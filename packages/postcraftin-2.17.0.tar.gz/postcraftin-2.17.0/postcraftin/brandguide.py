"""Brand Guide Generator for postcraftin.

Generates voice.md, vocabulary.md, anti-patterns.md from profile data.
"""

from pathlib import Path
from typing import Any


def generate_voice_guide(profile: dict[str, Any]) -> str:
    """Generate voice guide content from profile voice settings.

    Args:
        profile: Complete profile dict

    Returns:
        Markdown content for voice.md

    """
    voice = profile.get("voice", {})
    identity = profile.get("identity", {})

    formality = voice.get("formality", 3)
    archetype = voice.get("archetype", "inspirierend")
    humor_level = voice.get("humor_level", "gelegentlich")
    sentence_style = voice.get("sentence_style", "mixtur")
    personal_ratio = voice.get("personal_ratio", "50%")

    name = identity.get("name", "User")

    formality_map = {
        1: "sehr locker (Du/Slang)",
        2: "locker",
        3: "neutral",
        4: "formell",
        5: "sehr formell (Sie/Beamtendeutsch)",
    }

    content = f"""# Voice Guide for {name}

## Overview
This guide defines the writing voice and tone for LinkedIn posts.

## Voice Characteristics

| Attribute | Value |
|-----------|-------|
| **Formality** | {formality} - {formality_map.get(formality, "neutral")} |
| **Archetype** | {archetype} |
| **Humor Level** | {humor_level} |
| **Sentence Style** | {sentence_style} |
| **Personal Ratio** | {personal_ratio} |

## Archetype Guidelines: {archetype}

"""

    archetype_guidelines = {
        "analytisch": """
- Focus on data, facts, and logical arguments
- Use charts, statistics, and concrete examples
- Avoid emotional language or superlatives
- Structure: Problem → Analysis → Solution
- Tone: Objective, precise, evidence-based
""",
        "inspirierend": """
- Use motivational language and positive framing
- Share personal growth stories and transformations
- Include calls-to-action that inspire action
- Tone: Uplifting, empowering, visionary
- Use metaphors and analogies for complex ideas
""",
        "lehrend": """
- Position yourself as a mentor sharing wisdom
- Teach concepts step-by-step with examples
- Use "I learned that..." or "Here's how to..."
- Tone: Patient, clear, educational
- Include actionable takeaways in every post
""",
        "storytelling": """
- Lead with narratives, not bullet points
- Use "I remember when..." or "This happened to me..."
- Include sensory details and emotional arcs
- Tone: Narrative, engaging, relatable
- Structure: Hook → Story → Lesson → CTA
""",
        "provokativ": """
- Challenge conventional wisdom with evidence
- Use "Everyone thinks X, but actually..." structure
- Take contrarian positions backed by logic
- Tone: Bold, challenging, thought-provoking
- Back claims with data and examples
""",
    }

    content += archetype_guidelines.get(archetype, archetype_guidelines["inspirierend"])

    content += f"""
## Humor Guidelines: {humor_level}

"""

    humor_guidelines = {
        "kein": ("- Do not use humor\n- Maintain serious, professional tone\n- Focus on content, not entertainment"),
        "gelegentlich": (
            "- Use light humor sparingly (1-2 times per post)\n"
            "- Avoid jokes that might offend\n"
            "- Use self-deprecating humor or industry observations"
        ),
        "regelmäßig": (
            "- Incorporate humor more frequently (3-5 times per post)\n"
            "- Use wit, wordplay, or clever analogies\n"
            "- Keep it professional - no sarcasm or mockery"
        ),
    }

    content += humor_guidelines.get(humor_level, humor_guidelines["gelegentlich"])

    content += f"""

## Sentence Structure: {sentence_style}

"""

    sentence_guidelines = {
        "kurz": (
            "- Keep sentences under 15 words\n"
            "- Use simple subject-verb-object structure\n"
            "- Break complex ideas into multiple sentences\n"
            "- Punchy, easy to scan"
        ),
        "lang": (
            "- Allow sentences up to 25 words\n"
            "- Use some complex structures (but not too many)\n"
            "- Balance short and long sentences\n"
            "- Detailed explanations where needed"
        ),
        "mixtur": (
            "- Mix short (10-15 words) and medium (15-20 words)\n"
            "- Occasionally use longer sentences for emphasis\n"
            "- Vary rhythm for engagement\n"
            "- Most versatile option"
        ),
    }

    content += sentence_guidelines.get(sentence_style, sentence_guidelines["mixtur"])

    return content


def generate_vocabulary_guide(profile: dict[str, Any]) -> str:
    """Generate vocabulary guide from profile expertise and industry.

    Args:
        profile: Complete profile dict

    Returns:
        Markdown content for vocabulary.md

    """
    identity = profile.get("identity", {})
    audience = profile.get("audience", {})

    name = identity.get("name", "User")
    expertise_areas = identity.get("expertise_areas", [])
    industry = identity.get("industry", "")
    job_title = identity.get("job_title", "")
    geography = audience.get("geography", "DACH")

    content = f"""# Vocabulary Guide for {name}

## Industry & Role Context

- **Industry**: {industry}
- **Role**: {job_title}
- **Geography**: {geography}

## Words to Use

### Expertise Areas
"""

    for area in expertise_areas:
        content += f"- {area}\n"

    content += """
### Industry Terms
"""

    industry_terms = {
        "Software Development": ["API", "Framework", "DevOps", "CI/CD", "Refactoring", "Legacy Code"],
        "AI & Machine Learning": [
            "LLM",
            "Neural Network",
            "Training Data",
            "Inference",
            "Prompt Engineering",
            "Fine-tuning",
        ],
        "Marketing": ["ROI", "Conversion", "Funnel", "Lead Generation", "Brand Awareness"],
        "Finance": ["Cash Flow", "EBITDA", "Portfolio", "Diversification", "Compound Interest"],
        "Healthcare": ["Patient Care", "Evidence-Based", "Compliance", "Outcome Metrics", "Clinical"],
    }

    terms = industry_terms.get(industry, ["Professional", "Industry-specific"])
    for term in terms:
        content += f"- {term}\n"

    content += """
## Words to Avoid

### Overused Buzzwords
- "Disruptive" (unless you can prove it)
- "Game-changer" (too vague)
- "Synergy" (meaningless in most contexts)
- "Circle back" (use "follow up" instead)
- "Deep dive" (use "analyze" or "explore")

### Geography-Specific (DACH)
"""

    if geography == "DACH":
        content += """- Avoid English words that have German equivalents
- Use "KI" instead of "AI" (in German posts)
- Use "Künstliche Intelligenz" sparingly
"""
    else:
        content += "- Use locally appropriate language and terminology\n"

    content += """
## Tone Do's and Don'ts

### Do:
- Use active voice ("I built" not "was built")
- Write at reader's level (not above or below)
- Use concrete examples over abstract concepts
- Vary sentence starters

### Don't:
- Use passive voice excessively
- Write overly complex sentences
- Use jargon without explanation
- Repeat the same phrases across posts
"""

    return content


def generate_anti_patterns_guide(profile: dict[str, Any]) -> str:
    """Generate anti-patterns guide based on archetype.

    Args:
        profile: Complete profile dict

    Returns:
        Markdown content for anti-patterns.md

    """
    voice = profile.get("voice", {})
    archetype = voice.get("archetype", "inspirierend")

    content = f"""# Anti-Patterns Guide

## What NOT to Write (Based on Your Archetype: {archetype})

This guide lists patterns that contradict your chosen voice and should be avoided.

## General Anti-Patterns (All Archetypes)

### Structure Anti-Patterns
- ❌ Wall of text (no paragraphs)
- ❌ Super short posts (under 150 chars) - no value
- ❌ Super long posts (over 3000 chars) - hard to read
- ❌ No line breaks or formatting
- ❌ Multiple topics in one post (stay focused)

### Engagement Anti-Patterns
- ❌ No question at the end (CTA missing)
- ❌ "What do you think?" (too generic)
- ❌ No hashtags (reduce discoverability)
- ❌ More than 5 hashtags (looks spammy)
- ❌ External links in main post (reduces reach)

### Tone Anti-Patterns
- ❌ All caps sentences (shouting)
- ❌ Excessive exclamation marks (!!!)
- ❌ Emojis in professional posts (unless brand guide allows)
- ❌ Clickbait headlines ("You won't believe...")
- ❌ Overly salesy language ("Buy now", "Limited offer")

## Archetype-Specific Anti-Patterns: {archetype}

"""

    archetype_anti_patterns = {
        "analytisch": """
- ❌ Emotional appeals without data
- ❌ "I feel that..." (use "Data shows...")
- ❌ Vague statements ("It's good") - always quantify
- ❌ Personal anecdotes without broader lesson
- ❌ Subjective opinions presented as facts
""",
        "inspirierend": """
- ❌ Cynical or negative framing
- ❌ "I'm better than others" tone
- ❌ Purely factual posts without emotional connection
- ❌ Complaining without offering solutions
- ❌ Humblebragging (false modesty)
""",
        "lehrend": """
- ❌ "Do as I say" without explanation
- ❌ Overly complex explanations for simple concepts
- ❌ No examples or code snippets
- ❌ Talking down to the audience
- ❌ Long theoretical introductions without practical value
""",
        "storytelling": """
- ❌ Starting with "Once upon a time" (too cheesy)
- ❌ Pure facts without narrative arc
- ❌ Revealing the ending too early
- ❌ Stories where nothing changes (no transformation)
- ❌ Fictional stories presented as real
""",
        "provokativ": """
- ❌ Personal attacks on individuals
- ❌ Contrarian just for shock value (must have logic)
- ❌ "Everyone is wrong" (too broad)
- ❌ No evidence for bold claims
- ❌ Angry or aggressive tone
""",
    }

    content += archetype_anti_patterns.get(archetype, archetype_anti_patterns["inspirierend"])

    content += """
## Checklist Before Publishing

- [ ] Is the tone consistent with my archetype?
- [ ] Did I avoid the anti-patterns above?
- [ ] Is the post scannable (short paragraphs)?
- [ ] Do I have a clear CTA?
- [ ] Are hashtags relevant and not spammy?
"""

    return content


def generate_all_brand_guides(profile_name: str, profile: dict[str, Any]) -> Path:
    """Generate all brand guide files in profile's brandguide folder.

    Args:
        profile_name: Name of the profile
        profile: Complete profile dict

    Returns:
        Path to brandguide directory

    """
    from postcraftin.profile import get_brandguide_dir

    brandguide_dir = get_brandguide_dir(profile_name)
    brandguide_dir.mkdir(parents=True, exist_ok=True)

    # Generate voice.md
    voice_content = generate_voice_guide(profile)
    (brandguide_dir / "voice.md").write_text(voice_content, encoding="utf-8")

    # Generate vocabulary.md
    vocab_content = generate_vocabulary_guide(profile)
    (brandguide_dir / "vocabulary.md").write_text(vocab_content, encoding="utf-8")

    # Generate anti-patterns.md
    anti_content = generate_anti_patterns_guide(profile)
    (brandguide_dir / "anti-patterns.md").write_text(anti_content, encoding="utf-8")

    return brandguide_dir
