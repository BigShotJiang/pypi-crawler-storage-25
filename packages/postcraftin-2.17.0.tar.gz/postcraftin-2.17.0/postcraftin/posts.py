import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from postcraftin.profile import (
    get_posts_drafts_dir as _get_posts_drafts_dir,
    get_posts_published_dir as _get_posts_published_dir,
    get_history_dir,
    ensure_profile_dirs,
    init_history_stats,
)


def parse_frontmatter(content: str) -> tuple[dict[str, Any], str]:
    """Parse YAML frontmatter from markdown content.

    Returns: (frontmatter_dict, markdown_content)
    """
    if not content.startswith("---"):
        return {}, content

    parts = content.split("---", 2)
    if len(parts) < 3:
        return {}, content

    frontmatter_text = parts[1].strip()
    markdown_content = parts[2].strip()

    import yaml

    try:
        data = yaml.safe_load(frontmatter_text) or {}
    except yaml.YAMLError:
        data = {}

    return data, markdown_content


def render_frontmatter(data: dict[str, Any]) -> str:
    """Render frontmatter dict to YAML string."""
    import yaml

    return "---\n" + yaml.safe_dump(data, default_flow_style=False, allow_unicode=True) + "---"


def create_slug(text: str) -> str:
    """Create URL-safe slug from text."""
    text = text.lower()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_-]+", "-", text)
    return text.strip("-")


def get_posts_drafts_dir(name: str) -> Path:
    return _get_posts_drafts_dir(name)


def get_posts_published_dir(name: str) -> Path:
    return _get_posts_published_dir(name)


def get_posts_examples_dir(name: str) -> Path:
    """Get examples directory for profile."""
    from postcraftin.profile import get_posts_examples_dir as _get_examples_dir

    return _get_examples_dir(name)


def save_example_post(name: str, content: str, example_num: int) -> Path:
    """Save an example post to examples/ folder with frontmatter.

    Args:
        name: Profile name
        content: Post content as string
        example_num: Example number (1, 2, 3...)

    Returns:
        Path to saved file

    """
    now = datetime.now()
    frontmatter = {
        "created": now.strftime("%Y-%m-%d"),
        "type": "example",
        "example_num": example_num,
        "word_count": len(content.split()),
    }
    filename = f"beispiel-{example_num}.md"
    examples_dir = get_posts_examples_dir(name)
    examples_dir.mkdir(parents=True, exist_ok=True)
    filepath = examples_dir / filename

    full_content = render_frontmatter(frontmatter) + "\n\n" + content
    filepath.write_text(full_content, encoding="utf-8")
    return filepath


def list_example_posts(name: str) -> list[dict[str, Any]]:
    """List all example posts with frontmatter.

    Args:
        name: Profile name

    Returns:
        List of dicts with keys: filename, path, frontmatter, content

    """
    examples_dir = get_posts_examples_dir(name)
    if not examples_dir.exists():
        return []

    examples = []
    for filepath in sorted(examples_dir.glob("*.md")):
        content = filepath.read_text(encoding="utf-8")
        frontmatter, markdown = parse_frontmatter(content)
        examples.append(
            {
                "filename": filepath.name,
                "path": filepath,
                "frontmatter": frontmatter,
                "content": markdown,
            }
        )
    return examples


def create_post_filename(topic: str) -> str:
    """Create filename with UUID + short slug."""
    import uuid

    date = datetime.now().strftime("%Y-%m-%d")
    short_slug = create_slug(topic)[:20]  # Max 20 chars
    unique_id = str(uuid.uuid4())[:8]  # First 8 chars of UUID
    return f"{date}-{short_slug}-{unique_id}.md"


def create_post_with_frontmatter(
    name: str,
    content: str,
    template: str | None = None,
    topics: list[str] | None = None,
) -> Path:
    """Save a new post to drafts folder with frontmatter."""
    now = datetime.now()

    frontmatter = {
        "created": now.strftime("%Y-%m-%d"),
        "status": "draft",
        "template": template,
        "topics": topics or [],
        "word_count": len(content.split()),
        "published_date": None,
        "linkedin_url": "",
    }

    filename = create_post_filename(content[:50] if len(content) > 50 else content)
    drafts_dir = get_posts_drafts_dir(name)
    drafts_dir.mkdir(parents=True, exist_ok=True)
    filepath = drafts_dir / filename

    full_content = render_frontmatter(frontmatter) + "\n\n" + content
    filepath.write_text(full_content, encoding="utf-8")

    _update_stats_on_new_post(name, template, topics)

    return filepath


def update_post_status(name: str, filepath: Path, new_status: str) -> Path:
    """Update post status (draft -> published)."""
    content = filepath.read_text(encoding="utf-8")
    frontmatter, markdown_content = parse_frontmatter(content)

    frontmatter["status"] = new_status

    if new_status == "published":
        frontmatter["published_date"] = datetime.now().strftime("%Y-%m-%d")

    new_content = render_frontmatter(frontmatter) + "\n\n" + markdown_content

    new_dir = get_posts_published_dir(name) if new_status == "published" else get_posts_drafts_dir(name)
    new_dir.mkdir(parents=True, exist_ok=True)
    new_path = new_dir / filepath.name

    if filepath != new_path:
        filepath.unlink()
        filepath = new_path

    filepath.write_text(new_content, encoding="utf-8")

    _recalculate_stats(name)

    return filepath


def update_post_topics(name: str, filepath: Path, topics: list[str]) -> Path:
    """Update post topics in frontmatter."""
    content = filepath.read_text(encoding="utf-8")
    frontmatter, markdown_content = parse_frontmatter(content)

    frontmatter["topics"] = topics

    new_content = render_frontmatter(frontmatter) + "\n\n" + markdown_content
    filepath.write_text(new_content, encoding="utf-8")

    _recalculate_stats(name)

    return filepath


def update_post_linkedin_url(name: str, filepath: Path, url: str) -> Path:
    """Update LinkedIn URL in frontmatter."""
    content = filepath.read_text(encoding="utf-8")
    frontmatter, markdown_content = parse_frontmatter(content)

    frontmatter["linkedin_url"] = url

    new_content = render_frontmatter(frontmatter) + "\n\n" + markdown_content
    filepath.write_text(new_content, encoding="utf-8")

    return filepath


def list_profile_posts(
    name: str,
    status_filter: str | None = None,
    topic_filter: str | None = None,
    topics_or: list[str] | None = None,
) -> list[dict[str, Any]]:
    """List all posts with optional filters.

    Args:
        name: Profile name
        status_filter: Filter by status (draft/published)
        topic_filter: Filter by single topic
        topics_or: Filter by multiple topics (OR logic)

    Returns: List of post info dicts

    """
    posts = []

    drafts_dir = get_posts_drafts_dir(name)
    published_dir = get_posts_published_dir(name)

    all_dirs = []
    if drafts_dir.exists():
        all_dirs.append(("draft", drafts_dir))
    if published_dir.exists():
        all_dirs.append(("published", published_dir))

    for status, dir_path in all_dirs:
        if status_filter and status != status_filter:
            continue

        for filepath in dir_path.glob("*.md"):
            try:
                content = filepath.read_text(encoding="utf-8")
                frontmatter, _ = parse_frontmatter(content)
            except Exception:
                continue

            topics = frontmatter.get("topics", [])

            if topic_filter and topic_filter not in topics:
                continue

            if topics_or and not any(t in topics for t in topics_or):
                continue

            posts.append(
                {
                    "filename": filepath.name,
                    "filepath": str(filepath),
                    "status": status,
                    "created": frontmatter.get("created", ""),
                    "template": frontmatter.get("template"),
                    "topics": topics,
                    "word_count": frontmatter.get("word_count", 0),
                    "linkedin_url": frontmatter.get("linkedin_url", ""),
                }
            )

    posts.sort(key=lambda x: x["created"], reverse=True)
    return posts


def get_post_by_filename(name: str, filename: str) -> Path | None:
    """Find a post file by filename in drafts or published."""
    drafts_path = get_posts_drafts_dir(name) / filename
    if drafts_path.exists():
        return drafts_path

    published_path = get_posts_published_dir(name) / filename
    if published_path.exists():
        return published_path

    return None


def publish_post(name: str, filename: str) -> Path:
    """Publish a draft post."""
    filepath = get_post_by_filename(name, filename)
    if not filepath:
        raise FileNotFoundError(f"Post '{filename}' not found")

    if "drafts" not in str(filepath):
        raise ValueError("Post is already published")

    return update_post_status(name, filepath, "published")


def get_post_history_stats(name: str) -> dict[str, Any]:
    """Get post history stats."""
    stats_path = get_history_dir(name) / "stats.json"
    if stats_path.exists():
        with open(stats_path, "r", encoding="utf-8") as f:
            return json.load(f)

    return {
        "total_posts": 0,
        "draft_count": 0,
        "published_count": 0,
        "last_post": None,
        "by_template": {},
        "by_topic": {},
    }


def _update_stats_on_new_post(name: str, template: str | None, topics: list[str] | None) -> None:
    """Update stats when new post is created."""
    stats = get_post_history_stats(name)

    stats["total_posts"] += 1
    stats["draft_count"] += 1
    stats["last_post"] = datetime.now().strftime("%Y-%m-%d")

    if template:
        stats["by_template"][template] = stats["by_template"].get(template, 0) + 1

    for topic in topics or []:
        stats["by_topic"][topic] = stats["by_topic"].get(topic, 0) + 1

    _save_stats(name, stats)


def _recalculate_stats(name: str) -> None:
    """Recalculate all stats from filesystem."""
    posts = list_profile_posts(name)

    stats = {
        "total_posts": len(posts),
        "draft_count": sum(1 for p in posts if p["status"] == "draft"),
        "published_count": sum(1 for p in posts if p["status"] == "published"),
        "last_post": posts[0]["created"] if posts else None,
        "by_template": {},
        "by_topic": {},
    }

    for post in posts:
        template = post.get("template")
        if template:
            stats["by_template"][template] = stats["by_template"].get(template, 0) + 1

        for topic in post.get("topics", []):
            stats["by_topic"][topic] = stats["by_topic"].get(topic, 0) + 1

    _save_stats(name, stats)


def _save_stats(name: str, stats: dict) -> None:
    """Save stats to history/stats.json."""
    stats_path = get_history_dir(name) / "stats.json"
    stats_path.parent.mkdir(parents=True, exist_ok=True)

    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)


def init_history(name: str) -> None:
    """Initialize history folder and stats for profile."""
    ensure_profile_dirs(name)
    init_history_stats(name)
