import click
from datetime import datetime
from postcraftin.profile import (
    save_profile,
    load_profile,
    create_empty_profile,
    SCHEMA_VERSION,
)
from postcraftin import brandguide


def run_onboarding(profile_name: str) -> None:
    """Run full 6-module onboarding."""
    click.echo(click.style("\n🚀 postcraftin Pro Onboarding!", fg="cyan", bold=True))
    click.echo("6 Module - etwa 15-20 Minuten.\n")
    click.echo(click.style("Drücke ENTER für Default-Werte.\n", fg="bright_black"))

    try:
        existing = load_profile(profile_name)
        profile = existing
        click.echo(click.style(f"→ Bestehendes Profil geladen: {profile_name}", fg="green"))
    except FileNotFoundError:
        profile = create_empty_profile()
        click.echo(click.style(f"→ Neues Profil: {profile_name}", fg="yellow"))

    identity = profile.get("identity", {})
    voice = profile.get("voice", {})
    audience = profile.get("audience", {})
    cs = profile.get("content_strategy", {})
    tp = profile.get("technical_preferences", {})

    click.echo(click.style("\n1️⃣ IDENTITÄT", fg="cyan", bold=True))
    identity["name"] = click.prompt("Dein Name", default=identity.get("name", ""))
    identity["job_title"] = click.prompt("Job-Bezeichnung", default=identity.get("job_title", ""))
    identity["company"] = click.prompt("Firma / Projekt", default=identity.get("company", ""))
    identity["is_freelance"] = click.confirm("Freelancer?", default=identity.get("is_freelance", False))
    identity["industry"] = click.prompt("Branche", default=identity.get("industry", ""))
    identity["years_experience"] = click.prompt(
        "Jahre Berufserfahrung", default=str(identity.get("years_experience", 0)), type=int
    )
    expertise_raw = click.prompt(
        "Expertise-Gebiete (kommagetrennt)", default=", ".join(identity.get("expertise_areas", []))
    )
    identity["expertise_areas"] = [e.strip() for e in expertise_raw.split(",") if e.strip()]
    identity["recent_transformation"] = click.prompt(
        "Letzte große Transformation", default=identity.get("recent_transformation", "")
    )

    click.echo(click.style("\n2️⃣ STIMME & TON", fg="cyan", bold=True))
    click.echo("Formality: 1=sehr locker, 5=sehr formell")
    formality = click.prompt("Formality-Level", default=str(voice.get("formality", 3)), type=int)
    voice["formality"] = max(1, min(5, formality))
    click.echo("\nArchetypen: analytisch, inspirierend, lehrend, storytelling, provokativ")
    voice["archetype"] = click.prompt(
        "Archetyp",
        type=click.Choice(
            ["analytisch", "inspirierend", "lehrend", "storytelling", "provokativ"],
            case_sensitive=False,
        ),
        default=voice.get("archetype", "inspirierend"),
    )
    voice["humor_level"] = click.prompt(
        "Humor",
        type=click.Choice(["kein", "gelegentlich", "regelmäßig"], case_sensitive=False),
        default=voice.get("humor_level", "gelegentlich"),
    )
    voice["sentence_style"] = click.prompt(
        "Satz-Stil",
        type=click.Choice(["kurz", "mixtur", "lang"], case_sensitive=False),
        default=voice.get("sentence_style", "mixtur"),
    )
    click.echo("\nPersonal Ratio: 0%=komplett professionell, 100%=sehr persönlich")
    voice["personal_ratio"] = click.prompt("Personal Ratio", default=voice.get("personal_ratio", "50%"))

    click.echo(click.style("\n3️⃣ ZIELGRUPPE", fg="cyan", bold=True))
    roles_raw = click.prompt("Primäre Zielrollen (kommagetrennt)", default=", ".join(audience.get("primary_roles", [])))
    audience["primary_roles"] = [r.strip() for r in roles_raw.split(",") if r.strip()]
    sec_roles_raw = click.prompt(
        "Sekundäre Zielrollen (kommagetrennt, optional)", default=", ".join(audience.get("secondary_roles", []))
    )
    audience["secondary_roles"] = [r.strip() for r in sec_roles_raw.split(",") if r.strip()]
    ind_raw = click.prompt("Branchen (kommagetrennt)", default=", ".join(audience.get("industries", [])))
    audience["industries"] = [i.strip() for i in ind_raw.split(",") if i.strip()]
    seniority_raw = click.prompt(
        "Seniority (kommagetrennt): Junior, Mid, Senior, C-Level",
        default=", ".join(audience.get("seniority_focus", [])),
    )
    audience["seniority_focus"] = [s.strip() for s in seniority_raw.split(",") if s.strip()]
    audience["geography"] = click.prompt(
        "Geografie",
        type=click.Choice(["DACH", "EU", "Global"], case_sensitive=False),
        default=audience.get("geography", "DACH"),
    )
    audience["connection_intent"] = click.prompt(
        "Was soll die Zielgruppe tun?",
        type=click.Choice(["Hire", "Follow", "Discuss", "Buy"], case_sensitive=False),
        default=audience.get("connection_intent", "Follow"),
    )

    click.echo(click.style("\n4️⃣ CONTENT STRATEGIE", fg="cyan", bold=True))
    click.echo("Content Pillars (leer = fertig):")
    pillars = []
    while True:
        name = click.prompt(f"  Pillar #{len(pillars) + 1} Name (leer = fertig)", default="")
        if not name:
            break
        weight = click.prompt(f"  Gewichtung '{name}' (0-100)", default="50", type=int)
        subtopics_raw = click.prompt(f"  Unterthemen für '{name}' (kommagetrennt)", default="")
        post_types_raw = click.prompt("  Post-Typen (kommagetrennt)", default="insight")
        pillars.append(
            {
                "name": name,
                "weight": max(0, min(100, weight)),
                "subtopics": [s.strip() for s in subtopics_raw.split(",") if s.strip()],
                "post_types": [p.strip() for p in post_types_raw.split(",") if p.strip()],
            }
        )
    if not pillars:
        pillars = [{"name": "General", "weight": 100, "subtopics": [], "post_types": ["insight"]}]
    cs["pillars"] = pillars
    cs["posting_frequency"] = click.prompt("Posting-Frequenz", default=cs.get("posting_frequency", "3x per week"))
    days_raw = click.prompt(
        "Bevorzugte Tage (kommagetrennt)", default=", ".join(cs.get("preferred_days", ["Di", "Do"]))
    )
    cs["preferred_days"] = [d.strip() for d in days_raw.split(",") if d.strip()]
    cs["preferred_time"] = click.prompt("Bevorzugte Zeit", default=cs.get("preferred_time", "08:00-10:00"))
    goals_raw = click.prompt(
        "Content-Ziele (kommagetrennt)", default=", ".join(cs.get("content_goals", ["Thought Leadership"]))
    )
    cs["content_goals"] = [g.strip() for g in goals_raw.split(",") if g.strip()]

    click.echo(click.style("\n5️⃣ BEISPIEL-POSTS (STILPROBEN)", fg="cyan", bold=True))
    click.echo("Füge 2-3 Beispiel-Posts ein, die deinen Stil zeigen.")
    click.echo("(Beende mit 'END' auf einer neuen Zeile)")

    for i in range(1, 4):
        click.echo(click.style(f"\nBeispiel #{i}:", fg="green"))
        lines = []
        while True:
            line = input()
            if line.strip().upper() == "END":
                break
            lines.append(line)
        if lines:
            content = "\n".join(lines).strip()
            try:
                from postcraftin.posts import save_example_post

                save_example_post(profile_name, content, i)
                click.echo(click.style(f"✅ Beispiel #{i} gespeichert", fg="green"))
            except ImportError:
                click.echo(click.style(f"⚠️  Konnte Beispiel #{i} nicht speichern", fg="yellow"))

    # Clear stylesamples from JSON (now stored as files)
    profile["post_history"]["stylesamples"] = []

    click.echo(click.style("\n6️⃣ TECHNISCHE PRÄFERENZEN", fg="cyan", bold=True))
    tp["model"] = click.prompt(
        "Ollama Model (leer = globaler Default)",
        default=tp.get("model", ""),
    )
    tp["output_language"] = click.prompt(
        "Sprache",
        type=click.Choice(["DE", "EN", "DE+EN"], case_sensitive=False),
        default=tp.get("output_language", "DE"),
    )
    tp["post_length_target"] = click.prompt(
        "Länge",
        type=click.Choice(["Short", "Medium", "Long"], case_sensitive=False),
        default=tp.get("post_length_target", "Medium"),
    )
    tp["emoji_style"] = click.prompt(
        "Emoji-Style",
        type=click.Choice(["None", "Minimal", "Moderate", "Heavy"], case_sensitive=False),
        default=tp.get("emoji_style", "Minimal"),
    )
    tp["hashtag_style"] = click.prompt(
        "Hashtag-Style",
        type=click.Choice(["None", "Minimal", "Standard", "Max"], case_sensitive=False),
        default=tp.get("hashtag_style", "Standard"),
    )
    tp["cta_default"] = click.prompt(
        "Default CTA",
        type=click.Choice(["Question", "Save", "Share", "Follow", "None"], case_sensitive=False),
        default=tp.get("cta_default", "Question"),
    )
    tp["formatting_style"] = click.prompt(
        "Formatting",
        type=click.Choice(["Fließtext", "Bullet", "Nummeriert", "Gemischt"], case_sensitive=False),
        default=tp.get("formatting_style", "Gemischt"),
    )
    tp["include_hook_suggestion"] = click.confirm("Hook-Vorschlag?", default=tp.get("include_hook_suggestion", True))
    tp["post_variants_count"] = click.prompt(
        "Anzahl Varianten", default=str(tp.get("post_variants_count", 1)), type=int
    )

    profile["identity"] = identity
    profile["voice"] = voice
    profile["audience"] = audience
    profile["content_strategy"] = cs
    profile["technical_preferences"] = tp
    profile["meta"]["version"] = SCHEMA_VERSION
    profile["meta"]["last_updated"] = datetime.now().isoformat()
    profile["meta"]["interview_completed"] = True

    save_profile(profile_name, profile)
    click.echo(click.style(f"\n✅ Profil '{profile_name}' gespeichert!", fg="green", bold=True))
    click.echo(click.style(f"Version: {SCHEMA_VERSION}", fg="bright_black"))

    # Generate brand guide
    try:
        brandguide.generate_all_brand_guides(profile_name, profile)
        click.echo(click.style("✅ Brand Guide generiert!", fg="green"))
    except ImportError:
        click.echo(click.style("⚠️  Brand Guide Generator nicht verfügbar", fg="yellow"))


def run_module_onboarding(profile_name: str, module: str) -> None:
    """Run modular onboarding for specific module(s)."""
    MODULES = {
        "identity": _run_identity_module,
        "voice": _run_voice_module,
        "audience": _run_audience_module,
        "content_strategy": _run_content_module,
        "technical_preferences": _run_technical_module,
    }

    if module == "all":
        run_onboarding(profile_name)
        return

    if module not in MODULES:
        click.echo(click.style(f"❌ Unbekanntes Modul: {module}", fg="red"))
        click.echo(f"Verfügbar: {', '.join(MODULES.keys())}, all")
        raise SystemExit(1)

    try:
        existing = load_profile(profile_name)
        profile = existing
    except FileNotFoundError:
        profile = create_empty_profile()

    result = MODULES[module](profile)
    profile[module].update(result[module])
    profile["meta"]["version"] = SCHEMA_VERSION
    profile["meta"]["last_updated"] = datetime.now().isoformat()
    profile["meta"]["interview_completed"] = True

    save_profile(profile_name, profile)
    click.echo(click.style(f"\n✅ Modul '{module}' aktualisiert!", fg="green", bold=True))


def _run_identity_module(profile: dict) -> dict:
    """Run identity module interview."""
    identity = profile.get("identity", {})
    click.echo(click.style("\n1️⃣ IDENTITÄT", fg="cyan", bold=True))

    identity["name"] = click.prompt("Dein Name", default=identity.get("name", ""))
    identity["job_title"] = click.prompt("Job-Bezeichnung", default=identity.get("job_title", ""))
    identity["company"] = click.prompt("Firma / Projekt", default=identity.get("company", ""))
    identity["is_freelance"] = click.confirm("Freelancer?", default=identity.get("is_freelance", False))
    identity["industry"] = click.prompt("Branche", default=identity.get("industry", ""))
    expertise_raw = click.prompt(
        "Expertise-Gebiete (kommagetrennt)", default=", ".join(identity.get("expertise_areas", []))
    )
    identity["expertise_areas"] = [e.strip() for e in expertise_raw.split(",") if e.strip()]
    identity["recent_transformation"] = click.prompt(
        "Letzte große Transformation", default=identity.get("recent_transformation", "")
    )
    return {"identity": identity}


def _run_voice_module(profile: dict) -> dict:
    """Run voice module interview."""
    voice = profile.get("voice", {})
    click.echo(click.style("\n2️⃣ STIMME & TON", fg="cyan", bold=True))

    click.echo("Formality: 1=sehr locker, 5=sehr formell")
    formality = click.prompt("Formality-Level", default=str(voice.get("formality", 3)), type=int)
    voice["formality"] = max(1, min(5, formality))

    click.echo("\nArchetypen: analytisch, inspirierend, lehrend, storytelling, provokativ")
    voice["archetype"] = click.prompt(
        "Archetyp",
        type=click.Choice(
            ["analytisch", "inspirierend", "lehrend", "storytelling", "provokativ"],
            case_sensitive=False,
        ),
        default=voice.get("archetype", "inspirierend"),
    )
    voice["humor_level"] = click.prompt(
        "Humor",
        type=click.Choice(["kein", "gelegentlich", "regelmäßig"], case_sensitive=False),
        default=voice.get("humor_level", "gelegentlich"),
    )
    voice["sentence_style"] = click.prompt(
        "Satz-Stil",
        type=click.Choice(["kurz", "mixtur", "lang"], case_sensitive=False),
        default=voice.get("sentence_style", "mixtur"),
    )
    voice["personal_ratio"] = click.prompt("Personal Ratio (0-100%)", default=voice.get("personal_ratio", "50%"))
    return {"voice": voice}


def _run_audience_module(profile: dict) -> dict:
    """Run audience module interview."""
    audience = profile.get("audience", {})
    click.echo(click.style("\n3️⃣ ZIELGRUPPE", fg="cyan", bold=True))

    roles_raw = click.prompt("Primäre Zielrollen (kommagetrennt)", default=", ".join(audience.get("primary_roles", [])))
    audience["primary_roles"] = [r.strip() for r in roles_raw.split(",") if r.strip()]

    ind_raw = click.prompt("Branchen (kommagetrennt)", default=", ".join(audience.get("industries", [])))
    audience["industries"] = [i.strip() for i in ind_raw.split(",") if i.strip()]

    audience["geography"] = click.prompt(
        "Geografie",
        type=click.Choice(["DACH", "EU", "Global"], case_sensitive=False),
        default=audience.get("geography", "DACH"),
    )
    audience["connection_intent"] = click.prompt(
        "Ziel",
        type=click.Choice(["Hire", "Follow", "Discuss", "Buy"], case_sensitive=False),
        default=audience.get("connection_intent", "Follow"),
    )
    return {"audience": audience}


def _run_content_module(profile: dict) -> dict:
    """Run content strategy module interview."""
    cs = profile.get("content_strategy", {})
    click.echo(click.style("\n4️⃣ CONTENT STRATEGIE", fg="cyan", bold=True))

    click.echo("Content Pillars (leer = fertig):")
    pillars = []
    while True:
        name = click.prompt(f"  Pillar #{len(pillars) + 1} Name (leer = fertig)", default="")
        if not name:
            break
        weight = click.prompt(f"  Gewichtung '{name}' (0-100)", default="50", type=int)
        pillars.append({"name": name, "weight": max(0, min(100, weight)), "subtopics": [], "post_types": ["insight"]})
    if not pillars:
        pillars = [{"name": "General", "weight": 100, "subtopics": [], "post_types": ["insight"]}]
    cs["pillars"] = pillars

    cs["posting_frequency"] = click.prompt("Posting-Frequenz", default=cs.get("posting_frequency", "3x per week"))
    return {"content_strategy": cs}


def _run_technical_module(profile: dict) -> dict:
    """Run technical preferences module interview."""
    tp = profile.get("technical_preferences", {})
    click.echo(click.style("\n6️⃣ TECHNISCHE PRÄFERENZEN", fg="cyan", bold=True))

    tp["model"] = click.prompt(
        "Ollama Model (leer = globaler Default)",
        default=tp.get("model", ""),
    )
    tp["output_language"] = click.prompt(
        "Sprache",
        type=click.Choice(["DE", "EN", "DE+EN"], case_sensitive=False),
        default=tp.get("output_language", "DE"),
    )
    tp["post_length_target"] = click.prompt(
        "Länge",
        type=click.Choice(["Short", "Medium", "Long"], case_sensitive=False),
        default=tp.get("post_length_target", "Medium"),
    )
    tp["emoji_style"] = click.prompt(
        "Emoji-Style",
        type=click.Choice(["None", "Minimal", "Moderate", "Heavy"], case_sensitive=False),
        default=tp.get("emoji_style", "Minimal"),
    )
    tp["hashtag_style"] = click.prompt(
        "Hashtag-Style",
        type=click.Choice(["None", "Minimal", "Standard", "Max"], case_sensitive=False),
        default=tp.get("hashtag_style", "Standard"),
    )
    tp["cta_default"] = click.prompt(
        "Default CTA",
        type=click.Choice(["Question", "Save", "Share", "Follow", "None"], case_sensitive=False),
        default=tp.get("cta_default", "Question"),
    )
    return {"technical_preferences": tp}
