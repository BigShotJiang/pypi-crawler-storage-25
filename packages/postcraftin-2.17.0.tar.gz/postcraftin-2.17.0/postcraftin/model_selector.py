import subprocess

import requests
from rich.console import Console
from rich.table import Table

from postcraftin.config_manager import get_ollama_host

console = Console()


def list_available_models(host: str | None = None) -> list[dict]:
    """Fetch list of available Ollama models via API."""
    if host is None:
        host = get_ollama_host()
    try:
        response = requests.get(f"{host}/api/tags", timeout=5)
        response.raise_for_status()
        data = response.json()
        return data.get("models", [])
    except requests.RequestException:
        try:
            result = subprocess.run(
                ["ollama", "list"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                lines = result.stdout.strip().split("\n")[1:]
                models = []
                for line in lines:
                    parts = line.split()
                    if parts:
                        name = parts[0]
                        size = parts[2] if len(parts) > 2 else "Unknown"
                        models.append({"name": name, "size": size})
                return models
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass
        return []


def format_model_table(models: list[dict]) -> Table:
    """Format models as a Rich table."""
    table = Table(title="Available Ollama Models")
    table.add_column("Name", style="cyan")
    table.add_column("Size", style="dim")
    table.add_column("Details", style="green")

    for model in models:
        name = model.get("name", "Unknown")
        size = model.get("size", "")
        if not size and "size" in model:
            size_gb = model.get("size", 0) / (1024**3)
            size = f"{size_gb:.1f} GB"
        elif isinstance(size, int):
            size = f"{size / (1024**3):.1f} GB" if size > 0 else "Unknown"
        details = model.get("details", {})
        if details:
            params = details.get("parameter_size", "")
            family = details.get("family", "")
            detail_str = f"{params} {family}" if params and family else params or family
        else:
            detail_str = ""
        table.add_row(name, size, detail_str)

    return table


def select_model_interactive(models: list[dict], default: str | None = None) -> str | None:
    """Interactive model selection with Rich prompt."""
    if not models:
        console.print("[red]No models available. Please pull a model first:[/red]")
        console.print("  ollama pull <model-name>")
        return None

    if default is None:
        from postcraftin.config_manager import get_model

        default = get_model()

    console.print("\n[cyan]Select a model:[/cyan]")
    for i, model in enumerate(models, 1):
        name = model.get("name", "")
        marker = " [green](default)[/green]" if name == default else ""
        console.print(f"  {i}. {name}{marker}")

    console.print("  0. Cancel")

    while True:
        choice = console.input("\n[dim]Enter number (or press Enter for default):[/dim] ")
        if not choice:
            return default
        try:
            idx = int(choice)
            if idx == 0:
                return None
            if 1 <= idx <= len(models):
                return models[idx - 1].get("name")
        except ValueError:
            pass
        console.print("[red]Invalid choice. Please try again.[/red]")


def get_model_by_name(name: str, models: list[dict]) -> dict | None:
    """Get model details by name."""
    for model in models:
        if model.get("name") == name:
            return model
    return None
