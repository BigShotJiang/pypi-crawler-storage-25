"""Clear: Cross-platform console screen clearing utility."""
