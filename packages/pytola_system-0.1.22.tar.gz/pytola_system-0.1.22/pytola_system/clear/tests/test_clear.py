"""Tests for clear console utility."""

import platform
from unittest.mock import patch


def test_clear_import():
    """Test that clear module can be imported."""
    from pytola_system.clear.cli import main

    if not callable(main):
        msg = "main function should be callable"
        raise AssertionError(msg)  # noqa: TRY004


def test_clear_screen_function_exists():
    """Test that clear_screen function exists."""
    from pytola_system.clear.cli import clear_screen

    if not callable(clear_screen):
        msg = "clear_screen function should be callable"
        raise AssertionError(msg)  # noqa: TRY004


def test_platform_detection():
    """Test platform detection logic."""
    from pytola_system.clear.cli import IS_WINDOWS

    # Verify IS_WINDOWS matches actual platform
    actual_is_windows = platform.system() == "Windows"
    if actual_is_windows != IS_WINDOWS:
        msg = f"IS_WINDOWS ({IS_WINDOWS}) should match actual platform ({actual_is_windows})"
        raise AssertionError(msg)


@patch("pytola_system.clear.cli.subprocess.run")
def test_clear_screen_windows(mock_subprocess):
    """Test clear_screen on Windows (mocked)."""
    from pytola_system.clear.cli import clear_screen

    with patch("pytola_system.clear.cli.IS_WINDOWS", True):
        clear_screen()
        # Should call cmd.exe with cls command
        mock_subprocess.assert_called_with(["cmd", "/c", "cls"], check=True)


@patch("pytola_system.clear.cli.subprocess.run")
def test_clear_screen_unix(mock_subprocess):
    """Test clear_screen on Unix-like systems (mocked)."""
    from pytola_system.clear.cli import clear_screen

    with patch("pytola_system.clear.cli.IS_WINDOWS", False):
        clear_screen()
        # Should call clear command
        mock_subprocess.assert_called_with(["clear"], check=True)


def test_main_function():
    """Test that main function runs without errors."""
    from pytola_system.clear.cli import main

    # Mock sys.argv to avoid argparse issues
    with patch("sys.argv", ["clear"]):
        result = main()
        # Should return 0 on success
        if result != 0:
            msg = f"main should return 0 on success, got {result}"
            raise AssertionError(msg)


def test_main_with_debug():
    """Test main function with debug flag."""
    from pytola_system.clear.cli import main

    with patch("sys.argv", ["clear", "--debug"]):
        result = main()
        if result != 0:
            msg = f"main should return 0 on success, got {result}"
            raise AssertionError(msg)


def test_ansi_escape_code_output():
    """Test that ANSI escape codes are printed."""
    # Capture stdout
    import io
    import sys

    from pytola_system.clear.cli import clear_screen

    captured_output = io.StringIO()
    old_stdout = sys.stdout
    sys.stdout = captured_output

    try:
        with patch("pytola_system.clear.cli.subprocess.run"):
            clear_screen()

        output = captured_output.getvalue()
        # Should contain ANSI escape codes
        if "\033[2J" not in output:
            msg = "Output should contain ANSI escape code \\033[2J"
            raise AssertionError(msg)
        if "\033[H" not in output:
            msg = "Output should contain ANSI escape code \\033[H"
            raise AssertionError(msg)
    finally:
        sys.stdout = old_stdout
