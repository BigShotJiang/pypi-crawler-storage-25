"""SSH key deployment utility."""
