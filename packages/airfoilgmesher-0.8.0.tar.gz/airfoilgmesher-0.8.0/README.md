# AirfoilGMesher

Python tools for generating and meshing airfoil geometries with Gmsh.

## Installation

```bash
pip install airfoilgmesher