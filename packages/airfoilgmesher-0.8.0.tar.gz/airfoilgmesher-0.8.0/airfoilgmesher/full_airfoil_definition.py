import numpy as np
from math import comb
import os
from airfoilgmesher.utils import enforce_slat_gap, enforce_flap_gap
from stl import mesh

def read_rae2822_airfoil(geometry_params):
    
    points = np.loadtxt(os.path.dirname(__file__) + "/airfoil_coordinates/RAE2822.dat").reshape(-1, 3)
    valid = points[:,0]>0.1
    points = points[valid,:]

    lower = points[:, :2].T
    upper = points[:, [0, 2]].T
    lower[1] = -lower[1]

    stl_mesh = mesh.Mesh.from_file(os.path.dirname(__file__) + "/airfoil_coordinates/rae2822_airfoil.stl")
    vertices = stl_mesh.vectors.reshape(-1, 3)

    # Remove duplicated nodes
    nodes = np.unique(vertices, axis=0)
    # Coordinates
    x = nodes[:, 0]
    y = nodes[:, 1]
    z = nodes[:, 2]
    c = np.max(x) - np.min(x)
    x/=c
    y/=c
    z/=c

    valid = z<0
    x = x[valid]
    y = y[valid]
    valid = x<=0.1
    x = x[valid]
    y = y[valid]

    upper_idx = y>=0
    lower_idx = y<0

    x_upper = x[upper_idx]
    x_lower = x[lower_idx]
    y_upper = y[upper_idx]
    y_lower = y[lower_idx]

    front_upper = np.vstack((x_upper, y_upper))
    front_lower = np.vstack((x_lower, y_lower))

    idx = np.argsort(front_upper[0,:])
    front_upper = front_upper[:, idx]
    idx = np.argsort(front_lower[0,:])
    front_lower = front_lower[:, idx]

    upper = np.hstack((front_upper, upper))
    lower = np.hstack((front_lower, lower))
    return np.hstack((np.flip(upper,axis=1), lower))

def read_30p30n_airfoil(derotate=False):
    points = np.loadtxt(os.path.dirname(__file__) + "/airfoil_coordinates/30P30N.dat").reshape(-1, 2).T
    slat = points[:,:200]
    main = points[:,201:421]
    flap = points[:,422:]

    # Slat
    idx_TE_slat = 0
    idx_low_point = 75
    angle = np.atan2(slat[1,idx_TE_slat]-slat[1,idx_low_point:idx_low_point+50], slat[0,idx_TE_slat]-slat[0,idx_low_point:idx_low_point+50])*180/np.pi
    idx_LE_slat = np.argmin(np.abs(angle-30)) + idx_low_point
    if derotate:
        slat_copy = slat.copy()
        slat_copy[0,:] = slat[0,:]*np.cos(np.radians(30)) + slat[1,:]*np.sin(np.radians(30))
        slat_copy[1,:] = -slat[0,:]*np.sin(np.radians(30)) + slat[1,:]*np.cos(np.radians(30))
        slat = slat_copy.copy()
        del slat_copy
        idx_LE_slat = np.argmin(slat[0,:])
        slat[0,:] = slat[0,:] - slat[0,idx_LE_slat]
        slat[1,:] = slat[1,:] - slat[1,idx_LE_slat]
    # Main
    idx_top_straight = 40
    idx_bot_straight = 57
    idx_LE_main = np.argmin(main[0,:])
    idx_TE_main = np.argmax(main[0,:])
    # Flap
    idx_TE_flap = flap.shape[1]-1
    idx_LE_flap = np.argmin(flap[0,:])
    if derotate:
        flap[0,:] = flap[0,:] - flap[0,idx_TE_flap]
        flap[1,:] = flap[1,:] - flap[1,idx_TE_flap]
        flap_copy = flap.copy()
        flap_copy[0,:] = flap[0,:]*np.cos(np.radians(30)) - flap[1,:]*np.sin(np.radians(30))
        flap_copy[1,:] = flap[0,:]*np.sin(np.radians(30)) + flap[1,:]*np.cos(np.radians(30))
        flap = flap_copy.copy()
        del flap_copy
        flap[0,:] = flap[0,:] - flap[0,idx_TE_flap] + 1
        flap[1,:] = flap[1,:] - flap[1,idx_TE_flap]
        idx_LE_flap = np.argmin(flap[0,:])

    info = {
        'idx_LE_slat': idx_LE_slat,
        'idx_TE_slat': idx_TE_slat,
        'idx_low_point_slat': idx_low_point,
        'idx_mid_point_back': int((slat.shape[1]-idx_low_point)/2),
        'idx_LE_main': idx_LE_main,
        'idx_TE_main': idx_TE_main,
        'idx_top_straight_main': idx_top_straight,
        'idx_bot_straight_main': idx_bot_straight,
        'idx_LE_flap': idx_LE_flap,
        'idx_TE_flap': idx_TE_flap,
    }

    return slat, main, flap, info

def permute_3_piece_airfoil(slat=None, main=None, flap=None, splitting_parameters=None, split_info=None, permutation_params=None):
    if splitting_parameters['scenario'] == 'slat' or splitting_parameters['scenario'] == 'slat-flap':
        idx_LE_slat = split_info['idx_LE_slat']
        idx_TE_slat = split_info['idx_TE_slat']
        delta_s = permutation_params['delta_s']
        o_s = permutation_params['o_s']
        g_s = permutation_params['g_s']
        new_slat = slat.copy()
        if g_s<o_s:
            raise ValueError("Target gaps must be greater than offsets to ensure physical feasibility.")

    if splitting_parameters['scenario'] == 'flap' or splitting_parameters['scenario'] == 'slat-flap':
        idx_LE_flap = split_info['idx_LE_flap']
        idx_TE_flap = split_info['idx_TE_flap']
        delta_f = permutation_params['delta_f']
        o_f = permutation_params['o_f']
        g_f = permutation_params['g_f']
        new_flap = flap.copy()
        if g_f<o_f:
            raise ValueError("Target gaps must be greater than offsets to ensure physical feasibility.")

    idx_LE_main = split_info['idx_LE_main']
    idx_TE_main = split_info['idx_TE_main']

    max_iter = 1000
    tol = 1e-6

    if splitting_parameters['scenario'] == 'slat' or splitting_parameters['scenario'] == 'slat-flap':
        new_slat[0,:] = slat[0,:]*np.cos(np.radians(delta_s)) - slat[1,:]*np.sin(np.radians(delta_s))
        new_slat[1,:] = slat[0,:]*np.sin(np.radians(delta_s)) + slat[1,:]*np.cos(np.radians(delta_s))
        new_slat[0,:] = new_slat[0,:] - np.max(new_slat[0,:]) + main[0,idx_LE_main] - o_s
        new_slat[1,:] = new_slat[1,:] - np.max(new_slat[1,:])
        gap = np.sqrt((new_slat[0,idx_TE_slat] - main[0, :])**2 + (new_slat[1,idx_TE_slat] - main[1, :])**2)
        idx = np.argmin(gap)
        new_slat[1,:] += main[1,idx]
        gap = np.sqrt((new_slat[0,idx_TE_slat] - main[0, :])**2 + (new_slat[1,idx_TE_slat] - main[1, :])**2)
        new_slat = enforce_slat_gap(main,
                                    new_slat,
                                    idx_TE_slat,
                                    g_s,
                                    max_iter=max_iter,
                                    tol=tol,
                                    direction=-1.0,)

    if splitting_parameters['scenario'] == 'flap' or splitting_parameters['scenario'] == 'slat-flap':
        flap[0,:] = flap[0,:] - flap[0,idx_LE_flap]
        new_flap[0,:] = flap[0,:]*np.cos(np.radians(-delta_f)) - flap[1,:]*np.sin(np.radians(-delta_f))
        new_flap[1,:] = flap[0,:]*np.sin(np.radians(-delta_f)) + flap[1,:]*np.cos(np.radians(-delta_f)) -1
        new_flap[0,:] = new_flap[0,:] - np.min(new_flap[0,:]) + main[0,idx_TE_main] + o_f
        new_flap[1,:] = new_flap[1,:] - np.max(new_flap[1,:]) + main[1,idx_TE_main]
        new_flap = enforce_flap_gap(
                                    main,
                                    new_flap,
                                    idx_LE_flap,
                                    g_f,
                                    max_iter=max_iter,
                                    tol=tol,
                                    direction=-1.0,
                                )
    if splitting_parameters['scenario'] == 'slat':
        return new_slat, main
    elif splitting_parameters['scenario'] == 'flap':
        return main, new_flap
    elif splitting_parameters['scenario'] == 'slat-flap':
        return new_slat, main, new_flap

def define_naca_airfoil(parameters):
    """
    Generate N points on a NACA 4-digit airfoil surface.

    Parameters
    ----------
    parameters : dict
        Dictionary with:
            m : float
                Maximum camber, e.g. 0.02 for NACA 2412.
            p : float
                Location of maximum camber, e.g. 0.4 for NACA 2412.
            t : float
                Maximum thickness, e.g. 0.12 for NACA 2412.
            N : int
                Total number of surface points.
            closed_te : bool, optional
                If True, uses closed trailing-edge coefficient.
                Default is True.

    Returns
    -------
    coords : ndarray, shape (2, N)
        Surface coordinates ordered as:

            TE -> upper surface -> LE -> lower surface -> TE
    """

    m = float(parameters["m"])
    p = float(parameters["p"])
    t = float(parameters["t"])
    N = int(parameters["N"])
    closed_te = bool(parameters.get("closed_te", True))

    if N < 3:
        raise ValueError("N must be at least 3.")

    if t < 0:
        raise ValueError("Thickness t must be non-negative.")

    if p < 0 or p > 1:
        raise ValueError("Camber location p must be in [0, 1].")

    # Number of points per surface.
    # Upper includes TE and LE.
    # Lower includes LE and TE.
    # LE is removed once during concatenation, so total is N.
    n_upper = N // 2 + 1
    n_lower = N - n_upper + 1

    # Cosine spacing
    # Upper: TE -> LE
    beta_u = np.linspace(0.0, np.pi, n_upper)
    x_u_base = 0.5 * (1.0 + np.cos(beta_u))

    # Lower: LE -> TE
    beta_l = np.linspace(np.pi, 0.0, n_lower)
    x_l_base = 0.5 * (1.0 + np.cos(beta_l))

    def thickness_distribution(x):
        a4 = -0.1036 if closed_te else -0.1015

        return 5.0 * t * (
            0.2969 * np.sqrt(np.maximum(x, 0.0))
            - 0.1260 * x
            - 0.3516 * x**2
            + 0.2843 * x**3
            + a4 * x**4
        )

    def camber_line(x):
        yc = np.zeros_like(x)
        dyc_dx = np.zeros_like(x)

        # Symmetric airfoil or invalid camber location for cambered formula
        if abs(m) < 1e-15 or abs(p) < 1e-15 or abs(1.0 - p) < 1e-15:
            return yc, dyc_dx

        idx1 = x < p
        idx2 = ~idx1

        yc[idx1] = m / p**2 * (
            2.0 * p * x[idx1] - x[idx1]**2
        )
        dyc_dx[idx1] = 2.0 * m / p**2 * (
            p - x[idx1]
        )

        yc[idx2] = m / (1.0 - p)**2 * (
            (1.0 - 2.0 * p)
            + 2.0 * p * x[idx2]
            - x[idx2]**2
        )
        dyc_dx[idx2] = 2.0 * m / (1.0 - p)**2 * (
            p - x[idx2]
        )

        return yc, dyc_dx

    # Upper surface
    yt_u = thickness_distribution(x_u_base)
    yc_u, dyc_dx_u = camber_line(x_u_base)
    theta_u = np.arctan(dyc_dx_u)

    x_u = x_u_base - yt_u * np.sin(theta_u)
    y_u = yc_u + yt_u * np.cos(theta_u)

    # Lower surface
    yt_l = thickness_distribution(x_l_base)
    yc_l, dyc_dx_l = camber_line(x_l_base)
    theta_l = np.arctan(dyc_dx_l)

    x_l = x_l_base + yt_l * np.sin(theta_l)
    y_l = yc_l - yt_l * np.cos(theta_l)

    # Concatenate:
    # upper is TE -> LE
    # lower is LE -> TE, but remove first point to avoid duplicate LE
    x = np.concatenate([x_u, x_l[1:]])
    y = np.concatenate([y_u, y_l[1:]])

    return np.vstack((x, y))

def define_cst_airfoil(params):
    """
    Build a 2 x N airfoil coordinate array from 12 CST parameters.

    Assumption:
        cst_params[0:6]  -> upper-surface CST coefficients
        cst_params[6:12] -> lower-surface CST coefficients

    Output ordering:
        TE upper -> LE -> TE lower

    Returns:
        pts : np.ndarray, shape (2, 2*n_points - 1)
            pts[0, :] = x coordinates
            pts[1, :] = y coordinates
    """
    cst_params = params['cst_params']
    n_points = params['N']
    te_thickness = params.get('te_thickness', 0.0)
    cosine_spacing = params.get('cosine_spacing', False)

    cst_params = np.asarray(cst_params, dtype=float).ravel()

    if cst_params.size != 12:
        raise ValueError("cst_params must contain exactly 12 coefficients.")

    au = cst_params[:6]
    al = cst_params[6:]

    def bernstein_basis(x, coeffs):
        n = len(coeffs) - 1
        y = np.zeros_like(x, dtype=float)
        for i, ai in enumerate(coeffs):
            y += ai * comb(n, i) * x**i * (1.0 - x)**(n - i)
        return y

    def cst_surface(x, coeffs, sign_te=1.0):
        # Standard airfoil CST class function: round LE, sharp TE
        N1, N2 = 0.5, 1.0
        C = x**N1 * (1.0 - x)**N2
        S = bernstein_basis(x, coeffs)
        return C * S + sign_te * 0.5 * te_thickness * x

    if cosine_spacing:
        beta = np.linspace(0.0, np.pi, n_points)
        x = 0.5 * (1.0 - np.cos(beta))  # LE -> TE
    else:
        x = np.linspace(0.0, 1.0, n_points)  # LE -> TE

    yu = cst_surface(x, au, sign_te=+1.0)
    yl = cst_surface(x, al, sign_te=-1.0)

    # Upper surface ordered TE -> LE
    xu = x[::-1]
    yu = yu[::-1]

    # Lower surface ordered LE -> TE, excluding repeated LE point
    xl = x[1:]
    yl = yl[1:]

    x_all = np.concatenate([xu, xl])
    y_all = np.concatenate([yu, yl])

    return np.vstack([x_all, y_all])

def define_airfoil_geometry(geometry_params):
    if geometry_params['airfoil_type'] == 'NACA':
        return define_naca_airfoil(geometry_params)
    elif geometry_params['airfoil_type'] == 'CST':
        return define_cst_airfoil(geometry_params)
    elif geometry_params['airfoil_type'] == 'RAE2822':
        return read_rae2822_airfoil(geometry_params)
    elif geometry_params['airfoil_type'] == '30P30N':
        return read_30p30n_airfoil()
    else:
        raise ValueError("Unsupported airfoil type")

# Splitting

def _unit(v, eps=1e-14):
    v = np.asarray(v, dtype=float)
    n = np.linalg.norm(v)
    if n < eps:
        return np.zeros_like(v)
    return v / n

def _surface_tangent(surface, idx):
    """
    Local tangent following the surface ordering.
    """
    n = surface.shape[1]

    if idx <= 0:
        t = surface[:, 1] - surface[:, 0]
    elif idx >= n - 1:
        t = surface[:, -1] - surface[:, -2]
    else:
        t = surface[:, idx + 1] - surface[:, idx - 1]

    return _unit(t)

def _closest_idx_by_x(surface, x_target):
    return int(np.argmin(np.abs(surface[0, :] - x_target)))

def _closest_idx_by_point(surface, point):
    point = np.asarray(point, dtype=float).reshape(2, 1)
    return int(np.argmin(np.linalg.norm(surface - point, axis=0)))

def _cubic_bezier(P0, P1, P2, P3, n=80):
    """
    Cubic Bezier curve from P0 to P3.
    Returns a 2 x n array.
    """
    u = np.linspace(0.0, 1.0, n)

    b0 = (1.0 - u)**3
    b1 = 3.0 * (1.0 - u)**2 * u
    b2 = 3.0 * (1.0 - u) * u**2
    b3 = u**3

    C = (
        b0[None, :] * P0[:, None]
        + b1[None, :] * P1[:, None]
        + b2[None, :] * P2[:, None]
        + b3[None, :] * P3[:, None]
    )

    return C

def _bezier_nose_top_le_bottom(
    P_top,
    P_le,
    P_bot,
    t_top,
    t_le,
    t_bot,
    n_each=80,
    alpha_top=0.35,
    alpha_le=0.25,
    alpha_bot=0.35,
):
    """
    Composite cubic Bezier nose:

        P_top -> P_le -> P_bot

    The first cubic enforces tangent continuity at P_top and P_le.
    The second cubic enforces tangent continuity at P_le and P_bot.

    Curve ordering:
        top cut -> new LE -> bottom cut
    """

    P_top = np.asarray(P_top, dtype=float)
    P_le  = np.asarray(P_le, dtype=float)
    P_bot = np.asarray(P_bot, dtype=float)

    t_top = _unit(t_top)
    t_le  = _unit(t_le)
    t_bot = _unit(t_bot)

    # Make sure tangents are consistent with the desired curve direction.
    # Desired direction: top -> LE -> bottom.
    if np.dot(t_top, P_le - P_top) < 0.0:
        t_top = -t_top

    if np.dot(t_le, P_bot - P_top) < 0.0:
        t_le = -t_le

    if np.dot(t_bot, P_bot - P_le) < 0.0:
        t_bot = -t_bot

    L_top = np.linalg.norm(P_le - P_top)
    L_bot = np.linalg.norm(P_bot - P_le)

    # First cubic: top cut -> new LE
    B0 = P_top
    B1 = P_top + alpha_top * L_top * t_top
    B2 = P_le  - alpha_le  * L_top * t_le
    B3 = P_le

    upper = _cubic_bezier(B0, B1, B2, B3, n=n_each)

    # Second cubic: new LE -> bottom cut
    C0 = P_le
    C1 = P_le  + alpha_le  * L_bot * t_le
    C2 = P_bot - alpha_bot * L_bot * t_bot
    C3 = P_bot

    lower = _cubic_bezier(C0, C1, C2, C3, n=n_each)

    # Avoid duplicating the LE point.
    nose = np.hstack([upper, lower[:, 1:]])

    return nose

def _split_airfoil_top_bot(airfoil):
    """
    Assumes ordering:
        upper: TE -> LE
        lower: LE -> TE
    """
    airfoil = np.asarray(airfoil, dtype=float)

    if airfoil.shape[0] != 2:
        raise ValueError("airfoil must have shape 2 x N")

    idx_le = int(np.argmin(airfoil[0, :]))

    airfoil_top = airfoil[:, :idx_le + 1]   # TE -> LE
    airfoil_bot = airfoil[:, idx_le:]       # LE -> TE

    return airfoil_top, airfoil_bot, idx_le

def _interp_surface_at_x(surface, x):
    """
    Interpolate point on a 2 x N surface at prescribed x.

    Works even if surface x is decreasing, as in upper TE -> LE.
    """
    xs = surface[0, :]
    ys = surface[1, :]

    order = np.argsort(xs)
    xs_s = xs[order]
    ys_s = ys[order]

    if x < xs_s[0] or x > xs_s[-1]:
        raise ValueError(f"x={x} outside surface x-range [{xs_s[0]}, {xs_s[-1]}].")

    y = np.interp(x, xs_s, ys_s)
    return np.array([x, y], dtype=float)

def _find_normal_cut_idx(surface, H, x_hinge, side):
    """
    Find point downstream of hinge whose normal line passes closest to H.

    Equivalent condition:
        H lies on the normal through P
    means:
        dot(H - P, tangent(P)) = 0

    Therefore we minimize:
        abs(dot(H - P, tangent(P)))

    Parameters
    ----------
    surface : 2 x N
        Upper or lower surface.

    H : ndarray, shape (2,)
        Hinge point.

    x_hinge : float
        Hinge x-location.

    side : {"upper", "lower"}
        Only used for diagnostics and error messages.
    """

    xs = surface[0, :]

    # Flap cut must be aft/downstream of the hinge.
    # With standard chord coordinates, aft means larger x.
    candidate_idx = np.where(xs >= x_hinge)[0]

    if candidate_idx.size < 3:
        raise ValueError(f"Not enough downstream candidate points on {side} surface.")

    best_idx = None
    best_value = np.inf

    for idx in candidate_idx:
        if idx <= 0 or idx >= surface.shape[1] - 1:
            continue

        P = surface[:, idx]
        t = _surface_tangent(surface, idx)

        # Distance-like residual to the normal-crossing condition.
        residual = abs(np.dot(H - P, t))

        # Optional normalization: makes it less biased by far points.
        dist = np.linalg.norm(H - P)
        if dist > 1e-14:
            residual /= dist

        if residual < best_value:
            best_value = residual
            best_idx = idx

    if best_idx is None:
        raise ValueError(f"Could not locate normal-based cut on {side} surface.")

    return int(best_idx), float(best_value)

def _circular_arc_centered_at_hinge(P_top, P_bot, H, n=80, force_equal_radius=True):
    """
    Circular arc from P_top to P_bot centered at H.

    If force_equal_radius=True, both endpoints are projected onto the
    average-radius circle centered at H. This gives a mathematically
    circular hinge cut.

    Returns
    -------
    arc : 2 x n ndarray
        Arc from upper cut to lower cut.

    R : float
        Arc radius.
    """

    P_top = np.asarray(P_top, dtype=float)
    P_bot = np.asarray(P_bot, dtype=float)
    H = np.asarray(H, dtype=float)

    v_top = P_top - H
    v_bot = P_bot - H

    R_top = np.linalg.norm(v_top)
    R_bot = np.linalg.norm(v_bot)

    if R_top < 1e-14 or R_bot < 1e-14:
        raise ValueError("Cut point too close to hinge center.")

    if force_equal_radius:
        R = 0.5 * (R_top + R_bot)

        P_top_arc = H + R * v_top / R_top
        P_bot_arc = H + R * v_bot / R_bot
    else:
        # Not a true circle if R_top != R_bot, but keeps exact endpoints.
        # Usually not recommended for hinge geometry.
        R = 0.5 * (R_top + R_bot)
        P_top_arc = P_top
        P_bot_arc = P_bot

    theta_top = np.arctan2(P_top_arc[1] - H[1], P_top_arc[0] - H[0])
    theta_bot = np.arctan2(P_bot_arc[1] - H[1], P_bot_arc[0] - H[0])

    # Use the opposite arc so the circular cut goes inside the main element.
    dtheta = theta_bot - theta_top

    if dtheta > 0.0:
        dtheta -= 2.0 * np.pi
    else:
        dtheta += 2.0 * np.pi

    theta = theta_top + np.linspace(0.0, 1.0, n) * dtheta

    arc = H[:, None] + R * np.vstack([np.cos(theta), np.sin(theta)])

    return arc, R

def _flap_naca_like_le(P_top, P_bot, t_top, t_bot, x_le, n=120,
                       alpha_cut=0.35, alpha_le=0.35):
    """
    Build a NACA-like rounded leading edge for the flap.

    Output ordering:
        upper cut -> flap LE -> lower cut

    The two cubic Bezier branches enforce:
        - tangent continuity at upper cut,
        - tangent continuity at lower cut,
        - common vertical tangent at the flap LE.

    Parameters
    ----------
    P_top : ndarray, shape (2,)
        Upper cut point.

    P_bot : ndarray, shape (2,)
        Lower cut point.

    t_top : ndarray, shape (2,)
        Tangent at upper cut.

    t_bot : ndarray, shape (2,)
        Tangent at lower cut.

    x_le : float
        x-location of flap leading edge. Must be upstream of P_bot[0].

    n : int
        Number of points per Bezier branch.

    alpha_cut, alpha_le : float
        Bezier handle strengths.
    """

    P_top = np.asarray(P_top, dtype=float)
    P_bot = np.asarray(P_bot, dtype=float)

    if x_le >= P_bot[0]:
        raise ValueError("Flap LE must be in front of the bottom cut point: x_le < P_bot[0].")

    # Put LE at mid-thickness between the two cut points.
    y_le = 0.5 * (P_top[1] + P_bot[1])
    P_le = np.array([x_le, y_le], dtype=float)

    t_top = _unit(t_top)
    t_bot = _unit(t_bot)

    # Desired curve direction:
    # upper cut -> flap LE -> lower cut
    if np.dot(t_top, P_le - P_top) < 0.0:
        t_top = -t_top

    if np.dot(t_bot, P_bot - P_le) < 0.0:
        t_bot = -t_bot

    # Vertical tangent at flap LE, NACA-like rounded nose.
    # Upper branch arrives downward into LE; lower branch leaves downward from LE.
    t_le = np.array([0.0, -1.0])

    L_top = np.linalg.norm(P_le - P_top)
    L_bot = np.linalg.norm(P_bot - P_le)

    # Upper branch: upper cut -> flap LE
    B0 = P_top
    B1 = P_top + alpha_cut * L_top * t_top
    B2 = P_le  - alpha_le  * L_top * t_le
    B3 = P_le

    upper_le = _cubic_bezier(B0, B1, B2, B3, n=n)

    # Lower branch: flap LE -> lower cut
    C0 = P_le
    C1 = P_le  + alpha_le  * L_bot * t_le
    C2 = P_bot - alpha_cut * L_bot * t_bot
    C3 = P_bot

    lower_le = _cubic_bezier(C0, C1, C2, C3, n=n)

    le_curve = np.hstack([
        upper_le,
        lower_le[:, 1:]
    ])

    return le_curve, P_le

def split_slat(airfoil, parameters):
    """
    Split a front slat from a 2 x N airfoil.

    Assumed ordering:
        upper surface: TE -> LE
        lower surface: LE -> TE

    The new main-element leading edge is rebuilt using one composite
    Bezier nose:

        top cut -> new LE -> bottom cut

    with tangent continuity at:
        - top cut,
        - new LE,
        - bottom cut.
    """

    airfoil = np.asarray(airfoil, dtype=float)

    if airfoil.shape[0] != 2:
        raise ValueError("airfoil must have shape 2 x N")

    n_total = airfoil.shape[1]
    mid = n_total // 2 + 2

    airfoil_top = airfoil[:, :mid]      # TE -> LE
    airfoil_bot = airfoil[:, mid:]      # LE -> TE

    # ------------------------------------------------------------
    # 1. Locate split points
    # ------------------------------------------------------------
    if "p_slat_top" in parameters:
        idx_top = _closest_idx_by_point(airfoil_top, parameters["p_slat_top"])
    else:
        idx_top = _closest_idx_by_x(airfoil_top, parameters["x_slat_top"])

    if "p_slat_bot" in parameters:
        idx_bot = _closest_idx_by_point(airfoil_bot, parameters["p_slat_bot"])
    else:
        idx_bot = _closest_idx_by_x(airfoil_bot, parameters["x_slat_bot"])

    P_top = airfoil_top[:, idx_top]
    P_bot = airfoil_bot[:, idx_bot]

    # ------------------------------------------------------------
    # 2. Original and new LE
    # ------------------------------------------------------------
    idx_le_global = int(np.argmin(airfoil[0, :]))
    P_le_old = airfoil[:, idx_le_global]

    if "p_new_le" in parameters:
        P_le_new = np.asarray(parameters["p_new_le"], dtype=float)

    elif "x_LE_main" in parameters:
        # x_LE_main is treated as an absolute x-location.
        P_le_new = np.array([parameters["x_LE_main"], P_le_old[1]], dtype=float)

    elif "d_le" in parameters:
        idx_top = np.argmin(np.abs(airfoil_top[0,:] - parameters["d_le"]))
        idx_bot = np.argmin(np.abs(airfoil_bot[0,:] - parameters["d_le"]))
        t_aprox = 0.5*(airfoil_top[1,idx_top] + airfoil_bot[1,idx_bot])
        P_le_new = P_le_old + np.asarray([parameters["d_le"],t_aprox], dtype=float)

    else:
        raise ValueError("Define 'p_new_le', 'x_LE_main', or 'd_le'.")

    if P_le_new[0] >= min(P_top[0], P_bot[0]):
        raise ValueError("The new LE must be upstream of both top and bottom cuts.")

    # ------------------------------------------------------------
    # 3. Tangents
    # ------------------------------------------------------------
    # Top tangent: use the two previous points from the upper surface.
    # Since upper is ordered TE -> LE, previous points are idx_top-2, idx_top-1.
    if idx_top < 2:
        raise ValueError("idx_top too close to the start of the upper surface.")

    t_top = airfoil_top[:, idx_top] - airfoil_top[:, idx_top - 2]
    t_top = _unit(t_top)
    theta = np.deg2rad(5) # Rotate a bit downwards for safety
    R = np.array([
            [np.cos(theta), -np.sin(theta)],
            [np.sin(theta),  np.cos(theta)],
        ])
    t_top = _unit(R @ t_top)

    # Bottom tangent: use the two following points from the lower surface.
    # Since lower is ordered LE -> TE, following points are idx_bot+1, idx_bot+2.
    if idx_bot > airfoil_bot.shape[1] - 3:
        raise ValueError("idx_bot too close to the end of the lower surface.")

    t_bot = airfoil_bot[:, idx_bot + 2] - airfoil_bot[:, idx_bot]
    t_bot = _unit(t_bot)
    theta = np.deg2rad(-5) # Rotate a bit downwards for safety
    R = np.array([
            [np.cos(theta), -np.sin(theta)],
            [np.sin(theta),  np.cos(theta)],
        ])
    t_bot = _unit(R @ t_bot)

    # LE tangent: inherit the original LE tangent.
    # This is approximately the direction from upper side to lower side.
    if idx_le_global < 1 or idx_le_global > airfoil.shape[1] - 2:
        raise ValueError("Original LE index too close to array boundary.")

    t_le = airfoil[:, idx_le_global + 1] - airfoil[:, idx_le_global - 1]
    t_le = _unit(t_le)

    # ------------------------------------------------------------
    # 4. Build the new Bezier nose
    # ------------------------------------------------------------
    n_cut = int(parameters.get("n_cut", 100))

    alpha_top = float(parameters.get("alpha_top", 0.35))
    alpha_le  = float(parameters.get("alpha_le",  0.25))
    alpha_bot = float(parameters.get("alpha_bot", 0.35))

    nose = _bezier_nose_top_le_bottom(
        P_top=P_top,
        P_le=P_le_new,
        P_bot=P_bot,
        t_top=t_top,
        t_le=t_le,
        t_bot=t_bot,
        n_each=n_cut,
        alpha_top=alpha_top,
        alpha_le=alpha_le,
        alpha_bot=alpha_bot,
    )

    # ------------------------------------------------------------
    # 5. Build slat and main element
    # ------------------------------------------------------------
    slat_upper = airfoil_top[:, idx_top:]        # top cut -> old LE
    slat_lower = airfoil_bot[:, :idx_bot + 1]    # old LE -> bottom cut
    slat = np.hstack([slat_upper, slat_lower])

    main_upper = airfoil_top[:, :idx_top + 1]    # TE -> top cut
    main_lower = airfoil_bot[:, idx_bot:]        # bottom cut -> TE

    main = np.hstack([
        main_upper,
        nose[:, 1:-1],       # avoid duplicating top and bottom cuts
        main_lower,
    ])

    # Optional: close the slat with the same new nose curve.
    if parameters.get("close_slat", True):
        slat = np.hstack([
            slat,
            np.flip(nose[:, 1:-1], axis=1),
        ])

    # Change the order for the mesher
    slat = np.flip(slat, axis=1)

    idx_low_point_slat = int(np.argmin(np.linalg.norm(slat - P_bot[:, None], axis=0)))

    info = {
        'idx_LE_slat': np.argmin(slat[0,:]),
        'idx_TE_slat': 0,
        'idx_low_point_slat': idx_low_point_slat,
        'idx_mid_point_back': np.argmin(slat[0,:idx_low_point_slat]),
    }

    return slat, main, info

def split_flap_round(main, airfoil, parameters):
    """
    Split a rear flap from an airfoil/main element using a circular
    hinge-like internal cut.

    Assumed ordering:
        upper surface: TE -> LE
        lower surface: LE -> TE

    Required
    --------
    parameters["x_flap_hinge"]

    Optional
    --------
    parameters["hinge_eta"] : float, default 0.5
        Position of hinge along local thickness:
            0.0 -> lower surface
            0.5 -> mid-thickness
            1.0 -> upper surface

    parameters["n_cut"] : int, default 80
        Number of points in the circular hinge cut.

    parameters["close_flap"] : bool, default True

    parameters["force_equal_radius"] : bool, default True
        If True, the internal cut is an exact circular arc centered at H.
        The arc endpoints may be slightly projected from the raw surface
        cut points if their distances to H are not identical.
    """

    airfoil = np.asarray(airfoil, dtype=float)

    if airfoil.shape[0] != 2:
        raise ValueError("airfoil must have shape 2 x N")

    x_hinge = float(parameters["x_flap_hinge"])
    hinge_eta = float(parameters.get("hinge_eta", 0.5))
    n_cut = int(parameters.get("n_cut", 50))
    close_flap = bool(parameters.get("close_flap", True))
    force_equal_radius = bool(parameters.get("force_equal_radius", True))

    if not (0.0 <= hinge_eta <= 1.0):
        raise ValueError("hinge_eta must be in [0, 1].")

    # ------------------------------------------------------------
    # 1. Split into upper/lower surfaces
    # ------------------------------------------------------------
    airfoil_top, airfoil_bot, idx_le = _split_airfoil_top_bot(airfoil)

    # ------------------------------------------------------------
    # 2. Hinge point on local thickness line
    # ------------------------------------------------------------
    P_top_h = _interp_surface_at_x(airfoil_top, x_hinge)
    P_bot_h = _interp_surface_at_x(airfoil_bot, x_hinge)

    # eta = 0 lower, eta = 1 upper
    H = (1.0 - hinge_eta) * P_bot_h + hinge_eta * P_top_h
    # Move it a bit backwards to ensure no lines cross
    H[0] += 0.02

    # ------------------------------------------------------------
    # 3. Locate upper/lower cutting points
    # ------------------------------------------------------------
    idx_top_cut, residual_top = _find_normal_cut_idx(
        airfoil_top,
        H=H,
        x_hinge=x_hinge,
        side="upper",
    )
    # For security take some points in front
    idx_top_cut += int(airfoil.shape[1]*1/400)

    idx_bot_cut, residual_bot = _find_normal_cut_idx(
        airfoil_bot,
        H=H,
        x_hinge=x_hinge,
        side="lower",
    )
    # For security take some points in front
    idx_bot_cut -= int(airfoil.shape[1]*1/400)

    P_top_cut = airfoil_top[:, idx_top_cut]
    P_bot_cut = airfoil_bot[:, idx_bot_cut]

    # ------------------------------------------------------------
    # 4. Circular hinge-like cut
    # ------------------------------------------------------------
    cut, R_hinge = _circular_arc_centered_at_hinge(
        P_top=P_top_cut,
        P_bot=P_bot_cut,
        H=H,
        n=n_cut,
        force_equal_radius=force_equal_radius,
    )

    # ------------------------------------------------------------
    # 5. Flap element
    # ------------------------------------------------------------
    flap_upper = airfoil_top[:, :idx_top_cut + 1]      # TE -> upper cut
    flap_lower = airfoil_bot[:, idx_bot_cut:]          # lower cut -> TE

    if close_flap:
        # Closed flap ordering:
        #     TE upper -> upper cut -> internal cut -> lower cut -> TE lower
        flap = np.hstack([
            flap_upper,
            cut[:, 1:-1],       # upper cut -> lower cut
            flap_lower,
        ])
    else:
        flap = np.hstack([
            flap_upper,
            flap_lower,
        ])

    # ------------------------------------------------------------
    # 6. Main element
    # ------------------------------------------------------------
    # Upper is TE -> LE.
    # The flap upper part is from TE to upper cut:
    #     airfoil_top[:, :idx_top_cut + 1]
    #
    # The main upper remaining part is from upper cut to LE:
    #     airfoil_top[:, idx_top_cut:]
    #
    # Lower is LE -> TE.
    # The main lower remaining part is from LE to lower cut:
    #     airfoil_bot[:, :idx_bot_cut + 1]
    #
    # The flap lower part is from lower cut to TE:
    #     airfoil_bot[:, idx_bot_cut:]
    idx_top_cut = np.argmin(np.sqrt(np.sum(np.power(main - P_top_cut.reshape((-1,1)),2),axis=0)))
    idx_bot_cut = np.argmin(np.sqrt(np.sum(np.power(main - P_bot_cut.reshape((-1,1)),2),axis=0)))+1

    # Main should preserve global ordering TE-like around the closed element.
    # For the main front element:
    #     upper cut -> LE -> lower cut -> internal cut back to upper cut
    main = np.hstack([
        main[:, idx_top_cut:idx_bot_cut],
        np.flip(cut[:, 1:-1], axis=1),  # lower cut -> upper cut
    ])

    # Rotate for mesher
    flap = np.flip(flap,axis=1)
    main = np.flip(main,axis=1)

    idx_bot_point = int(np.argmin(np.linalg.norm(main - P_bot_cut[:, None], axis=0)))

    info = {
        'idx_LE_flap': np.argmin(flap[0,:]),
        'idx_TE_flap': 0,
        'idx_LE_main': np.argmin(main[0,:]),
        'idx_TE_main': 0,
        'idx_bot_point': idx_bot_point,
        }

    return main, flap, info

def split_flap_square(main, airfoil, parameters):
    """
    Split a rear flap using a vertical/square cut in the main element and
    a newly rebuilt NACA-like flap leading edge.

    Required parameters
    -------------------
    parameters["x_cut"]
        x-location of the vertical cut.

    parameters["x_main_right"]
        right-most x-coordinate retained by the new main element.
        This defines the vertical rear face of the main element.

    Optional parameters
    -------------------
    parameters["x_flap_le"]
        x-coordinate of the new flap leading edge.
        If omitted, it is placed using flap_le_offset.

    parameters["flap_le_offset"]
        Offset behind x_main_right used to place the flap LE:
            x_flap_le = x_main_right + flap_le_offset
        Default: 0.01

    parameters["n_le"]
        Number of points per Bezier branch for the flap LE.

    parameters["n_vertical"]
        Number of points for the main vertical rear face.

    parameters["alpha_cut"]
    parameters["alpha_le"]
        Bezier handle strengths.

    Returns
    -------
    main : ndarray, shape (2, Nm)
        Main element closed with a vertical rear face.

    flap : ndarray, shape (2, Nf)
        Flap element with a NACA-like leading edge.

    info : dict
        Geometric construction information.
    """

    airfoil = np.asarray(airfoil, dtype=float)

    if airfoil.shape[0] != 2:
        raise ValueError("airfoil must have shape 2 x N")

    x_cut = float(parameters["x_flap_bot"])
    x_main_right = float(parameters["x_flap_top"])

    n_le = int(parameters.get("n_le", 50))
    n_vertical = int(parameters.get("n_vertical", 10))

    alpha_cut = float(parameters.get("alpha_cut", 0.35))
    alpha_le = float(parameters.get("alpha_le", 0.35))

    if x_main_right <= x_cut:
        raise ValueError("x_main_right must be larger than x_cut.")

    top, bot, idx_le = _split_airfoil_top_bot(airfoil)

    # ------------------------------------------------------------
    # 1. Cut points at x_cut for the flap
    # ------------------------------------------------------------
    P_top_cut = _interp_surface_at_x(top, x_main_right)
    P_bot_cut = _interp_surface_at_x(bot, x_cut)

    idx_top_cut = _closest_idx_by_x(top, x_main_right)
    idx_bot_cut = _closest_idx_by_x(bot, x_cut)

    # Tangents at cut points inherited from original airfoil.
    t_top_cut = _surface_tangent(top, idx_top_cut)
    t_bot_cut = _surface_tangent(bot, idx_bot_cut)

    # ------------------------------------------------------------
    # 3. Main element: keep original airfoil from LE to x_main_right,
    #    and close with a vertical rear face.
    # ------------------------------------------------------------
    idx_top_cut_main = np.argmin(np.sqrt(np.sum(np.power(main - P_top_cut.reshape((-1,1)),2),axis=0)))
    idx_bot_cut_main = np.argmin(np.sqrt(np.sum(np.power(main - P_bot_cut.reshape((-1,1)),2),axis=0)))+1

    s = np.linspace(P_bot_cut[1], P_top_cut[1], n_vertical)
    vertical_face = np.vstack((np.ones((1,s.size))*P_bot_cut[0], s))
    s = np.linspace(P_bot_cut[0], P_top_cut[0], n_vertical)
    horizontal_face = np.vstack((s,np.ones((1,s.size))*P_top_cut[1]))

    main_cut = main[:, idx_top_cut_main:idx_bot_cut_main-1]
    idx_top_straight = main_cut.shape[1] + n_vertical - 1
    idx_bot_straight = main_cut.shape[1]

    main = np.hstack([
        main_cut,
        vertical_face[:, :-1],         # bottom rear -> top rear
        horizontal_face[:, :-1],         # bottom rear -> top rear
    ])

    # ------------------------------------------------------------
    # 4. Flap trailing part from original airfoil
    # ------------------------------------------------------------
    # Upper is TE -> LE. For flap, keep TE -> upper cut.
    flap_upper = top[:, :idx_top_cut + 1]

    # Lower is LE -> TE. For flap, keep lower cut -> TE.
    flap_lower = bot[:, idx_bot_cut:]

    # ------------------------------------------------------------
    # 5. Define flap leading edge in front of bottom cut point
    # ------------------------------------------------------------
    if "x_flap_le" in parameters:
        x_flap_le = float(parameters["x_flap_le"])
    else:
        flap_le_offset = float(parameters.get("flap_le_offset", 0.01))
        x_flap_le = x_main_right + flap_le_offset

    if x_flap_le >= P_bot_cut[0]:
        raise ValueError(
            "Invalid flap LE. Need x_flap_le < x-coordinate of bottom cut."
        )

    le_curve, P_flap_le = _flap_naca_like_le(
        P_top=P_top_cut,
        P_bot=P_bot_cut,
        t_top=t_top_cut,
        t_bot=t_bot_cut,
        x_le=x_flap_le,
        n=n_le,
        alpha_cut=alpha_cut,
        alpha_le=alpha_le,
    )

    # ------------------------------------------------------------
    # 6. Assemble flap
    # ------------------------------------------------------------
    # Ordering:
    #   TE upper -> upper cut -> flap LE -> lower cut -> TE lower
    flap = np.hstack([
        flap_upper,
        le_curve[:, 1:-1],
        flap_lower,
    ])
    
    # Rotate for mesher
    flap = np.flip(flap,axis=1)
    main = np.flip(main,axis=1)

    idx_bot_straight = int(np.argmin(np.linalg.norm(main - P_bot_cut[:, None], axis=0)))
    idx_top_straight = int(np.argmin(np.linalg.norm(main - horizontal_face[:, 0].reshape((-1,1)), axis=0)))

    info = {
        'idx_LE_flap': np.argmin(flap[0,:]),
        'idx_TE_flap': 0,
        'idx_LE_main': np.argmin(main[0,:]),
        'idx_TE_main': 0,
        'idx_top_straight_main': idx_top_straight,
        'idx_bot_straight_main': idx_bot_straight,
        }

    return main, flap, info

def split_airfoil(airfoil, splitting_params):
    if splitting_params['scenario'] == 'slat':
        slat, main, info = split_slat(airfoil, splitting_params)
        main = np.flip(main,axis=1)
        info['idx_LE_main'] = np.argmin(main[0,:])
        info['idx_TE_main'] = 0
        return slat, main, info
    elif splitting_params['scenario'] == 'flap':
        if splitting_params['flap_type']=='round':    
            main, flap, info = split_flap_round(airfoil, airfoil, splitting_params)
        elif splitting_params['flap_type']=='square':   
            main, flap, info = split_flap_square(airfoil, airfoil, splitting_params)
        return main, flap, info
    else:
        slat, main, info_slat = split_slat(airfoil, splitting_params)
        if splitting_params['flap_type']=='round': 
            main, flap, info_flap = split_flap_round(main, airfoil, splitting_params)
        elif splitting_params['flap_type']=='square':   
            main, flap, info_flap = split_flap_square(main, airfoil, splitting_params)
        return slat, main, flap, info_slat | info_flap

def define_split_and_permute_airfoil(geometry_parameters, splitting_parameters, permutation_parameters = None):
    airfoil = define_airfoil_geometry(geometry_parameters)

    split_out = split_airfoil(airfoil, splitting_parameters)
    if splitting_parameters['scenario'] == 'slat':
        slat, main, split_info = split_out
        flap = None
    elif splitting_parameters['scenario'] == 'flap':
        main, flap, split_info = split_out
        slat = None
    elif splitting_parameters['scenario'] == 'slat-flap':
        slat, main, flap, split_info = split_out

    if permutation_parameters is not None:
        permute_out = permute_3_piece_airfoil(slat=slat,main=main, flap=flap,splitting_parameters=splitting_parameters,
                                            split_info=split_info,permutation_params=permutation_parameters)
        if splitting_parameters['scenario'] == 'slat':
            slat, main = permute_out
        elif splitting_parameters['scenario'] == 'flap':
            main, flap = permute_out
        elif splitting_parameters['scenario'] == 'slat-flap':
            slat, main, flap = permute_out
    
    if splitting_parameters['scenario'] == 'slat':
        return slat, main
    elif splitting_parameters['scenario'] == 'flap':
        return main, flap
    elif splitting_parameters['scenario'] == 'slat-flap':
        return slat,main,flap 