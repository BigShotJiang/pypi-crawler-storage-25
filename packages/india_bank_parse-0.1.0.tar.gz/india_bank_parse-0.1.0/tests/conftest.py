"""Test fixtures and shared configuration."""

import pytest
