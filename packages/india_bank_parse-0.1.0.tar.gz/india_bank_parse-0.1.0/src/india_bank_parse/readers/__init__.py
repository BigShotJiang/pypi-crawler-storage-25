"""File readers for PDF, Excel, and CSV inputs."""

from india_bank_parse.readers.pdf_reader import read_pdf

__all__ = ["read_pdf"]
