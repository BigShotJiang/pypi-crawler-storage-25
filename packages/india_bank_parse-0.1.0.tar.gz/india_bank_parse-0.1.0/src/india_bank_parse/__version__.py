"""Version information for india-bank-parse."""

__version__ = "0.1.0"
