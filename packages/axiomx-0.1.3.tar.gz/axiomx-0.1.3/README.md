# 🔢 AxiomX

**AxiomX** is a lightweight, pure-Python mathematical library built from
first principles --- designed for accuracy, learning, and mathematical
exploration.

------------------------------------------------------------------------

## 📢 Community

Join Discord for updates and feature requests. Join [here](https://discord.gg/yhN5eYwT).

------------------------------------------------------------------------

## 🚀 Features

### 📐 Core Mathematics (AxiomX.constants)

-   Constants (π, e, φ, √2, γ, ...)
-   Custom implementations

### 📈 Exponential & Logarithmic (AxiomX.exp)

-   exp(x)
-   ln(x)
-   log10(x)
-   log2(x)
-   log(arg, base)

### 📐 Trigonometry (AxiomX.trig)

-   sin, cos, tan, cot, sec, cosec
-   inverse functions

### 🔢 Hyperbolic Functions (AxiomX.hyperbolic)

-   sinh, cosh, tanh, coth

### 🧮 General Functions (AxiomX.functions)

-   absolute(x)
-   sqrt(x)
-   gamma(x)
-   cbrt(x)
-   zeta(n) and beta(n)
-   bc(n, k) - **NEW**
-   perm(n, K) - **NEW**
-   pascal(row) - **NEW**

### ∫ Calculus

-   Numerical integration
-   summation
-   convergence analysis
-   limit evaluation

### 🧱 Matrix Engine

-   Matrix creation
-   A\[i, j\] access
-   Addition, subtraction, multiplication by using actual mathematical operators.
-   Transpose
-   Determinant
-   Inverse
-   Division (via inverse) by using / operator
-   Rank of a Matrix by Gaussian elimination (**NEW**)

If you want to create a zero matrix or identity of any order, you can do it this way:

```
from AxiomX.matrix import Matrix

a = Matrix(x,y) # you can put your values in place of x and y.
a.zero() # for zero matrix
a.identity() # for identity matrix.
```

If you want to create a matrix, from a list, you can try it this way:

```
from AxiomX.matrix import Matrix

a = Matrix.from_list([]) # enter your matrix in it.
```
------------------------------------------------------------------------

## 📈 GRAPH ENGINE - **NEW** (included in AxiomX.graph)

AxiomX has introduced a killer feature - graphing. Just like how `matplotlib` is for numpy, AxiomX has introduced a graph module. It has only one function:

- plot(functions, start, end)

The functions argument can a function or list of functions. It also contains a scale and you can provide a starting and ending limit. We will add zooming later.

------------------------------------------------------------------------

## 📦 Installation

`pip install axiomx`

------------------------------------------------------------------------

## ▶️ Usage
```
from AxiomX.matrix import Matrix

A = Matrix.from_list([1, 2], [3, 4]])
print(A.det())
```

------------------------------------------------------------------------

## 🧠 Philosophy

Accuracy \> Speed

------------------------------------------------------------------------

## 🌐 Website

https://axiomxpy.wordpress.com

------------------------------------------------------------------------

## 🛣️ Roadmap

-   Advanced linear algebra
-   Series & constants

------------------------------------------------------------------------

## 📜 License

MIT License
