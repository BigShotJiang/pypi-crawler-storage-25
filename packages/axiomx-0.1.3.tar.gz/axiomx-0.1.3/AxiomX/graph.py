import turtle

def plot(funcs, start, end, step=0.1, scale=20, limit=1000):
    if not isinstance(funcs, list):
        funcs = [funcs]
    screen = turtle.Screen()
    screen.title("AxiomX Graph")

    t = turtle.Turtle()
    t.speed(0)
    t.hideturtle()

# =========================
# AXES + NUMBER LINES
# =========================

    # Axes
    t.penup()
    t.goto(-400, 0)
    t.pendown()
    t.goto(400, 0)

    t.penup()
    t.goto(0, -300)
    t.pendown()
    t.goto(0, 300)

    # ----- X-axis ticks -----
    # ----- X-axis ticks (with proper negative handling) -----

    tick_step = max(1, int((end - start) / 10))

    x_tick = int(start // tick_step) * tick_step

    while x_tick <= end:
        sx = x_tick * scale

        # Tick
        t.penup()
        t.goto(sx, -5)
        t.pendown()
        t.goto(sx, 5)

        # Label
        t.penup()
        t.goto(sx, -20)

        label = "0" if abs(x_tick) < 1e-9 else str(x_tick)
        t.write(label, align="center", font=("Arial", 8, "normal"))

        x_tick += tick_step

    # ----- Y-axis ticks -----
    # Estimate visible y-range based on screen height
    y_range = 300 / scale
    y_tick_step = max(1, int((2 * y_range) / 10))

    y_tick = int(-y_range)
    while y_tick <= y_range:
        sy = y_tick * scale

        # Skip origin label overlap (optional)
        if y_tick == 0:
            y_tick += y_tick_step
            continue

        # Tick
        t.penup()
        t.goto(-5, sy)
        t.pendown()
        t.goto(5, sy)

        # Label
        t.penup()
        t.goto(-25, sy - 5)
        t.write(f"{y_tick}", align="right", font=("Arial", 8, "normal"))

        y_tick += y_tick_step
    colors = ["red", "blue", "green", "purple"]

    for i, f in enumerate(funcs):
        t.color(colors[i % len(colors)])
        t.penup()

        x = start
        drawing = False

        while x <= end:
            try:
                y = f(x)

                if y is None or abs(y) > limit:
                    raise ValueError

                sx = x * scale
                sy = y * scale

                if not drawing:
                    t.penup()
                    t.goto(sx, sy)
                    t.pendown()
                    drawing = True
                else:
                    t.goto(sx, sy)

            except turtle.Terminator:
                return
            except:
                t.penup()
                drawing = False

            x += step