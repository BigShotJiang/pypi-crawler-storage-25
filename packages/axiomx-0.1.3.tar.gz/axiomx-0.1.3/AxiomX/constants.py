from AxiomX.calculus import *
from AxiomX.functions import *

pi = 3.141592653589793
e = 2.718281828459045
tau = 2*pi
lemniscate = 2.622057554292119
gauss = lemniscate / pi
euler_mascheroni = 0.577215664901533
sqrt_2 = 2**0.5
sqrt_3 = 3**0.5
sqrt_5 = 5**0.5
golden_ratio = (1 + sqrt_5) / 2
silver_ratio = 1 + sqrt_2
gelfond = e**pi
gelfond_schneider = 2**sqrt_2
infinity = float("inf")

def metallic_ratio(n):
    return (n + (n**2 + 4)**0.5) / 2
    
def harmonic_number(n):
    return summation(1, n, lambda x:1/x)
    
def bernoulli(n):
    B = [0] * (n + 1)
    B[0] = 1

    for m in range(1, n + 1):
        B[m] = 0
        for k in range(m):
            B[m] -= (bc(m + 1, k) * B[k])
        B[m] /= (m + 1)

    return B[n]