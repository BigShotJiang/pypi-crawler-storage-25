import time

print("AxiomX loading...")
time.sleep(3)
print("AxiomX is ready to use!")

import AxiomX.constants
import AxiomX.calculus
import AxiomX.functions
import AxiomX.exp
import AxiomX.trig
import AxiomX.hyperbolic

version = '0.1.0'
