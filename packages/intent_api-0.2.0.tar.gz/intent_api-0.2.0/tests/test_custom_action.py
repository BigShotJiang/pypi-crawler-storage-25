"""Tests for the @custom_action decorator system (Phase 1)."""

from __future__ import annotations

import pytest
from fastapi import HTTPException
from pydantic import BaseModel

from intent_api import IntentService, custom_action
from intent_api.router import IntentRouter


class _ArchivePayload(BaseModel):
    reason: str


class TodoService(IntentService):
    """Todo service."""

    @custom_action(schema=_ArchivePayload)
    async def archive(self, *, db, user, context, id, payload):
        return {"archived": id, "reason": (payload or {}).get("reason")}

    @custom_action(name="export_csv")
    async def export(self, *, db, user, context, id, payload):
        return {"exported": True}


class ChildTodoService(TodoService):
    @custom_action()
    async def restore(self, *, db, user, context, id, payload):
        return {"restored": id}


class LegacyService(IntentService):
    """Service using the manual custom_action override (legacy pattern)."""

    async def custom_action(
        self, *, command, db, user, context=None, id=None, payload=None
    ):
        if command == "foo":
            return "legacy_foo"
        raise HTTPException(status_code=400, detail=f"Unknown: {command}")


# ── Decorator collection ─────────────────────────────────────────────────────


def test_decorator_collects_commands():
    assert set(TodoService._registered_commands.keys()) == {"archive", "export_csv"}


def test_decorator_stores_schema():
    assert TodoService._registered_commands["archive"]["schema"] is _ArchivePayload
    assert TodoService._registered_commands["export_csv"]["schema"] is None


def test_decorator_name_override():
    assert "export_csv" in TodoService._registered_commands
    assert "export" not in TodoService._registered_commands
    assert TodoService._registered_commands["export_csv"]["handler"] == "export"


# ── Auto-dispatch ────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_auto_dispatch_routes_to_handler():
    svc = TodoService()
    result = await svc.custom_action(
        command="archive",
        db=None,
        user=None,
        id=42,
        payload={"reason": "test"},
    )
    assert result == {"archived": 42, "reason": "test"}


@pytest.mark.asyncio
async def test_auto_dispatch_named_command():
    svc = TodoService()
    result = await svc.custom_action(command="export_csv", db=None, user=None)
    assert result == {"exported": True}


@pytest.mark.asyncio
async def test_unknown_command_raises_400():
    svc = TodoService()
    with pytest.raises(HTTPException) as exc:
        await svc.custom_action(command="nonexistent", db=None, user=None)
    assert exc.value.status_code == 400


# ── Mixed-mode error (Boundary B18) ──────────────────────────────────────────


def test_mixed_mode_raises_at_class_definition():
    with pytest.raises(TypeError, match="cannot use both"):

        class BadService(IntentService):  # noqa: N801
            @custom_action()
            async def foo(self, *, db, user, context, id, payload):
                pass

            async def custom_action(self, *, command, **kw):
                pass


# ── Inheritance (Boundary B19) ───────────────────────────────────────────────


def test_child_inherits_parent_commands():
    assert "archive" in ChildTodoService._registered_commands
    assert "export_csv" in ChildTodoService._registered_commands
    assert "restore" in ChildTodoService._registered_commands


def test_parent_unaffected_by_child():
    assert "restore" not in TodoService._registered_commands


def test_child_overrides_parent_command_of_same_name():
    class ChildOverride(TodoService):
        @custom_action()
        async def archive(self, *, db, user, context, id, payload):
            return "overridden"

    assert (
        ChildOverride._registered_commands["archive"]["handler"] == "archive"
    )


# ── Backward compatibility (Boundary B17) ────────────────────────────────────


@pytest.mark.asyncio
async def test_manual_override_still_works():
    svc = LegacyService()
    result = await svc.custom_action(command="foo", db=None, user=None)
    assert result == "legacy_foo"


@pytest.mark.asyncio
async def test_manual_override_unknown_command_raises():
    svc = LegacyService()
    with pytest.raises(HTTPException):
        await svc.custom_action(command="nope", db=None, user=None)


# ── Registry introspection ───────────────────────────────────────────────────


def test_build_registry_map_returns_per_command_lines():
    router = IntentRouter()
    router.register("Todo", TodoService())
    registry_map = router._build_registry_map()
    assert "Todo" in registry_map
    methods = registry_map["Todo"]["methods"]
    assert "archive" in methods
    assert "export_csv" in methods
    assert isinstance(methods["archive"]["line"], int)
    assert methods["archive"]["line"] > 0


def test_build_registry_map_for_legacy_service_returns_custom():
    router = IntentRouter()
    router.register("Legacy", LegacyService())
    registry_map = router._build_registry_map()
    assert "custom" in registry_map["Legacy"]["methods"]
