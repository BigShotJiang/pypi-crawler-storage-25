"""Tests for MCP schema generation (Phase 2)."""

from __future__ import annotations

import pytest
from jsonschema import Draft202012Validator

from intent_api import IntentService, custom_action
from intent_api.mcp_schemas import (
    JSON_SCHEMA_DIALECT,
    build_full_schema,
    build_intent_tool_input_schema,
    build_model_schema,
    build_models_list,
)
from intent_api.registry import ServiceRegistry


class BrandService(IntentService):
    """Brand management."""

    async def list(self, *, db, user, context, skip=0, limit=10):
        return {"items": []}


class BlogPostService(IntentService):
    """Blog posts."""

    async def create(self, *, db, user, context, payload=None):
        return {"success": True}

    @custom_action()
    async def generate(self, *, db, user, context, id, payload):
        return {"generated": True}


class HiddenService(IntentService):
    async def list(self, *, db, user, context, skip=0, limit=10):
        return {"items": []}


@pytest.fixture
def registry() -> ServiceRegistry:
    reg = ServiceRegistry()
    reg.register("Brand", BrandService())
    reg.register("BlogPost", BlogPostService())
    reg.register("Hidden", HiddenService(), expose_mcp=False)
    return reg


# ── expose_mcp filtering ─────────────────────────────────────────────────────


def test_models_list_excludes_hidden(registry):
    models = build_models_list(registry)["models"]
    names = [m["model"] for m in models]
    assert "Brand" in names
    assert "BlogPost" in names
    assert "Hidden" not in names


def test_full_schema_excludes_hidden(registry):
    schema = build_full_schema(registry)
    assert "Hidden" not in schema["services"]
    assert "Brand" in schema["services"]


def test_model_schema_for_hidden_returns_none(registry):
    assert build_model_schema(registry, "Hidden") is None


def test_model_schema_for_unregistered_returns_none(registry):
    assert build_model_schema(registry, "Nope") is None


# ── Service introspection ────────────────────────────────────────────────────


def test_blogpost_schema_has_create_action(registry):
    schema = build_model_schema(registry, "BlogPost")
    actions = [a["name"] for a in schema["actions"]]
    assert actions == ["create"]


def test_blogpost_schema_has_generate_command(registry):
    schema = build_model_schema(registry, "BlogPost")
    commands = [c["name"] for c in schema["commands"]]
    assert commands == ["generate"]


def test_brand_schema_only_has_list(registry):
    schema = build_model_schema(registry, "Brand")
    actions = [a["name"] for a in schema["actions"]]
    assert actions == ["list"]
    assert schema["commands"] == []


# ── JSON Schema 2020-12 compliance (Boundary B16) ───────────────────────────


def test_intent_tool_input_schema_is_valid_2020_12():
    schema = build_intent_tool_input_schema()
    Draft202012Validator.check_schema(schema)
    assert schema["$schema"] == JSON_SCHEMA_DIALECT


def test_intent_tool_input_schema_omits_context():
    schema = build_intent_tool_input_schema()
    assert "context" not in schema["properties"]


def test_intent_tool_input_schema_required_fields():
    schema = build_intent_tool_input_schema()
    assert set(schema["required"]) == {"model", "action"}


def test_intent_tool_input_schema_action_enum():
    schema = build_intent_tool_input_schema()
    actions = schema["properties"]["action"]["enum"]
    assert set(actions) == {"create", "read", "update", "delete", "list", "custom"}


def test_full_schema_has_dialect(registry):
    assert build_full_schema(registry)["$schema"] == JSON_SCHEMA_DIALECT


def test_models_list_has_dialect(registry):
    assert build_models_list(registry)["$schema"] == JSON_SCHEMA_DIALECT


def test_register_default_expose_mcp_is_true():
    reg = ServiceRegistry()
    reg.register("Foo", BrandService())
    assert reg.is_mcp_exposed("Foo")
    assert reg.mcp_models == ["Foo"]
