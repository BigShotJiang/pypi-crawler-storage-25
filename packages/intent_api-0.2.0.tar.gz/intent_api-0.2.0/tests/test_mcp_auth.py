"""Tests for MCP auth helpers (Phase 4)."""

from __future__ import annotations

import pytest
from fastapi import FastAPI, HTTPException
from starlette.testclient import TestClient

from intent_api.mcp_auth import (
    bearer_token_auth,
    build_protected_resource_metadata,
    build_well_known_router,
)


# ── RFC 9728 metadata ────────────────────────────────────────────────────────


def test_protected_resource_metadata_basic():
    doc = build_protected_resource_metadata(
        resource_url="https://api.example.com/mcp",
        authorization_servers=["https://example.clerk.accounts.dev"],
    )
    assert doc["resource"] == "https://api.example.com/mcp"
    assert doc["authorization_servers"] == [
        "https://example.clerk.accounts.dev"
    ]
    assert doc["bearer_methods_supported"] == ["header"]


def test_protected_resource_metadata_with_scopes():
    doc = build_protected_resource_metadata(
        resource_url="https://api.example.com/mcp",
        authorization_servers=["https://x"],
        scopes_supported=["read", "write"],
        resource_name="My API",
    )
    assert doc["scopes_supported"] == ["read", "write"]
    assert doc["resource_name"] == "My API"


def test_well_known_router_returns_metadata():
    app = FastAPI()
    app.include_router(
        build_well_known_router(
            resource_url="https://api.example.com/mcp",
            authorization_server="https://example.clerk.accounts.dev",
        )
    )
    with TestClient(app) as client:
        r = client.get("/.well-known/oauth-protected-resource")
        assert r.status_code == 200
        body = r.json()
        assert body["resource"] == "https://api.example.com/mcp"
        assert body["authorization_servers"] == [
            "https://example.clerk.accounts.dev"
        ]


# ── bearer_token_auth ────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_bearer_token_auth_resolves_user():
    def verify(token):
        return {"sub": "u1"} if token == "good" else (_ for _ in ()).throw(
            ValueError("bad")
        )

    async def resolve(decoded, db):
        return {"id": decoded["sub"]}

    get_user = bearer_token_auth(verify_fn=verify, resolve_user=resolve)

    class Creds:
        credentials = "good"

    user = await get_user(credentials=Creds(), context=None, db=None)
    assert user == {"id": "u1"}


@pytest.mark.asyncio
async def test_bearer_token_auth_invalid_token_raises_401():
    def verify(token):
        raise ValueError("bad")

    async def resolve(decoded, db):
        return {"id": "x"}

    get_user = bearer_token_auth(verify_fn=verify, resolve_user=resolve)

    class Creds:
        credentials = "bad"

    with pytest.raises(HTTPException) as exc:
        await get_user(credentials=Creds(), context=None, db=None)
    assert exc.value.status_code == 401


@pytest.mark.asyncio
async def test_bearer_token_auth_missing_token_raises_401():
    def verify(token):
        return {"sub": "u1"}

    async def resolve(decoded, db):
        return {"id": "u1"}

    get_user = bearer_token_auth(verify_fn=verify, resolve_user=resolve)

    class Creds:
        credentials = ""

    with pytest.raises(HTTPException) as exc:
        await get_user(credentials=Creds(), context=None, db=None)
    assert exc.value.status_code == 401


@pytest.mark.asyncio
async def test_bearer_token_auth_resolver_returning_none_raises_401():
    def verify(token):
        return {"sub": "ghost"}

    async def resolve(decoded, db):
        return None

    get_user = bearer_token_auth(verify_fn=verify, resolve_user=resolve)

    class Creds:
        credentials = "good"

    with pytest.raises(HTTPException) as exc:
        await get_user(credentials=Creds(), context=None, db=None)
    assert exc.value.status_code == 401


# ── clerk_mcp_auth lazy-import ───────────────────────────────────────────────


def test_clerk_mcp_auth_raises_clear_error_without_sdk(monkeypatch):
    """Boundary B5: graceful degradation if clerk-backend-api not installed."""
    import builtins
    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "clerk_backend_api" or name.startswith("clerk_backend_api."):
            raise ImportError("No module named 'clerk_backend_api'")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    import importlib, intent_api.mcp_auth as mcp_auth_mod
    importlib.reload(mcp_auth_mod)

    with pytest.raises(ImportError, match="clerk-backend-api"):
        mcp_auth_mod.clerk_mcp_auth(
            secret_key="sk_test_x",
            authorization_server="https://x.clerk.accounts.dev",
        )

    importlib.reload(mcp_auth_mod)
