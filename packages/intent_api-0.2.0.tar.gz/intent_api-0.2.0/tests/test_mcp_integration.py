"""End-to-end integration test against a real fastmcp client (Phase 3 + 4 + 5)."""

from __future__ import annotations

import asyncio
import json
import socket
import time
from threading import Thread

import httpx
import pytest
import uvicorn
from fastapi import FastAPI

from intent_api import IntentRouter, IntentService, custom_action


def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class BrandService(IntentService):
    """Brand service."""

    async def list(self, *, db, user, context, skip=0, limit=10):
        return {"items": [{"id": "1", "name": "Acme"}], "total": 1, "user_id": user["id"]}


class BlogPostService(IntentService):
    """Blog posts."""

    @custom_action()
    async def generate(self, *, db, user, context, id, payload):
        return {"generated": True, "id": id, "user_id": user["id"]}


class HiddenService(IntentService):
    async def list(self, *, db, user, context, skip=0, limit=10):
        return {"items": []}


@pytest.fixture(scope="module")
def server():
    port = _free_port()

    router = IntentRouter()
    router.register("Brand", BrandService())
    router.register("BlogPost", BlogPostService())
    router.register("Hidden", HiddenService(), expose_mcp=False)

    async def get_user(*, credentials, context, db):
        if credentials.credentials == "good-token":
            return {"id": "u1"}
        from fastapi import HTTPException
        raise HTTPException(status_code=401, detail="bad token")

    db_calls = {"opens": 0, "closes": 0}

    def get_db():
        db_calls["opens"] += 1
        try:
            yield None
        finally:
            db_calls["closes"] += 1

    mcp_app = router.build_mcp(
        get_user=get_user,
        get_db=get_db,
        resource_metadata_url=(
            f"http://127.0.0.1:{port}/.well-known/oauth-protected-resource"
        ),
    )
    app = FastAPI(lifespan=mcp_app.lifespan)
    app.mount("/mcp", mcp_app)
    app.include_router(
        router.build_mcp_well_known(
            resource_url=f"http://127.0.0.1:{port}/mcp",
            authorization_server="https://example.clerk.accounts.dev",
        )
    )

    server_config = uvicorn.Config(
        app, host="127.0.0.1", port=port, log_level="warning"
    )
    s = uvicorn.Server(server_config)

    def serve():
        asyncio.new_event_loop().run_until_complete(s.serve())

    t = Thread(target=serve, daemon=True)
    t.start()

    deadline = time.time() + 5
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                break
        except OSError:
            time.sleep(0.1)
    else:
        raise RuntimeError("Server never came up")

    yield {"port": port, "db_calls": db_calls}

    s.should_exit = True


@pytest.mark.asyncio
async def test_well_known_endpoint(server):
    async with httpx.AsyncClient() as hx:
        r = await hx.get(
            f"http://127.0.0.1:{server['port']}/.well-known/oauth-protected-resource"
        )
    assert r.status_code == 200
    body = r.json()
    assert body["resource"] == f"http://127.0.0.1:{server['port']}/mcp"
    assert body["authorization_servers"] == [
        "https://example.clerk.accounts.dev"
    ]


@pytest.mark.asyncio
async def test_unauthorized_returns_401_with_metadata_header(server):
    async with httpx.AsyncClient() as hx:
        r = await hx.post(
            f"http://127.0.0.1:{server['port']}/mcp/",
            headers={
                "Accept": "application/json,text/event-stream",
                "Content-Type": "application/json",
            },
            json={"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}},
        )
    assert r.status_code == 401
    www = r.headers.get("www-authenticate", "")
    assert www.startswith("Bearer ")
    assert "resource_metadata" in www


@pytest.mark.asyncio
async def test_full_flow_with_real_client(server):
    from fastmcp import Client
    from fastmcp.client.transports import StreamableHttpTransport

    transport = StreamableHttpTransport(
        f"http://127.0.0.1:{server['port']}/mcp/", auth="good-token"
    )

    async with Client(transport) as client:
        tools = await client.list_tools()
        assert [t.name for t in tools] == ["intent_api"]

        intent_tool = tools[0]
        assert "context" not in intent_tool.inputSchema.get("properties", {}).get(
            "input", {}
        ).get("properties", {})

        resources = await client.list_resources()
        uris = [str(r.uri) for r in resources]
        assert "intent://schema" in uris
        assert "intent://models" in uris

        templates = await client.list_resource_templates()
        template_uris = [str(t.uriTemplate) for t in templates]
        assert "intent://models/{model_name}" in template_uris

        models_doc = await client.read_resource("intent://models")
        models_json = json.loads(models_doc[0].text)
        names = [m["model"] for m in models_json["models"]]
        assert "Brand" in names
        assert "BlogPost" in names
        assert "Hidden" not in names

        brand_doc = await client.read_resource("intent://models/BlogPost")
        brand_json = json.loads(brand_doc[0].text)
        cmd_names = [c["name"] for c in brand_json["commands"]]
        assert cmd_names == ["generate"]

        r = await client.call_tool(
            "intent_api", {"input": {"model": "Brand", "action": "list"}}
        )
        assert r.is_error is False
        body = json.loads(r.content[0].text)
        assert body["total"] == 1
        assert body["user_id"] == "u1"

        r = await client.call_tool(
            "intent_api",
            {
                "input": {
                    "model": "BlogPost",
                    "action": "custom",
                    "command": "generate",
                    "id": "p1",
                }
            },
        )
        assert r.is_error is False
        body = json.loads(r.content[0].text)
        assert body["generated"] is True
        assert body["id"] == "p1"

        r = await client.call_tool(
            "intent_api",
            {"input": {"model": "Hidden", "action": "list"}},
            raise_on_error=False,
        )
        assert r.is_error is True

        r = await client.call_tool(
            "intent_api",
            {"input": {"model": "Nope", "action": "list"}},
            raise_on_error=False,
        )
        assert r.is_error is True


@pytest.mark.asyncio
async def test_db_session_lifecycle_under_concurrent_load(server):
    """Boundary B31: 50 concurrent MCP calls must not leak db sessions."""
    from fastmcp import Client
    from fastmcp.client.transports import StreamableHttpTransport

    db_calls = server["db_calls"]
    opens_before = db_calls["opens"]
    closes_before = db_calls["closes"]

    async def one_call():
        transport = StreamableHttpTransport(
            f"http://127.0.0.1:{server['port']}/mcp/", auth="good-token"
        )
        async with Client(transport) as client:
            r = await client.call_tool(
                "intent_api", {"input": {"model": "Brand", "action": "list"}}
            )
            assert r.is_error is False

    await asyncio.gather(*[one_call() for _ in range(50)])

    opens = db_calls["opens"] - opens_before
    closes = db_calls["closes"] - closes_before
    assert opens >= 50
    assert opens == closes, (
        f"DB session leak: {opens} opens vs {closes} closes"
    )
