"""
Core schemas for the Intent API framework.

IntentRequest is the universal request format — every API call is an intent.
IntentContext carries the caller's identity context (role, team, org, etc).
"""

from pydantic import BaseModel, Field
from typing import Any, Dict, Literal, Optional


class IntentContext(BaseModel):
    """
    Caller context attached to every intent.

    The context tells the backend WHO is making the request and
    WHAT scope they're operating in. This enables multi-tenant,
    role-aware routing without per-endpoint configuration.

    Attributes:
        type: The caller's role/surface type (e.g., "user", "member", "admin").
        team_id: Optional team scope for multi-team applications.
        organization_id: Optional org scope for multi-org setups.
        workspace_id: Optional workspace scope inside an organization.
        acting_as_role: Optional impersonation or role override.
        region: Optional geographic region for region-scoped actions.
    """

    type: str = Field(
        description="The role or surface type of the caller (e.g., 'user', 'admin')."
    )
    team_id: Optional[str] = Field(
        default=None,
        description="Optional team scope for multi-tenant applications.",
    )
    organization_id: Optional[str] = Field(
        default=None,
        description="Optional organization scope.",
    )
    workspace_id: Optional[str] = Field(
        default=None,
        description="Optional workspace scope inside an organization.",
    )
    acting_as_role: Optional[str] = Field(
        default=None,
        description="Optional role override or impersonation.",
    )
    region: Optional[str] = Field(
        default=None,
        description="Optional geographic region for region-scoped actions.",
    )

    class Config:
        extra = "forbid"

    @property
    def scope(self) -> Dict[str, Optional[str]]:
        """Return all non-None scope fields as a dict."""
        return {
            k: v
            for k, v in {
                "team_id": self.team_id,
                "organization_id": self.organization_id,
                "workspace_id": self.workspace_id,
            }.items()
            if v is not None
        }


class IntentRequest(BaseModel):
    """
    The universal request format for the Intent API.

    Every API call is an intent: a declaration of what the caller
    wants to do, on what model, with what data. The framework
    dispatches it to the correct service method.

    Attributes:
        model: The target resource/model name (e.g., "User", "Order").
        action: The CRUD action or "custom" for named commands.
        id: Optional resource ID for read/update/delete operations.
        payload: Optional data payload for create/update/custom operations.
        skip: Pagination offset for list operations.
        limit: Pagination limit for list operations.
        command: Named command string when action is "custom".
        context: Caller context (role, team, org, etc).
    """

    model: str = Field(
        description="Target resource/model name (e.g., 'User', 'Order')."
    )
    action: Literal["create", "read", "update", "delete", "list", "custom"] = Field(
        description="The intent action: CRUD or 'custom' for named commands."
    )
    id: Optional[Any] = Field(
        default=None,
        description="Resource ID for read/update/delete operations.",
    )
    payload: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Data payload for create/update/custom operations.",
    )
    skip: Optional[int] = Field(
        default=0,
        description="Pagination offset for list operations.",
    )
    limit: Optional[int] = Field(
        default=10,
        description="Pagination limit for list operations.",
    )
    command: Optional[str] = Field(
        default=None,
        description="Named command string when action is 'custom'.",
    )
    context: Optional[IntentContext] = Field(
        default=None,
        description="Caller context (role, team, org, etc).",
    )

    class Config:
        extra = "forbid"
