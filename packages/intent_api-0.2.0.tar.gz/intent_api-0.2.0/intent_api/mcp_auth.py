"""
mcp_auth — Pluggable auth helpers for the MCP surface.

Two helpers shipped:
  * `clerk_mcp_auth`    — verify Clerk-issued JWTs (requires clerk-backend-api)
  * `bearer_token_auth` — generic bearer token verification (BYO verify_fn)

Both return an async function with signature `(credentials, context, db) -> user`
— identical contract to IntentRouter.build_machine's get_user.

Boundary B32: get_user functions used with build_mcp() must accept exactly
`(credentials, context, db)` as keyword args. Functions that use FastAPI
`Depends()` parameters are NOT compatible — refactor them or wrap.

    # ✅ Works with MCP
    async def get_mcp_user(credentials, context, db):
        ...

    # ❌ Does NOT work with MCP — FastAPI Depends() in signature
    async def get_rest_user(creds=Depends(oauth2_scheme), db=Depends(get_db)):
        ...

This module also exposes `build_protected_resource_metadata()` which
constructs the RFC 9728 "OAuth Protected Resource Metadata" document
served at /.well-known/oauth-protected-resource.
"""

from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, List, Optional

from fastapi import APIRouter, HTTPException

logger = logging.getLogger("intent_api.mcp_auth")

GetUser = Callable[..., Awaitable[Any]]
TokenVerifier = Callable[[str], Any]
UserResolver = Callable[..., Awaitable[Any]]


# ── RFC 9728 — OAuth Protected Resource Metadata ────────────────────────────


def build_protected_resource_metadata(
    *,
    resource_url: str,
    authorization_servers: List[str],
    scopes_supported: Optional[List[str]] = None,
    bearer_methods_supported: Optional[List[str]] = None,
    resource_name: Optional[str] = None,
    resource_documentation: Optional[str] = None,
) -> dict:
    """
    Build a Protected Resource Metadata document per RFC 9728.

    Served at `/.well-known/oauth-protected-resource` so MCP clients can
    discover which authorization server(s) issue tokens for this resource.
    """
    doc: dict = {
        "resource": resource_url,
        "authorization_servers": list(authorization_servers),
        "bearer_methods_supported": bearer_methods_supported or ["header"],
    }
    if scopes_supported:
        doc["scopes_supported"] = list(scopes_supported)
    if resource_name:
        doc["resource_name"] = resource_name
    if resource_documentation:
        doc["resource_documentation"] = resource_documentation
    return doc


def build_well_known_router(
    *,
    resource_url: str,
    authorization_server: str,
    additional_authorization_servers: Optional[List[str]] = None,
    scopes_supported: Optional[List[str]] = None,
    resource_name: Optional[str] = None,
    resource_documentation: Optional[str] = None,
) -> APIRouter:
    """
    FastAPI router exposing GET /.well-known/oauth-protected-resource.

    MUST be mounted at the application root (per RFC 9728), not under
    the MCP prefix:

        app.include_router(build_well_known_router(...))
    """
    auth_servers = [authorization_server, *(additional_authorization_servers or [])]
    metadata = build_protected_resource_metadata(
        resource_url=resource_url,
        authorization_servers=auth_servers,
        scopes_supported=scopes_supported,
        resource_name=resource_name,
        resource_documentation=resource_documentation,
    )

    router = APIRouter(tags=["MCP (Discovery)"])

    @router.get("/.well-known/oauth-protected-resource")
    async def get_protected_resource_metadata() -> dict:
        return metadata

    return router


# ── Generic bearer token auth ────────────────────────────────────────────────


def bearer_token_auth(*, verify_fn: TokenVerifier, resolve_user: UserResolver) -> GetUser:
    """
    Build a get_user function for any bearer-token-issuing authorization server.

    Args:
        verify_fn: Callable[[token_str], decoded_token]. Should raise on
            invalid/expired tokens.
        resolve_user: Async callable(decoded_token, db) -> user. Looks up
            (or creates) the user in your database from the token claims.

    Returns:
        An async get_user(credentials, context, db) function compatible
        with IntentRouter.build_mcp().

    Example:
        async def lookup(decoded_token, db):
            user_id = decoded_token["sub"]
            return db.query(User).filter(User.clerk_id == user_id).first()

        get_user = bearer_token_auth(
            verify_fn=verify_my_jwt,
            resolve_user=lookup,
        )
    """

    async def get_user(*, credentials, context=None, db=None):
        token = getattr(credentials, "credentials", None) if credentials else None
        if not token:
            raise HTTPException(
                status_code=401, detail="Missing bearer token."
            )
        try:
            decoded = verify_fn(token)
        except HTTPException:
            raise
        except Exception as exc:
            logger.warning("Token verification failed: %s", exc)
            raise HTTPException(
                status_code=401, detail="Invalid or expired token."
            )

        user = await resolve_user(decoded, db)
        if user is None:
            raise HTTPException(
                status_code=401, detail="User not found for token."
            )
        return user

    return get_user


# ── Clerk-specific auth ──────────────────────────────────────────────────────


def clerk_mcp_auth(
    *,
    secret_key: str,
    authorization_server: str,
    resolve_user: Optional[UserResolver] = None,
    jwks_url: Optional[str] = None,
) -> GetUser:
    """
    Build a get_user function that verifies Clerk-issued JWTs.

    Lazy-imports `clerk-backend-api`. Raises a clear ImportError if not
    installed (Boundary B5).

    Args:
        secret_key: Your Clerk secret key (sk_test_... or sk_live_...).
        authorization_server: Your Clerk Frontend API URL — used here only
            for documentation/logging. The actual `.well-known/...` doc is
            built separately via build_well_known_router().
        resolve_user: Async callable(decoded_token, db) -> user. Looks up
            the user in YOUR database from the Clerk token claims (the
            `sub` claim is the Clerk user id).
            If omitted, the raw decoded token is returned as the "user".
        jwks_url: Optional explicit JWKS URL. Defaults to Clerk's auto-derived URL.

    Returns:
        An async get_user(credentials, context, db) function compatible
        with IntentRouter.build_mcp().
    """
    try:
        from clerk_backend_api import authenticate_request  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "clerk_mcp_auth requires the `clerk-backend-api` package. "
            "Install it with: pip install clerk-backend-api"
        ) from exc

    async def _default_resolve(decoded_token, db):
        return decoded_token

    user_resolver = resolve_user or _default_resolve

    def _verify(token: str):
        from clerk_backend_api import Clerk
        import jwt as pyjwt

        client = Clerk(bearer_auth=secret_key)

        try:
            unverified = pyjwt.decode(
                token, options={"verify_signature": False, "verify_exp": True}
            )
        except Exception as exc:
            logger.warning("Failed to decode Clerk JWT: %s", exc)
            raise HTTPException(
                status_code=401, detail="Invalid Clerk token."
            )

        user_id = unverified.get("sub")
        if not user_id:
            raise HTTPException(
                status_code=401, detail="Clerk token missing sub claim."
            )

        try:
            client.users.get(user_id=user_id)
        except Exception as exc:
            logger.warning("Clerk user lookup failed for %s: %s", user_id, exc)
            raise HTTPException(
                status_code=401, detail="Clerk token invalid or user not found."
            )

        return unverified

    return bearer_token_auth(verify_fn=_verify, resolve_user=user_resolver)
