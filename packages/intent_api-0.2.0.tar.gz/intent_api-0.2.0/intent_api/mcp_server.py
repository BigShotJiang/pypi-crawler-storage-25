"""
mcp_server — FastMCP integration for the Intent API.

Exposes the entire Intent API through a single MCP tool (`intent_api`)
plus three discovery Resources. Reuses the existing IntentRouter
dispatch path — zero duplicated routing logic.

Architecture:
- Single tool: `intent_api` (deliberately avoids name collisions in MCP hosts)
- Three resources: intent://schema, intent://models, intent://models/{model}
- Streamable HTTP transport (the modern MCP transport)
- Auth via ASGI middleware that calls the user's `get_user` function
- DB session lifecycle managed in middleware (sync + async generator safe)
- IntentContext is derived server-side — never LLM-provided (Boundary B11)

The `intent_api` tool input schema is a Pydantic model that mirrors
build_intent_tool_input_schema() — context is deliberately absent.
"""

from __future__ import annotations

import inspect
import json
import logging
from typing import Any, Awaitable, Callable, Literal, Optional

from fastapi import HTTPException
from pydantic import BaseModel, Field
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Receive, Scope, Send

from intent_api.mcp_schemas import (
    build_full_schema,
    build_model_schema,
    build_models_list,
)
from intent_api.registry import ServiceRegistry
from intent_api.schemas import IntentContext, IntentRequest

logger = logging.getLogger("intent_api.mcp")


GetUser = Callable[..., Awaitable[Any]]


# ── Tool input schema (Pydantic) ─────────────────────────────────────────────


class IntentToolInput(BaseModel):
    """
    Input for the single `intent_api` MCP tool.

    SECURITY (Boundary B11): `context` is deliberately absent.
    IntentContext is derived server-side from the authenticated user
    inside the tool handler. The LLM cannot pass, forge, or influence
    team_id, role, or any context field through this surface.
    """

    model: str = Field(
        description=(
            "Target resource/model name (e.g. 'User', 'Order'). "
            "Use the intent://models resource to discover available models."
        )
    )
    action: Literal["create", "read", "update", "delete", "list", "custom"] = Field(
        description=(
            "The intent action: standard CRUD verb, 'list' for pagination, "
            "or 'custom' for a named command."
        )
    )
    command: Optional[str] = Field(
        default=None,
        description=(
            "Named command string when action is 'custom'. "
            "Use intent://models/{model} to discover available commands."
        ),
    )
    id: Optional[Any] = Field(
        default=None,
        description="Resource ID for read/update/delete and some custom commands.",
    )
    payload: Optional[dict] = Field(
        default=None,
        description=(
            "Data payload for create/update/custom operations. Per-command "
            "typed schemas are described in intent://models/{model}."
        ),
    )
    skip: int = Field(
        default=0, ge=0, description="Pagination offset for list operations."
    )
    limit: int = Field(
        default=10, ge=1, description="Pagination limit for list operations."
    )


# ── DB lifecycle (Boundary B31) ──────────────────────────────────────────────


async def _open_db(get_db: Callable[..., Any]):
    """
    Open a database session from a `get_db` dependency.

    Supports sync generators, async generators, and plain callables.
    Returns a tuple (db, cleanup_callable). `cleanup_callable` must be
    awaited in a `finally` block to prevent session leaks under load.
    """
    if get_db is None:
        return None, None

    result = get_db()

    if inspect.isasyncgen(result):
        gen = result
        db = await gen.__anext__()

        async def cleanup() -> None:
            try:
                await gen.__anext__()
            except StopAsyncIteration:
                pass
            except Exception:
                logger.exception("Error closing async db session")

        return db, cleanup

    if inspect.isgenerator(result):
        gen = result
        db = next(gen)

        async def cleanup() -> None:
            try:
                next(gen)
            except StopIteration:
                pass
            except Exception:
                logger.exception("Error closing sync db session")

        return db, cleanup

    if inspect.isawaitable(result):
        db = await result
        return db, None

    return result, None


# ── Bearer credentials shim ──────────────────────────────────────────────────


class _BearerCredentials:
    """Mirror of fastapi.security.HTTPAuthorizationCredentials for compatibility."""

    __slots__ = ("scheme", "credentials")

    def __init__(self, scheme: str, credentials: str) -> None:
        self.scheme = scheme
        self.credentials = credentials


# ── Auth middleware ──────────────────────────────────────────────────────────


def _build_unauthorized_response(
    message: str,
    resource_metadata_url: Optional[str],
) -> JSONResponse:
    """Build a 401 with the WWW-Authenticate header pointing to the metadata URL."""
    headers: dict = {}
    if resource_metadata_url:
        headers["WWW-Authenticate"] = (
            f'Bearer resource_metadata="{resource_metadata_url}"'
        )
    else:
        headers["WWW-Authenticate"] = "Bearer"
    return JSONResponse(
        status_code=401,
        content={"error": "unauthorized", "error_description": message},
        headers=headers,
    )


class IntentApiAuthMiddleware:
    """
    Pure-ASGI middleware that authenticates MCP requests by:
      1. Extracting the bearer token from the Authorization header
      2. Calling the user-provided get_user(credentials, context, db)
      3. Storing user + db on request.state for the tool handler to read
      4. Closing the db session in finally (Boundary B31)

    Returns 401 with WWW-Authenticate header on missing/invalid tokens.
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        get_user: GetUser,
        get_db: Optional[Callable[..., Any]],
        resource_metadata_url: Optional[str],
    ) -> None:
        self.app = app
        self.get_user = get_user
        self.get_db = get_db
        self.resource_metadata_url = resource_metadata_url

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request = Request(scope, receive=receive)
        auth_header = request.headers.get("authorization") or ""
        parts = auth_header.split(" ", 1)

        if len(parts) != 2 or parts[0].lower() != "bearer" or not parts[1].strip():
            response = _build_unauthorized_response(
                "Missing or malformed Authorization header (expected Bearer token).",
                self.resource_metadata_url,
            )
            await response(scope, receive, send)
            return

        credentials = _BearerCredentials(scheme=parts[0], credentials=parts[1].strip())

        db, db_cleanup = None, None
        try:
            try:
                db, db_cleanup = await _open_db(self.get_db) if self.get_db else (None, None)
            except Exception:
                logger.exception("Failed to open db session for MCP request")
                response = _build_unauthorized_response(
                    "Database session unavailable.", self.resource_metadata_url
                )
                await response(scope, receive, send)
                return

            try:
                user = await self.get_user(
                    credentials=credentials,
                    context=IntentContext(type="mcp"),
                    db=db,
                )
            except HTTPException as exc:
                response = _build_unauthorized_response(
                    exc.detail or "Authentication failed.",
                    self.resource_metadata_url,
                )
                await response(scope, receive, send)
                return
            except Exception:
                logger.exception("get_user raised unexpectedly")
                response = _build_unauthorized_response(
                    "Authentication failed.", self.resource_metadata_url
                )
                await response(scope, receive, send)
                return

            if user is None:
                response = _build_unauthorized_response(
                    "Authentication failed.", self.resource_metadata_url
                )
                await response(scope, receive, send)
                return

            scope.setdefault("state", {})
            if isinstance(scope["state"], dict):
                scope["state"]["intent_api_user"] = user
                scope["state"]["intent_api_db"] = db
            else:
                setattr(scope["state"], "intent_api_user", user)
                setattr(scope["state"], "intent_api_db", db)

            await self.app(scope, receive, send)
        finally:
            if db_cleanup is not None:
                try:
                    await db_cleanup()
                except Exception:
                    logger.exception("Error during db session cleanup")


# ── Result formatting (Boundary B14) ────────────────────────────────────────


def _serialize_result(result: Any) -> str:
    """JSON-encode a dispatch result, falling back to str() for non-JSON objects."""
    if hasattr(result, "model_dump"):
        try:
            return json.dumps(result.model_dump(), default=str)
        except Exception:
            return json.dumps(str(result))
    try:
        return json.dumps(result, default=str)
    except (TypeError, ValueError):
        return json.dumps(str(result))


# ── Box logger (matches REST surface format) ────────────────────────────────


def _log_intent(
    intent: IntentRequest,
    user: Any,
    debug_payload: bool,
) -> None:
    user_id = getattr(user, "id", user) if user else "unknown"
    logger.info("--------------------------------")
    logger.info("|")
    logger.info(f"| MCP Intent received: {intent.model}")
    logger.info(f"| Action: {intent.action}")
    logger.info(f"| Command: {intent.command}")
    logger.info("|")
    logger.info(f"| ID: {intent.id}")
    logger.info(f"| User: {user_id}")
    logger.info("| Source: mcp")
    if debug_payload:
        logger.info(f"| Payload: {intent.payload}")
    logger.info("|")
    logger.info("--------------------------------")


# ── Builder ──────────────────────────────────────────────────────────────────


def build_mcp_app(
    *,
    registry: ServiceRegistry,
    get_user: GetUser,
    get_db: Optional[Callable[..., Any]] = None,
    server_name: str = "intent-api",
    instructions: Optional[str] = None,
    resource_metadata_url: Optional[str] = None,
    debug: bool = False,
    debug_payload: bool = False,
) -> ASGIApp:
    """
    Build the MCP server ASGI app for app.mount() into a FastAPI/Starlette app.

    This returns an ASGI app (not a FastAPI Router) because MCP speaks
    JSON-RPC 2.0 over Streamable HTTP — it is a mounted protocol, not a
    REST router (Boundary B6).

    Args:
        registry: The Intent API ServiceRegistry from your IntentRouter.
        get_user: Async function with signature (credentials, context, db) -> user.
            Identical contract to IntentRouter.build_machine's get_user.
            Must NOT use FastAPI Depends() in its signature (Boundary B32).
        get_db: Optional FastAPI dependency that yields a db session.
            Generators (sync + async) are properly closed (Boundary B31).
        server_name: MCP server name advertised in the initialize response.
        instructions: Optional natural-language instructions for clients.
        resource_metadata_url: URL of the OAuth Protected Resource Metadata
            document (RFC 9728). Sent in the WWW-Authenticate header on 401.
            Typically the URL where build_mcp_well_known() is mounted.
        debug: Box-style logs for every MCP tool call.
        debug_payload: Also log the payload (DEV only — may contain secrets).

    Returns:
        A Starlette ASGI app ready to mount: `app.mount("/mcp", build_mcp_app(...))`.
    """
    try:
        from fastmcp import FastMCP
        from fastmcp.server.dependencies import get_http_request
    except ImportError as exc:
        raise ImportError(
            "fastmcp is required for the MCP surface. "
            "Install it with: pip install fastmcp"
        ) from exc

    from intent_api.router import _dispatch  # circular-safe (router doesn't import this)

    mcp = FastMCP(
        name=server_name,
        instructions=instructions
        or (
            "Intent API MCP surface. Call the `intent_api` tool to dispatch "
            "an intent. Read intent://models or intent://models/{model} to "
            "discover available models, actions, and commands."
        ),
    )

    # ── Tool: intent_api ──────────────────────────────────────────────────

    @mcp.tool(
        name="intent_api",
        description=(
            "Dispatch an intent to the Intent API backend. Use intent://models "
            "to discover models and intent://models/{model} to discover the "
            "available actions, commands, and payload schemas. The 'context' "
            "field is intentionally not accepted — it is derived server-side "
            "from the authenticated session."
        ),
    )
    async def intent_api_tool(input: IntentToolInput) -> str:
        request = get_http_request()
        state_dict = (
            request.state._state if hasattr(request.state, "_state") else {}
        )
        user = state_dict.get("intent_api_user") or getattr(
            request.state, "intent_api_user", None
        )
        db = state_dict.get("intent_api_db") or getattr(
            request.state, "intent_api_db", None
        )

        if user is None:
            raise HTTPException(status_code=401, detail="Unauthenticated.")

        if not registry.is_mcp_exposed(input.model):
            raise HTTPException(
                status_code=404,
                detail=f"Model '{input.model}' is not available.",
            )

        service = registry.get(input.model)
        if service is None:
            raise HTTPException(
                status_code=404,
                detail=f"Model '{input.model}' is not registered.",
            )

        if service.is_admin_only:
            raise HTTPException(
                status_code=403,
                detail=f"Model '{input.model}' is admin-only.",
            )

        context = IntentContext(type="mcp")

        intent = IntentRequest(
            model=input.model,
            action=input.action,
            command=input.command,
            id=input.id,
            payload=input.payload,
            skip=input.skip,
            limit=input.limit,
            context=context,
        )

        if debug:
            _log_intent(intent, user, debug_payload)

        try:
            result = await _dispatch(service, intent, db, user, context)
        except HTTPException:
            raise
        except Exception:
            logger.exception("Unexpected error in MCP tool dispatch")
            raise HTTPException(status_code=500, detail="Internal server error.")

        return _serialize_result(result)

    # ── Resources ──────────────────────────────────────────────────────────

    @mcp.resource(
        "intent://schema",
        name="intent-schema",
        description=(
            "Full Intent API schema document. Lists every MCP-visible model "
            "with its overridden CRUD actions, custom commands, and payload "
            "schemas. May be large for big registries — prefer intent://models "
            "or intent://models/{model} for narrower discovery."
        ),
        mime_type="application/json",
    )
    async def schema_resource() -> str:
        return json.dumps(build_full_schema(registry), default=str)

    @mcp.resource(
        "intent://models",
        name="intent-models",
        description=(
            "Lightweight list of all MCP-visible models with their service "
            "class names and one-line descriptions."
        ),
        mime_type="application/json",
    )
    async def models_resource() -> str:
        return json.dumps(build_models_list(registry), default=str)

    @mcp.resource(
        "intent://models/{model_name}",
        name="intent-model",
        description=(
            "Full schema for a single model: actions, custom commands, and "
            "per-command payload schemas. Returns an error document if the "
            "model is not registered or is hidden via expose_mcp=False."
        ),
        mime_type="application/json",
    )
    async def model_resource(model_name: str) -> str:
        schema = build_model_schema(registry, model_name)
        if schema is None:
            return json.dumps(
                {
                    "error": "not_found",
                    "model": model_name,
                    "message": (
                        f"Model '{model_name}' is not registered or is not "
                        f"exposed to the MCP surface."
                    ),
                }
            )
        return json.dumps(schema, default=str)

    # ── Build ASGI app ─────────────────────────────────────────────────────

    from starlette.middleware import Middleware

    auth_middleware = Middleware(
        IntentApiAuthMiddleware,
        get_user=get_user,
        get_db=get_db,
        resource_metadata_url=resource_metadata_url,
    )
    return mcp.http_app(
        path="/",
        transport="http",
        middleware=[auth_middleware],
        stateless_http=True,
    )
