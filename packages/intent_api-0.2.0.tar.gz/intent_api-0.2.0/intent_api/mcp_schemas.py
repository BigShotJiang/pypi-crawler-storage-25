"""
mcp_schemas — JSON Schema generators for the MCP Resources surface.

Produces three discoverability documents auto-derived from the
ServiceRegistry and `_registered_commands`:

- intent://schema           → build_full_schema(registry)
- intent://models           → build_models_list(registry)
- intent://models/{model}   → build_model_schema(registry, model)

All output conforms to JSON Schema 2020-12 (MCP standard, SEP-1613).
"""

import inspect
from typing import Any, Dict, List, Optional, Type

from pydantic import BaseModel

from intent_api.registry import ServiceRegistry
from intent_api.service import IntentService

JSON_SCHEMA_DIALECT = "https://json-schema.org/draft/2020-12/schema"

CRUD_ACTIONS = ("create", "read", "update", "delete", "list")


# ── Helpers ───────────────────────────────────────────────────────────────────


def _is_overridden(service_cls: Type[IntentService], method_name: str) -> bool:
    """Check if a service subclass overrides a base method."""
    method = getattr(service_cls, method_name, None)
    base_method = getattr(IntentService, method_name, None)
    if method is None or base_method is None:
        return False
    return method is not base_method


def _payload_schema(
    schema_cls: Optional[Type[BaseModel]],
) -> Dict[str, Any]:
    """
    Generate a JSON Schema 2020-12 fragment for a payload.

    Pydantic v2's model_json_schema() emits draft-2020-12 by default.
    Returns a loose `{"type": "object"}` if no schema class is provided.
    """
    if schema_cls is None:
        return {"type": "object"}
    try:
        return schema_cls.model_json_schema()
    except Exception:
        return {"type": "object"}


def _crud_actions_for(service: IntentService) -> List[Dict[str, Any]]:
    """Return overridden CRUD actions for a service."""
    actions: List[Dict[str, Any]] = []
    for action_name in CRUD_ACTIONS:
        if _is_overridden(service.__class__, action_name):
            actions.append({"name": action_name})
    return actions


def _commands_for(service: IntentService) -> List[Dict[str, Any]]:
    """Return registered custom commands with payload schemas."""
    commands: List[Dict[str, Any]] = []
    registered = getattr(service.__class__, "_registered_commands", {}) or {}
    for command_name, info in registered.items():
        commands.append(
            {
                "name": command_name,
                "handler": info.get("handler"),
                "payload_schema": _payload_schema(info.get("schema")),
            }
        )
    return commands


def _service_doc(service: IntentService) -> Optional[str]:
    """Extract the first non-empty line of the service's docstring."""
    doc = inspect.getdoc(service.__class__)
    if not doc:
        return None
    for line in doc.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped
    return None


# ── Public builders ──────────────────────────────────────────────────────────


def build_models_list(registry: ServiceRegistry) -> Dict[str, Any]:
    """
    Build the `intent://models` Resource payload.

    Returns a lightweight list of MCP-visible models with their service
    class names and one-line descriptions. Useful for cheap discovery.
    """
    models = []
    for model_name in registry.mcp_models:
        service = registry.get(model_name)
        if service is None:
            continue
        models.append(
            {
                "model": model_name,
                "service": service.__class__.__name__,
                "description": _service_doc(service),
            }
        )
    return {
        "$schema": JSON_SCHEMA_DIALECT,
        "models": models,
        "total": len(models),
    }


def build_model_schema(
    registry: ServiceRegistry, model_name: str
) -> Optional[Dict[str, Any]]:
    """
    Build the `intent://models/{model}` Resource payload for a single model.

    Returns None if the model is not registered or is hidden via expose_mcp=False.
    """
    if not registry.is_mcp_exposed(model_name):
        return None

    service = registry.get(model_name)
    if service is None:
        return None

    return {
        "$schema": JSON_SCHEMA_DIALECT,
        "model": model_name,
        "service": service.__class__.__name__,
        "description": _service_doc(service),
        "actions": _crud_actions_for(service),
        "commands": _commands_for(service),
    }


def build_full_schema(registry: ServiceRegistry) -> Dict[str, Any]:
    """
    Build the `intent://schema` Resource payload — full registry document.

    Includes every MCP-visible model with its actions, commands, and
    payload schemas. May be large for big registries; cheaper alternatives
    are `intent://models` and `intent://models/{model}`.
    """
    services: Dict[str, Any] = {}
    for model_name in registry.mcp_models:
        per_model = build_model_schema(registry, model_name)
        if per_model is None:
            continue
        services[model_name] = {
            "service": per_model["service"],
            "description": per_model["description"],
            "actions": per_model["actions"],
            "commands": per_model["commands"],
        }
    return {
        "$schema": JSON_SCHEMA_DIALECT,
        "version": "1",
        "services": services,
        "total": len(services),
    }


def build_intent_tool_input_schema() -> Dict[str, Any]:
    """
    Build the JSON Schema 2020-12 input schema for the single MCP `intent_api` tool.

    SECURITY: This schema deliberately OMITS the `context` field.
    IntentContext is derived server-side from the authenticated user
    inside the tool handler (see Boundary B11). The LLM cannot
    pass, forge, or influence team_id, role, or any context field.
    """
    return {
        "$schema": JSON_SCHEMA_DIALECT,
        "type": "object",
        "properties": {
            "model": {
                "type": "string",
                "description": (
                    "Target resource/model name (e.g. 'User', 'Order'). "
                    "Use the intent://models resource to discover available models."
                ),
            },
            "action": {
                "type": "string",
                "enum": [
                    "create",
                    "read",
                    "update",
                    "delete",
                    "list",
                    "custom",
                ],
                "description": (
                    "The intent action: standard CRUD verb, 'list' for "
                    "pagination, or 'custom' for a named command."
                ),
            },
            "command": {
                "type": "string",
                "description": (
                    "Named command string when action is 'custom'. "
                    "Use intent://models/{model} to discover available commands."
                ),
            },
            "id": {
                "description": (
                    "Resource ID for read/update/delete and some custom commands."
                ),
            },
            "payload": {
                "type": "object",
                "description": (
                    "Data payload for create/update/custom operations. "
                    "Per-command typed schemas are described in "
                    "intent://models/{model}."
                ),
                "additionalProperties": True,
            },
            "skip": {
                "type": "integer",
                "minimum": 0,
                "default": 0,
                "description": "Pagination offset for list operations.",
            },
            "limit": {
                "type": "integer",
                "minimum": 1,
                "default": 10,
                "description": "Pagination limit for list operations.",
            },
        },
        "required": ["model", "action"],
        "additionalProperties": False,
    }
