"""
ServiceRegistry — Maps model names to IntentService instances.

The registry is the central dispatch table. When an intent arrives,
the router looks up the model name here to find the right service.

Example:
    registry = ServiceRegistry()
    registry.register("Todo", TodoService())
    registry.register("User", UserService())
    registry.register("Internal", InternalService(), expose_mcp=False)

    service = registry.get("Todo")  # → TodoService instance
"""

import logging
from typing import Dict, List, Optional

from intent_api.service import IntentService

logger = logging.getLogger("intent_api")


class ServiceRegistry:
    """
    A registry that maps model names to IntentService instances.

    Thread-safe for reads (lookups during request handling).
    Registration should happen at startup before serving requests.

    Each registered service carries an `expose_mcp` flag (default True).
    Services with `expose_mcp=False` are hidden from the MCP surface
    (tool dispatch + Resources) but remain accessible via REST surfaces.
    """

    def __init__(self) -> None:
        self._services: Dict[str, IntentService] = {}
        self._mcp_exposed: Dict[str, bool] = {}

    def register(
        self,
        model: str,
        service: IntentService,
        expose_mcp: bool = True,
    ) -> None:
        """
        Register an IntentService for a model name.

        Args:
            model: The model name (e.g., "User", "Order"). Case-sensitive.
            service: An instance of an IntentService subclass.
            expose_mcp: If True (default), this service is visible to MCP
                clients. If False, the service is registered for REST
                surfaces only and is invisible to the MCP surface.

        Raises:
            TypeError: If service is not an IntentService instance.
            ValueError: If a service is already registered for this model.
        """
        if not isinstance(service, IntentService):
            raise TypeError(
                f"Expected an IntentService instance, got {type(service).__name__}. "
                f"Make sure {type(service).__name__} extends IntentService."
            )

        if model in self._services:
            raise ValueError(
                f"Model '{model}' is already registered to {type(self._services[model]).__name__}. "
                f"Each model name can only have one service."
            )

        self._services[model] = service
        self._mcp_exposed[model] = expose_mcp
        mcp_note = "" if expose_mcp else " (hidden from MCP)"
        logger.info(
            f"Registered intent service: {model} → {type(service).__name__}{mcp_note}"
        )

    def get(self, model: str) -> Optional[IntentService]:
        """Look up the IntentService for a model name. Returns None if not found."""
        return self._services.get(model)

    def has(self, model: str) -> bool:
        """Check if a model name is registered."""
        return model in self._services

    def is_mcp_exposed(self, model: str) -> bool:
        """Check if a model is visible to the MCP surface."""
        return self._mcp_exposed.get(model, False)

    @property
    def models(self) -> List[str]:
        """List all registered model names (regardless of MCP exposure)."""
        return list(self._services.keys())

    @property
    def mcp_models(self) -> List[str]:
        """List model names visible to MCP (expose_mcp=True only)."""
        return [m for m in self._services if self._mcp_exposed.get(m, False)]

    def __len__(self) -> int:
        return len(self._services)

    def __repr__(self) -> str:
        models = ", ".join(self.models)
        return f"<ServiceRegistry [{models}]>"
