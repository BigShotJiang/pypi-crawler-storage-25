"""
Intent API — A constraint-driven API framework for Python.

One endpoint. Typed intents. Zero boilerplate.

Usage:
    from intent_api import IntentRouter, IntentService, custom_action

    router = IntentRouter()

    class UserService(IntentService):
        async def create(self, *, db, user, context, payload):
            ...

        @custom_action(schema=ChangeEmailPayload)
        async def change_email(self, *, db, user, context, id, payload):
            ...

    router.register("User", UserService())
    app.include_router(router.build(...))

MCP server (optional, lazy-loaded):
    from intent_api.mcp_auth import clerk_mcp_auth

    app.mount("/mcp", router.build_mcp(
        get_user=clerk_mcp_auth(secret_key=..., authorization_server=...),
        get_db=get_db,
    ))
    app.include_router(router.build_mcp_well_known(
        resource_url="https://api.example.com/mcp",
        authorization_server="https://example.clerk.accounts.dev",
    ))
"""

from intent_api.registry import ServiceRegistry
from intent_api.router import IntentRouter
from intent_api.schemas import IntentContext, IntentRequest
from intent_api.service import IntentService, MutationResponse, custom_action

__version__ = "0.2.0"

__all__ = [
    "IntentRequest",
    "IntentContext",
    "IntentService",
    "MutationResponse",
    "ServiceRegistry",
    "IntentRouter",
    "custom_action",
]


def __getattr__(name: str):
    """
    Lazy access to MCP helpers — keeps `import intent_api` cheap for
    REST-only users who haven't installed clerk-backend-api.
    """
    if name in ("clerk_mcp_auth", "bearer_token_auth", "build_protected_resource_metadata", "build_well_known_router"):
        from intent_api import mcp_auth

        return getattr(mcp_auth, name)
    if name == "build_mcp_app":
        from intent_api import mcp_server

        return mcp_server.build_mcp_app
    raise AttributeError(f"module 'intent_api' has no attribute {name!r}")
