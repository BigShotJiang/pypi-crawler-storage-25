"""
IntentRouter — The single-endpoint router factory.

Creates FastAPI routers that dispatch intents to registered services.
Supports multiple surfaces (standard, admin, guest, machine) from one configuration.

Example:
    from intent_api import IntentRouter, IntentService

    router = IntentRouter(debug=True)
    router.register("Todo", TodoService())

    # Standard surface (authenticated users)
    app.include_router(router.build(
        get_user=my_auth_dependency,
        get_db=my_db_dependency,
    ))

    # Machine surface (API key auth for SDKs / M2M)
    app.include_router(router.build_machine(
        get_user=my_api_key_auth,
        get_db=my_db_dependency,
    ))
"""

import inspect
import logging
from typing import Any, Awaitable, Callable, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from intent_api.registry import ServiceRegistry
from intent_api.schemas import IntentContext, IntentRequest
from intent_api.service import IntentService

logger = logging.getLogger("intent_api")

# Type for the user-provided auth dependency
# Should accept (credentials, context) and return a user object
AuthDependency = Callable[..., Awaitable[Any]]

# Type for admin authorization check
# Should accept (user, context) and return True if authorized
AdminAuthorize = Callable[[Any, Optional[IntentContext]], bool]


# ── Debug Logging ─────────────────────────────────────────────────────────────


def _log_intent(
    intent: IntentRequest,
    user: Any,
    surface: str,
    debug_payload: bool = False,
) -> None:
    """Print a formatted debug box for an intent."""
    user_id = getattr(user, "id", user) if user else "guest"
    context_type = intent.context.type if intent.context else "none"

    logger.info("--------------------------------")
    logger.info("|")
    logger.info(f"| {surface} Intent received: {intent.model}")
    logger.info(f"| Action: {intent.action}")
    logger.info(f"| Command: {intent.command}")
    logger.info("|")
    logger.info(f"| ID: {intent.id}")
    logger.info(f"| User: {user_id}")
    logger.info(f"| Context: {context_type}")
    if debug_payload:
        logger.info(f"| Payload: {intent.payload}")
    logger.info("|")
    logger.info("--------------------------------")


# ── Dispatch ──────────────────────────────────────────────────────────────────


async def _dispatch(
    service: IntentService,
    intent: IntentRequest,
    db: Any,
    user: Any,
    context: Optional[IntentContext],
) -> Any:
    """
    Core dispatch logic. Routes an intent to the correct service method.
    Shared by all surfaces (standard, admin, guest).
    """
    common = {"db": db, "user": user, "context": context}

    if intent.action == "create":
        return await service.create(**common, payload=intent.payload)
    elif intent.action == "read":
        return await service.read(**common, id=intent.id)
    elif intent.action == "update":
        return await service.update(**common, id=intent.id, payload=intent.payload)
    elif intent.action == "delete":
        return await service.delete(**common, id=intent.id)
    elif intent.action == "list":
        return await service.list(**common, skip=intent.skip, limit=intent.limit)
    elif intent.action == "custom":
        if not intent.command:
            raise HTTPException(
                status_code=400, detail="Missing 'command' for custom action."
            )
        return await service.custom_action(
            **common, command=intent.command, id=intent.id, payload=intent.payload
        )
    else:
        raise HTTPException(
            status_code=400, detail=f"Unknown action '{intent.action}'."
        )


# ── Router Factory ────────────────────────────────────────────────────────────


class IntentRouter:
    """
    Factory for creating intent-based FastAPI routers.

    Usage:
        router = IntentRouter(debug=True, debug_payload=True)
        router.register("Todo", TodoService())
        router.register("User", UserService())

        app.include_router(router.build(
            get_user=my_auth_dependency,
            get_db=my_db_dependency,
        ))

    Args:
        prefix: URL prefix for all intent endpoints. Defaults to "/api".
        debug: Enable debug logging for all intents. Defaults to False.
        debug_payload: Also log the payload (may contain sensitive data — DEV only). Defaults to False.
    """

    def __init__(
        self,
        prefix: str = "/api",
        debug: bool = False,
        debug_payload: bool = False,
    ) -> None:
        self._registry = ServiceRegistry()
        self._prefix = prefix
        self._debug = debug
        self._debug_payload = debug_payload

    # ── Registration ──────────────────────────────────────────────────────

    def register(
        self,
        model: str,
        service: IntentService,
        expose_mcp: bool = True,
    ) -> None:
        """
        Register an IntentService for a model name.

        Args:
            model: The model name (e.g., "User", "Order"). Case-sensitive.
            service: An instance of an IntentService subclass.
            expose_mcp: If True (default), this service is visible to MCP
                clients. If False, the service is REST-only.
        """
        self._registry.register(model, service, expose_mcp=expose_mcp)

    # ── Registry Inspector (for DevTools) ─────────────────────────────────

    def _build_registry_map(self) -> Dict[str, Any]:
        """
        Introspect the service registry and return file paths + line numbers
        for every registered service method. Used by the debug endpoint.

        For services using @custom_action decorators, returns per-command
        line numbers (so DevTools click-to-source opens directly at the
        decorated method, not at custom_action()).
        """
        registry_map = {}

        for model_name in self._registry.models:
            service = self._registry.get(model_name)
            if not service:
                continue

            try:
                source_file = inspect.getfile(service.__class__)
            except (TypeError, OSError):
                source_file = "unknown"

            methods: Dict[str, Any] = {}

            for method_name in ["create", "read", "update", "delete", "list"]:
                method = getattr(service.__class__, method_name, None)
                if method is None:
                    continue
                try:
                    _, line_number = inspect.getsourcelines(method)
                    methods[method_name] = {"line": line_number}
                except (TypeError, OSError):
                    pass

            registered_commands = getattr(
                service.__class__, "_registered_commands", {}
            )
            if registered_commands:
                for command_name, info in registered_commands.items():
                    handler_name = info.get("handler")
                    if not handler_name:
                        continue
                    handler = getattr(service.__class__, handler_name, None)
                    if handler is None:
                        continue
                    try:
                        _, line_number = inspect.getsourcelines(handler)
                        methods[command_name] = {"line": line_number}
                    except (TypeError, OSError):
                        pass
            else:
                custom_method = getattr(
                    service.__class__, "custom_action", None
                )
                if custom_method is not None:
                    try:
                        _, line_number = inspect.getsourcelines(custom_method)
                        methods["custom"] = {"line": line_number}
                    except (TypeError, OSError):
                        pass

            registry_map[model_name] = {
                "service": service.__class__.__name__,
                "file": source_file,
                "methods": methods,
            }

        return registry_map

    def build_debug_router(self) -> APIRouter:
        """
        Build a debug router with the registry inspection endpoint.
        Only mount this when debug=True.

        Returns a router with:
          GET /api/intent-debug/registry → file paths + line numbers for all services
        """
        debug_router = APIRouter(tags=["Intent API (Debug)"])
        endpoint = f"{self._prefix}/intent-debug/registry"

        @debug_router.get(endpoint)
        async def get_registry_map():
            return self._build_registry_map()

        return debug_router

    @property
    def registry(self) -> ServiceRegistry:
        """Access the underlying service registry."""
        return self._registry

    # ── Standard Surface ──────────────────────────────────────────────────

    def build(
        self,
        *,
        get_user: AuthDependency,
        get_db: Callable,
        path: str = "/intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the standard authenticated intent router.

        Args:
            get_user: FastAPI dependency that returns the authenticated user.
            get_db: FastAPI dependency that yields a database session.
            path: Endpoint path (appended to prefix). Defaults to "/intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.
        """
        api_router = APIRouter(tags=tags or ["Intent API"])
        registry = self._registry
        security = HTTPBearer()
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        @api_router.post(endpoint)
        async def handle_intent(
            intent: IntentRequest,
            request: Request,
            db=Depends(get_db),
            credentials: HTTPAuthorizationCredentials = Depends(security),
        ):
            # Resolve user
            user = await get_user(credentials=credentials, context=intent.context, db=db)

            # Debug log
            if debug:
                _log_intent(intent, user, "Standard", debug_payload)

            # Look up service
            service = registry.get(intent.model)
            if not service:
                raise HTTPException(
                    status_code=404,
                    detail=f"Model '{intent.model}' not registered.",
                )

            if service.is_admin_only:
                raise HTTPException(
                    status_code=403, detail="Admin access required."
                )

            return await _dispatch(service, intent, db, user, intent.context)

        return api_router

    # ── Admin Surface ─────────────────────────────────────────────────────

    def build_admin(
        self,
        *,
        get_user: AuthDependency,
        get_db: Callable,
        authorize: AdminAuthorize,
        path: str = "/admin-intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the admin intent router with an additional authorization check.

        Args:
            get_user: FastAPI dependency that returns the authenticated user.
            get_db: FastAPI dependency that yields a database session.
            authorize: A callable (user, context) -> bool that returns True
                if the user is authorized for admin access.
            path: Endpoint path (appended to prefix). Defaults to "/admin-intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.
        """
        api_router = APIRouter(tags=tags or ["Intent API (Admin)"])
        registry = self._registry
        security = HTTPBearer()
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        @api_router.post(endpoint)
        async def handle_admin_intent(
            intent: IntentRequest,
            request: Request,
            db=Depends(get_db),
            credentials: HTTPAuthorizationCredentials = Depends(security),
        ):
            user = await get_user(credentials=credentials, context=intent.context, db=db)

            # Debug log
            if debug:
                _log_intent(intent, user, "Admin", debug_payload)

            # Admin authorization gate
            if not authorize(user, intent.context):
                raise HTTPException(
                    status_code=403, detail="Admin access required."
                )

            service = registry.get(intent.model)
            if not service:
                raise HTTPException(
                    status_code=404,
                    detail=f"Model '{intent.model}' not registered.",
                )

            return await _dispatch(service, intent, db, user, intent.context)

        return api_router

    # ── Machine Surface (API Key Auth) ──────────────────────────────────

    def build_machine(
        self,
        *,
        get_user: AuthDependency,
        get_db: Callable,
        path: str = "/machine-intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the machine-to-machine intent router (API key auth).

        For SDK clients, external services, and M2M communication.
        Auth is handled by the provided get_user dependency, which
        should verify an API key (e.g., Clerk API keys, custom keys)
        instead of a JWT token.

        The get_user function receives (credentials, context, db) just like
        the standard surface — but credentials will contain an API key
        instead of a JWT. Your get_user implementation decides how to verify it.

        Args:
            get_user: FastAPI dependency that verifies the API key and returns a user/context.
            get_db: FastAPI dependency that yields a database session.
            path: Endpoint path (appended to prefix). Defaults to "/machine-intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.

        Example:
            async def get_machine_user(credentials, context, db):
                api_key = credentials.credentials  # "sk_live_xxx"
                # Verify with Clerk API keys or your own key table
                project = verify_api_key(db, api_key)
                return project.owner  # Return the user who owns this key

            app.include_router(intent_router.build_machine(
                get_user=get_machine_user,
                get_db=get_db,
            ))
        """
        api_router = APIRouter(tags=tags or ["Intent API (Machine)"])
        registry = self._registry
        security = HTTPBearer()
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        @api_router.post(endpoint)
        async def handle_machine_intent(
            intent: IntentRequest,
            request: Request,
            db=Depends(get_db),
            credentials: HTTPAuthorizationCredentials = Depends(security),
        ):
            # Resolve user via API key
            user = await get_user(credentials=credentials, context=intent.context, db=db)

            # Debug log
            if debug:
                _log_intent(intent, user, "Machine", debug_payload)

            # Look up service
            service = registry.get(intent.model)
            if not service:
                raise HTTPException(
                    status_code=404,
                    detail=f"Model '{intent.model}' not registered.",
                )

            return await _dispatch(service, intent, db, user, intent.context)

        return api_router

    # ── MCP Surface ────────────────────────────────────────────────────────

    def build_mcp(
        self,
        *,
        get_user: AuthDependency,
        get_db: Optional[Callable] = None,
        server_name: str = "intent-api",
        instructions: Optional[str] = None,
        resource_metadata_url: Optional[str] = None,
    ):
        """
        Build the MCP surface as an ASGI app for `app.mount()`.

        Unlike the REST surfaces (which return FastAPI Routers consumed
        with `app.include_router()`), MCP speaks JSON-RPC 2.0 over Streamable
        HTTP — it is a mounted protocol, not a REST router (Boundary B6).

        IMPORTANT: FastMCP's session manager requires its lifespan to be
        attached to the parent FastAPI app. Build once, mount once, and
        pass the lifespan explicitly:

            mcp_app = intent_router.build_mcp(
                get_user=clerk_mcp_auth(...),
                get_db=get_db,
                resource_metadata_url="https://api.example.com/.well-known/oauth-protected-resource",
            )
            app = FastAPI(lifespan=mcp_app.lifespan)
            app.mount("/mcp", mcp_app)

        Args:
            get_user: Async function with signature (credentials, context, db) -> user.
                Identical contract to build_machine's get_user. Must NOT use
                FastAPI Depends() in its signature (Boundary B32).
            get_db: Optional dependency that yields a db session (sync or async
                generator). The MCP middleware closes it in finally to prevent
                pool leaks under concurrent load (Boundary B31).
            server_name: MCP server name advertised in the initialize response.
            instructions: Optional natural-language instructions for clients.
            resource_metadata_url: URL to your /.well-known/oauth-protected-resource
                endpoint. Sent in the WWW-Authenticate header on 401.

        Returns:
            A Starlette ASGI app for `app.mount()`.
        """
        from intent_api.mcp_server import build_mcp_app

        return build_mcp_app(
            registry=self._registry,
            get_user=get_user,
            get_db=get_db,
            server_name=server_name,
            instructions=instructions,
            resource_metadata_url=resource_metadata_url,
            debug=self._debug,
            debug_payload=self._debug_payload,
        )

    def build_mcp_well_known(
        self,
        *,
        resource_url: str,
        authorization_server: str,
        additional_authorization_servers: Optional[list[str]] = None,
        scopes_supported: Optional[list[str]] = None,
        resource_name: Optional[str] = None,
        resource_documentation: Optional[str] = None,
    ) -> APIRouter:
        """
        Build the OAuth Protected Resource Metadata router (RFC 9728).

        MUST be mounted at the application root, not under the MCP prefix:

            app.include_router(intent_router.build_mcp_well_known(
                resource_url="https://api.example.com/mcp",
                authorization_server="https://example.clerk.accounts.dev",
            ))

        Returns:
            A FastAPI Router exposing GET /.well-known/oauth-protected-resource.
        """
        from intent_api.mcp_auth import build_well_known_router

        return build_well_known_router(
            resource_url=resource_url,
            authorization_server=authorization_server,
            additional_authorization_servers=additional_authorization_servers,
            scopes_supported=scopes_supported,
            resource_name=resource_name,
            resource_documentation=resource_documentation,
        )

    # ── Guest Surface ─────────────────────────────────────────────────────

    def build_guest(
        self,
        *,
        get_db: Optional[Callable] = None,
        path: str = "/guest-intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the guest (unauthenticated) intent router.

        Only services with `is_guest_allowed = True` are accessible.
        Only actions in `allowed_guest_actions` are permitted.

        Args:
            get_db: Optional FastAPI dependency that yields a database session.
            path: Endpoint path (appended to prefix). Defaults to "/guest-intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.
        """
        api_router = APIRouter(tags=tags or ["Intent API (Guest)"])
        registry = self._registry
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        if get_db:

            @api_router.post(endpoint)
            async def handle_guest_intent_with_db(
                intent: IntentRequest,
                request: Request,
                db=Depends(get_db),
            ):
                return await _handle_guest(registry, intent, db=db, debug=debug, debug_payload=debug_payload)

        else:

            @api_router.post(endpoint)
            async def handle_guest_intent(
                intent: IntentRequest,
                request: Request,
            ):
                return await _handle_guest(registry, intent, db=None, debug=debug, debug_payload=debug_payload)

        return api_router


async def _handle_guest(
    registry: ServiceRegistry,
    intent: IntentRequest,
    db: Any = None,
    debug: bool = False,
    debug_payload: bool = False,
) -> Any:
    """Shared guest dispatch logic."""
    # Debug log
    if debug:
        _log_intent(intent, None, "Guest", debug_payload)

    service = registry.get(intent.model)
    if not service:
        raise HTTPException(
            status_code=404, detail="This action is not allowed."
        )

    if not service.guest_allowed(intent.action, intent.command):
        raise HTTPException(
            status_code=403,
            detail="You don't have permission to perform this action.",
        )

    # Guests can only read, list, or use allowed custom commands
    if intent.action not in ("read", "list", "custom"):
        raise HTTPException(
            status_code=403, detail="Guests can only read or list."
        )

    return await _dispatch(service, intent, db=db, user=None, context=intent.context)
