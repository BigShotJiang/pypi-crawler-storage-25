# spawnhub-openai-agents

SpawnHub adapter for the [OpenAI Agents SDK](https://github.com/openai/openai-agents-python). Streams agent events to [SpawnHub](https://spawnhub.ai) so your agents appear as live avatars in the SpawnHub world.

```bash
pip install spawnhub-openai-agents
```

```python
from spawnhub_openai_agents import SpawnHubTracingProcessor
from agents import Agent, Runner, add_trace_processor

add_trace_processor(SpawnHubTracingProcessor(api_key="spwnhub_..."))

agent = Agent(name="my-agent", instructions="You are a helpful assistant.")
result = await Runner.run(agent, "Hello!")
```

For OTEL-native frameworks (LangChain, CrewAI, AutoGen, Google ADK) use the main [`spawnhub`](https://pypi.org/project/spawnhub/) package instead — those emit OpenTelemetry natively and don't need an adapter.
