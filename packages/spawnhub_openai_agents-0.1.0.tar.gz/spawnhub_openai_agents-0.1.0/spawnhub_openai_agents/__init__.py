"""
spawnhub-openai-agents — DEPRECATED.

This package is superseded by the `spawnhub` SDK which auto-detects
all supported frameworks including the OpenAI Agents SDK.

Migrate in one step:

    # Before
    from spawnhub_openai_agents import instrument
    instrument(endpoint="...", pattern="orchestrator", personas={...})

    # After
    from spawnhub import instrument
    instrument(api_key="spwnhub_...", pattern="orchestrator", personas={...})

This shim re-exports from `spawnhub` so existing code keeps working.
"""

import warnings as _warnings

_warnings.warn(
    "spawnhub-openai-agents is deprecated. Use `pip install spawnhub` and "
    "`from spawnhub import instrument` instead.",
    DeprecationWarning,
    stacklevel=2,
)

from spawnhub import instrument, SpawnHubTracingProcessor  # noqa: F401, E402

__all__ = ["instrument", "SpawnHubTracingProcessor"]
