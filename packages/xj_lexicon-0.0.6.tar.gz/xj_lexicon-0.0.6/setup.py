# encoding: utf-8
"""
@project: djangoModel->setup
@author: 赵向明
@Email: sieyoo@163.com
@synopsis: 俄语词典模块打包文件
@created_time: 2026/04/21 23:22
"""
from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf8') as fp:
    log_desc = fp.read()

setup(
    name='xj_lexicon',  # 模块名称
    version='0.0.6',  # 模块版本
    description='俄语词典模块',  # 项目摘要描述
    long_description=log_desc,  # 项目描述
    long_description_content_type="text/markdown",  # md文件，markdown格式
    author='赵向明',  # 作者
    author_email='sieyoo@163.com',  # 作者邮箱
    url='',  # 项目地址
    packages=find_packages(),  # 系统自动从当前目录开始找包
    # packages=['xj_lexicon'],  # 或指定安装模块
    license="apache 3.0",

    # Django版本依赖
    install_requires=[
        'Django>=3.2',
    ],

    # 包含数据文件
    include_package_data=True,

    # Python版本要求
    python_requires='>=3.7',

    # 分类信息
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: Apache Software License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Framework :: Django',
        'Framework :: Django :: 3.2',
        'Framework :: Django :: 4.0',
        'Framework :: Django :: 4.1',
    ],

    # 关键词
    keywords='django russian lexicon dictionary vocabulary',
)

"""
模块说明:
本模块提供俄语词典的Django模型定义,包含以下功能:
1. LexiconRoot - 俄语词根管理
2. LexiconCategory - 单词分类管理(支持树形结构)
3. LexiconWord - 俄语单词详细信息(包含词性、词根、释义、变位等)
4. LexiconRelation - 单词间关系(同义词、反义词、体配对等)

主要特性:
- 支持词根分析(最多3个词根)
- 多维度分类(分类、主题、等级、词频)
- 完整的语法信息(词性、性、数、体、格等)
- 丰富的学习资源(例句、搭配、音频)
- 词汇关系网络(同义、反义、派生等)
- JSONField支持复杂数据结构
- 完善的数据库索引优化查询性能
"""
