# admin.py
from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from import_export import resources, fields
from import_export.admin import ImportExportActionModelAdmin
from import_export.widgets import Widget
from import_export.formats import base_formats
from .models import LexiconRoot, LexiconCategory, LexiconWord, LexiconRelation, LexiconNote, LexiconWordbook, LexiconSentence, LexiconArticle
import json


class JSONStringWidget(Widget):
    """JSON 序列化为字符串（不转码）"""

    def render(self, value, obj=None, **kwargs):
        if value is None:
            return ''
        return json.dumps(value, ensure_ascii=False)

    def clean(self, value, row=None, **kwargs):
        if not value:
            return None
        try:
            return json.loads(value)
        except (ValueError, TypeError):
            return value


class RootWidget(Widget):
    """词根组件：支持通过词根字母导入导出，自动创建不存在的词根"""

    def clean(self, value, row=None, **kwargs):
        """导入时：根据词根字母获取或创建词根对象"""
        if not value or not value.strip():
            return None

        root_text = value.strip()
        root_obj, created = LexiconRoot.objects.get_or_create(root=root_text, defaults={'meaning': '', 'desc': ''})
        return root_obj

    def render(self, value, obj=None, **kwargs):
        """导出时：返回词根字母而不是ID"""
        if value is None:
            return ''
        return value.root


class CategoryWidget(Widget):
    """分类组件：支持通过分类编码导入导出，自动创建不存在的分类"""

    def clean(self, value, row=None, **kwargs):
        """导入时：根据分类编码获取或创建分类对象"""
        if not value or not value.strip():
            return None

        code = value.strip()
        name = code.replace('_', ' ')
        category_obj, created = LexiconCategory.objects.get_or_create(code=code, defaults={'name': name, 'sort': 100})
        return category_obj

    def render(self, value, obj=None, **kwargs):
        """导出时：返回分类编码（单词间用下划线分隔）而不是ID"""
        if value is None:
            return ''
        return value.code if value.code else ''


class UTF8BOMCSV(base_formats.CSV):
    """支持 UTF-8 BOM 的 CSV 格式（Excel 友好）"""

    def export_data(self, dataset, **kwargs):
        csv_data = super().export_data(dataset, **kwargs)
        return '\ufeff' + csv_data


class LexiconWordResource(resources.ModelResource):
    """单词导入导出资源配置"""
    root1 = fields.Field(column_name='root1', attribute='root1', widget=RootWidget())
    root2 = fields.Field(column_name='root2', attribute='root2', widget=RootWidget())
    root3 = fields.Field(column_name='root3', attribute='root3', widget=RootWidget())
    category = fields.Field(column_name='category_code', attribute='category', widget=CategoryWidget())
    meanings = fields.Field(column_name='meanings', attribute='meanings', widget=JSONStringWidget())
    forms = fields.Field(column_name='forms', attribute='forms', widget=JSONStringWidget())
    examples = fields.Field(column_name='examples', attribute='examples', widget=JSONStringWidget())
    collocations = fields.Field(column_name='collocations', attribute='collocations', widget=JSONStringWidget())

    class Meta:
        model = LexiconWord
        import_id_fields = ('id',)
        fields = ('id', 'lemma', 'accented', 'gloss', 'pos', 'pos_tags', 'aspect', 'gender', 'is_animacy', 'level', 'frequency', 'meanings', 'forms', 'examples', 'collocations', 'index_words', 'root1', 'root2', 'root3', 'category', 'create_time')
        export_order = fields
        skip_unchanged = True
        report_skipped = True


@admin.register(LexiconCategory)
class LexiconCategoryAdmin(admin.ModelAdmin):
    """单词分类管理"""

    class SubCategoryInline(admin.TabularInline):
        model = LexiconCategory
        fk_name = 'parent'
        fields = ['name', 'code', 'sort']
        extra = 0
        verbose_name = '子分类'
        verbose_name_plural = '子分类列表'

    inlines = [SubCategoryInline]
    fields = ('id', 'name', 'code', 'parent', 'sort')
    list_display = ('id', 'name', 'code', 'parent', 'sort', 'word_count', 'children_count')
    list_filter = ['parent']
    list_display_links = ['id', 'name']
    search_fields = ('id', 'name', 'code')
    raw_id_fields = ['parent']
    readonly_fields = ('id',)
    ordering = ['parent', 'sort', 'name']
    list_per_page = 20

    def word_count(self, obj):
        """递归统计当前分类及所有子分类的单词总数"""

        def count_recursive(category):
            # 当前分类的单词数
            total = category.lexicons.count()
            # 递归累加所有子分类的单词数
            for child in category.children.all():
                total += count_recursive(child)
            return total

        return count_recursive(obj)

    word_count.short_description = '单词数量（含子分类）'

    def children_count(self, obj):
        return obj.children.count()

    children_count.short_description = '子分类数量'


@admin.register(LexiconRoot)
class LexiconRootAdmin(admin.ModelAdmin):
    """词根管理"""
    fields = ('id', 'root', 'meaning', 'desc')
    list_display = ('id', 'root', 'meaning', 'desc', 'word_count')
    list_display_links = ['id', 'root']
    search_fields = ('id', 'root', 'meaning', 'desc')
    readonly_fields = ('id',)
    ordering = ['root']
    list_per_page = 20

    def word_count(self, obj):
        return obj.word_root1.count() + obj.word_root2.count() + obj.word_root3.count()

    word_count.short_description = '单词数量'


@admin.register(LexiconWord)
class LexiconWordAdmin(ImportExportActionModelAdmin):
    """俄语单词管理（支持导入导出）"""
    resource_class = LexiconWordResource
    export_action_description = "导出所选的 %(verbose_name_plural)s"

    class LexiconRelationInline(admin.TabularInline):
        model = LexiconRelation
        fk_name = 'from_word'
        fields = ['to_word', 'relation_type']
        raw_id_fields = ['to_word']
        extra = 0
        verbose_name = '词汇关系'
        verbose_name_plural = '词汇关系（同义词、反义词等）'

    inlines = [LexiconRelationInline]
    fieldsets = [
        ('基本信息', {'fields': ('id', ('lemma', 'accented'), 'gloss', ('root1', 'root2', 'root3'), ('category', 'level', 'frequency'), 'index_words')}),
        ('语法信息', {'fields': (('pos', 'pos_tags'), ('aspect', 'gender', 'is_animacy'))}),
        ('详细信息', {'fields': ('meanings', 'forms', 'examples', 'collocations')}),
        ('时间信息', {'fields': ('create_time',)})
    ]
    list_display = ('id', 'lemma_display', 'accented', 'gloss_display', 'pos', 'pos_tags', 'aspect', 'gender', 'level', 'frequency', 'category', 'roots_display', 'create_time')
    list_filter = ['pos', 'aspect', 'gender', 'level', 'category', 'create_time']
    list_display_links = ['id', 'lemma_display']
    search_fields = ('id', 'lemma', 'accented', 'gloss', 'index_words')
    raw_id_fields = ['root1', 'root2', 'root3', 'category']
    readonly_fields = ('id', 'create_time')
    ordering = ['id']
    list_per_page = 100

    def get_export_formats(self):
        """返回导出格式列表"""
        formats = (UTF8BOMCSV, base_formats.JSON)
        return [f for f in formats if f().can_export()]

    def get_import_formats(self):
        """返回导入格式列表"""
        formats = (base_formats.CSV, base_formats.JSON)
        return [f for f in formats if f().can_import()]

    def get_list_filter(self, request):
        return list(self.list_filter) + ['root1', 'root2', 'root3']

    def lemma_display(self, obj):
        return format_html('<strong>{}</strong>', obj.lemma)

    lemma_display.short_description = '单词原形'
    lemma_display.admin_order_field = 'lemma'

    def gloss_display(self, obj):
        if not obj.gloss:
            return '-'
        return f"{obj.gloss[:30]}..." if len(obj.gloss) > 30 else obj.gloss

    gloss_display.short_description = '简明释义'

    def roots_display(self, obj):
        roots = []
        for root_field in [obj.root1, obj.root2, obj.root3]:
            if not root_field:
                continue
            url = reverse('admin:xj_lexicon_lexiconroot_change', args=[root_field.id])
            roots.append(format_html('<a href="{}">{}</a>', url, root_field.root))
        return format_html(' + '.join(roots)) if roots else '-'

    roots_display.short_description = '词根'


@admin.register(LexiconRelation)
class LexiconRelationAdmin(admin.ModelAdmin):
    """词汇关系管理"""
    list_display = ('id', 'from_word', 'to_word', 'relation_type')
    list_filter = ['relation_type']
    search_fields = ('from_word__lemma', 'to_word__lemma')
    raw_id_fields = ['from_word', 'to_word']
    list_per_page = 20


@admin.register(LexiconWordbook)
class LexiconWordbookAdmin(admin.ModelAdmin):
    """词集管理"""
    fields = ('id', 'name', 'description', 'cover', 'press', 'books', 'create_time', 'update_time')
    list_display = ('id', 'name', 'cover_display', 'description_short', 'press', 'books_count', 'update_time')
    list_filter = ['press', 'create_time', 'update_time']
    list_display_links = ['id', 'name']
    search_fields = ('id', 'name', 'description', 'press')
    readonly_fields = ('id', 'create_time', 'update_time')
    ordering = ['-update_time']
    list_per_page = 20
    def cover_display(self, obj):
        """封面图片展示"""
        if not obj.cover:
            return '-'
        # 如果是图片URL，显示缩略图
        if obj.cover.startswith('http://') or obj.cover.startswith('https://'):
            return format_html(
                '<a href="{}" target="_blank"><img src="{}" style="width: 50px; height: 70px; object-fit: cover; border-radius: 4px;" /></a>',
                obj.cover, obj.cover
            )
        # 如果是相对路径或其他格式，显示链接
        return format_html('<a href="{}" target="_blank">查看封面</a>', obj.cover)
    cover_display.short_description = '封面'
    def description_short(self, obj):
        """描述信息展示（截断）"""
        if not obj.description:
            return '-'
        return f"{obj.description[:30]}..." if len(obj.description) > 30 else obj.description
    description_short.short_description = '描述'
    def books_count(self, obj):
        """词集单词数"""
        count = len(obj.books) if obj.books else 0
        if count > 0:
            return format_html('<span style="color: blue; font-weight: bold;">{}</span>', count)
        return count
    books_count.short_description = '单词数'


@admin.register(LexiconNote)
class LexiconNoteAdmin(admin.ModelAdmin):
    """词典笔记管理"""
    fields = ('id', 'user_id', 'user_uuid', 'knowns', 'match', 'remark', 'create_time', 'update_time')
    list_display = ('id', 'user_display', 'knowns_count', 'known_2_count', 'known_1_count', 'known_0_count', 'match_count', 'remark_short', 'update_time')
    list_display_links = ['id', 'user_display']
    search_fields = ('id', 'user_id', 'user_uuid', 'remark')
    readonly_fields = ('id', 'create_time', 'update_time')
    ordering = ['-update_time']
    list_per_page = 20
    def user_display(self, obj):
        """用户信息展示"""
        if obj.user_id:
            return format_html('<strong>用户#{}</strong>', obj.user_id)
        elif obj.user_uuid:
            return format_html('<code>{}</code>', str(obj.user_uuid)[:13])
        return '-'
    user_display.short_description = '用户'
    user_display.admin_order_field = 'user_id'
    def knowns_count(self, obj):
        """总记录单词数"""
        knowns_dict = obj.knowns or {}
        count = len(knowns_dict)
        if count > 0:
            return format_html('<span style="font-weight: bold;">{}</span>', count)
        return count
    knowns_count.short_description = '总记录数'
    def known_2_count(self, obj):
        """已掌握单词数 (known >= 2)"""
        knowns_dict = obj.knowns or {}
        count = sum(1 for v in knowns_dict.values() if int(v) >= 2)
        if count > 0:
            return format_html('<span style="color: green; font-weight: bold;">{}</span>', count)
        return count
    known_2_count.short_description = '已掌握(≥2)'
    def known_1_count(self, obj):
        """模糊单词数 (known = 1)"""
        knowns_dict = obj.knowns or {}
        count = sum(1 for v in knowns_dict.values() if int(v) == 1)
        if count > 0:
            return format_html('<span style="color: orange; font-weight: bold;">{}</span>', count)
        return count
    known_1_count.short_description = '模糊(=1)'
    def known_0_count(self, obj):
        """不认识单词数 (known = 0)"""
        knowns_dict = obj.knowns or {}
        count = sum(1 for v in knowns_dict.values() if int(v) == 0)
        if count > 0:
            return format_html('<span style="color: red; font-weight: bold;">{}</span>', count)
        return count
    known_0_count.short_description = '不认识(=0)'
    def match_count(self, obj):
        """消消乐单词数"""
        count = len(obj.match) if obj.match else 0
        if count > 0:
            return format_html('<span style="color: purple; font-weight: bold;">{}</span>', count)
        return count
    match_count.short_description = '消消乐'
    def remark_short(self, obj):
        """备注信息展示（截断）"""
        if not obj.remark:
            return '-'
        # 超过 20 个字符截断
        if len(obj.remark) > 20:
            return format_html('<span title="{}">{}</span>', obj.remark, obj.remark[:20] + '...')
        return obj.remark
    remark_short.short_description = '备注'
    remark_short.admin_order_field = 'remark'


class LexiconSentenceInline(admin.TabularInline):
    """文章句子内联（在文章详情页展示句子列表）"""
    model = LexiconSentence
    fields = ['section_order', 'paragraph_order', 'sentence_order', 'russian', 'chinese', 'level']
    extra = 0
    ordering = ['section_order', 'paragraph_order', 'sentence_order']
    verbose_name = '句子'
    verbose_name_plural = '句子列表'
    show_change_link = True  # 行末显示「修改」链接，可跳转到句子详情页


# ==================== LexiconArticle ====================

@admin.register(LexiconArticle)
class LexiconArticleAdmin(admin.ModelAdmin):
    """俄语文章管理"""

    inlines = [LexiconSentenceInline]

    fieldsets = [
        # ===== 标题信息 =====
        ('标题信息', {'fields': ('id', 'title', 'meaning', 'rendering', 'title_accented')}),
        # ===== 作者信息 =====
        ('作者信息', {'fields': (('author_russian', 'author_chinese'),)}),
        # ===== 内容分析 =====
        ('内容分析', {'fields': ('article_analysis', 'qa')}),
        # ===== 分类信息 =====
        ('分类信息', {'fields': (('category_code', 'article_source'),)}),
        # ===== 时间信息 =====
        ('时间信息', {'fields': (('create_time', 'update_time'),)}),
    ]
    list_display = ('id', 'title_display', 'meaning_short', 'author_russian', 'author_chinese', 'category_code', 'article_source', 'sentence_count', 'create_time')
    list_filter = ['category_code', 'article_source', 'create_time']
    list_display_links = ['id', 'title_display']
    search_fields = ('id', 'title', 'meaning', 'rendering', 'author_russian', 'author_chinese', 'category_code', 'article_source')
    readonly_fields = ('id', 'create_time', 'update_time')
    ordering = ['-create_time']
    list_per_page = 20

    def title_display(self, obj):
        """文章标题展示（截断）"""
        text = obj.title[:60] + '...' if len(obj.title) > 60 else obj.title
        return format_html('<strong>{}</strong>', text)

    title_display.short_description = '文章标题'
    title_display.admin_order_field = 'title'

    def meaning_short(self, obj):
        """释义展示（截断）"""
        if not obj.meaning:
            return '-'
        return obj.meaning[:30] + '...' if len(obj.meaning) > 30 else obj.meaning

    meaning_short.short_description = '释义'

    def sentence_count(self, obj):
        """句子总数（可点击跳转筛选列表）"""
        count = obj.get_sentence_count()
        if count > 0:
            url = reverse('admin:xj_lexicon_lexiconsentence_changelist') + f'?article__id__exact={obj.pk}'
            return format_html('<a href="{}" style="color: blue; font-weight: bold;">{} 句</a>', url, count)
        return format_html('<span style="color: #ccc;">0 句</span>')

    sentence_count.short_description = '句子数'


# ==================== LexiconSentence ====================

@admin.register(LexiconSentence)
class LexiconSentenceAdmin(admin.ModelAdmin):
    """词典句子管理"""

    fieldsets = [
        # ===== 所属文章 =====
        ('所属文章', {'fields': ('article', ('section_order', 'paragraph_order', 'sentence_order'))}),
        # ===== 基本信息 =====
        ('基本信息', {'fields': ('russian', 'chinese', 'russian_accented', 'grammar_analysis')}),
        # ===== 分类信息 =====
        ('分类信息', {'fields': (('level', 'source'),)}),
        # ===== 时间信息 =====
        ('时间信息', {'fields': (('create_time', 'update_time'),)}),
    ]
    list_display = ['id', 'article_link', 'position_display', 'russian_short', 'chinese_short', 'level', 'source', 'create_time']
    list_filter = ['level', 'source', 'create_time', 'article']
    search_fields = ['russian', 'chinese', 'russian_accented', 'grammar_analysis']
    readonly_fields = ['create_time', 'update_time']
    list_display_links = ['id', 'russian_short']
    raw_id_fields = ['article']
    ordering = ['article', 'section_order', 'paragraph_order', 'sentence_order']
    list_per_page = 50

    def article_link(self, obj):
        """所属文章（可跳转到文章详情）"""
        if not obj.article:
            return '-'
        url = reverse('admin:xj_lexicon_lexiconarticle_change', args=[obj.article.pk])
        title = obj.article.title[:20] + '...' if len(obj.article.title) > 20 else obj.article.title
        return format_html('<a href="{}">{}</a>', url, title)

    article_link.short_description = '所属文章'
    article_link.admin_order_field = 'article'

    def position_display(self, obj):
        """章节-段落-句子 三级序号"""
        return format_html('<span style="color: #666; font-size: 12px;">{}-{}-{}</span>', obj.section_order or 0, obj.paragraph_order or 0, obj.sentence_order or 0)

    position_display.short_description = '位置'
    position_display.admin_order_field = 'section_order'

    def russian_short(self, obj):
        """显示俄语句子（截断）"""
        return obj.russian[:50] + '...' if len(obj.russian) > 50 else obj.russian

    russian_short.short_description = '俄语句子'

    def chinese_short(self, obj):
        """显示中文翻译（截断）"""
        return obj.chinese[:30] + '...' if len(obj.chinese) > 30 else obj.chinese

    chinese_short.short_description = '中文翻译'
