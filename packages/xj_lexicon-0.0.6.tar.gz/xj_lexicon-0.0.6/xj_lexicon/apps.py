from django.apps import AppConfig


class LexiconConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'xj_lexicon'
    verbose_name = 'Ⅲ 俄语词典'
    sort = 13
