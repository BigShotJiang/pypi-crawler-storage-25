# encoding: utf-8
"""
@project: lexicon_word_api
@author:
@Email:
@synopsis: 词典单词详情API接口
@created_time: 2026
"""

from rest_framework.views import APIView

from ..services.lexicon_word_service import LexiconWordService
from ..utils.custom_response import util_response
from ..utils.request_params_wrapper import request_params_wrapper


class LexiconWordAPI(APIView):
    """
    词典单词详情API：单词详情查询

    @description
    - 支持按 ID 查询
    - 支持按 lemma（单词原形）查询
    - 返回完整的单词信息（词根、分类、词汇关系等）
    """

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        """
        获取单词详情

        @param word_id: 单词ID（优先使用）
        @param lemma: 单词原形（当 word_id 不存在时使用）

        @example
        GET /api/lexicon/word/?id=1
        GET /api/lexicon/word/?lemma=работа

        @return
        {
            "err": 0,
            "data": {
                "id": 1,
                "lemma": "работа",
                "accented": "рабо́та",
                "gloss": "工作；作品",
                "pos": "n",
                "pos_display": "名词",
                "roots": [...],
                "relations": {...},
                ...
            }
        }

        @error_codes
        - 8511: 缺少查询参数
        - 8512: 单词不存在
        - 8513: 查询失败
        """

        # 调用 Service 层
        data, error = LexiconWordService.item(
            word_id=request_params.get('id'),
            lemma=request_params.get('lemma')
        )
        if error:
            return util_response(data=data, msg=error)

        # 返回响应
        return util_response(data=data)