# encoding: utf-8
"""
@project: lexicon_article_detail_api
@synopsis: 词典文章详情API接口
"""
from rest_framework.views import APIView
from ..services.lexicon_article_service import LexiconArticleService
from ..utils.custom_response import util_response
from ..utils.request_params_wrapper import request_params_wrapper


class LexiconArticleAPI(APIView):

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        data, error = LexiconArticleService.detail(article_id=request_params.get('id'))
        if error:
            return util_response(data=data, msg=error)
        return util_response(data=data)