# encoding: utf-8
"""
@project: lexicon_note_api
@author:
@Email:
@synopsis: 词典笔记API接口
@created_time: 2026
"""
import sys

from rest_framework.views import APIView
from ..services.lexicon_note_service import LexiconNoteService
from ..utils.custom_response import util_response
from ..utils.j_transform_type import JTransformType


class LexiconNoteAPI(APIView):
    """词典笔记API：添加单词到学习笔记"""

    def post(self, request, *args, **kwargs):
        """批量添加或更新单词掌握状态"""
        # ========== 用户令牌验证 ==========
        token = request.headers.get('Authorization')

        if 'xj_user' in sys.modules:
            from xj_user.services.user_service import UserService
            token_serv, error_text = UserService.check_token(token)
            if error_text:
                return util_response(err=6045, msg=error_text)
            token_user_uuid = token_serv.get('user_uuid', None)
            token_user_id = token_serv.get('user_id', None)
        else:
            return util_response(err=6046, msg="用户模块未安装")

        # ========== 解析请求参数 ==========
        request_params = request.data if hasattr(request, 'data') else {}

        # ========== 获取用户标识（参数优先） ==========
        user_uuid = request_params.get('user_uuid') or token_user_uuid
        user_id, _ = JTransformType.to(request_params.get('user_id'), "int", token_user_id)

        # ========== 获取 knowns 批量操作参数 ==========
        knowns, _ = JTransformType.to(request_params.get('knowns'), "dict", None)

        # ========== 调用服务层 ==========
        data, error_text = LexiconNoteService.add(
            user_uuid=user_uuid,
            user_id=user_id,
            knowns=knowns
        )

        if not error_text:
            return util_response(data=data)

        return util_response(err=9503, msg=error_text)


class LexiconNoteKnownListAPI(APIView):
    """按掌握程度筛选单词ID列表"""

    def get(self, request, *args, **kwargs):
        """获取指定掌握程度的单词ID列表"""
        # ========== 用户令牌验证 ==========
        token = request.headers.get('Authorization')

        if 'xj_user' in sys.modules:
            from xj_user.services.user_service import UserService
            token_serv, error_text = UserService.check_token(token)
            if error_text:
                return util_response(err=6045, msg=error_text)
            token_user_uuid = token_serv.get('user_uuid', None)
            token_user_id = token_serv.get('user_id', None)
        else:
            return util_response(err=6046, msg="用户模块未安装")

        # ========== 解析请求参数 ==========
        request_params = request.query_params if hasattr(request, 'query_params') else {}

        # ========== 获取用户标识 ==========
        user_uuid = request_params.get('user_uuid') or token_user_uuid
        user_id, _ = JTransformType.to(request_params.get('user_id'), "int", token_user_id)

        # ========== 获取掌握程度参数 ==========
        known, _ = JTransformType.to(request_params.get('known'), "int", None)
        max_known, _ = JTransformType.to(request_params.get('max_known'), "int", None)

        # ========== 调用服务层 ==========
        data, error_text = LexiconNoteService.known_list(user_uuid=user_uuid, user_id=user_id, known=known, max_known=max_known)

        if not error_text:
            return util_response(data={'word_ids': data, 'count': len(data)})

        return util_response(err=9504, msg=error_text)


class LexiconNoteStatisticAPI(APIView):
    """用户学习统计API"""

    def get(self, request, *args, **kwargs):
        """获取用户学习统计数据"""
        # ========== 用户令牌验证 ==========
        token = request.headers.get('Authorization')

        if 'xj_user' in sys.modules:
            from xj_user.services.user_service import UserService
            token_serv, error_text = UserService.check_token(token)
            if error_text:
                return util_response(err=6045, msg=error_text)
            token_user_uuid = token_serv.get('user_uuid', None)
            token_user_id = token_serv.get('user_id', None)
        else:
            return util_response(err=6046, msg="用户模块未安装")

        # ========== 解析请求参数 ==========
        request_params = request.query_params if hasattr(request, 'query_params') else {}

        # ========== 获取用户标识 ==========
        user_uuid = request_params.get('user_uuid') or token_user_uuid
        user_id, _ = JTransformType.to(request_params.get('user_id'), "int", token_user_id)

        # ========== 调用服务层 ==========
        data, error_text = LexiconNoteService.get_statistic(
            user_uuid=user_uuid,
            user_id=user_id
        )

        if not error_text:
            return util_response(data=data)

        return util_response(err=9505, msg=error_text)


class LexiconNoteKnownsByKeysAPI(APIView):
    """获取指定单词的掌握状态API"""
    def post(self, request, *args, **kwargs):
        """批量获取指定单词ID的掌握状态"""
        # ========== 用户令牌验证 ==========
        token = request.headers.get('Authorization')
        if 'xj_user' in sys.modules:
            from xj_user.services.user_service import UserService
            token_serv, error_text = UserService.check_token(token)
            if error_text:
                return util_response(err=6045, msg=error_text)
            token_user_uuid = token_serv.get('user_uuid', None)
            token_user_id = token_serv.get('user_id', None)
        else:
            return util_response(err=6046, msg="用户模块未安装")
        # ========== 解析请求参数 ==========
        request_params = request.data if hasattr(request, 'data') else {}
        # ========== 获取用户标识（参数优先） ==========
        user_uuid = request_params.get('user_uuid') or token_user_uuid
        user_id, _ = JTransformType.to(request_params.get('user_id'), "int", token_user_id)
        # ========== 获取 key_list 参数 ==========
        word_key_list, _ = JTransformType.to(request_params.get('word_key_list'), "list", None)
        # ========== 参数校验 ==========
        if not word_key_list:
            return util_response(err=9507, msg="key_list 参数不能为空")
        # ========== 调用服务层 ==========
        data, error_text = LexiconNoteService.get_knowns_by_keys(user_uuid=user_uuid, user_id=user_id, key_list=word_key_list)
        if not error_text:
            # 格式化返回数据
            result = {'knowns': data, 'count': len(data)}
            return util_response(data=result)
        return util_response(err=9507, msg=error_text)