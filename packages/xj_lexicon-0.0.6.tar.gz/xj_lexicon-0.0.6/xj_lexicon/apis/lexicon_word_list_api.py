# encoding: utf-8
"""
@project: lexicon_word_list_api
@author:
@Email:
@synopsis: 词典单词列表API接口 - 统一查询入口
@created_time: 2026
"""
from rest_framework.views import APIView
from ..services.lexicon_word_list_service import LexiconWordListService
from ..utils.custom_response import util_response
from ..utils.request_params_wrapper import request_params_wrapper


class LexiconWordListAPI(APIView):
    """
    词典单词列表API：统一查询入口
    @description
    支持多种查询场景：
    - ✅ 普通单词列表查询（按分类、词根、词性等）
    - ✅ 词集单词列表查询（wordbook_id）
    - ✅ 用户未掌握单词列表查询（user_id/user_uuid + known_filter）
    - ✅ 用户已掌握单词列表查询（known_status/known_min/known_max）
    - ✅ 支持多条件组合查询
    - ✅ 支持ID列表查询
    - ✅ 支持分页、排序
    """

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        """
        获取单词列表 - 统一查询接口
        # ===== 基础查询参数 =====
        @param page: 页码，默认1
        @param size: 每页数量，默认20（别名：page_size）
        @param sort: 排序字段，默认-create_time（别名：order_by）
                     可选值：id, -id, lemma, -lemma, frequency, -frequency, level, -level, create_time, -create_time
        @param search: 搜索关键词（单词原形、带重音词形、简明释义）
        @param id_list: 单词ID列表（逗号分隔或数组）
        # ===== 单词属性筛选 =====
        @param lemma: 单词原形（模糊查询）
        @param accented: 带重音词形（模糊查询）
        @param gloss: 简明释义（模糊查询）
        # ===== 分类词根筛选 =====
        @param category_id: 分类ID
        @param category_id_list: 分类ID列表（逗号分隔或数组）
        @param root_id: 词根ID（查询包含该词根的所有单词，包括root1/root2/root3）
        @param root1_id: 词根1 ID（精确查询）
        @param root2_id: 词根2 ID（精确查询）
        @param root3_id: 词根3 ID（精确查询）
        # ===== 词性特征筛选 =====
        @param pos: 基本词性（n=名词, v=动词, adj=形容词, adv=副词, pron=代词, prep=前置词, conj=连词, part=小品词, num=数词, interj=感叹词, phrase=固定短语）
        @param pos_list: 词性列表（逗号分隔或数组）
        @param aspect: 动词体（ipf=未完成体, pf=完成体, both=兼体）
        @param aspect_list: 动词体列表（逗号分隔或数组）
        @param gender: 性（m=阳性, f=阴性, n=中性, mf=共性）
        @param gender_list: 性列表（逗号分隔或数组）
        @param is_animacy: 是否动物名词（true/false）
        # ===== 等级词频筛选 =====
        @param level: 欧标等级（A1, A2, B1, B2, C1, C2）
        @param level_list: 欧标等级列表（逗号分隔或数组）
        @param frequency_min: 最小词频
        @param frequency_max: 最大词频
        # ===== 时间范围筛选 =====
        @param create_time_start: 创建开始时间（格式：YYYY-MM-DD 或 YYYY-MM-DD HH:MM:SS）
        @param create_time_end: 创建结束时间（格式：YYYY-MM-DD 或 YYYY-MM-DD HH:MM:SS）
        # ===== 词集查询（新增） =====
        @param wordbook_id: 词集ID（查询词集中的单词，可与其他条件组合）
        # ===== 用户笔记查询（新增） =====
        @param user_id: 用户ID（与 user_uuid 二选一）
        @param user_uuid: 用户UUID（与 user_id 二选一）
        @param known_filter: 掌握度快捷筛选（与用户ID配合使用）
                             - unknown: 未掌握（known < 1，即不在笔记中或known=0）
                             - known: 已掌握（known >= 2）
                             - half: 模糊（known = 1）
        @param known_status: 掌握度精确值（0=不认识, 1=模糊, 2=认识, 3-5=认识熟悉度）
        @param known_min: 掌握度最小值（区间查询，如 known_min=2 表示 known >= 2）
        @param known_max: 掌握度最大值（区间查询，如 known_max=5 表示 known <= 5）
        # ===== 使用示例 =====
        @example1 普通查询
        GET /api/lexicon/word_list/?page=1&size=20
        GET /api/lexicon/word_list/?category_id=1
        GET /api/lexicon/word_list/?root_id=5
        GET /api/lexicon/word_list/?pos=v&aspect=ipf&level=A1
        @example2 词集查询
        GET /api/lexicon/word_list/?wordbook_id=1
        GET /api/lexicon/word_list/?wordbook_id=1&pos=v&level=A1
        @example3 用户未掌握单词
        GET /api/lexicon/word_list/?user_id=123&known_filter=unknown
        GET /api/lexicon/word_list/?user_uuid=xxx&known_filter=unknown&level=A1
        @example4 用户已掌握单词
        GET /api/lexicon/word_list/?user_id=123&known_filter=known
        GET /api/lexicon/word_list/?user_id=123&known_filter=half&pos=v
        @example5 按掌握度精确查询
        GET /api/lexicon/word_list/?user_id=123&known_status=2
        GET /api/lexicon/word_list/?user_id=123&known_min=2&known_max=5
        @example6 组合查询
        GET /api/lexicon/word_list/?wordbook_id=1&user_id=123&known_filter=unknown&level=A1
        # 查询词集中用户未掌握的A1单词
        # ===== 返回格式 =====
        @return
        {
            "err": 0,
            "data": {
                "page": 1,
                "size": 20,
                "total": 150,
                "list": [...],

                # 以下字段根据查询场景动态返回：
                "category_id": 1,              # 当查询分类时返回
                "root_id": 5,                   # 当查询词根时返回
                "wordbook_id": 1,               # 当查询词集时返回
                "wordbook_name": "大学俄语1",   # 词集名称
                "wordbook_description": "...",  # 词集描述
                "wordbook_press": "外研社",     # 出版机构
                "user_id": 123,                 # 当查询用户笔记时返回
                "user_uuid": "xxx",             # 用户UUID
                "known_filter": "unknown",      # 掌握度筛选
                "excluded_count": 50,           # 排除的单词数量（仅 known_filter=unknown 时）
                "query": "SELECT ..."           # SQL查询语句（调试用）
            }
        }
        # ===== 返回的单词字段 =====
        list中每个单词包含：
        {
            "id": 1,
            "lemma": "работа",
            "accented": "рабо́та",
            "gloss": "工作",
            "pos": "n",
            "pos_display": "名词",
            "aspect": null,
            "aspect_display": null,
            "gender": "f",
            "gender_display": "阴性",
            "is_animacy": false,
            "level": "A1",
            "level_display": "A1",
            "frequency": 5000,
            "category_id": 1,
            "category_name": "日常词汇",
            "roots": [
                {"root": "работ", "meaning": "工作"}
            ],
            "meanings": {...},
            "forms": {...},
            "examples": [...],
            "collocations": [...],
            "create_time": "2024-01-01 00:00:00"
        }
        """
        # 调用 Service 层统一查询方法
        data, error = LexiconWordListService.list(query_params=request_params,page=request_params.get('page', 1),size=request_params.get('size', 20),sort=request_params.get('sort', '-create_time'))
        if error:
            return util_response(data=data, msg=error)
        # 返回响应
        return util_response(data=data)