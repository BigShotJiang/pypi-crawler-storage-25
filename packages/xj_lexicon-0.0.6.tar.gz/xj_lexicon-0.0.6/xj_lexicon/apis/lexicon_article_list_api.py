# encoding: utf-8
"""
@project: lexicon_article_list_api
@synopsis: 词典文章列表API接口
"""
from rest_framework.views import APIView
from ..services.lexicon_article_list_service import LexiconArticleListService
from ..utils.custom_response import util_response
from ..utils.request_params_wrapper import request_params_wrapper


class LexiconArticleListAPI(APIView):

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        """
        获取文章列表
        @param page: 页码，默认1
        @param size: 每页数量，默认20
        @param sort: 排序字段，默认-create_time
                     可选值：id, -id, title, -title, create_time, -create_time, update_time, -update_time
        @param search: 搜索关键词（标题模糊查询）
        @param category_code: 分类编码（精确查询）
        """
        data, error = LexiconArticleListService.list(
            query_params=request_params,
            page=request_params.get('page', 1),
            size=request_params.get('size', 20),
            sort=request_params.get('sort', '-create_time'),
        )
        if error:
            return util_response(data=data, msg=error)
        return util_response(data=data)