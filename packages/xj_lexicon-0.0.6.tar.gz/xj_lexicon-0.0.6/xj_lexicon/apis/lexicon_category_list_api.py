# encoding: utf-8
"""
@project: lexicon_category_list_api
@author:
@Email:
@synopsis: 词典分类列表API接口
@created_time: 2026
"""

from rest_framework.views import APIView

from ..services.lexicon_category_service import LexiconCategoryService
from ..utils.custom_response import util_response
from ..utils.request_params_wrapper import request_params_wrapper

class LexiconCategoryListAPI(APIView):
    """
    词典分类列表API：分类列表查询

    @description
    - 支持分页查询
    - 支持按父分类筛选
    - 支持按名称、编码查询
    - 可选统计单词数量
    """

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        """
        获取分类列表

        @param id: 分类ID（精确查询）
        @param name: 分类名称（模糊查询）
        @param code: 分类编码（精确查询）
        @param parent_id: 父分类ID（筛选子分类）
        @param id_list: ID列表（逗号分隔或数组）
        @param sort: 排序字段（可选：id, -id, sort, -sort, name, -name，默认：sort）
        @param page: 页码（默认：1）
        @param size: 每页数量（默认：20）
        @param need_pagination: 是否分页（默认：true）
        @param with_word_count: 是否统计单词数量（默认：false）
        @param filter_fields: 返回字段（逗号分隔，默认全部）

        @example
        GET /api/lexicon/category/list/?page=1&size=20
        GET /api/lexicon/category/list/?parent_id=1&with_word_count=true
        GET /api/lexicon/category/list/?need_pagination=false
        GET /api/lexicon/category/list/?id_list=1,2,3

        @return
        {
            "err": 0,
            "data": {
                "page": 1,
                "size": 20,
                "total": 50,
                "list": [
                    {
                        "id": 1,
                        "name": "日常生活",
                        "code": "daily_life",
                        "parent_id": null,
                        "parent_name": null,
                        "sort": 10,
                        "word_count": 150  // 仅当 with_word_count=true 时返回
                    }
                ]
            }
        }

        @return (不分页时)
        {
            "err": 0,
            "data": [
                {
                    "id": 1,
                    "name": "日常生活",
                    "code": "daily_life",
                    "parent_id": null,
                    "parent_name": null,
                    "sort": 10
                }
            ]
        }

        @error_codes
        - 8531: 查询参数错误
        - 8532: 查询失败
        """

        # 获取参数
        params = {
            'id': request_params.get('id'),
            'name': request_params.get('name'),
            'code': request_params.get('code'),
            'parent_id': request_params.get('parent_id'),
            'id_list': request_params.get('id_list'),
            'sort': request_params.get('sort'),
            'page': request_params.get('page'),
            'size': request_params.get('size'),
        }

        # 移除 None 值
        params = {k: v for k, v in params.items() if v is not None}

        # 分页控制
        need_pagination = request_params.get('need_pagination', True)
        if isinstance(need_pagination, str):
            need_pagination = need_pagination.lower() not in ('false', '0', 'no')

        # 单词数量统计
        with_word_count = request_params.get('with_word_count', False)
        if isinstance(with_word_count, str):
            with_word_count = with_word_count.lower() in ('true', '1', 'yes')

        # 字段过滤
        filter_fields = request_params.get('filter_fields')

        try:
            # 调用 Service 层
            data, error = LexiconCategoryService.list(params=params, filter_fields=filter_fields, need_pagination=need_pagination, with_word_count=with_word_count)

            # 错误处理
            if error:
                return util_response(data=None, msg=error)

            # 返回响应
            return util_response(data=data, msg="ok")

        except Exception as e:
            return util_response(data=None, err=8532, msg=f"查询分类列表失败：{str(e)}")