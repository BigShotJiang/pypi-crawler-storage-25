# encoding: utf-8
"""
@project: lexicon_wordbook_api
@author:
@Email:
@synopsis: 词典词集API接口
@created_time: 2026
"""

from rest_framework.views import APIView
from ..services.lexicon_wordbook_service import LexiconWordbookService
from ..utils.custom_response import util_response
from ..utils.j_transform_type import JTransformType


class LexiconWordbookListAPI(APIView):
    """词典词集列表API"""

    def get(self, request, *args, **kwargs):
        """获取词集列表（分页）"""
        # ========== 解析请求参数 ==========
        request_params = request.query_params if hasattr(request, 'query_params') else {}

        # ========== 获取分页参数 ==========
        page, _ = JTransformType.to(request_params.get('page'), "int", 1)
        size, _ = JTransformType.to(request_params.get('size'), "int", 20)
        sort = request_params.get('sort', '-update_time')

        # ========== 获取ID列表参数 ==========
        id_list_str = request_params.get('id_list')
        id_list = None
        if id_list_str:
            try:
                id_list = [int(x.strip()) for x in id_list_str.split(',') if x.strip()]
            except ValueError:
                return util_response(err=9601, msg="id_list 格式错误，应为逗号分隔的整数")

        # ========== 构建查询参数 ==========
        query_params = {
            'search': request_params.get('search'),
            'name': request_params.get('name'),
            'description': request_params.get('description'),
            'press': request_params.get('press'),
            'create_time_start': request_params.get('create_time_start'),
            'create_time_end': request_params.get('create_time_end'),
            'update_time_start': request_params.get('update_time_start'),
            'update_time_end': request_params.get('update_time_end'),
        }

        # 移除空值
        query_params = {k: v for k, v in query_params.items() if v is not None}

        # ========== 调用服务层 ==========
        data, error_text = LexiconWordbookService.word_list(id_list=id_list, query_params=query_params, page=page, size=size, sort=sort)

        if not error_text:
            return util_response(data=data)

        return util_response(err=9602, msg=error_text)