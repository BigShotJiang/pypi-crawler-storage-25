# encoding: utf-8
from django.db import models
from .utils.j_ulid_field import JULIDField


class LexiconCategory(models.Model):
    """单词分类"""
    name = models.CharField(max_length=100, unique=True, db_index=True, verbose_name="分类名称")
    code = models.CharField(max_length=50, unique=True, blank=True, null=True, db_index=True, verbose_name="分类编码")
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.SET_NULL, db_constraint=False, related_name="children", verbose_name="父分类")
    sort = models.PositiveSmallIntegerField(default=100, blank=True, null=True, db_index=True, verbose_name="排序")

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'lexicon_category'
        verbose_name = "单词分类"
        verbose_name_plural = "01. 词典 - 分类"
        ordering = ["sort", "name"]


class LexiconRoot(models.Model):
    """俄语词根"""
    root = models.CharField(max_length=100, unique=True, db_index=True, verbose_name="俄语词根")
    meaning = models.CharField(max_length=255, blank=True, null=True, verbose_name="词根含义")
    desc = models.CharField(max_length=255, blank=True, null=True, verbose_name="备注说明")

    def __str__(self):
        return self.root

    class Meta:
        db_table = 'lexicon_root'
        verbose_name = "俄语词根"
        verbose_name_plural = "02. 词典 - 词根"


class LexiconWordManager(models.Manager):
    def by_root(self, root):
        """根据词根查询单词"""
        return self.filter(models.Q(root1=root) | models.Q(root2=root) | models.Q(root3=root))


class LexiconWord(models.Model):
    """俄语单词"""
    lemma = models.CharField(max_length=255, db_index=True, verbose_name="单词原形")
    accented = models.CharField(max_length=255, blank=True, null=True, db_index=True, verbose_name="带重音词形")
    root1 = models.ForeignKey(LexiconRoot, on_delete=models.SET_NULL, null=True, blank=True, db_constraint=False, db_index=True, related_name="word_root1", verbose_name="词根1")
    root2 = models.ForeignKey(LexiconRoot, on_delete=models.SET_NULL, null=True, blank=True, db_constraint=False, db_index=True, related_name="word_root2", verbose_name="词根2")
    root3 = models.ForeignKey(LexiconRoot, on_delete=models.SET_NULL, null=True, blank=True, db_constraint=False, db_index=True, related_name="word_root3", verbose_name="词根3")
    category = models.ForeignKey(LexiconCategory, on_delete=models.SET_NULL, null=True, blank=True, db_constraint=False, db_index=True, related_name="lexicons", verbose_name="单词分类")

    POS_CHOICES = [
        ("n", "名词"), ("v", "动词"), ("adj", "形容词"), ("adv", "副词"), ("pron", "代词"),
        ("prep", "前置词"), ("conj", "连词"), ("part", "小品词"), ("num", "数词"),
        ("interj", "感叹词"), ("phrase", "固定短语")
    ]
    pos = models.CharField(max_length=20, blank=True, null=True, choices=POS_CHOICES, db_index=True, verbose_name="基本词性", help_text="主要词性，用于分类检索")
    pos_tags = models.CharField(max_length=100, blank=True, null=True, db_index=True, verbose_name="多词性标签", help_text="逗号分隔，如：n,v")

    ASPECT_CHOICES = [("ipf", "未完成体"), ("pf", "完成体"), ("both", "兼体")]
    aspect = models.CharField(max_length=10, blank=True, null=True, choices=ASPECT_CHOICES, db_index=True, verbose_name="动词体")

    GENDER_CHOICES = [("m", "阳性"), ("f", "阴性"), ("n", "中性"), ("mf", "共性")]
    gender = models.CharField(max_length=5, blank=True, null=True, choices=GENDER_CHOICES, db_index=True, verbose_name="性")

    is_animacy = models.BooleanField(null=True, blank=True, verbose_name="是否动物名词")

    gloss = models.CharField(max_length=512, blank=True, null=True, db_index=True, verbose_name="简明释义")
    meanings = models.JSONField(default=dict, blank=True, null=True, verbose_name="全部释义", help_text="JSON格式存储多个释义")
    forms = models.JSONField(default=dict, blank=True, null=True, verbose_name="变格变位", help_text="JSON格式存储词形变化")
    index_words = models.CharField(max_length=2000, blank=True, null=True, db_index=True, verbose_name="全部变形合集", help_text="逗号分隔，用于检索")

    examples = models.JSONField(default=list, blank=True, null=True, verbose_name="例句", help_text="JSON格式存储俄+中例句")
    collocations = models.JSONField(default=list, blank=True, null=True, verbose_name="固定搭配", help_text="JSON格式存储搭配")

    CEFR_CHOICES = [("A1", "A1"), ("A2", "A2"), ("B1", "B1"), ("B2", "B2"), ("C1", "C1"), ("C2", "C2"), ("LET", "Letter"), ("OTH", "Other")]
    level = models.CharField(max_length=5, blank=True, null=True, choices=CEFR_CHOICES, db_index=True, verbose_name="欧标等级")
    frequency = models.IntegerField(null=True, blank=True, db_index=True, verbose_name="词频")

    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="创建时间")

    objects = LexiconWordManager()

    class Meta:
        db_table = 'lexicon_word'
        verbose_name = "俄语单词"
        verbose_name_plural = "03. 词典 - 单词"
        ordering = ["lemma"]

    def __str__(self):
        return f"{self.lemma} | {self.gloss or ''}"


class LexiconRelation(models.Model):
    """词汇关系"""
    REL_CHOICES = [
        ("aspect", "体配对"), ("synonym", "同义词"), ("near_syn", "近义词"),
        ("antonym", "反义词"), ("related", "相关词"), ("derivative", "派生词")
    ]
    from_word = models.ForeignKey(LexiconWord, on_delete=models.CASCADE, db_constraint=False, db_index=True, related_name="relations_out", verbose_name="源单词")
    to_word = models.ForeignKey(LexiconWord, on_delete=models.CASCADE, db_constraint=False, db_index=True, related_name="relations_in", verbose_name="目标单词")
    relation_type = models.CharField(max_length=20, choices=REL_CHOICES, db_index=True, verbose_name="关系类型")

    class Meta:
        db_table = 'lexicon_relation'
        verbose_name = "词汇关系"
        verbose_name_plural = "04. 词典 - 词汇关系"
        unique_together = ("from_word", "to_word", "relation_type")

    def __str__(self):
        return f"{self.from_word.lemma} → {self.to_word.lemma} ({self.get_relation_type_display()})"


class LexiconWordbook(models.Model):
    """词典词集 - 单词集合本"""
    name = models.CharField(max_length=255, db_index=True, verbose_name="词集名")
    books = models.JSONField(default=list, blank=True, null=True, verbose_name="词集", help_text="词集，JSON数组")
    description = models.CharField(max_length=1024, db_index=True, verbose_name="描述")
    cover = models.CharField(max_length=1024, blank=True, null=True, verbose_name='封面', help_text='')
    press = models.CharField(max_length=255, db_index=True, blank=True, null=True, verbose_name="出版机构")
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="创建时间")
    update_time = models.DateTimeField(auto_now=True, db_index=True, verbose_name="更新时间")

    class Meta:
        db_table = 'lexicon_wordbook'
        verbose_name = "词集"
        verbose_name_plural = "05. 词典 - 词集"
        ordering = ['-update_time']


class LexiconNote(models.Model):
    """词典笔记 - 用户单词学习记录"""
    user_id = models.BigIntegerField(verbose_name='用户ID', db_column='user_id', db_index=True, blank=True, null=True)
    user_uuid = JULIDField(verbose_name='用户UUID', editable=True, blank=True, null=True, db_index=True)
    knowns = models.JSONField(default=list, blank=True, null=True, verbose_name="已掌握单词", help_text="JSON对象，存储学过的LexiconWord ID，对象key=id，=0不认识，=1模糊，value=2认识，=2-5认识熟悉度")
    match = models.JSONField(default=list, blank=True, null=True, verbose_name="消消乐", help_text="JSON数组，存储LexiconWord的ID列表")
    remark = models.CharField(max_length=1024, blank=True, null=True, verbose_name="备注")
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="创建时间")
    update_time = models.DateTimeField(auto_now=True, db_index=True, verbose_name="更新时间")

    class Meta:
        db_table = 'lexicon_note'
        verbose_name = "用户笔记"
        verbose_name_plural = "05. 词典 - 用户笔记"
        ordering = ['-update_time']
        indexes = [
            models.Index(fields=['user_id']),
            models.Index(fields=['user_uuid']),
            models.Index(fields=['user_id', 'user_uuid']),
        ]

    def __str__(self):
        user_display = f"用户#{self.user_id}" if self.user_id else f"UUID:{str(self.user_uuid)[:8]}"
        return f"{user_display} - 笔记"

    def get_knowns_count(self):
        """获取已掌握单词数量"""
        return len(self.knowns) if self.knowns else 0


class LexiconArticle(models.Model):
    """俄语文章"""
    # ===== 标题信息 =====
    title = models.CharField(max_length=1024, db_index=True, verbose_name="文章标题")
    meaning = models.CharField(max_length=1024, blank=True, null=True, verbose_name="释义")
    rendering = models.CharField(max_length=1024, blank=True, null=True, verbose_name="意译")
    title_accented = models.CharField(max_length=2048, blank=True, null=True, verbose_name="带重音俄语标题（富文本）")

    # ===== 作者信息 =====
    author_russian = models.CharField(max_length=255, blank=True, null=True, db_index=True, verbose_name="作者俄语")
    author_chinese = models.CharField(max_length=255, blank=True, null=True, verbose_name="作者中文")

    # ===== 内容分析 =====
    article_analysis = models.TextField(blank=True, null=True, verbose_name="文章分析", help_text="文章分析")
    qa = models.JSONField(default=list, blank=True, null=True, verbose_name="文章问答", help_text="JSON数组，存储文章相关问答，如：[{'question': '...', 'answer': '...'}]")

    category_code = models.CharField(max_length=255, blank=True, null=True, db_index=True, verbose_name="类别编码")
    article_source = models.CharField(max_length=255, blank=True, null=True, db_index=True, verbose_name="文章来源")

    # ===== 时间信息 =====
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="创建时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="更新时间")

    class Meta:
        db_table = 'lexicon_article'
        verbose_name = "俄语文章"
        verbose_name_plural = "07. 词典 - 文章"
        ordering = ['-create_time']

    def __str__(self):
        return f"{self.title[:50]}"

    def get_sentence_count(self):
        """获取文章句子总数"""
        return self.sentences.count()


class LexiconSentence(models.Model):
    """词典句子"""
    # ===== 所属文章 =====
    article = models.ForeignKey(LexiconArticle, on_delete=models.SET_NULL, null=True, blank=True, db_constraint=False, db_index=True, related_name="sentences", verbose_name="所属文章")

    # ===== 位置序号 =====
    section_order = models.IntegerField(default=0, blank=True, null=True, db_index=True, verbose_name="章节序号", help_text="文章中的章节编号，从1开始")
    paragraph_order = models.IntegerField(default=0, blank=True, null=True, db_index=True, verbose_name="段落序号", help_text="章节内的段落编号，从1开始")
    sentence_order = models.IntegerField(default=0, blank=True, null=True, db_index=True, verbose_name="句子序号", help_text="段落内的句子编号，从1开始")

    # ===== 基本信息 =====
    russian = models.TextField(verbose_name="俄语句子", db_index=True)
    chinese = models.TextField(verbose_name="中文翻译", blank=True, null=True)
    russian_accented = models.TextField(blank=True, null=True, verbose_name="带重音俄语")
    grammar_analysis = models.TextField(blank=True, null=True, verbose_name="语法分析")

    # ===== 分类信息 =====
    LEVEL_CHOICES = [("A1", "A1"), ("A2", "A2"), ("B1", "B1"), ("B2", "B2"), ("C1", "C1"), ("C2", "C2")]
    level = models.CharField(max_length=5, blank=True, null=True, choices=LEVEL_CHOICES, db_index=True, verbose_name="难度等级")
    source = models.CharField(max_length=100, blank=True, null=True, db_index=True, verbose_name="来源")

    # ===== 时间信息 =====
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="创建时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="更新时间")

    class Meta:
        db_table = 'lexicon_sentence'
        verbose_name = "词典句子"
        verbose_name_plural = "06. 词典 - 句子"
        ordering = ['article', 'section_order', 'paragraph_order', 'sentence_order']
        indexes = [
            models.Index(fields=['level', 'source']),
            models.Index(fields=['article', 'section_order', 'paragraph_order', 'sentence_order']),
        ]

    def __str__(self):
        if self.article:
            return f"[{self.article.title[:20]}] {self.section_order}-{self.paragraph_order}-{self.sentence_order} {self.russian[:30]}..."
        return f"{self.russian[:50]}..."