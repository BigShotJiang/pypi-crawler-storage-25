# encoding: utf-8
"""
@project: LexiconWordbook Service
@synopsis: 词典词集服务层 - 单词集合本管理
@created_time: 2024
"""
import sys

from django.core.paginator import Paginator, EmptyPage
from django.db.models import Q, F

from ..models import LexiconWordbook, LexiconWord
from ..utils.j_transform_type import JTransformType
from ..utils.j_parameter import JParameter
from ..utils.custom_tool import format_params_handle


class LexiconWordbookService:
    """
    词典词集服务类 - 管理词集本
    """

    # 查询字段说明
    __support_queries = {
        "id": "词集ID",
        "id_list": "词集ID列表",
        "name": "词集名（模糊查询）",
        "description": "描述（模糊查询）",
        "press": "出版机构（模糊查询）",
        "search": "搜索关键词（名称、描述、出版机构）",
        "create_time_start|date": "创建开始时间",
        "create_time_end|date": "创建结束时间",
        "update_time_start|date": "更新开始时间",
        "update_time_end|date": "更新结束时间",
        "page": "页号，默认第1页",
        "size": "每页行数，默认20行",
        "sort": "排序字段，默认 -update_time",
        "filter_fields": "返回字段筛选",
    }

    # 所有字段
    all_fields = [
        "id",
        "name",
        "books",
        "description",
        "cover",
        "press",
        "create_time",
        "update_time",
    ]

    # 格式化字段
    format_fields = [
        "id|int",
        "name|str",
        "books|json",
        "description|str",
        "press|str",
        "cover|str",
        "create_time|date",
        "update_time|date",
    ]

    # 默认字段类型
    filter_filed_list = [
        "id|int",
        "id_list|list",
        "name|str",
        "description|str",
        "press|str",
        "create_time_start|date",
        "create_time_end|date",
        "update_time_start|date",
        "update_time_end|date",
    ]

    # 搜索条件映射
    __condition_alias = {
        "id_list": "id__in",
        "name": "name__icontains",
        "description": "description__icontains",
        "press": "press__icontains",
        "create_time_start": "create_time__gte",
        "create_time_end": "create_time__lte",
        "update_time_start": "update_time__gte",
        "update_time_end": "update_time__lte",
    }

    @staticmethod
    def word_list(id_list: list = None, query_params: dict = None, page: int = 1, size: int = 20,
                  sort: str = "-update_time"):
        """
        获取词集列表
        :param id_list: 词集ID列表
        :param query_params: 查询参数字典
        :param page: 页号
        :param size: 每页行数
        :param sort: 排序字段
        :return: (结果字典, 错误信息)

        @example
        query_params = {
            "name": "俄语",              # 模糊查询词集名
            "press": "外研社",           # 模糊查询出版机构
            "search": "基础",            # 搜索关键词
        }
        """
        # ========== 参数类型处理 ==========
        query_params, is_void = JTransformType.to(query_params, "dict", {})
        page, is_void = JTransformType.to(page, "int", 1)
        size, is_void = JTransformType.to(size, "int", 20)
        sort_param, is_void = JTransformType.to(sort, "str", "-update_time")

        if page < 1:
            page = 1
        if size < 1:
            size = 1
        if size > 200:
            size = 200

        sort_choices = [
            "id", "-id",
            "name", "-name",
            "press", "-press",
            "create_time", "-create_time",
            "update_time", "-update_time"
        ]
        if sort_param not in sort_choices:
            return None, f"排序字段无效，可选值：{'、'.join(sort_choices)}。"

        # ========== 基础查询 ==========
        book_set = LexiconWordbook.objects.all()

        # ========== 应用过滤条件 ==========
        if id_list and len(id_list) > 0:
            book_set = book_set.filter(id__in=id_list)

        # 处理搜索关键词
        search = query_params.pop("search", None)
        if search:
            search, is_void = JTransformType.to(search, "str")
            if search:
                book_set = book_set.filter(
                    Q(name__icontains=search) |
                    Q(description__icontains=search) |
                    Q(press__icontains=search)
                )

        # 处理其他查询参数
        conditions = format_params_handle(
            param_dict=query_params,
            filter_filed_list=LexiconWordbookService.filter_filed_list,
            alias_dict=LexiconWordbookService.__condition_alias,
            split_list=["id_list"],
            is_remove_empty=True
        )
        if conditions:
            book_set = book_set.filter(**conditions)

        # ========== 排序 ==========
        if sort_param.startswith('-'):
            book_set = book_set.order_by(sort_param, '-id')
        else:
            book_set = book_set.order_by(sort_param, 'id')

        # ========== 确定返回字段 ==========
        all_query_fields = list(LexiconWordbookService.all_fields)

        # ========== 使用 values() + distinct() 去重 ==========
        book_set = book_set.values(*all_query_fields).distinct()

        book_query = book_set.query

        # ========== 执行分页查询 ==========
        paginator = Paginator(book_set, per_page=size)
        total = paginator.count

        if page > paginator.num_pages and paginator.num_pages > 0:
            return {"page": page, "size": size, "total": total, "list": [], "query": str(book_query)}, None

        paginator_set = paginator.page(page) if total > 0 else []

        # ========== 导出分页结果 ==========
        if total > 0:
            main_list = list(paginator_set.object_list)

            # ✅ 格式化时间字段
            for item in main_list:
                if item.get('create_time') and hasattr(item['create_time'], 'strftime'):
                    item['create_time'] = item['create_time'].strftime("%Y-%m-%d %H:%M:%S")
                if item.get('update_time') and hasattr(item['update_time'], 'strftime'):
                    item['update_time'] = item['update_time'].strftime("%Y-%m-%d %H:%M:%S")

                # 统计词集中的单词数量
                if item.get('books'):
                    item['books_count'] = len(item['books'])
                else:
                    item['books_count'] = 0

                # 移除 books 字段
                item.pop('books', None)

        else:
            main_list = []

        result = {
            "page": int(page),
            "size": int(size),
            "total": total,
            "list": main_list,
            "query": str(book_query)
        }

        return result, None

    @staticmethod
    def book_list(wordbook_id: int = None, query_params: dict = None, page: int = 1, size: int = 20,
                  sort: str = "lemma"):
        """
        获取词集中的单词列表（通过 LexiconWordbook 查询 LexiconWord）
        :param wordbook_id: 词集ID（必填）
        :param query_params: 查询参数字典（可选，用于在词集内过滤单词）
        :param page: 页号
        :param size: 每页行数
        :param sort: 排序字段
        :return: (结果字典, 错误信息)
        """
        # ========== 参数类型处理 ==========
        wordbook_id, is_void = JTransformType.to(wordbook_id, "int")
        if not wordbook_id:
            return None, "词集ID不能为空"
        query_params, is_void = JTransformType.to(query_params, "dict", {})
        page, is_void = JTransformType.to(page, "int", 1)
        size, is_void = JTransformType.to(size, "int", 20)
        sort_param, is_void = JTransformType.to(sort, "str", "lemma")
        if page < 1:
            page = 1
        if size < 1:
            size = 1
        if size > 200:
            size = 200
        sort_choices = [
            "id", "-id",
            "lemma", "-lemma",
            "frequency", "-frequency",
            "level", "-level",
            "create_time", "-create_time"
        ]
        if sort_param not in sort_choices:
            return None, f"排序字段无效，可选值：{'、'.join(sort_choices)}。"
        try:
            # ========== 获取词集信息 ==========
            try:
                wordbook = LexiconWordbook.objects.get(id=wordbook_id)
            except LexiconWordbook.DoesNotExist:
                return None, f"词集(ID:{wordbook_id})不存在"
            # ========== 检查词集是否为空 ==========
            if not wordbook.books or len(wordbook.books) == 0:
                return {
                    "page": page,
                    "size": size,
                    "total": 0,
                    "list": [],
                    "wordbook_id": wordbook_id,
                    "wordbook_name": wordbook.name,
                    "wordbook_description": wordbook.description,
                    "wordbook_press": wordbook.press,
                    "query": ""
                }, None
            # ========== 基础查询：通过 books 字段中的 ID 列表查询单词 ==========
            word_set = LexiconWord.objects.filter(id__in=wordbook.books).select_related(
                'category', 'root1', 'root2', 'root3'
            )
            # ========== 应用过滤条件（在词集范围内） ==========
            # 处理搜索关键词
            search = query_params.pop("search", None)
            if search:
                search, is_void = JTransformType.to(search, "str")
                if search:
                    word_set = word_set.filter(
                        Q(lemma__icontains=search) |
                        Q(accented__icontains=search) |
                        Q(gloss__icontains=search)
                    )
            # 处理其他查询参数
            filter_conditions = {}

            # 单词原形
            lemma = query_params.get("lemma")
            if lemma:
                lemma, is_void = JTransformType.to(lemma, "str")
                if lemma:
                    filter_conditions["lemma__icontains"] = lemma
            # 词性
            pos = query_params.get("pos")
            if pos:
                pos, is_void = JTransformType.to(pos, "str")
                if pos:
                    filter_conditions["pos"] = pos
            # 词性列表
            pos_list = query_params.get("pos_list")
            if pos_list:
                pos_list, is_void = JTransformType.to(pos_list, "list")
                if pos_list:
                    filter_conditions["pos__in"] = pos_list
            # 欧标等级
            level = query_params.get("level")
            if level:
                level, is_void = JTransformType.to(level, "str")
                if level:
                    filter_conditions["level"] = level
            # 欧标等级列表
            level_list = query_params.get("level_list")
            if level_list:
                level_list, is_void = JTransformType.to(level_list, "list")
                if level_list:
                    filter_conditions["level__in"] = level_list
            # 词频范围
            frequency_min = query_params.get("frequency_min")
            if frequency_min:
                frequency_min, is_void = JTransformType.to(frequency_min, "int")
                if frequency_min is not None:
                    filter_conditions["frequency__gte"] = frequency_min
            frequency_max = query_params.get("frequency_max")
            if frequency_max:
                frequency_max, is_void = JTransformType.to(frequency_max, "int")
                if frequency_max is not None:
                    filter_conditions["frequency__lte"] = frequency_max
            # 应用过滤条件
            if filter_conditions:
                word_set = word_set.filter(**filter_conditions)
            # ========== 统计关联数据 ==========
            word_set = word_set.annotate(
                category_name=F('category__name'),
                root1_text=F('root1__root'),
                root1_meaning=F('root1__meaning'),
                root2_text=F('root2__root'),
                root2_meaning=F('root2__meaning'),
                root3_text=F('root3__root'),
                root3_meaning=F('root3__meaning'),
            )
            # ========== 排序 ==========
            if sort_param.startswith('-'):
                word_set = word_set.order_by(sort_param, '-id')
            else:
                word_set = word_set.order_by(sort_param, 'id')
            # ========== 确定返回字段 ==========
            base_fields = [
                "id", "lemma", "accented", "root1_id", "root2_id", "root3_id",
                "category_id", "pos", "pos_tags", "aspect", "gender", "is_animacy",
                "gloss", "meanings", "forms", "index_words", "examples", "collocations",
                "level", "frequency", "create_time"
            ]
            extra_fields = [
                'category_name',
                'root1_text', 'root1_meaning',
                'root2_text', 'root2_meaning',
                'root3_text', 'root3_meaning'
            ]
            all_query_fields = base_fields + extra_fields
            # ========== 使用 values() + distinct() 去重 ==========
            word_set = word_set.values(*all_query_fields).distinct()
            word_query = word_set.query
            # ========== 执行分页查询 ==========
            paginator = Paginator(word_set, per_page=size)
            total = paginator.count
            if page > paginator.num_pages and paginator.num_pages > 0:
                return {
                    "page": page,
                    "size": size,
                    "total": total,
                    "list": [],
                    "wordbook_id": wordbook_id,
                    "wordbook_name": wordbook.name,
                    "wordbook_description": wordbook.description,
                    "wordbook_press": wordbook.press,
                    "query": str(word_query)
                }, None
            paginator_set = paginator.page(page) if total > 0 else []
            # ========== 导出分页结果 ==========
            if total > 0:
                main_list = list(paginator_set.object_list)
                # ✅ 格式化字段
                for item in main_list:
                    # 格式化时间
                    if item.get('create_time') and hasattr(item['create_time'], 'strftime'):
                        item['create_time'] = item['create_time'].strftime("%Y-%m-%d %H:%M:%S")
                    # 组织词根信息为列表
                    roots = []
                    for i in [1, 2, 3]:
                        root_text = item.pop(f'root{i}_text', None)
                        root_meaning = item.pop(f'root{i}_meaning', None)
                        if root_text:
                            roots.append({
                                "root": root_text,
                                "meaning": root_meaning
                            })
                    item['roots'] = roots
                    # 获取词性显示名称
                    if item.get('pos'):
                        pos_dict = dict(LexiconWord.POS_CHOICES)
                        item['pos_display'] = pos_dict.get(item['pos'], item['pos'])
                    # 获取动词体显示名称
                    if item.get('aspect'):
                        aspect_dict = dict(LexiconWord.ASPECT_CHOICES)
                        item['aspect_display'] = aspect_dict.get(item['aspect'], item['aspect'])
                    # 获取性显示名称
                    if item.get('gender'):
                        gender_dict = dict(LexiconWord.GENDER_CHOICES)
                        item['gender_display'] = gender_dict.get(item['gender'], item['gender'])
                    # 获取等级显示名称
                    if item.get('level'):
                        level_dict = dict(LexiconWord.CEFR_CHOICES)
                        item['level_display'] = level_dict.get(item['level'], item['level'])
            else:
                main_list = []
            result = {
                "page": int(page),
                "size": int(size),
                "total": total,
                "list": main_list,
                "wordbook_id": wordbook_id,
                "wordbook_name": wordbook.name,
                "wordbook_description": wordbook.description,
                "wordbook_press": wordbook.press,
                "query": str(word_query)
            }
            return result, None
        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""