# encoding: utf-8
"""
@project: LexiconNote Service
@synopsis: 词典笔记服务层 - 用户单词学习记录管理
@created_time: 2026
"""
import sys

from django.db.models import Q, F
from django.core.paginator import Paginator

from ..models import LexiconNote, LexiconWord
from ..utils.j_transform_type import JTransformType
from ..utils.custom_tool import format_params_handle

# 可操作字段定义
add_fields = [
    "user_id", "user_uuid",
    "knowns",
]

format_fields = [
    "id|int",
    "user_id|int",
    "user_uuid|str",
    "knowns|dict",
    "match|list",
    "create_time|date",
    "update_time|date",
]

# 默认字段类型
filter_filed_list = [
    "id|int",
    "id_list|list",
    "lemma|str",
    "accented|str",
    "gloss|str",
    "category_id|int",
    "category_id_list|list",
    "root1_id|int",
    "root2_id|int",
    "root3_id|int",
    "root_id|int",
    "pos|str",
    "pos_list|list",
    "aspect|str",
    "aspect_list|list",
    "gender|str",
    "gender_list|list",
    "is_animacy|bool",
    "level|str",
    "level_list|list",
    "frequency_min|int",
    "frequency_max|int",
    "create_time_start|date",
    "create_time_end|date",
]

# 搜索条件映射
condition_alias = {
    "id_list": "id__in",
    "lemma": "lemma__icontains",
    "accented": "accented__icontains",
    "gloss": "gloss__icontains",
    "category_id_list": "category_id__in",
    "pos_list": "pos__in",
    "aspect_list": "aspect__in",
    "gender_list": "gender__in",
    "level_list": "level__in",
    "frequency_min": "frequency__gte",
    "frequency_max": "frequency__lte",
    "create_time_start": "create_time__gte",
    "create_time_end": "create_time__lte",
}


class LexiconNoteService:
    """
    词典笔记服务 - 管理用户单词学习记录
    knowns: {word_id: known}
      - 0: 不认识
      - 1: 模糊
      - 2: 认识
      - 3-5: 认识熟悉度
    """

    @staticmethod
    def add(user_uuid: str = None, user_id: int = None, knowns: dict = None):
        """
        批量添加或更新单词的掌握状态
        :param user_uuid: 用户UUID
        :param user_id: 用户ID
        :param knowns: 批量操作 {word_id: known, ...}
        :return: (result_dict, error)
        """
        query = {}

        # 检查用户参数
        if not user_uuid and not user_id:
            return None, "user_uuid 或 user_id 至少提供一个。"

        if 'xj_user' in sys.modules:
            from xj_user.services.user_detail_info_service import DetailInfoService
            user_dict, err = DetailInfoService.get_detail(user_uuid=user_uuid, user_id=user_id)
            if err or not user_dict:
                return None, f"用户不存在。({user_uuid or user_id})"

            query['user_uuid'] = user_dict.get('user_uuid')
            query['user_id'] = user_dict.get('user_id')
        else:
            return None, "用户模块未安装"

        # 参数校验
        if not knowns:
            return None, "knowns 参数不能为空"

        if not isinstance(knowns, dict):
            return None, "knowns 必须是字典格式 {word_id: known}"

        merge_data = {str(k): v for k, v in knowns.items()}

        # 查找或创建用户笔记
        note_set = LexiconNote.objects.filter(**query).first()

        if not note_set:
            note_set = LexiconNote.objects.create(user_uuid=query.get('user_uuid'), user_id=query.get('user_id'), knowns={}, match=[])

        # 合并 JSON 数据
        existing_knowns = note_set.knowns or {}
        existing_knowns.update(merge_data)
        note_set.knowns = existing_knowns

        note_set.save()
        return {
            'id': note_set.id,
            'user_id': note_set.user_id,
            'user_uuid': str(note_set.user_uuid) if note_set.user_uuid else None,
            'updated_count': len(merge_data),
            'knowns': merge_data,  # 返回本次更新的数据
            'update_time': note_set.update_time.strftime("%Y-%m-%d %H:%M:%S") if note_set.update_time else None,
        }, None

    @staticmethod
    def known_list(user_uuid: str = None, user_id: int = None, known: int = None, max_known: int = None):
        """
        按掌握程度筛选单词
        :param user_uuid: 用户UUID
        :param user_id: 用户ID
        :param known: 掌握程度值（固定值或最小值）
        :param max_known: 掌握程度最大值（可选，传入则取区间）
        :return: (word_ids, error)
        """
        query = {}
        if user_uuid:
            query['user_uuid'] = user_uuid
        elif user_id:
            query['user_id'] = user_id
        else:
            return None, "缺少 user_uuid 或 user_id 参数。"

        note_set = LexiconNote.objects.filter(**query).first()
        if not note_set:
            return [], None

        knowns_dict = note_set.knowns or {}

        if known is None:
            # 返回所有单词ID
            return list(knowns_dict.keys()), None

        # 判断是固定值还是区间
        if max_known is None:
            # 固定值
            filtered_ids = [word_id for word_id, k in knowns_dict.items() if k == known]
        else:
            # 区间 [known, max_known]
            filtered_ids = [word_id for word_id, k in knowns_dict.items() if known <= k <= max_known]

        return filtered_ids, None

    @staticmethod
    def get_statistic(user_uuid: str = None, user_id: int = None):
        """
        获取用户学习统计
        :param user_uuid: 用户UUID
        :param user_id: 用户ID
        :return: (stats_dict, error)
        """
        query = {}
        if user_uuid:
            query['user_uuid'] = user_uuid
        elif user_id:
            query['user_id'] = user_id
        else:
            return None, "缺少 user_uuid 或 user_id 参数。"

        note_set = LexiconNote.objects.filter(**query).first()
        if not note_set:
            return {
                'total': 0,
                'knowns': 0,  # known>=2 (认识及以上)
                'unknowns': 0,  # known=0 (不认识)
                'half_known': 0,  # known=1 (模糊)
            }, None

        knowns_dict = note_set.knowns or {}

        stats = {
            'total': len(knowns_dict),
            'knowns': sum(1 for v in knowns_dict.values() if v >= 2),
            'unknowns': sum(1 for v in knowns_dict.values() if v == 0),
            'half_known': sum(1 for v in knowns_dict.values() if v == 1),
        }

        return stats, None

    @staticmethod
    def unknown_list(user_uuid: str = None, user_id: int = None,
                     query_params: dict = None, page: int = 1, size: int = 20, sort: str = "-create_time"):
        """
        获取用户未掌握的单词列表（known < 1，即不在knowns中或known=0）
        返回格式与 LexiconWordListService.list 一致

        :param user_uuid: 用户UUID
        :param user_id: 用户ID
        :param query_params: 查询参数字典（用于额外过滤，如词性、等级等）
        :param page: 页号
        :param size: 每页行数
        :param sort: 排序字段
        :return: (结果字典, 错误信息)

        @example
        query_params = {
            "pos": "v",                 # 查询动词
            "level": "A1",              # 查询A1等级
            "search": "工作"            # 搜索关键词
        }
        """
        # ========== 参数类型处理 ==========
        query_params, is_void = JTransformType.to(query_params, "dict", {})
        page, is_void = JTransformType.to(page, "int", 1)
        size, is_void = JTransformType.to(size, "int", 20)
        sort_param, is_void = JTransformType.to(sort, "str", "-create_time")

        if page < 1:
            page = 1
        if size < 1:
            size = 1
        if size > 200:
            size = 200

        sort_choices = [
            "id", "-id",
            "lemma", "-lemma",
            "frequency", "-frequency",
            "level", "-level",
            "create_time", "-create_time"
        ]
        if sort_param not in sort_choices:
            return None, f"排序字段无效，可选值：{'、'.join(sort_choices)}。"

        # ========== 获取用户笔记 ==========
        query = {}
        if user_uuid:
            query['user_uuid'] = user_uuid
        elif user_id:
            query['user_id'] = user_id
        else:
            return None, "缺少 user_uuid 或 user_id 参数。"

        note_set = LexiconNote.objects.filter(**query).first()

        # ========== 获取已掌握单词ID（known >= 1） ==========
        known_word_ids = []
        if note_set and note_set.knowns:
            knowns_dict = note_set.knowns or {}
            # 筛选出 known >= 1 的单词ID（字符串转整数）
            known_word_ids = [int(word_id) for word_id, k in knowns_dict.items() if int(k) >= 1]

        # ========== 基础查询：排除 known >= 1 的单词 ==========
        word_set = LexiconWord.objects.select_related('category', 'root1', 'root2', 'root3')

        if known_word_ids:
            word_set = word_set.exclude(id__in=known_word_ids)

        # ========== 处理搜索关键词 ==========
        search = query_params.pop("search", None)
        if search:
            search, is_void = JTransformType.to(search, "str")
            if search:
                word_set = word_set.filter(
                    Q(lemma__icontains=search) |
                    Q(accented__icontains=search) |
                    Q(gloss__icontains=search)
                )

        # ========== 处理其他查询参数 ==========
        conditions = format_params_handle(
            param_dict=query_params,
            filter_filed_list=filter_filed_list,
            alias_dict=condition_alias,
            split_list=["id_list", "category_id_list", "pos_list", "aspect_list", "gender_list", "level_list"],
            is_remove_empty=True
        )
        if conditions:
            word_set = word_set.filter(**conditions)

        # ========== 统计关联数据 ==========
        word_set = word_set.annotate(
            category_name=F('category__name'),
            root1_text=F('root1__root'),
            root1_meaning=F('root1__meaning'),
            root2_text=F('root2__root'),
            root2_meaning=F('root2__meaning'),
            root3_text=F('root3__root'),
            root3_meaning=F('root3__meaning'),
        )

        # ========== 排序 ==========
        if sort_param.startswith('-'):
            word_set = word_set.order_by(sort_param, '-id')
        else:
            word_set = word_set.order_by(sort_param, 'id')

        # ========== 确定返回字段 ==========
        all_fields = [
            "id", "lemma", "accented", "root1_id", "root2_id", "root3_id",
            "category_id", "pos", "pos_tags", "aspect", "gender", "is_animacy",
            "gloss", "meanings", "forms", "index_words", "examples", "collocations",
            "level", "frequency", "create_time",
        ]
        extra_fields = [
            'category_name',
            'root1_text', 'root1_meaning',
            'root2_text', 'root2_meaning',
            'root3_text', 'root3_meaning'
        ]
        all_query_fields = all_fields + extra_fields

        # ========== 使用 values() + distinct() 去重 ==========
        word_set = word_set.values(*all_query_fields).distinct()

        word_query = word_set.query

        # ========== 执行分页查询 ==========
        paginator = Paginator(word_set, per_page=size)
        total = paginator.count

        if page > paginator.num_pages and paginator.num_pages > 0:
            return {"page": page, "size": size, "total": total, "list": [], "query": str(word_query)}, None

        paginator_set = paginator.page(page) if total > 0 else []

        # ========== 导出分页结果 ==========
        if total > 0:
            main_list = list(paginator_set.object_list)

            # ✅ 格式化 create_time 和组织词根信息
            for item in main_list:
                if item.get('create_time') and hasattr(item['create_time'], 'strftime'):
                    item['create_time'] = item['create_time'].strftime("%Y-%m-%d %H:%M:%S")

                # 组织词根信息为列表
                roots = []
                for i in [1, 2, 3]:
                    root_text = item.pop(f'root{i}_text', None)
                    root_meaning = item.pop(f'root{i}_meaning', None)
                    if root_text:
                        roots.append({
                            "root": root_text,
                            "meaning": root_meaning
                        })
                item['roots'] = roots

                # 获取词性显示名称
                if item.get('pos'):
                    pos_dict = dict(LexiconWord.POS_CHOICES)
                    item['pos_display'] = pos_dict.get(item['pos'], item['pos'])

                # 获取动词体显示名称
                if item.get('aspect'):
                    aspect_dict = dict(LexiconWord.ASPECT_CHOICES)
                    item['aspect_display'] = aspect_dict.get(item['aspect'], item['aspect'])

                # 获取性显示名称
                if item.get('gender'):
                    gender_dict = dict(LexiconWord.GENDER_CHOICES)
                    item['gender_display'] = gender_dict.get(item['gender'], item['gender'])

                # 获取等级显示名称
                if item.get('level'):
                    level_dict = dict(LexiconWord.CEFR_CHOICES)
                    item['level_display'] = level_dict.get(item['level'], item['level'])
        else:
            main_list = []

        result = {
            "page": int(page),
            "size": int(size),
            "total": total,
            "list": main_list,
            "query": str(word_query),
            "user_id": user_id,
            "user_uuid": user_uuid,
            "excluded_count": len(known_word_ids)  # 排除的已掌握单词数量
        }

        return result, None

    @staticmethod
    def get_knowns_by_keys(user_uuid: str = None, user_id: int = None, key_list: list = None):
        """
        获取 knowns 中指定 key 的内容
        :param user_uuid: 用户UUID
        :param user_id: 用户ID
        :param key_list: 要获取的 key 列表（单词ID列表）
        :return: (knowns_dict, error)

        @example
        # 获取指定单词的掌握状态
        knowns, err = LexiconNoteService.get_knowns_by_keys(
            user_id=1,
            key_list=[123, 456, 789]
        )
        # 返回: {'123': 2, '456': 0, '789': 3}  # 只返回存在的key
        """
        # ========== 参数校验 ==========
        if not user_uuid and not user_id:
            return None, "user_uuid 或 user_id 至少提供一个。"

        if not key_list or not isinstance(key_list, list):
            return None, "key_list 必须是非空列表。"

        # ========== 查询用户笔记 ==========
        query = {}
        if user_uuid:
            query['user_uuid'] = user_uuid
        elif user_id:
            query['user_id'] = user_id

        note_set = LexiconNote.objects.filter(**query).first()

        if not note_set:
            return {}, None  # 用户笔记不存在，返回空字典

        knowns_dict = note_set.knowns or {}

        # ========== 筛选指定的 key ==========
        # 将 key_list 转为字符串（因为 JSON 的 key 是字符串）
        str_key_list = [str(k) for k in key_list]

        # 只返回存在的 key
        result = {k: v for k, v in knowns_dict.items() if k in str_key_list}

        return result, None