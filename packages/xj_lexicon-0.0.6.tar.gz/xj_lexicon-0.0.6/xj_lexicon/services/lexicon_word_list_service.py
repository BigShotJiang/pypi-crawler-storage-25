# encoding: utf-8
"""
@project: lexicon_word_list_service
@author:
@Email:
@synopsis: 词典单词列表服务层 - 统一查询入口
@created_time: 2026
"""

from django.db import transaction
from django.db.models import Q, Count, F
from django.core.paginator import Paginator, EmptyPage

from ..models import LexiconWord, LexiconCategory, LexiconRoot, LexiconWordbook, LexiconNote
from ..utils.j_transform_type import JTransformType
from ..utils.j_parameter import JParameter
from ..utils.custom_tool import format_params_handle


class LexiconWordListService:
    """
    词典单词列表服务类：统一查询入口

    支持场景：
    1. 普通单词列表查询（按分类、词根、词性等）
    2. 词集单词列表查询（wordbook_id）
    3. 用户笔记单词列表查询（user_id/user_uuid + known_status）
    """

    # 查询字段说明
    __support_queries = {
        # ===== 基础查询 =====
        "id": "单词ID",
        "id_list": "单词ID列表",
        "lemma": "单词原形（模糊查询）",
        "accented": "带重音词形（模糊查询）",
        "gloss": "简明释义（模糊查询）",
        "search": "搜索关键词（单词原形、带重音词形、简明释义）",

        # ===== 分类词根 =====
        "category_id": "分类ID",
        "category_id_list": "分类ID列表",
        "root1_id": "词根1 ID",
        "root2_id": "词根2 ID",
        "root3_id": "词根3 ID",
        "root_id": "词根ID（查询包含该词根的所有单词）",

        # ===== 词性特征 =====
        "pos": "基本词性",
        "pos_list": "词性列表",
        "aspect": "动词体",
        "aspect_list": "动词体列表",
        "gender": "性",
        "gender_list": "性列表",
        "is_animacy": "是否动物名词",

        # ===== 等级词频 =====
        "level": "欧标等级",
        "level_list": "欧标等级列表",
        "frequency_min": "最小词频",
        "frequency_max": "最大词频",

        # ===== 时间范围 =====
        "create_time_start|date": "创建开始时间",
        "create_time_end|date": "创建结束时间",

        # ===== 词集查询 =====
        "wordbook_id": "词集ID（查询词集中的单词）",

        # ===== 用户笔记查询 =====
        "user_id": "用户ID",
        "user_uuid": "用户UUID",
        "known_status": "掌握度值（'not_noted'=未标注, 0=不认识, 1=模糊, 2+=认识）",
        "known_min": "掌握度最小值",
        "known_max": "掌握度最大值",

        # ===== 分页排序 =====
        "page": "页号，默认第1页",
        "size": "每页行数，默认20行",
        "sort": "排序字段，默认 -create_time",
        "filter_fields": "返回字段筛选",
    }

    # 所有字段
    all_fields = ["id", "lemma", "accented", "root1_id", "root2_id", "root3_id", "category_id", "pos", "pos_tags",
                  "aspect", "gender", "is_animacy", "gloss", "meanings", "forms", "index_words", "examples",
                  "collocations", "level", "frequency", "create_time"]

    # 格式化字段
    format_fields = ["id|int", "lemma|str", "accented|str", "root1_id|int", "root2_id|int", "root3_id|int",
                     "category_id|int", "pos|str", "pos_tags|str", "aspect|str", "gender|str", "is_animacy|bool",
                     "gloss|str", "meanings|json", "forms|json", "index_words|str", "examples|json",
                     "collocations|json", "level|str", "frequency|int", "create_time|date"]

    # 搜索条件映射
    __condition_alias = {
        "id_list": "id__in",
        "lemma": "lemma__icontains",
        "accented": "accented__icontains",
        "gloss": "gloss__icontains",
        "category_id_list": "category_id__in",
        "pos_list": "pos__in",
        "aspect_list": "aspect__in",
        "gender_list": "gender__in",
        "level_list": "level__in",
        "frequency_min": "frequency__gte",
        "frequency_max": "frequency__lte",
        "create_time_start": "create_time__gte",
        "create_time_end": "create_time__lte",
    }

    # 默认字段类型
    filter_filed_list = ["id|int", "id_list|list", "lemma|str", "accented|str", "gloss|str", "category_id|int",
                         "category_id_list|list", "root1_id|int", "root2_id|int", "root3_id|int", "root_id|int",
                         "pos|str", "pos_list|list", "aspect|str", "aspect_list|list", "gender|str", "gender_list|list",
                         "is_animacy|bool", "level|str", "level_list|list", "frequency_min|int", "frequency_max|int",
                         "create_time_start|date", "create_time_end|date"]

    @staticmethod
    def list(query_params: dict = None, page: int = 1, size: int = 20, sort: str = "-create_time"):
        """
        统一单词列表查询入口

        :param query_params: 查询参数字典
        :param page: 页号
        :param size: 每页行数
        :param sort: 排序字段
        :return: (结果字典, 错误信息)

        @场景1: 普通查询
        query_params = {
            "lemma": "работ",           # 模糊查询单词原形
            "pos": "v",                 # 查询动词
            "level": "A1",              # 查询A1等级
            "category_id": 5,           # 分类ID
            "root_id": 10,              # 词根ID
        }

        @场景2: 词集查询
        query_params = {
            "wordbook_id": 1,           # 词集ID
            "pos": "v",                 # 在词集中筛选动词
        }

        @场景3: 用户未标注单词（必须传 user_id）
        query_params = {
            "user_id": 123,             # 用户ID（必填）
            "known_status": "not_noted",  # 完全未标注
        }

        @场景4: 用户不认识单词（必须传 user_id）
        query_params = {
            "user_uuid": "xxx",         # 用户UUID（必填）
            "known_status": 0,          # 不认识（明确标记）
            "level": "A1",              # 再按等级筛选
        }

        @场景5: 用户模糊单词
        query_params = {
            "user_id": 123,
            "known_status": 1,          # 模糊
        }

        @场景6: 用户已掌握单词
        query_params = {
            "user_id": 123,
            "known_status": 2,          # 认识
        }

        @场景7: 按掌握度区间查询
        query_params = {
            "user_id": 123,
            "known_min": 2,             # 掌握度 >= 2
            "known_max": 5,             # 掌握度 <= 5
        }
        """
        # ========== 参数类型处理 ==========
        query_params, is_void = JTransformType.to(query_params, "dict", {})
        page, is_void = JTransformType.to(page, "int", 1)
        size, is_void = JTransformType.to(size, "int", 20)
        sort_param, is_void = JTransformType.to(sort, "str", "-create_time")

        if page < 1:
            page = 1
        if size < 1:
            size = 1
        if size > 200:
            size = 200

        sort_choices = ["id", "-id", "lemma", "-lemma", "frequency", "-frequency", "level", "-level", "create_time",
                        "-create_time"]
        if sort_param not in sort_choices:
            return None, f"排序字段无效，可选值：{'、'.join(sort_choices)}。"

        # ========== 提取特殊参数 ==========
        wordbook_id = query_params.pop("wordbook_id", None)
        user_id = query_params.pop("user_id", None)
        user_uuid = query_params.pop("user_uuid", None)
        known_status = query_params.pop("known_status", None)
        known_min = query_params.pop("known_min", None)
        known_max = query_params.pop("known_max", None)

        category_id = query_params.get("category_id")
        root_id = query_params.get("root_id")
        id_list = query_params.get("id_list")

        # ========== 额外返回信息 ==========
        extra_info = {}

        # ========== 场景1: 词集查询 ==========
        if wordbook_id:
            wordbook_id, is_void = JTransformType.to(wordbook_id, "int")
            if not wordbook_id:
                return None, "词集ID无效"

            wordbook = LexiconWordbook.objects.filter(id=wordbook_id).first()
            if not wordbook:
                return None, f"词集(ID:{wordbook_id})不存在"

            if not wordbook.books or len(wordbook.books) == 0:
                return {"page": page, "size": size, "total": 0, "list": [], "wordbook_id": wordbook_id,
                        "wordbook_name": wordbook.name, "wordbook_description": wordbook.description,
                        "wordbook_press": wordbook.press, "query": ""}, None

            # 限定查询范围为词集中的单词
            id_list = wordbook.books
            query_params["id_list"] = id_list

            extra_info.update({"wordbook_id": wordbook_id, "wordbook_name": wordbook.name,
                               "wordbook_description": wordbook.description, "wordbook_press": wordbook.press})

        # ========== 场景2: 用户笔记查询 ==========
        # 🔥 关键修复：只有传了 known_status/known_min/known_max 时才要求必须传 user_id
        has_known_filter = known_status is not None or known_min is not None or known_max is not None

        if has_known_filter and not user_id and not user_uuid:
            return None, "查询用户笔记状态时，必须传递 user_id 或 user_uuid 参数"

        # 🔥 修复：只有在有 user_id/user_uuid 且有过滤条件时才进行笔记查询
        if (user_id or user_uuid) and has_known_filter:
            # 查询用户笔记
            note_query = {}
            if user_uuid:
                note_query['user_uuid'] = user_uuid
            elif user_id:
                note_query['user_id'] = user_id

            note_set = LexiconNote.objects.filter(**note_query).first()
            knowns_dict = note_set.knowns if note_set else {}

            # 根据筛选条件获取单词ID
            filtered_ids = []

            # 🔥 优先处理特殊字符串值
            if known_status == "not_noted":
                # 查询完全未标注的单词
                all_word_ids = set(LexiconWord.objects.values_list('id', flat=True))
                noted_ids = {int(k) for k in knowns_dict.keys()}
                filtered_ids = list(all_word_ids - noted_ids)

            # 精确查询（支持任意整数，包括负数）
            elif known_status is not None:
                known_status, is_void = JTransformType.to(known_status, "int")
                filtered_ids = [int(k) for k, v in knowns_dict.items() if int(v) == known_status]

            # 区间查询
            elif known_min is not None or known_max is not None:
                known_min, is_void = JTransformType.to(known_min, "int", 0)
                known_max, is_void = JTransformType.to(known_max, "int", 5)
                filtered_ids = [int(k) for k, v in knowns_dict.items() if known_min <= int(v) <= known_max]

            if not filtered_ids:
                return {"page": page, "size": size, "total": 0, "list": [], "user_id": user_id, "user_uuid": user_uuid,
                        "known_status": known_status, "query": ""}, None

            query_params["id_list"] = filtered_ids

            extra_info.update({"user_id": user_id, "user_uuid": user_uuid, "known_status": known_status})

        # ========== 验证分类是否存在 ==========
        if category_id:
            category_id, is_void = JTransformType.to(category_id, "int")
            category_exists = LexiconCategory.objects.filter(id=category_id).exists()
            if not category_exists:
                return None, f"分类(ID:{category_id})不存在。"
            extra_info['category_id'] = category_id

        # ========== 验证词根是否存在 ==========
        if root_id:
            root_id, is_void = JTransformType.to(root_id, "int")
            root_exists = LexiconRoot.objects.filter(id=root_id).exists()
            if not root_exists:
                return None, f"词根(ID:{root_id})不存在。"

            # 查询包含该词根的所有单词（词根1、词根2或词根3）
            query_params["root_id"] = root_id
            extra_info['root_id'] = root_id

        # ========== 基础查询 ==========
        word_set = LexiconWord.objects.select_related('category', 'root1', 'root2', 'root3')

        # ========== 应用ID列表过滤 ==========
        if id_list and len(id_list) > 0:
            word_set = word_set.filter(id__in=id_list)

        # ========== 应用分类过滤 ==========
        if category_id:
            word_set = word_set.filter(category_id=category_id)

        # ========== 应用词根过滤 ==========
        if root_id:
            word_set = word_set.filter(Q(root1_id=root_id) | Q(root2_id=root_id) | Q(root3_id=root_id))

        # ========== 处理搜索关键词 ==========
        search = query_params.pop("search", None)
        if search:
            search, is_void = JTransformType.to(search, "str")
            if search:
                word_set = word_set.filter(
                    Q(lemma__icontains=search) | Q(accented__icontains=search) | Q(gloss__icontains=search))

        # ========== 处理其他查询参数 ==========
        conditions = format_params_handle(param_dict=query_params,
                                          filter_filed_list=LexiconWordListService.filter_filed_list,
                                          alias_dict=LexiconWordListService.__condition_alias,
                                          split_list=["id_list", "category_id_list", "pos_list", "aspect_list",
                                                      "gender_list", "level_list"], is_remove_empty=True)
        if conditions:
            word_set = word_set.filter(**conditions)

        # ========== 统计关联数据 ==========
        word_set = word_set.annotate(category_name=F('category__name'), root1_text=F('root1__root'),
                                     root1_meaning=F('root1__meaning'), root2_text=F('root2__root'),
                                     root2_meaning=F('root2__meaning'), root3_text=F('root3__root'),
                                     root3_meaning=F('root3__meaning'))

        # ========== 排序 ==========
        if sort_param.startswith('-'):
            word_set = word_set.order_by(sort_param, '-id')
        else:
            word_set = word_set.order_by(sort_param, 'id')

        # ========== 确定返回字段 ==========
        base_fields = list(LexiconWordListService.all_fields)
        extra_fields = ['category_name', 'root1_text', 'root1_meaning', 'root2_text', 'root2_meaning', 'root3_text',
                        'root3_meaning']
        all_query_fields = base_fields + extra_fields

        # ========== 使用 values() + distinct() 去重 ==========
        word_set = word_set.values(*all_query_fields).distinct()
        word_query = word_set.query

        # ========== 执行分页查询 ==========
        paginator = Paginator(word_set, per_page=size)
        total = paginator.count

        if page > paginator.num_pages and paginator.num_pages > 0:
            result = {"page": page, "size": size, "total": total, "list": [], "query": str(word_query)}
            result.update(extra_info)
            return result, None

        paginator_set = paginator.page(page) if total > 0 else []

        # ========== 导出分页结果 ==========
        if total > 0:
            main_list = list(paginator_set.object_list)

            for item in main_list:
                # 格式化时间
                if item.get('create_time') and hasattr(item['create_time'], 'strftime'):
                    item['create_time'] = item['create_time'].strftime("%Y-%m-%d %H:%M:%S")

                # 组织词根信息为列表
                roots = []
                for i in [1, 2, 3]:
                    root_text = item.pop(f'root{i}_text', None)
                    root_meaning = item.pop(f'root{i}_meaning', None)
                    if root_text:
                        roots.append({"root": root_text, "meaning": root_meaning})
                item['roots'] = roots

                # 获取词性显示名称
                if item.get('pos'):
                    pos_dict = dict(LexiconWord.POS_CHOICES)
                    item['pos_display'] = pos_dict.get(item['pos'], item['pos'])

                # 获取动词体显示名称
                if item.get('aspect'):
                    aspect_dict = dict(LexiconWord.ASPECT_CHOICES)
                    item['aspect_display'] = aspect_dict.get(item['aspect'], item['aspect'])

                # 获取性显示名称
                if item.get('gender'):
                    gender_dict = dict(LexiconWord.GENDER_CHOICES)
                    item['gender_display'] = gender_dict.get(item['gender'], item['gender'])

                # 获取等级显示名称
                if item.get('level'):
                    level_dict = dict(LexiconWord.CEFR_CHOICES)
                    item['level_display'] = level_dict.get(item['level'], item['level'])
        else:
            main_list = []

        result = {"page": int(page), "size": int(size), "total": total, "list": main_list, "query": str(word_query)}
        result.update(extra_info)

        return result, None