# encoding: utf-8
"""
@project: lexicon_category_list_service
@author:
@Email:
@synopsis: 词典分类列表服务
@created_time: 2026
"""
from django.core.paginator import Paginator
from django.db.models import F, Count

from ..models import LexiconCategory
from ..utils.custom_tool import format_params_handle, filter_fields_handler, force_transform_type


class LexiconCategoryService:
    """词典分类列表服务"""

    @staticmethod
    def list(params: dict = None, filter_fields: "str|list" = None, need_pagination: bool = True, with_word_count: bool = False):
        """
        词典分类列表
        :param params: 搜索参数
            - id: 分类ID
            - name: 分类名称（模糊查询）
            - code: 分类编码
            - parent_id: 父分类ID
            - id_list: ID列表
            - sort: 排序字段（默认：sort）
            - page: 页码（默认：1）
            - size: 每页数量（默认：20）
        :param filter_fields: 过滤字段
        :param need_pagination: 是否需要分页
        :param with_word_count: 是否统计单词数量
        :return: data, err
        """
        # 参数筛选
        params, err = force_transform_type(variable=params, var_type="dict", default={})
        need_pagination, err = force_transform_type(variable=need_pagination, var_type="bool", default=True)
        with_word_count, err = force_transform_type(variable=with_word_count, var_type="bool", default=False)

        sort = params.get("sort", "sort")
        sort = sort if sort and sort in ["id", "-id", "sort", "-sort", "name", "-name"] else "sort"
        page, err = force_transform_type(variable=params.get("page", 1), var_type="int", default=1)
        size, err = force_transform_type(variable=params.get("size", 20), var_type="int", default=20)

        # 查询参数过滤、替换
        queries = format_params_handle(
            param_dict=params,
            filter_filed_list=["id", "name", "code", "parent_id"],
            alias_dict={"name": "name__contains"}
        )

        # ID列表查询
        id_list = params.get("id_list")
        if id_list:
            queries.pop("id", None)
            if isinstance(id_list, str):
                id_list = [int(x.strip()) for x in id_list.split(',') if x.strip()]
            queries["id__in"] = id_list

        # 查询字段处理
        filter_fields_list = filter_fields_handler(
            default_field_list=['id', 'name', 'code', 'parent_id', 'parent_name', 'sort'],
            input_field_expression=filter_fields
        )

        # 数据库ORM查询
        category_set = LexiconCategory.objects.annotate(
            parent_name=F('parent__name')
        )

        # 统计单词数量
        if with_word_count:
            category_set = category_set.annotate(word_count=Count('lexicons'))
            if 'word_count' not in filter_fields_list:
                filter_fields_list.append('word_count')

        category_set = category_set.filter(**queries).order_by(sort, 'name')
        category_obj = category_set.values(*filter_fields_list)

        # 不需要分页展示全部数据
        if not need_pagination:
            if not category_obj:
                return [], None
            return list(category_obj), None

        # 分页展示
        count = category_obj.count()
        finish_set = list(Paginator(category_obj, size).page(page))
        return {'size': int(size), 'page': int(page), 'total': count, 'list': finish_set}, None