from ..models import LexiconArticle, LexiconSentence
from ..utils.j_transform_type import JTransformType


class LexiconArticleService:
    # 文章详情返回字段（包含完整内容）
    article_fields = [
        "id", "title", "meaning", "rendering", "title_accented",
        "author_russian", "author_chinese",
        "article_analysis", "qa",
        "category_code", "article_source",
        "create_time", "update_time"
    ]
    # 句子返回字段
    sentence_fields = [
        "id",
        "section_order", "paragraph_order", "sentence_order",
        "russian", "chinese", "russian_accented",
        "grammar_analysis", "level", "source",
        "create_time"
    ]
    @staticmethod
    def detail(article_id: int = None):
        """
        文章详情查询（含关联句子）
        :param article_id: 文章ID
        :return: (结果字典, 错误信息)
        """
        # ========== 参数校验 ==========
        article_id, is_void = JTransformType.to(article_id, "int")
        if not article_id:
            return None, "文章ID无效。"
        # ========== 查询文章 ==========
        article = LexiconArticle.objects.filter(id=article_id).values(
            *LexiconArticleService.article_fields
        ).first()
        if not article:
            return None, "文章不存在。"
        # ========== 格式化文章时间 ==========
        for time_field in ["create_time", "update_time"]:
            if article.get(time_field) and hasattr(article[time_field], 'strftime'):
                article[time_field] = article[time_field].strftime("%Y-%m-%d %H:%M:%S")
        # ========== 查询关联句子 ==========
        sentence_qs = (
            LexiconSentence.objects
            .filter(article_id=article_id)
            .order_by("section_order", "paragraph_order", "sentence_order")
            .values(*LexiconArticleService.sentence_fields)
        )
        sentence_list = list(sentence_qs)
        # ========== 格式化句子时间 ==========
        for item in sentence_list:
            if item.get('create_time') and hasattr(item['create_time'], 'strftime'):
                item['create_time'] = item['create_time'].strftime("%Y-%m-%d %H:%M:%S")
        # ========== 按章节/段落结构化句子 ==========
        structured = LexiconArticleService._build_structure(sentence_list)
        # ========== 组装结果 ==========
        result = dict(article)
        result["sentence_count"] = len(sentence_list)
        # result["sentences"] = sentence_list        # 平铺列表
        result["sections"] = structured            # 结构化：章节 → 段落 → 句子
        return result, None
    @staticmethod
    def _build_structure(sentence_list: list) -> list:
        """
        将平铺句子列表结构化为：章节 → 段落 → 句子
        :param sentence_list: 平铺句子列表
        :return: 结构化章节列表
        [
            {
                "section_order": 1,
                "paragraphs": [
                    {
                        "paragraph_order": 1,
                        "sentences": [ {...}, {...} ]
                    }
                ]
            }
        ]
        """
        section_map = {}  # section_order → paragraph_map
        for sentence in sentence_list:
            s_order = sentence.get("section_order") or 0
            p_order = sentence.get("paragraph_order") or 0
            if s_order not in section_map:
                section_map[s_order] = {}
            if p_order not in section_map[s_order]:
                section_map[s_order][p_order] = []
            section_map[s_order][p_order].append(sentence)
        # 转换为有序列表
        sections = []
        for s_order in sorted(section_map.keys()):
            paragraphs = []
            for p_order in sorted(section_map[s_order].keys()):
                paragraphs.append({
                    "paragraph_order": p_order,
                    "sentences": section_map[s_order][p_order]
                })
            sections.append({
                "section_order": s_order,
                "paragraphs": paragraphs
            })
        return sections