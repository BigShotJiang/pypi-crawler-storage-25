# encoding: utf-8
"""
@project: lexicon_word_service
@author:
@Email:
@synopsis: 词典单词详情Service
@created_time: 2026
"""

from django.db.models import Prefetch

from ..models import LexiconWord, LexiconRelation


class LexiconWordService:
    """词典单词详情服务"""

    @staticmethod
    def item(word_id=None, lemma=None):
        """
        获取单词详情

        @param word_id: 单词ID
        @param lemma: 单词原形
        @return: (data, error)
            data: 单词详情字典
            error: 错误元组 (错误码, 错误消息) 或 None

        @example
        data, error = LexiconWordService.item(word_id=1)
        data, error = LexiconWordService.item(lemma="работа")

        @error_codes
        - 8511: 缺少查询参数
        - 8512: 单词不存在
        - 8513: 查询失败
        """

        try:
            # ========== 参数校验 ==========
            if not word_id and not lemma:
                return None, (8511, "缺少查询参数：word_id 或 lemma 至少需要一个")

            # ========== 查询单词 ==========
            queryset = LexiconWord.objects.select_related(
                'category',
                'root1',
                'root2',
                'root3'
            ).prefetch_related(
                # 预加载词汇关系（从此单词指向其他单词）
                Prefetch(
                    'relations_out',
                    queryset=LexiconRelation.objects.select_related('to_word')
                ),
                # 预加载词汇关系（其他单词指向此单词）
                Prefetch(
                    'relations_in',
                    queryset=LexiconRelation.objects.select_related('from_word')
                )
            )

            if word_id:
                word = queryset.filter(id=word_id).first()
            else:
                word = queryset.filter(lemma=lemma).first()

            if not word:
                return None, (8512, "单词不存在")

            # ========== 构建返回数据 ==========
            data = {
                # 基本信息
                "id": word.id,
                "lemma": word.lemma,
                "accented": word.accented,
                "gloss": word.gloss,

                # 词性信息
                "pos": word.pos,
                "pos_display": word.get_pos_display() if word.pos else None,
                "pos_tags": word.pos_tags.split(',') if word.pos_tags else [],

                # 语法属性
                "aspect": word.aspect,
                "aspect_display": word.get_aspect_display() if word.aspect else None,
                "gender": word.gender,
                "gender_display": word.get_gender_display() if word.gender else None,
                "is_animacy": word.is_animacy,

                # 分类
                "category_id": word.category_id,
                "category_name": word.category.name if word.category else None,

                # 词根
                "roots": [],

                # 释义和词形
                "meanings": word.meanings or {},
                "forms": word.forms or {},
                "index_words": word.index_words.split(',') if word.index_words else [],

                # 例句和搭配
                "examples": word.examples or [],
                "collocations": word.collocations or [],

                # 等级和词频
                "level": word.level,
                "frequency": word.frequency,

                # 词汇关系
                "relations": {
                    "aspect": [],  # 体配对
                    "synonym": [],  # 同义词
                    "near_syn": [],  # 近义词
                    "antonym": [],  # 反义词
                    "related": [],  # 相关词
                    "derivative": []  # 派生词
                },

                # 时间
                "create_time": word.create_time.strftime("%Y-%m-%d %H:%M:%S") if word.create_time else None,
            }

            # ========== 处理词根 ==========
            for i, root_field in enumerate(['root1', 'root2', 'root3'], 1):
                root = getattr(word, root_field, None)
                if root:
                    data["roots"].append({
                        "id": root.id,
                        "root": root.root,
                        "meaning": root.meaning,
                        "desc": root.desc,
                        "position": i  # 词根位置：1/2/3
                    })

            # ========== 处理词汇关系（出向关系：从此单词指向其他单词）==========
            for relation in word.relations_out.all():
                relation_data = {
                    "id": relation.to_word.id,
                    "lemma": relation.to_word.lemma,
                    "accented": relation.to_word.accented,
                    "gloss": relation.to_word.gloss,
                    "pos": relation.to_word.pos,
                    "pos_display": relation.to_word.get_pos_display() if relation.to_word.pos else None,
                }

                # 根据关系类型分组
                rel_type = relation.relation_type
                if rel_type in data["relations"]:
                    data["relations"][rel_type].append(relation_data)

            # ========== 处理反向关系（入向关系：其他单词指向此单词）==========
            # 例如：如果其他单词把当前单词标记为同义词，也应该显示出来
            for relation in word.relations_in.all():
                relation_data = {
                    "id": relation.from_word.id,
                    "lemma": relation.from_word.lemma,
                    "accented": relation.from_word.accented,
                    "gloss": relation.from_word.gloss,
                    "pos": relation.from_word.pos,
                    "pos_display": relation.from_word.get_pos_display() if relation.from_word.pos else None,
                    "is_reverse": True  # 标记为反向关系
                }

                rel_type = relation.relation_type
                if rel_type in data["relations"]:
                    # 避免重复添加
                    if not any(r.get("id") == relation_data["id"] for r in data["relations"][rel_type]):
                        data["relations"][rel_type].append(relation_data)

            return data, None

        except Exception as e:
            return None, (8513, f"查询单词详情失败：{str(e)}")