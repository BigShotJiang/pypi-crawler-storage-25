# encoding: utf-8
"""
@project: lexicon_article_list_service
@synopsis: 词典文章列表服务层
"""

from django.db.models import Q
from django.core.paginator import Paginator

from ..models import LexiconArticle
from ..utils.j_transform_type import JTransformType
from ..utils.custom_tool import format_params_handle


class LexiconArticleListService:

    all_fields = ["id", "title", "meaning", "rendering", "title_accented", "author_russian", "author_chinese",
                  "category_code", "article_source", "create_time", "update_time"]

    __condition_alias = {
        "category_code": "category_code",
    }

    filter_filed_list = ["category_code|str"]

    @staticmethod
    def list(query_params: dict = None, page: int = 1, size: int = 20, sort: str = "-create_time"):
        """
        文章列表查询

        :param query_params: 查询参数字典
        :param page: 页号
        :param size: 每页行数
        :param sort: 排序字段
        :return: (结果字典, 错误信息)
        """
        query_params, is_void = JTransformType.to(query_params, "dict", {})
        page, is_void = JTransformType.to(page, "int", 1)
        size, is_void = JTransformType.to(size, "int", 20)
        sort_param, is_void = JTransformType.to(sort, "str", "-create_time")

        if page < 1:
            page = 1
        if size < 1:
            size = 1
        if size > 200:
            size = 200

        sort_choices = ["id", "-id", "title", "-title", "create_time", "-create_time", "update_time", "-update_time"]
        if sort_param not in sort_choices:
            return None, f"排序字段无效，可选值：{'、'.join(sort_choices)}。"

        article_set = LexiconArticle.objects.all()

        search = query_params.pop("search", None)
        if search:
            search, is_void = JTransformType.to(search, "str")
            if search:
                article_set = article_set.filter(Q(title__icontains=search))

        conditions = format_params_handle(param_dict=query_params,
                                          filter_filed_list=LexiconArticleListService.filter_filed_list,
                                          alias_dict=LexiconArticleListService.__condition_alias,
                                          split_list=[],
                                          is_remove_empty=True)
        if conditions:
            article_set = article_set.filter(**conditions)

        if sort_param.startswith('-'):
            article_set = article_set.order_by(sort_param, '-id')
        else:
            article_set = article_set.order_by(sort_param, 'id')

        article_set = article_set.values(*LexiconArticleListService.all_fields).distinct()
        article_query = article_set.query

        paginator = Paginator(article_set, per_page=size)
        total = paginator.count

        if page > paginator.num_pages and paginator.num_pages > 0:
            return {"page": page, "size": size, "total": total, "list": [], "query": str(article_query)}, None

        paginator_set = paginator.page(page) if total > 0 else []

        if total > 0:
            main_list = list(paginator_set.object_list)
            for item in main_list:
                if item.get('create_time') and hasattr(item['create_time'], 'strftime'):
                    item['create_time'] = item['create_time'].strftime("%Y-%m-%d %H:%M:%S")
                if item.get('update_time') and hasattr(item['update_time'], 'strftime'):
                    item['update_time'] = item['update_time'].strftime("%Y-%m-%d %H:%M:%S")
        else:
            main_list = []

        return {"page": int(page), "size": int(size), "total": total, "list": main_list, "query": str(article_query)}, None