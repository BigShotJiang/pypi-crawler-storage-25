# admin_import_export.py
from django.http import HttpResponse
from django.contrib import messages
from django.db import transaction
import csv
import io
import json
from .models import LexiconWord


class LexiconWordImportExport:
    """词汇导入导出工具类"""

    @staticmethod
    def export_to_csv(queryset):
        """导出选中单词为CSV（所有字段）"""
        response = HttpResponse(content_type='text/csv; charset=utf-8-sig')
        response['Content-Disposition'] = 'attachment; filename="lexicon_words_export.csv"'
        writer = csv.writer(response)
        fieldnames = ['id', 'lemma', 'accented', 'gloss', 'pos', 'pos_tags', 'aspect', 'gender', 'is_animacy', 'level',
                      'frequency', 'meanings', 'forms', 'examples', 'collocations', 'index_words', 'root1_id',
                      'root2_id', 'root3_id', 'category_id', 'create_time']
        writer.writerow(fieldnames)
        for word in queryset:
            row = [
                word.id,
                word.lemma,
                word.accented or '',
                word.gloss or '',
                word.pos or '',
                word.pos_tags or '',
                word.aspect or '',
                word.gender or '',
                word.is_animacy if word.is_animacy is not None else '',
                word.level or '',
                word.frequency or '',
                json.dumps(word.meanings, ensure_ascii=False) if word.meanings else '',
                json.dumps(word.forms, ensure_ascii=False) if word.forms else '',
                json.dumps(word.examples, ensure_ascii=False) if word.examples else '',
                json.dumps(word.collocations, ensure_ascii=False) if word.collocations else '',
                word.index_words or '',
                word.root1_id or '',
                word.root2_id or '',
                word.root3_id or '',
                word.category_id or '',
                word.create_time.strftime('%Y-%m-%d %H:%M:%S') if word.create_time else ''
            ]
            writer.writerow(row)
        return response

    @staticmethod
    def export_all_to_csv(modeladmin, request, queryset):
        """导出所有单词为CSV（Admin action）"""
        all_words = LexiconWord.objects.all()
        return LexiconWordImportExport.export_to_csv(all_words)

    @staticmethod
    def _parse_foreign_key(value):
        """解析外键值"""
        value_str = (value or '').strip()
        return int(value_str) if value_str else None

    @staticmethod
    def _parse_frequency(value):
        """解析频率值"""
        value_str = (value or '').strip()
        return int(value_str) if value_str else None

    @staticmethod
    def _parse_boolean(value):
        """解析布尔值"""
        value_str = (value or '').strip().lower()
        if value_str in ('true', '1', 'yes', 'True'):
            return True
        elif value_str in ('false', '0', 'no', 'False'):
            return False
        return None

    @staticmethod
    def _parse_json_field(value):
        """解析JSON字段"""
        value_str = (value or '').strip()
        if not value_str:
            return None
        return json.loads(value_str)

    @staticmethod
    def _build_word_data(row):
        """构建单词数据字典"""
        return {
            'lemma': row.get('lemma', '').strip(),
            'accented': row.get('accented', '').strip() or None,
            'gloss': row.get('gloss', '').strip() or None,
            'pos': row.get('pos', '').strip() or None,
            'pos_tags': row.get('pos_tags', '').strip() or None,
            'aspect': row.get('aspect', '').strip() or None,
            'gender': row.get('gender', '').strip() or None,
            'is_animacy': LexiconWordImportExport._parse_boolean(row.get('is_animacy', '')),
            'level': row.get('level', '').strip() or None,
            'frequency': LexiconWordImportExport._parse_frequency(row.get('frequency', '')),
            'meanings': LexiconWordImportExport._parse_json_field(row.get('meanings', '')),
            'forms': LexiconWordImportExport._parse_json_field(row.get('forms', '')),
            'examples': LexiconWordImportExport._parse_json_field(row.get('examples', '')),
            'collocations': LexiconWordImportExport._parse_json_field(row.get('collocations', '')),
            'index_words': row.get('index_words', '').strip() or None,
            'root1_id': LexiconWordImportExport._parse_foreign_key(row.get('root1_id', '')),
            'root2_id': LexiconWordImportExport._parse_foreign_key(row.get('root2_id', '')),
            'root3_id': LexiconWordImportExport._parse_foreign_key(row.get('root3_id', '')),
            'category_id': LexiconWordImportExport._parse_foreign_key(row.get('category_id', ''))
        }

    @staticmethod
    def _process_import_row(row, row_num, stats):
        """处理单行导入数据"""
        word_data = LexiconWordImportExport._build_word_data(row)
        if not word_data['lemma']:
            stats['errors'].append(f"第{row_num}行: lemma 字段为空")
            stats['error_count'] += 1
            return
        word_id = row.get('id', '').strip()
        LexiconWordImportExport._create_or_update_word(word_id, word_data, stats)

    @staticmethod
    def _create_or_update_word(word_id, word_data, stats):
        """创建或更新单词"""
        if not word_id:
            LexiconWord.objects.create(**word_data)
            stats['created_count'] += 1
            return
        word = LexiconWord.objects.filter(id=int(word_id)).first()
        if word:
            for key, value in word_data.items():
                setattr(word, key, value)
            word.save()
            stats['updated_count'] += 1
        else:
            LexiconWord.objects.create(**word_data)
            stats['created_count'] += 1

    @staticmethod
    def _show_import_messages(modeladmin, request, stats):
        """显示导入结果消息"""
        if stats['created_count'] > 0:
            modeladmin.message_user(request, f"成功创建 {stats['created_count']} 条记录", messages.SUCCESS)
        if stats['updated_count'] > 0:
            modeladmin.message_user(request, f"成功更新 {stats['updated_count']} 条记录", messages.SUCCESS)
        if stats['error_count'] > 0:
            modeladmin.message_user(request, f"失败 {stats['error_count']} 条记录", messages.WARNING)
            for error in stats['errors'][:10]:
                modeladmin.message_user(request, error, messages.ERROR)

    @staticmethod
    @transaction.atomic
    def import_from_csv(modeladmin, request, queryset):
        """从CSV文件导入单词（Admin action）"""
        csv_file = request.FILES.get('csv_file')
        if not csv_file:
            modeladmin.message_user(request, '请先上传CSV文件', messages.ERROR)
            return
        if not csv_file.name.endswith('.csv'):
            modeladmin.message_user(request, '文件格式错误，请上传CSV文件', messages.ERROR)
            return

        decoded_file = csv_file.read().decode('utf-8-sig')
        reader = csv.DictReader(io.StringIO(decoded_file))
        stats = {'created_count': 0, 'updated_count': 0, 'error_count': 0, 'errors': []}
        for row_num, row in enumerate(reader, start=2):
            LexiconWordImportExport._process_import_row(row, row_num, stats)
        LexiconWordImportExport._show_import_messages(modeladmin, request, stats)
