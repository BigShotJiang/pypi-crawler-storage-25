# encoding: utf-8
"""
@project: exam urls
@author:
@Email:
@synopsis: 考试模块路由分发
@created_time: 2026
"""

from django.urls import re_path
from .apis.lexicon_word_list_api import LexiconWordListAPI
from .apis.lexicon_word_api import LexiconWordAPI
from .apis.lexicon_category_list_api import LexiconCategoryListAPI
from .apis.lexicon_note_api import LexiconNoteAPI, LexiconNoteKnownListAPI, LexiconNoteStatisticAPI, LexiconNoteKnownsByKeysAPI
from .apis.lexicon_wordbook_api import LexiconWordbookListAPI
from .apis.lexicon_article_list_api import LexiconArticleListAPI
from .apis.lexicon_article_api import LexiconArticleAPI

# 应用名称
app_name = 'lexicon'

urlpatterns = [
    re_path(r'^word_list/?$', LexiconWordListAPI.as_view(), name='单词列表'),
    re_path(r'^word/?$', LexiconWordAPI.as_view(), name='字典详情'),
    re_path(r'^category_list/?$', LexiconCategoryListAPI.as_view(), name='单词分类列表'),

    # ==================== 用户相关 ====================
    re_path(r'^note?$', LexiconNoteAPI.as_view(), name='用户记忆'),
    re_path(r'^note?$', LexiconNoteAPI.as_view(), name='批量添加/更新单词掌握状态'),
    re_path(r'^note_known?$', LexiconNoteKnownListAPI.as_view(), name='按掌握程度筛选单词ID'),
    re_path(r'^note_statistic?$', LexiconNoteStatisticAPI.as_view(), name='用户学习统计'),
    # ==================== 词集相关 ====================
    re_path(r'^wordbook_list?$', LexiconWordbookListAPI.as_view(), name='词集列表'),
    re_path(r'^note_knowns_by_keys/?$', LexiconNoteKnownsByKeysAPI.as_view(), name='获取指定单词的掌握状态'),
    # ==================== 文章相关 ====================
    re_path(r'^article_list/?$', LexiconArticleListAPI.as_view(), name='文章列表'),

    re_path(r'^article_item?$', LexiconArticleAPI.as_view(), name='文章列表')
]