"""Bundled composer manifest data."""
