"""
설정 파일 관리 및 API 키 우선순위 처리.

우선순위 (높은 순):
  1. CLI --api-key 옵션 (일회성 override)
  2. USPTO_API_KEY 환경변수 (CI/CD, shell profile)
  3. ~/.oa-cli.toml [auth] api_key  (oa configure 로 저장)

개발 환경에서는 python-dotenv가 설치된 경우 .env를 자동 로드해
환경변수(2번)로 처리된다. 배포 환경에서는 dotenv 없이도 정상 동작.
"""

import os
import sys
import tomllib
from pathlib import Path
from typing import Optional

CONFIG_PATH = Path.home() / ".oa-cli.toml"


def load() -> dict:
    """~/.oa-cli.toml 을 읽어 dict 반환. 파일 없으면 빈 dict."""
    if not CONFIG_PATH.exists():
        return {}
    with open(CONFIG_PATH, "rb") as f:
        return tomllib.load(f)


def save(config: dict) -> None:
    """config dict 를 ~/.oa-cli.toml 에 저장."""
    CONFIG_PATH.write_text(_dump_toml(config), encoding="utf-8")


def resolve_api_key(cli_key: Optional[str] = None) -> str:
    """API 키를 우선순위에 따라 결정해 반환. 없으면 빈 문자열."""
    if cli_key:
        return cli_key

    _try_load_dotenv()
    env_key = os.getenv("USPTO_API_KEY", "")
    if env_key:
        return env_key

    cfg = load()
    return cfg.get("auth", {}).get("api_key", "")


def require_api_key(cli_key: Optional[str] = None) -> str:
    """API 키를 반환. 없으면 오류 메시지 출력 후 종료."""
    key = resolve_api_key(cli_key)
    if not key:
        import click
        click.echo(
            "오류: USPTO API 키가 설정되지 않았습니다.\n"
            "\n"
            "다음 중 하나로 설정하세요:\n"
            "  uspto-oa configure             # 설정 파일에 저장 (권장)\n"
            "  export USPTO_API_KEY=..        # 환경변수\n"
            "  uspto-oa download --api-key KEY <app_number>  # 일회성 옵션",
            err=True,
        )
        sys.exit(1)
    return key


def mask_key(key: str) -> str:
    """API 키를 마스킹하여 반환 (끝 4자리만 표시)."""
    if not key:
        return "(없음)"
    if len(key) <= 4:
        return "****"
    return "****" + key[-4:]


def _try_load_dotenv() -> None:
    """python-dotenv 가 설치된 경우(개발 환경)에만 .env 를 로드."""
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass


def _dump_toml(config: dict) -> str:
    """config dict 를 TOML 문자열로 직렬화 (tomllib 은 read-only 라 직접 구현)."""
    lines: list[str] = []
    for section, values in config.items():
        if not isinstance(values, dict):
            continue
        lines.append(f"[{section}]")
        for key, val in values.items():
            if val is None or val == "":
                continue
            if isinstance(val, bool):
                lines.append(f"{key} = {'true' if val else 'false'}")
            elif isinstance(val, (int, float)):
                lines.append(f"{key} = {val}")
            else:
                escaped = str(val).replace("\\", "\\\\").replace('"', '\\"')
                lines.append(f'{key} = "{escaped}"')
        lines.append("")
    return "\n".join(lines)
