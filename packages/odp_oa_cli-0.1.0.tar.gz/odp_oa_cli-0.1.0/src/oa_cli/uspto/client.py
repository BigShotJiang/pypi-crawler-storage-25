"""USPTO ODP API HTTP 클라이언트 (재시도/백오프 포함)."""

import time
import logging
import requests
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def make_api_request(
    url: str,
    api_key: str,
    params: Optional[Dict[str, Any]] = None,
    timeout: int = 30,
    retries: int = 3,
    backoff_factor: float = 1.0,
) -> Dict[str, Any]:
    headers = {
        "X-API-KEY": api_key,
        "accept": "application/json",
    }
    for i in range(retries):
        try:
            logger.debug(f"GET {url}  params={params}")
            resp = requests.get(url, headers=headers, params=params, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.HTTPError as e:
            if e.response.status_code in (429, 500, 502, 503, 504) and i < retries - 1:
                wait = backoff_factor * (2 ** i)
                logger.warning(f"HTTP {e.response.status_code}, {wait:.0f}초 후 재시도...")
                time.sleep(wait)
            else:
                logger.error(f"API 요청 실패: {e}")
                raise
        except requests.RequestException as e:
            logger.error(f"API 요청 실패: {e}")
            raise
    raise RuntimeError("재시도 횟수 초과")
