"""출원 문서 목록 조회 엔드포인트 래퍼."""

import logging
from typing import Any, Dict

from oa_cli.uspto.client import make_api_request

logger = logging.getLogger(__name__)

BASE_URL = "https://api.uspto.gov/api/v1/patent"


def get_application_documents(
    api_key: str,
    application_number: str,
    timeout: int = 30,
) -> Dict[str, Any]:
    """출원번호에 해당하는 전체 문서 목록을 반환."""
    url = f"{BASE_URL}/applications/{application_number}/documents"
    return make_api_request(url, api_key, timeout=timeout)
