"""파일 스트리밍 다운로드 유틸 (재시도/백오프 포함)."""

import time
import logging
from pathlib import Path
from typing import Optional

import requests

logger = logging.getLogger(__name__)


def download_bytes(
    url: str,
    api_key: str,
    retries: int = 5,
    backoff_factor: float = 1.0,
    timeout: int = 120,
) -> bytes:
    """URL에서 파일을 다운로드해 bytes로 반환 (tar 등 중간 처리가 필요한 경우)."""
    headers = {"x-api-key": api_key}
    for attempt in range(retries):
        try:
            resp = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
            resp.raise_for_status()
            return resp.content
        except requests.HTTPError as e:
            if e.response.status_code in (429, 500, 502, 503, 504) and attempt < retries - 1:
                wait = backoff_factor * (2 ** attempt)
                logger.warning(f"HTTP {e.response.status_code}, {wait:.0f}초 후 재시도...")
                time.sleep(wait)
            else:
                raise
        except requests.RequestException as e:
            if attempt < retries - 1:
                wait = backoff_factor * (2 ** attempt)
                logger.warning(f"요청 오류 ({e}), {wait:.0f}초 후 재시도...")
                time.sleep(wait)
            else:
                raise
    raise RuntimeError(f"다운로드 재시도 횟수 초과: {url}")


def download_file(
    url: str,
    api_key: str,
    save_path: str,
    retries: int = 5,
    backoff_factor: float = 1.0,
    timeout: int = 120,
) -> str:
    """URL에서 파일을 다운로드해 save_path에 저장하고 경로를 반환."""
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    headers = {"x-api-key": api_key}

    for attempt in range(retries):
        try:
            resp = requests.get(url, headers=headers, stream=True, timeout=timeout, allow_redirects=True)
            resp.raise_for_status()
            with open(save_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    f.write(chunk)
            logger.debug(f"저장 완료: {save_path}")
            return save_path
        except requests.HTTPError as e:
            if e.response.status_code in (429, 500, 502, 503, 504) and attempt < retries - 1:
                wait = backoff_factor * (2 ** attempt)
                logger.warning(f"HTTP {e.response.status_code}, {wait:.0f}초 후 재시도...")
                time.sleep(wait)
            else:
                raise
        except requests.RequestException as e:
            if attempt < retries - 1:
                wait = backoff_factor * (2 ** attempt)
                logger.warning(f"요청 오류 ({e}), {wait:.0f}초 후 재시도...")
                time.sleep(wait)
            else:
                raise

    raise RuntimeError(f"다운로드 재시도 횟수 초과: {url}")
