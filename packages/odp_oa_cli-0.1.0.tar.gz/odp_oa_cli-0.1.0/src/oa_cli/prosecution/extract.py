"""다운로드된 XML 파일 파싱 → 심사과정 분석 MD 생성."""

import re
import logging
from pathlib import Path
from typing import Optional
import xml.etree.ElementTree as ET

logger = logging.getLogger(__name__)

USCOM = "{urn:us:gov:doc:uspto:common}"

CODE_LABELS = {
    "CTNF": "Non-Final Rejection",
    "CTFR": "Final Rejection",
    "NOA":  "Notice of Allowance",
    "NACT": "Notice of Allowance",
    "IDS":  "Information Disclosure Statement",
    "REM":  "Remarks",
    "ABST": "Abstract",
    "CLM":  "Claims",
    "SPEC": "Specification",
}

# FormParagraph 번호 분류
_FP_REJECTION      = "07-21-aia"   # 거절 항목 (CTNF/CTFR)
_FP_FINAL_FLAG     = "07-39"       # Final Action 선언
_FP_ALLOWED_CLAIMS = "12-151-07"   # 허여 청구항
_FP_ALLOW_REASON   = "13-03"       # 허여 이유 (Examiner's Statement)


# ── 텍스트 정규화 ────────────────────────────────────────────────

def _fp_text(fp_el) -> str:
    """FormParagraph 요소의 텍스트를 정규화해서 반환."""
    raw = " ".join(fp_el.itertext())
    text = re.sub(r"\s+", " ", raw).strip()
    text = re.sub(r"^[\w\.\-]+ (?:AIA )?", "", text, count=1)
    return text


def _all_text(root) -> str:
    """루트 하위 전체 텍스트 추출 및 정규화."""
    return re.sub(r"\s+", " ", " ".join(root.itertext())).strip()


# ── 문서 타입별 파서 ─────────────────────────────────────────────

def _fp_iter(root, number: str):
    for fp in root.iter(f"{USCOM}FormParagraph"):
        num_el = fp.find(f"{USCOM}FormParagraphNumber")
        if num_el is not None and (num_el.text or "").strip() == number:
            yield fp


def _parse_oa(root) -> dict:
    """CTNF / CTFR: 거절 항목 파싱."""
    rejections = [_fp_text(fp) for fp in _fp_iter(root, _FP_REJECTION)]
    is_final = any(True for _ in _fp_iter(root, _FP_FINAL_FLAG))
    return {
        "is_final": is_final,
        "rejections": rejections,
    }


def _parse_noa(root) -> dict:
    """NOA: 허여 청구항 + 허여 이유 파싱."""
    allowed = next((_fp_text(fp) for fp in _fp_iter(root, _FP_ALLOWED_CLAIMS)), "")
    reason  = next((_fp_text(fp) for fp in _fp_iter(root, _FP_ALLOW_REASON)),   "")
    return {
        "allowed_claims": allowed,
        "reason": reason,
    }


# ── 파일 단위 파서 ────────────────────────────────────────────────

def parse_xml_file(xml_path: Path) -> Optional[dict]:
    """
    XML 파일 1개를 파싱해 구조화된 dict로 반환.

    Returns None if the file is not a parseable prosecution document.
    """
    stem_parts = xml_path.stem.split("_", 2)
    if len(stem_parts) < 2:
        return None
    date, code = stem_parts[0], stem_parts[1]
    doc_id = stem_parts[2] if len(stem_parts) > 2 else ""

    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
    except ET.ParseError as e:
        logger.warning(f"XML 파싱 실패 {xml_path.name}: {e}")
        return None

    base = {
        "date":   date,
        "code":   code,
        "doc_id": doc_id,
        "label":  CODE_LABELS.get(code, code),
        "path":   str(xml_path),
        "fmt":    "xml",
    }

    if code in ("CTNF", "CTFR"):
        return {**base, **_parse_oa(root)}
    if code in ("NOA", "NACT"):
        return {**base, **_parse_noa(root)}

    return None


# ── 타임라인 조합 ────────────────────────────────────────────────

def build_timeline(app_number: str, file_dir: Optional[str] = None) -> list[dict]:
    """
    file_dir 내 모든 파일(.xml / .pdf)을 날짜순으로 정리해 타임라인 리스트를 반환.
    XML 파싱 가능 문서는 파싱 결과를 포함하고, PDF는 경로 참조만 포함한다.
    """
    if file_dir is None:
        file_dir = str(Path.cwd() / "file" / app_number)

    base_dir = Path(file_dir)
    entries: dict[str, dict] = {}

    for f in sorted(base_dir.glob("*.pdf")):
        stem_parts = f.stem.split("_", 2)
        if len(stem_parts) < 2:
            continue
        date, code = stem_parts[0], stem_parts[1]
        doc_id = stem_parts[2] if len(stem_parts) > 2 else ""
        key = f"{date}_{code}_{doc_id}"
        entries[key] = {
            "date": date, "code": code, "doc_id": doc_id,
            "label": CODE_LABELS.get(code, code),
            "path": str(f), "fmt": "pdf",
        }

    for f in sorted(base_dir.glob("*.xml")):
        stem_parts = f.stem.split("_", 2)
        if len(stem_parts) < 2:
            continue
        date, code = stem_parts[0], stem_parts[1]
        doc_id = stem_parts[2] if len(stem_parts) > 2 else ""
        key = f"{date}_{code}_{doc_id}"
        parsed = parse_xml_file(f)
        if parsed:
            entries[key] = parsed
        else:
            entries[key] = {
                "date": date, "code": code, "doc_id": doc_id,
                "label": CODE_LABELS.get(code, code),
                "path": str(f), "fmt": "xml",
            }

    return sorted(entries.values(), key=lambda x: x["date"])


# ── MD 렌더러 ─────────────────────────────────────────────────────

def render_md(app_number: str, timeline: list[dict]) -> str:
    lines: list[str] = []

    lines += [f"# 심사과정 분석 — {app_number}", ""]

    lines += ["## 타임라인", ""]
    lines += ["| 날짜 | 문서 | 형식 | 파일 |"]
    lines += ["|------|------|:----:|------|"]
    for e in timeline:
        lines.append(
            f"| {e['date']} | {e['label']} (`{e['code']}`) "
            f"| {e['fmt'].upper()} | `{Path(e['path']).name}` |"
        )
    lines += [""]

    oa_docs = [e for e in timeline if e["code"] in ("CTNF", "CTFR") and "rejections" in e]
    if oa_docs:
        lines += ["---", "## Office Action 상세", ""]
        for doc in oa_docs:
            oa_type = "Final Rejection" if doc.get("is_final") else "Non-Final Rejection"
            lines += [f"### {oa_type} — {doc['date']}", ""]
            for i, rej in enumerate(doc["rejections"], 1):
                lines += [f"**거절 {i}**", "", rej, ""]

    noa_docs = [e for e in timeline if e["code"] in ("NOA", "NACT") and "allowed_claims" in e]
    if noa_docs:
        lines += ["---", "## Notice of Allowance 상세", ""]
        for doc in noa_docs:
            lines += [f"### {doc['date']}", ""]
            if doc.get("allowed_claims"):
                lines += ["**허여 청구항**", "", doc["allowed_claims"], ""]
            if doc.get("reason"):
                lines += ["**허여 이유 (Examiner's Statement)**", "", doc["reason"], ""]

    pdf_only = [e for e in timeline if e["fmt"] == "pdf" and "rejections" not in e and "allowed_claims" not in e]
    if pdf_only:
        lines += ["---", "## PDF 전용 문서 (텍스트 추출 불가)", ""]
        lines += ["아래 파일은 이미지 PDF로 구성되어 자동 파싱이 불가합니다. AI 에이전트에 직접 전달하세요.", ""]
        lines += ["| 날짜 | 문서 | 파일 |"]
        lines += ["|------|------|------|"]
        for e in pdf_only:
            lines.append(f"| {e['date']} | {e['label']} (`{e['code']}`) | `{Path(e['path']).name}` |")
        lines += [""]

    return "\n".join(lines)


# ── 진입점 ────────────────────────────────────────────────────────

def extract(
    app_number: str,
    file_dir: Optional[str] = None,
    output_path: Optional[str] = None,
) -> str:
    """다운로드된 파일을 파싱해 MD 문자열을 반환하고, output_path가 지정되면 파일로 저장."""
    timeline = build_timeline(app_number, file_dir)
    md = render_md(app_number, timeline)

    if output_path:
        Path(output_path).write_text(md, encoding="utf-8")
        logger.info(f"저장 완료: {output_path}")

    return md
