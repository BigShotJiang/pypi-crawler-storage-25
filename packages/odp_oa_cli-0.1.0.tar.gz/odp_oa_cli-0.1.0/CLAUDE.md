# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 프로젝트 개요

USPTO ODP(Open Data Portal) API를 통해 미국 특허 심사과정 문서를 다운로드하고, XML 파싱을 거쳐 구조화된 Markdown으로 변환하는 CLI 도구. AI 에이전트(Claude Code, Gemini CLI)가 생성된 MD 파일을 읽고 심사 전략을 분석하는 워크플로우를 목표로 한다. LLM API 직접 호출은 최소화하고 AI 코딩 에이전트에게 분석을 위임하는 방식을 지향한다.

## 실행 명령

```bash
# 의존성 설치
uv sync

# API 키 설정 (최초 1회) → ~/.oa-cli.toml 에 저장
uv run uspto-oa configure

# 문서 다운로드
uv run uspto-oa download 16330077

# XML 파싱 → MD 생성 (file/{app_num}/{app_num}_prosecution.md)
uv run uspto-oa extract 16330077

# 특허번호 입력 (출원번호 자동 변환)
uv run uspto-oa download US12228644B2

# 특정 문서 코드만 다운로드
uv run uspto-oa download 16330077 --doc-codes CTNF,CTFR,NOA

# 강제 재다운로드
uv run uspto-oa download 16330077 --force

# 상세 로그
uv run uspto-oa -v download 16330077

# PyPI 배포 (빌드 → 업로드)
uv build && uv run twine upload dist/*
```

**API 키 우선순위**: `--api-key` 옵션 > `USPTO_API_KEY` 환경변수 > `~/.oa-cli.toml` (개발 시 `.env` 자동 로드)

## 소스 구조

```
src/oa_cli/                 # PyPI 배포 패키지 (hatchling wheel 타겟)
├── __init__.py             # __version__
├── __main__.py             # python -m oa_cli 지원
├── cli.py                  # click 진입점 (configure / download / extract 커맨드)
├── config.py               # API 키 우선순위 관리, ~/.oa-cli.toml 읽기/쓰기
├── uspto/                  # USPTO ODP API 저수준 클라이언트 (도메인 무관)
│   ├── client.py           # make_api_request() — GET + 재시도/백오프
│   ├── documents.py        # get_application_documents() — 문서 목록 API
│   └── download.py         # download_file() / download_bytes()
└── prosecution/            # 심사과정 분석 도메인 로직
    ├── collect.py          # 문서 필터링 + XML 우선 일괄 다운로드
    └── extract.py          # XML 파싱 → prosecution.md 생성
file/
└── {app_num}/              # 다운로드 파일 + 생성된 MD 저장 위치
```

## 아키텍처 핵심 사항

**레이어 분리**: `src/uspto/`는 API 통신만 담당(도메인 무관), `src/prosecution/`은 심사과정 비즈니스 로직 담당. `cli.py`는 두 레이어를 연결하는 진입점.

**서버사이드 필터 미사용**: USPTO API의 `documentCodes` 파라미터가 500 오류를 유발하므로, 전건 조회 후 클라이언트에서 필터링한다(`collect.py`의 `PROSECUTION_CODES_EXACT` / `PROSECUTION_CODE_PREFIXES`).

**파일명 규칙**: `{날짜}_{코드}_{문서ID}.{ext}` — 날짜 오름차순 정렬, 확장자는 실제 포맷 반영.

**다운로드 우선순위**: XML > PDF (MS_WORD 제외). XML은 tar 아카이브로 전달되므로 압축 해제 후 저장하며, tar 내 `.xml` 없거나 오류 시 PDF로 자동 폴백.

**XML 구조 (USPTO ST96 스키마)**: CTNF/CTFR는 `FormParagraph[07-21-aia]`에 거절 항목, NOA/NACT는 `FormParagraph[12-151-07]`에 허여 청구항, `FormParagraph[13-03]`에 Examiner's Statement 포함.

**PDF 특이사항**: USPTO OA PDF는 전 페이지 이미지 구성 → pypdf 텍스트 추출 불가. PDF 전용 문서(Amendment 등)는 MD에 경로만 참조로 포함하고 AI 에이전트가 필요 시 직접 읽도록 한다.

**생성 MD 구조** (`{app_num}_prosecution.md`):
- 타임라인 표 (전체 문서, XML/PDF 형식 표시)
- Office Action 상세 (CTNF/CTFR 거절 항목 전문)
- Notice of Allowance 상세 (허여 청구항 + Examiner's Statement)
- PDF 전용 문서 목록 (AI 에이전트 직접 전달용)

## 다음 구현 단계

- `--step summary/detail/prior-art/strategy` — 생성된 prosecution.md를 AI 에이전트에 넘기는 분석 진입점 (LLM API 직접 호출 없이 Claude Code / Gemini CLI에 위임)
- `--no-download` — 이미 다운로드된 파일 기준으로 `--extract` 바로 수행
