import os
import shutil
import sys
from setuptools import setup

def copy_template():
    # Only copy if the source 'src' directory exists at the root.
    # If it doesn't exist, we are likely building from an sdist where
    # the template files are already inside the package.
    if not os.path.exists('project_src'):
        print("Source 'src' directory not found. Skipping template copy.")
        return

    package_dir = 'ziyodev_django'
    template_dir = os.path.join(package_dir, 'template')
    
    # Remove existing template folder to ensure clean copy
    if os.path.exists(template_dir):
        shutil.rmtree(template_dir)
    
    # Copy src directory
    shutil.copytree('project_src', os.path.join(template_dir), ignore=shutil.ignore_patterns('*.sqlite3', 'venv', ".git", ".gitignore", "README.md"))
    
    """
    # Copy other files
    files_to_copy = ['requirements.txt', '.gitignore', 'README.md']
    for file in files_to_copy:
        if os.path.exists(file):
            shutil.copy(file, template_dir)
            print(f"Copied {file} to template directory")
    """

# Trigger copy only if building packages
if any(arg in sys.argv for arg in ['sdist', 'bdist_wheel', 'build', 'egg_info']):
    print("template packetlar qo'shilmoqda...")
    copy_template()

setup()

