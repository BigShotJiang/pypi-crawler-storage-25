# Ziyodev Django

Production-ready Django starter template with authentication system, REST API support, deployment configuration, and scalable project structure.

This template is designed for quickly building modern Django applications with clean architecture and reusable components.

---

# Features

- Django REST Framework
- Authentication system
- Login / Register
- Forget password
- Change password
- Change email
- OTP verification
- SMTP email integration
- Environment variables support
- Jazzmin admin panel
- Gunicorn configuration
- Nginx deployment config
- Modular architecture
- Ready for production

---

# Project Structure

```bash
project/
│
├── deployment/
│   ├── gunicorn.service
│   ├── gunicorn.socket
│   └── nginx.conf
│
├── src/
│   ├── api/
│   ├── apps/
│   ├── config/
│   ├── images/
│   ├── requirements/
│   ├── static/
│   ├── templates/
│   ├── .env
│   ├── .env.example
│   ├── db.sqlite3
│   └── manage.py
│
├── venv/
├── .gitignore
└── README.md
```

---

# Installation

## 1. Install package

```bash
pip install ziyodev-django
```

---

# Create New Project

Initialize new Django project:

```bash
ziyodev-django init .
```

---

# Virtual Environment if not exists

## Linux / macOS

Create venv:

```bash
python3 -m venv venv
```

Activate:

```bash
source venv/bin/activate
```

---

## Windows

Create venv:

```bash
python -m venv venv
```

Activate:

```bash
venv\Scripts\activate
```

---

# Install Requirements

```bash
pip install -r src/requirements/dev.txt
```

---

# Run migrations:

```bash
cd src
python manage.py migrate
```

Create superuser:

```bash
python manage.py createsuperuser
```

---

# Run Development Server

```bash
python manage.py runserver
```

Server:

```txt
http://127.0.0.1:8000/
```

---

# Authentication System

Included authentication features:

- User registration
- Login
- Logout
- Forget password
- Change password
- Change email
- OTP verification
- Email verification
- SMTP integration

---

# Deployment

Deployment configurations included:

```bash
deployment/
```

Contains:

- `gunicorn.service`
- `gunicorn.socket`
- `nginx.conf`

Suitable for:

- Ubuntu Server
- Nginx
- Gunicorn
- Systemd

---

# Admin Panel

Jazzmin admin panel included.

Admin URL:

```txt
/admin/
```

---

# API Support

Django REST Framework preconfigured.

Create APIs inside:

```bash
src/api/
```

---

# Static & Media Files

Static files:

```bash
src/static/
```

Images:

```bash
src/images/
```

Templates:

```bash
src/templates/
```

---

# Installed Packages

Main packages included:

- Django
- Django REST Framework
- Django Environ
- Django Jazzmin
- Gunicorn

---

# Production

Install production requirements:

```bash
pip install -r src/requirements/prod.txt
```

Collect static files:

```bash
python manage.py collectstatic
```

---

# License

MIT License

---

# Author

Ziyodullo Aliyev

GitHub:
https://github.com/Ziyodullodev

---

Happy coding 🚀