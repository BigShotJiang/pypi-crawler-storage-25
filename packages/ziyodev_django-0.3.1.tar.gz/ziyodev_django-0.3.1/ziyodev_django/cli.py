import shutil
import sys
from pathlib import Path


def main():
    if len(sys.argv) < 3:
        print("Usage:")
        print("ziyodev-django init project_name")
        return

    command = sys.argv[1]
    project_name = sys.argv[2]

    if command == "init":
        current_dir = Path(__file__).parent
        template_dir = current_dir / "template"

        if not template_dir.exists():
            print(f"Xato: '{template_dir}' papkasi topilmadi!")
            return

        target_path = Path(project_name).resolve()
        print(f"Boshlandi! '{target_path.name}' loyihasi yaratilmoqda...")

        try:
            shutil.copytree(template_dir, target_path, dirs_exist_ok=True)
            
            # ANSI rang kodlari: 
            # \033[92m - yashil rang boshlanishi
            # \033[0m  - rangni qayta tiklash (reset)
            YASHIL = "\033[92m"
            RESET = "\033[0m"
            
            print(f"{YASHIL}Project '{target_path.name}' created successfully!{RESET}")
            
        except Exception as e:
            # Xatolikni esa qizil rangda chiqaramiz (\033[91m)
            QIZIL = "\033[91m"
            RESET = "\033[0m"
            print(f"{QIZIL}Nusxalashda xatolik yuz berdi: {e}{RESET}")