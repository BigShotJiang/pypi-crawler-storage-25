from typing import Any, TYPE_CHECKING

from zoe_http.code import HttpCode
from zoe_http._response_util.response_header import ResponseHeader
from zoe_http._response_util.response_cookies import CookiePair, CookieAttributes, ResponseCookie

if TYPE_CHECKING:
    from zoe_http._response_util._pagination import Filter
    from zoe_http.request import Request

class Response:
    def __init__(self, http_code: HttpCode, headers: dict[str, Any] | None = None) -> None:
        self.__http_version: str = "HTTP/1.1"
        self.__status_code = http_code
        self.__response_header: ResponseHeader = ResponseHeader(headers=headers)

    def add_header(self, name: str, value: str) -> "Response":
        self.headers.add(name, value)
        return self

    def add_cookie(self, pair: CookiePair, attrs: CookieAttributes | None = None) -> "Response":
        self.headers.cookies.add(pair, attrs)
        return self

    @property
    def status_code(self) -> HttpCode:
        return self.__status_code

    @property
    def headers(self) -> ResponseHeader:
        return self.__response_header

    def _build(self) -> bytes:
        response_message = self._status_line()
        response_message = self.__response_header._build(to_append=response_message)
        return response_message.encode("utf-8")

    def _status_line(self) -> str:
        return f"{self.__http_version} {self.__status_code.code} {self.__status_code.message}" + "\r\n"

    def _content_line(self, content_type: str, body: str) -> str:
        encoded = body.encode("utf-8")
        content_line: str = ""
        content_line += f"Content-Type: {content_type}\r\n"
        content_line += f"Content-Length: {len(encoded)}\r\n"
        return content_line

    @classmethod
    def json(cls,
             http_code: HttpCode,
             body: Any,
             headers: dict[str, Any] | None = None
            ) -> "Json": # type: ignore
        from zoe_http._response_util.response_json import Json
        return Json(http_code=http_code, body=body, headers=headers)

    @classmethod
    def text(cls,
             http_code: HttpCode,
             body: Any,
             charset: str = "utf-8",
             headers: dict[str, Any] | None = None
            ) -> "PlainText": # type: ignore
        from zoe_http._response_util.response_text import PlainText
        return PlainText(http_code=http_code, text=body, charset=charset, headers=headers)

    @classmethod
    def html(cls,
             body: Any,
             http_code: HttpCode = HttpCode.OK,
             charset: str = "utf-8",
             headers: dict[str, Any] | None = None
            ) -> "Html": # type: ignore
        from zoe_http._response_util.response_html import Html
        return Html(http_code=http_code, html_content=body, charset=charset, headers=headers)

    @classmethod
    def redirect(cls,
                 redirect_to: str,
                 http_code: HttpCode = HttpCode.FOUND,
                 headers: dict[str, Any] | None = None
                ) -> "Redirect": # type: ignore
        from zoe_http._response_util.response_redirect import Redirect
        return Redirect(http_code=http_code, redirect_to=redirect_to, headers=headers)

    @classmethod
    def file(cls,
             filename: str,
             http_code: HttpCode = HttpCode.OK,
             directory: str | None = None,
             force_download: bool = False,
             headers: dict[str, Any] | None = None
            ) -> "File": # type: ignore
        from zoe_http._response_util.response_file import File
        return File(filename=filename, directory=directory, force_download=force_download, headers=headers, http_code=http_code)

    @classmethod
    def paginated(cls,
                  items: list[Any],
                  request: "Request",
                  per_page: int | None = None,
                  filters: list["Filter"] | None = None,
                  headers: dict[str, Any] | None = None,
                  http_code: HttpCode = HttpCode.OK
        ) -> "Paginated": # type: ignore
        from zoe_http._response_util.response_paginated import Paginated, Pagination

        pagination = Pagination(
        items=items,
        request=request,
        total=len(items),
        perpage=per_page,
        filters=filters
        )

        return Paginated(
            items=items,
            headers=headers,
            http_code=http_code,
            pagination=pagination
            )

    @classmethod
    def empty(cls) -> "Empty": # type: ignore
        from zoe_http._response_util.response_empty import Empty
        return Empty()
