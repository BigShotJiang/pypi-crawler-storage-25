from zoe import App, Router, HttpCode, Response, Request, on_error, DomainException, Guard, BearerStrategy, JWT_HS256

class TestOnError(DomainException):
  def __init__(self) -> None:
    super().__init__(http_code=HttpCode.INTERNAL_SERVER_ERROR)

  def to_body(self, request):
    return {
      "erro": "alguma"
    }

  def to_response(self, request):
    return Response.json(http_code=self.status_code, body=self.to_body(request))

@on_error(TestOnError)
def testando_error(exception: DomainException, request: Request) -> Response:
  return exception(request)

router: Router = Router("/")
@router.get("/test")
def test(req: Request) ->Response:
  raise TestOnError()

token = JWT_HS256(secret="secret-key-super-secreta-12345-67890", issued_by="zoe-framework", expires_min=180)
print(token.encode())
App().use(router.use(Guard(BearerStrategy(validator=token)))).listen()
