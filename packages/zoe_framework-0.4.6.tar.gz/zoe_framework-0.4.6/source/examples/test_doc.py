from zoe import (
    Request, Response, Server, App, Router, HttpCode,
    Model, Field, NotNull, Email, Min, Max, UUID, Singleton, Lifecycle, Guard, BearerStrategy, doc, JWT_HS256, JWT_Claim
)
from zoe_doc import *
from typing import Any
import uuid as _uuid
import time


# ══════════════════════════════════════════════════════════════
#  MODELS
# ══════════════════════════════════════════════════════════════

class CreateUserDto(Model):
    id:         str  = Field(generator=UUID())
    name:       str  = Field(NotNull(), Min(2), Max(80))
    email:      str  = Field(NotNull(), Email())
    password:   str  = Field(NotNull(), Min(8))
    role:       str  = Field(default="member")

    @property
    def example(self) -> dict[str, Any] | None:
        return {"name": "Lucas Brites", "email": "lucas@zoe.io", "password": "Zoe@2024!", "role": "member"}

class UpdateUserDto(Model):
    name:   str | None = Field(default=None)
    email:  str | None = Field(default=None)
    role:   str | None = Field(default=None)

    @property
    def example(self) -> dict[str, Any] | None:
        return {"name": "Lucas Updated", "role": "admin"}

class LoginDto(Model):
    email:    str = Field(NotNull(), Email())
    password: str = Field(NotNull(), Min(8))

    @property
    def example(self) -> dict[str, Any] | None:
        return {"email": "lucas@zoe.io", "password": "Zoe@2024!"}

class CreateProductDto(Model):
    id:          str   = Field(generator=UUID())
    name:        str   = Field(NotNull(), Min(2), Max(200))
    description: str   = Field(NotNull(), Min(10))
    price:       float = Field(NotNull())
    stock:       int   = Field(default=0)
    category:    str   = Field(NotNull())
    sku:         str   = Field(NotNull())

    @property
    def example(self) -> dict[str, Any] | None:
        return {
            "name": "Mechanical Keyboard",
            "description": "High-performance mechanical keyboard with RGB backlight.",
            "price": 149.99,
            "stock": 50,
            "category": "electronics",
            "sku": "KB-MECH-001"
        }

class UpdateProductDto(Model):
    name:        str | None   = Field(default=None)
    description: str | None   = Field(default=None)
    price:       float | None = Field(default=None)
    stock:       int | None   = Field(default=None)

class CreateOrderDto(Model):
    id:         str        = Field(generator=UUID())
    user_id:    str        = Field(NotNull())
    product_ids: list | None = Field(default=None)
    notes:      str | None = Field(default=None)

    @property
    def example(self) -> dict[str, Any] | None:
        return {
            "user_id": "usr_abc123",
            "product_ids": ["prd_001", "prd_002"],
            "notes": "Please gift wrap"
        }

class CreateReviewDto(Model):
    id:         str = Field(generator=UUID())
    user_id:    str = Field(NotNull())
    product_id: str = Field(NotNull())
    rating:     int = Field(NotNull())
    comment:    str = Field(NotNull(), Min(10), Max(1000))

    @property
    def example(self) -> dict[str, Any] | None:
        return {"user_id": "usr_abc123", "product_id": "prd_001", "rating": 5, "comment": "Excellent product!"}

class CreateCategoryDto(Model):
    id:          str = Field(generator=UUID())
    name:        str = Field(NotNull(), Min(2), Max(60))
    description: str = Field(NotNull())
    slug:        str = Field(NotNull())

class CreateCouponDto(Model):
    id:         str   = Field(generator=UUID())
    code:       str   = Field(NotNull(), Min(4), Max(20))
    discount:   float = Field(NotNull())
    max_uses:   int   = Field(default=100)
    expires_at: str   = Field(NotNull())

    @property
    def example(self) -> dict[str, Any] | None:
        return {"code": "ZOE20", "discount": 20.0, "max_uses": 500, "expires_at": "2025-12-31"}

class CreateNotificationDto(Model):
    id:        str      = Field(generator=UUID())
    user_id:   str      = Field(NotNull())
    type:      str      = Field(NotNull())
    title:     str      = Field(NotNull(), Max(120))
    body:      str      = Field(NotNull(), Max(500))
    read:      bool | None = Field(default=False)

class CreateAddressDto(Model):
    id:          str = Field(generator=UUID())
    user_id:     str = Field(NotNull())
    street:      str = Field(NotNull())
    city:        str = Field(NotNull())
    state:       str = Field(NotNull())
    zip_code:    str = Field(NotNull())
    country:     str = Field(default="BR")

    @property
    def example(self) -> dict[str, Any] | None:
        return {"user_id": "usr_abc123", "street": "Rua das Flores, 42", "city": "Campinas", "state": "SP", "zip_code": "13000-000", "country": "BR"}

class CreatePaymentDto(Model):
    id:         str   = Field(generator=UUID())
    order_id:   str   = Field(NotNull())
    method:     str   = Field(NotNull())
    amount:     float = Field(NotNull())
    currency:   str   = Field(default="BRL")

    @property
    def example(self) -> dict[str, Any] | None:
        return {"order_id": "ord_xyz789", "method": "credit_card", "amount": 299.98, "currency": "BRL"}

class CreateWishlistDto(Model):
    id:         str = Field(generator=UUID())
    user_id:    str = Field(NotNull())
    product_id: str = Field(NotNull())


# ══════════════════════════════════════════════════════════════
#  IN-MEMORY STORES
# ══════════════════════════════════════════════════════════════

@Singleton()
class UserStore:
    def __init__(self):
        self.users: dict[str, dict] = {
            "usr_001": {"id": "usr_001", "name": "Lucas Brites", "email": "lucas@zoe.io", "role": "admin"},
            "usr_002": {"id": "usr_002", "name": "Ana Costa",    "email": "ana@zoe.io",   "role": "member"},
        }

@Singleton()
class ProductStore:
    def __init__(self):
        self.products: dict[str, dict] = {
            "prd_001": {"id": "prd_001", "name": "Mechanical Keyboard", "price": 149.99, "stock": 50, "category": "electronics"},
            "prd_002": {"id": "prd_002", "name": "Ergonomic Mouse",     "price": 79.99,  "stock": 30, "category": "electronics"},
            "prd_003": {"id": "prd_003", "name": "USB-C Hub 7-in-1",    "price": 49.99,  "stock": 100,"category": "electronics"},
        }

@Singleton()
class OrderStore:
    def __init__(self):
        self.orders: dict[str, dict] = {}

@Singleton()
class ReviewStore:
    def __init__(self):
        self.reviews: list[dict] = []

@Singleton()
class CategoryStore:
    def __init__(self):
        self.categories: dict[str, dict] = {
            "cat_001": {"id": "cat_001", "name": "Electronics", "slug": "electronics"},
            "cat_002": {"id": "cat_002", "name": "Furniture",   "slug": "furniture"},
        }

@Singleton()
class CouponStore:
    def __init__(self):
        self.coupons: dict[str, dict] = {}

@Singleton()
class NotificationStore:
    def __init__(self):
        self.notifications: list[dict] = []

@Singleton()
class AddressStore:
    def __init__(self):
        self.addresses: list[dict] = []

@Singleton()
class PaymentStore:
    def __init__(self):
        self.payments: list[dict] = []

@Singleton()
class WishlistStore:
    def __init__(self):
        self.items: list[dict] = []


# ══════════════════════════════════════════════════════════════
#  AUTH ROUTER  /v1/auth
# ══════════════════════════════════════════════════════════════

auth_router = Router(prefix="/v1/auth")

@auth_router.post("/login")
@doc(
    summary=Summary(
        title="Login",
        description="Authenticate with email and password. Returns a signed JWT token valid for 24h.",
        tags=["auth"]
    ),
    request=RouteRequest(body=LoginDto),
    responses=[
        RouteResponse(status_code=200, description="Authenticated.",
            examples={"success": {"token": "eyJhbGci...", "expires_in": 86400, "user": {"id": "usr_001", "role": "admin"}}}),
        RouteResponse(status_code=401, description="Invalid credentials."),
        RouteResponse(status_code=400, description="Validation error."),
    ],
    security=RouteSecurity(scheme="None", description="Public endpoint — no auth required."),
    logic=BusinessLogic(
        summary="Validates credentials against stored hash, then issues a JWT.",
        steps=[
            LogicStep(what="Validate body",     how="Schema validation on LoginDto",       why="Reject malformed requests early"),
            LogicStep(what="Lookup user",        how="Query UserStore by email"),
            LogicStep(what="Verify password",   how="bcrypt compare",                      why="Timing-safe comparison"),
            LogicStep(what="Issue JWT",          how="Sign HS256 payload with secret key",  why="Stateless session"),
        ],
        notes="Tokens are not stored server-side. Use /auth/refresh to renew."
    )
)
def login(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"token": "eyJhbGci...", "expires_in": 86400})

@auth_router.post("/register")
@doc(
    summary=Summary(title="Register", description="Create a new account. Email must be unique.", tags=["auth"]),
    request=RouteRequest(body=CreateUserDto),
    responses=[
        RouteResponse(status_code=201, description="Account created.", examples={"ok": {"id": "usr_abc", "email": "lucas@zoe.io"}}),
        RouteResponse(status_code=409, description="Email already in use."),
        RouteResponse(status_code=400, description="Validation error."),
    ],
    logic=BusinessLogic(
        summary="Validates input, checks uniqueness, hashes password, persists user.",
        steps=[
            LogicStep(what="Validate body",    how="Schema validation on CreateUserDto"),
            LogicStep(what="Check uniqueness", how="Scan UserStore for duplicate email",   why="Prevent duplicate accounts"),
            LogicStep(what="Hash password",    how="bcrypt with cost factor 12",           why="Never store plaintext"),
            LogicStep(what="Persist",          how="Insert into UserStore"),
        ]
    )
)
def register(req: Request) -> Response:
    return Response.json(http_code=HttpCode.CREATED, body={"id": "usr_new"})

@auth_router.post("/refresh")
@doc(
    summary=Summary(title="Refresh Token", description="Exchange a valid token for a new one before it expires.", tags=["auth"]),
    request=RouteRequest(headers=[RouteHeader(header_key="Authorization", header_value="Bearer <token>", reason="Current valid JWT")]),
    responses=[
        RouteResponse(status_code=200, description="New token issued.", examples={"ok": {"token": "eyJhbGci...", "expires_in": 86400}}),
        RouteResponse(status_code=401, description="Token expired or invalid."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def refresh_token(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"token": "eyJnew..."})

@auth_router.post("/logout")
@doc(
    summary=Summary(title="Logout", description="Invalidate the current session token.", tags=["auth"]),
    request=RouteRequest(headers=[RouteHeader(header_key="Authorization", header_value="Bearer <token>")]),
    responses=[
        RouteResponse(status_code=204, description="Session terminated."),
        RouteResponse(status_code=401, description="Not authenticated."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def logout(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={})

@auth_router.post("/forgot-password")
@doc(
    summary=Summary(title="Forgot Password", description="Send a password reset link to the provided email.", tags=["auth"]),
    request=RouteRequest(
        body=LoginDto,
        headers=[RouteHeader(header_key="Content-Type", header_value="application/json")]
    ),
    responses=[
        RouteResponse(status_code=200, description="Reset email sent (if account exists)."),
        RouteResponse(status_code=429, description="Too many requests."),
    ],
    logic=BusinessLogic(
        summary="Always returns 200 regardless of whether the email exists to prevent enumeration.",
        steps=[
            LogicStep(what="Validate email",   how="Email format validation"),
            LogicStep(what="Lookup user",       how="Query UserStore silently"),
            LogicStep(what="Send email",        how="Queue reset link via MailService",    why="Async to not block response"),
        ]
    )
)
def forgot_password(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"message": "Reset email sent."})


# ══════════════════════════════════════════════════════════════
#  USERS ROUTER  /v1/users
# ══════════════════════════════════════════════════════════════

users_router = Router(prefix="/v1/users")

@users_router.get("/")
@doc(
    summary=Summary(title="List Users", description="Returns a paginated list of all users. Requires admin role.", tags=["users", "admin"]),
    request=RouteRequest(
        headers=[RouteHeader(header_key="Authorization", header_value="Bearer <token>")],
        query_params=[
            RouteParam(name="page",   reason="Page number (default 1)"),
            RouteParam(name="limit",  reason="Results per page (default 20, max 100)"),
            RouteParam(name="role",   reason="Filter by role: admin | member"),
            RouteParam(name="search", reason="Search by name or email"),
        ]
    ),
    responses=[
        RouteResponse(status_code=200, description="Paginated user list.",
            examples={"ok": {"data": [{"id": "usr_001", "name": "Lucas"}], "total": 42, "page": 1, "pages": 3}}),
        RouteResponse(status_code=403, description="Insufficient permissions."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER, description="Admin role required."),
    depends_on=[DependsOn(service="UserStore", lifecycle=Lifecycle.SINGLETON)],
    author=Author(name="Lucas Brites", email="lucas@zoe.io", squad="Platform")
)
def list_users(req: Request, store: UserStore) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"data": list(store.users.values()), "total": len(store.users)})

@users_router.get("/{id}")
@doc(
    summary=Summary(title="Get User", description="Retrieve a single user profile by ID.", tags=["users"]),
    request=RouteRequest(
        path_params=[RouteParam(name="id", reason="User's unique identifier (UUID)")],
        headers=[RouteHeader(header_key="Authorization", header_value="Bearer <token>")]
    ),
    responses=[
        RouteResponse(status_code=200, description="User profile.", examples={"ok": {"id": "usr_001", "name": "Lucas", "email": "lucas@zoe.io", "role": "admin"}}),
        RouteResponse(status_code=404, description="User not found."),
        RouteResponse(status_code=401, description="Not authenticated."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER),
    depends_on=[DependsOn(service="UserStore", lifecycle=Lifecycle.SINGLETON)]
)
def get_user(req: Request, store: UserStore) -> Response:
    uid = req.path_params.get("id")
    user = store.users.get(uid)
    if not user:
        return Response.json(http_code=HttpCode.NOT_FOUND, body={"error": "User not found"})
    return Response.json(http_code=HttpCode.OK, body=user)

@users_router.put("/{id}")
@doc(
    summary=Summary(title="Update User", description="Update user profile fields. Partial updates supported.", tags=["users"]),
    request=RouteRequest(
        path_params=[RouteParam(name="id", reason="User ID to update")],
        body=UpdateUserDto,
        headers=[RouteHeader(header_key="Authorization", header_value="Bearer <token>")]
    ),
    responses=[
        RouteResponse(status_code=200, description="User updated.", examples={"ok": {"id": "usr_001", "name": "Lucas Updated"}}),
        RouteResponse(status_code=404, description="User not found."),
        RouteResponse(status_code=403, description="Cannot update another user unless admin."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER),
    depends_on=[DependsOn(service="UserStore", lifecycle=Lifecycle.SINGLETON)],
    logic=BusinessLogic(
        summary="Partial update — only provided fields are changed.",
        steps=[
            LogicStep(what="Validate body",    how="Schema validation on UpdateUserDto"),
            LogicStep(what="Auth check",       how="Verify caller is owner or admin",      why="Prevent unauthorized modification"),
            LogicStep(what="Apply changes",    how="Merge non-null fields into user record"),
        ]
    )
)
def update_user(req: Request, store: UserStore) -> Response:
    uid = req.path_params.get("id")
    if uid not in store.users:
        return Response.json(http_code=HttpCode.NOT_FOUND, body={"error": "User not found"})
    return Response.json(http_code=HttpCode.OK, body=store.users[uid])

@users_router.delete("/{id}")
@doc(
    summary=Summary(title="Delete User", description="Permanently delete a user account. Irreversible.", tags=["users", "admin"]),
    request=RouteRequest(
        path_params=[RouteParam(name="id", reason="User ID to delete")],
        headers=[RouteHeader(header_key="Authorization", header_value="Bearer <token>")]
    ),
    responses=[
        RouteResponse(status_code=204, description="User deleted."),
        RouteResponse(status_code=404, description="User not found."),
        RouteResponse(status_code=403, description="Admin only."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER, description="Admin role required."),
    depends_on=[DependsOn(service="UserStore", lifecycle=Lifecycle.SINGLETON)],
    deprecated=False
)
def delete_user(req: Request, store: UserStore) -> Response:
    uid = req.path_params.get("id")
    store.users.pop(uid, None)
    return Response.json(http_code=HttpCode.OK, body={})

@users_router.get("/{id}/orders")
@doc(
    summary=Summary(title="User Orders", description="Fetch all orders placed by a specific user.", tags=["users", "orders"]),
    request=RouteRequest(
        path_params=[RouteParam(name="id", reason="User ID")],
        query_params=[RouteParam(name="status", reason="Filter by order status: pending | paid | shipped | cancelled")]
    ),
    responses=[
        RouteResponse(status_code=200, description="List of user orders.", examples={"ok": {"data": [], "total": 0}}),
        RouteResponse(status_code=404, description="User not found."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER),
    depends_on=[
        DependsOn(service="UserStore",  lifecycle=Lifecycle.SINGLETON),
        DependsOn(service="OrderStore", lifecycle=Lifecycle.SINGLETON),
    ]
)
def get_user_orders(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"data": [], "total": 0})

@users_router.get("/{id}/addresses")
@doc(
    summary=Summary(title="User Addresses", description="Retrieve all saved shipping addresses for a user.", tags=["users", "addresses"]),
    request=RouteRequest(path_params=[RouteParam(name="id", reason="User ID")]),
    responses=[
        RouteResponse(status_code=200, description="Address list.", examples={"ok": {"data": [{"street": "Rua das Flores", "city": "Campinas"}]}}),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def get_user_addresses(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"data": []})


# ══════════════════════════════════════════════════════════════
#  PRODUCTS ROUTER  /v1/products
# ══════════════════════════════════════════════════════════════

products_router = Router(prefix="/v1/products")

@products_router.get("/")
@doc(
    summary=Summary(title="List Products", description="Browse the product catalog with filters, sorting and pagination.", tags=["products"]),
    request=RouteRequest(
        query_params=[
            RouteParam(name="page",     reason="Page number (default 1)"),
            RouteParam(name="limit",    reason="Items per page (default 24)"),
            RouteParam(name="category", reason="Filter by category slug"),
            RouteParam(name="min_price",reason="Minimum price filter"),
            RouteParam(name="max_price",reason="Maximum price filter"),
            RouteParam(name="sort",     reason="Sort field: price | name | created_at"),
            RouteParam(name="order",    reason="Sort direction: asc | desc"),
            RouteParam(name="search",   reason="Full-text search on name and description"),
            RouteParam(name="in_stock", reason="If true, only returns products with stock > 0"),
        ]
    ),
    responses=[
        RouteResponse(status_code=200, description="Paginated product list.",
            examples={"ok": {"data": [{"id": "prd_001", "name": "Keyboard", "price": 149.99}], "total": 120, "page": 1}}),
    ],
    depends_on=[DependsOn(service="ProductStore", lifecycle=Lifecycle.SINGLETON)]
)
def list_products(req: Request, store: ProductStore) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"data": list(store.products.values()), "total": len(store.products)})

@products_router.get("/{id}")
@doc(
    summary=Summary(title="Get Product", description="Fetch full details of a single product by ID.", tags=["products"]),
    request=RouteRequest(path_params=[RouteParam(name="id", reason="Product UUID")]),
    responses=[
        RouteResponse(status_code=200, description="Product details.",
            examples={"ok": {"id": "prd_001", "name": "Keyboard", "price": 149.99, "stock": 50}}),
        RouteResponse(status_code=404, description="Product not found."),
    ],
    depends_on=[DependsOn(service="ProductStore", lifecycle=Lifecycle.SINGLETON)]
)
def get_product(req: Request, store: ProductStore) -> Response:
    pid = req.path_params.get("id")
    product = store.products.get(pid)
    if not product:
        return Response.json(http_code=HttpCode.NOT_FOUND, body={"error": "Product not found"})
    return Response.json(http_code=HttpCode.OK, body=product)

@products_router.post("/")
@doc(
    summary=Summary(title="Create Product", description="Add a new product to the catalog. Admin only.", tags=["products", "admin"]),
    request=RouteRequest(
        body=CreateProductDto,
        headers=[RouteHeader(header_key="Authorization", header_value="Bearer <token>")]
    ),
    responses=[
        RouteResponse(status_code=201, description="Product created.",
            examples={"ok": {"id": "prd_new", "name": "New Product", "price": 99.99}}),
        RouteResponse(status_code=409, description="SKU already exists."),
        RouteResponse(status_code=403, description="Admin only."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER, description="Admin role required."),
    depends_on=[DependsOn(service="ProductStore", lifecycle=Lifecycle.SINGLETON)],
    author=Author(name="Lucas Brites", email="lucas@zoe.io", team="Catalog"),
    logic=BusinessLogic(
        summary="Validates product data, checks SKU uniqueness and persists.",
        steps=[
            LogicStep(what="Validate body",    how="Schema validation on CreateProductDto"),
            LogicStep(what="Check SKU",        how="Scan ProductStore for duplicate SKU",  why="SKUs must be globally unique"),
            LogicStep(what="Persist product",  how="Insert into ProductStore"),
        ]
    )
)
def create_product(req: Request, store: ProductStore) -> Response:
    pid = str(_uuid.uuid4())
    store.products[pid] = {"id": pid, "name": "New Product"}
    return Response.json(http_code=HttpCode.CREATED, body=store.products[pid])

@products_router.put("/{id}")
@doc(
    summary=Summary(title="Update Product", description="Update product details or stock levels.", tags=["products", "admin"]),
    request=RouteRequest(
        path_params=[RouteParam(name="id", reason="Product ID")],
        body=UpdateProductDto,
        headers=[RouteHeader(header_key="Authorization", header_value="Bearer <token>")]
    ),
    responses=[
        RouteResponse(status_code=200, description="Product updated."),
        RouteResponse(status_code=404, description="Product not found."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def update_product(req: Request, store: ProductStore) -> Response:
    pid = req.path_params.get("id")
    if pid not in store.products:
        return Response.json(http_code=HttpCode.NOT_FOUND, body={"error": "Not found"})
    return Response.json(http_code=HttpCode.OK, body=store.products[pid])

@products_router.delete("/{id}")
@doc(
    summary=Summary(title="Delete Product", description="Remove product from catalog. Cannot be undone.", tags=["products", "admin"]),
    request=RouteRequest(path_params=[RouteParam(name="id", reason="Product ID to delete")]),
    responses=[
        RouteResponse(status_code=204, description="Deleted."),
        RouteResponse(status_code=404, description="Not found."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER, description="Admin only."),
    deprecated=False
)
def delete_product(req: Request, store: ProductStore) -> Response:
    pid = req.path_params.get("id")
    store.products.pop(pid, None)
    return Response.json(http_code=HttpCode.OK, body={})

@products_router.get("/{id}/reviews")
@doc(
    summary=Summary(title="Product Reviews", description="Fetch all reviews for a product, sorted by date descending.", tags=["products", "reviews"]),
    request=RouteRequest(
        path_params=[RouteParam(name="id", reason="Product ID")],
        query_params=[
            RouteParam(name="rating", reason="Filter by rating: 1-5"),
            RouteParam(name="page",   reason="Page number"),
        ]
    ),
    responses=[
        RouteResponse(status_code=200, description="Review list.",
            examples={"ok": {"data": [{"rating": 5, "comment": "Great!"}], "avg_rating": 4.7, "total": 38}}),
        RouteResponse(status_code=404, description="Product not found."),
    ]
)
def get_product_reviews(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"data": [], "avg_rating": 0, "total": 0})


# ══════════════════════════════════════════════════════════════
#  ORDERS ROUTER  /v1/orders
# ══════════════════════════════════════════════════════════════

orders_router = Router(prefix="/v1/orders")

@orders_router.get("/")
@doc(
    summary=Summary(title="List Orders", description="Admin endpoint to list all orders across all users.", tags=["orders", "admin"]),
    request=RouteRequest(
        query_params=[
            RouteParam(name="status",   reason="Filter: pending | paid | shipped | delivered | cancelled"),
            RouteParam(name="user_id",  reason="Filter by user"),
            RouteParam(name="from",     reason="Start date (ISO 8601)"),
            RouteParam(name="to",       reason="End date (ISO 8601)"),
            RouteParam(name="page",     reason="Page number"),
        ]
    ),
    responses=[
        RouteResponse(status_code=200, description="Order list.", examples={"ok": {"data": [], "total": 0}}),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER, description="Admin required."),
    depends_on=[DependsOn(service="OrderStore", lifecycle=Lifecycle.SINGLETON)]
)
def list_orders(req: Request, store: OrderStore) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"data": list(store.orders.values())})

@orders_router.post("/")
@doc(
    summary=Summary(title="Create Order", description="Place a new order. Validates product availability before confirming.", tags=["orders"]),
    request=RouteRequest(
        body=CreateOrderDto,
        headers=[RouteHeader(header_key="Authorization", header_value="Bearer <token>")]
    ),
    responses=[
        RouteResponse(status_code=201, description="Order placed.",
            examples={"ok": {"id": "ord_xyz", "status": "pending", "total": 299.98}}),
        RouteResponse(status_code=400, description="Invalid product IDs or out of stock."),
        RouteResponse(status_code=401, description="Not authenticated."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER),
    depends_on=[
        DependsOn(service="OrderStore",   lifecycle=Lifecycle.SINGLETON),
        DependsOn(service="ProductStore", lifecycle=Lifecycle.SINGLETON, reason="Stock validation"),
    ],
    logic=BusinessLogic(
        summary="Validates product availability, computes total, creates order and decrements stock.",
        steps=[
            LogicStep(what="Validate body",      how="Schema validation on CreateOrderDto"),
            LogicStep(what="Validate products",  how="Check all product_ids exist and have stock", why="Atomic check before any write"),
            LogicStep(what="Compute total",      how="Sum product prices"),
            LogicStep(what="Create order",       how="Insert into OrderStore with status=pending"),
            LogicStep(what="Decrement stock",    how="Update each product's stock count",           why="Prevent overselling"),
        ]
    )
)
def create_order(req: Request, store: OrderStore) -> Response:
    oid = str(_uuid.uuid4())
    store.orders[oid] = {"id": oid, "status": "pending"}
    return Response.json(http_code=HttpCode.CREATED, body=store.orders[oid])

@orders_router.get("/{id}")
@doc(
    summary=Summary(title="Get Order", description="Fetch a specific order with full line items and payment info.", tags=["orders"]),
    request=RouteRequest(path_params=[RouteParam(name="id", reason="Order UUID")]),
    responses=[
        RouteResponse(status_code=200, description="Order details.", examples={"ok": {"id": "ord_xyz", "status": "paid", "items": []}}),
        RouteResponse(status_code=404, description="Order not found."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def get_order(req: Request, store: OrderStore) -> Response:
    oid = req.path_params.get("id")
    order = store.orders.get(oid)
    if not order:
        return Response.json(http_code=HttpCode.NOT_FOUND, body={"error": "Not found"})
    return Response.json(http_code=HttpCode.OK, body=order)

@orders_router.patch("/{id}/cancel")
@doc(
    summary=Summary(title="Cancel Order", description="Cancel a pending order. Cannot cancel if already shipped.", tags=["orders"]),
    request=RouteRequest(path_params=[RouteParam(name="id", reason="Order ID to cancel")]),
    responses=[
        RouteResponse(status_code=200, description="Order cancelled.", examples={"ok": {"id": "ord_xyz", "status": "cancelled"}}),
        RouteResponse(status_code=400, description="Order cannot be cancelled in its current status."),
        RouteResponse(status_code=404, description="Order not found."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER),
    logic=BusinessLogic(
        summary="Validates order status transition, restores product stock and updates status.",
        steps=[
            LogicStep(what="Fetch order",        how="Query OrderStore by ID"),
            LogicStep(what="Validate status",    how="Allow cancel only if status in [pending, paid]", why="Shipped orders cannot be recalled"),
            LogicStep(what="Restore stock",      how="Increment product quantities back",               why="Make items available again"),
            LogicStep(what="Update status",      how="Set status=cancelled"),
        ]
    )
)
def cancel_order(req: Request, store: OrderStore) -> Response:
    oid = req.path_params.get("id")
    if oid in store.orders:
        store.orders[oid]["status"] = "cancelled"
    return Response.json(http_code=HttpCode.OK, body={"status": "cancelled"})


# ══════════════════════════════════════════════════════════════
#  REVIEWS ROUTER  /v1/reviews
# ══════════════════════════════════════════════════════════════

reviews_router = Router(prefix="/v1/reviews")

@reviews_router.post("/")
@doc(
    summary=Summary(title="Submit Review", description="Post a review for a product. One review per user per product.", tags=["reviews"]),
    request=RouteRequest(body=CreateReviewDto),
    responses=[
        RouteResponse(status_code=201, description="Review submitted.", examples={"ok": {"id": "rev_001", "rating": 5}}),
        RouteResponse(status_code=409, description="You already reviewed this product."),
        RouteResponse(status_code=400, description="Rating must be between 1 and 5."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER),
    depends_on=[DependsOn(service="ReviewStore", lifecycle=Lifecycle.SINGLETON)]
)
def create_review(req: Request, store: ReviewStore) -> Response:
    return Response.json(http_code=HttpCode.CREATED, body={"id": "rev_new"})

@reviews_router.delete("/{id}")
@doc(
    summary=Summary(title="Delete Review", description="Remove a review. Users can delete their own; admins can delete any.", tags=["reviews", "admin"]),
    request=RouteRequest(path_params=[RouteParam(name="id", reason="Review ID")]),
    responses=[
        RouteResponse(status_code=204, description="Review deleted."),
        RouteResponse(status_code=403, description="Cannot delete another user's review."),
        RouteResponse(status_code=404, description="Review not found."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def delete_review(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={})


# ══════════════════════════════════════════════════════════════
#  CATEGORIES ROUTER  /v1/categories
# ══════════════════════════════════════════════════════════════

categories_router = Router(prefix="/v1/categories")

@categories_router.get("/")
@doc(
    summary=Summary(title="List Categories", description="Fetch all product categories.", tags=["categories"]),
    responses=[
        RouteResponse(status_code=200, description="Category list.",
            examples={"ok": {"data": [{"id": "cat_001", "name": "Electronics", "slug": "electronics"}]}}),
    ],
    depends_on=[DependsOn(service="CategoryStore", lifecycle=Lifecycle.SINGLETON)]
)
def list_categories(req: Request, store: CategoryStore) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"data": list(store.categories.values())})

@categories_router.post("/")
@doc(
    summary=Summary(title="Create Category", description="Add a new product category.", tags=["categories", "admin"]),
    request=RouteRequest(body=CreateCategoryDto),
    responses=[
        RouteResponse(status_code=201, description="Category created."),
        RouteResponse(status_code=409, description="Slug already in use."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER, description="Admin required.")
)
def create_category(req: Request, store: CategoryStore) -> Response:
    return Response.json(http_code=HttpCode.CREATED, body={"id": "cat_new"})

@categories_router.get("/{slug}/products")
@doc(
    summary=Summary(title="Category Products", description="Browse all products belonging to a category.", tags=["categories", "products"]),
    request=RouteRequest(
        path_params=[RouteParam(name="slug", reason="Category slug, e.g. electronics")],
        query_params=[
            RouteParam(name="page",  reason="Page number"),
            RouteParam(name="sort",  reason="Sort field: price | name"),
        ]
    ),
    responses=[
        RouteResponse(status_code=200, description="Products in category."),
        RouteResponse(status_code=404, description="Category not found."),
    ]
)
def category_products(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"data": []})


# ══════════════════════════════════════════════════════════════
#  PAYMENTS ROUTER  /v1/payments
# ══════════════════════════════════════════════════════════════

payments_router = Router(prefix="/v1/payments")

@payments_router.post("/")
@doc(
    summary=Summary(title="Process Payment", description="Process payment for an order via the configured gateway.", tags=["payments"]),
    request=RouteRequest(
        body=CreatePaymentDto,
        headers=[RouteHeader(header_key="Authorization", header_value="Bearer <token>")]
    ),
    responses=[
        RouteResponse(status_code=201, description="Payment processed.",
            examples={"ok": {"id": "pay_001", "status": "approved", "amount": 299.98}}),
        RouteResponse(status_code=402, description="Payment declined."),
        RouteResponse(status_code=400, description="Invalid payment data."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER),
    depends_on=[
        DependsOn(service="PaymentStore", lifecycle=Lifecycle.SINGLETON),
        DependsOn(service="OrderStore",   lifecycle=Lifecycle.SINGLETON, reason="Update order status on success"),
    ],
    logic=BusinessLogic(
        summary="Submits payment to external gateway, handles response and updates order status.",
        steps=[
            LogicStep(what="Validate body",      how="Schema validation on CreatePaymentDto"),
            LogicStep(what="Fetch order",        how="Verify order exists and is in 'pending' state"),
            LogicStep(what="Submit to gateway",  how="POST to payment provider API",                why="External settlement"),
            LogicStep(what="Handle response",    how="Map gateway status to internal status"),
            LogicStep(what="Update order",       how="Set order status=paid if approved"),
        ],
        notes="Idempotency key can be passed via X-Idempotency-Key header to prevent double charges."
    ),
    author=Author(name="Lucas Brites", squad="Payments", email="lucas@zoe.io")
)
def process_payment(req: Request, store: PaymentStore) -> Response:
    return Response.json(http_code=HttpCode.CREATED, body={"status": "approved"})

@payments_router.get("/{id}")
@doc(
    summary=Summary(title="Get Payment", description="Retrieve details of a specific payment transaction.", tags=["payments"]),
    request=RouteRequest(path_params=[RouteParam(name="id", reason="Payment ID")]),
    responses=[
        RouteResponse(status_code=200, description="Payment details."),
        RouteResponse(status_code=404, description="Payment not found."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def get_payment(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"id": req.path_params.get("id")})

@payments_router.post("/{id}/refund")
@doc(
    summary=Summary(title="Refund Payment", description="Request a full or partial refund for a payment.", tags=["payments", "admin"]),
    request=RouteRequest(
        path_params=[RouteParam(name="id", reason="Payment ID to refund")],
        query_params=[RouteParam(name="amount", reason="Partial refund amount. Omit for full refund.")],
    ),
    responses=[
        RouteResponse(status_code=200, description="Refund initiated.", examples={"ok": {"refund_id": "ref_001", "status": "pending"}}),
        RouteResponse(status_code=400, description="Refund amount exceeds original payment."),
        RouteResponse(status_code=409, description="Payment already refunded."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER, description="Admin required.")
)
def refund_payment(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"refund_id": "ref_new", "status": "pending"})


# ══════════════════════════════════════════════════════════════
#  COUPONS ROUTER  /v1/coupons
# ══════════════════════════════════════════════════════════════

coupons_router = Router(prefix="/v1/coupons")

@coupons_router.post("/")
@doc(
    summary=Summary(title="Create Coupon", description="Generate a new discount coupon code.", tags=["coupons", "admin"]),
    request=RouteRequest(body=CreateCouponDto),
    responses=[
        RouteResponse(status_code=201, description="Coupon created.", examples={"ok": {"code": "ZOE20", "discount": 20}}),
        RouteResponse(status_code=409, description="Coupon code already exists."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER, description="Admin required.")
)
def create_coupon(req: Request, store: CouponStore) -> Response:
    return Response.json(http_code=HttpCode.CREATED, body={"code": "ZOE20"})

@coupons_router.post("/validate")
@doc(
    summary=Summary(title="Validate Coupon", description="Check if a coupon code is valid and return its discount value.", tags=["coupons"]),
    request=RouteRequest(query_params=[RouteParam(name="code", reason="Coupon code to validate")]),
    responses=[
        RouteResponse(status_code=200, description="Valid coupon.", examples={"ok": {"code": "ZOE20", "discount": 20, "valid": True}}),
        RouteResponse(status_code=404, description="Coupon not found or expired."),
    ]
)
def validate_coupon(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"valid": True, "discount": 20})

@coupons_router.delete("/{code}")
@doc(
    summary=Summary(title="Delete Coupon", description="Invalidate and remove a coupon.", tags=["coupons", "admin"]),
    request=RouteRequest(path_params=[RouteParam(name="code", reason="Coupon code to delete")]),
    responses=[
        RouteResponse(status_code=204, description="Coupon deleted."),
        RouteResponse(status_code=404, description="Coupon not found."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER, description="Admin required."),
    deprecated=False
)
def delete_coupon(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={})


# ══════════════════════════════════════════════════════════════
#  NOTIFICATIONS ROUTER  /v1/notifications
# ══════════════════════════════════════════════════════════════

notifications_router = Router(prefix="/v1/notifications")

@notifications_router.get("/")
@doc(
    summary=Summary(title="List Notifications", description="Get notifications for the authenticated user. Sorted by newest first.", tags=["notifications"]),
    request=RouteRequest(
        query_params=[RouteParam(name="unread_only", reason="If true, only returns unread notifications")],
        headers=[RouteHeader(header_key="Authorization", header_value="Bearer <token>")]
    ),
    responses=[
        RouteResponse(status_code=200, description="Notification list.",
            examples={"ok": {"data": [{"id": "notif_001", "title": "Order shipped", "read": False}], "unread_count": 3}}),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def list_notifications(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"data": [], "unread_count": 0})

@notifications_router.patch("/{id}/read")
@doc(
    summary=Summary(title="Mark as Read", description="Mark a notification as read.", tags=["notifications"]),
    request=RouteRequest(path_params=[RouteParam(name="id", reason="Notification ID")]),
    responses=[
        RouteResponse(status_code=200, description="Marked as read."),
        RouteResponse(status_code=404, description="Notification not found."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def mark_notification_read(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"read": True})

@notifications_router.patch("/read-all")
@doc(
    summary=Summary(title="Mark All as Read", description="Mark all notifications for the authenticated user as read.", tags=["notifications"]),
    responses=[
        RouteResponse(status_code=200, description="All notifications marked as read.", examples={"ok": {"updated": 5}}),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def mark_all_read(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"updated": 0})


# ══════════════════════════════════════════════════════════════
#  WISHLIST ROUTER  /v1/wishlist
# ══════════════════════════════════════════════════════════════

wishlist_router = Router(prefix="/v1/wishlist")

@wishlist_router.get("/")
@doc(
    summary=Summary(title="Get Wishlist", description="Retrieve the authenticated user's saved wishlist items.", tags=["wishlist"]),
    responses=[
        RouteResponse(status_code=200, description="Wishlist items.", examples={"ok": {"data": [{"product_id": "prd_001"}], "total": 1}}),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def get_wishlist(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"data": []})

@wishlist_router.post("/")
@doc(
    summary=Summary(title="Add to Wishlist", description="Save a product to the user's wishlist.", tags=["wishlist"]),
    request=RouteRequest(body=CreateWishlistDto),
    responses=[
        RouteResponse(status_code=201, description="Added to wishlist."),
        RouteResponse(status_code=409, description="Product already in wishlist."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def add_to_wishlist(req: Request, store: WishlistStore) -> Response:
    return Response.json(http_code=HttpCode.CREATED, body={"added": True})

@wishlist_router.delete("/{product_id}")
@doc(
    summary=Summary(title="Remove from Wishlist", description="Remove a product from the wishlist.", tags=["wishlist"]),
    request=RouteRequest(path_params=[RouteParam(name="product_id", reason="Product ID to remove")]),
    responses=[
        RouteResponse(status_code=204, description="Removed."),
        RouteResponse(status_code=404, description="Item not in wishlist."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER)
)
def remove_from_wishlist(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={})


# ══════════════════════════════════════════════════════════════
#  SYSTEM ROUTER  /
# ══════════════════════════════════════════════════════════════

system_router = Router(prefix="/")

@system_router.get("/health")
@doc(
    summary=Summary(title="Health Check", description="Returns server status and basic diagnostics. No auth required.", tags=["system"]),
    responses=[
        RouteResponse(status_code=200, description="Server is healthy.",
            examples={"ok": {"status": "ok", "uptime": 3820, "version": "1.0.0", "timestamp": "2024-01-01T00:00:00Z"}}),
    ]
)
def health(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"status": "ok", "uptime": int(time.time()), "version": "1.0.0"})

@system_router.get("/metrics")
@doc(
    summary=Summary(title="Metrics", description="Expose internal server metrics. Admin only.", tags=["system", "admin"]),
    responses=[
        RouteResponse(status_code=200, description="Metrics snapshot.",
            examples={"ok": {"requests_total": 1240, "errors_total": 3, "avg_latency_ms": 12}}),
        RouteResponse(status_code=403, description="Admin only."),
    ],
    security=RouteSecurity(scheme=DocAuthScheme.BEARER, description="Admin role required.")
)
def metrics(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"requests_total": 0})

@system_router.get("/version")
@doc(
    summary=Summary(title="Version", description="Returns the current API version string.", tags=["system"]),
    version="v1.2.4",
    responses=[RouteResponse(status_code=200, description="Version info.", examples={"ok": {"version": "1.2.4", "framework": "Zoe"}})]
)
def version(req: Request) -> Response:
    return Response.json(http_code=HttpCode.OK, body={"version": "1.0.0", "framework": "Zoe"})


# ══════════════════════════════════════════════════════════════
#  APP
# ══════════════════════════════════════════════════════════════
jwt = JWT_HS256(
    secret="super_secret_key",
    issued_by="brites",
    expires_min=15,
    claims=[JWT_Claim("role", "admin")],
    audience=["my-api"]
)

token: str = jwt.encode()
print(token)

if __name__ == "__main__":
    app = App()
    (
        app
        .use(auth_router.use(Guard(BearerStrategy(validator=jwt))))
        .use(users_router)
        .use(products_router)
        .use(orders_router)
        .use(reviews_router)
        .use(categories_router)
        .use(payments_router)
        .use(coupons_router)
        .use(notifications_router)
        .use(wishlist_router)
        .use(system_router)
    )
    Server(application=app).run()
