# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["SourceIngestYoutubeParams"]


class SourceIngestYoutubeParams(TypedDict, total=False):
    url: Required[str]
    """The YouTube video URL to ingest (e.g.

    https://www.youtube.com/watch?v=dQw4w9WgXcQ)
    """
