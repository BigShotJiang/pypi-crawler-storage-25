# Changelog

## 0.22.0 (2026-04-07)

Full Changelog: [v0.21.0...v0.22.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.21.0...v0.22.0)

### Features

* **api:** api update ([ccdeb6c](https://github.com/synapseops/graphor-python-sdk/commit/ccdeb6cac11a0cbf1ff4105e021426a99633a18b))

## 0.21.0 (2026-04-05)

Full Changelog: [v0.20.0...v0.21.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.20.0...v0.21.0)

### Features

* **api:** api update ([d174df1](https://github.com/synapseops/graphor-python-sdk/commit/d174df1ebad5f103c239e8f25ab819d68296fffe))

## 0.20.0 (2026-04-02)

Full Changelog: [v0.19.0...v0.20.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.19.0...v0.20.0)

### Features

* **api:** api update ([40c6b90](https://github.com/synapseops/graphor-python-sdk/commit/40c6b90355933b2f6375ed3d5d6093ac533295e9))
* **internal:** implement indices array format for query and form serialization ([82cfa12](https://github.com/synapseops/graphor-python-sdk/commit/82cfa1236a1d475cd14c9faf6c6bfe101266900c))


### Bug Fixes

* **deps:** bump minimum typing-extensions version ([6cbd959](https://github.com/synapseops/graphor-python-sdk/commit/6cbd9597b7262d47ebeb35e9bfb366c953ab6cba))
* **pydantic:** do not pass `by_alias` unless set ([8efce77](https://github.com/synapseops/graphor-python-sdk/commit/8efce77a47722e8d82896845d6b7e9aa9f07b4bf))
* sanitize endpoint path params ([1a0d2cb](https://github.com/synapseops/graphor-python-sdk/commit/1a0d2cb6f3da1189bee84e568d46a0b6d51f6e82))


### Chores

* **ci:** skip lint on metadata-only changes ([dd8dd4e](https://github.com/synapseops/graphor-python-sdk/commit/dd8dd4eaef59291ab82c08425cf4f9de1179f44b))
* **internal:** tweak CI branches ([9a63ab5](https://github.com/synapseops/graphor-python-sdk/commit/9a63ab5af223f7eb289c7fc9193ccc7d84cd9186))
* **internal:** update gitignore ([6bca9d8](https://github.com/synapseops/graphor-python-sdk/commit/6bca9d89cd27aa0955773cafd374427fb01a3b65))

## 0.19.0 (2026-03-11)

Full Changelog: [v0.18.0...v0.19.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.18.0...v0.19.0)

### Features

* **api:** api update ([c97b715](https://github.com/synapseops/graphor-python-sdk/commit/c97b715d879760b7928bd2d598aaee2bf46d5655))

## 0.18.0 (2026-03-08)

Full Changelog: [v0.17.1...v0.18.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.17.1...v0.18.0)

### Features

* **api:** api update ([5d922e8](https://github.com/synapseops/graphor-python-sdk/commit/5d922e80054bc3d55bb1bf88d92472013307eb00))
* **api:** api update ([7fc6c4b](https://github.com/synapseops/graphor-python-sdk/commit/7fc6c4b4092d765317b55f1cc145f03ccf1069da))
* **api:** manual updates ([4e70124](https://github.com/synapseops/graphor-python-sdk/commit/4e70124c3e45c3f7205b62547382874fa2f632f3))
* **api:** manual updates ([62efd09](https://github.com/synapseops/graphor-python-sdk/commit/62efd098c6005fa42627513ad93de2df877f1294))
* **api:** manual updates ([137d286](https://github.com/synapseops/graphor-python-sdk/commit/137d2860bde438209e4422479c2577ca27522c02))
* **api:** manual updates ([b71ef86](https://github.com/synapseops/graphor-python-sdk/commit/b71ef8629b3498facd0df13e9998f16ec5c9f8a9))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([53ed9ce](https://github.com/synapseops/graphor-python-sdk/commit/53ed9ce41036e9a7c787ac7f099093ffcb1994c9))
* update placeholder string ([80726da](https://github.com/synapseops/graphor-python-sdk/commit/80726dafe5251a4505989fc44c8f37b38bde6b4c))

## 0.17.1 (2026-03-03)

Full Changelog: [v0.17.0...v0.17.1](https://github.com/synapseops/graphor-python-sdk/compare/v0.17.0...v0.17.1)

### Chores

* **ci:** bump uv version ([2324ec4](https://github.com/synapseops/graphor-python-sdk/commit/2324ec41075cff920f6a25a3eb032160b655ddba))
* **internal:** refactor authentication internals ([47cdcdc](https://github.com/synapseops/graphor-python-sdk/commit/47cdcdce6c27dbc1b21bb875e58e49882ecef4b5))

## 0.17.0 (2026-02-26)

Full Changelog: [v0.16.1...v0.17.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.16.1...v0.17.0)

### Features

* **api:** api update ([be7361f](https://github.com/synapseops/graphor-python-sdk/commit/be7361fd3759e8492f5175b6e1ec5aa0d7c255d7))


### Chores

* **internal:** add request options to SSE classes ([f3441b1](https://github.com/synapseops/graphor-python-sdk/commit/f3441b11b9995237015200da3890e28aecd969fb))
* **internal:** make `test_proxy_environment_variables` more resilient ([5dbd8ca](https://github.com/synapseops/graphor-python-sdk/commit/5dbd8ca2b2408d9d9a5dd1cdcf5ee5db6f38d4db))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([b1866fb](https://github.com/synapseops/graphor-python-sdk/commit/b1866fb949e072f79073dbe9f08fb698251c3831))
* **internal:** remove mock server code ([2eadf82](https://github.com/synapseops/graphor-python-sdk/commit/2eadf82cc19d8647ed5d63dcbc1b6cdd5e095963))
* update mock server docs ([705d15f](https://github.com/synapseops/graphor-python-sdk/commit/705d15f259ed83773db7fefe1d50d7eaed3ca463))

## 0.16.1 (2026-02-13)

Full Changelog: [v0.16.0...v0.16.1](https://github.com/synapseops/graphor-python-sdk/compare/v0.16.0...v0.16.1)

### Chores

* format all `api.md` files ([bf8f6a6](https://github.com/synapseops/graphor-python-sdk/commit/bf8f6a6604722ceb43f46fac5d2c7e48857357a1))


### Documentation

* update mcp docs ([9604db3](https://github.com/synapseops/graphor-python-sdk/commit/9604db30b794b914c8f0975223776ef3c9e56281))

## 0.16.0 (2026-02-12)

Full Changelog: [v0.15.3...v0.16.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.15.3...v0.16.0)

### Features

* **api:** api update ([7eae1f1](https://github.com/synapseops/graphor-python-sdk/commit/7eae1f18be8b7ee4a06f1d39093f6c72a3ff2508))


### Documentation

* add parsing to quickstart ([150af10](https://github.com/synapseops/graphor-python-sdk/commit/150af10c1fb1b97297112ff32537ebfa85f18a4c))

## 0.15.3 (2026-02-12)

Full Changelog: [v0.15.2...v0.15.3](https://github.com/synapseops/graphor-python-sdk/compare/v0.15.2...v0.15.3)

### Documentation

* update readme ([44b6f66](https://github.com/synapseops/graphor-python-sdk/commit/44b6f66faae3a13178c7bb323165b8e066829928))

## 0.15.2 (2026-02-12)

Full Changelog: [v0.15.1...v0.15.2](https://github.com/synapseops/graphor-python-sdk/compare/v0.15.1...v0.15.2)

### Documentation

* update mpc deeplinks ([d4e3d50](https://github.com/synapseops/graphor-python-sdk/commit/d4e3d50131c7ec1a0b446d09cf518162db6673c3))

## 0.15.1 (2026-02-12)

Full Changelog: [v0.15.0...v0.15.1](https://github.com/synapseops/graphor-python-sdk/compare/v0.15.0...v0.15.1)

### Documentation

* update mpc deeplinks ([6084a50](https://github.com/synapseops/graphor-python-sdk/commit/6084a5070725b52bbcebcff3e6d698517ee64f72))

## 0.15.0 (2026-02-12)

Full Changelog: [v0.14.0...v0.15.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.14.0...v0.15.0)

### Features

* **api:** manual updates ([06021a4](https://github.com/synapseops/graphor-python-sdk/commit/06021a434b677aa1c7d23e0f0c9639d9701e9086))
* **api:** manual updates ([11c174f](https://github.com/synapseops/graphor-python-sdk/commit/11c174f9bc177d1d5796caf452b83728da7b0440))
* **api:** manual updates ([7a63b4d](https://github.com/synapseops/graphor-python-sdk/commit/7a63b4dbe7fa871670f86394dcd15f981bbc5663))
* **api:** manual updates ([492f332](https://github.com/synapseops/graphor-python-sdk/commit/492f33292707600f8812dcd363df99e20ac8cb08))


### Chores

* **internal:** fix lint error on Python 3.14 ([5d22a81](https://github.com/synapseops/graphor-python-sdk/commit/5d22a81d928be4564903420f7895fb17ff61cfd9))

## 0.14.0 (2026-02-11)

Full Changelog: [v0.13.0...v0.14.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.13.0...v0.14.0)

### Features

* **api:** api update ([b3da855](https://github.com/synapseops/graphor-python-sdk/commit/b3da8552226f780cdb7694a3d1a5050d0044b36b))

## 0.13.0 (2026-02-11)

Full Changelog: [v0.12.0...v0.13.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.12.0...v0.13.0)

### Features

* **api:** api update ([4512db3](https://github.com/synapseops/graphor-python-sdk/commit/4512db33a348d254e4b7dac77014048634c0b8af))

## 0.12.0 (2026-02-10)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.11.0...v0.12.0)

### Features

* **api:** manual updates ([c1dcb37](https://github.com/synapseops/graphor-python-sdk/commit/c1dcb375622c1f9903fb622c30fedcf2adcd7f5e))

## 0.11.0 (2026-02-10)

Full Changelog: [v0.10.0...v0.11.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.10.0...v0.11.0)

### Features

* **api:** manual updates ([fa2a5d7](https://github.com/synapseops/graphor-python-sdk/commit/fa2a5d70b3db4c220f4ed69e861d4b9f3c21ff5a))

## 0.10.0 (2026-02-10)

Full Changelog: [v0.9.3...v0.10.0](https://github.com/synapseops/graphor-python-sdk/compare/v0.9.3...v0.10.0)

### Features

* **api:** manual updates ([9eb4ef0](https://github.com/synapseops/graphor-python-sdk/commit/9eb4ef04428e93eda6e34ba2a028d34cf0a6879d))

## 0.9.3 (2026-02-10)

Full Changelog: [v0.9.2...v0.9.3](https://github.com/synapseops/graphor-python-sdk/compare/v0.9.2...v0.9.3)

### Documentation

* **readme:** update ([8ec15a1](https://github.com/synapseops/graphor-python-sdk/commit/8ec15a1ed8646767eda74904c3b4e30c0118673d))

## 0.9.2 (2026-02-10)

Full Changelog: [v0.0.1...v0.9.2](https://github.com/synapseops/graphor-python-sdk/compare/v0.0.1...v0.9.2)

### Features

* **api:** api update ([fe0e593](https://github.com/synapseops/graphor-python-sdk/commit/fe0e593bf3bc2ec7c3675b3f38967d5e11e4abdd))
* **api:** api update ([14d6eae](https://github.com/synapseops/graphor-python-sdk/commit/14d6eaeff741233fe8dd830f64c24b01a046d2fb))
* **api:** api update ([6d56646](https://github.com/synapseops/graphor-python-sdk/commit/6d566469a9d4727ebcd6df97a3108793278e75df))
* **api:** api update ([559274c](https://github.com/synapseops/graphor-python-sdk/commit/559274c0df96b1eba48a51edd9f02af94016f09b))
* **api:** manual updates ([733e5a0](https://github.com/synapseops/graphor-python-sdk/commit/733e5a056dba56417d01535b5b18e58dd4f3c35f))
* **api:** manual updates ([077b7fa](https://github.com/synapseops/graphor-python-sdk/commit/077b7fafd99ab1eb7e27b80bf4bcb7e97b03a160))
* **api:** manual updates ([d839f34](https://github.com/synapseops/graphor-python-sdk/commit/d839f34918ab6c09b5036665b093ae11397139b3))
* **api:** manual updates ([c50df16](https://github.com/synapseops/graphor-python-sdk/commit/c50df16e7f81ffa82d27ffdab819464ec0173a3a))
* **api:** manual updates ([00e7cc4](https://github.com/synapseops/graphor-python-sdk/commit/00e7cc4d8942e24e2dd448552cd055d19e8a069a))
* **api:** manual updates ([86d679a](https://github.com/synapseops/graphor-python-sdk/commit/86d679a0c0bcf6600fc5979e91b716800369c404))
* **client:** add custom JSON encoder for extended type support ([9a5e3bc](https://github.com/synapseops/graphor-python-sdk/commit/9a5e3bc260358347354aaeb508a1d679f40d4f8d))
* **client:** add support for binary request streaming ([247170c](https://github.com/synapseops/graphor-python-sdk/commit/247170c9501b0f1f2ceaea4361532030d777dfc6))


### Chores

* **ci:** upgrade `actions/github-script` ([4ee07c4](https://github.com/synapseops/graphor-python-sdk/commit/4ee07c48770525196ada72b50e966161c17aa0c5))
* configure new SDK language ([cf085f5](https://github.com/synapseops/graphor-python-sdk/commit/cf085f5a9025945a1a29f763ffd51197a94cb99a))
* configure new SDK language ([13f3cb2](https://github.com/synapseops/graphor-python-sdk/commit/13f3cb20cd5aaf117292d32198ecc853c46c0ac3))
* **internal:** bump dependencies ([00443fe](https://github.com/synapseops/graphor-python-sdk/commit/00443fe29917729071838ccf1792dc9db78de0ca))
* **internal:** update `actions/checkout` version ([ebd8144](https://github.com/synapseops/graphor-python-sdk/commit/ebd81445054763a698cdc05eb0ee7f8486e9b476))
* sync repo ([7f85230](https://github.com/synapseops/graphor-python-sdk/commit/7f85230cb6877e03e9c1dc24b7c12164a653e298))
* update SDK settings ([c8de2f3](https://github.com/synapseops/graphor-python-sdk/commit/c8de2f322c1200c715de302b86e47f42b53d87a5))
* update SDK settings ([7349a7b](https://github.com/synapseops/graphor-python-sdk/commit/7349a7b5d1ec767c6309dd4e41f6d838cb7e39bd))
* update SDK settings ([0dec652](https://github.com/synapseops/graphor-python-sdk/commit/0dec65247848b18645a37750f848e4f88da1f2fa))
* update SDK settings ([473b8c9](https://github.com/synapseops/graphor-python-sdk/commit/473b8c9b0be36968ba7c3eca9513ff17ac5dcf19))
* update SDK settings ([fdd61a1](https://github.com/synapseops/graphor-python-sdk/commit/fdd61a1cf0fa3f1228d6820653c04fcf0d8f9a24))
* update SDK settings ([7802406](https://github.com/synapseops/graphor-python-sdk/commit/7802406efe4ad09e1442061f57146c0d711b1ec8))
* update SDK settings ([ba9c5ca](https://github.com/synapseops/graphor-python-sdk/commit/ba9c5ca617475914a9a2b85e3148aae9ce801701))
* update SDK settings ([537f485](https://github.com/synapseops/graphor-python-sdk/commit/537f4854551d1e90054c6720b189e13d1972958c))
* update SDK settings ([5cd084e](https://github.com/synapseops/graphor-python-sdk/commit/5cd084ed8d292eb7c8a032b760ffcd2014410d39))
* update SDK settings ([66fa45c](https://github.com/synapseops/graphor-python-sdk/commit/66fa45c5d81fdc7844cfd087402ccef4fef640f6))
* update SDK settings ([bc8071e](https://github.com/synapseops/graphor-python-sdk/commit/bc8071e93301daf9827045da08daa2640d5dbcef))
* update SDK settings ([33a40d1](https://github.com/synapseops/graphor-python-sdk/commit/33a40d1047da3d79aebb8869c943ea3f6e835ca7))
* update SDK settings ([94f0de7](https://github.com/synapseops/graphor-python-sdk/commit/94f0de70825b6227639d4464a973f2ca62276101))
* update SDK settings ([857d1c7](https://github.com/synapseops/graphor-python-sdk/commit/857d1c7e4d3db182f82c58f53278532fd767b714))
* update SDK settings ([4ba7825](https://github.com/synapseops/graphor-python-sdk/commit/4ba7825240e6ce494f9b54dacc6ed184af1bd892))
* update SDK settings ([90e8d89](https://github.com/synapseops/graphor-python-sdk/commit/90e8d891a01ff096530ab969a85cc9c880de4016))
* update SDK settings ([3bf7091](https://github.com/synapseops/graphor-python-sdk/commit/3bf7091ce36c6075a93bc7941dc31181197c9d93))
* update SDK settings ([d9868f7](https://github.com/synapseops/graphor-python-sdk/commit/d9868f70c7c41860f0a45afaa181019b3fc9bc74))
* update SDK settings ([8604de9](https://github.com/synapseops/graphor-python-sdk/commit/8604de954ff177984d1f88b8ae626057423f0c6c))
* update SDK settings ([1298437](https://github.com/synapseops/graphor-python-sdk/commit/1298437d43d82b5d715882e9929d89da9975f340))
* update SDK settings ([63adcee](https://github.com/synapseops/graphor-python-sdk/commit/63adcee3788c695712a15fa050498da79653cebe))


### Documentation

* **readme:** update ([a025e6d](https://github.com/synapseops/graphor-python-sdk/commit/a025e6da939eba7738b1eb76d08abbfcdbf81355))
