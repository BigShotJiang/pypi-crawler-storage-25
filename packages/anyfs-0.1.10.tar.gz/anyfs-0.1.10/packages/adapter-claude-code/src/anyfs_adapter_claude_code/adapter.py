from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from anyfs_adapters_core import AgentAdapter, append_unique, collect_text_files, read_text_file
from anyfs_schemas import AgentType, CaptureResult, CodeRef, Namespace, WorkspaceBinding, WorkspaceOverlay

_CLAUDE_EXCLUDED_CONTEXT_FILES = {"settings.json", ".claude.json"}


def _claude_project_dir(workspace: str) -> Path | None:
    """Find the ~/.claude/projects/ directory for this workspace."""
    workspace_path = Path(workspace).resolve()
    claude_home = Path.home() / ".claude"
    if not claude_home.exists():
        return None
    projects_dir = claude_home / "projects"
    if not projects_dir.exists():
        return None
    # Claude Code encodes workspace path: /home/user/foo → -home-user-foo
    encoded = str(workspace_path).replace("/", "-")
    if encoded.startswith("-"):
        pass  # already starts with -
    project_path = projects_dir / encoded
    if project_path.exists():
        return project_path
    # Fallback: try to find a matching directory
    for d in projects_dir.iterdir():
        if d.is_dir() and str(workspace_path).replace("/", "-") in d.name:
            return d
    return None


def _is_workspace_state_file(path: Path, workspace_root: Path) -> bool:
    try:
        relative = path.relative_to(workspace_root)
    except ValueError:
        return False

    hidden_dirs = {part for part in relative.parts[:-1] if part.startswith(".")}
    if hidden_dirs:
        return False

    ignored_dirs = {"node_modules", ".git", ".venv", "__pycache__"}
    if any(part in ignored_dirs for part in relative.parts[:-1]):
        return False

    name = path.name.lower()
    path_text = str(relative).lower()
    tracked_suffixes = {".md", ".json", ".txt", ".log", ".jsonl"}
    tracked_dirs = {"memory", "process", "logs", "prompts", "instructions", "artifacts"}
    tracked_terms = {"claude", "soul", "memory", "session", "skill", "instruction", "prompt", "log"}

    return (
        path.name == "CLAUDE.md"
        or path.suffix.lower() in tracked_suffixes
        or any(part.lower() in tracked_dirs for part in relative.parts[:-1])
        or any(term in name or term in path_text for term in tracked_terms)
    )
def _claude_session_sort_key(path: Path) -> tuple[float, float]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return (0.0, 0.0)

    for line in reversed(lines):
        if not line.strip():
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        timestamp = _extract_claude_timestamp(payload)
        if timestamp is not None:
            return (timestamp, path.stat().st_mtime)

    try:
        return (0.0, path.stat().st_mtime)
    except OSError:
        return (0.0, 0.0)


def _extract_claude_timestamp(payload: dict) -> float | None:
    candidates = [
        payload.get("timestamp"),
        payload.get("createdAt"),
    ]
    message = payload.get("message")
    if isinstance(message, dict):
        candidates.extend([message.get("timestamp"), message.get("createdAt")])
    snapshot = payload.get("snapshot")
    if isinstance(snapshot, dict):
        candidates.append(snapshot.get("timestamp"))
    for candidate in candidates:
        if isinstance(candidate, str):
            try:
                return datetime.fromisoformat(candidate.replace("Z", "+00:00")).timestamp()
            except ValueError:
                continue
    return None


def _looks_like_log_file(path: Path) -> bool:
    name = path.name.lower()
    if name in {"log", "logs"}:
        return True
    if name.endswith(".log"):
        return True
    return False


class ClaudeCodeAdapter(AgentAdapter):
    agent_type = AgentType.CLAUDE_CODE

    def __init__(self, process_scope: str = "current") -> None:
        self.process_scope = process_scope if process_scope in {"current", "all"} else "current"

    def discover(self, workspace: str) -> list[Path]:
        """Discover Claude Code's actual state files, NOT the workspace code.

        Targets:
        - CLAUDE.md (project skills/rules) → skills
        - ~/.claude/projects/<ws>/memory/ (agent memory) → memory
        - ~/.claude/projects/<ws>/<session>.jsonl (transcript) → process
        - Workspace files matching *soul*, *memory*, *skill* patterns → respective namespaces
        """
        workspace_path = Path(workspace).resolve()
        candidates: list[Path] = []
        claude_home = Path.home() / ".claude"

        # 1. Claude Code project directory (~/.claude/projects/<encoded-path>/)
        project_dir = _claude_project_dir(workspace)
        if project_dir:
            # Memory files
            memory_dir = project_dir / "memory"
            if memory_dir.exists():
                for f in memory_dir.rglob("*"):
                    if f.is_file():
                        candidates.append(f)

            # Transcripts (session .jsonl files)
            transcripts = sorted(project_dir.glob("*.jsonl"), key=_claude_session_sort_key, reverse=True)
            if self.process_scope != "all":
                transcripts = transcripts[:1]
            else:
                transcripts = transcripts[:20]
            for f in transcripts:
                if f.is_file():
                    candidates.append(f)

        # 1.5 Global Claude guidance/config/plugins.
        for root in (
            claude_home / "commands",
            claude_home / "agents",
            claude_home / "plugins" / "marketplaces",
            workspace_path / ".claude",
        ):
            for f in collect_text_files(root, max_files=80, exclude_names=_CLAUDE_EXCLUDED_CONTEXT_FILES):
                append_unique(candidates, f)

        # 2. Workspace-local guidance/state files.
        for f in sorted(workspace_path.rglob("*")):
            if f.is_file() and _is_workspace_state_file(f, workspace_path) and f not in candidates:
                candidates.append(f)
            if len(candidates) >= 100:
                break

        return candidates[:100]

    def extract(self, workspace: str) -> list[dict]:
        workspace_path = Path(workspace).resolve()
        project_dir = _claude_project_dir(workspace)
        claude_home = Path.home() / ".claude"
        records = []

        for path in self.discover(workspace):
            # Classify based on what the file actually is
            if path.name == "CLAUDE.md":
                namespace = "skills"
                relative = path.name
            elif project_dir and str(path).startswith(str(project_dir)):
                # Files from ~/.claude/projects/<ws>/
                relative = str(path.relative_to(project_dir))
                if "/memory/" in str(path) or path.parent.name == "memory":
                    namespace = "memory"
                elif path.suffix == ".jsonl":
                    namespace = "process"  # transcripts
                else:
                    namespace = "memory"
            elif path.is_relative_to(claude_home):
                relative = f"skills/claude/global/{path.relative_to(claude_home)}"
                namespace = "skills"
            else:
                # User-created files in workspace
                relative = str(path.relative_to(workspace_path))
                relative_lower = relative.lower()
                name_lower = path.name.lower()
                path_parts = {part.lower() for part in Path(relative).parts[:-1]}
                if "soul" in name_lower or "soul" in relative_lower:
                    namespace = "soul"
                elif "memory" in path_parts or "memory" in name_lower or "session" in name_lower:
                    namespace = "memory"
                elif "process" in path_parts or "logs" in path_parts or _looks_like_log_file(path):
                    namespace = "process"
                elif (
                    "prompts" in path_parts
                    or "instructions" in path_parts
                    or "skill" in name_lower
                    or "instruction" in name_lower
                    or "prompt" in name_lower
                ):
                    namespace = "skills"
                else:
                    namespace = "artifacts"

            # For transcripts, parse to canonical format + render markdown
            canonical_transcript = None
            if namespace == "process" and path.suffix == ".jsonl":
                try:
                    from anyfs_transcript import parse_transcript, render_markdown
                    canonical = parse_transcript(path, agent_type="claude-code")
                    content = render_markdown(canonical)
                    canonical_transcript = canonical.model_dump(mode="json")
                except Exception:
                    content = _summarize_transcript(path)
            else:
                content = read_text_file(path)

            record = {
                "path": str(path),
                "relative_path": relative,
                "namespace": namespace,
                "content": content,
            }
            if canonical_transcript:
                record["canonical_transcript"] = canonical_transcript
            records.append(record)

        return records

    def normalize(self, raw: list[dict]) -> dict[str, list[dict]]:
        normalized: dict[str, list[dict]] = {}
        for record in raw:
            normalized.setdefault(record["namespace"], []).append(record)
        return normalized

    def bundle(self, normalized: dict[str, list[dict]], policy: dict | None = None) -> CaptureResult:
        trajectory = {ns: items for ns, items in normalized.items() if ns != "artifacts"}
        components = [Namespace(ns) for ns in trajectory.keys()]
        return CaptureResult(
            agent_id="pending",
            agent_type=self.agent_type,
            workspace="",
            code_ref=CodeRef(),
            workspace_overlay=WorkspaceOverlay(mode="none", binding=WorkspaceBinding(cwd="")),
            trajectory=trajectory,
            artifacts=normalized.get("artifacts", []),
            trajectory_components=components,
            captured_namespaces=list(normalized.keys()),
            payloads=normalized,
            warnings=[] if normalized else ["no Claude Code files were discovered"],
        )


def _summarize_transcript(jsonl_path: Path) -> str:
    """Extract a readable summary from a Claude Code transcript .jsonl file.

    Pulls out user messages and assistant text (skipping tool calls and system messages)
    to create a conversation summary that's useful for sharing.
    """
    lines = []
    try:
        for raw_line in jsonl_path.read_text(encoding="utf-8").splitlines():
            if not raw_line.strip():
                continue
            try:
                msg = json.loads(raw_line)
            except json.JSONDecodeError:
                continue

            msg_type = msg.get("type", "")
            role = msg.get("role", "")

            if msg_type == "human" or role == "human":
                content = msg.get("content", "")
                if isinstance(content, list):
                    text_parts = [p.get("text", "") for p in content if isinstance(p, dict) and p.get("type") == "text"]
                    content = "\n".join(text_parts)
                if content.strip():
                    lines.append(f"## User\n{content.strip()}")

            elif msg_type == "assistant" or role == "assistant":
                content = msg.get("content", "")
                if isinstance(content, list):
                    text_parts = [p.get("text", "") for p in content if isinstance(p, dict) and p.get("type") == "text"]
                    content = "\n".join(text_parts)
                if content.strip():
                    # Truncate long assistant responses
                    if len(content) > 500:
                        content = content[:500] + "\n... (truncated)"
                    lines.append(f"## Assistant\n{content.strip()}")

    except Exception:
        return f"(transcript at {jsonl_path.name}, could not parse)"

    if not lines:
        return f"(transcript at {jsonl_path.name}, no messages extracted)"

    return "\n\n".join(lines)
