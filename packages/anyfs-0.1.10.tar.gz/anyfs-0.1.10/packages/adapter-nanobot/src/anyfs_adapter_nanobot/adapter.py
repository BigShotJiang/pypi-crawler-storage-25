from __future__ import annotations

import os
import json
from datetime import datetime
from pathlib import Path

from anyfs_adapters_core import AgentAdapter, append_unique, collect_text_files, read_text_file
from anyfs_schemas import AgentType, CaptureResult, CodeRef, Namespace, WorkspaceBinding, WorkspaceOverlay
from anyfs_transcript import parse_transcript, render_markdown

_DEFAULT_NANOBOT_HOME = ".nanobot"
_NANOBOT_EXCLUDED_CONTEXT_FILES = {"config.json"}


def _nanobot_home() -> Path:
    return Path(os.environ.get("NANOBOT_HOME", Path.home() / _DEFAULT_NANOBOT_HOME)).expanduser()
def _nanobot_session_sort_key(path: Path) -> tuple[float, float]:
    try:
        first_line = path.read_text(encoding="utf-8").split("\n", 1)[0]
        payload = json.loads(first_line)
    except (OSError, json.JSONDecodeError):
        try:
            return (0.0, path.stat().st_mtime)
        except OSError:
            return (0.0, 0.0)

    updated_at = payload.get("updated_at")
    if isinstance(updated_at, str):
        try:
            return (datetime.fromisoformat(updated_at).timestamp(), path.stat().st_mtime)
        except ValueError:
            pass
    try:
        return (0.0, path.stat().st_mtime)
    except OSError:
        return (0.0, 0.0)


def _nanobot_process_files(workspace_path: Path, process_scope: str = "current") -> list[Path]:
    sessions_dir = workspace_path / "sessions"
    if not sessions_dir.exists():
        return []

    sessions = sorted(sessions_dir.glob("*.jsonl"), key=_nanobot_session_sort_key, reverse=True)
    if process_scope == "all":
        return sessions[:20]
    return sessions[:1]


class NanobotAdapter(AgentAdapter):
    agent_type = AgentType.NANOBOT

    def __init__(self, process_scope: str = "current") -> None:
        self.process_scope = process_scope if process_scope in {"current", "all"} else "current"

    def discover(self, workspace: str) -> list[Path]:
        workspace_path = Path(workspace).resolve()
        nanobot_home = _nanobot_home()
        candidates: list[Path] = list(_nanobot_process_files(workspace_path, self.process_scope))

        for path in (
            workspace_path / "SOUL.md",
            workspace_path / "USER.md",
            workspace_path / "AGENTS.md",
            workspace_path / "HEARTBEAT.md",
            workspace_path / "memory" / "MEMORY.md",
            workspace_path / "memory" / "history.jsonl",
        ):
            append_unique(candidates, path)

        for root in (
            workspace_path / "skills",
            workspace_path / ".nanobot",
            nanobot_home / "skills",
        ):
            for path in collect_text_files(root, max_files=120, exclude_names=_NANOBOT_EXCLUDED_CONTEXT_FILES):
                append_unique(candidates, path)

        return candidates[:200]

    def extract(self, workspace: str) -> list[dict]:
        workspace_path = Path(workspace).resolve()
        nanobot_home = _nanobot_home()
        records = []
        for path in self.discover(workspace):
            name = path.name.lower()
            if path.suffix == ".jsonl" and path.parent == workspace_path / "sessions":
                try:
                    canonical = parse_transcript(path, agent_type="nanobot")
                    records.append(
                        {
                            "path": str(path),
                            "relative_path": f"process/nanobot/{path.name}",
                            "namespace": "process",
                            "content": render_markdown(canonical),
                            "canonical_transcript": canonical.model_dump(mode="json"),
                        }
                    )
                    continue
                except Exception:
                    pass

            if name == "soul.md":
                namespace = "soul"
            elif name == "user.md":
                namespace = "user"
            elif "memory" in path.parts or name == "history.jsonl":
                namespace = "memory"
            elif name in {"agents.md", "heartbeat.md"} or path.is_relative_to(workspace_path / "skills") or path.is_relative_to(workspace_path / ".nanobot") or path.is_relative_to(nanobot_home / "skills"):
                namespace = "skills"
            else:
                namespace = "artifacts"

            if path.is_relative_to(nanobot_home):
                relative_path = f"{namespace}/nanobot/global/{path.relative_to(nanobot_home)}"
            else:
                relative_path = str(path.relative_to(workspace_path))

            records.append(
                {
                    "path": str(path),
                    "relative_path": relative_path,
                    "namespace": namespace,
                    "content": read_text_file(path),
                }
            )
        return records

    def normalize(self, raw: list[dict]) -> dict[str, list[dict]]:
        normalized: dict[str, list[dict]] = {}
        for record in raw:
            normalized.setdefault(record["namespace"], []).append(record)
        return normalized

    def bundle(self, normalized: dict[str, list[dict]], policy: dict | None = None) -> CaptureResult:
        trajectory = {ns: items for ns, items in normalized.items() if ns != "artifacts"}
        components = [Namespace(ns) for ns in trajectory.keys()]
        return CaptureResult(
            agent_id="pending",
            agent_type=self.agent_type,
            workspace="",
            code_ref=CodeRef(),
            workspace_overlay=WorkspaceOverlay(mode="none", binding=WorkspaceBinding(cwd="")),
            trajectory=trajectory,
            artifacts=normalized.get("artifacts", []),
            trajectory_components=components,
            captured_namespaces=list(normalized.keys()),
            payloads=normalized,
            warnings=[] if normalized else ["no nanobot files were discovered"],
        )
