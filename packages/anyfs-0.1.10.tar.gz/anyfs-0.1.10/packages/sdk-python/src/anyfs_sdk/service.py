from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import uuid
from base64 import b64decode, b64encode
from io import BytesIO
from pathlib import Path
from typing import Any
import zipfile

import httpx

from anyfs_adapter_claude_code import ClaudeCodeAdapter
from anyfs_adapter_codex_cli import CodexCLIAdapter
from anyfs_adapter_gemini_cli import GeminiCLIAdapter
from anyfs_adapter_hermes import HermesAdapter
from anyfs_adapter_nanobot import NanobotAdapter
from anyfs_adapter_opencode import OpenCodeAdapter
from anyfs_adapter_openclaw import OpenClawAdapter
from anyfs_crypto import create_auth_header, decrypt_json_payload, decrypt_shared_payload, encrypt_json_payload, ensure_root_key, export_recovery_bundle, import_recovery_bundle, load_root_key, rewrap_dek_for_share
from anyfs_lineage import make_lineage_record
from anyfs_local_state import (
    append_backup,
    append_lineage,
    append_link,
    append_package,
    append_release,
    append_snapshot,
    default_global_root,
    default_workspace_root,
    doctor,
    initialize_global_state,
    latest_capture,
    latest_snapshot_id,
    lineage_for_package,
    list_registered_agents,
    list_backups,
    list_links,
    list_packages,
    list_snapshots,
    workspace_agent_by_id,
    workspace_agent_private_key,
    read_agent_remote_state,
    read_config,
    read_json,
    read_manifest,
    record_capture,
    rename_agent,
    register_agent,
    workspace_agent,
    write_agent_remote_state,
    write_config,
    write_json,
    write_manifest,
)
from anyfs_packaging import build_afpkg, extract_afpkg
from anyfs_schemas import (
    AgentAuthMode,
    AgentAuthRegisterRequest,
    AgentBindingStatus,
    AgentRenameRequest,
    AgentRecord,
    AgentRecordLite,
    AgentStatusResponse,
    AgentType,
    ArtifactsSummary,
    AuthStatus,
    BackupCreateRequest,
    BackupRecord,
    CaptureResult,
    CodeRef,
    CodeRefProvider,
    LinkCreateRequest,
    LinkRecord,
    Namespace,
    PackageCreateRequest,
    PackageManifest,
    PackageRecord,
    PublishVisibilityMode,
    PublishResult,
    ReleaseRecord,
    SnapshotManifest,
    SnapshotRecord,
    SnapshotRecordLite,
    TrajectorySummary,
    Visibility,
    WorkspaceBinding,
    WorkspaceOverlay,
    WorkspaceOverlayFile,
    WorkspaceOverlaySummary,
    utc_now_iso,
)
from anyfs_skill_spec import ACTION_SPECS


class AnyFSService:
    _PROJECT_GUIDANCE_FILES = {
        "agents.md",
        "claude.md",
        "gemini.md",
        "tools.md",
        "bootstrap.md",
        "heartbeat.md",
        "identity.md",
    }
    _CLAUDE_SKILL_RE = re.compile(r"(?<!\w)/([a-z0-9][a-z0-9:_-]*)", re.IGNORECASE)
    _CODEX_SKILL_RE = re.compile(r"(?<!\w)\$([a-z0-9][a-z0-9:_-]*)", re.IGNORECASE)
    _GEMINI_COMMAND_RE = re.compile(r"(?<!\w)/([a-z0-9][a-z0-9:_-]*)", re.IGNORECASE)
    _OPENCODE_AGENT_RE = re.compile(r"(?<!\w)@([a-z0-9][a-z0-9:_-]*)", re.IGNORECASE)
    _OPENCODE_SKILL_NAME_RE = re.compile(r'"name"\s*:\s*"([a-z0-9][a-z0-9:_-]*)"', re.IGNORECASE)
    _PUBLISHABLE_CODE_AGENTS = {
        AgentType.CLAUDE_CODE.value,
        AgentType.CODEX_CLI.value,
        AgentType.GEMINI_CLI.value,
        AgentType.OPENCODE.value,
    }
    _CODE_AGENT_PRIORITY = [
        AgentType.CODEX_CLI.value,
        AgentType.CLAUDE_CODE.value,
        AgentType.GEMINI_CLI.value,
        AgentType.OPENCODE.value,
    ]

    def __init__(
        self,
        global_root: Path | None = None,
        api_base_url: str | None = None,
        auth_token: str | None = None,
        agent_token: str | None = None,
        api_client: Any | None = None,
    ) -> None:
        self.global_root = default_global_root(global_root)
        self.api_base_url = api_base_url
        self.auth_token = auth_token
        self.agent_token = agent_token
        self.api_client = api_client

    def _identity(self) -> dict[str, Any]:
        return read_json(self.global_root / "identity.json", {})

    def _root_key(self) -> bytes:
        return load_root_key(self.global_root, self._identity())

    def _config(self) -> dict[str, Any]:
        return read_config(self.global_root)

    def _effective_api_base_url(self, workspace: str | None = None, agent_type: str | None = None) -> str | None:
        # Explicit overrides win.
        if self.api_base_url:
            return self.api_base_url
        env_url = os.getenv("ANYFS_API_BASE_URL")
        if env_url:
            return env_url
        # Prefer the URL recorded when the workspace's agent was registered.
        # This keeps a workspace pinned to the API it was registered against,
        # so an agent registered on a local dev API doesn't try to talk to the
        # global default on subsequent commands.
        if workspace:
            try:
                remote_state = read_agent_remote_state(workspace, agent_type, self.global_root)
            except Exception:
                remote_state = {}
            ws_url = remote_state.get("api_base_url") if remote_state else None
            if ws_url:
                return ws_url
        return self._config().get("default_api_base_url")

    def _effective_user_token(self) -> str | None:
        return self.auth_token or os.getenv("ANYFS_AUTH_TOKEN") or self._config().get("auth_token")

    def _effective_agent_token(self) -> str | None:
        return self.agent_token or os.getenv("ANYFS_AGENT_TOKEN") or self._config().get("agent_token")

    def _effective_storage_gateway_url(self) -> str | None:
        config = self._config()
        return (
            os.getenv("ANYFS_STORAGE_GATEWAY_URL")
            or config.get("storage_gateway_url")
            or os.getenv("ANYFS_SIDECAR_URL")
            or config.get("sidecar_url")
        )

    def _git_output(self, workspace_path: Path, *args: str) -> str | None:
        result = subprocess.run(
            ["git", *args],
            cwd=str(workspace_path),
            text=True,
            capture_output=True,
            check=False,
        )
        if result.returncode != 0:
            return None
        output = result.stdout.strip()
        return output or None

    def _workspace_git_metadata(self, workspace_path: Path) -> dict[str, Any]:
        repo_root = self._git_output(workspace_path, "rev-parse", "--show-toplevel")
        if not repo_root:
            return WorkspaceBinding(cwd=str(workspace_path)).model_dump(mode="json")
        branch = self._git_output(workspace_path, "rev-parse", "--abbrev-ref", "HEAD")
        commit = self._git_output(workspace_path, "rev-parse", "HEAD")
        remote = self._git_output(workspace_path, "config", "--get", "remote.origin.url")
        status = self._git_output(workspace_path, "status", "--short")
        return WorkspaceBinding(
            cwd=str(workspace_path),
            repo_root=repo_root,
            branch=branch,
            commit_sha=commit,
            remote=remote,
            dirty=bool(status),
            status_summary=status.splitlines()[:50] if status else [],
        ).model_dump(mode="json")

    def _workspace_subdir(self, workspace_path: Path, repo_root: str | None) -> str | None:
        if not repo_root:
            return None
        try:
            relative = workspace_path.resolve().relative_to(Path(repo_root).resolve())
        except ValueError:
            return None
        rel = str(relative)
        return None if rel in {".", ""} else rel

    def _code_ref_from_binding(self, workspace_path: Path, binding: dict[str, Any]) -> dict[str, Any]:
        repo_root = binding.get("repo_root")
        remote = binding.get("remote")
        provider = CodeRefProvider.NONE
        if remote:
            provider = CodeRefProvider.GITHUB if "github.com" in remote.lower() else CodeRefProvider.GIT
        elif repo_root:
            provider = CodeRefProvider.GIT
        return CodeRef(
            provider=provider,
            repo_url=remote,
            default_branch=binding.get("branch"),
            commit_sha=binding.get("commit_sha"),
            subdir=self._workspace_subdir(workspace_path, repo_root),
        ).model_dump(mode="json")

    def _package_identity(
        self,
        workspace_path: Path,
        code_ref: dict[str, Any] | None,
        binding: dict[str, Any] | None,
    ) -> tuple[str | None, str | None]:
        repo_url = (code_ref or {}).get("repo_url") or ""
        cleaned = (
            repo_url.replace("git@", "", 1)
            .replace("ssh://git@", "", 1)
            .replace("https://", "", 1)
            .replace("http://", "", 1)
        )
        if ":" in cleaned and "/" not in cleaned.split(":", 1)[0]:
            cleaned = cleaned.replace(":", "/", 1)
        cleaned = cleaned.split("/", 1)[1] if "/" in cleaned and "." in cleaned.split("/", 1)[0] else cleaned
        cleaned = cleaned.removesuffix(".git").strip("/")
        segments = [segment for segment in cleaned.split("/") if segment]
        repo_owner = segments[-2] if len(segments) > 1 else None
        project_name = segments[-1] if segments else None
        if not project_name:
            cwd = (binding or {}).get("cwd")
            project_name = Path(cwd).name if cwd else workspace_path.name
        return repo_owner, project_name

    def _trajectory_from_payloads(self, normalized: dict[str, list[dict[str, Any]]]) -> tuple[dict[str, list[dict[str, Any]]], list[dict[str, Any]], list[str]]:
        trajectory: dict[str, list[dict[str, Any]]] = {}
        components: list[str] = []
        for namespace, items in normalized.items():
            if namespace == "artifacts":
                continue
            trajectory[namespace] = items
            components.append(namespace)
        return trajectory, normalized.get("artifacts", []), components

    def _capture_agent_types(self, primary_agent_type: str, client_scope: str) -> list[str]:
        if client_scope != "project":
            return [primary_agent_type]
        ordered = [
            primary_agent_type,
            AgentType.CLAUDE_CODE.value,
            AgentType.CODEX_CLI.value,
            AgentType.GEMINI_CLI.value,
            AgentType.OPENCODE.value,
        ]
        seen: set[str] = set()
        result: list[str] = []
        for agent_type in ordered:
            if agent_type in seen:
                continue
            seen.add(agent_type)
            result.append(agent_type)
        return result

    def _merge_normalized_payloads(self, bundles: list[dict[str, list[dict[str, Any]]]]) -> dict[str, list[dict[str, Any]]]:
        merged: dict[str, list[dict[str, Any]]] = {}
        seen: set[tuple[str, str, str]] = set()
        for bundle in bundles:
            for namespace, items in bundle.items():
                target = merged.setdefault(namespace, [])
                for item in items:
                    key = (
                        namespace,
                        str(item.get("relative_path") or ""),
                        str(item.get("path") or ""),
                    )
                    if key in seen:
                        continue
                    seen.add(key)
                    target.append(item)
        return merged

    def _normalize_skill_ref(self, value: str) -> str:
        token = value.strip().lower()
        token = token.lstrip("/$@")
        token = token.replace("_", "-")
        return token

    def _is_project_guidance_record(self, item: dict[str, Any]) -> bool:
        relative = str(item.get("relative_path") or "")
        if not relative:
            return False
        parts = Path(relative).parts
        if not parts:
            return False
        if len(parts) >= 2 and parts[0] == ".agents" and parts[1] == "skills":
            return True
        if len(parts) >= 2 and parts[0] == ".claude" and parts[1] in {"commands", "agents", "rules"}:
            return True
        if len(parts) >= 2 and parts[0] == ".gemini" and parts[1] == "commands":
            return True
        return parts[0].lower() in self._PROJECT_GUIDANCE_FILES

    def _is_full_personal_agent_skill_record(self, item: dict[str, Any]) -> bool:
        relative = str(item.get("relative_path") or "")
        if not relative:
            return False
        if relative.startswith("skills/openclaw/global/"):
            return True
        if relative.startswith("skills/hermes/global/"):
            return True
        if relative.startswith("skills/nanobot/global/"):
            return True
        if relative.startswith(".openclaw/") or relative.startswith(".hermes/") or relative.startswith(".nanobot/"):
            return True
        if relative.startswith("skills/") and not any(
            relative.startswith(prefix)
            for prefix in (
                "skills/codex/",
                "skills/claude/",
                "skills/gemini/",
                "skills/opencode/",
                "skills/openclaw/",
                "skills/hermes/",
                "skills/nanobot/",
            )
        ):
            return True
        return False

    def _is_global_skill_record(self, item: dict[str, Any]) -> bool:
        relative = str(item.get("relative_path") or "")
        return "/global/" in relative or relative.startswith("skills/") and "/global/" in f"/{relative}"

    def _skill_item_agent(self, item: dict[str, Any]) -> str | None:
        relative = str(item.get("relative_path") or "").lower()
        if relative.startswith("skills/codex/") or relative.startswith(".agents/"):
            return AgentType.CODEX_CLI.value
        if relative.startswith("skills/claude/") or relative.startswith(".claude/") or relative == "claude.md":
            return AgentType.CLAUDE_CODE.value
        if relative.startswith("skills/gemini/") or relative.startswith(".gemini/") or relative == "gemini.md":
            return AgentType.GEMINI_CLI.value
        if relative.startswith("skills/opencode/") or relative.startswith(".opencode/"):
            return AgentType.OPENCODE.value
        if relative.startswith("skills/openclaw/") or relative.startswith(".openclaw/"):
            return AgentType.OPENCLAW.value
        if relative.startswith("skills/hermes/") or relative.startswith(".hermes/"):
            return AgentType.HERMES.value
        if relative.startswith("skills/nanobot/") or relative.startswith(".nanobot/"):
            return AgentType.NANOBOT.value
        return None

    def _global_skill_bundle_key(self, item: dict[str, Any]) -> tuple[str, str, str] | None:
        relative = str(item.get("relative_path") or "")
        parts = Path(relative).parts
        if len(parts) >= 5 and parts[0] == "skills" and parts[2] == "global" and parts[3] == "skills":
            agent = self._skill_item_agent(item)
            if not agent:
                return None
            skill_name = self._normalize_skill_ref(parts[4])
            bundle_root = str(Path(*parts[:5]))
            return (agent, skill_name, bundle_root)
        return None

    def _dedupe_skills_by_name(self, normalized: dict[str, list[dict[str, Any]]], primary_agent_type: str) -> dict[str, list[dict[str, Any]]]:
        skill_items = normalized.get(Namespace.SKILLS.value)
        if not skill_items:
            return normalized

        grouped: dict[str, dict[str, list[dict[str, Any]]]] = {}
        passthrough: list[dict[str, Any]] = []
        for item in skill_items:
            bundle = self._global_skill_bundle_key(item)
            if not bundle:
                passthrough.append(item)
                continue
            agent, skill_name, _bundle_root = bundle
            grouped.setdefault(skill_name, {}).setdefault(agent, []).append(item)

        preferred_order = [primary_agent_type, *[agent for agent in self._CODE_AGENT_PRIORITY if agent != primary_agent_type]]
        deduped = list(passthrough)
        for per_agent in grouped.values():
            if len(per_agent) == 1:
                deduped.extend(next(iter(per_agent.values())))
                continue
            chosen_items: list[dict[str, Any]] | None = None
            for agent in preferred_order:
                if agent in per_agent:
                    chosen_items = per_agent[agent]
                    break
            if chosen_items is None:
                chosen_items = next(iter(per_agent.values()))
            deduped.extend(chosen_items)

        normalized[Namespace.SKILLS.value] = deduped
        return normalized

    def _skill_record_refs(self, item: dict[str, Any]) -> set[str]:
        relative = str(item.get("relative_path") or "")
        if not relative:
            return set()
        path = Path(relative)
        raw_parts = [part for part in path.parts if part not in {".", ".."}]
        parts = [self._normalize_skill_ref(part) for part in raw_parts]
        refs: set[str] = set()
        ignore = {
            "skills",
            "global",
            "codex",
            "claude",
            "gemini",
            "openclaw",
            "opencode",
            "hermes",
            "nanobot",
            "project",
            "personal",
            "plugin",
            "commands",
            "agents",
            "prompts",
            "rules",
            "memory",
            "process",
            "workspace",
        }
        for idx, part in enumerate(parts):
            if part in {"skills", "commands", "agents", "prompts", "rules"} and idx + 1 < len(parts):
                name = parts[idx + 1]
                if name and name not in ignore and not name.endswith(('.md', '.json', '.toml')):
                    refs.add(name)
                    if "plugins" in parts:
                        try:
                            plugin_idx = parts.index("plugins")
                            plugin = parts[plugin_idx + 1]
                            if plugin and plugin not in ignore:
                                refs.add(f"{plugin}:{name}")
                        except (ValueError, IndexError):
                            pass
        stem = self._normalize_skill_ref(path.stem)
        if stem and stem not in ignore and stem not in {"skill", "index", "readme"}:
            refs.add(stem)
        parent = self._normalize_skill_ref(path.parent.name)
        if path.name.upper() == "SKILL.MD" and parent and parent not in ignore:
            refs.add(parent)
        return refs

    def _plugin_root_key(self, item: dict[str, Any]) -> str | None:
        relative = str(item.get("relative_path") or "")
        if not relative:
            return None
        parts = [self._normalize_skill_ref(part) for part in Path(relative).parts]
        try:
            plugins_idx = parts.index("plugins")
        except ValueError:
            return None
        # codex/plugins/<plugin>/...
        if plugins_idx + 1 < len(parts):
            if parts[plugins_idx + 1] == "marketplaces" and plugins_idx + 4 < len(parts):
                marketplace = parts[plugins_idx + 2]
                section = parts[plugins_idx + 3]
                plugin = parts[plugins_idx + 4]
                if section in {"external-plugins", "external_plugins", "plugins"}:
                    return f"{marketplace}/{plugin}"
                return marketplace
            plugin = parts[plugins_idx + 1]
            if plugin and plugin not in {"cache", "known-marketplaces"}:
                return plugin
        return None

    def _is_plugin_metadata_record(self, item: dict[str, Any]) -> bool:
        name = Path(str(item.get("relative_path") or "")).name.lower()
        return name in {
            "readme.md",
            "plugin.json",
            "package.json",
            "marketplace.json",
            ".mcp.json",
        }

    def _skill_refs_from_text(self, agent: str, text: str) -> set[str]:
        refs: set[str] = set()
        if agent == AgentType.CLAUDE_CODE.value:
            refs.update(self._normalize_skill_ref(match) for match in self._CLAUDE_SKILL_RE.findall(text))
        elif agent == AgentType.CODEX_CLI.value:
            refs.update(self._normalize_skill_ref(match) for match in self._CODEX_SKILL_RE.findall(text))
        elif agent == AgentType.GEMINI_CLI.value:
            refs.update(self._normalize_skill_ref(match) for match in self._GEMINI_COMMAND_RE.findall(text))
        elif agent == AgentType.OPENCODE.value:
            refs.update(self._normalize_skill_ref(match) for match in self._OPENCODE_AGENT_RE.findall(text))
            if "[Tool: skill]" in text:
                refs.update(self._normalize_skill_ref(match) for match in self._OPENCODE_SKILL_NAME_RE.findall(text))
        return {ref for ref in refs if ref}

    def _used_skill_refs_from_process(self, normalized: dict[str, list[dict[str, Any]]]) -> set[str]:
        refs: set[str] = set()
        for item in normalized.get(Namespace.PROCESS.value, []):
            canonical = item.get("canonical_transcript")
            if not isinstance(canonical, dict):
                continue
            session = canonical.get("session") or {}
            agent = str(session.get("agent") or "")
            events = canonical.get("events") or []
            for event in events:
                if not isinstance(event, dict):
                    continue
                text = event.get("text")
                if isinstance(text, str) and text.strip():
                    refs.update(self._skill_refs_from_text(agent, text))
        return refs

    def _filter_skills_by_process_usage(self, normalized: dict[str, list[dict[str, Any]]]) -> dict[str, list[dict[str, Any]]]:
        skill_items = normalized.get(Namespace.SKILLS.value)
        if not skill_items:
            return normalized
        used_refs = self._used_skill_refs_from_process(normalized)
        filtered: list[dict[str, Any]] = []
        matched_plugin_roots: set[str] = set()
        for item in skill_items:
            if self._is_project_guidance_record(item):
                filtered.append(item)
                continue
            if self._is_full_personal_agent_skill_record(item):
                filtered.append(item)
                continue
            item_refs = self._skill_record_refs(item)
            if item_refs and item_refs.intersection(used_refs):
                filtered.append(item)
                plugin_root = self._plugin_root_key(item)
                if plugin_root:
                    matched_plugin_roots.add(plugin_root)
                continue
            if not self._is_global_skill_record(item):
                # Keep project-local skill files only when they look like guidance roots; otherwise require explicit usage.
                relative = str(item.get("relative_path") or "")
                if relative.startswith(".claude/") or relative.startswith(".codex/") or relative.startswith(".gemini/") or relative.startswith(".opencode/"):
                    if item_refs and item_refs.intersection(used_refs):
                        filtered.append(item)
                continue
        for item in skill_items:
            plugin_root = self._plugin_root_key(item)
            if plugin_root and plugin_root in matched_plugin_roots and self._is_plugin_metadata_record(item):
                if item not in filtered:
                    filtered.append(item)
        normalized[Namespace.SKILLS.value] = filtered
        return normalized

    def _trajectory_summary(self, trajectory: dict[str, list[dict[str, Any]]]) -> dict[str, Any]:
        counts = {namespace: len(items) for namespace, items in trajectory.items() if items}
        ordered = [
            namespace
            for namespace in (
                "process",
                "skills",
                "memory",
                "soul",
                "user",
            )
            if counts.get(namespace, 0) > 0
        ]
        return TrajectorySummary(components=ordered, counts=counts).model_dump(mode="json")

    def _publishable_trajectory(self, trajectory: dict[str, list[dict[str, Any]]]) -> dict[str, list[dict[str, Any]]]:
        publishable: dict[str, list[dict[str, Any]]] = {}
        for namespace, items in trajectory.items():
            filtered = self._filter_publishable_trajectory_records(namespace, items)
            if filtered:
                publishable[namespace] = filtered
        return publishable

    def _publishable_trajectory_summary(self, summary: dict[str, Any]) -> dict[str, Any]:
        filtered = self._publishable_trajectory(
            {
                namespace: [{}] * int(count)
                for namespace, count in summary.get("counts", {}).items()
                if count
            }
        )
        counts = {namespace: len(items) for namespace, items in filtered.items()}
        components = [namespace for namespace in summary.get("components", []) if namespace in counts]
        return TrajectorySummary(components=components, counts=counts).model_dump(mode="json")

    def _record_publish_agent(self, item: dict[str, Any]) -> str | None:
        canonical = item.get("canonical_transcript")
        if isinstance(canonical, dict):
            session = canonical.get("session")
            if isinstance(session, dict):
                agent = session.get("agent")
                if isinstance(agent, str) and agent:
                    return agent
        relative = str(item.get("relative_path") or "").lower()
        if relative.startswith("process/codex/") or relative.startswith("skills/codex/") or relative.startswith(".agents/"):
            return AgentType.CODEX_CLI.value
        if relative.startswith("process/gemini/") or relative.startswith("skills/gemini/") or relative.startswith(".gemini/") or relative == "gemini.md":
            return AgentType.GEMINI_CLI.value
        if relative.startswith("process/opencode/") or relative.startswith("skills/opencode/") or relative.startswith(".opencode/"):
            return AgentType.OPENCODE.value
        if relative.startswith("process/openclaw/") or relative.startswith("skills/openclaw/") or relative.startswith(".openclaw/"):
            return AgentType.OPENCLAW.value
        if relative.startswith("process/hermes/") or relative.startswith("skills/hermes/") or relative.startswith(".hermes/"):
            return AgentType.HERMES.value
        if relative.startswith("process/nanobot/") or relative.startswith("skills/nanobot/") or relative.startswith(".nanobot/"):
            return AgentType.NANOBOT.value
        if relative.startswith("skills/claude/") or relative.startswith(".claude/") or relative == "claude.md":
            return AgentType.CLAUDE_CODE.value
        return None

    def _is_publishable_skill_record(self, item: dict[str, Any]) -> bool:
        relative = str(item.get("relative_path") or "").lower()
        if relative.startswith(("skills/openclaw/", "skills/hermes/", "skills/nanobot/", ".openclaw/", ".hermes/", ".nanobot/")):
            return False
        agent = self._record_publish_agent(item)
        if agent is None:
            return True
        return agent in self._PUBLISHABLE_CODE_AGENTS

    def _is_publishable_process_record(self, item: dict[str, Any]) -> bool:
        canonical = item.get("canonical_transcript")
        if not isinstance(canonical, dict):
            return False
        agent = self._record_publish_agent(item)
        return agent in self._PUBLISHABLE_CODE_AGENTS

    def _filter_publishable_trajectory_records(self, namespace: str, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        if namespace in {Namespace.SOUL.value, Namespace.MEMORY.value}:
            return []
        if namespace == Namespace.PROCESS.value:
            return [item for item in items if self._is_publishable_process_record(item)]
        if namespace == Namespace.SKILLS.value:
            return [item for item in items if self._is_publishable_skill_record(item)]
        return items

    def _artifacts_summary(self, artifacts: list[dict[str, Any]], visibility: str = Visibility.PUBLIC.value) -> dict[str, Any]:
        index = []
        if visibility == Visibility.PUBLIC.value:
            index = [
                {
                    "path": item.get("relative_path") or item.get("path") or f"artifact-{index}",
                    **({"title": item.get("title")} if item.get("title") else {}),
                    **({"type": item.get("type")} if item.get("type") else {}),
                }
                for index, item in enumerate(artifacts)
            ]
        return ArtifactsSummary(
            visibility=visibility,
            count=len(artifacts),
            index=index,
        ).model_dump(mode="json")

    def _encode_artifact_file(self, path: Path, workspace_path: Path) -> dict[str, Any]:
        raw = path.read_bytes()
        try:
            content = raw.decode("utf-8")
            encoding = "utf-8"
        except UnicodeDecodeError:
            content = b64encode(raw).decode("ascii")
            encoding = "base64"
        try:
            relative = str(path.resolve().relative_to(workspace_path.resolve()))
        except ValueError:
            relative = path.name
        return {
            "path": str(path.resolve()),
            "relative_path": relative,
            "namespace": Namespace.ARTIFACTS.value,
            "encoding": encoding,
            "content": content,
            "size": len(raw),
            "title": path.name,
        }

    def _explicit_artifacts(self, workspace: str, artifact_paths: list[str] | None) -> list[dict[str, Any]]:
        if not artifact_paths:
            return []
        workspace_path = Path(workspace).resolve()
        files: list[Path] = []
        seen: set[Path] = set()
        for item in artifact_paths:
            candidate = Path(item).expanduser()
            if not candidate.is_absolute():
                candidate = (workspace_path / candidate).resolve()
            else:
                candidate = candidate.resolve()
            if not candidate.exists():
                continue
            if candidate.is_file():
                if candidate not in seen:
                    seen.add(candidate)
                    files.append(candidate)
                continue
            for path in sorted(candidate.rglob("*")):
                if path.is_file() and path not in seen:
                    seen.add(path)
                    files.append(path)
        return [self._encode_artifact_file(path, workspace_path) for path in files]

    def _hermes_home(self) -> Path:
        return Path(os.environ.get("HERMES_HOME", Path.home() / ".hermes")).expanduser().resolve()

    def _nanobot_home(self) -> Path:
        return Path(os.environ.get("NANOBOT_HOME", Path.home() / ".nanobot")).expanduser().resolve()

    def _gemini_home(self) -> Path:
        cli_home = os.environ.get("GEMINI_CLI_HOME")
        if cli_home:
            return (Path(cli_home).expanduser() / ".gemini").resolve()
        legacy_home = os.environ.get("GEMINI_HOME")
        if legacy_home:
            return Path(legacy_home).expanduser().resolve()
        return (Path.home() / ".gemini").resolve()

    def _secret_env_names(self) -> tuple[str, ...]:
        return (
            "OPENAI_API_KEY",
            "ANTHROPIC_API_KEY",
            "ANTHROPIC_AUTH_TOKEN",
            "GOOGLE_API_KEY",
            "GEMINI_API_KEY",
            "OPENROUTER_API_KEY",
            "GROQ_API_KEY",
            "ELEVENLABS_API_KEY",
            "TELEGRAM_BOT_TOKEN",
            "SLACK_BOT_TOKEN",
            "DISCORD_TOKEN",
        )

    def _runtime_config_candidates_for_source(self, source_agent: str) -> list[Path]:
        home = Path.home()
        if source_agent == AgentType.CLAUDE_CODE.value:
            return [home / ".claude" / "settings.json"]
        if source_agent == AgentType.CODEX_CLI.value:
            return [home / ".codex" / "config.toml"]
        if source_agent == AgentType.GEMINI_CLI.value:
            gemini_home = self._gemini_home()
            return [gemini_home / "settings.json", gemini_home / "projects.json"]
        if source_agent == AgentType.HERMES.value:
            return [self._hermes_home() / "config.yaml"]
        if source_agent == AgentType.NANOBOT.value:
            return [self._nanobot_home() / "config.json"]
        if source_agent == AgentType.OPENCLAW.value:
            return [Path(os.environ.get("OPENCLAW_HOME", home / ".openclaw")).expanduser().resolve() / "openclaw.json"]
        if source_agent == AgentType.OPENCODE.value:
            return [home / ".config" / "opencode" / "opencode.json"]
        return []

    def _redact_secret_text(self, content: str) -> tuple[str, bool]:
        patterns = [
            re.compile(r'(?im)^(\s*[\w.-]*(?:api[_-]?key|auth[_-]?token|token|authorization|secret|password)[\w.-]*\s*[:=]\s*)(.+)$'),
            re.compile(r'(?im)^(\s*"[\w.-]*(?:api[_-]?key|auth[_-]?token|token|authorization|secret|password)[\w.-]*"\s*:\s*)(".*?"|\'.*?\'|[^,\n]+)'),
            re.compile(r'(?im)\b(OPENAI_API_KEY|ANTHROPIC_API_KEY|ANTHROPIC_AUTH_TOKEN|GOOGLE_API_KEY|GEMINI_API_KEY|OPENROUTER_API_KEY|GROQ_API_KEY|ELEVENLABS_API_KEY|TELEGRAM_BOT_TOKEN|SLACK_BOT_TOKEN|DISCORD_TOKEN)\b(\s*[:=]\s*)([^\n]+)'),
        ]
        redacted = content
        changed = False
        for pattern in patterns:
            new_redacted, replacements = pattern.subn(r"\1\2***REDACTED***" if pattern.groups == 3 else r"\1***REDACTED***", redacted)
            if replacements:
                changed = True
                redacted = new_redacted
        return redacted, changed

    def _collect_secret_env_payload(self) -> dict[str, str]:
        payload: dict[str, str] = {}
        for env_name in self._secret_env_names():
            value = os.environ.get(env_name)
            if value:
                payload[env_name] = value
        return payload

    def _collect_migrate_extra_items(
        self,
        source_agent: str,
        *,
        preset: str,
        include_secrets: bool,
    ) -> dict[str, Any]:
        items: list[dict[str, Any]] = []
        redacted_items: list[str] = []
        secret_items: list[str] = []
        warnings: list[str] = []

        if preset == "full":
            for candidate in self._runtime_config_candidates_for_source(source_agent):
                if not candidate.exists() or not candidate.is_file():
                    continue
                try:
                    original = candidate.read_text(encoding="utf-8")
                except OSError as exc:
                    warnings.append(f"could not read runtime config {candidate}: {exc}")
                    continue
                content = original
                if not include_secrets:
                    content, changed = self._redact_secret_text(original)
                    if changed:
                        redacted_items.append(str(candidate))
                else:
                    secret_items.append(str(candidate))
                items.append(
                    {
                        "path": str(candidate),
                        "relative_path": f"runtime-config/{source_agent}/{candidate.name}",
                        "content": content,
                        "kind": "runtime-config",
                    }
                )

        if include_secrets:
            env_payload = self._collect_secret_env_payload()
            if env_payload:
                secret_items.extend(sorted(env_payload.keys()))
                items.append(
                    {
                        "path": "<env>",
                        "relative_path": f"runtime-config/{source_agent}/secrets.env.json",
                        "content": json.dumps(env_payload, indent=2, sort_keys=True),
                        "kind": "secret-env",
                    }
                )

        return {
            "items": items,
            "redacted_items": redacted_items,
            "secret_items": secret_items,
            "warnings": warnings,
        }

    def _normalized_relative_subpath(self, relative_path: str, namespace: str) -> Path:
        relative = Path(relative_path)
        parts = list(relative.parts)
        if parts and parts[0] == namespace:
            parts = parts[1:]
        return Path(*parts) if parts else Path(relative.name)

    def _guidance_alias_target(self, target: str, workspace_path: Path, source_name: str) -> Path | None:
        if target == AgentType.OPENCLAW.value and source_name in {"agents.md", "tools.md", "bootstrap.md", "heartbeat.md", "identity.md"}:
            return workspace_path / source_name.upper().replace(".MD", ".md")
        if target == AgentType.NANOBOT.value and source_name == "heartbeat.md":
            return workspace_path / "HEARTBEAT.md"
        if source_name in {"agents.md", "claude.md", "gemini.md"}:
            return self._guidance_path_for_target(target, workspace_path)
        return None

    def _target_projection(
        self,
        target: str,
        workspace_path: Path,
        source_agent: str,
        item: dict[str, Any],
        import_root: Path,
    ) -> tuple[Path, str]:
        namespace = item["namespace"]
        relative_path = item.get("relative_path") or Path(item["path"]).name
        source_name = Path(relative_path).name.lower()
        guidance_target = self._guidance_alias_target(target, workspace_path, source_name)
        if guidance_target is not None:
            return guidance_target, "merge"

        if target == AgentType.HERMES.value:
            hermes_home = self._hermes_home()
            if namespace == "soul":
                return hermes_home / "SOUL.md", "merge"
            if namespace == "user":
                return hermes_home / "memories" / "USER.md", "merge"
            if namespace == "memory":
                if source_name == "history.jsonl":
                    return import_root / "memory" / f"{source_agent}-history.jsonl", "copy"
                return hermes_home / "memories" / "MEMORY.md", "merge"
            if namespace == "skills":
                return hermes_home / "skills" / "anyfs-imports" / source_agent / self._normalized_relative_subpath(relative_path, namespace), "copy"

        if target == AgentType.NANOBOT.value:
            if namespace == "soul":
                return workspace_path / "SOUL.md", "merge"
            if namespace == "user":
                return workspace_path / "USER.md", "merge"
            if namespace == "memory":
                if source_name == "history.jsonl":
                    return import_root / "memory" / f"{source_agent}-history.jsonl", "copy"
                return workspace_path / "memory" / "MEMORY.md", "merge"
            if namespace == "skills":
                return workspace_path / "skills" / "anyfs-imports" / source_agent / self._normalized_relative_subpath(relative_path, namespace), "copy"

        if target == AgentType.OPENCLAW.value:
            if namespace == "soul":
                return workspace_path / "SOUL.md", "merge"
            if namespace == "user":
                return workspace_path / "USER.md", "merge"
            if namespace == "memory":
                if source_name == "history.jsonl":
                    return import_root / "memory" / f"{source_agent}-history.jsonl", "copy"
                return workspace_path / "memory" / "MEMORY.md", "merge"
            if namespace == "skills":
                return workspace_path / "skills" / "anyfs-imports" / source_agent / self._normalized_relative_subpath(relative_path, namespace), "copy"

        return import_root / namespace / self._normalized_relative_subpath(relative_path, namespace), "copy"

    def _merge_text_if_allowed(
        self,
        path: Path,
        content: str,
        overwrite: bool,
        *,
        source_agent: str,
        source_label: str,
    ) -> str:
        if not content.strip():
            return "skipped"
        if path.exists() and not overwrite:
            existing = path.read_text(encoding="utf-8")
            normalized_existing = " ".join(existing.split())
            normalized_content = " ".join(content.split())
            if normalized_content and normalized_content in normalized_existing:
                return "skipped"
            section = (
                f"\n\n---\n\n## Imported From AnyFS\n\n"
                f"- Source agent: `{source_agent}`\n"
                f"- Source item: `{source_label}`\n\n"
                f"{content.strip()}\n"
            )
            path.write_text(existing.rstrip() + section, encoding="utf-8")
            return "merged"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content.rstrip() + "\n", encoding="utf-8")
        return "written"

    def _native_resume_supported(self, target_agent: str) -> bool:
        return target_agent in {
            AgentType.CLAUDE_CODE.value,
            AgentType.CODEX_CLI.value,
            AgentType.GEMINI_CLI.value,
            AgentType.HERMES.value,
            AgentType.NANOBOT.value,
            AgentType.OPENCLAW.value,
            AgentType.OPENCODE.value,
        }

    def _context_injection_supported(self, target_agent: str) -> bool:
        return target_agent == AgentType.CURSOR.value

    def _write_process_context_note(
        self,
        transcript: Any,
        target_agent: str,
        target_workspace_path: Path,
        import_root: Path,
        overwrite: bool,
    ) -> dict[str, str]:
        from anyfs_transcript.injectors.context import render_resume_context

        note_path = import_root / "process" / f"{transcript.session.id}.md"
        note_body = (
            f"# Imported Session Context\n\n"
            f"- Source agent: `{transcript.session.agent}`\n"
            f"- Source session: `{transcript.session.id}`\n"
            f"- Target agent: `{target_agent}`\n\n"
            f"{render_resume_context(transcript)}\n"
        )
        self._write_text_if_allowed(note_path, note_body, overwrite)
        return {
            "process_note": str(note_path),
            "resume_hint": f"Review {note_path} and continue in {target_agent} from {target_workspace_path}",
        }

    def _workspace_changed_paths(self, workspace_path: Path) -> tuple[list[str], list[str]]:
        repo_root = self._git_output(workspace_path, "rev-parse", "--show-toplevel")
        if not repo_root:
            return [], []

        changed = self._git_output(workspace_path, "diff", "--name-only", "HEAD", "--")
        untracked = self._git_output(workspace_path, "ls-files", "--others", "--exclude-standard")
        deleted = self._git_output(workspace_path, "diff", "--name-only", "--diff-filter=D", "HEAD", "--")

        selected = {
            line.strip()
            for block in (changed, untracked)
            if block
            for line in block.splitlines()
            if line.strip()
        }
        deleted_paths = {
            line.strip()
            for line in (deleted or "").splitlines()
            if line.strip()
        }
        return sorted(selected - deleted_paths), sorted(deleted_paths)

    def _is_workspace_ignored(self, path: Path, workspace_path: Path) -> bool:
        try:
            relative = path.relative_to(workspace_path)
        except ValueError:
            return True
        ignored = {".git", ".anyfs", "node_modules", ".venv", "venv", "__pycache__", "dist", "build", ".next", ".cache"}
        return any(part in ignored for part in relative.parts)

    def _encode_workspace_file(self, path: Path) -> dict[str, Any] | None:
        raw = path.read_bytes()
        if len(raw) > 512 * 1024:
            return None
        try:
            content = raw.decode("utf-8")
            encoding = "utf-8"
        except UnicodeDecodeError:
            content = b64encode(raw).decode("ascii")
            encoding = "base64"
        return {
            "relative_path": path.name,
            "encoding": encoding,
            "content": content,
            "executable": os.access(path, os.X_OK),
            "size": len(raw),
        }

    def _snapshot_workspace_files(self, workspace_path: Path, mode: str) -> tuple[str, list[dict[str, Any]], list[str], list[str]]:
        omitted: list[str] = []
        deleted_paths: list[str] = []
        candidates: list[Path] = []
        effective_mode = mode

        if mode == "changed":
            changed_paths, deleted_paths = self._workspace_changed_paths(workspace_path)
            for rel in changed_paths:
                candidate = (workspace_path / rel).resolve()
                if candidate.exists() and candidate.is_file() and not self._is_workspace_ignored(candidate, workspace_path):
                    candidates.append(candidate)
            if not candidates:
                effective_mode = "full"

        if effective_mode == "full":
            for path in sorted(workspace_path.rglob("*")):
                if not path.is_file() or self._is_workspace_ignored(path, workspace_path):
                    continue
                candidates.append(path)
                if len(candidates) >= 200:
                    break

        files: list[dict[str, Any]] = []
        seen: set[str] = set()
        for path in candidates:
            rel = str(path.relative_to(workspace_path))
            if rel in seen:
                continue
            seen.add(rel)
            encoded = self._encode_workspace_file(path)
            if encoded is None:
                omitted.append(rel)
                continue
            encoded["relative_path"] = rel
            files.append(encoded)
        return effective_mode, files[:200], deleted_paths, omitted

    def _workspace_archive(self, workspace_path: Path) -> tuple[str, str, str, int, int]:
        archive_buffer = BytesIO()
        file_count = 0
        with zipfile.ZipFile(archive_buffer, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(workspace_path.rglob("*")):
                if not path.is_file() or self._is_workspace_ignored(path, workspace_path):
                    continue
                rel = str(path.relative_to(workspace_path))
                zf.write(path, arcname=rel)
                file_count += 1
        archive_bytes = archive_buffer.getvalue()
        return (
            f"{workspace_path.name or 'workspace'}.zip",
            "base64",
            b64encode(archive_bytes).decode("ascii"),
            len(archive_bytes),
            file_count,
        )

    def _build_workspace_bundle(self, workspace: str, mode: str = "changed") -> dict[str, Any]:
        workspace_path = Path(workspace).resolve()
        requested_mode = mode if mode in {"changed", "full", "none"} else "changed"
        binding = self._workspace_git_metadata(workspace_path)
        # Auto-escalate to "full" when not inside a git repo — the receiver
        # has no remote to clone, so the share must include everything.
        if requested_mode == "changed" and not binding.get("repo_root"):
            requested_mode = "full"
        if requested_mode == "none":
            overlay = WorkspaceOverlay(
                mode="none",
                binding=WorkspaceBinding.model_validate(binding),
            )
            return overlay.model_dump(mode="json")

        effective_mode, files, deleted_paths, omitted = self._snapshot_workspace_files(workspace_path, requested_mode)
        overlay_kwargs: dict[str, Any] = {
            "mode": effective_mode,
            "binding": WorkspaceBinding.model_validate(binding),
            "deleted_paths": deleted_paths,
            "omitted_paths": omitted,
        }
        if effective_mode == "full":
            archive_name, archive_encoding, archive_content, archive_size, archive_file_count = self._workspace_archive(workspace_path)
            overlay_kwargs.update(
                {
                    "archive_name": archive_name,
                    "archive_encoding": archive_encoding,
                    "archive_content": archive_content,
                    "archive_size": archive_size,
                    "archive_file_count": archive_file_count,
                }
            )
        else:
            overlay_kwargs["files"] = [WorkspaceOverlayFile.model_validate(item) for item in files]
        overlay = WorkspaceOverlay(**overlay_kwargs)
        return overlay.model_dump(mode="json")

    def _workspace_overlay_summary(self, overlay: dict[str, Any] | None) -> dict[str, Any] | None:
        if not overlay:
            return None
        return WorkspaceOverlaySummary(
            mode=overlay.get("mode", "changed"),
            binding=WorkspaceBinding.model_validate(overlay.get("binding", {"cwd": overlay.get("workspace", "")})),
            file_count=overlay.get("archive_file_count") or len(overlay.get("files", [])),
            deleted_count=len(overlay.get("deleted_paths", [])),
            omitted_count=len(overlay.get("omitted_paths", [])),
            captured_at=overlay.get("captured_at"),
        ).model_dump(mode="json")

    def _restore_workspace_bundle(self, bundle: dict[str, Any], output: Path) -> dict[str, Any]:
        restore_root = output / "workspace"
        restore_root.mkdir(parents=True, exist_ok=True)
        files = bundle.get("files", [])
        if bundle.get("archive_content"):
            archive_bytes = b64decode(bundle["archive_content"])
            with zipfile.ZipFile(BytesIO(archive_bytes), "r") as zf:
                zf.extractall(restore_root)
        else:
            for item in files:
                rel = item["relative_path"]
                target = restore_root / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                if item.get("encoding") == "base64":
                    target.write_bytes(b64decode(item["content"]))
                else:
                    target.write_text(item["content"], encoding="utf-8")
                if item.get("executable"):
                    target.chmod(target.stat().st_mode | 0o111)

        manifest_path = output / "workspace.json"
        manifest_path.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
        return {
            "output_file": str(manifest_path),
            "restore_dir": str(restore_root),
            "item_count": len(files),
            "workspace_mode": bundle.get("mode"),
        }

    def _import_root_for_target(self, target: str, workspace_path: Path, source_agent: str) -> Path:
        source_slug = source_agent.replace("/", "-")
        if target == AgentType.HERMES.value:
            return workspace_path / ".anyfs" / "imports" / "hermes" / source_slug
        if target == AgentType.NANOBOT.value:
            return workspace_path / ".anyfs" / "imports" / "nanobot" / source_slug
        if target == AgentType.CLAUDE_CODE.value:
            return workspace_path / ".claude" / "skills" / "anyfs-imports" / source_slug
        if target == AgentType.CODEX_CLI.value:
            return workspace_path / ".codex" / "skills" / "anyfs-imports" / source_slug
        if target == AgentType.GEMINI_CLI.value:
            return workspace_path / ".gemini" / "skills" / "anyfs-imports" / source_slug
        if target == AgentType.OPENCLAW.value:
            return workspace_path / ".openclaw" / "imports" / source_slug
        if target == AgentType.OPENCODE.value:
            return workspace_path / ".opencode" / "skills" / "anyfs-imports" / source_slug
        return workspace_path / ".anyfs" / "imports" / target / source_slug

    def _guidance_path_for_target(self, target: str, workspace_path: Path) -> Path:
        if target == AgentType.CLAUDE_CODE.value:
            return workspace_path / "CLAUDE.md"
        if target in {AgentType.HERMES.value, AgentType.NANOBOT.value}:
            return workspace_path / "AGENTS.md"
        if target in {AgentType.CODEX_CLI.value, AgentType.OPENCLAW.value, AgentType.OPENCODE.value}:
            return workspace_path / "AGENTS.md"
        if target == AgentType.GEMINI_CLI.value:
            return workspace_path / "GEMINI.md"
        return workspace_path / "AGENTS.md"

    def _write_text_if_allowed(self, path: Path, content: str, overwrite: bool) -> str:
        if path.exists() and not overwrite:
            return "skipped"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return "written"

    def _append_import_reference(self, target: str, workspace_path: Path, source_agent: str, import_root: Path) -> str:
        guidance_path = self._guidance_path_for_target(target, workspace_path)
        header = "# Project Instructions\n" if not guidance_path.exists() else ""
        section = (
            f"\n---\n\n## Imported AnyFS Context\n\n"
            f"- Source agent: `{source_agent}`\n"
            f"- Imported context root: `{import_root.relative_to(workspace_path)}`\n"
            f"- Use the imported files for migrated skills, memory, and workspace notes.\n"
        )
        existing = guidance_path.read_text(encoding="utf-8") if guidance_path.exists() else ""
        if str(import_root.relative_to(workspace_path)) in existing:
            return str(guidance_path)
        guidance_path.parent.mkdir(parents=True, exist_ok=True)
        guidance_path.write_text(header + existing + section, encoding="utf-8")
        return str(guidance_path)

    def _transcripts_from_capture(self, capture: dict[str, Any]) -> list[dict[str, Any]]:
        transcripts: list[dict[str, Any]] = []
        for item in capture.get("trajectory", {}).get("process", []):
            canonical = item.get("canonical_transcript")
            if isinstance(canonical, dict) and canonical.get("session") and canonical.get("events") is not None:
                transcripts.append(canonical)
        return transcripts

    def _workspace_default_agent_type(self, workspace: str) -> str | None:
        """Best-effort fallback for commands that still do not accept --type."""
        agents = list_registered_agents(self.global_root)
        if len(agents) == 1:
            return agents[0].get("agent_type")
        agent = workspace_agent(workspace, global_root=self.global_root)
        return agent.get("agent_type") if agent else None

    def _agent_private_key(self, workspace: str, agent_type: str | None = None) -> str | None:
        """Load the agent's Ed25519 private key for the given machine/client."""
        return workspace_agent_private_key(workspace, agent_type, self.global_root)

    def _upload_to_storage_gateway(self, data: bytes, content_type: str = "application/octet-stream") -> dict[str, Any]:
        """Upload raw bytes to the storage gateway and return the response with CID."""
        gateway_url = self._effective_storage_gateway_url()
        if not gateway_url:
            raise ValueError(
                "storage gateway URL not configured, set ANYFS_STORAGE_GATEWAY_URL "
                "or storage_gateway_url in config"
            )
        import base64
        payload = {
            "bytes": base64.b64encode(data).decode("ascii"),
            "content_type": content_type,
        }
        with httpx.Client(base_url=gateway_url, timeout=120.0) as client:
            response = client.post("/blobs/upload", json=payload)
            response.raise_for_status()
            return response.json()

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        auth_kind: str = "agent",
        workspace: str | None = None,
        agent_type: str | None = None,
    ) -> dict[str, Any]:
        headers: dict[str, str] = {}
        if auth_kind == "user":
            token = self._effective_user_token()
            if not token:
                raise ValueError("user auth token not configured, run anyfs auth login")
            headers["Authorization"] = f"Bearer {token}"
        elif auth_kind == "agent":
            # Try Ed25519 signature auth first, fall back to bearer token
            agent = workspace_agent(workspace, agent_type, self.global_root) if workspace else {}
            priv_key = self._agent_private_key(workspace, agent_type) if workspace else None
            did = agent.get("agent_id", "")
            if priv_key and did.startswith("did:key:"):
                headers["Authorization"] = create_auth_header(did, priv_key)
            else:
                token = self._effective_agent_token()
                if not token:
                    raise ValueError("agent not registered, run anyfs register")
                headers["Authorization"] = f"Bearer {token}"
        elif auth_kind != "public":
            raise ValueError(f"unsupported auth kind: {auth_kind}")

        if self.api_client is not None:
            response = self.api_client.request(method, path, json=payload, headers=headers)
            response.raise_for_status()
            return response.json()

        base_url = self._effective_api_base_url(workspace=workspace, agent_type=agent_type)
        if not base_url:
            raise ValueError("API base URL not configured")
        with httpx.Client(base_url=base_url, timeout=30.0) as client:
            response = client.request(method, path, json=payload, headers=headers)
            response.raise_for_status()
            return response.json()

    def _resolve_snapshot_id(self, workspace: str, snapshot: str) -> str:
        if snapshot == "latest":
            snapshot_id = latest_snapshot_id(workspace)
            if not snapshot_id:
                raise ValueError("no snapshot available")
            return snapshot_id
        return snapshot

    def _get_snapshot_record(self, workspace: str, snapshot_id: str) -> dict[str, Any]:
        snapshot = next((item for item in list_snapshots(workspace) if item["snapshot_id"] == snapshot_id), None)
        if not snapshot:
            raise ValueError(f"snapshot not found: {snapshot_id}")
        return snapshot

    def _get_package_record(self, workspace: str, package_id: str) -> dict[str, Any]:
        package = next((item for item in list_packages(workspace) if item["package_id"] == package_id), None)
        if package:
            return package
        # Not in local state — try the public registry endpoint so that
        # `buy`/`fork` can consume a package_id discovered in the Hub without
        # requiring it to be pre-cached locally.
        if self.api_client is not None or self._effective_api_base_url(workspace=workspace):
            try:
                remote = self._request("GET", f"/packages/{package_id}", auth_kind="public", workspace=workspace)
            except Exception as error:
                raise ValueError(f"package not found: {package_id}") from error
            if remote:
                append_package(workspace, remote)
                return remote
        raise ValueError(f"package not found: {package_id}")

    def _normalize_namespaces(self, namespaces: list[str] | None, available: list[str]) -> list[str]:
        if not namespaces:
            return available
        unknown = [item for item in namespaces if item not in available]
        if unknown:
            raise ValueError(f"unknown namespaces requested: {', '.join(unknown)}")
        return namespaces

    def _visibility_policy_path(self, workspace: str, explicit_path: str | None = None) -> Path:
        if explicit_path:
            return Path(explicit_path).expanduser().resolve()
        return default_workspace_root(workspace) / "visibility.json"

    def _default_publish_visibility_mode(self) -> str:
        return PublishVisibilityMode.ARTIFACTS_PUBLIC.value

    def _resolve_publish_visibility_mode(
        self,
        workspace: str,
        *,
        policy_path: str | None = None,
        visibility_mode: str | None = None,
    ) -> dict[str, Any]:
        effective = self._default_publish_visibility_mode()
        source = "default"

        path = self._visibility_policy_path(workspace, policy_path)
        if path.exists():
            loaded = json.loads(path.read_text(encoding="utf-8"))
            publish = loaded.get("publish", {})
            if publish:
                mode = publish.get("mode")
                if mode:
                    effective = mode
                else:
                    namespaces = publish.get("namespaces", {})
                    default_visibility = publish.get("default", Visibility.PRIVATE.value)
                    if namespaces == {"artifacts": Visibility.PRIVATE.value} and default_visibility == Visibility.PRIVATE.value:
                        effective = PublishVisibilityMode.ALL_PRIVATE.value
                    elif namespaces == {"artifacts": Visibility.PUBLIC.value} and default_visibility == Visibility.PRIVATE.value:
                        effective = PublishVisibilityMode.ARTIFACTS_PUBLIC.value
                    else:
                        raise ValueError(
                            "publish visibility policy must set publish.mode to one of: "
                            "all-public, artifacts-public, all-private"
                        )
                source = "file"

        if visibility_mode:
            effective = visibility_mode
            source = "cli" if source == "default" else "merged"

        if effective not in {mode.value for mode in PublishVisibilityMode}:
            raise ValueError(
                "publish visibility mode must be one of: all-public, artifacts-public, all-private"
            )

        visibility = {
            "mode": effective,
            "code_ref": Visibility.PUBLIC.value,
            "artifacts": Visibility.PUBLIC.value if effective != PublishVisibilityMode.ALL_PRIVATE.value else Visibility.PRIVATE.value,
            "trajectory": Visibility.PUBLIC.value if effective == PublishVisibilityMode.ALL_PUBLIC.value else Visibility.PRIVATE.value,
            "workspace_overlay": Visibility.PUBLIC.value if effective == PublishVisibilityMode.ALL_PUBLIC.value else Visibility.PRIVATE.value,
        }

        return {
            "policy_source": source,
            "policy_path": str(path) if path.exists() else None,
            "visibility_mode": effective,
            "effective_visibility": visibility,
            "public_sections": sorted(name for name, vis in visibility.items() if name != "mode" and vis == Visibility.PUBLIC.value),
            "private_sections": sorted(name for name, vis in visibility.items() if name != "mode" and vis == Visibility.PRIVATE.value),
        }

    def _local_agent(self, workspace: str, agent_type: str | None = None) -> dict[str, Any]:
        agent = workspace_agent(workspace, agent_type, self.global_root)
        if not agent:
            if agent_type:
                raise ValueError(f"no AnyFS agent is registered for {agent_type} on this machine")
            raise ValueError("no AnyFS agent is registered on this machine")
        return agent

    def _remote_agent_state(self, workspace: str, agent_type: str | None = None) -> dict[str, Any]:
        return read_agent_remote_state(workspace, agent_type, self.global_root)

    def _agent_lite(self, workspace: str, agent_type: str | None = None) -> AgentRecordLite:
        agent = self._local_agent(workspace, agent_type)
        remote_state = self._remote_agent_state(workspace, agent.get("agent_type"))
        return AgentRecordLite(
            agent_id=agent["agent_id"],
            owner_user_id=remote_state.get("owner_user_id"),
            agent_type=agent["agent_type"],
            display_name=agent["display_name"],
            created_at=agent["created_at"],
            last_seen_at=utc_now_iso(),
            auth_mode=remote_state.get("auth_mode", AgentAuthMode.STANDALONE.value),
            status=remote_state.get("status", AgentBindingStatus.UNCLAIMED.value),
        )

    def _snapshot_lite(self, workspace: str, snapshot_id: str, origin: str, namespaces: list[str], agent_type: str | None = None) -> SnapshotRecordLite:
        snapshot = self._get_snapshot_record(workspace, snapshot_id)
        remote_state = self._remote_agent_state(workspace, agent_type)
        return SnapshotRecordLite(
            snapshot_id=snapshot_id,
            agent_id=snapshot["agent_id"],
            parent_snapshot_id=snapshot.get("parent_snapshot_id"),
            manifest_cid=snapshot["manifest_cid"],
            payload_cid=snapshot["payload_cid"],
            namespace_summary=namespaces,
            encrypted=snapshot["encrypted"],
            created_at=snapshot["created_at"],
            origin=origin,
            owner_user_id=remote_state.get("owner_user_id"),
        )

    def _sync_remote_agent_state(self, workspace: str, payload: dict[str, Any], agent_type: str | None = None) -> None:
        state = self._remote_agent_state(workspace, agent_type)
        state.update(payload)
        write_agent_remote_state(workspace, state, agent_type, self.global_root)

    def init(self) -> dict[str, Any]:
        state = initialize_global_state(self.global_root)
        ensure_root_key(self.global_root, state["identity"])
        export_recovery_bundle(self.global_root, state["identity"])
        return state

    def doctor(self, workspace: str | None = None) -> dict[str, Any]:
        return doctor(self.global_root, workspace).model_dump(mode="json")

    def auth_register(self, email: str, password: str) -> dict[str, Any]:
        self.init()
        result = self._request("POST", "/auth/register", {"email": email, "password": password}, auth_kind="public")
        config = self._config()
        config["auth_email"] = email
        config["auth_token"] = result["token"]
        write_config(self.global_root, config)
        return AuthStatus(email=email, token=result["token"]).model_dump(mode="json")

    def auth_login(self, email: str, password: str) -> dict[str, Any]:
        self.init()
        result = self._request("POST", "/auth/login", {"email": email, "password": password}, auth_kind="public")
        config = self._config()
        config["auth_email"] = email
        config["auth_token"] = result["token"]
        write_config(self.global_root, config)
        return AuthStatus(email=email, token=result["token"]).model_dump(mode="json")

    def register_agent(self, agent_type: str, workspace: str, display_name: str | None = None) -> dict[str, Any]:
        self.init()
        agent = register_agent(self.global_root, workspace, agent_type, display_name)
        public_agent = {key: value for key, value in agent.items() if key in AgentRecord.model_fields}
        return AgentRecord(**public_agent).model_dump(mode="json")

    def agent_rename(self, workspace: str, agent_type: str, display_name: str) -> dict[str, Any]:
        self.init()
        agent = rename_agent(self.global_root, workspace, agent_type, display_name)
        public_agent = {key: value for key, value in agent.items() if key in AgentRecord.model_fields}
        remote_updated = False
        try:
            remote = self._request(
                "PATCH",
                "/agent-auth/me",
                AgentRenameRequest(display_name=display_name).model_dump(mode="json"),
                auth_kind="agent",
                workspace=workspace,
                agent_type=agent_type,
            )
            remote_updated = True
            if isinstance(remote, dict):
                public_agent.update({k: v for k, v in remote.items() if k in AgentRecord.model_fields or k in AgentRecordLite.model_fields})
        except Exception:
            remote_updated = False
        public_agent["remote_updated"] = remote_updated
        return public_agent

    def agent_create_remote(self, workspace: str, agent_type: str | None = None) -> dict[str, Any]:
        agent = self._local_agent(workspace, agent_type)
        # Capture the API URL we are actually registering against so we can pin
        # the workspace to it for subsequent commands. The registration request
        # itself must ignore any workspace-recorded URL (which does not exist
        # yet on first registration).
        registration_api_base_url = self.api_base_url or os.getenv("ANYFS_API_BASE_URL") or self._config().get("default_api_base_url")
        result = self._request(
            "POST",
            "/agent-auth/register",
            AgentAuthRegisterRequest(
                agent_id=agent["agent_id"],
                agent_type=agent["agent_type"],
                display_name=agent["display_name"],
                public_key=agent.get("public_key"),
            ).model_dump(mode="json"),
            auth_kind="public",
        )
        # No token needed for Ed25519 agents — auth is via signature
        if result.get("token"):
            config = self._config()
            config["agent_token"] = result["token"]
            config["agent_token_agent_id"] = result["agent"]["agent_id"]
            write_config(self.global_root, config)
        self._sync_remote_agent_state(
            workspace,
            {
                "registered": True,
                "remote_registered_at": utc_now_iso(),
                "owner_user_id": result["agent"].get("owner_user_id"),
                "auth_mode": result["agent"]["auth_mode"],
                "status": result["agent"]["status"],
                # Pin the workspace to the API it was registered against.
                **({"api_base_url": registration_api_base_url} if registration_api_base_url else {}),
            },
            agent.get("agent_type"),
        )
        return result

    def agent_status(self, workspace: str, agent_type: str | None = None) -> dict[str, Any]:
        local_agent = self._local_agent(workspace, agent_type)
        resolved_agent_type = local_agent.get("agent_type")
        remote_state = self._remote_agent_state(workspace, resolved_agent_type)
        try:
            remote = self._request("GET", "/agent-auth/me", auth_kind="agent", workspace=workspace, agent_type=resolved_agent_type)
            remote_agent = dict(remote.get("agent", {}))
            if remote.get("binding"):
                remote_agent["binding_id"] = remote["binding"].get("binding_id")
            self._sync_remote_agent_state(
                workspace,
                {
                    "registered": True,
                    "owner_user_id": remote_agent.get("owner_user_id"),
                    "auth_mode": remote_agent["auth_mode"],
                    "status": remote_agent["status"],
                    "binding_id": remote.get("binding", {}).get("binding_id") if remote.get("binding") else None,
                },
                resolved_agent_type,
            )
            return {"local_agent": local_agent, "remote": remote_agent, "binding": remote.get("binding")}
        except Exception:
            pass
        return {"local_agent": local_agent, "remote": remote_state}

    def agent_bind(self, workspace: str, email: str, password: str, agent_type: str | None = None) -> dict[str, Any]:
        local_agent = self._local_agent(workspace, agent_type)
        result = self._request(
            "POST",
            "/agent-bindings/bind",
            {"email": email, "password": password},
            auth_kind="agent",
            workspace=workspace,
            agent_type=local_agent.get("agent_type"),
        )
        self._sync_remote_agent_state(
            workspace,
            {
                "registered": True,
                "owner_user_id": result["agent"].get("owner_user_id"),
                "auth_mode": result["agent"]["auth_mode"],
                "status": result["agent"]["status"],
                "binding_id": result["binding"]["binding_id"],
            },
            local_agent.get("agent_type"),
        )
        return result

    def _require_bound_agent_for_publish(self, workspace: str, agent_type: str | None = None) -> None:
        status = self.agent_status(workspace, agent_type)
        local_agent = status.get("local_agent") or {}
        remote = status.get("remote") or {}
        if (
            remote.get("auth_mode") == AgentAuthMode.BOUND.value
            and remote.get("status") == AgentBindingStatus.CLAIMED.value
            and remote.get("owner_user_id")
        ):
            return
        resolved_type = local_agent.get("agent_type") or agent_type or "<agent-type>"
        raise ValueError(
            "publish requires a registered user account bound to this agent. "
            "First run `anyfs auth register --email <email> --password <password>` or "
            "`anyfs auth login --email <email> --password <password>`, then "
            f"`anyfs agent bind --type {resolved_type} --email <email> --password <password> -w {workspace}`."
        )

    def _get_adapter(self, agent_type: str, process_scope: str = "current"):
        if agent_type == AgentType.HERMES.value:
            return HermesAdapter(process_scope=process_scope)
        if agent_type == AgentType.NANOBOT.value:
            return NanobotAdapter(process_scope=process_scope)
        if agent_type == AgentType.OPENCLAW.value:
            return OpenClawAdapter(process_scope=process_scope)
        if agent_type == AgentType.OPENCODE.value:
            return OpenCodeAdapter(process_scope=process_scope)
        if agent_type == AgentType.CLAUDE_CODE.value:
            return ClaudeCodeAdapter(process_scope=process_scope)
        if agent_type == AgentType.CODEX_CLI.value:
            return CodexCLIAdapter(process_scope=process_scope)
        if agent_type == AgentType.GEMINI_CLI.value:
            return GeminiCLIAdapter(process_scope=process_scope)
        raise ValueError(f"unsupported agent type: {agent_type}")

    def capture(
        self,
        agent_type: str,
        workspace: str,
        process_scope: str = "all",
        workspace_mode: str = "changed",
        client_scope: str = "project",
        artifact_paths: list[str] | None = None,
    ) -> dict[str, Any]:
        scope = process_scope if process_scope in {"current", "all"} else "all"
        resolved_client_scope = client_scope if client_scope in {"project", "single"} else "project"
        normalized_bundles: list[dict[str, list[dict[str, Any]]]] = []
        captured_agent_types: list[str] = []
        warnings: list[str] = []
        for capture_agent_type in self._capture_agent_types(agent_type, resolved_client_scope):
            adapter = self._get_adapter(capture_agent_type, process_scope=scope)
            raw = adapter.extract(workspace)
            normalized = adapter.normalize(raw)
            if normalized:
                normalized_bundles.append(normalized)
                captured_agent_types.append(capture_agent_type)
        normalized = self._merge_normalized_payloads(normalized_bundles)
        normalized = self._filter_skills_by_process_usage(normalized)
        normalized = self._dedupe_skills_by_name(normalized, agent_type)
        normalized.pop(Namespace.ARTIFACTS.value, None)
        agent = workspace_agent(workspace, agent_type, self.global_root)
        workspace_path = Path(workspace).resolve()
        binding = self._workspace_git_metadata(workspace_path)
        code_ref = self._code_ref_from_binding(workspace_path, binding)
        trajectory, _, components = self._trajectory_from_payloads(normalized)
        artifacts = self._explicit_artifacts(workspace, artifact_paths)
        overlay = self._build_workspace_bundle(workspace, workspace_mode)
        bundle = CaptureResult(
            agent_id=agent.get("agent_id", f"agt_{uuid.uuid4().hex[:12]}"),
            agent_type=agent_type,
            workspace=str(workspace_path),
            client_scope=resolved_client_scope,
            process_scope=scope,
            captured_agent_types=captured_agent_types,
            code_ref=code_ref,
            workspace_overlay=overlay,
            trajectory=trajectory,
            artifacts=artifacts,
            trajectory_components=components,
            captured_namespaces=[*components, *([Namespace.ARTIFACTS.value] if artifacts else []), *([Namespace.WORKSPACE_OVERLAY.value] if overlay and overlay.get("mode") != "none" else [])],
            payloads=normalized,
            warnings=warnings if normalized else [f"no files discovered for {agent_type}"],
        )
        record_capture(workspace, bundle.model_dump(mode="json"))
        return bundle.model_dump(mode="json")

    def snapshot_create(self, workspace: str, artifacts_public: bool = True) -> dict[str, Any]:
        capture = latest_capture(workspace)
        if not capture:
            raise ValueError("no capture state found for workspace")
        capture_agent_type = capture.get("agent_type")
        agent = workspace_agent(workspace, capture_agent_type, self.global_root)
        snapshot_id = f"snp_{uuid.uuid4().hex[:12]}"
        payload_root = default_workspace_root(workspace) / "exports" / "snapshots" / snapshot_id
        public_root = payload_root / "artifacts" / "public"
        private_root = payload_root / "payloads" / "private"
        public_root.mkdir(parents=True, exist_ok=True)
        private_root.mkdir(parents=True, exist_ok=True)

        root_key = self._root_key()
        trajectory = capture.get("trajectory", {})
        artifacts = capture.get("artifacts", [])
        workspace_overlay = capture.get("workspace_overlay")

        for namespace, items in trajectory.items():
            envelope = encrypt_json_payload(root_key, items, namespace)
            envelope_path = private_root / f"{namespace}.json"
            envelope_path.write_text(json.dumps(envelope, indent=2), encoding="utf-8")

        if workspace_overlay and workspace_overlay.get("mode") != "none":
            overlay_envelope = encrypt_json_payload(root_key, workspace_overlay, Namespace.WORKSPACE_OVERLAY.value)
            overlay_path = private_root / f"{Namespace.WORKSPACE_OVERLAY.value}.json"
            overlay_path.write_text(json.dumps(overlay_envelope, indent=2), encoding="utf-8")

        if artifacts:
            if artifacts_public:
                artifact_path = public_root / "artifacts.json"
                artifact_path.write_text(json.dumps(artifacts, indent=2), encoding="utf-8")
            else:
                envelope = encrypt_json_payload(root_key, artifacts, Namespace.ARTIFACTS.value)
                envelope_path = private_root / "artifacts.json"
                envelope_path.write_text(json.dumps(envelope, indent=2), encoding="utf-8")

        trajectory_summary = self._trajectory_summary(trajectory)
        artifacts_summary = self._artifacts_summary(
            artifacts,
            visibility=Visibility.PUBLIC.value if artifacts_public else Visibility.PRIVATE.value,
        )
        overlay_summary = self._workspace_overlay_summary(workspace_overlay)

        manifest = SnapshotManifest(
            snapshot_id=snapshot_id,
            agent_id=agent.get("agent_id", "unknown"),
            workspace=str(Path(workspace).resolve()),
            code_ref=capture.get("code_ref", CodeRef().model_dump(mode="json")),
            workspace_overlay=overlay_summary,
            trajectory=trajectory_summary,
            artifacts=artifacts_summary,
            restore_metadata={"restore_root": str(default_workspace_root(workspace) / "exports" / "restores" / snapshot_id)},
        )
        manifest_path = write_manifest(workspace, snapshot_id, manifest.model_dump(mode="json"))
        manifest_cid = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
        payload_cid = hashlib.sha256(
            json.dumps(
                {
                    "trajectory": trajectory_summary,
                    "artifacts": artifacts_summary,
                    "workspace_overlay": overlay_summary,
                },
                sort_keys=True,
                default=str,
            ).encode("utf-8")
        ).hexdigest()
        snapshot_namespaces = [Namespace(component) for component in capture.get("trajectory_components", [])]
        if artifacts:
            snapshot_namespaces.append(Namespace.ARTIFACTS)
        if workspace_overlay and workspace_overlay.get("mode") != "none":
            snapshot_namespaces.append(Namespace.WORKSPACE_OVERLAY)
        snapshot = SnapshotRecord(
            snapshot_id=snapshot_id,
            agent_id=agent.get("agent_id", "unknown"),
            namespace=snapshot_namespaces,
            parent_snapshot_id=latest_snapshot_id(workspace),
            manifest_cid=manifest_cid,
            payload_cid=payload_cid,
            encrypted=True,
        )
        append_snapshot(workspace, snapshot.model_dump(mode="json"))
        return snapshot.model_dump(mode="json")

    def snapshot_list(self, workspace: str) -> list[dict[str, Any]]:
        return list_snapshots(workspace)

    def restore(self, workspace: str, snapshot: str = "latest") -> dict[str, Any]:
        snapshot_id = self._resolve_snapshot_id(workspace, snapshot)
        export_root = default_workspace_root(workspace) / "exports" / "snapshots" / snapshot_id
        restore_root = default_workspace_root(workspace) / "exports" / "restores" / snapshot_id
        restore_root.mkdir(parents=True, exist_ok=True)
        root_key = self._root_key()
        private_root = export_root / "payloads" / "private"
        restored: dict[str, Any] = {}
        for envelope_path in private_root.glob("*.json"):
            envelope = json.loads(envelope_path.read_text(encoding="utf-8"))
            namespace = envelope["namespace"]
            restored_payload = decrypt_json_payload(root_key, envelope)
            if namespace == Namespace.WORKSPACE_OVERLAY.value:
                workspace_result = self._restore_workspace_bundle(restored_payload, restore_root)
                restored["workspace_overlay"] = workspace_result["output_file"]
                restored["workspace_restore_dir"] = workspace_result["restore_dir"]
                continue
            target_path = restore_root / f"{namespace}.json"
            target_path.write_text(json.dumps(restored_payload, indent=2), encoding="utf-8")
            restored[namespace] = str(target_path)
        artifact_path = export_root / "artifacts" / "public" / "artifacts.json"
        if artifact_path.exists():
            shutil.copy2(artifact_path, restore_root / artifact_path.name)
            restored["artifacts"] = str(restore_root / artifact_path.name)
        write_json(restore_root / "restore-metadata.json", {"snapshot_id": snapshot_id, "restored_at": utc_now_iso(), "files": restored})
        return {"snapshot_id": snapshot_id, "restore_dir": str(restore_root), "files": restored}

    def backup_create(self, workspace: str, snapshot: str = "latest", namespaces: list[str] | None = None) -> dict[str, Any]:
        snapshot_id = self._resolve_snapshot_id(workspace, snapshot)
        snapshot_record = self._get_snapshot_record(workspace, snapshot_id)
        available = snapshot_record["namespace"]
        selected = self._normalize_namespaces(namespaces, available)
        local_agent = workspace_agent_by_id(workspace, snapshot_record["agent_id"], self.global_root)
        if not local_agent:
            raise ValueError("agent for snapshot is not registered locally")
        agent_type = local_agent.get("agent_type")
        agent = self._agent_lite(workspace, agent_type)
        snapshot_lite = self._snapshot_lite(workspace, snapshot_id, "backup", selected, agent_type)

        # Upload encrypted payloads to the storage gateway if configured.
        storage_gateway_url = self._effective_storage_gateway_url()
        payload_cids: dict[str, str] = {}
        if storage_gateway_url:
            private_root = default_workspace_root(workspace) / "exports" / "snapshots" / snapshot_id / "payloads" / "private"
            if private_root.exists():
                for envelope_path in private_root.glob("*.json"):
                    ns = envelope_path.stem
                    if ns in selected:
                        upload_result = self._upload_to_storage_gateway(
                            envelope_path.read_bytes(), "application/json"
                        )
                        payload_cids[ns] = upload_result["cid"]

        backup = BackupRecord(
            backup_id=f"bkp_{uuid.uuid4().hex[:12]}",
            agent_id=agent.agent_id,
            snapshot_id=snapshot_id,
            namespaces=selected,
            manifest_cid=snapshot_lite.manifest_cid,
            payload_cid=snapshot_lite.payload_cid,
            created_by_agent_id=agent.agent_id,
            owner_user_id=agent.owner_user_id,
            restore_hint=f"snapshot:{snapshot_id}",
        )
        self._request("POST", "/agents", agent.model_dump(mode="json"), auth_kind="agent", workspace=workspace, agent_type=agent_type)
        self._request("POST", "/snapshots", snapshot_lite.model_dump(mode="json"), auth_kind="agent", workspace=workspace, agent_type=agent_type)
        result = self._request("POST", "/backups", BackupCreateRequest(agent=agent, snapshot=snapshot_lite, backup=backup).model_dump(mode="json"), auth_kind="agent", workspace=workspace, agent_type=agent_type)
        if payload_cids:
            result["payload_cids"] = payload_cids
        append_backup(workspace, result)
        return result

    def list_backups(self, workspace: str) -> list[dict[str, Any]]:
        return list_backups(workspace)

    def share_memory(self, workspace: str, snapshot: str = "latest", namespaces: list[str] | None = None) -> dict[str, Any]:
        snapshot_id = self._resolve_snapshot_id(workspace, snapshot)
        snapshot_record = self._get_snapshot_record(workspace, snapshot_id)
        available = snapshot_record["namespace"]
        selected = self._normalize_namespaces(namespaces or ["memory"], available)
        local_agent = workspace_agent_by_id(workspace, snapshot_record["agent_id"], self.global_root)
        if not local_agent:
            raise ValueError("agent for snapshot is not registered locally")
        agent_type = local_agent.get("agent_type")
        agent = self._agent_lite(workspace, agent_type)
        snapshot_lite = self._snapshot_lite(workspace, snapshot_id, "link", selected, agent_type)
        link = LinkRecord(
            link_id=f"lnk_{uuid.uuid4().hex[:12]}",
            agent_id=agent.agent_id,
            snapshot_id=snapshot_id,
            namespaces=selected,
            created_by_agent_id=agent.agent_id,
            owner_user_id=agent.owner_user_id,
            url="pending",
        )
        self._request("POST", "/agents", agent.model_dump(mode="json"), auth_kind="agent", workspace=workspace, agent_type=agent_type)
        self._request("POST", "/snapshots", snapshot_lite.model_dump(mode="json"), auth_kind="agent", workspace=workspace, agent_type=agent_type)
        result = self._request("POST", "/links", LinkCreateRequest(agent=agent, snapshot=snapshot_lite, link=link).model_dump(mode="json"), auth_kind="agent", workspace=workspace, agent_type=agent_type)
        append_link(workspace, result)
        return result

    def list_links(self, workspace: str) -> list[dict[str, Any]]:
        return list_links(workspace)

    def share_namespace(
        self,
        workspace: str,
        namespace: str,
        share_password: str,
        snapshot: str = "latest",
        message: str | None = None,
        workspace_mode: str = "changed",
    ) -> dict[str, Any]:
        """Share a single namespace with a password. The recipient can decrypt
        just this namespace without needing your root key.

        Returns the share file path and the CID if uploaded to the storage gateway.
        """
        root_key = self._root_key()
        requested_namespace = namespace
        effective_namespace = Namespace.WORKSPACE_OVERLAY.value if namespace == "workspace" else namespace

        snapshot_id = self._resolve_snapshot_id(workspace, snapshot)
        private_root = default_workspace_root(workspace) / "exports" / "snapshots" / snapshot_id / "payloads" / "private"
        envelope_path = private_root / f"{effective_namespace}.json"
        if not envelope_path.exists():
            if effective_namespace == Namespace.WORKSPACE_OVERLAY.value and workspace_mode != "none":
                bundle = self._build_workspace_bundle(workspace, workspace_mode)
                envelope = encrypt_json_payload(root_key, bundle, Namespace.WORKSPACE_OVERLAY.value)
                share_id = f"wsp_{uuid.uuid4().hex[:12]}"
            else:
                raise ValueError(f"namespace '{requested_namespace}' not found in snapshot {snapshot_id}")
        else:
            envelope = json.loads(envelope_path.read_text(encoding="utf-8"))
            share_id = snapshot_id
        share_envelope = rewrap_dek_for_share(root_key, envelope, share_password)
        if requested_namespace != effective_namespace:
            share_envelope["display_namespace"] = requested_namespace

        if not message:
            raise ValueError("share message is required")
        share_envelope["message"] = message

        # Write share file locally
        share_dir = default_workspace_root(workspace) / "exports" / "shares"
        share_dir.mkdir(parents=True, exist_ok=True)
        share_file = share_dir / f"{share_id}.{namespace}.share.json"
        share_file.write_text(json.dumps(share_envelope, indent=2), encoding="utf-8")

        result: dict[str, Any] = {
            "snapshot_id": share_id,
            "namespace": namespace,
            "share_file": str(share_file),
            "message": message,
        }

        # Upload to the storage gateway if configured.
        storage_gateway_url = self._effective_storage_gateway_url()
        if storage_gateway_url:
            upload_result = self._upload_to_storage_gateway(
                share_file.read_bytes(), "application/json"
            )
            result["cid"] = upload_result["cid"]
            result["gateway_url"] = upload_result.get("gateway_url")

        return result

    def open_shared(self, share_path: str, share_password: str, output_dir: str | None = None) -> dict[str, Any]:
        """Decrypt a shared file using only the share password. No root key needed."""
        is_remote = share_path.startswith(("http://", "https://"))
        envelope = self._load_share_envelope(share_path)
        if envelope.get("share_mode") != "password":
            raise ValueError("this file was not shared with a password")

        decrypted = decrypt_shared_payload(share_password, envelope)

        if output_dir:
            output = Path(output_dir)
        elif is_remote:
            output = Path(tempfile.mkdtemp(prefix="anyfs-share-"))
        else:
            output = Path(share_path).expanduser().resolve().parent
        output.mkdir(parents=True, exist_ok=True)
        display_namespace = envelope.get("display_namespace") or envelope["namespace"]
        if display_namespace == "workspace" and isinstance(decrypted, dict):
            result = self._restore_workspace_bundle(decrypted, output)
        else:
            result_path = output / f"{display_namespace}.json"
            result_path.write_text(json.dumps(decrypted, indent=2), encoding="utf-8")
            result = {
                "output_file": str(result_path),
                "item_count": len(decrypted) if isinstance(decrypted, list) else 1,
            }

        return {
            "namespace": display_namespace,
            "share_source": share_path,
            **result,
            **({"message": envelope["message"]} if envelope.get("message") else {}),
        }

    def _load_share_envelope(self, share_path: str) -> dict[str, Any]:
        if share_path.startswith(("http://", "https://")):
            with httpx.Client(timeout=120.0, follow_redirects=True) as client:
                response = client.get(share_path)
                response.raise_for_status()
                return response.json()

        share_file = Path(share_path).expanduser().resolve()
        if not share_file.exists():
            raise ValueError(f"share file not found: {share_file}")
        return json.loads(share_file.read_text(encoding="utf-8"))

    def pack(
        self,
        workspace: str,
        snapshot_id: str,
        output_path: str | None = None,
        *,
        message: str | None = None,
        visibility_policy_path: str | None = None,
        visibility_mode: str | None = None,
    ) -> dict[str, Any]:
        manifest = read_manifest(workspace, snapshot_id)
        if not manifest:
            raise ValueError(f"snapshot manifest not found: {snapshot_id}")
        snapshot_record = self._get_snapshot_record(workspace, snapshot_id)
        local_agent = workspace_agent_by_id(workspace, snapshot_record["agent_id"], self.global_root)
        if not local_agent:
            raise ValueError("agent for snapshot is not registered locally")
        agent = self._agent_lite(workspace, local_agent.get("agent_type"))
        remote_state = self._remote_agent_state(workspace, local_agent.get("agent_type"))
        archive_path = Path(output_path or (default_workspace_root(workspace) / "exports" / f"{snapshot_id}.afpkg")).resolve()
        snapshot_root = default_workspace_root(workspace) / "exports" / "snapshots" / snapshot_id
        visibility = self._resolve_publish_visibility_mode(
            workspace,
            policy_path=visibility_policy_path,
            visibility_mode=visibility_mode,
        )
        resolved_visibility_mode = visibility["visibility_mode"]
        artifacts_public = visibility["effective_visibility"]["artifacts"] == Visibility.PUBLIC.value
        trajectory_public = visibility["effective_visibility"]["trajectory"] == Visibility.PUBLIC.value
        overlay_public = visibility["effective_visibility"]["workspace_overlay"] == Visibility.PUBLIC.value

        public_entries: dict[str, bytes] = {}
        public_dir = snapshot_root / "artifacts" / "public"
        if public_dir.exists():
            for path in public_dir.rglob("*"):
                if path.is_file():
                    public_entries[f"artifacts/{path.relative_to(public_dir)}"] = path.read_bytes()

        private_entries: dict[str, dict[str, Any]] = {}
        private_dir = snapshot_root / "payloads" / "private"
        if private_dir.exists():
            for path in private_dir.rglob("*.json"):
                rel_name = str(path.relative_to(private_dir))
                if rel_name == f"{Namespace.WORKSPACE_OVERLAY.value}.json":
                    private_entries["workspace_overlay.json"] = json.loads(path.read_text(encoding="utf-8"))
                else:
                    private_entries[f"trajectory/{rel_name}"] = json.loads(path.read_text(encoding="utf-8"))

        root_key = self._root_key()
        trajectory_private_keys = [name for name in private_entries if name.startswith("trajectory/")]
        artifacts_private_key = "trajectory/artifacts.json"
        for key in list(trajectory_private_keys):
            namespace = Path(key).stem
            if namespace == Namespace.ARTIFACTS.value:
                continue
            envelope = private_entries.get(key)
            if envelope is None:
                continue
            payload = decrypt_json_payload(root_key, envelope)
            filtered_payload = self._filter_publishable_trajectory_records(namespace, payload if isinstance(payload, list) else [])
            if not filtered_payload:
                private_entries.pop(key, None)
                trajectory_private_keys.remove(key)
                continue
            private_entries[key] = encrypt_json_payload(root_key, filtered_payload, namespace)
        publishable_trajectory_summary = self._trajectory_summary(
            {
                Path(key).stem: decrypt_json_payload(root_key, private_entries[key])
                for key in trajectory_private_keys
                if key in private_entries and Path(key).stem != Namespace.ARTIFACTS.value
            }
        )
        if trajectory_public:
            for key in trajectory_private_keys:
                envelope = private_entries.pop(key, None)
                if envelope is None:
                    continue
                payload = decrypt_json_payload(root_key, envelope)
                public_key = "artifacts/artifacts.json" if key == artifacts_private_key else key
                public_entries[public_key] = json.dumps(payload, indent=2).encode("utf-8")
        elif artifacts_public and artifacts_private_key in private_entries:
            artifacts_envelope = private_entries.pop(artifacts_private_key)
            artifacts_payload = decrypt_json_payload(root_key, artifacts_envelope)
            public_entries["artifacts/artifacts.json"] = json.dumps(artifacts_payload, indent=2).encode("utf-8")
        elif not artifacts_public and "artifacts/artifacts.json" in public_entries:
            artifacts_payload = json.loads(public_entries.pop("artifacts/artifacts.json").decode("utf-8"))
            private_entries[artifacts_private_key] = encrypt_json_payload(root_key, artifacts_payload, Namespace.ARTIFACTS.value)

        overlay_private_key = "workspace_overlay.json"
        if overlay_public and overlay_private_key in private_entries:
            overlay_envelope = private_entries.pop(overlay_private_key)
            overlay_payload = decrypt_json_payload(root_key, overlay_envelope)
            public_entries[overlay_private_key] = json.dumps(overlay_payload, indent=2).encode("utf-8")

        package_manifest = PackageManifest(
            name=f"{agent.display_name or 'anyfs-agent'}-{snapshot_id}",
            description=message or f"AFPKG generated from snapshot {snapshot_id}",
            message=message,
            agent_type=agent.agent_type or AgentType.OPENCLAW.value,
            version="0.1.0.dev1",
            tags=["anyfs", agent.agent_type or "unknown"],
            visibility_mode=resolved_visibility_mode,
            code_ref=manifest.get("code_ref", CodeRef().model_dump(mode="json")),
            workspace_overlay=manifest.get("workspace_overlay"),
            trajectory=publishable_trajectory_summary,
            artifacts={
                **manifest.get("artifacts", self._artifacts_summary([], Visibility.PRIVATE.value)),
                "visibility": Visibility.PUBLIC.value if artifacts_public else Visibility.PRIVATE.value,
                "index": manifest.get("artifacts", {}).get("index", []) if artifacts_public else [],
            },
        )
        repo_owner, project_name = self._package_identity(
            Path(workspace).resolve(),
            package_manifest.code_ref.model_dump(mode="json"),
            package_manifest.workspace_overlay.model_dump(mode="json").get("binding", {})
            if package_manifest.workspace_overlay
            else manifest.get("workspace_overlay", {}).get("binding", {}),
        )
        package_record = PackageRecord(
            package_id=f"pkg_{uuid.uuid4().hex[:12]}",
            source_snapshot_id=snapshot_id,
            manifest_cid=hashlib.sha256(json.dumps(package_manifest.model_dump(mode="json"), sort_keys=True).encode("utf-8")).hexdigest(),
            message=message,
            visibility_mode=resolved_visibility_mode,
            code_ref=package_manifest.code_ref,
            workspace_overlay=package_manifest.workspace_overlay,
            trajectory=package_manifest.trajectory,
            artifacts=package_manifest.artifacts,
            fork_policy="free",
            created_by_agent_id=agent.agent_id,
            owner_user_id=remote_state.get("owner_user_id"),
            repo_owner=repo_owner,
            project_name=project_name,
        )
        build_afpkg(
            archive_path,
            package_manifest.model_dump(mode="json"),
            public_entries,
            private_entries,
            {"package_id": package_record.package_id, "source_snapshot_id": snapshot_id},
            {
                "fork_policy": "free",
                "visibility": visibility["effective_visibility"],
            },
        )
        append_package(workspace, package_record.model_dump(mode="json"))
        return {
            "archive_path": str(archive_path),
            "package": package_record.model_dump(mode="json"),
            "visibility_mode": resolved_visibility_mode,
            "policy_source": visibility["policy_source"],
            "effective_visibility": visibility["effective_visibility"],
            "public_sections": visibility["public_sections"],
            "private_sections": visibility["private_sections"],
            "code_ref": package_manifest.code_ref.model_dump(mode="json") if isinstance(package_manifest.code_ref, CodeRef) else package_manifest.code_ref,
            "workspace_overlay": package_manifest.workspace_overlay.model_dump(mode="json") if isinstance(package_manifest.workspace_overlay, WorkspaceOverlaySummary) else package_manifest.workspace_overlay,
            "trajectory": package_manifest.trajectory.model_dump(mode="json") if isinstance(package_manifest.trajectory, TrajectorySummary) else package_manifest.trajectory,
            "artifacts": package_manifest.artifacts.model_dump(mode="json") if isinstance(package_manifest.artifacts, ArtifactsSummary) else package_manifest.artifacts,
            **({"policy_path": visibility["policy_path"]} if visibility["policy_path"] else {}),
        }

    def publish(
        self,
        workspace: str,
        archive_path: str,
        *,
        message: str | None = None,
        visibility_policy_path: str | None = None,
        visibility_mode: str | None = None,
    ) -> dict[str, Any]:
        archive = Path(archive_path).resolve()
        if not archive.exists():
            raise ValueError(f"archive does not exist: {archive}")
        if archive_path and (visibility_policy_path or visibility_mode):
            raise ValueError(
                "visibility overrides apply during pack. Re-run `anyfs pack` with policy options, "
                "or omit the archive path so `anyfs publish` can auto-pack."
            )
        packages = list_packages(workspace)
        if not packages:
            raise ValueError("no package metadata available, run pack first")
        package = packages[-1]
        local_agent = workspace_agent_by_id(workspace, package["created_by_agent_id"], self.global_root)
        if not local_agent:
            raise ValueError("creating agent for package is not registered locally")
        agent_type = local_agent.get("agent_type")
        self._require_bound_agent_for_publish(workspace, agent_type)
        effective_message = (message or package.get("message") or "").strip()
        if not effective_message:
            raise ValueError("publish message is required")
        package["message"] = effective_message
        snapshot_id = package["source_snapshot_id"]
        available = self._get_snapshot_record(workspace, snapshot_id)["namespace"]
        agent = self._agent_lite(workspace, agent_type)
        snapshot_lite = self._snapshot_lite(workspace, snapshot_id, "package", available, agent_type)
        self._request("POST", "/agents", agent.model_dump(mode="json"), auth_kind="agent", workspace=workspace, agent_type=agent_type)
        self._request("POST", "/snapshots", snapshot_lite.model_dump(mode="json"), auth_kind="agent", workspace=workspace, agent_type=agent_type)

        # Upload the AFPKG archive to the configured blob backend via the storage gateway.
        archive_bytes = archive.read_bytes()
        storage_gateway_url = self._effective_storage_gateway_url()
        if storage_gateway_url:
            upload_result = self._upload_to_storage_gateway(archive_bytes, "application/zip")
            cid = upload_result["cid"]
            gateway_url = upload_result.get("gateway_url")
        else:
            cid = hashlib.sha256(archive_bytes).hexdigest()
            gateway_url = None

        self._request("POST", "/storage/delegation", {"agent_did": agent.agent_id, "scope": f"upload:{package['package_id']}"}, auth_kind="agent", workspace=workspace, agent_type=agent_type)
        self._request(
            "POST",
            "/storage/commit",
            {"resource_type": "package", "resource_id": package["package_id"], "cid": cid, "metadata": {"path": str(archive), "gateway_url": gateway_url}},
            auth_kind="agent",
            workspace=workspace,
            agent_type=agent_type,
        )
        self._request("POST", "/packages", PackageCreateRequest(agent=agent, snapshot=snapshot_lite, package=package).model_dump(mode="json"), auth_kind="agent", workspace=workspace, agent_type=agent_type)
        self._request("POST", f"/packages/{package['package_id']}/publish", {}, auth_kind="agent", workspace=workspace, agent_type=agent_type)
        package["published_at"] = utc_now_iso()
        package["cid"] = cid
        if gateway_url:
            package["gateway_url"] = gateway_url
        append_package(workspace, package)
        result = PublishResult(
            package_id=package["package_id"],
            cid=cid,
            path=str(archive),
            visibility_mode=package.get("visibility_mode", PublishVisibilityMode.ARTIFACTS_PUBLIC.value),
        ).model_dump(mode="json")
        result["message"] = package.get("message")
        result["code_ref"] = package.get("code_ref")
        result["workspace_overlay"] = package.get("workspace_overlay")
        result["trajectory"] = package.get("trajectory")
        result["artifacts"] = package.get("artifacts")
        if gateway_url:
            result["gateway_url"] = gateway_url
        return result

    def release_create(self, workspace: str, package_id: str, version: str) -> dict[str, Any]:
        package = self._get_package_record(workspace, package_id)
        if not package.get("published_at"):
            raise ValueError("package must be published before creating a release")
        release = ReleaseRecord(release_id=f"rel_{uuid.uuid4().hex[:12]}", package_id=package_id, version=version)
        # Sign as the workspace's default agent. The server enforces whether
        # this caller is allowed to cut a release for the package.
        agent_type = self._workspace_default_agent_type(workspace)
        result = self._request("POST", "/releases", release.model_dump(mode="json"), auth_kind="agent", workspace=workspace, agent_type=agent_type)
        append_release(workspace, result)
        return result

    def fork(self, workspace: str, package_id: str, child_display_name: str) -> dict[str, Any]:
        package = self._get_package_record(workspace, package_id)
        # Fork is always performed as the caller's own agent, never the creator's.
        # Picking creator's agent_type breaks for forks of packages published by
        # someone else (the creator DID is not registered in this workspace).
        agent_type = self._workspace_default_agent_type(workspace)
        result = self._request("POST", "/forks", {"package_id": package_id, "child_display_name": child_display_name, "fork_policy": "free"}, auth_kind="agent", workspace=workspace, agent_type=agent_type)
        append_package(workspace, result["child_package"])
        append_lineage(workspace, result["lineage"])
        return result

    def lineage_show(self, workspace: str, package_id: str) -> dict[str, Any]:
        if self.api_client is not None or self._effective_api_base_url(workspace=workspace):
            try:
                return {"items": self._request("GET", f"/packages/{package_id}/lineage", auth_kind="public")}
            except Exception:
                pass
        return {"items": lineage_for_package(workspace, package_id)}

    def package_storage(self, package_id: str, workspace: str | None = None) -> dict[str, Any]:
        return self._request("GET", f"/storage/package/{package_id}", auth_kind="public", workspace=workspace)

    def install_package(
        self,
        workspace: str,
        *,
        archive_path: str | None = None,
        package_id: str | None = None,
        output_dir: str | None = None,
    ) -> dict[str, Any]:
        if not archive_path and not package_id:
            raise ValueError("install_package requires archive_path or package_id")

        output_root = Path(output_dir or (default_workspace_root(workspace) / "exports" / "packages")).resolve()
        output_root.mkdir(parents=True, exist_ok=True)

        storage: dict[str, Any] | None = None
        if package_id and not archive_path:
            storage = self.package_storage(package_id, workspace=workspace)
            source = storage.get("metadata", {}).get("gateway_url") or storage.get("metadata", {}).get("path")
            if not source:
                raise ValueError(f"package {package_id} has no downloadable archive metadata")
            archive_path = source

        if archive_path is None:
            raise ValueError("archive path could not be resolved")

        if archive_path.startswith(("http://", "https://")):
            archive_file = output_root / (f"{package_id or 'package'}.afpkg")
            with httpx.Client(timeout=120.0) as client:
                response = client.get(archive_path)
                response.raise_for_status()
                archive_file.write_bytes(response.content)
        else:
            archive_file = Path(archive_path).expanduser().resolve()

        extracted_root = output_root / f"{archive_file.stem}-extracted"
        extract_afpkg(archive_file, extracted_root)

        restore_root = extracted_root / "restored"
        restore_root.mkdir(parents=True, exist_ok=True)
        private_dir = extracted_root / "afpkg" / "private"
        public_dir = extracted_root / "afpkg" / "public"
        restored_files: dict[str, str] = {}
        warnings: list[str] = []
        root_key = self._root_key()
        manifest_path = extracted_root / "afpkg" / "manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}

        if public_dir.exists():
            artifacts_public_dir = public_dir / "artifacts"
            if artifacts_public_dir.exists():
                artifacts_target = restore_root / "artifacts"
                shutil.copytree(artifacts_public_dir, artifacts_target, dirs_exist_ok=True)
                restored_files["artifacts"] = str(artifacts_target)
            trajectory_public_dir = public_dir / "trajectory"
            if trajectory_public_dir.exists():
                for payload_path in trajectory_public_dir.glob("*.json"):
                    target_path = restore_root / payload_path.name
                    target_path.write_bytes(payload_path.read_bytes())
                    restored_files[payload_path.stem] = str(target_path)
            workspace_overlay_public = public_dir / "workspace_overlay.json"
            if workspace_overlay_public.exists():
                overlay_payload = json.loads(workspace_overlay_public.read_text(encoding="utf-8"))
                workspace_result = self._restore_workspace_bundle(overlay_payload, restore_root)
                restored_files["workspace_overlay"] = workspace_result["output_file"]
                restored_files["workspace_restore_dir"] = workspace_result["restore_dir"]

        if private_dir.exists():
            for envelope_path in private_dir.glob("*.json"):
                envelope = json.loads(envelope_path.read_text(encoding="utf-8"))
                namespace = envelope["namespace"]
                try:
                    restored_payload = decrypt_json_payload(root_key, envelope)
                except Exception as exc:
                    warnings.append(f"could not decrypt namespace {namespace}: {exc}")
                    continue
                if namespace == Namespace.WORKSPACE_OVERLAY.value:
                    workspace_result = self._restore_workspace_bundle(restored_payload, restore_root)
                    restored_files["workspace_overlay"] = workspace_result["output_file"]
                    restored_files["workspace_restore_dir"] = workspace_result["restore_dir"]
                else:
                    target_path = restore_root / f"{namespace}.json"
                    target_path.write_text(json.dumps(restored_payload, indent=2), encoding="utf-8")
                    restored_files[namespace] = str(target_path)

            trajectory_dir = private_dir / "trajectory"
            if trajectory_dir.exists():
                for envelope_path in trajectory_dir.glob("*.json"):
                    envelope = json.loads(envelope_path.read_text(encoding="utf-8"))
                    namespace = envelope["namespace"]
                    try:
                        restored_payload = decrypt_json_payload(root_key, envelope)
                    except Exception as exc:
                        warnings.append(f"could not decrypt namespace {namespace}: {exc}")
                        continue
                    target_path = restore_root / f"{namespace}.json"
                    target_path.write_text(json.dumps(restored_payload, indent=2), encoding="utf-8")
                    restored_files[namespace] = str(target_path)

        code_ref_path = restore_root / "code_ref.json"
        if manifest.get("code_ref"):
            code_ref_path.write_text(json.dumps(manifest["code_ref"], indent=2), encoding="utf-8")
            restored_files["code_ref"] = str(code_ref_path)
            code_ref = manifest["code_ref"]
            if code_ref.get("repo_url"):
                restored_files["code_ref_hint"] = (
                    f"clone {code_ref['repo_url']} and checkout {code_ref.get('commit_sha') or 'the referenced commit'}"
                )

        return {
            "archive_path": str(archive_file),
            "extracted_root": str(extracted_root),
            "restore_dir": str(restore_root),
            "files": restored_files,
            "warnings": warnings,
            **({"manifest": manifest} if manifest else {}),
            **({"storage": storage} if storage else {}),
        }

    def buy(
        self,
        workspace: str,
        package_id: str,
        child_display_name: str,
        *,
        output_dir: str | None = None,
        resume_target: str | None = None,
    ) -> dict[str, Any]:
        fork_result = self.fork(workspace, package_id, child_display_name)
        install_result = self.install_package(workspace, package_id=package_id, output_dir=output_dir)

        resume_result: dict[str, Any] | None = None
        process_file = install_result.get("files", {}).get("process")
        workspace_root = install_result.get("files", {}).get("workspace_restore_dir") or workspace
        if resume_target and process_file:
            from anyfs_transcript import export_transcript, load_transcripts

            transcripts = load_transcripts(process_file)
            sessions = []
            for transcript in transcripts:
                files_written = export_transcript(transcript, target_agent=resume_target, workspace=workspace_root)
                sessions.append(
                    {
                        "source_agent": transcript.session.agent,
                        "source_session_id": transcript.session.id,
                        "files_written": files_written,
                        **({"resume_hint": files_written["resume_hint"]} if "resume_hint" in files_written else {}),
                    }
                )
            resume_result = {"target_agent": resume_target, "sessions": sessions}

        return {
            "package_id": package_id,
            "fork": fork_result,
            "install": install_result,
            **({"resume": resume_result} if resume_result else {}),
        }

    def migrate_context(
        self,
        source_agent: str,
        target_agent: str,
        workspace: str,
        *,
        target_workspace: str | None = None,
        overwrite: bool = False,
        dry_run: bool = False,
        preset: str = "user-data",
        include_secrets: bool = False,
    ) -> dict[str, Any]:
        if preset not in {"user-data", "full"}:
            raise ValueError("preset must be one of: user-data, full")
        target_workspace_path = Path(target_workspace or workspace).resolve()
        target_workspace_path.mkdir(parents=True, exist_ok=True)
        capture = self.capture(source_agent, workspace, client_scope="single")
        import_root = self._import_root_for_target(target_agent, target_workspace_path, source_agent)
        guidance_path = self._guidance_path_for_target(target_agent, target_workspace_path)
        extra_items = self._collect_migrate_extra_items(
            source_agent,
            preset=preset,
            include_secrets=include_secrets,
        )

        planned_files: list[str] = []
        applied_files: list[str] = []
        skipped_files: list[str] = []
        warnings = list(capture.get("warnings", [])) + list(extra_items["warnings"])

        non_process_items = {
            **capture.get("trajectory", {}),
            **({"artifacts": capture.get("artifacts", [])} if capture.get("artifacts") else {}),
        }
        for namespace, items in non_process_items.items():
            if namespace == "process":
                continue
            for item in items:
                target_path, mode = self._target_projection(
                    target_agent,
                    target_workspace_path,
                    source_agent,
                    item,
                    import_root,
                )
                planned_files.append(str(target_path))
                if dry_run:
                    continue
                if mode == "merge":
                    status = self._merge_text_if_allowed(
                        target_path,
                        item.get("content", ""),
                        overwrite,
                        source_agent=source_agent,
                        source_label=item.get("relative_path") or Path(item["path"]).name,
                    )
                else:
                    status = self._write_text_if_allowed(target_path, item.get("content", ""), overwrite)
                if status in {"written", "merged"}:
                    applied_files.append(str(target_path))
                else:
                    skipped_files.append(str(target_path))

        for item in extra_items["items"]:
            target_path = import_root / item["relative_path"]
            planned_files.append(str(target_path))
            if dry_run:
                continue
            status = self._write_text_if_allowed(target_path, item["content"], overwrite)
            if status == "written":
                applied_files.append(str(target_path))
            else:
                skipped_files.append(str(target_path))

        transcripts = self._transcripts_from_capture(capture)
        resume_sessions: list[dict[str, Any]] = []
        for canonical in transcripts:
            session_mode = (
                "native-resume"
                if self._native_resume_supported(target_agent)
                else "context-inject"
                if self._context_injection_supported(target_agent)
                else "process-note"
            )
            planned_files.append(f"{session_mode}:{target_agent}:{canonical['session']['id']}")
            if dry_run:
                continue
            from anyfs_schemas import CanonicalTranscript
            from anyfs_transcript import export_transcript, inject_transcript

            transcript = CanonicalTranscript.model_validate(canonical)
            if self._native_resume_supported(target_agent):
                files_written = export_transcript(transcript, target_agent=target_agent, workspace=str(target_workspace_path))
            elif self._context_injection_supported(target_agent):
                files_written = inject_transcript(transcript, target_agent=target_agent, workspace=str(target_workspace_path))
            else:
                files_written = self._write_process_context_note(
                    transcript,
                    target_agent,
                    target_workspace_path,
                    import_root,
                    overwrite,
                )
            session_entry = {
                "source_session_id": transcript.session.id,
                "files_written": files_written,
                **({"resume_hint": files_written["resume_hint"]} if "resume_hint" in files_written else {}),
            }
            resume_sessions.append(session_entry)

        if not dry_run:
            guidance_written = self._append_import_reference(target_agent, target_workspace_path, source_agent, import_root)
        else:
            guidance_written = str(guidance_path)

        report = {
            "source_agent": source_agent,
            "target_agent": target_agent,
            "workspace": str(Path(workspace).resolve()),
            "target_workspace": str(target_workspace_path),
            "dry_run": dry_run,
            "preset": preset,
            "include_secrets": include_secrets,
            "import_root": str(import_root),
            "guidance_file": guidance_written,
            "planned_items": planned_files,
            "applied_files": applied_files,
            "skipped_files": skipped_files,
            "resume_sessions": resume_sessions,
            "captured_namespaces": [
                *capture.get("trajectory_components", []),
                *([Namespace.ARTIFACTS.value] if capture.get("artifacts") else []),
                *([Namespace.WORKSPACE_OVERLAY.value] if capture.get("workspace_overlay") and capture["workspace_overlay"].get("mode") != "none" else []),
            ],
            "redacted_items": extra_items["redacted_items"],
            "secret_items": extra_items["secret_items"],
            "warnings": warnings,
        }
        return report

    def quick_share(
        self,
        workspace: str,
        namespaces: list[str] | None = None,
        share_password: str | None = None,
        agent_type: str = "claude-code",
        message: str | None = None,
        workspace_mode: str = "changed",
        process_scope: str = "current",
        artifacts_public: bool = True,
        artifact_paths: list[str] | None = None,
    ) -> dict[str, Any]:
        """One-shot: capture -> snapshot -> share selected namespaces with a password.

        Returns share links (content-addressed CIDs) for each namespace + the password.
        Designed to be called directly from an agent session.
        """
        import secrets
        import string

        if not message:
            raise ValueError("share message is required")

        # Auto-generate password if not provided
        if not share_password:
            alphabet = string.ascii_letters + string.digits
            share_password = "".join(secrets.choice(alphabet) for _ in range(16))

        # Ensure init + agent
        self.init()
        agent = workspace_agent(workspace, agent_type, self.global_root)
        if not agent:
            self.register_agent(agent_type, workspace)
            try:
                self.agent_create_remote(workspace, agent_type)
            except Exception:
                pass  # OK if API is not available

        # Capture + snapshot
        self.capture(
            agent_type,
            workspace,
            process_scope=process_scope,
            workspace_mode=workspace_mode,
            client_scope="single",
            artifact_paths=artifact_paths,
        )
        snapshot = self.snapshot_create(workspace, artifacts_public=artifacts_public)
        snapshot_id = snapshot["snapshot_id"]

        # Determine which namespaces to share
        available = snapshot.get("namespace", [])
        if namespaces is not None:
            selected = namespaces
        else:
            selected = [
                "workspace" if ns == "workspace_overlay" else ns
                for ns in available
                if ns not in {"artifacts", Namespace.SOUL.value, Namespace.MEMORY.value}
            ]
            if workspace_mode != "none":
                if "workspace_overlay" not in selected and "workspace" not in selected:
                    selected.append("workspace")

        # Share each namespace
        shares: dict[str, dict[str, Any]] = {}
        for ns in selected:
            try:
                result = self.share_namespace(
                    workspace,
                    ns,
                    share_password,
                    snapshot_id,
                    message=message,
                    workspace_mode=workspace_mode,
                )
                shares[ns] = {
                    "cid": result.get("cid"),
                    "gateway_url": result.get("gateway_url"),
                    "share_file": result.get("share_file"),
                    "message": result.get("message"),
                }
            except Exception as exc:
                shares[ns] = {"error": str(exc)}

        sender_name = agent.get("display_name") or agent.get("agent_type") or "Someone"
        successful_links = [
            info.get("gateway_url") or info.get("share_file")
            for info in shares.values()
            if not info.get("error") and (info.get("gateway_url") or info.get("share_file"))
        ]
        handoff_lines = [
            f"{sender_name} shared agent context with you via AnyFS.",
            "",
        ]
        if successful_links:
            handoff_lines.extend(
                [
                    "Open it with:",
                    f"    anyfs open {successful_links[0]} -p {share_password} --type <your-current-client>",
                    "    Replace <your-current-client> with your current client, for example: claude-code, codex-cli, gemini-cli, or opencode.",
                    "",
                ]
            )
            if len(successful_links) > 1:
                handoff_lines.append("Additional links:")
                handoff_lines.extend(f"    {link}" for link in successful_links[1:])
                handoff_lines.append("")
        handoff_lines.extend(
            [
                "If <your-current-client> is not registered with AnyFS yet, register first:",
                "    anyfs register --type <your-current-client> <display-name>",
                "",
                "If you do not have AnyFS yet:",
                "    curl -fsSL https://skills.anyfs.ai/install.sh | bash",
                "    curl -fsSL https://skills.anyfs.ai/skill.md",
            ]
        )
        handoff_text = "\n".join(handoff_lines)

        return {
            "snapshot_id": snapshot_id,
            "password": share_password,
            "message": message,
            "workspace_mode": workspace_mode,
            "process_scope": process_scope if process_scope in {"current", "all"} else "current",
            "shares": shares,
            "instructions": f"Recipient runs: anyfs open <file_or_url> -p {share_password} --type <their-client>",
            "handoff_text": handoff_text,
        }

    def export_recovery(self, output_path: str | None = None) -> dict[str, Any]:
        self.init()
        path = export_recovery_bundle(self.global_root, self._identity(), Path(output_path).resolve() if output_path else None)
        return {"recovery_path": str(path)}

    def import_recovery(self, recovery_path: str) -> dict[str, Any]:
        payload = import_recovery_bundle(self.global_root, Path(recovery_path).resolve())
        return {"bundle_version": payload["bundle_version"], "global_root": str(self.global_root)}

    def skill_specs(self) -> dict[str, Any]:
        return {name: spec.model_dump(mode="json") for name, spec in ACTION_SPECS.items()}
