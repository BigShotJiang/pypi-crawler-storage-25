from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from anyfs_adapters_core import AgentAdapter, append_unique, collect_text_files, read_text_file
from anyfs_schemas import AgentType, CaptureResult, CodeRef, Namespace, WorkspaceBinding, WorkspaceOverlay
from anyfs_transcript import parse_transcript, render_markdown

_EXPORT_ROOT = ".anyfs/exports/opencode-capture"
_OPENCODE_EXCLUDED_CONTEXT_FILES = {"opencode.json", "package.json"}


def _resolve_opencode_binary() -> str | None:
    explicit = os.environ.get("OPENCODE_BIN")
    if explicit:
        return explicit
    discovered = shutil.which("opencode")
    if discovered:
        return discovered
    home = Path.home()
    candidates = sorted(home.glob(".local/node-*/bin/opencode"), reverse=True)
    candidates.extend([home / ".local" / "bin" / "opencode", home / ".npm-global" / "bin" / "opencode"])
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return None


def _config_paths(workspace_path: Path) -> list[Path]:
    return [
        workspace_path / "AGENTS.md",
    ]


def _capture_root(workspace_path: Path) -> Path:
    root = workspace_path / _EXPORT_ROOT
    root.mkdir(parents=True, exist_ok=True)
    return root


def _extract_json(payload: str) -> dict:
    start = payload.find("{")
    if start == -1:
        raise ValueError("OpenCode export did not return JSON")
    return json.loads(payload[start:])


def _list_workspace_sessions(binary: str, workspace_path: Path) -> list[dict]:
    result = subprocess.run(
        [binary, "session", "list", "--format", "json"],
        cwd=str(workspace_path),
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise ValueError(result.stderr.strip() or result.stdout.strip() or "failed to list OpenCode sessions")
    payload = json.loads(result.stdout)
    sessions: list[dict] = []
    for item in payload:
        directory = item.get("directory")
        if not isinstance(directory, str):
            continue
        if Path(directory).resolve() != workspace_path:
            continue
        sessions.append(item)
    sessions.sort(key=lambda item: item.get("updated", 0), reverse=True)
    return sessions
def _export_session(binary: str, workspace_path: Path, session_id: str, output_path: Path) -> Path:
    result = subprocess.run(
        [binary, "export", session_id],
        cwd=str(workspace_path),
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise ValueError(result.stderr.strip() or result.stdout.strip() or f"failed to export OpenCode session {session_id}")
    payload = _extract_json(result.stdout)
    output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return output_path


class OpenCodeAdapter(AgentAdapter):
    agent_type = AgentType.OPENCODE

    def __init__(self, process_scope: str = "current") -> None:
        self.process_scope = process_scope if process_scope in {"current", "all"} else "current"

    def discover(self, workspace: str) -> list[Path]:
        workspace_path = Path(workspace).resolve()
        candidates: list[Path] = [path for path in _config_paths(workspace_path) if path.is_file()]
        for root in (
            workspace_path / ".opencode",
            Path.home() / ".config" / "opencode" / "skills",
        ):
            for path in collect_text_files(root, max_files=120, exclude_names=_OPENCODE_EXCLUDED_CONTEXT_FILES):
                append_unique(candidates, path)

        binary = _resolve_opencode_binary()
        if not binary:
            return candidates

        capture_root = _capture_root(workspace_path)
        try:
            sessions = _list_workspace_sessions(binary, workspace_path)
        except Exception:
            return candidates

        if self.process_scope == "all":
            selected_sessions = sessions[:20]
        else:
            selected_sessions = sessions[:1]
        for session in selected_sessions:
            session_id = session.get("id")
            if not isinstance(session_id, str) or not session_id:
                continue
            output_path = capture_root / f"{session_id}.json"
            try:
                candidates.append(_export_session(binary, workspace_path, session_id, output_path))
            except Exception:
                continue

        return candidates[:100]

    def extract(self, workspace: str) -> list[dict]:
        workspace_path = Path(workspace).resolve()
        global_root = Path.home() / ".config" / "opencode"
        records = []
        for path in self.discover(workspace):
            if path.parent == _capture_root(workspace_path) and path.suffix == ".json":
                try:
                    canonical = parse_transcript(path, agent_type="opencode")
                    content = render_markdown(canonical)
                    records.append(
                        {
                            "path": str(path),
                            "relative_path": f"process/opencode/{path.name}",
                            "namespace": "process",
                            "content": content,
                            "canonical_transcript": canonical.model_dump(mode="json"),
                        }
                    )
                    continue
                except Exception:
                    pass

            if path.is_relative_to(global_root):
                namespace = "skills"
                relative_path = f"skills/opencode/global/{path.relative_to(global_root)}"
            else:
                namespace = "skills" if path.name == "AGENTS.md" or path.is_relative_to(workspace_path / ".opencode") else "artifacts"
                relative_path = str(path.relative_to(workspace_path))
            records.append(
                {
                    "path": str(path),
                    "relative_path": relative_path,
                    "namespace": namespace,
                    "content": read_text_file(path),
                }
            )
        return records

    def normalize(self, raw: list[dict]) -> dict[str, list[dict]]:
        normalized: dict[str, list[dict]] = {}
        for record in raw:
            normalized.setdefault(record["namespace"], []).append(record)
        return normalized

    def bundle(self, normalized: dict[str, list[dict]], policy: dict | None = None) -> CaptureResult:
        trajectory = {ns: items for ns, items in normalized.items() if ns != "artifacts"}
        components = [Namespace(ns) for ns in trajectory.keys()]
        return CaptureResult(
            agent_id="pending",
            agent_type=self.agent_type,
            workspace="",
            code_ref=CodeRef(),
            workspace_overlay=WorkspaceOverlay(mode="none", binding=WorkspaceBinding(cwd="")),
            trajectory=trajectory,
            artifacts=normalized.get("artifacts", []),
            trajectory_components=components,
            captured_namespaces=list(normalized.keys()),
            payloads=normalized,
            warnings=[] if normalized else ["no OpenCode files were discovered"],
        )
