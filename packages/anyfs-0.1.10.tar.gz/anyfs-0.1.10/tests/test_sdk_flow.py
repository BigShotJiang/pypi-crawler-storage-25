from __future__ import annotations

import asyncio
import importlib
import json
import os
import zipfile
from contextlib import contextmanager
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from anyfs_crypto import encrypt_json_payload, rewrap_dek_for_share
from anyfs_local_state import record_capture
from anyfs_sdk import AnyFSService, run_skill_action


def write_workspace_file(workspace: Path, rel_path: str, content: str) -> None:
    path = workspace / rel_path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def write_codex_session(home: Path, workspace: Path, session_id: str = "demo") -> None:
    session_path = home / ".codex" / "sessions" / "2026" / "04" / "09" / f"rollout-{session_id}.jsonl"
    session_path.parent.mkdir(parents=True, exist_ok=True)
    session_path.write_text(
        "\n".join(
            [
                json.dumps(
                    {
                        "type": "session_meta",
                        "timestamp": "2026-04-09T12:00:00+00:00",
                        "payload": {"id": session_id, "cwd": str(workspace.resolve()), "model_provider": "gpt-5.4"},
                    }
                ),
                json.dumps(
                    {
                        "type": "response_item",
                        "timestamp": "2026-04-09T12:00:00+00:00",
                        "payload": {"type": "message", "role": "user", "content": [{"type": "input_text", "text": "Check codex state"}]},
                    }
                ),
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def write_claude_session(home: Path, workspace: Path, session_id: str = "demo") -> None:
    session_path = home / ".claude" / "projects" / str(workspace.resolve()).replace("/", "-") / f"{session_id}.jsonl"
    session_path.parent.mkdir(parents=True, exist_ok=True)
    session_path.write_text(
        json.dumps(
            {
                "type": "user",
                "timestamp": "2026-04-09T12:00:02+00:00",
                "message": {
                    "role": "user",
                    "content": "Check claude state",
                },
            }
        )
        + "\n",
        encoding="utf-8",
    )


def write_gemini_session(gemini_home: Path, workspace: Path) -> None:
    project_dir = gemini_home / ".gemini" / "tmp" / "demo"
    (project_dir / "chats").mkdir(parents=True, exist_ok=True)
    (project_dir / ".project_root").write_text(str(workspace.resolve()), encoding="utf-8")
    (project_dir / "chats" / "session-demo.json").write_text(
        json.dumps(
            {
                "sessionId": "gem-demo",
                "projectHash": "demo",
                "startTime": "2026-04-09T12:00:00+00:00",
                "lastUpdated": "2026-04-09T12:00:01+00:00",
                "messages": [
                    {"id": "u1", "timestamp": "2026-04-09T12:00:00+00:00", "type": "user", "content": "Check gemini state"},
                ],
            }
        ),
        encoding="utf-8",
    )


@contextmanager
def build_api_client(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("ANYFS_API_DATA_DIR", str(tmp_path / "api-data"))
    monkeypatch.setenv("ANYFS_PUBLIC_BASE_URL", "http://testserver")
    import anyfs_api.main as api_main

    api_main = importlib.reload(api_main)
    with TestClient(api_main.app) as client:
        yield client


def test_openclaw_local_flow(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-openclaw"
    workspace.mkdir()
    write_workspace_file(workspace, "state/soul.json", '{"kind":"soul"}')
    write_workspace_file(workspace, "memory/notes.md", "# memory")
    write_workspace_file(workspace, "artifacts/report.md", "# artifact")

    service = AnyFSService(global_root=global_root)
    service.init()
    agent = service.register_agent("openclaw", str(workspace))
    capture = service.capture("openclaw", str(workspace))
    assert agent["agent_id"].startswith("did:key:")
    assert "soul" in capture["captured_namespaces"]

    snapshot = service.snapshot_create(str(workspace))
    assert snapshot["snapshot_id"].startswith("snp_")

    restored = service.restore(str(workspace), "latest")
    assert Path(restored["restore_dir"]).exists()

    packed = service.pack(str(workspace), snapshot["snapshot_id"])
    assert Path(packed["archive_path"]).exists()


def test_snapshot_can_make_artifacts_private(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-private-artifacts"
    workspace.mkdir()
    write_workspace_file(workspace, "state/soul.json", '{"kind":"soul"}')
    write_workspace_file(workspace, "artifacts/report.md", "# artifact")

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("openclaw", str(workspace))
    service.capture("openclaw", str(workspace), artifact_paths=["artifacts/report.md"])

    snapshot = service.snapshot_create(str(workspace), artifacts_public=False)
    manifest = json.loads((workspace / ".anyfs" / "manifests" / f"{snapshot['snapshot_id']}.json").read_text(encoding="utf-8"))
    assert manifest["artifacts"]["visibility"] == "private"
    assert manifest["artifacts"]["count"] >= 1

    packed = service.pack(str(workspace), snapshot["snapshot_id"])
    assert Path(packed["archive_path"]).exists()


def test_opencode_local_flow(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-opencode"
    workspace.mkdir()
    write_workspace_file(workspace, "opencode.json", '{"model":"moonshotai-cn/kimi-k2.5"}')

    fake_bin = tmp_path / "opencode"
    export_payload = {
        "info": {
            "id": "ses_test",
            "slug": "demo",
            "projectID": "proj_anyfs",
            "directory": str(workspace.resolve()),
            "title": "Demo",
            "version": "2.1.89",
            "time": {"created": 1775736000000, "updated": 1775736001000},
        },
        "messages": [
            {
                "info": {
                    "id": "msg_u1",
                    "sessionID": "ses_test",
                    "role": "user",
                    "time": {"created": 1775736000000},
                    "agent": "build",
                    "model": {"providerID": "moonshotai-cn", "modelID": "kimi-k2.5"},
                },
                "parts": [{"id": "prt_u1", "sessionID": "ses_test", "messageID": "msg_u1", "type": "text", "text": "Share this", "time": {"start": 1775736000000, "end": 1775736000000}}],
            }
        ],
    }
    fake_bin.write_text(
        "\n".join(
            [
                "#!/usr/bin/env python3",
                "import json, sys",
                f"workspace = {str(workspace.resolve())!r}",
                f"payload = {json.dumps(export_payload, ensure_ascii=False)!r}",
                "argv = sys.argv[1:]",
                "if argv == ['session', 'list', '--format', 'json']:",
                "    print(json.dumps([{'id': 'ses_test', 'title': 'Demo', 'updated': 1775736001000, 'created': 1775736000000, 'projectId': 'proj_anyfs', 'directory': workspace}]))",
                "    raise SystemExit(0)",
                "if len(argv) == 2 and argv[0] == 'export' and argv[1] == 'ses_test':",
                "    print('Exporting session: ses_test')",
                "    print(payload)",
                "    raise SystemExit(0)",
                "raise SystemExit(1)",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    fake_bin.chmod(0o755)
    monkeypatch.setenv("PATH", f"{tmp_path}:{os.environ.get('PATH', '')}")
    monkeypatch.delenv("OPENCODE_BIN", raising=False)

    service = AnyFSService(global_root=global_root)
    service.init()
    agent = service.register_agent("opencode", str(workspace))
    capture = service.capture("opencode", str(workspace))
    assert agent["agent_id"].startswith("did:key:")
    assert "process" in capture["captured_namespaces"]

    snapshot = service.snapshot_create(str(workspace))
    assert snapshot["snapshot_id"].startswith("snp_")


def test_codex_local_flow(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-codex"
    workspace.mkdir()
    home = tmp_path / "home"
    write_workspace_file(workspace, "AGENTS.md", "# codex agents")
    write_workspace_file(home, ".codex/skills/demo/SKILL.md", "# skill")
    write_codex_session(home, workspace)
    monkeypatch.setenv("HOME", str(home))

    service = AnyFSService(global_root=global_root)
    service.init()
    agent = service.register_agent("codex-cli", str(workspace))
    capture = service.capture("codex-cli", str(workspace))
    assert agent["agent_id"].startswith("did:key:")
    assert "process" in capture["captured_namespaces"]
    assert "skills" in capture["captured_namespaces"]
    assert capture["process_scope"] == "all"


def test_capture_defaults_to_project_scope_across_code_clients(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-project-capture"
    workspace.mkdir()
    home = tmp_path / "home"
    write_workspace_file(workspace, "AGENTS.md", "# shared guidance")
    write_workspace_file(workspace, "CLAUDE.md", "# claude guidance")
    write_codex_session(home, workspace, session_id="codex-demo")
    write_claude_session(home, workspace, session_id="claude-demo")
    monkeypatch.setenv("HOME", str(home))

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("codex-cli", str(workspace))
    capture = service.capture("codex-cli", str(workspace))

    process_items = capture["payloads"]["process"]
    assert capture["client_scope"] == "project"
    assert "codex-cli" in capture["captured_agent_types"]
    assert "claude-code" in capture["captured_agent_types"]
    assert len(process_items) >= 2
    assert any("process/codex/" in item["relative_path"] for item in process_items)
    assert any("claude-demo.jsonl" in item["path"] for item in process_items)


def test_skill_filter_keeps_only_explicitly_used_codex_skills(tmp_path: Path) -> None:
    service = AnyFSService(global_root=tmp_path / "global")
    normalized = {
        "process": [
            {
                "canonical_transcript": {
                    "session": {"agent": "codex-cli"},
                    "events": [
                        {"kind": "user_message", "text": "Use $anyfs and then continue."},
                    ],
                }
            }
        ],
        "skills": [
            {
                "relative_path": "skills/codex/global/skills/anyfs/SKILL.md",
                "path": "/tmp/.codex/skills/anyfs/SKILL.md",
                "namespace": "skills",
                "content": "# AnyFS",
            },
            {
                "relative_path": "skills/codex/global/skills/github/SKILL.md",
                "path": "/tmp/.codex/skills/github/SKILL.md",
                "namespace": "skills",
                "content": "# GitHub",
            },
            {
                "relative_path": "AGENTS.md",
                "path": "/tmp/workspace/AGENTS.md",
                "namespace": "skills",
                "content": "# Project guidance",
            },
        ],
    }

    filtered = service._filter_skills_by_process_usage(normalized)
    kept = {item["relative_path"] for item in filtered["skills"]}
    assert "skills/codex/global/skills/anyfs/SKILL.md" in kept
    assert "AGENTS.md" in kept
    assert "skills/codex/global/skills/github/SKILL.md" not in kept


def test_skill_filter_keeps_only_explicitly_used_claude_and_opencode_entries(tmp_path: Path) -> None:
    service = AnyFSService(global_root=tmp_path / "global")
    normalized = {
        "process": [
            {
                "canonical_transcript": {
                    "session": {"agent": "claude-code"},
                    "events": [
                        {"kind": "user_message", "text": "Run /deploy-check before shipping."},
                    ],
                }
            },
            {
                "canonical_transcript": {
                    "session": {"agent": "opencode"},
                    "events": [
                        {"kind": "user_message", "text": "@review help me inspect this."},
                        {"kind": "assistant_text", "text": '[Tool: skill] {"name":"release"}'},
                    ],
                }
            },
        ],
        "skills": [
            {
                "relative_path": "skills/claude/global/skills/deploy-check/SKILL.md",
                "path": "/tmp/.claude/skills/deploy-check/SKILL.md",
                "namespace": "skills",
                "content": "# deploy-check",
            },
            {
                "relative_path": "skills/opencode/global/agents/review.md",
                "path": "/tmp/.config/opencode/agents/review.md",
                "namespace": "skills",
                "content": "# review",
            },
            {
                "relative_path": "skills/opencode/global/skills/release/SKILL.md",
                "path": "/tmp/.config/opencode/skills/release/SKILL.md",
                "namespace": "skills",
                "content": "# release",
            },
            {
                "relative_path": "skills/opencode/global/skills/unused/SKILL.md",
                "path": "/tmp/.config/opencode/skills/unused/SKILL.md",
                "namespace": "skills",
                "content": "# unused",
            },
            {
                "relative_path": "CLAUDE.md",
                "path": "/tmp/workspace/CLAUDE.md",
                "namespace": "skills",
                "content": "# Project guidance",
            },
        ],
    }

    filtered = service._filter_skills_by_process_usage(normalized)
    kept = {item["relative_path"] for item in filtered["skills"]}
    assert "skills/claude/global/skills/deploy-check/SKILL.md" in kept
    assert "skills/opencode/global/agents/review.md" in kept
    assert "skills/opencode/global/skills/release/SKILL.md" in kept
    assert "CLAUDE.md" in kept
    assert "skills/opencode/global/skills/unused/SKILL.md" not in kept


def test_skill_filter_keeps_plugin_metadata_for_used_plugin(tmp_path: Path) -> None:
    service = AnyFSService(global_root=tmp_path / "global")
    normalized = {
        "process": [
            {
                "canonical_transcript": {
                    "session": {"agent": "claude-code"},
                    "events": [
                        {"kind": "user_message", "text": "Use /terraform to inspect infra."},
                    ],
                }
            }
        ],
        "skills": [
            {
                "relative_path": "skills/claude/global/plugins/marketplaces/claude-plugins-official/external_plugins/terraform/SKILL.md",
                "path": "/tmp/.claude/plugins/marketplaces/claude-plugins-official/external_plugins/terraform/SKILL.md",
                "namespace": "skills",
                "content": "# terraform",
            },
            {
                "relative_path": "skills/claude/global/plugins/marketplaces/claude-plugins-official/external_plugins/terraform/.mcp.json",
                "path": "/tmp/.claude/plugins/marketplaces/claude-plugins-official/external_plugins/terraform/.mcp.json",
                "namespace": "skills",
                "content": "{\"name\":\"terraform\"}",
            },
            {
                "relative_path": "skills/claude/global/plugins/marketplaces/claude-plugins-official/external_plugins/fakechat/.mcp.json",
                "path": "/tmp/.claude/plugins/marketplaces/claude-plugins-official/external_plugins/fakechat/.mcp.json",
                "namespace": "skills",
                "content": "{\"name\":\"fakechat\"}",
            },
        ],
    }

    filtered = service._filter_skills_by_process_usage(normalized)
    kept = {item["relative_path"] for item in filtered["skills"]}
    assert "skills/claude/global/plugins/marketplaces/claude-plugins-official/external_plugins/terraform/SKILL.md" in kept
    assert "skills/claude/global/plugins/marketplaces/claude-plugins-official/external_plugins/terraform/.mcp.json" in kept
    assert "skills/claude/global/plugins/marketplaces/claude-plugins-official/external_plugins/fakechat/.mcp.json" not in kept


def test_skill_filter_keeps_full_personal_agent_skills(tmp_path: Path) -> None:
    service = AnyFSService(global_root=tmp_path / "global")
    normalized = {
        "process": [
            {
                "canonical_transcript": {
                    "session": {"agent": "codex-cli"},
                    "events": [
                        {"kind": "user_message", "text": "Do the thing."},
                    ],
                }
            }
        ],
        "skills": [
            {
                "relative_path": "skills/hermes/global/skills/daily/SKILL.md",
                "path": "/tmp/.hermes/skills/daily/SKILL.md",
                "namespace": "skills",
                "content": "# daily",
            },
            {
                "relative_path": ".openclaw/workflows/triage.md",
                "path": "/tmp/workspace/.openclaw/workflows/triage.md",
                "namespace": "skills",
                "content": "# triage",
            },
            {
                "relative_path": "skills/nanobot-helper/SKILL.md",
                "path": "/tmp/workspace/skills/nanobot-helper/SKILL.md",
                "namespace": "skills",
                "content": "# helper",
            },
            {
                "relative_path": "skills/codex/global/skills/github/SKILL.md",
                "path": "/tmp/.codex/skills/github/SKILL.md",
                "namespace": "skills",
                "content": "# github",
            },
        ],
    }

    filtered = service._filter_skills_by_process_usage(normalized)
    kept = {item["relative_path"] for item in filtered["skills"]}
    assert "skills/hermes/global/skills/daily/SKILL.md" in kept
    assert ".openclaw/workflows/triage.md" in kept
    assert "skills/nanobot-helper/SKILL.md" in kept
    assert "skills/codex/global/skills/github/SKILL.md" not in kept


def test_skill_filter_keeps_project_gemini_commands_and_used_global_command(tmp_path: Path) -> None:
    service = AnyFSService(global_root=tmp_path / "global")
    normalized = {
        "process": [
            {
                "canonical_transcript": {
                    "session": {"agent": "gemini-cli"},
                    "events": [
                        {"kind": "user_message", "text": "Run /release-notes and then /deploy."},
                    ],
                }
            }
        ],
        "skills": [
            {
                "relative_path": ".gemini/commands/release-notes.toml",
                "path": "/tmp/workspace/.gemini/commands/release-notes.toml",
                "namespace": "skills",
                "content": "prompt = 'release notes'",
            },
            {
                "relative_path": "skills/gemini/global/commands/deploy.toml",
                "path": "/tmp/.gemini/commands/deploy.toml",
                "namespace": "skills",
                "content": "prompt = 'deploy'",
            },
            {
                "relative_path": "skills/gemini/global/commands/unused.toml",
                "path": "/tmp/.gemini/commands/unused.toml",
                "namespace": "skills",
                "content": "prompt = 'unused'",
            },
        ],
    }

    filtered = service._filter_skills_by_process_usage(normalized)
    kept = {item["relative_path"] for item in filtered["skills"]}
    assert ".gemini/commands/release-notes.toml" in kept
    assert "skills/gemini/global/commands/deploy.toml" in kept
    assert "skills/gemini/global/commands/unused.toml" not in kept


def test_skill_filter_keeps_project_codex_and_claude_skill_roots(tmp_path: Path) -> None:
    service = AnyFSService(global_root=tmp_path / "global")
    normalized = {
        "process": [
            {
                "canonical_transcript": {
                    "session": {"agent": "codex-cli"},
                    "events": [
                        {"kind": "user_message", "text": "General work, no explicit skill invocation."},
                    ],
                }
            }
        ],
        "skills": [
            {
                "relative_path": ".agents/skills/release-helper/SKILL.md",
                "path": "/tmp/workspace/.agents/skills/release-helper/SKILL.md",
                "namespace": "skills",
                "content": "# release helper",
            },
            {
                "relative_path": ".claude/commands/review.md",
                "path": "/tmp/workspace/.claude/commands/review.md",
                "namespace": "skills",
                "content": "# review",
            },
            {
                "relative_path": ".claude/agents/research.md",
                "path": "/tmp/workspace/.claude/agents/research.md",
                "namespace": "skills",
                "content": "# research",
            },
            {
                "relative_path": ".claude/rules/security.md",
                "path": "/tmp/workspace/.claude/rules/security.md",
                "namespace": "skills",
                "content": "# security",
            },
            {
                "relative_path": "skills/codex/global/skills/github/SKILL.md",
                "path": "/tmp/.codex/skills/github/SKILL.md",
                "namespace": "skills",
                "content": "# github",
            },
        ],
    }

    filtered = service._filter_skills_by_process_usage(normalized)
    kept = {item["relative_path"] for item in filtered["skills"]}
    assert ".agents/skills/release-helper/SKILL.md" in kept
    assert ".claude/commands/review.md" in kept
    assert ".claude/agents/research.md" in kept
    assert ".claude/rules/security.md" in kept
    assert "skills/codex/global/skills/github/SKILL.md" not in kept


def test_project_capture_dedupes_same_skill_name_across_code_clients(tmp_path: Path) -> None:
    service = AnyFSService(global_root=tmp_path / "global")
    normalized = {
        "process": [
            {
                "canonical_transcript": {
                    "session": {"agent": "codex-cli"},
                    "events": [{"kind": "user_message", "text": "Use $anyfs for this task."}],
                }
            },
            {
                "canonical_transcript": {
                    "session": {"agent": "claude-code"},
                    "events": [{"kind": "user_message", "text": "Also /anyfs if needed."}],
                }
            },
        ],
        "skills": [
            {
                "relative_path": "skills/codex/global/skills/anyfs/SKILL.md",
                "path": "/tmp/.codex/skills/anyfs/SKILL.md",
                "namespace": "skills",
                "content": "# AnyFS codex",
            },
            {
                "relative_path": "skills/codex/global/skills/anyfs/references/cli-commands.md",
                "path": "/tmp/.codex/skills/anyfs/references/cli-commands.md",
                "namespace": "skills",
                "content": "# docs",
            },
            {
                "relative_path": "skills/claude/global/skills/anyfs/SKILL.md",
                "path": "/tmp/.claude/skills/anyfs/SKILL.md",
                "namespace": "skills",
                "content": "# AnyFS claude",
            },
            {
                "relative_path": "skills/claude/global/skills/anyfs/references/cli-commands.md",
                "path": "/tmp/.claude/skills/anyfs/references/cli-commands.md",
                "namespace": "skills",
                "content": "# docs",
            },
        ],
    }

    filtered = service._filter_skills_by_process_usage(normalized)
    deduped = service._dedupe_skills_by_name(filtered, "codex-cli")
    kept = {item["relative_path"] for item in deduped["skills"]}
    assert "skills/codex/global/skills/anyfs/SKILL.md" in kept
    assert "skills/codex/global/skills/anyfs/references/cli-commands.md" in kept
    assert "skills/claude/global/skills/anyfs/SKILL.md" not in kept
    assert "skills/claude/global/skills/anyfs/references/cli-commands.md" not in kept


def test_capture_single_client_scope_keeps_source_agent_only(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-single-capture"
    workspace.mkdir()
    home = tmp_path / "home"
    write_codex_session(home, workspace, session_id="codex-demo")
    write_claude_session(home, workspace, session_id="claude-demo")
    monkeypatch.setenv("HOME", str(home))

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("codex-cli", str(workspace))
    capture = service.capture("codex-cli", str(workspace), client_scope="single")

    process_items = capture["payloads"]["process"]
    assert capture["client_scope"] == "single"
    assert capture["captured_agent_types"] == ["codex-cli"]
    assert len(process_items) == 1
    assert "process/codex/" in process_items[0]["relative_path"]


def test_gemini_local_flow(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-gemini"
    workspace.mkdir()
    gemini_root = tmp_path / "gemini-home"
    write_workspace_file(workspace, "GEMINI.md", "# gemini instructions")
    write_workspace_file(gemini_root, ".gemini/skills/demo/SKILL.md", "# skill")
    write_gemini_session(gemini_root, workspace)
    monkeypatch.setenv("GEMINI_HOME", str(gemini_root / ".gemini"))

    service = AnyFSService(global_root=global_root)
    service.init()
    agent = service.register_agent("gemini-cli", str(workspace))
    capture = service.capture("gemini-cli", str(workspace))
    assert agent["agent_id"].startswith("did:key:")
    assert "process" in capture["captured_namespaces"]
    assert "skills" in capture["captured_namespaces"]
    assert capture["process_scope"] == "all"


def test_capture_can_include_all_process_sessions(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-codex-all"
    workspace.mkdir()
    home = tmp_path / "home"
    write_workspace_file(home, ".codex/skills/demo/SKILL.md", "# skill")
    write_codex_session(home, workspace, session_id="sid-1")
    write_codex_session(home, workspace, session_id="sid-2")
    monkeypatch.setenv("HOME", str(home))

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("codex-cli", str(workspace))
    capture = service.capture("codex-cli", str(workspace), process_scope="all")
    process_items = capture["payloads"]["process"]
    assert capture["process_scope"] == "all"
    assert len(process_items) == 2


def test_get_adapter_passes_process_scope_to_hermes_and_nanobot(tmp_path: Path, monkeypatch) -> None:
    import anyfs_sdk.service as service_module

    seen: dict[str, str] = {}

    class DummyHermesAdapter:
        def __init__(self, process_scope: str = "current") -> None:
            seen["hermes"] = process_scope

    class DummyNanobotAdapter:
        def __init__(self, process_scope: str = "current") -> None:
            seen["nanobot"] = process_scope

    monkeypatch.setattr(service_module, "HermesAdapter", DummyHermesAdapter)
    monkeypatch.setattr(service_module, "NanobotAdapter", DummyNanobotAdapter)

    service = AnyFSService(global_root=tmp_path / "global")
    service._get_adapter("hermes", process_scope="all")
    service._get_adapter("nanobot", process_scope="all")

    assert seen == {"hermes": "all", "nanobot": "all"}


def test_quick_share_can_make_artifacts_private(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-share-private-artifacts"
    workspace.mkdir()
    home = tmp_path / "home"
    write_workspace_file(workspace, "AGENTS.md", "# codex agents")
    write_workspace_file(workspace, "artifacts/report.md", "# artifact")
    write_codex_session(home, workspace)
    monkeypatch.setenv("HOME", str(home))

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("codex-cli", str(workspace))
    result = service.quick_share(
        str(workspace),
        agent_type="codex-cli",
        message="private artifacts please",
        artifacts_public=False,
        artifact_paths=["artifacts/report.md"],
    )
    manifest = json.loads((workspace / ".anyfs" / "manifests" / f"{result['snapshot_id']}.json").read_text(encoding="utf-8"))
    assert manifest["artifacts"]["visibility"] == "private"
    assert manifest["artifacts"]["index"] == []


def test_capture_does_not_auto_collect_artifacts(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-no-auto-artifacts"
    workspace.mkdir()
    write_workspace_file(workspace, "artifacts/report.md", "# artifact")
    write_workspace_file(workspace, "README.md", "# readme")

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("openclaw", str(workspace))
    capture = service.capture("openclaw", str(workspace))

    assert capture["artifacts"] == []
    assert "artifacts" not in capture["captured_namespaces"]


def test_capture_collects_only_explicit_artifacts(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-explicit-artifacts"
    workspace.mkdir()
    write_workspace_file(workspace, "artifacts/report.md", "# artifact")
    write_workspace_file(workspace, "outputs/data.json", '{"ok":true}')
    write_workspace_file(workspace, "README.md", "# readme")

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("openclaw", str(workspace))
    capture = service.capture(
        "openclaw",
        str(workspace),
        artifact_paths=["artifacts/report.md", "outputs"],
    )

    paths = {item["relative_path"] for item in capture["artifacts"]}
    assert paths == {"artifacts/report.md", "outputs/data.json"}
    assert "artifacts" in capture["captured_namespaces"]


def test_pack_uses_publish_visibility_policy_file(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-pack-policy"
    workspace.mkdir()
    write_workspace_file(workspace, "state/soul.json", '{"kind":"soul"}')
    write_workspace_file(workspace, "artifacts/report.md", "# artifact")

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("openclaw", str(workspace))
    service.capture("openclaw", str(workspace), artifact_paths=["artifacts/report.md"])
    snapshot = service.snapshot_create(str(workspace))

    visibility_path = workspace / ".anyfs" / "visibility.json"
    visibility_path.write_text(
        json.dumps(
            {
                "version": 1,
                "publish": {
                    "mode": "all-private",
                },
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    packed = service.pack(str(workspace), snapshot["snapshot_id"])
    assert packed["policy_source"] == "file"
    assert packed["visibility_mode"] == "all-private"
    assert packed["effective_visibility"]["artifacts"] == "private"
    assert packed["effective_visibility"]["trajectory"] == "private"

    with zipfile.ZipFile(packed["archive_path"], "r") as zf:
        names = set(zf.namelist())
        assert "afpkg/public/artifacts/artifacts.json" not in names
        assert "afpkg/private/trajectory/artifacts.json" in names
        policy = json.loads(zf.read("afpkg/policy.json").decode("utf-8"))
        assert policy["visibility"]["mode"] == "all-private"


def test_pack_cli_visibility_mode_overrides_policy_file(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-pack-cli-policy"
    workspace.mkdir()
    write_workspace_file(workspace, "state/soul.json", '{"kind":"soul"}')
    write_workspace_file(workspace, "artifacts/report.md", "# artifact")

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("openclaw", str(workspace))
    service.capture("openclaw", str(workspace), artifact_paths=["artifacts/report.md"])
    snapshot = service.snapshot_create(str(workspace), artifacts_public=False)

    visibility_path = workspace / ".anyfs" / "visibility.json"
    visibility_path.write_text(
        json.dumps(
            {
                "version": 1,
                "publish": {
                    "mode": "all-private",
                },
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    packed = service.pack(
        str(workspace),
        snapshot["snapshot_id"],
        visibility_mode="artifacts-public",
    )
    assert packed["policy_source"] == "merged"
    assert packed["visibility_mode"] == "artifacts-public"
    assert packed["effective_visibility"]["artifacts"] == "public"
    assert packed["effective_visibility"]["trajectory"] == "private"

    with zipfile.ZipFile(packed["archive_path"], "r") as zf:
        names = set(zf.namelist())
        assert "afpkg/public/artifacts/artifacts.json" in names
        assert "afpkg/private/trajectory/artifacts.json" not in names


def test_publish_rejects_visibility_mode_overrides_for_prebuilt_archive(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-publish-policy"
    workspace.mkdir()
    write_workspace_file(workspace, "state/soul.json", '{"kind":"soul"}')
    write_workspace_file(workspace, "artifacts/report.md", "# artifact")

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("openclaw", str(workspace))
    service.capture("openclaw", str(workspace), artifact_paths=["artifacts/report.md"])
    snapshot = service.snapshot_create(str(workspace))
    packed = service.pack(str(workspace), snapshot["snapshot_id"])

    try:
        service.publish(str(workspace), packed["archive_path"], visibility_mode="all-private")
    except ValueError as exc:
        assert "visibility overrides apply during pack" in str(exc)
    else:
        raise AssertionError("expected publish to reject visibility mode overrides for prebuilt archives")


def test_publish_requires_message(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-publish-message"
    workspace.mkdir()
    write_workspace_file(workspace, "AGENTS.md", "# codex guidance")

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("codex-cli", str(workspace))
    service.capture("codex-cli", str(workspace), client_scope="single")
    snapshot = service.snapshot_create(str(workspace))
    packed = service.pack(str(workspace), snapshot["snapshot_id"])

    try:
        service.publish(str(workspace), packed["archive_path"])
    except ValueError as exc:
        assert "publish message is required" in str(exc)
    else:
        raise AssertionError("expected publish to require a message")


def test_pack_supports_all_public_mode_and_install_restores_public_payloads(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-pack-all-public"
    workspace.mkdir()
    write_workspace_file(workspace, "state/soul.json", '{"kind":"soul"}')
    write_workspace_file(workspace, "artifacts/report.md", "# artifact")
    write_workspace_file(workspace, "README.md", "# workspace")

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("openclaw", str(workspace))
    service.capture("openclaw", str(workspace), workspace_mode="full", artifact_paths=["artifacts/report.md"])
    snapshot = service.snapshot_create(str(workspace))

    packed = service.pack(str(workspace), snapshot["snapshot_id"], visibility_mode="all-public")
    assert packed["visibility_mode"] == "all-public"
    assert packed["effective_visibility"]["artifacts"] == "public"
    assert packed["effective_visibility"]["trajectory"] == "public"
    assert packed["effective_visibility"]["workspace_overlay"] == "public"

    with zipfile.ZipFile(packed["archive_path"], "r") as zf:
        names = set(zf.namelist())
        assert "afpkg/public/artifacts/artifacts.json" in names
        assert "afpkg/public/trajectory/soul.json" not in names
        assert "afpkg/public/workspace_overlay.json" in names
        assert "afpkg/private/trajectory/soul.json" not in names

    installed = service.install_package(str(workspace), archive_path=packed["archive_path"])
    assert "soul" not in installed["files"]
    assert "workspace_overlay" in installed["files"]
    assert Path(installed["files"]["workspace_restore_dir"]).exists()


def test_api_exposes_public_package_contents_for_all_public_packages(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-public-package"
    workspace.mkdir()
    write_workspace_file(workspace, "state/soul.json", '{"kind":"soul"}')
    write_workspace_file(workspace, "README.md", "# workspace")

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("openclaw", str(workspace))
    service.capture("openclaw", str(workspace), workspace_mode="full", artifact_paths=["artifacts/report.md"])
    snapshot = service.snapshot_create(str(workspace))
    packed = service.pack(str(workspace), snapshot["snapshot_id"], visibility_mode="all-public")

    with build_api_client(tmp_path, monkeypatch) as client:
        import anyfs_api.main as api_main

        asyncio.run(
            api_main.store.create_commit(
                "package",
                packed["package"]["package_id"],
                "cid-demo",
                {"path": packed["archive_path"]},
            )
        )
        asyncio.run(api_main.store.put("packages", packed["package"]["package_id"], packed["package"]))

        response = client.get(f"/packages/{packed['package']['package_id']}/public-contents")
        assert response.status_code == 200
        payload = response.json()
        assert payload["package_id"] == packed["package"]["package_id"]
        assert payload["visibility_mode"] == "all-public"
        assert "soul" not in payload["trajectory"]
        assert payload["workspace_overlay"]["mode"] == "full"
        assert payload["workspace_overlay"]["archive_name"].endswith(".zip")


def test_pack_publish_filters_out_personal_agents_and_noncanonical_process_items(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-publish-filter"
    workspace.mkdir()

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("codex-cli", str(workspace))

    capture_payload = {
        "agent_id": "agt_demo",
        "agent_type": "codex-cli",
        "workspace": str(workspace),
        "captured_agent_types": ["codex-cli", "claude-code", "openclaw", "hermes"],
        "code_ref": {
            "provider": "github",
            "repo_url": "git@github.com:demo/repo.git",
            "default_branch": None,
            "commit_sha": None,
            "subdir": None,
        },
        "workspace_overlay": {
            "mode": "none",
            "captured_at": "2026-04-12T00:00:00+00:00",
            "binding": {
                "cwd": str(workspace),
                "repo_root": None,
                "branch": None,
                "commit_sha": None,
                "remote": None,
                "dirty": False,
                "status_summary": [],
            },
        },
        "trajectory": {
            "process": [
                {
                    "relative_path": "process/codex/demo.jsonl",
                    "namespace": "process",
                    "content": "# Session: c1",
                    "canonical_transcript": {"session": {"id": "c1", "agent": "codex-cli"}, "events": []},
                },
                {
                    "relative_path": "process/openclaw/demo.jsonl",
                    "namespace": "process",
                    "content": "# Session: o1",
                    "canonical_transcript": {"session": {"id": "o1", "agent": "openclaw"}, "events": []},
                },
                {
                    "relative_path": "apps/web/components/login-form.tsx",
                    "namespace": "process",
                    "content": "export function LoginForm() {}",
                },
            ],
            "skills": [
                {"relative_path": ".claude/commands/review.md", "namespace": "skills", "content": "# review"},
                {"relative_path": "skills/openclaw/global/agent/SKILL.md", "namespace": "skills", "content": "# openclaw"},
                {"relative_path": ".agents/skills/demo/SKILL.md", "namespace": "skills", "content": "# demo"},
            ],
            "soul": [{"relative_path": "SOUL.md", "namespace": "soul", "content": "# soul"}],
            "memory": [{"relative_path": "memory/MEMORY.md", "namespace": "memory", "content": "# memory"}],
        },
        "artifacts": [],
        "trajectory_components": ["process", "skills", "soul", "memory"],
        "captured_namespaces": ["process", "skills", "soul", "memory"],
        "payloads": {},
        "warnings": [],
    }
    record_capture(str(workspace), capture_payload)
    snapshot = service.snapshot_create(str(workspace))
    packed = service.pack(str(workspace), snapshot["snapshot_id"], visibility_mode="all-public")

    assert packed["package"]["trajectory"]["counts"] == {"process": 1, "skills": 2}

    with zipfile.ZipFile(packed["archive_path"], "r") as zf:
        process_payload = json.loads(zf.read("afpkg/public/trajectory/process.json"))
        skill_payload = json.loads(zf.read("afpkg/public/trajectory/skills.json"))
        assert [item["relative_path"] for item in process_payload] == ["process/codex/demo.jsonl"]
        assert {item["relative_path"] for item in skill_payload} == {
            ".claude/commands/review.md",
            ".agents/skills/demo/SKILL.md",
        }


def test_migrate_context_supports_dry_run_and_import_report(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    source_workspace = tmp_path / "workspace-source"
    target_workspace = tmp_path / "workspace-target"
    source_workspace.mkdir()
    write_workspace_file(source_workspace, "AGENTS.md", "# codex guidance")
    home = tmp_path / "home"
    write_workspace_file(home, ".codex/skills/demo/SKILL.md", "# demo skill")
    write_codex_session(home, source_workspace)
    monkeypatch.setenv("HOME", str(home))

    service = AnyFSService(global_root=global_root)
    service.init()

    dry_run = service.migrate_context(
        "codex-cli",
        "gemini-cli",
        str(source_workspace),
        target_workspace=str(target_workspace),
        dry_run=True,
    )
    assert dry_run["dry_run"] is True
    assert any(item.startswith("native-resume:gemini-cli:") for item in dry_run["planned_items"])
    assert dry_run["applied_files"] == []

    applied = service.migrate_context(
        "codex-cli",
        "gemini-cli",
        str(source_workspace),
        target_workspace=str(target_workspace),
    )
    imported_root = Path(applied["import_root"])
    assert imported_root.exists()
    assert (imported_root / "skills" / "codex" / "global" / "skills" / "demo" / "SKILL.md").exists()
    assert (target_workspace / "GEMINI.md").exists()
    guidance = (target_workspace / "GEMINI.md").read_text(encoding="utf-8")
    assert "codex guidance" in guidance
    assert "Imported AnyFS Context" in guidance
    assert applied["resume_sessions"]
    assert applied["resume_sessions"][0]["resume_hint"].startswith("gemini --resume ")


def test_migrate_context_projects_personal_agent_files_into_hermes(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    source_workspace = tmp_path / "workspace-nanobot"
    target_workspace = tmp_path / "workspace-hermes-target"
    hermes_home = tmp_path / "hermes-home"
    source_workspace.mkdir()

    write_workspace_file(source_workspace, "SOUL.md", "# Nanobot Soul")
    write_workspace_file(source_workspace, "USER.md", "# User Profile")
    write_workspace_file(source_workspace, "AGENTS.md", "# Project Guidance")
    write_workspace_file(source_workspace, "HEARTBEAT.md", "- [ ] nightly digest")
    write_workspace_file(source_workspace, "memory/MEMORY.md", "# Durable Memory")
    write_workspace_file(source_workspace, "skills/demo/SKILL.md", "# Demo Skill")
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))

    service = AnyFSService(global_root=global_root)
    service.init()

    report = service.migrate_context(
        "nanobot",
        "hermes",
        str(source_workspace),
        target_workspace=str(target_workspace),
    )

    assert (hermes_home / "SOUL.md").exists()
    assert (hermes_home / "memories" / "USER.md").exists()
    assert (hermes_home / "memories" / "MEMORY.md").exists()
    assert (hermes_home / "skills" / "anyfs-imports" / "nanobot" / "demo" / "SKILL.md").exists()
    assert (target_workspace / "AGENTS.md").exists()
    assert "Project Guidance" in (target_workspace / "AGENTS.md").read_text(encoding="utf-8")
    assert not report["resume_sessions"]


def test_migrate_context_supports_native_resume_for_nanobot_target(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    source_workspace = tmp_path / "workspace-source"
    target_workspace = tmp_path / "workspace-target"
    source_workspace.mkdir()
    write_workspace_file(source_workspace, "AGENTS.md", "# codex guidance")
    home = tmp_path / "home"
    write_workspace_file(home, ".codex/skills/demo/SKILL.md", "# demo skill")
    write_codex_session(home, source_workspace)
    monkeypatch.setenv("HOME", str(home))

    service = AnyFSService(global_root=global_root)
    service.init()

    dry_run = service.migrate_context(
        "codex-cli",
        "nanobot",
        str(source_workspace),
        target_workspace=str(target_workspace),
        dry_run=True,
    )
    assert any(item.startswith("native-resume:nanobot:") for item in dry_run["planned_items"])

    report = service.migrate_context(
        "codex-cli",
        "nanobot",
        str(source_workspace),
        target_workspace=str(target_workspace),
    )
    assert report["resume_sessions"]
    session = report["resume_sessions"][0]
    transcript_path = Path(session["files_written"]["transcript"])
    assert transcript_path.exists()
    assert session["resume_hint"].startswith("nanobot agent --session ")


def test_migrate_context_supports_full_preset_and_include_secrets(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    source_workspace = tmp_path / "workspace-source"
    target_workspace = tmp_path / "workspace-target"
    hermes_home = tmp_path / "hermes-home"
    source_workspace.mkdir()
    target_workspace.mkdir()

    write_workspace_file(source_workspace, "AGENTS.md", "# source guidance")
    write_workspace_file(hermes_home, "config.yaml", "model: test\nopenai_api_key: sk-local\n")
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))
    monkeypatch.setenv("OPENAI_API_KEY", "sk-env-secret")

    service = AnyFSService(global_root=global_root)
    service.init()

    dry_run = service.migrate_context(
        "hermes",
        "nanobot",
        str(source_workspace),
        target_workspace=str(target_workspace),
        preset="full",
        dry_run=True,
    )
    assert dry_run["preset"] == "full"
    assert dry_run["include_secrets"] is False
    assert dry_run["redacted_items"] == [str(hermes_home / "config.yaml")]
    assert dry_run["secret_items"] == []

    report = service.migrate_context(
        "hermes",
        "nanobot",
        str(source_workspace),
        target_workspace=str(target_workspace),
        preset="full",
        include_secrets=True,
    )
    import_root = Path(report["import_root"])
    runtime_config = import_root / "runtime-config" / "hermes" / "config.yaml"
    secret_bundle = import_root / "runtime-config" / "hermes" / "secrets.env.json"
    assert runtime_config.exists()
    assert "sk-local" in runtime_config.read_text(encoding="utf-8")
    assert secret_bundle.exists()
    assert json.loads(secret_bundle.read_text(encoding="utf-8"))["OPENAI_API_KEY"] == "sk-env-secret"
    assert "OPENAI_API_KEY" in report["secret_items"]


def test_open_shared_supports_share_url(tmp_path: Path, monkeypatch) -> None:
    global_root = tmp_path / "global"
    service = AnyFSService(global_root=global_root)
    service.init()

    root_key = service._root_key()
    payload = [{"canonical_transcript": {"session": {"id": "s1", "agent": "claude-code"}, "events": []}}]
    share_envelope = rewrap_dek_for_share(
        root_key,
        encrypt_json_payload(root_key, payload, "process"),
        "SharedPass123",
    )

    class _Response:
        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict:
            return share_envelope

    def fake_get(self, url: str):
        assert url == "https://storage.anyfs.ai/raw/demo"
        return _Response()

    monkeypatch.setattr("httpx.Client.get", fake_get)

    opened = service.open_shared("https://storage.anyfs.ai/raw/demo", "SharedPass123", str(tmp_path / "opened"))
    opened_payload = json.loads(Path(opened["output_file"]).read_text(encoding="utf-8"))

    assert opened["namespace"] == "process"
    assert opened["share_source"] == "https://storage.anyfs.ai/raw/demo"
    assert opened_payload == payload


def test_quick_share_includes_workspace_and_message(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-share"
    workspace.mkdir()
    write_workspace_file(workspace, "CLAUDE.md", "# guidance")
    write_workspace_file(workspace, "src/app.py", "print('hello')\n")
    write_workspace_file(workspace, "README.md", "# demo\n")

    service = AnyFSService(global_root=global_root)
    service.init()

    result = service.quick_share(
        str(workspace),
        namespaces=["skills", "workspace"],
        share_password="SharePass123",
        agent_type="claude-code",
        message="Restore the workspace and continue from src/app.py",
        workspace_mode="changed",
    )

    assert result["message"] == "Restore the workspace and continue from src/app.py"
    assert result["workspace_mode"] == "changed"
    assert "--type <your-current-client>" in result["handoff_text"]
    assert "anyfs register --type <your-current-client> <display-name>" in result["handoff_text"]
    assert "register first:" in result["handoff_text"]
    workspace_share = Path(result["shares"]["workspace"]["share_file"])
    assert workspace_share.exists()

    opened = service.open_shared(str(workspace_share), "SharePass123", str(tmp_path / "opened"))
    restored_app = Path(opened["restore_dir"]) / "src" / "app.py"
    restored_readme = Path(opened["restore_dir"]) / "README.md"

    assert opened["namespace"] == "workspace"
    assert opened["message"] == "Restore the workspace and continue from src/app.py"
    assert restored_app.read_text(encoding="utf-8") == "print('hello')\n"
    assert restored_readme.read_text(encoding="utf-8") == "# demo\n"


def test_register_agent_writes_global_identity_only(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-global-agent"
    workspace.mkdir()

    service = AnyFSService(global_root=global_root)
    service.init()
    agent = service.register_agent("codex-cli", str(workspace), "codex-main")

    assert (global_root / "agents" / "codex-cli.json").exists()
    assert (global_root / "agents" / "codex-cli.key").exists()
    assert not (workspace / ".anyfs" / "agent.json").exists()
    stored = json.loads((global_root / "agents" / "codex-cli.json").read_text(encoding="utf-8"))
    assert stored["agent_id"] == agent["agent_id"]


def test_quick_share_defaults_exclude_soul_and_memory(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-default-share"
    workspace.mkdir()
    write_workspace_file(workspace, "state/soul.json", '{"kind":"soul"}')
    write_workspace_file(workspace, "memory/MEMORY.md", "# memory")
    write_workspace_file(workspace, "AGENTS.md", "# skills")

    service = AnyFSService(global_root=global_root)
    service.init()
    service.register_agent("openclaw", str(workspace))

    result = service.quick_share(
        str(workspace),
        share_password="SharePass123",
        agent_type="openclaw",
        message="share current workspace context",
        workspace_mode="none",
    )

    assert "soul" not in result["shares"]
    assert "memory" not in result["shares"]


def test_full_workspace_overlay_uses_archive_and_restores(tmp_path: Path) -> None:
    global_root = tmp_path / "global"
    workspace = tmp_path / "workspace-full-overlay"
    workspace.mkdir()
    write_workspace_file(workspace, "src/app.py", "print('hello')\n")
    write_workspace_file(workspace, "docs/readme.md", "# readme\n")

    service = AnyFSService(global_root=global_root)
    service.init()
    overlay = service._build_workspace_bundle(str(workspace), "full")

    assert overlay["mode"] == "full"
    assert overlay["archive_name"].endswith(".zip")
    assert overlay["archive_encoding"] == "base64"
    assert overlay["archive_content"]
    assert overlay["archive_file_count"] >= 2
    assert overlay["files"] == []

    restored = service._restore_workspace_bundle(overlay, tmp_path / "restored")
    restore_dir = Path(restored["restore_dir"])
    assert (restore_dir / "src" / "app.py").read_text(encoding="utf-8") == "print('hello')\n"
    assert (restore_dir / "docs" / "readme.md").read_text(encoding="utf-8") == "# readme\n"


def test_standalone_agent_then_user_binding_flow(tmp_path: Path, monkeypatch) -> None:
    with build_api_client(tmp_path, monkeypatch) as api_client:
        global_root = tmp_path / "global"
        workspace = tmp_path / "workspace-claude"
        workspace.mkdir()
        write_workspace_file(workspace, "CLAUDE.md", "system guidance")
        write_workspace_file(workspace, "memory/session.md", "memory block")
        write_workspace_file(workspace, "process/log.txt", "process block")
        write_workspace_file(workspace, "artifacts/output.md", "artifact")

        service = AnyFSService(global_root=global_root, api_client=api_client)
        run_skill_action("anyfs.init", {}, service)
        local_agent = run_skill_action(
            "anyfs.register_agent",
            {"agent_type": "claude-code", "workspace": str(workspace)},
            service,
        )
        remote_agent = run_skill_action("anyfs.agent_create_remote", {"workspace": str(workspace)}, service)
        assert remote_agent["agent"]["agent_id"] == local_agent["agent_id"]

        status = run_skill_action("anyfs.agent_status", {"workspace": str(workspace)}, service)
        assert status["remote"]["status"] == "unclaimed"
        assert status["remote"]["auth_mode"] == "standalone"

        capture = run_skill_action(
            "anyfs.capture",
            {"agent_type": "claude-code", "workspace": str(workspace)},
            service,
        )
        assert "memory" in capture["captured_namespaces"]

        snapshot = run_skill_action("anyfs.snapshot_create", {"workspace": str(workspace)}, service)
        backup = run_skill_action(
            "anyfs.backup_create",
            {"workspace": str(workspace), "snapshot": snapshot["snapshot_id"], "namespaces": ["memory"]},
            service,
        )
        assert backup["created_by_agent_id"] == local_agent["agent_id"]
        assert backup["owner_user_id"] is None

        link = run_skill_action(
            "anyfs.share_link",
            {"workspace": str(workspace), "snapshot": "latest", "namespaces": ["memory", "process"]},
            service,
        )
        assert link["created_by_agent_id"] == local_agent["agent_id"]
        assert link["owner_user_id"] is None

        packed = service.pack(str(workspace), snapshot["snapshot_id"])
        with pytest.raises(ValueError, match="publish requires a registered user account bound to this agent"):
            service.publish(str(workspace), packed["archive_path"])

        # User joins later and the standalone agent binds directly by email + password.
        register = api_client.post(
            "/auth/register",
            json={"email": "demo@example.com", "password": "hunter2password"},
        )
        assert register.status_code == 200
        user_auth = run_skill_action(
            "anyfs.auth_login",
            {"email": "demo@example.com", "password": "hunter2password"},
            service,
        )
        user_token = user_auth["token"]
        bound = run_skill_action(
            "anyfs.agent_bind",
            {"workspace": str(workspace), "email": "demo@example.com", "password": "hunter2password"},
            service,
        )
        assert bound["agent"]["status"] == "claimed"
        assert bound["agent"]["auth_mode"] == "bound"

        status_after_bind = run_skill_action("anyfs.agent_status", {"workspace": str(workspace)}, service)
        assert status_after_bind["remote"]["owner_user_id"] is not None

        published = service.publish(str(workspace), packed["archive_path"], message="demo package")
        assert len(published["cid"]) == 64
        release = service.release_create(str(workspace), packed["package"]["package_id"], "v0.1.0")
        assert release["version"] == "v0.1.0"

        # Existing standalone objects should auto-attach to the user after claim.
        my_agents = api_client.get("/my/agents", headers={"Authorization": f"Bearer {user_token}"})
        assert my_agents.status_code == 200
        assert len(my_agents.json()) == 1

        my_backups = api_client.get("/my/backups", headers={"Authorization": f"Bearer {user_token}"})
        assert my_backups.status_code == 200
        assert len(my_backups.json()) == 1
        assert my_backups.json()[0]["backup_id"] == backup["backup_id"]

        my_links = api_client.get("/my/links", headers={"Authorization": f"Bearer {user_token}"})
        assert my_links.status_code == 200
        assert len(my_links.json()) == 1
        assert my_links.json()[0]["link_id"] == link["link_id"]

        my_packages = api_client.get("/my/packages", headers={"Authorization": f"Bearer {user_token}"})
        assert my_packages.status_code == 200
        assert len(my_packages.json()) == 1
        assert my_packages.json()[0]["package_id"] == packed["package"]["package_id"]

        # New objects created after binding inherit the user owner automatically.
        second_backup = run_skill_action(
            "anyfs.backup_create",
            {"workspace": str(workspace), "snapshot": "latest", "namespaces": ["memory", "process"]},
            service,
        )
        assert second_backup["owner_user_id"] == my_agents.json()[0]["owner_user_id"]

        forked = service.fork(str(workspace), packed["package"]["package_id"], "child-package")
        assert forked["child_package"]["owner_user_id"] == my_agents.json()[0]["owner_user_id"]
        assert service.lineage_show(str(workspace), packed["package"]["package_id"])["items"]

        # Private records are readable by the bound owner and by the originating agent token.
        private_backup_as_user = api_client.get(
            f"/backups/{backup['backup_id']}",
            headers={"Authorization": f"Bearer {user_token}"},
        )
        assert private_backup_as_user.status_code == 200

        local_links = service.list_links(str(workspace))
        assert len(local_links) == 1
        local_backups = service.list_backups(str(workspace))
        assert len(local_backups) == 2

        metadata = json.loads((Path(global_root) / "config.json").read_text(encoding="utf-8"))
        assert metadata["auth_email"] == "demo@example.com"
        assert metadata.get("agent_token_agent_id") in (None, local_agent["agent_id"])

        unbind = api_client.delete(
            f"/agent-bindings/{local_agent['agent_id']}",
            headers={"Authorization": f"Bearer {user_token}"},
        )
        assert unbind.status_code == 200

        my_agents_after_unbind = api_client.get("/my/agents", headers={"Authorization": f"Bearer {user_token}"})
        assert my_agents_after_unbind.status_code == 200
        assert my_agents_after_unbind.json() == []

        status_after_unbind = run_skill_action("anyfs.agent_status", {"workspace": str(workspace)}, service)
        assert status_after_unbind["remote"]["status"] == "unclaimed"
        assert status_after_unbind["remote"]["auth_mode"] == "standalone"


def test_auth_register_and_login_requires_password(tmp_path: Path, monkeypatch) -> None:
    with build_api_client(tmp_path, monkeypatch) as api_client:
        registered = api_client.post(
            "/auth/register",
            json={"email": "person@example.com", "password": "supersecret123"},
        )
        assert registered.status_code == 200
        payload = registered.json()
        assert payload["user"]["email"] == "person@example.com"
        assert "token" in payload

        duplicate = api_client.post(
            "/auth/register",
            json={"email": "person@example.com", "password": "supersecret123"},
        )
        assert duplicate.status_code == 409

        bad_login = api_client.post(
            "/auth/login",
            json={"email": "person@example.com", "password": "wrong-password"},
        )
        assert bad_login.status_code == 401

        logged_in = api_client.post(
            "/auth/login",
            json={"email": "person@example.com", "password": "supersecret123"},
        )
        assert logged_in.status_code == 200
        token = logged_in.json()["token"]

        me = api_client.get("/auth/me", headers={"Authorization": f"Bearer {token}"})
        assert me.status_code == 200
        assert me.json()["user"]["email"] == "person@example.com"


def test_buy_installs_package_and_can_resume(tmp_path: Path, monkeypatch) -> None:
    with build_api_client(tmp_path, monkeypatch) as api_client:
        global_root = tmp_path / "global"
        workspace = tmp_path / "workspace-buy"
        workspace.mkdir()
        home = tmp_path / "home"
        write_workspace_file(workspace, "AGENTS.md", "# codex agents")
        write_workspace_file(home, ".codex/skills/demo/SKILL.md", "# skill")
        write_codex_session(home, workspace)
        monkeypatch.setenv("HOME", str(home))

        service = AnyFSService(global_root=global_root, api_client=api_client)
        service.init()
        service.register_agent("codex-cli", str(workspace))
        service.agent_create_remote(str(workspace))
        service.capture("codex-cli", str(workspace))
        snapshot = service.snapshot_create(str(workspace))
        packed = service.pack(str(workspace), snapshot["snapshot_id"])
        published = service.publish(str(workspace), packed["archive_path"])

        storage = service.package_storage(packed["package"]["package_id"])
        assert storage["resource_id"] == packed["package"]["package_id"]
        assert storage["metadata"]["path"] == packed["archive_path"]

        bought = service.buy(
            str(workspace),
            packed["package"]["package_id"],
            "child-package",
            resume_target="codex-cli",
        )
        assert bought["fork"]["child_package"]["package_id"].startswith("pkg_")
        assert Path(bought["install"]["archive_path"]).exists()
        assert "process" in bought["install"]["files"]
        assert bought["resume"]["sessions"]
        assert bought["resume"]["sessions"][0]["resume_hint"].startswith("codex resume ")
