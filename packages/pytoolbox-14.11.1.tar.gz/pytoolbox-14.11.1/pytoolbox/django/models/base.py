"""
Abstract models for building your own models.
"""
# pylint: disable=too-few-public-methods

from __future__ import annotations

from django.db import models

from . import fields

__all__ = ['Timestamped']


class Timestamped(models.Model):
    """Abstract model with auto-managed ``created_at`` and ``updated_at`` fields."""

    class Meta:
        """Default ordering by creation and update timestamps."""

        abstract = True
        get_latest_by = 'created_at'
        ordering = ('created_at', 'updated_at')

    created_at = fields.CreatedAtField()
    updated_at = fields.UpdatedAtField()
