# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["RunRetrieveResponse", "GeneratedFile", "RuntimeParams"]


class GeneratedFile(BaseModel):
    """A generated file from a run"""

    id: Optional[str] = None
    """File identifier for download"""

    file_type: Optional[str] = None
    """MIME type of the file"""

    path: Optional[str] = None
    """File path within the run output"""

    size_bytes: Optional[int] = None
    """File size in bytes"""


class RuntimeParams(BaseModel):
    """Generation parameters used for the run"""

    filtering_types: Optional[List[str]] = None
    """Filtering types that were applied"""

    generation_model: Optional[str] = None
    """Model used for generation"""

    generation_thinking_budget: Optional[int] = None
    """Thinking budget used for generation model (null if not a thinking model)"""

    max_examples_in_prompt: Optional[int] = None
    """Max examples in prompt (null if not set)"""

    max_revision_cycles: Optional[int] = None
    """Max revision cycles (null if revisions disabled)"""

    number_of_samples: Optional[int] = None
    """Number of samples requested"""

    outline_model: Optional[str] = None
    """Model used for outline generation"""

    outline_thinking_budget: Optional[int] = None
    """Thinking budget used for outline model (null if not a thinking model)"""

    revision_model: Optional[str] = None
    """Model used for revisions (null if revisions disabled)"""

    revision_thinking_budget: Optional[int] = None
    """Thinking budget used for revision model (null if not a thinking model)"""

    revision_types: Optional[List[str]] = None
    """Revision types that were applied"""

    seed_shuffling_level: Optional[Literal["none", "sample", "field", "prompt"]] = None
    """Seed shuffling level used"""

    skip_outline: Optional[bool] = None
    """Whether outline and part-by-part generation was skipped"""

    tools: Optional[List[str]] = None
    """Tools that were available to the LLM during generation"""

    unified_multifield: Optional[bool] = None
    """Whether unified multifield generation was used"""


class RunRetrieveResponse(BaseModel):
    """Detailed run information"""

    id: Optional[str] = None
    """Unique identifier for the run"""

    completed_at: Optional[datetime] = None
    """When the run completed (null if not finished)"""

    created_at: Optional[datetime] = None
    """When the run was created"""

    created_by_email: Optional[str] = None
    """Email of the user who created the run"""

    dataset_id: Optional[str] = None
    """ID of the seed dataset (null for seedless specs)"""

    dataset_name: Optional[str] = None
    """Name of the seed dataset (null for seedless specs)"""

    dataset_type: Optional[Literal["SINGLE_FILE", "MULTI_FILE", "MULTI_FOLDER"]] = None
    """Type of dataset"""

    generated_files: Optional[List[GeneratedFile]] = None
    """List of generated files (populated when run completes)"""

    runtime_params: Optional[RuntimeParams] = None
    """Generation parameters used for the run"""

    samples_completed: Optional[int] = None
    """Number of samples successfully generated"""

    samples_failed: Optional[int] = None
    """Number of samples that failed to generate"""

    spec_id: Optional[str] = None
    """ID of the spec used"""

    spec_name: Optional[str] = None
    """Name of the spec"""

    spec_version: Optional[int] = None
    """Version number of the spec used"""

    status: Optional[Literal["PENDING", "PROCESSING", "SUCCEEDED", "FAILED", "CANCELED"]] = None
    """Current status of the run"""

    total_cost: Optional[float] = None
    """Total cost of the run in dollars"""
