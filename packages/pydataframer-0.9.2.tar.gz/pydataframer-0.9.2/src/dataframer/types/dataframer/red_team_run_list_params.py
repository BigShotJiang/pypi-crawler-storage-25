# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["RedTeamRunListParams"]


class RedTeamRunListParams(TypedDict, total=False):
    spec_id: str
    """Filter runs by red team spec ID"""
