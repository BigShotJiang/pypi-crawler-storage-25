# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["AnonymizationRunCreateResponse", "AnonymizedFile", "Results", "ResultsEntitiesFound"]


class AnonymizedFile(BaseModel):
    id: Optional[str] = None
    """File ID. Pass this as `file_id` to the download-file endpoint."""

    content_type: Optional[str] = None
    """MIME type of the file."""

    path: Optional[str] = None
    """Original file path/name."""

    size_in_bytes: Optional[int] = None
    """Size of the anonymized file content in bytes."""


class ResultsEntitiesFound(BaseModel):
    end: Optional[int] = None

    label: Optional[str] = None

    score: Optional[float] = None

    start: Optional[int] = None


class Results(BaseModel):
    """Anonymization results once the run completes."""

    entities_found: Optional[List[ResultsEntitiesFound]] = None
    """Flat list of all entities detected across all samples."""

    entity_summary: Optional[object] = None
    """Aggregated entity counts by type across all samples."""

    error: Optional[str] = None
    """Error message if the run failed."""

    samples_processed: Optional[int] = None
    """Total number of samples processed."""


class AnonymizationRunCreateResponse(BaseModel):
    """A PII/PHI anonymization run."""

    id: Optional[str] = None
    """Unique identifier for the anonymization run."""

    anonymized_files: Optional[List[AnonymizedFile]] = None
    """List of anonymized output files produced by the run."""

    completed_at: Optional[datetime] = None
    """When the run completed (succeeded or failed)."""

    created_at: Optional[datetime] = None
    """When the run was created."""

    created_by_email: Optional[str] = None
    """Email of the user who created this run."""

    dataset_id: Optional[str] = None
    """UUID of the seed dataset being anonymized."""

    dataset_name: Optional[str] = None
    """Name of the seed dataset."""

    detection_method: Optional[str] = None
    """Entity detection method used."""

    duration_seconds: Optional[int] = None
    """Time taken to complete the run in seconds. Null until completed."""

    llm_model_name: Optional[str] = None
    """LLM model name (when detection_method includes `llm`)."""

    pii_types: Optional[List[str]] = None
    """List of PII/PHI entity types being detected."""

    results: Optional[Results] = None
    """Anonymization results once the run completes."""

    status: Optional[Literal["PENDING", "PROCESSING", "SUCCEEDED", "FAILED"]] = None
    """Current status of the anonymization run."""
