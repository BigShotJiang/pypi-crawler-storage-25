# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List
from typing_extensions import Literal, Required, TypedDict

from ..._types import SequenceNotStr

__all__ = ["RunCreateParams"]


class RunCreateParams(TypedDict, total=False):
    number_of_samples: Required[int]
    """Number of samples to generate"""

    spec_id: Required[str]
    """ID of the spec to use for generation. Spec must be in SUCCEEDED status."""

    databricks_api_base: str
    """Databricks Model Serving endpoint URL (e.g.

    https://adb-xxx.azuredatabricks.net/serving-endpoints). Required when using
    databricks/models.
    """

    databricks_client_id: str
    """Databricks service principal application (client) ID.

    Required when using databricks/models.
    """

    databricks_client_secret: str
    """Databricks service principal secret. Required when using databricks/models."""

    enable_revisions: bool
    """Use revision_types and filtering_types instead.

    When set to true without those fields, enables all revision types and structural
    filtering.
    """

    filtering_types: List[Literal["structural", "conformance"]]
    """List of filtering quality gates.

    Valid values: 'structural' (reject severe format issues), 'conformance' (reject
    property violations). Documents that fail are regenerated. Defaults to empty (no
    filtering).
    """

    generation_model: Literal[
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-6-thinking",
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-sonnet-4-6-thinking",
        "anthropic/claude-haiku-4-5",
        "anthropic/claude-haiku-4-5-thinking",
        "gemini/gemini-3.1-pro-preview",
        "gemini/gemini-3.1-pro-preview-thinking",
        "openai/gpt-oss-120b",
        "deepseek-ai/DeepSeek-V3.1",
        "moonshotai/Kimi-K2-Instruct",
        "deepseek-ai/DeepSeek-R1-0528-tput",
        "openai/gpt-5.4",
        "openai/gpt-5.4-thinking",
        "databricks/databricks-claude-haiku-4-5",
        "databricks/databricks-claude-haiku-4-5-thinking",
        "databricks/databricks-claude-opus-4-6",
        "databricks/databricks-claude-opus-4-6-thinking",
        "databricks/databricks-claude-sonnet-4-6",
        "databricks/databricks-claude-sonnet-4-6-thinking",
        "databricks/databricks-gemini-3-1-pro",
        "databricks/databricks-gemini-3-1-pro-thinking",
        "databricks/databricks-gpt-5-4",
        "databricks/databricks-gpt-5-4-thinking",
    ]
    """Model for generation.

    Use -thinking suffix to enable thinking mode. For databricks/ models, you must
    also provide databricks_client_id, databricks_client_secret, and
    databricks_api_base.
    """

    generation_thinking_budget: int
    """Token budget for extended thinking during generation.

    Only applies to models with -thinking suffix.
    """

    max_examples_in_prompt: int
    """(advanced) Maximum number of seed examples to include in prompts.

    By default, only as many seeds as fit in 10K tokens are used. Use this to
    override the default.
    """

    max_revision_cycles: int
    """Maximum number of revision cycles.

    2-3 is a solid pick for complex documents requiring internal consistency, e.g.
    financial reports, invoices, etc.; increase to 3-5 for highest quality or when
    generated data has issues.
    """

    outline_model: Literal[
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-6-thinking",
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-sonnet-4-6-thinking",
        "anthropic/claude-haiku-4-5",
        "anthropic/claude-haiku-4-5-thinking",
        "gemini/gemini-3.1-pro-preview",
        "gemini/gemini-3.1-pro-preview-thinking",
        "openai/gpt-oss-120b",
        "deepseek-ai/DeepSeek-V3.1",
        "moonshotai/Kimi-K2-Instruct",
        "deepseek-ai/DeepSeek-R1-0528-tput",
        "openai/gpt-5.4",
        "openai/gpt-5.4-thinking",
        "databricks/databricks-claude-haiku-4-5",
        "databricks/databricks-claude-haiku-4-5-thinking",
        "databricks/databricks-claude-opus-4-6",
        "databricks/databricks-claude-opus-4-6-thinking",
        "databricks/databricks-claude-sonnet-4-6",
        "databricks/databricks-claude-sonnet-4-6-thinking",
        "databricks/databricks-gemini-3-1-pro",
        "databricks/databricks-gemini-3-1-pro-thinking",
        "databricks/databricks-gpt-5-4",
        "databricks/databricks-gpt-5-4-thinking",
    ]
    """Model for outline generation"""

    outline_thinking_budget: int
    """Token budget for extended thinking during outline generation.

    Only applies to models with -thinking suffix.
    """

    revision_model: Literal[
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-6-thinking",
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-sonnet-4-6-thinking",
        "anthropic/claude-haiku-4-5",
        "anthropic/claude-haiku-4-5-thinking",
        "gemini/gemini-3.1-pro-preview",
        "gemini/gemini-3.1-pro-preview-thinking",
        "openai/gpt-oss-120b",
        "deepseek-ai/DeepSeek-V3.1",
        "moonshotai/Kimi-K2-Instruct",
        "deepseek-ai/DeepSeek-R1-0528-tput",
        "openai/gpt-5.4",
        "openai/gpt-5.4-thinking",
        "databricks/databricks-claude-haiku-4-5",
        "databricks/databricks-claude-haiku-4-5-thinking",
        "databricks/databricks-claude-opus-4-6",
        "databricks/databricks-claude-opus-4-6-thinking",
        "databricks/databricks-claude-sonnet-4-6",
        "databricks/databricks-claude-sonnet-4-6-thinking",
        "databricks/databricks-gemini-3-1-pro",
        "databricks/databricks-gemini-3-1-pro-thinking",
        "databricks/databricks-gpt-5-4",
        "databricks/databricks-gpt-5-4-thinking",
    ]
    """
    Model for revisions and filtering (only used if revision_types or
    filtering_types is set)
    """

    revision_thinking_budget: int
    """Token budget for extended thinking during revisions.

    Only applies to models with -thinking suffix.
    """

    revision_types: List[Literal["coherence_flow", "consistency", "distinguishability", "conformance"]]
    """List of revision types to apply.

    Valid values: 'coherence_flow' (fix formatting/flow issues), 'consistency' (fix
    internal contradictions), 'distinguishability' (seeded only — blend with seed
    style), 'conformance' (verify property compliance). Defaults to empty (no
    revisions).
    """

    seed_shuffling_level: Literal["none", "sample", "field", "prompt"]
    """(advanced) How to shuffle seed examples between samples"""

    skip_outline: bool
    """Skip outline and part-by-part generation.

    Generates a document draft directly in a single call. Faster and cheaper but not
    suitable for very long documents.
    """

    spec_version: int
    """Version number to use (optional, defaults to latest)"""

    tools: SequenceNotStr[str]
    """List of tools available to the LLM during generation.

    Currently supported: 'calculator' (sandboxed Python for numerical verification).
    Roughly doubles cost and time. Defaults to empty.
    """

    unified_multifield: bool
    """(advanced) Use unified multifield generation.

    This helps to reduce the generation cost by processing all fields together
    rather than one by one.
    """
