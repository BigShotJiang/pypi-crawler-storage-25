# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from ..._models import BaseModel

__all__ = ["AnonymizationRunListResponse", "AnonymizationRunListResponseItem"]


class AnonymizationRunListResponseItem(BaseModel):
    """Summarised view of a PII/PHI anonymization run returned in list endpoints."""

    id: Optional[str] = None
    """Unique identifier for the anonymization run."""

    completed_at: Optional[datetime] = None
    """When the run completed."""

    created_at: Optional[datetime] = None
    """When the run was created."""

    created_by_email: Optional[str] = None
    """Email of the user who created this run."""

    dataset_id: Optional[str] = None
    """UUID of the seed dataset being anonymized."""

    dataset_name: Optional[str] = None
    """Name of the seed dataset."""

    detection_method: Optional[str] = None
    """Entity detection method used."""

    llm_model_name: Optional[str] = None
    """LLM model name (when detection_method includes `llm`)."""

    pii_types: Optional[List[str]] = None
    """List of PII/PHI entity types being detected."""

    status: Optional[Literal["PENDING", "PROCESSING", "SUCCEEDED", "FAILED"]] = None
    """Current status of the anonymization run."""


AnonymizationRunListResponse: TypeAlias = List[AnonymizationRunListResponseItem]
