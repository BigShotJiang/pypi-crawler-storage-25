# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["SpecCreateResponse"]


class SpecCreateResponse(BaseModel):
    id: Optional[str] = None
    """ID of the newly created spec"""
