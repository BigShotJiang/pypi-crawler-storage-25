# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, TypedDict

from ..._types import SequenceNotStr

__all__ = ["AnonymizationRunCreateParams"]


class AnonymizationRunCreateParams(TypedDict, total=False):
    dataset_id: Required[str]
    """UUID of the seed dataset to anonymize."""

    detection_method: Required[
        Literal["aimon_pii_m1", "llm", "heuristics", "aimon_pii_m1+heuristics", "llm+heuristics", "all"]
    ]
    """Entity detection method.

    Use `llm` or compound methods when you need LLM-based detection; supply
    `llm_model_name` in that case.
    """

    pii_types: Required[SequenceNotStr[str]]
    """List of PII/PHI entity types to detect and mask (e.g.

    ["first_name", "email", "phone_number"]). All values must be lowercase.
    """

    llm_model_name: str
    """LLM model name. Required when `detection_method` includes `llm`."""

    mask_config: Dict[str, str]
    """Optional per-entity-type masking strategy, e.g.

    `{"first_name": "<FIRST_NAME>", "email": "<EMAIL>"}`. Defaults to redact all.
    """

    threshold: float
    """Confidence threshold for entity detection (0.0–1.0).

    Lower values detect more entities; higher values reduce false positives.
    """
