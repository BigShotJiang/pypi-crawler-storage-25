# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ...._models import BaseModel

__all__ = ["FileDownloadResponse"]


class FileDownloadResponse(BaseModel):
    content_type: Optional[str] = None
    """MIME type of the file"""

    download_url: Optional[str] = None
    """Presigned URL to download the file (valid for 1 hour)"""

    filename: Optional[str] = None
    """Original filename"""
