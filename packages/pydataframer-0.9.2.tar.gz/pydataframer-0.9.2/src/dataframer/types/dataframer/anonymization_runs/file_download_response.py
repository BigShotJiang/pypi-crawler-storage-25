# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ...._models import BaseModel

__all__ = ["FileDownloadResponse"]


class FileDownloadResponse(BaseModel):
    """Presigned download URL for a single anonymized file."""

    content_type: Optional[str] = None
    """MIME type of the file (e.g. `text/plain`, `application/json`)."""

    download_url: Optional[str] = None
    """Presigned S3 URL to download the anonymized file. Expires after 1 hour."""

    file_name: Optional[str] = None
    """Original file name."""
