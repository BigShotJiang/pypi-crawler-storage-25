# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from ...._models import BaseModel

__all__ = ["FileDownloadAllResponse"]


class FileDownloadAllResponse(BaseModel):
    """Response for the async ZIP download endpoint."""

    download_url: Optional[str] = None
    """Presigned S3 URL to download the ZIP archive.

    Expires after 1 hour. `null` when the ZIP is still being generated (status
    `generating`).
    """

    status: Optional[Literal["ready", "generating"]] = None
    """`ready` when the ZIP is available and `download_url` is set.

    `generating` when ZIP creation is in progress — poll again until `ready`.
    """
