# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

from ..._types import FileTypes

__all__ = ["SeedDatasetCreateFromZipParams"]


class SeedDatasetCreateFromZipParams(TypedDict, total=False):
    name: Required[str]
    """Dataset name (unique within company)"""

    zip_file: Required[FileTypes]
    """ZIP file containing dataset files.

    For MULTI_FOLDER datasets, the order files appear in the ZIP determines their
    order within each folder — earlier files should be the ones that later files may
    depend on.
    """

    description: str
    """Optional dataset description"""
