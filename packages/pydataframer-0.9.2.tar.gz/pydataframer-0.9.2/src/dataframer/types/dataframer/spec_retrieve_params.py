# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["SpecRetrieveParams"]


class SpecRetrieveParams(TypedDict, total=False):
    include_versions: bool
    """Include all previous spec versions in the response"""
