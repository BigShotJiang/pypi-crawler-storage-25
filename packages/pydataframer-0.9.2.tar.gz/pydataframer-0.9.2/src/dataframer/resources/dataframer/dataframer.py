# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .specs import (
    SpecsResource,
    AsyncSpecsResource,
    SpecsResourceWithRawResponse,
    AsyncSpecsResourceWithRawResponse,
    SpecsResourceWithStreamingResponse,
    AsyncSpecsResourceWithStreamingResponse,
)
from ..._compat import cached_property
from .runs.runs import (
    RunsResource,
    AsyncRunsResource,
    RunsResourceWithRawResponse,
    AsyncRunsResourceWithRawResponse,
    RunsResourceWithStreamingResponse,
    AsyncRunsResourceWithStreamingResponse,
)
from ..._resource import SyncAPIResource, AsyncAPIResource
from .evaluations import (
    EvaluationsResource,
    AsyncEvaluationsResource,
    EvaluationsResourceWithRawResponse,
    AsyncEvaluationsResourceWithRawResponse,
    EvaluationsResourceWithStreamingResponse,
    AsyncEvaluationsResourceWithStreamingResponse,
)
from .red_team_runs import (
    RedTeamRunsResource,
    AsyncRedTeamRunsResource,
    RedTeamRunsResourceWithRawResponse,
    AsyncRedTeamRunsResourceWithRawResponse,
    RedTeamRunsResourceWithStreamingResponse,
    AsyncRedTeamRunsResourceWithStreamingResponse,
)
from .red_team_specs import (
    RedTeamSpecsResource,
    AsyncRedTeamSpecsResource,
    RedTeamSpecsResourceWithRawResponse,
    AsyncRedTeamSpecsResourceWithRawResponse,
    RedTeamSpecsResourceWithStreamingResponse,
    AsyncRedTeamSpecsResourceWithStreamingResponse,
)
from .seed_datasets.seed_datasets import (
    SeedDatasetsResource,
    AsyncSeedDatasetsResource,
    SeedDatasetsResourceWithRawResponse,
    AsyncSeedDatasetsResourceWithRawResponse,
    SeedDatasetsResourceWithStreamingResponse,
    AsyncSeedDatasetsResourceWithStreamingResponse,
)
from .anonymization_runs.anonymization_runs import (
    AnonymizationRunsResource,
    AsyncAnonymizationRunsResource,
    AnonymizationRunsResourceWithRawResponse,
    AsyncAnonymizationRunsResourceWithRawResponse,
    AnonymizationRunsResourceWithStreamingResponse,
    AsyncAnonymizationRunsResourceWithStreamingResponse,
)

__all__ = ["DataframerResource", "AsyncDataframerResource"]


class DataframerResource(SyncAPIResource):
    @cached_property
    def seed_datasets(self) -> SeedDatasetsResource:
        """Manage seed datasets for generation"""
        return SeedDatasetsResource(self._client)

    @cached_property
    def evaluations(self) -> EvaluationsResource:
        """Evaluate generated sample quality"""
        return EvaluationsResource(self._client)

    @cached_property
    def red_team_runs(self) -> RedTeamRunsResource:
        """Security testing and adversarial prompts"""
        return RedTeamRunsResource(self._client)

    @cached_property
    def red_team_specs(self) -> RedTeamSpecsResource:
        """Security testing and adversarial prompts"""
        return RedTeamSpecsResource(self._client)

    @cached_property
    def runs(self) -> RunsResource:
        return RunsResource(self._client)

    @cached_property
    def specs(self) -> SpecsResource:
        """Data specifications for sample generation"""
        return SpecsResource(self._client)

    @cached_property
    def anonymization_runs(self) -> AnonymizationRunsResource:
        return AnonymizationRunsResource(self._client)

    @cached_property
    def with_raw_response(self) -> DataframerResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return DataframerResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> DataframerResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return DataframerResourceWithStreamingResponse(self)


class AsyncDataframerResource(AsyncAPIResource):
    @cached_property
    def seed_datasets(self) -> AsyncSeedDatasetsResource:
        """Manage seed datasets for generation"""
        return AsyncSeedDatasetsResource(self._client)

    @cached_property
    def evaluations(self) -> AsyncEvaluationsResource:
        """Evaluate generated sample quality"""
        return AsyncEvaluationsResource(self._client)

    @cached_property
    def red_team_runs(self) -> AsyncRedTeamRunsResource:
        """Security testing and adversarial prompts"""
        return AsyncRedTeamRunsResource(self._client)

    @cached_property
    def red_team_specs(self) -> AsyncRedTeamSpecsResource:
        """Security testing and adversarial prompts"""
        return AsyncRedTeamSpecsResource(self._client)

    @cached_property
    def runs(self) -> AsyncRunsResource:
        return AsyncRunsResource(self._client)

    @cached_property
    def specs(self) -> AsyncSpecsResource:
        """Data specifications for sample generation"""
        return AsyncSpecsResource(self._client)

    @cached_property
    def anonymization_runs(self) -> AsyncAnonymizationRunsResource:
        return AsyncAnonymizationRunsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncDataframerResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncDataframerResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncDataframerResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return AsyncDataframerResourceWithStreamingResponse(self)


class DataframerResourceWithRawResponse:
    def __init__(self, dataframer: DataframerResource) -> None:
        self._dataframer = dataframer

    @cached_property
    def seed_datasets(self) -> SeedDatasetsResourceWithRawResponse:
        """Manage seed datasets for generation"""
        return SeedDatasetsResourceWithRawResponse(self._dataframer.seed_datasets)

    @cached_property
    def evaluations(self) -> EvaluationsResourceWithRawResponse:
        """Evaluate generated sample quality"""
        return EvaluationsResourceWithRawResponse(self._dataframer.evaluations)

    @cached_property
    def red_team_runs(self) -> RedTeamRunsResourceWithRawResponse:
        """Security testing and adversarial prompts"""
        return RedTeamRunsResourceWithRawResponse(self._dataframer.red_team_runs)

    @cached_property
    def red_team_specs(self) -> RedTeamSpecsResourceWithRawResponse:
        """Security testing and adversarial prompts"""
        return RedTeamSpecsResourceWithRawResponse(self._dataframer.red_team_specs)

    @cached_property
    def runs(self) -> RunsResourceWithRawResponse:
        return RunsResourceWithRawResponse(self._dataframer.runs)

    @cached_property
    def specs(self) -> SpecsResourceWithRawResponse:
        """Data specifications for sample generation"""
        return SpecsResourceWithRawResponse(self._dataframer.specs)

    @cached_property
    def anonymization_runs(self) -> AnonymizationRunsResourceWithRawResponse:
        return AnonymizationRunsResourceWithRawResponse(self._dataframer.anonymization_runs)


class AsyncDataframerResourceWithRawResponse:
    def __init__(self, dataframer: AsyncDataframerResource) -> None:
        self._dataframer = dataframer

    @cached_property
    def seed_datasets(self) -> AsyncSeedDatasetsResourceWithRawResponse:
        """Manage seed datasets for generation"""
        return AsyncSeedDatasetsResourceWithRawResponse(self._dataframer.seed_datasets)

    @cached_property
    def evaluations(self) -> AsyncEvaluationsResourceWithRawResponse:
        """Evaluate generated sample quality"""
        return AsyncEvaluationsResourceWithRawResponse(self._dataframer.evaluations)

    @cached_property
    def red_team_runs(self) -> AsyncRedTeamRunsResourceWithRawResponse:
        """Security testing and adversarial prompts"""
        return AsyncRedTeamRunsResourceWithRawResponse(self._dataframer.red_team_runs)

    @cached_property
    def red_team_specs(self) -> AsyncRedTeamSpecsResourceWithRawResponse:
        """Security testing and adversarial prompts"""
        return AsyncRedTeamSpecsResourceWithRawResponse(self._dataframer.red_team_specs)

    @cached_property
    def runs(self) -> AsyncRunsResourceWithRawResponse:
        return AsyncRunsResourceWithRawResponse(self._dataframer.runs)

    @cached_property
    def specs(self) -> AsyncSpecsResourceWithRawResponse:
        """Data specifications for sample generation"""
        return AsyncSpecsResourceWithRawResponse(self._dataframer.specs)

    @cached_property
    def anonymization_runs(self) -> AsyncAnonymizationRunsResourceWithRawResponse:
        return AsyncAnonymizationRunsResourceWithRawResponse(self._dataframer.anonymization_runs)


class DataframerResourceWithStreamingResponse:
    def __init__(self, dataframer: DataframerResource) -> None:
        self._dataframer = dataframer

    @cached_property
    def seed_datasets(self) -> SeedDatasetsResourceWithStreamingResponse:
        """Manage seed datasets for generation"""
        return SeedDatasetsResourceWithStreamingResponse(self._dataframer.seed_datasets)

    @cached_property
    def evaluations(self) -> EvaluationsResourceWithStreamingResponse:
        """Evaluate generated sample quality"""
        return EvaluationsResourceWithStreamingResponse(self._dataframer.evaluations)

    @cached_property
    def red_team_runs(self) -> RedTeamRunsResourceWithStreamingResponse:
        """Security testing and adversarial prompts"""
        return RedTeamRunsResourceWithStreamingResponse(self._dataframer.red_team_runs)

    @cached_property
    def red_team_specs(self) -> RedTeamSpecsResourceWithStreamingResponse:
        """Security testing and adversarial prompts"""
        return RedTeamSpecsResourceWithStreamingResponse(self._dataframer.red_team_specs)

    @cached_property
    def runs(self) -> RunsResourceWithStreamingResponse:
        return RunsResourceWithStreamingResponse(self._dataframer.runs)

    @cached_property
    def specs(self) -> SpecsResourceWithStreamingResponse:
        """Data specifications for sample generation"""
        return SpecsResourceWithStreamingResponse(self._dataframer.specs)

    @cached_property
    def anonymization_runs(self) -> AnonymizationRunsResourceWithStreamingResponse:
        return AnonymizationRunsResourceWithStreamingResponse(self._dataframer.anonymization_runs)


class AsyncDataframerResourceWithStreamingResponse:
    def __init__(self, dataframer: AsyncDataframerResource) -> None:
        self._dataframer = dataframer

    @cached_property
    def seed_datasets(self) -> AsyncSeedDatasetsResourceWithStreamingResponse:
        """Manage seed datasets for generation"""
        return AsyncSeedDatasetsResourceWithStreamingResponse(self._dataframer.seed_datasets)

    @cached_property
    def evaluations(self) -> AsyncEvaluationsResourceWithStreamingResponse:
        """Evaluate generated sample quality"""
        return AsyncEvaluationsResourceWithStreamingResponse(self._dataframer.evaluations)

    @cached_property
    def red_team_runs(self) -> AsyncRedTeamRunsResourceWithStreamingResponse:
        """Security testing and adversarial prompts"""
        return AsyncRedTeamRunsResourceWithStreamingResponse(self._dataframer.red_team_runs)

    @cached_property
    def red_team_specs(self) -> AsyncRedTeamSpecsResourceWithStreamingResponse:
        """Security testing and adversarial prompts"""
        return AsyncRedTeamSpecsResourceWithStreamingResponse(self._dataframer.red_team_specs)

    @cached_property
    def runs(self) -> AsyncRunsResourceWithStreamingResponse:
        return AsyncRunsResourceWithStreamingResponse(self._dataframer.runs)

    @cached_property
    def specs(self) -> AsyncSpecsResourceWithStreamingResponse:
        """Data specifications for sample generation"""
        return AsyncSpecsResourceWithStreamingResponse(self._dataframer.specs)

    @cached_property
    def anonymization_runs(self) -> AsyncAnonymizationRunsResourceWithStreamingResponse:
        return AsyncAnonymizationRunsResourceWithStreamingResponse(self._dataframer.anonymization_runs)
