# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.dataframer import evaluation_create_params
from ...types.dataframer.evaluation_create_response import EvaluationCreateResponse
from ...types.dataframer.evaluation_retrieve_response import EvaluationRetrieveResponse

__all__ = ["EvaluationsResource", "AsyncEvaluationsResource"]


class EvaluationsResource(SyncAPIResource):
    """Evaluate generated sample quality"""

    @cached_property
    def with_raw_response(self) -> EvaluationsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return EvaluationsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> EvaluationsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return EvaluationsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        run_id: str,
        evaluation_model: Literal[
            "anthropic/claude-opus-4-6",
            "anthropic/claude-opus-4-6-thinking",
            "anthropic/claude-sonnet-4-6",
            "anthropic/claude-sonnet-4-6-thinking",
            "anthropic/claude-haiku-4-5",
            "anthropic/claude-haiku-4-5-thinking",
            "openai/gpt-5.4",
            "openai/gpt-5.4-thinking",
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EvaluationCreateResponse:
        """
        Start a new evaluation for a completed run.

        **Async operation**: This endpoint returns immediately with an evaluation ID.
        Poll `GET /api/dataframer/evaluations/{evaluation_id}/` until status is
        `SUCCEEDED` or `FAILED`.

        The run must be in `SUCCEEDED` status before an evaluation can be created.

        Args:
          run_id: ID of the completed run to evaluate. Run must be in SUCCEEDED status.

          evaluation_model: AI model to use for evaluation. Defaults to anthropic/claude-sonnet-4-5.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/dataframer/evaluations/",
            body=maybe_transform(
                {
                    "run_id": run_id,
                    "evaluation_model": evaluation_model,
                },
                evaluation_create_params.EvaluationCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EvaluationCreateResponse,
        )

    def retrieve(
        self,
        evaluation_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EvaluationRetrieveResponse:
        """
        Retrieve full evaluation details including distribution analysis.

        Also use this endpoint to poll for evaluation completion while it is still
        PROCESSING.

        When an evaluation completes successfully, the response includes:

        - **conformance_score**: Overall score (0-100) measuring how well samples match
          expected distributions
        - **conformance_explanation**: Human-readable explanation of the conformance
          score and notable deviations
        - **distribution_analysis**: Per-property comparison of expected vs observed
          percentages
        - **sample_classifications**: How each generated sample was classified for each
          property

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not evaluation_id:
            raise ValueError(f"Expected a non-empty value for `evaluation_id` but received {evaluation_id!r}")
        return self._get(
            path_template("/api/dataframer/evaluations/{evaluation_id}/", evaluation_id=evaluation_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EvaluationRetrieveResponse,
        )


class AsyncEvaluationsResource(AsyncAPIResource):
    """Evaluate generated sample quality"""

    @cached_property
    def with_raw_response(self) -> AsyncEvaluationsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncEvaluationsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncEvaluationsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return AsyncEvaluationsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        run_id: str,
        evaluation_model: Literal[
            "anthropic/claude-opus-4-6",
            "anthropic/claude-opus-4-6-thinking",
            "anthropic/claude-sonnet-4-6",
            "anthropic/claude-sonnet-4-6-thinking",
            "anthropic/claude-haiku-4-5",
            "anthropic/claude-haiku-4-5-thinking",
            "openai/gpt-5.4",
            "openai/gpt-5.4-thinking",
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EvaluationCreateResponse:
        """
        Start a new evaluation for a completed run.

        **Async operation**: This endpoint returns immediately with an evaluation ID.
        Poll `GET /api/dataframer/evaluations/{evaluation_id}/` until status is
        `SUCCEEDED` or `FAILED`.

        The run must be in `SUCCEEDED` status before an evaluation can be created.

        Args:
          run_id: ID of the completed run to evaluate. Run must be in SUCCEEDED status.

          evaluation_model: AI model to use for evaluation. Defaults to anthropic/claude-sonnet-4-5.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/dataframer/evaluations/",
            body=await async_maybe_transform(
                {
                    "run_id": run_id,
                    "evaluation_model": evaluation_model,
                },
                evaluation_create_params.EvaluationCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EvaluationCreateResponse,
        )

    async def retrieve(
        self,
        evaluation_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EvaluationRetrieveResponse:
        """
        Retrieve full evaluation details including distribution analysis.

        Also use this endpoint to poll for evaluation completion while it is still
        PROCESSING.

        When an evaluation completes successfully, the response includes:

        - **conformance_score**: Overall score (0-100) measuring how well samples match
          expected distributions
        - **conformance_explanation**: Human-readable explanation of the conformance
          score and notable deviations
        - **distribution_analysis**: Per-property comparison of expected vs observed
          percentages
        - **sample_classifications**: How each generated sample was classified for each
          property

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not evaluation_id:
            raise ValueError(f"Expected a non-empty value for `evaluation_id` but received {evaluation_id!r}")
        return await self._get(
            path_template("/api/dataframer/evaluations/{evaluation_id}/", evaluation_id=evaluation_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EvaluationRetrieveResponse,
        )


class EvaluationsResourceWithRawResponse:
    def __init__(self, evaluations: EvaluationsResource) -> None:
        self._evaluations = evaluations

        self.create = to_raw_response_wrapper(
            evaluations.create,
        )
        self.retrieve = to_raw_response_wrapper(
            evaluations.retrieve,
        )


class AsyncEvaluationsResourceWithRawResponse:
    def __init__(self, evaluations: AsyncEvaluationsResource) -> None:
        self._evaluations = evaluations

        self.create = async_to_raw_response_wrapper(
            evaluations.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            evaluations.retrieve,
        )


class EvaluationsResourceWithStreamingResponse:
    def __init__(self, evaluations: EvaluationsResource) -> None:
        self._evaluations = evaluations

        self.create = to_streamed_response_wrapper(
            evaluations.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            evaluations.retrieve,
        )


class AsyncEvaluationsResourceWithStreamingResponse:
    def __init__(self, evaluations: AsyncEvaluationsResource) -> None:
        self._evaluations = evaluations

        self.create = async_to_streamed_response_wrapper(
            evaluations.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            evaluations.retrieve,
        )
