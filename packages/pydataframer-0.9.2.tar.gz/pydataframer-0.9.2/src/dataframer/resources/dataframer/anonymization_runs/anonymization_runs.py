# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal

import httpx

from .files import (
    FilesResource,
    AsyncFilesResource,
    FilesResourceWithRawResponse,
    AsyncFilesResourceWithRawResponse,
    FilesResourceWithStreamingResponse,
    AsyncFilesResourceWithStreamingResponse,
)
from ...._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.dataframer import anonymization_run_create_params
from ....types.dataframer.anonymization_run_list_response import AnonymizationRunListResponse
from ....types.dataframer.anonymization_run_create_response import AnonymizationRunCreateResponse
from ....types.dataframer.anonymization_run_retrieve_response import AnonymizationRunRetrieveResponse

__all__ = ["AnonymizationRunsResource", "AsyncAnonymizationRunsResource"]


class AnonymizationRunsResource(SyncAPIResource):
    @cached_property
    def files(self) -> FilesResource:
        return FilesResource(self._client)

    @cached_property
    def with_raw_response(self) -> AnonymizationRunsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AnonymizationRunsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AnonymizationRunsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return AnonymizationRunsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        dataset_id: str,
        detection_method: Literal[
            "aimon_pii_m1", "llm", "heuristics", "aimon_pii_m1+heuristics", "llm+heuristics", "all"
        ],
        pii_types: SequenceNotStr[str],
        llm_model_name: str | Omit = omit,
        mask_config: Dict[str, str] | Omit = omit,
        threshold: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AnonymizationRunCreateResponse:
        """
        Create a new anonymization run.

        **Async operation**: Returns immediately with a run ID and `PENDING` status.
        Poll `GET /api/dataframer/anonymization-runs/{run_id}/` until status is
        `SUCCEEDED` or `FAILED`.

        Args:
          dataset_id: UUID of the seed dataset to anonymize.

          detection_method: Entity detection method. Use `llm` or compound methods when you need LLM-based
              detection; supply `llm_model_name` in that case.

          pii_types: List of PII/PHI entity types to detect and mask (e.g. ["first_name", "email",
              "phone_number"]). All values must be lowercase.

          llm_model_name: LLM model name. Required when `detection_method` includes `llm`.

          mask_config: Optional per-entity-type masking strategy, e.g.
              `{"first_name": "<FIRST_NAME>", "email": "<EMAIL>"}`. Defaults to redact all.

          threshold: Confidence threshold for entity detection (0.0–1.0). Lower values detect more
              entities; higher values reduce false positives.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/dataframer/anonymization-runs/",
            body=maybe_transform(
                {
                    "dataset_id": dataset_id,
                    "detection_method": detection_method,
                    "pii_types": pii_types,
                    "llm_model_name": llm_model_name,
                    "mask_config": mask_config,
                    "threshold": threshold,
                },
                anonymization_run_create_params.AnonymizationRunCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AnonymizationRunCreateResponse,
        )

    def retrieve(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AnonymizationRunRetrieveResponse:
        """Retrieve an anonymization run by ID.

        Use this endpoint to poll for completion
        while status is `PENDING` or `PROCESSING`.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        return self._get(
            path_template("/api/dataframer/anonymization-runs/{run_id}/", run_id=run_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AnonymizationRunRetrieveResponse,
        )

    def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AnonymizationRunListResponse:
        """List all anonymization runs for the authenticated company, newest first.

        Running
        and pending runs have their status refreshed automatically.
        """
        return self._get(
            "/api/dataframer/anonymization-runs/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AnonymizationRunListResponse,
        )

    def delete(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Soft-delete an anonymization run (hidden from list view).

        The run data is
        retained internally.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/api/dataframer/anonymization-runs/{run_id}/", run_id=run_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncAnonymizationRunsResource(AsyncAPIResource):
    @cached_property
    def files(self) -> AsyncFilesResource:
        return AsyncFilesResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncAnonymizationRunsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncAnonymizationRunsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAnonymizationRunsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return AsyncAnonymizationRunsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        dataset_id: str,
        detection_method: Literal[
            "aimon_pii_m1", "llm", "heuristics", "aimon_pii_m1+heuristics", "llm+heuristics", "all"
        ],
        pii_types: SequenceNotStr[str],
        llm_model_name: str | Omit = omit,
        mask_config: Dict[str, str] | Omit = omit,
        threshold: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AnonymizationRunCreateResponse:
        """
        Create a new anonymization run.

        **Async operation**: Returns immediately with a run ID and `PENDING` status.
        Poll `GET /api/dataframer/anonymization-runs/{run_id}/` until status is
        `SUCCEEDED` or `FAILED`.

        Args:
          dataset_id: UUID of the seed dataset to anonymize.

          detection_method: Entity detection method. Use `llm` or compound methods when you need LLM-based
              detection; supply `llm_model_name` in that case.

          pii_types: List of PII/PHI entity types to detect and mask (e.g. ["first_name", "email",
              "phone_number"]). All values must be lowercase.

          llm_model_name: LLM model name. Required when `detection_method` includes `llm`.

          mask_config: Optional per-entity-type masking strategy, e.g.
              `{"first_name": "<FIRST_NAME>", "email": "<EMAIL>"}`. Defaults to redact all.

          threshold: Confidence threshold for entity detection (0.0–1.0). Lower values detect more
              entities; higher values reduce false positives.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/dataframer/anonymization-runs/",
            body=await async_maybe_transform(
                {
                    "dataset_id": dataset_id,
                    "detection_method": detection_method,
                    "pii_types": pii_types,
                    "llm_model_name": llm_model_name,
                    "mask_config": mask_config,
                    "threshold": threshold,
                },
                anonymization_run_create_params.AnonymizationRunCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AnonymizationRunCreateResponse,
        )

    async def retrieve(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AnonymizationRunRetrieveResponse:
        """Retrieve an anonymization run by ID.

        Use this endpoint to poll for completion
        while status is `PENDING` or `PROCESSING`.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        return await self._get(
            path_template("/api/dataframer/anonymization-runs/{run_id}/", run_id=run_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AnonymizationRunRetrieveResponse,
        )

    async def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AnonymizationRunListResponse:
        """List all anonymization runs for the authenticated company, newest first.

        Running
        and pending runs have their status refreshed automatically.
        """
        return await self._get(
            "/api/dataframer/anonymization-runs/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AnonymizationRunListResponse,
        )

    async def delete(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Soft-delete an anonymization run (hidden from list view).

        The run data is
        retained internally.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/api/dataframer/anonymization-runs/{run_id}/", run_id=run_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AnonymizationRunsResourceWithRawResponse:
    def __init__(self, anonymization_runs: AnonymizationRunsResource) -> None:
        self._anonymization_runs = anonymization_runs

        self.create = to_raw_response_wrapper(
            anonymization_runs.create,
        )
        self.retrieve = to_raw_response_wrapper(
            anonymization_runs.retrieve,
        )
        self.list = to_raw_response_wrapper(
            anonymization_runs.list,
        )
        self.delete = to_raw_response_wrapper(
            anonymization_runs.delete,
        )

    @cached_property
    def files(self) -> FilesResourceWithRawResponse:
        return FilesResourceWithRawResponse(self._anonymization_runs.files)


class AsyncAnonymizationRunsResourceWithRawResponse:
    def __init__(self, anonymization_runs: AsyncAnonymizationRunsResource) -> None:
        self._anonymization_runs = anonymization_runs

        self.create = async_to_raw_response_wrapper(
            anonymization_runs.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            anonymization_runs.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            anonymization_runs.list,
        )
        self.delete = async_to_raw_response_wrapper(
            anonymization_runs.delete,
        )

    @cached_property
    def files(self) -> AsyncFilesResourceWithRawResponse:
        return AsyncFilesResourceWithRawResponse(self._anonymization_runs.files)


class AnonymizationRunsResourceWithStreamingResponse:
    def __init__(self, anonymization_runs: AnonymizationRunsResource) -> None:
        self._anonymization_runs = anonymization_runs

        self.create = to_streamed_response_wrapper(
            anonymization_runs.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            anonymization_runs.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            anonymization_runs.list,
        )
        self.delete = to_streamed_response_wrapper(
            anonymization_runs.delete,
        )

    @cached_property
    def files(self) -> FilesResourceWithStreamingResponse:
        return FilesResourceWithStreamingResponse(self._anonymization_runs.files)


class AsyncAnonymizationRunsResourceWithStreamingResponse:
    def __init__(self, anonymization_runs: AsyncAnonymizationRunsResource) -> None:
        self._anonymization_runs = anonymization_runs

        self.create = async_to_streamed_response_wrapper(
            anonymization_runs.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            anonymization_runs.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            anonymization_runs.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            anonymization_runs.delete,
        )

    @cached_property
    def files(self) -> AsyncFilesResourceWithStreamingResponse:
        return AsyncFilesResourceWithStreamingResponse(self._anonymization_runs.files)
