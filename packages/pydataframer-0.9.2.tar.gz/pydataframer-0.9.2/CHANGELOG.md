# Changelog

## 0.9.2 (2026-04-23)

Full Changelog: [v0.9.1...v0.9.2](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.9.1...v0.9.2)

### Chores

* **internal:** more robust bootstrap script ([0f13362](https://github.com/aimonlabs/dataframer-python-sdk/commit/0f13362de0838387615e812b61d5a07b1ddc58db))

## 0.9.1 (2026-04-18)

Full Changelog: [v0.9.0...v0.9.1](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.9.0...v0.9.1)

### Performance Improvements

* **client:** optimize file structure copying in multipart requests ([65044ed](https://github.com/aimonlabs/dataframer-python-sdk/commit/65044ed018061475bc61f7a6a88f7eb6ba69d431))

## 0.9.0 (2026-04-16)

Full Changelog: [v0.8.0...v0.9.0](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.8.0...v0.9.0)

### Features

* **api:** api update ([7cae9de](https://github.com/aimonlabs/dataframer-python-sdk/commit/7cae9dec0a4490be4c76f437e0ac9e669e0002f2))
* **api:** api update ([b6058b8](https://github.com/aimonlabs/dataframer-python-sdk/commit/b6058b8003e3cb66edee523d655d3f56efe15e29))
* **internal:** implement indices array format for query and form serialization ([67d2546](https://github.com/aimonlabs/dataframer-python-sdk/commit/67d2546cc50072a3d1d1cee02d2368eb8f58d699))


### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([15fad42](https://github.com/aimonlabs/dataframer-python-sdk/commit/15fad427f58ab679bd90794018c659db48f37bca))
* ensure file data are only sent as 1 parameter ([7ea3f10](https://github.com/aimonlabs/dataframer-python-sdk/commit/7ea3f10a7ac47ddfb50341f82df71670783ee2ed))


### Chores

* **ci:** skip lint on metadata-only changes ([7f4c570](https://github.com/aimonlabs/dataframer-python-sdk/commit/7f4c5709e970fe4c1bfdad121fb89830561b43d2))
* **internal:** update gitignore ([c954e8b](https://github.com/aimonlabs/dataframer-python-sdk/commit/c954e8b2bf30c2dcd57a780c37b77c031d638ddf))

## 0.8.0 (2026-03-21)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.7.0...v0.8.0)

### Features

* **api:** manual updates ([8e1e0bf](https://github.com/aimonlabs/dataframer-python-sdk/commit/8e1e0bf17ed702388fd5494dba85c93263a15214))


### Bug Fixes

* **deps:** bump minimum typing-extensions version ([ea9f5ea](https://github.com/aimonlabs/dataframer-python-sdk/commit/ea9f5eaddf810e2b226e7e0e17af75eab25037b0))
* **pydantic:** do not pass `by_alias` unless set ([135c69a](https://github.com/aimonlabs/dataframer-python-sdk/commit/135c69aed7920046d5764f8728fec797e90a1ffc))
* sanitize endpoint path params ([1d72e34](https://github.com/aimonlabs/dataframer-python-sdk/commit/1d72e3471b1b92c9b9e2a9d5df4df70a46780cb0))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([eb08003](https://github.com/aimonlabs/dataframer-python-sdk/commit/eb08003c7c8ece3d34927ec71d9b129ba3573722))
* **internal:** tweak CI branches ([007baf9](https://github.com/aimonlabs/dataframer-python-sdk/commit/007baf95548279dd28fb39e95c5d666fd491e13f))
* update placeholder string ([60a30e3](https://github.com/aimonlabs/dataframer-python-sdk/commit/60a30e3ea28f13b53554bf6720bdd85b03449f02))

## 0.7.0 (2026-03-06)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.6.0...v0.7.0)

### Features

* **api:** manual updates ([0e153db](https://github.com/aimonlabs/dataframer-python-sdk/commit/0e153db6a0fcf0af81aaab5d811f76a315bcd07a))
* **api:** manual updates ([a6ffab5](https://github.com/aimonlabs/dataframer-python-sdk/commit/a6ffab557e71f5cff10532bf90eb65d5afddae85))


### Chores

* **internal:** add request options to SSE classes ([bbd1d5d](https://github.com/aimonlabs/dataframer-python-sdk/commit/bbd1d5df1a0fa9bdd37fd8378f2863e950fbb823))
* **internal:** codegen related update ([cba2143](https://github.com/aimonlabs/dataframer-python-sdk/commit/cba21436eeb8d72cebc97f5ffc101b8c40b50a14))
* **internal:** make `test_proxy_environment_variables` more resilient ([e2c6f63](https://github.com/aimonlabs/dataframer-python-sdk/commit/e2c6f63dff2f4e9c383235273930a6ad7f5889fc))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([ae901d9](https://github.com/aimonlabs/dataframer-python-sdk/commit/ae901d937755e249d162bd4ebfb1168aeb2ea972))

## 0.6.0 (2026-02-20)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.5.0...v0.6.0)

### Features

* **api:** manual updates ([d4ff69a](https://github.com/aimonlabs/dataframer-python-sdk/commit/d4ff69aac331f364ad0c879e8a460c1cb5173d8e))


### Chores

* **internal:** remove mock server code ([02fae3b](https://github.com/aimonlabs/dataframer-python-sdk/commit/02fae3b96c5dc29fa497a44e7fed09a871abb502))
* update mock server docs ([c3e98ab](https://github.com/aimonlabs/dataframer-python-sdk/commit/c3e98ab13be43e39675f550036016375a21bfab1))

## 0.5.0 (2026-02-18)

Full Changelog: [v0.4.2...v0.5.0](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.4.2...v0.5.0)

### Features

* **api:** manual updates ([00c2115](https://github.com/aimonlabs/dataframer-python-sdk/commit/00c21154a6a4b995ced47e45fbddfdb786c62778))

## 0.4.2 (2026-02-13)

Full Changelog: [v0.4.1...v0.4.2](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.4.1...v0.4.2)

### Chores

* format all `api.md` files ([197e90d](https://github.com/aimonlabs/dataframer-python-sdk/commit/197e90de028ac4eed125451a306412ba5242f1af))
* **internal:** bump dependencies ([556f75c](https://github.com/aimonlabs/dataframer-python-sdk/commit/556f75c8ccd95c9cd43d5bb8920128e02537b8d2))
* **internal:** fix lint error on Python 3.14 ([3cbf60c](https://github.com/aimonlabs/dataframer-python-sdk/commit/3cbf60c90d45c19ce129a0f1d3bfb69c77601dcc))

## 0.4.1 (2026-02-06)

Full Changelog: [v0.4.0...v0.4.1](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.4.0...v0.4.1)

### Features

* **api:** added runs/cancel endpoint ([978e153](https://github.com/aimonlabs/dataframer-python-sdk/commit/978e153648e9901299095cd4ee0292075734a65b))
* **api:** databricks models supported in specs and runs ([1ef9261](https://github.com/aimonlabs/dataframer-python-sdk/commit/1ef9261edd257882d1803cf9fede5eaf31c7f44e))
* **api:** manual updates ([e80f787](https://github.com/aimonlabs/dataframer-python-sdk/commit/e80f7870ed2a8c70802816e13b16a7423ccd865d))
* **api:** manual updates ([3d72af8](https://github.com/aimonlabs/dataframer-python-sdk/commit/3d72af8a7417b3756034dd346a5245cb84cd43e8))

## 0.4.0 (2026-02-03)

Full Changelog: [v0.3.1...v0.4.0](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.3.1...v0.4.0)

### Features

* **api:** manual updates ([68d931a](https://github.com/aimonlabs/dataframer-python-sdk/commit/68d931acb9f60466ebd0d24166282bdbc739122b))
* **api:** manual updates ([a27cdd3](https://github.com/aimonlabs/dataframer-python-sdk/commit/a27cdd32d316d67364a8fd904cad9967e61d2abd))
* **api:** manual updates ([53947fd](https://github.com/aimonlabs/dataframer-python-sdk/commit/53947fdf0fd89a1d79b9b92aa53951a02df315fc))
* **client:** add custom JSON encoder for extended type support ([d4e380f](https://github.com/aimonlabs/dataframer-python-sdk/commit/d4e380f398c6955888900a5c02e16cc938bb69ba))
* **client:** add support for binary request streaming ([12535db](https://github.com/aimonlabs/dataframer-python-sdk/commit/12535db76d2f01dc2595495eefc605af39242812))


### Chores

* **ci:** upgrade `actions/github-script` ([ab9ca6f](https://github.com/aimonlabs/dataframer-python-sdk/commit/ab9ca6f22ad4e36ab74186d18e7e0b24b1d8378d))
* **internal:** update `actions/checkout` version ([b8c5f7c](https://github.com/aimonlabs/dataframer-python-sdk/commit/b8c5f7c7b23e67e4ca50ea0d50f3ab817a340316))

## 0.3.1 (2026-01-06)

Full Changelog: [v0.3.0...v0.3.1](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.3.0...v0.3.1)

### Chores

* **internal:** codegen related update ([f0a682b](https://github.com/aimonlabs/dataframer-python-sdk/commit/f0a682b9d90848b6b413d9772993b2736cf02389))

## 0.3.0 (2025-12-19)

Full Changelog: [v0.2.1...v0.3.0](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.2.1...v0.3.0)

### Features

* **api:** manual updates ([e0048d7](https://github.com/aimonlabs/dataframer-python-sdk/commit/e0048d71e5779b071bad7514719aab6b12833ea2))


### Bug Fixes

* use async_to_httpx_files in patch method ([3a27765](https://github.com/aimonlabs/dataframer-python-sdk/commit/3a27765e327eaa4366b964e81a0770f4d3a5c166))


### Chores

* **internal:** add `--fix` argument to lint script ([db17a5a](https://github.com/aimonlabs/dataframer-python-sdk/commit/db17a5a32befccba949a919d1f6a2c935e28a646))
* **internal:** add missing files argument to base client ([13a9353](https://github.com/aimonlabs/dataframer-python-sdk/commit/13a93531d903542cfa73a6d759b99f7c243a9f44))
* speedup initial import ([c9b4b65](https://github.com/aimonlabs/dataframer-python-sdk/commit/c9b4b65c9465a26a77f18ae83472d71240f2eb3c))

## 0.2.1 (2025-12-09)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.2.0...v0.2.1)

### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([d886811](https://github.com/aimonlabs/dataframer-python-sdk/commit/d886811b3bec331cf614f41de85366c727a82375))


### Chores

* **docs:** use environment variables for authentication in code snippets ([10665cc](https://github.com/aimonlabs/dataframer-python-sdk/commit/10665cc3e37ba8199238fac3d84986986cc94902))
* update lockfile ([40697be](https://github.com/aimonlabs/dataframer-python-sdk/commit/40697beea8ed5d20c0c10f4904549632d8b21a2a))

## 0.2.0 (2025-12-01)

Full Changelog: [v0.1.1...v0.2.0](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.1.1...v0.2.0)

### Features

* **api:** Updated OpenAPI Spec with the right links ([3409433](https://github.com/aimonlabs/dataframer-python-sdk/commit/3409433fb7553d198d8764c2d97bf75f873dcdf4))
* Updated endpoint to df-api.dataframer.ai ([7844f4d](https://github.com/aimonlabs/dataframer-python-sdk/commit/7844f4da1eef92a408c1a1eeac10e4e0d973cdad))

## 0.1.1 (2025-11-28)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.1.0...v0.1.1)

### Bug Fixes

* ensure streams are always closed ([a95a16e](https://github.com/aimonlabs/dataframer-python-sdk/commit/a95a16e7916383d9a3d2df96ee349554c451ec84))


### Chores

* add Python 3.14 classifier and testing ([e4d8e08](https://github.com/aimonlabs/dataframer-python-sdk/commit/e4d8e0897bf3c2c6936631723966de48bfa5f8d1))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([43a3d31](https://github.com/aimonlabs/dataframer-python-sdk/commit/43a3d3126a63e93b73ebb4607856ef5d6a62bf3b))

## 0.1.0 (2025-11-20)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** fixed parameters to be compliant to openapi 3.0 ([a33ea08](https://github.com/aimonlabs/dataframer-python-sdk/commit/a33ea085d56276bacafee1e7363706e3c11df5cc))
* **api:** manual updates ([5b4b8e4](https://github.com/aimonlabs/dataframer-python-sdk/commit/5b4b8e465d31df281cab3c8b63915e77e7f9afc2))
* **api:** manual updates ([2cd2653](https://github.com/aimonlabs/dataframer-python-sdk/commit/2cd265380eb3acf273becce9835ceaf878680ba1))
* **api:** manual updates ([6103e74](https://github.com/aimonlabs/dataframer-python-sdk/commit/6103e7444bf36a5fc5e7c7e30a5ee6476921a220))
* **api:** manual updates ([943a854](https://github.com/aimonlabs/dataframer-python-sdk/commit/943a854003cc8017eef3d59891acb005d0224d98))
* **api:** manual updates ([80cf9d5](https://github.com/aimonlabs/dataframer-python-sdk/commit/80cf9d5b8d5c8c14b27571bc528aa84c5e92e6df))
* **api:** manual updates ([1d4f6c6](https://github.com/aimonlabs/dataframer-python-sdk/commit/1d4f6c6a765ad9d3a091e9101d45cbd6521ff668))
* **api:** manual updates ([536a4d5](https://github.com/aimonlabs/dataframer-python-sdk/commit/536a4d54c823082d6beadd346e3cc20c3ef0dddb))
* **api:** manual updates ([d34676b](https://github.com/aimonlabs/dataframer-python-sdk/commit/d34676b1c90a628e85185bce5587693bd24aefb6))
* **api:** manual updates ([94fa1ae](https://github.com/aimonlabs/dataframer-python-sdk/commit/94fa1ae5093d56e24ea66854274842040b532cb1))
* **api:** manual updates ([0956709](https://github.com/aimonlabs/dataframer-python-sdk/commit/09567093fda7443b66d5673d6392db801aa9a944))
* **api:** manual updates ([c53c0af](https://github.com/aimonlabs/dataframer-python-sdk/commit/c53c0af906e8a6369a6cb2a408fac2ac19c52e05))
* **api:** manual updates ([1171eba](https://github.com/aimonlabs/dataframer-python-sdk/commit/1171eba3c0a306e0c37e017febf5acc71a4c466a))
* **api:** manual updates ([e09640c](https://github.com/aimonlabs/dataframer-python-sdk/commit/e09640cecbd2f4d195be1a60251e5b79d1e8c972))
* **api:** manual updates ([02afcbf](https://github.com/aimonlabs/dataframer-python-sdk/commit/02afcbf699dc84e044150c8422a022847a5d69e5))
* **api:** manual updates ([23456d6](https://github.com/aimonlabs/dataframer-python-sdk/commit/23456d6511020ec8cbf29ecd4c0af63d6e540702))
* **api:** manual updates ([f91a639](https://github.com/aimonlabs/dataframer-python-sdk/commit/f91a639b50ab922466e2361a4d80eebe9b9e657d))
* **api:** manual updates ([d03e7b9](https://github.com/aimonlabs/dataframer-python-sdk/commit/d03e7b93bddbf5b658929c514d40d6bb2c4fab55))
* **api:** manual updates ([e5fa408](https://github.com/aimonlabs/dataframer-python-sdk/commit/e5fa408188a61f53dc89d9b7b200e1145f319d2b))
* **api:** manual updates ([eb310b1](https://github.com/aimonlabs/dataframer-python-sdk/commit/eb310b1dedf9050252d79025d67d7282801ec988))
* **api:** manual updates ([490a115](https://github.com/aimonlabs/dataframer-python-sdk/commit/490a1155282218f405eabc7866f0f3341e7c19e4))
* **api:** manual updates ([2b67257](https://github.com/aimonlabs/dataframer-python-sdk/commit/2b6725775a1f7d0645ea6d8b17897d8bb878ee8f))
* **api:** manual updates ([d18bbe6](https://github.com/aimonlabs/dataframer-python-sdk/commit/d18bbe60a14f218585db01a88222694f0ed69e0c))
* **api:** manual updates ([4dcff69](https://github.com/aimonlabs/dataframer-python-sdk/commit/4dcff69b5e23e1b83d0b4592edd185fb8cd544e9))
* **api:** manual updates ([b044068](https://github.com/aimonlabs/dataframer-python-sdk/commit/b044068b442db76449d709fd0e481e297c903273))
* **api:** manual updates ([8df4811](https://github.com/aimonlabs/dataframer-python-sdk/commit/8df48116575162bdc14eb14ae1e6cde1557dcd53))
* **api:** manual updates ([e2cbaed](https://github.com/aimonlabs/dataframer-python-sdk/commit/e2cbaed701a65ae3767ce4af5fb336251953745e))
* **api:** manual updates ([993c406](https://github.com/aimonlabs/dataframer-python-sdk/commit/993c406aa5c30a010726d96e10bcf673e6da34cc))
* **api:** manual updates ([747aa39](https://github.com/aimonlabs/dataframer-python-sdk/commit/747aa397012371d3c5ee839808f808f736a37baf))
* **api:** manual updates ([d64c197](https://github.com/aimonlabs/dataframer-python-sdk/commit/d64c19763f4b6b11a727d074f34832df6b8abeb6))
* **api:** manual updates ([cddd29f](https://github.com/aimonlabs/dataframer-python-sdk/commit/cddd29f91978c30a098a8d1ef352a04f89f46f35))
* **api:** manual updates ([a1023d4](https://github.com/aimonlabs/dataframer-python-sdk/commit/a1023d4349e6e813bd372f94c17c77f55ef2c6a4))
* **api:** manual updates ([f7d13cf](https://github.com/aimonlabs/dataframer-python-sdk/commit/f7d13cf428f2f79673c0a90ea4d95eb020fa513f))
* **api:** proper conversion to openapi 3.0 ([74b532e](https://github.com/aimonlabs/dataframer-python-sdk/commit/74b532e5864607c7eda1456c4af8f375f344b117))


### Bug Fixes

* compat with Python 3.14 ([312e95e](https://github.com/aimonlabs/dataframer-python-sdk/commit/312e95e153c0b9caa8bb19bed53ef1f9037a8c01))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([d7e8df0](https://github.com/aimonlabs/dataframer-python-sdk/commit/d7e8df0a5b50d5dec40fcb5601e3bac9e2e6e496))


### Chores

* **internal:** grammar fix (it's -&gt; its) ([79bea7b](https://github.com/aimonlabs/dataframer-python-sdk/commit/79bea7bcacc4cd201f9a663e8922a3a3c86fc4c1))
* **package:** drop Python 3.8 support ([aeda96a](https://github.com/aimonlabs/dataframer-python-sdk/commit/aeda96a83a70cfd3b799c0a1751199f2a5eedbaa))
* update SDK settings ([39d0dcb](https://github.com/aimonlabs/dataframer-python-sdk/commit/39d0dcb4dfa4c83656c3b3c169466ccf3cf17aaa))
* update SDK settings ([aaf8e3b](https://github.com/aimonlabs/dataframer-python-sdk/commit/aaf8e3b50292985c5392a51c605bf2b4c75148f0))
* update SDK settings ([e01ce10](https://github.com/aimonlabs/dataframer-python-sdk/commit/e01ce10e0056ff4dc0580500ee09a02504eee13f))
