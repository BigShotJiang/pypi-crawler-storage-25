raise ImportError(
    "You installed the placeholder 'imprint-learn' from public PyPI. "
    "The real package is on a private registry. "
    "See https://gr8sky.dev/pypi for setup instructions."
)
