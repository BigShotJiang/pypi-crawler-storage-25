# !/usr/bin/python
# coding=utf-8
import logging
import re
import importlib.resources
from typing import Union
from qtpy import QtWidgets, QtCore, QtGui
import pythontk as ptk
from uitk.widgets.mixins.settings_manager import SettingsManager

_logger = logging.getLogger(__name__)


class StyleSheet(QtCore.QObject, ptk.LoggingMixin):
    """Theme and stylesheet manager with light/dark theme support."""

    # Signal emitted when theme changes: (widget, theme_name, theme_vars)
    theme_changed = QtCore.Signal(object, str, dict)

    themes = {
        "light": {
            # Surfaces
            "PANEL_BACKGROUND": "rgb(70,70,70)",
            "WINDOW_BACKGROUND": "rgba(80,80,80,170)",
            "WIDGET_BACKGROUND": "rgb(125,125,125)",
            "WIDGET_BACKGROUND_HOVER": "rgb(140,140,140)",
            "DISABLED_BACKGROUND": "rgb(85,85,85)",
            "ALTERNATE_BACKGROUND": "rgba(255,255,255,10)",
            "TREE_ALTERNATE_BG": "rgb(127,127,127)",
            # Text
            "TEXT_COLOR": "rgb(255,255,255)",
            "TEXT_HOVER": "rgb(255,255,255)",
            "TEXT_CHECKED": "rgb(255,255,255)",
            "TEXT_DISABLED": "rgba(150,150,150,175)",
            # Accents
            "BUTTON_HOVER": "rgb(100,130,150)",  # Desaturated blue
            "BUTTON_CHECKED": "rgb(165,135,110)",  # Further desaturated orange
            "PROGRESS_BAR_COLOR": "rgb(0,160,208)",
            # Borders + shape
            "BORDER_COLOR": "rgb(40,40,40)",
            "BORDER_HOVER": "rgba(255,255,255,110)",
            "BORDER_W": "1px",
            "RADIUS": "4px",
            # Selection (text-selection inside inputs)
            "SELECTION_BG": "rgba(70,70,70,100)",
            "SELECTION_FG": "rgb(255,255,190)",
            # Status (input feedback)
            "ACTION_VALID_FG": "rgb(60,141,60)",
            "ACTION_VALID_BG": "rgb(230,244,234)",
            "ACTION_INVALID_FG": "rgb(185,122,122)",
            "ACTION_INVALID_BG": "rgb(251,234,234)",
            "ACTION_WARNING_FG": "rgb(180,155,92)",
            "ACTION_WARNING_BG": "rgb(255,246,220)",
            "ACTION_INFO_FG": "rgb(109,155,170)",
            "ACTION_INFO_BG": "rgb(226,243,249)",
            "ACTION_INACTIVE_FG": "rgb(170,170,170)",
            # Misc (Python-consumed)
            "ICON_COLOR": "rgb(220,220,220)",
            "LINK_COLOR": "rgb(130,170,210)",
            "LINK_VISITED_COLOR": "rgb(160,150,190)",
        },
        "dark": {
            # Surfaces
            "PANEL_BACKGROUND": "rgba(105,105,105,100)",
            "WINDOW_BACKGROUND": "rgba(100,100,100,200)",
            "WIDGET_BACKGROUND": "rgb(60,60,60)",
            "WIDGET_BACKGROUND_HOVER": "rgb(78,78,78)",
            "DISABLED_BACKGROUND": "rgb(85,85,85)",
            "ALTERNATE_BACKGROUND": "rgba(255,255,255,8)",
            "TREE_ALTERNATE_BG": "rgb(70,70,70)",
            # Text
            "TEXT_COLOR": "rgb(220,220,220)",
            "TEXT_HOVER": "rgb(255,255,255)",
            "TEXT_CHECKED": "rgb(255,255,255)",
            "TEXT_DISABLED": "rgb(150,150,150)",
            # Accents
            "BUTTON_HOVER": "rgba(100,130,150,225)",  # Desaturated blue
            "BUTTON_CHECKED": "rgba(165,135,100,225)",  # Further desaturated orange
            "PROGRESS_BAR_COLOR": "rgb(0,160,208)",
            # Borders + shape
            "BORDER_COLOR": "rgb(40,40,40)",
            "BORDER_HOVER": "rgba(255,255,255,110)",
            "BORDER_W": "0px",  # Dark theme defaults borderless for a softer look.
            "RADIUS": "1px",
            # Selection (text-selection inside inputs)
            "SELECTION_BG": "rgba(80,80,80,100)",
            "SELECTION_FG": "rgb(255,255,190)",
            # Status (input feedback)
            "ACTION_VALID_FG": "rgb(168,213,162)",
            "ACTION_VALID_BG": "rgb(30,46,30)",
            "ACTION_INVALID_FG": "rgb(232,165,163)",
            "ACTION_INVALID_BG": "rgb(51,32,31)",
            "ACTION_WARNING_FG": "rgb(224,201,127)",
            "ACTION_WARNING_BG": "rgb(51,46,32)",
            "ACTION_INFO_FG": "rgb(163,203,224)",
            "ACTION_INFO_BG": "rgb(30,46,51)",
            "ACTION_INACTIVE_FG": "rgb(119,119,119)",
            # Misc (Python-consumed)
            "ICON_COLOR": "rgb(220,220,220)",
            "LINK_COLOR": "rgb(130,170,210)",
            "LINK_VISITED_COLOR": "rgb(160,150,190)",
        },
    }

    # Token substitution: ``{TOKEN_NAME}`` where TOKEN_NAME is UPPER_SNAKE.
    # Anchored so QSS rule-block braces ``{`` followed by whitespace/newline
    # never match.
    _token_pat = re.compile(r"\{([A-Z_][A-Z0-9_]*)\}")

    _qss_cache: dict[str, str] = {}
    # Parsed-template cache: cache_key -> [literal, TOKEN, literal, TOKEN, ...].
    # Built once per (package, resource) on first load; assembly is then a
    # single ``''.join`` of dict lookups, replacing N full-string ``str.replace``
    # passes (one per token) with one pass.
    _template_cache: dict[str, list[str]] = {}
    # Track current theme per widget for icon color lookups
    _widget_themes: dict = {}
    # Track configuration for reloading
    _widget_configs: dict = {}
    # Track custom overrides
    _global_overrides: dict = {}
    _widget_overrides: dict = {}
    _settings = SettingsManager(
        org="uitk", app="GlobalStyle", namespace="overrides_v3"
    )  # v3: token-set cleanup (drops + renames + adds). v2 left on disk.
    _settings_loaded = False

    @classmethod
    def _ensure_settings_loaded(cls):
        """Lazy load settings from persistent storage."""
        if not cls._settings_loaded:
            stored_overrides = cls._settings.value("global", {})
            if stored_overrides and isinstance(stored_overrides, dict):
                cls._global_overrides.update(stored_overrides)
            # Initialize structure for known themes if missing
            for theme_name in cls.themes:
                if theme_name not in cls._global_overrides:
                    cls._global_overrides[theme_name] = {}
            cls._settings_loaded = True

    def __init__(
        self, parent: Union[QtWidgets.QWidget, None] = None, log_level: str = "WARNING"
    ):
        StyleSheet._ensure_settings_loaded()
        super().__init__(parent)
        self.logger.setLevel(log_level)
        self.set = self._set_style

    @classmethod
    def get_icon_color(cls, widget: QtWidgets.QWidget = None) -> str:
        """Get the icon color for a widget based on its current theme.

        Args:
            widget: The widget to get icon color for. If None, returns default.

        Returns:
            Hex color string for icons (e.g., "#ffffff")
        """
        if widget is not None:
            # Walk up the widget hierarchy to find a themed ancestor
            w = widget
            while w is not None:
                if w in cls._widget_themes:
                    theme_name = cls._widget_themes[w]
                    return cls.themes.get(theme_name, {}).get("ICON_COLOR", "#888888")
                w = w.parent() if hasattr(w, "parent") else None

        # Default fallback
        return "#888888"

    @classmethod
    def set_theme(cls, theme: str, widget: QtWidgets.QWidget = None):
        """Set a new theme for a specific widget or all registered widgets.

        Args:
            theme: Name of the theme to apply (e.g. "light", "dark")
            widget: Specific widget to update. If None, updates all registered widgets.
        """
        targets = [widget] if widget else list(cls._widget_configs.keys())

        for w in targets:
            if w in cls._widget_configs:
                cls._widget_configs[w]["theme"] = theme
                cls.reload(w)

    @classmethod
    def reload(cls, widget: QtWidgets.QWidget = None):
        """Reload the style for a specific widget or all registered widgets.

        Widgets are grouped by ``(theme, resource, package, kwargs)`` so each
        unique configuration's QSS is assembled exactly once per call — large
        registries with a shared theme pay the template-apply cost once, not
        N times. Widgets with per-widget overrides take the slow path since
        their theme_vars dict is unique.

        Args:
            widget: Specific widget to reload. If None, reloads all registered widgets.
        """
        targets = [widget] if widget else list(cls._widget_configs.keys())
        styler = cls()
        # Per-call cache: (theme, resource, package, frozenset(kwargs.items())) -> qss_final
        assembled: dict = {}

        for w in targets:
            if w not in cls._widget_configs:
                continue
            config = cls._widget_configs[w].copy()
            kwargs = config.pop("kwargs", {})

            # Per-widget overrides break sharing — fall through to the slow path.
            if w in cls._widget_overrides:
                try:
                    styler.set(w, **config, **kwargs)
                except RuntimeError:
                    cls._widget_configs.pop(w, None)
                continue

            key = (
                config["theme"],
                config["resource"],
                config["package"],
                frozenset(kwargs.items()),
            )
            qss_final = assembled.get(key)
            if qss_final is None:
                theme_vars = cls.themes.get(config["theme"], {}).copy()
                if config["theme"] in cls._global_overrides:
                    theme_vars.update(cls._global_overrides[config["theme"]])
                for k, v in kwargs.items():
                    if k in theme_vars:
                        theme_vars[k] = str(v)
                parts = cls._get_template(config["resource"], config["package"])
                qss_final = cls._apply_template(parts, theme_vars)
                assembled[key] = qss_final

            try:
                styler.set(w, **config, **kwargs, _qss_final=qss_final)
            except RuntimeError:
                cls._widget_configs.pop(w, None)

    @classmethod
    def clear_caches(cls) -> None:
        """Drop QSS + parsed-template caches.

        Call after editing ``style.qss`` during a dev session so the next
        ``reload()`` re-reads from disk and rebuilds its template.
        """
        cls._qss_cache.clear()
        cls._template_cache.clear()

    @classmethod
    def set_variable(
        cls,
        name: str,
        value: Union[str, QtGui.QColor, None],
        theme: str = "light",
        widget: QtWidgets.QWidget = None,
    ):
        """Set a theme variable override.

        Args:
            name: The variable name (e.g. "BUTTON_HOVER").
            value: The value. If None, the override is removed.
            theme: The theme to modify (e.g. "light"). Defaults to "light" for global fallback.
            widget: If provided, override only for this widget. Otherwise global for the theme.
        """
        cls._ensure_settings_loaded()
        if value is None:
            if widget:
                if (
                    widget in cls._widget_overrides
                    and name in cls._widget_overrides[widget]
                ):
                    del cls._widget_overrides[widget][name]
                    cls.reload(widget)
            else:
                if (
                    theme in cls._global_overrides
                    and name in cls._global_overrides[theme]
                ):
                    del cls._global_overrides[theme][name]
                    # Update settings
                    cls._settings.setValue("global", cls._global_overrides)
                    cls.reload()
            return

        val_str = value
        if hasattr(value, "name"):  # Handle QColor
            if value.alpha() == 255:
                # Use hex for opaque colors to keep strings short/readable
                val_str = value.name()
            else:
                val_str = f"rgba({value.red()},{value.green()},{value.blue()},{value.alpha()})"
        elif hasattr(value, "toRgb"):  # Handle other Qt color objects
            c = value.toRgb()
            if c.alpha() == 255:
                val_str = c.name()
            else:
                val_str = f"rgba({c.red()},{c.green()},{c.blue()},{c.alpha()})"
        elif not isinstance(value, str):
            val_str = str(value)

        if widget:
            if widget not in cls._widget_overrides:
                cls._widget_overrides[widget] = {}
                # Ensure cleanup
                try:
                    widget.destroyed.connect(
                        lambda obj: cls._widget_overrides.pop(obj, None)
                    )
                except (AttributeError, RuntimeError):
                    pass
            cls._widget_overrides[widget][name] = val_str
            cls.reload(widget)
        else:
            if theme not in cls._global_overrides:
                cls._global_overrides[theme] = {}
            cls._global_overrides[theme][name] = val_str
            # Update settings
            cls._settings.setValue("global", cls._global_overrides)
            cls.reload()

    @classmethod
    def get_variable(
        cls, name: str, theme: str = "light", widget: QtWidgets.QWidget = None
    ) -> str:
        """Get a theme variable value, resolving overrides.

        Args:
            name: Variable name.
            theme: Base theme name.
            widget: Context widget for checking overrides.
        """
        cls._ensure_settings_loaded()
        # Check widget override
        if widget and widget in cls._widget_overrides:
            if name in cls._widget_overrides[widget]:
                return cls._widget_overrides[widget][name]

        # Check global override for specific theme
        if theme in cls._global_overrides and name in cls._global_overrides[theme]:
            return cls._global_overrides[theme][name]

        # Check base theme
        return cls.themes.get(theme, {}).get(name, "")

    @classmethod
    def get_variables(cls, theme: str = "light") -> list[str]:
        """Get list of available theme variables."""
        return list(cls.themes.get(theme, {}).keys())

    @classmethod
    def export_overrides(cls) -> dict:
        """Export the current global overrides as a plain dict.

        Returns a deep copy of ``{theme_name: {var: value, ...}, ...}``
        suitable for JSON serialization.
        """
        cls._ensure_settings_loaded()
        import copy

        return copy.deepcopy(cls._global_overrides)

    @classmethod
    def import_overrides(cls, data: dict) -> None:
        """Bulk-replace global overrides from a dict and reload once.

        Args:
            data: A ``{theme_name: {var: value, ...}, ...}`` dict.
                  Keys not present in *data* are cleared.
        """
        cls._ensure_settings_loaded()
        cls._global_overrides.clear()
        for theme_name, overrides in data.items():
            if isinstance(overrides, dict):
                cls._global_overrides[theme_name] = dict(overrides)
        cls._settings.setValue("global", cls._global_overrides)
        cls.reload()

    @classmethod
    def reset_overrides(cls, widget: QtWidgets.QWidget = None):
        """Clear overrides.

        Args:
            widget: If provided, clear only this widget's overrides.
                    If None, clear ALL overrides (global and all widgets).
        """
        cls._ensure_settings_loaded()
        if widget:
            if widget in cls._widget_overrides:
                del cls._widget_overrides[widget]
                cls.reload(widget)
        else:
            cls._widget_overrides.clear()
            cls._global_overrides.clear()
            # Clear settings
            cls._settings.clear("global")
            cls.reload()

    @classmethod
    def _load_qss_file(
        cls, resource: str = "style.qss", package: str = "uitk.widgets.mixins"
    ) -> str:
        """Read a QSS resource from a package, caching the result.

        Classmethod (not instance method) so callers like ``_get_template``
        don't have to instantiate ``cls()`` — instance creation triggers
        ``_ensure_settings_loaded`` and QObject init for no benefit when
        all we need is the file contents.
        """
        cache_key = f"{package}:{resource}"
        if cache_key not in cls._qss_cache:
            try:
                with (
                    importlib.resources.files(package)
                    .joinpath(resource)
                    .open("r", encoding="utf-8") as f
                ):
                    cls._qss_cache[cache_key] = f.read()
            except Exception as e:
                _logger.error(f"Failed to load QSS from {package}/{resource} ({e})")
                raise
        return cls._qss_cache[cache_key]

    @classmethod
    def _get_template(
        cls, resource: str = "style.qss", package: str = "uitk.widgets.mixins"
    ) -> list[str]:
        """Return a parsed-template list for ``package/resource``.

        The list alternates literal chunks and token names:
        ``[literal, TOKEN, literal, TOKEN, ..., literal]``. Even indices are
        literals, odd indices are token names looked up against ``theme_vars``.
        """
        cache_key = f"{package}:{resource}"
        parts = cls._template_cache.get(cache_key)
        if parts is None:
            qss = cls._load_qss_file(resource, package)
            parts = cls._token_pat.split(qss)
            cls._template_cache[cache_key] = parts
        return parts

    @staticmethod
    def _apply_template(parts: list[str], theme_vars: dict) -> str:
        """Assemble a QSS string from a parsed template and a vars dict.

        Unknown tokens are left as ``{TOKEN}`` literals so missing vars are
        visible in the applied QSS rather than silently producing an empty
        substitution. Tokens inside commented-out QSS blocks are substituted
        too — harmless since the surrounding ``/* ... */`` still parses as
        a comment after substitution.
        """
        return "".join(
            p if i % 2 == 0 else theme_vars.get(p, "{" + p + "}")
            for i, p in enumerate(parts)
        )

    @staticmethod
    def _set_class_property(widget: QtWidgets.QWidget, style_class: str):
        widget.setProperty("class", style_class)
        if isinstance(widget, QtWidgets.QMainWindow) and widget.centralWidget():
            widget.centralWidget().setProperty("class", style_class)

    @ptk.listify
    def _set_style(
        self,
        widget: Union[QtWidgets.QWidget, None] = None,
        theme: str = "light",
        style_class: str = "",
        recursive: bool = False,
        resource: str = "style.qss",
        package: str = "uitk.widgets.mixins",
        _qss_final: Union[str, None] = None,
        **kwargs,
    ):
        """Apply a themed stylesheet to ``widget`` and register it for reloads.

        Args:
            widget: Target. Defaults to ``self.parent()`` if a QWidget.
            theme: Theme name (key of :attr:`themes`).
            style_class: Optional ``class`` property to set on the widget.
            recursive: If True, apply to every QWidget descendant.
            resource, package: Locate the QSS file via importlib.resources.
            _qss_final: **Internal.** Precomputed QSS string from
                :meth:`reload`'s group-by-config fast path. When supplied,
                template assembly is skipped — the widget must NOT have
                per-widget overrides (caller is responsible for filtering),
                otherwise the precomputed QSS won't reflect them.
            **kwargs: Per-call token overrides; keys matching theme vars
                replace those vars for this widget only (not persisted).
        """
        if widget is None:
            if isinstance(self.parent(), QtWidgets.QWidget):
                widget = self.parent()
            else:
                raise ValueError(
                    f"No valid QWidget found for styling (self={self}, parent={self.parent()})"
                )

        if not isinstance(widget, QtWidgets.QWidget):
            self.logger.error(f"Invalid datatype for widget: {type(widget)}")
            raise ValueError(f"Expected QWidget, got {type(widget)}.")

        if not style_class:
            default_class = getattr(widget, "_default_style_class", "")
            if default_class:
                style_class = default_class

        if style_class:
            self._set_class_property(widget, style_class)
            self.logger.debug(
                f"Set style class '{style_class}' on widget: {widget.objectName()}"
            )

        try:
            # Prepare theme variables with overrides
            theme_vars = self.themes.get(theme, {}).copy()
            # Apply global overrides for this theme
            if theme in self._global_overrides:
                theme_vars.update(self._global_overrides[theme])

            # Apply widget-specific overrides
            if widget in self._widget_overrides:
                theme_vars.update(self._widget_overrides[widget])
            # Apply kwargs overrides (if any match theme keys)
            for k, v in kwargs.items():
                if k in theme_vars:  # treat kwargs as overrides if they match keys
                    theme_vars[k] = str(v)

            # Reuse a precomputed QSS string if the caller (typically
            # ``reload()``) has already assembled it for our config group.
            if _qss_final is None:
                parts = self._get_template(resource, package)
                qss_final = self._apply_template(parts, theme_vars)
            else:
                qss_final = _qss_final
            self.logger.debug(
                f"Applying QSS to widget '{widget.objectName()}':\n---BEGIN QSS---\n{qss_final}\n---END QSS---"
            )
            widget.setStyleSheet(qss_final)
            self.logger.info(
                f"Applied QSS style to widget: {widget.objectName()} (theme='{theme}', class='{style_class}')"
            )

            # Track theme for this widget
            StyleSheet._widget_themes[widget] = theme

            # Track configuration for reloading
            if widget not in StyleSheet._widget_configs:
                try:
                    widget.destroyed.connect(
                        lambda obj: StyleSheet._widget_themes.pop(obj, None)
                    )
                    widget.destroyed.connect(
                        lambda obj: StyleSheet._widget_configs.pop(obj, None)
                    )
                except (AttributeError, RuntimeError):
                    pass

            StyleSheet._widget_configs[widget] = {
                "theme": theme,
                "style_class": style_class,
                "recursive": recursive,
                "resource": resource,
                "package": package,
                "kwargs": kwargs,
            }

            # Update default icon color and refresh icons for this widget tree
            # Use resolved color from theme_vars to ensure overrides are respected
            icon_color = theme_vars.get("ICON_COLOR", "#888888")
            from uitk.widgets.mixins.icon_manager import IconManager

            IconManager.set_default_color(icon_color)
            IconManager.update_widget_icons(widget, icon_color)

            # Emit signal for any custom handlers
            self.theme_changed.emit(widget, theme, theme_vars)

        except Exception as e:
            self.logger.error(
                f"Failed to apply QSS style to {widget.objectName()}: {e}"
            )
            raise

        if recursive:
            for child in widget.findChildren(QtWidgets.QWidget):
                self.logger.debug(
                    f"Recursively setting style on: {child.objectName()} ({type(child).__name__})"
                )
                self._set_style(
                    child,
                    theme=theme,
                    recursive=False,
                    resource=resource,
                    package=package,
                    **kwargs,
                )


# --------------------------------------------------------------------------------------------

if __name__ == "__main__":
    ...

# --------------------------------------------------------------------------------------------
# Notes
# --------------------------------------------------------------------------------------------
