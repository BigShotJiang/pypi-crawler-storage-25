"""Logs command — stream container logs from extension pods."""

from __future__ import annotations

import subprocess
from typing import Optional

import typer
from rich.console import Console

console = Console(stderr=True)


def run_logs(
    *,
    name: Optional[str] = None,
    service: Optional[str] = None,
    follow: bool = False,
    tail: Optional[int] = None,
) -> None:
    """Stream logs from extension pods."""
    from kamiwaza_sdk import KamiwazaClient
    from kamiwaza_sdk.exceptions import APIError, NotFoundError

    from kamiwaza_extensions.connections import ConnectionManager
    from kamiwaza_extensions.constants import EXTENSIONS_NAMESPACE, extract_user_id

    # Resolve connection + auth
    conn_mgr = ConnectionManager()
    connection = conn_mgr.get_active_connection()
    if connection is None:
        console.print(
            "[red]Error:[/red] No Kamiwaza connection. Run: [bold]kz-ext login <url>[/bold]"
        )
        raise typer.Exit(code=1)

    token = conn_mgr.get_token()
    if token is None:
        console.print("[red]Error:[/red] Token expired. Run: [bold]kz-ext login[/bold]")
        raise typer.Exit(code=1)

    # Resolve extension name
    if name is None:
        from kamiwaza_extensions.extension_detector import ExtensionDetector
        from kamiwaza_extensions.payload_builder import PayloadBuilder

        detector = ExtensionDetector()
        info = detector.detect()
        dev_name = PayloadBuilder.make_dev_name(
            info.name, user_id=extract_user_id(token.access_token)
        )
    else:
        dev_name = name

    # Try to get pod names via status endpoint
    from kamiwaza_extensions.constants import ssl_env_override

    pod_name = None
    with ssl_env_override(connection):
        client = KamiwazaClient(base_url=connection.url, api_key=token.access_token)
        try:
            status = client.extensions.get_extension_status(dev_name)
            # Find target pods
            for svc_status in status.services:
                if service and svc_status.name != service:
                    continue
                for pod in svc_status.pods:
                    if pod.phase in ("Running", "CrashLoopBackOff"):
                        pod_name = pod.name
                        break
                if pod_name:
                    break
        except NotFoundError as exc:
            console.print(f"[red]Error:[/red] Extension '{dev_name}' not found.")
            console.print("  Run: [bold]kz-ext dev[/bold] to deploy first.")
            raise typer.Exit(code=1) from exc
        except APIError as exc:
            if exc.status_code == 404:
                console.print(f"[red]Error:[/red] Extension '{dev_name}' not found.")
                console.print("  Run: [bold]kz-ext dev[/bold] to deploy first.")
                raise typer.Exit(code=1) from exc
            if exc.status_code in (405, 501):
                pass  # Status endpoint not supported — fall through to label selector
            else:
                console.print(f"[yellow]Warning:[/yellow] Status fetch failed: {exc}")
        except Exception as exc:
            console.print(f"[yellow]Warning:[/yellow] Status fetch failed: {exc}")

    # Build kubectl command
    cmd = ["kubectl", "logs", "-n", EXTENSIONS_NAMESPACE]

    if pod_name:
        cmd.append(pod_name)
    else:
        # Use label selector
        label = f"extensions.kamiwaza.io/deployment-id={dev_name}"
        if service:
            label += f",extensions.kamiwaza.io/service={service}"
        cmd.extend(["-l", label])

    if follow:
        cmd.append("--follow")
    if tail is not None:
        cmd.extend(["--tail", str(tail)])

    console.print(f"[dim]$ {' '.join(cmd)}[/dim]")

    try:
        result = subprocess.run(cmd, timeout=None if follow else 300)
        raise typer.Exit(code=result.returncode)
    except FileNotFoundError:
        console.print("[red]Error:[/red] kubectl not found. Install it to view logs.")
        raise typer.Exit(code=1)
    except KeyboardInterrupt:
        raise typer.Exit(code=0)
