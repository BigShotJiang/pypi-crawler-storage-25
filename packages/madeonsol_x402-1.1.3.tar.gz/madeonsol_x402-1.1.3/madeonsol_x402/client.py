"""MadeOnSol API client. Supports MadeOnSol API key (msk_) or x402 micropayments."""

from __future__ import annotations

import asyncio
from typing import Any

import httpx

BASE_URL = "https://madeonsol.com"


class MadeOnSolClient:
    """MadeOnSol Solana API client.

    Auth priority: api_key > private_key (x402).

    Args:
        api_key: MadeOnSol API key — get one free at https://madeonsol.com/developer. Preferred.
        private_key: Base58-encoded Solana private key for x402 USDC micropayments (AI agents).
        base_url: API base URL (default: https://madeonsol.com).
    """

    def __init__(
        self,
        private_key: str | None = None,
        base_url: str = BASE_URL,
        *,
        api_key: str | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._auth_mode: str = "none"
        self._auth_headers: dict[str, str] = {}
        self._x402: Any = None
        self._api_key = api_key
        self._rest_client: "MadeOnSolREST | None" = None

        if api_key:
            self._auth_mode = "madeonsol"
            self._auth_headers = {"Authorization": f"Bearer {api_key}"}
        elif private_key:
            self._auth_mode = "x402"
            from x402 import x402Client
            from x402.mechanisms.svm import KeypairSigner
            from x402.mechanisms.svm.exact.register import register_exact_svm_client
            self._x402 = x402Client()
            signer = KeypairSigner.from_base58(private_key)
            register_exact_svm_client(self._x402, signer)
        else:
            import sys
            sys.stderr.write(
                "\n[madeonsol-x402] Missing api_key or private_key.\n"
                "  → Get a free API key (200 req/day, no card) at https://madeonsol.com/developer\n"
                "  → Then: MadeOnSolClient(api_key=os.environ['MADEONSOL_API_KEY'])\n\n"
            )
            raise ValueError(
                "Provide api_key or private_key. "
                "Get a free API key at https://madeonsol.com/developer"
            )

    @property
    def rest(self) -> "MadeOnSolREST":
        """REST client for webhook management, streaming tokens, alpha intelligence,
        token quality, copy-trade rules, and wallet tracker.

        Lazily constructed from the same credentials as the parent client.
        Requires `api_key` (x402 mode is not supported for REST endpoints).
        """
        if self._rest_client is None:
            if self._api_key:
                self._rest_client = MadeOnSolREST(api_key=self._api_key, base_url=self.base_url)
            else:
                raise RuntimeError(
                    ".rest requires api_key — x402 mode does not support REST endpoints"
                )
        return self._rest_client

    def _resolve_path(self, path: str) -> str:
        if self._auth_mode == "madeonsol":
            return path.replace("/api/x402/", "/api/v1/")
        return path

    async def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        api_path = self._resolve_path(path)
        if self._auth_mode == "x402":
            from x402.http.clients import x402HttpxClient
            async with x402HttpxClient(self._x402) as http:
                resp = await http.get(f"{self.base_url}{api_path}", params=params)
                resp.raise_for_status()
                return resp.json()
        else:
            async with httpx.AsyncClient() as http:
                resp = await http.get(
                    f"{self.base_url}{api_path}",
                    params=params,
                    headers=self._auth_headers,
                )
                resp.raise_for_status()
                return resp.json()

    def _get_sync(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop and loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(asyncio.run, self._get(path, params)).result()
        return asyncio.run(self._get(path, params))

    # ── Endpoints ──

    def kol_feed(
        self,
        *,
        limit: int = 50,
        action: str | None = None,
        kol: str | None = None,
        min_sol: float | None = None,
        token_age_max_min: int | None = None,
        exclude_sells: bool | None = None,
        min_kol_winrate: float | None = None,
        strategy: str | None = None,
    ) -> dict[str, Any]:
        """Real-time KOL trade feed from 1,000+ wallets.

        Args:
            limit: Max trades to return.
            action: Filter by 'buy' or 'sell'.
            kol: Filter by KOL handle/name.
            min_sol: PRO+ — minimum SOL size per trade.
            token_age_max_min: PRO+ — max token age in minutes at trade time.
            exclude_sells: PRO+ — drop sell-side trades.
            min_kol_winrate: PRO+ — minimum 7d winrate of the KOL (0-100).
            strategy: PRO+ — 'sniper', 'flipper', 'swinger', 'holder', or 'mixed'.
        """
        params: dict[str, Any] = {"limit": limit}
        if action:
            params["action"] = action
        if kol:
            params["kol"] = kol
        if min_sol is not None:
            params["min_sol"] = min_sol
        if token_age_max_min is not None:
            params["token_age_max_min"] = token_age_max_min
        if exclude_sells:
            params["exclude_sells"] = "true"
        if min_kol_winrate is not None:
            params["min_kol_winrate"] = min_kol_winrate
        if strategy:
            params["strategy"] = strategy
        return self._get_sync("/api/x402/kol/feed", params)

    def kol_coordination(
        self,
        *,
        period: str = "24h",
        min_kols: int = 3,
        limit: int = 20,
        min_avg_winrate: float | None = None,
        unique_strategies: int | None = None,
        include_majors: bool | None = None,
        window_minutes: int | None = None,
        min_score: int | None = None,
    ) -> dict[str, Any]:
        """KOL convergence signals (v1.1 — peak-density + score).

        Args:
            period: '1h', '6h', '24h', or '7d'.
            min_kols: Minimum KOLs in a cluster.
            limit: Max clusters to return.
            min_avg_winrate: PRO+ — require cluster avg winrate_7d >= N (0-100).
            unique_strategies: PRO+ — require cluster to span >= N strategies.
            include_majors: v1.1 — include WIF/BONK/POPCAT etc. Default False.
            window_minutes: v1.1 — peak-density window size (1-60). Default 15.
            min_score: v1.1 — minimum composite coordination score (0-100).

        Response (v1.1): each token includes peak_window_start/end, peak_kols,
        peak_buys, exited_count, holders_count, coordination_score, and per-KOL
        buy_sol/sell_sol/exited (PRO+).
        """
        params: dict[str, Any] = {"period": period, "min_kols": min_kols, "limit": limit}
        if min_avg_winrate is not None:
            params["min_avg_winrate"] = min_avg_winrate
        if unique_strategies is not None:
            params["unique_strategies"] = unique_strategies
        if include_majors is not None:
            params["include_majors"] = "true" if include_majors else "false"
        if window_minutes is not None:
            params["window_minutes"] = window_minutes
        if min_score is not None:
            params["min_score"] = min_score
        return self._get_sync("/api/x402/kol/coordination", params)

    def kol_leaderboard(
        self,
        *,
        period: str = "7d",
        limit: int = 20,
        sort: str | None = None,
        strategy: str | None = None,
        min_winrate: float | None = None,
    ) -> dict[str, Any]:
        """KOL PnL/win-rate rankings.

        Args:
            period: One of 'today', '7d', '30d', '90d', '180d'. Trade history is
                retained for 180 days; long windows fill up over time.
            limit: Max KOLs to return.
            sort: PRO+ — 'pnl' (default), 'winrate', 'profit_factor', 'roi', or 'early_entry'.
            strategy: PRO+ — filter by 'sniper', 'flipper', 'swinger', 'holder', 'mixed'.
            min_winrate: PRO+ — minimum winrate cutoff (0-100).
        """
        params: dict[str, Any] = {"period": period, "limit": limit}
        if sort:
            params["sort"] = sort
        if strategy:
            params["strategy"] = strategy
        if min_winrate is not None:
            params["min_winrate"] = min_winrate
        return self._get_sync("/api/x402/kol/leaderboard", params)

    def deployer_alerts(
        self,
        *,
        limit: int = 20,
        since: str | None = None,
        offset: int = 0,
        tier: str | None = None,
    ) -> dict[str, Any]:
        """Pump.fun deployer alerts with KOL buy enrichment.

        Args:
            limit: Max alerts to return.
            since: Optional ISO8601 timestamp — only alerts created after this.
            offset: Pagination offset.
            tier: Filter by deployer tier ('elite', 'good', 'moderate', 'rising',
                'cold'). **PRO/ULTRA subscribers only** — BASIC callers passing
                this receive HTTP 403.
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if since:
            params["since"] = since
        if tier:
            params["tier"] = tier
        return self._get_sync("/api/x402/deployer-hunter/alerts", params)

    def kol_pairs(
        self, *, period: str = "7d", min_shared: int = 3, limit: int = 20
    ) -> dict[str, Any]:
        """KOL affinity matrix — which KOLs co-trade the same tokens."""
        return self._get_sync("/api/x402/kol/pairs", {
            "period": period, "min_shared": min_shared, "limit": limit,
        })

    def kol_hot_tokens(
        self,
        *,
        period: str = "6h",
        min_kols: int = 1,
        limit: int = 20,
        min_avg_winrate: float | None = None,
        unique_strategies: int | None = None,
    ) -> dict[str, Any]:
        """KOL momentum tokens — accelerating KOL buy interest.

        Args:
            period: '1h' or '6h'.
            min_kols: Minimum distinct KOL buyers.
            limit: Max tokens to return.
            min_avg_winrate: PRO+ — require avg winrate_7d of buyers >= N (0-100).
            unique_strategies: PRO+ — require >= N distinct strategies among buyers.
        """
        params: dict[str, Any] = {"period": period, "min_kols": min_kols, "limit": limit}
        if min_avg_winrate is not None:
            params["min_avg_winrate"] = min_avg_winrate
        if unique_strategies is not None:
            params["unique_strategies"] = unique_strategies
        return self._get_sync("/api/x402/kol/tokens/hot", params)

    def kol_trending_tokens(
        self, *, period: str = "1h", min_kols: int = 1, limit: int = 20
    ) -> dict[str, Any]:
        """Tokens ranked by KOL buy volume. Sub-hour periods require PRO/ULTRA."""
        return self._get_sync("/api/x402/kol/tokens/trending", {
            "period": period, "min_kols": min_kols, "limit": limit,
        })

    def kol_token_entry_order(
        self, mint: str, *, limit: int = 50
    ) -> dict[str, Any]:
        """Ranked KOL first-buyers for a token.

        Returns each KOL's first buy ordered by traded_at, with seconds_after_first
        relative to the first KOL entry. PRO+ adds percentile_pnl_7d per entry.
        """
        return self._get_sync(
            f"/api/x402/kol/tokens/{mint}/entry-order", {"limit": limit}
        )

    def kol_compare_wallets(self, wallets: list[str]) -> dict[str, Any]:
        """Side-by-side comparison of 2-5 KOL wallets.

        Args:
            wallets: 2-5 wallet addresses. BASIC=2, PRO=4, ULTRA=5.
        PRO+ adds an `overlap` list of tokens bought by 2+ of the wallets in 30d.
        """
        return self._get_sync("/api/x402/kol/compare", {"wallets": ",".join(wallets)})

    def kol_alerts_recent(
        self,
        *,
        window: str = "15m",
        types: list[str] | None = None,
        min_severity: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Live KOL alert feed.

        Args:
            window: '5m', '15m', '1h', '6h', or '24h'. Default '15m'.
            types: Subset of 'consensus_cluster', 'fresh_token_kol_buy', 'heating_up'.
            min_severity: 'low', 'medium', or 'high'.
            limit: Max alerts to return.
        """
        params: dict[str, Any] = {"window": window, "limit": limit}
        if types:
            params["types"] = ",".join(types)
        if min_severity:
            params["min_severity"] = min_severity
        return self._get_sync("/api/x402/kol/alerts/recent", params)

    def discovery(self) -> dict[str, Any]:
        """Free — list all endpoints and prices."""
        resp = httpx.get(f"{self.base_url}/api/x402")
        resp.raise_for_status()
        return resp.json()


class MadeOnSolREST:
    """REST API client for the full v1 surface — webhooks, streaming, alpha
    intelligence, token quality, copy-trade rules, wallet tracker.

    Args:
        api_key: MadeOnSol API key (msk_...). Required.
        base_url: API base URL (default: https://madeonsol.com).

    The most recent response's rate-limit headers are exposed via `last_rate_limit`:
        {'limit': int|None, 'remaining': int|None, 'reset': int|None, 'request_id': str|None}
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = BASE_URL,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        if not api_key:
            import sys
            sys.stderr.write(
                "\n[madeonsol-x402] MadeOnSolREST: missing api_key.\n"
                "  → Get a free key (200 req/day, no card) at https://madeonsol.com/developer\n\n"
            )
            raise ValueError(
                "Provide api_key. Get a free API key at https://madeonsol.com/developer"
            )
        if not api_key.startswith("msk_"):
            raise ValueError(
                "api_key must start with 'msk_'. Get one at https://madeonsol.com/developer"
            )
        self._headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        }
        self.last_rate_limit: dict[str, Any] = {
            "limit": None, "remaining": None, "reset": None, "request_id": None,
        }

    def _capture_rate_limit(self, resp: httpx.Response) -> None:
        def _to_int(v: str | None) -> int | None:
            if v is None:
                return None
            try:
                return int(v)
            except (ValueError, TypeError):
                return None
        self.last_rate_limit = {
            "limit":      _to_int(resp.headers.get("x-ratelimit-limit")),
            "remaining":  _to_int(resp.headers.get("x-ratelimit-remaining")),
            "reset":      _to_int(resp.headers.get("x-ratelimit-reset")),
            "request_id": resp.headers.get("x-request-id"),
        }

    def _request(
        self,
        method: str,
        path: str,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        resp = httpx.request(
            method,
            f"{self.base_url}/api/v1{path}",
            headers=self._headers,
            json=json_body,
            params=params,
        )
        self._capture_rate_limit(resp)
        resp.raise_for_status()
        return resp.json()

    # ── Webhooks ──

    def create_webhook(
        self,
        *,
        url: str,
        events: list[str],
        filters: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Register a webhook. Returns webhook with HMAC secret (shown once)."""
        body: dict[str, Any] = {"url": url, "events": events}
        if filters:
            body["filters"] = filters
        return self._request("POST", "/webhooks", body)

    def list_webhooks(self) -> dict[str, Any]:
        """List all your registered webhooks."""
        return self._request("GET", "/webhooks")

    def get_webhook(self, webhook_id: int) -> dict[str, Any]:
        """Get webhook detail with recent delivery log."""
        return self._request("GET", f"/webhooks/{webhook_id}")

    def update_webhook(self, webhook_id: int, **kwargs: Any) -> dict[str, Any]:
        """Update a webhook (url, events, filters, is_active)."""
        return self._request("PATCH", f"/webhooks/{webhook_id}", kwargs)

    def delete_webhook(self, webhook_id: int) -> dict[str, Any]:
        """Delete a webhook permanently."""
        return self._request("DELETE", f"/webhooks/{webhook_id}")

    def test_webhook(self, webhook_id: int) -> dict[str, Any]:
        """Send a test payload to verify a webhook URL."""
        return self._request("POST", "/webhooks/test", {"webhook_id": webhook_id})

    # ── KOL/deployer detail ──

    def kol_pnl(self, wallet: str, *, period: str = "30d") -> dict[str, Any]:
        """Deep per-wallet PnL: equity curve, risk metrics, positions."""
        return self._request("GET", f"/kol/{wallet}/pnl", params={"period": period})

    def kol_timing(self, wallet: str, *, period: str = "30d") -> dict[str, Any]:
        """KOL entry/exit timing profile — hold duration, exit speed, patterns."""
        return self._request("GET", f"/kol/{wallet}/timing", params={"period": period})

    def deployer_trajectory(self, wallet: str) -> dict[str, Any]:
        """Deployer skill curve — streaks, rolling bond rate, trend."""
        return self._request("GET", f"/deployer-hunter/{wallet}/trajectory")

    # ── Streaming ──

    def get_stream_token(self) -> dict[str, Any]:
        """Generate a 24h WebSocket streaming token."""
        return self._request("POST", "/stream/token")

    # ── Alpha Wallet Intelligence ──

    def alpha_leaderboard(
        self,
        *,
        period: str = "30d",
        min_tokens: int = 5,
        sort: str = "win_rate",
        exclude_bots: bool = True,
    ) -> dict[str, Any]:
        """Top statistically profitable early-buyer wallets.

        Args:
            period: '7d', '30d', or 'all'.
            min_tokens: 1–20 — minimum tokens traded by the wallet.
            sort: 'win_rate', 'pnl', or 'roi'.
            exclude_bots: Exclude wallets flagged as bots.

        BASIC: 25 results, truncated wallets, rounded values.
        PRO: 100 results, full wallets + extended stats.
        ULTRA: 500 results + bot_confidence + behavioral signals.
        """
        return self._request("GET", "/alpha/leaderboard", params={
            "period": period,
            "min_tokens": min_tokens,
            "sort": sort,
            "exclude_bots": "true" if exclude_bots else "false",
        })

    def alpha_wallet(self, wallet: str) -> dict[str, Any]:
        """Full alpha profile for one wallet — per-token breakdown + bot signals.

        ULTRA only.
        """
        return self._request("GET", f"/alpha/{wallet}")

    def alpha_linked(self, wallet: str) -> dict[str, Any]:
        """Wallets behaviorally linked to this one (co-bought 3+ tokens within 2s).

        ULTRA only.
        """
        return self._request("GET", f"/alpha/{wallet}/linked")

    # ── Token Quality ──

    def token_cap_table(self, mint: str) -> dict[str, Any]:
        """First non-deployer early buyers for a token, enriched with PnL/KOL/bot flags.

        BASIC: 403. PRO: top 10, truncated wallets. ULTRA: top 20, full wallets.
        """
        return self._request("GET", f"/tokens/{mint}/cap-table")

    def token_buyer_quality(self, mint: str) -> dict[str, Any]:
        """0–100 buyer-quality score for a token's first-buyer cohort.

        BASIC: score + signal only. PRO/ULTRA: full breakdown.
        Cached for 5 minutes per mint.
        """
        return self._request("GET", f"/tokens/{mint}/buyer-quality")

    # ── Copy-Trade (PRO/ULTRA) ──

    def copy_trade_list(self) -> dict[str, Any]:
        """List your copy-trade rules."""
        return self._request("GET", "/copytrade/subscriptions")

    def copy_trade_create(
        self,
        *,
        source_wallets: list[str],
        sizing_amount: float,
        name: str | None = None,
        min_trade_sol: float | None = None,
        only_action: str | None = None,
        sizing_mode: str | None = None,
        delivery_mode: str | None = None,
        webhook_url: str | None = None,
    ) -> dict[str, Any]:
        """Create a copy-trade rule. Returns webhook_secret ONCE — store it.

        Args:
            source_wallets: Wallets to follow. PRO=5/rule, ULTRA=50/rule.
            sizing_amount: Amount used by the chosen sizing_mode.
            name: Optional human label.
            min_trade_sol: Minimum source-wallet trade size to fire a signal.
            only_action: 'buy', 'sell', or 'both' (default 'both').
            sizing_mode: 'fixed', 'proportional', or 'percent_source'.
            delivery_mode: 'webhook', 'websocket', or 'both'.
            webhook_url: Required when delivery_mode includes 'webhook'.
        """
        body: dict[str, Any] = {
            "source_wallets": source_wallets,
            "sizing_amount": sizing_amount,
        }
        if name is not None: body["name"] = name
        if min_trade_sol is not None: body["min_trade_sol"] = min_trade_sol
        if only_action is not None: body["only_action"] = only_action
        if sizing_mode is not None: body["sizing_mode"] = sizing_mode
        if delivery_mode is not None: body["delivery_mode"] = delivery_mode
        if webhook_url is not None: body["webhook_url"] = webhook_url
        return self._request("POST", "/copytrade/subscriptions", body)

    def copy_trade_get(self, subscription_id: int) -> dict[str, Any]:
        """Get one copy-trade rule by id."""
        return self._request("GET", f"/copytrade/subscriptions/{subscription_id}")

    def copy_trade_update(self, subscription_id: int, **kwargs: Any) -> dict[str, Any]:
        """Update a copy-trade rule.

        Accepts: name, source_wallets, min_trade_sol, only_action, sizing_mode,
        sizing_amount, delivery_mode, webhook_url, is_active.
        """
        return self._request("PATCH", f"/copytrade/subscriptions/{subscription_id}", kwargs)

    def copy_trade_delete(self, subscription_id: int) -> dict[str, Any]:
        """Delete a copy-trade rule permanently."""
        return self._request("DELETE", f"/copytrade/subscriptions/{subscription_id}")

    def copy_trade_signals(
        self,
        *,
        subscription_id: int | None = None,
        since: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Recent fired copy-trade signals (up to 7 days).

        Args:
            subscription_id: Filter to one rule.
            since: ISO8601 timestamp — only signals fired at-or-after this time.
            limit: 1–500. Default 50.
        """
        params: dict[str, Any] = {"limit": limit}
        if subscription_id is not None:
            params["subscription_id"] = subscription_id
        if since:
            params["since"] = since
        return self._request("GET", "/copytrade/signals", params=params)

    # ── Coordination Alerts (PRO/ULTRA) ──

    def coordination_alerts_list(self) -> dict[str, Any]:
        """List your coordination alert rules."""
        return self._request("GET", "/kol/coordination/alerts")

    def coordination_alerts_create(
        self,
        *,
        name: str | None = None,
        min_kols: int | None = None,
        window_minutes: int | None = None,
        min_score: int | None = None,
        include_majors: bool | None = None,
        cooldown_min: int | None = None,
        score_jump_break: int | None = None,
        delivery_mode: str | None = None,
        webhook_url: str | None = None,
    ) -> dict[str, Any]:
        """Create a coordination alert rule. Returns webhook_secret ONCE — store it.

        Args:
            name: Optional label.
            min_kols: Minimum distinct KOLs in the window (default 3).
            window_minutes: Peak-density window (1-60, default 15).
            min_score: Minimum composite score 0-100 (default 60).
            include_majors: Include WIF/BONK/POPCAT etc (default False).
            cooldown_min: Silence per (rule, token) in minutes (default 60).
            score_jump_break: Re-fire early when score jumps by N (default 10).
            delivery_mode: 'websocket', 'webhook', or 'both'.
            webhook_url: Required when delivery_mode includes 'webhook'.

        PRO=5 rules, ULTRA=20.
        """
        body: dict[str, Any] = {}
        if name is not None: body["name"] = name
        if min_kols is not None: body["min_kols"] = min_kols
        if window_minutes is not None: body["window_minutes"] = window_minutes
        if min_score is not None: body["min_score"] = min_score
        if include_majors is not None: body["include_majors"] = include_majors
        if cooldown_min is not None: body["cooldown_min"] = cooldown_min
        if score_jump_break is not None: body["score_jump_break"] = score_jump_break
        if delivery_mode is not None: body["delivery_mode"] = delivery_mode
        if webhook_url is not None: body["webhook_url"] = webhook_url
        return self._request("POST", "/kol/coordination/alerts", body)

    def coordination_alerts_get(self, rule_id: str) -> dict[str, Any]:
        """Get one coordination alert rule by id."""
        return self._request("GET", f"/kol/coordination/alerts/{rule_id}")

    def coordination_alerts_update(self, rule_id: str, **kwargs: Any) -> dict[str, Any]:
        """Update a coordination alert rule.

        Accepts: name, min_kols, window_minutes, min_score, include_majors,
        cooldown_min, score_jump_break, delivery_mode, webhook_url, is_active.
        """
        return self._request("PATCH", f"/kol/coordination/alerts/{rule_id}", kwargs)

    def coordination_alerts_delete(self, rule_id: str) -> dict[str, Any]:
        """Delete a coordination alert rule permanently."""
        return self._request("DELETE", f"/kol/coordination/alerts/{rule_id}")

    # ── Wallet Tracker ──

    def wallet_tracker_watchlist(self) -> dict[str, Any]:
        """List tracked wallets with labels and remaining capacity."""
        return self._request("GET", "/wallet-tracker/watchlist")

    def wallet_tracker_add(self, wallet_address: str, *, label: str | None = None) -> dict[str, Any]:
        """Add a wallet to your watchlist.

        Args:
            wallet_address: Solana wallet address to track.
            label: Optional human-readable label.
        Returns HTTP 409 if already tracked or tier limit reached.
        Limits: BASIC=10, PRO=50, ULTRA=100.
        """
        body: dict[str, Any] = {"wallet_address": wallet_address}
        if label is not None:
            body["label"] = label
        return self._request("POST", "/wallet-tracker/watchlist", body)

    def wallet_tracker_remove(self, wallet_address: str) -> dict[str, Any]:
        """Remove a wallet from your watchlist."""
        return self._request("DELETE", f"/wallet-tracker/watchlist/{wallet_address}")

    def wallet_tracker_update_label(self, wallet_address: str, label: str | None) -> dict[str, Any]:
        """Update the label for a tracked wallet. Pass None to clear."""
        return self._request("PATCH", f"/wallet-tracker/watchlist/{wallet_address}", {"label": label})

    def wallet_tracker_trades(
        self,
        *,
        wallet: str | None = None,
        action: str | None = None,
        event_type: str | None = None,
        limit: int = 50,
        before: int | None = None,
    ) -> dict[str, Any]:
        """Historical swap/transfer events for all watched wallets.

        Args:
            wallet: Filter to a specific wallet address.
            action: Filter by action ('buy', 'sell', 'transfer_in', 'transfer_out').
            event_type: Filter by event type ('swap' or 'transfer').
            limit: Max results (1–200). Default: 50.
            before: Pagination cursor — block_time of the last event from previous page.
        BASIC: truncated wallets, no tx_signature, no counterparty.
        """
        params: dict[str, Any] = {"limit": limit}
        if wallet:
            params["wallet"] = wallet
        if action:
            params["action"] = action
        if event_type:
            params["event_type"] = event_type
        if before is not None:
            params["before"] = before
        return self._request("GET", "/wallet-tracker/trades", params=params)

    def wallet_tracker_summary(
        self,
        *,
        period: str = "7d",
        wallet: str | None = None,
    ) -> dict[str, Any]:
        """Per-wallet stats (swap counts, SOL bought/sold, last activity).

        Args:
            period: Time window — '24h', '7d', or '30d'. Default: '7d'.
            wallet: Filter to a specific wallet address.
        """
        params: dict[str, Any] = {"period": period}
        if wallet:
            params["wallet"] = wallet
        return self._request("GET", "/wallet-tracker/summary", params=params)
