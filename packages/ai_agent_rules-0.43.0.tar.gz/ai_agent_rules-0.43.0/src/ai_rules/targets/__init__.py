"""Config target base classes."""
