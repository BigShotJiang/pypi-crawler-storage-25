"""AI tool implementations."""
