@~/AGENTS.md
