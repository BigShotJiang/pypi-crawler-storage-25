"""
x-agent-trust v0.1.0

CyberSecAI-maintained entry point for "x-agent-trust" on PyPI.
Canonical implementation: https://www.npmjs.com/package/x-agent-trust

(c) 2026 CyberSecAI Ltd. Apache 2.0.
"""

META = {
    "name": "x-agent-trust",
    "description": """Reference implementation of the x-agent-trust signing scheme (ECDSA P-256). OpenAPI Extensions Registry registered. IETF draft-sharif-agent-payment-trust.""",
    "publisher": "CyberSecAI Ltd",
    "homepage": "https://agentpass.co.uk",
    "canonical_implementation": "https://www.npmjs.com/package/x-agent-trust",
    "standards": {
        "openapi_registry": "https://spec.openapis.org/registry/extension/x-agent-trust.html",
        "ietf_agent_payment": "https://datatracker.ietf.org/doc/draft-sharif-agent-payment-trust/",
        "ietf_mcps": "https://datatracker.ietf.org/doc/draft-sharif-mcps-secure-mcp/",
    },
}


def info():
    """Return package metadata."""
    return META


__version__ = "0.1.0"
__all__ = ["info", "META", "__version__"]
