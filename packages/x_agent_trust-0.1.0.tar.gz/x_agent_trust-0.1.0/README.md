# x-agent-trust

Reference implementation of the x-agent-trust signing scheme (ECDSA P-256). OpenAPI Extensions Registry registered. IETF draft-sharif-agent-payment-trust.

CyberSecAI-maintained entry point for `x-agent-trust` on PyPI. Canonical implementation at [https://www.npmjs.com/package/x-agent-trust](https://www.npmjs.com/package/x-agent-trust).

```python
import x_agent_trust
print(x_agent_trust.META)
```

## Related packages

- [mcp-secure on PyPI](https://pypi.org/project/mcp-secure/) -- MCP transport boundary security (BSL 1.1)
- [x-agent-trust on npm](https://www.npmjs.com/package/x-agent-trust) -- reference signing primitive (Apache 2.0)
- [agentpass-demo-mcp on npm](https://www.npmjs.com/package/agentpass-demo-mcp) -- demo MCP payment server (Apache 2.0)

## Standards

- OpenAPI Extensions Registry: x-agent-trust
- IETF draft-sharif-agent-payment-trust
- IETF draft-sharif-mcps-secure-mcp

## Maintainer

Raza Sharif, FBCS, CISSP, CSSLP. CyberSecAI Ltd -- contact@agentsign.dev

## Licence

Apache 2.0.
