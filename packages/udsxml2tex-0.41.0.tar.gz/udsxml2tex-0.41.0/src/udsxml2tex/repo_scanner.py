"""Auto-discover UDS-relevant ARXML and C source files inside a BSW repository.

Given the root directory of a software project, this module walks the tree,
classifies every ``*.arxml`` file by which AUTOSAR module(s) it contains
(``Dcm`` / ``CanTp`` / ``Dem`` / ``DoIp``), collects ``*.c`` / ``*.cpp`` /
``*.cc`` / ``*.cxx`` files that may host ``DcmAppl_*`` / ``Rte_*`` callbacks,
groups the result into per-ECU buckets when the repository hosts more than
one ECU, and produces a :class:`RepoScanResult` describing exactly what
udsxml2tex will consume.

The minimum-required modules to render a UDS-on-CAN specification are
``Dcm`` (ISO 14229-1 + 14229-2), ``CanTp`` (ISO 15765-2) and ``Dem``
(ISO 14229-1 §11 + Annex C/D). See ``docs/standards/required-arxmls.md``.

Public entry points
-------------------

* :func:`scan_repo`           — walk a directory, classify each ARXML, return
                                a :class:`RepoScanResult`.
* :func:`classify_arxml`      — classify a single ARXML by the modules it
                                contains; returns a frozenset of module names.
* :func:`partition_by_ecu`    — group discovered ARXMLs into per-ECU buckets
                                using the top-level subdirectory under
                                ``scan.root`` as the partitioning key.
* :func:`detect_ecu_mode`     — return ``"single"`` or ``"multi"`` based on
                                whether the partition produces ≥2 ECUs.
* :func:`load_from_repo`      — convenience wrapper that runs ``scan_repo``
                                and then parses every discovered file into a
                                fully-populated :class:`UdsSpecification`.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Iterable, Optional

from lxml import etree

if TYPE_CHECKING:
    from udsxml2tex.models import UdsSpecification


logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Module recognition
# ---------------------------------------------------------------------------

# Modules udsxml2tex actively consumes. Each entry maps the canonical module
# name (the one we report) to the substring matched against the
# ``ECUC-MODULE-CONFIGURATION-VALUES/SHORT-NAME`` value (case-sensitive — the
# AUTOSAR meta-model defines these names verbatim).
_KNOWN_MODULES: tuple[str, ...] = ("Dcm", "CanTp", "Dem", "DoIp")

# Directories we should never descend into. Keeps walks fast on real BSW
# projects which often vendor in massive third-party trees.
_SKIP_DIRS: frozenset[str] = frozenset({
    ".git", ".hg", ".svn",
    "node_modules", "__pycache__",
    ".venv", "venv", ".tox",
    "build", "dist", ".cache",
    ".idea", ".vscode",
})

_C_EXTENSIONS: tuple[str, ...] = (".c", ".cpp", ".cc", ".cxx")
_C_HEADER_EXTENSIONS: tuple[str, ...] = (".h", ".hpp", ".hh", ".hxx")


# Identifiers whose presence in a C file makes it interesting to udsxml2tex.
# scan_did_variables/scan_rid_variables will reject files that do not host
# any referenced handler, but pre-filtering keeps the C-scan pass off
# vendored libraries on big trees. The list covers the AUTOSAR Dcm callout
# conventions as well as the Did_/Rid_/_ReadData/_WriteData naming used by
# udsxml2tex's bundled samples.
_UDS_C_TOKENS: tuple[str, ...] = (
    "DcmAppl_",
    "Dcm_Read",
    "Dcm_Write",
    "Dcm_RoutineControl",
    "Rte_Call_Dcm",
    "RteCallDcm",
    "ReadDataByIdentifier",
    "WriteDataByIdentifier",
    "RoutineControl",
    "_ReadData",
    "_WriteData",
    "_RoutineControl_Start",
    "_RoutineControl_Stop",
    "_RoutineControl_RequestResults",
    "Did_0x",
    "Rid_0x",
)


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------

@dataclass
class EcuPartition:
    """ARXMLs and C files that belong to a single ECU within the repository.

    Produced by :func:`partition_by_ecu`. The :attr:`name` is derived from
    the top-level subdirectory under the repo root that the Dcm ARXML
    lives in — or from the Dcm SHORT-NAME, or from the file stem when the
    repository has a flat layout. It is stable enough to use as an ECU
    identifier in multi-ECU mode.
    """

    name: str
    dcm_arxmls: list[Path] = field(default_factory=list)
    cantp_arxmls: list[Path] = field(default_factory=list)
    dem_arxmls: list[Path] = field(default_factory=list)
    doip_arxmls: list[Path] = field(default_factory=list)
    c_files: list[Path] = field(default_factory=list)

    @property
    def has_minimum_set(self) -> bool:
        return bool(self.dcm_arxmls and self.cantp_arxmls and self.dem_arxmls)


@dataclass
class RepoScanResult:
    """Outcome of a repository scan.

    The ARXML lists are deduplicated — a single file containing both ``Dcm``
    and ``CanTp`` appears in both ``dcm_arxmls`` *and* ``cantp_arxmls`` so a
    caller can decide whether to invoke the corresponding parser. The
    :func:`load_from_repo` wrapper handles deduplication automatically.
    """

    root: Path

    # ARXML files, classified by which AUTOSAR module they contain.
    # A single file may appear in more than one list.
    dcm_arxmls: list[Path] = field(default_factory=list)
    cantp_arxmls: list[Path] = field(default_factory=list)
    dem_arxmls: list[Path] = field(default_factory=list)
    doip_arxmls: list[Path] = field(default_factory=list)

    # ARXMLs whose <AUTOSAR> root was parseable but contain no recognised
    # ECUC module — e.g. communication / topology / port-interface files.
    other_arxmls: list[Path] = field(default_factory=list)

    # ARXMLs that could not be parsed (invalid XML / non-AUTOSAR root).
    unparseable_arxmls: list[tuple[Path, str]] = field(default_factory=list)

    # C/C++ source and header files we collected for the DID / RID scanner.
    c_files: list[Path] = field(default_factory=list)

    # Per-file classification (resolved Path → frozenset of module names).
    # Useful for diagnostics ("which file did module X come from?").
    classifications: dict[Path, frozenset[str]] = field(default_factory=dict)

    # Files matching a `.cls` extension found anywhere under the root, in
    # case the project ships its own LaTeX class file. Selection is left to
    # the caller — udsxml2tex never auto-loads a `.cls`.
    cls_files: list[Path] = field(default_factory=list)

    @property
    def has_minimum_set(self) -> bool:
        """True when at least one Dcm + one CanTp + one Dem ARXML was found."""
        return bool(self.dcm_arxmls and self.cantp_arxmls and self.dem_arxmls)

    @property
    def missing_modules(self) -> list[str]:
        """Names of minimum-set modules absent from the scan."""
        missing: list[str] = []
        if not self.dcm_arxmls:
            missing.append("Dcm")
        if not self.cantp_arxmls:
            missing.append("CanTp")
        if not self.dem_arxmls:
            missing.append("Dem")
        return missing

    def summary(self) -> str:
        """Human-readable one-paragraph scan summary."""
        return (
            f"Repo scan rooted at {self.root}: "
            f"{len(self.dcm_arxmls)} Dcm, "
            f"{len(self.cantp_arxmls)} CanTp, "
            f"{len(self.dem_arxmls)} Dem, "
            f"{len(self.doip_arxmls)} DoIp ARXML(s); "
            f"{len(self.other_arxmls)} other ARXML(s); "
            f"{len(self.c_files)} C/C++ source file(s); "
            f"{len(self.cls_files)} .cls file(s)."
        )


# ---------------------------------------------------------------------------
# ECU partitioning + auto-detect (single vs multi)
# ---------------------------------------------------------------------------

def _top_level_segment(path: Path, root: Path) -> str:
    """Return the first path segment of *path* relative to *root*.

    For ``/repo/ecu1/Dcm/Dcm.arxml`` relative to ``/repo`` returns
    ``"ecu1"``. For a file directly under *root* returns ``""`` (sentinel
    meaning "no enclosing subdirectory").
    """
    try:
        rel = path.resolve().relative_to(root.resolve())
    except ValueError:
        return ""
    parts = rel.parts
    if len(parts) <= 1:
        return ""
    return parts[0]


def partition_by_ecu(scan: RepoScanResult) -> list[EcuPartition]:
    """Group discovered ARXMLs and C files into per-ECU buckets.

    Heuristic:

    1. **Group by top-level subdirectory.** Every Dcm ARXML carries a
       top-level segment (its first path component under
       ``scan.root``). All Dcm ARXMLs sharing a top-level segment go
       into one bucket. Files at the repo root (no enclosing
       directory) collapse into a single ``""`` bucket — typical for
       flat layouts where the whole project is one ECU.

    2. **Attach companions by segment.** CanTp / Dem / DoIp / C files
       are attached to the bucket whose top-level segment they share.
       Companion files at the repo root attach to *every* bucket only
       if there is just one Dcm bucket — multi-ECU repos with a flat
       layout are unusual and we prefer a missed attachment over a
       wrong one.

    3. **Naming.** A bucket's name is its top-level segment, or — when
       the segment is empty — the Dcm SHORT-NAME parsed out of the
       first Dcm ARXML (e.g. ``DcmECU1``), or finally the Dcm file
       stem.

    Returns one or more :class:`EcuPartition`. An empty list is
    returned only if the scan found zero Dcm ARXMLs.
    """
    if not scan.dcm_arxmls:
        return []

    root = scan.root

    def _rel_parts(p: Path) -> tuple[str, ...]:
        try:
            return p.resolve().relative_to(root.resolve()).parts
        except ValueError:
            return ()

    # Pick the path level that distinguishes Dcm ARXMLs the best.
    # Skip leading directory components shared by *all* Dcm files (e.g.
    # an outer wrapper folder like ``multi-ecu/``) and use the first
    # component that diverges as the per-ECU bucket key. Falls back to
    # ``""`` when there is only one Dcm file or all Dcm files live in
    # the exact same directory.
    dcm_dir_parts = [_rel_parts(p)[:-1] for p in scan.dcm_arxmls]
    common = 0
    if dcm_dir_parts:
        min_depth = min(len(d) for d in dcm_dir_parts)
        for i in range(min_depth):
            if all(d[i] == dcm_dir_parts[0][i] for d in dcm_dir_parts):
                common += 1
            else:
                break

    def _segment(p: Path) -> str:
        dirs = _rel_parts(p)[:-1]
        if len(dirs) > common:
            return dirs[common]
        return ""

    # 1. Group Dcm ARXMLs by their distinguishing segment.
    dcm_by_segment: dict[str, list[Path]] = {}
    for p in scan.dcm_arxmls:
        dcm_by_segment.setdefault(_segment(p), []).append(p)

    # 2. Build EcuPartition objects (preserve discovery order).
    partitions: dict[str, EcuPartition] = {}
    for segment, dcm_paths in dcm_by_segment.items():
        name = segment or _derive_single_ecu_name(dcm_paths[0])
        partitions[segment] = EcuPartition(name=name, dcm_arxmls=list(dcm_paths))

    # 3. Attach companions (CanTp / Dem / DoIp / C) by matching segment.
    #    Files whose segment doesn't match any Dcm bucket attach to the
    #    sole partition when there's only one — multi-ECU repos drop
    #    unmatched files to keep assignment unambiguous.
    only_one = len(partitions) == 1
    sole_segment = next(iter(partitions.keys())) if only_one else None

    def _attach(paths: list[Path], target: str) -> None:
        for p in paths:
            seg = _segment(p)
            if seg in partitions:
                getattr(partitions[seg], target).append(p)
            elif only_one:
                getattr(partitions[sole_segment], target).append(p)
            # else: file in a multi-ECU repo with no matching ECU bucket — drop.

    _attach(scan.cantp_arxmls, "cantp_arxmls")
    _attach(scan.dem_arxmls, "dem_arxmls")
    _attach(scan.doip_arxmls, "doip_arxmls")
    _attach(scan.c_files, "c_files")

    return list(partitions.values())


def _derive_single_ecu_name(dcm_path: Path) -> str:
    """Derive an ECU name from a Dcm ARXML at the repo root.

    Tries the Dcm module-config SHORT-NAME first (so a file containing
    ``DcmECU1`` is named ``DcmECU1``); falls back to the file stem.
    """
    try:
        xml_parser = etree.XMLParser(remove_blank_text=True,
                                     remove_comments=True, recover=True)
        tree = etree.parse(str(dcm_path), xml_parser)
        for elem in tree.getroot().iter():
            if not isinstance(elem.tag, str):
                continue
            if elem.tag.rsplit("}", 1)[-1] != "ECUC-MODULE-CONFIGURATION-VALUES":
                continue
            for child in elem:
                if isinstance(child.tag, str) and child.tag.rsplit("}", 1)[-1] == "SHORT-NAME":
                    name = (child.text or "").strip()
                    if name and _is_module_match(name, "Dcm"):
                        return name
                    break
    except (etree.XMLSyntaxError, OSError):
        pass
    return dcm_path.stem or "ECU"


def detect_ecu_mode(scan: RepoScanResult) -> str:
    """Return ``"multi"`` when the scan partitions into ≥2 ECUs, else ``"single"``.

    See :func:`partition_by_ecu` for the partitioning rule. A scan with
    zero Dcm ARXMLs returns ``"single"`` (the caller will still error
    later, but the mode label is unambiguous).
    """
    parts = partition_by_ecu(scan)
    return "multi" if len(parts) >= 2 else "single"


# ---------------------------------------------------------------------------
# Classification helpers
# ---------------------------------------------------------------------------

def classify_arxml(path: "str | Path") -> frozenset[str]:
    """Return the AUTOSAR modules contained in *path*.

    Looks for ``ECUC-MODULE-CONFIGURATION-VALUES`` elements and returns the
    set of canonical module names (a subset of :data:`_KNOWN_MODULES`) whose
    name appears in any ``SHORT-NAME`` of a module-configuration container.

    Returns an empty frozenset for files that parse cleanly but contain no
    recognised module. Raises :class:`etree.XMLSyntaxError` /
    :class:`OSError` for unparseable files (callers typically catch and
    record these in :attr:`RepoScanResult.unparseable_arxmls`).
    """
    p = Path(path)
    # Use a permissive parser — broken comments / blank text are common in
    # tool-chain output.
    xml_parser = etree.XMLParser(remove_blank_text=True, remove_comments=True,
                                 recover=True)
    tree = etree.parse(str(p), xml_parser)
    root = tree.getroot()
    if root is None:
        return frozenset()

    # Iterate all ECUC-MODULE-CONFIGURATION-VALUES regardless of namespace.
    found: set[str] = set()
    for elem in root.iter():
        if not isinstance(elem.tag, str):
            continue
        # Strip XML namespace from tag, if any.
        tag = elem.tag.rsplit("}", 1)[-1]
        if tag != "ECUC-MODULE-CONFIGURATION-VALUES":
            continue
        short_name = ""
        for child in elem:
            if isinstance(child.tag, str) and child.tag.rsplit("}", 1)[-1] == "SHORT-NAME":
                short_name = (child.text or "").strip()
                break
        if not short_name:
            continue
        for module in _KNOWN_MODULES:
            if module in short_name:
                # Filter out false positives: ``Dem`` would also match
                # ``Demo*`` so require boundary on the right.
                if _is_module_match(short_name, module):
                    found.add(module)
    return frozenset(found)


def _is_module_match(short_name: str, module: str) -> bool:
    """Return True if *short_name* names an instance of *module*.

    AUTOSAR ECUC short-names for module-configuration containers start with
    the module name (``Dcm``, ``CanTp``, ``Dem``, ``DoIp``) and are
    optionally followed by a non-letter separator or an upper-case suffix
    (``Dcm``, ``Dcm_Cfg``, ``DcmConfig``, ``DemSample``). This guard
    rejects unrelated names that merely share the prefix (``Demo``,
    ``Demand``).
    """
    if not short_name.startswith(module):
        return False
    tail = short_name[len(module):]
    if not tail:
        return True
    # Reject a continuation that would extend the identifier into a
    # different word, e.g. ``Demo`` for ``Dem``. Accept underscores,
    # digits, or upper-case starts (camel-cased suffixes).
    return not (tail[0].isalpha() and tail[0].islower())


# ---------------------------------------------------------------------------
# Repo walker
# ---------------------------------------------------------------------------

def scan_repo(
    root: "str | Path",
    *,
    include_headers: bool = False,
    relevant_c_only: bool = True,
    skip_dirs: Optional[Iterable[str]] = None,
    follow_symlinks: bool = False,
) -> RepoScanResult:
    """Walk *root* and classify every ARXML / C source file inside it.

    Args:
        root:              Directory to scan. Must exist.
        include_headers:   When True, also collect ``*.h`` / ``*.hpp`` /
                           ``*.hh`` / ``*.hxx`` files. Defaults to False —
                           the DID/RID scanner walks headers itself when
                           ``include_headers=True`` is passed to it, so the
                           repo scanner does not need to surface them.
        relevant_c_only:   When True (default), C files that contain no
                           UDS-related identifier (``DcmAppl_*``,
                           ``Dcm_Read``, ``ReadDataByIdentifier`` …) are
                           dropped. Set False to forward every C file found.
        skip_dirs:         Override the default set of directory names that
                           the walker refuses to descend into. The default
                           covers ``.git`` / ``node_modules`` / ``build`` /
                           virtual envs and similar.
        follow_symlinks:   Whether ``os.walk`` should follow symlinks.

    Returns:
        :class:`RepoScanResult` populated with classified file lists.

    Raises:
        FileNotFoundError: if *root* does not exist or is not a directory.
    """
    root_path = Path(root).expanduser().resolve()
    if not root_path.exists():
        raise FileNotFoundError(f"Repository root does not exist: {root_path}")
    if not root_path.is_dir():
        raise FileNotFoundError(f"Repository root is not a directory: {root_path}")

    skip = set(_SKIP_DIRS)
    if skip_dirs is not None:
        skip = set(skip_dirs)

    result = RepoScanResult(root=root_path)

    arxml_paths: list[Path] = []
    c_paths: list[Path] = []
    cls_paths: list[Path] = []

    # os.walk is faster than Path.rglob for large trees because we can prune
    # directories in-place via the ``dirnames`` mutation contract.
    import os

    for dirpath, dirnames, filenames in os.walk(
        root_path, followlinks=follow_symlinks
    ):
        # Prune ignored directories. Mutate ``dirnames`` in-place per
        # os.walk's documented contract.
        dirnames[:] = [d for d in dirnames if d not in skip]

        dp = Path(dirpath)
        for name in filenames:
            lower = name.lower()
            if lower.endswith(".arxml"):
                arxml_paths.append(dp / name)
            elif lower.endswith(_C_EXTENSIONS):
                c_paths.append(dp / name)
            elif include_headers and lower.endswith(_C_HEADER_EXTENSIONS):
                c_paths.append(dp / name)
            elif lower.endswith(".cls"):
                cls_paths.append(dp / name)

    logger.info(
        "repo_scanner: found %d ARXML, %d C/C++, %d .cls under %s",
        len(arxml_paths), len(c_paths), len(cls_paths), root_path,
    )

    # Classify ARXMLs.
    for p in sorted(arxml_paths):
        try:
            modules = classify_arxml(p)
        except (etree.XMLSyntaxError, OSError) as e:
            logger.warning("repo_scanner: skipping unparseable %s: %s", p, e)
            result.unparseable_arxmls.append((p, str(e)))
            continue
        result.classifications[p] = modules
        if "Dcm" in modules:
            result.dcm_arxmls.append(p)
        if "CanTp" in modules:
            result.cantp_arxmls.append(p)
        if "Dem" in modules:
            result.dem_arxmls.append(p)
        if "DoIp" in modules:
            result.doip_arxmls.append(p)
        if not modules:
            result.other_arxmls.append(p)

    # Filter C files to UDS-relevant ones.
    if relevant_c_only:
        result.c_files = sorted(_filter_uds_relevant_c(c_paths))
    else:
        result.c_files = sorted(c_paths)

    result.cls_files = sorted(cls_paths)

    logger.info("repo_scanner: %s", result.summary())
    return result


def _filter_uds_relevant_c(paths: list[Path]) -> list[Path]:
    """Keep only C files whose text contains a UDS-related token.

    Reads each file in binary mode and substring-matches against
    :data:`_UDS_C_TOKENS`. Errors (permission / encoding) cause the file to
    be skipped rather than aborting the scan.
    """
    keep: list[Path] = []
    tokens_bytes = tuple(t.encode("ascii") for t in _UDS_C_TOKENS)
    for p in paths:
        try:
            data = p.read_bytes()
        except OSError as e:
            logger.debug("repo_scanner: cannot read %s: %s", p, e)
            continue
        if any(tok in data for tok in tokens_bytes):
            keep.append(p)
    return keep


# ---------------------------------------------------------------------------
# Convenience loader: scan + parse + return UdsSpecification
# ---------------------------------------------------------------------------

def load_from_repo(
    root: "str | Path",
    *,
    c_scan_depth: int = 0,
    include_headers: bool = False,
    relevant_c_only: bool = True,
    require_minimum_set: bool = False,
) -> tuple["UdsSpecification", RepoScanResult]:
    """Scan *root*, parse every relevant file, return the resulting spec.

    This is the one-call wrapper most users want: pass a BSW repository
    root and get back a fully-populated :class:`UdsSpecification` ready to
    feed into :class:`TexGenerator`.

    Args:
        root:                   Directory to scan.
        c_scan_depth:           Transitive depth for the C scanner (0–3).
        include_headers:        Also feed header files to the scan.
        relevant_c_only:        Drop C files that contain no UDS-related
                                identifiers. Set False to scan every C/C++
                                source under the root.
        require_minimum_set:    When True, raise ``ValueError`` if the scan
                                does not find at least one Dcm + CanTp +
                                Dem ARXML. Defaults to False (a Dcm file
                                alone is enough to render a partial spec).

    Returns:
        Tuple ``(spec, scan_result)``.

    Raises:
        ValueError:       No Dcm ARXML found in *root*, or
                          ``require_minimum_set`` is True and one of
                          Dcm/CanTp/Dem is missing.
        FileNotFoundError: *root* does not exist.
    """
    from udsxml2tex.c_scanner import scan_did_variables, scan_rid_variables
    from udsxml2tex.cantp_parser import CanTpParser
    from udsxml2tex.dem_parser import DemParser
    from udsxml2tex.parser import ArxmlParser

    scan = scan_repo(
        root,
        include_headers=include_headers,
        relevant_c_only=relevant_c_only,
    )

    if not scan.dcm_arxmls:
        raise ValueError(
            f"No Dcm module configuration found under {scan.root}. "
            f"udsxml2tex needs at least one ARXML file containing an "
            f"ECUC-MODULE-CONFIGURATION-VALUES with a Dcm SHORT-NAME."
        )

    if require_minimum_set and scan.missing_modules:
        raise ValueError(
            f"Repository scan is missing required module(s) "
            f"{scan.missing_modules!r} under {scan.root}. "
            f"For full UDS-on-CAN coverage, the project must ship Dcm + "
            f"CanTp + Dem ARXML files."
        )

    # ---- Dcm (+ inline CanTp / Dem) ---------------------------------------
    arxml_parser = ArxmlParser()
    if len(scan.dcm_arxmls) == 1:
        spec = arxml_parser.parse(scan.dcm_arxmls[0])
    else:
        spec = arxml_parser.parse_multi(scan.dcm_arxmls)

    # ---- CanTp in a separate file -----------------------------------------
    # ArxmlParser already pulls CanTp data when CanTp is in the same file as
    # Dcm. Files that contain CanTp but *not* Dcm need a dedicated parse.
    standalone_cantp = [
        p for p in scan.cantp_arxmls
        if "Dcm" not in scan.classifications.get(p, frozenset())
    ]
    for p in standalone_cantp:
        try:
            cantp_config = CanTpParser().parse(p)
        except Exception as e:  # noqa: BLE001 — log and continue
            logger.warning("repo_scanner: CanTp parse failed for %s: %s", p, e)
            continue
        # Replace transport_config only if the main parser produced nothing
        # (e.g. Dcm file lacked an inline CanTpChannel). Otherwise merge
        # the channel list — keeping anything already attached to the spec.
        if spec.transport_config is None:
            spec.transport_config = cantp_config
        else:
            spec.transport_config.channels.extend(cantp_config.channels)

    # ---- Dem --------------------------------------------------------------
    for p in scan.dem_arxmls:
        # Even if a Dcm file also contains Dem, DemParser is more thorough,
        # so call it for every Dem-bearing file. Deduplicate by resolved path
        # to avoid double-counting symlinks.
        try:
            DemParser().parse(p, spec)
        except Exception as e:  # noqa: BLE001 — log and continue
            logger.warning("repo_scanner: Dem parse failed for %s: %s", p, e)

    # ---- DoIP -------------------------------------------------------------
    if scan.doip_arxmls:
        try:
            from udsxml2tex.doip_parser import DoIpParser
            xml_parser = etree.XMLParser(remove_blank_text=True,
                                         remove_comments=True, recover=True)
            for p in scan.doip_arxmls:
                doip_root = etree.parse(str(p), xml_parser).getroot()
                spec.doip_config = DoIpParser().parse(doip_root)
        except Exception as e:  # noqa: BLE001 — log and continue
            logger.warning("repo_scanner: DoIP parse failed: %s", e)

    # ---- C / C++ scanner -------------------------------------------------
    if scan.c_files:
        try:
            scan_did_variables(
                scan.c_files, spec.dids,
                include_headers=include_headers,
                transitive_depth=c_scan_depth,
            )
        except Exception as e:  # noqa: BLE001 — log and continue
            logger.warning("repo_scanner: DID C scan failed: %s", e)
        try:
            scan_rid_variables(
                scan.c_files, spec.routines,
                include_headers=include_headers,
                transitive_depth=c_scan_depth,
            )
        except Exception as e:  # noqa: BLE001 — log and continue
            logger.warning("repo_scanner: RID C scan failed: %s", e)

    return spec, scan


def load_system_from_repo(
    root: "str | Path",
    *,
    c_scan_depth: int = 0,
    include_headers: bool = False,
    relevant_c_only: bool = True,
    infer_routing: bool = True,
):
    """Build a fully-parsed multi-ECU :class:`EcuSystem` from a repo root.

    Walks *root* with :func:`scan_repo`, partitions the result with
    :func:`partition_by_ecu`, parses each ECU's ARXMLs into a
    :class:`UdsSpecification`, runs the DID/RID C scanners on every
    partition's C files, and (optionally) runs ARXML-based routing
    inference. The returned :class:`EcuSystem` is wire-compatible with
    :func:`multi_ecu.generator.generate_system_html` / ``_latex`` etc.

    Args:
        root:                 Repository root.
        c_scan_depth:         Transitive depth for the C scanner.
        include_headers:      Forward header files to the C scanner.
        relevant_c_only:      Drop irrelevant C files at scan time.
        infer_routing:        Run ARXML-based routing inference after
                              parsing. Falls back gracefully if the
                              inference module is unavailable.

    Returns:
        Tuple ``(system, scan_result, partitions)``.

    Raises:
        ValueError:        Scan found no Dcm ARXMLs.
        FileNotFoundError: *root* does not exist.
    """
    from udsxml2tex.c_scanner import scan_did_variables, scan_rid_variables
    from udsxml2tex.cantp_parser import CanTpParser
    from udsxml2tex.dem_parser import DemParser
    from udsxml2tex.multi_ecu.models import EcuConfig, EcuRole, EcuSystem
    from udsxml2tex.parser import ArxmlParser

    scan = scan_repo(
        root,
        include_headers=include_headers,
        relevant_c_only=relevant_c_only,
    )
    if not scan.dcm_arxmls:
        raise ValueError(
            f"No Dcm module configuration found under {scan.root}. "
            f"udsxml2tex needs at least one ARXML file containing an "
            f"ECUC-MODULE-CONFIGURATION-VALUES with a Dcm SHORT-NAME."
        )

    partitions = partition_by_ecu(scan)

    system = EcuSystem(name=scan.root.name or "UnnamedSystem")

    for i, part in enumerate(partitions):
        # First partition becomes GATEWAY (tester-facing); rest become
        # ENDPOINTs. Caller can override afterwards if needed.
        role = EcuRole.GATEWAY if i == 0 else EcuRole.ENDPOINT
        arxml_files = list(part.dcm_arxmls) + [
            p for p in part.cantp_arxmls if p not in part.dcm_arxmls
        ]
        ecu = EcuConfig(
            name=part.name,
            role=role,
            arxml_files=arxml_files,
            dem_arxml=part.dem_arxmls[0] if part.dem_arxmls else None,
            did_c_files=list(part.c_files),
            rid_c_files=list(part.c_files),
        )

        # Parse this ECU's ARXMLs.
        arxml_parser = ArxmlParser()
        if len(arxml_files) == 1:
            ecu.spec = arxml_parser.parse(arxml_files[0])
        else:
            ecu.spec = arxml_parser.parse_multi(arxml_files)

        # Standalone CanTp fallback when CanTp is in a separate file.
        for p in part.cantp_arxmls:
            if "Dcm" in scan.classifications.get(p, frozenset()):
                continue
            try:
                cfg = CanTpParser().parse(p)
            except Exception as e:  # noqa: BLE001
                logger.warning(
                    "repo_scanner: CanTp parse failed for %s: %s", p, e
                )
                continue
            if ecu.spec.transport_config is None:
                ecu.spec.transport_config = cfg
            else:
                ecu.spec.transport_config.channels.extend(cfg.channels)

        # DEM (every Dem ARXML in this partition).
        for p in part.dem_arxmls:
            try:
                DemParser().parse(p, ecu.spec)
            except Exception as e:  # noqa: BLE001
                logger.warning(
                    "repo_scanner: Dem parse failed for %s: %s", p, e
                )

        # Mirror single-ECU naming behaviour: prefer the partition name
        # when the ARXML didn't carry one.
        if not ecu.spec.ecu_name or ecu.spec.ecu_name == "UnnamedECU":
            ecu.spec.ecu_name = part.name

        # C / C++ scan against this ECU's C files only.
        if part.c_files:
            try:
                scan_did_variables(
                    part.c_files, ecu.spec.dids,
                    include_headers=include_headers,
                    transitive_depth=c_scan_depth,
                )
            except Exception as e:  # noqa: BLE001
                logger.warning("repo_scanner: DID C scan failed: %s", e)
            try:
                scan_rid_variables(
                    part.c_files, ecu.spec.routines,
                    include_headers=include_headers,
                    transitive_depth=c_scan_depth,
                )
            except Exception as e:  # noqa: BLE001
                logger.warning("repo_scanner: RID C scan failed: %s", e)

        system.ecus[part.name] = ecu

    if infer_routing:
        try:
            from udsxml2tex.multi_ecu.inference import infer_routing_rules
            system.routing_rules.extend(infer_routing_rules(system))
        except Exception as e:  # noqa: BLE001
            logger.warning("repo_scanner: routing inference failed: %s", e)

    return system, scan, partitions
