"""Tests for udsxml2tex.repo_scanner — repo-level ARXML/C auto-discovery."""

from __future__ import annotations

import shutil
import textwrap
from pathlib import Path

import pytest

from udsxml2tex.repo_scanner import (
    EcuPartition,
    RepoScanResult,
    _is_module_match,
    classify_arxml,
    detect_ecu_mode,
    load_from_repo,
    load_system_from_repo,
    partition_by_ecu,
    scan_repo,
)

FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_DCM = FIXTURES_DIR / "sample_dcm.arxml"
SAMPLE_CANTP = FIXTURES_DIR / "sample_cantp.arxml"
SAMPLE_DEM = FIXTURES_DIR / "sample_dem.arxml"

SAMPLES_DIR = Path(__file__).parent.parent / "src" / "udsxml2tex" / "samples"
SAMPLE_DID_C = SAMPLES_DIR / "sample1_did.c"
SAMPLE_RID_C = SAMPLES_DIR / "sample1_rid.c"


# ---------------------------------------------------------------------------
# _is_module_match heuristic
# ---------------------------------------------------------------------------

class TestModuleMatch:

    @pytest.mark.parametrize("short_name,module", [
        ("Dcm", "Dcm"),
        ("DcmGeneral", "Dcm"),
        ("DcmSample", "Dcm"),
        ("Dcm_Cfg", "Dcm"),
        ("Dcm_Bsw", "Dcm"),
        ("Dem", "Dem"),
        ("DemConfigSet", "Dem"),
        ("CanTp", "CanTp"),
        ("CanTpChannel", "CanTp"),
        ("DoIp", "DoIp"),
        ("DoIpConfig", "DoIp"),
    ])
    def test_accepts(self, short_name: str, module: str) -> None:
        assert _is_module_match(short_name, module)

    @pytest.mark.parametrize("short_name,module", [
        ("Demo", "Dem"),                 # lower-case 'o' → not a Dem instance
        ("Demand", "Dem"),               # lower-case 'a'
        ("Demonstrative", "Dem"),        # lower-case 'o'
        ("Dcmodule", "Dcm"),             # lower-case 'o'
        ("CanTpacked", "CanTp"),         # lower-case 'a'
        ("DoIparametric", "DoIp"),       # lower-case 'a'
        ("Project", "Dcm"),              # no 'Dcm' prefix at all
        ("MyDcm", "Dcm"),                # module name only allowed as prefix
    ])
    def test_rejects(self, short_name: str, module: str) -> None:
        assert not _is_module_match(short_name, module)


# ---------------------------------------------------------------------------
# classify_arxml
# ---------------------------------------------------------------------------

class TestClassifyArxml:

    def test_dcm_file(self) -> None:
        modules = classify_arxml(SAMPLE_DCM)
        assert "Dcm" in modules

    def test_cantp_file(self) -> None:
        modules = classify_arxml(SAMPLE_CANTP)
        assert "CanTp" in modules

    def test_dem_file(self) -> None:
        modules = classify_arxml(SAMPLE_DEM)
        assert "Dem" in modules

    def test_unparseable_file_raises(self, tmp_path: Path) -> None:
        bad = tmp_path / "bad.arxml"
        bad.write_text("<<<not xml at all>>>", encoding="utf-8")
        # The lxml parser is set to ``recover=True``, so it returns an empty
        # tree rather than raising — verify we get back an empty frozenset.
        result = classify_arxml(bad)
        assert result == frozenset()

    def test_empty_autosar_returns_empty(self, tmp_path: Path) -> None:
        empty = tmp_path / "empty.arxml"
        empty.write_text(
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<AUTOSAR xmlns="http://autosar.org/schema/r4.0">'
            '<AR-PACKAGES/></AUTOSAR>',
            encoding="utf-8",
        )
        assert classify_arxml(empty) == frozenset()


# ---------------------------------------------------------------------------
# scan_repo — synthetic BSW tree
# ---------------------------------------------------------------------------

def _build_synthetic_repo(root: Path) -> None:
    """Lay out a representative BSW tree under *root*."""
    (root / "Dcm").mkdir()
    (root / "CanTp").mkdir()
    (root / "Dem").mkdir()
    (root / "Appl").mkdir()
    (root / "build").mkdir()  # should be pruned
    (root / ".git").mkdir()   # should be pruned

    shutil.copy(SAMPLE_DCM, root / "Dcm" / "Dcm.arxml")
    shutil.copy(SAMPLE_CANTP, root / "CanTp" / "CanTp.arxml")
    shutil.copy(SAMPLE_DEM, root / "Dem" / "Dem.arxml")
    shutil.copy(SAMPLE_DID_C, root / "Appl" / "did_handlers.c")
    shutil.copy(SAMPLE_RID_C, root / "Appl" / "rid_handlers.c")

    # A vendored helper C file that should be filtered out by default.
    (root / "Appl" / "helpers.c").write_text(
        "#include <stdint.h>\nuint32_t crc32(const uint8_t *p, size_t n) { return 0; }\n",
        encoding="utf-8",
    )
    # Build artifacts that must be ignored.
    (root / "build" / "Dcm.arxml").write_bytes(b"<not arxml>")
    (root / ".git" / "config").write_text("[core]\n", encoding="utf-8")


class TestScanRepo:

    def test_classifies_modules(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        _build_synthetic_repo(repo)

        result = scan_repo(repo)
        assert isinstance(result, RepoScanResult)
        assert len(result.dcm_arxmls) == 1
        assert len(result.cantp_arxmls) == 1
        assert len(result.dem_arxmls) == 1
        assert result.has_minimum_set
        assert result.missing_modules == []
        assert result.dcm_arxmls[0].name == "Dcm.arxml"
        assert result.cantp_arxmls[0].name == "CanTp.arxml"
        assert result.dem_arxmls[0].name == "Dem.arxml"

    def test_prunes_build_and_dotgit(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        _build_synthetic_repo(repo)
        result = scan_repo(repo)
        # The build/Dcm.arxml fake should be neither classified nor in
        # unparseable_arxmls — it must have been skipped entirely by the
        # directory-prune step.
        for p in (
            *result.dcm_arxmls, *result.cantp_arxmls, *result.dem_arxmls,
            *result.other_arxmls,
            *(t[0] for t in result.unparseable_arxmls),
        ):
            assert "build" not in p.parts
            assert ".git" not in p.parts

    def test_filters_irrelevant_c_files_by_default(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        _build_synthetic_repo(repo)
        result = scan_repo(repo)
        # did_handlers.c & rid_handlers.c contain ``_ReadData`` / ``_RoutineControl_Start``;
        # helpers.c does not — so default filter drops it.
        names = sorted(p.name for p in result.c_files)
        assert names == ["did_handlers.c", "rid_handlers.c"]

    def test_keeps_all_c_files_when_relevant_only_false(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        _build_synthetic_repo(repo)
        result = scan_repo(repo, relevant_c_only=False)
        names = sorted(p.name for p in result.c_files)
        assert "helpers.c" in names

    def test_missing_modules_reports_correctly(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        (repo / "Dcm").mkdir()
        shutil.copy(SAMPLE_DCM, repo / "Dcm" / "Dcm.arxml")

        result = scan_repo(repo)
        assert not result.has_minimum_set
        assert set(result.missing_modules) == {"CanTp", "Dem"}

    def test_records_unparseable(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        (repo / "broken.arxml").write_text("not<xml", encoding="utf-8")
        result = scan_repo(repo)
        # With lxml recover=True, the parser succeeds with an empty tree —
        # the file is therefore in other_arxmls, not unparseable_arxmls.
        # Either bucket is acceptable; just confirm it didn't land in any
        # module list.
        assert not result.dcm_arxmls
        assert (
            repo / "broken.arxml" in result.other_arxmls
            or any(p == repo / "broken.arxml"
                   for p, _ in result.unparseable_arxmls)
        )

    def test_summary_contains_counts(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        _build_synthetic_repo(repo)
        summary = scan_repo(repo).summary()
        assert "1 Dcm" in summary
        assert "1 CanTp" in summary
        assert "1 Dem" in summary

    def test_root_must_exist(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError):
            scan_repo(tmp_path / "does_not_exist")

    def test_root_must_be_directory(self, tmp_path: Path) -> None:
        f = tmp_path / "file"
        f.write_text("hi", encoding="utf-8")
        with pytest.raises(FileNotFoundError):
            scan_repo(f)


# ---------------------------------------------------------------------------
# load_from_repo — full parse pipeline
# ---------------------------------------------------------------------------

class TestLoadFromRepo:

    def test_produces_populated_spec(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        _build_synthetic_repo(repo)

        spec, scan = load_from_repo(repo)
        assert scan.has_minimum_set
        assert len(spec.sessions) > 0
        assert len(spec.services) > 0
        # Dem.arxml contributes DTCs.
        assert len(spec.dem_dtcs) > 0
        # CanTp.arxml is in a separate file — repo scanner must have
        # populated transport_config (either via main parser or the
        # standalone CanTpParser fallback).
        assert spec.transport_config is not None

    def test_raises_without_dcm(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        shutil.copy(SAMPLE_CANTP, repo / "CanTp.arxml")
        with pytest.raises(ValueError, match="No Dcm"):
            load_from_repo(repo)

    def test_require_minimum_set_enforced(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        shutil.copy(SAMPLE_DCM, repo / "Dcm.arxml")
        with pytest.raises(ValueError, match="missing required module"):
            load_from_repo(repo, require_minimum_set=True)

    def test_works_without_minimum_set_by_default(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        shutil.copy(SAMPLE_DCM, repo / "Dcm.arxml")
        # Just Dcm — should still produce a spec (services etc.) without
        # raising.
        spec, scan = load_from_repo(repo)
        assert len(spec.services) > 0
        assert "Dem" in scan.missing_modules
        assert "CanTp" in scan.missing_modules

    def test_handles_dcm_with_inline_cantp(self, tmp_path: Path) -> None:
        """A file containing both Dcm + CanTp must not be double-parsed."""
        repo = tmp_path / "bsw"
        repo.mkdir()
        # Synthesise an ARXML containing both modules.
        combined = repo / "combined.arxml"
        combined.write_text(textwrap.dedent("""\
            <?xml version="1.0" encoding="UTF-8"?>
            <AUTOSAR xmlns="http://autosar.org/schema/r4.0">
              <AR-PACKAGES>
                <AR-PACKAGE>
                  <SHORT-NAME>X</SHORT-NAME>
                  <ELEMENTS>
                    <ECUC-MODULE-CONFIGURATION-VALUES>
                      <SHORT-NAME>Dcm</SHORT-NAME>
                    </ECUC-MODULE-CONFIGURATION-VALUES>
                    <ECUC-MODULE-CONFIGURATION-VALUES>
                      <SHORT-NAME>CanTp</SHORT-NAME>
                    </ECUC-MODULE-CONFIGURATION-VALUES>
                  </ELEMENTS>
                </AR-PACKAGE>
              </AR-PACKAGES>
            </AUTOSAR>
            """), encoding="utf-8")
        # Classification: the file is reported under both module lists.
        modules = classify_arxml(combined)
        assert modules == frozenset({"Dcm", "CanTp"})
        # load_from_repo should not invoke the standalone CanTpParser on a
        # combined file (only files with CanTp but no Dcm trigger that
        # fallback).
        scan = scan_repo(repo)
        assert combined in scan.cantp_arxmls
        assert combined in scan.dcm_arxmls


# ---------------------------------------------------------------------------
# partition_by_ecu / detect_ecu_mode
# ---------------------------------------------------------------------------

def _build_two_ecu_repo(root: Path) -> None:
    """Layout: ecu1/{dcm,cantp,dem}.arxml + ecu2/{dcm,cantp,dem}.arxml."""
    for ecu_dir, suffix in (("ecu1", "1"), ("ecu2", "2")):
        d = root / ecu_dir
        d.mkdir()
        for kind in ("dcm", "cantp", "dem"):
            shutil.copy(
                SAMPLES_DIR / f"sample{suffix}_{kind}.arxml",
                d / f"{kind}.arxml",
            )


class TestPartitionByEcu:

    def test_single_ecu_flat_layout(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        shutil.copy(SAMPLE_DCM, repo / "Dcm.arxml")
        shutil.copy(SAMPLE_CANTP, repo / "CanTp.arxml")
        shutil.copy(SAMPLE_DEM, repo / "Dem.arxml")
        scan = scan_repo(repo)
        parts = partition_by_ecu(scan)
        assert len(parts) == 1
        only = parts[0]
        # Name falls back to the Dcm SHORT-NAME ("DcmSample" in the bundled
        # fixture) when files sit at the repo root.
        assert only.name
        # Companion files at the repo root attach to the sole partition.
        assert len(only.dcm_arxmls) == 1
        assert len(only.cantp_arxmls) == 1
        assert len(only.dem_arxmls) == 1

    def test_two_ecu_subdir_layout(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        _build_two_ecu_repo(repo)
        scan = scan_repo(repo)
        parts = partition_by_ecu(scan)
        assert len(parts) == 2
        names = sorted(p.name for p in parts)
        assert names == ["ecu1", "ecu2"]
        for p in parts:
            assert isinstance(p, EcuPartition)
            assert p.has_minimum_set, p.name

    def test_detect_mode_single(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        shutil.copy(SAMPLE_DCM, repo / "Dcm.arxml")
        assert detect_ecu_mode(scan_repo(repo)) == "single"

    def test_detect_mode_multi(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        _build_two_ecu_repo(repo)
        assert detect_ecu_mode(scan_repo(repo)) == "multi"

    def test_companion_at_root_drops_in_multi(self, tmp_path: Path) -> None:
        """A CanTp ARXML at the repo root must not attach to multiple ECUs."""
        repo = tmp_path / "bsw"
        repo.mkdir()
        _build_two_ecu_repo(repo)
        # Stray CanTp at the root.
        shutil.copy(SAMPLE_CANTP, repo / "extra_cantp.arxml")
        scan = scan_repo(repo)
        parts = partition_by_ecu(scan)
        assert len(parts) == 2
        for p in parts:
            # Each partition keeps only its own ecu*/cantp.arxml; the
            # root-level extra_cantp.arxml is dropped because the
            # repo has multiple ECUs.
            assert all("extra_cantp.arxml" not in str(x) for x in p.cantp_arxmls)


# ---------------------------------------------------------------------------
# load_system_from_repo
# ---------------------------------------------------------------------------

class TestLoadSystemFromRepo:

    def test_two_ecu_layout_produces_system(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        _build_two_ecu_repo(repo)
        system, scan, parts = load_system_from_repo(repo)
        assert len(system.ecus) == 2
        assert sorted(system.ecus.keys()) == ["ecu1", "ecu2"]
        for ecu in system.ecus.values():
            assert ecu.spec is not None
            assert len(ecu.spec.services) > 0
            assert len(ecu.spec.dem_dtcs) > 0
        # First partition becomes the gateway.
        from udsxml2tex.multi_ecu.models import EcuRole
        roles = [e.role for e in system.ecus.values()]
        assert EcuRole.GATEWAY in roles
        assert EcuRole.ENDPOINT in roles

    def test_raises_without_dcm(self, tmp_path: Path) -> None:
        repo = tmp_path / "bsw"
        repo.mkdir()
        shutil.copy(SAMPLE_CANTP, repo / "CanTp.arxml")
        with pytest.raises(ValueError, match="No Dcm"):
            load_system_from_repo(repo)


# ---------------------------------------------------------------------------
# /repo/scan + /repo/generate FastAPI endpoints
# ---------------------------------------------------------------------------

class TestRepoEndpoints:
    """Exercise the browser-facing endpoints via FastAPI's TestClient."""

    def _client(self):
        pytest.importorskip("fastapi")
        from fastapi.testclient import TestClient
        from udsxml2tex.webserver import _create_app
        return TestClient(_create_app())

    def _make_files(self, layout: dict[str, Path]) -> list[tuple]:
        """Build the ``files=`` multipart payload from {relpath: source}."""
        out = []
        for rel, src in layout.items():
            out.append(
                ("files", (rel, src.read_bytes(), "application/xml"))
            )
        return out

    def test_scan_single_ecu(self) -> None:
        client = self._client()
        layout = {
            "Dcm.arxml": SAMPLE_DCM,
            "CanTp.arxml": SAMPLE_CANTP,
            "Dem.arxml": SAMPLE_DEM,
        }
        r = client.post("/repo/scan", files=self._make_files(layout))
        assert r.status_code == 200
        data = r.json()
        assert data["mode"] == "single"
        assert data["session_id"]
        assert len(data["ecus"]) == 1
        assert data["ecus"][0]["has_minimum_set"] is True

    def test_scan_multi_ecu(self) -> None:
        client = self._client()
        layout = {}
        for ecu, suffix in (("ecu1", "1"), ("ecu2", "2")):
            for kind in ("dcm", "cantp", "dem"):
                src = SAMPLES_DIR / f"sample{suffix}_{kind}.arxml"
                layout[f"{ecu}/{kind}.arxml"] = src
        r = client.post("/repo/scan", files=self._make_files(layout))
        assert r.status_code == 200
        data = r.json()
        assert data["mode"] == "multi"
        assert {e["name"] for e in data["ecus"]} == {"ecu1", "ecu2"}

    def test_scan_rejects_unsafe_path(self) -> None:
        client = self._client()
        files = [("files", ("../escape.arxml", b"<x/>", "application/xml"))]
        r = client.post("/repo/scan", files=files)
        assert r.status_code == 400

    def test_scan_rejects_empty(self) -> None:
        client = self._client()
        # All files filtered out as non-Dcm.
        files = [("files", ("note.txt", b"hello", "text/plain"))]
        # FastAPI requires at least one valid upload; even when the file
        # has no AUTOSAR content the scan reports zero Dcm and rejects.
        r = client.post("/repo/scan", files=files)
        assert r.status_code == 400

    def test_generate_single_md(self) -> None:
        client = self._client()
        layout = {
            "Dcm.arxml": SAMPLE_DCM,
            "CanTp.arxml": SAMPLE_CANTP,
            "Dem.arxml": SAMPLE_DEM,
        }
        r = client.post("/repo/scan", files=self._make_files(layout))
        sid = r.json()["session_id"]
        r2 = client.post(
            "/repo/generate",
            data={"session_id": sid, "format": "md", "mode": "auto"},
        )
        assert r2.status_code == 200
        assert "text/markdown" in r2.headers["content-type"]
        body = r2.text
        # The bundled DCM fixture defines DefaultSession + ProgrammingSession.
        assert "DefaultSession" in body or "Diagnostic Sessions" in body

    def test_generate_multi_md_returns_system_doc(self) -> None:
        client = self._client()
        layout = {}
        for ecu, suffix in (("ecu1", "1"), ("ecu2", "2")):
            for kind in ("dcm", "cantp", "dem"):
                src = SAMPLES_DIR / f"sample{suffix}_{kind}.arxml"
                layout[f"{ecu}/{kind}.arxml"] = src
        r = client.post("/repo/scan", files=self._make_files(layout))
        sid = r.json()["session_id"]
        r2 = client.post(
            "/repo/generate",
            data={"session_id": sid, "format": "md", "mode": "auto"},
        )
        assert r2.status_code == 200
        assert "system" in (r2.headers.get("content-disposition") or "").lower()
        body = r2.text
        assert "ECU" in body  # System Integration Document mentions ECUs

    def test_generate_rejects_unknown_session(self) -> None:
        client = self._client()
        r = client.post(
            "/repo/generate",
            data={"session_id": "no-such-session", "format": "md"},
        )
        assert r.status_code == 400

    def test_explicit_mode_overrides_auto(self) -> None:
        """Forcing mode=single on a 2-ECU upload must take just the first ECU."""
        client = self._client()
        layout = {}
        for ecu, suffix in (("ecu1", "1"), ("ecu2", "2")):
            for kind in ("dcm", "cantp", "dem"):
                src = SAMPLES_DIR / f"sample{suffix}_{kind}.arxml"
                layout[f"{ecu}/{kind}.arxml"] = src
        r = client.post("/repo/scan", files=self._make_files(layout))
        sid = r.json()["session_id"]
        # With mode=single the server falls back to load_from_repo which
        # parses every Dcm via parse_multi; the response is a single .md
        # rather than a system document.
        r2 = client.post(
            "/repo/generate",
            data={"session_id": sid, "format": "md", "mode": "single"},
        )
        assert r2.status_code == 200
        disp = (r2.headers.get("content-disposition") or "").lower()
        assert "system.md" not in disp


