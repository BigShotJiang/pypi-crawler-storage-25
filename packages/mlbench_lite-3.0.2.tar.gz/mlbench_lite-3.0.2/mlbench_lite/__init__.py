"""
mlbench-lite: A Pypi machine learning benchmarking library to make life easier.

This library provides a simple ways to benchmark multiple machine learning models
on a dataset using scikit-learn. Supports both classification and regression tasks.
"""

from .benchmark import (
    benchmark, list_available_models, get_model_info
)
from .regression import (
    benchmark_regression, list_available_regressors, get_regressor_info
)
from .datasets import load_clover, make_regression_dataset

__version__ = "3.0.1"
__author__ = "Arefin Amin"
__email__ = "arefinamin994@gmail.com"

__all__ = [
    "benchmark",
    "list_available_models",
    "get_model_info",
    "benchmark_regression",
    "list_available_regressors",
    "get_regressor_info",
    "load_clover",
    "make_regression_dataset",
]
