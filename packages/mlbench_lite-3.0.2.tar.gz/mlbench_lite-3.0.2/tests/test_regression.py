"""
Unit tests for mlbench-lite regression functionality.
"""

import pytest
import pandas as pd
import numpy as np
from sklearn.datasets import make_regression
from mlbench_lite.regression import (
    benchmark_regression, list_available_regressors, get_regressor_info
)
from mlbench_lite.datasets import make_regression_dataset


class TestRegressionBenchmark:
    """Test cases for the benchmark_regression function."""
    
    def setup_method(self):
        """Set up test data before each test method."""
        # Create a simple regression dataset
        self.X, self.y = make_regression(
            n_samples=500,
            n_features=10,
            n_informative=8,
            noise=10.0,
            random_state=42
        )
    
    def test_benchmark_regression_returns_dataframe(self):
        """Test that benchmark_regression returns a pandas DataFrame."""
        results = benchmark_regression(self.X, self.y)
        assert isinstance(results, pd.DataFrame)
    
    def test_benchmark_regression_dataframe_columns(self):
        """Test that the returned DataFrame has the expected columns."""
        results = benchmark_regression(self.X, self.y)
        expected_columns = ['Model', 'Category', 'R2', 'MAE', 'RMSE', 'MSE']
        assert list(results.columns) == expected_columns
    
    def test_benchmark_regression_dataframe_rows(self):
        """Test that the returned DataFrame has the expected number of rows."""
        results = benchmark_regression(self.X, self.y)
        # Should have many models (20+)
        assert len(results) >= 20
    
    def test_benchmark_regression_models_present(self):
        """Test that all expected models are present in results."""
        results = benchmark_regression(self.X, self.y)
        expected_models = ['Linear Regression', 'Random Forest Regressor', 'SVR (RBF)']
        model_names = set(results['Model'].tolist())
        for model in expected_models:
            assert model in model_names
    
    def test_benchmark_regression_r2_range(self):
        """Test that R2 scores are in valid range."""
        results = benchmark_regression(self.X, self.y)
        # R2 can be negative for bad models, but should typically be <= 1
        assert all(val <= 1 for val in results['R2'])
    
    def test_benchmark_regression_mae_positive(self):
        """Test that MAE scores are non-negative."""
        results = benchmark_regression(self.X, self.y)
        assert all(val >= 0 for val in results['MAE'])
    
    def test_benchmark_regression_rmse_positive(self):
        """Test that RMSE scores are non-negative."""
        results = benchmark_regression(self.X, self.y)
        assert all(val >= 0 for val in results['RMSE'])
    
    def test_benchmark_regression_custom_test_size(self):
        """Test benchmark_regression with custom test size."""
        results = benchmark_regression(self.X, self.y, test_size=0.3)
        assert isinstance(results, pd.DataFrame)
        assert len(results) >= 20
    
    def test_benchmark_regression_custom_random_state(self):
        """Test benchmark_regression with custom random state."""
        results1 = benchmark_regression(self.X, self.y, random_state=123)
        results2 = benchmark_regression(self.X, self.y, random_state=123)
        # Results should be identical with same random state
        pd.testing.assert_frame_equal(results1, results2)
    
    def test_benchmark_regression_different_random_states(self):
        """Test that different random states produce different results."""
        results1 = benchmark_regression(self.X, self.y, random_state=123)
        results2 = benchmark_regression(self.X, self.y, random_state=456)
        # Results should be different with different random states
        assert not results1.equals(results2)
    
    def test_benchmark_regression_sorted_by_r2(self):
        """Test that results are sorted by R2 in descending order."""
        results = benchmark_regression(self.X, self.y)
        r2_scores = results['R2'].tolist()
        assert r2_scores == sorted(r2_scores, reverse=True)
    
    def test_benchmark_regression_with_small_dataset(self):
        """Test benchmark_regression with a small dataset."""
        X_small, y_small = make_regression(
            n_samples=100,
            n_features=5,
            random_state=42
        )
        results = benchmark_regression(X_small, y_small)
        assert isinstance(results, pd.DataFrame)
        assert len(results) >= 20
    
    def test_benchmark_regression_specific_models(self):
        """Test benchmark_regression with specific models."""
        results = benchmark_regression(
            self.X, self.y, 
            models=['Random Forest Regressor', 'Linear Regression']
        )
        assert isinstance(results, pd.DataFrame)
        assert len(results) == 2
        model_names = set(results['Model'].tolist())
        assert 'Random Forest Regressor' in model_names
        assert 'Linear Regression' in model_names
    
    def test_benchmark_regression_model_categories(self):
        """Test benchmark_regression with specific model categories."""
        results = benchmark_regression(
            self.X, self.y, 
            model_categories=['Linear Regression']
        )
        assert isinstance(results, pd.DataFrame)
        assert len(results) >= 7  # At least 7 linear regression models
        # All results should be from Linear Regression category
        assert all(cat == 'Linear Regression' for cat in results['Category'])
    
    def test_benchmark_regression_exclude_models(self):
        """Test benchmark_regression with excluded models."""
        results = benchmark_regression(
            self.X, self.y, 
            exclude_models=['Gaussian Process Regressor']
        )
        assert isinstance(results, pd.DataFrame)
        model_names = set(results['Model'].tolist())
        assert 'Gaussian Process Regressor' not in model_names
    
    def test_list_available_regressors(self):
        """Test list_available_regressors function."""
        regressors = list_available_regressors()
        assert isinstance(regressors, dict)
        assert 'Linear Regression' in regressors
        assert 'Tree-based Regression' in regressors
        assert 'Random Forest Regressor' in regressors['Tree-based Regression']
    
    def test_get_regressor_info(self):
        """Test get_regressor_info function."""
        info = get_regressor_info()
        assert isinstance(info, pd.DataFrame)
        assert 'Category' in info.columns
        assert 'Model' in info.columns
        assert 'Description' in info.columns
        assert len(info) >= 20
    
    def test_regression_dataset_generation(self):
        """Test make_regression_dataset function."""
        X, y = make_regression_dataset(n_samples=200, n_features=8, return_X_y=True)
        assert X.shape == (200, 8)
        assert y.shape == (200,)
    
    def test_regression_dataset_bunch_object(self):
        """Test make_regression_dataset returns Bunch object."""
        dataset = make_regression_dataset(n_samples=100, n_features=5)
        assert hasattr(dataset, 'data')
        assert hasattr(dataset, 'target')
        assert hasattr(dataset, 'feature_names')
        assert hasattr(dataset, 'DESCR')
        assert dataset.data.shape == (100, 5)
        assert dataset.target.shape == (100,)


class TestRegressionModelsCoverage:
    """Test coverage of all regression model families."""
    
    def setup_method(self):
        """Set up test data before each test method."""
        self.X, self.y = make_regression(
            n_samples=300,
            n_features=10,
            n_informative=8,
            noise=5.0,
            random_state=42
        )
    
    def test_linear_regression_models(self):
        """Test that all linear regression models are available."""
        results = benchmark_regression(
            self.X, self.y,
            model_categories=['Linear Regression']
        )
        expected_models = [
            'Linear Regression',
            'Ridge Regression',
            'Lasso Regression',
            'ElasticNet Regression',
            'Bayesian Ridge',
            'Huber Regressor',
            'Quantile Regressor',
        ]
        model_names = set(results['Model'].tolist())
        for model in expected_models:
            assert model in model_names, f"Missing {model}"
    
    def test_tree_based_regression_models(self):
        """Test that all tree-based regression models are available."""
        results = benchmark_regression(
            self.X, self.y,
            model_categories=['Tree-based Regression']
        )
        expected_models = [
            'Decision Tree Regressor',
            'Random Forest Regressor',
            'Extra Trees Regressor',
            'Gradient Boosting Regressor',
            'AdaBoost Regressor',
            'Bagging Regressor',
        ]
        model_names = set(results['Model'].tolist())
        for model in expected_models:
            assert model in model_names, f"Missing {model}"
    
    def test_svm_regression_models(self):
        """Test that SVM regression models are available."""
        results = benchmark_regression(
            self.X, self.y,
            model_categories=['SVM Regression']
        )
        expected_models = [
            'SVR (RBF)',
            'SVR (Linear)',
        ]
        model_names = set(results['Model'].tolist())
        for model in expected_models:
            assert model in model_names, f"Missing {model}"
    
    def test_neighbors_regression_models(self):
        """Test that neighbors regression models are available."""
        results = benchmark_regression(
            self.X, self.y,
            model_categories=['Neighbors']
        )
        assert 'K-Neighbors Regressor' in results['Model'].tolist()
    
    def test_neural_network_regression_models(self):
        """Test that neural network regression models are available."""
        results = benchmark_regression(
            self.X, self.y,
            model_categories=['Neural Networks']
        )
        assert 'MLP Regressor' in results['Model'].tolist()
    
    def test_gaussian_process_regression_models(self):
        """Test that Gaussian Process regression models are available."""
        results = benchmark_regression(
            self.X, self.y,
            model_categories=['Gaussian Process']
        )
        assert 'Gaussian Process Regressor' in results['Model'].tolist()


class TestBackwardCompatibility:
    """Test that classification functionality remains unchanged."""
    
    def setup_method(self):
        """Set up test data before each test method."""
        from sklearn.datasets import make_classification
        self.X_clf, self.y_clf = make_classification(
            n_samples=500,
            n_features=10,
            n_informative=8,
            n_redundant=2,
            n_classes=3,
            random_state=42
        )
    
    def test_classification_still_works(self):
        """Test that classification benchmarking still works."""
        from mlbench_lite import benchmark
        results = benchmark(self.X_clf, self.y_clf)
        assert isinstance(results, pd.DataFrame)
        assert len(results) >= 20
        assert 'Accuracy' in results.columns
        assert 'F1' in results.columns
    
    def test_classification_models_unchanged(self):
        """Test that classification models are still available."""
        from mlbench_lite import list_available_models
        models = list_available_models()
        expected_categories = [
            'Linear Models',
            'Tree-based Models',
            'SVM Models',
            'Neighbors',
            'Naive Bayes',
            'Discriminant Analysis',
            'Neural Networks',
            'Gaussian Process',
        ]
        for cat in expected_categories:
            assert cat in models, f"Missing category {cat}"
    
    def test_classification_and_regression_both_available(self):
        """Test that both classification and regression are available."""
        from mlbench_lite import benchmark, benchmark_regression
        from mlbench_lite import list_available_models, list_available_regressors
        
        # Both should work
        clf_models = list_available_models()
        reg_models = list_available_regressors()
        
        assert isinstance(clf_models, dict)
        assert isinstance(reg_models, dict)
        assert len(clf_models) > 0
        assert len(reg_models) > 0
