"""Legacy text-patch manifest system for extracted Bun bundles."""

import errno
import json
import os
import stat
from pathlib import Path

from ._utils import safe_child_path, safe_relative_path
from .workspace import file_sha256, validate_patch_package_manifest

PATCH_MANIFEST = "patch.json"
SOURCE_METADATA = ".bundle_source.json"


def build_source_metadata(binary_path, source_version=None):
    metadata = {
        "binary_sha256": file_sha256(binary_path),
    }
    if source_version is not None:
        metadata["source_version"] = source_version
    return metadata


def write_source_metadata(out_dir, binary_path, source_version=None):
    metadata = build_source_metadata(binary_path, source_version=source_version)
    metadata_path = Path(out_dir) / SOURCE_METADATA
    metadata_path.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    return metadata


def load_source_metadata(extract_dir):
    metadata_path = Path(extract_dir) / SOURCE_METADATA
    if not metadata_path.exists():
        return None

    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    checksum = metadata.get("binary_sha256")
    if not isinstance(checksum, str) or not checksum:
        raise ValueError(f"{SOURCE_METADATA} is missing binary_sha256")

    source_version = metadata.get("source_version")
    if source_version is not None and not isinstance(source_version, str):
        raise ValueError(f"{SOURCE_METADATA} has an invalid source_version")

    return metadata


def load_patch_manifest(patch_dir):
    manifest_path = Path(patch_dir) / PATCH_MANIFEST
    if not manifest_path.exists():
        raise ValueError(f"No {PATCH_MANIFEST} found in {patch_dir}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schemaVersion") == 1:
        validate_patch_package_manifest(manifest)
        manifest = normalize_patch_package_manifest(manifest)

    for field in ("id", "description", "targets", "operations"):
        if field not in manifest:
            raise ValueError(f"{PATCH_MANIFEST} is missing required field {field!r}")

    if not isinstance(manifest["targets"], dict):
        raise ValueError("patch targets must be an object")
    if not isinstance(manifest["operations"], list):
        raise ValueError("patch operations must be a list")

    return manifest


def normalize_patch_package_manifest(manifest):
    targets = manifest.get("targets", {})
    return {
        "schemaVersion": manifest["schemaVersion"],
        "id": manifest["id"],
        "version": manifest["version"],
        "name": manifest["name"],
        "description": manifest.get("description") or manifest["name"],
        "targets": {
            "versions": targets.get("claudeVersions", []),
            "binary_sha256": targets.get("sourceSha256", []),
            "platforms": targets.get("platforms", []),
        },
        "operations": manifest.get("operations", []),
    }


def init_patch(patch_dir):
    patch_root = Path(patch_dir)
    patch_root.mkdir(parents=True, exist_ok=True)
    blocks_dir = patch_root / "blocks"
    patch_manifest_path = patch_root / PATCH_MANIFEST
    find_block_path = blocks_dir / "find_example.js"
    replace_block_path = blocks_dir / "replace_example.js"

    existing = [
        path for path in (patch_manifest_path, find_block_path, replace_block_path)
        if path.exists()
    ]
    if existing:
        names = ", ".join(str(path.relative_to(patch_root)) for path in existing)
        raise ValueError(f"Patch scaffold already exists in {patch_dir}: {names}")

    blocks_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        "id": "example.patch",
        "description": "Example patch scaffold. Update paths, targets, and replacements.",
        "targets": {
            "versions": [],
            "binary_sha256": [],
        },
        "operations": [
            {
                "type": "replace_string",
                "path": "src/example.js",
                "find": "const featureEnabled = false;",
                "replace": "const featureEnabled = true;",
                "count": 1,
            },
            {
                "type": "replace_block",
                "path": "src/example.js",
                "find_file": "blocks/find_example.js",
                "replace_file": "blocks/replace_example.js",
                "count": 1,
            },
        ],
    }

    patch_manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    find_block_path.write_text(
        "function example() {\n"
        "  return 'before';\n"
        "}\n",
        encoding="utf-8",
    )
    replace_block_path.write_text(
        "function example() {\n"
        "  return 'after';\n"
        "}\n",
        encoding="utf-8",
    )

    print(f"[+] Created patch scaffold at {patch_root}")
    return patch_manifest_path


def apply_patch(
    patch_dir,
    extract_dir,
    check=False,
    binary_path=None,
    source_version=None,
    source_platform=None,
):
    patch_root = Path(patch_dir).resolve()
    extract_root = Path(extract_dir).resolve()
    manifest = load_patch_manifest(patch_root)
    source_metadata = load_source_metadata(extract_root)

    effective_checksum = file_sha256(binary_path) if binary_path else (
        source_metadata.get("binary_sha256") if source_metadata else None
    )
    effective_version = source_version if source_version is not None else (
        source_metadata.get("source_version") if source_metadata else None
    )

    validate_patch_targets(
        manifest["targets"],
        effective_version=effective_version,
        effective_checksum=effective_checksum,
        effective_platform=source_platform,
    )

    pending_changes = {}
    pending_rel_paths = {}
    applied_operations = []

    for index, operation in enumerate(manifest["operations"], start=1):
        target_path, rel_path, updated_text, matches = apply_patch_operation(
            patch_root,
            extract_root,
            operation,
            pending_changes,
            index,
        )
        pending_changes[target_path] = updated_text
        pending_rel_paths[target_path] = rel_path
        applied_operations.append((operation["type"], target_path, matches))

    if check:
        print(f"[+] Patch check succeeded for {manifest['id']}")
        for op_type, target_path, matches in applied_operations:
            rel_path = target_path.relative_to(extract_root)
            print(f"    - {op_type}: {rel_path} ({matches} match{'es' if matches != 1 else ''})")
        return applied_operations

    for target_path, updated_text in pending_changes.items():
        _write_child_text_no_symlink(
            extract_root,
            pending_rel_paths[target_path],
            updated_text,
            label="patch target",
        )

    print(f"[+] Applied patch {manifest['id']} to {extract_root}")
    for op_type, target_path, matches in applied_operations:
        rel_path = target_path.relative_to(extract_root)
        print(f"    - {op_type}: {rel_path} ({matches} match{'es' if matches != 1 else ''})")
    return applied_operations


def validate_patch_targets(
    targets,
    effective_version=None,
    effective_checksum=None,
    effective_platform=None,
):
    versions = targets.get("versions", [])
    checksums = targets.get("binary_sha256", [])
    platforms = targets.get("platforms", [])

    if not isinstance(versions, list) or any(not isinstance(item, str) or not item for item in versions):
        raise ValueError("patch targets.versions must be a list of non-empty strings")
    if not isinstance(checksums, list) or any(not isinstance(item, str) or not item for item in checksums):
        raise ValueError("patch targets.binary_sha256 must be a list of non-empty strings")
    if not isinstance(platforms, list) or any(not isinstance(item, str) or not item for item in platforms):
        raise ValueError("patch targets.platforms must be a list of non-empty strings")

    if versions:
        if not effective_version:
            raise ValueError(
                "Patch requires source version metadata. Re-extract with --source-version or pass --source-version."
            )
        if effective_version not in versions:
            raise ValueError(
                f"Patch targets versions {versions}, but source version is {effective_version!r}."
            )

    if checksums:
        if not effective_checksum:
            raise ValueError(
                "Patch requires binary checksum metadata. Re-extract from the source binary or pass --binary."
            )
        if effective_checksum not in checksums:
            raise ValueError("Patch does not target the provided binary checksum.")

    if platforms:
        if not effective_platform:
            raise ValueError("Patch requires source platform metadata.")
        if effective_platform not in platforms:
            raise ValueError(
                f"Patch targets platforms {platforms}, but source platform is {effective_platform!r}."
            )


def apply_patch_operation(patch_root, extract_root, operation, pending_changes, index):
    op_type = operation.get("type")
    if op_type not in {"replace_string", "replace_block"}:
        raise ValueError(f"Unsupported patch operation type at operations[{index - 1}]: {op_type!r}")

    rel_path = require_non_empty_string(operation.get("path"), f"operations[{index - 1}].path")
    unresolved_target_path = unresolved_child_path(
        extract_root,
        rel_path,
        label=f"operations[{index - 1}].path",
    )
    if unresolved_target_path.is_symlink():
        raise ValueError(f"Refusing to patch symlink: {rel_path}")
    try:
        target_path = safe_child_path(extract_root, rel_path, label=f"operations[{index - 1}].path")
    except ValueError as exc:
        raise ValueError(str(exc)) from exc
    if not target_path.exists():
        raise ValueError(f"Patch target file does not exist: {rel_path}")

    current_text = pending_changes.get(target_path)
    if current_text is None:
        try:
            current_text = _read_child_text_no_symlink(
                extract_root,
                rel_path,
                label="patch target",
            )
        except FileNotFoundError as exc:
            raise ValueError(f"Patch target file does not exist: {rel_path}") from exc
        except UnicodeDecodeError as exc:
            raise ValueError(f"Patch target file is not valid UTF-8: {rel_path}") from exc

    expected_count = operation.get("count", 1)
    if not isinstance(expected_count, int) or expected_count < 1:
        raise ValueError(f"operations[{index - 1}].count must be a positive integer")

    if op_type == "replace_string":
        find_text = require_non_empty_string(operation.get("find"), f"operations[{index - 1}].find")
        replace_text = require_string(operation.get("replace"), f"operations[{index - 1}].replace")
    else:
        find_file = require_non_empty_string(operation.get("find_file"), f"operations[{index - 1}].find_file")
        replace_file = require_non_empty_string(
            operation.get("replace_file"),
            f"operations[{index - 1}].replace_file",
        )
        find_text = read_patch_text(patch_root, find_file)
        replace_text = read_patch_text(patch_root, replace_file)

    matches = current_text.count(find_text)
    if matches == 0:
        raise ValueError(f"Patch operation {index} found no matches in {rel_path}")
    if matches != expected_count:
        raise ValueError(
            f"Patch operation {index} expected {expected_count} match(es) in {rel_path}, found {matches}"
        )

    updated_text = current_text.replace(find_text, replace_text, expected_count)
    return target_path, rel_path, updated_text, matches


def read_patch_text(patch_root, rel_path):
    unresolved_path = unresolved_child_path(Path(patch_root), rel_path, label="patch asset")
    if unresolved_path.is_symlink():
        raise ValueError(f"Refusing to read symlink patch asset: {rel_path}")
    try:
        path = safe_child_path(Path(patch_root), rel_path, label="patch asset")
    except ValueError as exc:
        raise ValueError(str(exc)) from exc
    if not path.exists():
        raise ValueError(f"Patch asset does not exist: {rel_path}")
    try:
        return _read_child_text_no_symlink(Path(patch_root), rel_path, label="patch asset")
    except FileNotFoundError as exc:
        raise ValueError(f"Patch asset does not exist: {rel_path}") from exc
    except UnicodeDecodeError as exc:
        raise ValueError(f"Patch asset is not valid UTF-8: {rel_path}") from exc


def require_non_empty_string(value, field_name):
    value = require_string(value, field_name)
    if not value:
        raise ValueError(f"{field_name} must be a non-empty string")
    return value


def require_string(value, field_name):
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a string")
    return value


def unresolved_child_path(root: Path, rel_path: str, *, label: str) -> Path:
    normalized = safe_relative_path(rel_path, label=label)
    return Path(root).resolve() / Path(*normalized.split("/"))


def _read_child_text_no_symlink(root: Path, rel_path: str, *, label: str) -> str:
    try:
        fd = _open_child_no_symlink(root, rel_path, os.O_RDONLY, label=label)
    except FileNotFoundError:
        raise
    except OSError as exc:
        raise ValueError(f"Cannot read {label}: {rel_path}: {exc}") from exc
    with os.fdopen(fd, "r", encoding="utf-8") as handle:
        return handle.read()


def _write_child_text_no_symlink(root: Path, rel_path: str, text: str, *, label: str) -> None:
    try:
        fd = _open_child_no_symlink(root, rel_path, os.O_WRONLY | os.O_TRUNC, label=label)
    except FileNotFoundError as exc:
        raise ValueError(f"Patch target file does not exist: {rel_path}") from exc
    except OSError as exc:
        raise ValueError(f"Cannot write {label}: {rel_path}: {exc}") from exc
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(text)


def _open_child_no_symlink(root: Path, rel_path: str, flags: int, *, label: str) -> int:
    normalized = safe_relative_path(rel_path, label=label)
    parts = normalized.split("/")
    if not _supports_openat():
        return _open_child_no_symlink_fallback(root, normalized, flags, label=label)

    dir_flags = os.O_RDONLY
    if hasattr(os, "O_DIRECTORY"):
        dir_flags |= os.O_DIRECTORY
    nofollow = getattr(os, "O_NOFOLLOW", 0)

    current_fd = os.open(Path(root).resolve(), dir_flags)
    try:
        for part in parts[:-1]:
            next_fd = os.open(part, dir_flags | nofollow, dir_fd=current_fd)
            try:
                if not stat.S_ISDIR(os.fstat(next_fd).st_mode):
                    raise ValueError(f"{label} parent is not a directory: {rel_path}")
            except Exception:
                os.close(next_fd)
                raise
            os.close(current_fd)
            current_fd = next_fd

        try:
            fd = os.open(parts[-1], flags | nofollow, dir_fd=current_fd)
        except OSError as exc:
            if exc.errno == errno.ELOOP:
                raise ValueError(f"Refusing to follow symlink for {label}: {rel_path}") from exc
            raise
        try:
            if not stat.S_ISREG(os.fstat(fd).st_mode):
                raise ValueError(f"{label} is not a regular file: {rel_path}")
        except Exception:
            os.close(fd)
            raise
        return fd
    finally:
        os.close(current_fd)


def _open_child_no_symlink_fallback(root: Path, rel_path: str, flags: int, *, label: str) -> int:
    unresolved_path = unresolved_child_path(root, rel_path, label=label)
    if unresolved_path.is_symlink():
        raise ValueError(f"Refusing to follow symlink for {label}: {rel_path}")
    path = safe_child_path(root, rel_path, label=label)
    fd = os.open(path, flags)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise ValueError(f"{label} is not a regular file: {rel_path}")
    except Exception:
        os.close(fd)
        raise
    return fd


def _supports_openat() -> bool:
    return os.open in getattr(os, "supports_dir_fd", set())
