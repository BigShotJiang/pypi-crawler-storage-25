"""Prompt overlay injection via tail-anchor replacement."""

# Prompt tail anchors are adapted from tweakcc prompt catalogs. See THIRD_PARTY_NOTICES.md.
from dataclasses import dataclass


OVERLAY_MARKERS = {
    "start": "<!-- cc-mirror:provider-overlay start -->",
    "end": "<!-- cc-mirror:provider-overlay end -->",
}

ANCHORS = {
    "webfetch": {
        "tail": "- For GitHub URLs, prefer using the gh CLI via Bash instead (e.g., gh pr view, gh issue view, gh api).",
    },
    "websearch": {
        "tail": 'Example: If the user asks for "latest React docs", search for "React documentation" with the current year, NOT last year',
    },
    "explore": {
        "tail": "Complete the user's search request efficiently and report your findings clearly.",
    },
    "planEnhanced": {
        "tail": "REMEMBER: You can ONLY explore and plan. You CANNOT and MUST NOT write, edit, or modify any files. You do NOT have access to file editing tools.",
    },
    "enterPlan": {
        "tail": "- Users appreciate being consulted before significant changes are made to their codebase",
    },
    "skill": {
        "tail": "tag in the current conversation turn, the skill has ALREADY been loaded - follow the instructions directly instead of calling this tool again",
    },
    "conversationSummary": {
        "tail": "When you are using compact - please focus on test output and code changes. Include file reads verbatim.",
    },
    "webfetchSummary": {
        "tail": "- Never produce or reproduce exact song lyrics.",
    },
}


@dataclass
class PromptResult:
    js: str
    replaced_targets: list
    missing: list


def apply_prompts(js, overlays):
    replaced_targets = []
    missing = []
    overlays = overlays or {}

    for key, overlay_text in overlays.items():
        if overlay_text is None or not str(overlay_text).strip():
            continue

        spec = ANCHORS.get(key)
        if spec is None:
            missing.append(key)
            continue

        tail_index = js.find(spec["tail"])
        if tail_index == -1:
            missing.append(key)
            continue

        tail_end = tail_index + len(spec["tail"])
        delim = _detect_delimiter(js, tail_index)
        stripped_js, insertion_point = _strip_existing_block(js, tail_end, delim)
        js = stripped_js
        block = _build_overlay_block(str(overlay_text), delim)
        if not block:
            continue
        js = js[:insertion_point] + block + js[insertion_point:]
        replaced_targets.append(key)

    return PromptResult(js=js, replaced_targets=replaced_targets, missing=missing)


def _detect_delimiter(js, index):
    stack = ["normal"]
    escaped = False
    pos = 0
    while pos < index:
        ch = js[pos]
        nxt = js[pos + 1] if pos + 1 < len(js) else ""
        mode = stack[-1]
        if mode == "line-comment":
            if ch in "\r\n":
                stack.pop()
        elif mode == "block-comment":
            if ch == "*" and nxt == "/":
                stack.pop()
                pos += 1
        elif isinstance(mode, tuple) and mode[0] == "string":
            delim = mode[1]
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == delim:
                stack.pop()
        elif mode == "template":
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == "$" and nxt == "{":
                stack.append(("template-expr", 1))
                pos += 1
            elif ch == "`":
                stack.pop()
        elif isinstance(mode, tuple) and mode[0] == "template-expr":
            depth = mode[1]
            if ch == "/" and nxt == "/":
                stack.append("line-comment")
                pos += 1
            elif ch == "/" and nxt == "*":
                stack.append("block-comment")
                pos += 1
            elif ch in ('"', "'"):
                stack.append(("string", ch))
                escaped = False
            elif ch == "`":
                stack.append("template")
                escaped = False
            elif ch == "{":
                stack[-1] = ("template-expr", depth + 1)
            elif ch == "}":
                if depth <= 1:
                    stack.pop()
                else:
                    stack[-1] = ("template-expr", depth - 1)
        elif ch == "/" and nxt == "/":
            stack.append("line-comment")
            pos += 1
        elif ch == "/" and nxt == "*":
            stack.append("block-comment")
            pos += 1
        elif ch in ('"', "'"):
            stack.append(("string", ch))
            escaped = False
        elif ch == "`":
            stack.append("template")
            escaped = False
        pos += 1
    mode = stack[-1]
    if mode == "template":
        return "`"
    if isinstance(mode, tuple) and mode[0] == "string":
        return mode[1]
    return "`"


def _escape_for_delimiter(text, delim):
    if delim == "`":
        return text.replace("`", "\\`").replace("${", "\\${")
    return text.replace("\\", "\\\\").replace(delim, "\\" + delim).replace("\n", "\\n")


def _build_overlay_block(overlay, delim):
    trimmed = overlay.strip()
    if not trimmed:
        return ""
    _reject_reserved_overlay_markers(trimmed)
    block = f"\n\n{OVERLAY_MARKERS['start']}\n{trimmed}\n{OVERLAY_MARKERS['end']}\n"
    return _escape_for_delimiter(block, delim)


def _reject_reserved_overlay_markers(overlay):
    for marker in OVERLAY_MARKERS.values():
        if marker in overlay:
            raise ValueError("provider overlay contains reserved marker text")


def _strip_existing_block(js, tail_end, delim):
    escaped_start = _escape_for_delimiter(f"\n\n{OVERLAY_MARKERS['start']}", delim)
    escaped_end = _escape_for_delimiter(f"{OVERLAY_MARKERS['end']}\n", delim)
    if js[tail_end : tail_end + len(escaped_start)] != escaped_start:
        return js, tail_end
    end_index = js.find(escaped_end, tail_end + len(escaped_start))
    if end_index == -1:
        return js, tail_end
    strip_until = end_index + len(escaped_end)
    return js[:tail_end] + js[strip_until:], tail_end
