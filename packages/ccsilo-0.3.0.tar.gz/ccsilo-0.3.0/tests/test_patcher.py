import hashlib
import json
import struct

import pytest

from ccsilo.bundler import pack_bundle
from ccsilo.extractor import extract_all
import ccsilo.patcher as patcher_module
from ccsilo.patcher import apply_patch, init_patch, write_source_metadata


def create_mock_macho(bun_offset, bun_size):
    header = bytearray(32)
    struct.pack_into("<I", header, 0, 0xFEEDFACF)
    struct.pack_into("<I", header, 4, 0x01000007)
    struct.pack_into("<I", header, 8, 3)
    struct.pack_into("<I", header, 12, 2)
    struct.pack_into("<I", header, 16, 2)
    struct.pack_into("<I", header, 20, 176)
    struct.pack_into("<I", header, 24, 0)
    struct.pack_into("<I", header, 28, 0)

    segment_cmd = bytearray(152)
    struct.pack_into("<I", segment_cmd, 0, 0x19)
    struct.pack_into("<I", segment_cmd, 4, 152)
    segment_cmd[8:24] = b'__BUN\x00\x00\x00\x00\x00\x00'
    struct.pack_into("<Q", segment_cmd, 24, 0x1000)
    struct.pack_into("<Q", segment_cmd, 32, bun_size)
    struct.pack_into("<Q", segment_cmd, 40, bun_offset)
    struct.pack_into("<Q", segment_cmd, 48, bun_size)
    struct.pack_into("<I", segment_cmd, 64, 1)

    sect_offset = 72
    segment_cmd[sect_offset:sect_offset + 16] = b'__bun\x00\x00\x00\x00\x00'
    segment_cmd[sect_offset + 16:sect_offset + 32] = b'__BUN\x00\x00\x00\x00\x00\x00'
    struct.pack_into("<Q", segment_cmd, sect_offset + 32, 0x1000)
    struct.pack_into("<Q", segment_cmd, sect_offset + 40, bun_size)
    struct.pack_into("<I", segment_cmd, sect_offset + 48, bun_offset)

    build_version = bytearray(24)
    struct.pack_into("<I", build_version, 0, 0x8000001D)
    struct.pack_into("<I", build_version, 4, 24)

    binary = bytearray(bun_offset + bun_size)
    binary[:len(header)] = header
    binary[len(header):len(header) + len(segment_cmd)] = segment_cmd
    binary[len(header) + len(segment_cmd):len(header) + len(segment_cmd) + len(build_version)] = build_version
    return bytes(binary)


def make_v2_entry(raw_path, file_data):
    path_bytes = raw_path.encode("utf-8")
    metadata = b"\xfa\xf9\x0d\x04" + (b"\x00" * 14) + struct.pack("<I", len(file_data))
    entry = struct.pack("<I", len(path_bytes)) + path_bytes + metadata + file_data
    return entry


def make_extract_dir(tmp_path, content="const value = 'before';\n", write_metadata=False, source_version="1.2.3"):
    extract_dir = tmp_path / "extract"
    extract_dir.mkdir()
    target_path = extract_dir / "app.js"
    target_path.write_text(content, encoding="utf-8")

    binary_path = tmp_path / "claude"
    binary_path.write_bytes(b"binary-data")

    if write_metadata:
        write_source_metadata(extract_dir, binary_path, source_version=source_version)

    return extract_dir, target_path, binary_path


def write_patch_manifest(patch_dir, manifest):
    patch_dir.mkdir(parents=True, exist_ok=True)
    (patch_dir / "patch.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


def make_patch_manifest(*, targets=None, operations=None):
    if operations is None:
        operations = [
            {
                "type": "replace_string",
                "path": "app.js",
                "find": "before",
                "replace": "after",
            }
        ]

    return {
        "id": "test.patch",
        "description": "Test patch",
        "targets": targets or {
            "versions": [],
            "binary_sha256": [],
        },
        "operations": operations,
    }


class TestInitPatch:
    def test_init_patch_creates_scaffold(self, tmp_path):
        patch_dir = tmp_path / "patch"

        init_patch(patch_dir)

        manifest = json.loads((patch_dir / "patch.json").read_text())
        assert manifest["id"] == "example.patch"
        assert manifest["targets"] == {
            "versions": [],
            "binary_sha256": [],
        }
        assert [op["type"] for op in manifest["operations"]] == [
            "replace_string",
            "replace_block",
        ]
        assert (patch_dir / "blocks" / "find_example.js").exists()
        assert (patch_dir / "blocks" / "replace_example.js").exists()


class TestPatchTargets:
    def test_apply_patch_accepts_matching_version_and_checksum(self, tmp_path):
        extract_dir, target_path, binary_path = make_extract_dir(tmp_path, write_metadata=True)
        checksum = hashlib.sha256(binary_path.read_bytes()).hexdigest()

        patch_dir = tmp_path / "patch"
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                targets={
                    "versions": ["1.2.3"],
                    "binary_sha256": [checksum],
                },
            ),
        )

        apply_patch(patch_dir, extract_dir)

        assert target_path.read_text(encoding="utf-8") == "const value = 'after';\n"

    def test_apply_patch_rejects_version_mismatch(self, tmp_path):
        extract_dir, _, binary_path = make_extract_dir(tmp_path, write_metadata=True, source_version="1.2.3")
        checksum = hashlib.sha256(binary_path.read_bytes()).hexdigest()

        patch_dir = tmp_path / "patch"
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                targets={
                    "versions": ["9.9.9"],
                    "binary_sha256": [checksum],
                },
            ),
        )

        with pytest.raises(ValueError, match="source version"):
            apply_patch(patch_dir, extract_dir)

    def test_apply_patch_rejects_checksum_mismatch(self, tmp_path):
        extract_dir, _, _ = make_extract_dir(tmp_path, write_metadata=True)
        other_binary = tmp_path / "other-claude"
        other_binary.write_bytes(b"other-binary-data")
        checksum = hashlib.sha256(other_binary.read_bytes()).hexdigest()

        patch_dir = tmp_path / "patch"
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                targets={
                    "versions": [],
                    "binary_sha256": [checksum],
                },
            ),
        )

        with pytest.raises(ValueError, match="checksum"):
            apply_patch(patch_dir, extract_dir)

    def test_apply_patch_requires_metadata_or_overrides_for_targeted_patch(self, tmp_path):
        extract_dir, _, binary_path = make_extract_dir(tmp_path, write_metadata=False)
        checksum = hashlib.sha256(binary_path.read_bytes()).hexdigest()

        patch_dir = tmp_path / "patch"
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                targets={
                    "versions": ["1.2.3"],
                    "binary_sha256": [checksum],
                },
            ),
        )

        with pytest.raises(ValueError, match="source version metadata"):
            apply_patch(patch_dir, extract_dir)

    def test_apply_patch_accepts_overrides_when_source_metadata_is_missing(self, tmp_path):
        extract_dir, target_path, binary_path = make_extract_dir(tmp_path, write_metadata=False)
        checksum = hashlib.sha256(binary_path.read_bytes()).hexdigest()

        patch_dir = tmp_path / "patch"
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                targets={
                    "versions": ["1.2.3"],
                    "binary_sha256": [checksum],
                },
            ),
        )

        apply_patch(
            patch_dir,
            extract_dir,
            binary_path=binary_path,
            source_version="1.2.3",
        )

        assert target_path.read_text(encoding="utf-8") == "const value = 'after';\n"


class TestReplaceString:
    def test_replace_string_exact_single_match_success(self, tmp_path):
        extract_dir, target_path, _ = make_extract_dir(tmp_path, content="one before two\n")

        patch_dir = tmp_path / "patch"
        write_patch_manifest(patch_dir, make_patch_manifest())

        apply_patch(patch_dir, extract_dir)

        assert target_path.read_text(encoding="utf-8") == "one after two\n"

    def test_replace_string_zero_matches(self, tmp_path):
        extract_dir, _, _ = make_extract_dir(tmp_path, content="no target here\n")

        patch_dir = tmp_path / "patch"
        write_patch_manifest(patch_dir, make_patch_manifest())

        with pytest.raises(ValueError, match="found no matches"):
            apply_patch(patch_dir, extract_dir)

    def test_replace_string_rejects_multiple_matches_when_count_is_default(self, tmp_path):
        extract_dir, _, _ = make_extract_dir(tmp_path, content="before and before\n")

        patch_dir = tmp_path / "patch"
        write_patch_manifest(patch_dir, make_patch_manifest())

        with pytest.raises(ValueError, match="expected 1 match"):
            apply_patch(patch_dir, extract_dir)

    def test_replace_string_allows_multiple_matches_when_count_matches(self, tmp_path):
        extract_dir, target_path, _ = make_extract_dir(tmp_path, content="before and before\n")

        patch_dir = tmp_path / "patch"
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                operations=[
                    {
                        "type": "replace_string",
                        "path": "app.js",
                        "find": "before",
                        "replace": "after",
                        "count": 2,
                    }
                ],
            ),
        )

        apply_patch(patch_dir, extract_dir)

        assert target_path.read_text(encoding="utf-8") == "after and after\n"

    def test_replace_string_rejects_path_traversal(self, tmp_path):
        extract_dir, _, _ = make_extract_dir(tmp_path)

        patch_dir = tmp_path / "patch"
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                operations=[
                    {
                        "type": "replace_string",
                        "path": "../outside.js",
                        "find": "before",
                        "replace": "after",
                    }
                ],
            ),
        )

        with pytest.raises(ValueError, match="unsafe path segment"):
            apply_patch(patch_dir, extract_dir)

    def test_replace_string_rejects_symlink_target(self, tmp_path):
        extract_dir, _, _ = make_extract_dir(tmp_path)
        real_path = extract_dir / "real.js"
        real_path.write_text("const value = 'before';\n", encoding="utf-8")
        link_path = extract_dir / "link.js"
        try:
            link_path.symlink_to(real_path)
        except OSError as exc:
            pytest.skip(f"symlink unavailable: {exc}")

        patch_dir = tmp_path / "patch"
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                operations=[
                    {
                        "type": "replace_string",
                        "path": "link.js",
                        "find": "before",
                        "replace": "after",
                    }
                ],
            ),
        )

        with pytest.raises(ValueError, match="Refusing to patch symlink"):
            apply_patch(patch_dir, extract_dir)

    def test_replace_string_rejects_symlink_swapped_before_write(self, tmp_path, monkeypatch):
        extract_dir, target_path, _ = make_extract_dir(tmp_path)
        outside = tmp_path / "outside.js"
        outside.write_text("const value = 'outside';\n", encoding="utf-8")

        patch_dir = tmp_path / "patch"
        write_patch_manifest(patch_dir, make_patch_manifest())
        original_apply_operation = patcher_module.apply_patch_operation

        def swap_target_to_symlink(*args, **kwargs):
            result = original_apply_operation(*args, **kwargs)
            target_path.unlink()
            target_path.symlink_to(outside)
            return result

        monkeypatch.setattr(patcher_module, "apply_patch_operation", swap_target_to_symlink)

        with pytest.raises(ValueError, match="symlink|Cannot write"):
            apply_patch(patch_dir, extract_dir)

        assert outside.read_text(encoding="utf-8") == "const value = 'outside';\n"


class TestReplaceBlock:
    def test_replace_block_success(self, tmp_path):
        extract_dir, target_path, _ = make_extract_dir(
            tmp_path,
            content="function example() {\n  return 'before';\n}\n",
        )

        patch_dir = tmp_path / "patch"
        (patch_dir / "blocks").mkdir(parents=True)
        (patch_dir / "blocks" / "find.js").write_text(
            "function example() {\n  return 'before';\n}\n",
            encoding="utf-8",
        )
        (patch_dir / "blocks" / "replace.js").write_text(
            "function example() {\n  return 'after';\n}\n",
            encoding="utf-8",
        )
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                operations=[
                    {
                        "type": "replace_block",
                        "path": "app.js",
                        "find_file": "blocks/find.js",
                        "replace_file": "blocks/replace.js",
                    }
                ],
            ),
        )

        apply_patch(patch_dir, extract_dir)

        assert target_path.read_text(encoding="utf-8") == "function example() {\n  return 'after';\n}\n"

    def test_replace_block_missing_asset(self, tmp_path):
        extract_dir, _, _ = make_extract_dir(
            tmp_path,
            content="function example() {\n  return 'before';\n}\n",
        )

        patch_dir = tmp_path / "patch"
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                operations=[
                    {
                        "type": "replace_block",
                        "path": "app.js",
                        "find_file": "blocks/find.js",
                        "replace_file": "blocks/replace.js",
                    }
                ],
            ),
        )

        with pytest.raises(ValueError, match="Patch asset does not exist"):
            apply_patch(patch_dir, extract_dir)

    def test_replace_block_rejects_asset_traversal(self, tmp_path):
        extract_dir, _, _ = make_extract_dir(
            tmp_path,
            content="function example() {\n  return 'before';\n}\n",
        )

        patch_dir = tmp_path / "patch"
        outside = tmp_path / "find.js"
        outside.write_text("function example() {\n  return 'before';\n}\n", encoding="utf-8")
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                operations=[
                    {
                        "type": "replace_block",
                        "path": "app.js",
                        "find_file": "../find.js",
                        "replace_file": "blocks/replace.js",
                    }
                ],
            ),
        )

        with pytest.raises(ValueError, match="unsafe path segment"):
            apply_patch(patch_dir, extract_dir)

    def test_replace_block_rejects_symlink_asset(self, tmp_path):
        extract_dir, _, _ = make_extract_dir(
            tmp_path,
            content="function example() {\n  return 'before';\n}\n",
        )

        patch_dir = tmp_path / "patch"
        (patch_dir / "blocks").mkdir(parents=True)
        real_find = patch_dir / "blocks" / "find-real.js"
        real_find.write_text("function example() {\n  return 'before';\n}\n", encoding="utf-8")
        try:
            (patch_dir / "blocks" / "find.js").symlink_to(real_find)
        except OSError as exc:
            pytest.skip(f"symlink unavailable: {exc}")
        (patch_dir / "blocks" / "replace.js").write_text(
            "function example() {\n  return 'after';\n}\n",
            encoding="utf-8",
        )
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                operations=[
                    {
                        "type": "replace_block",
                        "path": "app.js",
                        "find_file": "blocks/find.js",
                        "replace_file": "blocks/replace.js",
                    }
                ],
            ),
        )

        with pytest.raises(ValueError, match="Refusing to read symlink patch asset"):
            apply_patch(patch_dir, extract_dir)

    def test_replace_block_count_mismatch(self, tmp_path):
        extract_dir, _, _ = make_extract_dir(
            tmp_path,
            content=(
                "function example() {\n  return 'before';\n}\n"
                "function example() {\n  return 'before';\n}\n"
            ),
        )

        patch_dir = tmp_path / "patch"
        (patch_dir / "blocks").mkdir(parents=True)
        (patch_dir / "blocks" / "find.js").write_text(
            "function example() {\n  return 'before';\n}\n",
            encoding="utf-8",
        )
        (patch_dir / "blocks" / "replace.js").write_text(
            "function example() {\n  return 'after';\n}\n",
            encoding="utf-8",
        )
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                operations=[
                    {
                        "type": "replace_block",
                        "path": "app.js",
                        "find_file": "blocks/find.js",
                        "replace_file": "blocks/replace.js",
                    }
                ],
            ),
        )

        with pytest.raises(ValueError, match="expected 1 match"):
            apply_patch(patch_dir, extract_dir)


class TestPatchCheckMode:
    def test_check_mode_does_not_mutate_files(self, tmp_path):
        extract_dir, target_path, _ = make_extract_dir(tmp_path, content="before only\n")

        patch_dir = tmp_path / "patch"
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                operations=[
                    {
                        "type": "replace_string",
                        "path": "app.js",
                        "find": "before",
                        "replace": "after",
                    }
                ],
            ),
        )

        apply_patch(patch_dir, extract_dir, check=True)

        assert target_path.read_text(encoding="utf-8") == "before only\n"


def create_mock_standalone_graph_patcher(content=b"console.log('before');\n"):
    name = b"app.js"
    data_buffer = bytearray()
    
    name_off = len(data_buffer)
    data_buffer.extend(name)
    name_len = len(name)
    
    cont_off = len(data_buffer)
    data_buffer.extend(content)
    cont_len = len(content)
    
    smap_off, smap_len = 0, 0
    bc_off, bc_len = 0, 0
    mod_offset = len(data_buffer)
    
    struct_data = struct.pack("<IIIIIIII", name_off, name_len, cont_off, cont_len, smap_off, smap_len, bc_off, bc_len)
    struct_data += bytes(16)
    struct_data += struct.pack("BBBB", 2, 1, 1, 0)
    
    module_table = struct_data
    mod_length = len(module_table)
    byte_count = mod_offset + mod_length
    
    offsets_struct = struct.pack("<QIIIIII", byte_count, mod_offset, mod_length, 0, 0, 0, 0)
    trailer = b"\n---- Bun! ----\n"
    
    return data_buffer + module_table + offsets_struct + trailer

class TestEndToEndPatchFlow:
    def test_extract_apply_patch_and_pack_round_trip(self, tmp_path):
        bun_offset = 0x4000
        original_data = b"console.log('before');\n"
        payload = create_mock_standalone_graph_patcher(original_data)
        bun_size = len(payload) + 8

        base_binary = tmp_path / "claude"
        binary = bytearray(create_mock_macho(bun_offset, bun_size))
        struct.pack_into("<Q", binary, bun_offset, bun_size)
        binary[bun_offset + 8:bun_offset + 8 + len(payload)] = payload
        base_binary.write_bytes(binary)

        extract_dir = tmp_path / "extract"
        extract_all(str(base_binary), str(extract_dir), source_version="1.2.3")

        checksum = hashlib.sha256(base_binary.read_bytes()).hexdigest()
        patch_dir = tmp_path / "patch"
        write_patch_manifest(
            patch_dir,
            make_patch_manifest(
                targets={
                    "versions": ["1.2.3"],
                    "binary_sha256": [checksum],
                },
                operations=[
                    {
                        "type": "replace_string",
                        "path": "app.js",
                        "find": "console.log('before');",
                        "replace": "console.log('after');",
                    }
                ],
            ),
        )

        apply_patch(patch_dir, extract_dir)

        rebuilt_binary = tmp_path / "claude-patched"
        pack_bundle(str(extract_dir), str(rebuilt_binary), str(base_binary))

        roundtrip_extract_dir = tmp_path / "roundtrip"
        extract_all(str(rebuilt_binary), str(roundtrip_extract_dir))

        assert (roundtrip_extract_dir / "app.js").read_text(encoding="utf-8") == "console.log('after');\n"
