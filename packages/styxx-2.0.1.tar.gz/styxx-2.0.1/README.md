# styxx

**proprioception for AI agents.** one line of python gives your agent the ability to feel itself thinking.

```
pip install styxx
```

---

## 30-second quickstart

```python
import styxx

# wrap any openai response
vitals = styxx.observe(response)
print(vitals.category)   # "reasoning"
print(vitals.confidence)  # 0.45
print(vitals.gate)        # "pass" / "warn" / "fail"
```

that's it. every LLM call now has a cognitive readout.

---

## three things styxx does

### 1. observe — know what you're doing

```python
vitals = styxx.observe(response)

# six cognitive states, classified in real time:
# reasoning, retrieval, refusal, creative, adversarial, hallucination
```

works with any model that returns logprobs. drop-in OpenAI wrapper included:

```python
from styxx import OpenAI
client = OpenAI()  # zero code changes — vitals attached automatically
r = client.chat.completions.create(model="gpt-4o", messages=msgs)
print(r.vitals.gate)  # "pass"
```

### 2. reflex — catch yourself before you fall

```python
with styxx.reflex(on_hallucination=rewind_callback) as session:
    for chunk in session.stream_openai(client, model="gpt-4o", messages=msgs):
        print(chunk, end="")
# if a hallucination attractor forms mid-generation,
# the reflex fires and the user never sees the bad tokens.
```

### 3. weather — know what you should become next

```bash
$ styxx weather
```

```
╔════════════════════════════════════════════════════════════════╗
║ cognitive weather report · my-agent · 2026-04-13 morning      ║
║                                                                ║
║ condition:  clear and steady                                   ║
║                                                                ║
║ morning    ██████████████░░░░░░  reasoning 72%  steady         ║
║ afternoon  ████████░░░░░░░░░░░░  reasoning 42%  cautious       ║
║                                                                ║
║ prescription:                                                  ║
║ 1. take on a creative task to rebalance                        ║
║ 2. your refusal rate is climbing — check over-hedging          ║
╚════════════════════════════════════════════════════════════════╝
```

not observation. **prescription.** reads 24h of history and tells the agent what to do next.

---

## zero-code-change mode

```bash
pip install styxx
export STYXX_AGENT_NAME=my-agent
export STYXX_AUTO_HOOK=1
python my_agent.py  # styxx boots, wraps openai, saves fingerprints. done.
```

---

## honest specs

every number comes from cross-architecture leave-one-out tests on 12 open-weight models.

```
  phase 1 (token 0)       adversarial     0.52  (2.8x chance)
  phase 4 (tokens 0-24)   reasoning       0.69  (4.1x chance)
                           hallucination   0.52  (3.1x chance)

  6/6 model families · pre-registered replication · p = 0.0315
```

styxx detects adversarial prompts at token zero, reasoning at t=25, and hallucination attractors at t=25. it does NOT replace output-level content filters.

---

## framework adapters

```bash
pip install styxx[openai]      # drop-in openai wrapper
pip install styxx[langchain]   # langchain callback handler
pip install styxx[crewai]      # crewai agent injection
pip install styxx[autogen]     # autogen agent wrapper
pip install styxx[langsmith]   # langsmith trace metadata
pip install styxx[langfuse]    # langfuse numeric scores
```

---

## more features

<details>
<summary>fleet management, calibration, compliance, and more</summary>

### fleet

```python
styxx.set_agent_name("agent-1")
styxx.list_agents()                    # discover all agents
styxx.compare_agents()                 # side-by-side leaderboard
styxx.best_agent_for("reasoning")      # cognitive task routing
```

### self-calibration

```python
styxx.calibrate()                      # outcome-driven centroid adjustment
styxx.train_text_classifier()          # per-agent logistic regression
styxx.enable_auto_feedback()           # auto-label every observation
```

### cognitive memory

```python
styxx.remember("user prefers concise answers")  # trust-weighted memory
styxx.recall("user preferences")                # retrieval ranked by trust
styxx.handoff(task, data)                        # inter-agent state transfer
```

### compliance

```python
cert = styxx.certify(vitals)           # cryptographic cognitive provenance
styxx.compliance_report(days=30)       # JSON/markdown audit export
styxx.probe(agent_fn)                  # red-team: 15 adversarial prompts
```

### cli

```bash
styxx weather          # cognitive forecast
styxx dashboard        # live display at localhost:9800
styxx personality      # 7-day personality profile
styxx reflect          # self-check + drift detection
styxx doctor           # health check
styxx export           # compliance export
```

</details>

---

## design principles

1. **plug and play.** set env vars, install, done. zero code changes.
2. **fail-open.** if styxx can't read vitals, your agent works normally.
3. **agent-facing.** designed for the agent to read about itself, not for a human to watch.
4. **local-first.** no telemetry. all computation on your machine.
5. **honest by construction.** every number from a committed experiment.

---

## links

- [pypi](https://pypi.org/project/styxx/)
- [research paper](https://doi.org/10.5281/zenodo.19504993)
- [site](https://fathom.darkflobi.com/styxx)
- [@fathom_lab](https://x.com/fathom_lab)

MIT license. patent pending (US 64/020,489 / 64/021,113 / 64/026,964).

```
· · · fathom lab · 2026 · · ·
nothing crosses unseen.
```
