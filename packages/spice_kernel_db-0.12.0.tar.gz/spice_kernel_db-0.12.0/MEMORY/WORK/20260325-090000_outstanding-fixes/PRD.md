---
task: Fix outstanding CLI gaps and stale docs
slug: 20260325-090000_outstanding-fixes
effort: advanced
phase: complete
progress: 28/28
mode: interactive
started: 2026-03-25T09:00:00+01:00
updated: 2026-03-25T09:45:00+01:00
---

## Context

Continued from yesterday's review. Fixed all remaining issues that didn't need user feedback.

## Criteria

- [x] ISC-1: design.qmd resolution flowchart updated to 3-step (no fuzzy)
- [x] ISC-2: design.qmd "Fuzzy matching" subsection replaced with "Path-suffix matching"
- [x] ISC-3: design.qmd tqdm reference replaced with rich
- [x] ISC-4: design.qmd server_url example fixed
- [x] ISC-5: design.qmd ER diagram includes kernel_coverage table
- [x] ISC-6: api.qmd KernelDB constructor signature correct
- [x] ISC-7: api.qmd scan_directory return type correct (tuple)
- [x] ISC-8: api.qmd scan_directory includes archive_dir param
- [x] ISC-9: api.qmd register_file includes archive_dir and expected_hash params
- [x] ISC-10: api.qmd get_metakernel includes force param
- [x] ISC-11: api.qmd check_metakernel includes verbose param
- [x] ISC-12: api.qmd browse_remote_metakernels includes show_versioned param
- [x] ISC-13: api.qmd resolve_kernel steps updated (3-step, no fuzzy)
- [x] ISC-14: api.qmd update_metakernel documented
- [x] ISC-15: cli.qmd get/update include --force flag
- [x] ISC-16: cli.qmd get usage shows url as optional
- [x] ISC-17: cli.qmd browse no-args output matches code
- [x] ISC-18: README Python version corrected to >= 3.11
- [x] ISC-19: _quarto.yml description updated
- [x] ISC-20: mk --remove implemented
- [x] ISC-21: mk remove test passes (3 tests)
- [x] ISC-22: prune command implemented
- [x] ISC-23: prune test passes (2 tests)
- [x] ISC-24: browse no-args now interactive (picks mission and browses)
- [x] ISC-25: pyproject.toml status changed to Beta
- [x] ISC-26: CLAUDE.md schema section updated (6 tables, kernel_coverage)
- [x] ISC-27: CLAUDE.md resolve_kernel description updated (no fuzzy)
- [x] ISC-28: All 150 tests pass

## Verification

All 28 criteria verified via grep/tool output. 150 tests passing. 3 commits made.
