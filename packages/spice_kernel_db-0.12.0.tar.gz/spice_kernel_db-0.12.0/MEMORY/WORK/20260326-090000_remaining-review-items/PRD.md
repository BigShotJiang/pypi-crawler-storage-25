---
task: Fix all remaining open review items
slug: 20260326-090000_remaining-review-items
effort: advanced
phase: execute
progress: 0/38
mode: interactive
started: 2026-03-26T09:00:00+01:00
updated: 2026-03-26T09:10:00+01:00
---

## Context

19 remaining review items, all "minor" severity. Fixing them all to get review.qmd to 100%.

## Criteria

C1 --mission help text:
- [ ] ISC-1: scan --mission help says "Override auto-detected mission name"
- [ ] ISC-2: get/update --mission help says "Override auto-detected mission name"
- [ ] ISC-3: check/list/mk --mission help says "Filter by mission name"
- [ ] ISC-4: browse --mission help says "Override auto-detected mission name"

C2 dedup confirmation:
- [ ] ISC-5: dedup --execute prompts for confirmation (or -y flag added)

C4 print vs console.print:
- [ ] ISC-6: db.py no longer uses raw print() for user-facing output

C5 global verbose:
- [ ] ISC-7: -v/--verbose is on the root parser (global)
- [ ] ISC-8: get and update pass verbose through

R2 mk/check/list overlap:
- [ ] ISC-9: mk help text includes "See also: check, list" cross-ref

R3 get/update relationship:
- [ ] ISC-10: update help text clarifies relationship to get

G2 resolve batch:
- [ ] ISC-11: resolve accepts --metakernel to resolve all kernels in a .tm
- [ ] ISC-12: resolve --metakernel test passes

G6 config set:
- [ ] ISC-13: config set <key> <value> subcommand works
- [ ] ISC-14: config get <key> subcommand works
- [ ] ISC-15: config set/get test passes

G7 coverage body_id rename:
- [ ] ISC-16: coverage positional renamed from body_id to body
- [ ] ISC-17: coverage help says "NAIF body ID or name"

G8 rewrite -o default:
- [ ] ISC-18: rewrite -o defaults to <stem>_local.tm when omitted

D1 See also:
- [ ] ISC-19: check help includes "See also: list, mk, resolve"
- [ ] ISC-20: list help includes "See also: check, mk"
- [ ] ISC-21: resolve help includes "See also: check"
- [ ] ISC-22: get help includes "See also: browse, update"
- [ ] ISC-23: update help includes "See also: get, browse"
- [ ] ISC-24: browse help includes "See also: get, mission add"

D2 workflow in help:
- [ ] ISC-25: epilog includes quick-start workflow hint

D3 get help text:
- [ ] ISC-26: get help text explains filename requires configured mission

E1 corrupt config:
- [ ] ISC-27: load_config catches TOMLDecodeError with friendly message

E2 browse URLError:
- [ ] ISC-28: browse catches URLError (network unreachable)

E3 coverage ImportError:
- [ ] ISC-29: coverage ImportError caught around body resolution too

DOC-16 usage.qmd browse:
- [ ] ISC-30: usage.qmd browse output updated to 3-state (yes/outdated/no)

DOC-17 usage.qmd list:
- [ ] ISC-31: usage.qmd mentions list command in inspect workflow

DOC-22 troubleshooting:
- [ ] ISC-32: troubleshooting section added to docs

Tests:
- [ ] ISC-33: test for resolve --metakernel
- [ ] ISC-34: test for config set/get
- [ ] ISC-35: test for corrupt config handling
- [ ] ISC-36: test for rewrite default output
- [ ] ISC-37: test for dedup confirmation
- [ ] ISC-38: all tests pass
