---
task: Review and fix CLI/docs before workgroup release
slug: 20260324-150000_cli-docs-review-fixes
effort: advanced
phase: complete
progress: 22/24
mode: interactive
started: 2026-03-24T15:00:00+01:00
updated: 2026-03-24T15:25:00+01:00
---

## Context

Maye wants to release spice-kernel-db to their workgroup but suspects CLI/docs inconsistencies. Two reviews (CLI + docs) identified 25+ issues. User explicitly requested: (1) write review into a QMD doc, (2) `skd` no-args should list MKs, (3) fix top 5 issues, (4) changelog + commit per fix.

### Risks
- `sys.exit()` removal in db.py could break existing error handling flow — MITIGATED: raises LookupError, caught in CLI
- Deferring `ensure_config()` could introduce None config — MITIGATED: config loaded after parse, before any command uses it

## Criteria

- [x] ISC-1: Review QMD doc exists at docs/review.qmd
- [x] ISC-2: Review QMD covers all CLI issues found
- [x] ISC-3: Review QMD covers all docs issues found
- [x] ISC-4: `--version` flag added to CLI parser
- [x] ISC-5: `--version` displays correct version from package metadata
- [x] ISC-6: Test for `--version` flag passes
- [x] ISC-7: `skd` entry point added to pyproject.toml
- [x] ISC-8: No-args invocation shows MK summary instead of just help
- [x] ISC-9: No-args output includes hint to browse/get workflow
- [x] ISC-10: Test for no-args behavior passes
- [x] ISC-11: `sys.exit(1)` removed from db.py update_metakernel (line 1284)
- [x] ISC-12: `sys.exit(1)` removed from db.py update_metakernel (line 1300)
- [x] ISC-13: db.py raises exceptions instead of sys.exit
- [x] ISC-14: cli.py catches those exceptions and exits gracefully
- [x] ISC-15: Test for update_metakernel error raising passes
- [x] ISC-16: `ensure_config()` deferred past --help and --version
- [x] ISC-17: `spice-kernel-db --help` works without config file
- [x] ISC-18: Test for deferred config passes
- [x] ISC-19: CHANGELOG has v0.10.1 entry
- [x] ISC-20: CHANGELOG has v0.11.0 entry for these fixes
- [x] ISC-21: All existing tests still pass after changes (145/145)
- [x] ISC-22: `sys.exit(1)` removed from cli.py _resolve_body_interactive
- [x] ISC-23: cli.py _resolve_body_interactive returns None instead of sys.exit
- [ ] ISC-24: browse (no args) consolidated — DEFERRED (lower priority, needs design discussion)

## Decisions

- Used LookupError (not ValueError) for update_metakernel since the issue is a failed lookup
- Version 0.11.0 (minor bump) since we added features (skd alias, no-args behavior, --version)
- Deferred browse/mission-list consolidation — needs discussion on desired behavior

## Verification

All 22/24 criteria verified via tool output. ISC-24 deferred by design choice.
