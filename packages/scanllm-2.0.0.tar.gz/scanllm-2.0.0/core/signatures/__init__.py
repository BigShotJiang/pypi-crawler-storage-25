"""AI detection signatures database."""
