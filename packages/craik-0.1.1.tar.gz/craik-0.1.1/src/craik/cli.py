"""Command-line interface for Craik."""

from __future__ import annotations

import json
import os
from importlib import import_module
from importlib.metadata import PackageNotFoundError, version
from typing import Annotated

import typer
from pydantic import ValidationError

from craik import __version__
from craik.cli_receipts import receipts_app
from craik.cli_runs import run_app
from craik.contracts.registry import schema_model, schema_names
from craik.runtime.doctor import run_doctor
from craik.runtime.gateway import default_gateway_config
from craik.runtime.paths import CraikPaths, ensure_craik_home, resolve_craik_paths
from craik.runtime.projects.update_guidance import update_guidance_payload
from craik.runtime.store import LocalStore

PACKAGE_NAME = "craik"

app = typer.Typer(
    add_completion=False,
    help="Governed agent-runtime substrate for case files, policy, receipts, and providers.",
    no_args_is_help=True,
)
schema_app = typer.Typer(help="Inspect Craik runtime contract schemas.")
app.add_typer(schema_app, name="schema")
home_app = typer.Typer(help="Inspect and initialize Craik local state paths.")
app.add_typer(home_app, name="home")
project_app = typer.Typer(help="Register and inspect Craik projects.")
app.add_typer(project_app, name="project")
task_app = typer.Typer(help="Create and inspect Craik tasks.")
app.add_typer(task_app, name="task")
intent_app = typer.Typer(help="Inspect task intent locks.")
app.add_typer(intent_app, name="intent")
case_app = typer.Typer(help="Build and inspect Craik case files.")
app.add_typer(case_app, name="case")
connect_app = typer.Typer(help="Connect to external services.")
app.add_typer(connect_app, name="connect")
demo_app = typer.Typer(help="Run built-in Craik demos.")
app.add_typer(demo_app, name="demo")
auth_app = typer.Typer(help="Manage provider credential profiles.")
app.add_typer(auth_app, name="auth")
contradictions_app = typer.Typer(help="Manage local contradiction reports.")
app.add_typer(contradictions_app, name="contradictions")
graph_app = typer.Typer(help="Export Craik work graphs.")
app.add_typer(graph_app, name="graph")
handoff_app = typer.Typer(help="Create and inspect Craik handoffs.")
app.add_typer(handoff_app, name="handoff")
memory_app = typer.Typer(help="Create and review local memory proposals.")
app.add_typer(memory_app, name="memory")
policy_app = typer.Typer(help="Inspect Craik policy profiles.")
app.add_typer(policy_app, name="policy")
app.add_typer(receipts_app, name="receipts")
app.add_typer(run_app, name="run")
runners_app = typer.Typer(help="Inspect runner capabilities and trust profiles.")
app.add_typer(runners_app, name="runners")
prompt_app = typer.Typer(help="Compile runner-ready prompts from Craik runtime state.")
app.add_typer(prompt_app, name="prompt")
provider_app = typer.Typer(help="Inspect and select model providers.")
app.add_typer(provider_app, name="provider")


def package_version() -> str:
    """Return the installed package version, with a source-tree fallback."""
    try:
        return version(PACKAGE_NAME)
    except PackageNotFoundError:
        return __version__


@app.callback(invoke_without_command=True)
def root(
    ctx: typer.Context,
    version_requested: Annotated[
        bool,
        typer.Option(
            "--version",
            help="Print the installed Craik version and exit.",
        ),
    ] = False,
) -> None:
    """Run Craik."""
    if version_requested:
        typer.echo(package_version())
        raise typer.Exit()

    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@app.command("version")
def version_command() -> None:
    """Print the installed Craik version."""
    typer.echo(package_version())


@app.command("setup")
def setup_command(
    project_id: Annotated[
        str | None,
        typer.Option("--project-id", help="Optional project id for gateway configuration."),
    ] = None,
    gateway_enabled: Annotated[
        bool,
        typer.Option(
            "--enable-gateway/--disable-gateway",
            help="Enable or disable the persisted gateway configuration.",
        ),
    ] = False,
    gateway_bind_host: Annotated[
        str,
        typer.Option("--gateway-bind-host", help="Gateway bind host. Defaults to local only."),
    ] = "127.0.0.1",
    gateway_port: Annotated[
        int,
        typer.Option("--gateway-port", help="Gateway port."),
    ] = 8765,
    policy_envelope_id: Annotated[
        str | None,
        typer.Option("--policy-envelope-id", help="Policy envelope for gateway authority."),
    ] = None,
) -> None:
    """Initialize local state and write non-secret gateway setup output."""
    paths = ensure_craik_home()
    store = LocalStore.from_paths(paths)
    try:
        store.initialize()
        config = default_gateway_config(
            project_id=project_id,
            policy_envelope_id=policy_envelope_id,
        ).model_copy(
            update={
                "bind_host": gateway_bind_host,
                "port": gateway_port,
                "enabled": gateway_enabled,
            }
        )
        try:
            config = type(config).model_validate(config.model_dump(mode="json", by_alias=True))
        except ValidationError as error:
            raise typer.BadParameter(str(error)) from None
        store.put_gateway_config(config)
        payload = {
            "home": _paths_payload(paths),
            "gateway_config": config.model_dump(mode="json", by_alias=True),
            "secrets_written": False,
            "next_steps": [
                "Review gateway_config before enabling external ingress.",
                "Store channel secrets outside Craik config files.",
                "Run gateway diagnostics before starting the daemon.",
            ],
        }
    finally:
        store.close()

    typer.echo(json.dumps(payload, indent=2, sort_keys=True))


@app.command("doctor")
def doctor_command() -> None:
    """Run read-only diagnostics for local and gateway readiness."""
    paths = resolve_craik_paths()
    payload = run_doctor(paths, env=dict(os.environ))
    typer.echo(json.dumps(payload, indent=2, sort_keys=True))


@app.command("update")
def update_command() -> None:
    """Print safe update guidance without modifying the installation."""
    payload = update_guidance_payload(installed_version=package_version())
    typer.echo(json.dumps(payload, indent=2, sort_keys=True))


@schema_app.command("list")
def schema_list() -> None:
    """List known Craik contract schemas."""
    for name in schema_names():
        typer.echo(name)


@schema_app.command("show")
def schema_show(name: str) -> None:
    """Print a contract JSON Schema by name."""
    try:
        model = schema_model(name)
    except KeyError:
        known = ", ".join(schema_names())
        raise typer.BadParameter(f"unknown schema {name!r}; known schemas: {known}") from None

    typer.echo(json.dumps(model.model_json_schema(), indent=2, sort_keys=True))




def _paths_payload(paths: CraikPaths) -> dict[str, str]:
    return {
        "cache": str(paths.cache),
        "case_files": str(paths.case_files),
        "config": str(paths.config),
        "handoffs": str(paths.handoffs),
        "home": str(paths.home),
        "logs": str(paths.logs),
        "projects": str(paths.projects),
        "receipts": str(paths.receipts),
        "secrets": str(paths.secrets),
        "state": str(paths.state),
    }


def _load_cli_extensions() -> None:
    """Import command modules that register subcommands on shared Typer apps."""
    for module_name in (
        "craik.cli_auth",
        "craik.cli_operations",
        "craik.cli_project",
    ):
        import_module(module_name)


_load_cli_extensions()


def main() -> None:
    app()
