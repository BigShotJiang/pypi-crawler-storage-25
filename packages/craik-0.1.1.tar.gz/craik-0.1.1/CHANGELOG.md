# Changelog

All notable Craik release changes are tracked here. Craik's first public
release target is a robust `0.x.0` MVP; `1.0.0` remains a later compatibility
signal after real-world usage and security soak.

This project follows the shape of Keep a Changelog and uses semantic versioning
within the `0.x.0` stability expectations described in
`docs/guides/release-management.md`.

## Unreleased

_No unreleased changes._

## 0.1.1 - 2026-05-18

### Fixed

- Restricted package metadata to Python 3.12 and 3.13 so `pipx install craik`
  does not select Python 3.14, where the current Pydantic runtime dependency
  cannot build compatible wheels.
- Updated installation and development docs to call out the Python 3.12/3.13
  support window and the `pipx --python` install path.
- Generalized the publish workflow tag guard so patch releases are checked
  against their own immutable version tag instead of being hardcoded to
  `v0.1.0`.

## 0.1.0 - 2026-05-17

### Added

- Live provider transport path with stdlib HTTP, explicit live access, retries,
  cancellation, streaming callback capture, and recorded chat-completions
  integration coverage.
- Provider adapters for OpenAI Responses, Anthropic Messages, and
  OpenAI-compatible Chat Completions, including local `/v1` provider metadata.
- Secret reference resolution for provider credentials without storing raw
  secret material in transport instances.
- Governed loop support for dispatchable provider tool calls and replayable
  streaming output chunks.

### Added — Pluggable credential sources

- Typed credential abstraction with `auth-profiles.json` and
  `<provider_family>:<name>` profile IDs.
- Credential sources: env-var API key, local-CLI OAuth fallback (e.g. Claude
  Code credentials), vendor-CLI subprocess bridge, external secret manager
  references, markers, and Stigmem-backed credential references.
- Credential pool with rotation, failover, and per-profile health tracking.
- Credential CLI: `craik auth list / add / remove / test / status / approve /
  grant`.
- Credential health surfaced in `craik doctor`.

### Added — OIDC operator identity

- OIDC operator authentication with device-code and loopback+PKCE flows.
- IdP discovery, JWKS-validated ID tokens (rejects `alg=none`, unknown `kid`,
  asymmetric/symmetric algorithm confusion), and refresh-token handling.
- Operator session store at `<CRAIK_HOME>/operator-session.json` with
  `craik login`, `craik logout`, `craik whoami`.
- Workload identity providers: GitHub Actions, Kubernetes projected service
  account token, generic file token, env-var token.
- RFC 8693 token-exchange secret manager for federated credential brokering.
- Operator identity bound to every provider call and persisted on every
  receipt.

### Added — Governance-native credential features

- Credential-scoped receipt fields: `auth_profile_id`, `auth_kind`,
  `auth_identity_hash`.
- Operator-scoped receipt fields: `operator_subject`, `operator_issuer`,
  `operator_email`, `operator_groups`.
- Policy envelopes can constrain operators (`required_operator`,
  `allowed_operator_groups`, `allowed_operator_subjects`,
  `required_operator_issuer`) and credentials (`allowed_credential_kinds`,
  `allowed_credential_profiles`).
- Approval-gated first live use of any credential profile, recorded as a
  receipt.
- Operator-credential authorization binding with a receipted grant chain.
- Credential expiry surfaced as evidence/risk in case files for long-running
  work.
- Per-credential redaction patterns extending the global redaction utility.
- Per-agent credential and operator isolation in handoff records (foundation
  for v0.3.0 multi-agent runtime).

## 0.0.0 - 2026-05-16

### Added

- Initial pre-release package metadata.
- Local CLI entrypoint and source-tree installation path.
