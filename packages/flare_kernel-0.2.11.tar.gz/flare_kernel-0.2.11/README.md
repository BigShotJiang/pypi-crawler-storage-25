# flare-kernel

通用编排与执行内核。

边界文档：

1. `packages/flare-kernel/docs/KERNEL-BOUNDARY.md`
2. `docs/contracts/core/agent.md`
3. `packages/flare-kernel/docs/replay-snapshot-technical-spec.md`

职责：

1. Decision 路由与策略入口。
2. Execution 流程推进与状态管理。
3. Runtime（含重试、超时、追踪）。
4. 加载 domain pack 并执行。

## Day 2 最小骨架

目录：

1. `src/flare_kernel/router`：接口路由
2. `src/flare_kernel/runtime`：`trace_id` 与基础日志
3. `src/flare_kernel/contracts`：请求/响应契约

最小接口：

1. `POST /kernel/run`
2. `POST /kernel/stream`
3. `GET /kernel/health`
4. `POST /kernel/knowledge/ingest`
5. `POST /kernel/knowledge/search`

kernel 现已输出 mode/context 运行时占位事件与字段。

## 品牌注入（可选）

1. kernel 支持从 domain-pack 读取品牌配置：
   `branding/instance-branding.json`
2. 读取方式：
   - 仅通过环境变量 `FLARE_DOMAIN_PACK_ROOT` 显式指定
3. 注入位置：
   - `POST /kernel/run` 响应 `result.instance_profile`
   - `POST /kernel/stream` SSE 事件 `instance_profile`

说明：品牌注入通过外部 domain-pack 配置，core 不写死产品名、logo、标签。

本地启动（示例）：

```bash
uvicorn flare_kernel.main:app --app-dir packages/flare-kernel/src --host 0.0.0.0 --port 8002
```

环境变量（真实链路）：

1. `DASHSCOPE_API_KEY`（必填，真实百炼调用）
2. `LLM_PROVIDER_BACKEND`（默认 `dashscope`）
3. `FLARE_POSTGRES_DSN`
4. `FLARE_REDIS_URL`
5. `FLARE_QDRANT_URL`

健康检查会输出依赖状态：

1. `llm_ready`
2. `postgres_ready`
3. `redis_ready`
4. `qdrant_ready`

模式决策优先级（`/kernel/run` 与 `/kernel/stream`）：

1. `intent_override`（外部业务侧注入）
2. 消息意图识别（内置关键词）
3. `manual_mode`
4. `current_mode`
5. fallback（`intent/default`）

## 最小发布说明

1. 当前包版本：`0.1.0`
2. 发布元数据：`packages/flare-kernel/pyproject.toml`
3. 本地构建：`python -m build`
4. 本地安装：`pip install packages/flare-kernel`
