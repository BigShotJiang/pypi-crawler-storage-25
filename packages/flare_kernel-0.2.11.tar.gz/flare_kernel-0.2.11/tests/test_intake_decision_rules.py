from __future__ import annotations

from flare_kernel.router.intake.decision_rules import (
    apply_entry_recommendation_to_decision,
    enforce_intake_gate_transition,
)


def test_apply_entry_recommendation_to_decision_does_not_insert_activate_action_by_default() -> None:
    payload = apply_entry_recommendation_to_decision(
        decision_payload={
            "next_actions": [
                {"action_key": "continue_collection", "status": "available"},
            ]
        },
        command="send_message",
        current_question=None,
        entry_mode="requirement_intake",
        entry_confidence=0.93,
        entry_reason="建议进入梳理模式。",
        entry_source="fuzzy_intent",
    )
    actions = payload.get("next_actions")
    assert isinstance(actions, list)
    assert actions[0]["action_key"] == "continue_collection"
    assert payload["entry_recommendation"]["action_key"] == "activate_requirement_intake"


def test_apply_entry_recommendation_to_decision_noop_for_non_send_message() -> None:
    payload = apply_entry_recommendation_to_decision(
        decision_payload={
            "next_actions": [
                {"action_key": "continue_collection", "status": "available"},
            ]
        },
        command="submit_intake_answer",
        current_question=None,
        entry_mode="requirement_intake",
        entry_confidence=0.93,
        entry_reason="建议进入梳理模式。",
        entry_source="fuzzy_intent",
    )
    actions = payload.get("next_actions")
    assert isinstance(actions, list)
    assert actions[0]["action_key"] == "continue_collection"
    assert payload.get("entry_recommendation") is None


def test_enforce_intake_gate_transition_adds_gap_advisory_without_rewriting_stage() -> None:
    payload = enforce_intake_gate_transition(
        decision_payload={
            "next_stage": "requirement_analysis.active",
            "stage_transition": {"from": "requirement_intake.ready_for_submit", "to": "requirement_analysis.active"},
            "next_actions": [
                {"action_key": "confirm_plan", "status": "available"},
                {"action_key": "continue_collection", "status": "available", "blocking_reason": "缺少预算"},
            ],
        },
        normalized_required_missing=["budget"],
        current_question={"field_key": "budget"},
    )
    assert payload["next_stage"] == "requirement_analysis.active"
    assert payload["stage_transition"]["to"] == "requirement_analysis.active"
    assert payload["gap_advisory"] == "仍有关键字段建议补充；可继续分析，但需保留待补充项与假设。"
    assert payload["chooser_required"] is False
    assert [item["action_key"] for item in payload["next_actions"]] == ["confirm_plan", "continue_collection"]


def test_enforce_intake_gate_transition_keeps_existing_actions_with_gap_advisory() -> None:
    payload = enforce_intake_gate_transition(
        decision_payload={
            "next_stage": "requirement_analysis.active",
            "next_actions": [
                {"action_key": "confirm_plan", "status": "available"},
            ],
        },
        normalized_required_missing=["quantity"],
        current_question={"field_key": "quantity"},
    )
    assert payload["next_stage"] == "requirement_analysis.active"
    assert payload["gap_advisory"] == "仍有关键字段建议补充；可继续分析，但需保留待补充项与假设。"
    assert payload["next_actions"][0]["action_key"] == "confirm_plan"
