from __future__ import annotations

import sys
from types import SimpleNamespace

import pytest

from flare_kernel.runtime.infrastructure import infrastructure


def test_ingest_knowledge_record_returns_error_fields_for_empty_content() -> None:
    result = infrastructure.ingest_knowledge_record(
        trace_id="trace-1",
        project_id="p1",
        user_id="u1",
        session_id="s1",
        content="   ",
        source_id="src-1",
        title=None,
        metadata=None,
    )

    assert result["status"] == "failed"
    assert result["record_id"] == ""
    assert result["chunk_count"] == 0
    assert result["source_id"] == "src-1"
    assert result["error_code"] == "EMPTY_CONTENT"
    assert result["error_message"] == "empty_content"


def test_ingest_knowledge_record_stable_source_and_error_fields_when_no_storage(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(infrastructure, "_build_sqlalchemy_engine", lambda: None)
    monkeypatch.setattr(infrastructure, "_qdrant_client", lambda: None)

    result = infrastructure.ingest_knowledge_record(
        trace_id="trace-1",
        project_id="p1",
        user_id="u1",
        session_id="s1",
        content="hello world",
        source_id=None,
        title=None,
        metadata=None,
    )

    assert result["status"] == "failed"
    assert result["source_id"] is None
    assert result["error_code"] == "KNOWLEDGE_INGEST_FAILED"
    assert result["error_message"] == "storage_unavailable"


def test_search_knowledge_records_qdrant_result_contains_source_id(monkeypatch: pytest.MonkeyPatch) -> None:
    captured = {}

    class _QdrantClientStub:
        def search(self, **_kwargs):
            captured.update(_kwargs)
            return [
                SimpleNamespace(
                    id="chunk-1",
                    score=0.9,
                    payload={
                        "record_id": "record-1",
                        "chunk_id": "chunk-1",
                        "chunk_index": 0,
                        "title": "t1",
                        "content": "query and content overlap",
                        "source_id": "src-qdrant",
                    },
                )
            ]

    models = SimpleNamespace(
        Filter=lambda **kwargs: kwargs,
        FieldCondition=lambda **kwargs: kwargs,
        MatchValue=lambda **kwargs: kwargs,
        MatchAny=lambda **kwargs: kwargs,
    )
    monkeypatch.setitem(sys.modules, "qdrant_client.http", SimpleNamespace(models=models))
    monkeypatch.setattr(infrastructure, "_qdrant_client", lambda: _QdrantClientStub())
    monkeypatch.setattr(infrastructure, "_build_sqlalchemy_engine", lambda: None)

    results = infrastructure.search_knowledge_records(
        trace_id="trace-1",
        project_id="p1",
        user_id="u1",
        query="query",
        top_k=3,
        source_ids=["src-qdrant"],
    )

    assert len(results) == 1
    assert results[0]["source"] == "qdrant"
    assert results[0]["source_id"] == "src-qdrant"
    query_filter = captured["query_filter"]
    assert any(condition.get("key") == "source_id" for condition in query_filter["must"])


def test_search_knowledge_records_postgres_fallback_contains_source_id(monkeypatch: pytest.MonkeyPatch) -> None:
    captured = {}

    class _ConnStub:
        def execute(self, _query, _params):
            captured["params"] = _params
            return [("r1", "title-1", "content-1", "src-pg")]

    class _ConnectCtx:
        def __enter__(self):
            return _ConnStub()

        def __exit__(self, exc_type, exc, tb):
            return False

    class _EngineStub:
        def connect(self):
            return _ConnectCtx()

    monkeypatch.setattr(infrastructure, "_qdrant_client", lambda: None)
    monkeypatch.setattr(infrastructure, "_build_sqlalchemy_engine", lambda: _EngineStub())
    monkeypatch.setitem(sys.modules, "sqlalchemy", SimpleNamespace(text=lambda value: value))

    results = infrastructure.search_knowledge_records(
        trace_id="trace-1",
        project_id="p1",
        user_id="u1",
        query="query",
        top_k=3,
        source_ids=["src-pg"],
    )

    assert len(results) == 1
    assert results[0]["source"] == "postgres"
    assert results[0]["source_id"] == "src-pg"
    assert captured["params"]["source_id_0"] == "src-pg"


def test_search_knowledge_records_includes_entity_hit_signals(monkeypatch: pytest.MonkeyPatch) -> None:
    class _QdrantClientStub:
        def search(self, **_kwargs):
            return [
                SimpleNamespace(
                    id="chunk-erp",
                    score=0.92,
                    payload={
                        "record_id": "record-erp",
                        "chunk_id": "chunk-erp",
                        "chunk_index": 0,
                        "title": "ERP 厂商评估",
                        "content": "SAP 与 Oracle 在大型企业场景较常见。",
                        "source_id": "src-erp",
                    },
                )
            ]

    models = SimpleNamespace(
        Filter=lambda **kwargs: kwargs,
        FieldCondition=lambda **kwargs: kwargs,
        MatchValue=lambda **kwargs: kwargs,
        MatchAny=lambda **kwargs: kwargs,
    )
    monkeypatch.setitem(sys.modules, "qdrant_client.http", SimpleNamespace(models=models))
    monkeypatch.setattr(infrastructure, "_qdrant_client", lambda: _QdrantClientStub())
    monkeypatch.setattr(infrastructure, "_build_sqlalchemy_engine", lambda: None)

    results = infrastructure.search_knowledge_records(
        trace_id="trace-entity",
        project_id="p1",
        user_id="u1",
        query="SAP",
        top_k=3,
        entities=[{"text": "SAP", "normalized": "sap", "aliases": ["Oracle"]}],
        entity_query_mode="prefer",
        query_lane="entity_exact",
    )

    assert len(results) == 1
    assert results[0]["entity_matched"] is True
    assert "sap" in results[0]["matched_entities"]
    assert results[0]["entity_match_score"] > 0
    assert results[0]["entity_query_mode"] == "prefer"
    assert results[0]["query_lane"] == "entity_exact"


def test_search_knowledge_records_postgres_source_fallback_when_query_misses(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured = {"calls": 0}

    class _ConnStub:
        def execute(self, _query, _params):
            captured["calls"] += 1
            if captured["calls"] == 1:
                return []
            captured["params"] = _params
            return [("r-fallback", "title-fallback", "content-fallback", "src-only")]

    class _ConnectCtx:
        def __enter__(self):
            return _ConnStub()

        def __exit__(self, exc_type, exc, tb):
            return False

    class _EngineStub:
        def connect(self):
            return _ConnectCtx()

    monkeypatch.setattr(infrastructure, "_qdrant_client", lambda: None)
    monkeypatch.setattr(infrastructure, "_build_sqlalchemy_engine", lambda: _EngineStub())
    monkeypatch.setitem(sys.modules, "sqlalchemy", SimpleNamespace(text=lambda value: value))

    results = infrastructure.search_knowledge_records(
        trace_id="trace-1",
        project_id="p1",
        user_id="u1",
        query="no lexical match",
        top_k=3,
        source_ids=["src-only"],
    )

    assert len(results) == 1
    assert results[0]["record_id"] == "r-fallback"
    assert results[0]["source_id"] == "src-only"
    assert results[0]["score"] >= 0.0
    assert captured["params"]["source_id_0"] == "src-only"


def test_search_knowledge_records_postgres_fallback_without_source_id_column(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class _ConnStub:
        def __init__(self) -> None:
            self.calls = 0

        def execute(self, _query, _params):
            self.calls += 1
            if self.calls == 1:
                raise RuntimeError("column source_id does not exist")
            return [("r1", "title-1", "content-1")]

    class _ConnectCtx:
        def __init__(self) -> None:
            self.conn = _ConnStub()

        def __enter__(self):
            return self.conn

        def __exit__(self, exc_type, exc, tb):
            return False

    class _EngineStub:
        def connect(self):
            return _ConnectCtx()

    monkeypatch.setattr(infrastructure, "_qdrant_client", lambda: None)
    monkeypatch.setattr(infrastructure, "_build_sqlalchemy_engine", lambda: _EngineStub())
    monkeypatch.setitem(sys.modules, "sqlalchemy", SimpleNamespace(text=lambda value: value))

    results = infrastructure.search_knowledge_records(
        trace_id="trace-1",
        project_id="p1",
        user_id="u1",
        query="query",
        top_k=3,
        source_ids=["src-only-filter"],
    )

    assert len(results) == 1
    assert results[0]["source"] == "postgres"
    assert results[0]["source_id"] == ""
