from __future__ import annotations

from flare_kernel.runtime.reasoning.intake.context import build_intake_domain_context


def test_domain_context_preserves_configured_question_options() -> None:
    domain_context = build_intake_domain_context(
        payload={},
        domain_pack={
            "fields": {
                "field_definitions": [
                    {
                        "key": "use_case",
                        "label": "使用场景",
                        "priority": "required",
                        "options": [
                            "日常办公",
                            {"key": "custom", "label": "其他用途", "value": ""},
                        ],
                    }
                ]
            }
        },
    )

    definition = domain_context["field_definitions"][0]
    assert definition["options"] == [
        "日常办公",
        {"key": "custom", "label": "其他用途", "value": ""},
    ]


def test_domain_context_does_not_create_generic_fallback_fields() -> None:
    domain_context = build_intake_domain_context(
        payload={},
        domain_pack={},
    )

    assert domain_context["field_definitions"] == []
    assert domain_context["required_fields"] == []
    assert domain_context["recommended_fields"] == []
    assert domain_context["optional_fields"] == []
