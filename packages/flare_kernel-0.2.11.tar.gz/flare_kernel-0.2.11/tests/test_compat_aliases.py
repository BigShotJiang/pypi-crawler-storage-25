from __future__ import annotations

from flare_kernel.router.intent.compat_aliases import (
    project_domain_relevance,
    resolve_domain_policy_flag,
    resolve_domain_relevance,
)


def test_resolve_domain_relevance_prefers_domain_key_then_legacy() -> None:
    assert resolve_domain_relevance({"domain_relevance": True, "procurement_relevance": False}) is True
    assert resolve_domain_relevance({"procurement_relevance": True}) is True
    assert resolve_domain_relevance({}, default=False) is False


def test_project_domain_relevance_keeps_compat_alias() -> None:
    projected = project_domain_relevance(True)
    assert projected["domain_relevance"] is True
    assert projected["procurement_relevance"] is True


def test_resolve_domain_policy_flag_accepts_legacy_input() -> None:
    assert resolve_domain_policy_flag(
        {"require_domain_relevance_for_auto_override": False},
        domain_key="require_domain_relevance_for_auto_override",
        legacy_key="require_procurement_relevance_for_auto_override",
        default=True,
    ) is False
    assert resolve_domain_policy_flag(
        {"require_procurement_relevance_for_auto_override": False},
        domain_key="require_domain_relevance_for_auto_override",
        legacy_key="require_procurement_relevance_for_auto_override",
        default=True,
    ) is False

