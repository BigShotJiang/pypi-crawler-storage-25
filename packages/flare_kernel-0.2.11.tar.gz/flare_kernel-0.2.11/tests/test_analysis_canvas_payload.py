from __future__ import annotations

from flare_kernel.router.payload import analysis_canvas as analysis_canvas_module
from flare_kernel.router.payload.analysis_canvas import build_canvas_analysis_payload


def test_build_canvas_analysis_payload_uses_template_registry_with_context_values() -> None:
    payload, slot_patches = build_canvas_analysis_payload(
        analysis_route={"analysis_type": "requirement", "template_id": "flare.requirement.rfx.v1"},
        content_text="忽略正文",
        orchestration_status={"required_missing": []},
        runtime_snapshot={"payload": {"fields": {"goal": "软件采购", "scope": "集团采购"}}},
    )
    assert isinstance(payload, dict)
    assert isinstance(slot_patches, list)
    assert [action["key"] for action in payload["toolbar_actions"]] == [
        "copy",
        "export_markdown",
        "edit",
        "fullscreen",
    ]
    assert payload["workspace_capabilities"]["toolbar_actions"] == payload["toolbar_actions"]
    document = payload.get("document") if isinstance(payload.get("document"), dict) else {}
    assert str(document.get("template_id") or "") == "flare.requirement.rfx.v1"
    sections = document.get("sections") if isinstance(document.get("sections"), list) else []
    assert len(sections) > 0
    first_items = sections[0].get("items") if isinstance(sections[0], dict) else []
    assert "软件采购" in first_items


def test_build_canvas_analysis_payload_renders_draft_fallback_for_missing_slots() -> None:
    payload, _ = build_canvas_analysis_payload(
        analysis_route={"analysis_type": "sourcing", "template_id": "flare.sourcing.default.v1"},
        content_text="忽略正文",
        orchestration_status={"required_missing": ["price_band"]},
        runtime_snapshot={"payload": {"fields": {"sourcing_scope": "ERP供应商"}}},
    )
    assert isinstance(payload, dict)
    markdown = str(payload.get("markdown") or "")
    assert "—" not in markdown
    assert "待补充：价格区间" not in markdown
    assert "待补充：供应商画像" not in markdown
    document = payload.get("document") if isinstance(payload.get("document"), dict) else {}
    sections = document.get("sections") if isinstance(document.get("sections"), list) else []
    info_items = [
        item
        for section in sections
        if isinstance(section, dict)
        for item in section.get("info", [])
    ]
    assert "价格区间：建议补充目标价、预算上限、报价单位和价格有效期。" in info_items
    assert "供应商画像：建议说明理想供应商类型、规模、能力和服务覆盖。" in info_items


def test_build_canvas_analysis_payload_merges_previous_slot_values_without_overwrite() -> None:
    first_payload, _ = build_canvas_analysis_payload(
        analysis_route={"analysis_type": "sourcing", "template_id": "flare.sourcing.default.v1"},
        content_text="first",
        orchestration_status={"required_missing": []},
        runtime_snapshot={"payload": {"fields": {"sourcing_scope": "ERP供应商"}}},
    )
    second_payload, _ = build_canvas_analysis_payload(
        analysis_route={"analysis_type": "sourcing", "template_id": "flare.sourcing.default.v1"},
        content_text="second",
        previous_payload=first_payload,
        orchestration_status={"required_missing": []},
        runtime_snapshot={"payload": {"fields": {"price_band": "50-100万"}}},
    )
    assert isinstance(second_payload, dict)
    markdown = str(second_payload.get("markdown") or "")
    assert "ERP供应商" in markdown
    assert "50-100万" in markdown
    assert "待补充：价格区间" not in markdown


def test_build_canvas_analysis_payload_flattens_dynamic_section_counts() -> None:
    payload, _ = build_canvas_analysis_payload(
        analysis_route={"analysis_type": "requirement", "template_id": "flare.requirement.rfx.v1"},
        content_text="忽略正文",
        orchestration_status={
            "required_missing": [["goal", "budget"]],
            "structured_retrieved_knowledge": [
                {"title": "资料A.pdf"},
                {"title": "资料B.pdf"},
            ],
        },
        runtime_snapshot={
            "payload": {
                "fields": {},
                "retrieved_knowledge": [
                    {"title": "资料A.pdf"},
                    {"title": "资料B.pdf"},
                    {"title": "资料C.pdf"},
                ],
            }
        },
    )
    assert isinstance(payload, dict)
    markdown = str(payload.get("markdown") or "")
    assert "证据摘要（3）" in markdown
    assert "待补充信息（2）" in markdown
    assert "资料C.pdf" in markdown


def test_build_canvas_analysis_payload_reuses_uploaded_template_sections() -> None:
    payload, _ = build_canvas_analysis_payload(
        analysis_route={"analysis_type": "requirement", "template_id": "flare.requirement.rfx.v1"},
        content_text="忽略正文",
        orchestration_status={"required_missing": ["预算"]},
        runtime_snapshot={
            "session_context": {
                "artifact_context": [
                    {
                        "source_id": "template-1",
                        "title": "分析报告模板",
                        "document_kind": "template",
                        "template": {
                            "is_template": True,
                            "template_sections": ["项目背景", "输出格式", "结论章节"],
                            "required_output_fields": ["核心问题", "事实依据"],
                        },
                    }
                ],
                "sourcing_results": [
                    {
                        "items": [
                            {
                                "supplier_name": "供应商A",
                                "confidence": 0.82,
                                "reason": "本地案例匹配",
                            }
                        ]
                    }
                ],
                "evidence": [{"title": "资料A", "snippet": "命中证据"}],
            },
            "payload": {"fields": {"goal": "空间搭建供应商分析"}},
        },
    )
    assert isinstance(payload, dict)
    document = payload.get("document") if isinstance(payload.get("document"), dict) else {}
    assert str(document.get("template_id") or "") == "user.template.template-1.v1"
    sections = document.get("sections") if isinstance(document.get("sections"), list) else []
    assert [section.get("title") for section in sections] == ["项目背景", "输出格式", "结论章节"]
    markdown = str(payload.get("markdown") or "")
    assert "空间搭建供应商分析" in markdown
    assert "供应商A" in markdown
    assert "建议补充：核心问题" in markdown
    assert "待补充：预算" in markdown


def test_build_canvas_analysis_payload_uses_latest_sourcing_candidates_and_criteria() -> None:
    payload, _ = build_canvas_analysis_payload(
        analysis_route={"analysis_type": "sourcing", "template_id": "flare.sourcing.default.v1"},
        content_text="忽略正文",
        orchestration_status={"required_missing": []},
        runtime_snapshot={
            "payload": {
                "fields": {"sourcing_scope": "北京展陈搭建服务"},
                "criteria": ["交付周期优先"],
                "sourcing_candidates": [
                    {
                        "supplier_name": "供应商A",
                        "capability": "北京本地交付",
                        "confidence": 0.91,
                        "reason": "案例和区域匹配",
                    }
                ],
            }
        },
    )
    assert isinstance(payload, dict)
    markdown = str(payload.get("markdown") or "")
    assert "北京展陈搭建服务" in markdown
    assert "供应商A：北京本地交付" in markdown
    assert "交付周期优先" in markdown


def test_build_canvas_analysis_payload_preserves_sourcing_trace_for_analysis(monkeypatch) -> None:
    captured: dict[str, object] = {}

    def _fake_build_analysis_canvas_payload(**kwargs):
        captured["context"] = kwargs["context"]
        return {"markdown": "", "document": {"sections": []}}, []

    monkeypatch.setattr(
        analysis_canvas_module,
        "build_analysis_canvas_payload",
        _fake_build_analysis_canvas_payload,
    )

    payload, _ = analysis_canvas_module.build_canvas_analysis_payload(
        analysis_route={"analysis_type": "sourcing", "template_id": "flare.sourcing.default.v1"},
        content_text="忽略正文",
        orchestration_status={"required_missing": []},
        runtime_snapshot={
            "session_context": {
                "sourcing_results": [
                    {
                        "retrieval_run_id": "run-analysis-1",
                        "query": "数据库服务器",
                        "selected_source": "instance_db",
                        "source_breakdown": {"instance_db": 1, "local": 0, "mcp": 0, "web": 0},
                        "source_priority": [{"source": "instance_db", "enabled": True}],
                        "provider_trace": [{"source": "instance_db", "status": "completed", "hit_count": 1}],
                        "items": [{"supplier_name": "供应商A"}],
                    }
                ]
            },
            "payload": {},
        },
    )

    assert isinstance(payload, dict)
    context = captured["context"]
    assert isinstance(context, dict)
    assert context["sourcing_trace"]["selected_source"] == "instance_db"
    assert context["sourcing_trace"]["provider_trace"][0]["source"] == "instance_db"
    assert context["sourcing_trace"]["source_meta"]["retrieval_batch"] == "run-analysis-1"


def test_build_canvas_analysis_payload_uses_latest_candidate_rows_only(monkeypatch) -> None:
    captured: dict[str, object] = {}

    def _fake_build_analysis_canvas_payload(**kwargs):
        captured["context"] = kwargs["context"]
        return {"markdown": "", "document": {"sections": []}}, []

    monkeypatch.setattr(
        analysis_canvas_module,
        "build_analysis_canvas_payload",
        _fake_build_analysis_canvas_payload,
    )

    payload, _ = analysis_canvas_module.build_canvas_analysis_payload(
        analysis_route={"analysis_type": "sourcing", "template_id": "flare.sourcing.default.v1"},
        content_text="忽略正文",
        orchestration_status={"required_missing": []},
        runtime_snapshot={
            "session_context": {
                "sourcing_results": [
                    {
                        "retrieval_run_id": "run-old",
                        "items": [{"supplier_id": "old", "supplier_name": "旧供应商"}],
                    },
                    {
                        "retrieval_run_id": "run-latest",
                        "items": [
                            {
                                "result_role": "reference",
                                "title": "采购需求文档.pdf",
                                "source_type": "local",
                            },
                            {
                                "supplier_id": "latest",
                                "supplier_name": "最新供应商",
                                "source_type": "instance_db",
                            },
                        ],
                    },
                ]
            },
            "payload": {},
        },
    )

    assert isinstance(payload, dict)
    context = captured["context"]
    assert isinstance(context, dict)
    assert context["sourcing_candidates"] == [
        {
            "supplier_id": "latest",
            "supplier_name": "最新供应商",
            "source_type": "instance_db",
        }
    ]


def test_build_canvas_analysis_payload_uses_generated_markdown_as_canvas_source() -> None:
    content_text = "# 服务器供应商分析报告\n\n## 初步判断\n优先确认 GPU 配置。\n\n## 风险提示\n- 预算口径待确认\n"
    payload, _ = build_canvas_analysis_payload(
        analysis_route={"analysis_type": "requirement", "template_id": "flare.requirement.rfx.v1"},
        content_text=content_text,
        orchestration_status={"required_missing": []},
        runtime_snapshot={"payload": {"fields": {"goal": "服务器供应商"}}},
    )
    assert isinstance(payload, dict)
    assert payload.get("markdown") == content_text.strip()
    document = payload.get("document") if isinstance(payload.get("document"), dict) else {}
    assert document.get("title") == "服务器供应商分析报告"
    sections = document.get("sections") if isinstance(document.get("sections"), list) else []
    assert [section.get("title") for section in sections] == ["初步判断", "风险提示"]
    assert sections[0].get("content") == "优先确认 GPU 配置。"
