from __future__ import annotations

from flare_kernel.router.intake.readiness import resolve_intake_readiness_metrics


def test_resolve_intake_readiness_metrics_clamps_invalid_inputs() -> None:
    metrics = resolve_intake_readiness_metrics(
        total_coverage_raw="x",
        required_coverage_raw=None,
        analysis_entry_threshold_raw="bad",
        analyzability_score_raw={},
        analysis_entry_eligible_raw=False,
        required_fields=[],
        required_missing=[],
    )
    assert metrics["total_coverage"] == 0.0
    assert metrics["required_coverage"] == 0.0
    assert metrics["analysis_entry_threshold"] == 0.8
    assert metrics["analyzability_score"] == 0.0
    assert metrics["analysis_entry_eligible"] is False


def test_resolve_intake_readiness_metrics_applies_required_field_floor() -> None:
    metrics = resolve_intake_readiness_metrics(
        total_coverage_raw=0.1,
        required_coverage_raw=0.2,
        analysis_entry_threshold_raw=0.8,
        analyzability_score_raw=0.4,
        analysis_entry_eligible_raw=False,
        required_fields=["category", "budget", "quantity"],
        required_missing=["quantity"],
    )
    assert metrics["required_coverage"] == 2 / 3
    assert metrics["total_coverage"] == 2 / 3
    assert metrics["analysis_entry_eligible"] is False


def test_resolve_intake_readiness_metrics_marks_entry_eligible_by_score_or_flag() -> None:
    by_score = resolve_intake_readiness_metrics(
        total_coverage_raw=0.3,
        required_coverage_raw=0.3,
        analysis_entry_threshold_raw=0.7,
        analyzability_score_raw=0.75,
        analysis_entry_eligible_raw=False,
        required_fields=["category"],
        required_missing=[],
    )
    by_flag = resolve_intake_readiness_metrics(
        total_coverage_raw=0.1,
        required_coverage_raw=0.1,
        analysis_entry_threshold_raw=0.9,
        analyzability_score_raw=0.1,
        analysis_entry_eligible_raw=True,
        required_fields=[],
        required_missing=[],
    )
    assert by_score["analysis_entry_eligible"] is True
    assert by_flag["analysis_entry_eligible"] is True


def test_resolve_intake_readiness_metrics_marks_entry_eligible_when_question_budget_reached() -> None:
    metrics = resolve_intake_readiness_metrics(
        total_coverage_raw=0.2,
        required_coverage_raw=0.2,
        analysis_entry_threshold_raw=0.8,
        analyzability_score_raw=0.1,
        analysis_entry_eligible_raw=False,
        required_fields=["goal", "scope", "constraints", "parameters"],
        required_missing=["parameters"],
        question_progress={"current": 3, "total": 4},
        intake_strategy={"question_budget_max": 3},
    )
    assert metrics["question_budget_reached"] is True
    assert metrics["analysis_entry_eligible"] is True
