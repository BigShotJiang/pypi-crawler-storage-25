from __future__ import annotations

from flare_kernel.router.intake.field_projection.entity import (
    build_unparsed_field_entity,
    canonicalize_field_entity,
    is_field_entity_confirmed,
)


def test_build_unparsed_field_entity_contains_source_payload() -> None:
    entity = build_unparsed_field_entity(
        raw_text="尽快",
        source_type="message_extraction",
        evidence_text="尽快",
    )
    assert entity["status"] == "unparsed"
    assert entity["source"] == {"type": "message_extraction", "evidence": "尽快"}


def test_canonicalize_field_entity_budget_becomes_confirmed() -> None:
    entity = canonicalize_field_entity(
        field_key="budget",
        raw_value="预算10万到20万",
        source_type="user_input",
        evidence_text="预算10万到20万",
        field_semantics={"value_type": "money"},
    )
    assert isinstance(entity, dict)
    assert is_field_entity_confirmed(entity) is True


def test_canonicalize_field_entity_uses_semantics_not_field_key() -> None:
    entity = canonicalize_field_entity(
        field_key="max_spend",
        raw_value="预算10万到20万",
        source_type="user_input",
        evidence_text="预算10万到20万",
        field_semantics={"value_type": "money"},
    )

    assert isinstance(entity, dict)
    assert entity["status"] == "confirmed"
    assert entity["normalized_value"]["kind"] == "range"
