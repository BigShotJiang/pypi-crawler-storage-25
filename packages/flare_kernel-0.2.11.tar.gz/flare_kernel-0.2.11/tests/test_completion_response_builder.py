from __future__ import annotations

from flare_kernel.router.completion.response_builder import (
    apply_completion_content_policy,
    build_action_result_payload,
    build_kernel_success_response,
    build_run_result_payload,
)


def test_apply_completion_content_policy_sets_content_and_analysis_state() -> None:
    status = {"intake_session_id": "intake-1"}
    apply_completion_content_policy(
        orchestration_status=status,
        command="generate_analysis",
        has_llm_content=True,
    )
    assert status["content_policy"]["has_llm_content"] is True
    assert status["intake_session_state"] == "analysis_completed"
    assert status["intake_session_completed"] is True


def test_apply_completion_content_policy_builds_analysis_payload_from_content() -> None:
    status = {
        "intake_session_id": "intake-1",
        "analysis_route": {"analysis_type": "requirement", "template_id": "req"},
    }
    apply_completion_content_policy(
        orchestration_status=status,
        command="generate_analysis",
        has_llm_content=True,
        content_text="# 需求分析\n\n## 摘要\n可交付草稿。",
        runtime_snapshot={"payload": {}},
    )
    assert status["content_policy"]["has_llm_content"] is True
    assert isinstance(status.get("canvas_analysis_payload"), dict)
    assert status["canvas_analysis_payload"]["document"]["analysis_type"] == "requirement"
    assert isinstance(status.get("analysis_slot_patches"), list)


def test_build_run_result_payload_merges_metrics_and_citations() -> None:
    runtime_snapshot = {
        "mode_key": "requirement_intake",
        "mode_state": "running",
        "mode_runtime": {},
        "track_result": {"track_id": "trk_1"},
        "context_usage": {},
        "agent_runtime": {},
        "skill_runtime": {},
        "data_ingestion": {},
        "memory_runtime": {"persisted_count": 1},
        "observation_runtime": {"metrics": {"base": 1}},
        "mode_events": [],
        "next_actions": [],
    }
    payload = build_run_result_payload(
        content_text="ok",
        completion_provider="p",
        completion_model="m",
        completion_status="ok",
        runtime_snapshot=runtime_snapshot,
        memory_record={"saved": True},
        retrieved_knowledge=[{"id": "k1"}],
        structured_retrieved_knowledge=[{"id": "k1"}],
        orchestration_status={"next_actions": [{"action_key": "a"}]},
        mode_switch_reason={"source": "intent"},
        build_knowledge_citations_fn=lambda items: [{"count": len(items)}],
    )
    assert payload["message"] == "ok"
    assert payload["track_result"] == {"track_id": "trk_1"}
    assert payload["observation_runtime"]["metrics"]["retrieval_hit_count"] == 1
    assert payload["knowledge_citation"] == [{"count": 1}]
    assert payload["next_actions"] == [{"action_key": "a"}]


def test_build_run_result_payload_keeps_requirement_summary_visible_with_confirm_send() -> None:
    runtime_snapshot = {
        "mode_key": "requirement_intake",
        "mode_state": "collecting",
        "mode_runtime": {},
        "track_result": {},
        "payload": {"prompt_summary_template_key": "business_requirement_summary"},
        "context_usage": {},
        "agent_runtime": {},
        "skill_runtime": {},
        "data_ingestion": {},
        "memory_runtime": {},
        "observation_runtime": {"metrics": {}},
        "next_actions": [],
        "mode_events": [
            {
                "event_type": "canvas_state",
                "payload": {
                    "mode_key": "requirement_intake",
                    "canvas_content": "需求梳理摘要\n\n摘要生成中。",
                    "canvas_state": {
                        "collected": [{"field_key": "goal", "value": "采购班车"}],
                        "missing": [],
                        "versions": [{"version": 1, "content": "需求梳理摘要\n\n摘要生成中。"}],
                    },
                },
            }
        ],
    }
    payload = build_run_result_payload(
        content_text="# 项目概述\n\n已整理为可提交提示词。",
        effective_command="send_message",
        completion_provider="p",
        completion_model="m",
        completion_status="ok",
        runtime_snapshot=runtime_snapshot,
        memory_record={},
        retrieved_knowledge=[],
        structured_retrieved_knowledge=[],
        orchestration_status={
            "current_question": {
                "field_key": "budget",
                "question_status": "active",
                "question_text": "预算范围是多少？",
            },
            "next_actions": [
                {
                    "action_key": "confirm_plan",
                    "payload": {"command": "generate_analysis"},
                }
            ]
        },
        mode_switch_reason={"source": "intent"},
        build_knowledge_citations_fn=lambda _items: [],
    )

    assert payload["message"].startswith("# 项目概述")
    assert payload["next_actions"][0]["action_key"] == "confirm_send_prompt"
    assert payload["next_actions"][0]["payload"]["prompt_text"].startswith("# 项目概述")
    assert payload["next_actions"][0]["payload"]["target_mode"] == "auto"
    assert payload["mode_events"][-1]["agent"] == "ModelCompletion"
    assert payload["mode_events"][-1]["payload"]["canvas_content"].startswith("# 项目概述")
    assert payload["mode_events"][-1]["payload"]["canvas_state"]["next_actions"][0]["action_key"] == "confirm_send_prompt"


def test_build_run_result_payload_appends_citation_lines_into_message() -> None:
    runtime_snapshot = {
        "mode_key": "intelligent_sourcing",
        "mode_state": "running",
        "mode_runtime": {},
        "context_usage": {},
        "agent_runtime": {},
        "skill_runtime": {},
        "data_ingestion": {},
        "memory_runtime": {},
        "observation_runtime": {"metrics": {}},
        "mode_events": [],
        "next_actions": [],
    }
    payload = build_run_result_payload(
        content_text="已完成初步寻源",
        completion_provider="p",
        completion_model="m",
        completion_status="ok",
        runtime_snapshot=runtime_snapshot,
        memory_record={},
        retrieved_knowledge=[{"id": "k1"}],
        structured_retrieved_knowledge=[{"id": "k1"}],
        orchestration_status={"next_actions": []},
        mode_switch_reason={"source": "intent"},
        build_knowledge_citations_fn=lambda _items: [
            {
                "citation_id": "cite_1",
                "title": "上海活动供应商目录",
                "snippet": "覆盖上海地区执行商与场地方。",
                "score": 0.81,
                "url": "https://example.test/a",
            }
        ],
    )
    assert "引用来源：" in payload["message"]
    assert "[cite_1] 上海活动供应商目录（相关度 0.81）" in payload["message"]
    assert "链接：https://example.test/a" in payload["message"]


def test_build_run_result_payload_appends_sourcing_preview_lines_in_collecting() -> None:
    runtime_snapshot = {
        "mode_key": "intelligent_sourcing",
        "mode_state": "collecting",
        "mode_runtime": {},
        "context_usage": {},
        "agent_runtime": {},
        "skill_runtime": {},
        "data_ingestion": {},
        "memory_runtime": {},
        "observation_runtime": {"metrics": {}},
        "mode_events": [],
        "next_actions": [],
    }
    payload = build_run_result_payload(
        content_text="先补充一些条件",
        completion_provider="p",
        completion_model="m",
        completion_status="ok",
        runtime_snapshot=runtime_snapshot,
        memory_record={},
        retrieved_knowledge=[],
        structured_retrieved_knowledge=[
            {"title": "露营地供应商筛选维度", "confidence": 0.91, "url": "https://a.test"},
            {"title": "活动场地采购评估清单", "confidence": 0.88, "url": "https://b.test"},
        ],
        orchestration_status={"next_actions": []},
        mode_switch_reason={"source": "intent"},
        build_knowledge_citations_fn=lambda items: [{"count": len(items)}],
    )
    assert "先给您两条预检索参考" in payload["message"]
    assert "露营地供应商筛选维度" in payload["message"]


def test_build_run_result_payload_attaches_analysis_context_patch() -> None:
    runtime_snapshot = {
        "mode_key": "requirement_intake",
        "mode_state": "running",
        "mode_runtime": {},
        "track_result": {},
        "context_usage": {},
        "agent_runtime": {},
        "skill_runtime": {},
        "data_ingestion": {},
        "memory_runtime": {},
        "observation_runtime": {"metrics": {}},
        "mode_events": [],
        "next_actions": [],
    }
    analysis_payload = {
        "analysis_type": "requirement",
        "document": {"analysis_schema_version": "v1"},
        "content": {"markdown": "分析稿"},
    }
    payload = build_run_result_payload(
        content_text="分析稿",
        completion_provider="p",
        completion_model="m",
        completion_status="ok",
        runtime_snapshot=runtime_snapshot,
        memory_record={},
        retrieved_knowledge=[],
        structured_retrieved_knowledge=[],
        orchestration_status={
            "next_actions": [],
            "canvas_analysis_payload": analysis_payload,
        },
        mode_switch_reason={"source": "intent"},
        build_knowledge_citations_fn=lambda items: [{"count": len(items)}],
    )
    assert payload["analysis_payload"] == analysis_payload
    assert payload["canvas_analysis_payload"] == analysis_payload
    assert payload["context_patch"]["analysis_results"][0]["payload"] == analysis_payload


def test_build_run_result_payload_keeps_context_answer_metadata_without_auto_append() -> None:
    runtime_snapshot = {
        "mode_key": "requirement_intake",
        "mode_state": "running",
        "mode_runtime": {},
        "session_context": {
            "artifact_context": [
                {
                    "source_id": "src_template",
                    "title": "分析报告模板",
                    "document_kind": "template",
                    "summary": "用于输出分析报告",
                    "template": {
                        "template_sections": ["项目背景", "结论"],
                        "required_output_fields": ["核心问题"],
                    },
                }
            ]
        },
        "context_usage": {},
        "agent_runtime": {},
        "skill_runtime": {},
        "data_ingestion": {},
        "memory_runtime": {},
        "observation_runtime": {"metrics": {}},
        "mode_events": [],
        "next_actions": [],
    }
    payload = build_run_result_payload(
        content_text="可以，我会按模板输出。",
        completion_provider="p",
        completion_model="m",
        completion_status="ok",
        runtime_snapshot=runtime_snapshot,
        memory_record={},
        retrieved_knowledge=[],
        structured_retrieved_knowledge=[],
        orchestration_status={"next_actions": []},
        mode_switch_reason={"source": "intent"},
        build_knowledge_citations_fn=lambda _items: [],
    )
    assert "上下文理解：" not in payload["message"]
    assert "模板章节：项目背景、结论" not in payload["message"]
    assert payload["message"] == "可以，我会按模板输出。"
    assert payload["context_answer"]["artifact_count"] == 1


def test_build_action_result_payload_projects_selected_action() -> None:
    runtime_snapshot = {
        "mode_key": "requirement_intake",
        "mode_state": "running",
        "mode_runtime": {},
        "context_usage": {},
        "agent_runtime": {},
        "skill_runtime": {},
        "data_ingestion": {},
        "memory_runtime": {},
        "observation_runtime": {"metrics": {}},
        "mode_events": [],
        "next_actions": [],
    }
    payload = build_action_result_payload(
        content_text="done",
        completion_provider="p",
        completion_model="m",
        completion_status="ok",
        runtime_snapshot=runtime_snapshot,
        memory_record={},
        orchestration_status={"next_actions": []},
        action_key="confirm_plan",
        action_target_mode="requirement_intake",
        action_status="available",
        action_reason="r",
    )
    assert payload["selected_action"]["action_key"] == "confirm_plan"
    assert payload["observation_runtime"]["metrics"]["plan_confirm_count"] == 1


def test_build_action_result_payload_does_not_rewrite_requirement_summary_canvas() -> None:
    runtime_snapshot = {
        "mode_key": "requirement_intake",
        "mode_state": "running",
        "mode_runtime": {},
        "payload": {"prompt_summary_template_key": "business_requirement_summary"},
        "context_usage": {},
        "agent_runtime": {},
        "skill_runtime": {},
        "data_ingestion": {},
        "memory_runtime": {},
        "observation_runtime": {"metrics": {}},
        "next_actions": [],
        "mode_events": [
            {
                "event_type": "canvas_state",
                "payload": {
                    "mode_key": "requirement_intake",
                    "canvas_state": {
                        "collected": [{"field_key": "goal", "value": "采购班车"}],
                        "missing": [],
                        "versions": [{"version": 1, "content": "需求梳理摘要"}],
                    },
                },
            }
        ],
    }
    payload = build_action_result_payload(
        content_text="这是确认提交后的最终反馈。",
        action_command="implement",
        completion_provider="p",
        completion_model="m",
        completion_status="ok",
        runtime_snapshot=runtime_snapshot,
        memory_record={},
        orchestration_status={"next_actions": []},
        action_key="implement",
        action_target_mode="requirement_intake",
        action_status="available",
        action_reason="r",
    )

    assert payload["message"] == "这是确认提交后的最终反馈。"
    assert payload["mode_events"] == runtime_snapshot["mode_events"]


def test_build_kernel_success_response_uses_orchestration_next_actions() -> None:
    response = build_kernel_success_response(
        trace_id="t1",
        result={"message": "x"},
        runtime_snapshot={"next_actions": [{"action_key": "from_runtime"}]},
        orchestration_status={"next_actions": [{"action_key": "from_status"}]},
    )
    assert response.trace_id == "t1"
    assert response.next_actions == [{"action_key": "from_status"}]


def test_build_kernel_success_response_dedupes_next_actions_by_action_key() -> None:
    response = build_kernel_success_response(
        trace_id="t1",
        result={"message": "x"},
        runtime_snapshot={"next_actions": []},
        orchestration_status={
            "next_actions": [
                {"action_key": "confirm_plan", "status": "available"},
                {"action_key": "confirm_plan", "status": "available", "label": "重复"},
                {"action_key": "continue_collection", "status": "available"},
            ]
        },
    )
    assert [item["action_key"] for item in response.next_actions] == ["confirm_plan", "continue_collection"]
