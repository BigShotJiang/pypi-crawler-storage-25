from __future__ import annotations

from flare_kernel.runtime.orchestration.decision_engine import DecisionContext, evaluate_orchestration_decision


def test_decision_engine_keeps_collecting_when_required_fields_missing() -> None:
    decision = evaluate_orchestration_decision(
        DecisionContext(
            resolved_intent="requirement_intake",
            resolved_mode="requirement_intake",
            mode_state="collecting",
            required_missing=("budget",),
            base_next_actions=(
                {"action_key": "continue_collection", "status": "available", "priority": 1},
            ),
            current_question={"field_key": "budget", "question_text": "预算是多少？"},
            retrieval_attempted=False,
            retrieval_hit_count=0,
            chooser={"blocking_reason": "缺少预算"},
            target_field="budget",
            pack_workflow={},
            pack_field_policies={"budget": {"blocker": True}},
            pack_blocker_policies={"required_fields": ["budget"], "chooser_on_blocking": True},
            pack_search_mapping={},
            degrade_reasons=(),
        )
    )

    assert decision.next_stage == "requirement_intake.collecting"
    assert decision.chooser_required is True
    assert decision.stage_transition.to_stage == "requirement_intake.collecting"


def test_decision_engine_moves_to_evidence_retrieval_when_action_requests_it() -> None:
    decision = evaluate_orchestration_decision(
        DecisionContext(
            resolved_intent="requirement_intake",
            resolved_mode="requirement_intake",
            mode_state="collecting",
            required_missing=(),
            base_next_actions=(
                {"action_key": "investigate_evidence", "status": "available", "priority": 1},
            ),
            current_question=None,
            retrieval_attempted=True,
            retrieval_hit_count=3,
            chooser=None,
            target_field="cpu",
            pack_workflow={},
            pack_field_policies={"cpu": {"blocker": False}},
            pack_blocker_policies={"required_fields": ["budget"], "chooser_on_blocking": True},
            pack_search_mapping={"field_mapping": {"cpu": ["server cpu benchmark"]}},
            degrade_reasons=(),
        )
    )

    assert decision.next_stage == "evidence_retrieval.running"
    assert decision.stage_transition.to_stage == "evidence_retrieval.running"
    assert any(item.rule_id == "rule_next_action_evidence" for item in decision.decision_basis)


def test_decision_engine_moves_to_sourcing_when_mode_is_sourcing() -> None:
    decision = evaluate_orchestration_decision(
        DecisionContext(
            resolved_intent="intelligent_sourcing",
            resolved_mode="intelligent_sourcing",
            mode_state="collecting",
            required_missing=(),
            base_next_actions=(
                {"action_key": "handoff_to_sourcing", "status": "available", "priority": 1},
            ),
            current_question=None,
            retrieval_attempted=False,
            retrieval_hit_count=0,
            chooser=None,
            target_field="",
            pack_workflow={},
            pack_field_policies={},
            pack_blocker_policies={},
            pack_search_mapping={},
            degrade_reasons=(),
        )
    )

    assert decision.next_stage == "sourcing.running"
    assert decision.stage_transition.to_stage == "sourcing.running"


def test_decision_engine_does_not_synthesize_ready_for_submit_actions_by_default() -> None:
    decision = evaluate_orchestration_decision(
        DecisionContext(
            resolved_intent="requirement_intake",
            resolved_mode="requirement_intake",
            mode_state="drafting",
            required_missing=(),
            base_next_actions=(
                {"action_key": "continue_collection", "status": "available", "priority": 2},
            ),
            current_question=None,
            retrieval_attempted=False,
            retrieval_hit_count=0,
            chooser=None,
            target_field="",
            pack_workflow={},
            pack_field_policies={"budget": {"blocker": True}},
            pack_blocker_policies={"required_fields": ["budget"], "chooser_on_blocking": True},
            pack_search_mapping={},
            degrade_reasons=(),
        )
    )

    assert decision.next_stage == "requirement_intake.ready_for_submit"
    action_keys = [item.get("action_key") for item in decision.next_actions]
    assert action_keys == ["continue_collection"]


def test_decision_engine_degrades_when_retrieval_mapping_missing() -> None:
    decision = evaluate_orchestration_decision(
        DecisionContext(
            resolved_intent="requirement_intake",
            resolved_mode="requirement_intake",
            mode_state="collecting",
            required_missing=(),
            base_next_actions=(
                {"action_key": "investigate_evidence", "status": "available", "priority": 1},
            ),
            current_question=None,
            retrieval_attempted=False,
            retrieval_hit_count=0,
            chooser=None,
            target_field="cpu_arch",
            pack_workflow={},
            pack_field_policies={"cpu_arch": {"blocker": False}},
            pack_blocker_policies={"required_fields": ["budget"], "chooser_on_blocking": True},
            pack_search_mapping={"field_mapping": {"budget": ["server price"]}},
            degrade_reasons=(),
        )
    )

    assert decision.next_stage == "requirement_analysis.ready"
    assert any(item.startswith("retrieval_mapping_missing:cpu_arch") for item in decision.degrade_reason)


def test_decision_engine_uses_pack_workflow_actions() -> None:
    decision = evaluate_orchestration_decision(
        DecisionContext(
            resolved_intent="requirement_intake",
            resolved_mode="requirement_intake",
            mode_state="collecting",
            required_missing=("budget",),
            base_next_actions=(
                {"action_key": "continue_collection", "status": "available", "priority": 9},
            ),
            current_question={"field_key": "budget", "question_text": "预算是多少？"},
            retrieval_attempted=False,
            retrieval_hit_count=0,
            chooser={"blocking_reason": "缺少预算"},
            target_field="budget",
            pack_workflow={
                "stages": {
                    "requirement_intake": {
                        "next_actions": [
                            {"action_key": "pack_continue", "label": "按pack继续", "priority": 1},
                        ]
                    }
                }
            },
            pack_field_policies={"budget": {"blocker": True}},
            pack_blocker_policies={"required_fields": ["budget"], "chooser_on_blocking": True},
            pack_search_mapping={},
            degrade_reasons=(),
        )
    )

    assert decision.next_actions[0]["action_key"] == "pack_continue"


def test_decision_engine_workflow_missing_keeps_collecting_when_required_fields_missing() -> None:
    decision = evaluate_orchestration_decision(
        DecisionContext(
            resolved_intent="requirement_intake",
            resolved_mode="requirement_intake",
            mode_state="collecting",
            required_missing=("goal",),
            base_next_actions=(
                {"action_key": "continue_collection", "status": "available", "priority": 1},
            ),
            current_question={"field_key": "goal", "question_text": "请先确认目标"},
            retrieval_attempted=False,
            retrieval_hit_count=0,
            chooser={"blocking_reason": "缺少目标"},
            target_field="goal",
            pack_workflow={},
            pack_field_policies={},
            pack_blocker_policies={},
            pack_search_mapping={},
            degrade_reasons=("workflow_missing",),
        )
    )

    assert decision.next_stage == "requirement_intake.collecting"
    assert decision.stage_transition.to_stage == "requirement_intake.collecting"
    assert decision.chooser_required is True
