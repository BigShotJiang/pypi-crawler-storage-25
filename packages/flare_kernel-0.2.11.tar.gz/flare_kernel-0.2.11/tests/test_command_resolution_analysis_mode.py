from __future__ import annotations

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.kernel_request_pipeline.action import _resolve_command as resolve_action_command


def test_run_command_promotes_send_message_to_generate_analysis_for_analysis_mode() -> None:
    req = KernelRequest(command="send_message", mode="analysis_mode", payload={})
    assert resolve_action_command(req) == "generate_analysis"


def test_action_command_promotes_send_message_to_generate_analysis_for_analysis_mode() -> None:
    req = KernelRequest(command="send_message", payload={"mode": "analysis_mode"})
    assert resolve_action_command(req) == "generate_analysis"


def test_action_command_uses_payload_generate_analysis_command() -> None:
    req = KernelRequest(command="send_message", payload={"command": "generate_analysis"})
    assert resolve_action_command(req) == "generate_analysis"


def test_action_command_promotes_generic_analysis_action_key() -> None:
    req = KernelRequest(action_key="generate_analysis", payload={})
    assert resolve_action_command(req) == "generate_analysis"


def test_action_command_uses_target_mode_analysis() -> None:
    req = KernelRequest(command="send_message", target_mode="analysis_mode", payload={})
    assert resolve_action_command(req) == "generate_analysis"


def test_command_resolution_keeps_explicit_non_default_command() -> None:
    req = KernelRequest(command="apply_field_candidate", mode="analysis_mode", payload={})
    assert resolve_action_command(req) == "apply_field_candidate"


def test_command_resolution_keeps_send_message_when_not_analysis_mode() -> None:
    req = KernelRequest(command="send_message", mode="requirement_intake", payload={})
    assert resolve_action_command(req) == "send_message"
