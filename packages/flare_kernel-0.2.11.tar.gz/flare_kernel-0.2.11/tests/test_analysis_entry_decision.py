from __future__ import annotations

from flare_kernel.router.orchestration.status.analysis_entry_decision import (
    build_analysis_entry_decision,
)


def test_analysis_entry_decision_hides_without_context() -> None:
    decision = build_analysis_entry_decision(
        fields={},
        normalized_required_missing=["budget"],
        retrieval_hit_count=0,
        analysis_entry_eligible=False,
        analyzability_score=0.0,
        analysis_entry_threshold=0.8,
    )

    assert decision["entry_level"] == "hidden"
    assert decision["can_generate"] is False


def test_analysis_entry_decision_allows_draft_with_partial_context() -> None:
    decision = build_analysis_entry_decision(
        fields={"category": "server"},
        normalized_required_missing=["quantity"],
        retrieval_hit_count=0,
        analysis_entry_eligible=False,
        analyzability_score=0.0,
        analysis_entry_threshold=0.8,
    )

    assert decision["entry_level"] == "available"
    assert decision["can_generate"] is True
    assert decision["blocking_fields"] == ["quantity"]
    assert decision["assumptions"]


def test_analysis_entry_decision_recommends_when_threshold_eligible() -> None:
    decision = build_analysis_entry_decision(
        fields={"category": "server", "budget": "80w"},
        normalized_required_missing=[],
        retrieval_hit_count=2,
        analysis_entry_eligible=True,
        analyzability_score=0.9,
        analysis_entry_threshold=0.8,
    )

    assert decision["entry_level"] == "recommended"
    assert decision["can_generate"] is True
    assert decision["score"] >= decision["threshold"]
