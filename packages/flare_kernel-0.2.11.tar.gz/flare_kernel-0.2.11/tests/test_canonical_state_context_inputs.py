from __future__ import annotations

from flare_kernel.router.canonical.context.inputs import (
    resolve_canonical_state_context_inputs,
)


def test_resolve_canonical_state_context_inputs_normalizes_core_inputs() -> None:
    context_inputs = resolve_canonical_state_context_inputs(
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        orchestration_status={
            "required_missing": ["budget", ""],
            "current_question": {"field_key": "budget"},
            "confirmed_updates": [{"field_key": "budget", "field_value": "100万"}],
            "analysis_ready": True,
            "intake_candidate": True,
        },
        map_external_mode_fn=lambda mode: mode,
        is_field_entity_confirmed_fn=lambda entity: bool(entity.get("confirmed") is True),
    )

    assert context_inputs["external_mode"] == "requirement_intake"
    assert context_inputs["required_missing"] == ["budget"]
    assert context_inputs["fields"] == {"budget": "100万"}
    assert context_inputs["analysis_ready"] is True
    assert context_inputs["intake_candidate"] is True
