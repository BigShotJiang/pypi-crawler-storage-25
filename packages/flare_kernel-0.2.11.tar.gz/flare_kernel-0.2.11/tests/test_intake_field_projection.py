from __future__ import annotations

from flare_kernel.router.intake.field_projection.core import (
    build_field_source_payload,
    build_unparsed_field_entity,
    canonicalize_field_entity,
    canonicalize_payload_fields,
    extract_workspace_patch_value,
    is_field_entity_confirmed,
    resolve_field_evidence,
)


def test_extract_workspace_patch_value_uses_latest_matching_patch() -> None:
    payload = {
        "workspace_patches": [
            {"field_key": "budget", "field_value": "50万"},
            {"field_key": "budget", "field_value": "100万"},
        ]
    }

    assert extract_workspace_patch_value(payload, "budget") == "100万"


def test_resolve_field_evidence_prefers_question_answer_for_matching_field() -> None:
    payload = {
        "question_answer": {"field_key": "quantity", "raw_value": "20台"},
        "message": "ignored",
    }

    assert resolve_field_evidence(payload, "quantity", "question_answer") == "20台"


def test_build_unparsed_field_entity_marks_source_payload() -> None:
    entity = build_unparsed_field_entity(
        raw_text="尽快",
        source_type="message_extraction",
        evidence_text="尽快",
    )

    assert entity["status"] == "unparsed"
    assert entity["source"] == {"type": "message_extraction", "evidence": "尽快"}


def test_canonicalize_field_entity_and_payload_fields_keep_structured_fields() -> None:
    entity = canonicalize_field_entity(
        field_key="budget",
        raw_value="预算10万到20万",
        source_type="user_input",
        evidence_text="预算10万到20万",
        field_semantics={"value_type": "money"},
    )
    assert isinstance(entity, dict)
    assert is_field_entity_confirmed(entity) is True

    payload = {
        "fields": {"delivery_time": "尽快"},
        "field_sources": {"delivery_time": "user_input"},
        "required_fields": ["delivery_time"],
        "field_semantics": {"delivery_time": {"value_type": "time_window"}},
    }
    canonicalized = canonicalize_payload_fields(payload)
    assert canonicalized.get("fields") == {}
    field_candidates = canonicalized.get("field_candidates") if isinstance(canonicalized.get("field_candidates"), dict) else {}
    entity = field_candidates.get("delivery_time") if isinstance(field_candidates, dict) else None
    assert isinstance(entity, dict)
    assert entity.get("status") == "unparsed"


def test_build_field_source_payload_omits_empty_evidence() -> None:
    assert build_field_source_payload(source_type="user_input", evidence_text="") == {"type": "user_input"}
