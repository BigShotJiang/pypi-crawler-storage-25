from __future__ import annotations

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.intake.clarification import (
    build_requirement_clarification_message,
    build_requirement_collection_status,
    extract_current_question_from_runtime,
    extract_intake_understanding_from_runtime,
    should_force_requirement_clarification,
)


def test_extract_current_question_and_understanding_from_runtime() -> None:
    snapshot = {
        "mode_events": [
            {"event_type": "field_progress", "payload": {"intake_understanding": {"goal": "上线"}}},
            {"event_type": "next_actions", "payload": {"current_question": {"question_text": "预算是多少？"}}},
        ]
    }
    question = extract_current_question_from_runtime(snapshot)
    understanding = extract_intake_understanding_from_runtime(snapshot)
    assert isinstance(question, dict)
    assert question.get("question_text") == "预算是多少？"
    assert isinstance(understanding, dict)
    assert understanding.get("goal") == "上线"


def test_build_requirement_collection_status_uses_question_when_available() -> None:
    snapshot = {
        "mode_events": [
            {
                "event_type": "next_actions",
                "payload": {
                    "current_question": {"question_text": "预算是多少？", "step_index": 1, "step_total": 3},
                    "flow_state": "collecting",
                },
            }
        ]
    }
    status = build_requirement_collection_status(snapshot)
    assert "预算是多少？" in status


def test_build_requirement_collection_status_names_intake_scope_without_question() -> None:
    status = build_requirement_collection_status({"mode_events": []})
    assert "采购对象/品类" in status
    assert "供应商要求" in status


def test_should_force_requirement_clarification_skips_alias_terms() -> None:
    req = KernelRequest()
    assert (
        should_force_requirement_clarification(
            req,
            message='请解释"采购"',
            normalize_message_for_intent_fn=lambda _r, msg, _p: msg.lower(),
            extract_quoted_terms_fn=lambda _msg: ["采购"],
            resolve_intent_aliases_fn=lambda _r, _p: {"采购": "requirement_intake"},
            retrieved_knowledge=[],
            instance_profile={},
        )
        is False
    )
    assert (
        should_force_requirement_clarification(
            req,
            message='请解释"AlphaProject"',
            normalize_message_for_intent_fn=lambda _r, msg, _p: msg.lower(),
            extract_quoted_terms_fn=lambda _msg: ["AlphaProject"],
            resolve_intent_aliases_fn=lambda _r, _p: {"采购": "requirement_intake"},
            retrieved_knowledge=[],
            instance_profile={},
        )
        is True
    )


def test_build_requirement_clarification_message_uses_first_quoted_term() -> None:
    message = build_requirement_clarification_message(
        '请解释"AlphaProject"',
        extract_quoted_terms_fn=lambda _msg: ["AlphaProject"],
    )
    assert "AlphaProject" in message


def test_should_force_requirement_clarification_skips_quoted_prompt_templates() -> None:
    req = KernelRequest()
    assert (
        should_force_requirement_clarification(
            req,
            message='请执行"帮我梳理采购需求"',
            normalize_message_for_intent_fn=lambda _r, msg, _p: msg.lower(),
            extract_quoted_terms_fn=lambda _msg: ["帮我梳理采购需求"],
            resolve_intent_aliases_fn=lambda _r, _p: {},
            retrieved_knowledge=[],
            instance_profile={},
        )
        is False
    )
