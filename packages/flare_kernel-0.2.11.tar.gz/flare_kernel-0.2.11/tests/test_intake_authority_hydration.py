from __future__ import annotations

from types import SimpleNamespace

from flare_kernel.router.intake.authority.hydration import (
    hydrate_payload_from_authoritative_checkpoint,
    hydrate_payload_from_authoritative_intake_session,
)


def test_hydrate_payload_from_authoritative_intake_session_fills_missing_fields() -> None:
    merged = hydrate_payload_from_authoritative_intake_session(
        payload={
            "message": "继续",
            "required_missing": ["budget"],
            "fields": {"category": "服务器"},
        },
        persisted_payload={
            "fields": {"category": "服务器", "use_case": "测试开发"},
            "field_sources": {"category": {"type": "user_extracted"}},
            "recommended_missing": ["delivery_time"],
            "question_progress": {"current": 2, "total": 5},
        },
        persisted_status={
            "intake_session_id": "intake_1",
            "intake_session_state": "workspace_live_updating",
            "intake_session_completed": False,
        },
    )

    assert merged["fields"] == {"category": "服务器", "use_case": "测试开发"}
    assert merged["field_sources"] == {"category": {"type": "user_extracted"}}
    assert merged["recommended_missing"] == ["delivery_time"]
    assert merged["question_progress"] == {"current": 2, "total": 5}
    assert merged["intake_session_id"] == "intake_1"
    assert merged["intake_session_state"] == "workspace_live_updating"
    assert merged["intake_session_completed"] is False


def test_hydrate_payload_from_authoritative_intake_session_merges_persisted_and_incoming_fields() -> None:
    merged = hydrate_payload_from_authoritative_intake_session(
        payload={
            "message": "补充约束",
            "fields": {"constraints": "预算上限80万"},
            "field_sources": {"constraints": {"type": "question_answer"}},
        },
        persisted_payload={
            "fields": {"scope": "总部一期"},
            "field_sources": {"scope": {"type": "question_answer"}},
        },
        persisted_status={
            "intake_session_id": "intake_2",
            "intake_session_state": "workspace_live_updating",
            "intake_session_completed": False,
        },
    )

    assert merged["fields"] == {
        "scope": "总部一期",
        "constraints": "预算上限80万",
    }
    assert merged["field_sources"] == {
        "scope": {"type": "question_answer"},
        "constraints": {"type": "question_answer"},
    }


def test_hydrate_payload_from_authoritative_intake_session_ignores_removed_plan_context_keys() -> None:
    merged = hydrate_payload_from_authoritative_intake_session(
        payload={
            "message": "继续计划",
        },
        persisted_payload={
            "plan_context_state": {"goal": "上线", "workflow_status": "in_progress"},
            "followup_question": {"question_text": "预算上限是多少？"},
            "plan_summary_handoff": {"ready": False},
            "removed_summary_contract": {"summary": "先拆阶段"},
        },
        persisted_status={
            "intake_session_id": "intake_plan_1",
            "intake_session_state": "workspace_live_updating",
            "intake_session_completed": False,
        },
    )

    assert merged["followup_question"] == {"question_text": "预算上限是多少？"}
    assert "removed_session_state" not in merged
    assert "removed_apply_handoff" not in merged
    assert "removed_summary_contract" not in merged


def test_hydrate_payload_from_authoritative_checkpoint_applies_question_progress() -> None:
    merged = hydrate_payload_from_authoritative_checkpoint(
        payload={"message": "继续", "intake_session_id": "intake_3"},
        checkpoint_snapshot=SimpleNamespace(
            checkpoint_id="ckpt_2",
            intake_session_id="intake_3",
            checkpoint_type="question_waiting",
            checkpoint_state="waiting_user",
            current_stage="requirement_intake.collecting",
            question_key="budget",
            ready_for_submit=False,
            decision_point_active=False,
            updated_at="2026-04-10T00:00:00+00:00",
            payload={
                "current_question": {"field_key": "budget", "step_index": 3, "step_total": 5},
                "next_action": {"action_key": "continue_collection"},
                "next_actions": [{"action_key": "continue_collection"}],
                "required_missing": ["budget"],
            },
        ),
    )

    assert merged["intake_checkpoint"]["checkpoint_id"] == "ckpt_2"
    assert merged["current_question"]["field_key"] == "budget"
    assert merged["next_action"]["action_key"] == "continue_collection"
    assert merged["required_missing"] == ["budget"]
    assert merged["question_progress"] == {
        "current": 3,
        "total": 5,
        "intake_session_id": "intake_3",
        "resumed": True,
    }


def test_hydrate_payload_from_authoritative_checkpoint_drops_legacy_question_text() -> None:
    merged = hydrate_payload_from_authoritative_checkpoint(
        payload={"message": "继续", "intake_session_id": "intake_4"},
        checkpoint_snapshot=SimpleNamespace(
            checkpoint_id="ckpt_legacy",
            intake_session_id="intake_4",
            checkpoint_type="question_waiting",
            checkpoint_state="waiting_user",
            current_stage="requirement_intake.collecting",
            question_key="project_name",
            ready_for_submit=False,
            decision_point_active=False,
            updated_at="2026-04-10T00:00:00+00:00",
            payload={
                "current_question": {
                    "field_key": "project_name",
                    "question_text": "请补充字段：项目名称",
                    "step_index": 1,
                    "step_total": 1,
                },
                "required_missing": ["project_name"],
            },
        ),
    )

    assert "current_question" not in merged
    assert "question_progress" not in merged
