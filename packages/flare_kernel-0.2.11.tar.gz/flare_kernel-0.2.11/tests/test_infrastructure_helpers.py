from __future__ import annotations

import sys
from pathlib import Path

_TESTS_DIR = Path(__file__).resolve().parent
_KERNEL_SRC = _TESTS_DIR.parents[1] / "src"
if str(_KERNEL_SRC) not in sys.path:
    sys.path.insert(0, str(_KERNEL_SRC))

from flare_kernel.runtime.infrastructure.infrastructure import _keyword_overlap_ratio, _split_text_chunks


def test_split_text_chunks_returns_multiple_chunks_when_text_is_long() -> None:
    text = "A" * 1200
    chunks = _split_text_chunks(text, chunk_size=500)
    assert len(chunks) == 3
    assert len(chunks[0]) == 500


def test_keyword_overlap_ratio_returns_positive_value_for_overlap() -> None:
    ratio = _keyword_overlap_ratio("procurement supplier screening", "supplier screening with procurement context")
    assert ratio > 0
