from __future__ import annotations

from flare_kernel.router.intake.entry_policy import (
    DEFAULT_INTAKE_STRATEGY,
    has_active_intake_payload,
    is_intake_exit_message,
    is_requirement_mode_explicit,
    resolve_intake_strategy_settings,
    resolve_requirement_intake_entry_recommendation,
    should_continue_active_intake,
)


def test_resolve_requirement_intake_entry_recommendation_detects_explicit_request() -> None:
    mode, confidence, _reason, source = resolve_requirement_intake_entry_recommendation(
        message="请先帮我梳理预算和数量",
        current_question=None,
        required_missing=["budget"],
        normalize_message_text_fn=lambda value: str(value or "").strip().lower(),
        looks_like_small_talk_fn=lambda text: "你好" in text,
        contains_any_text_fn=lambda text, terms: any(term in text for term in terms),
        requirement_entry_explicit_phrases=("请先帮我梳理",),
        requirement_entry_context_terms=("预算", "数量"),
        requirement_entry_structuring_terms=("梳理",),
        question_terms=("?", "？"),
    )
    assert mode == "requirement_intake"
    assert confidence == 0.9
    assert source == "explicit_request"


def test_resolve_requirement_intake_entry_recommendation_detects_bare_structuring_request() -> None:
    mode, confidence, _reason, source = resolve_requirement_intake_entry_recommendation(
        message="整理一下采购需求",
        current_question=None,
        required_missing=[],
        normalize_message_text_fn=lambda value: str(value or "").strip().lower(),
        looks_like_small_talk_fn=lambda text: "你好" in text,
        contains_any_text_fn=lambda text, terms: any(term in text for term in terms),
        requirement_entry_explicit_phrases=("请先帮我梳理",),
        requirement_entry_context_terms=("需求",),
        requirement_entry_structuring_terms=("整理", "梳理"),
        question_terms=("?", "？"),
    )
    assert mode == "requirement_intake"
    assert confidence == 0.9
    assert source == "explicit_request"


def test_intake_payload_activity_and_requirement_mode_explicit_resolution() -> None:
    payload = {
        "required_missing": ["budget"],
    }
    assert has_active_intake_payload(payload) is True
    assert is_requirement_mode_explicit(
        command="send_message",
        mode_source="runtime",
        payload=payload,
    ) is True


def test_should_continue_active_intake_stops_on_small_talk_and_exit_message() -> None:
    payload = {
        "required_missing": ["budget"],
        "message": "先看分析吧",
    }
    assert should_continue_active_intake(
        command="send_message",
        payload=payload,
        extract_user_message_fn=lambda raw: str((raw or {}).get("message") or ""),
        looks_like_small_talk_fn=lambda text: text.strip() == "你好",
        is_intake_exit_message_fn=lambda text: is_intake_exit_message(
            text,
            intake_exit_hints=("先看分析",),
        ),
    ) is False


def test_resolve_intake_strategy_settings_supports_payload_override() -> None:
    strategy = resolve_intake_strategy_settings(
        runtime_payload={
            "intake_strategy": {
                "question_budget_max": 4,
                "framework_only": False,
            }
        },
        runtime_snapshot={},
    )
    assert strategy["question_budget_max"] == 4
    assert strategy["framework_only"] is False
    assert tuple(strategy["framework_fields"]) == tuple(DEFAULT_INTAKE_STRATEGY["framework_fields"])
