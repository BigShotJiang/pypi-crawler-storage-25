from __future__ import annotations

import json
from pathlib import Path

from flare_kernel.runtime.orchestration.artifact_template_runtime import build_artifact_template_runtime


_REPO_ROOT = Path(__file__).resolve().parents[3]


def _load_generic_domain_pack() -> dict:
    domain_dir = _REPO_ROOT / "domain-packs" / "generic"
    workflow = json.loads((domain_dir / "workflow.yaml").read_text(encoding="utf-8"))
    templates = {
        path.name: path.read_text(encoding="utf-8")
        for path in (domain_dir / "templates").glob("*.md")
    }
    return {"workflow": workflow, "templates": templates}


def test_artifact_template_runtime_projects_domain_pack_template() -> None:
    result = build_artifact_template_runtime(
        payload={
            "response_intent_result": {
                "response_intent": "document_template_output",
                "artifact_type": "requirements_document",
            }
        },
        domain_pack={
            "workflow": {
                "artifact_templates": {
                    "requirements_document": {
                        "template": "requirements-document.md",
                        "sections": [
                            {"key": "goal", "label": "目标", "instruction": "保留用户目标。"}
                        ],
                    }
                }
            },
            "templates": {"requirements-document.md": "# 模板\n## 目标"},
            "fields": {
                "field_definitions": [
                    {"key": "goal", "label": "目标", "priority": "required"},
                    {"key": "budget", "label": "预算", "priority": "recommended"},
                ]
            },
        },
    )

    assert result["status"] == "matched"
    assert result["artifact_type"] == "requirements_document"
    assert result["template_key"] == "requirements-document.md"
    assert result["sections"][0]["label"] == "目标"
    assert result["fields"][0]["key"] == "goal"


def test_artifact_template_runtime_ignores_non_document_response() -> None:
    result = build_artifact_template_runtime(
        payload={"response_intent_result": {"response_intent": "direct_answer", "artifact_type": "none"}},
        domain_pack={"templates": {"requirements-document.md": "# 模板"}},
    )

    assert result == {}


def test_generic_domain_pack_provides_base_templates_for_document_artifacts() -> None:
    domain_pack = _load_generic_domain_pack()

    for artifact_type, expected_template in {
        "generic_document": "generic-document.md",
        "plan": "plan.md",
        "report": "report.md",
        "checklist": "checklist.md",
    }.items():
        result = build_artifact_template_runtime(
            payload={
                "response_intent_result": {
                    "response_intent": "document_template_output",
                    "artifact_type": artifact_type,
                }
            },
            domain_pack=domain_pack,
        )

        assert result["status"] == "matched"
        assert result["artifact_type"] == artifact_type
        assert result["template_key"] == expected_template
        assert result["sections"]
        assert result["template_excerpt"].startswith("#")
        assert "<!--" not in result["template_excerpt"]
        assert "DOC HELPER" not in result["template_excerpt"]
