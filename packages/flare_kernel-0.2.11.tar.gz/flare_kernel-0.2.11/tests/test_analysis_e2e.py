from __future__ import annotations

from flare_kernel.router.payload.analysis_canvas import build_canvas_analysis_payload
from flare_kernel.runtime.context.analysis_application import build_context_patch_from_analysis
from flare_kernel.session_store import append_exchange, create_session, get_session, reset_store_for_testing


def test_uploaded_template_analysis_roundtrip_appends_and_reuses_context_result() -> None:
    reset_store_for_testing()
    session = create_session(function_type="chat", project_id="p", title="Demo", user_id="u")

    append_exchange(
        session_id=session["session_id"],
        document_result={
            "source_id": "src_template",
            "title": "分析报告模板",
            "document_kind": "template",
            "template": {
                "is_template": True,
                "template_sections": ["项目背景", "输出格式", "结论章节"],
                "required_output_fields": ["核心问题"],
            },
        },
    )
    with_template = get_session(session_id=session["session_id"])
    first_payload, _ = build_canvas_analysis_payload(
        analysis_route={"analysis_type": "requirement", "template_id": "flare.requirement.rfx.v1"},
        content_text="忽略正文",
        orchestration_status={"required_missing": []},
        runtime_snapshot={
            "session_context": with_template["context"],
            "payload": {"fields": {"goal": "空间搭建供应商分析"}},
        },
    )
    assert isinstance(first_payload, dict)
    document = first_payload["document"]
    assert document["template_id"] == "user.template.src_template.v1"
    assert [section["title"] for section in document["sections"]] == ["项目背景", "输出格式", "结论章节"]

    append_exchange(
        session_id=session["session_id"],
        context_patch=build_context_patch_from_analysis(first_payload),
    )
    with_analysis = get_session(session_id=session["session_id"])

    assert with_analysis["context"]["analysis_results"][0]["payload"]["markdown"] == first_payload["markdown"]

    second_payload, _ = build_canvas_analysis_payload(
        analysis_route={"analysis_type": "requirement", "template_id": "flare.requirement.rfx.v1"},
        content_text="忽略正文",
        orchestration_status={"required_missing": []},
        runtime_snapshot={
            "session_context": with_analysis["context"],
            "payload": {"fields": {}},
        },
    )
    assert isinstance(second_payload, dict)
    assert "项目背景：" in str(second_payload.get("markdown") or "")
