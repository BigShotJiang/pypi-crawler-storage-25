from __future__ import annotations

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.payload.action import build_action_payload, resolve_action_target_mode


def test_resolve_action_target_mode_prefers_explicit_target_mode() -> None:
    req = KernelRequest(target_mode="requirement_intake", intent="default", payload={})
    assert resolve_action_target_mode(req) == "requirement_intake"


def test_resolve_action_target_mode_falls_back_to_action_key() -> None:
    req = KernelRequest(action_key="handoff_to_sourcing", intent="default", payload={})
    assert resolve_action_target_mode(req) == "intelligent_sourcing"


def test_resolve_action_target_mode_accepts_neutral_domain_action_alias() -> None:
    req = KernelRequest(action_key="handoff_to_domain_flow", intent="default", payload={})
    assert resolve_action_target_mode(req) == "intelligent_sourcing"


def test_resolve_action_target_mode_routes_generic_analysis() -> None:
    req = KernelRequest(action_key="generate_analysis", intent="default", payload={})
    assert resolve_action_target_mode(req) == "analysis_mode"


def test_build_action_payload_applies_action_fields_and_base_fields() -> None:
    req = KernelRequest(
        action_key="confirm_sourcing",
        action_status="available",
        action_reason="ok",
        retrieval_config={"top_k": 8},
        payload={"category": "服务器"},
    )
    payload = build_action_payload(
        req,
        "intelligent_sourcing",
        collect_sourcing_base_fields=lambda p: {"category": p.get("category", "服务器")},
    )
    assert payload["function_type"] == "intelligent_sourcing"
    assert payload["target_mode"] == "intelligent_sourcing"
    assert payload["action_key"] == "confirm_sourcing"
    assert payload["sourcing_confirmed"] is True
    assert payload["retrieval_config"] == {"top_k": 8}
    assert payload["base_fields"] == {"category": "服务器"}


def test_build_action_payload_collects_explicit_base_fields_without_injected_collector() -> None:
    req = KernelRequest(
        action_key="handoff_to_sourcing",
        payload={
            "sourcing_base_field_keys": ["category", "region"],
            "fields": [
                {"field_key": "category", "value": "数据库"},
                {"field_key": "region", "value": "华东"},
            ]
        },
    )
    payload = build_action_payload(req, "intelligent_sourcing")
    assert payload["base_fields"] == {"category": "数据库", "region": "华东"}


def test_build_action_payload_collects_profile_defined_sourcing_base_fields() -> None:
    req = KernelRequest(
        action_key="handoff_to_sourcing",
        payload={
            "sourcing_base_field_keys": ["objective", "location"],
            "fields": [
                {"field_key": "objective", "value": "容量扩展"},
                {"field_key": "location", "value": "ap-southeast"},
            ],
        },
    )
    payload = build_action_payload(req, "intelligent_sourcing")
    assert payload["base_fields"] == {"objective": "容量扩展", "location": "ap-southeast"}


def test_confirm_sourcing_action_preserves_handoff_draft_payload() -> None:
    req = KernelRequest(
        action_key="confirm_sourcing",
        payload={
            "sourcing_parameters": {"category": "活动执行", "region": "上海"},
            "sourcing_query_draft": "活动执行 上海",
            "supplier_profile_draft": {"fields": {"category": "活动执行"}, "field_count": 2},
            "criteria": [{"key": "case", "label": "案例"}],
            "data_source_priority": ["instance_db", "local", "web"],
        },
    )

    payload = build_action_payload(req, "intelligent_sourcing")

    assert payload["sourcing_confirmed"] is True
    assert payload["sourcing_parameters"] == {"category": "活动执行", "region": "上海"}
    assert payload["sourcing_query_draft"] == "活动执行 上海"
    assert payload["supplier_profile_draft"] == {"fields": {"category": "活动执行"}, "field_count": 2}
    assert payload["criteria"] == [{"key": "case", "label": "案例"}]
    assert payload["data_source_priority"] == ["instance_db", "local", "web"]
