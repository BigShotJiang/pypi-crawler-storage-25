from __future__ import annotations

from flare_kernel.router.intake.amount_quantity import (
    canonicalize_budget_value,
    canonicalize_quantity_value,
)


def test_canonicalize_budget_value_handles_range() -> None:
    result = canonicalize_budget_value("预算10万到20万")
    assert isinstance(result, dict)
    assert result.get("status") == "confirmed"
    normalized = result.get("normalized_value") if isinstance(result.get("normalized_value"), dict) else {}
    assert normalized.get("kind") == "range"
    assert normalized.get("min") == 100000
    assert normalized.get("max") == 200000


def test_canonicalize_quantity_value_handles_approximate_quantity() -> None:
    result = canonicalize_quantity_value("大约20台")
    assert isinstance(result, dict)
    assert result.get("status") == "confirmed"
    assert result.get("display_value") == "约20台"
