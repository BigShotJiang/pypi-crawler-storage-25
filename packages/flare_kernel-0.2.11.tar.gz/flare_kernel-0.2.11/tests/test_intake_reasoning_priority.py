from __future__ import annotations

from flare_kernel.runtime.reasoning.intake.planning import detect_candidate_information_gaps


def test_direction_priority_disabled_by_default() -> None:
    session_state = {
        "confirmed_fields": {
            "goal": "我要组织一个商业演出",
        }
    }
    domain_context = {
        "required_fields": ["goal", "category", "execution_subject", "scope"],
        "field_definitions": [
            {"key": "goal", "label": "目标"},
            {"key": "category", "label": "演出性质"},
            {"key": "execution_subject", "label": "执行主体"},
            {"key": "scope", "label": "范围"},
        ],
        "field_semantics": {},
        "branch_hints": {},
    }

    result = detect_candidate_information_gaps(
        session_state=session_state,
        domain_context=domain_context,
        hypotheses=[],
        understood_context={},
    )

    gaps = result["candidate_information_gaps"]
    assert gaps
    reason = str(gaps[0].get("reason") or "")
    assert "pack_direction" not in reason


def test_direction_priority_prefers_category_after_goal_confirmed() -> None:
    session_state = {
        "confirmed_fields": {
            "goal": "我要组织一个商业演出",
        }
    }
    domain_context = {
        "required_fields": ["goal", "category", "execution_subject", "scope"],
        "field_definitions": [
            {"key": "goal", "label": "目标"},
            {"key": "category", "label": "演出性质"},
            {"key": "execution_subject", "label": "执行主体"},
            {"key": "scope", "label": "范围"},
        ],
        "field_semantics": {},
        "branch_hints": {},
        "intake_priority_policy": {
            "enabled": True,
            "category_weight": 0.26,
            "subject_after_category_weight": 0.24,
            "subject_before_category_weight": 0.08,
            "goal_defined_category_bonus": 0.08,
        },
    }

    result = detect_candidate_information_gaps(
        session_state=session_state,
        domain_context=domain_context,
        hypotheses=[],
        understood_context={},
    )

    gaps = result["candidate_information_gaps"]
    assert gaps
    assert gaps[0]["key"] == "category"


def test_direction_priority_prefers_subject_after_category_confirmed() -> None:
    session_state = {
        "confirmed_fields": {
            "goal": "我要组织一个商业演出",
            "category": "营利性商演",
        }
    }
    domain_context = {
        "required_fields": ["goal", "category", "execution_subject", "scope"],
        "field_definitions": [
            {"key": "goal", "label": "目标"},
            {"key": "category", "label": "演出性质"},
            {"key": "execution_subject", "label": "执行主体"},
            {"key": "scope", "label": "范围"},
        ],
        "field_semantics": {},
        "branch_hints": {},
        "intake_priority_policy": {
            "enabled": True,
            "category_weight": 0.26,
            "subject_after_category_weight": 0.24,
            "subject_before_category_weight": 0.08,
            "goal_defined_category_bonus": 0.08,
        },
    }

    result = detect_candidate_information_gaps(
        session_state=session_state,
        domain_context=domain_context,
        hypotheses=[],
        understood_context={},
    )

    gaps = result["candidate_information_gaps"]
    assert gaps
    assert gaps[0]["key"] == "execution_subject"


def test_gap_detection_does_not_deprioritize_field_names_without_pack_policy() -> None:
    domain_context = {
        "required_fields": ["constraints", "quantity"],
        "field_definitions": [
            {"key": "constraints", "label": "约束"},
            {"key": "quantity", "label": "数量"},
        ],
        "field_semantics": {},
        "branch_hints": {},
    }

    result = detect_candidate_information_gaps(
        session_state={"confirmed_fields": {}},
        domain_context=domain_context,
        hypotheses=[],
        understood_context={},
    )

    gaps = result["candidate_information_gaps"]
    assert gaps
    assert gaps[0]["key"] == "constraints"
    assert "pack_deprioritized_field" not in str(gaps[0].get("reason") or "")


def test_gap_detection_deprioritizes_fields_from_pack_policy() -> None:
    domain_context = {
        "required_fields": ["constraints", "quantity"],
        "field_definitions": [
            {"key": "constraints", "label": "约束"},
            {"key": "quantity", "label": "数量"},
        ],
        "field_semantics": {},
        "branch_hints": {},
        "intake_priority_policy": {
            "deprioritized_fields": ["constraints"],
            "deprioritized_field_weight": 0.5,
        },
    }

    result = detect_candidate_information_gaps(
        session_state={"confirmed_fields": {}},
        domain_context=domain_context,
        hypotheses=[],
        understood_context={},
    )

    gaps = result["candidate_information_gaps"]
    assert gaps
    assert gaps[0]["key"] == "quantity"
    constraint_gap = next(item for item in gaps if item["key"] == "constraints")
    assert "pack_deprioritized_field" in str(constraint_gap.get("reason") or "")
