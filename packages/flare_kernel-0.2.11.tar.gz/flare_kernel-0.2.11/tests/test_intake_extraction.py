from __future__ import annotations

from flare_kernel.router.intake.extraction.core import (
    extract_intake_fields_from_message,
    merge_into_confirmed_fields,
    merge_inferred_requirements,
    merge_supplementary_fields,
    normalize_extracted_field_values,
    resolve_intake_extraction_scope,
)


def test_resolve_intake_extraction_scope_uses_allowed_fields() -> None:
    scope = resolve_intake_extraction_scope({"allowed_fields": ["goal", "budget"]})
    assert scope == {"goal", "budget"}


def test_resolve_intake_extraction_scope_accepts_set_allowed_fields() -> None:
    scope = resolve_intake_extraction_scope({"allowed_fields": {"goal", "budget"}})
    assert scope == {"goal", "budget"}


def test_extract_intake_fields_from_message_respects_scope() -> None:
    result = extract_intake_fields_from_message(
        "用于测试，预算20万，预计10台",
        context={"allowed_fields": ["budget", "quantity"]},
    )
    fields = result.get("fields") if isinstance(result.get("fields"), dict) else {}
    assert "budget" in fields
    assert "quantity" in fields
    assert "goal" not in fields


def test_extract_intake_fields_from_message_infers_use_case_from_causal_context() -> None:
    result = extract_intake_fields_from_message(
        "公司计划发展AI赋能技术，为此需要添置一批服务器。",
        context={"allowed_fields": ["goal", "use_case"]},
    )
    fields = result.get("fields") if isinstance(result.get("fields"), dict) else {}
    assert fields["goal"] == "公司计划发展ai赋能技术"
    assert fields["use_case"] == "公司计划发展ai赋能技术"


def test_extract_intake_fields_from_message_does_not_treat_anniversary_as_delivery_time() -> None:
    result = extract_intake_fields_from_message(
        "公司20周年需要在上海办一次盛大的周年庆，还需要购买周年庆礼品。",
        context={"allowed_fields": ["delivery_time"]},
    )
    fields = result.get("fields") if isinstance(result.get("fields"), dict) else {}
    assert "delivery_time" not in fields


def test_extract_intake_fields_from_message_ignores_intake_instruction_prompt() -> None:
    result = extract_intake_fields_from_message(
        "请帮我梳理需求：基于当前会话，整理已知信息、关键缺口和下一步需要确认的问题。",
        context={"allowed_fields": ["goal", "use_case", "constraints"]},
    )
    assert result == {"fields": {}, "supplementary_fields": {}, "inferred_requirements": []}


def test_extract_intake_fields_from_message_ignores_analysis_instruction_prompt() -> None:
    result = extract_intake_fields_from_message(
        "请生成分析报告：基于当前已知信息生成分析初稿，明确已确认信息、当前假设和待补充项。",
        context={"allowed_fields": ["goal", "use_case", "constraints"]},
    )
    assert result == {"fields": {}, "supplementary_fields": {}, "inferred_requirements": []}


def test_normalize_extracted_field_values_filters_empty_entries() -> None:
    normalized = normalize_extracted_field_values(
        {
            "fields": {"goal": "  上线  ", "budget": "   ", "": "x"},
            "supplementary_fields": {"a": 1},
            "inferred_requirements": [" x ", " ", "x"],
        }
    )
    assert normalized["fields"] == {"goal": "上线"}
    assert normalized["supplementary_fields"] == {"a": 1}
    assert normalized["inferred_requirements"] == ["x", "x"]


def test_merge_helpers_preserve_existing_and_deduplicate() -> None:
    merged_fields, sources = merge_into_confirmed_fields(
        {"goal": "已有"},
        {"fields": {"goal": "新值", "budget": "预算10万"}},
    )
    assert merged_fields == {"goal": "已有", "budget": "预算10万"}
    assert sources == {"budget": "message_extraction"}

    supplementary = merge_supplementary_fields({"tags": ["a"]}, {"tags": ["a", "b"], "note": "ok"})
    assert supplementary == {"tags": ["a", "b"], "note": "ok"}

    inferred = merge_inferred_requirements(["one"], ["one", "two"])
    assert inferred == ["one", "two"]
