from __future__ import annotations

from flare_kernel.router.intake.node_state import resolve_intake_node_state


def test_resolve_intake_node_state_prefers_chooser_when_required() -> None:
    state = resolve_intake_node_state(
        current_stage="requirement_intake.collecting",
        current_question={"field_key": "budget", "question_text": "预算？"},
        open_fields=[{"field_key": "budget"}],
        chooser={"blocking_reason": "缺少预算"},
        decision_point_active=False,
        decision_basis=[],
        blocking_reason="",
        checkpoint_state_value="",
    )
    assert state["chooser_required"] is True
    assert state["node_id"] == "chooser"
    assert state["node_state"] == "blocked"
    assert state["needs_user_choice"] is True
    assert state["blocking_reason"] == "缺少预算"


def test_resolve_intake_node_state_uses_decision_point_when_ready() -> None:
    state = resolve_intake_node_state(
        current_stage="requirement_intake.ready_for_submit",
        current_question=None,
        open_fields=[],
        chooser=None,
        decision_point_active=True,
        decision_basis=[],
        blocking_reason="",
        checkpoint_state_value="",
    )
    assert state["node_id"] == "decision_point"
    assert state["node_state"] == "ready"
    assert state["needs_user_choice"] is True
    assert state["node_reason"] == "关键字段已确认，请选择下一步。"


def test_resolve_intake_node_state_waiting_user_overrides_default_next_actions() -> None:
    state = resolve_intake_node_state(
        current_stage="intent_detecting",
        current_question={"field_key": "quantity"},
        open_fields=[],
        chooser=None,
        decision_point_active=False,
        decision_basis=[],
        blocking_reason="",
        checkpoint_state_value="waiting_user",
    )
    assert state["node_id"] == "chooser"
    assert state["node_state"] == "blocked"
    assert state["needs_user_choice"] is True
    assert state["node_reason"] == "等待用户补充关键信息。"


def test_resolve_intake_node_state_drops_chooser_when_not_required() -> None:
    state = resolve_intake_node_state(
        current_stage="sourcing.ready",
        current_question=None,
        open_fields=[],
        chooser={"blocking_reason": "不会展示"},
        decision_point_active=False,
        decision_basis=[{"conclusion": "已切换为寻源流程"}],
        blocking_reason="",
        checkpoint_state_value="",
    )
    assert state["chooser_required"] is False
    assert state["chooser"] is None
    assert state["node_id"] == "sourcing"
    assert state["node_state"] == "ready"
    assert state["node_reason"] == "已切换为寻源流程"
