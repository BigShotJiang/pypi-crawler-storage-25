from __future__ import annotations

from flare_kernel.router.intake.field_projection.payload import canonicalize_payload_fields


def test_canonicalize_payload_fields_keeps_unparsed_structured_as_candidate() -> None:
    payload = {
        "fields": {"delivery_time": "尽快"},
        "field_sources": {"delivery_time": "user_input"},
        "required_fields": ["delivery_time"],
        "field_semantics": {"delivery_time": {"value_type": "time_window"}},
    }
    canonicalized = canonicalize_payload_fields(payload)
    assert canonicalized.get("fields") == {}
    assert canonicalized.get("required_missing") == []
    candidates = canonicalized.get("field_candidates")
    assert isinstance(candidates, dict)
    delivery = candidates.get("delivery_time")
    assert isinstance(delivery, dict)
    assert delivery.get("status") == "unparsed"
    clarifications = canonicalized.get("field_clarifications")
    assert isinstance(clarifications, dict)
    assert clarifications["delivery_time"]["status"] == "needs_clarification"


def test_canonicalize_payload_fields_does_not_revive_answered_structured_field() -> None:
    payload = {
        "fields": {"budget": "预算大概看情况"},
        "field_sources": {"budget": "question_answer"},
        "required_fields": ["budget", "quantity"],
        "required_missing": ["budget", "quantity"],
        "question_answer": {"field_key": "budget", "raw_value": "预算大概看情况"},
        "field_semantics": {"budget": {"value_type": "money"}, "quantity": {"value_type": "quantity"}},
    }

    canonicalized = canonicalize_payload_fields(payload)

    assert canonicalized.get("fields") == {}
    assert canonicalized.get("required_missing") == ["quantity"]
    candidates = canonicalized.get("field_candidates")
    assert isinstance(candidates, dict)
    assert candidates["budget"]["status"] == "unparsed"
    assert canonicalized["field_clarifications"]["budget"]["reason"] == "unparsed_structured_value"
