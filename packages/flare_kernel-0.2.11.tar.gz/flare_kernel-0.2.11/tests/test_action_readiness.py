from __future__ import annotations

from flare_kernel.router.orchestration.status.action_readiness import evaluate_action_readiness


def test_action_readiness_hides_optional_actions_without_context() -> None:
    readiness = evaluate_action_readiness(
        fields={},
        normalized_required_missing=["budget"],
        retrieval_hit_count=0,
        analysis_entry_eligible=False,
        current_question={"field_key": "budget"},
    )

    assert readiness["continue_collection"]["readiness_level"] == "recommended"
    assert readiness["confirm_plan"]["readiness_level"] == "hidden"
    assert readiness["handoff_to_sourcing"]["readiness_level"] == "hidden"


def test_action_readiness_allows_optional_actions_with_field_context() -> None:
    readiness = evaluate_action_readiness(
        fields={"category": "服务器"},
        normalized_required_missing=["budget"],
        retrieval_hit_count=0,
        analysis_entry_eligible=False,
        current_question={"field_key": "budget"},
    )

    assert readiness["confirm_plan"]["readiness_level"] == "available"
    assert readiness["handoff_to_sourcing"]["readiness_level"] == "available"
    assert readiness["confirm_plan"]["readiness_score"] > 0


def test_action_readiness_uses_retrieval_context_without_field_values() -> None:
    readiness = evaluate_action_readiness(
        fields={},
        normalized_required_missing=["budget"],
        retrieval_hit_count=2,
        analysis_entry_eligible=False,
        current_question={"field_key": "budget"},
    )

    assert readiness["confirm_plan"]["readiness_level"] == "available"
    assert readiness["handoff_to_sourcing"]["readiness_level"] == "available"


def test_action_readiness_recommends_analysis_when_eligible() -> None:
    readiness = evaluate_action_readiness(
        fields={"category": "服务器", "quantity": "10台", "deadline": "下周"},
        normalized_required_missing=[],
        retrieval_hit_count=2,
        analysis_entry_eligible=True,
        current_question=None,
    )

    assert readiness["confirm_plan"]["readiness_level"] == "recommended"
