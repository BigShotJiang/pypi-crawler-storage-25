from __future__ import annotations

from flare_kernel.router.intake.guided.confirmed_updates import build_confirmed_updates


def test_build_confirmed_updates_filters_empty_values() -> None:
    result = build_confirmed_updates(
        {
            "category": "服务器",
            "budget": "",
            "quantity": None,
            "delivery_location": "上海园区",
        }
    )
    assert result == [
        {"field_key": "category", "field_value": "服务器"},
        {"field_key": "delivery_location", "field_value": "上海园区"},
    ]


def test_build_confirmed_updates_projects_backend_field_labels() -> None:
    result = build_confirmed_updates(
        {"delivery_location": "上海园区"},
        field_label_map={"delivery_location": "交付地点"},
    )

    assert result == [
        {
            "field_key": "delivery_location",
            "field_value": "上海园区",
            "label": "交付地点",
            "field_label": "交付地点",
        }
    ]
