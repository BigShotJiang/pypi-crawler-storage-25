from __future__ import annotations

from typing import Any

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.canonical.context import resolve_canonical_state_context
from flare_kernel.router.canonical.payload import build_canonical_payload
from flare_kernel.router.orchestration.status.builder import build_orchestration_status
from flare_kernel.router.orchestration.status.core import resolve_orchestration_status_state


def test_resolve_canonical_state_context_returns_expected_core_fields() -> None:
    req = KernelRequest(payload={"message": "请继续"}, session_id="session-1", trace_id="trace-1")
    context = resolve_canonical_state_context(
        req=req,
        command="send_message",
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        mode_source="manual",
        orchestration_status={
            "required_missing": ["budget"],
            "current_question": {
                "field_key": "budget",
                "question_text": "预算区间是多少？",
            },
            "intake_session_id": "intake-1",
            "intake_session_state": "collecting",
            "analysis_entry_threshold": 0.75,
            "analysis_entry_eligible": False,
            "intake_understanding": {"summary": "s"},
        },
        assistant_text="",
        map_external_mode_fn=lambda mode: mode,
        resolve_session_intent_stage_fn=lambda **_: "clarification_in_progress",
        coerce_intent_escalation_policy_fn=lambda raw: raw if isinstance(raw, dict) else {},
        normalize_stage_status_fn=lambda **kwargs: (
            str(kwargs.get("current_stage") or "intake_collecting"),
            "waiting_user" if list(kwargs.get("required_missing") or []) else "running",
        ),
        is_field_entity_confirmed_fn=lambda entity: bool(isinstance(entity, dict) and entity.get("confirmed") is True),
        extract_user_message_fn=lambda payload: str((payload or {}).get("message") or ""),
        normalize_intake_session_id_fn=lambda raw: str(raw or "").strip(),
    )

    assert context["intake_session_id"] == "intake-1"
    assert context["session_intent_stage"] == "clarification_in_progress"
    assert context["required_missing"] == ["budget"]
    assert context["can_generate"] is False
    assert context["activated_mode"] in {"requirement_intake", "auto"}


def test_build_canonical_payload_projects_context_into_contract_shape() -> None:
    req = KernelRequest(payload={"field_key": "budget"}, session_id="session-2", trace_id="trace-2")
    canonical = build_canonical_payload(
        req=req,
        command="generate_analysis",
        mode_source="manual",
        orchestration_status={"intake_understanding": {"summary": "ok"}},
        assistant_text="分析结果",
        provider_status="ok",
        canonical_context={
            "fields": {"budget": "100万"},
            "field_entities": {"budget": {"confirmed": True}},
            "required_missing": [],
            "intake_session_id": "intake-2",
            "intake_session_state": "analysis_running",
            "intake_session_completed": False,
            "can_generate": True,
            "explicit_activation": True,
            "activated_mode": "requirement_intake",
            "suggested_mode": "requirement_intake",
            "stage_key": "analysis_running",
            "status_key": "running",
            "checkpoint": {"workflow_id": "wf-1", "checkpoints": []},
            "intent_type": "procurement_requirement_intake",
            "session_intent_stage": "analysis_running",
            "conversation_intent_state": "analysis_running",
            "procurement_relevance": True,
            "escalation_target": "intake_candidate",
            "intake_candidate": True,
            "clarification_recommended": False,
            "analysis_ready": True,
            "draft_seeded": True,
            "missing_key_fields": [],
            "recommended_next_step": "generate_analysis",
            "resolved_intent_escalation_policy": {},
            "resolved_intent_escalation_policy_source": "default",
            "current_question": None,
            "next_actions": [{"action_key": "generate_analysis"}],
            "required_coverage": 1.0,
            "total_coverage": 1.0,
            "analysis_entry_threshold": 0.8,
            "analysis_entry_eligible": True,
            "analyzability_score": 1.0,
            "analysis_assumptions": [],
            "errors": [],
        },
        build_confirmed_fields_schema_fn=lambda fields, entities: {
            "items": [{"field_key": key, "value": value, "entity": entities.get(key)} for key, value in fields.items()]
        },
        build_missing_fields_schema_fn=lambda missing: {"items": [{"field_key": item} for item in missing]},
        resolve_trace_id_fn=lambda trace_id: str(trace_id or "trace"),
        safe_session_id_fn=lambda session_id: str(session_id or ""),
    )

    assert canonical["primary_flow"]["mode"]["activated"] == "requirement_intake"
    assert canonical["primary_flow"]["chooser_state"]["kind"] == "none"
    assert canonical["primary_flow"]["chooser_state"]["visible"] is False
    assert canonical["analysis"]["readiness"]["can_generate"] is True
    assert canonical["confirmed_fields"]["items"][0]["field_key"] == "budget"
    assert canonical["intake_session_id"] == "intake-2"


def test_build_orchestration_status_wires_state_and_projection_layers(monkeypatch: Any) -> None:
    captured: dict[str, Any] = {}

    def fake_resolve_state(**kwargs: Any) -> dict[str, Any]:
        captured["resolve_state_kwargs"] = kwargs
        return {
            "current_stage": "intake_collecting",
            "confirmed_updates": [],
            "field_entities": {},
            "open_fields": [],
            "next_action": {"action_key": "collect"},
            "resolved_actions": [],
            "decision_payload": {},
            "active_collecting": True,
            "ready_for_submit": False,
            "required_coverage": 0.1,
            "total_coverage": 0.2,
            "analysis_entry_threshold": 0.8,
            "analysis_entry_eligible": False,
            "analyzability_score": 0.1,
            "decision_point_active": False,
            "has_active_question": True,
            "question_progress": {},
            "guided_session": {},
            "intake_followup_state": {},
            "current_question": None,
            "normalized_required_fields": ["budget"],
            "normalized_required_missing": ["budget"],
            "session_intent_stage": "clarification_in_progress",
            "conversation_intent_state": "clarification_in_progress",
            "procurement_relevance": True,
            "intake_understanding": {},
            "active_checkpoint": {},
            "checkpoint_state_value": "running",
            "chooser": None,
            "node_id": "collect",
            "node_state": "running",
            "node_reason": "collecting",
            "needs_user_choice": False,
            "chooser_required": False,
            "blocking_reason": "",
            "search_retrieval_hit_count": 1,
            "intake_session_id": "intake-3",
        }

    def fake_build_search_actions(**kwargs: Any) -> list[dict[str, Any]]:
        captured["search_actions_kwargs"] = kwargs
        return [{"action": "knowledge_search"}]

    def fake_build_workspace_updates(**kwargs: Any) -> list[dict[str, Any]]:
        captured["workspace_updates_kwargs"] = kwargs
        return [{"type": "note"}]

    def fake_build_payload(**kwargs: Any) -> dict[str, Any]:
        captured["payload_kwargs"] = kwargs
        return {"ok": True, "trace_id": kwargs["trace_id"]}

    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.builder.resolve_orchestration_status_state",
        fake_resolve_state,
    )
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.builder.build_search_actions",
        fake_build_search_actions,
    )
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.builder.build_workspace_updates",
        fake_build_workspace_updates,
    )
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.builder.build_orchestration_status_payload",
        fake_build_payload,
    )

    result = build_orchestration_status(
        trace_id="trace-x",
        command="send_message",
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        intent_source="manual",
        intent_confidence=1.0,
        intent_reason="reason",
        runtime_snapshot={},
        raw_message="hello",
        retrieval_attempted=True,
        retrieval_queries=["q1"],
        retrieved_knowledge=[{"id": "k1"}],
        resolve_requirement_intake_entry_recommendation_fn=lambda **_: ("requirement_intake", 1.0, "rule", "rule"),
        resolve_session_intent_stage_fn=lambda **_: "clarification_in_progress",
        coerce_intent_escalation_policy_fn=lambda raw: raw if isinstance(raw, dict) else {},
        extract_user_message_fn=lambda payload: str((payload or {}).get("message") or ""),
        intent_escalation_policy={"enabled": True},
        intent_escalation_policy_source="manual",
    )

    assert result == {"ok": True, "trace_id": "trace-x"}
    assert captured["resolve_state_kwargs"]["trace_id"] == "trace-x"
    assert captured["search_actions_kwargs"]["retrieval_queries"] == ["q1"]
    assert captured["workspace_updates_kwargs"]["retrieved_knowledge_count"] == 1
    assert captured["payload_kwargs"]["intent_escalation_policy_source"] == "manual"


def test_resolve_orchestration_status_state_is_unit_testable_with_monkeypatch(monkeypatch: Any) -> None:
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.core.prepare_orchestration_input_context",
        lambda **_: {"ok": True},
    )
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.core.unpack_orchestration_input_context",
        lambda _: {
            "next_actions_payload": {},
            "field_progress_payload": {},
            "runtime_payload": {"message": "m"},
            "intake_checkpoint": {},
            "current_question": None,
            "question_progress": {},
            "fields": {},
            "field_entities": {},
            "intake_understanding": {},
            "intake_session_id": "intake-9",
            "normalized_required_fields": ["budget"],
            "normalized_required_missing": ["budget"],
            "required_coverage": 0.2,
            "total_coverage": 0.3,
            "analysis_entry_threshold": 0.8,
            "analyzability_score": 0.25,
            "analysis_entry_eligible": False,
            "open_fields": [],
            "chooser": None,
            "mode_state": {},
            "payload_actions": [],
        },
    )
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.core.resolve_entry_message",
        lambda **_: "m",
    )
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.core.resolve_decision_and_stage",
        lambda **_: ({"next_actions": []}, "intake_collecting"),
    )
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.core.build_confirmed_updates",
            lambda *_, **__: [],
    )
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.core.build_field_label_map",
        lambda _: {},
    )
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.core.resolve_followup_and_guided_state",
        lambda **_: {
            "intake_followup_state": {},
            "next_action": {"action_key": "collect"},
            "ready_for_submit": False,
            "decision_point_active": False,
            "has_active_question": False,
            "active_collecting": True,
            "guided_session": {},
        },
    )
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.core.resolve_node_and_checkpoint_state",
        lambda **_: {
            "checkpoint_state_value": "running",
            "node_id": "collect",
            "node_state": "running",
            "node_reason": "collecting",
            "needs_user_choice": False,
            "chooser_required": False,
            "blocking_reason": "",
            "chooser": None,
            "active_checkpoint": {},
        },
    )
    monkeypatch.setattr(
        "flare_kernel.router.orchestration.status.core.compute_procurement_relevance",
        lambda **_: True,
    )

    state = resolve_orchestration_status_state(
        trace_id="trace-z",
        command="send_message",
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        runtime_snapshot={},
        raw_message="m",
        retrieval_attempted=True,
        retrieved_knowledge=[{"id": "k1"}],
        resolve_requirement_intake_entry_recommendation_fn=lambda **_: ("requirement_intake", 1.0, "rule", "rule"),
        resolve_session_intent_stage_fn=lambda **_: "clarification_in_progress",
        extract_user_message_fn=lambda payload: str((payload or {}).get("message") or ""),
    )

    assert state["intake_session_id"] == "intake-9"
    assert state["node_id"] == "collect"
    assert state["search_retrieval_hit_count"] == 1
    assert state["session_intent_stage"] == "clarification_in_progress"
