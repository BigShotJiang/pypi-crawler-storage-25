from __future__ import annotations

from flare_kernel.router.intake.guided.followup_work_item import (
    build_active_work_item_payload,
    build_work_item_actions,
    resolve_external_work_item_status,
    resolve_external_work_item_type,
)


def test_resolve_external_work_item_type_and_status() -> None:
    work_type = resolve_external_work_item_type(
        current_stage="evidence_retrieval.active",
        command="open_field_retrieval",
        intake_session_open=False,
    )
    assert work_type == "retrieval"
    work_status = resolve_external_work_item_status(
        work_item_type=work_type,
        followup_status="idle",
        command="open_field_retrieval",
        has_analysis_content=False,
        normalized_required_missing=[],
        active_field_key="budget",
    )
    assert work_status == "running"


def test_build_work_item_actions_and_payload_shape() -> None:
    actions = build_work_item_actions(
        [
            {"action_key": "confirm_plan", "status": "available", "command": "send_message", "target_mode": "requirement_intake"},
            {"status": "available"},
        ]
    )
    assert actions == [
        {
            "action_key": "confirm_plan",
            "status": "available",
            "command": "send_message",
            "target_mode": "requirement_intake",
        }
    ]

    payload = build_active_work_item_payload(
        external_work_item_type="analysis",
        intake_session_id="intake-1",
        trace_id="trace-1",
        work_item_status="running",
        blocking_is_blocked=False,
        blocking_reason="",
        normalized_required_missing=["budget"],
        has_analysis_content=False,
        active_field_key="budget",
        active_question_id="budget:1",
        work_item_actions=actions,
    )
    assert payload["id"] == "analysis::intake-1"
    assert payload["blocking"]["is_blocked"] is True
    assert payload["blocking"]["reason"] == "waiting_required_fields"
