from __future__ import annotations

from flare_kernel.runtime.orchestration.mode.intake_question import build_intake_question
from flare_kernel.runtime.reasoning.intake.question.extraction import extract_next_question_plan


def test_intake_question_projection_normalizes_options_and_aligns_decision() -> None:
    result = build_intake_question(
        payload={},
        intake_session_id="intake-1",
        missing=["quantity"],
        reasoning_state={"confirmed_fields": {}, "latest_input": "我要采购服务器"},
        domain_context={
            "required_fields": ["use_case", "quantity"],
            "field_definitions": [
                {"key": "use_case", "label": "使用场景", "priority": "required"},
                {
                    "key": "quantity",
                    "label": "数量",
                    "priority": "required",
                    "options": ["10台以内", "50台以上"],
                },
            ],
            "field_semantics": {"quantity": {"value_type": "quantity"}},
        },
        hypotheses=[],
        field_selection={
            "active_fields": ["use_case", "quantity"],
            "field_scores": {"use_case": 100, "quantity": 10},
        },
        structured_reasoning={
            "question_planner": {
                "next_question": {
                    "question_key": "use_case",
                    "question_text": "主要使用场景是什么？",
                    "target_field_keys": ["use_case"],
                    "why_now": "structured_model",
                }
            }
        },
        understanding_state={},
        field_definitions_by_key={
            "use_case": {"key": "use_case", "label": "使用场景", "priority": "required"},
            "quantity": {
                "key": "quantity",
                "label": "数量",
                "priority": "required",
                "options": ["10台以内", "50台以上"],
            },
        },
    )

    question = result["current_question"]
    assert question["field_key"] == "quantity"
    assert question["question_key"] == "quantity"
    assert question["target_information_gap"] == "quantity"
    assert question["options"] == [
        {
            "key": "option_1",
            "label": "10台以内",
            "value": "10台以内",
            "followup_hint": "",
            "requires_custom_input": False,
            "activates_fields": [],
            "suppresses_fields": [],
        },
        {
            "key": "option_2",
            "label": "50台以上",
            "value": "50台以上",
            "followup_hint": "",
            "requires_custom_input": False,
            "activates_fields": [],
            "suppresses_fields": [],
        },
    ]
    assert result["question_decision"]["selected_field_key"] == "quantity"


def test_intake_question_uses_structured_calibration_question_with_carrier_field() -> None:
    result = build_intake_question(
        payload={},
        intake_session_id="intake-1",
        missing=["use_case", "budget", "quantity", "constraints"],
        reasoning_state={"confirmed_fields": {"goal": "采购桌椅"}, "latest_input": "我要采购一批桌椅"},
        domain_context={
            "required_fields": ["goal", "use_case", "budget", "quantity", "constraints"],
            "field_definitions": [
                {"key": "use_case", "label": "使用场景", "priority": "required"},
                {"key": "budget", "label": "预算", "priority": "required"},
                {"key": "quantity", "label": "数量", "priority": "required"},
                {"key": "constraints", "label": "关键约束", "priority": "required"},
            ],
            "field_semantics": {
                "use_case": {"value_type": "text"},
                "constraints": {"value_type": "text"},
            },
        },
        hypotheses=[],
        field_selection={
            "active_fields": ["use_case", "budget", "quantity", "constraints"],
            "field_scores": {"use_case": 20, "budget": 5, "quantity": 4, "constraints": 10},
        },
        structured_reasoning={
            "question_planner": {
                "next_question": {
                    "question_key": "placement_area",
                    "target_field_keys": ["placement_area"],
                    "target_information_gap": "placement_area",
                    "question_text": "这批桌椅主要计划布置在哪个具体区域？",
                    "options": [
                        {"key": "reception", "label": "展厅接待洽谈区", "value": "展厅接待洽谈区"},
                    ],
                }
            }
        },
        understanding_state={},
        field_definitions_by_key={
            "use_case": {"key": "use_case", "label": "使用场景", "priority": "required"},
            "budget": {"key": "budget", "label": "预算", "priority": "required"},
            "quantity": {"key": "quantity", "label": "数量", "priority": "required"},
            "constraints": {"key": "constraints", "label": "关键约束", "priority": "required"},
        },
    )

    question = result["current_question"]
    assert question["field_key"] == "use_case"
    assert question["question_key"] == "placement_area"
    assert question["target_information_gap"] == "placement_area"
    assert question["question_text"] == "这批桌椅主要计划布置在哪个具体区域？"
    assert [item["label"] for item in question["options"]] == ["展厅接待洽谈区"]
    assert result["question_decision"]["selected_field_key"] == "use_case"
    assert result["question_decision"]["target_information_gap"] == "placement_area"


def test_intake_question_does_not_generate_label_based_fallback_text() -> None:
    result = build_intake_question(
        payload={},
        intake_session_id="intake-1",
        missing=["budget"],
        reasoning_state={"confirmed_fields": {}, "latest_input": "我要采购服务器"},
        domain_context={
            "required_fields": ["budget"],
            "field_definitions": [
                {"key": "budget", "label": "预算", "priority": "required"},
            ],
            "field_semantics": {"budget": {"value_type": "money"}},
        },
        hypotheses=[],
        field_selection={
            "active_fields": ["budget"],
            "field_scores": {"budget": 10},
        },
        structured_reasoning={},
        understanding_state={},
        field_definitions_by_key={
            "budget": {"key": "budget", "label": "预算", "priority": "required"},
        },
    )

    question = result["current_question"]
    assert question["field_key"] == "budget"
    assert question["question_text"] == ""


def test_result_extraction_does_not_synthesize_gap_label_question() -> None:
    result = extract_next_question_plan(
        result_text="关键缺口：\n1. 预算范围：待确认",
        current_planned_question={},
        candidate_information_gaps=[{"key": "budget", "label": "预算范围"}],
    )

    assert result == {}
