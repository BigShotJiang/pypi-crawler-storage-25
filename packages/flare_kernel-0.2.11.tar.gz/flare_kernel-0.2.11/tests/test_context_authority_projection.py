from __future__ import annotations

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.canonical.payload import build_canonical_payload


def test_canonical_payload_projects_context_authority_from_backend_session_context() -> None:
    canonical = build_canonical_payload(
        req=KernelRequest(payload={}),
        command="send_message",
        mode_source="manual",
        orchestration_status={},
        assistant_text="完成",
        provider_status="ok",
        canonical_context={
            "fields": {},
            "field_entities": {},
            "required_missing": [],
            "intake_session_id": "",
            "intake_session_state": "",
            "intake_session_completed": False,
            "can_generate": False,
            "explicit_activation": False,
            "activated_mode": "auto",
            "stage_key": "general_chat",
            "status_key": "idle",
            "current_question": None,
            "next_actions": [],
            "checkpoint": {},
        },
        runtime_snapshot={
            "session_context": {
                "context_revision_id": "ctx_1",
                "updated_at": "2026-05-03T00:00:00Z",
                "facts": [{"id": "fact_1", "text": "已确认预算。"}],
                "unknowns": [{"id": "unknown_1", "text": "交付时间待确认。"}],
                "evidence": [{"id": "ev_1", "source_id": "src_1"}],
                "turns": [{"turn_id": "turn_1"}],
                "artifact_context": [{"source_id": "src_1"}],
                "archive_summary": {
                    "relationship_graph": {
                        "nodes": [{"id": "fact_1"}],
                        "edges": [{"source": "fact_1", "target": "summary"}],
                    }
                },
            }
        },
        build_confirmed_fields_schema_fn=lambda *_args, **_kwargs: {},
        build_missing_fields_schema_fn=lambda *_args, **_kwargs: {"required": [], "recommended": [], "optional": []},
        resolve_trace_id_fn=lambda _trace: "trace_1",
        safe_session_id_fn=lambda _sid: "session_1",
    )

    authority = canonical["context_authority"]
    assert authority["schema_version"] == "context_authority.v1"
    assert authority["owner"] == "backend"
    assert authority["authoritative"] is True
    assert authority["source"] == "session_context"
    assert authority["frontend_policy"] == "projection_only"
    assert authority["persistence"]["available"] is True
    assert authority["persistence"]["context_revision_id"] == "ctx_1"
    assert authority["counts"] == {
        "facts": 1,
        "unknowns": 1,
        "evidence": 1,
        "turns": 1,
        "artifact_context": 1,
        "graph_nodes": 1,
        "graph_edges": 1,
    }
