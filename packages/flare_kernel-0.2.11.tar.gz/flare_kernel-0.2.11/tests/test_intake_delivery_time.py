from __future__ import annotations

from flare_kernel.router.intake.delivery_time import canonicalize_delivery_time_value


def test_canonicalize_delivery_time_value_handles_date_and_duration() -> None:
    date_result = canonicalize_delivery_time_value("2024年6月1日")
    assert isinstance(date_result, dict)
    assert date_result.get("display_value") == "2024年6月1日"

    duration_result = canonicalize_delivery_time_value("大约3个月")
    assert isinstance(duration_result, dict)
    assert duration_result.get("display_value") == "约3个月"


def test_canonicalize_delivery_time_value_does_not_treat_anniversary_as_duration() -> None:
    assert canonicalize_delivery_time_value("公司20周年需要采购礼品") is None
