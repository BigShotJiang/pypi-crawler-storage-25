from __future__ import annotations

from flare_kernel.router.canonical.flow import (
    normalize_stage_status_and_question,
    resolve_analysis_generation_state,
    resolve_flow_activation,
)


def test_resolve_flow_activation_prefers_explicit_activation() -> None:
    result = resolve_flow_activation(
        command="activate_requirement_intake",
        mode_source="fallback",
        resolved_intent="default",
        external_mode="requirement_intake",
        inferred_stage="",
        intake_candidate=False,
        clarification_recommended=False,
        escalation_target="",
        analysis_ready=False,
        required_missing=[],
        current_question=None,
        fields={},
        map_external_mode_fn=lambda mode: "requirement_intake" if mode == "requirement_intake" else mode,
    )

    assert result["explicit_activation"] is True
    assert result["activated_mode"] == "requirement_intake"


def test_resolve_flow_activation_treats_manual_hint_as_explicit_activation() -> None:
    result = resolve_flow_activation(
        command="send_message",
        mode_source="manual_hint",
        resolved_intent="default",
        external_mode="requirement_intake",
        inferred_stage="general_chat",
        intake_candidate=False,
        clarification_recommended=False,
        escalation_target="",
        analysis_ready=False,
        required_missing=[],
        current_question=None,
        fields={},
        map_external_mode_fn=lambda mode: "requirement_intake" if mode == "requirement_intake" else mode,
    )

    assert result["explicit_activation"] is True
    assert result["activated_mode"] == "requirement_intake"


def test_resolve_flow_activation_treats_intake_apply_as_explicit_activation() -> None:
    result = resolve_flow_activation(
        command="implement",
        mode_source="command",
        resolved_intent="default",
        external_mode="requirement_intake",
        inferred_stage="requirement_intake.collecting",
        intake_candidate=False,
        clarification_recommended=False,
        escalation_target="",
        analysis_ready=False,
        required_missing=["constraints"],
        current_question={"field_key": "constraints"},
        fields={"goal": "采购服务器"},
        map_external_mode_fn=lambda mode: "requirement_intake" if mode == "requirement_intake" else mode,
    )

    assert result["explicit_activation"] is True
    assert result["activated_mode"] == "requirement_intake"


def test_resolve_flow_activation_suggests_intake_without_auto_activation() -> None:
    result = resolve_flow_activation(
        command="send_message",
        mode_source="intent_and_escalation_classifier",
        resolved_intent="requirement_intake",
        external_mode="requirement_intake",
        inferred_stage="requirement_intake.collecting",
        intake_candidate=True,
        clarification_recommended=True,
        escalation_target="intake_candidate",
        analysis_ready=False,
        required_missing=["budget"],
        current_question={"field_key": "budget"},
        fields={},
        map_external_mode_fn=lambda mode: "requirement_intake" if mode == "requirement_intake" else mode,
    )

    assert result["explicit_activation"] is False
    assert result["activated_mode"] == "auto"
    assert result["suggested_mode"] == "requirement_intake"


def test_normalize_stage_status_and_question_sets_idle_when_auto_collecting() -> None:
    stage_key, status_key, question = normalize_stage_status_and_question(
        orchestration_status={"current_stage": "requirement_intake.collecting"},
        required_missing=["budget"],
        activated_mode="auto",
        current_question={"field_key": "budget"},
        command="send_message",
        assistant_text="",
        intake_session_id="intake_1",
        normalize_stage_status_fn=lambda **_kwargs: ("requirement_intake", "collecting"),
    )

    assert stage_key == "requirement_intake"
    assert status_key == "idle"
    assert question is None


def test_normalize_stage_status_and_question_does_not_synthesize_question_without_backend_state() -> None:
    stage_key, status_key, question = normalize_stage_status_and_question(
        orchestration_status={"current_stage": "requirement_intake.collecting"},
        required_missing=["budget"],
        activated_mode="requirement_intake",
        current_question=None,
        command="send_message",
        assistant_text="",
        intake_session_id="intake_1",
        normalize_stage_status_fn=lambda **_kwargs: ("requirement_intake", "collecting"),
    )

    assert stage_key == "requirement_intake"
    assert status_key == "collecting"
    assert question is None


def test_resolve_analysis_generation_state_builds_validation_error_when_not_ready() -> None:
    state = resolve_analysis_generation_state(
        command="generate_analysis",
        activated_mode="requirement_intake",
        required_missing=["budget"],
        analysis_entry_eligible=False,
        analysis_ready=False,
        has_fields=False,
        stage_key="requirement_intake",
        status_key="collecting",
    )

    assert state["can_generate"] is False
    assert len(state["errors"]) == 1
    assert state["errors"][0]["code"] == "intake_not_ready"


def test_normalize_stage_status_and_question_does_not_extract_options_from_assistant_text() -> None:
    stage_key, status_key, question = normalize_stage_status_and_question(
        orchestration_status={"current_stage": "requirement_intake.collecting"},
        required_missing=["constraints", "scope"],
        activated_mode="requirement_intake",
        current_question={
            "field_key": "constraints",
            "field_label": "约束",
            "question_text": "请先确认约束",
            "options": [],
            "step_index": 1,
            "step_total": 2,
        },
        command="send_message",
        assistant_text=(
            "请优先确认约束：\n"
            "- 时间（上线节点）\n"
            "- 预算（总额上限）\n"
            "- 合规（必须满足标准）\n"
        ),
        intake_session_id="intake_1",
        normalize_stage_status_fn=lambda **_kwargs: ("requirement_intake", "collecting"),
    )

    assert stage_key == "requirement_intake"
    assert status_key == "collecting"
    assert isinstance(question, dict)
    assert question.get("field_key") == "constraints"
    assert question.get("options") == []


def test_normalize_stage_status_and_question_keeps_text_question_open_ended() -> None:
    stage_key, status_key, question = normalize_stage_status_and_question(
        orchestration_status={"current_stage": "requirement_intake.collecting"},
        required_missing=["parameters", "scope"],
        activated_mode="requirement_intake",
        current_question={
            "field_key": "parameters",
            "field_label": "关键参数",
            "question_text": "请先确认关键参数",
            "options": [],
            "step_index": 2,
            "step_total": 3,
        },
        command="send_message",
        assistant_text=(
            "高价值缺口：\n"
            "- 是否必须使用 OA 系统（版本）\n"
            "- 是否要求开启源许可（如 AGPL）\n"
            "- 是否禁用云服务（纯本地）\n"
        ),
        intake_session_id="intake_2",
        normalize_stage_status_fn=lambda **_kwargs: ("requirement_intake", "collecting"),
    )

    assert stage_key == "requirement_intake"
    assert status_key == "collecting"
    assert isinstance(question, dict)
    assert question.get("field_key") == "parameters"
    assert question.get("options") == []
