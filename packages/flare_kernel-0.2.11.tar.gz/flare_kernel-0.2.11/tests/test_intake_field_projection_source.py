from __future__ import annotations

from flare_kernel.router.intake.field_projection.source import (
    build_field_source_payload,
    extract_workspace_patch_value,
    resolve_field_evidence,
)


def test_extract_workspace_patch_value_uses_latest_match() -> None:
    payload = {
        "workspace_patches": [
            {"field_key": "budget", "field_value": "50万"},
            {"field_key": "budget", "field_value": "100万"},
        ]
    }
    assert extract_workspace_patch_value(payload, "budget") == "100万"


def test_resolve_field_evidence_uses_question_answer_when_matching() -> None:
    payload = {
        "question_answer": {"field_key": "quantity", "raw_value": "20台"},
        "message": "ignored",
    }
    assert resolve_field_evidence(payload, "quantity", "question_answer") == "20台"


def test_build_field_source_payload_omits_empty_evidence() -> None:
    assert build_field_source_payload(source_type="user_input", evidence_text="") == {"type": "user_input"}
