from __future__ import annotations

from flare_kernel.runtime.context.analysis_application import build_context_patch_from_analysis


def test_build_context_patch_from_analysis_appends_analysis_result() -> None:
    patch = build_context_patch_from_analysis(
        {
            "markdown": "# 需求分析",
            "document": {
                "analysis_schema_version": "v1",
                "template_id": "flare.requirement.rfx.v1",
            },
        }
    )

    results = patch.get("analysis_results")
    assert isinstance(results, list)
    assert len(results) == 1
    assert results[0]["version"] == 1
    assert results[0]["payload"]["markdown"] == "# 需求分析"
    assert results[0]["timestamp"]
