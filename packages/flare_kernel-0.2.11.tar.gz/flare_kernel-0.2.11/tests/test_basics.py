from __future__ import annotations

from flare_kernel import create_app
from flare_kernel.contracts import KernelRequest


def test_package_smoke_imports_create_app() -> None:
    assert callable(create_app)


def test_create_app_registers_kernel_routes() -> None:
    app = create_app()
    route_paths = {route.path for route in app.routes if hasattr(route, "path")}

    assert {
        "/kernel/health",
        "/kernel/run",
        "/kernel/stream",
        "/kernel/action",
        "/kernel/knowledge/ingest",
        "/kernel/knowledge/search",
        "/kernel/sourcing/search",
    }.issubset(route_paths)


def test_kernel_request_defaults_are_stable() -> None:
    request = KernelRequest()

    assert request.contract_version == "flare.v1"
    assert request.client_request_id is None
    assert request.tenant_id == "default"
    assert request.instance_id == "default"
    assert request.session_id is None
    assert request.last_turn_id is None
    assert request.command is None
    assert request.payload == {}
    assert request.context_refs == []
    assert request.retrieval_config == {}
    assert request.canvas_config == {}
    assert request.knowledge_refs == []
    assert request.project_id is None
    assert request.user_id is None
    assert request.intent_override is None
    assert request.manual_mode is None
    assert request.current_mode is None
    assert request.mode is None
    assert request.trace_id is None


def test_kernel_request_top_level_content_is_normalized_into_payload_message() -> None:
    request = KernelRequest(content="我要采购一批服务器")

    assert request.content == "我要采购一批服务器"
    assert request.payload["message"] == "我要采购一批服务器"


def test_kernel_request_does_not_override_existing_payload_message() -> None:
    request = KernelRequest(content="顶层内容", payload={"message": "真实消息"})

    assert request.payload["message"] == "真实消息"


def test_kernel_request_accepts_typed_intake_field_value() -> None:
    request = KernelRequest(
        command="submit_intake_answer",
        field_key="budget",
        question_id="q_budget_002",
        field_value={
            "kind": "range",
            "min": 200000,
            "max": 500000,
            "currency": "CNY",
        },
    )

    assert request.field_value is not None
    assert request.field_value.kind == "range"
