from __future__ import annotations

import json

from fastapi.testclient import TestClient

from flare_kernel import create_app
from flare_kernel.contracts import KernelRequest
from flare_kernel.router.kernel import _build_canonical_state


def _base_orchestration_status() -> dict:
    return {
        "current_stage": "requirement_intake.blocked",
        "intake_session_id": "intake_sess_contract_001",
        "intake_session_state": "clarification_in_progress",
        "intake_session_completed": False,
        "required_missing": ["budget"],
        "current_question": {
            "question_id": "q_budget_001",
            "field_key": "budget",
            "question_text": "预算范围是多少？",
        },
        "confirmed_updates": [],
        "next_actions": [
            {
                "action_key": "continue_collection",
                "label": "继续梳理",
                "status": "available",
                "target_mode": "requirement_intake",
            }
        ],
        "checkpoint": {
            "checkpoint_id": "ckpt_intake_sess_contract_001_question_budget",
            "intake_session_id": "intake_sess_contract_001",
            "checkpoint_type": "question_waiting",
            "checkpoint_state": "waiting_user",
            "current_stage": "requirement_intake.blocked",
            "question_key": "budget",
            "ready_for_submit": False,
            "decision_point_active": False,
            "updated_at": "2026-04-10T00:00:00+00:00",
        },
        "checkpoint_waiting_user": True,
        "intent_escalation_policy_source": "domain_pack",
    }


def _assert_external_work_item_contract(work_item: dict) -> None:
    assert isinstance(work_item, dict)
    assert str(work_item.get("id") or "").strip()
    assert str(work_item.get("type") or "").strip() in {"intake", "analysis", "retrieval"}
    assert str(work_item.get("status") or "").strip() in {
        "idle",
        "collecting",
        "converged",
        "running",
        "blocked",
        "completed",
    }
    blocking = work_item.get("blocking")
    assert isinstance(blocking, dict)
    assert isinstance(blocking.get("is_blocked"), bool)
    assert isinstance(blocking.get("reason"), str)
    next_actions = work_item.get("next_actions")
    assert isinstance(next_actions, list)
    checkpoint_ref = work_item.get("checkpoint_ref")
    assert isinstance(checkpoint_ref, dict)
    assert "intake_session_id" in checkpoint_ref
    assert "active_question_id" in checkpoint_ref


def test_external_work_item_contract_helper_accepts_analysis_and_retrieval_shapes() -> None:
    _assert_external_work_item_contract(
        {
            "id": "analysis::sess_contract",
            "type": "analysis",
            "status": "running",
            "blocking": {"is_blocked": False, "reason": ""},
            "next_actions": [{"action_key": "continue_analysis", "status": "available"}],
            "checkpoint_ref": {"intake_session_id": "sess_contract", "active_question_id": None},
        }
    )
    _assert_external_work_item_contract(
        {
            "id": "retrieval::sess_contract",
            "type": "retrieval",
            "status": "completed",
            "blocking": {"is_blocked": False, "reason": ""},
            "next_actions": [{"action_key": "open_field_retrieval", "status": "available"}],
            "checkpoint_ref": {"intake_session_id": "", "active_question_id": None},
        }
    )


def test_canonical_state_activates_requirement_flow_when_intake_fields_are_missing() -> None:
    req = KernelRequest(
        command="send_message",
        session_id="sess_contract",
        payload={"message": "我要购买一批服务器 测试开发用"},
    )
    canonical = _build_canonical_state(
        req=req,
        command="send_message",
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        mode_source="intent",
        orchestration_status=_base_orchestration_status(),
        runtime_snapshot={},
        assistant_text="给你一个普通建议回复",
        provider_status="ok",
    )

    assert canonical["primary_flow"]["mode"]["suggested"] == "requirement_intake"
    assert canonical["primary_flow"]["mode"]["activated"] == "auto"
    assert canonical["primary_flow"]["status"] == "idle"
    assert canonical["checkpoint"]["checkpoint_id"] == "ckpt_intake_sess_contract_001_question_budget"
    assert canonical["checkpoint"]["checkpoint_state"] == "waiting_user"
    assert canonical["checkpoint"]["workflow_id"] == "wf_intake_sess_contract_001"
    assert canonical["checkpoint"]["active_checkpoint_id"] == canonical["checkpoint"]["checkpoint_id"]
    assert canonical["checkpoint"]["version"] >= 1
    assert isinstance(canonical["checkpoint"]["checkpoints"], list)
    assert canonical["checkpoint"]["checkpoints"]
    assert isinstance(canonical["checkpoint"]["checkpoints"][0].get("child_tasks"), list)
    assert canonical["intent_state"]["procurement_relevance"] is True
    assert canonical["intent_state"]["escalation_target"] in {"qa_only", "intake_candidate"}
    assert canonical["intent_state"]["intent_escalation_policy_source"] == "domain_pack"
    assert canonical["intent_state"]["conversation_intent_state"] in {"business_intake_candidate", "clarification_in_progress"}
    assert canonical["question"] is None


def test_stream_emits_patch_event_with_single_final_frame() -> None:
    app = create_app()
    client = TestClient(app)

    with client.stream(
        "POST",
        "/kernel/stream",
        json={
            "contract_version": "flare.v1",
            "client_request_id": "req_stream_001",
            "session_id": "sess_stream_001",
            "command": "send_message",
            "payload": {"message": "我要购买一批服务器 测试开发用"},
        },
    ) as response:
        assert response.status_code == 200
        body = "".join(list(response.iter_text()))

    frames = [segment for segment in body.split("\n\n") if "event: patch_event" in segment]
    assert len(frames) >= 2

    parsed = []
    for frame in frames:
        payload_line = next((line for line in frame.splitlines() if line.startswith("data: ")), "")
        assert payload_line
        parsed.append(json.loads(payload_line.replace("data: ", "", 1)))

    assert parsed[0]["event_type"] == "ack"
    emitted_scopes = {
        str(scope)
        for event in parsed
        for scope in (event.get("patch_scope") or [])
    }
    assert "current_question" not in emitted_scopes
    assert "recommendation_summary" not in emitted_scopes
    finals = [item for item in parsed if item.get("event_type") == "final" and item.get("final") is True]
    assert len(finals) == 1
    assert all(item.get("client_request_id") == "req_stream_001" for item in parsed)
    final_payload = finals[0].get("payload") or {}
    assert "primary_flow" in final_payload
    assert "composer_ui" in final_payload
    assert "intent_state" in final_payload
    assert "assistant_reply" in final_payload
    assert isinstance(final_payload.get("primary_flow", {}).get("intake_session_id"), str)
    assert "checkpoint" in final_payload
    assert "checkpoint" in (finals[0].get("patch_scope") or [])
    assert "session" in (finals[0].get("patch_scope") or [])
    assert "analysis" in (finals[0].get("patch_scope") or [])
    assert "composer_ui" in (finals[0].get("patch_scope") or [])
    assert isinstance(final_payload.get("analysis"), dict)
    assert isinstance((final_payload.get("analysis") or {}).get("readiness"), dict)
    assert isinstance(((final_payload.get("analysis") or {}).get("readiness") or {}).get("blocking_fields"), list)
    assert isinstance((final_payload.get("analysis") or {}).get("assumptions"), list)
    assert isinstance(final_payload.get("observation"), dict)
    assert isinstance((final_payload.get("observation") or {}).get("active_fields"), list)
    assert isinstance((final_payload.get("observation") or {}).get("hypotheses"), list)
    planner = (final_payload.get("observation") or {}).get("planner")
    assert planner is None or isinstance(planner, dict)
    checkpoint = final_payload.get("checkpoint") or {}
    assert isinstance(checkpoint.get("workflow_id"), (str, type(None)))
    assert isinstance(checkpoint.get("active_checkpoint_id"), (str, type(None)))
    assert isinstance(checkpoint.get("checkpoints"), list)


def test_stream_without_session_id_authoritatively_creates_and_reuses_session_projection() -> None:
    app = create_app()
    client = TestClient(app)

    with client.stream(
        "POST",
        "/kernel/stream",
        json={
            "contract_version": "flare.v1",
            "client_request_id": "req_stream_autosession_001",
            "command": "send_message",
            "payload": {"message": "请先梳理需求"},
        },
    ) as response:
        assert response.status_code == 200
        body = "".join(list(response.iter_text()))

    ack_payload: dict | None = None
    complete_payload: dict | None = None
    patch_events: list[dict] = []
    for frame in [segment for segment in body.split("\n\n") if segment.strip()]:
        event_name = ""
        payload = {}
        for line in frame.splitlines():
            if line.startswith("event: "):
                event_name = line.replace("event: ", "", 1).strip()
            if line.startswith("data: "):
                payload = json.loads(line.replace("data: ", "", 1))
        if event_name == "ack":
            ack_payload = payload
        elif event_name == "complete":
            complete_payload = payload
        elif event_name == "patch_event":
            patch_events.append(payload)

    assert ack_payload is not None
    assert complete_payload is not None
    authoritative_session_id = str(ack_payload.get("session_id") or "").strip()
    assert authoritative_session_id
    assert authoritative_session_id != "default"
    assert complete_payload["session_id"] == authoritative_session_id
    assert patch_events
    assert all(event.get("session_id") == authoritative_session_id for event in patch_events)
    assert all((event.get("session") or {}).get("session_id") == authoritative_session_id for event in patch_events)


def test_stream_sequence_keeps_runtime_events_observational_before_final_canonical() -> None:
    app = create_app()
    client = TestClient(app)

    with client.stream(
        "POST",
        "/kernel/stream",
        json={
            "contract_version": "flare.v1",
            "client_request_id": "req_stream_seq_001",
            "session_id": "sess_stream_seq_001",
            "command": "send_message",
            "payload": {"message": "请先帮我梳理采购需求并列出缺失字段"},
        },
    ) as response:
        assert response.status_code == 200
        body = "".join(list(response.iter_text()))

    events: list[tuple[str, dict]] = []
    for frame in [segment for segment in body.split("\n\n") if segment.strip()]:
        lines = frame.splitlines()
        event_name = ""
        payload = {}
        for line in lines:
            if line.startswith("event: "):
                event_name = line.replace("event: ", "", 1).strip()
            if line.startswith("data: "):
                payload = json.loads(line.replace("data: ", "", 1))
        if event_name:
            events.append((event_name, payload))

    assert events
    event_names = [name for name, _payload in events]
    assert "orchestration_status" in event_names
    final_patch_indexes = [
        idx for idx, (name, payload) in enumerate(events)
        if name == "patch_event" and payload.get("event_type") == "final" and payload.get("final") is True
    ]
    assert len(final_patch_indexes) == 1
    final_index = final_patch_indexes[0]
    orchestration_indexes = [idx for idx, (name, _payload) in enumerate(events) if name == "orchestration_status"]
    assert orchestration_indexes[0] < final_index


def test_run_and_stream_expose_consistent_external_work_item_contract() -> None:
    app = create_app()
    client = TestClient(app)
    request_body = {
        "contract_version": "flare.v1",
        "client_request_id": "req_work_item_contract_001",
        "session_id": "sess_work_item_contract_001",
        "command": "activate_requirement_intake",
        "payload": {"message": "请先梳理采购需求并确认缺失字段"},
    }

    run_response = client.post("/kernel/run", json=request_body)
    assert run_response.status_code == 200
    run_json = run_response.json()
    run_status = (run_json.get("result") or {}).get("orchestration_status") or {}
    run_work_item = run_status.get("active_work_item")
    _assert_external_work_item_contract(run_work_item)

    with client.stream("POST", "/kernel/stream", json=request_body) as stream_response:
        assert stream_response.status_code == 200
        stream_body = "".join(list(stream_response.iter_text()))

    stream_events: list[tuple[str, dict]] = []
    for frame in [segment for segment in stream_body.split("\n\n") if segment.strip()]:
        event_name = ""
        payload = {}
        for line in frame.splitlines():
            if line.startswith("event: "):
                event_name = line.replace("event: ", "", 1).strip()
            if line.startswith("data: "):
                payload = json.loads(line.replace("data: ", "", 1))
        if event_name:
            stream_events.append((event_name, payload))

    stream_status_payloads = [
        payload
        for name, payload in stream_events
        if name == "orchestration_status" and isinstance(payload.get("active_work_item"), dict)
    ]
    assert stream_status_payloads
    stream_work_item = stream_status_payloads[0]["active_work_item"]
    _assert_external_work_item_contract(stream_work_item)

    assert set(run_work_item.keys()) == set(stream_work_item.keys())


def test_stream_emits_layered_events_for_control_phase_patch_and_text() -> None:
    app = create_app()
    client = TestClient(app)

    with client.stream(
        "POST",
        "/kernel/stream",
        json={
            "contract_version": "flare.v1",
            "client_request_id": "req_stream_layered_001",
            "session_id": "sess_stream_layered_001",
            "command": "send_message",
            "payload": {"message": "请先确认字段，再检索证据并给出建议"},
        },
    ) as response:
        assert response.status_code == 200
        body = "".join(list(response.iter_text()))

    events: list[tuple[str, dict]] = []
    for frame in [segment for segment in body.split("\n\n") if segment.strip()]:
        lines = frame.splitlines()
        event_name = ""
        payload = {}
        for line in lines:
            if line.startswith("event: "):
                event_name = line.replace("event: ", "", 1).strip()
            if line.startswith("data: "):
                payload = json.loads(line.replace("data: ", "", 1))
        if event_name:
            events.append((event_name, payload))

    assert events
    names = [name for name, _payload in events]
    assert "ack" in names
    assert "phase.start" in names
    assert "phase.update" in names
    assert "phase.end" in names
    assert "patch" in names
    assert "text.delta" in names
    assert "done" in names
    assert "complete" in names
    assert "patch_event" in names

    ack_index = names.index("ack")
    phase_index = names.index("phase.start")
    patch_index = names.index("patch")
    text_delta_index = names.index("text.delta")
    done_index = names.index("done")
    complete_index = names.index("complete")
    final_patch_index = next(
        idx for idx, (event_name, payload) in enumerate(events)
        if event_name == "patch_event" and payload.get("event_type") == "final" and payload.get("final") is True
    )

    assert ack_index < phase_index < done_index
    assert ack_index < patch_index < done_index
    assert ack_index < text_delta_index < done_index
    assert final_patch_index < done_index <= complete_index

    ack_payload = events[ack_index][1]
    assert ack_payload.get("trace_id")
    assert ack_payload.get("session_id") == "sess_stream_layered_001"
    assert ack_payload.get("request_id") == "req_stream_layered_001"
    assert ack_payload.get("mode")
    assert isinstance(ack_payload.get("ts"), int)

    done_payload = events[done_index][1]
    assert done_payload.get("trace_id") == ack_payload.get("trace_id")
    assert done_payload.get("session_id") == "sess_stream_layered_001"
    assert done_payload.get("request_id") == "req_stream_layered_001"
    assert done_payload.get("status") in {"done", "error"}
    assert isinstance(done_payload.get("ts"), int)

    patch_scopes = [
        str(payload.get("scope") or "")
        for event_name, payload in events
        if event_name == "patch" and isinstance(payload, dict)
    ]
    assert "confirmed_fields" in patch_scopes
    assert "missing_fields" in patch_scopes
    assert "analysis.sections" in patch_scopes


def test_generate_analysis_before_ready_returns_recoverable_validation_error() -> None:
    req = KernelRequest(
        command="generate_analysis",
        session_id="sess_analysis_gate",
        payload={"message": "生成分析"},
    )
    canonical = _build_canonical_state(
        req=req,
        command="generate_analysis",
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        mode_source="command",
        orchestration_status=_base_orchestration_status(),
        runtime_snapshot={},
        assistant_text="",
        provider_status="ok",
    )

    assert canonical["primary_flow"]["stage"] == "requirement_intake"
    assert canonical["primary_flow"]["intake_session_id"] == "intake_sess_contract_001"
    assert canonical["analysis"]["readiness"]["can_generate"] is False
    assert canonical["analysis"]["readiness"]["entry_level"] == "hidden"
    assert canonical["analysis"]["sections"] == []
    assert canonical["errors"]
    assert canonical["errors"][0]["type"] == "recoverable_validation_error"
    assert canonical["errors"][0]["fatal"] is False


def test_canonical_main_flow_does_not_drift_when_only_orchestration_meta_changes() -> None:
    req = KernelRequest(
        command="send_message",
        session_id="sess_meta_stable",
        payload={"message": "继续"},
    )
    base = _base_orchestration_status()
    changed = {
        **base,
        "decision_basis": [{"rule_id": "rule_meta_only"}],
        "degrade_reason": ["meta_update"],
        "blocking": {"is_blocked": True, "reason": "meta", "chooser_required": True},
        "workspace_updates": {"debug": "changed"},
    }

    canonical_a = _build_canonical_state(
        req=req,
        command="send_message",
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        mode_source="intent",
        orchestration_status=base,
        runtime_snapshot={},
        assistant_text="",
        provider_status="ok",
    )
    canonical_b = _build_canonical_state(
        req=req,
        command="send_message",
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        mode_source="intent",
        orchestration_status=changed,
        runtime_snapshot={},
        assistant_text="",
        provider_status="ok",
    )

    assert canonical_a["primary_flow"] == canonical_b["primary_flow"]
    assert canonical_a["question"] == canonical_b["question"]
    assert canonical_a["next_actions"] == canonical_b["next_actions"]


def test_generate_analysis_when_ready_does_not_raise_validation_error() -> None:
    req = KernelRequest(
        command="generate_analysis",
        session_id="sess_analysis_ready",
        payload={"message": "生成分析"},
    )
    orchestration_status = {
        "current_stage": "requirement_analysis.ready",
        "required_missing": [],
        "current_question": None,
        "confirmed_updates": [
            {"field_key": "category", "field_value": "基础设施"},
            {"field_key": "budget", "field_value": "预算500万"},
        ],
        "analysis_ready": True,
        "active_fields": ["category", "budget"],
        "hypotheses": [{"id": "h_budget_ready", "confidence": 0.9}],
        "planner": {"question_id": "q_ready_submit", "decision": "confirm_plan"},
        "next_actions": [],
    }
    canonical = _build_canonical_state(
        req=req,
        command="generate_analysis",
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        mode_source="command",
        orchestration_status=orchestration_status,
        runtime_snapshot={},
        assistant_text="这是分析正文",
        provider_status="ok",
    )

    assert canonical["analysis"]["readiness"]["can_generate"] is True
    assert canonical["errors"] == []
    assert canonical["analysis"]["sections"]
    assert canonical["observation"]["active_fields"] == ["category", "budget"]
    assert canonical["observation"]["hypotheses"][0]["id"] == "h_budget_ready"
    assert canonical["observation"]["planner"]["question_id"] == "q_ready_submit"


def test_generate_analysis_when_threshold_eligible_with_missing_includes_assumptions_and_blocking_fields() -> None:
    req = KernelRequest(
        command="generate_analysis",
        session_id="sess_analysis_threshold",
        payload={"message": "生成分析"},
    )
    orchestration_status = {
        "current_stage": "requirement_intake.blocked",
        "required_missing": ["category"],
        "current_question": {
            "question_id": "q_category_001",
            "field_key": "category",
            "question_text": "请先确认需求分类",
        },
        "confirmed_updates": [
            {"field_key": "budget", "field_value": "预算20万"},
            {"field_key": "quantity", "field_value": "30台"},
            {"field_key": "delivery_location", "field_value": "上海园区"},
            {"field_key": "storage_network_security", "field_value": "万兆网络与DDoS防护"},
        ],
        "analysis_entry_eligible": True,
        "required_coverage": 0.8,
        "total_coverage": 0.83,
        "analysis_entry_threshold": 0.8,
        "next_actions": [],
    }
    canonical = _build_canonical_state(
        req=req,
        command="generate_analysis",
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        mode_source="command",
        orchestration_status=orchestration_status,
        runtime_snapshot={},
        assistant_text="这是分析正文",
        provider_status="ok",
    )

    assert canonical["analysis"]["readiness"]["can_generate"] is True
    assert canonical["analysis"]["readiness"]["analysis_entry_eligible"] is True
    assert canonical["analysis"]["readiness"]["blocking_fields"] == ["category"]
    assert canonical["analysis"]["assumptions"]
    assert canonical["errors"] == []
    assert canonical["analysis"]["sections"]


def test_ready_for_submit_actions_keep_confirm_plan_available_before_analysis_generation() -> None:
    req = KernelRequest(
        command="send_message",
        session_id="sess_ready_submit_actions",
        payload={"message": "请先梳理需求，再让我决定下一步"},
    )
    orchestration_status = {
        "current_stage": "requirement_intake.ready_for_submit",
        "required_missing": [],
        "current_question": None,
        "confirmed_updates": [
            {"field_key": "category", "field_value": "基础设施"},
            {"field_key": "budget", "field_value": "预算500万"},
        ],
        "ready_for_submit": True,
        "analysis_ready": True,
        "next_actions": [
            {"action_key": "confirm_plan", "label": "开始需求分析", "status": "available", "command": "generate_analysis"},
            {"action_key": "continue_collection", "label": "继续补充需求", "status": "available"},
        ],
    }

    canonical = _build_canonical_state(
        req=req,
        command="send_message",
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        mode_source="intent",
        orchestration_status=orchestration_status,
        runtime_snapshot={},
        assistant_text="当前梳理已完成，请选择下一步。",
        provider_status="ok",
    )

    assert canonical["primary_flow"]["stage"] == "general_chat"
    assert canonical["primary_flow"]["status"] == "idle"
    assert canonical["analysis"]["readiness"]["can_generate"] is True
    assert canonical["analysis"]["readiness"]["entry_level"] in {"available", "recommended"}
    action_keys = [item.get("action_key") for item in canonical["next_actions"]]
    assert "confirm_plan" in action_keys
    assert "continue_collection" in action_keys
    confirm_plan = next(item for item in canonical["next_actions"] if item.get("action_key") == "confirm_plan")
    assert confirm_plan["command"] == "generate_analysis"


def test_field_retrieval_stays_sidecar_without_taking_over_primary_flow() -> None:
    req = KernelRequest(
        command="open_field_retrieval",
        session_id="sess_field_retrieval",
        payload={"field_key": "gpu"},
    )
    orchestration_status = {
        "current_stage": "requirement_intake.collecting",
        "required_missing": ["budget"],
        "current_question": {
            "question_id": "q_budget_001",
            "field_key": "budget",
            "question_text": "预算范围是多少？",
        },
        "confirmed_updates": [],
        "next_actions": [],
    }
    canonical = _build_canonical_state(
        req=req,
        command="open_field_retrieval",
        resolved_intent="intelligent_sourcing",
        resolved_mode="intelligent_sourcing",
        mode_source="command",
        orchestration_status=orchestration_status,
        runtime_snapshot={},
        assistant_text="",
        provider_status="ok",
    )

    assert canonical["primary_flow"]["stage"] == "requirement_intake"
    assert canonical["primary_flow"]["status"] == "collecting"
    assert canonical["primary_flow"]["mode"]["activated"] in {"requirement_intake", "sourcing"}
    assert canonical["question"] is not None
    assert canonical["capabilities"]["field_retrieval"]["active"] is True
