from __future__ import annotations

from flare_kernel.router.intake.canonicalization import (
    canonicalize_budget_value,
    canonicalize_payload_fields,
    parse_simple_chinese_number,
)


def test_parse_simple_chinese_number_handles_compound_value() -> None:
    assert parse_simple_chinese_number("三十五") == 35


def test_canonicalize_budget_value_handles_range() -> None:
    result = canonicalize_budget_value("预算10万到20万")
    assert isinstance(result, dict)
    assert result.get("status") == "confirmed"
    normalized = result.get("normalized_value") if isinstance(result.get("normalized_value"), dict) else {}
    assert normalized.get("kind") == "range"
    assert normalized.get("min") == 100000
    assert normalized.get("max") == 200000


def test_canonicalize_payload_fields_routes_unparsed_structured_fields_to_candidates() -> None:
    payload = {
        "fields": {"delivery_time": "尽快"},
        "field_sources": {"delivery_time": "user_input"},
        "required_fields": ["delivery_time"],
        "field_semantics": {"delivery_time": {"value_type": "time_window"}},
    }
    canonicalized = canonicalize_payload_fields(payload)
    assert canonicalized.get("fields") == {}
    field_candidates = canonicalized.get("field_candidates") if isinstance(canonicalized.get("field_candidates"), dict) else {}
    entity = field_candidates.get("delivery_time") if isinstance(field_candidates, dict) else None
    assert isinstance(entity, dict)
    assert entity.get("status") == "unparsed"
