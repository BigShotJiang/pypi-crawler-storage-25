from __future__ import annotations

from flare_kernel.router.intake.guided.status import build_guided_session_status


def test_build_guided_session_status_sets_summary_ready() -> None:
    status = build_guided_session_status(
        resolved_mode="requirement_intake",
        current_stage="requirement_intake.ready_for_submit",
        command="send_message",
        current_question=None,
        required_fields=["category", "budget"],
        required_missing=[],
        confirmed_updates=[{"field_key": "category", "field_value": "服务器"}],
        next_actions=[{"action_key": "confirm_plan"}],
        active_collecting=False,
        ready_for_submit=True,
        decision_point_active=False,
        field_label_map={"category": "类别"},
    )
    assert status["state"] == "summary_ready"
    assert status["summary"]["ready"] is True
    assert "类别：服务器" in status["summary"]["text"]
