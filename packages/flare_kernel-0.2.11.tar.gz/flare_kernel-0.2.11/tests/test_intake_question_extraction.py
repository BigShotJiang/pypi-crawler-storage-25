from __future__ import annotations

from flare_kernel.runtime.reasoning.intake.question.extraction import extract_next_question_plan


def test_extract_next_question_plan_uses_explicit_calibration_question() -> None:
    result = extract_next_question_plan(
        result_text=(
            "5. 校准问题\n"
            "为精准匹配硬件配置与供应商策略，这批服务器的主要使用场景是什么？"
            "（例如：AI模型训练、核心数据库、Web应用托管、还是办公/通用业务？）"
            "明确后我将为您输出对应的配置建议清单与采购策略。"
        ),
        current_planned_question={
            "question_key": "use_case",
            "target_information_gap": "use_case",
            "question_kind": "field",
        },
    )

    assert result["source"] == "result_extraction"
    assert result["question_key"] == "use_case"
    assert result["question_text"] == (
        "为精准匹配硬件配置与供应商策略，这批服务器的主要使用场景是什么？"
        "（例如：AI模型训练、核心数据库、Web应用托管、还是办公/通用业务？）"
    )
    assert [item["label"] for item in result["options"]] == [
        "AI模型训练",
        "核心数据库",
        "Web应用托管",
        "办公/通用业务",
    ]


def test_extract_next_question_plan_does_not_invent_question_from_gap_label() -> None:
    result = extract_next_question_plan(
        result_text="关键缺口：\n1. 使用场景：待确认\n2. 数量：待确认",
        current_planned_question={},
        candidate_information_gaps=[{"key": "use_case", "label": "使用场景"}],
    )

    assert result == {}
