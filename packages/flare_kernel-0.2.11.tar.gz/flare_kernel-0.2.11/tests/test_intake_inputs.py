from __future__ import annotations

from flare_kernel.router.intake.inputs import (
    extract_mode_event_payload,
    extract_orchestration_status_inputs,
)


def test_extract_mode_event_payload_uses_latest_matching_event() -> None:
    payload = extract_mode_event_payload(
        {
            "mode_events": [
                {"event_type": "next_actions", "payload": {"required_missing": ["budget"]}},
                {"event_type": "next_actions", "payload": {"required_missing": ["quantity"]}},
            ]
        },
        "next_actions",
    )
    assert payload == {"required_missing": ["quantity"]}


def test_extract_orchestration_status_inputs_falls_back_to_checkpoint_question() -> None:
    extracted = extract_orchestration_status_inputs(
        {
            "payload": {
                "intake_checkpoint": {
                    "payload": {
                        "current_question": {"field_key": "budget", "question_text": "预算？"},
                        "required_missing": ["budget"],
                    }
                }
            },
            "mode_events": [
                {"event_type": "next_actions", "payload": {"required_missing": []}},
                {"event_type": "field_progress", "payload": {"fields": {"category": "服务器"}}},
            ],
        }
    )
    assert extracted["current_question"]["field_key"] == "budget"
    assert extracted["required_missing"] == []
    assert extracted["fields"] == {"category": "服务器"}


def test_extract_orchestration_status_inputs_ignores_legacy_checkpoint_question() -> None:
    extracted = extract_orchestration_status_inputs(
        {
            "payload": {
                "intake_checkpoint": {
                    "payload": {
                        "current_question": {
                            "field_key": "project_name",
                            "question_text": "请补充字段：项目名称",
                        },
                        "required_missing": ["project_name"],
                    }
                }
            },
            "mode_events": [
                {"event_type": "next_actions", "payload": {"required_missing": []}},
                {"event_type": "field_progress", "payload": {}},
            ],
        }
    )

    assert extracted["current_question"] is None


def test_extract_orchestration_status_inputs_prefers_event_payload_entities() -> None:
    extracted = extract_orchestration_status_inputs(
        {
            "payload": {"field_entities": {"budget": {"normalized": "20万以内"}}},
            "mode_events": [
                {
                    "event_type": "field_progress",
                    "payload": {"field_entities": {"budget": {"normalized": "10万以内"}}},
                }
            ],
        }
    )
    assert extracted["field_entities"]["budget"]["normalized"] == "10万以内"


def test_extract_orchestration_status_inputs_merges_runtime_and_progress_fields() -> None:
    extracted = extract_orchestration_status_inputs(
        {
            "payload": {
                "fields": {
                    "scope": "总部一期",
                    "constraints": "预算80万",
                }
            },
            "mode_events": [
                {
                    "event_type": "field_progress",
                    "payload": {
                        "fields": {
                            "parameters": "GPU服务器10台",
                            "constraints": "预算上限80万，3个月上线",
                        }
                    },
                }
            ],
        }
    )
    assert extracted["fields"] == {
        "scope": "总部一期",
        "constraints": "预算上限80万，3个月上线",
        "parameters": "GPU服务器10台",
    }
