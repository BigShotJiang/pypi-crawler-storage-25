from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

_TESTS_DIR = Path(__file__).resolve().parent
_KERNEL_SRC = _TESTS_DIR.parents[1] / "src"
if str(_KERNEL_SRC) not in sys.path:
    sys.path.insert(0, str(_KERNEL_SRC))

from flare_kernel.runtime.llm.contracts import LLMProviderConfig
from flare_kernel.runtime.llm.dashscope_streaming_provider import call_dashscope_stream


class MockStreamResponse:
    status_code = 200

    async def __aenter__(self) -> "MockStreamResponse":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return None

    async def aiter_lines(self):
        chunks = [
            {"choices": [{"delta": {"content": "hello"}}]},
            {"choices": [{"delta": {"content": " world"}}]},
        ]
        for chunk in chunks:
            yield f"data: {json.dumps(chunk)}"
        yield "data: [DONE]"


class MockAsyncClient:
    def __init__(self, timeout: float) -> None:
        self.timeout = timeout

    async def __aenter__(self) -> "MockAsyncClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return None

    def stream(self, method: str, url: str, json: dict, headers: dict):
        return MockStreamResponse()


@pytest.mark.asyncio
async def test_call_dashscope_stream_projects_sse_chunks(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(
        sys.modules,
        "httpx",
        SimpleNamespace(AsyncClient=MockAsyncClient, HTTPError=Exception),
    )
    config = LLMProviderConfig(
        backend="dashscope",
        dashscope_api_key="test-key",
        dashscope_base_url="https://example.test",
        dashscope_model="qwen-plus",
        timeout_seconds=3.0,
    )

    events = [
        event
        async for event in call_dashscope_stream(
            config=config,
            prompt="hello",
            model="qwen-plus",
            temperature=0.2,
            trace_id="t-stream-native",
            session_id="s-stream-native",
            intent="default",
        )
    ]

    assert [event.event_type for event in events] == ["provider.delta", "provider.delta", "provider.done"]
    assert [event.delta for event in events[:-1]] == ["hello", " world"]
    assert events[-1].completion is not None
    assert events[-1].completion.content == "hello world"
    assert events[-1].details["streaming"] is True
