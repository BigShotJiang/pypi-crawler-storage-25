from __future__ import annotations

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.canonical.context.analysis import (
    build_canonical_state_context_output,
)


def test_build_canonical_state_context_output_projects_analysis_and_checkpoint_state() -> None:
    output = build_canonical_state_context_output(
        req=KernelRequest(payload={"message": "hello"}, session_id="session-2"),
        command="generate_analysis",
        orchestration_status={
            "intake_understanding": {"summary": "ok"},
            "next_actions": [{"action_key": "generate_analysis", "label": "生成分析"}],
        },
        assistant_text="分析结果",
        context_inputs={
            "analysis_ready": True,
            "clarification_recommended": False,
            "draft_seeded": True,
            "fields": {"budget": "100万"},
            "field_entities": {"budget": {"confirmed": True}},
            "intake_candidate": True,
            "intent_type": "procurement_requirement_intake",
            "missing_key_fields": [],
            "procurement_relevance": True,
            "recommended_next_step": "generate_analysis",
            "required_missing": [],
            "question_decision": {"selected_field_key": "budget"},
            "escalation_target": "intake_candidate",
        },
        context_session={
            "activated_mode": "requirement_intake",
            "conversation_intent_state": "analysis_running",
            "current_question": None,
            "explicit_activation": True,
            "intake_session_completed": False,
            "intake_session_id": "intake-2",
            "intake_session_state": "analysis_running",
            "resolved_intent_escalation_policy": {},
            "resolved_intent_escalation_policy_source": "default",
            "session_intent_stage": "analysis_running",
            "stage_key": "analysis_running",
            "status_key": "running",
            "suggested_mode": "requirement_intake",
            "current_question": None,
        },
        map_external_mode_fn=lambda mode: mode,
    )

    assert output["can_generate"] is True
    assert output["checkpoint"]["session_id"] == "session-2"
    assert output["next_actions"][0]["intake_session_id"] == "intake-2"
    assert output["question_decision"] == {"selected_field_key": "budget"}
    assert output["analysis_entry_eligible"] is True
