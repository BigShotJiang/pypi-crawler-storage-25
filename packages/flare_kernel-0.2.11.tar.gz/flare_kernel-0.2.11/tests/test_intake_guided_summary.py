from __future__ import annotations

from flare_kernel.router.intake.guided.summary import build_guided_session_summary


def test_build_guided_session_summary_uses_field_labels() -> None:
    summary = build_guided_session_summary(
        confirmed_updates=[{"field_key": "category", "field_value": "服务器"}],
        field_label_map={"category": "类别"},
    )
    assert "类别：服务器" in summary
