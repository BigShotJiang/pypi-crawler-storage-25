from __future__ import annotations

from flare_kernel.router.intake.numeric import (
    apply_amount_unit,
    detect_numeric_precision,
    format_cny_amount,
    parse_numeric_token,
    parse_simple_chinese_number,
)


def test_parse_simple_chinese_number_handles_compound_value() -> None:
    assert parse_simple_chinese_number("三十五") == 35


def test_parse_numeric_token_parses_grouped_decimal() -> None:
    assert parse_numeric_token("1,234.5") == 1234.5


def test_detect_numeric_precision_uses_bound_hints() -> None:
    assert detect_numeric_precision("预算不超过10万") == "upper_bound"


def test_amount_helpers_round_and_format_values() -> None:
    assert apply_amount_unit(10, "万") == 100000
    assert format_cny_amount(200000) == "20万"
