from __future__ import annotations

from flare_kernel.router.intake.field_scope import resolve_intake_allowed_fields


def test_resolve_intake_allowed_fields_merges_definitions_and_lists() -> None:
    fields = resolve_intake_allowed_fields(
        {
            "field_definitions": [{"key": "budget"}, {"key": "quantity"}],
            "required_fields": ["budget", "category"],
            "recommended_fields": ["delivery_time"],
            "optional_fields": ["constraints"],
            "fields": {"region": "华东"},
        }
    )
    assert fields == ["budget", "quantity", "category", "delivery_time", "constraints", "region"]


def test_resolve_intake_allowed_fields_returns_empty_for_invalid_payload() -> None:
    assert resolve_intake_allowed_fields({}) == []
