from __future__ import annotations

from flare_kernel.router.intake.guided.open_fields import build_open_fields


def test_build_open_fields_marks_current_field() -> None:
    result = build_open_fields(
        required_missing=["budget", "quantity"],
        current_question={"field_key": "budget"},
    )
    assert result == [
        {"field_key": "budget", "priority": "required", "is_current": True},
        {"field_key": "quantity", "priority": "required", "is_current": False},
    ]


def test_build_open_fields_prioritizes_framework_and_defers_detail_fields() -> None:
    result = build_open_fields(
        required_missing=["gpu_memory", "constraints", "scope"],
        current_question=None,
        intake_strategy={
            "framework_fields": ("scope", "constraints"),
            "detail_deferral": True,
            "detail_field_keywords": ("gpu", "memory"),
        },
    )
    assert [item["field_key"] for item in result] == ["constraints", "scope", "gpu_memory"]


def test_build_open_fields_projects_backend_field_labels() -> None:
    result = build_open_fields(
        required_missing=["delivery_location"],
        current_question={"field_key": "delivery_location"},
        field_label_map={"delivery_location": "交付地点"},
    )

    assert result == [
        {
            "field_key": "delivery_location",
            "priority": "required",
            "is_current": True,
            "label": "交付地点",
            "field_label": "交付地点",
        }
    ]
