from __future__ import annotations

from flare_kernel.router.intake.answer import normalize_field_value_payload


def test_normalize_field_value_payload_for_multi_choice() -> None:
    value, display = normalize_field_value_payload(
        {"kind": "multi_choice", "values": ["A", "B"], "display_value": ""}
    )
    assert value == "A、B"
    assert display == "A、B"


def test_normalize_field_value_payload_for_candidate_ref() -> None:
    value, display = normalize_field_value_payload(
        {"kind": "candidate_ref", "candidate_id": "cand_1", "display_value": "候选 1"}
    )
    assert value == "cand_1"
    assert display == "候选 1"


def test_normalize_field_value_payload_for_plain_text_fallback() -> None:
    value, display = normalize_field_value_payload("预算 50 万")
    assert value == "预算 50 万"
    assert display == "预算 50 万"
