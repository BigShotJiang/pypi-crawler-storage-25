from __future__ import annotations

from flare_kernel.router.intake.extraction.merge import (
    merge_inferred_requirements,
    merge_into_confirmed_fields,
    merge_supplementary_fields,
    normalize_extracted_field_values,
)


def test_normalize_extracted_field_values_keeps_only_non_empty_fields() -> None:
    normalized = normalize_extracted_field_values(
        {
            "fields": {"goal": " x ", "budget": " "},
            "supplementary_fields": {"a": 1},
            "inferred_requirements": ["one", " ", "two"],
        }
    )
    assert normalized["fields"] == {"goal": "x"}
    assert normalized["supplementary_fields"] == {"a": 1}
    assert normalized["inferred_requirements"] == ["one", "two"]


def test_merge_helpers_merge_without_overwriting_confirmed_values() -> None:
    merged_fields, sources = merge_into_confirmed_fields(
        {"goal": "existing"},
        {"fields": {"goal": "new", "budget": "预算10万"}},
    )
    assert merged_fields == {"goal": "existing", "budget": "预算10万"}
    assert sources == {"budget": "message_extraction"}

    supplementary = merge_supplementary_fields({"tags": ["a"]}, {"tags": ["a", "b"]})
    assert supplementary == {"tags": ["a", "b"]}

    inferred = merge_inferred_requirements(["one"], ["one", "two"])
    assert inferred == ["one", "two"]
