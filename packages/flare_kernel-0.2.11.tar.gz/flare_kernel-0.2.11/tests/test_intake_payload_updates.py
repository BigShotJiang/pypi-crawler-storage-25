from __future__ import annotations

from flare_kernel.router.intake.payload_updates import (
    apply_question_answer_payload,
    apply_workspace_patch_payload,
    extract_quoted_terms,
    normalize_workspace_patches,
)


def test_extract_quoted_terms_keeps_unique_terms() -> None:
    terms = extract_quoted_terms('请确认"预算"和「交付时间」以及"预算"')
    assert terms == ["预算", "交付时间"]


def test_apply_question_answer_payload_updates_fields_and_sources() -> None:
    payload = {
        "question_answer": {"field_key": "budget", "raw_value": "预算20万"},
        "required_missing": ["budget", "quantity"],
    }
    updated = apply_question_answer_payload(payload)
    assert updated["fields"]["budget"] == "预算20万"
    assert updated["field_sources"]["budget"] == "question_answer"
    assert updated["required_missing"] == ["quantity"]


def test_apply_question_answer_payload_preserves_dynamic_calibration_gap() -> None:
    payload = {
        "question_answer": {
            "field_key": "use_case",
            "question_key": "placement_area",
            "target_information_gap": "placement_area",
            "field_value": "展厅接待洽谈区",
        },
        "required_missing": ["use_case", "budget"],
    }
    updated = apply_question_answer_payload(payload)
    assert updated["fields"]["use_case"] == "展厅接待洽谈区"
    assert updated["supplementary_fields"]["placement_area"] == "展厅接待洽谈区"
    assert updated["required_missing"] == ["budget"]


def test_apply_question_answer_payload_updates_intake_field_updates() -> None:
    payload = {
        "intake_field_updates": [
            {"field_key": "budget", "field_value": "预算20万"},
            {"field_key": "quantity", "field_value": "10台"},
        ],
        "required_missing": ["budget", "quantity", "deadline"],
    }
    updated = apply_question_answer_payload(payload)
    assert updated["fields"]["budget"] == "预算20万"
    assert updated["fields"]["quantity"] == "10台"
    assert updated["field_sources"]["budget"] == "question_answer"
    assert updated["field_sources"]["quantity"] == "question_answer"
    assert updated["required_missing"] == ["deadline"]


def test_apply_question_answer_payload_keeps_legacy_batch_answers_compatible() -> None:
    payload = {
        "question_answers": [
            {"field_key": "budget", "field_value": "预算20万"},
        ],
        "required_missing": ["budget", "quantity"],
    }
    updated = apply_question_answer_payload(payload)
    assert updated["fields"]["budget"] == "预算20万"
    assert updated["field_sources"]["budget"] == "question_answer"
    assert updated["required_missing"] == ["quantity"]


def test_normalize_workspace_patches_collects_single_and_list() -> None:
    payload = {
        "workspace_patch": {"field_key": "goal", "field_value": "上线"},
        "workspace_patches": [{"field_key": "quantity", "field_value": "10台"}, "invalid"],
    }
    patches = normalize_workspace_patches(payload)
    assert patches == [
        {"field_key": "goal", "field_value": "上线"},
        {"field_key": "quantity", "field_value": "10台"},
    ]


def test_apply_workspace_patch_payload_merges_and_removes_required_missing() -> None:
    payload = {
        "workspace_patches": [
            {"field_key": "goal", "field_value": "上线"},
            {"field_key": "budget", "field_value": "预算30万"},
        ],
        "required_missing": ["goal", "budget", "quantity"],
    }
    updated = apply_workspace_patch_payload(payload)
    assert updated["fields"]["goal"] == "上线"
    assert updated["fields"]["budget"] == "预算30万"
    assert updated["field_sources"]["goal"] == "workspace_patch"
    assert updated["required_missing"] == ["quantity"]
