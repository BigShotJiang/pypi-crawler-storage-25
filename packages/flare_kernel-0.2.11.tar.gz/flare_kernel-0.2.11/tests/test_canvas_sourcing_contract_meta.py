from __future__ import annotations

from flare_kernel.runtime.orchestration.mode.orchestration import _build_intelligent_sourcing_events
from flare_kernel.runtime.orchestration.canvas_sourcing_contract import (
    CANVAS_SOURCING_CONTRACT_VERSION,
    CANVAS_SOURCING_SCHEMA_VERSION,
)
from flare_kernel.runtime.orchestration.sourcing.event_payloads import normalize_candidate_rows


def test_intelligent_sourcing_events_include_contract_meta() -> None:
    events, _next_actions, _mode_state = _build_intelligent_sourcing_events(
        mode_key="intelligent_sourcing",
        session_id="s-1",
        payload={
            "sourcing_confirmed": True,
            "project_id": "p-1",
            "candidates": [{"supplier_id": "c-1", "supplier_name": "A Supplier", "score": 0.95}],
            "shortlist": [{"supplier_id": "c-1", "supplier_name": "A Supplier", "score": 0.95}],
            "report": {"sections": [{"title": "summary", "content": "ok"}]},
        },
    )

    checked_event_types = {
        "sourcing_candidates",
        "risk_summary",
        "shortlist_updated",
        "evaluation_report_ready",
    }

    for event in events:
        event_type = event.get("event_type")
        if event_type not in checked_event_types:
            continue
        payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
        assert payload.get("contract_version") == CANVAS_SOURCING_CONTRACT_VERSION
        assert payload.get("schema_version") == CANVAS_SOURCING_SCHEMA_VERSION

    canvas_event = next(item for item in events if item.get("event_type") == "canvas_state")
    canvas_state = canvas_event["payload"]["canvas_state"]
    assert [action["key"] for action in canvas_state["toolbar_actions"]] == [
        "export_markdown",
        "fullscreen",
    ]
    assert canvas_state["workspace_capabilities"]["toolbar_actions"] == canvas_state["toolbar_actions"]


def test_intelligent_sourcing_preview_includes_parameter_draft_and_confirm_payload() -> None:
    events, next_actions, mode_state = _build_intelligent_sourcing_events(
        mode_key="intelligent_sourcing",
        session_id="s-2",
        payload={
            "project_id": "p-2",
            "base_fields": {"category": "活动执行", "region": "上海"},
            "provider_config": {"source_priority": ["instance_db", "local"]},
        },
    )

    assert mode_state == "collecting"
    next_actions_event = next(item for item in events if item.get("event_type") == "next_actions")
    payload = next_actions_event["payload"]
    assert payload["sourcing_parameters"] == {"category": "活动执行", "region": "上海"}
    assert payload["sourcing_query_draft"] == "活动执行 上海"
    assert payload["supplier_profile_draft"]["field_count"] == 2
    assert payload["data_source_priority"] == ["instance_db", "local"]
    assert payload["confirm_action"]["action_key"] == "confirm_sourcing"
    assert payload["confirm_action"]["payload"]["sourcing_confirmed"] is True
    assert next_actions[0]["payload"]["sourcing_query_draft"] == "活动执行 上海"


def test_intelligent_sourcing_preview_uses_session_context_confirmed_fields() -> None:
    events, next_actions, mode_state = _build_intelligent_sourcing_events(
        mode_key="intelligent_sourcing",
        session_id="s-context",
        payload={
            "project_id": "p-context",
            "session_context": {
                "confirmed_fields": {
                    "category": "数据库服务器",
                    "budget": "80万",
                }
            },
        },
    )

    assert mode_state == "collecting"
    next_actions_event = next(item for item in events if item.get("event_type") == "next_actions")
    payload = next_actions_event["payload"]
    assert payload["sourcing_parameters"] == {"category": "数据库服务器", "budget": "80万"}
    assert payload["sourcing_query_draft"] == "数据库服务器 80万"
    assert payload["supplier_profile_draft"]["source"] == "session_context"
    assert next_actions[0]["payload"]["sourcing_parameters"]["category"] == "数据库服务器"


def test_confirmed_sourcing_events_preserve_candidate_explainability() -> None:
    events, _next_actions, mode_state = _build_intelligent_sourcing_events(
        mode_key="intelligent_sourcing",
        session_id="s-explain",
        payload={
            "sourcing_confirmed": True,
            "candidates": [
                {
                    "supplier_id": "c-1",
                    "supplier_name": "A Supplier",
                    "score": 0.95,
                    "source_type": "web",
                    "canonical_url": "https://supplier.test/a",
                    "source_domain": "supplier.test",
                    "confidence": "82 (high)",
                    "confidence_detail": {"score": 82, "level": "high"},
                    "rerank_explain": {"alignment": 0.8},
                    "match_reasons": ["命中服务能力"],
                    "evidence_refs": [
                        {
                            "source": "web",
                            "url": "https://supplier.test/a",
                            "title": "A Supplier",
                            "snippet": "服务能力说明",
                        }
                    ],
                }
            ],
        },
    )

    assert mode_state == "report_ready"
    candidates_event = next(item for item in events if item.get("event_type") == "sourcing_candidates")
    row = candidates_event["payload"]["candidates"][0]
    assert row["source_type"] == "web"
    assert row["canonical_url"] == "https://supplier.test/a"
    assert row["source_domain"] == "supplier.test"
    assert row["confidence_detail"]["score"] == 82
    assert row["rerank_explain"]["alignment"] == 0.8
    assert row["match_reasons"] == ["命中服务能力"]
    assert row["evidence_refs"][0]["url"] == "https://supplier.test/a"


def test_confirmed_sourcing_events_keep_handoff_draft() -> None:
    events, next_actions, mode_state = _build_intelligent_sourcing_events(
        mode_key="intelligent_sourcing",
        session_id="s-3",
        payload={
            "sourcing_confirmed": True,
            "sourcing_parameters": {"category": "活动执行", "region": "上海"},
            "sourcing_query_draft": "活动执行 上海",
            "supplier_profile_draft": {"fields": {"category": "活动执行", "region": "上海"}, "field_count": 2},
            "criteria": [{"key": "case", "label": "案例"}],
            "data_source_priority": ["instance_db", "local", "web"],
            "candidates": [{"supplier_id": "c-1", "supplier_name": "A Supplier", "score": 0.95}],
            "source_breakdown": {"instance_db": 1, "local": 0, "mcp": 0, "web": 0},
            "retrieval_batch": "run-sourcing-1",
            "selected_source": "instance_db",
            "source_priority": [{"source": "instance_db", "enabled": True}],
            "fallbacks": ["local", "web"],
            "provider_health": [{"source": "instance_db", "status": "ok", "enabled": True}],
            "provider_trace": [{"source": "instance_db", "status": "completed", "hit_count": 1}],
        },
    )

    assert mode_state == "report_ready"
    candidates_event = next(item for item in events if item.get("event_type") == "sourcing_candidates")
    payload = candidates_event["payload"]
    assert payload["base_ready_for_matching"] is True
    assert payload["mode_state"] == "matching"
    assert payload["sourcing_query_draft"] == "活动执行 上海"
    assert payload["supplier_profile_draft"]["field_count"] == 2
    assert payload["criteria"] == [{"key": "case", "label": "案例"}]
    assert payload["data_source_priority"] == ["instance_db", "local", "web"]
    assert next_actions[0]["action_key"] == "generate_analysis"
    assert next_actions[0]["target_mode"] == "analysis_mode"
    assert next_actions[0]["command"] == "generate_analysis"
    assert next_actions[0]["payload"]["analysis_route"]["analysis_type"] == "sourcing"
    profile_input = next_actions[0]["payload"]["supplier_profile_input"]
    assert profile_input["source"] == "sourcing_candidates"
    assert profile_input["candidate_count"] == 1
    assert profile_input["sourcing_parameters"] == {"category": "活动执行", "region": "上海"}
    assert profile_input["sourcing_trace"]["source_meta"]["source_breakdown"]["instance_db"] == 1
    assert profile_input["sourcing_trace"]["source_meta"]["provider_health"][0]["source"] == "instance_db"
    assert profile_input["sourcing_trace"]["provider_trace"][0]["source"] == "instance_db"
    assert next_actions[0]["payload"]["sourcing_trace"]["selected_source"] == "instance_db"
    assert next_actions[0]["payload"]["sourcing_trace"]["source_priority"][0]["source"] == "instance_db"
    next_actions_event = next(item for item in events if item.get("event_type") == "next_actions")
    assert next_actions_event["payload"]["next_actions"][0]["action_key"] == "generate_analysis"


def test_confirmed_sourcing_events_project_execution_observations() -> None:
    events, _next_actions, mode_state = _build_intelligent_sourcing_events(
        mode_key="intelligent_sourcing",
        session_id="s-observe",
        payload={
            "sourcing_confirmed": True,
            "candidates": [{"supplier_id": "c-1", "supplier_name": "A Supplier", "score": 0.95}],
            "shortlist": [{"supplier_id": "c-1", "supplier_name": "A Supplier", "score": 0.95}],
            "source_breakdown": {"instance_db": 1, "local": 0, "mcp": 0, "web": 0},
            "sourcing_search": {
                "final_status": "completed",
                "returned_count": 1,
                "observations": [
                    {"stage_id": "prepare_context", "status": "completed", "hit_count": 0},
                    {"stage_id": "search_instance_db", "status": "completed", "source": "instance_db", "hit_count": 1},
                    {"stage_id": "finalize", "status": "completed", "hit_count": 1, "terminal": True},
                ],
            },
        },
    )

    assert mode_state == "report_ready"
    candidates_event = next(item for item in events if item.get("event_type") == "sourcing_candidates")
    source_meta = candidates_event["payload"]["source_meta"]
    assert source_meta["final_status"] == "completed"
    assert source_meta["returned_count"] == 1
    assert source_meta["current_stage"] == "finalize"
    assert source_meta["observations"][1]["stage_id"] == "search_instance_db"
    assert source_meta["observations"][1]["hit_count"] == 1


def test_sourcing_rows_mark_document_hits_as_reference_role() -> None:
    rows = normalize_candidate_rows([
        {
            "id": "doc-1",
            "title": "采购需求文档.pdf",
            "source_type": "local",
            "snippet": "预算与需求说明",
        },
        {
            "supplier_id": "supplier-1",
            "supplier_name": "供应商 A",
            "source_type": "instance_db",
        },
    ])

    assert rows[0]["result_role"] == "reference"
    assert rows[0]["source_title"] == "采购需求文档.pdf"
    assert rows[1]["result_role"] == "candidate"
    assert rows[1]["supplier_name"] == "供应商 A"


def test_reference_only_sourcing_rows_do_not_force_analysis_action() -> None:
    events, next_actions, mode_state = _build_intelligent_sourcing_events(
        mode_key="intelligent_sourcing",
        session_id="s-reference-only",
        payload={
            "sourcing_confirmed": True,
            "candidates": [
                {
                    "id": "doc-1",
                    "title": "采购需求文档.pdf",
                    "source_type": "local",
                    "snippet": "预算与交付要求",
                }
            ],
        },
    )

    candidates_event = next(item for item in events if item.get("event_type") == "sourcing_candidates")
    canvas_event = next(item for item in events if item.get("event_type") == "canvas_state")
    assert mode_state == "report_ready"
    assert candidates_event["payload"]["candidate_count"] == 0
    assert candidates_event["payload"]["candidates"][0]["result_role"] == "reference"
    assert canvas_event["payload"]["ui_signal"]["active_tab"] == "evidence"
    assert next_actions == []
    assert not any(item.get("event_type") == "next_actions" for item in events)


def test_confirmed_sourcing_without_candidates_does_not_force_analysis_path() -> None:
    events, next_actions, mode_state = _build_intelligent_sourcing_events(
        mode_key="intelligent_sourcing",
        session_id="s-empty",
        payload={
            "sourcing_confirmed": True,
            "sourcing_parameters": {"category": "活动执行"},
            "sourcing_query_draft": "活动执行",
            "candidates": [],
            "shortlist": [],
        },
    )

    assert mode_state == "report_ready"
    canvas_event = next(item for item in events if item.get("event_type") == "canvas_state")
    assert canvas_event["payload"]["ui_signal"]["active_tab"] == "evidence"
    assert next_actions == []
    assert not any(item.get("event_type") == "next_actions" for item in events)
