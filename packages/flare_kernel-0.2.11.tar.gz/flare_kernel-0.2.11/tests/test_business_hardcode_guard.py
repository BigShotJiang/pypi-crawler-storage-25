from __future__ import annotations

from pathlib import Path


def _read(relative_path: str) -> str:
    return Path(relative_path).read_text(encoding="utf-8")


def test_kernel_domain_loader_has_no_legacy_procurement_fallback_switch() -> None:
    source = _read("src/flare_kernel/runtime/domain/domain_pack_loader.py")
    assert "FLARE_DOMAIN_PACK_ENABLE_LEGACY_PROCUREMENT_FALLBACK" not in source
    assert "legacy_domain_fallback:" not in source


def test_kernel_intent_constants_have_no_legacy_procurement_lexicon_toggle() -> None:
    source = _read("src/flare_kernel/router/kernel_constants/intent.py")
    assert "FLARE_COMPAT_ENABLE_LEGACY_PROCUREMENT_LEXICON" not in source
    assert "_LEGACY_PROCUREMENT_INTENT_KEYWORDS" not in source


def test_intake_default_policy_uses_domain_relevance_keys_only() -> None:
    source = _read("src/flare_kernel/router/kernel_constants/intake.py")
    assert "require_domain_relevance_for_recommendation" in source
    assert "require_domain_relevance_for_auto_override" in source
    assert "require_procurement_relevance_for_recommendation" not in source
    assert "require_procurement_relevance_for_auto_override" not in source


def test_legacy_policy_aliases_are_centralized() -> None:
    root = Path("src/flare_kernel")
    files_with_legacy_policy_alias: list[str] = []
    for path in root.rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        if "require_procurement_relevance_for_" in text:
            files_with_legacy_policy_alias.append(str(path))

    assert sorted(files_with_legacy_policy_alias) == sorted(
        [
            "src/flare_kernel/router/intent/escalation/override.py",
            "src/flare_kernel/router/intake/status/schema.py",
        ]
    )


def test_intent_escalation_signal_uses_compat_alias_helpers() -> None:
    source = _read("src/flare_kernel/router/intent/escalation/signal.py")
    assert "resolve_domain_relevance" in source
    assert "project_domain_relevance" in source
    assert 'if "domain_relevance" not in signal and "procurement_relevance" in signal' not in source


def test_session_intent_small_talk_uses_compat_alias_helpers() -> None:
    source = _read("src/flare_kernel/router/intent/session_intent/small_talk.py")
    assert "resolve_domain_relevance" in source
    assert "procurement_relevance =" not in source


def test_orchestration_status_builder_uses_compat_alias_helpers() -> None:
    source = _read("src/flare_kernel/router/orchestration/status/builder.py")
    assert "resolve_domain_relevance" in source
    assert 'if "domain_relevance" in state' not in source


def test_orchestration_status_state_flow_uses_compat_alias_helpers() -> None:
    source = _read("src/flare_kernel/router/orchestration/status/state/flow.py")
    assert "resolve_domain_relevance" in source
    assert 'if "domain_relevance" in intent_context' not in source


def test_kernel_core_has_no_infrastructure_deployment_field_canonicalization() -> None:
    root = Path("src/flare_kernel")
    banned_tokens = [
        "deployment" + "_type",
        "canonicalize_deployment_value",
        "resolve_deployment_candidates",
        "公有" + "云",
        "私有" + "云",
        "本地" + "IDC",
        "边缘" + "节点",
    ]
    offenders: dict[str, list[str]] = {}
    for path in root.rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        matches = [token for token in banned_tokens if token in text]
        if matches:
            offenders[str(path)] = matches

    assert offenders == {}


def test_generic_pack_and_frontend_process_model_have_no_deployment_gate_terms() -> None:
    repo_root = Path(__file__).resolve().parents[3]
    paths = [
        repo_root / "domain-packs" / "generic" / "fields.yaml",
        repo_root / "domain-packs" / "generic" / "workflow.yaml",
        repo_root / "domain-packs" / "generic" / "search-mapping.yaml",
        repo_root / "packages" / "flare-chat-ui" / "src" / "chat-gui" / "ui" / "timeline" / "components" / "chatTimelineSystemProcessModel.js",
    ]
    banned_tokens = [
        "deployment" + "_type",
        "\u90e8\u7f72" + "环境",
        "\u90e8\u7f72" + "方式",
        "understood" + "_environment",
    ]
    offenders: dict[str, list[str]] = {}
    for path in paths:
        text = path.read_text(encoding="utf-8")
        matches = [token for token in banned_tokens if token in text]
        if matches:
            offenders[str(path)] = matches

    assert offenders == {}
