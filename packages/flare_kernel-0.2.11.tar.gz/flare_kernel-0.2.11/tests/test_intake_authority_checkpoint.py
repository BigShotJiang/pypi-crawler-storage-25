from __future__ import annotations

from types import SimpleNamespace

from flare_kernel.router.intake.authority.checkpoint import build_intake_checkpoint_payload


def test_build_intake_checkpoint_payload_from_snapshot() -> None:
    payload = build_intake_checkpoint_payload(
        checkpoint_snapshot=SimpleNamespace(
            checkpoint_id="ckpt_1",
            intake_session_id="intake_2",
            checkpoint_type="question_waiting",
            checkpoint_state="waiting_user",
            current_stage="requirement_intake.blocked",
            question_key="budget",
            ready_for_submit=False,
            decision_point_active=False,
            updated_at="2026-04-10T00:00:00+00:00",
            payload={
                "current_question": {"field_key": "budget", "step_index": 2, "step_total": 4},
                "next_actions": [{"action_key": "continue_collection"}],
            },
        )
    )

    assert payload["checkpoint_id"] == "ckpt_1"
    assert payload["intake_session_id"] == "intake_2"
    assert payload["checkpoint_type"] == "question_waiting"
    assert payload["checkpoint_state"] == "waiting_user"
    assert payload["question_key"] == "budget"
    assert payload["workflow_id"] == "wf_intake_2"
    assert payload["active_checkpoint_id"] == "ckpt_1"
    assert payload["version"] == 1
    assert payload["checkpoints"] == []
    assert payload["payload"]["next_actions"] == [{"action_key": "continue_collection"}]
