from __future__ import annotations

from flare_kernel.router.intake.guided.flags import resolve_guided_session_flags


def test_resolve_guided_session_flags_marks_ready_for_submit() -> None:
    flags = resolve_guided_session_flags(
        current_stage="requirement_intake.ready_for_submit",
        required_missing=[],
        current_question=None,
        command="send_message",
    )
    assert flags["ready_for_submit"] is True
    assert flags["decision_point_active"] is True


def test_resolve_guided_session_flags_keeps_ready_with_gaps() -> None:
    flags = resolve_guided_session_flags(
        current_stage="requirement_intake.ready_for_submit",
        required_missing=["budget"],
        current_question={"field_key": "budget"},
        command="send_message",
    )
    assert flags["ready_for_submit"] is True
    assert flags["decision_point_active"] is True
