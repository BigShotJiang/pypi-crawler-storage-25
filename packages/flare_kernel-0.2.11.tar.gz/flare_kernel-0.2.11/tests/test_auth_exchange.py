"""Authorization exchange API tests."""

from __future__ import annotations

from fastapi.testclient import TestClient

from flare_kernel import create_app


def _exchange_payload() -> dict:
    return {
        "provider": "wechat",
        "external_subject": "openid_demo",
        "user_id": "user_demo",
        "tenant_id": "tenant_demo",
        "instance_id": "instance_demo",
        "project_id": "project_demo",
        "scopes": ["kernel:run", "sessions:read"],
        "claims": {"unionid": "union_demo"},
    }


def test_auth_exchange_returns_normalized_context(monkeypatch) -> None:
    monkeypatch.delenv("FLARE_AUTH_ALLOWED_PROVIDERS", raising=False)
    monkeypatch.delenv("FLARE_AUTH_ALLOWED_SUBJECTS", raising=False)
    monkeypatch.delenv("FLARE_AUTH_EXCHANGE_SECRET", raising=False)
    client = TestClient(create_app())

    response = client.post("/auth/exchange", json=_exchange_payload())

    assert response.status_code == 200
    payload = response.json()
    assert payload["contract_version"] == "auth.exchange.v0"
    assert payload["auth_context"]["contract_version"] == "auth.context.v0"
    assert payload["auth_context"]["principal"]["provider"] == "wechat"
    assert payload["auth_context"]["principal"]["external_subject"] == "openid_demo"
    assert payload["auth_context"]["principal"]["user_id"] == "user_demo"
    assert payload["auth_context"]["scopes"] == ["kernel:run", "sessions:read"]
    assert payload["authorization"]["allowed"] is True
    assert payload["token_type"] == "none"
    assert payload["token_status"] == "not_issued"
    assert payload["access_token"] is None


def test_auth_exchange_rejects_unlisted_provider(monkeypatch) -> None:
    monkeypatch.setenv("FLARE_AUTH_ALLOWED_PROVIDERS", '["oidc"]')
    client = TestClient(create_app())

    response = client.post("/auth/exchange", json=_exchange_payload())

    assert response.status_code == 403
    assert response.json()["error"]["code"] == "FORBIDDEN_SCOPE"
    assert response.json()["error"]["details"]["reason_codes"] == ["provider_not_allowed"]


def test_auth_exchange_requires_configured_secret(monkeypatch) -> None:
    monkeypatch.setenv("FLARE_AUTH_EXCHANGE_SECRET", "secret_demo")
    client = TestClient(create_app())

    missing = client.post("/auth/exchange", json=_exchange_payload())
    accepted = client.post("/auth/exchange", json=_exchange_payload(), headers={"X-FLARE-Auth-Secret": "secret_demo"})

    assert missing.status_code == 401
    assert missing.json()["error"]["code"] == "UNAUTHORIZED"
    assert accepted.status_code == 200
    assert accepted.json()["authorization"]["allowed"] is True


def test_auth_exchange_can_require_bound_user_id(monkeypatch) -> None:
    payload = _exchange_payload()
    payload.pop("user_id")
    monkeypatch.setenv("FLARE_AUTH_REQUIRE_USER_ID", "1")
    client = TestClient(create_app())

    response = client.post("/auth/exchange", json=payload)

    assert response.status_code == 403
    assert response.json()["error"]["details"]["reason_codes"] == ["missing_user_id"]


def test_auth_exchange_rejects_unlisted_scope(monkeypatch) -> None:
    monkeypatch.setenv("FLARE_AUTH_ALLOWED_SCOPES", '["sessions:read"]')
    client = TestClient(create_app())

    response = client.post("/auth/exchange", json=_exchange_payload())

    assert response.status_code == 403
    body = response.json()
    assert body["error"]["details"]["reason_codes"] == ["scope_not_allowed"]
    assert body["error"]["details"]["context_fields"] == ["scopes"]
