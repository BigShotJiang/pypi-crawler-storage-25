from __future__ import annotations

from fastapi.testclient import TestClient

from flare_kernel import create_app


def test_chat_run_alias_uses_kernel_contract() -> None:
    client = TestClient(create_app())

    response = client.post(
        "/chat/run",
        json={
            "session_id": "sess_chat_alias",
            "intent": "default",
            "payload": {
                "message": "我要采购一批服务器",
                "function_type": "requirement_intake",
            },
        },
    )

    assert response.status_code == 200
    assert response.json()["result"]["mode_runtime"]["mode_key"] == "requirement_intake"
