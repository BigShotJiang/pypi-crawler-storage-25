from __future__ import annotations

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.context.endpoint import (
    prepare_action_turn_context,
    unpack_kernel_turn_context,
)


def test_unpack_kernel_turn_context_normalizes_optional_shapes() -> None:
    unpacked = unpack_kernel_turn_context(
        {
            "trace_id": "t1",
            "command": "send_message",
            "session_id": "s1",
            "instance_profile": {"x": 1},
            "resolved_intent": "default",
            "intent_source": "fallback",
            "intent_confidence": 0.1,
            "intent_reason": "r",
            "raw_message": "m",
            "resolved_mode": "default",
            "mode_source": "fallback",
            "project_id": None,
            "user_id": None,
            "retrieval_config": [],
            "retrieval_queries": "q",
            "retrieval_attempted": 1,
            "retrieved_knowledge": {},
            "enriched_payload": [],
            "runtime_snapshot": [],
            "orchestration_status": [],
            "escalation_signal": [],
            "effective_command": "send_message",
            "structured_retrieved_knowledge": {},
        }
    )
    assert unpacked["project_id"] == ""
    assert unpacked["user_id"] == ""
    assert unpacked["retrieval_config"] == {}
    assert unpacked["retrieval_queries"] == []
    assert unpacked["retrieved_knowledge"] == []
    assert unpacked["structured_retrieved_knowledge"] == []


def test_prepare_action_turn_context_wires_runtime_and_orchestration_layers() -> None:
    req = KernelRequest(
        session_id="s1",
        instance_id="default",
        domain_pack_version="default",
        tenant_id="default",
        action_key="confirm_plan",
        payload={"message": "go"},
        action_reason="reason",
    )

    ctx = prepare_action_turn_context(
        req,
        resolve_trace_id_fn=lambda _trace: "trace-1",
        load_instance_profile_fn=lambda _instance_id: {"profile": True},
        resolve_intent_escalation_policy_with_source_fn=lambda **_kwargs: ({"enable": True}, "default"),
        resolve_command_fn=lambda _req: "send_message",
        resolve_action_target_mode_fn=lambda _req: "requirement_intake",
        build_action_payload_fn=lambda _req, target_mode: {"message": "go", "target_mode": target_mode},
        enrich_payload_fn=lambda enriched_req, **_kwargs: {**enriched_req.payload, "enriched": True},
        build_kernel_runtime_fn=lambda **_kwargs: {
            "mode_key": "requirement_intake",
            "next_actions": [],
        },
        build_orchestration_status_fn=lambda **_kwargs: {"next_actions": [{"action_key": "a"}]},
        extract_user_message_fn=lambda payload: str((payload or {}).get("message") or ""),
        build_intent_and_escalation_signal_fn=lambda **_kwargs: {"signal": True},
        merge_intent_and_escalation_signal_fn=lambda **_kwargs: {"merged": True, "next_actions": [{"action_key": "a"}]},
    )

    assert ctx["trace_id"] == "trace-1"
    assert ctx["action_target_mode"] == "requirement_intake"
    assert ctx["action_payload"]["enriched"] is True
    assert ctx["runtime_snapshot"]["mode_key"] == "requirement_intake"
    assert ctx["orchestration_status"]["merged"] is True
    assert ctx["action_message"] == "go"
    assert "action_command" not in ctx["action_payload"]



def test_prepare_action_turn_context_does_not_apply_legacy_requirement_intake_sanitize() -> None:
    req = KernelRequest(
        session_id="s1",
        instance_id="default",
        domain_pack_version="default",
        tenant_id="default",
        action_key="submit_plan",
        payload={
            "message": "go",
            "command": "legacy_command",
            "action_key": "legacy_action",
            "selected_action_key": "legacy_selected",
            "next_action": {"action_key": "legacy_next"},
        },
    )

    ctx = prepare_action_turn_context(
        req,
        resolve_trace_id_fn=lambda _trace: "trace-2",
        load_instance_profile_fn=lambda _instance_id: {"profile": True},
        resolve_intent_escalation_policy_with_source_fn=lambda **_kwargs: ({"enable": True}, "default"),
        resolve_command_fn=lambda _req: "send_message",
        resolve_action_target_mode_fn=lambda _req: "requirement_intake",
        build_action_payload_fn=lambda _req, target_mode: {
            "message": "go",
            "target_mode": target_mode,
            "command": "legacy_command",
            "action_key": "legacy_action",
            "selected_action_key": "legacy_selected",
            "next_action": {"action_key": "legacy_next"},
        },
        enrich_payload_fn=lambda enriched_req, **_kwargs: dict(enriched_req.payload),
        build_kernel_runtime_fn=lambda **_kwargs: {
            "mode_key": "requirement_intake",
            "next_actions": [],
        },
        build_orchestration_status_fn=lambda **_kwargs: {"next_actions": []},
        extract_user_message_fn=lambda payload: str((payload or {}).get("message") or ""),
        build_intent_and_escalation_signal_fn=lambda **_kwargs: {"signal": True},
        merge_intent_and_escalation_signal_fn=lambda **_kwargs: {"merged": True, "next_actions": []},
    )

    payload = ctx["action_payload"]
    assert ctx["action_target_mode"] == "requirement_intake"
    assert "action_command" not in payload
    assert payload["command"] == "legacy_command"
    assert payload["action_key"] == "legacy_action"
    assert payload["selected_action_key"] == "legacy_selected"
    assert payload["next_action"] == {"action_key": "legacy_next"}


def test_prepare_action_turn_context_passes_action_analysis_route() -> None:
    captured: dict[str, object] = {}
    req = KernelRequest(
        session_id="s1",
        action_key="generate_analysis",
        payload={"message": "go"},
    )

    prepare_action_turn_context(
        req,
        resolve_trace_id_fn=lambda _trace: "trace-3",
        load_instance_profile_fn=lambda _instance_id: None,
        resolve_intent_escalation_policy_with_source_fn=lambda **_kwargs: ({}, "default"),
        resolve_command_fn=lambda _req: "generate_analysis",
        resolve_action_target_mode_fn=lambda _req: "analysis_mode",
        build_action_payload_fn=lambda _req, target_mode: {
            "message": "go",
            "target_mode": target_mode,
            "analysis_route": {"analysis_type": "sourcing"},
        },
        enrich_payload_fn=lambda enriched_req, **_kwargs: dict(enriched_req.payload),
        build_kernel_runtime_fn=lambda **_kwargs: {
            "mode_key": "analysis_mode",
            "next_actions": [],
        },
        build_orchestration_status_fn=lambda **_kwargs: captured.update(_kwargs) or {"next_actions": []},
        extract_user_message_fn=lambda payload: str((payload or {}).get("message") or ""),
        build_intent_and_escalation_signal_fn=lambda **_kwargs: {},
        merge_intent_and_escalation_signal_fn=lambda **_kwargs: _kwargs["orchestration_status"],
    )

    assert captured["analysis_route"] == {"analysis_type": "sourcing"}
