from __future__ import annotations

from flare_kernel.router.intake.guided.followup import build_intake_followup_state


def test_build_intake_followup_state_transitions_to_analysis_ready() -> None:
    state = build_intake_followup_state(
        trace_id="trace-1",
        intake_session_id="intake_1",
        resolved_mode="requirement_intake",
        current_stage="requirement_intake.ready_for_submit",
        current_question=None,
        required_fields=["category", "budget"],
        required_missing=[],
        fields={"category": "服务器", "budget": "20万以内"},
        next_actions=[{"action_key": "confirm_plan", "status": "available"}],
        command="send_message",
        has_analysis_content=False,
    )
    assert state["intake_session_state"] == "analysis_ready"
    assert state["analysis_ready"] is True
    assert state["followup_status"] == "converged"
    assert state["next_user_action"] == "confirm_plan"
    active_work_item = state["active_work_item"]
    assert isinstance(active_work_item, dict)
    assert active_work_item["id"] == "intake::intake_1"
    assert active_work_item["type"] == "intake"
    assert active_work_item["kind"] == "intake"
    assert active_work_item["status"] == "converged"
    assert isinstance(active_work_item["blocking"], dict)
    assert active_work_item["blocking"]["is_blocked"] is False
    assert isinstance(active_work_item["next_actions"], list)
    assert active_work_item["next_actions"][0]["action_key"] == "confirm_plan"
    assert isinstance(active_work_item["checkpoint_ref"], dict)
    assert active_work_item["checkpoint_ref"]["intake_session_id"] == "intake_1"


def test_build_intake_followup_state_marks_intake_apply_as_terminal() -> None:
    state = build_intake_followup_state(
        trace_id="trace-apply",
        intake_session_id="intake_apply_1",
        resolved_mode="requirement_intake",
        current_stage="requirement_intake.collecting",
        current_question={"field_key": "use_case", "question_text": "主要使用场景是什么？"},
        required_fields=["goal", "use_case"],
        required_missing=["use_case"],
        fields={"goal": "采购服务器"},
        next_actions=[],
        command="implement",
        has_analysis_content=False,
    )

    assert state["intake_session_state"] == "applied"
    assert state["intake_session_completed"] is True
    assert state["followup_status"] == "applied"
    assert state["next_question"] is None
    assert state["active_field_key"] == ""
    assert state["pending_merge"] is False
    assert state["remaining_required_fields"] == ["use_case"]
    assert state["unresolved_points"] == ["use_case"]
    assert state["exit_intake_allowed"] is True
    assert state["active_work_item"] is None


def test_build_intake_followup_state_exposes_analysis_work_item() -> None:
    state = build_intake_followup_state(
        trace_id="trace-analysis",
        intake_session_id="intake_analysis_1",
        resolved_mode="requirement_intake",
        current_stage="requirement_analysis.active",
        current_question=None,
        required_fields=["category", "budget"],
        required_missing=[],
        fields={"category": "服务器", "budget": "20万以内"},
        next_actions=[{"action_key": "continue_analysis", "status": "available"}],
        command="generate_analysis",
        has_analysis_content=False,
    )
    active_work_item = state["active_work_item"]
    assert isinstance(active_work_item, dict)
    assert active_work_item["type"] == "analysis"
    assert active_work_item["kind"] == "analysis"
    assert active_work_item["status"] == "running"
    assert isinstance(active_work_item["blocking"], dict)
    assert active_work_item["blocking"]["is_blocked"] is False


def test_build_intake_followup_state_exposes_retrieval_work_item() -> None:
    state = build_intake_followup_state(
        trace_id="trace-retrieval",
        intake_session_id="",
        resolved_mode="intelligent_sourcing",
        current_stage="evidence_retrieval.active",
        current_question={"field_key": "budget"},
        required_fields=[],
        required_missing=[],
        fields={},
        next_actions=[{"action_key": "open_field_retrieval", "status": "available"}],
        command="open_field_retrieval",
        has_analysis_content=False,
    )
    active_work_item = state["active_work_item"]
    assert isinstance(active_work_item, dict)
    assert active_work_item["type"] == "retrieval"
    assert active_work_item["kind"] == "retrieval"
    assert active_work_item["status"] == "running"
    assert isinstance(active_work_item["blocking"], dict)
    assert active_work_item["blocking"]["is_blocked"] is False


def test_build_intake_followup_state_analysis_work_item_can_be_blocked() -> None:
    state = build_intake_followup_state(
        trace_id="trace-analysis-blocked",
        intake_session_id="intake_analysis_blocked_1",
        resolved_mode="requirement_intake",
        current_stage="requirement_analysis.active",
        current_question={"field_key": "category"},
        required_fields=["category", "budget"],
        required_missing=["category"],
        fields={"budget": "20万以内"},
        next_actions=[{"action_key": "continue_collection", "status": "available"}],
        command="generate_analysis",
        has_analysis_content=False,
    )
    active_work_item = state["active_work_item"]
    assert isinstance(active_work_item, dict)
    assert active_work_item["type"] == "analysis"
    assert active_work_item["status"] == "blocked"
    assert active_work_item["blocking"]["is_blocked"] is True
    assert active_work_item["blocking"]["reason"] == "waiting_required_fields"


def test_build_intake_followup_state_analysis_work_item_can_be_completed() -> None:
    state = build_intake_followup_state(
        trace_id="trace-analysis-completed",
        intake_session_id="intake_analysis_completed_1",
        resolved_mode="requirement_intake",
        current_stage="requirement_analysis.active",
        current_question=None,
        required_fields=["category", "budget"],
        required_missing=[],
        fields={"category": "服务器", "budget": "20万以内"},
        next_actions=[{"action_key": "continue_analysis", "status": "available"}],
        command="generate_analysis",
        has_analysis_content=True,
    )
    active_work_item = state["active_work_item"]
    assert isinstance(active_work_item, dict)
    assert active_work_item["type"] == "analysis"
    assert active_work_item["status"] == "completed"
    assert active_work_item["blocking"]["is_blocked"] is False


def test_build_intake_followup_state_retrieval_work_item_can_be_completed() -> None:
    state = build_intake_followup_state(
        trace_id="trace-retrieval-completed",
        intake_session_id="",
        resolved_mode="intelligent_sourcing",
        current_stage="evidence_retrieval.active",
        current_question=None,
        required_fields=[],
        required_missing=[],
        fields={},
        next_actions=[{"action_key": "apply_field_candidate", "status": "available"}],
        command="apply_field_candidate",
        has_analysis_content=False,
    )
    active_work_item = state["active_work_item"]
    assert isinstance(active_work_item, dict)
    assert active_work_item["type"] == "retrieval"
    assert active_work_item["status"] == "completed"
    assert active_work_item["blocking"]["is_blocked"] is True
    assert active_work_item["blocking"]["reason"] == "waiting_target_field"


def test_build_intake_followup_state_retrieval_work_item_can_be_waiting_target_field() -> None:
    state = build_intake_followup_state(
        trace_id="trace-retrieval-waiting",
        intake_session_id="",
        resolved_mode="intelligent_sourcing",
        current_stage="evidence_retrieval.active",
        current_question=None,
        required_fields=[],
        required_missing=[],
        fields={},
        next_actions=[{"action_key": "open_field_retrieval", "status": "available"}],
        command="open_field_retrieval",
        has_analysis_content=False,
    )
    active_work_item = state["active_work_item"]
    assert isinstance(active_work_item, dict)
    assert active_work_item["type"] == "retrieval"
    assert active_work_item["status"] == "idle"
    assert active_work_item["blocking"]["is_blocked"] is True
    assert active_work_item["blocking"]["reason"] == "waiting_target_field"


def test_build_intake_followup_state_without_active_flow_has_no_external_work_item() -> None:
    state = build_intake_followup_state(
        trace_id="trace-no-work",
        intake_session_id="",
        resolved_mode="auto",
        current_stage="general_chat",
        current_question=None,
        required_fields=[],
        required_missing=[],
        fields={},
        next_actions=[],
        command="send_message",
        has_analysis_content=False,
    )
    assert state["active_work_item"] is None
