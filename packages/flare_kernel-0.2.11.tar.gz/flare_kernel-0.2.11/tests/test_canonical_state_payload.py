from __future__ import annotations

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.canonical.payload import build_canonical_payload


def _build_payload(
    *,
    current_question,
    required_missing,
    status_key: str,
    checkpoint: dict | None = None,
    activated_mode: str = "requirement_intake",
    stage_key: str = "requirement_intake",
    question_decision: dict | None = None,
    intake_session_completed: bool = False,
    runtime_snapshot: dict | None = None,
) -> dict:
    return build_canonical_payload(
        req=KernelRequest(payload={}),
        command="send_message",
        mode_source="manual",
        orchestration_status={},
        assistant_text="",
        provider_status="orchestrated",
        canonical_context={
            "fields": {},
            "field_entities": {},
            "required_missing": required_missing,
            "intake_session_id": "intake_1",
            "intake_session_state": status_key,
            "intake_session_completed": intake_session_completed,
            "can_generate": False,
            "explicit_activation": True,
            "activated_mode": activated_mode,
            "stage_key": stage_key,
            "status_key": status_key,
            "current_question": current_question,
            "question_decision": question_decision or {},
            "next_actions": [],
            "checkpoint": checkpoint or {},
        },
        build_confirmed_fields_schema_fn=lambda *_args, **_kwargs: {},
        build_missing_fields_schema_fn=lambda *_args, **_kwargs: {"required": [], "recommended": [], "optional": []},
        resolve_trace_id_fn=lambda _trace: "trace_1",
        safe_session_id_fn=lambda _sid: "session_1",
        runtime_snapshot=runtime_snapshot,
    )


def test_canonical_payload_uses_question_chooser_when_current_question_exists() -> None:
    canonical = _build_payload(
        current_question={"field_key": "use_case", "question_text": "请补充使用场景"},
        required_missing=[],
        status_key="ready_for_submit",
    )
    chooser_state = canonical["primary_flow"]["chooser_state"]
    assert chooser_state["kind"] == "question"
    assert chooser_state["visible"] is True
    assert chooser_state["dismissible"] is True
    assert chooser_state["dismiss_token"]
    assert canonical["composer_ui"]["composer_chooser"] == chooser_state
    assert canonical["composer_ui"]["recommendation_panel"]["visible"] is False
    assert canonical["primary_flow"]["round_state"] == "completed"
    assert canonical["primary_flow"]["round_id"] == "intake_1"
    assert canonical["question_decision"] == {}


def test_canonical_payload_projects_authoritative_question_decision() -> None:
    canonical = _build_payload(
        current_question={"field_key": "budget", "question_text": "预算是多少？"},
        required_missing=["budget"],
        status_key="collecting",
        question_decision={"selected_field_key": "budget", "planning_source": "policy"},
    )

    assert canonical["question_decision"]["selected_field_key"] == "budget"


def test_canonical_payload_stops_stale_runtime_question_after_intake_completed() -> None:
    canonical = _build_payload(
        current_question=None,
        required_missing=[],
        status_key="applied",
        intake_session_completed=True,
        runtime_snapshot={
            "payload": {
                "current_question": {"field_key": "budget", "question_text": "预算是多少？"},
                "next_actions": [{"action_key": "continue_collection"}],
                "track_result": {
                    "track_id": "trk_terminal",
                    "next_actions": [{"action_type": "analyze", "label": "开始需求分析"}],
                },
            }
        },
    )

    assert canonical["current_question"] is None
    assert [item["action_key"] for item in canonical["next_actions"]] == ["confirm_plan"]
    assert canonical["primary_flow"]["mode"]["activated"] == "auto"
    assert canonical["composer_ui"]["active_mode"] == "auto"
    assert canonical["primary_flow"]["chooser_state"]["visible"] is False
    assert canonical["composer_ui"]["composer_chooser"]["visible"] is False
    assert canonical["composer_ui"]["composer_chooser"]["dismiss_token"] == ""


def test_canonical_payload_hides_chooser_when_no_question_and_ready() -> None:
    canonical = _build_payload(
        current_question=None,
        required_missing=[],
        status_key="ready_for_submit",
    )
    chooser_state = canonical["primary_flow"]["chooser_state"]
    assert chooser_state["kind"] == "none"
    assert chooser_state["visible"] is False
    assert canonical["composer_ui"]["composer_chooser"]["visible"] is False
    assert canonical["primary_flow"]["round_state"] == "completed"
    assert canonical["primary_flow"]["round_completed"] is True


def test_canonical_payload_projects_round_progress_from_question() -> None:
    canonical = _build_payload(
        current_question={"field_key": "constraints", "step_index": 2, "step_total": 4},
        required_missing=["constraints"],
        status_key="collecting",
    )
    primary_flow = canonical["primary_flow"]
    assert primary_flow["round_state"] == "collecting"
    assert primary_flow["round_question_index"] == 2
    assert primary_flow["round_question_total"] == 4
    assert primary_flow["round_interruptible"] is True


def test_canonical_payload_projects_round_id_with_checkpoint_seq() -> None:
    canonical = _build_payload(
        current_question={"field_key": "constraints", "step_index": 1, "step_total": 3},
        required_missing=["constraints"],
        status_key="collecting",
        checkpoint={
            "checkpoints": [
                {
                    "seq": 3,
                }
            ]
        },
    )
    assert canonical["primary_flow"]["round_id"] == "intake_1:r3"


def test_canonical_payload_does_not_treat_old_followup_as_special_question() -> None:
    canonical = _build_payload(
        current_question={
            "field_key": "intake_context",
            "question_kind": "followup",
            "question_text": "请补充约束",
        },
        required_missing=[],
        status_key="idle",
        activated_mode="requirement_analysis",
        stage_key="general_chat",
    )
    chooser_state = canonical["primary_flow"]["chooser_state"]
    assert chooser_state["kind"] == "none"
    assert chooser_state["visible"] is False


def test_canonical_payload_uses_sourcing_analysis_title_when_route_is_sourcing() -> None:
    canonical = build_canonical_payload(
        req=KernelRequest(payload={}),
        command="generate_analysis",
        mode_source="manual",
        orchestration_status={"analysis_route": {"analysis_type": "sourcing"}},
        assistant_text="",
        provider_status="ok",
        canonical_context={
            "fields": {},
            "field_entities": {},
            "required_missing": [],
            "intake_session_id": "intake_1",
            "intake_session_state": "analysis_running",
            "intake_session_completed": False,
            "can_generate": True,
            "explicit_activation": True,
            "activated_mode": "requirement_analysis",
            "stage_key": "requirement_analysis",
            "status_key": "active",
            "current_question": None,
            "next_actions": [],
            "checkpoint": {},
        },
        build_confirmed_fields_schema_fn=lambda *_args, **_kwargs: {},
        build_missing_fields_schema_fn=lambda *_args, **_kwargs: {"required": [], "recommended": [], "optional": []},
        resolve_trace_id_fn=lambda _trace: "trace_1",
        safe_session_id_fn=lambda _sid: "session_1",
    )
    assert canonical["analysis"]["title"] == "寻源分析"


def test_canonical_payload_ignores_removed_plan_authoritative_fields() -> None:
    canonical = build_canonical_payload(
        req=KernelRequest(payload={}),
        command="send_message",
        mode_source="manual",
        orchestration_status={},
        assistant_text="",
        provider_status="ok",
        canonical_context={
            "fields": {},
            "field_entities": {},
            "required_missing": [],
            "intake_session_id": "intake_1",
            "intake_session_state": "collecting",
            "intake_session_completed": False,
            "can_generate": False,
            "explicit_activation": True,
            "activated_mode": "requirement_intake",
            "stage_key": "collecting",
            "status_key": "collecting",
            "current_question": {"field_key": "intake_context", "question_text": "请补充约束"},
            "next_actions": [],
            "checkpoint": {},
            "removed_session_state": {"workflow_status": "collecting"},
            "removed_canvas_draft": {"content": "draft"},
            "removed_apply_handoff": {"ready": False},
            "removed_summary_contract": {"summary": "contract"},
            "removed_summary_template_key": "flare_default",
            "removed_summary_template": {"sections": ["summary"]},
        },
        build_confirmed_fields_schema_fn=lambda *_args, **_kwargs: {},
        build_missing_fields_schema_fn=lambda *_args, **_kwargs: {"required": [], "recommended": [], "optional": []},
        resolve_trace_id_fn=lambda _trace: "trace_1",
        safe_session_id_fn=lambda _sid: "session_1",
    )
    assert canonical["mode_key"] == "requirement_intake"
    assert "removed_session_state" not in canonical
    assert "removed_canvas_draft" not in canonical
    assert "removed_apply_handoff" not in canonical


def test_canonical_payload_marks_non_empty_orchestrated_reply_as_system_notice_in_requirement_intake() -> None:
    canonical = build_canonical_payload(
        req=KernelRequest(payload={}),
        command="send_message",
        mode_source="manual",
        orchestration_status={},
        assistant_text="请补充约束",
        provider_status="orchestrated",
        canonical_context={
            "fields": {},
            "field_entities": {},
            "required_missing": ["constraints"],
            "intake_session_id": "intake_1",
            "intake_session_state": "collecting",
            "intake_session_completed": False,
            "can_generate": False,
            "explicit_activation": True,
            "activated_mode": "requirement_intake",
            "stage_key": "collecting",
            "status_key": "collecting",
            "current_question": {"field_key": "constraints", "question_text": "请补充约束"},
            "next_actions": [],
            "checkpoint": {},
        },
        build_confirmed_fields_schema_fn=lambda *_args, **_kwargs: {},
        build_missing_fields_schema_fn=lambda *_args, **_kwargs: {"required": [], "recommended": [], "optional": []},
        resolve_trace_id_fn=lambda _trace: "trace_1",
        safe_session_id_fn=lambda _sid: "session_1",
    )
    assert canonical["assistant_reply"]["type"] == "system_notice"


def test_canonical_payload_uses_track_decision_as_next_actions_fallback() -> None:
    canonical = _build_payload(
        current_question=None,
        required_missing=[],
        status_key="idle",
        activated_mode="auto",
        stage_key="general_chat",
        runtime_snapshot={
            "payload": {
                "track_result": {
                    "track_id": "trk_1",
                    "track_key": "market_scan",
                    "current_step_id": "scan",
                    "readiness": {
                        "readiness_score": 0.7,
                        "readiness_level": "partial",
                        "blocking_gaps": ["scope"],
                        "non_blocking_gaps": ["timeline"],
                    },
                    "next_actions": [
                        {
                            "action_type": "search",
                            "label": "开始市场扫描",
                            "capability": "market_scan",
                            "score": 0.68,
                        }
                    ],
                },
                "response_strategy_result": {"strategy_key": "consultative"},
            }
        },
    )

    assert canonical["track_result"]["track_id"] == "trk_1"
    assert canonical["response_strategy_result"]["strategy_key"] == "consultative"
    assert canonical["next_actions"][0]["source"] == "track_decision"
    assert canonical["next_actions"][0]["target_mode"] == "market_scan"
    assert canonical["next_actions"][0]["payload"]["blocking_gaps"] == ["scope"]
    assert canonical["next_actions"][0]["payload"]["non_blocking_gaps"] == ["timeline"]
    assert canonical["assistant_reply"]["text"] == ""
    assert canonical["composer_ui"]["recommendation_panel"]["visible"] is True


def test_canonical_payload_keeps_empty_orchestrated_reply_as_system_notice() -> None:
    canonical = _build_payload(
        current_question={"field_key": "constraints", "question_text": "请补充约束"},
        required_missing=["constraints"],
        status_key="collecting",
    )
    assert canonical["assistant_reply"]["type"] == "system_notice"


def test_canonical_payload_suppresses_requirement_intake_reply_before_implement() -> None:
    canonical = build_canonical_payload(
        req=KernelRequest(payload={}),
        command="send_message",
        mode_source="manual",
        orchestration_status={},
        assistant_text="请先确认范围",
        provider_status="orchestrated",
        canonical_context={
            "fields": {},
            "field_entities": {},
            "required_missing": ["constraints"],
            "intake_session_id": "intake_1",
            "intake_session_state": "collecting",
            "intake_session_completed": False,
            "can_generate": False,
            "explicit_activation": True,
            "activated_mode": "requirement_intake",
            "stage_key": "collecting",
            "status_key": "collecting",
            "current_question": {"field_key": "constraints", "question_text": "请补充约束"},
            "next_actions": [],
            "checkpoint": {},
        },
        build_confirmed_fields_schema_fn=lambda *_args, **_kwargs: {},
        build_missing_fields_schema_fn=lambda *_args, **_kwargs: {"required": [], "recommended": [], "optional": []},
        resolve_trace_id_fn=lambda _trace: "trace_1",
        safe_session_id_fn=lambda _sid: "session_1",
    )
    assert canonical["assistant_reply"]["text"] == ""
    assert canonical["assistant_reply"]["type"] == "system_notice"


def test_canonical_payload_normalizes_legacy_requirement_intake_and_keeps_analysis_canvas_payload() -> None:
    canonical = build_canonical_payload(
        req=KernelRequest(payload={}),
        command="send_message",
        mode_source="manual",
        orchestration_status={
            "canvas_analysis_payload": {"markdown": "# 模板"},
            "analysis_slot_patches": [{"slot_key": "summary"}],
        },
        assistant_text="",
        provider_status="ok",
        canonical_context={
            "fields": {},
            "field_entities": {},
            "required_missing": [],
            "intake_session_id": "intake_1",
            "intake_session_state": "reviewing",
            "intake_session_completed": False,
            "can_generate": False,
            "explicit_activation": True,
            "activated_mode": "requirement_intake",
            "stage_key": "reviewing",
            "status_key": "reviewing",
            "current_question": None,
            "next_actions": [],
            "checkpoint": {},
            "removed_session_state": {"workflow_status": "reviewing"},
            "removed_canvas_draft": {"content": "draft"},
            "removed_apply_handoff": {"ready": False},
        },
        build_confirmed_fields_schema_fn=lambda *_args, **_kwargs: {},
        build_missing_fields_schema_fn=lambda *_args, **_kwargs: {"required": [], "recommended": [], "optional": []},
        resolve_trace_id_fn=lambda _trace: "trace_1",
        safe_session_id_fn=lambda _sid: "session_1",
    )
    assert canonical["mode_key"] == "requirement_intake"
    assert canonical["analysis"]["readiness"]["can_generate"] is False
    assert canonical["canvas_analysis_payload"] == {"markdown": "# 模板"}
    assert canonical["analysis_payload"] == {"markdown": "# 模板"}
    assert canonical["analysis_slot_patches"] == [{"slot_key": "summary"}]
