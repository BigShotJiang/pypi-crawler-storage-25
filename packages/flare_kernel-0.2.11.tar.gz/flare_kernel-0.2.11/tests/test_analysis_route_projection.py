from __future__ import annotations

import asyncio

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.kernel_facade.turn_context import prepare_kernel_turn_context_flow
from flare_kernel.router.orchestration.status.projection import build_orchestration_status_payload


def test_orchestration_status_payload_projects_analysis_route_append_only() -> None:
    payload = build_orchestration_status_payload(
        trace_id="trace-analysis-route",
        current_stage="requirement_analysis.ready",
        resolved_intent="requirement_intake",
        resolved_mode="requirement_intake",
        intent_source="intent",
        intent_confidence=0.88,
        intent_reason="matched",
        confirmed_updates=[],
        field_entities={},
        open_fields=[],
        search_actions=[],
        workspace_updates={},
        next_action={"action_key": "generate_analysis"},
        resolved_actions=[{"action_key": "generate_analysis"}],
        decision_payload={},
        active_collecting=False,
        ready_for_submit=True,
        required_coverage=1.0,
        total_coverage=1.0,
        analysis_entry_threshold=0.8,
        analysis_entry_eligible=True,
        analyzability_score=0.92,
        decision_point_active=False,
        has_active_question=False,
        question_progress={"current": 0, "total": 0},
        guided_session={},
        intake_followup_state={},
        current_question=None,
        normalized_required_fields=[],
        normalized_required_missing=[],
        session_intent_stage="analysis_ready",
        conversation_intent_state="analysis_ready",
        intake_understanding={},
        active_checkpoint={},
        checkpoint_state_value="",
        chooser=None,
        node_id="analysis",
        node_state="ready",
        node_reason="",
        needs_user_choice=False,
        chooser_required=False,
        blocking_reason="",
        intent_escalation_policy={},
        intent_escalation_policy_source="default",
        coerce_intent_escalation_policy_fn=lambda value: value if isinstance(value, dict) else {},
        analysis_route={
            "analysis_type": "sourcing",
            "template_id": "flare.sourcing.default.v1",
            "reason_codes": ["ROUTE_SIGNAL_SOURCING_INTENT"],
            "confidence": 0.83,
        },
    )

    assert payload["analysis_route"]["analysis_type"] == "sourcing"
    assert payload["analysis_route"]["template_id"] == "flare.sourcing.default.v1"


def test_prepare_kernel_turn_context_attaches_analysis_route_to_orchestration_status() -> None:
    req = KernelRequest(
        payload={
            "message": "请分析这些供应商",
            "project_id": "p1",
            "user_id": "u1",
        }
    )

    async def _run() -> dict:
        return await prepare_kernel_turn_context_flow(
            req=req,
            resolve_trace_id_fn=lambda _t: "trace-1",
            resolve_command_fn=lambda _r: "generate_analysis",
            safe_session_id_fn=lambda _s: "session-1",
            load_instance_profile_fn=lambda _i: {"profile": "ok"},
            resolve_intent_escalation_policy_with_source_fn=lambda **_kwargs: ({"enabled": True}, "default"),
            resolve_request_intent_with_ai_fn=lambda _r, _t: _async_tuple(("default", "fallback", 0.2, "none")),
            extract_user_message_fn=lambda payload: str((payload or {}).get("message") or ""),
            build_intent_and_escalation_signal_fn=lambda **_kwargs: {"signal": "ok"},
            resolve_request_mode_fn=lambda _r, _i: ("intelligent_sourcing", "command"),
            apply_escalation_mode_override_fn=lambda **kwargs: (
                kwargs["resolved_intent"],
                kwargs["intent_source"],
                kwargs["intent_confidence"],
                kwargs["intent_reason"],
                kwargs["resolved_mode"],
                kwargs["mode_source"],
            ),
            resolve_project_id_fn=lambda _r, payload: str(payload.get("project_id") or ""),
            resolve_user_id_fn=lambda _r, payload: str(payload.get("user_id") or ""),
            resolve_retrieval_config_fn=lambda _r, _p: {"enabled": True, "top_k": 3, "min_score": 0.1},
            build_retrieval_queries_fn=lambda _r, **_kwargs: [],
            search_knowledge_by_queries_fn=lambda **_kwargs: [],
            enrich_payload_fn=lambda _r, **_kwargs: {"message": "请分析这些供应商"},
            build_kernel_runtime_fn=lambda **_kwargs: {"payload": {"message": "请分析这些供应商"}, "open_fields": []},
            build_orchestration_status_fn=lambda **_kwargs: {"open_fields": [], "analysis_route": _kwargs.get("analysis_route")},
            merge_intent_and_escalation_signal_fn=lambda **kwargs: kwargs["orchestration_status"],
            resolve_effective_command_fn=lambda **_kwargs: "generate_analysis",
            build_structured_search_results_fn=lambda **_kwargs: [],
            resolve_analysis_route_fn=lambda **_kwargs: {
                "analysis_type": "sourcing",
                "template_id": "flare.sourcing.default.v1",
                "reason_codes": ["ROUTE_SIGNAL_SOURCING_INTENT"],
                "confidence": 0.81,
            },
        )

    result = asyncio.run(_run())
    assert result["analysis_route"]["analysis_type"] == "sourcing"
    assert result["orchestration_status"]["analysis_route"]["template_id"] == "flare.sourcing.default.v1"


async def _async_tuple(value):
    return value
