from __future__ import annotations

from flare_kernel.runtime.orchestration.analysis_router_runtime import resolve_analysis_route


def test_analysis_route_runtime_honors_explicit_payload_route() -> None:
    route = resolve_analysis_route(
        message="请按当前候选生成分析",
        intent="default",
        command="generate_analysis",
        mode="analysis_mode",
        payload={
            "analysis_route": {
                "analysis_type": "sourcing",
                "template_id": "flare.sourcing.default.v1",
                "reason_codes": ["ROUTE_SIGNAL_SOURCING_HANDOFF"],
                "confidence": 0.91,
            }
        },
    )

    assert route["analysis_type"] == "sourcing"
    assert route["template_id"] == "flare.sourcing.default.v1"
    assert route["reason_codes"] == ["ROUTE_SIGNAL_SOURCING_HANDOFF"]
    assert route["confidence"] == 0.91


def test_analysis_route_runtime_uses_contract_policy_for_sourcing_candidates() -> None:
    route = resolve_analysis_route(
        message="请分析这些供应商",
        intent="intelligent_sourcing",
        command="generate_analysis",
        mode="intelligent_sourcing",
        payload={
            "sourcing_candidates": [
                {
                    "supplier_name": "供应商 A",
                    "confidence": 0.88,
                }
            ]
        },
        retrieval_hit_count=1,
    )

    assert route["analysis_type"] == "sourcing"
    assert route["template_id"] == "flare.sourcing.default.v1"
    assert "ROUTE_SIGNAL_CANDIDATE_POOL_READY" in route["reason_codes"]


def test_analysis_route_runtime_accepts_payload_policy_override() -> None:
    route = resolve_analysis_route(
        message="custom signal",
        intent="default",
        command="generate_analysis",
        mode="analysis_mode",
        payload={
            "analysis_route_policy": {
                "analysis_type_terms": {
                    "sourcing": ["custom signal"],
                    "requirement": [],
                },
                "candidate_pool_analysis_type": "sourcing",
                "default_analysis_type": "requirement",
            },
            "sourcing_candidates": [{"supplier_name": "Custom Vendor"}],
        },
    )

    assert route["analysis_type"] == "sourcing"
