from __future__ import annotations

from flare_kernel.router.intake.authority.session import (
    build_intake_session_id,
    normalize_intake_session_id,
    resolve_intake_session_id,
)


def test_normalize_and_build_intake_session_id() -> None:
    assert normalize_intake_session_id(" intake@session#1 ") == "intake_session_1"
    assert build_intake_session_id(session_id="session-1", seed="req@1") == "intake_session-1_req_1"


def test_resolve_intake_session_id_prefers_payload_then_persisted_then_local() -> None:
    from_payload = resolve_intake_session_id(
        payload={"intake_session_id": "intake_payload_1"},
        session_id="session-1",
        trace_id="trace-1",
        command="send_message",
        resolved_mode="requirement_intake",
        latest_persisted_intake_session_id="intake_persisted_1",
        has_active_intake_payload=False,
    )
    assert from_payload == "intake_payload_1"

    from_persisted = resolve_intake_session_id(
        payload={},
        session_id="session-1",
        trace_id="trace-1",
        command="submit_intake_answer",
        resolved_mode="default",
        latest_persisted_intake_session_id="intake_persisted_1",
        has_active_intake_payload=False,
    )
    assert from_persisted == "intake_persisted_1"

    from_local = resolve_intake_session_id(
        payload={"client_request_id": "req-xyz"},
        session_id="session-1",
        trace_id="trace-1",
        command="send_message",
        resolved_mode="requirement_intake",
        latest_persisted_intake_session_id="",
        has_active_intake_payload=False,
    )
    assert from_local == "intake_session-1_req-xyz"

    no_intake = resolve_intake_session_id(
        payload={},
        session_id="session-1",
        trace_id="trace-1",
        command="send_message",
        resolved_mode="default",
        latest_persisted_intake_session_id="",
        has_active_intake_payload=False,
    )
    assert no_intake == ""
