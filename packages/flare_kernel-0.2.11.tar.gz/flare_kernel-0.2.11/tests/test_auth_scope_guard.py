"""Route scope guard tests."""

from __future__ import annotations

import json

from fastapi.testclient import TestClient

from flare_kernel import create_app
from flare_kernel.runtime.auth.scope_guard import filter_patch_operations, filter_payload_fields
from flare_kernel.session_store import create_session, reset_store_for_testing


def _auth_context_header(
    *,
    scopes: list[str],
    project_id: str = "project_auth",
    user_id: str = "user_auth",
    session_id: str | None = None,
) -> dict[str, str]:
    payload = {
        "principal": {
            "provider": "test",
            "external_subject": "subject_auth",
            "user_id": user_id,
            "tenant_id": "tenant_auth",
            "instance_id": "instance_auth",
        },
        "project_id": project_id,
        "session_id": session_id,
        "scopes": scopes,
        "claims": {},
    }
    return {"X-FLARE-Auth-Context": json.dumps(payload)}


def test_scope_guard_rejects_missing_auth_context(monkeypatch) -> None:
    monkeypatch.setenv("FLARE_AUTH_ROUTE_GUARD_ENABLED", "1")
    reset_store_for_testing()
    client = TestClient(create_app())

    response = client.post(
        "/sessions",
        json={
            "function_type": "chat",
            "project_id": "project_auth",
            "title": "Auth session",
            "user_id": "user_auth",
        },
    )

    assert response.status_code == 401
    assert response.json()["error"]["code"] == "UNAUTHORIZED"
    assert response.json()["error"]["details"]["reason_codes"] == ["missing_auth_context"]


def test_scope_guard_rejects_invalid_auth_context_header(monkeypatch) -> None:
    monkeypatch.setenv("FLARE_AUTH_ROUTE_GUARD_ENABLED", "1")
    reset_store_for_testing()
    client = TestClient(create_app())

    response = client.post(
        "/sessions",
        headers={"X-FLARE-Auth-Context": "{invalid-json"},
        json={
            "function_type": "chat",
            "project_id": "project_auth",
            "title": "Auth session",
            "user_id": "user_auth",
        },
    )

    assert response.status_code == 401
    assert response.json()["error"]["code"] == "UNAUTHORIZED"
    assert response.json()["error"]["details"]["reason_codes"] == ["invalid_auth_context"]


def test_scope_guard_allows_matching_session_create(monkeypatch) -> None:
    monkeypatch.setenv("FLARE_AUTH_ROUTE_GUARD_ENABLED", "1")
    reset_store_for_testing()
    client = TestClient(create_app())

    response = client.post(
        "/sessions",
        headers=_auth_context_header(scopes=["sessions:write"]),
        json={
            "function_type": "chat",
            "project_id": "project_auth",
            "title": "Auth session",
            "user_id": "user_auth",
        },
    )

    assert response.status_code == 200
    assert response.json()["project_id"] == "project_auth"
    assert response.json()["user_id"] == "user_auth"


def test_scope_guard_rejects_project_mismatch(monkeypatch) -> None:
    monkeypatch.setenv("FLARE_AUTH_ROUTE_GUARD_ENABLED", "1")
    reset_store_for_testing()
    client = TestClient(create_app())

    response = client.post(
        "/sessions",
        headers=_auth_context_header(scopes=["sessions:write"], project_id="project_other"),
        json={
            "function_type": "chat",
            "project_id": "project_auth",
            "title": "Auth session",
            "user_id": "user_auth",
        },
    )

    assert response.status_code == 403
    assert response.json()["error"]["code"] == "FORBIDDEN_SCOPE"
    assert response.json()["error"]["details"]["reason_codes"] == ["project_id_scope_mismatch"]


def test_scope_guard_filters_session_list_by_auth_context(monkeypatch) -> None:
    monkeypatch.setenv("FLARE_AUTH_ROUTE_GUARD_ENABLED", "1")
    reset_store_for_testing()
    create_session(function_type="chat", project_id="project_auth", title="Visible", user_id="user_auth")
    create_session(function_type="chat", project_id="project_other", title="Hidden", user_id="user_other")
    client = TestClient(create_app())

    response = client.get(
        "/sessions?status=all",
        headers=_auth_context_header(scopes=["sessions:read"]),
    )

    assert response.status_code == 200
    sessions = response.json()["sessions"]
    assert [item["project_id"] for item in sessions] == ["project_auth"]


def test_scope_guard_rejects_missing_kernel_scope_before_execution(monkeypatch) -> None:
    monkeypatch.setenv("FLARE_AUTH_ROUTE_GUARD_ENABLED", "1")
    client = TestClient(create_app())

    response = client.post(
        "/kernel/run",
        headers=_auth_context_header(scopes=["sessions:read"]),
        json={
            "content": "hello",
            "project_id": "project_auth",
            "user_id": "user_auth",
        },
    )

    assert response.status_code == 403
    assert response.json()["error"]["details"]["reason_codes"] == ["route_scope_not_allowed"]
    assert response.json()["error"]["details"]["denied_scopes"] == ["kernel:run"]


def test_filter_payload_fields_keeps_allowed_nested_paths() -> None:
    payload = {
        "project_id": "project_auth",
        "profile": {"name": "Alice", "email": "alice@example.com"},
        "private": {"token": "secret"},
    }

    filtered = filter_payload_fields(payload, ["project_id", "profile.name"])

    assert filtered == {
        "project_id": "project_auth",
        "profile": {"name": "Alice"},
    }


def test_filter_payload_fields_supports_explicit_wildcard() -> None:
    payload = {"project_id": "project_auth", "status": "active"}

    assert filter_payload_fields(payload, ["*"]) == payload


def test_filter_patch_operations_keeps_allowed_field_paths() -> None:
    operations = [
        {"op": "replace", "path": "/profile/name", "value": "Alice"},
        {"op": "replace", "path": "/private/token", "value": "secret"},
        {"op": "add", "path": "project_id", "value": "project_auth"},
    ]

    filtered = filter_patch_operations(operations, ["profile", "project_id"])

    assert filtered == [
        {"op": "replace", "path": "/profile/name", "value": "Alice"},
        {"op": "add", "path": "project_id", "value": "project_auth"},
    ]
