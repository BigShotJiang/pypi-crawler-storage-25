from __future__ import annotations

from types import SimpleNamespace

from flare_kernel.router.intake.authority.core import (
    build_intake_session_id,
    build_intake_checkpoint_payload,
    hydrate_payload_from_authoritative_checkpoint,
    hydrate_payload_from_authoritative_intake_session,
    normalize_intake_session_id,
    resolve_intake_session_id,
)


def test_hydrate_payload_from_authoritative_intake_session_fills_missing_fields() -> None:
    merged = hydrate_payload_from_authoritative_intake_session(
        payload={
            "message": "继续",
            "required_missing": ["budget"],
            "fields": {"category": "服务器"},
        },
        persisted_payload={
            "fields": {"category": "服务器", "use_case": "测试开发"},
            "field_sources": {"category": {"type": "user_extracted"}},
            "recommended_missing": ["delivery_time"],
            "question_progress": {"current": 2, "total": 5},
        },
        persisted_status={
            "intake_session_id": "intake_1",
            "intake_session_state": "workspace_live_updating",
            "intake_session_completed": False,
        },
    )

    assert merged["fields"] == {"category": "服务器"}
    assert merged["field_sources"] == {"category": {"type": "user_extracted"}}
    assert merged["recommended_missing"] == ["delivery_time"]
    assert merged["question_progress"] == {"current": 2, "total": 5}
    assert merged["intake_session_id"] == "intake_1"
    assert merged["intake_session_state"] == "workspace_live_updating"
    assert merged["intake_session_completed"] is False


def test_build_intake_checkpoint_payload_from_snapshot() -> None:
    payload = build_intake_checkpoint_payload(
        checkpoint_snapshot=SimpleNamespace(
            checkpoint_id="ckpt_1",
            intake_session_id="intake_2",
            checkpoint_type="question_waiting",
            checkpoint_state="waiting_user",
            current_stage="requirement_intake.blocked",
            question_key="budget",
            ready_for_submit=False,
            decision_point_active=False,
            updated_at="2026-04-10T00:00:00+00:00",
            payload={
                "current_question": {"field_key": "budget", "step_index": 2, "step_total": 4},
                "next_actions": [{"action_key": "continue_collection"}],
            },
        )
    )

    assert payload["checkpoint_id"] == "ckpt_1"
    assert payload["intake_session_id"] == "intake_2"
    assert payload["checkpoint_type"] == "question_waiting"
    assert payload["checkpoint_state"] == "waiting_user"
    assert payload["question_key"] == "budget"
    assert payload["workflow_id"] == "wf_intake_2"
    assert payload["active_checkpoint_id"] == "ckpt_1"
    assert payload["version"] == 1
    assert payload["checkpoints"] == []
    assert payload["payload"]["next_actions"] == [{"action_key": "continue_collection"}]


def test_hydrate_payload_from_authoritative_checkpoint_applies_question_progress() -> None:
    merged = hydrate_payload_from_authoritative_checkpoint(
        payload={"message": "继续", "intake_session_id": "intake_3"},
        checkpoint_snapshot=SimpleNamespace(
            checkpoint_id="ckpt_2",
            intake_session_id="intake_3",
            checkpoint_type="question_waiting",
            checkpoint_state="waiting_user",
            current_stage="requirement_intake.collecting",
            question_key="budget",
            ready_for_submit=False,
            decision_point_active=False,
            updated_at="2026-04-10T00:00:00+00:00",
            payload={
                "current_question": {"field_key": "budget", "step_index": 3, "step_total": 5},
                "next_action": {"action_key": "continue_collection"},
                "next_actions": [{"action_key": "continue_collection"}],
                "required_missing": ["budget"],
            },
        ),
    )

    assert merged["intake_checkpoint"]["checkpoint_id"] == "ckpt_2"
    assert merged["current_question"]["field_key"] == "budget"
    assert merged["next_action"]["action_key"] == "continue_collection"
    assert merged["required_missing"] == ["budget"]
    assert merged["question_progress"] == {
        "current": 3,
        "total": 5,
        "intake_session_id": "intake_3",
        "resumed": True,
    }


def test_normalize_and_build_intake_session_id() -> None:
    normalized = normalize_intake_session_id(" intake@session#1 ")
    assert normalized == "intake_session_1"
    built = build_intake_session_id(session_id="session-1", seed="req@1")
    assert built == "intake_session-1_req_1"


def test_resolve_intake_session_id_prefers_payload_then_persisted_then_local() -> None:
    from_payload = resolve_intake_session_id(
        payload={"intake_session_id": "intake_payload_1"},
        session_id="session-1",
        trace_id="trace-1",
        command="send_message",
        resolved_mode="requirement_intake",
        latest_persisted_intake_session_id="intake_persisted_1",
        has_active_intake_payload=False,
    )
    assert from_payload == "intake_payload_1"

    from_persisted = resolve_intake_session_id(
        payload={},
        session_id="session-1",
        trace_id="trace-1",
        command="submit_intake_answer",
        resolved_mode="default",
        latest_persisted_intake_session_id="intake_persisted_1",
        has_active_intake_payload=False,
    )
    assert from_persisted == "intake_persisted_1"

    from_local = resolve_intake_session_id(
        payload={"client_request_id": "req-xyz"},
        session_id="session-1",
        trace_id="trace-1",
        command="send_message",
        resolved_mode="requirement_intake",
        latest_persisted_intake_session_id="",
        has_active_intake_payload=False,
    )
    assert from_local == "intake_session-1_req-xyz"

    no_intake = resolve_intake_session_id(
        payload={},
        session_id="session-1",
        trace_id="trace-1",
        command="send_message",
        resolved_mode="default",
        latest_persisted_intake_session_id="",
        has_active_intake_payload=False,
    )
    assert no_intake == ""
