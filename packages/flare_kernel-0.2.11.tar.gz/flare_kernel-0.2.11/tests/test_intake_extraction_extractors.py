from __future__ import annotations

from flare_kernel.router.intake.extraction.extractors import (
    extract_intake_goal,
    extract_intake_fields_from_message,
    resolve_intake_extraction_scope,
)


def test_extract_intake_fields_from_message_supports_dependency_injection() -> None:
    result = extract_intake_fields_from_message(
        "raw message",
        context={"allowed_fields": ["goal", "budget"]},
        normalize_message_text_fn=lambda _: "normalized",
        resolve_intake_extraction_scope_fn=lambda _: {"goal", "budget"},
        extract_intake_goal_fn=lambda _: "g",
        extract_intake_use_case_fn=lambda _: "",
        extract_intake_budget_fn=lambda _: "b",
        extract_intake_quantity_fn=lambda _: "",
        extract_intake_constraints_fn=lambda _: "",
        extract_intake_delivery_time_fn=lambda _: "",
    )

    assert result["fields"] == {"goal": "g", "budget": "b"}


def test_resolve_intake_extraction_scope_does_not_invent_business_fields() -> None:
    scope = resolve_intake_extraction_scope({"allowed_fields": []})
    assert scope == set()


def test_extract_intake_goal_skips_control_messages() -> None:
    assert extract_intake_goal("继续") == ""
    assert extract_intake_goal("确认提交") == ""
