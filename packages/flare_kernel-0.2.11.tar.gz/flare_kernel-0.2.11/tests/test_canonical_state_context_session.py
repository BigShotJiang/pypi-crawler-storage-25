from __future__ import annotations

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.canonical.context.session import (
    resolve_canonical_state_context_session,
)


def test_resolve_canonical_state_context_session_keeps_activation_and_stage_wiring() -> None:
    context_session = resolve_canonical_state_context_session(
        req=KernelRequest(payload={"message": "请继续"}, session_id="session-1"),
        command="send_message",
        resolved_intent="requirement_intake",
        mode_source="manual",
        orchestration_status={
            "intake_session_id": "intake-1",
            "intake_session_state": "collecting",
            "intake_session_completed": False,
            "intent_escalation_policy": {"enabled": True},
            "intent_escalation_policy_source": "manual",
        },
        assistant_text="",
        context_inputs={
            "external_mode": "requirement_intake",
            "inferred_stage": "intake_collecting",
            "current_question": {"field_key": "budget"},
            "required_missing": ["budget"],
            "fields": {"budget": "100万"},
            "intake_candidate": True,
            "clarification_recommended": False,
            "escalation_target": "intake_candidate",
            "analysis_ready": False,
        },
        map_external_mode_fn=lambda mode: mode,
        resolve_session_intent_stage_fn=lambda **_: "clarification_in_progress",
        coerce_intent_escalation_policy_fn=lambda raw: raw if isinstance(raw, dict) else {},
        normalize_stage_status_fn=lambda **kwargs: (
            str(kwargs.get("current_stage") or "intake_collecting"),
            "waiting_user" if list(kwargs.get("required_missing") or []) else "running",
        ),
        extract_user_message_fn=lambda payload: str((payload or {}).get("message") or ""),
        normalize_intake_session_id_fn=lambda raw: str(raw or "").strip(),
    )

    assert context_session["intake_session_id"] == "intake-1"
    assert context_session["session_intent_stage"] == "clarification_in_progress"
    assert context_session["explicit_activation"] is False
    assert context_session["stage_key"] == "intake_collecting"

