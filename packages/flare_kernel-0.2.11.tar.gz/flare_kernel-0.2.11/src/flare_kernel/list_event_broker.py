"""In-memory list invalidation event broker."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime

from flare_kernel.contracts import ListEventRecord, ListEventResource

_SUBSCRIBER_QUEUE_SIZE = 100
_subscribers: set[asyncio.Queue[ListEventRecord]] = set()


def _now_iso() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def build_list_event(
    *,
    resource: ListEventResource,
    reason: str,
    project_id: str = "",
    session_id: str = "",
) -> ListEventRecord:
    """Build a list invalidation event with normalized string fields."""

    return ListEventRecord(
        resource=resource,
        reason=str(reason or "").strip(),
        project_id=str(project_id or "").strip(),
        session_id=str(session_id or "").strip(),
        created_at=_now_iso(),
    )


def subscribe_list_events() -> asyncio.Queue[ListEventRecord]:
    """Register one SSE subscriber queue."""

    queue: asyncio.Queue[ListEventRecord] = asyncio.Queue(maxsize=_SUBSCRIBER_QUEUE_SIZE)
    _subscribers.add(queue)
    return queue


def unsubscribe_list_events(queue: asyncio.Queue[ListEventRecord]) -> None:
    """Remove one SSE subscriber queue."""

    _subscribers.discard(queue)


def publish_list_event(event: ListEventRecord) -> None:
    """Publish one list invalidation event to active subscribers."""

    for queue in list(_subscribers):
        if queue.full():
            try:
                queue.get_nowait()
            except asyncio.QueueEmpty:
                pass
        try:
            queue.put_nowait(event)
        except asyncio.QueueFull:
            pass


def publish_list_invalidation(
    *,
    resource: ListEventResource,
    reason: str,
    project_id: str = "",
    session_id: str = "",
) -> ListEventRecord:
    """Build and publish one list invalidation event."""

    event = build_list_event(
        resource=resource,
        reason=reason,
        project_id=project_id,
        session_id=session_id,
    )
    publish_list_event(event)
    return event


def reset_list_event_broker_for_testing() -> None:
    """Clear subscribers for isolated tests."""

    _subscribers.clear()
