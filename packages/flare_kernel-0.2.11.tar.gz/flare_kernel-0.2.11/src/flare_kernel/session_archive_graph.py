"""Deterministic relationship graph projection for archived sessions.

DOC HELPER — OBJ-06B archive graph boundary:

This module builds an archive-local relationship graph from normalized context
fields. It is a projection, not the final long-term knowledge graph.

Current graph semantics:
- fact --supports--> summary
- unknown --unresolved_in--> summary
- focus --frames--> summary
- current_question --asks_about--> unknown

Why projection first:
The archive must be useful before a full graph database/vector pipeline exists.
This graph gives the UI and future governance jobs a stable, inspectable shape
for "what connects to what" without inventing a global ontology.

What this file must not do:
- No cross-session merge or deduplication.
- No user/project/global storage decisions.
- No domain-pack concepts, supplier fields, procurement-specific labels, etc.
- No provider payload usage. Inputs must already be normalized context items.

Replacement guidance:
If a later graph engine exists, keep this contract as the archive projection
adapter or replace it behind `build_archive_relationship_graph`.
"""

from __future__ import annotations

from typing import Any


def _clean_text(value: Any) -> str:
    """Normalize graph text values.

    Args:
        value: Raw label/content value.

    Returns:
        Whitespace-normalized string.
    """

    return " ".join(str(value or "").split()).strip()


def _node(node_id: str, node_type: str, label: str, value: Any = None, evidence_ids: list[str] | None = None) -> dict[str, Any]:
    """Build one graph node.

    Args:
        node_id: Stable node identifier within the archive graph.
        node_type: Node category.
        label: Human readable label.
        value: Optional node value.
        evidence_ids: Optional evidence references.

    Returns:
        Graph node dictionary.
    """

    return {
        "id": node_id,
        "type": node_type,
        "label": label,
        "value": value,
        "evidence_ids": evidence_ids or [],
    }


def _edge(source: str, target: str, relation: str) -> dict[str, str]:
    """Build one directed graph edge.

    Args:
        source: Source node id.
        target: Target node id.
        relation: Relationship label.

    Returns:
        Graph edge dictionary.
    """

    return {"source": source, "target": target, "relation": relation}


def _claim_node_id(prefix: str, index: int, item: Any) -> str:
    """Resolve a stable claim node id.

    Args:
        prefix: Node id prefix.
        index: Claim index fallback.
        item: Claim-like dict or scalar.

    Returns:
        Stable node id.
    """

    if isinstance(item, dict) and _clean_text(item.get("id")):
        return f"{prefix}_{_clean_text(item.get('id'))}"
    return f"{prefix}_{index + 1}"


def _claim_text(item: Any) -> str:
    """Extract text from a claim-like item.

    Args:
        item: Claim dict or scalar.

    Returns:
        Claim text.
    """

    if isinstance(item, dict):
        return _clean_text(item.get("text") or item.get("content") or item.get("summary"))
    return _clean_text(item)


def _claim_evidence_ids(item: Any) -> list[str]:
    """Extract evidence ids from a claim-like item.

    Args:
        item: Claim dict or scalar.

    Returns:
        Evidence id list.
    """

    if not isinstance(item, dict) or not isinstance(item.get("evidence_ids"), list):
        return []
    return [_clean_text(value) for value in item.get("evidence_ids") if _clean_text(value)]


def build_archive_relationship_graph(
    *,
    summary: str,
    facts: list[Any],
    unknowns: list[Any],
    user_focus: list[Any],
    current_question: dict[str, Any] | None,
) -> dict[str, Any]:
    """Project archive facts, unknowns, focus, and question into a graph.

    Args:
        summary: Archive summary text.
        facts: Fact-like context items.
        unknowns: Unknown/open-question context items.
        user_focus: User focus strings.
        current_question: Latest strategy question, when available.

    Returns:
        Relationship graph with deterministic nodes and edges.
    """

    nodes = [_node("summary", "summary", "Archive Summary", summary)]
    edges: list[dict[str, str]] = []
    for index, item in enumerate(facts):
        node_id = _claim_node_id("fact", index, item)
        nodes.append(_node(node_id, "fact", _claim_text(item), _claim_text(item), _claim_evidence_ids(item)))
        edges.append(_edge(node_id, "summary", "supports"))
    for index, item in enumerate(unknowns):
        node_id = _claim_node_id("unknown", index, item)
        nodes.append(_node(node_id, "unknown", _claim_text(item), _claim_text(item), _claim_evidence_ids(item)))
        edges.append(_edge(node_id, "summary", "unresolved_in"))
    for index, item in enumerate(user_focus):
        node_id = f"focus_{index + 1}"
        nodes.append(_node(node_id, "focus", _clean_text(item), _clean_text(item)))
        edges.append(_edge(node_id, "summary", "frames"))
    question_text = _clean_text((current_question or {}).get("question_text"))
    if question_text:
        nodes.append(_node("current_question", "question", question_text, question_text))
        edges.append(_edge("current_question", "summary", "continues"))
        for index, _ in enumerate(unknowns):
            edges.append(_edge("current_question", _claim_node_id("unknown", index, unknowns[index]), "asks_about"))
    return {
        "schema_version": "session.relationship_graph.v1",
        "nodes": nodes,
        "edges": edges,
    }


__all__ = ["build_archive_relationship_graph"]
