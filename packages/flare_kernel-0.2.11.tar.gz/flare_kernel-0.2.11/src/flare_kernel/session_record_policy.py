"""Pure session record normalization policies."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts.context import create_empty_context

DEFAULT_SESSION_TITLE = "新会话"
TITLE_SOURCE_DEFAULT = "default"
TITLE_SOURCE_AUTO = "auto"
TITLE_SOURCE_MANUAL = "manual"
MAX_AUTO_TITLE_LENGTH = 24
MAX_PREVIEW_LENGTH = 80


def normalize_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def is_default_title(value: Any) -> bool:
    title = normalize_text(value)
    return not title or title in {DEFAULT_SESSION_TITLE, "调试会话", "寻源会话"}


def extract_auto_title(value: Any) -> str:
    text = normalize_text(value).lstrip("# ").strip()
    if not text:
        return ""
    if len(text) <= MAX_AUTO_TITLE_LENGTH:
        return text
    return f"{text[:MAX_AUTO_TITLE_LENGTH]}…"


def extract_preview(*, user_message: Any = "", assistant_message: Any = "") -> str:
    base = normalize_text(assistant_message) or normalize_text(user_message)
    if not base:
        return ""
    if len(base) <= MAX_PREVIEW_LENGTH:
        return base
    return f"{base[:MAX_PREVIEW_LENGTH]}..."


def find_reusable_draft_session(
    *,
    sessions: dict[str, dict[str, Any]],
    messages: dict[str, list[dict[str, Any]]],
    function_type: str | None,
    project_id: str | None,
    user_id: str | None,
    requested_title: str,
) -> dict[str, Any] | None:
    if not is_default_title(requested_title):
        return None
    resolved_function_type = normalize_text(function_type)
    resolved_project_id = normalize_text(project_id)
    resolved_user_id = normalize_text(user_id)
    candidates: list[dict[str, Any]] = []
    for record in sessions.values():
        if normalize_text(record.get("status")) != "active":
            continue
        if normalize_text(record.get("function_type")) != resolved_function_type:
            continue
        if normalize_text(record.get("project_id")) != resolved_project_id:
            continue
        if normalize_text(record.get("user_id")) != resolved_user_id:
            continue
        if not is_default_title(record.get("title")):
            continue
        session_id = normalize_text(record.get("session_id"))
        if not session_id or messages.get(session_id):
            continue
        candidates.append(record)
    if not candidates:
        return None
    candidates.sort(key=lambda item: str(item.get("updated_at") or ""), reverse=True)
    return dict(candidates[0])


def normalize_session_record(record: dict[str, Any]) -> dict[str, Any]:
    next_record = dict(record)
    if not normalize_text(next_record.get("title")):
        next_record["title"] = DEFAULT_SESSION_TITLE
    if "preview" not in next_record:
        next_record["preview"] = ""
    if not normalize_text(next_record.get("title_source")):
        next_record["title_source"] = (
            TITLE_SOURCE_DEFAULT if is_default_title(next_record.get("title")) else TITLE_SOURCE_MANUAL
        )
    if not normalize_text(next_record.get("status")):
        next_record["status"] = "active"
    if not isinstance(next_record.get("context"), dict):
        next_record["context"] = create_empty_context().model_dump()
    return next_record


__all__ = [
    "DEFAULT_SESSION_TITLE",
    "TITLE_SOURCE_AUTO",
    "TITLE_SOURCE_DEFAULT",
    "TITLE_SOURCE_MANUAL",
    "extract_auto_title",
    "extract_preview",
    "find_reusable_draft_session",
    "is_default_title",
    "normalize_session_record",
    "normalize_text",
]
