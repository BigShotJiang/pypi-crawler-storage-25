"""Kernel API contracts."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


class IntakeFieldValue(BaseModel):
    kind: Literal["single_choice", "multi_choice", "free_text", "number", "range", "candidate_ref"]
    value: Any = None
    display_value: str | None = None
    values: list[Any] | None = None
    text: str | None = None
    number: float | int | None = None
    min: float | int | None = None
    max: float | int | None = None
    unit: str | None = None
    currency: str | None = None
    candidate_id: str | None = None

    @model_validator(mode="after")
    def validate_shape(self) -> "IntakeFieldValue":
        if self.kind == "single_choice" and self.value in (None, ""):
            raise ValueError("single_choice requires value")
        if self.kind == "multi_choice" and not isinstance(self.values, list):
            raise ValueError("multi_choice requires values[]")
        if self.kind == "free_text" and not str(self.text or "").strip():
            raise ValueError("free_text requires text")
        if self.kind == "number" and self.number is None:
            raise ValueError("number requires number")
        if self.kind == "range" and (self.min is None or self.max is None):
            raise ValueError("range requires min and max")
        if self.kind == "candidate_ref" and not str(self.candidate_id or "").strip():
            raise ValueError("candidate_ref requires candidate_id")
        return self


class KernelRequest(BaseModel):
    contract_version: str = "flare.v1"
    content: str | None = None
    client_request_id: str | None = None
    run_id: str | None = None
    tenant_id: str = "default"
    instance_id: str = "default"
    domain_pack_version: str = "default"
    session_id: str | None = None
    last_turn_id: str | None = None
    command: str | None = None
    intent: str = "default"
    intent_override: str | None = None
    mode: str | None = None
    manual_mode: str | None = None
    current_mode: str | None = None
    project_id: str | None = None
    user_id: str | None = None
    retrieval_config: dict[str, Any] = Field(default_factory=dict)
    canvas_config: dict[str, Any] = Field(default_factory=dict)
    payload: dict[str, Any] = Field(default_factory=dict)
    entities: list[dict[str, Any] | str] = Field(default_factory=list)
    entity_query_mode: Literal["off", "prefer", "only"] = "prefer"
    context_refs: list[Any] = Field(default_factory=list)
    knowledge_refs: list[Any] = Field(default_factory=list)
    action_key: str | None = None
    target_mode: str | None = None
    action_status: str | None = None
    action_reason: str | None = None
    trace_id: str | None = None
    question_id: str | None = None
    field_key: str | None = None
    field_value: IntakeFieldValue | None = None

    @model_validator(mode="after")
    def normalize_top_level_content_into_payload(self) -> "KernelRequest":
        content = str(self.content or "").strip()
        if not content:
            return self
        payload = dict(self.payload or {})
        message = str(payload.get("message") or "").strip()
        if not message:
            payload["message"] = content
            self.payload = payload
        return self


class AnalysisRouteDecision(BaseModel):
    analysis_type: Literal["requirement", "sourcing"] = "requirement"
    template_id: str = ""
    reason_codes: list[str] = Field(default_factory=list)
    confidence: float = 0.0


class KernelResponse(BaseModel):
    trace_id: str
    state: Literal["RUNNING", "SUCCEEDED", "FAILED"]
    events: list[dict[str, Any]] = Field(default_factory=list)
    result: dict[str, Any] = Field(default_factory=dict)
    analysis_route: AnalysisRouteDecision | None = None
    next_actions: list[dict[str, Any]] = Field(default_factory=list)


class HealthResponse(BaseModel):
    status: Literal["healthy"]
    service: str
    trace_id: str
    llm_ready: bool
    postgres_ready: bool
    redis_ready: bool
    qdrant_ready: bool
    canvas_ready: bool
    rag_ready: bool
    plan_ready: bool


class KnowledgeIngestRequest(BaseModel):
    project_id: str = "default"
    user_id: str = "default"
    session_id: str = "default"
    source_id: str | None = None
    title: str | None = None
    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class KnowledgeIngestResponse(BaseModel):
    trace_id: str
    project_id: str
    user_id: str
    record_id: str
    chunk_count: int
    status: Literal["stored", "partial", "failed"]
    details: dict[str, Any] = Field(default_factory=dict)
    source_id: str | None = None
    error_code: str | None = None
    error_message: str | None = None


class KnowledgeSearchRequest(BaseModel):
    project_id: str = "default"
    user_id: str = "default"
    query: str
    top_k: int = 5


class KnowledgeSearchResponse(BaseModel):
    trace_id: str
    project_id: str
    user_id: str
    query: str
    results: list[dict[str, Any]] = Field(default_factory=list)


class SourcingSearchRequest(BaseModel):
    project_id: str = "default"
    user_id: str = "default"
    session_id: str = "default"
    instance_id: str = "default"
    query: str
    top_k: int = 8
    append_mode: bool = False
    lock_existing_order: bool = True
    base_result_ids: list[str] = Field(default_factory=list)
    source_scope: Literal["local", "web", "hybrid"] = "hybrid"
    sourcing_enabled: bool = False
    context_refs: list[Any] = Field(default_factory=list)
    knowledge_refs: list[Any] = Field(default_factory=list)
    source_ids: list[str] = Field(default_factory=list)
    entities: list[dict[str, Any] | str] = Field(default_factory=list)
    entity_query_mode: Literal["off", "prefer", "only"] = "prefer"
    provider_config: dict[str, Any] = Field(default_factory=dict)


class SourcingSearchResponse(BaseModel):
    trace_id: str
    retrieval_run_id: str
    project_id: str
    user_id: str
    session_id: str
    query: str
    effective_query: str = ""
    intent: str = ""
    sourcing_task_kind: str = "mixed"
    response_label: str = "候选条目"
    source_scope: Literal["local", "web", "hybrid"]
    sourcing_enabled: bool
    requested_top_k: int = 8
    returned_count: int = 0
    has_more: bool = False
    next_top_k: int = 8
    source_breakdown: dict[str, int] = Field(default_factory=dict)
    selected_source: str = ""
    source_priority: list[dict[str, Any]] = Field(default_factory=list)
    fallbacks: list[str] = Field(default_factory=list)
    provider_health: list[dict[str, Any]] = Field(default_factory=list)
    provider_trace: list[dict[str, Any]] = Field(default_factory=list)
    router_reason: str = ""
    final_status: Literal["completed", "partial", "blocked", "failed"] = "partial"
    observations: list[dict[str, Any]] = Field(default_factory=list)
    new_results: list[dict[str, Any]] = Field(default_factory=list)
    all_results: list[dict[str, Any]] = Field(default_factory=list)
    results: list[dict[str, Any]] = Field(default_factory=list)
    shortlist: list[dict[str, Any]] = Field(default_factory=list)
    canvas_state: dict[str, Any] = Field(default_factory=dict)
    context_patch: dict[str, Any] = Field(default_factory=dict)
    context_revision_id: str = ""
    blocked: bool = False
    reason: str = ""


class IntentSuggestResponse(BaseModel):
    trace_id: str
    suggested_mode: str
    confidence: float = 0.0
    reason: str = ""
    source: Literal[
        "intent_override",
        "manual",
        "current",
        "llm",
        "keywords",
        "keyword_priority",
        "keyword_fallback",
        "explicit_request",
        "explicit_required",
        "fuzzy_intent",
        "fallback",
    ] = "fallback"


class ProjectSourceRecord(BaseModel):
    id: str
    source_id: str
    project_id: str
    user_id: str
    session_id: str | None = None
    scope: str = "project"
    source: str = "local_upload"
    filename: str
    mime_type: str = ""
    size: int | None = None
    status: Literal["uploaded", "parsing", "chunked", "embedded", "indexed", "ready", "failed"] = "uploaded"
    error_code: str | None = None
    error_message: str = ""
    document_understanding: dict[str, Any] | None = None
    created_at: str
    updated_at: str
    persisted_to_project: bool = True


class ProjectSourceUploadResponse(BaseModel):
    data: ProjectSourceRecord


class ProjectSourcesResponse(BaseModel):
    sources: list[ProjectSourceRecord] = Field(default_factory=list)


class DeleteProjectSourceResponse(BaseModel):
    ok: bool = True
