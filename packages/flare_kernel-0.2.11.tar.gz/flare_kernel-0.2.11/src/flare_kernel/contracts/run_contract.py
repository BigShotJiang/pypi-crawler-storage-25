"""Run state and event replay contracts."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

RunState = Literal["queued", "running", "completed", "failed", "cancelled"]


class RunRecord(BaseModel):
    run_id: str
    session_id: str
    request_id: str = ""
    trace_id: str = ""
    state: RunState = "queued"
    error: str = ""
    created_at: str
    started_at: str = ""
    completed_at: str = ""
    updated_at: str


class RunEventRecord(BaseModel):
    event_id: str
    run_id: str
    session_id: str
    request_id: str = ""
    event_name: str
    sequence: int
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: str


class RunListResponse(BaseModel):
    runs: list[RunRecord] = Field(default_factory=list)


class RunEventListResponse(BaseModel):
    events: list[RunEventRecord] = Field(default_factory=list)
