"""Project API contracts."""

from __future__ import annotations

from pydantic import BaseModel, Field


class ProjectRecord(BaseModel):
    """Persisted Project row returned by the Project API.

    Attributes:
        project_id: Stable Project identifier used by frontend and backend routes.
        project_name: Human-readable Project name shown in the UI.
        status: Project lifecycle state, for example "active" or "archived".
        session_count: Number of sessions currently linked to this Project.
        created_at: ISO timestamp for Project creation when available.
        updated_at: ISO timestamp for the stored Project row update when available.
        latest_updated_at: Most recent Project activity timestamp, including sessions.
    """

    project_id: str
    project_name: str
    status: str = "active"
    session_count: int = 0
    created_at: str | None = None
    updated_at: str | None = None
    latest_updated_at: str | None = None


class ProjectUpsertRequest(BaseModel):
    """Request body for creating or updating a Project.

    Attributes:
        project_name: Optional replacement Project display name.
        status: Project lifecycle state to persist; defaults to "active".
    """

    project_name: str | None = None
    status: str = "active"


class ProjectsResponse(BaseModel):
    """Response body for listing Projects.

    Attributes:
        projects: Persisted Project records visible in the current user scope.
    """

    projects: list[ProjectRecord] = Field(default_factory=list)
