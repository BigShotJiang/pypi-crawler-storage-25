"""Canonical context contract for kernel orchestration.

DOC HELPER — OBJ-09/SRC-06 context schema boundary.
This contract is the canonical shape for session-scoped context. Runtime layers
may append patches, but fields must be declared here before they can survive
validation and become reusable backend state.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ContextEvidenceItem(BaseModel):
    id: str
    source_id: str = ""
    source: str = ""
    snippet: str = ""
    meta: dict[str, Any] = Field(default_factory=dict)


class ContextClaimItem(BaseModel):
    id: str
    text: str
    source_id: str = ""
    evidence_ids: list[str] = Field(default_factory=list)
    confidence: float | None = None
    meta: dict[str, Any] = Field(default_factory=dict)


class ContextTurnItem(BaseModel):
    turn_id: str
    user_message: str = ""
    assistant_message: str = ""
    source_ids: list[str] = Field(default_factory=list)
    created_at: str = ""


class ContextSourcingResult(BaseModel):
    id: str = ""
    round: int = 0
    retrieval_run_id: str = ""
    query: str = ""
    sourcing_task_kind: str = ""
    source_scope: str = ""
    requested_top_k: int = 0
    returned_count: int = 0
    new_count: int = 0
    has_more: bool = False
    next_top_k: int = 0
    source_breakdown: dict[str, int] = Field(default_factory=dict)
    selected_source: str = ""
    source_priority: list[dict[str, Any]] = Field(default_factory=list)
    fallbacks: list[str] = Field(default_factory=list)
    provider_health: list[dict[str, Any]] = Field(default_factory=list)
    provider_trace: list[dict[str, Any]] = Field(default_factory=list)
    items: list[dict[str, Any]] = Field(default_factory=list)
    shortlist: list[dict[str, Any]] = Field(default_factory=list)
    timestamp: str = ""


class ContextAnalysisResult(BaseModel):
    version: int
    payload: dict[str, Any] = Field(default_factory=dict)
    timestamp: str


class ContextContract(BaseModel):
    context_revision_id: str = ""
    session_summary: str = ""
    user_focus: list[str] = Field(default_factory=list)
    response_priorities: list[str] = Field(default_factory=list)
    confirmed_fields: dict[str, Any] = Field(default_factory=dict)
    missing_fields: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    turns: list[ContextTurnItem] = Field(default_factory=list)
    evidence: list[ContextEvidenceItem] = Field(default_factory=list)
    facts: list[ContextClaimItem] = Field(default_factory=list)
    inferences: list[ContextClaimItem] = Field(default_factory=list)
    unknowns: list[ContextClaimItem] = Field(default_factory=list)
    source_attributions: list[dict[str, Any]] = Field(default_factory=list)
    artifact_context: list[dict[str, Any]] = Field(default_factory=list)
    track: dict[str, Any] = Field(default_factory=dict)
    sourcing_results: list[ContextSourcingResult] = Field(default_factory=list)
    analysis_results: list[ContextAnalysisResult] = Field(default_factory=list)
    rank_profile: dict[str, Any] = Field(default_factory=dict)
    rank_feedback_log: list[dict[str, Any]] = Field(default_factory=list)
    archive_summary: dict[str, Any] = Field(default_factory=dict)
    updated_at: str = ""


def create_empty_context() -> ContextContract:
    return ContextContract()
