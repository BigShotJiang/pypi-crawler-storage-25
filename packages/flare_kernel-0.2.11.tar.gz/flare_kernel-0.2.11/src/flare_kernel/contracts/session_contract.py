"""Session API contracts.

DOC HELPER — OBJ-09 context authority persistence boundary.
Session message contracts may carry backend context authority metadata; callers
must treat it as a read-only projection, not an alternate context writer.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

from flare_kernel.contracts.context import ContextContract, create_empty_context


class SessionRecord(BaseModel):
    session_id: str
    project_id: str | None = None
    title: str
    preview: str = ""
    title_source: Literal["default", "auto", "manual"] = "default"
    status: str = "active"
    user_id: str | None = None
    function_type: str | None = None
    context: ContextContract = Field(default_factory=create_empty_context)
    created_at: str
    updated_at: str


class SessionCreateRequest(BaseModel):
    function_type: str | None = None
    project_id: str | None = None
    title: str | None = None
    user_id: str | None = None


class SessionUpdateRequest(BaseModel):
    """Request contract for patching session metadata."""

    function_type: str | None = None
    status: str | None = None
    title: str | None = None
    preview: str | None = None
    title_source: Literal["default", "auto", "manual"] | None = None


class SessionLifecycleRequest(BaseModel):
    """Explicit lifecycle command for archive/restore operations.

    Fields:
        action: Lifecycle action string. Supported values are validated by
            session_lifecycle_policy to keep the API contract extensible.
    """

    action: str


class SessionListResponse(BaseModel):
    sessions: list[SessionRecord] = Field(default_factory=list)


class SessionMessageRecord(BaseModel):
    message_id: str
    session_id: str
    run_id: str = ""
    role: str
    content: str
    attachments: list[dict[str, Any]] = Field(default_factory=list)
    context_refs: list[dict[str, Any]] = Field(default_factory=list)
    knowledge_refs: list[dict[str, Any]] = Field(default_factory=list)
    agent_status: dict[str, Any] | None = None
    thinking_trace: str = ""
    execution_trace: dict[str, Any] | None = None
    knowledge_search: dict[str, Any] | None = None
    sourcing_candidates: dict[str, Any] | None = None
    knowledge_citation: dict[str, Any] | None = None
    canvas_state: dict[str, Any] | None = None
    analysis_payload: dict[str, Any] | None = None
    context_usage: dict[str, Any] | None = None
    provider_trace: dict[str, Any] | None = None
    context_authority: dict[str, Any] | None = None
    plan_payload: dict[str, Any] | None = None
    created_at: str


class SessionMessageListResponse(BaseModel):
    messages: list[SessionMessageRecord] = Field(default_factory=list)


class SessionReplayTurn(BaseModel):
    """One replayable user/assistant turn with diagnostic metadata.

    Fields:
        turn_index: One-based turn index.
        user_message: User message for the turn, when present.
        assistant_message: Assistant message for the turn, when present.
        diagnostics: Read-only replay diagnostics for strategy review.
    """

    turn_index: int
    user_message: SessionMessageRecord | None = None
    assistant_message: SessionMessageRecord | None = None
    run: dict[str, Any] = Field(default_factory=dict)
    diagnostics: dict[str, Any] = Field(default_factory=dict)


class SessionReplayResponse(BaseModel):
    """Read-only session replay projection.

    Fields:
        session: Session metadata and final context snapshot.
        messages: Raw persisted messages for the session.
        turns: User/assistant message pairs for review.
        diagnostics: Replay-level counts and trace coverage summary.
    """

    session: SessionRecord
    messages: list[SessionMessageRecord] = Field(default_factory=list)
    turns: list[SessionReplayTurn] = Field(default_factory=list)
    diagnostics: dict[str, Any] = Field(default_factory=dict)


class SessionAppendExchangeRequest(BaseModel):
    run_id: str = ""
    user_message: str = ""
    assistant_message: str = ""
    attachments: list[dict[str, Any]] = Field(default_factory=list)
    context_refs: list[dict[str, Any]] = Field(default_factory=list)
    knowledge_refs: list[dict[str, Any]] = Field(default_factory=list)
    agent_status: dict[str, Any] | None = None
    thinking_trace: str = ""
    execution_trace: dict[str, Any] | None = None
    knowledge_search: dict[str, Any] | None = None
    sourcing_candidates: dict[str, Any] | None = None
    knowledge_citation: dict[str, Any] | None = None
    canvas_state: dict[str, Any] | None = None
    analysis_payload: dict[str, Any] | None = None
    context_usage: dict[str, Any] | None = None
    provider_trace: dict[str, Any] | None = None
    context_authority: dict[str, Any] | None = None
    plan_payload: dict[str, Any] | None = None
    reasoning_result: dict[str, Any] | None = None
    document_result: dict[str, Any] | None = None
    track_result: dict[str, Any] | None = None
    context_patch: dict[str, Any] | None = None
    context_snapshot: dict[str, Any] | None = None
