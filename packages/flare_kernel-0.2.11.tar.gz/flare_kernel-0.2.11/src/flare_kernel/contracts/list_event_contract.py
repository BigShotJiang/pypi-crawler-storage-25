"""List invalidation event contracts."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


ListEventResource = Literal["sessions", "projects", "all"]


class ListEventRecord(BaseModel):
    """Server-triggered list invalidation event.

    The event is an invalidation signal only. Clients must refresh canonical
    list APIs instead of treating this payload as authoritative list state.
    """

    schema_version: Literal["list_event.v1"] = "list_event.v1"
    event_type: Literal["list_invalidated"] = "list_invalidated"
    resource: ListEventResource
    project_id: str = ""
    session_id: str = ""
    reason: str = ""
    created_at: str
