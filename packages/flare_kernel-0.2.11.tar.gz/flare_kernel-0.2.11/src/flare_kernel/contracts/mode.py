"""Canonical mode contract and dispatch for kernel orchestration."""

from __future__ import annotations

from typing import Any, Callable, Literal

from flare_kernel.contracts.context import ContextContract

Mode = Literal["plan", "sourcing", "analysis"]
ModeHandler = Callable[[ContextContract, dict[str, Any]], ContextContract]


def _missing_handler(_context: ContextContract, _payload: dict[str, Any]) -> ContextContract:
    raise ValueError("mode handler not implemented")


mode_handlers: dict[Mode, ModeHandler] = {
    "plan": _missing_handler,
    "sourcing": _missing_handler,
    "analysis": _missing_handler,
}


def run_mode(
    mode: Mode,
    handlers: dict[Mode, ModeHandler],
    context: ContextContract,
    payload: dict[str, Any] | None = None,
) -> ContextContract:
    if mode not in handlers:
        raise ValueError(f"unsupported mode: {mode}")
    return handlers[mode](context, payload or {})
