"""Project Memory contracts for OBJ-03."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ProjectMemoryCandidate(BaseModel):
    """Runtime Project Memory candidate before durable scope is applied.

    Attributes:
        memory_type: Category used by recall and presentation.
        content: Normalized memory text to be considered for persistence.
        evidence: Optional source snippets that support the candidate.
        confidence: Optional confidence score from the extraction path.
        source_session_id: Session that produced the candidate, when available.
        source_message_id: Message that produced the candidate, when available.
        source_id: Source document or runtime artifact id, when available.
    """

    memory_type: str = "fact"
    content: str
    evidence: list[dict[str, Any]] = Field(default_factory=list)
    confidence: float | None = None
    source_session_id: str = ""
    source_message_id: str = ""
    source_id: str = ""


class ProjectMemoryRecord(BaseModel):
    """Durable Project Memory record stored under project and user scope.

    Attributes:
        memory_id: Stable Project Memory identifier.
        project_id: Project scope that owns the memory.
        user_id: User scope that owns the memory.
        source_session_id: Session that produced the memory, when available.
        source_message_id: Message that produced the memory, when available.
        source_id: Source document or runtime artifact id, when available.
        memory_type: Category used by recall and presentation.
        content: Durable memory text.
        evidence: Optional source snippets that support the memory.
        confidence: Optional confidence score.
        status: Lifecycle status, such as active or archived.
        created_at: Creation timestamp in ISO string format.
        updated_at: Last update timestamp in ISO string format.
    """

    memory_id: str
    project_id: str
    user_id: str
    source_session_id: str = ""
    source_message_id: str = ""
    source_id: str = ""
    memory_type: str = "fact"
    content: str
    evidence: list[dict[str, Any]] = Field(default_factory=list)
    confidence: float | None = None
    status: str = "active"
    created_at: str
    updated_at: str


class ProjectMemoryRecall(BaseModel):
    """Project Memory recall payload consumed by context assembly.

    Attributes:
        project_id: Project scope used for recall.
        user_id: User scope used for recall.
        query: Normalized recall query.
        hit_count: Number of memory records included in the payload.
        memory_ids: Ordered identifiers for the recalled memories.
        memories: Presentation-safe memory snippets.
        degraded: True when recall failed and returned an empty fallback.
    """

    project_id: str
    user_id: str
    query: str
    hit_count: int = 0
    memory_ids: list[str] = Field(default_factory=list)
    memories: list[dict[str, Any]] = Field(default_factory=list)
    degraded: bool = False
