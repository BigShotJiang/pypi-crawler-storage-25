"""Authorization capability contracts."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class AuthPrincipal(BaseModel):
    provider: str
    external_subject: str
    user_id: str | None = None
    tenant_id: str = "default"
    instance_id: str = "default"
    display_name: str | None = None


class AuthContext(BaseModel):
    contract_version: str = "auth.context.v0"
    principal: AuthPrincipal
    project_id: str | None = None
    session_id: str | None = None
    scopes: list[str] = Field(default_factory=list)
    claims: dict[str, Any] = Field(default_factory=dict)


class AuthorizationDecision(BaseModel):
    contract_version: str = "auth.decision.v0"
    allowed: bool
    reason: str
    reason_codes: list[str] = Field(default_factory=list)
    allowed_scopes: list[str] = Field(default_factory=list)
    denied_scopes: list[str] = Field(default_factory=list)
    required_context_fields: list[str] = Field(default_factory=list)


class AuthExchangeRequest(BaseModel):
    provider: str
    external_subject: str
    user_id: str | None = None
    tenant_id: str = "default"
    instance_id: str = "default"
    project_id: str | None = None
    session_id: str | None = None
    scopes: list[str] = Field(default_factory=list)
    claims: dict[str, Any] = Field(default_factory=dict)
    display_name: str | None = None


class AuthExchangeResponse(BaseModel):
    contract_version: str = "auth.exchange.v0"
    auth_context: AuthContext
    authorization: AuthorizationDecision
    access_token: str | None = None
    token_type: Literal["none", "bearer"] = "none"
    token_status: Literal["not_issued", "external_required"] = "not_issued"
