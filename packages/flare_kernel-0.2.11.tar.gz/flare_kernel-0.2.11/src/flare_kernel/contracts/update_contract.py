"""Update plane contracts."""

from __future__ import annotations

from pydantic import BaseModel, Field


class VersionConstraint(BaseModel):
    min_version: str = ""
    max_version: str = ""


class ReleaseManifestEntry(BaseModel):
    version: str
    channel: str = "stable"
    minimum_supported_version: str = ""
    breaking_changes: bool = False
    required_migrations: list[str] = Field(default_factory=list)
    recommended_tests: list[str] = Field(default_factory=list)
    rollback_supported: bool = True
    release_notes_url: str = ""


class UpdateCheckRequest(BaseModel):
    current_version: str
    target_channel: str = "stable"
    compatibility_constraints: VersionConstraint = Field(default_factory=VersionConstraint)
    releases: list[ReleaseManifestEntry] = Field(default_factory=list)


class UpdateCheckResult(BaseModel):
    current_version: str
    latest_version: str = ""
    update_available: bool = False
    upgradeable: bool = False
    reason: str = ""
    breaking_changes: bool = False
    required_migrations: list[str] = Field(default_factory=list)
    recommended_tests: list[str] = Field(default_factory=list)
    rollback_supported: bool = False
    release_notes_url: str = ""


class UpgradePlanStep(BaseModel):
    action: str
    description: str
    required: bool = True


class UpgradePlanRequest(UpdateCheckRequest):
    dry_run: bool = True


class UpgradePlanResult(UpdateCheckResult):
    dry_run: bool = True
    steps: list[UpgradePlanStep] = Field(default_factory=list)
