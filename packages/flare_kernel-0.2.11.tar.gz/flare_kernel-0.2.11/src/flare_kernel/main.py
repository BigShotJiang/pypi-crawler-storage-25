"""ASGI entrypoint."""

from flare_kernel.app import create_app

app = create_app()
