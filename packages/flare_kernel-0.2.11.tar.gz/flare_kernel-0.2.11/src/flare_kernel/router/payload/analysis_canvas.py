"""Analysis canvas payload orchestration bridge.

DOC HELPER — ANL-02/ANL-03 kernel-to-engine analysis payload boundary.
This bridge normalizes runtime/session context into the analysis engine input
contract. It does not render frontend state, persist context, or own analysis
template/domain decisions.
"""

from __future__ import annotations

from typing import Any

from flare_engines import build_analysis_canvas_payload
from flare_kernel.runtime.orchestration.canvas.toolbar_actions import (
    build_canvas_toolbar_actions,
    build_canvas_workspace_capabilities,
)


def _coerce_context_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    return {}


def _coerce_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _merge_lists(*values: Any) -> list[Any]:
    merged: list[Any] = []
    for value in values:
        for item in _coerce_list(value):
            merged.append(item)
    return merged


def _has_candidate_identity(item: Any) -> bool:
    if not isinstance(item, dict):
        return False
    role = str(item.get("result_role") or item.get("sourcing_result_role") or "").strip().lower()
    if role:
        return role == "candidate"
    identity = (
        item.get("supplier_id")
        or item.get("supplier_name")
        or item.get("vendor_id")
        or item.get("vendor_name")
        or item.get("company_id")
        or item.get("company_name")
    )
    return bool(str(identity or "").strip())


def _candidate_rows(*values: Any) -> list[Any]:
    return [item for item in _merge_lists(*values) if _has_candidate_identity(item)]


def _candidate_only_sourcing_round(result: Any) -> dict[str, Any]:
    if not isinstance(result, dict):
        return {}
    return {
        **result,
        "items": _candidate_rows(result.get("items")),
        "shortlist": _candidate_rows(result.get("shortlist")),
    }


def _candidate_only_session_context(session_context: dict[str, Any]) -> dict[str, Any]:
    rounds = [
        round_value
        for round_value in map(_candidate_only_sourcing_round, _coerce_list(session_context.get("sourcing_results")))
        if round_value
    ]
    return {**session_context, "sourcing_results": rounds} if rounds else session_context


def _resolve_session_context(snapshot: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    if isinstance(snapshot.get("session_context"), dict):
        return snapshot.get("session_context") or {}
    if isinstance(payload.get("session_context"), dict):
        return payload.get("session_context") or {}
    return {}


def _resolve_latest_sourcing_candidates(payload: dict[str, Any], session_context: dict[str, Any]) -> list[Any]:
    candidates = _candidate_rows(payload.get("sourcing_candidates"))
    if candidates:
        return candidates
    latest_result = _latest_sourcing_result(session_context)
    return _candidate_rows(latest_result.get("shortlist"), latest_result.get("items"))


def _latest_sourcing_result(session_context: dict[str, Any]) -> dict[str, Any]:
    for result in reversed(_coerce_list(session_context.get("sourcing_results"))):
        if isinstance(result, dict):
            return result
    return {}


def _resolve_sourcing_trace(payload: dict[str, Any], session_context: dict[str, Any]) -> dict[str, Any]:
    direct_trace = _coerce_context_dict(payload.get("sourcing_trace"))
    if direct_trace:
        return direct_trace
    latest_result = _latest_sourcing_result(session_context)
    if not latest_result:
        return {}
    return {
        "source_meta": {
            "source_breakdown": _coerce_context_dict(latest_result.get("source_breakdown")),
            "retrieval_batch": str(latest_result.get("retrieval_run_id") or latest_result.get("id") or "").strip(),
            "query_profile": str(latest_result.get("query") or "").strip(),
            "selected_source": str(latest_result.get("selected_source") or "").strip(),
            "source_priority": _coerce_list(latest_result.get("source_priority")),
            "fallbacks": _coerce_list(latest_result.get("fallbacks")),
            "provider_trace": _coerce_list(latest_result.get("provider_trace")),
        },
        "selected_source": str(latest_result.get("selected_source") or "").strip(),
        "source_priority": _coerce_list(latest_result.get("source_priority")),
        "fallbacks": _coerce_list(latest_result.get("fallbacks")),
        "provider_trace": _coerce_list(latest_result.get("provider_trace")),
        "retrieval_batch": str(latest_result.get("retrieval_run_id") or latest_result.get("id") or "").strip(),
    }


def _resolve_analysis_context(
    *,
    analysis_route: dict[str, Any] | None,
    orchestration_status: dict[str, Any] | None,
    runtime_snapshot: dict[str, Any] | None,
) -> dict[str, Any]:
    status = _coerce_context_dict(orchestration_status)
    snapshot = _coerce_context_dict(runtime_snapshot)
    payload = _coerce_context_dict(snapshot.get("payload"))
    route = _coerce_context_dict(analysis_route)
    session_context = _resolve_session_context(snapshot, payload)
    analysis_session_context = _candidate_only_session_context(session_context)
    detected_intent = _coerce_context_dict(status.get("detected_intent"))
    return {
        "analysis_type": str(route.get("analysis_type") or "requirement").strip().lower(),
        "template_id": str(route.get("template_id") or "").strip(),
        "mode": str(detected_intent.get("mode") or payload.get("mode") or "").strip(),
        "intent": str(detected_intent.get("intent") or "").strip(),
        "fields": _coerce_context_dict(payload.get("fields")),
        "field_entities": _coerce_context_dict(status.get("field_entities")),
        "criteria": payload.get("criteria"),
        "evaluation_criteria": payload.get("evaluation_criteria"),
        "priority_weights": payload.get("priority_weights"),
        "sourcing_candidates": _resolve_latest_sourcing_candidates(payload, session_context),
        "sourcing_trace": _resolve_sourcing_trace(payload, session_context),
        "session_context": analysis_session_context,
        "artifact_context": _merge_lists(
            payload.get("artifact_context"),
            session_context.get("artifact_context"),
        ),
        "analysis_results": _merge_lists(session_context.get("analysis_results")),
        "document_result": _coerce_context_dict(payload.get("document_result")),
        "user_template": _coerce_context_dict(payload.get("user_template")),
        "required_missing": (
            status.get("required_missing")
            if isinstance(status.get("required_missing"), list)
            else (payload.get("required_missing") if isinstance(payload.get("required_missing"), list) else [])
        ),
        "retrieved_knowledge": (
            payload.get("retrieved_knowledge")
            if isinstance(payload.get("retrieved_knowledge"), list)
            else []
        ),
        "structured_retrieved_knowledge": (
            status.get("structured_retrieved_knowledge")
            if isinstance(status.get("structured_retrieved_knowledge"), list)
            else []
        ),
        "evidence_refs": _merge_lists(
            payload.get("evidence_refs"),
            session_context.get("evidence"),
            session_context.get("source_attributions"),
        ),
    }


def build_canvas_analysis_payload(
    *,
    analysis_route: dict[str, Any] | None,
    content_text: str,
    previous_payload: dict[str, Any] | None = None,
    orchestration_status: dict[str, Any] | None = None,
    runtime_snapshot: dict[str, Any] | None = None,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    context = _resolve_analysis_context(
        analysis_route=analysis_route,
        orchestration_status=orchestration_status,
        runtime_snapshot=runtime_snapshot,
    )
    context["generated_markdown"] = str(content_text or "").strip()
    payload, slot_patches = build_analysis_canvas_payload(
        analysis_type=str(context.get("analysis_type") or "requirement"),
        template_id=str(context.get("template_id") or ""),
        context=context,
        previous_payload=previous_payload,
        placeholder="—",
    )
    if isinstance(payload, dict):
        toolbar_actions = build_canvas_toolbar_actions(
            copy=True,
            edit=True,
            export_markdown=True,
            fullscreen=True,
        )
        payload = {
            **payload,
            "toolbar_actions": toolbar_actions,
            "workspace_capabilities": build_canvas_workspace_capabilities(toolbar_actions=toolbar_actions),
        }
    return payload, slot_patches


__all__ = ["build_canvas_analysis_payload"]
