"""Action target mode and payload shaping helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest


def resolve_action_target_mode(req: KernelRequest) -> str:
    target_mode = req.target_mode
    if isinstance(target_mode, str):
        normalized = target_mode.strip()
        if normalized in {"requirement_intake", "analysis_mode", "intelligent_sourcing"}:
            return normalized

    action_key = req.action_key if isinstance(req.action_key, str) else ""
    if action_key == "handoff_to_sourcing":
        return "intelligent_sourcing"
    if action_key == "handoff_to_domain_flow":
        return "intelligent_sourcing"
    if action_key == "continue_collection":
        return "requirement_intake"
    if action_key == "confirm_plan":
        return "analysis_mode"
    if action_key == "generate_analysis":
        return "analysis_mode"
    if action_key == "confirm_sourcing":
        return "intelligent_sourcing"
    if action_key == "confirm_domain_flow":
        return "intelligent_sourcing"

    return req.intent if isinstance(req.intent, str) and req.intent.strip() else "default"


def _normalize_key(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip().lower().replace("-", "_").replace(" ", "_")


def _extract_value(raw_value: Any) -> Any:
    if isinstance(raw_value, dict):
        for candidate in ("value", "content", "text"):
            candidate_value = raw_value.get(candidate)
            if candidate_value not in (None, "", [], {}):
                return candidate_value
    return raw_value


def _resolve_sourcing_base_field_keys(payload: dict[str, Any]) -> tuple[str, ...]:
    explicit = payload.get("sourcing_base_field_keys")
    if isinstance(explicit, list):
        normalized = [str(item).strip() for item in explicit if str(item).strip()]
        if normalized:
            return tuple(dict.fromkeys(normalized))
    return ()


def collect_sourcing_base_fields_from_payload(payload: dict[str, Any]) -> dict[str, Any]:
    base_field_keys = _resolve_sourcing_base_field_keys(payload)
    if not base_field_keys:
        return {}

    raw_base_fields = payload.get("base_fields")
    if isinstance(raw_base_fields, dict):
        return dict(raw_base_fields)

    base_fields: dict[str, Any] = {}
    raw_fields = payload.get("fields")

    if isinstance(raw_fields, dict):
        for key in base_field_keys:
            if key not in raw_fields:
                continue
            value = _extract_value(raw_fields.get(key))
            if value not in (None, "", [], {}):
                base_fields[key] = value
    elif isinstance(raw_fields, list):
        for raw_item in raw_fields:
            if not isinstance(raw_item, dict):
                continue
            field_key = ""
            for candidate in ("field_key", "name", "id", "key", "label"):
                candidate_value = raw_item.get(candidate)
                if isinstance(candidate_value, str) and candidate_value.strip():
                    field_key = candidate_value.strip()
                    break
            normalized_key = _normalize_key(field_key)
            if normalized_key not in set(base_field_keys):
                continue
            value = _extract_value(raw_item.get("value", raw_item.get("content", raw_item.get("text"))))
            if value not in (None, "", [], {}):
                base_fields[normalized_key] = value

    for key in base_field_keys:
        if key in base_fields:
            continue
        value = payload.get(key)
        if value not in (None, "", [], {}):
            base_fields[key] = value

    return base_fields


def build_action_payload(
    req: KernelRequest,
    target_mode: str,
    *,
    collect_sourcing_base_fields: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    payload = dict(req.payload) if isinstance(req.payload, dict) else {}
    payload["function_type"] = target_mode
    payload["target_mode"] = target_mode
    if isinstance(req.action_key, str) and req.action_key.strip():
        payload["action_key"] = req.action_key.strip()
    if isinstance(req.action_status, str) and req.action_status.strip():
        payload["action_status"] = req.action_status.strip()
    if isinstance(req.action_reason, str) and req.action_reason.strip():
        payload["action_reason"] = req.action_reason.strip()
    if isinstance(req.action_key, str) and req.action_key.strip() == "confirm_sourcing":
        payload["sourcing_confirmed"] = True
    if isinstance(req.retrieval_config, dict) and req.retrieval_config:
        payload["retrieval_config"] = dict(req.retrieval_config)
    if isinstance(req.canvas_config, dict) and req.canvas_config:
        payload["canvas_config"] = dict(req.canvas_config)

    if target_mode == "intelligent_sourcing":
        collect_fn = collect_sourcing_base_fields or collect_sourcing_base_fields_from_payload
        base_fields = collect_fn(payload)
        if base_fields:
            payload["base_fields"] = base_fields

    return payload
