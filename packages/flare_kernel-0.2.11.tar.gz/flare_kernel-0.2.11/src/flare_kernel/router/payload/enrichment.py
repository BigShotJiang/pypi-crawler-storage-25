"""Kernel request payload enrichment helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest


def extract_source_ids_from_payload(payload: dict[str, Any] | None) -> list[str]:
    if not isinstance(payload, dict):
        return []
    source_ids: list[str] = []
    seen: set[str] = set()

    def _append(raw_value: Any) -> None:
        value = str(raw_value or "").strip()
        if not value or value in seen:
            return
        seen.add(value)
        source_ids.append(value)

    knowledge_refs = payload.get("knowledge_refs")
    if isinstance(knowledge_refs, list):
        for item in knowledge_refs:
            if isinstance(item, dict):
                _append(item.get("source_id") or item.get("id"))
                continue
            _append(item)

    context_refs = payload.get("context_refs")
    if isinstance(context_refs, list):
        for item in context_refs:
            if isinstance(item, dict):
                _append(item.get("source_id") or item.get("id"))
                continue
            _append(item)

    return source_ids


def apply_current_question_message_answer(
    payload: dict[str, Any],
    *,
    command: str,
    resolved_mode: str,
    message: str,
    is_intake_control_message_fn: Callable[[str], bool] | None = None,
) -> dict[str, Any]:
    if command == "submit_intake_answer" or resolved_mode != "requirement_intake":
        return payload
    if isinstance(payload.get("question_answer"), dict):
        return payload
    current_question = payload.get("current_question")
    if not isinstance(current_question, dict):
        return payload
    field_key = str(current_question.get("field_key") or "").strip()
    question_kind = str(current_question.get("question_kind") or "").strip()
    raw_value = str(message or "").strip()
    if not field_key or not raw_value:
        return payload
    if is_intake_control_message_fn is not None and is_intake_control_message_fn(raw_value):
        return payload
    payload["question_answer"] = {
        "question_id": str(current_question.get("question_id") or "").strip(),
        "question_revision": str(current_question.get("question_revision") or current_question.get("revision") or "").strip(),
        "field_key": field_key,
        "field_value": raw_value,
        "raw_value": raw_value,
    }
    if question_kind:
        payload["question_answer"]["question_kind"] = question_kind
    branch_node_key = str(current_question.get("branch_node_key") or "").strip()
    if branch_node_key:
        payload["question_answer"]["branch_node_key"] = branch_node_key
    return payload


def enrich_payload(
    req: KernelRequest,
    *,
    resolved_mode: str,
    retrieved_knowledge: list[dict[str, Any]] | None = None,
    resolve_command_fn: Callable[[KernelRequest], str],
    safe_session_id_fn: Callable[[Any], str],
    resolve_trace_id_fn: Callable[[Any], str],
    resolve_intake_session_id_fn: Callable[..., str],
    load_latest_intake_session_id_fn: Callable[..., str | None],
    load_intake_session_snapshot_fn: Callable[..., Any],
    hydrate_payload_from_authoritative_intake_state_fn: Callable[..., dict[str, Any]],
    load_intake_checkpoint_fn: Callable[..., Any],
    hydrate_payload_from_authoritative_checkpoint_state_fn: Callable[..., dict[str, Any]],
    has_active_intake_payload_fn: Callable[[dict[str, Any] | None], bool],
    normalize_field_value_payload_fn: Callable[[Any], tuple[str, str]],
    apply_question_answer_payload_fn: Callable[[dict[str, Any]], dict[str, Any]],
    apply_workspace_patch_payload_fn: Callable[[dict[str, Any]], dict[str, Any]],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    resolve_intake_allowed_fields_fn: Callable[[dict[str, Any]], set[str] | None],
    extract_intake_fields_from_message_fn: Callable[..., dict[str, Any]],
    normalize_extracted_field_values_fn: Callable[[dict[str, Any]], dict[str, Any]],
    merge_into_confirmed_fields_fn: Callable[[dict[str, Any], dict[str, Any]], tuple[dict[str, Any], dict[str, Any]]],
    merge_supplementary_fields_fn: Callable[[Any, Any], dict[str, Any]],
    merge_inferred_requirements_fn: Callable[[Any, Any], list[str]],
    canonicalize_payload_fields_fn: Callable[[dict[str, Any]], dict[str, Any]],
    resolve_intent_override_fn: Callable[[KernelRequest], str],
    resolve_manual_mode_fn: Callable[[KernelRequest], str],
    resolve_current_mode_fn: Callable[[KernelRequest], str],
    is_intake_control_message_fn: Callable[[str], bool] | None = None,
) -> dict[str, Any]:
    payload = dict(req.payload) if isinstance(req.payload, dict) else {}
    command = resolve_command_fn(req)
    safe_session_id = safe_session_id_fn(req.session_id)
    intake_session_id = resolve_intake_session_id_fn(
        payload=payload,
        session_id=safe_session_id,
        trace_id=resolve_trace_id_fn(req.trace_id),
        command=command,
        resolved_mode=resolved_mode,
        latest_persisted_intake_session_id=load_latest_intake_session_id_fn(session_id=safe_session_id),
        has_active_intake_payload=has_active_intake_payload_fn(payload),
    )
    persisted_intake_snapshot = load_intake_session_snapshot_fn(
        intake_session_id=intake_session_id,
        session_id=safe_session_id,
    )
    if persisted_intake_snapshot is not None:
        payload = hydrate_payload_from_authoritative_intake_state_fn(
            payload=payload,
            persisted_payload=persisted_intake_snapshot.payload,
            persisted_status=persisted_intake_snapshot.orchestration_status,
        )
    persisted_checkpoint_snapshot = load_intake_checkpoint_fn(intake_session_id=intake_session_id)
    if persisted_checkpoint_snapshot is not None:
        payload = hydrate_payload_from_authoritative_checkpoint_state_fn(
            payload=payload,
            checkpoint_snapshot=persisted_checkpoint_snapshot,
        )
    if intake_session_id:
        payload["intake_session_id"] = intake_session_id
        if not isinstance(payload.get("intake_session_completed"), bool):
            payload["intake_session_completed"] = False
        if not str(payload.get("intake_session_state") or "").strip():
            payload["intake_session_state"] = "started"

    if command == "submit_intake_answer":
        question_id = str((payload.get("question_id") or req.question_id or "")).strip()
        question_revision = str((payload.get("question_revision") or getattr(req, "question_revision", "") or "")).strip()
        field_key = str((payload.get("field_key") or req.field_key or "")).strip()
        question_answer_payload = payload.get("question_answer") if isinstance(payload.get("question_answer"), dict) else {}
        if not question_revision:
            question_revision = str(question_answer_payload.get("question_revision") or question_answer_payload.get("revision") or "").strip()
        question_kind = str(question_answer_payload.get("question_kind") or payload.get("question_kind") or "").strip()
        branch_node_key = str(question_answer_payload.get("branch_node_key") or payload.get("branch_node_key") or "").strip()
        selected_option_value = str(question_answer_payload.get("selected_option_value") or "").strip()
        raw_field_value = payload.get("field_value")
        if raw_field_value is None and req.field_value is not None:
            raw_field_value = req.field_value.model_dump()
        field_value, display_value = normalize_field_value_payload_fn(raw_field_value)
        raw_value_text = field_value or display_value
        if not raw_value_text and selected_option_value:
            raw_value_text = selected_option_value
        if field_key and (display_value or raw_value_text):
            payload["question_id"] = question_id
            payload["question_answer"] = {
                "question_id": question_id,
                "question_revision": question_revision,
                "field_key": field_key,
                "field_value": display_value or field_value,
                "raw_value": raw_value_text,
            }
        elif isinstance(question_answer_payload, dict):
            payload["question_answer"] = dict(question_answer_payload)
        if isinstance(payload.get("question_answer"), dict):
            if question_kind:
                payload["question_answer"]["question_kind"] = question_kind
            if branch_node_key:
                payload["question_answer"]["branch_node_key"] = branch_node_key
            if selected_option_value:
                payload["question_answer"]["selected_option_value"] = selected_option_value

    round_control = payload.get("round_control") if isinstance(payload.get("round_control"), dict) else {}
    round_control_action = str(
        round_control.get("action")
        or payload.get("round_control_action")
        or ""
    ).strip().lower()
    if round_control_action == "interrupt":
        payload["round_control"] = {
            "action": "interrupt",
            "source": str(round_control.get("source") or "user").strip() or "user",
        }
        payload["interrupt_collection"] = True
        payload["resume_collection"] = False
        payload["intake_session_state"] = "interrupted_by_user"
    elif round_control_action == "resume":
        payload["round_control"] = {
            "action": "resume",
            "source": str(round_control.get("source") or "user").strip() or "user",
        }
        payload["resume_collection"] = True
        payload["interrupt_collection"] = False
        if not str(payload.get("intake_session_state") or "").strip():
            payload["intake_session_state"] = "workspace_live_updating"

    payload = apply_current_question_message_answer(
        payload,
        command=command,
        resolved_mode=resolved_mode,
        message=extract_user_message_fn(payload),
        is_intake_control_message_fn=is_intake_control_message_fn,
    )
    payload = apply_question_answer_payload_fn(payload)
    payload = apply_workspace_patch_payload_fn(payload)
    if resolved_mode == "requirement_intake":
        message = extract_user_message_fn(payload)
        allowed_fields = resolve_intake_allowed_fields_fn(payload)
        normalized_extraction = normalize_extracted_field_values_fn(
            extract_intake_fields_from_message_fn(
                message,
                context={
                    "mode": resolved_mode,
                    "allowed_fields": allowed_fields,
                },
            )
        )
        existing_fields = payload.get("fields")
        merged_fields, extracted_sources = merge_into_confirmed_fields_fn(
            existing_fields if isinstance(existing_fields, dict) else {},
            normalized_extraction,
        )
        payload["fields"] = merged_fields
        existing_sources = payload.get("field_sources")
        next_sources = dict(existing_sources) if isinstance(existing_sources, dict) else {}
        for field_key, source in extracted_sources.items():
            if field_key not in next_sources:
                next_sources[field_key] = source
        if next_sources:
            payload["field_sources"] = next_sources
        payload["supplementary_fields"] = merge_supplementary_fields_fn(
            payload.get("supplementary_fields"),
            normalized_extraction.get("supplementary_fields"),
        )
        payload["inferred_requirements"] = merge_inferred_requirements_fn(
            payload.get("inferred_requirements"),
            normalized_extraction.get("inferred_requirements"),
        )
        required_missing = payload.get("required_missing")
        if isinstance(required_missing, list):
            payload["required_missing"] = [
                item
                for item in required_missing
                if str(item).strip() and merged_fields.get(str(item).strip()) in (None, "", [], {})
            ]
        payload = canonicalize_payload_fields_fn(payload)

    payload["function_type"] = resolved_mode
    payload["mode"] = resolved_mode
    if isinstance(req.project_id, str) and req.project_id.strip():
        payload["project_id"] = req.project_id.strip()
    if isinstance(req.user_id, str) and req.user_id.strip():
        payload["user_id"] = req.user_id.strip()
    if isinstance(req.knowledge_refs, list) and req.knowledge_refs:
        payload["knowledge_refs"] = list(req.knowledge_refs)
    if isinstance(req.retrieval_config, dict) and req.retrieval_config:
        payload["retrieval_config"] = dict(req.retrieval_config)
    if isinstance(req.canvas_config, dict) and req.canvas_config:
        payload["canvas_config"] = dict(req.canvas_config)

    intent_override = resolve_intent_override_fn(req)
    if intent_override:
        payload["intent_override"] = intent_override
    manual_mode = resolve_manual_mode_fn(req)
    current_mode = resolve_current_mode_fn(req)
    if manual_mode:
        payload["manual_mode"] = manual_mode
    if current_mode:
        payload["current_mode"] = current_mode
    if retrieved_knowledge:
        payload["retrieved_knowledge"] = retrieved_knowledge
        if resolved_mode == "intelligent_sourcing":
            existing_candidates = payload.get("sourcing_candidates")
            if not isinstance(existing_candidates, list) or not existing_candidates:
                payload["sourcing_candidates"] = list(retrieved_knowledge)
    source_ids = extract_source_ids_from_payload(payload)
    if source_ids:
        payload["source_ids"] = source_ids
    return payload
