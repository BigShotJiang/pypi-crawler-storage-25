"""Kernel route execution helpers."""

from __future__ import annotations

from typing import Any

from fastapi.responses import StreamingResponse

from flare_kernel.contracts import KernelRequest, KernelResponse
from flare_kernel.router.kernel_route.action import (
    build_kernel_action_response as build_kernel_action_response_from_router,
)
from flare_kernel.router.kernel_route.run import (
    build_kernel_run_response as build_kernel_run_response_from_router,
)
from flare_kernel.router.kernel_route.stream import (
    build_kernel_stream_response as build_kernel_stream_response_from_router,
)


async def build_kernel_run_response(
    *,
    req: KernelRequest,
    turn: dict[str, Any],
    resolved_intent: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    resolved_mode: str,
    mode_source: str,
    should_force_requirement_clarification_fn,
    build_requirement_clarification_message_fn,
    build_prompt_fn,
    build_mode_switch_reason_fn,
    build_canonical_state_fn,
    sync_session_intent_stage_fn,
    persist_authoritative_intake_state_fn,
) -> KernelResponse:
    return await build_kernel_run_response_from_router(
        req=req,
        turn=turn,
        resolved_intent=resolved_intent,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        should_force_requirement_clarification_fn=should_force_requirement_clarification_fn,
        build_requirement_clarification_message_fn=build_requirement_clarification_message_fn,
        build_prompt_fn=build_prompt_fn,
        build_mode_switch_reason_fn=build_mode_switch_reason_fn,
        build_canonical_state_fn=build_canonical_state_fn,
        sync_session_intent_stage_fn=sync_session_intent_stage_fn,
        persist_authoritative_intake_state_fn=persist_authoritative_intake_state_fn,
    )


async def build_kernel_action_response(
    *,
    req: KernelRequest,
    action_context: dict[str, Any],
    build_prompt_fn,
    sync_session_intent_stage_fn,
    persist_authoritative_intake_state_fn,
) -> KernelResponse:
    return await build_kernel_action_response_from_router(
        req=req,
        action_context=action_context,
        build_prompt_fn=build_prompt_fn,
        sync_session_intent_stage_fn=sync_session_intent_stage_fn,
        persist_authoritative_intake_state_fn=persist_authoritative_intake_state_fn,
    )


async def build_kernel_stream_response(
    *,
    req: KernelRequest,
    turn: dict[str, Any],
    resolved_intent: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    resolved_mode: str,
    mode_source: str,
    patch_scopes: set[str],
    build_patch_event_fn,
    safe_session_id_fn,
    build_mode_switch_reason_fn,
    build_canonical_state_fn,
    should_force_requirement_clarification_fn,
    build_requirement_clarification_message_fn,
    build_prompt_fn,
    sync_session_intent_stage_fn,
    persist_authoritative_intake_state_fn,
) -> StreamingResponse:
    return await build_kernel_stream_response_from_router(
        req=req,
        turn=turn,
        resolved_intent=resolved_intent,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        patch_scopes=patch_scopes,
        build_patch_event_fn=build_patch_event_fn,
        safe_session_id_fn=safe_session_id_fn,
        build_mode_switch_reason_fn=build_mode_switch_reason_fn,
        build_canonical_state_fn=build_canonical_state_fn,
        should_force_requirement_clarification_fn=should_force_requirement_clarification_fn,
        build_requirement_clarification_message_fn=build_requirement_clarification_message_fn,
        build_prompt_fn=build_prompt_fn,
        sync_session_intent_stage_fn=sync_session_intent_stage_fn,
        persist_authoritative_intake_state_fn=persist_authoritative_intake_state_fn,
    )
