"""Kernel /stream route execution helper."""

from __future__ import annotations

from typing import Any

from fastapi.responses import StreamingResponse

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime import generate_llm_completion, generate_llm_completion_stream, get_logger, persist_memory_record
from flare_kernel.runtime.llm.config import bool_env
from flare_kernel.router.completion.guided import (
    resolve_guided_orchestrated_completion as resolve_guided_orchestrated_completion_from_router,
    should_persist_memory_record as should_persist_memory_record_from_router,
)
from flare_kernel.router.completion.stream_collect import collect_stream_completion
from flare_kernel.router.orchestration.trace.core import (
    build_agent_step_trace as build_agent_step_trace_from_router,
    build_llm_execution_trace as build_llm_execution_trace_from_router,
    build_orchestration_execution_trace as build_orchestration_execution_trace_from_router,
    build_retrieval_execution_trace as build_retrieval_execution_trace_from_router,
    build_skill_step_trace as build_skill_step_trace_from_router,
    resolve_skill_for_step as resolve_skill_for_step_from_router,
    resolve_step_for_event as resolve_step_for_event_from_router,
)
from flare_kernel.router.retrieval.projection import (
    build_knowledge_citations as build_knowledge_citations_from_router,
    build_source_breakdown as build_source_breakdown_from_router,
)
from flare_kernel.router.streaming.response.builder import (
    build_kernel_streaming_response as build_kernel_streaming_response_from_router,
)
from flare_kernel.router.text_safety import (
    sanitize_customer_visible_text as sanitize_customer_visible_text_from_router,
    sanitize_product_name_for_prompt as sanitize_product_name_for_prompt_from_router,
)


def _resolve_turn_value(turn: dict[str, Any], key: str, default: Any = None) -> Any:
    value = turn.get(key, default)
    return value


def _resolve_dict_value(data: dict[str, Any], key: str) -> dict[str, Any]:
    value = data.get(key)
    return value if isinstance(value, dict) else {}


def _resolve_list_value(data: dict[str, Any], key: str) -> list[Any]:
    value = data.get(key)
    return value if isinstance(value, list) else []


async def _generate_llm_completion_via_provider_stream(
    prompt: str,
    *,
    trace_id: str,
    session_id: str,
    intent: str,
    on_delta_fn=None,
):
    return await collect_stream_completion(
        generate_llm_completion_stream,
        prompt,
        trace_id=trace_id,
        session_id=session_id,
        intent=intent,
        on_delta_fn=on_delta_fn,
    )


async def _generate_llm_completion_via_standard(
    prompt: str,
    *,
    trace_id: str,
    session_id: str,
    intent: str,
    on_delta_fn=None,
):
    _ = on_delta_fn
    return await generate_llm_completion(prompt, trace_id=trace_id, session_id=session_id, intent=intent)


def _resolve_stream_completion_fn():
    if bool_env("KERNEL_STREAM_USE_PROVIDER_STREAMING", True):
        return _generate_llm_completion_via_provider_stream
    return _generate_llm_completion_via_standard


async def build_kernel_stream_response(
    *,
    req: KernelRequest,
    turn: dict[str, Any],
    resolved_intent: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    resolved_mode: str,
    mode_source: str,
    patch_scopes: set[str],
    build_patch_event_fn,
    safe_session_id_fn,
    build_mode_switch_reason_fn,
    build_canonical_state_fn,
    should_force_requirement_clarification_fn,
    build_requirement_clarification_message_fn,
    build_prompt_fn,
    sync_session_intent_stage_fn,
    persist_authoritative_intake_state_fn,
) -> StreamingResponse:
    trace_id = str(_resolve_turn_value(turn, "trace_id"))
    session_id = str(_resolve_turn_value(turn, "session_id"))
    instance_profile = _resolve_turn_value(turn, "instance_profile")
    raw_message = str(_resolve_turn_value(turn, "raw_message"))
    project_id = str(_resolve_turn_value(turn, "project_id"))
    user_id = str(_resolve_turn_value(turn, "user_id"))
    retrieval_config = _resolve_dict_value(turn, "retrieval_config")
    retrieval_queries = _resolve_list_value(turn, "retrieval_queries")
    retrieval_attempted = bool(_resolve_turn_value(turn, "retrieval_attempted"))
    retrieved_knowledge = _resolve_list_value(turn, "retrieved_knowledge")
    enriched_payload = _resolve_dict_value(turn, "enriched_payload")
    runtime_snapshot = _resolve_dict_value(turn, "runtime_snapshot")
    orchestration_status = _resolve_dict_value(turn, "orchestration_status")
    escalation_signal = _resolve_dict_value(turn, "escalation_signal")
    effective_command = str(_resolve_turn_value(turn, "effective_command"))
    structured_retrieved_knowledge = _resolve_list_value(turn, "structured_retrieved_knowledge")
    logger = get_logger("flare_kernel.router.kernel")
    logger.info(
        "kernel.stream trace_id=%s session_id=%s intent=%s mode=%s mode_source=%s instance_id=%s has_instance_profile=%s",
        trace_id,
        session_id,
        resolved_intent,
        resolved_mode,
        mode_source,
        req.instance_id,
        bool(instance_profile),
    )
    return build_kernel_streaming_response_from_router(
        req=req,
        trace_id=trace_id,
        session_id=session_id,
        instance_profile=instance_profile,
        resolved_intent=resolved_intent,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        raw_message=raw_message,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        project_id=project_id,
        user_id=user_id,
        retrieval_config=retrieval_config,
        retrieval_queries=retrieval_queries,
        retrieval_attempted=retrieval_attempted,
        retrieved_knowledge=retrieved_knowledge,
        enriched_payload=enriched_payload,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        escalation_signal=escalation_signal,
        effective_command=effective_command,
        structured_retrieved_knowledge=structured_retrieved_knowledge,
        build_patch_event_fn=build_patch_event_fn,
        safe_session_id_fn=safe_session_id_fn,
        patch_scopes=patch_scopes,
        build_mode_switch_reason_fn=build_mode_switch_reason_fn,
        build_canonical_state_fn=build_canonical_state_fn,
        build_orchestration_execution_trace_fn=build_orchestration_execution_trace_from_router,
        build_agent_step_trace_fn=build_agent_step_trace_from_router,
        build_skill_step_trace_fn=build_skill_step_trace_from_router,
        resolve_skill_for_step_fn=resolve_skill_for_step_from_router,
        resolve_step_for_event_fn=resolve_step_for_event_from_router,
        build_retrieval_execution_trace_fn=build_retrieval_execution_trace_from_router,
        build_knowledge_citations_fn=build_knowledge_citations_from_router,
        build_source_breakdown_fn=build_source_breakdown_from_router,
        build_llm_execution_trace_fn=build_llm_execution_trace_from_router,
        resolve_guided_orchestrated_completion_fn=resolve_guided_orchestrated_completion_from_router,
        should_persist_memory_record_fn=should_persist_memory_record_from_router,
        should_force_requirement_clarification_fn=should_force_requirement_clarification_fn,
        build_requirement_clarification_message_fn=build_requirement_clarification_message_fn,
        build_prompt_fn=build_prompt_fn,
        generate_llm_completion_fn=_resolve_stream_completion_fn(),
        persist_memory_record_fn=persist_memory_record,
        sanitize_customer_visible_text_fn=sanitize_customer_visible_text_from_router,
        sanitize_product_name_for_prompt_fn=sanitize_product_name_for_prompt_from_router,
        sync_session_intent_stage_fn=sync_session_intent_stage_fn,
        persist_authoritative_intake_state_fn=persist_authoritative_intake_state_fn,
    )
