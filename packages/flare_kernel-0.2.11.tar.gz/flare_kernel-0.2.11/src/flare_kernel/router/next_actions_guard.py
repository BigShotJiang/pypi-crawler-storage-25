"""Next-action guard helpers for output-safe action lists."""

from __future__ import annotations

from typing import Any


def dedupe_next_actions_by_action_key(actions: list[dict[str, Any]] | Any) -> list[dict[str, Any]]:
    """Keep the first action per action_key/type while preserving order."""
    if not isinstance(actions, list):
        return []
    deduped: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    for item in actions:
        if not isinstance(item, dict):
            continue
        action_key = str(item.get("action_key") or item.get("type") or "").strip()
        if action_key:
            if action_key in seen_keys:
                continue
            seen_keys.add(action_key)
        deduped.append(item)
    return deduped


__all__ = ["dedupe_next_actions_by_action_key"]
