"""Async intent routing helpers used by kernel endpoints."""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from flare_kernel.contracts import KernelRequest


def _requires_explicit_sourcing(mode: str) -> bool:
    return str(mode or "").strip() == "intelligent_sourcing"


def _is_analysis_mode(mode: str) -> bool:
    return str(mode or "").strip() == "analysis_mode"


def _is_intake_mode(mode: str) -> bool:
    return str(mode or "").strip() == "requirement_intake"


def _default_for_implicit_sourcing() -> tuple[str, float, str, str]:
    return "default", 0.0, "寻源模式需要显式开启。", "explicit_required"


def _contains_any(message: str, terms: tuple[str, ...]) -> bool:
    return any(term and term in message for term in terms)


def _is_negated_analysis_request(message: str) -> bool:
    return _contains_any(message, ("先别分析", "先别做分析", "不要分析", "别分析", "不用分析"))


def _resolve_explicit_canvas_suggestion(message: str) -> tuple[str, float, str, str] | None:
    if _contains_any(message, ("智能寻源", "供应商寻源", "帮我寻源", "开始寻源", "进入寻源")):
        return "intelligent_sourcing", 0.86, "识别到明确寻源请求，建议进入智能寻源。", "explicit_request"
    if _contains_any(message, ("找供应商", "寻找供应商", "推荐供应商", "供应商推荐", "有哪些厂家", "找厂家")):
        return "intelligent_sourcing", 0.82, "识别到明确供应商寻找请求，建议进入智能寻源。", "explicit_request"
    if not _is_negated_analysis_request(message) and _contains_any(
        message,
        ("需求分析", "帮我分析", "做分析", "开始分析", "进入分析", "分析"),
    ):
        return "analysis_mode", 0.84, "识别到明确分析请求，建议进入分析画布。", "explicit_request"
    return None


async def resolve_request_intent_with_ai(
    req: KernelRequest,
    trace_id: str,
    *,
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    normalize_message_for_intent_fn: Callable[[KernelRequest, str], str],
    looks_like_small_talk_fn: Callable[[str], bool],
    resolve_requirement_intake_entry_recommendation_fn: Callable[..., tuple[str, float, str, str]],
    contains_any_text_fn: Callable[[str, tuple[str, ...]], bool],
    requirement_entry_structuring_terms: tuple[str, ...],
    infer_intent_by_keywords_fn: Callable[[str], str],
    requirement_entry_context_terms: tuple[str, ...],
    generate_llm_completion_fn: Callable[..., Awaitable[Any]],
    build_intent_classifier_prompt_fn: Callable[[str], str],
    extract_json_object_fn: Callable[[str], dict[str, Any]],
    coerce_suggestable_mode_fn: Callable[[Any], str],
    build_keyword_suggestion_fn: Callable[[str], tuple[str, float, str, str]],
) -> tuple[str, str, float, str]:
    explicit_intent = ""
    if isinstance(req.intent, str):
        raw_intent = req.intent.strip()
        if raw_intent and raw_intent.lower() != "default":
            explicit_intent = raw_intent
    if explicit_intent:
        return explicit_intent, "explicit_intent", 1.0, "请求已明确指定意图。"

    message = extract_user_message_fn(req.payload)
    if not message:
        return "default", "fallback", 0.0, "消息为空，无法判断模式。"
    normalized_message = normalize_message_for_intent_fn(req, message)
    if looks_like_small_talk_fn(normalized_message):
        return "default", "fallback", 0.0, "识别为闲聊/寒暄，保持普通对话。"
    intake_mode, intake_confidence, intake_reason, intake_source = resolve_requirement_intake_entry_recommendation_fn(
        message=normalized_message
    )
    if _is_intake_mode(intake_mode) and intake_source == "explicit_request":
        return intake_mode, intake_source, intake_confidence, intake_reason
    if _is_intake_mode(intake_mode) and intake_source == "fuzzy_intent":
        if contains_any_text_fn(normalized_message, requirement_entry_structuring_terms):
            return intake_mode, intake_source, intake_confidence, intake_reason
        return "default", intake_source, intake_confidence, intake_reason
    keyword_mode = infer_intent_by_keywords_fn(normalized_message)
    if keyword_mode == "requirement_intake" and _is_intake_mode(intake_mode) and intake_source == "fuzzy_intent":
        keyword_mode = ""
    if keyword_mode == "requirement_intake":
        return keyword_mode, "keyword_priority", 0.74, "命中需求梳理关键词，优先进入梳理阶段。"
    has_requirement_context = contains_any_text_fn(normalized_message, requirement_entry_context_terms)
    if intake_mode == "default" and not keyword_mode and has_requirement_context:
        return "default", "fallback", 0.0, "未识别到明确模式意图。"

    completion = await generate_llm_completion_fn(
        build_intent_classifier_prompt_fn(normalized_message),
        trace_id=trace_id,
        session_id=req.session_id,
        intent="intent_router",
    )
    if completion.status == "ok":
        payload = extract_json_object_fn(completion.content)
        mode = coerce_suggestable_mode_fn(payload.get("mode"))
        if mode != "default":
            if _requires_explicit_sourcing(mode):
                fallback_mode, confidence, reason, source = _default_for_implicit_sourcing()
                return fallback_mode, source, confidence, reason
            if _is_intake_mode(mode) and _is_intake_mode(intake_mode) and intake_source == "fuzzy_intent":
                return "default", intake_source, intake_confidence, intake_reason
            try:
                confidence = max(0.0, min(1.0, float(payload.get("confidence", 0.82))))
            except (TypeError, ValueError):
                confidence = 0.82
            reason = str(payload.get("reason") or "模型识别到明确意图。").strip()
            return mode, "llm", confidence, reason

    fallback_mode, fallback_confidence, fallback_reason, _ = build_keyword_suggestion_fn(normalized_message)
    if _requires_explicit_sourcing(fallback_mode):
        mode, confidence, reason, source = _default_for_implicit_sourcing()
        return mode, source, confidence, reason
    return fallback_mode, "keyword_fallback", fallback_confidence, fallback_reason


async def resolve_intent_suggestion(
    req: KernelRequest,
    trace_id: str,
    *,
    resolve_intent_override_fn: Callable[[KernelRequest], str],
    resolve_manual_mode_fn: Callable[[KernelRequest], str],
    resolve_current_mode_fn: Callable[[KernelRequest], str],
    suggestable_modes: set[str],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    normalize_message_for_intent_fn: Callable[[KernelRequest, str], str],
    looks_like_small_talk_fn: Callable[[str], bool],
    resolve_requirement_intake_entry_recommendation_fn: Callable[..., tuple[str, float, str, str]],
    infer_intent_by_keywords_fn: Callable[[str], str],
    generate_llm_completion_fn: Callable[..., Awaitable[Any]],
    build_intent_classifier_prompt_fn: Callable[[str], str],
    extract_json_object_fn: Callable[[str], dict[str, Any]],
    coerce_suggestable_mode_fn: Callable[[Any], str],
    build_keyword_suggestion_fn: Callable[[str], tuple[str, float, str, str]],
) -> tuple[str, float, str, str]:
    intent_override = resolve_intent_override_fn(req)
    if intent_override in suggestable_modes:
        return intent_override, 1.0, "外部意图已指定模式。", "intent_override"

    message = extract_user_message_fn(req.payload)
    if not message:
        manual_mode = resolve_manual_mode_fn(req)
        if manual_mode in suggestable_modes:
            return manual_mode, 0.9, "当前手动模式已明确。", "manual"
        current_mode = resolve_current_mode_fn(req)
        if current_mode in suggestable_modes:
            return current_mode, 0.75, "沿用当前模式上下文。", "current"
        return "default", 0.0, "消息为空，无法判断模式。", "fallback"
    normalized_message = normalize_message_for_intent_fn(req, message)
    if looks_like_small_talk_fn(normalized_message):
        return "default", 0.0, "识别为闲聊/寒暄，保持普通对话。", "fallback"
    explicit_canvas_suggestion = _resolve_explicit_canvas_suggestion(normalized_message)
    if explicit_canvas_suggestion is not None:
        return explicit_canvas_suggestion
    intake_mode, intake_confidence, intake_reason, intake_source = resolve_requirement_intake_entry_recommendation_fn(
        message=normalized_message
    )
    if _is_intake_mode(intake_mode):
        return intake_mode, intake_confidence, intake_reason, intake_source
    keyword_mode = infer_intent_by_keywords_fn(normalized_message)
    if keyword_mode == "requirement_intake":
        return keyword_mode, 0.74, "命中需求梳理关键词，建议先进入梳理。", "keyword_priority"

    manual_mode = resolve_manual_mode_fn(req)
    if manual_mode in suggestable_modes:
        return manual_mode, 0.9, "当前手动模式已明确。", "manual"

    current_mode = resolve_current_mode_fn(req)
    if current_mode in suggestable_modes:
        return current_mode, 0.75, "沿用当前模式上下文。", "current"

    completion = await generate_llm_completion_fn(
        build_intent_classifier_prompt_fn(normalized_message),
        trace_id=trace_id,
        session_id=req.session_id,
        intent="intent_suggestion",
    )
    if completion.status == "ok":
        payload = extract_json_object_fn(completion.content)
        mode = coerce_suggestable_mode_fn(payload.get("mode"))
        if mode != "default":
            if _requires_explicit_sourcing(mode):
                return _default_for_implicit_sourcing()
            try:
                confidence = max(0.0, min(1.0, float(payload.get("confidence", 0.75))))
            except (TypeError, ValueError):
                confidence = 0.75
            reason = str(payload.get("reason") or "模型识别到明确意图，建议开启对应模式。").strip()
            return mode, confidence, reason, "llm"

    fallback_mode, fallback_confidence, fallback_reason, fallback_source = build_keyword_suggestion_fn(normalized_message)
    if _requires_explicit_sourcing(fallback_mode):
        return _default_for_implicit_sourcing()
    if _is_analysis_mode(fallback_mode):
        return fallback_mode, fallback_confidence, fallback_reason, fallback_source
    return fallback_mode, fallback_confidence, fallback_reason, fallback_source
