"""Router intent module group."""

from __future__ import annotations

import importlib
import sys

_LEGACY_MODULE_TARGETS = {
    "session_intent": "flare_kernel.router.intent.session_intent.core",
    "session_intent_fields": "flare_kernel.router.intent.session_intent.fields",
    "session_intent_small_talk": "flare_kernel.router.intent.session_intent.small_talk",
    "intent_classifier_utils": "flare_kernel.router.intent.classifier_utils",
    "intent_routing": "flare_kernel.router.intent.routing",
    "intent_escalation_override": "flare_kernel.router.intent.escalation.override",
    "intent_escalation_pipeline": "flare_kernel.router.intent.escalation.pipeline",
    "intent_escalation_signal": "flare_kernel.router.intent.escalation.signal",
}

for _legacy_name, _target in _LEGACY_MODULE_TARGETS.items():
    sys.modules.setdefault(
        f"flare_kernel.router.intent.{_legacy_name}",
        importlib.import_module(_target),
    )
