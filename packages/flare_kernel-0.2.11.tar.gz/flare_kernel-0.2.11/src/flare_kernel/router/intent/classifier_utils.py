"""Utility helpers for intent classification and keyword fallback."""

from __future__ import annotations

import json
import re
from typing import Any, Callable


def infer_intent_by_keywords(normalized_message: str, *, intent_keywords: dict[str, tuple[str, ...]]) -> str:
    if not normalized_message:
        return ""
    for intent_key, keywords in intent_keywords.items():
        for keyword in keywords:
            if keyword and keyword in normalized_message:
                return intent_key
    return ""


def coerce_suggestable_mode(raw_mode: Any, *, suggestable_modes: set[str]) -> str:
    if not isinstance(raw_mode, str):
        return "default"
    normalized = raw_mode.strip().lower().replace("-", "_").replace(" ", "_")
    if normalized in suggestable_modes:
        return normalized
    return "default"


def extract_json_object(raw_text: str) -> dict[str, Any]:
    text = str(raw_text or "").strip()
    if not text:
        return {}
    try:
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]*\}", text)
        if not match:
            return {}
        try:
            parsed = json.loads(match.group(0))
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            return {}


def build_intent_classifier_prompt(message: str) -> str:
    return (
        "你是通用编排助手的意图路由器。"
        "请判断用户输入是否明确要求进入 `requirement_intake`（需求梳理），"
        "`intelligent_sourcing`（智能寻源），或 `analysis_mode`（分析画布），"
        "否则返回 `default`。"
        "不要因为检索、搜索、采购、供应商等词自动返回智能寻源；"
        "智能寻源必须有明确找供应商/寻源意图。\n"
        "仅返回 JSON，不要附加解释。格式："
        '{"mode":"default|requirement_intake|intelligent_sourcing|analysis_mode","confidence":0~1,"reason":"简短中文原因"}\n'
        f"用户输入：{message}"
    )


def build_keyword_suggestion(
    message: str,
    *,
    resolve_requirement_intake_entry_recommendation_fn: Callable[[str], tuple[str, float, str, str]],
    infer_intent_by_keywords_fn: Callable[[str], str],
) -> tuple[str, float, str, str]:
    intake_mode, confidence, reason, source = resolve_requirement_intake_entry_recommendation_fn(message)
    if intake_mode == "requirement_intake":
        return intake_mode, confidence, reason or "识别到梳理模式入口信号。", source
    inferred = infer_intent_by_keywords_fn(message.lower())
    if inferred:
        return inferred, 0.62, "命中基础意图规则，建议开启对应模式。", "keywords"
    return "default", 0.0, "未识别到明确模式意图。", "fallback"
