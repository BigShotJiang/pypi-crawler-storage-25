"""Classifier-field helpers for session intent resolution."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.domain.domain_pack_loader import load_domain_pack, resolve_domain_pack_domain
from flare_kernel.runtime.orchestration.session_context_runtime import load_session_context_snapshot


def normalize_field_keys(items: list[Any] | tuple[Any, ...] | None) -> tuple[str, ...]:
    if not items:
        return ()
    normalized: list[str] = []
    seen: set[str] = set()
    for item in items:
        text = str(item or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        normalized.append(text)
    return tuple(normalized)


def resolve_classifier_required_fields(
    *,
    req: KernelRequest,
    runtime_snapshot: dict[str, Any] | None,
    orchestration_status: dict[str, Any] | None,
    normalize_field_keys_fn: Callable[[list[Any] | tuple[Any, ...] | None], tuple[str, ...]],
    fallback_required_fields: tuple[str, ...] = (),
) -> tuple[str, ...]:
    if isinstance(orchestration_status, dict):
        from_status = orchestration_status.get("required_fields")
        if isinstance(from_status, list):
            normalized = normalize_field_keys_fn(from_status)
            if normalized:
                return normalized
    if isinstance(runtime_snapshot, dict):
        payload = runtime_snapshot.get("payload") if isinstance(runtime_snapshot.get("payload"), dict) else {}
        from_payload = payload.get("required_fields") if isinstance(payload, dict) else None
        if isinstance(from_payload, list):
            normalized = normalize_field_keys_fn(from_payload)
            if normalized:
                return normalized
        domain_pack = runtime_snapshot.get("domain_pack") if isinstance(runtime_snapshot.get("domain_pack"), dict) else {}
        from_pack = (domain_pack.get("fields") or {}).get("required_fields") if isinstance(domain_pack, dict) else None
        if isinstance(from_pack, list):
            normalized = normalize_field_keys_fn(from_pack)
            if normalized:
                return normalized
    domain_pack = load_domain_pack(
        instance_id=req.instance_id,
        domain_pack_version=req.domain_pack_version,
        domain=resolve_domain_pack_domain(payload=req.payload),
        payload=req.payload if isinstance(req.payload, dict) else {},
        tenant_id=req.tenant_id,
    )
    required = domain_pack.required_fields()
    normalized = normalize_field_keys_fn(required)
    if normalized:
        return normalized
    return fallback_required_fields


def resolve_classifier_known_fields(
    *,
    req: KernelRequest,
    message: str,
    orchestration_status: dict[str, Any] | None,
    normalize_extracted_field_values_fn: Callable[[dict[str, Any]], dict[str, Any]],
    extract_intake_fields_from_message_fn: Callable[[str, dict[str, Any] | None], dict[str, Any]],
    normalize_field_keys_fn: Callable[[list[Any] | tuple[Any, ...] | None], tuple[str, ...]],
) -> tuple[str, ...]:
    known_fields: set[str] = set()
    payload = req.payload if isinstance(req.payload, dict) else {}
    payload_fields = payload.get("fields")
    if isinstance(payload_fields, dict):
        for key, value in payload_fields.items():
            field_key = str(key or "").strip()
            if field_key and value not in (None, "", [], {}):
                known_fields.add(field_key)
    confirmed_fields = payload.get("confirmed_fields")
    if isinstance(confirmed_fields, dict):
        for key, value in confirmed_fields.items():
            field_key = str(key or "").strip()
            if field_key and value not in (None, "", [], {}):
                known_fields.add(field_key)
    session_context = load_session_context_snapshot(str(req.session_id or "").strip())
    if isinstance(session_context, dict):
        persisted_confirmed_fields = session_context.get("confirmed_fields")
        if isinstance(persisted_confirmed_fields, dict):
            for key, value in persisted_confirmed_fields.items():
                field_key = str(key or "").strip()
                if field_key and value not in (None, "", [], {}):
                    known_fields.add(field_key)
    extracted = normalize_extracted_field_values_fn(extract_intake_fields_from_message_fn(message, None))
    for key in extracted.get("fields", {}).keys():
        field_key = str(key or "").strip()
        if field_key:
            known_fields.add(field_key)
    if isinstance(orchestration_status, dict):
        confirmed_updates = orchestration_status.get("confirmed_updates")
        if isinstance(confirmed_updates, list):
            for item in confirmed_updates:
                if not isinstance(item, dict):
                    continue
                field_key = str(item.get("field_key") or "").strip()
                if field_key:
                    known_fields.add(field_key)
    return normalize_field_keys_fn(list(known_fields))
