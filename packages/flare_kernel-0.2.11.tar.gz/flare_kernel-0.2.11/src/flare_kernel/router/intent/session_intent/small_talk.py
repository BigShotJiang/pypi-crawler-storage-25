"""Small-talk and session-intent-stage helpers."""

from __future__ import annotations

import re
from typing import Any, Callable

from flare_kernel.router.intent.compat_aliases import (
    resolve_domain_relevance,
)

def looks_like_small_talk(
    message: str,
    *,
    contains_any_text_fn: Callable[[str, tuple[str, ...]], bool],
    intent_keywords: dict[str, tuple[str, ...]],
    small_talk_hints: tuple[str, ...],
) -> bool:
    normalized = str(message or "").strip().lower()
    if not normalized:
        return False
    if contains_any_text_fn(normalized, intent_keywords["requirement_intake"]):
        return False
    if contains_any_text_fn(normalized, intent_keywords["intelligent_sourcing"]):
        return False
    return contains_any_text_fn(normalized, small_talk_hints)


def normalize_small_talk_intro_text(message: str) -> str:
    text = str(message or "").strip().lower()
    if not text:
        return ""
    return re.sub(r"[\s,，。.!！?？:：;；、~～]+", "", text)


def resolve_small_talk_intro_reply(
    *,
    message: str,
    session_intent_stage: str,
    normalize_small_talk_intro_text_fn: Callable[[str], str],
    contains_any_text_fn: Callable[[str, tuple[str, ...]], bool],
    small_talk_intro_identity_hints: tuple[str, ...],
    small_talk_intro_capability_hints: tuple[str, ...],
) -> str:
    stage = str(session_intent_stage or "").strip().lower()
    if stage not in {"small_talk", "general_qa"}:
        return ""
    normalized = normalize_small_talk_intro_text_fn(message)
    if not normalized:
        return ""
    asked_identity = contains_any_text_fn(normalized, small_talk_intro_identity_hints)
    asked_capability = contains_any_text_fn(normalized, small_talk_intro_capability_hints)
    if not asked_identity and not asked_capability:
        return ""
    return (
        "你好，我是智能工作流助手。\n"
        "我可以先给你演示一遍标准流程：\n"
        "1. 你先告诉我目标、范围和约束。\n"
        "2. 我只追问会显著影响方案质量的关键缺口。\n"
        "3. 信息齐备后，我会输出结构化分析（含假设、风险、下一步）。\n"
        "4. 需要时再进入证据检索与候选对比。\n"
        "你可以直接回复：`先模拟一轮流程` 或 `我想先梳理目标`。"
    )


def resolve_session_intent_stage(
    *,
    signal: dict[str, Any] | None = None,
    orchestration_status: dict[str, Any] | None = None,
    message: str = "",
    command: str = "send_message",
    looks_like_small_talk_fn: Callable[[str], bool],
    session_intent_stages: set[str],
) -> str:
    if str(command or "").strip() == "generate_analysis":
        return "analysis_running"

    status = orchestration_status if isinstance(orchestration_status, dict) else {}
    normalized_stage = str(status.get("current_stage") or "").strip().lower()
    intake_session_state = str(status.get("intake_session_state") or "").strip().lower()
    if intake_session_state in {"analysis_running", "analysis_completed"}:
        return "analysis_running"
    if (
        intake_session_state in {"analysis_ready", "draft_ready_for_review"}
        or normalized_stage.startswith("requirement_analysis.ready")
    ):
        return "analysis_ready"
    if (
        intake_session_state in {"started", "clarification_in_progress", "workspace_live_updating"}
        or normalized_stage.startswith("requirement_intake")
    ):
        return "clarification_in_progress"

    stage_from_signal = ""
    if isinstance(signal, dict):
        stage_from_signal = str(
            signal.get("conversation_intent_state")
            or signal.get("session_intent_stage")
            or ""
        ).strip()
    if stage_from_signal in session_intent_stages:
        return stage_from_signal

    domain_relevance = resolve_domain_relevance(status)
    if isinstance(signal, dict):
        domain_relevance = domain_relevance or resolve_domain_relevance(signal)
    if domain_relevance:
        return "business_intake_candidate"
    if looks_like_small_talk_fn(message):
        return "small_talk"
    return "general_qa"


def sync_session_intent_stage(
    *,
    orchestration_status: dict[str, Any],
    signal: dict[str, Any] | None = None,
    message: str = "",
    command: str = "send_message",
    resolve_session_intent_stage_fn: Callable[..., str],
) -> None:
    if not isinstance(orchestration_status, dict):
        return
    stage = resolve_session_intent_stage_fn(
        signal=signal,
        orchestration_status=orchestration_status,
        message=message,
        command=command,
    )
    orchestration_status["session_intent_stage"] = stage
    orchestration_status["conversation_intent_state"] = stage
