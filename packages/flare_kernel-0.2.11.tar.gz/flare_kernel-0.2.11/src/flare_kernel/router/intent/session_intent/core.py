"""Session intent stage and classifier-field resolution helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.intent.session_intent.fields import (
    normalize_field_keys as normalize_field_keys_from_router,
    resolve_classifier_known_fields as resolve_classifier_known_fields_from_router,
    resolve_classifier_required_fields as resolve_classifier_required_fields_from_router,
)
from flare_kernel.router.intent.session_intent.small_talk import (
    looks_like_small_talk as looks_like_small_talk_from_router,
    normalize_small_talk_intro_text as normalize_small_talk_intro_text_from_router,
    resolve_session_intent_stage as resolve_session_intent_stage_from_router,
    resolve_small_talk_intro_reply as resolve_small_talk_intro_reply_from_router,
    sync_session_intent_stage as sync_session_intent_stage_from_router,
)


def normalize_field_keys(items: list[Any] | tuple[Any, ...] | None) -> tuple[str, ...]:
    return normalize_field_keys_from_router(items)


def resolve_classifier_required_fields(
    *,
    req: KernelRequest,
    runtime_snapshot: dict[str, Any] | None,
    orchestration_status: dict[str, Any] | None,
    normalize_field_keys_fn: Callable[[list[Any] | tuple[Any, ...] | None], tuple[str, ...]],
    fallback_required_fields: tuple[str, ...] = (),
) -> tuple[str, ...]:
    return resolve_classifier_required_fields_from_router(
        req=req,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        normalize_field_keys_fn=normalize_field_keys_fn,
        fallback_required_fields=fallback_required_fields,
    )


def resolve_classifier_known_fields(
    *,
    req: KernelRequest,
    message: str,
    orchestration_status: dict[str, Any] | None,
    normalize_extracted_field_values_fn: Callable[[dict[str, Any]], dict[str, Any]],
    extract_intake_fields_from_message_fn: Callable[[str, dict[str, Any] | None], dict[str, Any]],
    normalize_field_keys_fn: Callable[[list[Any] | tuple[Any, ...] | None], tuple[str, ...]],
) -> tuple[str, ...]:
    return resolve_classifier_known_fields_from_router(
        req=req,
        message=message,
        orchestration_status=orchestration_status,
        normalize_extracted_field_values_fn=normalize_extracted_field_values_fn,
        extract_intake_fields_from_message_fn=extract_intake_fields_from_message_fn,
        normalize_field_keys_fn=normalize_field_keys_fn,
    )


def looks_like_small_talk(
    message: str,
    *,
    contains_any_text_fn: Callable[[str, tuple[str, ...]], bool],
    intent_keywords: dict[str, tuple[str, ...]],
    small_talk_hints: tuple[str, ...],
) -> bool:
    return looks_like_small_talk_from_router(
        message,
        contains_any_text_fn=contains_any_text_fn,
        intent_keywords=intent_keywords,
        small_talk_hints=small_talk_hints,
    )


def normalize_small_talk_intro_text(message: str) -> str:
    return normalize_small_talk_intro_text_from_router(message)


def resolve_small_talk_intro_reply(
    *,
    message: str,
    session_intent_stage: str,
    normalize_small_talk_intro_text_fn: Callable[[str], str],
    contains_any_text_fn: Callable[[str, tuple[str, ...]], bool],
    small_talk_intro_identity_hints: tuple[str, ...],
    small_talk_intro_capability_hints: tuple[str, ...],
) -> str:
    return resolve_small_talk_intro_reply_from_router(
        message=message,
        session_intent_stage=session_intent_stage,
        normalize_small_talk_intro_text_fn=normalize_small_talk_intro_text_fn,
        contains_any_text_fn=contains_any_text_fn,
        small_talk_intro_identity_hints=small_talk_intro_identity_hints,
        small_talk_intro_capability_hints=small_talk_intro_capability_hints,
    )


def resolve_session_intent_stage(
    *,
    signal: dict[str, Any] | None = None,
    orchestration_status: dict[str, Any] | None = None,
    message: str = "",
    command: str = "send_message",
    looks_like_small_talk_fn: Callable[[str], bool],
    session_intent_stages: set[str],
) -> str:
    return resolve_session_intent_stage_from_router(
        signal=signal,
        orchestration_status=orchestration_status,
        message=message,
        command=command,
        looks_like_small_talk_fn=looks_like_small_talk_fn,
        session_intent_stages=session_intent_stages,
    )


def sync_session_intent_stage(
    *,
    orchestration_status: dict[str, Any],
    signal: dict[str, Any] | None = None,
    message: str = "",
    command: str = "send_message",
    resolve_session_intent_stage_fn: Callable[..., str],
) -> None:
    sync_session_intent_stage_from_router(
        orchestration_status=orchestration_status,
        signal=signal,
        message=message,
        command=command,
        resolve_session_intent_stage_fn=resolve_session_intent_stage_fn,
    )
