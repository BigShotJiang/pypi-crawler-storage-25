"""Compatibility alias helpers for domain-neutral intent state fields."""

from __future__ import annotations

from typing import Any

_DOMAIN_TO_LEGACY_INTENT_TYPE = {
    "domain_analysis": "procurement_analysis",
    "domain_consultation_qa": "procurement_consultation_qa",
    "domain_requirement_intake": "procurement_requirement_intake",
}
_LEGACY_TO_DOMAIN_INTENT_TYPE = {value: key for key, value in _DOMAIN_TO_LEGACY_INTENT_TYPE.items()}


def resolve_domain_relevance(
    source: dict[str, Any] | None,
    *,
    domain_key: str = "domain_relevance",
    legacy_key: str = "procurement_relevance",
    default: bool = False,
) -> bool:
    payload = source if isinstance(source, dict) else {}
    if domain_key in payload:
        return bool(payload.get(domain_key))
    if legacy_key in payload:
        return bool(payload.get(legacy_key))
    return bool(default)


def project_domain_relevance(domain_relevance: bool) -> dict[str, bool]:
    normalized = bool(domain_relevance)
    return {
        "domain_relevance": normalized,
        "procurement_relevance": normalized,
    }


def resolve_domain_policy_flag(
    policy: dict[str, Any] | None,
    *,
    domain_key: str,
    legacy_key: str,
    default: bool,
) -> bool:
    mapping = policy if isinstance(policy, dict) else {}
    if domain_key in mapping:
        return bool(mapping.get(domain_key))
    if legacy_key in mapping:
        return bool(mapping.get(legacy_key))
    return bool(default)


def resolve_domain_intent_type(
    source: dict[str, Any] | None,
    *,
    default: str = "qa_only",
) -> str:
    payload = source if isinstance(source, dict) else {}
    if "intent_type_domain" in payload:
        value = str(payload.get("intent_type_domain") or "").strip()
        if value:
            return value
    if "intent_type" in payload:
        value = str(payload.get("intent_type") or "").strip()
        if value:
            return _LEGACY_TO_DOMAIN_INTENT_TYPE.get(value, value)
    return str(default or "qa_only")


def project_compat_intent_type(domain_intent_type: str) -> dict[str, str]:
    normalized = str(domain_intent_type or "").strip() or "qa_only"
    return {
        "intent_type_domain": normalized,
        "intent_type": _DOMAIN_TO_LEGACY_INTENT_TYPE.get(normalized, normalized),
    }
