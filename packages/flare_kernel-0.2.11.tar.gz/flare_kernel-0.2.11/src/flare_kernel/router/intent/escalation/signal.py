"""Intent and escalation signal composition helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.intent.compat_aliases import (
    project_compat_intent_type,
    project_domain_relevance,
    resolve_domain_intent_type,
    resolve_domain_relevance,
)


def build_intent_and_escalation_signal(
    *,
    req: KernelRequest,
    command: str,
    message: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    resolve_classifier_required_fields_fn: Callable[..., tuple[str, ...]],
    resolve_classifier_known_fields_fn: Callable[..., tuple[str, ...]],
    normalize_field_keys_fn: Callable[[list[Any] | tuple[Any, ...] | None], tuple[str, ...]],
    normalize_intake_session_id_fn: Callable[[Any], str],
    resolve_session_intent_stage_fn: Callable[..., str],
    classify_intent_and_escalation_fn: Callable[[Any], Any],
    intent_escalation_context_cls: Any,
    runtime_snapshot: dict[str, Any] | None = None,
    orchestration_status: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = req.payload if isinstance(req.payload, dict) else {}
    intent_lexicon: dict[str, Any] | None = None
    if isinstance(payload.get("intent_lexicon"), dict):
        intent_lexicon = payload.get("intent_lexicon")
    if intent_lexicon is None and isinstance(runtime_snapshot, dict):
        domain_pack = runtime_snapshot.get("domain_pack") if isinstance(runtime_snapshot.get("domain_pack"), dict) else {}
        taxonomy = domain_pack.get("taxonomy") if isinstance(domain_pack, dict) else {}
        raw_taxonomy_lexicon = taxonomy.get("intent_lexicon") if isinstance(taxonomy, dict) else None
        if isinstance(raw_taxonomy_lexicon, dict):
            intent_lexicon = raw_taxonomy_lexicon

    required_fields = resolve_classifier_required_fields_fn(
        req=req,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
    )
    known_fields = resolve_classifier_known_fields_fn(
        req=req,
        message=message,
        orchestration_status=orchestration_status,
    )
    required_missing: tuple[str, ...] = ()
    if isinstance(orchestration_status, dict):
        status_missing = orchestration_status.get("required_missing")
        if isinstance(status_missing, list):
            required_missing = normalize_field_keys_fn(status_missing)
    if not required_missing and required_fields:
        known = set(known_fields)
        required_missing = tuple(item for item in required_fields if item not in known)
    has_current_question = bool(
        isinstance(orchestration_status, dict)
        and isinstance(orchestration_status.get("current_question"), dict)
    )
    intake_session_id = (
        normalize_intake_session_id_fn(orchestration_status.get("intake_session_id"))
        if isinstance(orchestration_status, dict)
        else normalize_intake_session_id_fn((req.payload or {}).get("intake_session_id"))
    )
    analysis_ready_hint = bool(
        isinstance(orchestration_status, dict) and orchestration_status.get("analysis_ready")
    )
    context = intent_escalation_context_cls(
        message=message,
        command=command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        required_fields=required_fields,
        required_missing=required_missing,
        known_fields=known_fields,
        has_current_question=has_current_question,
        intake_session_id=intake_session_id,
        analysis_ready_hint=analysis_ready_hint,
        intent_lexicon=intent_lexicon,
    )
    signal = classify_intent_and_escalation_fn(context).to_dict()
    stage = resolve_session_intent_stage_fn(
        signal=signal,
        orchestration_status=orchestration_status,
        message=message,
        command=command,
    )
    signal["session_intent_stage"] = stage
    signal["conversation_intent_state"] = stage
    signal["intent_and_escalation_confidence"] = signal.get("confidence", 0.0)
    signal["intent_and_escalation_reason"] = signal.get("reason", "")
    signal.update(project_domain_relevance(resolve_domain_relevance(signal)))
    signal.update(project_compat_intent_type(resolve_domain_intent_type(signal)))
    return signal


def merge_intent_and_escalation_signal(
    *,
    orchestration_status: dict[str, Any],
    signal: dict[str, Any] | None,
    resolve_session_intent_stage_fn: Callable[..., str],
) -> dict[str, Any]:
    if not isinstance(orchestration_status, dict):
        return {}
    merged = dict(orchestration_status)
    if not isinstance(signal, dict):
        return merged
    merged.update(
        project_domain_relevance(
            resolve_domain_relevance(
                signal,
                default=resolve_domain_relevance(merged),
            )
        )
    )
    merged.update(
        project_compat_intent_type(
            resolve_domain_intent_type(
                signal,
                default=resolve_domain_intent_type(merged, default="qa_only"),
            )
        )
    )
    for key in (
        "consultative_domain_qa",
        "consultative_procurement_qa",
        "escalation_target",
        "explicit_intake_request",
        "intake_candidate",
        "clarification_recommended",
        "draft_seeded",
        "missing_key_fields",
        "recommended_next_step",
        "session_intent_stage",
        "conversation_intent_state",
        "intent_and_escalation_confidence",
        "intent_and_escalation_reason",
    ):
        if key in signal:
            merged[key] = signal[key]
    if "consultative_domain_qa" in merged and "consultative_procurement_qa" not in merged:
        merged["consultative_procurement_qa"] = bool(merged.get("consultative_domain_qa"))
    if "consultative_procurement_qa" in merged and "consultative_domain_qa" not in merged:
        merged["consultative_domain_qa"] = bool(merged.get("consultative_procurement_qa"))
    analysis_ready = bool(orchestration_status.get("analysis_ready")) or bool(signal.get("analysis_ready"))
    merged["analysis_ready"] = analysis_ready
    if not isinstance(merged.get("required_missing"), list) and isinstance(signal.get("missing_key_fields"), list):
        merged["required_missing"] = [item for item in signal.get("missing_key_fields", []) if str(item).strip()]
    stage = resolve_session_intent_stage_fn(
        signal=signal,
        orchestration_status=merged,
        message="",
        command="send_message",
    )
    merged["session_intent_stage"] = stage
    merged["conversation_intent_state"] = stage
    return merged
