"""Intent and escalation signal pipeline helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime import (
    IntentEscalationContext,
    classify_intent_and_escalation,
)
from flare_kernel.router.intent.escalation.override import (
    apply_escalation_mode_override as apply_escalation_mode_override_from_router,
)
from flare_kernel.router.intent.escalation.signal import (
    build_intent_and_escalation_signal as build_intent_and_escalation_signal_from_router,
    merge_intent_and_escalation_signal as merge_intent_and_escalation_signal_from_router,
)


def build_intent_and_escalation_signal(
    *,
    req: KernelRequest,
    command: str,
    message: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    resolve_classifier_required_fields_fn: Callable[..., tuple[str, ...]],
    resolve_classifier_known_fields_fn: Callable[..., tuple[str, ...]],
    normalize_field_keys_fn: Callable[[list[Any] | tuple[Any, ...] | None], tuple[str, ...]],
    normalize_intake_session_id_fn: Callable[[Any], str],
    resolve_session_intent_stage_fn: Callable[..., str],
    runtime_snapshot: dict[str, Any] | None = None,
    orchestration_status: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return build_intent_and_escalation_signal_from_router(
        req=req,
        command=command,
        message=message,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        resolve_classifier_required_fields_fn=resolve_classifier_required_fields_fn,
        resolve_classifier_known_fields_fn=resolve_classifier_known_fields_fn,
        normalize_field_keys_fn=normalize_field_keys_fn,
        normalize_intake_session_id_fn=normalize_intake_session_id_fn,
        resolve_session_intent_stage_fn=resolve_session_intent_stage_fn,
        classify_intent_and_escalation_fn=classify_intent_and_escalation,
        intent_escalation_context_cls=IntentEscalationContext,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
    )


def merge_intent_and_escalation_signal(
    *,
    orchestration_status: dict[str, Any],
    signal: dict[str, Any] | None,
    resolve_session_intent_stage_fn: Callable[..., str],
) -> dict[str, Any]:
    return merge_intent_and_escalation_signal_from_router(
        orchestration_status=orchestration_status,
        signal=signal,
        resolve_session_intent_stage_fn=resolve_session_intent_stage_fn,
    )


def apply_escalation_mode_override(
    *,
    command: str,
    resolved_intent: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    resolved_mode: str,
    mode_source: str,
    escalation_signal: dict[str, Any],
    intent_escalation_policy: dict[str, Any] | None,
    coerce_intent_escalation_policy_fn: Callable[[dict[str, Any]], dict[str, Any]],
    default_intent_escalation_policy: dict[str, Any],
) -> tuple[str, str, float, str, str, str]:
    return apply_escalation_mode_override_from_router(
        command=command,
        resolved_intent=resolved_intent,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        escalation_signal=escalation_signal,
        intent_escalation_policy=intent_escalation_policy,
        coerce_intent_escalation_policy_fn=coerce_intent_escalation_policy_fn,
        default_intent_escalation_policy=default_intent_escalation_policy,
    )
