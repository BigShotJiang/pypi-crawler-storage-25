"""Intent/mode override policy helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.router.intent.compat_aliases import (
    resolve_domain_policy_flag,
    resolve_domain_relevance,
)


def apply_escalation_mode_override(
    *,
    command: str,
    resolved_intent: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    resolved_mode: str,
    mode_source: str,
    escalation_signal: dict[str, Any],
    intent_escalation_policy: dict[str, Any] | None,
    coerce_intent_escalation_policy_fn: Callable[[dict[str, Any]], dict[str, Any]],
    default_intent_escalation_policy: dict[str, Any],
) -> tuple[str, str, float, str, str, str]:
    policy = coerce_intent_escalation_policy_fn(intent_escalation_policy or {})
    enable_auto_mode_override = bool(policy.get("enable_auto_mode_override", True))
    if not enable_auto_mode_override:
        return resolved_intent, intent_source, intent_confidence, intent_reason, resolved_mode, mode_source
    min_confidence = float(
        policy.get(
            "auto_mode_override_min_confidence",
            default_intent_escalation_policy["auto_mode_override_min_confidence"],
        )
    )
    require_domain_relevance = resolve_domain_policy_flag(
        policy,
        domain_key="require_domain_relevance_for_auto_override",
        legacy_key="require_procurement_relevance_for_auto_override",
        default=True,
    )
    escalation_target = str(escalation_signal.get("escalation_target") or "").strip()
    explicit_intake_request = bool(escalation_signal.get("explicit_intake_request"))
    domain_relevance = resolve_domain_relevance(escalation_signal)
    try:
        classifier_confidence = float(escalation_signal.get("confidence", 0.0))
    except (TypeError, ValueError):
        classifier_confidence = 0.0
    should_escalate = escalation_target in {
        "intake_candidate",
        "clarification_recommended",
        "draft_seeded",
        "analysis_ready",
    }
    if escalation_target in {"intake_candidate", "clarification_recommended"} and not explicit_intake_request:
        should_escalate = False
    session_intent_stage = str(
        escalation_signal.get("conversation_intent_state")
        or escalation_signal.get("session_intent_stage")
        or ""
    ).strip()
    if session_intent_stage in {"small_talk", "general_qa"}:
        should_escalate = False
    if classifier_confidence < min_confidence:
        should_escalate = False
    if require_domain_relevance and not domain_relevance:
        should_escalate = False
    normalized_mode = str(resolved_mode or "").strip()
    if command != "send_message" or normalized_mode not in {"default", "intelligent_sourcing"} or not should_escalate:
        return resolved_intent, intent_source, intent_confidence, intent_reason, resolved_mode, mode_source
    if escalation_target in {"intake_candidate", "clarification_recommended"}:
        resolved_intent = "requirement_intake"
    elif not str(resolved_intent or "").strip() or str(resolved_intent).strip() == "default":
        resolved_intent = "requirement_intake"
    intent_source = "intent_and_escalation_classifier"
    intent_confidence = max(float(intent_confidence or 0.0), max(0.0, min(1.0, classifier_confidence)))
    classifier_reason = str(escalation_signal.get("reason") or "").strip()
    if classifier_reason:
        intent_reason = classifier_reason
    return resolved_intent, intent_source, intent_confidence, intent_reason, resolved_mode, mode_source
