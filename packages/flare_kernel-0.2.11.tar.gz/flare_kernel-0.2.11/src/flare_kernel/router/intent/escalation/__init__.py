"""Intent escalation helpers."""
