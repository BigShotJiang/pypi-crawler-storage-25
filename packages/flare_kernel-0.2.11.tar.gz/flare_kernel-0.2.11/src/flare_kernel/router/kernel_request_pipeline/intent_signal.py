"""Intent/escalation signal helper cluster for kernel request pipeline."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.intake.authority.core import (
    normalize_intake_session_id as normalize_intake_session_id_from_authority,
)
from flare_kernel.router.intent.escalation.pipeline import (
    apply_escalation_mode_override as _apply_escalation_mode_override_from_router,
    build_intent_and_escalation_signal as _build_intent_and_escalation_signal_from_router,
)
from flare_kernel.router.kernel_constants import (
    DEFAULT_INTENT_ESCALATION_POLICY as _DEFAULT_INTENT_ESCALATION_POLICY,
)
from flare_kernel.router.kernel_request_pipeline.intake import (
    _coerce_intent_escalation_policy,
    _normalize_field_keys,
    _resolve_classifier_known_fields,
    _resolve_classifier_required_fields,
    _resolve_session_intent_stage,
)


def _build_intent_and_escalation_signal(
    *,
    req: KernelRequest,
    command: str,
    message: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    runtime_snapshot: dict[str, Any] | None = None,
    orchestration_status: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return _build_intent_and_escalation_signal_from_router(
        req=req,
        command=command,
        message=message,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        resolve_classifier_required_fields_fn=_resolve_classifier_required_fields,
        resolve_classifier_known_fields_fn=_resolve_classifier_known_fields,
        normalize_field_keys_fn=_normalize_field_keys,
        normalize_intake_session_id_fn=normalize_intake_session_id_from_authority,
        resolve_session_intent_stage_fn=_resolve_session_intent_stage,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
    )


def _apply_escalation_mode_override(
    *,
    command: str,
    resolved_intent: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    resolved_mode: str,
    mode_source: str,
    escalation_signal: dict[str, Any],
    intent_escalation_policy: dict[str, Any] | None = None,
) -> tuple[str, str, float, str, str, str]:
    return _apply_escalation_mode_override_from_router(
        command=command,
        resolved_intent=resolved_intent,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        escalation_signal=escalation_signal,
        intent_escalation_policy=intent_escalation_policy,
        coerce_intent_escalation_policy_fn=_coerce_intent_escalation_policy,
        default_intent_escalation_policy=_DEFAULT_INTENT_ESCALATION_POLICY,
    )


__all__ = [name for name in globals() if name.startswith("_")]
