"""Command/mode switch request-pipeline helpers for kernel router."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.orchestration.analysis_router_runtime import (
    resolve_analysis_route as resolve_analysis_route_from_runtime,
)
from flare_kernel.router.kernel_constants import ROUTABLE_MODES as _ROUTABLE_MODES
from flare_kernel.router.kernel_flow_bindings.mode import (
    normalize_mode_candidate as _normalize_mode_candidate_in_kernel_mode_flow,
    resolve_current_mode as _resolve_current_mode_in_kernel_mode_flow,
    resolve_explicit_intent as _resolve_explicit_intent_in_kernel_mode_flow,
    resolve_intent_override as _resolve_intent_override_in_kernel_mode_flow,
    resolve_manual_mode as _resolve_manual_mode_in_kernel_mode_flow,
    resolve_request_mode as _resolve_request_mode_in_kernel_mode_flow,
)
from flare_kernel.router.mode.resolution import (
    normalize_mode_candidate as _normalize_mode_candidate_from_router,
    resolve_current_mode as _resolve_current_mode_from_router,
    resolve_manual_mode as _resolve_manual_mode_from_router,
    resolve_request_mode as _resolve_request_mode_from_router,
)
from flare_kernel.router.request.intent_resolution import (
    resolve_explicit_intent as _resolve_explicit_intent_from_router,
    resolve_intent_override as _resolve_intent_override_from_router,
)
from flare_kernel.router.mode.switch import (
    build_mode_switch_reason as _build_mode_switch_reason_from_router,
)


def _resolve_command(req: KernelRequest) -> str:
    command = str(req.command or "").strip()
    payload = req.payload if isinstance(req.payload, dict) else {}
    mode_candidates = (
        req.mode,
        req.manual_mode,
        req.current_mode,
        req.target_mode,
        payload.get("mode"),
        payload.get("manual_mode"),
        payload.get("current_mode"),
        payload.get("function_type"),
        payload.get("target_mode"),
    )
    is_analysis_mode = any(str(candidate or "").strip() == "analysis_mode" for candidate in mode_candidates)
    if command and command != "send_message":
        return command
    payload_command = str(payload.get("command") or payload.get("action_command") or "").strip()
    if payload_command and payload_command != "send_message":
        return payload_command
    if str(req.action_key or "").strip() == "generate_analysis":
        return "generate_analysis"
    if is_analysis_mode:
        return "generate_analysis"
    if command:
        return command
    if req.action_key:
        return "apply_field_candidate"
    return "send_message"


def _resolve_explicit_intent(req: KernelRequest) -> str:
    return _resolve_explicit_intent_in_kernel_mode_flow(
        req,
        resolve_explicit_intent_from_router_fn=_resolve_explicit_intent_from_router,
        normalize_mode_candidate_fn=_normalize_mode_candidate,
    )


def _resolve_intent_override(req: KernelRequest) -> str:
    return _resolve_intent_override_in_kernel_mode_flow(
        req,
        resolve_intent_override_from_router_fn=_resolve_intent_override_from_router,
        normalize_mode_candidate_fn=_normalize_mode_candidate,
    )


def _normalize_mode_candidate(raw_mode: Any) -> str:
    return _normalize_mode_candidate_in_kernel_mode_flow(
        raw_mode,
        normalize_mode_candidate_from_router_fn=_normalize_mode_candidate_from_router,
        routable_modes=_ROUTABLE_MODES,
    )


def _resolve_manual_mode(req: KernelRequest) -> str:
    return _resolve_manual_mode_in_kernel_mode_flow(
        req,
        resolve_manual_mode_from_router_fn=_resolve_manual_mode_from_router,
        normalize_mode_candidate_fn=_normalize_mode_candidate,
    )


def _resolve_current_mode(req: KernelRequest) -> str:
    return _resolve_current_mode_in_kernel_mode_flow(
        req,
        resolve_current_mode_from_router_fn=_resolve_current_mode_from_router,
        normalize_mode_candidate_fn=_normalize_mode_candidate,
    )


def _resolve_request_mode(req: KernelRequest, resolved_intent: str) -> tuple[str, str]:
    from flare_kernel.router.kernel_request_pipeline.intake import _should_continue_active_intake

    return _resolve_request_mode_in_kernel_mode_flow(
        req,
        resolved_intent,
        resolve_request_mode_from_router_fn=_resolve_request_mode_from_router,
        resolve_command_fn=_resolve_command,
        should_continue_active_intake_fn=_should_continue_active_intake,
        resolve_intent_override_fn=_resolve_intent_override,
        resolve_manual_mode_fn=_resolve_manual_mode,
        resolve_current_mode_fn=_resolve_current_mode,
        resolve_explicit_intent_fn=_resolve_explicit_intent,
        normalize_mode_candidate_fn=_normalize_mode_candidate,
        resolve_analysis_route_fn=resolve_analysis_route_from_runtime,
    )


def _build_mode_switch_reason(
    *,
    trace_id: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    intent_source: str = "",
    intent_confidence: float | None = None,
    intent_reason: str = "",
    req: KernelRequest,
) -> dict[str, Any]:
    return _build_mode_switch_reason_from_router(
        trace_id=trace_id,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        req=req,
        resolve_intent_override=_resolve_intent_override,
        resolve_manual_mode=_resolve_manual_mode,
        resolve_current_mode=_resolve_current_mode,
    )


__all__ = [name for name in globals() if name.startswith("_")]
