"""Intake/session helper cluster for kernel request pipeline."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.domain.domain_pack_loader import load_domain_pack
from flare_kernel.router.intake.answer import normalize_field_value_payload as _normalize_field_value_payload
from flare_kernel.router.intake.authority.core import (
    normalize_intake_session_id as normalize_intake_session_id_from_authority,
)
from flare_kernel.router.intake.entry_policy import (
    has_active_intake_payload as _has_active_intake_payload_from_router,
    is_intake_exit_message as _is_intake_exit_message_from_router,
    is_requirement_mode_explicit as _is_requirement_mode_explicit_from_router,
    resolve_requirement_intake_entry_recommendation as _resolve_requirement_intake_entry_recommendation_from_router,
    should_continue_active_intake as _should_continue_active_intake_from_router,
)
from flare_kernel.router.intake.extraction.core import (
    extract_intake_fields_from_message as _extract_intake_fields_from_message,
    normalize_extracted_field_values as _normalize_extracted_field_values,
)
from flare_kernel.router.intake.status.schema import (
    build_confirmed_fields_schema as _build_confirmed_fields_schema_from_router,
    build_missing_fields_schema as _build_missing_fields_schema_from_router,
    coerce_intent_escalation_policy as _coerce_intent_escalation_policy_from_router,
    normalize_stage_status as _normalize_stage_status_from_router,
    resolve_intent_escalation_policy_with_source as _resolve_intent_escalation_policy_with_source_from_router,
)
from flare_kernel.router.intent.escalation.pipeline import (
    merge_intent_and_escalation_signal as _merge_intent_and_escalation_signal_from_router,
)
from flare_kernel.router.retrieval.field_queries import (
    resolve_retrieval_field_queries as _resolve_retrieval_field_queries_from_router,
)
from flare_kernel.router.intent.session_intent.core import (
    looks_like_small_talk as _looks_like_small_talk_from_router,
    normalize_field_keys as _normalize_field_keys_from_router,
    normalize_small_talk_intro_text as _normalize_small_talk_intro_text_from_router,
    resolve_classifier_known_fields as _resolve_classifier_known_fields_from_router,
    resolve_classifier_required_fields as _resolve_classifier_required_fields_from_router,
    resolve_session_intent_stage as _resolve_session_intent_stage_from_router,
    resolve_small_talk_intro_reply as _resolve_small_talk_intro_reply_from_router,
    sync_session_intent_stage as _sync_session_intent_stage_from_router,
)
from flare_kernel.router.kernel_flow_bindings.session_intent import (
    looks_like_small_talk as _looks_like_small_talk_in_kernel_session_intent_flow,
    normalize_field_keys as _normalize_field_keys_in_kernel_session_intent_flow,
    normalize_small_talk_intro_text as _normalize_small_talk_intro_text_in_kernel_session_intent_flow,
    resolve_classifier_known_fields as _resolve_classifier_known_fields_in_kernel_session_intent_flow,
    resolve_classifier_required_fields as _resolve_classifier_required_fields_in_kernel_session_intent_flow,
    resolve_session_intent_stage as _resolve_session_intent_stage_in_kernel_session_intent_flow,
    resolve_small_talk_intro_reply as _resolve_small_talk_intro_reply_in_kernel_session_intent_flow,
    sync_session_intent_stage as _sync_session_intent_stage_in_kernel_session_intent_flow,
)
from flare_kernel.router.text_safety import (
    contains_any_text as _contains_any_text,
    extract_user_message as _extract_user_message,
    normalize_message_text as _normalize_message_text,
)
from flare_kernel.router.kernel_constants import (
    DEFAULT_INTENT_ESCALATION_POLICY as _DEFAULT_INTENT_ESCALATION_POLICY,
    FLOW_ALLOWED_STATUSES_BY_STAGE as _FLOW_ALLOWED_STATUSES_BY_STAGE,
    INTAKE_EXIT_HINTS as _INTAKE_EXIT_HINTS,
    INTENT_KEYWORDS as _INTENT_KEYWORDS,
    QUESTION_TERMS as _QUESTION_TERMS,
    REQUIREMENT_ENTRY_CONTEXT_TERMS as _REQUIREMENT_ENTRY_CONTEXT_TERMS,
    REQUIREMENT_ENTRY_EXPLICIT_PHRASES as _REQUIREMENT_ENTRY_EXPLICIT_PHRASES,
    REQUIREMENT_ENTRY_STRUCTURING_TERMS as _REQUIREMENT_ENTRY_STRUCTURING_TERMS,
    SESSION_INTENT_STAGES as _SESSION_INTENT_STAGES,
    SMALL_TALK_HINTS as _SMALL_TALK_HINTS,
    SMALL_TALK_INTRO_CAPABILITY_HINTS as _SMALL_TALK_INTRO_CAPABILITY_HINTS,
    SMALL_TALK_INTRO_IDENTITY_HINTS as _SMALL_TALK_INTRO_IDENTITY_HINTS,
)


def _resolve_requirement_intake_entry_recommendation(
    *,
    message: str,
    current_question: dict[str, Any] | None = None,
    required_missing: list[str] | tuple[str, ...] | None = None,
) -> tuple[str, float, str, str]:
    return _resolve_requirement_intake_entry_recommendation_from_router(
        message=message,
        current_question=current_question,
        required_missing=required_missing,
        normalize_message_text_fn=_normalize_message_text,
        looks_like_small_talk_fn=_looks_like_small_talk,
        contains_any_text_fn=_contains_any_text,
        requirement_entry_explicit_phrases=_REQUIREMENT_ENTRY_EXPLICIT_PHRASES,
        requirement_entry_context_terms=_REQUIREMENT_ENTRY_CONTEXT_TERMS,
        requirement_entry_structuring_terms=_REQUIREMENT_ENTRY_STRUCTURING_TERMS,
        question_terms=_QUESTION_TERMS,
    )


def _resolve_retrieval_field_queries(req: KernelRequest) -> list[tuple[str, str]]:
    return _resolve_retrieval_field_queries_from_router(
        req,
        normalize_field_value_payload_fn=_normalize_field_value_payload,
    )


def _is_requirement_mode_explicit(req: KernelRequest, command: str, mode_source: str) -> bool:
    payload = req.payload if isinstance(req.payload, dict) else {}
    return _is_requirement_mode_explicit_from_router(
        command=command,
        mode_source=mode_source,
        payload=payload,
    )


def _has_active_intake_payload(payload: dict[str, Any] | None) -> bool:
    return _has_active_intake_payload_from_router(payload)


def _is_intake_exit_message(message: str) -> bool:
    return _is_intake_exit_message_from_router(
        message,
        intake_exit_hints=_INTAKE_EXIT_HINTS,
    )


def _should_continue_active_intake(req: KernelRequest, command: str) -> bool:
    payload = req.payload if isinstance(req.payload, dict) else {}
    return _should_continue_active_intake_from_router(
        command=command,
        payload=payload,
        extract_user_message_fn=_extract_user_message,
        looks_like_small_talk_fn=_looks_like_small_talk,
        is_intake_exit_message_fn=_is_intake_exit_message,
    )


def _build_confirmed_fields_schema(
    fields: dict[str, Any],
    field_entities: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return _build_confirmed_fields_schema_from_router(
        fields=fields,
        field_entities=field_entities,
    )


def _build_missing_fields_schema(required_missing: list[str]) -> dict[str, Any]:
    return _build_missing_fields_schema_from_router(required_missing)


def _normalize_stage_status(
    *,
    current_stage: str,
    required_missing: list[str],
    activated_mode: str,
    question: dict[str, Any] | None,
    command: str,
    has_analysis_content: bool,
    analysis_entry_eligible: bool = False,
) -> tuple[str, str]:
    return _normalize_stage_status_from_router(
        current_stage=current_stage,
        required_missing=required_missing,
        activated_mode=activated_mode,
        question=question,
        command=command,
        has_analysis_content=has_analysis_content,
        flow_allowed_statuses_by_stage=_FLOW_ALLOWED_STATUSES_BY_STAGE,
        analysis_entry_eligible=analysis_entry_eligible,
    )


def _coerce_intent_escalation_policy(raw_policy: Any) -> dict[str, Any]:
    return _coerce_intent_escalation_policy_from_router(
        raw_policy,
        default_policy=_DEFAULT_INTENT_ESCALATION_POLICY,
    )


def _resolve_intent_escalation_policy(
    *,
    req: KernelRequest,
    runtime_snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    policy, _source = _resolve_intent_escalation_policy_with_source(
        req=req,
        runtime_snapshot=runtime_snapshot,
    )
    return policy


def _resolve_intent_escalation_policy_with_source(
    *,
    req: KernelRequest,
    runtime_snapshot: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], str]:
    return _resolve_intent_escalation_policy_with_source_from_router(
        req=req,
        runtime_snapshot=runtime_snapshot,
        default_policy=_DEFAULT_INTENT_ESCALATION_POLICY,
        coerce_intent_escalation_policy_fn=_coerce_intent_escalation_policy,
        load_domain_pack_fn=load_domain_pack,
    )


def _normalize_field_keys(items: list[Any] | tuple[Any, ...] | None) -> tuple[str, ...]:
    return _normalize_field_keys_in_kernel_session_intent_flow(
        items,
        normalize_field_keys_from_router_fn=_normalize_field_keys_from_router,
    )


def _resolve_classifier_required_fields(
    *,
    req: KernelRequest,
    runtime_snapshot: dict[str, Any] | None,
    orchestration_status: dict[str, Any] | None,
) -> tuple[str, ...]:
    return _resolve_classifier_required_fields_in_kernel_session_intent_flow(
        req=req,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        resolve_classifier_required_fields_from_router_fn=_resolve_classifier_required_fields_from_router,
        normalize_field_keys_fn=_normalize_field_keys,
    )


def _resolve_classifier_known_fields(
    *,
    req: KernelRequest,
    message: str,
    orchestration_status: dict[str, Any] | None,
) -> tuple[str, ...]:
    return _resolve_classifier_known_fields_in_kernel_session_intent_flow(
        req=req,
        message=message,
        orchestration_status=orchestration_status,
        resolve_classifier_known_fields_from_router_fn=_resolve_classifier_known_fields_from_router,
        normalize_extracted_field_values_fn=_normalize_extracted_field_values,
        extract_intake_fields_from_message_fn=_extract_intake_fields_from_message,
        normalize_field_keys_fn=_normalize_field_keys,
    )


def _looks_like_small_talk(message: str) -> bool:
    return _looks_like_small_talk_in_kernel_session_intent_flow(
        message,
        looks_like_small_talk_from_router_fn=_looks_like_small_talk_from_router,
        contains_any_text_fn=_contains_any_text,
        intent_keywords=_INTENT_KEYWORDS,
        small_talk_hints=_SMALL_TALK_HINTS,
    )


def _normalize_small_talk_intro_text(message: str) -> str:
    return _normalize_small_talk_intro_text_in_kernel_session_intent_flow(
        message,
        normalize_small_talk_intro_text_from_router_fn=_normalize_small_talk_intro_text_from_router,
    )


def _resolve_small_talk_intro_reply(*, message: str, session_intent_stage: str) -> str:
    return _resolve_small_talk_intro_reply_in_kernel_session_intent_flow(
        message=message,
        session_intent_stage=session_intent_stage,
        resolve_small_talk_intro_reply_from_router_fn=_resolve_small_talk_intro_reply_from_router,
        normalize_small_talk_intro_text_fn=_normalize_small_talk_intro_text,
        contains_any_text_fn=_contains_any_text,
        small_talk_intro_identity_hints=_SMALL_TALK_INTRO_IDENTITY_HINTS,
        small_talk_intro_capability_hints=_SMALL_TALK_INTRO_CAPABILITY_HINTS,
    )


def _resolve_session_intent_stage(
    *,
    signal: dict[str, Any] | None = None,
    orchestration_status: dict[str, Any] | None = None,
    message: str = "",
    command: str = "send_message",
) -> str:
    return _resolve_session_intent_stage_in_kernel_session_intent_flow(
        signal=signal,
        orchestration_status=orchestration_status,
        message=message,
        command=command,
        resolve_session_intent_stage_from_router_fn=_resolve_session_intent_stage_from_router,
        looks_like_small_talk_fn=_looks_like_small_talk,
        session_intent_stages=_SESSION_INTENT_STAGES,
    )


def _sync_session_intent_stage(
    *,
    orchestration_status: dict[str, Any],
    signal: dict[str, Any] | None = None,
    message: str = "",
    command: str = "send_message",
) -> None:
    _sync_session_intent_stage_in_kernel_session_intent_flow(
        orchestration_status=orchestration_status,
        signal=signal,
        message=message,
        command=command,
        sync_session_intent_stage_from_router_fn=_sync_session_intent_stage_from_router,
        resolve_session_intent_stage_fn=_resolve_session_intent_stage,
    )


def _merge_intent_and_escalation_signal(
    *,
    orchestration_status: dict[str, Any],
    signal: dict[str, Any] | None,
) -> dict[str, Any]:
    return _merge_intent_and_escalation_signal_from_router(
        orchestration_status=orchestration_status,
        signal=signal,
        resolve_session_intent_stage_fn=_resolve_session_intent_stage,
    )


__all__ = [name for name in globals() if name.startswith("_")]
