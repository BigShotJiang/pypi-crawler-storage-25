"""Intent-query/AI helper cluster for kernel request pipeline."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime import generate_llm_completion
from flare_kernel.router.intake.clarification import (
    should_force_requirement_clarification as _should_force_requirement_clarification_from_router,
)
from flare_kernel.router.intake.payload_updates import extract_quoted_terms as _extract_quoted_terms
from flare_kernel.router.intent.classifier_utils import (
    build_intent_classifier_prompt as _build_intent_classifier_prompt,
    build_keyword_suggestion as _build_keyword_suggestion_from_router,
    coerce_suggestable_mode as _coerce_suggestable_mode_from_router,
    extract_json_object as _extract_json_object,
    infer_intent_by_keywords as _infer_intent_by_keywords,
)
from flare_kernel.router.retrieval.aliases import (
    normalize_message_for_intent as _normalize_message_for_intent_from_router,
    resolve_intent_aliases as _resolve_intent_aliases_from_router,
)
from flare_kernel.router.retrieval.query_builder import (
    build_retrieval_queries as _build_retrieval_queries_from_router,
)
from flare_kernel.router.intent.routing import (
    resolve_intent_suggestion as _resolve_intent_suggestion_from_router,
    resolve_request_intent_with_ai as _resolve_request_intent_with_ai_from_router,
)
from flare_kernel.router.kernel_flow_bindings.intent_query import (
    build_keyword_suggestion as _build_keyword_suggestion_in_kernel_intent_query_flow,
    build_retrieval_queries as _build_retrieval_queries_in_kernel_intent_query_flow,
    normalize_message_for_intent as _normalize_message_for_intent_in_kernel_intent_query_flow,
    resolve_intent_aliases as _resolve_intent_aliases_in_kernel_intent_query_flow,
    resolve_intent_suggestion as _resolve_intent_suggestion_in_kernel_intent_query_flow,
    resolve_request_intent as _resolve_request_intent_in_kernel_intent_query_flow,
    resolve_request_intent_with_ai as _resolve_request_intent_with_ai_in_kernel_intent_query_flow,
    should_force_requirement_clarification as _should_force_requirement_clarification_in_kernel_intent_query_flow,
)
from flare_kernel.router.request.intent_resolution import (
    resolve_request_intent as _resolve_request_intent_from_router,
)
from flare_kernel.router.text_safety import (
    contains_any_text as _contains_any_text,
    extract_user_message as _extract_user_message,
)
from flare_kernel.router.kernel_constants import (
    DEFAULT_INTENT_ALIASES as _DEFAULT_INTENT_ALIASES,
    INTENT_KEYWORDS as _INTENT_KEYWORDS,
    REQUIREMENT_ENTRY_CONTEXT_TERMS as _REQUIREMENT_ENTRY_CONTEXT_TERMS,
    REQUIREMENT_ENTRY_STRUCTURING_TERMS as _REQUIREMENT_ENTRY_STRUCTURING_TERMS,
    SUGGESTABLE_MODES as _SUGGESTABLE_MODES,
)
from flare_kernel.router.kernel_request_pipeline.intake import (
    _looks_like_small_talk,
    _resolve_requirement_intake_entry_recommendation,
    _resolve_retrieval_field_queries,
)


def _resolve_generate_llm_completion_fn():
    try:
        import flare_kernel.router.kernel as kernel_module

        candidate = getattr(kernel_module, "generate_llm_completion", None)
        if callable(candidate):
            return candidate
    except Exception:  # pragma: no cover - defensive fallback
        pass
    return generate_llm_completion


def _resolve_intent_aliases(req: KernelRequest, *, instance_profile: dict[str, Any] | None = None) -> dict[str, str]:
    return _resolve_intent_aliases_in_kernel_intent_query_flow(
        req,
        instance_profile=instance_profile,
        resolve_intent_aliases_from_router_fn=_resolve_intent_aliases_from_router,
        default_intent_aliases=_DEFAULT_INTENT_ALIASES,
    )


def _normalize_message_for_intent(
    req: KernelRequest,
    *,
    message: str,
    instance_profile: dict[str, Any] | None = None,
) -> str:
    return _normalize_message_for_intent_in_kernel_intent_query_flow(
        req,
        message=message,
        instance_profile=instance_profile,
        normalize_message_for_intent_from_router_fn=_normalize_message_for_intent_from_router,
        default_intent_aliases=_DEFAULT_INTENT_ALIASES,
    )


def _build_retrieval_queries(
    req: KernelRequest,
    *,
    message: str,
    instance_profile: dict[str, Any] | None = None,
) -> list[str]:
    return _build_retrieval_queries_in_kernel_intent_query_flow(
        req,
        message=message,
        instance_profile=instance_profile,
        build_retrieval_queries_from_router_fn=_build_retrieval_queries_from_router,
        default_intent_aliases=_DEFAULT_INTENT_ALIASES,
        resolve_retrieval_field_queries_fn=_resolve_retrieval_field_queries,
    )


def _should_force_requirement_clarification(
    req: KernelRequest,
    *,
    message: str,
    retrieved_knowledge: list[dict[str, Any]] | None = None,
    instance_profile: dict[str, Any] | None = None,
) -> bool:
    return _should_force_requirement_clarification_in_kernel_intent_query_flow(
        req,
        message=message,
        retrieved_knowledge=retrieved_knowledge,
        instance_profile=instance_profile,
        should_force_requirement_clarification_from_router_fn=_should_force_requirement_clarification_from_router,
        normalize_message_for_intent_fn=lambda request, text, profile: _normalize_message_for_intent(
            request,
            message=text,
            instance_profile=profile,
        ),
        extract_quoted_terms_fn=_extract_quoted_terms,
        resolve_intent_aliases_fn=lambda request, profile: _resolve_intent_aliases(
            request,
            instance_profile=profile,
        ),
    )


def _resolve_request_intent(req: KernelRequest, *, instance_profile: dict[str, Any] | None = None) -> str:
    return _resolve_request_intent_in_kernel_intent_query_flow(
        req,
        instance_profile=instance_profile,
        resolve_request_intent_from_router_fn=_resolve_request_intent_from_router,
        extract_user_message_fn=_extract_user_message,
        normalize_message_for_intent_fn=lambda request, message, profile: _normalize_message_for_intent(
            request,
            message=message,
            instance_profile=profile,
        ),
        resolve_requirement_intake_entry_recommendation_fn=_resolve_requirement_intake_entry_recommendation,
        infer_intent_by_keywords_fn=lambda text: _infer_intent_by_keywords(
            text,
            intent_keywords=_INTENT_KEYWORDS,
        ),
        contains_any_text_fn=_contains_any_text,
        requirement_entry_structuring_terms=_REQUIREMENT_ENTRY_STRUCTURING_TERMS,
    )


def _build_keyword_suggestion(message: str) -> tuple[str, float, str, str]:
    return _build_keyword_suggestion_in_kernel_intent_query_flow(
        message,
        build_keyword_suggestion_from_router_fn=_build_keyword_suggestion_from_router,
        resolve_requirement_intake_entry_recommendation_fn=lambda text: _resolve_requirement_intake_entry_recommendation(
            message=text
        ),
        infer_intent_by_keywords_fn=lambda text: _infer_intent_by_keywords(
            text,
            intent_keywords=_INTENT_KEYWORDS,
        ),
    )


async def _resolve_request_intent_with_ai(req: KernelRequest, trace_id: str) -> tuple[str, str, float, str]:
    return await _resolve_request_intent_with_ai_in_kernel_intent_query_flow(
        req,
        trace_id,
        resolve_request_intent_with_ai_from_router_fn=_resolve_request_intent_with_ai_from_router,
        extract_user_message_fn=_extract_user_message,
        normalize_message_for_intent_fn=lambda request, message: _normalize_message_for_intent(
            request,
            message=message,
        ),
        looks_like_small_talk_fn=_looks_like_small_talk,
        resolve_requirement_intake_entry_recommendation_fn=_resolve_requirement_intake_entry_recommendation,
        contains_any_text_fn=_contains_any_text,
        requirement_entry_structuring_terms=_REQUIREMENT_ENTRY_STRUCTURING_TERMS,
        infer_intent_by_keywords_fn=lambda text: _infer_intent_by_keywords(
            text,
            intent_keywords=_INTENT_KEYWORDS,
        ),
        requirement_entry_context_terms=_REQUIREMENT_ENTRY_CONTEXT_TERMS,
        generate_llm_completion_fn=_resolve_generate_llm_completion_fn(),
        build_intent_classifier_prompt_fn=_build_intent_classifier_prompt,
        extract_json_object_fn=_extract_json_object,
        coerce_suggestable_mode_fn=lambda raw_mode: _coerce_suggestable_mode_from_router(
            raw_mode,
            suggestable_modes=_SUGGESTABLE_MODES,
        ),
        build_keyword_suggestion_fn=_build_keyword_suggestion,
    )


async def _resolve_intent_suggestion(req: KernelRequest, trace_id: str) -> tuple[str, float, str, str]:
    from flare_kernel.router.kernel_request_pipeline.action import (
        _resolve_current_mode,
        _resolve_intent_override,
        _resolve_manual_mode,
    )

    return await _resolve_intent_suggestion_in_kernel_intent_query_flow(
        req,
        trace_id,
        resolve_intent_suggestion_from_router_fn=_resolve_intent_suggestion_from_router,
        resolve_intent_override_fn=_resolve_intent_override,
        resolve_manual_mode_fn=_resolve_manual_mode,
        resolve_current_mode_fn=_resolve_current_mode,
        suggestable_modes=_SUGGESTABLE_MODES,
        extract_user_message_fn=_extract_user_message,
        normalize_message_for_intent_fn=lambda request, message: _normalize_message_for_intent(
            request,
            message=message,
        ),
        looks_like_small_talk_fn=_looks_like_small_talk,
        resolve_requirement_intake_entry_recommendation_fn=_resolve_requirement_intake_entry_recommendation,
        infer_intent_by_keywords_fn=lambda text: _infer_intent_by_keywords(
            text,
            intent_keywords=_INTENT_KEYWORDS,
        ),
        generate_llm_completion_fn=_resolve_generate_llm_completion_fn(),
        build_intent_classifier_prompt_fn=_build_intent_classifier_prompt,
        extract_json_object_fn=_extract_json_object,
        coerce_suggestable_mode_fn=lambda raw_mode: _coerce_suggestable_mode_from_router(
            raw_mode,
            suggestable_modes=_SUGGESTABLE_MODES,
        ),
        build_keyword_suggestion_fn=_build_keyword_suggestion,
    )


__all__ = [name for name in globals() if name.startswith("_")]
