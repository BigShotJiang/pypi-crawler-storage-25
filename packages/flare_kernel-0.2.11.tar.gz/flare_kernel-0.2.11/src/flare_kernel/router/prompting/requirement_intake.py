"""Requirement-intake prompt assembly.

This module owns generic requirement-intake prompting only. Domain-specific
sections, fields, and templates must come from domain packs or payload
contracts before they reach this layer.
"""

from __future__ import annotations

import json
from typing import Any, Callable

# Generic requirement-intake behavior contract. Domain-specific fields,
# examples, and templates must be carried by payload/domain contracts instead.
_REQUIREMENT_INTAKE_INSTRUCTION = (
    "instruction: 你是需求梳理助手。先基于用户原话、已确认字段与可用知识给出初步判断与建议框架；"
    "仅追问会显著影响方案、预算、风险与候选比较的高价值缺口；"
    "不要一次性罗列全部未填字段，不要重复询问已明确信息，避免通用模板化开场；"
    "普通沟通场景下必须先识别用户真实意图，并先给答案、方案、判断或可讨论版本；"
    "不要把用户每句话都处理成字段补齐任务，也不要只输出“还缺哪些信息”；"
    "当 payload 已提供 understanding_summary 时，优先按其已确认信息、关键缺口和下一步动作组织回复，"
    "不要重新退化成只问一个问题；"
    "当用户明确要求整理、撰写、生成文档、模板、清单、方案或报告时，必须先给出一版可直接使用的结构化正文或模板，"
    "再列出待补充信息与一个最高优先级问题；"
    "非文档产出请求时，回复先给“初步结论+建议路径/可选方案”，再给“一个校准问题”；"
    "初步结论必须包含明确判断，不要只复述用户原话；优先给出一版可讨论答案，"
    "并写清楚当前已收敛到什么方向、已排除什么方向、哪些内容是当前假设、待验证点或后续需要校准的判断；"
    "专业解释必须说明为什么这样判断、下一步方案如何拆、哪些假设会改变结论；"
    "用户询问输入、资料、字段、要素、标准、准备方式或判断口径时，也必须先围绕用户目标输出专业准备清单或评估维度，"
    "同时给出一版可先推进的方案路径；然后再追问一个最高优先级校准问题；"
    "默认使用中短结构（意图判断+初步答案/方案+专业解释+执行路径+1个校准问题），但不得覆盖用户明确提出的正文/模板/文档产出请求；"
    "对不确定内容要明确标注为“当前假设/待验证点/风险约束”，不要伪装成已确认事实；"
    "禁止对用户术语自行猜测或扩写含义，尤其是引号内术语；"
    "当术语含义不确定且无检索证据时，明确说明“我不确定该术语含义”，并先请求用户确认或建议先检索证据。"
)

_DOCUMENT_OUTPUT_INSTRUCTION = (
    "document_output_instruction: 本轮用户明确请求产出可用文档/模板；"
    "不要只输出“初步结论+一个问题”；"
    "回答必须以完整正文结构或模板标题开头，不要以“初步结论”开头；"
    "必须先输出完整正文结构，按用户主题展开主要章节、字段说明、填写口径、示例占位和待补充项；"
    "用户原话是最高优先级输入，必须保留并使用用户已经给出的目标、对象、场景、地点、时间、预算、数量、限制、已列字段和特殊要求；"
    "不要无视用户列出的任何要素；如果某个要素无法确定，只能标注“待补充/待验证”，不能从正文中删除；"
    "输出形态应是可直接复制继续编辑的草案或模板，而不是只解释还缺哪些内容；"
    "缺失信息只能作为正文后的“待补充信息/待验证项”，不能阻塞正文输出。"
)


def _normalize_prompt_options(options: Any) -> list[dict[str, str]]:
    if not isinstance(options, list):
        return []
    normalized: list[dict[str, str]] = []
    for index, option in enumerate(options, start=1):
        item = option if isinstance(option, dict) else {"label": option, "value": option}
        label = str(item.get("label") or item.get("text") or item.get("value") or "").strip()
        if not label:
            continue
        normalized.append(
            {
                "key": str(item.get("key") or f"option_{index}").strip(),
                "label": label,
                "value": str(item.get("value") or label).strip(),
            }
        )
    return normalized


def _missing_field_prompt_items(payload: dict[str, Any], required_missing: list[Any]) -> list[dict[str, Any]]:
    projected_items = payload.get("required_missing_items") if isinstance(payload.get("required_missing_items"), list) else []
    projected_map = {
        str(item.get("key") or "").strip(): str(item.get("label") or "").strip()
        for item in projected_items
        if isinstance(item, dict) and str(item.get("key") or "").strip()
    }
    definitions = payload.get("field_definitions") if isinstance(payload.get("field_definitions"), list) else []
    definition_map = {
        str(item.get("key") or "").strip(): item
        for item in definitions
        if isinstance(item, dict) and str(item.get("key") or "").strip()
    }
    items: list[dict[str, str]] = []
    for field_key in required_missing:
        key = str(field_key or "").strip()
        if not key:
            continue
        definition = definition_map.get(key, {})
        label = projected_map.get(key) or str(definition.get("label") or key).strip()
        prompt_item: dict[str, Any] = {"key": key, "label": label}
        question = str(definition.get("question") or "").strip()
        if question:
            prompt_item["question"] = question
        options = _normalize_prompt_options(definition.get("options"))
        if options:
            prompt_item["options"] = options
        items.append(prompt_item)
    return items


def _append_prompt_summary_template_parts(prompt_parts: list[str], payload: dict[str, Any]) -> None:
    template = payload.get("prompt_summary_template")
    if not isinstance(template, dict) or not template:
        return
    template_key = str(payload.get("prompt_summary_template_key") or template.get("key") or "").strip()
    if template_key:
        prompt_parts.append(f"prompt_summary_template_key: {template_key}")
    prompt_parts.append(f"prompt_summary_template: {json.dumps(template, ensure_ascii=False)}")
    prompt_parts.append(
        "prompt_summary_instruction: 本轮 requirement_intake 回复会被归一化为 Canvas requirement_summary；"
        "请优先基于 prompt_summary_template 的 tone、sections 和 constraints 输出 Markdown 需求梳理正文；"
        "只使用用户原文、recognized_fields、required_missing_fields、session_context 和检索证据中的信息；"
        "不得补造未确认事实；已确认内容沉淀为上下文，未确认内容放入待确认或待验证项。"
    )


def _append_current_question_prompt_parts(prompt_parts: list[str], payload: dict[str, Any]) -> None:
    current_question = payload.get("current_question")
    if not isinstance(current_question, dict):
        return
    question_text = str(current_question.get("question_text") or "").strip()
    if not question_text:
        return
    prompt_payload = {
        "field_key": str(current_question.get("field_key") or "").strip(),
        "question_key": str(current_question.get("question_key") or "").strip(),
        "target_information_gap": str(current_question.get("target_information_gap") or "").strip(),
        "question_text": question_text,
        "options": _normalize_prompt_options(current_question.get("options")),
    }
    prompt_parts.append(f"current_calibration_question: {json.dumps(prompt_payload, ensure_ascii=False)}")
    prompt_parts.append(
        "current_calibration_instruction: 如果本轮回复包含校准问题，必须使用 current_calibration_question.question_text；"
        "候选项必须沿用 current_calibration_question.options；不要另造一个不同问题。"
    )


def append_requirement_intake_prompt_parts(
    prompt_parts: list[str],
    payload: dict[str, Any],
    *,
    document_output_requested: bool,
    effective_command: str,
    build_analysis_instruction: Callable[[bool], str],
    is_sourcing_analysis_context: Callable[[dict[str, Any], str], bool],
) -> None:
    """Append requirement-intake prompt fragments without owning domain policy.

    The caller injects analysis callbacks so this module stays a prompt
    assembler and does not depend on routing state, sourcing internals, or
    business-specific requirement fields.
    """
    fields = payload.get("fields")
    if isinstance(fields, dict) and fields:
        prompt_parts.append(f"recognized_fields: {json.dumps(fields, ensure_ascii=False)}")

    required_missing = payload.get("required_missing")
    if isinstance(required_missing, list):
        missing_items = _missing_field_prompt_items(payload, required_missing)
        prompt_parts.append(f"required_missing_fields: {json.dumps(missing_items, ensure_ascii=False)}")

    _append_current_question_prompt_parts(prompt_parts, payload)
    _append_prompt_summary_template_parts(prompt_parts, payload)
    prompt_parts.append(_REQUIREMENT_INTAKE_INSTRUCTION)
    if document_output_requested:
        prompt_parts.append(_DOCUMENT_OUTPUT_INSTRUCTION)

    if effective_command == "generate_analysis":
        prompt_parts.append(
            build_analysis_instruction(
                is_sourcing_analysis_context(payload, effective_command)
            )
        )


__all__ = ["append_requirement_intake_prompt_parts"]
