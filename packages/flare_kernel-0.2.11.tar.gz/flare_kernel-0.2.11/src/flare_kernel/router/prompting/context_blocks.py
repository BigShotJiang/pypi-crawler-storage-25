"""Prompt context block formatting helpers.

DOC HELPER — ANL-05 prompt context projection boundary.
This module formats already-canonical context into prompt fragments. It must
not persist context, call providers, decide workflow state, or invent analysis
content beyond explicit session context fields.
"""

from __future__ import annotations

from typing import Any

from flare_engines import build_memory_task_relevance


def _clean_context_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _format_context_claims(items: Any, *, limit: int) -> str:
    if not isinstance(items, list):
        return ""
    values = [
        _clean_context_text(item.get("text") if isinstance(item, dict) else item)
        for item in items[:limit]
    ]
    return "; ".join(value for value in values if value)


def _format_context_artifacts(items: Any, *, limit: int) -> str:
    if not isinstance(items, list):
        return ""
    parts: list[str] = []
    for item in items[:limit]:
        if not isinstance(item, dict):
            continue
        title = _clean_context_text(item.get("title") or item.get("source_id"))
        kind = _clean_context_text(item.get("document_kind"))
        summary = _clean_context_text(item.get("summary"))
        if title or summary:
            parts.append(f"{title}({kind}): {summary}".strip())
    return "; ".join(parts)


def _template_values(template: dict[str, Any], key: str, *, limit: int) -> list[str]:
    values: list[str] = []
    for item in _as_list(template.get(key)):
        text = _clean_context_text(item)
        if text and text not in values:
            values.append(text)
    return values[:limit]


def _format_context_template_artifacts(items: Any, *, limit: int) -> str:
    parts: list[str] = []
    for item in _as_list(items):
        if not isinstance(item, dict):
            continue
        template = item.get("template") if isinstance(item.get("template"), dict) else {}
        sections = _template_values(template, "template_sections", limit=12)
        if template.get("is_template") is not True or not sections:
            continue
        title = _clean_context_text(item.get("title") or item.get("source_id") or "uploaded_template")
        fields = _template_values(template, "required_output_fields", limit=12)
        field_text = f"; required_fields={', '.join(fields)}" if fields else ""
        parts.append(f"{title}: sections={' > '.join(sections)}{field_text}")
        if len(parts) >= limit:
            break
    return "; ".join(parts)


def _format_confirmed_fields(fields: Any, *, limit: int) -> str:
    if not isinstance(fields, dict):
        return ""
    parts: list[str] = []
    for key, value in fields.items():
        field_key = _clean_context_text(key)
        field_value = _clean_context_text(value)
        if not field_key or not field_value:
            continue
        parts.append(f"{field_key}={field_value}")
        if len(parts) >= limit:
            break
    return "; ".join(parts)


def _format_recent_turns(turns: Any, *, limit: int) -> str:
    if not isinstance(turns, list):
        return ""
    parts: list[str] = []
    for item in turns[-limit:]:
        if not isinstance(item, dict):
            continue
        user_message = _clean_context_text(item.get("user_message"))
        assistant_message = _clean_context_text(item.get("assistant_message"))
        if not user_message and not assistant_message:
            continue
        turn_parts: list[str] = []
        if user_message:
            turn_parts.append(f"user={user_message}")
        if assistant_message:
            turn_parts.append(f"assistant={assistant_message}")
        parts.append(" | ".join(turn_parts))
    return " || ".join(parts)


def _format_project_memories(memories: Any, *, limit: int) -> str:
    """Format recalled Project Memory records for prompt context.

    Args:
        memories: Recalled memory records.
        limit: Maximum number of memory records to include.

    Returns:
        Compact Project Memory text block.
    """

    if not isinstance(memories, list):
        return ""
    parts: list[str] = []
    for item in memories[:limit]:
        if not isinstance(item, dict):
            continue
        memory_type = _clean_context_text(item.get("memory_type"))
        content = _clean_context_text(item.get("content"))
        if not content:
            continue
        parts.append(f"{memory_type}: {content}" if memory_type else content)
    return "; ".join(parts)


def _resolve_active_track(payload: dict[str, Any]) -> dict[str, Any]:
    track = payload.get("track_result")
    if isinstance(track, dict) and track:
        return track
    session_context = payload.get("session_context") if isinstance(payload.get("session_context"), dict) else {}
    return session_context.get("track") if isinstance(session_context.get("track"), dict) else {}


def _append_session_context_prompt_parts(prompt_parts: list[str], payload: dict[str, Any]) -> None:
    session_context = payload.get("session_context")
    if not isinstance(session_context, dict) or not session_context:
        return
    summary = _clean_context_text(session_context.get("session_summary"))
    facts = _format_context_claims(session_context.get("facts"), limit=3)
    unknowns = _format_context_claims(session_context.get("unknowns"), limit=3)
    artifacts = _format_context_artifacts(session_context.get("artifact_context"), limit=2)
    template_artifacts = _format_context_template_artifacts(session_context.get("artifact_context"), limit=2)
    confirmed_fields = _format_confirmed_fields(session_context.get("confirmed_fields"), limit=4)
    recent_turns = _format_recent_turns(session_context.get("turns"), limit=1)
    if summary:
        prompt_parts.append(f"session_context_summary: {summary}")
    if facts:
        prompt_parts.append(f"session_context_facts: {facts}")
    if unknowns:
        prompt_parts.append(f"session_context_unknowns: {unknowns}")
    if artifacts:
        prompt_parts.append(f"session_context_artifacts: {artifacts}")
    if template_artifacts:
        prompt_parts.append(f"session_context_user_templates: {template_artifacts}")
        prompt_parts.append(
            "session_context_user_template_instruction: 当当前任务需要生成分析、报告或文档正文时，"
            "必须优先沿用用户上传模板的章节顺序与字段要求；模板是输出骨架，不是证据来源；"
            "缺失内容放入对应章节的待补充/待验证项，不要因模板缺口阻塞生成。"
        )
    if confirmed_fields:
        prompt_parts.append(f"session_context_confirmed_fields: {confirmed_fields}")
    if recent_turns:
        prompt_parts.append(f"session_context_recent_turns: {recent_turns}")


def _append_project_memory_prompt_parts(prompt_parts: list[str], payload: dict[str, Any]) -> None:
    """Append project-level recalled memory to prompt parts.

    Args:
        prompt_parts: Mutable prompt line list.
        payload: Enriched kernel payload.

    Returns:
        None.
    """

    recall = payload.get("project_memory_recall")
    if not isinstance(recall, dict) or not recall:
        return
    track = _resolve_active_track(payload)
    relevance = build_memory_task_relevance(
        current_message=_clean_context_text(payload.get("message") or payload.get("user_message")),
        active_goal=_clean_context_text(track.get("goal")),
        memories=recall.get("memories") if isinstance(recall.get("memories"), list) else [],
    )
    memories = _format_project_memories(relevance.get("related"), limit=2)
    background_memories = _format_project_memories(relevance.get("background_only"), limit=1)
    if memories:
        prompt_parts.append(f"project_memory: {memories}")
    if background_memories:
        prompt_parts.append(f"project_memory_background_only: {background_memories}")


def _append_active_task_boundary_prompt_part(
    prompt_parts: list[str],
    payload: dict[str, Any],
    current_message: str,
) -> None:
    track = _resolve_active_track(payload)
    goal = _clean_context_text(track.get("goal")) if isinstance(track, dict) else ""
    message = _clean_context_text(current_message)
    if goal or message:
        prompt_parts.append(f"active_task_boundary: current_user_message={message}; current_task_goal={goal}")
        prompt_parts.append(
            "active_task_rule: 当前轮用户输入和 track_result/session_context.track 是本轮任务主语；"
            "session_context/project_memory 只能作为与当前任务一致的背景，不能替换当前任务对象、场景或目标。"
        )


def _append_track_prompt_parts(prompt_parts: list[str], payload: dict[str, Any]) -> None:
    track = payload.get("track_result")
    if not isinstance(track, dict) or not track:
        session_context = payload.get("session_context") if isinstance(payload.get("session_context"), dict) else {}
        track = session_context.get("track") if isinstance(session_context.get("track"), dict) else {}
    if not isinstance(track, dict) or not track:
        return
    enrichment = _clean_context_text(track.get("prompt_enrichment"))
    next_question = track.get("next_question") if isinstance(track.get("next_question"), dict) else {}
    actions = track.get("next_actions") if isinstance(track.get("next_actions"), list) else []
    action_labels = [
        _clean_context_text(item.get("label"))
        for item in actions
        if isinstance(item, dict) and _clean_context_text(item.get("label"))
    ][:4]
    if enrichment:
        prompt_parts.append(f"track_prompt_enrichment: {enrichment}")
    if _clean_context_text(next_question.get("text")):
        prompt_parts.append(f"track_next_question: {_clean_context_text(next_question.get('text'))}")
    if action_labels:
        prompt_parts.append(f"track_suggested_actions: {'; '.join(action_labels)}")


def _append_understanding_summary_prompt_part(prompt_parts: list[str], payload: dict[str, Any]) -> None:
    understanding_summary = _clean_context_text(payload.get("understanding_summary"))
    if understanding_summary:
        prompt_parts.append(f"understanding_summary: {understanding_summary}")


__all__ = [
    "_append_active_task_boundary_prompt_part",
    "_append_project_memory_prompt_parts",
    "_append_session_context_prompt_parts",
    "_append_track_prompt_parts",
    "_append_understanding_summary_prompt_part",
]
