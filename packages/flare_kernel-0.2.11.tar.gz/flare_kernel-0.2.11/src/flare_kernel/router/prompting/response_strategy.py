"""Prompt fragments for response strategy guidance."""

from __future__ import annotations

from typing import Any


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def append_response_strategy_prompt_parts(prompt_parts: list[str], payload: dict[str, Any]) -> None:
    strategy = payload.get("response_strategy_result")
    if not isinstance(strategy, dict) or not strategy:
        return
    response_plan = strategy.get("response_plan") if isinstance(strategy.get("response_plan"), dict) else {}
    guidance = _clean_text(response_plan.get("guidance") or strategy.get("guidance"))
    strategy_key = _clean_text(strategy.get("strategy_key"))
    response_shape = _clean_text(response_plan.get("response_shape") or strategy.get("response_shape"))
    response_intent = _clean_text(strategy.get("response_intent"))
    tone = _clean_text(strategy.get("tone"))
    sections = response_plan.get("sections") if isinstance(response_plan.get("sections"), list) else []
    if not sections:
        sections = strategy.get("sections") if isinstance(strategy.get("sections"), list) else []
    section_labels = [
        _clean_text(item.get("label") or item.get("key"))
        for item in sections
        if isinstance(item, dict) and _clean_text(item.get("label") or item.get("key"))
    ][:8]
    if strategy_key:
        prompt_parts.append(f"response_strategy_key: {strategy_key}")
    if response_shape:
        prompt_parts.append(f"response_shape: {response_shape}")
    if response_intent:
        prompt_parts.append(f"response_strategy_intent: {response_intent}")
    if tone:
        prompt_parts.append(f"response_strategy_tone: {tone}")
    if section_labels:
        prompt_parts.append(f"response_strategy_sections: {'; '.join(section_labels)}")
    if guidance:
        prompt_parts.append(f"response_strategy_guidance: {guidance}")


__all__ = ["append_response_strategy_prompt_parts"]
