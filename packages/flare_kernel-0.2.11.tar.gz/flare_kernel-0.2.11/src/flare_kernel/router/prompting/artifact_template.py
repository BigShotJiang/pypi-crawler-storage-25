"""Prompt fragments for domain-pack artifact templates.

DOC HELPER — OBJ-08 template prompt bridge.
This module appends already-normalized domain-pack template metadata to the
model prompt. It owns generic usage rules only; concrete sections, fields and
copy must remain in domain packs or instance configuration.
"""

from __future__ import annotations

import json
from typing import Any


def append_artifact_template_prompt_parts(prompt_parts: list[str], payload: dict[str, Any]) -> None:
    template_result = payload.get("artifact_template_result")
    if not isinstance(template_result, dict) or not template_result:
        return
    if str(template_result.get("status") or "").strip() not in {"matched", "partial"}:
        return
    prompt_parts.append(
        f"artifact_template_result: {json.dumps(template_result, ensure_ascii=False)}"
    )
    prompt_parts.append(
        "artifact_template_instruction: 当前 domain pack 提供了 artifact_template_result；"
        "当 response_intent_result 要求文档/模板/草案输出时，必须优先使用该模板、章节和字段；"
        "模板只提供基础骨架，不是固定文案；必须根据用户主题改写标题、章节名称和正文措辞；"
        "不得把模板缺口变成阻塞式追问；缺失内容应放在正文后的待补充/待验证项。"
    )


__all__ = ["append_artifact_template_prompt_parts"]
