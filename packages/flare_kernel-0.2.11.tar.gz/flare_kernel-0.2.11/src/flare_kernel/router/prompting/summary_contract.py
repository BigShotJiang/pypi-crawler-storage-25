"""Prompt-summary template extraction for kernel facade payloads.

This module only copies backend-canonical template contracts from runtime
mode events into the prompt payload. It does not define business sections,
call providers, or assemble Canvas prose.
"""

from __future__ import annotations

from typing import Any


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _iter_mode_event_payloads(runtime_snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    events = runtime_snapshot.get("mode_events")
    if not isinstance(events, list):
        return []
    return [event.get("payload") for event in events if isinstance(event, dict) and isinstance(event.get("payload"), dict)]


def resolve_prompt_summary_contract(runtime_snapshot: dict[str, Any]) -> dict[str, Any]:
    """Resolve the prompt-summary template contract from runtime events."""

    for payload in _iter_mode_event_payloads(runtime_snapshot):
        template = _coerce_mapping(payload.get("prompt_summary_template"))
        template_key = _clean_text(payload.get("prompt_summary_template_key") or template.get("key"))
        if template or template_key:
            return {
                "prompt_summary_template": template,
                "prompt_summary_template_key": template_key,
            }
    return {}


def apply_prompt_summary_contract(*, payload: dict[str, Any], runtime_snapshot: dict[str, Any]) -> None:
    """Copy template contract into payload if it is not already present."""

    contract = resolve_prompt_summary_contract(runtime_snapshot)
    if not contract:
        return
    if not isinstance(payload.get("prompt_summary_template"), dict) and contract["prompt_summary_template"]:
        payload["prompt_summary_template"] = contract["prompt_summary_template"]
    if not _clean_text(payload.get("prompt_summary_template_key")) and contract["prompt_summary_template_key"]:
        payload["prompt_summary_template_key"] = contract["prompt_summary_template_key"]


__all__ = ["apply_prompt_summary_contract", "resolve_prompt_summary_contract"]
