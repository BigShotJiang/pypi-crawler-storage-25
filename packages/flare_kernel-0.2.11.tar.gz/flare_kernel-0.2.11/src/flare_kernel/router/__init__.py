"""Kernel router public exports."""

from __future__ import annotations

from flare_kernel.router.api.auth import router as auth_api_router
from flare_kernel.router.api.list_events import router as list_events_api_router
from flare_kernel.router.api.project import router as project_api_router
from flare_kernel.router.api.session import router as session_api_router
from flare_kernel.router.api.chat import router as chat_api_router
from flare_kernel.router.api.run import router as run_api_router
from flare_kernel.router.api.update import router as update_api_router
from flare_kernel.router.kernel import router as kernel_router
from flare_kernel.router.source_library import router as source_library_router

__all__ = [
    "kernel_router",
    "auth_api_router",
    "chat_api_router",
    "list_events_api_router",
    "project_api_router",
    "session_api_router",
    "run_api_router",
    "update_api_router",
    "source_library_router",
]
