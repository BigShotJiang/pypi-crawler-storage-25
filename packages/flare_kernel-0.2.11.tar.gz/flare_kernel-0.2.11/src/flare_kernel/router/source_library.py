"""Source library API routes."""

from __future__ import annotations

import json
import os
from pathlib import Path
from uuid import uuid4

from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, UploadFile

from flare_kernel.contracts import (
    AuthContext,
    DeleteProjectSourceResponse,
    ProjectSourcesResponse,
    ProjectSourceUploadResponse,
)
from flare_kernel.router.api.auth_guard import require_route_scope, resolve_route_auth_context
from flare_kernel.router.api.errors import ApiError
from flare_kernel.runtime import (
    build_sqlalchemy_engine,
    create_project_source_record,
    delete_project_source,
    list_project_sources,
    run_source_ingestion_pipeline,
)

router = APIRouter(tags=["source-library"])

_UPLOAD_ROOT = Path(os.getenv("FLARE_SOURCE_UPLOAD_DIR", "/tmp/flare_sources"))


def _persist_upload_file(*, project_id: str, source_id: str, upload_file: UploadFile) -> str:
    _UPLOAD_ROOT.mkdir(parents=True, exist_ok=True)
    extension = Path(upload_file.filename or "upload.bin").suffix
    file_path = _UPLOAD_ROOT / f"{project_id}-{source_id}{extension}"
    with file_path.open("wb") as f:
        f.write(upload_file.file.read())
    return str(file_path)


def _assert_non_empty_scope_value(value: str, field_name: str) -> str:
    normalized = str(value or "").strip()
    if normalized:
        return normalized
    raise ApiError(
        code="INVALID_REQUEST",
        http_status=422,
        message=f"{field_name} is required",
        description="request payload missing required scope field",
        context_fields=[field_name],
        retryable=False,
    )


def _parse_document_understanding_config(value: str | None) -> dict[str, object]:
    raw = str(value or "").strip()
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ApiError(
            code="INVALID_REQUEST",
            http_status=422,
            message="document_understanding_config must be valid JSON",
            description="upload config must be a JSON object",
            context_fields=["document_understanding_config"],
            retryable=False,
        ) from exc
    if isinstance(parsed, dict):
        return parsed
    raise ApiError(
        code="INVALID_REQUEST",
        http_status=422,
        message="document_understanding_config must be an object",
        description="upload config must be a JSON object",
        context_fields=["document_understanding_config"],
        retryable=False,
    )


def _save_and_create_source_record(
    *,
    project_id: str,
    user_id: str,
    session_id: str | None,
    file: UploadFile,
) -> dict[str, object]:
    draft_source_id = f"src-{uuid4().hex}"
    storage_uri = _persist_upload_file(project_id=project_id, source_id=draft_source_id, upload_file=file)
    source = create_project_source_record(
        project_id=project_id,
        user_id=user_id,
        session_id=session_id,
        filename=file.filename or "upload.bin",
        mime_type=file.content_type or "",
        size=None,
        storage_uri=storage_uri,
        build_sqlalchemy_engine_fn=build_sqlalchemy_engine,
    )
    return source


def _build_project_sources_response(*, project_id: str, session_id: str | None = None) -> ProjectSourcesResponse:
    resolved_project_id = _assert_non_empty_scope_value(project_id, "project_id")
    sources = list_project_sources(project_id=resolved_project_id, build_sqlalchemy_engine_fn=build_sqlalchemy_engine)
    normalized_session_id = str(session_id or "").strip()
    if normalized_session_id:
        sources = [
            source for source in sources
            if str(source.get("scope") or "").strip().lower() == "project"
            or str(source.get("session_id") or "") == normalized_session_id
        ]
    else:
        sources = [
            source for source in sources
            if str(source.get("scope") or "").strip().lower() == "project"
        ]
    normalized_sources: list[dict[str, object]] = []
    for source in sources:
        normalized_source = dict(source)
        normalized_source.setdefault("status", "uploaded")
        normalized_source.setdefault("error_code", None)
        normalized_source.setdefault("error_message", "")
        normalized_sources.append(normalized_source)
    return ProjectSourcesResponse(sources=normalized_sources)


@router.post("/files/upload", response_model=ProjectSourceUploadResponse)
async def upload_project_source_file(
    background_tasks: BackgroundTasks,
    project_id: str = Form(...),
    user_id: str = Form("default"),
    session_id: str | None = Form(None),
    document_understanding_config: str = Form(""),
    file: UploadFile = File(...),
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> ProjectSourceUploadResponse:
    resolved_project_id = _assert_non_empty_scope_value(project_id, "project_id")
    resolved_user_id = str(user_id or "default").strip() or "default"
    require_route_scope(
        auth_context,
        required_scopes=["sources:write"],
        project_id=resolved_project_id,
        session_id=str(session_id or ""),
        user_id=resolved_user_id,
    )
    parsed_document_config = _parse_document_understanding_config(document_understanding_config)
    source = _save_and_create_source_record(
        project_id=resolved_project_id,
        user_id=resolved_user_id,
        session_id=session_id,
        file=file,
    )
    background_tasks.add_task(
        run_source_ingestion_pipeline,
        project_id=resolved_project_id,
        source_id=str(source["source_id"]),
        build_sqlalchemy_engine_fn=build_sqlalchemy_engine,
        document_understanding_config=parsed_document_config,
    )
    return ProjectSourceUploadResponse(data=source)


@router.post("/chat/files/upload", response_model=ProjectSourceUploadResponse)
async def upload_project_source_file_chat_alias(
    background_tasks: BackgroundTasks,
    project_id: str = Form(...),
    user_id: str = Form("default"),
    session_id: str | None = Form(None),
    document_understanding_config: str = Form(""),
    file: UploadFile = File(...),
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> ProjectSourceUploadResponse:
    return await upload_project_source_file(
        background_tasks=background_tasks,
        project_id=project_id,
        user_id=user_id,
        session_id=session_id,
        document_understanding_config=document_understanding_config,
        file=file,
        auth_context=auth_context,
    )


@router.get("/projects/{project_id}/sources", response_model=ProjectSourcesResponse)
async def list_sources_for_project(
    project_id: str,
    session_id: str | None = None,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> ProjectSourcesResponse:
    resolved_project_id = _assert_non_empty_scope_value(project_id, "project_id")
    require_route_scope(
        auth_context,
        required_scopes=["sources:read"],
        project_id=resolved_project_id,
        session_id=str(session_id or ""),
    )
    return _build_project_sources_response(project_id=resolved_project_id, session_id=session_id)


@router.get("/chat/projects/{project_id}/sources", response_model=ProjectSourcesResponse)
async def list_sources_for_project_chat_alias(
    project_id: str,
    session_id: str | None = None,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> ProjectSourcesResponse:
    resolved_project_id = _assert_non_empty_scope_value(project_id, "project_id")
    require_route_scope(
        auth_context,
        required_scopes=["sources:read"],
        project_id=resolved_project_id,
        session_id=str(session_id or ""),
    )
    return _build_project_sources_response(project_id=resolved_project_id, session_id=session_id)


@router.delete("/projects/{project_id}/sources/{source_id}", response_model=DeleteProjectSourceResponse)
async def delete_source_for_project(
    project_id: str,
    source_id: str,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> DeleteProjectSourceResponse:
    resolved_project_id = _assert_non_empty_scope_value(project_id, "project_id")
    resolved_source_id = _assert_non_empty_scope_value(source_id, "source_id")
    require_route_scope(auth_context, required_scopes=["sources:write"], project_id=resolved_project_id)
    deleted = delete_project_source(
        project_id=resolved_project_id,
        source_id=resolved_source_id,
        build_sqlalchemy_engine_fn=build_sqlalchemy_engine,
    )
    if not deleted:
        raise ApiError(
            code="RESOURCE_NOT_FOUND",
            http_status=404,
            message="source not found",
            description="source_id does not exist under target project",
            context_fields=["project_id", "source_id"],
            retryable=False,
            details={
                "project_id": resolved_project_id,
                "source_id": resolved_source_id,
            },
        )
    return DeleteProjectSourceResponse(ok=True)


@router.delete("/chat/projects/{project_id}/sources/{source_id}", response_model=DeleteProjectSourceResponse)
async def delete_source_for_project_chat_alias(
    project_id: str,
    source_id: str,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> DeleteProjectSourceResponse:
    return await delete_source_for_project(project_id=project_id, source_id=source_id, auth_context=auth_context)
