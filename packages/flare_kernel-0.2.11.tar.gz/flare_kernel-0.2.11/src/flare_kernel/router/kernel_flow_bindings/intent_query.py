"""Kernel-local intent/query binding helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest


def resolve_intent_aliases(
    req: KernelRequest,
    *,
    instance_profile: dict[str, Any] | None,
    resolve_intent_aliases_from_router_fn: Callable[..., dict[str, str]],
    default_intent_aliases: dict[str, str],
) -> dict[str, str]:
    return resolve_intent_aliases_from_router_fn(
        req,
        default_intent_aliases=default_intent_aliases,
        instance_profile=instance_profile,
    )


def normalize_message_for_intent(
    req: KernelRequest,
    *,
    message: str,
    instance_profile: dict[str, Any] | None,
    normalize_message_for_intent_from_router_fn: Callable[..., str],
    default_intent_aliases: dict[str, str],
) -> str:
    return normalize_message_for_intent_from_router_fn(
        req,
        message=message,
        default_intent_aliases=default_intent_aliases,
        instance_profile=instance_profile,
    )


def build_retrieval_queries(
    req: KernelRequest,
    *,
    message: str,
    instance_profile: dict[str, Any] | None,
    build_retrieval_queries_from_router_fn: Callable[..., list[str]],
    default_intent_aliases: dict[str, str],
    resolve_retrieval_field_queries_fn: Callable[[KernelRequest], list[tuple[str, str]]],
) -> list[str]:
    return build_retrieval_queries_from_router_fn(
        req,
        message=message,
        default_intent_aliases=default_intent_aliases,
        resolve_retrieval_field_queries_fn=resolve_retrieval_field_queries_fn,
        instance_profile=instance_profile,
    )


def should_force_requirement_clarification(
    req: KernelRequest,
    *,
    message: str,
    retrieved_knowledge: list[dict[str, Any]] | None,
    instance_profile: dict[str, Any] | None,
    should_force_requirement_clarification_from_router_fn: Callable[..., bool],
    normalize_message_for_intent_fn: Callable[..., str],
    extract_quoted_terms_fn: Callable[[str], list[str]],
    resolve_intent_aliases_fn: Callable[..., dict[str, str]],
) -> bool:
    return should_force_requirement_clarification_from_router_fn(
        req,
        message=message,
        normalize_message_for_intent_fn=normalize_message_for_intent_fn,
        extract_quoted_terms_fn=extract_quoted_terms_fn,
        resolve_intent_aliases_fn=resolve_intent_aliases_fn,
        retrieved_knowledge=retrieved_knowledge,
        instance_profile=instance_profile,
    )


def resolve_request_intent(
    req: KernelRequest,
    *,
    instance_profile: dict[str, Any] | None,
    resolve_request_intent_from_router_fn: Callable[..., str],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    normalize_message_for_intent_fn: Callable[..., str],
    resolve_requirement_intake_entry_recommendation_fn: Callable[..., tuple[str, float, str, str]],
    infer_intent_by_keywords_fn: Callable[[str], str],
    contains_any_text_fn: Callable[[str, tuple[str, ...]], bool],
    requirement_entry_structuring_terms: tuple[str, ...],
) -> str:
    return resolve_request_intent_from_router_fn(
        req,
        instance_profile=instance_profile,
        extract_user_message_fn=extract_user_message_fn,
        normalize_message_for_intent_fn=normalize_message_for_intent_fn,
        resolve_requirement_intake_entry_recommendation_fn=resolve_requirement_intake_entry_recommendation_fn,
        infer_intent_by_keywords_fn=infer_intent_by_keywords_fn,
        contains_any_text_fn=contains_any_text_fn,
        requirement_entry_structuring_terms=requirement_entry_structuring_terms,
    )


def build_keyword_suggestion(
    message: str,
    *,
    build_keyword_suggestion_from_router_fn: Callable[..., tuple[str, float, str, str]],
    resolve_requirement_intake_entry_recommendation_fn: Callable[[str], tuple[str, float, str, str]],
    infer_intent_by_keywords_fn: Callable[[str], str],
) -> tuple[str, float, str, str]:
    return build_keyword_suggestion_from_router_fn(
        message,
        resolve_requirement_intake_entry_recommendation_fn=resolve_requirement_intake_entry_recommendation_fn,
        infer_intent_by_keywords_fn=infer_intent_by_keywords_fn,
    )


async def resolve_request_intent_with_ai(
    req: KernelRequest,
    trace_id: str,
    *,
    resolve_request_intent_with_ai_from_router_fn: Callable[..., Any],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    normalize_message_for_intent_fn: Callable[..., str],
    looks_like_small_talk_fn: Callable[[str], bool],
    resolve_requirement_intake_entry_recommendation_fn: Callable[..., tuple[str, float, str, str]],
    contains_any_text_fn: Callable[[str, tuple[str, ...]], bool],
    requirement_entry_structuring_terms: tuple[str, ...],
    infer_intent_by_keywords_fn: Callable[[str], str],
    requirement_entry_context_terms: tuple[str, ...],
    generate_llm_completion_fn: Callable[..., Any],
    build_intent_classifier_prompt_fn: Callable[..., str],
    extract_json_object_fn: Callable[[str], dict[str, Any]],
    coerce_suggestable_mode_fn: Callable[[Any], str],
    build_keyword_suggestion_fn: Callable[[str], tuple[str, float, str, str]],
) -> tuple[str, str, float, str]:
    return await resolve_request_intent_with_ai_from_router_fn(
        req,
        trace_id,
        extract_user_message_fn=extract_user_message_fn,
        normalize_message_for_intent_fn=normalize_message_for_intent_fn,
        looks_like_small_talk_fn=looks_like_small_talk_fn,
        resolve_requirement_intake_entry_recommendation_fn=resolve_requirement_intake_entry_recommendation_fn,
        contains_any_text_fn=contains_any_text_fn,
        requirement_entry_structuring_terms=requirement_entry_structuring_terms,
        infer_intent_by_keywords_fn=infer_intent_by_keywords_fn,
        requirement_entry_context_terms=requirement_entry_context_terms,
        generate_llm_completion_fn=generate_llm_completion_fn,
        build_intent_classifier_prompt_fn=build_intent_classifier_prompt_fn,
        extract_json_object_fn=extract_json_object_fn,
        coerce_suggestable_mode_fn=coerce_suggestable_mode_fn,
        build_keyword_suggestion_fn=build_keyword_suggestion_fn,
    )


async def resolve_intent_suggestion(
    req: KernelRequest,
    trace_id: str,
    *,
    resolve_intent_suggestion_from_router_fn: Callable[..., Any],
    resolve_intent_override_fn: Callable[[KernelRequest], str],
    resolve_manual_mode_fn: Callable[[KernelRequest], str],
    resolve_current_mode_fn: Callable[[KernelRequest], str],
    suggestable_modes: set[str],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    normalize_message_for_intent_fn: Callable[..., str],
    looks_like_small_talk_fn: Callable[[str], bool],
    resolve_requirement_intake_entry_recommendation_fn: Callable[..., tuple[str, float, str, str]],
    infer_intent_by_keywords_fn: Callable[[str], str],
    generate_llm_completion_fn: Callable[..., Any],
    build_intent_classifier_prompt_fn: Callable[..., str],
    extract_json_object_fn: Callable[[str], dict[str, Any]],
    coerce_suggestable_mode_fn: Callable[[Any], str],
    build_keyword_suggestion_fn: Callable[[str], tuple[str, float, str, str]],
) -> tuple[str, float, str, str]:
    return await resolve_intent_suggestion_from_router_fn(
        req,
        trace_id,
        resolve_intent_override_fn=resolve_intent_override_fn,
        resolve_manual_mode_fn=resolve_manual_mode_fn,
        resolve_current_mode_fn=resolve_current_mode_fn,
        suggestable_modes=suggestable_modes,
        extract_user_message_fn=extract_user_message_fn,
        normalize_message_for_intent_fn=normalize_message_for_intent_fn,
        looks_like_small_talk_fn=looks_like_small_talk_fn,
        resolve_requirement_intake_entry_recommendation_fn=resolve_requirement_intake_entry_recommendation_fn,
        infer_intent_by_keywords_fn=infer_intent_by_keywords_fn,
        generate_llm_completion_fn=generate_llm_completion_fn,
        build_intent_classifier_prompt_fn=build_intent_classifier_prompt_fn,
        extract_json_object_fn=extract_json_object_fn,
        coerce_suggestable_mode_fn=coerce_suggestable_mode_fn,
        build_keyword_suggestion_fn=build_keyword_suggestion_fn,
    )
