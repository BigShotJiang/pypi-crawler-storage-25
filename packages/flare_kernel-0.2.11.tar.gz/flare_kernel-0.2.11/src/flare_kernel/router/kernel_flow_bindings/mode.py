"""Kernel-local mode binding helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest


def normalize_mode_candidate(
    raw_mode: Any,
    *,
    normalize_mode_candidate_from_router_fn: Callable[[Any, set[str]], str],
    routable_modes: set[str],
) -> str:
    return normalize_mode_candidate_from_router_fn(raw_mode, routable_modes=routable_modes)


def resolve_explicit_intent(
    req: KernelRequest,
    *,
    resolve_explicit_intent_from_router_fn: Callable[..., str],
    normalize_mode_candidate_fn: Callable[[Any], str],
) -> str:
    return resolve_explicit_intent_from_router_fn(
        req,
        normalize_mode_candidate_fn=normalize_mode_candidate_fn,
    )


def resolve_intent_override(
    req: KernelRequest,
    *,
    resolve_intent_override_from_router_fn: Callable[..., str],
    normalize_mode_candidate_fn: Callable[[Any], str],
) -> str:
    return resolve_intent_override_from_router_fn(
        req,
        normalize_mode_candidate_fn=normalize_mode_candidate_fn,
    )


def resolve_manual_mode(
    req: KernelRequest,
    *,
    resolve_manual_mode_from_router_fn: Callable[..., str],
    normalize_mode_candidate_fn: Callable[[Any], str],
) -> str:
    return resolve_manual_mode_from_router_fn(
        req,
        normalize_mode_candidate_fn=normalize_mode_candidate_fn,
    )


def resolve_current_mode(
    req: KernelRequest,
    *,
    resolve_current_mode_from_router_fn: Callable[..., str],
    normalize_mode_candidate_fn: Callable[[Any], str],
) -> str:
    return resolve_current_mode_from_router_fn(
        req,
        normalize_mode_candidate_fn=normalize_mode_candidate_fn,
    )


def resolve_request_mode(
    req: KernelRequest,
    resolved_intent: str,
    *,
    resolve_request_mode_from_router_fn: Callable[..., tuple[str, str]],
    resolve_command_fn: Callable[[KernelRequest], str],
    should_continue_active_intake_fn: Callable[[KernelRequest, str], bool],
    resolve_intent_override_fn: Callable[[KernelRequest], str],
    resolve_manual_mode_fn: Callable[[KernelRequest], str],
    resolve_current_mode_fn: Callable[[KernelRequest], str],
    resolve_explicit_intent_fn: Callable[[KernelRequest], str],
    normalize_mode_candidate_fn: Callable[[Any], str],
    resolve_analysis_route_fn: Callable[..., dict[str, Any]] | None = None,
) -> tuple[str, str]:
    return resolve_request_mode_from_router_fn(
        req,
        resolved_intent,
        resolve_command_fn=resolve_command_fn,
        should_continue_active_intake_fn=should_continue_active_intake_fn,
        resolve_intent_override_fn=resolve_intent_override_fn,
        resolve_manual_mode_fn=resolve_manual_mode_fn,
        resolve_current_mode_fn=resolve_current_mode_fn,
        resolve_explicit_intent_fn=resolve_explicit_intent_fn,
        normalize_mode_candidate_fn=normalize_mode_candidate_fn,
        resolve_analysis_route_fn=resolve_analysis_route_fn,
    )
