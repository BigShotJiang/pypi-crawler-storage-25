"""Delivery-time canonicalization helpers for intake fields."""

from __future__ import annotations

import re
from typing import Any

from flare_kernel.router.intake.numeric import detect_numeric_precision, parse_numeric_token


def _is_anniversary_duration_false_positive(text: str, duration_match: re.Match[str]) -> bool:
    unit = str(duration_match.group("unit") or "").strip()
    if unit != "周":
        return False
    following = text[duration_match.end():duration_match.end() + 1]
    return following == "年"


def canonicalize_delivery_time_value(raw_text: str) -> dict[str, Any] | None:
    text = str(raw_text or "").strip()
    if not text:
        return None
    precision = detect_numeric_precision(text)
    date_match = re.search(r"(?P<year>\d{4})[年/\-](?P<month>\d{1,2})[月/\-](?P<day>\d{1,2})日?", text)
    if date_match:
        year = int(date_match.group("year"))
        month = int(date_match.group("month"))
        day = int(date_match.group("day"))
        if 1 <= month <= 12 and 1 <= day <= 31:
            iso_text = f"{year:04d}-{month:02d}-{day:02d}"
            return {
                "status": "confirmed",
                "normalized_value": {"kind": "date", "value": iso_text, "precision": precision},
                "display_value": f"{year}年{month}月{day}日",
                "confidence": 0.9,
            }
    duration_match = re.search(r"(?P<number>\d+(?:\.\d+)?)\s*(?P<unit>天|周|个月|月)", text)
    if not duration_match:
        return None
    if _is_anniversary_duration_false_positive(text, duration_match):
        return None
    number = parse_numeric_token(duration_match.group("number"))
    if number is None:
        return None
    unit = str(duration_match.group("unit") or "").strip()
    value = int(round(number)) if float(number).is_integer() else number
    display_value = f"{value}{unit}"
    if precision == "approx":
        display_value = f"约{display_value}"
    return {
        "status": "confirmed",
        "normalized_value": {
            "kind": "duration",
            "value": value,
            "unit": unit,
            "precision": precision,
        },
        "display_value": display_value,
        "confidence": 0.87 if precision == "exact" else 0.8,
    }


__all__ = ["canonicalize_delivery_time_value"]
