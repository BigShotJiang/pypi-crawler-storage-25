"""Readiness metric normalization for intake orchestration."""

from __future__ import annotations

from typing import Any


def resolve_intake_readiness_metrics(
    *,
    total_coverage_raw: Any,
    required_coverage_raw: Any,
    analysis_entry_threshold_raw: Any,
    analyzability_score_raw: Any,
    analysis_entry_eligible_raw: Any,
    required_fields: list[str],
    required_missing: list[str],
    question_progress: dict[str, Any] | None = None,
    intake_strategy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    try:
        total_coverage = max(0.0, min(1.0, float(total_coverage_raw)))
    except (TypeError, ValueError):
        total_coverage = 0.0
    try:
        required_coverage = max(0.0, min(1.0, float(required_coverage_raw)))
    except (TypeError, ValueError):
        required_coverage = 0.0
    try:
        analysis_entry_threshold = max(0.0, min(1.0, float(analysis_entry_threshold_raw)))
    except (TypeError, ValueError):
        analysis_entry_threshold = 0.8
    try:
        analyzability_score = max(0.0, min(1.0, float(analyzability_score_raw)))
    except (TypeError, ValueError):
        analyzability_score = 0.0

    analysis_entry_eligible = bool(
        analysis_entry_eligible_raw is True
        or analyzability_score >= analysis_entry_threshold
        or total_coverage >= analysis_entry_threshold
    )

    normalized_required_fields = [str(item).strip() for item in required_fields if str(item).strip()]
    normalized_required_missing = [str(item).strip() for item in required_missing if str(item).strip()]
    if normalized_required_fields:
        required_total = max(1, len(normalized_required_fields))
        fallback_required_coverage = max(
            0.0,
            min(1.0, (required_total - len(normalized_required_missing)) / required_total),
        )
        if required_coverage < fallback_required_coverage:
            required_coverage = fallback_required_coverage
        if total_coverage < fallback_required_coverage:
            total_coverage = fallback_required_coverage

    if not analysis_entry_eligible and total_coverage >= analysis_entry_threshold:
        analysis_entry_eligible = True

    strategy_payload = intake_strategy if isinstance(intake_strategy, dict) else {}
    try:
        question_budget_max = int(strategy_payload.get("question_budget_max") or 3)
    except (TypeError, ValueError):
        question_budget_max = 3
    question_budget_max = max(1, min(8, question_budget_max))
    progress_payload = question_progress if isinstance(question_progress, dict) else {}
    try:
        question_index = int(progress_payload.get("current") or 0)
    except (TypeError, ValueError):
        question_index = 0
    question_budget_reached = bool(
        question_index > question_budget_max
        or (
            question_index >= question_budget_max
            and len(normalized_required_fields) > len(normalized_required_missing)
        )
    )
    if question_budget_reached:
        analysis_entry_eligible = True

    return {
        "required_coverage": required_coverage,
        "total_coverage": total_coverage,
        "analysis_entry_threshold": analysis_entry_threshold,
        "analyzability_score": analyzability_score,
        "analysis_entry_eligible": analysis_entry_eligible,
        "question_budget_max": question_budget_max,
        "question_budget_reached": question_budget_reached,
    }
