"""Workflow checkpoint projection for intake status."""

from __future__ import annotations

from typing import Any


def build_workflow_checkpoint_projection(
    *,
    intake_session_id: str,
    session_id: str,
    mode: str,
    current_stage: str,
    active_collecting: bool,
    ready_for_submit: bool,
    decision_point_active: bool,
    current_question: dict[str, Any] | None,
    confirmed_updates: list[dict[str, Any]],
    required_missing: list[str],
    blocking_reason: str,
    checkpoint_base: dict[str, Any] | None = None,
    question_progress: dict[str, Any] | None = None,
    updated_at: str = "",
) -> dict[str, Any]:
    checkpoint_base = checkpoint_base if isinstance(checkpoint_base, dict) else {}
    current_question_payload = current_question if isinstance(current_question, dict) else {}
    normalized_session_id = str(session_id or "").strip()
    normalized_intake_session_id = str(intake_session_id or "").strip()
    workflow_id = f"wf_{normalized_intake_session_id}" if normalized_intake_session_id else ""
    active_checkpoint_id = str(checkpoint_base.get("checkpoint_id") or "").strip()
    if not active_checkpoint_id and normalized_intake_session_id:
        question_key = str(current_question_payload.get("field_key") or "none").strip() or "none"
        active_checkpoint_id = f"ckpt_{normalized_intake_session_id}_question_{question_key}"
    if not active_checkpoint_id:
        return {}

    try:
        progress_current = int((question_progress or {}).get("current") or 0)
    except (TypeError, ValueError):
        progress_current = 0
    try:
        progress_total = int((question_progress or {}).get("total") or 0)
    except (TypeError, ValueError):
        progress_total = 0
    progress_total = max(progress_total, progress_current)
    try:
        base_version = int(checkpoint_base.get("version") or 0)
    except (TypeError, ValueError):
        base_version = 0

    if ready_for_submit:
        workflow_status = "succeeded"
        checkpoint_status = "succeeded"
    elif active_collecting:
        workflow_status = "waiting_user" if bool(current_question_payload) else "running"
        checkpoint_status = workflow_status
    else:
        workflow_status = "queued"
        checkpoint_status = "queued"

    if str(current_stage or "").strip().endswith(".blocked"):
        workflow_status = "blocked"
        checkpoint_status = "blocked"
    elif str(current_stage or "").strip().startswith("requirement_analysis"):
        workflow_status = "partial"
        checkpoint_status = "partial"

    confirmed_fields = []
    for item in confirmed_updates:
        if not isinstance(item, dict):
            continue
        field_key = str(item.get("field_key") or "").strip()
        if not field_key:
            continue
        confirmed_fields.append(
            {
                "field_key": field_key,
                "display_value": str(item.get("field_value") or "").strip(),
                "confidence": float(item.get("confidence") or 0.85),
            }
        )

    missing_fields = []
    for field_key in required_missing:
        normalized_field_key = str(field_key or "").strip()
        if not normalized_field_key:
            continue
        missing_fields.append(
            {
                "field_key": normalized_field_key,
                "reason": "required_missing",
                "blocks": True,
            }
        )
    convergence_score = (len(confirmed_fields) * 3) + max(0, 12 - len(missing_fields))
    computed_version = max(
        1,
        convergence_score + progress_current + (2 if ready_for_submit else 1) + (1 if decision_point_active else 0),
    )
    version = max(computed_version, base_version + 1)

    child_tasks = [
        {
            "task_id": f"{active_checkpoint_id}:understanding",
            "parent_checkpoint_id": active_checkpoint_id,
            "title": "需求理解与字段归一",
            "kind": "understanding",
            "status": "succeeded" if confirmed_fields else ("running" if active_collecting else "queued"),
            "progress_text": f"已确认 {len(confirmed_fields)} 项",
        },
        {
            "task_id": f"{active_checkpoint_id}:question_planning",
            "parent_checkpoint_id": active_checkpoint_id,
            "title": "下一问规划",
            "kind": "question_planning",
            "status": "waiting_user" if bool(current_question_payload) else ("succeeded" if ready_for_submit else "running"),
            "progress_text": str(current_question_payload.get("question_text") or "").strip(),
            "blocking_reason": str(blocking_reason or "").strip(),
        },
    ]
    if decision_point_active:
        child_tasks.append(
            {
                "task_id": f"{active_checkpoint_id}:analysis_entry",
                "parent_checkpoint_id": active_checkpoint_id,
                "title": "分析入口判定",
                "kind": "validation",
                "status": "waiting_user",
                "progress_text": "等待用户选择：开始分析或继续补充",
            }
        )

    checkpoint_stage = "clarification" if active_collecting else ("analysis" if str(current_stage or "").startswith("requirement_analysis") else "intake")
    checkpoints = [
        {
            "checkpoint_id": active_checkpoint_id,
            "seq": max(1, progress_current or 1),
            "title": "需求梳理",
            "stage": checkpoint_stage,
            "status": checkpoint_status,
            "mode": str(mode or "").strip(),
            "summary": f"已确认 {len(confirmed_fields)} 项，待确认 {len(missing_fields)} 项",
            "question": {
                "question_id": str(current_question_payload.get("question_id") or f"question::{current_question_payload.get('field_key') or ''}").strip(),
                "text": str(current_question_payload.get("question_text") or "").strip(),
                "target_fields": [str(current_question_payload.get("field_key") or "").strip()] if str(current_question_payload.get("field_key") or "").strip() else [],
            } if current_question_payload else None,
            "confirmed_fields": confirmed_fields,
            "missing_fields": missing_fields,
            "child_tasks": child_tasks,
            "blocking_reason": str(blocking_reason or "").strip(),
            "user_action_required": bool(current_question_payload) or bool(decision_point_active),
            "updated_at": str(updated_at or "").strip(),
            "question_progress": {
                "current": progress_current,
                "total": progress_total,
            },
        }
    ]

    checkpoint_state = str(checkpoint_base.get("checkpoint_state") or "").strip()
    if not checkpoint_state:
        checkpoint_state = "waiting_user" if workflow_status == "waiting_user" else ("completed" if workflow_status == "succeeded" else "active")

    return {
        "checkpoint_id": active_checkpoint_id,
        "intake_session_id": normalized_intake_session_id,
        "checkpoint_type": str(checkpoint_base.get("checkpoint_type") or "workflow").strip(),
        "checkpoint_state": checkpoint_state,
        "current_stage": str(current_stage or "").strip(),
        "question_key": str(current_question_payload.get("field_key") or checkpoint_base.get("question_key") or "").strip(),
        "ready_for_submit": bool(ready_for_submit),
        "decision_point_active": bool(decision_point_active),
        "waiting_user": bool(workflow_status in {"waiting_user", "blocked"}),
        "workflow_id": workflow_id,
        "session_id": normalized_session_id,
        "mode": str(mode or "").strip(),
        "status": workflow_status,
        "active_checkpoint_id": active_checkpoint_id,
        "version": version,
        "checkpoints": checkpoints,
        "updated_at": str(updated_at or checkpoint_base.get("updated_at") or "").strip(),
    }
