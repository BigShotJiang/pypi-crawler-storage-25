"""Helpers for intake clarification checks and user-facing status text."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.reasoning.intake.api import build_user_visible_intake_response


def extract_current_question_from_runtime(runtime_snapshot: dict[str, Any]) -> dict[str, Any] | None:
    mode_events = runtime_snapshot.get("mode_events")
    if not isinstance(mode_events, list):
        return None
    for event in reversed(mode_events):
        if not isinstance(event, dict):
            continue
        event_type = str(event.get("event_type") or "").strip()
        if event_type not in {"next_actions", "field_progress"}:
            continue
        payload = event.get("payload")
        if not isinstance(payload, dict):
            continue
        flow_state = str(payload.get("flow_state") or payload.get("collection_phase") or "").strip().lower()
        if flow_state and flow_state != "collecting":
            return None
        current_question = payload.get("current_question")
        if isinstance(current_question, dict):
            return current_question
        return None
    return None


def extract_intake_understanding_from_runtime(runtime_snapshot: dict[str, Any]) -> dict[str, Any] | None:
    mode_events = runtime_snapshot.get("mode_events")
    if not isinstance(mode_events, list):
        return None
    for event in reversed(mode_events):
        if not isinstance(event, dict):
            continue
        event_type = str(event.get("event_type") or "").strip()
        if event_type not in {"next_actions", "field_progress"}:
            continue
        payload = event.get("payload")
        if not isinstance(payload, dict):
            continue
        understanding = payload.get("intake_understanding")
        if isinstance(understanding, dict):
            return understanding
    return None


def build_requirement_collection_status(runtime_snapshot: dict[str, Any]) -> str:
    current_question = extract_current_question_from_runtime(runtime_snapshot)
    intake_understanding = extract_intake_understanding_from_runtime(runtime_snapshot)
    understanding_message = build_user_visible_intake_response(
        understanding_state=intake_understanding if isinstance(intake_understanding, dict) else None,
        current_question=current_question if isinstance(current_question, dict) else None,
    )
    if understanding_message:
        return understanding_message
    if not isinstance(current_question, dict):
        return (
            "我先把当前需求收口成可分析版本。"
            "会优先梳理：采购对象/品类、使用场景、数量与预算、交付时间地点、质量参数、供应商要求和风险约束。"
        )
    step_index = int(current_question.get("step_index") or 0)
    step_total = int(current_question.get("step_total") or 0)
    progress = f"（{step_index}/{step_total}）" if step_index > 0 and step_total > 0 else ""
    question_text = str(current_question.get("question_text") or "").strip()
    if step_index <= 1 and question_text:
        return (
            "我先把需求梳理到可分析阈值，再由你决定是否进入分析。\n\n"
            f"先确认一个关键点{progress}：{question_text}"
        )
    if question_text:
        return f"继续补充一个关键点{progress}：{question_text}"
    return f"请在输入区选择或填写当前关键问题{progress}。"


def _looks_like_prompt_instruction(term: str) -> bool:
    normalized = str(term or "").strip().lower()
    if not normalized:
        return False
    instruction_terms = ("帮我", "请", "先", "梳理", "整理", "分析", "找供应商", "寻源", "采购需求")
    return any(item in normalized for item in instruction_terms)


def should_force_requirement_clarification(
    req: KernelRequest,
    *,
    message: str,
    normalize_message_for_intent_fn: Callable[[KernelRequest, str, dict[str, Any] | None], str],
    extract_quoted_terms_fn: Callable[[str], list[str]],
    resolve_intent_aliases_fn: Callable[[KernelRequest, dict[str, Any] | None], dict[str, str]],
    retrieved_knowledge: list[dict[str, Any]] | None = None,
    instance_profile: dict[str, Any] | None = None,
) -> bool:
    clean_message = str(message or "").strip()
    if not clean_message:
        return False
    if isinstance(retrieved_knowledge, list) and len(retrieved_knowledge) > 0:
        return False

    _ = normalize_message_for_intent_fn(req, clean_message, instance_profile)
    quoted_terms = extract_quoted_terms_fn(clean_message)
    if not quoted_terms:
        return False

    aliases = resolve_intent_aliases_fn(req, instance_profile)
    alias_keys = {key.lower() for key in aliases.keys()}
    alias_values = {value.lower() for value in aliases.values()}
    for term in quoted_terms:
        if _looks_like_prompt_instruction(term):
            continue
        lowered = term.lower()
        if lowered in alias_keys or lowered in alias_values:
            continue
        return True
    return False


def build_requirement_clarification_message(message: str, *, extract_quoted_terms_fn: Callable[[str], list[str]]) -> str:
    quoted_terms = extract_quoted_terms_fn(message)
    term_text = quoted_terms[0] if quoted_terms else "该术语"
    return (
        f"我还不能确认“{term_text}”在当前需求里的具体含义，所以先不替你猜。\n\n"
        "为了继续梳理，我需要先确认它属于哪类信息：\n"
        "1. 项目/系统/品牌名称\n"
        "2. 采购对象或业务场景\n"
        "3. 资料里的专有术语或线索\n\n"
        "确认后我会继续收口采购对象、使用场景、数量预算、交付要求、质量参数、供应商要求和风险约束。"
    )
