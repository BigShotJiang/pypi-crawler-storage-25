"""Intake extraction scope helpers."""

from __future__ import annotations

from typing import Any


def resolve_intake_allowed_fields(payload: dict[str, Any]) -> list[str]:
    if not isinstance(payload, dict):
        return []
    resolved: list[str] = []
    seen: set[str] = set()

    def append_field(field_key: Any) -> None:
        key = str(field_key or "").strip()
        if not key or key in seen:
            return
        seen.add(key)
        resolved.append(key)

    field_definitions = payload.get("field_definitions")
    if isinstance(field_definitions, list):
        for item in field_definitions:
            if not isinstance(item, dict):
                continue
            append_field(item.get("key"))

    for key in ("required_fields", "recommended_fields", "optional_fields"):
        values = payload.get(key)
        if not isinstance(values, list):
            continue
        for field_key in values:
            append_field(field_key)

    existing_fields = payload.get("fields")
    if isinstance(existing_fields, dict):
        for field_key in existing_fields.keys():
            append_field(field_key)

    return resolved
