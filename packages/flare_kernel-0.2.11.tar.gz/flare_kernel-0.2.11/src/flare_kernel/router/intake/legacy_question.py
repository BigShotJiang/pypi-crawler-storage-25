"""Legacy intake question guards."""

from __future__ import annotations

from typing import Any


_LEGACY_QUESTION_PREFIXES = (
    "请补充字段：",
    "请补充：",
    "请补充 ",
    "请确认：",
    "请确认 ",
)


def is_legacy_question_payload(question: Any) -> bool:
    if not isinstance(question, dict):
        return False
    text = str(question.get("question_text") or "").strip()
    return any(text.startswith(prefix) for prefix in _LEGACY_QUESTION_PREFIXES)


__all__ = ["is_legacy_question_payload"]
