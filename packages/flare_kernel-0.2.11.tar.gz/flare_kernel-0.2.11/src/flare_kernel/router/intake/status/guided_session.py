"""Guided-session shaping helpers for intake status projections."""

from __future__ import annotations

from flare_kernel.router.intake.guided.confirmed_updates import build_confirmed_updates
from flare_kernel.router.intake.guided.flags import resolve_guided_session_flags
from flare_kernel.router.intake.guided.followup import build_intake_followup_state
from flare_kernel.router.intake.guided.open_fields import build_open_fields
from flare_kernel.router.intake.guided.status import build_guided_session_status
from flare_kernel.router.intake.guided.summary import build_guided_session_summary


__all__ = [
    "build_confirmed_updates",
    "build_guided_session_status",
    "build_guided_session_summary",
    "build_intake_followup_state",
    "build_open_fields",
    "resolve_guided_session_flags",
]
