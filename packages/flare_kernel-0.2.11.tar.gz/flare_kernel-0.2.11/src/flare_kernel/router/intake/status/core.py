"""Intake status shaping helpers for router orchestration output."""

from __future__ import annotations

from flare_kernel.router.intake.status.chooser_stage import (
    build_status_chooser,
    pick_next_action,
    resolve_current_stage,
)
from flare_kernel.router.intake.status.guided_session import (
    build_confirmed_updates,
    build_guided_session_status,
    build_guided_session_summary,
    build_intake_followup_state,
    build_open_fields,
    resolve_guided_session_flags,
)
from flare_kernel.router.intake.status.projection import (
    build_active_checkpoint,
    build_field_label_map,
    build_fallback_active_checkpoint,
    build_search_actions,
    build_structured_search_results,
    build_workspace_updates,
    build_workflow_checkpoint_projection,
    compute_domain_relevance,
    compute_procurement_relevance,
)

__all__ = [
    "build_active_checkpoint",
    "build_confirmed_updates",
    "build_field_label_map",
    "build_fallback_active_checkpoint",
    "build_guided_session_status",
    "build_guided_session_summary",
    "build_intake_followup_state",
    "build_open_fields",
    "build_search_actions",
    "build_status_chooser",
    "build_structured_search_results",
    "build_workspace_updates",
    "build_workflow_checkpoint_projection",
    "compute_domain_relevance",
    "compute_procurement_relevance",
    "pick_next_action",
    "resolve_current_stage",
    "resolve_guided_session_flags",
]
