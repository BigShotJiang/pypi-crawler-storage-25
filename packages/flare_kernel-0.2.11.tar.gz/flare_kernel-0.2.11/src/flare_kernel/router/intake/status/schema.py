"""Canonical/intake status schema helpers shared by kernel router wrappers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.runtime.domain.domain_pack_loader import resolve_domain_pack_domain


def build_confirmed_fields_schema(
    fields: dict[str, Any],
    field_entities: dict[str, Any] | None = None,
) -> dict[str, Any]:
    confirmed: dict[str, Any] = {}
    normalized_entities = field_entities if isinstance(field_entities, dict) else {}
    for key, value in fields.items():
        field_key = str(key).strip()
        if not field_key:
            continue
        rendered = str(value or "").strip()
        if not rendered:
            continue
        entity = normalized_entities.get(field_key) if isinstance(normalized_entities.get(field_key), dict) else {}
        source_value = entity.get("source") if isinstance(entity, dict) else None
        source_payload = source_value if isinstance(source_value, dict) else {
            "type": str(source_value or "user_extracted"),
        }
        confirmed[field_key] = {
            "value": rendered,
            "raw_value": str(entity.get("raw_value") or rendered).strip() if isinstance(entity, dict) else rendered,
            "normalized_value": entity.get("normalized_value") if isinstance(entity, dict) else {"kind": "text", "value": rendered},
            "display_value": str(entity.get("display_value") or rendered).strip() if isinstance(entity, dict) else rendered,
            "source": source_payload,
            "confidence": float(entity.get("confidence") or 0.9) if isinstance(entity, dict) else 0.9,
        }
    return confirmed


def build_missing_fields_schema(required_missing: list[str]) -> dict[str, Any]:
    required = [
        {
            "field_key": field_key,
            "reason": "关键字段缺失会影响后续方案质量。",
            "blocks": True,
        }
        for field_key in required_missing
    ]
    return {
        "required": required,
        "recommended": [],
        "optional": [],
    }


def normalize_stage_status(
    *,
    current_stage: str,
    required_missing: list[str],
    activated_mode: str,
    question: dict[str, Any] | None,
    command: str,
    has_analysis_content: bool,
    flow_allowed_statuses_by_stage: dict[str, set[str]],
    analysis_entry_eligible: bool = False,
) -> tuple[str, str]:
    stage_key = "general_chat"
    status_key = "idle"
    stage_text = str(current_stage or "").strip()
    if stage_text.startswith("requirement_intake"):
        stage_key = "requirement_intake"
        if question:
            status_key = "collecting"
        elif required_missing and not analysis_entry_eligible:
            status_key = "blocked"
        else:
            status_key = "ready_for_submit"
    elif stage_text.startswith("requirement_analysis"):
        stage_key = "requirement_analysis"
        status_key = "active" if has_analysis_content else "completed"
    elif stage_text.startswith("sourcing"):
        stage_key = "general_chat"
        status_key = "idle"
    if command == "generate_analysis" and activated_mode == "requirement_intake" and (not required_missing or analysis_entry_eligible):
        stage_key = "requirement_analysis"
        status_key = "active"
    if activated_mode == "auto":
        stage_key = "general_chat"
        status_key = "idle"
    allowed = flow_allowed_statuses_by_stage.get(stage_key, {"idle"})
    if status_key not in allowed:
        status_key = "idle"
    return stage_key, status_key


def coerce_intent_escalation_policy(
    raw_policy: Any,
    *,
    default_policy: dict[str, Any],
) -> dict[str, Any]:
    policy = dict(default_policy)
    if isinstance(raw_policy, dict):
        for key in (
            "recommendation_min_confidence",
            "auto_mode_override_min_confidence",
        ):
            if key in raw_policy:
                try:
                    value = float(raw_policy.get(key))
                except (TypeError, ValueError):
                    continue
                policy[key] = max(0.0, min(1.0, value))
        for key in (
            "enable_recommendation_trigger",
            "enable_auto_mode_override",
            "require_domain_relevance_for_recommendation",
            "require_domain_relevance_for_auto_override",
        ):
            if key in raw_policy:
                policy[key] = bool(raw_policy.get(key))
        if "require_procurement_relevance_for_recommendation" in raw_policy:
            policy["require_domain_relevance_for_recommendation"] = bool(
                raw_policy.get("require_procurement_relevance_for_recommendation")
            )
        if "require_procurement_relevance_for_auto_override" in raw_policy:
            policy["require_domain_relevance_for_auto_override"] = bool(
                raw_policy.get("require_procurement_relevance_for_auto_override")
            )
    else:
        if "require_procurement_relevance_for_recommendation" in policy:
            policy["require_domain_relevance_for_recommendation"] = bool(
                policy.get("require_procurement_relevance_for_recommendation")
            )
        if "require_procurement_relevance_for_auto_override" in policy:
            policy["require_domain_relevance_for_auto_override"] = bool(
                policy.get("require_procurement_relevance_for_auto_override")
            )
    if "require_procurement_relevance_for_recommendation" in policy:
        policy.pop("require_procurement_relevance_for_recommendation", None)
    if "require_procurement_relevance_for_auto_override" in policy:
        policy.pop("require_procurement_relevance_for_auto_override", None)
    if "require_domain_relevance_for_recommendation" not in policy:
        policy["require_domain_relevance_for_recommendation"] = bool(
            default_policy.get("require_domain_relevance_for_recommendation")
        )
    if "require_domain_relevance_for_auto_override" not in policy:
        policy["require_domain_relevance_for_auto_override"] = bool(
            default_policy.get("require_domain_relevance_for_auto_override")
        )
    return policy


def resolve_intent_escalation_policy_with_source(
    *,
    req: Any,
    runtime_snapshot: dict[str, Any] | None,
    default_policy: dict[str, Any],
    coerce_intent_escalation_policy_fn: Callable[[Any], dict[str, Any]],
    load_domain_pack_fn: Callable[..., Any],
) -> tuple[dict[str, Any], str]:
    resolved = dict(default_policy)
    policy_source = "default"
    workflow_policy: dict[str, Any] | None = None
    if isinstance(runtime_snapshot, dict):
        domain_pack = runtime_snapshot.get("domain_pack")
        if isinstance(domain_pack, dict):
            workflow = domain_pack.get("workflow")
            if isinstance(workflow, dict):
                raw = workflow.get("intent_escalation_policy")
                if isinstance(raw, dict):
                    workflow_policy = raw
    if workflow_policy is None:
        domain_pack = load_domain_pack_fn(
            instance_id=req.instance_id,
            domain_pack_version=req.domain_pack_version,
            domain=resolve_domain_pack_domain(payload=req.payload),
            payload=req.payload if isinstance(req.payload, dict) else {},
            tenant_id=getattr(req, "tenant_id", ""),
        )
        workflow = domain_pack.workflow.raw if domain_pack.workflow is not None else {}
        if isinstance(workflow, dict):
            raw = workflow.get("intent_escalation_policy")
            if isinstance(raw, dict):
                workflow_policy = raw
    if isinstance(workflow_policy, dict):
        resolved.update(coerce_intent_escalation_policy_fn(workflow_policy))
        policy_source = "domain_pack"
    payload = req.payload if isinstance(req.payload, dict) else {}
    override_policy = payload.get("intent_escalation_policy")
    if isinstance(override_policy, dict):
        resolved.update(coerce_intent_escalation_policy_fn(override_policy))
        policy_source = "payload_override"
    return coerce_intent_escalation_policy_fn(resolved), policy_source
