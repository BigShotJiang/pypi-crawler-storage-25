"""Chooser and stage resolution helpers for intake status projections."""

from __future__ import annotations

from typing import Any


def pick_next_action(next_actions_payload: dict[str, Any]) -> dict[str, Any]:
    actions = next_actions_payload.get("actions")
    if not isinstance(actions, list):
        actions = next_actions_payload.get("next_actions")
    if not isinstance(actions, list):
        actions = []
    available = [
        item
        for item in actions
        if isinstance(item, dict) and str(item.get("status") or "").strip().lower() != "blocked"
    ]
    selected = available[0] if available else (actions[0] if actions else {})
    if not isinstance(selected, dict):
        selected = {}
    return {
        "action_key": str(selected.get("action_key") or selected.get("type") or "").strip(),
        "reason": str(selected.get("reason") or "").strip(),
        "target_mode": str(selected.get("target_mode") or "").strip(),
        "target_field": str(selected.get("target_field") or "").strip(),
    }


def build_status_chooser(
    *,
    current_question: dict[str, Any] | None,
    next_actions_payload: dict[str, Any],
    open_fields: list[dict[str, Any]],
    retrieval_attempted: bool,
    retrieval_hits: int,
) -> dict[str, Any] | None:
    if not isinstance(current_question, dict):
        return None
    actions = next_actions_payload.get("actions")
    if not isinstance(actions, list):
        actions = next_actions_payload.get("next_actions")
    if not isinstance(actions, list):
        actions = []
    blocking_action = None
    for item in actions:
        if not isinstance(item, dict):
            continue
        if str(item.get("action_key") or item.get("type") or "").strip() != "continue_collection":
            continue
        if str(item.get("blocking_reason") or "").strip():
            blocking_action = item
            break
    blocking_reason = str((blocking_action or {}).get("blocking_reason") or "").strip()
    if not blocking_reason:
        blocking_reason = "关键字段缺失，需先确认当前问题。"

    options_raw = current_question.get("options")
    options = []
    if isinstance(options_raw, list):
        for index, item in enumerate(options_raw[:6], start=1):
            option_payload = item if isinstance(item, dict) else {"label": item}
            option_text = str(
                option_payload.get("label")
                or option_payload.get("text")
                or option_payload.get("value")
                or ""
            ).strip()
            if not option_text:
                continue
            options.append(
                {
                    "key": str(option_payload.get("key") or f"option_{index}").strip(),
                    "label": option_text,
                    "impact": "将直接用于更新当前字段。",
                    "value": str(option_payload.get("value") or option_text).strip(),
                    "followup_hint": str(option_payload.get("followup_hint") or "").strip(),
                    "requires_custom_input": bool(
                        option_payload.get("requires_custom_input")
                        or option_payload.get("allow_custom_input")
                    ),
                    "recommended": index == 1,
                }
            )
    has_custom_input_option = any(item.get("requires_custom_input") is True for item in options)
    if not has_custom_input_option:
        options.append(
            {
                "key": "other_input",
                "label": "其他（我来输入）",
                "impact": "可提供更精确的字段值。",
                "value": "",
                "followup_hint": "",
                "requires_custom_input": True,
                "recommended": len(options) == 0,
            }
        )
    return {
        "blocking_point": str(current_question.get("question_text") or "").strip() or "当前关键字段待确认",
        "blocking_reason": blocking_reason,
        "target_field": str(current_question.get("field_key") or "").strip(),
        "question_kind": str(current_question.get("question_kind") or "field").strip() or "field",
        "branch_node_key": str(current_question.get("branch_node_key") or "").strip(),
        "decision_needed": "当前问题需要用户选择或输入后才能继续推进计划。",
        "options": options[:6],
        "recommended_option_key": str(options[0].get("key") or "other_input") if options else "other_input",
        "retrieval_attempted": retrieval_attempted,
        "retrieval_hits": retrieval_hits,
    }


def resolve_current_stage(
    *,
    mode_key: str,
    mode_state: str,
    open_fields: list[dict[str, Any]],
    chooser: dict[str, Any] | None,
) -> str:
    normalized_mode = str(mode_key or "").strip()
    normalized_state = str(mode_state or "").strip()
    if normalized_mode == "intelligent_sourcing":
        return "compare_replace"
    if normalized_mode == "requirement_intake":
        if normalized_state == "drafting":
            return "requirement_analysis"
        if chooser:
            return "focused_clarifying"
        if open_fields:
            return "requirement_structuring"
        return "requirement_analysis"
    return "intent_detecting"


__all__ = [
    "build_status_chooser",
    "pick_next_action",
    "resolve_current_stage",
]
