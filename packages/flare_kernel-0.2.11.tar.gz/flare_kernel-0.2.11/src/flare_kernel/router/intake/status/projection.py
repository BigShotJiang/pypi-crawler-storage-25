"""Checkpoint and workspace projection helpers for intake status."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.workflow_checkpoint import (
    build_workflow_checkpoint_projection,
)


def build_active_checkpoint(intake_checkpoint: dict[str, Any]) -> dict[str, Any]:
    payload = {
        "checkpoint_id": str(intake_checkpoint.get("checkpoint_id") or "").strip(),
        "intake_session_id": str(intake_checkpoint.get("intake_session_id") or "").strip(),
        "checkpoint_type": str(intake_checkpoint.get("checkpoint_type") or "").strip(),
        "checkpoint_state": str(intake_checkpoint.get("checkpoint_state") or "").strip(),
        "current_stage": str(intake_checkpoint.get("current_stage") or "").strip(),
        "question_key": str(intake_checkpoint.get("question_key") or "").strip(),
        "ready_for_submit": bool(intake_checkpoint.get("ready_for_submit")),
        "decision_point_active": bool(intake_checkpoint.get("decision_point_active")),
        "updated_at": str(intake_checkpoint.get("updated_at") or "").strip(),
    }
    if not payload["checkpoint_id"]:
        return {}
    return payload


def build_field_label_map(field_definitions: Any) -> dict[str, str]:
    mapping: dict[str, str] = {}
    if not isinstance(field_definitions, list):
        return mapping
    for item in field_definitions:
        if not isinstance(item, dict):
            continue
        field_key = str(item.get("key") or "").strip()
        field_label = str(item.get("label") or "").strip()
        if field_key and field_label:
            mapping[field_key] = field_label
    return mapping


def build_search_actions(
    *,
    retrieval_attempted: bool,
    retrieval_queries: list[str],
    retrieved_knowledge: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    if not retrieval_attempted:
        return []
    return [
        {
            "action": "knowledge_search",
            "queries": retrieval_queries,
            "result_count": len(retrieved_knowledge),
            "status": "completed",
        }
    ]


def build_structured_search_results(
    *,
    results: list[dict[str, Any]],
    open_fields: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    target_field = str((open_fields[0] if open_fields else {}).get("field_key") or "").strip()
    structured: list[dict[str, Any]] = []
    for item in results:
        if not isinstance(item, dict):
            continue
        source = str(item.get("source_type") or item.get("source") or "local").strip() or "local"
        title = str(item.get("title") or item.get("source_label") or "证据条目").strip() or "证据条目"
        snippet = str(item.get("content") or item.get("snippet") or "").strip()
        score_raw = item.get("score")
        try:
            confidence = max(0.0, min(1.0, float(score_raw)))
        except Exception:
            confidence = 0.0
        candidate_value = title
        why_relevant = f"用于补充字段 {target_field}" if target_field else "与当前需求主题相关。"
        structured.append(
            {
                **item,
                "source": source,
                "title": title,
                "snippet": snippet[:220],
                "matched_field": target_field,
                "candidate_value": candidate_value,
                "confidence": confidence,
                "why_relevant": why_relevant,
                "selectable_for_replace": bool(target_field and candidate_value),
            }
        )
    return structured


def build_fallback_active_checkpoint(
    *,
    intake_session_id: str,
    current_question: dict[str, Any] | None,
    ready_for_submit: bool,
    decision_point_active: bool,
    current_stage: str,
    updated_at: str,
) -> dict[str, Any]:
    return {
        "checkpoint_id": f"ckpt_{intake_session_id}_entry" if intake_session_id else "",
        "intake_session_id": intake_session_id,
        "checkpoint_type": "workflow",
        "checkpoint_state": "waiting_user" if bool(current_question) else ("completed" if ready_for_submit else "active"),
        "current_stage": current_stage,
        "question_key": str((current_question or {}).get("field_key") or "").strip(),
        "ready_for_submit": bool(ready_for_submit),
        "decision_point_active": bool(decision_point_active),
        "updated_at": str(updated_at or "").strip(),
    }


def build_workspace_updates(
    *,
    retrieval_attempted: bool,
    retrieved_knowledge_count: int,
    confirmed_updates: list[dict[str, Any]],
    open_fields: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "search_workspace": {
            "updated": retrieval_attempted,
            "evidence_count": int(retrieved_knowledge_count),
        },
        "requirement_workspace": {
            "updated_fields": [item.get("field_key") for item in confirmed_updates],
            "pending_fields": [item.get("field_key") for item in open_fields],
        },
    }


def compute_domain_relevance(*, resolved_intent: str, resolved_mode: str) -> bool:
    normalized_intent = str(resolved_intent or "").strip()
    normalized_mode = str(resolved_mode or "").strip()
    return bool(
        normalized_intent in {"requirement_intake", "intelligent_sourcing"}
        or normalized_mode in {"requirement_intake", "intelligent_sourcing"}
    )


def compute_procurement_relevance(*, resolved_intent: str, resolved_mode: str) -> bool:
    """Compatibility alias for legacy callers."""
    return compute_domain_relevance(
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
    )


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return parsed


def build_round_projection(
    *,
    intake_session_id: str,
    stage_key: str,
    status_key: str,
    intake_session_state: str,
    current_question: dict[str, Any] | None,
    checkpoint: dict[str, Any] | None,
    next_actions: list[dict[str, Any]],
) -> dict[str, Any]:
    normalized_stage = str(stage_key or "").strip().lower()
    normalized_status = str(status_key or "").strip().lower()
    normalized_session_state = str(intake_session_state or "").strip().lower()
    question_payload = current_question if isinstance(current_question, dict) else {}

    round_question_total = _safe_int(question_payload.get("step_total"), 0)
    round_question_index = _safe_int(question_payload.get("step_index"), 0)

    checkpoint_payload = checkpoint if isinstance(checkpoint, dict) else {}
    workflow_checkpoints = checkpoint_payload.get("checkpoints")
    first_checkpoint = workflow_checkpoints[0] if isinstance(workflow_checkpoints, list) and workflow_checkpoints else {}
    round_seq = max(0, _safe_int(first_checkpoint.get("seq"), 0)) if isinstance(first_checkpoint, dict) else 0
    if round_question_total <= 0:
        progress_payload = first_checkpoint.get("question_progress") if isinstance(first_checkpoint, dict) else {}
        if isinstance(progress_payload, dict):
            round_question_total = max(0, _safe_int(progress_payload.get("total"), 0))
            round_question_index = max(round_question_index, _safe_int(progress_payload.get("current"), 0))
    if round_seq <= 0:
        round_seq = max(0, _safe_int(checkpoint_payload.get("version"), 0))
    if normalized_status == "ready_for_submit" and round_question_total > 0 and round_question_index <= 0:
        round_question_index = round_question_total

    if "interrupt" in normalized_session_state:
        round_state = "interrupted"
    elif normalized_stage.startswith("requirement_analysis"):
        round_state = "implement"
    elif normalized_status in {"collecting", "blocked"}:
        round_state = "collecting"
    elif normalized_status == "ready_for_submit":
        round_state = "completed"
    elif normalized_stage.startswith("requirement_intake"):
        round_state = "planning"
    else:
        round_state = "planning"

    normalized_round_id = str(intake_session_id or "").strip()
    if normalized_round_id and round_seq > 0:
        normalized_round_id = f"{normalized_round_id}:r{round_seq}"
    recommendations: list[str] = []
    for item in (next_actions if isinstance(next_actions, list) else []):
        if not isinstance(item, dict):
            continue
        action_key = str(item.get("action_key") or item.get("type") or "").strip()
        if not action_key or action_key in recommendations:
            continue
        recommendations.append(action_key)

    return {
        "round_id": normalized_round_id,
        "round_state": round_state,
        "round_question_total": max(0, round_question_total),
        "round_question_index": max(0, round_question_index),
        "round_completed": round_state == "completed",
        "round_interruptible": round_state in {"collecting", "implement"},
        "next_recommendations": recommendations,
    }


__all__ = [
    "build_active_checkpoint",
    "build_field_label_map",
    "build_fallback_active_checkpoint",
    "build_search_actions",
    "build_structured_search_results",
    "build_workspace_updates",
    "build_workflow_checkpoint_projection",
    "build_round_projection",
    "compute_domain_relevance",
    "compute_procurement_relevance",
]
