"""Router intake module group."""

from __future__ import annotations

import importlib
import sys

_LEGACY_MODULE_TARGETS = {
    "intake_amount_quantity": "flare_kernel.router.intake.amount_quantity",
    "intake_answer": "flare_kernel.router.intake.answer",
    "intake_authority": "flare_kernel.router.intake.authority.core",
    "intake_canonicalization": "flare_kernel.router.intake.canonicalization",
    "intake_clarification": "flare_kernel.router.intake.clarification",
    "intake_decision_rules": "flare_kernel.router.intake.decision_rules",
    "intake_delivery_time": "flare_kernel.router.intake.delivery_time",
    "intake_entry_policy": "flare_kernel.router.intake.entry_policy",
    "intake_authority_checkpoint": "flare_kernel.router.intake.authority.checkpoint",
    "intake_authority_hydration": "flare_kernel.router.intake.authority.hydration",
    "intake_authority_session": "flare_kernel.router.intake.authority.session",
    "intake_extraction": "flare_kernel.router.intake.extraction.core",
    "intake_extraction_extractors": "flare_kernel.router.intake.extraction.extractors",
    "intake_extraction_merge": "flare_kernel.router.intake.extraction.merge",
    "intake_field_projection": "flare_kernel.router.intake.field_projection.core",
    "intake_field_projection_entity": "flare_kernel.router.intake.field_projection.entity",
    "intake_field_projection_payload": "flare_kernel.router.intake.field_projection.payload",
    "intake_field_projection_source": "flare_kernel.router.intake.field_projection.source",
    "intake_field_scope": "flare_kernel.router.intake.field_scope",
    "intake_guided_confirmed_updates": "flare_kernel.router.intake.guided.confirmed_updates",
    "intake_guided_flags": "flare_kernel.router.intake.guided.flags",
    "intake_guided_followup": "flare_kernel.router.intake.guided.followup",
    "intake_guided_followup_work_item": "flare_kernel.router.intake.guided.followup_work_item",
    "intake_guided_open_fields": "flare_kernel.router.intake.guided.open_fields",
    "intake_guided_status": "flare_kernel.router.intake.guided.status",
    "intake_guided_summary": "flare_kernel.router.intake.guided.summary",
    "intake_inputs": "flare_kernel.router.intake.inputs",
    "intake_node_state": "flare_kernel.router.intake.node_state",
    "intake_numeric": "flare_kernel.router.intake.numeric",
    "intake_payload_updates": "flare_kernel.router.intake.payload_updates",
    "intake_readiness": "flare_kernel.router.intake.readiness",
    "intake_state_persistence": "flare_kernel.router.intake.state_persistence",
    "intake_status": "flare_kernel.router.intake.status.core",
    "intake_status_chooser_stage": "flare_kernel.router.intake.status.chooser_stage",
    "intake_status_guided_session": "flare_kernel.router.intake.status.guided_session",
    "intake_status_projection": "flare_kernel.router.intake.status.projection",
    "intake_status_schema": "flare_kernel.router.intake.status.schema",
    "intake_workflow_checkpoint": "flare_kernel.router.intake.workflow_checkpoint",
}


for _legacy_name, _target in _LEGACY_MODULE_TARGETS.items():
    sys.modules.setdefault(
        f"flare_kernel.router.intake.{_legacy_name}",
        importlib.import_module(_target),
    )
