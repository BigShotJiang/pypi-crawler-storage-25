"""Input extraction helpers for intake orchestration status."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.legacy_question import is_legacy_question_payload


def extract_mode_event_payload(runtime_snapshot: dict[str, Any], event_type: str) -> dict[str, Any]:
    mode_events = runtime_snapshot.get("mode_events")
    if not isinstance(mode_events, list):
        return {}
    for event in reversed(mode_events):
        if not isinstance(event, dict):
            continue
        if str(event.get("event_type") or "").strip() != event_type:
            continue
        payload = event.get("payload")
        if isinstance(payload, dict):
            return payload
    return {}


def extract_orchestration_status_inputs(runtime_snapshot: dict[str, Any]) -> dict[str, Any]:
    next_actions_payload = extract_mode_event_payload(runtime_snapshot, "next_actions")
    field_progress_payload = extract_mode_event_payload(runtime_snapshot, "field_progress")
    runtime_payload = runtime_snapshot.get("payload") if isinstance(runtime_snapshot.get("payload"), dict) else {}
    intake_checkpoint = (
        runtime_payload.get("intake_checkpoint")
        if isinstance(runtime_payload.get("intake_checkpoint"), dict)
        else {}
    )
    checkpoint_payload = (
        intake_checkpoint.get("payload")
        if isinstance(intake_checkpoint.get("payload"), dict)
        else {}
    )
    current_question = (
        next_actions_payload.get("current_question")
        if isinstance(next_actions_payload.get("current_question"), dict)
        else field_progress_payload.get("current_question")
    )
    question_progress = (
        next_actions_payload.get("question_progress")
        if isinstance(next_actions_payload.get("question_progress"), dict)
        else field_progress_payload.get("question_progress")
        if isinstance(field_progress_payload.get("question_progress"), dict)
        else {}
    )
    if not isinstance(current_question, dict):
        checkpoint_question = checkpoint_payload.get("current_question")
        if isinstance(checkpoint_question, dict) and not is_legacy_question_payload(checkpoint_question):
            current_question = checkpoint_question
    runtime_fields = runtime_payload.get("fields") if isinstance(runtime_payload.get("fields"), dict) else {}
    progress_fields = field_progress_payload.get("fields") if isinstance(field_progress_payload.get("fields"), dict) else {}
    fields = {
        **runtime_fields,
        **progress_fields,
    }
    runtime_field_entities = runtime_payload.get("field_entities") if isinstance(runtime_payload.get("field_entities"), dict) else {}
    progress_field_entities = (
        field_progress_payload.get("field_entities")
        if isinstance(field_progress_payload.get("field_entities"), dict)
        else {}
    )
    field_entities = {
        **runtime_field_entities,
        **progress_field_entities,
    }
    required_fields = field_progress_payload.get("required_fields")
    if not isinstance(required_fields, list):
        required_fields = next_actions_payload.get("required_fields")
    if not isinstance(required_fields, list):
        required_fields = []
    required_missing = next_actions_payload.get("required_missing")
    if not isinstance(required_missing, list):
        required_missing = field_progress_payload.get("required_missing")
    if not isinstance(required_missing, list):
        required_missing = checkpoint_payload.get("required_missing")
    if not isinstance(required_missing, list):
        required_missing = []
    intake_understanding = next_actions_payload.get("intake_understanding")
    if not isinstance(intake_understanding, dict):
        intake_understanding = field_progress_payload.get("intake_understanding")
    if not isinstance(intake_understanding, dict):
        intake_understanding = {}
    analyzability_score_raw = next_actions_payload.get("analyzability_score")
    if analyzability_score_raw is None:
        analyzability_score_raw = field_progress_payload.get("analyzability_score")
    total_coverage_raw = next_actions_payload.get("total_coverage")
    if total_coverage_raw is None:
        total_coverage_raw = field_progress_payload.get("total_coverage")
    required_coverage_raw = next_actions_payload.get("required_coverage")
    if required_coverage_raw is None:
        required_coverage_raw = field_progress_payload.get("required_coverage")
    analysis_entry_threshold_raw = next_actions_payload.get("analysis_entry_threshold")
    if analysis_entry_threshold_raw is None:
        analysis_entry_threshold_raw = field_progress_payload.get("analysis_entry_threshold")
    analysis_entry_eligible_raw = next_actions_payload.get("analysis_entry_eligible")
    if analysis_entry_eligible_raw is None:
        analysis_entry_eligible_raw = field_progress_payload.get("analysis_entry_eligible")
    return {
        "next_actions_payload": next_actions_payload if isinstance(next_actions_payload, dict) else {},
        "field_progress_payload": field_progress_payload if isinstance(field_progress_payload, dict) else {},
        "runtime_payload": runtime_payload,
        "intake_checkpoint": intake_checkpoint,
        "checkpoint_payload": checkpoint_payload,
        "current_question": current_question if isinstance(current_question, dict) else None,
        "question_progress": question_progress if isinstance(question_progress, dict) else {},
        "fields": fields,
        "field_entities": field_entities,
        "required_fields": required_fields,
        "required_missing": required_missing,
        "intake_understanding": intake_understanding,
        "analyzability_score_raw": analyzability_score_raw,
        "total_coverage_raw": total_coverage_raw,
        "required_coverage_raw": required_coverage_raw,
        "analysis_entry_threshold_raw": analysis_entry_threshold_raw,
        "analysis_entry_eligible_raw": analysis_entry_eligible_raw,
    }
