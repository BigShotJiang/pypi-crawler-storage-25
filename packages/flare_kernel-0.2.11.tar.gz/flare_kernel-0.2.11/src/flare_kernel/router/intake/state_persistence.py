"""Persistence helpers for authoritative intake state."""

from __future__ import annotations

from typing import Any, Callable


def _merge_confirmed_updates_into_runtime_payload(
    *,
    runtime_payload: dict[str, Any],
    orchestration_status: dict[str, Any],
) -> dict[str, Any]:
    merged_payload = dict(runtime_payload) if isinstance(runtime_payload, dict) else {}
    status = dict(orchestration_status) if isinstance(orchestration_status, dict) else {}
    confirmed_updates = status.get("confirmed_updates")
    if not isinstance(confirmed_updates, list):
        return merged_payload
    fields = merged_payload.get("fields")
    next_fields = dict(fields) if isinstance(fields, dict) else {}
    for item in confirmed_updates:
        if not isinstance(item, dict):
            continue
        field_key = str(item.get("field_key") or "").strip()
        field_value = str(item.get("field_value") or "").strip()
        if not field_key or not field_value:
            continue
        next_fields[field_key] = field_value
    if next_fields:
        merged_payload["fields"] = next_fields
    field_entities = status.get("field_entities")
    if isinstance(field_entities, dict):
        current_entities = merged_payload.get("field_entities")
        merged_payload["field_entities"] = {
            **(current_entities if isinstance(current_entities, dict) else {}),
            **field_entities,
        }
    return merged_payload


def persist_authoritative_intake_state(
    *,
    trace_id: str,
    session_id: str,
    project_id: str | None,
    user_id: str | None,
    command: str,
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    persist_intake_session_state_fn: Callable[..., dict[str, Any]],
    persist_intake_checkpoint_fn: Callable[..., dict[str, Any]],
) -> dict[str, Any]:
    if not isinstance(orchestration_status, dict):
        return {}
    intake_session_id = str(orchestration_status.get("intake_session_id") or "").strip()
    if not intake_session_id:
        return {}

    runtime_payload = runtime_snapshot.get("payload") if isinstance(runtime_snapshot.get("payload"), dict) else {}
    runtime_payload = _merge_confirmed_updates_into_runtime_payload(
        runtime_payload=runtime_payload,
        orchestration_status=orchestration_status,
    )
    session_store_state = persist_intake_session_state_fn(
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        command=command,
        runtime_payload=runtime_payload,
        orchestration_status=orchestration_status,
    )
    checkpoint_store_state = persist_intake_checkpoint_fn(
        trace_id=trace_id,
        session_id=session_id,
        command=command,
        orchestration_status=orchestration_status,
    )
    return {
        "session_store": session_store_state,
        "checkpoint_store": checkpoint_store_state,
    }
