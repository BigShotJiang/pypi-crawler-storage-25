"""Decision payload rewrite helpers for intake orchestration."""

from __future__ import annotations

from typing import Any


def apply_entry_recommendation_to_decision(
    *,
    decision_payload: dict[str, Any],
    command: str,
    current_question: dict[str, Any] | None,
    entry_mode: str,
    entry_confidence: float,
    entry_reason: str,
    entry_source: str,
) -> dict[str, Any]:
    should_offer_entry = bool(
        entry_mode == "requirement_intake"
        and command == "send_message"
        and not current_question
    )
    if not should_offer_entry:
        return decision_payload

    existing_actions = decision_payload.get("next_actions")
    normalized_actions = (
        [dict(item) for item in existing_actions if isinstance(item, dict)]
        if isinstance(existing_actions, list)
        else []
    )
    has_entry_action = any(
        str(item.get("action_key") or item.get("type") or "").strip() == "activate_requirement_intake"
        for item in normalized_actions
    )
    decision_payload["next_actions"] = normalized_actions
    decision_payload["entry_recommendation"] = {
        "mode": "requirement_intake",
        "action_key": "activate_requirement_intake",
        "label": "开启梳理模式",
        "confidence": entry_confidence,
        "reason": entry_reason,
        "source": entry_source,
    }
    return decision_payload


def enforce_intake_gate_transition(
    *,
    decision_payload: dict[str, Any],
    normalized_required_missing: list[str],
    current_question: dict[str, Any] | None,
) -> dict[str, Any]:
    raw_next_stage = str(decision_payload.get("next_stage") or "").strip()
    has_gap_advisory = bool(
        normalized_required_missing
        and raw_next_stage.startswith("requirement_analysis")
    )
    if not has_gap_advisory:
        return decision_payload

    if not str(decision_payload.get("gap_advisory") or "").strip():
        decision_payload["gap_advisory"] = "仍有关键字段建议补充；可继续分析，但需保留待补充项与假设。"
    if isinstance(current_question, dict):
        decision_payload["chooser_required"] = False

    existing_actions = decision_payload.get("next_actions")
    normalized_actions = (
        [item for item in existing_actions if isinstance(item, dict)]
        if isinstance(existing_actions, list)
        else []
    )
    continue_actions = [
        item
        for item in normalized_actions
        if str(item.get("action_key") or item.get("type") or "").strip() == "continue_collection"
    ]
    if continue_actions:
        keep_keys = {
            str(item.get("action_key") or item.get("type") or "").strip()
            for item in normalized_actions
        }
        existing_continue = any(key == "continue_collection" for key in keep_keys)
        if not existing_continue:
            normalized_actions.extend(continue_actions)
    decision_payload["next_actions"] = normalized_actions
    return decision_payload
