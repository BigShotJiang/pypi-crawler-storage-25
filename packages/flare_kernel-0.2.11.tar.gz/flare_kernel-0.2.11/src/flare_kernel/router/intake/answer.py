"""Intake answer payload normalization helpers."""

from __future__ import annotations

from typing import Any


def normalize_field_value_payload(raw: Any) -> tuple[str, str]:
    if isinstance(raw, dict):
        kind = str(raw.get("kind") or "").strip()
        display_value = str(raw.get("display_value") or "").strip()
        if not kind:
            value_candidate = str(raw.get("value") or "").strip()
            raw_candidate = str(raw.get("raw_value") or "").strip()
            candidate = display_value or value_candidate or raw_candidate
            if candidate:
                return candidate, display_value or value_candidate or raw_candidate
        if kind == "single_choice":
            return str(raw.get("value") or display_value).strip(), display_value or str(raw.get("value") or "").strip()
        if kind == "multi_choice":
            values = raw.get("values")
            if isinstance(values, list):
                rendered = "、".join(str(item).strip() for item in values if str(item).strip())
                return rendered, display_value or rendered
        if kind == "free_text":
            text = str(raw.get("text") or "").strip()
            return text, display_value or text
        if kind == "number":
            number = raw.get("number")
            unit = str(raw.get("unit") or "").strip()
            text = f"{number}{unit}" if number is not None else ""
            return text, display_value or text
        if kind == "range":
            min_value = raw.get("min")
            max_value = raw.get("max")
            unit = str(raw.get("currency") or raw.get("unit") or "").strip()
            text = f"{min_value}-{max_value}{unit}" if min_value is not None and max_value is not None else ""
            return text, display_value or text
        if kind == "candidate_ref":
            candidate = str(raw.get("candidate_id") or "").strip()
            return candidate, display_value or candidate
    return str(raw or "").strip(), str(raw or "").strip()
