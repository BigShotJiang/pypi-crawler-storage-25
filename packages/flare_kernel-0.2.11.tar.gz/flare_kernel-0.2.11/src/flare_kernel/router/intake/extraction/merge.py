"""Normalization and merge helpers for extracted intake fields."""

from __future__ import annotations

from typing import Any


def normalize_extracted_field_values(raw_extraction: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw_extraction, dict):
        return {"fields": {}, "supplementary_fields": {}, "inferred_requirements": []}
    normalized_fields: dict[str, str] = {}
    raw_fields = raw_extraction.get("fields")
    if isinstance(raw_fields, dict):
        for key, value in raw_fields.items():
            field_key = str(key or "").strip()
            field_value = str(value or "").strip()
            if field_key and field_value:
                normalized_fields[field_key] = field_value

    supplementary_fields = raw_extraction.get("supplementary_fields")
    normalized_supplementary = dict(supplementary_fields) if isinstance(supplementary_fields, dict) else {}
    inferred = raw_extraction.get("inferred_requirements")
    normalized_inferred = [
        str(item).strip()
        for item in inferred
        if str(item).strip()
    ] if isinstance(inferred, list) else []

    return {
        "fields": normalized_fields,
        "supplementary_fields": normalized_supplementary,
        "inferred_requirements": normalized_inferred,
    }


def merge_into_confirmed_fields(previous_confirmed: dict[str, Any], extracted: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
    merged = dict(previous_confirmed) if isinstance(previous_confirmed, dict) else {}
    extracted_sources: dict[str, str] = {}
    extracted_fields = extracted.get("fields")
    if not isinstance(extracted_fields, dict):
        return merged, extracted_sources
    for key, value in extracted_fields.items():
        field_key = str(key or "").strip()
        field_value = str(value or "").strip()
        if not field_key or not field_value:
            continue
        existing = merged.get(field_key)
        if existing not in (None, "", [], {}):
            continue
        merged[field_key] = field_value
        extracted_sources[field_key] = "message_extraction"
    return merged, extracted_sources


def merge_supplementary_fields(existing: Any, incoming: Any) -> dict[str, Any]:
    merged = dict(existing) if isinstance(existing, dict) else {}
    if not isinstance(incoming, dict):
        return merged
    for key, value in incoming.items():
        field_key = str(key or "").strip()
        if not field_key:
            continue
        if field_key not in merged:
            merged[field_key] = value
            continue
        current = merged[field_key]
        if isinstance(current, list) and isinstance(value, list):
            next_items = [*current]
            for item in value:
                if item not in next_items:
                    next_items.append(item)
            merged[field_key] = next_items
    return merged


def merge_inferred_requirements(existing: Any, incoming: Any) -> list[str]:
    merged: list[str] = []
    if isinstance(existing, list):
        merged.extend(str(item).strip() for item in existing if str(item).strip())
    if isinstance(incoming, list):
        for item in incoming:
            text = str(item).strip()
            if text and text not in merged:
                merged.append(text)
    return merged
