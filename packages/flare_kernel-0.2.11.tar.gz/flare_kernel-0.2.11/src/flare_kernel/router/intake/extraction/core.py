"""Message extraction and merge helpers for requirement intake fields."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.extraction.extractors import (
    extract_intake_budget as extract_intake_budget_from_router,
    extract_intake_constraints as extract_intake_constraints_from_router,
    extract_intake_delivery_time as extract_intake_delivery_time_from_router,
    extract_intake_fields_from_message as extract_intake_fields_from_message_from_router,
    extract_intake_goal as extract_intake_goal_from_router,
    extract_intake_quantity as extract_intake_quantity_from_router,
    extract_intake_use_case as extract_intake_use_case_from_router,
    is_intake_control_message as is_intake_control_message_from_router,
    resolve_intake_extraction_scope as resolve_intake_extraction_scope_from_router,
)
from flare_kernel.router.intake.extraction.merge import (
    merge_inferred_requirements as merge_inferred_requirements_from_router,
    merge_into_confirmed_fields as merge_into_confirmed_fields_from_router,
    merge_supplementary_fields as merge_supplementary_fields_from_router,
    normalize_extracted_field_values as normalize_extracted_field_values_from_router,
)
from flare_kernel.router.text_safety import (
    normalize_message_text as normalize_message_text_from_router,
)


def extract_intake_goal(message: str) -> str:
    return extract_intake_goal_from_router(message)


def extract_intake_use_case(message: str) -> str:
    return extract_intake_use_case_from_router(message)


def extract_intake_budget(message: str) -> str:
    return extract_intake_budget_from_router(message)


def extract_intake_quantity(message: str) -> str:
    return extract_intake_quantity_from_router(message)


def extract_intake_constraints(message: str) -> str:
    return extract_intake_constraints_from_router(message)


def extract_intake_delivery_time(message: str) -> str:
    return extract_intake_delivery_time_from_router(message)


def is_intake_control_message(message: str) -> bool:
    """Return whether message text is a control action instead of field content.

    Args:
        message: Raw text to normalize and check against intake control tokens.

    Returns:
        True when the text should not be persisted as a current-question answer.
    """
    return is_intake_control_message_from_router(message)


def resolve_intake_extraction_scope(context: dict[str, Any] | None = None) -> set[str]:
    return resolve_intake_extraction_scope_from_router(context)


def extract_intake_fields_from_message(message: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
    return extract_intake_fields_from_message_from_router(
        message,
        context,
        normalize_message_text_fn=normalize_message_text_from_router,
        resolve_intake_extraction_scope_fn=resolve_intake_extraction_scope,
        extract_intake_goal_fn=extract_intake_goal,
        extract_intake_use_case_fn=extract_intake_use_case,
        extract_intake_budget_fn=extract_intake_budget,
        extract_intake_quantity_fn=extract_intake_quantity,
        extract_intake_constraints_fn=extract_intake_constraints,
        extract_intake_delivery_time_fn=extract_intake_delivery_time,
    )


def normalize_extracted_field_values(raw_extraction: dict[str, Any]) -> dict[str, Any]:
    return normalize_extracted_field_values_from_router(raw_extraction)


def merge_into_confirmed_fields(previous_confirmed: dict[str, Any], extracted: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
    return merge_into_confirmed_fields_from_router(previous_confirmed, extracted)


def merge_supplementary_fields(existing: Any, incoming: Any) -> dict[str, Any]:
    return merge_supplementary_fields_from_router(existing, incoming)


def merge_inferred_requirements(existing: Any, incoming: Any) -> list[str]:
    return merge_inferred_requirements_from_router(existing, incoming)
