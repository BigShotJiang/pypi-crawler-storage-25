"""Canonicalization helpers for intake field values and entities."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.amount_quantity import (
    canonicalize_budget_value as canonicalize_budget_value_from_router,
    canonicalize_quantity_value as canonicalize_quantity_value_from_router,
)
from flare_kernel.router.intake.delivery_time import (
    canonicalize_delivery_time_value as canonicalize_delivery_time_value_from_router,
)
from flare_kernel.router.intake.field_projection.core import (
    build_field_source_payload as build_field_source_payload_from_router,
    build_unparsed_field_entity as build_unparsed_field_entity_from_router,
    canonicalize_field_entity as canonicalize_field_entity_from_router,
    canonicalize_payload_fields as canonicalize_payload_fields_from_router,
    extract_workspace_patch_value as extract_workspace_patch_value_from_router,
    is_field_entity_confirmed as is_field_entity_confirmed_from_router,
    resolve_field_evidence as resolve_field_evidence_from_router,
)
from flare_kernel.router.intake.numeric import (
    apply_amount_unit as apply_amount_unit_from_router,
    detect_numeric_precision as detect_numeric_precision_from_router,
    format_cny_amount as format_cny_amount_from_router,
    parse_numeric_token as parse_numeric_token_from_router,
    parse_simple_chinese_number as parse_simple_chinese_number_from_router,
)


def parse_simple_chinese_number(token: str) -> int | None:
    return parse_simple_chinese_number_from_router(token)


def parse_numeric_token(token: Any) -> float | None:
    return parse_numeric_token_from_router(token)


def apply_amount_unit(number: float, unit: str) -> int:
    return apply_amount_unit_from_router(number, unit)


def format_cny_amount(amount: int) -> str:
    return format_cny_amount_from_router(amount)


def detect_numeric_precision(text: str) -> str:
    return detect_numeric_precision_from_router(text)


def canonicalize_budget_value(raw_text: str) -> dict[str, Any] | None:
    return canonicalize_budget_value_from_router(raw_text)


def canonicalize_quantity_value(raw_text: str) -> dict[str, Any] | None:
    return canonicalize_quantity_value_from_router(raw_text)


def canonicalize_delivery_time_value(raw_text: str) -> dict[str, Any] | None:
    return canonicalize_delivery_time_value_from_router(raw_text)


def extract_workspace_patch_value(payload: dict[str, Any], field_key: str) -> str:
    return extract_workspace_patch_value_from_router(payload, field_key)


def build_field_source_payload(*, source_type: str, evidence_text: str) -> dict[str, Any]:
    return build_field_source_payload_from_router(source_type=source_type, evidence_text=evidence_text)


def resolve_field_evidence(payload: dict[str, Any], field_key: str, source_type: str) -> str:
    return resolve_field_evidence_from_router(payload, field_key, source_type)


def build_unparsed_field_entity(
    *,
    raw_text: str,
    source_type: str,
    evidence_text: str,
) -> dict[str, Any]:
    return build_unparsed_field_entity_from_router(
        raw_text=raw_text,
        source_type=source_type,
        evidence_text=evidence_text,
    )


def canonicalize_field_entity(
    *,
    field_key: str,
    raw_value: Any,
    source_type: str,
    evidence_text: str,
    field_definition: dict[str, Any] | None = None,
    field_semantics: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    return canonicalize_field_entity_from_router(
        field_key=field_key,
        raw_value=raw_value,
        source_type=source_type,
        evidence_text=evidence_text,
        field_definition=field_definition,
        field_semantics=field_semantics,
    )


def is_field_entity_confirmed(entity: Any) -> bool:
    return is_field_entity_confirmed_from_router(entity)


def canonicalize_payload_fields(payload: dict[str, Any]) -> dict[str, Any]:
    return canonicalize_payload_fields_from_router(payload)
