"""Node-state resolution helpers for orchestration status."""

from __future__ import annotations

from typing import Any


def resolve_intake_node_state(
    *,
    current_stage: str,
    current_question: dict[str, Any] | None,
    open_fields: list[dict[str, Any]],
    chooser: dict[str, Any] | None,
    decision_point_active: bool,
    decision_basis: list[dict[str, Any]],
    blocking_reason: str,
    checkpoint_state_value: str,
) -> dict[str, Any]:
    normalized_stage = str(current_stage or "").strip()
    normalized_blocking_reason = str(blocking_reason or "").strip()
    chooser_required = bool(
        normalized_stage.startswith("requirement_intake")
        and isinstance(current_question, dict)
    )
    resolved_chooser = chooser
    if not chooser_required:
        resolved_chooser = None
    if not normalized_blocking_reason and resolved_chooser:
        normalized_blocking_reason = str((resolved_chooser or {}).get("blocking_reason") or "").strip()

    node_reason = ""
    if decision_basis:
        first_basis = decision_basis[0] if isinstance(decision_basis[0], dict) else {}
        node_reason = str(first_basis.get("conclusion") or "").strip()
    if not node_reason:
        node_reason = normalized_blocking_reason
    if not node_reason and decision_point_active:
        node_reason = "关键字段已确认，请选择下一步。"

    node_id = "next_actions"
    node_state = "completed"
    needs_user_choice = False
    if chooser_required:
        node_id = "chooser"
        node_state = "blocked"
        needs_user_choice = True
    elif decision_point_active:
        node_id = "decision_point"
        node_state = "ready"
        needs_user_choice = True
    elif bool(normalized_stage.endswith(".blocked")):
        node_id = "blocker_policy"
        node_state = "blocked"
    elif normalized_stage.startswith("evidence_retrieval"):
        node_id = "evidence_retrieval"
        node_state = "running" if normalized_stage.endswith(".running") else "ready"
    elif normalized_stage.startswith("sourcing"):
        node_id = "sourcing"
        node_state = "running" if normalized_stage.endswith(".running") else "ready"
    elif len(open_fields) > 0:
        node_id = "field_extractor"
        node_state = "running"
    elif normalized_stage.startswith("requirement_analysis"):
        node_id = "summarize_update"
        node_state = "completed"

    if str(checkpoint_state_value or "").strip().lower() == "waiting_user" and isinstance(current_question, dict):
        needs_user_choice = True
        if node_id == "next_actions":
            node_id = "chooser"
            node_state = "blocked"
        if not node_reason:
            node_reason = "等待用户补充关键信息。"

    return {
        "node_id": node_id,
        "node_state": node_state,
        "node_reason": node_reason,
        "needs_user_choice": needs_user_choice,
        "chooser_required": chooser_required,
        "chooser": resolved_chooser,
        "blocking_reason": normalized_blocking_reason,
    }
