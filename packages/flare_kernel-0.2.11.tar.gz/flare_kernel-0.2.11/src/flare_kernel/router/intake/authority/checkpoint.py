"""Checkpoint payload projection helpers for authoritative intake state."""

from __future__ import annotations

from typing import Any


def build_intake_checkpoint_payload(*, checkpoint_snapshot: Any) -> dict[str, Any]:
    """Project a persisted checkpoint snapshot into a normalized payload."""
    if checkpoint_snapshot is None:
        return {}
    checkpoint_payload = (
        dict(checkpoint_snapshot.payload)
        if isinstance(getattr(checkpoint_snapshot, "payload", None), dict)
        else {}
    )
    workflow_checkpoint = (
        dict(checkpoint_payload.get("workflow_checkpoint"))
        if isinstance(checkpoint_payload.get("workflow_checkpoint"), dict)
        else {}
    )
    checkpoint_id = str(getattr(checkpoint_snapshot, "checkpoint_id", "") or "").strip()
    intake_session_id = str(getattr(checkpoint_snapshot, "intake_session_id", "") or "").strip()
    try:
        checkpoint_version = int(workflow_checkpoint.get("version") or 1)
    except (TypeError, ValueError):
        checkpoint_version = 1

    return {
        "checkpoint_id": checkpoint_id,
        "intake_session_id": intake_session_id,
        "checkpoint_type": str(getattr(checkpoint_snapshot, "checkpoint_type", "") or "").strip(),
        "checkpoint_state": str(getattr(checkpoint_snapshot, "checkpoint_state", "") or "").strip(),
        "current_stage": str(getattr(checkpoint_snapshot, "current_stage", "") or "").strip(),
        "question_key": str(getattr(checkpoint_snapshot, "question_key", "") or "").strip(),
        "ready_for_submit": bool(getattr(checkpoint_snapshot, "ready_for_submit", False)),
        "decision_point_active": bool(getattr(checkpoint_snapshot, "decision_point_active", False)),
        "updated_at": str(getattr(checkpoint_snapshot, "updated_at", "") or "").strip(),
        "workflow_id": str(
            workflow_checkpoint.get("workflow_id")
            or (f"wf_{intake_session_id}" if intake_session_id else "")
        ).strip(),
        "session_id": str(
            workflow_checkpoint.get("session_id") or getattr(checkpoint_snapshot, "session_id", "") or ""
        ).strip(),
        "mode": str(workflow_checkpoint.get("mode") or "").strip(),
        "status": str(workflow_checkpoint.get("status") or "").strip(),
        "active_checkpoint_id": str(workflow_checkpoint.get("active_checkpoint_id") or checkpoint_id).strip(),
        "version": max(1, checkpoint_version),
        "checkpoints": [
            item for item in workflow_checkpoint.get("checkpoints", [])
            if isinstance(item, dict)
        ] if isinstance(workflow_checkpoint.get("checkpoints"), list) else [],
        "payload": checkpoint_payload,
    }


__all__ = ["build_intake_checkpoint_payload"]
