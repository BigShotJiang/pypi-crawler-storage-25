"""Facade for authoritative intake payload helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.authority.checkpoint import (
    build_intake_checkpoint_payload as _build_intake_checkpoint_payload,
)
from flare_kernel.router.intake.authority.hydration import (
    hydrate_payload_from_authoritative_checkpoint as _hydrate_payload_from_authoritative_checkpoint,
    hydrate_payload_from_authoritative_intake_session as _hydrate_payload_from_authoritative_intake_session,
)
from flare_kernel.router.intake.authority.session import (
    build_intake_session_id as _build_intake_session_id,
    normalize_intake_session_id as _normalize_intake_session_id,
    resolve_intake_session_id as _resolve_intake_session_id,
)


def normalize_intake_session_id(value: Any) -> str:
    """Normalize intake session id to safe storage/transit format."""
    return _normalize_intake_session_id(value)


def build_intake_session_id(*, session_id: str, seed: str) -> str:
    """Build deterministic local intake session id."""
    return _build_intake_session_id(session_id=session_id, seed=seed)


def resolve_intake_session_id(
    *,
    payload: dict[str, Any],
    session_id: str,
    trace_id: str,
    command: str,
    resolved_mode: str,
    latest_persisted_intake_session_id: str = "",
    has_active_intake_payload: bool = False,
) -> str:
    """Resolve intake session id with payload-first and persisted fallback policy."""
    return _resolve_intake_session_id(
        payload=payload,
        session_id=session_id,
        trace_id=trace_id,
        command=command,
        resolved_mode=resolved_mode,
        latest_persisted_intake_session_id=latest_persisted_intake_session_id,
        has_active_intake_payload=has_active_intake_payload,
    )


def build_intake_checkpoint_payload(*, checkpoint_snapshot: Any) -> dict[str, Any]:
    """Build normalized checkpoint payload from persisted snapshot."""
    return _build_intake_checkpoint_payload(checkpoint_snapshot=checkpoint_snapshot)


def hydrate_payload_from_authoritative_intake_session(
    *,
    payload: dict[str, Any],
    persisted_payload: dict[str, Any],
    persisted_status: dict[str, Any],
) -> dict[str, Any]:
    """Hydrate incoming payload with persisted authoritative intake snapshot."""
    hydrated = _hydrate_payload_from_authoritative_intake_session(
        payload=payload,
        persisted_payload=persisted_payload,
        persisted_status=persisted_status,
    )
    incoming_fields = payload.get("fields") if isinstance(payload.get("fields"), dict) else {}
    if incoming_fields:
        hydrated["fields"] = dict(incoming_fields)
    return hydrated


def hydrate_payload_from_authoritative_checkpoint(
    *,
    payload: dict[str, Any],
    checkpoint_snapshot: Any,
) -> dict[str, Any]:
    """Hydrate incoming payload with persisted authoritative checkpoint state."""
    return _hydrate_payload_from_authoritative_checkpoint(
        payload=payload,
        checkpoint_snapshot=checkpoint_snapshot,
    )
