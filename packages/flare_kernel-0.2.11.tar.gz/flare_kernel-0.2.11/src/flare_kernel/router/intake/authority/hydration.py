"""Hydration policy helpers for authoritative intake payloads."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.authority.checkpoint import build_intake_checkpoint_payload
from flare_kernel.router.intake.legacy_question import is_legacy_question_payload


def hydrate_payload_from_authoritative_intake_session(
    *,
    payload: dict[str, Any],
    persisted_payload: dict[str, Any],
    persisted_status: dict[str, Any],
) -> dict[str, Any]:
    """Hydrate an incoming payload with persisted authoritative intake state."""
    merged = dict(payload) if isinstance(payload, dict) else {}
    persisted = dict(persisted_payload) if isinstance(persisted_payload, dict) else {}
    status = dict(persisted_status) if isinstance(persisted_status, dict) else {}

    persisted_fields = persisted.get("fields") if isinstance(persisted.get("fields"), dict) else {}
    incoming_fields = merged.get("fields") if isinstance(merged.get("fields"), dict) else {}
    if persisted_fields or incoming_fields:
        merged["fields"] = {
            **dict(persisted_fields),
            **dict(incoming_fields),
        }
    persisted_sources = persisted.get("field_sources") if isinstance(persisted.get("field_sources"), dict) else {}
    incoming_sources = merged.get("field_sources") if isinstance(merged.get("field_sources"), dict) else {}
    if persisted_sources or incoming_sources:
        merged["field_sources"] = {
            **dict(persisted_sources),
            **dict(incoming_sources),
        }

    for key in (
        "required_fields",
        "required_missing",
        "recommended_fields",
        "recommended_missing",
        "optional_fields",
        "optional_missing",
        "question_progress",
        "followup_question",
        "canvas_analysis_payload",
    ):
        if (key not in merged or merged.get(key) in (None, "", [], {})) and key in persisted:
            value = persisted.get(key)
            if key == "followup_question" and is_legacy_question_payload(value):
                continue
            merged[key] = value
    if (not isinstance(merged.get("canvas_analysis_payload"), dict)) and isinstance(status.get("canvas_analysis_payload"), dict):
        merged["canvas_analysis_payload"] = status.get("canvas_analysis_payload")

    if not str(merged.get("intake_session_id") or "").strip():
        session_id = str(status.get("intake_session_id") or persisted.get("intake_session_id") or "").strip()
        if session_id:
            merged["intake_session_id"] = session_id
    if not str(merged.get("intake_session_state") or "").strip():
        session_state = str(
            status.get("intake_session_state")
            or persisted.get("intake_session_state")
            or ""
        ).strip()
        if session_state:
            merged["intake_session_state"] = session_state
    if not isinstance(merged.get("intake_session_completed"), bool):
        completed = status.get("intake_session_completed")
        if isinstance(completed, bool):
            merged["intake_session_completed"] = completed

    return merged


def hydrate_payload_from_authoritative_checkpoint(
    *,
    payload: dict[str, Any],
    checkpoint_snapshot: Any,
) -> dict[str, Any]:
    """Hydrate an incoming payload with a persisted checkpoint snapshot."""
    merged = dict(payload) if isinstance(payload, dict) else {}
    checkpoint_state = build_intake_checkpoint_payload(checkpoint_snapshot=checkpoint_snapshot)
    if not checkpoint_state:
        return merged
    checkpoint_payload = (
        dict(checkpoint_state.get("payload"))
        if isinstance(checkpoint_state.get("payload"), dict)
        else {}
    )
    if checkpoint_state:
        merged["intake_checkpoint"] = checkpoint_state

    if not isinstance(merged.get("current_question"), dict):
        checkpoint_question = checkpoint_payload.get("current_question")
        if isinstance(checkpoint_question, dict) and not is_legacy_question_payload(checkpoint_question):
            merged["current_question"] = dict(checkpoint_question)

    for key in ("next_action", "guided_session"):
        if (key not in merged or merged.get(key) in (None, "", [], {})) and isinstance(checkpoint_payload.get(key), dict):
            merged[key] = dict(checkpoint_payload.get(key))

    for key in ("next_actions", "required_missing"):
        if (key not in merged or merged.get(key) in (None, "", [], {})) and isinstance(checkpoint_payload.get(key), list):
            merged[key] = list(checkpoint_payload.get(key))

    if not isinstance(merged.get("question_progress"), dict):
        checkpoint_question = merged.get("current_question")
        if isinstance(checkpoint_question, dict):
            try:
                step_index = max(1, int(checkpoint_question.get("step_index") or 1))
            except (TypeError, ValueError):
                step_index = 1
            try:
                step_total = max(step_index, int(checkpoint_question.get("step_total") or step_index))
            except (TypeError, ValueError):
                step_total = step_index
            merged["question_progress"] = {
                "current": step_index,
                "total": step_total,
                "intake_session_id": str(
                    merged.get("intake_session_id")
                    or checkpoint_state.get("intake_session_id")
                    or ""
                ).strip(),
                "resumed": True,
            }
    return merged


__all__ = [
    "hydrate_payload_from_authoritative_checkpoint",
    "hydrate_payload_from_authoritative_intake_session",
]
