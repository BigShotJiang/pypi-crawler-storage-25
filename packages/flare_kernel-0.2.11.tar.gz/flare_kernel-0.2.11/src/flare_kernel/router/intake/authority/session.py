"""Session-id helpers for authoritative intake payload resolution."""

from __future__ import annotations

from typing import Any


def normalize_intake_session_id(value: Any) -> str:
    """Normalize intake session id to a safe storage/transit token."""
    import re

    text = str(value or "").strip()
    if not text:
        return ""
    normalized = re.sub(r"[^a-zA-Z0-9:_\-]", "_", text)
    return normalized[:120]


def build_intake_session_id(*, session_id: str, seed: str) -> str:
    """Build a deterministic local intake session id."""
    safe_session = normalize_intake_session_id(session_id or "default")
    safe_seed = normalize_intake_session_id(seed or "")
    suffix = safe_seed or "unknown"
    return f"intake_{safe_session}_{suffix}"


def resolve_intake_session_id(
    *,
    payload: dict[str, Any],
    session_id: str,
    trace_id: str,
    command: str,
    resolved_mode: str,
    latest_persisted_intake_session_id: str = "",
    has_active_intake_payload: bool = False,
) -> str:
    """Resolve intake session id using payload, persisted, then local fallback."""
    candidates = [
        payload.get("intake_session_id"),
        (payload.get("intake_followup") or {}).get("intake_session_id")
        if isinstance(payload.get("intake_followup"), dict)
        else "",
        (payload.get("primary_flow") or {}).get("intake_session_id")
        if isinstance(payload.get("primary_flow"), dict)
        else "",
    ]
    for candidate in candidates:
        normalized = normalize_intake_session_id(candidate)
        if normalized:
            return normalized

    persisted_intake_session_id = normalize_intake_session_id(latest_persisted_intake_session_id)
    if persisted_intake_session_id and (
        resolved_mode == "requirement_intake"
        or command in {"submit_intake_answer", "generate_analysis", "activate_requirement_intake"}
        or has_active_intake_payload
    ):
        return persisted_intake_session_id
    if resolved_mode != "requirement_intake" and command != "generate_analysis" and not has_active_intake_payload:
        return ""

    seed = str(payload.get("client_request_id") or payload.get("request_id") or trace_id or "").strip()
    return build_intake_session_id(session_id=session_id, seed=seed)


__all__ = [
    "build_intake_session_id",
    "normalize_intake_session_id",
    "resolve_intake_session_id",
]
