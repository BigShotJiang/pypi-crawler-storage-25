"""Payload mutation helpers for intake answers and workspace edits."""

from __future__ import annotations

import re
from typing import Any


def extract_quoted_terms(message: str) -> list[str]:
    text = str(message or "").strip()
    if not text:
        return []
    terms: list[str] = []
    for pattern in (r"[\"“”']([^\"“”']{1,32})[\"“”']", r"「([^」]{1,32})」", r"『([^』]{1,32})』"):
        for term in re.findall(pattern, text):
            normalized = str(term or "").strip()
            if normalized and normalized not in terms:
                terms.append(normalized)
    return terms


def _collect_intake_field_updates(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Collect field-update payloads from current and legacy intake contracts.

    The canonical batch contract is `intake_field_updates`: a list of explicit
    field mutations emitted by the composer chooser after the user answers a
    backend-provided `question_plan`.  Single-question submissions still use the
    older `question_answer` shape, because that contract is already part of the
    single current-question path.

    `question_answers` is read only as a backward-compatible legacy batch key.
    New callers should not emit it.  Keeping the read path here prevents older
    replayed payloads or in-flight WIP clients from being dropped while allowing
    the rest of the kernel merge logic to operate on one normalized list.
    """

    field_updates: list[dict[str, Any]] = []
    single = payload.get("question_answer")
    if isinstance(single, dict):
        field_updates.append(single)
    many = payload.get("intake_field_updates")
    if isinstance(many, list):
        field_updates.extend(item for item in many if isinstance(item, dict))
    legacy_many = payload.get("question_answers")
    if isinstance(legacy_many, list):
        field_updates.extend(item for item in legacy_many if isinstance(item, dict))
    return field_updates


def apply_question_answer_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """Merge intake field updates into the mutable kernel payload.

    This helper is a narrow adapter between transport/controller payload keys
    and the canonical intake field state consumed by orchestration.  It updates
    only generic field containers: `fields`, `field_sources`,
    `required_missing`, and branch selection metadata.  It does not choose the
    next workflow state, mark the intake session terminal, or decide whether a
    field is sufficient for analysis / sourcing readiness.

    Accepted inputs are normalized by `_collect_intake_field_updates()`:

    - `question_answer` for the single-question chooser path.
    - `intake_field_updates` for the batch chooser path.
    - legacy `question_answers` for compatibility only.

    The function mutates and returns the provided payload to preserve the
    existing router contract.  Field source remains `question_answer` for both
    single and batch inputs so downstream code can treat all human chooser
    answers as one source class.
    """

    if not isinstance(payload, dict):
        return payload
    field_updates = _collect_intake_field_updates(payload)
    if not field_updates:
        return payload

    fields = payload.get("fields")
    next_fields = dict(fields) if isinstance(fields, dict) else {}
    field_sources = payload.get("field_sources")
    next_sources = dict(field_sources) if isinstance(field_sources, dict) else {}
    supplementary_fields = payload.get("supplementary_fields")
    next_supplementary = dict(supplementary_fields) if isinstance(supplementary_fields, dict) else {}
    required_missing = payload.get("required_missing")
    next_required_missing = list(required_missing) if isinstance(required_missing, list) else None
    branch_state = payload.get("intake_branch_state")
    next_branch_state = dict(branch_state) if isinstance(branch_state, dict) else {}

    for field_update in field_updates:
        field_key = str(field_update.get("field_key") or "").strip()
        field_value = str(field_update.get("raw_value") or field_update.get("field_value") or "").strip()
        if field_key and field_value:
            next_fields[field_key] = field_value
            next_sources[field_key] = "question_answer"
            target_gap = str(
                field_update.get("target_information_gap")
                or field_update.get("question_key")
                or ""
            ).strip()
            if target_gap and target_gap != field_key:
                next_supplementary[target_gap] = field_value
            if isinstance(next_required_missing, list):
                next_required_missing = [
                    item
                    for item in next_required_missing
                    if str(item).strip() and str(item).strip() != field_key
                ]
        branch_node_key = str(field_update.get("branch_node_key") or "").strip()
        if not branch_node_key:
            continue
        selected_option_value = str(field_update.get("selected_option_value") or field_value).strip()
        selected_option_text = str(field_update.get("selected_option_text") or selected_option_value).strip()
        next_branch_state[branch_node_key] = {
            "selected_option_key": str(field_update.get("selected_option_key") or "").strip(),
            "selected_option_value": selected_option_value,
            "selected_option_text": selected_option_text,
            "question_kind": str(field_update.get("question_kind") or "").strip(),
        }

    if next_fields:
        payload["fields"] = next_fields
        payload["field_sources"] = next_sources
    if next_supplementary:
        payload["supplementary_fields"] = next_supplementary
    if isinstance(next_required_missing, list):
        payload["required_missing"] = next_required_missing
    if next_branch_state:
        payload["intake_branch_state"] = next_branch_state
        payload["active_branch_path"] = [
            str(item).strip()
            for item in next_branch_state.keys()
            if str(item).strip()
        ]
    return payload

def normalize_workspace_patches(payload: dict[str, Any]) -> list[dict[str, Any]]:
    patches: list[dict[str, Any]] = []
    raw_single = payload.get("workspace_patch")
    if isinstance(raw_single, dict):
        patches.append(raw_single)
    raw_many = payload.get("workspace_patches")
    if isinstance(raw_many, list):
        patches.extend(item for item in raw_many if isinstance(item, dict))
    return patches


def apply_workspace_patch_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return payload
    patches = normalize_workspace_patches(payload)
    if not patches:
        return payload
    fields = payload.get("fields")
    next_fields = dict(fields) if isinstance(fields, dict) else {}
    field_sources = payload.get("field_sources")
    next_sources = dict(field_sources) if isinstance(field_sources, dict) else {}
    required_missing = payload.get("required_missing")
    next_required_missing = list(required_missing) if isinstance(required_missing, list) else None

    for patch in patches:
        field_key = str(patch.get("field_key") or "").strip()
        if not field_key:
            continue
        field_value = str(patch.get("field_value") or "").strip()
        next_fields[field_key] = field_value
        next_sources[field_key] = "workspace_patch"
        if isinstance(next_required_missing, list) and field_value:
            next_required_missing = [
                item
                for item in next_required_missing
                if str(item).strip() and str(item).strip() != field_key
            ]

    payload["fields"] = next_fields
    payload["field_sources"] = next_sources
    if isinstance(next_required_missing, list):
        payload["required_missing"] = next_required_missing
    return payload
