"""Requirement-intake entry and continuation policy helpers.

DOC HELPER — PLN-01 entry boundary.
This module recognizes explicit requirement-intake entry signals and returns a
mode recommendation. It does not collect fields, update memory, build graphs,
open canvas, or decide analysis/sourcing readiness; those belong to later PLN
and memory workflows.
"""

from __future__ import annotations

import re
from typing import Any, Callable, Iterable


DEFAULT_INTAKE_STRATEGY: dict[str, Any] = {
    "question_budget_min": 2,
    "question_budget_max": 3,
    "framework_only": True,
    "detail_deferral": True,
    "framework_fields": (
        "goal",
        "purpose",
        "scope",
        "use_case",
        "scenario",
        "constraints",
        "success_criteria",
    ),
    "detail_field_keywords": (
        "gpu",
        "cpu",
        "memory",
        "ram",
        "iops",
        "latency",
        "bandwidth",
        "throughput",
        "nic",
        "raid",
        "jbod",
        "nvme",
        "slot",
        "topology",
    ),
}


def _coerce_int(raw: Any, fallback: int, *, minimum: int, maximum: int) -> int:
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return fallback
    return max(minimum, min(maximum, value))


def _normalize_text_tuple(raw: Any, fallback: tuple[str, ...]) -> tuple[str, ...]:
    if not isinstance(raw, (list, tuple)):
        return fallback
    normalized = tuple(str(item).strip() for item in raw if str(item).strip())
    return normalized or fallback


def resolve_intake_strategy_settings(
    *,
    runtime_payload: dict[str, Any] | None = None,
    runtime_snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    strategy = dict(DEFAULT_INTAKE_STRATEGY)
    candidate: dict[str, Any] = {}
    payload_source = runtime_payload if isinstance(runtime_payload, dict) else {}
    if isinstance(payload_source.get("intake_strategy"), dict):
        candidate.update(payload_source.get("intake_strategy") or {})
    snapshot_source = runtime_snapshot if isinstance(runtime_snapshot, dict) else {}
    domain_pack = snapshot_source.get("domain_pack")
    if isinstance(domain_pack, dict):
        workflow = domain_pack.get("workflow")
        if isinstance(workflow, dict) and isinstance(workflow.get("intake_strategy"), dict):
            candidate.update(workflow.get("intake_strategy") or {})
    strategy["question_budget_min"] = _coerce_int(
        candidate.get("question_budget_min"),
        int(strategy["question_budget_min"]),
        minimum=1,
        maximum=6,
    )
    strategy["question_budget_max"] = _coerce_int(
        candidate.get("question_budget_max"),
        int(strategy["question_budget_max"]),
        minimum=strategy["question_budget_min"],
        maximum=8,
    )
    strategy["framework_only"] = bool(candidate.get("framework_only", strategy["framework_only"]))
    strategy["detail_deferral"] = bool(candidate.get("detail_deferral", strategy["detail_deferral"]))
    strategy["framework_fields"] = _normalize_text_tuple(
        candidate.get("framework_fields"),
        tuple(strategy["framework_fields"]),
    )
    strategy["detail_field_keywords"] = _normalize_text_tuple(
        candidate.get("detail_field_keywords"),
        tuple(strategy["detail_field_keywords"]),
    )
    return strategy


def resolve_requirement_intake_entry_recommendation(
    *,
    message: str,
    current_question: dict[str, Any] | None = None,
    required_missing: list[str] | tuple[str, ...] | None = None,
    normalize_message_text_fn: Callable[[Any], str],
    looks_like_small_talk_fn: Callable[[str], bool],
    contains_any_text_fn: Callable[[str, Iterable[str]], bool],
    requirement_entry_explicit_phrases: tuple[str, ...],
    requirement_entry_context_terms: tuple[str, ...],
    requirement_entry_structuring_terms: tuple[str, ...],
    question_terms: tuple[str, ...],
) -> tuple[str, float, str, str]:
    normalized_message = normalize_message_text_fn(message)
    if not normalized_message:
        return "default", 0.0, "未识别到可推荐梳理的信号。", "fallback"
    if looks_like_small_talk_fn(normalized_message):
        return "default", 0.0, "识别为闲聊/寒暄，保持普通对话。", "fallback"

    score = 0.0
    signals: list[str] = []

    explicit_request = contains_any_text_fn(normalized_message, requirement_entry_explicit_phrases)
    if not explicit_request:
        has_request_marker = contains_any_text_fn(normalized_message, ("请", "帮我", "先"))
        explicit_request = bool(
            has_request_marker
            and contains_any_text_fn(normalized_message, ("梳理", "整理", "收口"))
        )
    if not explicit_request:
        explicit_request = bool(
            contains_any_text_fn(normalized_message, requirement_entry_context_terms)
            and contains_any_text_fn(normalized_message, requirement_entry_structuring_terms)
        )
    if explicit_request:
        score += 2.5
        signals.append("明确梳理请求")

    has_context_signal = contains_any_text_fn(normalized_message, requirement_entry_context_terms)
    has_structuring_signal = contains_any_text_fn(normalized_message, requirement_entry_structuring_terms)
    has_question_signal = contains_any_text_fn(normalized_message, question_terms)

    if has_context_signal:
        score += 1.0
        signals.append("需求上下文信号")
    if has_structuring_signal:
        score += 1.0
        signals.append("梳理/收口信号")
    if has_context_signal and has_question_signal:
        score += 0.4
        signals.append("澄清请求")
    if isinstance(current_question, dict) and str(current_question.get("field_key") or "").strip():
        score += 0.5
        signals.append("当前已有梳理上下文")
    if isinstance(required_missing, (list, tuple)) and any(str(item).strip() for item in required_missing):
        score += 0.3
        signals.append("仍有缺口")

    if score < 1.5:
        return "default", 0.0, "未达到梳理模式推荐阈值。", "fallback"

    source = "fuzzy_intent"
    confidence = min(0.86, 0.68 + (score * 0.06))
    if explicit_request:
        confidence = 0.9
        source = "explicit_request"

    reason = "；".join(signals) if signals else "识别到领域梳理信号，建议开启梳理模式。"
    if "建议" not in reason:
        reason = f"{reason}；建议进入梳理模式。"
    return "requirement_intake", confidence, reason, source


def has_active_intake_payload(payload: dict[str, Any] | None) -> bool:
    if not isinstance(payload, dict):
        return False
    required_missing = payload.get("required_missing")
    if isinstance(required_missing, list) and any(str(item or "").strip() for item in required_missing):
        return True
    flow_state = str(payload.get("flow_state") or payload.get("collection_phase") or "").strip().lower()
    if flow_state in {"collecting", "blocked"}:
        return True
    current_question = payload.get("current_question")
    if isinstance(current_question, dict) and str(current_question.get("field_key") or "").strip():
        return True
    primary_flow = payload.get("primary_flow")
    if isinstance(primary_flow, dict):
        stage = str(primary_flow.get("stage") or "").strip().lower()
        if stage.startswith("requirement_intake"):
            return True
    return False


def is_requirement_mode_explicit(
    *,
    command: str,
    mode_source: str,
    payload: dict[str, Any] | None = None,
) -> bool:
    if command in {"activate_requirement_intake", "submit_intake_answer", "generate_analysis"}:
        return True
    if mode_source in {"intent_override", "active_intake"}:
        return True
    return has_active_intake_payload(payload)


def is_intake_exit_message(
    message: str,
    *,
    intake_exit_hints: tuple[str, ...],
) -> bool:
    normalized = str(message or "").strip().lower()
    if not normalized:
        return False
    if any(hint in normalized for hint in intake_exit_hints):
        return True
    return bool(re.search(r"(先|请).{0,6}(看|做|生成|输出).{0,6}需求分析", normalized))


def should_continue_active_intake(
    *,
    command: str,
    payload: dict[str, Any] | None,
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    looks_like_small_talk_fn: Callable[[str], bool],
    is_intake_exit_message_fn: Callable[[str], bool],
) -> bool:
    if command == "generate_analysis":
        return False
    if not has_active_intake_payload(payload):
        return False
    if command != "send_message":
        return True
    message = extract_user_message_fn(payload)
    if looks_like_small_talk_fn(message):
        return False
    if is_intake_exit_message_fn(message):
        return False
    return True


__all__ = [
    "DEFAULT_INTAKE_STRATEGY",
    "has_active_intake_payload",
    "is_intake_exit_message",
    "is_requirement_mode_explicit",
    "resolve_intake_strategy_settings",
    "resolve_requirement_intake_entry_recommendation",
    "should_continue_active_intake",
]
