"""Source/evidence helpers for intake field projection."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.text_safety import extract_user_message


def extract_workspace_patch_value(payload: dict[str, Any], field_key: str) -> str:
    """Resolve the latest workspace patch value for a specific field key."""
    if not isinstance(payload, dict):
        return ""
    workspace_patches = payload.get("workspace_patches")
    if isinstance(workspace_patches, list):
        for patch in reversed(workspace_patches):
            if not isinstance(patch, dict):
                continue
            patch_key = str(patch.get("field_key") or "").strip()
            if patch_key != field_key:
                continue
            return str(patch.get("field_value") or "").strip()
    workspace_patch = payload.get("workspace_patch")
    if isinstance(workspace_patch, dict) and str(workspace_patch.get("field_key") or "").strip() == field_key:
        return str(workspace_patch.get("field_value") or "").strip()
    return ""


def build_field_source_payload(*, source_type: str, evidence_text: str) -> dict[str, Any]:
    """Build source payload with optional evidence text."""
    payload: dict[str, Any] = {"type": source_type}
    evidence = str(evidence_text or "").strip()
    if evidence:
        payload["evidence"] = evidence
    return payload


def resolve_field_evidence(payload: dict[str, Any], field_key: str, source_type: str) -> str:
    """Resolve evidence text by source type for a field projection pass."""
    if not isinstance(payload, dict):
        return ""
    normalized_source = str(source_type or "").strip()
    if normalized_source == "question_answer":
        question_answer = payload.get("question_answer")
        if isinstance(question_answer, dict) and str(question_answer.get("field_key") or "").strip() == field_key:
            return str(question_answer.get("raw_value") or question_answer.get("field_value") or "").strip()
    if normalized_source == "workspace_patch":
        patched_value = extract_workspace_patch_value(payload, field_key)
        if patched_value:
            return patched_value
    if normalized_source == "message_extraction":
        return extract_user_message(payload)
    return extract_user_message(payload)


__all__ = [
    "build_field_source_payload",
    "extract_workspace_patch_value",
    "resolve_field_evidence",
]
