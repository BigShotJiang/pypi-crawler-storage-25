"""Payload-level field projection and candidate derivation helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.field_projection.entity import (
    canonicalize_field_entity,
    is_field_entity_confirmed,
)
from flare_kernel.router.intake.field_projection.source import resolve_field_evidence
from flare_kernel.router.text_safety import has_value


def canonicalize_payload_fields(payload: dict[str, Any]) -> dict[str, Any]:
    """Canonicalize all field entities in payload and update fields/candidates."""
    if not isinstance(payload, dict):
        return payload
    raw_fields = payload.get("fields")
    fields = dict(raw_fields) if isinstance(raw_fields, dict) else {}
    field_sources = payload.get("field_sources")
    normalized_sources = dict(field_sources) if isinstance(field_sources, dict) else {}
    existing_entities = payload.get("field_entities")
    normalized_existing = dict(existing_entities) if isinstance(existing_entities, dict) else {}
    field_definitions = payload.get("field_definitions")
    definitions_by_key = {
        str(item.get("key") or "").strip(): item
        for item in field_definitions
        if isinstance(item, dict) and str(item.get("key") or "").strip()
    } if isinstance(field_definitions, list) else {}
    field_semantics = payload.get("field_semantics")
    semantics_by_key = dict(field_semantics) if isinstance(field_semantics, dict) else {}

    next_entities: dict[str, Any] = {}
    next_fields: dict[str, str] = {}
    field_candidates: dict[str, Any] = {}
    field_clarifications: dict[str, Any] = {}
    answered_field_keys: set[str] = set()
    field_keys = set()
    field_keys.update(str(key or "").strip() for key in fields.keys())
    field_keys.update(str(key or "").strip() for key in normalized_existing.keys())
    for field_key in field_keys:
        if not field_key:
            continue
        has_explicit_value = field_key in fields
        if has_explicit_value:
            raw_value = fields.get(field_key)
            if not has_value(raw_value):
                continue
        else:
            existing_entity = normalized_existing.get(field_key)
            if not isinstance(existing_entity, dict):
                continue
            raw_value = existing_entity.get("raw_value")
            if not has_value(raw_value):
                continue
        source_type = str(normalized_sources.get(field_key) or "user_input").strip() or "user_input"
        evidence_text = resolve_field_evidence(payload, field_key, source_type)
        entity = canonicalize_field_entity(
            field_key=field_key,
            raw_value=raw_value,
            source_type=source_type,
            evidence_text=evidence_text,
            field_definition=definitions_by_key.get(field_key),
            field_semantics=(
                semantics_by_key.get(field_key)
                if isinstance(semantics_by_key.get(field_key), dict)
                else None
            ),
        )
        if not isinstance(entity, dict):
            continue
        next_entities[field_key] = entity
        answered_field_keys.add(field_key)
        if is_field_entity_confirmed(entity):
            next_fields[field_key] = str(entity.get("display_value") or "").strip()
        else:
            field_candidates[field_key] = entity
            field_clarifications[field_key] = {
                "field_key": field_key,
                "status": "needs_clarification",
                "reason": "unparsed_structured_value",
                "raw_value": str(entity.get("raw_value") or raw_value or "").strip(),
            }

    payload["field_entities"] = next_entities
    payload["fields"] = next_fields
    if field_candidates:
        payload["field_candidates"] = field_candidates
    else:
        payload.pop("field_candidates", None)
    if field_clarifications:
        payload["field_clarifications"] = field_clarifications
    else:
        payload.pop("field_clarifications", None)

    required_missing = payload.get("required_missing")
    if isinstance(required_missing, list):
        payload["required_missing"] = [
            item
            for item in required_missing
            if str(item).strip()
            and str(item).strip() not in next_fields
            and str(item).strip() not in answered_field_keys
        ]
        return payload

    required_fields = payload.get("required_fields")
    if isinstance(required_fields, list):
        normalized_required_fields = [str(item).strip() for item in required_fields if str(item).strip()]
        payload["required_missing"] = [
            field_key
            for field_key in normalized_required_fields
            if field_key not in next_fields and field_key not in answered_field_keys
        ]
    return payload


__all__ = ["canonicalize_payload_fields"]
