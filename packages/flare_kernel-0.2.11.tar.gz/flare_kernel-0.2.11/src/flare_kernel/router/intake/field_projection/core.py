"""Facade for intake field projection helpers.

This module preserves historical imports while delegating implementation to
focused source/entity/payload projection submodules.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.field_projection.entity import (
    build_unparsed_field_entity as _build_unparsed_field_entity,
    canonicalize_field_entity as _canonicalize_field_entity,
    is_field_entity_confirmed as _is_field_entity_confirmed,
)
from flare_kernel.router.intake.field_projection.payload import (
    canonicalize_payload_fields as _canonicalize_payload_fields,
)
from flare_kernel.router.intake.field_projection.source import (
    build_field_source_payload as _build_field_source_payload,
    extract_workspace_patch_value as _extract_workspace_patch_value,
    resolve_field_evidence as _resolve_field_evidence,
)


def extract_workspace_patch_value(payload: dict[str, Any], field_key: str) -> str:
    """Resolve the latest workspace patch value for a specific field key."""
    return _extract_workspace_patch_value(payload, field_key)


def build_field_source_payload(*, source_type: str, evidence_text: str) -> dict[str, Any]:
    """Build source payload with optional evidence text."""
    return _build_field_source_payload(source_type=source_type, evidence_text=evidence_text)


def resolve_field_evidence(payload: dict[str, Any], field_key: str, source_type: str) -> str:
    """Resolve evidence text by source type for a field projection pass."""
    return _resolve_field_evidence(payload, field_key, source_type)


def build_unparsed_field_entity(
    *,
    raw_text: str,
    source_type: str,
    evidence_text: str,
) -> dict[str, Any]:
    """Build fallback entity for structured values that cannot be parsed."""
    return _build_unparsed_field_entity(
        raw_text=raw_text,
        source_type=source_type,
        evidence_text=evidence_text,
    )


def canonicalize_field_entity(
    *,
    field_key: str,
    raw_value: Any,
    source_type: str,
    evidence_text: str,
    field_definition: dict[str, Any] | None = None,
    field_semantics: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Canonicalize a single field entity from raw value and evidence."""
    return _canonicalize_field_entity(
        field_key=field_key,
        raw_value=raw_value,
        source_type=source_type,
        evidence_text=evidence_text,
        field_definition=field_definition,
        field_semantics=field_semantics,
    )


def is_field_entity_confirmed(entity: Any) -> bool:
    """Return whether entity is confirmed and has complete normalized/display value."""
    return _is_field_entity_confirmed(entity)


def canonicalize_payload_fields(payload: dict[str, Any]) -> dict[str, Any]:
    """Canonicalize all field entities in payload and update fields/candidates."""
    return _canonicalize_payload_fields(payload)
