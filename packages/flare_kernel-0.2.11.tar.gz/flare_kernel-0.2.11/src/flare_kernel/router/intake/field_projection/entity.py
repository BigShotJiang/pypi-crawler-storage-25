"""Entity canonicalization helpers for intake field projection."""

from __future__ import annotations

import re
from typing import Any

from flare_kernel.router.intake.amount_quantity import canonicalize_budget_value, canonicalize_quantity_value
from flare_kernel.router.intake.delivery_time import canonicalize_delivery_time_value
from flare_kernel.router.intake.field_projection.source import build_field_source_payload
from flare_kernel.router.intake.numeric import detect_numeric_precision, parse_numeric_token
from flare_kernel.router.text_safety import has_value

_STRUCTURED_VALUE_TYPES = {
    "money",
    "money_range",
    "quantity",
    "integer",
    "number",
    "time_window",
    "date",
    "datetime",
}


def build_unparsed_field_entity(
    *,
    raw_text: str,
    source_type: str,
    evidence_text: str,
) -> dict[str, Any]:
    """Build fallback entity for structured values that cannot be parsed."""
    normalized_raw = str(raw_text or "").strip()
    return {
        "raw_value": normalized_raw,
        "normalized_value": None,
        "display_value": normalized_raw,
        "confidence": 0.0,
        "source": build_field_source_payload(source_type=source_type, evidence_text=evidence_text),
        "status": "unparsed",
    }


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _resolve_value_type(
    *,
    field_definition: dict[str, Any] | None,
    field_semantics: dict[str, Any] | None,
) -> str:
    semantics = _coerce_mapping(field_semantics)
    definition = _coerce_mapping(field_definition)
    return str(
        semantics.get("value_type")
        or definition.get("value_type")
        or definition.get("type")
        or ""
    ).strip().lower()


def _canonicalize_number_value(raw_text: str) -> dict[str, Any] | None:
    match = re.search(r"(?P<number>\d+(?:\.\d+)?|[一二两三四五六七八九十百千万亿]+)", raw_text)
    if not match:
        return None
    parsed = parse_numeric_token(match.group("number"))
    if parsed is None:
        return None
    value: int | float = int(round(parsed)) if float(parsed).is_integer() else parsed
    return {
        "status": "confirmed",
        "normalized_value": {
            "kind": "number",
            "value": value,
            "precision": detect_numeric_precision(raw_text),
        },
        "display_value": str(value),
        "confidence": 0.9,
    }


def _canonicalize_structured_value(value_type: str, raw_text: str) -> dict[str, Any] | None:
    if value_type in {"money", "money_range"}:
        return canonicalize_budget_value(raw_text)
    if value_type == "quantity":
        return canonicalize_quantity_value(raw_text)
    if value_type in {"integer", "number"}:
        return _canonicalize_number_value(raw_text)
    if value_type in {"time_window", "date", "datetime"}:
        return canonicalize_delivery_time_value(raw_text)
    return None


def canonicalize_field_entity(
    *,
    field_key: str,
    raw_value: Any,
    source_type: str,
    evidence_text: str,
    field_definition: dict[str, Any] | None = None,
    field_semantics: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Canonicalize a single field entity from raw value and evidence."""
    normalized_key = str(field_key or "").strip()
    raw_text = str(raw_value or "").strip()
    if not normalized_key or not raw_text:
        return None
    value_type = _resolve_value_type(
        field_definition=field_definition,
        field_semantics=field_semantics,
    )
    canonical = _canonicalize_structured_value(value_type, raw_text)
    if canonical is None:
        if value_type in _STRUCTURED_VALUE_TYPES:
            canonical = {
                "status": "unparsed",
                "normalized_value": None,
                "display_value": raw_text,
                "confidence": 0.0,
            }
        else:
            canonical = {
                "status": "confirmed",
                "normalized_value": {"kind": "text", "value": raw_text},
                "display_value": raw_text,
                "confidence": 0.85,
            }
    return {
        "raw_value": raw_text,
        "normalized_value": canonical.get("normalized_value"),
        "display_value": str(canonical.get("display_value") or raw_text).strip() or raw_text,
        "confidence": float(canonical.get("confidence") or 0.0),
        "source": build_field_source_payload(source_type=source_type, evidence_text=evidence_text),
        "status": str(canonical.get("status") or "unparsed"),
    }


def is_field_entity_confirmed(entity: Any) -> bool:
    """Return whether entity is confirmed and has complete normalized/display value."""
    if not isinstance(entity, dict):
        return False
    status = str(entity.get("status") or "").strip().lower()
    if status != "confirmed":
        return False
    normalized_value = entity.get("normalized_value")
    if not has_value(normalized_value):
        return False
    display_value = str(entity.get("display_value") or "").strip()
    if not display_value:
        return False
    return True


__all__ = [
    "build_unparsed_field_entity",
    "canonicalize_field_entity",
    "is_field_entity_confirmed",
]
