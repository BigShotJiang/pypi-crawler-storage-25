"""Numeric parsing helpers for intake canonicalization."""

from __future__ import annotations

import re
from typing import Any

from flare_kernel.router.text_safety import normalize_message_text

_INTAKE_APPROX_HINTS = ("大概", "大约", "约", "差不多", "左右", "先按", "先按照")
_INTAKE_UPPER_BOUND_HINTS = ("不超过", "不高于", "最多", "以内", "以下", "上限")
_INTAKE_LOWER_BOUND_HINTS = ("不少于", "不低于", "至少", "起码", "以上")
_INTAKE_AMOUNT_UNIT_MULTIPLIERS = {
    "亿": 100000000,
    "万": 10000,
    "千": 1000,
    "百": 100,
    "元": 1,
    "": 1,
}
_INTAKE_CHINESE_DIGITS = {
    "零": 0,
    "〇": 0,
    "一": 1,
    "二": 2,
    "两": 2,
    "三": 3,
    "四": 4,
    "五": 5,
    "六": 6,
    "七": 7,
    "八": 8,
    "九": 9,
}
_INTAKE_CHINESE_UNITS = {
    "十": 10,
    "百": 100,
    "千": 1000,
    "万": 10000,
}


def parse_simple_chinese_number(token: str) -> int | None:
    text = str(token or "").strip()
    if not text:
        return None
    if re.fullmatch(r"\d+(?:\.\d+)?", text):
        try:
            return int(float(text))
        except Exception:
            return None
    if text in _INTAKE_CHINESE_DIGITS:
        return _INTAKE_CHINESE_DIGITS[text]

    total = 0
    section = 0
    current = 0
    has_magnitude = False
    for ch in text:
        if ch in _INTAKE_CHINESE_DIGITS:
            current = _INTAKE_CHINESE_DIGITS[ch]
            continue
        if ch in _INTAKE_CHINESE_UNITS:
            unit = _INTAKE_CHINESE_UNITS[ch]
            has_magnitude = True
            if unit == 10000:
                section = (section + (current or 0)) * unit
                total += section
                section = 0
                current = 0
                continue
            if current == 0:
                current = 1
            section += current * unit
            current = 0
            continue
        return None
    if has_magnitude:
        return total + section + current
    return None


def parse_numeric_token(token: Any) -> float | None:
    text = str(token or "").strip().replace(",", "")
    if not text:
        return None
    if re.fullmatch(r"-?\d+(?:\.\d+)?", text):
        try:
            return float(text)
        except ValueError:
            return None
    parsed = parse_simple_chinese_number(text)
    if parsed is None:
        return None
    return float(parsed)


def apply_amount_unit(number: float, unit: str) -> int:
    normalized_unit = str(unit or "").strip()
    multiplier = _INTAKE_AMOUNT_UNIT_MULTIPLIERS.get(normalized_unit, 1)
    return int(round(number * multiplier))


def format_cny_amount(amount: int) -> str:
    if amount >= 100000000:
        yi_value = amount / 100000000
        if yi_value.is_integer():
            return f"{int(yi_value)}亿"
        return f"{yi_value:.2f}".rstrip("0").rstrip(".") + "亿"
    if amount >= 10000:
        wan_value = amount / 10000
        if wan_value.is_integer():
            return f"{int(wan_value)}万"
        return f"{wan_value:.2f}".rstrip("0").rstrip(".") + "万"
    return str(amount)


def detect_numeric_precision(text: str) -> str:
    normalized = normalize_message_text(text)
    if any(hint in normalized for hint in _INTAKE_UPPER_BOUND_HINTS):
        return "upper_bound"
    if any(hint in normalized for hint in _INTAKE_LOWER_BOUND_HINTS):
        return "lower_bound"
    if any(hint in normalized for hint in _INTAKE_APPROX_HINTS):
        return "approx"
    return "exact"
