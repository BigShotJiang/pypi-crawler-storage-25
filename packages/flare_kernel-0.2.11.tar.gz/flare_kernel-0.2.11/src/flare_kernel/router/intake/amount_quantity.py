"""Budget and quantity canonicalization helpers for intake fields."""

from __future__ import annotations

import re
from typing import Any

from flare_kernel.router.intake.numeric import (
    apply_amount_unit,
    detect_numeric_precision,
    format_cny_amount,
    parse_numeric_token,
)


def canonicalize_budget_value(raw_text: str) -> dict[str, Any] | None:
    text = str(raw_text or "").strip()
    if not text:
        return None
    precision = detect_numeric_precision(text)
    range_match = re.search(
        r"(?P<min>\d+(?:\.\d+)?|[一二两三四五六七八九十百千万亿]+)\s*(?P<min_unit>亿|万|千|百|元)?\s*(?:到|至|~|～|-|—)\s*(?P<max>\d+(?:\.\d+)?|[一二两三四五六七八九十百千万亿]+)\s*(?P<max_unit>亿|万|千|百|元)?",
        text,
    )
    if range_match:
        min_number = parse_numeric_token(range_match.group("min"))
        max_number = parse_numeric_token(range_match.group("max"))
        if min_number is None or max_number is None:
            return None
        min_unit = str(range_match.group("min_unit") or "").strip()
        max_unit = str(range_match.group("max_unit") or "").strip()
        if not min_unit and max_unit:
            min_unit = max_unit
        if not max_unit and min_unit:
            max_unit = min_unit
        min_amount = apply_amount_unit(min_number, min_unit)
        max_amount = apply_amount_unit(max_number, max_unit)
        if min_amount > max_amount:
            min_amount, max_amount = max_amount, min_amount
        if min_amount >= 10000 and max_amount >= 10000:
            display_value = f"{format_cny_amount(min_amount)}~{format_cny_amount(max_amount)}元"
        else:
            display_value = f"{min_amount}~{max_amount}元"
        return {
            "status": "confirmed",
            "normalized_value": {
                "kind": "range",
                "min": min_amount,
                "max": max_amount,
                "currency": "CNY",
                "precision": "range" if precision == "exact" else precision,
            },
            "display_value": display_value,
            "confidence": 0.93,
        }

    number_match = re.search(r"(?P<number>\d+(?:\.\d+)?|[一二两三四五六七八九十百千万亿]+)\s*(?P<unit>亿|万|千|百|元)?", text)
    if not number_match:
        return None
    parsed_number = parse_numeric_token(number_match.group("number"))
    if parsed_number is None:
        return None
    unit = str(number_match.group("unit") or "").strip()
    amount = apply_amount_unit(parsed_number, unit)
    formatted = format_cny_amount(amount)
    if precision == "upper_bound":
        display_value = f"不超过{formatted}元"
        normalized_value = {
            "kind": "limit",
            "operator": "<=",
            "amount": amount,
            "currency": "CNY",
            "precision": precision,
        }
    elif precision == "lower_bound":
        display_value = f"不少于{formatted}元"
        normalized_value = {
            "kind": "limit",
            "operator": ">=",
            "amount": amount,
            "currency": "CNY",
            "precision": precision,
        }
    elif precision == "approx":
        display_value = f"约{formatted}元"
        normalized_value = {
            "kind": "amount",
            "amount": amount,
            "currency": "CNY",
            "precision": precision,
        }
    else:
        display_value = f"{formatted}元"
        normalized_value = {
            "kind": "amount",
            "amount": amount,
            "currency": "CNY",
            "precision": precision,
        }
    return {
        "status": "confirmed",
        "normalized_value": normalized_value,
        "display_value": display_value,
        "confidence": 0.92 if precision == "exact" else 0.88,
    }


def canonicalize_quantity_value(raw_text: str) -> dict[str, Any] | None:
    text = str(raw_text or "").strip()
    if not text:
        return None
    precision = detect_numeric_precision(text)
    range_match = re.search(
        r"(?P<min>\d+(?:\.\d+)?|[一二两三四五六七八九十百千万]+)\s*(?P<unit>台|套|个|部|件|张|人|节点|机柜)?\s*(?:到|至|~|～|-|—)\s*(?P<max>\d+(?:\.\d+)?|[一二两三四五六七八九十百千万]+)\s*(?P<unit2>台|套|个|部|件|张|人|节点|机柜)?",
        text,
    )
    if range_match:
        min_number = parse_numeric_token(range_match.group("min"))
        max_number = parse_numeric_token(range_match.group("max"))
        if min_number is None or max_number is None:
            return None
        unit = str(range_match.group("unit2") or range_match.group("unit") or "台").strip()
        min_value = int(round(min_number))
        max_value = int(round(max_number))
        if min_value > max_value:
            min_value, max_value = max_value, min_value
        return {
            "status": "confirmed",
            "normalized_value": {
                "kind": "range",
                "min": min_value,
                "max": max_value,
                "unit": unit,
                "precision": "range" if precision == "exact" else precision,
            },
            "display_value": f"{min_value}{unit}~{max_value}{unit}",
            "confidence": 0.92,
        }
    single_match = re.search(
        r"(?P<number>\d+(?:\.\d+)?|[一二两三四五六七八九十百千万]+)\s*(?P<unit>台|套|个|部|件|张|人|节点|机柜)?",
        text,
    )
    if not single_match:
        return None
    parsed_number = parse_numeric_token(single_match.group("number"))
    if parsed_number is None:
        return None
    unit = str(single_match.group("unit") or "台").strip()
    quantity = int(round(parsed_number))
    display_value = f"{quantity}{unit}"
    if precision == "approx":
        display_value = f"约{display_value}"
    return {
        "status": "confirmed",
        "normalized_value": {
            "kind": "number",
            "value": quantity,
            "unit": unit,
            "precision": precision,
        },
        "display_value": display_value,
        "confidence": 0.94 if precision == "exact" else 0.89,
    }
