"""Confirmed-update shaping helpers for guided intake status.

DOC HELPER — ORC-02 backend projection boundary.
Customer-facing labels for confirmed fields are projected from domain field
definitions here so frontend timeline code can render backend-provided labels
without business-specific fallback maps.
"""

from __future__ import annotations

from typing import Any


def _has_value(value: Any) -> bool:
    return value not in (None, "", [], {})


def build_confirmed_updates(
    fields: dict[str, Any],
    *,
    field_label_map: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    updates: list[dict[str, Any]] = []
    labels = field_label_map if isinstance(field_label_map, dict) else {}
    for key, value in fields.items():
        if not _has_value(value):
            continue
        field_key = str(key)
        row = {"field_key": field_key, "field_value": str(value)}
        field_label = str(labels.get(field_key) or "").strip()
        if field_label:
            row["label"] = field_label
            row["field_label"] = field_label
        updates.append(row)
    return updates


__all__ = ["build_confirmed_updates"]
