"""Follow-up state helpers for guided intake status."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.guided.followup_work_item import (
    build_active_work_item_payload,
    build_work_item_actions,
    resolve_external_work_item_status,
    resolve_external_work_item_type,
)


def _has_value(value: Any) -> bool:
    return value not in (None, "", [], {})


def _is_terminal_intake_command(*, resolved_mode: str, command: str) -> bool:
    """Return whether the current router turn explicitly closes intake.

    `build_intake_followup_state()` is the router-side projection consumed by
    canonical status, persistence, and frontend mode indicators.  The
    lower-level mode orchestration already treats `apply` / `implement` as the
    terminal requirement-intake path, but this status projection also needs the
    same contract so it does not re-open collection merely because optional or
    still-missing fields remain.

    The helper is intentionally narrow:

    - it only applies while the resolved mode is `requirement_intake`;
    - it only recognizes explicit terminal commands, not generic send text;
    - it does not decide whether analysis or sourcing should start next.

    That keeps PLN-06 terminal handling in the orchestration/status boundary
    without turning missing-field readiness into transport or UI policy.
    """

    return (
        str(resolved_mode or "").strip() == "requirement_intake"
        and str(command or "").strip().lower() in {"apply", "implement"}
    )


def build_intake_followup_state(
    *,
    trace_id: str,
    intake_session_id: str,
    resolved_mode: str,
    current_stage: str,
    current_question: dict[str, Any] | None,
    required_fields: list[str],
    required_missing: list[str],
    fields: dict[str, Any],
    next_actions: list[dict[str, Any]],
    command: str,
    has_analysis_content: bool,
) -> dict[str, Any]:
    terminal_intake = _is_terminal_intake_command(
        resolved_mode=resolved_mode,
        command=command,
    )
    normalized_required_fields = [str(item).strip() for item in required_fields if str(item).strip()]
    normalized_required_missing = [str(item).strip() for item in required_missing if str(item).strip()]
    if not normalized_required_fields and normalized_required_missing:
        normalized_required_fields = list(normalized_required_missing)
    asked_required_fields = [
        field_key
        for field_key in normalized_required_fields
        if _has_value(fields.get(field_key)) and field_key not in normalized_required_missing
    ]
    active_field_key = "" if terminal_intake else str((current_question or {}).get("field_key") or "").strip()
    if active_field_key and active_field_key not in normalized_required_fields:
        normalized_required_fields.append(active_field_key)
    try:
        clarification_round = int((current_question or {}).get("step_index") or 0)
    except (TypeError, ValueError):
        clarification_round = 0
    if clarification_round <= 0 and active_field_key:
        clarification_round = len(asked_required_fields) + 1
    stage_text = str(current_stage or "").strip().lower()
    in_intake_mode = (
        str(resolved_mode or "").strip() == "requirement_intake"
        or stage_text.startswith("requirement_intake")
    )
    intake_active = (
        not terminal_intake
        and in_intake_mode
        and (bool(normalized_required_missing) or bool(active_field_key))
    )
    analysis_ready = bool(normalized_required_fields) and not normalized_required_missing
    followup_status = "applied" if terminal_intake else ("collecting" if intake_active else ("converged" if analysis_ready else "idle"))
    next_question = dict(current_question) if intake_active and isinstance(current_question, dict) else None
    pending_merge = bool(active_field_key and active_field_key in normalized_required_missing)
    unresolved_points = list(normalized_required_missing)
    next_user_action = next(
        (
            str(item.get("action_key") or item.get("type") or "").strip()
            for item in next_actions
            if isinstance(item, dict) and str(item.get("status") or "").strip().lower() != "blocked"
        ),
        "",
    )
    active_question_id = f"{active_field_key}:{clarification_round}" if intake_active and active_field_key else ""
    next_action_keys = [
        str(item.get("action_key") or item.get("type") or "").strip()
        for item in next_actions
        if isinstance(item, dict)
    ]
    work_item_actions = build_work_item_actions(next_actions)
    has_confirm_plan_action = "confirm_plan" in next_action_keys
    intake_session_state = "idle"
    intake_session_completed = False
    if terminal_intake:
        intake_session_state = "applied"
        intake_session_completed = True
    elif command == "generate_analysis":
        intake_session_state = "analysis_completed" if has_analysis_content else "analysis_running"
        intake_session_completed = bool(has_analysis_content)
    elif intake_active:
        if clarification_round <= 1 and len(asked_required_fields) <= 1:
            intake_session_state = "started"
        elif asked_required_fields:
            intake_session_state = "workspace_live_updating"
        else:
            intake_session_state = "clarification_in_progress"
    elif analysis_ready:
        intake_session_state = "analysis_ready" if has_confirm_plan_action else "draft_ready_for_review"
    elif str(resolved_mode or "").strip() == "requirement_intake":
        intake_session_state = "draft_ready_for_review"
    intake_session_open = bool(intake_session_id) and intake_session_state in {
        "started",
        "clarification_in_progress",
        "workspace_live_updating",
        "draft_ready_for_review",
        "analysis_ready",
    }
    blocking_is_blocked = bool(intake_active and (active_field_key or normalized_required_missing))
    blocking_reason = (
        "waiting_required_field"
        if active_field_key and active_field_key in normalized_required_missing
        else ("waiting_user_input" if blocking_is_blocked else "")
    )
    external_work_item_type = resolve_external_work_item_type(
        current_stage=current_stage,
        command=command,
        intake_session_open=intake_session_open,
    )
    active_work_item = None
    if external_work_item_type:
        work_item_status = resolve_external_work_item_status(
            work_item_type=external_work_item_type,
            followup_status=followup_status,
            command=command,
            has_analysis_content=has_analysis_content,
            normalized_required_missing=normalized_required_missing,
            active_field_key=active_field_key,
        )
        active_work_item = build_active_work_item_payload(
            external_work_item_type=external_work_item_type,
            intake_session_id=intake_session_id,
            trace_id=trace_id,
            work_item_status=work_item_status,
            blocking_is_blocked=blocking_is_blocked,
            blocking_reason=blocking_reason,
            normalized_required_missing=normalized_required_missing,
            has_analysis_content=has_analysis_content,
            active_field_key=active_field_key,
            active_question_id=active_question_id,
            work_item_actions=work_item_actions,
        )
    return {
        "intake_session_id": intake_session_id,
        "intake_session_state": intake_session_state,
        "intake_session_completed": intake_session_completed,
        "active_work_item": active_work_item,
        "active_question_id": active_question_id,
        "active_field_key": active_field_key,
        "asked_required_fields": asked_required_fields,
        "remaining_required_fields": list(normalized_required_missing),
        "followup_status": followup_status,
        "clarification_round": clarification_round,
        "exit_intake_allowed": intake_session_state in {"applied", "analysis_ready", "analysis_running", "analysis_completed"},
        "analysis_ready": analysis_ready,
        "next_question": next_question,
        "pending_merge": pending_merge,
        "unresolved_points": unresolved_points,
        "next_user_action": next_user_action,
    }


__all__ = ["build_intake_followup_state"]
