"""Flag resolution helpers for guided intake status."""

from __future__ import annotations


def resolve_guided_session_flags(
    *,
    current_stage: str,
    required_missing: list[str],
    current_question: dict[str, object] | None,
    command: str,
) -> dict[str, bool]:
    normalized_stage = str(current_stage or "").strip()
    missing_count = len([item for item in required_missing if str(item).strip()])
    has_active_question = isinstance(current_question, dict)
    ready_for_submit = bool(
        normalized_stage == "requirement_intake.ready_for_submit"
    )
    decision_point_active = bool(
        ready_for_submit
        and str(command or "").strip() != "generate_analysis"
    )
    active_collecting = bool(
        normalized_stage.startswith("requirement_intake.collecting")
        or normalized_stage.startswith("requirement_intake.blocked")
        or (
            normalized_stage.startswith("requirement_intake")
            and (missing_count > 0 or has_active_question)
        )
    )
    return {
        "ready_for_submit": ready_for_submit,
        "decision_point_active": decision_point_active,
        "has_active_question": has_active_question,
        "active_collecting": active_collecting,
    }


__all__ = ["resolve_guided_session_flags"]
