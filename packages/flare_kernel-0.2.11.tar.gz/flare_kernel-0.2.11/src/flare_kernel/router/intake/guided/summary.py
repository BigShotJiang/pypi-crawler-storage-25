"""Summary helpers for guided intake status."""

from __future__ import annotations


def build_guided_session_summary(
    *,
    confirmed_updates: list[dict[str, object]],
    field_label_map: dict[str, str],
) -> str:
    normalized_updates = [item for item in confirmed_updates if isinstance(item, dict)]
    if not normalized_updates:
        return "当前关键字段已收口。你可以开始需求分析，或继续补充需求。"
    lines = ["当前轮梳理已收口，已确认的关键信息："]
    for item in normalized_updates[:8]:
        field_key = str(item.get("field_key") or "").strip()
        field_value = str(item.get("field_value") or "").strip()
        if not field_key or not field_value:
            continue
        field_label = str(field_label_map.get(field_key) or field_key).strip() or field_key
        lines.append(f"- {field_label}：{field_value}")
    lines.append("如无补充，可点击“开始需求分析”；也可以先“继续补充需求”。")
    return "\n".join(lines)


__all__ = ["build_guided_session_summary"]
