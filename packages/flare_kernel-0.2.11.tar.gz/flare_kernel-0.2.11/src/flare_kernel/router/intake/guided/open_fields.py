"""Open-field shaping helpers for guided intake status.

DOC HELPER — ORC-02 backend projection boundary.
Pending-field labels are attached from domain field definitions before the
stream status reaches the client; frontend must not infer business labels.
"""

from __future__ import annotations

from typing import Any


def build_open_fields(
    required_missing: list[str],
    current_question: dict[str, Any] | None,
    *,
    fields: dict[str, Any] | None = None,
    intake_strategy: dict[str, Any] | None = None,
    field_label_map: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    open_fields: list[dict[str, Any]] = []
    field_payload = fields if isinstance(fields, dict) else {}
    strategy = intake_strategy if isinstance(intake_strategy, dict) else {}
    labels = field_label_map if isinstance(field_label_map, dict) else {}
    framework_fields = {
        str(item).strip().lower()
        for item in (strategy.get("framework_fields") or [])
        if str(item).strip()
    }
    detail_keywords = tuple(
        str(item).strip().lower()
        for item in (strategy.get("detail_field_keywords") or [])
        if str(item).strip()
    )
    detail_deferral = bool(strategy.get("detail_deferral"))
    current_key = str((current_question or {}).get("field_key") or "").strip()
    prioritized_rows: list[tuple[int, dict[str, Any]]] = []
    for field in required_missing:
        field_key = str(field or "").strip()
        if not field_key:
            continue
        row = {
            "field_key": field_key,
            "priority": "required",
            "is_current": field_key == current_key,
        }
        field_label = str(labels.get(field_key) or "").strip()
        if field_label:
            row["label"] = field_label
            row["field_label"] = field_label
        field_key_lower = field_key.lower()
        if row["is_current"]:
            score = 100
        else:
            score = 50
            if framework_fields and field_key_lower in framework_fields:
                score += 20
            if detail_deferral and detail_keywords and any(keyword in field_key_lower for keyword in detail_keywords):
                score -= 10
            if field_key in field_payload and field_payload.get(field_key) not in (None, "", [], {}):
                score -= 20
        prioritized_rows.append((score, row))
    prioritized_rows.sort(key=lambda item: item[0], reverse=True)
    for _, row in prioritized_rows:
        open_fields.append(row)
    return open_fields


__all__ = ["build_open_fields"]
