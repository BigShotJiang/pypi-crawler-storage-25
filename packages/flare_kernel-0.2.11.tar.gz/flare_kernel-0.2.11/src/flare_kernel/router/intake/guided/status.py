"""Guided-session status assembly helpers for intake status."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.guided.summary import build_guided_session_summary


def build_guided_session_status(
    *,
    resolved_mode: str,
    current_stage: str,
    command: str,
    current_question: dict[str, Any] | None,
    required_fields: list[str],
    required_missing: list[str],
    confirmed_updates: list[dict[str, Any]],
    next_actions: list[dict[str, Any]],
    active_collecting: bool,
    ready_for_submit: bool,
    decision_point_active: bool,
    field_label_map: dict[str, str],
) -> dict[str, Any]:
    normalized_required_fields = [str(item).strip() for item in required_fields if str(item).strip()]
    normalized_required_missing = [str(item).strip() for item in required_missing if str(item).strip()]
    current_question_payload = current_question if isinstance(current_question, dict) else None
    current_field_key = str((current_question_payload or {}).get("field_key") or "").strip()

    total_questions = len(normalized_required_fields)
    if total_questions <= 0:
        total_questions = len(normalized_required_missing) + (1 if current_field_key else 0)
    remaining_count = len(normalized_required_missing)
    answered_count = max(0, total_questions - remaining_count)

    decision_actions = [
        item
        for item in next_actions
        if isinstance(item, dict)
        and str(item.get("action_key") or item.get("type") or "").strip()
        in {"confirm_plan", "continue_collection"}
    ]

    guided_state = "inactive"
    normalized_stage = str(current_stage or "").strip()
    if command == "generate_analysis" or normalized_stage.startswith("requirement_analysis"):
        guided_state = "analysis_active"
    elif active_collecting or bool(normalized_required_missing) or bool(current_question_payload):
        guided_state = "active"
    elif ready_for_submit:
        if command in {"send_message", "submit_intake_answer"}:
            guided_state = "summary_ready"
        elif decision_point_active:
            guided_state = "decision_point"

    summary_text = ""
    if guided_state in {"summary_ready", "decision_point"}:
        summary_text = build_guided_session_summary(
            confirmed_updates=confirmed_updates,
            field_label_map=field_label_map,
        )

    return {
        "state": guided_state,
        "active": guided_state == "active",
        "current_question": current_question_payload,
        "question_queue": {
            "total": total_questions,
            "answered": answered_count,
            "remaining": remaining_count,
            "pending_fields": normalized_required_missing,
        },
        "summary": {
            "text": summary_text,
            "ready": guided_state in {"summary_ready", "decision_point"},
        },
        "decision_point": {
            "active": bool(decision_point_active),
            "actions": decision_actions,
        },
    }


__all__ = ["build_guided_session_status"]
