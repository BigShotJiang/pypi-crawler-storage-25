"""Work-item helpers for guided intake follow-up state."""

from __future__ import annotations

from typing import Any


def resolve_external_work_item_type(
    *,
    current_stage: str,
    command: str,
    intake_session_open: bool,
) -> str:
    if intake_session_open:
        return "intake"
    stage_text = str(current_stage or "").strip().lower()
    command_text = str(command or "").strip().lower()
    if (
        command_text in {"open_field_retrieval", "apply_field_candidate"}
        or stage_text.startswith("evidence_retrieval")
    ):
        return "retrieval"
    if command_text == "generate_analysis" or stage_text.startswith("requirement_analysis"):
        return "analysis"
    return ""


def resolve_external_work_item_status(
    *,
    work_item_type: str,
    followup_status: str,
    command: str,
    has_analysis_content: bool,
    normalized_required_missing: list[str],
    active_field_key: str,
) -> str:
    if work_item_type == "intake":
        return followup_status
    if work_item_type == "analysis":
        if normalized_required_missing and not has_analysis_content:
            return "blocked"
        if has_analysis_content:
            return "completed"
        return "running"
    if work_item_type == "retrieval":
        if str(command or "").strip().lower() == "apply_field_candidate":
            return "completed"
        if active_field_key or normalized_required_missing:
            return "running"
        return "idle"
    return "idle"


def build_work_item_actions(next_actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    work_item_actions: list[dict[str, Any]] = []
    for item in next_actions:
        if not isinstance(item, dict):
            continue
        action_key = str(item.get("action_key") or item.get("type") or "").strip()
        if not action_key:
            continue
        action_status = str(item.get("status") or "available").strip().lower() or "available"
        compact_action: dict[str, Any] = {
            "action_key": action_key,
            "status": action_status,
        }
        command_text = str(item.get("command") or "").strip()
        if command_text:
            compact_action["command"] = command_text
        target_mode = str(item.get("target_mode") or "").strip()
        if target_mode:
            compact_action["target_mode"] = target_mode
        work_item_actions.append(compact_action)
    return work_item_actions


def build_active_work_item_payload(
    *,
    external_work_item_type: str,
    intake_session_id: str,
    trace_id: str,
    work_item_status: str,
    blocking_is_blocked: bool,
    blocking_reason: str,
    normalized_required_missing: list[str],
    has_analysis_content: bool,
    active_field_key: str,
    active_question_id: str,
    work_item_actions: list[dict[str, Any]],
) -> dict[str, Any]:
    is_blocked = blocking_is_blocked
    reason = blocking_reason
    if external_work_item_type == "analysis":
        is_blocked = bool(normalized_required_missing and not has_analysis_content)
        reason = "waiting_required_fields" if is_blocked else ""
    elif external_work_item_type == "retrieval":
        is_blocked = bool(not active_field_key and not normalized_required_missing)
        reason = "waiting_target_field" if is_blocked else ""
    return {
        "id": f"{external_work_item_type}::{intake_session_id or trace_id}",
        "type": external_work_item_type,
        "kind": external_work_item_type,
        "status": work_item_status,
        "blocking": {
            "is_blocked": is_blocked,
            "reason": reason,
        },
        "next_actions": work_item_actions,
        "checkpoint_ref": {
            "intake_session_id": intake_session_id,
            "active_question_id": active_question_id or None,
        },
    }
