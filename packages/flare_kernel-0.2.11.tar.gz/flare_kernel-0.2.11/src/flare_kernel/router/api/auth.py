"""Authorization API routes."""

from __future__ import annotations

from fastapi import APIRouter, Header

from flare_kernel.contracts import AuthExchangeRequest, AuthExchangeResponse
from flare_kernel.router.api.errors import ApiError
from flare_kernel.runtime.auth.exchange import exchange_auth_context

router = APIRouter(tags=["auth"])


def _auth_denied_error(response: AuthExchangeResponse) -> ApiError:
    decision = response.authorization
    is_secret_error = "invalid_exchange_secret" in decision.reason_codes
    return ApiError(
        code="UNAUTHORIZED" if is_secret_error else "FORBIDDEN_SCOPE",
        http_status=401 if is_secret_error else 403,
        message="unauthorized" if is_secret_error else "forbidden scope",
        description=decision.reason,
        context_fields=decision.required_context_fields,
        retryable=False,
        details={"reason_codes": decision.reason_codes},
    )


@router.post("/auth/exchange", response_model=AuthExchangeResponse)
async def exchange_auth(
    req: AuthExchangeRequest,
    x_flare_auth_secret: str | None = Header(default=None),
) -> AuthExchangeResponse:
    response = exchange_auth_context(req, provided_secret=str(x_flare_auth_secret or ""))
    if response.authorization.allowed:
        return response
    raise _auth_denied_error(response)
