"""Project API routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from flare_kernel.contracts import AuthContext, ProjectRecord, ProjectsResponse, ProjectUpsertRequest
from flare_kernel.list_event_broker import publish_list_invalidation
from flare_kernel.router.api.auth_guard import filter_records_for_route_auth, require_route_scope, resolve_route_auth_context
from flare_kernel.project_store import list_projects, upsert_project

router = APIRouter(tags=["projects"])


@router.get("/projects", response_model=ProjectsResponse)
async def list_project_records(
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> ProjectsResponse:
    """List persisted Projects visible to the current Project scope.

    Returns:
        ProjectsResponse containing Project records normalized through ProjectRecord.
    """

    require_route_scope(auth_context, required_scopes=["projects:read"])
    rows = filter_records_for_route_auth(list_projects(), auth_context)
    return ProjectsResponse(projects=[ProjectRecord.model_validate(row) for row in rows])


@router.put("/projects/{project_id}", response_model=ProjectRecord)
async def upsert_project_record(
    project_id: str,
    req: ProjectUpsertRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> ProjectRecord:
    """Create or update a persisted Project record.

    Args:
        project_id: Stable Project identifier from the route path.
        req: Request body carrying the Project name and lifecycle status.

    Returns:
        ProjectRecord containing the stored Project row after the upsert.
    """

    require_route_scope(auth_context, required_scopes=["projects:write"], project_id=project_id)
    row = upsert_project(
        project_id=project_id,
        project_name=req.project_name,
        status=req.status,
    )
    publish_list_invalidation(resource="projects", reason="upserted")
    return ProjectRecord.model_validate(row)
