"""List invalidation SSE API route."""

from __future__ import annotations

import asyncio

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse

from flare_kernel.contracts import AuthContext, ListEventRecord
from flare_kernel.list_event_broker import subscribe_list_events, unsubscribe_list_events
from flare_kernel.router.api.auth_guard import require_route_scope, resolve_route_auth_context

router = APIRouter(tags=["list-events"])

_HEARTBEAT_SECONDS = 15


def _format_sse_event(event: ListEventRecord) -> str:
    return f"event: {event.event_type}\ndata: {event.model_dump_json()}\n\n"


async def _iter_list_events(request: Request):
    queue = subscribe_list_events()
    try:
        while not await request.is_disconnected():
            try:
                event = await asyncio.wait_for(queue.get(), timeout=_HEARTBEAT_SECONDS)
            except asyncio.TimeoutError:
                yield ": heartbeat\n\n"
                continue
            yield _format_sse_event(event)
    finally:
        unsubscribe_list_events(queue)


@router.get("/chat/list-events")
async def stream_chat_list_events(
    request: Request,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> StreamingResponse:
    """Stream list invalidation events for session/project projections."""

    require_route_scope(auth_context, required_scopes=["sessions:read", "projects:read"])
    return StreamingResponse(
        _iter_list_events(request),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )
