"""Update plane API routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from flare_kernel.contracts import (
    AuthContext,
    UpdateCheckRequest,
    UpdateCheckResult,
    UpgradePlanRequest,
    UpgradePlanResult,
)
from flare_kernel.router.api.auth_guard import require_route_scope, resolve_route_auth_context
from flare_kernel.update import check_update, create_upgrade_plan

router = APIRouter(prefix="/update", tags=["update"])


@router.post("/check", response_model=UpdateCheckResult)
async def post_update_check(
    req: UpdateCheckRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> UpdateCheckResult:
    require_route_scope(auth_context, required_scopes=["updates:read"])
    return check_update(req)


@router.post("/plan", response_model=UpgradePlanResult)
async def post_upgrade_plan(
    req: UpgradePlanRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> UpgradePlanResult:
    require_route_scope(auth_context, required_scopes=["updates:read"])
    return create_upgrade_plan(req)
