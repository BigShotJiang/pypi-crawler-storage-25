"""Chat API aliases backed by kernel runtime endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

from flare_kernel.contracts import AuthContext, KernelRequest, KernelResponse
from flare_kernel.router.api.auth_guard import resolve_route_auth_context
from flare_kernel.router.kernel import kernel_action, kernel_run, kernel_stream

router = APIRouter(tags=["chat"])


@router.post("/chat/run", response_model=KernelResponse)
async def chat_run(
    req: KernelRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> KernelResponse:
    return await kernel_run(req, auth_context=auth_context)


@router.post("/chat/action", response_model=KernelResponse)
async def chat_action(
    req: KernelRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> KernelResponse:
    return await kernel_action(req, auth_context=auth_context)


@router.post("/chat/stream")
async def chat_stream(
    req: KernelRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> StreamingResponse:
    return await kernel_stream(req, auth_context=auth_context)


__all__ = ["router"]
