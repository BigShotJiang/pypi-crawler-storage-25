"""Run state and event replay API routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from flare_kernel.contracts import AuthContext, RunEventListResponse, RunEventRecord, RunListResponse, RunRecord
from flare_kernel.router.api.auth_guard import require_route_scope, resolve_route_auth_context
from flare_kernel.router.api.errors import ApiError
from flare_kernel.run_store import get_run, list_run_events, list_session_runs

router = APIRouter(tags=["runs"])


def _require_run_or_404(run_id: str) -> dict:
    record = get_run(run_id=run_id)
    if record is not None:
        return record
    raise ApiError(
        code="RESOURCE_NOT_FOUND",
        http_status=404,
        message="run not found",
        description="target run_id does not exist",
        context_fields=["run_id"],
        retryable=False,
        details={"run_id": run_id},
    )


@router.get("/runs/{run_id}", response_model=RunRecord)
@router.get("/chat/runs/{run_id}", response_model=RunRecord)
async def get_chat_run(
    run_id: str,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> RunRecord:
    record = _require_run_or_404(run_id)
    require_route_scope(auth_context, required_scopes=["sessions:read"], session_id=str(record.get("session_id") or ""))
    return RunRecord.model_validate(record)


@router.get("/runs/{run_id}/events", response_model=RunEventListResponse)
@router.get("/chat/runs/{run_id}/events", response_model=RunEventListResponse)
async def list_chat_run_events(
    run_id: str,
    after_sequence: int = 0,
    limit: int = 500,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> RunEventListResponse:
    record = _require_run_or_404(run_id)
    require_route_scope(auth_context, required_scopes=["sessions:read"], session_id=str(record.get("session_id") or ""))
    resolved_limit = max(1, min(int(limit or 500), 1000))
    rows = [
        row
        for row in list_run_events(run_id=run_id)
        if int(row.get("sequence") or 0) > int(after_sequence or 0)
    ][:resolved_limit]
    return RunEventListResponse(events=[RunEventRecord.model_validate(row) for row in rows])


@router.get("/chat/sessions/{session_id}/runs", response_model=RunListResponse)
async def list_chat_session_runs(
    session_id: str,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> RunListResponse:
    require_route_scope(auth_context, required_scopes=["sessions:read"], session_id=session_id)
    rows = list_session_runs(session_id=session_id)
    return RunListResponse(runs=[RunRecord.model_validate(row) for row in rows])
