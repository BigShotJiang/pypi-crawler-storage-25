"""API error contract helpers for transport-layer responses."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse


@dataclass(slots=True)
class ApiError(Exception):
    """Structured API error for transport-layer mapping."""

    code: str
    http_status: int
    message: str
    description: str = ""
    context_fields: list[str] = field(default_factory=list)
    retryable: bool = False
    details: dict[str, Any] = field(default_factory=dict)


def build_error_response_payload(
    *,
    code: str,
    http_status: int,
    message: str,
    description: str = "",
    context_fields: list[str] | None = None,
    retryable: bool = False,
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    context_field_list = list(context_fields or [])
    return {
        "error": {
            "code": code,
            "message": message,
            "details": {
                **(details or {}),
                "http_status": http_status,
                "description": description,
                "context_fields": context_field_list,
                "retryable": retryable,
            },
        }
    }


def _default_code_by_status(status_code: int) -> str:
    if status_code == 403:
        return "FORBIDDEN_SCOPE"
    if status_code == 404:
        return "RESOURCE_NOT_FOUND"
    if status_code == 409:
        return "INVALID_STATE_TRANSITION"
    if status_code == 422:
        return "INVALID_REQUEST"
    if status_code == 401:
        return "UNAUTHORIZED"
    return "HTTP_EXCEPTION"


def _default_message_by_status(status_code: int) -> str:
    if status_code == 403:
        return "forbidden scope"
    if status_code == 404:
        return "resource not found"
    if status_code == 409:
        return "invalid state transition"
    if status_code == 422:
        return "invalid request"
    if status_code == 401:
        return "unauthorized"
    return "request failed"


async def api_error_exception_handler(_: Request, exc: ApiError) -> JSONResponse:
    payload = build_error_response_payload(
        code=exc.code,
        http_status=exc.http_status,
        message=exc.message,
        description=exc.description,
        context_fields=exc.context_fields,
        retryable=exc.retryable,
        details=exc.details,
    )
    return JSONResponse(status_code=exc.http_status, content=payload)


async def http_exception_handler(_: Request, exc: HTTPException) -> JSONResponse:
    status_code = int(exc.status_code)
    code = _default_code_by_status(status_code)
    message = _default_message_by_status(status_code)
    details: dict[str, Any] = {}

    if isinstance(exc.detail, dict):
        maybe_error = exc.detail.get("error")
        if isinstance(maybe_error, dict):
            code = str(maybe_error.get("code") or code)
            message = str(maybe_error.get("message") or message)
            details = maybe_error.get("details") if isinstance(maybe_error.get("details"), dict) else {}
        else:
            code = str(exc.detail.get("code") or code)
            message = str(exc.detail.get("message") or message)
            details = exc.detail.get("details") if isinstance(exc.detail.get("details"), dict) else {}
    elif isinstance(exc.detail, str) and exc.detail.strip():
        message = exc.detail.strip()

    payload = build_error_response_payload(
        code=code,
        http_status=status_code,
        message=message,
        details=details,
    )
    return JSONResponse(status_code=status_code, content=payload)


async def unhandled_exception_handler(_: Request, __: Exception) -> JSONResponse:
    payload = build_error_response_payload(
        code="INTERNAL_ERROR",
        http_status=500,
        message="internal server error",
        description="unexpected server exception",
        retryable=False,
    )
    return JSONResponse(status_code=500, content=payload)

