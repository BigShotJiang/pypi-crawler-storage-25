"""Session API list invalidation event projection."""

from __future__ import annotations

from flare_kernel.list_event_broker import publish_list_invalidation


def publish_session_list_invalidation(reason: str) -> None:
    """Publish a list invalidation event for a changed session record."""

    publish_list_invalidation(
        resource="all",
        reason=str(reason or "").strip(),
    )
