"""Session and session-message API routes.

DOC HELPER — OBJ-09 transport boundary.
Routes pass context authority metadata through the session contract but do not
interpret, derive, or mutate backend context state.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from flare_kernel.contracts import (
    AuthContext,
    SessionAppendExchangeRequest,
    SessionCreateRequest,
    SessionLifecycleRequest,
    SessionListResponse,
    SessionMessageListResponse,
    SessionRecord,
    SessionReplayResponse,
    SessionUpdateRequest,
)
from flare_kernel.router.api.auth_guard import (
    guarded_filter_value,
    guarded_project_id,
    guarded_user_id,
    require_route_scope,
    resolve_route_auth_context,
)
from flare_kernel.router.api.errors import ApiError
from flare_kernel.router.api.session_list_events import publish_session_list_invalidation
from flare_kernel.session_replay import build_session_replay
from flare_kernel.session_store import (
    apply_lifecycle_action,
    append_exchange,
    create_session,
    ensure_session,
    get_session,
    list_messages,
    list_sessions,
    update_session,
)

router = APIRouter(tags=["sessions"])


def _require_session_or_404(session_id: str) -> dict:
    record = get_session(session_id=session_id)
    if record is not None:
        return record
    raise ApiError(
        code="RESOURCE_NOT_FOUND",
        http_status=404,
        message="session not found",
        description="target session_id does not exist",
        context_fields=["session_id"],
        retryable=False,
        details={"session_id": session_id},
    )


def _require_session_scope(
    auth_context: AuthContext | None,
    record: dict,
    required_scopes: list[str],
) -> None:
    require_route_scope(
        auth_context,
        required_scopes=required_scopes,
        project_id=str(record.get("project_id") or ""),
        session_id=str(record.get("session_id") or ""),
        user_id=str(record.get("user_id") or ""),
    )


def _invalid_lifecycle_error(exc: ValueError, fields: list[str]) -> ApiError:
    """Map lifecycle policy validation failures to the API error contract.

    Args:
        exc: Policy validation exception raised by session lifecycle helpers.
        fields: Request fields responsible for the validation failure.

    Returns:
        ApiError with the shared structured error payload fields.
    """

    return ApiError(
        code="INVALID_SESSION_LIFECYCLE",
        http_status=422,
        message="invalid session lifecycle",
        description=str(exc),
        context_fields=fields,
        retryable=False,
    )


@router.get("/sessions", response_model=SessionListResponse)
@router.get("/chat/sessions", response_model=SessionListResponse)
async def list_chat_sessions(
    status: str = Query(default=""),
    function_type: str = Query(default=""),
    project_id: str = Query(default=""),
    user_id: str = Query(default=""),
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> SessionListResponse:
    """List sessions using lifecycle-aware status filtering.

    Args:
        status: Empty for active-only, archived for archived-only, all for all.
        function_type: Optional function-type filter.
        project_id: Optional project scope filter.
        user_id: Optional user scope filter.

    Returns:
        Session list response with records normalized by the store layer.
    """

    try:
        require_route_scope(
            auth_context,
            required_scopes=["sessions:read"],
            project_id=project_id,
            user_id=user_id,
        )
        rows = list_sessions(
            status=status,
            function_type=function_type,
            project_id=guarded_filter_value(project_id, guarded_project_id(auth_context)),
            user_id=guarded_filter_value(user_id, guarded_user_id(auth_context)),
        )
    except ValueError as exc:
        raise _invalid_lifecycle_error(exc, ["status"]) from exc
    return SessionListResponse(sessions=[SessionRecord.model_validate(row) for row in rows])


@router.post("/sessions", response_model=SessionRecord)
@router.post("/chat/sessions", response_model=SessionRecord)
async def create_chat_session(
    req: SessionCreateRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> SessionRecord:
    require_route_scope(
        auth_context,
        required_scopes=["sessions:write"],
        project_id=str(req.project_id or ""),
        user_id=str(req.user_id or ""),
    )
    row = create_session(
        function_type=req.function_type,
        project_id=req.project_id,
        title=req.title,
        user_id=req.user_id,
    )
    publish_session_list_invalidation("created")
    return SessionRecord.model_validate(row)


@router.get("/sessions/{session_id}", response_model=SessionRecord)
@router.get("/chat/sessions/{session_id}", response_model=SessionRecord)
async def get_chat_session(
    session_id: str,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> SessionRecord:
    record = _require_session_or_404(session_id)
    _require_session_scope(auth_context, record, ["sessions:read"])
    return SessionRecord.model_validate(record)


@router.patch("/sessions/{session_id}", response_model=SessionRecord)
@router.patch("/chat/sessions/{session_id}", response_model=SessionRecord)
async def patch_chat_session(
    session_id: str,
    req: SessionUpdateRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> SessionRecord:
    """Patch session metadata while preserving lifecycle status constraints.

    Args:
        session_id: Target session id.
        req: Metadata patch request.

    Returns:
        Updated session record.
    """

    record = _require_session_or_404(session_id)
    _require_session_scope(auth_context, record, ["sessions:write"])
    try:
        row = update_session(
            session_id=session_id,
            title=req.title,
            status=req.status,
            function_type=req.function_type,
            preview=req.preview,
            title_source=req.title_source,
        )
    except ValueError as exc:
        raise _invalid_lifecycle_error(exc, ["status"]) from exc
    next_row = row or _require_session_or_404(session_id)
    publish_session_list_invalidation("updated")
    return SessionRecord.model_validate(next_row)


@router.get("/sessions/{session_id}/messages", response_model=SessionMessageListResponse)
@router.get("/chat/sessions/{session_id}/messages", response_model=SessionMessageListResponse)
async def list_chat_session_messages(
    session_id: str,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> SessionMessageListResponse:
    record = _require_session_or_404(session_id)
    _require_session_scope(auth_context, record, ["sessions:read"])
    return SessionMessageListResponse(messages=list_messages(session_id=session_id))


@router.get("/sessions/{session_id}/replay", response_model=SessionReplayResponse)
@router.get("/chat/sessions/{session_id}/replay", response_model=SessionReplayResponse)
async def get_chat_session_replay(
    session_id: str,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> SessionReplayResponse:
    """Return the read-only replay projection for a session.

    Args:
        session_id: Target session id.

    Returns:
        Session replay response including messages, turns, and diagnostics.
    """

    replay = build_session_replay(session_id=session_id)
    if replay is None:
        record = _require_session_or_404(session_id)
    else:
        record = dict(replay.get("session") or {})
    _require_session_scope(auth_context, record, ["sessions:read"])
    return SessionReplayResponse.model_validate(replay)


@router.post("/sessions/{session_id}/lifecycle", response_model=SessionRecord)
@router.post("/chat/sessions/{session_id}/lifecycle", response_model=SessionRecord)
async def apply_chat_session_lifecycle(
    session_id: str,
    req: SessionLifecycleRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> SessionRecord:
    """Apply an explicit archive/restore lifecycle command to a session.

    Args:
        session_id: Target session id.
        req: Lifecycle command request.

    Returns:
        Updated session record after the lifecycle transition.
    """

    record = _require_session_or_404(session_id)
    _require_session_scope(auth_context, record, ["sessions:write"])
    try:
        row = apply_lifecycle_action(session_id=session_id, action=req.action)
    except ValueError as exc:
        raise _invalid_lifecycle_error(exc, ["action"]) from exc
    next_row = row or _require_session_or_404(session_id)
    publish_session_list_invalidation(str(req.action or "").strip() or "lifecycle")
    return SessionRecord.model_validate(next_row)


@router.post("/sessions/{session_id}/messages", response_model=SessionRecord)
@router.post("/chat/sessions/{session_id}/messages", response_model=SessionRecord)
async def append_chat_session_exchange(
    session_id: str,
    req: SessionAppendExchangeRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> SessionRecord:
    record = _require_session_or_404(session_id)
    _require_session_scope(auth_context, record, ["sessions:write"])
    row = append_exchange(
        session_id=session_id,
        run_id=req.run_id,
        user_message=req.user_message,
        assistant_message=req.assistant_message,
        attachments=req.attachments,
        context_refs=req.context_refs,
        knowledge_refs=req.knowledge_refs,
        agent_status=req.agent_status,
        thinking_trace=req.thinking_trace,
        execution_trace=req.execution_trace,
        knowledge_search=req.knowledge_search,
        sourcing_candidates=req.sourcing_candidates,
        knowledge_citation=req.knowledge_citation,
        canvas_state=req.canvas_state,
        analysis_payload=req.analysis_payload,
        context_usage=req.context_usage,
        provider_trace=req.provider_trace,
        context_authority=req.context_authority,
        plan_payload=req.plan_payload,
        reasoning_result=req.reasoning_result,
        document_result=req.document_result,
        track_result=req.track_result,
        context_patch=req.context_patch,
        context_snapshot=req.context_snapshot,
    )
    next_row = row or _require_session_or_404(session_id)
    publish_session_list_invalidation("message_appended")
    return SessionRecord.model_validate(next_row)


@router.post("/sessions/ensure", response_model=SessionRecord)
@router.post("/chat/sessions/ensure", response_model=SessionRecord)
async def ensure_chat_session(
    req: SessionCreateRequest,
    session_id: str | None = None,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> SessionRecord:
    require_route_scope(
        auth_context,
        required_scopes=["sessions:write"],
        project_id=str(req.project_id or ""),
        session_id=str(session_id or ""),
        user_id=str(req.user_id or ""),
    )
    row = ensure_session(
        session_id=session_id,
        function_type=req.function_type,
        project_id=req.project_id,
        title=req.title,
        user_id=req.user_id,
    )
    publish_session_list_invalidation("ensured")
    return SessionRecord.model_validate(row)
