"""Transport helpers for route scope authorization."""

from __future__ import annotations

import json
import os
from typing import Any

from fastapi import Header
from pydantic import ValidationError

from flare_kernel.contracts import AuthContext, AuthorizationDecision
from flare_kernel.router.api.errors import ApiError
from flare_kernel.runtime.auth.scope_guard import (
    evaluate_route_scope,
    filter_records_for_auth_context,
    resolve_guarded_filter_value,
)


def route_guard_enabled() -> bool:
    return str(os.getenv("FLARE_AUTH_ROUTE_GUARD_ENABLED") or "").strip() == "1"


def _error_from_decision(decision: AuthorizationDecision) -> ApiError:
    reason_codes = list(decision.reason_codes)
    is_auth_error = "missing_auth_context" in reason_codes or "invalid_auth_context" in reason_codes
    return ApiError(
        code="UNAUTHORIZED" if is_auth_error else "FORBIDDEN_SCOPE",
        http_status=401 if is_auth_error else 403,
        message="unauthorized" if is_auth_error else "forbidden scope",
        description=decision.reason,
        context_fields=decision.required_context_fields,
        retryable=False,
        details={
            "reason_codes": reason_codes,
            "denied_scopes": list(decision.denied_scopes),
        },
    )


def _invalid_auth_context_error() -> ApiError:
    return _error_from_decision(
        AuthorizationDecision(
            allowed=False,
            reason="auth context header is invalid",
            reason_codes=["invalid_auth_context"],
        )
    )


async def resolve_route_auth_context(
    x_flare_auth_context: str | None = Header(default=None, alias="X-FLARE-Auth-Context"),
) -> AuthContext | None:
    raw = str(x_flare_auth_context or "").strip()
    if not raw:
        return None
    try:
        parsed = json.loads(raw)
        return AuthContext.model_validate(parsed)
    except (json.JSONDecodeError, TypeError, ValidationError) as exc:
        raise _invalid_auth_context_error() from exc


def require_route_scope(
    auth_context: AuthContext | None,
    *,
    required_scopes: list[str] | tuple[str, ...],
    project_id: str = "",
    session_id: str = "",
    user_id: str = "",
) -> None:
    if not route_guard_enabled():
        return
    decision = evaluate_route_scope(
        auth_context,
        required_scopes=required_scopes,
        project_id=project_id,
        session_id=session_id,
        user_id=user_id,
    )
    if decision.allowed:
        return
    raise _error_from_decision(decision)


def guarded_filter_value(requested_value: str, auth_value: str) -> str:
    if not route_guard_enabled():
        return str(requested_value or "").strip()
    return resolve_guarded_filter_value(requested_value, auth_value)


def guarded_project_id(auth_context: AuthContext | None) -> str:
    return str(auth_context.project_id if auth_context else "").strip()


def guarded_user_id(auth_context: AuthContext | None) -> str:
    principal = auth_context.principal if auth_context else None
    return str(principal.user_id if principal else "").strip()


def filter_records_for_route_auth(
    records: list[dict[str, Any]],
    auth_context: AuthContext | None,
) -> list[dict[str, Any]]:
    if not route_guard_enabled():
        return list(records)
    return filter_records_for_auth_context(records, auth_context)
