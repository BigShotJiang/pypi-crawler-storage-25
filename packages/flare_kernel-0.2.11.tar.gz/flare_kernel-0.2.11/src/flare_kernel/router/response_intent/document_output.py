"""Document-output request detection for response policy."""

from __future__ import annotations

_DOCUMENT_OUTPUT_ACTION_TERMS = (
    "整理",
    "撰写",
    "生成",
    "输出",
    "写",
    "起草",
)

_DOCUMENT_OUTPUT_ARTIFACT_TERMS = (
    "文档",
    "模板",
    "清单",
    "方案",
    "报告",
    "正文",
    "草案",
)


def requests_document_output(message: str) -> bool:
    """Return whether the user is asking for a concrete written artifact.

    DOC HELPER — this is a response-shaping signal, not a business rule. It
    prevents explicit artifact requests from being downgraded into field-only
    clarification, while still allowing the answer to mark missing data.
    """

    normalized = str(message or "").strip()
    if not normalized:
        return False
    has_action = any(term in normalized for term in _DOCUMENT_OUTPUT_ACTION_TERMS)
    has_artifact = any(term in normalized for term in _DOCUMENT_OUTPUT_ARTIFACT_TERMS)
    return has_action and has_artifact
