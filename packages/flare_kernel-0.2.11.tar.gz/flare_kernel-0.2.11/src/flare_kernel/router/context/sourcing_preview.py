"""Helpers for sourcing preview retrieval during collecting stage."""

from __future__ import annotations

from typing import Any, Callable


def _coerce_preview_row(item: dict[str, Any]) -> dict[str, Any]:
    title = str(item.get("title") or item.get("source_title") or "").strip()
    snippet = str(item.get("snippet") or item.get("content") or "").strip()
    if not title and not snippet:
        return {}
    return {
        "title": title or snippet[:48] or "检索线索",
        "content": snippet,
        "snippet": snippet,
        "url": str(item.get("url") or item.get("canonical_url") or "").strip(),
        "source_type": str(item.get("source_type") or "web").strip() or "web",
        "source": str(item.get("source") or item.get("source_type") or "web").strip() or "web",
        "source_label": str(item.get("provider") or item.get("source_label") or "web").strip() or "web",
        "score": item.get("score") if item.get("score") is not None else 0.0,
    }


def maybe_append_sourcing_preview_rows(
    *,
    retrieved_knowledge: list[dict[str, Any]],
    resolved_mode: str,
    raw_message: str,
    retrieval_top_k: int,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    search_web_sources_fn: Callable[..., list[dict[str, Any]]] | None,
) -> list[dict[str, Any]]:
    if str(resolved_mode or "").strip() != "intelligent_sourcing":
        return retrieved_knowledge
    if retrieved_knowledge:
        return retrieved_knowledge
    if not callable(search_web_sources_fn):
        return retrieved_knowledge

    query = str(raw_message or "").strip()
    if not query:
        return retrieved_knowledge

    top_k = max(1, int(retrieval_top_k or 1))
    try:
        preview_rows = search_web_sources_fn(
            query=query,
            top_k=top_k,
            trace_id=trace_id,
            session_id=session_id,
            project_id=project_id,
            user_id=user_id,
        )
    except Exception:
        return retrieved_knowledge

    if not isinstance(preview_rows, list):
        return retrieved_knowledge

    normalized: list[dict[str, Any]] = []
    for item in preview_rows:
        if not isinstance(item, dict):
            continue
        row = _coerce_preview_row(item)
        if row:
            normalized.append(row)
    return normalized or retrieved_knowledge


__all__ = ["maybe_append_sourcing_preview_rows"]
