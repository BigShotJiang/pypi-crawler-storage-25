"""Endpoint context preparation helpers for kernel router handlers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.prompting.summary_contract import apply_prompt_summary_contract


def _normalize_action_target_mode(value: str) -> str:
    return str(value or "").strip().lower().replace("-", "_").replace(" ", "_")


def unpack_kernel_turn_context(turn: dict[str, Any]) -> dict[str, Any]:
    return {
        "trace_id": str(turn["trace_id"]),
        "command": str(turn["command"]),
        "session_id": str(turn["session_id"]),
        "instance_profile": turn["instance_profile"],
        "resolved_intent": str(turn["resolved_intent"]),
        "intent_source": str(turn["intent_source"]),
        "intent_confidence": float(turn["intent_confidence"]),
        "intent_reason": str(turn["intent_reason"]),
        "raw_message": str(turn["raw_message"]),
        "resolved_mode": str(turn["resolved_mode"]),
        "mode_source": str(turn["mode_source"]),
        "project_id": str(turn["project_id"] or ""),
        "user_id": str(turn["user_id"] or ""),
        "retrieval_config": turn["retrieval_config"] if isinstance(turn["retrieval_config"], dict) else {},
        "retrieval_queries": turn["retrieval_queries"] if isinstance(turn["retrieval_queries"], list) else [],
        "retrieval_attempted": bool(turn["retrieval_attempted"]),
        "retrieved_knowledge": turn["retrieved_knowledge"] if isinstance(turn["retrieved_knowledge"], list) else [],
        "enriched_payload": turn["enriched_payload"] if isinstance(turn["enriched_payload"], dict) else {},
        "runtime_snapshot": turn["runtime_snapshot"] if isinstance(turn["runtime_snapshot"], dict) else {},
        "orchestration_status": turn["orchestration_status"] if isinstance(turn["orchestration_status"], dict) else {},
        "escalation_signal": turn["escalation_signal"] if isinstance(turn["escalation_signal"], dict) else {},
        "effective_command": str(turn["effective_command"]),
        "structured_retrieved_knowledge": (
            turn["structured_retrieved_knowledge"]
            if isinstance(turn["structured_retrieved_knowledge"], list)
            else []
        ),
    }


def prepare_action_turn_context(
    req: KernelRequest,
    *,
    resolve_trace_id_fn: Callable[[Any], str],
    load_instance_profile_fn: Callable[[str], dict[str, Any] | None],
    resolve_intent_escalation_policy_with_source_fn: Callable[..., tuple[dict[str, Any], str]],
    resolve_command_fn: Callable[[KernelRequest], str],
    resolve_action_target_mode_fn: Callable[[KernelRequest], str],
    build_action_payload_fn: Callable[[KernelRequest, str], dict[str, Any]],
    enrich_payload_fn: Callable[..., dict[str, Any]],
    build_kernel_runtime_fn: Callable[..., dict[str, Any]],
    build_orchestration_status_fn: Callable[..., dict[str, Any]],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    build_intent_and_escalation_signal_fn: Callable[..., dict[str, Any]],
    merge_intent_and_escalation_signal_fn: Callable[..., dict[str, Any]],
) -> dict[str, Any]:
    trace_id = resolve_trace_id_fn(req.trace_id)
    instance_profile = load_instance_profile_fn(req.instance_id)
    intent_escalation_policy, intent_escalation_policy_source = resolve_intent_escalation_policy_with_source_fn(req=req)
    action_command = resolve_command_fn(req)
    action_target_mode = _normalize_action_target_mode(resolve_action_target_mode_fn(req))
    action_payload = build_action_payload_fn(req, action_target_mode)
    if isinstance(req.project_id, str) and req.project_id.strip():
        action_payload["project_id"] = req.project_id.strip()
    if isinstance(req.user_id, str) and req.user_id.strip():
        action_payload["user_id"] = req.user_id.strip()
    enriched_action_req_data = req.model_dump(mode="python")
    enriched_action_req_data["payload"] = action_payload
    enriched_action_req_data["intent"] = action_target_mode
    action_payload = enrich_payload_fn(
        KernelRequest(**enriched_action_req_data),
        resolved_mode=action_target_mode,
        retrieved_knowledge=[],
    )
    runtime_snapshot = build_kernel_runtime_fn(
        trace_id=trace_id,
        tenant_id=req.tenant_id,
        instance_id=req.instance_id,
        domain_pack_version=req.domain_pack_version,
        session_id=req.session_id,
        intent=action_target_mode,
        payload=action_payload,
        instance_profile=instance_profile,
    )
    apply_prompt_summary_contract(payload=action_payload, runtime_snapshot=runtime_snapshot)
    orchestration_status = build_orchestration_status_fn(
        trace_id=trace_id,
        command=action_command,
        resolved_intent=action_target_mode,
        resolved_mode=action_target_mode,
        intent_source="action",
        intent_confidence=1.0,
        intent_reason=str(req.action_reason or ""),
        runtime_snapshot=runtime_snapshot,
        raw_message=extract_user_message_fn(action_payload),
        retrieval_attempted=False,
        retrieval_queries=[],
        retrieved_knowledge=[],
        intent_escalation_policy=intent_escalation_policy,
        intent_escalation_policy_source=intent_escalation_policy_source,
        analysis_route=(
            action_payload.get("analysis_route")
            if isinstance(action_payload.get("analysis_route"), dict)
            else {}
        ),
    )
    action_message = extract_user_message_fn(action_payload)
    escalation_signal = build_intent_and_escalation_signal_fn(
        req=req,
        command=action_command,
        message=action_message,
        resolved_intent=action_target_mode,
        resolved_mode=action_target_mode,
        mode_source="action",
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
    )
    orchestration_status = merge_intent_and_escalation_signal_fn(
        orchestration_status=orchestration_status,
        signal=escalation_signal,
    )
    return {
        "trace_id": trace_id,
        "instance_profile": instance_profile,
        "action_command": action_command,
        "action_target_mode": action_target_mode,
        "action_payload": action_payload,
        "runtime_snapshot": runtime_snapshot,
        "orchestration_status": orchestration_status,
        "action_message": action_message,
        "escalation_signal": escalation_signal,
    }
