"""Canonical-state flow body for the kernel facade helper layer."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime import resolve_trace_id
from flare_kernel.router.canonical.analysis import (
    apply_analysis_and_retrieval_projection,
)
from flare_kernel.router.canonical.context import (
    resolve_canonical_state_context,
)
from flare_kernel.router.canonical.payload import (
    build_canonical_payload,
)
from flare_kernel.router.intake.authority.core import (
    normalize_intake_session_id as normalize_intake_session_id_from_authority,
)
from flare_kernel.router.intake.canonicalization import (
    is_field_entity_confirmed as _is_field_entity_confirmed,
)
from flare_kernel.router.intake.status.schema import (
    build_confirmed_fields_schema as _build_confirmed_fields_schema_from_router,
    build_missing_fields_schema as _build_missing_fields_schema_from_router,
    coerce_intent_escalation_policy as _coerce_intent_escalation_policy_from_router,
    normalize_stage_status as _normalize_stage_status_from_router,
)
from flare_kernel.router.kernel_facade.dependency_resolution import (
    resolve_canonical_state_dependencies,
)
from flare_kernel.router.kernel_facade.utils import (
    _kernel_attr,
    _map_external_mode,
    _safe_session_id,
)
from flare_kernel.router.kernel_flow_bindings.session_intent import (
    resolve_session_intent_stage as _resolve_session_intent_stage_in_kernel_session_intent_flow,
)
from flare_kernel.router.text_safety import (
    extract_user_message as _extract_user_message,
)


def build_kernel_canonical_state_flow(
    *,
    req: KernelRequest,
    command: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    orchestration_status: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    assistant_text: str,
    provider_status: str,
    normalized_retrieved_knowledge: list[dict[str, Any]],
    map_external_mode_fn: Callable[[str], str],
    resolve_session_intent_stage_fn: Callable[..., str],
    coerce_intent_escalation_policy_fn: Callable[[Any], dict[str, Any]],
    normalize_stage_status_fn: Callable[..., tuple[str, str]],
    build_confirmed_fields_schema_fn: Callable[..., dict[str, Any]],
    build_missing_fields_schema_fn: Callable[..., dict[str, Any]],
    is_field_entity_confirmed_fn: Callable[[Any], bool],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    normalize_intake_session_id_fn: Callable[[Any], str],
    resolve_trace_id_fn: Callable[..., str],
    safe_session_id_fn: Callable[[Any], str],
) -> dict[str, Any]:
    """Build canonical kernel response state from resolved dependencies."""
    canonical_context = resolve_canonical_state_context(
        req=req,
        command=command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        orchestration_status=orchestration_status,
        assistant_text=assistant_text,
        map_external_mode_fn=map_external_mode_fn,
        resolve_session_intent_stage_fn=resolve_session_intent_stage_fn,
        coerce_intent_escalation_policy_fn=coerce_intent_escalation_policy_fn,
        normalize_stage_status_fn=normalize_stage_status_fn,
        is_field_entity_confirmed_fn=is_field_entity_confirmed_fn,
        extract_user_message_fn=extract_user_message_fn,
        normalize_intake_session_id_fn=normalize_intake_session_id_fn,
    )
    canonical = build_canonical_payload(
        req=req,
        command=command,
        mode_source=mode_source,
        orchestration_status=orchestration_status,
        runtime_snapshot=runtime_snapshot,
        assistant_text=assistant_text,
        provider_status=provider_status,
        canonical_context=canonical_context,
        build_confirmed_fields_schema_fn=build_confirmed_fields_schema_fn,
        build_missing_fields_schema_fn=build_missing_fields_schema_fn,
        resolve_trace_id_fn=resolve_trace_id_fn,
        safe_session_id_fn=safe_session_id_fn,
    )
    apply_analysis_and_retrieval_projection(
        canonical=canonical,
        command=command,
        can_generate=bool(canonical_context.get("can_generate")),
        assistant_text=assistant_text,
        normalized_retrieved_knowledge=normalized_retrieved_knowledge,
    )
    return canonical


def _build_canonical_state(
    *,
    req: KernelRequest,
    command: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    orchestration_status: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    assistant_text: str,
    provider_status: str,
    structured_retrieved_knowledge: list[dict[str, Any]] | None = None,
    map_external_mode_fn=None,
    resolve_session_intent_stage_fn=None,
    coerce_intent_escalation_policy_fn=None,
    normalize_stage_status_fn=None,
    build_confirmed_fields_schema_fn=None,
    build_missing_fields_schema_fn=None,
    is_field_entity_confirmed_fn=None,
    extract_user_message_fn=None,
    normalize_intake_session_id_fn=None,
    resolve_trace_id_fn=None,
    safe_session_id_fn=None,
) -> dict[str, Any]:
    canonical_deps = resolve_canonical_state_dependencies(
        map_external_mode_fn=map_external_mode_fn,
        resolve_session_intent_stage_fn=resolve_session_intent_stage_fn,
        coerce_intent_escalation_policy_fn=coerce_intent_escalation_policy_fn,
        normalize_stage_status_fn=normalize_stage_status_fn,
        build_confirmed_fields_schema_fn=build_confirmed_fields_schema_fn,
        build_missing_fields_schema_fn=build_missing_fields_schema_fn,
        is_field_entity_confirmed_fn=is_field_entity_confirmed_fn,
        extract_user_message_fn=extract_user_message_fn,
        normalize_intake_session_id_fn=normalize_intake_session_id_fn,
        resolve_trace_id_fn=resolve_trace_id_fn,
        safe_session_id_fn=safe_session_id_fn,
        kernel_attr_fn=_kernel_attr,
        defaults={
            "map_external_mode_fn": _map_external_mode,
            "resolve_session_intent_stage_fn": _resolve_session_intent_stage_in_kernel_session_intent_flow,
            "coerce_intent_escalation_policy_fn": _coerce_intent_escalation_policy_from_router,
            "normalize_stage_status_fn": _normalize_stage_status_from_router,
            "build_confirmed_fields_schema_fn": _build_confirmed_fields_schema_from_router,
            "build_missing_fields_schema_fn": _build_missing_fields_schema_from_router,
            "is_field_entity_confirmed_fn": _is_field_entity_confirmed,
            "extract_user_message_fn": _extract_user_message,
            "normalize_intake_session_id_fn": normalize_intake_session_id_from_authority,
            "resolve_trace_id_fn": resolve_trace_id,
            "safe_session_id_fn": _safe_session_id,
        },
    )
    normalized_retrieved_knowledge = []
    if structured_retrieved_knowledge:
        normalized_retrieved_knowledge = [
            item for item in structured_retrieved_knowledge if isinstance(item, dict)
        ]
    return build_kernel_canonical_state_flow(
        req=req,
        command=command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        orchestration_status=orchestration_status,
        runtime_snapshot=runtime_snapshot,
        assistant_text=assistant_text,
        provider_status=provider_status,
        normalized_retrieved_knowledge=normalized_retrieved_knowledge,
        map_external_mode_fn=canonical_deps["map_external_mode_fn"],
        resolve_session_intent_stage_fn=canonical_deps["resolve_session_intent_stage_fn"],
        coerce_intent_escalation_policy_fn=canonical_deps["coerce_intent_escalation_policy_fn"],
        normalize_stage_status_fn=canonical_deps["normalize_stage_status_fn"],
        build_confirmed_fields_schema_fn=canonical_deps["build_confirmed_fields_schema_fn"],
        build_missing_fields_schema_fn=canonical_deps["build_missing_fields_schema_fn"],
        is_field_entity_confirmed_fn=canonical_deps["is_field_entity_confirmed_fn"],
        extract_user_message_fn=canonical_deps["extract_user_message_fn"],
        normalize_intake_session_id_fn=canonical_deps["normalize_intake_session_id_fn"],
        resolve_trace_id_fn=canonical_deps["resolve_trace_id_fn"],
        safe_session_id_fn=canonical_deps["safe_session_id_fn"],
    )


__all__ = ["build_kernel_canonical_state_flow", "_build_canonical_state"]
