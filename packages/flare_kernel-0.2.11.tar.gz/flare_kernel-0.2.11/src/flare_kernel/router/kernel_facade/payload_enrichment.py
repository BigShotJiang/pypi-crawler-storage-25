"""Payload-enrichment flow body for the kernel facade helper layer."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime import (
    load_intake_checkpoint,
    load_intake_session_snapshot,
    load_latest_intake_session_id,
    resolve_trace_id,
)
from flare_kernel.router.intake.answer import (
    normalize_field_value_payload as _normalize_field_value_payload,
)
from flare_kernel.router.intake.authority.core import (
    hydrate_payload_from_authoritative_checkpoint as hydrate_payload_from_authoritative_checkpoint_state,
    hydrate_payload_from_authoritative_intake_session as hydrate_payload_from_authoritative_intake_state,
    resolve_intake_session_id as resolve_intake_session_id_from_authority,
)
from flare_kernel.router.intake.canonicalization import (
    canonicalize_payload_fields as _canonicalize_payload_fields,
)
from flare_kernel.router.intake.entry_policy import (
    has_active_intake_payload as _has_active_intake_payload_from_router,
)
from flare_kernel.router.intake.extraction.core import (
    extract_intake_fields_from_message as _extract_intake_fields_from_message,
    is_intake_control_message as _is_intake_control_message,
    merge_inferred_requirements as _merge_inferred_requirements,
    merge_into_confirmed_fields as _merge_into_confirmed_fields,
    merge_supplementary_fields as _merge_supplementary_fields,
    normalize_extracted_field_values as _normalize_extracted_field_values,
)
from flare_kernel.router.intake.field_scope import (
    resolve_intake_allowed_fields as resolve_intake_allowed_fields_from_router,
)
from flare_kernel.router.intake.payload_updates import (
    apply_question_answer_payload as _apply_question_answer_payload,
    apply_workspace_patch_payload as _apply_workspace_patch_payload,
)
from flare_kernel.router.kernel_facade.dependency_resolution import (
    resolve_payload_enrichment_dependencies,
)
from flare_kernel.router.kernel_facade.domain_pack_payload import (
    merge_domain_pack_field_context,
)
from flare_kernel.router.kernel_facade.utils import (
    _kernel_attr,
    _safe_session_id,
)
from flare_kernel.router.payload.enrichment import (
    enrich_payload as enrich_payload_from_router,
)
from flare_kernel.router.kernel_request_pipeline.action import _resolve_command
from flare_kernel.router.mode.resolution import (
    resolve_current_mode as _resolve_current_mode_from_router,
    resolve_manual_mode as _resolve_manual_mode_from_router,
)
from flare_kernel.router.request.intent_resolution import (
    resolve_intent_override as _resolve_intent_override_from_router,
)
from flare_kernel.router.text_safety import extract_user_message as _extract_user_message


def enrich_kernel_payload_flow(
    *,
    req: KernelRequest,
    resolved_mode: str,
    retrieved_knowledge: list[dict[str, Any]] | None,
    resolve_command_fn: Callable[..., str],
    safe_session_id_fn: Callable[..., str],
    resolve_trace_id_fn: Callable[..., str],
    resolve_intake_session_id_fn: Callable[..., str],
    load_latest_intake_session_id_fn: Callable[..., str | None],
    load_intake_session_snapshot_fn: Callable[..., dict[str, Any] | None],
    hydrate_payload_from_authoritative_intake_state_fn: Callable[..., dict[str, Any]],
    load_intake_checkpoint_fn: Callable[..., Any],
    hydrate_payload_from_authoritative_checkpoint_state_fn: Callable[..., dict[str, Any]],
    has_active_intake_payload_fn: Callable[[dict[str, Any] | None], bool],
    normalize_field_value_payload_fn: Callable[..., Any],
    apply_question_answer_payload_fn: Callable[..., dict[str, Any]],
    apply_workspace_patch_payload_fn: Callable[..., dict[str, Any]],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    resolve_intake_allowed_fields_fn: Callable[..., set[str]],
    extract_intake_fields_from_message_fn: Callable[..., dict[str, Any]],
    normalize_extracted_field_values_fn: Callable[..., dict[str, Any]],
    merge_into_confirmed_fields_fn: Callable[..., dict[str, Any]],
    merge_supplementary_fields_fn: Callable[..., dict[str, Any]],
    merge_inferred_requirements_fn: Callable[..., dict[str, Any]],
    canonicalize_payload_fields_fn: Callable[..., dict[str, Any]],
    resolve_intent_override_fn: Callable[..., str],
    resolve_manual_mode_fn: Callable[..., str],
    resolve_current_mode_fn: Callable[..., str],
    is_intake_control_message_fn: Callable[[str], bool] | None = None,
) -> dict[str, Any]:
    """Run payload enrichment with fully resolved dependencies."""
    if resolved_mode == "requirement_intake":
        req = merge_domain_pack_field_context(req)
    return enrich_payload_from_router(
        req,
        resolved_mode=resolved_mode,
        retrieved_knowledge=retrieved_knowledge,
        resolve_command_fn=resolve_command_fn,
        safe_session_id_fn=safe_session_id_fn,
        resolve_trace_id_fn=resolve_trace_id_fn,
        resolve_intake_session_id_fn=resolve_intake_session_id_fn,
        load_latest_intake_session_id_fn=load_latest_intake_session_id_fn,
        load_intake_session_snapshot_fn=load_intake_session_snapshot_fn,
        hydrate_payload_from_authoritative_intake_state_fn=hydrate_payload_from_authoritative_intake_state_fn,
        load_intake_checkpoint_fn=load_intake_checkpoint_fn,
        hydrate_payload_from_authoritative_checkpoint_state_fn=hydrate_payload_from_authoritative_checkpoint_state_fn,
        has_active_intake_payload_fn=has_active_intake_payload_fn,
        normalize_field_value_payload_fn=normalize_field_value_payload_fn,
        apply_question_answer_payload_fn=apply_question_answer_payload_fn,
        apply_workspace_patch_payload_fn=apply_workspace_patch_payload_fn,
        extract_user_message_fn=extract_user_message_fn,
        resolve_intake_allowed_fields_fn=resolve_intake_allowed_fields_fn,
        extract_intake_fields_from_message_fn=extract_intake_fields_from_message_fn,
        normalize_extracted_field_values_fn=normalize_extracted_field_values_fn,
        merge_into_confirmed_fields_fn=merge_into_confirmed_fields_fn,
        merge_supplementary_fields_fn=merge_supplementary_fields_fn,
        merge_inferred_requirements_fn=merge_inferred_requirements_fn,
        canonicalize_payload_fields_fn=canonicalize_payload_fields_fn,
        resolve_intent_override_fn=resolve_intent_override_fn,
        resolve_manual_mode_fn=resolve_manual_mode_fn,
        resolve_current_mode_fn=resolve_current_mode_fn,
        is_intake_control_message_fn=is_intake_control_message_fn,
    )


def _enrich_payload(
    req: KernelRequest,
    *,
    resolved_mode: str,
    retrieved_knowledge: list[dict[str, Any]] | None = None,
    resolve_command_fn=None,
    safe_session_id_fn=None,
    resolve_trace_id_fn=None,
    resolve_intake_session_id_fn=None,
    load_latest_intake_session_id_fn=None,
    load_intake_session_snapshot_fn=None,
    hydrate_payload_from_authoritative_intake_state_fn=None,
    load_intake_checkpoint_fn=None,
    hydrate_payload_from_authoritative_checkpoint_state_fn=None,
    has_active_intake_payload_fn=None,
    normalize_field_value_payload_fn=None,
    apply_question_answer_payload_fn=None,
    apply_workspace_patch_payload_fn=None,
    extract_user_message_fn=None,
    resolve_intake_allowed_fields_fn=None,
    extract_intake_fields_from_message_fn=None,
    normalize_extracted_field_values_fn=None,
    merge_into_confirmed_fields_fn=None,
    merge_supplementary_fields_fn=None,
    merge_inferred_requirements_fn=None,
    canonicalize_payload_fields_fn=None,
    resolve_intent_override_fn=None,
    resolve_manual_mode_fn=None,
    resolve_current_mode_fn=None,
    is_intake_control_message_fn=None,
) -> dict[str, Any]:
    enrichment_deps = resolve_payload_enrichment_dependencies(
        resolve_command_fn=resolve_command_fn,
        safe_session_id_fn=safe_session_id_fn,
        resolve_trace_id_fn=resolve_trace_id_fn,
        resolve_intake_session_id_fn=resolve_intake_session_id_fn,
        load_latest_intake_session_id_fn=load_latest_intake_session_id_fn,
        load_intake_session_snapshot_fn=load_intake_session_snapshot_fn,
        hydrate_payload_from_authoritative_intake_state_fn=hydrate_payload_from_authoritative_intake_state_fn,
        load_intake_checkpoint_fn=load_intake_checkpoint_fn,
        hydrate_payload_from_authoritative_checkpoint_state_fn=hydrate_payload_from_authoritative_checkpoint_state_fn,
        has_active_intake_payload_fn=has_active_intake_payload_fn,
        normalize_field_value_payload_fn=normalize_field_value_payload_fn,
        apply_question_answer_payload_fn=apply_question_answer_payload_fn,
        apply_workspace_patch_payload_fn=apply_workspace_patch_payload_fn,
        extract_user_message_fn=extract_user_message_fn,
        resolve_intake_allowed_fields_fn=resolve_intake_allowed_fields_fn,
        extract_intake_fields_from_message_fn=extract_intake_fields_from_message_fn,
        normalize_extracted_field_values_fn=normalize_extracted_field_values_fn,
        merge_into_confirmed_fields_fn=merge_into_confirmed_fields_fn,
        merge_supplementary_fields_fn=merge_supplementary_fields_fn,
        merge_inferred_requirements_fn=merge_inferred_requirements_fn,
        canonicalize_payload_fields_fn=canonicalize_payload_fields_fn,
        resolve_intent_override_fn=resolve_intent_override_fn,
        resolve_manual_mode_fn=resolve_manual_mode_fn,
        resolve_current_mode_fn=resolve_current_mode_fn,
        kernel_attr_fn=_kernel_attr,
        defaults={
            "resolve_command_fn": _resolve_command,
            "safe_session_id_fn": _safe_session_id,
            "resolve_trace_id_fn": resolve_trace_id,
            "resolve_intake_session_id_fn": resolve_intake_session_id_from_authority,
            "load_latest_intake_session_id_fn": load_latest_intake_session_id,
            "load_intake_session_snapshot_fn": load_intake_session_snapshot,
            "hydrate_payload_from_authoritative_intake_state_fn": hydrate_payload_from_authoritative_intake_state,
            "load_intake_checkpoint_fn": load_intake_checkpoint,
            "hydrate_payload_from_authoritative_checkpoint_state_fn": hydrate_payload_from_authoritative_checkpoint_state,
            "has_active_intake_payload_fn": _has_active_intake_payload_from_router,
            "normalize_field_value_payload_fn": _normalize_field_value_payload,
            "apply_question_answer_payload_fn": _apply_question_answer_payload,
            "apply_workspace_patch_payload_fn": _apply_workspace_patch_payload,
            "extract_user_message_fn": _extract_user_message,
            "resolve_intake_allowed_fields_fn": resolve_intake_allowed_fields_from_router,
            "extract_intake_fields_from_message_fn": _extract_intake_fields_from_message,
            "normalize_extracted_field_values_fn": _normalize_extracted_field_values,
            "merge_into_confirmed_fields_fn": _merge_into_confirmed_fields,
            "merge_supplementary_fields_fn": _merge_supplementary_fields,
            "merge_inferred_requirements_fn": _merge_inferred_requirements,
            "canonicalize_payload_fields_fn": _canonicalize_payload_fields,
            "resolve_intent_override_fn": _resolve_intent_override_from_router,
            "resolve_manual_mode_fn": _resolve_manual_mode_from_router,
            "resolve_current_mode_fn": _resolve_current_mode_from_router,
        },
    )
    return enrich_kernel_payload_flow(
        req=req,
        resolved_mode=resolved_mode,
        retrieved_knowledge=retrieved_knowledge,
        resolve_command_fn=enrichment_deps["resolve_command_fn"],
        safe_session_id_fn=enrichment_deps["safe_session_id_fn"],
        resolve_trace_id_fn=enrichment_deps["resolve_trace_id_fn"],
        resolve_intake_session_id_fn=enrichment_deps["resolve_intake_session_id_fn"],
        load_latest_intake_session_id_fn=enrichment_deps["load_latest_intake_session_id_fn"],
        load_intake_session_snapshot_fn=enrichment_deps["load_intake_session_snapshot_fn"],
        hydrate_payload_from_authoritative_intake_state_fn=enrichment_deps["hydrate_payload_from_authoritative_intake_state_fn"],
        load_intake_checkpoint_fn=enrichment_deps["load_intake_checkpoint_fn"],
        hydrate_payload_from_authoritative_checkpoint_state_fn=enrichment_deps["hydrate_payload_from_authoritative_checkpoint_state_fn"],
        has_active_intake_payload_fn=enrichment_deps["has_active_intake_payload_fn"],
        normalize_field_value_payload_fn=enrichment_deps["normalize_field_value_payload_fn"],
        apply_question_answer_payload_fn=enrichment_deps["apply_question_answer_payload_fn"],
        apply_workspace_patch_payload_fn=enrichment_deps["apply_workspace_patch_payload_fn"],
        extract_user_message_fn=enrichment_deps["extract_user_message_fn"],
        resolve_intake_allowed_fields_fn=enrichment_deps["resolve_intake_allowed_fields_fn"],
        extract_intake_fields_from_message_fn=enrichment_deps["extract_intake_fields_from_message_fn"],
        normalize_extracted_field_values_fn=enrichment_deps["normalize_extracted_field_values_fn"],
        merge_into_confirmed_fields_fn=enrichment_deps["merge_into_confirmed_fields_fn"],
        merge_supplementary_fields_fn=enrichment_deps["merge_supplementary_fields_fn"],
        merge_inferred_requirements_fn=enrichment_deps["merge_inferred_requirements_fn"],
        canonicalize_payload_fields_fn=enrichment_deps["canonicalize_payload_fields_fn"],
        resolve_intent_override_fn=enrichment_deps["resolve_intent_override_fn"],
        resolve_manual_mode_fn=enrichment_deps["resolve_manual_mode_fn"],
        resolve_current_mode_fn=enrichment_deps["resolve_current_mode_fn"],
        is_intake_control_message_fn=is_intake_control_message_fn or _is_intake_control_message,
    )


__all__ = ["enrich_kernel_payload_flow", "_enrich_payload"]
