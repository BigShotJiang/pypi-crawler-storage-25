"""Turn-context assembly flow for the kernel facade helper layer."""

from __future__ import annotations

import os
from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.context.sourcing_preview import maybe_append_sourcing_preview_rows
from flare_kernel.router.prompting.summary_contract import apply_prompt_summary_contract
from flare_kernel.router.payload.enrichment import extract_source_ids_from_payload
from flare_kernel.router.response_intent import resolve_response_intent
from flare_kernel.runtime.orchestration.structured_reasoning import generate_structured_reasoning


def _structured_reasoning_enabled() -> bool:
    # TEMPORARY STABILITY GATE — GOV-07 follow-up.
    # Keep provider-backed structured reasoning disabled by default while
    # qwen3.5-plus latency/quota is unstable. Re-enable through explicit env
    # once provider router/fallback/phase-timeout work lands.
    raw = str(os.getenv("STRUCTURED_REASONING_ENABLED") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _has_question_answer(payload: dict[str, Any]) -> bool:
    question_answer = payload.get("question_answer")
    if not isinstance(question_answer, dict):
        return False
    field_key = str(question_answer.get("field_key") or "").strip()
    field_value = str(
        question_answer.get("raw_value")
        or question_answer.get("field_value")
        or question_answer.get("selected_option_value")
        or ""
    ).strip()
    return bool(field_key and field_value)


async def prepare_kernel_turn_context_flow(
    *,
    req: KernelRequest,
    resolve_trace_id_fn: Callable[[str | None], str],
    resolve_command_fn: Callable[[KernelRequest], str],
    safe_session_id_fn: Callable[[Any], str],
    load_instance_profile_fn: Callable[[str | None], dict[str, Any] | None],
    resolve_intent_escalation_policy_with_source_fn: Callable[..., tuple[dict[str, Any], str]],
    resolve_request_intent_with_ai_fn: Callable[..., Any],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    build_intent_and_escalation_signal_fn: Callable[..., dict[str, Any]],
    resolve_request_mode_fn: Callable[..., tuple[str, str]],
    apply_escalation_mode_override_fn: Callable[..., tuple[str, str, float, str, str, str]],
    resolve_project_id_fn: Callable[..., str | None],
    resolve_user_id_fn: Callable[..., str | None],
    resolve_retrieval_config_fn: Callable[..., dict[str, Any]],
    build_retrieval_queries_fn: Callable[..., list[str]],
    search_knowledge_by_queries_fn: Callable[..., list[dict[str, Any]]],
    enrich_payload_fn: Callable[..., dict[str, Any]],
    build_kernel_runtime_fn: Callable[..., dict[str, Any]],
    build_orchestration_status_fn: Callable[..., dict[str, Any]],
    merge_intent_and_escalation_signal_fn: Callable[..., dict[str, Any]],
    resolve_effective_command_fn: Callable[..., str],
    build_structured_search_results_fn: Callable[..., list[dict[str, Any]]],
    generate_llm_completion_fn: Callable[..., Any] | None = None,
    search_web_sources_fn: Callable[..., list[dict[str, Any]]] | None = None,
    resolve_analysis_route_fn: Callable[..., dict[str, Any]] | None = None,
    build_project_memory_context_layer_fn: Callable[..., dict[str, Any]] | None = None,
    run_sourcing_search_fn: Callable[..., dict[str, Any]] | None = None,
    search_knowledge_records_fn: Callable[..., list[dict[str, Any]]] | None = None,
    persist_sourcing_run_bundle_fn: Callable[..., dict[str, Any]] | None = None,
    search_instance_records_fn: Callable[..., Any] | None = None,
    run_structured_reasoning: bool = True,
) -> dict[str, Any]:
    """Assemble the turn context consumed by kernel run/action/stream handlers."""
    trace_id = resolve_trace_id_fn(req.trace_id)
    command = resolve_command_fn(req)
    session_id = safe_session_id_fn(req.session_id)
    instance_profile = load_instance_profile_fn(req.instance_id)
    intent_escalation_policy, intent_escalation_policy_source = resolve_intent_escalation_policy_with_source_fn(req=req)
    resolved_intent, intent_source, intent_confidence, intent_reason = await resolve_request_intent_with_ai_fn(req, trace_id)
    raw_message = extract_user_message_fn(req.payload)

    pre_escalation_signal = build_intent_and_escalation_signal_fn(
        req=req,
        command=command,
        message=raw_message,
        resolved_intent=resolved_intent,
        resolved_mode="default",
        mode_source="pre_routing",
    )
    resolved_mode, mode_source = resolve_request_mode_fn(req, resolved_intent)
    (
        resolved_intent,
        intent_source,
        intent_confidence,
        intent_reason,
        resolved_mode,
        mode_source,
    ) = apply_escalation_mode_override_fn(
        command=command,
        resolved_intent=resolved_intent,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        escalation_signal=pre_escalation_signal,
        intent_escalation_policy=intent_escalation_policy,
    )

    payload = req.payload if isinstance(req.payload, dict) else {}
    project_id = resolve_project_id_fn(req, payload)
    user_id = resolve_user_id_fn(req, payload)
    retrieval_config = resolve_retrieval_config_fn(req, payload)
    ref_payload = dict(payload)
    if isinstance(req.context_refs, list) and req.context_refs:
        ref_payload["context_refs"] = list(req.context_refs)
    if isinstance(req.knowledge_refs, list) and req.knowledge_refs:
        ref_payload["knowledge_refs"] = list(req.knowledge_refs)
    source_ids = extract_source_ids_from_payload(ref_payload)
    retrieval_queries = build_retrieval_queries_fn(req, message=raw_message, instance_profile=instance_profile)
    if not retrieval_queries and str(raw_message or "").strip():
        retrieval_queries = [str(raw_message).strip()]
    retrieval_attempted = bool(project_id and user_id and retrieval_config["enabled"] and retrieval_queries)
    retrieved_knowledge: list[dict[str, Any]] = []
    if retrieval_attempted:
        retrieved_knowledge = search_knowledge_by_queries_fn(
            trace_id=trace_id,
            project_id=project_id,
            user_id=user_id,
            queries=retrieval_queries,
            top_k=retrieval_config["top_k"],
            min_score=retrieval_config["min_score"],
            source_ids=source_ids or None,
        )
    retrieved_knowledge = maybe_append_sourcing_preview_rows(
        retrieved_knowledge=retrieved_knowledge,
        resolved_mode=resolved_mode,
        raw_message=raw_message,
        retrieval_top_k=int(retrieval_config.get("top_k") or 0),
        trace_id=trace_id,
        session_id=session_id,
        project_id=str(project_id or ""),
        user_id=str(user_id or ""),
        search_web_sources_fn=search_web_sources_fn,
    )

    if callable(resolve_analysis_route_fn):
        analysis_route = resolve_analysis_route_fn(
            message=raw_message,
            intent=resolved_intent,
            command=command,
            mode=resolved_mode,
            payload=payload,
            retrieval_hit_count=len(retrieved_knowledge),
        )
    else:
        analysis_route = {
            "analysis_type": "requirement",
            "template_id": "",
            "reason_codes": ["ROUTE_SIGNAL_DEFAULT"],
            "confidence": 0.0,
        }

    project_memory_recall = {}
    if callable(build_project_memory_context_layer_fn):
        project_memory_recall = build_project_memory_context_layer_fn(
            project_id=project_id,
            user_id=user_id,
            query=raw_message,
        )

    enriched_payload = enrich_payload_fn(req, resolved_mode=resolved_mode, retrieved_knowledge=retrieved_knowledge)
    if isinstance(enriched_payload, dict):
        enriched_payload["response_intent_result"] = resolve_response_intent(
            message=raw_message,
            payload=enriched_payload,
            resolved_mode=resolved_mode,
            command=command,
        )
        if isinstance(project_memory_recall, dict) and project_memory_recall:
            enriched_payload["project_memory_recall"] = project_memory_recall
        enriched_payload["analysis_route"] = analysis_route
        should_skip_structured_reasoning = (not run_structured_reasoning) or not _structured_reasoning_enabled() or (
            command == "submit_intake_answer"
            and _has_question_answer(enriched_payload)
        )
        if not should_skip_structured_reasoning:
            structured_reasoning = await generate_structured_reasoning(
                trace_id=trace_id,
                session_id=session_id,
                message=raw_message,
                mode_key=resolved_mode,
                payload=enriched_payload,
                retrieved_knowledge=retrieved_knowledge,
                instance_profile=instance_profile,
                generate_llm_completion_fn=generate_llm_completion_fn,
            )
            if structured_reasoning:
                enriched_payload["structured_reasoning"] = structured_reasoning
    runtime_snapshot = build_kernel_runtime_fn(
        trace_id=trace_id,
        tenant_id=req.tenant_id,
        instance_id=req.instance_id,
        domain_pack_version=req.domain_pack_version,
        session_id=session_id,
        intent=resolved_intent,
        payload=enriched_payload,
        instance_profile=instance_profile,
        run_sourcing_search_fn=run_sourcing_search_fn,
        search_knowledge_records_fn=search_knowledge_records_fn,
        search_web_sources_fn=search_web_sources_fn,
        search_instance_records_fn=search_instance_records_fn,
        persist_sourcing_run_bundle_fn=persist_sourcing_run_bundle_fn,
    )
    if isinstance(enriched_payload, dict):
        enriched_payload["session_context"] = runtime_snapshot.get("session_context", {})
        enriched_payload["track_result"] = runtime_snapshot.get("track_result", {})
        enriched_payload["response_strategy_result"] = runtime_snapshot.get("response_strategy_result", {})
        enriched_payload["artifact_template_result"] = runtime_snapshot.get("artifact_template_result", {})
        apply_prompt_summary_contract(payload=enriched_payload, runtime_snapshot=runtime_snapshot)
    orchestration_status = build_orchestration_status_fn(
        trace_id=trace_id,
        command=command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        runtime_snapshot=runtime_snapshot,
        raw_message=raw_message,
        retrieval_attempted=retrieval_attempted,
        retrieval_queries=retrieval_queries,
        retrieved_knowledge=retrieved_knowledge,
        intent_escalation_policy=intent_escalation_policy,
        intent_escalation_policy_source=intent_escalation_policy_source,
        analysis_route=analysis_route,
    )
    if isinstance(orchestration_status, dict):
        orchestration_status["analysis_route"] = analysis_route
    escalation_signal = build_intent_and_escalation_signal_fn(
        req=req,
        command=command,
        message=raw_message,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
    )
    orchestration_status = merge_intent_and_escalation_signal_fn(
        orchestration_status=orchestration_status,
        signal=escalation_signal,
    )
    effective_command = resolve_effective_command_fn(
        command=command,
        resolved_mode=resolved_mode,
        orchestration_status=orchestration_status,
        message=raw_message,
    )
    structured_retrieved_knowledge = build_structured_search_results_fn(
        results=retrieved_knowledge,
        open_fields=orchestration_status.get("open_fields") if isinstance(orchestration_status.get("open_fields"), list) else [],
    )

    return {
        "trace_id": trace_id,
        "command": command,
        "session_id": session_id,
        "instance_profile": instance_profile,
        "intent_escalation_policy": intent_escalation_policy,
        "intent_escalation_policy_source": intent_escalation_policy_source,
        "resolved_intent": resolved_intent,
        "intent_source": intent_source,
        "intent_confidence": intent_confidence,
        "intent_reason": intent_reason,
        "raw_message": raw_message,
        "resolved_mode": resolved_mode,
        "mode_source": mode_source,
        "project_id": project_id,
        "user_id": user_id,
        "retrieval_config": retrieval_config,
        "retrieval_queries": retrieval_queries,
        "retrieval_attempted": retrieval_attempted,
        "retrieved_knowledge": retrieved_knowledge,
        "enriched_payload": enriched_payload,
        "runtime_snapshot": runtime_snapshot,
        "orchestration_status": orchestration_status,
        "escalation_signal": escalation_signal,
        "effective_command": effective_command,
        "structured_retrieved_knowledge": structured_retrieved_knowledge,
        "analysis_route": analysis_route,
        "project_memory_recall": project_memory_recall,
    }


__all__ = ["prepare_kernel_turn_context_flow"]
