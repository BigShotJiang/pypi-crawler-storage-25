"""Dependency-resolution helpers for kernel facade wrappers.

These helpers centralize fallback wiring (`kernel` monkeypatch override first,
module-local default second) so facade functions can focus on flow sequencing.
"""

from __future__ import annotations

from typing import Any, Callable


def resolve_canonical_state_dependencies(
    *,
    map_external_mode_fn: Any,
    resolve_session_intent_stage_fn: Any,
    coerce_intent_escalation_policy_fn: Any,
    normalize_stage_status_fn: Any,
    build_confirmed_fields_schema_fn: Any,
    build_missing_fields_schema_fn: Any,
    is_field_entity_confirmed_fn: Any,
    extract_user_message_fn: Any,
    normalize_intake_session_id_fn: Any,
    resolve_trace_id_fn: Any,
    safe_session_id_fn: Any,
    kernel_attr_fn: Callable[[str, Any], Any],
    defaults: dict[str, Any],
) -> dict[str, Any]:
    """Resolve canonical-state dependency callables with kernel override precedence."""
    return {
        "map_external_mode_fn": map_external_mode_fn
        or kernel_attr_fn("_map_external_mode", defaults["map_external_mode_fn"]),
        "resolve_session_intent_stage_fn": resolve_session_intent_stage_fn
        or kernel_attr_fn("_resolve_session_intent_stage", defaults["resolve_session_intent_stage_fn"]),
        "coerce_intent_escalation_policy_fn": coerce_intent_escalation_policy_fn
        or kernel_attr_fn("_coerce_intent_escalation_policy", defaults["coerce_intent_escalation_policy_fn"]),
        "normalize_stage_status_fn": normalize_stage_status_fn
        or kernel_attr_fn("_normalize_stage_status", defaults["normalize_stage_status_fn"]),
        "build_confirmed_fields_schema_fn": build_confirmed_fields_schema_fn
        or kernel_attr_fn("_build_confirmed_fields_schema", defaults["build_confirmed_fields_schema_fn"]),
        "build_missing_fields_schema_fn": build_missing_fields_schema_fn
        or kernel_attr_fn("_build_missing_fields_schema", defaults["build_missing_fields_schema_fn"]),
        "is_field_entity_confirmed_fn": is_field_entity_confirmed_fn
        or kernel_attr_fn("_is_field_entity_confirmed", defaults["is_field_entity_confirmed_fn"]),
        "extract_user_message_fn": extract_user_message_fn
        or kernel_attr_fn("_extract_user_message", defaults["extract_user_message_fn"]),
        "normalize_intake_session_id_fn": normalize_intake_session_id_fn
        or kernel_attr_fn("normalize_intake_session_id_from_authority", defaults["normalize_intake_session_id_fn"]),
        "resolve_trace_id_fn": resolve_trace_id_fn
        or kernel_attr_fn("resolve_trace_id", defaults["resolve_trace_id_fn"]),
        "safe_session_id_fn": safe_session_id_fn
        or kernel_attr_fn("_safe_session_id", defaults["safe_session_id_fn"]),
    }


def resolve_payload_enrichment_dependencies(
    *,
    resolve_command_fn: Any,
    safe_session_id_fn: Any,
    resolve_trace_id_fn: Any,
    resolve_intake_session_id_fn: Any,
    load_latest_intake_session_id_fn: Any,
    load_intake_session_snapshot_fn: Any,
    hydrate_payload_from_authoritative_intake_state_fn: Any,
    load_intake_checkpoint_fn: Any,
    hydrate_payload_from_authoritative_checkpoint_state_fn: Any,
    has_active_intake_payload_fn: Any,
    normalize_field_value_payload_fn: Any,
    apply_question_answer_payload_fn: Any,
    apply_workspace_patch_payload_fn: Any,
    extract_user_message_fn: Any,
    resolve_intake_allowed_fields_fn: Any,
    extract_intake_fields_from_message_fn: Any,
    normalize_extracted_field_values_fn: Any,
    merge_into_confirmed_fields_fn: Any,
    merge_supplementary_fields_fn: Any,
    merge_inferred_requirements_fn: Any,
    canonicalize_payload_fields_fn: Any,
    resolve_intent_override_fn: Any,
    resolve_manual_mode_fn: Any,
    resolve_current_mode_fn: Any,
    kernel_attr_fn: Callable[[str, Any], Any],
    defaults: dict[str, Any],
) -> dict[str, Any]:
    """Resolve payload-enrichment dependency callables with kernel override precedence."""
    return {
        "resolve_command_fn": resolve_command_fn or kernel_attr_fn("_resolve_command", defaults["resolve_command_fn"]),
        "safe_session_id_fn": safe_session_id_fn or kernel_attr_fn("_safe_session_id", defaults["safe_session_id_fn"]),
        "resolve_trace_id_fn": resolve_trace_id_fn or kernel_attr_fn("resolve_trace_id", defaults["resolve_trace_id_fn"]),
        "resolve_intake_session_id_fn": resolve_intake_session_id_fn
        or kernel_attr_fn("resolve_intake_session_id_from_authority", defaults["resolve_intake_session_id_fn"]),
        "load_latest_intake_session_id_fn": load_latest_intake_session_id_fn
        or kernel_attr_fn("load_latest_intake_session_id", defaults["load_latest_intake_session_id_fn"]),
        "load_intake_session_snapshot_fn": load_intake_session_snapshot_fn
        or kernel_attr_fn("load_intake_session_snapshot", defaults["load_intake_session_snapshot_fn"]),
        "hydrate_payload_from_authoritative_intake_state_fn": hydrate_payload_from_authoritative_intake_state_fn
        or kernel_attr_fn("hydrate_payload_from_authoritative_intake_state", defaults["hydrate_payload_from_authoritative_intake_state_fn"]),
        "load_intake_checkpoint_fn": load_intake_checkpoint_fn
        or kernel_attr_fn("load_intake_checkpoint", defaults["load_intake_checkpoint_fn"]),
        "hydrate_payload_from_authoritative_checkpoint_state_fn": hydrate_payload_from_authoritative_checkpoint_state_fn
        or kernel_attr_fn("hydrate_payload_from_authoritative_checkpoint_state", defaults["hydrate_payload_from_authoritative_checkpoint_state_fn"]),
        "has_active_intake_payload_fn": has_active_intake_payload_fn
        or kernel_attr_fn("_has_active_intake_payload", defaults["has_active_intake_payload_fn"]),
        "normalize_field_value_payload_fn": normalize_field_value_payload_fn
        or kernel_attr_fn("_normalize_field_value_payload", defaults["normalize_field_value_payload_fn"]),
        "apply_question_answer_payload_fn": apply_question_answer_payload_fn
        or kernel_attr_fn("_apply_question_answer_payload", defaults["apply_question_answer_payload_fn"]),
        "apply_workspace_patch_payload_fn": apply_workspace_patch_payload_fn
        or kernel_attr_fn("_apply_workspace_patch_payload", defaults["apply_workspace_patch_payload_fn"]),
        "extract_user_message_fn": extract_user_message_fn
        or kernel_attr_fn("_extract_user_message", defaults["extract_user_message_fn"]),
        "resolve_intake_allowed_fields_fn": resolve_intake_allowed_fields_fn
        or kernel_attr_fn("resolve_intake_allowed_fields_from_router", defaults["resolve_intake_allowed_fields_fn"]),
        "extract_intake_fields_from_message_fn": extract_intake_fields_from_message_fn
        or kernel_attr_fn("_extract_intake_fields_from_message", defaults["extract_intake_fields_from_message_fn"]),
        "normalize_extracted_field_values_fn": normalize_extracted_field_values_fn
        or kernel_attr_fn("_normalize_extracted_field_values", defaults["normalize_extracted_field_values_fn"]),
        "merge_into_confirmed_fields_fn": merge_into_confirmed_fields_fn
        or kernel_attr_fn("_merge_into_confirmed_fields", defaults["merge_into_confirmed_fields_fn"]),
        "merge_supplementary_fields_fn": merge_supplementary_fields_fn
        or kernel_attr_fn("_merge_supplementary_fields", defaults["merge_supplementary_fields_fn"]),
        "merge_inferred_requirements_fn": merge_inferred_requirements_fn
        or kernel_attr_fn("_merge_inferred_requirements", defaults["merge_inferred_requirements_fn"]),
        "canonicalize_payload_fields_fn": canonicalize_payload_fields_fn
        or kernel_attr_fn("_canonicalize_payload_fields", defaults["canonicalize_payload_fields_fn"]),
        "resolve_intent_override_fn": resolve_intent_override_fn
        or kernel_attr_fn("_resolve_intent_override", defaults["resolve_intent_override_fn"]),
        "resolve_manual_mode_fn": resolve_manual_mode_fn
        or kernel_attr_fn("_resolve_manual_mode", defaults["resolve_manual_mode_fn"]),
        "resolve_current_mode_fn": resolve_current_mode_fn
        or kernel_attr_fn("_resolve_current_mode", defaults["resolve_current_mode_fn"]),
    }


def resolve_turn_context_dependencies(
    *,
    resolve_trace_id_fn: Any,
    resolve_command_fn: Any,
    safe_session_id_fn: Any,
    load_instance_profile_fn: Any,
    resolve_intent_escalation_policy_with_source_fn: Any,
    resolve_request_intent_with_ai_fn: Any,
    extract_user_message_fn: Any,
    build_intent_and_escalation_signal_fn: Any,
    resolve_request_mode_fn: Any,
    apply_escalation_mode_override_fn: Any,
    resolve_project_id_fn: Any,
    resolve_user_id_fn: Any,
    resolve_retrieval_config_fn: Any,
    build_retrieval_queries_fn: Any,
    search_knowledge_by_queries_fn: Any,
    enrich_payload_fn: Any,
    build_kernel_runtime_fn: Any,
    build_orchestration_status_fn: Any,
    merge_intent_and_escalation_signal_fn: Any,
    resolve_effective_command_fn: Any,
    build_structured_search_results_fn: Any,
    generate_llm_completion_fn: Any,
    resolve_analysis_route_fn: Any,
    build_project_memory_context_layer_fn: Any,
    run_sourcing_search_fn: Any,
    search_knowledge_records_fn: Any,
    search_web_sources_fn: Any,
    search_instance_records_fn: Any,
    persist_sourcing_run_bundle_fn: Any,
    kernel_attr_fn: Callable[[str, Any], Any],
    defaults: dict[str, Any],
) -> dict[str, Any]:
    """Resolve turn-context dependency callables with kernel override precedence."""
    return {
        "resolve_trace_id_fn": resolve_trace_id_fn or kernel_attr_fn("resolve_trace_id", defaults["resolve_trace_id_fn"]),
        "resolve_command_fn": resolve_command_fn or kernel_attr_fn("_resolve_command", defaults["resolve_command_fn"]),
        "safe_session_id_fn": safe_session_id_fn or kernel_attr_fn("_safe_session_id", defaults["safe_session_id_fn"]),
        "load_instance_profile_fn": load_instance_profile_fn or kernel_attr_fn("load_instance_profile", defaults["load_instance_profile_fn"]),
        "resolve_intent_escalation_policy_with_source_fn": resolve_intent_escalation_policy_with_source_fn
        or kernel_attr_fn("_resolve_intent_escalation_policy_with_source", defaults["resolve_intent_escalation_policy_with_source_fn"]),
        "resolve_request_intent_with_ai_fn": resolve_request_intent_with_ai_fn
        or kernel_attr_fn("_resolve_request_intent_with_ai", defaults["resolve_request_intent_with_ai_fn"]),
        "extract_user_message_fn": extract_user_message_fn
        or kernel_attr_fn("_extract_user_message", defaults["extract_user_message_fn"]),
        "build_intent_and_escalation_signal_fn": build_intent_and_escalation_signal_fn
        or kernel_attr_fn("_build_intent_and_escalation_signal", defaults["build_intent_and_escalation_signal_fn"]),
        "resolve_request_mode_fn": resolve_request_mode_fn
        or kernel_attr_fn("_resolve_request_mode", defaults["resolve_request_mode_fn"]),
        "apply_escalation_mode_override_fn": apply_escalation_mode_override_fn
        or kernel_attr_fn("_apply_escalation_mode_override", defaults["apply_escalation_mode_override_fn"]),
        "resolve_project_id_fn": resolve_project_id_fn
        or kernel_attr_fn("resolve_project_id_from_router", defaults["resolve_project_id_fn"]),
        "resolve_user_id_fn": resolve_user_id_fn
        or kernel_attr_fn("resolve_user_id_from_router", defaults["resolve_user_id_fn"]),
        "resolve_retrieval_config_fn": resolve_retrieval_config_fn
        or kernel_attr_fn("resolve_retrieval_config_from_router", defaults["resolve_retrieval_config_fn"]),
        "build_retrieval_queries_fn": build_retrieval_queries_fn
        or kernel_attr_fn("_build_retrieval_queries", defaults["build_retrieval_queries_fn"]),
        "search_knowledge_by_queries_fn": search_knowledge_by_queries_fn
        or kernel_attr_fn("_search_knowledge_by_queries", defaults["search_knowledge_by_queries_fn"]),
        "enrich_payload_fn": enrich_payload_fn or kernel_attr_fn("_enrich_payload", defaults["enrich_payload_fn"]),
        "build_kernel_runtime_fn": build_kernel_runtime_fn
        or kernel_attr_fn("build_kernel_runtime", defaults["build_kernel_runtime_fn"]),
        "build_orchestration_status_fn": build_orchestration_status_fn
        or kernel_attr_fn("_build_orchestration_status", defaults["build_orchestration_status_fn"]),
        "merge_intent_and_escalation_signal_fn": merge_intent_and_escalation_signal_fn
        or kernel_attr_fn("_merge_intent_and_escalation_signal", defaults["merge_intent_and_escalation_signal_fn"]),
        "resolve_effective_command_fn": resolve_effective_command_fn
        or kernel_attr_fn("_resolve_effective_command", defaults["resolve_effective_command_fn"]),
        "build_structured_search_results_fn": build_structured_search_results_fn
        or kernel_attr_fn("build_structured_search_results_from_intake_status", defaults["build_structured_search_results_fn"]),
        "generate_llm_completion_fn": generate_llm_completion_fn
        or kernel_attr_fn("generate_llm_completion", defaults["generate_llm_completion_fn"]),
        "resolve_analysis_route_fn": resolve_analysis_route_fn
        or kernel_attr_fn("resolve_analysis_route_from_runtime", defaults["resolve_analysis_route_fn"]),
        "build_project_memory_context_layer_fn": build_project_memory_context_layer_fn
        or kernel_attr_fn("build_project_memory_context_layer", defaults["build_project_memory_context_layer_fn"]),
        "run_sourcing_search_fn": run_sourcing_search_fn
        or kernel_attr_fn("run_sourcing_search", defaults["run_sourcing_search_fn"]),
        "search_knowledge_records_fn": search_knowledge_records_fn
        or kernel_attr_fn("search_knowledge_records", defaults["search_knowledge_records_fn"]),
        "search_web_sources_fn": search_web_sources_fn
        or kernel_attr_fn("search_web_sources", defaults["search_web_sources_fn"]),
        "search_instance_records_fn": search_instance_records_fn
        or kernel_attr_fn("search_instance_records", defaults["search_instance_records_fn"]),
        "persist_sourcing_run_bundle_fn": persist_sourcing_run_bundle_fn
        or kernel_attr_fn("persist_sourcing_run_bundle", defaults["persist_sourcing_run_bundle_fn"]),
    }


__all__ = [
    "resolve_canonical_state_dependencies",
    "resolve_payload_enrichment_dependencies",
    "resolve_orchestration_dependencies",
    "resolve_persistence_dependencies",
    "resolve_prompt_dependencies",
    "resolve_turn_context_dependencies",
]


def resolve_orchestration_dependencies(
    *,
    resolve_requirement_intake_entry_recommendation_fn: Any,
    resolve_session_intent_stage_fn: Any,
    coerce_intent_escalation_policy_fn: Any,
    extract_user_message_fn: Any,
    kernel_attr_fn: Callable[[str, Any], Any],
    defaults: dict[str, Any],
) -> dict[str, Any]:
    """Resolve orchestration-status dependency callables."""
    return {
        "resolve_requirement_intake_entry_recommendation_fn": resolve_requirement_intake_entry_recommendation_fn
        or kernel_attr_fn(
            "_resolve_requirement_intake_entry_recommendation",
            defaults["resolve_requirement_intake_entry_recommendation_fn"],
        ),
        "resolve_session_intent_stage_fn": resolve_session_intent_stage_fn
        or kernel_attr_fn("_resolve_session_intent_stage", defaults["resolve_session_intent_stage_fn"]),
        "coerce_intent_escalation_policy_fn": coerce_intent_escalation_policy_fn
        or kernel_attr_fn("_coerce_intent_escalation_policy", defaults["coerce_intent_escalation_policy_fn"]),
        "extract_user_message_fn": extract_user_message_fn
        or kernel_attr_fn("_extract_user_message", defaults["extract_user_message_fn"]),
    }


def resolve_persistence_dependencies(
    *,
    persist_intake_session_state_fn: Any,
    persist_intake_checkpoint_fn: Any,
    kernel_attr_fn: Callable[[str, Any], Any],
    defaults: dict[str, Any],
) -> dict[str, Any]:
    """Resolve persistence dependency callables."""
    return {
        "persist_intake_session_state_fn": persist_intake_session_state_fn
        or kernel_attr_fn("persist_intake_session_state", defaults["persist_intake_session_state_fn"]),
        "persist_intake_checkpoint_fn": persist_intake_checkpoint_fn
        or kernel_attr_fn("persist_intake_checkpoint", defaults["persist_intake_checkpoint_fn"]),
    }


def resolve_prompt_dependencies(
    *,
    resolve_command_fn: Any,
    extract_user_message_fn: Any,
    sanitize_product_name_for_prompt_fn: Any,
    extract_quoted_terms_fn: Any,
    kernel_attr_fn: Callable[[str, Any], Any],
    defaults: dict[str, Any],
) -> dict[str, Any]:
    """Resolve prompt-building dependency callables."""
    return {
        "resolve_command_fn": resolve_command_fn
        or kernel_attr_fn("_resolve_command", defaults["resolve_command_fn"]),
        "extract_user_message_fn": extract_user_message_fn
        or kernel_attr_fn("_extract_user_message", defaults["extract_user_message_fn"]),
        "sanitize_product_name_for_prompt_fn": sanitize_product_name_for_prompt_fn
        or kernel_attr_fn("_sanitize_product_name_for_prompt", defaults["sanitize_product_name_for_prompt_fn"]),
        "extract_quoted_terms_fn": extract_quoted_terms_fn
        or kernel_attr_fn("_extract_quoted_terms", defaults["extract_quoted_terms_fn"]),
    }
