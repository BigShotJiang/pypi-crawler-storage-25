"""Domain-pack field context injection for kernel payload enrichment."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.domain.domain_pack_loader import load_domain_pack


def _copy_list(value: Any) -> list[Any]:
    return list(value) if isinstance(value, list) else []


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _should_skip_field_list(payload: dict[str, Any], key: str) -> bool:
    if isinstance(payload.get(key), list):
        return True
    if key == "required_fields" and isinstance(payload.get("required_missing"), list):
        return True
    return False


def _compact_template_sections(raw_sections: Any) -> list[dict[str, str]]:
    sections = raw_sections if isinstance(raw_sections, list) else []
    compacted: list[dict[str, str]] = []
    for section in sections:
        if not isinstance(section, dict):
            continue
        compacted.append(
            {
                "key": _clean_text(section.get("key")),
                "label": _clean_text(section.get("label")),
                "instruction": _clean_text(section.get("instruction")),
            }
        )
    return compacted


def _compact_artifact_template_context(workflow: Any) -> list[dict[str, Any]]:
    workflow_raw = workflow.raw if hasattr(workflow, "raw") else workflow
    templates = workflow_raw.get("artifact_templates") if isinstance(workflow_raw, dict) else {}
    if not isinstance(templates, dict):
        return []
    compacted: list[dict[str, Any]] = []
    for key, config in templates.items():
        if str(key or "").startswith("_") or not isinstance(config, dict):
            continue
        compacted.append(
            {
                "artifact_type": _clean_text(key),
                "template": _clean_text(config.get("template")),
                "sections": _compact_template_sections(config.get("sections")),
            }
        )
    return compacted


def merge_domain_pack_field_context(req: KernelRequest) -> KernelRequest:
    """Attach domain-pack field contracts before intake extraction runs."""
    payload = dict(req.payload) if isinstance(req.payload, dict) else {}
    pack = load_domain_pack(
        instance_id=req.instance_id,
        domain_pack_version=req.domain_pack_version,
        domain=str(payload.get("domain_pack_domain") or payload.get("domain") or "").strip() or None,
        payload=payload,
        tenant_id=req.tenant_id,
    )
    pack_fields = pack.fields if isinstance(pack.fields, dict) else {}
    if not isinstance(payload.get("field_definitions"), list):
        definitions = _copy_list(pack_fields.get("field_definitions"))
        if definitions:
            payload["field_definitions"] = definitions
    for key in ("required_fields", "recommended_fields", "optional_fields"):
        if _should_skip_field_list(payload, key):
            continue
        values = _copy_list(pack_fields.get(key))
        if values:
            payload[key] = values
    if (
        not isinstance(payload.get("field_semantics"), dict)
        and isinstance(pack_fields.get("field_semantics"), dict)
    ):
        payload["field_semantics"] = dict(pack_fields.get("field_semantics") or {})
    if not isinstance(payload.get("artifact_template_context"), list):
        artifact_template_context = _compact_artifact_template_context(pack.workflow)
        if artifact_template_context:
            payload["artifact_template_context"] = artifact_template_context
    return req.model_copy(update={"payload": payload})


__all__ = ["merge_domain_pack_field_context"]
