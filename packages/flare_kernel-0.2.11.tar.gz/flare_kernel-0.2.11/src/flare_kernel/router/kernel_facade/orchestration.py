"""Orchestration/persistence/prompt flow bodies for kernel facade helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime import persist_intake_checkpoint, persist_intake_session_state
from flare_kernel.router.intake.entry_policy import (
    resolve_requirement_intake_entry_recommendation as _resolve_requirement_intake_entry_recommendation_from_router,
)
from flare_kernel.router.intake.payload_updates import (
    extract_quoted_terms as _extract_quoted_terms,
)
from flare_kernel.router.intake.status.schema import (
    coerce_intent_escalation_policy as _coerce_intent_escalation_policy_from_router,
)
from flare_kernel.router.intake.state_persistence import (
    persist_authoritative_intake_state as persist_authoritative_intake_state_from_router,
)
from flare_kernel.router.kernel_facade.dependency_resolution import (
    resolve_orchestration_dependencies,
    resolve_persistence_dependencies,
    resolve_prompt_dependencies,
)
from flare_kernel.router.kernel_facade.utils import _kernel_attr
from flare_kernel.router.kernel_flow_bindings.session_intent import (
    resolve_session_intent_stage as _resolve_session_intent_stage_in_kernel_session_intent_flow,
)
from flare_kernel.router.kernel_request_pipeline.action import _resolve_command
from flare_kernel.router.kernel_request_pipeline.intake import (
    _merge_intent_and_escalation_signal,
)
from flare_kernel.router.orchestration.status.builder import (
    build_orchestration_status as build_orchestration_status_from_router,
)
from flare_kernel.router.prompting import (
    build_prompt as build_prompt_from_router,
)
from flare_kernel.router.text_safety import (
    extract_user_message as _extract_user_message,
    sanitize_product_name_for_prompt as _sanitize_product_name_for_prompt,
)


def build_kernel_orchestration_status_flow(
    *,
    trace_id: str,
    command: str,
    resolved_intent: str,
    resolved_mode: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    runtime_snapshot: dict[str, Any],
    raw_message: str,
    retrieval_attempted: bool,
    retrieval_queries: list[str],
    retrieved_knowledge: list[dict[str, Any]],
    resolve_requirement_intake_entry_recommendation_fn: Callable[..., tuple[str, float, str, str]],
    resolve_session_intent_stage_fn: Callable[..., str],
    coerce_intent_escalation_policy_fn: Callable[[Any], dict[str, Any]],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    intent_escalation_policy: dict[str, Any] | None,
    intent_escalation_policy_source: str,
    analysis_route: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build orchestration status projection from resolved dependencies."""
    return build_orchestration_status_from_router(
        trace_id=trace_id,
        command=command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        runtime_snapshot=runtime_snapshot,
        raw_message=raw_message,
        retrieval_attempted=retrieval_attempted,
        retrieval_queries=retrieval_queries,
        retrieved_knowledge=retrieved_knowledge,
        resolve_requirement_intake_entry_recommendation_fn=resolve_requirement_intake_entry_recommendation_fn,
        resolve_session_intent_stage_fn=resolve_session_intent_stage_fn,
        coerce_intent_escalation_policy_fn=coerce_intent_escalation_policy_fn,
        extract_user_message_fn=extract_user_message_fn,
        intent_escalation_policy=intent_escalation_policy,
        intent_escalation_policy_source=intent_escalation_policy_source,
        analysis_route=analysis_route,
    )


def persist_kernel_authoritative_intake_state_flow(
    *,
    trace_id: str,
    session_id: str,
    project_id: str | None,
    user_id: str | None,
    command: str,
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    persist_intake_session_state_fn: Callable[..., dict[str, Any]],
    persist_intake_checkpoint_fn: Callable[..., dict[str, Any]],
) -> dict[str, Any]:
    """Persist authoritative intake session/checkpoint state."""
    return persist_authoritative_intake_state_from_router(
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        command=command,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        persist_intake_session_state_fn=persist_intake_session_state_fn,
        persist_intake_checkpoint_fn=persist_intake_checkpoint_fn,
    )


def build_kernel_prompt_flow(
    *,
    req: KernelRequest,
    payload: dict[str, Any],
    instance_profile: dict[str, object] | None,
    intent: str | None,
    command: str | None,
    resolve_command_fn: Callable[[KernelRequest], str],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    sanitize_product_name_for_prompt_fn: Callable[[str], str],
    extract_quoted_terms_fn: Callable[[str], list[str]],
) -> str:
    """Build prompt text from resolved prompt dependencies."""
    return build_prompt_from_router(
        req,
        payload,
        instance_profile,
        intent=intent,
        command=command,
        resolve_command=resolve_command_fn,
        extract_user_message=extract_user_message_fn,
        sanitize_product_name_for_prompt=sanitize_product_name_for_prompt_fn,
        extract_quoted_terms=extract_quoted_terms_fn,
    )


def _build_orchestration_status(
    *,
    trace_id: str,
    command: str = "send_message",
    resolved_intent: str,
    resolved_mode: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    runtime_snapshot: dict[str, Any],
    raw_message: str = "",
    retrieval_attempted: bool,
    retrieval_queries: list[str],
    retrieved_knowledge: list[dict[str, Any]],
    intent_escalation_policy: dict[str, Any] | None = None,
    intent_escalation_policy_source: str = "default",
    analysis_route: dict[str, Any] | None = None,
    resolve_requirement_intake_entry_recommendation_fn=None,
    resolve_session_intent_stage_fn=None,
    coerce_intent_escalation_policy_fn=None,
    extract_user_message_fn=None,
) -> dict[str, Any]:
    orchestration_deps = resolve_orchestration_dependencies(
        resolve_requirement_intake_entry_recommendation_fn=resolve_requirement_intake_entry_recommendation_fn,
        resolve_session_intent_stage_fn=resolve_session_intent_stage_fn,
        coerce_intent_escalation_policy_fn=coerce_intent_escalation_policy_fn,
        extract_user_message_fn=extract_user_message_fn,
        kernel_attr_fn=_kernel_attr,
        defaults={
            "resolve_requirement_intake_entry_recommendation_fn": _resolve_requirement_intake_entry_recommendation_from_router,
            "resolve_session_intent_stage_fn": _resolve_session_intent_stage_in_kernel_session_intent_flow,
            "coerce_intent_escalation_policy_fn": _coerce_intent_escalation_policy_from_router,
            "extract_user_message_fn": _extract_user_message,
        },
    )
    return build_kernel_orchestration_status_flow(
        trace_id=trace_id,
        command=command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        runtime_snapshot=runtime_snapshot,
        raw_message=raw_message,
        retrieval_attempted=retrieval_attempted,
        retrieval_queries=retrieval_queries,
        retrieved_knowledge=retrieved_knowledge,
        resolve_requirement_intake_entry_recommendation_fn=orchestration_deps["resolve_requirement_intake_entry_recommendation_fn"],
        resolve_session_intent_stage_fn=orchestration_deps["resolve_session_intent_stage_fn"],
        coerce_intent_escalation_policy_fn=orchestration_deps["coerce_intent_escalation_policy_fn"],
        extract_user_message_fn=orchestration_deps["extract_user_message_fn"],
        intent_escalation_policy=intent_escalation_policy,
        intent_escalation_policy_source=intent_escalation_policy_source,
        analysis_route=analysis_route,
    )


def _persist_authoritative_intake_state(
    *,
    trace_id: str,
    session_id: str,
    project_id: str | None,
    user_id: str | None,
    command: str,
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    persist_intake_session_state_fn=None,
    persist_intake_checkpoint_fn=None,
) -> dict[str, Any]:
    persistence_deps = resolve_persistence_dependencies(
        persist_intake_session_state_fn=persist_intake_session_state_fn,
        persist_intake_checkpoint_fn=persist_intake_checkpoint_fn,
        kernel_attr_fn=_kernel_attr,
        defaults={
            "persist_intake_session_state_fn": persist_intake_session_state,
            "persist_intake_checkpoint_fn": persist_intake_checkpoint,
        },
    )
    return persist_kernel_authoritative_intake_state_flow(
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        command=command,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        persist_intake_session_state_fn=persistence_deps["persist_intake_session_state_fn"],
        persist_intake_checkpoint_fn=persistence_deps["persist_intake_checkpoint_fn"],
    )


def _build_prompt(
    req: KernelRequest,
    payload: dict[str, Any],
    instance_profile: dict[str, object] | None,
    *,
    intent: str | None = None,
    command: str | None = None,
    resolve_command=None,
    extract_user_message=None,
    sanitize_product_name_for_prompt=None,
    extract_quoted_terms=None,
) -> str:
    prompt_deps = resolve_prompt_dependencies(
        resolve_command_fn=resolve_command,
        extract_user_message_fn=extract_user_message,
        sanitize_product_name_for_prompt_fn=sanitize_product_name_for_prompt,
        extract_quoted_terms_fn=extract_quoted_terms,
        kernel_attr_fn=_kernel_attr,
        defaults={
            "resolve_command_fn": _resolve_command,
            "extract_user_message_fn": _extract_user_message,
            "sanitize_product_name_for_prompt_fn": _sanitize_product_name_for_prompt,
            "extract_quoted_terms_fn": _extract_quoted_terms,
        },
    )
    return build_kernel_prompt_flow(
        req=req,
        payload=payload,
        instance_profile=instance_profile,
        intent=intent,
        command=command,
        resolve_command_fn=prompt_deps["resolve_command_fn"],
        extract_user_message_fn=prompt_deps["extract_user_message_fn"],
        sanitize_product_name_for_prompt_fn=prompt_deps["sanitize_product_name_for_prompt_fn"],
        extract_quoted_terms_fn=prompt_deps["extract_quoted_terms_fn"],
    )


__all__ = [
    "build_kernel_orchestration_status_flow",
    "persist_kernel_authoritative_intake_state_flow",
    "build_kernel_prompt_flow",
    "_build_orchestration_status",
    "_persist_authoritative_intake_state",
    "_build_prompt",
]
