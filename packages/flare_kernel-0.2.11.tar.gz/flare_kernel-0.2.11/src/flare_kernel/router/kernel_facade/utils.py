"""Shared helper utilities for kernel facade wrappers."""

from __future__ import annotations

from importlib import import_module
from typing import Any


def _kernel_attr(name: str, fallback: Any) -> Any:
    """Read a live symbol from the kernel facade module when available."""
    try:
        kernel_module = import_module("flare_kernel.router.kernel")
        return getattr(kernel_module, name, fallback)
    except Exception:  # pragma: no cover - defensive fallback
        return fallback


def _map_external_mode(mode_key: str) -> str:
    """Map external mode keys into the internal kernel mode vocabulary."""
    normalized = str(mode_key or "").strip()
    mapping = {
        "requirement_intake": "requirement_intake",
        "intelligent_sourcing": "sourcing",
        "analysis_mode": "analysis_mode",
        "default": "auto",
    }
    return mapping.get(normalized, normalized or "auto")


def _safe_session_id(value: Any) -> str:
    """Return a stable fallback session id for empty or invalid values."""
    text = str(value or "").strip()
    return text or "default"


__all__ = ["_kernel_attr", "_map_external_mode", "_safe_session_id"]
