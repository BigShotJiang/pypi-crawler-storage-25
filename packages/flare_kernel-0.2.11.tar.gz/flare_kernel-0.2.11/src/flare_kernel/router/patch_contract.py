"""Patch-event contract shaping helpers."""

from __future__ import annotations

from typing import Any


def build_patch_event(
    *,
    contract_version: str,
    trace_id: str,
    sequence: int,
    event_type: str,
    client_request_id: str,
    session_id: str,
    turn_id: str,
    patch_scope: list[str],
    payload: dict[str, Any],
    final: bool,
    allowed_scopes: set[str],
    request_id: str = "",
    run_id: str = "",
    run_state: str = "running",
) -> dict[str, Any]:
    normalized_payload = payload if isinstance(payload, dict) else {}
    return {
        "contract_version": contract_version,
        "message_type": "patch_event",
        "event_type": event_type,
        "sequence": int(sequence),
        "trace_id": trace_id,
        "client_request_id": client_request_id,
        "request_id": request_id,
        "run_id": run_id,
        "run_state": run_state,
        "session_id": session_id,
        "session": {
            "session_id": session_id,
            "turn_id": str(turn_id or ""),
        },
        "patch_scope": [item for item in patch_scope if item in allowed_scopes],
        "payload": normalized_payload,
        "final": bool(final),
    }
