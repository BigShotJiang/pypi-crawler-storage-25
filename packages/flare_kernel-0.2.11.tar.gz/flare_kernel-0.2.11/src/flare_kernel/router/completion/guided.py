"""Guided-session completion helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.llm.llm_provider import LLMCompletion

_REQUIREMENT_INTAKE_COMMAND_SCORES = {
    "": {"main_chain": 1.0, "patch_only": 0.0},
    "send_message": {"main_chain": 1.0, "patch_only": 0.0},
    "submit_intake_answer": {"main_chain": 0.0, "patch_only": 1.0},
    "activate_requirement_intake": {"main_chain": 0.0, "patch_only": 1.0},
}
_DEFAULT_REQUIREMENT_INTAKE_COMMAND_SCORE = {"main_chain": 1.0, "patch_only": 0.0}
_PATCH_ONLY_COMPLETION_MODES = frozenset({"patch_only", "state_patch_only"})
_MAIN_CHAIN_COMPLETION_MODES = frozenset({"main_chain", "llm", "generate"})


@dataclass(frozen=True)
class _GuidedCompletionDecision:
    action: str
    main_chain_score: float
    patch_only_score: float
    phase_score: float
    policy_reason: str

    @property
    def is_patch_only(self) -> bool:
        return self.action == "patch_only"


def _is_collecting_question_phase(orchestration_status: dict[str, Any]) -> bool:
    status = orchestration_status if isinstance(orchestration_status, dict) else {}
    current_stage = str(status.get("current_stage") or "").strip().lower()
    if not current_stage.startswith("requirement_intake"):
        return False
    if current_stage == "requirement_intake.collecting":
        return True
    chooser_state = status.get("chooser_state") if isinstance(status.get("chooser_state"), dict) else {}
    chooser_kind = str(chooser_state.get("kind") or "").strip().lower()
    has_current_question = isinstance(status.get("current_question"), dict)
    if has_current_question:
        return True
    if chooser_kind == "question":
        return True
    if bool(status.get("has_active_question")):
        return True
    state = str(status.get("intake_session_state") or "").strip().lower()
    if state in {"collecting", "blocked"}:
        return True
    return False


def _coerce_payload(req: KernelRequest) -> dict[str, Any]:
    return req.payload if isinstance(req.payload, dict) else {}


def _completion_mode_from_payload(payload: dict[str, Any]) -> str:
    """Read the optional completion-routing contract from request payload.

    Supported payload shapes:
    - completion_policy: {"mode": "patch_only" | "main_chain"}
    - completion_mode: "patch_only" | "main_chain"
    """
    policy = payload.get("completion_policy")
    raw_mode = ""
    if isinstance(policy, dict):
        raw_mode = str(policy.get("mode") or policy.get("completion_mode") or policy.get("action") or "").strip()
    elif policy is not None:
        raw_mode = str(policy or "").strip()
    if not raw_mode:
        raw_mode = str(payload.get("completion_mode") or "").strip()
    return raw_mode.lower().replace("-", "_").replace(" ", "_")


def _has_workspace_patch_signal(payload: dict[str, Any]) -> bool:
    if isinstance(payload.get("workspace_patch"), dict) and payload.get("workspace_patch"):
        return True
    patches = payload.get("workspace_patches")
    return isinstance(patches, list) and any(isinstance(item, dict) and item for item in patches)


def _explicit_completion_decision(payload: dict[str, Any]) -> _GuidedCompletionDecision | None:
    completion_mode = _completion_mode_from_payload(payload)
    if completion_mode in _PATCH_ONLY_COMPLETION_MODES:
        return _GuidedCompletionDecision(
            action="patch_only",
            main_chain_score=0.0,
            patch_only_score=1.0,
            phase_score=1.0,
            policy_reason="explicit_completion_policy",
        )
    if completion_mode in _MAIN_CHAIN_COMPLETION_MODES:
        return _GuidedCompletionDecision(
            action="main_chain",
            main_chain_score=1.0,
            patch_only_score=0.0,
            phase_score=0.0,
            policy_reason="explicit_completion_policy",
        )
    return None


def _payload_patch_decision(payload: dict[str, Any]) -> _GuidedCompletionDecision | None:
    if not _has_workspace_patch_signal(payload):
        return None
    return _GuidedCompletionDecision(
        action="patch_only",
        main_chain_score=0.0,
        patch_only_score=1.0,
        phase_score=1.0,
        policy_reason="workspace_patch_payload",
    )


def _resolve_requirement_intake_guided_decision(
    *,
    req: KernelRequest,
    command: str,
    orchestration_status: dict[str, Any],
) -> _GuidedCompletionDecision:
    """Resolve requirement-intake guided completion as a scored policy decision.

    Args:
        command: Normalized kernel command for the current turn.
        orchestration_status: Canonical orchestration state for this turn.

    Returns:
        A scored decision. `main_chain` means the assistant response should continue
        through the normal LLM path; `patch_only` means this turn only emits UI/state
        patches and should not be persisted as an assistant memory record.
    """
    payload = _coerce_payload(req)
    explicit_decision = _explicit_completion_decision(payload)
    if explicit_decision is not None:
        return explicit_decision
    payload_decision = _payload_patch_decision(payload)
    if payload_decision is not None:
        return payload_decision
    command_scores = _REQUIREMENT_INTAKE_COMMAND_SCORES.get(
        command,
        _DEFAULT_REQUIREMENT_INTAKE_COMMAND_SCORE,
    )
    phase_score = float(_is_collecting_question_phase(orchestration_status))
    patch_only_score = phase_score * float(command_scores["patch_only"])
    main_chain_score = float(command_scores["main_chain"])
    action = "patch_only" if patch_only_score > main_chain_score else "main_chain"
    return _GuidedCompletionDecision(
        action=action,
        main_chain_score=main_chain_score,
        patch_only_score=patch_only_score,
        phase_score=phase_score,
        policy_reason="legacy_command_phase_score",
    )


def resolve_guided_orchestrated_completion(
    *,
    req: KernelRequest,
    command: str,
    resolved_mode: str,
    mode_source: str,
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
) -> LLMCompletion | None:
    _ = (req, mode_source)
    normalized_mode = str(resolved_mode or "").strip()
    normalized_command = str(command or "").strip()
    if normalized_mode != "requirement_intake":
        return None
    intake_decision = _resolve_requirement_intake_guided_decision(
        req=req,
        command=normalized_command,
        orchestration_status=orchestration_status,
    )
    if not intake_decision.is_patch_only:
        return None
    _ = req
    return LLMCompletion(
        provider="kernel_guardrail",
        model="guided_session",
        content="",
        status="orchestrated",
        details={
            "reason": "guided_session_patch_only",
            "phase": "collecting_question",
            "mode": normalized_mode,
            "command": normalized_command,
            "main_chain_score": intake_decision.main_chain_score,
            "patch_only_score": intake_decision.patch_only_score,
            "phase_score": intake_decision.phase_score,
            "policy_reason": intake_decision.policy_reason,
        },
    )


def should_persist_memory_record(*, completion: LLMCompletion) -> bool:
    details = completion.details if isinstance(completion.details, dict) else {}
    if str(details.get("reason") or "").strip() == "guided_session_patch_only":
        return False
    return True
