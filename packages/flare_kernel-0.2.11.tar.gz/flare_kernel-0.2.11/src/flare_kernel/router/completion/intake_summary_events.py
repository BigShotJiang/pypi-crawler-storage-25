"""Completion-time intake summary event helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.intake_summary_artifact import (
    build_model_authored_requirement_summary_event,
)

_CANVAS_ONLY_COMMANDS = frozenset({"", "send_message"})
_DOCUMENT_OUTPUT_INTENTS = frozenset({"document_template_output", "document_draft_output"})
_CONFIRM_SEND_PROMPT_ACTION_KEY = "confirm_send_prompt"


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _has_document_output_intent(runtime_snapshot: dict[str, Any]) -> bool:
    payload = _coerce_mapping(runtime_snapshot.get("payload"))
    response_intent_result = _coerce_mapping(payload.get("response_intent_result"))
    return _clean_text(response_intent_result.get("response_intent")) in _DOCUMENT_OUTPUT_INTENTS


def _has_active_question(orchestration_status: dict[str, Any]) -> bool:
    status = orchestration_status if isinstance(orchestration_status, dict) else {}
    current_question = _coerce_mapping(status.get("current_question"))
    question_status = _clean_text(current_question.get("question_status") or current_question.get("status")).lower()
    if current_question and question_status not in {"answered", "stale", "dismissed", "completed", "applied"}:
        return True
    chooser_state = _coerce_mapping(status.get("chooser_state"))
    if _clean_text(chooser_state.get("kind")).lower() == "question" and chooser_state.get("visible") is not False:
        return True
    return bool(status.get("has_active_question"))


def _is_confirm_send_prompt_action(action: dict[str, Any]) -> bool:
    payload = _coerce_mapping(action.get("payload"))
    action_key = _clean_text(action.get("action_key") or action.get("id") or action.get("command"))
    action_type = _clean_text(action.get("action_type") or action.get("type"))
    payload_action_type = _clean_text(payload.get("action_type") or payload.get("type"))
    return (
        action_key == _CONFIRM_SEND_PROMPT_ACTION_KEY
        or action_type == _CONFIRM_SEND_PROMPT_ACTION_KEY
        or payload_action_type == _CONFIRM_SEND_PROMPT_ACTION_KEY
    )


def build_requirement_summary_confirm_send_action(
    *,
    content_text: str,
) -> dict[str, Any] | None:
    """Build the backend-owned action that sends the reviewed prompt text."""

    prompt = _clean_text(content_text)
    if not prompt:
        return None
    return {
        "action_key": _CONFIRM_SEND_PROMPT_ACTION_KEY,
        "action_type": _CONFIRM_SEND_PROMPT_ACTION_KEY,
        "label": "确认发送",
        "target_mode": "auto",
        "priority": 0,
        "status": "available",
        "command": "send_message",
        "reason": "确认后会将整理后的完整提示词作为下一条消息发送。",
        "payload": {
            "action_key": _CONFIRM_SEND_PROMPT_ACTION_KEY,
            "action_type": _CONFIRM_SEND_PROMPT_ACTION_KEY,
            "command": "send_message",
            "target_mode": "auto",
            "prompt_text": prompt,
            "answer_value": prompt,
            "submit_label": "确认发送",
            "title": "确认发送整理后的提示词",
        },
    }


def with_requirement_summary_confirm_send_action(
    *,
    next_actions: list[dict[str, Any]],
    content_text: str,
) -> list[dict[str, Any]]:
    """Attach the prompt-confirm action without rewriting other actions."""

    actions = next_actions if isinstance(next_actions, list) else []
    resolved = [
        dict(action)
        for action in actions
        if isinstance(action, dict) and not _is_confirm_send_prompt_action(action)
    ]
    confirm_action = build_requirement_summary_confirm_send_action(content_text=content_text)
    if not confirm_action:
        return resolved
    return [confirm_action, *resolved]


def with_requirement_summary_confirm_send_canvas_event(
    *,
    summary_event: dict[str, Any] | None,
    content_text: str,
) -> dict[str, Any] | None:
    """Attach the prompt-confirm action to a Canvas state event."""

    if not isinstance(summary_event, dict):
        return summary_event
    payload = _coerce_mapping(summary_event.get("payload"))
    canvas_state = _coerce_mapping(payload.get("canvas_state"))
    if not canvas_state:
        return summary_event
    next_actions = with_requirement_summary_confirm_send_action(
        next_actions=canvas_state.get("next_actions") if isinstance(canvas_state.get("next_actions"), list) else [],
        content_text=content_text,
    )
    if not next_actions:
        return summary_event
    next_canvas_state = {**canvas_state, "next_actions": next_actions}
    next_payload = {**payload, "canvas_state": next_canvas_state}
    return {**summary_event, "payload": next_payload}


def should_render_requirement_summary_as_canvas_only(
    *,
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    content_text: str,
    completion_provider: str,
    completion_model: str,
    completion_status: str,
    command: str,
) -> bool:
    """Return whether a generated intake summary is a review prompt, not a reply."""

    if _clean_text(command) not in _CANVAS_ONLY_COMMANDS:
        return False
    if _has_document_output_intent(runtime_snapshot):
        return False
    # PLN-15: a model-authored intake summary is the prompt-ready artifact to
    # review/send. Existing active questions remain state carriers, but must not
    # block the summary confirmation loop or revive mechanical field chasing.
    return build_model_authored_requirement_summary_event(
        runtime_snapshot=runtime_snapshot,
        content_text=content_text,
        completion_provider=completion_provider,
        completion_model=completion_model,
        completion_status=completion_status,
    ) is not None


def with_model_authored_requirement_summary_event(
    *,
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    content_text: str,
    completion_provider: str,
    completion_model: str,
    completion_status: str,
    command: str,
) -> list[dict[str, Any]]:
    """Return mode events with a model-authored Canvas summary event appended."""

    mode_events = list(runtime_snapshot.get("mode_events") if isinstance(runtime_snapshot.get("mode_events"), list) else [])
    if not should_render_requirement_summary_as_canvas_only(
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        content_text=content_text,
        completion_provider=completion_provider,
        completion_model=completion_model,
        completion_status=completion_status,
        command=command,
    ):
        return mode_events
    summary_event = build_model_authored_requirement_summary_event(
        runtime_snapshot=runtime_snapshot,
        content_text=content_text,
        completion_provider=completion_provider,
        completion_model=completion_model,
        completion_status=completion_status,
    )
    if summary_event:
        mode_events.append(with_requirement_summary_confirm_send_canvas_event(
            summary_event=summary_event,
            content_text=content_text,
        ))
    return mode_events


__all__ = [
    "build_requirement_summary_confirm_send_action",
    "should_render_requirement_summary_as_canvas_only",
    "with_requirement_summary_confirm_send_action",
    "with_requirement_summary_confirm_send_canvas_event",
    "with_model_authored_requirement_summary_event",
]
