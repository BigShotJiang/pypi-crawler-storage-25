"""Analysis payload projection for completion run results.

DOC HELPER — ANL-02/WRK-04 run result analysis writeback boundary.
Non-stream /kernel/run responses expose the same analysis payload and
append-only context patch that stream completion events already carry.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.context.analysis_application import build_context_patch_from_analysis


def attach_analysis_result_contract(
    *,
    result: dict[str, Any],
    orchestration_status: dict[str, Any],
) -> dict[str, Any]:
    analysis_payload = (
        orchestration_status.get("canvas_analysis_payload")
        if isinstance(orchestration_status.get("canvas_analysis_payload"), dict)
        else {}
    )
    if not analysis_payload:
        return result
    result["canvas_analysis_payload"] = analysis_payload
    result["analysis_payload"] = analysis_payload
    context_patch = build_context_patch_from_analysis(analysis_payload)
    if context_patch:
        result["context_patch"] = context_patch
    return result


__all__ = ["attach_analysis_result_contract"]
