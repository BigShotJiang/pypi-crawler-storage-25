"""Shared analysis completion policy for run and stream routes.

DOC HELPER — ANL-02/ANL-03 completion analysis payload bridge.
This module owns the route-neutral conversion from generated analysis text to
the canonical analysis canvas payload. It does not persist state, frame
transport events, or reinterpret domain content.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.router.payload.analysis_canvas import build_canvas_analysis_payload


def _resolve_previous_payload(
    *,
    orchestration_status: dict[str, Any],
    runtime_snapshot: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if isinstance(orchestration_status.get("canvas_analysis_payload"), dict):
        return orchestration_status.get("canvas_analysis_payload")
    if not isinstance(runtime_snapshot, dict):
        return None
    payload = runtime_snapshot.get("payload")
    if isinstance(payload, dict) and isinstance(payload.get("canvas_analysis_payload"), dict):
        return payload.get("canvas_analysis_payload")
    return None


def apply_analysis_completion_policy(
    *,
    orchestration_status: dict[str, Any],
    command: str,
    content_text: str,
    runtime_snapshot: dict[str, Any] | None = None,
) -> None:
    has_llm_content = bool(str(content_text or "").strip())
    orchestration_status["content_policy"] = {
        "has_llm_content": has_llm_content,
        "rendered_as_system_notice": not has_llm_content,
    }
    if command == "generate_analysis" and orchestration_status.get("intake_session_id"):
        orchestration_status["intake_session_state"] = (
            "analysis_completed" if has_llm_content else "analysis_running"
        )
        orchestration_status["intake_session_completed"] = bool(has_llm_content)
    if command != "generate_analysis":
        return
    canvas_analysis_payload, slot_patches = build_canvas_analysis_payload(
        analysis_route=(
            orchestration_status.get("analysis_route")
            if isinstance(orchestration_status.get("analysis_route"), dict)
            else None
        ),
        content_text=content_text,
        previous_payload=_resolve_previous_payload(
            orchestration_status=orchestration_status,
            runtime_snapshot=runtime_snapshot,
        ),
        orchestration_status=orchestration_status,
        runtime_snapshot=runtime_snapshot,
    )
    if canvas_analysis_payload:
        orchestration_status["canvas_analysis_payload"] = canvas_analysis_payload
    if isinstance(slot_patches, list):
        orchestration_status["analysis_slot_patches"] = slot_patches


def apply_completion_content_policy(
    *,
    orchestration_status: dict[str, Any],
    command: str,
    has_llm_content: bool,
    content_text: str | None = None,
    runtime_snapshot: dict[str, Any] | None = None,
) -> None:
    if content_text is not None:
        apply_analysis_completion_policy(
            orchestration_status=orchestration_status,
            command=command,
            content_text=content_text,
            runtime_snapshot=runtime_snapshot,
        )
        return
    orchestration_status["content_policy"] = {
        "has_llm_content": has_llm_content,
        "rendered_as_system_notice": not has_llm_content,
    }
    if command == "generate_analysis" and orchestration_status.get("intake_session_id"):
        orchestration_status["intake_session_state"] = (
            "analysis_completed" if has_llm_content else "analysis_running"
        )
        orchestration_status["intake_session_completed"] = bool(has_llm_content)


__all__ = ["apply_analysis_completion_policy", "apply_completion_content_policy"]
