"""Collect provider stream events into a completion."""

from __future__ import annotations

from inspect import isawaitable
from typing import Any, Callable

from flare_kernel.runtime.llm.contracts import LLMCompletion


async def collect_stream_completion(
    generate_llm_completion_stream_fn: Callable[..., Any],
    prompt: str,
    *,
    trace_id: str,
    session_id: str,
    intent: str,
    on_delta_fn: Callable[[str], Any] | None = None,
) -> LLMCompletion:
    completion: LLMCompletion | None = None
    async for event in generate_llm_completion_stream_fn(
        prompt,
        trace_id=trace_id,
        session_id=session_id,
        intent=intent,
    ):
        delta = str(getattr(event, "delta", "") or "")
        if delta and on_delta_fn is not None:
            result = on_delta_fn(delta)
            if isawaitable(result):
                await result
        if getattr(event, "completion", None) is not None:
            completion = event.completion
    if completion is not None:
        return completion
    return LLMCompletion(
        provider="stream",
        model="unknown",
        content="[stream:unknown] LLM stream placeholder (missing completion)",
        status="placeholder",
        details={"backend": "stream", "reason": "missing_completion"},
    )


__all__ = ["collect_stream_completion"]
