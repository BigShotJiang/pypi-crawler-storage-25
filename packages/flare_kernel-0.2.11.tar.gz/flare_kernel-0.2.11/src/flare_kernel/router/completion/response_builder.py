"""Kernel run/action completion response assembly helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_engines import build_context_answer_appendix
from flare_kernel.contracts import KernelResponse
from flare_kernel.router.completion.analysis_policy import apply_completion_content_policy
from flare_kernel.router.completion.analysis_result_contract import (
    attach_analysis_result_contract,
)
from flare_kernel.router.completion.intake_summary_events import (
    should_render_requirement_summary_as_canvas_only,
    with_requirement_summary_confirm_send_action,
    with_model_authored_requirement_summary_event,
)
from flare_kernel.router.next_actions_guard import dedupe_next_actions_by_action_key
from flare_kernel.runtime.llm.contracts import LLMCompletion
from flare_kernel.runtime.llm.provider_trace import build_completion_provider_trace


def _append_sourcing_preview_lines(
    *,
    content_text: str,
    mode_key: str,
    mode_state: str,
    structured_retrieved_knowledge: list[dict[str, Any]],
) -> str:
    if mode_key != "intelligent_sourcing" or mode_state != "collecting":
        return content_text
    if not isinstance(structured_retrieved_knowledge, list) or not structured_retrieved_knowledge:
        return content_text

    lines: list[str] = []
    for item in structured_retrieved_knowledge[:2]:
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or "").strip()
        if not title:
            continue
        try:
            confidence = max(0.0, min(1.0, float(item.get("confidence") or item.get("score") or 0.0)))
        except (TypeError, ValueError):
            confidence = 0.0
        url = str(item.get("url") or "").strip()
        line = f"- {title}（置信度 {confidence:.2f}）"
        if url:
            line += f"\n  来源：{url}"
        lines.append(line)
    if not lines:
        return content_text

    extra = "先给您两条预检索参考（补充字段后再匹配候选供应商）：\n" + "\n".join(lines)
    base = str(content_text or "").rstrip()
    return f"{base}\n\n{extra}".strip()


def _format_citation_line(citation: dict[str, Any], index: int) -> str:
    citation_id = str(citation.get("citation_id") or f"cite_{index + 1}").strip()
    title = str(citation.get("title") or citation.get("source_id") or "").strip()
    snippet = str(
        citation.get("snippet")
        or citation.get("matched_text")
        or citation.get("hit_reason")
        or ""
    ).strip()
    url = str(citation.get("url") or citation.get("source_url") or "").strip()
    if not title and not snippet and not url:
        return ""
    title = title or "引用条目"
    try:
        score_value = float(citation.get("score")) if citation.get("score") is not None else None
    except (TypeError, ValueError):
        score_value = None
    score_suffix = f"（相关度 {score_value:.2f}）" if score_value is not None else ""
    detail_text = f"：{snippet}" if snippet else ""
    link_text = f"\n链接：{url}" if url else ""
    return f"[{citation_id}] {title}{score_suffix}{detail_text}{link_text}".strip()


def _build_citation_appendix(citations: list[dict[str, Any]]) -> str:
    lines = [
        _format_citation_line(citation, index)
        for index, citation in enumerate(citations[:3])
        if isinstance(citation, dict)
    ]
    lines = [line for line in lines if line]
    if not lines:
        return ""
    return "引用来源：\n" + "\n\n".join(lines)


def _append_citation_lines(*, content_text: str, citations: list[dict[str, Any]]) -> str:
    appendix = _build_citation_appendix(citations)
    if not appendix:
        return str(content_text or "").strip()
    base = str(content_text or "").strip()
    if not base:
        return appendix
    if appendix in base:
        return base
    return f"{base}\n\n{appendix}".strip()


def _append_context_answer_lines(*, content_text: str, runtime_snapshot: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    context_answer = build_context_answer_appendix(
        {
            "session_context": runtime_snapshot.get("session_context")
            if isinstance(runtime_snapshot.get("session_context"), dict)
            else {},
            "document_result": runtime_snapshot.get("document_result")
            if isinstance(runtime_snapshot.get("document_result"), dict)
            else {},
            "max_artifacts": 2,
        }
    )
    appendix = str(context_answer.get("appendix") or "").strip()
    base = str(content_text or "").strip()
    display_policy = runtime_snapshot.get("context_display_policy")
    should_append = isinstance(display_policy, dict) and display_policy.get("append_context_answer") is True
    if not should_append or not appendix or appendix in base:
        return base, context_answer
    if not base:
        return appendix, context_answer
    return f"{base}\n\n{appendix}".strip(), context_answer


def build_run_result_payload(
    *,
    content_text: str,
    effective_command: str = "",
    completion_provider: str,
    completion_model: str,
    completion_status: str,
    completion_details: dict[str, Any] | None = None,
    runtime_snapshot: dict[str, Any],
    memory_record: dict[str, Any],
    retrieved_knowledge: list[dict[str, Any]],
    structured_retrieved_knowledge: list[dict[str, Any]],
    orchestration_status: dict[str, Any],
    mode_switch_reason: dict[str, Any],
    build_knowledge_citations_fn: Callable[[list[dict[str, Any]]], list[dict[str, Any]]],
) -> dict[str, Any]:
    provider_trace = build_completion_provider_trace(
        LLMCompletion(
            provider=completion_provider,
            model=completion_model,
            content="",
            status=completion_status,
            details=completion_details or {},
        )
    )
    knowledge_citation = build_knowledge_citations_fn(structured_retrieved_knowledge)
    final_message = _append_sourcing_preview_lines(
        content_text=content_text,
        mode_key=str(runtime_snapshot["mode_key"]),
        mode_state=str(runtime_snapshot["mode_state"]),
        structured_retrieved_knowledge=structured_retrieved_knowledge,
    )
    final_message, context_answer = _append_context_answer_lines(
        content_text=final_message,
        runtime_snapshot=runtime_snapshot,
    )
    final_message = _append_citation_lines(content_text=final_message, citations=knowledge_citation)
    canvas_only_summary = should_render_requirement_summary_as_canvas_only(
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        content_text=content_text,
        completion_provider=completion_provider,
        completion_model=completion_model,
        completion_status=completion_status,
        command=effective_command,
    )
    raw_next_actions = dedupe_next_actions_by_action_key(
        orchestration_status.get("next_actions", runtime_snapshot["next_actions"])
    )
    next_actions = (
        with_requirement_summary_confirm_send_action(
            next_actions=raw_next_actions,
            content_text=content_text,
        )
        if canvas_only_summary
        else raw_next_actions
    )
    result_orchestration_status = (
        {**orchestration_status, "next_actions": next_actions}
        if canvas_only_summary
        else orchestration_status
    )
    mode_events = with_model_authored_requirement_summary_event(
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        content_text=content_text,
        completion_provider=completion_provider,
        completion_model=completion_model,
        completion_status=completion_status,
        command=effective_command,
    )
    result = {
        "message": final_message,
        "provider": completion_provider,
        "model": completion_model,
        "provider_status": completion_status,
        "provider_trace": provider_trace,
        "mode_switch_reason": mode_switch_reason,
        "mode_key": runtime_snapshot["mode_key"],
        "mode_state": runtime_snapshot["mode_state"],
        "mode_runtime": runtime_snapshot["mode_runtime"],
        "session_context": runtime_snapshot.get("session_context", {}),
        "track_result": runtime_snapshot.get("track_result", {}),
        "response_strategy_result": runtime_snapshot.get("response_strategy_result", {}),
        "context_usage": runtime_snapshot["context_usage"],
        "agent_runtime": runtime_snapshot["agent_runtime"],
        "skill_runtime": runtime_snapshot["skill_runtime"],
        "data_ingestion": runtime_snapshot["data_ingestion"],
        "memory_runtime": {**runtime_snapshot["memory_runtime"], **memory_record},
        "observation_runtime": {
            **runtime_snapshot["observation_runtime"],
            "provider_trace": provider_trace,
            "metrics": {
                **runtime_snapshot["observation_runtime"].get("metrics", {}),
                "retrieval_hit_count": len(retrieved_knowledge),
                "llm_success_count": 1 if completion_status == "ok" else 0,
            },
        },
        "mode_events": mode_events,
        "next_actions": next_actions,
        "retrieved_knowledge": structured_retrieved_knowledge,
        "knowledge_citation": knowledge_citation,
        "context_answer": context_answer,
        "orchestration_status": result_orchestration_status,
    }
    return attach_analysis_result_contract(
        result=result,
        orchestration_status=result_orchestration_status,
    )


def build_action_result_payload(
    *,
    content_text: str,
    action_command: str = "action",
    completion_provider: str,
    completion_model: str,
    completion_status: str,
    completion_details: dict[str, Any] | None = None,
    runtime_snapshot: dict[str, Any],
    memory_record: dict[str, Any],
    orchestration_status: dict[str, Any],
    action_key: str | None,
    action_target_mode: str,
    action_status: str | None,
    action_reason: str | None,
) -> dict[str, Any]:
    provider_trace = build_completion_provider_trace(
        LLMCompletion(
            provider=completion_provider,
            model=completion_model,
            content="",
            status=completion_status,
            details=completion_details or {},
        )
    )
    next_actions = dedupe_next_actions_by_action_key(
        orchestration_status.get("next_actions", runtime_snapshot["next_actions"])
    )
    mode_events = with_model_authored_requirement_summary_event(
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        content_text=content_text,
        completion_provider=completion_provider,
        completion_model=completion_model,
        completion_status=completion_status,
        command=action_command,
    )
    return {
        "message": content_text,
        "provider": completion_provider,
        "model": completion_model,
        "provider_status": completion_status,
        "provider_trace": provider_trace,
        "mode_key": runtime_snapshot["mode_key"],
        "mode_state": runtime_snapshot["mode_state"],
        "mode_runtime": runtime_snapshot["mode_runtime"],
        "context_usage": runtime_snapshot["context_usage"],
        "agent_runtime": runtime_snapshot["agent_runtime"],
        "skill_runtime": runtime_snapshot["skill_runtime"],
        "data_ingestion": runtime_snapshot["data_ingestion"],
        "memory_runtime": {**runtime_snapshot["memory_runtime"], **memory_record},
        "observation_runtime": {
            **runtime_snapshot["observation_runtime"],
            "provider_trace": provider_trace,
            "metrics": {
                **runtime_snapshot["observation_runtime"].get("metrics", {}),
                "plan_confirm_count": 1 if (action_key or "") == "confirm_plan" else 0,
                "llm_success_count": 1 if completion_status == "ok" else 0,
            },
        },
        "mode_events": mode_events,
        "next_actions": next_actions,
        "orchestration_status": orchestration_status,
        "selected_action": {
            "action_key": action_key,
            "target_mode": action_target_mode,
            "status": action_status,
            "reason": action_reason,
        },
    }


def build_kernel_success_response(
    *,
    trace_id: str,
    result: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
) -> KernelResponse:
    next_actions = dedupe_next_actions_by_action_key(
        orchestration_status.get("next_actions", runtime_snapshot["next_actions"])
    )
    return KernelResponse(
        trace_id=trace_id,
        state="SUCCEEDED",
        events=[],
        result=result,
        next_actions=next_actions,
    )
