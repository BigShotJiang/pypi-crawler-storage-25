"""Request-intent resolution helpers for kernel router wrappers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest


def _is_intake_mode(mode: str) -> bool:
    return str(mode or "").strip() == "requirement_intake"


def resolve_explicit_intent(
    req: KernelRequest,
    *,
    normalize_mode_candidate_fn: Callable[[Any], str],
) -> str:
    if not isinstance(req.intent, str):
        return ""
    return normalize_mode_candidate_fn(req.intent)


def resolve_intent_override(
    req: KernelRequest,
    *,
    normalize_mode_candidate_fn: Callable[[Any], str],
) -> str:
    payload = req.payload if isinstance(req.payload, dict) else {}
    candidates = [
        req.intent_override,
        payload.get("intent_override"),
    ]
    for candidate in candidates:
        normalized = normalize_mode_candidate_fn(candidate)
        if normalized:
            return normalized
    return ""


def resolve_request_intent(
    req: KernelRequest,
    *,
    instance_profile: dict[str, Any] | None,
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    normalize_message_for_intent_fn: Callable[[KernelRequest, str, dict[str, Any] | None], str],
    resolve_requirement_intake_entry_recommendation_fn: Callable[..., tuple[str, float, str, str]],
    infer_intent_by_keywords_fn: Callable[[str], str],
    contains_any_text_fn: Callable[[str, tuple[str, ...]], bool],
    requirement_entry_structuring_terms: tuple[str, ...],
) -> str:
    raw_intent = req.intent if isinstance(req.intent, str) else ""
    intent = raw_intent.strip()
    if intent and intent.lower() != "default":
        return intent

    message = extract_user_message_fn(req.payload)
    if not message:
        return intent or "default"

    normalized_message = normalize_message_for_intent_fn(req, message, instance_profile)
    intake_mode, _, _, intake_source = resolve_requirement_intake_entry_recommendation_fn(message=normalized_message)
    if _is_intake_mode(intake_mode) and intake_source == "explicit_request":
        return intake_mode
    inferred = infer_intent_by_keywords_fn(normalized_message)
    if _is_intake_mode(intake_mode) and intake_source == "fuzzy_intent" and inferred == "requirement_intake":
        if contains_any_text_fn(normalized_message, requirement_entry_structuring_terms):
            return intake_mode
        return intent or "default"
    if inferred == "intelligent_sourcing":
        return intent or "default"
    if inferred:
        return inferred
    return intent or "default"
