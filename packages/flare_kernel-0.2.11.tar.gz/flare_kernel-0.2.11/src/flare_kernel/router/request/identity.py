"""Request identity resolution helpers."""

from __future__ import annotations

from flare_kernel.contracts import KernelRequest


def resolve_project_id(req: KernelRequest, payload: dict[str, object]) -> str | None:
    if isinstance(req.project_id, str) and req.project_id.strip():
        return req.project_id.strip()
    project_id = payload.get("project_id")
    if isinstance(project_id, str) and project_id.strip():
        return project_id.strip()
    return None


def resolve_user_id(req: KernelRequest, payload: dict[str, object]) -> str | None:
    if isinstance(req.user_id, str) and req.user_id.strip():
        return req.user_id.strip()
    user_id = payload.get("user_id")
    if isinstance(user_id, str) and user_id.strip():
        return user_id.strip()
    return None
