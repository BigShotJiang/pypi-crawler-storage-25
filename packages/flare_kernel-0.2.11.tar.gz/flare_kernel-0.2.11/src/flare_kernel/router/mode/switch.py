"""Mode switch reason helper."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest


def build_mode_switch_reason(
    *,
    trace_id: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    intent_source: str = "",
    intent_confidence: float | None = None,
    intent_reason: str = "",
    req: KernelRequest,
    resolve_intent_override: Callable[[KernelRequest], str],
    resolve_manual_mode: Callable[[KernelRequest], str],
    resolve_current_mode: Callable[[KernelRequest], str],
) -> dict[str, Any]:
    intent_override = resolve_intent_override(req)
    manual_mode = resolve_manual_mode(req)
    current_mode = resolve_current_mode(req)
    source_label = {
        "intent_override": "外部意图",
        "intent": "意图识别",
        "manual": "手动开关",
        "current": "当前模式",
        "manual_hint": "手动模式提示",
        "current_hint": "历史模式提示",
        "active_intake": "进行中梳理",
        "source_grounding": "资料证据路径",
    }.get(mode_source, "默认路由")
    summary = f"本轮模式已切换为 {resolved_mode}（来源：{source_label}）"
    safe_confidence = 0.0
    if isinstance(intent_confidence, (float, int)):
        safe_confidence = max(0.0, min(1.0, float(intent_confidence)))
    return {
        "trace_id": trace_id,
        "mode_key": resolved_mode,
        "intent": resolved_intent,
        "source": mode_source,
        "intent_source": intent_source or "unknown",
        "intent_confidence": safe_confidence,
        "intent_reason": intent_reason,
        "intent_override": intent_override,
        "manual_mode": manual_mode,
        "current_mode": current_mode,
        "summary": summary,
    }
