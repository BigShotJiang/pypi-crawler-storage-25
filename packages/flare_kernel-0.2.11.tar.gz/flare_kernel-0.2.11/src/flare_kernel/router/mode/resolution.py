"""Resolve request mode candidates for kernel routing.

Module Responsibility:
    Normalize and prioritize mode candidates from command, intent, manual hints,
    and current-mode hints before router execution.

Primary Exports:
    normalize_mode_candidate, resolve_manual_mode, resolve_current_mode,
    resolve_request_mode.

Key Dependencies:
    - ``flare_kernel.contracts.KernelRequest`` as the request envelope.
    - Upstream command/intent resolver callbacks injected into
      ``resolve_request_mode``.

Core Path:
    Yes. This module is part of the request-mode decision path used by
    ``kernel_run`` and ``kernel_stream`` routing orchestration.
"""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest

_MODE_ALIASES: dict[str, str] = {
    "domain_workflow": "intelligent_sourcing",
    "domain_exploration": "intelligent_sourcing",
    "domain_analysis": "analysis_mode",
    "requirement_intake": "requirement_intake",
    "sourcing": "intelligent_sourcing",
}


def normalize_mode_candidate(raw_mode: Any, *, routable_modes: set[str]) -> str:
    """Normalize a raw mode candidate and validate it against routable modes.

    Args:
        raw_mode: Candidate mode value from request payload or upstream logic.
        routable_modes: Allowed mode keys in current runtime context.

    Returns:
        Normalized mode key when valid; otherwise an empty string.

    Side Effects:
        None.
    """
    if not isinstance(raw_mode, str):
        return ""
    normalized = raw_mode.strip().lower().replace("-", "_").replace(" ", "_")
    normalized = _MODE_ALIASES.get(normalized, normalized)
    if not normalized or normalized == "auto":
        return ""
    return normalized if normalized in routable_modes else ""


def resolve_manual_mode(
    req: KernelRequest,
    *,
    normalize_mode_candidate_fn: Callable[[Any], str],
) -> str:
    """Resolve manual-mode hint from request fields with precedence ordering.

    Args:
        req: Incoming kernel request.
        normalize_mode_candidate_fn: Candidate normalizer used to validate
            mode strings.

    Returns:
        First valid manual mode candidate; empty string if none is valid.

    Side Effects:
        None.

    Notes:
        Reads both top-level request fields and payload fallback fields for
        compatibility.
    """
    payload = req.payload if isinstance(req.payload, dict) else {}
    candidates = [
        req.manual_mode,
        payload.get("manual_mode"),
        req.mode,
        payload.get("mode"),
        payload.get("function_type"),
    ]
    for candidate in candidates:
        normalized = normalize_mode_candidate_fn(candidate)
        if normalized:
            return normalized
    return ""


def resolve_current_mode(
    req: KernelRequest,
    *,
    normalize_mode_candidate_fn: Callable[[Any], str],
) -> str:
    """Resolve current-mode hint from request context fields.

    Args:
        req: Incoming kernel request.
        normalize_mode_candidate_fn: Candidate normalizer used to validate
            mode strings.

    Returns:
        First valid current-mode hint; empty string if no valid hint exists.

    Side Effects:
        None.
    """
    payload = req.payload if isinstance(req.payload, dict) else {}
    candidates = [
        req.current_mode,
        payload.get("current_mode"),
        payload.get("last_mode"),
    ]
    for candidate in candidates:
        normalized = normalize_mode_candidate_fn(candidate)
        if normalized:
            return normalized
    return ""



def _has_source_grounding_route(req: KernelRequest) -> bool:
    payload = req.payload if isinstance(req.payload, dict) else {}
    source_grounding = payload.get("source_grounding") if isinstance(payload.get("source_grounding"), dict) else {}
    route = str(source_grounding.get("route") or "").strip()
    return source_grounding.get("active") is True and route == "source_grounded_answer"


def _resolve_mode_from_inferred_intent(resolved_intent: str) -> tuple[str, str]:
    if not resolved_intent:
        return "", ""
    if resolved_intent == "requirement_intake":
        return "default", "intent_suggestion"
    return resolved_intent, "intent"


def resolve_request_mode(
    req: KernelRequest,
    resolved_intent: str,
    *,
    resolve_command_fn: Callable[[KernelRequest], str],
    should_continue_active_intake_fn: Callable[[KernelRequest, str], bool],
    resolve_intent_override_fn: Callable[[KernelRequest], str],
    resolve_manual_mode_fn: Callable[[KernelRequest], str],
    resolve_current_mode_fn: Callable[[KernelRequest], str],
    resolve_explicit_intent_fn: Callable[[KernelRequest], str],
    normalize_mode_candidate_fn: Callable[[Any], str],
    resolve_analysis_route_fn: Callable[..., dict[str, Any]] | None = None,
) -> tuple[str, str]:
    """Resolve final request mode and decision source for router orchestration.

    Args:
        req: Incoming kernel request.
        resolved_intent: Intent-derived mode candidate from upstream stage.
        resolve_command_fn: Resolves command key from request.
        should_continue_active_intake_fn: Decides whether intake should continue
            regardless of hints.
        resolve_intent_override_fn: Resolves explicit intent override mode.
        resolve_manual_mode_fn: Resolves manual mode hint.
        resolve_current_mode_fn: Resolves current mode hint.
        resolve_explicit_intent_fn: Resolves explicit intent mode.
        normalize_mode_candidate_fn: Normalizes and validates mode candidates.

    Returns:
        A tuple ``(mode_key, source_key)`` where ``source_key`` indicates which
        precedence branch produced the final decision.

    Side Effects:
        None.

    Notes:
        This function is pure decision logic. It does not emit events, patch
        state, or call external services.
    """
    command = resolve_command_fn(req)
    if command == "activate_requirement_intake":
        return "requirement_intake", "command"
    if command in {"open_field_retrieval", "apply_field_candidate"}:
        return "requirement_intake", "command"
    if command == "generate_analysis":
        payload = req.payload if isinstance(req.payload, dict) else {}
        if callable(resolve_analysis_route_fn):
            raw_route = resolve_analysis_route_fn(
                message=str(payload.get("message") or payload.get("input") or ""),
                intent=resolved_intent,
                command=command,
                mode=str(req.mode or ""),
                payload=payload,
                retrieval_hit_count=0,
            )
            if isinstance(raw_route, dict):
                analysis_type = str(raw_route.get("analysis_type") or "").strip().lower()
                if analysis_type == "sourcing":
                    return "intelligent_sourcing", "command"
        return "analysis_mode", "command"
    if _has_source_grounding_route(req):
        return "default", "source_grounding"
    if should_continue_active_intake_fn(req, command):
        return "requirement_intake", "active_intake"

    intent_override = resolve_intent_override_fn(req)
    if intent_override:
        return intent_override, "intent_override"

    explicit_intent_mode = resolve_explicit_intent_fn(req)
    if explicit_intent_mode:
        return explicit_intent_mode, "intent"

    manual_mode = resolve_manual_mode_fn(req)
    if manual_mode:
        return manual_mode, "manual_hint"

    current_mode = resolve_current_mode_fn(req)
    if current_mode:
        return current_mode, "current_hint"

    normalized_resolved_intent = normalize_mode_candidate_fn(resolved_intent)
    inferred_mode, inferred_source = _resolve_mode_from_inferred_intent(normalized_resolved_intent)
    if inferred_source:
        return inferred_mode, inferred_source

    return "default", "fallback"
