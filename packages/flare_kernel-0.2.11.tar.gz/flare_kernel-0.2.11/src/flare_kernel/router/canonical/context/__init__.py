"""Facade for canonical state context assembly.

This module keeps the public entrypoint stable while delegating the work into
three readable stages:
1. normalize the incoming context inputs
2. derive session-scoped context material
3. assemble the canonical output consumed by the state builder

The contract assumption is that each helper is pure with respect to the input
payloads it receives; this facade only wires the stage outputs together.
"""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.canonical.context.analysis import (
    build_canonical_state_context_output,
)
from flare_kernel.router.canonical.context.inputs import (
    resolve_canonical_state_context_inputs,
)
from flare_kernel.router.canonical.context.session import (
    resolve_canonical_state_context_session,
)


def resolve_canonical_state_context(
    *,
    req: KernelRequest,
    command: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    orchestration_status: dict[str, Any],
    assistant_text: str,
    map_external_mode_fn: Callable[[str], str],
    resolve_session_intent_stage_fn: Callable[..., str],
    coerce_intent_escalation_policy_fn: Callable[[Any], dict[str, Any]],
    normalize_stage_status_fn: Callable[..., tuple[str, str]],
    is_field_entity_confirmed_fn: Callable[[Any], bool],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    normalize_intake_session_id_fn: Callable[[Any], str],
) -> dict[str, Any]:
    """Resolve the canonical context used by the canonical state builder.

    The function is intentionally thin: it does not infer policy, only
    sequences the normalization, session resolution, and output assembly
    stages so downstream callers can treat the result as a canonical snapshot.
    """
    # Stage 1: normalize the raw request and orchestration inputs into a
    # compact context bundle that subsequent helpers can consume consistently.
    context_inputs = resolve_canonical_state_context_inputs(
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        orchestration_status=orchestration_status,
        map_external_mode_fn=map_external_mode_fn,
        is_field_entity_confirmed_fn=is_field_entity_confirmed_fn,
    )
    # Stage 2: resolve the session-scoped fields that depend on the normalized
    # context and request/session metadata.
    context_session = resolve_canonical_state_context_session(
        req=req,
        command=command,
        resolved_intent=resolved_intent,
        mode_source=mode_source,
        orchestration_status=orchestration_status,
        assistant_text=assistant_text,
        context_inputs=context_inputs,
        map_external_mode_fn=map_external_mode_fn,
        resolve_session_intent_stage_fn=resolve_session_intent_stage_fn,
        coerce_intent_escalation_policy_fn=coerce_intent_escalation_policy_fn,
        normalize_stage_status_fn=normalize_stage_status_fn,
        extract_user_message_fn=extract_user_message_fn,
        normalize_intake_session_id_fn=normalize_intake_session_id_fn,
    )
    # Stage 3: assemble the final canonical payload that the state builder
    # consumes without having to re-run any normalization logic.
    return build_canonical_state_context_output(
        req=req,
        command=command,
        orchestration_status=orchestration_status,
        assistant_text=assistant_text,
        context_inputs=context_inputs,
        context_session=context_session,
        map_external_mode_fn=map_external_mode_fn,
    )
