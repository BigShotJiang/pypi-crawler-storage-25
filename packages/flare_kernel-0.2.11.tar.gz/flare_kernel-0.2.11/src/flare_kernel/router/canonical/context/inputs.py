"""Input normalization helpers for canonical state context assembly."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.router.canonical.projection import (
    collect_confirmed_field_values,
)
from flare_kernel.router.intent.compat_aliases import (
    project_compat_intent_type,
    project_domain_relevance,
    resolve_domain_intent_type,
    resolve_domain_relevance,
)


def resolve_canonical_state_context_inputs(
    *,
    resolved_intent: str,
    resolved_mode: str,
    orchestration_status: dict[str, Any],
    map_external_mode_fn: Callable[[str], str],
    is_field_entity_confirmed_fn: Callable[[Any], bool],
) -> dict[str, Any]:
    """Normalize raw orchestration status into shared context inputs."""
    external_mode = map_external_mode_fn(resolved_mode)
    inferred_stage = str(orchestration_status.get("current_stage") or "").strip()
    current_question = (
        orchestration_status.get("current_question")
        if isinstance(orchestration_status.get("current_question"), dict)
        else None
    )
    question_decision = (
        orchestration_status.get("question_decision")
        if isinstance(orchestration_status.get("question_decision"), dict)
        else {}
    )
    required_missing = [
        str(item).strip()
        for item in (
            orchestration_status.get("required_missing")
            if isinstance(orchestration_status.get("required_missing"), list)
            else []
        )
        if str(item).strip()
    ]
    fields, field_entities = collect_confirmed_field_values(
        orchestration_status=orchestration_status,
        is_field_entity_confirmed_fn=is_field_entity_confirmed_fn,
    )
    domain_relevance = resolve_domain_relevance(
        orchestration_status,
        default=(
            str(resolved_intent or "").strip() in {"requirement_intake", "intelligent_sourcing"}
            or str(resolved_mode or "").strip() in {"requirement_intake", "intelligent_sourcing"}
        ),
    )
    intent_type_domain = resolve_domain_intent_type(
        orchestration_status,
        default=("qa_only" if not domain_relevance else "domain_requirement_intake"),
    )
    escalation_target = str(orchestration_status.get("escalation_target") or "").strip()
    intake_candidate = bool(orchestration_status.get("intake_candidate"))
    clarification_recommended = bool(orchestration_status.get("clarification_recommended"))
    draft_seeded = bool(orchestration_status.get("draft_seeded"))
    missing_key_fields = [
        str(item).strip()
        for item in (
            orchestration_status.get("missing_key_fields")
            if isinstance(orchestration_status.get("missing_key_fields"), list)
            else []
        )
        if str(item).strip()
    ]
    if not missing_key_fields:
        missing_key_fields = list(required_missing)
    recommended_next_step = str(orchestration_status.get("recommended_next_step") or "").strip() or "continue_qa"
    analysis_ready = bool(orchestration_status.get("analysis_ready"))
    active_fields = [
        str(item).strip()
        for item in (
            orchestration_status.get("active_fields")
            if isinstance(orchestration_status.get("active_fields"), list)
            else []
        )
        if str(item).strip()
    ]
    hypotheses = [
        item
        for item in (
            orchestration_status.get("hypotheses")
            if isinstance(orchestration_status.get("hypotheses"), list)
            else []
        )
        if isinstance(item, dict)
    ]
    planner = (
        orchestration_status.get("planner")
        if isinstance(orchestration_status.get("planner"), dict)
        else None
    )
    return {
        "active_fields": active_fields,
        "analysis_ready": analysis_ready,
        "clarification_recommended": clarification_recommended,
        "current_question": current_question,
        "question_decision": question_decision,
        "draft_seeded": draft_seeded,
        "escalation_target": escalation_target,
        "external_mode": external_mode,
        "field_entities": field_entities,
        "fields": fields,
        "inferred_stage": inferred_stage,
        "intake_candidate": intake_candidate,
        **project_compat_intent_type(intent_type_domain),
        "hypotheses": hypotheses,
        "missing_key_fields": missing_key_fields,
        "planner": planner,
        **project_domain_relevance(domain_relevance),
        "recommended_next_step": recommended_next_step,
        "required_missing": required_missing,
    }
