"""Analysis and checkpoint assembly helpers for canonical state context."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.canonical.flow import (
    resolve_analysis_generation_state,
)
from flare_kernel.router.canonical.projection import (
    build_checkpoint_projection,
    build_next_actions_projection,
    resolve_analysis_readiness_metrics,
)
from flare_kernel.router.intent.compat_aliases import (
    project_compat_intent_type,
    project_domain_relevance,
    resolve_domain_intent_type,
    resolve_domain_relevance,
)
from flare_kernel.router.orchestration.status.analysis_entry_decision import (
    build_analysis_entry_decision,
)


def _coerce_count(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


def build_canonical_state_context_output(
    *,
    req: KernelRequest,
    command: str,
    orchestration_status: dict[str, Any],
    assistant_text: str,
    context_inputs: dict[str, Any],
    context_session: dict[str, Any],
    map_external_mode_fn: Callable[[str], str],
) -> dict[str, Any]:
    """Assemble the final canonical state context payload."""
    activated_mode = map_external_mode_fn(str(context_session["activated_mode"] or "auto"))
    next_actions = build_next_actions_projection(
        orchestration_status=orchestration_status,
        intake_session_id=str(context_session["intake_session_id"] or ""),
        intake_session_state=str(context_session["intake_session_state"] or ""),
        intake_session_completed=bool(context_session["intake_session_completed"]),
        status_key=str(context_session["status_key"] or ""),
        map_external_mode_fn=map_external_mode_fn,
    )
    readiness_metrics = resolve_analysis_readiness_metrics(orchestration_status)
    total_coverage = float(readiness_metrics.get("total_coverage") or 0.0)
    required_coverage = float(readiness_metrics.get("required_coverage") or 0.0)
    analysis_entry_threshold = float(readiness_metrics.get("analysis_entry_threshold") or 0.8)
    analyzability_score = float(readiness_metrics.get("analyzability_score") or 0.0)
    analysis_entry_eligible = bool(readiness_metrics.get("analysis_entry_eligible")) or bool(
        context_inputs.get("analysis_ready")
    )
    analysis_entry_decision = (
        orchestration_status.get("analysis_entry_decision")
        if isinstance(orchestration_status.get("analysis_entry_decision"), dict)
        else build_analysis_entry_decision(
            fields=context_inputs["fields"],
            normalized_required_missing=list(context_inputs["required_missing"]),
            retrieval_hit_count=_coerce_count(orchestration_status.get("search_retrieval_hit_count")),
            analysis_entry_eligible=analysis_entry_eligible,
            analyzability_score=analyzability_score,
            analysis_entry_threshold=analysis_entry_threshold,
        )
    )
    # DOC HELPER — canonical context preserves the backend decision boundary.
    # The generate-analysis gate and canvas readiness projection both consume
    # this object, keeping analysis entry behavior aligned across clients.
    analysis_generation_state = resolve_analysis_generation_state(
        command=command,
        activated_mode=activated_mode,
        required_missing=list(context_inputs["required_missing"]),
        analysis_entry_eligible=analysis_entry_eligible,
        analysis_ready=bool(context_inputs["analysis_ready"]),
        has_fields=bool(context_inputs["fields"]),
        stage_key=str(context_session["stage_key"] or ""),
        status_key=str(context_session["status_key"] or ""),
        analysis_entry_decision=analysis_entry_decision,
    )
    can_generate = bool(analysis_generation_state.get("can_generate"))
    analysis_assumptions = [
        str(item)
        for item in (
            analysis_generation_state.get("analysis_assumptions")
            if isinstance(analysis_generation_state.get("analysis_assumptions"), list)
            else []
        )
        if str(item).strip()
    ]
    errors = [
        item
        for item in (
            analysis_generation_state.get("errors")
            if isinstance(analysis_generation_state.get("errors"), list)
            else []
        )
        if isinstance(item, dict)
    ]
    checkpoint = build_checkpoint_projection(
        orchestration_status=orchestration_status,
        intake_session_id=str(context_session["intake_session_id"] or ""),
        status_key=str(context_session["status_key"] or ""),
        current_question=context_session["current_question"],
        fields=context_inputs["fields"],
        required_missing=list(context_inputs["required_missing"]),
        session_id=str(req.session_id or ""),
        activated_mode=str(context_session["activated_mode"] or "auto"),
    )
    if not isinstance(checkpoint, dict) or not checkpoint:
        checkpoint = {
            "checkpoint_id": "",
            "intake_session_id": str(context_session["intake_session_id"] or ""),
            "session_id": str(req.session_id or ""),
            "mode": str(context_session["activated_mode"] or "auto"),
            "status": str(context_session["status_key"] or ""),
            "version": 1,
            "checkpoints": [],
        }
    active_fields = (
        list(context_inputs.get("active_fields"))
        if isinstance(context_inputs.get("active_fields"), list)
        else []
    )
    hypotheses = (
        list(context_inputs.get("hypotheses"))
        if isinstance(context_inputs.get("hypotheses"), list)
        else []
    )
    planner = (
        context_inputs.get("planner")
        if isinstance(context_inputs.get("planner"), dict)
        else {}
    )
    domain_relevance = resolve_domain_relevance(context_inputs)
    intent_type_domain = resolve_domain_intent_type(context_inputs, default="qa_only")
    return {
        "active_fields": active_fields,
        "analysis_assumptions": analysis_assumptions,
        "analysis_entry_decision": analysis_entry_decision,
        "analysis_entry_eligible": analysis_entry_eligible,
        "analysis_entry_threshold": analysis_entry_threshold,
        "analysis_ready": bool(context_inputs["analysis_ready"]),
        "analyzability_score": analyzability_score,
        "can_generate": can_generate,
        "checkpoint": checkpoint,
        "clarification_recommended": bool(context_inputs["clarification_recommended"]),
        "conversation_intent_state": context_session["conversation_intent_state"],
        "current_question": context_session["current_question"],
        "draft_seeded": bool(context_inputs["draft_seeded"]),
        "errors": errors,
        "explicit_activation": bool(context_session["explicit_activation"]),
        "field_entities": context_inputs["field_entities"],
        "fields": context_inputs["fields"],
        "hypotheses": hypotheses,
        "intake_candidate": bool(context_inputs["intake_candidate"]),
        "intake_session_completed": bool(context_session["intake_session_completed"]),
        "intake_session_id": context_session["intake_session_id"],
        "intake_session_state": context_session["intake_session_state"],
        **project_compat_intent_type(intent_type_domain),
        "missing_key_fields": list(context_inputs["missing_key_fields"]),
        "next_actions": next_actions,
        "planner": planner,
        **project_domain_relevance(domain_relevance),
        "question_decision": context_inputs.get("question_decision")
        if isinstance(context_inputs.get("question_decision"), dict)
        else {},
        "recommended_next_step": str(context_inputs["recommended_next_step"] or ""),
        "required_coverage": required_coverage,
        "required_missing": list(context_inputs["required_missing"]),
        "resolved_intent_escalation_policy": context_session["resolved_intent_escalation_policy"],
        "resolved_intent_escalation_policy_source": context_session["resolved_intent_escalation_policy_source"],
        "session_intent_stage": context_session["session_intent_stage"],
        "stage_key": context_session["stage_key"],
        "status_key": context_session["status_key"],
        "suggested_mode": context_session["suggested_mode"],
        "total_coverage": total_coverage,
        "activated_mode": context_session["activated_mode"],
        "escalation_target": str(context_inputs["escalation_target"] or ""),
    }
