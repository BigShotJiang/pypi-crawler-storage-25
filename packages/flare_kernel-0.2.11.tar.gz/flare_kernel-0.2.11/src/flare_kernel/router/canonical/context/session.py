"""Session and activation helpers for canonical state context assembly."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.canonical.flow import (
    normalize_stage_status_and_question,
    resolve_flow_activation,
)


def resolve_canonical_state_context_session(
    *,
    req: KernelRequest,
    command: str,
    resolved_intent: str,
    mode_source: str,
    orchestration_status: dict[str, Any],
    assistant_text: str,
    context_inputs: dict[str, Any],
    map_external_mode_fn: Callable[[str], str],
    resolve_session_intent_stage_fn: Callable[..., str],
    coerce_intent_escalation_policy_fn: Callable[[Any], dict[str, Any]],
    normalize_stage_status_fn: Callable[..., tuple[str, str]],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    normalize_intake_session_id_fn: Callable[[Any], str],
) -> dict[str, Any]:
    """Resolve intent stage, activation, and session-level context values."""
    session_intent_stage = resolve_session_intent_stage_fn(
        signal=orchestration_status,
        orchestration_status=orchestration_status,
        message=extract_user_message_fn(req.payload),
        command=command,
    )
    resolved_intent_escalation_policy = coerce_intent_escalation_policy_fn(
        orchestration_status.get("intent_escalation_policy")
        if isinstance(orchestration_status.get("intent_escalation_policy"), dict)
        else {}
    )
    resolved_intent_escalation_policy_source = str(
        orchestration_status.get("intent_escalation_policy_source") or "default"
    ).strip() or "default"
    flow_activation = resolve_flow_activation(
        command=command,
        mode_source=mode_source,
        resolved_intent=resolved_intent,
        external_mode=context_inputs["external_mode"],
        inferred_stage=context_inputs["inferred_stage"],
        intake_candidate=bool(context_inputs["intake_candidate"]),
        clarification_recommended=bool(context_inputs["clarification_recommended"]),
        escalation_target=str(context_inputs["escalation_target"] or ""),
        analysis_ready=bool(context_inputs["analysis_ready"]),
        required_missing=list(context_inputs["required_missing"]),
        current_question=context_inputs["current_question"] if isinstance(context_inputs["current_question"], dict) else None,
        fields=context_inputs["fields"],
        map_external_mode_fn=map_external_mode_fn,
    )
    explicit_activation = bool(flow_activation.get("explicit_activation"))
    activated_mode = str(flow_activation.get("activated_mode") or "auto")
    suggested_mode = flow_activation.get("suggested_mode")
    intake_session_id = normalize_intake_session_id_fn(orchestration_status.get("intake_session_id"))
    intake_session_state = str(orchestration_status.get("intake_session_state") or "").strip()
    intake_session_completed = bool(orchestration_status.get("intake_session_completed"))
    stage_key, status_key, current_question = normalize_stage_status_and_question(
        orchestration_status=orchestration_status,
        required_missing=list(context_inputs["required_missing"]),
        activated_mode=activated_mode,
        current_question=context_inputs["current_question"] if isinstance(context_inputs["current_question"], dict) else None,
        command=command,
        assistant_text=assistant_text,
        intake_session_id=intake_session_id,
        normalize_stage_status_fn=normalize_stage_status_fn,
    )
    return {
        "activated_mode": activated_mode,
        "conversation_intent_state": session_intent_stage,
        "current_question": current_question,
        "explicit_activation": explicit_activation,
        "intake_session_completed": intake_session_completed,
        "intake_session_id": intake_session_id,
        "intake_session_state": intake_session_state,
        "resolved_intent_escalation_policy": resolved_intent_escalation_policy,
        "resolved_intent_escalation_policy_source": resolved_intent_escalation_policy_source,
        "session_intent_stage": session_intent_stage,
        "stage_key": stage_key,
        "status_key": status_key,
        "suggested_mode": suggested_mode,
    }
