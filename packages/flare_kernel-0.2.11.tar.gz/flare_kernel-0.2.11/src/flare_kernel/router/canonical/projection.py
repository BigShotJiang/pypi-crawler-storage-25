"""Helpers for canonical-state projection assembly."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.router.canonical.analysis import (
    apply_analysis_and_retrieval_projection,
)
from flare_kernel.router.canonical.checkpoint import (
    build_checkpoint_projection,
)
from flare_kernel.router.next_actions_guard import dedupe_next_actions_by_action_key

_POST_INTAKE_INTERNAL_ACTION_KEYS = {
    "activate_requirement_intake",
    "continue_collection",
    "implement",
}


def normalize_retrieved_knowledge(
    structured_retrieved_knowledge: list[dict[str, Any]] | None,
) -> list[dict[str, Any]]:
    if not isinstance(structured_retrieved_knowledge, list):
        return []
    return [item for item in structured_retrieved_knowledge if isinstance(item, dict)]


def collect_confirmed_field_values(
    *,
    orchestration_status: dict[str, Any],
    is_field_entity_confirmed_fn: Callable[[Any], bool],
) -> tuple[dict[str, str], dict[str, Any]]:
    fields: dict[str, str] = {}
    confirmed_updates = (
        orchestration_status.get("confirmed_updates")
        if isinstance(orchestration_status.get("confirmed_updates"), list)
        else []
    )
    for item in confirmed_updates:
        if not isinstance(item, dict):
            continue
        field_key = str(item.get("field_key") or "").strip()
        field_value = str(item.get("field_value") or "").strip()
        if field_key and field_value:
            fields[field_key] = field_value
    field_entities = (
        orchestration_status.get("field_entities")
        if isinstance(orchestration_status.get("field_entities"), dict)
        else {}
    )
    for key, entity in field_entities.items():
        field_key = str(key or "").strip()
        if not field_key or not isinstance(entity, dict):
            continue
        if field_key in fields:
            continue
        if not is_field_entity_confirmed_fn(entity):
            continue
        display_value = str(entity.get("display_value") or "").strip()
        if display_value:
            fields[field_key] = display_value
    return fields, field_entities


def _action_key(action: dict[str, Any]) -> str:
    return str(action.get("action_key") or action.get("type") or "").strip()


def filter_post_intake_next_actions(
    actions: list[dict[str, Any]],
    *,
    intake_session_completed: bool,
) -> list[dict[str, Any]]:
    filtered = [item for item in actions if isinstance(item, dict)]
    if not intake_session_completed:
        return filtered
    return [
        item for item in filtered
        if _action_key(item) not in _POST_INTAKE_INTERNAL_ACTION_KEYS
    ]


def resolve_canonical_next_actions(
    *,
    runtime_actions: list[dict[str, Any]],
    context_actions: list[dict[str, Any]],
    track_actions: list[dict[str, Any]],
    intake_session_completed: bool,
) -> list[dict[str, Any]]:
    for actions in (runtime_actions, context_actions, track_actions):
        resolved = filter_post_intake_next_actions(
            actions,
            intake_session_completed=intake_session_completed,
        )
        if resolved:
            return resolved
    return []


def build_next_actions_projection(
    *,
    orchestration_status: dict[str, Any],
    intake_session_id: str,
    intake_session_state: str,
    intake_session_completed: bool,
    status_key: str,
    map_external_mode_fn: Callable[[str], str],
) -> list[dict[str, Any]]:
    next_actions: list[dict[str, Any]] = []
    raw_actions = (
        orchestration_status.get("next_actions")
        if isinstance(orchestration_status.get("next_actions"), list)
        else []
    )
    for action in dedupe_next_actions_by_action_key(raw_actions):
        if not isinstance(action, dict):
            continue
        action_key = str(action.get("action_key") or action.get("type") or "").strip()
        if not action_key:
            continue
        if intake_session_completed and action_key in _POST_INTAKE_INTERNAL_ACTION_KEYS:
            continue
        # DOC HELPER — action visibility is decision-driven.
        # Do not hide analysis actions by workflow stage here; status/readiness
        # must already reflect analysis_entry_decision from orchestration.
        if str(action.get("readiness_level") or "").strip() == "hidden":
            continue
        if str(action.get("status") or "").strip() == "hidden":
            continue
        mapped_command = {
            "continue_collection": "activate_requirement_intake",
            "handoff_to_sourcing": "send_message",
            "handoff_to_domain_flow": "send_message",
            "investigate_evidence": "open_field_retrieval",
            "confirm_sourcing": "send_message",
            "confirm_domain_flow": "send_message",
            "confirm_plan": "generate_analysis",
        }.get(action_key, action_key)
        projected = {
            "action_key": action_key,
            "label": str(action.get("label") or action_key),
            "status": str(action.get("status") or "available"),
            "intake_session_id": intake_session_id,
            "intake_session_state": intake_session_state,
            "intake_session_completed": intake_session_completed,
            "command": mapped_command,
            "payload": {
                "intake_session_id": intake_session_id,
                "intake_session_state": intake_session_state,
                "intake_session_completed": intake_session_completed,
                **(action.get("payload") if isinstance(action.get("payload"), dict) else {}),
                "target_mode": map_external_mode_fn(str(action.get("target_mode") or "")),
            },
        }
        for key in ("reason", "source", "target_field", "blocking_reason", "policy_id", "owner_module"):
            value = action.get(key)
            if value is not None:
                projected[key] = value
        if action.get("confidence") is not None:
            projected["confidence"] = action.get("confidence")
        next_actions.append(projected)
    return next_actions


def _clamp_float(value: Any, *, default: float) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default


def resolve_analysis_readiness_metrics(orchestration_status: dict[str, Any]) -> dict[str, Any]:
    total_coverage = _clamp_float(orchestration_status.get("total_coverage"), default=0.0)
    required_coverage = _clamp_float(orchestration_status.get("required_coverage"), default=0.0)
    analysis_entry_threshold = _clamp_float(orchestration_status.get("analysis_entry_threshold"), default=0.8)
    analyzability_score = _clamp_float(orchestration_status.get("analyzability_score"), default=0.0)
    analysis_entry_eligible = bool(
        orchestration_status.get("analysis_entry_eligible") is True
        or analyzability_score >= analysis_entry_threshold
        or total_coverage >= analysis_entry_threshold
    )
    return {
        "total_coverage": total_coverage,
        "required_coverage": required_coverage,
        "analysis_entry_threshold": analysis_entry_threshold,
        "analyzability_score": analyzability_score,
        "analysis_entry_eligible": analysis_entry_eligible,
    }
