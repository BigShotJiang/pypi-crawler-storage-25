"""Canonical context authority projection for frontend consumers.

DOC HELPER — OBJ-09 SSOT boundary.
This module exposes who owns authoritative context for a turn. It does not
mutate context, read repositories, or infer workflow state; it only projects
backend runtime context metadata into a stable payload section.
"""

from __future__ import annotations

from typing import Any


def _as_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _count_list(value: Any) -> int:
    return len(value) if isinstance(value, list) else 0


def _build_graph_counts(context: dict[str, Any]) -> dict[str, int]:
    archive_summary = _as_mapping(context.get("archive_summary"))
    relationship_graph = _as_mapping(archive_summary.get("relationship_graph"))
    return {
        "graph_nodes": _count_list(relationship_graph.get("nodes")),
        "graph_edges": _count_list(relationship_graph.get("edges")),
    }


def build_context_authority_projection(runtime_snapshot: dict[str, Any] | None) -> dict[str, Any]:
    """Return a stable authority descriptor for canonical payloads.

    DOC HELPER — this is a presentation contract, not a writer. Frontend code
    may display these values, but must not use them to replace backend session
    context or invent authoritative workflow state.
    """

    runtime = _as_mapping(runtime_snapshot)
    context = _as_mapping(runtime.get("session_context"))
    counts = {
        "facts": _count_list(context.get("facts")),
        "unknowns": _count_list(context.get("unknowns")),
        "evidence": _count_list(context.get("evidence")),
        "turns": _count_list(context.get("turns")),
        "artifact_context": _count_list(context.get("artifact_context")),
        **_build_graph_counts(context),
    }
    return {
        "schema_version": "context_authority.v1",
        "owner": "backend",
        "authoritative": True,
        "source": "session_context" if context else "empty_context",
        "frontend_policy": "projection_only",
        "persistence": {
            "available": bool(context),
            "context_revision_id": str(context.get("context_revision_id") or ""),
            "updated_at": str(context.get("updated_at") or ""),
        },
        "counts": counts,
    }


__all__ = ["build_context_authority_projection"]
