"""Track decision to canonical next-action projection.

DOC HELPER — ORC-10 boundary.
This module only projects an already-resolved generic track decision into the
canonical `next_actions` contract. It does not choose a track, advance workflow
state, or encode domain/business-specific actions.
"""

from __future__ import annotations

from typing import Any


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_action_list(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _action_key(action: dict[str, Any]) -> str:
    payload = _coerce_mapping(action.get("payload"))
    explicit = _clean_text(payload.get("action_key") or action.get("action_key"))
    if explicit:
        return explicit
    action_type = _clean_text(action.get("action_type")).lower()
    capability = _clean_text(action.get("capability"))
    if action_type == "ask":
        return "continue_collection"
    if action_type == "analyze":
        return "confirm_plan"
    if action_type == "search":
        return "handoff_to_domain_flow"
    if capability:
        return f"activate_{capability}"
    return action_type or "continue_task"


def _command(action_type: str) -> str:
    if action_type == "analyze":
        return "generate_analysis"
    return "send_message"


def build_track_next_actions(track_result: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Project generic track actions into the canonical `next_actions` contract."""

    track = _coerce_mapping(track_result)
    actions = _as_action_list(track.get("next_actions"))
    readiness = _coerce_mapping(track.get("readiness"))
    projected: list[dict[str, Any]] = []
    for action in actions:
        action_type = _clean_text(action.get("action_type")).lower()
        action_key = _action_key(action)
        capability = _clean_text(action.get("capability"))
        payload = _coerce_mapping(action.get("payload"))
        blocking_gaps = _as_list(action.get("blocking_gaps") or readiness.get("blocking_gaps"))
        non_blocking_gaps = _as_list(action.get("non_blocking_gaps") or readiness.get("non_blocking_gaps"))
        projected.append(
            {
                "action_key": action_key,
                "label": _clean_text(action.get("label")) or action_key,
                "status": "available",
                "command": _command(action_type),
                "target_mode": _clean_text(payload.get("target_mode")) or capability,
                "reason": _clean_text(action.get("reason")) or _clean_text(readiness.get("reason")),
                "source": "track_decision",
                "confidence": action.get("score") or action.get("readiness_score"),
                "readiness_score": action.get("readiness_score") or readiness.get("readiness_score"),
                "readiness_level": action.get("readiness_level") or readiness.get("readiness_level"),
                "payload": {
                    **payload,
                    "source": "track_decision",
                    "track_id": _clean_text(track.get("track_id")),
                    "track_key": _clean_text(track.get("track_key")),
                    "current_step_id": _clean_text(track.get("current_step_id")),
                    "target_mode": _clean_text(payload.get("target_mode")) or capability,
                    "blocking_gaps": blocking_gaps,
                    "non_blocking_gaps": non_blocking_gaps,
                },
            }
        )
    return projected


__all__ = ["build_track_next_actions"]
