"""Canonical payload assembly extracted from builder.

DOC HELPER — OBJ-09 canonical authority boundary.
Canonical payload assembly attaches backend context authority projection; it
does not persist context or let transport/frontend invent workflow state.
"""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.canonical.contract_support import (
    coerce_action_list,
    coerce_mapping,
    resolve_authoritative_runtime_payload,
    resolve_canvas_analysis_payload,
)
from flare_kernel.router.canonical.composer_ui import build_composer_ui_projection
from flare_kernel.router.canonical.context_authority import build_context_authority_projection
from flare_kernel.router.canonical.projection import resolve_canonical_next_actions
from flare_kernel.router.canonical.track_actions import build_track_next_actions
from flare_kernel.router.intake.status.projection import (
    build_round_projection,
)
from flare_kernel.router.intent.compat_aliases import (
    project_compat_intent_type,
    project_domain_relevance,
    resolve_domain_intent_type,
    resolve_domain_relevance,
)

def _normalize_canonical_mode(value: str) -> str:
    normalized = str(value or "auto").strip().lower().replace("-", "_").replace(" ", "_")
    return normalized or "auto"


def _resolve_analysis_title(*, command: str, can_generate: bool, orchestration_status: dict[str, Any]) -> str:
    if command != "generate_analysis" or not can_generate:
        return ""
    analysis_route = orchestration_status.get("analysis_route")
    if isinstance(analysis_route, dict):
        if str(analysis_route.get("analysis_type") or "").strip().lower() == "sourcing":
            return "寻源分析"
    return "需求分析"


def build_canonical_payload(
    *,
    req: KernelRequest,
    command: str,
    mode_source: str,
    orchestration_status: dict[str, Any],
    assistant_text: str,
    provider_status: str,
    canonical_context: dict[str, Any],
    build_confirmed_fields_schema_fn: Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]],
    build_missing_fields_schema_fn: Callable[[list[str]], dict[str, Any]],
    resolve_trace_id_fn: Callable[[str | None], str],
    safe_session_id_fn: Callable[[Any], str],
    runtime_snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    fields = canonical_context.get("fields") if isinstance(canonical_context.get("fields"), dict) else {}
    field_entities = canonical_context.get("field_entities") if isinstance(canonical_context.get("field_entities"), dict) else {}
    required_missing = canonical_context.get("required_missing") if isinstance(canonical_context.get("required_missing"), list) else []
    intake_session_id = str(canonical_context.get("intake_session_id") or "").strip()
    intake_session_state = str(canonical_context.get("intake_session_state") or "").strip()
    intake_session_completed = bool(canonical_context.get("intake_session_completed"))
    can_generate = bool(canonical_context.get("can_generate"))
    explicit_activation = bool(canonical_context.get("explicit_activation"))
    activated_mode = _normalize_canonical_mode(str(canonical_context.get("activated_mode") or "auto"))
    stage_key = str(canonical_context.get("stage_key") or "").strip()
    status_key = str(canonical_context.get("status_key") or "").strip()
    current_question = canonical_context.get("current_question") if isinstance(canonical_context.get("current_question"), dict) else None
    next_actions = canonical_context.get("next_actions") if isinstance(canonical_context.get("next_actions"), list) else []
    authoritative_runtime_payload = resolve_authoritative_runtime_payload(
        runtime_snapshot=runtime_snapshot,
        canonical_context=canonical_context,
        activated_mode=activated_mode,
        status_key=status_key,
        current_question=current_question,
        next_actions=next_actions,
    )
    authoritative_current_question = (
        authoritative_runtime_payload.get("current_question")
        if isinstance(authoritative_runtime_payload.get("current_question"), dict)
        else None
    )
    if intake_session_completed:
        authoritative_current_question = None
    question_decision = (
        authoritative_runtime_payload.get("question_decision")
        if isinstance(authoritative_runtime_payload.get("question_decision"), dict)
        else {}
    )
    track_result = (
        authoritative_runtime_payload.get("track_result")
        if isinstance(authoritative_runtime_payload.get("track_result"), dict)
        else {}
    )
    response_strategy_result = (
        authoritative_runtime_payload.get("response_strategy_result")
        if isinstance(authoritative_runtime_payload.get("response_strategy_result"), dict)
        else {}
    )
    runtime_payload = coerce_mapping(coerce_mapping(runtime_snapshot).get("payload"))
    # DOC HELPER — ORC-10: track-derived actions are a backend fallback only
    # when no runtime/canonical next_actions exist. UI must not infer these.
    authoritative_next_actions = resolve_canonical_next_actions(
        runtime_actions=coerce_action_list(runtime_payload.get("next_actions")),
        context_actions=next_actions,
        track_actions=build_track_next_actions(track_result),
        intake_session_completed=intake_session_completed,
    )
    module_prompt_registry = coerce_action_list(authoritative_runtime_payload.get("module_prompt_registry"))
    current_question = authoritative_current_question
    next_actions = authoritative_next_actions
    projected_activated_mode = "auto" if intake_session_completed else activated_mode
    projected_suggested_mode = None if intake_session_completed else canonical_context.get("suggested_mode")
    composer_ui = build_composer_ui_projection(
        activated_mode=projected_activated_mode,
        mode_source=mode_source,
        stage_key=stage_key,
        status_key=status_key,
        current_question=current_question,
        required_missing=required_missing,
        next_actions=next_actions,
    )
    chooser_state = composer_ui["chooser_state"]
    round_projection = build_round_projection(
        intake_session_id=intake_session_id,
        stage_key=stage_key,
        status_key=status_key,
        intake_session_state=intake_session_state,
        current_question=current_question,
        checkpoint=canonical_context.get("checkpoint") if isinstance(canonical_context.get("checkpoint"), dict) else {},
        next_actions=next_actions,
    )
    domain_relevance = resolve_domain_relevance(canonical_context)
    intent_type_domain = resolve_domain_intent_type(canonical_context, default="qa_only")
    followup_question = authoritative_runtime_payload.get("followup_question")
    if not isinstance(followup_question, dict):
        followup_question = {}

    canvas_analysis_payload = resolve_canvas_analysis_payload(
        orchestration_status=orchestration_status,
        runtime_snapshot=runtime_snapshot,
    )
    analysis_entry_decision = (
        canonical_context.get("analysis_entry_decision")
        if isinstance(canonical_context.get("analysis_entry_decision"), dict)
        else {}
    )
    analysis_entry_reasons = (
        analysis_entry_decision.get("reasons")
        if isinstance(analysis_entry_decision.get("reasons"), list)
        else []
    )
    # DOC HELPER — expose analysis_entry_decision as the readiness contract.
    # Frontend canvas/tabs/cards should render this projection and must not
    # recompute business readiness locally.
    analysis_projection = {
        "readiness": {
            "can_generate": can_generate,
            "entry_level": str(analysis_entry_decision.get("entry_level") or ""),
            "score": float(analysis_entry_decision.get("score") or 0.0),
            "reason": str((analysis_entry_reasons or [""])[0] or "")
            or ("" if can_generate else "关键字段不足且清晰度未达到建议阈值"),
            "blocking_fields": analysis_entry_decision.get("blocking_fields")
            if isinstance(analysis_entry_decision.get("blocking_fields"), list)
            else [str(item) for item in required_missing if str(item).strip()],
            "required_coverage": float(canonical_context.get("required_coverage") or 0.0),
            "total_coverage": float(canonical_context.get("total_coverage") or 0.0),
            "analysis_entry_threshold": float(canonical_context.get("analysis_entry_threshold") or 0.8),
            "analysis_entry_eligible": bool(canonical_context.get("analysis_entry_eligible")),
            "analyzability_score": float(canonical_context.get("analyzability_score") or 0.0),
            "decision": analysis_entry_decision,
        },
        "title": _resolve_analysis_title(
            command=command,
            can_generate=can_generate,
            orchestration_status=orchestration_status,
        ),
        "sections": [],
        "assumptions": canonical_context.get("analysis_assumptions")
        if isinstance(canonical_context.get("analysis_assumptions"), list)
        else [],
    }
    assistant_reply_text = str(assistant_text or "")
    normalized_command = str(command or "").strip().lower()
    if activated_mode == "requirement_intake" and normalized_command not in {"implement", "apply"}:
        assistant_reply_text = ""

    return {
        "mode_key": authoritative_runtime_payload.get("mode_key") or activated_mode,
        "mode_state": authoritative_runtime_payload.get("mode_state") or status_key,
        "contract_version": str(req.contract_version or "flare.v1"),
        "trace_id": resolve_trace_id_fn(req.trace_id),
        "client_request_id": req.client_request_id or "",
        "session": {
            "session_id": safe_session_id_fn(req.session_id),
            "turn_id": str(req.last_turn_id or ""),
        },
        "assistant_reply": {
            "text": assistant_reply_text,
            "type": "normal" if str(assistant_reply_text or "").strip() else "system_notice",
            "is_placeholder": provider_status == "placeholder",
        },
        "context_authority": build_context_authority_projection(runtime_snapshot),
        "primary_flow": {
            "mode": {
                "suggested": projected_suggested_mode,
                "activated": projected_activated_mode,
                "is_activation_explicit": explicit_activation and projected_activated_mode != "auto",
                "activation_source": mode_source if explicit_activation else "none",
            },
            "stage": stage_key,
            "status": status_key,
            "chooser_state": chooser_state,
            "composer_ui": composer_ui,
            "intake_session_id": intake_session_id,
            "intake_session_state": intake_session_state,
            "intake_session_completed": intake_session_completed,
            "checkpoint": canonical_context.get("checkpoint"),
            **round_projection,
        },
        "checkpoint": canonical_context.get("checkpoint"),
        "intent_state": {
            **project_compat_intent_type(intent_type_domain),
            "session_intent_stage": str(canonical_context.get("session_intent_stage") or ""),
            "conversation_intent_state": str(canonical_context.get("conversation_intent_state") or ""),
            **project_domain_relevance(domain_relevance),
            "escalation_target": str(canonical_context.get("escalation_target") or "")
            or ("qa_only" if not domain_relevance else "intake_candidate"),
            "intake_candidate": bool(canonical_context.get("intake_candidate")),
            "clarification_recommended": bool(canonical_context.get("clarification_recommended")),
            "analysis_ready": bool(canonical_context.get("analysis_ready")),
            "draft_seeded": bool(canonical_context.get("draft_seeded")),
            "missing_key_fields": canonical_context.get("missing_key_fields") if isinstance(canonical_context.get("missing_key_fields"), list) else [],
            "recommended_next_step": str(canonical_context.get("recommended_next_step") or "continue_qa"),
            "intent_escalation_policy": canonical_context.get("resolved_intent_escalation_policy")
            if isinstance(canonical_context.get("resolved_intent_escalation_policy"), dict)
            else {},
            "intent_escalation_policy_source": str(
                canonical_context.get("resolved_intent_escalation_policy_source") or "default"
            ),
        },
        "question": authoritative_current_question,
        "confirmed_fields": build_confirmed_fields_schema_fn(fields, field_entities),
        "missing_fields": build_missing_fields_schema_fn([str(item) for item in required_missing if str(item).strip()]),
        "current_question": authoritative_current_question,
        "followup_question": followup_question,
        "question_decision": question_decision,
        "next_actions": authoritative_next_actions,
        "composer_ui": composer_ui,
        "track_result": track_result,
        "response_strategy_result": response_strategy_result,
        "module_prompt_registry": module_prompt_registry,
        "analysis": analysis_projection,
        "canvas_analysis_payload": canvas_analysis_payload,
        "analysis_payload": canvas_analysis_payload,
        "analysis_slot_patches": (
            orchestration_status.get("analysis_slot_patches")
            if isinstance(orchestration_status.get("analysis_slot_patches"), list)
            else []
        ),
        "observation": {
            "active_fields": canonical_context.get("active_fields")
            if isinstance(canonical_context.get("active_fields"), list)
            else [],
            "hypotheses": canonical_context.get("hypotheses")
            if isinstance(canonical_context.get("hypotheses"), list)
            else [],
            "planner": canonical_context.get("planner")
            if isinstance(canonical_context.get("planner"), dict)
            else None,
        },
        "capabilities": {
            "field_retrieval": {
                "active": command in {"open_field_retrieval", "apply_field_candidate"},
                "field_key": str((req.payload or {}).get("field_key") or req.field_key or ""),
                "comparison_rows": [],
                "recommendation_summary": "",
            }
        },
        "errors": canonical_context.get("errors") if isinstance(canonical_context.get("errors"), list) else [],
        "intake_session_id": intake_session_id,
        "intake_session_state": intake_session_state,
        "intake_session_completed": intake_session_completed,
        "intake_understanding": orchestration_status.get("intake_understanding")
        if isinstance(orchestration_status.get("intake_understanding"), dict)
        else None,
    }
