"""Backend-owned composer UI projection helpers.

The frontend renders this projection; it must not infer chooser visibility,
recommendation visibility, or dismissal semantics from local keys.
"""

from __future__ import annotations

from typing import Any


def _trim(value: Any) -> str:
    return str(value or "").strip()


def _is_requirement_intake_mode(value: str) -> bool:
    return _trim(value) == "requirement_intake"


def _clean_list(values: list[Any]) -> list[str]:
    return [_trim(item) for item in values if _trim(item)]


def _next_action_keys(next_actions: list[Any]) -> list[str]:
    keys: list[str] = []
    for item in next_actions:
        if not isinstance(item, dict):
            continue
        key = _trim(item.get("action_key") or item.get("type"))
        if key:
            keys.append(key)
    return keys


def _resolve_chooser_visibility(
    *,
    activated_mode: str,
    stage_key: str,
    status_key: str,
    current_question: dict[str, Any] | None,
    required_missing: list[Any],
) -> tuple[str, bool]:
    if _trim(activated_mode) == "auto":
        return "none", False
    if stage_key == "requirement_intake" and isinstance(current_question, dict):
        return "question", True
    if _is_requirement_intake_mode(activated_mode) and isinstance(current_question, dict):
        return "question", True
    if stage_key == "requirement_intake" and status_key in {"collecting", "blocked"} and bool(required_missing):
        return "question", True
    return "none", False


def _build_dismiss_token(
    *,
    chooser_kind: str,
    stage_key: str,
    status_key: str,
    current_question: dict[str, Any] | None,
    required_missing: list[Any],
) -> str:
    if chooser_kind == "none":
        return ""
    question = current_question if isinstance(current_question, dict) else {}
    question_ref = _trim(
        question.get("question_revision")
        or question.get("revision")
        or question.get("question_id")
        or question.get("field_key")
    )
    missing_ref = ",".join(_clean_list(required_missing))
    parts = [chooser_kind, question_ref or missing_ref, _trim(stage_key), _trim(status_key)]
    return "|".join([part for part in parts if part])


def build_composer_ui_projection(
    *,
    activated_mode: str,
    mode_source: str,
    stage_key: str,
    status_key: str,
    current_question: dict[str, Any] | None,
    required_missing: list[Any],
    next_actions: list[Any],
) -> dict[str, Any]:
    question_field_key = _trim((current_question or {}).get("field_key"))
    primary_missing_field = _trim(required_missing[0] if required_missing else "")
    chooser_kind, chooser_visible = _resolve_chooser_visibility(
        activated_mode=activated_mode,
        stage_key=stage_key,
        status_key=status_key,
        current_question=current_question,
        required_missing=required_missing,
    )
    dismiss_token = _build_dismiss_token(
        chooser_kind=chooser_kind,
        stage_key=stage_key,
        status_key=status_key,
        current_question=current_question,
        required_missing=required_missing,
    )
    chooser_state = {
        "kind": chooser_kind,
        "visible": chooser_visible,
        "requires_explicit_user_action": chooser_visible,
        "dismissible": chooser_visible,
        "dismiss_token": dismiss_token,
        "keep_mode_on_submit": chooser_visible,
        "source": "authoritative",
        "current_field_key": question_field_key or primary_missing_field,
        "blocking_fields": _clean_list(required_missing),
        "next_action_keys": _next_action_keys(next_actions),
    }
    active_manual_mode = _trim(activated_mode) not in {"", "auto"}
    return {
        "active_mode": _trim(activated_mode) or "auto",
        "mode_source": _trim(mode_source),
        "source": "authoritative",
        "recommendation_panel": {
            "visible": not active_manual_mode,
            "source": "authoritative",
            "reason": "active_mode" if active_manual_mode else "auto_mode",
        },
        "composer_chooser": chooser_state,
        "chooser_state": chooser_state,
    }
