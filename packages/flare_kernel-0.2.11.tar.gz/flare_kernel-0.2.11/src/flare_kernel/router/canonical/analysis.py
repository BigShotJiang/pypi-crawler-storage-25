"""Analysis/retrieval projection helpers for canonical state."""

from __future__ import annotations

from typing import Any


def apply_analysis_and_retrieval_projection(
    *,
    canonical: dict[str, Any],
    command: str,
    can_generate: bool,
    assistant_text: str,
    normalized_retrieved_knowledge: list[dict[str, Any]],
) -> None:
    if command == "generate_analysis" and can_generate and assistant_text:
        canonical["analysis"]["sections"].append({"id": "analysis", "title": "需求分析", "content": assistant_text})
    if command == "generate_analysis" and normalized_retrieved_knowledge:
        evidence_rows = normalized_retrieved_knowledge[:3]
        evidence_titles = [str(item.get("title") or item.get("candidate_value") or item.get("snippet") or "证据") for item in evidence_rows]
        evidence_summary = f"检索到 {len(normalized_retrieved_knowledge)} 条证据"
        if evidence_titles:
            evidence_summary = f"{evidence_summary}，重点参考：{'；'.join(evidence_titles[:3])}"
        canonical["analysis"]["sections"].append(
            {
                "id": "evidence",
                "title": "检索证据",
                "content": evidence_summary,
            }
        )
    if not normalized_retrieved_knowledge:
        return
    comparison_rows: list[dict[str, Any]] = []
    for item in normalized_retrieved_knowledge[:3]:
        comparison_rows.append(
            {
                "record_id": item.get("record_id"),
                "chunk_id": item.get("chunk_id"),
                "title": str(item.get("title") or item.get("candidate_value") or "证据条目"),
                "source": str(item.get("source") or item.get("source_type") or "local"),
                "score": item.get("score"),
                "snippet": str(item.get("snippet") or item.get("content") or "")[:220],
                "matched_field": str(item.get("matched_field") or ""),
                "candidate_value": str(item.get("candidate_value") or ""),
                "confidence": item.get("confidence"),
                "why_relevant": str(item.get("why_relevant") or ""),
            }
        )
    canonical["capabilities"]["field_retrieval"]["comparison_rows"] = comparison_rows
    canonical["capabilities"]["field_retrieval"]["recommendation_summary"] = (
        f"已检索到 {len(normalized_retrieved_knowledge)} 条候选证据，优先查看 "
        + "；".join(str(item.get("title") or item.get("candidate_value") or "证据条目") for item in comparison_rows)
    )
