"""Pure contract helpers for canonical state payload assembly."""

from __future__ import annotations

from typing import Any


def coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def coerce_action_list(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


def _first_mapping(*values: Any) -> dict[str, Any]:
    for value in values:
        if isinstance(value, dict):
            return value
    return {}


def resolve_canvas_analysis_payload(
    *,
    orchestration_status: dict[str, Any],
    runtime_snapshot: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if isinstance(orchestration_status.get("canvas_analysis_payload"), dict):
        return orchestration_status.get("canvas_analysis_payload")
    runtime_payload = coerce_mapping(coerce_mapping(runtime_snapshot).get("payload"))
    if isinstance(runtime_payload.get("canvas_analysis_payload"), dict):
        return runtime_payload.get("canvas_analysis_payload")
    return None


def resolve_authoritative_runtime_payload(
    *,
    runtime_snapshot: dict[str, Any] | None,
    canonical_context: dict[str, Any],
    activated_mode: str,
    status_key: str,
    current_question: dict[str, Any] | None,
    next_actions: list[dict[str, Any]],
) -> dict[str, Any]:
    runtime_payload = coerce_mapping(coerce_mapping(runtime_snapshot).get("payload"))
    snapshot = coerce_mapping(runtime_snapshot)
    runtime_module_registry = coerce_action_list(runtime_payload.get("module_prompt_registry"))
    snapshot_module_registry = coerce_action_list(snapshot.get("module_prompt_registry"))
    track_result = _first_mapping(runtime_payload.get("track_result"), snapshot.get("track_result"))
    response_strategy_result = _first_mapping(
        runtime_payload.get("response_strategy_result"),
        snapshot.get("response_strategy_result"),
    )
    authoritative_current_question = (
        runtime_payload.get("current_question")
        if isinstance(runtime_payload.get("current_question"), dict)
        else current_question
    )
    followup_question = (
        runtime_payload.get("followup_question")
        if isinstance(runtime_payload.get("followup_question"), dict)
        else (
            canonical_context.get("followup_question")
            if isinstance(canonical_context.get("followup_question"), dict)
            else {}
        )
    )
    authoritative_next_actions = coerce_action_list(runtime_payload.get("next_actions")) or next_actions
    question_decision = _first_mapping(runtime_payload.get("question_decision"), canonical_context.get("question_decision"))
    return {
        "mode_key": str(snapshot.get("mode_key") or activated_mode).strip() or activated_mode,
        "mode_state": str(snapshot.get("mode_state") or status_key).strip() or status_key,
        "current_question": authoritative_current_question,
        "followup_question": followup_question,
        "question_decision": question_decision,
        "next_actions": authoritative_next_actions,
        "module_prompt_registry": runtime_module_registry or snapshot_module_registry,
        "track_result": track_result,
        "response_strategy_result": response_strategy_result,
    }


__all__ = [
    "coerce_action_list",
    "coerce_mapping",
    "resolve_authoritative_runtime_payload",
    "resolve_canvas_analysis_payload",
]
