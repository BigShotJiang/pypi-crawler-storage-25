"""Flow-mode and analysis-readiness helpers for canonical state builder."""

from __future__ import annotations

from typing import Any, Callable


def resolve_flow_activation(
    *,
    command: str,
    mode_source: str,
    resolved_intent: str,
    external_mode: str,
    inferred_stage: str,
    intake_candidate: bool,
    clarification_recommended: bool,
    escalation_target: str,
    analysis_ready: bool,
    required_missing: list[str],
    current_question: dict[str, Any] | None,
    fields: dict[str, str],
    map_external_mode_fn: Callable[[str], str],
) -> dict[str, Any]:
    explicit_activation = command in {
        "activate_requirement_intake",
        "submit_intake_answer",
        "generate_analysis",
        "implement",
        "apply",
    } or mode_source in {
        "intent_override",
        "active_intake",
        "manual_hint",
        "current_hint",
        "command",
    }
    should_activate_requirement_flow = bool(
        (
            external_mode == "requirement_intake"
            or intake_candidate
            or clarification_recommended
            or escalation_target in {"intake_candidate", "clarification_recommended", "draft_seeded", "analysis_ready"}
        )
        and (
            analysis_ready
            or bool(required_missing)
            or isinstance(current_question, dict)
            or bool(fields)
            or inferred_stage.startswith("requirement_intake")
            or inferred_stage.startswith("requirement_analysis")
        )
    )
    if explicit_activation:
        activated_mode = external_mode
    elif command in {"open_field_retrieval", "apply_field_candidate"}:
        if inferred_stage.startswith("requirement_intake"):
            activated_mode = "requirement_intake"
        elif inferred_stage.startswith("requirement_analysis"):
            activated_mode = "requirement_analysis"
        else:
            activated_mode = "requirement_intake"
    else:
        activated_mode = "auto"
    suggested_mode = (
        "requirement_intake"
        if (
            map_external_mode_fn(resolved_intent) == "requirement_intake"
            or escalation_target in {"intake_candidate", "clarification_recommended", "draft_seeded", "analysis_ready"}
        )
        else None
    )
    return {
        "explicit_activation": explicit_activation,
        "activated_mode": activated_mode,
        "suggested_mode": suggested_mode,
    }


def normalize_stage_status_and_question(
    *,
    orchestration_status: dict[str, Any],
    required_missing: list[str],
    activated_mode: str,
    current_question: dict[str, Any] | None,
    command: str,
    assistant_text: str,
    intake_session_id: str,
    normalize_stage_status_fn: Callable[..., tuple[str, str]],
) -> tuple[str, str, dict[str, Any] | None]:
    stage_key, status_key = normalize_stage_status_fn(
        current_stage=str(orchestration_status.get("current_stage") or ""),
        required_missing=required_missing,
        activated_mode=activated_mode,
        question=current_question,
        command=command,
        has_analysis_content=bool(str(assistant_text or "").strip()) and command == "generate_analysis",
        analysis_entry_eligible=bool(orchestration_status.get("analysis_entry_eligible")),
    )
    resolved_question = dict(current_question) if isinstance(current_question, dict) else None
    if activated_mode == "auto":
        resolved_question = None
        if status_key in {"collecting", "blocked"}:
            status_key = "idle"
    if isinstance(resolved_question, dict) and intake_session_id:
        resolved_question = {
            **resolved_question,
            "intake_session_id": intake_session_id,
        }
    return stage_key, status_key, resolved_question


def resolve_analysis_generation_state(
    *,
    command: str,
    activated_mode: str,
    required_missing: list[str],
    analysis_entry_eligible: bool,
    analysis_ready: bool,
    has_fields: bool,
    stage_key: str,
    status_key: str,
    analysis_entry_decision: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if isinstance(analysis_entry_decision, dict) and analysis_entry_decision:
        can_generate = bool(analysis_entry_decision.get("can_generate"))
        analysis_assumptions = [
            str(item)
            for item in (
                analysis_entry_decision.get("assumptions")
                if isinstance(analysis_entry_decision.get("assumptions"), list)
                else []
            )
            if str(item).strip()
        ]
    else:
        can_generate = bool(
            activated_mode == "requirement_intake"
            and (not required_missing or analysis_entry_eligible)
            and (
                analysis_ready
                or has_fields
                or stage_key == "requirement_analysis"
                or status_key == "ready_for_submit"
                or analysis_entry_eligible
            )
        )
        analysis_assumptions = []
        if analysis_entry_eligible and required_missing:
            blocking_labels = "、".join(required_missing[:6])
            if blocking_labels:
                analysis_assumptions.append(f"当前分析在字段覆盖率达到阈值后提前触发，仍待确认字段：{blocking_labels}。")
            analysis_assumptions.append("未确认字段已按“假设/待验证点”处理，不视为已确认事实。")
    errors: list[dict[str, Any]] = []
    if command == "generate_analysis" and not can_generate:
        errors.append(
            {
                "type": "recoverable_validation_error",
                "code": "intake_not_ready",
                "message": "required fields missing",
                "fatal": False,
                "retryable": False,
            }
        )
    return {
        "can_generate": can_generate,
        "analysis_assumptions": analysis_assumptions,
        "errors": errors,
    }
