"""Router canonical module group."""
