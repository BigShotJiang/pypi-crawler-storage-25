"""Checkpoint projection helpers for canonical state."""

from __future__ import annotations

from typing import Any


def build_checkpoint_projection(
    *,
    orchestration_status: dict[str, Any],
    intake_session_id: str,
    status_key: str,
    current_question: dict[str, Any] | None,
    fields: dict[str, str],
    required_missing: list[str],
    session_id: str,
    activated_mode: str,
) -> dict[str, Any]:
    raw_checkpoint = (
        orchestration_status.get("checkpoint")
        if isinstance(orchestration_status.get("checkpoint"), dict)
        else {}
    )
    try:
        checkpoint_version = int(raw_checkpoint.get("version") or 1)
    except (TypeError, ValueError):
        checkpoint_version = 1
    checkpoint = {
        "checkpoint_id": str(raw_checkpoint.get("checkpoint_id") or "").strip(),
        "intake_session_id": str(raw_checkpoint.get("intake_session_id") or intake_session_id or "").strip(),
        "checkpoint_type": str(raw_checkpoint.get("checkpoint_type") or "").strip(),
        "checkpoint_state": str(raw_checkpoint.get("checkpoint_state") or "").strip(),
        "current_stage": str(raw_checkpoint.get("current_stage") or "").strip(),
        "question_key": str(raw_checkpoint.get("question_key") or "").strip(),
        "ready_for_submit": bool(raw_checkpoint.get("ready_for_submit")),
        "decision_point_active": bool(raw_checkpoint.get("decision_point_active")),
        "updated_at": str(raw_checkpoint.get("updated_at") or "").strip(),
        "waiting_user": bool(
            orchestration_status.get("checkpoint_waiting_user") is True
            or str(raw_checkpoint.get("checkpoint_state") or "").strip().lower() == "waiting_user"
        ),
        "workflow_id": str(raw_checkpoint.get("workflow_id") or "").strip(),
        "session_id": str(raw_checkpoint.get("session_id") or session_id or "").strip(),
        "mode": str(raw_checkpoint.get("mode") or activated_mode or "").strip(),
        "status": str(raw_checkpoint.get("status") or "").strip(),
        "active_checkpoint_id": str(raw_checkpoint.get("active_checkpoint_id") or raw_checkpoint.get("checkpoint_id") or "").strip(),
        "version": max(1, checkpoint_version),
        "checkpoints": (
            [item for item in raw_checkpoint.get("checkpoints") if isinstance(item, dict)]
            if isinstance(raw_checkpoint.get("checkpoints"), list)
            else []
        ),
    }
    if not checkpoint["workflow_id"] and checkpoint["intake_session_id"]:
        checkpoint["workflow_id"] = f"wf_{checkpoint['intake_session_id']}"
    if not checkpoint["status"]:
        if status_key == "ready_for_submit":
            checkpoint["status"] = "succeeded"
        elif status_key in {"collecting", "blocked"}:
            checkpoint["status"] = "waiting_user"
        else:
            checkpoint["status"] = "queued"
    if not checkpoint["checkpoints"] and checkpoint["checkpoint_id"]:
        current_question_text = ""
        current_question_field = ""
        if isinstance(current_question, dict):
            current_question_text = str(current_question.get("question_text") or "").strip()
            current_question_field = str(current_question.get("field_key") or "").strip()
        checkpoint["checkpoints"] = [
            {
                "checkpoint_id": checkpoint["checkpoint_id"],
                "seq": 1,
                "title": "需求梳理",
                "stage": "clarification" if status_key in {"collecting", "blocked"} else "intake",
                "status": checkpoint["status"],
                "question": (
                    {
                        "question_id": f"question::{current_question_field}" if current_question_field else "",
                        "text": current_question_text,
                        "target_fields": [current_question_field] if current_question_field else [],
                    }
                    if current_question_text or current_question_field
                    else None
                ),
                "confirmed_fields": [
                    {
                        "field_key": field_key,
                        "display_value": field_value,
                        "confidence": 0.85,
                    }
                    for field_key, field_value in fields.items()
                ],
                "missing_fields": [
                    {"field_key": field_key, "reason": "required_missing", "blocks": True}
                    for field_key in required_missing
                ],
                "child_tasks": [],
            }
        ]
    if not checkpoint["checkpoint_id"]:
        return {}
    return checkpoint
