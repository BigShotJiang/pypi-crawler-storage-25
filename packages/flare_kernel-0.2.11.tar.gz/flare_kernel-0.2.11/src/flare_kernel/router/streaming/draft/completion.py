"""Completion and runtime artifact helpers for draft-generation phase."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.completion.intake_summary_events import (
    should_render_requirement_summary_as_canvas_only,
)
from flare_kernel.runtime.llm.llm_provider import LLMCompletion
from flare_kernel.runtime.llm.provider_trace import build_completion_provider_trace
from flare_kernel.runtime.project_memory import persist_project_memory_from_runtime


@dataclass(frozen=True)
class DraftCompletionArtifacts:
    completion: LLMCompletion
    content_text: str
    memory_record: dict[str, Any]
    observation_runtime_event: dict[str, Any]
    llm_finish_trace: dict[str, Any]


def _resolve_llm_trace_status(completion_status: str) -> str:
    return "completed" if completion_status in {"ok", "orchestrated"} else "failed"


async def resolve_draft_completion_artifacts(
    *,
    req: KernelRequest,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    raw_message: str,
    resolved_mode: str,
    mode_source: str,
    effective_command: str,
    retrieved_knowledge: list[dict[str, Any]],
    enriched_payload: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    instance_profile: dict[str, Any] | None,
    resolve_turn_completion_fn: Callable[..., Any],
    resolve_guided_orchestrated_completion_fn: Callable[..., LLMCompletion | None],
    should_force_requirement_clarification_fn: Callable[..., bool],
    build_requirement_clarification_message_fn: Callable[[str], str],
    build_prompt_fn: Callable[[KernelRequest, dict[str, Any], dict[str, Any] | None, str, str], str],
    generate_llm_completion_fn: Callable[..., Any],
    on_llm_delta_fn: Callable[[str], Any] | None = None,
    should_persist_memory_record_fn: Callable[..., bool],
    persist_memory_record_fn: Callable[..., dict[str, Any]],
    sanitize_customer_visible_text_fn: Callable[[str], str],
    sanitize_product_name_for_prompt_fn: Callable[[str], str],
    build_llm_execution_trace_fn: Callable[..., dict[str, Any]],
) -> DraftCompletionArtifacts:
    product_name = ""
    if instance_profile and isinstance(instance_profile.get("product_name"), str):
        product_name = sanitize_product_name_for_prompt_fn(instance_profile.get("product_name", ""))
    completion = await resolve_turn_completion_fn(
        req=req,
        trace_id=trace_id,
        session_id=session_id,
        raw_message=raw_message,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        effective_command=effective_command,
        retrieved_knowledge=retrieved_knowledge,
        enriched_payload=enriched_payload,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        instance_profile=instance_profile,
        resolve_guided_orchestrated_completion_fn=resolve_guided_orchestrated_completion_fn,
        should_force_requirement_clarification_fn=should_force_requirement_clarification_fn,
        build_requirement_clarification_message_fn=build_requirement_clarification_message_fn,
        build_prompt_fn=build_prompt_fn,
        generate_llm_completion_fn=generate_llm_completion_fn,
        on_llm_delta_fn=on_llm_delta_fn,
    )
    content_text = completion.content
    if product_name and completion.status == "placeholder" and "kernel.stream placeholder" not in content_text:
        content_text = f"{product_name} {content_text}".strip()
    content_text = sanitize_customer_visible_text_fn(content_text)
    canvas_only_summary = should_render_requirement_summary_as_canvas_only(
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        content_text=content_text,
        completion_provider=completion.provider,
        completion_model=completion.model,
        completion_status=completion.status,
        command=effective_command,
    )

    memory_record = {}
    if (not canvas_only_summary) and should_persist_memory_record_fn(completion=completion):
        memory_record = persist_memory_record_fn(
            trace_id=trace_id,
            session_id=session_id,
            project_id=project_id,
            user_id=user_id,
            mode_key=runtime_snapshot["mode_key"],
            user_message=raw_message,
            assistant_message=content_text,
            provider=completion.provider,
            model=completion.model,
            provider_status=completion.status,
        )
    project_memory_record = persist_project_memory_from_runtime(
        project_id=project_id,
        user_id=user_id,
        source_session_id=session_id,
        runtime_snapshot=runtime_snapshot,
    )
    if project_memory_record:
        memory_record.update(project_memory_record)

    provider_trace = build_completion_provider_trace(completion)
    observation_runtime_event = {
        "trace_id": trace_id,
        **runtime_snapshot["observation_runtime"],
        "provider": completion.provider,
        "model": completion.model,
        "provider_status": completion.status,
        "provider_trace": provider_trace,
        "metrics": {
            **runtime_snapshot["observation_runtime"].get("metrics", {}),
            "retrieval_hit_count": len(retrieved_knowledge),
            "llm_success_count": 1 if completion.status == "ok" else 0,
        },
    }

    llm_status = _resolve_llm_trace_status(str(completion.status or ""))
    llm_finish_trace = build_llm_execution_trace_fn(
        trace_id=trace_id,
        session_id=req.session_id,
        mode_key=resolved_mode,
        status=llm_status,
        provider=completion.provider,
        model=completion.model,
        detail=f"provider_status={completion.status}",
    )

    return DraftCompletionArtifacts(
        completion=completion,
        content_text=content_text,
        memory_record=memory_record,
        observation_runtime_event=observation_runtime_event,
        llm_finish_trace=llm_finish_trace,
    )
