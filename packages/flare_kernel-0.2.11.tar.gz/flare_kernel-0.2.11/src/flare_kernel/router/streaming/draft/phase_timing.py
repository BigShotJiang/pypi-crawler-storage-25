"""Timing-log helpers for the draft-generation streaming phase.

This module keeps stream telemetry formatting separate from phase sequencing so
`iter_draft_generation_events` can remain focused on orchestration and error
fallback behavior.
"""

from __future__ import annotations

from logging import Logger

from flare_kernel.router.streaming.event_emitter import StreamingEventEmitter


def log_draft_generation_timing(
    *,
    logger: Logger,
    trace_id: str,
    session_id: str,
    request_id: str,
    stream_started_at: int,
    ack_ts: int,
    emitter: StreamingEventEmitter,
    done_ts: int,
) -> None:
    """Emit the draft-generation timing log with the same telemetry fields."""

    logger.info(
        "kernel.stream.timing trace_id=%s session_id=%s request_id=%s t_submit=%s t_ack=%s t_first_phase=%s t_first_patch=%s t_first_text=%s t_done=%s",
        trace_id,
        session_id,
        request_id,
        stream_started_at,
        ack_ts,
        emitter.first_phase_at or 0,
        emitter.first_patch_at or 0,
        emitter.first_text_at or 0,
        done_ts,
    )
