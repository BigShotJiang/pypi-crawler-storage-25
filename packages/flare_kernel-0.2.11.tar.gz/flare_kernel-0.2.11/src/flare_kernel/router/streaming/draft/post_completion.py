"""Post-completion helpers for draft-generation streaming events.

DOC HELPER — WRK-04 draft completion context-patch bridge.
This module attaches backend-owned context patches to terminal stream events.
It may merge patch fragments but must not persist state or reinterpret
analysis payload content.
"""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.completion.intake_summary_events import (
    should_render_requirement_summary_as_canvas_only,
    with_requirement_summary_confirm_send_action,
    with_requirement_summary_confirm_send_canvas_event,
)
from flare_kernel.router.streaming.draft.completion import DraftCompletionArtifacts
from flare_kernel.router.streaming.draft.finalize import (
    apply_draft_content_policy,
    iter_canonical_finalize_events,
)
from flare_kernel.router.streaming.event_emitter import StreamingEventEmitter
from flare_kernel.runtime.context.analysis_application import build_context_patch_from_analysis
from flare_kernel.runtime.orchestration.mode.intake_summary_artifact import (
    build_model_authored_requirement_summary_event,
)


def _merge_context_patches(*patches: dict[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = {}
    for patch in patches:
        if not isinstance(patch, dict):
            continue
        for key, value in patch.items():
            if isinstance(value, list):
                existing = merged.get(key) if isinstance(merged.get(key), list) else []
                merged[key] = [*existing, *value]
            elif isinstance(value, dict) and isinstance(merged.get(key), dict):
                merged[key] = {**merged[key], **value}
            else:
                merged[key] = value
    return merged


def _resolve_analysis_payload(
    *,
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
) -> dict[str, Any]:
    if isinstance(orchestration_status.get("canvas_analysis_payload"), dict):
        return orchestration_status.get("canvas_analysis_payload") or {}
    payload = runtime_snapshot.get("payload") if isinstance(runtime_snapshot.get("payload"), dict) else {}
    if isinstance(payload.get("canvas_analysis_payload"), dict):
        return payload.get("canvas_analysis_payload") or {}
    return {}


def _resolve_context_patch(
    *,
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
) -> dict[str, Any]:
    payload = runtime_snapshot.get("payload") if isinstance(runtime_snapshot.get("payload"), dict) else {}
    context_patch = payload.get("context_patch") if isinstance(payload.get("context_patch"), dict) else {}
    analysis_patch = build_context_patch_from_analysis(
        _resolve_analysis_payload(
            runtime_snapshot=runtime_snapshot,
            orchestration_status=orchestration_status,
        )
    )
    return _merge_context_patches(context_patch, analysis_patch)


def build_draft_post_completion_events(
    *,
    req: KernelRequest,
    trace_id: str,
    session_id: str,
    request_id: str,
    project_id: str,
    user_id: str,
    raw_message: str,
    effective_command: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    structured_retrieved_knowledge: list[dict[str, Any]],
    escalation_signal: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    artifacts: DraftCompletionArtifacts,
    emitter: StreamingEventEmitter,
    build_canonical_state_fn: Callable[..., dict[str, Any]],
    sync_session_intent_stage_fn: Callable[..., None],
    persist_authoritative_intake_state_fn: Callable[..., dict[str, Any]],
) -> tuple[list[str], int]:
    """Apply the draft completion side effects and assemble the final stream events."""

    canvas_only_summary = should_render_requirement_summary_as_canvas_only(
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        content_text=artifacts.content_text,
        completion_provider=artifacts.completion.provider,
        completion_model=artifacts.completion.model,
        completion_status=artifacts.completion.status,
        command=effective_command,
    )
    if canvas_only_summary:
        orchestration_status["next_actions"] = with_requirement_summary_confirm_send_action(
            next_actions=orchestration_status.get("next_actions")
            if isinstance(orchestration_status.get("next_actions"), list)
            else [],
            content_text=artifacts.content_text,
        )
    # Demo-safe PLN-15 behavior: the model-authored prompt must remain visible
    # in the main timeline; Canvas is an additional review surface, not the
    # only place where the prompt exists.
    visible_content_text = artifacts.content_text
    apply_draft_content_policy(
        orchestration_status=orchestration_status,
        effective_command=effective_command,
        content_text=visible_content_text,
        runtime_snapshot=runtime_snapshot,
    )
    sync_session_intent_stage_fn(
        orchestration_status=orchestration_status,
        signal=escalation_signal,
        message=raw_message,
        command=effective_command,
    )
    persist_authoritative_intake_state_fn(
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        command=effective_command,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
    )

    canonical = build_canonical_state_fn(
        req=req,
        command=effective_command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        orchestration_status=orchestration_status,
        runtime_snapshot=runtime_snapshot,
        assistant_text=visible_content_text,
        provider_status=artifacts.completion.status,
        structured_retrieved_knowledge=structured_retrieved_knowledge,
    )

    events: list[str] = []
    completion_details = artifacts.completion.details if isinstance(artifacts.completion.details, dict) else {}
    patch_only_completion = (
        str(completion_details.get("reason") or "").strip() == "guided_session_patch_only"
        and not str(artifacts.content_text or "").strip()
    )
    memory_runtime_event = {"trace_id": trace_id, **runtime_snapshot["memory_runtime"], **artifacts.memory_record}
    events.append(emitter.emit_event("memory_runtime", memory_runtime_event))
    events.append(emitter.emit_event("observation_runtime", artifacts.observation_runtime_event))
    events.append(emitter.emit_event("execution_trace", artifacts.llm_finish_trace))
    if canvas_only_summary:
        summary_event = build_model_authored_requirement_summary_event(
            runtime_snapshot=runtime_snapshot,
            content_text=artifacts.content_text,
            completion_provider=artifacts.completion.provider,
            completion_model=artifacts.completion.model,
            completion_status=artifacts.completion.status,
        )
        summary_event = with_requirement_summary_confirm_send_canvas_event(
            summary_event=summary_event,
            content_text=artifacts.content_text,
        )
        if summary_event:
            events.append(emitter.emit_event("canvas_state", summary_event["payload"]))
    elif resolved_mode == "requirement_intake":
        summary_event = build_model_authored_requirement_summary_event(
            runtime_snapshot=runtime_snapshot,
            content_text=artifacts.content_text,
            completion_provider=artifacts.completion.provider,
            completion_model=artifacts.completion.model,
            completion_status=artifacts.completion.status,
        )
        if summary_event:
            events.append(emitter.emit_event("canvas_state", summary_event["payload"]))
    events.append(emitter.emit_event("orchestration_status", orchestration_status))
    if not patch_only_completion:
        events.append(
            emitter.emit_text_replace(artifacts.content_text)
        )
    final_events, done_ts = iter_canonical_finalize_events(
        trace_id=trace_id,
        session_id=session_id,
        request_id=request_id,
        content_text=visible_content_text,
        canonical=canonical,
        context_patch=_resolve_context_patch(
            runtime_snapshot=runtime_snapshot,
            orchestration_status=orchestration_status,
        ),
        emitter=emitter,
    )
    events.extend(final_events)
    return events, done_ts
