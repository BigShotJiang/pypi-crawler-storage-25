"""Bootstrap helpers for draft-generation streaming events."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.streaming.event_emitter import StreamingEventEmitter


def build_draft_prologue_events(
    *,
    req: KernelRequest,
    trace_id: str,
    session_id: str,
    request_id: str,
    resolved_mode: str,
    emitter: StreamingEventEmitter,
    build_llm_execution_trace_fn: Callable[..., dict[str, Any]],
) -> list[str]:
    """Build the initial phase, heartbeat, and execution-trace events for draft generation."""

    events: list[str] = []
    events.append(
        emitter.emit_phase_event(
            "phase.start",
            {
                "phase": "draft_generation",
                "label": "正在生成分析草稿",
            },
        )
    )
    events.append(
        emitter.emit_event(
            "heartbeat",
            {
                "trace_id": trace_id,
                "session_id": session_id,
                "request_id": request_id,
                "ts": emitter.now_ts(),
            },
        )
    )
    llm_start_trace = build_llm_execution_trace_fn(
        trace_id=trace_id,
        session_id=req.session_id,
        mode_key=resolved_mode,
        status="running",
        provider="dashscope",
        model="pending",
        detail="开始调用模型生成回复。",
    )
    events.append(emitter.emit_event("execution_trace", llm_start_trace))
    return events
