"""Helpers for streaming draft-generation phase events."""

from __future__ import annotations

import asyncio
from logging import Logger
from typing import Any, AsyncIterator, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.llm.llm_provider import LLMCompletion
from flare_kernel.router.streaming.draft.completion import (
    resolve_draft_completion_artifacts,
)
from flare_kernel.router.streaming.draft.finalize import (
    iter_draft_error_events,
)
from flare_kernel.router.streaming.draft.phase_timing import (
    log_draft_generation_timing,
)
from flare_kernel.router.streaming.draft.prologue import build_draft_prologue_events
from flare_kernel.router.streaming.draft.post_completion import (
    build_draft_post_completion_events,
)
from flare_kernel.router.streaming.event_emitter import StreamingEventEmitter


async def _iter_pending_delta_events(
    task: asyncio.Task,
    delta_events: asyncio.Queue[str],
) -> AsyncIterator[str]:
    while not task.done():
        try:
            yield await asyncio.wait_for(delta_events.get(), timeout=0.05)
        except asyncio.TimeoutError:
            continue
    while not delta_events.empty():
        yield delta_events.get_nowait()


async def iter_draft_generation_events(
    *,
    req: KernelRequest,
    trace_id: str,
    session_id: str,
    request_id: str,
    stream_started_at: int,
    ack_ts: int,
    raw_message: str,
    project_id: str,
    user_id: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    effective_command: str,
    retrieved_knowledge: list[dict[str, Any]],
    enriched_payload: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    escalation_signal: dict[str, Any],
    instance_profile: dict[str, Any] | None,
    structured_retrieved_knowledge: list[dict[str, Any]],
    emitter: StreamingEventEmitter,
    resolve_turn_completion_fn: Callable[..., Any],
    build_llm_execution_trace_fn: Callable[..., dict[str, Any]],
    resolve_guided_orchestrated_completion_fn: Callable[..., LLMCompletion | None],
    should_force_requirement_clarification_fn: Callable[..., bool],
    build_requirement_clarification_message_fn: Callable[[str], str],
    build_prompt_fn: Callable[[KernelRequest, dict[str, Any], dict[str, Any] | None, str, str], str],
    generate_llm_completion_fn: Callable[..., Any],
    should_persist_memory_record_fn: Callable[..., bool],
    persist_memory_record_fn: Callable[..., dict[str, Any]],
    sanitize_customer_visible_text_fn: Callable[[str], str],
    sanitize_product_name_for_prompt_fn: Callable[[str], str],
    sync_session_intent_stage_fn: Callable[..., None],
    persist_authoritative_intake_state_fn: Callable[..., dict[str, Any]],
    build_canonical_state_fn: Callable[..., dict[str, Any]],
    logger: Logger,
) -> AsyncIterator[str]:
    """Stream the draft-generation phase while preserving event order.

    Stage boundaries are explicit here so the transport layer can remain thin:
    - prologue events establish the draft phase and emit early traces
    - completion artifacts resolve the model/clarification outcome
    - post-completion events finalize the stream and update session state
    - error handling always falls back to a structured streamable failure

    The contract assumption is that the injected helpers own the policy and
    persistence details; this function only sequences those helpers.
    """
    try:
        # Stage 1: emit the draft prologue before any completion work begins.
        for event in build_draft_prologue_events(
            req=req,
            trace_id=trace_id,
            session_id=session_id,
            request_id=request_id,
            resolved_mode=resolved_mode,
            emitter=emitter,
            build_llm_execution_trace_fn=build_llm_execution_trace_fn,
        ):
            yield event
        # Stage 2: resolve the draft completion artifacts that drive the
        # remainder of the stream and any persistence side effects.
        delta_events: asyncio.Queue[str] = asyncio.Queue()

        def _queue_llm_delta(delta: str) -> None:
            safe_delta = sanitize_customer_visible_text_fn(str(delta or ""))
            if safe_delta:
                delta_events.put_nowait(emitter.emit_text_delta(safe_delta))

        artifacts_task = asyncio.create_task(resolve_draft_completion_artifacts(
            req=req,
            trace_id=trace_id,
            session_id=session_id,
            project_id=project_id,
            user_id=user_id,
            raw_message=raw_message,
            resolved_mode=resolved_mode,
            mode_source=mode_source,
            effective_command=effective_command,
            retrieved_knowledge=retrieved_knowledge,
            enriched_payload=enriched_payload,
            runtime_snapshot=runtime_snapshot,
            orchestration_status=orchestration_status,
            instance_profile=instance_profile,
            resolve_turn_completion_fn=resolve_turn_completion_fn,
            resolve_guided_orchestrated_completion_fn=resolve_guided_orchestrated_completion_fn,
            should_force_requirement_clarification_fn=should_force_requirement_clarification_fn,
            build_requirement_clarification_message_fn=build_requirement_clarification_message_fn,
            build_prompt_fn=build_prompt_fn,
            generate_llm_completion_fn=generate_llm_completion_fn,
            on_llm_delta_fn=_queue_llm_delta,
            should_persist_memory_record_fn=should_persist_memory_record_fn,
            persist_memory_record_fn=persist_memory_record_fn,
            sanitize_customer_visible_text_fn=sanitize_customer_visible_text_fn,
            sanitize_product_name_for_prompt_fn=sanitize_product_name_for_prompt_fn,
            build_llm_execution_trace_fn=build_llm_execution_trace_fn,
        ))
        try:
            async for event in _iter_pending_delta_events(artifacts_task, delta_events):
                yield event
            artifacts = await artifacts_task
        finally:
            if not artifacts_task.done():
                artifacts_task.cancel()
        # Stage 3: emit the completion tail and capture the terminal timestamp
        # used for stream timing telemetry.
        completion_events, done_ts = build_draft_post_completion_events(
            req=req,
            trace_id=trace_id,
            session_id=session_id,
            request_id=request_id,
            project_id=project_id,
            user_id=user_id,
            raw_message=raw_message,
            effective_command=effective_command,
            resolved_intent=resolved_intent,
            resolved_mode=resolved_mode,
            mode_source=mode_source,
            structured_retrieved_knowledge=structured_retrieved_knowledge,
            escalation_signal=escalation_signal,
            runtime_snapshot=runtime_snapshot,
            orchestration_status=orchestration_status,
            artifacts=artifacts,
            emitter=emitter,
            build_canonical_state_fn=build_canonical_state_fn,
            sync_session_intent_stage_fn=sync_session_intent_stage_fn,
            persist_authoritative_intake_state_fn=persist_authoritative_intake_state_fn,
        )
        for event in completion_events:
            yield event
        log_draft_generation_timing(
            logger=logger,
            trace_id=trace_id,
            session_id=session_id,
            request_id=request_id,
            stream_started_at=stream_started_at,
            ack_ts=ack_ts,
            emitter=emitter,
            done_ts=done_ts,
        )
    except asyncio.CancelledError:
        if not emitter.terminal_emitted:
            emitter.emit_event(
                "complete",
                {
                    "trace_id": trace_id,
                    "session_id": session_id,
                    "request_id": request_id,
                    "status": "error",
                    "message": "stream cancelled before complete",
                },
            )
        raise
    except Exception as exc:  # pragma: no cover - defensive stream fallback
        # Stage 4: surface stream-safe failures as structured error events so
        # the transport contract stays consumable by the client.
        for event in iter_draft_error_events(
            trace_id=trace_id,
            session_id=session_id,
            request_id=request_id,
            message=str(exc),
            emitter=emitter,
        ):
            yield event
