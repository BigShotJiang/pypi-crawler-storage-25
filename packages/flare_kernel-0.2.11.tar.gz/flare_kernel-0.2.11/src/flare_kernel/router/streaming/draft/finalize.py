"""Finalize/error event helpers for draft-generation phase.

DOC HELPER — OBJ-09 final patch boundary.
Final patch emission includes context authority as backend-owned metadata; this
module only frames the event and does not create context facts.

DOC HELPER — ORC-02 terminal stream contract.
Both success and failure paths must emit a stable terminal sequence that clients
can consume without special casing missing final-result events.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.llm.llm_provider import LLMCompletion
from flare_kernel.router.completion.analysis_policy import (
    apply_analysis_completion_policy,
)
from flare_kernel.router.streaming.event_emitter import StreamingEventEmitter


def build_content_event(
    *,
    trace_id: str,
    content_text: str,
    completion: LLMCompletion,
) -> dict[str, Any]:
    return {
        "trace_id": trace_id,
        "content": content_text,
        "provider": completion.provider,
        "model": completion.model,
        "provider_status": completion.status,
    }


def _build_analysis_contract_payload(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "canvas_analysis_payload": payload,
        "analysis_payload": payload,
    }


def _is_waiting_user(canonical: dict[str, Any]) -> bool:
    if str(canonical.get("mode_key") or "").strip() != "requirement_intake":
        return False
    mode_state = str(canonical.get("mode_state") or "").strip().lower()
    if mode_state in {"applied", "completed", "done"}:
        return False
    current_question = canonical.get("current_question")
    return isinstance(current_question, dict) and bool(current_question)


def iter_canonical_finalize_events(
    *,
    trace_id: str,
    session_id: str,
    request_id: str,
    content_text: str,
    canonical: dict[str, Any],
    context_patch: dict[str, Any] | None = None,
    emitter: StreamingEventEmitter,
) -> tuple[list[str], int]:
    events: list[str] = []
    analysis_payload = (
        canonical.get("canvas_analysis_payload")
        if isinstance(canonical.get("canvas_analysis_payload"), dict)
        else {}
    )
    analysis_contract_payload = _build_analysis_contract_payload(analysis_payload) if analysis_payload else {}
    if canonical.get("errors"):
        events.append(
            emitter.emit_contract_patch(
                event_type="error",
                patch_scope=["errors"],
                payload={"errors": canonical.get("errors", [])},
                final=False,
            )
        )
        events.append(
            emitter.emit_event(
                "error",
                {
                    "trace_id": trace_id,
                    "session_id": session_id,
                    "request_id": request_id,
                    "message": "生成过程中出现可恢复错误",
                    "errors": canonical.get("errors", []),
                    "ts": emitter.now_ts(),
                },
            )
        )
    events.append(emitter.emit_patch("analysis.sections", canonical.get("analysis") if isinstance(canonical.get("analysis"), dict) else {}))
    if analysis_payload:
        events.append(
            emitter.emit_event(
                "analysis_payload",
                {
                    "trace_id": trace_id,
                    "session_id": session_id,
                    "request_id": request_id,
                    **analysis_payload,
                    **analysis_contract_payload,
                },
            )
        )
        events.append(emitter.emit_patch("analysis.canvas_payload", analysis_payload))
    slot_patches = canonical.get("analysis_slot_patches")
    if isinstance(slot_patches, list) and slot_patches:
        events.append(emitter.emit_event("analysis_slot_patch", {"patches": slot_patches}))
        events.append(emitter.emit_patch("analysis.slot_patch", {"patches": slot_patches}))
    events.append(
        emitter.emit_contract_patch(
            event_type="final",
            patch_scope=[
                "session",
                "assistant_reply",
                "context_authority",
                "primary_flow",
                "checkpoint",
                "intent_state",
                "question",
                "confirmed_fields",
                "missing_fields",
                "next_actions",
                "track_result",
                "response_strategy_result",
                "module_prompt_registry",
                "composer_ui",
                "analysis",
                "observation",
                "capabilities.field_retrieval",
                "errors",
            ],
            payload={
                "mode_key": canonical.get("mode_key"),
                "mode_state": canonical.get("mode_state"),
                "assistant_reply": canonical.get("assistant_reply"),
                "context_authority": canonical.get("context_authority"),
                "primary_flow": canonical.get("primary_flow"),
                "checkpoint": canonical.get("checkpoint"),
                "intent_state": canonical.get("intent_state"),
                "question": canonical.get("question"),
                "current_question": canonical.get("current_question"),
                "followup_question": canonical.get("followup_question"),
                "confirmed_fields": canonical.get("confirmed_fields"),
                "missing_fields": canonical.get("missing_fields"),
                "next_actions": canonical.get("next_actions"),
                "track_result": canonical.get("track_result"),
                "response_strategy_result": canonical.get("response_strategy_result"),
                "module_prompt_registry": canonical.get("module_prompt_registry"),
                "composer_ui": canonical.get("composer_ui"),
                "analysis": canonical.get("analysis"),
                "canvas_analysis_payload": analysis_payload,
                "analysis_payload": analysis_payload,
                "analysis_slot_patches": (
                    slot_patches
                    if isinstance(slot_patches, list)
                    else []
                ),
                "observation": canonical.get("observation"),
                "capabilities": canonical.get("capabilities"),
                "errors": canonical.get("errors"),
                "session": canonical.get("session"),
            },
            final=True,
        )
    )
    waiting_user = _is_waiting_user(canonical)
    phase_end_status = "waiting_user" if waiting_user else "succeeded"
    phase_end_label = "等待用户回答" if waiting_user else "草稿生成完成"
    done_status = "waiting_user" if waiting_user else "done"
    events.append(
        emitter.emit_phase_event(
            "phase.end",
            {
                "phase": "draft_generation",
                "label": phase_end_label,
                "status": phase_end_status,
            },
        )
    )
    done_payload = {
        "trace_id": trace_id,
        "session_id": session_id,
        "request_id": request_id,
        "status": done_status,
        "ts": emitter.now_ts(),
    }
    events.append(emitter.emit_event("done", done_payload))
    complete_payload = {
        "trace_id": trace_id,
        "session_id": session_id,
        "request_id": request_id,
        "status": done_status,
        **analysis_payload,
        **analysis_contract_payload,
    }
    if isinstance(context_patch, dict) and context_patch:
        complete_payload["context_patch"] = context_patch
    events.append(
        emitter.emit_event(
            "complete",
            complete_payload,
        )
    )
    return events, int(done_payload["ts"])


def iter_draft_error_events(
    *,
    trace_id: str,
    session_id: str,
    request_id: str,
    message: str,
    emitter: StreamingEventEmitter,
) -> list[str]:
    """Emit the failure terminal sequence for the stream contract."""

    error_payload = {
        "trace_id": trace_id,
        "session_id": session_id,
        "request_id": request_id,
        "message": message,
        "ts": emitter.now_ts(),
    }
    contract_error = {
        "errors": [
            {
                "message": message,
                "source": "draft_generation",
            }
        ]
    }
    return [
        emitter.emit_contract_patch(
            event_type="error",
            patch_scope=["errors"],
            payload=contract_error,
            final=False,
        ),
        emitter.emit_event("error", error_payload),
        emitter.emit_phase_event(
            "phase.end",
            {
                "phase": "draft_generation",
                "label": "草稿生成失败",
                "status": "failed",
            },
        ),
        emitter.emit_event(
            "done",
            {
                "trace_id": trace_id,
                "session_id": session_id,
                "request_id": request_id,
                "status": "error",
                "ts": emitter.now_ts(),
            },
        ),
        emitter.emit_event(
            "complete",
            {
                "trace_id": trace_id,
                "session_id": session_id,
                "request_id": request_id,
                "status": "error",
                **contract_error,
            },
        ),
    ]


def apply_draft_content_policy(
    *,
    orchestration_status: dict[str, Any],
    effective_command: str,
    content_text: str,
    runtime_snapshot: dict[str, Any] | None = None,
) -> None:
    apply_analysis_completion_policy(
        orchestration_status=orchestration_status,
        command=effective_command,
        content_text=content_text,
        runtime_snapshot=runtime_snapshot,
    )
