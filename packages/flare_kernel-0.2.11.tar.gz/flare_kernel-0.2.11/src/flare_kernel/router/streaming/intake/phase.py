"""Helpers for streaming intake-phase canonical state events."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest


def iter_intake_state_events(
    *,
    req: KernelRequest,
    effective_command: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    orchestration_status: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    structured_retrieved_knowledge: list[dict[str, Any]],
    build_canonical_state_fn: Callable[..., dict[str, Any]],
    emit_contract_patch_fn: Callable[..., str],
    emit_patch_fn: Callable[[str, dict[str, Any]], str],
    emit_phase_event_fn: Callable[[str, dict[str, Any]], str],
    emit_text_delta_fn: Callable[[str], str],
) -> list[str]:
    events: list[str] = []
    early_state = build_canonical_state_fn(
        req=req,
        command=effective_command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        orchestration_status=orchestration_status,
        runtime_snapshot=runtime_snapshot,
        assistant_text="",
        provider_status="streaming",
        structured_retrieved_knowledge=structured_retrieved_knowledge,
    )
    events.append(
        emit_contract_patch_fn(
            event_type="patch",
            patch_scope=[
                "primary_flow",
                "checkpoint",
                "intent_state",
                "question",
                "confirmed_fields",
                "missing_fields",
                "next_actions",
                "track_result",
                "response_strategy_result",
                "module_prompt_registry",
                "composer_ui",
            ],
            payload={
                "mode_key": early_state.get("mode_key"),
                "mode_state": early_state.get("mode_state"),
                "primary_flow": early_state.get("primary_flow"),
                "checkpoint": early_state.get("checkpoint"),
                "intent_state": early_state.get("intent_state"),
                "question": early_state.get("question"),
                "current_question": early_state.get("current_question"),
                "followup_question": early_state.get("followup_question"),
                "confirmed_fields": early_state.get("confirmed_fields"),
                "missing_fields": early_state.get("missing_fields"),
                "next_actions": early_state.get("next_actions"),
                "track_result": early_state.get("track_result"),
                "response_strategy_result": early_state.get("response_strategy_result"),
                "module_prompt_registry": early_state.get("module_prompt_registry"),
                "composer_ui": early_state.get("composer_ui"),
                "canvas_analysis_payload": early_state.get("canvas_analysis_payload"),
                "analysis_payload": early_state.get("analysis_payload"),
            },
            final=False,
        )
    )

    confirmed_fields = early_state.get("confirmed_fields") if isinstance(early_state.get("confirmed_fields"), dict) else {}
    missing_fields = early_state.get("missing_fields") if isinstance(early_state.get("missing_fields"), list) else []
    question = early_state.get("question")
    analysis_payload = early_state.get("analysis") if isinstance(early_state.get("analysis"), dict) else {}
    capabilities = early_state.get("capabilities") if isinstance(early_state.get("capabilities"), dict) else {}
    field_retrieval_payload = capabilities.get("field_retrieval") if isinstance(capabilities.get("field_retrieval"), dict) else {}
    recommendation_summary = (
        analysis_payload.get("recommendation_summary")
        if isinstance(analysis_payload.get("recommendation_summary"), dict)
        else {}
    )

    events.append(emit_patch_fn("confirmed_fields", confirmed_fields))
    events.append(emit_patch_fn("missing_fields", {"items": missing_fields}))
    if isinstance(question, dict):
        events.append(emit_patch_fn("current_question", question))
    if field_retrieval_payload:
        events.append(emit_patch_fn("capabilities.field_retrieval", field_retrieval_payload))
    if recommendation_summary:
        events.append(emit_patch_fn("recommendation_summary", recommendation_summary))

    events.append(
        emit_phase_event_fn(
            "phase.update",
            {
                "phase": "intake",
                "label": f"已识别 {len(confirmed_fields)} 个字段，正在确认缺失项",
                "progress": 0.5,
                "meta": {
                    "confirmed_count": len(confirmed_fields),
                    "missing_count": len(missing_fields),
                },
            },
        )
    )
    _ = emit_text_delta_fn

    return events
