"""Helpers for streaming retrieval-phase events."""

from __future__ import annotations

from typing import Any, Callable


def iter_retrieval_phase_events(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    raw_message: str,
    retrieval_queries: list[str],
    retrieval_config: dict[str, Any],
    structured_retrieved_knowledge: list[dict[str, Any]],
    emit_phase_event_fn: Callable[[str, dict[str, Any]], str],
    emit_text_delta_fn: Callable[[str], str],
    emit_event_fn: Callable[[str, dict[str, Any]], str],
    emit_patch_fn: Callable[[str, dict[str, Any]], str],
    build_retrieval_execution_trace_fn: Callable[..., dict[str, Any]],
    build_source_breakdown_fn: Callable[[list[dict[str, Any]]], dict[str, int]],
    build_knowledge_citations_fn: Callable[[list[dict[str, Any]]], list[dict[str, Any]]],
) -> list[str]:
    events: list[str] = []
    events.append(
        emit_phase_event_fn(
            "phase.start",
            {
                "phase": "retrieval",
                "label": "正在检索相关证据",
            },
        )
    )
    _ = emit_text_delta_fn
    query_preview = " / ".join(retrieval_queries[:2]) if retrieval_queries else str(raw_message or "").strip()
    retrieval_start_trace = build_retrieval_execution_trace_fn(
        trace_id=trace_id,
        session_id=session_id,
        mode_key=mode_key,
        status="running",
        detail=f"尝试检索相关信息：{query_preview}",
    )
    events.append(emit_event_fn("execution_trace", retrieval_start_trace))

    retrieval_run_id = f"retrieval-{trace_id}"
    source_breakdown = build_source_breakdown_fn(structured_retrieved_knowledge)
    knowledge_event = {
        "trace_id": trace_id,
        "run_id": retrieval_run_id,
        "query": raw_message,
        "result_count": len(structured_retrieved_knowledge),
        "source_breakdown": source_breakdown,
        "results": structured_retrieved_knowledge,
        "retrieval_config": retrieval_config,
    }
    events.append(emit_event_fn("knowledge_search", knowledge_event))
    citation_event = {
        "trace_id": trace_id,
        "run_id": retrieval_run_id,
        "citations": build_knowledge_citations_fn(structured_retrieved_knowledge),
    }
    events.append(emit_event_fn("knowledge_citation", citation_event))
    events.append(
        emit_patch_fn(
            "analysis.sections",
            {
                "retrieval_candidates": len(structured_retrieved_knowledge),
                "source_breakdown": source_breakdown,
            },
        )
    )
    events.append(
        emit_phase_event_fn(
            "phase.update",
            {
                "phase": "retrieval",
                "label": f"已找到 {len(structured_retrieved_knowledge)} 条候选结果",
                "progress": 0.7,
                "meta": {
                    "candidate_count": len(structured_retrieved_knowledge),
                },
            },
        )
    )

    retrieval_finish_trace = build_retrieval_execution_trace_fn(
        trace_id=trace_id,
        session_id=session_id,
        mode_key=mode_key,
        status="completed",
        detail=f"检索完成：命中 {len(structured_retrieved_knowledge)} 条。",
    )
    events.append(emit_event_fn("execution_trace", retrieval_finish_trace))
    events.append(
        emit_phase_event_fn(
            "phase.end",
            {
                "phase": "retrieval",
                "label": "证据检索完成",
                "status": "succeeded",
            },
        )
    )
    return events
