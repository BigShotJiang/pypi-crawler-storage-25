"""Router streaming module group."""
