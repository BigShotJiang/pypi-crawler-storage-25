"""SSE event emission helpers for kernel streaming responses."""

from __future__ import annotations

import json
import time
from typing import Any, Callable

from flare_kernel.contracts import KernelRequest


class StreamingEventEmitter:
    """Track stream timing markers and generate SSE payload strings."""

    def __init__(
        self,
        *,
        req: KernelRequest,
        trace_id: str,
        session_id: str,
        request_id: str,
        patch_scopes: set[str],
        build_patch_event_fn: Callable[..., dict[str, Any]],
        safe_session_id_fn: Callable[[Any], str],
        run_id: str = "",
        record_event_fn: Callable[[str, dict[str, Any]], Any] | None = None,
    ) -> None:
        self._req = req
        self._trace_id = trace_id
        self._session_id = session_id
        self._request_id = request_id
        self._run_id = str(run_id or "").strip()
        self._patch_scopes = patch_scopes
        self._build_patch_event_fn = build_patch_event_fn
        self._safe_session_id_fn = safe_session_id_fn
        self._record_event_fn = record_event_fn
        self._sequence = 0
        self._event_sequence = 0
        self._first_phase_at = 0
        self._first_patch_at = 0
        self._first_text_at = 0
        # DOC HELPER — ORC-11 terminal run boundary.
        # The emitter is the single transport object that knows whether a
        # terminal `complete` event has been emitted for this stream.
        self._terminal_emitted = False

    @property
    def first_phase_at(self) -> int:
        return self._first_phase_at

    @property
    def first_patch_at(self) -> int:
        return self._first_patch_at

    @property
    def first_text_at(self) -> int:
        return self._first_text_at

    @property
    def terminal_emitted(self) -> bool:
        return self._terminal_emitted

    def _next_sequence(self) -> int:
        self._sequence += 1
        return self._sequence

    def _next_event_sequence(self) -> int:
        self._event_sequence += 1
        return self._event_sequence

    def now_ts(self) -> int:
        return int(time.time() * 1000)

    def _run_state_for(self, event_name: str, payload: dict[str, Any]) -> str:
        state = str(payload.get("run_state") or "").strip()
        if state:
            return state
        status = str(payload.get("status") or "").strip().lower()
        if event_name == "error" or status in {"error", "failed"}:
            return "failed"
        if event_name in {"done", "complete"}:
            return "completed"
        return "running"

    def emit_event(self, event_name: str, payload: dict[str, Any]) -> str:
        if event_name == "complete":
            self._terminal_emitted = True
        event_payload = {
            "trace_id": self._trace_id,
            "session_id": self._session_id,
            "request_id": self._request_id,
            "run_id": self._run_id,
            **payload,
        }
        event_payload.setdefault("run_state", self._run_state_for(event_name, event_payload))
        event_payload.setdefault("ts", self.now_ts())
        event_payload.setdefault("run_event_sequence", self._next_event_sequence())
        if self._record_event_fn is not None:
            self._record_event_fn(event_name, event_payload)
        return f"event: {event_name}\ndata: {json.dumps(event_payload, ensure_ascii=False)}\n\n"

    def emit_phase_event(self, event_name: str, payload: dict[str, Any]) -> str:
        if self._first_phase_at == 0:
            self._first_phase_at = self.now_ts()
        event_payload = {
            "trace_id": self._trace_id,
            "session_id": self._session_id,
            "request_id": self._request_id,
            **payload,
            "ts": self.now_ts(),
        }
        return self.emit_event(event_name, event_payload)

    def emit_patch(self, scope: str, payload: dict[str, Any]) -> str:
        if self._first_patch_at == 0:
            self._first_patch_at = self.now_ts()
        return self.emit_event(
            "patch",
            {
                "trace_id": self._trace_id,
                "session_id": self._session_id,
                "request_id": self._request_id,
                "scope": scope,
                "payload": payload,
                "ts": self.now_ts(),
            },
        )

    def emit_text_delta(self, delta: str) -> str:
        if self._first_text_at == 0:
            self._first_text_at = self.now_ts()
        return self.emit_event(
            "text.delta",
            {
                "trace_id": self._trace_id,
                "session_id": self._session_id,
                "request_id": self._request_id,
                "channel": "assistant",
                "delta": delta,
                "ts": self.now_ts(),
            },
        )

    def emit_text_replace(self, content: str) -> str:
        if self._first_text_at == 0:
            self._first_text_at = self.now_ts()
        return self.emit_event(
            "text.replace",
            {
                "trace_id": self._trace_id,
                "session_id": self._session_id,
                "request_id": self._request_id,
                "channel": "assistant",
                "content": content,
                "ts": self.now_ts(),
            },
        )

    def emit_contract_patch(
        self,
        *,
        event_type: str,
        patch_scope: list[str],
        payload: dict[str, Any],
        final: bool,
    ) -> str:
        patch_event = self._build_patch_event_fn(
            contract_version=str(self._req.contract_version or "flare.v1"),
            trace_id=self._trace_id,
            sequence=self._next_sequence(),
            event_type=event_type,
            client_request_id=self._req.client_request_id or "",
            request_id=self._request_id,
            run_id=self._run_id,
            run_state="completed" if final else "running",
            session_id=self._safe_session_id_fn(self._session_id),
            turn_id=str(self._req.last_turn_id or ""),
            patch_scope=patch_scope,
            payload=payload,
            final=final,
            allowed_scopes=self._patch_scopes,
        )
        return self.emit_event("patch_event", patch_event)
