"""Small streaming response phase adapters."""

from __future__ import annotations

from logging import Logger
from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.streaming.event_emitter import StreamingEventEmitter
from flare_kernel.router.streaming.intake.phase import iter_intake_state_events
from flare_kernel.router.streaming.mode.events import iter_runtime_mode_events
from flare_kernel.router.streaming.retrieval.phase import iter_retrieval_phase_events
from flare_kernel.router.streaming.response.bootstrap import build_bootstrap_event_batch
from flare_kernel.router.streaming.response.runtime import build_post_intake_runtime_batch


def build_streaming_bootstrap_phase(
    *,
    req: KernelRequest,
    trace_id: str,
    session_id: str,
    request_id: str,
    resolved_mode: str,
    mode_source: str,
    resolved_intent: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    instance_profile: dict[str, Any] | None,
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    emitter: StreamingEventEmitter,
    build_mode_switch_reason_fn: Callable[..., dict[str, Any]],
    logger: Logger,
) -> dict[str, Any]:
    """Build the bootstrap batch that seeds the response stream."""
    return build_bootstrap_event_batch(
        req=req,
        trace_id=trace_id,
        session_id=session_id,
        request_id=request_id,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        resolved_intent=resolved_intent,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        instance_profile=instance_profile,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        emitter=emitter,
        build_mode_switch_reason_fn=build_mode_switch_reason_fn,
        logger=logger,
    )


def iter_streaming_intake_phase_events(
    *,
    req: KernelRequest,
    effective_command: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    orchestration_status: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    structured_retrieved_knowledge: list[dict[str, Any]],
    build_canonical_state_fn: Callable[..., dict[str, Any]],
    emit_contract_patch_fn: Callable[..., str],
    emit_patch_fn: Callable[[str, dict[str, Any]], str],
    emit_phase_event_fn: Callable[[str, dict[str, Any]], str],
    emit_text_delta_fn: Callable[[str], str],
) -> list[str]:
    """Build the intake phase events that project canonical state to the stream."""
    return iter_intake_state_events(
        req=req,
        effective_command=effective_command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        orchestration_status=orchestration_status,
        runtime_snapshot=runtime_snapshot,
        structured_retrieved_knowledge=structured_retrieved_knowledge,
        build_canonical_state_fn=build_canonical_state_fn,
        emit_contract_patch_fn=emit_contract_patch_fn,
        emit_patch_fn=emit_patch_fn,
        emit_phase_event_fn=emit_phase_event_fn,
        emit_text_delta_fn=emit_text_delta_fn,
    )


def build_streaming_runtime_phase(
    *,
    req: KernelRequest,
    trace_id: str,
    resolved_mode: str,
    runtime_snapshot: dict[str, Any],
    mode_switch_event: dict[str, Any],
    emitter: StreamingEventEmitter,
    build_orchestration_execution_trace_fn: Callable[..., dict[str, Any]],
    build_agent_step_trace_fn: Callable[..., dict[str, Any]],
) -> dict[str, Any]:
    """Build the runtime batch that carries the post-intake execution trace."""
    return build_post_intake_runtime_batch(
        req=req,
        trace_id=trace_id,
        resolved_mode=resolved_mode,
        runtime_snapshot=runtime_snapshot,
        mode_switch_event=mode_switch_event,
        emitter=emitter,
        build_orchestration_execution_trace_fn=build_orchestration_execution_trace_fn,
        build_agent_step_trace_fn=build_agent_step_trace_fn,
    )


def iter_streaming_retrieval_phase_events(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    raw_message: str,
    retrieval_queries: list[str],
    retrieval_config: dict[str, Any],
    structured_retrieved_knowledge: list[dict[str, Any]],
    emit_phase_event_fn: Callable[[str, dict[str, Any]], str],
    emit_text_delta_fn: Callable[[str], str],
    emit_event_fn: Callable[[str, dict[str, Any]], str],
    emit_patch_fn: Callable[[str, dict[str, Any]], str],
    build_retrieval_execution_trace_fn: Callable[..., dict[str, Any]],
    build_source_breakdown_fn: Callable[[list[dict[str, Any]]], dict[str, int]],
    build_knowledge_citations_fn: Callable[[list[dict[str, Any]]], list[dict[str, Any]]],
) -> list[str]:
    """Build the retrieval phase events that surface evidence search progress."""
    return iter_retrieval_phase_events(
        trace_id=trace_id,
        session_id=session_id,
        mode_key=mode_key,
        raw_message=raw_message,
        retrieval_queries=retrieval_queries,
        retrieval_config=retrieval_config,
        structured_retrieved_knowledge=structured_retrieved_knowledge,
        emit_phase_event_fn=emit_phase_event_fn,
        emit_text_delta_fn=emit_text_delta_fn,
        emit_event_fn=emit_event_fn,
        emit_patch_fn=emit_patch_fn,
        build_retrieval_execution_trace_fn=build_retrieval_execution_trace_fn,
        build_source_breakdown_fn=build_source_breakdown_fn,
        build_knowledge_citations_fn=build_knowledge_citations_fn,
    )


def iter_streaming_mode_phase_events(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    mode_events: list[dict[str, Any]],
    steps_by_id: dict[str, dict[str, Any]],
    skill_by_step: dict[str, dict[str, Any]],
    orchestration_status: dict[str, Any],
    emit_event_fn: Callable[[str, dict[str, Any]], str],
    build_agent_step_trace_fn: Callable[..., dict[str, Any]],
    build_skill_step_trace_fn: Callable[..., dict[str, Any]],
    resolve_step_for_event_fn: Callable[..., str],
    resolve_skill_for_step_fn: Callable[..., dict[str, Any] | None],
) -> list[str]:
    """Build the runtime mode events that mirror orchestrated execution steps."""
    return iter_runtime_mode_events(
        trace_id=trace_id,
        session_id=session_id,
        mode_key=mode_key,
        mode_events=mode_events,
        steps_by_id=steps_by_id,
        skill_by_step=skill_by_step,
        orchestration_status=orchestration_status,
        emit_event_fn=emit_event_fn,
        build_agent_step_trace_fn=build_agent_step_trace_fn,
        build_skill_step_trace_fn=build_skill_step_trace_fn,
        resolve_step_for_event_fn=resolve_step_for_event_fn,
        resolve_skill_for_step_fn=resolve_skill_for_step_fn,
    )


__all__ = [
    "build_streaming_bootstrap_phase",
    "iter_streaming_intake_phase_events",
    "build_streaming_runtime_phase",
    "iter_streaming_retrieval_phase_events",
    "iter_streaming_mode_phase_events",
]
