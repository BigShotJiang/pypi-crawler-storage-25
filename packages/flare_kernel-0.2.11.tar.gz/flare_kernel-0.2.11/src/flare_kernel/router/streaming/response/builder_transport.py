"""Transport-shell helpers for kernel streaming response construction.

This module keeps request metadata parsing and emitter wiring separate from the
public streaming response builder so the builder can stay a thin transport
boundary.
"""

from __future__ import annotations

import time
from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.api.errors import ApiError
from flare_kernel.run_store import RunAlreadyRunningError, record_run_event, start_run
from flare_kernel.router.streaming.event_emitter import StreamingEventEmitter


def _resolve_run_id(req: KernelRequest, trace_id: str) -> str:
    """Resolve canonical run identity at the transport boundary."""

    payload = req.payload if isinstance(req.payload, dict) else {}
    return str(req.run_id or payload.get("run_id") or "").strip() or f"run_{trace_id}"


def build_streaming_response_transport_shell(
    *,
    req: KernelRequest,
    trace_id: str,
    session_id: str,
    patch_scopes: set[str],
    build_patch_event_fn: Callable[..., dict[str, Any]],
    safe_session_id_fn: Callable[[Any], str],
) -> tuple[str, int, StreamingEventEmitter]:
    """Derive request-scoped transport metadata and construct the emitter.

    The builder keeps this work at the transport boundary so downstream phase
    helpers can focus on orchestration and persistence, not request identity
    plumbing.
    """

    request_id = str(req.client_request_id or "").strip() or f"req_{trace_id}"
    run_id = _resolve_run_id(req, trace_id)
    try:
        start_run(run_id=run_id, session_id=session_id, request_id=request_id, trace_id=trace_id)
    except RunAlreadyRunningError as exc:
        raise ApiError(
            code="RUN_ALREADY_RUNNING",
            http_status=409,
            message="run already running",
            description="target session already has an active run",
            context_fields=["session_id"],
            retryable=True,
            details={
                "session_id": exc.session_id,
                "running_run_id": exc.running_run_id,
                "requested_run_id": run_id,
            },
        ) from exc
    stream_started_at = int(time.time() * 1000)
    emitter = StreamingEventEmitter(
        req=req,
        trace_id=trace_id,
        session_id=session_id,
        request_id=request_id,
        patch_scopes=patch_scopes,
        build_patch_event_fn=build_patch_event_fn,
        safe_session_id_fn=safe_session_id_fn,
        run_id=run_id,
        record_event_fn=lambda event_name, payload: record_run_event(event_name=event_name, payload=payload),
    )
    return request_id, stream_started_at, emitter
