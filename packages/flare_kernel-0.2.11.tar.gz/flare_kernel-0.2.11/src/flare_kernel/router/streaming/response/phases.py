"""Public streaming response phase exports."""

from __future__ import annotations

from logging import Logger
from typing import Any, AsyncIterator, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.llm.llm_provider import LLMCompletion
from flare_kernel.router.streaming.event_emitter import StreamingEventEmitter
from flare_kernel.router.streaming.response.draft_phase import iter_streaming_draft_phase_events
from flare_kernel.router.streaming.response.phase_groups import (
    build_streaming_bootstrap_phase,
    build_streaming_runtime_phase,
    iter_streaming_intake_phase_events,
    iter_streaming_mode_phase_events,
    iter_streaming_retrieval_phase_events,
)
from flare_kernel.router.streaming.response.structured_reasoning_phase import (
    iter_structured_reasoning_phase_events,
)


async def iter_kernel_streaming_response_events(
    *,
    req: KernelRequest,
    trace_id: str,
    session_id: str,
    request_id: str,
    stream_started_at: int,
    emitter: StreamingEventEmitter,
    instance_profile: dict[str, Any] | None,
    resolved_intent: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    raw_message: str,
    resolved_mode: str,
    mode_source: str,
    project_id: str,
    user_id: str,
    retrieval_config: dict[str, Any],
    retrieval_queries: list[str],
    retrieval_attempted: bool,
    retrieved_knowledge: list[dict[str, Any]],
    enriched_payload: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    escalation_signal: dict[str, Any],
    effective_command: str,
    structured_retrieved_knowledge: list[dict[str, Any]],
    resolve_turn_completion_fn: Callable[..., Any],
    build_mode_switch_reason_fn: Callable[..., dict[str, Any]],
    build_canonical_state_fn: Callable[..., dict[str, Any]],
    build_orchestration_execution_trace_fn: Callable[..., dict[str, Any]],
    build_agent_step_trace_fn: Callable[..., dict[str, Any]],
    build_skill_step_trace_fn: Callable[..., dict[str, Any]],
    resolve_skill_for_step_fn: Callable[..., dict[str, Any] | None],
    resolve_step_for_event_fn: Callable[..., str],
    build_retrieval_execution_trace_fn: Callable[..., dict[str, Any]],
    build_knowledge_citations_fn: Callable[[list[dict[str, Any]]], list[dict[str, Any]]],
    build_source_breakdown_fn: Callable[[list[dict[str, Any]]], dict[str, int]],
    build_llm_execution_trace_fn: Callable[..., dict[str, Any]],
    resolve_guided_orchestrated_completion_fn: Callable[..., LLMCompletion | None],
    should_persist_memory_record_fn: Callable[..., bool],
    should_force_requirement_clarification_fn: Callable[..., bool],
    build_requirement_clarification_message_fn: Callable[[str], str],
    build_prompt_fn: Callable[[KernelRequest, dict[str, Any], dict[str, Any] | None, str, str], str],
    generate_llm_completion_fn: Callable[..., Any],
    persist_memory_record_fn: Callable[..., dict[str, Any]],
    sanitize_customer_visible_text_fn: Callable[[str], str],
    sanitize_product_name_for_prompt_fn: Callable[[str], str],
    sync_session_intent_stage_fn: Callable[..., None],
    persist_authoritative_intake_state_fn: Callable[..., dict[str, Any]],
    logger: Logger,
) -> AsyncIterator[str]:
    """Yield the complete kernel stream in the preserved phase order."""
    bootstrap_batch = build_streaming_bootstrap_phase(
        req=req,
        trace_id=trace_id,
        session_id=session_id,
        request_id=request_id,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        resolved_intent=resolved_intent,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        instance_profile=instance_profile,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        emitter=emitter,
        build_mode_switch_reason_fn=build_mode_switch_reason_fn,
        logger=logger,
    )
    ack_payload = bootstrap_batch["ack_payload"]
    mode_switch_event = bootstrap_batch["mode_switch_event"]
    for event_payload in bootstrap_batch["events"]:
        yield event_payload

    for event_payload in iter_streaming_intake_phase_events(
        req=req,
        effective_command=effective_command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        orchestration_status=orchestration_status,
        runtime_snapshot=runtime_snapshot,
        structured_retrieved_knowledge=structured_retrieved_knowledge,
        build_canonical_state_fn=build_canonical_state_fn,
        emit_contract_patch_fn=emitter.emit_contract_patch,
        emit_patch_fn=emitter.emit_patch,
        emit_phase_event_fn=emitter.emit_phase_event,
        emit_text_delta_fn=emitter.emit_text_delta,
    ):
        yield event_payload

    runtime_batch = build_streaming_runtime_phase(
        req=req,
        trace_id=trace_id,
        resolved_mode=resolved_mode,
        runtime_snapshot=runtime_snapshot,
        mode_switch_event=mode_switch_event,
        emitter=emitter,
        build_orchestration_execution_trace_fn=build_orchestration_execution_trace_fn,
        build_agent_step_trace_fn=build_agent_step_trace_fn,
    )
    mode_key = str(runtime_batch["mode_key"])
    steps_by_id = runtime_batch["steps_by_id"]
    skill_by_step = runtime_batch["skill_by_step"]
    for event_payload in runtime_batch["events"]:
        yield event_payload

    if retrieval_attempted:
        for event_payload in iter_streaming_retrieval_phase_events(
            trace_id=trace_id,
            session_id=req.session_id,
            mode_key=mode_key,
            raw_message=raw_message,
            retrieval_queries=retrieval_queries,
            retrieval_config=retrieval_config,
            structured_retrieved_knowledge=structured_retrieved_knowledge,
            emit_phase_event_fn=emitter.emit_phase_event,
            emit_text_delta_fn=emitter.emit_text_delta,
            emit_event_fn=emitter.emit_event,
            emit_patch_fn=emitter.emit_patch,
            build_retrieval_execution_trace_fn=build_retrieval_execution_trace_fn,
            build_source_breakdown_fn=build_source_breakdown_fn,
            build_knowledge_citations_fn=build_knowledge_citations_fn,
        ):
            yield event_payload

    for event_payload in iter_streaming_mode_phase_events(
        trace_id=trace_id,
        session_id=req.session_id,
        mode_key=mode_key,
        mode_events=runtime_snapshot["mode_events"],
        steps_by_id=steps_by_id,
        skill_by_step=skill_by_step,
        orchestration_status=orchestration_status,
        emit_event_fn=emitter.emit_event,
        build_agent_step_trace_fn=build_agent_step_trace_fn,
        build_skill_step_trace_fn=build_skill_step_trace_fn,
        resolve_step_for_event_fn=resolve_step_for_event_fn,
        resolve_skill_for_step_fn=resolve_skill_for_step_fn,
    ):
        yield event_payload

    async for event_payload in iter_structured_reasoning_phase_events(
        trace_id=trace_id,
        session_id=session_id,
        raw_message=raw_message,
        resolved_mode=resolved_mode,
        effective_command=effective_command,
        enriched_payload=enriched_payload,
        runtime_snapshot=runtime_snapshot,
        retrieved_knowledge=retrieved_knowledge,
        instance_profile=instance_profile,
        emitter=emitter,
        generate_llm_completion_fn=generate_llm_completion_fn,
    ):
        yield event_payload

    async for event_payload in iter_streaming_draft_phase_events(
        req=req,
        trace_id=trace_id,
        session_id=session_id,
        request_id=request_id,
        stream_started_at=stream_started_at,
        ack_ts=ack_payload["ts"],
        raw_message=raw_message,
        project_id=project_id,
        user_id=user_id,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        effective_command=effective_command,
        retrieved_knowledge=retrieved_knowledge,
        enriched_payload=enriched_payload,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        escalation_signal=escalation_signal,
        instance_profile=instance_profile,
        structured_retrieved_knowledge=structured_retrieved_knowledge,
        emitter=emitter,
        resolve_turn_completion_fn=resolve_turn_completion_fn,
        build_llm_execution_trace_fn=build_llm_execution_trace_fn,
        resolve_guided_orchestrated_completion_fn=resolve_guided_orchestrated_completion_fn,
        should_force_requirement_clarification_fn=should_force_requirement_clarification_fn,
        build_requirement_clarification_message_fn=build_requirement_clarification_message_fn,
        build_prompt_fn=build_prompt_fn,
        generate_llm_completion_fn=generate_llm_completion_fn,
        should_persist_memory_record_fn=should_persist_memory_record_fn,
        persist_memory_record_fn=persist_memory_record_fn,
        sanitize_customer_visible_text_fn=sanitize_customer_visible_text_fn,
        sanitize_product_name_for_prompt_fn=sanitize_product_name_for_prompt_fn,
        sync_session_intent_stage_fn=sync_session_intent_stage_fn,
        persist_authoritative_intake_state_fn=persist_authoritative_intake_state_fn,
        build_canonical_state_fn=build_canonical_state_fn,
        logger=logger,
    ):
        yield event_payload


__all__ = [
    "build_streaming_bootstrap_phase",
    "iter_streaming_intake_phase_events",
    "build_streaming_runtime_phase",
    "iter_streaming_retrieval_phase_events",
    "iter_streaming_mode_phase_events",
    "iter_streaming_draft_phase_events",
    "iter_structured_reasoning_phase_events",
    "iter_kernel_streaming_response_events",
]
