"""Bootstrap event batch builder for kernel streaming responses.

This module isolates the initial intent/intake prelude emission sequence so the
main streaming builder focuses on high-level phase orchestration.
"""

from __future__ import annotations

from typing import Any


def build_bootstrap_event_batch(
    *,
    req,
    trace_id: str,
    session_id: str,
    request_id: str,
    resolved_mode: str,
    mode_source: str,
    resolved_intent: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    instance_profile: dict[str, Any] | None,
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    emitter,
    build_mode_switch_reason_fn,
    logger,
) -> dict[str, Any]:
    """Build initial stream events and metadata required by later phases."""
    running = {"trace_id": trace_id, "state": "RUNNING", "events": [], "result": {}, "next_actions": []}
    ack_payload = {
        "type": "ack",
        "trace_id": trace_id,
        "session_id": session_id,
        "request_id": request_id,
        "mode": resolved_mode,
        "ts": emitter.now_ts(),
    }
    mode_switch_event = build_mode_switch_reason_fn(
        trace_id=trace_id,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        req=req,
    )

    logger.info(
        "kernel.stream.timing t_ack=%s trace_id=%s session_id=%s request_id=%s",
        ack_payload["ts"],
        trace_id,
        session_id,
        request_id,
    )

    events: list[str] = [
        emitter.emit_event("ack", ack_payload),
        emitter.emit_contract_patch(
            event_type="ack",
            patch_scope=[],
            payload={},
            final=False,
        ),
        emitter.emit_event("status", running),
        emitter.emit_phase_event(
            "phase.start",
            {
                "phase": "intent",
                "label": "正在识别当前任务意图",
            },
        ),
    ]

    if instance_profile:
        profile_event = {"trace_id": trace_id, "instance_profile": instance_profile}
        events.append(emitter.emit_event("instance_profile", profile_event))

    mode_runtime_event = {"trace_id": trace_id, **runtime_snapshot["mode_runtime"]}
    events.extend(
        [
            emitter.emit_event("mode_runtime", mode_runtime_event),
            emitter.emit_event("mode_switch_reason", mode_switch_event),
            emitter.emit_event("orchestration_status", orchestration_status),
            emitter.emit_phase_event(
                "phase.end",
                {
                    "phase": "intent",
                    "label": "意图识别完成",
                    "status": "succeeded",
                },
            ),
            emitter.emit_phase_event(
                "phase.start",
                {
                    "phase": "intake",
                    "label": "正在梳理已确认字段与缺失字段",
                },
            ),
        ]
    )

    return {
        "ack_payload": ack_payload,
        "mode_switch_event": mode_switch_event,
        "events": events,
    }
