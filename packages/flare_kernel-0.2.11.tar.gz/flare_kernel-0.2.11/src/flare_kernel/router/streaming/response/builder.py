"""Kernel stream response builder extracted from router endpoint.

This module stays as the public entry point while phase orchestration lives in
dedicated streaming-response helpers.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from fastapi.responses import StreamingResponse

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.llm.llm_provider import LLMCompletion
from flare_kernel.router.completion.selection import (
    resolve_turn_completion,
)
from flare_kernel.router.streaming.response.builder_transport import (
    build_streaming_response_transport_shell,
)
from flare_kernel.router.streaming.response.phases import (
    iter_kernel_streaming_response_events,
)

logger = logging.getLogger(__name__)


def build_kernel_streaming_response(
    *,
    req: KernelRequest,
    trace_id: str,
    session_id: str,
    instance_profile: dict[str, Any] | None,
    resolved_intent: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    raw_message: str,
    resolved_mode: str,
    mode_source: str,
    project_id: str,
    user_id: str,
    retrieval_config: dict[str, Any],
    retrieval_queries: list[str],
    retrieval_attempted: bool,
    retrieved_knowledge: list[dict[str, Any]],
    enriched_payload: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    escalation_signal: dict[str, Any],
    effective_command: str,
    structured_retrieved_knowledge: list[dict[str, Any]],
    build_patch_event_fn: Callable[..., dict[str, Any]],
    safe_session_id_fn: Callable[[Any], str],
    patch_scopes: set[str],
    build_mode_switch_reason_fn: Callable[..., dict[str, Any]],
    build_canonical_state_fn: Callable[..., dict[str, Any]],
    build_orchestration_execution_trace_fn: Callable[..., dict[str, Any]],
    build_agent_step_trace_fn: Callable[..., dict[str, Any]],
    build_skill_step_trace_fn: Callable[..., dict[str, Any]],
    resolve_skill_for_step_fn: Callable[..., dict[str, Any] | None],
    resolve_step_for_event_fn: Callable[..., str],
    build_retrieval_execution_trace_fn: Callable[..., dict[str, Any]],
    build_knowledge_citations_fn: Callable[[list[dict[str, Any]]], list[dict[str, Any]]],
    build_source_breakdown_fn: Callable[[list[dict[str, Any]]], dict[str, int]],
    build_llm_execution_trace_fn: Callable[..., dict[str, Any]],
    resolve_guided_orchestrated_completion_fn: Callable[..., LLMCompletion | None],
    should_persist_memory_record_fn: Callable[..., bool],
    should_force_requirement_clarification_fn: Callable[..., bool],
    build_requirement_clarification_message_fn: Callable[[str], str],
    build_prompt_fn: Callable[[KernelRequest, dict[str, Any], dict[str, Any] | None, str, str], str],
    generate_llm_completion_fn: Callable[..., Any],
    persist_memory_record_fn: Callable[..., dict[str, Any]],
    sanitize_customer_visible_text_fn: Callable[[str], str],
    sanitize_product_name_for_prompt_fn: Callable[[str], str],
    sync_session_intent_stage_fn: Callable[..., None],
    persist_authoritative_intake_state_fn: Callable[..., dict[str, Any]],
) -> StreamingResponse:
    """Build the router-facing streaming response wrapper.

    This function owns the transport shell only:
    - request-scoped identifiers are derived here
    - the streaming event emitter is instantiated here
    - phase sequencing stays delegated to the streaming-response phase helper

    The contract assumption is that the delegated iterator preserves event
    order and side effects; this wrapper only provides the boundary objects.
    """

    request_id, stream_started_at, emitter = build_streaming_response_transport_shell(
        req=req,
        trace_id=trace_id,
        session_id=session_id,
        patch_scopes=patch_scopes,
        build_patch_event_fn=build_patch_event_fn,
        safe_session_id_fn=safe_session_id_fn,
    )

    return StreamingResponse(
        iter_kernel_streaming_response_events(
            req=req,
            trace_id=trace_id,
            session_id=session_id,
            request_id=request_id,
            stream_started_at=stream_started_at,
            emitter=emitter,
            instance_profile=instance_profile,
            resolved_intent=resolved_intent,
            intent_source=intent_source,
            intent_confidence=intent_confidence,
            intent_reason=intent_reason,
            raw_message=raw_message,
            resolved_mode=resolved_mode,
            mode_source=mode_source,
            project_id=project_id,
            user_id=user_id,
            retrieval_config=retrieval_config,
            retrieval_queries=retrieval_queries,
            retrieval_attempted=retrieval_attempted,
            retrieved_knowledge=retrieved_knowledge,
            enriched_payload=enriched_payload,
            runtime_snapshot=runtime_snapshot,
            orchestration_status=orchestration_status,
            escalation_signal=escalation_signal,
            effective_command=effective_command,
            structured_retrieved_knowledge=structured_retrieved_knowledge,
            resolve_turn_completion_fn=resolve_turn_completion,
            build_mode_switch_reason_fn=build_mode_switch_reason_fn,
            build_canonical_state_fn=build_canonical_state_fn,
            build_orchestration_execution_trace_fn=build_orchestration_execution_trace_fn,
            build_agent_step_trace_fn=build_agent_step_trace_fn,
            build_skill_step_trace_fn=build_skill_step_trace_fn,
            resolve_skill_for_step_fn=resolve_skill_for_step_fn,
            resolve_step_for_event_fn=resolve_step_for_event_fn,
            build_retrieval_execution_trace_fn=build_retrieval_execution_trace_fn,
            build_knowledge_citations_fn=build_knowledge_citations_fn,
            build_source_breakdown_fn=build_source_breakdown_fn,
            build_llm_execution_trace_fn=build_llm_execution_trace_fn,
            resolve_guided_orchestrated_completion_fn=resolve_guided_orchestrated_completion_fn,
            should_persist_memory_record_fn=should_persist_memory_record_fn,
            should_force_requirement_clarification_fn=should_force_requirement_clarification_fn,
            build_requirement_clarification_message_fn=build_requirement_clarification_message_fn,
            build_prompt_fn=build_prompt_fn,
            generate_llm_completion_fn=generate_llm_completion_fn,
            persist_memory_record_fn=persist_memory_record_fn,
            sanitize_customer_visible_text_fn=sanitize_customer_visible_text_fn,
            sanitize_product_name_for_prompt_fn=sanitize_product_name_for_prompt_fn,
            sync_session_intent_stage_fn=sync_session_intent_stage_fn,
            persist_authoritative_intake_state_fn=persist_authoritative_intake_state_fn,
            logger=logger,
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )
