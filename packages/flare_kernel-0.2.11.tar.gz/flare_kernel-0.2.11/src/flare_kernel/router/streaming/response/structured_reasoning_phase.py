"""Structured reasoning stream phase helpers."""

from __future__ import annotations

import os
from typing import Any, Callable

from flare_kernel.runtime.orchestration.structured_reasoning import generate_structured_reasoning


def _structured_reasoning_enabled() -> bool:
    raw = str(os.getenv("STRUCTURED_REASONING_ENABLED") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _has_question_answer(payload: dict[str, Any]) -> bool:
    question_answer = payload.get("question_answer")
    if not isinstance(question_answer, dict):
        return False
    field_key = str(question_answer.get("field_key") or "").strip()
    field_value = str(
        question_answer.get("raw_value")
        or question_answer.get("field_value")
        or question_answer.get("selected_option_value")
        or ""
    ).strip()
    return bool(field_key and field_value)


def should_run_structured_reasoning_phase(
    *,
    command: str,
    message: str,
    payload: dict[str, Any],
    generate_llm_completion_fn: Callable[..., Any] | None,
) -> bool:
    if not _structured_reasoning_enabled():
        return False
    if not callable(generate_llm_completion_fn):
        return False
    if not str(message or "").strip():
        return False
    return not (str(command or "").strip() == "submit_intake_answer" and _has_question_answer(payload))


def _attach_structured_reasoning(
    *,
    structured_reasoning: dict[str, Any],
    enriched_payload: dict[str, Any],
    runtime_snapshot: dict[str, Any],
) -> None:
    enriched_payload["structured_reasoning"] = structured_reasoning
    payload = runtime_snapshot.get("payload")
    if isinstance(payload, dict):
        payload["structured_reasoning"] = structured_reasoning


async def iter_structured_reasoning_phase_events(
    *,
    trace_id: str,
    session_id: str,
    raw_message: str,
    resolved_mode: str,
    effective_command: str,
    enriched_payload: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    retrieved_knowledge: list[dict[str, Any]],
    instance_profile: dict[str, Any] | None,
    emitter,
    generate_llm_completion_fn: Callable[..., Any],
):
    """Yield structured reasoning phase events and attach its result in-place."""
    if not should_run_structured_reasoning_phase(
        command=effective_command,
        message=raw_message,
        payload=enriched_payload,
        generate_llm_completion_fn=generate_llm_completion_fn,
    ):
        return

    yield emitter.emit_phase_event(
        "phase.start",
        {
            "phase": "structured_reasoning",
            "label": "正在结构化理解需求",
            "status": "running",
        },
    )
    try:
        structured_reasoning = await generate_structured_reasoning(
            trace_id=trace_id,
            session_id=session_id,
            message=raw_message,
            mode_key=resolved_mode,
            payload=enriched_payload,
            retrieved_knowledge=retrieved_knowledge,
            instance_profile=instance_profile,
            generate_llm_completion_fn=generate_llm_completion_fn,
        )
    except Exception as exc:  # pragma: no cover - defensive stream fallback
        yield emitter.emit_event(
            "error",
            {
                "status": "error",
                "message": "structured reasoning phase failed",
                "errors": [{"fatal": False, "message": str(exc)}],
            },
        )
        yield emitter.emit_phase_event(
            "phase.end",
            {
                "phase": "structured_reasoning",
                "label": "结构化理解失败，继续生成回复",
                "status": "failed",
            },
        )
        return
    if structured_reasoning:
        _attach_structured_reasoning(
            structured_reasoning=structured_reasoning,
            enriched_payload=enriched_payload,
            runtime_snapshot=runtime_snapshot,
        )
        yield emitter.emit_event(
            "structured_reasoning",
            {
                "trace_id": trace_id,
                "session_id": session_id,
                "structured_reasoning": structured_reasoning,
            },
        )
        yield emitter.emit_contract_patch(
            event_type="structured_reasoning",
            patch_scope=["reasoning"],
            payload={"structured_reasoning": structured_reasoning},
            final=False,
        )
    yield emitter.emit_phase_event(
        "phase.end",
        {
            "phase": "structured_reasoning",
            "label": "结构化理解完成",
            "status": "succeeded" if structured_reasoning else "skipped",
        },
    )


__all__ = [
    "iter_structured_reasoning_phase_events",
    "should_run_structured_reasoning_phase",
]
