"""Runtime event batch builder for kernel streaming responses.

These helpers emit deterministic post-intake runtime and trace events and
return resolved step maps for downstream phase emitters.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.router.streaming.runtime.steps import resolve_runtime_step_maps
from flare_kernel.router.streaming.runtime.sourcing_observations import iter_sourcing_observation_traces


def build_post_intake_runtime_batch(
    *,
    req,
    trace_id: str,
    resolved_mode: str,
    runtime_snapshot: dict[str, Any],
    mode_switch_event: dict[str, Any],
    emitter,
    build_orchestration_execution_trace_fn,
    build_agent_step_trace_fn,
) -> dict[str, Any]:
    """Emit runtime/trace events after intake phase and return resolved step maps."""
    orchestration_trace_event = build_orchestration_execution_trace_fn(
        trace_id=trace_id,
        session_id=req.session_id,
        runtime_snapshot=runtime_snapshot,
        mode_switch_event=mode_switch_event,
    )

    mode_key, steps_by_id, skill_by_step = resolve_runtime_step_maps(
        runtime_snapshot=runtime_snapshot,
        resolved_mode=resolved_mode,
    )

    events: list[str] = [
        emitter.emit_event("execution_trace", orchestration_trace_event),
        emitter.emit_event("context_usage", {"trace_id": trace_id, **runtime_snapshot["context_usage"]}),
        emitter.emit_event("agent_runtime", {"trace_id": trace_id, **runtime_snapshot["agent_runtime"]}),
        emitter.emit_event("skill_runtime", {"trace_id": trace_id, **runtime_snapshot["skill_runtime"]}),
    ]
    reasoning_result = runtime_snapshot.get("reasoning_result")
    if isinstance(reasoning_result, dict):
        events.append(emitter.emit_event("reasoning_result", {"trace_id": trace_id, **reasoning_result}))

    intent_router_step = steps_by_id.get("intent_router")
    if isinstance(intent_router_step, dict):
        intent_router_running = build_agent_step_trace_fn(
            trace_id=trace_id,
            session_id=req.session_id,
            mode_key=mode_key,
            step=intent_router_step,
            status="running",
            detail="尝试识别意图并判断下一步处理方式。",
        )
        intent_router_done = build_agent_step_trace_fn(
            trace_id=trace_id,
            session_id=req.session_id,
            mode_key=mode_key,
            step=intent_router_step,
            status="completed",
            detail=f"意图识别完成，进入 {mode_key}。",
        )
        events.extend(
            [
                emitter.emit_event("execution_trace", intent_router_running),
                emitter.emit_event("execution_trace", intent_router_done),
            ]
        )

    payload = runtime_snapshot.get("payload") if isinstance(runtime_snapshot.get("payload"), dict) else {}
    for trace_event in iter_sourcing_observation_traces(
        trace_id=trace_id,
        session_id=req.session_id,
        mode_key=mode_key,
        payload=payload,
    ):
        events.append(emitter.emit_event("execution_trace", trace_event))

    data_ingestion_event = {"trace_id": trace_id, **runtime_snapshot["data_ingestion"]}
    events.extend(
        [
            emitter.emit_event("data_ingestion", data_ingestion_event),
            emitter.emit_phase_event(
                "phase.end",
                {
                    "phase": "intake",
                    "label": "字段梳理完成",
                    "status": "succeeded",
                },
            ),
        ]
    )

    return {
        "events": events,
        "mode_key": mode_key,
        "steps_by_id": steps_by_id,
        "skill_by_step": skill_by_step,
    }
