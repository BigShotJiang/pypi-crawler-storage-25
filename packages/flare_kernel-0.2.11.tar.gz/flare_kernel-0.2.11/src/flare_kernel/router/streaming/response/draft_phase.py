"""Draft-generation phase adapter for kernel streaming responses."""

from __future__ import annotations

from logging import Logger
from typing import Any, AsyncIterator, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.llm.llm_provider import LLMCompletion
from flare_kernel.router.streaming.draft.phase import iter_draft_generation_events
from flare_kernel.router.streaming.event_emitter import StreamingEventEmitter


async def iter_streaming_draft_phase_events(
    *,
    req: KernelRequest,
    trace_id: str,
    session_id: str,
    request_id: str,
    stream_started_at: int,
    ack_ts: int,
    raw_message: str,
    project_id: str,
    user_id: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_source: str,
    effective_command: str,
    retrieved_knowledge: list[dict[str, Any]],
    enriched_payload: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    escalation_signal: dict[str, Any],
    instance_profile: dict[str, Any] | None,
    structured_retrieved_knowledge: list[dict[str, Any]],
    emitter: StreamingEventEmitter,
    resolve_turn_completion_fn: Callable[..., Any],
    build_llm_execution_trace_fn: Callable[..., dict[str, Any]],
    resolve_guided_orchestrated_completion_fn: Callable[..., LLMCompletion | None],
    should_force_requirement_clarification_fn: Callable[..., bool],
    build_requirement_clarification_message_fn: Callable[[str], str],
    build_prompt_fn: Callable[[KernelRequest, dict[str, Any], dict[str, Any] | None, str, str], str],
    generate_llm_completion_fn: Callable[..., Any],
    should_persist_memory_record_fn: Callable[..., bool],
    persist_memory_record_fn: Callable[..., dict[str, Any]],
    sanitize_customer_visible_text_fn: Callable[[str], str],
    sanitize_product_name_for_prompt_fn: Callable[[str], str],
    sync_session_intent_stage_fn: Callable[..., None],
    persist_authoritative_intake_state_fn: Callable[..., dict[str, Any]],
    build_canonical_state_fn: Callable[..., dict[str, Any]],
    logger: Logger,
) -> AsyncIterator[str]:
    """Build the draft-generation phase events that close out the response."""
    async for event_payload in iter_draft_generation_events(
        req=req,
        trace_id=trace_id,
        session_id=session_id,
        request_id=request_id,
        stream_started_at=stream_started_at,
        ack_ts=ack_ts,
        raw_message=raw_message,
        project_id=project_id,
        user_id=user_id,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        effective_command=effective_command,
        retrieved_knowledge=retrieved_knowledge,
        enriched_payload=enriched_payload,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        escalation_signal=escalation_signal,
        instance_profile=instance_profile,
        structured_retrieved_knowledge=structured_retrieved_knowledge,
        emitter=emitter,
        resolve_turn_completion_fn=resolve_turn_completion_fn,
        build_llm_execution_trace_fn=build_llm_execution_trace_fn,
        resolve_guided_orchestrated_completion_fn=resolve_guided_orchestrated_completion_fn,
        should_force_requirement_clarification_fn=should_force_requirement_clarification_fn,
        build_requirement_clarification_message_fn=build_requirement_clarification_message_fn,
        build_prompt_fn=build_prompt_fn,
        generate_llm_completion_fn=generate_llm_completion_fn,
        should_persist_memory_record_fn=should_persist_memory_record_fn,
        persist_memory_record_fn=persist_memory_record_fn,
        sanitize_customer_visible_text_fn=sanitize_customer_visible_text_fn,
        sanitize_product_name_for_prompt_fn=sanitize_product_name_for_prompt_fn,
        sync_session_intent_stage_fn=sync_session_intent_stage_fn,
        persist_authoritative_intake_state_fn=persist_authoritative_intake_state_fn,
        build_canonical_state_fn=build_canonical_state_fn,
        logger=logger,
    ):
        yield event_payload


__all__ = ["iter_streaming_draft_phase_events"]
