"""Mode event payload projection helpers for kernel streaming."""

from __future__ import annotations

from typing import Any


def build_mode_event_payload(
    *,
    trace_id: str,
    event_type: str,
    event_payload: Any,
    orchestration_status: dict[str, Any],
) -> dict[str, Any]:
    if not isinstance(event_payload, dict):
        return {"trace_id": trace_id, "payload": event_payload}

    event_data: dict[str, Any] = {"trace_id": trace_id, **event_payload}

    if event_type in {"field_progress", "next_actions", "requirement_draft", "canvas_state", "canvas_revision"}:
        if orchestration_status.get("intake_session_id"):
            event_data["intake_session_id"] = orchestration_status.get("intake_session_id")
        if orchestration_status.get("intake_session_state"):
            event_data["intake_session_state"] = orchestration_status.get("intake_session_state")
        event_data["intake_session_completed"] = bool(orchestration_status.get("intake_session_completed"))

    if event_type in {"field_progress", "next_actions"}:
        event_data["guided_session"] = orchestration_status.get("guided_session")
        event_data["active_collecting"] = bool(orchestration_status.get("active_collecting"))
        event_data["ready_for_submit"] = bool(orchestration_status.get("ready_for_submit"))
        event_data["decision_point_active"] = bool(orchestration_status.get("decision_point_active"))
        event_data["has_active_question"] = bool(orchestration_status.get("has_active_question"))
        event_data["required_coverage"] = float(orchestration_status.get("required_coverage") or 0.0)
        event_data["total_coverage"] = float(orchestration_status.get("total_coverage") or 0.0)
        event_data["analysis_entry_threshold"] = float(orchestration_status.get("analysis_entry_threshold") or 0.8)
        event_data["analysis_entry_eligible"] = bool(orchestration_status.get("analysis_entry_eligible"))
        event_data["analyzability_score"] = float(orchestration_status.get("analyzability_score") or 0.0)
        if isinstance(orchestration_status.get("intake_understanding"), dict):
            event_data["intake_understanding"] = orchestration_status.get("intake_understanding")

    if event_type == "next_actions":
        event_data["actions"] = orchestration_status.get("next_actions", event_data.get("actions", []))
        event_data["next_actions"] = orchestration_status.get("next_actions", event_data.get("next_actions", []))
        event_data["current_question"] = orchestration_status.get("current_question")
        event_data["required_missing"] = orchestration_status.get("required_missing", event_data.get("required_missing", []))
        event_data["active_collecting"] = bool(orchestration_status.get("active_collecting"))
        event_data["ready_for_submit"] = bool(orchestration_status.get("ready_for_submit"))
        event_data["decision_point_active"] = bool(orchestration_status.get("decision_point_active"))
        event_data["has_active_question"] = bool(orchestration_status.get("has_active_question"))
        event_data["required_coverage"] = float(orchestration_status.get("required_coverage") or 0.0)
        event_data["total_coverage"] = float(orchestration_status.get("total_coverage") or 0.0)
        event_data["analysis_entry_threshold"] = float(orchestration_status.get("analysis_entry_threshold") or 0.8)
        event_data["analysis_entry_eligible"] = bool(orchestration_status.get("analysis_entry_eligible"))
        event_data["flow_state"] = (
            "collecting"
            if bool(orchestration_status.get("active_collecting"))
            else ("completed" if bool(orchestration_status.get("ready_for_submit")) else event_data.get("flow_state", ""))
        )
        event_data["collection_phase"] = event_data["flow_state"]
        event_data["completion_state"] = (
            "ready_for_submit"
            if bool(orchestration_status.get("ready_for_submit"))
            else "collecting"
        )
        blocking = orchestration_status.get("blocking")
        if isinstance(blocking, dict):
            event_data["blocking"] = blocking
            event_data["chooser_required"] = bool(blocking.get("chooser_required"))
            if isinstance(blocking.get("reason"), str) and blocking.get("reason"):
                event_data["blocking_reason"] = blocking.get("reason")
        next_action = orchestration_status.get("next_action")
        if isinstance(next_action, dict) and isinstance(next_action.get("target_field"), str):
            event_data["target_field"] = next_action.get("target_field")
        degrade_reason = orchestration_status.get("degrade_reason")
        if isinstance(degrade_reason, list):
            event_data["degrade_reason"] = degrade_reason

    return event_data
