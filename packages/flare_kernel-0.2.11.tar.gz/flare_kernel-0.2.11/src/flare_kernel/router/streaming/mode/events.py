"""Helpers for emitting runtime mode events during streaming."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.router.streaming.mode.event_payload import build_mode_event_payload
from flare_kernel.router.streaming.runtime.steps import resolve_mode_event_step_context


def iter_runtime_mode_events(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    mode_events: list[dict[str, Any]],
    steps_by_id: dict[str, dict[str, Any]],
    skill_by_step: dict[str, dict[str, Any]],
    orchestration_status: dict[str, Any],
    emit_event_fn: Callable[[str, dict[str, Any]], str],
    build_agent_step_trace_fn: Callable[..., dict[str, Any]],
    build_skill_step_trace_fn: Callable[..., dict[str, Any]],
    resolve_step_for_event_fn: Callable[..., str],
    resolve_skill_for_step_fn: Callable[..., dict[str, Any] | None],
) -> list[str]:
    events: list[str] = []
    for mode_event in mode_events:
        event_type = mode_event.get("event_type")
        if not isinstance(event_type, str) or not event_type.strip():
            continue
        event_payload = mode_event.get("payload") if isinstance(mode_event.get("payload"), dict) else {}
        running_detail = str(event_payload.get("trace_detail_running") or f"执行环节: {event_type}").strip()
        completed_detail = str(event_payload.get("trace_detail_completed") or f"环节完成: {event_type}").strip()

        step, skill_call = resolve_mode_event_step_context(
            mode_key=mode_key,
            event_type=event_type,
            steps_by_id=steps_by_id,
            skill_by_step=skill_by_step,
            resolve_step_for_event_fn=resolve_step_for_event_fn,
            resolve_skill_for_step_fn=resolve_skill_for_step_fn,
        )
        if isinstance(step, dict):
            step_running = build_agent_step_trace_fn(
                trace_id=trace_id,
                session_id=session_id,
                mode_key=mode_key,
                step=step,
                status="running",
                detail=running_detail,
            )
            events.append(emit_event_fn("execution_trace", step_running))
        if isinstance(skill_call, dict):
            skill_running = build_skill_step_trace_fn(
                trace_id=trace_id,
                session_id=session_id,
                mode_key=mode_key,
                skill_call=skill_call,
                status="running",
                detail=running_detail,
            )
            events.append(emit_event_fn("execution_trace", skill_running))

        event_data = build_mode_event_payload(
            trace_id=trace_id,
            event_type=event_type,
            event_payload=mode_event.get("payload"),
            orchestration_status=orchestration_status,
        )
        events.append(emit_event_fn(event_type, event_data))

        if isinstance(step, dict):
            step_done = build_agent_step_trace_fn(
                trace_id=trace_id,
                session_id=session_id,
                mode_key=mode_key,
                step=step,
                status="completed",
                detail=completed_detail,
            )
            events.append(emit_event_fn("execution_trace", step_done))
        if isinstance(skill_call, dict):
            skill_done = build_skill_step_trace_fn(
                trace_id=trace_id,
                session_id=session_id,
                mode_key=mode_key,
                skill_call=skill_call,
                status="completed",
                detail=completed_detail,
            )
            events.append(emit_event_fn("execution_trace", skill_done))
    return events
