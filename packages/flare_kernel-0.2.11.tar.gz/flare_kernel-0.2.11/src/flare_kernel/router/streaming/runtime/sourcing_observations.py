"""Project sourcing observations into stream execution traces."""

from __future__ import annotations

from typing import Any, Iterator


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    return list(value) if isinstance(value, list) else []


def _as_int(value: Any) -> int:
    try:
        return int(value or 0)
    except Exception:
        return 0


def _trace_status(status: Any) -> str:
    normalized = _clean_text(status).lower()
    if normalized in {"failed", "error", "timeout"}:
        return "failed"
    if normalized in {"running", "in_progress", "pending"}:
        return "running"
    return "completed"


def _trace_detail(observation: dict[str, Any]) -> str:
    parts = [
        f"阶段：{_clean_text(observation.get('stage_id'))}",
        f"状态：{_clean_text(observation.get('status'))}",
        f"命中：{_as_int(observation.get('hit_count'))}",
    ]
    source = _clean_text(observation.get("source"))
    reason = _clean_text(observation.get("reason"))
    summary = _clean_text(observation.get("summary"))
    if source:
        parts.append(f"来源：{source}")
    if summary:
        parts.append(f"摘要：{summary}")
    if reason:
        parts.append(f"原因：{reason}")
    return "；".join(parts)


def iter_sourcing_observation_traces(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    payload: dict[str, Any],
) -> Iterator[dict[str, Any]]:
    search_state = _as_dict(payload.get("sourcing_search"))
    observations = _as_list(search_state.get("observations"))
    for observation_value in observations:
        observation = _as_dict(observation_value)
        stage_id = _clean_text(observation.get("stage_id"))
        if not stage_id:
            continue
        yield {
            "trace_id": trace_id,
            "session_id": session_id,
            "step_id": f"sourcing_observation:{mode_key}:{stage_id}",
            "agent": "sourcing_orchestrator",
            "stage": "orchestration",
            "label": f"寻源检索 {stage_id}",
            "detail": _trace_detail(observation),
            "reason": _clean_text(observation.get("reason")),
            "status": _trace_status(observation.get("status")),
            "observation": observation,
        }


__all__ = ["iter_sourcing_observation_traces"]
