"""Runtime step indexing helpers for streaming response assembly."""

from __future__ import annotations

from typing import Any, Callable


def resolve_runtime_step_maps(
    *,
    runtime_snapshot: dict[str, Any],
    resolved_mode: str,
) -> tuple[str, dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
    mode_key = str(runtime_snapshot.get("mode_key") or resolved_mode or "unknown")

    agent_steps = runtime_snapshot.get("agent_runtime", {}).get("agent_step")
    if not isinstance(agent_steps, list):
        agent_steps = []
    steps_by_id: dict[str, dict[str, Any]] = {
        str(step.get("step_id")): step
        for step in agent_steps
        if isinstance(step, dict) and isinstance(step.get("step_id"), str)
    }

    skill_calls = runtime_snapshot.get("skill_runtime", {}).get("skill_call")
    if not isinstance(skill_calls, list):
        skill_calls = []
    skill_by_step: dict[str, dict[str, Any]] = {}
    for skill_call in skill_calls:
        if not isinstance(skill_call, dict):
            continue
        skill_agent_id = str(skill_call.get("agent_id") or "")
        for step_id, step in steps_by_id.items():
            if str(step.get("agent_id") or "") == skill_agent_id:
                skill_by_step[step_id] = skill_call
                break

    return mode_key, steps_by_id, skill_by_step


def resolve_mode_event_step_context(
    *,
    mode_key: str,
    event_type: str,
    steps_by_id: dict[str, dict[str, Any]],
    skill_by_step: dict[str, dict[str, Any]],
    resolve_step_for_event_fn: Callable[..., str],
    resolve_skill_for_step_fn: Callable[..., dict[str, Any] | None],
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    step_id = resolve_step_for_event_fn(
        mode_key=mode_key,
        event_type=event_type,
        steps_by_id=steps_by_id,
    )
    step = steps_by_id.get(step_id) if step_id else None
    skill_call = (
        resolve_skill_for_step_fn(step_id=step_id, skill_by_step=skill_by_step)
        if step_id
        else None
    )
    return (
        step if isinstance(step, dict) else None,
        skill_call if isinstance(skill_call, dict) else None,
    )
