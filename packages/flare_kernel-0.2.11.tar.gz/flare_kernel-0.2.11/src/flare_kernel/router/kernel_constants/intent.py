"""Intent and interaction language constants for kernel routing."""

from __future__ import annotations


_NEUTRAL_INTENT_KEYWORDS = {
    "requirement_intake": ("梳理", "需求梳理", "requirement_intake"),
    "intelligent_sourcing": ("寻源", "智能寻源", "intelligent_sourcing"),
    "analysis_mode": ("分析", "需求分析", "analysis_mode"),
}

INTENT_KEYWORDS = {
    "requirement_intake": _NEUTRAL_INTENT_KEYWORDS["requirement_intake"],
    "intelligent_sourcing": _NEUTRAL_INTENT_KEYWORDS["intelligent_sourcing"],
    "analysis_mode": _NEUTRAL_INTENT_KEYWORDS["analysis_mode"],
}
ROUTABLE_MODES = {"requirement_intake", "analysis_mode", "intelligent_sourcing"}
SUGGESTABLE_MODES = {"default", "requirement_intake", "analysis_mode", "intelligent_sourcing"}
DEFAULT_INTENT_ALIASES: dict[str, str] = {}
SESSION_INTENT_STAGES = {
    "small_talk",
    "general_qa",
    "business_intake_candidate",
    "clarification_in_progress",
    "analysis_ready",
    "analysis_running",
}
REQUIREMENT_ENTRY_EXPLICIT_PHRASES = (
    "请先帮我梳理",
    "请帮我梳理",
    "请梳理",
    "帮我梳理一下",
    "帮我梳理需求",
    "帮我做需求梳理",
    "先帮我梳理",
    "先梳理需求",
    "先梳理一下",
    "先做需求梳理",
    "帮我把需求说清楚",
    "把需求说清楚",
    "先收口",
    "先整理需求",
)
REQUIREMENT_ENTRY_STRUCTURING_TERMS = (
    "梳理",
    "整理",
    "整理需求",
    "收口",
    "需求梳理",
    "需求说清楚",
)
REQUIREMENT_ENTRY_CONTEXT_TERMS = (
    "需求",
    "requirement_intake",
)
QUESTION_TERMS = (
    "?",
    "？",
    "怎么",
    "如何",
    "请问",
    "建议",
    "推荐",
    "是否",
    "哪些",
    "什么",
    "先确认",
)
SMALL_TALK_HINTS = (
    "你好",
    "您好",
    "哈喽",
    "嗨",
    "hello",
    "hi",
    "在吗",
    "你是谁",
    "你是做什么的",
    "你能干什么",
    "你能做什么",
    "你可以做什么",
    "你都能做什么",
    "你会什么",
    "你会做什么",
    "你有什么能力",
    "可以帮我做什么",
    "能帮我做什么",
    "你主要做什么",
    "怎么称呼",
    "叫什么",
    "早上好",
    "中午好",
    "下午好",
    "晚上好",
    "谢谢",
    "再见",
)
SMALL_TALK_INTRO_IDENTITY_HINTS = (
    "你是谁",
    "你叫什么",
    "怎么称呼",
    "你是做什么",
    "你是做什么的",
    "介绍一下你自己",
)
SMALL_TALK_INTRO_CAPABILITY_HINTS = (
    "你能干什么",
    "你能做什么",
    "你可以做什么",
    "你都能做什么",
    "你会什么",
    "你会做什么",
    "你有什么能力",
    "能帮我做什么",
    "可以帮我做什么",
    "你主要做什么",
)
