"""Patch scope constants for flare.v1 contract emission.

DOC HELPER — OBJ-09 patch authority allowlist.
`context_authority` is an authoritative backend scope; consumers may project it
but must not synthesize equivalent frontend authority.
"""

from __future__ import annotations

PATCH_SCOPES_AUTHORITATIVE = {
    "session",
    "assistant_reply",
    "context_authority",
    "primary_flow",
    "checkpoint",
    "intent_state",
    "question",
    "confirmed_fields",
    "missing_fields",
    "next_actions",
    "track_result",
    "response_strategy_result",
    "module_prompt_registry",
    "composer_ui",
    "analysis",
    "observation",
    "capabilities.field_retrieval",
    "errors",
    "reasoning",
}
PATCH_SCOPES_LEGACY_COMPAT = {
    "current_question",
    "recommendation_summary",
}
PATCH_SCOPES_OBSERVATION = {
    "confirmed_fields",
    "missing_fields",
    "current_question",
    "analysis.sections",
    "capabilities.field_retrieval",
    "recommendation_summary",
}
PATCH_SCOPES = set(PATCH_SCOPES_AUTHORITATIVE)
