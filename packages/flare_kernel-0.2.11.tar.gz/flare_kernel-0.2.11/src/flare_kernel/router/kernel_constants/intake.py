"""Intake flow state constants for kernel orchestration."""

from __future__ import annotations

INTAKE_EXIT_HINTS = (
    "先这样",
    "稍后再补",
    "稍后再说",
    "先暂停",
    "暂停梳理",
    "停止梳理",
    "结束梳理",
    "先给我看分析",
    "先看分析",
    "先做分析",
    "先出分析",
)
FLOW_ALLOWED_STATUSES_BY_STAGE = {
    "general_chat": {"idle", "error"},
    "requirement_intake": {"collecting", "blocked", "ready_for_submit", "error"},
    "requirement_analysis": {"active", "completed", "error"},
}
DEFAULT_INTENT_ESCALATION_POLICY = {
    "enable_recommendation_trigger": True,
    "enable_auto_mode_override": True,
    "recommendation_min_confidence": 0.58,
    "auto_mode_override_min_confidence": 0.72,
    "require_domain_relevance_for_recommendation": False,
    "require_domain_relevance_for_auto_override": False,
}
