"""Text normalization and customer-safe rendering helpers for router workflows."""

from __future__ import annotations

import re
from typing import Any

_CUSTOMER_ROLE_SAFE_FALLBACK = "智能工作流助手"
_CUSTOMER_SAFE_REPLY_FALLBACK = "你好，我是智能工作流助手，可以帮你进行需求梳理、分析和证据检索。"
_CUSTOMER_VISIBLE_FORBIDDEN_TERMS = (
    "flare",
    "flarekernel",
    "kernel",
    "subagent",
    "orchestration",
    "canonicalstate",
    "moderuntime",
    "analysisengine",
    "repo",
    "repository",
    "github",
    "仓库",
    "内核",
    "子代理",
    "编排",
)
_CUSTOMER_VISIBLE_FORBIDDEN_LATIN_TERMS = tuple(
    term for term in _CUSTOMER_VISIBLE_FORBIDDEN_TERMS if re.fullmatch(r"[a-z0-9]+", term)
)
_CUSTOMER_VISIBLE_FORBIDDEN_CJK_TERMS = tuple(
    term for term in _CUSTOMER_VISIBLE_FORBIDDEN_TERMS if term not in _CUSTOMER_VISIBLE_FORBIDDEN_LATIN_TERMS
)
_CUSTOMER_SAFE_REPLACEMENTS: tuple[tuple[str, str], ...] = (
    (r"f\.?\s*l\.?\s*a\.?\s*r\.?\s*e\.?\s*kernel", _CUSTOMER_ROLE_SAFE_FALLBACK),
    (r"\bflare\s*kernel\b", _CUSTOMER_ROLE_SAFE_FALLBACK),
    (r"f\.?\s*l\.?\s*a\.?\s*r\.?\s*e\.?", "工作流助手"),
    (r"\bflare\b", "工作流助手"),
    (r"\bkernel\b", "助手"),
    (r"\bsubagent\b", "助手流程"),
    (r"\borchestration\b", "流程"),
    (r"\bcanonical\s*state\b", "会话状态"),
    (r"\bmode\s*runtime\b", "运行状态"),
    (r"\banalysis\s*engine\b", "分析能力"),
    (r"内核", "助手"),
    (r"子代理", "助手流程"),
    (r"编排", "流程"),
)


def has_value(value: Any) -> bool:
    return value not in (None, "", [], {})


def extract_user_message(payload: dict[str, Any] | None) -> str:
    if not isinstance(payload, dict):
        return ""
    raw_message = payload.get("message")
    if isinstance(raw_message, str):
        return raw_message.strip()
    return ""


def normalize_message_text(value: Any) -> str:
    return str(value or "").strip().lower()


def contains_any_text(message: str, candidates: tuple[str, ...]) -> bool:
    return any(token for token in candidates if token and token in message)


def normalize_for_customer_safety(text: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", str(text or "").strip().lower())


def contains_customer_visible_forbidden_terms(text: str) -> bool:
    raw_text = str(text or "")
    if not raw_text.strip():
        return False
    if re.search(r"f\.?\s*l\.?\s*a\.?\s*r\.?\s*e\.?", raw_text, flags=re.IGNORECASE):
        return True
    normalized = normalize_for_customer_safety(raw_text)
    if any(term in normalized for term in _CUSTOMER_VISIBLE_FORBIDDEN_CJK_TERMS):
        return True
    normalized_latin = raw_text.lower()
    return any(
        re.search(rf"(?<![a-z0-9]){re.escape(term)}(?![a-z0-9])", normalized_latin)
        for term in _CUSTOMER_VISIBLE_FORBIDDEN_LATIN_TERMS
    )


def sanitize_product_name_for_prompt(raw_name: str) -> str:
    text = str(raw_name or "").strip()
    if not text:
        return ""
    if contains_customer_visible_forbidden_terms(text):
        return _CUSTOMER_ROLE_SAFE_FALLBACK
    return text


def sanitize_customer_visible_text(raw_text: str) -> str:
    text = str(raw_text or "")
    if not text.strip():
        return text
    sanitized = text
    for pattern, replacement in _CUSTOMER_SAFE_REPLACEMENTS:
        sanitized = re.sub(pattern, replacement, sanitized, flags=re.IGNORECASE)
    if contains_customer_visible_forbidden_terms(sanitized):
        return _CUSTOMER_SAFE_REPLY_FALLBACK
    return sanitized
