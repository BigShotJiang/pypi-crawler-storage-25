"""Knowledge retrieval aggregation helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime import search_knowledge_records


def _normalize_entities(entities: list[dict[str, Any] | str] | None) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in entities or []:
        if isinstance(item, str):
            text = str(item).strip()
            normalized_text = text.lower()
            aliases = [text, normalized_text] if text else []
        elif isinstance(item, dict):
            text = str(item.get("text") or item.get("value") or item.get("name") or "").strip()
            normalized_text = str(item.get("normalized") or item.get("entity_normalized") or text).strip().lower()
            aliases = []
            if isinstance(item.get("aliases"), list):
                aliases.extend(str(alias).strip() for alias in item.get("aliases") or [] if str(alias).strip())
            for value in (text, normalized_text):
                if value:
                    aliases.append(value)
        else:
            continue
        if not text:
            continue
        dedup_key = normalized_text or text.lower()
        if dedup_key in seen:
            continue
        seen.add(dedup_key)
        cleaned_aliases: list[str] = []
        seen_aliases: set[str] = set()
        for alias in aliases:
            alias_text = str(alias or "").strip()
            alias_key = alias_text.lower()
            if not alias_text or alias_key in seen_aliases:
                continue
            seen_aliases.add(alias_key)
            cleaned_aliases.append(alias_text)
        normalized.append({"text": text, "normalized": normalized_text, "aliases": cleaned_aliases})
    return normalized


def _resolve_query_lane(query: str, entities: list[dict[str, Any]]) -> str:
    query_text = str(query or "").strip().lower()
    if not query_text or not entities:
        return "semantic"
    for entity in entities:
        aliases = entity.get("aliases") if isinstance(entity.get("aliases"), list) else []
        if query_text == str(entity.get("text") or "").strip().lower():
            return "entity_exact"
        if query_text in {str(alias).strip().lower() for alias in aliases if str(alias).strip()}:
            return "entity_alias"
    return "semantic"


def search_knowledge_by_queries(
    *,
    trace_id: str,
    project_id: str,
    user_id: str,
    queries: list[str],
    top_k: int,
    min_score: float,
    source_ids: list[str] | None = None,
    entities: list[dict[str, Any] | str] | None = None,
    entity_query_mode: str = "prefer",
    search_knowledge_records_fn: Any | None = None,
) -> list[dict[str, Any]]:
    if not queries:
        return []
    search_records = search_knowledge_records_fn or search_knowledge_records
    normalized_entities = _normalize_entities(entities)
    merged: list[dict[str, Any]] = []
    seen_keys: set[tuple[str, str]] = set()
    for query in queries:
        lane = _resolve_query_lane(str(query or ""), normalized_entities)
        search_kwargs: dict[str, Any] = {
            "trace_id": trace_id,
            "project_id": project_id,
            "user_id": user_id,
            "query": query,
            "top_k": top_k,
            "min_score": min_score,
            "source_ids": source_ids,
            "entities": normalized_entities,
            "entity_query_mode": entity_query_mode,
            "query_lane": lane,
        }
        try:
            hits = search_records(**search_kwargs)
        except TypeError:
            search_kwargs.pop("entities", None)
            search_kwargs.pop("entity_query_mode", None)
            search_kwargs.pop("query_lane", None)
            hits = search_records(**search_kwargs)
        for item in hits:
            if not isinstance(item, dict):
                continue
            dedup_key = (
                str(item.get("record_id") or ""),
                str(item.get("chunk_id") or ""),
            )
            if dedup_key in seen_keys:
                continue
            seen_keys.add(dedup_key)
            normalized_item = dict(item)
            if str(normalized_item.get("matched_query") or "").strip() == "":
                normalized_item["matched_query"] = str(query or "").strip()
            if str(normalized_item.get("query_lane") or "").strip() == "":
                normalized_item["query_lane"] = lane
            if not isinstance(normalized_item.get("matched_entities"), list) and normalized_entities:
                query_text = str(query or "").strip().lower()
                matched_entities = []
                for entity in normalized_entities:
                    aliases = entity.get("aliases") if isinstance(entity.get("aliases"), list) else []
                    if query_text in {str(alias).strip().lower() for alias in aliases if str(alias).strip()}:
                        matched_entities.append(str(entity.get("text") or "").strip())
                normalized_item["matched_entities"] = matched_entities
                normalized_item["entity_matched"] = bool(matched_entities)
            merged.append(normalized_item)
    return sorted(merged, key=lambda item: float(item.get("score") or 0.0), reverse=True)[: max(1, min(top_k, 20))]
