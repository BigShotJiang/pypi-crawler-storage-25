"""Retrieval result projection helpers for router outputs."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts import KernelRequest


def _resolve_citation_clue(item: dict[str, Any]) -> str:
    for key in ("matched_text", "hit_reason", "why_relevant"):
        value = str(item.get(key) or "").strip()
        if value:
            return value
    snippet = str(item.get("snippet") or item.get("content") or "").strip()
    query = str(item.get("query") or item.get("matched_query") or "").strip()
    if snippet and query and len(query) >= 2:
        query_pos = snippet.lower().find(query.lower())
        if query_pos >= 0:
            start = max(0, query_pos - 24)
            end = min(len(snippet), query_pos + len(query) + 36)
            return snippet[start:end].strip()
    return ""


def resolve_retrieval_config(req: KernelRequest, payload: dict[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = {}
    if isinstance(payload.get("retrieval_config"), dict):
        merged.update(payload["retrieval_config"])
    if isinstance(req.retrieval_config, dict):
        merged.update(req.retrieval_config)
    enabled = merged.get("enabled", True)
    top_k = merged.get("top_k", 5)
    min_score = merged.get("min_score", 0.0)
    try:
        top_k = max(1, min(int(top_k), 20))
    except Exception:
        top_k = 5
    try:
        min_score = float(min_score)
    except Exception:
        min_score = 0.0
    return {
        "enabled": bool(enabled),
        "top_k": top_k,
        "min_score": min_score,
    }


def build_knowledge_citations(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    citations: list[dict[str, Any]] = []
    for index, item in enumerate(results[:3], start=1):
        snippet = str(item.get("content") or item.get("snippet") or "")[:220]
        matched_text = _resolve_citation_clue(item)
        matched_query = item.get("query") or item.get("matched_query")
        matched_terms = item.get("matched_terms")
        normalized_terms = matched_terms if isinstance(matched_terms, list) else []
        matched_entities = item.get("matched_entities")
        normalized_entities = matched_entities if isinstance(matched_entities, list) else []
        source_type = item.get("source_type") or item.get("source")
        confidence = item.get("confidence")
        hit_dimensions = (
            item.get("hit_dimensions")
            if isinstance(item.get("hit_dimensions"), dict)
            else {
                "matched_query": matched_query,
                "matched_terms": normalized_terms,
                "matched_entities": normalized_entities,
                "entity_matched": bool(item.get("entity_matched")),
                "entity_match_score": item.get("entity_match_score"),
                "entity_query_mode": item.get("entity_query_mode"),
                "query_lane": item.get("query_lane"),
                "matched_field": item.get("matched_field"),
                "source_type": source_type,
                "confidence": confidence,
            }
        )
        citations.append(
            {
                "citation_id": f"cite_{index}",
                "record_id": item.get("record_id"),
                "chunk_id": item.get("chunk_id"),
                "source_id": item.get("source_id"),
                "title": item.get("title"),
                "url": item.get("url") or item.get("canonical_url"),
                "canonical_url": item.get("canonical_url") or item.get("url"),
                "source_domain": item.get("source_domain"),
                "score": item.get("score"),
                "snippet": snippet,
                "query": matched_query,
                "matched_text": matched_text,
                "hit_reason": matched_text,
                "matched_terms": normalized_terms,
                "matched_entities": normalized_entities,
                "entity_matched": bool(item.get("entity_matched")),
                "entity_match_score": item.get("entity_match_score"),
                "entity_query_mode": item.get("entity_query_mode"),
                "query_lane": item.get("query_lane"),
                "matched_field": item.get("matched_field"),
                "source_type": source_type,
                "confidence": confidence,
                "rank": index,
                "hit_dimensions": hit_dimensions,
            }
        )
    return citations


def infer_retrieval_source_bucket(item: dict[str, Any]) -> str:
    raw_source = str(item.get("source_type") or item.get("source") or "").strip().lower()
    if not raw_source:
        return "local"
    if "web" in raw_source:
        return "web"
    if "mcp" in raw_source:
        return "mcp"
    return "local"


def build_source_breakdown(results: list[dict[str, Any]]) -> dict[str, int]:
    breakdown = {"local": 0, "mcp": 0, "web": 0}
    for item in results:
        if not isinstance(item, dict):
            continue
        bucket = infer_retrieval_source_bucket(item)
        breakdown[bucket] = int(breakdown.get(bucket, 0)) + 1
    return breakdown
