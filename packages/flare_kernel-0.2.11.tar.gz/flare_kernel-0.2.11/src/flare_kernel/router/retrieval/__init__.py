"""Router retrieval module group."""

from __future__ import annotations

import importlib
import sys

_LEGACY_MODULE_TARGETS = {
    "retrieval_aliases": "flare_kernel.router.retrieval.aliases",
    "retrieval_field_queries": "flare_kernel.router.retrieval.field_queries",
    "retrieval_projection": "flare_kernel.router.retrieval.projection",
    "retrieval_query_builder": "flare_kernel.router.retrieval.query_builder",
    "retrieval_search": "flare_kernel.router.retrieval.search",
}

for _legacy_name, _target in _LEGACY_MODULE_TARGETS.items():
    sys.modules.setdefault(
        f"flare_kernel.router.retrieval.{_legacy_name}",
        importlib.import_module(_target),
    )
