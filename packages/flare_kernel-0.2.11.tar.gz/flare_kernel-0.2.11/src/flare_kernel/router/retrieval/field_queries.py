"""Field query extraction helpers for retrieval routing."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest


def resolve_retrieval_field_queries(
    req: KernelRequest,
    *,
    normalize_field_value_payload_fn: Callable[[Any], tuple[str, str]],
) -> list[tuple[str, str]]:
    payload = req.payload if isinstance(req.payload, dict) else {}
    field_pairs: list[tuple[str, str]] = []
    seen_pairs: set[tuple[str, str]] = set()

    def _add_pair(field_key: Any, raw_value: Any) -> None:
        normalized_field_key = str(field_key or "").strip()
        if not normalized_field_key:
            return
        field_value, display_value = normalize_field_value_payload_fn(raw_value)
        normalized_field_value = str(display_value or field_value or "").strip()
        if not normalized_field_value:
            return
        pair = (normalized_field_key, normalized_field_value)
        if pair in seen_pairs:
            return
        seen_pairs.add(pair)
        field_pairs.append(pair)

    payload_field_key = str(payload.get("field_key") or req.field_key or "").strip()
    if payload_field_key:
        if req.field_value is not None:
            _add_pair(payload_field_key, req.field_value.model_dump())
        _add_pair(payload_field_key, payload.get("field_value"))

    question_answer = payload.get("question_answer")
    if isinstance(question_answer, dict):
        _add_pair(question_answer.get("field_key") or payload_field_key, question_answer.get("field_value"))

    fields = payload.get("fields")
    if isinstance(fields, dict) and payload_field_key in fields:
        _add_pair(payload_field_key, fields.get(payload_field_key))

    confirmed_fields = payload.get("confirmed_fields")
    if isinstance(confirmed_fields, dict) and payload_field_key in confirmed_fields:
        _add_pair(payload_field_key, confirmed_fields.get(payload_field_key))

    workspace_patch = payload.get("workspace_patch")
    if isinstance(workspace_patch, dict) and payload_field_key in workspace_patch:
        _add_pair(payload_field_key, workspace_patch.get(payload_field_key))

    workspace_patches = payload.get("workspace_patches")
    if isinstance(workspace_patches, list):
        for patch in workspace_patches:
            if not isinstance(patch, dict):
                continue
            _add_pair(patch.get("field_key") or payload_field_key, patch.get("field_value"))

    current_question = payload.get("current_question")
    if isinstance(current_question, dict) and not payload_field_key:
        _add_pair(current_question.get("field_key"), current_question.get("field_value"))

    if payload_field_key and all(existing_key != payload_field_key for existing_key, _ in field_pairs):
        # Field-retrieval commands may only provide field_key; keep one fallback pair
        # so query templates can still resolve a usable search query.
        field_pairs.append((payload_field_key, payload_field_key))

    return field_pairs
