"""Intent alias normalization helpers for retrieval routing."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime import load_instance_profile
from flare_kernel.runtime.domain.domain_pack_loader import load_domain_pack, resolve_domain_pack_domain
from flare_kernel.runtime.orchestration.session_context_runtime import load_session_context_snapshot


def _clean_context_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _build_session_intent_context(req: KernelRequest) -> str:
    session_context = load_session_context_snapshot(str(req.session_id or "").strip())
    if not isinstance(session_context, dict) or not session_context:
        return ""

    parts: list[str] = []
    summary = _clean_context_text(session_context.get("session_summary"))
    if summary:
        parts.append(summary)

    confirmed_fields = session_context.get("confirmed_fields")
    if isinstance(confirmed_fields, dict):
        for key, value in confirmed_fields.items():
            field_key = _clean_context_text(key)
            field_value = _clean_context_text(value)
            if not field_key or not field_value:
                continue
            parts.append(f"{field_key} {field_value}")
            if len(parts) >= 5:
                break

    turns = session_context.get("turns")
    if isinstance(turns, list):
        for item in turns[-2:]:
            if not isinstance(item, dict):
                continue
            user_message = _clean_context_text(item.get("user_message"))
            assistant_message = _clean_context_text(item.get("assistant_message"))
            if user_message:
                parts.append(user_message)
            if assistant_message:
                parts.append(assistant_message)
            if len(parts) >= 7:
                break

    return " ".join(part for part in parts if part).strip()


def normalize_intent_alias_entries(raw_aliases: Any) -> dict[str, str]:
    normalized: dict[str, str] = {}
    if isinstance(raw_aliases, dict):
        for alias, canonical in raw_aliases.items():
            alias_text = str(alias or "").strip().lower()
            canonical_text = str(canonical or "").strip().lower()
            if alias_text and canonical_text:
                normalized[alias_text] = canonical_text
        return normalized

    if isinstance(raw_aliases, list):
        for entry in raw_aliases:
            if not isinstance(entry, dict):
                continue
            alias_text = str(entry.get("alias") or entry.get("from") or "").strip().lower()
            canonical_text = str(entry.get("canonical") or entry.get("to") or entry.get("value") or "").strip().lower()
            if alias_text and canonical_text:
                normalized[alias_text] = canonical_text
    return normalized


def resolve_intent_aliases(
    req: KernelRequest,
    *,
    default_intent_aliases: dict[str, str],
    instance_profile: dict[str, Any] | None = None,
    load_instance_profile_fn: Callable[[str | None], dict[str, Any] | None] | None = None,
    load_domain_pack_fn: Callable[..., Any] | None = None,
) -> dict[str, str]:
    aliases = dict(default_intent_aliases)
    profile_loader = load_instance_profile_fn or load_instance_profile
    domain_pack_loader = load_domain_pack_fn or load_domain_pack

    resolved_profile = (
        instance_profile
        if isinstance(instance_profile, dict)
        else profile_loader(req.instance_id)
    )
    domain_pack_obj = domain_pack_loader(
        instance_id=req.instance_id,
        domain_pack_version=req.domain_pack_version,
        domain=resolve_domain_pack_domain(payload=req.payload, instance_profile=resolved_profile),
    )
    domain_aliases = {}
    domain_pack = domain_pack_obj.to_dict()
    if isinstance(domain_pack, dict):
        taxonomy = domain_pack.get("taxonomy")
        if isinstance(taxonomy, dict):
            domain_aliases = taxonomy.get("intent_aliases") or taxonomy.get("domain_aliases") or {}
        if not domain_aliases:
            domain_aliases = domain_pack.get("intent_aliases") or domain_pack.get("domain_aliases") or {}
    aliases.update(normalize_intent_alias_entries(domain_aliases))

    profile_aliases = {}
    if isinstance(resolved_profile, dict):
        profile_aliases = (
            resolved_profile.get("intent_aliases")
            or resolved_profile.get("domain_aliases")
            or {}
        )
    aliases.update(normalize_intent_alias_entries(profile_aliases))
    return aliases


def normalize_message_for_intent(
    req: KernelRequest,
    *,
    message: str,
    default_intent_aliases: dict[str, str],
    instance_profile: dict[str, Any] | None = None,
) -> str:
    normalized = str(message or "").strip().lower()
    if not normalized:
        return ""
    session_context_text = _build_session_intent_context(req)
    aliases = resolve_intent_aliases(
        req,
        default_intent_aliases=default_intent_aliases,
        instance_profile=instance_profile,
    )
    canonical_tokens: list[str] = []
    if aliases:
        for alias, canonical in aliases.items():
            if alias and canonical and alias in normalized and canonical not in canonical_tokens:
                canonical_tokens.append(canonical)
    parts = [normalized]
    if canonical_tokens:
        parts.append(" ".join(canonical_tokens))
    if session_context_text:
        parts.append(session_context_text.lower())
    return " ".join(part for part in parts if part).strip()
