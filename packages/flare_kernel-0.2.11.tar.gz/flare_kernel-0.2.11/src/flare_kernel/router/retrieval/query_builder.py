"""Retrieval query construction helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.domain.domain_pack_loader import load_domain_pack, resolve_domain_pack_domain
from flare_kernel.router.retrieval.aliases import normalize_message_for_intent


def _normalize_entity_query_mode(req: KernelRequest) -> str:
    payload = req.payload if isinstance(req.payload, dict) else {}
    mode = payload.get("entity_query_mode")
    if not isinstance(mode, str) or not mode.strip():
        mode = req.entity_query_mode
    normalized = str(mode or "").strip().lower()
    if normalized in {"off", "prefer", "only"}:
        return normalized
    return "prefer"


def _resolve_request_entities(req: KernelRequest) -> list[dict[str, Any]]:
    payload = req.payload if isinstance(req.payload, dict) else {}
    raw_entities: list[Any] = []
    if isinstance(payload.get("entities"), list):
        raw_entities.extend(payload.get("entities") or [])
    if isinstance(req.entities, list):
        raw_entities.extend(req.entities)
    normalized_entities: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    for item in raw_entities:
        raw_text = ""
        raw_normalized = ""
        raw_aliases: list[str] = []
        if isinstance(item, str):
            raw_text = item
        elif isinstance(item, dict):
            raw_text = str(item.get("text") or item.get("value") or item.get("name") or "").strip()
            raw_normalized = str(item.get("normalized") or item.get("entity_normalized") or "").strip()
            alias_values = item.get("aliases")
            if isinstance(alias_values, list):
                raw_aliases.extend(str(alias).strip() for alias in alias_values if str(alias).strip())
            alias_single = str(item.get("alias") or "").strip()
            if alias_single:
                raw_aliases.append(alias_single)
        text = str(raw_text or "").strip()
        normalized = str(raw_normalized or text).strip().lower()
        if not text:
            continue
        dedup_key = normalized or text.lower()
        if dedup_key in seen_keys:
            continue
        seen_keys.add(dedup_key)
        aliases: list[str] = []
        seen_alias: set[str] = set()
        for candidate in [text, normalized, *raw_aliases]:
            alias_text = str(candidate or "").strip()
            if not alias_text:
                continue
            alias_key = alias_text.lower()
            if alias_key in seen_alias:
                continue
            seen_alias.add(alias_key)
            aliases.append(alias_text)
        normalized_entities.append(
            {
                "text": text,
                "normalized": normalized,
                "aliases": aliases,
            }
        )
    return normalized_entities


def build_retrieval_queries(
    req: KernelRequest,
    *,
    message: str,
    default_intent_aliases: dict[str, str],
    resolve_retrieval_field_queries_fn: Callable[[KernelRequest], list[tuple[str, str]]],
    instance_profile: dict[str, Any] | None = None,
    load_domain_pack_fn: Callable[..., Any] | None = None,
    normalize_message_for_intent_fn: Callable[..., str] | None = None,
) -> list[str]:
    base_message = str(message or "").strip()
    queries: list[str] = []
    entity_queries: list[str] = []
    domain_pack_loader = load_domain_pack_fn or load_domain_pack
    normalize_message_fn = normalize_message_for_intent_fn or normalize_message_for_intent
    entity_query_mode = _normalize_entity_query_mode(req)
    entities = _resolve_request_entities(req)
    domain_pack_obj = domain_pack_loader(
        instance_id=req.instance_id,
        domain_pack_version=req.domain_pack_version,
        domain=resolve_domain_pack_domain(payload=req.payload),
        payload=req.payload if isinstance(req.payload, dict) else {},
        instance_profile=instance_profile if isinstance(instance_profile, dict) else {},
        tenant_id=req.tenant_id,
    )
    domain_pack = domain_pack_obj.to_dict()
    search_mapping = domain_pack.get("search_mapping") if isinstance(domain_pack, dict) else {}
    field_mapping = search_mapping.get("field_mapping") if isinstance(search_mapping, dict) else {}
    if isinstance(field_mapping, dict):
        for field_key, field_value in resolve_retrieval_field_queries_fn(req):
            field_mapping_node = field_mapping.get(field_key)
            query_templates: list[str] = []
            if isinstance(field_mapping_node, dict):
                raw_templates = field_mapping_node.get("query_templates")
                if isinstance(raw_templates, list):
                    query_templates = [str(item).strip() for item in raw_templates if str(item).strip()]
            elif isinstance(field_mapping_node, list):
                query_templates = [str(item).strip() for item in field_mapping_node if str(item).strip()]
            if query_templates:
                for template in query_templates:
                    try:
                        candidate = template.format(
                            value=field_value,
                            field_key=field_key,
                            key=field_key,
                            label=field_key,
                        ).strip()
                    except Exception:
                        continue
                    if candidate and candidate not in queries:
                        queries.append(candidate)
            else:
                candidate = f"{field_key} {field_value}".strip()
                if candidate and candidate not in queries:
                    queries.append(candidate)
    if base_message:
        normalized_message = normalize_message_fn(
            req,
            message=base_message,
            default_intent_aliases=default_intent_aliases,
            instance_profile=instance_profile,
        )
        for candidate in (base_message, normalized_message):
            text = str(candidate or "").strip()
            if not text or text in queries:
                continue
            queries.append(text)
    if entity_query_mode != "off" and entities:
        for entity in entities:
            aliases = entity.get("aliases") if isinstance(entity.get("aliases"), list) else []
            for alias in aliases:
                candidate = str(alias or "").strip()
                if not candidate or candidate in entity_queries:
                    continue
                entity_queries.append(candidate)
    if entity_query_mode == "only" and entity_queries:
        return entity_queries
    for candidate in entity_queries:
        if candidate not in queries:
            queries.append(candidate)
    return queries
