"""Execution trace helpers for orchestration workflow."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.orchestration.trace.projection import (
    build_orchestration_execution_trace as build_orchestration_execution_trace_from_router,
)
from flare_kernel.router.orchestration.trace.steps import (
    build_agent_step_trace as build_agent_step_trace_from_router,
    build_llm_execution_trace as build_llm_execution_trace_from_router,
    build_retrieval_execution_trace as build_retrieval_execution_trace_from_router,
    build_skill_step_trace as build_skill_step_trace_from_router,
    resolve_skill_for_step as resolve_skill_for_step_from_router,
    resolve_step_for_event as resolve_step_for_event_from_router,
)


def build_orchestration_execution_trace(
    *,
    trace_id: str,
    session_id: str,
    runtime_snapshot: dict[str, Any],
    mode_switch_event: dict[str, Any],
) -> dict[str, Any]:
    return build_orchestration_execution_trace_from_router(
        trace_id=trace_id,
        session_id=session_id,
        runtime_snapshot=runtime_snapshot,
        mode_switch_event=mode_switch_event,
    )


def resolve_step_for_event(
    *,
    mode_key: str,
    event_type: str,
    steps_by_id: dict[str, dict[str, Any]],
) -> str:
    return resolve_step_for_event_from_router(
        mode_key=mode_key,
        event_type=event_type,
        steps_by_id=steps_by_id,
    )


def resolve_skill_for_step(
    *,
    step_id: str,
    skill_by_step: dict[str, dict[str, Any]],
) -> dict[str, Any] | None:
    return resolve_skill_for_step_from_router(
        step_id=step_id,
        skill_by_step=skill_by_step,
    )


def build_llm_execution_trace(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    status: str,
    provider: str,
    model: str,
    detail: str,
) -> dict[str, Any]:
    return build_llm_execution_trace_from_router(
        trace_id=trace_id,
        session_id=session_id,
        mode_key=mode_key,
        status=status,
        provider=provider,
        model=model,
        detail=detail,
    )


def build_retrieval_execution_trace(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    status: str,
    detail: str,
) -> dict[str, Any]:
    return build_retrieval_execution_trace_from_router(
        trace_id=trace_id,
        session_id=session_id,
        mode_key=mode_key,
        status=status,
        detail=detail,
    )


def build_agent_step_trace(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    step: dict[str, Any],
    status: str,
    detail: str,
) -> dict[str, Any]:
    return build_agent_step_trace_from_router(
        trace_id=trace_id,
        session_id=session_id,
        mode_key=mode_key,
        step=step,
        status=status,
        detail=detail,
    )


def build_skill_step_trace(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    skill_call: dict[str, Any],
    status: str,
    detail: str,
) -> dict[str, Any]:
    return build_skill_step_trace_from_router(
        trace_id=trace_id,
        session_id=session_id,
        mode_key=mode_key,
        skill_call=skill_call,
        status=status,
        detail=detail,
    )
