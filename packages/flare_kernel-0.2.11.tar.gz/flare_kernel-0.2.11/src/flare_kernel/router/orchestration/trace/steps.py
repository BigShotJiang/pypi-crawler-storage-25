"""Step mapping and trace record helpers for orchestration runtime."""

from __future__ import annotations

from typing import Any


def resolve_step_for_event(
    *,
    mode_key: str,
    event_type: str,
    steps_by_id: dict[str, dict[str, Any]],
) -> str:
    mapping = {
        "requirement_intake": {
            "field_progress": "requirement_collect",
            "next_actions": "requirement_collect",
            "requirement_draft": "knowledge_inject",
            "canvas_state": "knowledge_inject",
            "canvas_revision": "knowledge_inject",
        },
        "intelligent_sourcing": {
            "next_actions": "sourcing_match",
            "canvas_state": "sourcing_match",
            "sourcing_candidates": "sourcing_match",
            "risk_summary": "risk_summary",
            "shortlist_updated": "report_build",
            "evaluation_report_ready": "report_build",
        },
    }
    candidate = mapping.get(mode_key, {}).get(event_type, "")
    return candidate if candidate in steps_by_id else ""


def resolve_skill_for_step(
    *,
    step_id: str,
    skill_by_step: dict[str, dict[str, Any]],
) -> dict[str, Any] | None:
    return skill_by_step.get(step_id)


def build_llm_execution_trace(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    status: str,
    provider: str,
    model: str,
    detail: str,
) -> dict[str, Any]:
    return {
        "trace_id": trace_id,
        "session_id": session_id,
        "step_id": f"llm_completion:{mode_key}",
        "agent": "llm_provider",
        "stage": "generating",
        "label": f"LLM 生成 {provider}/{model}",
        "detail": detail,
        "reason": "",
        "status": status,
    }


def build_retrieval_execution_trace(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    status: str,
    detail: str,
) -> dict[str, Any]:
    return {
        "trace_id": trace_id,
        "session_id": session_id,
        "step_id": f"knowledge_search:{mode_key}",
        "agent": "knowledge_search_agent",
        "stage": "analysis",
        "label": "检索证据",
        "detail": detail,
        "reason": "",
        "status": status,
    }


def build_agent_step_trace(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    step: dict[str, Any],
    status: str,
    detail: str,
) -> dict[str, Any]:
    step_id = str(step.get("step_id") or "unknown_step")
    agent_id = str(step.get("agent_id") or "unknown_agent")
    role = str(step.get("role") or "unknown_role")
    stage = "analysis" if step_id == "intent_router" else "orchestration"
    return {
        "trace_id": trace_id,
        "session_id": session_id,
        "step_id": f"assistant_step:{mode_key}:{step_id}",
        "agent": agent_id,
        "stage": stage,
        "label": f"{step_id} ({role})",
        "detail": detail,
        "reason": "",
        "status": status,
    }


def build_skill_step_trace(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    skill_call: dict[str, Any],
    status: str,
    detail: str,
) -> dict[str, Any]:
    skill_id = str(skill_call.get("skill_id") or "unknown_skill")
    agent_id = str(skill_call.get("agent_id") or "unknown_agent")
    return {
        "trace_id": trace_id,
        "session_id": session_id,
        "step_id": f"skill:{mode_key}:{skill_id}",
        "agent": agent_id,
        "stage": "orchestration",
        "label": f"{skill_id}",
        "detail": detail,
        "reason": "",
        "status": status,
    }
