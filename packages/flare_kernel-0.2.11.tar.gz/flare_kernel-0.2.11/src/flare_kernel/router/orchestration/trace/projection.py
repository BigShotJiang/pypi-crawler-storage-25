"""Projection helpers for orchestration execution trace overview."""

from __future__ import annotations

from typing import Any


def build_orchestration_execution_trace(
    *,
    trace_id: str,
    session_id: str,
    runtime_snapshot: dict[str, Any],
    mode_switch_event: dict[str, Any],
) -> dict[str, Any]:
    mode_runtime = runtime_snapshot.get("mode_runtime") if isinstance(runtime_snapshot.get("mode_runtime"), dict) else {}
    agent_runtime = runtime_snapshot.get("agent_runtime") if isinstance(runtime_snapshot.get("agent_runtime"), dict) else {}
    skill_runtime = runtime_snapshot.get("skill_runtime") if isinstance(runtime_snapshot.get("skill_runtime"), dict) else {}
    mode_events = runtime_snapshot.get("mode_events") if isinstance(runtime_snapshot.get("mode_events"), list) else []

    mode_key = str(mode_runtime.get("mode_key") or runtime_snapshot.get("mode_key") or "unknown")
    mode_state = str(mode_runtime.get("mode_state") or runtime_snapshot.get("mode_state") or "unknown")
    mode_source = str(mode_switch_event.get("source") or "fallback")
    resolved_intent = str(mode_switch_event.get("intent") or "default")

    agent_steps = agent_runtime.get("agent_step") if isinstance(agent_runtime.get("agent_step"), list) else []
    skill_calls = skill_runtime.get("skill_call") if isinstance(skill_runtime.get("skill_call"), list) else []

    agent_lines = []
    for index, step in enumerate(agent_steps, start=1):
        if not isinstance(step, dict):
            continue
        step_id = str(step.get("step_id") or f"step_{index}")
        agent_id = str(step.get("agent_id") or "unknown_agent")
        role = str(step.get("role") or "unknown_role")
        status = str(step.get("status") or "planned")
        handoff = str(step.get("handoff_rule") or "").strip()
        suffix = f" | handoff={handoff}" if handoff else ""
        agent_lines.append(f"{index}. {step_id} -> {agent_id} ({role}) [{status}]{suffix}")

    skill_lines = []
    for index, skill in enumerate(skill_calls, start=1):
        if not isinstance(skill, dict):
            continue
        skill_id = str(skill.get("skill_id") or f"skill_{index}")
        agent_id = str(skill.get("agent_id") or "unknown_agent")
        status = str(skill.get("status") or "planned")
        reason = str(skill.get("reason") or "").strip()
        suffix = f" | reason={reason}" if reason else ""
        skill_lines.append(f"{index}. {skill_id} -> {agent_id} [{status}]{suffix}")

    mode_event_lines = []
    for index, mode_event in enumerate(mode_events, start=1):
        if not isinstance(mode_event, dict):
            continue
        event_type = str(mode_event.get("event_type") or f"event_{index}")
        step_id = str(mode_event.get("step_id") or "")
        label = f"{index}. {event_type}"
        if step_id and step_id != event_type:
            label = f"{label} ({step_id})"
        mode_event_lines.append(label)

    detail_parts = [
        f"流程判断: source={mode_source}, intent={resolved_intent}, mode={mode_key}/{mode_state}",
        "任务步骤:",
        *(agent_lines or ["1. (none)"]),
        "能力调用:",
        *(skill_lines or ["1. (none)"]),
        "执行事件:",
        *(mode_event_lines or ["1. (none)"]),
    ]
    detail_text = "\n".join(detail_parts)

    return {
        "trace_id": trace_id,
        "session_id": session_id,
        "step_id": f"process_blueprint:{mode_key}",
        "agent": "orchestrator",
        "stage": "analysis",
        "label": f"流程概览 {mode_key}",
        "detail": detail_text,
        "reason": str(mode_switch_event.get("summary") or ""),
        "status": "running",
    }
