"""Canonical analysis-entry decision policy.

DOC HELPER — PLN-04B analysis-entry SSOT.
This module owns the reusable decision object that tells downstream layers
whether analysis generation is hidden, available, or recommended. UI and
projection layers must consume this decision instead of re-scoring readiness.
"""

from __future__ import annotations

from typing import Any

_AVAILABLE_SCORE = 0.30
_RECOMMENDED_SCORE = 0.75


def _clamp_score(value: Any) -> float:
    try:
        return max(0.0, min(1.0, float(value or 0.0)))
    except (TypeError, ValueError):
        return 0.0


def _has_value(value: Any) -> bool:
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, dict):
        return any(_has_value(item) for item in value.values())
    if isinstance(value, list | tuple | set):
        return any(_has_value(item) for item in value)
    return value is not None


def _count_non_empty_fields(fields: dict[str, Any] | None) -> int:
    if not isinstance(fields, dict):
        return 0
    return sum(1 for value in fields.values() if _has_value(value))


def _coerce_count(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


def _entry_level_for_score(*, score: float, analysis_entry_eligible: bool) -> str:
    if analysis_entry_eligible or score >= _RECOMMENDED_SCORE:
        return "recommended"
    if score >= _AVAILABLE_SCORE:
        return "available"
    return "hidden"


def build_analysis_entry_decision(
    *,
    fields: dict[str, Any] | None,
    normalized_required_missing: list[str] | None,
    retrieval_hit_count: int,
    analysis_entry_eligible: bool,
    analyzability_score: float,
    analysis_entry_threshold: float,
) -> dict[str, Any]:
    """Return the single source of truth for analysis-entry availability."""
    field_count = _count_non_empty_fields(fields)
    retrieval_count = _coerce_count(retrieval_hit_count)
    missing = [
        str(item).strip()
        for item in (normalized_required_missing if isinstance(normalized_required_missing, list) else [])
        if str(item).strip()
    ]
    field_presence = min(field_count, 1)
    field_depth = min(field_count, 4) / 4
    retrieval_presence = min(retrieval_count, 1)
    retrieval_depth = min(retrieval_count, 4) / 4
    score = max(
        _clamp_score(analyzability_score),
        _clamp_score(
            0.30 * field_presence
            + 0.20 * field_depth
            + 0.25 * retrieval_presence
            + 0.10 * retrieval_depth
            + (0.35 if analysis_entry_eligible else 0.0)
        ),
    )
    entry_level = _entry_level_for_score(
        score=score,
        analysis_entry_eligible=bool(analysis_entry_eligible),
    )
    can_generate = entry_level in {"available", "recommended"}
    assumptions: list[str] = []
    if can_generate and missing:
        assumptions.append("未确认字段已按“假设/待验证点”处理，不视为已确认事实。")
    reason = "已有一定上下文，可生成初版分析；信息越完整结果越稳。"
    if entry_level == "hidden":
        reason = "当前上下文不足，暂不建议生成分析。"
    elif entry_level == "recommended":
        reason = "字段覆盖已达到分析入口条件，建议生成分析。"
    return {
        "can_generate": can_generate,
        "entry_level": entry_level,
        "score": round(score, 3),
        "threshold": _clamp_score(analysis_entry_threshold),
        "reasons": [reason],
        "blocking_fields": missing,
        "assumptions": assumptions,
        "source": "analysis_entry_decision",
    }


__all__ = ["build_analysis_entry_decision"]
