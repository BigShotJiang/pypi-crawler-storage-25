"""Status-stage action normalization helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.orchestration.status.action_readiness import (
    evaluate_action_readiness,
    is_action_visible,
)
from flare_kernel.router.orchestration.status.analysis_entry_decision import (
    build_analysis_entry_decision,
)


def _apply_readiness(action: dict[str, Any], readiness: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(readiness, dict):
        return action
    enriched = dict(action)
    for key in ("readiness_score", "readiness_level", "reason", "source"):
        value = readiness.get(key)
        if value is not None:
            enriched[key] = value
    return enriched


def _build_continue_collection_action(
    current_question: dict[str, Any] | None,
    readiness: dict[str, Any] | None,
) -> dict[str, Any]:
    target_field = str((current_question or {}).get("field_key") or "").strip()
    action = {
        "action_key": "continue_collection",
        "label": "可选梳理需求",
        "target_mode": "requirement_intake",
        "priority": 2,
        "status": "available",
        "optional": True,
    }
    if target_field:
        action["target_field"] = target_field
    return _apply_readiness(action, readiness)


def _build_confirm_plan_action(readiness: dict[str, Any] | None = None) -> dict[str, Any]:
    return _apply_readiness({
        "action_key": "confirm_plan",
        "label": "开始需求分析",
        "target_mode": "analysis_mode",
        "priority": 1,
        "status": "available",
        "command": "generate_analysis",
        "payload": {
            "target_mode": "analysis_mode",
            "action_key": "confirm_plan",
            "command": "generate_analysis",
        },
    }, readiness)


def _build_sourcing_action(readiness: dict[str, Any] | None = None) -> dict[str, Any]:
    return _apply_readiness({
        "action_key": "handoff_to_sourcing",
        "label": "进入智能寻源",
        "target_mode": "intelligent_sourcing",
        "priority": 3,
        "status": "available",
        "command": "handoff_to_sourcing",
        "payload": {
            "target_mode": "intelligent_sourcing",
            "action_key": "handoff_to_sourcing",
            "command": "handoff_to_sourcing",
        },
    }, readiness)


def _append_action_if_missing(actions: list[dict[str, Any]], action: dict[str, Any]) -> None:
    action_key = str(action.get("action_key") or "").strip()
    if not action_key:
        return
    if any(str(item.get("action_key") or "").strip() == action_key for item in actions):
        return
    actions.append(action)


def _build_optional_collection_actions(
    *,
    current_question: dict[str, Any] | None,
    existing_actions: list[dict[str, Any]],
    readiness_by_action: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    actions = [
        _build_continue_collection_action(
            current_question,
            readiness_by_action.get("continue_collection"),
        ),
    ]
    for item in existing_actions:
        if str(item.get("status") or "available").strip().lower() == "blocked":
            continue
        action_key = str(item.get("action_key") or "").strip()
        readiness = readiness_by_action.get(action_key)
        if isinstance(readiness, dict) and not is_action_visible(readiness):
            continue
        _append_action_if_missing(actions, _apply_readiness(item, readiness_by_action.get(action_key)))
    if is_action_visible(readiness_by_action.get("confirm_plan")):
        _append_action_if_missing(actions, _build_confirm_plan_action(readiness_by_action.get("confirm_plan")))
    if is_action_visible(readiness_by_action.get("handoff_to_sourcing")):
        _append_action_if_missing(actions, _build_sourcing_action(readiness_by_action.get("handoff_to_sourcing")))
    return actions


def normalize_status_stage_and_actions(
    *,
    current_stage: str,
    decision_payload: dict[str, Any],
    resolved_actions: list[dict[str, Any]],
    normalized_required_missing: list[str],
    current_question: dict[str, Any] | None,
    fields: dict[str, Any] | None = None,
    retrieval_hit_count: int = 0,
    analysis_entry_eligible: bool = False,
    analyzability_score: float = 0.0,
    analysis_entry_threshold: float = 0.8,
) -> tuple[str, dict[str, Any], list[dict[str, Any]]]:
    stage = str(current_stage or "").strip()
    payload = dict(decision_payload) if isinstance(decision_payload, dict) else {}
    actions = [dict(item) for item in resolved_actions if isinstance(item, dict)]
    should_offer_collection = bool(
        stage == "requirement_intake.collecting"
        and normalized_required_missing
        and isinstance(current_question, dict)
    )
    analysis_entry_decision = build_analysis_entry_decision(
        fields=fields,
        normalized_required_missing=normalized_required_missing,
        retrieval_hit_count=retrieval_hit_count,
        analysis_entry_eligible=analysis_entry_eligible,
        analyzability_score=analyzability_score,
        analysis_entry_threshold=analysis_entry_threshold,
    )
    # DOC HELPER — carry the canonical analysis-entry decision forward.
    # Later projections should read this payload field instead of deriving
    # analysis availability from stage names or frontend state.
    payload["analysis_entry_decision"] = analysis_entry_decision
    if should_offer_collection:
        readiness_by_action = evaluate_action_readiness(
            fields=fields,
            normalized_required_missing=normalized_required_missing,
            retrieval_hit_count=retrieval_hit_count,
            analysis_entry_eligible=analysis_entry_eligible,
            current_question=current_question,
            analyzability_score=analyzability_score,
            analysis_entry_threshold=analysis_entry_threshold,
            analysis_entry_decision=analysis_entry_decision,
        )
        payload["chooser_required"] = False
        payload["auxiliary_mode_optional"] = True
        actions = _build_optional_collection_actions(
            current_question=current_question,
            existing_actions=actions,
            readiness_by_action=readiness_by_action,
        )
    elif stage == "requirement_intake.ready_for_submit":
        has_confirm = any(str(item.get("action_key") or "").strip() == "confirm_plan" for item in actions)
        if not has_confirm:
            actions.append(_build_confirm_plan_action())
    entry_recommendation = payload.get("entry_recommendation")
    has_entry_action = any(str(item.get("action_key") or "").strip() == "activate_requirement_intake" for item in actions)
    if isinstance(entry_recommendation, dict) and not has_entry_action:
        actions.insert(
            0,
            {
                "action_key": str(entry_recommendation.get("action_key") or "activate_requirement_intake").strip(),
                "label": str(entry_recommendation.get("label") or "开启梳理模式").strip(),
                "target_mode": str(entry_recommendation.get("mode") or "requirement_intake").strip(),
                "priority": 0,
                "status": "available",
                "command": "activate_requirement_intake",
                "reason": str(entry_recommendation.get("reason") or "").strip(),
                "source": str(entry_recommendation.get("source") or "").strip(),
                "confidence": float(entry_recommendation.get("confidence") or 0.0),
            },
        )
    payload["next_actions"] = actions
    return stage, payload, actions


__all__ = ["normalize_status_stage_and_actions"]
