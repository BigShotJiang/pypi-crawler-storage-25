"""Follow-up and node-state projection helpers for orchestration status facade."""

from __future__ import annotations

from typing import Any


def unpack_followup_and_node_state(followup_and_checkpoint_state: dict[str, Any]) -> dict[str, Any]:
    """Normalize follow-up summary and node/checkpoint projection fields."""
    intake_followup_state = (
        followup_and_checkpoint_state.get("intake_followup_state")
        if isinstance(followup_and_checkpoint_state.get("intake_followup_state"), dict)
        else {}
    )
    next_action = followup_and_checkpoint_state.get("next_action")
    ready_for_submit = bool(followup_and_checkpoint_state.get("ready_for_submit"))
    decision_point_active = bool(followup_and_checkpoint_state.get("decision_point_active"))
    has_active_question = bool(followup_and_checkpoint_state.get("has_active_question"))
    active_collecting = bool(followup_and_checkpoint_state.get("active_collecting"))
    guided_session = (
        followup_and_checkpoint_state.get("guided_session")
        if isinstance(followup_and_checkpoint_state.get("guided_session"), dict)
        else {}
    )
    node_and_checkpoint_state = (
        followup_and_checkpoint_state.get("node_and_checkpoint_state")
        if isinstance(followup_and_checkpoint_state.get("node_and_checkpoint_state"), dict)
        else {}
    )
    checkpoint_state_value = str(node_and_checkpoint_state.get("checkpoint_state_value") or "").strip().lower()
    node_id = str(node_and_checkpoint_state.get("node_id") or "next_actions")
    node_state = str(node_and_checkpoint_state.get("node_state") or "completed")
    node_reason = str(node_and_checkpoint_state.get("node_reason") or "").strip()
    needs_user_choice = bool(node_and_checkpoint_state.get("needs_user_choice"))
    chooser_required = bool(node_and_checkpoint_state.get("chooser_required"))
    blocking_reason = str(node_and_checkpoint_state.get("blocking_reason") or "").strip()
    chooser = node_and_checkpoint_state.get("chooser") if isinstance(node_and_checkpoint_state.get("chooser"), dict) else None
    active_checkpoint = node_and_checkpoint_state.get("active_checkpoint") if isinstance(node_and_checkpoint_state.get("active_checkpoint"), dict) else {}

    return {
        "intake_followup_state": intake_followup_state,
        "next_action": next_action,
        "ready_for_submit": ready_for_submit,
        "decision_point_active": decision_point_active,
        "has_active_question": has_active_question,
        "active_collecting": active_collecting,
        "guided_session": guided_session,
        "checkpoint_state_value": checkpoint_state_value,
        "node_id": node_id,
        "node_state": node_state,
        "node_reason": node_reason,
        "needs_user_choice": needs_user_choice,
        "chooser_required": chooser_required,
        "blocking_reason": blocking_reason,
        "chooser": chooser,
        "active_checkpoint": active_checkpoint,
    }


__all__ = ["unpack_followup_and_node_state"]
