"""Public facade for orchestration status state resolution.

This module is the stable router entrypoint. It keeps the hook symbols in the
facade namespace for monkeypatch-based tests, while the sequencing logic lives
in ``orchestration_status_state_flow``.

The contract assumption is that callers patch the facade symbols, not the
internal flow module. That keeps the public surface narrow and the stage
boundaries explicit.
"""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.router.intake.status.core import (
    build_confirmed_updates,
    build_field_label_map,
    compute_domain_relevance,
    compute_procurement_relevance,
)
from flare_kernel.router.orchestration.status.context import (
    prepare_orchestration_input_context,
    unpack_orchestration_input_context,
)
from flare_kernel.router.orchestration.status.decision import (
    resolve_decision_and_stage,
)
from flare_kernel.router.orchestration.status.projection import (
    resolve_entry_message,
)
from flare_kernel.router.orchestration.status.result import (
    build_orchestration_status_state_payload,
)
from flare_kernel.router.orchestration.status.runtime_state import (
    resolve_followup_and_guided_state,
    resolve_node_and_checkpoint_state,
)
from flare_kernel.router.orchestration.status.state.flow import (
    resolve_orchestration_status_state_flow,
)


def resolve_orchestration_status_state(
    *,
    trace_id: str,
    command: str,
    resolved_intent: str,
    resolved_mode: str,
    runtime_snapshot: dict[str, Any],
    raw_message: str,
    retrieval_attempted: bool,
    retrieved_knowledge: list[dict[str, Any]],
    resolve_requirement_intake_entry_recommendation_fn: Callable[..., tuple[str, float, str, str]],
    resolve_session_intent_stage_fn: Callable[..., str],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
) -> dict[str, Any]:
    """Resolve orchestration status state without changing the public contract.

    The public wrapper intentionally performs no policy work. It only forwards
    the injected hooks and raw request material to the internal flow module so
    the orchestration pipeline stays testable and deterministic.
    """
    return resolve_orchestration_status_state_flow(
        trace_id=trace_id,
        command=command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        runtime_snapshot=runtime_snapshot,
        raw_message=raw_message,
        retrieval_attempted=retrieval_attempted,
        retrieved_knowledge=retrieved_knowledge,
        resolve_requirement_intake_entry_recommendation_fn=resolve_requirement_intake_entry_recommendation_fn,
        resolve_session_intent_stage_fn=resolve_session_intent_stage_fn,
        extract_user_message_fn=extract_user_message_fn,
        prepare_orchestration_input_context_fn=prepare_orchestration_input_context,
        unpack_orchestration_input_context_fn=unpack_orchestration_input_context,
        resolve_entry_message_fn=resolve_entry_message,
        resolve_decision_and_stage_fn=resolve_decision_and_stage,
        build_confirmed_updates_fn=build_confirmed_updates,
        build_field_label_map_fn=build_field_label_map,
        resolve_followup_and_guided_state_fn=resolve_followup_and_guided_state,
        resolve_node_and_checkpoint_state_fn=resolve_node_and_checkpoint_state,
        compute_domain_relevance_fn=compute_domain_relevance,
        build_orchestration_status_state_payload_fn=build_orchestration_status_state_payload,
    )
