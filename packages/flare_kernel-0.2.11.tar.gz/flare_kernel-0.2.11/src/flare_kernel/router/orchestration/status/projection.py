"""Projection helpers for orchestration status payloads.

DOC HELPER — ORC-02 stream-visible status contract.
This module assembles client-visible orchestration_status fields. Presentation
labels exposed here must be backend projections, not frontend guesses.
"""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.router.intent.compat_aliases import (
    project_compat_intent_type,
    project_domain_relevance,
    resolve_domain_relevance,
)


def _resolve_current_stage_label(current_stage: str) -> str:
    """Project generic stage labels for stream process display."""

    normalized = str(current_stage or "").strip()
    if normalized in {
        "requirement_intake.collecting",
        "requirement_intake_collecting",
        "intake_collecting",
    }:
        return "正在收集关键信息"
    if normalized == "requirement_analysis":
        return "正在分析需求"
    return "正在梳理需求"


def resolve_entry_message(
    *,
    runtime_payload: dict[str, Any],
    raw_message: str,
    next_actions_payload: dict[str, Any],
    field_progress_payload: dict[str, Any],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
) -> str:
    entry_message = extract_user_message_fn(runtime_payload)
    if entry_message:
        return entry_message
    entry_message = str(
        raw_message
        or next_actions_payload.get("message_excerpt")
        or field_progress_payload.get("message_excerpt")
        or ""
    ).strip()
    if entry_message:
        return entry_message
    return str(
        next_actions_payload.get("message_excerpt")
        or field_progress_payload.get("message_excerpt")
        or ""
    ).strip()


def build_orchestration_status_payload(
    *,
    trace_id: str,
    current_stage: str,
    resolved_intent: str,
    resolved_mode: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    confirmed_updates: list[dict[str, Any]],
    field_entities: dict[str, Any],
    open_fields: list[dict[str, Any]],
    search_actions: list[dict[str, Any]],
    workspace_updates: dict[str, Any],
    next_action: dict[str, Any] | None,
    resolved_actions: list[dict[str, Any]],
    decision_payload: dict[str, Any],
    active_collecting: bool,
    ready_for_submit: bool,
    required_coverage: float,
    total_coverage: float,
    analysis_entry_threshold: float,
    analysis_entry_eligible: bool,
    analyzability_score: float,
    decision_point_active: bool,
    has_active_question: bool,
    question_progress: dict[str, Any],
    guided_session: dict[str, Any],
    intake_followup_state: dict[str, Any],
    current_question: dict[str, Any] | None,
    normalized_required_fields: list[str],
    normalized_required_missing: list[str],
    session_intent_stage: str,
    conversation_intent_state: str,
    intake_understanding: dict[str, Any],
    active_checkpoint: dict[str, Any],
    checkpoint_state_value: str,
    chooser: dict[str, Any] | None,
    node_id: str,
    node_state: str,
    node_reason: str,
    needs_user_choice: bool,
    chooser_required: bool,
    blocking_reason: str,
    intent_escalation_policy: dict[str, Any] | None,
    intent_escalation_policy_source: str,
    coerce_intent_escalation_policy_fn: Callable[[Any], dict[str, Any]],
    analysis_route: dict[str, Any] | None = None,
    domain_relevance: bool | None = None,
    procurement_relevance: bool | None = None,
) -> dict[str, Any]:
    decision_basis = decision_payload.get("decision_basis") if isinstance(decision_payload.get("decision_basis"), list) else []
    resolved_domain_relevance = resolve_domain_relevance(
        {
            "domain_relevance": domain_relevance,
            "procurement_relevance": procurement_relevance,
        }
    )
    intent_type_domain = "domain_requirement_intake" if resolved_domain_relevance else "qa_only"
    return {
        "trace_id": trace_id,
        "current_stage": current_stage,
        "current_stage_label": _resolve_current_stage_label(current_stage),
        "detected_intent": {
            "intent": resolved_intent,
            "mode": resolved_mode,
            "source": intent_source,
            "confidence": float(intent_confidence or 0.0),
            "reason": intent_reason,
        },
        "confirmed_updates": confirmed_updates,
        "field_entities": field_entities,
        "open_fields": open_fields,
        "search_actions": search_actions,
        "workspace_updates": workspace_updates,
        "next_action": next_action,
        "next_actions": resolved_actions,
        "entry_recommendation": decision_payload.get("entry_recommendation")
        if isinstance(decision_payload.get("entry_recommendation"), dict)
        else None,
        "active_collecting": active_collecting,
        "ready_for_submit": ready_for_submit,
        "required_coverage": required_coverage,
        "total_coverage": total_coverage,
        "analysis_entry_threshold": analysis_entry_threshold,
        "analysis_entry_eligible": analysis_entry_eligible,
        "analyzability_score": analyzability_score,
        "decision_point_active": decision_point_active,
        "has_active_question": has_active_question,
        "question_progress": question_progress,
        "guided_session": guided_session,
        "intake_session_id": intake_followup_state.get("intake_session_id", ""),
        "intake_session_state": intake_followup_state.get("intake_session_state", "idle"),
        "intake_session_completed": bool(intake_followup_state.get("intake_session_completed")),
        "current_question": current_question if isinstance(current_question, dict) else None,
        "required_fields": normalized_required_fields,
        "required_missing": normalized_required_missing,
        "active_work_item": intake_followup_state.get("active_work_item"),
        "active_question_id": intake_followup_state.get("active_question_id"),
        "active_field_key": intake_followup_state.get("active_field_key"),
        "asked_required_fields": intake_followup_state.get("asked_required_fields", []),
        "remaining_required_fields": intake_followup_state.get("remaining_required_fields", []),
        "followup_status": intake_followup_state.get("followup_status", "idle"),
        "clarification_round": intake_followup_state.get("clarification_round", 0),
        "exit_intake_allowed": bool(intake_followup_state.get("exit_intake_allowed")),
        "analysis_ready": bool(intake_followup_state.get("analysis_ready")),
        "session_intent_stage": session_intent_stage,
        "conversation_intent_state": conversation_intent_state,
        **project_compat_intent_type(intent_type_domain),
        **project_domain_relevance(resolved_domain_relevance),
        "escalation_target": "qa_only",
        "intake_candidate": False,
        "clarification_recommended": False,
        "draft_seeded": bool(intake_followup_state.get("intake_session_id")),
        "missing_key_fields": normalized_required_missing,
        "recommended_next_step": "continue_qa",
        "next_question": intake_followup_state.get("next_question"),
        "intake_understanding": intake_understanding,
        "checkpoint": active_checkpoint,
        "checkpoint_waiting_user": bool(
            active_checkpoint.get("waiting_user") is True
            or checkpoint_state_value == "waiting_user"
        ),
        "pending_merge": bool(intake_followup_state.get("pending_merge")),
        "unresolved_points": intake_followup_state.get("unresolved_points", []),
        "intake_followup": intake_followup_state,
        "chooser": chooser,
        "node_id": node_id,
        "node_state": node_state,
        "node_reason": node_reason,
        "needs_user_choice": needs_user_choice,
        "node": {
            "id": node_id,
            "state": node_state,
            "reason": node_reason,
            "needs_user_choice": needs_user_choice,
        },
        "stage_transition": decision_payload.get("stage_transition") if isinstance(decision_payload.get("stage_transition"), dict) else {},
        "decision_basis": decision_basis,
        "blocking": {
            "is_blocked": bool(current_stage.endswith(".blocked")),
            "reason": blocking_reason,
            "chooser_required": chooser_required,
        },
        "degrade_reason": decision_payload.get("degrade_reason") if isinstance(decision_payload.get("degrade_reason"), list) else [],
        "content_policy": {
            "has_llm_content": False,
            "rendered_as_system_notice": False,
        },
        "analysis_route": analysis_route if isinstance(analysis_route, dict) else {},
        "intent_escalation_policy": coerce_intent_escalation_policy_fn(intent_escalation_policy or {}),
        "intent_escalation_policy_source": str(intent_escalation_policy_source or "default"),
    }
