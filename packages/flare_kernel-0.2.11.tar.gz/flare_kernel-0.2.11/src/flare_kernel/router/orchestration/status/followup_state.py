"""Follow-up and guided-session state resolution helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.status.core import (
    build_guided_session_status,
    build_intake_followup_state,
    pick_next_action,
    resolve_guided_session_flags,
)


def resolve_followup_and_guided_state(
    *,
    trace_id: str,
    intake_session_id: str,
    resolved_mode: str,
    current_stage: str,
    current_question: dict[str, Any] | None,
    normalized_required_fields: list[str],
    normalized_required_missing: list[str],
    fields: dict[str, Any],
    resolved_actions: list[dict[str, Any]],
    command: str,
    confirmed_updates: list[dict[str, Any]],
    field_label_map: dict[str, str],
) -> dict[str, Any]:
    filtered_actions = [item for item in resolved_actions if isinstance(item, dict)]
    intake_followup_state = build_intake_followup_state(
        trace_id=trace_id,
        intake_session_id=intake_session_id,
        resolved_mode=resolved_mode,
        current_stage=current_stage,
        current_question=current_question if isinstance(current_question, dict) else None,
        required_fields=normalized_required_fields,
        required_missing=normalized_required_missing,
        fields=fields,
        next_actions=filtered_actions,
        command=command,
        has_analysis_content=False,
    )
    next_action = pick_next_action({"actions": filtered_actions})
    guided_flags = resolve_guided_session_flags(
        current_stage=current_stage,
        required_missing=normalized_required_missing,
        current_question=current_question if isinstance(current_question, dict) else None,
        command=command,
    )
    ready_for_submit = bool(guided_flags.get("ready_for_submit"))
    decision_point_active = bool(guided_flags.get("decision_point_active"))
    has_active_question = bool(guided_flags.get("has_active_question"))
    active_collecting = bool(guided_flags.get("active_collecting"))
    guided_session = build_guided_session_status(
        resolved_mode=resolved_mode,
        current_stage=current_stage,
        command=command,
        current_question=current_question if isinstance(current_question, dict) else None,
        required_fields=normalized_required_fields,
        required_missing=normalized_required_missing,
        confirmed_updates=confirmed_updates,
        next_actions=filtered_actions,
        active_collecting=active_collecting,
        ready_for_submit=ready_for_submit,
        decision_point_active=decision_point_active,
        field_label_map=field_label_map,
    )
    return {
        "intake_followup_state": intake_followup_state,
        "next_action": next_action,
        "ready_for_submit": ready_for_submit,
        "decision_point_active": decision_point_active,
        "has_active_question": has_active_question,
        "active_collecting": active_collecting,
        "guided_session": guided_session,
    }
