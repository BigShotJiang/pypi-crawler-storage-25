"""Input context preparation for orchestration status builder.

DOC HELPER — ORC-02 status context wiring.
This is the handoff point where domain field definitions are converted into
label maps for stream-visible orchestration status payloads.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.entry_policy import (
    resolve_intake_strategy_settings,
)
from flare_kernel.router.intake.authority.core import (
    build_intake_session_id,
    normalize_intake_session_id,
)
from flare_kernel.router.intake.inputs import (
    extract_orchestration_status_inputs,
)
from flare_kernel.router.intake.readiness import (
    resolve_intake_readiness_metrics,
)
from flare_kernel.router.intake.status.core import (
    build_field_label_map,
    build_open_fields,
    build_status_chooser,
)
from flare_kernel.router.orchestration.status.context_helpers import (
    normalize_orchestration_input_context,
    resolve_input_payload_nodes,
    resolve_intake_session_and_missing_fields,
    resolve_payload_actions,
)


def prepare_orchestration_input_context(
    *,
    trace_id: str,
    resolved_mode: str,
    runtime_snapshot: dict[str, Any],
    retrieval_attempted: bool,
    retrieved_knowledge_count: int,
) -> dict[str, Any]:
    intake_inputs = extract_orchestration_status_inputs(runtime_snapshot)
    input_nodes = resolve_input_payload_nodes(intake_inputs)
    next_actions_payload = input_nodes["next_actions_payload"]
    field_progress_payload = input_nodes["field_progress_payload"]
    runtime_payload = input_nodes["runtime_payload"]
    intake_checkpoint = input_nodes["intake_checkpoint"]
    checkpoint_payload = input_nodes["checkpoint_payload"]
    question_progress = input_nodes["question_progress"]
    fields = input_nodes["fields"]
    field_entities = input_nodes["field_entities"]
    intake_understanding = input_nodes["intake_understanding"]
    analyzability_score_raw = input_nodes["analyzability_score_raw"]
    total_coverage_raw = input_nodes["total_coverage_raw"]
    required_coverage_raw = input_nodes["required_coverage_raw"]
    analysis_entry_threshold_raw = input_nodes["analysis_entry_threshold_raw"]
    analysis_entry_eligible_raw = input_nodes["analysis_entry_eligible_raw"]

    session_scope = resolve_intake_session_and_missing_fields(
        trace_id=trace_id,
        resolved_mode=resolved_mode,
        runtime_snapshot=runtime_snapshot,
        next_actions_payload=next_actions_payload,
        field_progress_payload=field_progress_payload,
        current_question=input_nodes["current_question"],
        fields=fields,
        required_fields=input_nodes["required_fields"],
        required_missing=input_nodes["required_missing"],
        normalize_intake_session_id_fn=normalize_intake_session_id,
        build_intake_session_id_fn=build_intake_session_id,
    )
    intake_session_id = session_scope["intake_session_id"]
    normalized_required_fields = session_scope["normalized_required_fields"]
    normalized_required_missing = session_scope["normalized_required_missing"]
    current_question = session_scope["current_question"]
    intake_strategy = resolve_intake_strategy_settings(
        runtime_payload=runtime_payload if isinstance(runtime_payload, dict) else {},
        runtime_snapshot=runtime_snapshot if isinstance(runtime_snapshot, dict) else {},
    )
    readiness_metrics = resolve_intake_readiness_metrics(
        total_coverage_raw=total_coverage_raw,
        required_coverage_raw=required_coverage_raw,
        analysis_entry_threshold_raw=analysis_entry_threshold_raw,
        analyzability_score_raw=analyzability_score_raw,
        analysis_entry_eligible_raw=analysis_entry_eligible_raw,
        required_fields=normalized_required_fields,
        required_missing=normalized_required_missing,
        question_progress=question_progress if isinstance(question_progress, dict) else {},
        intake_strategy=intake_strategy,
    )
    required_coverage = float(readiness_metrics.get("required_coverage") or 0.0)
    total_coverage = float(readiness_metrics.get("total_coverage") or 0.0)
    analysis_entry_threshold = float(readiness_metrics.get("analysis_entry_threshold") or 0.8)
    analyzability_score = float(readiness_metrics.get("analyzability_score") or 0.0)
    analysis_entry_eligible = bool(readiness_metrics.get("analysis_entry_eligible"))
    question_budget_reached = bool(readiness_metrics.get("question_budget_reached"))
    if question_budget_reached:
        current_question = None
        normalized_required_missing = []
    # DOC HELPER — keep field label projection backend-owned for stream UI.
    field_label_map = build_field_label_map(field_progress_payload.get("field_definitions"))
    open_fields = build_open_fields(
        normalized_required_missing,
        current_question if isinstance(current_question, dict) else None,
        fields=fields,
        intake_strategy=intake_strategy,
        field_label_map=field_label_map,
    )
    chooser = build_status_chooser(
        current_question=current_question if isinstance(current_question, dict) else None,
        next_actions_payload=next_actions_payload if isinstance(next_actions_payload, dict) else {},
        open_fields=open_fields,
        retrieval_attempted=retrieval_attempted,
        retrieval_hits=int(retrieved_knowledge_count),
    )
    mode_state = str(runtime_snapshot.get("mode_state") or "").strip()
    payload_actions = resolve_payload_actions(
        next_actions_payload=next_actions_payload if isinstance(next_actions_payload, dict) else {},
        checkpoint_payload=checkpoint_payload if isinstance(checkpoint_payload, dict) else {},
    )

    return {
        "next_actions_payload": next_actions_payload,
        "field_progress_payload": field_progress_payload,
        "runtime_payload": runtime_payload,
        "intake_checkpoint": intake_checkpoint,
        "checkpoint_payload": checkpoint_payload,
        "current_question": current_question if isinstance(current_question, dict) else None,
        "question_progress": question_progress,
        "fields": fields,
        "field_entities": field_entities,
        "intake_understanding": intake_understanding,
        "intake_session_id": intake_session_id,
        "normalized_required_fields": normalized_required_fields,
        "normalized_required_missing": normalized_required_missing,
        "required_coverage": required_coverage,
        "total_coverage": total_coverage,
        "analysis_entry_threshold": analysis_entry_threshold,
        "analyzability_score": analyzability_score,
        "analysis_entry_eligible": analysis_entry_eligible,
        "question_budget_reached": question_budget_reached,
        "intake_strategy": intake_strategy,
        "open_fields": open_fields,
        "chooser": chooser if isinstance(chooser, dict) else {},
        "mode_state": mode_state,
        "payload_actions": payload_actions,
    }


def unpack_orchestration_input_context(context: dict[str, Any]) -> dict[str, Any]:
    """Normalize context payload into stable typed fields for builders."""
    return normalize_orchestration_input_context(context)
