"""Orchestration status builder extracted from kernel router."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.router.intake.status.core import (
    build_search_actions,
    build_workspace_updates,
)
from flare_kernel.router.intent.compat_aliases import (
    resolve_domain_relevance,
)
from flare_kernel.router.orchestration.status.projection import (
    build_orchestration_status_payload,
)
from flare_kernel.router.orchestration.status.core import (
    resolve_orchestration_status_state,
)


def build_orchestration_status(
    *,
    trace_id: str,
    command: str = "send_message",
    resolved_intent: str,
    resolved_mode: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    runtime_snapshot: dict[str, Any],
    raw_message: str = "",
    retrieval_attempted: bool,
    retrieval_queries: list[str],
    retrieved_knowledge: list[dict[str, Any]],
    resolve_requirement_intake_entry_recommendation_fn: Callable[..., tuple[str, float, str, str]],
    resolve_session_intent_stage_fn: Callable[..., str],
    coerce_intent_escalation_policy_fn: Callable[[Any], dict[str, Any]],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    intent_escalation_policy: dict[str, Any] | None = None,
    intent_escalation_policy_source: str = "default",
    analysis_route: dict[str, Any] | None = None,
) -> dict[str, Any]:
    state = resolve_orchestration_status_state(
        trace_id=trace_id,
        command=command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        runtime_snapshot=runtime_snapshot,
        raw_message=raw_message,
        retrieval_attempted=retrieval_attempted,
        retrieved_knowledge=retrieved_knowledge,
        resolve_requirement_intake_entry_recommendation_fn=resolve_requirement_intake_entry_recommendation_fn,
        resolve_session_intent_stage_fn=resolve_session_intent_stage_fn,
        extract_user_message_fn=extract_user_message_fn,
    )

    search_actions = build_search_actions(
        retrieval_attempted=retrieval_attempted,
        retrieval_queries=retrieval_queries,
        retrieved_knowledge=retrieved_knowledge,
    )
    workspace_updates = build_workspace_updates(
        retrieval_attempted=retrieval_attempted,
        retrieved_knowledge_count=int(state.get("search_retrieval_hit_count") or 0),
        confirmed_updates=state.get("confirmed_updates") if isinstance(state.get("confirmed_updates"), list) else [],
        open_fields=state.get("open_fields") if isinstance(state.get("open_fields"), list) else [],
    )

    return build_orchestration_status_payload(
        trace_id=trace_id,
        current_stage=str(state.get("current_stage") or ""),
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        intent_source=intent_source,
        intent_confidence=float(intent_confidence or 0.0),
        intent_reason=intent_reason,
        confirmed_updates=state.get("confirmed_updates") if isinstance(state.get("confirmed_updates"), list) else [],
        field_entities=state.get("field_entities") if isinstance(state.get("field_entities"), dict) else {},
        open_fields=state.get("open_fields") if isinstance(state.get("open_fields"), list) else [],
        search_actions=search_actions,
        workspace_updates=workspace_updates,
        next_action=state.get("next_action"),
        resolved_actions=state.get("resolved_actions") if isinstance(state.get("resolved_actions"), list) else [],
        decision_payload=state.get("decision_payload") if isinstance(state.get("decision_payload"), dict) else {},
        active_collecting=bool(state.get("active_collecting")),
        ready_for_submit=bool(state.get("ready_for_submit")),
        required_coverage=float(state.get("required_coverage") or 0.0),
        total_coverage=float(state.get("total_coverage") or 0.0),
        analysis_entry_threshold=float(state.get("analysis_entry_threshold") or 0.8),
        analysis_entry_eligible=bool(state.get("analysis_entry_eligible")),
        analyzability_score=float(state.get("analyzability_score") or 0.0),
        decision_point_active=bool(state.get("decision_point_active")),
        has_active_question=bool(state.get("has_active_question")),
        question_progress=state.get("question_progress") if isinstance(state.get("question_progress"), dict) else {},
        guided_session=state.get("guided_session") if isinstance(state.get("guided_session"), dict) else {},
        intake_followup_state=state.get("intake_followup_state") if isinstance(state.get("intake_followup_state"), dict) else {},
        current_question=state.get("current_question") if isinstance(state.get("current_question"), dict) else None,
        normalized_required_fields=state.get("normalized_required_fields") if isinstance(state.get("normalized_required_fields"), list) else [],
        normalized_required_missing=state.get("normalized_required_missing") if isinstance(state.get("normalized_required_missing"), list) else [],
        session_intent_stage=str(state.get("session_intent_stage") or ""),
        conversation_intent_state=str(state.get("conversation_intent_state") or ""),
        domain_relevance=resolve_domain_relevance(state),
        intake_understanding=state.get("intake_understanding") if isinstance(state.get("intake_understanding"), dict) else {},
        active_checkpoint=state.get("active_checkpoint") if isinstance(state.get("active_checkpoint"), dict) else {},
        checkpoint_state_value=str(state.get("checkpoint_state_value") or "").strip().lower(),
        chooser=state.get("chooser") if isinstance(state.get("chooser"), dict) else None,
        node_id=str(state.get("node_id") or "next_actions"),
        node_state=str(state.get("node_state") or "completed"),
        node_reason=str(state.get("node_reason") or "").strip(),
        needs_user_choice=bool(state.get("needs_user_choice")),
        chooser_required=bool(state.get("chooser_required")),
        blocking_reason=str(state.get("blocking_reason") or "").strip(),
        intent_escalation_policy=intent_escalation_policy if isinstance(intent_escalation_policy, dict) else {},
        intent_escalation_policy_source=str(intent_escalation_policy_source or "default"),
        coerce_intent_escalation_policy_fn=coerce_intent_escalation_policy_fn,
        analysis_route=analysis_route if isinstance(analysis_route, dict) else {},
    )
