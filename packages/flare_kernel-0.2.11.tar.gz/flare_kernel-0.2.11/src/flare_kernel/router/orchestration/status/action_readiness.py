"""Action readiness scoring for orchestration status suggestions."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.orchestration.status.analysis_entry_decision import (
    build_analysis_entry_decision,
)

_AVAILABLE_SCORE = 0.30
_RECOMMENDED_SCORE = 0.75


def _clamp_score(value: float) -> float:
    return max(0.0, min(1.0, value))


def _has_value(value: Any) -> bool:
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, dict):
        return any(_has_value(item) for item in value.values())
    if isinstance(value, list | tuple | set):
        return any(_has_value(item) for item in value)
    return value is not None


def _count_non_empty_fields(fields: dict[str, Any] | None) -> int:
    if not isinstance(fields, dict):
        return 0
    return sum(1 for value in fields.values() if _has_value(value))


def _coerce_count(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


def _level_for_score(score: float) -> str:
    if score >= _RECOMMENDED_SCORE:
        return "recommended"
    if score >= _AVAILABLE_SCORE:
        return "available"
    return "hidden"


def _build_item(
    *,
    action_key: str,
    score: float,
    reason: str,
    readiness_level: str | None = None,
    source: str = "action_readiness",
) -> dict[str, Any]:
    normalized_score = round(_clamp_score(score), 3)
    return {
        "action_key": action_key,
        "readiness_score": normalized_score,
        "readiness_level": readiness_level or _level_for_score(normalized_score),
        "reason": reason,
        "source": source,
    }


def evaluate_action_readiness(
    *,
    fields: dict[str, Any] | None,
    normalized_required_missing: list[str],
    retrieval_hit_count: int,
    analysis_entry_eligible: bool,
    current_question: dict[str, Any] | None,
    analyzability_score: float = 0.0,
    analysis_entry_threshold: float = 0.8,
    analysis_entry_decision: dict[str, Any] | None = None,
) -> dict[str, dict[str, Any]]:
    """Return score metadata for optional next actions.

    The policy consumes generic context signals only. It does not inspect domain
    vocabulary, field names, transport state, or provider payloads.
    """

    field_count = _count_non_empty_fields(fields)
    missing_count = len(normalized_required_missing) if isinstance(normalized_required_missing, list) else 0
    retrieval_count = _coerce_count(retrieval_hit_count)
    field_presence = min(field_count, 1)
    field_depth = min(field_count, 4) / 4
    missing_signal = min(missing_count, 4) / 4
    retrieval_presence = min(retrieval_count, 1)
    retrieval_depth = min(retrieval_count, 4) / 4
    question_signal = 1.0 if isinstance(current_question, dict) and current_question else 0.0
    entry_decision = (
        analysis_entry_decision
        if isinstance(analysis_entry_decision, dict)
        else build_analysis_entry_decision(
            fields=fields,
            normalized_required_missing=normalized_required_missing,
            retrieval_hit_count=retrieval_count,
            analysis_entry_eligible=analysis_entry_eligible,
            analyzability_score=analyzability_score,
            analysis_entry_threshold=analysis_entry_threshold,
        )
    )
    entry_reasons = (
        entry_decision.get("reasons")
        if isinstance(entry_decision.get("reasons"), list)
        else []
    )

    continue_score = 0.68 + 0.20 * question_signal + 0.12 * missing_signal
    sourcing_score = (
        0.35 * field_presence
        + 0.20 * field_depth
        + 0.35 * retrieval_presence
        + 0.10 * retrieval_depth
    )

    return {
        "continue_collection": _build_item(
            action_key="continue_collection",
            score=continue_score,
            reason="当前仍有关键问题待确认，建议先梳理需求。",
        ),
        # DOC HELPER — confirm_plan readiness delegates to analysis_entry_decision.
        # This prevents a separate action-level formula from disagreeing with
        # the canonical analysis-entry gate.
        "confirm_plan": _build_item(
            action_key="confirm_plan",
            score=float(entry_decision.get("score") or 0.0),
            reason=str((entry_reasons or [""])[0] or ""),
            readiness_level=str(entry_decision.get("entry_level") or "hidden"),
            source=str(entry_decision.get("source") or "analysis_entry_decision"),
        ),
        "handoff_to_sourcing": _build_item(
            action_key="handoff_to_sourcing",
            score=sourcing_score,
            reason="已有一定上下文，可进入智能寻源；信息越完整匹配越准。",
        ),
    }


def is_action_visible(readiness: dict[str, Any] | None) -> bool:
    if not isinstance(readiness, dict):
        return False
    return str(readiness.get("readiness_level") or "").strip() != "hidden"


__all__ = ["evaluate_action_readiness", "is_action_visible"]
