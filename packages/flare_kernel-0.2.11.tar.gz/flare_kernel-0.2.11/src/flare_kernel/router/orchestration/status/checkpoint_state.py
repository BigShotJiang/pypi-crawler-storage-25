"""Checkpoint and node-state projection helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.router.intake.node_state import (
    resolve_intake_node_state,
)
from flare_kernel.router.intake.status.core import (
    build_active_checkpoint,
    build_fallback_active_checkpoint,
    build_workflow_checkpoint_projection,
)


def resolve_node_and_checkpoint_state(
    *,
    intake_checkpoint: dict[str, Any],
    current_stage: str,
    current_question: dict[str, Any] | None,
    open_fields: list[dict[str, Any]],
    chooser: dict[str, Any] | None,
    decision_point_active: bool,
    decision_payload: dict[str, Any],
    intake_session_id: str,
    runtime_payload: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    resolved_mode: str,
    active_collecting: bool,
    ready_for_submit: bool,
    confirmed_updates: list[dict[str, Any]],
    normalized_required_missing: list[str],
    question_progress: dict[str, Any],
) -> dict[str, Any]:
    checkpoint_state_value = str(intake_checkpoint.get("checkpoint_state") or "").strip().lower()
    decision_basis = decision_payload.get("decision_basis") if isinstance(decision_payload.get("decision_basis"), list) else []
    resolved_node_state = resolve_intake_node_state(
        current_stage=current_stage,
        current_question=current_question if isinstance(current_question, dict) else None,
        open_fields=open_fields,
        chooser=chooser if isinstance(chooser, dict) else None,
        decision_point_active=decision_point_active,
        decision_basis=[item for item in decision_basis if isinstance(item, dict)],
        blocking_reason=str(decision_payload.get("blocking_reason") or "").strip(),
        checkpoint_state_value=checkpoint_state_value,
    )
    node_id = str(resolved_node_state.get("node_id") or "next_actions")
    node_state = str(resolved_node_state.get("node_state") or "completed")
    node_reason = str(resolved_node_state.get("node_reason") or "").strip()
    needs_user_choice = bool(resolved_node_state.get("needs_user_choice"))
    chooser_required = bool(resolved_node_state.get("chooser_required"))
    blocking_reason = str(resolved_node_state.get("blocking_reason") or "").strip()
    resolved_chooser = resolved_node_state.get("chooser") if isinstance(resolved_node_state.get("chooser"), dict) else None
    if decision_payload.get("auxiliary_mode_optional") is True:
        needs_user_choice = False
        chooser_required = False
        blocking_reason = ""
    active_checkpoint = build_active_checkpoint(intake_checkpoint)
    if not active_checkpoint:
        active_checkpoint = build_fallback_active_checkpoint(
            intake_session_id=intake_session_id,
            current_question=current_question if isinstance(current_question, dict) else None,
            ready_for_submit=ready_for_submit,
            decision_point_active=decision_point_active,
            current_stage=current_stage,
            updated_at=str(runtime_payload.get("updated_at") or "").strip(),
        )
    workflow_checkpoint = build_workflow_checkpoint_projection(
        intake_session_id=intake_session_id,
        session_id=str(runtime_snapshot.get("session_id") or runtime_payload.get("session_id") or "").strip(),
        mode=resolved_mode,
        current_stage=current_stage,
        active_collecting=active_collecting,
        ready_for_submit=ready_for_submit,
        decision_point_active=decision_point_active,
        current_question=current_question if isinstance(current_question, dict) else None,
        confirmed_updates=confirmed_updates,
        required_missing=normalized_required_missing,
        blocking_reason=blocking_reason,
        checkpoint_base=active_checkpoint,
        question_progress=question_progress if isinstance(question_progress, dict) else {},
        updated_at=str(active_checkpoint.get("updated_at") or runtime_payload.get("updated_at") or "").strip(),
    )
    if workflow_checkpoint:
        active_checkpoint = workflow_checkpoint
    return {
        "checkpoint_state_value": checkpoint_state_value,
        "node_id": node_id,
        "node_state": node_state,
        "node_reason": node_reason,
        "needs_user_choice": needs_user_choice,
        "chooser_required": chooser_required,
        "blocking_reason": blocking_reason,
        "chooser": resolved_chooser,
        "active_checkpoint": active_checkpoint,
    }
