"""Decision resolution helpers for orchestration status state.

This module keeps the main facade from carrying the large decision-and-stage
call site while preserving the same inputs and return shape.
"""

from __future__ import annotations

from typing import Any, Callable


def build_orchestration_status_state_decision_context(
    *,
    command: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_state: dict[str, Any],
    normalized_required_missing: list[str],
    payload_actions: list[dict[str, Any]],
    current_question: dict[str, Any] | None,
    retrieval_attempted: bool,
    retrieval_hit_count: int,
    chooser: dict[str, Any],
    open_fields: list[dict[str, Any]],
    runtime_snapshot: dict[str, Any],
    entry_mode: str,
    entry_confidence: float,
    entry_reason: str,
    entry_source: str,
    resolve_decision_and_stage_fn: Callable[..., tuple[dict[str, Any], str]],
) -> dict[str, Any]:
    """Return the decision payload and current stage for the facade."""
    decision_payload, current_stage = resolve_decision_and_stage_fn(
        command=command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_state=mode_state,
        normalized_required_missing=normalized_required_missing,
        payload_actions=payload_actions,
        current_question=current_question,
        retrieval_attempted=retrieval_attempted,
        retrieval_hit_count=retrieval_hit_count,
        chooser=chooser,
        open_fields=open_fields,
        runtime_snapshot=runtime_snapshot,
        entry_mode=entry_mode,
        entry_confidence=entry_confidence,
        entry_reason=entry_reason,
        entry_source=entry_source,
    )
    return {
        "decision_payload": decision_payload,
        "current_stage": current_stage,
    }
