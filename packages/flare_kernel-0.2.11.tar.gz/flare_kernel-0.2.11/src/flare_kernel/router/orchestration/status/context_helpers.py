"""Helper utilities for orchestration-status input context assembly."""

from __future__ import annotations

from typing import Any, Callable


def resolve_input_payload_nodes(intake_inputs: dict[str, Any]) -> dict[str, Any]:
    next_actions_payload = (
        intake_inputs.get("next_actions_payload")
        if isinstance(intake_inputs.get("next_actions_payload"), dict)
        else {}
    )
    field_progress_payload = (
        intake_inputs.get("field_progress_payload")
        if isinstance(intake_inputs.get("field_progress_payload"), dict)
        else {}
    )
    runtime_payload = (
        intake_inputs.get("runtime_payload")
        if isinstance(intake_inputs.get("runtime_payload"), dict)
        else {}
    )
    intake_checkpoint = (
        intake_inputs.get("intake_checkpoint")
        if isinstance(intake_inputs.get("intake_checkpoint"), dict)
        else {}
    )
    checkpoint_payload = (
        intake_inputs.get("checkpoint_payload")
        if isinstance(intake_inputs.get("checkpoint_payload"), dict)
        else {}
    )
    current_question = (
        intake_inputs.get("current_question")
        if isinstance(intake_inputs.get("current_question"), dict)
        else None
    )
    question_progress = (
        intake_inputs.get("question_progress")
        if isinstance(intake_inputs.get("question_progress"), dict)
        else {}
    )
    return {
        "next_actions_payload": next_actions_payload,
        "field_progress_payload": field_progress_payload,
        "runtime_payload": runtime_payload,
        "intake_checkpoint": intake_checkpoint,
        "checkpoint_payload": checkpoint_payload,
        "current_question": current_question,
        "question_progress": question_progress,
        "fields": intake_inputs.get("fields") if isinstance(intake_inputs.get("fields"), dict) else {},
        "field_entities": intake_inputs.get("field_entities") if isinstance(intake_inputs.get("field_entities"), dict) else {},
        "required_fields": intake_inputs.get("required_fields") if isinstance(intake_inputs.get("required_fields"), list) else [],
        "required_missing": intake_inputs.get("required_missing") if isinstance(intake_inputs.get("required_missing"), list) else [],
        "intake_understanding": (
            intake_inputs.get("intake_understanding")
            if isinstance(intake_inputs.get("intake_understanding"), dict)
            else {}
        ),
        "analyzability_score_raw": intake_inputs.get("analyzability_score_raw"),
        "total_coverage_raw": intake_inputs.get("total_coverage_raw"),
        "required_coverage_raw": intake_inputs.get("required_coverage_raw"),
        "analysis_entry_threshold_raw": intake_inputs.get("analysis_entry_threshold_raw"),
        "analysis_entry_eligible_raw": intake_inputs.get("analysis_entry_eligible_raw"),
    }


def resolve_intake_session_and_missing_fields(
    *,
    trace_id: str,
    resolved_mode: str,
    runtime_snapshot: dict[str, Any],
    next_actions_payload: dict[str, Any],
    field_progress_payload: dict[str, Any],
    current_question: dict[str, Any] | None,
    fields: dict[str, Any] | None,
    required_fields: list[Any],
    required_missing: list[Any],
    normalize_intake_session_id_fn: Callable[[Any], str],
    build_intake_session_id_fn: Callable[..., str],
) -> dict[str, Any]:
    intake_session_id = normalize_intake_session_id_fn(
        next_actions_payload.get("intake_session_id")
        or field_progress_payload.get("intake_session_id")
        or (
            (runtime_snapshot.get("payload") or {}).get("intake_session_id")
            if isinstance(runtime_snapshot.get("payload"), dict)
            else ""
        )
    )
    if not intake_session_id:
        stage_hint = str(next_actions_payload.get("flow_state") or field_progress_payload.get("flow_state") or "").strip().lower()
        if (
            str(resolved_mode or "").strip() == "requirement_intake"
            or stage_hint in {"collecting", "completed"}
            or str((next_actions_payload.get("current_question") or {}).get("field_key") or "").strip()
        ):
            intake_session_id = build_intake_session_id_fn(
                session_id=str(
                    next_actions_payload.get("session_id")
                    or field_progress_payload.get("session_id")
                    or "default"
                ),
                seed=trace_id,
            )

    normalized_required_fields = [str(item).strip() for item in required_fields if str(item).strip()]
    normalized_required_missing = [str(item).strip() for item in required_missing if str(item).strip()]
    normalized_current_question = current_question if isinstance(current_question, dict) else None
    normalized_fields = fields if isinstance(fields, dict) else {}
    current_question_field = str((normalized_current_question or {}).get("field_key") or "").strip()
    current_question_answered = bool(
        current_question_field
        and str(normalized_fields.get(current_question_field) or "").strip()
    )
    if not normalized_required_missing:
        if current_question_field and not current_question_answered:
            normalized_required_missing = [current_question_field]
        else:
            normalized_current_question = None
    elif current_question_answered:
        normalized_required_missing = [
            item for item in normalized_required_missing if item != current_question_field
        ]
        normalized_current_question = None
    return {
        "intake_session_id": intake_session_id,
        "normalized_required_fields": normalized_required_fields,
        "normalized_required_missing": normalized_required_missing,
        "current_question": normalized_current_question,
    }


def resolve_payload_actions(
    *,
    next_actions_payload: dict[str, Any],
    checkpoint_payload: dict[str, Any],
) -> list[dict[str, Any]]:
    payload_actions = next_actions_payload.get("actions")
    if not isinstance(payload_actions, list):
        payload_actions = next_actions_payload.get("next_actions")
    if not isinstance(payload_actions, list):
        payload_actions = checkpoint_payload.get("next_actions")
    if not isinstance(payload_actions, list):
        payload_actions = []
    return [item for item in payload_actions if isinstance(item, dict)]


def normalize_orchestration_input_context(context: dict[str, Any]) -> dict[str, Any]:
    source = context if isinstance(context, dict) else {}
    return {
        "next_actions_payload": source.get("next_actions_payload") if isinstance(source.get("next_actions_payload"), dict) else {},
        "field_progress_payload": source.get("field_progress_payload") if isinstance(source.get("field_progress_payload"), dict) else {},
        "runtime_payload": source.get("runtime_payload") if isinstance(source.get("runtime_payload"), dict) else {},
        "intake_checkpoint": source.get("intake_checkpoint") if isinstance(source.get("intake_checkpoint"), dict) else {},
        "current_question": source.get("current_question") if isinstance(source.get("current_question"), dict) else None,
        "question_progress": source.get("question_progress") if isinstance(source.get("question_progress"), dict) else {},
        "fields": source.get("fields") if isinstance(source.get("fields"), dict) else {},
        "field_entities": source.get("field_entities") if isinstance(source.get("field_entities"), dict) else {},
        "intake_understanding": source.get("intake_understanding") if isinstance(source.get("intake_understanding"), dict) else {},
        "intake_session_id": str(source.get("intake_session_id") or "").strip(),
        "normalized_required_fields": [
            str(item).strip()
            for item in (source.get("normalized_required_fields") if isinstance(source.get("normalized_required_fields"), list) else [])
            if str(item).strip()
        ],
        "normalized_required_missing": [
            str(item).strip()
            for item in (source.get("normalized_required_missing") if isinstance(source.get("normalized_required_missing"), list) else [])
            if str(item).strip()
        ],
        "required_coverage": float(source.get("required_coverage") or 0.0),
        "total_coverage": float(source.get("total_coverage") or 0.0),
        "analysis_entry_threshold": float(source.get("analysis_entry_threshold") or 0.8),
        "analyzability_score": float(source.get("analyzability_score") or 0.0),
        "analysis_entry_eligible": bool(source.get("analysis_entry_eligible")),
        "open_fields": [
            item
            for item in (source.get("open_fields") if isinstance(source.get("open_fields"), list) else [])
            if isinstance(item, dict)
        ],
        "chooser": source.get("chooser") if isinstance(source.get("chooser"), dict) else {},
        "mode_state": str(source.get("mode_state") or "").strip(),
        "payload_actions": [
            item
            for item in (source.get("payload_actions") if isinstance(source.get("payload_actions"), list) else [])
            if isinstance(item, dict)
        ],
    }
