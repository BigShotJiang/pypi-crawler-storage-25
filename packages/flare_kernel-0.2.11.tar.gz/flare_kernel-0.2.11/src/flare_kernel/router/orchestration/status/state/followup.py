"""Follow-up and checkpoint projection for orchestration status state.

This module keeps the facade from carrying the guided-session and checkpoint
projection wiring in the same function body.
"""

from __future__ import annotations

from typing import Any, Callable


def build_orchestration_status_state_followup_projection(
    *,
    trace_id: str,
    intake_session_id: str,
    resolved_mode: str,
    current_stage: str,
    intake_checkpoint: dict[str, Any],
    current_question: dict[str, Any] | None,
    normalized_required_fields: list[str],
    normalized_required_missing: list[str],
    fields: dict[str, Any],
    resolved_actions: list[dict[str, Any]],
    command: str,
    confirmed_updates: list[dict[str, Any]],
    field_label_map: dict[str, str],
    open_fields: list[dict[str, Any]],
    chooser: dict[str, Any] | None,
    decision_payload: dict[str, Any],
    runtime_payload: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    question_progress: dict[str, Any],
    resolve_followup_and_guided_state_fn: Callable[..., dict[str, Any]],
    resolve_node_and_checkpoint_state_fn: Callable[..., dict[str, Any]],
) -> dict[str, Any]:
    """Resolve the guided-session state and checkpoint projection together."""
    filtered_actions = [item for item in resolved_actions if isinstance(item, dict)]
    followup_and_guided_state = resolve_followup_and_guided_state_fn(
        trace_id=trace_id,
        intake_session_id=intake_session_id,
        resolved_mode=resolved_mode,
        current_stage=current_stage,
        current_question=current_question if isinstance(current_question, dict) else None,
        normalized_required_fields=normalized_required_fields,
        normalized_required_missing=normalized_required_missing,
        fields=fields,
        resolved_actions=filtered_actions,
        command=command,
        confirmed_updates=confirmed_updates,
        field_label_map=field_label_map,
    )
    intake_followup_state = (
        followup_and_guided_state.get("intake_followup_state")
        if isinstance(followup_and_guided_state.get("intake_followup_state"), dict)
        else {}
    )
    next_action = followup_and_guided_state.get("next_action")
    ready_for_submit = bool(followup_and_guided_state.get("ready_for_submit"))
    decision_point_active = bool(followup_and_guided_state.get("decision_point_active"))
    has_active_question = bool(followup_and_guided_state.get("has_active_question"))
    active_collecting = bool(followup_and_guided_state.get("active_collecting"))
    guided_session = (
        followup_and_guided_state.get("guided_session")
        if isinstance(followup_and_guided_state.get("guided_session"), dict)
        else {}
    )
    node_and_checkpoint_state = resolve_node_and_checkpoint_state_fn(
        intake_checkpoint=intake_checkpoint if isinstance(intake_checkpoint, dict) else {},
        current_stage=current_stage,
        current_question=current_question if isinstance(current_question, dict) else None,
        open_fields=open_fields,
        chooser=chooser if isinstance(chooser, dict) else None,
        decision_point_active=decision_point_active,
        decision_payload=decision_payload if isinstance(decision_payload, dict) else {},
        intake_session_id=intake_session_id,
        runtime_payload=runtime_payload if isinstance(runtime_payload, dict) else {},
        runtime_snapshot=runtime_snapshot if isinstance(runtime_snapshot, dict) else {},
        resolved_mode=resolved_mode,
        active_collecting=active_collecting,
        ready_for_submit=ready_for_submit,
        confirmed_updates=confirmed_updates,
        normalized_required_missing=normalized_required_missing,
        question_progress=question_progress if isinstance(question_progress, dict) else {},
    )
    return {
        "intake_followup_state": intake_followup_state,
        "next_action": next_action,
        "ready_for_submit": ready_for_submit,
        "decision_point_active": decision_point_active,
        "has_active_question": has_active_question,
        "active_collecting": active_collecting,
        "guided_session": guided_session,
        "node_and_checkpoint_state": node_and_checkpoint_state,
    }
