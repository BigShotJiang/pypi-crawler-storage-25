"""Intent-stage helpers for orchestration status state.

This module keeps the domain relevance calculation and session-intent stage
resolution together so the main facade only coordinates the pipeline.
"""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.router.intent.compat_aliases import (
    project_domain_relevance,
)

def build_orchestration_status_state_intent_context(
    *,
    resolved_intent: str,
    resolved_mode: str,
    current_stage: str,
    intake_followup_state: dict[str, Any],
    command: str,
    runtime_payload: dict[str, Any],
    compute_domain_relevance_fn: Callable[..., bool] | None = None,
    compute_procurement_relevance_fn: Callable[..., bool] | None = None,
    resolve_session_intent_stage_fn: Callable[..., str],
) -> dict[str, Any]:
    """Return domain relevance and session intent stage for the facade."""
    relevance_fn = compute_domain_relevance_fn or compute_procurement_relevance_fn
    if relevance_fn is None:
        raise ValueError("compute_domain_relevance_fn is required")
    domain_relevance = relevance_fn(
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
    )
    session_intent_stage = resolve_session_intent_stage_fn(
        signal={
            **project_domain_relevance(domain_relevance),
        },
        orchestration_status={
            "current_stage": current_stage,
            "intake_session_state": intake_followup_state.get("intake_session_state", "idle"),
            **project_domain_relevance(domain_relevance),
        },
        message=str(runtime_payload.get("message") or ""),
        command=command,
    )
    return {
        "procurement_relevance": domain_relevance,
        "session_intent_stage": session_intent_stage,
    }
