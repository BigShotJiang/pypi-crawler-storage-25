"""Context-unpack helpers for orchestration status state facade.

This module isolates extraction of normalized context fields so the facade can
focus on orchestration sequencing instead of local variable fan-out.
"""

from __future__ import annotations

from typing import Any


def unpack_orchestration_status_state_context(normalized_context: dict[str, Any]) -> dict[str, Any]:
    """Extract and normalize context fields required by the state facade."""
    return {
        "next_actions_payload": normalized_context["next_actions_payload"],
        "field_progress_payload": normalized_context["field_progress_payload"],
        "runtime_payload": normalized_context["runtime_payload"],
        "intake_checkpoint": normalized_context["intake_checkpoint"],
        "current_question": normalized_context["current_question"],
        "question_progress": normalized_context["question_progress"],
        "fields": normalized_context["fields"],
        "field_entities": normalized_context["field_entities"],
        "intake_understanding": normalized_context["intake_understanding"],
        "intake_session_id": normalized_context["intake_session_id"],
        "normalized_required_fields": normalized_context["normalized_required_fields"],
        "normalized_required_missing": normalized_context["normalized_required_missing"],
        "required_coverage": normalized_context["required_coverage"],
        "total_coverage": normalized_context["total_coverage"],
        "analysis_entry_threshold": normalized_context["analysis_entry_threshold"],
        "analyzability_score": normalized_context["analyzability_score"],
        "analysis_entry_eligible": normalized_context["analysis_entry_eligible"],
        "open_fields": normalized_context["open_fields"],
        "chooser": normalized_context["chooser"],
        "mode_state": normalized_context["mode_state"],
        "payload_actions": normalized_context["payload_actions"],
    }


__all__ = ["unpack_orchestration_status_state_context"]
