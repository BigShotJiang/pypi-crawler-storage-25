"""Decision and stage resolution helpers for orchestration status."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.runtime import DecisionContext, evaluate_orchestration_decision
from flare_kernel.router.intake.decision_rules import (
    apply_entry_recommendation_to_decision,
    enforce_intake_gate_transition,
)
from flare_kernel.router.intake.status.core import (
    resolve_current_stage,
)


def resolve_decision_and_stage(
    *,
    command: str,
    resolved_intent: str,
    resolved_mode: str,
    mode_state: str,
    normalized_required_missing: list[str],
    payload_actions: list[dict[str, Any]],
    current_question: dict[str, Any] | None,
    retrieval_attempted: bool,
    retrieval_hit_count: int,
    chooser: dict[str, Any] | None,
    open_fields: list[dict[str, Any]],
    runtime_snapshot: dict[str, Any],
    entry_mode: str,
    entry_confidence: float,
    entry_reason: str,
    entry_source: str,
    evaluate_orchestration_decision_fn: Callable[[Any], Any] = evaluate_orchestration_decision,
    decision_context_cls: Callable[..., Any] = DecisionContext,
    apply_entry_recommendation_to_decision_fn: Callable[..., dict[str, Any]] = apply_entry_recommendation_to_decision,
    enforce_intake_gate_transition_fn: Callable[..., dict[str, Any]] = enforce_intake_gate_transition,
    resolve_current_stage_fn: Callable[..., str] = resolve_current_stage,
) -> tuple[dict[str, Any], str]:
    decision = evaluate_orchestration_decision_fn(
        decision_context_cls(
            resolved_intent=resolved_intent,
            resolved_mode=resolved_mode,
            mode_state=mode_state,
            required_missing=tuple(normalized_required_missing),
            base_next_actions=tuple(item for item in payload_actions if isinstance(item, dict)),
            current_question=current_question if isinstance(current_question, dict) else None,
            retrieval_attempted=retrieval_attempted,
            retrieval_hit_count=int(retrieval_hit_count),
            chooser=chooser if isinstance(chooser, dict) else {},
            target_field=str((open_fields[0] if open_fields else {}).get("field_key") or "").strip(),
            pack_workflow=(runtime_snapshot.get("domain_pack") or {}).get("workflow")
            if isinstance(runtime_snapshot.get("domain_pack"), dict)
            else None,
            pack_field_policies=(runtime_snapshot.get("domain_pack") or {}).get("field_policies")
            if isinstance(runtime_snapshot.get("domain_pack"), dict)
            else None,
            pack_blocker_policies=(runtime_snapshot.get("domain_pack") or {}).get("blocker_policies")
            if isinstance(runtime_snapshot.get("domain_pack"), dict)
            else None,
            pack_search_mapping=(runtime_snapshot.get("domain_pack") or {}).get("search_mapping")
            if isinstance(runtime_snapshot.get("domain_pack"), dict)
            else None,
            degrade_reasons=tuple(item for item in runtime_snapshot.get("degrade_reasons", []) if str(item).strip())
            if isinstance(runtime_snapshot.get("degrade_reasons"), list)
            else (),
        )
    )
    decision_payload = decision.to_dict()
    decision_payload = apply_entry_recommendation_to_decision_fn(
        decision_payload=decision_payload,
        command=command,
        current_question=current_question if isinstance(current_question, dict) else None,
        entry_mode=entry_mode,
        entry_confidence=entry_confidence,
        entry_reason=entry_reason,
        entry_source=entry_source,
    )
    decision_payload = enforce_intake_gate_transition_fn(
        decision_payload=decision_payload,
        normalized_required_missing=normalized_required_missing,
        current_question=current_question if isinstance(current_question, dict) else None,
    )
    current_stage = str(
        decision_payload.get("next_stage")
        or resolve_current_stage_fn(
            mode_key=resolved_mode,
            mode_state=mode_state,
            open_fields=open_fields,
            chooser=chooser if isinstance(chooser, dict) else {},
        )
    )
    if command == "generate_analysis":
        current_stage = "requirement_analysis.active"
    return decision_payload, current_stage
