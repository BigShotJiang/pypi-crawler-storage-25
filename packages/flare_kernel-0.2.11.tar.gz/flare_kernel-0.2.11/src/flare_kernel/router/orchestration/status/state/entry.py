"""Entry-message and recommendation helpers for orchestration status state.

This module isolates the step that extracts the effective entry message and
turns it into the intake recommendation inputs used by the facade.
"""

from __future__ import annotations

from typing import Any, Callable


def build_orchestration_status_state_entry_context(
    *,
    runtime_payload: dict[str, Any],
    raw_message: str,
    next_actions_payload: dict[str, Any],
    field_progress_payload: dict[str, Any],
    current_question: dict[str, Any] | None,
    normalized_required_missing: list[str],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    resolve_requirement_intake_entry_recommendation_fn: Callable[..., tuple[str, float, str, str]],
    resolve_entry_message_fn: Callable[..., str],
) -> dict[str, Any]:
    """Return the entry message and recommendation tuple used by the facade."""
    entry_message = resolve_entry_message_fn(
        runtime_payload=runtime_payload,
        raw_message=raw_message,
        next_actions_payload=next_actions_payload,
        field_progress_payload=field_progress_payload,
        extract_user_message_fn=extract_user_message_fn,
    )
    entry_mode, entry_confidence, entry_reason, entry_source = resolve_requirement_intake_entry_recommendation_fn(
        message=entry_message,
        current_question=current_question,
        required_missing=normalized_required_missing,
    )
    return {
        "entry_message": entry_message,
        "entry_mode": entry_mode,
        "entry_confidence": entry_confidence,
        "entry_reason": entry_reason,
        "entry_source": entry_source,
    }
