"""Internal pipeline for orchestration status state resolution.

This module hosts the sequencing logic while the public facade provides the
patchable hook surface. The pipeline is intentionally split into readable
stages so the flow boundary stays obvious:
1. normalize and unpack the orchestration context
2. build entry and decision projections
3. derive follow-up, checkpoint, and node state
4. resolve intent and assemble the final payload

The contract assumption is that each injected helper is side-effect free unless
its name explicitly indicates persistence or projection work.

DOC HELPER — ORC-02 stream status chain.
Field label maps are carried through this orchestration pipeline before
confirmed/open field rows are exposed to clients.
"""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.router.orchestration.status.state.context import (
    build_orchestration_status_state_context,
)
from flare_kernel.router.orchestration.status.state.decision import (
    build_orchestration_status_state_decision_context,
)
from flare_kernel.router.orchestration.status.state.entry import (
    build_orchestration_status_state_entry_context,
)
from flare_kernel.router.orchestration.status.state.followup import (
    build_orchestration_status_state_followup_projection,
)
from flare_kernel.router.orchestration.status.state.intent import (
    build_orchestration_status_state_intent_context,
)
from flare_kernel.router.orchestration.status.state.node import (
    unpack_followup_and_node_state,
)
from flare_kernel.router.orchestration.status.state.payload import (
    assemble_orchestration_status_state_payload,
)
from flare_kernel.router.orchestration.status.state.unpack import (
    unpack_orchestration_status_state_context,
)
from flare_kernel.router.intent.compat_aliases import (
    resolve_domain_relevance,
)
from flare_kernel.router.next_actions_guard import dedupe_next_actions_by_action_key


from flare_kernel.router.orchestration.status.actions import (
    normalize_status_stage_and_actions,
)


def resolve_orchestration_status_state_flow(
    *,
    trace_id: str,
    command: str,
    resolved_intent: str,
    resolved_mode: str,
    runtime_snapshot: dict[str, Any],
    raw_message: str,
    retrieval_attempted: bool,
    retrieved_knowledge: list[dict[str, Any]],
    resolve_requirement_intake_entry_recommendation_fn: Callable[..., tuple[str, float, str, str]],
    resolve_session_intent_stage_fn: Callable[..., str],
    extract_user_message_fn: Callable[[dict[str, Any] | None], str],
    prepare_orchestration_input_context_fn: Callable[..., dict[str, Any]],
    unpack_orchestration_input_context_fn: Callable[[dict[str, Any]], dict[str, Any]],
    resolve_entry_message_fn: Callable[..., str],
    resolve_decision_and_stage_fn: Callable[..., tuple[dict[str, Any], str]],
    build_confirmed_updates_fn: Callable[..., list[dict[str, Any]]],
    build_field_label_map_fn: Callable[[Any], dict[str, str]],
    resolve_followup_and_guided_state_fn: Callable[..., dict[str, Any]],
    resolve_node_and_checkpoint_state_fn: Callable[..., dict[str, Any]],
    compute_domain_relevance_fn: Callable[..., bool],
    build_orchestration_status_state_payload_fn: Callable[..., dict[str, Any]],
) -> dict[str, Any]:
    """Run the state-resolution pipeline and return the canonical status payload."""
    # Stage 1: normalize the runtime context and unpack the flat values used by
    # the later projections.
    normalized_context = build_orchestration_status_state_context(
        trace_id=trace_id,
        resolved_mode=resolved_mode,
        runtime_snapshot=runtime_snapshot,
        retrieval_attempted=retrieval_attempted,
        retrieved_knowledge_count=len(retrieved_knowledge),
        prepare_orchestration_input_context_fn=prepare_orchestration_input_context_fn,
        unpack_orchestration_input_context_fn=unpack_orchestration_input_context_fn,
    )
    unpacked_context = unpack_orchestration_status_state_context(normalized_context)
    next_actions_payload = unpacked_context["next_actions_payload"]
    field_progress_payload = unpacked_context["field_progress_payload"]
    runtime_payload = unpacked_context["runtime_payload"]
    intake_checkpoint = unpacked_context["intake_checkpoint"]
    current_question = unpacked_context["current_question"]
    question_progress = unpacked_context["question_progress"]
    fields = unpacked_context["fields"]
    field_entities = unpacked_context["field_entities"]
    intake_understanding = unpacked_context["intake_understanding"]
    intake_session_id = unpacked_context["intake_session_id"]
    normalized_required_fields = unpacked_context["normalized_required_fields"]
    normalized_required_missing = unpacked_context["normalized_required_missing"]
    required_coverage = unpacked_context["required_coverage"]
    total_coverage = unpacked_context["total_coverage"]
    analysis_entry_threshold = unpacked_context["analysis_entry_threshold"]
    analyzability_score = unpacked_context["analyzability_score"]
    analysis_entry_eligible = unpacked_context["analysis_entry_eligible"]
    open_fields = unpacked_context["open_fields"]
    chooser = unpacked_context["chooser"]
    mode_state = unpacked_context["mode_state"]
    payload_actions = unpacked_context["payload_actions"]

    # Stage 2: derive the entry projection and the decision/stage pair before
    # any follow-up or checkpoint projection is computed.
    entry_context = build_orchestration_status_state_entry_context(
        runtime_payload=runtime_payload,
        raw_message=raw_message,
        next_actions_payload=next_actions_payload,
        field_progress_payload=field_progress_payload,
        current_question=current_question if isinstance(current_question, dict) else None,
        normalized_required_missing=normalized_required_missing,
        extract_user_message_fn=extract_user_message_fn,
        resolve_requirement_intake_entry_recommendation_fn=resolve_requirement_intake_entry_recommendation_fn,
        resolve_entry_message_fn=resolve_entry_message_fn,
    )
    decision_context = build_orchestration_status_state_decision_context(
        command=command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_state=mode_state,
        normalized_required_missing=normalized_required_missing,
        payload_actions=payload_actions,
        current_question=current_question if isinstance(current_question, dict) else None,
        retrieval_attempted=retrieval_attempted,
        retrieval_hit_count=len(retrieved_knowledge),
        chooser=chooser if isinstance(chooser, dict) else {},
        open_fields=open_fields,
        runtime_snapshot=runtime_snapshot,
        entry_mode=entry_context["entry_mode"],
        entry_confidence=entry_context["entry_confidence"],
        entry_reason=entry_context["entry_reason"],
        entry_source=entry_context["entry_source"],
        resolve_decision_and_stage_fn=resolve_decision_and_stage_fn,
    )
    decision_payload = decision_context["decision_payload"]
    current_stage = decision_context["current_stage"]
    # DOC HELPER — labels come from domain field definitions, not frontend maps.
    field_label_map = build_field_label_map_fn(field_progress_payload.get("field_definitions"))
    confirmed_updates = build_confirmed_updates_fn(fields, field_label_map=field_label_map)
    resolved_actions = decision_payload.get("next_actions") if isinstance(decision_payload.get("next_actions"), list) else []
    resolved_action_items = dedupe_next_actions_by_action_key(resolved_actions)
    current_stage, decision_payload, resolved_action_items = normalize_status_stage_and_actions(
        current_stage=current_stage,
        decision_payload=decision_payload if isinstance(decision_payload, dict) else {},
        resolved_actions=resolved_action_items,
        normalized_required_missing=normalized_required_missing,
        current_question=current_question if isinstance(current_question, dict) else None,
        fields=fields if isinstance(fields, dict) else {},
        retrieval_hit_count=len(retrieved_knowledge),
        analysis_entry_eligible=analysis_entry_eligible,
        analyzability_score=analyzability_score,
        analysis_entry_threshold=analysis_entry_threshold,
    )
    decision_payload["next_actions"] = resolved_action_items

    # Stage 3: project the follow-up state and checkpoint/node boundary that
    # the client can render without reconstructing the workflow locally.
    followup_and_checkpoint_state = build_orchestration_status_state_followup_projection(
        trace_id=trace_id,
        intake_session_id=intake_session_id,
        resolved_mode=resolved_mode,
        current_stage=current_stage,
        intake_checkpoint=intake_checkpoint if isinstance(intake_checkpoint, dict) else {},
        current_question=current_question if isinstance(current_question, dict) else None,
        normalized_required_fields=normalized_required_fields,
        normalized_required_missing=normalized_required_missing,
        fields=fields,
        resolved_actions=resolved_action_items,
        command=command,
        confirmed_updates=confirmed_updates,
        field_label_map=field_label_map,
        open_fields=open_fields,
        chooser=chooser if isinstance(chooser, dict) else None,
        decision_payload=decision_payload if isinstance(decision_payload, dict) else {},
        runtime_payload=runtime_payload if isinstance(runtime_payload, dict) else {},
        runtime_snapshot=runtime_snapshot if isinstance(runtime_snapshot, dict) else {},
        question_progress=question_progress if isinstance(question_progress, dict) else {},
        resolve_followup_and_guided_state_fn=resolve_followup_and_guided_state_fn,
        resolve_node_and_checkpoint_state_fn=resolve_node_and_checkpoint_state_fn,
    )
    node_projection = unpack_followup_and_node_state(followup_and_checkpoint_state)
    intake_followup_state = node_projection["intake_followup_state"]
    next_action = node_projection["next_action"]
    ready_for_submit = bool(node_projection["ready_for_submit"])
    decision_point_active = bool(node_projection["decision_point_active"])
    has_active_question = bool(node_projection["has_active_question"])
    active_collecting = bool(node_projection["active_collecting"])
    guided_session = node_projection["guided_session"]
    checkpoint_state_value = str(node_projection["checkpoint_state_value"])
    node_id = str(node_projection["node_id"])
    node_state = str(node_projection["node_state"])
    node_reason = str(node_projection["node_reason"])
    needs_user_choice = bool(node_projection["needs_user_choice"])
    chooser_required = bool(node_projection["chooser_required"])
    blocking_reason = str(node_projection["blocking_reason"])
    chooser = node_projection["chooser"]
    active_checkpoint = node_projection["active_checkpoint"]

    # Stage 4: resolve the session-intent view and assemble the final canonical
    # payload consumed by the router response contract.
    intent_context = build_orchestration_status_state_intent_context(
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        current_stage=current_stage,
        intake_followup_state=intake_followup_state,
        command=command,
        runtime_payload=runtime_payload if isinstance(runtime_payload, dict) else {},
        compute_domain_relevance_fn=compute_domain_relevance_fn,
        resolve_session_intent_stage_fn=resolve_session_intent_stage_fn,
    )
    domain_relevance = resolve_domain_relevance(intent_context)
    session_intent_stage = intent_context["session_intent_stage"]

    return assemble_orchestration_status_state_payload(
        active_checkpoint=active_checkpoint,
        active_collecting=active_collecting,
        analysis_entry_decision=(
            decision_payload.get("analysis_entry_decision")
            if isinstance(decision_payload.get("analysis_entry_decision"), dict)
            else None
        ),
        analysis_entry_eligible=analysis_entry_eligible,
        analysis_entry_threshold=analysis_entry_threshold,
        analyzability_score=analyzability_score,
        blocking_reason=blocking_reason,
        checkpoint_state_value=checkpoint_state_value,
        chooser=chooser,
        chooser_required=chooser_required,
        confirmed_updates=confirmed_updates,
        conversation_intent_state=session_intent_stage,
        current_question=current_question if isinstance(current_question, dict) else None,
        decision_payload=decision_payload if isinstance(decision_payload, dict) else {},
        decision_point_active=decision_point_active,
        field_entities=field_entities,
        guided_session=guided_session,
        has_active_question=has_active_question,
        intake_followup_state=intake_followup_state,
        intake_session_id=intake_session_id,
        intake_understanding=intake_understanding if isinstance(intake_understanding, dict) else {},
        next_action=next_action if isinstance(next_action, dict) else None,
        needs_user_choice=needs_user_choice,
        node_id=node_id,
        node_reason=node_reason,
        node_state=node_state,
        normalized_required_fields=normalized_required_fields,
        normalized_required_missing=normalized_required_missing,
        open_fields=open_fields,
        domain_relevance=domain_relevance,
        question_progress=question_progress if isinstance(question_progress, dict) else {},
        ready_for_submit=ready_for_submit,
        required_coverage=required_coverage,
        resolved_actions=resolved_action_items,
        search_retrieval_hit_count=len(retrieved_knowledge),
        session_intent_stage=session_intent_stage,
        total_coverage=total_coverage,
        current_stage=current_stage,
        build_orchestration_status_state_payload_fn=build_orchestration_status_state_payload_fn,
    )


__all__ = ["resolve_orchestration_status_state_flow"]
