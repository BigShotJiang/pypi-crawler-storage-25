"""Context normalization helpers for orchestration status state.

This module keeps the facade from carrying the raw prepare/unpack wiring.
"""

from __future__ import annotations

from typing import Any, Callable


def build_orchestration_status_state_context(
    *,
    trace_id: str,
    resolved_mode: str,
    runtime_snapshot: dict[str, Any],
    retrieval_attempted: bool,
    retrieved_knowledge_count: int,
    prepare_orchestration_input_context_fn: Callable[..., dict[str, Any]],
    unpack_orchestration_input_context_fn: Callable[[dict[str, Any]], dict[str, Any]],
) -> dict[str, Any]:
    """Prepare and unpack the orchestration context in one stable step."""
    prepared_context = prepare_orchestration_input_context_fn(
        trace_id=trace_id,
        resolved_mode=resolved_mode,
        runtime_snapshot=runtime_snapshot,
        retrieval_attempted=retrieval_attempted,
        retrieved_knowledge_count=retrieved_knowledge_count,
    )
    return unpack_orchestration_input_context_fn(prepared_context)
