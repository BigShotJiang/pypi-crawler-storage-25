"""Router orchestration module group."""

from __future__ import annotations

import importlib
import sys

_LEGACY_MODULE_TARGETS = {
    "orchestration_trace": "flare_kernel.router.orchestration.trace.core",
    "orchestration_trace_projection": "flare_kernel.router.orchestration.trace.projection",
    "orchestration_trace_steps": "flare_kernel.router.orchestration.trace.steps",
    "orchestration_status_actions": "flare_kernel.router.orchestration.status.actions",
    "orchestration_status_builder": "flare_kernel.router.orchestration.status.builder",
    "orchestration_status_context": "flare_kernel.router.orchestration.status.context",
    "orchestration_status_context_helpers": "flare_kernel.router.orchestration.status.context_helpers",
    "orchestration_status_decision": "flare_kernel.router.orchestration.status.decision",
    "orchestration_status_projection": "flare_kernel.router.orchestration.status.projection",
    "orchestration_status_result": "flare_kernel.router.orchestration.status.result",
    "orchestration_status_runtime_state": "flare_kernel.router.orchestration.status.runtime_state",
    "orchestration_checkpoint_state": "flare_kernel.router.orchestration.status.checkpoint_state",
    "orchestration_followup_state": "flare_kernel.router.orchestration.status.followup_state",
    "orchestration_status_state": "flare_kernel.router.orchestration.status.core",
    "orchestration_status_state_context": "flare_kernel.router.orchestration.status.state.context",
    "orchestration_status_state_decision": "flare_kernel.router.orchestration.status.state.decision",
    "orchestration_status_state_entry": "flare_kernel.router.orchestration.status.state.entry",
    "orchestration_status_state_flow": "flare_kernel.router.orchestration.status.state.flow",
    "orchestration_status_state_followup": "flare_kernel.router.orchestration.status.state.followup",
    "orchestration_status_state_intent": "flare_kernel.router.orchestration.status.state.intent",
    "orchestration_status_state_node": "flare_kernel.router.orchestration.status.state.node",
    "orchestration_status_state_payload": "flare_kernel.router.orchestration.status.state.payload",
    "orchestration_status_state_unpack": "flare_kernel.router.orchestration.status.state.unpack",
}

for _legacy_name, _target in _LEGACY_MODULE_TARGETS.items():
    sys.modules.setdefault(
        f"flare_kernel.router.orchestration.{_legacy_name}",
        importlib.import_module(_target),
    )
