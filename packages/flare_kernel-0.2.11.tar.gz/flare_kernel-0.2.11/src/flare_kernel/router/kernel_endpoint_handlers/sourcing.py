"""Sourcing endpoint handler helpers.

DOC HELPER — SRC-01 transport-to-runtime sourcing boundary.
This handler maps API contracts into sourcing runtime calls and maps runtime
results back to response DTOs. It does not implement provider logic,
orchestration policy, persistence internals, or frontend state.
"""

from __future__ import annotations

from typing import Callable

from flare_kernel.contracts import SourcingSearchRequest, SourcingSearchResponse
from flare_kernel.runtime.orchestration.sourcing.provider_config_loader import resolve_sourcing_provider_config


def handle_sourcing_search(
    req: SourcingSearchRequest,
    *,
    resolve_trace_id_fn: Callable[[str | None], str],
    run_sourcing_search_fn,
    search_knowledge_records_fn,
    search_web_sources_fn,
    search_instance_records_fn=None,
    search_mcp_records_fn=None,
    persist_sourcing_run_bundle_fn=None,
    load_instance_profile_fn=None,
) -> SourcingSearchResponse:
    trace_id = resolve_trace_id_fn(None)
    source_ids = [str(item).strip() for item in (req.source_ids or []) if str(item).strip()]
    if not source_ids:
        source_ids = [str(item).strip() for item in (req.knowledge_refs or []) if str(item).strip()]
    instance_profile = load_instance_profile_fn(req.instance_id) if callable(load_instance_profile_fn) else None
    provider_config = resolve_sourcing_provider_config(
        request_provider_config=req.provider_config,
        instance_profile=instance_profile,
    )
    result = run_sourcing_search_fn(
        trace_id=trace_id,
        session_id=req.session_id,
        project_id=req.project_id,
        user_id=req.user_id,
        query=req.query,
        top_k=req.top_k,
        append_mode=req.append_mode,
        lock_existing_order=req.lock_existing_order,
        base_result_ids=req.base_result_ids,
        source_scope=req.source_scope,
        sourcing_enabled=req.sourcing_enabled,
        search_knowledge_records_fn=search_knowledge_records_fn,
        search_web_sources_fn=search_web_sources_fn,
        search_instance_records_fn=search_instance_records_fn,
        search_mcp_records_fn=search_mcp_records_fn,
        persist_sourcing_run_bundle_fn=persist_sourcing_run_bundle_fn,
        source_ids=source_ids,
        entities=req.entities,
        provider_config=provider_config,
    )
    return SourcingSearchResponse(
        trace_id=trace_id,
        retrieval_run_id=str(result.get("retrieval_run_id") or ""),
        project_id=req.project_id,
        user_id=req.user_id,
        session_id=req.session_id,
        query=str(result.get("query") or req.query),
        effective_query=str(result.get("effective_query") or ""),
        intent=str(result.get("intent") or ""),
        sourcing_task_kind=str(result.get("sourcing_task_kind") or "mixed"),
        response_label=str(result.get("response_label") or "候选条目"),
        source_scope=req.source_scope,
        sourcing_enabled=req.sourcing_enabled,
        requested_top_k=int(result.get("requested_top_k") or req.top_k),
        returned_count=int(result.get("returned_count") or 0),
        has_more=bool(result.get("has_more")),
        next_top_k=int(result.get("next_top_k") or req.top_k),
        source_breakdown=result.get("source_breakdown") if isinstance(result.get("source_breakdown"), dict) else {},
        selected_source=str(result.get("selected_source") or ""),
        source_priority=result.get("source_priority") if isinstance(result.get("source_priority"), list) else [],
        fallbacks=result.get("fallbacks") if isinstance(result.get("fallbacks"), list) else [],
        provider_health=result.get("provider_health") if isinstance(result.get("provider_health"), list) else [],
        provider_trace=result.get("provider_trace") if isinstance(result.get("provider_trace"), list) else [],
        router_reason=str(result.get("router_reason") or ""),
        final_status=str(result.get("final_status") or "partial"),
        observations=result.get("observations") if isinstance(result.get("observations"), list) else [],
        new_results=result.get("new_results") if isinstance(result.get("new_results"), list) else [],
        all_results=result.get("all_results") if isinstance(result.get("all_results"), list) else [],
        results=result.get("results") if isinstance(result.get("results"), list) else [],
        shortlist=result.get("shortlist") if isinstance(result.get("shortlist"), list) else [],
        canvas_state=result.get("canvas_state") if isinstance(result.get("canvas_state"), dict) else {},
        context_patch=result.get("context_patch") if isinstance(result.get("context_patch"), dict) else {},
        context_revision_id=str(result.get("context_revision_id") or ""),
        blocked=bool(result.get("blocked")),
        reason=str(result.get("reason") or ""),
    )
