"""Health endpoint handler helpers.

This module isolates `/kernel/health` response assembly so transport-layer
contracts stay stable while health/dependency policy can evolve independently.
"""

from __future__ import annotations

from typing import Callable

from flare_kernel.contracts import HealthResponse


def build_health_response(
    *,
    logger,
    resolve_trace_id_fn: Callable[[str | None], str],
    collect_dependency_status_fn: Callable[[], dict[str, bool]],
    collect_capability_status_fn: Callable[..., dict[str, bool]],
) -> HealthResponse:
    """Build typed health response from dependency/capability probes."""
    trace_id = resolve_trace_id_fn(None)
    dependency_status = collect_dependency_status_fn()
    capability_status = collect_capability_status_fn(dependency_status=dependency_status)
    logger.info("kernel.health trace_id=%s", trace_id)
    return HealthResponse(
        status="healthy",
        service="flare-kernel",
        trace_id=trace_id,
        llm_ready=dependency_status["llm_ready"],
        postgres_ready=dependency_status["postgres_ready"],
        redis_ready=dependency_status["redis_ready"],
        qdrant_ready=dependency_status["qdrant_ready"],
        canvas_ready=capability_status["canvas_ready"],
        rag_ready=capability_status["rag_ready"],
        plan_ready=capability_status["plan_ready"],
    )
