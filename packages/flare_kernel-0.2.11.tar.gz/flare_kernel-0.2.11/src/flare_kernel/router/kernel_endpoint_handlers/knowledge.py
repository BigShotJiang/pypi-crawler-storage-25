"""Knowledge endpoint handler helpers.

These handlers only map request/response contracts and delegate persistence/
search to injected runtime callables.
"""

from __future__ import annotations

from typing import Callable

from flare_kernel.contracts import (
    KnowledgeIngestRequest,
    KnowledgeIngestResponse,
    KnowledgeSearchRequest,
    KnowledgeSearchResponse,
)


def handle_knowledge_ingest(
    req: KnowledgeIngestRequest,
    *,
    resolve_trace_id_fn: Callable[[str | None], str],
    ingest_knowledge_record_fn,
) -> KnowledgeIngestResponse:
    """Handle `/kernel/knowledge/ingest` by delegating to runtime ingest."""
    trace_id = resolve_trace_id_fn(None)
    ingest_result = ingest_knowledge_record_fn(
        trace_id=trace_id,
        project_id=req.project_id,
        user_id=req.user_id,
        session_id=req.session_id,
        content=req.content,
        source_id=req.source_id,
        title=req.title,
        metadata=req.metadata,
    )
    return KnowledgeIngestResponse(
        trace_id=trace_id,
        project_id=req.project_id,
        user_id=req.user_id,
        record_id=ingest_result["record_id"],
        chunk_count=ingest_result["chunk_count"],
        status=ingest_result["status"],
        details=ingest_result["details"],
        source_id=ingest_result.get("source_id"),
        error_code=ingest_result.get("error_code"),
        error_message=ingest_result.get("error_message"),
    )


def handle_knowledge_search(
    req: KnowledgeSearchRequest,
    *,
    resolve_trace_id_fn: Callable[[str | None], str],
    search_knowledge_records_fn,
) -> KnowledgeSearchResponse:
    """Handle `/kernel/knowledge/search` by delegating to runtime search."""
    trace_id = resolve_trace_id_fn(None)
    results = search_knowledge_records_fn(
        trace_id=trace_id,
        project_id=req.project_id,
        user_id=req.user_id,
        query=req.query,
        top_k=req.top_k,
    )
    return KnowledgeSearchResponse(
        trace_id=trace_id,
        project_id=req.project_id,
        user_id=req.user_id,
        query=req.query,
        results=results,
    )
