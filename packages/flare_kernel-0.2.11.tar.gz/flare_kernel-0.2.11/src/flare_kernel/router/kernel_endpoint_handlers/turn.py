"""Turn-oriented endpoint handlers for run/action/stream and intent suggestion.

This module keeps per-turn transport wiring in one place while delegating
business logic to injected builder/resolver callables.
"""

from __future__ import annotations

from inspect import Parameter, signature
from typing import Any

from fastapi.responses import StreamingResponse

from flare_kernel.contracts import IntentSuggestResponse, KernelRequest, KernelResponse


async def handle_intent_suggest(
    req: KernelRequest,
    *,
    logger,
    resolve_trace_id_fn,
    resolve_intent_suggestion_fn,
) -> IntentSuggestResponse:
    """Resolve intent suggestion and return typed contract payload."""
    trace_id = resolve_trace_id_fn(req.trace_id)
    suggested_mode, confidence, reason, source = await resolve_intent_suggestion_fn(req, trace_id)
    logger.info(
        "kernel.intent_suggest trace_id=%s session_id=%s suggested_mode=%s source=%s confidence=%.2f",
        trace_id,
        req.session_id,
        suggested_mode,
        source,
        confidence,
    )
    return IntentSuggestResponse(
        trace_id=trace_id,
        suggested_mode=suggested_mode,
        confidence=confidence,
        reason=reason,
        source=source,
    )


def _extract_turn_mode_intent_payload(turn: dict[str, Any]) -> dict[str, Any]:
    """Normalize common intent/mode attributes from prepared turn context."""
    return {
        "resolved_intent": str(turn["resolved_intent"]),
        "intent_source": str(turn["intent_source"]),
        "intent_confidence": float(turn["intent_confidence"]),
        "intent_reason": str(turn["intent_reason"]),
        "resolved_mode": str(turn["resolved_mode"]),
        "mode_source": str(turn["mode_source"]),
    }


def _supports_run_structured_reasoning_flag(callable_obj) -> bool:
    params = signature(callable_obj).parameters
    return "run_structured_reasoning" in params or any(
        param.kind == Parameter.VAR_KEYWORD
        for param in params.values()
    )


async def handle_kernel_run(
    req: KernelRequest,
    *,
    prepare_kernel_turn_context_fn,
    unpack_kernel_turn_context_fn,
    build_kernel_run_response_fn,
    should_force_requirement_clarification_fn,
    build_requirement_clarification_message_fn,
    extract_quoted_terms_fn,
    build_prompt_fn,
    build_mode_switch_reason_fn,
    build_canonical_state_fn,
    sync_session_intent_stage_fn,
    persist_authoritative_intake_state_fn,
) -> KernelResponse:
    """Handle `/kernel/run` using prepared turn context and run response builder."""
    turn = unpack_kernel_turn_context_fn(await prepare_kernel_turn_context_fn(req))
    return await build_kernel_run_response_fn(
        req=req,
        turn=turn,
        **_extract_turn_mode_intent_payload(turn),
        should_force_requirement_clarification_fn=should_force_requirement_clarification_fn,
        build_requirement_clarification_message_fn=lambda message: build_requirement_clarification_message_fn(
            message,
            extract_quoted_terms_fn=extract_quoted_terms_fn,
        ),
        build_prompt_fn=lambda request, payload, profile, intent, command: build_prompt_fn(
            request,
            payload,
            profile,
            intent=intent,
            command=command,
        ),
        build_mode_switch_reason_fn=build_mode_switch_reason_fn,
        build_canonical_state_fn=build_canonical_state_fn,
        sync_session_intent_stage_fn=sync_session_intent_stage_fn,
        persist_authoritative_intake_state_fn=persist_authoritative_intake_state_fn,
    )


async def handle_kernel_action(
    req: KernelRequest,
    *,
    prepare_action_turn_context_fn,
    resolve_trace_id_fn,
    load_instance_profile_fn,
    resolve_intent_escalation_policy_with_source_fn,
    resolve_command_fn,
    resolve_action_target_mode_fn,
    build_action_payload_fn,
    enrich_payload_fn,
    build_kernel_runtime_fn,
    build_orchestration_status_fn,
    extract_user_message_fn,
    build_intent_and_escalation_signal_fn,
    merge_intent_and_escalation_signal_fn,
    build_kernel_action_response_fn,
    build_prompt_fn,
    sync_session_intent_stage_fn,
    persist_authoritative_intake_state_fn,
) -> KernelResponse:
    """Handle `/kernel/action` by preparing action context then delegating response."""
    action_context = prepare_action_turn_context_fn(
        req,
        resolve_trace_id_fn=resolve_trace_id_fn,
        load_instance_profile_fn=load_instance_profile_fn,
        resolve_intent_escalation_policy_with_source_fn=resolve_intent_escalation_policy_with_source_fn,
        resolve_command_fn=resolve_command_fn,
        resolve_action_target_mode_fn=resolve_action_target_mode_fn,
        build_action_payload_fn=build_action_payload_fn,
        enrich_payload_fn=enrich_payload_fn,
        build_kernel_runtime_fn=build_kernel_runtime_fn,
        build_orchestration_status_fn=build_orchestration_status_fn,
        extract_user_message_fn=extract_user_message_fn,
        build_intent_and_escalation_signal_fn=build_intent_and_escalation_signal_fn,
        merge_intent_and_escalation_signal_fn=merge_intent_and_escalation_signal_fn,
    )
    return await build_kernel_action_response_fn(
        req=req,
        action_context=action_context,
        build_prompt_fn=build_prompt_fn,
        sync_session_intent_stage_fn=sync_session_intent_stage_fn,
        persist_authoritative_intake_state_fn=persist_authoritative_intake_state_fn,
    )


async def handle_kernel_stream(
    req: KernelRequest,
    *,
    prepare_kernel_turn_context_fn,
    unpack_kernel_turn_context_fn,
    build_kernel_stream_response_fn,
    ensure_stream_session_fn,
    patch_scopes: set[str],
    build_patch_event_fn,
    safe_session_id_fn,
    build_mode_switch_reason_fn,
    build_canonical_state_fn,
    should_force_requirement_clarification_fn,
    build_requirement_clarification_message_fn,
    extract_quoted_terms_fn,
    build_prompt_fn,
    sync_session_intent_stage_fn,
    persist_authoritative_intake_state_fn,
) -> StreamingResponse:
    """Handle `/kernel/stream` by wiring context and stream builder dependencies."""
    authoritative_session_id = str(req.session_id or "").strip()
    if not authoritative_session_id:
        authoritative_session_id = str(ensure_stream_session_fn(req) or "").strip()
    effective_req = (
        req.model_copy(update={"session_id": authoritative_session_id})
        if authoritative_session_id and authoritative_session_id != str(req.session_id or "").strip()
        else req
    )
    if _supports_run_structured_reasoning_flag(prepare_kernel_turn_context_fn):
        turn_context = await prepare_kernel_turn_context_fn(effective_req, run_structured_reasoning=False)
    else:
        turn_context = await prepare_kernel_turn_context_fn(effective_req)
    turn = unpack_kernel_turn_context_fn(turn_context)
    return await build_kernel_stream_response_fn(
        req=effective_req,
        turn=turn,
        **_extract_turn_mode_intent_payload(turn),
        patch_scopes=patch_scopes,
        build_patch_event_fn=build_patch_event_fn,
        safe_session_id_fn=safe_session_id_fn,
        build_mode_switch_reason_fn=build_mode_switch_reason_fn,
        build_canonical_state_fn=build_canonical_state_fn,
        should_force_requirement_clarification_fn=should_force_requirement_clarification_fn,
        build_requirement_clarification_message_fn=lambda message: build_requirement_clarification_message_fn(
            message,
            extract_quoted_terms_fn=extract_quoted_terms_fn,
        ),
        build_prompt_fn=lambda request, payload, profile, intent, command: build_prompt_fn(
            request,
            payload,
            profile,
            intent=intent,
            command=command,
        ),
        sync_session_intent_stage_fn=sync_session_intent_stage_fn,
        persist_authoritative_intake_state_fn=persist_authoritative_intake_state_fn,
    )
