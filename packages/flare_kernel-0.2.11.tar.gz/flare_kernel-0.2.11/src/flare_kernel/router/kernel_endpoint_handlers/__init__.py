"""Kernel endpoint handler facade.

This module preserves historical import paths while delegating endpoint-specific
logic to smaller focused handler modules.
"""

from __future__ import annotations

from flare_kernel.router.kernel_endpoint_handlers.health import build_health_response
from flare_kernel.router.kernel_endpoint_handlers.knowledge import (
    handle_knowledge_ingest,
    handle_knowledge_search,
)
from flare_kernel.router.kernel_endpoint_handlers.sourcing import handle_sourcing_search
from flare_kernel.router.kernel_endpoint_handlers.turn import (
    handle_intent_suggest,
    handle_kernel_action,
    handle_kernel_run,
    handle_kernel_stream,
)

__all__ = [
    "build_health_response",
    "handle_intent_suggest",
    "handle_kernel_run",
    "handle_kernel_action",
    "handle_kernel_stream",
    "handle_knowledge_ingest",
    "handle_knowledge_search",
    "handle_sourcing_search",
]
