"""Kernel API router."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

from flare_kernel.contracts import (
    AuthContext,
    HealthResponse,
    IntentSuggestResponse,
    KernelRequest,
    KernelResponse,
    KnowledgeIngestRequest,
    KnowledgeIngestResponse,
    KnowledgeSearchRequest,
    KnowledgeSearchResponse,
    SourcingSearchRequest,
    SourcingSearchResponse,
)
from flare_kernel.router.api.auth_guard import require_route_scope, resolve_route_auth_context
from flare_kernel.router.payload.action import (
    build_action_payload as build_action_payload_from_router,
    resolve_action_target_mode as resolve_action_target_mode_from_router,
)
from flare_kernel.router.context.endpoint import (
    prepare_action_turn_context as prepare_action_turn_context_from_router,
    unpack_kernel_turn_context as unpack_kernel_turn_context_from_router,
)
from flare_kernel.router.kernel_constants import PATCH_SCOPES as _PATCH_SCOPES
from flare_kernel.router.kernel_endpoint_handlers import (
    build_health_response as build_health_response_from_router,
    handle_intent_suggest as handle_intent_suggest_from_router,
    handle_kernel_action as handle_kernel_action_from_router,
    handle_kernel_run as handle_kernel_run_from_router,
    handle_kernel_stream as handle_kernel_stream_from_router,
    handle_knowledge_ingest as handle_knowledge_ingest_from_router,
    handle_knowledge_search as handle_knowledge_search_from_router,
)
from flare_kernel.router.kernel_endpoint_handlers.sourcing import (
    handle_sourcing_search as handle_sourcing_search_from_router,
)
from flare_kernel.router.kernel_facade.canonical_state import _build_canonical_state
from flare_kernel.router.kernel_facade.orchestration import (
    _build_orchestration_status,
    _build_prompt,
    _persist_authoritative_intake_state,
)
from flare_kernel.router.kernel_facade.payload_enrichment import _enrich_payload
from flare_kernel.router.kernel_facade.turn_context import _prepare_kernel_turn_context
from flare_kernel.router.kernel_facade.utils import _safe_session_id
from flare_kernel.router.kernel_request_pipeline.action import (
    _build_mode_switch_reason,
    _resolve_command,
    _resolve_current_mode,
    _resolve_intent_override,
    _resolve_manual_mode,
    _resolve_request_mode,
)
from flare_kernel.router.kernel_request_pipeline.intake import (
    _build_confirmed_fields_schema,
    _build_missing_fields_schema,
    _coerce_intent_escalation_policy,
    _is_requirement_mode_explicit,
    _merge_intent_and_escalation_signal,
    _normalize_stage_status,
    _resolve_intent_escalation_policy,
    _resolve_intent_escalation_policy_with_source,
    _resolve_requirement_intake_entry_recommendation,
    _resolve_session_intent_stage,
    _resolve_small_talk_intro_reply,
    _sync_session_intent_stage,
)
from flare_kernel.router.kernel_request_pipeline.intent_query import (
    _build_retrieval_queries,
    _resolve_intent_suggestion,
    _resolve_request_intent,
    _resolve_request_intent_with_ai,
    _should_force_requirement_clarification,
)
from flare_kernel.router.kernel_request_pipeline.intent_signal import (
    _apply_escalation_mode_override,
    _build_intent_and_escalation_signal,
)
from flare_kernel.router.intake.clarification import (
    build_requirement_clarification_message as _build_requirement_clarification_message,
    build_requirement_collection_status as _build_requirement_collection_status,
)
from flare_kernel.router.intake.answer import (
    normalize_field_value_payload as _normalize_field_value_payload,
)
from flare_kernel.router.intake.authority.core import (
    hydrate_payload_from_authoritative_checkpoint as hydrate_payload_from_authoritative_checkpoint_state,
    hydrate_payload_from_authoritative_intake_session as hydrate_payload_from_authoritative_intake_state,
    normalize_intake_session_id as normalize_intake_session_id_from_authority,
    resolve_intake_session_id as resolve_intake_session_id_from_authority,
)
from flare_kernel.router.intake.canonicalization import (
    canonicalize_budget_value as _canonicalize_budget_value,
    canonicalize_payload_fields as _canonicalize_payload_fields,
    is_field_entity_confirmed as _is_field_entity_confirmed,
)
from flare_kernel.router.intake.extraction.core import (
    extract_intake_fields_from_message as _extract_intake_fields_from_message,
    merge_inferred_requirements as _merge_inferred_requirements,
    merge_into_confirmed_fields as _merge_into_confirmed_fields,
    merge_supplementary_fields as _merge_supplementary_fields,
    normalize_extracted_field_values as _normalize_extracted_field_values,
)
from flare_kernel.router.intake.field_scope import (
    resolve_intake_allowed_fields as resolve_intake_allowed_fields_from_router,
)
from flare_kernel.router.intake.payload_updates import (
    apply_question_answer_payload as _apply_question_answer_payload,
    apply_workspace_patch_payload as _apply_workspace_patch_payload,
    extract_quoted_terms as _extract_quoted_terms,
)
from flare_kernel.router.intake.status.core import (
    build_structured_search_results as build_structured_search_results_from_intake_status,
)
from flare_kernel.router.kernel_route.execution import (
    build_kernel_action_response as build_kernel_action_response_from_router,
    build_kernel_run_response as build_kernel_run_response_from_router,
    build_kernel_stream_response as build_kernel_stream_response_from_router,
)
from flare_kernel.router.patch_contract import build_patch_event as _build_patch_event
from flare_kernel.router.prompting import resolve_effective_command as _resolve_effective_command
from flare_kernel.router.request.identity import (
    resolve_project_id as resolve_project_id_from_router,
    resolve_user_id as resolve_user_id_from_router,
)
from flare_kernel.router.retrieval.projection import (
    resolve_retrieval_config as resolve_retrieval_config_from_router,
)
from flare_kernel.router.retrieval.search import (
    search_knowledge_by_queries as _search_knowledge_by_queries,
)
from flare_kernel.router.text_safety import sanitize_customer_visible_text as _sanitize_customer_visible_text
from flare_kernel.router.text_safety import (
    extract_user_message as _extract_user_message,
    normalize_message_text as _normalize_message_text,
    sanitize_product_name_for_prompt as _sanitize_product_name_for_prompt,
)
from flare_kernel.runtime.infrastructure.sourcing.persistence import persist_sourcing_run_bundle
from flare_kernel.runtime.infrastructure.sourcing.instance_profile_adapter import search_instance_records
from flare_kernel.runtime.infrastructure.sourcing.provider import search_web_sources
from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine
from flare_kernel.runtime.orchestration.sourcing.search_runtime import run_sourcing_search
from flare_kernel.runtime.orchestration.analysis_router_runtime import (
    resolve_analysis_route as resolve_analysis_route_from_runtime,
)
from flare_kernel.runtime import (
    build_kernel_runtime,
    collect_capability_status,
    collect_dependency_status,
    generate_llm_completion,
    get_logger,
    ingest_knowledge_record,
    load_intake_checkpoint,
    load_intake_session_snapshot,
    load_latest_intake_session_id,
    load_instance_profile,
    persist_intake_checkpoint,
    persist_intake_session_state,
    resolve_trace_id,
    search_knowledge_records,
)
from flare_kernel.session_store import ensure_session

router = APIRouter(prefix="/kernel", tags=["kernel"])
logger = get_logger("flare_kernel.router.kernel")


def _require_kernel_scope(auth_context: AuthContext | None, req: object, scope: str) -> None:
    require_route_scope(
        auth_context,
        required_scopes=[scope],
        project_id=str(getattr(req, "project_id", "") or ""),
        session_id=str(getattr(req, "session_id", "") or ""),
        user_id=str(getattr(req, "user_id", "") or ""),
    )


def _ensure_kernel_stream_session_id(req: KernelRequest) -> str:
    payload = req.payload if isinstance(req.payload, dict) else {}
    row = ensure_session(
        session_id=req.session_id,
        function_type=(
            req.current_mode
            or req.manual_mode
            or req.mode
            or payload.get("function_type")
            or payload.get("mode")
        ),
        project_id=req.project_id or payload.get("project_id"),
        title=None,
        user_id=req.user_id or payload.get("user_id"),
    )
    return str((row or {}).get("session_id") or "").strip()


@router.get("/health", response_model=HealthResponse)
async def kernel_health() -> HealthResponse:
    return build_health_response_from_router(
        logger=logger,
        resolve_trace_id_fn=resolve_trace_id,
        collect_dependency_status_fn=collect_dependency_status,
        collect_capability_status_fn=collect_capability_status,
    )


@router.post("/intent/suggest", response_model=IntentSuggestResponse)
async def kernel_intent_suggest(
    req: KernelRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> IntentSuggestResponse:
    _require_kernel_scope(auth_context, req, "kernel:intent:suggest")
    return await handle_intent_suggest_from_router(
        req,
        logger=logger,
        resolve_trace_id_fn=resolve_trace_id,
        resolve_intent_suggestion_fn=_resolve_intent_suggestion,
    )


@router.post("/run", response_model=KernelResponse)
async def kernel_run(
    req: KernelRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> KernelResponse:
    _require_kernel_scope(auth_context, req, "kernel:run")
    return await handle_kernel_run_from_router(
        req,
        prepare_kernel_turn_context_fn=_prepare_kernel_turn_context,
        unpack_kernel_turn_context_fn=unpack_kernel_turn_context_from_router,
        build_kernel_run_response_fn=build_kernel_run_response_from_router,
        should_force_requirement_clarification_fn=_should_force_requirement_clarification,
        build_requirement_clarification_message_fn=_build_requirement_clarification_message,
        extract_quoted_terms_fn=_extract_quoted_terms,
        build_prompt_fn=_build_prompt,
        build_mode_switch_reason_fn=_build_mode_switch_reason,
        build_canonical_state_fn=_build_canonical_state,
        sync_session_intent_stage_fn=_sync_session_intent_stage,
        persist_authoritative_intake_state_fn=_persist_authoritative_intake_state,
    )


@router.post("/action", response_model=KernelResponse)
async def kernel_action(
    req: KernelRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> KernelResponse:
    _require_kernel_scope(auth_context, req, "kernel:action")
    return await handle_kernel_action_from_router(
        req,
        prepare_action_turn_context_fn=prepare_action_turn_context_from_router,
        resolve_trace_id_fn=resolve_trace_id,
        load_instance_profile_fn=load_instance_profile,
        resolve_intent_escalation_policy_with_source_fn=_resolve_intent_escalation_policy_with_source,
        resolve_command_fn=_resolve_command,
        resolve_action_target_mode_fn=resolve_action_target_mode_from_router,
        build_action_payload_fn=build_action_payload_from_router,
        enrich_payload_fn=_enrich_payload,
        build_kernel_runtime_fn=build_kernel_runtime,
        build_orchestration_status_fn=_build_orchestration_status,
        extract_user_message_fn=_extract_user_message,
        build_intent_and_escalation_signal_fn=_build_intent_and_escalation_signal,
        merge_intent_and_escalation_signal_fn=_merge_intent_and_escalation_signal,
        build_kernel_action_response_fn=build_kernel_action_response_from_router,
        build_prompt_fn=_build_prompt,
        sync_session_intent_stage_fn=_sync_session_intent_stage,
        persist_authoritative_intake_state_fn=_persist_authoritative_intake_state,
    )


@router.post("/stream")
async def kernel_stream(
    req: KernelRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> StreamingResponse:
    _require_kernel_scope(auth_context, req, "kernel:stream")
    return await handle_kernel_stream_from_router(
        req,
        prepare_kernel_turn_context_fn=_prepare_kernel_turn_context,
        unpack_kernel_turn_context_fn=unpack_kernel_turn_context_from_router,
        build_kernel_stream_response_fn=build_kernel_stream_response_from_router,
        ensure_stream_session_fn=_ensure_kernel_stream_session_id,
        patch_scopes=_PATCH_SCOPES,
        build_patch_event_fn=_build_patch_event,
        safe_session_id_fn=_safe_session_id,
        build_mode_switch_reason_fn=_build_mode_switch_reason,
        build_canonical_state_fn=_build_canonical_state,
        should_force_requirement_clarification_fn=_should_force_requirement_clarification,
        build_requirement_clarification_message_fn=_build_requirement_clarification_message,
        extract_quoted_terms_fn=_extract_quoted_terms,
        build_prompt_fn=_build_prompt,
        sync_session_intent_stage_fn=_sync_session_intent_stage,
        persist_authoritative_intake_state_fn=_persist_authoritative_intake_state,
    )


@router.post("/knowledge/ingest", response_model=KnowledgeIngestResponse)
async def kernel_knowledge_ingest(
    req: KnowledgeIngestRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> KnowledgeIngestResponse:
    _require_kernel_scope(auth_context, req, "knowledge:ingest")
    return handle_knowledge_ingest_from_router(
        req,
        resolve_trace_id_fn=resolve_trace_id,
        ingest_knowledge_record_fn=ingest_knowledge_record,
    )


@router.post("/knowledge/search", response_model=KnowledgeSearchResponse)
async def kernel_knowledge_search(
    req: KnowledgeSearchRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> KnowledgeSearchResponse:
    _require_kernel_scope(auth_context, req, "knowledge:search")
    return handle_knowledge_search_from_router(
        req,
        resolve_trace_id_fn=resolve_trace_id,
        search_knowledge_records_fn=search_knowledge_records,
    )


@router.post("/sourcing/search", response_model=SourcingSearchResponse)
async def kernel_sourcing_search(
    req: SourcingSearchRequest,
    auth_context: AuthContext | None = Depends(resolve_route_auth_context),
) -> SourcingSearchResponse:
    _require_kernel_scope(auth_context, req, "sourcing:search")
    return handle_sourcing_search_from_router(
        req,
        resolve_trace_id_fn=resolve_trace_id,
        run_sourcing_search_fn=run_sourcing_search,
        search_knowledge_records_fn=search_knowledge_records,
        search_web_sources_fn=search_web_sources,
        search_instance_records_fn=search_instance_records,
        load_instance_profile_fn=load_instance_profile,
        persist_sourcing_run_bundle_fn=lambda **kwargs: persist_sourcing_run_bundle(
            **kwargs,
            build_sqlalchemy_engine_fn=build_sqlalchemy_engine,
        ),
    )
