"""Compatibility policy for update planning."""

from __future__ import annotations

from flare_kernel.contracts.update_contract import ReleaseManifestEntry, VersionConstraint
from flare_kernel.update.versioning import compare_versions, satisfies_max_version


def release_accepts_current_version(release: ReleaseManifestEntry, current_version: str) -> bool:
    minimum = str(release.minimum_supported_version or "").strip()
    return not minimum or compare_versions(current_version, minimum) >= 0


def target_satisfies_constraints(release: ReleaseManifestEntry, constraints: VersionConstraint) -> bool:
    if constraints.min_version and compare_versions(release.version, constraints.min_version) < 0:
        return False
    return satisfies_max_version(release.version, constraints.max_version)
