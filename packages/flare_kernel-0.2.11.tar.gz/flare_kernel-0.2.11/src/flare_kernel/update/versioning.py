"""Version comparison helpers for update planning."""

from __future__ import annotations


def parse_version(version: str) -> tuple[int, ...]:
    parts = []
    for raw_part in str(version or "").split("."):
        digits = "".join(ch for ch in raw_part if ch.isdigit())
        parts.append(int(digits or 0))
    return tuple(parts or [0])


def compare_versions(left: str, right: str) -> int:
    left_parts = parse_version(left)
    right_parts = parse_version(right)
    width = max(len(left_parts), len(right_parts))
    normalized_left = left_parts + (0,) * (width - len(left_parts))
    normalized_right = right_parts + (0,) * (width - len(right_parts))
    return (normalized_left > normalized_right) - (normalized_left < normalized_right)


def satisfies_max_version(version: str, max_version: str) -> bool:
    raw = str(max_version or "").strip()
    if not raw:
        return True
    if raw.endswith(".x"):
        prefix = raw[:-2]
        return str(version or "").startswith(f"{prefix}.") or str(version or "") == prefix
    return compare_versions(version, raw) <= 0
