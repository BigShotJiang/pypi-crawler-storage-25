"""Release registry selection for update planning."""

from __future__ import annotations

from flare_kernel.contracts.update_contract import ReleaseManifestEntry
from flare_kernel.update.versioning import parse_version


def latest_release_for_channel(
    releases: list[ReleaseManifestEntry],
    *,
    channel: str,
) -> ReleaseManifestEntry | None:
    channel_releases = [release for release in releases if release.channel == channel]
    if not channel_releases:
        return None
    return max(channel_releases, key=lambda release: parse_version(release.version))
