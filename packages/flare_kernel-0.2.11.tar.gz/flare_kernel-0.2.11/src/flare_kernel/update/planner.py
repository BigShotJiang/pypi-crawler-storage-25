"""Pure update check and upgrade plan orchestration."""

from __future__ import annotations

from flare_kernel.contracts.update_contract import (
    UpdateCheckRequest,
    UpdateCheckResult,
    UpgradePlanRequest,
    UpgradePlanResult,
    UpgradePlanStep,
)
from flare_kernel.update.compatibility import release_accepts_current_version, target_satisfies_constraints
from flare_kernel.update.registry import latest_release_for_channel
from flare_kernel.update.versioning import compare_versions


def check_update(request: UpdateCheckRequest) -> UpdateCheckResult:
    latest = latest_release_for_channel(request.releases, channel=request.target_channel)
    if latest is None:
        return UpdateCheckResult(current_version=request.current_version, reason="no_release_for_channel")

    update_available = compare_versions(latest.version, request.current_version) > 0
    compatible = release_accepts_current_version(latest, request.current_version)
    constrained = target_satisfies_constraints(latest, request.compatibility_constraints)
    upgradeable = update_available and compatible and constrained
    return UpdateCheckResult(
        current_version=request.current_version,
        latest_version=latest.version,
        update_available=update_available,
        upgradeable=upgradeable,
        reason=_resolve_reason(update_available, compatible, constrained),
        breaking_changes=latest.breaking_changes,
        required_migrations=list(latest.required_migrations),
        recommended_tests=list(latest.recommended_tests),
        rollback_supported=latest.rollback_supported,
        release_notes_url=latest.release_notes_url,
    )


def create_upgrade_plan(request: UpgradePlanRequest) -> UpgradePlanResult:
    check = check_update(request)
    steps = _build_plan_steps(check)
    return UpgradePlanResult(**check.model_dump(), dry_run=request.dry_run, steps=steps)


def _resolve_reason(update_available: bool, compatible: bool, constrained: bool) -> str:
    if not update_available:
        return "already_latest"
    if not compatible:
        return "current_version_unsupported"
    if not constrained:
        return "target_version_outside_constraints"
    return "upgrade_available"


def _build_plan_steps(check: UpdateCheckResult) -> list[UpgradePlanStep]:
    if not check.upgradeable:
        return []
    steps = [
        UpgradePlanStep(action="prepare", description="Prepare deployment update materials."),
        UpgradePlanStep(action="test", description="Run recommended compatibility tests."),
    ]
    if check.required_migrations:
        steps.append(UpgradePlanStep(action="migrate", description="Apply required migrations."))
    steps.append(UpgradePlanStep(action="deploy", description="Hand off update execution to deployment adapter."))
    return steps
