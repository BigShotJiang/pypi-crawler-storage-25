"""Read-only session replay assembly.

DOC HELPER — OBJ-09 replay boundary.
Replay exposes persisted context authority as diagnostics only; it must not
reconstruct or alter authoritative context from historical UI artifacts.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.session_store import get_session, list_messages

_TRACE_FIELDS = (
    "agent_status",
    "execution_trace",
    "knowledge_search",
    "sourcing_candidates",
    "knowledge_citation",
    "context_usage",
    "provider_trace",
    "context_authority",
    "plan_payload",
)


def _has_value(value: Any) -> bool:
    """Return whether a persisted message field carries replay value."""

    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    return bool(value)


def _strategy_fields(message: dict[str, Any] | None) -> list[str]:
    """List persisted strategy/trace fields available for a message."""

    if not message:
        return []
    fields = [field for field in _TRACE_FIELDS if _has_value(message.get(field))]
    if _has_value(message.get("thinking_trace")):
        fields.append("thinking_trace")
    return fields


def _plan_summary(message: dict[str, Any] | None) -> dict[str, Any]:
    """Project plan payload fields useful for read-only replay review."""

    payload = message.get("plan_payload") if message else None
    if not isinstance(payload, dict):
        return {}
    return {
        "mode_key": payload.get("mode_key"),
        "mode_state": payload.get("mode_state"),
        "current_question": payload.get("current_question"),
        "next_actions": payload.get("next_actions"),
    }


def _turn_diagnostics(user_message: dict[str, Any] | None, assistant_message: dict[str, Any] | None) -> dict[str, Any]:
    """Build deterministic replay diagnostics for one user/assistant turn."""

    fields = _strategy_fields(assistant_message)
    hints: list[str] = []
    if user_message is not None and assistant_message is None:
        hints.append("missing_assistant_response")
    if assistant_message is not None and not fields:
        hints.append("assistant_message_has_no_strategy_trace")
    if assistant_message is not None and _has_value(assistant_message.get("plan_payload")):
        if not _has_value(assistant_message.get("execution_trace")):
            hints.append("plan_payload_without_execution_trace")
    return {
        "strategy_fields": fields,
        "plan": _plan_summary(assistant_message),
        "review_hints": hints,
    }


def _turn_run(user_message: dict[str, Any] | None, assistant_message: dict[str, Any] | None) -> dict[str, Any]:
    """Project canonical run metadata for a replay turn."""

    run_id = str((assistant_message or {}).get("run_id") or (user_message or {}).get("run_id") or "").strip()
    return {"run_id": run_id} if run_id else {}


def _build_turn(turn_index: int, user_message: dict[str, Any] | None, assistant_message: dict[str, Any] | None) -> dict[str, Any]:
    """Assemble one replay turn."""

    return {
        "turn_index": turn_index,
        "user_message": user_message,
        "assistant_message": assistant_message,
        "run": _turn_run(user_message, assistant_message),
        "diagnostics": _turn_diagnostics(user_message, assistant_message),
    }


def _build_turns(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Pair persisted user and assistant messages into replay turns."""

    turns: list[dict[str, Any]] = []
    pending_user: dict[str, Any] | None = None
    for message in messages:
        role = str(message.get("role") or "").strip()
        if role == "user":
            if pending_user is not None:
                turns.append(_build_turn(len(turns) + 1, pending_user, None))
            pending_user = message
            continue
        if role == "assistant":
            turns.append(_build_turn(len(turns) + 1, pending_user, message))
            pending_user = None
    if pending_user is not None:
        turns.append(_build_turn(len(turns) + 1, pending_user, None))
    return turns


def _replay_diagnostics(messages: list[dict[str, Any]], turns: list[dict[str, Any]]) -> dict[str, Any]:
    """Summarize replay-level review coverage."""

    field_counts = {
        field: sum(1 for message in messages if _has_value(message.get(field)))
        for field in (*_TRACE_FIELDS, "thinking_trace", "run_id")
    }
    return {
        "message_count": len(messages),
        "turn_count": len(turns),
        "trace_field_counts": field_counts,
        "reviewable_turn_indexes": [
            turn["turn_index"]
            for turn in turns
            if turn["diagnostics"]["strategy_fields"] or turn["diagnostics"]["review_hints"]
        ],
    }


def build_session_replay(*, session_id: str) -> dict[str, Any] | None:
    """Build a read-only replay projection for a session."""

    session = get_session(session_id=session_id)
    if session is None:
        return None
    messages = list_messages(session_id=session_id)
    turns = _build_turns(messages)
    return {
        "session": session,
        "messages": messages,
        "turns": turns,
        "diagnostics": _replay_diagnostics(messages, turns),
    }
