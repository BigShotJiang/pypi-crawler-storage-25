"""Database-backed user scope lookup for local FLARE resource records."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any


def _now_iso() -> str:
    """Build the current UTC timestamp for persisted User records.

    Returns:
        ISO-formatted UTC timestamp string.
    """

    return datetime.now(UTC).isoformat()


def ensure_user_table(conn: Any, text_fn: Any) -> None:
    """Create the durable User table when it does not exist.

    Args:
        conn: Active SQLAlchemy connection or transaction connection.
        text_fn: SQLAlchemy text factory used by the caller's SQL boundary.

    Returns:
        None. The table is created as a database side effect.
    """

    conn.execute(
        text_fn(
            """
            CREATE TABLE IF NOT EXISTS flare_users (
                user_id TEXT PRIMARY KEY,
                user_name TEXT NOT NULL,
                status TEXT NOT NULL,
                is_current INTEGER NOT NULL DEFAULT 0,
                created_at TEXT,
                updated_at TEXT
            )
            """
        )
    )


def ensure_demo_user(conn: Any, text_fn: Any) -> None:
    """Seed the local demo user row when the user table has no current user.

    Args:
        conn: Active SQLAlchemy connection or transaction connection.
        text_fn: SQLAlchemy text factory used by the caller's SQL boundary.

    Returns:
        None. A demo user row is inserted only when no current user exists.
    """

    now = _now_iso()
    conn.execute(
        text_fn(
            """
            INSERT INTO flare_users (
                user_id, user_name, status, is_current, created_at, updated_at
            )
            SELECT
                'demo_user', 'Demo User', 'active', 1, :created_at, :updated_at
            WHERE NOT EXISTS (
                SELECT 1
                FROM flare_users
                WHERE is_current = 1
            )
            """
        ),
        {"created_at": now, "updated_at": now},
    )


def get_current_user_id(conn: Any, text_fn: Any) -> str:
    """Read the current resource owner user_id from the database.

    Args:
        conn: Active SQLAlchemy connection or transaction connection.
        text_fn: SQLAlchemy text factory used by the caller's SQL boundary.

    Returns:
        Current active user_id stored in flare_users.

    Raises:
        RuntimeError: When no current user row can be resolved.
    """

    ensure_user_table(conn, text_fn)
    ensure_demo_user(conn, text_fn)
    row = conn.execute(
        text_fn(
            """
            SELECT user_id
            FROM flare_users
            WHERE is_current = 1 AND status = 'active'
            ORDER BY updated_at DESC
            LIMIT 1
            """
        )
    ).mappings().first()
    user_id = str(dict(row or {}).get("user_id") or "").strip()
    if not user_id:
        raise RuntimeError("current user is unavailable for resource storage")
    return user_id
