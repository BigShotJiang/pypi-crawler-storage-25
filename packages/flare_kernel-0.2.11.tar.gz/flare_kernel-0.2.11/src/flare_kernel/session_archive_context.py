"""Archive context patch assembly for lifecycle transitions.

DOC HELPER — OBJ-06B context writeback boundary:

This module is the smallest bridge between lifecycle orchestration and archive
summary assembly. It returns a new context dict with `archive_summary` attached;
it does not save anything by itself.

Why keep this separate from session_store:
- session_store already owns session orchestration and repository calls.
- archive_summary assembly is reusable and testable without repository state.
- this bridge makes the lifecycle writeback point easy to remove or replace.

What this file must not do:
- No repository access.
- No lifecycle policy decision; callers decide whether archive is happening.
- No mutation of Project Memory or global knowledge stores.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.session_archive_summary import build_session_archive_summary


def attach_archive_summary(
    *,
    session: dict[str, Any],
    messages: list[dict[str, Any]],
    created_at: str | None = None,
) -> dict[str, Any]:
    """Return session context with deterministic archive summary attached."""

    context = session.get("context") if isinstance(session.get("context"), dict) else {}
    next_context = dict(context)
    next_session = dict(session)
    next_session["context"] = next_context
    next_context["archive_summary"] = build_session_archive_summary(
        session=next_session,
        messages=messages,
        created_at=created_at,
    )
    return next_context


__all__ = ["attach_archive_summary"]
