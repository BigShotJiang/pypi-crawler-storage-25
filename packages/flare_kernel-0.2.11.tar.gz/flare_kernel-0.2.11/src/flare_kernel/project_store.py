"""Project repository backed by FLARE SQL storage."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine
from flare_kernel.session_store import list_sessions
from flare_kernel.user_store import get_current_user_id


def _now_iso() -> str:
    """Build the current UTC timestamp for persisted Project records.

    Returns:
        ISO-formatted UTC timestamp string.
    """

    return datetime.now(UTC).isoformat()


def _normalize_text(value: Any) -> str:
    """Normalize a Project text value before storage or response projection.

    Args:
        value: Raw text-like value from API input or persisted storage.

    Returns:
        Whitespace-collapsed string, or an empty string when value is missing.
    """

    return " ".join(str(value or "").split()).strip()


def _ensure_project_table(conn: Any, text_fn: Any) -> None:
    """Create the durable Project table when it does not exist.

    Args:
        conn: Active SQLAlchemy connection or transaction connection.
        text_fn: SQLAlchemy text factory used by the caller's SQL boundary.

    Returns:
        None. The table is created as a database side effect.
    """

    conn.execute(
        text_fn(
            """
            CREATE TABLE IF NOT EXISTS flare_projects (
                project_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                project_name TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT,
                updated_at TEXT,
                PRIMARY KEY (user_id, project_id)
            )
            """
        )
    )


def _build_project_view(record: dict[str, Any]) -> dict[str, Any]:
    """Project a stored Project row into the Project API response shape.

    Args:
        record: Persisted Project row with project_id, project_name, status, and timestamps.

    Returns:
        Dictionary matching ProjectRecord fields, including derived session_count and latest_updated_at.
    """

    project_id = _normalize_text(record.get("project_id"))
    session_rows = list_sessions(project_id=project_id)
    latest_updated_at = ""
    if session_rows:
        latest_updated_at = str(session_rows[0].get("updated_at") or "").strip()
    updated_at = _normalize_text(record.get("updated_at")) or latest_updated_at or _normalize_text(record.get("created_at"))
    return {
        "project_id": project_id,
        "project_name": _normalize_text(record.get("project_name")) or project_id,
        "status": _normalize_text(record.get("status")) or "active",
        "session_count": len(session_rows),
        "created_at": _normalize_text(record.get("created_at")) or None,
        "updated_at": updated_at or None,
        "latest_updated_at": latest_updated_at or updated_at or None,
    }


def _project_engine() -> Any:
    """Resolve the SQLAlchemy engine required by Project persistence.

    Returns:
        SQLAlchemy Engine configured from FLARE_POSTGRES_DSN.

    Raises:
        RuntimeError: When SQLAlchemy or the configured engine is unavailable.
    """

    engine = build_sqlalchemy_engine()
    if engine is None:
        raise RuntimeError("SQLAlchemy engine is unavailable for project storage")
    return engine


def list_projects() -> list[dict[str, Any]]:
    """List durable Projects for the current database user scope.

    Returns:
        Project view dictionaries sorted by persisted updated_at descending.
    """

    from sqlalchemy import text

    with _project_engine().begin() as conn:
        _ensure_project_table(conn, text)
        user_id = get_current_user_id(conn, text)
        rows = conn.execute(
            text(
                """
                SELECT project_id, user_id, project_name, status, created_at, updated_at
                FROM flare_projects
                WHERE user_id = :user_id
                ORDER BY updated_at DESC
                """
            ),
            {"user_id": user_id},
        ).mappings().all()
    return [_build_project_view(dict(row)) for row in rows]


def get_project(*, project_id: str) -> dict[str, Any] | None:
    """Fetch one durable Project by id in the current database user scope.

    Args:
        project_id: Stable Project identifier to load.

    Returns:
        Project view dictionary when found, otherwise None.
    """

    resolved_project_id = _normalize_text(project_id)
    if not resolved_project_id:
        return None

    from sqlalchemy import text

    with _project_engine().begin() as conn:
        _ensure_project_table(conn, text)
        user_id = get_current_user_id(conn, text)
        row = conn.execute(
            text(
                """
                SELECT project_id, user_id, project_name, status, created_at, updated_at
                FROM flare_projects
                WHERE user_id = :user_id AND project_id = :project_id
                LIMIT 1
                """
            ),
            {"user_id": user_id, "project_id": resolved_project_id},
        ).mappings().first()
    return _build_project_view(dict(row)) if row else None


def upsert_project(*, project_id: str, project_name: str | None, status: str | None = None) -> dict[str, Any]:
    """Create or update a durable Project name and status.

    Args:
        project_id: Stable Project identifier to create or update.
        project_name: Optional Project display name; existing name is preserved when blank on update.
        status: Optional lifecycle status; existing status is preserved when blank on update.

    Returns:
        Project view dictionary after persistence.

    Raises:
        ValueError: When project_id is empty.
        RuntimeError: When the upsert does not produce a stored Project record.
    """

    resolved_project_id = _normalize_text(project_id)
    if not resolved_project_id:
        raise ValueError("project_id is required")

    now = _now_iso()
    next_project_name = _normalize_text(project_name)
    next_status = _normalize_text(status)

    from sqlalchemy import text

    with _project_engine().begin() as conn:
        _ensure_project_table(conn, text)
        user_id = get_current_user_id(conn, text)
        existing = conn.execute(
            text(
                """
                SELECT project_id, user_id, project_name, status, created_at, updated_at
                FROM flare_projects
                WHERE user_id = :user_id AND project_id = :project_id
                LIMIT 1
                """
            ),
            {"user_id": user_id, "project_id": resolved_project_id},
        ).mappings().first()
        if existing is None:
            conn.execute(
                text(
                    """
                    INSERT INTO flare_projects (
                        project_id, user_id, project_name, status, created_at, updated_at
                    ) VALUES (
                        :project_id, :user_id, :project_name, :status, :created_at, :updated_at
                    )
                    """
                ),
                {
                    "project_id": resolved_project_id,
                    "user_id": user_id,
                    "project_name": next_project_name or resolved_project_id,
                    "status": next_status or "active",
                    "created_at": now,
                    "updated_at": now,
                },
            )
        else:
            current = dict(existing)
            conn.execute(
                text(
                    """
                    UPDATE flare_projects
                    SET project_name = :project_name,
                        status = :status,
                        updated_at = :updated_at
                    WHERE user_id = :user_id AND project_id = :project_id
                    """
                ),
                {
                    "project_id": resolved_project_id,
                    "user_id": user_id,
                    "project_name": next_project_name or _normalize_text(current.get("project_name")) or resolved_project_id,
                    "status": next_status or _normalize_text(current.get("status")) or "active",
                    "updated_at": now,
                },
            )
    stored = get_project(project_id=resolved_project_id)
    if stored is None:
        raise RuntimeError("project upsert did not persist a project record")
    return stored
