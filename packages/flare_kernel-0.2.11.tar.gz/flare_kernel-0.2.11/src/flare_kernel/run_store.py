"""Canonical backend run state facade."""

from __future__ import annotations

import os
from datetime import UTC, datetime
from typing import Any

from flare_kernel.runtime.infrastructure.run import (
    InMemoryRunRepository,
    RunRepository,
    SqlAlchemyRunRepository,
)

ACTIVE_RUN_STATES = frozenset({"queued", "running"})
TERMINAL_RUN_STATES = frozenset({"completed", "failed", "cancelled"})


class RunAlreadyRunningError(ValueError):
    """Raised when a session already owns an active run."""

    def __init__(self, *, session_id: str, running_run_id: str) -> None:
        super().__init__("session already has an active run")
        self.session_id = session_id
        self.running_run_id = running_run_id


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _build_default_repository() -> RunRepository:
    if str(os.getenv("FLARE_POSTGRES_DSN") or "").strip():
        return SqlAlchemyRunRepository()
    return InMemoryRunRepository()


_repository: RunRepository = _build_default_repository()


def set_run_repository(repository: RunRepository) -> None:
    global _repository
    _repository = repository


def _active_session_run(session_id: str, run_id: str) -> dict[str, Any] | None:
    for record in _repository.list_session_runs(session_id):
        record_run_id = str(record.get("run_id") or "").strip()
        record_state = str(record.get("state") or "").strip()
        if record_run_id != run_id and record_state in ACTIVE_RUN_STATES:
            return record
    return None


def start_run(*, run_id: str, session_id: str, request_id: str = "", trace_id: str = "") -> dict[str, Any]:
    """Start a canonical run unless the same session already has one active.

    DOC HELPER — ORC-11 boundary.
    The run store owns same-session active-run protection; transports only map
    `RunAlreadyRunningError` to API/SSE errors.
    """

    resolved_run_id = str(run_id or "").strip()
    resolved_session_id = str(session_id or "").strip()
    if not resolved_run_id or not resolved_session_id:
        return {}
    existing = _repository.load_run_record(resolved_run_id)
    active_run = _active_session_run(resolved_session_id, resolved_run_id)
    if active_run is not None:
        raise RunAlreadyRunningError(
            session_id=resolved_session_id,
            running_run_id=str(active_run.get("run_id") or ""),
        )
    created_at = str((existing or {}).get("created_at") or _now_iso())
    record = {
        "run_id": resolved_run_id,
        "session_id": resolved_session_id,
        "request_id": str(request_id or ""),
        "trace_id": str(trace_id or ""),
        "state": "running",
        "error": "",
        "created_at": created_at,
        "started_at": str((existing or {}).get("started_at") or created_at),
        "completed_at": "",
        "updated_at": _now_iso(),
    }
    try:
        return _repository.save_run_record(record)
    except Exception:
        active_after_conflict = _active_session_run(resolved_session_id, resolved_run_id)
        if active_after_conflict is not None:
            raise RunAlreadyRunningError(
                session_id=resolved_session_id,
                running_run_id=str(active_after_conflict.get("run_id") or ""),
            )
        raise


def get_run(*, run_id: str) -> dict[str, Any] | None:
    return _repository.load_run_record(str(run_id or "").strip())


def list_session_runs(*, session_id: str) -> list[dict[str, Any]]:
    return _repository.list_session_runs(str(session_id or "").strip())


def list_run_events(*, run_id: str) -> list[dict[str, Any]]:
    return _repository.list_run_events(str(run_id or "").strip())


def _terminal_state(event_name: str, payload: dict[str, Any]) -> str:
    if str(event_name or "").strip() != "complete":
        return ""
    status = str(payload.get("status") or "").strip().lower()
    return "failed" if status in {"error", "failed"} else "completed"


def _update_terminal_state(*, run_id: str, event_name: str, payload: dict[str, Any]) -> None:
    next_state = _terminal_state(event_name, payload)
    if not next_state:
        return
    existing = _repository.load_run_record(run_id)
    if not existing or str(existing.get("state") or "") in TERMINAL_RUN_STATES:
        return
    now = _now_iso()
    record = {
        **existing,
        "state": next_state,
        "error": str(payload.get("message") or "") if next_state == "failed" else "",
        "completed_at": now,
        "updated_at": now,
    }
    _repository.save_run_record(record)


def record_run_event(*, event_name: str, payload: dict[str, Any]) -> dict[str, Any] | None:
    resolved_payload = payload if isinstance(payload, dict) else {}
    run_id = str(resolved_payload.get("run_id") or "").strip()
    session_id = str(resolved_payload.get("session_id") or "").strip()
    if not run_id or not session_id:
        return None
    sequence = int(resolved_payload.get("run_event_sequence") or 0)
    record = {
        "event_id": f"{run_id}:{sequence}",
        "run_id": run_id,
        "session_id": session_id,
        "request_id": str(resolved_payload.get("request_id") or ""),
        "event_name": str(event_name or ""),
        "sequence": sequence,
        "payload": dict(resolved_payload),
        "created_at": str(resolved_payload.get("ts") or _now_iso()),
    }
    stored = _repository.append_run_event(record)
    _update_terminal_state(run_id=run_id, event_name=event_name, payload=resolved_payload)
    return stored


def reset_run_store_for_testing() -> None:
    global _repository
    _repository = InMemoryRunRepository()
