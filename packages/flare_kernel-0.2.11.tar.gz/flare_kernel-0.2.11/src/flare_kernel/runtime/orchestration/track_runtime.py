"""Kernel runtime adapter for track reasoning."""

from __future__ import annotations

from typing import Any

from flare_engines import run_track_reasoning


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _document_context_from_refs(items: Any, *, source: str) -> list[dict[str, Any]]:
    documents: list[dict[str, Any]] = []
    for index, item in enumerate(_as_list(items), start=1):
        payload = item if isinstance(item, dict) else {"source_id": item}
        source_id = _clean_text(payload.get("source_id") or payload.get("id") or payload.get("sourceId"))
        title = _clean_text(payload.get("title") or payload.get("name") or payload.get("filename"))
        summary = _clean_text(payload.get("summary") or payload.get("snippet") or title or source_id)
        if not source_id and not summary:
            continue
        documents.append(
            {
                "source_id": source_id or f"{source}:{index}",
                "title": title,
                "summary": summary,
                "source": source,
            }
        )
    return documents


def _resolve_document_context(*, payload: dict[str, Any], session_context: dict[str, Any]) -> list[dict[str, Any]]:
    documents = [
        item
        for item in _as_list(session_context.get("artifact_context"))
        if isinstance(item, dict)
    ]
    documents.extend(_document_context_from_refs(payload.get("knowledge_refs"), source="knowledge_ref"))
    documents.extend(_document_context_from_refs(payload.get("context_refs"), source="context_ref"))
    return documents


def _resolve_track_domain_hints(*, payload: dict[str, Any], domain_pack: dict[str, Any]) -> dict[str, Any]:
    payload_config = payload.get("track_reasoning") if isinstance(payload.get("track_reasoning"), dict) else {}
    payload_track = payload.get("track") if isinstance(payload.get("track"), dict) else {}
    if not payload_track:
        payload_track = payload.get("workflow_track") if isinstance(payload.get("workflow_track"), dict) else {}
    workflow = _coerce_mapping(domain_pack.get("workflow"))
    workflow_config = workflow.get("track_reasoning") if isinstance(workflow.get("track_reasoning"), dict) else {}
    workflow_tracks = workflow.get("tracks") if isinstance(workflow.get("tracks"), list) else []
    hints = {**workflow_config, **payload_config}
    if workflow_tracks and "tracks" not in hints:
        hints["tracks"] = workflow_tracks
    if payload_track:
        hints["track"] = payload_track
    return hints


def build_track_runtime(
    *,
    session_id: str,
    payload: dict[str, Any],
    session_context: dict[str, Any],
    domain_pack: dict[str, Any],
    mode_runtime: dict[str, Any],
) -> dict[str, Any]:
    message = _clean_text(payload.get("message") or payload.get("user_message"))
    existing_track = session_context.get("track") if isinstance(session_context.get("track"), dict) else {}
    result = run_track_reasoning(
        {
            "track_id": _clean_text(existing_track.get("track_id")),
            "user_message": message,
            "session_context": session_context,
            "document_context": _resolve_document_context(payload=payload, session_context=session_context),
            "existing_track": existing_track,
            "domain_hints": _resolve_track_domain_hints(payload=payload, domain_pack=domain_pack),
        }
    )
    return {
        **result,
        "runtime": {
            "session_id": session_id,
            "mode_key": _clean_text(mode_runtime.get("mode_key")),
            "source": "track_reasoning_engine",
        },
    }


__all__ = ["build_track_runtime"]
