"""Kernel runtime adapter for response strategy normalization."""

from __future__ import annotations

from typing import Any

from flare_engines import run_response_strategy


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _resolve_domain_strategy(domain_pack: dict[str, Any]) -> dict[str, Any]:
    workflow = _coerce_mapping(domain_pack.get("workflow"))
    workflow_strategy = workflow.get("response_strategy")
    if isinstance(workflow_strategy, dict):
        return workflow_strategy
    strategy = domain_pack.get("response_strategy")
    return strategy if isinstance(strategy, dict) else {}


def _stamp_registry(raw: Any, source: str) -> list[dict[str, Any]]:
    if isinstance(raw, dict):
        raw = raw.get("response_shape_registry") or raw.get("shapes") or raw.get("items")
    if not isinstance(raw, list):
        return []
    stamped: list[dict[str, Any]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        stamped.append({**item, "source": source})
    return stamped


def _resolve_shape_registry(
    *,
    payload: dict[str, Any],
    domain_pack: dict[str, Any],
    instance_profile: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    profile = _coerce_mapping(instance_profile)
    profile_strategy = _coerce_mapping(profile.get("response_strategy"))
    workflow = _coerce_mapping(domain_pack.get("workflow"))
    candidates = (
        (payload.get("response_shape_registry"), "payload"),
        (profile.get("response_shape_registry"), "instance_profile"),
        (profile_strategy.get("response_shape_registry"), "instance_profile"),
        (workflow.get("response_shape_registry"), "domain_pack"),
        (domain_pack.get("response_shape_registry"), "domain_pack"),
    )
    for raw, source in candidates:
        registry = _stamp_registry(raw, source)
        if registry:
            return registry
    return []


def build_response_strategy_runtime(
    *,
    payload: dict[str, Any],
    domain_pack: dict[str, Any],
    instance_profile: dict[str, Any] | None = None,
    mode_runtime: dict[str, Any],
    track_result: dict[str, Any],
) -> dict[str, Any]:
    payload_strategy = payload.get("response_strategy") if isinstance(payload.get("response_strategy"), dict) else {}
    result = run_response_strategy(
        {
            "payload_strategy": payload_strategy,
            "domain_strategy": _resolve_domain_strategy(domain_pack),
            "response_shape_registry": _resolve_shape_registry(
                payload=payload,
                domain_pack=domain_pack,
                instance_profile=instance_profile,
            ),
            "track_result": track_result,
            "response_intent_result": payload.get("response_intent_result")
            if isinstance(payload.get("response_intent_result"), dict)
            else {},
            "mode_key": _clean_text(mode_runtime.get("mode_key")),
        }
    )
    return {
        **result,
        "runtime": {
            "mode_key": _clean_text(mode_runtime.get("mode_key")),
            "source": "response_strategy_engine",
        },
    }


__all__ = ["build_response_strategy_runtime"]
