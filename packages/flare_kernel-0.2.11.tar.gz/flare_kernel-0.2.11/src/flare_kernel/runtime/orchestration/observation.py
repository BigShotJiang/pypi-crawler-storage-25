"""Structured observation logs for runtime and session artifacts."""

from __future__ import annotations

import json
from typing import Any

from flare_kernel.runtime.infrastructure.logging import get_logger

logger = get_logger("flare_kernel.runtime.orchestration.observation")


def _object_keys(value: Any) -> list[str]:
    if not isinstance(value, dict):
        return []
    return sorted(str(key) for key in value.keys())


def _event_types(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    event_types: list[str] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        event_type = str(item.get("event_type") or "").strip()
        if event_type:
            event_types.append(event_type)
    return event_types


def _current_question_from_payload(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    question = value.get("current_question")
    if isinstance(question, dict):
        return dict(question)
    return None


def _current_question_from_events(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, list):
        return None
    for item in value:
        if not isinstance(item, dict):
            continue
        payload = item.get("payload")
        question = _current_question_from_payload(payload)
        if question:
            return question
    return None


def _write_info(event_name: str, payload: dict[str, Any]) -> None:
    logger.info(
        "%s %s",
        event_name,
        json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str),
    )


def log_kernel_runtime_generated(
    *,
    trace_id: str,
    session_id: str,
    function_type: str | None,
    mode_runtime: dict[str, Any],
    context_usage: dict[str, Any],
    reasoning_result: dict[str, Any],
    track_result: dict[str, Any],
    response_strategy_result: dict[str, Any],
    mode_orchestration: dict[str, Any],
) -> None:
    mode_events = mode_orchestration.get("mode_events")
    current_question = (
        _current_question_from_payload(track_result)
        or _current_question_from_events(mode_events)
    )
    _write_info(
        "kernel.runtime.generated",
        {
            "trace_id": trace_id,
            "session_id": session_id,
            "function_type": function_type,
            "mode_key": mode_runtime.get("mode_key"),
            "mode_state": mode_runtime.get("mode_state"),
            "context_usage_keys": _object_keys(context_usage),
            "reasoning_keys": _object_keys(reasoning_result),
            "track_keys": _object_keys(track_result),
            "response_strategy_keys": _object_keys(response_strategy_result),
            "mode_event_types": _event_types(mode_events),
            "current_question": current_question,
        },
    )


def log_session_append_persisted(
    *,
    session_id: str,
    user_message: str,
    assistant_message: str,
    plan_payload: dict[str, Any] | None,
) -> None:
    _write_info(
        "session.exchange.appended",
        {
            "session_id": session_id,
            "has_user_message": bool(str(user_message or "").strip()),
            "has_assistant_message": bool(str(assistant_message or "").strip()),
            "has_plan_payload": isinstance(plan_payload, dict) and bool(plan_payload),
            "plan_payload_keys": _object_keys(plan_payload),
            "current_question": _current_question_from_payload(plan_payload),
        },
    )


__all__ = ["log_kernel_runtime_generated", "log_session_append_persisted"]
