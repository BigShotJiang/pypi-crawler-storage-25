"""Analysis route policy loader.

DOC HELPER — ANL-03 route policy boundary.
This module adapts the analysis routing contract into the engine policy shape.
It reads routing hints from explicit payload/config files and does not hardcode
business terms in reusable runtime code.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

_ROUTING_CONTRACT_RELATIVE_PATH = Path("docs/contracts/analysis/routing.yaml")


def _resolve_project_root() -> Path | None:
    current = Path(__file__).resolve()
    for parent in current.parents:
        candidate = parent / _ROUTING_CONTRACT_RELATIVE_PATH
        if candidate.exists():
            return parent
    return None


def _as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _clean_list(value: Any) -> list[str]:
    result: list[str] = []
    for item in _as_list(value):
        text = _clean_text(item)
        if text and text not in result:
            result.append(text)
    return result


def _safe_load_yaml(text: str) -> dict[str, Any]:
    try:
        import yaml  # type: ignore
    except Exception:
        return {}
    try:
        parsed = yaml.safe_load(text)
    except Exception:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _strip_scalar(value: str) -> str:
    text = _clean_text(value)
    if text.startswith(("'", '"')) and text.endswith(("'", '"')) and len(text) >= 2:
        return text[1:-1].strip()
    return text


def _parse_fallback_routing_contract(text: str) -> dict[str, Any]:
    default_analysis_type = ""
    sourcing_hints: list[str] = []
    requirement_hints: list[str] = []
    active_hint_key = ""
    has_sourcing_rule = False
    for raw_line in str(text or "").splitlines():
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("default_analysis_type:"):
            default_analysis_type = _strip_scalar(stripped.split(":", 1)[1])
            active_hint_key = ""
            continue
        if stripped.startswith("sourcing_hints:"):
            active_hint_key = "sourcing"
            continue
        if stripped.startswith("requirement_hints:"):
            active_hint_key = "requirement"
            continue
        if stripped.startswith("analysis_type:") and _strip_scalar(stripped.split(":", 1)[1]) == "sourcing":
            has_sourcing_rule = True
            active_hint_key = ""
            continue
        if stripped.startswith("- ") and active_hint_key:
            value = _strip_scalar(stripped[2:])
            if active_hint_key == "sourcing" and value:
                sourcing_hints.append(value)
            if active_hint_key == "requirement" and value:
                requirement_hints.append(value)
    return {
        "routing": {
            "default_analysis_type": default_analysis_type,
            "signals": {
                "intent": {
                    "sourcing_hints": sourcing_hints,
                    "requirement_hints": requirement_hints,
                }
            },
            "rules": [{"then": {"analysis_type": "sourcing"}}] if has_sourcing_rule else [],
        }
    }


def _contract_to_policy(contract: dict[str, Any]) -> dict[str, Any]:
    routing = _as_dict(contract.get("routing"))
    signals = _as_dict(routing.get("signals"))
    intent = _as_dict(signals.get("intent"))
    sourcing_hints = _clean_list(intent.get("sourcing_hints"))
    requirement_hints = _clean_list(intent.get("requirement_hints"))
    policy: dict[str, Any] = {
        "analysis_type_terms": {
            "sourcing": sourcing_hints,
            "requirement": requirement_hints,
        },
        "default_analysis_type": _clean_text(routing.get("default_analysis_type")) or "requirement",
    }
    sourcing_rules = [
        rule
        for rule in _as_list(routing.get("rules"))
        if _clean_text(_as_dict(_as_dict(rule).get("then")).get("analysis_type")) == "sourcing"
    ]
    if sourcing_rules:
        policy["candidate_pool_analysis_type"] = "sourcing"
        policy["evidence_analysis_type"] = "sourcing"
    return policy


@lru_cache(maxsize=1)
def load_default_analysis_route_policy() -> dict[str, Any]:
    root = _resolve_project_root()
    if root is None:
        return {}
    path = root / _ROUTING_CONTRACT_RELATIVE_PATH
    text = path.read_text(encoding="utf-8")
    contract = _safe_load_yaml(text) or _parse_fallback_routing_contract(text)
    return _contract_to_policy(contract)


def resolve_analysis_route_policy(payload: dict[str, Any]) -> dict[str, Any]:
    for key in ("analysis_route_policy", "analysis_policy"):
        policy = payload.get(key)
        if isinstance(policy, dict):
            return policy
    return load_default_analysis_route_policy()


__all__ = ["load_default_analysis_route_policy", "resolve_analysis_route_policy"]
