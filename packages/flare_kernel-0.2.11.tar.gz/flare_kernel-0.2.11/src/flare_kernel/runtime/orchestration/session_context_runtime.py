"""Session context projection for kernel runtime orchestration."""

from __future__ import annotations

from typing import Any


def load_session_context_snapshot(session_id: str) -> dict[str, Any]:
    resolved_session_id = str(session_id or "").strip()
    if not resolved_session_id:
        return {}
    from flare_kernel.session_store import get_session

    session = get_session(session_id=resolved_session_id)
    if not isinstance(session, dict):
        return {}
    context = session.get("context")
    return context if isinstance(context, dict) else {}


__all__ = ["load_session_context_snapshot"]
