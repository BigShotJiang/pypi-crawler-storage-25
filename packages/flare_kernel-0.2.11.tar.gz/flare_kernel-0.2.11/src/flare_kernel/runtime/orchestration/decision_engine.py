"""Decision engine for orchestration stage transitions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class StageTransition:
    from_stage: str
    to_stage: str
    trigger: str

    def to_dict(self) -> dict[str, str]:
        return {
            "from": self.from_stage,
            "to": self.to_stage,
            "trigger": self.trigger,
        }


@dataclass(frozen=True)
class DecisionBasis:
    rule_id: str
    conclusion: str
    confidence: float
    evidence: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "conclusion": self.conclusion,
            "confidence": max(0.0, min(1.0, float(self.confidence))),
            "evidence": [item for item in self.evidence if str(item).strip()],
        }


@dataclass(frozen=True)
class DecisionContext:
    resolved_intent: str
    resolved_mode: str
    mode_state: str
    required_missing: tuple[str, ...]
    base_next_actions: tuple[dict[str, Any], ...]
    current_question: dict[str, Any] | None
    retrieval_attempted: bool
    retrieval_hit_count: int
    chooser: dict[str, Any] | None
    target_field: str
    pack_workflow: dict[str, Any] | None
    pack_field_policies: dict[str, Any] | None
    pack_blocker_policies: dict[str, Any] | None
    pack_search_mapping: dict[str, Any] | None
    degrade_reasons: tuple[str, ...]


@dataclass(frozen=True)
class OrchestrationDecision:
    next_stage: str
    stage_transition: StageTransition
    decision_basis: tuple[DecisionBasis, ...]
    chooser_required: bool
    blocking_reason: str
    next_actions: tuple[dict[str, Any], ...]
    degrade_reason: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "next_stage": self.next_stage,
            "stage_transition": self.stage_transition.to_dict(),
            "decision_basis": [item.to_dict() for item in self.decision_basis],
            "chooser_required": self.chooser_required,
            "blocking_reason": self.blocking_reason,
            "next_actions": [dict(item) for item in self.next_actions],
            "degrade_reason": [item for item in self.degrade_reason if str(item).strip()],
        }


def _infer_stage_from_mode(mode_key: str, mode_state: str) -> str:
    normalized_mode = str(mode_key or "").strip()
    normalized_state = str(mode_state or "").strip()
    if normalized_mode == "intelligent_sourcing":
        return "sourcing.running"
    if normalized_mode == "requirement_intake":
        if normalized_state == "collecting":
            return "requirement_intake.collecting"
        if normalized_state in {"drafting", "ready_for_submit"}:
            return "requirement_intake.ready_for_submit"
    return "requirement_analysis.ready"


def _pick_next_action_from_actions(actions: tuple[dict[str, Any], ...]) -> dict[str, Any]:
    available = [
        item
        for item in actions
        if isinstance(item, dict) and str(item.get("status") or "").strip().lower() != "blocked"
    ]
    selected = available[0] if available else (actions[0] if actions else {})
    if not isinstance(selected, dict):
        selected = {}
    return {
        "action_key": str(selected.get("action_key") or selected.get("type") or "").strip(),
        "reason": str(selected.get("reason") or "").strip(),
        "target_mode": str(selected.get("target_mode") or "").strip(),
        "target_field": str(selected.get("target_field") or "").strip(),
    }


def _resolve_next_actions(
    *,
    base_actions: tuple[dict[str, Any], ...],
    next_stage: str,
    chooser_required: bool,
    blocking_reason: str,
    target_field: str,
) -> tuple[dict[str, Any], ...]:
    actions: list[dict[str, Any]] = [dict(item) for item in base_actions if isinstance(item, dict)]
    indexed = {str(item.get("action_key") or item.get("type") or "").strip(): item for item in actions if isinstance(item, dict)}

    if next_stage.startswith("requirement_intake"):
        continue_action = indexed.get("continue_collection")
        if isinstance(continue_action, dict):
            continue_action["status"] = "available"
            if chooser_required:
                continue_action["blocking_reason"] = blocking_reason
                continue_action["target_field"] = target_field
            elif next_stage == "requirement_intake.ready_for_submit":
                continue_action.pop("blocking_reason", None)
                continue_action.pop("target_field", None)

        if next_stage == "requirement_intake.ready_for_submit":
            confirm_action = indexed.get("confirm_plan")
            if isinstance(confirm_action, dict):
                confirm_action["status"] = "available"
                confirm_action["command"] = "generate_analysis"
                payload = confirm_action.get("payload")
                if isinstance(payload, dict):
                    payload = dict(payload)
                    payload["command"] = "generate_analysis"
                    confirm_action["payload"] = payload

    if next_stage.startswith("evidence_retrieval"):
        retrieval_action = indexed.get("investigate_evidence")
        if isinstance(retrieval_action, dict):
            retrieval_action["status"] = "available"

    if next_stage.startswith("sourcing"):
        handoff_action = indexed.get("handoff_to_sourcing")
        if isinstance(handoff_action, dict):
            handoff_action["status"] = "available"

    actions.sort(key=lambda item: int(item.get("priority") or 99))
    return tuple(actions[:3])


def _resolve_pack_stage_actions(pack_workflow: dict[str, Any] | None, stage_key: str) -> tuple[dict[str, Any], ...]:
    if not isinstance(pack_workflow, dict):
        return ()
    stages = pack_workflow.get("stages")
    if not isinstance(stages, dict):
        return ()
    stage_node = stages.get(stage_key)
    if not isinstance(stage_node, dict):
        return ()
    actions = stage_node.get("next_actions")
    if not isinstance(actions, list):
        return ()
    normalized = [dict(item) for item in actions if isinstance(item, dict)]
    return tuple(normalized)


def _resolve_effective_missing_fields(
    *,
    required_missing: tuple[str, ...],
    pack_field_policies: dict[str, Any] | None,
    pack_blocker_policies: dict[str, Any] | None,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    if not required_missing:
        return (), ()

    if not isinstance(pack_field_policies, dict) or not pack_field_policies:
        return required_missing, ()

    blocker_fields: set[str] = set()
    if isinstance(pack_blocker_policies, dict):
        raw_required = pack_blocker_policies.get("required_fields")
        if isinstance(raw_required, list):
            blocker_fields = {str(item).strip() for item in raw_required if str(item).strip()}

    if not blocker_fields:
        for key, node in pack_field_policies.items():
            if not isinstance(node, dict):
                continue
            if bool(node.get("blocker")):
                blocker_fields.add(str(key).strip())

    effective: list[str] = []
    ignored: list[str] = []
    for field in required_missing:
        if field in blocker_fields:
            effective.append(field)
        else:
            ignored.append(field)
    return tuple(effective), tuple(ignored)


def _search_mapping_for_field(pack_search_mapping: dict[str, Any] | None, target_field: str) -> bool:
    if not target_field:
        return False
    if not isinstance(pack_search_mapping, dict):
        return False
    if target_field in pack_search_mapping:
        return True
    field_mapping = pack_search_mapping.get("field_mapping")
    if isinstance(field_mapping, dict) and target_field in field_mapping:
        return True
    mappings = pack_search_mapping.get("mappings")
    if isinstance(mappings, dict) and target_field in mappings:
        return True
    return False


def evaluate_orchestration_decision(context: DecisionContext) -> OrchestrationDecision:
    missing_fields = tuple(item for item in context.required_missing if str(item).strip())
    effective_missing, ignored_missing = _resolve_effective_missing_fields(
        required_missing=missing_fields,
        pack_field_policies=context.pack_field_policies,
        pack_blocker_policies=context.pack_blocker_policies,
    )
    has_required_missing = len(effective_missing) > 0
    next_stage = "requirement_intake.ready_for_submit"
    trigger = "requirements_ready"
    blocking_reason = ""
    degrade_reasons: list[str] = [item for item in context.degrade_reasons if str(item).strip()]
    basis: list[DecisionBasis] = []

    selected_next_action = _pick_next_action_from_actions(context.base_next_actions)
    selected_action_key = str(selected_next_action.get("action_key") or "").strip()

    workflow_missing = any(item == "workflow_missing" for item in degrade_reasons)
    if workflow_missing and has_required_missing:
        next_stage = "requirement_intake.collecting"
        trigger = "required_fields_missing"
        blocking_reason = "建议继续补充关键字段，以提高后续分析质量。"
        basis.append(
            DecisionBasis(
                rule_id="rule_workflow_missing",
                conclusion="流程配置缺失，按字段阻塞策略降级运行。",
                confidence=0.82,
                evidence=tuple(item for item in degrade_reasons if item == "workflow_missing"),
            )
        )
        basis.append(
            DecisionBasis(
                rule_id="rule_required_fields_missing",
                conclusion="关键字段未补齐，维持在需求梳理阶段。",
                confidence=0.96,
                evidence=(f"required_missing={','.join(effective_missing)}",),
            )
        )
    elif workflow_missing:
        next_stage = "requirement_intake.ready_for_submit"
        trigger = "workflow_missing"
        basis.append(
            DecisionBasis(
                rule_id="rule_workflow_missing",
                conclusion="流程配置缺失，降级为需求分析待继续。",
                confidence=0.82,
                evidence=tuple(item for item in degrade_reasons if item == "workflow_missing"),
            )
        )
    elif selected_action_key == "investigate_evidence":
        target_field = str(context.target_field or "").strip()
        if not target_field:
            next_stage = "requirement_intake.collecting"
            trigger = "target_field_missing"
            blocking_reason = "检索需要先确认目标字段。"
            degrade_reasons.append("target_field_missing")
            basis.append(
                DecisionBasis(
                    rule_id="rule_target_field_missing",
                    conclusion="检索动作缺少目标字段，降级为待字段确认。",
                    confidence=0.95,
                    evidence=("target_field=empty",),
                )
            )
        elif not _search_mapping_for_field(context.pack_search_mapping, target_field):
            next_stage = "requirement_analysis.ready"
            trigger = "retrieval_mapping_missing"
            degrade_reasons.append(f"retrieval_mapping_missing:{target_field}")
            basis.append(
                DecisionBasis(
                    rule_id="rule_retrieval_mapping_missing",
                    conclusion="缺少目标字段检索映射，跳过检索回到分析阶段。",
                    confidence=0.9,
                    evidence=(f"target_field={target_field}",),
                )
            )
        else:
            next_stage = "evidence_retrieval.running" if context.retrieval_attempted else "evidence_retrieval.ready"
            trigger = "next_action_investigate_evidence"
            basis.append(
                DecisionBasis(
                    rule_id="rule_next_action_evidence",
                    conclusion="编排动作要求先检索证据，切入检索阶段。",
                    confidence=0.9,
                    evidence=(
                        f"resolved_mode={context.resolved_mode}",
                        f"target_field={target_field}",
                        f"retrieval_attempted={str(context.retrieval_attempted).lower()}",
                        f"retrieval_hits={context.retrieval_hit_count}",
                    ),
                )
            )
    elif has_required_missing:
        next_stage = "requirement_intake.collecting"
        trigger = "required_fields_missing"
        blocking_reason = "建议继续补充关键字段，以提高后续分析质量。"
        basis.append(
            DecisionBasis(
                rule_id="rule_required_fields_missing",
                conclusion="关键字段未补齐，维持在需求梳理阶段。",
                confidence=0.96,
                evidence=(f"required_missing={','.join(effective_missing)}",),
            )
        )
    elif context.resolved_mode == "intelligent_sourcing" or context.resolved_intent == "intelligent_sourcing":
        next_stage = "sourcing.running"
        trigger = "mode_sourcing"
        basis.append(
            DecisionBasis(
                rule_id="rule_mode_sourcing",
                conclusion="路由已进入智能寻源，进入寻源执行阶段。",
                confidence=0.88,
                evidence=(
                    f"mode_state={context.mode_state or 'unknown'}",
                    f"resolved_intent={context.resolved_intent}",
                ),
            )
        )
    else:
        basis.append(
            DecisionBasis(
                rule_id="rule_requirements_ready",
                conclusion="关键字段已具备，进入下一步确认节点。",
                confidence=0.9,
                evidence=(f"required_missing_count={len(effective_missing)}",),
            )
        )

    if ignored_missing:
        degrade_reasons.extend(f"field_policy_missing:{field}" for field in ignored_missing)
        basis.append(
            DecisionBasis(
                rule_id="rule_field_policy_missing",
                conclusion="部分缺失字段无阻塞策略，已按字段降级忽略。",
                confidence=0.76,
                evidence=tuple(f"ignored_missing={field}" for field in ignored_missing),
            )
        )

    chooser_required = bool(
        next_stage.startswith("requirement_intake")
        and isinstance(context.current_question, dict)
        and bool((context.pack_blocker_policies or {}).get("chooser_on_blocking", True))
    )
    if chooser_required and not blocking_reason:
        blocking_reason = str((context.chooser or {}).get("blocking_reason") or "").strip() or "请先确认当前关键字段。"

    target_field = str(context.target_field or "").strip()
    if not target_field and isinstance(context.current_question, dict):
        target_field = str((context.current_question or {}).get("field_key") or "").strip()
    stage_key = next_stage.split(".", 1)[0]
    pack_stage_actions = _resolve_pack_stage_actions(context.pack_workflow, stage_key)
    action_source = pack_stage_actions if pack_stage_actions else context.base_next_actions
    next_actions = _resolve_next_actions(
        base_actions=action_source,
        next_stage=next_stage,
        chooser_required=chooser_required,
        blocking_reason=blocking_reason,
        target_field=target_field,
    )
    return OrchestrationDecision(
        next_stage=next_stage,
        stage_transition=StageTransition(
            from_stage=_infer_stage_from_mode(context.resolved_mode, context.mode_state),
            to_stage=next_stage,
            trigger=trigger,
        ),
        decision_basis=tuple(basis),
        chooser_required=chooser_required,
        blocking_reason=blocking_reason,
        next_actions=next_actions,
        degrade_reason=tuple(dict.fromkeys(item for item in degrade_reasons if str(item).strip())),
    )
