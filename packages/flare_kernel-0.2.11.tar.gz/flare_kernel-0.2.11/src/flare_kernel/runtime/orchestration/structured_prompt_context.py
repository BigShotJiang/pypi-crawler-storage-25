"""Prompt context assembly for structured reasoning."""

from __future__ import annotations

from typing import Any


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _coerce_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _compact_items(items: list[Any], *, limit: int) -> list[dict[str, str]]:
    compacted: list[dict[str, str]] = []
    for item in items:
        payload = item if isinstance(item, dict) else {"text": item}
        title = _clean_text(payload.get("title") or payload.get("label") or payload.get("id"))
        text = _clean_text(
            payload.get("snippet")
            or payload.get("summary")
            or payload.get("content")
            or payload.get("text")
        )
        if not title and not text:
            continue
        compacted.append({"title": title[:120], "text": text[:360]})
        if len(compacted) >= limit:
            break
    return compacted


def _compact_field_contracts(payload: dict[str, Any]) -> list[dict[str, Any]]:
    semantics = _coerce_mapping(payload.get("field_semantics"))
    contracts: list[dict[str, Any]] = []
    for item in _coerce_list(payload.get("field_definitions")):
        definition = _coerce_mapping(item)
        field_key = _clean_text(definition.get("key"))
        if not field_key:
            continue
        field_semantics = _coerce_mapping(semantics.get(field_key))
        contracts.append(
            {
                "key": field_key,
                "label": _clean_text(definition.get("label")) or field_key,
                "priority": _clean_text(definition.get("priority")),
                "blocker": bool(definition.get("blocker")),
                "value_type": _clean_text(field_semantics.get("value_type")),
            }
        )
    return contracts


def _compact_template_sections(raw_sections: Any) -> list[dict[str, str]]:
    compacted: list[dict[str, str]] = []
    for section in _coerce_list(raw_sections)[:8]:
        section_payload = _coerce_mapping(section)
        section_key = _clean_text(section_payload.get("key"))
        if not section_key:
            continue
        compacted.append(
            {
                "key": section_key,
                "label": _clean_text(section_payload.get("label"))[:80],
                "instruction": _clean_text(section_payload.get("instruction"))[:220],
            }
        )
    return compacted


def _compact_artifact_template_context(payload: dict[str, Any]) -> list[dict[str, Any]]:
    compacted: list[dict[str, Any]] = []
    for item in _coerce_list(payload.get("artifact_template_context")):
        template = _coerce_mapping(item)
        artifact_type = _clean_text(template.get("artifact_type"))
        if not artifact_type:
            continue
        compacted.append(
            {
                "artifact_type": artifact_type,
                "template": _clean_text(template.get("template"))[:120],
                "sections": _compact_template_sections(template.get("sections")),
            }
        )
    return compacted[:4]


def _resolve_missing_fields(payload: dict[str, Any]) -> list[str]:
    missing = [_clean_text(item) for item in _coerce_list(payload.get("required_missing"))]
    if missing:
        return [item for item in missing if item]
    known = _coerce_mapping(payload.get("fields"))
    return [
        item for item in (_clean_text(value) for value in _coerce_list(payload.get("required_fields")))
        if item and known.get(item) in (None, "", [], {})
    ]


def build_structured_prompt_context(
    *,
    message: str,
    mode_key: str,
    payload: dict[str, Any],
    retrieved_knowledge: list[dict[str, Any]],
    instance_profile: dict[str, Any] | None,
) -> dict[str, Any]:
    context = _coerce_mapping(payload.get("context") or payload.get("session_context"))
    return {
        "mode_key": mode_key,
        "message": _clean_text(message),
        "known_fields": _coerce_mapping(payload.get("fields")),
        "missing_fields": _resolve_missing_fields(payload),
        "field_contracts": _compact_field_contracts(payload),
        "artifact_template_context": _compact_artifact_template_context(payload),
        "context_summary": _clean_text(context.get("session_summary") or context.get("summary")),
        "retrieved_knowledge": _compact_items(retrieved_knowledge, limit=4),
        "instance_profile": _coerce_mapping(instance_profile),
    }


__all__ = ["build_structured_prompt_context"]
