"""Resolve canonical module prompt registry from backend-owned configuration."""

from __future__ import annotations

from typing import Any


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _normalize_text(value: Any) -> str:
    return str(value or "").strip()


def _normalize_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [_normalize_text(item) for item in value if _normalize_text(item)]


def _coerce_registry_entries(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    source = _coerce_mapping(value)
    for key in ("module_prompt_registry", "modulePromptRegistry", "module_prompts", "modules"):
        raw_entries = source.get(key)
        if isinstance(raw_entries, list):
            return [item for item in raw_entries if isinstance(item, dict)]
    return []


def _normalize_prompt_templates(entry: dict[str, Any]) -> list[dict[str, str]]:
    raw_templates = entry.get("prompt_templates") or entry.get("promptTemplates")
    if not isinstance(raw_templates, list):
        prompt = _normalize_text(entry.get("prompt"))
        return [{"key": "default", "label": "", "prompt": prompt}] if prompt else []

    templates: list[dict[str, str]] = []
    for index, raw_item in enumerate(raw_templates):
        item = _coerce_mapping(raw_item)
        prompt = _normalize_text(item.get("prompt") or item.get("text") or item.get("value"))
        if not prompt:
            continue
        templates.append(
            {
                "key": _normalize_text(item.get("key") or item.get("id")) or f"prompt-{index + 1}",
                "label": _normalize_text(item.get("label") or item.get("title")),
                "prompt": prompt,
            }
        )
    return templates


def _normalize_entry(entry: dict[str, Any]) -> dict[str, Any] | None:
    source = _coerce_mapping(entry)
    module_key = _normalize_text(
        source.get("module_key")
        or source.get("moduleKey")
        or source.get("key")
        or source.get("target_mode")
        or source.get("targetMode")
    )
    if not module_key:
        return None

    target_mode = _normalize_text(source.get("target_mode") or source.get("targetMode"))
    target_modes = _normalize_list(source.get("target_modes") or source.get("targetModes"))
    if target_mode and target_mode not in target_modes:
        target_modes = [target_mode, *target_modes]

    return {
        "module_key": module_key,
        "key": module_key,
        "label": _normalize_text(source.get("label")),
        "target_mode": target_mode,
        "trigger_keywords": _normalize_list(source.get("trigger_keywords") or source.get("triggerKeywords")),
        "action_text": _normalize_text(source.get("action_text") or source.get("actionText")),
        "reason": _normalize_text(source.get("reason") or source.get("description")),
        "action_commands": _normalize_list(source.get("action_commands") or source.get("actionCommands")),
        "target_modes": target_modes,
        "prompt_templates": _normalize_prompt_templates(source),
        "priority": float(source.get("priority") or 0),
    }


def _prefer_text(override_value: Any, base_value: Any) -> str:
    return _normalize_text(override_value) or _normalize_text(base_value)


def _merge_entry(base: dict[str, Any] | None, override: dict[str, Any]) -> dict[str, Any]:
    if not base:
        return dict(override)
    return {
        "module_key": _prefer_text(override.get("module_key"), base.get("module_key")),
        "key": _prefer_text(override.get("key"), base.get("key")),
        "label": _prefer_text(override.get("label"), base.get("label")),
        "target_mode": _prefer_text(override.get("target_mode"), base.get("target_mode")),
        "action_text": _prefer_text(override.get("action_text"), base.get("action_text")),
        "reason": _prefer_text(override.get("reason"), base.get("reason")),
        "priority": float(override.get("priority") or base.get("priority") or 0),
        "trigger_keywords": override.get("trigger_keywords") or base.get("trigger_keywords") or [],
        "action_commands": override.get("action_commands") or base.get("action_commands") or [],
        "target_modes": override.get("target_modes") or base.get("target_modes") or [],
        "prompt_templates": override.get("prompt_templates") or base.get("prompt_templates") or [],
    }


def _registry_sources(
    *,
    domain_pack: dict[str, Any] | None,
    instance_profile: dict[str, Any] | None,
    payload: dict[str, Any] | None,
) -> list[Any]:
    pack = _coerce_mapping(domain_pack)
    workflow = _coerce_mapping(pack.get("workflow"))
    return [
        workflow.get("module_prompt_registry"),
        workflow.get("module_prompts"),
        pack.get("module_prompt_registry"),
        _coerce_mapping(instance_profile).get("module_prompt_registry"),
        _coerce_mapping(payload),
    ]


def build_module_prompt_registry(
    *,
    domain_pack: dict[str, Any] | None,
    instance_profile: dict[str, Any] | None,
    payload: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    """Build a backend-canonical registry for module prompt/tip contracts."""

    registry: dict[str, dict[str, Any]] = {}
    for source in _registry_sources(
        domain_pack=domain_pack,
        instance_profile=instance_profile,
        payload=payload,
    ):
        for raw_entry in _coerce_registry_entries(source):
            entry = _normalize_entry(raw_entry)
            if not entry:
                continue
            registry[entry["module_key"]] = _merge_entry(registry.get(entry["module_key"]), entry)
    return sorted(registry.values(), key=lambda item: float(item.get("priority") or 0), reverse=True)
