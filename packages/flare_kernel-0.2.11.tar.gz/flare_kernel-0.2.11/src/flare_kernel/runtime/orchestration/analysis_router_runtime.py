"""Runtime bridge for analysis-route capability."""

from __future__ import annotations

from typing import Any

from flare_engines import resolve_analysis_route as resolve_analysis_route_from_engine
from flare_kernel.runtime.orchestration.analysis_route_policy import resolve_analysis_route_policy


def _coerce_non_negative_int(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


def _resolve_candidate_pool_count(payload: dict[str, Any]) -> int:
    count = _coerce_non_negative_int(payload.get("candidate_pool_count"))
    if count > 0:
        return count
    candidates = payload.get("sourcing_candidates")
    if isinstance(candidates, list):
        return len([item for item in candidates if isinstance(item, dict)])
    return 0


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _resolve_reason_codes(value: Any) -> list[str]:
    if not isinstance(value, list):
        return ["ROUTE_SIGNAL_EXPLICIT_PAYLOAD"]
    reason_codes = [_clean_text(item) for item in value if _clean_text(item)]
    return reason_codes or ["ROUTE_SIGNAL_EXPLICIT_PAYLOAD"]


def _resolve_confidence(value: Any, default: float = 1.0) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default


def _resolve_explicit_analysis_route(payload: dict[str, Any]) -> dict[str, Any]:
    route = payload.get("analysis_route")
    if not isinstance(route, dict):
        return {}
    analysis_type = _clean_text(route.get("analysis_type")).lower()
    if analysis_type not in {"requirement", "sourcing"}:
        return {}
    return {
        "analysis_type": analysis_type,
        "template_id": _clean_text(route.get("template_id")),
        "reason_codes": _resolve_reason_codes(route.get("reason_codes")),
        "confidence": _resolve_confidence(route.get("confidence")),
    }


def resolve_analysis_route(*, message: str, intent: str, command: str, mode: str, payload: dict[str, Any] | None = None, retrieval_hit_count: int = 0) -> dict[str, Any]:
    resolved_payload = payload if isinstance(payload, dict) else {}
    explicit_route = _resolve_explicit_analysis_route(resolved_payload)
    if explicit_route:
        return explicit_route
    decision = resolve_analysis_route_from_engine(
        {
            "message": message,
            "intent": intent,
            "command": command,
            "mode": mode,
            "candidate_pool_count": _resolve_candidate_pool_count(resolved_payload),
            "retrieval_hit_count": _coerce_non_negative_int(retrieval_hit_count),
            "sourcing_candidates": resolved_payload.get("sourcing_candidates") if isinstance(resolved_payload.get("sourcing_candidates"), list) else [],
            "policy": resolve_analysis_route_policy(resolved_payload),
        }
    )
    return {
        "analysis_type": str(decision.get("analysis_type") or "requirement"),
        "template_id": str(decision.get("template_id") or ""),
        "reason_codes": list(decision.get("reason_codes") or []),
        "confidence": float(decision.get("confidence") or 0.0),
    }


__all__ = ["resolve_analysis_route"]
