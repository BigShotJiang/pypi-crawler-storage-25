"""Domain-pack artifact template projection for runtime payloads.

DOC HELPER — OBJ-08 artifact template runtime boundary.
This module selects and normalizes templates supplied by a domain pack. It does
not invent document sections, perform model prompting, or decide user-facing
workflow state.
"""

from __future__ import annotations

import re
from typing import Any

_DOCUMENT_OUTPUT_INTENTS = frozenset({"document_template_output", "document_draft_output"})
_MAX_TEMPLATE_CHARS = 4000
_HTML_COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _as_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _strip_template_comments(template_text: str) -> str:
    without_comments = _HTML_COMMENT_RE.sub("", template_text)
    lines = [line.rstrip() for line in without_comments.splitlines()]
    return "\n".join(lines).strip()


def _normalize_section(item: Any, index: int) -> dict[str, str]:
    payload = item if isinstance(item, dict) else {"label": item}
    key = _clean_text(payload.get("key")) or f"section_{index}"
    label = _clean_text(payload.get("label") or key)
    instruction = _clean_text(payload.get("instruction") or payload.get("description"))
    return {"key": key, "label": label, "instruction": instruction}


def _normalize_sections(raw_sections: Any) -> list[dict[str, str]]:
    sections: list[dict[str, str]] = []
    for index, item in enumerate(_as_list(raw_sections), start=1):
        sections.append(_normalize_section(item, index))
    return sections


def _markdown_heading_sections(template_text: str) -> list[dict[str, str]]:
    sections: list[dict[str, str]] = []
    for line in template_text.splitlines():
        stripped = line.strip()
        if not stripped.startswith("#"):
            continue
        label = stripped.lstrip("#").strip()
        if not label:
            continue
        sections.append({"key": f"section_{len(sections) + 1}", "label": label, "instruction": ""})
    return sections[:20]


def _field_projection(fields: dict[str, Any]) -> list[dict[str, Any]]:
    raw_definitions = fields.get("field_definitions")
    if not isinstance(raw_definitions, list):
        return []
    projected: list[dict[str, Any]] = []
    for item in raw_definitions[:30]:
        if not isinstance(item, dict):
            continue
        key = _clean_text(item.get("key"))
        if not key:
            continue
        projected.append(
            {
                "key": key,
                "label": _clean_text(item.get("label")) or key,
                "priority": _clean_text(item.get("priority")) or "optional",
                "question": _clean_text(item.get("question")),
            }
        )
    return projected


def _artifact_config(domain_pack: dict[str, Any], artifact_type: str) -> dict[str, Any]:
    workflow = _as_mapping(domain_pack.get("workflow"))
    configs = _as_mapping(workflow.get("artifact_templates") or domain_pack.get("artifact_templates"))
    raw_config = configs.get(artifact_type)
    if isinstance(raw_config, str):
        return {"template": raw_config}
    return raw_config if isinstance(raw_config, dict) else {}


def _template_candidates(config: dict[str, Any], artifact_type: str) -> list[str]:
    candidates = [
        _clean_text(config.get("template")),
        _clean_text(config.get("template_key")),
        _clean_text(config.get("path")),
        f"{artifact_type}.md" if artifact_type else "",
        f"{artifact_type.replace('_', '-')}.md" if artifact_type else "",
    ]
    return [item for item in dict.fromkeys(candidates) if item]


def _select_template(templates: dict[str, Any], candidates: list[str]) -> tuple[str, str]:
    for key in candidates:
        raw_template = templates.get(key)
        if isinstance(raw_template, str):
            return key, raw_template
        if isinstance(raw_template, dict):
            content = raw_template.get("content") or raw_template.get("template")
            if isinstance(content, str):
                return key, content
    return "", ""


def build_artifact_template_runtime(
    *,
    payload: dict[str, Any],
    domain_pack: dict[str, Any],
) -> dict[str, Any]:
    """Project domain-pack template metadata for the requested artifact.

    DOC HELPER — this module does not define business sections. It only
    selects and normalizes domain-pack-provided template content for a generic
    response intent/artifact type contract.
    """

    response_intent = _as_mapping(payload.get("response_intent_result"))
    response_intent_key = _clean_text(response_intent.get("response_intent"))
    artifact_type = _clean_text(response_intent.get("artifact_type"))
    if response_intent_key not in _DOCUMENT_OUTPUT_INTENTS or not artifact_type or artifact_type == "none":
        return {}

    config = _artifact_config(domain_pack, artifact_type)
    templates = _as_mapping(domain_pack.get("templates"))
    template_key, template_text = _select_template(templates, _template_candidates(config, artifact_type))
    public_template_text = _strip_template_comments(template_text)
    sections = _normalize_sections(config.get("sections")) or _markdown_heading_sections(public_template_text)
    fields = _field_projection(_as_mapping(domain_pack.get("fields")))
    status = "matched" if template_text or sections else "partial" if fields else "missing"
    return {
        "status": status,
        "source": "domain_pack",
        "artifact_type": artifact_type,
        "response_intent": response_intent_key,
        "template_key": template_key,
        "template_excerpt": public_template_text[:_MAX_TEMPLATE_CHARS],
        "sections": sections,
        "fields": fields,
    }


__all__ = ["build_artifact_template_runtime"]
