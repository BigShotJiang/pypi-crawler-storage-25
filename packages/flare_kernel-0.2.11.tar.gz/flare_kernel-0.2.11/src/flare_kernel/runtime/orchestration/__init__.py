"""Runtime orchestration submodules."""

from __future__ import annotations

import importlib
import sys

_LEGACY_MODULE_TARGETS = {
    "mode_orchestration": "flare_kernel.runtime.orchestration.mode.orchestration",
    "mode_reasoning": "flare_kernel.runtime.orchestration.mode.reasoning",
    "mode_runtime": "flare_kernel.runtime.orchestration.mode.runtime",
    "sourcing_event_payloads": "flare_kernel.runtime.orchestration.sourcing.event_payloads",
    "sourcing_search_runtime": "flare_kernel.runtime.orchestration.sourcing.search_runtime",
}

for _legacy_name, _target in _LEGACY_MODULE_TARGETS.items():
    sys.modules.setdefault(
        f"flare_kernel.runtime.orchestration.{_legacy_name}",
        importlib.import_module(_target),
    )
