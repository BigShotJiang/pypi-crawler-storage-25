"""Canvas sourcing contract metadata helpers."""

from __future__ import annotations

from typing import Any


CANVAS_SOURCING_CONTRACT_VERSION = "canvas_sourcing.v0"
CANVAS_SOURCING_SCHEMA_VERSION = "v0"


def with_canvas_sourcing_contract_meta(payload: dict[str, Any]) -> dict[str, Any]:
    """Attach canvas sourcing contract metadata to event payloads."""

    return {
        **payload,
        "contract_version": CANVAS_SOURCING_CONTRACT_VERSION,
        "schema_version": CANVAS_SOURCING_SCHEMA_VERSION,
    }
