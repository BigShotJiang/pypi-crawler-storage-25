"""Requirement-intake canvas event assembly."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.canvas_state import (
    _build_canvas_revision_payload,
    _build_canvas_state_payload,
)
from flare_kernel.runtime.orchestration.mode.intake_canvas import enrich_intake_canvas_state


def build_intake_events_from_payloads(
    *,
    mode_key: str,
    session_id: str,
    payload: dict[str, Any],
    context: dict[str, Any],
    coverage: dict[str, Any],
    question: dict[str, Any],
    can_handoff_to_sourcing: bool,
    understanding_summary: str,
    field_progress_payload: dict[str, Any],
    next_actions_payload: dict[str, Any],
    requirement_draft_payload: dict[str, Any],
) -> list[dict[str, Any]]:
    events = [
        {
            "event_type": "field_progress",
            "step_id": "field_progress",
            "agent": "ModeOrchestration",
            "mode_key": mode_key,
            "payload": field_progress_payload,
        },
        {
            "event_type": "next_actions",
            "step_id": "next_actions",
            "agent": "ModeOrchestration",
            "mode_key": mode_key,
            "payload": next_actions_payload,
        },
    ]
    ready_for_workspace = can_handoff_to_sourcing
    intake_canvas_state_payload = None
    if mode_key == "requirement_intake":
        intake_canvas_state_payload = _build_canvas_state_payload(
            mode_key=mode_key,
            session_id=session_id,
            payload=payload,
            progress=coverage["progress"],
            collected=coverage["collected"],
            missing=question["missing"],
        )
        intake_canvas_state_payload = enrich_intake_canvas_state(
            canvas_state_payload=intake_canvas_state_payload,
            fields=context["fields"],
            field_definitions_by_key=coverage["field_definitions_by_key"],
            collected=coverage["collected"],
            missing=question["missing"],
            current_question=question["current_question"] if isinstance(question["current_question"], dict) else None,
            question_lifecycle=question.get("question_lifecycle", {}),
            readiness={
                "required_coverage": next_actions_payload.get("required_coverage"),
                "total_coverage": next_actions_payload.get("total_coverage"),
                "analysis_entry_threshold": next_actions_payload.get("analysis_entry_threshold"),
                "analysis_entry_eligible": next_actions_payload.get("analysis_entry_eligible"),
                "can_analyze": next_actions_payload.get("can_analyze"),
                "readiness_confidence": next_actions_payload.get("readiness_confidence"),
            },
            next_actions=next_actions_payload.get("next_actions", []),
            understanding_summary=understanding_summary,
            intake_ready=ready_for_workspace,
            intake_completed=context["intake_session_completed"],
        )
        intake_canvas_state_payload["intake_session_id"] = context["intake_session_id"]
        intake_canvas_state_payload["intake_session_state"] = context["intake_session_state"]
        intake_canvas_state_payload["intake_session_completed"] = context["intake_session_completed"]
    if intake_canvas_state_payload is not None and not ready_for_workspace:
        events.append(
            {
                "event_type": "canvas_state",
                "step_id": "canvas_state",
                "agent": "ModeOrchestration",
                "mode_key": mode_key,
                "payload": intake_canvas_state_payload,
            }
        )
    if mode_key == "requirement_intake" and context["intake_session_completed"]:
        events.append(
            {
                "event_type": "requirement_draft",
                "step_id": "requirement_draft",
                "agent": "ModeOrchestration",
                "mode_key": mode_key,
                "payload": requirement_draft_payload,
            }
        )
    if ready_for_workspace:
        revision_payload = _build_canvas_revision_payload(
            mode_key=mode_key,
            session_id=session_id,
            payload=payload,
        )
        revision_payload["intake_session_id"] = context["intake_session_id"]
        revision_payload["intake_session_state"] = context["intake_session_state"]
        revision_payload["intake_session_completed"] = context["intake_session_completed"]
        ready_events = [
            {
                "event_type": "requirement_draft",
                "step_id": "requirement_draft",
                "agent": "ModeOrchestration",
                "mode_key": mode_key,
                "payload": requirement_draft_payload,
            },
            {
                "event_type": "canvas_revision",
                "step_id": "canvas_revision",
                "agent": "ModeOrchestration",
                "mode_key": mode_key,
                "payload": revision_payload,
            },
        ]
        if intake_canvas_state_payload is not None:
            ready_events.insert(
                1,
                {
                    "event_type": "canvas_state",
                    "step_id": "canvas_state",
                    "agent": "ModeOrchestration",
                    "mode_key": mode_key,
                    "payload": intake_canvas_state_payload,
                },
            )
        else:
            canvas_state_payload = _build_canvas_state_payload(
                mode_key=mode_key,
                session_id=session_id,
                payload=payload,
                progress=coverage["progress"],
                collected=coverage["collected"],
                missing=question["missing"],
            )
            canvas_state_payload["intake_session_id"] = context["intake_session_id"]
            canvas_state_payload["intake_session_state"] = context["intake_session_state"]
            canvas_state_payload["intake_session_completed"] = context["intake_session_completed"]
            ready_events.insert(
                1,
                {
                    "event_type": "canvas_state",
                    "step_id": "canvas_state",
                    "agent": "ModeOrchestration",
                    "mode_key": mode_key,
                    "payload": canvas_state_payload,
                },
            )
        events.extend(ready_events)
    return events


__all__ = ["build_intake_events_from_payloads"]
