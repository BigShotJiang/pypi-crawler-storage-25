"""Requirement-intake field display projection."""

from __future__ import annotations

from typing import Any


def _field_definition_map(field_definitions: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {
        str(item.get("key") or "").strip(): item
        for item in field_definitions
        if isinstance(item, dict) and str(item.get("key") or "").strip()
    }


def build_missing_field_items(
    *,
    field_keys: list[str],
    field_definitions: list[dict[str, Any]],
    status: str,
) -> list[dict[str, str]]:
    definitions = _field_definition_map(field_definitions)
    items: list[dict[str, str]] = []
    for field_key in field_keys:
        normalized_key = str(field_key or "").strip()
        if not normalized_key:
            continue
        definition = definitions.get(normalized_key, {})
        items.append(
            {
                "key": normalized_key,
                "label": str(definition.get("label") or normalized_key).strip(),
                "priority": str(definition.get("priority") or "").strip(),
                "status": status,
            }
        )
    return items


def build_missing_field_groups(
    *,
    required_missing: list[str],
    recommended_missing: list[str],
    optional_missing: list[str],
    field_definitions: list[dict[str, Any]],
) -> dict[str, list[dict[str, str]]]:
    return {
        "required": build_missing_field_items(
            field_keys=required_missing,
            field_definitions=field_definitions,
            status="required",
        ),
        "recommended": build_missing_field_items(
            field_keys=recommended_missing,
            field_definitions=field_definitions,
            status="recommended",
        ),
        "optional": build_missing_field_items(
            field_keys=optional_missing,
            field_definitions=field_definitions,
            status="optional",
        ),
    }


__all__ = ["build_missing_field_groups", "build_missing_field_items"]
