"""Model-authored requirement summary artifact helpers.

These helpers normalize already-generated model text into backend Canvas state.
They do not call providers, assemble prompts, or decide workflow readiness.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _version_number(value: Any) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return 0
    return max(number, 0)


def _field_keys(rows: Any) -> list[str]:
    if not isinstance(rows, list):
        return []
    keys: list[str] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        field_key = _clean_text(row.get("field_key") or row.get("key"))
        if field_key and field_key not in keys:
            keys.append(field_key)
    return keys


def _latest_canvas_state_event(mode_events: Any) -> dict[str, Any]:
    if not isinstance(mode_events, list):
        return {}
    for event in reversed(mode_events):
        if not isinstance(event, dict):
            continue
        if _clean_text(event.get("event_type")) != "canvas_state":
            continue
        payload = event.get("payload")
        if isinstance(payload, dict) and _clean_text(payload.get("mode_key")) == "requirement_intake":
            return event
    return {}


def _template_from_payload(payload: dict[str, Any]) -> dict[str, Any]:
    template = payload.get("prompt_summary_template")
    return template if isinstance(template, dict) else {}


def _template_from_mode_events(mode_events: Any) -> dict[str, Any]:
    if not isinstance(mode_events, list):
        return {}
    for event in mode_events:
        payload = event.get("payload") if isinstance(event, dict) else None
        if not isinstance(payload, dict):
            continue
        template = _template_from_payload(payload)
        if template:
            return template
    return {}


def _template_key(*, template: dict[str, Any], runtime_payload: dict[str, Any], canvas_payload: dict[str, Any]) -> str:
    return _clean_text(
        runtime_payload.get("prompt_summary_template_key")
        or canvas_payload.get("prompt_summary_template_key")
        or template.get("key")
    )


def _append_content_version(*, versions: Any, content: str) -> list[dict[str, Any]]:
    normalized = [deepcopy(item) for item in versions if isinstance(item, dict)] if isinstance(versions, list) else []
    if normalized and _clean_text(normalized[-1].get("content")) == content:
        return normalized
    latest_version = _version_number(normalized[-1].get("version") if normalized else 0) or len(normalized)
    return [
        *normalized,
        {
            "version": latest_version + 1,
            "content": content,
            "diff": "model_generated",
        },
    ]


def build_model_authored_requirement_summary_event(
    *,
    runtime_snapshot: dict[str, Any],
    content_text: str,
    completion_provider: str,
    completion_model: str,
    completion_status: str,
) -> dict[str, Any] | None:
    """Build a Canvas state event carrying a normalized model summary."""

    if _clean_text(runtime_snapshot.get("mode_key")) != "requirement_intake":
        return None
    if _clean_text(completion_status) != "ok":
        return None
    content = _clean_text(content_text)
    if not content:
        return None

    source_event = _latest_canvas_state_event(runtime_snapshot.get("mode_events"))
    source_payload = deepcopy(_coerce_mapping(source_event.get("payload")))
    if not source_payload:
        return None
    canvas_state = deepcopy(_coerce_mapping(source_payload.get("canvas_state")))
    if not canvas_state:
        return None

    runtime_payload = _coerce_mapping(runtime_snapshot.get("payload"))
    template = _template_from_payload(runtime_payload) or _template_from_mode_events(runtime_snapshot.get("mode_events"))
    summary_artifact = {
        "artifact_type": "requirement_summary",
        "template_key": _template_key(
            template=template,
            runtime_payload=runtime_payload,
            canvas_payload=source_payload,
        ),
        "content": content,
        "source": "model",
        "status": "generated",
        "provider": {
            "provider": _clean_text(completion_provider),
            "model": _clean_text(completion_model),
            "status": _clean_text(completion_status),
        },
        "grounding": {
            "confirmed_field_keys": _field_keys(canvas_state.get("collected")),
            "missing_field_keys": _field_keys(canvas_state.get("missing")),
        },
    }
    canvas_state["requirement_summary"] = summary_artifact
    canvas_state["versions"] = _append_content_version(
        versions=canvas_state.get("versions"),
        content=content,
    )
    source_payload["canvas_state"] = canvas_state
    source_payload["canvas_content"] = content
    source_payload["requirement_summary"] = summary_artifact
    return {
        "event_type": "canvas_state",
        "step_id": "canvas_state",
        "agent": "ModelCompletion",
        "mode_key": "requirement_intake",
        "payload": source_payload,
    }


__all__ = ["build_model_authored_requirement_summary_event"]
