"""Requirement-intake draft payload assembly."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.shared import _coerce_message_excerpt


def build_requirement_draft_payload(
    *,
    mode_key: str,
    session_id: str,
    payload: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    draft_state = "applied" if context["intake_session_completed"] else "drafting"
    return {
        "mode_key": mode_key,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "message_excerpt": _coerce_message_excerpt(payload),
        "draft": {
            "fields": context["fields"],
            "summary": payload.get("summary") or payload.get("draft_summary") or "",
            "status": payload.get("draft_status") or draft_state,
        },
        "mode_state": draft_state,
        "render_hint": "requirement_draft",
        "intake_session_id": context["intake_session_id"],
        "intake_session_state": context["intake_session_state"],
        "intake_session_completed": context["intake_session_completed"],
    }


__all__ = ["build_requirement_draft_payload"]
