"""Requirement-intake question construction."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.api import canonicalize_answer, plan_next_question
from flare_kernel.runtime.reasoning.intake.question.builder import _resolve_question_options_from_text
from flare_kernel.runtime.reasoning.intake.question.decision import build_question_decision
from flare_kernel.runtime.orchestration.mode.question_selection import (
    _resolve_question_text_for_current_field,
    _select_best_missing_field,
)
from flare_kernel.runtime.orchestration.mode.intake_question_lifecycle import (
    attach_question_lifecycle,
    build_question_lifecycle,
)
from flare_kernel.runtime.orchestration.mode.shared import (
    _coerce_mapping,
    _normalize_field_list,
)


def _normalize_question_options(options: list[Any]) -> list[dict[str, Any]]:
    normalized_options: list[dict[str, Any]] = []
    for index, option in enumerate(options, start=1):
        payload = option if isinstance(option, dict) else {"label": option, "value": option}
        option_label = str(payload.get("label") or payload.get("text") or payload.get("value") or "").strip()
        if not option_label:
            continue
        normalized_options.append(
            {
                "key": str(payload.get("key") or f"option_{index}").strip(),
                "label": option_label,
                "value": str(payload.get("value") or option_label).strip(),
                "followup_hint": str(payload.get("followup_hint") or "").strip(),
                "requires_custom_input": bool(payload.get("requires_custom_input") or payload.get("allow_custom_input")),
                "activates_fields": _normalize_field_list(payload.get("activates_fields")),
                "suppresses_fields": _normalize_field_list(payload.get("suppresses_fields")),
            }
        )
    return normalized_options


def _resolve_question_decision(
    *,
    current_question: dict[str, Any] | None,
    planning_state: dict[str, Any],
    field_selection: dict[str, Any],
    reasoning_state: dict[str, Any],
) -> dict[str, Any]:
    decision = _coerce_mapping(planning_state.get("question_decision"))
    field_key = str((current_question or {}).get("field_key") or "").strip()
    if not field_key:
        return decision
    if str(decision.get("selected_field_key") or "").strip() == field_key:
        return decision
    return build_question_decision(
        selected_field_key=field_key,
        candidate_information_gaps=[],
        field_scores=_coerce_mapping(field_selection.get("field_scores")),
        planning_source=str(planning_state.get("planning_source") or "").strip(),
        why_now=str(planning_state.get("why_now") or "").strip(),
        target_information_gap=str(planning_state.get("target_information_gap") or field_key).strip(),
        session_state=reasoning_state,
    )


def _is_terminal_intake_state(payload: dict[str, Any], reasoning_state: dict[str, Any]) -> bool:
    command = str(payload.get("command") or payload.get("action_command") or "").strip().lower()
    if command in {"apply", "implement"}:
        return True
    return bool(payload.get("intake_session_completed") or reasoning_state.get("intake_session_completed"))


def build_intake_question(
    *,
    payload: dict[str, Any],
    intake_session_id: str,
    missing: list[str],
    reasoning_state: dict[str, Any],
    domain_context: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    field_selection: dict[str, Any],
    structured_reasoning: dict[str, Any],
    understanding_state: dict[str, Any],
    field_definitions_by_key: dict[str, Any],
) -> dict[str, Any]:
    planning_state = plan_next_question(
        session_state=reasoning_state,
        domain_context=domain_context,
        hypotheses=hypotheses,
        field_selection=field_selection,
        structured_output=_coerce_mapping(structured_reasoning.get("question_planner"))
        or {
            "next_question": _coerce_mapping(understanding_state.get("current_best_next_question"))
        },
    )
    planned_target_fields = _normalize_field_list(planning_state.get("target_field_keys"))
    first_missing_key = planned_target_fields[0] if planned_target_fields else ""
    if first_missing_key and first_missing_key not in missing:
        first_missing_key = ""
    if not first_missing_key and missing:
        first_missing_key = _select_best_missing_field(
            missing=missing,
            field_scores=_coerce_mapping(field_selection.get("field_scores")),
        )
    if first_missing_key and first_missing_key in missing:
        missing = [first_missing_key] + [field for field in missing if field != first_missing_key]
    first_missing_definition = field_definitions_by_key.get(first_missing_key, {})
    terminal_intake_state = _is_terminal_intake_state(payload, reasoning_state)
    if terminal_intake_state:
        return {
            "current_question": None,
            "first_missing_key": "",
            "latest_answer_canonical": None,
            "missing": missing,
            "planning_state": planning_state,
            "question_lifecycle": build_question_lifecycle(
                payload=payload,
                current_question=None,
                terminal_intake=True,
            ),
            "question_decision": {},
            "question_progress_resumed": False,
        }

    latest_answer_canonical = None
    question_answer = payload.get("question_answer")
    if isinstance(question_answer, dict):
        answer_field_key = str(question_answer.get("field_key") or "").strip()
        answer_field_value = str(
            question_answer.get("raw_value")
            or question_answer.get("field_value")
            or question_answer.get("selected_option_value")
            or ""
        ).strip()
        if answer_field_key and answer_field_value:
            answer_semantics = _coerce_mapping(_coerce_mapping(domain_context.get("field_semantics")).get(answer_field_key))
            answer_definition = _coerce_mapping(field_definitions_by_key.get(answer_field_key))
            latest_answer_canonical = canonicalize_answer(
                field_type=str(answer_semantics.get("value_type") or "text"),
                raw_answer=answer_field_value,
                context={
                    "source": "question_answer",
                    "options": answer_definition.get("options") if isinstance(answer_definition.get("options"), list) else [],
                },
            )

    current_question = None
    question_progress_resumed = False
    question_kind = str(planning_state.get("question_kind") or "field").strip() or "field"
    branch_node_key = str(planning_state.get("branch_node_key") or "").strip()
    active_field_scope = _normalize_field_list(planning_state.get("active_field_scope"))
    suppressed_field_scope = _normalize_field_list(planning_state.get("suppressed_field_scope"))
    if missing and (question_kind == "branch" or first_missing_key):
        planning_matches_missing = (
            question_kind == "branch"
            or not planned_target_fields
            or first_missing_key in set(planned_target_fields)
        )
        label = str(first_missing_definition.get("label") or first_missing_key or branch_node_key)
        question_text = _resolve_question_text_for_current_field(
            question_kind=question_kind,
            field_key=first_missing_key,
            planned_question_text=str(planning_state.get("question_text") or "").strip()
            if planning_matches_missing
            else "",
            planned_target_fields=planned_target_fields,
            field_definition=first_missing_definition,
            fallback_label=label,
        )
        options = planning_state.get("options") if planning_matches_missing else []
        if not isinstance(options, list) or not options:
            options = first_missing_definition.get("options")
        if not isinstance(options, list):
            options = []
        if not options:
            options = _resolve_question_options_from_text(question_text)
        normalized_options = _normalize_question_options(options)
        previous_progress = payload.get("question_progress")
        previous_total = 0
        previous_current = 0
        previous_session_id = ""
        if isinstance(previous_progress, dict):
            try:
                previous_total = int(previous_progress.get("total") or 0)
            except (TypeError, ValueError):
                previous_total = 0
            try:
                previous_current = int(previous_progress.get("current") or 0)
            except (TypeError, ValueError):
                previous_current = 0
            previous_session_id = str(previous_progress.get("intake_session_id") or "").strip()
        question_answer = payload.get("question_answer")
        has_question_answer = bool(
            isinstance(question_answer, dict)
            and str(question_answer.get("field_key") or "").strip()
            and str(
                question_answer.get("field_value")
                or question_answer.get("raw_value")
                or question_answer.get("selected_option_value")
                or ""
            ).strip()
        )
        resume_collection = payload.get("resume_collection") is True
        can_resume_progress = bool(
            previous_total > 0
            and previous_current > 0
            and (not previous_session_id or previous_session_id == intake_session_id)
            and (has_question_answer or resume_collection)
        )
        if can_resume_progress:
            step_total = max(previous_total, len(missing), 1)
            next_step_index = previous_current + 1 if has_question_answer else previous_current
            step_index = max(1, min(step_total, next_step_index))
            question_progress_resumed = True
        else:
            step_total = max(len(missing), 1)
            step_index = 1
        question_key = str(
            (planning_state.get("question_key") or first_missing_key)
            if planning_matches_missing
            else first_missing_key
        ).strip() or first_missing_key
        target_information_gap = str(
            (planning_state.get("target_information_gap") or first_missing_key)
            if planning_matches_missing
            else first_missing_key
        ).strip() or first_missing_key
        current_question = {
            "question_id": str(planning_state.get("question_id") or f"question::{first_missing_key}").strip(),
            "question_revision": str(
                payload.get("question_revision")
                or planning_state.get("question_revision")
                or f"{intake_session_id}:{first_missing_key}:{step_index}"
            ).strip(),
            "question_status": "active",
            "issued_at": str(payload.get("question_issued_at") or "").strip(),
            "field_key": first_missing_key,
            "question_key": question_key,
            "field_label": label,
            "question_text": question_text,
            "question_kind": question_kind,
            "branch_node_key": branch_node_key,
            "why_now": planning_state.get("why_now"),
            "target_information_gap": target_information_gap,
            "options": normalized_options,
            "allow_other_input": True,
            "step_index": step_index,
            "step_total": step_total,
            "active_field_scope": active_field_scope,
            "suppressed_field_scope": suppressed_field_scope,
        }
    question_decision = _resolve_question_decision(
        current_question=current_question,
        planning_state=planning_state,
        field_selection=field_selection,
        reasoning_state=reasoning_state,
    )
    question_lifecycle = build_question_lifecycle(
        payload=payload,
        current_question=current_question,
        terminal_intake=terminal_intake_state,
    )
    current_question = attach_question_lifecycle(
        current_question=current_question,
        lifecycle=question_lifecycle,
    )

    return {
        "current_question": current_question,
        "first_missing_key": first_missing_key,
        "latest_answer_canonical": latest_answer_canonical,
        "missing": missing,
        "planning_state": planning_state,
        "question_lifecycle": question_lifecycle,
        "question_decision": question_decision,
        "question_progress_resumed": question_progress_resumed,
    }


__all__ = ["build_intake_question"]
