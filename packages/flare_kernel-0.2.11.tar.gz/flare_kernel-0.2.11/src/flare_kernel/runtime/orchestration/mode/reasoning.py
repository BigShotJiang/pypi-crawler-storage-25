"""Runtime reasoning orchestration adapter."""

from __future__ import annotations

from typing import Any

from flare_engines import run_reasoning


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _coerce_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def build_runtime_reasoning(
    *,
    session_id: str,
    payload: dict[str, Any],
    mode_runtime: dict[str, str],
) -> dict[str, Any]:
    context = _coerce_mapping(payload.get("context") or payload.get("session_context"))
    return run_reasoning(
        {
            "reasoning_id": str(payload.get("reasoning_id") or "").strip(),
            "scope": "session",
            "user_message": str(payload.get("message") or payload.get("content") or ""),
            "assistant_message": str(payload.get("assistant_message") or ""),
            "context": context,
            "evidence": _coerce_list(payload.get("evidence")),
            "facts": _coerce_list(payload.get("facts")),
            "inferences": _coerce_list(payload.get("inferences")),
            "unknowns": _coerce_list(payload.get("unknowns")),
            "domain_hints": {
                "session_id": session_id,
                "mode_key": mode_runtime.get("mode_key", ""),
                "mode_state": mode_runtime.get("mode_state", ""),
            },
        }
    )


__all__ = ["build_runtime_reasoning"]
