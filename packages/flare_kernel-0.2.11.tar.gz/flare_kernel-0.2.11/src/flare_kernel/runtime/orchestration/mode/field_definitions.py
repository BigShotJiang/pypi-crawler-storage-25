"""Field definition normalization for mode orchestration."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.shared import _normalize_field_list


def _normalize_field_definitions(*, payload: dict[str, Any], domain_pack: dict[str, Any] | None) -> list[dict[str, Any]]:
    raw_definitions = payload.get("field_definitions")
    if not isinstance(raw_definitions, list):
        pack_fields = domain_pack.get("fields") if isinstance(domain_pack, dict) and isinstance(domain_pack.get("fields"), dict) else {}
        raw_definitions = pack_fields.get("field_definitions") if isinstance(pack_fields.get("field_definitions"), list) else []

    normalized: list[dict[str, Any]] = []
    for item in raw_definitions:
        if not isinstance(item, dict):
            continue
        field_key = str(item.get("key") or "").strip()
        if not field_key:
            continue
        priority = str(item.get("priority") or "optional").strip() or "optional"
        options = item.get("options")
        normalized.append(
            {
                "key": field_key,
                "label": str(item.get("label") or field_key),
                "priority": priority,
                "blocker": bool(item.get("blocker", priority == "required")),
                "question": str(item.get("question") or "").strip(),
                "options": options if isinstance(options, list) else [],
                "weight": item.get("weight"),
                "confidence": item.get("confidence"),
            }
        )
    return normalized


def _derive_field_lists(
    *,
    payload: dict[str, Any],
    field_definitions: list[dict[str, Any]],
) -> tuple[list[str], list[str], list[str]]:
    if field_definitions:
        required_fields: list[str] = []
        recommended_fields: list[str] = []
        optional_fields: list[str] = []
        for item in field_definitions:
            if not isinstance(item, dict):
                continue
            field_key = str(item.get("key") or "").strip()
            if not field_key:
                continue
            priority = str(item.get("priority") or "optional").strip().lower()
            if priority == "required":
                required_fields.append(field_key)
            elif priority == "recommended":
                recommended_fields.append(field_key)
            else:
                optional_fields.append(field_key)
        return (
            _normalize_field_list(required_fields),
            _normalize_field_list(recommended_fields),
            _normalize_field_list(optional_fields),
        )
    return (
        _normalize_field_list(payload.get("required_fields")),
        _normalize_field_list(payload.get("recommended_fields")),
        _normalize_field_list(payload.get("optional_fields")),
    )


__all__ = ["_derive_field_lists", "_normalize_field_definitions"]
