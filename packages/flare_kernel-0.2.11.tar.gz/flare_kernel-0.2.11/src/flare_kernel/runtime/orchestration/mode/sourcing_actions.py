"""Sourcing next-action normalization."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.shared import _resolve_workflow_alias


_INTELLIGENT_SOURCING_CONFIRM_ACTIONS: list[dict[str, Any]] = [
    {
        "action_key": "confirm_sourcing",
        "action_type": "next_step",
        "label": "确认进入智能寻源",
        "target_mode": "intelligent_sourcing",
        "priority": 1,
        "status": "available",
        "reason": "检索范围已收口，确认后再进入候选筛选。",
        "description": "确认后进入候选匹配、风险摘要与报告组装。",
        "payload": {
            "target_mode": "intelligent_sourcing",
            "action_key": "confirm_sourcing",
            "sourcing_confirmed": True,
            "prefill_prompt": "确认进入智能寻源，请继续。",
        },
    }
]


def build_sourcing_confirm_actions(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Build confirm actions for entering intelligent sourcing.

    Args:
        payload: Current orchestration payload used to resolve workflow aliases.

    Returns:
        A list of normalized confirm actions with canonical action payloads.
    """
    actions = [dict(item) for item in _INTELLIGENT_SOURCING_CONFIRM_ACTIONS]
    for action in actions:
        action_key = str(action.get("action_key") or "").strip() or "confirm_sourcing"
        action["action_key"] = _resolve_workflow_alias(
            payload,
            namespace="actions",
            name=action_key,
            default=action_key,
        )
        raw_payload = action.get("payload") if isinstance(action.get("payload"), dict) else {}
        action["payload"] = {
            **raw_payload,
            "action_key": action["action_key"],
        }
    return actions


__all__ = ["build_sourcing_confirm_actions"]
