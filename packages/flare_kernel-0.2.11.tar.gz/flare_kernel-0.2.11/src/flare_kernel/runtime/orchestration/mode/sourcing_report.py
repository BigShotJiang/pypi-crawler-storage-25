"""Confirmed intelligent-sourcing report event assembly.

DOC HELPER — SRC-07 mode-event projection boundary.
This module projects confirmed sourcing payloads into canvas/report events and
next actions. It does not perform retrieval, mutate session context, generate
analysis content, or invent frontend state.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.canvas_sourcing_contract import (
    with_canvas_sourcing_contract_meta,
)
from flare_kernel.runtime.orchestration.mode.canvas_state import _build_canvas_state_payload
from flare_kernel.runtime.orchestration.mode.shared import (
    _coerce_message_excerpt,
    _resolve_workflow_alias,
)
from flare_kernel.runtime.orchestration.sourcing.event_payloads import (
    resolve_sourcing_rows,
    resolve_sourcing_status,
)
from flare_kernel.runtime.orchestration.sourcing.analysis_entry import (
    build_sourcing_analysis_action,
)


def _candidate_count(rows: list[dict[str, Any]]) -> int:
    return sum(1 for row in rows if row.get("result_role") == "candidate")


def build_sourcing_report_events(
    *,
    mode_key: str,
    session_id: str,
    payload: dict[str, Any],
    base_fields: dict[str, Any],
    base_collected: list[str],
    base_missing: list[str],
    base_total: int,
    base_progress: float,
    candidate_rows: list[dict[str, Any]],
    source_meta: dict[str, Any],
    parameter_draft: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], str]:
    """Assemble confirmed intelligent-sourcing report events.

    Args:
        mode_key: Active workflow mode key.
        session_id: Current chat or run session identifier.
        payload: Canonical orchestration payload for the confirmed run.
        base_fields: Collected intake fields used by sourcing.
        base_collected: Names of fields already collected.
        base_missing: Names of fields still missing.
        base_total: Total expected field count for progress calculation.
        base_progress: Current collection progress ratio.
        candidate_rows: Confirmed candidate rows for comparison and screening.
        source_meta: Source trace metadata from the sourcing runtime.
        parameter_draft: Deterministic handoff draft to attach to all events.

    Returns:
        A tuple of assembled events, next actions, and final mode state.
    """
    shortlist_rows = resolve_sourcing_rows(payload, shortlist=True)
    analysis_action = build_sourcing_analysis_action(
        payload=payload,
        candidates=candidate_rows,
        shortlist=shortlist_rows,
        parameter_draft=parameter_draft,
        source_meta=source_meta,
    )
    next_actions = [analysis_action] if analysis_action else []
    payload_actions = payload.get("actions") if isinstance(payload.get("actions"), list) else []
    actions = [*payload_actions, *next_actions]
    candidates_payload = with_canvas_sourcing_contract_meta({
        "mode_key": mode_key,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "message_excerpt": _coerce_message_excerpt(payload),
        "missing": base_missing,
        "base_fields": list(base_fields.keys()),
        "base_collected": base_collected,
        "base_missing": base_missing,
        "base_total": base_total,
        "base_progress": base_progress,
        "base_ready_for_matching": True,
        "mode_state": payload.get("mode_state") or "matching",
        "candidate_count": _candidate_count(candidate_rows),
        "is_placeholder": False,
        "required_missing": payload.get("required_missing", []),
        "recommended_missing": payload.get("recommended_missing", []),
        "optional_missing": payload.get("optional_missing", []),
        "actions": actions,
        "next_actions": next_actions,
        "candidates": candidate_rows,
        **parameter_draft,
        "reasoning": payload.get("reasoning", []),
        "summary": payload.get("summary") or payload.get("sourcing_summary"),
        "source_meta": source_meta,
        "render_hint": "sourcing_candidates",
    })
    risk_summary_payload = with_canvas_sourcing_contract_meta({
        "mode_key": mode_key,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "message_excerpt": _coerce_message_excerpt(payload),
        "mode_state": "screening",
        "base_fields": list(base_fields.keys()),
        "base_collected": base_collected,
        "base_missing": base_missing,
        "base_total": base_total,
        "base_progress": base_progress,
        "base_ready_for_matching": True,
        "is_placeholder": False,
        "actions": actions,
        "risks": payload.get("risk_flags", payload.get("risks", payload.get("risk_items", []))),
        **parameter_draft,
        "sources": payload.get("sources", payload.get("references", [])),
        "summary": payload.get("risk_summary") or payload.get("summary") or "",
        "source_meta": source_meta,
        "render_hint": "risk_summary",
    })
    shortlist_payload = with_canvas_sourcing_contract_meta({
        "mode_key": mode_key,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "message_excerpt": _coerce_message_excerpt(payload),
        "mode_state": "shortlisted",
        "base_fields": list(base_fields.keys()),
        "base_collected": base_collected,
        "base_missing": base_missing,
        "base_total": base_total,
        "base_progress": base_progress,
        "base_ready_for_matching": True,
        "shortlist": shortlist_rows,
        "status": resolve_sourcing_status(payload, len(shortlist_rows)),
        "reason": payload.get("reason") or payload.get("message") or "",
        "selected_count": _candidate_count(shortlist_rows),
        "is_placeholder": False,
        "actions": actions,
        "next_actions": next_actions,
        "source_meta": source_meta,
        **parameter_draft,
        "render_hint": "shortlist_updated",
    })
    report = payload.get("report")
    if not isinstance(report, dict):
        report = payload.get("evaluation_report_ready") if isinstance(payload.get("evaluation_report_ready"), dict) else {}
    evaluation_report_ready_payload = with_canvas_sourcing_contract_meta({
        "mode_key": mode_key,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "message_excerpt": _coerce_message_excerpt(payload),
        "mode_state": "report_ready",
        "base_fields": list(base_fields.keys()),
        "base_collected": base_collected,
        "base_missing": base_missing,
        "base_total": base_total,
        "base_progress": base_progress,
        "base_ready_for_matching": True,
        "is_placeholder": False,
        "actions": actions,
        "report": {
            **report,
            "sections": report.get("sections", []) if isinstance(report.get("sections"), list) else [],
        },
        **parameter_draft,
        "compare_table": payload.get("compare_table") or payload.get("comparison_table") or payload.get("compare_rows"),
        "source_meta": source_meta,
        "render_hint": "evaluation_report_ready",
    })
    event_names = {
        "sourcing_candidates": _resolve_workflow_alias(payload, namespace="events", name="sourcing_candidates", default="sourcing_candidates"),
        "risk_summary": _resolve_workflow_alias(payload, namespace="events", name="risk_summary", default="risk_summary"),
        "shortlist_updated": _resolve_workflow_alias(payload, namespace="events", name="shortlist_updated", default="shortlist_updated"),
        "evaluation_report_ready": _resolve_workflow_alias(payload, namespace="events", name="evaluation_report_ready", default="evaluation_report_ready"),
    }
    events = [
        {"event_type": event_names["sourcing_candidates"], "step_id": event_names["sourcing_candidates"], "agent": "ModeOrchestration", "mode_key": mode_key, "payload": candidates_payload},
        {"event_type": event_names["risk_summary"], "step_id": event_names["risk_summary"], "agent": "ModeOrchestration", "mode_key": mode_key, "payload": risk_summary_payload},
        {"event_type": event_names["shortlist_updated"], "step_id": event_names["shortlist_updated"], "agent": "ModeOrchestration", "mode_key": mode_key, "payload": shortlist_payload},
        {"event_type": event_names["evaluation_report_ready"], "step_id": event_names["evaluation_report_ready"], "agent": "ModeOrchestration", "mode_key": mode_key, "payload": evaluation_report_ready_payload},
    ]
    if next_actions:
        events.append(
            {
                "event_type": "next_actions",
                "step_id": "next_actions",
                "agent": "ModeOrchestration",
                "mode_key": mode_key,
                "payload": {
                    "mode_key": mode_key,
                    "session_id": session_id,
                    "project_id": payload.get("project_id"),
                    "mode_state": "report_ready",
                    "render_hint": "next_actions",
                    "summary": "候选池已准备好，可继续生成可编辑分析。",
                    "next_actions": next_actions,
                    "actions": next_actions,
                },
            }
        )
    events.append(
        {
            "event_type": "canvas_state",
            "step_id": "canvas_state",
            "agent": "ModeOrchestration",
            "mode_key": mode_key,
            "payload": _build_canvas_state_payload(
                mode_key=mode_key,
                session_id=session_id,
                payload=payload,
                progress=1.0,
                collected=base_collected,
                missing=base_missing,
                sourcing_candidate_count=_candidate_count(candidate_rows),
            ),
        },
    )
    return events, next_actions, "report_ready"


__all__ = ["build_sourcing_report_events"]
