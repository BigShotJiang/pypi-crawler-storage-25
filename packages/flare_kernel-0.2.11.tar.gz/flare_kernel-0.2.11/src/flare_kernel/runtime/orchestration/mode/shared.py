"""Shared normalization helpers for mode orchestration."""

from __future__ import annotations

from typing import Any


def _coerce_message_excerpt(payload: dict[str, Any]) -> str:
    message = payload.get("message")
    if isinstance(message, str):
        return message.strip()
    return ""


def _resolve_result_text_from_payload(payload: dict[str, Any]) -> str:
    candidates = [
        payload.get("result_text"),
        payload.get("result_summary"),
        payload.get("response_text"),
        payload.get("final_answer_text"),
        payload.get("canvas_candidate_content"),
        payload.get("canvas_content"),
        payload.get("draft_summary"),
        payload.get("summary"),
    ]
    for value in candidates:
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _normalize_field_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    seen: set[str] = set()
    normalized: list[str] = []
    for item in value:
        field_key = str(item or "").strip()
        if not field_key or field_key in seen:
            continue
        seen.add(field_key)
        normalized.append(field_key)
    return normalized


def _has_value(value: Any) -> bool:
    return value not in (None, "", [], {})


def _resolve_sourcing_base_field_keys(payload: dict[str, Any]) -> tuple[str, ...]:
    explicit = payload.get("sourcing_base_field_keys")
    if isinstance(explicit, list):
        normalized = [str(item).strip() for item in explicit if str(item).strip()]
        if normalized:
            return tuple(dict.fromkeys(normalized))
    return ()


def _resolve_workflow_alias(
    payload: dict[str, Any],
    *,
    namespace: str,
    name: str,
    default: str,
) -> str:
    aliases = payload.get("workflow_aliases")
    if not isinstance(aliases, dict):
        return default
    node = aliases.get(namespace)
    if not isinstance(node, dict):
        return default
    candidate = node.get(name)
    if isinstance(candidate, str) and candidate.strip():
        return candidate.strip()
    return default


__all__ = [
    "_coerce_mapping",
    "_coerce_message_excerpt",
    "_has_value",
    "_normalize_field_list",
    "_resolve_result_text_from_payload",
    "_resolve_sourcing_base_field_keys",
    "_resolve_workflow_alias",
]
