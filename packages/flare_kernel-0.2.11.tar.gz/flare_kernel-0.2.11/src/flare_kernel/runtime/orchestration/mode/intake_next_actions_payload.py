"""Requirement-intake next-actions payload assembly."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.intake_field_projection import build_missing_field_groups
from flare_kernel.runtime.orchestration.mode.shared import _coerce_message_excerpt


def build_next_actions_payload(
    *,
    mode_key: str,
    session_id: str,
    payload: dict[str, Any],
    context: dict[str, Any],
    coverage: dict[str, Any],
    question: dict[str, Any],
    question_progress: dict[str, Any],
    resolved_actions: list[dict[str, Any]],
    flow_state: str,
    can_handoff_to_sourcing: bool,
    required_missing_count: int,
    readiness: dict[str, Any],
    analyzability_score: float,
    understanding_summary: str,
) -> dict[str, Any]:
    terminal_intake = bool(context["intake_session_completed"])
    required_missing = coverage["missing"]
    missing_field_groups = build_missing_field_groups(
        required_missing=required_missing,
        recommended_missing=coverage["recommended_missing"],
        optional_missing=coverage["optional_missing"],
        field_definitions=context["field_definitions"],
    )
    return {
        "mode_key": mode_key,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "message_excerpt": _coerce_message_excerpt(payload),
        "actions": resolved_actions,
        "next_actions": resolved_actions,
        "completion_state": "completed" if terminal_intake else ("ready" if can_handoff_to_sourcing else "collecting"),
        "required_missing": required_missing,
        "required_missing_items": missing_field_groups["required"],
        "recommended_missing": coverage["recommended_missing"],
        "recommended_missing_items": missing_field_groups["recommended"],
        "optional_missing": coverage["optional_missing"],
        "optional_missing_items": missing_field_groups["optional"],
        "missing_field_groups": missing_field_groups,
        "intake_core_fields": context["intake_core_fields"],
        "intake_supplementary_fields": context["intake_supplementary_fields"],
        "analysis_enrichment_fields": context["analysis_enrichment_fields"],
        "ready_for_sourcing": can_handoff_to_sourcing,
        "status": "available" if can_handoff_to_sourcing else "available_with_gaps",
        "reason": "当前需求清晰度已可支持智能寻源。" if can_handoff_to_sourcing else "仍有关键字段建议补充；也可带待补充项和假设继续。",
        "mode_state": "applied" if terminal_intake else ("ready_for_submit" if can_handoff_to_sourcing else "collecting"),
        "flow_state": flow_state,
        "current_question": question["current_question"],
        "question_lifecycle": question.get("question_lifecycle", {}),
        "question_decision": question.get("question_decision", {}),
        "question_progress": question_progress,
        "collection_phase": flow_state,
        "required_missing_count": required_missing_count,
        "required_coverage": readiness["required_coverage"],
        "total_coverage": readiness["total_coverage"],
        "analysis_entry_threshold": readiness["analysis_entry_threshold"],
        "analysis_entry_eligible": readiness["analysis_entry_eligible"],
        "can_analyze": readiness["can_analyze"],
        "readiness_confidence": readiness["confidence"],
        "blocking_reasons": readiness["blocking_reasons"],
        "unresolved_critical_questions": readiness["unresolved_critical_questions"],
        "uncertainty_level": readiness["uncertainty_level"],
        "hypotheses": context["hypotheses"],
        "primary_hypothesis": context["primary_hypothesis"],
        "active_fields": context["active_fields"],
        "deferred_fields": context["deferred_fields"],
        "low_relevance_fields": context["low_relevance_fields"],
        "field_scores": context["field_selection"].get("field_scores", {}),
        "planner": {
            "question_id": question["planning_state"].get("question_id"),
            "target_field_keys": question["planning_state"].get("target_field_keys", []),
            "rationale": question["planning_state"].get("rationale"),
            "expected_answer_type": question["planning_state"].get("expected_answer_type"),
            "planning_source": question["planning_state"].get("planning_source"),
            "why_now": question["planning_state"].get("why_now"),
            "target_information_gap": question["planning_state"].get("target_information_gap"),
        },
        "intake_understanding": context["understanding_state"],
        "understanding_summary": understanding_summary,
        "analyzability_score": analyzability_score,
        "last_answer_canonical": question["latest_answer_canonical"],
        "prompt_summary_template_key": context["prompt_summary_template_key"],
        "prompt_summary_template": context["prompt_summary_template"],
        "render_hint": "next_actions",
        "intake_session_id": context["intake_session_id"],
        "intake_session_state": context["intake_session_state"],
        "intake_session_completed": context["intake_session_completed"],
    }


__all__ = ["build_next_actions_payload"]
