"""Requirement-intake context assembly."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.api import (
    build_intake_domain_context,
    build_intake_understanding_state,
)
from flare_kernel.runtime.reasoning.intake.branching.core import (
    merge_branch_field_definitions,
)
from flare_kernel.runtime.orchestration.mode.field_definitions import (
    _derive_field_lists,
    _normalize_field_definitions,
)
from flare_kernel.runtime.orchestration.mode.shared import (
    _coerce_mapping,
    _coerce_message_excerpt,
    _normalize_field_list,
    _resolve_result_text_from_payload,
)


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _collect_text(items: list[Any], *keys: str) -> list[str]:
    texts: list[str] = []
    for item in items:
        payload = item if isinstance(item, dict) else {"text": item}
        parts = [_clean_text(payload.get(key)) for key in keys]
        text = " ".join(part for part in parts if part)
        if text:
            texts.append(text)
    return texts


def _build_question_context(payload: dict[str, Any]) -> dict[str, Any]:
    track_result = _coerce_mapping(payload.get("track_result"))
    artifact_result = _coerce_mapping(payload.get("artifact_template_result"))
    track_readiness = _coerce_mapping(track_result.get("readiness"))
    artifact_fields = [
        _clean_text(item.get("key"))
        for item in _as_list(artifact_result.get("fields"))
        if isinstance(item, dict) and _clean_text(item.get("key"))
    ]
    artifact_sections = _collect_text(
        _as_list(artifact_result.get("sections")),
        "key",
        "label",
        "instruction",
    )
    document_count = len(_as_list(payload.get("knowledge_refs"))) + len(_as_list(payload.get("context_refs")))
    try:
        document_count = max(document_count, int(track_readiness.get("document_count") or 0))
    except (TypeError, ValueError):
        pass

    return {
        "track_key": _clean_text(track_result.get("track_key")),
        "track_step_id": _clean_text(track_result.get("current_step_id")),
        "track_signal_text": " ".join(
            [
                _clean_text(track_result.get("goal")),
                *_collect_text(_as_list(track_result.get("unknowns")), "text"),
                *_collect_text(_as_list(track_readiness.get("blocking_gaps")), "text"),
                *_collect_text(_as_list(track_readiness.get("non_blocking_gaps")), "text"),
                _clean_text(_coerce_mapping(track_result.get("next_question")).get("text")),
            ]
        ).strip(),
        "artifact_type": _clean_text(artifact_result.get("artifact_type")),
        "artifact_status": _clean_text(artifact_result.get("status")),
        "artifact_field_keys": artifact_fields,
        "artifact_signal_text": " ".join(artifact_sections).strip(),
        "document_count": document_count,
    }


def build_intake_context(
    *,
    payload: dict[str, Any],
    domain_pack: dict[str, Any] | None,
) -> dict[str, Any]:
    pack_workflow = _coerce_mapping(_coerce_mapping(domain_pack).get("workflow"))
    prompt_summary_template_key = str(
        payload.get("prompt_summary_template_key")
        or pack_workflow.get("prompt_summary_template_key")
        or "flare_default"
    ).strip() or "flare_default"
    prompt_summary_template = payload.get("prompt_summary_template")
    if not isinstance(prompt_summary_template, dict):
        prompt_summary_template = pack_workflow.get("prompt_summary_template")
    if not isinstance(prompt_summary_template, dict):
        prompt_summary_template = {}

    intake_session_id = str(payload.get("intake_session_id") or "").strip()
    intake_session_state = str(payload.get("intake_session_state") or "").strip()
    intake_session_completed = bool(payload.get("intake_session_completed"))
    fields = {
        **_coerce_mapping(payload.get("confirmed_fields")),
        **_coerce_mapping(payload.get("fields")),
    }
    field_entities = _coerce_mapping(payload.get("field_entities"))
    sources = _coerce_mapping(payload.get("field_sources"))
    field_definitions = _normalize_field_definitions(payload=payload, domain_pack=domain_pack)
    required_fields, recommended_fields, optional_fields = _derive_field_lists(
        payload=payload,
        field_definitions=field_definitions,
    )
    domain_context = build_intake_domain_context(
        payload=payload,
        domain_pack=domain_pack,
        field_definitions=field_definitions,
        required_fields=required_fields,
        recommended_fields=recommended_fields,
        optional_fields=optional_fields,
    )
    field_definitions = merge_branch_field_definitions(
        field_definitions=field_definitions,
        policy=_coerce_mapping(domain_context.get("branching_chooser_policy")),
    )
    branch_required_fields, branch_recommended_fields, branch_optional_fields = _derive_field_lists(
        payload=payload,
        field_definitions=field_definitions,
    )
    domain_context = {
        **domain_context,
        "field_definitions": field_definitions,
        "required_fields": branch_required_fields,
        "recommended_fields": branch_recommended_fields,
        "optional_fields": branch_optional_fields,
    }
    required_fields = _normalize_field_list(domain_context.get("required_fields"))
    recommended_fields = _normalize_field_list(domain_context.get("recommended_fields"))
    optional_fields = _normalize_field_list(domain_context.get("optional_fields"))
    analysis_entry_threshold = float(domain_context.get("analysis_entry_threshold") or 0.8)

    structured_reasoning = _coerce_mapping(payload.get("structured_reasoning"))
    result_text_from_payload = _resolve_result_text_from_payload(payload)
    if result_text_from_payload and not any(
        isinstance(structured_reasoning.get(key), str) and structured_reasoning.get(key).strip()
        for key in ("result_text", "result_summary", "response_text", "final_answer_text")
    ):
        structured_reasoning = {
            **structured_reasoning,
            "result_text": result_text_from_payload,
        }
    question_context = _build_question_context(payload)
    reasoning_state = {
        "confirmed_fields": fields,
        "required_missing": payload.get("required_missing"),
        "question_progress": payload.get("question_progress"),
        "intake_session_id": intake_session_id,
        "intake_session_completed": intake_session_completed,
        "latest_input": _coerce_message_excerpt(payload),
        "branch_state": payload.get("intake_branch_state"),
        "active_branch_path": payload.get("active_branch_path"),
        "question_context": question_context,
    }
    latest_input = _coerce_message_excerpt(payload)
    understanding_state = build_intake_understanding_state(
        intake_session_id=intake_session_id,
        session_state=reasoning_state,
        latest_input=latest_input,
        domain_context=domain_context,
        structured_reasoning=structured_reasoning,
    )
    hypothesis_state = {
        "hypotheses": understanding_state.get("hypotheses", []),
        "inference_source": "understanding_layer",
    }
    hypotheses = [
        item for item in hypothesis_state.get("hypotheses", [])
        if isinstance(item, dict) and str(item.get("id") or "").strip()
    ]
    field_selection = _coerce_mapping(understanding_state.get("field_selection"))
    active_fields = _normalize_field_list(field_selection.get("active_fields"))
    deferred_fields = _normalize_field_list(field_selection.get("deferred_fields"))
    low_relevance_fields = _normalize_field_list(field_selection.get("low_relevance_fields"))
    active_required_fields = [field for field in required_fields if field in set(active_fields)]
    if not active_required_fields:
        active_required_fields = list(required_fields)
    primary_hypothesis = str((hypotheses[0] or {}).get("id") or "general_intake").strip() or "general_intake"

    intake_core_fields = payload.get("intake_core_fields")
    if not isinstance(intake_core_fields, list):
        intake_core_fields = list(active_required_fields)
    else:
        intake_core_fields = [field for field in _normalize_field_list(intake_core_fields) if field in active_required_fields]
    intake_supplementary_fields = payload.get("intake_supplementary_fields")
    if not isinstance(intake_supplementary_fields, list):
        intake_supplementary_fields = list(_normalize_field_list([*recommended_fields, *deferred_fields]))
    else:
        intake_supplementary_fields = [field for field in _normalize_field_list(intake_supplementary_fields) if field in recommended_fields]
    analysis_enrichment_fields = payload.get("analysis_enrichment_fields")
    if not isinstance(analysis_enrichment_fields, list):
        analysis_enrichment_fields = list(optional_fields)
    else:
        analysis_enrichment_fields = [field for field in _normalize_field_list(analysis_enrichment_fields) if field in optional_fields]

    return {
        "analysis_enrichment_fields": analysis_enrichment_fields,
        "analysis_entry_threshold": analysis_entry_threshold,
        "active_fields": active_fields,
        "active_required_fields": active_required_fields,
        "deferred_fields": deferred_fields,
        "domain_context": domain_context,
        "field_definitions": field_definitions,
        "field_entities": field_entities,
        "field_selection": field_selection,
        "fields": fields,
        "hypotheses": hypotheses,
        "intake_core_fields": intake_core_fields,
        "intake_session_completed": intake_session_completed,
        "intake_session_id": intake_session_id,
        "intake_session_state": intake_session_state,
        "intake_supplementary_fields": intake_supplementary_fields,
        "low_relevance_fields": low_relevance_fields,
        "optional_fields": optional_fields,
        "primary_hypothesis": primary_hypothesis,
        "prompt_summary_template": prompt_summary_template,
        "prompt_summary_template_key": prompt_summary_template_key,
        "question_context": question_context,
        "reasoning_state": reasoning_state,
        "recommended_fields": recommended_fields,
        "required_fields": required_fields,
        "sources": sources,
        "structured_reasoning": structured_reasoning,
        "understanding_state": understanding_state,
    }


__all__ = ["build_intake_context"]
