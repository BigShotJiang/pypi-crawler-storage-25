"""Requirement-intake next-action templates."""

from __future__ import annotations

from typing import Any


_REQUIREMENT_INTAKE_NEXT_ACTIONS: list[dict[str, Any]] = [
    {
        "action_key": "continue_collection",
        "label": "继续梳理",
        "target_mode": "requirement_intake",
        "priority": 1,
        "status": "blocked",
        "reason": "当前已有可推进的需求版本，也可以继续补充关键字段。",
        "description": "继续补充关键字段，提升需求清晰度。",
    },
    {
        "action_key": "handoff_to_sourcing",
        "label": "进入智能寻源",
        "target_mode": "intelligent_sourcing",
        "priority": 2,
        "status": "available",
        "reason": "可基于当前需求进入智能寻源，并显式保留待补充项。",
        "description": "切换到候选匹配与风险摘要，缺口会作为假设或待确认项保留。",
    },
    {
        "action_key": "investigate_evidence",
        "label": "先检索证据",
        "target_mode": "requirement_intake",
        "priority": 3,
        "status": "available",
        "reason": "信息不足，建议先检索证据再继续梳理。",
        "description": "触发证据检索回合，补充事实依据与来源。",
        "payload": {
            "target_mode": "requirement_intake",
            "action_key": "investigate_evidence",
            "prefill_prompt": "请先基于当前信息做一次证据检索，并给出来源与摘要。",
        },
    },
]


__all__ = ["_REQUIREMENT_INTAKE_NEXT_ACTIONS"]
