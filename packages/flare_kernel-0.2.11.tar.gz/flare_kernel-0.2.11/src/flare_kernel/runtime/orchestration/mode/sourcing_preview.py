"""Preview event assembly for unconfirmed intelligent sourcing."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.canvas_sourcing_contract import (
    with_canvas_sourcing_contract_meta,
)
from flare_kernel.runtime.orchestration.mode.canvas_state import _build_canvas_state_payload
from flare_kernel.runtime.orchestration.mode.shared import (
    _coerce_message_excerpt,
    _resolve_workflow_alias,
)
from flare_kernel.runtime.orchestration.sourcing.event_payloads import resolve_sourcing_status


def _candidate_count(rows: list[dict[str, Any]]) -> int:
    return sum(1 for row in rows if row.get("result_role") == "candidate")


def build_sourcing_preview_events(
    *,
    mode_key: str,
    session_id: str,
    payload: dict[str, Any],
    base_fields: dict[str, Any],
    base_collected: list[str],
    base_missing: list[str],
    base_total: int,
    base_progress: float,
    candidate_rows: list[dict[str, Any]],
    source_meta: dict[str, Any],
    confirm_actions: list[dict[str, Any]],
    parameter_draft: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], str]:
    """Assemble preview events before sourcing is confirmed.

    Args:
        mode_key: Active workflow mode key.
        session_id: Current chat or run session identifier.
        payload: Canonical orchestration payload for the current turn.
        base_fields: Collected intake fields used by sourcing.
        base_collected: Names of fields already collected.
        base_missing: Names of fields still missing.
        base_total: Total expected field count for progress calculation.
        base_progress: Current collection progress ratio.
        candidate_rows: Reference candidate rows available before confirmation.
        source_meta: Source trace metadata from the sourcing runtime.
        confirm_actions: Actions that can confirm entry into sourcing.
        parameter_draft: Deterministic handoff draft to attach to events/actions.

    Returns:
        A tuple of assembled events, resolved actions, and mode state.
    """
    resolved_actions = [
        {
            **action,
            "payload": {
                **(action.get("payload") if isinstance(action.get("payload"), dict) else {}),
                **parameter_draft,
            },
        }
        for action in confirm_actions
    ]
    preview_payload = with_canvas_sourcing_contract_meta({
        "mode_key": mode_key,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "message_excerpt": _coerce_message_excerpt(payload),
        "missing": base_missing,
        "base_fields": list(base_fields.keys()),
        "base_collected": base_collected,
        "base_missing": base_missing,
        "base_total": base_total,
        "base_progress": base_progress,
        "base_ready_for_matching": False,
        "mode_state": "collecting",
        "candidate_count": _candidate_count(candidate_rows),
        "is_placeholder": True,
        "required_missing": payload.get("required_missing", []),
        "recommended_missing": payload.get("recommended_missing", []),
        "optional_missing": payload.get("optional_missing", []),
        "actions": resolved_actions,
        "confirm_action": resolved_actions[0] if resolved_actions else {},
        "candidates": candidate_rows,
        **parameter_draft,
        "summary": "已先给出一批检索参考，用户提供更多关键信息后可继续匹配候选供应商。",
        "source_meta": source_meta,
        "source_status": resolve_sourcing_status(payload, len(candidate_rows)),
        "render_hint": "sourcing_candidates",
    })
    next_actions_payload = {
        "mode_key": mode_key,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "message_excerpt": _coerce_message_excerpt(payload),
        "mode_state": "collecting",
        "render_hint": "next_actions",
        "summary": (
            f"已先提供 {_candidate_count(candidate_rows)} 条候选供应商，"
            "用户提供更多关键信息后可继续收敛。"
            if _candidate_count(candidate_rows)
            else "已完成检索收口，当前只有资料参考，确认后再进入供应商寻源。"
        ),
        "next_actions": resolved_actions,
        "actions": resolved_actions,
        "confirm_action": resolved_actions[0] if resolved_actions else {},
        **parameter_draft,
    }
    canvas_state_payload = _build_canvas_state_payload(
        mode_key=mode_key,
        session_id=session_id,
        payload=payload,
        progress=min(0.8, base_progress if base_progress > 0 else 0.5),
        collected=base_collected,
        missing=base_missing,
        sourcing_candidate_count=_candidate_count(candidate_rows),
    )
    events: list[dict[str, Any]] = []
    if candidate_rows:
        sourcing_candidates_event = _resolve_workflow_alias(
            payload,
            namespace="events",
            name="sourcing_candidates",
            default="sourcing_candidates",
        )
        events.append(
            {
                "event_type": sourcing_candidates_event,
                "step_id": sourcing_candidates_event,
                "agent": "ModeOrchestration",
                "mode_key": mode_key,
                "payload": preview_payload,
            }
        )
    events.extend(
        [
            {
                "event_type": "next_actions",
                "step_id": "next_actions",
                "agent": "ModeOrchestration",
                "mode_key": mode_key,
                "payload": next_actions_payload,
            },
            {
                "event_type": "canvas_state",
                "step_id": "canvas_state",
                "agent": "ModeOrchestration",
                "mode_key": mode_key,
                "payload": canvas_state_payload,
            },
        ]
    )
    return events, resolved_actions, "collecting"


__all__ = ["build_sourcing_preview_events"]
