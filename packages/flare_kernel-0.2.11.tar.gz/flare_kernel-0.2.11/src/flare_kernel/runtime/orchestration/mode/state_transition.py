"""Mode-state transition helpers for mode orchestration."""

from __future__ import annotations

from typing import Any

from flare_engines.decision import advance_mode_state as advance_mode_state_from_engine
from flare_engines.decision.mode_resolution import build_mode_registry_from_workflow
from flare_kernel.runtime.orchestration.mode.shared import _coerce_mapping


def resolve_mode_state_with_engine(
    *,
    mode_key: str,
    mode_runtime: dict[str, str],
    mode_events: list[dict[str, Any]],
    payload: dict[str, Any],
    domain_pack: dict[str, Any] | None,
    fallback_state: str,
) -> str:
    if mode_key != "intelligent_sourcing":
        return fallback_state

    workflow_raw = _coerce_mapping(_coerce_mapping(domain_pack).get("workflow"))
    mode_registry = build_mode_registry_from_workflow(workflow_raw)
    if mode_registry is None:
        payload_workflow = _coerce_mapping(payload.get("workflow"))
        mode_registry = build_mode_registry_from_workflow(payload_workflow)
    if mode_registry is None:
        return fallback_state

    current_state = str(mode_runtime.get("mode_state") or "").strip() or None
    resolved_state = fallback_state

    for event in mode_events:
        if not isinstance(event, dict):
            continue
        event_type = event.get("event_type")
        if not isinstance(event_type, str) or not event_type.strip():
            continue
        try:
            transition = advance_mode_state_from_engine(
                mode_key=mode_key,
                current_state=current_state,
                event_type=event_type,
                mode_registry=mode_registry,
            )
        except ValueError:
            return fallback_state

        if transition.advanced:
            current_state = transition.next_state
            resolved_state = transition.next_state

    return resolved_state


__all__ = ["resolve_mode_state_with_engine"]
