"""Question lifecycle projection for requirement-intake orchestration."""

from __future__ import annotations

from typing import Any


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _question_answer_payload(payload: dict[str, Any]) -> dict[str, Any]:
    answer = payload.get("question_answer")
    return answer if isinstance(answer, dict) else {}


def _answer_value(answer: dict[str, Any]) -> str:
    return _clean_text(
        answer.get("raw_value")
        or answer.get("field_value")
        or answer.get("selected_option_value")
    )


def _resolve_status(
    *,
    payload: dict[str, Any],
    current_question: dict[str, Any] | None,
    terminal_intake: bool,
) -> str:
    """Resolve canonical lifecycle status without owning question selection.

    The planner has already decided whether a new `current_question` exists.
    This helper only classifies the projected question contract so downstream
    surfaces can distinguish active, answered, stale, and completed states.  It
    treats matching answered fields as answered, mismatched revisions on the
    same field as stale, and terminal intake as completed.  It does not decide
    which field should be asked next.
    """
    if terminal_intake:
        return "completed"
    answer = _question_answer_payload(payload)
    answer_field = _clean_text(answer.get("field_key"))
    current = current_question if isinstance(current_question, dict) else {}
    current_field = _clean_text(current.get("field_key"))
    if answer_field and _answer_value(answer) and not current:
        return "answered"
    if answer_field and current_field and answer_field == current_field and _answer_value(answer):
        answer_revision = _clean_text(answer.get("question_revision") or answer.get("revision"))
        current_revision = _clean_text(current.get("question_revision") or current.get("revision"))
        if answer_revision and current_revision and answer_revision != current_revision:
            return "stale"
        return "answered"
    return "active" if current else "idle"


def build_question_lifecycle(
    *,
    payload: dict[str, Any],
    current_question: dict[str, Any] | None,
    terminal_intake: bool,
) -> dict[str, Any]:
    """Build the backend-owned question lifecycle projection.

    The returned object is intentionally flat and redundant: consumers can read
    `status`, boolean flags, or active/answered identifiers without reconstructing
    workflow meaning from scattered payload fields.  Timestamp fields are copied
    from explicit payload values when available; this layer does not generate
    wall-clock time so orchestration remains deterministic in tests and replay.
    """
    current = current_question if isinstance(current_question, dict) else {}
    answer = _question_answer_payload(payload)
    status = _resolve_status(payload=payload, current_question=current_question, terminal_intake=terminal_intake)
    question_id = _clean_text(current.get("question_id") or answer.get("question_id"))
    question_revision = _clean_text(
        current.get("question_revision")
        or current.get("revision")
        or answer.get("question_revision")
        or answer.get("revision")
        or payload.get("question_revision")
    )
    field_key = _clean_text(current.get("field_key") or answer.get("field_key"))
    issued_at = _clean_text(current.get("issued_at") or payload.get("question_issued_at"))
    answered_at = _clean_text(answer.get("answered_at") or payload.get("question_answered_at"))
    return {
        "status": status,
        "question_active": status == "active",
        "question_answered": status == "answered",
        "question_stale": status == "stale",
        "question_completed": status == "completed",
        "question_id": question_id,
        "question_revision": question_revision,
        "field_key": field_key,
        "issued_at": issued_at,
        "answered_at": answered_at,
        "answer_source": "question_answer" if answer else "",
    }


def attach_question_lifecycle(
    *,
    current_question: dict[str, Any] | None,
    lifecycle: dict[str, Any],
) -> dict[str, Any] | None:
    """Attach lifecycle metadata to an emitted current-question payload.

    Frontend chooser code already honors `question_status`; keeping this field
    in sync with the backend lifecycle lets UI surfaces render or suppress the
    chooser without inventing freshness rules.  The original question payload is
    copied rather than mutated so callers can keep the orchestration data flow
    explicit.
    """
    if not isinstance(current_question, dict):
        return None
    enriched = dict(current_question)
    status = _clean_text(lifecycle.get("status"))
    if status:
        enriched["question_status"] = status
    if _clean_text(lifecycle.get("issued_at")):
        enriched["issued_at"] = _clean_text(lifecycle.get("issued_at"))
    enriched["question_lifecycle"] = dict(lifecycle)
    return enriched


__all__ = ["attach_question_lifecycle", "build_question_lifecycle"]
