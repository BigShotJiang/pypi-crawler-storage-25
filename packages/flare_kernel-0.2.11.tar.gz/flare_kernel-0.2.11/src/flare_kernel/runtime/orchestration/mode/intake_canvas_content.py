"""Prompt-context content placeholder for requirement-intake Canvas.

This module must not author business summaries. Requirement summaries are
model-authored artifacts generated after completion and merged into Canvas as
backend events. This helper only provides a minimal placeholder while that
artifact is unavailable.
"""

from __future__ import annotations

from typing import Any

_CANVAS_SUMMARY_PLACEHOLDER = "需求梳理摘要\n\n摘要生成中。"


def build_intake_canvas_content(*, collected_rows: list[dict[str, Any]]) -> str:
    """Build the initial Canvas body before a model-authored summary exists.

    The collected rows remain available in `canvas_state.collected`; duplicating
    them here as prose would turn this formatter into a deterministic summary
    generator. Model-authored summary content is appended later as a Canvas
    state revision once provider output has been normalized.
    """

    del collected_rows
    return _CANVAS_SUMMARY_PLACEHOLDER


__all__ = ["build_intake_canvas_content"]
