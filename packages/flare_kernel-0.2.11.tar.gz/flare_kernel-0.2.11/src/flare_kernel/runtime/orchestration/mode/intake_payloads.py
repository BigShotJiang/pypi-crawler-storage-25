"""Requirement-intake event payload assembly."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.intake_action_resolution import (
    build_resolved_actions,
)
from flare_kernel.runtime.orchestration.mode.intake_draft_payload import (
    build_requirement_draft_payload,
)
from flare_kernel.runtime.orchestration.mode.intake_next_actions_payload import (
    build_next_actions_payload,
)
from flare_kernel.runtime.orchestration.mode.intake_progress_payload import (
    build_field_progress_payload,
)
from flare_kernel.runtime.orchestration.mode.intake_question_progress import (
    build_question_progress,
)


def build_intake_payloads(
    *,
    mode_key: str,
    session_id: str,
    payload: dict[str, Any],
    context: dict[str, Any],
    coverage: dict[str, Any],
    question: dict[str, Any],
    flow_state: str,
    can_handoff_to_sourcing: bool,
    required_missing_count: int,
    readiness: dict[str, Any],
    analyzability_score: float,
    understanding_summary: str,
) -> dict[str, Any]:
    current_question = question["current_question"]
    question_progress = build_question_progress(
        current_question=current_question,
        active_required_fields=context["active_required_fields"],
        intake_session_id=context["intake_session_id"],
        question_progress_resumed=question["question_progress_resumed"],
    )
    field_progress_payload = build_field_progress_payload(
        mode_key=mode_key,
        session_id=session_id,
        payload=payload,
        context=context,
        coverage=coverage,
        question=question,
        question_progress=question_progress,
        flow_state=flow_state,
        can_handoff_to_sourcing=can_handoff_to_sourcing,
        required_missing_count=required_missing_count,
        readiness=readiness,
        analyzability_score=analyzability_score,
        understanding_summary=understanding_summary,
    )
    requirement_draft_payload = build_requirement_draft_payload(
        mode_key=mode_key,
        session_id=session_id,
        payload=payload,
        context=context,
    )
    if context["intake_session_completed"]:
        resolved_actions = []
    else:
        resolved_actions = build_resolved_actions(
            payload=payload,
            mode_key=mode_key,
            can_handoff_to_sourcing=can_handoff_to_sourcing,
            first_missing_key=question["first_missing_key"],
            missing=question["missing"],
            current_question=current_question,
        )
    next_actions_payload = build_next_actions_payload(
        mode_key=mode_key,
        session_id=session_id,
        payload=payload,
        context=context,
        coverage=coverage,
        question=question,
        question_progress=question_progress,
        resolved_actions=resolved_actions,
        flow_state=flow_state,
        can_handoff_to_sourcing=can_handoff_to_sourcing,
        required_missing_count=required_missing_count,
        readiness=readiness,
        analyzability_score=analyzability_score,
        understanding_summary=understanding_summary,
    )
    return {
        "field_progress_payload": field_progress_payload,
        "next_actions_payload": next_actions_payload,
        "requirement_draft_payload": requirement_draft_payload,
        "resolved_actions": resolved_actions,
    }


__all__ = ["build_intake_payloads"]
