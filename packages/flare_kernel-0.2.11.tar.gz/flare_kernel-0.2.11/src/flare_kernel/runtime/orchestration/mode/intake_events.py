"""Requirement-intake event orchestration."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.api import (
    build_user_visible_intake_response,
    evaluate_readiness,
)
from flare_kernel.runtime.orchestration.mode.intake_canvas_events import (
    build_intake_events_from_payloads,
)
from flare_kernel.runtime.orchestration.mode.intake_context import build_intake_context
from flare_kernel.runtime.orchestration.mode.intake_coverage import (
    build_intake_coverage,
    resolve_intake_question_missing,
)
from flare_kernel.runtime.orchestration.mode.intake_payloads import build_intake_payloads
from flare_kernel.runtime.orchestration.mode.intake_question import build_intake_question


def _is_terminal_command(payload: dict[str, Any]) -> bool:
    command = str(payload.get("command") or payload.get("action_command") or "").strip().lower()
    return command in {"apply", "implement"}


def build_requirement_intake_events(
    *,
    mode_key: str,
    session_id: str,
    payload: dict[str, Any],
    domain_pack: dict[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], str]:
    context = build_intake_context(payload=payload, domain_pack=domain_pack)
    terminal_intake = mode_key == "requirement_intake" and _is_terminal_command(payload)
    if terminal_intake:
        context["intake_session_completed"] = True
        context["intake_session_state"] = "applied"
    coverage = build_intake_coverage(
        payload=payload,
        fields=context["fields"],
        active_required_fields=context["active_required_fields"],
        recommended_fields=context["recommended_fields"],
        optional_fields=context["optional_fields"],
        field_definitions=context["field_definitions"],
    )
    question_missing = resolve_intake_question_missing(
        payload=payload,
        coverage=coverage,
        intake_supplementary_fields=context["intake_supplementary_fields"],
    )
    question = build_intake_question(
        payload=payload,
        intake_session_id=context["intake_session_id"],
        missing=question_missing,
        reasoning_state=context["reasoning_state"],
        domain_context=context["domain_context"],
        hypotheses=context["hypotheses"],
        field_selection=context["field_selection"],
        structured_reasoning=context["structured_reasoning"],
        understanding_state=context["understanding_state"],
        field_definitions_by_key=coverage["field_definitions_by_key"],
    )

    readiness = evaluate_readiness(
        session_state=context["reasoning_state"],
        domain_context=context["domain_context"],
        field_selection=context["field_selection"],
        hypotheses=context["hypotheses"],
        threshold=context["analysis_entry_threshold"],
    )
    has_active_collection_question = bool(question["current_question"]) and bool(question["missing"])
    can_handoff_to_sourcing = (
        bool(readiness.get("analysis_entry_eligible"))
        and not terminal_intake
        and not has_active_collection_question
    )
    flow_state = "applied" if terminal_intake else ("drafting" if can_handoff_to_sourcing else "collecting")
    if not context["intake_session_state"]:
        context["intake_session_state"] = "analysis_ready" if can_handoff_to_sourcing else "workspace_live_updating"
    required_missing_count = len(coverage["missing"])
    analyzability_score = float(
        readiness.get("analyzability_score")
        or context["understanding_state"].get("analyzability_score")
        or 0.0
    )
    understanding_summary = build_user_visible_intake_response(
        understanding_state=context["understanding_state"],
        current_question=question["current_question"] if isinstance(question["current_question"], dict) else None,
        confirmed_fields=context["fields"],
        missing_fields=question["missing"],
        field_definitions_by_key=coverage["field_definitions_by_key"],
        readiness=readiness,
    )
    event_payloads = build_intake_payloads(
        mode_key=mode_key,
        session_id=session_id,
        payload=payload,
        context=context,
        coverage=coverage,
        question=question,
        flow_state=flow_state,
        can_handoff_to_sourcing=can_handoff_to_sourcing,
        required_missing_count=required_missing_count,
        readiness=readiness,
        analyzability_score=analyzability_score,
        understanding_summary=understanding_summary,
    )
    events = build_intake_events_from_payloads(
        mode_key=mode_key,
        session_id=session_id,
        payload=payload,
        context=context,
        coverage=coverage,
        question=question,
        can_handoff_to_sourcing=can_handoff_to_sourcing,
        understanding_summary=understanding_summary,
        field_progress_payload=event_payloads["field_progress_payload"],
        next_actions_payload=event_payloads["next_actions_payload"],
        requirement_draft_payload=event_payloads["requirement_draft_payload"],
    )
    return (
        events,
        event_payloads["resolved_actions"],
        "applied" if terminal_intake else ("drafting" if can_handoff_to_sourcing else "collecting"),
    )


__all__ = ["build_requirement_intake_events"]
