"""Requirement-intake next-action resolution."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.intake_actions import (
    _REQUIREMENT_INTAKE_NEXT_ACTIONS,
)
from flare_kernel.runtime.orchestration.mode.shared import (
    _coerce_mapping,
    _resolve_workflow_alias,
)


def build_resolved_actions(
    *,
    payload: dict[str, Any],
    mode_key: str,
    can_handoff_to_sourcing: bool,
    first_missing_key: str,
    missing: list[str],
    current_question: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    continue_action = dict(_REQUIREMENT_INTAKE_NEXT_ACTIONS[0])
    handoff_action = dict(_REQUIREMENT_INTAKE_NEXT_ACTIONS[1])
    investigate_action = dict(_REQUIREMENT_INTAKE_NEXT_ACTIONS[2])
    handoff_action["action_key"] = _resolve_workflow_alias(
        payload,
        namespace="actions",
        name="handoff_to_sourcing",
        default=str(handoff_action.get("action_key") or "handoff_to_sourcing"),
    )
    confirm_action = {
        "action_key": "confirm_plan",
        "label": "生成分析初稿",
        "target_mode": "analysis_mode",
        "priority": 1,
        "status": "available",
        "command": "generate_analysis",
        "reason": "可基于当前信息生成带待补充项的分析初稿。",
        "payload": {
            "target_mode": "analysis_mode",
            "action_key": "confirm_plan",
            "command": "generate_analysis",
            "prefill_prompt": "请基于当前已确认信息生成分析初稿，明确区分已确认信息、资料线索、假设与待补充项。",
        },
    }
    confirm_action["action_key"] = _resolve_workflow_alias(
        payload,
        namespace="actions",
        name="confirm_plan",
        default=str(confirm_action.get("action_key") or "confirm_plan"),
    )
    implement_action = {
        "action_key": "implement",
        "label": "确认当前梳理",
        "target_mode": mode_key,
        "priority": 4,
        "status": "available",
        "command": "implement",
        "reason": "确认当前需求梳理版本，结束本轮梳理。",
        "payload": {
            "target_mode": mode_key,
            "action_key": "implement",
            "command": "implement",
        },
    }
    retrieval_config = _coerce_mapping(payload.get("retrieval_config"))
    can_investigate_evidence = bool(first_missing_key) and retrieval_config.get("enabled") is not False
    if can_handoff_to_sourcing:
        continue_action["status"] = "available"
        continue_action["reason"] = "当前需求清晰度已可推进，也可继续完善建议字段。"
        continue_action["target_field"] = ""
        continue_action["branch_impact"] = "不会阻塞后续流程。"
        handoff_action["status"] = "available"
        handoff_action["reason"] = "当前需求清晰度已可支持智能寻源。"
        handoff_action["target_field"] = ""
        handoff_action["branch_impact"] = "将进入候选匹配与对比流程。"
        resolved_actions = [confirm_action, continue_action, handoff_action, implement_action]
    else:
        continue_action["status"] = "available"
        continue_action["reason"] = "仍有关键字段建议补充；也可先生成带待补充项的分析初稿。"
        continue_action["blocking_reason"] = "关键字段不足会降低计划稳定性，但不阻塞分析初稿。"
        continue_action["target_field"] = first_missing_key
        continue_action["branch_impact"] = "会影响后续计划边界与检索范围。"
        handoff_action["status"] = "available_with_gaps"
        handoff_action["reason"] = "可进入智能寻源，但会携带待补充字段与假设。"
        handoff_action["target_field"] = first_missing_key
        handoff_action["branch_impact"] = "候选匹配会受当前缺口影响，需要在结果中显式标注假设。"
        confirm_action["reason"] = "字段尚未补齐，但可先生成带待补充项的分析初稿。"
        confirm_action["payload"]["draft_with_missing"] = True
        confirm_action["payload"]["missing_fields"] = missing
        implement_action["status"] = "available_with_gaps"
        implement_action["reason"] = "可确认当前版本并保留待补充项，后续分析或寻源会携带这些假设。"
        implement_action["payload"]["missing_fields"] = missing
        resolved_actions = [confirm_action, continue_action, handoff_action, implement_action]
        if can_investigate_evidence:
            investigate_action["status"] = "available"
            investigate_action["reason"] = "信息不足，建议先检索证据再继续梳理。"
            investigate_action["target_field"] = first_missing_key
            investigate_action["branch_impact"] = "先补证据可降低误判风险。"
            resolved_actions.append(investigate_action)
    if current_question:
        continue_action["payload"] = {
            "target_mode": mode_key,
            "action_key": "continue_collection",
            "field_key": current_question.get("field_key"),
            "question_answer": {
                "field_key": current_question.get("field_key"),
                "field_value": "",
            },
        }
    return resolved_actions


__all__ = ["build_resolved_actions"]
