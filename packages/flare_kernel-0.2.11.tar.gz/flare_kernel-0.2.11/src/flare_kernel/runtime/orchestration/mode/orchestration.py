"""Mode orchestration entrypoint for the kernel runtime."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.intake_events import (
    build_requirement_intake_events as _build_requirement_intake_events,
)
from flare_kernel.runtime.orchestration.mode.sourcing_events import (
    build_intelligent_sourcing_events as _build_intelligent_sourcing_events,
)
from flare_kernel.runtime.orchestration.mode.state_transition import (
    resolve_mode_state_with_engine as _resolve_mode_state_with_engine,
)

def _normalize_active_mode_key(raw_mode_key: Any) -> str:
    return str(raw_mode_key or "unknown").strip().lower().replace("-", "_").replace(" ", "_") or "unknown"


def build_mode_orchestration(
    *,
    trace_id: str,
    session_id: str,
    payload: dict[str, Any],
    mode_runtime: dict[str, str],
    agent_runtime: dict[str, Any],
    skill_runtime: dict[str, Any],
    domain_pack: dict[str, Any] | None,
) -> dict[str, Any]:
    del trace_id, agent_runtime, skill_runtime

    mode_key = _normalize_active_mode_key(mode_runtime.get("mode_key"))
    effective_mode_runtime = {**mode_runtime, "mode_key": mode_key}

    if mode_key in {"requirement_intake", "analysis_mode"}:
        mode_events, next_actions, mode_state = _build_requirement_intake_events(
            mode_key=mode_key,
            session_id=session_id,
            payload=payload,
            domain_pack=domain_pack,
        )
    elif mode_key == "intelligent_sourcing":
        mode_events, next_actions, mode_state = _build_intelligent_sourcing_events(
            mode_key=mode_key,
            session_id=session_id,
            payload=payload,
        )
    else:
        mode_events = []
        next_actions = []
        mode_state = effective_mode_runtime.get("mode_state", "unknown")

    resolved_mode_state = _resolve_mode_state_with_engine(
        mode_key=mode_key,
        mode_runtime=effective_mode_runtime,
        mode_events=mode_events,
        payload=payload,
        domain_pack=domain_pack,
        fallback_state=mode_state,
    )
    runtime_payload = dict(payload) if isinstance(payload, dict) else {}

    return {
        "mode_key": mode_key,
        "mode_state": resolved_mode_state,
        "mode_events": mode_events,
        "next_actions": next_actions,
        "payload": runtime_payload,
    }
