"""Requirement-intake question progress payload helper."""

from __future__ import annotations

from typing import Any


def build_question_progress(
    *,
    current_question: dict[str, Any] | None,
    active_required_fields: list[str],
    intake_session_id: str,
    question_progress_resumed: bool,
) -> dict[str, Any]:
    return {
        "current": current_question.get("step_index") if isinstance(current_question, dict) else 0,
        "total": current_question.get("step_total") if isinstance(current_question, dict) else (len(active_required_fields) or 0),
        "intake_session_id": intake_session_id,
        "resumed": question_progress_resumed,
    }


__all__ = ["build_question_progress"]
