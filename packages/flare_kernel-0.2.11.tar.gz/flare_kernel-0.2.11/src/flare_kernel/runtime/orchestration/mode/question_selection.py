"""Question selection helpers for requirement-intake orchestration."""

from __future__ import annotations

from typing import Any


def _select_best_missing_field(*, missing: list[str], field_scores: dict[str, Any]) -> str:
    if not missing:
        return ""
    best_key = ""
    best_score = float("-inf")
    for field_key in missing:
        try:
            score = float(field_scores.get(field_key) or 0.0)
        except (TypeError, ValueError):
            score = 0.0
        if score > best_score:
            best_score = score
            best_key = field_key
    return best_key


def _resolve_question_text_for_current_field(
    *,
    question_kind: str,
    field_key: str,
    planned_question_text: str,
    planned_target_fields: list[str],
    field_definition: dict[str, Any],
    fallback_label: str,
) -> str:
    del fallback_label
    normalized_question_kind = str(question_kind or "").strip()
    normalized_field_key = str(field_key or "").strip()
    normalized_planned_text = str(planned_question_text or "").strip()
    definition_question = str(field_definition.get("question") or "").strip()

    if normalized_question_kind == "branch":
        return normalized_planned_text or definition_question

    if not normalized_planned_text:
        return definition_question

    if normalized_field_key and planned_target_fields and normalized_field_key not in set(planned_target_fields):
        return definition_question or normalized_planned_text

    return normalized_planned_text


__all__ = ["_resolve_question_text_for_current_field", "_select_best_missing_field"]
