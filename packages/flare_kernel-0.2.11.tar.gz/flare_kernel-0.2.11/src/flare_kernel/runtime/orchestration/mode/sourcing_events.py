"""Intelligent sourcing event assembly for mode orchestration."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.shared import (
    _coerce_mapping,
    _resolve_sourcing_base_field_keys,
)
from flare_kernel.runtime.orchestration.mode.sourcing_actions import (
    build_sourcing_confirm_actions,
)
from flare_kernel.runtime.orchestration.mode.sourcing_preview import (
    build_sourcing_preview_events,
)
from flare_kernel.runtime.orchestration.mode.sourcing_report import (
    build_sourcing_report_events,
)
from flare_kernel.runtime.orchestration.sourcing.event_payloads import (
    build_source_meta,
    resolve_sourcing_rows,
)
from flare_kernel.runtime.orchestration.sourcing.parameter_draft import (
    build_sourcing_parameter_draft,
)


def build_intelligent_sourcing_events(
    *,
    mode_key: str,
    session_id: str,
    payload: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], str]:
    sourcing_confirmed = bool(payload.get("sourcing_confirmed", False))
    base_field_keys = _resolve_sourcing_base_field_keys(payload)
    confirm_actions = build_sourcing_confirm_actions(payload)
    base_fields = _coerce_mapping(payload.get("base_fields"))
    base_collected = [key for key, value in base_fields.items() if value not in (None, "", [], {})]
    base_missing = [key for key in base_field_keys if key not in base_fields]
    base_total = max(len(base_fields), len(base_collected) + len(base_missing))
    base_progress = len(base_collected) / base_total if base_total else 0.0
    candidate_rows = resolve_sourcing_rows(payload, shortlist=False)
    source_meta = build_source_meta(payload)
    parameter_draft = build_sourcing_parameter_draft(base_fields=base_fields, payload=payload)

    if not sourcing_confirmed:
        return build_sourcing_preview_events(
            mode_key=mode_key,
            session_id=session_id,
            payload=payload,
            base_fields=base_fields,
            base_collected=base_collected,
            base_missing=base_missing,
            base_total=base_total,
            base_progress=base_progress,
            candidate_rows=candidate_rows,
            source_meta=source_meta,
            confirm_actions=confirm_actions,
            parameter_draft=parameter_draft,
        )
    return build_sourcing_report_events(
        mode_key=mode_key,
        session_id=session_id,
        payload=payload,
        base_fields=base_fields,
        base_collected=base_collected,
        base_missing=base_missing,
        base_total=base_total,
        base_progress=base_progress,
        candidate_rows=candidate_rows,
        source_meta=source_meta,
        parameter_draft=parameter_draft,
    )


__all__ = ["build_intelligent_sourcing_events"]
