"""Sourcing candidate explanation and citation assembly.

DOC HELPER — SRC-05 candidate explainability boundary.
This module attaches normalized reasons, evidence refs, unresolved checks, and
source summary to already-normalized candidates. It does not rank candidates,
call providers, persist records, or render UI.
"""

from __future__ import annotations

from typing import Any


def _text(value: Any) -> str:
    return str(value or "").strip()


def _text_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [text for item in value if (text := _text(item))]


def _confidence_reasons(candidate: dict[str, Any]) -> list[str]:
    detail = candidate.get("confidence_detail")
    if not isinstance(detail, dict):
        return []
    return _text_list(detail.get("reasons"))


def _match_reasons(candidate: dict[str, Any]) -> list[str]:
    reasons = _text_list(candidate.get("match_reasons") or candidate.get("reasons"))
    if not reasons:
        snippet = _text(candidate.get("snippet") or candidate.get("summary"))
        reasons = [snippet[:120]] if snippet else []
    for reason in _confidence_reasons(candidate):
        if reason not in reasons:
            reasons.append(reason)
    return reasons[:5]


def _normalize_evidence_ref(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "source": _text(item.get("source") or item.get("source_type")),
        "url": _text(item.get("url") or item.get("canonical_url") or item.get("source_url")),
        "title": _text(item.get("title") or item.get("source_title")),
        "snippet": _text(item.get("snippet") or item.get("content") or item.get("summary"))[:220],
        "collected_at": _text(item.get("collected_at") or item.get("timestamp") or item.get("publish_time")),
        "strength": _text(item.get("strength") or item.get("confidence")),
    }


def _evidence_refs(candidate: dict[str, Any]) -> list[dict[str, Any]]:
    raw_refs = candidate.get("evidence_refs") or candidate.get("references")
    if isinstance(raw_refs, list):
        refs = [_normalize_evidence_ref(item) for item in raw_refs if isinstance(item, dict)]
        refs = [ref for ref in refs if ref["title"] or ref["snippet"] or ref["url"]]
        if refs:
            return refs
    ref = _normalize_evidence_ref(candidate)
    return [ref] if ref["title"] or ref["snippet"] or ref["url"] else []


def _unresolved_checks(*, candidate: dict[str, Any], reasons: list[str], refs: list[dict[str, Any]]) -> list[str]:
    checks = _text_list(candidate.get("unresolved_checks"))
    if not reasons and "missing_match_reason" not in checks:
        checks.append("missing_match_reason")
    if not refs and "missing_evidence_ref" not in checks:
        checks.append("missing_evidence_ref")
    if not _text(candidate.get("confidence") or candidate.get("score") or candidate.get("match_score")):
        if "missing_confidence" not in checks:
            checks.append("missing_confidence")
    return checks


def _source_summary(
    *,
    candidate: dict[str, Any],
    reasons: list[str],
    refs: list[dict[str, Any]],
    unresolved_checks: list[str],
) -> dict[str, Any]:
    return {
        "source_type": _text(candidate.get("source_type") or candidate.get("source")),
        "source_title": _text(candidate.get("source_title") or candidate.get("title")),
        "canonical_url": _text(candidate.get("canonical_url") or candidate.get("url") or candidate.get("source_url")),
        "confidence": _text(candidate.get("confidence") or candidate.get("score") or candidate.get("match_score")),
        "primary_reason": reasons[0] if reasons else "",
        "evidence_count": len(refs),
        "has_match_reason": bool(reasons),
        "has_evidence": bool(refs),
        "unresolved_checks": unresolved_checks,
    }


def enrich_sourcing_candidate(candidate: dict[str, Any]) -> dict[str, Any]:
    """Attach stable explanation fields to a normalized sourcing candidate."""
    row = dict(candidate)
    reasons = _match_reasons(row)
    refs = _evidence_refs(row)
    unresolved_checks = _unresolved_checks(candidate=row, reasons=reasons, refs=refs)
    row["match_reasons"] = reasons
    row["evidence_refs"] = refs
    row["unresolved_checks"] = unresolved_checks
    if not _text(row.get("source_title")):
        row["source_title"] = _text(row.get("title"))
    if not _text(row.get("canonical_url")):
        row["canonical_url"] = _text(row.get("url") or row.get("source_url"))
    row["source_summary"] = _source_summary(
        candidate=row,
        reasons=reasons,
        refs=refs,
        unresolved_checks=unresolved_checks,
    )
    return row


def enrich_sourcing_candidates(candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Attach explanation fields to each candidate row."""
    return [enrich_sourcing_candidate(item) for item in candidates if isinstance(item, dict)]


__all__ = ["enrich_sourcing_candidate", "enrich_sourcing_candidates"]
