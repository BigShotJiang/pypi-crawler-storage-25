"""Source priority decision helpers for sourcing orchestration."""

from __future__ import annotations

from functools import reduce
from typing import Any

from flare_kernel.runtime.orchestration.sourcing.provider_health import (
    apply_provider_health_to_priority,
    build_provider_health_registry,
)


_SOURCE_SCOPE_MAP = {
    "local": ("local",),
    "web": ("web",),
    "hybrid": ("local", "web"),
}


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _clean_scope(value: Any) -> str:
    scope = _clean_text(value).lower()
    return scope if scope in _SOURCE_SCOPE_MAP else "hybrid"


def _source_key(value: Any) -> str:
    source = _clean_text(value).lower()
    if source in {"instance_db", "instance", "database", "db"}:
        return "instance_db"
    if source in {"mcp", "mcp_knowledge", "mcp_tool"}:
        return "mcp"
    if source in {"local", "internal", "knowledge"}:
        return "local"
    if source in {"web", "external", "gateway", "provider"}:
        return "web"
    return source


def _source_allowed(source: str, allowed: tuple[str, ...]) -> bool:
    if source == "instance_db":
        return "local" in allowed
    if source == "mcp":
        return "local" in allowed
    return source in allowed


def _configured_sources(provider_config: dict[str, Any], allowed: tuple[str, ...]) -> list[dict[str, Any]]:
    raw_items = provider_config.get("source_priority") or provider_config.get("sources")
    if not isinstance(raw_items, list):
        return []
    rows: list[dict[str, Any]] = []
    for raw_item in raw_items:
        item = raw_item if isinstance(raw_item, dict) else {"source": raw_item}
        source = _source_key(item.get("source") or item.get("key") or item.get("name"))
        if not _source_allowed(source, allowed):
            continue
        enabled = item.get("enabled")
        rows.append(
            {
                "source": source,
                "enabled": enabled is not False,
                "priority": len(rows) + 1,
                "reason": _clean_text(item.get("reason")) or "configured_priority",
            }
        )
    return rows


def _mcp_row_from_config(
    *,
    provider_config: dict[str, Any],
    allowed: tuple[str, ...],
    existing_sources: set[str],
    priority: int,
) -> dict[str, Any]:
    mcp_config = provider_config.get("mcp")
    if not isinstance(mcp_config, dict) or "mcp" in existing_sources or not _source_allowed("mcp", allowed):
        return {}
    return {
        "source": "mcp",
        "enabled": mcp_config.get("enabled") is True,
        "priority": priority,
        "reason": _clean_text(mcp_config.get("reason")) or "mcp_config",
    }


def _instance_db_config(provider_config: dict[str, Any]) -> dict[str, Any]:
    for key in ("instance_db", "instance_database", "database"):
        value = provider_config.get(key)
        if isinstance(value, dict):
            return value
    return {}


def _instance_db_row_from_config(
    *,
    provider_config: dict[str, Any],
    allowed: tuple[str, ...],
    existing_sources: set[str],
    priority: int,
) -> dict[str, Any]:
    instance_config = _instance_db_config(provider_config)
    if (
        not instance_config
        or "instance_db" in existing_sources
        or not _source_allowed("instance_db", allowed)
    ):
        return {}
    has_records = any(
        isinstance(instance_config.get(key), list)
        for key in ("records", "items", "candidates", "suppliers")
    )
    return {
        "source": "instance_db",
        "enabled": instance_config.get("enabled") is not False and has_records,
        "priority": priority,
        "reason": _clean_text(instance_config.get("reason")) or "instance_db_config",
    }


def build_source_priority_decision(
    *,
    source_scope: str,
    provider_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    config = provider_config if isinstance(provider_config, dict) else {}
    scope = _clean_scope(source_scope)
    allowed = _SOURCE_SCOPE_MAP[scope]
    priority = _configured_sources(config, allowed)
    using_default_priority = not priority
    if not priority:
        priority = [
            {"source": source, "enabled": True, "priority": index, "reason": f"source_scope:{scope}"}
            for index, source in enumerate(allowed, start=1)
        ]
    if using_default_priority:
        instance_db_row = _instance_db_row_from_config(
            provider_config=config,
            allowed=allowed,
            existing_sources={str(item.get("source") or "") for item in priority if isinstance(item, dict)},
            priority=len(priority) + 1,
        )
        if instance_db_row:
            priority.insert(0, {**instance_db_row, "priority": 1})
            priority = [{**item, "priority": index} for index, item in enumerate(priority, start=1)]
    mcp_row = _mcp_row_from_config(
        provider_config=config,
        allowed=allowed,
        existing_sources={str(item.get("source") or "") for item in priority if isinstance(item, dict)},
        priority=len(priority) + 1,
    )
    if mcp_row:
        priority.append(mcp_row)
    provider_health = build_provider_health_registry(config)
    priority = apply_provider_health_to_priority(priority, provider_health)
    enabled_sources = [item["source"] for item in priority if item.get("enabled")]
    selected = enabled_sources[0] if enabled_sources else ""
    return {
        "selected_source": selected,
        "source_priority": priority,
        "fallbacks": enabled_sources[1:],
        "provider_health": list(provider_health.values()),
        "router_reason": _clean_text(config.get("router_reason")) or f"source_scope:{scope}",
    }


def resolve_selected_source(*, source_breakdown: dict[str, int], fallback: str) -> str:
    instance_db_count = int(source_breakdown.get("instance_db") or 0)
    local_count = int(source_breakdown.get("local") or 0)
    mcp_count = int(source_breakdown.get("mcp") or 0)
    web_count = int(source_breakdown.get("web") or 0)
    if (instance_db_count > 0 or local_count > 0 or mcp_count > 0) and web_count > 0:
        return "hybrid"
    if instance_db_count > 0:
        return "instance_db"
    if local_count > 0:
        return "local"
    if mcp_count > 0:
        return "mcp"
    if web_count > 0:
        return "web"
    return _clean_text(fallback)


def _source_enabled_pair(item: dict[str, Any]) -> tuple[str, bool]:
    return _source_key(item.get("source")), item.get("enabled") is not False


def _merge_first_enabled(acc: dict[str, bool], pair: tuple[str, bool]) -> dict[str, bool]:
    source, enabled = pair
    if source and source not in acc:
        acc[source] = enabled
    return acc


def _source_enabled_index(priority: Any) -> dict[str, bool]:
    if not isinstance(priority, list):
        return {}
    items = filter(lambda item: isinstance(item, dict), priority)
    return reduce(_merge_first_enabled, map(_source_enabled_pair, items), {})


def is_source_enabled(*, priority_decision: dict[str, Any], source: str) -> bool:
    source_key = _source_key(source)
    enabled_index = _source_enabled_index(priority_decision.get("source_priority"))
    return enabled_index.get(source_key, False)


def build_provider_trace_entry(*, source: str, status: str, hit_count: int, reason: str = "") -> dict[str, Any]:
    return {
        "source": _source_key(source),
        "status": _clean_text(status),
        "hit_count": max(0, int(hit_count or 0)),
        "reason": _clean_text(reason),
    }


__all__ = [
    "build_provider_trace_entry",
    "build_source_priority_decision",
    "is_source_enabled",
    "resolve_selected_source",
]
