"""Web provider invocation helpers for sourcing orchestration."""

from __future__ import annotations

from inspect import Parameter, signature
from typing import Any, Callable

from flare_kernel.runtime.orchestration.sourcing.source_priority import build_provider_trace_entry


def call_web_search(
    *,
    search_web_sources_fn: Callable[..., Any],
    query: str,
    top_k: int,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    provider_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    params = signature(search_web_sources_fn).parameters
    kwargs: dict[str, Any] = {
        "query": query,
        "top_k": top_k,
        "trace_id": trace_id,
        "session_id": session_id,
        "project_id": project_id,
        "user_id": user_id,
    }
    accepts_kwargs = any(map(lambda param: param.kind == Parameter.VAR_KEYWORD, params.values()))
    if "include_trace" in params or accepts_kwargs:
        kwargs["include_trace"] = True
    if "provider_config" in params or accepts_kwargs:
        kwargs["provider_config"] = provider_config or {}
    try:
        raw_response = search_web_sources_fn(**kwargs)
    except Exception:
        return {
            "items": [],
            "provider_trace": [
                build_provider_trace_entry(source="web", status="failed", hit_count=0, reason="adapter_failed")
            ],
            "selected_provider": "",
            "fallbacks": [],
        }
    if isinstance(raw_response, dict):
        items = raw_response.get("items")
        trace = raw_response.get("provider_trace")
        fallbacks = raw_response.get("fallbacks")
        return {
            "items": items if isinstance(items, list) else [],
            "provider_trace": trace if isinstance(trace, list) else [],
            "selected_provider": str(raw_response.get("selected_provider") or "").strip(),
            "fallbacks": fallbacks if isinstance(fallbacks, list) else [],
        }
    if isinstance(raw_response, list):
        return {"items": raw_response, "provider_trace": [], "selected_provider": "", "fallbacks": []}
    return {"items": [], "provider_trace": [], "selected_provider": "", "fallbacks": []}


__all__ = ["call_web_search"]
