"""Sourcing provider health projection helpers.

DOC HELPER — SRC-02 provider gate contract boundary.
This module normalizes provider health/gate state for sourcing orchestration.
It is pure logic: no provider calls, persistence, transport, or UI decisions.
"""

from __future__ import annotations

from typing import Any

_KNOWN_STATUSES = {"ok", "degraded", "disabled", "failed", "unavailable", "unknown"}
_DISABLING_STATUSES = {"disabled", "failed", "unavailable"}


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _source_key(value: Any) -> str:
    source = _clean_text(value).lower()
    if source in {"instance_db", "instance", "database", "db"}:
        return "instance_db"
    if source in {"mcp", "mcp_knowledge", "mcp_tool"}:
        return "mcp"
    if source in {"local", "internal", "knowledge"}:
        return "local"
    if source in {"web", "external", "gateway", "provider"}:
        return "web"
    return source


def _health_status(value: Any) -> str:
    status = _clean_text(value).lower()
    return status if status in _KNOWN_STATUSES else "unknown"


def _health_payloads(provider_config: dict[str, Any]) -> list[dict[str, Any]]:
    raw = (
        provider_config.get("provider_health")
        or provider_config.get("provider_health_registry")
        or provider_config.get("health")
    )
    if isinstance(raw, list):
        return [item for item in raw if isinstance(item, dict)]
    if isinstance(raw, dict):
        return [
            {"source": source, **_as_dict(value)}
            if isinstance(value, dict)
            else {"source": source, "status": value}
            for source, value in raw.items()
        ]
    return []


def build_provider_health_registry(provider_config: dict[str, Any] | None) -> dict[str, dict[str, Any]]:
    """Normalize provider health config into a source-keyed registry.

    Args:
        provider_config: Provider configuration that may contain
            `provider_health`, `provider_health_registry`, or `health`.

    Returns:
        Mapping from normalized source key to a health row containing `source`,
        `status`, and `reason`.
    """
    registry: dict[str, dict[str, Any]] = {}
    for item in _health_payloads(_as_dict(provider_config)):
        source = _source_key(item.get("source") or item.get("key") or item.get("name"))
        if not source:
            continue
        registry[source] = {
            "source": source,
            "status": _health_status(item.get("status")),
            "reason": _clean_text(item.get("reason")),
        }
    return registry


def apply_provider_health_to_priority(
    source_priority: list[dict[str, Any]],
    provider_health: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """Apply provider health gates to source-priority rows.

    Args:
        source_priority: Ordered source priority rows from routing policy.
        provider_health: Source-keyed health registry from provider config.

    Returns:
        Source priority rows with disabled health states applied and optional
        `health_status` / `health_reason` fields added.
    """
    rows: list[dict[str, Any]] = []
    for item in source_priority:
        source = _source_key(item.get("source"))
        health = provider_health.get(source, {})
        status = _health_status(health.get("status"))
        disabled_by_health = status in _DISABLING_STATUSES
        reason = _clean_text(health.get("reason")) or f"health_{status}"
        rows.append(
            {
                **item,
                "enabled": item.get("enabled") is not False and not disabled_by_health,
                **({"health_status": status, "health_reason": reason} if health else {}),
            }
        )
    return rows


def _trace_health(trace: dict[str, Any]) -> dict[str, Any]:
    source = _source_key(trace.get("source") or trace.get("provider"))
    status = _health_status(trace.get("status"))
    reason = _clean_text(trace.get("reason"))
    if status in {"ok", "degraded", "disabled", "failed", "unavailable"}:
        return {"source": source, "status": status, "reason": reason}
    if status == "unknown" and _clean_text(trace.get("status")).lower() in {"completed", "success", "empty"}:
        return {"source": source, "status": "ok", "reason": reason}
    if _clean_text(trace.get("status")).lower() == "skipped" and reason == "adapter_unavailable":
        return {"source": source, "status": "unavailable", "reason": reason}
    if _clean_text(trace.get("status")).lower() == "skipped" and reason == "source_disabled":
        return {"source": source, "status": "disabled", "reason": reason}
    if _clean_text(trace.get("status")).lower() in {"error", "timeout"}:
        return {"source": source, "status": "failed", "reason": reason}
    return {"source": source, "status": "ok", "reason": reason}


def _merge_health_rows(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    registry: dict[str, dict[str, Any]] = {}
    for item in rows:
        source = _source_key(item.get("source"))
        if source:
            registry[source] = item
    return registry


def build_provider_health_projection(
    *,
    source_priority: Any,
    provider_trace: Any,
    provider_health: Any,
) -> list[dict[str, Any]]:
    """Build the provider health projection for sourcing outputs.

    Args:
        source_priority: Source priority rows used by sourcing routing.
        provider_trace: Runtime provider trace rows from the search execution.
        provider_health: Configured or pre-projected provider health rows.

    Returns:
        List of provider health rows with `source`, `status`, `enabled`,
        optional `priority`, and `reason`.
    """
    configured = provider_health if isinstance(provider_health, dict) else _merge_health_rows(
        [item for item in provider_health if isinstance(item, dict)] if isinstance(provider_health, list) else []
    )
    trace_registry = _merge_health_rows([
        _trace_health(item) for item in provider_trace if isinstance(item, dict)
    ] if isinstance(provider_trace, list) else [])
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in source_priority if isinstance(source_priority, list) else []:
        if not isinstance(item, dict):
            continue
        source = _source_key(item.get("source"))
        health = configured.get(source) or trace_registry.get(source) or {}
        status = _health_status(health.get("status")) if health else ("disabled" if item.get("enabled") is False else "ok")
        rows.append(
            {
                "source": source,
                "status": status,
                "enabled": item.get("enabled") is not False and status not in _DISABLING_STATUSES,
                "priority": item.get("priority"),
                "reason": _clean_text(health.get("reason")) or _clean_text(item.get("health_reason") or item.get("reason")),
            }
        )
        seen.add(source)
    for source, health in trace_registry.items():
        if source and source not in seen:
            rows.append({**health, "enabled": _health_status(health.get("status")) not in _DISABLING_STATUSES})
    return rows


__all__ = [
    "apply_provider_health_to_priority",
    "build_provider_health_projection",
    "build_provider_health_registry",
]
