"""Instance DB adapter invocation helpers for sourcing orchestration."""

from __future__ import annotations

from inspect import Parameter, signature
from typing import Any, Callable

from flare_kernel.runtime.orchestration.sourcing.source_priority import build_provider_trace_entry

_SUPPLIER_IDENTITY_KEYS = (
    "supplier_id",
    "supplier_name",
    "vendor_id",
    "vendor_name",
    "company_id",
    "company_name",
)


def _accepts_param(fn: Callable[..., Any], name: str) -> bool:
    params = signature(fn).parameters
    accepts_kwargs = any(map(lambda param: param.kind == Parameter.VAR_KEYWORD, params.values()))
    return name in params or accepts_kwargs


def _adapter_kwargs(
    *,
    search_instance_records_fn: Callable[..., Any],
    query: str,
    top_k: int,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    provider_config: dict[str, Any] | None,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "query": query,
        "top_k": top_k,
        "trace_id": trace_id,
        "session_id": session_id,
        "project_id": project_id,
        "user_id": user_id,
    }
    if _accepts_param(search_instance_records_fn, "provider_config"):
        kwargs["provider_config"] = provider_config or {}
    return kwargs


def _has_supplier_identity(item: dict[str, Any]) -> bool:
    return any(str(item.get(key) or "").strip() for key in _SUPPLIER_IDENTITY_KEYS)


def _normalize_instance_items(items: Any) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in items if isinstance(items, list) else []:
        if not isinstance(item, dict):
            continue
        row = {**item, "source_type": "instance_db"}
        if "result_role" not in row and _has_supplier_identity(row):
            row["result_role"] = "candidate"
        rows.append(row)
    return rows


def _trace_or_default(trace: Any, *, hit_count: int) -> list[dict[str, Any]]:
    if isinstance(trace, list):
        return [item for item in trace if isinstance(item, dict)]
    return [
        build_provider_trace_entry(
            source="instance_db",
            status="completed",
            hit_count=hit_count,
            reason="instance_db_search",
        )
    ]


def call_instance_db_search(
    *,
    search_instance_records_fn: Callable[..., Any] | None,
    query: str,
    top_k: int,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    provider_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if not callable(search_instance_records_fn):
        return {
            "items": [],
            "provider_trace": [
                build_provider_trace_entry(
                    source="instance_db",
                    status="skipped",
                    hit_count=0,
                    reason="adapter_unavailable",
                )
            ],
        }
    try:
        raw_response = search_instance_records_fn(
            **_adapter_kwargs(
                search_instance_records_fn=search_instance_records_fn,
                query=query,
                top_k=top_k,
                trace_id=trace_id,
                session_id=session_id,
                project_id=project_id,
                user_id=user_id,
                provider_config=provider_config,
            )
        )
    except Exception:
        return {
            "items": [],
            "provider_trace": [
                build_provider_trace_entry(
                    source="instance_db",
                    status="failed",
                    hit_count=0,
                    reason="adapter_failed",
                )
            ],
        }
    if isinstance(raw_response, dict):
        items = _normalize_instance_items(raw_response.get("items"))
        return {"items": items, "provider_trace": _trace_or_default(raw_response.get("provider_trace"), hit_count=len(items))}
    if isinstance(raw_response, list):
        items = _normalize_instance_items(raw_response)
        return {
            "items": items,
            "provider_trace": _trace_or_default(None, hit_count=len(items)),
        }
    return {
        "items": [],
        "provider_trace": [
            build_provider_trace_entry(
                source="instance_db",
                status="failed",
                hit_count=0,
                reason="invalid_adapter_response",
            )
        ],
    }


__all__ = ["call_instance_db_search"]
