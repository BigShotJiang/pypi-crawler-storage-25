"""Standard sourcing observation assembly."""

from __future__ import annotations

from typing import Any

_FAILED_STATUSES = {"failed", "error", "timeout"}
_BLOCKED_STATUSES = {"blocked"}


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    return list(value) if isinstance(value, list) else []


def _as_int(value: Any) -> int:
    try:
        return int(value or 0)
    except Exception:
        return 0


def _observation(
    *,
    stage_id: str,
    status: str,
    source: str = "",
    hit_count: int = 0,
    reason: str = "",
    summary: str = "",
    terminal: bool = False,
) -> dict[str, Any]:
    return {
        "observation_type": "sourcing",
        "stage_id": stage_id,
        "status": status,
        "source": source,
        "hit_count": max(0, hit_count),
        "reason": reason,
        "summary": summary,
        "terminal": terminal,
    }


def _trace_matches_source(trace: dict[str, Any], aliases: set[str]) -> bool:
    source = _clean_text(trace.get("source")).lower()
    provider = _clean_text(trace.get("provider")).lower()
    return source in aliases or provider in aliases


def _source_trace_summary(provider_trace: list[Any], aliases: set[str]) -> tuple[str, int, str]:
    traces = [_as_dict(item) for item in provider_trace if _trace_matches_source(_as_dict(item), aliases)]
    if not traces:
        return "completed", 0, ""
    statuses = {_clean_text(item.get("status")).lower() for item in traces}
    hit_count = sum(_as_int(item.get("hit_count")) for item in traces)
    reason = "; ".join(_clean_text(item.get("reason")) for item in traces if _clean_text(item.get("reason")))
    if statuses & _FAILED_STATUSES:
        return "failed", hit_count, reason
    if statuses & _BLOCKED_STATUSES:
        return "blocked", hit_count, reason
    return "completed", hit_count, reason


def resolve_sourcing_final_status(result: dict[str, Any]) -> str:
    provider_trace = _as_list(result.get("provider_trace"))
    returned_count = _as_int(result.get("returned_count"))
    if bool(result.get("blocked")):
        return "blocked"
    statuses = {_clean_text(_as_dict(item).get("status")).lower() for item in provider_trace}
    if statuses & _FAILED_STATUSES:
        return "partial" if returned_count > 0 else "failed"
    return "completed" if returned_count > 0 else "partial"


def build_sourcing_observations(result: dict[str, Any]) -> list[dict[str, Any]]:
    source_breakdown = _as_dict(result.get("source_breakdown"))
    provider_trace = _as_list(result.get("provider_trace"))
    selected_source = _clean_text(result.get("selected_source"))
    returned_count = _as_int(result.get("returned_count"))
    final_status = resolve_sourcing_final_status(result)
    context_patch = _as_dict(result.get("context_patch"))
    has_context_patch = bool(_as_list(context_patch.get("sourcing_results")))

    source_stages = [
        ("search_instance_db", "instance_db", {"instance_db"}),
        ("search_mcp", "mcp", {"mcp"}),
        ("search_local_knowledge", "local", {"local", "knowledge", "knowledge_base"}),
        ("search_external_fallback", "web", {"web", "intranet_gateway", "domestic_gateway", "public_ddg"}),
    ]
    observations = [
        _observation(stage_id="prepare_context", status="completed", summary="query_ready"),
        _observation(stage_id="route_sources", status="completed", source=selected_source, summary="sources_routed"),
    ]
    for stage_id, source, aliases in source_stages:
        status, hit_count, reason = _source_trace_summary(provider_trace, aliases)
        observations.append(
            _observation(
                stage_id=stage_id,
                status=status,
                source=source,
                hit_count=hit_count or _as_int(source_breakdown.get(source)),
                reason=reason,
                summary="source_checked",
            )
        )
    observations.extend(
        [
            _observation(stage_id="rerank_candidates", status="completed", hit_count=returned_count, summary="candidates_ranked"),
            _observation(stage_id="build_shortlist", status="completed", hit_count=len(_as_list(result.get("shortlist"))), summary="shortlist_ready"),
            _observation(
                stage_id="persist_context_patch",
                status="completed" if has_context_patch else "partial",
                hit_count=len(_as_list(context_patch.get("sourcing_results"))),
                summary="context_patch_ready" if has_context_patch else "context_patch_missing",
            ),
            _observation(
                stage_id="finalize",
                status=final_status,
                source=selected_source,
                hit_count=returned_count,
                reason=_clean_text(result.get("reason")),
                summary="sourcing_finalized",
                terminal=True,
            ),
        ]
    )
    return observations


__all__ = ["build_sourcing_observations", "resolve_sourcing_final_status"]
