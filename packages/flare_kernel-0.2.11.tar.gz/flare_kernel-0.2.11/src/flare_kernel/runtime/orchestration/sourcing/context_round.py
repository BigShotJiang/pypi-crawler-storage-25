"""Session-context round assembly for sourcing results.

DOC HELPER — SRC-06 sourcing-result persistence boundary.
This module only assembles the canonical sourcing round that can be appended
to session context. It does not own provider routing, persistence IO, analysis
generation, or frontend display decisions.
"""

from __future__ import annotations

from typing import Any


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def build_sourcing_context_round(
    *,
    retrieval_run_id: str,
    round_value: Any,
    query: str,
    sourcing_task_kind: str,
    source_scope: str,
    requested_top_k: int,
    returned_count: int,
    new_count: int,
    has_more: bool,
    next_top_k: int,
    timestamp: str,
    items: list[dict[str, Any]],
    shortlist: list[dict[str, Any]],
    source_breakdown: dict[str, Any],
    selected_source: str,
    source_priority: Any,
    fallbacks: Any,
    provider_health: Any,
    provider_trace: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build a persisted sourcing round for session context reuse."""
    return {
        "id": retrieval_run_id,
        "round": round_value if isinstance(round_value, int) else 0,
        "retrieval_run_id": retrieval_run_id,
        "query": query,
        "sourcing_task_kind": sourcing_task_kind,
        "source_scope": source_scope,
        "requested_top_k": requested_top_k,
        "returned_count": returned_count,
        "new_count": new_count,
        "has_more": has_more,
        "next_top_k": next_top_k,
        "timestamp": timestamp,
        "items": items,
        "shortlist": shortlist,
        "source_breakdown": source_breakdown,
        "selected_source": selected_source,
        "source_priority": _as_list(source_priority),
        "fallbacks": _as_list(fallbacks),
        "provider_health": _as_list(provider_health),
        "provider_trace": provider_trace,
    }


__all__ = ["build_sourcing_context_round"]
