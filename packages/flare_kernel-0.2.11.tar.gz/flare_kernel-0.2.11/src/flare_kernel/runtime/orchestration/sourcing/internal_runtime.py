"""Internal-source collection for sourcing orchestration."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.runtime.orchestration.sourcing.instance_db_runtime import call_instance_db_search
from flare_kernel.runtime.orchestration.sourcing.mcp_runtime import call_mcp_search
from flare_kernel.runtime.orchestration.sourcing.source_priority import build_provider_trace_entry, is_source_enabled


def _append_response(target: list[dict[str, Any]], trace: list[dict[str, Any]], response: dict[str, Any]) -> None:
    target.extend(item for item in response.get("items", []) if isinstance(item, dict))
    trace.extend(item for item in response.get("provider_trace", []) if isinstance(item, dict))


def _local_search_response(
    *,
    search_knowledge_records_fn: Callable[..., list[dict[str, Any]]],
    trace_id: str,
    project_id: str,
    user_id: str,
    query: str,
    top_k: int,
    source_ids: list[str] | None,
) -> dict[str, Any]:
    try:
        rows = search_knowledge_records_fn(
            trace_id=trace_id,
            project_id=project_id,
            user_id=user_id,
            query=query,
            top_k=top_k,
            min_score=0.0,
            source_ids=source_ids,
        )
    except Exception:
        rows = []
        status = "failed"
        reason = "knowledge_search_failed"
    else:
        status = "completed"
        reason = "knowledge_search"
    items = rows if isinstance(rows, list) else []
    return {
        "items": items,
        "provider_trace": [
            build_provider_trace_entry(source="local", status=status, hit_count=len(items), reason=reason)
        ],
    }


def collect_internal_sourcing_hits(
    *,
    clean_scope: str,
    priority_decision: dict[str, Any],
    search_knowledge_records_fn: Callable[..., list[dict[str, Any]]],
    search_instance_records_fn: Callable[..., Any] | None,
    search_mcp_records_fn: Callable[..., Any] | None,
    query: str,
    top_k: int,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    provider_config: dict[str, Any] | None,
    source_ids: list[str] | None,
) -> dict[str, Any]:
    items: list[dict[str, Any]] = []
    provider_trace: list[dict[str, Any]] = []
    if clean_scope not in {"local", "hybrid"}:
        return {"items": items, "provider_trace": provider_trace}

    if is_source_enabled(priority_decision=priority_decision, source="instance_db"):
        _append_response(
            items,
            provider_trace,
            call_instance_db_search(
                search_instance_records_fn=search_instance_records_fn,
                query=query,
                top_k=top_k,
                trace_id=trace_id,
                session_id=session_id,
                project_id=project_id,
                user_id=user_id,
                provider_config=provider_config,
            ),
        )
    if is_source_enabled(priority_decision=priority_decision, source="mcp"):
        _append_response(
            items,
            provider_trace,
            call_mcp_search(
                search_mcp_records_fn=search_mcp_records_fn,
                query=query,
                top_k=top_k,
                trace_id=trace_id,
                session_id=session_id,
                project_id=project_id,
                user_id=user_id,
                provider_config=provider_config,
            ),
        )
    if is_source_enabled(priority_decision=priority_decision, source="local"):
        _append_response(
            items,
            provider_trace,
            _local_search_response(
                search_knowledge_records_fn=search_knowledge_records_fn,
                trace_id=trace_id,
                project_id=project_id,
                user_id=user_id,
                query=query,
                top_k=top_k,
                source_ids=source_ids,
            ),
        )
    return {"items": items, "provider_trace": provider_trace}


__all__ = ["collect_internal_sourcing_hits"]
