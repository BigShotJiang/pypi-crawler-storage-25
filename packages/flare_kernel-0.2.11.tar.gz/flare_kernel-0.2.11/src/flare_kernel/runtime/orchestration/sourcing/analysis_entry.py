"""Sourcing-to-analysis handoff assembly.

DOC HELPER — SRC-07 analysis handoff boundary.
This module carries candidates, shortlist, supplier-profile input, and sourcing
trace into the generic analysis action. It does not generate analysis content,
select templates, call providers, persist edits, or render frontend state.
"""

from __future__ import annotations

from typing import Any


def _text(value: Any) -> str:
    return str(value or "").strip()


def _dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _is_candidate_row(candidate: dict[str, Any]) -> bool:
    role = _text(candidate.get("result_role") or candidate.get("sourcing_result_role"))
    if role:
        return role == "candidate"
    return bool(_text(candidate.get("supplier_id") or candidate.get("supplier_name")))


def _candidate_ref(candidate: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": _text(candidate.get("supplier_id") or candidate.get("result_id") or candidate.get("id")),
        "name": _text(candidate.get("supplier_name") or candidate.get("title")),
        "result_role": _text(candidate.get("result_role") or "candidate"),
        "source_type": _text(candidate.get("source_type") or candidate.get("source")),
        "source_domain": _text(candidate.get("source_domain")),
        "canonical_url": _text(candidate.get("canonical_url") or candidate.get("url")),
        "match_score": candidate.get("match_score") if candidate.get("match_score") is not None else candidate.get("score"),
        "confidence": _text(candidate.get("confidence")),
        "match_reasons": candidate.get("match_reasons") if isinstance(candidate.get("match_reasons"), list) else [],
        "evidence_refs": candidate.get("evidence_refs") if isinstance(candidate.get("evidence_refs"), list) else [],
    }


def build_supplier_profile_input(
    *,
    candidates: list[dict[str, Any]],
    shortlist: list[dict[str, Any]],
    parameter_draft: dict[str, Any],
    sourcing_trace: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build analysis-ready supplier profile input from sourcing outputs."""
    candidate_refs = [_candidate_ref(item) for item in candidates if isinstance(item, dict) and _is_candidate_row(item)]
    shortlist_refs = [_candidate_ref(item) for item in shortlist if isinstance(item, dict) and _is_candidate_row(item)]
    return {
        "source": "sourcing_candidates",
        "candidate_count": len(candidate_refs),
        "shortlist_count": len(shortlist_refs),
        "candidates": candidate_refs,
        "shortlist": shortlist_refs,
        "sourcing_parameters": parameter_draft.get("sourcing_parameters") if isinstance(parameter_draft.get("sourcing_parameters"), dict) else {},
        "criteria": parameter_draft.get("criteria") if isinstance(parameter_draft.get("criteria"), list) else [],
        "supplier_profile_draft": parameter_draft.get("supplier_profile_draft") if isinstance(parameter_draft.get("supplier_profile_draft"), dict) else {},
        "sourcing_trace": _dict(sourcing_trace),
    }


def _build_sourcing_trace(*, payload: dict[str, Any], source_meta: dict[str, Any] | None) -> dict[str, Any]:
    meta = _dict(source_meta)
    return {
        "source_meta": meta,
        "selected_source": _text(payload.get("selected_source") or meta.get("selected_source")),
        "source_priority": _list(payload.get("source_priority")) or _list(meta.get("source_priority")),
        "fallbacks": _list(payload.get("fallbacks")) or _list(meta.get("fallbacks")),
        "provider_trace": _list(payload.get("provider_trace")) or _list(meta.get("provider_trace")),
        "retrieval_batch": _text(
            payload.get("retrieval_batch")
            or payload.get("retrieval_run_id")
            or meta.get("retrieval_batch")
        ),
    }


def build_sourcing_analysis_action(
    *,
    payload: dict[str, Any],
    candidates: list[dict[str, Any]],
    shortlist: list[dict[str, Any]],
    parameter_draft: dict[str, Any],
    source_meta: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Build the next action that hands sourcing candidates into analysis."""
    candidate_rows = [item for item in candidates if isinstance(item, dict) and _is_candidate_row(item)]
    shortlist_rows = [item for item in shortlist if isinstance(item, dict) and _is_candidate_row(item)]
    if not candidate_rows and not shortlist_rows:
        return None
    sourcing_trace = _build_sourcing_trace(payload=payload, source_meta=source_meta)
    supplier_profile_input = build_supplier_profile_input(
        candidates=candidate_rows,
        shortlist=shortlist_rows,
        parameter_draft=parameter_draft,
        sourcing_trace=sourcing_trace,
    )
    analysis_route = payload.get("analysis_route") if isinstance(payload.get("analysis_route"), dict) else {}
    return {
        "action_key": "generate_analysis",
        "action_type": "next_step",
        "label": "生成分析",
        "target_mode": "analysis_mode",
        "command": "generate_analysis",
        "priority": 1,
        "status": "available",
        "reason": "当前候选、证据与约束已具备，可进入可编辑分析。",
        "description": "基于当前上下文、候选、证据、置信度与约束动态生成分析。",
        "payload": {
            "target_mode": "analysis_mode",
            "action_key": "generate_analysis",
            "command": "generate_analysis",
            "analysis_route": {
                "analysis_type": str(analysis_route.get("analysis_type") or "sourcing"),
                "template_id": str(analysis_route.get("template_id") or ""),
            },
            "message": str(payload.get("analysis_message") or "基于当前上下文生成分析。"),
            "sourcing_candidates": candidate_rows,
            "shortlist": shortlist_rows,
            "supplier_profile_input": supplier_profile_input,
            "sourcing_parameters": supplier_profile_input["sourcing_parameters"],
            "criteria": supplier_profile_input["criteria"],
            "supplier_profile_draft": supplier_profile_input["supplier_profile_draft"],
            "sourcing_trace": sourcing_trace,
            "project_id": payload.get("project_id"),
        },
    }


__all__ = ["build_sourcing_analysis_action", "build_supplier_profile_input"]
