"""Result window helpers for sourcing orchestration."""

from __future__ import annotations

from typing import Any


def resolve_max_top_k() -> int:
    import os

    raw = str(os.getenv("SOURCING_MAX_TOP_K", "100")).strip()
    try:
        value = int(raw)
    except (TypeError, ValueError):
        value = 100
    return max(1, min(value, 100))


def resolve_requested_top_k(top_k: int) -> int:
    return max(1, min(int(top_k), resolve_max_top_k()))


def resolve_result_id(item: dict[str, Any], index: int) -> str:
    for key in ("record_id", "raw_id", "source_id", "id", "canonical_url", "url", "title"):
        value = str(item.get(key) or "").strip()
        if value:
            return value
    return f"candidate-{index}"


def dedup_base_result_ids(base_result_ids: list[str] | None) -> list[str]:
    seen: set[str] = set()
    deduped: list[str] = []
    for item in base_result_ids or []:
        candidate = str(item or "").strip()
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        deduped.append(candidate)
    return deduped


def build_locked_rows(
    *,
    all_results: list[dict[str, Any]],
    base_result_ids: list[str],
    lock_existing_order: bool,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    keyed_results: dict[str, dict[str, Any]] = {}
    ordered_all: list[tuple[str, dict[str, Any]]] = []
    for index, item in enumerate(all_results, start=1):
        row = dict(item)
        row_id = resolve_result_id(row, index)
        row["result_id"] = row_id
        keyed_results[row_id] = row
        ordered_all.append((row_id, row))

    new_results = [row for row_id, row in ordered_all if row_id not in base_result_ids]
    if not lock_existing_order:
        return [row for _, row in ordered_all], new_results

    locked_existing = [keyed_results[row_id] for row_id in base_result_ids if row_id in keyed_results]
    return [*locked_existing, *new_results], new_results


__all__ = [
    "build_locked_rows",
    "dedup_base_result_ids",
    "resolve_max_top_k",
    "resolve_requested_top_k",
    "resolve_result_id",
]
