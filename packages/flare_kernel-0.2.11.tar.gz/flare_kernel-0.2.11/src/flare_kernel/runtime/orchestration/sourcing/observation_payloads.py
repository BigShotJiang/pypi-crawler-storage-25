"""Sourcing observation payload projection helpers."""

from __future__ import annotations

from typing import Any

_RUNNING_STATUSES = {"running", "in_progress", "pending"}


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    return list(value) if isinstance(value, list) else []


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _as_int(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except Exception:
        return 0


def _normalize_observation(value: Any) -> dict[str, Any]:
    item = _as_dict(value)
    if not item:
        return {}
    stage_id = _clean_text(item.get("stage_id"))
    status = _clean_text(item.get("status")).lower()
    if not stage_id and not status:
        return {}
    return {
        "observation_type": _clean_text(item.get("observation_type") or "sourcing"),
        "stage_id": stage_id,
        "status": status,
        "source": _clean_text(item.get("source")),
        "hit_count": _as_int(item.get("hit_count")),
        "reason": _clean_text(item.get("reason")),
        "summary": _clean_text(item.get("summary")),
        "terminal": bool(item.get("terminal")),
    }


def _normalize_observations(value: Any) -> list[dict[str, Any]]:
    observations: list[dict[str, Any]] = []
    for item in _as_list(value):
        normalized = _normalize_observation(item)
        if normalized:
            observations.append(normalized)
    return observations


def _last_relevant_observation(observations: list[dict[str, Any]]) -> dict[str, Any]:
    for item in reversed(observations):
        if _clean_text(item.get("status")).lower() in _RUNNING_STATUSES:
            return item
    for item in reversed(observations):
        if item.get("terminal") is True:
            return item
    return observations[-1] if observations else {}


def _resolve_final_status(*, source: dict[str, Any], observations: list[dict[str, Any]]) -> str:
    explicit = _clean_text(source.get("final_status")).lower()
    if explicit:
        return explicit
    for item in reversed(observations):
        if item.get("terminal") is True:
            return _clean_text(item.get("status")).lower()
    return ""


def build_sourcing_observation_meta(
    *,
    payload: dict[str, Any],
    latest_result: dict[str, Any],
) -> dict[str, Any]:
    """Project backend sourcing observations into source metadata."""
    search_payload = _as_dict(payload.get("sourcing_search"))
    source = search_payload or payload or latest_result
    observations = (
        _normalize_observations(search_payload.get("observations"))
        or _normalize_observations(payload.get("observations"))
        or _normalize_observations(latest_result.get("observations"))
    )
    current = _last_relevant_observation(observations)
    final_status = _resolve_final_status(source=source, observations=observations)
    return {
        "observations": observations,
        "current_stage": _clean_text(current.get("stage_id")),
        "current_status": _clean_text(current.get("status")).lower(),
        "final_status": final_status,
        "returned_count": _as_int(source.get("returned_count")),
    }


__all__ = ["build_sourcing_observation_meta"]
