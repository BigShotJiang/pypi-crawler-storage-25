"""Sourcing event payload normalization helpers.

DOC HELPER — SRC-05/SRC-06 sourcing event contract boundary.
This module normalizes candidate rows and source metadata from canonical
payload/session context. It does not infer workflow state, call providers,
persist data, or decide UI behavior.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.sourcing.observation_payloads import (
    build_sourcing_observation_meta,
)


_LIST_GROUP_VALUES = {"recommended", "backup", "pending_verify"}
_RESULT_ROLE_VALUES = {"candidate", "reference"}
_EXPLICIT_CANDIDATE_KEYS = (
    "supplier_id",
    "supplier_name",
    "vendor_id",
    "vendor_name",
    "company_id",
    "company_name",
)


def _coerce_text(value: Any) -> str:
    return str(value or "").strip()


def _coerce_float(value: Any) -> float | None:
    try:
        return float(value)
    except Exception:
        return None


def _coerce_int(value: Any) -> int | None:
    try:
        return int(value)
    except Exception:
        return None


def _coerce_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _coerce_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _coerce_str_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    normalized: list[str] = []
    for item in value:
        text = _coerce_text(item)
        if text:
            normalized.append(text)
    return normalized


def _coerce_evidence_refs(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    refs: list[dict[str, Any]] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        refs.append(
            {
                "source": _coerce_text(item.get("source")),
                "url": _coerce_text(item.get("url")),
                "title": _coerce_text(item.get("title")),
                "snippet": _coerce_text(item.get("snippet") or item.get("content")),
                "collected_at": _coerce_text(item.get("collected_at") or item.get("timestamp")),
                "strength": _coerce_text(item.get("strength")),
            }
        )
    return refs


def _fallback_evidence_refs(item: dict[str, Any]) -> list[dict[str, Any]]:
    return _coerce_evidence_refs([
        {
            "source": item.get("source") or item.get("source_type"),
            "url": item.get("canonical_url") or item.get("url") or item.get("source_url"),
            "title": item.get("source_title") or item.get("title") or item.get("supplier_name"),
            "snippet": item.get("snippet") or item.get("summary"),
            "collected_at": item.get("publish_time"),
            "strength": item.get("confidence"),
        }
    ])


def _coerce_risk_flags(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    flags: list[dict[str, Any]] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        flags.append(
            {
                "type": _coerce_text(item.get("type")),
                "level": _coerce_text(item.get("level")),
                "summary": _coerce_text(item.get("summary") or item.get("reason")),
                "source_url": _coerce_text(item.get("source_url") or item.get("url")),
            }
        )
    return flags


def _coerce_unresolved_checks(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    checks: list[str] = []
    for item in value:
        if isinstance(item, dict):
            text = _coerce_text(item.get("summary") or item.get("check") or item.get("title"))
        else:
            text = _coerce_text(item)
        if text:
            checks.append(text)
    return checks


def _normalize_list_group(value: Any) -> str:
    normalized = _coerce_text(value).lower()
    return normalized if normalized in _LIST_GROUP_VALUES else "pending_verify"


def _has_explicit_candidate_identity(item: dict[str, Any]) -> bool:
    """Check whether a row has explicit candidate identity.

    Args:
        item: Raw sourcing row.

    Returns:
        True when the row contains supplier/vendor/company identity fields.
    """
    return any(_coerce_text(item.get(key)) for key in _EXPLICIT_CANDIDATE_KEYS)


def _normalize_result_role(item: dict[str, Any]) -> str:
    """Normalize the result role for a sourcing row.

    Args:
        item: Raw sourcing row.

    Returns:
        `candidate` for supplier/vendor rows, otherwise `reference`.
    """
    explicit = _coerce_text(
        item.get("result_role")
        or item.get("sourcing_result_role")
        or item.get("row_role")
    ).lower()
    if explicit in _RESULT_ROLE_VALUES:
        return explicit
    if _has_explicit_candidate_identity(item):
        return "candidate"
    return "reference"


def _latest_session_sourcing_result(payload: dict[str, Any]) -> dict[str, Any]:
    session_context = _coerce_dict(payload.get("session_context"))
    rounds = _coerce_list(session_context.get("sourcing_results"))
    for item in reversed(rounds):
        if isinstance(item, dict):
            return item
    return {}


def _list_from_payload_or_round(
    payload: dict[str, Any],
    round_value: dict[str, Any],
    key: str,
) -> list[Any]:
    payload_value = payload.get(key)
    if isinstance(payload_value, list):
        return payload_value
    round_item = round_value.get(key)
    return round_item if isinstance(round_item, list) else []


def build_source_meta(payload: dict[str, Any]) -> dict[str, Any]:
    source_breakdown_payload = payload.get("source_breakdown")
    latest_result = _latest_session_sourcing_result(payload)
    source_breakdown = (
        source_breakdown_payload
        if isinstance(source_breakdown_payload, dict)
        else _coerce_dict(latest_result.get("source_breakdown"))
    )
    retrieval_batch = _coerce_text(
        payload.get("retrieval_batch")
        or payload.get("batch_id")
        or latest_result.get("retrieval_run_id")
        or latest_result.get("id")
    )
    observation_meta = build_sourcing_observation_meta(
        payload=payload,
        latest_result=latest_result,
    )
    return {
        "source_breakdown": {
            "instance_db": int(source_breakdown.get("instance_db") or 0),
            "local": int(source_breakdown.get("local") or 0),
            "mcp": int(source_breakdown.get("mcp") or 0),
            "web": int(source_breakdown.get("web") or 0),
        },
        "retrieval_batch": retrieval_batch,
        "query_profile": _coerce_text(
            payload.get("query_profile")
            or payload.get("context_profile")
            or latest_result.get("query")
        ),
        "selected_source": _coerce_text(
            payload.get("selected_source")
            or latest_result.get("selected_source")
        ),
        "source_priority": _list_from_payload_or_round(payload, latest_result, "source_priority"),
        "fallbacks": _list_from_payload_or_round(payload, latest_result, "fallbacks"),
        "provider_health": _list_from_payload_or_round(payload, latest_result, "provider_health"),
        "provider_trace": _list_from_payload_or_round(payload, latest_result, "provider_trace"),
        **observation_meta,
    }


def normalize_candidate_rows(raw_rows: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_rows, list):
        return []
    rows: list[dict[str, Any]] = []
    for index, item in enumerate(raw_rows, start=1):
        if not isinstance(item, dict):
            continue
        supplier_id = _coerce_text(
            item.get("supplier_id")
            or item.get("vendor_id")
            or item.get("id")
            or f"supplier_{index}"
        )
        supplier_name = _coerce_text(
            item.get("supplier_name")
            or item.get("vendor_name")
            or item.get("company_name")
            or item.get("name")
            or item.get("title")
            or supplier_id
        )
        match_score = _coerce_float(item.get("match_score") or item.get("score"))
        match_reasons = _coerce_str_list(item.get("match_reasons") or item.get("reasons"))
        if not match_reasons:
            fallback_reason = _coerce_text(item.get("match_reason") or item.get("reason") or item.get("summary"))
            match_reasons = [fallback_reason] if fallback_reason else []
        risk_flags = _coerce_risk_flags(item.get("risk_flags") or item.get("risks"))
        unresolved_checks = _coerce_unresolved_checks(item.get("unresolved_checks"))
        evidence_refs = _coerce_evidence_refs(item.get("evidence_refs") or item.get("references"))
        if not evidence_refs:
            evidence_refs = _fallback_evidence_refs(item)
        source_meta = _coerce_dict(item.get("source_meta"))
        first_ref = evidence_refs[0] if evidence_refs else {}
        canonical_url = _coerce_text(item.get("canonical_url") or item.get("url") or source_meta.get("canonical_url") or first_ref.get("url"))
        result_role = _normalize_result_role(item)
        row = {
            "result_role": result_role,
            "candidate_kind": _coerce_text(item.get("candidate_kind")),
            "supplier_id": supplier_id,
            "supplier_name": supplier_name,
            "list_group": _normalize_list_group(item.get("list_group")),
            "match_score": match_score,
            "match_reasons": match_reasons,
            "source_type": _coerce_text(item.get("source_type") or item.get("source")),
            "source_title": _coerce_text(item.get("source_title") or item.get("title") or source_meta.get("source_title") or supplier_name),
            "source_domain": _coerce_text(item.get("source_domain") or source_meta.get("source_domain")),
            "canonical_url": canonical_url,
            "confidence": _coerce_text(item.get("confidence")),
            "confidence_detail": _coerce_dict(item.get("confidence_detail")),
            "rerank_explain": _coerce_dict(item.get("rerank_explain")),
            "service_mode": _coerce_text(item.get("service_mode")),
            "city_coverage": _coerce_str_list(item.get("city_coverage")),
            "budget_band_fit": _coerce_text(item.get("budget_band_fit")),
            "delivery_eta_days": _coerce_int(item.get("delivery_eta_days")),
            "capability_tags": _coerce_str_list(item.get("capability_tags") or item.get("tags")),
            "evidence_refs": evidence_refs,
            "risk_flags": risk_flags,
            "unresolved_checks": unresolved_checks,
            "source_summary": _coerce_dict(item.get("source_summary")),
            "source_meta": source_meta,
            # compatibility projections for existing UI consumers
            "id": supplier_id,
            "title": supplier_name,
            "score": match_score,
            "match_reason": match_reasons[0] if match_reasons else "",
            "summary": _coerce_text(item.get("summary")),
        }
        rows.append(row)
    return rows


def resolve_sourcing_rows(payload: dict[str, Any], *, shortlist: bool = False) -> list[dict[str, Any]]:
    if shortlist:
        raw_rows = payload.get("shortlist")
        if not isinstance(raw_rows, list):
            raw_rows = payload.get("shortlist_updated")
        if not isinstance(raw_rows, list):
            raw_rows = payload.get("selected_candidates")
        if not isinstance(raw_rows, list):
            raw_rows = _latest_session_sourcing_rows(payload, key="shortlist")
    else:
        raw_rows = payload.get("candidates")
        if not isinstance(raw_rows, list):
            raw_rows = payload.get("sourcing_candidates")
        if not isinstance(raw_rows, list):
            raw_rows = payload.get("results")
        if not isinstance(raw_rows, list):
            raw_rows = _latest_session_sourcing_rows(payload, key="items")
    return normalize_candidate_rows(raw_rows)


def _latest_session_sourcing_rows(payload: dict[str, Any], *, key: str) -> list[Any]:
    session_context = _coerce_dict(payload.get("session_context"))
    rounds = _coerce_list(session_context.get("sourcing_results"))
    for item in reversed(rounds):
        round_value = _coerce_dict(item)
        rows = round_value.get(key)
        if isinstance(rows, list):
            return rows
    return []


def resolve_sourcing_status(payload: dict[str, Any], count: int) -> str:
    explicit = _coerce_text(payload.get("status") or payload.get("state")).lower()
    if explicit:
        return explicit
    return "available" if count > 0 else "empty"
