"""Build deterministic sourcing handoff drafts from collected fields."""

from __future__ import annotations

from typing import Any


def _has_value(value: Any) -> bool:
    """Return whether a field value should be kept in the draft.

    Args:
        value: Candidate field value from collected base fields or payload.

    Returns:
        True when the value is non-empty; otherwise False.
    """
    return value not in (None, "", [], {})


def _as_mapping(value: Any) -> dict[str, Any]:
    """Normalize a value into a shallow mapping.

    Args:
        value: Candidate mapping-like payload value.

    Returns:
        A copied dictionary when value is a dict; otherwise an empty dict.
    """
    return dict(value) if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    """Normalize a value into a shallow list.

    Args:
        value: Candidate list-like payload value.

    Returns:
        A copied list when value is a list; otherwise an empty list.
    """
    return list(value) if isinstance(value, list) else []


def _stringify_value(value: Any) -> str:
    """Convert nested draft values into compact searchable text.

    Args:
        value: Scalar, list, tuple, or dict value from sourcing parameters.

    Returns:
        A stripped text representation with nested empty values removed.
    """
    if isinstance(value, (list, tuple)):
        return " ".join(filter(None, map(_stringify_value, value)))
    if isinstance(value, dict):
        return " ".join(filter(None, map(_stringify_value, value.values())))
    return str(value or "").strip()


def _unique_texts(values: list[Any]) -> list[str]:
    """Build stable unique text terms from raw parameter values.

    Args:
        values: Raw field values used to derive query terms.

    Returns:
        Ordered unique non-empty text values.
    """
    return list(dict.fromkeys(filter(None, map(_stringify_value, values))))


def _criteria_from_payload(payload: dict[str, Any]) -> list[Any]:
    """Read sourcing criteria from supported payload keys.

    Args:
        payload: Canonical action or event payload.

    Returns:
        Criteria list from payload, or an empty list when absent.
    """
    return _as_list(payload.get("sourcing_criteria")) or _as_list(payload.get("criteria"))


def _source_priority_from_payload(payload: dict[str, Any]) -> list[Any]:
    """Resolve data-source priority for the handoff draft.

    Args:
        payload: Canonical payload that may contain provider_config or priority.

    Returns:
        Ordered source priority list, falling back to the default chain.
    """
    provider_config = _as_mapping(payload.get("provider_config"))
    priority = provider_config.get("source_priority") or payload.get("data_source_priority")
    return _as_list(priority) or ["instance_db", "local", "web"]


def _confirmed_fields_from_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """Read persisted confirmed fields from payload session context.

    Args:
        payload: Current orchestration payload.

    Returns:
        Confirmed fields from session context, or an empty mapping.
    """
    session_context = _as_mapping(payload.get("session_context"))
    return _as_mapping(session_context.get("confirmed_fields"))


def _parameters_from_inputs(*, base_fields: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    """Resolve non-empty sourcing parameters from collected inputs.

    Args:
        base_fields: Fields collected by the mode intake chain.
        payload: Existing action or confirmed payload carrying prior parameters.

    Returns:
        A filtered parameter mapping. Persisted session context is the base,
        existing sourcing parameters may override it, and current base_fields
        have highest priority.
    """
    fields = {
        **_confirmed_fields_from_payload(payload),
        **_as_mapping(payload.get("sourcing_parameters")),
        **_as_mapping(base_fields),
    }
    return {key: value for key, value in fields.items() if _has_value(value)}


def _resolve_field_source(*, base_fields: dict[str, Any], payload: dict[str, Any]) -> str:
    """Resolve where the current handoff fields came from."""
    if _as_mapping(base_fields):
        return "base_fields"
    if _as_mapping(payload.get("sourcing_parameters")):
        return "sourcing_parameters"
    if _confirmed_fields_from_payload(payload):
        return "session_context"
    return "base_fields"


def _supplier_profile_from_inputs(*, fields: dict[str, Any], payload: dict[str, Any], source: str) -> dict[str, Any]:
    """Build or preserve the supplier-profile draft.

    Args:
        fields: Resolved sourcing parameter fields.
        payload: Existing action or confirmed payload.

    Returns:
        Existing supplier_profile_draft when present; otherwise a field summary.
    """
    existing_profile = _as_mapping(payload.get("supplier_profile_draft"))
    if existing_profile:
        return existing_profile
    return {
        "fields": fields,
        "field_count": len(fields),
        "source": source,
    }


def build_sourcing_parameter_draft(*, base_fields: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    """Build the deterministic sourcing handoff draft.

    Args:
        base_fields: Fields collected before entering intelligent sourcing.
        payload: Current orchestration payload, including any prior draft data.

    Returns:
        Draft payload containing sourcing parameters, query text, supplier
        profile, criteria, and source-priority metadata.
    """
    fields = _parameters_from_inputs(base_fields=base_fields, payload=payload)
    field_source = _resolve_field_source(base_fields=base_fields, payload=payload)
    query_terms = _unique_texts(list(fields.values()))
    query_draft = _stringify_value(payload.get("sourcing_query_draft")) or " ".join(query_terms) or _stringify_value(payload.get("message"))
    return {
        "sourcing_parameters": fields,
        "sourcing_query_draft": query_draft,
        "supplier_profile_draft": _supplier_profile_from_inputs(fields=fields, payload=payload, source=field_source),
        "criteria": _criteria_from_payload(payload),
        "data_source_priority": _source_priority_from_payload(payload),
    }


def apply_sourcing_parameter_draft(payload: dict[str, Any], draft: dict[str, Any]) -> dict[str, Any]:
    """Merge a sourcing handoff draft into a payload without mutation.

    Args:
        payload: Original action or event payload.
        draft: Draft values produced by build_sourcing_parameter_draft.

    Returns:
        A new payload containing the original keys plus draft metadata.
    """
    return {**payload, **_as_mapping(draft)}


__all__ = ["apply_sourcing_parameter_draft", "build_sourcing_parameter_draft"]
