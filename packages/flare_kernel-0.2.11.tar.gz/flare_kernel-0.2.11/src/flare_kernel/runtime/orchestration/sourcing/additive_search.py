"""Additive sourcing-search orchestration for the main kernel chain."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.runtime.orchestration.sourcing.parameter_draft import (
    build_sourcing_parameter_draft,
)
from flare_kernel.runtime.orchestration.sourcing.observations import (
    build_sourcing_observations,
    resolve_sourcing_final_status,
)
from flare_kernel.runtime.orchestration.sourcing.provider_config_loader import (
    resolve_sourcing_provider_config,
)


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    return list(value) if isinstance(value, list) else []


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _clean_scope(value: Any) -> str:
    scope = _clean_text(value).lower()
    return scope if scope in {"local", "web", "hybrid"} else "hybrid"


def _resolve_top_k(payload: dict[str, Any]) -> int:
    for key in ("sourcing_top_k", "requested_top_k", "top_k"):
        try:
            value = int(payload.get(key) or 0)
        except Exception:
            value = 0
        if value > 0:
            return value
    return 8


def _resolve_enabled(payload: dict[str, Any]) -> bool:
    if "sourcing_enabled" not in payload:
        return True
    return bool(payload.get("sourcing_enabled"))


def _empty_web_search(**_kwargs: Any) -> list[dict[str, Any]]:
    return []


def _merge_context_patch(left: Any, right: Any) -> dict[str, Any]:
    merged = _as_dict(left)
    incoming = _as_dict(right)
    for key, value in incoming.items():
        current = merged.get(key)
        if isinstance(current, list) and isinstance(value, list):
            merged[key] = [*current, *value]
        elif isinstance(current, dict) and isinstance(value, dict):
            merged[key] = {**current, **value}
        else:
            merged[key] = value
    return merged


def _should_run(
    *,
    mode_runtime: dict[str, Any],
    payload: dict[str, Any],
    run_sourcing_search_fn: Callable[..., dict[str, Any]] | None,
    search_knowledge_records_fn: Callable[..., list[dict[str, Any]]] | None,
) -> bool:
    return (
        _clean_text(mode_runtime.get("mode_key")) == "intelligent_sourcing"
        and bool(payload.get("sourcing_confirmed"))
        and callable(run_sourcing_search_fn)
        and callable(search_knowledge_records_fn)
    )


def _rank_profile(payload: dict[str, Any]) -> dict[str, Any] | None:
    if isinstance(payload.get("rank_profile"), dict):
        return payload["rank_profile"]
    session_context = _as_dict(payload.get("session_context"))
    rank_profile = session_context.get("rank_profile")
    return rank_profile if isinstance(rank_profile, dict) else None


def _merge_search_result(
    *,
    payload: dict[str, Any],
    draft: dict[str, Any],
    result: dict[str, Any],
) -> dict[str, Any]:
    results = result.get("results") if isinstance(result.get("results"), list) else []
    shortlist = result.get("shortlist") if isinstance(result.get("shortlist"), list) else []
    context_patch = _merge_context_patch(payload.get("context_patch"), result.get("context_patch"))
    observations = _as_list(result.get("observations"))
    final_status = _clean_text(result.get("final_status")) or resolve_sourcing_final_status(result)
    return {
        **payload,
        **draft,
        "sourcing_candidates": results,
        "candidates": results,
        "shortlist": shortlist,
        "source_breakdown": _as_dict(result.get("source_breakdown")),
        "selected_source": _clean_text(result.get("selected_source")),
        "source_priority": _as_list(result.get("source_priority")),
        "fallbacks": _as_list(result.get("fallbacks")),
        "provider_health": _as_list(result.get("provider_health")),
        "provider_trace": _as_list(result.get("provider_trace")),
        "retrieval_batch": _clean_text(result.get("retrieval_run_id")),
        "context_patch": context_patch,
        "context_revision_id": _clean_text(result.get("context_revision_id")),
        "sourcing_search": {
            "status": "blocked" if result.get("blocked") else "completed",
            "reason": _clean_text(result.get("reason")),
            "retrieval_run_id": _clean_text(result.get("retrieval_run_id")),
            "query": _clean_text(result.get("query")),
            "source_scope": _clean_text(result.get("source_scope")),
            "requested_top_k": int(result.get("requested_top_k") or 0),
            "returned_count": int(result.get("returned_count") or 0),
            "has_more": bool(result.get("has_more")),
            "next_top_k": int(result.get("next_top_k") or 0),
            "final_status": final_status,
            "observations": observations,
            "provider_health": _as_list(result.get("provider_health")),
            "context_patch": context_patch,
        },
    }


def apply_additive_sourcing_search(
    *,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    payload: dict[str, Any],
    mode_runtime: dict[str, Any],
    instance_profile: dict[str, Any] | None,
    run_sourcing_search_fn: Callable[..., dict[str, Any]] | None = None,
    search_knowledge_records_fn: Callable[..., list[dict[str, Any]]] | None = None,
    search_web_sources_fn: Callable[..., Any] | None = None,
    search_instance_records_fn: Callable[..., Any] | None = None,
    search_mcp_records_fn: Callable[..., Any] | None = None,
    persist_sourcing_run_bundle_fn: Callable[..., dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Run sourcing search as additive evidence without bypassing the main chain."""
    if not _should_run(
        mode_runtime=mode_runtime,
        payload=payload,
        run_sourcing_search_fn=run_sourcing_search_fn,
        search_knowledge_records_fn=search_knowledge_records_fn,
    ):
        return dict(payload)

    draft = build_sourcing_parameter_draft(base_fields=_as_dict(payload.get("base_fields")), payload=payload)
    query = _clean_text(draft.get("sourcing_query_draft")) or _clean_text(payload.get("message"))
    if not query:
        result = {"blocked": True, "reason": "empty_query", "query": "", "returned_count": 0}
        return {
            **payload,
            **draft,
            "sourcing_search": {
                "status": "skipped",
                "reason": "empty_query",
                "final_status": "blocked",
                "observations": build_sourcing_observations(result),
            },
        }

    provider_config = resolve_sourcing_provider_config(
        request_provider_config=_as_dict(payload.get("provider_config")),
        instance_profile=instance_profile,
    )
    try:
        result = run_sourcing_search_fn(
            trace_id=trace_id,
            session_id=session_id,
            project_id=project_id or _clean_text(payload.get("project_id")) or "default",
            user_id=user_id or _clean_text(payload.get("user_id")) or "default",
            query=query,
            top_k=_resolve_top_k(payload),
            append_mode=False,
            lock_existing_order=True,
            base_result_ids=[],
            source_scope=_clean_scope(payload.get("source_scope")),
            sourcing_enabled=_resolve_enabled(payload),
            search_knowledge_records_fn=search_knowledge_records_fn,
            search_web_sources_fn=search_web_sources_fn if callable(search_web_sources_fn) else _empty_web_search,
            search_instance_records_fn=search_instance_records_fn,
            search_mcp_records_fn=search_mcp_records_fn,
            persist_sourcing_run_bundle_fn=persist_sourcing_run_bundle_fn,
            source_ids=[_clean_text(item) for item in _as_list(payload.get("source_ids")) if _clean_text(item)],
            entities=_as_list(payload.get("entities")),
            rank_profile=_rank_profile(payload),
            provider_config=provider_config,
        )
    except Exception as exc:
        result = {
            "blocked": False,
            "reason": str(exc),
            "query": query,
            "returned_count": 0,
            "provider_trace": [{"source": "sourcing_runtime", "status": "failed", "hit_count": 0, "reason": str(exc)}],
        }
        return {
            **payload,
            **draft,
            "sourcing_search": {
                "status": "failed",
                "reason": str(exc),
                "final_status": "failed",
                "observations": build_sourcing_observations(result),
            },
        }
    return _merge_search_result(payload=payload, draft=draft, result=result)


__all__ = ["apply_additive_sourcing_search"]
