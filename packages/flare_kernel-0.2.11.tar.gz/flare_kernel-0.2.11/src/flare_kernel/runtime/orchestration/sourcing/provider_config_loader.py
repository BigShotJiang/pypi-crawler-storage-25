"""Resolve sourcing provider config from request and instance profile layers."""

from __future__ import annotations

from functools import reduce
from typing import Any


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _nested_dict(root: dict[str, Any], path: tuple[str, ...]) -> dict[str, Any]:
    resolved = reduce(
        lambda current, key: current.get(key) if isinstance(current, dict) else None,
        path,
        root,
    )
    return _as_dict(resolved)


def _instance_sourcing_provider_config(instance_profile: dict[str, Any] | None) -> dict[str, Any]:
    profile = _as_dict(instance_profile)
    candidates = (
        profile.get("sourcing_provider_config"),
        _nested_dict(profile, ("sourcing", "provider_config")),
        _nested_dict(profile, ("sourcing", "provider")),
    )
    return reduce(lambda acc, item: {**acc, **_as_dict(item)}, candidates, {})


def resolve_sourcing_provider_config(
    *,
    request_provider_config: dict[str, Any] | None = None,
    instance_profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    instance_config = _instance_sourcing_provider_config(instance_profile)
    request_config = _as_dict(request_provider_config)
    return {**instance_config, **request_config}


__all__ = ["resolve_sourcing_provider_config"]
