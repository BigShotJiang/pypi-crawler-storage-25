"""Canvas toolbar capability contract helpers."""

from __future__ import annotations


def build_canvas_toolbar_actions(
    *,
    copy: bool = True,
    edit: bool = False,
    export_markdown: bool = False,
    fullscreen: bool = True,
) -> list[dict[str, str]]:
    """Build toolbar action capabilities for a Canvas work product.

    This helper only emits generic action contracts.  Mode/domain orchestration
    decides which booleans apply to a work product; frontend components only
    render the resulting constrained action list.
    """

    actions: list[dict[str, str]] = []
    if copy:
        actions.append({"key": "copy", "icon": "copy"})
    if export_markdown:
        actions.append({"key": "export_markdown", "icon": "download"})
    if edit:
        actions.append({"key": "edit", "icon": "edit"})
    if fullscreen:
        actions.append({"key": "fullscreen", "icon": "fullscreen"})
    return actions


def build_canvas_workspace_capabilities(*, toolbar_actions: list[dict[str, str]]) -> dict[str, list[dict[str, str]]]:
    """Build workspace capability projection for Canvas toolbar actions."""

    return {"toolbar_actions": [dict(action) for action in toolbar_actions]}


__all__ = ["build_canvas_toolbar_actions", "build_canvas_workspace_capabilities"]
