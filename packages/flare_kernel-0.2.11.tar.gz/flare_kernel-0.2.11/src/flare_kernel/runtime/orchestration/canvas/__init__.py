"""Canvas orchestration capability helpers."""

