"""Project Memory runtime orchestration helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.runtime.infrastructure.project_memory_store import (
    search_project_memory_records,
    upsert_project_memory_record,
)
from flare_kernel.runtime.project_memory.extraction import extract_project_memory_candidates
from flare_kernel.runtime.project_memory.recall import recall_project_memory


def _as_dict(value: Any) -> dict[str, Any]:
    """Return dict-shaped values only.

    Args:
        value: Candidate runtime value.

    Returns:
        Original dict or an empty dict.
    """

    return value if isinstance(value, dict) else {}


def _clean_text(value: Any) -> str:
    """Normalize text-like values.

    Args:
        value: Raw value.

    Returns:
        Whitespace-normalized string.
    """

    return " ".join(str(value or "").split()).strip()


def build_project_memory_context_layer(
    *,
    project_id: str | None,
    user_id: str | None,
    query: str | None,
    top_k: int = 5,
    search_project_memory_records_fn: Callable[..., list[dict[str, Any]]] = search_project_memory_records,
) -> dict[str, Any]:
    """Build the Project Memory recall layer for one turn.

    Args:
        project_id: Project scope used for recall.
        user_id: User scope used for recall.
        query: User/query text used to recall memory.
        top_k: Maximum number of records to request.
        search_project_memory_records_fn: Persistence search boundary.

    Returns:
        ProjectMemoryRecall dict, or empty dict when scope/query is missing.
    """

    resolved_project_id = _clean_text(project_id)
    resolved_user_id = _clean_text(user_id)
    resolved_query = _clean_text(query)
    if not resolved_project_id or not resolved_user_id or not resolved_query:
        return {}
    return recall_project_memory(
        project_id=resolved_project_id,
        user_id=resolved_user_id,
        query=resolved_query,
        top_k=top_k,
        search_project_memory_records_fn=search_project_memory_records_fn,
    )


def persist_project_memory_from_runtime(
    *,
    project_id: str | None,
    user_id: str | None,
    source_session_id: str | None,
    runtime_snapshot: dict[str, Any],
    upsert_project_memory_record_fn: Callable[..., dict[str, Any]] = upsert_project_memory_record,
) -> dict[str, Any]:
    """Persist Project Memory candidates extracted from runtime outputs.

    Args:
        project_id: Project scope used for persistence.
        user_id: User scope used for persistence.
        source_session_id: Session that produced the runtime outputs.
        runtime_snapshot: Kernel runtime snapshot containing context outputs.
        upsert_project_memory_record_fn: Persistence upsert boundary.

    Returns:
        Project Memory persistence status dict, or empty dict when skipped.
    """

    resolved_project_id = _clean_text(project_id)
    resolved_user_id = _clean_text(user_id)
    if not resolved_project_id or not resolved_user_id:
        return {}

    candidates = extract_project_memory_candidates(
        context=_as_dict(runtime_snapshot.get("session_context")),
        reasoning_result=_as_dict(runtime_snapshot.get("reasoning_result")),
        document_result=_as_dict(runtime_snapshot.get("document_result")),
        track_result=_as_dict(runtime_snapshot.get("track_result")),
        source_session_id=source_session_id,
    )
    if not candidates:
        return {}

    memory_ids: list[str] = []
    try:
        for candidate in candidates:
            stored = upsert_project_memory_record_fn(
                project_id=resolved_project_id,
                user_id=resolved_user_id,
                content=str(candidate.get("content") or ""),
                memory_type=str(candidate.get("memory_type") or "fact"),
                source_session_id=str(candidate.get("source_session_id") or ""),
                source_message_id=str(candidate.get("source_message_id") or ""),
                source_id=str(candidate.get("source_id") or ""),
                evidence=candidate.get("evidence") if isinstance(candidate.get("evidence"), list) else [],
                confidence=candidate.get("confidence"),
                status="active",
            )
            memory_id = _clean_text(stored.get("memory_id") if isinstance(stored, dict) else "")
            if memory_id:
                memory_ids.append(memory_id)
    except Exception as exc:
        return {
            "project_memory_stored": False,
            "project_memory_status": "failed",
            "project_memory_error": str(exc),
            "project_memory_count": len(memory_ids),
            "project_memory_ids": memory_ids,
        }

    return {
        "project_memory_stored": bool(memory_ids),
        "project_memory_status": "stored" if memory_ids else "skipped",
        "project_memory_count": len(memory_ids),
        "project_memory_ids": memory_ids,
    }
