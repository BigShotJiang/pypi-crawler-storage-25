"""Project Memory recall payload assembly."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.contracts.project_memory_contract import ProjectMemoryRecall


def _clean_text(value: Any) -> str:
    """Normalize arbitrary input into compact text.

    Args:
        value: Raw value from store or caller input.

    Returns:
        Whitespace-normalized string.
    """

    return " ".join(str(value or "").split()).strip()


def _memory_view(record: dict[str, Any]) -> dict[str, Any]:
    """Project a durable memory record into recall payload shape.

    Args:
        record: ProjectMemoryRecord-compatible dict from storage.

    Returns:
        Minimal memory dict safe for context assembly.
    """

    return {
        "memory_id": _clean_text(record.get("memory_id")),
        "memory_type": _clean_text(record.get("memory_type")),
        "content": _clean_text(record.get("content")),
        "evidence": record.get("evidence") if isinstance(record.get("evidence"), list) else [],
        "confidence": record.get("confidence"),
    }


def build_project_memory_recall(
    *,
    project_id: str,
    user_id: str,
    query: str,
    memories: list[dict[str, Any]] | None,
    degraded: bool = False,
) -> dict[str, Any]:
    """Build the `project_memory_recall` context layer payload.

    Args:
        project_id: Project scope used for recall.
        user_id: User scope used for recall.
        query: User/query text used to search memory.
        memories: Raw memory records returned by persistence.
        degraded: Whether recall failed and used fallback output.

    Returns:
        ProjectMemoryRecall as a dict.
    """

    memory_items = [_memory_view(item) for item in (memories or []) if isinstance(item, dict)]
    memory_items = [item for item in memory_items if item["memory_id"] and item["content"]]
    return ProjectMemoryRecall(
        project_id=_clean_text(project_id),
        user_id=_clean_text(user_id),
        query=_clean_text(query),
        hit_count=len(memory_items),
        memory_ids=[item["memory_id"] for item in memory_items],
        memories=memory_items,
        degraded=degraded,
    ).model_dump()


def recall_project_memory(
    *,
    project_id: str,
    user_id: str,
    query: str,
    search_project_memory_records_fn: Callable[..., list[dict[str, Any]]],
    top_k: int = 5,
) -> dict[str, Any]:
    """Recall Project Memory records through an injected search boundary.

    Args:
        project_id: Project scope used for recall.
        user_id: User scope used for recall.
        query: User/query text used to search memory.
        search_project_memory_records_fn: Persistence search function.
        top_k: Maximum number of records to request.

    Returns:
        ProjectMemoryRecall as a dict. Returns degraded=True if search fails.
    """

    try:
        memories = search_project_memory_records_fn(
            project_id=project_id,
            user_id=user_id,
            query=query,
            top_k=top_k,
        )
        return build_project_memory_recall(
            project_id=project_id,
            user_id=user_id,
            query=query,
            memories=memories,
            degraded=False,
        )
    except Exception:
        return build_project_memory_recall(
            project_id=project_id,
            user_id=user_id,
            query=query,
            memories=[],
            degraded=True,
        )
