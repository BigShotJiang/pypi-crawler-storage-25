"""Pure Project Memory candidate extraction policies."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts.project_memory_contract import ProjectMemoryCandidate


def _clean_text(value: Any) -> str:
    """Normalize arbitrary input into compact text.

    Args:
        value: Raw value from runtime output.

    Returns:
        Whitespace-normalized string.
    """

    return " ".join(str(value or "").split()).strip()


def _as_dict(value: Any) -> dict[str, Any]:
    """Return a dict only when the value already has mapping shape.

    Args:
        value: Candidate runtime payload.

    Returns:
        The original dict, or an empty dict for non-dict values.
    """

    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    """Return a list only when the value already has list shape.

    Args:
        value: Candidate runtime field.

    Returns:
        The original list, or an empty list for non-list values.
    """

    return value if isinstance(value, list) else []


def _item_text(item: Any) -> str:
    """Extract normalized text from a structured or plain runtime item.

    Args:
        item: Runtime item with text-like fields, or a scalar value.

    Returns:
        Best-effort normalized text content.
    """

    if isinstance(item, dict):
        return _clean_text(item.get("text") or item.get("summary") or item.get("content") or item.get("snippet"))
    return _clean_text(item)


def _item_evidence(item: Any) -> list[dict[str, Any]]:
    """Build evidence refs from a runtime item when source_id exists.

    Args:
        item: Runtime item that may contain source_id and snippet text.

    Returns:
        Evidence list compatible with ProjectMemoryCandidate.
    """

    if not isinstance(item, dict):
        return []
    source_id = _clean_text(item.get("source_id"))
    if not source_id:
        return []
    return [{"source_id": source_id, "snippet": _clean_text(item.get("snippet") or item.get("text"))}]


def _candidate(
    *,
    memory_type: str,
    content: str,
    evidence: list[dict[str, Any]] | None = None,
    confidence: float | None = None,
    source_session_id: str | None = None,
    source_message_id: str | None = None,
    source_id: str | None = None,
) -> dict[str, Any] | None:
    """Build one normalized Project Memory candidate.

    Args:
        memory_type: Candidate category.
        content: Candidate text before normalization.
        evidence: Optional evidence snippets.
        confidence: Optional confidence score.
        source_session_id: Producing session id, when available.
        source_message_id: Producing message id, when available.
        source_id: Producing source id, when available.

    Returns:
        ProjectMemoryCandidate as a dict, or None when content is empty.
    """

    clean_content = _clean_text(content)
    if not clean_content:
        return None
    return ProjectMemoryCandidate(
        memory_type=_clean_text(memory_type) or "fact",
        content=clean_content,
        evidence=evidence or [],
        confidence=confidence,
        source_session_id=_clean_text(source_session_id),
        source_message_id=_clean_text(source_message_id),
        source_id=_clean_text(source_id),
    ).model_dump()


def _append_candidate(candidates: list[dict[str, Any]], candidate: dict[str, Any] | None) -> None:
    """Append a candidate only when extraction produced content.

    Args:
        candidates: Mutable candidate list owned by the caller.
        candidate: Candidate dict or None.

    Returns:
        None.
    """

    if candidate is not None:
        candidates.append(candidate)


def _extract_context_candidates(context: dict[str, Any], **source: Any) -> list[dict[str, Any]]:
    """Extract candidates from the session context contract.

    Args:
        context: Context payload with facts, unknowns, and notes.
        **source: Source identifiers attached to each candidate.

    Returns:
        List of Project Memory candidate dicts.
    """

    candidates: list[dict[str, Any]] = []
    for item in _as_list(context.get("facts")):
        _append_candidate(candidates, _candidate(memory_type="fact", content=_item_text(item), evidence=_item_evidence(item), **source))
    for item in _as_list(context.get("unknowns")):
        _append_candidate(candidates, _candidate(memory_type="open_question", content=_item_text(item), evidence=_item_evidence(item), **source))
    for item in _as_list(context.get("notes")):
        _append_candidate(candidates, _candidate(memory_type="summary", content=_item_text(item), **source))
    return candidates


def _extract_reasoning_candidates(reasoning_result: dict[str, Any], **source: Any) -> list[dict[str, Any]]:
    """Extract candidates from reasoning output.

    Args:
        reasoning_result: Runtime reasoning result payload.
        **source: Source identifiers attached to each candidate.

    Returns:
        List of Project Memory candidate dicts.
    """

    candidates: list[dict[str, Any]] = []
    for item in _as_list(reasoning_result.get("facts")):
        _append_candidate(candidates, _candidate(memory_type="fact", content=_item_text(item), evidence=_item_evidence(item), **source))
    for item in _as_list(reasoning_result.get("unknowns")):
        _append_candidate(candidates, _candidate(memory_type="open_question", content=_item_text(item), evidence=_item_evidence(item), **source))
    for item in _as_list(reasoning_result.get("user_focus")):
        _append_candidate(candidates, _candidate(memory_type="preference", content=_item_text(item), **source))
    return candidates


def _extract_document_candidates(document_result: dict[str, Any], **source: Any) -> list[dict[str, Any]]:
    """Extract candidates from document analysis output.

    Args:
        document_result: Runtime document result payload.
        **source: Source identifiers attached to each candidate.

    Returns:
        List of Project Memory candidate dicts.
    """

    candidates: list[dict[str, Any]] = []
    _append_candidate(candidates, _candidate(memory_type="summary", content=_clean_text(document_result.get("summary")), **source))
    for item in _as_list(document_result.get("key_facts")):
        _append_candidate(candidates, _candidate(memory_type="fact", content=_item_text(item), **source))
    for item in _as_list(document_result.get("open_questions")):
        _append_candidate(candidates, _candidate(memory_type="open_question", content=_item_text(item), **source))
    return candidates


def _extract_track_candidates(track_result: dict[str, Any], **source: Any) -> list[dict[str, Any]]:
    """Extract candidates from track-style runtime output.

    Args:
        track_result: Runtime track result payload.
        **source: Source identifiers attached to each candidate.

    Returns:
        List of Project Memory candidate dicts.
    """

    candidates: list[dict[str, Any]] = []
    _append_candidate(candidates, _candidate(memory_type="result", content=_clean_text(track_result.get("goal")), **source))
    _append_candidate(candidates, _candidate(memory_type="summary", content=_clean_text(track_result.get("prompt_enrichment")), **source))
    for item in _as_list(track_result.get("unknowns")):
        _append_candidate(candidates, _candidate(memory_type="open_question", content=_item_text(item), **source))
    return candidates


def _dedupe_candidates(candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Remove empty or duplicate candidates while preserving order.

    Args:
        candidates: Candidate dicts from all extraction sources.

    Returns:
        Deduplicated candidate dicts keyed by type and content.
    """

    deduped: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for item in candidates:
        key = (str(item.get("memory_type") or ""), str(item.get("content") or ""))
        if not key[1] or key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def extract_project_memory_candidates(
    *,
    context: dict[str, Any] | None = None,
    reasoning_result: dict[str, Any] | None = None,
    document_result: dict[str, Any] | None = None,
    track_result: dict[str, Any] | None = None,
    source_session_id: str | None = None,
    source_message_id: str | None = None,
    source_id: str | None = None,
) -> list[dict[str, Any]]:
    """Extract Project Memory candidates from runtime outputs without side effects.

    Args:
        context: Session context payload.
        reasoning_result: Reasoning output payload.
        document_result: Document analysis output payload.
        track_result: Track output payload.
        source_session_id: Producing session id, when available.
        source_message_id: Producing message id, when available.
        source_id: Producing source id, when available.

    Returns:
        Deduplicated ProjectMemoryCandidate dicts ready for persistence review.
    """

    source = {
        "source_session_id": source_session_id,
        "source_message_id": source_message_id,
        "source_id": source_id,
    }
    candidates: list[dict[str, Any]] = []
    candidates.extend(_extract_context_candidates(_as_dict(context), **source))
    candidates.extend(_extract_reasoning_candidates(_as_dict(reasoning_result), **source))
    candidates.extend(_extract_document_candidates(_as_dict(document_result), **source))
    candidates.extend(_extract_track_candidates(_as_dict(track_result), **source))
    return _dedupe_candidates(candidates)
