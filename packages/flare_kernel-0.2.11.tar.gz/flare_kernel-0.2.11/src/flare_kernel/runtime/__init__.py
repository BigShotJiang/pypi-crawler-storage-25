"""Kernel runtime helpers."""

from __future__ import annotations


from flare_kernel.runtime.domain.domain_pack_loader import (
    DomainPack,
    FieldPolicy,
    ReplaceRuleSet,
    SearchMapping,
    WorkflowConfig,
    load_domain_pack,
    load_instance_profile,
    resolve_domain_pack_root,
)
from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine
from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.llm.llm_provider import generate_llm_completion, generate_llm_completion_stream, get_llm_provider_config
from flare_kernel.runtime.llm.model_router import (
    ModelCandidate,
    RouterWeights,
    RoutingContext,
    RoutingDecision,
    normalize_candidate,
    select_model,
)
from flare_kernel.runtime.orchestration.mode.runtime import build_kernel_runtime, build_mode_runtime, build_context_usage, get_context_budget_config
from flare_kernel.runtime.orchestration.mode.orchestration import build_mode_orchestration
from flare_kernel.runtime.orchestration.decision_engine import (
    DecisionContext,
    DecisionBasis,
    OrchestrationDecision,
    StageTransition,
    evaluate_orchestration_decision,
)
from flare_kernel.runtime.intent.intent_and_escalation_classifier import (
    IntentEscalationContext,
    IntentEscalationResult,
    classify_intent_and_escalation,
)
from flare_kernel.runtime.execution.agent_runtime import build_agent_runtime
from flare_kernel.runtime.execution.skill_runtime import build_skill_runtime
from flare_kernel.runtime.infrastructure.infrastructure import (
    collect_capability_status,
    collect_dependency_status,
    ingest_knowledge_record,
    persist_memory_record,
    search_knowledge_records,
)
from flare_kernel.runtime.infrastructure.source.library_persistence import (
    create_project_source_record,
    delete_project_source,
    list_project_sources,
)
from flare_kernel.runtime.source_ingestion.runtime import run_source_ingestion_pipeline
from flare_kernel.runtime.session import (
    IntakeCheckpointSnapshot,
    IntakeSessionSnapshot,
    load_intake_checkpoint,
    load_intake_session_snapshot,
    load_latest_intake_session_id,
    persist_intake_checkpoint,
    persist_intake_session_state,
)
from flare_kernel.runtime.infrastructure.trace import resolve_trace_id
from flare_kernel.runtime.domain.profile_resolution import (
    ProfileSourceResolver,
    TenantOverrideResolver,
    TenantBindingResolver,
    ProfileMergeValidator,
    ResolutionTraceEmitter,
)

__all__ = [
    "resolve_trace_id",
    "get_logger",
    "resolve_domain_pack_root",
    "load_domain_pack",
    "load_instance_profile",
    "DomainPack",
    "WorkflowConfig",
    "FieldPolicy",
    "SearchMapping",
    "ReplaceRuleSet",
    "get_llm_provider_config",
    "generate_llm_completion",
    "generate_llm_completion_stream",
    "ModelCandidate",
    "RouterWeights",
    "RoutingContext",
    "RoutingDecision",
    "normalize_candidate",
    "select_model",
    "get_context_budget_config",
    "build_mode_runtime",
    "build_context_usage",
    "build_mode_orchestration",
    "DecisionContext",
    "DecisionBasis",
    "OrchestrationDecision",
    "StageTransition",
    "evaluate_orchestration_decision",
    "IntentEscalationContext",
    "IntentEscalationResult",
    "classify_intent_and_escalation",
    "build_agent_runtime",
    "build_skill_runtime",
    "build_kernel_runtime",
    "collect_dependency_status",
    "collect_capability_status",
    "build_sqlalchemy_engine",
    "persist_memory_record",
    "ingest_knowledge_record",
    "search_knowledge_records",
    "create_project_source_record",
    "list_project_sources",
    "delete_project_source",
    "run_source_ingestion_pipeline",
    "IntakeSessionSnapshot",
    "IntakeCheckpointSnapshot",
    "persist_intake_session_state",
    "load_intake_session_snapshot",
    "load_latest_intake_session_id",
    "persist_intake_checkpoint",
    "load_intake_checkpoint",
    "ProfileSourceResolver",
    "TenantOverrideResolver",
    "TenantBindingResolver",
    "ProfileMergeValidator",
    "ResolutionTraceEmitter",
]
