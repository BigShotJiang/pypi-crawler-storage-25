"""Source ingestion orchestration runtime."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from flare_engines import run_ingestion
from flare_kernel.runtime.infrastructure.source.library_persistence import (
    get_source_record,
    update_source_document_understanding,
    update_source_status,
)
from flare_kernel.runtime.infrastructure.source.text_extractor import (
    SourceTextExtractionError,
    extract_source_text,
)
from flare_kernel.runtime.source_ingestion.artifacts import (
    apply_source_document_context,
    build_source_document_result,
)
from flare_kernel.runtime.source_ingestion.storage import (
    persist_chunks_and_embeddings,
    persist_searchable_knowledge_record,
)

_CHUNK_SIZE = 800


def _split_chunks(text: str, chunk_size: int = _CHUNK_SIZE) -> list[str]:
    normalized = " ".join((text or "").split())
    if not normalized:
        return []
    return [normalized[index : index + chunk_size] for index in range(0, len(normalized), chunk_size)]


def run_source_ingestion_pipeline(
    *,
    project_id: str,
    source_id: str,
    build_sqlalchemy_engine_fn: Callable[[], Any],
    document_understanding_config: dict[str, Any] | None = None,
) -> None:
    source = get_source_record(
        project_id=project_id,
        source_id=source_id,
        build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
    )
    if not source:
        return
    storage_uri = str(source.get("storage_uri") or "").strip()
    if not storage_uri:
        update_source_status(
            project_id=project_id,
            source_id=source_id,
            status="failed",
            error_code="storage_uri_missing",
            error_message="storage uri missing",
            build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
        )
        return
    file_path = Path(storage_uri)
    try:
        content = extract_source_text(
            file_path,
            mime_type=str(source.get("mime_type") or ""),
            filename=str(source.get("filename") or ""),
        )
    except SourceTextExtractionError as exc:
        update_source_status(
            project_id=project_id,
            source_id=source_id,
            status="failed",
            error_code=str(exc.code or "source_parse_failed"),
            error_message=str(exc.message or "source parse failed"),
            build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
        )
        return
    document_result = build_source_document_result(
        source=source,
        content=content,
        document_understanding_config=document_understanding_config,
    )
    update_source_document_understanding(
        project_id=project_id,
        source_id=source_id,
        document_understanding=document_result,
        build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
    )
    apply_source_document_context(source=source, document_result=document_result)
    chunks = _split_chunks(content)
    current_status = "uploaded"
    while current_status not in ("ready", "failed"):
        result = run_ingestion({"source_id": source_id, "status": current_status})
        error_code = str(result.get("error_code") or "").strip()
        if error_code:
            update_source_status(
                project_id=project_id,
                source_id=source_id,
                status="failed",
                error_code=error_code,
                error_message=str(result.get("error_message") or "ingestion failed"),
                build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
            )
            return
        payload = result.get("result")
        next_status = str(payload.get("status") if isinstance(payload, dict) else "").strip()
        if not next_status:
            update_source_status(
                project_id=project_id,
                source_id=source_id,
                status="failed",
                error_code="ingestion_status_missing",
                error_message="ingestion output missing status",
                build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
            )
            return
        if next_status == "chunked":
            persist_chunks_and_embeddings(
                source_id=source_id,
                project_id=project_id,
                chunks=chunks,
                build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
            )
            persist_searchable_knowledge_record(
                source_id=source_id,
                project_id=project_id,
                source_title=str(source.get("filename") or source_id),
                content=content,
                chunks=chunks,
                user_id=str(source.get("user_id") or "default"),
                session_id=str(source.get("session_id") or "default"),
                metadata={"document_understanding": document_result},
                build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
            )
        update_source_status(
            project_id=project_id,
            source_id=source_id,
            status=next_status,
            build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
        )
        current_status = next_status
