"""Storage facade for source ingestion runtime."""

from __future__ import annotations

from flare_kernel.runtime.source_ingestion.chunk_storage import (
    persist_chunks_and_embeddings,
    stable_embedding,
)
from flare_kernel.runtime.source_ingestion.knowledge_storage import (
    persist_searchable_knowledge_record,
)

__all__ = [
    "persist_chunks_and_embeddings",
    "persist_searchable_knowledge_record",
    "stable_embedding",
]
