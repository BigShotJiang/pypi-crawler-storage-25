"""Chunk and embedding storage for source ingestion."""

from __future__ import annotations

import hashlib
import json
import uuid
from typing import Any, Callable

_CHUNK_EMBEDDING_DIM = 8


def stable_embedding(chunk_text: str, dim: int = _CHUNK_EMBEDDING_DIM) -> list[float]:
    digest = hashlib.sha256(chunk_text.encode("utf-8")).digest()
    return [((digest[index] / 255.0) * 2.0) - 1.0 for index in range(dim)]


def persist_chunks_and_embeddings(
    *,
    source_id: str,
    project_id: str,
    chunks: list[str],
    build_sqlalchemy_engine_fn: Callable[[], Any],
) -> None:
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        return
    try:
        from sqlalchemy import text

        with engine.begin() as conn:
            _ensure_chunk_tables(conn, text)
            _delete_existing_source_chunks(conn, text, source_id=source_id, project_id=project_id)
            _insert_chunks(conn, text, source_id=source_id, project_id=project_id, chunks=chunks)
    except Exception:
        return


def _ensure_chunk_tables(conn: Any, text_fn: Any) -> None:
    conn.execute(
        text_fn(
            """
            CREATE TABLE IF NOT EXISTS flare_project_source_chunks (
                id TEXT PRIMARY KEY,
                source_id TEXT,
                project_id TEXT,
                chunk_index INTEGER,
                content TEXT,
                created_at TEXT
            )
            """
        )
    )
    conn.execute(
        text_fn(
            """
            CREATE TABLE IF NOT EXISTS flare_project_source_embeddings (
                id TEXT PRIMARY KEY,
                source_id TEXT,
                project_id TEXT,
                chunk_id TEXT,
                model TEXT,
                vector_json TEXT,
                created_at TEXT
            )
            """
        )
    )


def _delete_existing_source_chunks(conn: Any, text_fn: Any, *, source_id: str, project_id: str) -> None:
    params = {"source_id": source_id, "project_id": project_id}
    conn.execute(
        text_fn(
            """
            DELETE FROM flare_project_source_chunks
            WHERE source_id = :source_id AND project_id = :project_id
            """
        ),
        params,
    )
    conn.execute(
        text_fn(
            """
            DELETE FROM flare_project_source_embeddings
            WHERE source_id = :source_id AND project_id = :project_id
            """
        ),
        params,
    )


def _insert_chunks(conn: Any, text_fn: Any, *, source_id: str, project_id: str, chunks: list[str]) -> None:
    for chunk_index, chunk_text in enumerate(chunks):
        chunk_id = f"chunk-{uuid.uuid4().hex}"
        _insert_source_chunk(
            conn,
            text_fn,
            chunk_id=chunk_id,
            source_id=source_id,
            project_id=project_id,
            chunk_index=chunk_index,
            chunk_text=chunk_text,
        )
        _insert_source_embedding(
            conn,
            text_fn,
            chunk_id=chunk_id,
            source_id=source_id,
            project_id=project_id,
            chunk_text=chunk_text,
        )


def _insert_source_chunk(
    conn: Any,
    text_fn: Any,
    *,
    chunk_id: str,
    source_id: str,
    project_id: str,
    chunk_index: int,
    chunk_text: str,
) -> None:
    conn.execute(
        text_fn(
            """
            INSERT INTO flare_project_source_chunks (
                id, source_id, project_id, chunk_index, content, created_at
            ) VALUES (
                :id, :source_id, :project_id, :chunk_index, :content, CURRENT_TIMESTAMP
            )
            """
        ),
        {
            "id": chunk_id,
            "source_id": source_id,
            "project_id": project_id,
            "chunk_index": chunk_index,
            "content": chunk_text,
        },
    )


def _insert_source_embedding(
    conn: Any,
    text_fn: Any,
    *,
    chunk_id: str,
    source_id: str,
    project_id: str,
    chunk_text: str,
) -> None:
    conn.execute(
        text_fn(
            """
            INSERT INTO flare_project_source_embeddings (
                id, source_id, project_id, chunk_id, model, vector_json, created_at
            ) VALUES (
                :id, :source_id, :project_id, :chunk_id, :model, :vector_json, CURRENT_TIMESTAMP
            )
            """
        ),
        {
            "id": f"embedding-{uuid.uuid4().hex}",
            "source_id": source_id,
            "project_id": project_id,
            "chunk_id": chunk_id,
            "model": "stable-hash-embed-v1",
            "vector_json": json.dumps(stable_embedding(chunk_text)),
        },
    )


__all__ = ["persist_chunks_and_embeddings", "stable_embedding"]
