"""Knowledge record storage for source ingestion."""

from __future__ import annotations

import json
import uuid
from typing import Any, Callable

from flare_kernel.runtime.infrastructure.knowledge_memory import append_memory_knowledge_record


def persist_searchable_knowledge_record(
    *,
    source_id: str,
    project_id: str,
    source_title: str,
    content: str,
    chunks: list[str],
    user_id: str,
    session_id: str,
    metadata: dict[str, Any] | None,
    build_sqlalchemy_engine_fn: Callable[[], Any],
) -> None:
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        _persist_memory_record(
            source_id=source_id,
            project_id=project_id,
            source_title=source_title,
            content=content,
            user_id=user_id,
            session_id=session_id,
            metadata=metadata,
        )
        return
    try:
        from sqlalchemy import text

        with engine.begin() as conn:
            _ensure_knowledge_tables(conn, text)
            record_id = f"record-{uuid.uuid4().hex}"
            _insert_knowledge_record(
                conn,
                text,
                record_id=record_id,
                source_id=source_id,
                project_id=project_id,
                source_title=source_title,
                content=content,
                user_id=user_id,
                session_id=session_id,
                metadata=metadata,
            )
            _insert_knowledge_chunks(
                conn,
                text,
                record_id=record_id,
                source_id=source_id,
                project_id=project_id,
                chunks=chunks,
                user_id=user_id,
                session_id=session_id,
            )
    except Exception:
        _persist_memory_record(
            source_id=source_id,
            project_id=project_id,
            source_title=source_title,
            content=content,
            user_id=user_id,
            session_id=session_id,
            metadata=metadata,
        )
        return


def _persist_memory_record(
    *,
    source_id: str,
    project_id: str,
    source_title: str,
    content: str,
    user_id: str,
    session_id: str,
    metadata: dict[str, Any] | None,
) -> None:
    append_memory_knowledge_record(
        source_id=source_id,
        project_id=project_id,
        user_id=user_id,
        session_id=session_id,
        title=source_title or source_id,
        content=content,
        metadata=metadata,
    )


def _ensure_knowledge_tables(conn: Any, text_fn: Any) -> None:
    conn.execute(
        text_fn(
            """
            CREATE TABLE IF NOT EXISTS flare_knowledge_records (
                id TEXT PRIMARY KEY,
                trace_id TEXT,
                project_id TEXT,
                user_id TEXT,
                session_id TEXT,
                source_id TEXT,
                title TEXT,
                content TEXT,
                metadata_json TEXT,
                created_at TEXT
            )
            """
        )
    )
    conn.execute(
        text_fn(
            """
            CREATE TABLE IF NOT EXISTS flare_knowledge_chunks (
                id TEXT PRIMARY KEY,
                record_id TEXT,
                trace_id TEXT,
                project_id TEXT,
                user_id TEXT,
                session_id TEXT,
                chunk_index INTEGER,
                content TEXT,
                created_at TEXT
            )
            """
        )
    )


def _insert_knowledge_record(
    conn: Any,
    text_fn: Any,
    *,
    record_id: str,
    source_id: str,
    project_id: str,
    source_title: str,
    content: str,
    user_id: str,
    session_id: str,
    metadata: dict[str, Any] | None,
) -> None:
    conn.execute(
        text_fn(
            """
            INSERT INTO flare_knowledge_records (
                id, trace_id, project_id, user_id, session_id, source_id,
                title, content, metadata_json, created_at
            ) VALUES (
                :id, :trace_id, :project_id, :user_id, :session_id, :source_id,
                :title, :content, :metadata_json, CURRENT_TIMESTAMP
            )
            """
        ),
        {
            "id": record_id,
            "trace_id": f"ingest-{source_id}",
            "project_id": project_id,
            "user_id": user_id,
            "session_id": session_id,
            "source_id": source_id,
            "title": source_title or source_id,
            "content": content,
            "metadata_json": json.dumps(metadata or {}, ensure_ascii=False),
        },
    )


def _insert_knowledge_chunks(
    conn: Any,
    text_fn: Any,
    *,
    record_id: str,
    source_id: str,
    project_id: str,
    chunks: list[str],
    user_id: str,
    session_id: str,
) -> None:
    for chunk_index, chunk_text in enumerate(chunks):
        conn.execute(
            text_fn(
                """
                INSERT INTO flare_knowledge_chunks (
                    id, record_id, trace_id, project_id, user_id, session_id,
                    chunk_index, content, created_at
                ) VALUES (
                    :id, :record_id, :trace_id, :project_id, :user_id, :session_id,
                    :chunk_index, :content, CURRENT_TIMESTAMP
                )
                """
            ),
            {
                "id": f"chunk-{uuid.uuid4().hex}",
                "record_id": record_id,
                "trace_id": f"ingest-{source_id}",
                "project_id": project_id,
                "user_id": user_id,
                "session_id": session_id,
                "chunk_index": chunk_index,
                "content": chunk_text,
            },
        )


__all__ = ["persist_searchable_knowledge_record"]
