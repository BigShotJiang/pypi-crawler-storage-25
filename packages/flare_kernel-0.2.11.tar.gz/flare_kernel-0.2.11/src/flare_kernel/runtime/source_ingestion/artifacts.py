"""Document artifact orchestration for uploaded sources."""

from __future__ import annotations

from typing import Any

from flare_engines import run_document_understanding


def build_source_document_result(
    *,
    source: dict[str, Any],
    content: str,
    document_understanding_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    source_id = str(source.get("source_id") or source.get("id") or "").strip()
    return run_document_understanding(
        {
            "source_id": source_id,
            "title": str(source.get("filename") or source_id),
            "content": content,
            "config": document_understanding_config or {},
            "metadata": {
                "project_id": str(source.get("project_id") or ""),
                "user_id": str(source.get("user_id") or ""),
                "session_id": str(source.get("session_id") or ""),
                "mime_type": str(source.get("mime_type") or ""),
                "source": str(source.get("source") or "local_upload"),
            },
        }
    )


def apply_source_document_context(*, source: dict[str, Any], document_result: dict[str, Any]) -> None:
    session_id = str(source.get("session_id") or "").strip()
    if not session_id or not document_result:
        return
    from flare_kernel.session_store import append_exchange

    append_exchange(
        session_id=session_id,
        document_result=document_result,
        context_refs=[
            {
                "source_id": str(source.get("source_id") or ""),
                "source": "local_upload",
                "title": str(source.get("filename") or ""),
            }
        ],
    )


__all__ = ["apply_source_document_context", "build_source_document_result"]
