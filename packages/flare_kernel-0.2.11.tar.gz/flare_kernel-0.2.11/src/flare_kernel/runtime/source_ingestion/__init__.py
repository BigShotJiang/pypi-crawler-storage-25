"""Source ingestion runtime package."""

from __future__ import annotations

from flare_kernel.runtime.source_ingestion.runtime import run_source_ingestion_pipeline

__all__ = ["run_source_ingestion_pipeline"]
