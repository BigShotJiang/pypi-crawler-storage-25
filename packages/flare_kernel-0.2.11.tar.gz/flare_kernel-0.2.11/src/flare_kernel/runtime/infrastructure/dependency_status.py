"""Runtime dependency and capability probes."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine
from flare_kernel.runtime.infrastructure.redis_client import build_redis_client
from flare_kernel.runtime.infrastructure.vector_store import qdrant_client
from flare_kernel.runtime.llm.llm_provider import get_llm_provider_config


def postgres_ready(*, build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine) -> bool:
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        return False
    try:
        from sqlalchemy import text

        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception:
        return False


def redis_ready(*, redis_client_fn: Callable[[], Any] = build_redis_client) -> bool:
    client = redis_client_fn()
    if client is None:
        return False
    try:
        return bool(client.ping())
    except Exception:
        return False


def qdrant_ready(*, qdrant_client_fn: Callable[[], Any] = qdrant_client) -> bool:
    client = qdrant_client_fn()
    if client is None:
        return False
    try:
        client.get_collections()
        return True
    except Exception:
        return False


def collect_dependency_status(
    *,
    build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine,
    redis_client_fn: Callable[[], Any] = build_redis_client,
    qdrant_client_fn: Callable[[], Any] = qdrant_client,
) -> dict[str, bool]:
    llm_config = get_llm_provider_config()
    llm_ready = llm_config.backend == "dashscope" and bool(llm_config.dashscope_api_key)
    return {
        "llm_ready": llm_ready,
        "postgres_ready": postgres_ready(build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn),
        "redis_ready": redis_ready(redis_client_fn=redis_client_fn),
        "qdrant_ready": qdrant_ready(qdrant_client_fn=qdrant_client_fn),
    }


def collect_capability_status(*, dependency_status: dict[str, bool]) -> dict[str, bool]:
    rag_ready = bool(dependency_status.get("qdrant_ready") or dependency_status.get("postgres_ready"))
    return {
        "canvas_ready": True,
        "rag_ready": rag_ready,
        "plan_ready": True,
    }
