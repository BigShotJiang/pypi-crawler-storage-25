"""Knowledge retrieval orchestration across vector, SQL, and memory stores."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine
from flare_kernel.runtime.infrastructure.knowledge_memory import search_memory_knowledge_records
from flare_kernel.runtime.infrastructure.knowledge_postgres_search import search_postgres_knowledge
from flare_kernel.runtime.infrastructure.knowledge_qdrant_search import search_qdrant_knowledge
from flare_kernel.runtime.infrastructure.knowledge_terms import normalize_entity_terms
from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.infrastructure.vector_store import ensure_qdrant_collection, qdrant_client

logger = get_logger("flare_kernel.runtime.infrastructure.knowledge_search")


def search_knowledge_records(
    *,
    trace_id: str,
    project_id: str,
    user_id: str,
    query: str,
    top_k: int,
    min_score: float = 0.0,
    source_ids: list[str] | None = None,
    entities: list[dict[str, Any] | str] | None = None,
    entity_query_mode: str = "prefer",
    query_lane: str = "semantic",
    build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine,
    qdrant_client_fn: Callable[[], Any] = qdrant_client,
    ensure_collection_fn: Callable[[Any, str], None] = ensure_qdrant_collection,
) -> list[dict[str, Any]]:
    clean_query = query.strip()
    if not clean_query:
        return []
    normalized_source_ids = [str(item).strip() for item in (source_ids or []) if str(item).strip()]
    entity_terms = normalize_entity_terms(entities=entities, query=clean_query, query_lane=query_lane)
    qdrant_results = _search_qdrant(
        trace_id=trace_id,
        project_id=project_id,
        user_id=user_id,
        query=clean_query,
        top_k=top_k,
        min_score=min_score,
        source_ids=normalized_source_ids,
        entity_terms=entity_terms,
        entity_query_mode=entity_query_mode,
        query_lane=query_lane,
        qdrant_client_fn=qdrant_client_fn,
        ensure_collection_fn=ensure_collection_fn,
    )
    if qdrant_results:
        return qdrant_results[: max(1, min(top_k, 20))]
    postgres_results = _search_postgres(
        trace_id=trace_id,
        project_id=project_id,
        user_id=user_id,
        query=clean_query,
        top_k=top_k,
        source_ids=normalized_source_ids,
        entity_terms=entity_terms,
        entity_query_mode=entity_query_mode,
        query_lane=query_lane,
        build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
    )
    if postgres_results:
        return postgres_results
    return search_memory_knowledge_records(
        project_id=project_id,
        user_id=user_id,
        query=clean_query,
        top_k=top_k,
        source_ids=normalized_source_ids,
    )


def _search_qdrant(**kwargs: Any) -> list[dict[str, Any]]:
    trace_id = str(kwargs.pop("trace_id"))
    try:
        return search_qdrant_knowledge(**kwargs)
    except Exception as exc:
        logger.warning("knowledge.search.qdrant_failed trace_id=%s error=%s", trace_id, str(exc))
        return []


def _search_postgres(**kwargs: Any) -> list[dict[str, Any]] | None:
    trace_id = str(kwargs.pop("trace_id"))
    try:
        return search_postgres_knowledge(**kwargs)
    except Exception as exc:
        logger.warning("knowledge.search.postgres_failed trace_id=%s error=%s", trace_id, str(exc))
        return []
