"""Qdrant vector-store boundary for runtime infrastructure."""

from __future__ import annotations

import hashlib
import os
from typing import Any

_DEFAULT_QDRANT_URL = "http://127.0.0.1:6333"
_KNOWLEDGE_COLLECTION = "flare_knowledge_v1"
_EMBEDDING_DIM = 8


def _env(name: str, default: str | None = None) -> str | None:
    raw = os.getenv(name)
    if raw is None:
        return default
    value = raw.strip()
    return value if value else default


def stable_embedding(text: str, dim: int = _EMBEDDING_DIM) -> list[float]:
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    values: list[float] = []
    for index in range(dim):
        byte_value = digest[index]
        values.append((byte_value / 255.0) * 2 - 1)
    return values


def qdrant_client() -> Any:
    try:
        from qdrant_client import QdrantClient
    except Exception:
        return None

    qdrant_url = _env("FLARE_QDRANT_URL", _DEFAULT_QDRANT_URL) or _DEFAULT_QDRANT_URL
    qdrant_api_key = _env("FLARE_QDRANT_API_KEY")
    return QdrantClient(url=qdrant_url, api_key=qdrant_api_key, timeout=3.0)


def ensure_qdrant_collection(client: Any, collection_name: str = _KNOWLEDGE_COLLECTION) -> None:
    if not hasattr(client, "get_collection") or not hasattr(client, "create_collection"):
        return
    try:
        from qdrant_client.http import models
    except Exception as exc:
        raise RuntimeError("qdrant models unavailable") from exc

    try:
        client.get_collection(collection_name)
    except Exception:
        client.create_collection(
            collection_name=collection_name,
            vectors_config=models.VectorParams(size=_EMBEDDING_DIM, distance=models.Distance.COSINE),
        )


__all__ = [
    "_EMBEDDING_DIM",
    "_KNOWLEDGE_COLLECTION",
    "ensure_qdrant_collection",
    "qdrant_client",
    "stable_embedding",
]
