"""Instance-profile-backed sourcing adapter.

DOC HELPER — SRC-02 instance data adapter boundary.
This adapter reads curated sourcing rows from instance/provider config and
returns normalized provider-contract rows. It performs no persistence, network
IO, workflow decisions, or UI state changes.
"""

from __future__ import annotations

import json
from typing import Any

from flare_kernel.runtime.infrastructure.sourcing.provider_config import resolve_top_k
from flare_kernel.runtime.infrastructure.sourcing.provider_result import provider_result, trace_entry

_INSTANCE_CONFIG_KEYS = ("instance_db", "instance_database", "database")
_RECORD_KEYS = ("records", "items", "candidates", "suppliers")
_SUPPLIER_IDENTITY_KEYS = (
    "supplier_id",
    "supplier_name",
    "vendor_id",
    "vendor_name",
    "company_id",
    "company_name",
)


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    return list(value) if isinstance(value, list) else []


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _instance_config(provider_config: dict[str, Any] | None) -> dict[str, Any]:
    """Resolve the instance database config node.

    Args:
        provider_config: Provider configuration payload.

    Returns:
        Instance database config dict, or an empty dict when unavailable.
    """
    config = _as_dict(provider_config)
    for key in _INSTANCE_CONFIG_KEYS:
        node = config.get(key)
        if isinstance(node, dict):
            return node
    return {}


def _configured_records(instance_config: dict[str, Any]) -> list[dict[str, Any]]:
    """Resolve configured instance sourcing records.

    Args:
        instance_config: Instance database config node.

    Returns:
        First non-empty configured record list.
    """
    for key in _RECORD_KEYS:
        rows = [item for item in _as_list(instance_config.get(key)) if isinstance(item, dict)]
        if rows:
            return rows
    return []


def _has_supplier_identity(item: dict[str, Any]) -> bool:
    """Check whether a record has supplier identity fields.

    Args:
        item: Instance record row.

    Returns:
        True when supplier/vendor/company identity is present.
    """
    return any(_clean_text(item.get(key)) for key in _SUPPLIER_IDENTITY_KEYS)


def _search_blob(item: dict[str, Any]) -> str:
    """Build searchable text for an instance record.

    Args:
        item: Instance record row.

    Returns:
        Lowercase serialized search text.
    """
    try:
        return json.dumps(item, ensure_ascii=False, sort_keys=True).lower()
    except TypeError:
        return " ".join(_clean_text(value).lower() for value in item.values())


def _query_terms(query: str) -> list[str]:
    """Split a query into matching terms.

    Args:
        query: User sourcing query.

    Returns:
        Non-empty lowercase query terms.
    """
    terms = [_clean_text(part).lower() for part in _clean_text(query).split()]
    return [term for term in terms if term]


def _match_score(*, item: dict[str, Any], terms: list[str]) -> float:
    """Compute simple term-match score for an instance record.

    Args:
        item: Instance record row.
        terms: Query terms.

    Returns:
        Match score between 0 and 1, or configured score when no terms exist.
    """
    if not terms:
        return float(item.get("score") or item.get("match_score") or 0.0)
    blob = _search_blob(item)
    matched = sum(1 for term in terms if term in blob)
    if matched == 0:
        return 0.0
    return max(float(item.get("score") or 0.0), matched / len(terms))


def _normalize_record(item: dict[str, Any], *, index: int, score: float) -> dict[str, Any]:
    """Normalize an instance record into provider-contract shape.

    Args:
        item: Instance record row.
        index: One-based row index.
        score: Computed match score.

    Returns:
        Normalized sourcing row with instance provider metadata.
    """
    title = _clean_text(
        item.get("title")
        or item.get("source_title")
        or item.get("supplier_name")
        or item.get("vendor_name")
        or item.get("company_name")
        or item.get("name")
    )
    snippet = _clean_text(item.get("snippet") or item.get("summary") or item.get("description") or item.get("content"))
    row = {
        **item,
        "title": title,
        "source_title": _clean_text(item.get("source_title") or title),
        "snippet": snippet,
        "source_type": "instance_db",
        "provider": _clean_text(item.get("provider") or "instance_db"),
        "raw_id": _clean_text(item.get("raw_id") or item.get("id") or item.get("record_id") or f"instance_db-{index}"),
        "score": score,
    }
    if "result_role" not in row and _has_supplier_identity(row):
        row["result_role"] = "candidate"
    return row


def _rank_records(*, records: list[dict[str, Any]], query: str, top_k: int) -> list[dict[str, Any]]:
    """Rank configured instance records for a query.

    Args:
        records: Instance record rows.
        query: User sourcing query.
        top_k: Maximum requested row count.

    Returns:
        Ranked normalized rows capped by top_k.
    """
    terms = _query_terms(query)
    ranked: list[tuple[float, int, dict[str, Any]]] = []
    for index, item in enumerate(records, start=1):
        score = _match_score(item=item, terms=terms)
        if terms and score <= 0.0:
            continue
        ranked.append((score, index, _normalize_record(item, index=index, score=score)))
    ranked.sort(key=lambda row: (-row[0], row[1]))
    return [row for _, _, row in ranked[: resolve_top_k(top_k)]]


def search_instance_records(
    *,
    query: str,
    top_k: int,
    trace_id: str = "",
    session_id: str = "",
    project_id: str = "",
    user_id: str = "",
    provider_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Search instance-configured sourcing records.

    Args:
        query: User sourcing query.
        top_k: Maximum requested row count.
        trace_id: Trace identifier.
        session_id: Session identifier.
        project_id: Project identifier.
        user_id: User identifier.
        provider_config: Provider configuration payload.

    Returns:
        Provider result with normalized instance rows and provider trace.
    """
    instance_config = _instance_config(provider_config)
    if instance_config.get("enabled") is False:
        return provider_result(
            provider_trace=[trace_entry(provider="instance_db", status="skipped", reason="source_disabled")]
        )
    records = _configured_records(instance_config)
    if not records:
        return provider_result(
            provider_trace=[
                trace_entry(provider="instance_db", status="unavailable", reason="missing_instance_records")
            ]
        )
    rows = _rank_records(records=records, query=query, top_k=top_k)
    return provider_result(
        items=rows,
        selected_provider="instance_db" if rows else "",
        provider_trace=[
            trace_entry(
                provider="instance_db",
                status="ok" if rows else "empty",
                hit_count=len(rows),
                reason="instance_profile_records" if rows else "no_matching_instance_records",
            )
        ],
    )


__all__ = ["search_instance_records"]
