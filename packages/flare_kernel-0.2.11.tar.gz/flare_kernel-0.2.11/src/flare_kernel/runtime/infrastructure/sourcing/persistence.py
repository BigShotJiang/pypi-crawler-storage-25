"""Sourcing persistence helpers."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any, Callable


def _utcnow_iso() -> str:
    return datetime.now(UTC).isoformat()


def persist_sourcing_run_bundle(
    *,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    query: str,
    source_scope: str,
    candidates: list[dict[str, Any]],
    shortlist: list[dict[str, Any]],
    build_sqlalchemy_engine_fn: Callable[[], Any],
    **_: Any,
) -> dict[str, Any]:
    retrieval_run_id = f"sourcing-{uuid.uuid4().hex}"
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        return {
            "retrieval_run_id": retrieval_run_id,
            "persisted": False,
            "reason": "engine_unavailable",
        }
    try:
        from sqlalchemy import text

        created_at = _utcnow_iso()
        shortlist_id = f"shortlist-{uuid.uuid4().hex}"
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS flare_sourcing_retrieval_run (
                        retrieval_run_id TEXT PRIMARY KEY,
                        trace_id TEXT,
                        session_id TEXT,
                        project_id TEXT,
                        user_id TEXT,
                        query_text TEXT,
                        source_scope TEXT,
                        result_count INTEGER,
                        created_at TEXT
                    )
                    """
                )
            )
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS flare_sourcing_candidate (
                        id TEXT PRIMARY KEY,
                        retrieval_run_id TEXT,
                        session_id TEXT,
                        project_id TEXT,
                        user_id TEXT,
                        source_type TEXT,
                        title TEXT,
                        snippet TEXT,
                        source_url TEXT,
                        score REAL,
                        raw_payload_json TEXT,
                        created_at TEXT
                    )
                    """
                )
            )
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS flare_sourcing_shortlist (
                        id TEXT PRIMARY KEY,
                        session_id TEXT,
                        project_id TEXT,
                        user_id TEXT,
                        name TEXT,
                        status TEXT,
                        created_at TEXT,
                        updated_at TEXT
                    )
                    """
                )
            )
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS flare_sourcing_shortlist_item (
                        id TEXT PRIMARY KEY,
                        shortlist_id TEXT,
                        candidate_id TEXT,
                        starred INTEGER,
                        note TEXT,
                        created_at TEXT,
                        updated_at TEXT
                    )
                    """
                )
            )
            conn.execute(
                text(
                    """
                    INSERT INTO flare_sourcing_retrieval_run (
                        retrieval_run_id, trace_id, session_id, project_id, user_id,
                        query_text, source_scope, result_count, created_at
                    ) VALUES (
                        :retrieval_run_id, :trace_id, :session_id, :project_id, :user_id,
                        :query_text, :source_scope, :result_count, :created_at
                    )
                    """
                ),
                {
                    "retrieval_run_id": retrieval_run_id,
                    "trace_id": trace_id,
                    "session_id": session_id,
                    "project_id": project_id,
                    "user_id": user_id,
                    "query_text": query,
                    "source_scope": source_scope,
                    "result_count": len(candidates),
                    "created_at": created_at,
                },
            )
            conn.execute(
                text(
                    """
                    INSERT INTO flare_sourcing_shortlist (
                        id, session_id, project_id, user_id, name, status, created_at, updated_at
                    ) VALUES (
                        :id, :session_id, :project_id, :user_id, :name, :status, :created_at, :updated_at
                    )
                    """
                ),
                {
                    "id": shortlist_id,
                    "session_id": session_id,
                    "project_id": project_id,
                    "user_id": user_id,
                    "name": "默认候选名单",
                    "status": "active",
                    "created_at": created_at,
                    "updated_at": created_at,
                },
            )
            candidate_id_list: list[str] = []
            for item in candidates:
                candidate_id = f"candidate-{uuid.uuid4().hex}"
                candidate_id_list.append(candidate_id)
                conn.execute(
                    text(
                        """
                        INSERT INTO flare_sourcing_candidate (
                            id, retrieval_run_id, session_id, project_id, user_id, source_type,
                            title, snippet, source_url, score, raw_payload_json, created_at
                        ) VALUES (
                            :id, :retrieval_run_id, :session_id, :project_id, :user_id, :source_type,
                            :title, :snippet, :source_url, :score, :raw_payload_json, :created_at
                        )
                        """
                    ),
                    {
                        "id": candidate_id,
                        "retrieval_run_id": retrieval_run_id,
                        "session_id": session_id,
                        "project_id": project_id,
                        "user_id": user_id,
                        "source_type": str(item.get("source_type") or "local"),
                        "title": str(item.get("title") or ""),
                        "snippet": str(item.get("snippet") or ""),
                        "source_url": str(item.get("url") or ""),
                        "score": float(item.get("score") or 0.0),
                        "raw_payload_json": str(item),
                        "created_at": created_at,
                    },
                )
            for shortlist_row in shortlist:
                matched_id = _match_candidate_id(shortlist_row=shortlist_row, candidates=candidates, ids=candidate_id_list)
                conn.execute(
                    text(
                        """
                        INSERT INTO flare_sourcing_shortlist_item (
                            id, shortlist_id, candidate_id, starred, note, created_at, updated_at
                        ) VALUES (
                            :id, :shortlist_id, :candidate_id, :starred, :note, :created_at, :updated_at
                        )
                        """
                    ),
                    {
                        "id": f"shortlist-item-{uuid.uuid4().hex}",
                        "shortlist_id": shortlist_id,
                        "candidate_id": matched_id,
                        "starred": 0,
                        "note": "",
                        "created_at": created_at,
                        "updated_at": created_at,
                    },
                )
    except Exception as exc:
        return {
            "retrieval_run_id": retrieval_run_id,
            "persisted": False,
            "reason": str(exc),
        }
    return {
        "retrieval_run_id": retrieval_run_id,
        "persisted": True,
        "shortlist_id": shortlist_id,
    }


def _match_candidate_id(*, shortlist_row: dict[str, Any], candidates: list[dict[str, Any]], ids: list[str]) -> str:
    shortlist_title = str(shortlist_row.get("supplier_name") or "").strip().lower()
    for index, candidate in enumerate(candidates):
        if str(candidate.get("title") or "").strip().lower() == shortlist_title:
            return ids[index]
    return ids[0] if ids else ""


def load_latest_sourcing_run_bundle(
    *,
    session_id: str,
    project_id: str,
    user_id: str,
    build_sqlalchemy_engine_fn: Callable[[], Any],
) -> dict[str, Any]:
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        return {}
    try:
        from sqlalchemy import text

        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS flare_sourcing_retrieval_run (
                        retrieval_run_id TEXT PRIMARY KEY,
                        trace_id TEXT,
                        session_id TEXT,
                        project_id TEXT,
                        user_id TEXT,
                        query_text TEXT,
                        source_scope TEXT,
                        result_count INTEGER,
                        created_at TEXT
                    )
                    """
                )
            )
            row = conn.execute(
                text(
                    """
                    SELECT retrieval_run_id, query_text, result_count, source_scope, created_at
                    FROM flare_sourcing_retrieval_run
                    WHERE session_id = :session_id
                      AND project_id = :project_id
                      AND user_id = :user_id
                    ORDER BY created_at DESC
                    LIMIT 1
                    """
                ),
                {
                    "session_id": session_id,
                    "project_id": project_id,
                    "user_id": user_id,
                },
            ).mappings().first()
        if row is None:
            return {}
        return {
            "retrieval_run_id": str(row.get("retrieval_run_id") or "").strip(),
            "query": str(row.get("query_text") or "").strip(),
            "top_k": int(row.get("result_count") or 0),
            "source_scope": str(row.get("source_scope") or "").strip(),
            "created_at": str(row.get("created_at") or "").strip(),
        }
    except Exception:
        return {}
