"""Configuration helpers for sourcing provider adapters."""

from __future__ import annotations

import os
from typing import Any


def env_value(name: str, default: str = "") -> str:
    raw = os.getenv(name)
    if raw is None:
        return default
    value = raw.strip()
    return value if value else default


def _timeout_ms_from_config(provider_config: dict[str, Any] | None) -> Any:
    config = provider_config if isinstance(provider_config, dict) else {}
    return config.get("timeout_ms") or config.get("provider_timeout_ms")


def timeout_seconds(provider_config: dict[str, Any] | None = None) -> float:
    raw = _timeout_ms_from_config(provider_config) or env_value("SOURCING_TIMEOUT_MS", "3000")
    try:
        timeout_ms = int(raw)
    except (TypeError, ValueError):
        timeout_ms = 3000
    return max(0.5, min(timeout_ms / 1000.0, 20.0))


def max_top_k() -> int:
    raw = env_value("SOURCING_MAX_TOP_K", "100")
    try:
        value = int(raw)
    except (TypeError, ValueError):
        value = 100
    return max(1, min(value, 100))


def resolve_top_k(top_k: int) -> int:
    return max(1, min(int(top_k), max_top_k()))


def dev_mode() -> str:
    raw = env_value("SOURCING_DEV_MODE", "gateway").lower()
    if raw in {"gateway", "direct"}:
        return raw
    return "gateway"


def provider_name() -> str:
    return env_value("SOURCING_PROVIDER", "hybrid").lower()


__all__ = [
    "dev_mode",
    "env_value",
    "max_top_k",
    "provider_name",
    "resolve_top_k",
    "timeout_seconds",
]
