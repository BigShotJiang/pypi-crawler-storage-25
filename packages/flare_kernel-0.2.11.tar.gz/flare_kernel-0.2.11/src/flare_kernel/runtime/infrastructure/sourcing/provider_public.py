"""Public web fallback provider for sourcing."""

from __future__ import annotations

import json
import re
import socket
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from flare_kernel.runtime.infrastructure.sourcing.provider_config import resolve_top_k, timeout_seconds
from flare_kernel.runtime.infrastructure.sourcing.provider_normalize import normalize_items, normalize_public_url
from flare_kernel.runtime.infrastructure.sourcing.provider_result import provider_result, trace_entry

_DUCKDUCKGO_INSTANT_API = "https://api.duckduckgo.com/"
_DUCKDUCKGO_HTML_SEARCH = "https://duckduckgo.com/html/"


def search_public_ddg(*, query: str, top_k: int, provider_config: dict[str, Any] | None = None) -> dict[str, Any]:
    clean_query = str(query or "").strip()
    if not clean_query:
        return provider_result(
            provider_trace=[trace_entry(provider="public_ddg", status="skipped", reason="empty_query")]
        )
    html_result = _search_public_ddg_html(query=clean_query, top_k=top_k, provider_config=provider_config)
    if html_result.get("items"):
        return html_result
    instant_result = _search_public_ddg_instant(query=clean_query, top_k=top_k, provider_config=provider_config)
    if instant_result.get("items"):
        return provider_result(
            items=instant_result["items"],
            selected_provider=str(instant_result.get("selected_provider") or ""),
            provider_trace=[*html_result.get("provider_trace", []), *instant_result.get("provider_trace", [])],
        )
    return provider_result(
        provider_trace=[*html_result.get("provider_trace", []), *instant_result.get("provider_trace", [])]
    )


def search_public_ddg_instant_items(
    *, query: str, top_k: int, provider_config: dict[str, Any] | None = None
) -> list[dict[str, Any]]:
    result = _search_public_ddg_instant(query=query, top_k=top_k, provider_config=provider_config)
    return list(result.get("items") or [])


def _search_public_ddg_instant(*, query: str, top_k: int, provider_config: dict[str, Any] | None) -> dict[str, Any]:
    params = urllib.parse.urlencode({"q": query, "format": "json", "no_html": "1", "skip_disambig": "1"})
    request_url = f"{_DUCKDUCKGO_INSTANT_API}?{params}"
    try:
        with urllib.request.urlopen(request_url, timeout=timeout_seconds(provider_config)) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except Exception as exc:
        return provider_result(
            provider_trace=[trace_entry(provider="public_ddg", status="failed", reason=_public_failure_reason(exc))]
        )

    rows = _instant_payload_rows(payload=payload, query=query)
    items = normalize_items(items=rows, source_type="domestic_web", provider="public_ddg", top_k=top_k)
    return provider_result(
        items=items,
        selected_provider="public_ddg" if items else "",
        provider_trace=[
            trace_entry(
                provider="public_ddg",
                status="ok" if items else "empty",
                hit_count=len(items),
                reason="public_fallback" if items else "no_results",
            )
        ],
    )


def _instant_payload_rows(*, payload: dict[str, Any], query: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    related_topics = payload.get("RelatedTopics")
    if isinstance(related_topics, list):
        rows.extend(_related_topic_rows(related_topics))
    abstract_text = str(payload.get("AbstractText") or "").strip()
    if abstract_text:
        rows.insert(
            0,
            {
                "title": str(payload.get("Heading") or "").strip() or query,
                "snippet": abstract_text,
                "url": str(payload.get("AbstractURL") or "").strip(),
                "score": 0.95,
            },
        )
    return rows


def _related_topic_rows(related_topics: list[Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for topic in related_topics:
        if isinstance(topic, dict) and isinstance(topic.get("Topics"), list):
            rows.extend(_related_topic_rows(topic.get("Topics", [])))
            continue
        if not isinstance(topic, dict):
            continue
        rows.append(
            {
                "title": str(topic.get("Text") or topic.get("Result") or "").strip(),
                "snippet": str(topic.get("Text") or "").strip(),
                "url": str(topic.get("FirstURL") or "").strip(),
                "score": 0.6,
            }
        )
    return rows


def search_public_ddg_html_items(
    *, query: str, top_k: int, provider_config: dict[str, Any] | None = None
) -> list[dict[str, Any]]:
    result = _search_public_ddg_html(query=query, top_k=top_k, provider_config=provider_config)
    return list(result.get("items") or [])


def _search_public_ddg_html(*, query: str, top_k: int, provider_config: dict[str, Any] | None) -> dict[str, Any]:
    request_url = f"{_DUCKDUCKGO_HTML_SEARCH}?{urllib.parse.urlencode({'q': query})}"
    req = urllib.request.Request(
        request_url,
        method="GET",
        headers={
            "User-Agent": "Mozilla/5.0 (compatible; FLARE-DEV/1.0)",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout_seconds(provider_config)) as response:
            html = response.read().decode("utf-8", errors="ignore")
    except Exception as exc:
        return provider_result(
            provider_trace=[trace_entry(provider="public_ddg_html", status="failed", reason=_public_failure_reason(exc))]
        )
    items = _html_items(html=html, top_k=top_k)
    return provider_result(
        items=items,
        selected_provider="public_ddg_html" if items else "",
        provider_trace=[
            trace_entry(
                provider="public_ddg_html",
                status="ok" if items else "empty",
                hit_count=len(items),
                reason="public_fallback" if items else "no_results",
            )
        ],
    )


def _html_items(*, html: str, top_k: int) -> list[dict[str, Any]]:
    if not html:
        return []
    rows: list[dict[str, Any]] = []
    pattern = re.compile(
        r'<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="(?P<href>[^"]+)"[^>]*>(?P<title>.*?)</a>',
        re.IGNORECASE | re.DOTALL,
    )
    for match in pattern.finditer(html):
        href = normalize_public_url(urllib.parse.unquote(str(match.group("href") or "").strip()))
        title = re.sub(r"<[^>]+>", "", str(match.group("title") or "").strip()).strip()
        if not href or not title:
            continue
        rows.append({"title": title, "snippet": title, "url": href, "score": 0.65})
        if len(rows) >= resolve_top_k(top_k):
            break
    return normalize_items(items=rows, source_type="domestic_web", provider="public_ddg_html", top_k=top_k)


def _public_failure_reason(exc: Exception) -> str:
    if isinstance(exc, (TimeoutError, socket.timeout)):
        return "timeout"
    if isinstance(exc, urllib.error.URLError) and "timed out" in str(exc.reason).lower():
        return "timeout"
    return "public_request_failed"


__all__ = ["search_public_ddg", "search_public_ddg_html_items", "search_public_ddg_instant_items"]
