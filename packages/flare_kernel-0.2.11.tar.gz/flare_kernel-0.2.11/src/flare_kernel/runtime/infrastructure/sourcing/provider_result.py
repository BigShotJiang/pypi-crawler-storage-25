"""Result contract helpers for sourcing provider adapters."""

from __future__ import annotations

from typing import Any


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def trace_entry(*, provider: str, status: str, hit_count: int = 0, reason: str = "") -> dict[str, Any]:
    return {
        "provider": _clean_text(provider),
        "source": _clean_text(provider),
        "status": _clean_text(status),
        "hit_count": max(0, int(hit_count or 0)),
        "reason": _clean_text(reason),
    }


def provider_result(
    *,
    items: list[dict[str, Any]] | None = None,
    provider_trace: list[dict[str, Any]] | None = None,
    selected_provider: str = "",
    fallbacks: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "items": list(items or []),
        "provider_trace": list(provider_trace or []),
        "selected_provider": _clean_text(selected_provider),
        "fallbacks": list(fallbacks or []),
    }


__all__ = ["provider_result", "trace_entry"]
