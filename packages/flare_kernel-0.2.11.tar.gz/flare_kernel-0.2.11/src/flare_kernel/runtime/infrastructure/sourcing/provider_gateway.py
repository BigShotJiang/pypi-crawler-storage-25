"""Gateway-backed sourcing provider calls."""

from __future__ import annotations

import json
import socket
import urllib.error
import urllib.request
from typing import Any

from flare_kernel.runtime.infrastructure.sourcing.provider_config import resolve_top_k, timeout_seconds
from flare_kernel.runtime.infrastructure.sourcing.provider_normalize import normalize_items
from flare_kernel.runtime.infrastructure.sourcing.provider_result import provider_result, trace_entry


def post_gateway_search(
    *,
    url: str,
    provider: str,
    source_type: str,
    query: str,
    top_k: int,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    provider_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    endpoint = str(url or "").strip().rstrip("/")
    if not endpoint:
        return provider_result(
            provider_trace=[trace_entry(provider=provider, status="skipped", reason="missing_gateway_url")]
        )
    request_url = endpoint if endpoint.endswith("/search") else f"{endpoint}/search"
    payload = {
        "query": query,
        "top_k": resolve_top_k(top_k),
        "scope": "sourcing",
        "trace_id": trace_id,
        "session_id": session_id,
        "project_id": project_id,
        "user_id": user_id,
    }
    req = urllib.request.Request(
        request_url,
        data=json.dumps(payload).encode("utf-8"),
        method="POST",
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout_seconds(provider_config)) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        return provider_result(
            provider_trace=[trace_entry(provider=provider, status="failed", reason=_gateway_failure_reason(exc))]
        )

    raw_items = data if isinstance(data, list) else data.get("items") if isinstance(data, dict) else []
    if not isinstance(raw_items, list):
        return provider_result(
            provider_trace=[trace_entry(provider=provider, status="failed", reason="invalid_gateway_payload")]
        )
    rows = normalize_items(items=raw_items, source_type=source_type, provider=provider, top_k=top_k)
    status = "ok" if rows else "empty"
    reason = "gateway_results" if rows else "no_results"
    return provider_result(
        items=rows,
        selected_provider=provider if rows else "",
        provider_trace=[trace_entry(provider=provider, status=status, hit_count=len(rows), reason=reason)],
    )


def _gateway_failure_reason(exc: Exception) -> str:
    if isinstance(exc, (TimeoutError, socket.timeout)):
        return "timeout"
    if isinstance(exc, urllib.error.URLError) and "timed out" in str(exc.reason).lower():
        return "timeout"
    return "gateway_request_failed"


__all__ = ["post_gateway_search"]
