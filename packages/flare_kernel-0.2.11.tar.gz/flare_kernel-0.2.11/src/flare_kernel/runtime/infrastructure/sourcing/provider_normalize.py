"""Normalize external provider payloads into sourcing candidate rows."""

from __future__ import annotations

import urllib.parse
from typing import Any

from flare_kernel.runtime.infrastructure.sourcing.provider_config import resolve_top_k


def normalize_public_url(raw_url: str) -> str:
    value = str(raw_url or "").strip()
    if not value:
        return ""
    if value.startswith("//"):
        value = f"https:{value}"
    try:
        parsed = urllib.parse.urlparse(value)
    except Exception:
        return value
    if "duckduckgo.com" in str(parsed.netloc).lower():
        query = urllib.parse.parse_qs(parsed.query or "")
        redirect = query.get("uddg")
        if isinstance(redirect, list) and redirect:
            target = str(redirect[0] or "").strip()
            if target:
                return target
    return value


def normalize_item(item: dict[str, Any], *, source_type: str, provider: str, index: int) -> dict[str, Any]:
    canonical_url = normalize_public_url(
        str(item.get("canonical_url") or item.get("url") or item.get("link") or item.get("source_url") or "").strip()
    )
    title = str(
        item.get("source_title")
        or item.get("title")
        or item.get("name")
        or item.get("supplier_name")
        or ""
    ).strip()
    snippet = str(item.get("snippet") or item.get("summary") or item.get("content") or "").strip()
    source_domain = ""
    if canonical_url:
        try:
            source_domain = str(urllib.parse.urlparse(canonical_url).netloc or "").strip().lower()
        except Exception:
            source_domain = ""
    raw_id = str(item.get("raw_id") or item.get("id") or item.get("record_id") or f"{provider}-{index}").strip()
    try:
        score = float(item.get("score") or item.get("match_score") or 0.0)
    except (TypeError, ValueError):
        score = 0.0
    return {
        "title": title,
        "source_title": title,
        "snippet": snippet,
        "url": canonical_url,
        "canonical_url": canonical_url,
        "source_domain": source_domain,
        "source_meta": {
            "source_title": title,
            "canonical_url": canonical_url,
            "source_domain": source_domain,
            "publish_time": str(item.get("publish_time") or "").strip() or None,
            "slots": item.get("source_meta_slots") if isinstance(item.get("source_meta_slots"), dict) else {},
        },
        "source_type": source_type,
        "score": score,
        "provider": provider,
        "raw_id": raw_id,
        "publish_time": str(item.get("publish_time") or "").strip() or None,
    }


def normalize_items(
    *,
    items: list[dict[str, Any]],
    source_type: str,
    provider: str,
    top_k: int,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            continue
        normalized = normalize_item(item, source_type=source_type, provider=provider, index=index)
        if not normalized.get("title") and not normalized.get("snippet"):
            continue
        rows.append(normalized)
    return rows[: resolve_top_k(top_k)]


__all__ = ["normalize_item", "normalize_items", "normalize_public_url"]
