"""External sourcing provider facade with capability gates."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.infrastructure.sourcing.provider_config import dev_mode, env_value, provider_name
from flare_kernel.runtime.infrastructure.sourcing.provider_gateway import post_gateway_search
from flare_kernel.runtime.infrastructure.sourcing.provider_public import search_public_ddg
from flare_kernel.runtime.infrastructure.sourcing.provider_result import provider_result, trace_entry


def _merge_provider_results(*results: dict[str, Any]) -> dict[str, Any]:
    items: list[dict[str, Any]] = []
    provider_trace: list[dict[str, Any]] = []
    fallbacks: list[str] = []
    selected_provider = ""
    for result in results:
        result_items = result.get("items") if isinstance(result, dict) else []
        result_trace = result.get("provider_trace") if isinstance(result, dict) else []
        if isinstance(result_items, list) and result_items and not items:
            items = result_items
            selected_provider = str(result.get("selected_provider") or "").strip()
        if isinstance(result_trace, list):
            provider_trace.extend(item for item in result_trace if isinstance(item, dict))
        if not items:
            fallback = str(result.get("selected_provider") or "").strip()
            if fallback:
                fallbacks.append(fallback)
    return provider_result(
        items=items,
        selected_provider=selected_provider,
        provider_trace=provider_trace,
        fallbacks=fallbacks,
    )


def _intranet_search_result(
    *,
    query: str,
    top_k: int,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    provider_config: dict[str, Any] | None,
) -> dict[str, Any]:
    return post_gateway_search(
        url=env_value("INTRANET_SEARCH_URL", ""),
        provider="intranet_gateway",
        source_type="intranet",
        query=query,
        top_k=top_k,
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        provider_config=provider_config,
    )


def _domestic_gateway_result(
    *,
    query: str,
    top_k: int,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    provider_config: dict[str, Any] | None,
) -> dict[str, Any]:
    return post_gateway_search(
        url=env_value("DOMESTIC_GATEWAY_URL", ""),
        provider="domestic_gateway",
        source_type="domestic_web",
        query=query,
        top_k=top_k,
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        provider_config=provider_config,
    )


def search_web_sources(
    *,
    query: str,
    top_k: int,
    trace_id: str = "",
    session_id: str = "",
    project_id: str = "",
    user_id: str = "",
    include_trace: bool = False,
    provider_config: dict[str, Any] | None = None,
) -> list[dict[str, Any]] | dict[str, Any]:
    result = search_web_sources_with_trace(
        query=query,
        top_k=top_k,
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        provider_config=provider_config,
    )
    if include_trace:
        return result
    return list(result.get("items") or [])


def search_web_sources_with_trace(
    *,
    query: str,
    top_k: int,
    trace_id: str = "",
    session_id: str = "",
    project_id: str = "",
    user_id: str = "",
    provider_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    clean_query = str(query or "").strip()
    if not clean_query:
        return provider_result(provider_trace=[trace_entry(provider="web", status="skipped", reason="empty_query")])

    provider = provider_name()
    mode = dev_mode()
    if provider == "elasticsearch":
        return provider_result(
            provider_trace=[trace_entry(provider="elasticsearch", status="skipped", reason="provider_not_enabled")]
        )

    if provider == "intranet":
        return _intranet_search_result(
            query=clean_query,
            top_k=top_k,
            trace_id=trace_id,
            session_id=session_id,
            project_id=project_id,
            user_id=user_id,
            provider_config=provider_config,
        )

    if provider == "domestic_gateway":
        if mode == "direct":
            return search_public_ddg(query=clean_query, top_k=top_k, provider_config=provider_config)
        return _domestic_gateway_result(
            query=clean_query,
            top_k=top_k,
            trace_id=trace_id,
            session_id=session_id,
            project_id=project_id,
            user_id=user_id,
            provider_config=provider_config,
        )

    intranet_result = _intranet_search_result(
        query=clean_query,
        top_k=top_k,
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        provider_config=provider_config,
    )
    if intranet_result.get("items"):
        return _merge_provider_results(intranet_result)

    if mode == "direct":
        return _merge_provider_results(
            intranet_result,
            search_public_ddg(query=clean_query, top_k=top_k, provider_config=provider_config),
        )

    domestic_result = _domestic_gateway_result(
        query=clean_query,
        top_k=top_k,
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        provider_config=provider_config,
    )
    if domestic_result.get("items"):
        return _merge_provider_results(intranet_result, domestic_result)

    return _merge_provider_results(
        intranet_result,
        domestic_result,
        search_public_ddg(query=clean_query, top_k=top_k, provider_config=provider_config),
    )


__all__ = ["search_web_sources", "search_web_sources_with_trace"]
