"""In-memory fallback storage for local knowledge records."""

from __future__ import annotations

import copy
import uuid
from datetime import UTC, datetime
from typing import Any

_MEMORY_KNOWLEDGE_RECORDS: list[dict[str, Any]] = []


def _utcnow_iso() -> str:
    return datetime.now(UTC).isoformat()


def append_memory_knowledge_record(
    *,
    source_id: str,
    project_id: str,
    user_id: str,
    session_id: str,
    title: str,
    content: str,
    metadata: dict[str, Any] | None,
) -> None:
    clean_content = str(content or "").strip()
    if not clean_content:
        return
    _MEMORY_KNOWLEDGE_RECORDS.insert(
        0,
        {
            "record_id": f"record-{uuid.uuid4().hex}",
            "source_id": source_id,
            "project_id": project_id,
            "user_id": user_id,
            "session_id": session_id,
            "title": title,
            "content": clean_content,
            "metadata": copy.deepcopy(metadata or {}),
            "created_at": _utcnow_iso(),
        },
    )


def search_memory_knowledge_records(
    *,
    project_id: str,
    user_id: str,
    query: str,
    top_k: int,
    source_ids: list[str] | None = None,
) -> list[dict[str, Any]]:
    clean_query = str(query or "").strip().lower()
    if not clean_query:
        return []
    source_filter = {str(item).strip() for item in (source_ids or []) if str(item).strip()}
    matches: list[dict[str, Any]] = []
    for row in _MEMORY_KNOWLEDGE_RECORDS:
        if row.get("project_id") != project_id or row.get("user_id") != user_id:
            continue
        if source_filter and str(row.get("source_id") or "") not in source_filter:
            continue
        target = f"{row.get('title') or ''}\n{row.get('content') or ''}".lower()
        if clean_query not in target:
            continue
        matches.append(
            {
                "record_id": row.get("record_id") or "",
                "title": row.get("title") or "",
                "content": row.get("content") or "",
                "source_id": row.get("source_id") or "",
                "score": 0.0,
                "source": "memory",
            }
        )
        if len(matches) >= max(1, min(top_k, 20)):
            break
    return matches


__all__ = ["append_memory_knowledge_record", "search_memory_knowledge_records"]
