"""Chat memory persistence adapters."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any, Callable

from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine
from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.infrastructure.redis_client import build_redis_client

logger = get_logger("flare_kernel.runtime.infrastructure.chat_memory")


def _utcnow_iso() -> str:
    return datetime.now(UTC).isoformat()


def persist_memory_record(
    *,
    trace_id: str,
    session_id: str,
    project_id: str | None,
    user_id: str | None,
    mode_key: str,
    user_message: str,
    assistant_message: str,
    provider: str,
    model: str,
    provider_status: str,
    build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine,
    redis_client_fn: Callable[[], Any] = build_redis_client,
) -> dict[str, Any]:
    memory_state: dict[str, Any] = {"stored": False, "channel": "none", "record_id": ""}
    record_id = str(uuid.uuid4())
    memory_state["record_id"] = record_id
    _persist_postgres_memory(
        memory_state,
        build_sqlalchemy_engine_fn,
        record_id=record_id,
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        mode_key=mode_key,
        user_message=user_message,
        assistant_message=assistant_message,
        provider=provider,
        model=model,
        provider_status=provider_status,
    )
    _persist_redis_cursor(
        memory_state,
        redis_client_fn,
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        mode_key=mode_key,
    )
    return memory_state


def _persist_postgres_memory(memory_state: dict[str, Any], build_engine_fn: Callable[[], Any], **record: Any) -> None:
    engine = build_engine_fn()
    if engine is None:
        return
    try:
        from sqlalchemy import text

        with engine.begin() as conn:
            conn.execute(text(_CHAT_MEMORY_TABLE_SQL))
            conn.execute(text(_CHAT_MEMORY_INSERT_SQL), {**record, "created_at": _utcnow_iso()})
        memory_state.update({"stored": True, "channel": "postgres"})
    except Exception as exc:
        logger.warning("memory.persist.postgres_failed trace_id=%s error=%s", record.get("trace_id"), str(exc))


def _persist_redis_cursor(memory_state: dict[str, Any], redis_client_fn: Callable[[], Any], **record: Any) -> None:
    redis_client = redis_client_fn()
    if redis_client is None:
        return
    try:
        redis_key = f"flare:session:{record['session_id']}:cursor"
        redis_client.hset(
            redis_key,
            mapping={
                "trace_id": record["trace_id"],
                "mode_key": record["mode_key"],
                "project_id": record.get("project_id") or "",
                "user_id": record.get("user_id") or "",
                "updated_at": _utcnow_iso(),
            },
        )
        redis_client.expire(redis_key, 60 * 60 * 24)
        memory_state["redis_cursor"] = redis_key
        if not memory_state["stored"]:
            memory_state.update({"stored": True, "channel": "redis"})
    except Exception as exc:
        logger.warning("memory.persist.redis_failed trace_id=%s error=%s", record.get("trace_id"), str(exc))


_CHAT_MEMORY_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS flare_chat_memory (
    id TEXT PRIMARY KEY,
    trace_id TEXT,
    session_id TEXT,
    project_id TEXT,
    user_id TEXT,
    mode_key TEXT,
    user_message TEXT,
    assistant_message TEXT,
    provider TEXT,
    model TEXT,
    provider_status TEXT,
    created_at TEXT
)
"""

_CHAT_MEMORY_INSERT_SQL = """
INSERT INTO flare_chat_memory (
    id, trace_id, session_id, project_id, user_id, mode_key,
    user_message, assistant_message, provider, model, provider_status, created_at
) VALUES (
    :record_id, :trace_id, :session_id, :project_id, :user_id, :mode_key,
    :user_message, :assistant_message, :provider, :model, :provider_status, :created_at
)
"""
