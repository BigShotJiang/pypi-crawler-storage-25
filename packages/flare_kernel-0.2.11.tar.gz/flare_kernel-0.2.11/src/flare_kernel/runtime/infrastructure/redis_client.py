"""Redis client boundary for runtime infrastructure."""

from __future__ import annotations

import os
from typing import Any

_DEFAULT_REDIS_URL = "redis://127.0.0.1:6379/0"


def _env(name: str, default: str | None = None) -> str | None:
    raw = os.getenv(name)
    if raw is None:
        return default
    value = raw.strip()
    return value if value else default


def build_redis_client() -> Any:
    try:
        import redis
    except Exception:
        return None

    redis_url = _env("FLARE_REDIS_URL", _DEFAULT_REDIS_URL) or _DEFAULT_REDIS_URL
    return redis.Redis.from_url(redis_url, decode_responses=True)
