"""Document understanding JSON codec for source persistence."""

from __future__ import annotations

import copy
import json
from typing import Any


def decode_document_understanding(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict):
        return copy.deepcopy(value)
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return None
    return parsed if isinstance(parsed, dict) else None


def encode_document_understanding(value: dict[str, Any]) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


__all__ = ["decode_document_understanding", "encode_document_understanding"]
