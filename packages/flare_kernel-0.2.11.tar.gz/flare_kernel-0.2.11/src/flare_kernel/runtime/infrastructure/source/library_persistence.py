"""Persistence helpers for project source library."""

from __future__ import annotations

import copy
import uuid
from datetime import UTC, datetime
from typing import Any, Callable

from flare_kernel.runtime.infrastructure.source.document_understanding_codec import decode_document_understanding, encode_document_understanding
from flare_kernel.runtime.infrastructure.source.schema import ensure_document_understanding_column

_MEMORY_SOURCE_STORE: dict[str, list[dict[str, Any]]] = {}


def _utcnow_iso() -> str:
    return datetime.now(UTC).isoformat()


def _build_source_record(
    *,
    project_id: str,
    user_id: str,
    session_id: str | None,
    filename: str,
    mime_type: str,
    size: int | None,
    storage_uri: str,
) -> dict[str, Any]:
    now = _utcnow_iso()
    source_id = f"src-{uuid.uuid4().hex}"
    scoped_session_id = str(session_id).strip() if session_id is not None else ""
    scope = "session" if scoped_session_id else "project"
    return {
        "id": source_id,
        "source_id": source_id,
        "project_id": project_id,
        "user_id": user_id,
        "session_id": scoped_session_id or None,
        "scope": scope,
        "source": "local_upload",
        "filename": filename,
        "mime_type": mime_type,
        "size": size,
        "storage_uri": storage_uri,
        "status": "uploaded",
        "error_code": None,
        "error_message": "",
        "document_understanding": None,
        "created_at": now,
        "updated_at": now,
        "persisted_to_project": scope == "project",
    }


def _memory_append(record: dict[str, Any]) -> dict[str, Any]:
    bucket = _MEMORY_SOURCE_STORE.setdefault(record["project_id"], [])
    bucket.insert(0, copy.deepcopy(record))
    return copy.deepcopy(record)


def _memory_list(project_id: str) -> list[dict[str, Any]]:
    return copy.deepcopy(_MEMORY_SOURCE_STORE.get(project_id, []))


def _memory_update_status(project_id: str, source_id: str, *, status: str, error_code: str | None, error_message: str) -> None:
    for row in _MEMORY_SOURCE_STORE.get(project_id, []):
        if row.get("source_id") != source_id:
            continue
        row["status"] = status
        row["error_code"] = error_code
        row["error_message"] = error_message
        row["updated_at"] = _utcnow_iso()
        return


def _memory_update_document_understanding(project_id: str, source_id: str, document_understanding: dict[str, Any]) -> None:
    for row in _MEMORY_SOURCE_STORE.get(project_id, []):
        if row.get("source_id") != source_id:
            continue
        row["document_understanding"] = copy.deepcopy(document_understanding)
        row["updated_at"] = _utcnow_iso()
        return


def _memory_delete(project_id: str, source_id: str) -> bool:
    bucket = _MEMORY_SOURCE_STORE.get(project_id, [])
    before = len(bucket)
    _MEMORY_SOURCE_STORE[project_id] = [row for row in bucket if row.get("source_id") != source_id]
    return len(_MEMORY_SOURCE_STORE[project_id]) < before


def _strip_storage_uri(record: dict[str, Any]) -> dict[str, Any]:
    safe = dict(record)
    safe.pop("storage_uri", None)
    decoded = decode_document_understanding(safe.get("document_understanding"))
    if decoded is not None:
        safe["document_understanding"] = decoded
    return safe


def create_project_source_record(
    *,
    project_id: str,
    user_id: str,
    session_id: str | None,
    filename: str,
    mime_type: str,
    size: int | None,
    storage_uri: str,
    build_sqlalchemy_engine_fn: Callable[[], Any],
) -> dict[str, Any]:
    record = _build_source_record(
        project_id=project_id,
        user_id=user_id,
        session_id=session_id,
        filename=filename,
        mime_type=mime_type,
        size=size,
        storage_uri=storage_uri,
    )
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        return _strip_storage_uri(_memory_append(record))
    try:
        from sqlalchemy import text

        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS flare_project_sources (
                        id TEXT PRIMARY KEY,
                        source_id TEXT UNIQUE,
                        project_id TEXT,
                        user_id TEXT,
                        session_id TEXT,
                        scope TEXT,
                        source TEXT,
                        filename TEXT,
                        mime_type TEXT,
                        size INTEGER,
                        storage_uri TEXT,
                        status TEXT,
                        error_code TEXT,
                        error_message TEXT,
                        document_understanding TEXT,
                        created_at TEXT,
                        updated_at TEXT
                    )
                    """
                )
            )
            conn.execute(
                text(
                    """
                    INSERT INTO flare_project_sources (
                        id, source_id, project_id, user_id, session_id, scope, source, filename,
                        mime_type, size, storage_uri, status, error_code, error_message, created_at, updated_at
                    ) VALUES (
                        :id, :source_id, :project_id, :user_id, :session_id, :scope, :source, :filename,
                        :mime_type, :size, :storage_uri, :status, :error_code, :error_message, :created_at, :updated_at
                    )
                    """
                ),
                record,
            )
    except Exception:
        return _strip_storage_uri(_memory_append(record))
    return _strip_storage_uri(record)


def list_project_sources(*, project_id: str, build_sqlalchemy_engine_fn: Callable[[], Any]) -> list[dict[str, Any]]:
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        return _memory_list(project_id)
    try:
        from sqlalchemy import text

        with engine.begin() as conn:
            ensure_document_understanding_column(conn, text)
            rows = conn.execute(
                text(
                    """
                    SELECT id, source_id, project_id, user_id, session_id, scope, source, filename,
                           mime_type, size, status, error_code, error_message, document_understanding,
                           created_at, updated_at
                    FROM flare_project_sources
                    WHERE project_id = :project_id
                    ORDER BY created_at DESC
                    """
                ),
                {"project_id": project_id},
            ).mappings().all()
        normalized_rows: list[dict[str, Any]] = []
        for row in rows:
            normalized = dict(row)
            normalized["persisted_to_project"] = str(normalized.get("scope") or "project").strip().lower() == "project"
            normalized_rows.append(_strip_storage_uri(normalized))
        return normalized_rows
    except Exception:
        return _memory_list(project_id)


def get_source_record(
    *,
    project_id: str,
    source_id: str,
    build_sqlalchemy_engine_fn: Callable[[], Any],
) -> dict[str, Any] | None:
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        for item in _memory_list(project_id):
            if item.get("source_id") == source_id:
                return item
        return None
    try:
        from sqlalchemy import text

        with engine.begin() as conn:
            ensure_document_understanding_column(conn, text)
            row = conn.execute(
                text(
                    """
                    SELECT id, source_id, project_id, user_id, session_id, scope, source, filename,
                           mime_type, size, storage_uri, status, error_code, error_message,
                           document_understanding, created_at, updated_at
                    FROM flare_project_sources
                    WHERE project_id = :project_id AND source_id = :source_id
                    LIMIT 1
                    """
                ),
                {"project_id": project_id, "source_id": source_id},
            ).mappings().first()
        return dict(row) if row else None
    except Exception:
        for item in _memory_list(project_id):
            if item.get("source_id") == source_id:
                return item
        return None


def update_source_document_understanding(
    *,
    project_id: str,
    source_id: str,
    document_understanding: dict[str, Any],
    build_sqlalchemy_engine_fn: Callable[[], Any],
) -> None:
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        _memory_update_document_understanding(project_id, source_id, document_understanding)
        return
    try:
        from sqlalchemy import text

        with engine.begin() as conn:
            ensure_document_understanding_column(conn, text)
            conn.execute(
                text(
                    """
                    UPDATE flare_project_sources
                    SET document_understanding = :document_understanding,
                        updated_at = :updated_at
                    WHERE project_id = :project_id
                      AND source_id = :source_id
                    """
                ),
                {
                    "document_understanding": encode_document_understanding(document_understanding),
                    "updated_at": _utcnow_iso(),
                    "project_id": project_id,
                    "source_id": source_id,
                },
            )
    except Exception:
        _memory_update_document_understanding(project_id, source_id, document_understanding)


def update_source_status(
    *,
    project_id: str,
    source_id: str,
    status: str,
    error_code: str | None = None,
    error_message: str = "",
    build_sqlalchemy_engine_fn: Callable[[], Any],
) -> None:
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        _memory_update_status(project_id, source_id, status=status, error_code=error_code, error_message=error_message)
        return
    try:
        from sqlalchemy import text

        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    UPDATE flare_project_sources
                    SET status = :status,
                        error_code = :error_code,
                        error_message = :error_message,
                        updated_at = :updated_at
                    WHERE project_id = :project_id
                      AND source_id = :source_id
                    """
                ),
                {
                    "status": status,
                    "error_code": error_code,
                    "error_message": error_message,
                    "updated_at": _utcnow_iso(),
                    "project_id": project_id,
                    "source_id": source_id,
                },
            )
    except Exception:
        _memory_update_status(project_id, source_id, status=status, error_code=error_code, error_message=error_message)


def delete_project_source(
    *,
    project_id: str,
    source_id: str,
    build_sqlalchemy_engine_fn: Callable[[], Any],
) -> bool:
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        return _memory_delete(project_id, source_id)
    try:
        from sqlalchemy import text

        with engine.begin() as conn:
            result = conn.execute(
                text(
                    """
                    DELETE FROM flare_project_sources
                    WHERE project_id = :project_id
                      AND source_id = :source_id
                    """
                ),
                {"project_id": project_id, "source_id": source_id},
            )
        return bool(result.rowcount)
    except Exception:
        return _memory_delete(project_id, source_id)
