"""Source persistence schema compatibility helpers."""

from __future__ import annotations

from typing import Any, Callable


def ensure_document_understanding_column(conn: Any, text_fn: Callable[[str], Any]) -> None:
    dialect_name = str(getattr(getattr(conn, "dialect", None), "name", "") or "").lower()
    if dialect_name == "postgresql":
        conn.execute(text_fn("ALTER TABLE flare_project_sources ADD COLUMN IF NOT EXISTS document_understanding TEXT"))
        return
    try:
        conn.execute(text_fn("ALTER TABLE flare_project_sources ADD COLUMN document_understanding TEXT"))
    except Exception:
        pass


__all__ = ["ensure_document_understanding_column"]
