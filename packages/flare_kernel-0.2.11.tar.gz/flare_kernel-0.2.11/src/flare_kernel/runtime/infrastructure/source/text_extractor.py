"""Source file text extraction helpers.

Infrastructure-only module:
- reads local uploaded files
- normalizes extracted text for ingestion runtime
"""

from __future__ import annotations

import html
import re
import zipfile
from io import BytesIO
from pathlib import Path
from xml.etree import ElementTree


class SourceTextExtractionError(Exception):
    """Raised when source text extraction fails."""

    def __init__(self, *, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def _normalize_text(value: str) -> str:
    normalized = str(value or "").strip()
    normalized = normalized.replace("\x00", "")
    normalized = re.sub(r"\r\n?", "\n", normalized)
    normalized = re.sub(r"[ \t]+", " ", normalized)
    normalized = re.sub(r"\n{3,}", "\n\n", normalized)
    return normalized.strip()


def _extract_docx_text(path: Path) -> str:
    try:
        with zipfile.ZipFile(path) as archive:
            xml_payload = archive.read("word/document.xml").decode("utf-8", errors="ignore")
    except KeyError as exc:  # pragma: no cover - defensive branch
        raise SourceTextExtractionError(code="docx_document_xml_missing", message="docx document.xml missing") from exc
    except Exception as exc:
        raise SourceTextExtractionError(code="docx_read_failed", message="failed to read docx file") from exc

    with_line_breaks = re.sub(r"</w:p>", "\n", xml_payload)
    text = re.sub(r"<[^>]+>", "", with_line_breaks)
    return _normalize_text(html.unescape(text))


def _extract_pdf_text(path: Path) -> str:
    try:
        from pypdf import PdfReader
    except Exception as exc:
        raise SourceTextExtractionError(code="pdf_dependency_missing", message="pypdf not installed") from exc

    try:
        reader = PdfReader(str(path))
    except Exception as exc:
        raise SourceTextExtractionError(code="pdf_open_failed", message="failed to open pdf file") from exc

    pages: list[str] = []
    for page in reader.pages:
        try:
            pages.append(str(page.extract_text() or ""))
        except Exception:
            pages.append("")
    return _normalize_text("\n".join(pages))


def _extract_xlsx_text(path: Path) -> str:
    try:
        with zipfile.ZipFile(path) as archive:
            shared_strings: list[str] = []
            if "xl/sharedStrings.xml" in archive.namelist():
                shared_xml = archive.read("xl/sharedStrings.xml")
                shared_root = ElementTree.fromstring(shared_xml)
                for node in shared_root.iter():
                    if node.tag.endswith("}t") and node.text:
                        shared_strings.append(node.text)
            rows: list[str] = []
            sheet_paths = sorted(
                [name for name in archive.namelist() if name.startswith("xl/worksheets/sheet") and name.endswith(".xml")]
            )
            for sheet_path in sheet_paths:
                sheet_xml = archive.read(sheet_path)
                root = ElementTree.fromstring(sheet_xml)
                for row_node in root.iter():
                    if not row_node.tag.endswith("}row"):
                        continue
                    row_cells: list[str] = []
                    for cell_node in list(row_node):
                        if not cell_node.tag.endswith("}c"):
                            continue
                        cell_type = str(cell_node.attrib.get("t") or "").strip().lower()
                        value_node = None
                        for child in list(cell_node):
                            if child.tag.endswith("}v"):
                                value_node = child
                                break
                        cell_value = str(value_node.text or "").strip() if value_node is not None else ""
                        if not cell_value:
                            continue
                        if cell_type == "s":
                            try:
                                row_cells.append(shared_strings[int(cell_value)])
                            except Exception:
                                row_cells.append(cell_value)
                        else:
                            row_cells.append(cell_value)
                    if row_cells:
                        rows.append(" | ".join(row_cells))
    except Exception as exc:
        raise SourceTextExtractionError(code="xlsx_read_failed", message="failed to read xlsx file") from exc
    return _normalize_text("\n".join(rows))


def _extract_image_ocr_text(path: Path) -> str:
    try:
        import pytesseract
    except Exception as exc:
        raise SourceTextExtractionError(code="ocr_dependency_missing", message="ocr dependency missing") from exc
    try:
        from PIL import Image
    except Exception as exc:
        raise SourceTextExtractionError(code="ocr_dependency_missing", message="ocr dependency missing") from exc

    try:
        with path.open("rb") as handle:
            image = Image.open(BytesIO(handle.read()))
            image.load()
        text = pytesseract.image_to_string(image, lang="chi_sim+eng")
    except Exception as exc:
        raise SourceTextExtractionError(code="ocr_extract_failed", message="failed to extract image text") from exc
    return _normalize_text(text)


def extract_source_text(path: Path, *, mime_type: str = "", filename: str = "") -> str:
    """Extract normalized text from an uploaded source file."""
    if not path.exists():
        raise SourceTextExtractionError(code="source_file_missing", message="source file not found")

    suffix = str(path.suffix or "").strip().lower()
    normalized_mime = str(mime_type or "").strip().lower()
    normalized_filename = str(filename or path.name or "").strip().lower()

    if suffix == ".docx" or normalized_mime.endswith("officedocument.wordprocessingml.document") or normalized_filename.endswith(".docx"):
        text = _extract_docx_text(path)
    elif suffix == ".xlsx" or normalized_mime.endswith("officedocument.spreadsheetml.sheet") or normalized_filename.endswith(".xlsx"):
        text = _extract_xlsx_text(path)
    elif suffix == ".pdf" or normalized_mime == "application/pdf" or normalized_filename.endswith(".pdf"):
        text = _extract_pdf_text(path)
    elif suffix in {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"} or normalized_mime.startswith("image/"):
        text = _extract_image_ocr_text(path)
    else:
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception as exc:
            raise SourceTextExtractionError(code="source_read_failed", message="failed to read source file") from exc
        text = _normalize_text(text)

    if not text:
        raise SourceTextExtractionError(code="source_text_empty", message="source text extraction produced empty content")
    return text
