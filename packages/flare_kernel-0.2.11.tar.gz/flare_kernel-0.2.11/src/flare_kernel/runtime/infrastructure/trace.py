"""trace_id helpers."""

from __future__ import annotations

from uuid import uuid4


def resolve_trace_id(trace_id: str | None) -> str:
    if trace_id and trace_id.strip():
        return trace_id.strip()
    return uuid4().hex
