"""Project Memory storage codecs and validation helpers."""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime
from typing import Any

from flare_kernel.contracts.project_memory_contract import ProjectMemoryRecord


def utcnow_iso() -> str:
    """Return the current UTC timestamp for durable rows.

    Returns:
        ISO formatted UTC datetime string.
    """

    return datetime.now(UTC).isoformat()


def normalize_project_memory_text(value: Any) -> str:
    """Normalize arbitrary input into compact text.

    Args:
        value: Raw value from caller or database row.

    Returns:
        Whitespace-normalized string.
    """

    return " ".join(str(value or "").split()).strip()


def normalize_project_memory_status(value: Any) -> str:
    """Normalize memory lifecycle status.

    Args:
        value: Raw status value.

    Returns:
        Non-empty status string, defaulting to active.
    """

    return normalize_project_memory_text(value) or "active"


def normalize_project_memory_confidence(value: Any) -> float | None:
    """Normalize confidence to a float when possible.

    Args:
        value: Raw confidence value.

    Returns:
        Float confidence, or None when unavailable/invalid.
    """

    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def json_dumps_evidence(value: Any) -> str:
    """Serialize evidence-like values for SQL storage.

    Args:
        value: Evidence value supplied by caller.

    Returns:
        JSON string persisted in evidence_json.
    """

    return json.dumps(value if value is not None else [], ensure_ascii=False, sort_keys=True)


def json_loads_evidence(value: Any) -> Any:
    """Deserialize evidence_json from SQL storage.

    Args:
        value: Raw JSON string from database.

    Returns:
        Parsed JSON value, or an empty list on missing/invalid input.
    """

    if not value:
        return []
    try:
        return json.loads(str(value))
    except json.JSONDecodeError:
        return []


def build_project_memory_id() -> str:
    """Create a local Project Memory identifier.

    Returns:
        Stable id string with pmem_ prefix.
    """

    return f"pmem_{uuid.uuid4().hex[:16]}"


def build_project_memory_params(
    *,
    memory_id: str | None,
    project_id: str,
    user_id: str,
    source_session_id: str | None,
    source_message_id: str | None,
    source_id: str | None,
    memory_type: str,
    content: str,
    evidence: list[dict[str, Any]] | None,
    confidence: float | None,
    status: str,
) -> dict[str, Any]:
    """Build normalized SQL parameters for an upsert.

    Args:
        memory_id: Optional existing memory id.
        project_id: Owning project id.
        user_id: Owning user id.
        source_session_id: Producing session id, when available.
        source_message_id: Producing message id, when available.
        source_id: Producing source id, when available.
        memory_type: Memory category.
        content: Durable memory text.
        evidence: Optional supporting snippets.
        confidence: Optional confidence score.
        status: Lifecycle status.

    Returns:
        SQL parameter dict for insert/update statements.
    """

    now = utcnow_iso()
    return {
        "memory_id": normalize_project_memory_text(memory_id) or build_project_memory_id(),
        "project_id": normalize_project_memory_text(project_id),
        "user_id": normalize_project_memory_text(user_id),
        "source_session_id": normalize_project_memory_text(source_session_id),
        "source_message_id": normalize_project_memory_text(source_message_id),
        "source_id": normalize_project_memory_text(source_id),
        "memory_type": normalize_project_memory_text(memory_type) or "fact",
        "content": str(content or "").strip(),
        "evidence_json": json_dumps_evidence(evidence),
        "confidence": confidence,
        "status": normalize_project_memory_status(status),
        "created_at": now,
        "updated_at": now,
    }


def row_to_project_memory_record(row: Any) -> dict[str, Any]:
    """Convert a SQL row into the public Project Memory record contract.

    Args:
        row: SQLAlchemy row mapping containing evidence_json.

    Returns:
        ProjectMemoryRecord as a dict.
    """

    record = dict(row)
    record["evidence"] = json_loads_evidence(record.pop("evidence_json", ""))
    record["confidence"] = normalize_project_memory_confidence(record.get("confidence"))
    return ProjectMemoryRecord.model_validate(record).model_dump()


def require_project_memory_scope(project_id: str, user_id: str) -> tuple[str, str]:
    """Validate and normalize required project/user scope.

    Args:
        project_id: Project id supplied by caller.
        user_id: User id supplied by caller.

    Returns:
        Tuple of normalized project_id and user_id.

    Raises:
        ValueError: If either scope value is empty.
    """

    resolved_project_id = normalize_project_memory_text(project_id)
    resolved_user_id = normalize_project_memory_text(user_id)
    if not resolved_project_id:
        raise ValueError("project_id is required")
    if not resolved_user_id:
        raise ValueError("user_id is required")
    return resolved_project_id, resolved_user_id


def require_project_memory_content(content: str) -> str:
    """Validate and normalize required memory content.

    Args:
        content: Memory text supplied by caller.

    Returns:
        Non-empty memory content.

    Raises:
        ValueError: If content is empty.
    """

    resolved = str(content or "").strip()
    if not resolved:
        raise ValueError("content is required")
    return resolved


def score_project_memory_record(record: dict[str, Any], query_terms: list[str]) -> tuple[int, dict[str, Any]]:
    """Score one memory record using lexical query-term overlap.

    Args:
        record: ProjectMemoryRecord-compatible dict.
        query_terms: Lowercase query tokens.

    Returns:
        Tuple of integer score and original record.
    """

    content = str(record.get("content") or "").lower()
    memory_type = str(record.get("memory_type") or "").lower()
    haystack = f"{memory_type} {content}"
    return sum(1 for term in query_terms if term in haystack), record
