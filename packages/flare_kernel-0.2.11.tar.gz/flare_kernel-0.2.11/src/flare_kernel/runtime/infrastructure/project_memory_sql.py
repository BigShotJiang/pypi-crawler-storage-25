"""SQL statements for Project Memory persistence."""

PROJECT_MEMORY_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS flare_project_memory (
    memory_id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    source_session_id TEXT,
    source_message_id TEXT,
    source_id TEXT,
    memory_type TEXT NOT NULL,
    content TEXT NOT NULL,
    evidence_json TEXT,
    confidence REAL,
    status TEXT NOT NULL,
    created_at TEXT,
    updated_at TEXT
)
"""

PROJECT_MEMORY_SCOPE_INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_project_memory_scope
ON flare_project_memory (project_id, user_id, status)
"""

PROJECT_MEMORY_TYPE_INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_project_memory_type
ON flare_project_memory (project_id, memory_type)
"""

PROJECT_MEMORY_SELECT_BASE_SQL = """
SELECT memory_id, project_id, user_id, source_session_id, source_message_id, source_id,
       memory_type, content, evidence_json, confidence, status, created_at, updated_at
FROM flare_project_memory
"""

PROJECT_MEMORY_LIST_WHERE_SQL = """
WHERE project_id = :project_id AND user_id = :user_id AND status = :status
ORDER BY updated_at DESC
"""

PROJECT_MEMORY_INSERT_SQL = """
INSERT INTO flare_project_memory (
    memory_id, project_id, user_id, source_session_id, source_message_id, source_id,
    memory_type, content, evidence_json, confidence, status, created_at, updated_at
) VALUES (
    :memory_id, :project_id, :user_id, :source_session_id, :source_message_id, :source_id,
    :memory_type, :content, :evidence_json, :confidence, :status, :created_at, :updated_at
)
"""

PROJECT_MEMORY_UPDATE_SQL = """
UPDATE flare_project_memory
SET project_id = :project_id,
    user_id = :user_id,
    source_session_id = :source_session_id,
    source_message_id = :source_message_id,
    source_id = :source_id,
    memory_type = :memory_type,
    content = :content,
    evidence_json = :evidence_json,
    confidence = :confidence,
    status = :status,
    updated_at = :updated_at
WHERE memory_id = :memory_id
"""
