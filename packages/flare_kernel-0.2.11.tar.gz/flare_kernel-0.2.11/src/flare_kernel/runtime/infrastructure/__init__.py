"""Runtime infrastructure submodules."""

from __future__ import annotations

import importlib
import sys

from flare_kernel.runtime.infrastructure.session.repository import SessionRepository
from flare_kernel.runtime.infrastructure.session.repository_memory import InMemorySessionRepository
from flare_kernel.runtime.infrastructure.session.repository_sql import SqlAlchemySessionRepository
from flare_kernel.runtime.infrastructure.run import InMemoryRunRepository, RunRepository, SqlAlchemyRunRepository

_LEGACY_MODULE_TARGETS = {
    "session_repository": "flare_kernel.runtime.infrastructure.session.repository",
    "session_repository_memory": "flare_kernel.runtime.infrastructure.session.repository_memory",
    "session_repository_sql": "flare_kernel.runtime.infrastructure.session.repository_sql",
    "source_library_persistence": "flare_kernel.runtime.infrastructure.source.library_persistence",
    "source_text_extractor": "flare_kernel.runtime.infrastructure.source.text_extractor",
    "sourcing_persistence": "flare_kernel.runtime.infrastructure.sourcing.persistence",
    "sourcing_provider": "flare_kernel.runtime.infrastructure.sourcing.provider",
}

for _legacy_name, _target in _LEGACY_MODULE_TARGETS.items():
    sys.modules.setdefault(
        f"flare_kernel.runtime.infrastructure.{_legacy_name}",
        importlib.import_module(_target),
    )

__all__ = [
    "SessionRepository",
    "InMemorySessionRepository",
    "SqlAlchemySessionRepository",
    "RunRepository",
    "InMemoryRunRepository",
    "SqlAlchemyRunRepository",
]
