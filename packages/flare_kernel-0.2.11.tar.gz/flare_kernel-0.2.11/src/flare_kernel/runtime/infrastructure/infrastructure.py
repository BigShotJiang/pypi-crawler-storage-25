"""Compatibility facade for runtime infrastructure adapters."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.infrastructure.chat_memory import persist_memory_record as _persist_memory_record
from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine as _build_database_engine
from flare_kernel.runtime.infrastructure.dependency_status import (
    collect_capability_status,
    collect_dependency_status as _collect_dependency_status,
    postgres_ready as _postgres_ready_impl,
    qdrant_ready as _qdrant_ready_impl,
    redis_ready as _redis_ready_impl,
)
from flare_kernel.runtime.infrastructure.knowledge_ingest import ingest_knowledge_record as _ingest_knowledge_record
from flare_kernel.runtime.infrastructure.knowledge_search import search_knowledge_records as _search_knowledge_records
from flare_kernel.runtime.infrastructure.knowledge_terms import (
    keyword_overlap_ratio as _keyword_overlap_ratio,
    split_query_terms as _split_query_terms,
    split_text_chunks as _split_text_chunks,
)
from flare_kernel.runtime.infrastructure.redis_client import build_redis_client
from flare_kernel.runtime.infrastructure.vector_store import (
    _KNOWLEDGE_COLLECTION,
    ensure_qdrant_collection as _ensure_qdrant_collection,
    qdrant_client,
    stable_embedding as _stable_embedding,
)


def _build_sqlalchemy_engine() -> Any:
    return _build_database_engine()


def build_sqlalchemy_engine() -> Any:
    """Public engine builder wrapper for legacy infrastructure imports."""
    return _build_sqlalchemy_engine()


def _redis_client() -> Any:
    return build_redis_client()


def _qdrant_client() -> Any:
    return qdrant_client()


def _postgres_ready() -> bool:
    return _postgres_ready_impl(build_sqlalchemy_engine_fn=_build_sqlalchemy_engine)


def _redis_ready() -> bool:
    return _redis_ready_impl(redis_client_fn=_redis_client)


def _qdrant_ready() -> bool:
    return _qdrant_ready_impl(qdrant_client_fn=_qdrant_client)


def collect_dependency_status() -> dict[str, bool]:
    return _collect_dependency_status(
        build_sqlalchemy_engine_fn=_build_sqlalchemy_engine,
        redis_client_fn=_redis_client,
        qdrant_client_fn=_qdrant_client,
    )


def persist_memory_record(**kwargs: Any) -> dict[str, Any]:
    return _persist_memory_record(
        **kwargs,
        build_sqlalchemy_engine_fn=_build_sqlalchemy_engine,
        redis_client_fn=_redis_client,
    )


def ingest_knowledge_record(**kwargs: Any) -> dict[str, Any]:
    return _ingest_knowledge_record(
        **kwargs,
        build_sqlalchemy_engine_fn=_build_sqlalchemy_engine,
        qdrant_client_fn=_qdrant_client,
        ensure_collection_fn=_ensure_qdrant_collection,
    )


def search_knowledge_records(**kwargs: Any) -> list[dict[str, Any]]:
    return _search_knowledge_records(
        **kwargs,
        build_sqlalchemy_engine_fn=_build_sqlalchemy_engine,
        qdrant_client_fn=_qdrant_client,
        ensure_collection_fn=_ensure_qdrant_collection,
    )


__all__ = [
    "_KNOWLEDGE_COLLECTION",
    "_build_sqlalchemy_engine",
    "_ensure_qdrant_collection",
    "_keyword_overlap_ratio",
    "_postgres_ready",
    "_qdrant_client",
    "_qdrant_ready",
    "_redis_client",
    "_redis_ready",
    "_split_query_terms",
    "_split_text_chunks",
    "_stable_embedding",
    "build_sqlalchemy_engine",
    "collect_capability_status",
    "collect_dependency_status",
    "ingest_knowledge_record",
    "persist_memory_record",
    "search_knowledge_records",
]
