"""Knowledge retrieval text matching helpers."""

from __future__ import annotations

import re
from typing import Any


def split_text_chunks(text: str, chunk_size: int = 500) -> list[str]:
    normalized = " ".join((text or "").split())
    if not normalized:
        return []
    return [normalized[index : index + chunk_size] for index in range(0, len(normalized), chunk_size)]


def keyword_overlap_ratio(query: str, text: str) -> float:
    query_tokens = {token for token in query.lower().split() if token}
    text_tokens = {token for token in text.lower().split() if token}
    if not query_tokens or not text_tokens:
        return 0.0
    overlap = len(query_tokens.intersection(text_tokens))
    return overlap / max(1, len(query_tokens))


def split_query_terms(query: str) -> list[str]:
    clean_query = str(query or "").strip()
    if not clean_query:
        return []
    terms = [token.strip() for token in re.split(r"[\s,，。；;、]+", clean_query) if token.strip()]
    if len(terms) == 1 and len(terms[0]) >= 4:
        single = terms[0]
        terms = [single, single[:4], single[-4:]]
    ordered: list[str] = []
    for term in terms:
        if term not in ordered:
            ordered.append(term)
    return ordered[:6]


def normalize_entity_terms(
    *,
    entities: list[dict[str, Any] | str] | None,
    query: str,
    query_lane: str,
) -> list[str]:
    normalized_entities: list[str] = []
    for item in entities or []:
        normalized_entities.extend(_extract_entity_terms(item))
    deduped = _dedupe_terms(normalized_entities)
    if not deduped and str(query_lane or "").strip().lower().startswith("entity"):
        deduped.append(query.lower())
    return deduped


def build_entity_match(*, title: str, content: str, entity_terms: list[str]) -> tuple[list[str], float]:
    match_target = f"{title}\n{content}".lower()
    matched = [term for term in entity_terms if len(term) >= 2 and term in match_target]
    score = float(len(matched)) / float(len(entity_terms)) if entity_terms else 0.0
    return matched, score


def _extract_entity_terms(item: dict[str, Any] | str) -> list[str]:
    if isinstance(item, str):
        value = item.strip().lower()
        return [value] if value else []
    if not isinstance(item, dict):
        return []
    values = [item.get("text"), item.get("normalized"), item.get("entity_normalized")]
    aliases = item.get("aliases")
    if isinstance(aliases, list):
        values.extend(aliases)
    return [str(value or "").strip().lower() for value in values if str(value or "").strip()]


def _dedupe_terms(values: list[str]) -> list[str]:
    deduped: list[str] = []
    seen: set[str] = set()
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        deduped.append(value)
    return deduped
