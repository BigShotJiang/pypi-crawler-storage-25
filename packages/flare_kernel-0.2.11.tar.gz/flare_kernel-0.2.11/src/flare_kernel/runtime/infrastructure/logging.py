"""Kernel logging setup."""

from __future__ import annotations

import logging

_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s %(message)s"
_configured = False


def _ensure_basic_logging() -> None:
    global _configured
    if _configured:
        return
    logging.basicConfig(level=logging.INFO, format=_LOG_FORMAT)
    _configured = True


def get_logger(name: str) -> logging.Logger:
    _ensure_basic_logging()
    return logging.getLogger(name)
