"""SQL-backed session persistence repository.

DOC HELPER — OBJ-09 persistence boundary.
SQL storage persists context authority JSON as message metadata only; authority
semantics remain owned by canonical kernel payloads.
"""

from __future__ import annotations

import json
from typing import Any, Callable

from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine

from .columns import list_session_message_columns
from .repository import SessionRepository


def _json_dumps(value: Any) -> str:
    """Serialize repository values for SQL storage."""

    return json.dumps(value if value is not None else None, ensure_ascii=False, sort_keys=True)


def _json_loads(value: Any, default: Any) -> Any:
    """Deserialize SQL JSON values with a safe default."""

    if value in (None, ""):
        return default
    try:
        return json.loads(str(value))
    except json.JSONDecodeError:
        return default


def _session_params(record: dict[str, Any]) -> dict[str, Any]:
    """Convert a session record into SQL parameters."""

    return {
        "session_id": str(record.get("session_id") or ""),
        "project_id": record.get("project_id"),
        "title": str(record.get("title") or ""),
        "preview": str(record.get("preview") or ""),
        "title_source": str(record.get("title_source") or "default"),
        "status": str(record.get("status") or "active"),
        "user_id": record.get("user_id"),
        "function_type": record.get("function_type"),
        "context_json": _json_dumps(record.get("context") or {}),
        "created_at": str(record.get("created_at") or ""),
        "updated_at": str(record.get("updated_at") or ""),
    }


def _message_params(record: dict[str, Any]) -> dict[str, Any]:
    """Convert a session message record into SQL parameters."""

    return {
        "message_id": str(record.get("message_id") or ""),
        "session_id": str(record.get("session_id") or ""),
        "run_id": str(record.get("run_id") or ""),
        "role": str(record.get("role") or ""),
        "content": str(record.get("content") or ""),
        "attachments_json": _json_dumps(record.get("attachments") or []),
        "context_refs_json": _json_dumps(record.get("context_refs") or []),
        "knowledge_refs_json": _json_dumps(record.get("knowledge_refs") or []),
        "agent_status_json": _json_dumps(record.get("agent_status")),
        "thinking_trace": str(record.get("thinking_trace") or ""),
        "execution_trace_json": _json_dumps(record.get("execution_trace")),
        "knowledge_search_json": _json_dumps(record.get("knowledge_search")),
        "sourcing_candidates_json": _json_dumps(record.get("sourcing_candidates")),
        "knowledge_citation_json": _json_dumps(record.get("knowledge_citation")),
        "canvas_state_json": _json_dumps(record.get("canvas_state")),
        "analysis_payload_json": _json_dumps(record.get("analysis_payload")),
        "context_usage_json": _json_dumps(record.get("context_usage")),
        "provider_trace_json": _json_dumps(record.get("provider_trace")),
        "context_authority_json": _json_dumps(record.get("context_authority")),
        "plan_payload_json": _json_dumps(record.get("plan_payload")),
        "created_at": str(record.get("created_at") or ""),
    }


def _row_to_session(row: Any) -> dict[str, Any]:
    """Convert a SQL row into a session record dict."""

    record = dict(row)
    record["context"] = _json_loads(record.pop("context_json", ""), {})
    return record


def _row_to_message(row: Any) -> dict[str, Any]:
    """Convert a SQL row into a session message record dict."""

    record = dict(row)
    record["run_id"] = str(record.get("run_id") or "")
    record["thinking_trace"] = str(record.get("thinking_trace") or "")
    record["attachments"] = _json_loads(record.pop("attachments_json", ""), [])
    record["context_refs"] = _json_loads(record.pop("context_refs_json", ""), [])
    record["knowledge_refs"] = _json_loads(record.pop("knowledge_refs_json", ""), [])
    record["agent_status"] = _json_loads(record.pop("agent_status_json", ""), None)
    record["execution_trace"] = _json_loads(record.pop("execution_trace_json", ""), None)
    record["knowledge_search"] = _json_loads(record.pop("knowledge_search_json", ""), None)
    record["sourcing_candidates"] = _json_loads(record.pop("sourcing_candidates_json", ""), None)
    record["knowledge_citation"] = _json_loads(record.pop("knowledge_citation_json", ""), None)
    record["canvas_state"] = _json_loads(record.pop("canvas_state_json", ""), None)
    record["analysis_payload"] = _json_loads(record.pop("analysis_payload_json", ""), None)
    record["context_usage"] = _json_loads(record.pop("context_usage_json", ""), None)
    record["provider_trace"] = _json_loads(record.pop("provider_trace_json", ""), None)
    record["context_authority"] = _json_loads(record.pop("context_authority_json", ""), None)
    record["plan_payload"] = _json_loads(record.pop("plan_payload_json", ""), None)
    return record


class SqlAlchemySessionRepository(SessionRepository):
    """SQLAlchemy implementation of SessionRepository."""

    def __init__(self, build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine) -> None:
        self._build_engine = build_sqlalchemy_engine_fn

    def _engine(self) -> Any:
        """Resolve the SQLAlchemy engine or fail explicitly."""

        engine = self._build_engine()
        if engine is None:
            raise RuntimeError("SQLAlchemy engine is unavailable for session storage")
        return engine

    def _ensure_tables(self, conn: Any, text_fn: Any) -> None:
        """Ensure session and message tables exist."""

        conn.execute(text_fn(_SESSION_TABLE_SQL))
        conn.execute(text_fn(_SESSION_MESSAGE_TABLE_SQL))
        self._ensure_message_columns(conn, text_fn)
        conn.execute(text_fn(_SESSION_PROJECT_INDEX_SQL))
        conn.execute(text_fn(_SESSION_MESSAGE_INDEX_SQL))

    def _ensure_message_columns(self, conn: Any, text_fn: Any) -> None:
        """Ensure additive message metadata columns exist."""

        existing = list_session_message_columns(conn, text_fn)
        for column_name in _SESSION_MESSAGE_ADDITIVE_COLUMNS:
            if column_name not in existing:
                conn.execute(text_fn(f"ALTER TABLE flare_session_messages ADD COLUMN {column_name} TEXT"))

    def create_session_record(self, record: dict[str, Any]) -> dict[str, Any]:
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            conn.execute(text(_SESSION_UPSERT_SQL), _session_params(record))
        return self.load_session_record(str(record.get("session_id") or "")) or dict(record)

    def load_session_record(self, session_id: str) -> dict[str, Any] | None:
        resolved = str(session_id or "").strip()
        if not resolved:
            return None
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            row = conn.execute(
                text(_SESSION_SELECT_SQL + " WHERE session_id = :session_id LIMIT 1"),
                {"session_id": resolved},
            ).mappings().first()
        return _row_to_session(row) if row else None

    def save_session_record(self, record: dict[str, Any]) -> dict[str, Any]:
        return self.create_session_record(record)

    def list_session_records(self) -> list[dict[str, Any]]:
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            rows = conn.execute(text(_SESSION_SELECT_SQL + " ORDER BY updated_at DESC")).mappings().all()
        return [_row_to_session(row) for row in rows]

    def list_session_messages(self, session_id: str) -> list[dict[str, Any]]:
        resolved = str(session_id or "").strip()
        if not resolved:
            return []
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            rows = conn.execute(
                text(_MESSAGE_SELECT_SQL + " WHERE session_id = :session_id ORDER BY created_at ASC, message_id ASC"),
                {"session_id": resolved},
            ).mappings().all()
        return [_row_to_message(row) for row in rows]

    def append_session_messages(self, session_id: str, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        resolved = str(session_id or "").strip()
        if not resolved:
            return []
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            for message in messages:
                conn.execute(text(_MESSAGE_INSERT_SQL), _message_params({**message, "session_id": resolved}))
        return self.list_session_messages(resolved)

    def reset(self) -> None:
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            conn.execute(text("DELETE FROM flare_session_messages"))
            conn.execute(text("DELETE FROM flare_sessions"))


_SESSION_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS flare_sessions (
    session_id TEXT PRIMARY KEY,
    project_id TEXT,
    title TEXT NOT NULL,
    preview TEXT,
    title_source TEXT,
    status TEXT,
    user_id TEXT,
    function_type TEXT,
    context_json TEXT,
    created_at TEXT,
    updated_at TEXT
)
"""

_SESSION_MESSAGE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS flare_session_messages (
    message_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    run_id TEXT,
    role TEXT,
    content TEXT,
    attachments_json TEXT,
    context_refs_json TEXT,
    knowledge_refs_json TEXT,
    agent_status_json TEXT,
    thinking_trace TEXT,
    execution_trace_json TEXT,
    knowledge_search_json TEXT,
    sourcing_candidates_json TEXT,
    knowledge_citation_json TEXT,
    canvas_state_json TEXT,
    analysis_payload_json TEXT,
    context_usage_json TEXT,
    provider_trace_json TEXT,
    context_authority_json TEXT,
    plan_payload_json TEXT,
    created_at TEXT
)
"""

_SESSION_PROJECT_INDEX_SQL = "CREATE INDEX IF NOT EXISTS idx_flare_sessions_project ON flare_sessions(project_id, user_id)"
_SESSION_MESSAGE_INDEX_SQL = "CREATE INDEX IF NOT EXISTS idx_flare_session_messages_session ON flare_session_messages(session_id)"

_SESSION_MESSAGE_ADDITIVE_COLUMNS = (
    "run_id", "agent_status_json", "thinking_trace", "execution_trace_json",
    "knowledge_search_json", "sourcing_candidates_json", "knowledge_citation_json",
    "canvas_state_json", "analysis_payload_json",
    "context_usage_json", "provider_trace_json", "context_authority_json", "plan_payload_json",
)

_SESSION_SELECT_SQL = """
SELECT session_id, project_id, title, preview, title_source, status, user_id,
       function_type, context_json, created_at, updated_at
FROM flare_sessions
"""

_MESSAGE_SELECT_SQL = """
SELECT message_id, session_id, run_id, role, content, attachments_json, context_refs_json,
       knowledge_refs_json, agent_status_json, thinking_trace, execution_trace_json,
       knowledge_search_json, sourcing_candidates_json, knowledge_citation_json,
       canvas_state_json, analysis_payload_json,
       context_usage_json, provider_trace_json, context_authority_json, plan_payload_json, created_at
FROM flare_session_messages
"""

_SESSION_UPSERT_SQL = """
INSERT INTO flare_sessions (
    session_id, project_id, title, preview, title_source, status, user_id,
    function_type, context_json, created_at, updated_at
) VALUES (
    :session_id, :project_id, :title, :preview, :title_source, :status, :user_id,
    :function_type, :context_json, :created_at, :updated_at
)
ON CONFLICT(session_id) DO UPDATE SET
    project_id = excluded.project_id,
    title = excluded.title,
    preview = excluded.preview,
    title_source = excluded.title_source,
    status = excluded.status,
    user_id = excluded.user_id,
    function_type = excluded.function_type,
    context_json = excluded.context_json,
    updated_at = excluded.updated_at
"""

_MESSAGE_INSERT_SQL = """
INSERT INTO flare_session_messages (
    message_id, session_id, run_id, role, content, attachments_json, context_refs_json,
    knowledge_refs_json, agent_status_json, thinking_trace, execution_trace_json,
    knowledge_search_json, sourcing_candidates_json, knowledge_citation_json,
    canvas_state_json, analysis_payload_json,
    context_usage_json, provider_trace_json, context_authority_json, plan_payload_json, created_at
) VALUES (
    :message_id, :session_id, :run_id, :role, :content, :attachments_json, :context_refs_json,
    :knowledge_refs_json, :agent_status_json, :thinking_trace, :execution_trace_json,
    :knowledge_search_json, :sourcing_candidates_json, :knowledge_citation_json,
    :canvas_state_json, :analysis_payload_json,
    :context_usage_json, :provider_trace_json, :context_authority_json, :plan_payload_json, :created_at
)
"""
