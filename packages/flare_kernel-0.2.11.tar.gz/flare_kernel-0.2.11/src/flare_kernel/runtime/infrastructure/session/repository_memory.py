"""In-memory session persistence repository."""

from __future__ import annotations

import threading
from typing import Any

from .repository import SessionRepository


class InMemorySessionRepository(SessionRepository):
    """Default in-memory repository for local/dev session state."""

    def __init__(self) -> None:
        self._sessions: dict[str, dict[str, Any]] = {}
        self._messages: dict[str, list[dict[str, Any]]] = {}
        self._lock = threading.Lock()

    def create_session_record(self, record: dict[str, Any]) -> dict[str, Any]:
        session_id = str(record.get("session_id") or "").strip()
        with self._lock:
            self._sessions[session_id] = dict(record)
            self._messages.setdefault(session_id, [])
            return dict(self._sessions[session_id])

    def load_session_record(self, session_id: str) -> dict[str, Any] | None:
        resolved = str(session_id or "").strip()
        if not resolved:
            return None
        with self._lock:
            record = self._sessions.get(resolved)
            return dict(record) if isinstance(record, dict) else None

    def save_session_record(self, record: dict[str, Any]) -> dict[str, Any]:
        session_id = str(record.get("session_id") or "").strip()
        with self._lock:
            self._sessions[session_id] = dict(record)
            self._messages.setdefault(session_id, [])
            return dict(self._sessions[session_id])

    def list_session_records(self) -> list[dict[str, Any]]:
        with self._lock:
            return [dict(item) for item in self._sessions.values()]

    def list_session_messages(self, session_id: str) -> list[dict[str, Any]]:
        resolved = str(session_id or "").strip()
        if not resolved:
            return []
        with self._lock:
            return [dict(item) for item in self._messages.get(resolved, [])]

    def append_session_messages(self, session_id: str, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        resolved = str(session_id or "").strip()
        if not resolved:
            return []
        with self._lock:
            session_messages = self._messages.setdefault(resolved, [])
            session_messages.extend(dict(item) for item in messages)
            return [dict(item) for item in session_messages]

    def reset(self) -> None:
        with self._lock:
            self._sessions.clear()
            self._messages.clear()
