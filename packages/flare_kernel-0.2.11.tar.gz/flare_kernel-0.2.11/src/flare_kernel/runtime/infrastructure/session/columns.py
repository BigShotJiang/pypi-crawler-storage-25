"""Session table column introspection helpers."""

from __future__ import annotations

from typing import Any


def list_session_message_columns(conn: Any, text_fn: Any) -> set[str]:
    """Return existing message column names for the active SQL dialect."""

    dialect_name = str(getattr(getattr(conn, "dialect", None), "name", "") or "").strip().lower()
    if dialect_name == "postgresql":
        rows = conn.execute(
            text_fn(
                """
                SELECT column_name
                FROM information_schema.columns
                WHERE table_name = 'flare_session_messages'
                """
            )
        ).fetchall()
        return {str(row[0]) for row in rows}

    rows = conn.execute(text_fn("PRAGMA table_info(flare_session_messages)")).fetchall()
    return {str(row[1]) for row in rows}


__all__ = ["list_session_message_columns"]
