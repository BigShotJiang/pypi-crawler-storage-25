"""Knowledge ingestion persistence across SQL and vector stores."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any, Callable

from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine
from flare_kernel.runtime.infrastructure.knowledge_terms import split_text_chunks
from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.infrastructure.vector_store import (
    _KNOWLEDGE_COLLECTION,
    ensure_qdrant_collection,
    qdrant_client,
    stable_embedding,
)

logger = get_logger("flare_kernel.runtime.infrastructure.knowledge_ingest")


def _utcnow_iso() -> str:
    return datetime.now(UTC).isoformat()


def ingest_knowledge_record(
    *,
    trace_id: str,
    project_id: str,
    user_id: str,
    session_id: str,
    content: str,
    source_id: str | None,
    title: str | None,
    metadata: dict[str, Any] | None,
    build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine,
    qdrant_client_fn: Callable[[], Any] = qdrant_client,
    ensure_collection_fn: Callable[[Any, str], None] = ensure_qdrant_collection,
) -> dict[str, Any]:
    clean_content = content.strip()
    chunks = split_text_chunks(clean_content)
    if not clean_content or not chunks:
        return _empty_content_result(source_id)

    record_id = str(uuid.uuid4())
    state = _build_initial_state()
    _persist_postgres_knowledge(
        state,
        build_sqlalchemy_engine_fn,
        trace_id=trace_id,
        record_id=record_id,
        project_id=project_id,
        user_id=user_id,
        session_id=session_id,
        content=clean_content,
        source_id=source_id,
        title=title,
        metadata=metadata,
        chunks=chunks,
    )
    _persist_qdrant_knowledge(
        state,
        qdrant_client_fn,
        ensure_collection_fn,
        trace_id=trace_id,
        record_id=record_id,
        project_id=project_id,
        user_id=user_id,
        session_id=session_id,
        source_id=source_id,
        title=title,
        chunks=chunks,
    )
    _finalize_ingest_state(state)
    return {
        "status": state["status"],
        "record_id": record_id,
        "chunk_count": len(chunks),
        "details": state["details"],
        "source_id": source_id,
        "error_code": state["error_code"],
        "error_message": state["error_message"],
    }


def _empty_content_result(source_id: str | None) -> dict[str, Any]:
    return {
        "status": "failed",
        "record_id": "",
        "chunk_count": 0,
        "details": {"reason": "empty_content"},
        "source_id": source_id,
        "error_code": "EMPTY_CONTENT",
        "error_message": "empty_content",
    }


def _build_initial_state() -> dict[str, Any]:
    return {"details": {"postgres": False, "qdrant": False}, "status": "stored", "error_code": None, "error_message": None}


def _persist_postgres_knowledge(state: dict[str, Any], build_engine_fn: Callable[[], Any], **record: Any) -> None:
    engine = build_engine_fn()
    if engine is None:
        return
    try:
        from sqlalchemy import text

        with engine.begin() as conn:
            conn.execute(text(_KNOWLEDGE_RECORDS_TABLE_SQL))
            conn.execute(text(_KNOWLEDGE_CHUNKS_TABLE_SQL))
            conn.execute(text(_KNOWLEDGE_RECORD_INSERT_SQL), _build_record_params(record))
            for chunk_index, chunk_text in enumerate(record["chunks"]):
                conn.execute(text(_KNOWLEDGE_CHUNK_INSERT_SQL), _build_chunk_params(record, chunk_index, chunk_text))
        state["details"]["postgres"] = True
    except Exception as exc:
        logger.warning("knowledge.ingest.postgres_failed trace_id=%s error=%s", record.get("trace_id"), str(exc))
        state.update({"status": "partial", "error_code": "POSTGRES_WRITE_FAILED", "error_message": str(exc)})


def _persist_qdrant_knowledge(state: dict[str, Any], qdrant_client_fn: Callable[[], Any], ensure_collection_fn: Callable[[Any, str], None], **record: Any) -> None:
    client = qdrant_client_fn()
    if client is None:
        return
    try:
        from qdrant_client.http import models

        ensure_collection_fn(client, _KNOWLEDGE_COLLECTION)
        points = [_build_qdrant_point(models, record, chunk_index, chunk_text) for chunk_index, chunk_text in enumerate(record["chunks"])]
        client.upsert(collection_name=_KNOWLEDGE_COLLECTION, points=points)
        state["details"]["qdrant"] = True
    except Exception as exc:
        logger.warning("knowledge.ingest.qdrant_failed trace_id=%s error=%s", record.get("trace_id"), str(exc))
        state.update({"status": "partial" if state["details"]["postgres"] else "failed", "error_code": "QDRANT_WRITE_FAILED", "error_message": str(exc)})


def _finalize_ingest_state(state: dict[str, Any]) -> None:
    if state["details"]["postgres"] or state["details"]["qdrant"]:
        return
    state["status"] = "failed"
    if state["error_code"] is None:
        state["error_code"] = "KNOWLEDGE_INGEST_FAILED"
        state["error_message"] = "storage_unavailable"


def _build_record_params(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": record["record_id"],
        "trace_id": record["trace_id"],
        "project_id": record["project_id"],
        "user_id": record["user_id"],
        "session_id": record["session_id"],
        "source_id": record["source_id"],
        "title": record["title"] or "",
        "content": record["content"],
        "metadata_json": str(record["metadata"] or {}),
        "created_at": _utcnow_iso(),
    }


def _build_chunk_params(record: dict[str, Any], chunk_index: int, chunk_text: str) -> dict[str, Any]:
    return {
        "id": str(uuid.uuid4()),
        "record_id": record["record_id"],
        "trace_id": record["trace_id"],
        "project_id": record["project_id"],
        "user_id": record["user_id"],
        "session_id": record["session_id"],
        "chunk_index": chunk_index,
        "content": chunk_text,
        "created_at": _utcnow_iso(),
    }


def _build_qdrant_point(models: Any, record: dict[str, Any], chunk_index: int, chunk_text: str) -> Any:
    chunk_id = str(uuid.uuid4())
    return models.PointStruct(
        id=chunk_id,
        vector=stable_embedding(chunk_text),
        payload={
            "record_id": record["record_id"],
            "chunk_id": chunk_id,
            "chunk_index": chunk_index,
            "project_id": record["project_id"],
            "user_id": record["user_id"],
            "session_id": record["session_id"],
            "source_id": record["source_id"] or "",
            "title": record["title"] or "",
            "content": chunk_text,
            "trace_id": record["trace_id"],
            "created_at": _utcnow_iso(),
        },
    )


_KNOWLEDGE_RECORDS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS flare_knowledge_records (
    id TEXT PRIMARY KEY,
    trace_id TEXT,
    project_id TEXT,
    user_id TEXT,
    session_id TEXT,
    source_id TEXT,
    title TEXT,
    content TEXT,
    metadata_json TEXT,
    created_at TEXT
)
"""

_KNOWLEDGE_CHUNKS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS flare_knowledge_chunks (
    id TEXT PRIMARY KEY,
    record_id TEXT,
    trace_id TEXT,
    project_id TEXT,
    user_id TEXT,
    session_id TEXT,
    chunk_index INTEGER,
    content TEXT,
    created_at TEXT
)
"""

_KNOWLEDGE_RECORD_INSERT_SQL = """
INSERT INTO flare_knowledge_records (
    id, trace_id, project_id, user_id, session_id, source_id, title, content, metadata_json, created_at
) VALUES (
    :id, :trace_id, :project_id, :user_id, :session_id, :source_id, :title, :content, :metadata_json, :created_at
)
"""

_KNOWLEDGE_CHUNK_INSERT_SQL = """
INSERT INTO flare_knowledge_chunks (
    id, record_id, trace_id, project_id, user_id, session_id, chunk_index, content, created_at
) VALUES (
    :id, :record_id, :trace_id, :project_id, :user_id, :session_id, :chunk_index, :content, :created_at
)
"""
