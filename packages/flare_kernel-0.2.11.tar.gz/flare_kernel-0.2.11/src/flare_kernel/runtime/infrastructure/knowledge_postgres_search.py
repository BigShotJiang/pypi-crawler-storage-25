"""Postgres-backed knowledge retrieval."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine
from flare_kernel.runtime.infrastructure.knowledge_terms import build_entity_match, split_query_terms


def search_postgres_knowledge(
    *,
    project_id: str,
    user_id: str,
    query: str,
    top_k: int,
    source_ids: list[str],
    entity_terms: list[str],
    entity_query_mode: str,
    query_lane: str,
    build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine,
) -> list[dict[str, Any]] | None:
    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        return None
    results: list[dict[str, Any]] = []
    try:
        from sqlalchemy import text

        with engine.connect() as conn:
            params, source_filter, query_filter, fact_filter = _build_query_parts(
                project_id=project_id,
                user_id=user_id,
                query=query,
                top_k=top_k,
                source_ids=source_ids,
            )
            _append_fact_rows(
                conn,
                text,
                results,
                params=params,
                source_filter=source_filter,
                fact_filter=fact_filter,
                entity_query_mode=entity_query_mode,
                query_lane=query_lane,
            )
            _append_knowledge_rows(
                conn,
                text,
                results,
                params=params,
                source_filter=source_filter,
                query_filter=query_filter,
                entity_terms=entity_terms,
                entity_query_mode=entity_query_mode,
                query_lane=query_lane,
            )
            if not results and source_ids:
                _append_source_fallback_rows(
                    conn,
                    text,
                    results,
                    params=params,
                    source_filter=source_filter,
                    entity_terms=entity_terms,
                    entity_query_mode=entity_query_mode,
                    query_lane=query_lane,
                )
    except Exception:
        return []
    return results


def _build_query_parts(*, project_id: str, user_id: str, query: str, top_k: int, source_ids: list[str]) -> tuple[dict[str, Any], str, str, str]:
    query_terms = split_query_terms(query) or [query]
    params: dict[str, Any] = {"project_id": project_id, "user_id": user_id, "limit": max(1, min(top_k, 20))}
    for index, term in enumerate(query_terms):
        params[f"query_{index}"] = f"%{term}%"
    source_filter = _build_source_filter(source_ids, params)
    query_filter = _build_like_filter(["content", "title"], query_terms)
    fact_filter = _build_like_filter(["fact_text", "fact_type"], query_terms)
    return params, source_filter, query_filter, fact_filter


def _build_source_filter(source_ids: list[str], params: dict[str, Any]) -> str:
    if not source_ids:
        return ""
    param_names: list[str] = []
    for index, source_id in enumerate(source_ids):
        param_name = f"source_id_{index}"
        param_names.append(f":{param_name}")
        params[param_name] = source_id
    return f" AND source_id IN ({', '.join(param_names)})"


def _build_like_filter(fields: list[str], query_terms: list[str]) -> str:
    conditions: list[str] = []
    for index, _ in enumerate(query_terms):
        for field in fields:
            conditions.append(f"LOWER({field}) LIKE LOWER(:query_{index})")
    return f" AND ({' OR '.join(conditions)})" if conditions else ""


def _append_fact_rows(conn: Any, text_fn: Any, results: list[dict[str, Any]], *, params: dict[str, Any], source_filter: str, fact_filter: str, entity_query_mode: str, query_lane: str) -> None:
    try:
        rows = conn.execute(
            text_fn(
                f"""
                SELECT id, fact_type, fact_text, source_id, chunk_id, confidence
                FROM flare_source_fact_cards
                WHERE project_id = :project_id
                  AND user_id = :user_id
                  {fact_filter}
                  {source_filter}
                ORDER BY confidence DESC, created_at DESC
                LIMIT :limit
                """
            ),
            params,
        )
        for row in rows:
            results.append(_build_fact_result(row, entity_query_mode=entity_query_mode, query_lane=query_lane))
    except Exception:
        _rollback_quietly(conn)


def _append_knowledge_rows(conn: Any, text_fn: Any, results: list[dict[str, Any]], *, params: dict[str, Any], source_filter: str, query_filter: str, entity_terms: list[str], entity_query_mode: str, query_lane: str) -> None:
    try:
        rows = conn.execute(
            text_fn(
                f"""
                SELECT id, title, content, source_id
                FROM flare_knowledge_records
                WHERE project_id = :project_id
                  AND user_id = :user_id
                  {query_filter}
                  {source_filter}
                ORDER BY created_at DESC
                LIMIT :limit
                """
            ),
            params,
        )
        for row in rows:
            results.append(_build_knowledge_result(row, entity_terms=entity_terms, entity_query_mode=entity_query_mode, query_lane=query_lane))
    except Exception:
        _append_legacy_knowledge_rows(conn, text_fn, results, params=params, entity_terms=entity_terms, entity_query_mode=entity_query_mode, query_lane=query_lane)


def _append_legacy_knowledge_rows(conn: Any, text_fn: Any, results: list[dict[str, Any]], *, params: dict[str, Any], entity_terms: list[str], entity_query_mode: str, query_lane: str) -> None:
    _rollback_quietly(conn)
    rows = conn.execute(
        text_fn(
            """
            SELECT id, title, content
            FROM flare_knowledge_records
            WHERE project_id = :project_id
              AND user_id = :user_id
              AND (LOWER(content) LIKE LOWER(:query_0) OR LOWER(title) LIKE LOWER(:query_0))
            ORDER BY created_at DESC
            LIMIT :limit
            """
        ),
        params,
    )
    for row in rows:
        results.append(_build_legacy_knowledge_result(row, entity_terms=entity_terms, entity_query_mode=entity_query_mode, query_lane=query_lane))


def _append_source_fallback_rows(conn: Any, text_fn: Any, results: list[dict[str, Any]], *, params: dict[str, Any], source_filter: str, entity_terms: list[str], entity_query_mode: str, query_lane: str) -> None:
    rows = conn.execute(
        text_fn(
            f"""
            SELECT id, title, content, source_id
            FROM flare_knowledge_records
            WHERE project_id = :project_id
              AND user_id = :user_id
              {source_filter}
            ORDER BY created_at DESC
            LIMIT :limit
            """
        ),
        params,
    )
    for row in rows:
        result = _build_knowledge_result(row, entity_terms=entity_terms, entity_query_mode=entity_query_mode, query_lane=query_lane)
        result["score"] = 0.0001
        results.append(result)


def _build_fact_result(row: Any, *, entity_query_mode: str, query_lane: str) -> dict[str, Any]:
    return {
        "record_id": row[0],
        "title": str(row[1] or "fact_card"),
        "content": row[2] or "",
        "source_id": row[3] or "",
        "chunk_id": row[4] or "",
        "score": max(0.1, float(row[5] or 0.0)),
        "matched_field": "fact_text",
        "source_type": "local_fact",
        "source": "fact_card",
        "matched_entities": [],
        "entity_matched": False,
        "entity_match_score": 0.0,
        "entity_query_mode": entity_query_mode,
        "query_lane": query_lane,
    }


def _build_knowledge_result(row: Any, *, entity_terms: list[str], entity_query_mode: str, query_lane: str) -> dict[str, Any]:
    matched_entities, entity_match_score = build_entity_match(title=str(row[1] or ""), content=str(row[2] or ""), entity_terms=entity_terms)
    return {
        "record_id": row[0],
        "title": row[1] or "",
        "content": row[2] or "",
        "source_id": row[3],
        "score": 0.0,
        "source": "postgres",
        "matched_entities": matched_entities,
        "entity_matched": bool(matched_entities),
        "entity_match_score": entity_match_score,
        "entity_query_mode": entity_query_mode,
        "query_lane": query_lane,
    }


def _build_legacy_knowledge_result(row: Any, *, entity_terms: list[str], entity_query_mode: str, query_lane: str) -> dict[str, Any]:
    matched_entities, entity_match_score = build_entity_match(title=str(row[1] or ""), content=str(row[2] or ""), entity_terms=entity_terms)
    return {
        "record_id": row[0],
        "title": row[1] or "",
        "content": row[2] or "",
        "source_id": "",
        "score": 0.0,
        "source": "postgres",
        "matched_entities": matched_entities,
        "entity_matched": bool(matched_entities),
        "entity_match_score": entity_match_score,
        "entity_query_mode": entity_query_mode,
        "query_lane": query_lane,
    }


def _rollback_quietly(conn_obj: Any) -> None:
    try:
        rollback_fn = getattr(conn_obj, "rollback", None)
        if callable(rollback_fn):
            rollback_fn()
    except Exception:
        return
