"""Qdrant-backed knowledge retrieval."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.runtime.infrastructure.knowledge_terms import build_entity_match, keyword_overlap_ratio
from flare_kernel.runtime.infrastructure.vector_store import (
    _KNOWLEDGE_COLLECTION,
    ensure_qdrant_collection,
    qdrant_client,
    stable_embedding,
)


def search_qdrant_knowledge(
    *,
    project_id: str,
    user_id: str,
    query: str,
    top_k: int,
    min_score: float,
    source_ids: list[str],
    entity_terms: list[str],
    entity_query_mode: str,
    query_lane: str,
    qdrant_client_fn: Callable[[], Any] = qdrant_client,
    ensure_collection_fn: Callable[[Any, str], None] = ensure_qdrant_collection,
) -> list[dict[str, Any]]:
    client = qdrant_client_fn()
    if client is None:
        return []
    from qdrant_client.http import models

    ensure_collection_fn(client, _KNOWLEDGE_COLLECTION)
    qdrant_hits = _query_qdrant_hits(
        client=client,
        models=models,
        project_id=project_id,
        user_id=user_id,
        query=query,
        top_k=top_k,
        source_ids=source_ids,
    )
    return _build_qdrant_results(
        qdrant_hits=qdrant_hits,
        query=query,
        min_score=min_score,
        entity_terms=entity_terms,
        entity_query_mode=entity_query_mode,
        query_lane=query_lane,
    )


def _query_qdrant_hits(*, client: Any, models: Any, project_id: str, user_id: str, query: str, top_k: int, source_ids: list[str]) -> Any:
    filter_must = [
        models.FieldCondition(key="project_id", match=models.MatchValue(value=project_id)),
        models.FieldCondition(key="user_id", match=models.MatchValue(value=user_id)),
    ]
    if source_ids:
        filter_must.append(models.FieldCondition(key="source_id", match=models.MatchAny(any=source_ids)))
    if hasattr(client, "search"):
        return client.search(
            collection_name=_KNOWLEDGE_COLLECTION,
            query_vector=stable_embedding(query),
            limit=max(1, min(top_k, 20)),
            query_filter=models.Filter(must=filter_must),
        )
    query_result = client.query_points(
        collection_name=_KNOWLEDGE_COLLECTION,
        query=stable_embedding(query),
        limit=max(1, min(top_k, 20)),
        query_filter=models.Filter(must=filter_must),
    )
    return getattr(query_result, "points", []) if query_result is not None else []


def _build_qdrant_results(
    *,
    qdrant_hits: Any,
    query: str,
    min_score: float,
    entity_terms: list[str],
    entity_query_mode: str,
    query_lane: str,
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for hit in qdrant_hits:
        payload, qdrant_score, hit_id = _read_qdrant_hit(hit)
        overlap_score = keyword_overlap_ratio(query, str(payload.get("content") or ""))
        combined_score = (0.7 * qdrant_score) + (0.3 * overlap_score)
        if combined_score < float(min_score):
            continue
        title = str(payload.get("title") or "")
        content = str(payload.get("content") or "")
        matched_entities, entity_match_score = build_entity_match(title=title, content=content, entity_terms=entity_terms)
        results.append(_build_qdrant_result(payload, hit_id, combined_score, qdrant_score, overlap_score, matched_entities, entity_match_score, entity_query_mode, query_lane))
    return sorted(results, key=lambda item: float(item.get("score") or 0.0), reverse=True)


def _read_qdrant_hit(hit: Any) -> tuple[dict[str, Any], float, Any]:
    if isinstance(hit, dict):
        payload = hit.get("payload") if isinstance(hit.get("payload"), dict) else {}
        return payload, float(hit.get("score") or 0.0), hit.get("id")
    payload = hit.payload if isinstance(hit.payload, dict) else {}
    return payload, float(getattr(hit, "score", 0.0) or 0.0), getattr(hit, "id", "")


def _build_qdrant_result(payload: dict[str, Any], hit_id: Any, combined_score: float, qdrant_score: float, overlap_score: float, matched_entities: list[str], entity_match_score: float, entity_query_mode: str, query_lane: str) -> dict[str, Any]:
    return {
        "record_id": payload.get("record_id") or str(hit_id or ""),
        "chunk_id": payload.get("chunk_id") or "",
        "chunk_index": payload.get("chunk_index"),
        "title": payload.get("title") or "",
        "content": payload.get("content") or "",
        "score": combined_score,
        "vector_score": qdrant_score,
        "overlap_score": overlap_score,
        "source_id": payload.get("source_id"),
        "source": "qdrant",
        "matched_entities": matched_entities,
        "entity_matched": bool(matched_entities),
        "entity_match_score": entity_match_score,
        "entity_query_mode": entity_query_mode,
        "query_lane": query_lane,
    }
