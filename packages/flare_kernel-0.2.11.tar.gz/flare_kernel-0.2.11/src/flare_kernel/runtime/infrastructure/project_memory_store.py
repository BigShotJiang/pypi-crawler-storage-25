"""Database-backed Project Memory persistence for OBJ-03."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine
from flare_kernel.runtime.infrastructure.project_memory_codec import (
    build_project_memory_params,
    normalize_project_memory_confidence,
    normalize_project_memory_status,
    normalize_project_memory_text,
    require_project_memory_content,
    require_project_memory_scope,
    row_to_project_memory_record,
    score_project_memory_record,
)
from flare_kernel.runtime.infrastructure.project_memory_sql import (
    PROJECT_MEMORY_INSERT_SQL,
    PROJECT_MEMORY_LIST_WHERE_SQL,
    PROJECT_MEMORY_SCOPE_INDEX_SQL,
    PROJECT_MEMORY_SELECT_BASE_SQL,
    PROJECT_MEMORY_TABLE_SQL,
    PROJECT_MEMORY_TYPE_INDEX_SQL,
    PROJECT_MEMORY_UPDATE_SQL,
)


def _ensure_project_memory_table(conn: Any, text_fn: Any) -> None:
    """Ensure Project Memory SQL table and indexes exist.

    Args:
        conn: SQLAlchemy connection.
        text_fn: SQLAlchemy text constructor.

    Returns:
        None.
    """

    conn.execute(text_fn(PROJECT_MEMORY_TABLE_SQL))
    conn.execute(text_fn(PROJECT_MEMORY_SCOPE_INDEX_SQL))
    conn.execute(text_fn(PROJECT_MEMORY_TYPE_INDEX_SQL))


def _project_memory_engine(build_sqlalchemy_engine_fn: Callable[[], Any]) -> Any:
    """Resolve the SQLAlchemy engine used by Project Memory storage.

    Args:
        build_sqlalchemy_engine_fn: Engine factory injected for tests/runtime.

    Returns:
        SQLAlchemy engine.

    Raises:
        RuntimeError: If no SQLAlchemy engine is available.
    """

    engine = build_sqlalchemy_engine_fn()
    if engine is None:
        raise RuntimeError("SQLAlchemy engine is unavailable for project memory storage")
    return engine


def upsert_project_memory_record(
    *,
    project_id: str,
    user_id: str,
    content: str,
    memory_id: str | None = None,
    memory_type: str = "fact",
    source_session_id: str | None = None,
    source_message_id: str | None = None,
    source_id: str | None = None,
    evidence: list[dict[str, Any]] | None = None,
    confidence: float | None = None,
    status: str = "active",
    build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine,
) -> dict[str, Any]:
    """Create or update a Project Memory record in SQL storage.

    Args:
        project_id: Owning project id.
        user_id: Owning user id.
        content: Durable memory text.
        memory_id: Optional existing memory id for update.
        memory_type: Memory category.
        source_session_id: Producing session id, when available.
        source_message_id: Producing message id, when available.
        source_id: Producing source id, when available.
        evidence: Optional supporting snippets.
        confidence: Optional confidence score.
        status: Lifecycle status.
        build_sqlalchemy_engine_fn: Engine factory injected for tests/runtime.

    Returns:
        Persisted ProjectMemoryRecord as a dict.
    """

    resolved_project_id, resolved_user_id = require_project_memory_scope(project_id, user_id)
    params = build_project_memory_params(
        memory_id=memory_id,
        project_id=resolved_project_id,
        user_id=resolved_user_id,
        source_session_id=source_session_id,
        source_message_id=source_message_id,
        source_id=source_id,
        memory_type=memory_type,
        content=require_project_memory_content(content),
        evidence=evidence,
        confidence=normalize_project_memory_confidence(confidence),
        status=status,
    )
    from sqlalchemy import text

    with _project_memory_engine(build_sqlalchemy_engine_fn).begin() as conn:
        _ensure_project_memory_table(conn, text)
        existing = conn.execute(
            text("SELECT memory_id, created_at FROM flare_project_memory WHERE memory_id = :memory_id LIMIT 1"),
            {"memory_id": params["memory_id"]},
        ).mappings().first()
        if existing is None:
            conn.execute(text(PROJECT_MEMORY_INSERT_SQL), params)
        else:
            params["created_at"] = dict(existing).get("created_at") or params["created_at"]
            conn.execute(text(PROJECT_MEMORY_UPDATE_SQL), params)
    stored = get_project_memory_record(
        memory_id=params["memory_id"],
        build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
    )
    if stored is None:
        raise RuntimeError("project memory upsert did not persist a record")
    return stored


def get_project_memory_record(
    *,
    memory_id: str,
    build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine,
) -> dict[str, Any] | None:
    """Fetch one Project Memory record by id.

    Args:
        memory_id: Stable Project Memory identifier.
        build_sqlalchemy_engine_fn: Engine factory injected for tests/runtime.

    Returns:
        ProjectMemoryRecord as a dict, or None when not found.
    """

    resolved_memory_id = normalize_project_memory_text(memory_id)
    if not resolved_memory_id:
        return None
    from sqlalchemy import text

    with _project_memory_engine(build_sqlalchemy_engine_fn).begin() as conn:
        _ensure_project_memory_table(conn, text)
        row = conn.execute(
            text(PROJECT_MEMORY_SELECT_BASE_SQL + " WHERE memory_id = :memory_id LIMIT 1"),
            {"memory_id": resolved_memory_id},
        ).mappings().first()
    return row_to_project_memory_record(row) if row else None


def list_project_memory_records(
    *,
    project_id: str,
    user_id: str,
    status: str = "active",
    build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine,
) -> list[dict[str, Any]]:
    """List Project Memory records by project/user scope and status.

    Args:
        project_id: Owning project id.
        user_id: Owning user id.
        status: Lifecycle status filter.
        build_sqlalchemy_engine_fn: Engine factory injected for tests/runtime.

    Returns:
        ProjectMemoryRecord dicts ordered by updated_at descending.
    """

    resolved_project_id, resolved_user_id = require_project_memory_scope(project_id, user_id)
    resolved_status = normalize_project_memory_status(status)
    from sqlalchemy import text

    with _project_memory_engine(build_sqlalchemy_engine_fn).begin() as conn:
        _ensure_project_memory_table(conn, text)
        rows = conn.execute(
            text(PROJECT_MEMORY_SELECT_BASE_SQL + PROJECT_MEMORY_LIST_WHERE_SQL),
            {"project_id": resolved_project_id, "user_id": resolved_user_id, "status": resolved_status},
        ).mappings().all()
    return [row_to_project_memory_record(row) for row in rows]


def search_project_memory_records(
    *,
    project_id: str,
    user_id: str,
    query: str,
    top_k: int = 5,
    status: str = "active",
    build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine,
) -> list[dict[str, Any]]:
    """Lexically recall Project Memory records within one project/user scope.

    Args:
        project_id: Owning project id.
        user_id: Owning user id.
        query: Recall query text.
        top_k: Maximum number of records to return.
        status: Lifecycle status filter.
        build_sqlalchemy_engine_fn: Engine factory injected for tests/runtime.

    Returns:
        Matching ProjectMemoryRecord dicts ordered by score and recency.
    """

    clean_query = normalize_project_memory_text(query)
    if not clean_query:
        return []
    scoped_rows = list_project_memory_records(
        project_id=project_id,
        user_id=user_id,
        status=status,
        build_sqlalchemy_engine_fn=build_sqlalchemy_engine_fn,
    )
    query_terms = [term.lower() for term in clean_query.split() if term.strip()]
    scored_rows = [score_project_memory_record(row, query_terms) for row in scoped_rows]
    matches = [item for item in scored_rows if item[0] > 0]
    matches.sort(key=lambda item: (item[0], str(item[1].get("updated_at") or "")), reverse=True)
    return [row for _, row in matches[: max(1, min(int(top_k or 5), 20))]]
