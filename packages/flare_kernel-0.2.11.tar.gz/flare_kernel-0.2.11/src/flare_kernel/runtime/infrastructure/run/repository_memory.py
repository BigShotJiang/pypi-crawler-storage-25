"""In-memory run persistence repository."""

from __future__ import annotations

import threading
from typing import Any

from flare_kernel.runtime.infrastructure.run.repository import RunRepository


class InMemoryRunRepository(RunRepository):
    """Default in-memory repository for local/dev run state."""

    def __init__(self) -> None:
        self._runs: dict[str, dict[str, Any]] = {}
        self._events: dict[str, list[dict[str, Any]]] = {}
        self._lock = threading.Lock()

    def save_run_record(self, record: dict[str, Any]) -> dict[str, Any]:
        run_id = str(record.get("run_id") or "").strip()
        with self._lock:
            self._runs[run_id] = dict(record)
            self._events.setdefault(run_id, [])
            return dict(self._runs[run_id])

    def load_run_record(self, run_id: str) -> dict[str, Any] | None:
        resolved = str(run_id or "").strip()
        if not resolved:
            return None
        with self._lock:
            record = self._runs.get(resolved)
            return dict(record) if isinstance(record, dict) else None

    def list_session_runs(self, session_id: str) -> list[dict[str, Any]]:
        resolved = str(session_id or "").strip()
        if not resolved:
            return []
        with self._lock:
            rows = [dict(item) for item in self._runs.values() if item.get("session_id") == resolved]
        return sorted(rows, key=lambda item: str(item.get("created_at") or ""), reverse=True)

    def append_run_event(self, record: dict[str, Any]) -> dict[str, Any]:
        run_id = str(record.get("run_id") or "").strip()
        with self._lock:
            events = self._events.setdefault(run_id, [])
            events.append(dict(record))
            return dict(record)

    def list_run_events(self, run_id: str) -> list[dict[str, Any]]:
        resolved = str(run_id or "").strip()
        if not resolved:
            return []
        with self._lock:
            rows = [dict(item) for item in self._events.get(resolved, [])]
        return sorted(rows, key=lambda item: int(item.get("sequence") or 0))

    def reset(self) -> None:
        with self._lock:
            self._runs.clear()
            self._events.clear()
