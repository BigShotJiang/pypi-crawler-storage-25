"""Run persistence repository contract."""

from __future__ import annotations

from typing import Any, Protocol


class RunRepository(Protocol):
    """Persistence boundary for run state and event replay storage."""

    def save_run_record(self, record: dict[str, Any]) -> dict[str, Any]: ...

    def load_run_record(self, run_id: str) -> dict[str, Any] | None: ...

    def list_session_runs(self, session_id: str) -> list[dict[str, Any]]: ...

    def append_run_event(self, record: dict[str, Any]) -> dict[str, Any]: ...

    def list_run_events(self, run_id: str) -> list[dict[str, Any]]: ...

    def reset(self) -> None: ...
