"""SQL-backed run persistence repository."""

from __future__ import annotations

import json
from typing import Any, Callable

from flare_kernel.runtime.infrastructure.database import build_sqlalchemy_engine
from flare_kernel.runtime.infrastructure.run.repository import RunRepository


def _json_dumps(value: Any) -> str:
    return json.dumps(value if value is not None else {}, ensure_ascii=False, sort_keys=True)


def _json_loads(value: Any) -> dict[str, Any]:
    if value in (None, ""):
        return {}
    try:
        parsed = json.loads(str(value))
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _run_params(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "run_id": str(record.get("run_id") or ""),
        "session_id": str(record.get("session_id") or ""),
        "request_id": str(record.get("request_id") or ""),
        "trace_id": str(record.get("trace_id") or ""),
        "state": str(record.get("state") or "queued"),
        "error": str(record.get("error") or ""),
        "created_at": str(record.get("created_at") or ""),
        "started_at": str(record.get("started_at") or ""),
        "completed_at": str(record.get("completed_at") or ""),
        "updated_at": str(record.get("updated_at") or ""),
    }


def _event_params(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "event_id": str(record.get("event_id") or ""),
        "run_id": str(record.get("run_id") or ""),
        "session_id": str(record.get("session_id") or ""),
        "request_id": str(record.get("request_id") or ""),
        "event_name": str(record.get("event_name") or ""),
        "sequence": int(record.get("sequence") or 0),
        "payload_json": _json_dumps(record.get("payload") or {}),
        "created_at": str(record.get("created_at") or ""),
    }


def _row_to_run(row: Any) -> dict[str, Any]:
    return dict(row)


def _row_to_event(row: Any) -> dict[str, Any]:
    record = dict(row)
    record["payload"] = _json_loads(record.pop("payload_json", ""))
    return record


class SqlAlchemyRunRepository(RunRepository):
    """SQLAlchemy implementation of RunRepository."""

    def __init__(self, build_sqlalchemy_engine_fn: Callable[[], Any] = build_sqlalchemy_engine) -> None:
        self._build_engine = build_sqlalchemy_engine_fn

    def _engine(self) -> Any:
        engine = self._build_engine()
        if engine is None:
            raise RuntimeError("SQLAlchemy engine is unavailable for run storage")
        return engine

    def _ensure_tables(self, conn: Any, text_fn: Any) -> None:
        conn.execute(text_fn(_RUN_TABLE_SQL))
        conn.execute(text_fn(_RUN_EVENT_TABLE_SQL))
        conn.execute(text_fn(_RUN_SESSION_INDEX_SQL))
        conn.execute(text_fn(_RUN_ACTIVE_SESSION_UNIQUE_SQL))
        conn.execute(text_fn(_RUN_EVENT_INDEX_SQL))

    def save_run_record(self, record: dict[str, Any]) -> dict[str, Any]:
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            conn.execute(text(_RUN_UPSERT_SQL), _run_params(record))
        return self.load_run_record(str(record.get("run_id") or "")) or dict(record)

    def load_run_record(self, run_id: str) -> dict[str, Any] | None:
        resolved = str(run_id or "").strip()
        if not resolved:
            return None
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            row = conn.execute(text(_RUN_SELECT_SQL + " WHERE run_id = :run_id LIMIT 1"), {"run_id": resolved}).mappings().first()
        return _row_to_run(row) if row else None

    def list_session_runs(self, session_id: str) -> list[dict[str, Any]]:
        resolved = str(session_id or "").strip()
        if not resolved:
            return []
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            rows = conn.execute(
                text(_RUN_SELECT_SQL + " WHERE session_id = :session_id ORDER BY created_at DESC"),
                {"session_id": resolved},
            ).mappings().all()
        return [_row_to_run(row) for row in rows]

    def append_run_event(self, record: dict[str, Any]) -> dict[str, Any]:
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            conn.execute(text(_RUN_EVENT_INSERT_SQL), _event_params(record))
        return dict(record)

    def list_run_events(self, run_id: str) -> list[dict[str, Any]]:
        resolved = str(run_id or "").strip()
        if not resolved:
            return []
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            rows = conn.execute(
                text(_RUN_EVENT_SELECT_SQL + " WHERE run_id = :run_id ORDER BY sequence ASC"),
                {"run_id": resolved},
            ).mappings().all()
        return [_row_to_event(row) for row in rows]

    def reset(self) -> None:
        from sqlalchemy import text

        with self._engine().begin() as conn:
            self._ensure_tables(conn, text)
            conn.execute(text("DELETE FROM flare_run_events"))
            conn.execute(text("DELETE FROM flare_runs"))


_RUN_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS flare_runs (
    run_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    request_id TEXT,
    trace_id TEXT,
    state TEXT,
    error TEXT,
    created_at TEXT,
    started_at TEXT,
    completed_at TEXT,
    updated_at TEXT
)
"""

_RUN_EVENT_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS flare_run_events (
    event_id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    request_id TEXT,
    event_name TEXT,
    sequence INTEGER,
    payload_json TEXT,
    created_at TEXT
)
"""

_RUN_SESSION_INDEX_SQL = "CREATE INDEX IF NOT EXISTS idx_flare_runs_session ON flare_runs(session_id, created_at)"
_RUN_ACTIVE_SESSION_UNIQUE_SQL = (
    # DOC HELPER — ORC-11: database-level guard for cross-process workers.
    # App-level checks remain for clearer domain errors before hitting SQL.
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_flare_runs_active_session "
    "ON flare_runs(session_id) WHERE state IN ('queued', 'running')"
)
_RUN_EVENT_INDEX_SQL = "CREATE INDEX IF NOT EXISTS idx_flare_run_events_run ON flare_run_events(run_id, sequence)"

_RUN_SELECT_SQL = """
SELECT run_id, session_id, request_id, trace_id, state, error, created_at, started_at, completed_at, updated_at
FROM flare_runs
"""

_RUN_EVENT_SELECT_SQL = """
SELECT event_id, run_id, session_id, request_id, event_name, sequence, payload_json, created_at
FROM flare_run_events
"""

_RUN_UPSERT_SQL = """
INSERT INTO flare_runs (
    run_id, session_id, request_id, trace_id, state, error, created_at, started_at, completed_at, updated_at
) VALUES (
    :run_id, :session_id, :request_id, :trace_id, :state, :error, :created_at, :started_at, :completed_at, :updated_at
)
ON CONFLICT(run_id) DO UPDATE SET
    session_id = excluded.session_id,
    request_id = excluded.request_id,
    trace_id = excluded.trace_id,
    state = excluded.state,
    error = excluded.error,
    started_at = excluded.started_at,
    completed_at = excluded.completed_at,
    updated_at = excluded.updated_at
"""

_RUN_EVENT_INSERT_SQL = """
INSERT INTO flare_run_events (
    event_id, run_id, session_id, request_id, event_name, sequence, payload_json, created_at
) VALUES (
    :event_id, :run_id, :session_id, :request_id, :event_name, :sequence, :payload_json, :created_at
)
"""
