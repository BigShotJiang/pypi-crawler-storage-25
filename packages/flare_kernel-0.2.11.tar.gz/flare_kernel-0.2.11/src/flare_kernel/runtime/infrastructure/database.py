"""SQL database engine boundary for runtime infrastructure."""

from __future__ import annotations

import os
from typing import Any

_DEFAULT_POSTGRES_DSN = "postgresql://flare:flare@127.0.0.1:5432/flare"


def _env(name: str, default: str | None = None) -> str | None:
    raw = os.getenv(name)
    if raw is None:
        return default
    value = raw.strip()
    return value if value else default


def build_sqlalchemy_engine() -> Any:
    try:
        from sqlalchemy import create_engine
    except Exception:
        return None

    dsn = _env("FLARE_POSTGRES_DSN", _DEFAULT_POSTGRES_DSN) or _DEFAULT_POSTGRES_DSN
    try:
        return create_engine(dsn, pool_pre_ping=True)
    except Exception:
        return None
