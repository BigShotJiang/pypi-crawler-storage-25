"""Checkpoint persistence helpers for intake workflow."""

from __future__ import annotations

import json
import os
import re
from datetime import UTC, datetime
from typing import Any

from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.session.models import IntakeCheckpointSnapshot

logger = get_logger("flare_kernel.runtime.session.checkpoint_manager")

_DEFAULT_POSTGRES_DSN = "postgresql://flare:flare@127.0.0.1:5432/flare"
_DEFAULT_REDIS_URL = "redis://127.0.0.1:6379/0"


def _env(name: str, default: str | None = None) -> str | None:
    raw = os.getenv(name)
    if raw is None:
        return default
    value = raw.strip()
    return value if value else default


def _utcnow_iso() -> str:
    return datetime.now(UTC).isoformat()


def _build_sqlalchemy_engine():
    try:
        from sqlalchemy import create_engine
    except Exception:
        return None

    dsn = _env("FLARE_POSTGRES_DSN", _DEFAULT_POSTGRES_DSN) or _DEFAULT_POSTGRES_DSN
    try:
        return create_engine(dsn, pool_pre_ping=True)
    except Exception:
        return None


def _redis_client():
    try:
        import redis
    except Exception:
        return None

    redis_url = _env("FLARE_REDIS_URL", _DEFAULT_REDIS_URL) or _DEFAULT_REDIS_URL
    return redis.Redis.from_url(redis_url, decode_responses=True)


def _normalize_text(value: Any) -> str:
    return str(value or "").strip()


def _safe_json_dumps(value: Any) -> str:
    try:
        return json.dumps(value if isinstance(value, dict) else {}, ensure_ascii=False)
    except Exception:
        return "{}"


def _safe_json_loads(value: Any) -> dict[str, Any]:
    if not isinstance(value, str) or not value.strip():
        return {}
    try:
        loaded = json.loads(value)
    except Exception:
        return {}
    return loaded if isinstance(loaded, dict) else {}


def _derive_checkpoint_type(*, command: str, orchestration_status: dict[str, Any]) -> str:
    current_stage = _normalize_text(orchestration_status.get("current_stage")).lower()
    if _normalize_text(command) == "generate_analysis":
        return "analysis_entry"
    if bool(orchestration_status.get("decision_point_active")):
        return "decision_point"
    question = orchestration_status.get("current_question")
    if isinstance(question, dict) and _normalize_text(question.get("field_key")):
        return "question_waiting"
    if current_stage.startswith("requirement_intake"):
        return "intake_progress"
    return "orchestration_snapshot"


def _derive_checkpoint_state(*, checkpoint_type: str, orchestration_status: dict[str, Any]) -> str:
    if checkpoint_type in {"question_waiting", "decision_point"}:
        return "waiting_user"
    if bool(orchestration_status.get("intake_session_completed")):
        return "completed"
    return "active"


def _build_checkpoint_id(*, intake_session_id: str, checkpoint_type: str, question_key: str) -> str:
    raw = f"{intake_session_id}:{checkpoint_type}:{question_key or 'none'}"
    normalized = re.sub(r"[^a-zA-Z0-9:_\-]", "_", raw)
    return f"ckpt_{normalized[:180]}"


def persist_intake_checkpoint(
    *,
    trace_id: str,
    session_id: str,
    command: str,
    orchestration_status: dict[str, Any] | None,
) -> dict[str, Any]:
    status = dict(orchestration_status) if isinstance(orchestration_status, dict) else {}
    intake_session_id = _normalize_text(status.get("intake_session_id"))
    if not intake_session_id:
        return {
            "stored": False,
            "reason": "missing_intake_session_id",
            "checkpoint_id": "",
            "channel": "none",
        }

    checkpoint_type = _derive_checkpoint_type(command=command, orchestration_status=status)
    current_question = status.get("current_question") if isinstance(status.get("current_question"), dict) else {}
    question_key = _normalize_text(current_question.get("field_key"))
    checkpoint_state = _derive_checkpoint_state(checkpoint_type=checkpoint_type, orchestration_status=status)
    checkpoint_id = _build_checkpoint_id(
        intake_session_id=intake_session_id,
        checkpoint_type=checkpoint_type,
        question_key=question_key,
    )
    now = _utcnow_iso()

    checkpoint_payload = {
        "current_question": current_question,
        "next_action": status.get("next_action") if isinstance(status.get("next_action"), dict) else {},
        "next_actions": status.get("next_actions") if isinstance(status.get("next_actions"), list) else [],
        "required_missing": status.get("required_missing") if isinstance(status.get("required_missing"), list) else [],
        "guided_session": status.get("guided_session") if isinstance(status.get("guided_session"), dict) else {},
        "workflow_checkpoint": status.get("checkpoint") if isinstance(status.get("checkpoint"), dict) else {},
        "question_progress": status.get("question_progress") if isinstance(status.get("question_progress"), dict) else {},
    }

    state: dict[str, Any] = {
        "stored": False,
        "channel": "none",
        "checkpoint_id": checkpoint_id,
        "checkpoint_type": checkpoint_type,
        "checkpoint_state": checkpoint_state,
        "intake_session_id": intake_session_id,
    }

    engine = _build_sqlalchemy_engine()
    if engine is not None:
        try:
            from sqlalchemy import text

            with engine.begin() as conn:
                conn.execute(
                    text(
                        """
                        CREATE TABLE IF NOT EXISTS flare_intake_checkpoint_state (
                            checkpoint_id TEXT PRIMARY KEY,
                            intake_session_id TEXT,
                            session_id TEXT,
                            trace_id TEXT,
                            checkpoint_type TEXT,
                            checkpoint_state TEXT,
                            current_stage TEXT,
                            question_key TEXT,
                            ready_for_submit BOOLEAN,
                            decision_point_active BOOLEAN,
                            payload_json TEXT,
                            created_at TEXT,
                            updated_at TEXT
                        )
                        """
                    )
                )
                conn.execute(
                    text(
                        """
                        INSERT INTO flare_intake_checkpoint_state (
                            checkpoint_id,
                            intake_session_id,
                            session_id,
                            trace_id,
                            checkpoint_type,
                            checkpoint_state,
                            current_stage,
                            question_key,
                            ready_for_submit,
                            decision_point_active,
                            payload_json,
                            created_at,
                            updated_at
                        ) VALUES (
                            :checkpoint_id,
                            :intake_session_id,
                            :session_id,
                            :trace_id,
                            :checkpoint_type,
                            :checkpoint_state,
                            :current_stage,
                            :question_key,
                            :ready_for_submit,
                            :decision_point_active,
                            :payload_json,
                            :created_at,
                            :updated_at
                        )
                        ON CONFLICT (checkpoint_id) DO UPDATE SET
                            intake_session_id = EXCLUDED.intake_session_id,
                            session_id = EXCLUDED.session_id,
                            trace_id = EXCLUDED.trace_id,
                            checkpoint_type = EXCLUDED.checkpoint_type,
                            checkpoint_state = EXCLUDED.checkpoint_state,
                            current_stage = EXCLUDED.current_stage,
                            question_key = EXCLUDED.question_key,
                            ready_for_submit = EXCLUDED.ready_for_submit,
                            decision_point_active = EXCLUDED.decision_point_active,
                            payload_json = EXCLUDED.payload_json,
                            updated_at = EXCLUDED.updated_at
                        """
                    ),
                    {
                        "checkpoint_id": checkpoint_id,
                        "intake_session_id": intake_session_id,
                        "session_id": _normalize_text(session_id),
                        "trace_id": _normalize_text(trace_id),
                        "checkpoint_type": checkpoint_type,
                        "checkpoint_state": checkpoint_state,
                        "current_stage": _normalize_text(status.get("current_stage")),
                        "question_key": question_key,
                        "ready_for_submit": bool(status.get("ready_for_submit")),
                        "decision_point_active": bool(status.get("decision_point_active")),
                        "payload_json": _safe_json_dumps(checkpoint_payload),
                        "created_at": now,
                        "updated_at": now,
                    },
                )
            state.update({"stored": True, "channel": "postgres"})
        except Exception as exc:
            logger.warning(
                "checkpoint.persist.postgres_failed trace_id=%s intake_session_id=%s checkpoint_id=%s error=%s",
                trace_id,
                intake_session_id,
                checkpoint_id,
                str(exc),
            )

    redis_client = _redis_client()
    if redis_client is not None:
        try:
            redis_key = f"flare:intake:checkpoint:{intake_session_id}"
            redis_client.hset(
                redis_key,
                mapping={
                    "checkpoint_id": checkpoint_id,
                    "session_id": _normalize_text(session_id),
                    "trace_id": _normalize_text(trace_id),
                    "checkpoint_type": checkpoint_type,
                    "checkpoint_state": checkpoint_state,
                    "current_stage": _normalize_text(status.get("current_stage")),
                    "question_key": question_key,
                    "ready_for_submit": "1" if bool(status.get("ready_for_submit")) else "0",
                    "decision_point_active": "1" if bool(status.get("decision_point_active")) else "0",
                    "payload_json": _safe_json_dumps(checkpoint_payload),
                    "updated_at": now,
                },
            )
            redis_client.expire(redis_key, 60 * 60 * 24 * 7)
            if not state["stored"]:
                state.update({"stored": True, "channel": "redis"})
        except Exception as exc:
            logger.warning(
                "checkpoint.persist.redis_failed trace_id=%s intake_session_id=%s checkpoint_id=%s error=%s",
                trace_id,
                intake_session_id,
                checkpoint_id,
                str(exc),
            )

    return state


def load_intake_checkpoint(*, intake_session_id: str) -> IntakeCheckpointSnapshot | None:
    safe_session_id = _normalize_text(intake_session_id)
    if not safe_session_id:
        return None

    engine = _build_sqlalchemy_engine()
    if engine is not None:
        try:
            from sqlalchemy import text

            with engine.connect() as conn:
                row = conn.execute(
                    text(
                        """
                        SELECT
                            checkpoint_id,
                            intake_session_id,
                            session_id,
                            trace_id,
                            checkpoint_type,
                            checkpoint_state,
                            current_stage,
                            question_key,
                            ready_for_submit,
                            decision_point_active,
                            payload_json,
                            updated_at
                        FROM flare_intake_checkpoint_state
                        WHERE intake_session_id = :intake_session_id
                        ORDER BY updated_at DESC
                        LIMIT 1
                        """
                    ),
                    {"intake_session_id": safe_session_id},
                ).mappings().first()
            if row:
                return IntakeCheckpointSnapshot(
                    checkpoint_id=_normalize_text(row.get("checkpoint_id")),
                    intake_session_id=_normalize_text(row.get("intake_session_id")),
                    session_id=_normalize_text(row.get("session_id")),
                    trace_id=_normalize_text(row.get("trace_id")),
                    checkpoint_type=_normalize_text(row.get("checkpoint_type")),
                    checkpoint_state=_normalize_text(row.get("checkpoint_state")),
                    current_stage=_normalize_text(row.get("current_stage")),
                    question_key=_normalize_text(row.get("question_key")),
                    ready_for_submit=bool(row.get("ready_for_submit")),
                    decision_point_active=bool(row.get("decision_point_active")),
                    updated_at=_normalize_text(row.get("updated_at")),
                    payload=_safe_json_loads(row.get("payload_json")),
                )
        except Exception:
            pass

    redis_client = _redis_client()
    if redis_client is None:
        return None

    try:
        mapping = redis_client.hgetall(f"flare:intake:checkpoint:{safe_session_id}") or {}
    except Exception:
        return None

    if not isinstance(mapping, dict) or not mapping:
        return None

    return IntakeCheckpointSnapshot(
        checkpoint_id=_normalize_text(mapping.get("checkpoint_id")),
        intake_session_id=safe_session_id,
        session_id=_normalize_text(mapping.get("session_id")),
        trace_id=_normalize_text(mapping.get("trace_id")),
        checkpoint_type=_normalize_text(mapping.get("checkpoint_type")),
        checkpoint_state=_normalize_text(mapping.get("checkpoint_state")),
        current_stage=_normalize_text(mapping.get("current_stage")),
        question_key=_normalize_text(mapping.get("question_key")),
        ready_for_submit=str(mapping.get("ready_for_submit") or "0").strip() in {"1", "true", "True"},
        decision_point_active=str(mapping.get("decision_point_active") or "0").strip() in {"1", "true", "True"},
        updated_at=_normalize_text(mapping.get("updated_at")),
        payload=_safe_json_loads(mapping.get("payload_json")),
    )
