"""Persistence helpers for authoritative intake session state."""

from __future__ import annotations

import json
import os
from datetime import UTC, datetime
from typing import Any

from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.session.models import IntakeSessionSnapshot

logger = get_logger("flare_kernel.runtime.session.intake_session_store")

_DEFAULT_POSTGRES_DSN = "postgresql://flare:flare@127.0.0.1:5432/flare"
_DEFAULT_REDIS_URL = "redis://127.0.0.1:6379/0"


def _env(name: str, default: str | None = None) -> str | None:
    raw = os.getenv(name)
    if raw is None:
        return default
    value = raw.strip()
    return value if value else default


def _utcnow_iso() -> str:
    return datetime.now(UTC).isoformat()


def _build_sqlalchemy_engine():
    try:
        from sqlalchemy import create_engine
    except Exception:
        return None

    dsn = _env("FLARE_POSTGRES_DSN", _DEFAULT_POSTGRES_DSN) or _DEFAULT_POSTGRES_DSN
    try:
        return create_engine(dsn, pool_pre_ping=True)
    except Exception:
        return None


def _redis_client():
    try:
        import redis
    except Exception:
        return None

    redis_url = _env("FLARE_REDIS_URL", _DEFAULT_REDIS_URL) or _DEFAULT_REDIS_URL
    return redis.Redis.from_url(redis_url, decode_responses=True)


def _normalize_text(value: Any) -> str:
    return str(value or "").strip()


def _safe_json_dumps(value: Any) -> str:
    try:
        return json.dumps(value if isinstance(value, dict) else {}, ensure_ascii=False)
    except Exception:
        return "{}"


def _safe_json_loads(value: Any) -> dict[str, Any]:
    if not isinstance(value, str) or not value.strip():
        return {}
    try:
        loaded = json.loads(value)
    except Exception:
        return {}
    return loaded if isinstance(loaded, dict) else {}


def persist_intake_session_state(
    *,
    trace_id: str,
    session_id: str,
    project_id: str | None,
    user_id: str | None,
    command: str,
    runtime_payload: dict[str, Any] | None,
    orchestration_status: dict[str, Any] | None,
) -> dict[str, Any]:
    payload = dict(runtime_payload) if isinstance(runtime_payload, dict) else {}
    status = dict(orchestration_status) if isinstance(orchestration_status, dict) else {}
    intake_session_id = _normalize_text(status.get("intake_session_id") or payload.get("intake_session_id"))
    if not intake_session_id:
        return {
            "stored": False,
            "reason": "missing_intake_session_id",
            "intake_session_id": "",
            "channel": "none",
        }

    intake_session_state = _normalize_text(status.get("intake_session_state") or payload.get("intake_session_state") or "started")
    intake_session_completed = bool(status.get("intake_session_completed") or payload.get("intake_session_completed"))
    current_stage = _normalize_text(status.get("current_stage"))
    payload_json = _safe_json_dumps(payload)
    status_json = _safe_json_dumps(status)
    now = _utcnow_iso()

    state: dict[str, Any] = {
        "stored": False,
        "channel": "none",
        "intake_session_id": intake_session_id,
        "intake_session_state": intake_session_state,
        "intake_session_completed": intake_session_completed,
    }

    engine = _build_sqlalchemy_engine()
    if engine is not None:
        try:
            from sqlalchemy import text

            with engine.begin() as conn:
                conn.execute(
                    text(
                        """
                        CREATE TABLE IF NOT EXISTS flare_intake_session_state (
                            intake_session_id TEXT PRIMARY KEY,
                            session_id TEXT,
                            project_id TEXT,
                            user_id TEXT,
                            trace_id TEXT,
                            intake_session_state TEXT,
                            intake_session_completed BOOLEAN,
                            current_stage TEXT,
                            last_command TEXT,
                            payload_json TEXT,
                            orchestration_status_json TEXT,
                            created_at TEXT,
                            updated_at TEXT
                        )
                        """
                    )
                )
                conn.execute(
                    text(
                        """
                        INSERT INTO flare_intake_session_state (
                            intake_session_id,
                            session_id,
                            project_id,
                            user_id,
                            trace_id,
                            intake_session_state,
                            intake_session_completed,
                            current_stage,
                            last_command,
                            payload_json,
                            orchestration_status_json,
                            created_at,
                            updated_at
                        ) VALUES (
                            :intake_session_id,
                            :session_id,
                            :project_id,
                            :user_id,
                            :trace_id,
                            :intake_session_state,
                            :intake_session_completed,
                            :current_stage,
                            :last_command,
                            :payload_json,
                            :orchestration_status_json,
                            :created_at,
                            :updated_at
                        )
                        ON CONFLICT (intake_session_id) DO UPDATE SET
                            session_id = EXCLUDED.session_id,
                            project_id = EXCLUDED.project_id,
                            user_id = EXCLUDED.user_id,
                            trace_id = EXCLUDED.trace_id,
                            intake_session_state = EXCLUDED.intake_session_state,
                            intake_session_completed = EXCLUDED.intake_session_completed,
                            current_stage = EXCLUDED.current_stage,
                            last_command = EXCLUDED.last_command,
                            payload_json = EXCLUDED.payload_json,
                            orchestration_status_json = EXCLUDED.orchestration_status_json,
                            updated_at = EXCLUDED.updated_at
                        """
                    ),
                    {
                        "intake_session_id": intake_session_id,
                        "session_id": _normalize_text(session_id),
                        "project_id": _normalize_text(project_id),
                        "user_id": _normalize_text(user_id),
                        "trace_id": _normalize_text(trace_id),
                        "intake_session_state": intake_session_state,
                        "intake_session_completed": intake_session_completed,
                        "current_stage": current_stage,
                        "last_command": _normalize_text(command),
                        "payload_json": payload_json,
                        "orchestration_status_json": status_json,
                        "created_at": now,
                        "updated_at": now,
                    },
                )
            state.update({"stored": True, "channel": "postgres"})
        except Exception as exc:
            logger.warning(
                "intake_session.persist.postgres_failed trace_id=%s intake_session_id=%s error=%s",
                trace_id,
                intake_session_id,
                str(exc),
            )

    redis_client = _redis_client()
    if redis_client is not None:
        try:
            redis_key = f"flare:intake:session:{intake_session_id}"
            redis_client.hset(
                redis_key,
                mapping={
                    "session_id": _normalize_text(session_id),
                    "project_id": _normalize_text(project_id),
                    "user_id": _normalize_text(user_id),
                    "trace_id": _normalize_text(trace_id),
                    "intake_session_state": intake_session_state,
                    "intake_session_completed": "1" if intake_session_completed else "0",
                    "current_stage": current_stage,
                    "last_command": _normalize_text(command),
                    "payload_json": payload_json,
                    "orchestration_status_json": status_json,
                    "updated_at": now,
                },
            )
            redis_client.expire(redis_key, 60 * 60 * 24 * 7)
            redis_client.set(f"flare:session:{_normalize_text(session_id)}:latest_intake", intake_session_id, ex=60 * 60 * 24 * 7)
            state["redis_key"] = redis_key
            if not state["stored"]:
                state.update({"stored": True, "channel": "redis"})
        except Exception as exc:
            logger.warning(
                "intake_session.persist.redis_failed trace_id=%s intake_session_id=%s error=%s",
                trace_id,
                intake_session_id,
                str(exc),
            )

    return state


def load_latest_intake_session_id(*, session_id: str) -> str:
    safe_session_id = _normalize_text(session_id)
    if not safe_session_id:
        return ""

    engine = _build_sqlalchemy_engine()
    if engine is not None:
        try:
            from sqlalchemy import text

            with engine.connect() as conn:
                row = conn.execute(
                    text(
                        """
                        SELECT intake_session_id
                        FROM flare_intake_session_state
                        WHERE session_id = :session_id
                        ORDER BY updated_at DESC
                        LIMIT 1
                        """
                    ),
                    {"session_id": safe_session_id},
                ).mappings().first()
            if row and _normalize_text(row.get("intake_session_id")):
                return _normalize_text(row.get("intake_session_id"))
        except Exception:
            pass

    redis_client = _redis_client()
    if redis_client is not None:
        try:
            cached = redis_client.get(f"flare:session:{safe_session_id}:latest_intake")
            return _normalize_text(cached)
        except Exception:
            return ""

    return ""


def load_intake_session_snapshot(
    *,
    intake_session_id: str = "",
    session_id: str = "",
) -> IntakeSessionSnapshot | None:
    target_session_id = _normalize_text(intake_session_id)
    fallback_session_id = _normalize_text(session_id)

    engine = _build_sqlalchemy_engine()
    if engine is not None:
        try:
            from sqlalchemy import text

            where_sql = "intake_session_id = :intake_session_id" if target_session_id else "session_id = :session_id"
            order_sql = "ORDER BY updated_at DESC LIMIT 1" if not target_session_id else "LIMIT 1"
            params = {
                "intake_session_id": target_session_id,
                "session_id": fallback_session_id,
            }
            with engine.connect() as conn:
                row = conn.execute(
                    text(
                        f"""
                        SELECT
                            intake_session_id,
                            session_id,
                            trace_id,
                            intake_session_state,
                            intake_session_completed,
                            current_stage,
                            last_command,
                            payload_json,
                            orchestration_status_json,
                            updated_at
                        FROM flare_intake_session_state
                        WHERE {where_sql}
                        {order_sql}
                        """
                    ),
                    params,
                ).mappings().first()
            if row:
                return IntakeSessionSnapshot(
                    intake_session_id=_normalize_text(row.get("intake_session_id")),
                    session_id=_normalize_text(row.get("session_id")),
                    trace_id=_normalize_text(row.get("trace_id")),
                    intake_session_state=_normalize_text(row.get("intake_session_state")),
                    intake_session_completed=bool(row.get("intake_session_completed")),
                    current_stage=_normalize_text(row.get("current_stage")),
                    last_command=_normalize_text(row.get("last_command")),
                    updated_at=_normalize_text(row.get("updated_at")),
                    payload=_safe_json_loads(row.get("payload_json")),
                    orchestration_status=_safe_json_loads(row.get("orchestration_status_json")),
                )
        except Exception:
            pass

    redis_session_id = target_session_id or load_latest_intake_session_id(session_id=fallback_session_id)
    if not redis_session_id:
        return None

    redis_client = _redis_client()
    if redis_client is None:
        return None
    try:
        mapping = redis_client.hgetall(f"flare:intake:session:{redis_session_id}") or {}
    except Exception:
        return None
    if not isinstance(mapping, dict) or not mapping:
        return None

    return IntakeSessionSnapshot(
        intake_session_id=redis_session_id,
        session_id=_normalize_text(mapping.get("session_id")),
        trace_id=_normalize_text(mapping.get("trace_id")),
        intake_session_state=_normalize_text(mapping.get("intake_session_state")),
        intake_session_completed=str(mapping.get("intake_session_completed") or "0").strip() in {"1", "true", "True"},
        current_stage=_normalize_text(mapping.get("current_stage")),
        last_command=_normalize_text(mapping.get("last_command")),
        updated_at=_normalize_text(mapping.get("updated_at")),
        payload=_safe_json_loads(mapping.get("payload_json")),
        orchestration_status=_safe_json_loads(mapping.get("orchestration_status_json")),
    )
