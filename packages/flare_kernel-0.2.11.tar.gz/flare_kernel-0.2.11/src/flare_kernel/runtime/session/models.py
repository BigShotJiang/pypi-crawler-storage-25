"""Data models for intake session persistence."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class IntakeSessionSnapshot:
    """Persisted intake session state snapshot."""

    intake_session_id: str
    session_id: str
    trace_id: str
    intake_session_state: str
    intake_session_completed: bool
    current_stage: str
    last_command: str
    updated_at: str
    payload: dict[str, Any]
    orchestration_status: dict[str, Any]


@dataclass(frozen=True)
class IntakeCheckpointSnapshot:
    """Persisted checkpoint snapshot for an intake session."""

    checkpoint_id: str
    intake_session_id: str
    session_id: str
    trace_id: str
    checkpoint_type: str
    checkpoint_state: str
    current_stage: str
    question_key: str
    ready_for_submit: bool
    decision_point_active: bool
    updated_at: str
    payload: dict[str, Any]
