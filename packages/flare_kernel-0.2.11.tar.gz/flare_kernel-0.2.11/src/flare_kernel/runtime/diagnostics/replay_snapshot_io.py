"""Replay snapshot JSON IO helpers."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


def load_replay_snapshot(path: str | Path) -> dict[str, Any]:
    """Load a replay snapshot JSON file."""

    value = json.loads(Path(path).read_text())
    return value if isinstance(value, dict) else {}


def write_replay_snapshot(path: str | Path, snapshot: dict[str, Any]) -> Path:
    """Write a replay snapshot JSON file and return the target path."""

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2, sort_keys=True))
    return target


def _safe_file_stem(value: Any) -> str:
    text = str(value or "").strip()
    safe = "".join(char if char.isalnum() or char in {"-", "_"} else "-" for char in text)
    return safe or "snapshot"


def write_replay_snapshot_if_enabled(snapshot: dict[str, Any], *, directory: str | Path | None = None) -> Path | None:
    """Write a replay snapshot only when an explicit diagnostics directory is configured."""

    target_dir = directory or os.getenv("FLARE_REPLAY_SNAPSHOT_DIR")
    if not target_dir:
        return None
    trace_id = snapshot.get("trace_id") if isinstance(snapshot, dict) else ""
    return write_replay_snapshot(Path(target_dir) / f"{_safe_file_stem(trace_id)}.json", snapshot)


__all__ = ["load_replay_snapshot", "write_replay_snapshot", "write_replay_snapshot_if_enabled"]
