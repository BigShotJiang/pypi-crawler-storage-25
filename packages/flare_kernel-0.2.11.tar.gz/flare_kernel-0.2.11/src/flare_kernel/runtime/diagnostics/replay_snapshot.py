"""Replay snapshot assembly helpers."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

_SCHEMA_VERSION = "replay.snapshot.v0"
_RUNTIME_KEYS = (
    "mode_runtime",
    "context_usage",
    "agent_runtime",
    "skill_runtime",
    "data_ingestion",
    "memory_runtime",
    "observation_runtime",
    "domain_pack",
    "degrade_reasons",
    "mode_key",
    "mode_state",
    "mode_events",
    "next_actions",
    "payload",
)


def _as_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _dump_model(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        dumped = value.model_dump()
        return dumped if isinstance(dumped, dict) else {}
    return _as_mapping(value)


def _request_projection(request: Any) -> dict[str, Any]:
    data = _dump_model(request)
    return {
        "contract_version": data.get("contract_version"),
        "tenant_id": data.get("tenant_id"),
        "instance_id": data.get("instance_id"),
        "domain_pack_version": data.get("domain_pack_version"),
        "session_id": data.get("session_id"),
        "intent": data.get("intent"),
        "intent_override": data.get("intent_override"),
        "mode": data.get("mode"),
        "manual_mode": data.get("manual_mode"),
        "current_mode": data.get("current_mode"),
        "command": data.get("command"),
        "action_key": data.get("action_key"),
        "target_mode": data.get("target_mode"),
        "payload": data.get("payload") if isinstance(data.get("payload"), dict) else {},
    }


def _response_projection(response: Any) -> dict[str, Any]:
    data = _dump_model(response)
    return {
        "state": data.get("state"),
        "events": data.get("events") if isinstance(data.get("events"), list) else [],
        "result": data.get("result") if isinstance(data.get("result"), dict) else {},
        "analysis_route": data.get("analysis_route"),
        "next_actions": data.get("next_actions") if isinstance(data.get("next_actions"), list) else [],
    }


def _provider_trace_from_response(response_projection: dict[str, Any]) -> dict[str, Any]:
    result = _as_mapping(response_projection.get("result"))
    direct = _as_mapping(result.get("provider_trace"))
    if direct:
        return direct
    observation = _as_mapping(result.get("observation_runtime"))
    return _as_mapping(observation.get("provider_trace"))


def _event_types(events: list[Any]) -> list[str]:
    return [str(item.get("event_type") or item.get("type") or "") for item in events if isinstance(item, dict)]


def _next_action_keys(actions: list[Any]) -> list[str]:
    return [str(item.get("action_key") or "") for item in actions if isinstance(item, dict)]


def _canvas_event_count(events: list[Any]) -> int:
    count = 0
    for item in events:
        if not isinstance(item, dict):
            continue
        event_type = str(item.get("event_type") or item.get("type") or "")
        render_hint = str(_as_mapping(item.get("payload")).get("render_hint") or "")
        if "canvas" in event_type or "canvas" in render_hint:
            count += 1
    return count


def _domain_pack_loaded(domain_pack: dict[str, Any]) -> bool:
    capabilities = _as_mapping(domain_pack.get("capabilities"))
    pack = _as_mapping(capabilities.get("pack"))
    return pack.get("enabled") is True


def _derived(runtime_snapshot: dict[str, Any], response_projection: dict[str, Any]) -> dict[str, Any]:
    payload = _as_mapping(runtime_snapshot.get("payload"))
    workflow_track = _as_mapping(payload.get("workflow_track"))
    mode_events = _as_list(runtime_snapshot.get("mode_events"))
    provider_trace = _provider_trace_from_response(response_projection)
    return {
        "runtime_payload_keys": sorted(payload.keys()),
        "mode_event_types": _event_types(mode_events),
        "next_action_keys": _next_action_keys(_as_list(runtime_snapshot.get("next_actions"))),
        "canvas_event_count": _canvas_event_count(mode_events),
        "domain_pack_loaded": _domain_pack_loaded(_as_mapping(runtime_snapshot.get("domain_pack"))),
        "degrade_reasons": _as_list(runtime_snapshot.get("degrade_reasons")),
        "track_key": workflow_track.get("track_key"),
        "goal_kind": workflow_track.get("goal_kind"),
        "provider_trace_backend": provider_trace.get("backend"),
        "provider_trace_status": provider_trace.get("status"),
    }


def _runtime_snapshot(runtime_snapshot: dict[str, Any]) -> dict[str, Any]:
    source = _as_mapping(runtime_snapshot)
    return {key: source.get(key, [] if key in {"mode_events", "next_actions", "degrade_reasons"} else {}) for key in _RUNTIME_KEYS}


def build_replay_snapshot(
    *,
    request: Any,
    runtime_snapshot: dict[str, Any],
    response: Any,
    stream_events: list[dict[str, Any]] | None = None,
    context_transition: dict[str, Any] | None = None,
    build: dict[str, Any] | None = None,
    notes: list[str] | None = None,
) -> dict[str, Any]:
    """Assemble a replay snapshot from existing runtime artifacts only."""

    request_projection = _request_projection(request)
    response_projection = _response_projection(response)
    runtime_projection = _runtime_snapshot(runtime_snapshot)
    response_data = _dump_model(response)
    return {
        "schema_version": _SCHEMA_VERSION,
        "trace_id": response_data.get("trace_id") or _dump_model(request).get("trace_id") or "",
        "session_id": request_projection.get("session_id") or "",
        "created_at": datetime.now(UTC).isoformat(),
        "build": build or {},
        "request": request_projection,
        "runtime_snapshot": runtime_projection,
        "response": response_projection,
        "stream_events": list(stream_events or []),
        "context_transition": context_transition or {"before": None, "patch": None, "after": None, "source": "not_available"},
        "derived": _derived(runtime_projection, response_projection),
        "assertions": [],
        "notes": list(notes or []),
    }


__all__ = ["build_replay_snapshot"]
