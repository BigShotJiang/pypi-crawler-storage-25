"""Provider audit JSON export helpers."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from flare_kernel.runtime.diagnostics.provider_audit import summarize_provider_audit

_SCHEMA_VERSION = "provider.audit.export.v0"


def build_provider_audit_export(records: list[dict[str, Any]], *, scope: dict[str, Any] | None = None) -> dict[str, Any]:
    return {
        "schema_version": _SCHEMA_VERSION,
        "generated_at": datetime.now(UTC).isoformat(),
        "scope": scope or {},
        "summary": summarize_provider_audit(records),
    }


def write_provider_audit_export(
    path: str | Path,
    records: list[dict[str, Any]],
    *,
    scope: dict[str, Any] | None = None,
) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = build_provider_audit_export(records, scope=scope)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
    return target


__all__ = ["build_provider_audit_export", "write_provider_audit_export"]
