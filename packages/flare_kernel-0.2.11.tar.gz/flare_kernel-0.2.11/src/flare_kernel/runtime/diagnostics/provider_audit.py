"""Provider trace audit summary helpers."""

from __future__ import annotations

from typing import Any

_SCHEMA_VERSION = "provider.audit.v0"


def _as_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _trace_items(record: dict[str, Any]) -> list[dict[str, Any]]:
    direct = record.get("provider_trace")
    if isinstance(direct, dict):
        return [direct]
    if isinstance(direct, list):
        return [item for item in direct if isinstance(item, dict)]

    result = _as_mapping(record.get("result"))
    result_trace = result.get("provider_trace")
    if isinstance(result_trace, dict):
        return [result_trace]
    if isinstance(result_trace, list):
        return [item for item in result_trace if isinstance(item, dict)]

    response = _as_mapping(record.get("response"))
    return _trace_items(response) if response else []


def _counter_entry(items: dict[str, int], key: Any) -> None:
    text = str(key or "unknown")
    items[text] = items.get(text, 0) + 1


def _number(value: Any) -> float:
    if isinstance(value, bool):
        return 0.0
    if isinstance(value, int | float):
        return float(value)
    return 0.0


def summarize_provider_audit(records: list[dict[str, Any]]) -> dict[str, Any]:
    """Summarize existing provider trace records without calling providers."""

    backend_counts: dict[str, int] = {}
    provider_counts: dict[str, int] = {}
    status_counts: dict[str, int] = {}
    model_counts: dict[str, int] = {}
    latency_ms_total = 0.0
    estimated_tokens_total = 0.0
    trace_count = 0

    for record in records:
        if not isinstance(record, dict):
            continue
        for trace in _trace_items(record):
            trace_count += 1
            _counter_entry(backend_counts, trace.get("backend"))
            _counter_entry(provider_counts, trace.get("provider") or trace.get("source"))
            _counter_entry(status_counts, trace.get("status"))
            _counter_entry(model_counts, trace.get("model") or trace.get("selected_model"))
            latency_ms_total += _number(trace.get("latency_ms"))
            usage = _as_mapping(trace.get("usage_estimate"))
            estimated_tokens_total += _number(usage.get("total_tokens"))

    return {
        "schema_version": _SCHEMA_VERSION,
        "record_count": len(records),
        "trace_count": trace_count,
        "by_backend": backend_counts,
        "by_provider": provider_counts,
        "by_status": status_counts,
        "by_model": model_counts,
        "latency_ms_total": int(latency_ms_total),
        "estimated_tokens_total": int(estimated_tokens_total),
    }


__all__ = ["summarize_provider_audit"]
