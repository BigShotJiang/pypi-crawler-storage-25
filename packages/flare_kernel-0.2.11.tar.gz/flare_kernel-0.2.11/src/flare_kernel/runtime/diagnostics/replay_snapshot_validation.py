"""Replay snapshot validation helpers."""

from __future__ import annotations

from typing import Any

_STABLE_PATHS = (
    "request.contract_version",
    "request.intent",
    "request.mode",
    "request.manual_mode",
    "request.current_mode",
    "request.command",
    "request.action_key",
    "request.target_mode",
    "runtime_snapshot.mode_key",
    "runtime_snapshot.mode_state",
    "runtime_snapshot.degrade_reasons",
    "derived.runtime_payload_keys",
    "derived.mode_event_types",
    "derived.next_action_keys",
    "derived.domain_pack_loaded",
    "derived.track_key",
    "derived.goal_kind",
)


def _as_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _value_at_path(snapshot: dict[str, Any], path: str) -> Any:
    value: Any = snapshot
    for segment in path.split("."):
        if not isinstance(value, dict):
            return None
        value = value.get(segment)
    return value


def build_replay_assertion(*, source_path: str, expected: Any, actual: Any) -> dict[str, Any]:
    return {
        "assertion_key": source_path.replace(".", "_"),
        "source_path": source_path,
        "expected": expected,
        "actual": actual,
        "passed": expected == actual,
    }


def validate_replay_snapshot(
    *,
    actual: dict[str, Any],
    golden: dict[str, Any],
    stable_paths: tuple[str, ...] = _STABLE_PATHS,
) -> list[dict[str, Any]]:
    """Compare actual replay snapshot against golden stable source paths."""

    actual_snapshot = _as_mapping(actual)
    golden_snapshot = _as_mapping(golden)
    return [
        build_replay_assertion(
            source_path=path,
            expected=_value_at_path(golden_snapshot, path),
            actual=_value_at_path(actual_snapshot, path),
        )
        for path in stable_paths
    ]


def replay_validation_passed(assertions: list[dict[str, Any]]) -> bool:
    return all(item.get("passed") is True for item in assertions if isinstance(item, dict))


__all__ = ["build_replay_assertion", "replay_validation_passed", "validate_replay_snapshot"]
