"""Helpers for loading external domain-pack assets."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.domain.profile_resolution import (
    InMemoryResolutionTraceEmitter,
    PassThroughProfileMergeValidator,
    PayloadProfileSourceResolver,
    PayloadTenantBindingResolver,
    PayloadTenantOverrideResolver,
    ResolutionContext,
    ResolutionTraceEntry,
)
from flare_kernel.runtime.domain.domain_pack_paths import (
    DEFAULT_PACK_VARIANT as _DEFAULT_PACK_VARIANT,
    resolve_domain_pack_dir,
)

logger = get_logger("flare_kernel.runtime.domain.domain_pack_loader")

_DOMAIN_PACK_ROOT_ENV = "FLARE_DOMAIN_PACK_ROOT"
_DEFAULT_DOMAIN_ENV = "FLARE_DOMAIN_PACK_DEFAULT_DOMAIN"
_INSTANCE_PROFILE_FILE = "branding/instance-branding.json"
_DEFAULT_DOMAIN = "generic"


@dataclass(frozen=True)
class WorkflowConfig:
    raw: dict[str, Any]


@dataclass(frozen=True)
class FieldPolicy:
    key: str
    label: str
    priority: str
    blocker: bool


@dataclass(frozen=True)
class SearchMapping:
    raw: dict[str, Any]


@dataclass(frozen=True)
class ReplaceRuleSet:
    raw: dict[str, Any]


@dataclass(frozen=True)
class DomainPack:
    domain: str
    version: str
    root: str
    taxonomy: dict[str, Any] | None
    fields: dict[str, Any] | None
    workflow: WorkflowConfig | None
    search_mapping: SearchMapping | None
    replace_rules: ReplaceRuleSet | None
    templates: dict[str, Any]
    capabilities: dict[str, dict[str, Any]]
    degrade_reasons: tuple[str, ...]
    resolution_trace: tuple[dict[str, Any], ...] = ()

    @property
    def is_missing(self) -> bool:
        return bool(self.capabilities.get("pack", {}).get("missing"))

    def _field_definitions(self) -> list[dict[str, Any]]:
        if not isinstance(self.fields, dict):
            return []
        raw_defs = self.fields.get("field_definitions")
        if isinstance(raw_defs, list):
            return [item for item in raw_defs if isinstance(item, dict) and str(item.get("key") or "").strip()]

        raw_fields = self.fields.get("fields")
        if not isinstance(raw_fields, dict):
            return []

        definitions: list[dict[str, Any]] = []
        for key, value in raw_fields.items():
            field_key = str(key or "").strip()
            if not field_key:
                continue
            node = value if isinstance(value, dict) else {}
            definitions.append(
                {
                    "key": field_key,
                    "label": str(node.get("label") or field_key),
                    "priority": str(node.get("priority") or "optional"),
                    "question": str(node.get("question") or "").strip(),
                    "options": node.get("options") if isinstance(node.get("options"), list) else [],
                    "blocker": bool(node.get("blocker", str(node.get("priority") or "") == "required")),
                }
            )
        return definitions

    def required_fields(self) -> list[str]:
        if isinstance(self.fields, dict):
            explicit = self.fields.get("required_fields")
            if isinstance(explicit, list):
                return [str(item).strip() for item in explicit if str(item).strip()]
        required: list[str] = []
        for definition in self._field_definitions():
            if str(definition.get("priority") or "").strip() == "required":
                required.append(str(definition.get("key") or "").strip())
        return required

    def field_policies(self) -> tuple[FieldPolicy, ...]:
        policies: list[FieldPolicy] = []
        for definition in self._field_definitions():
            key = str(definition.get("key") or "").strip()
            if not key:
                continue
            priority = str(definition.get("priority") or "optional").strip() or "optional"
            policies.append(
                FieldPolicy(
                    key=key,
                    label=str(definition.get("label") or key).strip() or key,
                    priority=priority,
                    blocker=bool(definition.get("blocker", priority == "required")),
                )
            )
        return tuple(policies)

    def blocker_policies(self) -> dict[str, Any]:
        workflow_raw = self.workflow.raw if isinstance(self.workflow, WorkflowConfig) else {}
        blocker = workflow_raw.get("blocker_policies") if isinstance(workflow_raw.get("blocker_policies"), dict) else {}
        if blocker:
            normalized = dict(blocker)
            raw_required = blocker.get("required_fields")
            if isinstance(raw_required, list):
                normalized["required_fields"] = [str(item).strip() for item in raw_required if str(item).strip()]
            return normalized

        required = [policy.key for policy in self.field_policies() if policy.blocker]
        return {"required_fields": required, "chooser_on_blocking": True}

    def field_policy_map(self) -> dict[str, dict[str, Any]]:
        mapped: dict[str, dict[str, Any]] = {}
        for policy in self.field_policies():
            mapped[policy.key] = {
                "key": policy.key,
                "label": policy.label,
                "priority": policy.priority,
                "blocker": policy.blocker,
            }
        return mapped

    def to_dict(self) -> dict[str, Any]:
        return {
            "domain": self.domain,
            "version": self.version,
            "root": self.root,
            "taxonomy": self.taxonomy or {},
            "fields": self.fields or {},
            "workflow": self.workflow.raw if isinstance(self.workflow, WorkflowConfig) else {},
            "search_mapping": self.search_mapping.raw if isinstance(self.search_mapping, SearchMapping) else {},
            "replace_rules": self.replace_rules.raw if isinstance(self.replace_rules, ReplaceRuleSet) else {},
            "templates": dict(self.templates),
            "capabilities": self.capabilities,
            "degrade_reasons": list(self.degrade_reasons),
            "resolution_trace": [dict(item) for item in self.resolution_trace if isinstance(item, dict)],
            "field_policies": self.field_policy_map(),
            "blocker_policies": self.blocker_policies(),
        }


def _resolve_from_env() -> Path | None:
    env_path = os.getenv(_DOMAIN_PACK_ROOT_ENV)
    if not env_path:
        return None

    root = Path(env_path).expanduser().resolve()
    if not root.exists():
        logger.warning("domain_pack.root_not_found env=%s path=%s", _DOMAIN_PACK_ROOT_ENV, str(root))
        return None
    return root


def resolve_domain_pack_root(instance_id: str) -> Path | None:
    del instance_id
    return _resolve_from_env()


def resolve_default_domain() -> str:
    raw = os.getenv(_DEFAULT_DOMAIN_ENV)
    if isinstance(raw, str):
        value = raw.strip()
        if value:
            return value
    return _DEFAULT_DOMAIN


def resolve_domain_pack_domain(
    *,
    payload: dict[str, Any] | None = None,
    instance_profile: dict[str, Any] | None = None,
    fallback_domain: str | None = None,
) -> str:
    payload_mapping = payload if isinstance(payload, dict) else {}
    profile_mapping = instance_profile if isinstance(instance_profile, dict) else {}
    candidates = (
        payload_mapping.get("domain_pack_domain"),
        payload_mapping.get("domain"),
        profile_mapping.get("domain_pack_domain"),
        profile_mapping.get("domain"),
        fallback_domain,
        resolve_default_domain(),
    )
    for candidate in candidates:
        if isinstance(candidate, str):
            value = candidate.strip()
            if value:
                return value
    return _DEFAULT_DOMAIN


def _parse_scalar(raw_value: str) -> Any:
    value = raw_value.strip()
    if not value:
        return ""

    if value.startswith(("'", '"')) and value.endswith(("'", '"')) and len(value) >= 2:
        return value[1:-1]

    lowered = value.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered == "null":
        return None

    try:
        return int(value)
    except ValueError:
        pass

    try:
        return float(value)
    except ValueError:
        return value


def _load_simple_yaml_text(text: str, *, source_path: Path) -> dict[str, Any]:
    lines = text.splitlines()
    parsed: dict[str, Any] = {}
    index = 0

    while index < len(lines):
        raw_line = lines[index].rstrip()
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            index += 1
            continue

        indent = len(raw_line) - len(raw_line.lstrip(" "))
        if indent != 0 or ":" not in stripped:
            index += 1
            continue

        key, raw_value = stripped.split(":", 1)
        key = key.strip()
        value = raw_value.strip()

        if not value:
            index += 1
            entries: list[Any] = []
            mapping: dict[str, Any] = {}
            while index < len(lines):
                nested_line = lines[index].rstrip()
                nested_stripped = nested_line.strip()
                if not nested_stripped or nested_stripped.startswith("#"):
                    index += 1
                    continue
                nested_indent = len(nested_line) - len(nested_line.lstrip(" "))
                if nested_indent < 2:
                    break

                if nested_stripped.startswith("- "):
                    entries.append(_parse_scalar(nested_stripped[2:]))
                    index += 1
                    continue

                if ":" in nested_stripped:
                    nested_key, nested_value = nested_stripped.split(":", 1)
                    mapping[nested_key.strip()] = _parse_scalar(nested_value)
                index += 1

            if entries:
                parsed[key] = entries
            elif mapping:
                parsed[key] = mapping
            else:
                parsed[key] = {}
            continue

        parsed[key] = _parse_scalar(value)
        index += 1

    parsed["_source_path"] = str(source_path)
    return parsed


def _read_structured_file(path: Path) -> dict[str, Any] | list[Any] | None:
    if not path.exists() or not path.is_file():
        return None

    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        logger.warning("domain_pack.read_failed file=%s", str(path))
        return None

    stripped = text.strip()
    if not stripped:
        return {}

    try:
        parsed_json = json.loads(stripped)
        if isinstance(parsed_json, (dict, list)):
            return parsed_json
    except json.JSONDecodeError:
        pass

    try:
        import yaml  # type: ignore

        parsed_yaml = yaml.safe_load(stripped)
        if isinstance(parsed_yaml, (dict, list)):
            return parsed_yaml
    except Exception:
        pass

    try:
        parsed_simple = _load_simple_yaml_text(stripped, source_path=path)
        if isinstance(parsed_simple, dict):
            return parsed_simple
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("domain_pack.parse_failed file=%s error=%s", str(path), str(exc))
    return None


def _read_templates(templates_root: Path) -> dict[str, Any]:
    if not templates_root.exists() or not templates_root.is_dir():
        return {}

    templates: dict[str, Any] = {}
    for path in sorted(templates_root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(templates_root).as_posix()
        suffix = path.suffix.lower()
        if suffix in {".yaml", ".yml", ".json"}:
            parsed = _read_structured_file(path)
            if parsed is not None:
                templates[rel] = parsed
                continue
        try:
            templates[rel] = path.read_text(encoding="utf-8")
        except OSError:
            logger.warning("domain_pack.read_failed file=%s", str(path))
    return templates


def _new_capability(enabled: bool, *, reason: str = "", missing: bool = False) -> dict[str, Any]:
    payload = {"enabled": bool(enabled), "missing": bool(missing)}
    if reason:
        payload["reason"] = reason
    return payload


def _build_missing_pack(domain: str, variant: str, root: Path | None, *, reason: str) -> DomainPack:
    capabilities = {
        "pack": _new_capability(False, reason=reason, missing=True),
        "taxonomy": _new_capability(False, reason="pack_missing", missing=True),
        "fields": _new_capability(False, reason="pack_missing", missing=True),
        "workflow": _new_capability(False, reason="pack_missing", missing=True),
        "search_mapping": _new_capability(False, reason="pack_missing", missing=True),
        "replace_rules": _new_capability(False, reason="pack_missing", missing=True),
        "templates": _new_capability(False, reason="pack_missing", missing=True),
    }
    return DomainPack(
        domain=domain,
        version=variant,
        root=str(root) if isinstance(root, Path) else "",
        taxonomy=None,
        fields=None,
        workflow=None,
        search_mapping=None,
        replace_rules=None,
        templates={},
        capabilities=capabilities,
        degrade_reasons=("pack_missing",),
        resolution_trace=(),
    )


@lru_cache(maxsize=32)
def _load_domain_pack_cached(root_path: str, domain: str, domain_pack_variant: str) -> DomainPack:
    root = Path(root_path)
    pack_root = resolve_domain_pack_dir(root, domain, domain_pack_variant)
    if pack_root is None:
        logger.warning("domain_pack.not_found domain=%s variant=%s root=%s", domain, domain_pack_variant, str(root / domain))
        return _build_missing_pack(domain, domain_pack_variant, root, reason="pack_not_found")

    taxonomy_raw = _read_structured_file(pack_root / "taxonomy.yaml")
    fields_raw = _read_structured_file(pack_root / "fields.yaml")
    workflow_raw = _read_structured_file(pack_root / "workflow.yaml")
    search_mapping_raw = _read_structured_file(pack_root / "search-mapping.yaml")
    replace_rules_raw = _read_structured_file(pack_root / "replace-rules.yaml")
    templates = _read_templates(pack_root / "templates")

    taxonomy = taxonomy_raw if isinstance(taxonomy_raw, dict) else None
    fields = fields_raw if isinstance(fields_raw, dict) else None
    workflow = WorkflowConfig(raw=workflow_raw) if isinstance(workflow_raw, dict) else None
    search_mapping = SearchMapping(raw=search_mapping_raw) if isinstance(search_mapping_raw, dict) else None
    replace_rules = ReplaceRuleSet(raw=replace_rules_raw) if isinstance(replace_rules_raw, dict) else None

    degrade_reasons: list[str] = []
    capabilities: dict[str, dict[str, Any]] = {
        "pack": _new_capability(True),
        "taxonomy": _new_capability(taxonomy is not None, reason="taxonomy_missing", missing=taxonomy is None),
        "fields": _new_capability(fields is not None, reason="fields_missing", missing=fields is None),
        "workflow": _new_capability(workflow is not None, reason="workflow_missing", missing=workflow is None),
        "search_mapping": _new_capability(search_mapping is not None, reason="retrieval_mapping_missing", missing=search_mapping is None),
        "replace_rules": _new_capability(replace_rules is not None, reason="replace_rules_missing", missing=replace_rules is None),
        "templates": _new_capability(len(templates) > 0, reason="templates_missing", missing=len(templates) == 0),
    }

    for module, capability in capabilities.items():
        if module == "pack":
            continue
        if not capability.get("enabled"):
            degrade_reasons.append(str(capability.get("reason") or f"{module}_missing"))

    if isinstance(fields, dict):
        required_fields = fields.get("required_fields")
        field_definitions = fields.get("field_definitions")
        defined_keys: set[str] = set()
        if isinstance(field_definitions, list):
            for item in field_definitions:
                if not isinstance(item, dict):
                    continue
                key = str(item.get("key") or "").strip()
                if key:
                    defined_keys.add(key)
        if isinstance(required_fields, list):
            for field in required_fields:
                field_key = str(field or "").strip()
                if field_key and field_key not in defined_keys:
                    degrade_reasons.append(f"field_policy_missing:{field_key}")

    return DomainPack(
        domain=domain,
        version=domain_pack_variant,
        root=str(pack_root),
        taxonomy=taxonomy,
        fields=fields,
        workflow=workflow,
        search_mapping=search_mapping,
        replace_rules=replace_rules,
        templates=templates,
        capabilities=capabilities,
        degrade_reasons=tuple(dict.fromkeys(degrade_reasons)),
        resolution_trace=(),
    )


def _with_resolution_trace(
    pack: DomainPack,
    *,
    instance_id: str,
    domain_pack_version: str,
    payload: dict[str, Any] | None,
    instance_profile: dict[str, Any] | None,
    tenant_id: str,
) -> DomainPack:
    trace = InMemoryResolutionTraceEmitter()
    context = ResolutionContext(
        instance_id=instance_id,
        domain=pack.domain,
        domain_pack_version=domain_pack_version,
        tenant_id=tenant_id,
        payload=payload if isinstance(payload, dict) else {},
        instance_profile=instance_profile if isinstance(instance_profile, dict) else {},
    )

    trace.emit(
        ResolutionTraceEntry(
            layer="core_default",
            source=pack.root or "domain_pack_loader",
            hit=not pack.is_missing,
            details="pack_missing" if pack.is_missing else "",
        )
    )

    product_resolver = PayloadProfileSourceResolver()
    tenant_override_resolver = PayloadTenantOverrideResolver()
    tenant_binding_resolver = PayloadTenantBindingResolver()
    validator = PassThroughProfileMergeValidator()

    product_profile = product_resolver.resolve_product_profile(context)
    trace.emit(
        ResolutionTraceEntry(
            layer="product_profile",
            source="payload_or_instance_profile",
            hit=isinstance(product_profile, dict) and len(product_profile) > 0,
            details="" if product_profile else "layer_missing:product_profile",
        )
    )
    tenant_override = tenant_override_resolver.resolve_tenant_override(context)
    trace.emit(
        ResolutionTraceEntry(
            layer="tenant_override",
            source="payload_or_instance_profile",
            hit=isinstance(tenant_override, dict) and len(tenant_override) > 0,
            details="" if tenant_override else "layer_missing:tenant_override",
        )
    )
    tenant_binding = tenant_binding_resolver.resolve_tenant_binding(context)
    trace.emit(
        ResolutionTraceEntry(
            layer="tenant_binding",
            source="payload_or_instance_profile",
            hit=isinstance(tenant_binding, dict) and len(tenant_binding) > 0,
            details="" if tenant_binding else "layer_missing:tenant_binding",
        )
    )
    _validated_layers, validation_reasons = validator.validate(
        {
            "core_default": pack.to_dict(),
            "product_profile": product_profile or {},
            "tenant_override": tenant_override or {},
            "tenant_binding": tenant_binding or {},
        }
    )
    for reason in validation_reasons:
        trace.emit(
            ResolutionTraceEntry(
                layer="validator",
                source="profile_merge_validator",
                hit=False,
                details=str(reason),
            )
        )

    if pack.resolution_trace:
        merged_trace = tuple(dict(item) for item in pack.resolution_trace if isinstance(item, dict)) + trace.snapshot()
    else:
        merged_trace = trace.snapshot()

    return DomainPack(
        domain=pack.domain,
        version=pack.version,
        root=pack.root,
        taxonomy=pack.taxonomy,
        fields=pack.fields,
        workflow=pack.workflow,
        search_mapping=pack.search_mapping,
        replace_rules=pack.replace_rules,
        templates=pack.templates,
        capabilities=pack.capabilities,
        degrade_reasons=pack.degrade_reasons,
        resolution_trace=merged_trace,
    )


def load_domain_pack(
    *,
    instance_id: str,
    domain_pack_version: str,
    domain: str | None = None,
    payload: dict[str, Any] | None = None,
    instance_profile: dict[str, Any] | None = None,
    tenant_id: str = "",
) -> DomainPack:
    normalized_domain = str(domain or "").strip() or resolve_default_domain()
    root = resolve_domain_pack_root("")
    if root is None:
        missing_pack = _build_missing_pack(normalized_domain, domain_pack_version, None, reason="root_not_configured")
        return _with_resolution_trace(
            missing_pack,
            instance_id=instance_id,
            domain_pack_version=domain_pack_version,
            payload=payload,
            instance_profile=instance_profile,
            tenant_id=tenant_id,
        )
    pack = _load_domain_pack_cached(str(root), normalized_domain, domain_pack_version)
    return _with_resolution_trace(
        pack,
        instance_id=instance_id,
        domain_pack_version=domain_pack_version,
        payload=payload,
        instance_profile=instance_profile,
        tenant_id=tenant_id,
    )


def load_requirement_schema(instance_id: str) -> dict[str, Any] | None:
    """Compatibility shim for legacy callers.

    Returns requirement-field schema from the resolved default domain pack when available.
    """

    pack = load_domain_pack(
        instance_id=instance_id,
        domain_pack_version=_DEFAULT_PACK_VARIANT,
        domain=resolve_default_domain(),
    )
    if not isinstance(pack.fields, dict):
        return None
    schema = dict(pack.fields)
    schema["root"] = pack.root
    schema["schema_path"] = str(Path(pack.root) / "fields.yaml")
    return schema


@lru_cache(maxsize=8)
def load_instance_profile(instance_id: str) -> dict[str, Any] | None:
    root = resolve_domain_pack_root(instance_id)
    if root is None:
        return None

    profile_path = root / _INSTANCE_PROFILE_FILE
    if not profile_path.exists():
        return None

    try:
        data = json.loads(profile_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        logger.warning("domain_pack.invalid_json file=%s", str(profile_path))
        return None
    except OSError:
        logger.warning("domain_pack.read_failed file=%s", str(profile_path))
        return None

    if not isinstance(data, dict):
        logger.warning("domain_pack.invalid_profile file=%s", str(profile_path))
        return None
    return data
