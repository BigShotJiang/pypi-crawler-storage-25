"""Profile resolution interfaces and default no-op implementations.

These interfaces provide a neutral, layered resolution pipeline without
changing existing runtime behavior. Current implementations are intentionally
minimal and compatibility-first.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol


@dataclass(frozen=True)
class ResolutionContext:
    instance_id: str
    domain: str
    domain_pack_version: str
    tenant_id: str = ""
    payload: dict[str, Any] | None = None
    instance_profile: dict[str, Any] | None = None


@dataclass(frozen=True)
class ResolutionTraceEntry:
    layer: str
    source: str
    hit: bool
    details: str = ""

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "layer": self.layer,
            "source": self.source,
            "hit": self.hit,
        }
        if self.details:
            payload["details"] = self.details
        return payload


class ProfileSourceResolver(Protocol):
    def resolve_product_profile(self, context: ResolutionContext) -> dict[str, Any] | None: ...


class TenantOverrideResolver(Protocol):
    def resolve_tenant_override(self, context: ResolutionContext) -> dict[str, Any] | None: ...


class TenantBindingResolver(Protocol):
    def resolve_tenant_binding(self, context: ResolutionContext) -> dict[str, Any] | None: ...


class ProfileMergeValidator(Protocol):
    def validate(self, profile_layers: dict[str, Any]) -> tuple[dict[str, Any], tuple[str, ...]]: ...


class ResolutionTraceEmitter(Protocol):
    def emit(self, entry: ResolutionTraceEntry) -> None: ...
    def snapshot(self) -> tuple[dict[str, Any], ...]: ...


class PayloadProfileSourceResolver:
    """Resolve optional product profile layer from payload/profile hints."""

    def resolve_product_profile(self, context: ResolutionContext) -> dict[str, Any] | None:
        payload = context.payload if isinstance(context.payload, dict) else {}
        profile = context.instance_profile if isinstance(context.instance_profile, dict) else {}
        candidate = payload.get("product_profile")
        if isinstance(candidate, dict):
            return dict(candidate)
        candidate = profile.get("product_profile")
        if isinstance(candidate, dict):
            return dict(candidate)
        return None


class PayloadTenantOverrideResolver:
    """Resolve tenant override layer from payload/profile hints."""

    def resolve_tenant_override(self, context: ResolutionContext) -> dict[str, Any] | None:
        payload = context.payload if isinstance(context.payload, dict) else {}
        profile = context.instance_profile if isinstance(context.instance_profile, dict) else {}
        candidate = payload.get("tenant_override")
        if isinstance(candidate, dict):
            return dict(candidate)
        candidate = profile.get("tenant_override")
        if isinstance(candidate, dict):
            return dict(candidate)
        return None


class PayloadTenantBindingResolver:
    """Resolve tenant private binding refs from payload/profile hints."""

    def resolve_tenant_binding(self, context: ResolutionContext) -> dict[str, Any] | None:
        payload = context.payload if isinstance(context.payload, dict) else {}
        profile = context.instance_profile if isinstance(context.instance_profile, dict) else {}
        candidate = payload.get("tenant_binding")
        if isinstance(candidate, dict):
            return dict(candidate)
        candidate = profile.get("tenant_binding")
        if isinstance(candidate, dict):
            return dict(candidate)
        return None


class PassThroughProfileMergeValidator:
    """Compatibility-first validator: keep current behavior, report no errors."""

    def validate(self, profile_layers: dict[str, Any]) -> tuple[dict[str, Any], tuple[str, ...]]:
        return dict(profile_layers), ()


class InMemoryResolutionTraceEmitter:
    """Collect layer-resolution trace entries for runtime observation."""

    def __init__(self) -> None:
        self._entries: list[dict[str, Any]] = []

    def emit(self, entry: ResolutionTraceEntry) -> None:
        self._entries.append(entry.to_dict())

    def snapshot(self) -> tuple[dict[str, Any], ...]:
        return tuple(dict(item) for item in self._entries if isinstance(item, dict))

