"""Domain-pack filesystem path resolution."""

from __future__ import annotations

from pathlib import Path

DEFAULT_PACK_VARIANT = "default"
_PACK_MODULE_FILENAMES = (
    "taxonomy.yaml",
    "fields.yaml",
    "workflow.yaml",
    "search-mapping.yaml",
    "replace-rules.yaml",
)


def is_domain_pack_dir(path: Path) -> bool:
    if not path.exists() or not path.is_dir():
        return False
    if (path / "templates").is_dir():
        return True
    return any((path / filename).is_file() for filename in _PACK_MODULE_FILENAMES)


def resolve_domain_pack_dir(root: Path, domain: str, domain_pack_variant: str) -> Path | None:
    domain_root = root / domain
    if is_domain_pack_dir(domain_root):
        return domain_root
    variant = str(domain_pack_variant or "").strip()
    if not variant:
        return None
    variant_root = domain_root / variant
    if is_domain_pack_dir(variant_root):
        return variant_root
    return None


__all__ = ["DEFAULT_PACK_VARIANT", "is_domain_pack_dir", "resolve_domain_pack_dir"]
