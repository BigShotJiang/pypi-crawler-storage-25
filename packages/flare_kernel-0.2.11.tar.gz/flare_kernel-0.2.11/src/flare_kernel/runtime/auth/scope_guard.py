"""Pure route-scope authorization helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts.auth_contract import AuthContext, AuthorizationDecision


def _text(value: Any) -> str:
    return str(value or "").strip()


def _principal_user_id(auth_context: AuthContext | None) -> str:
    return _text(auth_context.principal.user_id if auth_context else "")


def _decision(
    *,
    allowed: bool,
    reason: str,
    reason_code: str,
    required_fields: list[str] | None = None,
    allowed_scopes: list[str] | None = None,
    denied_scopes: list[str] | None = None,
) -> AuthorizationDecision:
    return AuthorizationDecision(
        allowed=allowed,
        reason=reason,
        reason_codes=[reason_code],
        allowed_scopes=list(allowed_scopes or []),
        denied_scopes=list(denied_scopes or []),
        required_context_fields=list(required_fields or []),
    )


def _deny_missing_auth_context() -> AuthorizationDecision:
    return _decision(
        allowed=False,
        reason="auth context is required",
        reason_code="missing_auth_context",
    )


def _deny_missing_scope(scopes: list[str]) -> AuthorizationDecision:
    return _decision(
        allowed=False,
        reason="required route scope is not allowed",
        reason_code="route_scope_not_allowed",
        required_fields=["scopes"],
        denied_scopes=scopes,
    )


def _deny_scope_mismatch(field_name: str) -> AuthorizationDecision:
    return _decision(
        allowed=False,
        reason=f"{field_name} is outside authorized scope",
        reason_code=f"{field_name}_scope_mismatch",
        required_fields=[field_name],
    )


def _has_scope(auth_context: AuthContext, required_scope: str) -> bool:
    scopes = {_text(scope) for scope in auth_context.scopes if _text(scope)}
    return required_scope in scopes


def _matches_context_value(auth_value: str, target_value: str, field_name: str) -> AuthorizationDecision | None:
    if not auth_value or not target_value:
        return None
    if auth_value and auth_value == target_value:
        return None
    return _deny_scope_mismatch(field_name)


def evaluate_route_scope(
    auth_context: AuthContext | None,
    *,
    required_scopes: list[str] | tuple[str, ...] = (),
    project_id: str = "",
    session_id: str = "",
    user_id: str = "",
) -> AuthorizationDecision:
    if auth_context is None:
        return _deny_missing_auth_context()

    required = [_text(scope) for scope in required_scopes if _text(scope)]
    missing_scopes = [scope for scope in required if not _has_scope(auth_context, scope)]
    if missing_scopes:
        return _deny_missing_scope(missing_scopes)

    checks = [
        (_text(auth_context.project_id), _text(project_id), "project_id"),
        (_text(auth_context.session_id), _text(session_id), "session_id"),
        (_principal_user_id(auth_context), _text(user_id), "user_id"),
    ]
    for auth_value, target_value, field_name in checks:
        denied = _matches_context_value(auth_value, target_value, field_name)
        if denied is not None:
            return denied

    return _decision(
        allowed=True,
        reason="route scope allowed",
        reason_code="route_scope_allowed",
        allowed_scopes=required,
    )


def filter_records_for_auth_context(
    records: list[dict[str, Any]],
    auth_context: AuthContext | None,
) -> list[dict[str, Any]]:
    if auth_context is None:
        return list(records)

    project_id = _text(auth_context.project_id)
    session_id = _text(auth_context.session_id)
    user_id = _principal_user_id(auth_context)

    def visible(record: dict[str, Any]) -> bool:
        record_project_id = _text(record.get("project_id"))
        record_session_id = _text(record.get("session_id"))
        record_user_id = _text(record.get("user_id"))
        return (
            (not project_id or record_project_id == project_id)
            and (not session_id or record_session_id == session_id)
            and (not user_id or not record_user_id or record_user_id == user_id)
        )

    return [record for record in records if visible(record)]


def _normalize_field_path(path: str) -> str:
    cleaned = _text(path).lstrip("/")
    return ".".join(part.strip() for part in cleaned.replace("/", ".").split(".") if part.strip())


def _field_path_allowed(path: str, allowed_field_paths: list[str] | tuple[str, ...]) -> bool:
    normalized = _normalize_field_path(path)
    allowed = {_normalize_field_path(item) for item in allowed_field_paths}
    if "*" in allowed:
        return True
    return bool(normalized) and any(normalized == item or normalized.startswith(f"{item}.") for item in allowed if item)


def _get_nested_value(payload: dict[str, Any], path: str) -> tuple[bool, Any]:
    current: Any = payload
    for part in _normalize_field_path(path).split("."):
        if not isinstance(current, dict) or part not in current:
            return False, None
        current = current[part]
    return True, current


def _set_nested_value(payload: dict[str, Any], path: str, value: Any) -> None:
    parts = _normalize_field_path(path).split(".")
    current = payload
    for part in parts[:-1]:
        next_value = current.get(part)
        if not isinstance(next_value, dict):
            next_value = {}
            current[part] = next_value
        current = next_value
    if parts:
        current[parts[-1]] = value


def filter_payload_fields(
    payload: dict[str, Any],
    allowed_field_paths: list[str] | tuple[str, ...],
) -> dict[str, Any]:
    if _field_path_allowed("*", allowed_field_paths):
        return dict(payload)

    filtered: dict[str, Any] = {}
    for field_path in allowed_field_paths:
        found, value = _get_nested_value(payload, field_path)
        if found:
            _set_nested_value(filtered, field_path, value)
    return filtered


def filter_patch_operations(
    patch_operations: list[dict[str, Any]],
    allowed_field_paths: list[str] | tuple[str, ...],
    *,
    path_key: str = "path",
) -> list[dict[str, Any]]:
    return [
        dict(operation)
        for operation in patch_operations
        if _field_path_allowed(_text(operation.get(path_key)), allowed_field_paths)
    ]


def resolve_guarded_filter_value(requested_value: str, auth_value: str) -> str:
    return _text(requested_value) or _text(auth_value)
