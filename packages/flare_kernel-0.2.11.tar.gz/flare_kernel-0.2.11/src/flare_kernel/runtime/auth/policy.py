"""Pure authorization policy helpers."""

from __future__ import annotations

from dataclasses import dataclass, field

from flare_kernel.contracts.auth_contract import AuthExchangeRequest, AuthorizationDecision


@dataclass(frozen=True, slots=True)
class AuthExchangePolicy:
    allowed_providers: frozenset[str] = field(default_factory=frozenset)
    allowed_subjects: frozenset[str] = field(default_factory=frozenset)
    allowed_scopes: frozenset[str] = field(default_factory=frozenset)
    expected_secret: str = ""
    require_user_id: bool = False


def _clean_set(values: frozenset[str]) -> set[str]:
    return {str(item).strip() for item in values if str(item).strip()}


def _deny(reason: str, reason_code: str, fields: list[str]) -> AuthorizationDecision:
    return AuthorizationDecision(
        allowed=False,
        reason=reason,
        reason_codes=[reason_code],
        required_context_fields=fields,
    )


def _deny_scopes(denied_scopes: list[str]) -> AuthorizationDecision:
    return AuthorizationDecision(
        allowed=False,
        reason="requested scope is not allowed",
        reason_codes=["scope_not_allowed"],
        denied_scopes=denied_scopes,
        required_context_fields=["scopes"],
    )


def evaluate_auth_exchange(
    req: AuthExchangeRequest,
    policy: AuthExchangePolicy,
    provided_secret: str = "",
) -> AuthorizationDecision:
    provider = req.provider.strip()
    subject = req.external_subject.strip()
    requested_scopes = [scope for scope in req.scopes if str(scope).strip()]
    allowed_providers = _clean_set(policy.allowed_providers)
    allowed_subjects = _clean_set(policy.allowed_subjects)
    allowed_scope_set = _clean_set(policy.allowed_scopes)

    if not provider:
        return _deny("provider is required", "missing_provider", ["provider"])
    if not subject:
        return _deny("external_subject is required", "missing_external_subject", ["external_subject"])
    if policy.require_user_id and not str(req.user_id or "").strip():
        return _deny("user_id is required", "missing_user_id", ["user_id"])
    if policy.expected_secret and provided_secret != policy.expected_secret:
        return _deny("exchange secret is invalid", "invalid_exchange_secret", [])
    if allowed_providers and provider not in allowed_providers:
        return _deny("provider is not allowed", "provider_not_allowed", ["provider"])
    if allowed_subjects and subject not in allowed_subjects:
        return _deny("external_subject is not allowed", "subject_not_allowed", ["external_subject"])
    denied_scopes = [scope for scope in requested_scopes if allowed_scope_set and scope not in allowed_scope_set]
    if denied_scopes:
        return _deny_scopes(denied_scopes)

    return AuthorizationDecision(
        allowed=True,
        reason="auth exchange allowed",
        reason_codes=["auth_exchange_allowed"],
        allowed_scopes=requested_scopes,
    )
