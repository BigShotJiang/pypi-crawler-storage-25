"""Auth exchange orchestration without provider-specific identity logic."""

from __future__ import annotations

import json
import os
from typing import Any

from flare_kernel.contracts.auth_contract import AuthContext, AuthExchangeRequest, AuthExchangeResponse, AuthPrincipal
from flare_kernel.runtime.auth.policy import AuthExchangePolicy, evaluate_auth_exchange


def _env_value(name: str) -> str:
    return os.getenv(name, "").strip()


def _string_list_from_env(name: str) -> frozenset[str]:
    raw = _env_value(name)
    if not raw:
        return frozenset()
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        parsed = [part.strip() for part in raw.split(",")]
    if not isinstance(parsed, list):
        return frozenset()
    return frozenset(str(item).strip() for item in parsed if str(item).strip())


def load_auth_exchange_policy() -> AuthExchangePolicy:
    return AuthExchangePolicy(
        allowed_providers=_string_list_from_env("FLARE_AUTH_ALLOWED_PROVIDERS"),
        allowed_subjects=_string_list_from_env("FLARE_AUTH_ALLOWED_SUBJECTS"),
        allowed_scopes=_string_list_from_env("FLARE_AUTH_ALLOWED_SCOPES"),
        expected_secret=_env_value("FLARE_AUTH_EXCHANGE_SECRET"),
        require_user_id=_env_value("FLARE_AUTH_REQUIRE_USER_ID") == "1",
    )


def _clean_claims(claims: dict[str, Any]) -> dict[str, Any]:
    return dict(claims or {})


def exchange_auth_context(
    req: AuthExchangeRequest,
    *,
    provided_secret: str = "",
    policy: AuthExchangePolicy | None = None,
) -> AuthExchangeResponse:
    resolved_policy = policy or load_auth_exchange_policy()
    decision = evaluate_auth_exchange(req, resolved_policy, provided_secret=provided_secret)
    principal = AuthPrincipal(
        provider=req.provider.strip(),
        external_subject=req.external_subject.strip(),
        user_id=str(req.user_id).strip() if req.user_id is not None else None,
        tenant_id=req.tenant_id.strip() or "default",
        instance_id=req.instance_id.strip() or "default",
        display_name=req.display_name,
    )
    context = AuthContext(
        principal=principal,
        project_id=req.project_id,
        session_id=req.session_id,
        scopes=list(decision.allowed_scopes),
        claims=_clean_claims(req.claims),
    )
    return AuthExchangeResponse(auth_context=context, authorization=decision)
