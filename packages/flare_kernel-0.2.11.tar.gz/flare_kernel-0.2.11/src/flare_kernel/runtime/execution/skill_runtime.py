"""Placeholder skill runtime helpers for the kernel."""

from __future__ import annotations

from typing import Any

_SKILL_CALLS_BY_MODE = {
    "requirement_intake": [
        {
            "skill_id": "mode_routing",
            "agent_id": "intent_router_agent",
            "status": "planned",
            "permission_scope": "read_only",
            "side_effect": "none",
            "reason": "route the request into the active mode",
        },
        {
            "skill_id": "requirement_field_capture",
            "agent_id": "requirement_collector_agent",
            "status": "planned",
            "permission_scope": "read_only",
            "side_effect": "none",
            "reason": "capture the current requirement fields",
        },
        {
            "skill_id": "knowledge_injection",
            "agent_id": "knowledge_injector_agent",
            "status": "planned",
            "permission_scope": "read_only",
            "side_effect": "none",
            "reason": "inject supporting knowledge when needed",
        },
    ],
    "intelligent_sourcing": [
        {
            "skill_id": "mode_routing",
            "agent_id": "intent_router_agent",
            "status": "planned",
            "permission_scope": "read_only",
            "side_effect": "none",
            "reason": "route the request into the active mode",
        },
        {
            "skill_id": "candidate_matching",
            "agent_id": "sourcing_matcher_agent",
            "status": "planned",
            "permission_scope": "read_only",
            "side_effect": "none",
            "reason": "produce a candidate set from the current context",
        },
        {
            "skill_id": "risk_summary",
            "agent_id": "risk_summarizer_agent",
            "status": "planned",
            "permission_scope": "read_only",
            "side_effect": "none",
            "reason": "summarize sourcing risks for the candidate set",
        },
        {
            "skill_id": "report_building",
            "agent_id": "report_builder_agent",
            "status": "planned",
            "permission_scope": "read_only",
            "side_effect": "none",
            "reason": "assemble a structured sourcing report",
        },
    ],
    "unknown": [
        {
            "skill_id": "mode_routing",
            "agent_id": "intent_router_agent",
            "status": "planned",
            "permission_scope": "read_only",
            "side_effect": "none",
            "reason": "hold the request until a mode can be inferred",
        }
    ],
}


def _skill_calls_for_mode(mode_key: str) -> list[dict[str, Any]]:
    return [dict(skill_call, call_index=index) for index, skill_call in enumerate(_SKILL_CALLS_BY_MODE.get(mode_key, _SKILL_CALLS_BY_MODE["unknown"]))]


def build_skill_runtime(
    *,
    trace_id: str,
    session_id: str,
    intent: str,
    function_type: str | None,
    mode_runtime: dict[str, str],
) -> dict[str, Any]:
    mode_key = mode_runtime.get("mode_key", "unknown")
    mode_state = mode_runtime.get("mode_state", "unknown")
    skill_call = _skill_calls_for_mode(mode_key)
    return {
        "trace_id": trace_id,
        "session_id": session_id,
        "intent": intent,
        "function_type": function_type,
        "mode_key": mode_key,
        "mode_state": mode_state,
        "skill_call": skill_call,
        "skill_call_count": len(skill_call),
    }
