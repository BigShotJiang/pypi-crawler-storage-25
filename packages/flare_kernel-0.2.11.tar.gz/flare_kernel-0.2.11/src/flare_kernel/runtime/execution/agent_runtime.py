"""Placeholder agent runtime helpers for the kernel."""

from __future__ import annotations

from typing import Any

_AGENT_STEPS_BY_MODE = {
    "requirement_intake": [
        {
            "step_id": "intent_router",
            "agent_id": "intent_router_agent",
            "role": "route_intent",
            "mode_scope": "all",
            "status": "planned",
            "handoff_rule": "route the request into the selected mode",
            "allowed_skills": ["mode_routing"],
        },
        {
            "step_id": "requirement_collect",
            "agent_id": "requirement_collector_agent",
            "role": "collect_requirements",
            "mode_scope": "requirement_intake",
            "status": "planned",
            "handoff_rule": "move to knowledge injection after fields are collected",
            "allowed_skills": ["requirement_field_capture"],
        },
        {
            "step_id": "knowledge_inject",
            "agent_id": "knowledge_injector_agent",
            "role": "inject_knowledge",
            "mode_scope": "requirement_intake",
            "status": "planned",
            "handoff_rule": "handoff to the next mode step once context is aligned",
            "allowed_skills": ["knowledge_injection"],
        },
    ],
    "intelligent_sourcing": [
        {
            "step_id": "intent_router",
            "agent_id": "intent_router_agent",
            "role": "route_intent",
            "mode_scope": "all",
            "status": "planned",
            "handoff_rule": "route the request into the selected mode",
            "allowed_skills": ["mode_routing"],
        },
        {
            "step_id": "sourcing_match",
            "agent_id": "sourcing_matcher_agent",
            "role": "match_candidates",
            "mode_scope": "intelligent_sourcing",
            "status": "planned",
            "handoff_rule": "hand off to risk summarization after candidates are matched",
            "allowed_skills": ["candidate_matching"],
        },
        {
            "step_id": "risk_summary",
            "agent_id": "risk_summarizer_agent",
            "role": "summarize_risk",
            "mode_scope": "intelligent_sourcing",
            "status": "planned",
            "handoff_rule": "handoff to report building after risks are summarized",
            "allowed_skills": ["risk_summary"],
        },
        {
            "step_id": "report_build",
            "agent_id": "report_builder_agent",
            "role": "build_report",
            "mode_scope": "intelligent_sourcing",
            "status": "planned",
            "handoff_rule": "complete the mode after the report is assembled",
            "allowed_skills": ["report_building"],
        },
    ],
    "unknown": [
        {
            "step_id": "intent_router",
            "agent_id": "intent_router_agent",
            "role": "route_intent",
            "mode_scope": "unknown",
            "status": "planned",
            "handoff_rule": "hold the request until a mode can be inferred",
            "allowed_skills": ["mode_routing"],
        }
    ],
}


def _agent_steps_for_mode(mode_key: str) -> list[dict[str, Any]]:
    return [dict(step, step_index=index) for index, step in enumerate(_AGENT_STEPS_BY_MODE.get(mode_key, _AGENT_STEPS_BY_MODE["unknown"]))]


def build_agent_runtime(
    *,
    trace_id: str,
    session_id: str,
    intent: str,
    function_type: str | None,
    mode_runtime: dict[str, str],
) -> dict[str, Any]:
    mode_key = mode_runtime.get("mode_key", "unknown")
    mode_state = mode_runtime.get("mode_state", "unknown")
    agent_step = _agent_steps_for_mode(mode_key)
    return {
        "trace_id": trace_id,
        "session_id": session_id,
        "intent": intent,
        "function_type": function_type,
        "mode_key": mode_key,
        "mode_state": mode_state,
        "agent_step": agent_step,
        "agent_step_count": len(agent_step),
    }
