"""Intent and escalation classifier capability for kernel orchestration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from flare_kernel.runtime.intent.intent_and_escalation.decision import project_intent_and_escalation_result
from flare_kernel.runtime.intent.intent_and_escalation.signals import build_intent_and_escalation_signals

_DOMAIN_TO_LEGACY_INTENT_TYPE = {
    "domain_analysis": "procurement_analysis",
    "domain_consultation_qa": "procurement_consultation_qa",
    "domain_requirement_intake": "procurement_requirement_intake",
}


@dataclass(frozen=True)
class IntentEscalationContext:
    message: str
    command: str
    resolved_intent: str
    resolved_mode: str
    mode_source: str
    required_fields: tuple[str, ...]
    required_missing: tuple[str, ...]
    known_fields: tuple[str, ...]
    has_current_question: bool
    intake_session_id: str
    analysis_ready_hint: bool
    intent_lexicon: dict[str, Any] | None = None


@dataclass(frozen=True)
class IntentEscalationResult:
    intent_type: str
    conversation_intent_state: str
    procurement_relevance: bool
    consultative_procurement_qa: bool
    escalation_target: str
    explicit_intake_request: bool
    intake_candidate: bool
    clarification_recommended: bool
    analysis_ready: bool
    draft_seeded: bool
    missing_key_fields: tuple[str, ...]
    recommended_next_step: str
    confidence: float
    reason: str

    def to_dict(self) -> dict[str, Any]:
        intent_type_domain = str(self.intent_type or "").strip() or "qa_only"
        intent_type_legacy = _DOMAIN_TO_LEGACY_INTENT_TYPE.get(intent_type_domain, intent_type_domain)
        return {
            "intent_type": intent_type_legacy,
            "intent_type_domain": intent_type_domain,
            "conversation_intent_state": self.conversation_intent_state,
            "session_intent_stage": self.conversation_intent_state,
            "procurement_relevance": self.procurement_relevance,
            "domain_relevance": self.procurement_relevance,
            "consultative_procurement_qa": self.consultative_procurement_qa,
            "consultative_domain_qa": self.consultative_procurement_qa,
            "escalation_target": self.escalation_target,
            "explicit_intake_request": self.explicit_intake_request,
            "intake_candidate": self.intake_candidate,
            "clarification_recommended": self.clarification_recommended,
            "analysis_ready": self.analysis_ready,
            "draft_seeded": self.draft_seeded,
            "missing_key_fields": [item for item in self.missing_key_fields if str(item).strip()],
            "recommended_next_step": self.recommended_next_step,
            "confidence": max(0.0, min(1.0, float(self.confidence))),
            "reason": self.reason,
        }


def classify_intent_and_escalation(context: IntentEscalationContext) -> IntentEscalationResult:
    signals = build_intent_and_escalation_signals(context)
    return project_intent_and_escalation_result(
        context=context,
        signals=signals,
        result_cls=IntentEscalationResult,
    )
