"""Decision projection for intent and escalation classification.

This module turns computed signals into the public result object. It does not
mutate context or re-derive vocabulary / preprocessing state.
"""

from __future__ import annotations

from typing import Any


def project_intent_and_escalation_result(
    *,
    context: Any,
    signals: dict[str, Any],
    result_cls: type[Any],
) -> Any:
    has_explicit_intake_request = bool(signals["has_explicit_intake_request"])
    has_intake_structuring_terms = bool(signals["has_intake_structuring_terms"])
    has_intake_purchase_terms = bool(signals["has_intake_purchase_terms"])
    has_intake_entity_terms = bool(signals["has_intake_entity_terms"])
    domain_relevance = bool(signals.get("domain_relevance", signals["procurement_relevance"]))
    consultative_domain_qa = bool(signals.get("consultative_domain_qa", signals["consultative_procurement_qa"]))
    analysis_ready = bool(signals["analysis_ready"])
    analysis_running = bool(signals["analysis_running"])
    intake_candidate = bool(signals["intake_candidate"])
    clarification_recommended = bool(signals["clarification_recommended"])
    clarification_in_progress = bool(signals["clarification_in_progress"])
    draft_seeded = bool(signals["draft_seeded"])
    required_missing = tuple(signals["required_missing"])
    has_current_question = bool(getattr(context, "has_current_question", False))
    intake_session_id = str(getattr(context, "intake_session_id", "") or "").strip()
    resolved_mode = str(signals["resolved_mode"])
    command = str(signals["command"])
    mode_source = str(signals["mode_source"])

    if signals["small_talk_message"] and not domain_relevance:
        intent_type = "small_talk"
        conversation_intent_state = "small_talk"
        escalation_target = "qa_only"
        recommended_next_step = "continue_qa"
        confidence = 0.95
        reason = "识别为闲聊/寒暄，保持基础对话。"
    elif not domain_relevance:
        intent_type = "qa_only"
        conversation_intent_state = "general_qa"
        escalation_target = "qa_only"
        recommended_next_step = "continue_qa"
        confidence = 0.92
        reason = "未识别到领域梳理相关语义，保持普通问答。"
    elif analysis_running:
        intent_type = "domain_analysis"
        conversation_intent_state = "analysis_running"
        escalation_target = "analysis_ready"
        recommended_next_step = "start_analysis"
        confidence = 0.92
        reason = "已进入分析执行阶段。"
    elif analysis_ready:
        intent_type = "domain_analysis"
        conversation_intent_state = "analysis_ready"
        escalation_target = "analysis_ready"
        recommended_next_step = "start_analysis"
        confidence = 0.9
        reason = "关键字段已具备，满足进入分析条件。"
    elif clarification_in_progress:
        intent_type = (
            "domain_consultation_qa" if consultative_domain_qa else "domain_requirement_intake"
        )
        conversation_intent_state = "clarification_in_progress"
        escalation_target = "clarification_recommended" if clarification_recommended else "intake_candidate"
        recommended_next_step = "continue_clarification"
        confidence = 0.88
        if has_explicit_intake_request:
            reason = "识别到明确梳理请求，建议直接开启梳理模式。"
        elif has_intake_structuring_terms or has_intake_purchase_terms or has_intake_entity_terms:
            reason = "识别到领域与梳理信号，建议继续收口关键字段。"
        else:
            reason = "已进入需求澄清过程，建议继续补齐关键字段。"
    elif intake_candidate or draft_seeded:
        intent_type = (
            "domain_consultation_qa" if consultative_domain_qa else "domain_requirement_intake"
        )
        conversation_intent_state = "business_intake_candidate"
        escalation_target = "intake_candidate" if intake_candidate else "draft_seeded"
        recommended_next_step = "start_intake" if intake_candidate else "continue_intake"
        confidence = 0.82 if intake_candidate else 0.8
        if has_explicit_intake_request:
            reason = "识别到明确梳理请求，建议直接开启梳理模式。"
        elif has_intake_structuring_terms or has_intake_purchase_terms or has_intake_entity_terms:
            reason = "识别到领域与梳理信号，建议进入需求梳理。"
        else:
            reason = "识别到领域意图，建议进入需求梳理。" if intake_candidate else "已存在梳理上下文，继续沿用需求草稿。"
    else:
        intent_type = "qa_only"
        conversation_intent_state = "general_qa"
        escalation_target = "qa_only"
        recommended_next_step = "continue_qa"
        confidence = 0.7
        reason = "当前信息不足以触发升级。"

    return result_cls(
        intent_type=intent_type,
        conversation_intent_state=conversation_intent_state,
        procurement_relevance=domain_relevance,
        consultative_procurement_qa=consultative_domain_qa,
        escalation_target=escalation_target,
        explicit_intake_request=has_explicit_intake_request,
        intake_candidate=intake_candidate,
        clarification_recommended=clarification_recommended,
        analysis_ready=analysis_ready,
        draft_seeded=draft_seeded,
        missing_key_fields=required_missing,
        recommended_next_step=recommended_next_step,
        confidence=confidence,
        reason=reason,
    )
