"""Intent and escalation classifier helper package.

This package holds the internal lexicon, preprocessing, signal extraction,
and decision projection helpers for intent and escalation classification. It
does not define public runtime entry points.
"""

