"""Preprocessing helpers for intent and escalation classification.

This module normalizes caller-supplied context and performs lightweight text
checks only. It does not own vocabulary policy or decision logic.
"""

from __future__ import annotations


def normalize_list(items: tuple[str, ...] | list[str] | None) -> tuple[str, ...]:
    if not items:
        return ()
    normalized: list[str] = []
    seen: set[str] = set()
    for item in items:
        text = str(item or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        normalized.append(text)
    return tuple(normalized)


def contains_any(text: str, terms: tuple[str, ...]) -> bool:
    return any(term in text for term in terms)


def is_small_talk_message(
    text: str,
    *,
    has_question_terms: bool,
    action_terms: tuple[str, ...],
    entity_terms: tuple[str, ...],
    small_talk_question_terms: tuple[str, ...],
    small_talk_terms: tuple[str, ...],
) -> bool:
    normalized = str(text or "").strip()
    if not normalized:
        return False
    if contains_any(normalized, action_terms):
        return False
    if contains_any(normalized, entity_terms):
        return False
    if has_question_terms and not contains_any(normalized, small_talk_question_terms):
        return False
    return contains_any(normalized, small_talk_terms)

