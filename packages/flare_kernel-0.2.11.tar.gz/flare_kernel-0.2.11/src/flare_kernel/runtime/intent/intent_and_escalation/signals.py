"""Signal extraction for intent and escalation classification.

This module converts normalized context and lexicon inputs into derived
signals. It does not decide the final intent state or escalation target.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.intent.intent_and_escalation.lexicon import (
    INTAKE_ENTITY_TERMS,
    INTAKE_EXPLICIT_PHRASES,
    INTAKE_PURCHASE_TERMS,
    INTAKE_STRUCTURING_TERMS,
    PROCUREMENT_ACTION_TERMS,
    PROCUREMENT_ENTITY_TERMS,
    QUESTION_TERMS,
    SMALL_TALK_QUESTION_TERMS,
    SMALL_TALK_TERMS,
    resolve_terms,
)
from flare_kernel.runtime.intent.intent_and_escalation.preprocessing import (
    contains_any,
    is_small_talk_message,
    normalize_list,
)


def build_intent_and_escalation_signals(context: Any) -> dict[str, Any]:
    message = str(getattr(context, "message", "") or "").strip().lower()
    command = str(getattr(context, "command", "") or "").strip()
    resolved_intent = str(getattr(context, "resolved_intent", "") or "").strip()
    resolved_mode = str(getattr(context, "resolved_mode", "") or "").strip()
    mode_source = str(getattr(context, "mode_source", "") or "").strip()

    required_fields = normalize_list(getattr(context, "required_fields", None))
    known_fields = normalize_list(getattr(context, "known_fields", None))
    required_missing = normalize_list(getattr(context, "required_missing", None))
    if not required_missing and required_fields:
        required_missing = tuple(item for item in required_fields if item not in set(known_fields))

    action_terms = resolve_terms(
        lexicon=getattr(context, "intent_lexicon", None),
        key="action_terms",
        legacy_terms=PROCUREMENT_ACTION_TERMS,
    )
    entity_terms = resolve_terms(
        lexicon=getattr(context, "intent_lexicon", None),
        key="entity_terms",
        legacy_terms=PROCUREMENT_ENTITY_TERMS,
    )
    intake_purchase_terms = resolve_terms(
        lexicon=getattr(context, "intent_lexicon", None),
        key="intake_purchase_terms",
        legacy_terms=INTAKE_PURCHASE_TERMS,
    )
    intake_entity_terms = resolve_terms(
        lexicon=getattr(context, "intent_lexicon", None),
        key="intake_entity_terms",
        legacy_terms=INTAKE_ENTITY_TERMS,
    )

    mode_or_intent_domain = (
        resolved_intent in {"requirement_intake", "intelligent_sourcing"}
        or resolved_mode in {"requirement_intake", "intelligent_sourcing"}
    )
    has_explicit_intake_request = contains_any(message, INTAKE_EXPLICIT_PHRASES)
    has_intake_structuring_terms = contains_any(message, INTAKE_STRUCTURING_TERMS)
    has_intake_purchase_terms = contains_any(message, intake_purchase_terms)
    has_intake_entity_terms = contains_any(message, intake_entity_terms)
    has_action_terms = contains_any(message, action_terms)
    has_entity_terms = contains_any(message, entity_terms)
    has_question_terms = contains_any(message, QUESTION_TERMS)
    small_talk_message = is_small_talk_message(
        message,
        has_question_terms=has_question_terms,
        action_terms=action_terms,
        entity_terms=entity_terms,
        small_talk_question_terms=SMALL_TALK_QUESTION_TERMS,
        small_talk_terms=SMALL_TALK_TERMS,
    )

    domain_relevance = bool(
        mode_or_intent_domain
        or has_action_terms
        or has_explicit_intake_request
        or has_intake_structuring_terms
        or has_intake_purchase_terms
        or has_intake_entity_terms
        or (has_entity_terms and (has_question_terms or len(known_fields) > 0))
        or command in {"activate_requirement_intake", "submit_intake_answer", "generate_analysis"}
    )
    if (
        command == "send_message"
        and small_talk_message
        and not has_action_terms
        and not has_entity_terms
    ):
        domain_relevance = False

    consultative_domain_qa = bool(
        domain_relevance
        and has_question_terms
        and (
            has_action_terms
            or has_explicit_intake_request
            or has_intake_structuring_terms
            or command == "send_message"
            or mode_source in {"fallback", "intent_and_escalation_classifier"}
        )
    )

    analysis_ready = bool(
        domain_relevance
        and (
            bool(getattr(context, "analysis_ready_hint", False))
            or (len(required_fields) > 0 and len(required_missing) == 0)
        )
    )
    analysis_running = bool(domain_relevance and command == "generate_analysis")
    intake_candidate = bool(domain_relevance and not analysis_ready)
    clarification_recommended = bool(intake_candidate and len(required_missing) > 0)
    clarification_in_progress = bool(
        domain_relevance
        and not analysis_ready
        and (
            bool(getattr(context, "has_current_question", False))
            or clarification_recommended
            or bool(str(getattr(context, "intake_session_id", "") or "").strip())
        )
    )
    draft_seeded = bool(
        domain_relevance
        and (
            bool(str(getattr(context, "intake_session_id", "") or "").strip())
            or resolved_mode == "requirement_intake"
            or command in {"activate_requirement_intake", "submit_intake_answer", "generate_analysis"}
        )
    )

    return {
        "message": message,
        "command": command,
        "resolved_intent": resolved_intent,
        "resolved_mode": resolved_mode,
        "mode_source": mode_source,
        "required_fields": required_fields,
        "known_fields": known_fields,
        "required_missing": required_missing,
        "action_terms": action_terms,
        "entity_terms": entity_terms,
        "intake_purchase_terms": intake_purchase_terms,
        "intake_entity_terms": intake_entity_terms,
        "has_explicit_intake_request": has_explicit_intake_request,
        "has_intake_structuring_terms": has_intake_structuring_terms,
        "has_intake_purchase_terms": has_intake_purchase_terms,
        "has_intake_entity_terms": has_intake_entity_terms,
        "has_action_terms": has_action_terms,
        "has_entity_terms": has_entity_terms,
        "has_question_terms": has_question_terms,
        "small_talk_message": small_talk_message,
        "domain_relevance": domain_relevance,
        "consultative_domain_qa": consultative_domain_qa,
        "procurement_relevance": domain_relevance,
        "consultative_procurement_qa": consultative_domain_qa,
        "analysis_ready": analysis_ready,
        "analysis_running": analysis_running,
        "intake_candidate": intake_candidate,
        "clarification_recommended": clarification_recommended,
        "clarification_in_progress": clarification_in_progress,
        "draft_seeded": draft_seeded,
    }
