"""Lexicon and compatibility toggles for intent and escalation classification.

This module owns the static vocabularies and legacy compatibility switch only.
It does not inspect request state, compute signals, or choose outcomes.
"""

from __future__ import annotations

from typing import Any

PROCUREMENT_ACTION_TERMS: tuple[str, ...] = ()

PROCUREMENT_ENTITY_TERMS: tuple[str, ...] = ()

QUESTION_TERMS = (
    "?",
    "？",
    "怎么",
    "如何",
    "请问",
    "建议",
    "推荐",
    "是否",
    "哪些",
    "什么",
    "先确认",
)

SMALL_TALK_TERMS = (
    "你好",
    "您好",
    "哈喽",
    "嗨",
    "hello",
    "hi",
    "hey",
    "在吗",
    "你在吗",
    "你是谁",
    "你是做什么",
    "你是做什么的",
    "你能干什么",
    "你能做什么",
    "你可以做什么",
    "你都能做什么",
    "你会什么",
    "你会做什么",
    "你有什么能力",
    "可以帮我做什么",
    "能帮我做什么",
    "你主要做什么",
    "你叫什么",
    "怎么称呼",
    "介绍一下你自己",
    "早上好",
    "中午好",
    "下午好",
    "晚上好",
    "谢谢",
    "感谢",
    "辛苦了",
    "再见",
)

SMALL_TALK_QUESTION_TERMS = (
    "你是谁",
    "你是做什么",
    "你是做什么的",
    "你能干什么",
    "你能做什么",
    "你可以做什么",
    "你都能做什么",
    "你会什么",
    "你会做什么",
    "你有什么能力",
    "可以帮我做什么",
    "能帮我做什么",
    "你主要做什么",
    "你叫什么",
    "怎么称呼",
    "介绍一下你自己",
)

INTAKE_EXPLICIT_PHRASES = (
    "请先帮我梳理",
    "请帮我梳理",
    "帮我梳理一下",
    "先帮我梳理",
    "先梳理需求",
    "先做需求梳理",
    "帮我把需求说清楚",
    "把需求说清楚",
    "先收口",
    "先整理需求",
)

INTAKE_STRUCTURING_TERMS = (
    "梳理",
    "整理",
    "整理需求",
    "收口",
    "需求梳理",
    "需求说清楚",
)

INTAKE_PURCHASE_TERMS: tuple[str, ...] = ()

INTAKE_ENTITY_TERMS: tuple[str, ...] = ()


def resolve_terms(
    *,
    lexicon: dict[str, Any] | None,
    key: str,
    legacy_terms: tuple[str, ...],
) -> tuple[str, ...]:
    terms: list[str] = []
    if isinstance(lexicon, dict):
        raw = lexicon.get(key)
        if isinstance(raw, list):
            for item in raw:
                text = str(item or "").strip().lower()
                if text:
                    terms.append(text)
    del legacy_terms
    return tuple(dict.fromkeys(terms))
