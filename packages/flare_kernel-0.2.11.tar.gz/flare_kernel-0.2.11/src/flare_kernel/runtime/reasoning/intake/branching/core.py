"""Branching chooser state helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.branching.policy import (
    normalize_branching_policy,
)
from flare_kernel.runtime.reasoning.intake.shared import (
    coerce_mapping,
    has_value,
    normalize_field_list,
    normalize_text,
)


def resolve_effective_branching_policy(
    *,
    domain_context: dict[str, Any],
    understood_context: dict[str, Any],
) -> dict[str, Any]:
    configured = normalize_branching_policy(domain_context.get("branching_chooser_policy"))
    if configured.get("branch_nodes"):
        return configured
    del understood_context
    return {"branch_nodes": [], "field_definitions": [], "activation_terms": ()}


def infer_branch_state(
    *,
    session_state: dict[str, Any],
    latest_input: str,
    domain_context: dict[str, Any],
    understood_context: dict[str, Any],
) -> dict[str, Any]:
    policy = resolve_effective_branching_policy(
        domain_context=domain_context,
        understood_context=understood_context,
    )
    nodes = policy.get("branch_nodes", [])
    if not nodes:
        return {"branch_state": {}, "active_branch_path": [], "policy": policy}
    confirmed_fields = coerce_mapping(session_state.get("confirmed_fields"))
    existing_state = coerce_mapping(session_state.get("branch_state") or session_state.get("intake_branch_state"))
    latest_text = normalize_text(latest_input)
    next_state: dict[str, Any] = {}
    active_path: list[str] = []
    for node in nodes:
        node_key = normalize_text(node.get("key"))
        field_key = normalize_text(node.get("field_key"))
        node_state = coerce_mapping(existing_state.get(node_key))
        resolved_option = None
        if normalize_text(node_state.get("selected_option_key")):
            for option in node.get("options", []):
                if normalize_text(option.get("key")) == normalize_text(node_state.get("selected_option_key")):
                    resolved_option = option
                    break
        if resolved_option is None:
            confirmed_value = normalize_text(confirmed_fields.get(field_key)) if field_key else ""
            combined_text = " ".join(part for part in (confirmed_value, latest_text) if part)
            lowered = combined_text.lower()
            for option in node.get("options", []):
                option_value = normalize_text(option.get("value") or option.get("label"))
                option_label = normalize_text(option.get("label"))
                if not option_value and not option_label:
                    continue
                if option.get("requires_custom_input"):
                    continue
                if option_value.lower() in lowered or option_label.lower() in lowered:
                    resolved_option = option
                    node_state = {
                        "selected_option_key": normalize_text(option.get("key")),
                        "selected_option_value": option_value or option_label,
                        "selected_option_text": option_label or option_value,
                    }
                    break
        if not node_state and field_key and has_value(confirmed_fields.get(field_key)):
            confirmed_value = normalize_text(confirmed_fields.get(field_key))
            node_state = {
                "selected_option_key": normalize_text(node_state.get("selected_option_key")),
                "selected_option_value": confirmed_value,
                "selected_option_text": confirmed_value,
            }
        if node_state:
            next_state[node_key] = node_state
            active_path.append(node_key)
    return {
        "branch_state": next_state,
        "active_branch_path": active_path,
        "policy": policy,
    }


def resolve_branch_field_scope(
    *,
    policy: dict[str, Any],
    branch_state: dict[str, Any],
) -> dict[str, list[str]]:
    active_fields: list[str] = []
    preferred_fields: list[str] = []
    suppressed_fields: list[str] = []
    nodes = policy.get("branch_nodes", []) if isinstance(policy, dict) else []
    state = coerce_mapping(branch_state)
    for node in nodes:
        node_key = normalize_text(node.get("key"))
        selected_key = normalize_text(coerce_mapping(state.get(node_key)).get("selected_option_key"))
        if not selected_key:
            continue
        for option in node.get("options", []):
            if normalize_text(option.get("key")) != selected_key:
                continue
            preferred_fields.extend(normalize_field_list(option.get("preferred_fields")))
            active_fields.extend(normalize_field_list(option.get("activates_fields")))
            suppressed_fields.extend(normalize_field_list(option.get("suppresses_fields")))
            break
    suppressed_set = set(suppressed_fields)
    active = [field for field in normalize_field_list(active_fields) if field not in suppressed_set]
    return {
        "active_fields": active,
        "preferred_fields": [field for field in normalize_field_list(preferred_fields) if field not in suppressed_set],
        "suppressed_fields": normalize_field_list(suppressed_fields),
    }


def find_next_branch_question(
    *,
    policy: dict[str, Any],
    branch_state: dict[str, Any],
    confirmed_fields: dict[str, Any],
) -> dict[str, Any] | None:
    nodes = policy.get("branch_nodes", []) if isinstance(policy, dict) else []
    state = coerce_mapping(branch_state)
    confirmed = coerce_mapping(confirmed_fields)
    scope = resolve_branch_field_scope(policy=policy, branch_state=state)
    for node in nodes:
        node_key = normalize_text(node.get("key"))
        if node_key in state:
            continue
        field_key = normalize_text(node.get("field_key"))
        if field_key and has_value(confirmed.get(field_key)):
            continue
        return {
            "question_kind": "branch",
            "branch_node_key": node_key,
            "field_key": field_key,
            "question_text": normalize_text(node.get("question_text")),
            "options": [dict(option) for option in node.get("options", []) if isinstance(option, dict)],
            "active_field_scope": list(scope.get("active_fields", [])),
            "suppressed_field_scope": list(scope.get("suppressed_fields", [])),
        }
    return None


def merge_branch_field_definitions(
    *,
    field_definitions: list[dict[str, Any]],
    policy: dict[str, Any],
) -> list[dict[str, Any]]:
    merged = [dict(item) for item in field_definitions if isinstance(item, dict)]
    existing = {normalize_text(item.get("key")) for item in merged}
    for item in policy.get("field_definitions", []) if isinstance(policy, dict) else []:
        if not isinstance(item, dict):
            continue
        key = normalize_text(item.get("key"))
        if not key or key in existing:
            continue
        merged.append(dict(item))
        existing.add(key)
    return merged


__all__ = [
    "find_next_branch_question",
    "infer_branch_state",
    "merge_branch_field_definitions",
    "resolve_branch_field_scope",
    "resolve_effective_branching_policy",
]
