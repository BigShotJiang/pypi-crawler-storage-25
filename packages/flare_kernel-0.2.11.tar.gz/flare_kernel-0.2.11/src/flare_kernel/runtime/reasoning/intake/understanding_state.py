"""Understanding state assembly for intake reasoning."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.context import _infer_understood_context
from flare_kernel.runtime.reasoning.intake.hypothesis import infer_hypotheses
from flare_kernel.runtime.reasoning.intake.question.extraction import extract_next_question_plan
from flare_kernel.runtime.reasoning.intake.planning import (
    detect_candidate_information_gaps,
    plan_next_question,
    select_active_fields,
)
from flare_kernel.runtime.reasoning.intake.readiness.scoring import evaluate_analyzability
from flare_kernel.runtime.reasoning.intake.shared import (
    DEFAULT_UNDERSTANDING_SCORE_THRESHOLD,
    clamp_score,
    coerce_mapping,
    normalize_field_list,
    normalize_text,
)


def _resolve_result_text_from_structured(structured: dict[str, Any]) -> str:
    direct_candidates = [
        structured.get("result_text"),
        structured.get("result_summary"),
        structured.get("response_text"),
        structured.get("final_answer_text"),
    ]
    for value in direct_candidates:
        text = normalize_text(value)
        if text:
            return text
    result_output = coerce_mapping(structured.get("result_output"))
    nested_candidates = [
        result_output.get("result_text"),
        result_output.get("result_summary"),
        result_output.get("response_text"),
        result_output.get("final_answer_text"),
    ]
    for value in nested_candidates:
        text = normalize_text(value)
        if text:
            return text
    return ""


def build_intake_understanding_state(
    *,
    intake_session_id: str,
    session_state: dict[str, Any],
    latest_input: str,
    domain_context: dict[str, Any],
    structured_reasoning: dict[str, Any] | None = None,
) -> dict[str, Any]:
    structured = coerce_mapping(structured_reasoning)
    enriched_session_state = dict(session_state)
    enriched_session_state["latest_input"] = latest_input
    hypothesis_state = infer_hypotheses(
        session_state=enriched_session_state,
        latest_input=latest_input,
        domain_context=domain_context,
        structured_output=coerce_mapping(structured.get("hypothesis_inference")),
    )
    hypotheses = [
        item
        for item in hypothesis_state.get("hypotheses", [])
        if isinstance(item, dict) and normalize_text(item.get("id"))
    ]
    field_selection = select_active_fields(
        session_state=enriched_session_state,
        domain_context=domain_context,
        hypotheses=hypotheses,
        structured_output=coerce_mapping(structured.get("field_activation")),
    )
    understood_context = _infer_understood_context(
        session_state=enriched_session_state,
        latest_input=latest_input,
    )
    gap_state = detect_candidate_information_gaps(
        session_state=enriched_session_state,
        domain_context=domain_context,
        hypotheses=hypotheses,
        understood_context=understood_context,
        field_selection=field_selection,
        structured_output=coerce_mapping(structured.get("gap_detection")),
    )
    candidate_information_gaps = [
        item
        for item in gap_state.get("candidate_information_gaps", [])
        if isinstance(item, dict) and normalize_text(item.get("key"))
    ]
    next_question_state = plan_next_question(
        session_state=enriched_session_state,
        domain_context=domain_context,
        hypotheses=hypotheses,
        field_selection=field_selection,
        structured_output=coerce_mapping(structured.get("question_planner")),
    )
    base_question_plan = {
        "question_key": normalize_text(next_question_state.get("branch_node_key") or next_question_state.get("question_key") or next_question_state.get("target_information_gap")),
        "question_text": normalize_text(next_question_state.get("question_text")),
        "why_now": normalize_text(next_question_state.get("why_now")),
        "target_information_gap": normalize_text(next_question_state.get("target_information_gap")),
        "question_kind": normalize_text(next_question_state.get("question_kind") or "field"),
        "branch_node_key": normalize_text(next_question_state.get("branch_node_key")),
        "options": [dict(item) for item in next_question_state.get("options", []) if isinstance(item, dict)],
        "source": normalize_text(next_question_state.get("planning_source")) or "field_fallback",
    } if normalize_text(next_question_state.get("question_text")) else {}
    has_structured_question = (
        normalize_text(base_question_plan.get("source")) == "structured_model"
        and normalize_text(base_question_plan.get("question_text"))
    )
    extracted_question_plan = {}
    if not has_structured_question:
        extracted_question_plan = extract_next_question_plan(
            result_text=_resolve_result_text_from_structured(structured),
            current_planned_question=base_question_plan,
            candidate_information_gaps=candidate_information_gaps,
        )
    next_question_plan = extracted_question_plan or base_question_plan
    analyzability_state = evaluate_analyzability(
        session_state=enriched_session_state,
        domain_context=domain_context,
        field_selection=field_selection,
        hypotheses=hypotheses,
        candidate_information_gaps=candidate_information_gaps,
        threshold=domain_context.get("analysis_entry_threshold"),
    )
    normalized_hypotheses: list[dict[str, Any]] = []
    for node in hypotheses:
        if not isinstance(node, dict):
            continue
        hypothesis_id = normalize_text(node.get("id"))
        if not hypothesis_id:
            continue
        try:
            hypothesis_score = clamp_score(float(node.get("score") or 0.0))
        except (TypeError, ValueError):
            hypothesis_score = 0.0
        normalized_hypotheses.append(
            {
                "id": hypothesis_id,
                "score": hypothesis_score,
                "rationale": normalize_text(node.get("rationale")) or "inferred",
            }
        )

    normalized_gaps: list[dict[str, Any]] = []
    for node in candidate_information_gaps:
        if not isinstance(node, dict):
            continue
        gap_key = normalize_text(node.get("key"))
        if not gap_key:
            continue
        try:
            importance = max(0.0, float(node.get("importance") or 0.0))
        except (TypeError, ValueError):
            importance = 0.0
        normalized_gaps.append(
            {
                "key": gap_key,
                "importance": importance,
                "reason": normalize_text(node.get("reason")) or "scored",
            }
        )

    return {
        "intake_session_id": intake_session_id,
        "raw_user_goal": normalize_text(latest_input),
        "understood_context": understood_context,
        "hypotheses": normalized_hypotheses,
        "candidate_information_gaps": normalized_gaps,
        "next_question_plan": next_question_plan or None,
        "current_best_next_question": {
            "question_key": normalize_text(next_question_plan.get("question_key")),
            "question_text": normalize_text(next_question_plan.get("question_text")),
            "why_now": normalize_text(next_question_plan.get("why_now")),
            "target_information_gap": normalize_text(next_question_plan.get("target_information_gap")),
            "question_kind": normalize_text(next_question_plan.get("question_kind") or "field"),
            "branch_node_key": normalize_text(next_question_plan.get("branch_node_key")),
            "options": [dict(item) for item in next_question_plan.get("options", []) if isinstance(item, dict)],
            "source": normalize_text(next_question_plan.get("source")),
        } if normalize_text(next_question_plan.get("question_text")) else None,
        "analyzability_score": float(analyzability_state.get("analyzability_score") or 0.0),
        "analysis_entry_threshold": float(analyzability_state.get("analysis_entry_threshold") or DEFAULT_UNDERSTANDING_SCORE_THRESHOLD),
        "analysis_entry_eligible": bool(analyzability_state.get("analysis_entry_eligible")),
        "field_selection": field_selection,
        "branch_state": coerce_mapping(field_selection.get("branch_state")),
        "active_branch_path": normalize_field_list(field_selection.get("active_branch_path")),
        "readiness": analyzability_state,
    }


__all__ = ["build_intake_understanding_state"]
