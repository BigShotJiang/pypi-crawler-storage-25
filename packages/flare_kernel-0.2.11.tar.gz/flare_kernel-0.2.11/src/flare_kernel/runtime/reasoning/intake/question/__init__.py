"""Question planning helpers for intake reasoning."""
