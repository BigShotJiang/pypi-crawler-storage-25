"""Hypothesis inference for generic intake reasoning."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.shared import coerce_mapping, normalize_text, has_value


def infer_hypotheses(
    *,
    session_state: dict[str, Any],
    latest_input: str,
    domain_context: dict[str, Any],
    structured_output: dict[str, Any] | None = None,
) -> dict[str, Any]:
    structured = coerce_mapping(structured_output)
    structured_hypotheses = structured.get("hypotheses") if isinstance(structured.get("hypotheses"), list) else []
    if structured_hypotheses:
        hypotheses: list[dict[str, Any]] = []
        for node in structured_hypotheses:
            if not isinstance(node, dict):
                continue
            hypothesis_id = normalize_text(node.get("id"))
            if not hypothesis_id:
                continue
            try:
                score = max(0.0, min(1.0, float(node.get("score"))))
            except (TypeError, ValueError):
                score = 0.0
            hypotheses.append(
                {
                    "id": hypothesis_id,
                    "score": score,
                    "rationale": normalize_text(node.get("rationale")) or "model_structured_output",
                    "supporting_signals": [
                        str(item).strip()
                        for item in node.get("supporting_signals", [])
                        if str(item).strip()
                    ] if isinstance(node.get("supporting_signals"), list) else [],
                    "conflicts": [
                        str(item).strip()
                        for item in node.get("conflicts", [])
                        if str(item).strip()
                    ] if isinstance(node.get("conflicts"), list) else [],
                }
            )
        if hypotheses:
            hypotheses.sort(key=lambda item: float(item.get("score") or 0.0), reverse=True)
            top = float(hypotheses[0].get("score") or 0.0)
            second = float(hypotheses[1].get("score") or 0.0) if len(hypotheses) > 1 else 0.0
            gap = top - second
            uncertainty = "low" if gap >= 0.25 else ("medium" if gap >= 0.12 else "high")
            unresolved_dimensions = [
                str(item).strip()
                for item in structured.get("unresolved_dimensions", [])
                if str(item).strip()
            ] if isinstance(structured.get("unresolved_dimensions"), list) else []
            return {
                "hypotheses": hypotheses,
                "uncertainty_level": uncertainty,
                "unresolved_dimensions": unresolved_dimensions,
                "inference_source": "structured_model",
            }

    message_text = normalize_text(latest_input).lower()
    confirmed_fields = coerce_mapping(session_state.get("confirmed_fields"))
    priors = coerce_mapping(domain_context.get("priors"))
    ontology = coerce_mapping(domain_context.get("ontology"))
    hypothesis_defs = ontology.get("hypotheses") if isinstance(ontology.get("hypotheses"), list) else []

    if not hypothesis_defs:
        hypothesis_defs = [{"id": "general_intake", "label": "General Intake", "description": "Generic intake fallback."}]

    score_map: dict[str, float] = {}
    signals_map: dict[str, list[str]] = {}
    conflicts_map: dict[str, list[str]] = {}

    for node in hypothesis_defs:
        if not isinstance(node, dict):
            continue
        hypothesis_id = normalize_text(node.get("id"))
        if not hypothesis_id:
            continue
        base_prior = node.get("prior")
        try:
            base_score = float(base_prior)
        except (TypeError, ValueError):
            base_score = 0.05
        score_map[hypothesis_id] = max(0.0, base_score)
        signals_map[hypothesis_id] = []
        conflicts_map[hypothesis_id] = []

    for item in priors.get("term_to_hypotheses", []):
        if not isinstance(item, dict):
            continue
        term = normalize_text(item.get("term")).lower()
        hypothesis_id = normalize_text(item.get("hypothesis"))
        if not term or not hypothesis_id:
            continue
        if term not in message_text:
            continue
        try:
            weight = float(item.get("weight") or 0.0)
        except (TypeError, ValueError):
            weight = 0.0
        if hypothesis_id not in score_map:
            continue
        score_map[hypothesis_id] += max(0.0, weight)
        signals_map[hypothesis_id].append(f"term:{term}")

    for item in priors.get("field_to_hypotheses", []):
        if not isinstance(item, dict):
            continue
        field_key = normalize_text(item.get("field_key"))
        hypothesis_id = normalize_text(item.get("hypothesis"))
        if not field_key or not hypothesis_id or hypothesis_id not in score_map:
            continue
        if not has_value(confirmed_fields.get(field_key)):
            continue
        try:
            weight = float(item.get("weight") or 0.0)
        except (TypeError, ValueError):
            weight = 0.0
        score_map[hypothesis_id] += max(0.0, weight)
        signals_map[hypothesis_id].append(f"field:{field_key}")

    for item in priors.get("field_value_to_hypotheses", []):
        if not isinstance(item, dict):
            continue
        field_key = normalize_text(item.get("field_key"))
        contains_text = normalize_text(item.get("contains")).lower()
        hypothesis_id = normalize_text(item.get("hypothesis"))
        if not field_key or not contains_text or not hypothesis_id or hypothesis_id not in score_map:
            continue
        field_value = normalize_text(confirmed_fields.get(field_key)).lower()
        if contains_text not in field_value:
            continue
        try:
            weight = float(item.get("weight") or 0.0)
        except (TypeError, ValueError):
            weight = 0.0
        score_map[hypothesis_id] += max(0.0, weight)
        signals_map[hypothesis_id].append(f"field_value:{field_key}:{contains_text}")

    for item in priors.get("conflict_signals", []):
        if not isinstance(item, dict):
            continue
        term = normalize_text(item.get("term")).lower()
        hypothesis_id = normalize_text(item.get("hypothesis"))
        if not term or not hypothesis_id or hypothesis_id not in score_map:
            continue
        if term not in message_text:
            continue
        try:
            penalty = float(item.get("penalty") or 0.0)
        except (TypeError, ValueError):
            penalty = 0.0
        score_map[hypothesis_id] -= abs(penalty)
        conflicts_map[hypothesis_id].append(f"term:{term}")

    hypotheses: list[dict[str, Any]] = []
    total = sum(max(0.0, score) for score in score_map.values())
    for node in hypothesis_defs:
        if not isinstance(node, dict):
            continue
        hypothesis_id = normalize_text(node.get("id"))
        if not hypothesis_id or hypothesis_id not in score_map:
            continue
        score = max(0.0, score_map[hypothesis_id])
        normalized_score = (score / total) if total > 0 else 0.0
        rationale = normalize_text(node.get("description")) or "scored_by_priors"
        hypotheses.append(
            {
                "id": hypothesis_id,
                "score": normalized_score,
                "rationale": rationale,
                "supporting_signals": signals_map.get(hypothesis_id, []),
                "conflicts": conflicts_map.get(hypothesis_id, []),
            }
        )

    if not hypotheses:
        hypotheses = [
            {
                "id": "general_intake",
                "score": 1.0,
                "rationale": "fallback",
                "supporting_signals": [],
                "conflicts": [],
            }
        ]

    hypotheses.sort(key=lambda item: float(item.get("score") or 0.0), reverse=True)
    top = float(hypotheses[0].get("score") or 0.0)
    second = float(hypotheses[1].get("score") or 0.0) if len(hypotheses) > 1 else 0.0
    gap = top - second
    uncertainty = "low" if gap >= 0.25 else ("medium" if gap >= 0.12 else "high")

    unresolved_dimensions: list[str] = []
    if uncertainty != "low":
        dimensions = ontology.get("dimensions") if isinstance(ontology.get("dimensions"), list) else []
        unresolved_dimensions = [normalize_text(item.get("id") if isinstance(item, dict) else item) for item in dimensions]
        unresolved_dimensions = [item for item in unresolved_dimensions if item]

    return {
        "hypotheses": hypotheses,
        "uncertainty_level": uncertainty,
        "unresolved_dimensions": unresolved_dimensions,
        "inference_source": "domain_priors",
    }
