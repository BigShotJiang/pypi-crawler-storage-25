"""Candidate information gap detection for intake reasoning."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.priority import (
    score_direction_priority_adjustment,
)
from flare_kernel.runtime.reasoning.intake.shared import (
    coerce_mapping,
    has_value,
    normalize_field_list,
    normalize_text,
)


def _prioritize_specific_candidate_gaps(
    candidate_information_gaps: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    return [item for item in candidate_information_gaps if isinstance(item, dict)]


def _field_deprioritize_adjustment(
    *,
    field_key: str,
    definition: dict[str, Any],
    semantics: dict[str, Any],
    policy: dict[str, Any],
) -> tuple[float, list[str]]:
    normalized_key = normalize_text(field_key)
    policy_fields = set(
        normalize_field_list(
            policy.get("deprioritized_fields")
            or policy.get("low_priority_fields")
            or policy.get("legacy_fields")
        )
    )
    flagged = (
        definition.get("deprioritize") is True
        or definition.get("low_priority") is True
        or definition.get("legacy_field") is True
        or semantics.get("deprioritize") is True
        or semantics.get("low_priority") is True
        or semantics.get("legacy_field") is True
        or normalized_key in policy_fields
    )
    if not flagged:
        return 0.0, []
    try:
        weight = float(policy.get("deprioritized_field_weight") or policy.get("low_priority_field_weight") or 0.28)
    except (TypeError, ValueError):
        weight = 0.28
    return -max(0.0, weight), ["pack_deprioritized_field"]


def _contains_field_reference(text: str, *, field_key: str, definition: dict[str, Any]) -> bool:
    haystack = normalize_text(text).lower()
    terms = {
        normalize_text(field_key).lower(),
        normalize_text(definition.get("label")).lower(),
        normalize_text(definition.get("question")).lower(),
    }
    return any(term and term in haystack for term in terms)


def _question_context_adjustment(
    *,
    field_key: str,
    definition: dict[str, Any],
    question_context: dict[str, Any],
) -> tuple[float, list[str]]:
    adjustment = 0.0
    reasons: list[str] = []
    artifact_field_keys = set(normalize_field_list(question_context.get("artifact_field_keys")))
    if field_key in artifact_field_keys:
        adjustment += 0.14
        reasons.append("artifact_field")

    track_text = normalize_text(question_context.get("track_signal_text"))
    if _contains_field_reference(track_text, field_key=field_key, definition=definition):
        adjustment += 0.16
        reasons.append("track_context")

    artifact_text = normalize_text(question_context.get("artifact_signal_text"))
    if _contains_field_reference(artifact_text, field_key=field_key, definition=definition):
        adjustment += 0.1
        reasons.append("artifact_context")

    try:
        document_count = int(question_context.get("document_count") or 0)
    except (TypeError, ValueError):
        document_count = 0
    if document_count > 0 and field_key in artifact_field_keys:
        adjustment += 0.06
        reasons.append("artifact_document_context")
    return adjustment, reasons


def detect_candidate_information_gaps(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    understood_context: dict[str, Any],
    field_selection: dict[str, Any] | None = None,
    structured_output: dict[str, Any] | None = None,
) -> dict[str, Any]:
    structured = coerce_mapping(structured_output)
    structured_gaps = structured.get("candidate_information_gaps")
    if isinstance(structured_gaps, list):
        normalized: list[dict[str, Any]] = []
        for item in structured_gaps:
            if not isinstance(item, dict):
                continue
            gap_key = normalize_text(item.get("key"))
            if not gap_key:
                continue
            try:
                importance = max(0.0, float(item.get("importance") or 0.0))
            except (TypeError, ValueError):
                importance = 0.0
            normalized.append(
                {
                    "key": gap_key,
                    "importance": importance,
                    "reason": normalize_text(item.get("reason")) or "structured_model",
                }
            )
        if normalized:
            normalized.sort(key=lambda node: float(node.get("importance") or 0.0), reverse=True)
            return {
                "candidate_information_gaps": normalized,
                "detection_source": "structured_model",
            }

    confirmed_fields = coerce_mapping(session_state.get("confirmed_fields"))
    required_field_list = normalize_field_list(domain_context.get("required_fields"))
    recommended_field_list = normalize_field_list(domain_context.get("recommended_fields"))
    optional_field_list = normalize_field_list(domain_context.get("optional_fields"))
    required_fields = set(required_field_list)
    recommended_fields = set(recommended_field_list)
    optional_fields = set(optional_field_list)
    scope = normalize_field_list([*required_field_list, *recommended_field_list, *optional_field_list])
    field_semantics = coerce_mapping(domain_context.get("field_semantics"))
    field_definitions = {
        normalize_text(item.get("key")): coerce_mapping(item)
        for item in domain_context.get("field_definitions", [])
        if isinstance(item, dict) and normalize_text(item.get("key"))
    }
    branch_hints = coerce_mapping(domain_context.get("branch_hints"))
    affinity_map = coerce_mapping(branch_hints.get("hypothesis_field_affinity"))
    distinguishing_fields = coerce_mapping(branch_hints.get("distinguishing_fields"))
    active_fields = normalize_field_list(coerce_mapping(field_selection or {}).get("active_fields"))
    active_field_rank = {
        field_key: index
        for index, field_key in enumerate(active_fields)
    }
    branch_preferred_fields = normalize_field_list(coerce_mapping(field_selection or {}).get("branch_preferred_fields"))
    field_scores = coerce_mapping(coerce_mapping(field_selection or {}).get("field_scores"))
    intake_priority_policy = coerce_mapping(domain_context.get("intake_priority_policy"))
    question_context = coerce_mapping(session_state.get("question_context"))

    top_hypothesis_id = normalize_text((hypotheses[0] or {}).get("id")) if hypotheses else ""
    target_distinguishing = set(normalize_field_list(distinguishing_fields.get(top_hypothesis_id)))
    gaps: list[dict[str, Any]] = []
    for field_key in scope:
        if has_value(confirmed_fields.get(field_key)):
            continue
        definition = coerce_mapping(field_definitions.get(field_key))
        semantics = coerce_mapping(field_semantics.get(field_key))
        criticality = normalize_text(semantics.get("criticality")).lower()
        try:
            analyzability_weight = max(0.0, float(semantics.get("analyzability_weight") or 0.0))
        except (TypeError, ValueError):
            analyzability_weight = 0.0
        try:
            score = float(field_scores.get(field_key) or 0.0)
        except (TypeError, ValueError):
            score = 0.0

        importance = 0.0
        reason_parts: list[str] = []
        if field_key in required_fields:
            importance += 0.62
            reason_parts.append("required")
        elif field_key in recommended_fields:
            importance += 0.36
            reason_parts.append("recommended")
        else:
            importance += 0.18
            reason_parts.append("optional")

        if criticality == "critical":
            importance += 0.18
            reason_parts.append("criticality")
        elif criticality == "important":
            importance += 0.1

        importance += analyzability_weight * 0.14
        if analyzability_weight > 0:
            reason_parts.append("analyzability")

        if field_key in target_distinguishing:
            importance += 0.16
            reason_parts.append("hypothesis_disambiguation")

        support = 0.0
        relevance_by_hypothesis = coerce_mapping(semantics.get("relevance_by_hypothesis"))
        for hypothesis in hypotheses:
            hypothesis_id = normalize_text(hypothesis.get("id"))
            try:
                hypothesis_score = max(0.0, float(hypothesis.get("score") or 0.0))
            except (TypeError, ValueError):
                hypothesis_score = 0.0
            if not hypothesis_id or hypothesis_score <= 0:
                continue
            affinity_scores = coerce_mapping(affinity_map.get(hypothesis_id))
            try:
                support += max(0.0, float(affinity_scores.get(field_key) or 0.0)) * hypothesis_score
            except (TypeError, ValueError):
                pass
            try:
                support += max(0.0, float(relevance_by_hypothesis.get(hypothesis_id) or 0.0)) * hypothesis_score
            except (TypeError, ValueError):
                pass
        if support > 0:
            importance += min(0.24, support * 0.22)
            reason_parts.append("hypothesis_support")

        if field_key in active_fields:
            rank = active_field_rank.get(field_key, len(active_fields))
            importance += max(0.08, 0.24 - (rank * 0.02))
            reason_parts.append("active_scope")
        if field_key in branch_preferred_fields:
            importance += 0.34
            reason_parts.append("branch_preferred")

        deprioritize_adjustment, deprioritize_reasons = _field_deprioritize_adjustment(
            field_key=field_key,
            definition=definition,
            semantics=semantics,
            policy=intake_priority_policy,
        )
        if deprioritize_adjustment < 0:
            importance += deprioritize_adjustment
            reason_parts.extend(deprioritize_reasons)

        context_adjustment, context_reasons = _question_context_adjustment(
            field_key=field_key,
            definition=definition,
            question_context=question_context,
        )
        if context_adjustment > 0:
            importance += context_adjustment
            reason_parts.extend(context_reasons)

        direction_adjustment, direction_reasons = score_direction_priority_adjustment(
            field_key=field_key,
            definition=definition,
            confirmed_fields=confirmed_fields,
            field_definitions=field_definitions,
            policy=intake_priority_policy,
        )
        if direction_adjustment > 0:
            importance += direction_adjustment
            reason_parts.extend(direction_reasons)

        importance = max(0.0, importance + (score * 0.08))
        gaps.append(
            {
                "key": field_key,
                "importance": importance,
                "reason": ",".join(reason_parts) if reason_parts else "scored",
            }
        )

    gaps.sort(key=lambda node: float(node.get("importance") or 0.0), reverse=True)
    return {
        "candidate_information_gaps": gaps,
        "detection_source": "scored_dynamic",
    }


__all__ = ["detect_candidate_information_gaps"]
