"""Question choice decision helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.shared import coerce_mapping, normalize_field_list, normalize_text


def _safe_float(value: Any) -> float:
    try:
        return float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _gap_for_field(candidate_information_gaps: list[dict[str, Any]], field_key: str) -> dict[str, Any]:
    normalized_key = normalize_text(field_key)
    for gap in candidate_information_gaps:
        if normalize_text(gap.get("key")) == normalized_key:
            return gap
    return {}


def select_best_question_field(
    *,
    planned_key: str,
    candidate_information_gaps: list[dict[str, Any]],
    active_fields: list[str],
    field_scores: dict[str, Any],
) -> str:
    active = normalize_field_list(active_fields)
    active_set = set(active)
    normalized_planned = normalize_text(planned_key)
    if normalized_planned and (not active_set or normalized_planned in active_set):
        return normalized_planned

    for gap in candidate_information_gaps:
        gap_key = normalize_text(gap.get("key"))
        if gap_key and (not active_set or gap_key in active_set):
            return gap_key

    best_key = ""
    best_score = float("-inf")
    for field_key in active:
        score = _safe_float(field_scores.get(field_key))
        if score > best_score:
            best_score = score
            best_key = field_key
    return best_key


def build_question_decision(
    *,
    selected_field_key: str,
    candidate_information_gaps: list[dict[str, Any]],
    field_scores: dict[str, Any],
    planning_source: str,
    why_now: str,
    target_information_gap: str,
    session_state: dict[str, Any],
) -> dict[str, Any]:
    field_key = normalize_text(selected_field_key)
    gap = _gap_for_field(candidate_information_gaps, field_key)
    gap_importance = _safe_float(gap.get("importance"))
    field_score = _safe_float(field_scores.get(field_key))
    question_context = coerce_mapping(session_state.get("question_context"))
    inputs_used = ["candidate_information_gaps", "field_scores"]
    if question_context.get("track_signal_text"):
        inputs_used.append("track_result")
    if question_context.get("artifact_field_keys") or question_context.get("artifact_signal_text"):
        inputs_used.append("artifact_template_result")
    if _safe_float(question_context.get("document_count")) > 0:
        inputs_used.append("artifact_context")

    return {
        "selected_field_key": field_key,
        "score": round(gap_importance + (field_score * 0.08), 4),
        "score_components": {
            "gap_importance": round(gap_importance, 4),
            "field_score": round(field_score, 4),
        },
        "planning_source": normalize_text(planning_source),
        "why_now": normalize_text(why_now),
        "target_information_gap": normalize_text(target_information_gap) or field_key,
        "gap_reason": normalize_text(gap.get("reason")),
        "inputs_used": inputs_used,
    }


__all__ = ["build_question_decision", "select_best_question_field"]
