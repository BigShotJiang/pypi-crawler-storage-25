"""Generic intake reasoning framework for mode orchestration.

This module intentionally avoids domain-specific constants. Domain semantics are
provided by domain pack ontology/priors/field semantics/branch hints.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.context import build_intake_domain_context as build_intake_domain_context_from_context
from flare_kernel.runtime.reasoning.intake.hypothesis import infer_hypotheses as infer_hypotheses_from_hypothesis
from flare_kernel.runtime.reasoning.intake.planning import (
    detect_candidate_information_gaps as detect_candidate_information_gaps_from_planning,
    plan_next_question as plan_next_question_from_planning,
    plan_next_question_based_on_understanding as plan_next_question_based_on_understanding_from_planning,
    select_active_fields as select_active_fields_from_planning,
)
from flare_kernel.runtime.reasoning.intake.readiness.core import (
    build_intake_understanding_state as build_intake_understanding_state_from_readiness,
    build_user_visible_intake_response as build_user_visible_intake_response_from_readiness,
    evaluate_analyzability as evaluate_analyzability_from_readiness,
    evaluate_readiness as evaluate_readiness_from_readiness,
)
from flare_kernel.runtime.reasoning.intake.shared import (
    coerce_mapping as _coerce_mapping,
    normalize_text as _normalize_text,
)


def build_intake_domain_context(
    *,
    payload: dict[str, Any],
    domain_pack: dict[str, Any] | None,
    field_definitions: list[dict[str, Any]] | None = None,
    required_fields: list[str] | None = None,
    recommended_fields: list[str] | None = None,
    optional_fields: list[str] | None = None,
) -> dict[str, Any]:
    return build_intake_domain_context_from_context(
        payload=payload,
        domain_pack=domain_pack,
        field_definitions=field_definitions,
        required_fields=required_fields,
        recommended_fields=recommended_fields,
        optional_fields=optional_fields,
    )


def infer_hypotheses(
    *,
    session_state: dict[str, Any],
    latest_input: str,
    domain_context: dict[str, Any],
    structured_output: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return infer_hypotheses_from_hypothesis(
        session_state=session_state,
        latest_input=latest_input,
        domain_context=domain_context,
        structured_output=structured_output,
    )


def select_active_fields(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    structured_output: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return select_active_fields_from_planning(
        session_state=session_state,
        domain_context=domain_context,
        hypotheses=hypotheses,
        structured_output=structured_output,
    )


def detect_candidate_information_gaps(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    understood_context: dict[str, Any],
    field_selection: dict[str, Any] | None = None,
    structured_output: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return detect_candidate_information_gaps_from_planning(
        session_state=session_state,
        domain_context=domain_context,
        hypotheses=hypotheses,
        understood_context=understood_context,
        field_selection=field_selection,
        structured_output=structured_output,
    )


def plan_next_question_based_on_understanding(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    candidate_information_gaps: list[dict[str, Any]],
    understood_context: dict[str, Any],
    structured_output: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return plan_next_question_based_on_understanding_from_planning(
        session_state=session_state,
        domain_context=domain_context,
        hypotheses=hypotheses,
        candidate_information_gaps=candidate_information_gaps,
        understood_context=understood_context,
        structured_output=structured_output,
    )


def plan_next_question(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    field_selection: dict[str, Any],
    structured_output: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return plan_next_question_from_planning(
        session_state=session_state,
        domain_context=domain_context,
        hypotheses=hypotheses,
        field_selection=field_selection,
        structured_output=structured_output,
    )


def canonicalize_answer(
    *,
    field_type: str,
    raw_answer: str,
    context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    source_context = _coerce_mapping(context)
    text = _normalize_text(raw_answer)
    if not text:
        return {
            "raw_value": "",
            "normalized_value": {"kind": "empty", "value": ""},
            "display_value": "",
            "confidence": 0.0,
            "source": _normalize_text(source_context.get("source")) or "user_input",
            "status": "empty",
        }

    normalized_type = _normalize_text(field_type).lower()
    options = [str(item).strip() for item in source_context.get("options", []) if str(item).strip()] if isinstance(source_context.get("options"), list) else []

    if normalized_type in {"integer", "number"}:
        digits = "".join(ch for ch in text if ch.isdigit())
        if digits:
            value = int(digits)
            return {
                "raw_value": text,
                "normalized_value": {"kind": "number", "value": value},
                "display_value": str(value),
                "confidence": 0.9,
                "source": _normalize_text(source_context.get("source")) or "user_input",
                "status": "confirmed",
            }

    if normalized_type in {"money", "money_range"}:
        digits = "".join(ch for ch in text if ch.isdigit())
        if digits:
            amount = int(digits)
            multiplier = 1
            if "万" in text:
                multiplier = 10000
            elif "亿" in text:
                multiplier = 100000000
            value = amount * multiplier
            display = f"{value}元" if value < 10000 else (f"{value // 10000}万元" if value % 10000 == 0 else f"{value}元")
            return {
                "raw_value": text,
                "normalized_value": {"kind": "money", "amount": value, "currency": "CNY"},
                "display_value": display,
                "confidence": 0.86,
                "source": _normalize_text(source_context.get("source")) or "user_input",
                "status": "confirmed",
            }

    if normalized_type == "enum" and options:
        lowered = text.lower()
        for option in options:
            if option.lower() in lowered or lowered in option.lower():
                return {
                    "raw_value": text,
                    "normalized_value": {"kind": "enum", "value": option},
                    "display_value": option,
                    "confidence": 0.88,
                    "source": _normalize_text(source_context.get("source")) or "user_input",
                    "status": "confirmed",
                }

    return {
        "raw_value": text,
        "normalized_value": {"kind": "text", "value": text},
        "display_value": text,
        "confidence": 0.75,
        "source": _normalize_text(source_context.get("source")) or "user_input",
        "status": "confirmed",
    }


def evaluate_analyzability(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    field_selection: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    candidate_information_gaps: list[dict[str, Any]] | None = None,
    threshold: float | None = None,
) -> dict[str, Any]:
    return evaluate_analyzability_from_readiness(
        session_state=session_state,
        domain_context=domain_context,
        field_selection=field_selection,
        hypotheses=hypotheses,
        candidate_information_gaps=candidate_information_gaps,
        threshold=threshold,
    )


def build_intake_understanding_state(
    *,
    intake_session_id: str,
    session_state: dict[str, Any],
    latest_input: str,
    domain_context: dict[str, Any],
    structured_reasoning: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return build_intake_understanding_state_from_readiness(
        intake_session_id=intake_session_id,
        session_state=session_state,
        latest_input=latest_input,
        domain_context=domain_context,
        structured_reasoning=structured_reasoning,
    )


def build_user_visible_intake_response(
    *,
    understanding_state: dict[str, Any] | None,
    current_question: dict[str, Any] | None = None,
    confirmed_fields: dict[str, Any] | None = None,
    missing_fields: list[Any] | None = None,
    field_definitions_by_key: dict[str, Any] | None = None,
    readiness: dict[str, Any] | None = None,
) -> str:
    return build_user_visible_intake_response_from_readiness(
        understanding_state=understanding_state,
        current_question=current_question,
        confirmed_fields=confirmed_fields,
        missing_fields=missing_fields,
        field_definitions_by_key=field_definitions_by_key,
        readiness=readiness,
    )


def evaluate_readiness(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    field_selection: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    threshold: float | None = None,
) -> dict[str, Any]:
    return evaluate_readiness_from_readiness(
        session_state=session_state,
        domain_context=domain_context,
        field_selection=field_selection,
        hypotheses=hypotheses,
        threshold=threshold,
    )
