"""Branching chooser policy definitions and normalization helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.shared import normalize_field_list, normalize_text


def normalize_branching_policy(raw_policy: Any) -> dict[str, Any]:
    policy = raw_policy if isinstance(raw_policy, dict) else {}
    branch_nodes = policy.get("branch_nodes")
    normalized_nodes: list[dict[str, Any]] = []
    if isinstance(branch_nodes, list):
        for raw_node in branch_nodes:
            if not isinstance(raw_node, dict):
                continue
            node_key = normalize_text(raw_node.get("key"))
            question_text = normalize_text(raw_node.get("question_text"))
            if not node_key or not question_text:
                continue
            raw_options = raw_node.get("options")
            normalized_options: list[dict[str, Any]] = []
            if isinstance(raw_options, list):
                for index, raw_option in enumerate(raw_options):
                    option = raw_option if isinstance(raw_option, dict) else {"label": raw_option}
                    label = normalize_text(option.get("label") or option.get("text") or option.get("value"))
                    option_key = normalize_text(option.get("key")) or f"{node_key}_option_{index + 1}"
                    if not label:
                        continue
                    normalized_options.append(
                        {
                            "key": option_key,
                            "label": label,
                            "value": normalize_text(option.get("value") or label),
                            "followup_hint": normalize_text(option.get("followup_hint")),
                            "requires_custom_input": bool(option.get("requires_custom_input") or option.get("allow_custom_input")),
                            "preferred_fields": normalize_field_list(option.get("preferred_fields")),
                            "activates_fields": normalize_field_list(option.get("activates_fields")),
                            "suppresses_fields": normalize_field_list(option.get("suppresses_fields")),
                        }
                    )
            if not normalized_options:
                continue
            normalized_nodes.append(
                {
                    "key": node_key,
                    "field_key": normalize_text(raw_node.get("field_key")),
                    "question_text": question_text,
                    "options": normalized_options,
                }
            )
    field_definitions = policy.get("field_definitions")
    normalized_fields = [
        item for item in field_definitions
        if isinstance(item, dict) and normalize_text(item.get("key"))
    ] if isinstance(field_definitions, list) else []
    activation_terms = tuple(
        normalize_text(item)
        for item in policy.get("activation_terms", [])
        if normalize_text(item)
    ) if isinstance(policy.get("activation_terms"), list) else ()
    return {
        "branch_nodes": normalized_nodes,
        "field_definitions": normalized_fields,
        "activation_terms": activation_terms,
    }


__all__ = [
    "normalize_branching_policy",
]
