"""Structured-model question planning helpers."""

from __future__ import annotations

from typing import Any, Callable

from flare_kernel.runtime.reasoning.intake.question.decision import build_question_decision
from flare_kernel.runtime.reasoning.intake.shared import has_value, normalize_field_list, normalize_text


def _safe_float(value: Any) -> float:
    try:
        return float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _safe_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _select_carrier_field(
    *,
    question_key: str,
    target_field_keys: list[str],
    active_fields: list[str],
    domain_field_keys: list[str],
    confirmed_fields: dict[str, Any],
    field_scores: dict[str, Any],
) -> str:
    active = normalize_field_list(active_fields)
    active_set = set(active)
    domain_set = set(normalize_field_list(domain_field_keys))
    if question_key in domain_set and question_key not in active_set:
        return ""
    if any(field_key in domain_set and field_key not in active_set for field_key in target_field_keys):
        return ""
    for field_key in target_field_keys:
        if field_key in active_set and not has_value(confirmed_fields.get(field_key)):
            return field_key
    if question_key in active_set and not has_value(confirmed_fields.get(question_key)):
        return question_key
    open_fields = [field_key for field_key in active if not has_value(confirmed_fields.get(field_key))]
    if not open_fields:
        return ""
    return max(open_fields, key=lambda field_key: _safe_float(field_scores.get(field_key)))


def resolve_structured_question_plan(
    *,
    structured_question: dict[str, Any],
    active_fields: list[str],
    domain_field_keys: list[str],
    field_scores: dict[str, Any],
    session_state: dict[str, Any],
    resolve_options_fn: Callable[[dict[str, Any]], list[dict[str, Any]]],
) -> dict[str, Any]:
    question_text = normalize_text(structured_question.get("question_text"))
    if not question_text:
        return {}
    target_field_keys = normalize_field_list(structured_question.get("target_field_keys"))
    question_key = normalize_text(
        structured_question.get("question_key")
        or structured_question.get("field_key")
        or structured_question.get("target_information_gap")
        or (target_field_keys[0] if target_field_keys else "")
    )
    if not target_field_keys and question_key:
        target_field_keys = [question_key]
    confirmed_fields = session_state.get("confirmed_fields")
    carrier_field = _select_carrier_field(
        question_key=question_key,
        target_field_keys=target_field_keys,
        active_fields=active_fields,
        domain_field_keys=domain_field_keys,
        confirmed_fields=confirmed_fields if isinstance(confirmed_fields, dict) else {},
        field_scores=field_scores,
    )
    if not carrier_field:
        return {}

    resolved_question_key = question_key or carrier_field
    why_now = normalize_text(structured_question.get("why_now") or structured_question.get("rationale"))
    target_gap = normalize_text(structured_question.get("target_information_gap")) or resolved_question_key
    return {
        "question_id": normalize_text(structured_question.get("question_id")) or f"question::{resolved_question_key}",
        "question_key": resolved_question_key,
        "field_key": carrier_field,
        "question_text": question_text,
        "target_field_keys": [carrier_field],
        "rationale": normalize_text(structured_question.get("rationale")) or "structured_model",
        "expected_answer_type": normalize_text(structured_question.get("expected_answer_type")) or "text",
        "priority": _safe_int(structured_question.get("priority"), 1),
        "blocking": bool(structured_question.get("blocking", True)),
        "planning_source": "structured_model",
        "source": "structured_model",
        "why_now": why_now,
        "target_information_gap": target_gap,
        "options": resolve_options_fn(structured_question),
        "question_decision": build_question_decision(
            selected_field_key=carrier_field,
            candidate_information_gaps=[],
            field_scores=field_scores,
            planning_source="structured_model",
            why_now=why_now,
            target_information_gap=target_gap,
            session_state=session_state,
        ),
    }


__all__ = ["resolve_structured_question_plan"]
