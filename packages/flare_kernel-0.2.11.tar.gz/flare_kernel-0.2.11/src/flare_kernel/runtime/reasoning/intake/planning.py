"""Planning facade for intake reasoning."""

from __future__ import annotations

from flare_kernel.runtime.reasoning.intake.field_selection import select_active_fields
from flare_kernel.runtime.reasoning.intake.gap_detection import detect_candidate_information_gaps
from flare_kernel.runtime.reasoning.intake.question.planner import (
    plan_next_question,
    plan_next_question_based_on_understanding,
)

__all__ = [
    "detect_candidate_information_gaps",
    "plan_next_question",
    "plan_next_question_based_on_understanding",
    "select_active_fields",
]
