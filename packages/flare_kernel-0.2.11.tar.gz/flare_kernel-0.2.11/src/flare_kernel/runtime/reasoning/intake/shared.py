"""Shared helpers for generic intake reasoning."""

from __future__ import annotations

from typing import Any

DEFAULT_ANALYSIS_THRESHOLD = 0.8
DEFAULT_UNDERSTANDING_SCORE_THRESHOLD = 0.75

GENERIC_OTHER_OPTION = {
    "key": "other",
    "label": "其他（我来输入）",
    "value": "",
    "requires_custom_input": True,
}

def coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def normalize_text(value: Any) -> str:
    return str(value or "").strip()


def normalize_field_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    seen: set[str] = set()
    fields: list[str] = []
    for item in value:
        key = normalize_text(item)
        if not key or key in seen:
            continue
        seen.add(key)
        fields.append(key)
    return fields


def has_value(value: Any) -> bool:
    return value not in (None, "", [], {})


def contains_any_term(text: str, terms: tuple[str, ...]) -> bool:
    lowered = normalize_text(text).lower()
    if not lowered:
        return False
    return any(str(term).lower() in lowered for term in terms if str(term).strip())


def clamp_score(value: float) -> float:
    return max(0.0, min(1.0, value))
