"""Active field selection for intake reasoning."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.branching.core import (
    infer_branch_state,
    resolve_branch_field_scope,
)
from flare_kernel.runtime.reasoning.intake.context import _infer_understood_context
from flare_kernel.runtime.reasoning.intake.shared import (
    coerce_mapping,
    has_value,
    normalize_field_list,
    normalize_text,
)


def _criticality_score(criticality: str) -> float:
    normalized = normalize_text(criticality).lower()
    if normalized == "critical":
        return 1.0
    if normalized == "important":
        return 0.75
    if normalized == "supplementary":
        return 0.4
    return 0.55


def select_active_fields(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    structured_output: dict[str, Any] | None = None,
) -> dict[str, Any]:
    structured = coerce_mapping(structured_output)
    if isinstance(structured.get("active_fields"), list):
        active_fields = normalize_field_list(structured.get("active_fields"))
        deferred_fields = normalize_field_list(structured.get("deferred_fields"))
        low_relevance_fields = normalize_field_list(structured.get("low_relevance_fields"))
        if active_fields:
            return {
                "active_fields": active_fields,
                "deferred_fields": deferred_fields,
                "low_relevance_fields": low_relevance_fields,
                "field_scores": coerce_mapping(structured.get("field_scores")),
                "selection_source": "structured_model",
            }

    confirmed_fields = coerce_mapping(session_state.get("confirmed_fields"))
    understood_context = _infer_understood_context(
        session_state=session_state,
        latest_input=normalize_text(session_state.get("latest_input")),
    )
    branch_resolution = infer_branch_state(
        session_state=session_state,
        latest_input=normalize_text(session_state.get("latest_input")),
        domain_context=domain_context,
        understood_context=understood_context,
    )
    branch_scope = resolve_branch_field_scope(
        policy=branch_resolution.get("policy", {}),
        branch_state=branch_resolution.get("branch_state", {}),
    )
    required_fields = normalize_field_list(domain_context.get("required_fields"))
    recommended_fields = normalize_field_list(domain_context.get("recommended_fields"))
    optional_fields = normalize_field_list(domain_context.get("optional_fields"))
    field_semantics = coerce_mapping(domain_context.get("field_semantics"))
    branch_hints = coerce_mapping(domain_context.get("branch_hints"))
    affinity_map = coerce_mapping(branch_hints.get("hypothesis_field_affinity"))

    scope = normalize_field_list([*required_fields, *recommended_fields, *optional_fields])
    missing = [field for field in scope if not has_value(confirmed_fields.get(field))]

    field_scores: dict[str, float] = {}
    field_hypothesis_support: dict[str, float] = {}
    for field in missing:
        semantics = coerce_mapping(field_semantics.get(field))
        criticality = normalize_text(semantics.get("criticality")).lower()
        score = _criticality_score(criticality)
        if field in required_fields:
            score += 0.2 if criticality == "critical" else 0.05
        analyzability_weight = semantics.get("analyzability_weight")
        try:
            score += max(0.0, float(analyzability_weight or 0.0)) * 0.15
        except (TypeError, ValueError):
            pass

        relevance_by_hypothesis = coerce_mapping(semantics.get("relevance_by_hypothesis"))
        support = 0.0
        for hypothesis in hypotheses:
            hypothesis_id = normalize_text(hypothesis.get("id"))
            try:
                hypothesis_score = max(0.0, float(hypothesis.get("score") or 0.0))
            except (TypeError, ValueError):
                hypothesis_score = 0.0
            if not hypothesis_id or hypothesis_score <= 0:
                continue

            affinity_scores = coerce_mapping(affinity_map.get(hypothesis_id))
            try:
                affinity_weight = max(0.0, float(affinity_scores.get(field) or 0.0))
            except (TypeError, ValueError):
                affinity_weight = 0.0
            score += affinity_weight * hypothesis_score
            support += affinity_weight * hypothesis_score

            try:
                relevance_weight = max(0.0, float(relevance_by_hypothesis.get(hypothesis_id) or 0.0))
            except (TypeError, ValueError):
                relevance_weight = 0.0
            score += relevance_weight * hypothesis_score
            support += relevance_weight * hypothesis_score

        field_scores[field] = score
        field_hypothesis_support[field] = support

    active_fields: list[str] = []
    deferred_fields: list[str] = []
    low_relevance_fields: list[str] = []

    for field in sorted(missing, key=lambda key: field_scores.get(key, 0.0), reverse=True):
        score = field_scores.get(field, 0.0)
        in_required = field in required_fields
        criticality = normalize_text(coerce_mapping(field_semantics.get(field)).get("criticality")).lower()
        support = field_hypothesis_support.get(field, 0.0)
        threshold = 0.95 if in_required else 1.05
        if score >= threshold:
            active_fields.append(field)
            continue
        if in_required and score >= 0.65 and (criticality == "critical" or support >= 0.2):
            active_fields.append(field)
            continue
        deferred_fields.append(field)
        if score < 0.65:
            low_relevance_fields.append(field)

    branch_active_fields = normalize_field_list(branch_scope.get("active_fields"))
    branch_preferred_fields = normalize_field_list(branch_scope.get("preferred_fields"))
    branch_suppressed_fields = set(normalize_field_list(branch_scope.get("suppressed_fields")))
    if branch_suppressed_fields:
        active_fields = [field for field in active_fields if field not in branch_suppressed_fields]
        deferred_fields = [field for field in deferred_fields if field not in branch_suppressed_fields]
        low_relevance_fields = [field for field in low_relevance_fields if field not in branch_suppressed_fields]
    if branch_active_fields:
        prioritized_active = [field for field in branch_active_fields if field in set(missing)]
        active_set = set(prioritized_active)
        active_fields = prioritized_active + [field for field in active_fields if field not in active_set and field not in branch_suppressed_fields]
        deferred_fields = [
            field
            for field in deferred_fields
            if field not in set(prioritized_active)
        ]

    if not active_fields and missing:
        active_fields.append(max(missing, key=lambda key: field_scores.get(key, 0.0)))
        deferred_fields = [field for field in missing if field not in set(active_fields)]
        low_relevance_fields = [field for field in deferred_fields if field_scores.get(field, 0.0) < 0.65]

    return {
        "active_fields": active_fields,
        "deferred_fields": deferred_fields,
        "low_relevance_fields": low_relevance_fields,
        "field_scores": field_scores,
        "selection_source": "scored_dynamic",
        "branch_state": branch_resolution.get("branch_state", {}),
        "active_branch_path": branch_resolution.get("active_branch_path", []),
        "branch_policy_active": bool(branch_resolution.get("policy", {}).get("branch_nodes")),
        "branch_active_fields": branch_active_fields,
        "branch_preferred_fields": branch_preferred_fields,
        "branch_suppressed_fields": list(branch_suppressed_fields),
    }


__all__ = ["select_active_fields"]
