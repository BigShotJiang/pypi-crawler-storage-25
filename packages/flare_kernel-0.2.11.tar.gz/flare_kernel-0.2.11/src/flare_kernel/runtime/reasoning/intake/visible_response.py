"""User-visible response assembly for intake reasoning."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.shared import (
    coerce_mapping,
    normalize_text,
)
from flare_kernel.runtime.reasoning.intake.visible_summary import (
    build_structured_intake_summary_response,
)


def _compact_goal_text(text: str, *, limit: int = 72) -> str:
    """Keep fallback goal labels short without changing their meaning."""
    cleaned = normalize_text(text)
    if len(cleaned) <= limit:
        return cleaned
    return f"{cleaned[:limit].rstrip()}…"


def _resolve_goal_label(*, context_phrase: str, raw_goal: str) -> str:
    """Prefer normalized intake context, then fall back to the raw user goal."""
    if context_phrase:
        return context_phrase
    return _compact_goal_text(raw_goal)


def _build_solution_first_response(*, context_phrase: str, raw_goal: str, question_text: str) -> str:
    """Build the deterministic intake response without phrase-trigger branches.

    Intake may still ask one calibration question, but the visible answer must
    first give a useful direction so normal dialogue does not collapse into
    mechanical field collection.
    """
    goal_label = _resolve_goal_label(context_phrase=context_phrase, raw_goal=raw_goal)
    context_summary = f"我先按“{goal_label}”来理解你的需求。" if goal_label else "我先按你的目标来理解。"
    return (
        f"{context_summary}\n"
        "先给一个可推进的初步版本，后续细节只用于校准，不作为当前回复的阻塞条件：\n"
        "1. 当前判断：大方向已经可以先进入方案讨论，只是结论精度还需要后续校准。\n"
        "2. 建议路径：先形成主方案、可选路径、比较口径和风险假设，再逐步补齐关键事实。\n"
        "3. 下一步动作：我可以先帮你整理一版初稿/清单/判断框架，然后根据你的补充继续收敛。\n"
        f"为了让下一版更贴近实际，我优先确认：{question_text}"
    ).strip()


def _resolve_visible_question_text(*, question: dict[str, Any], next_question: dict[str, Any]) -> str:
    next_question_text = normalize_text(next_question.get("question_text"))
    question_text = normalize_text(question.get("question_text"))
    question_field_key = normalize_text(question.get("field_key"))
    next_question_key = normalize_text(
        next_question.get("question_key")
        or next_question.get("field_key")
        or next_question.get("target_information_gap")
    )
    if next_question_text and question_field_key and question_field_key == next_question_key:
        return next_question_text
    return question_text or next_question_text


def build_user_visible_intake_response(
    *,
    understanding_state: dict[str, Any] | None,
    current_question: dict[str, Any] | None = None,
    confirmed_fields: dict[str, Any] | None = None,
    missing_fields: list[Any] | None = None,
    field_definitions_by_key: dict[str, Any] | None = None,
    readiness: dict[str, Any] | None = None,
) -> str:
    """Convert intake state into a user-visible, solution-first response."""
    state = coerce_mapping(understanding_state)
    context = coerce_mapping(state.get("understood_context"))
    next_question = coerce_mapping(state.get("current_best_next_question"))
    has_understanding_signal = bool(state) and (
        bool(context)
        or bool(next_question)
        or bool(normalize_text(state.get("raw_user_goal")))
    )
    has_summary_signal = bool(confirmed_fields or missing_fields)
    if not has_understanding_signal:
        if not has_summary_signal:
            return ""
        context = {}
        next_question = {}
        state = {}
    question = coerce_mapping(current_question) if isinstance(current_question, dict) else {}

    context_phrase = normalize_text(context.get("context_phrase"))
    raw_goal = normalize_text(state.get("raw_user_goal"))
    question_text = _resolve_visible_question_text(question=question, next_question=next_question)
    structured_summary = build_structured_intake_summary_response(
        context_phrase=context_phrase,
        raw_goal=raw_goal,
        question_text=question_text,
        confirmed_fields=confirmed_fields,
        missing_fields=missing_fields,
        field_definitions_by_key=field_definitions_by_key,
        readiness=coerce_mapping(readiness),
    )
    if structured_summary:
        return structured_summary

    if not question_text:
        return ""
    return _build_solution_first_response(
        context_phrase=context_phrase,
        raw_goal=raw_goal,
        question_text=question_text,
    )


__all__ = ["build_user_visible_intake_response"]
