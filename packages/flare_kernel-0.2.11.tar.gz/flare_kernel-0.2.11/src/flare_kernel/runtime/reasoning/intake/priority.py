"""Priority tuning helpers for intake question planning.

Core remains neutral by default. Priority bias is only applied when domain pack
provides explicit policy configuration.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.shared import (
    coerce_mapping,
    contains_any_term,
    has_value,
    normalize_text,
)

_CATEGORY_HINTS = (
    "category",
    "type",
    "nature",
    "classification",
    "品类",
    "类别",
    "性质",
    "场景",
    "业务类型",
)

_SUBJECT_HINTS = (
    "subject",
    "owner",
    "executor",
    "sponsor",
    "actor",
    "执行主体",
    "主体",
    "主办",
    "承办",
    "组织方",
    "甲方",
)


def classify_field_roles(field_key: str, definition: dict[str, Any] | None = None) -> set[str]:
    """Classify a field into semantic roles used by question priority tuning."""
    node = coerce_mapping(definition)
    merged_text = " ".join(
        part
        for part in (
            normalize_text(field_key),
            normalize_text(node.get("label")),
            normalize_text(node.get("question")),
        )
        if part
    ).lower()
    roles: set[str] = set()
    if contains_any_term(merged_text, _CATEGORY_HINTS):
        roles.add("category")
    if contains_any_term(merged_text, _SUBJECT_HINTS):
        roles.add("subject")
    return roles


def score_direction_priority_adjustment(
    *,
    field_key: str,
    definition: dict[str, Any] | None,
    confirmed_fields: dict[str, Any],
    field_definitions: dict[str, dict[str, Any]],
    policy: dict[str, Any] | None = None,
) -> tuple[float, list[str]]:
    """Return additive priority score/reasons from domain-pack policy."""
    policy_node = coerce_mapping(policy)
    if not policy_node or policy_node.get("enabled") is not True:
        return 0.0, []

    roles = classify_field_roles(field_key, definition)
    if not roles:
        return 0.0, []

    def _is_role_confirmed(role_name: str) -> bool:
        for key, value in confirmed_fields.items():
            if not has_value(value):
                continue
            role_set = classify_field_roles(str(key or ""), field_definitions.get(str(key or "")))
            if role_name in role_set:
                return True
        return False

    category_confirmed = _is_role_confirmed("category")
    subject_confirmed = _is_role_confirmed("subject")
    goal_confirmed = has_value(confirmed_fields.get("goal"))

    score = 0.0
    reasons: list[str] = []
    try:
        category_weight = float(policy_node.get("category_weight") or 0.0)
    except (TypeError, ValueError):
        category_weight = 0.0
    try:
        subject_after_category_weight = float(policy_node.get("subject_after_category_weight") or 0.0)
    except (TypeError, ValueError):
        subject_after_category_weight = 0.0
    try:
        subject_before_category_weight = float(policy_node.get("subject_before_category_weight") or 0.0)
    except (TypeError, ValueError):
        subject_before_category_weight = 0.0
    try:
        goal_defined_category_bonus = float(policy_node.get("goal_defined_category_bonus") or 0.0)
    except (TypeError, ValueError):
        goal_defined_category_bonus = 0.0

    if "category" in roles and not category_confirmed:
        score += max(0.0, category_weight)
        reasons.append("pack_direction_category")
        if goal_confirmed:
            score += max(0.0, goal_defined_category_bonus)
            reasons.append("pack_goal_defined_category_bonus")
    if "subject" in roles and not subject_confirmed:
        if category_confirmed:
            score += max(0.0, subject_after_category_weight)
            reasons.append("pack_direction_subject_after_category")
        else:
            score += max(0.0, subject_before_category_weight)
            reasons.append("pack_direction_subject_before_category")
    return score, reasons
