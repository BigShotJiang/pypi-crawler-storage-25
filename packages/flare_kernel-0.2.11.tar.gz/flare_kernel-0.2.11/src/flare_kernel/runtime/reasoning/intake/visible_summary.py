"""Structured summary assembly for long requirement-intake prompts."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.shared import normalize_text


def _coerce_field_definition_map(value: Any) -> dict[str, dict[str, Any]]:
    """Normalize field-definition contracts into a lookup map for rendering.

    The visible summary layer must not know procurement fields, report fields,
    or any instance-specific vocabulary. It can only use field definitions that
    have already crossed the orchestration contract boundary. This helper keeps
    that boundary explicit by accepting the map shape emitted by coverage
    assembly, discarding invalid entries, and returning a label lookup that the
    summary renderer can consume without introducing business-specific fallback
    constants.
    """
    if not isinstance(value, dict):
        return {}
    definitions: dict[str, dict[str, Any]] = {}
    for key, definition in value.items():
        field_key = normalize_text(key)
        if field_key and isinstance(definition, dict):
            definitions[field_key] = definition
    return definitions


def _format_field_value(value: Any) -> str:
    """Convert a collected field value into compact text for visible rows.

    Intake fields may arrive as strings, selected option payloads, or simple
    lists from composer batch submission. The renderer preserves the confirmed
    meaning while avoiding raw Python representations in the visible answer.
    Unknown complex objects are not interpreted here because semantic
    canonicalization belongs to intake reasoning, not response formatting.
    """
    if isinstance(value, list):
        parts = [normalize_text(item) for item in value]
        return "、".join(part for part in parts if part)
    if isinstance(value, dict):
        for key in ("value", "label", "text", "field_value", "raw_value"):
            text = normalize_text(value.get(key))
            if text:
                return text
        return ""
    return normalize_text(value)


def _resolve_field_label(field_key: str, definitions: dict[str, dict[str, Any]]) -> str:
    """Resolve a display label from explicit field definitions only.

    This helper intentionally avoids hardcoded labels. If the domain pack or
    payload supplied a label, that label is used; otherwise the field key is
    shown as the safest transparent fallback so reviewers can see exactly which
    canonical field is being discussed.
    """
    definition = definitions.get(field_key, {})
    return normalize_text(definition.get("label") or definition.get("name") or field_key)


def _build_confirmed_field_rows(
    *,
    confirmed_fields: dict[str, Any] | None,
    definitions: dict[str, dict[str, Any]],
    limit: int = 8,
) -> list[tuple[str, str]]:
    """Project confirmed canonical fields into ordered summary rows.

    The intake state remains authoritative; this helper only selects visible
    non-empty values and resolves their labels. It preserves the field order
    provided by orchestration, caps the row count to keep long-prompt replies
    readable, and returns tuples so downstream rendering stays deterministic.
    """
    if not isinstance(confirmed_fields, dict):
        return []
    rows: list[tuple[str, str]] = []
    for key, value in confirmed_fields.items():
        field_key = normalize_text(key)
        field_value = _format_field_value(value)
        if not field_key or not field_value:
            continue
        rows.append((_resolve_field_label(field_key, definitions), field_value))
        if len(rows) >= limit:
            break
    return rows


def _build_missing_field_rows(
    *,
    missing_fields: list[Any] | None,
    definitions: dict[str, dict[str, Any]],
    limit: int = 6,
) -> list[str]:
    """Project missing canonical fields into label-only gap rows.

    Missing fields are already selected by orchestration and question planning.
    The response layer therefore does not decide which gaps matter; it only
    translates canonical field keys into user-facing labels using the same field
    definition contract as the Canvas and chooser projections.
    """
    if not isinstance(missing_fields, list):
        return []
    rows: list[str] = []
    for field_key_value in missing_fields:
        field_key = normalize_text(field_key_value)
        if not field_key:
            continue
        rows.append(_resolve_field_label(field_key, definitions))
        if len(rows) >= limit:
            break
    return rows


def _looks_like_long_prompt(raw_goal: str) -> bool:
    """Detect whether latest user input has dense long-prompt shape.

    PLN-08 is about response shape, not domain classification. This helper only
    checks generic text density signals such as length, line breaks, and clause
    separators. It deliberately avoids trigger words and business vocabulary so
    the reusable intake layer does not learn procurement-specific heuristics.
    """
    text = normalize_text(raw_goal)
    if len(text) >= 96:
        return True
    separator_count = sum(text.count(mark) for mark in ("，", "。", "；", ";", ",", "."))
    return raw_goal.count("\n") >= 2 or separator_count >= 4


def _should_render_structured_summary(
    *,
    raw_goal: str,
    confirmed_rows: list[tuple[str, str]],
    missing_rows: list[str],
) -> bool:
    """Decide when the visible response should become a structured summary.

    The decision is intentionally based on generic input density and canonical
    coverage projection rather than field names. Short conversational turns keep
    the existing solution-first response; dense long prompts or already-rich
    field coverage get a summary that can be reused as downstream context.
    """
    if _looks_like_long_prompt(raw_goal):
        return bool(raw_goal or confirmed_rows or missing_rows)
    return len(confirmed_rows) >= 3


def _resolve_goal_label(*, context_phrase: str, raw_goal: str, limit: int = 72) -> str:
    """Resolve a compact fallback label when no confirmed field row exists.

    The primary summary content should come from confirmed canonical fields. If
    none exist yet, this helper uses normalized context or raw input so a long
    prompt still produces a reusable summary shell instead of an empty response.
    """
    label = normalize_text(context_phrase) or normalize_text(raw_goal)
    if len(label) <= limit:
        return label
    return f"{label[:limit].rstrip()}…"


def _render_structured_summary(
    *,
    context_phrase: str,
    raw_goal: str,
    question_text: str,
    confirmed_rows: list[tuple[str, str]],
    missing_rows: list[str],
    readiness: dict[str, Any],
) -> str:
    """Render the deterministic long-prompt intake summary.

    The output is prompt-ready: confirmed information first, explicit gaps
    second, and next action path last. It does not mutate workflow state and
    does not select fields; all authoritative decisions have already happened
    upstream. The final question is kept as a calibration pointer when
    available, but it no longer replaces the summary body.
    """
    goal_label = _resolve_goal_label(context_phrase=context_phrase, raw_goal=raw_goal)
    lines = ["我先把这段需求收敛成可复用的需求摘要，后续分析或执行会以它作为上下文。"]
    if goal_label and not confirmed_rows:
        lines.extend(["", f"需求概述：{goal_label}"])

    lines.extend(["", "已确认信息："])
    if confirmed_rows:
        lines.extend(f"{index}. {label}：{value}" for index, (label, value) in enumerate(confirmed_rows, start=1))
    else:
        lines.append("1. 暂未抽取到明确字段，先保留用户原始描述作为上下文。")

    lines.extend(["", "关键缺口："])
    if missing_rows:
        lines.extend(f"{index}. {label}：待确认" for index, label in enumerate(missing_rows, start=1))
    else:
        lines.append("1. 当前没有识别到阻塞性缺口；后续仍可把不确定内容标注为待验证。")

    lines.extend(["", "下一步动作："])
    if readiness.get("analysis_entry_eligible") or readiness.get("can_analyze"):
        lines.append("1. 可以基于已确认信息进入分析或执行草案，并把未验证项显式标注。")
    else:
        lines.append("1. 可以先生成带假设说明的初稿，同时把关键缺口作为校准项。")
    if question_text:
        lines.append(f"2. 若继续补齐，优先确认：{question_text}")
    else:
        lines.append("2. 若继续补齐，优先补充上方关键缺口。")
    return "\n".join(lines).strip()


def build_structured_intake_summary_response(
    *,
    context_phrase: str,
    raw_goal: str,
    question_text: str,
    confirmed_fields: dict[str, Any] | None,
    missing_fields: list[Any] | None,
    field_definitions_by_key: dict[str, Any] | None,
    readiness: dict[str, Any],
) -> str:
    """Build a PLN-08 summary response when long-prompt conditions are met.

    Callers pass canonical intake state and field definitions; this function
    performs only deterministic projection and rendering. It returns an empty
    string when the input should keep the older short-turn response style, which
    lets `visible_response` remain a small coordinator instead of owning the
    detailed summary assembly.
    """
    definitions = _coerce_field_definition_map(field_definitions_by_key)
    confirmed_rows = _build_confirmed_field_rows(confirmed_fields=confirmed_fields, definitions=definitions)
    missing_rows = _build_missing_field_rows(missing_fields=missing_fields, definitions=definitions)
    if not _should_render_structured_summary(
        raw_goal=raw_goal,
        confirmed_rows=confirmed_rows,
        missing_rows=missing_rows,
    ):
        return ""
    return _render_structured_summary(
        context_phrase=context_phrase,
        raw_goal=raw_goal,
        question_text=question_text,
        confirmed_rows=confirmed_rows,
        missing_rows=missing_rows,
        readiness=readiness,
    )


__all__ = ["build_structured_intake_summary_response"]
