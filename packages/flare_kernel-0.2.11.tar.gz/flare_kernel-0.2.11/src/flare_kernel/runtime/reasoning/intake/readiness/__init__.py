"""Readiness helpers for intake reasoning."""
