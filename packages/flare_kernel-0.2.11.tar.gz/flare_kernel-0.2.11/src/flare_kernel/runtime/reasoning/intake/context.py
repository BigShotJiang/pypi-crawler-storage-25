"""Understanding-context builders for generic intake reasoning."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.shared import (
    DEFAULT_ANALYSIS_THRESHOLD,
    coerce_mapping,
    normalize_field_list,
    normalize_text,
)
from flare_kernel.runtime.reasoning.intake.branching.policy import (
    normalize_branching_policy,
)

def _normalize_field_options(options: Any) -> list[Any]:
    if not isinstance(options, list):
        return []
    normalized: list[Any] = []
    for item in options:
        if isinstance(item, dict):
            label = normalize_text(item.get("label") or item.get("text") or item.get("value"))
            if label:
                normalized.append(dict(item))
            continue
        label = normalize_text(item)
        if label:
            normalized.append(label)
    return normalized


def _infer_understood_context(
    *,
    session_state: dict[str, Any],
    latest_input: str,
) -> dict[str, str]:
    confirmed_fields = coerce_mapping(session_state.get("confirmed_fields"))
    del latest_input

    confirmed_values = [
        normalize_text(value)
        for value in confirmed_fields.values()
        if normalize_text(value)
    ]
    if not confirmed_values:
        return {}
    return {"context_phrase": " / ".join(confirmed_values[:2])}


def _normalize_field_definitions(field_definitions: Any) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    if isinstance(field_definitions, list):
        for node in field_definitions:
            if not isinstance(node, dict):
                continue
            key = normalize_text(node.get("key"))
            if not key:
                continue
            normalized.append(
                {
                    "key": key,
                    "label": normalize_text(node.get("label")) or key,
                    "priority": normalize_text(node.get("priority") or "optional") or "optional",
                    "blocker": bool(node.get("blocker", normalize_text(node.get("priority")) == "required")),
                    "question": normalize_text(node.get("question")),
                    "options": _normalize_field_options(node.get("options")),
                }
            )
    return normalized


def build_intake_domain_context(
    *,
    payload: dict[str, Any],
    domain_pack: dict[str, Any] | None,
    field_definitions: list[dict[str, Any]] | None = None,
    required_fields: list[str] | None = None,
    recommended_fields: list[str] | None = None,
    optional_fields: list[str] | None = None,
) -> dict[str, Any]:
    pack_fields = coerce_mapping(coerce_mapping(domain_pack).get("fields"))
    pack_workflow = coerce_mapping(coerce_mapping(domain_pack).get("workflow"))
    pack_taxonomy = coerce_mapping(coerce_mapping(domain_pack).get("taxonomy"))

    normalized_definitions = _normalize_field_definitions(field_definitions)
    if not normalized_definitions:
        normalized_definitions = _normalize_field_definitions(payload.get("field_definitions"))
    if not normalized_definitions:
        normalized_definitions = _normalize_field_definitions(pack_fields.get("field_definitions"))

    normalized_required = normalize_field_list(required_fields)
    normalized_recommended = normalize_field_list(recommended_fields)
    normalized_optional = normalize_field_list(optional_fields)

    if not normalized_required and isinstance(payload.get("required_fields"), list):
        normalized_required = normalize_field_list(payload.get("required_fields"))
    if not normalized_required and isinstance(pack_fields.get("required_fields"), list):
        normalized_required = normalize_field_list(pack_fields.get("required_fields"))
    if not normalized_required:
        normalized_required = [
            str(item.get("key"))
            for item in normalized_definitions
            if isinstance(item, dict) and normalize_text(item.get("priority")).lower() == "required"
        ]

    if not normalized_recommended:
        normalized_recommended = [
            str(item.get("key"))
            for item in normalized_definitions
            if isinstance(item, dict) and normalize_text(item.get("priority")).lower() == "recommended"
        ]

    if not normalized_optional:
        normalized_optional = [
            str(item.get("key"))
            for item in normalized_definitions
            if isinstance(item, dict) and normalize_text(item.get("priority")).lower() not in {"required", "recommended"}
        ]

    ontology = coerce_mapping(pack_fields.get("ontology"))
    hypotheses = ontology.get("hypotheses") if isinstance(ontology.get("hypotheses"), list) else []
    if not hypotheses:
        hypotheses = [{"id": "general_intake", "label": "General Intake", "description": "Generic requirement intake."}]

    field_semantics = coerce_mapping(pack_fields.get("field_semantics"))
    if not field_semantics:
        generated_semantics: dict[str, Any] = {}
        for item in normalized_definitions:
            key = normalize_text(item.get("key"))
            if not key:
                continue
            options = item.get("options") if isinstance(item.get("options"), list) else []
            priority = normalize_text(item.get("priority") or "optional").lower()
            generated_semantics[key] = {
                "value_type": "enum" if options else "text",
                "criticality": "critical" if priority == "required" else ("important" if priority == "recommended" else "supplementary"),
                "analyzability_weight": 1.0 if priority == "required" else (0.7 if priority == "recommended" else 0.4),
            }
        field_semantics = generated_semantics

    priors = coerce_mapping(pack_fields.get("priors"))
    taxonomy_priors = coerce_mapping(pack_taxonomy.get("priors"))
    if taxonomy_priors:
        merged = dict(priors)
        for key, value in taxonomy_priors.items():
            if key not in merged:
                merged[key] = value
        priors = merged

    branch_hints = coerce_mapping(pack_fields.get("branch_hints"))
    taxonomy_branch_hints = coerce_mapping(pack_taxonomy.get("branch_hints"))
    if taxonomy_branch_hints:
        merged = dict(branch_hints)
        for key, value in taxonomy_branch_hints.items():
            if key not in merged:
                merged[key] = value
        branch_hints = merged

    raw_branching_policy = payload.get("branching_chooser_policy")
    if not isinstance(raw_branching_policy, dict):
        raw_branching_policy = pack_workflow.get("branching_chooser_policy")
    branching_chooser_policy = normalize_branching_policy(raw_branching_policy)

    raw_threshold = payload.get("analysis_entry_threshold")
    if raw_threshold is None:
        raw_threshold = pack_workflow.get("analysis_entry_threshold")
    try:
        analysis_entry_threshold = float(raw_threshold)
    except (TypeError, ValueError):
        analysis_entry_threshold = DEFAULT_ANALYSIS_THRESHOLD
    analysis_entry_threshold = max(0.0, min(1.0, analysis_entry_threshold))

    return {
        "field_definitions": normalized_definitions,
        "required_fields": normalized_required,
        "recommended_fields": normalized_recommended,
        "optional_fields": normalized_optional,
        "ontology": {
            "hypotheses": [node for node in hypotheses if isinstance(node, dict) and normalize_text(node.get("id"))],
            "dimensions": ontology.get("dimensions") if isinstance(ontology.get("dimensions"), list) else [],
        },
        "field_semantics": field_semantics,
        "priors": priors,
        "branch_hints": branch_hints,
        "analysis_entry_threshold": analysis_entry_threshold,
        "branching_chooser_policy": branching_chooser_policy,
    }
