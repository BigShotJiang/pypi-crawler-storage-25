"""Intake reasoning runtime package."""

from __future__ import annotations

import importlib
import sys

from flare_kernel.runtime.reasoning.intake.api import (
    build_intake_domain_context,
    build_user_visible_intake_response,
    evaluate_readiness,
    infer_hypotheses,
    plan_next_question,
)

_LEGACY_MODULE_TARGETS = {
    "question_builder": "flare_kernel.runtime.reasoning.intake.question.builder",
    "question_extraction": "flare_kernel.runtime.reasoning.intake.question.extraction",
    "question_planner": "flare_kernel.runtime.reasoning.intake.question.planner",
    "readiness": "flare_kernel.runtime.reasoning.intake.readiness.core",
    "readiness_scoring": "flare_kernel.runtime.reasoning.intake.readiness.scoring",
    "branching": "flare_kernel.runtime.reasoning.intake.branching.core",
    "branching_policy": "flare_kernel.runtime.reasoning.intake.branching.policy",
}

for _legacy_name, _target in _LEGACY_MODULE_TARGETS.items():
    sys.modules.setdefault(
        f"flare_kernel.runtime.reasoning.intake.{_legacy_name}",
        importlib.import_module(_target),
    )

__all__ = [
    "build_intake_domain_context",
    "build_user_visible_intake_response",
    "evaluate_readiness",
    "infer_hypotheses",
    "plan_next_question",
]
