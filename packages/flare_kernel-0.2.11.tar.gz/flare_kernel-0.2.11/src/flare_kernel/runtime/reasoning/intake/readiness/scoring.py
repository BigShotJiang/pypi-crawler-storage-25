"""Readiness and analyzability scoring for intake reasoning."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.context import _infer_understood_context
from flare_kernel.runtime.reasoning.intake.planning import detect_candidate_information_gaps
from flare_kernel.runtime.reasoning.intake.shared import (
    DEFAULT_ANALYSIS_THRESHOLD,
    DEFAULT_UNDERSTANDING_SCORE_THRESHOLD,
    clamp_score,
    coerce_mapping,
    has_value,
    normalize_field_list,
    normalize_text,
)


def evaluate_analyzability(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    field_selection: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    candidate_information_gaps: list[dict[str, Any]] | None = None,
    threshold: float | None = None,
) -> dict[str, Any]:
    fields = coerce_mapping(session_state.get("confirmed_fields"))
    required_fields = normalize_field_list(domain_context.get("required_fields"))
    recommended_fields = normalize_field_list(domain_context.get("recommended_fields"))
    field_semantics = coerce_mapping(domain_context.get("field_semantics"))

    if threshold is None:
        raw_threshold = domain_context.get("analysis_entry_threshold")
        try:
            threshold_value = float(raw_threshold)
        except (TypeError, ValueError):
            threshold_value = DEFAULT_UNDERSTANDING_SCORE_THRESHOLD
    else:
        threshold_value = threshold
    threshold_value = clamp_score(float(threshold_value))

    active_fields = normalize_field_list(field_selection.get("active_fields"))
    active_required_fields = [field for field in required_fields if field in set(active_fields)]
    if not active_required_fields:
        active_required_fields = list(required_fields)
    active_recommended_fields = [field for field in recommended_fields if field in set(active_fields)]
    total_scope = normalize_field_list([*active_required_fields, *active_recommended_fields])
    if not total_scope:
        total_scope = list(active_required_fields)

    unresolved_critical = [
        field
        for field in active_required_fields
        if not has_value(fields.get(field))
    ]

    required_weight_total = 0.0
    required_weight_collected = 0.0
    total_weight = 0.0
    total_weight_collected = 0.0

    for field in active_required_fields:
        semantics = coerce_mapping(field_semantics.get(field))
        criticality = normalize_text(semantics.get("criticality")).lower()
        try:
            analyzability_weight = max(0.0, float(semantics.get("analyzability_weight") or 0.0))
        except (TypeError, ValueError):
            analyzability_weight = 0.0
        base = 1.0 if criticality == "critical" else 0.82
        weight = base + (analyzability_weight * 0.25)
        required_weight_total += weight
        if has_value(fields.get(field)):
            required_weight_collected += weight

    for field in total_scope:
        semantics = coerce_mapping(field_semantics.get(field))
        criticality = normalize_text(semantics.get("criticality")).lower()
        try:
            analyzability_weight = max(0.0, float(semantics.get("analyzability_weight") or 0.0))
        except (TypeError, ValueError):
            analyzability_weight = 0.0
        criticality_base = 1.0 if criticality == "critical" else (0.72 if criticality == "important" else 0.5)
        weight = criticality_base + (analyzability_weight * 0.2)
        total_weight += weight
        if has_value(fields.get(field)):
            total_weight_collected += weight

    required_coverage = (required_weight_collected / required_weight_total) if required_weight_total > 0 else 0.0
    total_coverage = (total_weight_collected / total_weight) if total_weight > 0 else 0.0

    uncertainty_level = "high"
    hypothesis_clarity = 0.0
    if hypotheses:
        top_score = float((hypotheses[0] or {}).get("score") or 0.0)
        second_score = float((hypotheses[1] or {}).get("score") or 0.0) if len(hypotheses) > 1 else 0.0
        hypothesis_clarity = max(0.0, top_score - second_score)
        uncertainty_level = "low" if hypothesis_clarity >= 0.25 else ("medium" if hypothesis_clarity >= 0.12 else "high")

    unresolved_penalty = min(0.2, len(unresolved_critical) * 0.06)
    analyzability_score = clamp_score(
        (total_coverage * 0.68)
        + (required_coverage * 0.24)
        + (0.08 if uncertainty_level == "low" else (0.04 if uncertainty_level == "medium" else 0.0))
        - unresolved_penalty
    )
    can_analyze = analyzability_score >= threshold_value

    blocking_reasons: list[str] = []
    if unresolved_critical:
        blocking_reasons.append(f"critical_missing:{','.join(unresolved_critical[:5])}")
    if analyzability_score < threshold_value:
        blocking_reasons.append(f"analyzability_below_threshold:{analyzability_score:.3f}<{threshold_value:.3f}")
    if isinstance(candidate_information_gaps, list) and candidate_information_gaps:
        top_gap = candidate_information_gaps[0]
        if isinstance(top_gap, dict):
            try:
                top_gap_importance = float(top_gap.get("importance") or 0.0)
            except (TypeError, ValueError):
                top_gap_importance = 0.0
            if top_gap_importance >= 0.95 and analyzability_score < (threshold_value + 0.08):
                can_analyze = False
                blocking_reasons.append("high_impact_gap_unresolved")

    confidence = clamp_score(
        (analyzability_score * 0.72)
        + (0.16 if uncertainty_level == "low" else (0.1 if uncertainty_level == "medium" else 0.05))
        + (0.12 if not unresolved_critical else 0.03)
    )

    return {
        "analyzability_score": analyzability_score,
        "can_analyze": can_analyze,
        "analysis_entry_eligible": can_analyze,
        "required_scope_fields": active_required_fields,
        "total_scope_fields": total_scope,
        "required_coverage": required_coverage,
        "total_coverage": total_coverage,
        "analysis_entry_threshold": threshold_value,
        "blocking_reasons": blocking_reasons,
        "unresolved_critical_questions": unresolved_critical,
        "confidence": confidence,
        "uncertainty_level": uncertainty_level,
        "hypothesis_clarity": hypothesis_clarity,
    }


def evaluate_readiness(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    field_selection: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    threshold: float | None = None,
) -> dict[str, Any]:
    candidate_gaps = detect_candidate_information_gaps(
        session_state=session_state,
        domain_context=domain_context,
        hypotheses=hypotheses,
        understood_context=_infer_understood_context(
            session_state=session_state,
            latest_input=normalize_text(session_state.get("latest_input")),
        ),
        field_selection=field_selection,
    ).get("candidate_information_gaps", [])
    analyzability_state = evaluate_analyzability(
        session_state=session_state,
        domain_context=domain_context,
        field_selection=field_selection,
        hypotheses=hypotheses,
        candidate_information_gaps=candidate_gaps if isinstance(candidate_gaps, list) else [],
        threshold=threshold if threshold is not None else domain_context.get("analysis_entry_threshold"),
    )
    return {
        "can_analyze": bool(analyzability_state.get("can_analyze")),
        "analysis_entry_eligible": bool(analyzability_state.get("analysis_entry_eligible")),
        "required_scope_fields": list(analyzability_state.get("required_scope_fields", [])),
        "total_scope_fields": list(analyzability_state.get("total_scope_fields", [])),
        "required_coverage": float(analyzability_state.get("required_coverage") or 0.0),
        "total_coverage": float(analyzability_state.get("total_coverage") or 0.0),
        "analysis_entry_threshold": float(analyzability_state.get("analysis_entry_threshold") or DEFAULT_ANALYSIS_THRESHOLD),
        "blocking_reasons": list(analyzability_state.get("blocking_reasons", [])),
        "unresolved_critical_questions": list(analyzability_state.get("unresolved_critical_questions", [])),
        "confidence": float(analyzability_state.get("confidence") or 0.0),
        "uncertainty_level": normalize_text(analyzability_state.get("uncertainty_level")) or "high",
        "analyzability_score": float(analyzability_state.get("analyzability_score") or 0.0),
        "hypothesis_clarity": float(analyzability_state.get("hypothesis_clarity") or 0.0),
    }


__all__ = ["evaluate_analyzability", "evaluate_readiness"]
