"""Branching helpers for intake reasoning."""
