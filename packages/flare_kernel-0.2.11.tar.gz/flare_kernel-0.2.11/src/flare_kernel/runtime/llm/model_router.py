"""Policy-driven model router for kernel LLM selection."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


_TASK_TYPES = (
    "factual_qa",
    "extraction",
    "planning",
    "reasoning_hard",
    "writing",
    "tool_or_code",
)


@dataclass(frozen=True)
class RoutingContext:
    intent: str
    prompt: str
    session_id: str
    trace_id: str
    mode: str = ""
    project_id: str = ""
    history_summary: str = ""
    urgency: str = "medium"
    has_file: bool = False
    file_types: tuple[str, ...] = ()


@dataclass(frozen=True)
class ModelCandidate:
    provider: str
    model: str
    is_free: bool
    max_context: int
    avg_latency_ms: int
    quality_tier: str
    reasoning_capable: bool
    enabled: bool
    supports_realtime: bool = True
    region: str = "cn"
    stability_score: float = 0.7
    normalized_cost: float = 0.5


@dataclass(frozen=True)
class RouterWeights:
    quality: float = 0.38
    free_bonus: float = 0.22
    context_fit: float = 0.16
    stability: float = 0.14
    cost_penalty: float = 0.06
    latency_penalty: float = 0.04


@dataclass(frozen=True)
class RoutingDecision:
    task_types: tuple[str, ...]
    risk: str
    selected_model: str
    reasoning_level: str
    fallback_model: str
    why: str
    scores: dict[str, float]

    def to_dict(self) -> dict[str, Any]:
        return {
            "task_types": list(self.task_types),
            "risk": self.risk,
            "selected_model": self.selected_model,
            "reasoning_level": self.reasoning_level,
            "fallback_model": self.fallback_model,
            "why": self.why,
            "scores": {k: float(v) for k, v in self.scores.items()},
        }


@dataclass(frozen=True)
class CandidateScore:
    candidate: ModelCandidate
    route_score: float
    quality_score: float
    free_bonus: float
    context_fit_score: float
    stability_score: float
    normalized_cost: float
    normalized_latency: float


def normalize_candidate(raw: dict[str, Any]) -> ModelCandidate:
    provider = str(raw.get("provider") or "").strip().lower()
    model = str(raw.get("model") or "").strip()
    free_value = raw.get("free")
    if free_value is None:
        free_value = raw.get("is_free")
    quality_tier = str(raw.get("quality_tier") or "balanced").strip().lower()
    return ModelCandidate(
        provider=provider,
        model=model,
        is_free=bool(free_value),
        max_context=max(1, int(raw.get("max_context") or 1)),
        avg_latency_ms=max(1, int(raw.get("avg_latency_ms") or 1)),
        quality_tier=quality_tier,
        reasoning_capable=bool(raw.get("reasoning_capable", quality_tier in {"strong", "premium"})),
        enabled=bool(raw.get("enabled", True)),
        supports_realtime=bool(raw.get("supports_realtime", True)),
        region=str(raw.get("region") or "cn").strip().lower(),
        stability_score=_clamp(float(raw.get("stability_score", 0.7))),
        normalized_cost=_clamp(float(raw.get("normalized_cost", raw.get("cost_score", 0.5)))),
    )


def select_model(
    context: RoutingContext,
    candidates: list[ModelCandidate],
    *,
    weights: RouterWeights | None = None,
    default_model: str = "aliyun/qwen-plus",
    provider_preference: tuple[str, ...] = ("aliyun",),
    region_preference: tuple[str, ...] = ("cn",),
    latency_budget_ms: dict[str, int] | None = None,
) -> RoutingDecision:
    resolved_weights = weights or RouterWeights()
    budgets = latency_budget_ms or {"low": 2500, "medium": 6000, "high": 12000}
    task_types = _infer_task_types(context)
    risk = _infer_risk(context, task_types)
    reasoning_level = _infer_reasoning_level(task_types, risk)
    estimated_tokens = estimate_input_tokens(context)

    hard_filtered = _hard_filter(
        candidates,
        estimated_tokens=estimated_tokens,
        task_types=task_types,
        provider_preference=provider_preference,
        region_preference=region_preference,
    )
    active_candidates = hard_filtered if hard_filtered else [item for item in candidates if item.enabled]

    if not active_candidates:
        return RoutingDecision(
            task_types=task_types,
            risk=risk,
            selected_model=default_model,
            reasoning_level=reasoning_level,
            fallback_model=default_model,
            why="候选为空，使用默认模型兜底。",
            scores={},
        )

    scored = _score_candidates(
        active_candidates,
        estimated_tokens=estimated_tokens,
        risk=risk,
        task_types=task_types,
        weights=resolved_weights,
    )
    selected = _choose_primary(scored, risk=risk, task_types=task_types, latency_budget=budgets.get(risk, 6000))
    fallback = _choose_fallback(scored, selected)

    if selected.candidate.provider and selected.candidate.model:
        selected_model = f"{selected.candidate.provider}/{selected.candidate.model}"
    else:
        selected_model = default_model

    if fallback.candidate.provider and fallback.candidate.model:
        fallback_model = f"{fallback.candidate.provider}/{fallback.candidate.model}"
    else:
        fallback_model = selected_model

    why = "在满足效果与风险前提下优先免费候选，并综合上下文适配、稳定性和时延打分。"
    return RoutingDecision(
        task_types=task_types,
        risk=risk,
        selected_model=selected_model,
        reasoning_level=reasoning_level,
        fallback_model=fallback_model,
        why=why,
        scores={
            "selected_route_score": selected.route_score,
            "fallback_route_score": fallback.route_score,
            "estimated_input_tokens": float(estimated_tokens),
        },
    )


def estimate_input_tokens(context: RoutingContext) -> int:
    text = " ".join(
        [
            str(context.prompt or ""),
            str(context.history_summary or ""),
            str(context.intent or ""),
            str(context.mode or ""),
        ]
    ).strip()
    estimated = max(1, len(text) // 4)
    if context.has_file:
        # File-attached tasks tend to include long extracted text in runtime payloads.
        estimated += 120000
    if context.file_types:
        estimated += 20000 * len(context.file_types)
    return estimated


def _infer_task_types(context: RoutingContext) -> tuple[str, ...]:
    text = " ".join(
        [
            str(context.prompt or ""),
            str(context.history_summary or ""),
            str(context.intent or ""),
            str(context.mode or ""),
        ]
    ).lower()

    task_types: list[str] = []

    if any(token in text for token in ("提取", "抽取", "结构化", "json", "table", "字段", "extract")):
        task_types.append("extraction")
    if any(token in text for token in ("计划", "方案", "步骤", "roadmap", "plan", "strategy")):
        task_types.append("planning")
    if any(token in text for token in ("约束", "权衡", "多目标", "tradeoff", "optimiz", "复杂", "推理")):
        task_types.append("reasoning_hard")
    if any(token in text for token in ("改写", "润色", "文案", "rewrite", "polish", "copywriting", "写一段")):
        task_types.append("writing")
    if any(token in text for token in ("代码", "函数", "api", "tool", "调用", "脚本", "bug", "test", "sql")):
        task_types.append("tool_or_code")
    if not task_types or any(token in text for token in ("是什么", "what is", "谁是", "how many", "定义")):
        task_types.append("factual_qa")

    normalized = []
    for task_type in task_types:
        if task_type in _TASK_TYPES and task_type not in normalized:
            normalized.append(task_type)
    return tuple(normalized)


def _infer_risk(context: RoutingContext, task_types: tuple[str, ...]) -> str:
    text = " ".join([str(context.prompt or ""), str(context.history_summary or "")]).lower()
    high_risk_terms = (
        "合同",
        "法律",
        "财务",
        "医疗",
        "合规",
        "production",
        "incident",
        "root cause",
        "上线",
        "付款",
    )
    if str(context.urgency or "").lower() == "high":
        return "high"
    if "reasoning_hard" in task_types or any(term in text for term in high_risk_terms):
        return "high"
    if context.has_file or "planning" in task_types or "tool_or_code" in task_types:
        return "medium"
    if len(text) > 5000:
        return "medium"
    return "low"


def _infer_reasoning_level(task_types: tuple[str, ...], risk: str) -> str:
    if risk == "high" or "reasoning_hard" in task_types:
        return "high"
    if risk == "medium" or any(item in task_types for item in ("planning", "tool_or_code", "extraction")):
        return "medium"
    return "low"


def _hard_filter(
    candidates: list[ModelCandidate],
    *,
    estimated_tokens: int,
    task_types: tuple[str, ...],
    provider_preference: tuple[str, ...],
    region_preference: tuple[str, ...],
) -> list[ModelCandidate]:
    provider_allow = {item.strip().lower() for item in provider_preference if item.strip()}
    region_allow = {item.strip().lower() for item in region_preference if item.strip()}
    need_strong_reasoning = "reasoning_hard" in task_types

    filtered: list[ModelCandidate] = []
    for candidate in candidates:
        if not candidate.enabled:
            continue
        if provider_allow and candidate.provider not in provider_allow:
            continue
        if region_allow and candidate.region not in region_allow:
            continue
        if not candidate.supports_realtime:
            continue
        if candidate.max_context < estimated_tokens:
            continue
        if need_strong_reasoning and not (
            candidate.reasoning_capable or candidate.quality_tier in {"strong", "premium"}
        ):
            continue
        filtered.append(candidate)
    return filtered


def _score_candidates(
    candidates: list[ModelCandidate],
    *,
    estimated_tokens: int,
    risk: str,
    task_types: tuple[str, ...],
    weights: RouterWeights,
) -> list[CandidateScore]:
    if not candidates:
        return []

    latencies = [item.avg_latency_ms for item in candidates]
    min_latency = min(latencies)
    max_latency = max(latencies)

    scores: list[CandidateScore] = []
    for candidate in candidates:
        quality_score = _quality_score(candidate.quality_tier)
        free_bonus = 1.0 if candidate.is_free else 0.0
        context_fit_score = _clamp(candidate.max_context / max(float(estimated_tokens) * 1.4, 1.0))
        stability_score = _clamp(candidate.stability_score)
        normalized_cost = _clamp(candidate.normalized_cost)
        normalized_latency = _normalize(candidate.avg_latency_ms, min_latency, max_latency)

        route_score = (
            weights.quality * quality_score
            + weights.free_bonus * free_bonus
            + weights.context_fit * context_fit_score
            + weights.stability * stability_score
            - weights.cost_penalty * normalized_cost
            - weights.latency_penalty * normalized_latency
        )

        if risk == "high" and candidate.quality_tier in {"strong", "premium"}:
            route_score += 0.05
        if "tool_or_code" in task_types and candidate.reasoning_capable:
            route_score += 0.04

        scores.append(
            CandidateScore(
                candidate=candidate,
                route_score=route_score,
                quality_score=quality_score,
                free_bonus=free_bonus,
                context_fit_score=context_fit_score,
                stability_score=stability_score,
                normalized_cost=normalized_cost,
                normalized_latency=normalized_latency,
            )
        )

    return sorted(scores, key=lambda item: item.route_score, reverse=True)


def _choose_primary(scored: list[CandidateScore], *, risk: str, task_types: tuple[str, ...], latency_budget: int) -> CandidateScore:
    if not scored:
        raise ValueError("scored candidates cannot be empty")

    free_only = [item for item in scored if item.candidate.is_free]
    simple_low = risk == "low" and all(item in {"factual_qa", "extraction", "writing"} for item in task_types)

    if simple_low and free_only:
        within_budget = [item for item in free_only if item.candidate.avg_latency_ms <= latency_budget]
        pool = within_budget if within_budget else free_only
        return sorted(pool, key=lambda item: (item.candidate.avg_latency_ms, -item.route_score))[0]

    if risk == "medium" and free_only:
        return sorted(free_only, key=lambda item: item.route_score, reverse=True)[0]

    if risk == "high":
        strong = [item for item in scored if item.candidate.quality_tier in {"strong", "premium"}]
        if strong:
            return strong[0]

    if free_only:
        return free_only[0]
    return scored[0]


def _choose_fallback(scored: list[CandidateScore], selected: CandidateScore) -> CandidateScore:
    if not scored:
        raise ValueError("scored candidates cannot be empty")

    selected_tier_rank = _tier_rank(selected.candidate.quality_tier)
    remaining = [item for item in scored if item.candidate.model != selected.candidate.model]
    if not remaining:
        return selected

    same_tier_more_stable = [
        item
        for item in remaining
        if _tier_rank(item.candidate.quality_tier) == selected_tier_rank
        and item.candidate.stability_score >= selected.candidate.stability_score
    ]
    if same_tier_more_stable:
        return sorted(same_tier_more_stable, key=lambda item: item.route_score, reverse=True)[0]

    one_tier_stronger = [item for item in remaining if _tier_rank(item.candidate.quality_tier) == selected_tier_rank + 1]
    if one_tier_stronger:
        return sorted(one_tier_stronger, key=lambda item: item.route_score, reverse=True)[0]

    one_tier_cheaper = [item for item in remaining if item.normalized_cost <= selected.normalized_cost]
    if one_tier_cheaper:
        return sorted(one_tier_cheaper, key=lambda item: item.route_score, reverse=True)[0]

    return remaining[0]


def _quality_score(quality_tier: str) -> float:
    mapping = {
        "fast": 0.58,
        "balanced": 0.74,
        "strong": 0.88,
        "premium": 0.96,
    }
    return mapping.get(str(quality_tier or "").strip().lower(), 0.7)


def _tier_rank(quality_tier: str) -> int:
    mapping = {
        "fast": 0,
        "balanced": 1,
        "strong": 2,
        "premium": 3,
    }
    return mapping.get(str(quality_tier or "").strip().lower(), 1)


def _normalize(value: float, low: float, high: float) -> float:
    if high <= low:
        return 0.0
    return _clamp((value - low) / (high - low))


def _clamp(value: float) -> float:
    if value < 0.0:
        return 0.0
    if value > 1.0:
        return 1.0
    return value
