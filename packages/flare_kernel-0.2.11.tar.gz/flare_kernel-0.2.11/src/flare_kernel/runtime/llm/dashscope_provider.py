"""DashScope provider adapter."""

from __future__ import annotations

import json
from typing import Any

from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.llm.contracts import LLMCompletion, LLMProviderConfig

logger = get_logger("flare_kernel.runtime.llm.dashscope_provider")


def placeholder_content(provider: str, model: str, reason: str | None = None) -> str:
    suffix = f" ({reason})" if reason else ""
    return f"[{provider}:{model}] LLM placeholder{suffix}"


def _completion_from_placeholder(*, model: str, reason: str, details: dict[str, Any]) -> LLMCompletion:
    return LLMCompletion(
        provider="dashscope",
        model=model,
        content=placeholder_content("dashscope", model, reason),
        status="placeholder",
        details={"backend": "dashscope", **details},
    )


def _extract_message(data: Any) -> str:
    choices = data.get("choices") if isinstance(data, dict) else None
    if not isinstance(choices, list) or not choices:
        return ""
    first_choice = choices[0]
    if not isinstance(first_choice, dict):
        return ""
    choice_message = first_choice.get("message")
    if not isinstance(choice_message, dict):
        return ""
    content = choice_message.get("content")
    return content.strip() if isinstance(content, str) else ""


async def call_dashscope(
    *,
    config: LLMProviderConfig,
    prompt: str,
    model: str,
    temperature: float,
    trace_id: str,
    session_id: str,
    intent: str,
) -> LLMCompletion:
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You are an intelligent workflow assistant. Respond concisely and helpfully.",
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": temperature,
    }
    headers = {
        "Authorization": f"Bearer {config.dashscope_api_key}",
        "Content-Type": "application/json",
    }
    url = f"{config.dashscope_base_url.rstrip('/')}/chat/completions"

    try:
        import httpx
    except ImportError:
        logger.warning("llm.provider.httpx_missing backend=dashscope trace_id=%s session_id=%s intent=%s", trace_id, session_id, intent)
        return _completion_from_placeholder(model=model, reason="httpx is not installed", details={"reason": "httpx_missing"})

    try:
        async with httpx.AsyncClient(timeout=config.timeout_seconds) as client:
            response = await client.post(url, json=payload, headers=headers)
    except httpx.HTTPError as exc:
        logger.warning("llm.provider.request_failed backend=dashscope trace_id=%s session_id=%s intent=%s error=%s", trace_id, session_id, intent, str(exc))
        return _completion_from_placeholder(model=model, reason="request failed", details={"reason": "request failed", "error": str(exc)})

    if response.status_code != 200:
        logger.warning(
            "llm.provider.http_error backend=dashscope trace_id=%s session_id=%s intent=%s status=%s",
            trace_id,
            session_id,
            intent,
            response.status_code,
        )
        return _completion_from_placeholder(
            model=model,
            reason=f"HTTP {response.status_code}",
            details={"reason": "http_error", "status_code": response.status_code, "response_text": response.text[:512]},
        )

    try:
        data = response.json()
    except json.JSONDecodeError:
        logger.warning("llm.provider.invalid_json backend=dashscope trace_id=%s session_id=%s intent=%s", trace_id, session_id, intent)
        return _completion_from_placeholder(
            model=model,
            reason="invalid JSON response",
            details={"reason": "invalid_json", "response_text": response.text[:512]},
        )

    message = _extract_message(data)
    if not message:
        logger.warning("llm.provider.empty_response backend=dashscope trace_id=%s session_id=%s intent=%s", trace_id, session_id, intent)
        return _completion_from_placeholder(
            model=model,
            reason="empty response",
            details={"reason": "empty response", "response": data},
        )

    return LLMCompletion(
        provider="dashscope",
        model=model,
        content=message,
        status="ok",
        details={"backend": "dashscope"},
    )
