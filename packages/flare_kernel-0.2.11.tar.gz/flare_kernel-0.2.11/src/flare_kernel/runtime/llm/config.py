"""LLM provider configuration helpers."""

from __future__ import annotations

import json
import os
from functools import lru_cache
from typing import Any

from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.llm.contracts import LLMProviderConfig
from flare_kernel.runtime.llm.model_router import ModelCandidate, RouterWeights, normalize_candidate
from flare_kernel.runtime.llm.provider_health import apply_provider_health, normalize_health_snapshot
from flare_kernel.runtime.llm.provider_health_source import merge_health_sources
from flare_kernel.runtime.llm.provider_quota import apply_provider_quota, normalize_quota_snapshot

logger = get_logger("flare_kernel.runtime.llm.config")

_DEFAULT_PROVIDER_BACKEND = "dashscope"
_DASHSCOPE_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
_DASHSCOPE_MODEL = "qwen-plus"


def env_value(name: str, default: str | None = None) -> str | None:
    raw = os.getenv(name)
    if raw is None:
        return default
    value = raw.strip()
    return value if value else default


def bool_env(name: str, default: bool = False) -> bool:
    raw = env_value(name)
    if raw is None:
        return default
    return raw.lower() in {"1", "true", "yes", "on"}


def float_env(name: str, default: float) -> float:
    raw = env_value(name)
    if raw is None:
        return default
    try:
        return float(raw)
    except ValueError:
        logger.warning("llm.provider.invalid_timeout env=%s raw=%s", name, raw)
        return default


def json_env(name: str) -> Any:
    raw = env_value(name)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("llm.provider.invalid_json env=%s", name)
        return None


@lru_cache(maxsize=1)
def get_llm_provider_config() -> LLMProviderConfig:
    backend = (env_value("LLM_PROVIDER_BACKEND", _DEFAULT_PROVIDER_BACKEND) or _DEFAULT_PROVIDER_BACKEND).lower()
    return LLMProviderConfig(
        backend=backend,
        dashscope_api_key=env_value("DASHSCOPE_API_KEY"),
        dashscope_base_url=env_value("DASHSCOPE_BASE_URL", _DASHSCOPE_BASE_URL) or _DASHSCOPE_BASE_URL,
        dashscope_model=env_value("DASHSCOPE_MODEL", _DASHSCOPE_MODEL) or _DASHSCOPE_MODEL,
        timeout_seconds=float_env("LLM_PROVIDER_TIMEOUT_SECONDS", 60.0),
    )


def resolve_timeout_seconds(*, intent: str, default_timeout: float) -> tuple[float, str]:
    payload = json_env("LLM_PROVIDER_TIMEOUT_BY_INTENT_JSON")
    if not isinstance(payload, dict):
        return default_timeout, "default"

    key = str(intent or "").strip()
    raw = payload.get(key) if key else None
    source = f"intent:{key}" if raw is not None else "default"
    if raw is None:
        raw = payload.get("default")
        source = "policy_default" if raw is not None else "default"
    if raw is None:
        return default_timeout, source

    try:
        value = float(raw)
    except (TypeError, ValueError):
        logger.warning("llm.provider.invalid_timeout_policy intent=%s raw=%s", key, raw)
        return default_timeout, "invalid_policy"
    if value <= 0:
        logger.warning("llm.provider.non_positive_timeout_policy intent=%s raw=%s", key, raw)
        return default_timeout, "invalid_policy"
    return value, source


def build_weights() -> RouterWeights:
    payload = json_env("MODEL_ROUTER_WEIGHTS_JSON")
    if not isinstance(payload, dict):
        return RouterWeights()
    return RouterWeights(
        quality=float(payload.get("quality", 0.38)),
        free_bonus=float(payload.get("free_bonus", 0.22)),
        context_fit=float(payload.get("context_fit", 0.16)),
        stability=float(payload.get("stability", 0.14)),
        cost_penalty=float(payload.get("cost_penalty", 0.06)),
        latency_penalty=float(payload.get("latency_penalty", 0.04)),
    )


def build_candidates() -> list[ModelCandidate]:
    payload = json_env("MODEL_ROUTER_CANDIDATES_JSON")
    if not isinstance(payload, list):
        return []

    candidates: list[ModelCandidate] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        try:
            normalized = normalize_candidate(item)
        except (TypeError, ValueError):
            continue
        if normalized.provider and normalized.model:
            candidates.append(normalized)
    health_payload = merge_health_sources(
        env_payload=json_env("MODEL_PROVIDER_HEALTH_JSON"),
        file_path=env_value("MODEL_PROVIDER_HEALTH_FILE"),
    )
    health = normalize_health_snapshot(health_payload)
    quota = normalize_quota_snapshot(json_env("MODEL_PROVIDER_QUOTA_JSON"))
    return apply_provider_quota(apply_provider_health(candidates, health), quota)
