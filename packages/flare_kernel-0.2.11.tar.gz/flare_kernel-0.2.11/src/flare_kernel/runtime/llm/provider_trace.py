"""Provider trace projection helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.llm.contracts import LLMCompletion


def _int_or_none(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def build_completion_provider_trace(completion: LLMCompletion) -> dict[str, Any]:
    details = completion.details if isinstance(completion.details, dict) else {}
    latency_ms = _int_or_none(details.get("latency_ms"))
    usage_estimate = details.get("usage_estimate") if isinstance(details.get("usage_estimate"), dict) else {}
    trace = {
        "backend": str(details.get("backend") or completion.provider),
        "provider": completion.provider,
        "model": completion.model,
        "status": completion.status,
        "reason": str(details.get("reason") or ""),
        "latency_ms": latency_ms,
        "routing_decision": details.get("routing_decision"),
        "fallback_used": bool(details.get("fallback_used")),
        "selected_model": details.get("selected_model"),
        "fallback_model": details.get("fallback_model"),
        "reasoning_level": details.get("reasoning_level"),
        "fixture_source": str(details.get("fixture_source") or ""),
        "replay_prompt_hash": str(details.get("replay_prompt_hash") or ""),
        "usage_estimate": usage_estimate,
    }
    return {key: value for key, value in trace.items() if value not in (None, "", {})}
