"""DashScope streaming provider adapter."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator

from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.llm.contracts import LLMCompletion, LLMProviderConfig, LLMStreamEvent
from flare_kernel.runtime.llm.dashscope_provider import placeholder_content

logger = get_logger("flare_kernel.runtime.llm.dashscope_streaming_provider")


def _stream_completion(*, model: str, content: str, status: str, details: dict) -> LLMCompletion:
    return LLMCompletion(
        provider="dashscope",
        model=model,
        content=content,
        status=status,
        details={"backend": "dashscope", **details},
    )


def _extract_delta(data: dict) -> str:
    choices = data.get("choices")
    if not isinstance(choices, list) or not choices:
        return ""
    first = choices[0]
    if not isinstance(first, dict):
        return ""
    delta = first.get("delta")
    if isinstance(delta, dict) and isinstance(delta.get("content"), str):
        return delta["content"]
    message = first.get("message")
    if isinstance(message, dict) and isinstance(message.get("content"), str):
        return message["content"]
    return ""


async def _error_event(*, model: str, reason: str, details: dict) -> AsyncIterator[LLMStreamEvent]:
    completion = _stream_completion(
        model=model,
        content=placeholder_content("dashscope", model, reason),
        status="placeholder",
        details=details,
    )
    yield LLMStreamEvent(event_type="provider.done", delta="", completion=completion, details=completion.details)


async def call_dashscope_stream(
    *,
    config: LLMProviderConfig,
    prompt: str,
    model: str,
    temperature: float,
    trace_id: str,
    session_id: str,
    intent: str,
) -> AsyncIterator[LLMStreamEvent]:
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You are an intelligent workflow assistant. Respond concisely and helpfully.",
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": temperature,
        "stream": True,
    }
    headers = {"Authorization": f"Bearer {config.dashscope_api_key}", "Content-Type": "application/json"}
    url = f"{config.dashscope_base_url.rstrip('/')}/chat/completions"

    try:
        import httpx
    except ImportError:
        async for event in _error_event(model=model, reason="httpx is not installed", details={"reason": "httpx_missing"}):
            yield event
        return

    try:
        async with httpx.AsyncClient(timeout=config.timeout_seconds) as client:
            async for event in _iter_client_stream(client=client, url=url, payload=payload, headers=headers, model=model):
                yield event
    except httpx.HTTPError as exc:
        logger.warning(
            "llm.provider.stream_failed trace_id=%s session_id=%s intent=%s error=%s",
            trace_id,
            session_id,
            intent,
            str(exc),
        )
        details = {"reason": "request failed", "error": str(exc)}
        async for event in _error_event(model=model, reason="request failed", details=details):
            yield event


async def _iter_client_stream(
    *,
    client,
    url: str,
    payload: dict,
    headers: dict,
    model: str,
) -> AsyncIterator[LLMStreamEvent]:
    async with client.stream("POST", url, json=payload, headers=headers) as response:
        async for event in _iter_response_events(response=response, model=model):
            yield event


async def _iter_response_events(*, response, model: str) -> AsyncIterator[LLMStreamEvent]:
    if response.status_code != 200:
        details = {"reason": "http_error", "status_code": response.status_code}
        async for event in _error_event(model=model, reason=f"HTTP {response.status_code}", details=details):
            yield event
        return

    content_parts: list[str] = []
    async for event in _iter_delta_events(response=response, model=model, content_parts=content_parts):
        yield event
    content = "".join(content_parts)
    completion = _stream_completion(model=model, content=content, status="ok", details={"streaming": True})
    yield LLMStreamEvent(event_type="provider.done", delta="", completion=completion, details=completion.details)


async def _iter_delta_events(*, response, model: str, content_parts: list[str]) -> AsyncIterator[LLMStreamEvent]:
    async for line in response.aiter_lines():
        chunk = _parse_stream_line(line)
        if not chunk:
            continue
        content_parts.append(chunk)
        yield LLMStreamEvent(
            event_type="provider.delta",
            delta=chunk,
            completion=None,
            details={"backend": "dashscope", "provider": "dashscope", "model": model, "status": "streaming"},
        )


def _parse_stream_line(line: str) -> str:
    text = str(line or "").strip()
    if not text or not text.startswith("data:"):
        return ""
    payload = text.removeprefix("data:").strip()
    if payload == "[DONE]":
        return ""
    try:
        data = json.loads(payload)
    except json.JSONDecodeError:
        return ""
    return _extract_delta(data)


__all__ = ["call_dashscope_stream"]
