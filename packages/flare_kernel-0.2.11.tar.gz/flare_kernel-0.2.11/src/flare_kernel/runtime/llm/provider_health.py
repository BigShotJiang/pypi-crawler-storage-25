"""Provider health policy for model routing."""

from __future__ import annotations

from dataclasses import replace
from typing import Any

from flare_kernel.runtime.llm.contracts import LLMProviderConfig
from flare_kernel.runtime.llm.model_router import ModelCandidate

_UNHEALTHY = {"down", "disabled", "unhealthy", "blocked"}
_DEGRADED = {"degraded", "slow", "limited"}


def normalize_health_snapshot(payload: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(payload, dict):
        return {}
    normalized: dict[str, dict[str, Any]] = {}
    for key, value in payload.items():
        ref = str(key or "").strip().lower()
        if not ref:
            continue
        if isinstance(value, dict):
            status = str(value.get("status") or "").strip().lower()
            normalized[ref] = {**value, "status": status or "unknown"}
            continue
        normalized[ref] = {"status": str(value or "").strip().lower() or "unknown"}
    return normalized


def _candidate_refs(candidate: ModelCandidate) -> tuple[str, str]:
    provider = str(candidate.provider or "").strip().lower()
    model = str(candidate.model or "").strip().lower()
    return f"{provider}/{model}", provider


def _health_for_candidate(candidate: ModelCandidate, health: dict[str, dict[str, Any]]) -> dict[str, Any]:
    model_ref, provider_ref = _candidate_refs(candidate)
    return health.get(model_ref) or health.get(provider_ref) or {}


def apply_provider_health(candidates: list[ModelCandidate], health: dict[str, dict[str, Any]]) -> list[ModelCandidate]:
    if not health:
        return candidates
    adjusted: list[ModelCandidate] = []
    for candidate in candidates:
        entry = _health_for_candidate(candidate, health)
        status = str(entry.get("status") or "").strip().lower()
        if status in _UNHEALTHY:
            adjusted.append(replace(candidate, enabled=False, stability_score=0.0))
            continue
        if status in _DEGRADED:
            adjusted.append(replace(candidate, stability_score=min(candidate.stability_score, 0.35)))
            continue
        adjusted.append(candidate)
    return adjusted


__all__ = ["apply_provider_health", "normalize_health_snapshot"]
