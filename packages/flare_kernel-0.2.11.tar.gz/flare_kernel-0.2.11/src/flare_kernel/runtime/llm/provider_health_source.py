"""Provider health source loading helpers."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from flare_kernel.runtime.infrastructure.logging import get_logger

logger = get_logger("flare_kernel.runtime.llm.provider_health_source")


def _load_file_payload(path: str | None) -> Any:
    if not path:
        return None
    try:
        return json.loads(Path(path).read_text())
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("llm.provider.health_file_unavailable path=%s error=%s", path, str(exc))
        return None


def _health_payload(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    nested = value.get("health")
    return nested if isinstance(nested, dict) else value


def merge_health_sources(*, env_payload: Any, file_path: str | None) -> dict[str, Any]:
    merged: dict[str, Any] = {}
    merged.update(_health_payload(env_payload))
    merged.update(_health_payload(_load_file_payload(file_path)))
    return merged


__all__ = ["merge_health_sources"]
