"""Optional normalized completion capture for replay fixtures."""

from __future__ import annotations

import json
from pathlib import Path

from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.llm.config import env_value
from flare_kernel.runtime.llm.contracts import LLMCompletion
from flare_kernel.runtime.llm.replay_provider import prompt_hash

logger = get_logger("flare_kernel.runtime.llm.completion_capture")


def capture_completion_if_enabled(
    *,
    prompt: str,
    trace_id: str,
    session_id: str,
    intent: str,
    completion: LLMCompletion,
) -> None:
    capture_dir = env_value("LLM_COMPLETION_CAPTURE_DIR")
    if not capture_dir:
        return
    target_dir = Path(capture_dir)
    hashed = prompt_hash(prompt)
    payload = {
        "schema_version": "llm.completion.fixture.v1",
        "trace_id": trace_id,
        "session_id": session_id,
        "intent": intent,
        "prompt_hash": hashed,
        "completion": {
            "provider": completion.provider,
            "model": completion.model,
            "status": completion.status,
            "content": completion.content,
            "details": completion.details,
        },
    }
    try:
        target_dir.mkdir(parents=True, exist_ok=True)
        (target_dir / f"{intent}.{hashed}.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2))
    except OSError as exc:
        logger.warning("llm.capture.write_failed trace_id=%s path=%s error=%s", trace_id, target_dir, str(exc))
