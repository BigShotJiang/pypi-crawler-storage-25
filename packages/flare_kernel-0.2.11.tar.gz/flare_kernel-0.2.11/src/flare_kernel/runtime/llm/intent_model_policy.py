"""Intent-scoped primary model policy helpers."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.llm.config import json_env


def resolve_primary_model_ref(*, intent: str) -> tuple[str, str]:
    payload = json_env("MODEL_ROUTER_PRIMARY_BY_INTENT_JSON")
    if not isinstance(payload, dict):
        return "", "router"

    key = str(intent or "").strip()
    raw = payload.get(key) if key else None
    source = f"intent:{key}" if raw else "router"
    if raw is None:
        raw = payload.get("default")
        source = "policy_default" if raw else "router"
    if not raw:
        return "", source
    return str(raw).strip(), source


def apply_primary_model_policy(
    routing_decision: dict[str, Any] | None,
    *,
    intent: str,
    default_model: str,
) -> dict[str, Any] | None:
    primary_model, source = resolve_primary_model_ref(intent=intent)
    if not primary_model:
        return routing_decision

    decision = dict(routing_decision or {})
    if not str(decision.get("fallback_model") or "").strip():
        decision["fallback_model"] = str(decision.get("selected_model") or default_model or primary_model).strip()
    decision["selected_model"] = primary_model
    decision["primary_policy_source"] = source
    return decision


__all__ = ["apply_primary_model_policy", "resolve_primary_model_ref"]
