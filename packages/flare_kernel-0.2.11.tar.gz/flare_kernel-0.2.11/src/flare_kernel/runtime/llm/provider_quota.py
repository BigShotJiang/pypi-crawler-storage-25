"""Provider quota policy for model routing."""

from __future__ import annotations

from dataclasses import replace
from typing import Any

from flare_kernel.runtime.llm.model_router import ModelCandidate

_EXHAUSTED = {"exhausted", "blocked", "disabled", "over_quota"}
_LOW = {"low", "limited", "near_limit"}


def normalize_quota_snapshot(payload: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(payload, dict):
        return {}
    normalized: dict[str, dict[str, Any]] = {}
    for key, value in payload.items():
        ref = str(key or "").strip().lower()
        if not ref:
            continue
        normalized[ref] = _quota_entry(value)
    return normalized


def _quota_entry(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        status = str(value.get("status") or "").strip().lower()
        return {**value, "status": status or "unknown"}
    return {"status": str(value or "").strip().lower() or "unknown"}


def _candidate_refs(candidate: ModelCandidate) -> tuple[str, str]:
    provider = str(candidate.provider or "").strip().lower()
    model = str(candidate.model or "").strip().lower()
    return f"{provider}/{model}", provider


def _quota_for_candidate(candidate: ModelCandidate, quota: dict[str, dict[str, Any]]) -> dict[str, Any]:
    model_ref, provider_ref = _candidate_refs(candidate)
    return quota.get(model_ref) or quota.get(provider_ref) or {}


def _remaining_ratio(entry: dict[str, Any]) -> float | None:
    raw = entry.get("remaining_ratio")
    if raw is None:
        return None
    try:
        return float(raw)
    except (TypeError, ValueError):
        return None


def apply_provider_quota(candidates: list[ModelCandidate], quota: dict[str, dict[str, Any]]) -> list[ModelCandidate]:
    if not quota:
        return candidates
    adjusted: list[ModelCandidate] = []
    for candidate in candidates:
        entry = _quota_for_candidate(candidate, quota)
        status = str(entry.get("status") or "").strip().lower()
        ratio = _remaining_ratio(entry)
        if status in _EXHAUSTED or ratio == 0:
            adjusted.append(replace(candidate, enabled=False, is_free=False, normalized_cost=1.0))
            continue
        if status in _LOW or (ratio is not None and ratio < 0.15):
            adjusted.append(replace(candidate, normalized_cost=max(candidate.normalized_cost, 0.95)))
            continue
        adjusted.append(candidate)
    return adjusted


__all__ = ["apply_provider_quota", "normalize_quota_snapshot"]
