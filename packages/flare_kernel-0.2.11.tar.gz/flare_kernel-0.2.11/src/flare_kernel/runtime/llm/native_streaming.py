"""Native provider streaming orchestration helpers."""

from __future__ import annotations

import time
from collections.abc import AsyncIterator
from typing import Any

from flare_kernel.runtime.llm.completion_capture import capture_completion_if_enabled
from flare_kernel.runtime.llm.contracts import LLMCompletion, LLMProviderConfig, LLMStreamEvent
from flare_kernel.runtime.llm.dashscope_streaming_provider import call_dashscope_stream
from flare_kernel.runtime.llm.provider_usage import attach_usage_estimate


def _finalize_stream_completion(
    *,
    prompt: str,
    trace_id: str,
    session_id: str,
    intent: str,
    completion: LLMCompletion,
    details: dict[str, Any],
) -> LLMCompletion:
    finalized = LLMCompletion(
        provider=completion.provider,
        model=completion.model,
        content=completion.content,
        status=completion.status,
        details={**dict(completion.details), **details},
    )
    finalized = attach_usage_estimate(prompt=prompt, completion=finalized)
    capture_completion_if_enabled(
        prompt=prompt,
        trace_id=trace_id,
        session_id=session_id,
        intent=intent,
        completion=finalized,
    )
    return finalized


async def generate_dashscope_native_stream(
    *,
    config: LLMProviderConfig,
    prompt: str,
    trace_id: str,
    session_id: str,
    intent: str,
    model: str,
    temperature: float,
    stream_details: dict[str, Any],
) -> AsyncIterator[LLMStreamEvent]:
    started_at = time.perf_counter()
    async for event in call_dashscope_stream(
        config=config,
        prompt=prompt,
        model=model,
        temperature=temperature,
        trace_id=trace_id,
        session_id=session_id,
        intent=intent,
    ):
        if event.event_type != "provider.done" or event.completion is None:
            yield event
            continue
        completion = _finalize_stream_completion(
            prompt=prompt,
            trace_id=trace_id,
            session_id=session_id,
            intent=intent,
            completion=event.completion,
            details={
                **stream_details,
                "latency_ms": int((time.perf_counter() - started_at) * 1000),
                "status": event.completion.status,
                "native_streaming": True,
            },
        )
        yield LLMStreamEvent(event_type=event.event_type, delta=event.delta, completion=completion, details=completion.details)


__all__ = ["generate_dashscope_native_stream"]
