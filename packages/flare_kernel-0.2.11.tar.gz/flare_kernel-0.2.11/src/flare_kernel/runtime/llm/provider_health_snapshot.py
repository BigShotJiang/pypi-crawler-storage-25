"""Provider health snapshot writer."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

_SCHEMA_VERSION = "provider.health.snapshot.v0"


def _entry_ref(entry: dict[str, Any]) -> str:
    provider = str(entry.get("provider") or "").strip().lower()
    model = str(entry.get("model") or "").strip()
    if provider and model:
        return f"{provider}/{model}"
    return provider


def _health_entry(entry: dict[str, Any]) -> dict[str, Any]:
    status = str(entry.get("status") or "unknown").strip().lower() or "unknown"
    reason = str(entry.get("reason") or "").strip()
    payload: dict[str, Any] = {"status": status}
    if reason:
        payload["reason"] = reason
    return payload


def build_provider_health_snapshot(entries: list[dict[str, Any]]) -> dict[str, Any]:
    health: dict[str, dict[str, Any]] = {}
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        ref = _entry_ref(entry)
        if ref:
            health[ref] = _health_entry(entry)
    return {
        "schema_version": _SCHEMA_VERSION,
        "generated_at": datetime.now(UTC).isoformat(),
        "health": health,
    }


def write_provider_health_snapshot(path: str | Path, entries: list[dict[str, Any]]) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    snapshot = build_provider_health_snapshot(entries)
    target.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2, sort_keys=True))
    return target


__all__ = ["build_provider_health_snapshot", "write_provider_health_snapshot"]
