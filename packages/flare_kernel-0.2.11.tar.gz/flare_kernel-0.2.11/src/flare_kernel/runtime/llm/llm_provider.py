"""LLM provider adapter layer for the kernel."""

from __future__ import annotations

import time
from collections.abc import AsyncIterator
from dataclasses import replace
from typing import Any

from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.llm.completion_capture import capture_completion_if_enabled
from flare_kernel.runtime.llm.config import (
    bool_env,
    build_candidates,
    build_weights,
    env_value,
    get_llm_provider_config,
    resolve_timeout_seconds,
)
from flare_kernel.runtime.llm.contracts import LLMCompletion, LLMProviderConfig, LLMStreamEvent
from flare_kernel.runtime.llm.dashscope_provider import call_dashscope, placeholder_content
from flare_kernel.runtime.llm.fallback_policy import apply_fallback_policy
from flare_kernel.runtime.llm.intent_model_policy import apply_primary_model_policy
from flare_kernel.runtime.llm.model_router import RoutingContext, select_model
from flare_kernel.runtime.llm.native_streaming import generate_dashscope_native_stream
from flare_kernel.runtime.llm.replay_provider import call_replay_provider
from flare_kernel.runtime.llm.provider_usage import attach_usage_estimate
from flare_kernel.runtime.llm.streaming_provider import stream_from_completion

logger = get_logger("flare_kernel.runtime.llm.llm_provider")


def _split_provider_model(value: str, *, default_provider: str = "dashscope") -> tuple[str, str]:
    text = str(value or "").strip()
    if not text:
        return default_provider, ""
    if "/" not in text:
        return default_provider, text
    provider, model = text.split("/", 1)
    return provider.strip().lower(), model.strip()


def _temperature_for_reasoning(reasoning_level: str) -> float:
    mapping = {
        "low": 0.15,
        "medium": 0.2,
        "high": 0.28,
    }
    return float(mapping.get(str(reasoning_level or "").strip().lower(), 0.2))


def _resolve_routing(
    *,
    prompt: str,
    trace_id: str,
    session_id: str,
    intent: str,
    fallback_default_model: str,
) -> dict[str, Any] | None:
    if not bool_env("MODEL_ROUTER_ENABLED", False):
        return None

    candidates = build_candidates()
    if not candidates:
        return None

    context = RoutingContext(
        intent=intent,
        prompt=prompt,
        session_id=session_id,
        trace_id=trace_id,
        history_summary="",
        urgency="medium",
        has_file=False,
        file_types=(),
    )
    decision = select_model(
        context,
        candidates,
        weights=build_weights(),
        default_model=fallback_default_model,
    )
    payload = decision.to_dict()
    health = env_value("MODEL_PROVIDER_HEALTH_JSON")
    if health:
        payload["provider_health_configured"] = True
    health_file = env_value("MODEL_PROVIDER_HEALTH_FILE")
    if health_file:
        payload["provider_health_file_configured"] = True
    quota = env_value("MODEL_PROVIDER_QUOTA_JSON")
    if quota:
        payload["provider_quota_configured"] = True
    return payload


def _placeholder_for_backend(config: LLMProviderConfig, *, trace_id: str, session_id: str, intent: str) -> LLMCompletion:
    provider = config.backend
    model = config.dashscope_model
    logger.info("llm.provider.placeholder backend=%s trace_id=%s session_id=%s intent=%s", provider, trace_id, session_id, intent)
    return LLMCompletion(
        provider=provider,
        model=model,
        content=placeholder_content(provider, model, "provider backend is not dashscope"),
        status="placeholder",
        details={"backend": provider, "reason": "provider backend is not dashscope"},
    )


def _missing_key_completion(config: LLMProviderConfig, *, trace_id: str, session_id: str, intent: str) -> LLMCompletion:
    logger.info("llm.provider.missing_key backend=dashscope trace_id=%s session_id=%s intent=%s", trace_id, session_id, intent)
    return LLMCompletion(
        provider="dashscope",
        model=config.dashscope_model,
        content=placeholder_content("dashscope", config.dashscope_model, "DASHSCOPE_API_KEY is missing"),
        status="placeholder",
        details={"backend": "dashscope", "reason": "DASHSCOPE_API_KEY is missing"},
    )


def _resolve_model_refs(
    *,
    config: LLMProviderConfig,
    routing_decision: dict[str, Any] | None,
) -> tuple[str, str, str, str]:
    selected_ref = str(routing_decision.get("selected_model") if isinstance(routing_decision, dict) else "")
    fallback_ref = str(routing_decision.get("fallback_model") if isinstance(routing_decision, dict) else "")
    selected_provider, selected_model = _split_provider_model(selected_ref, default_provider="dashscope")
    fallback_provider, fallback_model = _split_provider_model(fallback_ref, default_provider=selected_provider or "dashscope")

    if not selected_model:
        selected_provider = "dashscope"
        selected_model = config.dashscope_model
    if not fallback_model:
        fallback_provider = selected_provider
        fallback_model = selected_model
    return selected_provider, selected_model, fallback_provider, fallback_model


async def _generate_dashscope_completion(
    *,
    config: LLMProviderConfig,
    prompt: str,
    trace_id: str,
    session_id: str,
    intent: str,
) -> LLMCompletion:
    if not config.dashscope_api_key:
        return _missing_key_completion(config, trace_id=trace_id, session_id=session_id, intent=intent)

    default_route_model = env_value("MODEL_ROUTER_DEFAULT_MODEL", f"aliyun/{config.dashscope_model}") or f"aliyun/{config.dashscope_model}"
    routing_decision = _resolve_routing(
        prompt=prompt,
        trace_id=trace_id,
        session_id=session_id,
        intent=intent,
        fallback_default_model=default_route_model,
    )
    routing_decision = apply_primary_model_policy(
        routing_decision,
        intent=intent,
        default_model=default_route_model,
    )
    routing_decision = apply_fallback_policy(routing_decision, intent=intent)
    selected_provider, selected_model, fallback_provider, fallback_model = _resolve_model_refs(
        config=config,
        routing_decision=routing_decision,
    )

    reasoning_level = str((routing_decision or {}).get("reasoning_level") if isinstance(routing_decision, dict) else "medium")
    temperature = _temperature_for_reasoning(reasoning_level)
    timeout_seconds, timeout_source = resolve_timeout_seconds(
        intent=intent,
        default_timeout=config.timeout_seconds,
    )
    effective_config = replace(config, timeout_seconds=timeout_seconds)
    started_at = time.perf_counter()
    primary_completion = await call_dashscope(
        config=effective_config,
        prompt=prompt,
        model=selected_model,
        temperature=temperature,
        trace_id=trace_id,
        session_id=session_id,
        intent=intent,
    )

    fallback_used = False
    completion = primary_completion
    if primary_completion.status != "ok" and fallback_model and fallback_model != selected_model:
        fallback_used = True
        completion = await call_dashscope(
            config=effective_config,
            prompt=prompt,
            model=fallback_model,
            temperature=temperature,
            trace_id=trace_id,
            session_id=session_id,
            intent=intent,
        )

    elapsed_ms = int((time.perf_counter() - started_at) * 1000)
    details = dict(completion.details)
    details.update(
        {
            "routing_decision": routing_decision,
            "fallback_used": fallback_used,
            "selected_model": f"{selected_provider}/{selected_model}",
            "fallback_model": f"{fallback_provider}/{fallback_model}",
            "reasoning_level": reasoning_level,
            "timeout_seconds": timeout_seconds,
            "timeout_source": timeout_source,
            "latency_ms": elapsed_ms,
            "status": completion.status,
        }
    )
    if fallback_used and primary_completion.status != "ok":
        details["primary_error"] = dict(primary_completion.details)

    provider_for_output = selected_provider or completion.provider
    if fallback_used and completion.model == fallback_model:
        provider_for_output = fallback_provider or provider_for_output

    return LLMCompletion(
        provider=provider_for_output,
        model=completion.model,
        content=completion.content,
        status=completion.status,
        details=details,
    )


async def generate_llm_completion(prompt: str, *, trace_id: str, session_id: str, intent: str) -> LLMCompletion:
    config = get_llm_provider_config()
    if config.backend == "replay":
        completion = await call_replay_provider(prompt=prompt, trace_id=trace_id, session_id=session_id, intent=intent)
    elif config.backend == "dashscope":
        completion = await _generate_dashscope_completion(
            config=config,
            prompt=prompt,
            trace_id=trace_id,
            session_id=session_id,
            intent=intent,
        )
    else:
        completion = _placeholder_for_backend(config, trace_id=trace_id, session_id=session_id, intent=intent)

    completion = attach_usage_estimate(prompt=prompt, completion=completion)
    capture_completion_if_enabled(
        prompt=prompt,
        trace_id=trace_id,
        session_id=session_id,
        intent=intent,
        completion=completion,
    )
    return completion


def _resolve_native_stream_plan(
    *,
    config: LLMProviderConfig,
    prompt: str,
    trace_id: str,
    session_id: str,
    intent: str,
) -> tuple[str, float, LLMProviderConfig, dict[str, Any]]:
    default_route_model = env_value("MODEL_ROUTER_DEFAULT_MODEL", f"aliyun/{config.dashscope_model}") or f"aliyun/{config.dashscope_model}"
    routing_decision = _resolve_routing(
        prompt=prompt,
        trace_id=trace_id,
        session_id=session_id,
        intent=intent,
        fallback_default_model=default_route_model,
    )
    routing_decision = apply_primary_model_policy(
        routing_decision,
        intent=intent,
        default_model=default_route_model,
    )
    routing_decision = apply_fallback_policy(routing_decision, intent=intent)
    selected_provider, selected_model, fallback_provider, fallback_model = _resolve_model_refs(
        config=config,
        routing_decision=routing_decision,
    )
    reasoning_level = str((routing_decision or {}).get("reasoning_level") if isinstance(routing_decision, dict) else "medium")
    temperature = _temperature_for_reasoning(reasoning_level)
    timeout_seconds, timeout_source = resolve_timeout_seconds(intent=intent, default_timeout=config.timeout_seconds)
    details = {
        "routing_decision": routing_decision,
        "fallback_used": False,
        "selected_model": f"{selected_provider}/{selected_model}",
        "fallback_model": f"{fallback_provider}/{fallback_model}",
        "reasoning_level": reasoning_level,
        "timeout_seconds": timeout_seconds,
        "timeout_source": timeout_source,
    }
    return selected_model, temperature, replace(config, timeout_seconds=timeout_seconds), details


async def generate_llm_completion_stream(
    prompt: str,
    *,
    trace_id: str,
    session_id: str,
    intent: str,
    chunk_size: int = 80,
) -> AsyncIterator[LLMStreamEvent]:
    config = get_llm_provider_config()
    native_enabled = bool_env("LLM_PROVIDER_NATIVE_STREAMING_ENABLED", True)
    if config.backend == "dashscope" and config.dashscope_api_key and native_enabled:
        model, temperature, stream_config, details = _resolve_native_stream_plan(
            config=config,
            prompt=prompt,
            trace_id=trace_id,
            session_id=session_id,
            intent=intent,
        )
        async for event in generate_dashscope_native_stream(
            config=stream_config,
            prompt=prompt,
            trace_id=trace_id,
            session_id=session_id,
            intent=intent,
            model=model,
            temperature=temperature,
            stream_details=details,
        ):
            yield event
        return

    completion = await generate_llm_completion(
        prompt,
        trace_id=trace_id,
        session_id=session_id,
        intent=intent,
    )
    async for event in stream_from_completion(completion, chunk_size=chunk_size):
        yield event


__all__ = [
    "LLMCompletion",
    "LLMProviderConfig",
    "LLMStreamEvent",
    "generate_llm_completion",
    "generate_llm_completion_stream",
    "get_llm_provider_config",
]
