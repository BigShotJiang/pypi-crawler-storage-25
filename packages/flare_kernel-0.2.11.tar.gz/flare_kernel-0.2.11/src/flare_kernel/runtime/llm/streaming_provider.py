"""Provider-level LLM streaming helpers."""

from __future__ import annotations

from collections.abc import AsyncIterator

from flare_kernel.runtime.llm.contracts import LLMCompletion, LLMStreamEvent


def _chunks(text: str, chunk_size: int) -> list[str]:
    size = max(1, int(chunk_size or 1))
    return [text[index : index + size] for index in range(0, len(text), size)] or [""]


async def stream_from_completion(
    completion: LLMCompletion,
    *,
    chunk_size: int = 80,
) -> AsyncIterator[LLMStreamEvent]:
    """Project a normalized completion into provider stream events."""

    for index, chunk in enumerate(_chunks(completion.content, chunk_size)):
        yield LLMStreamEvent(
            event_type="provider.delta",
            delta=chunk,
            completion=None,
            details={
                "provider": completion.provider,
                "model": completion.model,
                "status": completion.status,
                "chunk_index": index,
            },
        )
    yield LLMStreamEvent(
        event_type="provider.done",
        delta="",
        completion=completion,
        details={
            "provider": completion.provider,
            "model": completion.model,
            "status": completion.status,
            "backend": completion.details.get("backend"),
        },
    )


__all__ = ["stream_from_completion"]
