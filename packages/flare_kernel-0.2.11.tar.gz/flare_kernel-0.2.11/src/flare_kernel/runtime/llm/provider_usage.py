"""Provider usage estimate helpers."""

from __future__ import annotations

from typing import Any

from flare_engines.context.api import estimate_tokens

from flare_kernel.runtime.llm.contracts import LLMCompletion


def build_provider_usage_estimate(*, prompt: str, completion_content: str) -> dict[str, Any]:
    prompt_text = str(prompt or "")
    completion_text = str(completion_content or "")
    prompt_tokens = estimate_tokens(prompt_text)
    completion_tokens = estimate_tokens(completion_text)
    return {
        "prompt_chars": len(prompt_text),
        "completion_chars": len(completion_text),
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": prompt_tokens + completion_tokens,
        "source": "estimated",
    }


def attach_usage_estimate(*, prompt: str, completion: LLMCompletion) -> LLMCompletion:
    details = completion.details if isinstance(completion.details, dict) else {}
    usage_estimate = build_provider_usage_estimate(
        prompt=prompt,
        completion_content=completion.content,
    )
    return LLMCompletion(
        provider=completion.provider,
        model=completion.model,
        content=completion.content,
        status=completion.status,
        details={**details, "usage_estimate": usage_estimate},
    )
