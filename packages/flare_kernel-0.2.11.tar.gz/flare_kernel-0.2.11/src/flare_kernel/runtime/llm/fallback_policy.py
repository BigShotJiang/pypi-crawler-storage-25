"""Fallback model policy helpers for routing decisions."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.llm.config import json_env


def resolve_fallback_model_ref(*, intent: str, current_fallback: str) -> tuple[str, str]:
    payload = json_env("MODEL_ROUTER_FALLBACK_BY_INTENT_JSON")
    if not isinstance(payload, dict):
        return current_fallback, "router"

    key = str(intent or "").strip()
    raw = payload.get(key) if key else None
    source = f"intent:{key}" if raw else "router"
    if raw is None:
        raw = payload.get("default")
        source = "policy_default" if raw else "router"
    if not raw:
        return current_fallback, source
    return str(raw).strip(), source


def apply_fallback_policy(routing_decision: dict[str, Any] | None, *, intent: str) -> dict[str, Any] | None:
    if not isinstance(routing_decision, dict):
        return routing_decision

    current = str(routing_decision.get("fallback_model") or "").strip()
    fallback_model, source = resolve_fallback_model_ref(intent=intent, current_fallback=current)
    if fallback_model == current and source == "router":
        return routing_decision
    return {**routing_decision, "fallback_model": fallback_model, "fallback_policy_source": source}


__all__ = ["apply_fallback_policy", "resolve_fallback_model_ref"]
