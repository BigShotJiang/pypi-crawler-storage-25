"""LLM provider contracts."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class LLMProviderConfig:
    backend: str
    dashscope_api_key: str | None
    dashscope_base_url: str
    dashscope_model: str
    timeout_seconds: float


@dataclass(frozen=True)
class LLMCompletion:
    provider: str
    model: str
    content: str
    status: str
    details: dict[str, Any]


@dataclass(frozen=True)
class LLMStreamEvent:
    event_type: str
    delta: str
    completion: LLMCompletion | None
    details: dict[str, Any]
