"""One-shot provider health probe runner."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Awaitable, Callable

from flare_kernel.runtime.llm.contracts import LLMCompletion, LLMProviderConfig
from flare_kernel.runtime.llm.dashscope_provider import call_dashscope
from flare_kernel.runtime.llm.provider_health_snapshot import build_provider_health_snapshot, write_provider_health_snapshot

ProbeCall = Callable[..., Awaitable[LLMCompletion]]


def normalize_probe_specs(payload: Any) -> list[dict[str, Any]]:
    if not isinstance(payload, list):
        return []
    specs: list[dict[str, Any]] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        provider = str(item.get("provider") or "aliyun").strip().lower()
        model = str(item.get("model") or "").strip()
        if provider and model:
            specs.append({"provider": provider, "model": model, "prompt": str(item.get("prompt") or "ping")})
    return specs


def _probe_entry(*, spec: dict[str, Any], completion: LLMCompletion) -> dict[str, Any]:
    status = "ok" if completion.status == "ok" else "degraded"
    reason = "" if status == "ok" else str(completion.details.get("reason") or completion.status)
    return {
        "provider": spec["provider"],
        "model": spec["model"],
        "status": status,
        "reason": reason,
    }


async def run_provider_health_probe_once(
    *,
    config: LLMProviderConfig,
    specs: list[dict[str, Any]],
    output_path: str | Path | None = None,
    call_completion_fn: ProbeCall = call_dashscope,
) -> dict[str, Any]:
    entries: list[dict[str, Any]] = []
    for spec in specs:
        completion = await call_completion_fn(
            config=config,
            prompt=str(spec.get("prompt") or "ping"),
            model=str(spec["model"]),
            temperature=0.0,
            trace_id="provider-health-probe",
            session_id="provider-health-probe",
            intent="provider_health_probe",
        )
        entries.append(_probe_entry(spec=spec, completion=completion))
    snapshot = build_provider_health_snapshot(entries)
    if output_path:
        write_provider_health_snapshot(output_path, entries)
    return snapshot


__all__ = ["normalize_probe_specs", "run_provider_health_probe_once"]
