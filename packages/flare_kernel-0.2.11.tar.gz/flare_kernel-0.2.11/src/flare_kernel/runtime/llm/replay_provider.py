"""Replay provider adapter for normalized LLM completions."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from flare_kernel.runtime.infrastructure.logging import get_logger
from flare_kernel.runtime.llm.config import env_value
from flare_kernel.runtime.llm.contracts import LLMCompletion

logger = get_logger("flare_kernel.runtime.llm.replay_provider")


def prompt_hash(prompt: str) -> str:
    return hashlib.sha256(str(prompt or "").encode("utf-8")).hexdigest()[:16]


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _fixture_path_candidates(*, prompt: str, intent: str) -> list[Path]:
    direct = env_value("LLM_REPLAY_FIXTURE_PATH")
    if direct:
        return [Path(direct)]

    fixture_name = env_value("LLM_REPLAY_FIXTURE_NAME")
    hashed = prompt_hash(prompt)
    names = [fixture_name] if fixture_name else []
    names.extend([f"{intent}.{hashed}.json", f"{intent}.json", "default.json"])
    configured_dir = env_value("LLM_REPLAY_FIXTURE_DIR")
    fixture_dirs = [Path(configured_dir)] if configured_dir else [
        Path("packages/flare-kernel/tests/fixtures/provider"),
        Path("tests/fixtures/provider"),
    ]
    return [
        fixture_dir / str(name)
        for fixture_dir in fixture_dirs
        for name in names
        if str(name or "").strip()
    ]


def _load_fixture(*, prompt: str, intent: str) -> tuple[dict[str, Any], Path | None]:
    for path in _fixture_path_candidates(prompt=prompt, intent=intent):
        try:
            if path.is_file():
                return json.loads(path.read_text()), path
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("llm.replay.fixture_load_failed path=%s error=%s", path, str(exc))
            return {}, path
    return {}, None


def _completion_payload(data: dict[str, Any]) -> dict[str, Any]:
    nested = data.get("completion")
    return nested if isinstance(nested, dict) else data


def _placeholder_completion(*, prompt: str, intent: str, source: Path | None) -> LLMCompletion:
    hashed = prompt_hash(prompt)
    reason = "fixture_not_found" if source is None else "fixture_invalid"
    return LLMCompletion(
        provider="replay",
        model="fixture",
        content=f"[replay:fixture] LLM replay placeholder ({reason})",
        status="placeholder",
        details={
            "backend": "replay",
            "reason": reason,
            "fixture_source": str(source) if source else "",
            "replay_prompt_hash": hashed,
            "intent": intent,
        },
    )


async def call_replay_provider(*, prompt: str, trace_id: str, session_id: str, intent: str) -> LLMCompletion:
    data, source = _load_fixture(prompt=prompt, intent=intent)
    payload = _completion_payload(data)
    content = payload.get("content")
    if not isinstance(content, str) or not content.strip():
        logger.info("llm.replay.fixture_missing trace_id=%s session_id=%s intent=%s source=%s", trace_id, session_id, intent, source)
        return _placeholder_completion(prompt=prompt, intent=intent, source=source)

    details = _coerce_mapping(payload.get("details"))
    return LLMCompletion(
        provider=str(payload.get("provider") or "replay"),
        model=str(payload.get("model") or "fixture"),
        content=content,
        status=str(payload.get("status") or "ok"),
        details={
            **details,
            "backend": "replay",
            "fixture_source": str(source) if source else "",
            "replay_prompt_hash": prompt_hash(prompt),
            "replay_trace_id": trace_id,
            "replay_session_id": session_id,
            "intent": intent,
            "original_provider": str(payload.get("provider") or ""),
            "original_model": str(payload.get("model") or ""),
            "original_status": str(payload.get("status") or ""),
        },
    )
