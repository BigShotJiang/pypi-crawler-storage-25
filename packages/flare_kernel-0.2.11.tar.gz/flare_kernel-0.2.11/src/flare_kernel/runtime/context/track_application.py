"""Apply track reasoning results to session context patches."""

from __future__ import annotations

from typing import Any


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _claim_items(items: Any, *, prefix: str) -> list[dict[str, Any]]:
    claims: list[dict[str, Any]] = []
    for index, item in enumerate(_as_list(items), start=1):
        text = _clean_text(item)
        if not text:
            continue
        claims.append({"id": f"{prefix}_{index}", "text": text, "meta": {"source": "track_reasoning"}})
    return claims


def build_context_patch_from_track(track_result: dict[str, Any] | None) -> dict[str, Any]:
    result = track_result if isinstance(track_result, dict) else {}
    if not result:
        return {}
    patch: dict[str, Any] = {"track": result}
    goal = _clean_text(result.get("goal"))
    if goal:
        patch["facts"] = _claim_items([f"当前目标：{goal}"], prefix="track_fact")
        patch["session_summary"] = goal
    unknowns = _claim_items(result.get("unknowns"), prefix="track_unknown")
    if unknowns:
        patch["unknowns"] = unknowns
    prompt_enrichment = _clean_text(result.get("prompt_enrichment"))
    if prompt_enrichment:
        patch["notes"] = [prompt_enrichment]
    return patch


__all__ = ["build_context_patch_from_track"]
