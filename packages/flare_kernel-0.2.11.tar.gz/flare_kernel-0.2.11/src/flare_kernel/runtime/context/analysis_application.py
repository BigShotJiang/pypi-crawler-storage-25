"""Apply generated analysis payloads to session context patches.

DOC HELPER — WRK-04 analysis result context writeback boundary.
This module converts a generated analysis payload into an append-only
`context_patch.analysis_results` update. It does not merge session context,
persist data, or mutate the analysis payload.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any


def _as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _schema_version_number(payload: dict[str, Any]) -> int:
    document = _as_dict(payload.get("document"))
    raw = _clean_text(document.get("analysis_schema_version") or payload.get("analysis_schema_version"))
    if raw.startswith("v"):
        raw = raw[1:]
    try:
        return max(1, int(raw or 1))
    except ValueError:
        return 1


def build_context_patch_from_analysis(analysis_payload: dict[str, Any] | None) -> dict[str, Any]:
    payload = analysis_payload if isinstance(analysis_payload, dict) else {}
    if not payload:
        return {}
    return {
        "analysis_results": [
            {
                "version": _schema_version_number(payload),
                "payload": payload,
                "timestamp": datetime.now(UTC).isoformat(),
            }
        ]
    }


__all__ = ["build_context_patch_from_analysis"]
