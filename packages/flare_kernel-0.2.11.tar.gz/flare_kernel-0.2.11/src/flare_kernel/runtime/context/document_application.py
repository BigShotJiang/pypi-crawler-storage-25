"""Apply document understanding results to session context patches."""

from __future__ import annotations

from typing import Any


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def build_context_patch_from_document(document_result: dict[str, Any] | None) -> dict[str, Any]:
    result = document_result if isinstance(document_result, dict) else {}
    if not result:
        return {}
    source_id = _clean_text(result.get("source_id"))
    evidence_id = f"document::{source_id}" if source_id else "document::inline"
    key_facts = [
        {
            "id": f"document_fact::{source_id or 'inline'}::{index}",
            "text": _clean_text(text),
            "source_id": source_id,
            "evidence_ids": [evidence_id],
            "meta": {"document_kind": _clean_text(result.get("document_kind"))},
        }
        for index, text in enumerate(_as_list(result.get("key_facts")), start=1)
        if _clean_text(text)
    ]
    unknowns = [
        {
            "id": f"document_unknown::{source_id or 'inline'}::{index}",
            "text": _clean_text(text),
            "source_id": source_id,
            "evidence_ids": [evidence_id],
            "meta": {"document_kind": _clean_text(result.get("document_kind"))},
        }
        for index, text in enumerate(_as_list(result.get("open_questions")), start=1)
        if _clean_text(text)
    ]
    evidence = {
        "id": evidence_id,
        "source_id": source_id,
        "source": "document_understanding",
        "snippet": _clean_text(result.get("summary")),
        "meta": {
            "title": _clean_text(result.get("title")),
            "document_kind": _clean_text(result.get("document_kind")),
        },
    }
    patch: dict[str, Any] = {
        "artifact_context": [result],
        "evidence": [evidence],
        "source_attributions": [evidence],
    }
    if key_facts:
        patch["facts"] = key_facts
    if unknowns:
        patch["unknowns"] = unknowns
    return patch


__all__ = ["build_context_patch_from_document"]
