"""Apply structured reasoning results to session context patches."""

from __future__ import annotations

from typing import Any

_REASONING_LIST_MAP = {
    "facts": "facts",
    "inferences": "inferences",
    "unknowns": "unknowns",
    "user_focus": "user_focus",
    "response_priorities": "response_priorities",
}


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _normalize_claims(items: Any) -> list[dict[str, Any]]:
    claims: list[dict[str, Any]] = []
    for item in _as_list(items):
        if not isinstance(item, dict):
            continue
        text = _clean_text(item.get("text"))
        if not text:
            continue
        claims.append(
            {
                "id": _clean_text(item.get("id")) or text[:80],
                "text": text,
                "source_id": _clean_text(item.get("source_id")),
                "evidence_ids": [
                    _clean_text(value)
                    for value in _as_list(item.get("evidence_ids"))
                    if _clean_text(value)
                ],
                "confidence": item.get("confidence") if isinstance(item.get("confidence"), (int, float)) else None,
                "meta": item.get("meta") if isinstance(item.get("meta"), dict) else {},
            }
        )
    return claims


def _normalize_text_list(items: Any) -> list[str]:
    return [_clean_text(item) for item in _as_list(items) if _clean_text(item)]


def _normalize_evidence(result: dict[str, Any]) -> list[dict[str, Any]]:
    metadata = result.get("metadata") if isinstance(result.get("metadata"), dict) else {}
    raw_evidence = metadata.get("evidence") if isinstance(metadata.get("evidence"), list) else []
    evidence: list[dict[str, Any]] = []
    for item in raw_evidence:
        if not isinstance(item, dict):
            continue
        evidence_id = _clean_text(item.get("id"))
        source_id = _clean_text(item.get("source_id"))
        if not evidence_id and not source_id:
            continue
        evidence.append(
            {
                "id": evidence_id or f"evidence::{source_id}",
                "source_id": source_id,
                "source": _clean_text(item.get("source")),
                "snippet": _clean_text(item.get("snippet")),
                "meta": item.get("meta") if isinstance(item.get("meta"), dict) else dict(item),
            }
        )
    return evidence


def build_context_patch_from_reasoning(reasoning_result: dict[str, Any] | None) -> dict[str, Any]:
    result = reasoning_result if isinstance(reasoning_result, dict) else {}
    if not result:
        return {}
    patch: dict[str, Any] = {}
    for source_key, target_key in _REASONING_LIST_MAP.items():
        if source_key in {"facts", "inferences", "unknowns"}:
            values = _normalize_claims(result.get(source_key))
        else:
            values = _normalize_text_list(result.get(source_key))
        if values:
            patch[target_key] = values
    evidence = _normalize_evidence(result)
    if evidence:
        patch["evidence"] = evidence
        patch["source_attributions"] = evidence
    input_summary = _clean_text(result.get("input_summary"))
    if input_summary:
        patch["notes"] = [input_summary]
    return patch


__all__ = ["build_context_patch_from_reasoning"]
