"""Runtime context helpers."""

from flare_kernel.runtime.context.analysis_application import build_context_patch_from_analysis
from flare_kernel.runtime.context.document_application import build_context_patch_from_document
from flare_kernel.runtime.context.reasoning_application import build_context_patch_from_reasoning
from flare_kernel.runtime.context.session_context import merge_session_context
from flare_kernel.runtime.context.track_application import build_context_patch_from_track

__all__ = [
    "build_context_patch_from_analysis",
    "build_context_patch_from_document",
    "build_context_patch_from_reasoning",
    "build_context_patch_from_track",
    "merge_session_context",
]
