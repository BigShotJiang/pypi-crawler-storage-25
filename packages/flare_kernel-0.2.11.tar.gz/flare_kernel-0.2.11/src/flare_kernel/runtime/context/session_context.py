"""Session-scoped context snapshot merge utilities."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

from flare_kernel.contracts.context import ContextContract, create_empty_context
from flare_kernel.runtime.context.document_application import build_context_patch_from_document
from flare_kernel.runtime.context.reasoning_application import build_context_patch_from_reasoning
from flare_kernel.runtime.context.track_application import build_context_patch_from_track

_CONTEXT_LIST_KEYS = (
    "user_focus",
    "response_priorities",
    "missing_fields",
    "notes",
    "turns",
    "evidence",
    "facts",
    "inferences",
    "unknowns",
    "source_attributions",
    "artifact_context",
    "sourcing_results",
    "analysis_results",
    "rank_feedback_log",
)
_CONTEXT_DICT_KEYS = ("confirmed_fields", "rank_profile", "track")


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _as_context_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, ContextContract):
        return value.model_dump()
    if isinstance(value, dict):
        return ContextContract.model_validate(value).model_dump()
    return create_empty_context().model_dump()


def _item_key(item: Any) -> str:
    if not isinstance(item, dict):
        return _clean_text(item)
    for key in ("id", "turn_id", "source_id", "text", "snippet"):
        value = _clean_text(item.get(key))
        if value:
            return f"{key}:{value}"
    return repr(sorted(item.items()))


def _merge_list(existing: Any, incoming: Any) -> list[Any]:
    merged: list[Any] = []
    seen: set[str] = set()
    for source in (existing, incoming):
        if not isinstance(source, list):
            continue
        for item in source:
            key = _item_key(item)
            if not key or key in seen:
                continue
            seen.add(key)
            merged.append(item)
    return merged


def _extract_source_id(ref: Any) -> str:
    if isinstance(ref, str):
        return _clean_text(ref)
    if not isinstance(ref, dict):
        return ""
    return _clean_text(ref.get("source_id") or ref.get("id"))


def _build_ref_evidence(refs: list[dict[str, Any]] | None, *, source: str) -> list[dict[str, Any]]:
    evidence: list[dict[str, Any]] = []
    for ref in refs or []:
        source_id = _extract_source_id(ref)
        if not source_id:
            continue
        evidence.append(
            {
                "id": f"evidence::{source}::{source_id}",
                "source_id": source_id,
                "source": source,
                "snippet": _clean_text(ref.get("title") or ref.get("filename") or source_id),
                "meta": dict(ref),
            }
        )
    return evidence


def _build_citation_evidence(citation: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not isinstance(citation, dict):
        return []
    raw_items = citation.get("citations") if isinstance(citation.get("citations"), list) else []
    evidence: list[dict[str, Any]] = []
    for index, item in enumerate(raw_items):
        if not isinstance(item, dict):
            continue
        source_id = _clean_text(item.get("source_id") or item.get("id") or item.get("title"))
        if not source_id:
            continue
        evidence.append(
            {
                "id": _clean_text(item.get("id")) or f"citation::{source_id}::{index}",
                "source_id": source_id,
                "source": _clean_text(item.get("source") or "knowledge_citation"),
                "snippet": _clean_text(item.get("snippet") or item.get("title")),
                "meta": dict(item),
            }
        )
    return evidence


def _build_turn(*, user_message: str, assistant_message: str, source_ids: list[str]) -> dict[str, Any] | None:
    if not _clean_text(user_message) and not _clean_text(assistant_message):
        return None
    return {
        "turn_id": f"turn_{uuid.uuid4().hex[:12]}",
        "user_message": str(user_message or ""),
        "assistant_message": str(assistant_message or ""),
        "source_ids": source_ids,
        "created_at": _now_iso(),
    }


def merge_session_context(
    *,
    existing_context: Any = None,
    user_message: str = "",
    assistant_message: str = "",
    context_refs: list[dict[str, Any]] | None = None,
    knowledge_refs: list[dict[str, Any]] | None = None,
    knowledge_citation: dict[str, Any] | None = None,
    reasoning_result: dict[str, Any] | None = None,
    document_result: dict[str, Any] | None = None,
    track_result: dict[str, Any] | None = None,
    context_patch: dict[str, Any] | None = None,
    context_snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if isinstance(context_snapshot, dict):
        return ContextContract.model_validate(context_snapshot).model_dump()

    base = _as_context_dict(existing_context)
    patch = context_patch if isinstance(context_patch, dict) else {}
    reasoning_patch = build_context_patch_from_reasoning(reasoning_result)
    document_patch = build_context_patch_from_document(document_result)
    track_patch = build_context_patch_from_track(track_result)
    for key in _CONTEXT_DICT_KEYS:
        base[key] = {**(base.get(key) if isinstance(base.get(key), dict) else {}), **(patch.get(key) if isinstance(patch.get(key), dict) else {})}
    for key in _CONTEXT_LIST_KEYS:
        base[key] = _merge_list(base.get(key), patch.get(key))
    for key in _CONTEXT_LIST_KEYS:
        base[key] = _merge_list(base.get(key), reasoning_patch.get(key))
    for key in _CONTEXT_LIST_KEYS:
        base[key] = _merge_list(base.get(key), document_patch.get(key))
    for key in _CONTEXT_DICT_KEYS:
        base[key] = {**(base.get(key) if isinstance(base.get(key), dict) else {}), **(track_patch.get(key) if isinstance(track_patch.get(key), dict) else {})}
    for key in _CONTEXT_LIST_KEYS:
        base[key] = _merge_list(base.get(key), track_patch.get(key))

    ref_evidence = _build_ref_evidence(context_refs, source="context_ref")
    ref_evidence.extend(_build_ref_evidence(knowledge_refs, source="knowledge_ref"))
    ref_evidence.extend(_build_citation_evidence(knowledge_citation))
    base["evidence"] = _merge_list(base.get("evidence"), ref_evidence)
    base["source_attributions"] = _merge_list(base.get("source_attributions"), ref_evidence)

    source_ids = sorted({item["source_id"] for item in ref_evidence if _clean_text(item.get("source_id"))})
    turn = _build_turn(user_message=user_message, assistant_message=assistant_message, source_ids=source_ids)
    if turn is not None:
        base["turns"] = _merge_list(base.get("turns"), [turn])

    if _clean_text(patch.get("session_summary")):
        base["session_summary"] = _clean_text(patch.get("session_summary"))
    if _clean_text(track_patch.get("session_summary")):
        base["session_summary"] = _clean_text(track_patch.get("session_summary"))
    base["updated_at"] = _now_iso()
    return ContextContract.model_validate(base).model_dump()


__all__ = ["merge_session_context"]
