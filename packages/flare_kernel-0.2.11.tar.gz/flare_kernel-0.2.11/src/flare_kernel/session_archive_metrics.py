"""Deterministic metrics for archived session summaries.

DOC HELPER — OBJ-06B metric engine boundary:

This module is a tiny scoring engine for archive review. The formulas are
intentionally simple and deterministic so product behavior can be inspected,
tested, and replaced without changing API contracts.

Metric meanings:
- completeness_score: how much of the archive is confirmed facts vs. still-open
  unknowns. It is not a truth score.
- uncertainty_score: how much unresolved context remains.
- traceability_score: how many fact/unknown items have evidence coverage.
- strategy_trace_score: whether the latest assistant turn persisted strategy
  fields such as plan_payload and execution_trace.
- reuse_potential_score: rough signal that this archive has reusable facts or
  user focus, not permission to auto-promote memory.

What this file must not do:
- No business/domain vocabulary or domain-pack-specific weights.
- No persistence, transport, or UI formatting.
- No LLM judgement; future AI-assisted scoring must normalize into explicit
  metric inputs before entering this module or a replacement engine.
"""

from __future__ import annotations

from typing import Any


def _count(value: Any) -> int:
    """Count list-shaped context fields.

    Args:
        value: Candidate list field.

    Returns:
        Number of items when value is a list, otherwise zero.
    """

    return len(value) if isinstance(value, list) else 0


def _round_score(value: float) -> float:
    """Normalize score precision for stable tests and API responses.

    Args:
        value: Raw score.

    Returns:
        Score clamped to [0, 1] with four decimals.
    """

    return round(max(0.0, min(1.0, value)), 4)


def calculate_archive_metrics(
    *,
    context: dict[str, Any],
    replay_diagnostics: dict[str, Any],
    strategy_fields: list[str],
) -> dict[str, Any]:
    """Calculate archive quality and reuse metrics without model inference.

    Args:
        context: Session context snapshot.
        replay_diagnostics: Replay-level diagnostics payload.
        strategy_fields: Trace fields present on the latest assistant turn.

    Returns:
        Deterministic metrics for archive review and context-window display.
    """

    facts_count = _count(context.get("facts"))
    unknowns_count = _count(context.get("unknowns"))
    evidence_count = _count(context.get("evidence"))
    user_focus_count = _count(context.get("user_focus"))
    total_items = facts_count + unknowns_count + 1
    evidence_base = max(1, facts_count + unknowns_count)
    return {
        "facts_count": facts_count,
        "unknowns_count": unknowns_count,
        "evidence_count": evidence_count,
        "user_focus_count": user_focus_count,
        "turn_count": int(replay_diagnostics.get("turn_count") or 0),
        "message_count": int(replay_diagnostics.get("message_count") or 0),
        "strategy_fields_count": len(strategy_fields),
        "completeness_score": _round_score(facts_count / total_items),
        "uncertainty_score": _round_score(unknowns_count / total_items),
        "traceability_score": _round_score(evidence_count / evidence_base),
        "strategy_trace_score": _round_score(len(strategy_fields) / 4),
        "reuse_potential_score": _round_score((facts_count + user_focus_count) / total_items),
    }


__all__ = ["calculate_archive_metrics"]
