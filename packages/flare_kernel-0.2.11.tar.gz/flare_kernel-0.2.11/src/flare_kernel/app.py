"""FastAPI app factory for flare-kernel."""

from __future__ import annotations

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from flare_kernel.router.api.errors import (
    ApiError,
    api_error_exception_handler,
    http_exception_handler,
    unhandled_exception_handler,
)
from flare_kernel.router import (
    auth_api_router,
    chat_api_router,
    kernel_router,
    list_events_api_router,
    project_api_router,
    run_api_router,
    session_api_router,
    source_library_router,
    update_api_router,
)


def create_app() -> FastAPI:
    app = FastAPI(
        title="FLARE Kernel",
        version="0.1.0",
        description="FLARE kernel minimal runtime",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(auth_api_router)
    app.include_router(kernel_router)
    app.include_router(chat_api_router)
    app.include_router(list_events_api_router)
    app.include_router(project_api_router)
    app.include_router(session_api_router)
    app.include_router(run_api_router)
    app.include_router(update_api_router)
    app.include_router(source_library_router)
    app.add_exception_handler(ApiError, api_error_exception_handler)
    app.add_exception_handler(HTTPException, http_exception_handler)
    app.add_exception_handler(Exception, unhandled_exception_handler)
    return app
