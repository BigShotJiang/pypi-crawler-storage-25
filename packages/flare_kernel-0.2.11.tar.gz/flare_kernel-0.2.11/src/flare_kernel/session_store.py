"""Chat session orchestration facade for session/message APIs.

DOC HELPER — OBJ-09 session append boundary.
Session append stores context authority beside assistant metadata; actual
context merging remains owned by merge_session_context.
"""

from __future__ import annotations

import uuid
import os
from datetime import UTC, datetime
from typing import Any

from flare_kernel.contracts.context import create_empty_context
from flare_kernel.runtime.context import merge_session_context
from flare_kernel.runtime.infrastructure import (
    InMemorySessionRepository,
    SessionRepository,
    SqlAlchemySessionRepository,
)
from flare_kernel.runtime.orchestration.observation import log_session_append_persisted
from flare_kernel.session_archive_context import attach_archive_summary
from flare_kernel.session_lifecycle_policy import (
    SESSION_STATUS_ARCHIVED,
    apply_session_lifecycle_action,
    normalize_session_status,
    normalize_session_status_filter,
    session_status_matches_filter,
)
from flare_kernel.session_record_policy import (
    DEFAULT_SESSION_TITLE,
    TITLE_SOURCE_AUTO,
    TITLE_SOURCE_DEFAULT,
    TITLE_SOURCE_MANUAL,
    extract_auto_title,
    extract_preview,
    find_reusable_draft_session,
    is_default_title,
    normalize_session_record,
    normalize_text,
)

def _build_default_repository() -> SessionRepository:
    """Build the default session repository for runtime use.

    Returns:
        SQL-backed repository when FLARE_POSTGRES_DSN is configured; otherwise in-memory repository.
    """

    if str(os.getenv("FLARE_POSTGRES_DSN") or "").strip():
        return SqlAlchemySessionRepository()
    return InMemorySessionRepository()


_repository: SessionRepository = _build_default_repository()


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _build_session_id() -> str:
    return f"sess_{uuid.uuid4().hex[:12]}"


def _build_message_id() -> str:
    return f"msg_{uuid.uuid4().hex[:12]}"


def set_session_repository(repository: SessionRepository) -> None:
    global _repository
    _repository = repository


def _list_raw_sessions() -> list[dict[str, Any]]:
    return _repository.list_session_records()


def _list_raw_messages_by_session() -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for record in _list_raw_sessions():
        session_id = normalize_text(record.get("session_id"))
        if not session_id:
            continue
        grouped[session_id] = _repository.list_session_messages(session_id)
    return grouped


def create_session(*, function_type: str | None, project_id: str | None, title: str | None, user_id: str | None) -> dict[str, Any]:
    now = _now_iso()
    resolved_title = normalize_text(title) or DEFAULT_SESSION_TITLE
    reusable = find_reusable_draft_session(
        sessions={normalize_text(item.get("session_id")): item for item in _list_raw_sessions()},
        messages=_list_raw_messages_by_session(),
        function_type=function_type,
        project_id=project_id,
        user_id=user_id,
        requested_title=resolved_title,
    )
    if reusable is not None:
        return reusable
    record = {
        "session_id": _build_session_id(),
        "project_id": project_id,
        "title": resolved_title,
        "preview": "",
        "title_source": TITLE_SOURCE_DEFAULT if is_default_title(resolved_title) else TITLE_SOURCE_MANUAL,
        "status": "active",
        "user_id": user_id,
        "function_type": function_type,
        "context": create_empty_context().model_dump(),
        "created_at": now,
        "updated_at": now,
    }
    return _repository.create_session_record(record)


def ensure_session(*, session_id: str | None, function_type: str | None, project_id: str | None, title: str | None, user_id: str | None) -> dict[str, Any]:
    resolved_session_id = normalize_text(session_id)
    if not resolved_session_id:
        return create_session(function_type=function_type, project_id=project_id, title=title, user_id=user_id)
    now = _now_iso()
    resolved_title = normalize_text(title) or DEFAULT_SESSION_TITLE
    existing = _repository.load_session_record(resolved_session_id)
    if existing is not None:
        return dict(existing)
    created = {
        "session_id": resolved_session_id,
        "project_id": project_id,
        "title": resolved_title,
        "preview": "",
        "title_source": TITLE_SOURCE_DEFAULT if is_default_title(resolved_title) else TITLE_SOURCE_MANUAL,
        "status": "active",
        "user_id": user_id,
        "function_type": function_type,
        "context": create_empty_context().model_dump(),
        "created_at": now,
        "updated_at": now,
    }
    return _repository.create_session_record(created)


def list_sessions(*, status: str = "", function_type: str = "", project_id: str = "", user_id: str = "") -> list[dict[str, Any]]:
    """List sessions with lifecycle-aware filtering, sorted by updated_at desc."""

    resolved_status = normalize_session_status_filter(status)
    resolved_function_type = normalize_text(function_type)
    resolved_project_id = normalize_text(project_id)
    resolved_user_id = normalize_text(user_id)
    items = [normalize_session_record(item) for item in _list_raw_sessions()]
    return sorted(
        [
            item for item in items
            if session_status_matches_filter(status=item.get("status"), status_filter=resolved_status)
            and (not resolved_function_type or normalize_text(item.get("function_type")) == resolved_function_type)
            and (not resolved_project_id or normalize_text(item.get("project_id")) == resolved_project_id)
            and (not resolved_user_id or normalize_text(item.get("user_id")) == resolved_user_id)
        ],
        key=lambda item: str(item.get("updated_at") or ""),
        reverse=True,
    )


def get_session(*, session_id: str) -> dict[str, Any] | None:
    resolved = normalize_text(session_id)
    if not resolved:
        return None
    record = _repository.load_session_record(resolved)
    return normalize_session_record(record) if record else None


def update_session(
    *,
    session_id: str,
    title: str | None = None,
    status: str | None = None,
    function_type: str | None = None,
    preview: str | None = None,
    title_source: str | None = None,
) -> dict[str, Any] | None:
    """Update mutable session metadata through the repository boundary."""

    resolved = normalize_text(session_id)
    if not resolved:
        return None
    record = _repository.load_session_record(resolved)
    if record is None:
        return None
    next_record = dict(record)
    if title is not None:
        resolved_title = normalize_text(title)
        if resolved_title:
            next_record["title"] = resolved_title
            next_record["title_source"] = TITLE_SOURCE_MANUAL
    if status is not None and normalize_text(status):
        next_status = normalize_session_status(status)
        if next_status == SESSION_STATUS_ARCHIVED:
            messages = _repository.list_session_messages(resolved)
            next_record["context"] = attach_archive_summary(session=next_record, messages=messages, created_at=_now_iso())
        next_record["status"] = next_status
    if function_type is not None:
        next_record["function_type"] = function_type
    if preview is not None:
        next_record["preview"] = normalize_text(preview)
    if title_source is not None and normalize_text(title_source):
        next_record["title_source"] = normalize_text(title_source)
    next_record["updated_at"] = _now_iso()
    return _repository.save_session_record(normalize_session_record(next_record))


def apply_lifecycle_action(*, session_id: str, action: str) -> dict[str, Any] | None:
    """Apply an explicit lifecycle action and persist the resulting status."""

    resolved = normalize_text(session_id)
    if not resolved:
        return None
    record = _repository.load_session_record(resolved)
    if record is None:
        return None
    next_record = dict(record)
    next_status = apply_session_lifecycle_action(
        current_status=record.get("status"),
        action=action,
    )
    if next_status == SESSION_STATUS_ARCHIVED:
        messages = _repository.list_session_messages(resolved)
        next_record["context"] = attach_archive_summary(session=record, messages=messages, created_at=_now_iso())
    next_record["status"] = next_status
    next_record["updated_at"] = _now_iso()
    return _repository.save_session_record(normalize_session_record(next_record))


def list_messages(*, session_id: str) -> list[dict[str, Any]]:
    resolved = normalize_text(session_id)
    if not resolved:
        return []
    return _repository.list_session_messages(resolved)


def append_exchange(
    *,
    session_id: str,
    run_id: str = "",
    user_message: str = "",
    assistant_message: str = "",
    attachments: list[dict[str, Any]] | None = None,
    context_refs: list[dict[str, Any]] | None = None,
    knowledge_refs: list[dict[str, Any]] | None = None,
    agent_status: dict[str, Any] | None = None,
    thinking_trace: str = "",
    execution_trace: dict[str, Any] | None = None,
    knowledge_search: dict[str, Any] | None = None,
    sourcing_candidates: dict[str, Any] | None = None,
    knowledge_citation: dict[str, Any] | None = None,
    canvas_state: dict[str, Any] | None = None,
    analysis_payload: dict[str, Any] | None = None,
    context_usage: dict[str, Any] | None = None,
    provider_trace: dict[str, Any] | None = None,
    context_authority: dict[str, Any] | None = None,
    plan_payload: dict[str, Any] | None = None,
    reasoning_result: dict[str, Any] | None = None,
    document_result: dict[str, Any] | None = None,
    track_result: dict[str, Any] | None = None,
    context_patch: dict[str, Any] | None = None,
    context_snapshot: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    resolved = normalize_text(session_id)
    if not resolved:
        return None
    record = _repository.load_session_record(resolved)
    if record is None:
        return None
    normalized_user_message = str(user_message or "")
    normalized_assistant_message = str(assistant_message or "")
    normalized_run_id = normalize_text(run_id)
    pending_messages: list[dict[str, Any]] = []
    if normalize_text(normalized_user_message):
        pending_messages.append(
            {
                "message_id": _build_message_id(),
                "session_id": resolved,
                "run_id": normalized_run_id,
                "role": "user",
                "content": normalized_user_message,
                "attachments": list(attachments or []),
                "context_refs": list(context_refs or []),
                "knowledge_refs": list(knowledge_refs or []),
                "created_at": _now_iso(),
            }
        )
    if normalize_text(normalized_assistant_message):
        pending_messages.append(
            {
                "message_id": _build_message_id(),
                "session_id": resolved,
                "run_id": normalized_run_id,
                "role": "assistant",
                "content": normalized_assistant_message,
                "agent_status": agent_status,
                "thinking_trace": str(thinking_trace or ""),
                "execution_trace": execution_trace,
                "knowledge_search": knowledge_search,
                "sourcing_candidates": sourcing_candidates,
                "knowledge_citation": knowledge_citation,
                "canvas_state": canvas_state,
                "analysis_payload": analysis_payload,
                "context_usage": context_usage,
                "provider_trace": provider_trace,
                "context_authority": context_authority,
                "plan_payload": plan_payload,
                "created_at": _now_iso(),
            }
        )
    if pending_messages:
        _repository.append_session_messages(resolved, pending_messages)
    log_session_append_persisted(
        session_id=resolved,
        user_message=normalized_user_message,
        assistant_message=normalized_assistant_message,
        plan_payload=plan_payload,
    )
    next_record = dict(record)
    next_record["context"] = merge_session_context(
        existing_context=record.get("context"),
        user_message=normalized_user_message,
        assistant_message=normalized_assistant_message,
        context_refs=context_refs,
        knowledge_refs=knowledge_refs,
        knowledge_citation=knowledge_citation,
        reasoning_result=reasoning_result,
        document_result=document_result,
        track_result=track_result,
        context_patch=context_patch,
        context_snapshot=context_snapshot,
    )
    next_preview = extract_preview(user_message=normalized_user_message, assistant_message=normalized_assistant_message)
    if next_preview:
        next_record["preview"] = next_preview
    current_title_source = normalize_text(next_record.get("title_source")) or TITLE_SOURCE_DEFAULT
    if current_title_source != TITLE_SOURCE_MANUAL and is_default_title(next_record.get("title")):
        auto_title = extract_auto_title(normalized_user_message) or extract_auto_title(next_preview)
        if auto_title:
            next_record["title"] = auto_title
            next_record["title_source"] = TITLE_SOURCE_AUTO
    next_record["updated_at"] = _now_iso()
    return _repository.save_session_record(normalize_session_record(next_record))


def reset_store_for_testing() -> None:
    global _repository
    _repository = InMemorySessionRepository()
