"""Deterministic archived-session summary assembly.

DOC HELPER — OBJ-06B archive intelligence boundary:

This module is the *archive summary assembler*. It turns one persisted session
record plus its persisted messages into `session.context.archive_summary`.

What this file owns:
- Selecting already-authoritative context fields that should survive archive.
- Projecting latest assistant strategy metadata into a reviewable shape.
- Calling deterministic graph and metric helpers.
- Producing promotion *candidates* for future Project Memory governance.

What this file must not own:
- No database writes; session_store/repository owns persistence.
- No transport/API response framing; router contracts own that.
- No provider/LLM calls; archive MVP is formula/structure based.
- No direct Project Memory promotion; candidates require a later governance step.

Why this exists:
Archive is not only a lifecycle status. It is the point where volatile session
context becomes a reviewable artifact: "what was learned, what is still open,
what strategy was used, and why this session may be reusable later."
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from flare_kernel.session_archive_graph import build_archive_relationship_graph
from flare_kernel.session_archive_metrics import calculate_archive_metrics


def _clean_text(value: Any) -> str:
    """Normalize text used in archive summaries."""

    return " ".join(str(value or "").split()).strip()


def _as_dict(value: Any) -> dict[str, Any]:
    """Return a dict only for object-shaped values."""

    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    """Return a list only for list-shaped values."""

    return value if isinstance(value, list) else []


def _latest_assistant(messages: list[dict[str, Any]]) -> dict[str, Any]:
    """Return the latest assistant message from persisted messages."""

    for message in reversed(messages):
        if _clean_text(message.get("role")) == "assistant":
            return message
    return {}


def _strategy_fields(message: dict[str, Any]) -> list[str]:
    """List strategy fields present on the latest assistant message."""

    fields = []
    for key in ("agent_status", "execution_trace", "knowledge_search", "sourcing_candidates", "context_usage", "plan_payload"):
        if message.get(key):
            fields.append(key)
    if _clean_text(message.get("thinking_trace")):
        fields.append("thinking_trace")
    return fields


def _last_strategy(message: dict[str, Any]) -> dict[str, Any]:
    """Project latest assistant strategy metadata into archive shape."""

    plan = _as_dict(message.get("plan_payload"))
    return {
        "mode_key": plan.get("mode_key"),
        "mode_state": plan.get("mode_state"),
        "current_question": _as_dict(plan.get("current_question")),
        "next_actions": _as_list(plan.get("next_actions")),
        "execution_trace": _as_dict(message.get("execution_trace")),
        "strategy_fields": _strategy_fields(message),
    }


def _summary_text(*, context: dict[str, Any], session: dict[str, Any], latest_assistant: dict[str, Any]) -> str:
    """Resolve archive summary text from authoritative existing fields."""

    return (
        _clean_text(context.get("session_summary"))
        or _clean_text(latest_assistant.get("content"))
        or _clean_text(session.get("preview"))
        or _clean_text(session.get("title"))
    )


def _promotion_candidates(*, summary: str, facts: list[Any], unknowns: list[Any], session_id: str) -> list[dict[str, Any]]:
    """Build Project Memory promotion candidates without persisting them."""

    candidates = []
    if summary:
        candidates.append({"memory_type": "summary", "content": summary, "source": "archive_summary", "source_session_id": session_id})
    for item in facts:
        text = _clean_text(item.get("text") if isinstance(item, dict) else item)
        if text:
            candidates.append({"memory_type": "fact", "content": text, "source": "archive_summary", "source_session_id": session_id})
    for item in unknowns:
        text = _clean_text(item.get("text") if isinstance(item, dict) else item)
        if text:
            candidates.append({"memory_type": "open_question", "content": text, "source": "archive_summary", "source_session_id": session_id})
    return candidates


def build_session_archive_summary(
    *,
    session: dict[str, Any],
    messages: list[dict[str, Any]],
    created_at: str | None = None,
) -> dict[str, Any]:
    """Build a deterministic archive summary for one session.

    Args:
        session: Session record containing context and metadata.
        messages: Persisted session messages.
        created_at: Optional timestamp supplied by the caller for test stability.

    Returns:
        Archive summary dict suitable for session.context.archive_summary.
    """

    context = _as_dict(session.get("context"))
    latest_assistant = _latest_assistant(messages)
    strategy = _last_strategy(latest_assistant)
    summary = _summary_text(context=context, session=session, latest_assistant=latest_assistant)
    facts = _as_list(context.get("facts"))
    unknowns = _as_list(context.get("unknowns"))
    user_focus = _as_list(context.get("user_focus"))
    replay_diagnostics = {"message_count": len(messages), "turn_count": len(_as_list(context.get("turns")))}
    graph = build_archive_relationship_graph(
        summary=summary,
        facts=facts,
        unknowns=unknowns,
        user_focus=user_focus,
        current_question=strategy.get("current_question"),
    )
    metrics = calculate_archive_metrics(
        context=context,
        replay_diagnostics=replay_diagnostics,
        strategy_fields=strategy.get("strategy_fields") or [],
    )
    return {
        "schema_version": "session.archive_summary.v1",
        "created_at": created_at or datetime.now(UTC).isoformat(),
        "summary": summary,
        "facts": facts,
        "unknowns": unknowns,
        "user_focus": user_focus,
        "last_strategy": strategy,
        "replay_diagnostics": replay_diagnostics,
        "relationship_graph": graph,
        "metrics": metrics,
        "promotion_candidates": _promotion_candidates(summary=summary, facts=facts, unknowns=unknowns, session_id=_clean_text(session.get("session_id"))),
    }


__all__ = ["build_session_archive_summary"]
