"""Pure session lifecycle policy."""

from __future__ import annotations

from typing import Any

SESSION_STATUS_ACTIVE = "active"
SESSION_STATUS_ARCHIVED = "archived"
SESSION_STATUS_ALL = "all"

SESSION_LIFECYCLE_ARCHIVE = "archive"
SESSION_LIFECYCLE_RESTORE = "restore"

# Keep lifecycle vocabulary centralized so API/store layers do not invent states.
_ALLOWED_STATUSES = {SESSION_STATUS_ACTIVE, SESSION_STATUS_ARCHIVED}
_ALLOWED_ACTIONS = {SESSION_LIFECYCLE_ARCHIVE, SESSION_LIFECYCLE_RESTORE}


def normalize_lifecycle_text(value: Any) -> str:
    """Normalize lifecycle command text.

    Args:
        value: Raw lifecycle command or status value.

    Returns:
        Lowercase, whitespace-normalized string.
    """

    return " ".join(str(value or "").split()).strip().lower()


def normalize_session_status(value: Any, *, default: str = SESSION_STATUS_ACTIVE) -> str:
    """Normalize and validate a persisted session status.

    Args:
        value: Raw status value from API input or storage.
        default: Status to use when value is empty.

    Returns:
        Supported session status.

    Raises:
        ValueError: When the status is not supported by the lifecycle policy.
    """

    status = normalize_lifecycle_text(value) or default
    if status not in _ALLOWED_STATUSES:
        raise ValueError(f"unsupported session status: {status}")
    return status


def normalize_session_status_filter(value: Any) -> str:
    """Normalize list-session status filtering semantics.

    Args:
        value: Raw status query parameter.

    Returns:
        `active` for empty filters, `all` for all sessions, or a supported status.

    Raises:
        ValueError: When the requested status filter is unsupported.
    """

    status = normalize_lifecycle_text(value)
    if not status:
        return SESSION_STATUS_ACTIVE
    if status == SESSION_STATUS_ALL:
        return SESSION_STATUS_ALL
    return normalize_session_status(status)


def session_status_matches_filter(*, status: Any, status_filter: str) -> bool:
    """Return whether a session status belongs in a list result.

    Args:
        status: Raw session status from storage.
        status_filter: Normalized status filter from normalize_session_status_filter.

    Returns:
        True when the session should be included in the list response.
    """

    if status_filter == SESSION_STATUS_ALL:
        return True
    return normalize_session_status(status) == status_filter


def apply_session_lifecycle_action(*, current_status: Any, action: Any) -> str:
    """Resolve the next status for a lifecycle action.

    Args:
        current_status: Current persisted session status.
        action: Requested lifecycle action.

    Returns:
        Next session status after applying the lifecycle action.

    Raises:
        ValueError: When current status or requested action is unsupported.
    """

    normalize_session_status(current_status)
    lifecycle_action = normalize_lifecycle_text(action)
    if lifecycle_action not in _ALLOWED_ACTIONS:
        raise ValueError(f"unsupported session lifecycle action: {lifecycle_action}")
    if lifecycle_action == SESSION_LIFECYCLE_ARCHIVE:
        return SESSION_STATUS_ARCHIVED
    return SESSION_STATUS_ACTIVE


__all__ = [
    "SESSION_LIFECYCLE_ARCHIVE",
    "SESSION_LIFECYCLE_RESTORE",
    "SESSION_STATUS_ACTIVE",
    "SESSION_STATUS_ALL",
    "SESSION_STATUS_ARCHIVED",
    "apply_session_lifecycle_action",
    "normalize_lifecycle_text",
    "normalize_session_status",
    "normalize_session_status_filter",
    "session_status_matches_filter",
]
