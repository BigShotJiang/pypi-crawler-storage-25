from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID
from warnings import warn

if TYPE_CHECKING:
    from .....models.pki_log_page import PkiLogPage

class LogsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/pki/logs
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new LogsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/pki/logs{?action*,actorType*,apiKeyId*,environmentId*,from*,page*,projectSlug*,roleName*,search*,size*,to*}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[LogsRequestBuilderGetQueryParameters]] = None) -> Optional[PkiLogPage]:
        """
        GET_api_v1_pki_logs
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[PkiLogPage]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.pki_log_page import PkiLogPage

        return await self.request_adapter.send_async(request_info, PkiLogPage, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[LogsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        GET_api_v1_pki_logs
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> LogsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: LogsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return LogsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class LogsRequestBuilderGetQueryParameters():
        """
        GET_api_v1_pki_logs
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "actor_type":
                return "actorType"
            if original_name == "api_key_id":
                return "apiKeyId"
            if original_name == "environment_id":
                return "environmentId"
            if original_name == "project_slug":
                return "projectSlug"
            if original_name == "role_name":
                return "roleName"
            if original_name == "action":
                return "action"
            if original_name == "from_":
                return "from_"
            if original_name == "page":
                return "page"
            if original_name == "search":
                return "search"
            if original_name == "size":
                return "size"
            if original_name == "to":
                return "to"
            return original_name
        
        action: Optional[str] = None

        actor_type: Optional[str] = None

        api_key_id: Optional[UUID] = None

        environment_id: Optional[UUID] = None

        from_: Optional[datetime.datetime] = None

        page: Optional[int] = None

        project_slug: Optional[str] = None

        role_name: Optional[str] = None

        search: Optional[str] = None

        size: Optional[int] = None

        to: Optional[datetime.datetime] = None

    
    @dataclass
    class LogsRequestBuilderGetRequestConfiguration(RequestConfiguration[LogsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

