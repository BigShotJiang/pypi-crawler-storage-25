from dlubal.api.common import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ConversionTables(_message.Message):
    __slots__ = ("material_conversion_tables_manager", "cross_section_conversion_tables_manager")
    class MaterialConversionTablesManager(_message.Message):
        __slots__ = ("property_active_config", "property_default_config_string_key", "configs")
        class MaterialConversionTablesManagerConfigs(_message.Message):
            __slots__ = ("rows",)
            ROWS_FIELD_NUMBER: _ClassVar[int]
            rows: _containers.RepeatedCompositeFieldContainer[ConversionTables.MaterialConversionTablesManager.MaterialConversionTablesManagerConfig]
            def __init__(self, rows: _Optional[_Iterable[_Union[ConversionTables.MaterialConversionTablesManager.MaterialConversionTablesManagerConfig, _Mapping]]] = ...) -> None: ...
        class MaterialConversionTablesManagerConfig(_message.Message):
            __slots__ = ("property_config_user_name", "property_config_id", "property_conversion_table", "property_imported_ifc_property")
            PROPERTY_CONFIG_USER_NAME_FIELD_NUMBER: _ClassVar[int]
            PROPERTY_CONFIG_ID_FIELD_NUMBER: _ClassVar[int]
            PROPERTY_CONVERSION_TABLE_FIELD_NUMBER: _ClassVar[int]
            PROPERTY_IMPORTED_IFC_PROPERTY_FIELD_NUMBER: _ClassVar[int]
            property_config_user_name: str
            property_config_id: int
            property_conversion_table: _common_pb2.StringPairList
            property_imported_ifc_property: _common_pb2.StringPairList
            def __init__(self, property_config_user_name: _Optional[str] = ..., property_config_id: _Optional[int] = ..., property_conversion_table: _Optional[_Union[_common_pb2.StringPairList, _Mapping]] = ..., property_imported_ifc_property: _Optional[_Union[_common_pb2.StringPairList, _Mapping]] = ...) -> None: ...
        PROPERTY_ACTIVE_CONFIG_FIELD_NUMBER: _ClassVar[int]
        PROPERTY_DEFAULT_CONFIG_STRING_KEY_FIELD_NUMBER: _ClassVar[int]
        CONFIGS_FIELD_NUMBER: _ClassVar[int]
        property_active_config: int
        property_default_config_string_key: str
        configs: ConversionTables.MaterialConversionTablesManager.MaterialConversionTablesManagerConfigs
        def __init__(self, property_active_config: _Optional[int] = ..., property_default_config_string_key: _Optional[str] = ..., configs: _Optional[_Union[ConversionTables.MaterialConversionTablesManager.MaterialConversionTablesManagerConfigs, _Mapping]] = ...) -> None: ...
    class CrossSectionConversionTablesManager(_message.Message):
        __slots__ = ("property_active_config", "property_default_config_string_key", "configs")
        class CrossSectionConversionTablesManagerConfigs(_message.Message):
            __slots__ = ("rows",)
            ROWS_FIELD_NUMBER: _ClassVar[int]
            rows: _containers.RepeatedCompositeFieldContainer[ConversionTables.CrossSectionConversionTablesManager.CrossSectionConversionTablesManagerConfig]
            def __init__(self, rows: _Optional[_Iterable[_Union[ConversionTables.CrossSectionConversionTablesManager.CrossSectionConversionTablesManagerConfig, _Mapping]]] = ...) -> None: ...
        class CrossSectionConversionTablesManagerConfig(_message.Message):
            __slots__ = ("property_config_user_name", "property_config_id", "property_conversion_table", "property_imported_ifc_property")
            PROPERTY_CONFIG_USER_NAME_FIELD_NUMBER: _ClassVar[int]
            PROPERTY_CONFIG_ID_FIELD_NUMBER: _ClassVar[int]
            PROPERTY_CONVERSION_TABLE_FIELD_NUMBER: _ClassVar[int]
            PROPERTY_IMPORTED_IFC_PROPERTY_FIELD_NUMBER: _ClassVar[int]
            property_config_user_name: str
            property_config_id: int
            property_conversion_table: _common_pb2.StringPairList
            property_imported_ifc_property: _common_pb2.StringPairList
            def __init__(self, property_config_user_name: _Optional[str] = ..., property_config_id: _Optional[int] = ..., property_conversion_table: _Optional[_Union[_common_pb2.StringPairList, _Mapping]] = ..., property_imported_ifc_property: _Optional[_Union[_common_pb2.StringPairList, _Mapping]] = ...) -> None: ...
        PROPERTY_ACTIVE_CONFIG_FIELD_NUMBER: _ClassVar[int]
        PROPERTY_DEFAULT_CONFIG_STRING_KEY_FIELD_NUMBER: _ClassVar[int]
        CONFIGS_FIELD_NUMBER: _ClassVar[int]
        property_active_config: int
        property_default_config_string_key: str
        configs: ConversionTables.CrossSectionConversionTablesManager.CrossSectionConversionTablesManagerConfigs
        def __init__(self, property_active_config: _Optional[int] = ..., property_default_config_string_key: _Optional[str] = ..., configs: _Optional[_Union[ConversionTables.CrossSectionConversionTablesManager.CrossSectionConversionTablesManagerConfigs, _Mapping]] = ...) -> None: ...
    MATERIAL_CONVERSION_TABLES_MANAGER_FIELD_NUMBER: _ClassVar[int]
    CROSS_SECTION_CONVERSION_TABLES_MANAGER_FIELD_NUMBER: _ClassVar[int]
    material_conversion_tables_manager: ConversionTables.MaterialConversionTablesManager
    cross_section_conversion_tables_manager: ConversionTables.CrossSectionConversionTablesManager
    def __init__(self, material_conversion_tables_manager: _Optional[_Union[ConversionTables.MaterialConversionTablesManager, _Mapping]] = ..., cross_section_conversion_tables_manager: _Optional[_Union[ConversionTables.CrossSectionConversionTablesManager, _Mapping]] = ...) -> None: ...
