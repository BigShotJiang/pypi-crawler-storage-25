from dlubal.api.common import common_pb2 as _common_pb2
from dlubal.api.rfem import referenced_object_pb2 as _referenced_object_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PointCloud(_message.Message):
    __slots__ = ("no", "user_defined_name_enabled", "name", "coordinate_system", "origin_coordinates", "origin_coordinate_x", "origin_coordinate_y", "origin_coordinate_z", "points_number_definition_option", "points_number_total", "points_number_in_direction_x", "points_number_in_direction_y", "points_number_in_direction_z", "dimension_A", "dimension_B", "dimension_C", "dimension_R", "specific_direction_type", "axes_sequence", "rotated_about_angle_x", "rotated_about_angle_y", "rotated_about_angle_z", "rotated_about_angle_1", "rotated_about_angle_2", "rotated_about_angle_3", "directed_to_node_first_axis", "directed_to_node_direction_node", "directed_to_node_second_axis", "directed_to_node_plane_node", "parallel_to_two_nodes_first_node", "parallel_to_two_nodes_second_node", "parallel_to_two_nodes_first_axis", "parallel_to_two_nodes_second_axis", "parallel_to_two_nodes_plane_node", "parallel_to_line", "parallel_to_member", "comment", "is_generated", "generating_object_info", "id_for_export_import", "metadata_for_export_import")
    class PointsNumberDefinitionOption(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        POINTS_NUMBER_DEFINITION_OPTION_POINTS_NUMBER_TOTAL: _ClassVar[PointCloud.PointsNumberDefinitionOption]
        POINTS_NUMBER_DEFINITION_OPTION_POINTS_NUMBER_IN_DIRECTION: _ClassVar[PointCloud.PointsNumberDefinitionOption]
    POINTS_NUMBER_DEFINITION_OPTION_POINTS_NUMBER_TOTAL: PointCloud.PointsNumberDefinitionOption
    POINTS_NUMBER_DEFINITION_OPTION_POINTS_NUMBER_IN_DIRECTION: PointCloud.PointsNumberDefinitionOption
    class SpecificDirectionType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        SPECIFIC_DIRECTION_TYPE_ROTATED_VIA_3_ANGLES: _ClassVar[PointCloud.SpecificDirectionType]
        SPECIFIC_DIRECTION_TYPE_DIRECTED_TO_NODE: _ClassVar[PointCloud.SpecificDirectionType]
        SPECIFIC_DIRECTION_TYPE_PARALLEL_TO_CS_OF_LINE: _ClassVar[PointCloud.SpecificDirectionType]
        SPECIFIC_DIRECTION_TYPE_PARALLEL_TO_CS_OF_MEMBER: _ClassVar[PointCloud.SpecificDirectionType]
        SPECIFIC_DIRECTION_TYPE_PARALLEL_TO_TWO_NODES: _ClassVar[PointCloud.SpecificDirectionType]
    SPECIFIC_DIRECTION_TYPE_ROTATED_VIA_3_ANGLES: PointCloud.SpecificDirectionType
    SPECIFIC_DIRECTION_TYPE_DIRECTED_TO_NODE: PointCloud.SpecificDirectionType
    SPECIFIC_DIRECTION_TYPE_PARALLEL_TO_CS_OF_LINE: PointCloud.SpecificDirectionType
    SPECIFIC_DIRECTION_TYPE_PARALLEL_TO_CS_OF_MEMBER: PointCloud.SpecificDirectionType
    SPECIFIC_DIRECTION_TYPE_PARALLEL_TO_TWO_NODES: PointCloud.SpecificDirectionType
    class AxesSequence(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        AXES_SEQUENCE_XYZ: _ClassVar[PointCloud.AxesSequence]
        AXES_SEQUENCE_XZY: _ClassVar[PointCloud.AxesSequence]
        AXES_SEQUENCE_YXZ: _ClassVar[PointCloud.AxesSequence]
        AXES_SEQUENCE_YZX: _ClassVar[PointCloud.AxesSequence]
        AXES_SEQUENCE_ZXY: _ClassVar[PointCloud.AxesSequence]
        AXES_SEQUENCE_ZYX: _ClassVar[PointCloud.AxesSequence]
    AXES_SEQUENCE_XYZ: PointCloud.AxesSequence
    AXES_SEQUENCE_XZY: PointCloud.AxesSequence
    AXES_SEQUENCE_YXZ: PointCloud.AxesSequence
    AXES_SEQUENCE_YZX: PointCloud.AxesSequence
    AXES_SEQUENCE_ZXY: PointCloud.AxesSequence
    AXES_SEQUENCE_ZYX: PointCloud.AxesSequence
    class DirectedToNodeFirstAxis(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        DIRECTED_TO_NODE_FIRST_AXIS_X: _ClassVar[PointCloud.DirectedToNodeFirstAxis]
        DIRECTED_TO_NODE_FIRST_AXIS_Y: _ClassVar[PointCloud.DirectedToNodeFirstAxis]
        DIRECTED_TO_NODE_FIRST_AXIS_Z: _ClassVar[PointCloud.DirectedToNodeFirstAxis]
    DIRECTED_TO_NODE_FIRST_AXIS_X: PointCloud.DirectedToNodeFirstAxis
    DIRECTED_TO_NODE_FIRST_AXIS_Y: PointCloud.DirectedToNodeFirstAxis
    DIRECTED_TO_NODE_FIRST_AXIS_Z: PointCloud.DirectedToNodeFirstAxis
    class DirectedToNodeSecondAxis(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        DIRECTED_TO_NODE_SECOND_AXIS_X: _ClassVar[PointCloud.DirectedToNodeSecondAxis]
        DIRECTED_TO_NODE_SECOND_AXIS_Y: _ClassVar[PointCloud.DirectedToNodeSecondAxis]
        DIRECTED_TO_NODE_SECOND_AXIS_Z: _ClassVar[PointCloud.DirectedToNodeSecondAxis]
    DIRECTED_TO_NODE_SECOND_AXIS_X: PointCloud.DirectedToNodeSecondAxis
    DIRECTED_TO_NODE_SECOND_AXIS_Y: PointCloud.DirectedToNodeSecondAxis
    DIRECTED_TO_NODE_SECOND_AXIS_Z: PointCloud.DirectedToNodeSecondAxis
    class ParallelToTwoNodesFirstAxis(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        PARALLEL_TO_TWO_NODES_FIRST_AXIS_X: _ClassVar[PointCloud.ParallelToTwoNodesFirstAxis]
        PARALLEL_TO_TWO_NODES_FIRST_AXIS_Y: _ClassVar[PointCloud.ParallelToTwoNodesFirstAxis]
        PARALLEL_TO_TWO_NODES_FIRST_AXIS_Z: _ClassVar[PointCloud.ParallelToTwoNodesFirstAxis]
    PARALLEL_TO_TWO_NODES_FIRST_AXIS_X: PointCloud.ParallelToTwoNodesFirstAxis
    PARALLEL_TO_TWO_NODES_FIRST_AXIS_Y: PointCloud.ParallelToTwoNodesFirstAxis
    PARALLEL_TO_TWO_NODES_FIRST_AXIS_Z: PointCloud.ParallelToTwoNodesFirstAxis
    class ParallelToTwoNodesSecondAxis(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        PARALLEL_TO_TWO_NODES_SECOND_AXIS_X: _ClassVar[PointCloud.ParallelToTwoNodesSecondAxis]
        PARALLEL_TO_TWO_NODES_SECOND_AXIS_Y: _ClassVar[PointCloud.ParallelToTwoNodesSecondAxis]
        PARALLEL_TO_TWO_NODES_SECOND_AXIS_Z: _ClassVar[PointCloud.ParallelToTwoNodesSecondAxis]
    PARALLEL_TO_TWO_NODES_SECOND_AXIS_X: PointCloud.ParallelToTwoNodesSecondAxis
    PARALLEL_TO_TWO_NODES_SECOND_AXIS_Y: PointCloud.ParallelToTwoNodesSecondAxis
    PARALLEL_TO_TWO_NODES_SECOND_AXIS_Z: PointCloud.ParallelToTwoNodesSecondAxis
    NO_FIELD_NUMBER: _ClassVar[int]
    USER_DEFINED_NAME_ENABLED_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    COORDINATE_SYSTEM_FIELD_NUMBER: _ClassVar[int]
    ORIGIN_COORDINATES_FIELD_NUMBER: _ClassVar[int]
    ORIGIN_COORDINATE_X_FIELD_NUMBER: _ClassVar[int]
    ORIGIN_COORDINATE_Y_FIELD_NUMBER: _ClassVar[int]
    ORIGIN_COORDINATE_Z_FIELD_NUMBER: _ClassVar[int]
    POINTS_NUMBER_DEFINITION_OPTION_FIELD_NUMBER: _ClassVar[int]
    POINTS_NUMBER_TOTAL_FIELD_NUMBER: _ClassVar[int]
    POINTS_NUMBER_IN_DIRECTION_X_FIELD_NUMBER: _ClassVar[int]
    POINTS_NUMBER_IN_DIRECTION_Y_FIELD_NUMBER: _ClassVar[int]
    POINTS_NUMBER_IN_DIRECTION_Z_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_A_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_B_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_C_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_R_FIELD_NUMBER: _ClassVar[int]
    SPECIFIC_DIRECTION_TYPE_FIELD_NUMBER: _ClassVar[int]
    AXES_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    ROTATED_ABOUT_ANGLE_X_FIELD_NUMBER: _ClassVar[int]
    ROTATED_ABOUT_ANGLE_Y_FIELD_NUMBER: _ClassVar[int]
    ROTATED_ABOUT_ANGLE_Z_FIELD_NUMBER: _ClassVar[int]
    ROTATED_ABOUT_ANGLE_1_FIELD_NUMBER: _ClassVar[int]
    ROTATED_ABOUT_ANGLE_2_FIELD_NUMBER: _ClassVar[int]
    ROTATED_ABOUT_ANGLE_3_FIELD_NUMBER: _ClassVar[int]
    DIRECTED_TO_NODE_FIRST_AXIS_FIELD_NUMBER: _ClassVar[int]
    DIRECTED_TO_NODE_DIRECTION_NODE_FIELD_NUMBER: _ClassVar[int]
    DIRECTED_TO_NODE_SECOND_AXIS_FIELD_NUMBER: _ClassVar[int]
    DIRECTED_TO_NODE_PLANE_NODE_FIELD_NUMBER: _ClassVar[int]
    PARALLEL_TO_TWO_NODES_FIRST_NODE_FIELD_NUMBER: _ClassVar[int]
    PARALLEL_TO_TWO_NODES_SECOND_NODE_FIELD_NUMBER: _ClassVar[int]
    PARALLEL_TO_TWO_NODES_FIRST_AXIS_FIELD_NUMBER: _ClassVar[int]
    PARALLEL_TO_TWO_NODES_SECOND_AXIS_FIELD_NUMBER: _ClassVar[int]
    PARALLEL_TO_TWO_NODES_PLANE_NODE_FIELD_NUMBER: _ClassVar[int]
    PARALLEL_TO_LINE_FIELD_NUMBER: _ClassVar[int]
    PARALLEL_TO_MEMBER_FIELD_NUMBER: _ClassVar[int]
    COMMENT_FIELD_NUMBER: _ClassVar[int]
    IS_GENERATED_FIELD_NUMBER: _ClassVar[int]
    GENERATING_OBJECT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FOR_EXPORT_IMPORT_FIELD_NUMBER: _ClassVar[int]
    METADATA_FOR_EXPORT_IMPORT_FIELD_NUMBER: _ClassVar[int]
    no: int
    user_defined_name_enabled: bool
    name: str
    coordinate_system: int
    origin_coordinates: _common_pb2.Vector3d
    origin_coordinate_x: float
    origin_coordinate_y: float
    origin_coordinate_z: float
    points_number_definition_option: PointCloud.PointsNumberDefinitionOption
    points_number_total: int
    points_number_in_direction_x: int
    points_number_in_direction_y: int
    points_number_in_direction_z: int
    dimension_A: float
    dimension_B: float
    dimension_C: float
    dimension_R: float
    specific_direction_type: PointCloud.SpecificDirectionType
    axes_sequence: PointCloud.AxesSequence
    rotated_about_angle_x: float
    rotated_about_angle_y: float
    rotated_about_angle_z: float
    rotated_about_angle_1: float
    rotated_about_angle_2: float
    rotated_about_angle_3: float
    directed_to_node_first_axis: PointCloud.DirectedToNodeFirstAxis
    directed_to_node_direction_node: int
    directed_to_node_second_axis: PointCloud.DirectedToNodeSecondAxis
    directed_to_node_plane_node: int
    parallel_to_two_nodes_first_node: int
    parallel_to_two_nodes_second_node: int
    parallel_to_two_nodes_first_axis: PointCloud.ParallelToTwoNodesFirstAxis
    parallel_to_two_nodes_second_axis: PointCloud.ParallelToTwoNodesSecondAxis
    parallel_to_two_nodes_plane_node: int
    parallel_to_line: int
    parallel_to_member: int
    comment: str
    is_generated: bool
    generating_object_info: str
    id_for_export_import: str
    metadata_for_export_import: str
    def __init__(self, no: _Optional[int] = ..., user_defined_name_enabled: bool = ..., name: _Optional[str] = ..., coordinate_system: _Optional[int] = ..., origin_coordinates: _Optional[_Union[_common_pb2.Vector3d, _Mapping]] = ..., origin_coordinate_x: _Optional[float] = ..., origin_coordinate_y: _Optional[float] = ..., origin_coordinate_z: _Optional[float] = ..., points_number_definition_option: _Optional[_Union[PointCloud.PointsNumberDefinitionOption, str]] = ..., points_number_total: _Optional[int] = ..., points_number_in_direction_x: _Optional[int] = ..., points_number_in_direction_y: _Optional[int] = ..., points_number_in_direction_z: _Optional[int] = ..., dimension_A: _Optional[float] = ..., dimension_B: _Optional[float] = ..., dimension_C: _Optional[float] = ..., dimension_R: _Optional[float] = ..., specific_direction_type: _Optional[_Union[PointCloud.SpecificDirectionType, str]] = ..., axes_sequence: _Optional[_Union[PointCloud.AxesSequence, str]] = ..., rotated_about_angle_x: _Optional[float] = ..., rotated_about_angle_y: _Optional[float] = ..., rotated_about_angle_z: _Optional[float] = ..., rotated_about_angle_1: _Optional[float] = ..., rotated_about_angle_2: _Optional[float] = ..., rotated_about_angle_3: _Optional[float] = ..., directed_to_node_first_axis: _Optional[_Union[PointCloud.DirectedToNodeFirstAxis, str]] = ..., directed_to_node_direction_node: _Optional[int] = ..., directed_to_node_second_axis: _Optional[_Union[PointCloud.DirectedToNodeSecondAxis, str]] = ..., directed_to_node_plane_node: _Optional[int] = ..., parallel_to_two_nodes_first_node: _Optional[int] = ..., parallel_to_two_nodes_second_node: _Optional[int] = ..., parallel_to_two_nodes_first_axis: _Optional[_Union[PointCloud.ParallelToTwoNodesFirstAxis, str]] = ..., parallel_to_two_nodes_second_axis: _Optional[_Union[PointCloud.ParallelToTwoNodesSecondAxis, str]] = ..., parallel_to_two_nodes_plane_node: _Optional[int] = ..., parallel_to_line: _Optional[int] = ..., parallel_to_member: _Optional[int] = ..., comment: _Optional[str] = ..., is_generated: bool = ..., generating_object_info: _Optional[str] = ..., id_for_export_import: _Optional[str] = ..., metadata_for_export_import: _Optional[str] = ...) -> None: ...
