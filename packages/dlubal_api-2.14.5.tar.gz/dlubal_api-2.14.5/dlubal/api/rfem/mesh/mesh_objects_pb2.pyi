from dlubal.api.common import model_id_pb2 as _model_id_pb2
from dlubal.api.rfem import object_id_pb2 as _object_id_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MeshEntity(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ENTITY_UNSPECIFIED: _ClassVar[MeshEntity]
    NODE: _ClassVar[MeshEntity]
    ELEMENT_1D: _ClassVar[MeshEntity]
    ELEMENT_2D: _ClassVar[MeshEntity]
    ELEMENT_3D: _ClassVar[MeshEntity]

class MeshShape(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SHAPE_UNSPECIFIED: _ClassVar[MeshShape]
    ORIGINAL: _ClassVar[MeshShape]
    DEFORMED: _ClassVar[MeshShape]
    INITIAL_STATE: _ClassVar[MeshShape]
ENTITY_UNSPECIFIED: MeshEntity
NODE: MeshEntity
ELEMENT_1D: MeshEntity
ELEMENT_2D: MeshEntity
ELEMENT_3D: MeshEntity
SHAPE_UNSPECIFIED: MeshShape
ORIGINAL: MeshShape
DEFORMED: MeshShape
INITIAL_STATE: MeshShape

class GetMeshTableRequest(_message.Message):
    __slots__ = ("mesh_entity", "mesh_shape", "loading", "load_increment", "model_id")
    MESH_ENTITY_FIELD_NUMBER: _ClassVar[int]
    MESH_SHAPE_FIELD_NUMBER: _ClassVar[int]
    LOADING_FIELD_NUMBER: _ClassVar[int]
    LOAD_INCREMENT_FIELD_NUMBER: _ClassVar[int]
    MODEL_ID_FIELD_NUMBER: _ClassVar[int]
    mesh_entity: MeshEntity
    mesh_shape: MeshShape
    loading: _object_id_pb2.ObjectId
    load_increment: int
    model_id: _model_id_pb2.ModelId
    def __init__(self, mesh_entity: _Optional[_Union[MeshEntity, str]] = ..., mesh_shape: _Optional[_Union[MeshShape, str]] = ..., loading: _Optional[_Union[_object_id_pb2.ObjectId, _Mapping]] = ..., load_increment: _Optional[int] = ..., model_id: _Optional[_Union[_model_id_pb2.ModelId, _Mapping]] = ...) -> None: ...
