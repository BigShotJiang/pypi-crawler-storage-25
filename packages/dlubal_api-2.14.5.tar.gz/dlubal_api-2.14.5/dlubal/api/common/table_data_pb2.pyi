from dlubal.api.common import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TableData(_message.Message):
    __slots__ = ("column_ids", "rows", "columns")
    COLUMN_IDS_FIELD_NUMBER: _ClassVar[int]
    ROWS_FIELD_NUMBER: _ClassVar[int]
    COLUMNS_FIELD_NUMBER: _ClassVar[int]
    column_ids: _containers.RepeatedScalarFieldContainer[str]
    rows: _containers.RepeatedCompositeFieldContainer[TableRow]
    columns: _containers.RepeatedCompositeFieldContainer[TableColumn]
    def __init__(self, column_ids: _Optional[_Iterable[str]] = ..., rows: _Optional[_Iterable[_Union[TableRow, _Mapping]]] = ..., columns: _Optional[_Iterable[_Union[TableColumn, _Mapping]]] = ...) -> None: ...

class TableColumn(_message.Message):
    __slots__ = ("id", "name", "group_name", "unit")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    GROUP_NAME_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    group_name: str
    unit: str
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., group_name: _Optional[str] = ..., unit: _Optional[str] = ...) -> None: ...

class TableRow(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedCompositeFieldContainer[_common_pb2.Value]
    def __init__(self, values: _Optional[_Iterable[_Union[_common_pb2.Value, _Mapping]]] = ...) -> None: ...
