''' Definition file '''
import os
import ssl
import grpc

from pathlib import Path
from configparser import ConfigParser
from importlib.metadata import version, PackageNotFoundError

# Enable prompt option for testing purposes
prompt = False

options = [
        ('grpc.max_send_message_length', -1),
        ('grpc.max_receive_message_length', -1),
    ]
compression = grpc.Compression.Gzip # https://grpc.io/docs/guides/compression/

class _config():
    def __init__(self):
        '''
        Read config file. It is doesn't exist, create one.
        '''
        self.config = ConfigParser()
        self.config_loc = Path(Path(__file__).parents[1], 'config.ini')
        # Parse existing file
        if os.path.isfile(self.config_loc):
            self.config.read(self.config_loc)

    def _save_to_file(self):
        '''
        Save current config file
        '''
        with open(self.config_loc, 'w', encoding="utf-8") as config_file:
            self.config.write(config_file)

    def get_name_of_default(self):
        '''
        Return first name of the API key, which was set as default
        '''
        all_items = self.config.items('api_keys')
        all_keys = self.config.options('api_keys')
        if 'default' in all_keys:
            default_value = self.config.get('api_keys', 'default')
            for i in all_items:
                if i[0] != 'default' and i[1] == default_value:
                    return i[0]
        return None

    def _set(self, section, key, value):
        '''
        Set value and save config into file
        '''
        self.config.set(section, key, value)
        self._save_to_file()

    def get_value(self, key):
        '''
        Get API key from config
        '''
        value = None
        if self.config.has_section('api_keys'):
            value = self.config.get('api_keys', key, fallback=None)
        if value and value.startswith(('AK', 'ak')):
            # Set default
            self._set('api_keys', 'default', value)
        return value

    def get_key(self, value):
        '''
        Get API key name from config by providing value
        '''
        if self.config.has_section('api_keys'):
            all_items = self.config.items('api_keys')
            for i in all_items:
                if i[1] == value and i[0] != 'default':
                    return i[0]
        return None

    def set_value(self, key, value):
        '''
        Set API key into config
        '''
        if self.config.has_section('api_keys'):
            self._set('api_keys', key, value)
        else:
            self.config.add_section('api_keys')
            self._set('api_keys', key, value)
        # Set default
        self._set('api_keys', 'default', value)

    def delete_value(self, section, key):
        '''
        Delete API key
        '''
        self.config.remove_option(section, key)


class _ApiKey():
    '''
    API key class to make it easy to manage API keys.
    '''
    def __init__(self, key=None , value=None):

        self.key = key
        self.value = value
        self.config = _config()

        if self.key and self.value:
            # Check if API key is saved. If not, save it to config file.
            if self.config.get_value(self.key) is None:
                self.config.set_value(self.key, self.value)
        elif self.key:
            # Check if API key is saved, get it and put into self.value
            self.value = self.config.get_value(self.key)
        elif self.value:
            # Providing value without key suggests user doesn't want to store it.
            # Don't even store any default value.
            # But user should be able to get key if value is known.
            self.key = self.config.get_key(self.value)
        else:
            # Key and value are None
            # Check if there is any default key set in config
            self.value = self.config.get_value('default')
            if self.value:
                self.key = self.config.get_name_of_default()

    def get(self, key=None):
        '''
        Get API key
        '''
        if key:
            self.value = self.config.get_value(key)
        else:
            self.value = self.config.get_value('default')

        if self.value is None:
            raise ValueError("Invalid API key idenficator or missing default value.")
        return self.value

    def set(self, key, value):
        '''
        Set APi key
        '''
        self.config.set_value(key, value)


class _ClientCallDetails(grpc.ClientCallDetails):
    '''
    Client call details class to pass authorization API key
    '''
    def __init__(self, call_details, metadata):
        self.method = call_details.method
        self.timeout = call_details.timeout
        self.credentials = call_details.credentials
        self.metadata = metadata

class AuthInterceptor(grpc.UnaryUnaryClientInterceptor):
    '''
    Authorization Unary Interceptor class
    '''
    def __init__(self, value):
        self.api_key = value

    def intercept_call(self, continuation, client_call_details, request_or_iterator):
        try:
            client_version = version('dlubal.api')
        except PackageNotFoundError:
            # Package not installed, fallback to default version string
            client_version = "dev"

        call_details = _ClientCallDetails(
            client_call_details,
            [
                ("authorization", f"Bearer {self.api_key}"),
                ("api-client-info", f"Python | {client_version}"),
            ]
        )
        return continuation(call_details, request_or_iterator)

    def intercept_unary_unary(self, continuation, client_call_details, request):
        return self.intercept_call(continuation, client_call_details, request)

def check_ssl(_ssl, _ssl_file):
    '''
    Check SSL certificate
    Params:
        _ssl (bool): False if NOT using SSL auth. True if using SSL certificate.
        _ssl_file (str):Path to .crt/.pem certificate.
    '''
    if _ssl is False:
        pass
    elif _ssl is True:
        if isinstance(_ssl_file, str) and os.path.isfile(_ssl_file) and _ssl_file.endswith(('.crt', '.pem')):
            # Use provided file
            pass
        elif _ssl_file == '':
            # Use Windows Certification Store
            pass
        else:
            # Provided path is not correct
            exit()

    return True

def _get_ssl_credentials(_ssl_file) -> grpc.ChannelCredentials:
    '''
    Get SSL channel credentials by reading cert. file

    Params:
    path (str): Path to the SSL (.crt) certificate filepath
    '''
    if _ssl_file == '':
        certs = ssl.create_default_context().get_ca_certs(True)
        cert_string = ''
        for cert in certs:
            cert_string += ssl.DER_cert_to_PEM_cert(cert)
        return grpc.ssl_channel_credentials(root_certificates=cert_string.encode('utf-8'))
    else:
        cert_file = open(_ssl_file, 'rb')
        return grpc.ssl_channel_credentials(cert_file.read())

def init_channel(API_key, url, port, _ssl, _ssl_file):
    '''
    Initialize the gRPC channel with the provided API key.

    Params:
        API_key (str): Api key
        url (str): URL number defaults to localhost (127.0.0.1)
        port (int): Port number defaults to 9000
        _ssl (bool): True if using SSL
        _ssl_file (str): Path to SSL cert file
    '''
    channel = None
    try:
        if _ssl:
            # Create secure channel
            channel_credentials = _get_ssl_credentials(_ssl_file)
            channel = grpc.secure_channel(f"{url}:{port}", channel_credentials, options, compression)
        else:
            # Create insecure channel
            channel = grpc.insecure_channel(f"{url}:{port}", options, compression)

        #  Create gRPC interceptor
        interceptor = AuthInterceptor(API_key)
        channel = grpc.intercept_channel(channel, interceptor)

    # All exceptions are handeled at the RFEM.__exit__()
    except:
        pass

    return channel


def format_grpc_error(error: grpc.RpcError, *, url=None, port=None, context='gRPC call', product='API'):
    '''
    Convert a gRPC exception to a user-friendly message.
    '''
    endpoint = f'{url}:{port}' if url is not None and port is not None else 'configured endpoint'

    try:
        code_name = error.code().name
    except Exception:
        code_name = 'UNKNOWN'

    try:
        details = error.details() or 'No additional details provided by gRPC.'
    except Exception:
        details = 'No additional details provided by gRPC.'

    if code_name == 'UNIMPLEMENTED':
        return (
            f"{context} failed ({code_name}). The endpoint '{endpoint}' is reachable, "
            f'but it does not provide the expected {product} API service. '
            'This usually means an incorrect server port or server type. '
            f'Original gRPC details: {details}'
        )

    if code_name == 'UNAVAILABLE':
        return (
            f"{context} failed ({code_name}). Cannot connect to '{endpoint}'. "
            f'Check that {product} is running and that URL/port are correct. '
            f'Original gRPC details: {details}'
        )

    if code_name == 'UNAUTHENTICATED':
        return (
            f"{context} failed ({code_name}) for '{endpoint}'. "
            'Authentication failed. Check that the API key is present, valid, and not expired. '
            f'Original gRPC details: {details}'
        )

    if code_name == 'PERMISSION_DENIED':
        return (
            f"{context} failed ({code_name}) for '{endpoint}'. "
            'The API key is valid but does not have permission for this operation. '
            'Check subscription scope and user permissions. '
            f'Original gRPC details: {details}'
        )

    if code_name == 'DEADLINE_EXCEEDED':
        return (
            f"{context} failed ({code_name}) for '{endpoint}'. "
            'The request timed out before the server responded. '
            'Check network latency, server load, or increase the request timeout. '
            f'Original gRPC details: {details}'
        )

    if code_name == 'INVALID_ARGUMENT':
        return (
            f"{context} failed ({code_name}) for '{endpoint}'. "
            'One or more request parameters are invalid. '
            'Check object IDs, enum values, and required fields. '
            f'Original gRPC details: {details}'
        )

    if code_name == 'FAILED_PRECONDITION':
        return (
            f"{context} failed ({code_name}) for '{endpoint}'. "
            'The operation cannot be executed in the current model/application state. '
            'Verify prerequisites and model state before retrying. '
            f'Original gRPC details: {details}'
        )

    if code_name == 'INTERNAL':
        return (
            f"{context} failed ({code_name}) for '{endpoint}'. "
            'The server reported an internal error. Retry the request and check server logs/version compatibility. '
            f'Original gRPC details: {details}'
        )

    return f'{context} failed ({code_name}) for {endpoint}: {details}'
