from typing import Any, Optional

import os
import re

import pandas as pd


def _load_vtk_module():
    try:
        import vtk  # type: ignore
        return vtk
    except Exception:
        return None


def _choose_scalar_array(polydata, array_name: Optional[str] = None):
    point_data = polydata.GetPointData()
    cell_data = polydata.GetCellData()
    if array_name:
        if point_data is not None:
            named = point_data.GetArray(array_name)
            if named is not None:
                point_data.SetActiveScalars(array_name)
                return named, "point"
        if cell_data is not None:
            named = cell_data.GetArray(array_name)
            if named is not None:
                cell_data.SetActiveScalars(array_name)
                return named, "cell"
    if point_data is not None and point_data.GetNumberOfArrays() > 0:
        array = point_data.GetArray(0)
        if array is not None:
            point_data.SetActiveScalars(array.GetName())
            return array, "point"
    if cell_data is not None and cell_data.GetNumberOfArrays() > 0:
        array = cell_data.GetArray(0)
        if array is not None:
            cell_data.SetActiveScalars(array.GetName())
            return array, "cell"
    return None, None


def _get_field_array(polydata, name):
    field_data = polydata.GetFieldData()
    if field_data is None:
        return None
    return field_data.GetArray(name)


def _build_palette_lookup_from_field(vtk_module, polydata):
    levels = _get_field_array(polydata, "scale_levels")
    palette = _get_field_array(polydata, "scale_palette")
    if levels is None or palette is None:
        return None

    num_levels = levels.GetNumberOfTuples()
    num_colors = palette.GetNumberOfTuples()
    if num_levels == 0 or num_colors == 0:
        return None

    lut = vtk_module.vtkLookupTable()
    lut.SetNumberOfTableValues(num_colors)
    lut.SetIndexedLookup(True)

    # For indexed lookups, the mapper provides indices (0..num_colors-1).
    # Keep the LUT range in index space so the scalar bar orders values correctly
    # (max at top, min at bottom).
    lut.SetRange(0, max(num_colors - 1, 0))
    lut.SetRampToLinear()
    lut.Build()

    comps = max(1, palette.GetNumberOfComponents())
    for i in range(num_colors):
        # RFEM stores ScalePalette in opposite direction to ScaleLevels/indices (max->min),
        # so invert it to get max at top (red) and min at bottom (blue).
        p_idx = (num_colors - 1) - i
        r = palette.GetComponent(p_idx, 0) if comps > 0 else palette.GetValue(p_idx)
        g = palette.GetComponent(p_idx, 1) if comps > 1 else r
        b = palette.GetComponent(p_idx, 2) if comps > 2 else r
        lut.SetTableValue(i, r / 255.0, g / 255.0, b / 255.0, 1.0)

    # Attach annotations so the scalar bar shows level values instead of palette indices.
    try:
        values_arr = vtk_module.vtkIntArray()
        labels_arr = vtk_module.vtkStringArray()
        label_count = min(num_colors, num_levels)
        use_upper_bounds = num_levels == num_colors + 1
        for i in range(label_count - 1, -1, -1):
            values_arr.InsertNextValue(i)
            level_idx = i + 1 if use_upper_bounds else i
            level_idx = min(max(level_idx, 0), num_levels - 1)
            labels_arr.InsertNextValue(f"{levels.GetValue(level_idx):.6f}")
        lut.SetAnnotations(values_arr, labels_arr)
    except Exception:
        pass

    min_level = levels.GetValue(0)
    max_level = levels.GetValue(0)
    for i in range(num_levels):
        min_level = min(min_level, levels.GetValue(i))
        max_level = max(max_level, levels.GetValue(i))

    return {
        "lut": lut,
        "levels_range": (min_level, max_level),
        "num_levels": num_levels,
        "num_colors": num_colors,
        "levels": levels,
    }


def _choose_palette_index_array(polydata, lut_size, array_name: Optional[str] = None):
    cell_data = polydata.GetCellData()
    if cell_data is None:
        return None
    if array_name:
        named = cell_data.GetArray(array_name)
        if named is not None:
            r_min, r_max = named.GetRange()
            if r_min >= 0 and r_max <= max(lut_size - 1, 0):
                return named
    for i in range(cell_data.GetNumberOfArrays()):
        arr = cell_data.GetArray(i)
        if arr is None:
            continue
        r_min, r_max = arr.GetRange()
        if r_min >= 0 and r_max <= max(lut_size - 1, 0):
            return arr
    return None


def _build_lookup_table(vtk_module, scalar_range):
    r_min, r_max = scalar_range
    if r_min == r_max:
        r_min -= 0.5
        r_max += 0.5

    # Build a 12-step "jet-like" scale to match the provided legend.
    steps = 11
    interval = (r_max - r_min) / steps
    _levels = [r_max - i * interval for i in range(steps + 1)]  # preserved for possible labeling/debug
    colors = [
        (0.00, 0.00, 0.50),  # deep blue (min)
        (0.00, 0.00, 1.00),  # blue
        (0.00, 0.40, 1.00),  # mid blue
        (0.00, 0.66, 1.00),  # light blue
        (0.00, 1.00, 1.00),  # cyan
        (0.00, 1.00, 0.50),  # yellow-green
        (0.00, 1.00, 0.00),  # green
        (1.00, 1.00, 0.00),  # yellow
        (1.00, 0.75, 0.00),  # yellow-orange
        (1.00, 0.47, 0.00),  # orange
        (1.00, 0.00, 0.00),  # red
        (0.70, 0.00, 0.00),  # deep red (max)
    ]

    lut = vtk_module.vtkLookupTable()
    lut.SetNumberOfTableValues(len(colors))
    lut.SetRange(r_min, r_max)
    lut.SetRampToLinear()
    lut.Build()

    for i, (r, g, b) in enumerate(colors):
        lut.SetTableValue(i, r, g, b, 1.0)

    return lut


def _show_polydata_window(
    polydata,
    vtk_module,
    use_palette_index: bool = False,
    array_name: Optional[str] = None,
):
    try:
        mapper = vtk_module.vtkPolyDataMapper()
        mapper.SetInputData(polydata)

        scalar_array, scalar_location = None, None
        lut = None
        scalar_range = None

        if use_palette_index:
            palette_info = _build_palette_lookup_from_field(vtk_module, polydata)
            if palette_info is not None:
                lut = palette_info["lut"]
                scalar_range = (-0.5, palette_info["num_colors"] - 0.5)
                scalar_array = _choose_palette_index_array(
                    polydata,
                    palette_info["num_colors"],
                    array_name=array_name,
                )
                scalar_location = "cell"
        else:
            scalar_array, scalar_location = _choose_scalar_array(polydata, array_name=array_name)
            if scalar_array is not None:
                r0, r1 = scalar_array.GetRange()
                scalar_range = (min(r0, r1), max(r0, r1))
                lut = _build_lookup_table(vtk_module, scalar_range)

        if scalar_array is not None and lut is not None:
            mapper.SetScalarVisibility(True)
            mapper.SetColorModeToMapScalars()
            mapper.InterpolateScalarsBeforeMappingOn()
            mapper.SetLookupTable(lut)
            mapper.SetScalarRange(scalar_range)
            if scalar_location == "point":
                mapper.SetScalarModeToUsePointData()
            else:
                mapper.SetScalarModeToUseCellData()
        else:
            mapper.SetScalarVisibility(False)

        actor = vtk_module.vtkActor()
        actor.SetMapper(mapper)
        prop = actor.GetProperty()
        prop.SetInterpolationToPhong()
        prop.SetSpecular(0.35)
        prop.SetSpecularPower(20.0)
        prop.SetAmbient(0.15)
        prop.SetDiffuse(0.8)

        renderer = vtk_module.vtkRenderer()
        renderer.AddActor(actor)
        colors = vtk_module.vtkNamedColors()
        renderer.SetBackground(colors.GetColor3d("SlateGray"))
        renderer.SetBackground2(colors.GetColor3d("DimGray"))
        renderer.GradientBackgroundOn()

        if scalar_array is not None and lut is not None:
            scalar_bar = vtk_module.vtkScalarBarActor()
            scalar_bar.SetLookupTable(mapper.GetLookupTable())
            scalar_bar.SetTitle(scalar_array.GetName() or "Values")
            scalar_bar.SetNumberOfLabels(lut.GetNumberOfTableValues())
            scalar_bar.UnconstrainedFontSizeOn()
            scalar_bar.SetMaximumWidthInPixels(80)
            renderer.AddViewProp(scalar_bar)

        light_kit = vtk_module.vtkLightKit()
        light_kit.AddLightsToRenderer(renderer)
        renderer.ResetCamera()
        renderer.GetActiveCamera().Elevation(25)
        renderer.GetActiveCamera().Azimuth(20)
        renderer.ResetCameraClippingRange()

        render_window = vtk_module.vtkRenderWindow()
        render_window.AddRenderer(renderer)
        render_window.SetSize(900, 700)

        interactor = vtk_module.vtkRenderWindowInteractor()
        interactor.SetRenderWindow(render_window)
        # Match ParaView-like navigation (trackball camera interactions).
        interactor.SetInteractorStyle(vtk_module.vtkInteractorStyleTrackballCamera())

        render_window.Render()
        interactor.Initialize()
        interactor.Start()  # blocks until window is closed
        return True
    except Exception:
        # Display is best-effort; ignore failures (e.g., headless environment)
        return False


def get_vtk_polydata(
    df: pd.DataFrame,
    column_id: str,
    mode_shape_no: Optional[int] = None,
    layer_side: Optional[str] = None,
) -> Optional[Any]:
    if column_id not in df.columns:
        return None

    series = df[column_id]

    if layer_side is not None:
        if "tag" not in df.columns:
            return None
        series = df.loc[df["tag"] == layer_side, column_id]

    if mode_shape_no is not None:
        if "mode_shape" not in df.columns:
            return None
        series = df.loc[df["mode_shape"] == mode_shape_no, column_id]

    for value in series:
        if value is None or value is pd.NA:
            continue
        if hasattr(value, "GetPointData"):
            return value

    return None


def save_vtk_polydata(polydata: Any, quantity_name: str, output_dir: str = r"d:\vtkPolydataCheck") -> Optional[str]:
    vtk_module = _load_vtk_module()
    if vtk_module is None or polydata is None or not hasattr(polydata, "GetPointData"):
        return None

    safe_quantity = re.sub(r"[^A-Za-z0-9_.-]+", "_", quantity_name).strip("._-")
    if not safe_quantity:
        safe_quantity = "polyData"

    os.makedirs(output_dir, exist_ok=True)
    file_path = os.path.join(output_dir, f"polyData_client_{safe_quantity}.vtp")

    try:
        writer = vtk_module.vtkXMLPolyDataWriter()
    except Exception:
        try:
            writer = vtk_module.vtkPolyDataWriter()
            file_path = os.path.splitext(file_path)[0] + ".vtk"
        except Exception:
            return None

    writer.SetFileName(file_path)
    try:
        writer.SetInputData(polydata)
    except Exception:
        try:
            writer.SetInput(polydata)
        except Exception:
            return None

    try:
        writer.Write()
    except Exception:
        return None

    return file_path

def display_vtk_polydata(
    polydata: Any,
    use_palette_index: bool = False,
    array_name: Optional[str] = None,
) -> bool:
    vtk_module = _load_vtk_module()
    if vtk_module is None or polydata is None or not hasattr(polydata, "GetPointData"):
        return False

    return _show_polydata_window(
        polydata,
        vtk_module,
        use_palette_index=use_palette_index,
        array_name=array_name,
    )

