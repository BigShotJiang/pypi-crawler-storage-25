from dlubal.api.common.common_messages_pb2 import Object, ObjectList
from dlubal.api.common.table import Table
from dlubal.api.common.table_data_pb2 import TableData
from dlubal.api.common.common_pb2 import Value
from google.protobuf.any_pb2 import Any
from google.protobuf import descriptor_pool
from google.protobuf.message_factory import GetMessageClass
import pandas as pd
from pandas import DataFrame

def pack_message_to_any(msg) -> Any:
    packed = Any()
    packed.Pack(msg)
    return packed

def pack_object(object, model_id=None) -> Object:
    packed = Any()
    packed.Pack(object)

    if model_id is None:
        return Object(object=packed)

    return Object(object=packed, model_id=model_id)


pool = None

def unpack_object(packed_object: Object, Type = None):
    if Type is None:
        # Find the object type dynamically
        type_url = packed_object.object.type_url
        message_type_name = type_url.split('/')[-1]

        # Initialize descriptor pool
        global pool
        if pool is None:
            pool = descriptor_pool.Default()

        try:
            # Look up the descriptor for the message
            descriptor = pool.FindMessageTypeByName(message_type_name)
            if not descriptor:
                raise ValueError(f"Message type '{message_type_name}' not found")

            # Dynamically create a class for the message type based on the descriptor
            message_class = GetMessageClass(descriptor)

            # Unpack the Any into the correct message type
            message_instance = message_class()
            packed_object.object.Unpack(message_instance)
            return message_instance

        except Exception as e:
            print(f"Error unpacking Any message: {str(e)}. Probably because of incompatible version of the client.")
            return None
    else:
        result = Type()
        packed_object.object.Unpack(result)
        return result


def pack_object_list(object_list, model_id=None):
    packed_list = ObjectList(model_id=model_id)
    for obj in object_list:
        if isinstance(obj, tuple) and len(obj) == 2:
            obj_to_pack, obj_model_id = obj
            packed_list.objects.append(pack_object(obj_to_pack, obj_model_id))
        elif isinstance(obj, Object):
            if obj.model_id is not None:
                packed_list.objects.append(pack_object(obj.object, obj.model_id))
            else:
                packed_list.objects.append(pack_object(obj.object, model_id))
        else:
            packed_list.objects.append(pack_object(obj, model_id))
    return packed_list


def unpack_object_list(packed_object_list: ObjectList, objs: list):
    type_list = []
    for o in objs:
        if isinstance(o, tuple) and len(o) == 2:
            type_list.append(type(o[0]))
        else:
            type_list.append(type(o))
    unpacked_list = []
    dynamic_type = len(type_list) != len(packed_object_list.objects)
    for i, object in enumerate(packed_object_list.objects):
        typ = None if dynamic_type else type_list[i]
        unpacked_list.append(unpack_object(object, typ))
    return unpacked_list


def get_internal_value(value: Value):
    '''
    Get the internal value stored in a generic Value object.
    For enum_value, return display_text if available.
    '''
    kind = value.WhichOneof("kind")
    if not kind or kind == "null_value":
        return None
    elif kind == "enum_value":
        # Return display_text for enums, fallback to name or value if not set
        enum_val = value.enum_value
        if enum_val.display_text:
            return enum_val.display_text
        elif enum_val.name:
            return enum_val.name
        else:
            return enum_val.value
    else:
        return getattr(value, kind)


def get_internal_value_type(value: Value):
    '''
    Get type of the internal value stored in a generic Value object
    '''
    kind = value.WhichOneof("kind")
    if kind == "int_value":
        return int
    elif kind == "double_value":
        return float
    elif kind == "string_value":
        return str
    elif kind == "bool_value":
        return bool
    else:
        return None


def set_internal_value(wrapped_value: Value, value: int | float | str | bool | None):
    value_type = type(value)
    if value_type is int:
        wrapped_value.int_value = value
    elif value_type is float:
        wrapped_value.double_value = value
    elif value_type is str:
        wrapped_value.string_value = value
    elif value_type is bool:
        wrapped_value.bool_value = value


def _get_table_column_ids(table_data: TableData) -> list[str]:
    if getattr(table_data, "columns", None):
        return [column.id for column in table_data.columns]
    return list(table_data.column_ids)

def _load_vtk_module():
    try:
        import vtk  # type: ignore
        return vtk
    except Exception:
        return None


def _looks_like_polydata_string(value: str) -> bool:
    # vtkXMLPolyDataWriter produces XML with PolyData type marker
    return isinstance(value, str) and "<VTKFile" in value and "PolyData" in value


def _deserialize_polydata(serialized: str):
    vtk_module = _load_vtk_module()
    if vtk_module is None or not _looks_like_polydata_string(serialized):
        return None, False, vtk_module

    try:
        reader = vtk_module.vtkXMLPolyDataReader()
        reader.SetReadFromInputString(True)
        reader.SetInputString(serialized)
        reader.Update()
        polydata = reader.GetOutput()
    except Exception:
        return None, False, vtk_module

    if polydata is None:
        return None, False, vtk_module

    return polydata, True, vtk_module


def _get_table_columns(table_data: TableData) -> list:
    if getattr(table_data, "columns", None):
        return list(table_data.columns)
    return []


def convert_table_data_to_table(table_data: TableData, warning: str = "", include_names_row: bool = False) -> Table:
    '''
    Converts TableData from API response to a Pandas-based Table.

    Args:
        table_data (TableData): Raw API response in TableData format.
        warning (str): Optional warning message.
        include_names_row (bool): If True, use a two-row header (first row: id, second row: name). If False, use only id.

    Returns:
        Table: Converted table with appropriate data types.
    '''
    polydata_column_indices = set()
    rows_data = []

    for row in table_data.rows:
        converted_row = []
        for col_index, raw_proto_value in enumerate(row.values):
            raw_value = get_internal_value(raw_proto_value)
            if isinstance(raw_value, str):
                polydata, is_polydata, vtk_module = _deserialize_polydata(raw_value)
                if is_polydata:
                    polydata_column_indices.add(col_index)
                    if polydata is not None and vtk_module is not None:
                        converted_row.append(polydata)
                        continue
            converted_row.append(pd.NA if raw_value is None else raw_value)
        rows_data.append(converted_row)

    n_cols = max((len(row) for row in rows_data), default=0)
    columns_meta = _get_table_columns(table_data)
    column_ids = _get_table_column_ids(table_data)

    # Empty tables can still carry usable column metadata.
    if n_cols == 0:
        n_cols = len(columns_meta) or len(column_ids)

    # Build columns
    if columns_meta and len(columns_meta) == n_cols:
        ids = [getattr(col, "id", "") or "" for col in columns_meta]
        names = [getattr(col, "name", "") or "" for col in columns_meta]
        units = [getattr(col, "unit", "") or "" for col in columns_meta]
    else:
        ids = column_ids
        names = [""] * len(ids)
        units = [""] * len(ids)

    if include_names_row:
        # Use MultiIndex: first row is id, second row is "name [unit]" when unit exists
        name_with_unit = [
            f"{name} [{unit}]" if unit and name else (f"[{unit}]" if unit else name)
            for name, unit in zip(names, units)
        ]
        columns = pd.MultiIndex.from_tuples(list(zip(ids, name_with_unit))) if ids else pd.MultiIndex.from_arrays([[], []])
    else:
        columns = ids

    # Fallback: if columns length still mismatches, use default column_ids
    if (isinstance(columns, list) and len(columns) != n_cols) or (isinstance(columns, pd.MultiIndex) and len(columns) != n_cols):
        columns = column_ids
        if include_names_row:
            columns = pd.MultiIndex.from_tuples(list(zip(columns, [""] * len(columns)))) if columns else pd.MultiIndex.from_arrays([[], []])

    # Final safety: if still mismatched, use generic column names to avoid runtime error
    if (isinstance(columns, list) and len(columns) != n_cols) or (isinstance(columns, pd.MultiIndex) and len(columns) != n_cols):
        import warnings
        warnings.warn(
            f"TableData column metadata mismatch: expected {n_cols}, got {len(columns)}. Using generic column names.",
            RuntimeWarning
        )
        if include_names_row:
            columns = pd.MultiIndex.from_tuples(list(zip(list(range(n_cols)), [""] * n_cols))) if n_cols else pd.MultiIndex.from_arrays([[], []])
        else:
            columns = list(range(n_cols))

    df = DataFrame(columns=columns, data=rows_data)

    # Convert DataFrame columns to their best possible nullable dtypes.
    # Rebuild column-by-column to avoid recursion with MultiIndex + duplicate labels.
    df_conv = df.convert_dtypes()

    resolved_column_ids = ids if len(ids) == n_cols else column_ids
    polydata_columns = {resolved_column_ids[idx] for idx in polydata_column_indices if idx < len(resolved_column_ids)}

    converted_columns = []
    for col_idx in range(df_conv.shape[1]):
        series = df_conv.iloc[:, col_idx]

        # Keep source float semantics even when values are whole numbers.
        if pd.api.types.is_float_dtype(df.iloc[:, col_idx].dtype):
            series = series.astype("Float64")

        # Convert plain object columns to nullable string, except PolyData columns.
        col_id = resolved_column_ids[col_idx] if col_idx < len(resolved_column_ids) else None
        if col_id not in polydata_columns and pd.api.types.is_object_dtype(series.dtype):
            series = series.astype("string")

        converted_columns.append(series)

    df_conv = pd.concat(converted_columns, axis=1)
    df_conv.columns = df.columns

    return Table(df_conv, warning, columns=columns_meta)
