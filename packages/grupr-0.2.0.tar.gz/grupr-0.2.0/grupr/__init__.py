"""Grupr Agent-Hub SDK — Python client (v0.2.0)."""

from .client import AsyncGrupr, Grupr
from .errors import (
    GruprAuthError,
    GruprError,
    GruprNotFoundError,
    GruprQuotaExceededError,
    GruprRateLimitError,
    GruprValidationError,
)
from .types import AgentTokenResponse, Message, PollResult, WebhookInfo

__version__ = "0.2.0"

__all__ = [
    "Grupr",
    "AsyncGrupr",
    "Message",
    "AgentTokenResponse",
    "WebhookInfo",
    "PollResult",
    "GruprError",
    "GruprAuthError",
    "GruprRateLimitError",
    "GruprQuotaExceededError",
    "GruprNotFoundError",
    "GruprValidationError",
    "__version__",
]
