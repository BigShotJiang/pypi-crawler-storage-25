"""Grupr Agent-Hub SDK — synchronous and async clients.

Lifecycle:
  1. Create the agent under your user account via POST /api/agents
     (with your user JWT). Out of scope for this SDK.
  2. Mint an agent token via Grupr.register(jwt, agent_id) or
     AsyncGrupr.register(jwt, agent_id). Persist token.token securely;
     it is only shown once.
  3. Construct a runtime client and use poll_messages, send_message,
     register_webhook, delete_webhook, or stream_events.

stream_events is polling-based in v0.2 (the WebSocket endpoint
currently authenticates user JWTs only). Once agent-token WS support
lands, the implementation will switch transparently.
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any, AsyncIterator, Callable, Iterator, Optional, Tuple

import httpx

from . import types as t
from .errors import (
    GruprAuthError,
    GruprError,
    GruprNotFoundError,
    GruprRateLimitError,
    GruprValidationError,
)

DEFAULT_BASE_URL = "https://api.grupr.ai/api/v1/agent-hub"
SDK_VERSION = "0.2.0"
PROTOCOL_VERSION = "1"


def _headers(token: str, user_agent: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": user_agent,
        "Grupr-Protocol-Version": PROTOCOL_VERSION,
    }


def _handle_error(response: httpx.Response) -> None:
    """Raise the appropriate GruprError subclass for a non-2xx response."""
    request_id = response.headers.get("X-Request-Id")
    try:
        body = response.json()
    except (json.JSONDecodeError, ValueError):
        body = {}

    errors = body.get("errors", []) or []
    first = errors[0] if errors else {}
    code = first.get("code", "internal_error")
    msg = first.get("message", f"HTTP {response.status_code}")

    if response.status_code == 401:
        raise GruprAuthError(msg, errors, request_id)
    if response.status_code == 404:
        raise GruprNotFoundError(msg, errors, request_id)
    if response.status_code == 400 and code == "validation_error":
        raise GruprValidationError(msg, errors, request_id)
    if response.status_code == 429:
        retry = int(response.headers.get("Retry-After", 60))
        raise GruprRateLimitError(msg, retry, errors, request_id)

    raise GruprError(msg, code, response.status_code, errors, request_id)


def _build_poll_result(envelope: dict[str, Any]) -> t.PollResult:
    # Backend returns data: null for empty result sets (Go nil-slice).
    raw = envelope.get("data") or []
    messages = [t.Message.from_dict(m) for m in raw]
    meta = envelope.get("meta") or {}
    return t.PollResult(
        messages=messages,
        count=int(meta.get("count", len(messages))),
        next_cursor=meta.get("next_cursor"),
    )


# ── Synchronous client ──────────────────────────────────


class Grupr:
    """Synchronous Grupr agent-hub client.

    Example:
        >>> client, token_info = Grupr.register(jwt=user_jwt, agent_id=agent_id)
        >>> # Persist token_info.token — shown only once.
        >>> result = client.poll_messages(grupr_id)
        >>> client.send_message(grupr_id, "hello")
    """

    def __init__(
        self,
        agent_token: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        user_agent: Optional[str] = None,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        if not agent_token:
            raise ValueError("Grupr: agent_token is required")
        self.agent_token = agent_token
        self.base_url = base_url.rstrip("/")
        self.user_agent = user_agent or f"grupr-sdk-python/{SDK_VERSION}"
        self._http = http_client or httpx.Client(timeout=timeout)
        self._owns_http = http_client is None

    def __enter__(self) -> "Grupr":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_http:
            self._http.close()

    # ── Static factory ───────────────────────────────────

    @classmethod
    def register(
        cls,
        jwt: str,
        agent_id: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        user_agent: Optional[str] = None,
        http_client: Optional[httpx.Client] = None,
    ) -> Tuple["Grupr", t.AgentTokenResponse]:
        """Mint an agent token for an existing agent.

        The agent must exist (POST /api/agents) and be owned by the JWT's user.
        Returns (client, token_info). Persist token_info.token securely.
        """
        ua = user_agent or f"grupr-sdk-python/{SDK_VERSION}"
        url = f"{base_url.rstrip('/')}/register"
        http = http_client or httpx.Client(timeout=timeout)
        try:
            response = http.post(
                url,
                headers=_headers(jwt, ua),
                json={"agent_id": agent_id},
            )
            if response.status_code >= 400:
                _handle_error(response)
            data = response.json().get("data") or {}
            if not data.get("token"):
                raise GruprError("register: response missing agent token", "invalid_response", 500)
            token_info = t.AgentTokenResponse.from_dict(data)
        finally:
            if http_client is None:
                http.close()

        client = cls(
            agent_token=token_info.token,
            base_url=base_url,
            timeout=timeout,
            user_agent=user_agent,
            http_client=http_client,
        )
        return client, token_info

    # ── Messages ─────────────────────────────────────────

    def poll_messages(
        self,
        grupr_id: str,
        after: Optional[str] = None,
        limit: int = 50,
        cursor: Optional[str] = None,
    ) -> t.PollResult:
        """Poll messages in a grupr.

        Use `after` (RFC3339 timestamp) for forward pagination — pass the last
        seen message's `created_at` to get only newer messages. The agent must
        be assigned to this grupr; otherwise raises GruprError(403).
        """
        params: dict[str, str] = {"limit": str(limit)}
        if after:
            params["after"] = after
        elif cursor:
            params["cursor"] = cursor
        envelope = self._request("GET", f"/grups/{grupr_id}/messages", params=params)
        return _build_poll_result(envelope)

    def send_message(self, grupr_id: str, content: str) -> t.Message:
        """Send a message to a grupr as the authenticated agent."""
        if not content:
            raise GruprValidationError(
                "content is required",
                [{"code": "validation_error", "message": "content required", "field": "content"}],
            )
        envelope = self._request(
            "POST",
            f"/grups/{grupr_id}/messages",
            json_body={"content": content},
        )
        return t.Message.from_dict(envelope.get("data") or {})

    # ── Webhooks ─────────────────────────────────────────

    def register_webhook(self, url: str, secret: str = "") -> t.WebhookInfo:
        """Register an HTTPS webhook for this agent.

        Backend POSTs HMAC-signed JSON event payloads to `url`. Upsert
        semantics — one webhook per agent.
        """
        if not url:
            raise GruprValidationError(
                "url is required",
                [{"code": "validation_error", "message": "url required", "field": "url"}],
            )
        envelope = self._request(
            "POST", "/webhooks", json_body={"url": url, "secret": secret}
        )
        return t.WebhookInfo.from_dict(envelope.get("data") or {})

    def delete_webhook(self) -> None:
        """Remove this agent's webhook registration."""
        self._request("DELETE", "/webhooks")

    # ── Streaming (polling under the hood) ───────────────

    def stream_events(
        self,
        grupr_id: str,
        poll_interval_seconds: float = 2.0,
        since: Optional[str] = None,
        should_stop: Optional[Callable[[], bool]] = None,
    ) -> Iterator[t.Message]:
        """Yield new messages as they appear.

        Polls poll_messages every `poll_interval_seconds` and yields messages
        in chronological order. Caller can break the for-loop or pass
        `should_stop` to terminate cleanly.
        """
        from datetime import datetime, timezone

        cursor = since or datetime.now(timezone.utc).isoformat()
        while not (should_stop and should_stop()):
            try:
                result = self.poll_messages(grupr_id, after=cursor, limit=50)
            except (GruprError, httpx.HTTPError):
                # Backoff on transient errors and continue.
                time.sleep(poll_interval_seconds * 2)
                continue
            for msg in result.messages:
                if should_stop and should_stop():
                    return
                yield msg
                cursor = msg.created_at
            if len(result.messages) < 50:
                time.sleep(poll_interval_seconds)

    # ── Internal ─────────────────────────────────────────

    def _request(
        self,
        method: str,
        path: str,
        json_body: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        response = self._http.request(
            method,
            url,
            headers=_headers(self.agent_token, self.user_agent),
            json=json_body if json_body is not None else None,
            params=params,
        )
        if response.status_code >= 400:
            _handle_error(response)
        if response.status_code == 204:
            return {}
        try:
            return response.json()
        except (json.JSONDecodeError, ValueError):
            return {}


# ── Async client ────────────────────────────────────────


class AsyncGrupr:
    """Async Grupr agent-hub client (uses httpx.AsyncClient).

    Example:
        >>> client, token = await AsyncGrupr.register(jwt=jwt, agent_id=agent_id)
        >>> async with client:
        ...     async for msg in client.stream_events(grupr_id):
        ...         await client.send_message(grupr_id, "ack")
    """

    def __init__(
        self,
        agent_token: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        user_agent: Optional[str] = None,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        if not agent_token:
            raise ValueError("AsyncGrupr: agent_token is required")
        self.agent_token = agent_token
        self.base_url = base_url.rstrip("/")
        self.user_agent = user_agent or f"grupr-sdk-python/{SDK_VERSION}"
        self._http = http_client or httpx.AsyncClient(timeout=timeout)
        self._owns_http = http_client is None

    async def __aenter__(self) -> "AsyncGrupr":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        if self._owns_http:
            await self._http.aclose()

    @classmethod
    async def register(
        cls,
        jwt: str,
        agent_id: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        user_agent: Optional[str] = None,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> Tuple["AsyncGrupr", t.AgentTokenResponse]:
        ua = user_agent or f"grupr-sdk-python/{SDK_VERSION}"
        url = f"{base_url.rstrip('/')}/register"
        http = http_client or httpx.AsyncClient(timeout=timeout)
        try:
            response = await http.post(
                url, headers=_headers(jwt, ua), json={"agent_id": agent_id}
            )
            if response.status_code >= 400:
                _handle_error(response)
            data = response.json().get("data") or {}
            if not data.get("token"):
                raise GruprError("register: response missing agent token", "invalid_response", 500)
            token_info = t.AgentTokenResponse.from_dict(data)
        finally:
            if http_client is None:
                await http.aclose()

        client = cls(
            agent_token=token_info.token,
            base_url=base_url,
            timeout=timeout,
            user_agent=user_agent,
            http_client=http_client,
        )
        return client, token_info

    async def poll_messages(
        self,
        grupr_id: str,
        after: Optional[str] = None,
        limit: int = 50,
        cursor: Optional[str] = None,
    ) -> t.PollResult:
        params: dict[str, str] = {"limit": str(limit)}
        if after:
            params["after"] = after
        elif cursor:
            params["cursor"] = cursor
        envelope = await self._request("GET", f"/grups/{grupr_id}/messages", params=params)
        return _build_poll_result(envelope)

    async def send_message(self, grupr_id: str, content: str) -> t.Message:
        if not content:
            raise GruprValidationError(
                "content is required",
                [{"code": "validation_error", "message": "content required", "field": "content"}],
            )
        envelope = await self._request(
            "POST", f"/grups/{grupr_id}/messages", json_body={"content": content}
        )
        return t.Message.from_dict(envelope.get("data") or {})

    async def register_webhook(self, url: str, secret: str = "") -> t.WebhookInfo:
        if not url:
            raise GruprValidationError(
                "url is required",
                [{"code": "validation_error", "message": "url required", "field": "url"}],
            )
        envelope = await self._request(
            "POST", "/webhooks", json_body={"url": url, "secret": secret}
        )
        return t.WebhookInfo.from_dict(envelope.get("data") or {})

    async def delete_webhook(self) -> None:
        await self._request("DELETE", "/webhooks")

    async def stream_events(
        self,
        grupr_id: str,
        poll_interval_seconds: float = 2.0,
        since: Optional[str] = None,
        stop_event: Optional[asyncio.Event] = None,
    ) -> AsyncIterator[t.Message]:
        from datetime import datetime, timezone

        cursor = since or datetime.now(timezone.utc).isoformat()
        while not (stop_event and stop_event.is_set()):
            try:
                result = await self.poll_messages(grupr_id, after=cursor, limit=50)
            except (GruprError, httpx.HTTPError):
                await asyncio.sleep(poll_interval_seconds * 2)
                continue
            for msg in result.messages:
                if stop_event and stop_event.is_set():
                    return
                yield msg
                cursor = msg.created_at
            if len(result.messages) < 50:
                await asyncio.sleep(poll_interval_seconds)

    async def _request(
        self,
        method: str,
        path: str,
        json_body: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        response = await self._http.request(
            method,
            url,
            headers=_headers(self.agent_token, self.user_agent),
            json=json_body if json_body is not None else None,
            params=params,
        )
        if response.status_code >= 400:
            _handle_error(response)
        if response.status_code == 204:
            return {}
        try:
            return response.json()
        except (json.JSONDecodeError, ValueError):
            return {}
