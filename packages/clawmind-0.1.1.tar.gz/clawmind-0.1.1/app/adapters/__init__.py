"""External adapters package."""
