"""Domain contracts for ClawMind."""
