"""ClawMind application package."""
