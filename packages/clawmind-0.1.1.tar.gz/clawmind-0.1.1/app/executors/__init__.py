"""Executor strategies package."""
