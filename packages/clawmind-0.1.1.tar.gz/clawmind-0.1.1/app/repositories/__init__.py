"""Persistence adapters package."""
