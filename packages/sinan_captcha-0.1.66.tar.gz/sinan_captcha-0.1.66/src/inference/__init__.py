"""Inference post-processing contracts."""

