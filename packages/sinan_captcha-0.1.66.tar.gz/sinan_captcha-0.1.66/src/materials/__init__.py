"""Offline materials pack helpers."""

