"""Prediction command helpers."""
