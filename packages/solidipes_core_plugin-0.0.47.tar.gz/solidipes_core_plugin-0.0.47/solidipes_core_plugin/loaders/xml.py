import xmltodict

from .code_snippet import CodeSnippet


class XML(CodeSnippet):
    supported_mime_types = {"text/xml": "xml", "application/xml": "xml", "application/paraview/state": "xml"}

    from ..viewers.dictionary import DictViewer

    _compatible_viewers = [DictViewer]

    @CodeSnippet.loadable
    def xml(self):
        text = self.text
        return xmltodict.parse(text)

    @CodeSnippet.loadable
    def dict(self):
        return self.xml
