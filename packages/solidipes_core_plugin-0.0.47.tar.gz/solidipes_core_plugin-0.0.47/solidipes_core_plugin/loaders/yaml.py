from .code_snippet import CodeSnippet


class YAML(CodeSnippet):
    supported_mime_types = {"application/yaml": ["yaml", "yml"], "text/plain": ["yaml", "yml"]}

    from ..viewers.dictionary import DictViewer

    _compatible_viewers = [DictViewer]

    @CodeSnippet.loadable
    def yaml(self):
        text = self.text
        import yaml as yaml_module

        yaml = yaml_module.safe_load(text)
        return yaml

    @CodeSnippet.loadable
    def dict(self):
        return self.yaml
