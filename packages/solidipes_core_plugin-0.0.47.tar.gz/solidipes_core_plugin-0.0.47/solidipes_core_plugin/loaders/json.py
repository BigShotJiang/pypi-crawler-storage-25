import json

from .code_snippet import CodeSnippet


class JSON(CodeSnippet):
    from ..viewers.dictionary import DictViewer

    supported_mime_types = {
        "text/plain": ["json"],
        "application/json": ["json"],
    }
    _compatible_viewers = [DictViewer]

    @CodeSnippet.loadable
    def json(self):
        _dict = {}
        with open(self.file_info.path) as json_data:
            _dict.update(json.loads(json_data.read()))
        return _dict

    @CodeSnippet.loadable
    def dict(self):
        return self.json
