from typing import Any, Dict, Generic, List, Optional, TypeVar, Union

from pydantic import field_validator
from sqlmodel import Field, SQLModel


class NDPModel(SQLModel):
    __abstract__ = True


T = TypeVar("T")


class ProjectBase(NDPModel, Generic[T]):
    table: str
    fields: str = Field("*")
    where: T


class ProjectWhere(NDPModel):
    sqlwhere: Optional[str] = Field("")
    pageNo: int = Field(1, ge=1)
    pageSize: int = Field(10, ge=0)

    @field_validator('pageNo', 'pageSize', mode='before')
    @classmethod
    def convert(cls, v):
        if v is None:
            return v
        try:
            return int(v)
        except (ValueError, TypeError):
            return v


class ProjectQuery(ProjectBase[ProjectWhere]):
    pass


class BaseResponse(NDPModel, Generic[T]):
    code: int = 100
    data: T


class InnerData(NDPModel):
    statusCode: int = 200
    result: List[dict]


class QueryOut(BaseResponse[InnerData]):
    pass


class PushData(NDPModel):
    data: Union[dict, List[dict]]
    pk: Optional[Union[str, List[str]]] = None

    @field_validator("data", mode="before")
    @classmethod
    def _ensure_list(cls, v):
        return v if isinstance(v, list) else [v]

    @field_validator("pk", mode="before")
    @classmethod
    def _normalize_pk(cls, v):
        if v is None or isinstance(v, list):
            return v

        if isinstance(v, str):
            return [v]

        raise TypeError(f"💥 pk {v}")


class PushOut(NDPModel):
    statusCode: int = 200
    description: str = "success"


class FkData(NDPModel):
    tablename: str
    primarykey: str
    primaryvalue: Any
    fields: Dict[str, Any] = {}
    childdata: List["FkData"] = []

    def walk(self, _visited: set | None = None) -> List[List]:
        if _visited is None:
            _visited = set()
        _id = id(self)
        if _id in _visited:
            return []
        _visited.add(_id)

        return (
            [[self.tablename, {**self.fields, self.primarykey: self.primaryvalue}, self.primarykey]] +
            [item for child in self.childdata for item in child.walk(_visited)]
        )
