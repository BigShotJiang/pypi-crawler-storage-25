
import typer

from .core import *
from .rdms import *

app = typer.Typer()
ndp_cmd = app.command
