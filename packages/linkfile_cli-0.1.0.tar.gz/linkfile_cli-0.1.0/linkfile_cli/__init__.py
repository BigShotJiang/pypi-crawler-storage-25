"""LinkFile CLI package."""
