"""Tests for CLI config management and helpers."""

import json
import subprocess
import sys

from am.cli import (
    _build_cli_command,
    _build_continue_command,
    format_permission_response_for_stdin,
    format_user_message_for_stdin,
    load_config,
    save_config,
)


class TestConfig:
    def test_load_config_missing(self, tmp_path, monkeypatch):
        monkeypatch.setattr("am.cli.CONFIG_FILE", tmp_path / "missing.json")
        assert load_config() == {}

    def test_save_and_load(self, tmp_path, monkeypatch):
        config_file = tmp_path / "sub" / "config.json"
        monkeypatch.setattr("am.cli.CONFIG_FILE", config_file)
        monkeypatch.setattr("am.cli.CONFIG_DIR", tmp_path / "sub")

        save_config({"host": "example.com", "secure": True})
        result = load_config()
        assert result["host"] == "example.com"
        assert result["secure"] is True


class TestFormatMessages:
    def test_user_message(self):
        result = json.loads(format_user_message_for_stdin("hello"))
        assert result["type"] == "user"
        assert result["message"]["role"] == "user"
        content = result["message"]["content"]
        assert len(content) == 1
        assert content[0]["type"] == "text"
        assert content[0]["text"] == "hello"

    def test_permission_allow(self):
        result = json.loads(format_permission_response_for_stdin(True))
        assert result["type"] == "permission_response"
        assert result["permission"] == "allow"

    def test_permission_deny(self):
        result = json.loads(format_permission_response_for_stdin(False))
        assert result["permission"] == "deny"


class TestBuildCommands:
    def test_claude_command(self):
        cmd = _build_cli_command("claude", "sess-123")
        assert cmd[0] == "claude"
        assert "--continue" in cmd
        assert "--resume" in cmd
        assert "sess-123" in cmd
        assert "--output-format" in cmd
        assert "stream-json" in cmd
        # No permission mode → flag should NOT be present
        assert "--permission-mode" not in cmd

    def test_claude_command_with_permission_mode(self):
        cmd = _build_cli_command("claude", "sess-123", permission_mode="acceptEdits")
        assert "--permission-mode" in cmd
        idx = cmd.index("--permission-mode")
        assert cmd[idx + 1] == "acceptEdits"

    def test_claude_command_rejects_unknown_permission_mode(self):
        # Unknown modes are silently dropped (we don't want to break
        # spawn just because the UI sent a garbage value).
        cmd = _build_cli_command("claude", "sess-123", permission_mode="nonsense")
        assert "--permission-mode" not in cmd

    def test_codex_command(self):
        cmd = _build_cli_command("codex", "rollout-abc")
        assert cmd == ["codex", "resume", "rollout-abc", "--json"]

    def test_gemini_command(self):
        cmd = _build_cli_command("gemini", "anything")
        assert cmd == ["gemini", "--resume"]

    def test_unsupported_cli(self):
        try:
            _build_cli_command("unknown", "x")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "unknown" in str(e)

    def test_continue_command(self):
        original = ["claude", "-p", "do stuff", "--output-format", "stream-json"]
        cmd = _build_continue_command(original, "sess-1", "next task")
        assert cmd[0] == "claude"
        assert "-p" in cmd
        assert "next task" in cmd
        assert "--continue" in cmd
        assert "--resume" in cmd
        assert "sess-1" in cmd


class TestCLIEntryPoint:
    def test_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "am", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "login" in result.stdout
        assert "connect" in result.stdout
        assert "daemon" in result.stdout

    def test_login_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "am", "login", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--host" in result.stdout
        assert "--email" in result.stdout

    def test_connect_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "am", "connect", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--host" in result.stdout

    def test_daemon_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "am", "daemon", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--token" in result.stdout

    def test_no_command_shows_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "am"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 1
