"""
Tests for Failscope core modules.
Run with: pytest tests/ -v
"""

import json
import tempfile
from pathlib import Path

from failscope.preprocessor import (
    smart_truncate,
    strip_noise,
    extract_error_signals,
    generate_fingerprint,
    preprocess,
    TRUNCATION_MARKER,
)
from failscope.stability import StabilityScorer, StabilityGrade, FlakinessVerdict
from failscope.rca_engine import OfflineRCA, Severity


# ===== Preprocessor Tests =====

class TestSmartTruncate:
    """Test Agnox-style smart truncation (first 10% + last 90%)."""

    def test_short_text_not_truncated(self):
        text = "short log output"
        result, was_truncated = smart_truncate(text, max_chars=1000)
        assert result == text
        assert was_truncated is False

    def test_long_text_truncated_with_marker(self):
        # Create text that exceeds threshold
        text = "A" * 500 + "B" * 500 + "ERROR_HERE" * 100
        result, was_truncated = smart_truncate(text, max_chars=800)
        assert was_truncated is True
        assert TRUNCATION_MARKER in result
        assert len(result) <= 800 + len(TRUNCATION_MARKER)

    def test_preserves_head_and_tail(self):
        head = "SETUP:" + "x" * 100
        tail = "ERROR:" + "y" * 100
        text = head + "MIDDLE" * 1000 + tail
        result, _ = smart_truncate(text, max_chars=300)
        # Head (first 10%) should be preserved
        assert result.startswith("SETUP:")
        # Tail (last 90%) should contain error info
        assert "ERROR:" in result or result.endswith("y" * 10)


class TestStripNoise:
    def test_removes_separator_lines(self):
        text = "===== test output =====\nactual content\n----- end -----"
        result, removed = strip_noise(text)
        assert "=====" not in result
        assert "-----" not in result
        assert "actual content" in result
        assert removed == 2

    def test_removes_platform_info(self):
        text = "platform linux -- Python 3.11.5, pytest-7.4.3\nE   AssertionError: 1 != 2"
        result, removed = strip_noise(text)
        assert "platform" not in result
        assert "AssertionError" in result

    def test_preserves_meaningful_content(self):
        text = "def test_login():\n    assert response.status_code == 200"
        result, removed = strip_noise(text)
        assert result == text
        assert removed == 0


class TestErrorSignals:
    def test_detects_assertion_errors(self):
        text = "line1\nAssertionError: expected True\nline3"
        signals = extract_error_signals(text)
        assert any("AssertionError" in s for s in signals)

    def test_detects_timeouts(self):
        text = "operation timed out after 30s\nTimeoutError"
        signals = extract_error_signals(text)
        assert len(signals) >= 1

    def test_detects_exceptions(self):
        text = "Traceback (most recent call last):\n  File test.py\nValueError: bad value"
        signals = extract_error_signals(text)
        assert len(signals) >= 2  # Traceback + ValueError


class TestFingerprinting:
    def test_same_error_same_hash(self):
        """Same error type + message + file → same fingerprint."""
        fp1 = generate_fingerprint("AssertionError: 1 != 2", "test_a", "test.py")
        fp2 = generate_fingerprint("AssertionError: 1 != 2", "test_b", "test.py")
        assert fp1.hash == fp2.hash

    def test_different_error_different_hash(self):
        fp1 = generate_fingerprint("AssertionError: 1 != 2", "test_a", "test.py")
        fp2 = generate_fingerprint("TimeoutError: timed out", "test_a", "test.py")
        assert fp1.hash != fp2.hash

    def test_normalizes_variable_data(self):
        """Numbers, UUIDs, timestamps should be normalized."""
        fp1 = generate_fingerprint(
            "ValueError: item 42 not found", "test_a", "test.py"
        )
        fp2 = generate_fingerprint(
            "ValueError: item 99 not found", "test_a", "test.py"
        )
        assert fp1.hash == fp2.hash  # numbers normalized to <NUM>

    def test_extracts_error_type(self):
        fp = generate_fingerprint("ConnectionError: refused", "test_a")
        assert fp.error_type == "ConnectionError"


class TestPreprocessPipeline:
    def test_full_pipeline(self):
        raw = (
            "platform linux -- Python 3.11\n"
            "collecting ...\n"
            "===========================\n"
            "FAILED test_login.py::test_valid_login\n"
            "E   AssertionError: assert 401 == 200\n"
            "E     +401\n"
            "E     -200\n"
        )
        result = preprocess(raw, "test_login.py::test_valid_login", "test_login.py", 5)

        assert result.noise_lines_removed >= 2
        assert result.fingerprint.error_type == "AssertionError"
        assert len(result.error_signals_found) >= 1
        assert "assert" in result.processed_text.lower() or "Assert" in result.processed_text


# ===== Stability Scorer Tests =====

class TestStabilityScorer:
    def _make_scorer(self, tmp_path):
        return StabilityScorer(tmp_path / "stability.json")

    def test_ungraded_with_few_runs(self, tmp_path):
        scorer = self._make_scorer(tmp_path)
        scorer.record("test_a", True, 0.5)
        scorer.record("test_a", True, 0.5)
        stability = scorer.score("test_a")
        assert stability.grade == StabilityGrade.UNGRADED

    def test_grade_a_high_pass_rate(self, tmp_path):
        scorer = self._make_scorer(tmp_path)
        for _ in range(20):
            scorer.record("test_a", True, 0.5)
        stability = scorer.score("test_a")
        assert stability.grade == StabilityGrade.A
        assert stability.pass_rate >= 0.95

    def test_grade_f_low_pass_rate(self, tmp_path):
        scorer = self._make_scorer(tmp_path)
        for i in range(20):
            scorer.record("test_a", i % 5 == 0, 0.5)  # 20% pass rate
        stability = scorer.score("test_a")
        assert stability.grade == StabilityGrade.F

    def test_flakiness_score_stable(self, tmp_path):
        scorer = self._make_scorer(tmp_path)
        for _ in range(10):
            scorer.record("test_a", True, 0.5)
        stability = scorer.score("test_a")
        assert stability.flakiness_score <= 20
        assert stability.verdict == FlakinessVerdict.STABLE

    def test_flakiness_score_alternating(self, tmp_path):
        """Alternating pass/fail = highly flaky."""
        scorer = self._make_scorer(tmp_path)
        for i in range(20):
            scorer.record("test_a", i % 2 == 0, 0.5)
        stability = scorer.score("test_a")
        assert stability.flakiness_score > 45
        assert stability.verdict in (FlakinessVerdict.FLAKY, FlakinessVerdict.HIGHLY_UNSTABLE)

    def test_performance_degradation(self, tmp_path):
        scorer = self._make_scorer(tmp_path)
        for _ in range(10):
            scorer.record("test_a", True, 1.0)  # avg = 1.0s
        stability = scorer.score("test_a", current_duration=3.0)  # 3x average
        assert stability.is_slow is True

    def test_trend_detection(self, tmp_path):
        scorer = self._make_scorer(tmp_path)
        # First half: mostly failing
        for _ in range(10):
            scorer.record("test_a", False, 0.5)
        # Second half: mostly passing
        for _ in range(10):
            scorer.record("test_a", True, 0.5)
        stability = scorer.score("test_a")
        assert stability.trend == "improving"

    def test_persistence(self, tmp_path):
        """Data persists across scorer instances."""
        scorer1 = self._make_scorer(tmp_path)
        for _ in range(10):
            scorer1.record("test_a", True, 0.5)

        scorer2 = self._make_scorer(tmp_path)
        stability = scorer2.score("test_a")
        assert stability.total_runs == 10


# ===== Offline RCA Tests =====

class TestOfflineRCA:
    def test_detects_assertion_failure(self):
        from failscope.preprocessor import preprocess
        preprocessed = preprocess(
            "AssertionError: assert 401 == 200",
            "test_login",
            "test_auth.py",
        )
        rca = OfflineRCA()
        result = rca.analyze(preprocessed, {"test_name": "test_login"})
        assert result.category == "assertion_failure"
        assert result.severity == Severity.MEDIUM

    def test_detects_timeout(self):
        from failscope.preprocessor import preprocess
        preprocessed = preprocess(
            "TimeoutError: operation timed out after 30s",
            "test_api_call",
        )
        rca = OfflineRCA()
        result = rca.analyze(preprocessed, {"test_name": "test_api_call"})
        assert result.category == "timeout"

    def test_detects_connection_error(self):
        from failscope.preprocessor import preprocess
        preprocessed = preprocess(
            "ConnectionError: Connection refused to localhost:5432",
            "test_db",
        )
        rca = OfflineRCA()
        result = rca.analyze(preprocessed, {"test_name": "test_db"})
        assert result.category == "connection_error"
        assert result.severity == Severity.CRITICAL

    def test_offline_lower_confidence(self):
        from failscope.preprocessor import preprocess
        preprocessed = preprocess("SomeWeirdError: ???", "test_x")
        rca = OfflineRCA()
        result = rca.analyze(preprocessed, {"test_name": "test_x"})
        assert result.confidence <= 0.3  # always lower than LLM
