def hello() -> str:
    return "Hello from azadmin!"
