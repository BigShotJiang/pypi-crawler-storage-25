"""CLI entry point: mkio serve | services | monitor | send | subpub | stream | query"""

from __future__ import annotations

import asyncio
import csv
import io
import json
import sys
from datetime import datetime, timezone
from typing import Any

from mkio._json import loads
from mkio._ref import local_ts


_VALID_COMMANDS = ("serve", "services", "monitor", "send", "subpub", "stream", "query")


def main() -> None:
    if len(sys.argv) < 2:
        _usage()

    cmd = sys.argv[1]
    if cmd.startswith("-"):
        print(f"Error: expected a command, got {cmd!r}")
        _usage()
    if cmd == "serve":
        _cmd_serve()
    elif cmd == "services":
        _cmd_services()
    elif cmd == "monitor":
        _cmd_monitor()
    elif cmd == "send":
        _cmd_send()
    elif cmd == "subpub":
        _cmd_subpub()
    elif cmd == "stream":
        _cmd_stream()
    elif cmd == "query":
        _cmd_query()
    else:
        import difflib
        close = difflib.get_close_matches(cmd, _VALID_COMMANDS, n=1, cutoff=0.5)
        hint = f" Did you mean {close[0]!r}?" if close else ""
        print(f"Unknown command: {cmd!r}.{hint}")
        _usage()


def _usage() -> None:
    print("Usage:")
    print("  mkio serve [mkio.toml]           Start a server (default: mkio.toml)")
    print("  mkio services <url> [service]    List services, or show detail for one")
    print("  mkio monitor <url> [service] [--filter <expr>]")
    print("                                   Monitor messages (all services or one)")
    print("  mkio send <url> <service> [--op <name>] <data>")
    print("                                   Send transaction(s) from JSON/CSV/inline")
    print("  mkio subpub <url> <service> <topic> [--subid <id>] [--fields <f1,f2,...>]")
    print("                                   Subscribe to a subpub service")
    print("  mkio stream <url> <service> [--subid <id>] [--fields <f1,f2,...>] [--filter <expr>] [--ref <ref>]")
    print("                                   Subscribe to a stream service")
    print("  mkio query <url> <service> [--subid <id>] [--fields <f1,f2,...>] [--filter <expr>] [--snapshotOnly] [--updateOnly]")
    print("                                   Subscribe to a query service")
    sys.exit(1)


def _cmd_serve() -> None:
    usage = "mkio serve [config.toml]"
    args = sys.argv[2:]
    _check_unknown_flags(args, set(), usage)
    if len(args) > 1:
        print(f"Error: 'serve' takes at most 1 argument (config path), got {len(args)}")
        print(f"Usage: {usage}")
        sys.exit(1)
    config_path = args[0] if args else "mkio.toml"
    from pathlib import Path
    if not Path(config_path).exists():
        print(f"Config file not found: {config_path}")
        sys.exit(1)
    from mkio.server import serve
    serve(config_path)


def _cmd_services() -> None:
    usage = "mkio services <url> [service]"
    args = sys.argv[2:]
    _check_unknown_flags(args, set(), usage)
    if len(args) < 1:
        print(f"Usage: {usage}")
        print("  e.g. mkio services http://localhost:8080")
        print("  e.g. mkio services http://localhost:8080 orders")
        sys.exit(1)
    if len(args) > 2:
        print(f"Error: 'services' takes 1–2 arguments (url [service]), got {len(args)}")
        print(f"Usage: {usage}")
        sys.exit(1)
    url = args[0].rstrip("/")
    service_name = args[1] if len(args) >= 2 else None
    if service_name:
        asyncio.run(_fetch_service_detail(url, service_name))
    else:
        asyncio.run(_fetch_services(url))


async def _fetch_services(url: str) -> None:
    import aiohttp
    api_url = f"{url}/api/services"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(api_url) as resp:
                if resp.status != 200:
                    print(f"Error: HTTP {resp.status}")
                    sys.exit(1)
                services = await resp.json()
    except aiohttp.ClientError as e:
        print(f"Error connecting to {api_url}: {e}")
        sys.exit(1)

    if not services:
        print("No services available.")
        return

    # Print table
    name_w = max(len(s["name"]) for s in services)
    proto_w = max(len(s["protocol"]) for s in services)
    name_w = max(name_w, 7)  # "SERVICE"
    proto_w = max(proto_w, 8)  # "PROTOCOL"

    print(f"{'SERVICE':<{name_w}}  {'PROTOCOL':<{proto_w}}  DETAILS")
    print(f"{'-' * name_w}  {'-' * proto_w}  {'-' * 30}")
    for svc in services:
        details = []
        if "primary_table" in svc:
            details.append(f"table={svc['primary_table']}")
        if "tables" in svc:
            details.append(f"tables={','.join(svc['tables'])}")
        if "watch_tables" in svc:
            details.append(f"watch={','.join(svc['watch_tables'])}")
        print(f"{svc['name']:<{name_w}}  {svc['protocol']:<{proto_w}}  {', '.join(details)}")


async def _fetch_service_detail(url: str, service_name: str) -> None:
    import aiohttp
    api_url = f"{url}/api/services/{service_name}"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(api_url) as resp:
                if resp.status == 404:
                    print(f"Unknown service: {service_name}")
                    sys.exit(1)
                if resp.status != 200:
                    print(f"Error: HTTP {resp.status}")
                    sys.exit(1)
                detail = await resp.json()
    except aiohttp.ClientError as e:
        print(f"Error connecting to {api_url}: {e}")
        sys.exit(1)

    _print_service_detail(detail)


def _print_service_detail(detail: dict[str, Any]) -> None:
    """Pretty-print service detail."""
    name = detail["name"]
    protocol = detail["protocol"]
    desc = detail.get("description", "")

    print(f"Service: {name} ({protocol})")
    if desc:
        print(f"  {desc}")
    print()

    if protocol == "transaction":
        _print_transaction_detail(detail)
    else:
        _print_listener_detail(detail)


def _print_transaction_detail(detail: dict[str, Any]) -> None:
    ops = detail.get("ops", {})

    # Collect all op names and their primary fields for a summary table
    op_names = list(ops.keys())
    if not op_names:
        return

    # Find max widths for alignment
    name_w = max(len(n) for n in op_names)
    name_w = max(name_w, 2)

    print("  Operations:")
    print()
    for op_name in op_names:
        op_info = ops[op_name]
        op_desc = op_info.get("description", "")
        steps = op_info.get("steps", [])
        primary = steps[0] if steps else {}
        fields = primary.get("fields", {})

        # Build a concise field summary
        parts = []
        for f, info in fields.items():
            typ_short = info.get("type", "")[0:3].lower() if info.get("type") else ""
            if info.get("key"):
                parts.append(f"{f}* (key)")
            elif info.get("required"):
                parts.append(f"{f}*")
            elif info.get("default"):
                parts.append(f"{f}={info['default']}")
            else:
                parts.append(f)

        field_str = ", ".join(parts) if parts else "(no fields)"
        desc_str = f"  — {op_desc}" if op_desc else ""

        print(f"    {op_name:<{name_w}}  {field_str}{desc_str}")

    # Detailed field info for each op
    print()
    for op_name in op_names:
        op_info = ops[op_name]
        steps = op_info.get("steps", [])
        if not steps:
            continue

        primary = steps[0]
        fields = primary.get("fields", {})
        auto = primary.get("auto", {})

        if not fields and not auto:
            continue

        print(f"  {op_name}:")
        if fields:
            col_w = max(len(f) for f in fields)
            for f, info in fields.items():
                typ = info.get("type", "")
                notes = []
                if info.get("key"):
                    notes.append("required, key")
                elif info.get("required"):
                    notes.append("required")
                if info.get("default"):
                    notes.append(f"default: {info['default']}")
                note_str = f"  {', '.join(notes)}" if notes else ""
                print(f"    {f:<{col_w}}  {typ:<10}{note_str}")

        if auto:
            auto_names = ", ".join(f"{f} ({info.get('source', '')})" for f, info in auto.items())
            print(f"    auto: {auto_names}")

        # Secondary steps (audit, etc.)
        for step in steps[1:]:
            bind = step.get("bind", {})
            if bind:
                bound_parts = ", ".join(f"{k}={v}" for k, v in bind.items())
                print(f"    + {step['table']}: {bound_parts}")

        # Example
        example = op_info.get("example")
        if example:
            print(f"    example: {example}")

        print()

    # Recovery info
    recovery = detail.get("recovery")
    if recovery:
        print("  Recovery:")
        print(f"    {recovery['description']}")
        check = recovery.get("check_message", {})
        if check:
            print(f"    Check: {json.dumps(check)}")
        print()


def _print_listener_detail(detail: dict[str, Any]) -> None:
    primary = detail.get("primary_table")
    if primary:
        print(f"  Table: {primary}")

    topic = detail.get("topic")
    if topic:
        print(f"  Topic: {topic}")

    filterable = detail.get("filterable", [])
    if filterable:
        print(f"  Filter by: {', '.join(filterable)}")

    schema = detail.get("schema", {})
    if schema:
        print()
        print("  Schema:")
        col_w = max(len(f) for f in schema)
        for f, info in schema.items():
            typ = info.get("type", "")
            note = "  (primary key)" if info.get("pk") else ""
            print(f"    {f:<{col_w}}  {typ}{note}")

    # Subscribe protocol / recovery
    subscribe = detail.get("subscribe", {})
    if subscribe:
        print()
        print("  Subscribe protocol:")
        msg = subscribe.get("message", {})
        print(f"    Message: {json.dumps(msg)}")
        response_types = subscribe.get("response_types", [])
        if response_types:
            print(f"    Response types: {', '.join(response_types)}")
        recovery = subscribe.get("recovery")
        if recovery:
            print(f"    Recovery: {recovery}")
        log_size = subscribe.get("change_log_size") or subscribe.get("buffer_size")
        if log_size:
            label = "buffer_size" if "buffer_size" in subscribe else "change_log_size"
            print(f"    {label}: {log_size:,}")

    example = detail.get("example", {})
    if example:
        print()
        print("  Example:")
        for cmd in example.values():
            print(f"    {cmd}")
    print()


def _cmd_monitor() -> None:
    usage = "mkio monitor <url> [service] [--filter <expr>]"
    args = sys.argv[2:]
    if len(args) < 1:
        print(f"Usage: {usage}")
        print("  e.g. mkio monitor ws://localhost:8080")
        print("  e.g. mkio monitor ws://localhost:8080 orders")
        print("  e.g. mkio monitor ws://localhost:8080 --filter \"direction == 'in'\"")
        sys.exit(1)
    _check_unknown_flags(args, {"--filter"}, usage)
    filter_expr = _extract_flag(args, "--filter")
    _check_extra_positional(args[2:] if len(args) > 2 else [], usage)
    url = args[0].rstrip("/")
    service = args[1] if len(args) >= 2 else None
    ws_url = _normalize_ws_url(url)

    filter_fn = None
    if filter_expr:
        from mkio._expr import compile_filter
        try:
            filter_fn = compile_filter(filter_expr)
        except Exception as e:
            print(f"Error: invalid filter expression: {e}")
            sys.exit(1)

    try:
        asyncio.run(_monitor_service(ws_url, service, filter_fn))
    except KeyboardInterrupt:
        print("\nMonitor stopped.")
    except Exception as e:
        _connection_error(ws_url, e)


async def _monitor_service(
    ws_url: str,
    service: str | None,
    filter_fn: Any = None,
) -> None:
    import aiohttp

    try:
        async with aiohttp.ClientSession() as session:
            async with session.ws_connect(ws_url) as ws:
                # Send monitor request
                from mkio._json import dumps
                monitor_msg: dict[str, Any] = {"type": "monitor"}
                if service:
                    monitor_msg["service"] = service
                await ws.send_bytes(dumps(monitor_msg))

                # Wait for ack
                ack_msg = await ws.receive()
                ack = loads(ack_msg.data)
                if ack.get("type") == "error":
                    print(f"Error: {ack.get('message', 'Unknown error')}")
                    sys.exit(1)

                label = f"service: {service}" if service else "all services"
                print(f"Monitoring {label}")
                print(f"Connected to: {ws_url}")
                if filter_fn:
                    print(f"Filter active")
                print("---")

                # Stream messages
                async for msg in ws:
                    if msg.type in (aiohttp.WSMsgType.TEXT, aiohttp.WSMsgType.BINARY):
                        data = loads(msg.data)
                        if filter_fn:
                            try:
                                if not filter_fn(data):
                                    continue
                            except Exception:
                                pass
                        _print_monitor_message(data)
                    elif msg.type == aiohttp.WSMsgType.ERROR:
                        print(f"WebSocket error: {ws.exception()}")
                        break

    except aiohttp.ClientError as e:
        print(f"Error connecting to {ws_url}: {e}")
        sys.exit(1)


def _print_monitor_message(data: dict[str, Any]) -> None:
    """Pretty-print a monitor envelope."""
    direction = data.get("direction", "?")
    service = data.get("service", "?")
    message = data.get("message", {})
    msg_type = message.get("type", "")

    now = local_ts()
    arrow = ">>" if direction == "in" else "<<"

    # Color codes (if terminal supports it)
    if sys.stdout.isatty():
        if direction == "in":
            color, reset = "\033[36m", "\033[0m"  # cyan
        else:
            color, reset = "\033[33m", "\033[0m"  # yellow
    else:
        color = reset = ""

    header = f"{color}[{now}] {arrow} {direction.upper():3s} {msg_type or '(message)'}{reset}"
    print(header)

    # Compact JSON for the message body
    body = json.dumps(message, indent=2, default=str)
    print(body)
    print()


# ---- send command -----------------------------------------------------------

def _cmd_send() -> None:
    usage = "mkio send <url> <service> [--op <name>] <data>"
    args = sys.argv[2:]
    if len(args) < 3:
        print(f"Usage: {usage}")
        print("  <data> can be inline JSON, a .json file, or a .csv file")
        sys.exit(1)

    url = args[0].rstrip("/")
    service = args[1]
    rest = args[2:]

    _check_unknown_flags(rest, {"--op"}, usage)

    op_name = None
    if "--op" in rest:
        idx = rest.index("--op")
        if idx + 1 >= len(rest):
            print("Error: --op requires a value")
            sys.exit(1)
        op_name = rest[idx + 1]
        rest = rest[:idx] + rest[idx + 2:]

    if not rest:
        print("Error: no data argument provided")
        print(f"Usage: {usage}")
        sys.exit(1)

    if len(rest) > 1:
        print(f"Error: expected 1 data argument, got {len(rest)}: {rest}")
        print(f"Usage: {usage}")
        sys.exit(1)

    data_arg = rest[0]
    messages = _load_messages(data_arg)

    ws_url = _normalize_ws_url(url)

    try:
        asyncio.run(_send_messages(ws_url, service, op_name, messages))
    except KeyboardInterrupt:
        pass


_ENVELOPE_KEYS = {"op", "ref", "service", "msgid"}


def _load_messages(data_arg: str) -> list[dict[str, Any]]:
    """Load messages from inline JSON, .json file, or .csv file.

    Returns a list of dicts. Each dict is either:
    - Flat data (all keys are data fields), or
    - Structured with envelope fields: {"data": {...}, "op": "...", "ref": "..."}

    CSV files support ``data.`` prefixed columns (e.g. ``data.id``) to separate
    data fields from envelope fields (``op``, ``ref``).  Flat CSVs without
    ``data.`` prefixes remain backwards-compatible.
    """
    if data_arg.endswith(".json"):
        from pathlib import Path
        if not Path(data_arg).exists():
            print(f"Error: file not found: {data_arg}")
            sys.exit(1)
        try:
            with open(data_arg) as f:
                parsed = json.load(f)
        except json.JSONDecodeError as e:
            print(f"Error: invalid JSON in {data_arg}: {e}")
            sys.exit(1)
        items = parsed if isinstance(parsed, list) else [parsed]
        return [_structure_json_msg(m) for m in items]
    elif data_arg.endswith(".csv"):
        from pathlib import Path
        if not Path(data_arg).exists():
            print(f"Error: file not found: {data_arg}")
            sys.exit(1)
        with open(data_arg) as f:
            reader = csv.DictReader(f)
            rows = []
            for raw_row in reader:
                rows.append(_structure_csv_row(raw_row))
            if not rows:
                print(f"Warning: CSV file {data_arg} has no data rows")
            return rows
    else:
        try:
            parsed = json.loads(data_arg)
        except json.JSONDecodeError as e:
            print(f"Error: invalid inline JSON: {e}")
            print("  Data must be inline JSON, a .json file, or a .csv file")
            sys.exit(1)
        items = parsed if isinstance(parsed, list) else [parsed]
        return [_structure_json_msg(m) for m in items]


def _structure_json_msg(obj: dict[str, Any]) -> dict[str, Any]:
    """If obj already has a 'data' sub-dict, treat as structured; otherwise flat."""
    if "data" in obj and isinstance(obj["data"], dict):
        return obj
    return obj


def _structure_csv_row(raw_row: dict[str, str]) -> dict[str, Any]:
    """Parse a CSV row, separating envelope fields from data fields.

    Columns prefixed with ``data.`` have the prefix stripped and go into
    the ``data`` sub-dict. Recognised envelope keys (``op``, ``ref``) become
    top-level. ``service`` is dropped (already on CLI). Other columns go
    into ``data`` for backwards compatibility with flat CSVs.
    """
    has_data_prefix = any(k.startswith("data.") for k in raw_row)
    msg: dict[str, Any] = {}
    data: dict[str, Any] = {}

    for k, v in raw_row.items():
        if k.startswith("data."):
            data[k[5:]] = _auto_convert(v)
        elif k in _ENVELOPE_KEYS:
            if k != "service":
                msg[k] = v
        elif has_data_prefix:
            pass  # ignore unknown non-data columns when data. prefix is used
        else:
            data[k] = _auto_convert(v)

    if msg:
        msg["data"] = data
        return msg
    return data


def _auto_convert(value: str) -> Any:
    """Convert string values to int/float if possible."""
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value


async def _send_messages(
    ws_url: str,
    service: str,
    op_name: str | None,
    messages: list[dict[str, Any]],
) -> None:
    from mkio.client import MkioClient

    async with MkioClient(ws_url, reconnect=False) as client:
        total = len(messages)
        for i, msg in enumerate(messages, 1):
            # Extract envelope fields if present
            if "data" in msg and isinstance(msg["data"], dict):
                data = msg["data"]
                row_op = msg.get("op")
                row_ref = msg.get("ref")
                row_msgid = msg.get("msgid")
            else:
                data = msg
                row_op = None
                row_ref = None
                row_msgid = None

            kwargs: dict[str, Any] = {}
            effective_op = row_op or op_name
            if effective_op:
                kwargs["op"] = effective_op
            if row_msgid is not None:
                kwargs["msgid"] = row_msgid

            try:
                result = await client.send(service, data, ref=row_ref, **kwargs)
                ref = result.get("ref", "")
                if result.get("ok"):
                    print(f"[{i}/{total}] ok ref={ref}")
                else:
                    err_msg = result.get("message", "unknown error")
                    print(f"[{i}/{total}] error: {err_msg}")
            except Exception as e:
                print(f"[{i}/{total}] error: {e}")


# ---- subscribe commands (subpub, stream, query) -----------------------------

def _cmd_subpub() -> None:
    args = sys.argv[2:]
    usage = "mkio subpub <url> <service> <topic> [--subid <id>] [--fields <f1,f2,...>]"
    if len(args) < 3:
        print(f"Usage: {usage}")
        sys.exit(1)

    url = args[0].rstrip("/")
    service = args[1]
    topic = args[2]
    rest = args[3:]
    _check_unknown_flags(rest, {"--fields", "--subid"}, usage)
    fields = _extract_fields(rest)
    subid = _extract_flag(rest, "--subid")
    _check_extra_positional(rest, usage)
    ws_url = _normalize_ws_url(url)

    try:
        asyncio.run(_subscribe_service(ws_url, service, "subpub", None, None, subid, topic=topic, fields=fields))
    except KeyboardInterrupt:
        print("\nSubscription stopped.")


def _cmd_stream() -> None:
    args = sys.argv[2:]
    usage = "mkio stream <url> <service> [--subid <id>] [--fields <f1,f2,...>] [--filter <expr>] [--ref <ref>]"
    if len(args) < 2:
        print(f"Usage: {usage}")
        sys.exit(1)

    url = args[0].rstrip("/")
    service = args[1]
    rest = args[2:]
    _check_unknown_flags(rest, {"--filter", "--fields", "--ref", "--subid"}, usage)
    filter_expr = _extract_flag(rest, "--filter")
    fields = _extract_fields(rest)
    ref = _extract_flag(rest, "--ref")
    if ref is None:
        from mkio._ref import next_ref
        ref = next_ref()
    subid = _extract_flag(rest, "--subid")
    _check_extra_positional(rest, usage)
    ws_url = _normalize_ws_url(url)

    try:
        asyncio.run(_subscribe_service(ws_url, service, "stream", filter_expr, ref, subid, fields=fields))
    except KeyboardInterrupt:
        print("\nSubscription stopped.")


def _cmd_query() -> None:
    args = sys.argv[2:]
    usage = "mkio query <url> <service> [--subid <id>] [--fields <f1,f2,...>] [--filter <expr>] [--snapshotOnly] [--updateOnly]"
    if len(args) < 2:
        print(f"Usage: {usage}")
        sys.exit(1)

    url = args[0].rstrip("/")
    service = args[1]
    rest = args[2:]
    _check_unknown_flags(rest, {"--filter", "--fields", "--subid", "--snapshotOnly", "--updateOnly"}, usage)
    filter_expr = _extract_flag(rest, "--filter")
    fields = _extract_fields(rest)
    subid = _extract_flag(rest, "--subid")
    snapshot, updates = _parse_mode_flags(rest)
    _check_extra_positional(rest, usage)
    ws_url = _normalize_ws_url(url)

    try:
        asyncio.run(_subscribe_service(ws_url, service, "query", filter_expr, None, subid, snapshot=snapshot, updates=updates, fields=fields))
    except KeyboardInterrupt:
        print("\nSubscription stopped.")


def _parse_mode_flags(args: list[str]) -> tuple[bool, bool]:
    snapshot_only = "--snapshotOnly" in args
    update_only = "--updateOnly" in args
    if snapshot_only and update_only:
        print("Error: --snapshotOnly and --updateOnly are mutually exclusive")
        sys.exit(1)
    if snapshot_only:
        args.remove("--snapshotOnly")
        return True, False
    if update_only:
        args.remove("--updateOnly")
        return False, True
    return True, True


def _extract_fields(args: list[str]) -> list[str] | None:
    raw = _extract_flag(args, "--fields")
    if raw is None:
        return None
    return [f.strip() for f in raw.split(",") if f.strip()]


def _extract_flag(args: list[str], flag: str) -> str | None:
    if flag not in args:
        return None
    idx = args.index(flag)
    if idx + 1 >= len(args):
        print(f"Error: {flag} requires a value")
        sys.exit(1)
    value = args[idx + 1]
    del args[idx:idx + 2]
    return value


async def _subscribe_service(
    ws_url: str,
    service: str,
    protocol: str,
    filter_expr: str | None,
    ref: str | None = None,
    subid: str | None = None,
    snapshot: bool = True,
    updates: bool = True,
    fields: list[str] | None = None,
    topic: str | None = None,
) -> None:
    from mkio.client import MkioClient

    async with MkioClient(ws_url, reconnect=True) as client:
        async for msg in client.subscribe(service, protocol, topic=topic, filter=filter_expr, ref=ref, subid=subid, snapshot=snapshot, updates=updates, fields=fields):
            if msg.get("type") == "nack":
                print(f"Error: {msg.get('message', 'subscription rejected')}")
                sys.exit(1)
            _print_subscribe_message(msg)


def _print_subscribe_message(data: dict[str, Any]) -> None:
    """Pretty-print a subscription message."""
    msg_type = data.get("type", "")
    ref = data.get("ref", "")
    now = local_ts()

    is_tty = sys.stdout.isatty()
    ver_suffix = f" ref={ref}" if ref else ""

    if msg_type == "snapshot":
        rows = data.get("rows", [])
        if is_tty:
            print(f"\033[32m[{now}] SNAPSHOT ({len(rows)} rows){ver_suffix}\033[0m")
        else:
            print(f"[{now}] SNAPSHOT ({len(rows)} rows){ver_suffix}")
        for row in rows:
            print(f"  {json.dumps(row, default=str)}")
    elif msg_type == "delta":
        changes = data.get("changes", [])
        if is_tty:
            print(f"\033[35m[{now}] DELTA ({len(changes)} changes){ver_suffix}\033[0m")
        else:
            print(f"[{now}] DELTA ({len(changes)} changes){ver_suffix}")
        for c in changes:
            op = c.get("op", "?")
            row = c.get("row", {})
            print(f"  {op}: {json.dumps(row, default=str)}")
    elif msg_type == "update":
        op = data.get("op", "?")
        row = data.get("row", {})
        if is_tty:
            color = "\033[36m" if op == "insert" else "\033[33m" if op == "update" else "\033[31m"
            print(f"{color}[{now}] UPDATE {op}{ver_suffix}\033[0m")
        else:
            print(f"[{now}] UPDATE {op}{ver_suffix}")
        print(f"  {json.dumps(row, default=str)}")
    else:
        print(f"[{now}] {msg_type}: {json.dumps(data, default=str)}")


def _check_unknown_flags(args: list[str], known: set[str], usage: str) -> None:
    """Error and exit if args contain any unrecognised --flags."""
    for arg in args:
        if arg.startswith("--") and arg not in known:
            if known:
                import difflib
                close = difflib.get_close_matches(arg, known, n=1, cutoff=0.5)
                hint = f" Did you mean {close[0]!r}?" if close else ""
                valid = ", ".join(sorted(known))
                print(f"Unknown option: {arg}.{hint}")
                print(f"Valid options: {valid}")
            else:
                print(f"Unknown option: {arg} (this command takes no options)")
            print(f"Usage: {usage}")
            sys.exit(1)


def _check_extra_positional(args: list[str], usage: str) -> None:
    """Error and exit if there are leftover positional args after flag extraction."""
    extra = [a for a in args if not a.startswith("--")]
    if extra:
        print(f"Error: unexpected argument(s): {' '.join(extra)}")
        print(f"Usage: {usage}")
        sys.exit(1)


# ---- helpers ----------------------------------------------------------------

def _connection_error(ws_url: str, exc: Exception) -> None:
    """Print a helpful connection error and exit."""
    base_url = ws_url.rsplit("/ws", 1)[0]
    print(f"Error: could not connect to {base_url}")
    print(f"  {type(exc).__name__}: {exc}")
    print("  Is the mkio server running?")
    sys.exit(1)


def _normalize_ws_url(url: str) -> str:
    """Normalize a URL to ws:// and append /ws path."""
    if url.startswith("http://"):
        url = "ws://" + url[7:]
    elif url.startswith("https://"):
        url = "wss://" + url[8:]
    elif not url.startswith("ws://") and not url.startswith("wss://"):
        url = "ws://" + url
    return f"{url}/ws"


if __name__ == "__main__":
    main()
