"""Core services for TraceBrain."""
