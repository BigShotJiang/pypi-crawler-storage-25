"""
TraceStore implementation using a Strategy Pattern for multiple backends.

This module provides a flexible storage system for agent execution traces,
supporting both SQLite (for development) and PostgreSQL (for production).
"""

from contextlib import contextmanager
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Iterator, Union
import logging
import re
import json
import os

import sqlparse
from sqlalchemy import create_engine, event, func, cast, text, Integer, Float, case, inspect
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.exc import IntegrityError, ProgrammingError, TimeoutError
from sqlalchemy.orm import joinedload, sessionmaker, Session, selectinload

from tracebrain.config import settings
from tracebrain.core.services.embedding import EmbeddingFactory
from tracebrain.db.base import (
    Base,
    Trace,
    Span,
    ChatSession,
    ChatMessage,
    TraceStatus,
    CurriculumTask,
    History,
    Settings as DBSettings,
)

logger = logging.getLogger(__name__)

_ALLOWED_SETTINGS_PROVIDERS = {"openai", "gemini", "anthropic", "huggingface"}
_API_KEY_FIELD_TO_ENV = {
    "openai_api_key": "OPENAI_API_KEY",
    "gemini_api_key": "GEMINI_API_KEY",
    "anthropic_api_key": "ANTHROPIC_API_KEY",
    "huggingface_api_key": "HUGGINGFACE_API_KEY",
}


class BaseStorageBackend:
    """
    Base class for trace storage backends.

    This class defines the interface that all storage backends must implement.
    It handles SQLAlchemy engine and session setup, and provides the core
    method for adding traces to the database.
    """

    def __init__(self, db_url: str):
        """
        Initialize the storage backend.

        Args:
            db_url (str): SQLAlchemy database connection URL.
        """
        self.db_url = db_url
        self.is_sqlite = db_url.startswith("sqlite")

        engine_kwargs: Dict[str, Any] = {
            "echo": settings.LOG_LEVEL.lower() == "debug",
            "pool_pre_ping": True,
            "pool_recycle": settings.DB_POOL_RECYCLE,
        }

        if self.is_sqlite:
            engine_kwargs["connect_args"] = {"check_same_thread": False}
        else:
            engine_kwargs["pool_size"] = settings.DB_POOL_SIZE
            engine_kwargs["max_overflow"] = settings.DB_MAX_OVERFLOW

        self.engine = create_engine(db_url, **engine_kwargs)

        if self.is_sqlite:
            @event.listens_for(self.engine, "connect")
            def set_sqlite_pragma(dbapi_connection, connection_record):
                cursor = dbapi_connection.cursor()
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.close()
                
        self.SessionLocal = sessionmaker(
            bind=self.engine,
            autocommit=False,
            autoflush=False,
            expire_on_commit=False
        )

        self.embedding_provider = EmbeddingFactory.create()

        self._create_tables()

    def _create_tables(self) -> None:
        """Create all tables defined in the models."""
        if not self.is_sqlite:
            with self.engine.begin() as connection:
                connection.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        Base.metadata.create_all(bind=self.engine)
        self._ensure_settings_schema()
        logger.info("Database tables created/verified for %s", self.__class__.__name__)

    def _ensure_settings_schema(self) -> None:
        """Backfill settings columns for existing databases created before new fields existed."""
        inspector = inspect(self.engine)
        if not inspector.has_table("settings"):
            return

        existing_columns = {column["name"] for column in inspector.get_columns("settings")}
        alter_statements: List[str] = []

        if "curator_provider" not in existing_columns:
            alter_statements.append(
                "ALTER TABLE settings ADD COLUMN curator_provider VARCHAR(50) NOT NULL DEFAULT 'gemini'"
            )
        if "curator_model" not in existing_columns:
            alter_statements.append(
                "ALTER TABLE settings ADD COLUMN curator_model VARCHAR(255) NOT NULL DEFAULT 'gemini-2.5-flash'"
            )
        if "openai_api_key" not in existing_columns:
            alter_statements.append(
                "ALTER TABLE settings ADD COLUMN openai_api_key VARCHAR(512)"
            )
        if "gemini_api_key" not in existing_columns:
            alter_statements.append(
                "ALTER TABLE settings ADD COLUMN gemini_api_key VARCHAR(512)"
            )
        if "anthropic_api_key" not in existing_columns:
            alter_statements.append(
                "ALTER TABLE settings ADD COLUMN anthropic_api_key VARCHAR(512)"
            )
        if "huggingface_api_key" not in existing_columns:
            alter_statements.append(
                "ALTER TABLE settings ADD COLUMN huggingface_api_key VARCHAR(512)"
            )

        if not alter_statements:
            return

        with self.engine.begin() as connection:
            for statement in alter_statements:
                connection.execute(text(statement))

        logger.info("Backfilled settings table with missing columns: %s", ", ".join(alter_statements))

    def get_session(self) -> Session:
        """Get a new database session."""
        return self.SessionLocal()

    @contextmanager
    def session_scope(self) -> Iterator[Session]:
        """Provide a transactional scope around a series of operations."""
        session = self.get_session()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def add_trace_from_dict(self, trace_data: Dict[str, Any]) -> str:
        """
        Add a trace to the database from a dictionary (parsed JSON).

        Args:
            trace_data (dict): A dictionary representing a complete trace,
                conforming to the TraceBrain OTLP schema.

        Returns:
            str: The trace_id of the inserted trace.

        Raises:
            ValueError: If the trace_data is invalid or missing required fields.
        """
        trace_id = trace_data.get("trace_id")
        if not trace_id:
            raise ValueError("trace_id is required in trace_data")

        attributes = trace_data.get("attributes") or {}
        system_prompt = attributes.get("system_prompt")
        episode_id = attributes.get("tracebrain.episode.id")
        status_value = attributes.get("tracebrain.trace.status")
        priority_value = attributes.get("tracebrain.trace.priority")
        ai_evaluation = attributes.get("tracebrain.ai_evaluation")

        spans_data = trace_data.get("spans") or []

        status = TraceStatus.running
        if isinstance(status_value, str):
            try:
                status = TraceStatus(status_value)
            except ValueError:
                status = TraceStatus.running

        has_system_error = self._has_system_error(spans_data)
        needs_review = (
            self._has_active_help_request(spans_data)
            or self._ai_eval_requires_review(ai_evaluation)
            or has_system_error
        )
        if needs_review:
            status = TraceStatus.needs_review
        if has_system_error and status == TraceStatus.failed:
            status = TraceStatus.needs_review

        priority = priority_value if isinstance(priority_value, int) else 3
        if priority < 1 or priority > 5:
            priority = 3

        if isinstance(attributes, dict):
            attributes["tracebrain.trace.status"] = (
                status.value if hasattr(status, "value") else str(status)
            )
        else:
            attributes = {
                "tracebrain.trace.status": (
                    status.value if hasattr(status, "value") else str(status)
                )
            }

        trace = Trace(
            id=trace_id,
            system_prompt=system_prompt,
            episode_id=episode_id,
            created_at=datetime.utcnow(),
            status=status,
            priority=priority,
            embedding=None,
            attributes=attributes,
            ai_evaluation=ai_evaluation,
        )

        for span_data in spans_data:
            span = self._create_span_from_dict(span_data, trace_id)
            trace.spans.append(span)

        session = self.get_session()
        try:
            session.add(trace)
            session.commit()
            logger.info("Successfully added trace %s with %s spans", trace_id, len(trace.spans))
            return trace_id
        except IntegrityError:
            session.rollback()
            existing = (
                session.query(Trace)
                .options(selectinload(Trace.spans))
                .filter(Trace.id == trace_id)
                .first()
            )
            if existing:
                if system_prompt and not existing.system_prompt:
                    existing.system_prompt = system_prompt
                if episode_id and not existing.episode_id:
                    existing.episode_id = episode_id
                if attributes:
                    if isinstance(existing.attributes, dict):
                        existing.attributes = {**existing.attributes, **attributes}
                    else:
                        existing.attributes = dict(attributes)
                if needs_review:
                    existing.status = TraceStatus.needs_review
                elif status != TraceStatus.running or existing.status == TraceStatus.running:
                    existing.status = status
                if isinstance(existing.attributes, dict):
                    existing.attributes["tracebrain.trace.status"] = (
                        existing.status.value if hasattr(existing.status, "value") else str(existing.status)
                    )
                else:
                    existing.attributes = {
                        "tracebrain.trace.status": (
                            existing.status.value if hasattr(existing.status, "value") else str(existing.status)
                        )
                    }
                if priority != existing.priority:
                    existing.priority = priority
                if ai_evaluation and not existing.ai_evaluation:
                    existing.ai_evaluation = ai_evaluation

                existing_span_ids = {span.span_id for span in existing.spans}
                for span_data in spans_data:
                    span_id = span_data.get("span_id")
                    if not span_id or span_id in existing_span_ids:
                        continue
                    span = self._create_span_from_dict(span_data, trace_id)
                    existing.spans.append(span)

                session.commit()
                logger.info("Merged trace %s with %s new spans", trace_id, len(spans_data))
                return trace_id
            raise
        except Exception:
            session.rollback()
            logger.exception("Failed to add trace")
            raise
        finally:
            session.close()

    def update_trace_embedding(self, trace_id: str, text_to_embed: str) -> None:
        if not trace_id or not text_to_embed:
            return

        embedding = self.embedding_provider.get_embedding(text_to_embed)
        if not embedding:
            return

        session = self.get_session()
        try:
            trace = session.query(Trace).filter(Trace.id == trace_id).first()
            if not trace:
                return
            trace.embedding = embedding
            session.commit()
        except Exception:
            session.rollback()
            logger.exception("Failed to update embedding for trace %s", trace_id)
        finally:
            session.close()

    def init_trace(
        self,
        trace_id: str,
        episode_id: Optional[str] = None,
        system_prompt: Optional[str] = None,
    ) -> str:
        if not trace_id:
            raise ValueError("trace_id is required")

        session = self.get_session()
        try:
            existing = session.query(Trace).filter(Trace.id == trace_id).first()
            if existing:
                return trace_id

            trace = Trace(
                id=trace_id,
                system_prompt=system_prompt,
                episode_id=episode_id,
                created_at=datetime.utcnow(),
                status=TraceStatus.running,
                priority=3,
                attributes={
                    "system_prompt": system_prompt,
                    "tracebrain.episode.id": episode_id,
                },
            )
            session.add(trace)
            session.commit()
            logger.info("Initialized trace %s", trace_id)
            return trace_id
        except Exception:
            session.rollback()
            logger.exception("Failed to initialize trace")
            raise
        finally:
            session.close()

    def _create_span_from_dict(self, span_data: Dict[str, Any], trace_id: str) -> Span:
        """Create a Span object from a dictionary."""
        span_id = span_data.get("span_id")
        if not span_id:
            raise ValueError("span_id is required in span_data")

        start_time = self._parse_timestamp(span_data.get("start_time"))
        end_time = self._parse_timestamp(span_data.get("end_time"))

        attributes = span_data.get("attributes") or {}
        if isinstance(attributes, dict) and "system_prompt" in attributes:
            attributes = dict(attributes)
            attributes.pop("system_prompt", None)

        return Span(
            span_id=span_id,
            trace_id=trace_id,
            parent_id=span_data.get("parent_id"),
            name=span_data.get("name") or "Unknown",
            start_time=start_time,
            end_time=end_time,
            attributes=attributes,
        )

    @staticmethod
    def _has_active_help_request(spans_data: List[Dict[str, Any]]) -> bool:
        for span in spans_data:
            attrs = (span or {}).get("attributes") or {}
            if attrs.get("tracebrain.span.type") == "tool_execution":
                tool_name = attrs.get("tracebrain.tool.name")
                if tool_name == "request_human_intervention":
                    return True

            tool_code = attrs.get("tracebrain.llm.tool_code")
            if isinstance(tool_code, str) and "request_human_intervention" in tool_code:
                return True
        return False

    @staticmethod
    def _has_system_error(spans_data: List[Dict[str, Any]]) -> bool:
        for span in spans_data:
            attrs = (span or {}).get("attributes") or {}
            if attrs.get("otel.status_code") == "ERROR":
                return True
        return False

    @staticmethod
    def _ai_eval_requires_review(ai_evaluation: Any) -> bool:
        critical_errors = {
            "logic_loop",
            "hallucination",
            "invalid_tool_usage",
            "tool_execution_error",
            "format_error",
            "misinterpretation",
            "context_overflow",
        }
        confidence_threshold = 0.75
        if not isinstance(ai_evaluation, dict):
            return False
        error_type = ai_evaluation.get("error_type")
        if isinstance(error_type, str) and error_type in critical_errors:
            return True
        confidence = ai_evaluation.get("confidence")
        if isinstance(confidence, (int, float)) and float(confidence) < confidence_threshold:
            return True
        return False

    @staticmethod
    def _extract_first_query(spans_data: List[Dict[str, Any]]) -> Optional[str]:
        if not spans_data:
            return None
        attrs = (spans_data[0] or {}).get("attributes") or {}
        raw = attrs.get("tracebrain.llm.new_content")
        if not raw:
            return None
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except Exception:
                return raw
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict) and item.get("role") == "user":
                    return item.get("content")
        if isinstance(raw, dict):
            return raw.get("content")
        return None

    @staticmethod
    def _extract_embedding_text(system_prompt: Optional[str], spans_data: List[Dict[str, Any]]) -> str:
        parts: List[str] = []
        if system_prompt:
            parts.append(f"System prompt: {system_prompt}")

        first_query = BaseStorageBackend._extract_first_query(spans_data)
        if first_query:
            parts.append(f"User query: {first_query}")

        for span in spans_data:
            attrs = (span or {}).get("attributes") or {}
            thought = attrs.get("tracebrain.llm.thought")
            final_answer = attrs.get("tracebrain.llm.final_answer")
            tool_output = attrs.get("tracebrain.tool.output")
            completion = attrs.get("tracebrain.llm.completion")

            for label, value in (
                ("Thought", thought),
                ("Final", final_answer),
                ("Output", tool_output),
                ("Completion", completion),
            ):
                if value is None:
                    continue
                if isinstance(value, (dict, list)):
                    value = json.dumps(value)
                text = str(value).strip()
                if not text:
                    continue
                parts.append(f"{label}: {text[:500]}")

        return "\n".join(parts).strip()

    def search_similar_experiences(
        self,
        text: str,
        min_rating: int = 4,
        limit: int = 3,
    ) -> List[Dict[str, Any]]:
        if self.is_sqlite or not text:
            return []

        embedding = self.embedding_provider.get_embedding(text)
        if not embedding:
            return []

        session = self.get_session()
        try:
            rating_value = cast(
                func.jsonb_extract_path_text(cast(Trace.feedback, JSONB), "rating"),
                Integer,
            )
            try:
                distance = Trace.embedding.cosine_distance(embedding)
            except AttributeError:
                distance = Trace.embedding.op("<=>")(embedding)
            rows = (
                session.query(Trace, distance.label("distance"))
                .filter(Trace.embedding.isnot(None))
                .filter(Trace.feedback.isnot(None))
                .filter(rating_value >= min_rating)
                .order_by(distance.asc())
                .limit(limit)
                .all()
            )

            results = []
            for trace, dist in rows:
                results.append(
                    {
                        "trace_id": trace.id,
                        "score": float(1.0 - dist) if dist is not None else None,
                        "rating": trace.feedback.get("rating") if trace.feedback else None,
                        "feedback": trace.feedback,
                        "created_at": trace.created_at,
                    }
                )
            return results
        finally:
            session.close()

    @staticmethod
    def _parse_timestamp(timestamp_str: Optional[str]) -> Optional[datetime]:
        """Parse an ISO 8601 timestamp string to a datetime object."""
        if not timestamp_str:
            return None

        match = re.match(
            r"^(?P<base>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?P<frac>\.\d+)?(?P<tz>Z|[+-]\d{2}:?\d{2})?$",
            timestamp_str
        )
        if not match:
            logger.warning("Failed to parse timestamp '%s'", timestamp_str)
            return None

        base = match.group("base")
        frac = match.group("frac") or ""
        tz = match.group("tz") or ""

        if tz == "Z":
            tz = "+00:00"
        if frac:
            frac_digits = frac[1:]
            frac_digits = (frac_digits[:6]).ljust(6, "0")
            frac = f".{frac_digits}"

        normalized = f"{base}{frac}{tz}"
        try:
            return datetime.fromisoformat(normalized)
        except ValueError:
            logger.warning("Failed to parse timestamp '%s'", timestamp_str)
            return None

    def get_trace(self, trace_id: str) -> Optional[Trace]:
        """Retrieve a trace by its ID."""
        session = self.get_session()
        try:
            return (
                session.query(Trace)
                .options(selectinload(Trace.spans))
                .filter(Trace.id == trace_id)
                .first()
            )
        finally:
            session.close()

    def get_traces_by_start_time(self, limit: int) -> list[Trace]:
        """Retrieve traces based on the start time of its first span."""
        session = self.get_session()
        try:
            return (
                session.query(Trace)
                .options(joinedload(Trace.spans))
                .join(Trace.spans)
                .filter(Span.parent_id == None)
                .order_by(Span.start_time.desc())
                .limit(limit)
                .all()
            )
        finally:
            session.close()

    def get_full_trace(self, trace_id: str) -> Optional[Dict[str, Any]]:
        """Return a full OTLP trace with spans ordered by start_time."""
        trace = self.get_trace(trace_id)
        if not trace:
            return None

        spans = list(trace.spans or [])
        spans.sort(key=lambda span: (span.start_time or datetime.min, span.id))

        trace_attributes: Dict[str, Any] = {}
        if isinstance(trace.attributes, dict):
            trace_attributes.update(trace.attributes)
        if trace.system_prompt:
            trace_attributes["system_prompt"] = trace.system_prompt
        if trace.episode_id:
            trace_attributes["tracebrain.episode.id"] = trace.episode_id
        if trace.status:
            trace_attributes["tracebrain.trace.status"] = (
                trace.status.value if hasattr(trace.status, "value") else str(trace.status)
            )
        if trace.priority is not None:
            trace_attributes["tracebrain.trace.priority"] = trace.priority
        if trace.ai_evaluation is not None:
            trace_attributes["tracebrain.ai_evaluation"] = trace.ai_evaluation

        span_payloads = []
        for span in spans:
            span_payloads.append(
                {
                    "span_id": span.span_id,
                    "parent_id": span.parent_id,
                    "name": span.name,
                    "start_time": span.start_time.isoformat() if span.start_time else None,
                    "end_time": span.end_time.isoformat() if span.end_time else None,
                    "attributes": span.attributes or {},
                }
            )

        return {
            "trace_id": trace.id,
            "attributes": trace_attributes,
            "spans": span_payloads,
        }

    def list_traces(
        self,
        limit: int = 100,
        skip: int = 0,
        query: Optional[str] = None,
        include_spans: bool = False,
        status: Optional[str] = None,
        min_rating: Optional[int] = None,
        error_type: Optional[str] = None,
        min_confidence: Optional[float] = None,
        max_confidence: Optional[float] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ) -> List[Trace]:
        """List traces in the database with pagination and optional filters."""
        session = self.get_session()
        try:
            q = self._build_traces_query(
                session=session,
                query=query,
                status=status,
                min_rating=min_rating,
                error_type=error_type,
                min_confidence=min_confidence,
                max_confidence=max_confidence,
                start_time=start_time,
                end_time=end_time,
            )

            if not self.is_sqlite:
                q = q.offset(skip).limit(limit)
                if include_spans:
                    q = q.options(selectinload(Trace.spans))
                return q.all()

            if include_spans:
                q = q.options(selectinload(Trace.spans))
            traces = q.all()
            return traces[skip: skip + limit]
        finally:
            session.close()

    def iter_traces_filtered(
        self,
        query: Optional[str] = None,
        status: Optional[str] = None,
        min_rating: Optional[int] = None,
        error_type: Optional[str] = None,
        min_confidence: Optional[float] = None,
        max_confidence: Optional[float] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: Optional[int] = None,
        batch_size: int = 500,
    ):
        """Yield traces matching filters without loading all rows into memory."""
        session = self.get_session()
        try:
            q = self._build_traces_query(
                session=session,
                query=query,
                status=status,
                min_rating=min_rating,
                error_type=error_type,
                min_confidence=min_confidence,
                max_confidence=max_confidence,
                start_time=start_time,
                end_time=end_time,
            )
            q = q.yield_per(batch_size)

            count = 0
            for trace in q:
                yield trace
                count += 1
                if limit is not None and count >= limit:
                    break
        finally:
            session.close()

    def count_traces_filtered(
        self,
        query: Optional[str] = None,
        status: Optional[str] = None,
        min_rating: Optional[int] = None,
        error_type: Optional[str] = None,
        min_confidence: Optional[float] = None,
        max_confidence: Optional[float] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ) -> int:
        """Return trace count for the given filters."""
        session = self.get_session()
        try:
            q = self._build_traces_query(
                session=session,
                query=query,
                status=status,
                min_rating=min_rating,
                error_type=error_type,
                min_confidence=min_confidence,
                max_confidence=max_confidence,
                start_time=start_time,
                end_time=end_time,
            )

            if not self.is_sqlite:
                return int(q.count())

            return len(q.all())
        finally:
            session.close()

    def _build_traces_query(
        self,
        session: Session,
        query: Optional[str],
        status: Optional[str],
        min_rating: Optional[int],
        error_type: Optional[str],
        min_confidence: Optional[float],
        max_confidence: Optional[float],
        start_time: Optional[datetime],
        end_time: Optional[datetime],
    ):
        root_span_times = (
            session.query(
                Span.trace_id.label("trace_id"),
                func.min(Span.start_time).label("root_start_time"),
            )
            .filter(Span.parent_id.is_(None))
            .group_by(Span.trace_id)
            .subquery()
        )

        event_time = func.coalesce(root_span_times.c.root_start_time, Trace.created_at)

        q = (
            session.query(Trace)
            .outerjoin(root_span_times, root_span_times.c.trace_id == Trace.id)
        )
        if query:
            q = q.filter(Trace.id.ilike(f"%{query}%"))
        if status:
            q = q.filter(Trace.status == status)
        if start_time:
            q = q.filter(event_time >= start_time)
        if end_time:
            q = q.filter(event_time <= end_time)

        if not self.is_sqlite:
            if min_rating is not None:
                human_rating = cast(Trace.feedback, JSONB)["rating"].astext.cast(Integer)
                ai_rating = cast(Trace.ai_evaluation, JSONB)["rating"].astext.cast(Integer)
                rating_value = func.coalesce(human_rating, ai_rating)
                q = q.filter(rating_value >= min_rating)
            if error_type:
                error_value = cast(Trace.ai_evaluation, JSONB)["error_type"].astext
                q = q.filter(error_value == error_type)
            if min_confidence is not None or max_confidence is not None:
                conf_value = cast(Trace.ai_evaluation, JSONB)["confidence"].astext.cast(Float)
                if min_confidence is not None:
                    q = q.filter(conf_value >= min_confidence)
                if max_confidence is not None:
                    q = q.filter(conf_value <= max_confidence)
            return q.order_by(event_time.desc())

        traces = q.all()
        if min_rating is None and error_type is None and min_confidence is None and max_confidence is None:
            return (
                session.query(Trace)
                .outerjoin(root_span_times, root_span_times.c.trace_id == Trace.id)
                .filter(Trace.id.in_([t.id for t in traces]))
                .order_by(event_time.desc())
            )

        filtered_ids: List[str] = []
        for trace in traces:
            ai_eval = None
            if trace.attributes and isinstance(trace.attributes, dict):
                ai_eval = trace.attributes.get("tracebrain.ai_evaluation")

            eval_error_type = None
            eval_confidence = None
            if isinstance(ai_eval, dict):
                eval_error_type = ai_eval.get("error_type")
                eval_confidence = ai_eval.get("confidence")

            if min_rating is not None:
                human_rating = None
                if trace.feedback and isinstance(trace.feedback, dict):
                    human_rating = trace.feedback.get("rating")
                ai_rating = ai_eval.get("rating") if isinstance(ai_eval, dict) else None
                rating_value = human_rating if human_rating is not None else ai_rating

                if not isinstance(rating_value, int) or rating_value < min_rating:
                    continue
            if error_type is not None:
                if eval_error_type != error_type:
                    continue
            if min_confidence is not None:
                if not isinstance(eval_confidence, (int, float)) or eval_confidence < min_confidence:
                    continue
            if max_confidence is not None:
                if not isinstance(eval_confidence, (int, float)) or eval_confidence > max_confidence:
                    continue

            filtered_ids.append(trace.id)

        if not filtered_ids:
            return session.query(Trace).filter(text("1=0"))

        return (
            session.query(Trace)
            .outerjoin(root_span_times, root_span_times.c.trace_id == Trace.id)
            .filter(Trace.id.in_(filtered_ids))
            .order_by(event_time.desc())
        )

    def get_traces_by_ids(self, trace_ids: List[str], include_spans: bool = False) -> List[Trace]:
        """Get traces by a list of trace IDs."""        
        session = self.get_session()
        try:
            query = session.query(Trace).filter(Trace.id.in_(trace_ids))
            if include_spans:
                query = query.options(selectinload(Trace.spans))
            return query.order_by(Trace.created_at.asc()).all()
        finally:
            session.close()

    def get_traces_by_episode_id(self, episode_id: str) -> List[Trace]:
        """Get all traces for a specific episode ID."""
        session = self.get_session()
        try:
            return (
                session.query(Trace)
                .options(selectinload(Trace.spans))
                .filter(Trace.episode_id == episode_id)
                .order_by(Trace.created_at.asc())
                .all()
            )
        finally:
            session.close()

    def execute_read_only_sql(self, query: str, row_limit: int = 100) -> Dict[str, Any]:
        """Execute a read-only SQL query with defense-in-depth controls."""
        try:
            parsed = sqlparse.parse(query)
            if not parsed or parsed[0].get_type() != "SELECT":
                raise ValueError("Only SELECT statements are permitted.")
        except Exception as e:
            return {"error": f"SQL Parsing Error: {str(e)}"}

        try:
            with self.get_session() as session:
                if self.engine.dialect.name == "postgresql":
                    session.execute(text("SET LOCAL statement_timeout = 5000;"))
                    session.execute(text("SET LOCAL TRANSACTION READ ONLY;"))

                result = session.execute(text(query))
                column_names = list(result.keys())
                rows = [
                    dict(zip(column_names, row))
                    for row in result.fetchmany(row_limit)
                ]
                return {"rows": rows, "count": len(rows)}

        except TimeoutError:
            return {
                "error": "SQL Execution Error: The query took too long to execute and was timed out. Please write a more efficient query."
            }
        except ProgrammingError as e:
            return {"error": f"SQL Execution Error: {str(e)}"}
        except Exception as e:
            logger.error("Unexpected error in execute_read_only_sql: %s", e, exc_info=True)
            return {"error": "An unexpected internal error occurred."}

    def get_chat_history(self, session_id: str) -> List[Dict[str, Any]]:
        """Return all messages for a session ordered by created_at."""
        session = self.get_session()
        try:
            messages = (
                session.query(ChatMessage)
                .filter(ChatMessage.session_id == session_id)
                .order_by(ChatMessage.created_at.asc())
                .all()
            )
            results = []
            for message in messages:
                content = message.content
                if isinstance(content, str):
                    try:
                        content = json.loads(content)
                    except (json.JSONDecodeError, TypeError):
                        content = {"answer": content}
                elif not isinstance(content, dict):
                    content = {"answer": str(content)}
                results.append(
                    {
                        "role": message.role,
                        "content": content,
                        "created_at": message.created_at,
                    }
                )
            return results
        finally:
            session.close()

    def save_chat_message(
        self,
        session_id: str,
        role: str,
        content: Union[str, Dict[str, Any]],
    ) -> None:
        """Save a new chat message, creating the session if needed."""
        session = self.get_session()
        try:
            chat_session = session.query(ChatSession).filter(ChatSession.id == session_id).first()
            if not chat_session:
                chat_session = ChatSession(id=session_id)
                session.add(chat_session)

            payload: Dict[str, Any]
            if isinstance(content, dict):
                payload = content
            elif role == "user":
                payload = {"answer": str(content)}
            else:
                payload = {"answer": str(content)}

            message = ChatMessage(
                session_id=session_id,
                role=role,
                content=payload,
            )
            session.add(message)
            session.commit()
        except Exception:
            session.rollback()
            logger.exception("Failed to save chat message")
            raise
        finally:
            session.close()

    def count_traces(self) -> int:
        """Return total trace count."""
        session = self.get_session()
        try:
            return int(session.query(func.count(Trace.id)).scalar() or 0)
        finally:
            session.close()

    def cleanup_traces(
        self,
        older_than_hours: Optional[int] = None,
        status: Optional[str] = None,
    ) -> int:
        """Delete traces matching cleanup filters and return count."""
        session = self.get_session()
        try:
            q = session.query(Trace)
            if older_than_hours is not None:
                cutoff = datetime.utcnow() - timedelta(hours=older_than_hours)
                q = q.filter(Trace.created_at <= cutoff)
            if status:
                q = q.filter(Trace.status == status)

            # History table cleanup
            traces_to_delete = q.all()
            trace_ids = [t.id for t in traces_to_delete]
            episode_ids = list({t.episode_id for t in traces_to_delete if t.episode_id})

            deleted = len(trace_ids)
            if deleted:
                session.query(History).filter(History.id.in_(trace_ids)).delete(synchronize_session=False)
                if episode_ids:
                    session.query(History).filter(History.id.in_(episode_ids)).delete(synchronize_session=False)
                q.delete(synchronize_session=False)
                session.commit()
            return int(deleted)
        except Exception:
            session.rollback()
            logger.exception("Failed to cleanup traces")
            raise
        finally:
            session.close()

    def delete_trace(self, trace_id: str) -> None:
        """Delete a single trace and its history entry."""
        session = self.get_session()
        try:
            session.query(History).filter(History.id == trace_id).delete(synchronize_session=False)
            session.query(Trace).filter(Trace.id == trace_id).delete(synchronize_session=False)
            session.commit()
        except Exception:
            session.rollback()
            logger.exception("Failed to delete trace")
            raise
        finally:
            session.close()

    def delete_episode(self, episode_id: str) -> None:
        """Delete all traces in an episode and their history entries."""
        session = self.get_session()
        try:
            traces = session.query(Trace).filter(Trace.episode_id == episode_id).all()
            trace_ids = [t.id for t in traces]
            if trace_ids:
                session.query(History).filter(History.id.in_(trace_ids)).delete(synchronize_session=False)
            session.query(History).filter(History.id == episode_id).delete(synchronize_session=False)
            session.query(Trace).filter(Trace.episode_id == episode_id).delete(synchronize_session=False)
            session.commit()
        except Exception:
            session.rollback()
            logger.exception("Failed to delete episode")
            raise
        finally:
            session.close()

    def add_feedback(self, trace_id: str, feedback_data: Dict[str, Any]) -> bool:
        """Add or update feedback for a trace."""
        session = self.get_session()
        try:
            trace = session.query(Trace).filter(Trace.id == trace_id).first()
            if not trace:
                raise ValueError(f"Trace not found: {trace_id}")
            
            priority = feedback_data.pop("priority", None)
            if priority is not None:
                trace.priority = priority

            trace.feedback = feedback_data
            trace.status = TraceStatus.completed
            if isinstance(trace.attributes, dict):
                trace.attributes["tracebrain.trace.status"] = TraceStatus.completed.value
            else:
                trace.attributes = {"tracebrain.trace.status": TraceStatus.completed.value}
            session.commit()
            logger.info("Added feedback to trace %s", trace_id)
            return True
        except Exception:
            session.rollback()
            logger.exception("Failed to add feedback")
            raise
        finally:
            session.close()

    def _default_llm_settings(self) -> Dict[str, Any]:
        librarian_provider = (
            os.getenv("DEFAULT_LIBRARIAN_PROVIDER")
            or "gemini"
        )
        librarian_model = (
            os.getenv("DEFAULT_LIBRARIAN_MODEL")
            or "gemini-2.5-flash"
        )

        judge_provider = os.getenv("DEFAULT_JUDGE_PROVIDER") or librarian_provider
        judge_model = os.getenv("DEFAULT_JUDGE_MODEL") or librarian_model

        curator_provider = os.getenv("DEFAULT_CURATOR_PROVIDER") or librarian_provider
        curator_model = os.getenv("DEFAULT_CURATOR_MODEL") or librarian_model

        defaults: Dict[str, Any] = {
            "librarian_provider": str(librarian_provider).strip().lower() or "gemini",
            "librarian_model": str(librarian_model).strip() or "gemini-2.5-flash",
            "judge_provider": str(judge_provider).strip().lower() or "gemini",
            "judge_model": str(judge_model).strip() or "gemini-2.5-flash",
            "curator_provider": str(curator_provider).strip().lower() or "gemini",
            "curator_model": str(curator_model).strip() or "gemini-2.5-flash",
        }
        for field_name, env_var in _API_KEY_FIELD_TO_ENV.items():
            defaults[field_name] = (os.getenv(env_var) or "").strip() or None
        return defaults

    def _mask_api_key(self, value: Optional[str]) -> Optional[str]:
        secret = str(value or "").strip()
        if not secret:
            return None
        if len(secret) <= 8:
            return "*" * len(secret)
        return f"{secret[:3]}...{secret[-4:]}"

    def _looks_masked_key(self, value: Optional[str]) -> bool:
        text = str(value or "").strip()
        if not text:
            return False
        if "..." in text and len(text) <= 32:
            return True
        if len(text) >= 4 and all(ch == "*" for ch in text):
            return True
        return False

    def _merge_api_key(
        self,
        incoming_value: Any,
        current_db_value: Optional[str],
    ) -> Optional[str]:
        current = str(current_db_value or "").strip() or None
        if incoming_value is None:
            return current

        candidate = str(incoming_value).strip()
        if not candidate:
            return current
        if self._looks_masked_key(candidate):
            return current
        return candidate

    def _sanitize_provider(self, value: Any) -> str:
        provider = str(value or "").strip().lower()
        if provider not in _ALLOWED_SETTINGS_PROVIDERS:
            raise ValueError(
                "Provider must be one of: openai, gemini, anthropic, huggingface"
            )
        return provider

    def get_settings(self, mask_api_keys: bool = False) -> Dict[str, Any]:
        """Return LLM routing settings with env fallback when DB row is missing."""
        defaults = self._default_llm_settings()
        session = self.get_session()
        try:
            settings_row = session.query(DBSettings).filter(DBSettings.id == 1).first()
            if not settings_row:
                result = dict(defaults)
                if mask_api_keys:
                    for field_name in _API_KEY_FIELD_TO_ENV:
                        result[field_name] = self._mask_api_key(result.get(field_name))
                return result

            librarian_provider = (settings_row.librarian_provider or "").strip().lower()
            librarian_model = (settings_row.librarian_model or "").strip()
            judge_provider = (settings_row.judge_provider or "").strip().lower()
            judge_model = (settings_row.judge_model or "").strip()
            curator_provider = (getattr(settings_row, "curator_provider", "") or "").strip().lower()
            curator_model = (getattr(settings_row, "curator_model", "") or "").strip()

            result = {
                "librarian_provider": librarian_provider or defaults["librarian_provider"],
                "librarian_model": librarian_model or defaults["librarian_model"],
                "judge_provider": judge_provider or defaults["judge_provider"],
                "judge_model": judge_model or defaults["judge_model"],
                "curator_provider": curator_provider or defaults["curator_provider"],
                "curator_model": curator_model or defaults["curator_model"],
            }

            for field_name in _API_KEY_FIELD_TO_ENV:
                db_secret = (getattr(settings_row, field_name, None) or "").strip() or None
                result[field_name] = db_secret or defaults.get(field_name)

            if mask_api_keys:
                for field_name in _API_KEY_FIELD_TO_ENV:
                    result[field_name] = self._mask_api_key(result.get(field_name))

            return result
        finally:
            session.close()

    def get_librarian_model_name(self) -> str:
        """Return the current Librarian model name from persisted settings with env fallback."""
        settings_payload = self.get_settings(mask_api_keys=False)
        model_name = str(settings_payload.get("librarian_model") or "").strip()
        return model_name or settings.LLM_MODEL

    def save_settings(self, new_settings: Dict[str, Any], mask_api_keys: bool = False) -> Dict[str, Any]:
        """Upsert singleton LLM settings and return the normalized payload."""
        payload = new_settings if isinstance(new_settings, dict) else {}
        defaults = self._default_llm_settings()

        session = self.get_session()
        try:
            settings_row = session.query(DBSettings).filter(DBSettings.id == 1).first()
            current = defaults if not settings_row else {
                "librarian_provider": (settings_row.librarian_provider or defaults["librarian_provider"]),
                "librarian_model": (settings_row.librarian_model or defaults["librarian_model"]),
                "judge_provider": (settings_row.judge_provider or defaults["judge_provider"]),
                "judge_model": (settings_row.judge_model or defaults["judge_model"]),
                "curator_provider": (getattr(settings_row, "curator_provider", None) or defaults["curator_provider"]),
                "curator_model": (getattr(settings_row, "curator_model", None) or defaults["curator_model"]),
            }

            librarian_provider = self._sanitize_provider(
                payload.get("librarian_provider", current["librarian_provider"])
            )
            judge_provider = self._sanitize_provider(
                payload.get("judge_provider", current["judge_provider"])
            )
            curator_provider = self._sanitize_provider(
                payload.get("curator_provider", current["curator_provider"])
            )

            librarian_model = str(
                payload.get("librarian_model", current["librarian_model"])
            ).strip()
            judge_model = str(payload.get("judge_model", current["judge_model"])).strip()
            curator_model = str(payload.get("curator_model", current["curator_model"])).strip()

            if not librarian_model:
                raise ValueError("librarian_model is required")
            if not judge_model:
                raise ValueError("judge_model is required")
            if not curator_model:
                raise ValueError("curator_model is required")

            if not settings_row:
                settings_row = DBSettings(
                    id=1,
                    librarian_provider=librarian_provider,
                    librarian_model=librarian_model,
                    judge_provider=judge_provider,
                    judge_model=judge_model,
                    curator_provider=curator_provider,
                    curator_model=curator_model,
                )
                session.add(settings_row)
            else:
                settings_row.librarian_provider = librarian_provider
                settings_row.librarian_model = librarian_model
                settings_row.judge_provider = judge_provider
                settings_row.judge_model = judge_model
                settings_row.curator_provider = curator_provider
                settings_row.curator_model = curator_model

            for field_name in _API_KEY_FIELD_TO_ENV:
                current_db_value = getattr(settings_row, field_name, None)
                merged_value = self._merge_api_key(
                    payload.get(field_name),
                    current_db_value,
                )
                setattr(settings_row, field_name, merged_value)

            session.commit()
            return self.get_settings(mask_api_keys=mask_api_keys)
        except Exception:
            session.rollback()
            logger.exception("Failed to save settings")
            raise
        finally:
            session.close()

    def update_settings(self, new_settings: Dict[str, Any]) -> Dict[str, Any]:
        """Backward-compatible alias for previous settings API."""
        return self.save_settings(new_settings)

    def update_ai_evaluation(self, trace_id: str, ai_evaluation: Dict[str, Any]) -> None:
        """Update AI evaluation metadata for a trace."""
        session = self.get_session()
        try:
            trace = session.query(Trace).filter(Trace.id == trace_id).first()
            if not trace:
                raise ValueError(f"Trace with ID '{trace_id}' not found")
            trace.ai_evaluation = dict(ai_evaluation)
            updated_attributes = dict(trace.attributes or {})
            updated_attributes["tracebrain.ai_evaluation"] = dict(ai_evaluation)
            trace.attributes = updated_attributes
            session.commit()
        except Exception:
            session.rollback()
            logger.exception("Failed to update AI evaluation")
            raise
        finally:
            session.close()

    def update_trace_status(self, trace_id: str, status: TraceStatus) -> None:
        """Update the status for a trace."""
        session = self.get_session()
        try:
            updated = (
                session.query(Trace)
                .filter(Trace.id == trace_id)
                .update({"status": status})
            )
            if updated == 0:
                raise ValueError(f"Trace with ID '{trace_id}' not found")
            session.commit()
        except Exception:
            session.rollback()
            logger.exception("Failed to update trace status")
            raise
        finally:
            session.close()

    def get_pending_curriculum(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Return pending curriculum tasks ordered by priority and recency."""
        session = self.get_session()
        try:
            priority_order = case(
                (CurriculumTask.priority == "high", 3),
                (CurriculumTask.priority == "medium", 2),
                (CurriculumTask.priority == "low", 1),
                else_=0,
            )
            tasks = (
                session.query(CurriculumTask)
                .filter(CurriculumTask.status == "pending")
                .order_by(priority_order.desc(), CurriculumTask.created_at.desc())
                .limit(limit)
                .all()
            )

            return [
                {
                    "id": task.id,
                    "instruction": task.task_description,
                    "context": task.reasoning,
                    "priority": task.priority,
                    "created_at": task.created_at.isoformat(),
                }
                for task in tasks
            ]
        finally:
            session.close()
        
    def delete_curriculum_task(self, task_id: int) -> bool:
        """Delete a single curriculum task by ID. Returns False if not found."""
        session = self.get_session()
        try:
            task = session.query(CurriculumTask).filter(CurriculumTask.id == task_id).first()
            if not task:
                return False
            session.delete(task)
            session.commit()
            return True
        finally:
            session.close()

    def delete_all_curriculum_tasks(self) -> None:
        """Delete all curriculum tasks."""
        session = self.get_session()
        try:
            session.query(CurriculumTask).delete()
            session.commit()
        finally:
            session.close()

    def mark_curriculum_task_complete(self, task_id: int) -> Optional[CurriculumTask]:
        """Mark a single curriculum task as complete. Returns None if not found."""
        session = self.get_session()
        try:
            task = session.query(CurriculumTask).filter(CurriculumTask.id == task_id).first()
            if not task:
                return None
            task.status = "completed"
            session.commit()
            session.refresh(task)
            return task
        finally:
            session.close()

    def mark_all_curriculum_tasks_complete(self) -> None:
        """Mark all curriculum tasks as complete."""
        session = self.get_session()
        try:
            session.query(CurriculumTask).update({CurriculumTask.status: "completed"})
            session.commit()
        finally:
            session.close()

    def get_stats(self) -> Dict[str, Any]:
        """Get overall statistics about the TraceStore."""
        from datetime import timedelta

        session = self.get_session()
        try:
            total_traces = session.query(func.count(Trace.id)).scalar() or 0
            total_spans = session.query(func.count(Span.id)).scalar() or 0
            if self.engine.dialect.name == "postgresql":
                rating_value = func.jsonb_extract_path_text(
                    cast(Trace.feedback, JSONB),
                    "rating",
                )
                traces_with_feedback = (
                    session.query(func.count(Trace.id))
                    .filter(Trace.feedback.isnot(None))
                    .filter(rating_value.isnot(None))
                    .scalar()
                    or 0
                )
            else:
                traces_with_feedback = (
                    session.query(func.count(Trace.id))
                    .filter(Trace.feedback.isnot(None))
                    .filter(Trace.feedback != {})
                    .scalar()
                    or 0
                )

            yesterday = datetime.utcnow() - timedelta(days=1)
            traces_last_24h = (
                session.query(func.count(Trace.id))
                .filter(Trace.created_at >= yesterday)
                .scalar()
                or 0
            )

            avg_spans = total_spans / total_traces if total_traces > 0 else 0

            return {
                "total_traces": int(total_traces),
                "total_spans": int(total_spans),
                "traces_with_feedback": int(traces_with_feedback),
                "traces_last_24h": int(traces_last_24h),
                "avg_spans_per_trace": round(avg_spans, 2)
            }
        finally:
            session.close()

    def get_tool_usage_stats(self, limit: int = 10) -> Dict[str, Any]:
        """Get tool usage statistics from all traces."""
        session = self.get_session()
        try:
            if self.engine.dialect.name == "postgresql":
                span_type = func.jsonb_extract_path_text(Span.attributes, "tracebrain.span.type")
                tool_name = func.jsonb_extract_path_text(Span.attributes, "tracebrain.tool.name")
                rows = (
                    session.query(tool_name.label("tool"), func.count().label("count"))
                    .filter(span_type == "tool_execution")
                    .filter(tool_name.isnot(None))
                    .group_by(tool_name)
                    .order_by(func.count().desc())
                    .limit(limit)
                    .all()
                )
                tools = [{"tool": row.tool, "count": int(row.count)} for row in rows]
                total_tool_calls = sum(item["count"] for item in tools)
                return {"tools": tools, "total_tool_calls": total_tool_calls}

            spans = session.query(Span.attributes).all()
            tool_counts: Dict[str, int] = {}
            for (attrs,) in spans:
                attrs = attrs or {}
                if attrs.get("tracebrain.span.type") != "tool_execution":
                    continue
                tool = attrs.get("tracebrain.tool.name")
                if not tool:
                    continue
                tool_counts[tool] = tool_counts.get(tool, 0) + 1

            tools = [
                {"tool": tool, "count": count}
                for tool, count in sorted(tool_counts.items(), key=lambda x: x[1], reverse=True)[:limit]
            ]
            return {"tools": tools, "total_tool_calls": sum(tool_counts.values())}
        finally:
            session.close()

    def add_history(self, id: str, type: str) -> None:
        """Add an entry for a trace/episode to users history."""
        session = self.get_session()
        try:
            if type == "trace":
                exists = session.query(Trace).filter(Trace.id == id).first()
            elif type == "episode":
                exists = session.query(Trace).filter(Trace.episode_id == id).first()
            else:
                return

            if not exists:
                return

            existing = session.query(History).filter(History.id == id).first()
            
            if existing:
                existing.last_accessed = datetime.utcnow()
            else:
                history_entry = History(
                    id=id,
                    type=type,
                    last_accessed=datetime.utcnow()
                )
                session.add(history_entry)
            
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def get_history(
        self, 
        type_filter: str,
        limit: int = 10, 
        offset: int = 0,
        query: Optional[str] = None,
    ) -> tuple[List[History], int]:
        """Return trace/episode entries within history."""
        session = self.get_session()
        try:
            q = session.query(History).filter(History.type == type_filter)
            
            if query:
                q = q.filter(History.id.ilike(f"%{query}%"))
            
            total = q.count()
            items = q.order_by(History.last_accessed.desc()).limit(limit).offset(offset).all()
            
            return items, total
        finally:
            session.close()

    def clear_history(self) -> int:
        """Empty the complete trace/episode entries history."""
        session = self.get_session()
        try:
            count = session.query(History).delete()
            session.commit()
            return count
        finally:
            session.close()

    def list_episodes(
        self,
        skip: int = 0,
        limit: int = 10,
        query: Optional[str] = None,
        include_spans: bool = False,
        min_confidence_lt: Optional[float] = None,
    ):
        """List episodes ordered by creation time with their traces."""
        session = self.get_session()
        try:
            if not self.is_sqlite:
                conf_value = (
                    Trace.attributes["tracebrain.ai_evaluation"]["confidence"].astext
                    .cast(Float)
                )

            q = (
                session.query(
                    Trace.episode_id.label("id"),
                    func.min(Trace.created_at).label("created_at"),
                )
                .filter(Trace.episode_id.isnot(None))
                .filter(Trace.episode_id.ilike(f"%{query}%") if query else True)
                .group_by(Trace.episode_id)
            )

            if not self.is_sqlite and min_confidence_lt is not None:
                q = q.having(func.min(conf_value) < min_confidence_lt)

            if not self.is_sqlite:
                total = q.count()
                episodes = (
                    q.order_by(text("created_at desc"))
                    .offset(skip)
                    .limit(limit)
                    .all()
                )
                result = []
                for episode in episodes:
                    trace_query = (
                        session.query(Trace)
                        .filter(Trace.episode_id == episode.id)
                        .order_by(Trace.created_at.asc())
                    )
                    if include_spans:
                        trace_query = trace_query.options(selectinload(Trace.spans))
                    result.append((episode.id, trace_query.all()))
                return result, total

            episodes = q.order_by(text("created_at desc")).all()

            result = []
            for episode in episodes:
                trace_query = (
                    session.query(Trace)
                    .filter(Trace.episode_id == episode.id)
                    .order_by(Trace.created_at.asc())
                )
                if include_spans:
                    trace_query = trace_query.options(selectinload(Trace.spans))
                result.append((episode.id, trace_query.all()))

            if min_confidence_lt is not None:
                filtered = []
                for episode_id, traces in result:
                    min_conf = None
                    for trace in traces:
                        ai_eval = None
                        if isinstance(trace.attributes, dict):
                            ai_eval = trace.attributes.get("tracebrain.ai_evaluation")
                        if isinstance(ai_eval, dict):
                            conf = ai_eval.get("confidence")
                            if isinstance(conf, (int, float)):
                                if min_conf is None or conf < min_conf:
                                    min_conf = float(conf)
                    if min_conf is not None and min_conf < min_confidence_lt:
                        filtered.append((episode_id, traces))
                result = filtered

            total = len(result)
            return result[skip: skip + limit], total
        finally:
            session.close()

    def list_episode_summaries(
        self,
        skip: int = 0,
        limit: int = 10,
        query: Optional[str] = None,
        min_confidence_lt: Optional[float] = None,
    ):
        """List episodes with aggregated metrics (start_time, trace_count, min_confidence)."""
        session = self.get_session()
        try:
            if not self.is_sqlite:
                conf_value = (
                    Trace.attributes["tracebrain.ai_evaluation"]["confidence"].astext
                    .cast(Float)
                )
                base_query = (
                    session.query(
                        Trace.episode_id.label("episode_id"),
                        func.min(Trace.created_at).label("start_time"),
                        func.count(Trace.id).label("trace_count"),
                        func.min(conf_value).label("min_confidence"),
                    )
                    .filter(Trace.episode_id.isnot(None))
                    .group_by(Trace.episode_id)
                )
                if query:
                    base_query = base_query.filter(Trace.episode_id.ilike(f"%{query}%"))
                if min_confidence_lt is not None:
                    base_query = base_query.having(func.min(conf_value) < min_confidence_lt)

                total = base_query.count()

                rows = (
                    base_query
                    .order_by(func.min(Trace.created_at).desc())
                    .offset(skip)
                    .limit(limit)
                    .all()
                )

                episodes = [
                    {
                        "episode_id": row.episode_id,
                        "start_time": row.start_time,
                        "trace_count": int(row.trace_count or 0),
                        "min_confidence": (float(row.min_confidence)
                                           if row.min_confidence is not None else None),
                    }
                    for row in rows
                ]
                return episodes, total

            traces_query = session.query(Trace).filter(Trace.episode_id.isnot(None))
            if query:
                traces_query = traces_query.filter(Trace.episode_id.ilike(f"%{query}%"))
            traces = traces_query.all()

            episodes_map: Dict[str, Dict[str, Any]] = {}
            for trace in traces:
                episode_id = trace.episode_id
                if not episode_id:
                    continue
                entry = episodes_map.get(episode_id)
                if not entry:
                    entry = {
                        "episode_id": episode_id,
                        "start_time": trace.created_at,
                        "trace_count": 0,
                        "min_confidence": None,
                    }
                    episodes_map[episode_id] = entry

                entry["trace_count"] += 1
                if trace.created_at and trace.created_at < entry["start_time"]:
                    entry["start_time"] = trace.created_at

                ai_eval = None
                if isinstance(trace.attributes, dict):
                    ai_eval = trace.attributes.get("tracebrain.ai_evaluation")
                if isinstance(ai_eval, dict):
                    conf = ai_eval.get("confidence")
                    if isinstance(conf, (int, float)):
                        if entry["min_confidence"] is None or conf < entry["min_confidence"]:
                            entry["min_confidence"] = float(conf)

            episodes = list(episodes_map.values())
            if min_confidence_lt is not None:
                episodes = [
                    ep
                    for ep in episodes
                    if ep["min_confidence"] is not None
                    and ep["min_confidence"] < min_confidence_lt
                ]

            episodes.sort(key=lambda item: item["start_time"], reverse=True)
            total = len(episodes)
            return episodes[skip: skip + limit], total
        finally:
            session.close()

class SQLiteBackend(BaseStorageBackend):
    """SQLite storage backend for development and testing."""

    def __init__(self, db_url: str = "sqlite:///tracestore.db"):
        super().__init__(db_url)
        logger.info("SQLite backend initialized: %s", db_url)


class PostgresBackend(BaseStorageBackend):
    """PostgreSQL storage backend for production."""

    def __init__(self, db_url: str):
        if not db_url:
            raise ValueError("db_url is required for PostgreSQL backend")
        super().__init__(db_url)
        logger.info("PostgreSQL backend initialized")


class TraceStore:
    """Factory class for creating trace storage backends."""

    def __new__(cls, backend: str = "sqlite", db_url: Optional[str] = None):
        backend = backend.lower()
        if backend == "sqlite":
            db_url = db_url or "sqlite:///tracestore.db"
            return SQLiteBackend(db_url=db_url)

        if backend in {"postgres", "postgresql"}:
            if not db_url:
                raise ValueError(
                    "db_url is required for PostgreSQL backend. "
                    "Example: 'postgresql://user:password@localhost/tracestore'"
                )
            return PostgresBackend(db_url=db_url)

        raise ValueError(
            f"Unknown backend: {backend}. Supported backends: 'sqlite', 'postgres'"
        )
