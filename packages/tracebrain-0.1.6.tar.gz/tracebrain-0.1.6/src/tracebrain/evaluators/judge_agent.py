"""AI judge logic for evaluating traces with prior episode context."""

from __future__ import annotations

import json
import logging
import re
from typing import Optional

from tracebrain.core.llm_providers import ProviderError, get_llm_provider

logger = logging.getLogger(__name__)


class AIJudge:
    """Evaluate traces using a judge LLM with prior episode feedback."""

    VALID_ERROR_TYPES = {
        "logic_loop",
        "hallucination",
        "invalid_tool_usage",
        "tool_execution_error",
        "format_error",
        "misinterpretation",
        "context_overflow",
        "none",
    }

    def __init__(self, store):
        self.store = store

    def _format_trace_summary(self, trace) -> str:
        """Create a concise summary of a trace for LLM consumption."""
        lines = [
            f"Trace ID: {trace.id}",
            f"System Prompt: {trace.system_prompt or 'N/A'}",
        ]

        for span in trace.spans or []:
            attrs = span.attributes or {}
            span_type = attrs.get("tracebrain.span.type", "unknown")
            thought = attrs.get("tracebrain.llm.thought")
            action = attrs.get("tracebrain.llm.tool_code")
            completion = attrs.get("tracebrain.llm.completion")
            final_answer = attrs.get("tracebrain.llm.final_answer")
            tool_name = attrs.get("tracebrain.tool.name")
            tool_input = attrs.get("tracebrain.tool.input")
            observation = attrs.get("tracebrain.tool.output")

            if isinstance(observation, (dict, list)):
                observation = json.dumps(observation)
            if observation:
                observation = str(observation)[:2000]

            reasoning = thought or (completion if not action else None)

            lines.append(
                "Span: "
                f"type={span_type}, "
                f"thought={reasoning or 'N/A'}, "
                f"action={action or 'N/A'}, "
                f"observation={observation or 'N/A'}"
                f"final_answer={final_answer or 'N/A'}"
                f"tool={tool_name or 'N/A'}, "
                f"tool_input={tool_input or 'N/A'}, "
            )

        return "\n".join(lines)

    def _get_prior_experience(self, episode_id: Optional[str], current_trace_id: str) -> str:
        """Gather human feedback signals from previous traces in the same episode."""
        if not episode_id:
            return ""

        traces = self.store.get_traces_by_episode_id(episode_id)
        try:
            traces = sorted(traces, key=lambda item: item.created_at, reverse=True)
        except Exception:
            pass

        examples = []
        for trace in traces:
            if trace.id == current_trace_id:
                continue
            if not trace.feedback:
                continue

            rating = trace.feedback.get("rating")
            comment = trace.feedback.get("comment")
            tags = trace.feedback.get("tags")
            metadata = trace.feedback.get("metadata")
            if rating is None:
                continue

            reason = comment if isinstance(comment, str) else json.dumps(comment) if comment else "No comment"
            tag_text = ", ".join(tags) if isinstance(tags, list) and tags else "None"
            meta_text = ""
            if metadata:
                meta_text = json.dumps(metadata) if not isinstance(metadata, str) else metadata

            examples.append(
                "Trace "
                f"{trace.id} rating={rating}; "
                f"tags=[{tag_text}]; "
                f"reason={reason}; "
                f"metadata={meta_text or 'None'}"
            )

        if not examples:
            return ""

        return "\n".join(examples)

    def _extract_json(self, text: str) -> dict:
        """Parse a JSON object from model output, with fence cleanup."""
        if not text:
            raise ValueError("Empty response from judge model")

        cleaned = text.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```(json)?", "", cleaned, flags=re.IGNORECASE).strip()
            if cleaned.endswith("```"):
                cleaned = cleaned[:-3].strip()

        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
            if not match:
                raise
            return json.loads(match.group(0))

    def evaluate(self, trace_id: str, judge_model_id: Optional[str] = None) -> dict:
        """Evaluate a trace using the judge model."""
        trace = self.store.get_trace(trace_id)
        if not trace:
            raise ValueError(f"Trace not found: {trace_id}")

        runtime_settings = self.store.get_settings()
        judge_provider = runtime_settings.get("judge_provider")
        selected_model = (judge_model_id or runtime_settings.get("judge_model") or "").strip()
        provider_key_field = f"{str(judge_provider or '').strip().lower()}_api_key"
        provider_api_key = runtime_settings.get(provider_key_field)

        has_active_help = False
        for span in trace.spans or []:
            attrs = span.attributes or {}
            tool_name = str(attrs.get("tracebrain.tool.name", ""))
            tool_code = str(attrs.get("tracebrain.llm.tool_code", ""))
            if "request_human_intervention" in tool_name or "request_human_intervention" in tool_code:
                has_active_help = True
                break

        prior = self._get_prior_experience(trace.episode_id, trace_id)
        summary = self._format_trace_summary(trace)

        system_instruction = (
            "You are a critical AI QA Engineer evaluating autonomous agents. "
            "Your primary metric is **Task Goal Completion**."
            "Return only strict JSON with keys: rating (1-5), feedback (string), "
            "confidence (float between 0.0 and 1.0), error_type (string), and priority (1-5).\n\n"
            "When prior human feedback from the same episode is available, align "
            "your evaluation with those preferences.\n\n"
            
            "### SCORING RUBRIC:\n"
            "- 5 (Perfect): Task completed successfully and efficiently.\n"
            "- 3-4 (Good): Task completed but with retries or minor inefficiencies.\n"
            "- 2 (Incomplete/Escalated): The agent FAILED to complete the task but handled the error gracefully (e.g., called for human help). This is better than a crash but NOT a success.\n"
            "- 1 (Failure): The agent crashed, looped indefinitely, or gave a wrong answer.\n\n"
            
            "### CONFIDENCE LOGIC:\n"
            "- High Confidence (>0.8): Clear success or clear failure.\n"
            "- Low Confidence (<0.5): **MANDATORY for cases where the agent calls 'request_human_intervention'**. "
            "Because the agent has admitted uncertainty or encountered a loop it cannot break, the final quality is operationally ambiguous. "
            "In such cases, you MUST set confidence between 0.30 and 0.49 to flag this trace for human review.\n\n"
 
            "### PRIORITY RUBRIC:\n"
            "- 1 (Critical): Hallucinated facts presented as truth, dangerous tool misuse, or corrupted output.\n"
            "- 2 (Major): Task failed or produced a wrong answer due to a clear reasoning or tool error.\n"
            "- 3 (Moderate): Task completed but with recoverable errors or suboptimal reasoning steps.\n"
            "- 4 (Minor): Task completed successfully with negligible inefficiencies.\n"
            "- 5 (Trivial): No errors detected, task completed correctly and efficiently.\n\n"
 
            "### ERROR CLASSIFICATION (MANDATORY):\n"
            "- logic_loop: Repeating same actions/tools without progress.\n"
            "- hallucination: Inventing facts or calling non-existent tools.\n"
            "- invalid_tool_usage: Calling tools with wrong arguments/schema.\n"
            "- tool_execution_error: External API failed (e.g., 500, 429, Timeout) and agent failed to recover.\n"
            "- format_error: Output format violated parsing rules.\n"
            "- misinterpretation: Agent misunderstood the tool output.\n"
            "- context_overflow: Task failed due to token limits.\n"
            "- none: If the task was successful."
        )

        # Add a warning flag if the agent requested human help.
        intervention_flag = "⚠️ AGENT HAS REQUESTED HUMAN HELP IN THIS TRACE." if has_active_help else ""

        user_content = (
            f"{intervention_flag}\n"
            "Current Trace Summary:\n"
            f"{summary}\n\n"
            "Prior Experience:\n"
            f"{prior or 'None'}\n\n"
            "Instruction: Evaluate based on the Mandatory Uncertainty Protocol. Output JSON only."
        )
        
        prompt = f"{system_instruction}\n\n{user_content}"

        logger.debug("AIJudge prompt:\n%s", prompt)

        try:
            provider = get_llm_provider(
                provider_name=judge_provider,
                model_id=selected_model,
                api_key=provider_api_key,
            )
        except (ProviderError, ValueError) as exc:
            logger.error("AIJudge provider error: %s", exc)
            return {
                "rating": 1,
                "feedback": str(exc),
                "confidence": 0.0,
                "error_type": "tool_execution_error",
                "priority": 2,
            }

        try:
            response = provider.send_user_message(
                provider.start_chat(system_instruction, []),
                user_content,
            )
            raw_text = provider.extract_text(response)
        except ProviderError as exc:
            logger.error("AIJudge provider error: %s", exc)
            return {
                "rating": 1,
                "feedback": str(exc),
                "confidence": 0.0,
                "error_type": "tool_execution_error",
                "priority": 2,
            }

        logger.debug("AIJudge raw response: %s", raw_text)

        parsed = self._extract_json(raw_text)
        rating = int(parsed.get("rating"))
        feedback = str(parsed.get("feedback", "")).strip()
        confidence = float(parsed.get("confidence"))
        error_type = str(parsed.get("error_type", "")).strip()
        priority = int(parsed.get("priority"))

        if rating < 1 or rating > 5:
            raise ValueError("Judge rating out of range (1-5)")
        if not feedback:
            raise ValueError("Judge feedback is empty")
        if confidence < 0.0 or confidence > 1.0:
            raise ValueError("Judge confidence out of range (0.0-1.0)")
        if priority < 1 or priority > 5:
            raise ValueError("Judge priority out of range (1-5)")

        if error_type not in self.VALID_ERROR_TYPES:
            error_type = "general_failure"

        return {
            "rating": rating,
            "feedback": feedback,
            "confidence": confidence,
            "error_type": error_type,
            "priority": priority,
        }
