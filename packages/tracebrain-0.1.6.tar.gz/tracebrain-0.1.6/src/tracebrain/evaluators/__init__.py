"""Evaluation utilities for TraceBrain."""
