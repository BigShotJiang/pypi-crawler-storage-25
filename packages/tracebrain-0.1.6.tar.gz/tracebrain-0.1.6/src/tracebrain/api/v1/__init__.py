"""
TraceBrain API v1

This module exports the API v1 router for use in the main application.
"""

from .api_router import router

__all__ = ["router"]
