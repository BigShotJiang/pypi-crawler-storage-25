"""
TraceBrain - Observability Platform for Agentic AI

This package provides a complete observability solution for AI agents,
allowing users to collect, store, and visualize execution traces.

Philosophy: "Pip install and run"
- Single package containing both backend (FastAPI) and frontend (React)
- Support for SQLite (development) and PostgreSQL (production)
- Custom TraceBrain Standard OTLP Trace Schema
- Robust SDK client with automatic retries and fail-safe design

Quick Start:
    # Install
    pip install tracebrain
    
    # Start infrastructure with Docker (recommended)
    tracebrain up
    
    # Or use Python server directly for development
    tracebrain init-db
    tracebrain start
    
    # Use the SDK client in your code
    from tracebrain import TraceClient
    
    client = TraceClient()
    success = client.log_trace({
        "trace_id": "abc123",
        "attributes": {"system_prompt": "You are helpful"},
        "spans": [...]
    })

Usage:
    # Import the FastAPI app
    from tracebrain import app
    
    # Import configuration
    from tracebrain import settings
    
    # Import SDK client (recommended)
    from tracebrain import TraceClient
    
    # Import TraceStore for programmatic access
    from tracebrain.core.store import TraceStore
"""

__version__ = "1.0.0"
__author__ = "TraceBrain Team"

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .main import app as app
    from .config import settings as settings
    from .sdk import TraceClient as TraceClient
    from .sdk.client import TraceScope as TraceScope

__all__ = [
    "app",
    "settings",
    "TraceClient",
    "TraceScope",
    "__version__",
]


def __getattr__(name: str):
    # Lazily import heavy modules to keep CLI startup lightweight.
    if name == "app":
        from .main import app as value
        return value
    if name == "settings":
        from .config import settings as value
        return value
    if name == "TraceClient":
        from .sdk import TraceClient as value
        return value
    if name == "TraceScope":
        from .sdk.client import TraceScope as value
        return value
    raise AttributeError(f"module 'tracebrain' has no attribute '{name}'")
