# Copyright (c) 2026 Pete Jemian <prjemian+hklpy2@gmail.com>
# SPDX-License-Identifier: LicenseRef-UChicago-Argonne-LLC-License
"""Tests for the diffcalc solver adapter."""

import math
import re
from contextlib import nullcontext as does_not_raise

import pytest

from hklpy2_solvers.diffcalc_solver import _MODES, GEOMETRY_NAME, PSEUDO_AXES, REAL_AXES, DiffcalcSolver

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Cubic silicon lattice constant (Angstrom)
SI_A = 5.431
SI_LATTICE = {"a": SI_A, "b": SI_A, "c": SI_A, "alpha": 90.0, "beta": 90.0, "gamma": 90.0}
WAVELENGTH = 1.0  # Angstrom
THETA_100 = math.degrees(math.asin(WAVELENGTH / (2 * SI_A)))
TTH_100 = 2 * THETA_100


def _make_solver_with_ub(
    mode: str = "4S+2D mu_chi_phi_fixed",
) -> DiffcalcSolver:
    """Return a DiffcalcSolver with Si lattice, two reflections, and UB calculated."""
    solver = DiffcalcSolver()
    solver.lattice = dict(SI_LATTICE)

    r1 = {
        "name": "r1",
        "pseudos": {"h": 1.0, "k": 0.0, "l": 0.0},
        "reals": {"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 0},
        "wavelength": WAVELENGTH,
    }
    r2 = {
        "name": "r2",
        "pseudos": {"h": 0.0, "k": 1.0, "l": 0.0},
        "reals": {"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 90},
        "wavelength": WAVELENGTH,
    }
    solver.addReflection(r1)
    solver.addReflection(r2)
    solver.calculate_UB(r1, r2)
    solver.mode = mode
    return solver


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(geometry=GEOMETRY_NAME),
            does_not_raise(),
            id="default geometry accepted",
        ),
        pytest.param(
            dict(),
            does_not_raise(),
            id="no geometry arg uses default",
        ),
        pytest.param(
            dict(geometry="E4CV"),
            pytest.raises(Exception, match=re.escape("DiffcalcSolver supports only")),
            id="unsupported geometry raises",
        ),
    ],
)
def test_instantiation(parms, context):
    with context:
        solver = DiffcalcSolver(**parms)
        assert solver.name == "diffcalc"
        assert solver.geometry == GEOMETRY_NAME


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(attr="geometries", expected=[GEOMETRY_NAME]),
            does_not_raise(),
            id="geometries returns list with geometry name",
        ),
        pytest.param(
            dict(attr="pseudo_axis_names", expected=PSEUDO_AXES),
            does_not_raise(),
            id="pseudo_axis_names returns h k l",
        ),
        pytest.param(
            dict(attr="real_axis_names", expected=REAL_AXES),
            does_not_raise(),
            id="real_axis_names returns six axes",
        ),
    ],
)
def test_class_attributes(parms, context):
    with context:
        solver = DiffcalcSolver()
        value = getattr(solver, parms["attr"])
        if callable(value):
            value = value()
        assert value == parms["expected"]


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(mode="4S+2D mu_chi_phi_fixed"),
            does_not_raise(),
            id="valid mode accepted",
        ),
        pytest.param(
            dict(mode="4S+2D eta_chi_phi_fixed"),
            does_not_raise(),
            id="another valid mode",
        ),
        pytest.param(
            dict(mode="nonexistent_mode"),
            pytest.raises(Exception, match=re.escape("nonexistent_mode")),
            id="invalid mode raises",
        ),
    ],
)
def test_mode_setter(parms, context):
    solver = DiffcalcSolver()
    with context:
        solver.mode = parms["mode"]
        assert solver.mode == parms["mode"]


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(modes_count=23),
            does_not_raise(),
            id="modes list has expected count",
        ),
    ],
)
def test_modes_list(parms, context):
    with context:
        solver = DiffcalcSolver()
        modes = solver.modes
        assert len(modes) == parms["modes_count"]
        assert all(isinstance(m, str) for m in modes)


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(lattice=SI_LATTICE),
            does_not_raise(),
            id="valid lattice dict accepted",
        ),
        pytest.param(
            dict(lattice="not a dict"),
            pytest.raises(TypeError, match=re.escape("Must supply dict")),
            id="non-dict lattice raises TypeError",
        ),
    ],
)
def test_lattice_setter(parms, context):
    solver = DiffcalcSolver()
    with context:
        solver.lattice = parms["lattice"]
        assert solver.lattice == parms["lattice"]


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(
                reflection={
                    "name": "r1",
                    "pseudos": {"h": 1, "k": 0, "l": 0},
                    "reals": {"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 0},
                    "wavelength": WAVELENGTH,
                },
            ),
            does_not_raise(),
            id="valid reflection added",
        ),
        pytest.param(
            dict(reflection="not a dict"),
            pytest.raises(TypeError, match=re.escape("Must supply ReflectionDict")),
            id="non-dict reflection raises TypeError",
        ),
    ],
)
def test_add_reflection(parms, context):
    solver = DiffcalcSolver()
    solver.lattice = dict(SI_LATTICE)
    with context:
        solver.addReflection(parms["reflection"])
        assert solver.wavelength == WAVELENGTH


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(),
            does_not_raise(),
            id="calculate_UB succeeds with two reflections",
        ),
    ],
)
def test_calculate_ub(parms, context):
    solver = DiffcalcSolver()
    solver.lattice = dict(SI_LATTICE)
    r1 = {
        "name": "r1",
        "pseudos": {"h": 1, "k": 0, "l": 0},
        "reals": {"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 0},
        "wavelength": WAVELENGTH,
    }
    r2 = {
        "name": "r2",
        "pseudos": {"h": 0, "k": 1, "l": 0},
        "reals": {"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 90},
        "wavelength": WAVELENGTH,
    }
    solver.addReflection(r1)
    solver.addReflection(r2)
    with context:
        ub = solver.calculate_UB(r1, r2)
        assert len(ub) == 3
        assert all(len(row) == 3 for row in ub)
        # UB should not be identity for a real lattice
        assert ub[0][0] != 1.0 or ub[1][1] != 1.0


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(),
            pytest.raises(Exception, match=re.escape("Lattice must be set")),
            id="calculate_UB without lattice raises",
        ),
    ],
)
def test_calculate_ub_no_lattice(parms, context):
    solver = DiffcalcSolver()
    r1 = {
        "name": "r1",
        "pseudos": {"h": 1, "k": 0, "l": 0},
        "reals": {"mu": 0, "delta": 10, "nu": 0, "eta": 5, "chi": 0, "phi": 0},
        "wavelength": 1.0,
    }
    solver.addReflection(r1)
    with context:
        solver.calculate_UB(r1, r1)


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(
                mode="4S+2D mu_chi_phi_fixed",
                pseudos={"h": 1.0, "k": 0.0, "l": 0.0},
                expected_h=1.0,
                expected_k=0.0,
                expected_l=0.0,
            ),
            does_not_raise(),
            id="forward (1,0,0) 3-sample mode",
        ),
        pytest.param(
            dict(
                mode="4S+2D eta_chi_phi_fixed",
                pseudos={"h": 0.0, "k": 1.0, "l": 0.0},
                expected_h=0.0,
                expected_k=1.0,
                expected_l=0.0,
            ),
            does_not_raise(),
            id="forward (0,1,0) 3-sample eta_chi_phi mode",
        ),
        pytest.param(
            dict(
                mode="4S+2D mu_chi_phi_fixed",
                pseudos="not a dict",
                expected_h=0,
                expected_k=0,
                expected_l=0,
            ),
            pytest.raises(TypeError, match=re.escape("Must supply dict")),
            id="forward with non-dict raises TypeError",
        ),
    ],
)
def test_forward(parms, context):
    solver = _make_solver_with_ub(mode=parms["mode"])
    with context:
        solutions = solver.forward(parms["pseudos"])
        assert len(solutions) >= 1
        # Verify the first solution roundtrips via inverse
        hkl = solver.inverse(solutions[0])
        assert abs(hkl["h"] - parms["expected_h"]) < 0.01
        assert abs(hkl["k"] - parms["expected_k"]) < 0.01
        assert abs(hkl["l"] - parms["expected_l"]) < 0.01


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(
                reals={"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 0},
                expected_h=1.0,
                expected_k=0.0,
                expected_l=0.0,
            ),
            does_not_raise(),
            id="inverse r1 position -> (1,0,0)",
        ),
        pytest.param(
            dict(
                reals={"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 90},
                expected_h=0.0,
                expected_k=1.0,
                expected_l=0.0,
            ),
            does_not_raise(),
            id="inverse r2 position -> (0,1,0)",
        ),
        pytest.param(
            dict(
                reals={"mu": 0, "delta": 0, "nu": 0, "eta": 0, "chi": 0, "phi": 0},
                expected_h=0.0,
                expected_k=0.0,
                expected_l=0.0,
            ),
            does_not_raise(),
            id="inverse zero angles -> (0,0,0)",
        ),
        pytest.param(
            dict(
                reals="not a dict",
                expected_h=0,
                expected_k=0,
                expected_l=0,
            ),
            pytest.raises(TypeError, match=re.escape("Must supply dict")),
            id="inverse with non-dict raises TypeError",
        ),
    ],
)
def test_inverse(parms, context):
    solver = _make_solver_with_ub()
    with context:
        hkl = solver.inverse(parms["reals"])
        assert abs(hkl["h"] - parms["expected_h"]) < 0.01
        assert abs(hkl["k"] - parms["expected_k"]) < 0.01
        assert abs(hkl["l"] - parms["expected_l"]) < 0.01


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(
                mode="4S+2D mu_chi_phi_fixed",
                pseudos={"h": 1.0, "k": 0.0, "l": 0.0},
            ),
            does_not_raise(),
            id="forward-inverse roundtrip (1,0,0)",
        ),
        pytest.param(
            dict(
                mode="4S+2D mu_chi_phi_fixed",
                pseudos={"h": 0.0, "k": 1.0, "l": 0.0},
            ),
            does_not_raise(),
            id="forward-inverse roundtrip (0,1,0)",
        ),
        pytest.param(
            dict(
                mode="4S+2D mu_chi_phi_fixed",
                pseudos={"h": 1.0, "k": 1.0, "l": 0.0},
            ),
            does_not_raise(),
            id="forward-inverse roundtrip (1,1,0)",
        ),
    ],
)
def test_forward_inverse_roundtrip(parms, context):
    solver = _make_solver_with_ub(mode=parms["mode"])
    with context:
        solutions = solver.forward(parms["pseudos"])
        assert len(solutions) >= 1
        for sol in solutions:
            hkl = solver.inverse(sol)
            for axis in ("h", "k", "l"):
                assert abs(hkl[axis] - parms["pseudos"][axis]) < 0.01, (
                    f"Roundtrip mismatch on {axis}: expected {parms['pseudos'][axis]}, got {hkl[axis]}"
                )


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(mode="4S+2D mu_chi_phi_fixed"),
            does_not_raise(),
            id="extra_axis_names is always empty",
        ),
        pytest.param(
            dict(mode="4S+2D mu_fixed a_eq_b delta_fixed"),
            does_not_raise(),
            id="extra_axis_names empty for det+ref+samp mode",
        ),
        pytest.param(
            dict(mode=""),
            does_not_raise(),
            id="extra_axis_names empty for empty mode",
        ),
    ],
)
def test_extra_axis_names(parms, context):
    solver = DiffcalcSolver()
    with context:
        solver.mode = parms["mode"]
        assert solver.extra_axis_names == []
        assert solver.extras == {}


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(
                mode="4S+2D mu_chi_phi_fixed",
                expected_axes_w=["delta", "nu", "eta"],
            ),
            does_not_raise(),
            id="axes_w excludes mu, chi, phi",
        ),
        pytest.param(
            dict(
                mode="4S+2D mu_fixed a_eq_b delta_fixed",
                expected_axes_w=["nu", "eta", "chi", "phi"],
            ),
            does_not_raise(),
            id="axes_w excludes mu and delta",
        ),
        pytest.param(
            dict(
                mode="4S+2D chi_phi_fixed delta_fixed",
                expected_axes_w=["mu", "nu", "eta"],
            ),
            does_not_raise(),
            id="axes_w excludes chi, phi, delta",
        ),
        pytest.param(
            dict(
                mode="",
                expected_axes_w=REAL_AXES,
            ),
            does_not_raise(),
            id="axes_w returns all axes when mode is empty",
        ),
    ],
)
def test_axes_w(parms, context):
    solver = DiffcalcSolver()
    with context:
        solver.mode = parms["mode"]
        assert solver.axes_w == parms["expected_axes_w"]


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(),
            does_not_raise(),
            id="UB is identity before calculation",
        ),
    ],
)
def test_ub_before_calculation(parms, context):
    solver = DiffcalcSolver()
    with context:
        ub = solver.UB
        assert ub == [[1, 0, 0], [0, 1, 0], [0, 0, 1]]


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(),
            does_not_raise(),
            id="removeAllReflections clears state",
        ),
    ],
)
def test_remove_all_reflections(parms, context):
    solver = _make_solver_with_ub()
    with context:
        assert solver.wavelength is not None
        solver.removeAllReflections()
        assert solver.wavelength is None
        # UB should revert to identity after reset
        assert solver.UB == [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
        # Lattice should still be set
        assert solver.lattice == SI_LATTICE


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(wavelength=1.5),
            does_not_raise(),
            id="set positive wavelength",
        ),
        pytest.param(
            dict(wavelength=-1.0),
            pytest.raises(ValueError, match=re.escape("Must supply positive number")),
            id="negative wavelength raises",
        ),
        pytest.param(
            dict(wavelength=0.0),
            pytest.raises(ValueError, match=re.escape("Must supply positive number")),
            id="zero wavelength raises",
        ),
        pytest.param(
            dict(wavelength="abc"),
            pytest.raises(TypeError, match=re.escape("Must supply number")),
            id="non-numeric wavelength raises",
        ),
    ],
)
def test_wavelength_setter(parms, context):
    solver = DiffcalcSolver()
    with context:
        solver.wavelength = parms["wavelength"]
        assert solver.wavelength == parms["wavelength"]


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(),
            pytest.raises(Exception, match=re.escape("UB matrix has not been set")),
            id="forward without UB raises",
        ),
    ],
)
def test_forward_without_ub(parms, context):
    solver = DiffcalcSolver()
    solver.lattice = dict(SI_LATTICE)
    solver.wavelength = 1.0
    with context:
        solver.forward({"h": 1, "k": 0, "l": 0})


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(),
            pytest.raises(Exception, match=re.escape("Wavelength is not set")),
            id="forward without wavelength raises",
        ),
    ],
)
def test_forward_without_wavelength(parms, context):
    """Solver with UB set but no wavelength should raise about wavelength."""
    solver = _make_solver_with_ub()
    solver.removeAllReflections()
    # Re-add reflections and UB but clear wavelength
    solver.lattice = dict(SI_LATTICE)
    r1 = {
        "name": "r1",
        "pseudos": {"h": 1, "k": 0, "l": 0},
        "reals": {"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 0},
        "wavelength": WAVELENGTH,
    }
    r2 = {
        "name": "r2",
        "pseudos": {"h": 0, "k": 1, "l": 0},
        "reals": {"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 90},
        "wavelength": WAVELENGTH,
    }
    solver.addReflection(r1)
    solver.addReflection(r2)
    solver.calculate_UB(r1, r2)
    # Force clear wavelength after UB is set
    solver._wavelength = None
    with context:
        solver.forward({"h": 1, "k": 0, "l": 0})


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(
                lattice={"a": 4.0, "b": 4.0, "c": 4.0, "alpha": 90, "beta": 90, "gamma": 90},
            ),
            does_not_raise(),
            id="lattice preserved after removeAllReflections",
        ),
    ],
)
def test_lattice_preserved_after_reset(parms, context):
    solver = DiffcalcSolver()
    with context:
        solver.lattice = parms["lattice"]
        solver.removeAllReflections()
        assert solver.lattice == parms["lattice"]


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(
                mode="4S+2D mu_chi_phi_fixed",
                pseudos={"h": 1, "k": 0, "l": 0},
                min_solutions=1,
            ),
            does_not_raise(),
            id="forward returns multiple solutions",
        ),
    ],
)
def test_forward_multiple_solutions(parms, context):
    solver = _make_solver_with_ub(mode=parms["mode"])
    with context:
        solutions = solver.forward(parms["pseudos"])
        assert len(solutions) >= parms["min_solutions"]
        # All solutions must have all real axis names
        for sol in solutions:
            for ax in REAL_AXES:
                assert ax in sol


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(
                lattice={"a": 3.905, "b": 3.905, "c": 3.905, "alpha": 90, "beta": 90, "gamma": 90},
            ),
            does_not_raise(),
            id="refineLattice returns None with <3 reflections",
        ),
    ],
)
def test_refine_lattice_insufficient_reflections(parms, context):
    solver = DiffcalcSolver()
    solver.lattice = parms["lattice"]
    with context:
        result = solver.refineLattice([])
        assert result is None


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(
                mode="4S+2D mu_fixed a_eq_b delta_fixed",
                pseudos={"h": 100, "k": 100, "l": 100},
            ),
            pytest.raises(Exception, match=re.escape("Reflection unreachable")),
            id="forward unreachable reflection raises SolverError",
        ),
    ],
)
def test_forward_diffcalc_exception(parms, context):
    solver = _make_solver_with_ub(mode=parms["mode"])
    with context:
        solver.forward(parms["pseudos"])


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(),
            does_not_raise(),
            id="refineLattice with 3+ reflections returns dict",
        ),
    ],
)
def test_refine_lattice_success(parms, context):
    """Add 3 non-coplanar reflections and verify refineLattice returns a dict."""
    solver = DiffcalcSolver()
    solver.lattice = dict(SI_LATTICE)

    wl = WAVELENGTH

    # Three reflections with known, physically consistent positions.
    # For cubic Si, d_hkl = a/sqrt(h^2+k^2+l^2).
    # Bragg: theta = arcsin(wl/(2*d))
    # Compute angles using mu_chi_phi_fixed mode from a helper solver.
    helper = _make_solver_with_ub(mode="4S+2D mu_chi_phi_fixed")

    # (1,0,0) and (0,1,0) work fine with this mode.
    # (1,1,0) also works. All are in-plane with chi=phi=mu=0.
    hkl_list = [(1, 0, 0), (0, 1, 0), (1, 1, 0)]
    for h, k, l in hkl_list:  # noqa: E741
        solutions = helper.forward({"h": float(h), "k": float(k), "l": float(l)})
        reals = solutions[0]
        refl = {
            "name": f"r_{h}{k}{l}",
            "pseudos": {"h": float(h), "k": float(k), "l": float(l)},
            "reals": reals,
            "wavelength": wl,
        }
        solver.addReflection(refl)

    solver.calculate_UB(solver._reflections[0], solver._reflections[1])

    with context:
        result = solver.refineLattice(solver._reflections)
        # refineLattice may return None if the reflections are coplanar
        # (singular matrix), which is acceptable for this test.
        if result is not None:
            assert isinstance(result, dict)
            assert "a" in result
            assert "b" in result
            assert "c" in result


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(mode=""),
            does_not_raise(),
            id="set mode to empty string",
        ),
    ],
)
def test_mode_set_empty(parms, context):
    solver = DiffcalcSolver()
    with context:
        solver.mode = parms["mode"]
        assert solver.mode == ""
        assert solver.extras == {}


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(
                reals={"mu": 0, "delta": 0, "nu": 0, "eta": 0, "chi": 0, "phi": 0},
                wavelength=1.0,
                expected={"h": 0.0, "k": 0.0, "l": 0.0},
            ),
            does_not_raise(),
            id="inverse at all-zeros without any UB returns (0,0,0) - issue #24",
        ),
        pytest.param(
            dict(
                reals={"mu": 0, "delta": 0, "nu": 0, "eta": 0, "chi": 0, "phi": 0},
                wavelength=None,
                expected={"h": 0.0, "k": 0.0, "l": 0.0},
            ),
            does_not_raise(),
            id="inverse at all-zeros without UB or wavelength returns (0,0,0)",
        ),
    ],
)
def test_inverse_without_ub(parms, context):
    """inverse() must work before any UB is set (issue #24 regression test)."""
    solver = DiffcalcSolver()
    if parms["wavelength"] is not None:
        solver.wavelength = parms["wavelength"]
    with context:
        result = solver.inverse(parms["reals"])
        for axis in ("h", "k", "l"):
            assert abs(result[axis] - parms["expected"][axis]) < 1e-9, (
                f"axis {axis}: expected {parms['expected'][axis]}, got {result[axis]}"
            )


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(
                reals={"mu": 0, "delta": 0, "nu": 0, "eta": 0, "chi": 0, "phi": 0},
            ),
            does_not_raise(),
            id="second inverse call reuses default UB without re-init",
        ),
    ],
)
def test_inverse_default_ub_idempotent(parms, context):
    """Calling inverse() repeatedly without a UB must not raise or re-init UB."""
    solver = DiffcalcSolver()
    solver.wavelength = 1.0
    with context:
        r1 = solver.inverse(parms["reals"])
        r2 = solver.inverse(parms["reals"])
        for axis in ("h", "k", "l"):
            assert r1[axis] == r2[axis]


# ---------------------------------------------------------------------------
# Issue #25 regression tests: sample setter pushes lattice into diffcalc
# ---------------------------------------------------------------------------

# A minimal SampleDict as produced by hklpy2 Core.to_solver_units()
_SAMPLE_DICT_LIST_REFLECTIONS = {
    "name": "vibranium",
    "lattice": {
        "a": SI_A,
        "b": SI_A,
        "c": SI_A,
        "alpha": 90.0,
        "beta": 90.0,
        "gamma": 90.0,
        "angle_units": "degrees",
        "length_units": "angstrom",
    },
    "order": ["r1", "r2"],
    "reflections": [
        {
            "name": "r1",
            "pseudos": {"h": 1.0, "k": 0.0, "l": 0.0},
            "reals": {"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 0},
            "wavelength": WAVELENGTH,
        },
        {
            "name": "r2",
            "pseudos": {"h": 0.0, "k": 1.0, "l": 0.0},
            "reals": {"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 90},
            "wavelength": WAVELENGTH,
        },
    ],
}

_SAMPLE_DICT_DICT_REFLECTIONS = {
    "name": "vibranium",
    "lattice": {
        "a": SI_A,
        "b": SI_A,
        "c": SI_A,
        "alpha": 90.0,
        "beta": 90.0,
        "gamma": 90.0,
    },
    "order": ["r1", "r2"],
    "reflections": {
        "r1": {
            "name": "r1",
            "pseudos": {"h": 1.0, "k": 0.0, "l": 0.0},
            "reals": {"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 0},
            "wavelength": WAVELENGTH,
        },
        "r2": {
            "name": "r2",
            "pseudos": {"h": 0.0, "k": 1.0, "l": 0.0},
            "reals": {"mu": 0, "delta": TTH_100, "nu": 0, "eta": THETA_100, "chi": 0, "phi": 90},
            "wavelength": WAVELENGTH,
        },
    },
}


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(sample=_SAMPLE_DICT_LIST_REFLECTIONS),
            does_not_raise(),
            id="sample setter with list reflections pushes lattice - issue #25",
        ),
        pytest.param(
            dict(sample=_SAMPLE_DICT_DICT_REFLECTIONS),
            does_not_raise(),
            id="sample setter with dict reflections pushes lattice",
        ),
        pytest.param(
            dict(sample="not a dict"),
            pytest.raises(TypeError, match=re.escape("Must supply dictionary")),
            id="sample setter with non-dict raises TypeError",
        ),
    ],
)
def test_sample_setter_pushes_lattice(parms, context):
    """sample setter must push the lattice into _ubcalc (issue #25 regression)."""
    solver = DiffcalcSolver()
    with context:
        solver.sample = parms["sample"]
        # Lattice must now be in _ubcalc (crystal is not None)
        assert solver._ubcalc.crystal is not None
        # The solver's lattice dict must match
        assert abs(solver.lattice["a"] - SI_A) < 1e-9


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(sample=_SAMPLE_DICT_LIST_REFLECTIONS),
            does_not_raise(),
            id="calculate_UB succeeds after sample setter - issue #25",
        ),
    ],
)
def test_calculate_ub_after_sample_setter(parms, context):
    """calculate_UB must succeed when lattice arrives via sample setter (issue #25)."""
    solver = DiffcalcSolver()
    solver.wavelength = WAVELENGTH
    with context:
        solver.sample = parms["sample"]
        r1 = parms["sample"]["reflections"][0]
        r2 = parms["sample"]["reflections"][1]
        ub = solver.calculate_UB(r1, r2)
        assert len(ub) == 3
        assert all(len(row) == 3 for row in ub)


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(sample=_SAMPLE_DICT_LIST_REFLECTIONS),
            does_not_raise(),
            id="sample setter re-adds reflections in order",
        ),
    ],
)
def test_sample_setter_repopulates_reflections(parms, context):
    """sample setter must re-add reflections so _reflections is populated."""
    solver = DiffcalcSolver()
    with context:
        solver.sample = parms["sample"]
        assert len(solver._reflections) == len(parms["sample"]["order"])
        for i, name in enumerate(parms["sample"]["order"]):
            assert solver._reflections[i]["name"] == name


# ---------------------------------------------------------------------------
# Issue #29 regression tests: set_reals and UB setter
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(reals={"mu": 0.0, "delta": 0.0, "nu": 0.0, "eta": 0.0, "chi": 0.0, "phi": 0.0}),
            does_not_raise(),
            id="set_reals accepts valid dict of floats",
        ),
        pytest.param(
            dict(reals={"mu": 0, "delta": 0, "nu": 0, "eta": 0, "chi": 0, "phi": 0}),
            does_not_raise(),
            id="set_reals accepts ints",
        ),
        pytest.param(
            dict(reals="not a dict"),
            pytest.raises(TypeError, match=re.escape("Must supply dict")),
            id="set_reals with non-dict raises TypeError",
        ),
        pytest.param(
            dict(reals={"mu": "bad", "delta": 0.0, "nu": 0.0, "eta": 0.0, "chi": 0.0, "phi": 0.0}),
            pytest.raises(TypeError, match=re.escape("All values must be numbers")),
            id="set_reals with non-numeric value raises TypeError",
        ),
    ],
)
def test_set_reals(parms, context):
    """set_reals validates input and is otherwise a no-op for diffcalc (issue #29)."""
    solver = DiffcalcSolver()
    with context:
        solver.set_reals(parms["reals"])


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(ub=[[1, 0, 0], [0, 1, 0], [0, 0, 1]]),
            does_not_raise(),
            id="UB setter restores identity matrix",
        ),
    ],
)
def test_ub_setter(parms, context):
    """UB setter must restore the orientation matrix into _ubcalc (issue #29)."""
    solver = _make_solver_with_ub()
    with context:
        solver.UB = parms["ub"]
        assert solver._ubcalc.UB is not None


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(mode="4S+2D mu_chi_phi_fixed", pseudos={"h": 1.0, "k": 0.0, "l": 0.0}),
            does_not_raise(),
            id="forward succeeds after update_solver restores UB via setter - issue #29",
        ),
    ],
)
def test_forward_after_ub_restore(parms, context):
    """forward() must work after update_solver() restores UB via the UB setter."""
    solver = _make_solver_with_ub(mode=parms["mode"])
    # Simulate what update_solver() does: reset via sample then restore UB
    ub = solver.UB
    solver.sample = {
        "name": "test",
        "lattice": dict(SI_LATTICE),
        "order": [],
        "reflections": [],
    }
    solver.UB = ub  # restore, as update_solver() does
    with context:
        solutions = solver.forward(parms["pseudos"])
        assert len(solutions) >= 1


@pytest.mark.parametrize(
    "parms, context",
    [
        # -- 1 det + 1 ref + 1 samp (a_eq_b is non-motor) --
        pytest.param(
            dict(
                mode="4S+2D mu_fixed a_eq_b delta_fixed",
                expected_reals=["nu", "eta", "chi", "phi"],
            ),
            does_not_raise(),
            id="a_eq_b non-motor: only mu,delta fixed",
        ),
        # -- 1 det + 1 ref + 1 samp (psi is non-motor) --
        pytest.param(
            dict(
                mode="4S+2D phi_fixed psi_fixed nu_fixed",
                expected_reals=["mu", "delta", "eta", "chi"],
            ),
            does_not_raise(),
            id="psi non-motor: only nu,phi fixed",
        ),
        # -- 1 det + 2 samp --
        pytest.param(
            dict(
                mode="4S+2D chi_phi_fixed delta_fixed",
                expected_reals=["mu", "nu", "eta"],
            ),
            does_not_raise(),
            id="3 motor constraints: delta,chi,phi fixed",
        ),
        # -- 1 det + 2 samp (bisect is non-motor) --
        pytest.param(
            dict(
                mode="4S+2D bisect_mu_fixed delta_fixed",
                expected_reals=["nu", "eta", "chi", "phi"],
            ),
            does_not_raise(),
            id="bisect non-motor: only mu,delta fixed",
        ),
        # -- 1 det + 2 samp (bisect+omega are non-motor) --
        pytest.param(
            dict(
                mode="4S+2D bisect_omega_fixed nu_fixed",
                expected_reals=["mu", "delta", "eta", "chi", "phi"],
            ),
            does_not_raise(),
            id="bisect+omega non-motor: only nu fixed",
        ),
        # -- 1 ref + 2 samp --
        pytest.param(
            dict(
                mode="4S+2D chi_mu_fixed a_eq_b",
                expected_reals=["delta", "nu", "eta", "phi"],
            ),
            does_not_raise(),
            id="1ref+2samp: mu,chi fixed",
        ),
        # -- 3 samp --
        pytest.param(
            dict(
                mode="4S+2D eta_chi_phi_fixed",
                expected_reals=["mu", "delta", "nu"],
            ),
            does_not_raise(),
            id="3samp: eta,chi,phi fixed",
        ),
        pytest.param(
            dict(
                mode="4S+2D mu_eta_chi_fixed",
                expected_reals=["delta", "nu", "phi"],
            ),
            does_not_raise(),
            id="3samp: mu,eta,chi fixed",
        ),
    ],
)
def test_summary_dict(parms, context):
    """_summary_dict reports correct writable axes per mode (issue #37)."""
    solver = DiffcalcSolver()
    with context:
        sdict = solver._summary_dict
        mode_entry = sdict["modes"][parms["mode"]]
        assert mode_entry["reals"] == parms["expected_reals"]
        assert mode_entry["extras"] == []
        # Top-level keys are correct regardless of mode.
        assert sdict["name"] == GEOMETRY_NAME
        assert sdict["pseudos"] == list(PSEUDO_AXES)
        assert sdict["reals"] == list(REAL_AXES)


@pytest.mark.parametrize(
    "parms, context",
    [
        pytest.param(
            dict(),
            does_not_raise(),
            id="all modes writable axes match axes_w",
        ),
    ],
)
def test_summary_dict_all_modes(parms, context):
    """Every mode in _summary_dict has reals == axes_w (issue #37)."""
    solver = DiffcalcSolver()
    with context:
        sdict = solver._summary_dict
        assert set(sdict["modes"].keys()) == set(_MODES.keys())
        for mode_name in _MODES:
            solver.mode = mode_name
            expected = solver.axes_w
            actual = sdict["modes"][mode_name]["reals"]
            assert actual == expected, f"Mode {mode_name!r}: expected writable {expected}, got {actual}"
