"""Built-in internal source adapters."""

from igrep.internal_sources.builtin.apple_notes import AppleNotesAdapter
from igrep.internal_sources.builtin.chrome_site import ChromeSiteAdapter
from igrep.internal_sources.builtin.gongfeng_project import GongfengProjectAdapter
from igrep.internal_sources.builtin.iwiki_doc import IWikiAdapter
from igrep.internal_sources.builtin.km_article import KmArticleAdapter
from igrep.internal_sources.builtin.spotlight_file import SpotlightFileAdapter
from igrep.internal_sources.builtin.tapd_story import TapdStoryAdapter

__all__ = [
    "AppleNotesAdapter",
    "ChromeSiteAdapter",
    "GongfengProjectAdapter",
    "IWikiAdapter",
    "KmArticleAdapter",
    "SpotlightFileAdapter",
    "TapdStoryAdapter",
]
