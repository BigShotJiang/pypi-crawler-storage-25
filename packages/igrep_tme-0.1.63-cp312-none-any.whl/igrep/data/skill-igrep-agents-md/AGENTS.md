## igrep — search routing

This block is only a routing hint. Full usage details live in the igrep MCP
tool descriptions and installed skills.

- **Concept / intent, unfamiliar code, behavior lookup, indexed docs**: prefer
  `mcp__igrep__search` before guessed Search/Grep/rg/ripgrep loops.
- **Known code-symbol, path, or file:line anchor**: prefer
  `mcp__igrep__lsp_locate` for definitions/source anchors and
  `mcp__igrep__lsp_refs` for callers/usages.
  Reuse emitted `query_handle`, `scoped_query`, `cursor_query`, or full `sym:...`
  qnames directly; prefer scoped handles when bare symbols are ambiguous.
- **Exact literal/regex, known file, or exhaustive sweep**: use built-in
  Search/Grep/rg/Read.

For repository search/exploration, default to igrep before guessed
rg/Grep/Search loops; keep exact-text tools for exact-literal cases.

After igrep returns, read cited files/ranges and verify with repo commands. If
MCP tools are hidden, load them once instead of guessed searches.
