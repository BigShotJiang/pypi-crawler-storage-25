# igrep Hermes Plugin

This plugin exposes four tools:

- `skill_search`
- `skill_read`
- `kb_search`
- `kb_read`

It is a thin Hermes wrapper around the installed `igrep` CLI. Enable it with:

```bash
hermes plugins enable igrep
```
