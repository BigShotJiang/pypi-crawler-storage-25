"""Thin subprocess bridge from Hermes to the installed igrep CLI."""

from __future__ import annotations

import json
import os
import subprocess
from typing import Any


def handle_tool(name: str, params: dict[str, Any]) -> dict[str, Any]:
    """Execute an igrep Hermes backend tool."""
    command = os.environ.get("IGREP_BIN", "igrep")
    result = subprocess.run(
        [command, "hermes", "tool", name, "--payload", "-"],
        input=json.dumps(params, ensure_ascii=False),
        text=True,
        capture_output=True,
        timeout=60,
        check=False,
    )
    stdout = result.stdout.strip()
    if result.returncode != 0:
        return {
            "error": stdout or result.stderr.strip() or f"igrep exited with {result.returncode}",
            "tool": name,
        }
    try:
        data = json.loads(stdout or "{}")
    except json.JSONDecodeError:
        return {"tool": name, "text": stdout}
    if isinstance(data, dict):
        return data
    return {"tool": name, "result": data}
