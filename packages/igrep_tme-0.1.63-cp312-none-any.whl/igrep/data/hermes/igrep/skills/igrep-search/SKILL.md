---
name: igrep-search
description: Use igrep tools to recall relevant skills and search knowledge bases from Hermes. Keep natural-language queries intact; do not turn them into regex probes.
---

# igrep Search for Hermes

Natural-language search is the intended input path for Hermes igrep tools.
Keep the user's natural-language query intact. Do not invent OR-regex probes
such as `auth|login|token`; regex is only for exact literal/regex lookup in a
known narrow path.

Use `skill_search` when the task suggests a skill may exist but the skill name
is unknown. Pass the task description as natural language. Prefer `skill_view`
with the returned `view_args`; use
`skill_read` only for returned external paths.

Use `kb_search` when the user asks about project, team, repo, or document
knowledge. Pass the user's question or topic as natural language. If a hit has
`read_args`, call `kb_read` for more context before answering. Do not turn
knowledge-base hits into memory unless the user asks to remember a conclusion.

Use `memory_recall` only when the igrep MemoryProvider is active or memory
tools are explicitly enabled. Pass the remembered preference/decision/session
topic as natural language. Memory recall is for user preferences, prior
decisions, and session context, not for external knowledge-base facts.
