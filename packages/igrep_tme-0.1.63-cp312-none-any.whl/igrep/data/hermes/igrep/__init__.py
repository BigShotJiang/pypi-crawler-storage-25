"""Hermes general plugin for igrep tools."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .schemas import TOOL_SCHEMAS
from .tools import handle_tool


def register(ctx: Any) -> None:
    """Register igrep tools and bundled skill with Hermes."""
    for schema in TOOL_SCHEMAS:
        name = str(schema["name"])
        ctx.register_tool(name, schema, lambda params, tool_name=name: handle_tool(tool_name, params))
    ctx.register_skill("igrep-search", Path(__file__).parent / "skills" / "igrep-search")
