"""Tool schemas exposed to Hermes by the igrep plugin."""

from __future__ import annotations

from typing import Any

TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "name": "skill_search",
        "description": (
            "Search local and external Hermes-compatible SKILL.md files by task intent. "
            "Keep the user's natural-language query intact; do not invent OR-regex probes."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": (
                        "Natural-language task or capability description. "
                        "Do not translate semantic intent into regex."
                    ),
                },
                "max_results": {"type": "integer", "minimum": 1, "maximum": 20, "default": 5},
            },
            "required": ["query"],
        },
    },
    {
        "name": "skill_read",
        "description": "Read one bounded SKILL.md file returned by skill_search.",
        "parameters": {
            "type": "object",
            "properties": {
                "name_or_path": {"type": "string"},
                "path": {"type": "string"},
                "max_chars": {"type": "integer", "minimum": 200, "maximum": 100000, "default": 8000},
            },
        },
    },
    {
        "name": "kb_search",
        "description": (
            "Search an igrep-center App or configured igrep internal knowledge source. "
            "Use the user's natural-language question, not a guessed regex."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural-language question or topic; do not invent OR-regex probes.",
                },
                "app": {"type": "string", "description": "igrep-center App slug; optional when configured by env."},
                "source_id": {"type": "string", "description": "Optional source narrowing."},
                "max_results": {"type": "integer", "minimum": 1, "maximum": 20, "default": 5},
            },
            "required": ["query"],
        },
    },
    {
        "name": "kb_read",
        "description": "Read bounded context from a kb_search result's read_args.",
        "parameters": {
            "type": "object",
            "properties": {
                "app": {"type": "string"},
                "read_args": {"type": "object"},
                "repo": {"type": "string"},
                "filename": {"type": "string"},
                "start_line": {"type": "integer", "minimum": 1, "default": 1},
                "limit": {"type": "integer", "minimum": 1, "maximum": 500, "default": 200},
            },
        },
    },
]
