"""Hermes CLI hook for the igrep memory provider."""

from __future__ import annotations

import subprocess
from typing import Any


def _handler(args: Any) -> None:
    sub = getattr(args, "igrep_memory_command", None)
    if sub == "status":
        subprocess.run(["igrep", "mem", "doctor"], check=False)
    elif sub == "doctor":
        subprocess.run(["igrep", "mem", "doctor", "--strict"], check=False)
    else:
        print("Usage: hermes igrep {status|doctor}")


def register_cli(subparser: Any) -> None:
    subs = subparser.add_subparsers(dest="igrep_memory_command")
    subs.add_parser("status", help="Show igrep memory root status")
    subs.add_parser("doctor", help="Strict igrep memory diagnostics")
    subparser.set_defaults(func=_handler)
