"""Hermes MemoryProvider backed by igrep mem."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Any

from agent.memory_provider import MemoryProvider


class IgrepMemoryProvider(MemoryProvider):
    """External Hermes memory provider that shells out to ``igrep mem``."""

    @property
    def name(self) -> str:
        return "igrep"

    def is_available(self) -> bool:
        command = self._igrep_bin()
        if Path(command).is_absolute():
            return Path(command).is_file() and os.access(command, os.X_OK)
        return shutil.which(command) is not None

    def initialize(self, session_id: str, **kwargs: Any) -> None:
        self._session_id = session_id
        self._hermes_home = Path(str(kwargs["hermes_home"])).expanduser()
        workspace = kwargs.get("workspace") or kwargs.get("cwd") or self._hermes_home
        self._workspace = Path(str(workspace)).expanduser()
        self._threads: list[threading.Thread] = []

    def get_config_schema(self) -> list[dict[str, Any]]:
        return [
            {
                "key": "igrep_bin",
                "description": "igrep command or absolute path",
                "default": "igrep",
            }
        ]

    def save_config(self, values: dict[str, Any], hermes_home: str) -> None:
        config_path = Path(hermes_home).expanduser() / "igrep-memory.json"
        config_path.write_text(json.dumps(values, ensure_ascii=False, indent=2), encoding="utf-8")

    def get_tool_schemas(self) -> list[dict[str, Any]]:
        return [
            {
                "name": "memory_recall",
                "description": "Search igrep memory roots for evidence-backed prior context.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "max_results": {"type": "integer", "minimum": 1, "maximum": 20, "default": 5},
                        "root_filter": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "memory_record",
                "description": "Record an important long-term memory entry.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "kind": {"type": "string"},
                        "content": {"type": "string"},
                        "tags": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["kind", "content"],
                },
            },
            {
                "name": "memory_get",
                "description": "Read a bounded memory file window from a recall ref.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "ref": {"type": "string"},
                        "start_line": {"type": "integer", "minimum": 1},
                        "limit": {"type": "integer", "minimum": 0, "maximum": 10000},
                    },
                    "required": ["ref"],
                },
            },
            {
                "name": "memory_ask",
                "description": "Answer a memory question with cited igrep evidence.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "level": {
                            "type": "string",
                            "enum": ["recall", "quick", "standard", "deep"],
                            "default": "quick",
                        },
                        "max_results": {"type": "integer", "minimum": 1, "maximum": 20, "default": 5},
                    },
                    "required": ["query"],
                },
            },
        ]

    def handle_tool_call(self, name: str, args: dict[str, Any], **kwargs: Any) -> str:
        if name == "memory_recall":
            cmd = [
                "mem",
                "recall",
                str(args["query"]),
                "--workspace",
                str(self._workspace),
                "--hermes-home",
                str(self._hermes_home),
                "--max-results",
                str(args.get("max_results", 5)),
                "--format",
                "provider-json",
            ]
            for root_id in args.get("root_filter", []) or []:
                cmd.extend(["--root-filter", str(root_id)])
            return json.dumps(self._run_json(cmd), ensure_ascii=False)
        if name == "memory_record":
            cmd = [
                "mem",
                "record",
                "--workspace",
                str(self._workspace),
                "--hermes-home",
                str(self._hermes_home),
                "--kind",
                str(args["kind"]),
                "--text",
                str(args["content"]),
            ]
            for tag in args.get("tags", []) or []:
                cmd.extend(["--tag", str(tag)])
            return json.dumps(self._run_json(cmd), ensure_ascii=False)
        if name == "memory_get":
            cmd = [
                "mem",
                "get",
                str(args["ref"]),
                "--workspace",
                str(self._workspace),
                "--hermes-home",
                str(self._hermes_home),
            ]
            if args.get("start_line"):
                cmd.extend(["--from", str(args["start_line"])])
            if args.get("limit") is not None:
                cmd.extend(["--lines", str(args["limit"])])
            return json.dumps(self._run_json(cmd), ensure_ascii=False)
        if name == "memory_ask":
            return json.dumps(
                self._run_json([
                    "mem",
                    "ask",
                    str(args["query"]),
                    "--workspace",
                    str(self._workspace),
                    "--hermes-home",
                    str(self._hermes_home),
                    "--level",
                    str(args.get("level", "quick")),
                    "--max-results",
                    str(args.get("max_results", 5)),
                ]),
                ensure_ascii=False,
            )
        return json.dumps({"error": f"unknown igrep memory tool: {name}"}, ensure_ascii=False)

    def system_prompt_block(self) -> str:
        return "igrep memory provider is active. Use memory_recall for evidence-backed memory search."

    def prefetch(self, query: str, *, session_id: str = "") -> str:
        try:
            data = self._run_json(
                [
                    "mem",
                    "recall",
                    query,
                    "--workspace",
                    str(self._workspace),
                    "--hermes-home",
                    str(self._hermes_home),
                    "--format",
                    "provider-json",
                ],
                timeout=2.5,
            )
        except Exception:
            return ""
        context = data.get("markdown_context")
        return context if isinstance(context, str) else ""

    def sync_turn(self, user_content: str, assistant_content: str, *, session_id: str = "") -> None:
        def _sync() -> None:
            text = f"User:\n{user_content}\n\nAssistant:\n{assistant_content}"
            result = self._run_json(
                [
                    "mem",
                    "record",
                    "--workspace",
                    str(self._workspace),
                    "--hermes-home",
                    str(self._hermes_home),
                    "--kind",
                    "session",
                    "--agent",
                    "hermes",
                    "--session-id",
                    session_id or getattr(self, "_session_id", ""),
                    "--observer",
                    "agent:hermes",
                    "--text",
                    text,
                ],
                timeout=10,
                fail_open=True,
            )
            self._derive_session_result(result)

        thread = threading.Thread(target=_sync, daemon=True)
        thread.start()
        self._threads.append(thread)

    def on_session_end(self, messages: list[dict[str, Any]]) -> None:
        for thread in self._threads:
            thread.join(timeout=1.0)

    def on_pre_compress(self, messages: list[dict[str, Any]]) -> str:
        text = json.dumps(messages[-20:], ensure_ascii=False)
        result = self._run_json(
            [
                "mem",
                "record",
                "--workspace",
                str(self._workspace),
                "--hermes-home",
                str(self._hermes_home),
                "--kind",
                "session",
                "--agent",
                "hermes",
                "--session-id",
                getattr(self, "_session_id", ""),
                "--observer",
                "agent:hermes",
                "--text",
                text,
            ],
            timeout=10,
            fail_open=True,
        )
        self._derive_session_result(result, background=True)
        return ""

    def on_memory_write(self, action: str, target: str, content: str) -> None:
        if action not in {"add", "replace"}:
            return
        kind = "preference" if target == "user" else "note"
        self._run_json(
            [
                "mem",
                "record",
                "--workspace",
                str(self._workspace),
                "--hermes-home",
                str(self._hermes_home),
                "--kind",
                kind,
                "--text",
                content,
            ],
            timeout=10,
            fail_open=True,
        )

    def shutdown(self) -> None:
        for thread in self._threads:
            thread.join(timeout=1.0)

    def _igrep_bin(self) -> str:
        config_path = getattr(self, "_hermes_home", Path.home() / ".hermes") / "igrep-memory.json"
        if config_path.is_file():
            try:
                data = json.loads(config_path.read_text(encoding="utf-8"))
                if isinstance(data, dict) and isinstance(data.get("igrep_bin"), str):
                    return data["igrep_bin"]
            except Exception:
                pass
        return os.environ.get("IGREP_BIN", "igrep")

    def _run_json(
        self,
        args: list[str],
        *,
        timeout: float = 30,
        fail_open: bool = False,
    ) -> dict[str, Any]:
        try:
            result = subprocess.run(
                [self._igrep_bin(), *args],
                text=True,
                capture_output=True,
                timeout=timeout,
                check=False,
            )
        except Exception as err:
            if fail_open:
                return {"warning": str(err)}
            raise
        if result.returncode != 0:
            if fail_open:
                return {"warning": result.stderr.strip() or result.stdout.strip()}
            raise RuntimeError(result.stderr.strip() or result.stdout.strip())
        try:
            data = json.loads(result.stdout or "{}")
        except json.JSONDecodeError as err:
            if fail_open:
                return {"warning": f"invalid igrep JSON output: {err}"}
            raise
        return data if isinstance(data, dict) else {"result": data}

    def _derive_session_result(self, result: dict[str, Any], *, background: bool = False) -> None:
        path = result.get("path")
        if not isinstance(path, str) or not path.startswith("memory/sessions/"):
            return
        cmd = [
            "mem",
            "derive",
            "--workspace",
            str(self._workspace),
            "--session",
            path,
            "--observer",
            "agent:hermes",
        ]

        def _run() -> None:
            self._run_json(cmd, timeout=20, fail_open=True)

        if background:
            thread = threading.Thread(target=_run, daemon=True)
            thread.start()
            self._threads.append(thread)
            return
        _run()


def register(ctx: Any) -> None:
    ctx.register_memory_provider(IgrepMemoryProvider())
