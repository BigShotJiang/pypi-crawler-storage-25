# igrep Hermes MemoryProvider

This provider shells out to `igrep mem` for recall, record, get, wake, and
doctor operations. It is installed by:

```bash
igrep setup hermes --with-memory-provider
```

For Hermes 0.8, provider discovery uses the Hermes runtime
`hermes-agent/plugins/memory/igrep` directory. The installer refuses to place
the provider in an unscanned fallback directory.

Activation is explicit because Hermes allows one external memory provider at a
time:

```bash
hermes memory setup
```
