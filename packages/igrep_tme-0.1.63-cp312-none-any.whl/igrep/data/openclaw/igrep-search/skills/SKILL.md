# igrep Search

Use `igrep_search` for local filesystem, code, and document evidence that may
live outside OpenClaw `.igrep/mem/MEMORY.md`.

Natural-language search is the intended input path. Keep the user's
natural-language query intact. Do not invent OR-regex probes such as
`auth|login|token`; regex is only for exact literal/regex lookup in a known
narrow path.

When using OpenClaw `memory_search`, pass `corpus: "all"` to include igrep
supplement results alongside memory-core results. Use `igrep_get` or
`memory_get` with the returned path/ref to read exact evidence before relying on
a snippet.
