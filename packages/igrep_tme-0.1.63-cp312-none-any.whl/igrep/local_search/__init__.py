"""Internal modules for local no-index search."""
