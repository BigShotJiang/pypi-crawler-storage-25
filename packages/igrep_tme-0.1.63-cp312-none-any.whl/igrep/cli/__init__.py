# ruff: noqa: F401,F403
"""Compatibility facade for the split igrep CLI package."""

import sys as _sys
from types import ModuleType as _ModuleType

from . import _common as _common_module
from . import _main as _main_module
from . import chat as _chat_module
from . import ops as _ops_module
from . import parser as _parser_module
from . import routing as _routing_module
from . import search as _search_module
from . import setup as _setup_module
from ._common import *
from ._main import *
from .chat import *
from .ops import *
from .parser import *
from .routing import *
from .search import *
from .setup import *

_COMPAT_MODULES = (
    _common_module,
    _main_module,
    _chat_module,
    _ops_module,
    _parser_module,
    _routing_module,
    _search_module,
    _setup_module,
)
_COMPAT_TARGETS: dict[str, list[_ModuleType]] = {}
_facade_names = set(globals())
for _module in _COMPAT_MODULES:
    for _name in _facade_names.intersection(vars(_module)):
        if _name.startswith("__"):
            continue
        _COMPAT_TARGETS.setdefault(_name, []).append(_module)


class _CliFacadeModule(_ModuleType):
    """Keep old single-module monkeypatch semantics after the CLI split."""

    def __setattr__(self, name: str, value: object) -> None:
        super().__setattr__(name, value)
        for module in _COMPAT_TARGETS.get(name, ()):
            setattr(module, name, value)


_sys.modules[__name__].__class__ = _CliFacadeModule
