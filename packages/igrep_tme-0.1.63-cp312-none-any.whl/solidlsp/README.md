# SolidLSP (igrep 内嵌副本)

本目录是从 Serena 上游同步的 SolidLSP 副本，并保留少量 igrep 本地兼容层。

## 权威同步流程

请使用仓库根目录脚本，不要手工 copy：

```bash
./scripts/update_serena_mirror.sh [tag-or-commit]
./scripts/sync_solidlsp_from_subtree.sh --verify-idempotent
./scripts/check_solidlsp_drift.sh --strict
```

`third_party/serena/UPSTREAM.toml` 记录当前 Serena pinned commit。需要最新 main
时可以直接省略参数；脚本会拉取 upstream main，但落盘的 `ref` / `commit` 会写成解析
后的固定 commit SHA。合入前不要让 `ref` 保持 `main` / `master` 这种浮动值。

## 本地定制点

- `serena_compat.py`：替代 Serena/sensai 内部工具依赖。
- `settings.py`：保留 `CustomLSSettings` 的轻量本地表示。
- `util/dotnet.py`：保留本地 `DotNETUtil`，避免依赖 Serena 外围包。

## 兼容脚本

`sync_from_serena.sh` 与 `verify_solidlsp.sh` 仍保留为兼容入口；
实际逻辑在仓库根目录 `scripts/` 下。
