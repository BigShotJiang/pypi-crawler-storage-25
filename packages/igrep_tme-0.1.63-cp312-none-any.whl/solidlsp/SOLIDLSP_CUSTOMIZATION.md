# solidlsp 本地定制说明

本文件是 `src/solidlsp/` 的最小定制清单，作为同步后的验收依据。

## 同步来源

- 上游镜像：`third_party/serena/src/solidlsp`
- 镜像更新：`scripts/update_serena_mirror.sh [tag-or-commit]`
- 同步脚本：`scripts/sync_solidlsp_from_subtree.sh`
- 漂移检查：`scripts/check_solidlsp_drift.sh`

省略 ref 时会拉取 Serena upstream main，并把解析后的 commit SHA 写入
`third_party/serena/UPSTREAM.toml`。合入前 strict 检查会拒绝浮动 `main` /
`master` ref。

## 定制策略

所有可重放定制必须以补丁形式存在于 `patches/solidlsp/`，并由
`scripts/check_solidlsp_drift.sh --strict` 校验，禁止未记录的手工散改。

当前补丁：

1. `0001-use-local-serena-compat.patch`
   - 将 Serena/sensai 工具引用改为本地 `solidlsp.serena_compat`。
   - 保留轻量 `CustomLSSettings`，避免依赖 Serena 外围包。
   - 替换 Elm/TypeScript `LogTime`、C#/F# `DotNETUtil` 的外围依赖。

## 不可覆盖文件

这些文件是本地资产，`sync` 脚本会排除覆盖：

- `src/solidlsp/serena_compat.py`
- `src/solidlsp/test_serena_compat.py`
- `src/solidlsp/README.md`
- `src/solidlsp/SOLIDLSP_CUSTOMIZATION.md`
- `src/solidlsp/LSP_SPEC_README.md`
- `src/solidlsp/lsp_protocol_complete.md`
- `src/solidlsp/sync_from_serena.sh`
- `src/solidlsp/verify_solidlsp.sh`
- `src/solidlsp/util/dotnet.py`
