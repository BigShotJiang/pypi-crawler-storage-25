#!/usr/bin/env bash
# Backward-compatible quick verification entrypoint.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
PYTHON_BIN="${PYTHON:-python3}"

echo "[INFO] running drift check (strict)"
bash "$PROJECT_ROOT/scripts/check_solidlsp_drift.sh" --strict

echo "[INFO] running import checks"
PYTHONPATH="$PROJECT_ROOT/src${PYTHONPATH:+:$PYTHONPATH}" "$PYTHON_BIN" -c "from solidlsp.ls import SolidLanguageServer" >/dev/null
PYTHONPATH="$PROJECT_ROOT/src${PYTHONPATH:+:$PYTHONPATH}" "$PYTHON_BIN" -c "from solidlsp.settings import SolidLSPSettings" >/dev/null
PYTHONPATH="$PROJECT_ROOT/src${PYTHONPATH:+:$PYTHONPATH}" "$PYTHON_BIN" -c "from solidlsp.serena_compat import MatchedConsecutiveLines" >/dev/null

echo "[OK] solidlsp verify passed"
