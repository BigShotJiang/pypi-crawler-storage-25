"""mitmproxy addon — intercepts LLM API traffic, attributes, and stores."""

import json
import os
import subprocess
import sys
import threading
import time

# Support both relative imports (tests) and standalone loading (mitmdump -s)
try:
    from .capture import extract_usage, PROVIDER_MAP
    from .attribute import get_git_info
    from .store import EventStore
    from .session import extract_transcript, get_session_id
    from .copilot_agent import extract_file_edits
except ImportError:
    _pkg_dir = os.path.dirname(os.path.abspath(__file__))
    if _pkg_dir not in sys.path:
        sys.path.insert(0, _pkg_dir)
    from capture import extract_usage, PROVIDER_MAP
    from attribute import get_git_info
    from store import EventStore
    from session import extract_transcript, get_session_id
    from copilot_agent import extract_file_edits

COPILOT_HOSTS = {"api.githubcopilot.com", "copilot-proxy.githubusercontent.com"}
_CHECKPOINT_DELAY_SECS = 3


def get_pid_cwd(flow):
    """Get the working directory of the process that made the request.

    Platform-specific: uses lsof on macOS/Linux.
    Returns cwd string or None.
    """
    try:
        port = flow.client_conn.peername[1]
        out = subprocess.check_output(
            ["lsof", "-i", f"TCP:{port}", "-F", "p"],
            text=True, timeout=2, stderr=subprocess.DEVNULL,
        )
        for line in out.strip().split("\n"):
            if line.startswith("p"):
                pid = line[1:]
                cwd = subprocess.check_output(
                    ["lsof", "-p", pid, "-d", "cwd", "-F", "n"],
                    text=True, timeout=2, stderr=subprocess.DEVNULL,
                )
                for cwd_line in cwd.strip().split("\n"):
                    if cwd_line.startswith("n") and cwd_line != "ncwd":
                        return cwd_line[1:]
    except Exception:
        pass
    return None


def get_process_name(flow):
    """Get the name of the process that made the request."""
    try:
        port = flow.client_conn.peername[1]
        out = subprocess.check_output(
            ["lsof", "-i", f"TCP:{port}", "-F", "c"],
            text=True, timeout=2, stderr=subprocess.DEVNULL,
        )
        for line in out.strip().split("\n"):
            if line.startswith("c"):
                return line[1:]
    except Exception:
        pass
    return "unknown"


def get_pid_from_flow(flow):
    """Get (pid, ppid) of the process that made the request."""
    try:
        port = flow.client_conn.peername[1]
        out = subprocess.check_output(
            ["lsof", "-i", f"TCP:{port}", "-F", "pR"],
            text=True, timeout=2, stderr=subprocess.DEVNULL,
        )
        pid = None
        ppid = None
        for line in out.strip().split("\n"):
            if line.startswith("p"):
                pid = int(line[1:])
            elif line.startswith("R"):
                ppid = int(line[1:])
        return (pid, ppid)
    except Exception:
        return (None, None)


def _resolve_process_info(flow):
    """Resolve PID, cwd, process name, ppid from flow's client connection.

    Must be called while the client connection is still alive (in request hook).
    """
    try:
        port = flow.client_conn.peername[1]
        out = subprocess.check_output(
            ["lsof", "-i", f"TCP:{port}", "-F", "pcRn"],
            text=True, timeout=2, stderr=subprocess.DEVNULL,
        )
        pid = None
        ppid = None
        pname = "unknown"
        cwd = None
        for line in out.strip().split("\n"):
            if line.startswith("p"):
                pid = int(line[1:])
            elif line.startswith("c"):
                pname = line[1:]
            elif line.startswith("R"):
                ppid = int(line[1:])
        if pid:
            cwd_out = subprocess.check_output(
                ["lsof", "-p", str(pid), "-d", "cwd", "-F", "n"],
                text=True, timeout=2, stderr=subprocess.DEVNULL,
            )
            for cwd_line in cwd_out.strip().split("\n"):
                if cwd_line.startswith("n") and cwd_line != "ncwd":
                    cwd = cwd_line[1:]
        return {"pid": pid, "ppid": ppid, "pname": pname, "cwd": cwd}
    except Exception:
        return {"pid": None, "ppid": None, "pname": "unknown", "cwd": None}


class LLMTrackerAddon:
    """mitmproxy addon that captures LLM usage and stores attributed events."""

    def __init__(self, store_path=None):
        from pathlib import Path

        if store_path is None:
            store_path = str(Path.home() / ".claude" / "proxy_events.jsonl")
        self._store = EventStore(store_path)
        self._flow_info = {}  # flow.id -> process info
        self._copilot_snapshots = {}  # tool_call_id -> {file: content}

    def _parse_sse_usage(self, host, content):
        """Extract usage from a streaming SSE response.

        Anthropic streams end with a message_delta event containing usage.
        OpenAI streams end with a [DONE] chunk, usage is in the last data chunk.
        """
        model = None
        usage = {}
        for line in content.decode("utf-8", errors="replace").split("\n"):
            if not line.startswith("data: "):
                continue
            data_str = line[6:].strip()
            if data_str == "[DONE]":
                continue
            try:
                data = json.loads(data_str)
            except (json.JSONDecodeError, ValueError):
                continue
            # Anthropic: message_start has the model
            if data.get("type") == "message_start" and "message" in data:
                model = data["message"].get("model")
            # Anthropic: message_delta has usage
            if data.get("type") == "message_delta" and "usage" in data:
                usage = data["usage"]
            # OpenAI: each chunk may have usage in the last one
            if data.get("model"):
                model = data["model"]
            if data.get("usage"):
                usage = data["usage"]
        if usage and model:
            return extract_usage(host, {"model": model, "usage": usage})
        return None

    def request(self, flow):
        """Capture process info while client connection is alive."""
        if flow.request.host in PROVIDER_MAP:
            self._flow_info[id(flow)] = _resolve_process_info(flow)

    def response(self, flow):
        if flow.request.host not in PROVIDER_MAP:
            return

        content_type = flow.response.headers.get("content-type", "")
        is_sse = "text/event-stream" in content_type

        if is_sse:
            usage_event = self._parse_sse_usage(flow.request.host, flow.response.content)
        else:
            try:
                body = json.loads(flow.response.content)
            except (json.JSONDecodeError, UnicodeDecodeError):
                return
            if not isinstance(body, dict):
                return
            usage_event = extract_usage(flow.request.host, body)

        if usage_event is None:
            self._flow_info.pop(id(flow), None)
            return

        # Use process info captured during request (connection was alive)
        pinfo = self._flow_info.pop(id(flow), None) or _resolve_process_info(flow)
        cwd = pinfo["cwd"]
        git_info = get_git_info(cwd) if cwd else {"repo": None, "branch": None, "git_user": None}

        # Transcript from request body
        transcript = None
        try:
            req_body = json.loads(flow.request.content)
            transcript = extract_transcript(req_body)
        except Exception:
            pass

        event = {
            **usage_event,
            "tool": pinfo["pname"],
            "repo": git_info["repo"],
            "branch": git_info["branch"],
            "git_user": git_info["git_user"],
            "session_id": get_session_id(pid=pinfo["pid"], ppid=pinfo["ppid"]),
            "transcript": transcript,
            "timestamp": getattr(flow, "timestamp_end", None) or flow.timestamp_created,
        }

        self._store.append(event)

        # Copilot Agent: check for file edits and create checkpoints
        if flow.request.host in COPILOT_HOSTS:
            self._handle_copilot_edits(flow, pinfo)

    def _handle_copilot_edits(self, flow, pinfo):
        """Detect Copilot Agent file edits and trigger ai-checkpoint."""
        cwd = pinfo.get("cwd")
        if not cwd:
            return

        content_type = flow.response.headers.get("content-type", "")
        is_sse = "text/event-stream" in content_type

        # Parse the response body for tool_calls
        if is_sse:
            body = self._assemble_sse_body(flow.response.content)
        else:
            try:
                body = json.loads(flow.response.content)
            except (json.JSONDecodeError, UnicodeDecodeError):
                return

        edits = extract_file_edits(body)
        if not edits:
            return

        # Snapshot current file state (pre-edit) and schedule post-edit check
        from pathlib import Path
        for edit in edits:
            abs_path = Path(cwd) / edit.file_path
            try:
                pre_content = abs_path.read_text(encoding="utf-8", errors="replace")
            except (OSError, UnicodeDecodeError):
                pre_content = ""  # new file

            self._copilot_snapshots[edit.tool_call_id] = {
                "file_path": edit.file_path,
                "pre_content": pre_content,
                "cwd": cwd,
                "model": edit.model,
                "tool_name": edit.tool_name,
                "tool_call_id": edit.tool_call_id,
                "session_id": get_session_id(pid=pinfo.get("pid"), ppid=pinfo.get("ppid")),
            }

            # Schedule delayed post-edit checkpoint
            threading.Thread(
                target=self._delayed_copilot_checkpoint,
                args=(edit.tool_call_id,),
                daemon=True,
            ).start()

    def _delayed_copilot_checkpoint(self, tool_call_id):
        """Wait for VS Code to apply the edit, then compute attribution."""
        time.sleep(_CHECKPOINT_DELAY_SECS)

        snapshot = self._copilot_snapshots.pop(tool_call_id, None)
        if not snapshot:
            return

        try:
            from pathlib import Path
            from claudedashboard.gitai.models import NormalizedHookInput, HookEvent
            from claudedashboard.gitai.checkpoint import CheckpointEngine
            from claudedashboard.gitai.git_notes import get_repo_root

            cwd = snapshot["cwd"]
            repo_root = get_repo_root(cwd)
            if not repo_root:
                return

            abs_path = Path(cwd) / snapshot["file_path"]
            try:
                post_content = abs_path.read_text(encoding="utf-8", errors="replace")
            except (OSError, UnicodeDecodeError):
                return

            # No change → user discarded the edit
            if post_content == snapshot["pre_content"]:
                return

            # Create pre-snapshot, then compute attribution
            engine = CheckpointEngine(repo_root)

            hook_pre = NormalizedHookInput(
                event=HookEvent.PRE_TOOL_USE,
                agent="copilot",
                session_id=snapshot["session_id"],
                tool_name="Write",
                tool_input={"file_path": str(abs_path)},
                tool_use_id=tool_call_id,
                cwd=cwd,
                model=snapshot["model"],
            )

            # Save pre-snapshot manually (file content before edit)
            engine.working_log.save_snapshot(tool_call_id, {
                snapshot["file_path"]: snapshot["pre_content"]
            })

            hook_post = NormalizedHookInput(
                event=HookEvent.POST_TOOL_USE,
                agent="copilot",
                session_id=snapshot["session_id"],
                tool_name="Write",
                tool_input={"file_path": str(abs_path)},
                tool_use_id=tool_call_id,
                cwd=cwd,
                model=snapshot["model"],
            )
            engine.handle_post_tool_use(hook_post)

        except Exception as e:
            print(f"copilot checkpoint error: {e}", file=sys.stderr)

    def _assemble_sse_body(self, content):
        """Assemble SSE chunks into a single response body with tool_calls."""
        model = None
        tool_calls = []
        usage = {}

        for line in content.decode("utf-8", errors="replace").split("\n"):
            if not line.startswith("data: "):
                continue
            data_str = line[6:].strip()
            if data_str == "[DONE]":
                continue
            try:
                data = json.loads(data_str)
            except (json.JSONDecodeError, ValueError):
                continue

            if data.get("model"):
                model = data["model"]
            if data.get("usage"):
                usage = data["usage"]

            # Accumulate tool_call chunks
            for choice in data.get("choices", []):
                delta = choice.get("delta", {})
                for tc in delta.get("tool_calls", []):
                    idx = tc.get("index", 0)
                    while len(tool_calls) <= idx:
                        tool_calls.append({"id": "", "type": "function",
                                           "function": {"name": "", "arguments": ""}})
                    if tc.get("id"):
                        tool_calls[idx]["id"] = tc["id"]
                    func = tc.get("function", {})
                    if func.get("name"):
                        tool_calls[idx]["function"]["name"] = func["name"]
                    if func.get("arguments"):
                        tool_calls[idx]["function"]["arguments"] += func["arguments"]

        result = {"model": model or "", "usage": usage}
        if tool_calls:
            result["choices"] = [{"message": {"tool_calls": tool_calls}}]
        return result

    def websocket_message(self, flow):
        """Handle WebSocket messages (Codex uses WebSocket via ab.chatgpt.com)."""
        if flow.request.host not in PROVIDER_MAP:
            return

        # Only look at server->client messages
        msg = flow.websocket.messages[-1]
        if msg.from_client:
            return

        try:
            data = json.loads(msg.content)
        except (json.JSONDecodeError, UnicodeDecodeError, TypeError):
            return

        if not isinstance(data, dict):
            return

        # OpenAI realtime/WebSocket format: look for usage in response
        usage = data.get("usage")
        model = data.get("model")

        # Codex may nest differently — also check response.usage
        if not usage and "response" in data:
            resp = data["response"]
            usage = resp.get("usage") if isinstance(resp, dict) else None
            model = model or (resp.get("model") if isinstance(resp, dict) else None)

        if not usage or not model:
            return

        usage_event = extract_usage(flow.request.host, {"model": model, "usage": usage})
        if usage_event is None:
            return

        # Attribution — use flow info if captured, or resolve now
        pinfo = self._flow_info.get(id(flow)) or _resolve_process_info(flow)
        cwd = pinfo["cwd"]
        git_info = get_git_info(cwd) if cwd else {"repo": None, "branch": None, "git_user": None}

        event = {
            **usage_event,
            "tool": pinfo["pname"],
            "repo": git_info["repo"],
            "branch": git_info["branch"],
            "git_user": git_info["git_user"],
            "session_id": get_session_id(pid=pinfo["pid"], ppid=pinfo["ppid"]),
            "transcript": None,  # WebSocket doesn't have easy request body
            "timestamp": time.time(),
        }

        self._store.append(event)


# mitmproxy script entry point
addons = [LLMTrackerAddon(store_path=os.environ.get("LLM_PROXY_STORE_PATH"))]
