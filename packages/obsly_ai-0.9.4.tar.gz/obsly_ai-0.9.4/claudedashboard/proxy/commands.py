"""CLI commands for proxy, server, doctor, config."""

import json
import os
import subprocess
import shutil
import sys
import webbrowser
from pathlib import Path

DEFAULT_CONFIG = {
    "proxy_port": 8080,
    "server_port": 8800,
    "events_path": str(Path.home() / ".claude" / "proxy_events.jsonl"),
    "llm_domains": [
        "api.anthropic.com",
        "api.openai.com",
        "api.githubcopilot.com",
        "copilot-proxy.githubusercontent.com",
        "api.mistral.ai",
        "api.deepseek.com",
        "generativelanguage.googleapis.com",
    ],
}

CONFIG_PATH = Path.home() / ".claude" / "proxy_config.json"


def _load_config():
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH) as f:
            saved = json.load(f)
        return {**DEFAULT_CONFIG, **saved}
    return dict(DEFAULT_CONFIG)


def _save_config(config):
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)


def cmd_proxy(port=None, no_browser=False):
    """Launch mitmproxy with the LLM tracker addon."""
    config = _load_config()
    port = port or config["proxy_port"]
    events_path = config["events_path"]

    mitmdump = shutil.which("mitmdump")
    if not mitmdump:
        print("Error: mitmdump not found. Install: pip install mitmproxy")
        sys.exit(1)

    addon_path = Path(__file__).parent / "addon.py"

    print(f"Starting LLM proxy on :{port}")
    print(f"Events → {events_path}")
    print(f"Intercepting: {', '.join(config['llm_domains'])}")
    print()
    print("Configure your system proxy or run tools with:")
    print(f"  export HTTPS_PROXY=http://127.0.0.1:{port}")
    print()

    env = os.environ.copy()
    env["LLM_PROXY_STORE_PATH"] = events_path

    cmd = [
        mitmdump,
        "--listen-port", str(port),
        "-s", str(addon_path),
    ]

    try:
        subprocess.run(cmd, env=env)
    except KeyboardInterrupt:
        print("\nProxy stopped.")


def cmd_server(port=None, no_browser=False):
    """Launch the team dashboard web server."""
    config = _load_config()
    port = port or config["server_port"]
    events_path = config["events_path"]

    from .team_dashboard import create_app

    app = create_app(events_path=events_path)
    print(f"Team dashboard: http://localhost:{port}")
    print(f"Reading events from: {events_path}")

    if not no_browser:
        import threading
        threading.Timer(1.0, lambda: webbrowser.open(f"http://localhost:{port}")).start()

    app.run(host="127.0.0.1", port=port, debug=False)


def cmd_doctor():
    """Run integration health checks."""
    from .doctor import run_all

    ICONS = {"ok": "✅", "warn": "⚠️ ", "fail": "❌"}

    print("claude-dashboard doctor\n")
    results = run_all()
    for name, status, msg in results:
        icon = ICONS.get(status, "?")
        print(f"  {icon} {name}: {msg}")

    fails = sum(1 for _, s, _ in results if s == "fail")
    warns = sum(1 for _, s, _ in results if s == "warn")
    print()
    if fails:
        print(f"  {fails} issue(s) to fix before the proxy will work.")
    elif warns:
        print(f"  All good, {warns} warning(s).")
    else:
        print("  All checks passed. Ready to go!")


def cmd_config(action="show", key=None, value=None):
    """Show or update proxy configuration."""
    config = _load_config()

    if action == "show":
        print("Proxy configuration:\n")
        for k, v in config.items():
            print(f"  {k}: {json.dumps(v)}")
        print(f"\n  Config file: {CONFIG_PATH}")
        if not CONFIG_PATH.exists():
            print("  (using defaults, no config file yet)")

    elif action == "set" and key and value:
        # Try to parse as JSON for lists/numbers, fallback to string
        try:
            value = json.loads(value)
        except (json.JSONDecodeError, TypeError):
            pass
        config[key] = value
        _save_config(config)
        print(f"  Set {key} = {json.dumps(value)}")

    elif action == "reset":
        if CONFIG_PATH.exists():
            CONFIG_PATH.unlink()
        print("  Config reset to defaults.")
