"""Extract usage data from LLM API responses."""

PROVIDER_MAP = {
    "api.anthropic.com": "anthropic",
    "api.openai.com": "openai",
    "ab.chatgpt.com": "openai",
    "chatgpt.com": "openai",
    "api.githubcopilot.com": "github-copilot",
    "copilot-proxy.githubusercontent.com": "github-copilot",
    "api.mistral.ai": "mistral",
    "api.deepseek.com": "deepseek",
    "generativelanguage.googleapis.com": "google",
}

# Pricing per million tokens (input, output)
PRICING = {
    # Anthropic
    "claude-opus-4-6":   {"input": 15.0, "output": 75.0, "cache_read": 1.50, "cache_create": 18.75},
    "claude-sonnet-4-6": {"input": 3.0,  "output": 15.0, "cache_read": 0.30, "cache_create": 3.75},
    "claude-haiku-4-5":  {"input": 0.80, "output": 4.0,  "cache_read": 0.08, "cache_create": 1.00},
    # OpenAI
    "gpt-4o":            {"input": 2.50, "output": 10.0},
    "gpt-4o-mini":       {"input": 0.15, "output": 0.60},
    "o3":                {"input": 2.00, "output": 8.00},
    # DeepSeek
    "deepseek-chat":     {"input": 0.14, "output": 0.28},
    "deepseek-reasoner": {"input": 0.55, "output": 2.19},
}

DEFAULT_PRICING = {"input": 3.0, "output": 15.0, "cache_read": 0.30, "cache_create": 3.75}


def _calc_cost(model, tokens_in, tokens_out, cache_read=0, cache_create=0):
    p = PRICING.get(model, DEFAULT_PRICING)
    cost = (
        tokens_in * p["input"] / 1_000_000
        + tokens_out * p["output"] / 1_000_000
        + cache_read * p.get("cache_read", 0) / 1_000_000
        + cache_create * p.get("cache_create", 0) / 1_000_000
    )
    return round(cost, 6)


def _match_model(model_str):
    """Match a full model string to a known pricing key."""
    if not model_str:
        return None
    for key in PRICING:
        if model_str.startswith(key):
            return key
    return None


def extract_usage(host, body):
    """Extract usage event from an LLM API response body.

    Returns a dict with provider, model, tokens, cost — or None if not applicable.
    """
    provider = PROVIDER_MAP.get(host)
    if provider is None:
        return None

    usage = body.get("usage")
    if not usage:
        return None

    model = body.get("model", "")

    # Anthropic uses input_tokens/output_tokens
    # OpenAI and others use prompt_tokens/completion_tokens
    tokens_in = usage.get("input_tokens") or usage.get("prompt_tokens") or 0
    tokens_out = usage.get("output_tokens") or usage.get("completion_tokens") or 0
    cache_read = usage.get("cache_read_input_tokens", 0)
    cache_create = usage.get("cache_creation_input_tokens", 0)

    pricing_key = _match_model(model) or model
    cost = _calc_cost(pricing_key, tokens_in, tokens_out, cache_read, cache_create)

    return {
        "provider": provider,
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cache_read": cache_read,
        "cache_create": cache_create,
        "cost": cost,
    }
