"""Loopback OAuth login flow for obsly-ai CLI. Stdlib only (Tier 1)."""

import http.server
import json
import secrets
import threading
import time
import webbrowser
from urllib.parse import parse_qs, urlparse


def _find_free_port():
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def run_login(server_url="https://ai.obsly.io", timeout=120):
    """Open browser for OAuth, capture device token via loopback redirect.

    Returns the device token string, or None on timeout/failure.
    """
    port = _find_free_port()
    state = secrets.token_urlsafe(32)
    result = {"token": None}

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path != "/callback":
                self.send_response(404)
                self.end_headers()
                return

            params = parse_qs(parsed.query)
            received_state = params.get("state", [""])[0]
            token = params.get("device_token", [""])[0]

            if received_state != state:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"State mismatch. Please try again.")
                return

            result["token"] = token
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(
                b"<html><body><h2>Login successful!</h2>"
                b"<p>You can close this tab and return to the terminal.</p>"
                b"</body></html>"
            )

        def log_message(self, format, *args):
            pass  # suppress http.server logs

    server = http.server.HTTPServer(("127.0.0.1", port), Handler)
    server.timeout = 2

    redirect_uri = f"http://localhost:{port}/callback"
    login_url = (
        f"{server_url}/auth/cli-login"
        f"?redirect_uri={redirect_uri}"
        f"&state={state}"
    )

    print("Opening browser for login...")
    print(f"  {login_url}")
    webbrowser.open(login_url)
    print(f"Waiting for callback on localhost:{port} (timeout {timeout}s)...")

    deadline = time.monotonic() + timeout
    while result["token"] is None and time.monotonic() < deadline:
        server.handle_request()

    server.server_close()
    return result["token"]
