"""Cross-platform tray icon for Claude/Codex usage.

Dispatches to one of two backends depending on the host OS:

- macOS   -> rumps (rich native menubar, same implementation as
             claudedashboard.menubar)
- Windows/Linux -> pystray (system tray icon, menu, refresh timer)

Both backends read the same live dashboard API (port 8765) and render a
compact status line plus a contextual menu with the key percentages, a
"Refresh now" action and shortcuts to open the personal / team
dashboards in the default browser.

All heavy UI imports (rumps, pystray, Pillow) are lazy so that importing
this module on a machine without the tray extras installed is a no-op.
"""

import json
import os
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import datetime
from pathlib import Path
from urllib.request import urlopen

DASHBOARD_URL = "http://localhost:8765/api"
DASHBOARD_HTML = "http://localhost:8765"
TEAM_HTML = "http://localhost:8800"
POLL_INTERVAL = 65  # seconds, offset from live dashboard's 60s poll
API_CACHE_FILE = os.path.expanduser("~/.claude/.dashboard_api_cache.json")


# ── Port / server helpers ────────────────────────────────────────────────

def _is_port_open(host, port):
    """Return True if a TCP connection to host:port succeeds."""
    try:
        with socket.create_connection((host, port), timeout=1):
            return True
    except (OSError, ConnectionRefusedError):
        return False


def ensure_live_server():
    """Launch live.py in the background if it is not already running."""
    if _is_port_open("127.0.0.1", 8765):
        return
    try:
        subprocess.Popen(
            [sys.executable, "-m", "claudedashboard.live", "--no-browser"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass


# ── Cache fallback ───────────────────────────────────────────────────────

def _load_disk_cache(path=None):
    """Read the Anthropic API cache from disk. Returns dict or None."""
    p = path or API_CACHE_FILE
    try:
        with open(p, "r") as f:
            return json.loads(f.read())
    except Exception:
        return None


def _snapshot_from_cache(cache):
    """Build a minimal snapshot dict from the on-disk cache. Returns None if unusable."""
    if not cache:
        return None
    snap = {
        "anthropic": {
            "seven_day_pct": cache.get("seven_day_pct"),
            "sonnet_pct": cache.get("sonnet_pct"),
            "five_hour_pct": cache.get("five_hour_pct"),
            "seven_day_resets": cache.get("seven_day_resets"),
            "five_hour_resets": cache.get("five_hour_resets"),
            "fetched_at": cache.get("fetched_at"),
        },
        "codex_week": {},
        "session_costs": [],
        "burn_rate": None,
        "week_api_cost": 0,
        "month_api_cost": 0,
        "_from_cache": True,
    }
    return snap


# ── Shared data access ────────────────────────────────────────────────────

def fetch_snapshot():
    """Read full snapshot from the live dashboard API. Falls back to disk cache."""
    try:
        with urlopen(DASHBOARD_URL, timeout=5) as r:
            return json.loads(r.read())
    except Exception:
        pass
    # Server unreachable — try the on-disk cache
    cached = _load_disk_cache()
    return _snapshot_from_cache(cached) or {}


# ── Pure formatters (tested) ──────────────────────────────────────────────

def _pct(value):
    """Render a percentage like '42%' or '-' when missing."""
    if value is None:
        return "-"
    try:
        return f"{float(value):.0f}%"
    except (TypeError, ValueError):
        return "-"


def format_title(snapshot):
    """Return the short status line shown in the tray tooltip / title."""
    snapshot = snapshot or {}
    a = snapshot.get("anthropic") or {}
    c = snapshot.get("codex_week") or {}
    claude = _pct(a.get("seven_day_pct"))
    codex = _pct(c.get("seven_day_pct"))
    return f"Claude: {claude} | Codex: {codex}"


def format_menu_items(snapshot):
    """Return a list of plain strings to render as menu rows."""
    snapshot = snapshot or {}
    a = snapshot.get("anthropic") or {}
    c = snapshot.get("codex_week") or {}

    weekly = a.get("seven_day_pct")
    sonnet = a.get("sonnet_pct")
    fh = a.get("five_hour_pct")
    codex_week = c.get("seven_day_pct")
    codex_fh = c.get("five_hour_pct")
    codex_plan = c.get("plan_type") or "-"

    lines = [
        f"Weekly (all models): {_pct(weekly)}",
        f"Sonnet only: {_pct(sonnet)}",
        f"5h window: {_pct(fh)}",
        f"Codex 7d: {_pct(codex_week)} ({codex_plan})",
        f"Codex 5h: {_pct(codex_fh)}",
    ]

    burn = snapshot.get("burn_rate") or {}
    pace = burn.get("avg_pace")
    if pace is not None:
        sus = burn.get("sustainable")
        if sus is not None and pace > sus:
            lines.append(f"Pace: {pace:.1f}%/day - over budget (max {sus:.1f}%/day)")
        elif sus is not None:
            lines.append(f"Pace: {pace:.1f}%/day - on track (max {sus:.1f}%/day)")
        else:
            lines.append(f"Pace: {pace:.1f}%/day")

    return lines


# ── Alert formatters & helpers (tested) ───────────────────────────────────

def format_alert_items(alerts):
    """Return a list of strings to render as menu rows for the alerts section.

    Each line: 'YYYY-MM-DD HH:MM  $X.XX  <repo-basename>'. Empty list if no
    alerts. `alerts` is the output of cost_alerts.load_alerts() — a list of
    Alert-like objects (anything with timestamp, cost_usd, repo_path attrs).
    """
    if not alerts:
        return []
    lines = []
    for a in alerts:
        try:
            ts = datetime.fromtimestamp(float(a.timestamp)).strftime("%Y-%m-%d %H:%M")
        except Exception:
            ts = "----"
        try:
            cost = f"${float(a.cost_usd):.2f}"
        except Exception:
            cost = "$?.??"
        try:
            repo = Path(str(a.repo_path).rstrip("/")).name or "?"
        except Exception:
            repo = "?"
        lines.append(f"{ts}  {cost}  {repo}")
    return lines


def format_title_with_alerts(snapshot, unread_count):
    """Return the tray title. Prepend '(!N) ' when unread_count > 0. Append ' [cached]' when stale."""
    base = format_title(snapshot)
    try:
        n = int(unread_count or 0)
    except (TypeError, ValueError):
        n = 0
    if n > 0:
        base = f"(!{n}) {base}"
    if snapshot and snapshot.get("_from_cache"):
        base = f"{base} [cached]"
    return base


def load_recent_alerts(limit=10):
    """Best-effort wrapper around cost_alerts.load_alerts(limit=limit)."""
    try:
        from claudedashboard.gitai import cost_alerts
        return cost_alerts.load_alerts(limit=limit)
    except Exception:
        return []


def count_unread_alerts():
    """Best-effort unread alert counter. Returns int (0 on failure)."""
    try:
        from claudedashboard.gitai import cost_alerts
        return len(cost_alerts.load_alerts(unread_only=True))
    except Exception:
        return 0


# ── Proxy indicator helpers (tested) ──────────────────────────────────────

def proxy_status_label(status_string):
    """Map a proxy_service.status() result to a menu label."""
    if status_string == "running":
        return "Proxy: [Running] - click to stop"
    if status_string == "stopped":
        return "Proxy: [Stopped] - click to start"
    if status_string == "not_installed":
        return "Proxy: [Not installed] - click to install"
    return "Proxy: [Unknown]"


def compute_last_hour_proxy_stats(events_path, *, now=None):
    """Sum count + cost of proxy events in the last 3600s. Never raises."""
    if now is None:
        now = time.time()
    result = {"count": 0, "cost_usd": 0.0}
    try:
        if not events_path or not os.path.exists(events_path):
            return result
        cutoff = float(now) - 3600.0
        with open(events_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                except Exception:
                    continue
                if not isinstance(ev, dict):
                    continue
                raw_ts = ev.get("timestamp", ev.get("ts"))
                if raw_ts is None:
                    continue
                try:
                    ts = float(raw_ts)
                except (TypeError, ValueError):
                    continue
                if ts <= cutoff or ts > float(now):
                    continue
                try:
                    cost = float(ev.get("cost_usd", ev.get("cost", 0.0)) or 0.0)
                except (TypeError, ValueError):
                    cost = 0.0
                result["count"] += 1
                result["cost_usd"] += cost
    except Exception:
        return result
    return result


def format_proxy_stats_line(stats):
    """Render last-hour stats as a menu row."""
    stats = stats or {}
    count = int(stats.get("count", 0) or 0)
    cost = float(stats.get("cost_usd", 0.0) or 0.0)
    if count == 0 and cost == 0.0:
        return "Last 1h: no traffic"
    return f"Last 1h: {count} events / ${cost:.2f}"


def get_proxy_status_safe(status_func=None):
    """Call proxy_service.status() and return the string. Returns 'unknown' on error."""
    try:
        if status_func is None:
            from claudedashboard import proxy_service
            return proxy_service.status()
        return status_func()
    except Exception:
        return "unknown"


def toggle_proxy(status_func=None, install_func=None, uninstall_func=None):
    """Click handler: read status, then install or uninstall accordingly."""
    try:
        current = status_func() if status_func else None
    except Exception:
        return {"action": "status", "ok": False, "message": "status check failed"}

    if current == "running":
        try:
            uninstall_func()
            return {"action": "uninstall", "ok": True, "message": None}
        except Exception as e:
            return {"action": "uninstall", "ok": False, "message": str(e)}

    # stopped, not_installed, or anything else -> try install
    try:
        res = install_func() or {}
        if res.get("refused"):
            msg = res.get("reason") or "install refused"
            return {"action": "install", "ok": False, "message": msg}
        if res.get("bootstrap_ok") is False and res.get("bootstrap_msg"):
            return {
                "action": "install",
                "ok": False,
                "message": res.get("bootstrap_msg"),
            }
        return {"action": "install", "ok": True, "message": None}
    except Exception as e:
        return {"action": "install", "ok": False, "message": str(e)}


# ── Backend dispatch ──────────────────────────────────────────────────────

def choose_backend(platform=None):
    """Return 'rumps' or 'pystray' based on the host platform string."""
    plat = platform if platform is not None else sys.platform
    if plat == "darwin":
        return "rumps"
    # win32, linux, linux2, freebsd*, cygwin, ... -> pystray
    return "pystray"


def _open_dashboard():
    try:
        webbrowser.open(DASHBOARD_HTML)
    except Exception:
        pass


def _open_team():
    try:
        webbrowser.open(TEAM_HTML)
    except Exception:
        pass


def _make_pystray_alert_callback(timestamp, refresh_callback):
    """Return a pystray menu callback that marks an alert read and refreshes."""
    def _cb(*_):
        try:
            from claudedashboard.gitai.cost_alerts import mark_alert_read
            mark_alert_read(timestamp)
            refresh_callback()
        except Exception:
            pass
    return _cb


def _on_pystray_proxy_click(icon, _item):
    """Pystray click handler for the proxy indicator row."""
    try:
        from claudedashboard import proxy_service as ps
        toggle_proxy(
            status_func=ps.status,
            install_func=ps.install,
            uninstall_func=ps.uninstall,
        )
        try:
            icon.update_menu()
        except Exception:
            pass
    except Exception:
        pass


def _run_rumps_backend():
    """Delegate to the existing macOS menubar implementation."""
    from claudedashboard.menubar import main as menubar_main
    menubar_main()


def _run_pystray_backend():
    """Run the pystray-based tray icon (Windows / Linux)."""
    try:
        import pystray
    except ImportError as e:
        raise ImportError(
            "pystray is required for the cross-platform tray. "
            "Install with: pipx install 'obsly-ai[tray]'"
        ) from e

    try:
        from PIL import Image, ImageDraw
    except ImportError as e:
        raise ImportError(
            "Pillow is required for the cross-platform tray. "
            "Install with: pipx install 'obsly-ai[tray]'"
        ) from e

    # State shared with the poll thread.
    state = {"snapshot": {}, "icon": None}

    def build_image(pct):
        """Draw a simple 64x64 icon whose fill colour reflects usage."""
        size = 64
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        # Background ring
        draw.ellipse((2, 2, size - 2, size - 2), outline=(180, 180, 180, 255), width=3)
        # Fill wedge proportional to pct
        if pct is None:
            color = (150, 150, 150, 255)
        elif pct < 60:
            color = (63, 185, 80, 255)
        elif pct < 75:
            color = (240, 136, 62, 255)
        elif pct < 90:
            color = (210, 153, 34, 255)
        else:
            color = (248, 81, 73, 255)
        try:
            start = -90
            sweep = 360 * (max(0.0, min(float(pct or 0), 100.0)) / 100.0)
            draw.pieslice((8, 8, size - 8, size - 8), start, start + sweep, fill=color)
        except Exception:
            pass
        return img

    def refresh(icon=None, _item=None):
        snap = fetch_snapshot()
        state["snapshot"] = snap
        a = snap.get("anthropic") or {}
        pct = a.get("seven_day_pct")
        unread = count_unread_alerts()
        new_title = format_title_with_alerts(snap, unread)
        if state["icon"] is not None:
            try:
                state["icon"].icon = build_image(pct)
                state["icon"].title = new_title
                state["icon"].menu = build_menu()
            except Exception:
                pass

    def quit_tray(icon, _item=None):
        try:
            icon.stop()
        except Exception:
            pass

    def build_menu():
        items = [pystray.MenuItem(line, None, enabled=False)
                 for line in format_menu_items(state["snapshot"])]

        # Proxy indicator section (0.6.0)
        ps_status = get_proxy_status_safe()
        items.append(pystray.Menu.SEPARATOR)
        items.append(pystray.MenuItem(
            proxy_status_label(ps_status),
            _on_pystray_proxy_click,
        ))
        try:
            from claudedashboard.proxy.commands import _load_config
            events_path = _load_config().get("events_path", "")
        except Exception:
            events_path = ""
        if events_path:
            stats = compute_last_hour_proxy_stats(events_path)
            items.append(pystray.MenuItem(
                format_proxy_stats_line(stats), None, enabled=False,
            ))

        alerts = load_recent_alerts(limit=10)
        if alerts:
            items.append(pystray.Menu.SEPARATOR)
            items.append(pystray.MenuItem("Recent spikes:", None, enabled=False))
            for alert in alerts:
                line = format_alert_items([alert])[0]
                ts = alert.timestamp
                items.append(pystray.MenuItem(
                    line, _make_pystray_alert_callback(ts, refresh)
                ))

        items.append(pystray.Menu.SEPARATOR)
        items.append(pystray.MenuItem("Open dashboard", lambda *_: _open_dashboard()))
        items.append(pystray.MenuItem("Open team dashboard", lambda *_: _open_team()))
        items.append(pystray.MenuItem("Refresh now", refresh))
        items.append(pystray.Menu.SEPARATOR)
        items.append(pystray.MenuItem("Quit", quit_tray))
        return pystray.Menu(*items)

    # Initial snapshot before starting the icon loop.
    state["snapshot"] = fetch_snapshot()
    initial_pct = (state["snapshot"].get("anthropic") or {}).get("seven_day_pct")

    icon = pystray.Icon(
        "obsly-ai",
        icon=build_image(initial_pct),
        title=format_title_with_alerts(state["snapshot"], count_unread_alerts()),
        menu=build_menu(),
    )
    state["icon"] = icon

    def poll_loop():
        while True:
            time.sleep(POLL_INTERVAL)
            try:
                refresh()
            except Exception:
                pass

    threading.Thread(target=poll_loop, daemon=True).start()
    icon.run()


def run_tray():
    """Entry point: dispatch to the correct backend for this platform."""
    backend = choose_backend()
    try:
        if backend == "rumps":
            _run_rumps_backend()
        else:
            _run_pystray_backend()
    except ImportError as e:
        print(
            f"tray backend not available: {e}\n"
            "Install the tray extras with:\n"
            "  pipx install 'obsly-ai[tray]'",
            file=sys.stderr,
        )
        sys.exit(1)


def main():
    run_tray()


if __name__ == "__main__":
    main()
