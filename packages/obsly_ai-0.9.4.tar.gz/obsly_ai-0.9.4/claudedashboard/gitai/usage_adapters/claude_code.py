"""Claude Code usage adapter — reads ~/.claude/projects/**/*.jsonl."""

import json
import os
from pathlib import Path
from claudedashboard.gitai.usage_adapters.base import UsageAdapter, UsageRecord
from claudedashboard.gitai.pricing import calc_cost, match_model


class ClaudeCodeAdapter(UsageAdapter):
    agent = "claude-code"

    def __init__(self, home_dir=None):
        self.home_dir = Path(home_dir) if home_dir else Path(os.path.expanduser("~"))
        self.projects_root = self.home_dir / ".claude" / "projects"

    def records_for_session(self, session_id):
        if not session_id or not self.projects_root.exists():
            return []

        # Claude Code typically names the file <session_id>.jsonl. Try that
        # first to avoid scanning thousands of unrelated files.
        candidates = list(self.projects_root.rglob(f"{session_id}.jsonl"))
        if not candidates:
            # Fallback: subagent files don't carry the session id in the
            # filename. Limit the recursive scan to a sensible budget so we
            # don't burn seconds on huge histories.
            max_files = 200
            candidates = []
            for i, p in enumerate(self.projects_root.rglob("*.jsonl")):
                if i >= max_files:
                    break
                candidates.append(p)

        records = []
        for jsonl in candidates:
            try:
                with jsonl.open("r", encoding="utf-8", errors="replace") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            entry = json.loads(line)
                        except (ValueError, json.JSONDecodeError):
                            continue
                        if entry.get("sessionId") != session_id:
                            continue
                        msg = entry.get("message") or {}
                        if not isinstance(msg, dict):
                            continue
                        if msg.get("role") != "assistant":
                            continue
                        usage = msg.get("usage") or {}
                        if not usage:
                            continue
                        model = msg.get("model") or ""
                        tokens_in = usage.get("input_tokens", 0) or 0
                        tokens_out = usage.get("output_tokens", 0) or 0
                        cache_read = usage.get("cache_read_input_tokens", 0) or 0
                        cache_create = usage.get("cache_creation_input_tokens", 0) or 0
                        cost = calc_cost(model, tokens_in, tokens_out, cache_read, cache_create)

                        # Extract tool_name and file_path from content blocks
                        tool_name, file_path = _extract_tool_info(msg.get("content"))

                        records.append(UsageRecord(
                            session_id=session_id,
                            timestamp=entry.get("timestamp", ""),
                            agent=self.agent,
                            model=match_model(model) or model,
                            tokens_in=tokens_in,
                            tokens_out=tokens_out,
                            cache_read=cache_read,
                            cache_create=cache_create,
                            equivalent_api_cost_usd=cost,
                            billed_usd=None,    # Claude Max plan: real charge unknown
                            plan=None,
                            tool_name=tool_name,
                            file_path=file_path,
                        ))
            except OSError:
                continue
        records.sort(key=lambda r: r.timestamp)
        return records


def _extract_tool_info(content):
    """Extract tool_name and file_path from message content blocks."""
    if not content or not isinstance(content, list):
        return None, None
    for block in content:
        if not isinstance(block, dict):
            continue
        if block.get("type") == "tool_use":
            name = block.get("name")
            inp = block.get("input") or {}
            file_path = inp.get("file_path")
            return name, file_path
    return None, None
