"""Base classes for usage adapters."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class UsageRecord:
    """One LLM API call's token usage + computed equivalent cost.

    `equivalent_api_cost_usd` is always populated (computed from tokens × the
    public API rate). `billed_usd` is only set if we actually know what the
    user was charged (per-token plans, or proxy data with billing info)."""
    session_id: str
    timestamp: str          # ISO-8601 string, sortable
    agent: str              # claude-code | codex | cursor | ...
    model: str
    tokens_in: int
    tokens_out: int
    cache_read: int
    cache_create: int
    equivalent_api_cost_usd: float
    billed_usd: Optional[float] = None
    plan: Optional[str] = None
    tool_name: Optional[str] = None   # Edit, Write, Read, Bash, etc.
    file_path: Optional[str] = None   # file affected (from tool_use input)


class UsageAdapter:
    """Interface every adapter implements. Subclasses set `agent` and override
    `records_for_session`."""
    agent: str = "unknown"

    def records_for_session(self, session_id):
        """Return list[UsageRecord] for the given session id. Empty if unknown."""
        return []

    def cost_for_session(self, session_id):
        return round(
            sum(r.equivalent_api_cost_usd for r in self.records_for_session(session_id)),
            6,
        )
