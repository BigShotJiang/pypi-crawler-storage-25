"""All data classes for the gitai attribution system."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict
import time


# ── Enums ────────────────────────────────────────────────────────────

class CheckpointKind(Enum):
    HUMAN = "human"
    AI_AGENT = "ai_agent"
    AI_TAB = "ai_tab"


class HookEvent(Enum):
    PRE_TOOL_USE = "PreToolUse"
    POST_TOOL_USE = "PostToolUse"
    STOP = "Stop"


# ── AgentId ──────────────────────────────────────────────────────────

@dataclass
class AgentId:
    tool: str
    id: str
    model: str

    def to_dict(self):
        return {"tool": self.tool, "id": self.id, "model": self.model}

    @classmethod
    def from_dict(cls, d):
        return cls(tool=d["tool"], id=d["id"], model=d["model"])


# ── LineAttribution ──────────────────────────────────────────────────

@dataclass
class LineAttribution:
    start_line: int
    end_line: int
    author_id: str
    overrode: Optional[str] = None

    def line_count(self):
        return self.end_line - self.start_line + 1

    def to_dict(self):
        return {
            "start_line": self.start_line,
            "end_line": self.end_line,
            "author_id": self.author_id,
            "overrode": self.overrode,
        }

    @classmethod
    def from_dict(cls, d):
        return cls(
            start_line=d["start_line"],
            end_line=d["end_line"],
            author_id=d["author_id"],
            overrode=d.get("overrode"),
        )


# ── LineRange ────────────────────────────────────────────────────────

@dataclass
class LineRange:
    start: int
    end: int

    def __str__(self):
        return str(self.start) if self.start == self.end else f"{self.start}-{self.end}"

    @staticmethod
    def compress(lines):
        """[1,2,3,5,6,10] -> [LineRange(1,3), LineRange(5,6), LineRange(10,10)]"""
        if not lines:
            return []
        result = []
        start = lines[0]
        prev = lines[0]
        for n in lines[1:]:
            if n == prev + 1:
                prev = n
            else:
                result.append(LineRange(start, prev))
                start = n
                prev = n
        result.append(LineRange(start, prev))
        return result

    @staticmethod
    def parse(s):
        """'1-3,5-6,10' -> [LineRange(1,3), LineRange(5,6), LineRange(10,10)]"""
        result = []
        for part in s.split(","):
            part = part.strip()
            if "-" in part:
                a, b = part.split("-", 1)
                result.append(LineRange(int(a), int(b)))
            else:
                n = int(part)
                result.append(LineRange(n, n))
        return result

    @staticmethod
    def format(ranges):
        """Inverse of parse."""
        return ",".join(str(r) for r in ranges)


# ── WorkingLogEntry ──────────────────────────────────────────────────

@dataclass
class WorkingLogEntry:
    file: str
    blob_sha: str
    line_attributions: List[LineAttribution] = field(default_factory=list)

    def to_dict(self):
        return {
            "file": self.file,
            "blob_sha": self.blob_sha,
            "line_attributions": [la.to_dict() for la in self.line_attributions],
        }

    @classmethod
    def from_dict(cls, d):
        return cls(
            file=d["file"],
            blob_sha=d["blob_sha"],
            line_attributions=[LineAttribution.from_dict(la) for la in d.get("line_attributions", [])],
        )


# ── Checkpoint ───────────────────────────────────────────────────────

@dataclass
class Checkpoint:
    kind: CheckpointKind
    author: str
    entries: List[WorkingLogEntry]
    timestamp_ms: int = field(default_factory=lambda: int(time.time() * 1000))
    agent_id: Optional[AgentId] = None
    transcript_messages: Optional[List[dict]] = None
    tool_use_id: Optional[str] = None
    cost_usd: Optional[float] = None       # cost of THIS specific edit
    tokens_in: Optional[int] = None
    tokens_out: Optional[int] = None
    cache_read: Optional[int] = None
    cache_create: Optional[int] = None

    def to_dict(self):
        d = {
            "kind": self.kind.value,
            "author": self.author,
            "entries": [e.to_dict() for e in self.entries],
            "timestamp_ms": self.timestamp_ms,
            "agent_id": self.agent_id.to_dict() if self.agent_id else None,
            "transcript_messages": self.transcript_messages,
            "tool_use_id": self.tool_use_id,
        }
        if self.cost_usd is not None:
            d["cost_usd"] = self.cost_usd
            d["tokens_in"] = self.tokens_in
            d["tokens_out"] = self.tokens_out
            d["cache_read"] = self.cache_read
            d["cache_create"] = self.cache_create
        return d

    @classmethod
    def from_dict(cls, d):
        agent_id = AgentId.from_dict(d["agent_id"]) if d.get("agent_id") else None
        return cls(
            kind=CheckpointKind(d["kind"]),
            author=d["author"],
            entries=[WorkingLogEntry.from_dict(e) for e in d["entries"]],
            timestamp_ms=d.get("timestamp_ms", 0),
            agent_id=agent_id,
            transcript_messages=d.get("transcript_messages"),
            tool_use_id=d.get("tool_use_id"),
            cost_usd=d.get("cost_usd"),
            tokens_in=d.get("tokens_in"),
            tokens_out=d.get("tokens_out"),
            cache_read=d.get("cache_read"),
            cache_create=d.get("cache_create"),
        )


# ── Attestation (Git Note) ──────────────────────────────────────────

@dataclass
class AttestationEntry:
    session_hash: str
    line_ranges: List[LineRange]


@dataclass
class FileAttestation:
    file_path: str
    entries: List[AttestationEntry]


@dataclass
class PromptRecord:
    agent_id: AgentId
    human_author: Optional[str] = None
    messages: List[dict] = field(default_factory=list)
    total_additions: int = 0
    total_deletions: int = 0
    accepted_lines: int = 0
    overridden_lines: int = 0
    messages_url: Optional[str] = None
    custom_attributes: Optional[Dict[str, str]] = None

    def to_dict(self):
        return {
            "agent_id": self.agent_id.to_dict(),
            "human_author": self.human_author,
            "messages": self.messages,
            "total_additions": self.total_additions,
            "total_deletions": self.total_deletions,
            "accepted_lines": self.accepted_lines,
            "overridden_lines": self.overridden_lines,
            "messages_url": self.messages_url,
            "custom_attributes": self.custom_attributes,
        }

    @classmethod
    def from_dict(cls, d):
        return cls(
            agent_id=AgentId.from_dict(d["agent_id"]),
            human_author=d.get("human_author"),
            messages=d.get("messages", []),
            total_additions=d.get("total_additions", 0),
            total_deletions=d.get("total_deletions", 0),
            accepted_lines=d.get("accepted_lines", 0),
            overridden_lines=d.get("overridden_lines", 0),
            messages_url=d.get("messages_url"),
            custom_attributes=d.get("custom_attributes"),
        )


# ── AuthorshipLog ────────────────────────────────────────────────────

@dataclass
class AuthorshipLog:
    attestations: List[FileAttestation]
    schema_version: str = "authorship/3.0.0"
    base_commit_sha: str = ""
    prompts: Dict[str, PromptRecord] = field(default_factory=dict)
    # Total lines added in the commit (AI + human). When known the schema is
    # bumped to 3.1.0 on serialize so the server can compute ai_percentage.
    # Stays None for v3.0.0 round-trips and back-compat.
    total_lines_added: Optional[int] = None


# ── Hook Input ───────────────────────────────────────────────────────

@dataclass
class NormalizedHookInput:
    event: HookEvent
    agent: str
    session_id: str
    tool_name: str
    tool_input: dict
    tool_use_id: str
    cwd: str
    transcript_path: Optional[str] = None
    model: Optional[str] = None


# ── Blame / Stats output ────────────────────────────────────────────

@dataclass
class BlameLine:
    line_number: int
    content: str
    agent: str
    model: str
    session_hash: str
    cost_usd: Optional[float] = None


@dataclass
class CommitStats:
    commit_sha: str
    message: str
    author: str
    date: str
    total_lines_added: int
    ai_lines: int
    human_lines: int
    ai_percentage: float
    by_agent: Dict[str, int] = field(default_factory=dict)
    by_model: Dict[str, int] = field(default_factory=dict)
    accepted_lines: int = 0
    overridden_lines: int = 0
    estimated_cost_usd: Optional[float] = None


@dataclass
class RepoStats:
    repo_path: str
    total_commits_scanned: int
    commits_with_ai: int
    total_lines_added: int
    ai_lines: int
    ai_percentage: float
    by_agent: Dict[str, int] = field(default_factory=dict)
    by_model: Dict[str, int] = field(default_factory=dict)
    estimated_total_cost_usd: Optional[float] = None
    commits: List[CommitStats] = field(default_factory=list)


# ── Durability ───────────────────────────────────────────────────────

@dataclass
class DurabilityRecord:
    session_hash: str
    agent: str
    model: str
    lines_authored: int
    lines_surviving: int
    lines_modified: int
    lines_deleted: int
    survival_rate: float
    commits_since: int
