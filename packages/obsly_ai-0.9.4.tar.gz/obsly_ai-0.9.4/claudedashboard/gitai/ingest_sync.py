"""POST git notes to the obsly-ai server. Stdlib only, silent on failure."""

import json
import urllib.request
import urllib.error

from claudedashboard.gitai.obsly_config import load_config


def send_note(repo_url, sha, note_content, author_email, author_name,
              message, committed_at, timeout=5):
    """POST a note to the obsly-ai server. Uses authenticated /api/ingest
    when a device_token is configured, falls back to /api/ingest-note."""
    cfg = load_config()
    server = cfg.get("server_url", "").rstrip("/")
    if not server:
        return False

    device_token = cfg.get("device_token", "")
    if device_token:
        return _send_authenticated(server, device_token, repo_url, sha,
                                   note_content, author_email, author_name,
                                   message, committed_at, timeout)
    return _send_unauthenticated(server, cfg.get("token", ""), repo_url, sha,
                                 note_content, author_email, author_name,
                                 message, committed_at, timeout)


def _send_authenticated(server, device_token, repo_url, sha, note_content,
                        author_email, author_name, message, committed_at, timeout):
    """POST to /api/ingest with Bearer device_token."""
    payload = {
        "remote_url": repo_url,
        "sha": sha,
        "note_content": note_content,
        "author_email": author_email,
        "author_name": author_name,
        "message": message,
        "committed_at": committed_at,
    }
    body = json.dumps(payload).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {device_token}",
    }
    req = urllib.request.Request(
        f"{server}/api/ingest", data=body, headers=headers, method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= resp.status < 300
    except (urllib.error.URLError, OSError, TimeoutError, Exception):
        return False


def _send_unauthenticated(server, token, repo_url, sha, note_content,
                          author_email, author_name, message, committed_at, timeout):
    """POST to /api/ingest-note (no auth required, org auto-created)."""
    payload = {
        "repo_url": repo_url,
        "sha": sha,
        "note_content": note_content,
        "author_email": author_email,
        "author_name": author_name,
        "message": message,
        "committed_at": committed_at,
    }
    body = json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(
        f"{server}/api/ingest-note", data=body, headers=headers, method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= resp.status < 300
    except (urllib.error.URLError, OSError, TimeoutError, Exception):
        return False
