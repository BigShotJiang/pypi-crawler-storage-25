"""AuthorshipLog v3.0.0 serialization and conversion from checkpoints."""

import json
from collections import defaultdict
from claudedashboard.gitai.models import (
    AuthorshipLog, FileAttestation, AttestationEntry, LineRange,
    PromptRecord, Checkpoint, CheckpointKind,
)
from claudedashboard.gitai.session import generate_session_hash


def serialize(log):
    """Serialize AuthorshipLog to git-ai v3.x format string.

    Bumps the on-the-wire schema to 3.1.0 when total_lines_added is known so
    the server can compute ai_percentage / human_lines from the note alone.
    """
    lines = []

    # Attestation section
    for fa in log.attestations:
        # Quote file paths with spaces
        if " " in fa.file_path or "\t" in fa.file_path:
            lines.append(f'"{fa.file_path}"')
        else:
            lines.append(fa.file_path)
        for entry in fa.entries:
            range_str = LineRange.format(entry.line_ranges)
            lines.append(f"  {entry.session_hash} {range_str}")

    # Separator
    lines.append("---")

    # Metadata section — bump to 3.1.0 if we have the total
    schema_version = log.schema_version
    if log.total_lines_added is not None and schema_version == "authorship/3.0.0":
        schema_version = "authorship/3.1.0"

    metadata = {
        "schema_version": schema_version,
        "base_commit_sha": log.base_commit_sha,
        "prompts": {k: v.to_dict() for k, v in log.prompts.items()},
    }
    if log.total_lines_added is not None:
        metadata["total_lines_added"] = int(log.total_lines_added)
    lines.append(json.dumps(metadata, separators=(",", ":")))

    return "\n".join(lines)


def deserialize(content):
    """Parse git-ai v3.0.0 format string to AuthorshipLog."""
    # Handle edge case: content starts with "---\n" (no attestations)
    if content.startswith("---\n"):
        attest_text = ""
        json_text = content[4:]
    else:
        parts = content.split("\n---\n", 1)
        attest_text = parts[0] if len(parts) > 0 else ""
        json_text = parts[1] if len(parts) > 1 else "{}"

    # Parse attestations
    attestations = []
    current_file = None
    current_entries = []

    for line in attest_text.split("\n"):
        if not line:
            continue
        if line.startswith("  "):
            # Attestation entry
            stripped = line.strip()
            hash_part, range_part = stripped.split(" ", 1)
            current_entries.append(AttestationEntry(hash_part, LineRange.parse(range_part)))
        else:
            # File path — flush previous
            if current_file is not None:
                attestations.append(FileAttestation(current_file, current_entries))
                current_entries = []
            # Remove quotes if present
            if line.startswith('"') and line.endswith('"'):
                current_file = line[1:-1]
            else:
                current_file = line

    if current_file is not None:
        attestations.append(FileAttestation(current_file, current_entries))

    # Parse metadata
    metadata = json.loads(json_text)
    prompts = {}
    for k, v in metadata.get("prompts", {}).items():
        prompts[k] = PromptRecord.from_dict(v)

    return AuthorshipLog(
        attestations=attestations,
        schema_version=metadata.get("schema_version", "authorship/3.0.0"),
        base_commit_sha=metadata.get("base_commit_sha", ""),
        prompts=prompts,
        total_lines_added=metadata.get("total_lines_added"),
    )


def from_checkpoints(checkpoints, commit_sha, git_user, total_lines_added=None):
    """Convert working log checkpoints into an AuthorshipLog."""
    # Collect AI attributions by file, keyed by session_hash
    file_attrs = defaultdict(lambda: defaultdict(list))  # file -> session_hash -> [line_nums]
    prompt_records = {}

    for cp in checkpoints:
        if cp.kind != CheckpointKind.AI_AGENT:
            continue
        if not cp.agent_id:
            continue

        session_hash = generate_session_hash(cp.agent_id.tool, cp.agent_id.id)

        if session_hash not in prompt_records:
            prompt_records[session_hash] = PromptRecord(
                agent_id=cp.agent_id,
                human_author=git_user,
                total_additions=0,
            )

        for entry in cp.entries:
            for la in entry.line_attributions:
                if la.author_id == session_hash:
                    for line_num in range(la.start_line, la.end_line + 1):
                        file_attrs[entry.file][session_hash].append(line_num)
                    prompt_records[session_hash].total_additions += la.line_count()

    # Build attestations
    attestations = []
    for file_path in sorted(file_attrs.keys()):
        entries = []
        for session_hash in sorted(file_attrs[file_path].keys()):
            line_nums = sorted(set(file_attrs[file_path][session_hash]))
            ranges = LineRange.compress(line_nums)
            if ranges:
                entries.append(AttestationEntry(session_hash, ranges))
        if entries:
            attestations.append(FileAttestation(file_path, entries))

    # Annotate each prompt with the equivalent API cost from local agent logs
    # (Claude Code's session jsonl, Codex sessions, etc.). Best-effort: if no
    # adapter has data for the session, leave custom_attributes alone.
    _annotate_costs(prompt_records, checkpoints)

    return AuthorshipLog(
        attestations=attestations,
        base_commit_sha=commit_sha,
        prompts=prompt_records,
        total_lines_added=total_lines_added,
    )


def _annotate_costs(prompt_records, checkpoints):
    """Annotate each prompt with the sum of per-edit costs from its checkpoints.

    If checkpoints already carry cost_usd (set at PostToolUse time), use that
    directly. Otherwise fall back to querying the UsageAdapters for Edit/Write
    turns only (never the full session)."""
    _EDIT_TOOLS = {"Edit", "Write"}

    # First: try using costs already stored in checkpoints
    session_costs = {}  # session_hash -> {cost, tokens_in, ...}
    for cp in checkpoints:
        if cp.kind != CheckpointKind.AI_AGENT or not cp.agent_id:
            continue
        if cp.cost_usd is None:
            continue
        sh = generate_session_hash(cp.agent_id.tool, cp.agent_id.id)
        acc = session_costs.setdefault(sh, {"cost": 0.0, "tokens_in": 0,
                                            "tokens_out": 0, "cache_read": 0,
                                            "cache_create": 0})
        acc["cost"] += cp.cost_usd
        acc["tokens_in"] += cp.tokens_in or 0
        acc["tokens_out"] += cp.tokens_out or 0
        acc["cache_read"] += cp.cache_read or 0
        acc["cache_create"] += cp.cache_create or 0

    # Apply checkpoint-based costs to prompts
    for sh, prompt in prompt_records.items():
        if sh in session_costs:
            acc = session_costs[sh]
            if acc["cost"] > 0:
                attrs = dict(prompt.custom_attributes or {})
                attrs["cost_usd"] = f"{acc['cost']:.6f}"
                attrs["tokens_in"] = str(acc["tokens_in"])
                attrs["tokens_out"] = str(acc["tokens_out"])
                attrs["cache_read"] = str(acc["cache_read"])
                attrs["cache_create"] = str(acc["cache_create"])
                prompt.custom_attributes = attrs

    # Fallback: for prompts without checkpoint costs, query adapters
    prompts_without_cost = [sh for sh, p in prompt_records.items()
                           if sh not in session_costs]
    if not prompts_without_cost:
        return

    try:
        from claudedashboard.gitai.usage_adapters import all_adapters
    except Exception:
        return

    session_real_id = {}
    for cp in checkpoints:
        if cp.kind != CheckpointKind.AI_AGENT or not cp.agent_id:
            continue
        sh = generate_session_hash(cp.agent_id.tool, cp.agent_id.id)
        session_real_id.setdefault(sh, (cp.agent_id.tool, cp.agent_id.id))

    adapters = all_adapters()
    for sh in prompts_without_cost:
        tool_id = session_real_id.get(sh)
        if not tool_id:
            continue
        tool, real_id = tool_id
        cost = 0.0
        tokens_in = tokens_out = cache_read = cache_create = 0
        for adapter in adapters:
            if adapter.agent != tool:
                continue
            for r in adapter.records_for_session(real_id):
                if r.tool_name not in _EDIT_TOOLS:
                    continue
                cost += r.equivalent_api_cost_usd
                tokens_in += r.tokens_in
                tokens_out += r.tokens_out
                cache_read += r.cache_read
                cache_create += r.cache_create
        if cost > 0:
            prompt = prompt_records[sh]
            attrs = dict(prompt.custom_attributes or {})
            attrs["cost_usd"] = f"{cost:.6f}"
            attrs["tokens_in"] = str(tokens_in)
            attrs["tokens_out"] = str(tokens_out)
            attrs["cache_read"] = str(cache_read)
            attrs["cache_create"] = str(cache_create)
            prompt.custom_attributes = attrs
