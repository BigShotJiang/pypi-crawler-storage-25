#!/usr/bin/env python3
"""
Claude Max Menu Bar App
Shows real weekly budget in the macOS toolbar with native notifications.

Install:  pip3 install rumps
Run:      python3 claude_menubar.py
"""

import json, re, subprocess, time, math, tempfile, os, sys
from urllib.request import urlopen
from datetime import datetime
from pathlib import Path

# Lazy imports: rumps (macOS only) and Pillow live inside main() so that
# non-darwin platforms can import this module for its shared helpers
# (fetch, reset_str, make_icon uses Pillow only when called) without
# triggering a hard ImportError on rumps at module load time.
try:
    import rumps  # noqa: F401  — imported for side effects, real import in main()
except Exception:  # pragma: no cover — exercised on Windows/Linux only
    rumps = None  # type: ignore[assignment]

try:
    from PIL import Image, ImageDraw, ImageFont
except Exception:  # pragma: no cover
    Image = ImageDraw = ImageFont = None  # type: ignore[assignment]

DASHBOARD_URL   = "http://localhost:8765/api"   # reads from live dashboard cache
PROXY_URL       = "http://localhost:8800/api/developer"  # reads from proxy server
CHECK_INTERVAL  = 65    # slightly offset from dashboard's 60s poll
API_CACHE_FILE  = os.path.expanduser("~/.claude/.dashboard_api_cache.json")
NOTIFY_WEEKLY   = [75, 90]
NOTIFY_5H       = 80


def fetch():
    """Read full snapshot from the live dashboard API. Falls back to disk cache."""
    try:
        with urlopen(DASHBOARD_URL, timeout=5) as r:
            return json.loads(r.read())
    except Exception:
        pass
    # Server down — try disk cache
    from claudedashboard.tray import _load_disk_cache, _snapshot_from_cache
    cached = _load_disk_cache(API_CACHE_FILE)
    snap = _snapshot_from_cache(cached)
    if snap:
        return snap
    raise ConnectionError("Live server unreachable and no disk cache available")


def fetch_proxy():
    """Read developer summary from the proxy server (optional)."""
    try:
        with urlopen(PROXY_URL, timeout=3) as r:
            return json.loads(r.read())
    except Exception:
        return None


_icon_file = os.path.join(tempfile.gettempdir(), "claude_budget_icon.png")

def _bar_color(pct):
    if pct is None or pct < 60:  return (63, 185, 80)    # green
    if pct < 75:                  return (240, 136, 62)   # orange
    if pct < 90:                  return (210, 153, 34)   # yellow
    return (248, 81, 73)                                  # red

def _draw_sparkle(draw, cx, cy, size, color):
    """Render a ✦ sparkle, stretched 1.6x horizontally so it's wide, not cross-like."""
    _sparkle_fonts = [
        "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        "/System/Library/Fonts/SFNS.ttf",
        "/System/Library/Fonts/LastResort.otf",
    ]
    font = ImageFont.load_default()
    for path in _sparkle_fonts:
        try:
            font = ImageFont.truetype(path, size)
            break
        except Exception:
            continue
    # Render to a temp image, stretch horizontally, paste back
    margin = size
    tmp = Image.new("RGBA", (size + margin * 2, size + margin * 2), (0, 0, 0, 0))
    tmp_draw = ImageDraw.Draw(tmp)
    tmp_draw.text((tmp.width // 2, tmp.height // 2), "✦", fill=color, font=font, anchor="mm")
    # Stretch 1.6x wider
    new_w = int(tmp.width * 1.6)
    tmp = tmp.resize((new_w, tmp.height), Image.LANCZOS)
    # Paste centered at (cx, cy) on the parent image
    paste_x = cx - new_w // 2
    paste_y = cy - tmp.height // 2
    draw._image.paste(tmp, (paste_x, paste_y), tmp)


def _draw_codex_mark(draw, cx, cy, size, color):
    """Simple Codex mark: a ring with a center dot, readable at tiny sizes."""
    stroke = max(2, size // 7)
    r = size // 2
    bbox = [cx - r, cy - r, cx + r, cy + r]
    draw.ellipse(bbox, outline=color, width=stroke)
    dot_r = max(2, size // 7)
    draw.ellipse([cx - dot_r, cy - dot_r, cx + dot_r, cy + dot_r], fill=color)


def make_icon(seven_pct, sonnet_pct, fh_pct, codex_week_pct=None, codex_fh_pct=None):
    """
    Two grouped meters:
    Claude  = sparkle + 7d/5h bars
    Codex   = ring + 7d/5h bars
    Rendered at 2x for retina.
    """
    GROUP_W   = 58
    GAP_X     = 12
    W         = GROUP_W * 2 + GAP_X
    H         = 44
    PAD_Y     = 4
    BAR_GAP   = 5
    BAR_W     = 8
    MAX_H     = H - PAD_Y * 2
    GHOST     = (255, 255, 255, 35)

    img  = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    def draw_group(x0, mark_fn, main_pct, sub_pct, mark_color):
        mark_cx = x0 + 16
        mark_cy = H // 2
        mark_fn(draw, mark_cx, mark_cy, 22, mark_color)

        bars_x = x0 + 30
        bars = [main_pct, sub_pct]
        for i, pct in enumerate(bars):
            x = bars_x + i * (BAR_W + BAR_GAP)
            draw.rounded_rectangle([x, PAD_Y, x + BAR_W, H - PAD_Y],
                                   radius=BAR_W // 2, fill=GHOST)
            fill_h = max(int(MAX_H * min((pct or 0) / 100.0, 1.0)), 0)
            if fill_h >= 2:
                fy = H - PAD_Y - fill_h
                draw.rounded_rectangle([x, fy, x + BAR_W, H - PAD_Y],
                                       radius=BAR_W // 2, fill=_bar_color(pct))

    claude_color = _bar_color(max(seven_pct or 0, fh_pct or 0)) + (220,)
    codex_color = _bar_color(max(codex_week_pct or 0, codex_fh_pct or 0)) + (220,)

    draw_group(0, _draw_sparkle, seven_pct, fh_pct, claude_color)
    draw_group(GROUP_W + GAP_X, _draw_codex_mark, codex_week_pct, codex_fh_pct, codex_color)

    img.save(_icon_file, "PNG")
    return _icon_file


def reset_str(resets_at):
    if not resets_at:
        return "—"
    try:
        if isinstance(resets_at, (int, float)):
            dt = datetime.fromtimestamp(resets_at).astimezone()
        else:
            dt = datetime.fromisoformat(resets_at).astimezone()
        return dt.strftime("%a %b %-d · %-I:%M %p")
    except Exception:
        return str(resets_at)


if rumps is not None:

  class ClaudeMenuBar(rumps.App):
      def __init__(self):
          super().__init__(
              name="Claude",
              title=None,
              quit_button="Quit",
          )

          self._notified = set()
          self._last_pct = None

          # Menu items
          self.weekly_item   = rumps.MenuItem("Weekly: —")
          self.sonnet_item   = rumps.MenuItem("Sonnet: —")
          self.fh_item       = rumps.MenuItem("5h window: —")
          self.codex_week_item = rumps.MenuItem("Codex 7d: —")
          self.codex_fh_item   = rumps.MenuItem("Codex 5h: —")
          self.resets_item   = rumps.MenuItem("Resets: —")
          self.codex_resets_item = rumps.MenuItem("Codex resets: —")
          self.pace_item     = rumps.MenuItem("Pace: —")
          self.savings_item  = rumps.MenuItem("API cost: —")
          self.sep_sessions  = rumps.separator
          self.sessions_hdr  = rumps.MenuItem("This week")
          # Session cost items (will be populated dynamically)
          self._session_items = []

          # Active sessions section — fixed slots with unique placeholders
          self.active_slot_0 = rumps.MenuItem("  -")
          self.active_slot_1 = rumps.MenuItem("  --")
          self.active_slot_2 = rumps.MenuItem("  ---")
          self.active_slot_3 = rumps.MenuItem("  ----")
          self.active_slot_4 = rumps.MenuItem("  -----")
          self._active_slots = [self.active_slot_0, self.active_slot_1,
                                self.active_slot_2, self.active_slot_3,
                                self.active_slot_4]

          # Alerts section
          self.alerts_hdr      = rumps.MenuItem("── Recent spikes ──")
          self.alerts_empty    = rumps.MenuItem("(no spikes)")
          self.alerts_dismiss  = rumps.MenuItem("Dismiss all", callback=self._dismiss_all_alerts)
          self._alert_items    = []

          # Proxy section
          self.proxy_hdr       = rumps.MenuItem("── Proxy ──")
          # Proxy indicator (launchd-managed) — added in 0.6.0
          self.proxy_indicator = rumps.MenuItem(
              "Proxy: [Unknown]", callback=self._on_proxy_click,
          )
          self.proxy_stats     = rumps.MenuItem("")
          self.proxy_total     = rumps.MenuItem("Proxy: not connected")
          self.proxy_cache     = rumps.MenuItem("")
          self._proxy_branch_items = []

          self.sep1          = rumps.separator
          self.dashboard_btn = rumps.MenuItem("Open dashboard", callback=self.open_dashboard)
          self.team_btn      = rumps.MenuItem("Open team dashboard", callback=self.open_team)
          self.refresh_btn   = rumps.MenuItem("Refresh now",    callback=self.refresh_now)

          self.menu = [
              self.weekly_item,
              self.fh_item,
              self.codex_week_item,
              self.codex_fh_item,
              self.resets_item,
              self.pace_item,
              self.savings_item,
              rumps.separator,
              self.active_slot_0,
              self.active_slot_1,
              self.active_slot_2,
              self.active_slot_3,
              self.active_slot_4,
              rumps.separator,
              self.sessions_hdr,
              rumps.separator,
              self.alerts_hdr,
              self.alerts_empty,
              self.alerts_dismiss,
              rumps.separator,
              self.proxy_hdr,
              self.proxy_indicator,
              self.proxy_stats,
              self.proxy_total,
              self.proxy_cache,
              rumps.separator,
              self.dashboard_btn,
              self.team_btn,
              self.refresh_btn,
          ]

          # Ensure the live server is running (auto-launch if needed)
          from claudedashboard.tray import ensure_live_server
          ensure_live_server()

          # Initial fetch on startup (runs on main thread before run loop)
          self._update()

      # ── Polling (main thread via rumps.Timer) ─────────────────────────────────

      def _update(self):
          try:
              data   = fetch()
              # Debug dump for diagnostics
              try:
                  import json as _j
                  _dump = {
                      "anthropic": data.get("anthropic"),
                      "codex_week": {k: v for k, v in (data.get("codex_week") or {}).items()
                                     if k not in ("history_pts", "day_labels")},
                      "active_sessions": data.get("active_sessions"),
                      "session_costs_count": len(data.get("session_costs") or []),
                      "ts": data.get("ts"),
                  }
                  with open(os.path.expanduser("~/.claude/.menubar_debug.json"), "w") as _f:
                      _f.write(_j.dumps(_dump, indent=2, default=str))
              except Exception:
                  pass
              self._from_cache = data.get("_from_cache", False)
              a      = data.get("anthropic") or {}
              c      = data.get("codex_week") or {}

              pct        = a.get("seven_day_pct")
              sonnet_pct = a.get("sonnet_pct")
              fh_pct     = a.get("five_hour_pct")
              resets_at  = a.get("seven_day_resets")
              fh_resets  = a.get("five_hour_resets")
              codex_week_pct = c.get("seven_day_pct")
              codex_fh_pct   = c.get("five_hour_pct")
              codex_week_reset = c.get("seven_day_resets_at")
              codex_fh_reset   = c.get("five_hour_resets_at")
              codex_plan       = c.get("plan_type")

              burn_rate     = data.get("burn_rate")
              session_costs = data.get("session_costs") or []
              week_api_cost  = data.get("week_api_cost", 0)
              month_api_cost = data.get("month_api_cost", 0)

              self._update_ui(
                  pct, sonnet_pct, fh_pct, resets_at,
                  codex_week_pct, codex_fh_pct, codex_week_reset, codex_fh_reset, codex_plan,
                  burn_rate, session_costs, week_api_cost, month_api_cost
              )
              self._check_notifications(pct, fh_pct, resets_at, fh_resets)

              # Active sessions
              self._update_active_sessions(data.get("active_sessions") or [])

          except Exception as e:
              self.title = ""
              self.weekly_item.title = f"Error: {e}"

          # Proxy data (optional, non-blocking)
          self._update_proxy()

          # Cost spike alerts (best-effort)
          try:
              self._update_alerts()
          except Exception as e:
              try:
                  self.alerts_empty.title = f"(alerts error: {e})"
              except Exception:
                  pass

      def _on_proxy_click(self, _item):
          try:
              from claudedashboard import tray
              from claudedashboard import proxy_service as ps
              result = tray.toggle_proxy(
                  status_func=ps.status,
                  install_func=ps.install,
                  uninstall_func=ps.uninstall,
              )
              # Refresh the indicator immediately
              self._update_proxy()
              if not result["ok"] and result.get("message"):
                  try:
                      rumps.notification("Obsly proxy", result["action"], result["message"])
                  except Exception:
                      pass
          except Exception:
              pass

      def _proxy_events_path(self):
          try:
              from claudedashboard.proxy.commands import _load_config
              cfg = _load_config()
              return cfg.get("events_path") or str(Path.home() / ".claude" / "proxy_events.jsonl")
          except Exception:
              return str(Path.home() / ".claude" / "proxy_events.jsonl")

      def _update_proxy(self):
          # New: launchd-managed proxy indicator
          try:
              from claudedashboard import tray
              ps_status = tray.get_proxy_status_safe()
              self.proxy_indicator.title = tray.proxy_status_label(ps_status)
              events_path = self._proxy_events_path()
              stats = tray.compute_last_hour_proxy_stats(events_path)
              self.proxy_stats.title = tray.format_proxy_stats_line(stats)
          except Exception:
              try:
                  self.proxy_indicator.title = "Proxy: [Unknown]"
                  self.proxy_stats.title = ""
              except Exception:
                  pass

          proxy = fetch_proxy()
          if proxy is None:
              self.proxy_total.title = "Proxy: not connected"
              return

          total = proxy.get("total_cost", 0)
          branches = proxy.get("branches", {})
          cache = proxy.get("cache_hit_ratio", 0)
          session = proxy.get("active_session") or {}

          # Total + session
          session_cost = session.get("cost", 0)
          session_model = (session.get("model") or "").split("-")[1] if session.get("model") else ""
          self.proxy_total.title = f"Proxy: ${total:.2f} total | session ${session_cost:.2f} ({session_model})"
          self.proxy_cache.title = f"Cache hit: {cache:.0f}%" if cache > 0 else ""

          # Remove old branch items
          for item in self._proxy_branch_items:
              try:
                  del self.menu[item.title]
              except Exception:
                  pass
          self._proxy_branch_items = []

          # Add branch breakdown (top 5)
          for branch, data in list(branches.items())[:5]:
              repo_short = data.get("repo_short", "?")
              short_branch = branch.split("/")[-1] if "/" in branch else branch
              label = f"  {repo_short}/{short_branch}: {data['pct']:.0f}% (${data['cost']:.3f})"
              item = rumps.MenuItem(label)
              self._proxy_branch_items.append(item)
              try:
                  self.menu.insert_after(self.proxy_cache.title or self.proxy_hdr.title, item)
              except (KeyError, Exception):
                  pass

      def _update_alerts(self):
          """Pull cost spike alerts and render them in the menu.

          Strategy: per-row items inserted after the "Recent spikes" header,
          mirroring the existing `_update_proxy` / `_session_items` pattern.
          The tray title is prefixed with `(!N)` when there are unread alerts.
          """
          from claudedashboard import tray
          alerts = tray.load_recent_alerts(limit=10)
          unread = tray.count_unread_alerts()

          # Title indicator — strip any previous (!N) prefix first so it
          # never stacks across refresh cycles.
          existing = self.title or ""
          stripped = re.sub(r"^\(!\d+\)\s*", "", existing)
          if unread > 0:
              self.title = f"(!{unread}) {stripped}".rstrip()
          else:
              self.title = stripped

          # Remove previous alert items from the menu
          for item in self._alert_items:
              try:
                  del self.menu[item.title]
              except Exception:
                  pass
          self._alert_items = []

          if not alerts:
              self.alerts_empty.title = "(no spikes)"
              return

          self.alerts_empty.title = ""
          # Insert in reverse so that, after repeated insert_after on the
          # same anchor, items end up in the original (newest-first) order.
          for alert in reversed(alerts):
              line = tray.format_alert_items([alert])[0]
              item = rumps.MenuItem(
                  line,
                  callback=self._make_alert_callback(alert.timestamp),
              )
              self._alert_items.append(item)
              try:
                  self.menu.insert_after(self.alerts_hdr.title, item)
              except (KeyError, Exception):
                  pass

      def _update_active_sessions(self, sessions):
          # Unique hidden suffixes so rumps doesn't deduplicate titles
          _hidden = ["\u200b" * (i+1) for i in range(5)]
          if not sessions:
              self._active_slots[0].title = f"  (no active sessions){_hidden[0]}"
              for i in range(1, 5):
                  self._active_slots[i].title = _hidden[i]
              return
          for i, slot in enumerate(self._active_slots):
              if i < len(sessions):
                  s = sessions[i]
                  ago = s.get("ago_secs", 0)
                  ago_str = f"{ago}s" if ago < 60 else f"{ago // 60}m"
                  cost = s.get("cost_usd", 0)
                  ctx = s.get("context_pct", 0)
                  proj = s.get("project", "?")
                  slot.title = f"  {proj} -- ${cost:.2f} ctx {ctx:.0f}% ({ago_str}){_hidden[i]}"
              else:
                  slot.title = _hidden[i]

      def _make_alert_callback(self, timestamp):
          def _cb(_item):
              try:
                  from claudedashboard.gitai.cost_alerts import mark_alert_read
                  mark_alert_read(timestamp)
                  self._update_alerts()
              except Exception as e:
                  print(f"menubar: alert callback error: {e}", file=__import__('sys').stderr)
          return _cb

      def _dismiss_all_alerts(self, _item):
          try:
              from claudedashboard.gitai.cost_alerts import mark_all_read
              mark_all_read()
              self._update_alerts()
          except Exception as e:
              print(f"menubar: dismiss all error: {e}", file=__import__('sys').stderr)

      def _update_ui(
          self, pct, sonnet_pct, fh_pct, resets_at,
          codex_week_pct, codex_fh_pct, codex_week_reset, codex_fh_reset, codex_plan,
          burn_rate, session_costs, week_api_cost=0, month_api_cost=0
      ):
          self.icon = None
          claude_txt = f"Claude: {pct:.0f}%" if pct is not None else "Claude: -"
          codex_txt = f"Codex: {codex_week_pct:.0f}%" if codex_week_pct is not None else "Codex: -"
          title = f"{claude_txt} | {codex_txt}"
          if getattr(self, "_from_cache", False):
              title = f"{title} [cached]"
          self.title = title

          # Menu items
          self.weekly_item.title  = f"Claude 7d: {pct:.0f}%  ·  5h: {fh_pct:.0f}%" if pct is not None and fh_pct is not None else "Claude: —"
          self.fh_item.title      = f"Resets: {reset_str(resets_at)}"
          self.codex_week_item.title = f"Codex 7d: {codex_week_pct:.0f}%  ·  5h: {codex_fh_pct:.0f}%" if codex_week_pct is not None else "Codex 7d: —"
          self.codex_fh_item.title   = f"Codex resets: {reset_str(codex_week_reset)}" if codex_week_reset else "Codex 5h: —"
          self.resets_item.title = ""

          # Burn rate / pace
          if burn_rate and burn_rate.get("avg_pace") is not None:
              pace = burn_rate["avg_pace"]
              sus = burn_rate.get("sustainable")
              today = burn_rate.get("today_used")
              today_str = f"Today: {today}%" if today is not None else ""
              if sus is not None and pace > sus:
                  self.pace_item.title = f"Pace: {pace:.1f}%/day — over budget (max {sus:.1f}%/day) {today_str}"
              elif sus is not None:
                  self.pace_item.title = f"Pace: {pace:.1f}%/day — on track (max {sus:.1f}%/day) {today_str}"
              else:
                  self.pace_item.title = f"Pace: {pace:.1f}%/day {today_str}"
          else:
              self.pace_item.title = "Pace: gathering data..."

          # API cost savings (last 30 days actual data)
          if month_api_cost > 200:
              self.savings_item.title = f"${week_api_cost:,.0f}/wk · saving ${month_api_cost - 200:,.0f}/mo vs Max 20x"
          elif month_api_cost > 100:
              self.savings_item.title = f"${week_api_cost:,.0f}/wk · saving ${month_api_cost - 100:,.0f}/mo vs Max 5x"
          elif week_api_cost > 0:
              self.savings_item.title = f"${week_api_cost:,.0f}/wk · ${month_api_cost:,.0f} last 30d"

          # Session costs (top 5)
          # Remove old session items
          for item in self._session_items:
              try:
                  del self.menu[item.title]
              except Exception:
                  pass
          self._session_items = []

          for s in session_costs[:5]:
              title = s.get("title") or s.get("id", "?")
              proj  = s.get("project", "")
              label = f"  {title[:40]} — {s['pct']:.1f}% ({s['model']})"
              item = rumps.MenuItem(label)
              self._session_items.append(item)
              self.menu.insert_after(self.sessions_hdr.title, item)

      # ── Notifications ─────────────────────────────────────────────────────────

      def _check_notifications(self, pct, fh_pct, resets_at, fh_resets):
          # Reset notification state at start of new cycle
          if pct is not None and pct < 40:
              self._notified = set()

          rl = f" Resets {reset_str(resets_at)}." if resets_at else ""

          for threshold in NOTIFY_WEEKLY:
              key = f"7d_{threshold}"
              if pct is not None and pct >= threshold and key not in self._notified:
                  if threshold >= 90:
                      rumps.notification(
                          title="🔴 Claude Max — Critical",
                          subtitle=f"Weekly budget at {pct:.0f}%",
                          message=f"Slow down!{rl}",
                          sound=True,
                      )
                  else:
                      rumps.notification(
                          title="🟡 Claude Max — Warning",
                          subtitle=f"Weekly budget at {pct:.0f}%",
                          message=rl.strip() or "Monitor your usage.",
                          sound=True,
                      )
                  self._notified.add(key)

          key_fh = "5h_warn"
          if fh_pct is not None and fh_pct >= NOTIFY_5H and key_fh not in self._notified:
              rl_fh = f" Resets {reset_str(fh_resets)}." if fh_resets else ""
              rumps.notification(
                  title="⚠️ Claude Max — Rate Limit Risk",
                  subtitle=f"5h window at {fh_pct:.0f}%",
                  message=f"You may get throttled.{rl_fh}",
                  sound=True,
              )
              self._notified.add(key_fh)
          elif fh_pct is not None and fh_pct < 50:
              self._notified.discard(key_fh)

      # ── Callbacks ─────────────────────────────────────────────────────────────

      def open_dashboard(self, _):
          import webbrowser
          from claudedashboard.tray import ensure_live_server
          ensure_live_server()
          webbrowser.open("http://localhost:8765")

      def open_team(self, _):
          import webbrowser
          webbrowser.open("http://localhost:8800")

      def refresh_now(self, _):
          self._update()

      @rumps.timer(CHECK_INTERVAL)
      def timer_tick(self, _):
          self._update()


  def main():
      ClaudeMenuBar().run()

else:

  def main():
      raise ImportError(
          "rumps is required for the macOS menubar. "
          "Install with: pipx install 'obsly-ai[menubar]' (macOS only). "
          "On Windows/Linux use: obsly-ai tray"
      )


if __name__ == "__main__":
    main()
