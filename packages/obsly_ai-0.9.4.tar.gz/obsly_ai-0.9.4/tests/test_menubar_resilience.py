"""Tests for menubar resilience: cache fallback + auto-launch of live.py."""

import json
import os
import sys
import time

import pytest

from claudedashboard import tray


# ── Cache fallback (tray.fetch_snapshot) ─────────────────────────────────

def test_fetch_snapshot_falls_back_to_disk_cache(tmp_path, monkeypatch):
    """When the live server is unreachable, fetch_snapshot reads the disk cache."""
    cache_file = tmp_path / ".dashboard_api_cache.json"
    cache_data = {
        "seven_day_pct": 42.0,
        "sonnet_pct": 30.0,
        "five_hour_pct": 18.0,
        "seven_day_resets": "2026-04-30T09:00:00+00:00",
        "five_hour_resets": "2026-04-26T14:00:00+00:00",
        "fetched_at": "2026-04-26T10:00:00+00:00",
    }
    cache_file.write_text(json.dumps(cache_data))

    # Point to a port that is definitely not listening
    monkeypatch.setattr(tray, "DASHBOARD_URL", "http://127.0.0.1:19999/api")
    monkeypatch.setattr(tray, "API_CACHE_FILE", str(cache_file))

    snap = tray.fetch_snapshot()
    assert snap != {}
    assert snap["anthropic"]["seven_day_pct"] == 42.0
    assert snap["anthropic"]["sonnet_pct"] == 30.0
    assert snap["anthropic"]["five_hour_pct"] == 18.0
    assert snap.get("_from_cache") is True


def test_fetch_snapshot_returns_empty_when_no_cache_and_no_server(tmp_path, monkeypatch):
    """When both server and cache are unavailable, returns {}."""
    monkeypatch.setattr(tray, "DASHBOARD_URL", "http://127.0.0.1:19999/api")
    monkeypatch.setattr(tray, "API_CACHE_FILE", str(tmp_path / "nonexistent.json"))

    snap = tray.fetch_snapshot()
    assert snap == {}


def test_fetch_snapshot_prefers_live_server_over_cache(tmp_path, monkeypatch):
    """When the server is reachable, the live data is returned (not the cache)."""
    cache_file = tmp_path / ".dashboard_api_cache.json"
    cache_data = {"seven_day_pct": 10.0, "fetched_at": "2026-04-25T10:00:00+00:00"}
    cache_file.write_text(json.dumps(cache_data))
    monkeypatch.setattr(tray, "API_CACHE_FILE", str(cache_file))

    live_data = {"anthropic": {"seven_day_pct": 55.0}, "codex_week": {}}

    import io
    from unittest.mock import patch, MagicMock

    fake_resp = MagicMock()
    fake_resp.read.return_value = json.dumps(live_data).encode()
    fake_resp.__enter__ = lambda s: s
    fake_resp.__exit__ = MagicMock(return_value=False)

    with patch("claudedashboard.tray.urlopen", return_value=fake_resp):
        snap = tray.fetch_snapshot()

    assert snap["anthropic"]["seven_day_pct"] == 55.0
    assert "_from_cache" not in snap


def test_cache_snapshot_marks_from_cache():
    """Snapshots built from cache have _from_cache=True."""
    cache = {
        "seven_day_pct": 60.0,
        "sonnet_pct": 40.0,
        "five_hour_pct": 25.0,
        "fetched_at": "2026-04-26T08:00:00+00:00",
    }
    snap = tray._snapshot_from_cache(cache)
    assert snap["_from_cache"] is True
    assert snap["anthropic"]["seven_day_pct"] == 60.0


def test_cache_snapshot_returns_none_for_empty_cache():
    """_snapshot_from_cache returns None when cache is None or empty."""
    assert tray._snapshot_from_cache(None) is None
    assert tray._snapshot_from_cache({}) is None


# ── format_title_with_alerts + cached indicator ──────────────────────────

def test_format_title_shows_cached_when_from_cache():
    """When snapshot has _from_cache, title ends with [cached]."""
    snap = {
        "anthropic": {"seven_day_pct": 42.0},
        "codex_week": {"seven_day_pct": 15.0},
        "_from_cache": True,
    }
    title = tray.format_title_with_alerts(snap, 0)
    assert "[cached]" in title
    assert "42%" in title


def test_format_title_no_cached_when_live():
    """Live data does not show [cached]."""
    snap = {
        "anthropic": {"seven_day_pct": 42.0},
        "codex_week": {"seven_day_pct": 15.0},
    }
    title = tray.format_title_with_alerts(snap, 0)
    assert "[cached]" not in title


# ── Auto-launch of live.py ───────────────────────────────────────────────

def test_ensure_live_server_launches_when_down(monkeypatch):
    """ensure_live_server() launches a subprocess when port 8765 is not listening."""
    launched = {}

    def fake_popen(*args, **kwargs):
        launched["args"] = args
        launched["kwargs"] = kwargs

    # Simulate port not listening
    monkeypatch.setattr(tray, "_is_port_open", lambda host, port: False)
    import subprocess
    monkeypatch.setattr(subprocess, "Popen", fake_popen)

    tray.ensure_live_server()

    assert "args" in launched
    # Should call python -m claudedashboard.live --no-browser
    cmd = launched["args"][0]
    assert "claudedashboard.live" in " ".join(cmd)
    assert "--no-browser" in cmd


def test_ensure_live_server_noop_when_already_running(monkeypatch):
    """ensure_live_server() does nothing when the port is already open."""
    launched = {}

    def fake_popen(*args, **kwargs):
        launched["called"] = True

    monkeypatch.setattr(tray, "_is_port_open", lambda host, port: True)
    import subprocess
    monkeypatch.setattr(subprocess, "Popen", fake_popen)

    tray.ensure_live_server()

    assert "called" not in launched


def test_is_port_open_returns_false_for_closed_port():
    """_is_port_open returns False for a port nobody is listening on."""
    assert tray._is_port_open("127.0.0.1", 19999) is False


# ── menubar.py fetch() fallback ──────────────────────────────────────────

def test_menubar_fetch_falls_back_to_cache(tmp_path, monkeypatch):
    """menubar.fetch() returns cached data when the server is down."""
    from claudedashboard import menubar

    cache_file = tmp_path / "cache.json"
    cache_data = {
        "seven_day_pct": 50.0,
        "sonnet_pct": 35.0,
        "five_hour_pct": 20.0,
        "fetched_at": "2026-04-26T09:00:00+00:00",
    }
    cache_file.write_text(json.dumps(cache_data))

    monkeypatch.setattr(menubar, "DASHBOARD_URL", "http://127.0.0.1:19999/api")
    monkeypatch.setattr(menubar, "API_CACHE_FILE", str(cache_file))

    result = menubar.fetch()
    assert result["anthropic"]["seven_day_pct"] == 50.0
    assert result.get("_from_cache") is True


def test_menubar_fetch_raises_when_no_server_and_no_cache(tmp_path, monkeypatch):
    """menubar.fetch() raises when both server and cache are unavailable."""
    from claudedashboard import menubar

    monkeypatch.setattr(menubar, "DASHBOARD_URL", "http://127.0.0.1:19999/api")
    monkeypatch.setattr(menubar, "API_CACHE_FILE", str(tmp_path / "nope.json"))

    with pytest.raises(Exception):
        menubar.fetch()
