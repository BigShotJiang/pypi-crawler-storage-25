"""Tests for the loopback OAuth login flow (0.9.0 B15)."""

import threading
import time
from urllib.request import urlopen

from claudedashboard.loopback_login import _find_free_port, run_login


def test_find_free_port():
    port = _find_free_port()
    assert 1024 <= port <= 65535


def test_loopback_captures_token():
    """Simulate the SaaS redirecting back with a device token."""
    port = _find_free_port()

    # We need to patch run_login to use a known port. Instead, test the
    # handler directly by running it in a thread and sending a request.
    import http.server
    from urllib.parse import urlencode
    from claudedashboard.loopback_login import run_login

    result = {"token": None}
    state = "test-state-123"

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            from urllib.parse import parse_qs, urlparse
            parsed = urlparse(self.path)
            if parsed.path != "/callback":
                self.send_response(404)
                self.end_headers()
                return
            params = parse_qs(parsed.query)
            if params.get("state", [""])[0] != state:
                self.send_response(400)
                self.end_headers()
                return
            result["token"] = params.get("device_token", [""])[0]
            self.send_response(200)
            self.end_headers()

        def log_message(self, format, *args):
            pass

    server = http.server.HTTPServer(("127.0.0.1", port), Handler)

    def serve():
        server.handle_request()
        server.server_close()

    t = threading.Thread(target=serve, daemon=True)
    t.start()

    url = f"http://localhost:{port}/callback?state={state}&device_token=tok_abc123"
    resp = urlopen(url, timeout=5)
    assert resp.status == 200
    t.join(timeout=5)
    assert result["token"] == "tok_abc123"


def test_loopback_rejects_bad_state():
    """State mismatch should return 400."""
    port = _find_free_port()
    state = "correct-state"

    import http.server
    from urllib.parse import parse_qs, urlparse

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            params = parse_qs(parsed.query)
            if params.get("state", [""])[0] != state:
                self.send_response(400)
                self.end_headers()
                return
            self.send_response(200)
            self.end_headers()

        def log_message(self, format, *args):
            pass

    server = http.server.HTTPServer(("127.0.0.1", port), Handler)

    def serve():
        server.handle_request()
        server.server_close()

    t = threading.Thread(target=serve, daemon=True)
    t.start()

    from urllib.error import HTTPError
    try:
        urlopen(f"http://localhost:{port}/callback?state=wrong&device_token=tok_x", timeout=5)
        assert False, "should have raised"
    except HTTPError as e:
        assert e.code == 400
    t.join(timeout=5)
