"""TDD for doctor — integration health checks."""
import pytest
from unittest.mock import patch, MagicMock


class TestDoctorChecks:
    """Each check returns (status, message). Status: 'ok', 'warn', 'fail'."""

    def test_check_mitmproxy_installed(self):
        import shutil
        from claudedashboard.proxy.doctor import check_mitmproxy_installed

        status, msg = check_mitmproxy_installed()
        if shutil.which("mitmdump"):
            assert status == "ok"
            assert "mitmdump" in msg or "mitmproxy" in msg
        else:
            # CI environments may not have mitmproxy installed
            assert status == "fail"

    def test_check_cert_exists(self):
        from claudedashboard.proxy.doctor import check_cert_exists

        status, msg = check_cert_exists()
        # May or may not exist — just verify it returns a valid tuple
        assert status in ("ok", "fail")

    def test_check_cert_trusted(self):
        from claudedashboard.proxy.doctor import check_cert_trusted

        status, msg = check_cert_trusted()
        assert status in ("ok", "fail")

    def test_check_proxy_starts(self):
        from claudedashboard.proxy.doctor import check_proxy_starts

        status, msg = check_proxy_starts()
        assert status in ("ok", "fail")

    def test_check_git_attribution(self):
        from claudedashboard.proxy.doctor import check_git_attribution

        status, msg = check_git_attribution()
        assert status == "ok"
        assert "repo" in msg.lower() or "branch" in msg.lower()

    def test_check_store_writable(self, tmp_path):
        from claudedashboard.proxy.doctor import check_store_writable

        status, msg = check_store_writable(str(tmp_path / "test.jsonl"))
        assert status == "ok"

    def test_check_store_writable_bad_path(self):
        from claudedashboard.proxy.doctor import check_store_writable

        status, msg = check_store_writable("/nonexistent/dir/test.jsonl")
        assert status == "fail"

    def test_run_all_returns_list(self):
        from claudedashboard.proxy.doctor import run_all

        results = run_all()
        assert isinstance(results, list)
        assert len(results) >= 5
        for name, status, msg in results:
            assert status in ("ok", "warn", "fail")
            assert isinstance(name, str)
            assert isinstance(msg, str)
