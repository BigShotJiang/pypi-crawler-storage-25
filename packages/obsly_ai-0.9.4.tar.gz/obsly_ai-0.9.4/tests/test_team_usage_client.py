"""Tests for the team-usage client track."""

import json
import sys
from pathlib import Path

import pytest


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("OBSLY_CONFIG_DIR", str(tmp_path / ".obsly-ai"))
    monkeypatch.delenv("OBSLY_DEVICE_TOKEN", raising=False)
    return tmp_path


def _write_codex_log(home_dir, *, session_id="abc123", plan_type="pro", weekly_pct=37.5, total_tokens=12345):
    sessions = Path(home_dir) / ".codex" / "sessions"
    sessions.mkdir(parents=True, exist_ok=True)
    path = sessions / f"session-{session_id}.jsonl"
    payload = {
        "type": "event_msg",
        "timestamp": "2026-04-10T12:00:00Z",
        "payload": {
            "type": "token_count",
            "info": {"total_token_usage": {"total_tokens": total_tokens}},
            "rate_limits": {
                "plan_type": plan_type,
                "primary": {"used_percent": 12.5, "resets_at": "2026-04-10T13:00:00Z"},
                "secondary": {"used_percent": weekly_pct, "resets_at": "2026-04-17T13:00:00Z"},
            },
        },
    }
    path.write_text(json.dumps(payload) + "\n")
    return path


def test_codex_estimator_returns_pct_from_local_logs(fake_home):
    from claudedashboard.codex_estimate import estimate_codex_usage

    _write_codex_log(fake_home, plan_type="team", weekly_pct=58.5)
    usage = estimate_codex_usage(home_dir=fake_home)

    assert usage["plan"] == "team"
    assert usage["weekly_pct"] == 58.5
    assert usage["estimated"] is True


def test_local_pusher_skips_when_no_device_token(fake_home):
    from claudedashboard import usage_pusher

    called = {"count": 0}

    def boom(*args, **kwargs):
        called["count"] += 1
        raise AssertionError("urlopen should not be called without a device token")

    ok = usage_pusher.push_usage_snapshot(
        snapshot={"anthropic": {"seven_day_pct": 12.5}},
        opener=boom,
    )

    assert ok is False
    assert called["count"] == 0


def test_local_pusher_includes_codex_when_local_logs_exist(fake_home):
    from claudedashboard import usage_pusher
    from claudedashboard.gitai.obsly_config import set_value

    _write_codex_log(fake_home, plan_type="pro", weekly_pct=41.0)
    set_value("server", "http://example.test")
    set_value("device_token", "device-123")

    captured = {}

    class _Resp:
        status = 200

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

    def opener(req, timeout=None):
        captured["url"] = req.full_url
        captured["headers"] = dict(req.headers)
        captured["body"] = json.loads(req.data.decode("utf-8"))
        captured["timeout"] = timeout
        return _Resp()

    ok = usage_pusher.push_usage_snapshot(
        snapshot={
            "anthropic": {
                "seven_day_pct": 55.0,
                "five_hour_pct": 20.0,
                "sonnet_pct": 10.0,
            },
            "week_api_cost": 19.99,
        },
        opener=opener,
    )

    assert ok is True
    assert captured["url"] == "http://example.test/api/usage-snapshot"
    assert captured["timeout"] == 10
    assert captured["body"]["claude"]["weekly_pct"] == 55.0
    assert captured["body"]["codex"]["plan"] == "pro"
    assert captured["body"]["codex"]["weekly_pct"] == 41.0
    assert captured["body"]["codex"]["estimated"] is True
    assert captured["body"]["equivalent_value_7d_usd"] == 19.99


def test_cli_login_calls_loopback(fake_home, monkeypatch, capsys):
    from claudedashboard import cli
    from claudedashboard.gitai.obsly_config import load_config
    from claudedashboard import loopback_login

    # Mock run_login to return a fake token without starting a server
    monkeypatch.setattr(loopback_login, "run_login", lambda **kw: "tok_test123")
    monkeypatch.setattr(cli, "_maybe_notify_update", lambda _cmd: None)
    monkeypatch.setattr(sys, "argv", ["obsly-ai", "login"])

    cli.main()

    out = capsys.readouterr().out
    assert "Login successful" in out
    assert load_config()["device_token"] == "tok_test123"
    assert load_config()["server_url"] == "https://ai.obsly.io"


def test_cli_config_set_device_token_persists(fake_home, monkeypatch, capsys):
    from claudedashboard import cli
    from claudedashboard.gitai.obsly_config import load_config

    monkeypatch.setattr(cli, "_maybe_notify_update", lambda _cmd: None)
    monkeypatch.setattr(sys, "argv", ["obsly-ai", "config", "set", "device_token", "device-xyz"])

    cli.main()

    out = capsys.readouterr().out
    assert "device_token = device-xyz" in out
    assert load_config()["device_token"] == "device-xyz"
