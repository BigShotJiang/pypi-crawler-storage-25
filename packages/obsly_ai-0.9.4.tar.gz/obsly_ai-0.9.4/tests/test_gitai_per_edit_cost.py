"""TDD: per-edit cost annotation — each edit gets its OWN cost, not the session total."""

import json
import pytest
from pathlib import Path


# ── Fixtures ─────────────────────────────────────────────────────────

@pytest.fixture
def claude_session_with_edits(tmp_path):
    """Synthetic JSONL with 5 turns: 2 Reads, 2 Edits on different files, 1 text.

    Each turn has its own usage. The edits should get individual costs.
    """
    proj = tmp_path / ".claude" / "projects" / "-Users-test-myproject"
    proj.mkdir(parents=True)
    sess = "session-edit-cost-test"
    entries = [
        # Turn 1: Read (no file edit)
        {
            "sessionId": sess,
            "timestamp": "2026-04-10T12:00:00.000Z",
            "message": {
                "role": "assistant",
                "model": "claude-sonnet-4-6-20250514",
                "content": [{"type": "tool_use", "id": "tu1", "name": "Read",
                             "input": {"file_path": "/src/foo.py"}}],
                "usage": {"input_tokens": 1, "output_tokens": 50,
                          "cache_read_input_tokens": 10000,
                          "cache_creation_input_tokens": 200},
            },
        },
        # Turn 2: Edit on foo.py
        {
            "sessionId": sess,
            "timestamp": "2026-04-10T12:00:05.000Z",
            "message": {
                "role": "assistant",
                "model": "claude-sonnet-4-6-20250514",
                "content": [{"type": "tool_use", "id": "tu2", "name": "Edit",
                             "input": {"file_path": "/src/foo.py",
                                       "old_string": "x", "new_string": "y"}}],
                "usage": {"input_tokens": 1, "output_tokens": 200,
                          "cache_read_input_tokens": 12000,
                          "cache_creation_input_tokens": 300},
            },
        },
        # Turn 3: Edit on bar.py
        {
            "sessionId": sess,
            "timestamp": "2026-04-10T12:00:10.000Z",
            "message": {
                "role": "assistant",
                "model": "claude-sonnet-4-6-20250514",
                "content": [{"type": "tool_use", "id": "tu3", "name": "Edit",
                             "input": {"file_path": "/src/bar.py",
                                       "old_string": "a", "new_string": "b"}}],
                "usage": {"input_tokens": 1, "output_tokens": 150,
                          "cache_read_input_tokens": 13000,
                          "cache_creation_input_tokens": 400},
            },
        },
        # Turn 4: Write on new_file.py
        {
            "sessionId": sess,
            "timestamp": "2026-04-10T12:00:15.000Z",
            "message": {
                "role": "assistant",
                "model": "claude-sonnet-4-6-20250514",
                "content": [{"type": "tool_use", "id": "tu4", "name": "Write",
                             "input": {"file_path": "/src/new_file.py",
                                       "content": "hello"}}],
                "usage": {"input_tokens": 1, "output_tokens": 500,
                          "cache_read_input_tokens": 14000,
                          "cache_creation_input_tokens": 100},
            },
        },
        # Turn 5: text response (no tool_use)
        {
            "sessionId": sess,
            "timestamp": "2026-04-10T12:00:20.000Z",
            "message": {
                "role": "assistant",
                "model": "claude-sonnet-4-6-20250514",
                "content": [{"type": "text", "text": "Done!"}],
                "usage": {"input_tokens": 1, "output_tokens": 30,
                          "cache_read_input_tokens": 15000,
                          "cache_creation_input_tokens": 50},
            },
        },
    ]
    log_file = proj / f"{sess}.jsonl"
    log_file.write_text("\n".join(json.dumps(e) for e in entries) + "\n")
    return tmp_path, sess


# ── Tests: UsageRecord now carries tool_name and file_path ───────────

class TestUsageRecordHasEditInfo:

    def test_record_has_tool_name(self, claude_session_with_edits):
        home, sess = claude_session_with_edits
        from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
        adapter = ClaudeCodeAdapter(home_dir=home)
        records = adapter.records_for_session(sess)
        tool_names = [r.tool_name for r in records]
        assert "Edit" in tool_names
        assert "Read" in tool_names
        assert "Write" in tool_names

    def test_record_has_file_path(self, claude_session_with_edits):
        home, sess = claude_session_with_edits
        from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
        adapter = ClaudeCodeAdapter(home_dir=home)
        records = adapter.records_for_session(sess)
        edit_records = [r for r in records if r.tool_name == "Edit"]
        files = [r.file_path for r in edit_records]
        assert "/src/foo.py" in files
        assert "/src/bar.py" in files

    def test_text_response_has_no_file(self, claude_session_with_edits):
        home, sess = claude_session_with_edits
        from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
        adapter = ClaudeCodeAdapter(home_dir=home)
        records = adapter.records_for_session(sess)
        text_records = [r for r in records if r.tool_name is None]
        assert len(text_records) == 1
        assert text_records[0].file_path is None


# ── Tests: per-edit cost is individual, not session total ────────────

class TestPerEditCost:

    def test_edit_cost_is_only_that_turn(self, claude_session_with_edits):
        """The cost annotated for an Edit of foo.py is ONLY the cost of that
        specific API turn, not the sum of the entire session."""
        home, sess = claude_session_with_edits
        from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
        from claudedashboard.gitai.pricing import calc_cost
        adapter = ClaudeCodeAdapter(home_dir=home)
        records = adapter.records_for_session(sess)

        foo_edits = [r for r in records if r.tool_name == "Edit" and r.file_path == "/src/foo.py"]
        assert len(foo_edits) == 1
        r = foo_edits[0]

        # Verify it has the exact usage from turn 2 only
        assert r.tokens_in == 1
        assert r.tokens_out == 200
        assert r.cache_read == 12000
        assert r.cache_create == 300

        # Verify cost is computed from THIS turn's tokens only
        expected = calc_cost("claude-sonnet-4-6", 1, 200, 12000, 300)
        assert r.equivalent_api_cost_usd == pytest.approx(expected, abs=1e-8)

    def test_session_total_is_sum_of_all_turns(self, claude_session_with_edits):
        """cost_for_session still returns the full session total (all 5 turns)."""
        home, sess = claude_session_with_edits
        from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
        adapter = ClaudeCodeAdapter(home_dir=home)
        total = adapter.cost_for_session(sess)
        records = adapter.records_for_session(sess)
        assert len(records) == 5
        assert total == pytest.approx(sum(r.equivalent_api_cost_usd for r in records))

    def test_edits_cost_less_than_session_total(self, claude_session_with_edits):
        """Individual edit costs must be < session total (they're not duplicated)."""
        home, sess = claude_session_with_edits
        from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
        adapter = ClaudeCodeAdapter(home_dir=home)
        records = adapter.records_for_session(sess)
        total = sum(r.equivalent_api_cost_usd for r in records)
        edits_only = sum(r.equivalent_api_cost_usd for r in records
                         if r.tool_name in ("Edit", "Write"))
        assert edits_only < total


# ── Tests: _annotate_costs uses per-file cost ────────────────────────

class TestAnnotateCostsPerFile:

    def test_annotates_per_file_not_session_total(self, claude_session_with_edits, monkeypatch):
        """Each file in the attestation gets only the cost of edits to THAT file."""
        home, sess = claude_session_with_edits
        monkeypatch.setenv("HOME", str(home))

        import claudedashboard.gitai.usage_adapters as ua
        from claudedashboard.gitai.usage_adapters.claude_code import ClaudeCodeAdapter
        monkeypatch.setattr(ua, "all_adapters", lambda: [ClaudeCodeAdapter(home_dir=home)])

        from claudedashboard.gitai.models import (
            Checkpoint, CheckpointKind, AgentId, WorkingLogEntry, LineAttribution,
        )
        from claudedashboard.gitai.session import generate_session_hash
        from claudedashboard.gitai.authorship_log import from_checkpoints
        from claudedashboard.gitai.pricing import calc_cost

        sh = generate_session_hash("claude-code", sess)

        # Two checkpoints: one edited foo.py, another edited bar.py
        cp1 = Checkpoint(
            kind=CheckpointKind.AI_AGENT,
            author="dev@test",
            agent_id=AgentId(tool="claude-code", id=sess, model="claude-sonnet-4-6"),
            entries=[WorkingLogEntry(
                file="src/foo.py", blob_sha="a" * 40,
                line_attributions=[LineAttribution(1, 5, sh)],
            )],
            timestamp_ms=1712750405000,
        )
        cp2 = Checkpoint(
            kind=CheckpointKind.AI_AGENT,
            author="dev@test",
            agent_id=AgentId(tool="claude-code", id=sess, model="claude-sonnet-4-6"),
            entries=[WorkingLogEntry(
                file="src/bar.py", blob_sha="b" * 40,
                line_attributions=[LineAttribution(1, 3, sh)],
            )],
            timestamp_ms=1712750410000,
        )

        log = from_checkpoints([cp1, cp2], "abc123", "dev@test")
        pr = log.prompts[sh]

        # The annotated cost should be the sum of edits to foo.py + bar.py
        # NOT the entire session (which includes Reads and text responses)
        edit_foo_cost = calc_cost("claude-sonnet-4-6", 1, 200, 12000, 300)
        edit_bar_cost = calc_cost("claude-sonnet-4-6", 1, 150, 13000, 400)
        write_cost = calc_cost("claude-sonnet-4-6", 1, 500, 14000, 100)
        edits_total = edit_foo_cost + edit_bar_cost + write_cost

        session_total = sum(
            calc_cost("claude-sonnet-4-6", 1, out, cr, cc)
            for out, cr, cc in [(50, 10000, 200), (200, 12000, 300),
                                (150, 13000, 400), (500, 14000, 100), (30, 15000, 50)]
        )

        annotated_cost = float(pr.custom_attributes["cost_usd"])

        # Must be the edits total, NOT the session total
        assert annotated_cost == pytest.approx(edits_total, abs=1e-6)
        assert annotated_cost < session_total  # proves we're not summing everything

    def test_checkpoint_with_precomputed_cost_skips_adapter(self, monkeypatch):
        """When checkpoints already carry cost_usd (set at PostToolUse time),
        _annotate_costs uses those directly without querying adapters."""
        from claudedashboard.gitai.models import (
            Checkpoint, CheckpointKind, AgentId, WorkingLogEntry, LineAttribution,
        )
        from claudedashboard.gitai.session import generate_session_hash
        from claudedashboard.gitai.authorship_log import from_checkpoints

        sess = "precosted-session"
        sh = generate_session_hash("claude-code", sess)

        # Checkpoints with cost already computed at hook time
        cp1 = Checkpoint(
            kind=CheckpointKind.AI_AGENT,
            author="dev@test",
            agent_id=AgentId(tool="claude-code", id=sess, model="claude-sonnet-4-6"),
            entries=[WorkingLogEntry(
                file="src/a.py", blob_sha="a" * 40,
                line_attributions=[LineAttribution(1, 10, sh)],
            )],
            timestamp_ms=1000,
            cost_usd=0.05,
            tokens_in=1,
            tokens_out=300,
            cache_read=20000,
            cache_create=500,
        )
        cp2 = Checkpoint(
            kind=CheckpointKind.AI_AGENT,
            author="dev@test",
            agent_id=AgentId(tool="claude-code", id=sess, model="claude-sonnet-4-6"),
            entries=[WorkingLogEntry(
                file="src/b.py", blob_sha="b" * 40,
                line_attributions=[LineAttribution(1, 5, sh)],
            )],
            timestamp_ms=2000,
            cost_usd=0.03,
            tokens_in=1,
            tokens_out=150,
            cache_read=22000,
            cache_create=200,
        )

        # No adapters configured — would fail if code tries to query them
        import claudedashboard.gitai.usage_adapters as ua
        monkeypatch.setattr(ua, "all_adapters", lambda: [])

        log = from_checkpoints([cp1, cp2], "abc123", "dev@test")
        pr = log.prompts[sh]

        assert pr.custom_attributes is not None
        assert float(pr.custom_attributes["cost_usd"]) == pytest.approx(0.08)
        assert int(pr.custom_attributes["tokens_out"]) == 450
        assert int(pr.custom_attributes["cache_read"]) == 42000
