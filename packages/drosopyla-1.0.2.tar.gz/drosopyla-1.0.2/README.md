# 🪰drosopyla

-----

A package implementing the building blocks for implementing the biological sequence analysis, from motif search to peptide sequencing from a Mass Spectre. This package was partially inspired from scikit-learn library.

This package provides the following solutions:

* 🧬Biologic Sequences Representations (`drosopyla.sequences`):
  * `DNASequence`
  * `RNASequence`
  * `Protein`

* 📑K-mer sequence computation (`drosopyla.frequency`):
  * `SimpleFrequencyTable`
  * `FrequencyTableWithMismatch`
  * `FrequencyTableWithMismatchAndReverseComplements`

* 📄Motif search (`drosospyla.motif_search`):
  * `SimpleMotifSearcher`
  * `MedianStringMotifSearcher`
  * `GreedyMotifSearcher`
  * `RandomizedMotifSearcher`

* 🅿️Peptide Sequencing from Mass Spectre (`drosopyla.spectrum`).
  * `LinearSpectrumFactory`
  * `CyclicSpectrumFactory`
  * `LeaderboardCyclicFactory`\
* 🧪 And more.
---

## 🔧How to install 
To install drosopyla just run the command below:

``pip install drosopyla``

## 📚Tutorials 

You can find tutorials on how to use the library here: https://hackernoon.com/u/papalutavasile

Made with love by Vasile Păpăluță <3