# Importing all needed modules.
from .utils import AMINO_ACID_MASS
from .sequences import Protein
from collections import Counter
from itertools import product
import re


class BaseSpectrumFactory:
    def protein_to_spectrum(self, protein, *args, **kwargs):
        """
            This function converts a Protein object int a list of integers representing their spectrum.
        :param protein: Protein
            The object representing the Peptide sequence.
        :param args: tuple
            Additional arguments.
        :param kwargs: dict
            Additional keyword arguments.
        :raises:
            NotImplemented: Always is raised and should be implemented by children classes.
        """
        raise NotImplementedError(f"The protein_to_spectrum is not implemented for {self.__class__}")

    def spectrum_to_protein(self, spectrum, *args, **kwargs):
        """
            This function converts a Protein object int a list of integers representing their spectrum.
        :param spectrum: list
            A list representing spectrum sequence from mass-spectrometry    .
        :param args: tuple
            Additional arguments.
        :param kwargs: dict
            Additional keyword arguments.
        :raises:
            NotImplemented: Always is raised and should be implemented by children classes.
        """
        raise NotImplementedError(f"The spectrum_to_protein is not implemented for {self.__class__}")

    def spectrum_score(self, protein, spectrum : list) -> int:
        """
            This function how strongly a spectrum is matching with a protein sequence.
        :param protein: Protein
            The Protein object representing the protein sequence.
        :param spectrum: list
            A list representing spectrum sequence from mass-spectrometry.
        :return: int
            The score measuring the matching between the peptide and spectrum.
        """
        # Calculating the theoretical spectrum of the protein.
        theoretical_spectrum = self.protein_to_spectrum(protein)
        score = 0

        # Counting the frequency of values in the theoretical and real spectrum
        theoretical_counter = Counter(theoretical_spectrum)
        spectrum_counter = Counter(spectrum)

        # Computing the score as the sum of minimal frequency of all masses in the theoretical spectrum.
        for mass in theoretical_counter:
            if mass in spectrum_counter:
                score += min(theoretical_counter[mass], spectrum_counter[mass])
        return score


class LinearSpectrumFactory(BaseSpectrumFactory):
    def protein_to_spectrum(self, protein, *args, **kwargs):
        """
            This function converts a Protein object int a list of integers representing their spectrum.
        :param protein: Protein
            The object representing the Peptide sequence.
        :param args: tuple
            Additional arguments.
        :param kwargs: dict
            Additional keyword arguments.
        :raises:
            ValueError: If the provided protein sequence is not of the type Protein.
        """
        # Checking the data type of the provided protein.
        if not isinstance(protein, Protein):
            raise ValueError("The provided protein sequence should be of the type Protein.")

        # Creating the initial list with molar masses of amino acids.
        prefix_masses = [0]
        for i in range(1, len(protein) + 1):
            prefix_masses.append(
                prefix_masses[i - 1] + AMINO_ACID_MASS[protein[i - 1].string()]
            )
        # Extending the list with molar masses with the molar masses of all possible sub-peptides.
        linear_spectrum_list = [0]
        for i in range(len(protein) + 1):
            for j in range(i + 1, len(protein) + 1):
                linear_spectrum_list.append(prefix_masses[j] - prefix_masses[i])
        # Sorting the spectrum.
        return sorted(linear_spectrum_list)


class CyclicSpectrumFactory(BaseSpectrumFactory):
    def __init__(self):
        """
            The constructor of the Cyclic Spectrum Factory.
        """
        super().__init__()
        # Creating the instance of the linear spectrum and the amino acid masses mapper.
        self.linear_spectrum = LinearSpectrumFactory()
        self.amino_acid_masses_mapper = AMINO_ACID_MASS.copy()

    def protein_to_spectrum(self, protein, *args, **kwargs):
        """
            This function converts a Protein object int a list of integers representing their spectrum.
        :param protein: Protein
            The object representing the Peptide sequence.
        :param args: tuple
            Additional arguments.
        :param kwargs: dict
            Additional keyword arguments.
        :raises:
            ValueError: If the provided protein sequence is not of the type Protein.
        """
        # Checking the data type of the provided protein.
        if not isinstance(protein, Protein):
            raise ValueError("The provided protein sequence should be of the type Protein.")

        # Creating the initial list with molar masses of amino acids.
        prefix_masses = [0]
        for i in range(1, len(protein) + 1):
            prefix_masses.append(
                prefix_masses[i - 1] + self.amino_acid_masses_mapper[protein[i - 1].string()]
            )
        # Getting the molar mass of the protein.
        protein_mass = prefix_masses[len(protein)]

        # Extending the molar mass list with the molar masses of sub-peptides.
        cycling_spectrum_list = [0]
        for i in range(len(protein) + 1):
            for j in range(i + 1, len(protein) + 1):
                cycling_spectrum_list.append(prefix_masses[j] - prefix_masses[i])
                if i > 0 and j < len(protein):
                    cycling_spectrum_list.append(protein_mass - (prefix_masses[j] - prefix_masses[i]))
        # Sorting the spectrum.
        return sorted(cycling_spectrum_list)

    def _mass_to_amino_acid(self, mass : int) -> str:
        """
            This function returns one or more amino acids that has the provided molar mass.
        :param mass: int
            The molar mass for the interested amino acid.
        :return: str
            The string representing one or more amino acids.
        """
        # Searching for all amino acids with the specified mass.
        amino_acids = []
        for aa in self.amino_acid_masses_mapper:
            if self.amino_acid_masses_mapper[aa] == mass:
                amino_acids.append(aa)
        if len(amino_acids) > 1:
            return f"[{''.join(sorted(amino_acids))}]"
        else:
            return amino_acids[0]

    def _expand_sequences(self, sequence : str) -> list:
        """
            This function expands a peptide sequence if it has variable amino acids.
        :param sequence: str
            The string representing the peptide sequence.
        :return: list
            All variable sequences.
        """
        # Extracting the parts of the amino acids sequences by splitting variable parts.
        parts = re.split(r"\[([^\]]+)\]", sequence)
        if len(parts) == 1:
            return [sequence]
        else:
            # Getting the fixed and variable parts.
            fixed_parts = parts[::2]
            variable_parts = [list(part) for part in parts[1::2]]

            # Getting and returning all possible combinations.
            combinations = product(*variable_parts) if variable_parts else [[]]

            return ["".join(sum(zip(fixed_parts, combo + ("",)), ())) for combo in combinations]

    def _expand(self, proteins : list) -> list:
        """
            This function expands a list of peptide sequences by adding every amino acid to each of the sequences.
        :param proteins: list
            The list of objects of type Protein.
        :return: list
            The list of objects of type Protein extended by adding all amino acids.
        :raises:
            ValueError: If the provided protein sequence is not of the type Protein.
        """
        # Checking the data type of the provided protein sequences.
        for protein in proteins:
            if not isinstance(protein, Protein):
                raise ValueError("The provided protein sequences should be of the type Protein.")

        # Getting a list of amino acids and defining the empty set of expanded peptides.
        amino_acids = list(self.amino_acid_masses_mapper.keys())
        expanded_proteins = set()
        # Expanding all peptide sequences.
        for protein in proteins:
            if protein.string() == "":
                for aa in amino_acids:
                    expanded_proteins.add(Protein(aa))
            else:
                for aa in amino_acids:
                    expanded_proteins.add(Protein(protein.string() + aa))
        return expanded_proteins

    def _consistent_cyclo_spectrum(self, protein, spectrum : list) -> bool:
        """
            This function checks if a Protein object is consistent with a cyclic spectrum.
        :param protein: Protein
            The Protein object representing the peptide sequence.
        :param spectrum: list
            A list representing spectrum sequence from mass-spectrometry.
        :return: bool
            The boolean value representing the consitency of the spectrum and cyclic peptide sequence.
        """
        # Getting the frequencies of values in the theoretical and real spectrums.
        protein_spectrum_counter = Counter(self.protein_to_spectrum(protein))
        spectrum_counter = Counter(spectrum)

        # Checking if the spectrums are matching.
        if protein_spectrum_counter == spectrum_counter:
            return True
        else:
            return False

    def _is_consistent(self, protein, spectrum):
        """
            This function checks if a Protein object is consistent with a cyclic spectrum.
        :param protein: Protein
            The Protein object representing the peptide sequence.
        :param spectrum: list
            A list representing spectrum sequence from mass-spectrometry.
        :return: bool
            The boolean value representing the consitency of the spectrum and cyclic peptide sequence.
        """
        # Getting the theoretical linear spectrum of a peptide.
        curr_spectrum = self.linear_spectrum.protein_to_spectrum(protein)

        # Getting the frequencies of values in the theoretical and real spectrums.
        curr_spectrum_counter = Counter(curr_spectrum)
        spectrum_counter = Counter(spectrum)

        # Checking if the frequencies of mass in the theoretical spectrum is lower or equal to frequencies of masses in
        # the real spectrum.
        for key, value in curr_spectrum_counter.items():    
            if value > spectrum_counter[key]:
                return False
        return True

    def spectrum_to_protein(self, spectrum, *args, **kwargs):
        """
            This function converts a Protein object int a list of integers representing their spectrum.
        :param spectrum: list
            A list representing spectrum sequence from mass-spectrometry.
        :param args: tuple
            Additional arguments.
        :param kwargs: dict
            Additional keyword arguments.
        """
        # Getting the molar mass of from the spectrum.
        parent_mass = max(spectrum)

        # Defining the set and list for storing protein candidates.
        candidate_proteins = {Protein("")}
        final_proteins = []
        while len(candidate_proteins) > 0:
            # Expanding the set on candidates.
            candidate_proteins = self._expand(candidate_proteins)
            deletions = []
            for protein in candidate_proteins:
                # Comparing the molar mass of the generated protein.
                if protein.compute_mass() == parent_mass:
                    # Checking the cyclo-peptide consistency.
                    if self._consistent_cyclo_spectrum(protein, spectrum):
                        final_proteins.append(protein)
                    # Adding the protein for deletion if no checks are passed.
                    deletions.append(protein)
                # Checking the consistency of the protein and spectrum.
                elif not self._is_consistent(protein, spectrum):
                    deletions.append(protein)
            # Deleting the proteins that didn't passed all checks.
            for p in deletions:
                candidate_proteins.remove(p)

        return final_proteins


class LeaderboardCyclicFactory(CyclicSpectrumFactory):
    def __init__(self, n_highest_scored : int = None) -> None:
        """
            The constructor of  the Leaderboard Cyclic sequencing.
        :param n_highest_scored: int
            The number of leaders taken into account in one iteration.
        """
        super().__init__()
        self.n_highest_scored = n_highest_scored

    def trim_leaderboard(self, leaderboard : list, spectrum : list) -> list:
        """
            This function shortens the leaderboard to the n-highest scores.
        :param leaderboard: list
            The list of Protein objects.
        :param spectrum: list
            The molar mass-spectrometry to be scored against.
        :return: list
            The list of n-highest scoring Protein objects.
        """
        # Creating the empty list for storing the peptide's scores.
        linear_scores = []
        # Calculating the spectrum score of the every peptide sequence in the leaderboard.
        for i in range(len(leaderboard)):
            linear_scores.append(self.linear_spectrum.spectrum_score(leaderboard[i], spectrum))
        # Sorting the leaderboard and scores.
        leaderboard = sorted(leaderboard, key=lambda x : linear_scores[leaderboard.index(x)], reverse=True)
        linear_scores.sort(reverse=True)

        # Trimming the leaderboard to n-highest scoring peptides.
        for i in range(self.n_highest_scored + 1, len(leaderboard)):
            if linear_scores[i] < linear_scores[self.n_highest_scored - 1]:
                leaderboard[i] = Protein("*")
                return leaderboard[:leaderboard.index(Protein("*")) - 1]
        return leaderboard

    def spectrum_to_protein(self, spectrum, *args, **kwargs):
        """
            This function converts a Protein object int a list of integers representing their spectrum.
        :param spectrum: list
            A list representing spectrum sequence from mass-spectrometry.
        :param args: tuple
            Additional arguments.
        :param kwargs: dict
            Additional keyword arguments.
        :return: Protein
            The highest scoring peptide sequence.
        """
        if "amino_acid_masses" in kwargs:
            amino_acid_masses = kwargs["amino_acid_masses"]
        else:
            amino_acid_masses = None
        # Defining the empty leaderboard and empty peptide sequence.
        leaderboard = {Protein("")}
        leader_protein = Protein("")
        while len(leaderboard):
            to_remove = []
            # Expanding the leaderboard with new peptides.
            leaderboard = self._expand(list(leaderboard))
            for protein in leaderboard:
                # Comparing the molar mass of the generated protein.
                if protein.compute_mass(amino_acid_masses_dict=amino_acid_masses) == spectrum[-1]:
                    # Comparing the new peptide spectrum score to the leader peptide spectrum score.
                    if self.spectrum_score(protein, spectrum) >= self.spectrum_score(leader_protein, spectrum):
                        leader_protein = protein
                # Removing peptides with the molar mass higher the one from spectrum.
                elif protein.compute_mass() > spectrum[-1]:
                    to_remove.append(protein)
            for protein in to_remove:
                leaderboard.remove(protein)
            # Trimming the leaderboard.
            leaderboard = set(self.trim_leaderboard(list(leaderboard), spectrum))
        # Expanding the peptides with multiple possibilities bases on same mass amino acids.
        leader_protein_string = leader_protein.string()

        poly_amino_acids = []
        masses = list(self.amino_acid_masses_mapper.values())
        for mass in masses:
            if masses.count(mass) > 0 and mass not in poly_amino_acids:
                poly_amino_acids.append(self._mass_to_amino_acid(mass))

        for pattern in poly_amino_acids:
            for letter in list(pattern[1:][:-1]):
                leader_protein_string = leader_protein_string.replace(letter, pattern.lower())

        for pattern in poly_amino_acids:
            leader_protein_string = leader_protein_string.replace(pattern.lower(), pattern)

        # Generating the new list of peptides.
        new_peptides = self._expand_sequences(leader_protein_string)
        new_peptides = [Protein(peptide_string) for peptide_string in new_peptides]
        return new_peptides
