# Importing all needed libraries.
from .distances import hamming_distance, pattern_collection_distance
from .sequences import DNASequence, RNASequence, Protein
from .utils import generate_all_kmers
from .profile import Profile
import random


def neighbors(pattern, d : int = 0) -> list:
    """
        This function generates all possible neighbors of a sequence that is at least 1 nucleotide away.
    :param pattern: DNASequence or RNASequence
        The DNA or RNA Sequence object.
    :param d: int, default = 0
        The hamming distance threshold.
    :return: list
        The list of sequence objects.
    """
    # Getting the list of nucleotides depending on the sequence type.
    if type(pattern) is DNASequence:
        nbs = [DNASequence(nb) for nb in list("ACGT")]
    elif type(pattern) is RNASequence:
        nbs = [RNASequence(nb) for nb in list("ACGU")]
    elif type(pattern) is Protein:
        nbs = [Protein(nb) for nb in list("GASPVTCILNDKQEMHFRYW")]
    
    # Returning the pattern itself in case the distance threshold is equal to 0.
    if d == 0:
        return [pattern]
    # Returning all nucleotides in case the pattern is only one nucleotide long.
    if len(pattern) == 1:
        return nbs
    # Defining the empty set for storing all generated neighbors.
    neighborhood = set()

    # Recursively getting the suffix neighbors.
    suffix_neighbors = neighbors(pattern[1:], d = d)
    for sequence in suffix_neighbors:
        # Checking if a generated sequence is within the hamming distance threshold from the pattern suffix.
        if hamming_distance(pattern[1:], sequence) < d:
            # Adding a new neighbor.
            for nucleotide in nbs:
                neighborhood.add(
                    pattern.__class__(nucleotide.string() + sequence.string())
                )
        else:
            neighborhood.add(
                pattern.__class__(pattern[0].string() + sequence.string())
            )
    return list(neighborhood)


class BaseMotifSearcher:
    def __init__(self, k : int) -> None:
        """
            The constructor of the Base Motif Searcher/
        :param k: int
            The size of the k-mer searched for.
        """
        self.k = k

    def motif_search(self, sequences : list, *args : tuple, **kwargs : dict):
        """
            The base function for searching for motifs in sequences.
        :param sequences: list
            The list of DNA or RNA sequences.
        :param args: tuple
            The additional ordered arguments.
        :param kwargs: dict
            The additional keyword arguments.
        :raises:
            NotImplemented: Always raised.
        """
        raise NotImplemented("motif_search not implemented.")


class SimpleMotifSearcher(BaseMotifSearcher):
    def __init__(self, k : int, d : int) -> None:
        """
            The constructor of the Simple Motif Searcher.
        :param k: int
            The size of the k-mer searched for.
        :param d: int
            The hamming distance threshold for searching similar sequences.
        """
        super().__init__(k)
        self.d = d

    def motif_search(self, sequences : list, *args : tuple, **kwargs : dict) -> list:
        """
            The base function for searching for motifs in sequences.
        :param sequences: list
            The list of DNA or RNA sequences.
        :param args: tuple
            The additional ordered arguments.
        :param kwargs: dict
            The additional keyword arguments.
        :return: list
            The list of found motifs.
        """
        # Defining the empty set for storing motifs.
        patterns = set()
        # Getting all unique k-mers from the first sequence in the collection.
        first_sequences_patterns = set(sequences[0].get_kmers(self.k))
        for kmer in first_sequences_patterns:
            # Generating the set of d-neighbors for a specific k-mer.
            d_neighbors = neighbors(sequences[0].__class__(kmer), d = self.d)
            # Checking if a neighbor is present in all sequence within the hamming distance threshold.
            for neighbor in d_neighbors:
                present_in_all = []
                for i in range(1, len(sequences)):
                    # Getting all unique k-mers from the sequence.
                    pats = set(sequences[i].get_kmers(self.k))
                    pats = [sequences[0].__class__(p) for p in pats]
                    # Checking if the distance between the neighbor and any k-mer is lower than the
                    # hamming distance threshold.
                    for p in pats:
                        if hamming_distance(p, neighbor) <= self.d:
                            # Flagging the presence of a derivative of a neighbor in a sequence.
                            present_in_all.append(True)
                            break
                # Adding the neighbor to the motifs set if it is present in all sequences.
                if len(present_in_all) == len(sequences) - 1:
                    patterns.add(neighbor)
        return [pat.string() for pat in list(patterns)]


class MedianStringMotifSearcher(BaseMotifSearcher):
    def motif_search(self, sequences: list, *args: tuple, **kwargs: dict) -> list:
        """
            This function computes the media string from a sequence collection.
        :param sequences: list
            The list of sequences.
        :param k: int
            The size of the k-mer.
        :return: list
            The list of kmer that are minimizing the hamming distance between the pattern and the sequence collection.
        """
        # Defining the min distance, the empty median strings and the holder of k-mer distances.
        min_distance = int(1_000_000)
        median_strings = []
        kmer_dist = {}
        if isinstance(sequences[0], DNASequence):
            sequence_type = "dna"
        elif isinstance(sequences[0], RNASequence):
            sequence_type = "rna"
        elif isinstance(sequences[0], Protein):
            sequence_type = "pep"

        # Generating all possible k-mers of size
        all_kmers = generate_all_kmers(self.k, sequence_type)
        # Computing the hamming distance between all k-mers and the sequence collection.
        for kmer in all_kmers:
            kmer_dist[kmer] = pattern_collection_distance(sequences[0].__class__(kmer), sequences)
            # Finding the minimum distance.
            if min_distance > kmer_dist[kmer]:
                min_distance = kmer_dist[kmer]
        # Finding all k-mers with the minimal distance to the sequence collection.
        for kmer in kmer_dist:
            if kmer_dist[kmer] == min_distance:
                median_strings.append(kmer)
        return median_strings


class GreedyMotifSearcher(BaseMotifSearcher):
    def __init__(self, k : int, alphabet : str = "ACGT", pseudo_counts : bool = False) -> None:
        """
            The constructor of the Greedy Motif Searcher.
        :param k: int
            The size of the k-mer searched for.
        :param alphabet: str, default = "ACGT",
            The alphabet used profile matrix generation. Use "ACGT" for DNA, "ACGU" for RNA or "GASPVTCILNDKQEMHFRYW" for Protein.
        :param pseudo_counts: bool, default = False
            The boolean argument controlling the use of pseudo counts.
        """
        super().__init__(k)
        self.alphabet = alphabet
        self.nb2index = {self.alphabet[i] : i for i in range(len(self.alphabet))}
        self.pseudo_counts = pseudo_counts

    def _score_motifs(self, motifs : list) -> float:
        """
            This function returns the score of count profile matrix generated from a list of motifs.
        :param motifs: list
            The list of motifs.
        :return: floa
            The score the of profile matrix.
        """
        # Generating the empty count profile matrix.
        n = len(motifs)
        profile = [[0 for _ in range(len(self.alphabet))] for __ in range(self.k)]
        # Filling up the count profile matrix.
        for motif in motifs:
            for i in range(self.k):
                profile[i][self.nb2index[motif[i].string()]] += 1
        # Computing the matrix score.
        matrix_score = 0
        for i in range(self.k):
            matrix_score += max(profile[i])
        return n * self.k - matrix_score

    def motif_search(self, sequences, *args, **kwargs):
        """
            The base function for searching for motifs in sequences.
        :param sequences: list
            The list of DNA or RNA sequences.
        :param args: tuple
            The additional ordered arguments.
        :param kwargs: dict
            The additional keyword arguments.
        :return: list
            The list of found motifs.
        :raises:
            ValueError: if the number of sequences in the sequence collection is lower than the defined number of
            searched motifs for.
        """
        # Creating the list of best motifs by taking
        best_motifs = [sequences[i][:self.k] for i in range(len(sequences))]
        # Defining the best score are infinity and the length of the first sequence.
        best_score = float("inf")
        sequence_1 = sequences[0]
        l1 = len(sequence_1)
        # Iterating through all k-mers in the first sequence.
        for i in range(l1 - self.k + 1):
            motifs = [sequence_1[i:i + self.k]]
            # Creating the motifs list by adding the most probable motif from every sequence.
            for i in range(1, len(sequences)):
                profile = Profile().from_motifs(motifs, self.alphabet, pseudo_counts=self.pseudo_counts)
                motifs.append(profile.get_most_probable_motifs(sequences[i])[0])
            # Getting the current matrix score.
            curr_score = self._score_motifs(motifs)
            # Checking if the best score and the motif collection can be updated.
            if curr_score < best_score:
                best_motifs = motifs
                best_score = curr_score
        return [motif.string() for motif in best_motifs]


class RandomizedMotifSearcher(GreedyMotifSearcher):
    def __init__(self, k : int, seed : int = 42, alphabet : str = "ACGT", pseudo_counts : bool = False) -> None:
        """
            THe constructor of the Randomized Motif Searcher.
        :param k: int
            The size of the k-mer searched for.
        :param seed: int, default = 42
            The seed used for repetitive random generation.
        :param alphabet: str, default = "ACGT"
            The alphabet used profile matrix generation. Use "ACGT" for DNA, "ACGU" for RNA or "GASPVTCILNDKQEMHFRYW" for Protein.
        :param pseudo_counts: bool, default = False
            The boolean argument controlling the use of pseudo counts.
        """
        super().__init__(k, alphabet=alphabet, pseudo_counts=pseudo_counts)
        self.seed = seed
        self.nb2index = {self.alphabet[i]: i for i in range(len(self.alphabet))}
        # Setting up the random seed.
        random.seed(seed)

    def one_random_motif_search(self, sequences : list) -> tuple:
        """
            This function runs one iteration of the random motif search.
        :param sequences: list
            The list of DNA or RNA sequences.
        :return: list and float
            The list of hte motifs with the highest matrix score and the score itself.
        """
        # Creating a motifs list by selecting random k-mers for random sequences.
        l = len(sequences[0])
        m = [random.randint(0, l-self.k-1) for _ in range(len(sequences))]
        motifs = [sequences[i][m[i]:m[i] + self.k] for i in range(len(sequences))]
        # Defining it as the best motifs.
        best_motifs = motifs
        # Computing the matrix score of the best motifs.
        best_score = self._score_motifs(best_motifs)
        while True:
            # Creating the profile matrix from motifs.
            profile = Profile().from_motifs(motifs, alphabet=self.alphabet, pseudo_counts=self.pseudo_counts)
            # Getting the most probable motifs from every sequence.
            motifs = profile.get_motifs_from_sequences(sequences)
            # Calculating the current score.
            curr_score = self._score_motifs(motifs)
            # Updating the score and the best motifs.
            if curr_score < best_score:
                best_motifs = motifs
                best_score = curr_score
            else:
                return best_motifs, best_score

    def motif_search(self, sequences, *args, **kwargs):
        """
            The base function for searching for motifs in sequences.
        :param sequences: list
            The list of DNA or RNA sequences.
        :param args: tuple
            The additional ordered arguments.
        :param kwargs: dict
            The additional keyword arguments.
        :return: list
            The list of found motifs.
        :raises:
            ValueError: if at least one of the sequences is not of type DNASequence or RNASequence.
        """
        # Checking the data type of the sequences.
        for sequence in sequences:
            if not isinstance(sequence, (DNASequence, RNASequence, Protein)):
                raise ValueError("All provided sequences should be of type DNASequence or RNASequence.")
        # Getting the value of number of iteration to run the algorithm of.
        if "n_iter" in kwargs:
            n_iter = kwargs["n_iter"]
        else:
            n_iter = 1000
        # Running for the defined number of iterations.
        best_score = float("inf")
        for iter in range(n_iter):
            # Getting the iterations score and motifs.
            curr_best_motifs, curr_best_score = self.one_random_motif_search(sequences)
            # Updating the score and the motifs.
            if curr_best_score < best_score:
                best_motifs, best_score = curr_best_motifs, curr_best_score
        return [motif.string() for motif in best_motifs]


