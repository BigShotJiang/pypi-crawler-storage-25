from .utils import NB_COMPLIMENTS, RNA2AMINO_ACIDS, AMINO_ACID_MASS


class BaseSequence:
    def __init__(self, sequence : str) -> None:
        """
            The constructor of the base sequence class.
        :param sequence: str
            The string representing the sequence.
        """
        self._sequence = sequence

    def __getitem__(self, item : int):
        """
            The function used for accessing substrings by indexing.
        :param item: int
            The index or range used for accessing subsequence of the sequence.
        :return: sequence
            The subsequence accessed by indexes or ranges.
        """
        return self.__class__(self._sequence[item])

    def __len__(self) -> int:
        """
            This function returns the length of the sequence when used as argument in the len() function call.
        :return: int
            The length of the sequences.
        """
        return len(self._sequence)

    def __eq__(self, other : "sequence") -> bool:
        """
            This function allows to compare the sequences objects as simple sequences. Triggered on == and != operator.
        :param other: object of a sequence type
            The other sequence that the sequence should be compared to.
        :return: bool
            Returns true if the sequences are equal else False.
        """
        return self._sequence == other._sequence

    def __hash__(self):
        """
            This function was created to be able to uniquely identified in the sets.
        :return: binary
            The binary sequence of the biological sequences or simply put hash.
        """
        return hash(self._sequence)

    def string(self) -> str:
        """
            This function return the string sequence.
        :return: str
            The string representation of the sequence.
        """
        return self._sequence

    def count_elements(self, element : str) -> int:
        """
            This function counts the number of subsequences in the sequence.
        :param element: str
            The string sequence to count the frequency of from the sequence.
        :return: int
            The number of the subsequences found in the sequence.
        """
        return self._sequence.count(element)

    def get_kmers(self, k : int) -> list:
        """
            This function generates the list of kmers of the sequence.
        :param k: int
            The size of the kmers to be found.
        :return: list
            The list of strings representing the kmers.
        """
        kmers = []
        for i in range(len(self._sequence) - k + 1):
            kmers.append(self._sequence[i:i+k])
        return kmers

    def get_locations(self, pattern : str) -> list:
        """
            This function finds the indices of a subsequence in a sequence.
        :param pattern: str
            The string pattern for which to find locations.
        :return: list
            The list with indices representing the starting positions of the subsequences.
        """
        indices = []
        for i in range(len(self._sequence) - len(pattern) + 1):
            if self._sequence[i:i+len(pattern)] == pattern:
                indices.append(i)
        return indices

    def iterate(self, L : int):
        """
            This function allows iteration through the sequence with a defined window size yielding all windows.
        :param L: int
            The size of the window.
        """
        for i in range(0, len(self._sequence), L):
            window = self._sequence[i:i+L if i + L < len(self._sequence) else None]
            yield self.__class__(window)

    def includes(self, subsequence : "sequence") -> bool:
        """
            This function tests for the presence of a subsequence in the sequence.
        :param subsequence: sequence object
            The subsequence to test the presence of in the sequence.
        :return: bool
            True if the sequence includes the subsequence else False.
        """
        return subsequence.string() in self._sequence


class DNASequence(BaseSequence):
    def __init__(self, sequence : str) -> None:
        """
            The constructor of the DNA Sequence.
        :param sequence: str
            The string representation of the DNA sequence.
        """
        super().__init__(sequence)

    def get_complement(self):
        """
            This function returns the complement DNA Sequence.
        :return: DNASequence
            The complementary DNA Sequence.
        """
        compliment = ""
        for nb in self._sequence:
            compliment += NB_COMPLIMENTS[nb]
        return DNASequence(compliment)

    def get_reverse_complement(self):
        """
            This function returns the reverse complement of the
        :return: DNASequence
            The Reverse complement of the DNA Sequence.
        """
        compliment = self.get_complement()
        return DNASequence(compliment[::-1].string())

    def get_mrna(self):
        """
            This function returns the RNA sequence generated from the DNA one.
        :return: RNASequence
            The RNA Sequences obtained from DNA translation.
        """
        mrna = self._sequence.replace("T",  "U")
        return RNASequence(mrna)

    def __str__(self):
        """
            This function returns the string representation of the object. Called by str and print functions.
        :return: str
            The string representation of the object.
        """
        return f"<DNA: {self._sequence if len(self._sequence) <= 20 else self._sequence[:10] + '...' + self._sequence[-10:]}>"


class RNASequence(BaseSequence):
    def __init__(self, sequence):
        """
            The constructor of the RNA Sequence.
        :param sequence: str
            The string representation of the RNA sequence.
        """
        super().__init__(sequence)

    def transcribe(self, codons_mapper : dict = None):
        """
            This function transcribes the RNA into the Protein sequence.
        :param codons_mapper: dict, default = None
            The dictionary containing the mapping of the codons to Amino Acids.
        :return: Protein
            The protein object transcribed from the RNA Sequence.
        """
        # Checking if the length of the sequence is divisible by 3.
        if len(self) % 3 != 0:
            raise ValueError("The length of the RNA sequence is not dividable by 3")

        if codons_mapper is None:
            codons_mapper = RNA2AMINO_ACIDS

        # Adding amino acids one by one depending on RNA codons.
        amino_acids = ""
        for i in range(0, len(self._sequence), 3):
            amino_acids += codons_mapper[self._sequence[i:i+3]]
        return Protein(amino_acids)

    def back_translation(self):
        """
            This function converts the RNA Sequence back to the DNA Sequence.
        :return: DNASequence
            The DNA Sequence from which RNA Sequence can be translated.
        """
        return DNASequence(self._sequence.replace("U", "T"))

    def __str__(self):
        """
            This function returns the string representation of the object. Called by str and print functions.
        :return: str
            The string representation of the object.
        """
        return f"<RNA: {self._sequence if len(self._sequence) <= 20 else self._sequence[:10] + '...' + self._sequence[-10:]}>"


class Protein(BaseSequence):
    def __init__(self, sequence):
        """
            The constructor of the Protein Sequence.
        :param sequence: str
            The string representation of the Protein sequence.
        """
        super().__init__(sequence)

    def compute_mass(self, amino_acid_masses_dict : dict = None) -> int:
        """
            This function computes the molar mass of the protein sequence.
        :param amino_acid_masses_dict: dict, default = None
            The dictionary mapping an amino acid to its Molar mass.
        :return: int
            The molar mass of the protein sequence.
        :raises:
            ValueError: If the amino acid masses dictionary is provided and it is not of type dict.
        """
        if amino_acid_masses_dict is None:
            return sum([AMINO_ACID_MASS[amino_acid] for amino_acid in self._sequence])
        else:
            if not isinstance(amino_acid_masses_dict, dict):
                raise ValueError("If provided the amino_acid_masses_dict should be a dictionary")
            else:
                return sum([amino_acid_masses_dict[amino_acid] for amino_acid in self._sequence])

    def __str__(self):
        """
            This function returns the string representation of the object. Called by str and print functions.
        :return: str
            The string representation of the object.
        """
        return f"<Protein: {self._sequence if len(self._sequence) <= 20 else self._sequence[:10] + '...' + self._sequence[-10:]}>"