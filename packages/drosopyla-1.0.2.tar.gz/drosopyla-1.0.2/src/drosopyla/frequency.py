# Importing all needed modules.
from collections import Counter
import matplotlib.pyplot as plt
from .sequences import DNASequence
from .motif_search import neighbors


class BaseFrequencyTable:
    def __init__(self, sequence, k) -> None:
        """
            This function configures simple frequency table and counts the frequency of every k-mer in the sequence.
        :param sequence: DNASequence or RNASequence
            The biological sequence in which to count the k-mer frequency.
        :param k: int
            The length of the k-mers.
        """
        # Configuring the sequence and k parameters.
        self.sequence = sequence
        self.k = k

        self.counter = Counter()
        self.most_frequent_kmers = []

    def most_common(self, n : int) -> dict:
        """
            This function is returning n most common k-mers from the sequence.
        :param n: int
            The number representing how many most common k-mers should be returned.
        :return: dict
            The dictionary containing the n most common k-mers and their frequencies.
        """
        return dict(self.counter.most_common(n))

    def to_dict(self) -> dict:
        """
            This function returns the counter object as a dictionary.
        :return: dict
            The dictionary form of the frequency counter.
        """
        return dict(self.counter)

    def barplot(self, figsize : tuple =(16, 10)) -> None:
        """
            This function generates a bar plot showing the frequency of k-mers in the sequence.
        :param figsize: tuple
            The tuple containing the figure size configuration for the bar plot.
        """
        # Getting the k-mer-frequency pairs from the counter and sorting them by frequency reversed.
        items = self.counter.items()
        items = sorted(items, key=lambda x : x[1], reverse=True)
        # Preparing the data for plotting.
        x = [item[0] for item in items]
        y = [item[1] for item in items]
        c = ["red" if items[i] in self.most_frequent_kmers else "blue" for i in range(len(items))]
        plt.figure(figsize=figsize)
        plt.bar(x, y, c=c)
        plt.xlabel("Kmers")
        plt.ylabel("Count")
        plt.xticks(rotation = 90)
        plt.show()

    def __getitem__(self, item : str) -> int:
        """
            This function returns the frequency of a k-mer in sequence.
        :param item: str
            The k-mer.
        :return: int
            The frequency of the k-mer in the sequence.
        """
        return self.counter.get(item)

    def get_most_frequent_kmers(self) -> list:
        """
            This function returns the most frequent k-mers.
        :return: list
            The list of most frequent k-mers.
        """
        return self.most_frequent_kmers


class SimpleFrequencyTable(BaseFrequencyTable):
    def __init__(self, sequence, k : int) -> None:
        """
            This function configures simple frequency table and counts the frequency of every k-mer in the sequence.
        :param sequence: DNASequence or RNASequence
            The biological sequence in which to count the k-mer frequency.
        :param k: int
            The length of the k-mers.
        """
        super().__init__(sequence, k)

        # Getting all k-mers and counting their frequencies.
        kmers = self.sequence.get_kmers(k)
        self.frequencies = {}

        self.counter = Counter(kmers)
        self.most_frequent_kmers = []

        m = max(dict(self.counter).values())

        # Getting the most frequent k-mers in the frequency table.
        for key in self.counter:
            if self.counter[key] == m:
                self.most_frequent_kmers.append(key)

class FrequencyTableWithMismatch(BaseFrequencyTable):
    def __init__(self, sequence, k : int, missmatch_delta : int) -> None:
        """
            The constructor of the Frequency Table with missmatch that configures the class and runs the kmers finding
            process.
        :param sequence: DNASequence or RNASequence
            The sequence in which is required to calculate the k-mer frequency.
        :param k: int
            The desired length of the k-mers.
        :param missmatch_delta: int
            The hamming distance threshold for matching k-mers.
        """
        super().__init__(sequence, k)
        self.missmatch_delta = missmatch_delta
        # Running the kmers search.
        self.find_kmers_with_missmatch()

    def find_kmers_with_missmatch(self):
        """
            This function searches for the k-mers with missmatch.
        """
        # Defining the empty list for storing the most frequent k-mers and the dictionary for storing k-mer frequency.
        self.most_frequent_kmers = []
        frequency_map = {}
        # Getting the k-mers of the sequence.
        kmers = self.sequence.get_kmers(self.k)
        for kmer in kmers:
            # Getting all d-neighbors of a k-mer.
            neighborhood = neighbors(self.sequence.__class__(kmer), self.missmatch_delta)
            # Updating the neighbor's frequency in the frequency dictionary.
            for j in range(len(neighborhood)):
                if not neighborhood[j].string() in frequency_map:
                    frequency_map[neighborhood[j].string()] = 0
                frequency_map[neighborhood[j].string()] += 1
        # Creating the counter from the frequency map.
        self.counter = Counter(frequency_map)
        # Getting the highest frequency.
        m = max(frequency_map.values())

        # Getting the most frequent k-mers in the frequency table.
        for key in frequency_map:
            if frequency_map[key] == m:
                self.most_frequent_kmers.append(key)


class FrequencyTableWithMismatchAndReverseComplements(BaseFrequencyTable):
    def __init__(self, sequence, k : int, missmatch_delta : int) -> None:
        """
            The constructor of the Frequency Table with missmatch that configures the class and runs the kmers finding
            process.
        :param sequence: DNASequence or RNASequence
            The sequence in which is required to calculate the k-mer frequency.
        :param k: int
            The desired length of the k-mers.
        :param missmatch_delta: int
            The hamming distance threshold for matching k-mers.
        """
        self.sequence = sequence
        self.k = k
        self.missmatch_delta = missmatch_delta
        # Running the kmers search.
        self.find_kmers_with_missmatches_and_reverse_complements()

    def find_kmers_with_missmatches_and_reverse_complements(self):
        """
            This function searches for the k-mers with missmatch and reverse complements.
        """
        # Defining the empty list for storing the most frequent k-mers and the dictionary for storing k-mer frequency.
        self.most_frequent_kmers = []
        frequency_map = {}
        # Getting the k-mers of the sequence.
        kmers = self.sequence.get_kmers(self.k)
        for kmer in kmers:
            # Getting all d-neighbors of a k-mer.
            neighborhood = neighbors(self.sequence.__class__(kmer), self.missmatch_delta)
            # Updating the neighbor's frequency in the frequency dictionary.
            for j in range(len(neighborhood)):
                if not neighborhood[j].string() in frequency_map:
                    frequency_map[neighborhood[j].string()] = 0
                frequency_map[neighborhood[j].string()] += 1
                # Getting the reverse complement of the neighbor.
                reverse_compliment = DNASequence(neighborhood[j].string()).get_reverse_complement().string()
                # Updating the frequency of the reverse complement of the neighbor in frequency map.
                if not reverse_compliment in frequency_map:
                    frequency_map[reverse_compliment] = 0
                frequency_map[reverse_compliment] += 1
        # Creating counter from the frequency map.
        self.counter = Counter(frequency_map)
        # Getting the highest frequency.
        m = max(frequency_map.values())
        # Getting the most frequent k-mers in the frequency table.
        for key in frequency_map:
            if frequency_map[key] == m:
                self.most_frequent_kmers.append(key)