# Importing all needed modules.
import pandas as pd
import numpy as np


class Profile:
    def from_motifs(self, motifs : list, alphabet : str = "ACGT", pseudo_counts : bool = False):
        """
            This function creates the Profile matrix from a list of motifs.
        :param motifs: list
            The list of motifs of type DNASequence, RNASequence or Protein.
        :param alphabet: str, default = "ACGT"
            The string containing the alphabet of the sequence type, "ACGT" for DNA and "ACGU" for RNA or amino acid
            list for Protein.
        :param pseudo_counts: bool, default = False
            The boolean argument controlling the user of pseudo counts.
        :return: Profile
            Returning the object itself.
        """
        # Getting the sizes of the profile matrix.
        k, n = len(motifs[0]), len(motifs)
        # Creating the alphabet list and the nucleotide base to index mapper.
        self.alphabet = list(alphabet)
        self.nb2index = {alphabet[i] : i for i in range(len(self.alphabet))}

        # Creating and populating the probability matrix.
        probability_matrix = [[0 for _ in range(k)] for __ in range(len(self.alphabet))]
        for motif in motifs:
            for i in range(k):
                probability_matrix[self.nb2index[motif[i].string()]][i] += 1

        # Saving the shape of the probability matrix.
        probability_matrix = np.array(probability_matrix)
        self.shape = probability_matrix.shape

        # Checking if the pseudo-counts should be applied.
        if pseudo_counts:
            probability_matrix += 1
            probability_matrix = probability_matrix / float(n + len(self.alphabet))
        else:
            probability_matrix = probability_matrix / n

        # Converting the probability matrix into a pandas DataFrame.
        self.df = pd.DataFrame(
            probability_matrix,
            index=self.alphabet
        )
        return self

    def from_probability_matrix(self, probability_matrix : list, alphabet : str = "ACGT"):
        """
            This function creates the profile matrix from a probability matrix.
        :param probability_matrix: list, 2d or np.array
            A 2-d list with the probabilities of every nucleotide per position.
            rows = nucleotides, columns = positions
        :param alphabet: str, default = "ACGT"
            The string containing the alphabet of the sequence type, "ACGT" for DNA and "ACGU" for RNA or amino acid
            list for Protein.
        :return: Profile
            Returning the object itself.
        """
        # Converting the probability matrix into an numpy array.
        if type(probability_matrix) is not np.array:
            probability_matrix = np.array(probability_matrix)
        # Checking is the probabilities if the columns are summing up to one.
        if not np.allclose(probability_matrix.sum(axis=0), np.ones(probability_matrix.shape[1])):
            raise ValueError("The columns of the provided probability matrix does not add to 1")
        # Setting up the parameters.
        self.shape = probability_matrix.shape
        self.alphabet = list(alphabet)
        # Converting the probability matrix into a pandas DataFrame.
        self.df = pd.DataFrame(
            probability_matrix,
            index=self.alphabet
        )
        return self

    def sequence_probability(self, sequence) -> float:
        """
            This function calculates the probability of a sequence based on the profile matrix.
        :param sequence: DNASequence, RNASequence or Protein.
            The DNA or RNA sequence to which the probability is required to be calculated from the metrix.
        :return: float
            The probability of the sequence.
        :raises:
            ValueError: if the length of the shape if different from the number of columns of the profile matrix.
            ValueError: if the alphabet of the sequence and the alphabet of the profile matrix are different.
        """
        # Checking if the length of the sequence matches with the profile matrix shape.
        if len(sequence) != self.shape[1]:
            raise ValueError(f"The provided sequence length is different from the number of columns in the profile matrix:" \
                             f"{len(sequence)} != {self.shape[1]}")
        # Checking if the sequence and profile matrix alphabets are matching.
        if len(set(list(sequence.string())).difference(set(self.alphabet))) > 0:
            raise ValueError("The provided the sequence uses different alphabet that the one in Profile matrix")
        # Calculating the probability of the sequence based on the profile matrix.
        probability = 1
        for i in range(self.shape[1]):
            probability *= self.df.loc[sequence[i].string(), i]
        return probability

    def get_most_probable_motifs(self, sequence) -> list:
        """
            This function returns the most probable motifs from a provided sequence.
        :param sequence: DNASequence, RNASequence or Protein.
            The sequence from which is required to get the most probable motifs.
        :return: list
            The list of the most probable sequences.
        """
        # Checking if the sequence and profile matrix alphabets are matching.
        if len(set(list(sequence.string())).difference(set(self.alphabet))) > 0:
            raise ValueError("The provided the sequence uses different alphabet that the one in Profile matrix")
        # Getting the length of the motifs to search for from the profile matrix.
        k = self.shape[1]
        # Creating the list for storing the most probable motifs.
        most_probable_motifs = []
        # Getting the unique k-mers from the sequence.
        kmers = set(sequence.get_kmers(k))
        kmers_probability = {}

        # Calculating the probability of every k-mer from the probability matrix.
        for kmer in kmers:
            kmers_probability[kmer] = self.sequence_probability(sequence.__class__(kmer))

        # Getting the highest probability and the k-mers with the highest probabilities.
        max_probability = max(kmers_probability.values())

        for kmer in kmers_probability:
            if kmers_probability[kmer] == max_probability:
                most_probable_motifs.append(kmer)
        most_probable_motifs = sorted(most_probable_motifs)
        return [sequence.__class__(seq) for seq in most_probable_motifs]

    def get_motifs_from_sequences(self, sequences : list) -> list:
        """
            This function extracts from every sequence in the sequence collection one most probable motif.
        :param sequences: list
            The list of sequences of type DNASequence, RNASequence or protein.
        :return: list
            The list of motifs of type DNASequence or RNASequence.
        """
        for sequence in sequences:
            # Checking the alphabet for every sequence in the collection.
            if len(set(list(sequence.string())).difference(set(self.alphabet))) > 0:
                raise ValueError("The provided the sequence uses different alphabet that the one in Profile matrix")
        # Getting one motif from every sequence in the sequence collection.
        new_motifs = []
        for i in range(len(sequences)):
            motif = self.get_most_probable_motifs(sequences[i])[0]
            new_motifs.append(motif)
        return new_motifs
