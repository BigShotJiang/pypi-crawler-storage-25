# Importing all needed modules.
from .utils import AMINO_ACIDS2RNA
from .sequences import RNASequence, DNASequence


class ProteinToRNA:
    def create(self, protein : "Protein", aa_codon_mapper : dict = None) -> list:
        """
            This function returns all the RNA sequences that can encode a provided Protein.
        :param protein: Protein
            The protein sequence object.
        :param aa_codon_mapper: dict, default = None
            The dictionary containing the mapping of the amino acids to nucleotide codons.
        :return: list
            The list with RNASequence object that encode the protein sequence.
        """
        # Checking the amino acid codon mapper offered.
        if aa_codon_mapper is None:
            aa_codon_mapper = AMINO_ACIDS2RNA

        # Defining the empty list to store the possible RNA sequence.
        versions = []

        # Iterating through the amino acids sequence.
        for amino_acid in protein.iterate(1):
            # Creating a new empty temporal version to add the new sequences.
            temp_versions = []
            if len(versions) > 0:
                # Extending the existing versions with amino acids.
                for version in versions:
                    for rna_codon in aa_codon_mapper[amino_acid._sequence]:
                        new_version = version + rna_codon
                        temp_versions.append(new_version)
                # Replacing the old list with RNA versions with the extended one.
                versions = temp_versions
            else:
                # Creating the initial seed sequence on RNA codons.
                for rna_codon in aa_codon_mapper[amino_acid._sequence]:
                    new_version = rna_codon
                    temp_versions.append(new_version)
                versions = temp_versions
        # Limiting the RNA sequences only to the unique ones.
        versions = list(set(versions))

        # Returning the result as a list of RNASequence objects.
        versions = [RNASequence(version) for version in versions]
        return versions


class ProteinEncodingRegionFinder:
    def __init__(self):
        """
            The constructor of Protein Encoding Region Finder.
            Creating the Protein to RNA encoder.
        """
        self.protein_to_rna_encoder = ProteinToRNA()

    def find(self, sequence, protein : "Protein", aa_codon_mapper : dict = None) -> list:
        """
            This function finds the region encoding a protein in a RNA or DNA sequence.
        :param sequence: DNASequence or RNASequence
            The DNA or RNA sequence object.
        :param protein: Protein object
            The protein which the encoding region is searched for.
        :param aa_codon_mapper: dict, default = None
            The dictionary containing the mapping of the amino acids to nucleotide codons.
        :return:
            The list with DNASequence or RNASequence objects found in the sequence encoding the provided
            Protein.
        """
        if type(sequence) is not DNASequence and type(sequence) is not RNASequence:
            raise ValueError("The provided sequence is not a DNASequence or RNASequence object.")
        # Defining the empty list for storing found regions.
        regions = []
        # Converting the protein sequence into possible RNA sequences.
        encoding_possibilities = self.protein_to_rna_encoder.create(protein, aa_codon_mapper=aa_codon_mapper)

        # Finding the protein encoding sequences in the RNA sequence.
        if type(sequence) is RNASequence:
            for rna in encoding_possibilities:
                if sequence.includes(rna):
                    regions.append((rna, "->"))
        # Finding the protein encoding sequences in the DNA sequence and its reverse complement.
        elif type(sequence) is DNASequence:
            # Getting the DNA reverse complement.
            dna_reverse_complement = sequence.get_reverse_complement()

            for rna in encoding_possibilities:
                # Back translating the RNA sequence into DNA sequence.
                dna_sequence = rna.back_translation()

                # Checking the presence DNA region in the DNA and DNA reverse compliment sequence.
                if sequence.includes(dna_sequence):
                    regions.append((dna_sequence, "->"))
                elif dna_reverse_complement.includes(dna_sequence):
                    regions.append((dna_sequence, "<-"))
                del dna_sequence
                del rna
        return regions
