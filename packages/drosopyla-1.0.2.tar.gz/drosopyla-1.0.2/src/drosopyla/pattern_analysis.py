# Importing all needed modules.
from .distances import hamming_distance
import matplotlib.pyplot as plt
from .sequences import DNASequence
import numpy as np
from .utils import SKEW_DELTA


def count_pattern_with_mismatch(sequence, pattern, match_delta : int) -> int:
    """
        This function counts the occurrence of a pattern in a sequence within a hamming distance threshold.
    :param sequence: DNASequence, RNASequence or Protein
        The sequence in which the pattern is searched for.
    :param pattern: DNASequence, RNASequence or Protein
        The pattern that is searched.
    :param match_delta: int
        The hamming distance threshold for matching.
    :return: int
        The number of occurrences of the pattern in a sequence within a hamming distance threshold.
    """
    count = 0
    # Iterating through all the pattern length - mers fo the sequence.
    for i in range(len(sequence) - len(pattern) + 1):
        # Checking the distance between the pattern and the sequence k-mer.
        if hamming_distance(sequence[i:i + len(pattern)], pattern) <= match_delta:
            count += 1
    return count


class Skew:
    def __init__(self, dna_sequence : DNASequence) -> None:
        """
            The constructor of the skew computation class.
        :param dna_sequence: DNASequence
            The dna sequence for which the skew should be computed.
        """
        if not isinstance(dna_sequence, DNASequence):
            raise ValueError("Sequence should be of type DNA")
        self.dna = dna_sequence
        self.skew_list = []
        self.__compute_skew()

    def __compute_skew(self) -> None:
        """
            This function computes the skew of the DNA sequence.
        :return:
        """
        # Extending the skew array one value at a time by adding values to the skew depending on nucleotides.
        # +1 if nb = G, -1 if nb = C, and no change in case of A and T.
        skew = 0
        for i in range(len(self.dna)):
            skew += SKEW_DELTA[self.dna[i].string()]
            self.skew_list.append(skew)
        self.skew_list = np.array(self.skew_list)

    def get_min_skew(self) -> tuple:
        """
            This function returns the minimal value of skew and their locations.
        :return: tuple
            The minimal value of skew, and it's location in the skew array.
        """
        # Getting the minimal value and their location.
        min_value = self.skew_list.min()
        min_indices = np.where(self.skew_list == min_value)[0]

        # Reducing neighboring min values locations to one location.
        first_occurrences = min_indices[np.insert(np.diff(min_indices) > 1, 0, True)]

        return int(min_value), first_occurrences

    def plot(self, figsize : tuple=(16, 10)) -> None:
        """
            This function makes a plot of the skew value through the sequence.
        :param figsize: tuple
            The size of the plot.
        """
        plt.figure(figsize=figsize)
        plt.plot(np.arange(len(self.dna)), self.skew_list)
        plt.xticks(range(len(self.dna)), list(self.dna.string() ), fontsize=10)
        plt.xlabel("Kmers")
        plt.ylabel("Count")
        plt.show()
