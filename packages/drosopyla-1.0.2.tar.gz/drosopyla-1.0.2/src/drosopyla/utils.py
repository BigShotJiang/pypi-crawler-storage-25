from itertools import product


NB_COMPLIMENTS = {
    "A" : "T",
    "T" : "A",
    "C" : "G",
    "G" : "C"
}

RNA2AMINO_ACIDS = {
    "UUU" : "F", "UCU" : "S", "UAU" : "Y", "UGU" : "C",
    "UUC" : "F", "UCC" : "S", "UAC" : "Y", "UGC" : "C",
    "UUA" : "L", "UCA" : "S", "UAA" : "|", "UGA" : "|",
    "UUG" : "L", "UCG" : "S", "UAG" : "|", "UGG" : "W",
    "CUU" : "L", "CCU" : "P", "CAU" : "H", "CGU" : "R",
    "CUC" : "L", "CCC" : "P", "CAC" : "H", "CGC" : "R",
    "CUA" : "L", "CCA" : "P", "CAA" : "Q", "CGA" : "R",
    "CUG" : "L", "CCG" : "P", "CAG" : "Q", "CGG" : "R",
    "AUU" : "I", "ACU" : "T", "AAU" : "N", "AGU" : "S",
    "AUC" : "I", "ACC" : "T", "AAC" : "N", "AGC" : "S",
    "AUA" : "I", "ACA" : "T", "AAA" : "K", "AGA" : "R",
    "AUG" : "M", "ACG" : "T", "AAG" : "K", "AGG" : "R",
    "GUU" : "V", "GCU" : "A", "GAU" : "D", "GGU" : "G",
    "GUC" : "V", "GCC" : "A", "GAC" : "D", "GGC" : "G",
    "GUA" : "V", "GCA" : "A", "GAA" : "E", "GGA" : "G",
    "GUG" : "V", "GCG" : "A", "GAG" : "E", "GGG" : "G"
}

SKEW_DELTA = {
    "A" : 0,
    "T" : 0,
    "G" : 1,
    "C" : -1
}

AMINO_ACIDS2RNA = {
    'K': ['AAA', 'AAG'],
    'N': ['AAC', 'AAU'],
    'T': ['ACA', 'ACC', 'ACG', 'ACU'],
    'R': ['AGA', 'AGG', 'CGA', 'CGC', 'CGG', 'CGU'],
    'S': ['AGC', 'AGU', 'UCA', 'UCC', 'UCG', 'UCU'],
    'I': ['AUA', 'AUC', 'AUU'],
    'M': ['AUG'],
    'Q': ['CAA', 'CAG'],
    'H': ['CAC', 'CAU'],
    'P': ['CCA', 'CCC', 'CCG', 'CCU'],
    'L': ['CUA', 'CUC', 'CUG', 'CUU', 'UUA', 'UUG'],
    'E': ['GAA', 'GAG'],
    'D': ['GAC', 'GAU'],
    'A': ['GCA', 'GCC', 'GCG', 'GCU'],
    'G': ['GGA', 'GGC', 'GGG', 'GGU'],
    'V': ['GUA', 'GUC', 'GUG', 'GUU'],
    '|': ['UAA', 'UAG', 'UGA'],
    'Y': ['UAC', 'UAU'],
    'C': ['UGC', 'UGU'],
    'W': ['UGG'],
    'F': ['UUC', 'UUU']
}

AMINO_ACID_MASS = {
    'G': 57,
    'A': 71,
    'S': 87,
    'P': 97,
    'V': 99,
    'T': 101,
    'C': 103,
    'I': 113,
    'L': 113,
    'N': 114,
    'D': 115,
    'K': 128,
    'Q': 128,
    'E': 129,
    'M': 131,
    'H': 137,
    'F': 147,
    'R': 156,
    'Y': 163,
    'W': 186,
}


def generate_all_kmers(k : int, sequence_type : str = "dna") -> list:
    """
        This function generates possible k-mers.
    :param k: int
        The size of the k-mers.
    :param sequence_type: str, default = "dna"
        The type of the biological sequence, DNA or RNA.
    :return: list
        The list with all types of k-mers.
    :raises:
        ValueError: If the k argument is zero or negative integer.
    """
    if k <= 0:
        raise ValueError("k must be a positive integer.")
    if sequence_type == "dna":
        alphabet = ['A', 'C', 'T', 'G']
    elif sequence_type == "rna":
        alphabet = ['A', 'C', 'U', 'G']
    elif sequence_type == "peptide":
        alphabet = list("GASPVTCILNDKQEMHFRYWOU")
    else:
        raise ValueError("No distinct sequence type was provided! Please use one of the following: dna, rna or peptide!")
    kmers = [''.join(p) for p in product(alphabet, repeat=k)]
    return kmers