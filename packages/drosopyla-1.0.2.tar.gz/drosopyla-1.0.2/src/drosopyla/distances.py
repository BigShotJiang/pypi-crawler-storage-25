# Importing all needed modules.
from .sequences import DNASequence, RNASequence, Protein


def hamming_distance(sequence1, sequence2) -> int:
    """
        This function calculates the hamming distance between two different sequences of the same type.
    :param sequence1: DNASequence, RNASequence or Protein
        The first biological sequence object.
    :param sequence2: DNASequence, RNASequence or Protein
        The second biological sequence object.
    :return: int
        The hamming distance between two sequences.
    :raises:
        ValueError: if sequences are not one of the following types: DNASequence, RNASequence, Protein
        ValueError: if sequences are not of the same length.
    """
    # Checking the data types of the sequences.
    if not isinstance(sequence1, (DNASequence, RNASequence, Protein)) or \
        not isinstance(sequence2, (DNASequence, RNASequence, Protein)):
        ValueError("Both sequences should one of DNASequence, RNASequence or Protein types and should have the same type")
    # Checking if the lengths of the sequences are equal.
    if len(sequence1) != len(sequence2):
        raise ValueError("Sequence 1 and Sequence 2 have different length")
    # Calculating the hamming distance.
    hamming_dist = 0
    for i in range(len(sequence1)):
        if sequence1[i] != sequence2[i]:
            hamming_dist += 1
    return hamming_dist


def pattern_sequence_distance(pattern, sequence) -> int:
    """
        This function computes the hamming distance between a pattern and a sequence as a minimal distance between the
        pattern and a k-mer of sequence.
    :param pattern: DNASequence, RNASequence or Protein
        The biological sequence pattern object.
    :param sequence: DNASequence, RNASequence or Protein
        The sequence object to which the pattern should be compared.
    :return: int
        The minimal distance between a pattern and a k-mer of the sequence.
    :raises:
        ValueError: if sequences are not one of the following types: DNASequence, RNASequence, Protein
    """
    # Checking the data types of the sequences.
    if not isinstance(pattern, (DNASequence, RNASequence, Protein)) or \
            not isinstance(sequence, (DNASequence, RNASequence, Protein)):
        ValueError("Both sequences should one of DNASequence, RNASequence or Protein types and should have the same type")
    # Getting the all unique k-mers of the sequence.
    kmers = set(sequence.get_kmers(len(pattern)))
    min_dist = 1_000_000
    # Finding the minimal hamming distance between the pattern and one of the k-mers of the sequence.
    for kmer in kmers:
        dist = hamming_distance(pattern.__class__(kmer), pattern)
        if dist < min_dist:
            min_dist = dist
    return min_dist


def pattern_collection_distance(pattern, sequence_collection : list) -> int:
    """
        This function calculates the distance between a patter and a list of sequences.
    :param pattern: DNASequence, RNASequence or Protein
        The biological sequence pattern object.
    :param sequence_collection: list of DNASequence, RNASequence or Protein
        A list of biological sequences objects.
    :return: int
        The sum of minimal hamming distances between the pattern and every sequence in the collection.
    """
    # Checking the data type of the pattern.
    if not isinstance(pattern, (DNASequence, RNASequence, Protein)):
        raise ValueError("The provided pattern object should be DNASequence, RNASequence or Protein type")
    # Checking the data type of the sequences in the sequence collection.
    for sequence in sequence_collection:
        if not isinstance(sequence, (DNASequence, RNASequence, Protein)):
            raise ValueError("It seems that at least one of sequence is not of the DNASequence, RNASequence or Protein type")
    # Calculating the sum of minimal hamming distances between the pattern and every sequence in the collection.
    distance_value = 0
    for sequence in sequence_collection:
        distance_value += pattern_sequence_distance(pattern, sequence)
    return distance_value
