"""Tunnel worker client implementation for the Lange tunnel service."""



from ._client import Tunnel

__all__ = ["Tunnel"]