from typing import Any

def _filter_hop_by_hop_headers(headers: Any) -> dict[str, str]:
    """
    Remove hop-by-hop headers before forwarding to the local target.

    :param headers: Request header mapping.
    :returns: Filtered header mapping.
    """
    if not isinstance(headers, dict):
        return {}

    hop_by_hop = {"connection", "keep-alive", "transfer-encoding", "upgrade"}
    return {
        str(key): str(value)
        for key, value in headers.items()
        if str(key).lower() not in hop_by_hop
    }