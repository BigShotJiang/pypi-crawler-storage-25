"""CLI commands for publishing distribution artifacts."""

from __future__ import annotations

from pathlib import Path

import click
import httpx

from ...distribution import DistributionClient


@click.group("distribution")
def distribution_group() -> None:
    """
    Group distribution-related CLI commands.

    :returns: ``None``.
    """


@distribution_group.command("publish")
@click.option("--path", "artifact_path", required=True, type=click.Path(path_type=Path), help="Artifact file to upload.")
@click.option("--version", "version_name", required=True, type=str, help="Distribution version to publish.")
@click.option(
    "--distribution-name",
    required=True,
    type=str,
    help="Distribution name in the app services distribution system.",
)
@click.option("--os", "os_name", required=True, type=str, help="Artifact operating system: windows, macos, or linux.")
def publish_distribution_command(
    artifact_path: Path,
    version_name: str,
    distribution_name: str,
    os_name: str,
) -> None:
    """
    Publish one distribution artifact to the app services distribution system.

    :param artifact_path: Artifact file path to upload.
    :param version_name: Version string associated with the artifact.
    :param distribution_name: Distribution name in the app service.
    :param os_name: Operating-system label for the uploaded artifact.
    :returns: ``None``.
    """
    try:
        client = DistributionClient(distribution_name=distribution_name)
        client.upload(path=artifact_path, version_name=version_name, os_name=os_name)
    except (ValueError, httpx.HTTPError) as error:
        raise click.ClickException(str(error)) from error

    click.echo(
        f"Published distribution '{distribution_name}' version '{version_name}' for '{os_name}'."
    )
