"""Distribution-related CLI commands for the ``lange`` package."""

from ._command import distribution_group

__all__ = ["distribution_group"]
