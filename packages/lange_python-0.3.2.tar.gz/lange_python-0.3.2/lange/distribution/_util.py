from __future__ import annotations

import platform


def detect_distribution_os() -> str:
    """
    Detect the current operating system for distribution artifact selection.

    :returns: Normalized operating-system label accepted by the app service.
    :raises ValueError: If the current platform is unsupported.
    """
    system_name = platform.system().strip().lower()

    if system_name == "windows":
        return "windows"

    if system_name == "darwin":
        return "macos"

    if system_name == "linux":
        return "linux"

    raise ValueError(f"Unsupported operating system: {platform.system()}.")


def parse_distribution_os(os_name: str) -> str:
    """
    Validate and normalize a distribution artifact operating-system label.

    :param os_name: Untrusted operating-system label.
    :returns: Normalized operating-system label accepted by the app service.
    :raises ValueError: If the operating-system label is missing or unsupported.
    """
    normalized_os_name = os_name.strip().lower()

    if not normalized_os_name:
        raise ValueError("os_name is required.")

    if normalized_os_name not in {"windows", "macos", "linux"}:
        raise ValueError("os_name must be one of: windows, macos, linux.")

    return normalized_os_name


def _compare_versions(left: str, right: str) -> int:
    """
    Compare two dotted numeric version strings.

    :param left: Left-hand version string.
    :param right: Right-hand version string.
    :returns: Positive when ``left`` is newer, negative when older, otherwise ``0``.
    """
    left_parts = _normalize_version_parts(left)
    right_parts = _normalize_version_parts(right)
    max_length = max(len(left_parts), len(right_parts))

    padded_left = left_parts + (0,) * (max_length - len(left_parts))
    padded_right = right_parts + (0,) * (max_length - len(right_parts))

    if padded_left > padded_right:
        return 1

    if padded_left < padded_right:
        return -1

    return 0


def _normalize_version_parts(version: str) -> tuple[int, ...]:
    """
    Convert a dotted numeric version string into comparable integer parts.

    :param version: Version string to normalize.
    :returns: Comparable integer tuple.
    :raises ValueError: If the version is empty or malformed.
    """
    normalized_version = version.strip()
    if not normalized_version:
        raise ValueError("Version is required.")

    parts = normalized_version.split(".")
    normalized_parts: list[int] = []

    for part in parts:
        if not part.isdigit():
            raise ValueError(f"Unsupported version format: {version}.")

        normalized_parts.append(int(part))

    return tuple(normalized_parts)
