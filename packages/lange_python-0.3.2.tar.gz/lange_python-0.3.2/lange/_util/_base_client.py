from threading import Thread
from ._key_handling import _resolve_api_key


class BaseLangeLabsClient(Thread):

    def __init__(self,
                 api_key: str | None = None,
                 daemon: bool = True,
                 host: str | None = None,
                 ) -> None:
        """
        Initialize a thread-based Lange Labs client with shared connection settings.

        :param api_key: Optional API key supplied directly or resolved from the environment.
        :param daemon: Whether the client thread should run as a daemon thread.
        :param host: Base service URL used for outbound requests.
        :raises ValueError: If ``api_key`` is unavailable or empty.
        """
        super().__init__(daemon=daemon)
        self.api_key = _resolve_api_key(api_key)
        self.host = host.rstrip("/")

    def _build_connection_headers(self) -> dict[str, str]:
        """
        Build outbound handshake headers.

        :returns: Header dictionary with bearer authorization.
        """
        return {"Authorization": f"Bearer {self.api_key}"}
