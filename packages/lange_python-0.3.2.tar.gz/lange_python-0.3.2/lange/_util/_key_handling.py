import os

def _resolve_api_key(api_key: str | None) -> str:
    """
    Resolve API key from argument or environment.

    :param api_key: Optional direct API key value.
    :returns: Sanitized non-empty API key.
    :raises ValueError: If no non-empty API key is available.
    """
    if api_key is not None and api_key.strip():
        return api_key.strip()

    env_api_key = os.getenv("LANGE_LABS_API_KEY", "")
    if env_api_key.strip():
        return env_api_key.strip()

    raise ValueError(
        "A non-empty api_key is required. "
        "Pass api_key directly or set LANGE_LABS_API_KEY."
    )
