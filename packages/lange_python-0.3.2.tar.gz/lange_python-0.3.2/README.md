# lange-python

Python helpers and clients for Lange services.

## Distribution CLI

Publish a distribution artifact to the app services distribution system:

```bash
export LANGE_LABS_API_KEY="your-api-key"
lange distribution publish \
  --path ./dist/app.dmg \
  --version 1.2.3 \
  --distribution-name desktop-app \
  --os macos
```

## Tunnel worker

```python
from lange.tunnel import Tunnel

tunnel = Tunnel(
    host="wss://tunnel.lange-labs.com",
    secret_key="your-bearer-token",
    tunnel_name="dev-edge",  # Optional but recommended when one key is linked to multiple tunnels.
    target="http://localhost:3000",
)

tunnel.start()
# ...
tunnel.stop()
```
