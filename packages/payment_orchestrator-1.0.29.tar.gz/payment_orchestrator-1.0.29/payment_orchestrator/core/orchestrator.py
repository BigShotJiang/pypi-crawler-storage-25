"""Main payment orchestration engine - Unified API.

UNIFIED API ARCHITECTURE:
========================
This orchestrator provides a single unified method for payment processing:

PRIMARY METHOD:
- process_payment(payment_data, payment_api_endpoint)
  → Handles everything: idempotency, validation, fraud detection, 
    Lambda triggering, notifications, and retry queue

For new integrations, use process_payment() which provides:
1. Automatic idempotency checking (DynamoDB)
2. Payment validation and fraud detection
3. Lambda triggering for payment processing
4. SNS notifications (success/failure)
5. SQS retry queue on failure
6. Complete transaction lifecycle management
"""

import logging
import uuid
from typing import Dict, Any, List, Optional
from datetime import datetime

from payment_orchestrator.models.payment import Payment
from payment_orchestrator.core.validator import PaymentValidator
from payment_orchestrator.core.fraud_detector import FraudDetector
from payment_orchestrator.core.processor import PaymentProcessor
from payment_orchestrator.services.encryptor import PaymentEncryptor
from payment_orchestrator.services.dynamodb_idempotency import DynamoDBIdempotencyManager
from payment_orchestrator.services.sns_notifier import SNSNotifier
from payment_orchestrator.services.queue_manager import RetryQueueManager
from payment_orchestrator.services.db_manager import TransactionStore

logger = logging.getLogger(__name__)


class PaymentOrchestrator:
    """
    Main orchestrator implementing the facade pattern.
    
    RECOMMENDED USAGE:
    ==================
    orchestrator = PaymentOrchestrator(
        sqs_queue_url="...",
        dynamodb_table="...",
        sns_topic_arn="...",
        region="us-east-1",
        idempotency_table="..."
    )
    
    result = orchestrator.process_payment(payment_data, payment_api_endpoint)
    
    This single call handles:
    - Idempotency checking
    - Validation & fraud detection
    - Lambda triggering
    - Status updates
    - Notifications
    - Retry queue
    """
    
    def __init__(self,
                 sqs_queue_url: str,
                 dynamodb_table: str,
                 sns_topic_arn: str,
                 region: str = "us-east-1",
                 idempotency_table: str = None):
        """
        Initialize the PaymentOrchestrator with all service dependencies.
        
        Args:
            sqs_queue_url: SQS queue URL for retries
            dynamodb_table: DynamoDB table name for transactions
            sns_topic_arn: SNS topic ARN for email notifications (REQUIRED)
            region: AWS region
            idempotency_table: DynamoDB table name for idempotency (optional)
        """
        self.region = region
        
        # Validate required parameters
        if not sns_topic_arn:
            raise ValueError("sns_topic_arn is required for email notifications")
        
        # Initialize all service classes
        self.validator = PaymentValidator()
        self.fraud_detector = FraudDetector()
        self.encryptor = PaymentEncryptor("none", region)
        self.queue_manager = RetryQueueManager(sqs_queue_url, region)
        self.transaction_store = TransactionStore(dynamodb_table, region)
        self.notifier = SNSNotifier(sns_topic_arn, region)
        
        logger.info(f"✅ SNS notifier initialized with topic: {sns_topic_arn}")
        
        # Initialize DynamoDB idempotency manager if table provided
        if idempotency_table:
            self.idempotency_manager = DynamoDBIdempotencyManager(idempotency_table, region)
            logger.info(f"✅ DynamoDB idempotency manager initialized with table: {idempotency_table}")
        else:
            self.idempotency_manager = None
            logger.warning("⚠️ Idempotency table not provided - idempotency checks disabled")
        
        logger.info("✅ PaymentOrchestrator initialized successfully")
    
    def process_payment(self, payment_data: dict, payment_api_endpoint: str) -> Dict[str, Any]:
        """
        Process payment following the complete orchestration flow.
        
        This is the PRIMARY method for payment processing. It handles:
        1. Idempotency check (prevents duplicate payments)
        2. Payment validation
        3. Fraud detection
        4. Data encryption
        5. Transaction storage (PENDING)
        6. Lambda API call for payment processing
        7. Status update (SUCCESS/FAILED)
        8. SNS notifications
        9. SQS retry queue (on failure)
        
        Args:
            payment_data: Payment request dictionary with keys:
                - cardholder_name: str
                - card_number: str
                - expiry_month: int
                - expiry_year: int
                - cvv: str
                - amount: int (in cents)
                - currency: str
                - email: str
            payment_api_endpoint: Lambda API endpoint URL for payment processing
            
        Returns:
            Dictionary with keys:
                - success: bool
                - transaction_id: str
                - status: str (SUCCESS/FAILED/ERROR)
                - message: str
        """
        transaction_id = str(uuid.uuid4())
        logger.info(f"🔄 Starting payment processing: {transaction_id}")
        
        try:
            # Step 1: Idempotency check
            idempotency_key = None
            if self.idempotency_manager:
                idempotency_key = self.idempotency_manager.generate_idempotency_key(payment_data)
                logger.info(f"🔑 Idempotency key: {idempotency_key}")
                
                # Check if this payment was already processed
                existing_txn_id = self.idempotency_manager.check_and_set(idempotency_key, transaction_id)
                
                if existing_txn_id:
                    # Duplicate payment detected - get status from transactions table
                    logger.info(f"♻️ Idempotent request detected: {existing_txn_id}")
                    
                    # Query transactions table for status
                    existing_transaction = self.transaction_store.get_transaction(existing_txn_id)
                    
                    if existing_transaction:
                        return {
                            "success": existing_transaction["status"] == "SUCCESS",
                            "transaction_id": existing_txn_id,
                            "status": existing_transaction["status"],
                            "message": f"Payment already processed (idempotent) - Status: {existing_transaction['status']}"
                        }
            
            # Step 2: Validate payment
            logger.info("✓ Validating payment data...")
            is_valid, error = self.validator.validate(payment_data)
            if not is_valid:
                logger.error(f"❌ Validation failed: {error}")
                return self._create_error_response(transaction_id, error)
            
            # Step 3: Fraud check
            logger.info("✓ Running fraud detection...")
            is_fraud, fraud_reason = self.fraud_detector.check_fraud(payment_data)
            if is_fraud:
                logger.error(f"🚨 Fraud detected: {fraud_reason}")
                self.notifier.notify_fraud_alert(
                    transaction_id,
                    payment_data.get("amount", 0),
                    payment_data.get("currency", "USD"),
                    payment_data.get("cardholder_name", "Customer"),
                    payment_data.get("email", ""),
                    fraud_reason
                )
                return self._create_error_response(transaction_id, f"Fraud detected: {fraud_reason}")
            
            # Step 4: Encrypt sensitive data
            logger.info("🔒 Encrypting sensitive data...")
            encrypted_card = self.encryptor.encrypt(payment_data["card_number"])
            encrypted_cvv = self.encryptor.encrypt(payment_data["cvv"])
            
            if not encrypted_card or not encrypted_cvv:
                error = "Encryption failed"
                logger.error(f"❌ {error}")
                return self._create_error_response(transaction_id, error)
            
            # Create payment object
            payment = Payment(
                cardholder_name=payment_data["cardholder_name"],
                card_number=payment_data["card_number"],
                expiry_month=payment_data["expiry_month"],
                expiry_year=payment_data["expiry_year"],
                cvv=payment_data["cvv"],
                amount=payment_data["amount"],
                currency=payment_data["currency"],
                email=payment_data["email"],
                transaction_id=transaction_id,
                timestamp=datetime.utcnow().isoformat()
            )
            
            # Step 5: Save transaction as PENDING
            logger.info("💾 Saving transaction to DynamoDB...")
            transaction_record = {
                "transaction_id": transaction_id,
                "status": "PENDING",
                "amount": payment.amount,
                "currency": payment.currency,
                "cardholder_name": payment.cardholder_name,
                "masked_card": payment.get_masked_card(),
                "email": payment.email,
                "timestamp": payment.timestamp,
                "encrypted_card": encrypted_card,
                "encrypted_cvv": encrypted_cvv,
                "retry_count": 0
            }
            
            if not self.transaction_store.save_transaction(transaction_record):
                error = "Failed to save transaction"
                logger.error(f"❌ {error}")
                return self._create_error_response(transaction_id, error)
            
            # Step 6: Trigger Payment Lambda
            logger.info(f"🚀 Triggering payment Lambda: {payment_api_endpoint}")
            processor = PaymentProcessor(payment_api_endpoint)
            success, message = processor.process(
                payment.card_number,
                payment.cvv,
                payment.amount,
                payment.currency,
                payment.cardholder_name,
                payment.expiry_month,
                payment.expiry_year,
                transaction_id
            )
            
            # Step 7 & 8: Update status and send notifications
            if success:
                logger.info(f"✅ Payment succeeded: {transaction_id}")
                
                # Update DynamoDB transactions table
                self.transaction_store.update_transaction_status(transaction_id, "SUCCESS")
                
                # Send success notification
                self.notifier.notify_payment_success(
                    transaction_id, payment.amount, payment.currency,
                    payment.cardholder_name, payment.email
                )
                
                return {
                    "success": True,
                    "transaction_id": transaction_id,
                    "status": "SUCCESS",
                    "message": message
                }
            else:
                logger.warning(f"❌ Payment failed: {transaction_id} - {message}")
                
                # Update DynamoDB transactions table
                self.transaction_store.update_transaction_status(transaction_id, "FAILED", message)
                
                # Step 9: Queue for retry
                logger.info("📤 Sending to retry queue...")
                # Add transaction_id to payment_data for retry tracking
                retry_payment_data = payment_data.copy()
                retry_payment_data["transaction_id"] = transaction_id
                self.queue_manager.send_retry_message(retry_payment_data, retry_count=0)
                
                # Send failure notification
                self.notifier.notify_payment_failure(
                    transaction_id, payment.amount, payment.currency,
                    payment.cardholder_name, payment.email, message
                )
                
                return {
                    "success": False,
                    "transaction_id": transaction_id,
                    "status": "FAILED",
                    "message": message
                }
        
        except Exception as e:
            error = f"Unexpected error during payment processing: {str(e)}"
            logger.error(f"❌ {error}")
            
            return self._create_error_response(transaction_id, error)
    
    def retry_failed_payment(self, payment_data: dict, retry_count: int, payment_api_endpoint: str) -> Dict[str, Any]:
        """
        Retry a failed payment from the SQS queue.
        
        This method is called by the Retry Lambda when processing messages from SQS.
        
        Args:
            payment_data: Original payment data
            retry_count: Current retry attempt number
            payment_api_endpoint: Lambda API endpoint for payment processing
            
        Returns:
            Dictionary with retry result
        """
        logger.info(f"🔄 Retrying payment, attempt {retry_count + 1}")
        
        # Maximum 3 retries
        if retry_count >= 3:
            logger.error("❌ Maximum retry attempts reached")
            return {
                "success": False,
                "message": "Maximum retry attempts exceeded"
            }
        
        # Process payment again
        result = self.process_payment(payment_data, payment_api_endpoint)
        
        # If still failed and under retry limit, send back to queue
        if not result.get("success") and retry_count < 2:
            logger.info(f"📤 Sending back to retry queue (attempt {retry_count + 2})")
            self.queue_manager.send_retry_message(payment_data, retry_count + 1)
        
        return result
    
    def get_transaction_history(self, email: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Retrieve transaction history from DynamoDB.
        
        Args:
            email: Optional email filter
            
        Returns:
            List of transaction dictionaries
        """
        if email:
            transactions = self.transaction_store.query_transactions_by_email(email)
        else:
            transactions = self.transaction_store.get_all_transactions()
        
        logger.info(f"📊 Retrieved {len(transactions)} transactions")
        return transactions
    
    def _create_error_response(self, transaction_id: str, error: str) -> Dict[str, Any]:
        """
        Create standardized error response.
        
        Args:
            transaction_id: Transaction ID
            error: Error message
            
        Returns:
            Error response dictionary
        """
        return {
            "success": False,
            "transaction_id": transaction_id,
            "status": "FAILED",
            "message": error
        }
