"""Payment processor that invokes Lambda function for actual payment processing."""

import logging
import boto3
import json
from typing import Tuple

logger = logging.getLogger(__name__)


class PaymentProcessor:
    """
    Payment processor that delegates actual payment processing to a Lambda function.
    
    This approach provides:
    - Better security isolation
    - Centralized payment logic
    - Easy scaling and monitoring
    - Direct Lambda invocation (no API Gateway needed)
    """
    
    def __init__(self, lambda_function_name: str, region: str = "us-east-1"):
        """
        Initialize the PaymentProcessor with Lambda function name.
        
        Args:
            lambda_function_name: Name or ARN of the bank API Lambda function
            region: AWS region where Lambda is deployed
        """
        self.lambda_function_name = lambda_function_name
        self.region = region
        self.lambda_client = boto3.client('lambda', region_name=region)
        logger.info(f"PaymentProcessor initialized with Lambda: {lambda_function_name} in {region}")
    
    def process(self, card_number: str, cvv: str, amount: int, 
               currency: str, cardholder_name: str, exp_month: int, exp_year: int,
               transaction_id: str) -> Tuple[bool, str]:
        """
        Process payment by invoking Lambda function directly.
        
        Args:
            card_number: Decrypted card number
            cvv: Decrypted CVV
            amount: Payment amount in cents
            currency: Currency code (e.g., 'USD')
            cardholder_name: Name on card
            exp_month: Card expiry month
            exp_year: Card expiry year
            transaction_id: Unique transaction ID for reference
            
        Returns:
            Tuple of (success, message)
        """
        logger.info(f"Processing payment via Lambda: {amount} {currency} for {cardholder_name}")
        
        try:
            # Prepare payment data for Lambda
            payment_data = {
                "transaction_id": transaction_id,
                "card_number": card_number,
                "cvv": cvv,
                "exp_month": exp_month,
                "exp_year": exp_year,
                "amount": amount,
                "currency": currency.upper(),
                "cardholder_name": cardholder_name
            }
            
            logger.info(f"Invoking Lambda: {self.lambda_function_name}")
            
            # Invoke Lambda function synchronously
            response = self.lambda_client.invoke(
                FunctionName=self.lambda_function_name,
                InvocationType='RequestResponse',  # Synchronous invocation
                Payload=json.dumps(payment_data)
            )
            
            # Read Lambda response
            response_payload = response['Payload'].read()
            lambda_result = json.loads(response_payload)
            
            # Check for Lambda execution errors
            if response.get('FunctionError'):
                error_msg = f"Lambda execution error: {lambda_result.get('errorMessage', 'Unknown error')}"
                logger.error(error_msg)
                return False, error_msg
            
            # Parse Lambda response body
            status_code = lambda_result.get('statusCode', 500)
            body = lambda_result.get('body', '{}')
            
            # Handle string body (Lambda returns JSON string)
            if isinstance(body, str):
                body = json.loads(body)
            
            logger.info(f"Lambda response - Status: {status_code}, Body: {body}")
            
            # Handle successful response (200)
            if status_code == 200:
                success = body.get('success', False)
                message = body.get('message', 'Unknown response')
                
                if success:
                    auth_code = body.get('authorization_code', '')
                    success_msg = f"{message} (Auth: {auth_code})" if auth_code else message
                    logger.info(f"✅ Payment succeeded: {success_msg}")
                    return True, success_msg
                else:
                    error_code = body.get('error_code', 'UNKNOWN')
                    error_msg = f"{message} (Code: {error_code})"
                    logger.warning(f"❌ Payment declined: {error_msg}")
                    return False, error_msg
            
            # Handle client errors (400)
            elif status_code == 400:
                error_msg = body.get('message', 'Invalid payment data')
                logger.error(f"❌ Validation error: {error_msg}")
                return False, error_msg
            
            # Handle server errors (500, 503, 504)
            elif status_code >= 500:
                error_msg = body.get('message', 'Payment service error')
                error_code = body.get('error_code', 'SERVER_ERROR')
                logger.error(f"❌ Server error: {error_msg} (Code: {error_code})")
                return False, f"{error_msg} - Please retry"
            
            else:
                # Other status codes
                error_msg = body.get('message', f'Unexpected status code: {status_code}')
                logger.error(f"❌ Unexpected response: {error_msg}")
                return False, error_msg
        
        except json.JSONDecodeError as e:
            error_msg = f"Failed to parse Lambda response: {str(e)}"
            logger.error(f"❌ JSON error: {error_msg}")
            return False, "Payment processing error - invalid response format"
        
        except self.lambda_client.exceptions.ResourceNotFoundException:
            error_msg = f"Lambda function not found: {self.lambda_function_name}"
            logger.error(f"❌ Lambda not found: {error_msg}")
            return False, "Payment service unavailable - configuration error"
        
        except self.lambda_client.exceptions.TooManyRequestsException:
            error_msg = "Lambda throttled - too many requests"
            logger.warning(f"⚠️ Throttled: {error_msg}")
            return False, "Payment service busy - please retry"
        
        except Exception as e:
            error_msg = f"Unexpected error invoking Lambda: {str(e)}"
            logger.error(f"❌ Unexpected error: {error_msg}")
            import traceback
            logger.error(traceback.format_exc())
            return False, "Payment processing error - please retry"