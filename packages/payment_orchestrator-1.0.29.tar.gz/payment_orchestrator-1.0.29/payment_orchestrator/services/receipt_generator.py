"""Receipt generator service for payment transactions - PDF version."""

import boto3
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from botocore.exceptions import ClientError
from io import BytesIO

# PDF generation
try:
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.pdfgen import canvas
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False
    logging.warning("reportlab not available - PDF generation disabled")

logger = logging.getLogger(__name__)


class ReceiptGenerator:
    """
    Generates PDF receipts for payment transactions and uploads to S3.
    """
    
    def __init__(self, s3_bucket: str, region: str = "us-east-1"):
        """
        Initialize receipt generator.
        
        Args:
            s3_bucket: S3 bucket name for storing receipts
            region: AWS region
        """
        self.s3_bucket = s3_bucket
        self.region = region
        self.s3_client = boto3.client('s3', region_name=region)
        logger.info(f"ReceiptGenerator initialized with bucket: {s3_bucket}")
    
    def generate_and_upload_receipt(
        self,
        transaction_id: str,
        cardholder_name: str,
        email: str,
        amount: int,
        currency: str,
        card_last4: str,
        timestamp: Optional[str] = None
    ) -> Optional[str]:
        """
        Generate PDF receipt and upload to S3.
        
        Args:
            transaction_id: Transaction ID
            cardholder_name: Customer name
            email: Customer email
            amount: Payment amount in cents
            currency: Currency code
            card_last4: Last 4 digits of card
            timestamp: Transaction timestamp (ISO format)
            
        Returns:
            S3 URL of the receipt, or None if failed
        """
        try:
            if not PDF_AVAILABLE:
                logger.error("reportlab not installed - cannot generate PDF")
                return None
            
            # Generate receipt PDF
            pdf_content = self._generate_receipt_pdf(
                transaction_id=transaction_id,
                cardholder_name=cardholder_name,
                email=email,
                amount=amount,
                currency=currency,
                card_last4=card_last4,
                timestamp=timestamp or datetime.utcnow().isoformat()
            )
            
            # Upload to S3
            receipt_url = self._upload_to_s3(transaction_id, pdf_content)
            
            if receipt_url:
                logger.info(f"✅ Receipt generated and uploaded: {receipt_url}")
                return receipt_url
            else:
                logger.error(f"❌ Failed to upload receipt for: {transaction_id}")
                return None
                
        except Exception as e:
            logger.error(f"❌ Error generating receipt: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return None
    
    def _generate_receipt_pdf(
        self,
        transaction_id: str,
        cardholder_name: str,
        email: str,
        amount: int,
        currency: str,
        card_last4: str,
        timestamp: str
    ) -> bytes:
        """Generate PDF receipt content."""
        
        buffer = BytesIO()
        
        # Create PDF
        pdf = canvas.Canvas(buffer, pagesize=letter)
        width, height = letter
        
        # Colors
        primary_color = colors.HexColor('#667eea')
        success_color = colors.HexColor('#28a745')
        text_color = colors.HexColor('#333333')
        gray_color = colors.HexColor('#666666')
        
        # Format data
        amount_formatted = amount / 100
        try:
            date_formatted = datetime.fromisoformat(timestamp.replace('Z', '+00:00')).strftime('%B %d, %Y at %I:%M %p UTC')
        except:
            date_formatted = datetime.utcnow().strftime('%B %d, %Y at %I:%M %p UTC')
        
        # Header - Success Banner
        pdf.setFillColor(primary_color)
        pdf.rect(0, height - 120, width, 120, fill=True, stroke=False)
        
        # Checkmark
        pdf.setFillColor(colors.white)
        pdf.setFont("Helvetica-Bold", 48)
        pdf.drawCentredString(width/2, height - 80, "✓")
        
        # Title
        pdf.setFont("Helvetica-Bold", 24)
        pdf.drawCentredString(width/2, height - 110, "Payment Successful")
        
        # Status Badge
        pdf.setFillColor(success_color)
        pdf.roundRect(width/2 - 30, height - 140, 60, 20, 10, fill=True, stroke=False)
        pdf.setFillColor(colors.white)
        pdf.setFont("Helvetica-Bold", 10)
        pdf.drawCentredString(width/2, height - 135, "PAID")
        
        # Content starts here
        y_position = height - 180
        
        # Transaction Details Section
        pdf.setFillColor(text_color)
        pdf.setFont("Helvetica-Bold", 12)
        pdf.drawString(50, y_position, "TRANSACTION DETAILS")
        y_position -= 25
        
        # Transaction ID
        pdf.setFont("Helvetica", 10)
        pdf.setFillColor(gray_color)
        pdf.drawString(50, y_position, "Transaction ID")
        pdf.setFillColor(text_color)
        pdf.setFont("Courier", 9)
        pdf.drawString(200, y_position, transaction_id)
        y_position -= 20
        
        # Date & Time
        pdf.setFont("Helvetica", 10)
        pdf.setFillColor(gray_color)
        pdf.drawString(50, y_position, "Date & Time")
        pdf.setFillColor(text_color)
        pdf.drawString(200, y_position, date_formatted)
        y_position -= 20
        
        # Status
        pdf.setFillColor(gray_color)
        pdf.drawString(50, y_position, "Status")
        pdf.setFillColor(success_color)
        pdf.setFont("Helvetica-Bold", 10)
        pdf.drawString(200, y_position, "SUCCESS")
        y_position -= 40
        
        # Customer Information Section
        pdf.setFillColor(text_color)
        pdf.setFont("Helvetica-Bold", 12)
        pdf.drawString(50, y_position, "CUSTOMER INFORMATION")
        y_position -= 25
        
        # Name
        pdf.setFont("Helvetica", 10)
        pdf.setFillColor(gray_color)
        pdf.drawString(50, y_position, "Name")
        pdf.setFillColor(text_color)
        pdf.drawString(200, y_position, cardholder_name)
        y_position -= 20
        
        # Email
        pdf.setFillColor(gray_color)
        pdf.drawString(50, y_position, "Email")
        pdf.setFillColor(text_color)
        pdf.drawString(200, y_position, email)
        y_position -= 40
        
        # Payment Method Section
        pdf.setFillColor(text_color)
        pdf.setFont("Helvetica-Bold", 12)
        pdf.drawString(50, y_position, "PAYMENT METHOD")
        y_position -= 25
        
        # Card
        pdf.setFont("Helvetica", 10)
        pdf.setFillColor(gray_color)
        pdf.drawString(50, y_position, "Card")
        pdf.setFillColor(text_color)
        pdf.drawString(200, y_position, f"•••• •••• •••• {card_last4}")
        y_position -= 40
        
        # Amount Section - Highlighted Box
        pdf.setFillColor(colors.HexColor('#f8f9fa'))
        pdf.roundRect(40, y_position - 40, width - 80, 60, 10, fill=True, stroke=False)
        
        pdf.setFillColor(gray_color)
        pdf.setFont("Helvetica", 10)
        pdf.drawString(50, y_position - 15, "Amount Paid")
        
        pdf.setFillColor(primary_color)
        pdf.setFont("Helvetica-Bold", 24)
        pdf.drawString(50, y_position - 35, f"{amount_formatted:.2f} {currency.upper()}")
        
        y_position -= 80
        
        # Footer
        pdf.setFillColor(gray_color)
        pdf.setFont("Helvetica", 9)
        pdf.drawCentredString(width/2, 80, "Thank you for your payment!")
        pdf.drawCentredString(width/2, 65, "This is an automatically generated receipt.")
        pdf.drawCentredString(width/2, 50, "If you have any questions, please contact our support team.")
        
        # Save PDF
        pdf.save()
        
        # Get PDF bytes
        pdf_bytes = buffer.getvalue()
        buffer.close()
        
        return pdf_bytes
    
    def _upload_to_s3(self, transaction_id: str, pdf_content: bytes) -> Optional[str]:
        """
        Upload receipt PDF to S3.
        
        Args:
            transaction_id: Transaction ID
            pdf_content: PDF content as bytes
            
        Returns:
            S3 URL or None if failed
        """
        try:
            # Generate S3 key
            timestamp = datetime.utcnow().strftime('%Y/%m/%d')
            s3_key = f"receipts/{timestamp}/{transaction_id}.pdf"
            
            # Upload to S3
            self.s3_client.put_object(
                Bucket=self.s3_bucket,
                Key=s3_key,
                Body=pdf_content,
                ContentType='application/pdf',
                ContentDisposition=f'inline; filename="{transaction_id}.pdf"',
                CacheControl='max-age=31536000',  # 1 year cache
                Metadata={
                    'transaction_id': transaction_id,
                    'generated_at': datetime.utcnow().isoformat()
                }
            )
            
            # Generate presigned URL (valid for 7 days)
            receipt_url = self.s3_client.generate_presigned_url(
                'get_object',
                Params={
                    'Bucket': self.s3_bucket,
                    'Key': s3_key
                },
                ExpiresIn=604800  # 7 days
            )
            
            logger.info(f"✅ Receipt uploaded to S3: {s3_key}")
            return receipt_url
            
        except ClientError as e:
            logger.error(f"❌ S3 upload failed: {e}")
            return None
        except Exception as e:
            logger.error(f"❌ Unexpected error uploading to S3: {e}")
            return None
    
    def get_receipt_url(self, transaction_id: str) -> Optional[str]:
        """
        Get presigned URL for existing receipt.
        
        Args:
            transaction_id: Transaction ID
            
        Returns:
            Presigned URL or None if not found
        """
        try:
            # Try to find receipt in S3
            # Search in last 30 days
            for days_ago in range(30):
                date = datetime.utcnow() - timedelta(days=days_ago)
                date_str = date.strftime('%Y/%m/%d')
                s3_key = f"receipts/{date_str}/{transaction_id}.pdf"
                
                try:
                    # Check if object exists
                    self.s3_client.head_object(Bucket=self.s3_bucket, Key=s3_key)
                    
                    # Generate presigned URL
                    receipt_url = self.s3_client.generate_presigned_url(
                        'get_object',
                        Params={
                            'Bucket': self.s3_bucket,
                            'Key': s3_key
                        },
                        ExpiresIn=604800  # 7 days
                    )
                    
                    return receipt_url
                except ClientError:
                    continue
            
            logger.warning(f"Receipt not found for transaction: {transaction_id}")
            return None
            
        except Exception as e:
            logger.error(f"Error retrieving receipt URL: {e}")
            return None
