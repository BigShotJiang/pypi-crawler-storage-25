# pipecat-ten-vad
TEN VAD implementation with pipecat
# pipecat-ten-vad

[![PyPI version](https://img.shields.io/pypi/v/pipecat-ten-vad)](https://pypi.python.org/pypi/pipecat-ten-vad)
[![Python versions](https://img.shields.io/pypi/pyversions/pipecat-ten-vad)](https://pypi.python.org/pypi/pipecat-ten-vad)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

[TEN VAD](https://github.com/TEN-framework/ten-vad) integration for [Pipecat](https://github.com/pipecat-ai/pipecat) — a low-latency, high-performance voice activity detector for real-time voice agents.

> **Community Integration** — This package is maintained by the community, not the Pipecat core team.
> See the [Pipecat community integrations](https://docs.pipecat.ai/server/services/community-integrations) page for more.

---

## Why TEN VAD?

Most Pipecat pipelines use Silero VAD by default. TEN VAD is worth considering if you need:

- **Lower latency** — detects speech-to-silence transitions faster, reducing end-of-turn delay in voice agents
- **Better short-silence handling** — correctly identifies brief pauses between words that Silero VAD can miss
- **Lower compute** — smaller model with a lower real-time factor (RTF) across tested platforms

---

## Pipecat Compatibility

Tested with **Pipecat v0.0.106**.

Check the [Pipecat changelog](https://github.com/pipecat-ai/pipecat/blob/main/CHANGELOG.md) when upgrading.

---

## Installation

### Step 1 — Install TEN VAD

TEN VAD is not yet available on PyPI. Install it directly from GitHub:

```bash
pip install git+https://github.com/TEN-framework/ten-vad.git
```

### Step 2 — Install pipecat-ten-vad

```bash
pip install pipecat-ten-vad
```

### Step 3 — Install Pipecat with your required extras

```bash
pip install "pipecat-ai[daily,deepgram,openai,cartesia]"
```

---

## Quick Start

```python
from pipecat.audio.vad.vad_analyzer import VADParams
from pipecat.transports.services.daily import DailyParams, DailyTransport
from pipecat_ten_vad import TenVadAnalyzer

transport = DailyTransport(
    room_url,
    token,
    "My Bot",
    DailyParams(
        audio_in_enabled=True,
        audio_out_enabled=True,
        vad_enabled=True,
        vad_analyzer=TenVadAnalyzer(
            sample_rate=16000,
            threshold=0.6,
            params=VADParams(stop_secs=0.3),
        ),
        vad_audio_passthrough=True,
    ),
)
```

---

## Configuration

### `TenVadAnalyzer` parameters

| Parameter | Type | Default | Description |
|---|---|---|---|
| `sample_rate` | `int` | `None` | Audio sample rate in Hz. **Must be 16000** if provided. |
| `threshold` | `float` | `0.6` | Detection threshold (0.0–1.0). Higher = requires stronger voice signal to trigger. |
| `params` | `VADParams` | `None` | Pipecat VAD smoothing params (e.g. `stop_secs`). |

### `VADParams` — key fields

| Parameter | Default | Description |
|---|---|---|
| `stop_secs` | `0.3` | Seconds of silence before end-of-turn is triggered. Lower = more responsive, higher = fewer false cuts. |

---

## Running the Example

```bash
# Clone the repo
git clone https://github.com/rahulsolanki001/pipecat-ten-vad.git
cd pipecat-ten-vad

# Install dependencies
pip install git+https://github.com/TEN-framework/ten-vad.git
pip install "pipecat-ten-vad[examples]"

# Set up environment
cp .env.example .env
# Edit .env with your API keys

# Run
python examples/foundational/ten_vad_basic.py
```

---

## Requirements

- Python >= 3.10, < 3.13
- pipecat-ai >= 0.0.106
- numpy >= 1.24
- TEN VAD (installed from GitHub — see above)

**Supported platforms:** Linux x64, macOS (arm64 + x64), Windows x64

---

## Contributing

Issues and PRs are welcome. When reporting a bug, please include:
- Your Python version
- Your pipecat-ai version (`pip show pipecat-ai`)
- A minimal reproduction script

---

## License

MIT — see [LICENSE](LICENSE) for details.

TEN VAD itself is licensed under Apache 2.0 with additional conditions — see the [TEN VAD license](https://github.com/TEN-framework/ten-vad/blob/main/LICENSE).

---

## Acknowledgements

- [Pipecat](https://github.com/pipecat-ai/pipecat) by Daily
- [TEN VAD](https://github.com/TEN-framework/ten-vad) by the TEN Framework team