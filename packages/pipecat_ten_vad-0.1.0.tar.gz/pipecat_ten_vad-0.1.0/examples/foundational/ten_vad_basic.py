"""Basic voice agent example using TEN VAD with Pipecat.

This example demonstrates a complete voice pipeline using TEN VAD for
voice activity detection, Deepgram for speech-to-text, OpenAI for the
LLM, and Cartesia for text-to-speech.

Requirements:
    pip install pipecat-ai[daily,deepgram,openai,cartesia]
    pip install git+https://github.com/TEN-framework/ten-vad.git
    pip install pipecat-ten-vad

Usage:
    Copy .env.example to .env and fill in your API keys, then run:
        python ten_vad_basic.py
"""

import asyncio
import os

from dotenv import load_dotenv
from loguru import logger

from pipecat.audio.vad.vad_analyzer import VADParams
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.pipeline.task import PipelineParams, PipelineTask
from pipecat.processors.aggregators.openai_llm_context import OpenAILLMContext
from pipecat.services.cartesia.tts import CartesiaTTSService
from pipecat.services.deepgram.stt import DeepgramSTTService
from pipecat.services.openai.llm import OpenAILLMService
from pipecat.transports.services.daily import DailyParams, DailyTransport

from pipecat_ten_vad import TenVadAnalyzer

load_dotenv()


async def main():
    transport = DailyTransport(
        os.getenv("DAILY_ROOM_URL"),
        os.getenv("DAILY_TOKEN"),
        "TEN VAD Bot",
        DailyParams(
            audio_in_enabled=True,
            audio_out_enabled=True,
            vad_enabled=True,
            vad_analyzer=TenVadAnalyzer(
                sample_rate=16000,
                threshold=0.6,
                params=VADParams(
                    stop_secs=0.3,  # seconds of silence before end-of-turn
                ),
            ),
            vad_audio_passthrough=True,
        ),
    )

    stt = DeepgramSTTService(api_key=os.getenv("DEEPGRAM_API_KEY"))

    llm = OpenAILLMService(
        api_key=os.getenv("OPENAI_API_KEY"),
        model="gpt-4o-mini",
    )

    tts = CartesiaTTSService(
        api_key=os.getenv("CARTESIA_API_KEY"),
        voice_id=os.getenv("CARTESIA_VOICE_ID", "71a7ad14-091d-4441-9a1e-4e1c48c89f41"),
    )

    messages = [
        {
            "role": "system",
            "content": (
                "You are a helpful voice assistant. "
                "Keep your responses concise and conversational — "
                "ideally one or two sentences. "
                "Avoid markdown, bullet points, or lists."
            ),
        }
    ]

    context = OpenAILLMContext(messages)
    context_aggregator = llm.create_context_aggregator(context)

    pipeline = Pipeline(
        [
            transport.input(),          # receives audio from the user
            stt,                        # transcribes speech to text
            context_aggregator.user(),  # collects user turn
            llm,                        # generates a response
            tts,                        # synthesizes speech
            transport.output(),         # sends audio to the user
            context_aggregator.assistant(),  # stores bot turn
        ]
    )

    task = PipelineTask(
        pipeline,
        params=PipelineParams(allow_interruptions=True),
    )

    @transport.event_handler("on_first_participant_joined")
    async def on_first_participant_joined(transport, participant):
        logger.info(f"Participant joined: {participant['id']}")
        await transport.capture_participant_transcription(participant["id"])
        await task.queue_frames([context_aggregator.user().get_context_frame()])

    @transport.event_handler("on_participant_left")
    async def on_participant_left(transport, participant, reason):
        logger.info(f"Participant left: {participant['id']}")
        await task.cancel()

    runner = PipelineRunner()
    await runner.run(task)


if __name__ == "__main__":
    asyncio.run(main())