"""Environment safety module.

Strips dangerous environment variables before any Claude Code invocation
to guarantee zero API credit usage (Max subscription only).

Non-negotiable constraint #1: no API keys must reach the Claude CLI.
Reference: ITAL-IA/kb/run-deep-research.py build_agent_env().
"""

import os
import sys

DANGEROUS_VARS: tuple[str, ...] = (
    "ANTHROPIC_API_KEY",
    "ANTHROPIC_AUTH_TOKEN",
    "ANTHROPIC_BEDROCK_API_KEY",
    "ANTHROPIC_VERTEX_PROJECT_ID",
    "CLAUDE_CODE_USE_BEDROCK",
    "CLAUDE_CODE_USE_VERTEX",
)


def strip_dangerous_env() -> None:
    """Remove every dangerous variable from the current process environment."""
    for var in DANGEROUS_VARS:
        os.environ.pop(var, None)


def build_agent_env() -> dict[str, str]:
    """Return a sanitized copy of the environment suitable for subprocess.run(env=...).

    The returned dict contains every variable except those in DANGEROUS_VARS.
    The calling process's os.environ is not mutated.
    """
    return {k: v for k, v in os.environ.items() if k not in DANGEROUS_VARS}


def assert_safe_environment() -> None:
    """Strip dangerous env vars from the current process, warning about each.

    The process environment is mutated in place so every downstream SDK and
    subprocess call inherits a clean environment — matching the pattern from
    ITAL-IA/kb/run-deep-research.py build_agent_env(). The user does not need
    to unset these variables in their shell.
    """
    offenders = [var for var in DANGEROUS_VARS if var in os.environ]
    if not offenders:
        return

    listed = ", ".join(offenders)
    print(
        f"Using Max subscription (ignoring {listed} for this process).",
        file=sys.stderr,
    )
    strip_dangerous_env()
