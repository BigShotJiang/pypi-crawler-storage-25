
## Data Sources
<!-- Market data providers, APIs, file formats -->

## Portfolio Models
<!-- Mean-Variance, Black-Litterman, Risk Parity, etc. -->

## Risk Measures
<!-- VaR, CVaR, Sharpe, Sortino, max drawdown, etc. -->
