
## API Endpoints
<!-- List the REST endpoints: method, path, description -->
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/v1/... | ... |

## Database Models
<!-- List the main entities and their relationships -->

## Authentication
<!-- JWT / OAuth2 / API key / none -->
