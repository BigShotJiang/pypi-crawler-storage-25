
## Modules
<!-- List the main NestJS modules -->

## Authentication and Guards
<!-- Passport / JWT / roles and permissions -->

## Database
<!-- Prisma / TypeORM, main entities -->
