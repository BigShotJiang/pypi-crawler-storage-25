"""Template files for `code-generator init`."""
