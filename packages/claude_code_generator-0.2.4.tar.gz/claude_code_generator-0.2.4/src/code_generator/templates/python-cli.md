
## CLI Commands
<!-- List the commands and their arguments/flags -->

## Configuration
<!-- Config files, environment variables, defaults -->

## Output format
<!-- Text, JSON, rich tables, etc. -->
