
## API Endpoints
<!-- List the REST endpoints: method, path, description -->
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/v1/... | ... |

## Database Models
<!-- List the main entities and their relationships -->

## Authentication
<!-- JWT / OAuth2 / API key / none -->

## Pages and Routing
<!-- List the main routes -->
| Path | Component | Description |
|------|-----------|-------------|
| / | HomePage | ... |

## State and Data
<!-- How to manage state: signals, ngrx, service-based -->

## Design System
<!-- Tailwind / Material / custom, color palette, typography -->
