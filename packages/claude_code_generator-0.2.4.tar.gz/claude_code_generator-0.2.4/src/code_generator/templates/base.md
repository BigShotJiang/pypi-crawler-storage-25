# Project Name

## Description
<!-- Describe the project in 2-3 sentences: what it does, for whom, why -->

## Tech Stack
<!-- The tool uses this information to select the right agents -->
- **Language**: [Python / TypeScript / ...]
- **Framework**: [FastAPI / Angular / NestJS / ...]
- **Database**: [PostgreSQL / Supabase / MongoDB / none]
- **Deploy**: [Fly.io / Vercel / Docker / local]
- **Tests**: [pytest / vitest / jest / ...]

## Features
<!-- List the features. Each entry becomes a GitHub Issue -->
1. ...
2. ...
3. ...

## Non-functional Requirements
<!-- Performance, security, scalability, accessibility -->
- ...

## Project Structure
<!-- Optional: folder structure preferences -->

## Additional Notes
<!-- Particular constraints, external integrations, third-party APIs -->
