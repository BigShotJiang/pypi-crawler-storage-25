
## Pages and Routing
<!-- List the main routes -->
| Path | Component | Description |
|------|-----------|-------------|
| / | HomePage | ... |

## State and Data
<!-- How to manage state: signals, ngrx, service-based -->

## Design System
<!-- Tailwind / Material / custom, color palette, typography -->
