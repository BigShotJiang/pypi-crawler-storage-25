"""Runner protocol — Dependency Inversion boundary for all phase modules.

Defines ``RunnerProtocol`` so that orchestrator phases and the cycle loop
depend on an abstraction rather than on the concrete ``sdk_runner`` or
``subprocess_runner`` modules typed as ``Any``.

Usage::

    from code_generator.runner.protocol import RunnerProtocol

    async def run_phase(runner: RunnerProtocol, ...) -> None:
        result = await runner.run(prompt, options, logger=logger, state_path=path)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    import logging
    from pathlib import Path
    from typing import Any

    from code_generator.runner.types import RunResult


class RunnerProtocol(Protocol):
    """Contract that every runner module must satisfy.

    Both ``sdk_runner`` and ``subprocess_runner`` expose exactly this
    interface as module-level async functions.  Using a structural Protocol
    without ``@runtime_checkable`` means zero runtime overhead — conformance
    is verified only by the type checker and by dedicated tests.
    """

    async def run(
        self,
        prompt: str,
        options: Any,
        *,
        logger: logging.Logger,
        state_path: Path,
    ) -> RunResult:
        """Execute a prompt and return the accumulated result.

        Args:
            prompt: The prompt text to send to the model.
            options: Runner-specific options object (duck-typed).
            logger: Phase logger for debug/info/warning output.
            state_path: Path to ``state.json`` for pause persistence.

        Returns:
            ``RunResult`` with text, session_id and ``usage: TokenUsage``
            carrying all four Anthropic token counters.

        Raises:
            OverageAbort: When overage billing is detected.
            RateLimitHit: When the current rate-limit window is exhausted.
        """
        ...
