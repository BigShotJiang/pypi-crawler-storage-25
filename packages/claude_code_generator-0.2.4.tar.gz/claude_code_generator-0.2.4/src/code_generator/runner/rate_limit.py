"""Wait-and-resume main loop for the SDK/subprocess runner.

Implements non-negotiable #5: rate-limit handling is wait-and-resume,
not exponential backoff. Session IDs are preserved across pauses so
Claude can continue from where it left off.
"""

from __future__ import annotations

import asyncio
import time
from typing import TYPE_CHECKING

from code_generator import state as _state
from code_generator.runner.types import (
    ApiUpstreamError,
    OverageAbort,
    RateLimitHit,
    RunResult,
)

# Escalating backoff for upstream 5xx outages (seconds). Caps at 10 min.
# Never gives up — we keep looping until Anthropic recovers.
_UPSTREAM_BACKOFF_SECS: list[int] = [60, 120, 240, 480, 600]

# Maximum allowed pause duration (12 hours). Any paused_until further
# than this from now is clamped. Prevents unbounded sleep from clock
# skew or malformed API timestamps. (Section 14, part 2)
MAX_PAUSE_SECONDS = 12 * 3600  # 43200

if TYPE_CHECKING:
    import logging
    from collections.abc import Callable, Coroutine
    from pathlib import Path
    from typing import Any

    from code_generator.runner.protocol import RunnerProtocol


async def main_loop(
    runner: RunnerProtocol,
    prompt: str,
    options: Any,
    *,
    state_path: Path,
    logger: logging.Logger,
    now_fn: Callable[[], float] = time.time,
    sleep_fn: Callable[[float], Coroutine[Any, Any, None]] = asyncio.sleep,
) -> RunResult:
    """Execute the wait-and-resume loop until a result is obtained.

    On entry, checks whether state.json indicates an active pause and waits
    in ≤60-second chunks before attempting the run. On RateLimitHit, reloads
    the state (already updated by the runner) and waits again. On success,
    clears the pause and persists the updated state.

    Args:
        runner: Module or object with ``async run(prompt, options, ...)`` method.
        prompt: The prompt text to pass to the runner.
        options: Options object forwarded to the runner (permission_mode and
            resume will be set here as needed).
        state_path: Path to state.json for persistence.
        logger: Phase logger.
        now_fn: Callable returning current time (injectable for tests).
        sleep_fn: Async sleep callable (injectable for tests).

    Returns:
        RunResult from the first successful run.

    Raises:
        OverageAbort: When overage billing is detected by the runner.
    """
    await _wait_if_paused(state_path, logger, now_fn, sleep_fn)

    upstream_attempt = 0

    while True:
        # Resume from the last session if one was saved.
        st = _state.load_state(state_path)
        if st.session_id:
            # Defensive assignment in case options doesn't expose resume as a field.
            options.resume = st.session_id
        else:
            # Ensure no stale session ID leaks across calls (non-negotiable #6).
            options.resume = None

        try:
            result = await runner.run(
                prompt,
                options,
                logger=logger,
                state_path=state_path,
            )
        except RateLimitHit:
            # State was already updated by the runner before raising.
            # Wait until the pause clears, then retry. Upstream-error retries
            # are independent of rate-limit pauses, so reset the counter.
            upstream_attempt = 0
            logger.info("RateLimitHit received — waiting for rate-limit window to reset.")
            await _wait_if_paused(state_path, logger, now_fn, sleep_fn)
            continue
        except ApiUpstreamError as exc:
            delay = _UPSTREAM_BACKOFF_SECS[min(upstream_attempt, len(_UPSTREAM_BACKOFF_SECS) - 1)]
            upstream_attempt += 1
            logger.error(
                "Anthropic upstream error (%s). Sleeping %ds before retry (attempt %d).",
                exc,
                delay,
                upstream_attempt,
            )
            # Persist so a user inspecting state.json (or a resume after
            # crash) sees why we're idle.
            st = _state.load_state(state_path)
            st.last_error = f"upstream_5xx: {exc}"
            st.paused_until = int(now_fn() + delay)
            st.rate_limit_type = "upstream_5xx"
            _state.save_state(state_path, st)
            await sleep_fn(float(delay))
            # Clear the pause marker so _wait_if_paused doesn't double-wait
            # on the next iteration; a retry will re-set it if it fails again.
            st = _state.load_state(state_path)
            _state.clear_pause(st)
            st.rate_limit_type = None
            _state.save_state(state_path, st)
            continue
        except OverageAbort:
            # Non-negotiable #4 — overage never retries.
            raise

        # Success — clear the pause and persist.
        st = _state.load_state(state_path)
        _state.clear_pause(st)
        st.last_error = None
        st.rate_limit_type = None
        _state.save_state(state_path, st)
        return result


async def _wait_if_paused(
    state_path: Path,
    logger: logging.Logger,
    now_fn: Callable[[], float],
    sleep_fn: Callable[[float], Coroutine[Any, Any, None]],
) -> None:
    """Sleep in ≤60-second chunks while state indicates an active pause.

    Args:
        state_path: Path to state.json.
        logger: Phase logger.
        now_fn: Callable returning current time.
        sleep_fn: Async sleep callable.
    """
    st = _state.load_state(state_path)
    while True:
        now = now_fn()
        # Clamp unreasonable paused_until (Section 14, part 2).
        if st.paused_until is not None and st.paused_until > now + MAX_PAUSE_SECONDS:
            original = st.paused_until
            st.paused_until = int(now + MAX_PAUSE_SECONDS)
            _state.save_state(state_path, st)
            logger.warning(
                "paused_until clamped from %d to %d (MAX_PAUSE_SECONDS=%d).",
                original,
                st.paused_until,
                MAX_PAUSE_SECONDS,
            )
        if not _state.is_paused(st, now=now):
            break
        remaining = st.paused_until - now  # type: ignore[operator]
        chunk = min(60.0, max(0.0, remaining))
        logger.info(
            "Rate-limit pause active; sleeping %.1fs (%.1fs remaining).",
            chunk,
            remaining,
        )
        await sleep_fn(chunk)
        st = _state.load_state(state_path)
