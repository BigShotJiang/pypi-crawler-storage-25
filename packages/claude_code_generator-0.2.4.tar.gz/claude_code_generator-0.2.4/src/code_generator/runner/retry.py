"""Retry logic with exponential backoff and a circuit breaker.

Backoff applies only to transient errors. RateLimitHit and OverageAbort
bypass both backoff and the circuit breaker — they are handled by the
wait-and-resume loop in rate_limit.py, not by blind retrying.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, TypeVar

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

from code_generator.runner.types import OverageAbort, RateLimitHit, TransientRunnerError

T = TypeVar("T")

# ---------------------------------------------------------------------------
# Backoff schedule (seconds). Capped at 120.
# ---------------------------------------------------------------------------

_BACKOFF_SCHEDULE: list[int] = [10, 20, 40, 80, 120]


# Re-export TransientRunnerError so existing code that imports it from here
# continues to work without modification.
__all__ = ["CircuitBreaker", "CircuitOpen", "TransientRunnerError", "with_backoff"]


# ---------------------------------------------------------------------------
# Transient-error types (retry-eligible)
# ---------------------------------------------------------------------------

_TRANSIENT_TYPES: tuple[type[BaseException], ...] = (
    asyncio.TimeoutError,
    ConnectionError,
    OSError,
    TransientRunnerError,
)


def _is_transient(exc: BaseException) -> bool:
    """Return True for exceptions that warrant a retry via backoff."""
    return isinstance(exc, _TRANSIENT_TYPES)


def _is_rate_limit_or_overage(exc: BaseException) -> bool:
    """Return True for exceptions that bypass both backoff and the breaker."""
    return isinstance(exc, RateLimitHit | OverageAbort)


# ---------------------------------------------------------------------------
# Circuit breaker
# ---------------------------------------------------------------------------


class CircuitOpen(RuntimeError):
    """Raised when the circuit breaker trips due to consecutive failures."""


class CircuitBreaker:
    """Counts consecutive non-rate-limit failures and opens after max_failures.

    Args:
        max_failures: Number of consecutive failures before the circuit opens.
    """

    def __init__(self, max_failures: int = 3) -> None:
        self._max_failures = max_failures
        self._consecutive_failures = 0

    def record_success(self) -> None:
        """Reset the failure counter after a successful operation."""
        self._consecutive_failures = 0

    def record_failure(self, exc: BaseException) -> None:
        """Increment the failure counter; raise CircuitOpen when threshold is hit.

        Rate-limit and overage exceptions are excluded from the counter —
        they are expected transients managed elsewhere.

        Args:
            exc: The exception that caused the failure.

        Raises:
            CircuitOpen: When consecutive failures reach max_failures.
        """
        if _is_rate_limit_or_overage(exc):
            # Non-negotiable bypass — never count rate-limit/overage towards circuit.
            return

        self._consecutive_failures += 1
        if self._consecutive_failures >= self._max_failures:
            raise CircuitOpen(
                f"Circuit opened after {self._consecutive_failures} consecutive failures."
            )


# ---------------------------------------------------------------------------
# with_backoff
# ---------------------------------------------------------------------------


async def with_backoff(
    coro_factory: Callable[[], Awaitable[T]],
    *,
    attempts: int = 5,
    sleep_fn: Callable[[float], Awaitable[None]] = asyncio.sleep,
    breaker: CircuitBreaker | None = None,
) -> T:
    """Execute coro_factory with exponential backoff on transient errors.

    Only retries on transient errors (asyncio.TimeoutError, ConnectionError,
    OSError, TransientRunnerError). RateLimitHit and OverageAbort propagate
    immediately without touching the circuit breaker.

    Args:
        coro_factory: Zero-argument callable returning an awaitable.
        attempts: Maximum number of attempts (1 means no retries).
        sleep_fn: Async sleep function (injectable for tests).
        breaker: Optional CircuitBreaker instance.

    Returns:
        The value returned by coro_factory on success.

    Raises:
        CircuitOpen: When the breaker trips.
        RateLimitHit: Immediately, bypassing backoff.
        OverageAbort: Immediately, bypassing backoff.
        The original exception: When all attempts are exhausted.
    """
    last_exc: BaseException | None = None

    for attempt in range(attempts):
        try:
            result = await coro_factory()
            if breaker is not None:
                breaker.record_success()
            return result
        except (RateLimitHit, OverageAbort):
            # Non-negotiable: bypass backoff and breaker for rate-limit/overage.
            raise
        except BaseException as exc:
            if not _is_transient(exc):
                # Non-transient error — propagate without retry or breaker.
                raise

            last_exc = exc

            if breaker is not None:
                # record_failure may raise CircuitOpen — let it propagate.
                breaker.record_failure(exc)

            delay = _BACKOFF_SCHEDULE[min(attempt, len(_BACKOFF_SCHEDULE) - 1)]
            await sleep_fn(float(delay))

    # All attempts exhausted.
    assert last_exc is not None
    raise last_exc
