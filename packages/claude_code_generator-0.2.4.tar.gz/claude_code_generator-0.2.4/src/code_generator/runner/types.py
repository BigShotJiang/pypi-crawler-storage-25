"""Shared domain types for all runner modules.

Centralises exception types and result dataclass so that sdk_runner,
subprocess_runner, rate_limit, and retry all depend on this module rather
than on each other — satisfying the Dependency Inversion Principle.
"""

from __future__ import annotations

from dataclasses import dataclass

# ---------------------------------------------------------------------------
# Exception types
# ---------------------------------------------------------------------------


class OverageAbort(RuntimeError):
    """Raised when overage billing is active — abort to avoid charges."""


class RateLimitHit(Exception):
    """Raised when the rate limit is rejected and the session is paused."""

    def __init__(self, resets_at: int, rate_limit_type: str) -> None:
        self.resets_at = resets_at
        self.rate_limit_type = rate_limit_type
        super().__init__(f"Rate limit hit; resets at {resets_at}, type={rate_limit_type}")


class ApiUpstreamError(RuntimeError):
    """Anthropic upstream returned a 5xx / is_error ResultMessage.

    The runner surfaces this so ``rate_limit.main_loop`` can wait-and-resume
    until the API recovers, instead of treating the error body as a normal
    assistant response.
    """


class TransientRunnerError(RuntimeError):
    """Marker exception for transient runner failures that should be retried."""


class MaxTurnsExceeded(RuntimeError):
    """Raised when the SDK terminates a session because the agent loop
    consumed its ``max_turns`` budget.

    Deterministic failure — never retried. Deliberately a sibling of
    ``ApiUpstreamError`` (not a subclass) so that ``rate_limit.main_loop``'s
    ``except ApiUpstreamError`` handler does not catch it and enter the
    wait-and-resume loop.
    """


class Phase0SchemaError(ValueError):
    """Raised when Phase 0 JSON parsed successfully but fails schema validation.

    Carries the offending JSON fragment so the caller can log or surface it.
    Only raised after successful JSON parsing — the existing fallback for total
    JSON parse failure (mode falls back to ``"single"`` after retries) is a
    separate code path and remains unchanged.

    Args:
        message: Human-readable description of the validation failure.
        raw: The raw dict that failed validation.
    """

    def __init__(self, message: str, raw: dict) -> None:
        self.raw = raw
        super().__init__(message)


# ---------------------------------------------------------------------------
# Token usage type
# ---------------------------------------------------------------------------


@dataclass
class TokenUsage:
    """All four Anthropic token counters from a single SDK result message.

    Fields map directly to the Anthropic usage payload:
    - ``input``      ← ``input_tokens``
    - ``output``     ← ``output_tokens``
    - ``cache_write`` ← ``cache_creation_input_tokens``
    - ``cache_read``  ← ``cache_read_input_tokens``

    Missing or ``None`` values default to 0 — callers never need to guard
    against ``None`` arithmetic.
    """

    input: int = 0
    output: int = 0
    cache_read: int = 0
    cache_write: int = 0

    def __iadd__(self, other: TokenUsage) -> TokenUsage:
        """Accumulate token counts in place.

        Args:
            other: Another :class:`TokenUsage` whose counters are added.

        Returns:
            ``self`` with all four counters incremented.
        """
        self.input += other.input
        self.output += other.output
        self.cache_read += other.cache_read
        self.cache_write += other.cache_write
        return self


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------


class RunResult:
    """Captured output from a single SDK or subprocess run.

    The canonical token counter is ``usage: TokenUsage``. The flat kwargs
    ``tokens_in`` and ``tokens_out`` are accepted by ``__init__`` for
    backward compatibility and will be removed in 0.3.0.
    """

    def __init__(
        self,
        text: str,
        session_id: str | None,
        usage: TokenUsage | None = None,
        # DEPRECATED: use usage= — will be removed in 0.3.0
        tokens_in: int | None = None,
        tokens_out: int | None = None,
    ) -> None:
        self.text = text
        self.session_id = session_id
        if usage is not None:
            self.usage = usage
        else:
            self.usage = TokenUsage(
                input=tokens_in or 0,
                output=tokens_out or 0,
            )

    @property
    def tokens_in(self) -> int:
        # DEPRECATED: use .usage.input — will be removed in 0.3.0
        return self.usage.input

    @property
    def tokens_out(self) -> int:
        # DEPRECATED: use .usage.output — will be removed in 0.3.0
        return self.usage.output

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, RunResult):
            return NotImplemented
        return (
            self.text == other.text
            and self.session_id == other.session_id
            and self.usage == other.usage
        )

    def __repr__(self) -> str:
        return (
            f"RunResult(text={self.text!r}, session_id={self.session_id!r}, usage={self.usage!r})"
        )
