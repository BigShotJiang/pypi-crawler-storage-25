"""Runner package — SDK runner with subprocess fallback.

Factory function `get_runner()` selects the SDK runner when
`claude_agent_sdk` is importable, otherwise falls back to the subprocess
runner that shells out to the `claude` CLI.

All shared types are also re-exported here for convenience.
"""

from __future__ import annotations

from code_generator.runner.protocol import RunnerProtocol
from code_generator.runner.types import (
    ApiUpstreamError,
    MaxTurnsExceeded,
    OverageAbort,
    RateLimitHit,
    RunResult,
    TokenUsage,
    TransientRunnerError,
)

__all__ = [
    "ApiUpstreamError",
    "MaxTurnsExceeded",
    "OverageAbort",
    "RateLimitHit",
    "RunResult",
    "RunnerProtocol",
    "TokenUsage",
    "TransientRunnerError",
    "get_runner",
]


def get_runner() -> RunnerProtocol:
    """Return the appropriate runner module.

    Returns:
        sdk_runner module if claude_agent_sdk is available, else subprocess_runner.
        Both satisfy ``RunnerProtocol``.
    """
    try:
        import claude_agent_sdk  # noqa: F401

        from . import sdk_runner

        return sdk_runner  # type: ignore[return-value]
    except ImportError:
        from . import subprocess_runner

        return subprocess_runner  # type: ignore[return-value]
