"""Shared utilities for the runner package.

Contains helpers used by both sdk_runner and subprocess_runner to avoid
cross-runner imports and keep private implementation details internal.
"""

from __future__ import annotations

import re

_UPSTREAM_5XX_RE = re.compile(r"API\s+Error:\s*5\d\d\b")


def looks_like_upstream_5xx(text: str) -> bool:
    """Return True when *text* contains an Anthropic 5xx error marker."""
    return bool(_UPSTREAM_5XX_RE.search(text))
