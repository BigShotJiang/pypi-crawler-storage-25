"""Message parsing helpers for SDK runner messages.

Provides pure helpers that operate on duck-typed message objects.
These have no dependency on the SDK client and can be tested independently,
satisfying SRP by keeping parsing logic separate from session orchestration.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from code_generator import state as _state
from code_generator.runner.types import OverageAbort, RateLimitHit, TokenUsage

if TYPE_CHECKING:
    import logging
    from pathlib import Path


# ---------------------------------------------------------------------------
# Text and usage extraction
# ---------------------------------------------------------------------------


def extract_text(msg: Any) -> str:
    """Extract concatenated text from an AssistantMessage's content blocks."""
    parts: list[str] = []
    for block in getattr(msg, "content", []):
        text = getattr(block, "text", None)
        if text is not None:
            parts.append(text)
    return "".join(parts)


def extract_usage(msg: Any) -> TokenUsage:
    """Return a TokenUsage from a ResultMessage, defensively.

    Reads all four Anthropic token counters. Missing or ``None`` values
    default to 0 — never returns ``None`` fields.

    Args:
        msg: The ResultMessage (duck-typed; may have dict or object .usage).

    Returns:
        A fully populated ``TokenUsage`` with zero defaults for absent fields.
    """
    usage = getattr(msg, "usage", None)
    if usage is None:
        return TokenUsage()
    if isinstance(usage, dict):
        return TokenUsage(
            input=usage.get("input_tokens") or 0,
            output=usage.get("output_tokens") or 0,
            cache_write=usage.get("cache_creation_input_tokens") or 0,
            cache_read=usage.get("cache_read_input_tokens") or 0,
        )
    return TokenUsage(
        input=getattr(usage, "input_tokens", None) or 0,
        output=getattr(usage, "output_tokens", None) or 0,
        cache_write=getattr(usage, "cache_creation_input_tokens", None) or 0,
        cache_read=getattr(usage, "cache_read_input_tokens", None) or 0,
    )


# ---------------------------------------------------------------------------
# Duck-type discriminators
# ---------------------------------------------------------------------------


def is_rate_limit_event(msg: Any) -> bool:
    """Return True when msg looks like a RateLimitEvent."""
    return hasattr(msg, "rate_limit_info")


def is_assistant_message(msg: Any) -> bool:
    """Return True when msg looks like an AssistantMessage."""
    return hasattr(msg, "content") and hasattr(msg, "model")


def is_result_message(msg: Any) -> bool:
    """Return True when msg looks like a ResultMessage."""
    return (
        hasattr(msg, "session_id")
        and hasattr(msg, "is_error")
        and not hasattr(msg, "rate_limit_info")
        and not hasattr(msg, "model")
    )


# ---------------------------------------------------------------------------
# Rate-limit event handler
# ---------------------------------------------------------------------------


def handle_rate_limit_event(
    msg: Any,
    logger: logging.Logger,
    state_path: Path,
) -> None:
    """Process a RateLimitEvent; raise OverageAbort or RateLimitHit as needed.

    Args:
        msg: The RateLimitEvent message (duck-typed).
        logger: Phase logger for warnings.
        state_path: Path to state.json for persistence.

    Raises:
        OverageAbort: When overage billing is active.
        RateLimitHit: When the rate limit is rejected and resets_at is known.
    """
    info = getattr(msg, "rate_limit_info", None)
    if info is None:
        logger.warning("RateLimitEvent received but has no rate_limit_info — skipping.")
        return

    # Non-negotiable #4: overage check — abort before incurring charges.
    # SDK values: "allowed" / "allowed_warning" mean overage billing IS active
    # (unsafe); "rejected" means overage is off and requests are blocked (safe);
    # None / "disabled" also safe.
    overage_status = getattr(info, "overage_status", None)
    if overage_status in ("allowed", "allowed_warning"):
        raise OverageAbort(
            f"Overage API billing active ({overage_status}) — aborting to avoid charges"
        )

    status = getattr(info, "status", None)

    if status == "rejected":
        _handle_rejected_rate_limit(msg, info, logger, state_path)
    elif status == "allowed_warning":
        utilization = getattr(info, "utilization", None)
        logger.warning(
            "Rate limit allowed_warning: approaching limit (utilization=%s).", utilization
        )


def _handle_rejected_rate_limit(
    msg: Any,
    info: Any,
    logger: logging.Logger,
    state_path: Path,
) -> None:
    """Persist pause state and raise RateLimitHit, or warn if resets_at is missing."""
    resets_at = getattr(info, "resets_at", None)
    rate_limit_type = getattr(info, "rate_limit_type", None) or "unknown"
    session_id = getattr(msg, "session_id", None)

    if resets_at is not None:
        # Non-negotiable #5: add 60-second safety buffer so the API window
        # has fully cleared before we attempt to resume.
        paused_until = resets_at + 60
        st = _state.load_state(state_path)
        _state.mark_paused(
            st,
            resets_at=paused_until,
            rate_limit_type=str(rate_limit_type),
            session_id=session_id,
        )
        _state.save_state(state_path, st)
        raise RateLimitHit(paused_until, str(rate_limit_type))

    logger.warning("Rate limit rejected but no resets_at provided — cannot pause.")
