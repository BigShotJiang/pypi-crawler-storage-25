"""Centralised factory for ClaudeAgentOptions.

Eliminates the try/except import-with-fallback boilerplate that was duplicated
across every phase module and commands/review.py.  Call `make_agent_options`
once with the desired keyword arguments; it returns either the real
ClaudeAgentOptions (when claude_agent_sdk is installed) or a lightweight
duck-typed fallback that exposes the same attributes.
"""

from __future__ import annotations

from typing import Any


def make_agent_options(**kwargs: Any) -> Any:
    """Return a ClaudeAgentOptions-compatible object populated with *kwargs*.

    When ``claude_agent_sdk`` is importable the real ``ClaudeAgentOptions``
    class is used so the SDK receives its native type.  When the SDK is absent
    (subprocess-runner path) a minimal duck-typed fallback is returned whose
    attributes mirror the passed keyword arguments exactly.

    Args:
        **kwargs: Forwarded verbatim to ``ClaudeAgentOptions.__init__``.

    Returns:
        A ``ClaudeAgentOptions`` instance or a duck-typed fallback object.
    """
    try:
        from claude_agent_sdk import ClaudeAgentOptions  # type: ignore[import-not-found]

        return ClaudeAgentOptions(**kwargs)
    except ImportError:
        return _FallbackOptions(**kwargs)


class _FallbackOptions:
    """Duck-typed stand-in for ClaudeAgentOptions used when the SDK is absent."""

    def __init__(self, **kwargs: Any) -> None:
        self.__dict__.update(kwargs)
