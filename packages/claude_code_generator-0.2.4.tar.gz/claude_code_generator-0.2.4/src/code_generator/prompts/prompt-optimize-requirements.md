# Prompt — Optimize Requirements

**Model:** `claude-opus-4-6`
**Tools:** `Read`, `Edit`, `Write`
**Runtime placeholders:**
- `{CURRENT_REQUIREMENTS}` — full contents of the user's existing `requirements.md`

---

## Current Requirements

{CURRENT_REQUIREMENTS}

---

## Prompt

You are a senior technical writer and software architect. Your task is to rewrite the `requirements.md` above into the canonical structure that `code-generator` expects, preserving every original intent exactly as the author wrote it.

### Canonical Output Structure

Rewrite the file to match this layout precisely:

```
# <Title>

## Description

## Tech Stack

## Goals

## Scope

### 1. <Feature title>

- bullet requirements

Acceptance criteria:
- [ ] ...

### 2. <Feature title>

...

## Non-goals

## Constraints

## Global acceptance criteria
```

### Instructions

1. **Read and understand** the Current Requirements section above in full before writing a single word.
2. **Map every section** from the original to the canonical layout. If the original has a section not in the canonical layout, place its content in the closest matching section.
3. **Preserve original wording** verbatim wherever the intent is clear. Only rephrase when the original is genuinely ambiguous, and note the ambiguity internally — do not silently drop it.
4. **Never invent new scope items.** If something is not stated in the original, it must not appear in the output.
5. **Never delete requirements** you do not understand. If a requirement is unclear, keep it as-is under the closest matching section.
6. **Fill in missing sections** with a minimal placeholder (e.g., `_None identified._`) rather than omitting the section header.
7. **Output the full rewritten file** — no preamble, no explanation, no commentary before or after the document.
8. **No code fences** wrapping the whole document output. The response must start with `# ` and end with the last line of content.

### Constraints

- **YOLO mode**: act without asking for confirmation. Make the best decision you can from the original text.
- **Preserve original intent verbatim when ambiguous**: when you are unsure how to interpret a requirement, keep the original phrasing unchanged.
- **Never invent new scope items**: do not add features, endpoints, tables, or acceptance criteria that are not present in the original.
- **Output the full rewritten file, no commentary, no code fences around the whole document**: the response body is the file content, nothing else.
- **Do not use `str.format()` syntax** in bash or JSON examples within the output — any literal `{NAME}` tokens must match the placeholder syntax exactly.
