"""Per-phase structured logging for the code-generator orchestrator.

Each phase gets its own log file under .code-generator/logs/ and a shared
RichHandler for colour-coded console output. The setup is idempotent: calling
setup_phase_logger() twice for the same phase does not duplicate handlers.
"""

import logging
from pathlib import Path

from rich.logging import RichHandler

_FILE_FORMATTER = logging.Formatter("%(asctime)s %(levelname)s %(message)s")


def setup_phase_logger(
    phase_name: str,
    project_dir: Path,
    *,
    level: int = logging.INFO,
) -> logging.Logger:
    """Configure and return a logger for a single orchestration phase.

    The logger writes to both a phase-specific log file and the console via
    Rich. A second call for the same phase_name returns the existing logger
    without adding duplicate handlers.

    Args:
        phase_name: Short identifier for the phase (e.g. ``"planning"``).
        project_dir: Root directory of the user's project. Logs are written to
            ``project_dir / ".code-generator" / "logs" / f"{phase_name}.log"``.
        level: Python logging level applied to the logger. Defaults to INFO.

    Returns:
        Configured :class:`logging.Logger` instance.
    """
    logger = logging.getLogger(f"code_generator.phase.{phase_name}")

    if _already_configured(logger):
        return logger

    logger.setLevel(level)
    logger.propagate = False

    _attach_file_handler(logger, project_dir, phase_name)
    _attach_rich_handler(logger)

    return logger


def _already_configured(logger: logging.Logger) -> bool:
    """Return True when the logger already has handlers attached."""
    return bool(logger.handlers)


def _attach_file_handler(
    logger: logging.Logger,
    project_dir: Path,
    phase_name: str,
) -> None:
    log_dir = project_dir / ".code-generator" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    handler = logging.FileHandler(log_dir / f"{phase_name}.log", encoding="utf-8")
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(_FILE_FORMATTER)
    logger.addHandler(handler)


def _attach_rich_handler(logger: logging.Logger) -> None:
    handler = RichHandler(show_time=False, show_path=False)
    handler.setLevel(logging.INFO)
    logger.addHandler(handler)


def log_issue_usage(
    logger: logging.Logger, phase: str | int, issue_number: int, usage: object
) -> None:
    """Emit the standard per-issue token line.

    Logs at INFO level with the format::

        Phase N: issue #M tokens: in=X cache_read=Y cache_write=Z out=W

    Args:
        logger: Phase logger to write to.
        phase: Phase identifier (e.g. ``2``, ``"3/4"``).
        issue_number: GitHub issue number.
        usage: A :class:`~code_generator.runner.types.TokenUsage` instance.
    """
    from code_generator.runner.types import TokenUsage  # noqa: PLC0415

    if not isinstance(usage, TokenUsage):
        return
    logger.info(
        "Phase %s: issue #%d tokens: in=%d cache_read=%d cache_write=%d out=%d",
        phase,
        issue_number,
        usage.input,
        usage.cache_read,
        usage.cache_write,
        usage.output,
    )


def log_phase_usage(logger: logging.Logger, phase: str | int, usage: object) -> None:
    """Emit the standard phase-boundary token summary line.

    Logs at INFO level with the format::

        Phase N complete: in=X cache_read=Y cache_write=Z out=W total=T

    where ``total = in + cache_read + cache_write + out``.

    Args:
        logger: Phase logger to write to.
        phase: Phase identifier (e.g. ``0``, ``"1"``, ``"6"``).
        usage: A :class:`~code_generator.runner.types.TokenUsage` instance.
    """
    # Import here to avoid a circular dependency at module load time.
    from code_generator.runner.types import TokenUsage  # noqa: PLC0415

    if not isinstance(usage, TokenUsage):
        return
    total = usage.input + usage.cache_read + usage.cache_write + usage.output
    logger.info(
        "Phase %s complete: in=%d cache_read=%d cache_write=%d out=%d total=%d",
        phase,
        usage.input,
        usage.cache_read,
        usage.cache_write,
        usage.output,
        total,
    )
