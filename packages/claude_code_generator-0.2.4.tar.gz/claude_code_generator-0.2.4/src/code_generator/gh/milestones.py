"""Milestone lifecycle: create, close, and delete via the GitHub API."""

from __future__ import annotations

import json

from code_generator.gh.core import _repo_name_with_owner, _run


def create_milestone(title: str, description: str = "") -> int:
    """Create a GitHub milestone via the API and return its number.

    Args:
        title: Milestone title.
        description: Optional description.

    Returns:
        The integer milestone number from the API response.

    Raises:
        GhError: When gh fails.
    """
    nwo = _repo_name_with_owner()
    raw = _run(
        [
            "gh",
            "api",
            "--method",
            "POST",
            f"repos/{nwo}/milestones",
            "-f",
            f"title={title}",
            "-f",
            f"description={description}",
            "-f",
            "state=open",
        ]
    )
    data = json.loads(raw)
    return int(data["number"])


def delete_milestone(number: int) -> None:
    """Delete a GitHub milestone permanently via the API.

    Uses DELETE instead of PATCH/close because GitHub returns HTTP 422
    "already_exists" when creating a milestone whose title matches an existing
    one — even a closed one. Deletion is the only way to allow reuse of the
    same title on retry.

    Args:
        number: The milestone number.

    Raises:
        GhError: When gh fails.
    """
    nwo = _repo_name_with_owner()
    _run(
        [
            "gh",
            "api",
            "--method",
            "DELETE",
            f"repos/{nwo}/milestones/{number}",
        ]
    )


def close_milestone(number: int) -> None:
    """Close a GitHub milestone via the API.

    Args:
        number: The milestone number.

    Raises:
        GhError: When gh fails.
    """
    nwo = _repo_name_with_owner()
    _run(
        [
            "gh",
            "api",
            "--method",
            "PATCH",
            f"repos/{nwo}/milestones/{number}",
            "-f",
            "state=closed",
        ]
    )
