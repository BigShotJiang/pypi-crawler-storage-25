"""Label management: create, add, and seed standard label taxonomy."""

from __future__ import annotations

from code_generator.gh.core import GhError, _run


def ensure_label(name: str, color: str, description: str) -> None:
    """Create a label, ignoring "already exists" errors.

    Args:
        name: Label name, e.g. ``"priority:high"``.
        color: Hex colour without leading ``#``, e.g. ``"FF0000"``.
        description: Human-readable description.

    Raises:
        GhError: On any error other than "already exists".
    """
    try:
        _run(["gh", "label", "create", name, "--color", color, "--description", description])
    except GhError as exc:
        if "already exists" in exc.stderr.lower():
            return
        raise


def add_label(issue_number: int, label: str) -> None:
    """Add a label to an existing issue.

    Args:
        issue_number: The issue number.
        label: Label name to add.

    Raises:
        GhError: When gh fails.
    """
    _run(["gh", "issue", "edit", str(issue_number), "--add-label", label])


def ensure_standard_labels() -> None:
    """Seed the repository with the standard label taxonomy.

    Creates all labels defined in requirements.md §8. Idempotent —
    "already exists" errors are silently ignored.

    Raises:
        GhError: On unexpected gh failures.
    """
    _create_priority_labels()
    _create_area_labels()
    _create_phase_labels()
    _create_agent_labels()


def _create_priority_labels() -> None:
    for priority, color in [("high", "FF0000"), ("medium", "FBCA04"), ("low", "0E8A16")]:
        ensure_label(f"priority:{priority}", color, f"{priority.capitalize()} priority")


def _create_area_labels() -> None:
    area_color = "0052CC"
    areas = [
        "cli",
        "orchestrator",
        "runner",
        "state",
        "prompts",
        "gh",
        "tests",
        "docs",
        "api",
        "frontend",
        "database",
        "auth",
        "infra",
    ]
    for area in areas:
        ensure_label(f"area:{area}", area_color, f"Area: {area}")


def _create_phase_labels() -> None:
    phase_color = "D4C5F9"
    for phase in ["plan", "implement", "review", "test"]:
        ensure_label(f"phase:{phase}", phase_color, f"Phase: {phase}")


def _create_agent_labels() -> None:
    agent_color = "7057FF"
    agents = [
        "frontend-developer",
        "typescript-pro",
        "tailwind-patterns",
        "ui-ux-designer",
        "python-pro",
        "fastapi-expert-agent",
        "supabase-connection-expert",
        "nestjs-expert",
        "baml-expert-agent",
        "riskfolio-expert",
    ]
    for agent in agents:
        ensure_label(f"agent:{agent}", agent_color, f"Agent: {agent}")
