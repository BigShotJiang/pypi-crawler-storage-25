"""Core primitives: GhError, GhCommandRunner protocol, and _run() wrapper."""

from __future__ import annotations

import subprocess
from typing import Protocol


class GhError(RuntimeError):
    """Raised when a `gh` subprocess exits with a non-zero return code.

    Attributes:
        returncode: The exit code from the gh process.
        stderr: The stderr output from the gh process.
    """

    def __init__(self, returncode: int, stderr: str) -> None:
        self.returncode = returncode
        self.stderr = stderr
        super().__init__(f"gh exited with code {returncode}: {stderr!r}")


class GhCommandRunner(Protocol):
    """Abstraction boundary for the gh CLI subprocess invocation.

    Conforming types implement a single ``run`` method that executes an
    argv list and returns the trimmed stdout string.  This follows the
    same structural-Protocol pattern used by ``RunnerProtocol`` in the
    runner layer, enabling dependency inversion for the entire gh package.
    """

    def run(self, argv: list[str], *, input: str | None = None) -> str:  # noqa: A002
        """Execute a gh command and return stdout on success.

        Args:
            argv: Full argument list including the ``gh`` binary.
            input: Optional string piped to stdin.

        Returns:
            Stripped stdout string.

        Raises:
            GhError: When the process exits with a non-zero return code.
        """
        ...


class SubprocessGhRunner:
    """Concrete ``GhCommandRunner`` that invokes the real ``gh`` CLI."""

    def run(self, argv: list[str], *, input: str | None = None) -> str:  # noqa: A002
        result = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            check=False,
            input=input,
        )
        if result.returncode != 0:
            raise GhError(result.returncode, result.stderr)
        return result.stdout.strip()


_runner: GhCommandRunner = SubprocessGhRunner()


def set_runner(runner: GhCommandRunner) -> None:
    """Replace the module-level runner (used in tests for DI).

    Args:
        runner: Any object satisfying ``GhCommandRunner``.
    """
    global _runner  # noqa: PLW0603
    _runner = runner


def reset_runner() -> None:
    """Restore the default ``SubprocessGhRunner`` (used in test teardown)."""
    global _runner  # noqa: PLW0603
    _runner = SubprocessGhRunner()


def _run(argv: list[str], *, input: str | None = None) -> str:  # noqa: A002
    """Run a gh sub-command and return stdout on success.

    Delegates to the module-level ``_runner`` so tests can inject a fake
    without patching ``subprocess.run`` at the module level.

    Args:
        argv: Full argument list including the ``gh`` binary.
        input: Optional string piped to stdin.

    Returns:
        Stripped stdout string.

    Raises:
        GhError: When the process exits with a non-zero return code.
    """
    return _runner.run(argv, input=input)


def _repo_name_with_owner() -> str:
    """Return the ``owner/repo`` string for the current repository.

    Returns:
        A string like ``"SilvioBaratto/code-generator"``.

    Raises:
        GhError: When gh cannot determine the repo.
    """
    return _run(["gh", "repo", "view", "--json", "nameWithOwner", "--jq", ".nameWithOwner"])
