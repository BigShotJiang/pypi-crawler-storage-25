"""Issue CRUD operations and label-to-agent extraction."""

from __future__ import annotations

import json
from typing import Any

from code_generator.gh.core import _run

_AGENT_PREFIX = "agent:"
_DEFAULT_AGENT = "python-pro"

_VIEW_DEFAULT_FIELDS = "number,title,body,state,labels,milestone,comments"
_LIST_DEFAULT_FIELDS = "number,title,body,state,labels,comments"


def agent_from_labels(labels: list[dict[str, Any]]) -> str:
    """Extract the agent name from a list of label dicts returned by gh.

    Returns the agent name (without the ``"agent:"`` prefix), or
    ``"python-pro"`` when no ``agent:`` label is present.
    """
    for lbl in labels:
        name: str = lbl.get("name", "")
        if name.startswith(_AGENT_PREFIX):
            return name[len(_AGENT_PREFIX) :]
    return _DEFAULT_AGENT


def view_issue(number: int, *, fields: list[str] | None = None) -> dict:  # type: ignore[type-arg]
    """Fetch a single issue as a parsed JSON dict.

    Args:
        number: Issue number.
        fields: Field names to request. Defaults to :data:`_VIEW_DEFAULT_FIELDS`.
    """
    field_str = ",".join(fields) if fields is not None else _VIEW_DEFAULT_FIELDS
    raw = _run(["gh", "issue", "view", str(number), "--json", field_str])
    return json.loads(raw)  # type: ignore[no-any-return]


def list_issues(
    *,
    milestone: str | None = None,
    state: str = "open",
    fields: list[str] | None = None,
) -> list[dict]:  # type: ignore[type-arg]
    """List issues, optionally filtered by milestone and state.

    Args:
        milestone: Milestone title to filter by.
        state: Issue state filter (``"open"`` or ``"closed"``).
        fields: Field names to request. Defaults to :data:`_LIST_DEFAULT_FIELDS`.
    """
    field_str = ",".join(fields) if fields is not None else _LIST_DEFAULT_FIELDS
    argv = ["gh", "issue", "list", "--state", state, "--json", field_str]
    if milestone is not None:
        argv += ["--milestone", milestone]
    raw = _run(argv)
    return json.loads(raw)  # type: ignore[no-any-return]


def issue_state(number: int) -> str:
    """Return the issue state as a lowercase string (``"open"`` or ``"closed"``)."""
    raw = _run(["gh", "issue", "view", str(number), "--json", "state", "--jq", ".state"])
    return raw.strip().lower()
