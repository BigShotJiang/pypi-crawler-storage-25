"""Thin subprocess wrapper around the `git` CLI.

All git operations in the orchestrator go through this module.
No direct subprocess.run() for git is allowed outside this file.
"""

from __future__ import annotations

import subprocess
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Exception
# ---------------------------------------------------------------------------


class GitError(RuntimeError):
    """Raised when a git subprocess exits with a non-zero return code.

    Attributes:
        returncode: The exit code from the git process.
        stderr: The stderr output from the git process.
    """

    def __init__(self, returncode: int, stderr: str) -> None:
        self.returncode = returncode
        self.stderr = stderr
        super().__init__(f"git exited with code {returncode}: {stderr!r}")


# ---------------------------------------------------------------------------
# Internal helper
# ---------------------------------------------------------------------------


def _run(
    argv: list[str],
    *,
    cwd: Path,
    check: bool = True,
) -> subprocess.CompletedProcess:  # type: ignore[type-arg]
    """Run a git sub-command and return the CompletedProcess.

    Args:
        argv: Full argument list including the ``git`` binary.
        cwd: Directory to run git in.
        check: When ``True`` (default), raise :class:`GitError` on non-zero exit.

    Returns:
        The :class:`subprocess.CompletedProcess` instance.

    Raises:
        GitError: When the process exits with a non-zero return code and
            ``check=True``.
    """
    result = subprocess.run(
        argv,
        cwd=cwd,
        capture_output=True,
        text=True,
        check=False,
    )
    if check and result.returncode != 0:
        raise GitError(result.returncode, result.stderr)
    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def git_current_branch(cwd: Path) -> str:
    """Return the current git branch name.

    Returns ``"HEAD"`` when in detached HEAD state.

    Args:
        cwd: Directory to run git in.

    Returns:
        Branch name string.

    Raises:
        GitError: When the git command fails (e.g. not a git repo).
    """
    result = _run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=cwd)
    return result.stdout.strip()


def git_has_staged(cwd: Path) -> bool:
    """Return ``True`` when the git index has staged changes.

    Args:
        cwd: Directory to run git in.

    Returns:
        ``True`` if there are staged changes, ``False`` otherwise.
    """
    result = _run(["git", "diff", "--cached", "--quiet"], cwd=cwd, check=False)
    return result.returncode != 0


def git_add_all(cwd: Path) -> None:
    """Stage all changes (``git add .``).

    Args:
        cwd: Directory to run git in.

    Raises:
        GitError: When the git command fails.
    """
    _run(["git", "add", "."], cwd=cwd)


def git_commit(cwd: Path, msg: str) -> None:
    """Create a commit with the given message.

    Args:
        cwd: Directory to run git in.
        msg: Commit message.

    Raises:
        GitError: When the git command fails.
    """
    _run(["git", "commit", "-m", msg], cwd=cwd)


def git_push(cwd: Path, branch: str) -> None:
    """Push the branch to origin.

    Args:
        cwd: Directory to run git in.
        branch: Branch name to push.

    Raises:
        GitError: When the push is rejected or fails.
    """
    _run(["git", "push", "origin", branch], cwd=cwd)


def git_rev_parse_head(cwd: Path) -> str:
    """Return the full 40-character SHA of the current HEAD commit.

    Args:
        cwd: Directory to run git in.

    Returns:
        40-character hex SHA string, stripped of whitespace.

    Raises:
        GitError: When the git command fails (e.g. not a git repo, no commits).
    """
    result = _run(["git", "rev-parse", "HEAD"], cwd=cwd)
    return result.stdout.strip()


def git_pull_rebase(cwd: Path) -> None:
    """Pull with rebase (``git pull --rebase``).

    Args:
        cwd: Directory to run git in.

    Raises:
        GitError: When the git command fails (e.g. conflicts).
    """
    _run(["git", "pull", "--rebase"], cwd=cwd)


def git_diff_cached(cwd: Path, *, stat: bool = False) -> str:
    """Return the staged diff (``git diff --cached``).

    Args:
        cwd: Directory to run git in.
        stat: When ``True``, pass ``--stat`` for a diffstat summary.
            When ``False`` (default), pass ``--name-only`` for a file list.

    Returns:
        Raw stdout from the git command.

    Raises:
        GitError: When the git command fails.
    """
    flag = "--stat" if stat else "--name-only"
    result = _run(["git", "diff", "--cached", flag], cwd=cwd)
    return result.stdout


def git_diff(cwd: Path, base: str, head: str = "HEAD", *, stat: bool = False) -> str:
    """Return the diff between *base* and *head*.

    Args:
        cwd: Directory to run git in.
        base: Base commit-ish (SHA, branch, tag).
        head: Target commit-ish (default: ``"HEAD"``).
        stat: When ``True``, pass ``--stat`` to produce a diffstat summary
            instead of the full patch.

    Returns:
        The raw stdout from ``git diff`` (not stripped — preserving
        significant whitespace in patch output).

    Raises:
        GitError: When the git command fails.
    """
    argv = ["git", "diff", f"{base}..{head}"]
    if stat:
        argv.append("--stat")
    result = _run(argv, cwd=cwd)
    return result.stdout
