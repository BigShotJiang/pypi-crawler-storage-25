"""Pure function for detecting canonical requirements.md structure.

Used by the ``optimize`` command to short-circuit when the file is already
well-formed (see issue #145).
"""

from __future__ import annotations

import re

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_REQUIRED_H2: frozenset[str] = frozenset(
    [
        "description",
        "tech stack",
        "goals",
        "scope",
        "non-goals",
        "constraints",
        "global acceptance criteria",
    ]
)

_H1_RE = re.compile(r"^# .+", re.MULTILINE)
_H2_RE = re.compile(r"^## (.+)", re.MULTILINE)
_SCOPE_BODY_RE = re.compile(
    r"^## scope[ \t]*\n(.*?)(?=^## |\Z)",
    re.MULTILINE | re.DOTALL | re.IGNORECASE,
)
_NUMBERED_SECTION_RE = re.compile(
    r"^### \d+\..+?(?=^### \d+\.|\Z)",
    re.MULTILINE | re.DOTALL,
)
_AC_RE = re.compile(r"acceptance criteria", re.IGNORECASE)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _has_h1(text: str) -> bool:
    return bool(_H1_RE.search(text))


def _has_required_h2(text: str) -> bool:
    present = {m.group(1).strip().lower() for m in _H2_RE.finditer(text)}
    return _REQUIRED_H2.issubset(present)


def _scope_sections_all_have_ac(text: str) -> bool:
    scope_match = _SCOPE_BODY_RE.search(text)
    if not scope_match:
        return True
    sections = _NUMBERED_SECTION_RE.findall(scope_match.group(1))
    return all(_AC_RE.search(section) for section in sections)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def is_canonical_structure(text: str) -> bool:
    """Return ``True`` if *text* conforms to the canonical requirements.md structure.

    Checks:
    - At least one level-1 heading (``# Title``).
    - All required level-2 headings are present (case-insensitive).
    - Every ``### N.`` numbered subsection inside ``## Scope`` contains an
      ``Acceptance criteria`` block (case-insensitive).

    Pure function — no I/O, no side effects.
    """
    return _has_h1(text) and _has_required_h2(text) and _scope_sections_all_have_ac(text)
