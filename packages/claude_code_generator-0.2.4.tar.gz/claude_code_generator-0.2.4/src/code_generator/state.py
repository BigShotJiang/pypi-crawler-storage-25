"""Atomic state persistence for the code-generator orchestrator.

State is serialized to JSON and written via a tmp-file + os.replace() pattern
so a crash mid-write cannot corrupt the existing state file.

Non-negotiables #5 (wait-and-resume) and #7 (atomic writes).
"""

import dataclasses
import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from code_generator.runner.types import TokenUsage


@dataclass
class IssueState:
    """Lightweight record for a single GitHub issue within a phase."""

    number: int
    status: Literal["open", "closed"]
    agent: str
    labels: list[str] = field(default_factory=list)
    reviewed: bool = False


@dataclass
class EffortHint:
    """Advisory effort hint emitted by Phase 0 for a class of issues.

    ``scope_keyword`` is a short descriptor (e.g. "database migration") that
    Phase 3/4 can match against issue titles or labels.  ``effort`` is one of
    ``"low"``, ``"medium"``, or ``"high"`` — ``"max"`` is deliberately excluded
    as it is gated to Opus-only phases.
    """

    scope_keyword: str
    effort: Literal["low", "medium", "high"]


@dataclass
class CycleState:
    """State for one generation cycle (maps 1-to-1 with a GitHub Milestone)."""

    id: int
    name: str
    milestone_number: int | None
    milestone_title: str
    status: str
    phase: int | None
    issues: list[IssueState]
    commit_sha: str | None
    depends_on: list[int] = field(default_factory=list)
    scope: str = ""
    effort_hints: list[EffortHint] = field(default_factory=list)
    base_commit: str | None = None
    token_usage: dict[str, TokenUsage] = field(default_factory=dict)
    started_at: str | None = None
    finished_at: str | None = None


@dataclass
class State:
    """Root state object persisted to .code-generator/state.json."""

    mode: Literal["single", "multi-cycle", "unknown"]
    started_at: str
    updated_at: str
    current_cycle: int | None = None
    cycles: list[CycleState] = field(default_factory=list)
    phase: int | None = None
    issues: list[IssueState] = field(default_factory=list)
    session_id: str | None = None
    paused_until: int | None = None
    rate_limit_type: str | None = None
    last_error: str | None = None
    effort_hints: list[EffortHint] = field(default_factory=list)
    requirements_hash: str | None = None
    base_commit: str | None = None
    token_usage: dict[str, TokenUsage] = field(default_factory=dict)


def compute_requirements_hash(path: Path) -> str:
    """Return the SHA-256 hex digest of the UTF-8 encoded contents of path.

    Args:
        path: Path to the requirements file to hash.

    Returns:
        Lowercase hex-encoded SHA-256 digest (64 characters).
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc_now() -> str:
    """Return the current UTC time as an ISO 8601 string with ``Z`` suffix."""
    return datetime.now(tz=UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


# Keep internal alias so existing call sites using the underscore name still work.
_utc_now = utc_now


def _issue_from_dict(d: dict) -> IssueState:  # type: ignore[type-arg]
    return IssueState(
        number=d["number"],
        status=d["status"],
        agent=d["agent"],
        labels=d.get("labels", []),
        reviewed=d.get("reviewed", False),
    )


def _effort_hint_from_dict(d: dict) -> EffortHint:  # type: ignore[type-arg]
    return EffortHint(scope_keyword=d["scope_keyword"], effort=d["effort"])  # type: ignore[arg-type]


def _token_usage_from_dict(raw: dict) -> dict[str, TokenUsage]:  # type: ignore[type-arg]
    """Deserialize a raw token_usage dict to ``dict[str, TokenUsage]``.

    Each value is expected to be a dict with the four token counter keys.
    Missing keys default to 0, matching ``TokenUsage`` field defaults.

    Args:
        raw: Mapping of phase id → token counter dict (e.g. from JSON).

    Returns:
        Mapping of phase id → ``TokenUsage`` instances.
    """
    return {
        phase: TokenUsage(
            input=v.get("input", 0),
            output=v.get("output", 0),
            cache_read=v.get("cache_read", 0),
            cache_write=v.get("cache_write", 0),
        )
        for phase, v in raw.items()
    }


def _cycle_from_dict(d: dict) -> CycleState:  # type: ignore[type-arg]
    return CycleState(
        id=d["id"],
        name=d["name"],
        milestone_number=d.get("milestone_number"),
        milestone_title=d["milestone_title"],
        status=d["status"],
        phase=d["phase"],
        issues=[_issue_from_dict(i) for i in d.get("issues", [])],
        commit_sha=d.get("commit_sha"),
        depends_on=d.get("depends_on", []),
        scope=d.get("scope", ""),
        effort_hints=[_effort_hint_from_dict(h) for h in d.get("effort_hints", [])],
        base_commit=d.get("base_commit"),
        token_usage=_token_usage_from_dict(d.get("token_usage", {})),
        started_at=d.get("started_at"),
        finished_at=d.get("finished_at"),
    )


def load_state(path: Path) -> State:
    """Load state from path, or return a fresh default when the file is missing.

    Args:
        path: Location of state.json (need not exist).

    Returns:
        Deserialized State, or a default single-mode State if the file is absent.
    """
    if not path.exists():
        now = _utc_now()
        return State(mode="unknown", started_at=now, updated_at=now)

    raw = json.loads(path.read_text(encoding="utf-8"))
    return State(
        mode=raw["mode"],
        started_at=raw["started_at"],
        updated_at=raw["updated_at"],
        current_cycle=raw.get("current_cycle"),
        cycles=[_cycle_from_dict(c) for c in raw.get("cycles", [])],
        phase=raw.get("phase"),
        issues=[_issue_from_dict(i) for i in raw.get("issues", [])],
        session_id=raw.get("session_id"),
        paused_until=raw.get("paused_until"),
        rate_limit_type=raw.get("rate_limit_type"),
        last_error=raw.get("last_error"),
        effort_hints=[_effort_hint_from_dict(h) for h in raw.get("effort_hints", [])],
        requirements_hash=raw.get("requirements_hash"),
        base_commit=raw.get("base_commit"),
        token_usage=_token_usage_from_dict(raw.get("token_usage", {})),
    )


def save_state(path: Path, state: State) -> None:
    """Atomically persist state to path.

    Updates state.updated_at, serializes to JSON with 2-space indentation,
    writes to a sibling .tmp file, then replaces the target via os.replace()
    so no partial write is ever visible.

    Args:
        path: Destination for state.json.
        state: State object to persist.
    """
    state.updated_at = _utc_now()
    path.parent.mkdir(parents=True, exist_ok=True)

    tmp = Path(str(path) + ".tmp")
    data = json.dumps(dataclasses.asdict(state), indent=2)
    tmp.write_text(data, encoding="utf-8")
    os.replace(tmp, path)


def mark_paused(
    state: State,
    *,
    resets_at: int,
    rate_limit_type: str,
    session_id: str | None,
) -> None:
    """Record a rate-limit pause in the state object (in-memory only).

    Caller must call save_state() afterwards to persist.

    Args:
        state: State to mutate.
        resets_at: Unix timestamp when the rate-limit window resets.
        rate_limit_type: Identifier for the type of rate limit hit.
        session_id: SDK session ID to resume from, if available.
    """
    state.paused_until = resets_at
    state.rate_limit_type = rate_limit_type
    state.session_id = session_id


def clear_pause(state: State) -> None:
    """Clear pause fields after the rate-limit window has passed.

    Args:
        state: State to mutate in place.
    """
    state.paused_until = None
    state.rate_limit_type = None


def is_paused(state: State, *, now: float | None = None) -> bool:
    """Return True when the state indicates an active rate-limit pause.

    Args:
        state: State to inspect.
        now: Override for the current time (seconds since epoch). Defaults to
            time.time() when omitted.

    Returns:
        True if paused_until is set and lies in the future.
    """
    if state.paused_until is None:
        return False
    return state.paused_until > (now if now is not None else time.time())


def _effort_hints_from_raw(raw: list[Any]) -> list[EffortHint]:
    """Convert a raw list of hint dicts to EffortHint objects, skipping invalid entries.

    Args:
        raw: List of dicts, each expected to have ``scope_keyword`` and ``effort`` keys.

    Returns:
        List of ``EffortHint`` instances; entries with missing keys are silently dropped.
    """
    hints = []
    for item in raw:
        if isinstance(item, dict) and "scope_keyword" in item and "effort" in item:
            hints.append(EffortHint(scope_keyword=item["scope_keyword"], effort=item["effort"]))  # type: ignore[arg-type]
    return hints


def append_new_cycles(state: State, raw_cycles: list[dict[str, Any]]) -> list[CycleState]:
    """Build new CycleState objects for scopes not yet in state.cycles.

    Phase 0 raw cycle IDs (typically 1-based) are remapped to actual IDs
    starting from ``max(existing_ids) + 1``. All ``depends_on`` references are
    remapped through the same mapping so cross-cycle dependencies remain
    consistent after the merge.

    Cycles whose ``scope`` already exists in ``state.cycles`` are silently
    skipped, making the operation idempotent — calling it twice with the same
    input produces no duplicates.

    Args:
        state: Current state with existing cycles (not mutated).
        raw_cycles: Raw cycle dicts from Phase 0 output (list of dicts with
            ``id``, ``scope``, ``name``, ``milestone_title``, ``depends_on``).

    Returns:
        List of new :class:`CycleState` objects (not yet appended to
        ``state.cycles``). Caller must extend ``state.cycles`` if desired.
    """
    existing_by_scope: dict[str, CycleState] = {c.scope: c for c in state.cycles}
    max_id = max((c.id for c in state.cycles), default=0)

    # Build ID remap: Phase 0 raw id → actual state id.
    id_remap: dict[int, int] = {}
    next_id = max_id + 1
    for idx, raw in enumerate(raw_cycles):
        raw_id = int(raw.get("id", idx + 1))
        scope = str(raw.get("scope", ""))
        if scope in existing_by_scope:
            id_remap[raw_id] = existing_by_scope[scope].id
        else:
            id_remap[raw_id] = next_id
            next_id += 1

    new_cycles: list[CycleState] = []
    for idx, raw in enumerate(raw_cycles):
        raw_id = int(raw.get("id", idx + 1))
        scope = str(raw.get("scope", ""))
        if scope in existing_by_scope:
            continue
        actual_id = id_remap[raw_id]
        raw_deps: list[int] = raw.get("depends_on", [])
        depends_on = [id_remap.get(d, d) for d in raw_deps]
        new_cycles.append(
            CycleState(
                id=actual_id,
                name=str(raw.get("name", f"Cycle {actual_id}")),
                milestone_number=None,
                milestone_title=str(raw.get("milestone_title", f"Cycle {actual_id}")),
                status="open",
                phase=0,
                issues=[],
                commit_sha=None,
                depends_on=depends_on,
                scope=scope,
                effort_hints=_effort_hints_from_raw(raw.get("effort_hints", [])),
            )
        )
    return new_cycles


def get_issues(state: State, cycle: CycleState | None) -> list[IssueState]:
    """Return the list of issues for the active scope, sorted ascending by number.

    Phase 1 already writes ``state.issues`` / ``cycle.issues`` in ascending
    order, but Phase 5 appends fix-issues mid-cycle from ``gh.list_issues()``
    which defaults to descending-by-number. A defensive sort here guarantees
    that every downstream phase (2, 3/4, 6, 7) iterates issues from lowest
    to highest number regardless of insertion order.

    Args:
        state: Root state.
        cycle: Active cycle or ``None`` for single-cycle mode.

    Returns:
        A new list of :class:`IssueState` sorted by ``number`` ascending.
        Callers that need to mutate the underlying list should access
        ``state.issues`` / ``cycle.issues`` directly.
    """
    source = cycle.issues if cycle is not None else state.issues
    return sorted(source, key=lambda issue: issue.number)
