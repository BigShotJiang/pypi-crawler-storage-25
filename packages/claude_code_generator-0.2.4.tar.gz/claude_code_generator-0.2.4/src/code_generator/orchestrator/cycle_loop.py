"""Multi-cycle driver: single-mode and multi-cycle orchestration loops.

Implements the phase 1→7 execution in dependency order for multi-cycle mode.
Each cycle gets a fresh SDK session (non-negotiable #6: no ``options.resume``
across cycle boundaries).

Topological iteration:
    A cycle is eligible when all its ``depends_on`` cycle IDs have
    ``status == "completed"``. The loop iterates until no further eligible
    cycles remain. Cycles with unmet dependencies after all eligible ones are
    exhausted remain as ``"open"``.
"""

from __future__ import annotations

import logging
import shutil
from typing import TYPE_CHECKING

from code_generator import gh, git_ops
from code_generator import state as _state
from code_generator.logging_setup import setup_phase_logger
from code_generator.orchestrator import (
    phase1_plan,
    phase2_review,
    phase3_4_implement,
    phase5_closure,
    phase6_test,
    phase7_commit,
)

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import CycleState, State


# Canonical phase numbers in execution order.
# Phase 3 and 4 are combined into a single implementation phase; the canonical
# boundary stored in state is 4 (the upper bound of the combined phase).
# These constants are used in guard conditions and state updates so that both
# locations stay in sync and no magic numbers appear in the code.
_PHASE_PLAN = 1
_PHASE_REVIEW = 2
_PHASE_IMPLEMENT = 4  # Combined phases 3+4; upper bound is 4.
_PHASE_CLOSURE = 5
_PHASE_TEST = 6
_PHASE_COMMIT = 7


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _eligible_cycles(state: State, completed_ids: set[int]) -> list[CycleState]:
    """Return cycles whose dependencies are all completed and which are open.

    Args:
        state: Root state with ``cycles`` list.
        completed_ids: Set of cycle IDs already completed this run.

    Returns:
        List of :class:`~code_generator.state.CycleState` objects that are
        eligible to run (open + all deps satisfied).
    """
    return [
        c
        for c in state.cycles
        if c.status == "open" and all(dep in completed_ids for dep in c.depends_on)
    ]


def _archive_cycle_logs(project_dir: Path, cycle_id: int) -> None:
    """Move completed cycle log files into a per-cycle subdirectory.

    Finds all files matching ``cycle{cycle_id}_*.log`` inside
    ``.code-generator/logs/`` and moves them to
    ``.code-generator/logs/cycle-{cycle_id}/``.  Existing files in the
    destination are overwritten.  A missing source match is a no-op.

    Args:
        project_dir: Root directory of the project being generated.
        cycle_id: Numeric ID of the cycle whose logs are to be archived.
    """
    logs_dir = project_dir / ".code-generator" / "logs"
    matches = [f for f in logs_dir.glob("*.log") if f.name.startswith(f"cycle{cycle_id}_")]
    if not matches:
        return
    dest_dir = logs_dir / f"cycle-{cycle_id}"
    dest_dir.mkdir(parents=True, exist_ok=True)
    for log_file in matches:
        shutil.move(str(log_file), str(dest_dir / log_file.name))


def _capture_base_commit(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    state_path: Path,
) -> None:
    """Capture HEAD SHA as base_commit before Phase 3/4, if not already set.

    Idempotent: a ``--continue`` resume that finds ``base_commit`` already
    set will not overwrite it.  A :class:`~code_generator.git_ops.GitError`
    is logged as a warning and the cycle continues without a baseline.

    Args:
        state: Root state (mutated in place).
        cycle: Active cycle, or ``None`` for single-mode.
        project_dir: Project root directory.
        state_path: Path to ``state.json`` for atomic persistence.
    """
    target = cycle if cycle is not None else state
    if target.base_commit is not None:
        return
    try:
        target.base_commit = git_ops.git_rev_parse_head(project_dir)
        _state.save_state(state_path, state)
    except git_ops.GitError:
        logging.getLogger(__name__).warning(
            "Could not capture base_commit: project_dir=%s is not a git repo or has no commits.",
            project_dir,
        )


# ---------------------------------------------------------------------------
# Shared phase sequence runner
# ---------------------------------------------------------------------------


async def _run_phases(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    runner_module: RunnerProtocol,
    log_prefix: str,
    start_phase: int,
) -> None:
    """Execute phases 1→7 for single-mode or a cycle, eliminating duplication.

    Handles the full phase-sequence including phase 5's fix re-entry.  The
    caller supplies ``log_prefix`` so logger names remain distinct between
    single-mode (``"phase1"``, …) and per-cycle runs
    (``"cycle{id}_phase1"``, …).

    Args:
        state: Root state object (mutated in place).
        cycle: Active cycle, or ``None`` for single-mode.
        project_dir: Project root directory.
        runner_module: Runner module returned by ``get_runner()``.
        log_prefix: Prepended to every phase logger name.  Use ``""`` for
            single-mode and ``f"cycle{cycle.id}_"`` for per-cycle runs.
        start_phase: First phase to execute; earlier phases are skipped.
    """
    state_path = project_dir / ".code-generator" / "state.json"

    def _phase_logger(name: str):  # type: ignore[return]
        return setup_phase_logger(f"{log_prefix}{name}", project_dir)

    def _set_phase(n: int) -> None:
        if cycle is not None:
            cycle.phase = n
        else:
            state.phase = n

    def _clear_error_and_save() -> None:
        """Reset stale error markers and persist state after a successful phase."""
        state.last_error = None
        state.rate_limit_type = None
        _state.save_state(state_path, state)

    if start_phase <= _PHASE_PLAN:
        await phase1_plan.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase1"),
        )
        _set_phase(_PHASE_PLAN)
        _clear_error_and_save()

    if start_phase <= _PHASE_REVIEW:
        await phase2_review.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase2"),
        )
        _set_phase(_PHASE_REVIEW)
        _clear_error_and_save()

    if start_phase <= _PHASE_IMPLEMENT:
        _capture_base_commit(state, cycle, project_dir, state_path)
        await phase3_4_implement.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase3_4"),
        )
        _set_phase(_PHASE_IMPLEMENT)
        _clear_error_and_save()

    if start_phase <= _PHASE_CLOSURE:
        fix_result = await phase5_closure.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase5"),
        )
        _set_phase(_PHASE_CLOSURE)
        _clear_error_and_save()
        # Re-enter implementation for any fix issues detected by phase 5.
        if fix_result.new_issues:
            await phase3_4_implement.run(
                state,
                cycle,
                project_dir,
                runner_module=runner_module,
                logger=_phase_logger("phase3_4_fix"),
            )
            _clear_error_and_save()

    if start_phase <= _PHASE_TEST:
        await phase6_test.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase6"),
        )
        _set_phase(_PHASE_TEST)
        _clear_error_and_save()

    if start_phase <= _PHASE_COMMIT:
        await phase7_commit.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase7"),
        )
        _set_phase(_PHASE_COMMIT)
        _clear_error_and_save()


# ---------------------------------------------------------------------------
# Single-mode driver
# ---------------------------------------------------------------------------


async def run_single_mode(
    state: State,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    start_phase: int = 1,
) -> State:
    """Execute the single-mode pipeline: phases 1→7.

    Non-negotiable #6 is respected by phase 3/4, which clears ``session_id``
    before each issue. This function itself does not set ``options.resume``.

    Args:
        state: Root state object (mutated in place and returned).
        project_dir: Project root directory.
        runner_module: Runner module returned by ``get_runner()``.
        logger: Optional phase logger; one is created when omitted.
        start_phase: First phase to execute. Phases below this number are
            skipped. Defaults to 1 (full run).

    Returns:
        The mutated state.

    Raises:
        OverageAbort: Propagated unchanged from any phase.
        RateLimitHit: Propagated unchanged from any phase.
        TestsFailed: When phase 6 reports persistent test failures.
        CircuitOpen: When phase 2's circuit breaker trips.
    """
    log = logger or setup_phase_logger("cycle_loop", project_dir)
    log.info("run_single_mode: start_phase=%d", start_phase)

    await _run_phases(
        state,
        None,
        project_dir,
        runner_module,
        log_prefix="",
        start_phase=start_phase,
    )

    log.info("run_single_mode: complete")
    return state


# ---------------------------------------------------------------------------
# Multi-cycle driver
# ---------------------------------------------------------------------------


async def run_multi_cycle(
    state: State,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    start_cycle: int | None = None,
    start_phase: int = 1,
) -> State:
    """Execute cycles in dependency order, each with a fresh SDK session.

    Eligible cycles are those whose ``depends_on`` cycle IDs are all
    ``"completed"``. The loop keeps running until no further eligible
    cycles remain.

    Non-negotiable #6: ``state.session_id`` is set to ``None`` at the entry
    of every cycle and persisted before any phase runs.

    Args:
        state: Root state object (mutated in place and returned).
        project_dir: Project root directory.
        runner_module: Runner module returned by ``get_runner()``.
        logger: Optional phase logger; one is created when omitted.
        start_cycle: When set, cycles with ``id < start_cycle`` are skipped
            even if their dependencies are not completed. The phase resume
            applies only to the *first* eligible cycle visited.
        start_phase: Resume from this phase in the first eligible cycle.
            Subsequent cycles always start at phase 1.

    Returns:
        The mutated state.

    Raises:
        OverageAbort: Propagated unchanged — stops all cycles.
        RateLimitHit: Propagated unchanged — stops all cycles.
        TestsFailed: When phase 6 fails — stops remaining cycles.
        CircuitOpen: Propagated unchanged — stops all cycles.
    """
    log = logger or setup_phase_logger("cycle_loop", project_dir)
    state_path = project_dir / ".code-generator" / "state.json"

    resumed_from = None
    if start_cycle is not None:
        current_cycle_record = next((c for c in state.cycles if c.id == start_cycle), None)
        if current_cycle_record is not None:
            resumed_from = current_cycle_record.phase

    log.info(
        "run_multi_cycle: start_cycle=%s start_phase=%d total_cycles=%d resumed_from=%s",
        start_cycle,
        start_phase,
        len(state.cycles),
        f"state.cycles[{start_cycle - 1}].phase={resumed_from}"
        if start_cycle is not None
        else None,
    )

    # Track which cycles have been completed during this run.
    completed_ids: set[int] = {c.id for c in state.cycles if c.status == "completed"}

    is_first_eligible = True

    while True:
        eligible = _eligible_cycles(state, completed_ids)
        if not eligible:
            break

        for cycle in eligible:
            # Honor --cycle N: skip cycles below the requested start.
            if start_cycle is not None and cycle.id < start_cycle:
                log.info("Skipping cycle %d (below start_cycle=%d).", cycle.id, start_cycle)
                # Mark as completed so dependent cycles can run.
                cycle.status = "completed"
                completed_ids.add(cycle.id)
                # Non-negotiable #7: persist every state mutation immediately.
                _state.save_state(state_path, state)
                continue

            # Non-negotiable #6: fresh session at every cycle entry.
            state.session_id = None
            state.current_cycle = cycle.id
            _state.save_state(state_path, state)

            log.info("Starting cycle %d (%s).", cycle.id, cycle.name)

            # Record wall-clock start; idempotent so --continue does not overwrite.
            if cycle.started_at is None:
                cycle.started_at = _state.utc_now()
                _state.save_state(state_path, state)

            # start_phase applies only to the first cycle we actually run.
            effective_start_phase = start_phase if is_first_eligible else 1
            is_first_eligible = False

            try:
                await _run_cycle_phases(
                    state=state,
                    cycle=cycle,
                    project_dir=project_dir,
                    runner_module=runner_module,
                    log=log,
                    start_phase=effective_start_phase,
                )
            except Exception as exc:
                cycle.finished_at = _state.utc_now()
                cycle.status = "failed"
                state.last_error = str(exc)
                _state.save_state(state_path, state)
                log.error(
                    "Cycle %d (%s) failed: %s. Aborting further cycles.",
                    cycle.id,
                    cycle.name,
                    exc,
                )
                raise

            # Cycle succeeded.
            cycle.status = "completed"
            cycle.finished_at = _state.utc_now()
            completed_ids.add(cycle.id)
            _archive_cycle_logs(project_dir, cycle.id)

            # Close the milestone for this cycle.
            if cycle.milestone_number is not None:
                try:
                    gh.close_milestone(cycle.milestone_number)
                    log.info(
                        "Closed milestone #%d for cycle %d.",
                        cycle.milestone_number,
                        cycle.id,
                    )
                except gh.GhError as exc:
                    log.warning(
                        "Could not close milestone #%d: %s",
                        cycle.milestone_number,
                        exc,
                    )

            _state.save_state(state_path, state)
            log.info("Cycle %d (%s) completed.", cycle.id, cycle.name)

    log.info("run_multi_cycle: all eligible cycles complete.")
    return state


# ---------------------------------------------------------------------------
# Per-cycle phase runner
# ---------------------------------------------------------------------------


async def _run_cycle_phases(
    state: State,
    cycle: CycleState,
    project_dir: Path,
    runner_module: RunnerProtocol,
    log: logging.Logger,
    start_phase: int,
) -> None:
    """Run phases 1→7 for a single cycle.

    Delegates to :func:`_run_phases` with a cycle-scoped logger prefix so
    log output for each cycle is clearly namespaced (e.g. ``cycle1_phase1``).

    Args:
        state: Root state (mutated in place).
        cycle: The active cycle being executed.
        project_dir: Project root directory.
        runner_module: Runner module.
        log: Logger for cycle-level messages (start / complete).
        start_phase: First phase to execute (1 = full, higher = resume).
    """
    await _run_phases(
        state,
        cycle,
        project_dir,
        runner_module,
        log_prefix=f"cycle{cycle.id}_",
        start_phase=start_phase,
    )
    log.info("Cycle %d phases 1-7 complete.", cycle.id)
