"""Shared comment-fetching helpers for phase orchestrators.

Centralises the duplicated ``gh.view_issue`` + ``GhError`` fallback logic
that previously lived independently in phase2, phase3_4, and phase5.

Public API
----------
fetch_issue_comments(number, logger) -> list[dict]
    Fetch raw comment dicts for one issue; returns [] on GhError.

fetch_formatted_comments(number, logger) -> str
    Convenience wrapper: raw comments → formatted markdown section.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from code_generator import gh
from code_generator.prompts import format_comments

if TYPE_CHECKING:
    import logging

__all__ = ["fetch_formatted_comments", "fetch_issue_comments"]


def fetch_issue_comments(
    number: int,
    logger: logging.Logger,
) -> list[dict]:  # type: ignore[type-arg]
    """Fetch raw comment dicts for *number*; return empty list on GhError.

    Args:
        number: GitHub issue number.
        logger: Logger for warnings when the gh call fails.

    Returns:
        List of comment dicts extracted from the issue data, or ``[]``
        when :class:`~code_generator.gh.GhError` is raised.
    """
    try:
        issue_data = gh.view_issue(number)
        return issue_data.get("comments", [])
    except gh.GhError as exc:
        logger.warning(
            "Could not fetch comments for issue #%d: %s. Continuing with empty comments.",
            number,
            exc,
        )
        return []


def fetch_formatted_comments(
    number: int,
    logger: logging.Logger,
) -> str:
    """Fetch and format issue comments as a markdown section.

    Calls :func:`fetch_issue_comments` then passes the result through
    :func:`~code_generator.prompts.format_comments`.

    Args:
        number: GitHub issue number.
        logger: Logger forwarded to :func:`fetch_issue_comments`.

    Returns:
        Formatted ``## Issue Comments`` markdown section, or ``""`` when
        no comments exist or the gh call fails.
    """
    comments = fetch_issue_comments(number, logger)
    return format_comments(comments)
