"""Orchestrator package — one module per pipeline phase.

Phase modules expose a single async ``run(...)`` coroutine each.
"""
