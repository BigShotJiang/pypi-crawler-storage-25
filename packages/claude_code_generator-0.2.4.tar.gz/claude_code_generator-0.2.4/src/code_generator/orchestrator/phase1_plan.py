"""Phase 1 — Planning: milestone creation and issue seeding.

Uses Opus 4.6 to read the requirements and create GitHub Issues
(via Bash tool calls inside the SDK session).

Non-negotiable #8: model is hard-coded to ``claude-opus-4-6``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from code_generator import effort as _effort
from code_generator import gh
from code_generator import state as _state
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit
from code_generator.runner.options import make_agent_options

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import CycleState, State


class Phase1NoIssuesError(RuntimeError):
    """Phase 1 completed but created zero GitHub issues — abort the pipeline."""


def _deduplicate_by_title(issues: list[dict[str, Any]]) -> list[dict[str, Any]]:  # type: ignore[type-arg]
    """Return only the lowest-numbered issue per case-insensitive stripped title.

    Args:
        issues: List of issue dicts already sorted by number (ascending).

    Returns:
        Deduplicated list preserving the lowest-numbered entry per title.
    """
    seen: set[str] = set()
    unique: list[dict[str, Any]] = []  # type: ignore[type-arg]
    for issue in issues:
        key = issue.get("title", "").strip().lower()
        if key not in seen:
            seen.add(key)
            unique.append(issue)
    return unique


def _build_issue_states(raw_issues: list[dict[str, Any]]) -> list[_state.IssueState]:  # type: ignore[type-arg]
    """Convert raw gh issue dicts into IssueState objects.

    Deduplicates by title (case-insensitive, stripped) as a defense-in-depth
    measure: if the planning session created duplicate issues, only the
    lowest-numbered entry per title is kept.

    Args:
        raw_issues: List of dicts as returned by ``gh.list_issues()``.

    Returns:
        List of :class:`~code_generator.state.IssueState` instances.
    """
    sorted_issues = sorted(raw_issues, key=lambda i: i["number"])
    unique_issues = _deduplicate_by_title(sorted_issues)
    return [
        _state.IssueState(
            number=issue["number"],
            status="open",
            agent=gh.agent_from_labels(issue.get("labels", [])),
            labels=[lbl.get("name", "") for lbl in issue.get("labels", []) if lbl.get("name")],
        )
        for issue in unique_issues
    ]


def _fetch_existing_issues(milestone_title: str | None) -> list[dict[str, Any]]:  # type: ignore[type-arg]
    """Fetch all issues in the given milestone, or return empty list for single-mode.

    Args:
        milestone_title: Milestone name, or ``None`` for single-cycle mode.

    Returns:
        List of raw issue dicts (may be empty).
    """
    if milestone_title is None:
        return []
    return gh.list_issues(milestone=milestone_title, state="all")


def _format_existing_issues(issues: list[dict[str, Any]]) -> str:  # type: ignore[type-arg]
    """Format a list of raw issue dicts as a readable string for prompt injection.

    Args:
        issues: Raw issue dicts as returned by ``gh.list_issues()``.

    Returns:
        A newline-separated list of ``#N: title`` entries, or ``"none"`` when empty.
    """
    if not issues:
        return "none"
    return "\n".join(f"- #{i['number']}: {i['title']}" for i in issues)


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
) -> None:
    """Execute phase 1: planning.

    Seeds standard labels, optionally creates a milestone (multi-cycle),
    runs the planning prompt, then populates ``state.issues`` or
    ``cycle.issues`` from the newly-created GitHub issues.

    Args:
        state: Root state object (mutated in place).
        cycle: Active cycle (multi-cycle mode) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
    """
    if logger is None:
        logger = setup_phase_logger("phase1", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"

    # Seed standard label taxonomy — idempotent.
    gh.ensure_standard_labels()

    # Multi-cycle: create the milestone if not yet done.
    # Track whether the milestone was created in this run so we can clean it up on failure.
    milestone_title: str | None = None
    milestone_number_before: int | None = None
    if cycle is not None:
        milestone_title = cycle.milestone_title
        milestone_number_before = cycle.milestone_number
        if cycle.milestone_number is None:
            cycle.milestone_number = gh.create_milestone(
                cycle.milestone_title,
                cycle.scope,
            )
            logger.info("Created milestone %r → #%d", cycle.milestone_title, cycle.milestone_number)

    try:
        # Determine completed cycle names for the prompt.
        completed_cycles: str = "none"
        if state.cycles:
            completed = [c.name for c in state.cycles if c.status == "completed"]
            if completed:
                completed_cycles = ", ".join(completed)

        # Pre-fetch existing issues so the model can skip them on --continue.
        existing_issues = _fetch_existing_issues(milestone_title)

        prompt = load_prompt(
            "prompt-phase-1-planning.md",
            REQUIREMENTS_PATH=".code-generator/requirements.md",
            CYCLE_SCOPE=(
                cycle.scope
                if cycle is not None
                else "single-cycle — implement all features from requirements.md"
            ),
            MILESTONE_TITLE=milestone_title if milestone_title is not None else "",
            COMPLETED_CYCLES=completed_cycles,
            EXISTING_ISSUES=_format_existing_issues(existing_issues),
        )

        effort_level = _effort.resolve_effort(
            phase=1,
            complexity="",
            issue_labels=[],
            retry_count=0,
        )
        _effort.validate_effort(effort_level, "claude-opus-4-6")

        options = make_agent_options(
            model="claude-opus-4-6",
            effort=effort_level,
            allowed_tools=["Read", "Bash", "Glob", "Grep"],
            cwd=str(project_dir),
            max_turns=60,
        )

        result = await rate_limit.main_loop(
            runner_module,
            prompt,
            options,
            state_path=state_path,
            logger=logger,
        )

        # Fetch all issues in the milestone (open + closed) to support deduplication.
        raw_issues = gh.list_issues(
            milestone=milestone_title,
            state="all",
        )
        issue_states = _build_issue_states(raw_issues)

        if not issue_states:
            raise Phase1NoIssuesError(
                "Phase 1 finished without creating any GitHub issues. "
                "Opus likely misread the task (e.g. audited existing code instead "
                "of planning new work). Inspect .code-generator/logs/phase1.log, "
                "adjust prompt-phase-1-planning.md if needed, and re-run."
            )

        if cycle is not None:
            cycle.issues = issue_states
            cycle.token_usage["phase1"] = result.usage
        else:
            state.issues = issue_states
            state.token_usage["phase1"] = result.usage

        _state.save_state(state_path, state)
        log_phase_usage(logger, 1, result.usage)
        logger.info("Phase 1: %d issues created.", len(issue_states))

    except Exception:
        _cleanup_orphaned_milestone(cycle, milestone_number_before, logger)
        raise


def _cleanup_orphaned_milestone(
    cycle: CycleState | None,
    milestone_number_before: int | None,
    logger: logging.Logger,
) -> None:
    """Delete a milestone created in this run if Phase 1 fails before persisting issues.

    Only deletes if the milestone was created during this run (i.e., it was None before
    and is now set). Best-effort: logs a WARNING if deletion itself fails.

    Args:
        cycle: Active cycle, or None in single-cycle mode.
        milestone_number_before: The milestone number before this run started (None = just created).
        logger: Phase logger for WARNING output.
    """
    if cycle is None or cycle.milestone_number is None or milestone_number_before is not None:
        return
    try:
        gh.delete_milestone(cycle.milestone_number)
    except Exception as cleanup_exc:
        logger.warning(
            "Failed to delete orphaned milestone #%d during Phase 1 cleanup: %s",
            cycle.milestone_number,
            cleanup_exc,
        )
