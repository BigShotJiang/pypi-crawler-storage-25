"""Phases 3 & 4 — Implementation loop (TDD, fresh session per issue).

Each open issue gets its own SDK session (non-negotiable #6: no ``resume``).
The issue agent is taken from state; skills default to ``solid-principles``
augmented by whatever ``agents.detect()`` returns for the requirements file.

Non-negotiable #8: model is hard-coded to ``claude-sonnet-4-6``.
"""

from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING

from code_generator import agents as _agents
from code_generator import effort as _effort
from code_generator import gh as _gh
from code_generator import state as _state
from code_generator.logging_setup import log_issue_usage, log_phase_usage, setup_phase_logger
from code_generator.orchestrator._comments import fetch_formatted_comments
from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit
from code_generator.runner.options import make_agent_options
from code_generator.runner.retry import TransientRunnerError
from code_generator.runner.types import MaxTurnsExceeded, OverageAbort, RateLimitHit, TokenUsage

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import CycleState, State


def _find_effort_hint(
    hints: list[_state.EffortHint],
    labels: list[str],
) -> _effort.EffortLevel | None:
    """Return effort from the first hint whose scope_keyword appears in any label.

    Args:
        hints: Effort hints from state or cycle (Phase 0 output).
        labels: GitHub label names attached to the current issue.

    Returns:
        Matching EffortLevel, or ``None`` when no hint matches.
    """
    for hint in hints:
        if any(hint.scope_keyword in label for label in labels):
            return _effort.EffortLevel(hint.effort)
    return None


def _default_skills(project_dir: Path) -> str:
    """Derive skill names from the requirements file (or use generic fallback).

    Args:
        project_dir: Project root; the requirements file lives at
            ``<project_dir>/.code-generator/requirements.md``.

    Returns:
        Comma-joined skill names string.
    """
    req_path = project_dir / ".code-generator" / "requirements.md"
    selection = _agents.detect(req_path)
    skills = selection.skills or ("solid-principles",)
    return ",".join(skills)


def _build_prompt(
    issue: _state.IssueState,
    skills: str,
    comments_section: str,
    attempt: int,
    last_err: str,
) -> str:
    """Build the implementation prompt for one attempt.

    Args:
        issue: The issue being implemented.
        skills: Comma-joined skill names.
        comments_section: Pre-formatted issue comments.
        attempt: Zero-based attempt index (0 = first try).
        last_err: Error message from the previous attempt (empty on first try).

    Returns:
        The prompt string to pass to the runner.
    """
    agent = issue.agent or "python-pro"
    base = load_prompt(
        "prompt-phase-3-implementation.md",
        ISSUE_NUMBER=str(issue.number),
        PRIMARY_AGENT=agent,
        SKILLS=skills,
        ISSUE_COMMENTS=comments_section,
    )
    if attempt > 0:
        return f"{base}\n\nPrevious attempt failed: {last_err}. Be more explicit this time."
    return base


def _resolve_issue_effort(
    issue: _state.IssueState,
    effort_hints: list[_state.EffortHint],
    attempt: int,
    complexity: str,
) -> _effort.EffortLevel | None:
    """Resolve and validate the effort level for an issue attempt.

    Args:
        issue: The issue being implemented.
        effort_hints: Effort hints from state or cycle (Phase 0 output).
        attempt: Zero-based attempt index.
        complexity: Project complexity string from state (e.g. ``"single"``,
            ``"multi-cycle"``, ``"unknown"``).  Must be non-empty for phase 4
            when ``attempt == 0`` and no effort hint is found.

    Returns:
        Validated EffortLevel.

    Raises:
        ValueError: When the resolved effort is incompatible with the model.
        InvalidEffortInput: When complexity is empty and no override is available.
    """
    effort_hint = _find_effort_hint(effort_hints, issue.labels)
    effort_level = _effort.resolve_effort(
        phase=4,
        complexity=complexity,
        issue_labels=issue.labels,
        retry_count=attempt,
        effort_hint=effort_hint,
    )
    _effort.validate_effort(effort_level, "claude-sonnet-4-6")
    return effort_level


def _verify_issue_closed(issue_number: int, logger: logging.Logger) -> None:
    """Defense-in-depth: confirm GitHub reports the issue as closed.

    Args:
        issue_number: GitHub issue number to verify.
        logger: Phase logger for warnings.

    Raises:
        TransientRunnerError: When the issue is still open after a successful run.
    """
    try:
        gh_state = _gh.issue_state(issue_number)
    except _gh.GhError as gh_exc:
        logger.warning(
            "Phase 3/4: could not verify issue #%d state on GitHub: %s. Proceeding on trust.",
            issue_number,
            gh_exc,
        )
        return
    if gh_state != "closed":
        raise TransientRunnerError(
            f"Phase 3/4: main_loop returned success but issue "
            f"#{issue_number} is still {gh_state!r} on GitHub."
        )


async def _implement_single_issue(
    issue: _state.IssueState,
    state: State,
    state_path: Path,
    skills: str,
    effort_hints: list[_state.EffortHint],
    project_dir: Path,
    runner_module: RunnerProtocol,
    logger: logging.Logger,
    max_retries: int,
) -> tuple[bool, TokenUsage]:
    """Run the retry loop for a single issue.

    Args:
        issue: The issue to implement.
        state: Root state object (mutated in place).
        state_path: Absolute path to state.json.
        skills: Comma-joined skill names.
        effort_hints: Effort hints for effort resolution.
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Phase logger.
        max_retries: Maximum number of attempts.

    Returns:
        ``(success, issue_total)`` where ``success`` is ``True`` if the issue
        was implemented and ``issue_total`` is the accumulated token usage
        across all attempts (zero for exception-only paths).
    """
    comments_section = fetch_formatted_comments(issue.number, logger)
    issue_total = TokenUsage()
    last_err = ""
    for attempt in range(max_retries):
        # Non-negotiable #6: fresh session per attempt — never accumulate context.
        state.session_id = None
        _state.save_state(state_path, state)
        prompt = _build_prompt(issue, skills, comments_section, attempt, last_err)
        effort_level = _resolve_issue_effort(issue, effort_hints, attempt, complexity=state.mode)
        options = make_agent_options(
            model="claude-sonnet-4-6",
            effort=effort_level,
            allowed_tools=["Read", "Edit", "Write", "Bash", "Glob", "Grep"],
            cwd=str(project_dir),
            max_turns=80,
        )
        try:
            result = await rate_limit.main_loop(
                runner_module, prompt, options, state_path=state_path, logger=logger
            )
            issue_total += result.usage
            _verify_issue_closed(issue.number, logger)
            return True, issue_total
        except (OverageAbort, RateLimitHit):
            # Non-negotiable: these must propagate immediately — never retry.
            raise
        except MaxTurnsExceeded:
            # Deterministic failure — retrying will hit the same ceiling.
            logger.error(
                "Phase 3/4: issue #%d hit max_turns ceiling at attempt %d/%d"
                " — no retry (deterministic failure).",
                issue.number,
                attempt + 1,
                max_retries,
            )
            with contextlib.suppress(Exception):
                _gh.add_label(issue.number, "needs-manual-review")
            break
        except Exception as exc:  # noqa: BLE001
            last_err = str(exc)
            logger.warning(
                "Phase 3/4: attempt %d/%d failed for issue #%d: %s",
                attempt + 1,
                max_retries,
                issue.number,
                last_err,
            )
    return False, issue_total


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    max_retries: int = 3,
) -> None:
    """Execute phases 3 and 4: implementation loop.

    For each open issue delegates to ``_implement_single_issue`` which owns
    the per-issue retry loop.  On success the issue is marked ``closed`` in
    state; on failure an ERROR is logged and the issue is left open.

    Args:
        state: Root state object (mutated in place).
        cycle: Active cycle (multi-cycle) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
        max_retries: Maximum implementation retries per issue (default 3).
    """
    if logger is None:
        logger = setup_phase_logger("phase3_4", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"
    skills = _default_skills(project_dir)
    effort_hints = cycle.effort_hints if cycle is not None else state.effort_hints
    phase_total = TokenUsage()

    for issue in _state.get_issues(state, cycle):
        if issue.status != "open":
            continue
        agent = issue.agent or "python-pro"
        logger.info("Phase 3/4: implementing issue #%d (agent=%s).", issue.number, agent)
        success, issue_usage = await _implement_single_issue(
            issue,
            state,
            state_path,
            skills,
            effort_hints,
            project_dir,
            runner_module,
            logger,
            max_retries,
        )
        log_issue_usage(logger, "3/4", issue.number, issue_usage)
        phase_total += issue_usage
        if success:
            issue.status = "closed"
            state.session_id = None
            _state.save_state(state_path, state)
            logger.info("Phase 3/4: issue #%d closed.", issue.number)
        else:
            logger.error(
                "Phase 3/4: issue #%d could not be implemented after %d retries.",
                issue.number,
                max_retries,
            )

    target = cycle if cycle is not None else state
    target.token_usage["phase3_4"] = phase_total
    _state.save_state(state_path, state)
    log_phase_usage(logger, "3/4", phase_total)
