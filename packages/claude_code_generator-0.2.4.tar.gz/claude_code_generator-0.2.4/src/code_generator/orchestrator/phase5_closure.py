"""Phase 5 — Closure and cross-module review.

Runs Opus 4.6 to review the full codebase, close any straggling issues,
and optionally create new ``fix:`` issues.  After the session, re-fetches
open issues and returns a :class:`FixResult` so the orchestrator can
re-enter phases 3/4 for any newly-created fix issues.

Non-negotiable #8: model is hard-coded to ``claude-opus-4-6``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from code_generator import effort as _effort
from code_generator import gh, git_ops
from code_generator import state as _state
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.orchestrator._comments import fetch_issue_comments
from code_generator.prompts import format_comments, load_prompt
from code_generator.runner import rate_limit
from code_generator.runner.options import make_agent_options

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import CycleState, IssueState, State


@dataclass
class FixResult:
    """Returned by :func:`run` to signal new fix issues to the orchestrator.

    Attributes:
        new_issues: List of IssueState objects for issues created during
            phase 5 (identified by the ``fix:`` title prefix).
    """

    new_issues: list[IssueState] = field(default_factory=list)


def _format_issue_section(number: int, title: str, comments: list[dict]) -> str:  # type: ignore[type-arg]
    """Render a single issue as a markdown section with its comments.

    Args:
        number: Issue number.
        title: Issue title.
        comments: List of comment dicts.

    Returns:
        Markdown string with issue header and, when present, its comments.
    """
    header = f"### Issue #{number}: {title}"
    comment_text = format_comments(comments)
    return f"{header}\n\n{comment_text}" if comment_text else header


def _fetch_open_issues_with_comments(
    milestone_title: str | None,
    logger: logging.Logger,
) -> str:
    """Pre-fetch open issues with comments for prompt injection.

    Args:
        milestone_title: Milestone title to filter issues, or None for all.
        logger: Logger for warnings.

    Returns:
        Formatted markdown string with all open issues and their comments,
        or an empty string when no issues exist or GhError is raised.
    """
    try:
        issues = gh.list_issues(milestone=milestone_title, state="open", fields=["number", "title"])
    except gh.GhError as exc:
        logger.warning("Phase 5: could not pre-fetch open issues: %s", exc)
        return ""

    if not issues:
        return ""

    sections = [
        _format_issue_section(
            raw["number"],
            raw.get("title", ""),
            fetch_issue_comments(raw["number"], logger),
        )
        for raw in issues
    ]
    return "\n\n---\n\n".join(sections)


_DIFF_CAP_BYTES = 100 * 1024
_TRUNCATION_MARKER = "\n[TRUNCATED — diff exceeds 100KB]"


def fetch_diff_since_base(
    base_commit: str | None,
    project_dir: Path,
    logger: logging.Logger,
) -> str:
    """Return a pre-fetched diff string between *base_commit* and HEAD.

    Args:
        base_commit: Base commit SHA to diff against, or ``None``.
        project_dir: Project root directory.
        logger: Logger for warnings.

    Returns:
        Formatted string with stat summary and full diff, or empty string when
        *base_commit* is ``None`` or a :class:`~code_generator.git_ops.GitError`
        is raised.
    """
    if base_commit is None:
        return ""
    try:
        stat = git_ops.git_diff(project_dir, base_commit, stat=True)
        full = git_ops.git_diff(project_dir, base_commit)
    except git_ops.GitError as exc:
        logger.warning("Phase 5: could not fetch diff since base commit: %s", exc)
        return ""
    if len(full.encode()) > _DIFF_CAP_BYTES:
        full = full.encode()[:_DIFF_CAP_BYTES].decode(errors="replace") + _TRUNCATION_MARKER
    return f"{stat}\n---\n{full}"


def _known_numbers(state: State, cycle: CycleState | None) -> set[int]:
    """Return the set of issue numbers already in state/cycle.

    Args:
        state: Root state.
        cycle: Active cycle or ``None``.

    Returns:
        Set of known issue numbers.
    """
    issues = cycle.issues if cycle is not None else state.issues
    return {i.number for i in issues}


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
) -> FixResult:
    """Execute phase 5: overall review and closure.

    Args:
        state: Root state object (mutated in place).
        cycle: Active cycle (multi-cycle) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.

    Returns:
        :class:`FixResult` listing any new fix issues discovered after the
        session.  An empty list means no re-entry into phases 3/4 is needed.
    """
    if logger is None:
        logger = setup_phase_logger("phase5", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"
    milestone_title = cycle.milestone_title if cycle is not None else None
    base_commit = cycle.base_commit if cycle is not None else state.base_commit

    open_issues_section = _fetch_open_issues_with_comments(milestone_title, logger)
    diff_section = fetch_diff_since_base(base_commit, project_dir, logger)

    prompt = load_prompt(
        "prompt-phase-5-final-review.md",
        CYCLE_SCOPE=(
            cycle.scope
            if cycle is not None
            else "single-cycle — implement all features from requirements.md"
        ),
        MILESTONE_TITLE=milestone_title or "",
        OPEN_ISSUES_WITH_COMMENTS=open_issues_section,
        DIFF_SINCE_BASE=diff_section,
    )

    effort_level = _effort.resolve_effort(phase=5, complexity="", issue_labels=[], retry_count=0)
    _effort.validate_effort(effort_level, "claude-opus-4-6")

    options = make_agent_options(
        model="claude-opus-4-6",
        effort=effort_level,
        allowed_tools=["Read", "Bash", "Glob", "Grep"],
        cwd=str(project_dir),
        max_turns=80,
    )

    result = await rate_limit.main_loop(
        runner_module,
        prompt,
        options,
        state_path=state_path,
        logger=logger,
    )

    target = cycle if cycle is not None else state
    target.token_usage["phase5"] = result.usage
    _state.save_state(state_path, state)
    log_phase_usage(logger, 5, result.usage)

    # Re-fetch open issues to detect any new fix: issues.
    known = _known_numbers(state, cycle)

    try:
        open_issues = gh.list_issues(
            milestone=milestone_title, state="open", fields=["number", "labels"]
        )
    except gh.GhError as exc:
        logger.warning("Phase 5: could not list issues after session: %s", exc)
        return FixResult()

    new_issue_states: list[_state.IssueState] = []
    for raw in open_issues:
        num = raw["number"]
        if num in known:
            continue
        # Only pick up new issues — they may be fix: issues created by the session.
        new_state = _state.IssueState(
            number=num,
            status="open",
            agent=gh.agent_from_labels(raw.get("labels", [])),
            labels=[lbl.get("name", "") for lbl in raw.get("labels", []) if lbl.get("name")],
        )
        new_issue_states.append(new_state)

    if new_issue_states:
        # Append order may be descending (gh.list_issues() default); no sort
        # needed here because _state.get_issues() enforces ascending order
        # defensively at every read site.
        if cycle is not None:
            cycle.issues.extend(new_issue_states)
        else:
            state.issues.extend(new_issue_states)
        _state.save_state(state_path, state)
        logger.info("Phase 5: %d new fix issues detected.", len(new_issue_states))

    return FixResult(new_issues=new_issue_states)
