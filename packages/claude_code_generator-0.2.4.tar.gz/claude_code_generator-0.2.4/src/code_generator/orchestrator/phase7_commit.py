"""Phase 7 — Commit message generation and git push.

Uses Opus 4.6 to generate a commit message, then performs
``git add . → git commit -m <msg> → git push origin <branch>``
with one rebase-and-retry on push rejection.

Non-negotiable #8: model is hard-coded to ``claude-opus-4-6``.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from code_generator import effort as _effort
from code_generator import state as _state
from code_generator.git_ops import (
    GitError,
    git_add_all,
    git_commit,
    git_current_branch,
    git_diff_cached,
    git_has_staged,
    git_pull_rebase,
    git_push,
)
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.prompts import PromptError, load_prompt
from code_generator.runner import rate_limit
from code_generator.runner.options import make_agent_options

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import CycleState, IssueState, State


_DIFF_CAP_BYTES = 20 * 1024
_TRUNCATION_MARKER = "\n[TRUNCATED — exceeds 20KB]"

# Sentinel that must appear in the rendered Phase 7 prompt; guards against
# accidental removal of the Wrong-vs-Right hardening section (issue #142).
_PROMPT_HARDENING_SENTINEL = "Any character before the commit type is a bug"

# Prepended to the original prompt on the one-retry attempt after extraction
# failure.  Fresh SDK session, no resume field (issue #143).
_HARDENED_RETRY_PREFIX = (
    "CRITICAL: your previous response was rejected because it contained text "
    "before the commit type. Any character before the commit type is a bug.\n"
    "Output ONLY the commit message starting immediately with the commit type "
    "(e.g. feat:, fix:, chore:). No preamble. No explanation. No markdown fences.\n\n"
)

# ---------------------------------------------------------------------------
# Commit-message extraction — issue #140
# ---------------------------------------------------------------------------

_CONVENTIONAL_COMMIT_RE = re.compile(
    r"^(feat|fix|refactor|test|docs|chore|perf|build|ci|style|revert)(\([^)]+\))?!?: .+",
    re.MULTILINE,
)

# Opening fence: ``` optionally followed by a language tag (e.g. ```text).
_FENCE_OPEN_RE = re.compile(r"^\s*```\w*\s*$")

# Closing fence: bare ```.
_FENCE_CLOSE_RE = re.compile(r"^\s*```\s*$")


def _extract_commit_message(raw: str, fallback: str) -> str:
    """Extract a valid conventional-commit message from noisy model output.

    Algorithm (see issue #140 and its Phase 2 review comment):
    1. Strip the input.
    2. If the whole text is wrapped in a triple-backtick fence (first and last
       non-empty lines are fence markers), unwrap it.
    3. Search for the first conventional-commit line.  Slice from that position
       to the end of the string — everything before it is preamble.
    4. Post-slice fence cleanup: if any remaining line is a bare closing fence
       marker (``````), truncate at that line.
    5. Strip trailing whitespace.
    6. If step 3 found no match, return *fallback* verbatim.

    Args:
        raw: The raw text returned by the model.
        fallback: Returned verbatim when no conventional-commit line is found.

    Returns:
        Extracted commit message or *fallback*.
    """
    text = raw.strip()
    if not text:
        return fallback

    text = _unwrap_whole_message_fence(text)

    match = _CONVENTIONAL_COMMIT_RE.search(text)
    if not match:
        return fallback

    text = _truncate_at_fence(text[match.start() :])
    return text.rstrip()


def _unwrap_whole_message_fence(text: str) -> str:
    """Remove wrapping triple-backtick fence if the entire message is fenced."""
    lines = text.splitlines()
    non_empty = [line for line in lines if line.strip()]
    if len(non_empty) < 2:
        return text
    if not (_FENCE_OPEN_RE.match(non_empty[0]) and _FENCE_CLOSE_RE.match(non_empty[-1])):
        return text

    first_idx = next(i for i, line in enumerate(lines) if line.strip())
    last_idx = len(lines) - 1 - next(i for i, line in enumerate(reversed(lines)) if line.strip())
    return "\n".join(lines[first_idx + 1 : last_idx])


def _truncate_at_fence(text: str) -> str:
    """Drop the first bare closing-fence line and everything after it."""
    result_lines = text.splitlines()
    for i, line in enumerate(result_lines):
        if _FENCE_CLOSE_RE.match(line):
            return "\n".join(result_lines[:i])
    return text


# ---------------------------------------------------------------------------
# Commit-message fallback synthesis and validation — issue #141
# ---------------------------------------------------------------------------


class Phase7CommitMessageError(RuntimeError):
    """Raised when a commit message does not match the conventional-commit format."""


def _synthesize_fallback(cycle_name: str, issues_closed: str) -> str:
    """Build a deterministic conventional-commit message from orchestrator metadata.

    Args:
        cycle_name: Name of the active cycle (empty string for single mode).
        issues_closed: Comma-separated issue refs (e.g. ``"#1, #2"``) or ``"none"``.

    Returns:
        A valid conventional-commit string, optionally with a ``Closed issues`` footer.
    """
    scope = f"({cycle_name})" if cycle_name else ""
    subject = f"chore{scope}: cycle complete"
    if issues_closed == "none":
        return subject
    return f"{subject}\n\nClosed issues: {issues_closed}"


def _validate_commit_message(msg: str) -> None:
    """Assert that *msg* starts with a conventional-commit line.

    Args:
        msg: The commit message to validate.

    Raises:
        Phase7CommitMessageError: When the first line does not match the regex.
    """
    first_line = msg.split("\n", 1)[0]
    if not _CONVENTIONAL_COMMIT_RE.match(first_line):
        raise Phase7CommitMessageError(
            f"Commit message does not match conventional-commit format: {first_line!r}"
        )


def _assert_prompt_sentinel(prompt: str) -> None:
    """Fail fast if the hardening sentinel was removed from the Phase 7 prompt.

    Args:
        prompt: Rendered prompt text returned by ``load_prompt``.

    Raises:
        PromptError: When the sentinel substring is absent.
    """
    if _PROMPT_HARDENING_SENTINEL not in prompt:
        raise PromptError(
            f"prompt-phase-7-commit.md missing hardening sentinel: {_PROMPT_HARDENING_SENTINEL!r}"
        )


def _cap_output(text: str) -> str:
    """Return *text* capped at 20KB with a truncation marker."""
    if len(text.encode()) <= _DIFF_CAP_BYTES:
        return text
    return text[:_DIFF_CAP_BYTES] + _TRUNCATION_MARKER


def _closed_issue_numbers(state: State, cycle: CycleState | None) -> list[int]:
    """Collect issue numbers marked as closed in the current scope.

    Args:
        state: Root state.
        cycle: Active cycle or ``None`` for single mode.

    Returns:
        Sorted list of closed issue numbers.
    """
    issues: list[IssueState] = cycle.issues if cycle is not None else state.issues
    return sorted(i.number for i in issues if i.status == "closed")


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
) -> None:
    """Execute phase 7: commit and push.

    Steps:
    1. ``git add .``
    2. ``git diff --cached --quiet`` — skip when nothing staged.
    3. Run Opus 4.6 via the rate-limit loop to generate a commit message.
    4. ``git commit -m <msg>``
    5. ``git push origin <branch>``; on rejection: ``git pull --rebase
       && git push origin <branch>`` (one retry).

    Args:
        state: Root state object.
        cycle: Active cycle (multi-cycle) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
    """
    if logger is None:
        logger = setup_phase_logger("phase7", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"

    git_add_all(project_dir)

    if not git_has_staged(project_dir):
        logger.info("Phase 7: nothing staged — skipping commit and push.")
        return

    closed_numbers = _closed_issue_numbers(state, cycle)
    issues_closed = ", ".join(f"#{n}" for n in closed_numbers) if closed_numbers else "none"
    cycle_name = cycle.name if cycle is not None else ""

    staged_diff_stat = _cap_output(git_diff_cached(project_dir, stat=True))
    staged_files = _cap_output(git_diff_cached(project_dir, stat=False))

    prompt = load_prompt(
        "prompt-phase-7-commit.md",
        CYCLE_NAME=cycle_name,
        ISSUES_CLOSED=issues_closed,
        STAGED_DIFF_STAT=staged_diff_stat,
        STAGED_FILES=staged_files,
    )

    # Startup assertion — fail fast if prompt hardening was removed (issue #142).
    _assert_prompt_sentinel(prompt)

    effort_level = _effort.resolve_effort(
        phase=7,
        complexity=state.mode,
        issue_labels=[],
        retry_count=0,
    )
    _effort.validate_effort(effort_level, "claude-opus-4-6")

    options = make_agent_options(
        model="claude-opus-4-6",
        effort=effort_level,
        allowed_tools=["Read", "Bash"],
        cwd=str(project_dir),
        max_turns=10,
    )

    result = await rate_limit.main_loop(
        runner_module,
        prompt,
        options,
        state_path=state_path,
        logger=logger,
    )

    fallback = _synthesize_fallback(cycle_name, issues_closed)
    commit_msg = _extract_commit_message(result.text, fallback=fallback)

    if commit_msg == fallback:
        raw_head = result.text[:200]
        logger.error(
            "Phase 7: attempt 1/2 failed — extraction rejected model output; raw_head=%r",
            raw_head,
        )
        retry_options = make_agent_options(
            model="claude-opus-4-6",
            effort=effort_level,
            allowed_tools=["Read", "Bash"],
            cwd=str(project_dir),
            max_turns=10,
        )
        retry_result = await rate_limit.main_loop(
            runner_module,
            _HARDENED_RETRY_PREFIX + prompt,
            retry_options,
            state_path=state_path,
            logger=logger,
        )
        retry_msg = _extract_commit_message(retry_result.text, fallback=fallback)
        if retry_msg != fallback:
            commit_msg = retry_msg
        else:
            raw_head_retry = retry_result.text[:200]
            logger.error(
                "Phase 7: attempt 2/2 failed → using fallback; raw_head=%r",
                raw_head_retry,
            )
            commit_msg = fallback

    _validate_commit_message(commit_msg)
    git_commit(project_dir, commit_msg)

    branch = git_current_branch(project_dir)

    try:
        git_push(project_dir, branch)
    except GitError:
        logger.warning("Phase 7: push rejected — attempting rebase and retry.")
        git_pull_rebase(project_dir)
        git_push(project_dir, branch)

    target = cycle if cycle is not None else state
    target.token_usage["phase7"] = result.usage
    _state.save_state(state_path, state)
    log_phase_usage(logger, 7, result.usage)
    logger.info("Phase 7: committed and pushed to %s.", branch)
