"""Phase 6 — Test suite runner.

Runs Sonnet 4.6 to execute the test suite and fix failures iteratively
(max 3 attempts, controlled by the prompt). Raises :class:`TestsFailed`
if the session text contains the sentinel string ``"TESTS FAILED"``.

Non-negotiable #8: model is hard-coded to ``claude-sonnet-4-6``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from code_generator import effort as _effort
from code_generator import state as _state
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit
from code_generator.runner.options import make_agent_options
from code_generator.runner.types import TokenUsage

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import CycleState, State


# Sentinel emitted by the prompt when all retries are exhausted.
_FAIL_SENTINEL = "TESTS FAILED"


class TestsFailed(RuntimeError):  # noqa: N818
    """Raised when the test-runner session reports persistent test failures.

    The orchestrator should skip phase 7 (commit) when this is raised.
    """

    __test__ = False  # pytest: not a test class


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    max_retries: int = 3,
) -> None:
    """Execute phase 6: test suite runner with effort escalation.

    Runs up to *max_retries* attempts. Each attempt resolves an escalating
    effort level via ``resolve_effort(phase=6, retry_count=attempt)`` so the
    model receives progressively more compute on repeated failures.
    Token usage is accumulated across all attempts and persisted on success.

    Args:
        state: Root state object.
        cycle: Active cycle (multi-cycle) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
        max_retries: Maximum number of Python-level retry attempts (default 3).

    Raises:
        TestsFailed: When all attempts report ``"TESTS FAILED"``.
    """
    if logger is None:
        logger = setup_phase_logger("phase6", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"
    total_usage = TokenUsage()

    for attempt in range(max_retries):
        effort_level = _effort.resolve_effort(
            phase=6, complexity="", issue_labels=[], retry_count=attempt
        )
        _effort.validate_effort(effort_level, "claude-sonnet-4-6")

        prompt = load_prompt("prompt-phase-6-test.md", MAX_RETRIES="3")

        options = make_agent_options(
            model="claude-sonnet-4-6",
            effort=effort_level,
            allowed_tools=["Read", "Edit", "Bash"],
            cwd=str(project_dir),
            max_turns=40,
        )

        result = await rate_limit.main_loop(
            runner_module,
            prompt,
            options,
            state_path=state_path,
            logger=logger,
        )
        total_usage += result.usage

        if _FAIL_SENTINEL not in result.text:
            target = cycle if cycle is not None else state
            target.token_usage["phase6"] = total_usage
            _state.save_state(state_path, state)
            log_phase_usage(logger, 6, total_usage)
            return

        logger.warning(
            "Phase 6: attempt %d/%d failed (TESTS FAILED sentinel found).",
            attempt + 1,
            max_retries,
        )

    logger.error("Phase 6: test runner reported persistent failures after %d retries.", max_retries)
    raise TestsFailed(
        "Test suite failed after all retries. Inspect the output above and fix manually."
    )
