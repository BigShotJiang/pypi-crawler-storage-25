"""init command — scaffold .code-generator/ with a requirements.md template."""

import importlib.resources
from pathlib import Path
from typing import Annotated

import typer

from code_generator import state as state_module

_VALID_TEMPLATES = frozenset({"fastapi", "angular", "nestjs", "fullstack", "python-cli", "finance"})


def _read_template(name: str) -> str:
    return (
        importlib.resources.files("code_generator.templates")
        .joinpath(name + ".md")
        .read_text(encoding="utf-8")
    )


def init_command(
    template: Annotated[
        str | None,
        typer.Option(
            "--template",
            help=(
                "Append a variant section. One of: "
                "fastapi, angular, nestjs, fullstack, python-cli, finance."
            ),
        ),
    ] = None,
    force: Annotated[
        bool,
        typer.Option("--force", help="Overwrite an existing .code-generator/ directory."),
    ] = False,
) -> None:
    """Scaffold .code-generator/ with a ready-to-fill requirements.md."""
    if template is not None and template not in _VALID_TEMPLATES:
        typer.echo(
            f"ERROR: unknown template {template!r}. "
            f"Valid values: {', '.join(sorted(_VALID_TEMPLATES))}",
            err=True,
        )
        raise typer.Exit(code=1)

    project_dir = Path.cwd()
    cg_dir = project_dir / ".code-generator"

    if cg_dir.exists() and not force:
        typer.echo(
            "ERROR: .code-generator/ already exists. Use --force to overwrite.",
            err=True,
        )
        raise typer.Exit(code=1)

    cg_dir.mkdir(parents=True, exist_ok=True)

    content = _read_template("base")
    if template is not None:
        content += _read_template(template)

    (cg_dir / "requirements.md").write_text(content, encoding="utf-8")

    fresh_state = state_module.load_state(cg_dir / "state.json.missing")
    state_module.save_state(cg_dir / "state.json", fresh_state)

    typer.echo(f"Initialized .code-generator/ in {project_dir}")
    if template:
        typer.echo(f"Template applied: {template}")
