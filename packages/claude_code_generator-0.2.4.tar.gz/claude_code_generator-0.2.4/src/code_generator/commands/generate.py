"""generate command — orchestrate a full project generation pipeline."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Annotated

import typer

from code_generator import env
from code_generator import state as state_module
from code_generator.commands._dispatch import dispatch_orchestrator

# ---------------------------------------------------------------------------
# Pause guard
# ---------------------------------------------------------------------------


def _check_paused(st: state_module.State) -> bool:
    """Return True and print a message when the state is paused for rate limit.

    Args:
        st: Root state to inspect.

    Returns:
        True when the state indicates an active rate-limit pause.
    """
    if st.paused_until is not None and st.paused_until > time.time():
        remaining_s = st.paused_until - time.time()
        remaining_m = remaining_s / 60
        typer.echo(
            f"Rate-limit pause active — {remaining_m:.1f} minutes remaining. "
            "Re-run after the reset window expires.",
            err=False,
        )
        return True
    return False


# ---------------------------------------------------------------------------
# Typer command
# ---------------------------------------------------------------------------


def generate_command(
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run/--no-dry-run", help="Print what would happen without doing it."),
    ] = False,
    phase: Annotated[
        int | None,
        typer.Option("--phase", help="Run only a specific phase number."),
    ] = None,
    continue_: Annotated[
        bool,
        typer.Option("--continue/--no-continue", help="Resume a paused generation run."),
    ] = False,
    mode: Annotated[
        str,
        typer.Option("--mode", help="Generation mode: auto, single, or multi-cycle."),
    ] = "auto",
    cycle: Annotated[
        int | None,
        typer.Option("--cycle", help="Target a specific cycle (multi-cycle mode only)."),
    ] = None,
) -> None:
    """Run the full code-generation pipeline."""
    env.assert_safe_environment()

    if phase is not None and continue_:
        typer.echo(
            "ERROR: --phase and --continue are mutually exclusive.",
            err=True,
        )
        raise typer.Exit(code=2)

    if cycle is not None and mode not in ("multi-cycle",) and not continue_:
        typer.echo(
            "ERROR: --cycle is only valid with --mode multi-cycle or --continue.",
            err=True,
        )
        raise typer.Exit(code=2)

    project_dir = Path.cwd()
    cg_dir = project_dir / ".code-generator"

    if not cg_dir.exists():
        typer.echo(
            "ERROR: .code-generator/ not found. Run `code-generator init` first.",
            err=True,
        )
        raise typer.Exit(code=1)

    state_path = cg_dir / "state.json"
    st = state_module.load_state(state_path)

    # Rate-limit pause guard: inform user and exit cleanly.
    if _check_paused(st):
        raise typer.Exit(code=0)

    # Compute current requirements hash (absent when file does not yet exist).
    req_path = cg_dir / "requirements.md"
    current_hash = state_module.compute_requirements_hash(req_path) if req_path.exists() else None

    try:
        dispatch_orchestrator(
            st,
            project_dir,
            dry_run=dry_run,
            phase=phase,
            continue_=continue_,
            mode=mode,
            cycle=cycle,
            state_path=state_path,
            requirements_hash=current_hash,
        )
    except NotImplementedError as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(code=1) from exc
    except Exception as exc:  # noqa: BLE001
        from rich.console import Console
        from rich.traceback import Traceback

        Console(stderr=True).print(Traceback())
        raise typer.Exit(code=1) from exc
