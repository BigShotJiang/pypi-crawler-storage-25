"""Resume helpers for the generate command.

Derives ``start_phase`` and ``start_cycle`` from persisted state when the user
passes ``--continue``.  These functions are pure (no I/O) so they are easy to
unit-test in isolation.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from code_generator import state as state_module

_logger = logging.getLogger(__name__)

__all__ = ["next_start_phase", "resolve_continue_multi_cycle"]


def next_start_phase(st: state_module.State) -> int:
    """Return the phase to resume from after ``--continue``.

    ``state.phase`` records the last *completed* phase, so the next phase to
    run is always ``phase + 1``.  When no prior phase is recorded (fresh run),
    start from phase 1.

    Args:
        st: Root state.

    Returns:
        Phase number to pass as ``start_phase`` to the cycle loop.
    """
    return (st.phase or 0) + 1


def resolve_continue_multi_cycle(
    st: state_module.State,
) -> tuple[int | None, int]:
    """Return ``(start_cycle, start_phase)`` for a ``--continue`` in multi-cycle mode.

    Rules:
    - When ``current_cycle`` is *completed* (all phases done), advance to the
      next cycle and restart from phase 1 — the completed cycle must not be
      re-entered.
    - When ``current_cycle`` is still *open* (interrupted mid-cycle), resume
      within that cycle at the next phase.
    - When no ``current_cycle`` is recorded, return ``(None, 1)`` for a full run.

    Args:
        st: Root state.

    Returns:
        Tuple of ``(start_cycle, start_phase)`` to pass to ``run_multi_cycle``.
    """
    if st.current_cycle is None:
        return None, 1

    current = next((c for c in st.cycles if c.id == st.current_cycle), None)
    if current is not None and current.status == "completed":
        return st.current_cycle + 1, 1

    if current is not None:
        cycle_phase = current.phase or 0
        # Phase 7 with non-completed status → retry commit (don't advance beyond 7).
        start_phase = cycle_phase + 1 if cycle_phase < 7 else 7
        return st.current_cycle, start_phase

    _logger.warning(
        "No cycle record found for current_cycle=%d; defaulting to phase 1.",
        st.current_cycle,
    )
    return st.current_cycle, 1
