"""status command — display current project generation state."""

import shutil
import textwrap
from datetime import UTC, datetime
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from code_generator import state as state_module
from code_generator.runner.types import TokenUsage

_MISSING = "—"
_SCOPE_MAX_LEN = 60

# Approximate Max plan 5-hour cache_read token budget.
# Used to compute "% of 5h window" column in the cycles table.
_5H_CACHE_READ_BUDGET = 50_000_000


def status_command() -> None:
    """Show the current generation state for this project."""
    project_dir = Path.cwd()
    state_path = project_dir / ".code-generator" / "state.json"

    if not state_path.exists():
        typer.echo(
            "no .code-generator/state.json in this directory — run `code-generator init` first"
        )
        raise typer.Exit(code=0)

    st = state_module.load_state(state_path)
    terminal_width = shutil.get_terminal_size((200, 24)).columns
    console = Console(file=typer.get_text_stream("stdout"), width=max(terminal_width, 200))

    if st.last_error:
        console.print(f"[bold red]⚠ Last error: {st.last_error}[/bold red]\n")

    _render_summary_table(console, st)

    if st.mode == "multi-cycle" and st.cycles:
        _render_cycles_table(console, st)


def _pause_remaining(state: state_module.State) -> str:
    import time

    if state.paused_until is None:
        return "-"
    remaining = state.paused_until - time.time()
    if remaining <= 0:
        return "-"
    minutes = remaining / 60
    return f"{minutes:.1f} minutes remaining"


def _sum_token_usage(token_usage: dict[str, TokenUsage]) -> TokenUsage:
    """Sum all TokenUsage values in a phase→usage mapping."""
    total = TokenUsage()
    for usage in token_usage.values():
        total += usage
    return total


def _render_summary_table(console: Console, st: state_module.State) -> None:
    table = Table(title="code-generator status")
    table.add_column("Field", style="bold")
    table.add_column("Value")

    open_issues = sum(1 for i in st.issues if i.status == "open")
    closed_issues = sum(1 for i in st.issues if i.status == "closed")

    table.add_row("mode", st.mode)
    table.add_row("current cycle", str(st.current_cycle) if st.current_cycle is not None else "-")
    table.add_row("current phase", str(st.phase) if st.phase is not None else "-")
    table.add_row("open issues", str(open_issues))
    table.add_row("closed issues", str(closed_issues))
    table.add_row("rate-limit pause", _pause_remaining(st))

    requirements_hash = getattr(st, "requirements_hash", None)
    if requirements_hash:
        table.add_row("requirements hash", str(requirements_hash)[:8])

    if st.mode == "single" and st.token_usage:
        totals = _sum_token_usage(st.token_usage)
        table.add_section()
        table.add_row("Tokens", "")
        table.add_row("  in", str(totals.input))
        table.add_row("  cache_read", str(totals.cache_read))
        table.add_row("  cache_write", str(totals.cache_write))
        table.add_row("  out", str(totals.output))

    console.print(table)


def _format_status(status: str) -> str:
    if status == "completed":
        return f"✓ {status}"
    return status


def _format_scope(scope: str) -> str:
    if not scope:
        return _MISSING
    return textwrap.shorten(scope, width=_SCOPE_MAX_LEN, placeholder="…")


def _format_depends_on(depends_on: list[int]) -> str:
    if not depends_on:
        return _MISSING
    return ", ".join(str(d) for d in depends_on)


def _format_milestone(milestone_number: int | None) -> str:
    if milestone_number is None:
        return _MISSING
    return f"#{milestone_number}"


def _format_wall_clock(started_at: str | None, finished_at: str | None) -> str:
    """Format elapsed time from ISO 8601 timestamps as Xh Ym (≥1h) or Xm Ys (<1h)."""
    if started_at is None or finished_at is None:
        return _MISSING
    start = datetime.fromisoformat(started_at.replace("Z", "+00:00")).replace(tzinfo=UTC)
    end = datetime.fromisoformat(finished_at.replace("Z", "+00:00")).replace(tzinfo=UTC)
    total_seconds = int((end - start).total_seconds())
    if total_seconds < 0:
        return _MISSING
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours >= 1:
        return f"{hours}h {minutes}m"
    return f"{minutes}m {seconds}s"


def _format_pct_5h(token_usage: dict[str, TokenUsage]) -> str:
    """Format cache_read sum as % of the 5h budget constant."""
    if not token_usage:
        return _MISSING
    total_cache_read = sum(u.cache_read for u in token_usage.values())
    pct = total_cache_read / _5H_CACHE_READ_BUDGET * 100
    return f"{pct:.1f}%"


def _render_cycles_table(console: Console, st: state_module.State) -> None:
    table = Table(title="cycles")
    table.add_column("id")
    table.add_column("name")
    table.add_column("status")
    table.add_column("phase")
    table.add_column("closed/total")
    table.add_column("scope")
    table.add_column("depends on")
    table.add_column("milestone")
    table.add_column("in")
    table.add_column("cache_read")
    table.add_column("cache_write")
    table.add_column("out")
    table.add_column("wall-clock")
    table.add_column("% of 5h")

    for cycle in st.cycles:
        closed = sum(1 for i in cycle.issues if i.status == "closed")
        total = len(cycle.issues)
        if cycle.token_usage:
            totals = _sum_token_usage(cycle.token_usage)
            tok_in = str(totals.input)
            tok_cr = str(totals.cache_read)
            tok_cw = str(totals.cache_write)
            tok_out = str(totals.output)
        else:
            tok_in = tok_cr = tok_cw = tok_out = _MISSING
        table.add_row(
            str(cycle.id),
            cycle.name,
            _format_status(cycle.status),
            str(cycle.phase),
            f"{closed}/{total}",
            _format_scope(cycle.scope),
            _format_depends_on(cycle.depends_on),
            _format_milestone(cycle.milestone_number),
            tok_in,
            tok_cr,
            tok_cw,
            tok_out,
            _format_wall_clock(cycle.started_at, cycle.finished_at),
            _format_pct_5h(cycle.token_usage),
        )

    console.print(table)
