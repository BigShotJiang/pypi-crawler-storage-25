"""Unit tests for is_canonical_structure — canonical requirements.md detection.

Each test corresponds to one acceptance criterion from issue #145.
All tests use fixture strings — no file I/O.
"""

from __future__ import annotations

from code_generator.requirements_structure import is_canonical_structure

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

_FULL_CANONICAL = """\
# My Project

## Description
Describe the project.

## Tech Stack
Python, FastAPI.

## Goals
- Ship fast.

## Scope

### 1. User authentication
Implement login and logout.

#### Acceptance criteria
- [ ] Users can log in with email and password.

### 2. Dashboard
Show usage stats.

#### Acceptance criteria
- [ ] Stats are displayed on the dashboard.

## Non-goals
- Native mobile apps.

## Constraints
- Must run on Python 3.11+.

## Global acceptance criteria
- [ ] All tests pass.
"""

_NO_CONSTRAINTS = """\
# My Project

## Description
Describe the project.

## Tech Stack
Python.

## Goals
- Ship fast.

## Scope

## Non-goals
- Native mobile apps.

## Global acceptance criteria
- [ ] All tests pass.
"""

_SCOPE_MISSING_AC = """\
# My Project

## Description
Describe the project.

## Tech Stack
Python.

## Goals
- Ship fast.

## Scope

### 1. User authentication
Implement login and logout.

#### Acceptance criteria
- [ ] Users can log in.

### 2. Dashboard
Show stats.

(this subsection is missing the required AC block)

## Non-goals
- None.

## Constraints
- Python 3.11+.

## Global acceptance criteria
- [ ] All tests pass.
"""

_EMPTY_SCOPE = """\
# My Project

## Description
Describe the project.

## Tech Stack
Python.

## Goals
- Ship fast.

## Scope

## Non-goals
- None.

## Constraints
- Python 3.11+.

## Global acceptance criteria
- [ ] All tests pass.
"""

_FREEFORM = """\
This is a freeform requirements file with no headings at all.
Just prose describing what we want to build.
No structure whatsoever.
"""

_MIXED_CASE_HEADINGS = """\
# My Project

## description
Describe the project.

## tech stack
Python.

## goals
- Ship fast.

## scope

## non-goals
- None.

## constraints
- Python 3.11+.

## global acceptance criteria
- [ ] All tests pass.
"""

_EXTRA_HEADINGS = """\
# My Project

## Description
Describe the project.

## Tech Stack
Python.

## Goals
- Ship fast.

## Scope

## Non-goals
- None.

## Constraints
- Python 3.11+.

## Global acceptance criteria
- [ ] All tests pass.

## Architecture
Extra section not in the canonical list.

## Deployment
Another extra section.
"""


# ---------------------------------------------------------------------------
# AC 1: Returns True for a fully canonical fixture
# ---------------------------------------------------------------------------


class TestFullyCanonicalFixture:
    def test_returns_true_when_all_headings_and_ac_blocks_present(self) -> None:
        """Returns True for a fixture with all headings and acceptance criteria blocks."""
        assert is_canonical_structure(_FULL_CANONICAL) is True


# ---------------------------------------------------------------------------
# AC 2: Returns False when ## Constraints is missing
# ---------------------------------------------------------------------------


class TestMissingConstraints:
    def test_returns_false_when_constraints_heading_absent(self) -> None:
        """Returns False when ## Constraints is missing."""
        assert is_canonical_structure(_NO_CONSTRAINTS) is False


# ---------------------------------------------------------------------------
# AC 3: Returns False when a ### N. subsection lacks Acceptance criteria
# ---------------------------------------------------------------------------


class TestScopeSubsectionMissingAC:
    def test_returns_false_when_one_subsection_lacks_acceptance_criteria(self) -> None:
        """Returns False when one ### N. subsection under ## Scope lacks an Acceptance criteria block."""
        assert is_canonical_structure(_SCOPE_MISSING_AC) is False


# ---------------------------------------------------------------------------
# AC 4: Returns True when there are zero ### N. subsections under Scope
# ---------------------------------------------------------------------------


class TestEmptyScope:
    def test_returns_true_when_scope_has_no_numbered_subsections(self) -> None:
        """Returns True when there are zero ### N. subsections under Scope (empty scope is valid)."""
        assert is_canonical_structure(_EMPTY_SCOPE) is True


# ---------------------------------------------------------------------------
# AC 5: Returns False for a completely freeform file
# ---------------------------------------------------------------------------


class TestFreeformFile:
    def test_returns_false_for_file_with_no_headings(self) -> None:
        """Returns False for a completely freeform requirements file (no headings at all)."""
        assert is_canonical_structure(_FREEFORM) is False

    def test_returns_false_for_empty_string(self) -> None:
        """Returns False for an empty string."""
        assert is_canonical_structure("") is False


# ---------------------------------------------------------------------------
# AC 6: Returns True when headings use different casing
# ---------------------------------------------------------------------------


class TestCaseInsensitiveHeadings:
    def test_returns_true_when_headings_use_lowercase(self) -> None:
        """Returns True when headings use lowercase (e.g. ## tech stack matches ## Tech Stack)."""
        assert is_canonical_structure(_MIXED_CASE_HEADINGS) is True


# ---------------------------------------------------------------------------
# AC 7: Returns True when extra non-canonical headings are present
# ---------------------------------------------------------------------------


class TestExtraHeadings:
    def test_returns_true_when_superset_of_required_headings_present(self) -> None:
        """Returns True when extra non-canonical headings are present (superset is still canonical)."""
        assert is_canonical_structure(_EXTRA_HEADINGS) is True


# ---------------------------------------------------------------------------
# AC 8: The function is pure — no I/O, no side effects
# ---------------------------------------------------------------------------


class TestPurity:
    def test_same_input_always_returns_same_output(self) -> None:
        """Calling with the same input multiple times always returns the same result."""
        for _ in range(5):
            assert is_canonical_structure(_FULL_CANONICAL) is True
            assert is_canonical_structure(_FREEFORM) is False

    def test_does_not_modify_input(self) -> None:
        """The function does not mutate its input string."""
        original = _FULL_CANONICAL
        snapshot = original[:]
        is_canonical_structure(original)
        assert original == snapshot
