"""Tests for resume flags in the `code-generator generate` command.

Covers --continue, --phase N, --cycle N, --dry-run, paused state,
and --mode auto with existing state.
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING

import pytest
from typer.testing import CliRunner

from code_generator import state as state_module
from code_generator.cli import app
from code_generator.env import DANGEROUS_VARS

if TYPE_CHECKING:
    from pathlib import Path

runner = CliRunner()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clear_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in DANGEROUS_VARS:
        monkeypatch.delenv(var, raising=False)


def _cg_dir(tmp_path: Path, *, mode: str = "single") -> Path:
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    st = state_module.State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
    )
    state_module.save_state(cg / "state.json", st)
    return cg


def _cg_dir_with_phase(tmp_path: Path, *, phase: int, mode: str = "single") -> Path:
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    st = state_module.State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        phase=phase,
    )
    state_module.save_state(cg / "state.json", st)
    return cg


def _cg_dir_with_cycle_phase(
    tmp_path: Path,
    *,
    current_cycle: int,
    phase: int,
    mode: str = "multi-cycle",
) -> Path:
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    st = state_module.State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        current_cycle=current_cycle,
        phase=phase,
    )
    state_module.save_state(cg / "state.json", st)
    return cg


def _cg_dir_with_completed_cycle(tmp_path: Path, *, completed_cycle_id: int) -> Path:
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    cycle = state_module.CycleState(
        id=completed_cycle_id,
        name=f"cycle_{completed_cycle_id}",
        milestone_number=None,
        milestone_title=f"Cycle {completed_cycle_id}",
        status="completed",
        phase=7,
        issues=[],
        commit_sha=None,
    )
    st = state_module.State(
        mode="multi-cycle",  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        current_cycle=completed_cycle_id,
        cycles=[cycle],
    )
    state_module.save_state(cg / "state.json", st)
    return cg


def _cg_dir_paused(tmp_path: Path, *, seconds_remaining: int = 300) -> Path:
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    st = state_module.State(
        mode="single",
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        paused_until=int(time.time()) + seconds_remaining,
        rate_limit_type="requests_per_day",
    )
    state_module.save_state(cg / "state.json", st)
    return cg


# ---------------------------------------------------------------------------
# Helper: patch the cycle_loop functions and capture call args
# ---------------------------------------------------------------------------


class _CaptureCycleLoop:
    """Context manager that captures calls to run_single_mode and run_multi_cycle."""

    def __init__(self) -> None:
        self.single_calls: list[dict] = []
        self.multi_calls: list[dict] = []

    def __enter__(self) -> _CaptureCycleLoop:
        return self

    def __exit__(self, *_exc: object) -> None:  # type: ignore[override]
        pass


def _mock_phase0_single(monkeypatch: pytest.MonkeyPatch) -> None:
    from code_generator.orchestrator import phase0_complexity

    async def _noop(state, *_args, **_kwargs):
        state.mode = "single"
        return state

    monkeypatch.setattr(phase0_complexity, "run", _noop)


def _mock_phase0_multi(monkeypatch: pytest.MonkeyPatch) -> None:
    from code_generator.orchestrator import phase0_complexity

    async def _noop(state, *_args, **_kwargs):
        state.mode = "multi-cycle"
        return state

    monkeypatch.setattr(phase0_complexity, "run", _noop)


# ---------------------------------------------------------------------------
# --continue with single mode: resume from state.phase
# ---------------------------------------------------------------------------


class TestContinueFlag:
    def test_continue_single_mode_after_phase2_resumes_at_phase3(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue after phase 2 completion resumes at phase 3, not phase 2."""
        monkeypatch.chdir(tmp_path)
        _cg_dir_with_phase(tmp_path, phase=2, mode="single")

        captured: list[int] = []

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            captured.append(start_phase)
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue"])
        assert result.exit_code == 0
        assert captured == [3]

    def test_continue_single_mode_at_phase3_resumes_at_phase4(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue with single-mode state at phase 3 calls run_single_mode(start_phase=4)."""
        monkeypatch.chdir(tmp_path)
        _cg_dir_with_phase(tmp_path, phase=3, mode="single")

        captured: list[int] = []

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            captured.append(start_phase)
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue"])
        assert result.exit_code == 0
        assert captured == [4]

    def test_continue_no_prior_phase_starts_at_phase1(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue with no prior phase in state starts at phase 1."""
        monkeypatch.chdir(tmp_path)
        _cg_dir(tmp_path, mode="single")  # phase=None in state

        captured: list[int] = []

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            captured.append(start_phase)
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue"])
        assert result.exit_code == 0
        assert captured == [1]

    def test_continue_multi_cycle_at_cycle2_phase4_resumes_at_phase5(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue with proper CycleState record at cycle 2, phase 4 resumes at phase 5."""
        monkeypatch.chdir(tmp_path)

        # Create state with a proper CycleState record (cycle_id=2, phase=4) and
        # top-level phase=None — the correct multi-cycle layout.
        cg = tmp_path / ".code-generator"
        cg.mkdir(parents=True, exist_ok=True)
        cycle = state_module.CycleState(
            id=2,
            name="cycle_2",
            milestone_number=None,
            milestone_title="Cycle 2",
            status="open",
            phase=4,
            issues=[],
            commit_sha=None,
        )
        st = state_module.State(
            mode="multi-cycle",  # type: ignore[arg-type]
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=2,
            cycles=[cycle],
            phase=None,  # always None in multi-cycle mode
        )
        state_module.save_state(cg / "state.json", st)

        captured: list[dict] = []

        async def mock_multi(
            state,
            *_args,
            start_cycle=None,
            start_phase=1,
            **_kwargs,
        ):
            captured.append({"start_cycle": start_cycle, "start_phase": start_phase})
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)
        _mock_phase0_single(monkeypatch)  # Phase0 won't run (mode already set).

        result = runner.invoke(app, ["generate", "--continue"])
        assert result.exit_code == 0
        assert len(captured) == 1
        assert captured[0]["start_cycle"] == 2
        assert captured[0]["start_phase"] == 5

    def test_continue_multi_cycle_completed_cycle_advances_start_cycle(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue when current cycle is completed advances start_cycle to next cycle."""
        monkeypatch.chdir(tmp_path)
        _cg_dir_with_completed_cycle(tmp_path, completed_cycle_id=2)

        captured: list[dict] = []

        async def mock_multi(
            state,
            *_args,
            start_cycle=None,
            start_phase=1,
            **_kwargs,
        ):
            captured.append({"start_cycle": start_cycle, "start_phase": start_phase})
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue"])
        assert result.exit_code == 0
        assert len(captured) == 1
        assert captured[0]["start_cycle"] == 3
        assert captured[0]["start_phase"] == 1


# ---------------------------------------------------------------------------
# --phase N
# ---------------------------------------------------------------------------


class TestPhaseFlag:
    def test_phase_5_sets_start_phase(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--phase 5 calls run_single_mode(start_phase=5)."""
        monkeypatch.chdir(tmp_path)
        _cg_dir(tmp_path, mode="single")

        captured: list[int] = []

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            captured.append(start_phase)
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--phase", "5"])
        assert result.exit_code == 0
        assert captured == [5]

    def test_phase_mutually_exclusive_with_continue(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--phase and --continue together exit with code 2."""
        monkeypatch.chdir(tmp_path)
        _cg_dir(tmp_path)
        result = runner.invoke(app, ["generate", "--phase", "3", "--continue"])
        assert result.exit_code == 2


# ---------------------------------------------------------------------------
# --cycle N
# ---------------------------------------------------------------------------


class TestCycleFlag:
    def test_cycle_2_sets_start_cycle(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--cycle 2 calls run_multi_cycle(start_cycle=2, start_phase=1)."""
        monkeypatch.chdir(tmp_path)
        _cg_dir(tmp_path, mode="multi-cycle")

        captured: list[dict] = []

        async def mock_multi(
            state,
            *_args,
            start_cycle=None,
            start_phase=1,
            **_kwargs,
        ):
            captured.append({"start_cycle": start_cycle, "start_phase": start_phase})
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--cycle", "2", "--mode", "multi-cycle"])
        assert result.exit_code == 0
        assert len(captured) == 1
        assert captured[0]["start_cycle"] == 2
        assert captured[0]["start_phase"] == 1

    def test_cycle_without_multi_cycle_mode_exits_2(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--cycle without --mode multi-cycle exits with code 2."""
        monkeypatch.chdir(tmp_path)
        _cg_dir(tmp_path)
        result = runner.invoke(app, ["generate", "--cycle", "1", "--mode", "single"])
        assert result.exit_code == 2

    def test_cycle_3_and_phase_5_combined_passes_both_to_orchestrator(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--cycle 3 --phase 5 passes start_cycle=3 and start_phase=5 to run_multi_cycle."""
        monkeypatch.chdir(tmp_path)
        _cg_dir(tmp_path, mode="multi-cycle")

        captured: list[dict] = []

        async def mock_multi(
            state,
            *_args,
            start_cycle=None,
            start_phase=1,
            **_kwargs,
        ):
            captured.append({"start_cycle": start_cycle, "start_phase": start_phase})
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)
        _mock_phase0_multi(monkeypatch)

        result = runner.invoke(
            app, ["generate", "--cycle", "3", "--phase", "5", "--mode", "multi-cycle"]
        )
        assert result.exit_code == 0
        assert len(captured) == 1
        assert captured[0]["start_cycle"] == 3
        assert captured[0]["start_phase"] == 5


# ---------------------------------------------------------------------------
# --dry-run: phases 0 + 1 only
# ---------------------------------------------------------------------------


class TestDryRun:
    def test_dry_run_only_calls_phase0_and_phase1(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--dry-run runs phase 0 and phase 1 only; cycle_loop is never called."""
        monkeypatch.chdir(tmp_path)
        _cg_dir(tmp_path)

        from code_generator.orchestrator import cycle_loop, phase0_complexity, phase1_plan

        phase0_called: list[bool] = []
        phase1_called: list[bool] = []
        cycle_loop_called: list[bool] = []

        async def mock_phase0(state, *_args, **_kwargs):
            phase0_called.append(True)
            state.mode = "single"
            return state

        async def mock_phase1(*args, **kwargs):
            phase1_called.append(True)

        async def mock_single(*args, **kwargs):
            cycle_loop_called.append(True)

        async def mock_multi(*args, **kwargs):
            cycle_loop_called.append(True)

        monkeypatch.setattr(phase0_complexity, "run", mock_phase0)
        monkeypatch.setattr(phase1_plan, "run", mock_phase1)
        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)

        result = runner.invoke(app, ["generate", "--dry-run"])
        assert result.exit_code == 0
        assert cycle_loop_called == []
        assert phase1_called == [True]


# ---------------------------------------------------------------------------
# Paused state guard
# ---------------------------------------------------------------------------


class TestPausedStateGuard:
    def test_paused_state_exits_0_without_invoking_orchestrator(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When state is paused, exits 0 with pause message, orchestrator not invoked."""
        monkeypatch.chdir(tmp_path)
        _cg_dir_paused(tmp_path, seconds_remaining=600)

        from code_generator.orchestrator import cycle_loop

        orchestrator_called: list[bool] = []

        async def mock_single(*args, **kwargs):
            orchestrator_called.append(True)

        async def mock_multi(*args, **kwargs):
            orchestrator_called.append(True)

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)

        result = runner.invoke(app, ["generate"])
        assert result.exit_code == 0
        assert "paused" in result.output.lower() or "rate-limit" in result.output.lower()
        assert orchestrator_called == []

    def test_paused_state_shows_minutes_remaining(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Pause message mentions time remaining."""
        monkeypatch.chdir(tmp_path)
        _cg_dir_paused(tmp_path, seconds_remaining=1800)

        result = runner.invoke(app, ["generate"])
        assert result.exit_code == 0
        # Should mention 30 minutes (1800s / 60).
        output = result.output
        assert any(char.isdigit() for char in output)


# ---------------------------------------------------------------------------
# --mode auto with existing state
# ---------------------------------------------------------------------------


class TestModeAuto:
    def test_mode_auto_honors_existing_single_state(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--mode auto with single-mode state calls run_single_mode (no phase0)."""
        monkeypatch.chdir(tmp_path)
        _cg_dir(tmp_path, mode="single")

        from code_generator.orchestrator import cycle_loop, phase0_complexity

        phase0_called: list[bool] = []
        single_called: list[bool] = []

        async def mock_phase0(state, *_args, **_kwargs):
            phase0_called.append(True)
            return state

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            single_called.append(True)
            return state

        monkeypatch.setattr(phase0_complexity, "run", mock_phase0)
        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)

        result = runner.invoke(app, ["generate"])
        assert result.exit_code == 0
        # Phase 0 should NOT be called when mode is already in state.
        assert phase0_called == []
        assert single_called == [True]

    def test_mode_auto_honors_existing_multi_cycle_state(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--mode auto with multi-cycle state calls run_multi_cycle (not run_single_mode)."""
        monkeypatch.chdir(tmp_path)
        _cg_dir(tmp_path, mode="multi-cycle")

        from code_generator.orchestrator import cycle_loop, phase0_complexity

        phase0_called: list[bool] = []
        multi_called: list[bool] = []
        single_called: list[bool] = []

        async def mock_phase0(state, *_args, **_kwargs):
            phase0_called.append(True)
            return state

        async def mock_multi(
            state,
            *_args,
            start_cycle=None,
            start_phase=1,
            **_kwargs,
        ):
            multi_called.append(True)
            return state

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            single_called.append(True)
            return state

        monkeypatch.setattr(phase0_complexity, "run", mock_phase0)
        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)
        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)

        result = runner.invoke(app, ["generate"])  # default --mode auto
        assert result.exit_code == 0
        # Phase 0 should NOT be called when mode is already in state.
        assert phase0_called == []
        # run_multi_cycle must be called; run_single_mode must not.
        assert multi_called == [True]
        assert single_called == []

    def test_mode_single_overrides_multi_cycle_state(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--mode single dispatches to run_single_mode even when state.mode is multi-cycle."""
        monkeypatch.chdir(tmp_path)
        _cg_dir(tmp_path, mode="multi-cycle")

        from code_generator.orchestrator import cycle_loop

        single_called: list[bool] = []
        multi_called: list[bool] = []

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            single_called.append(True)
            return state

        async def mock_multi(
            state,
            *_args,
            start_cycle=None,
            start_phase=1,
            **_kwargs,
        ):
            multi_called.append(True)
            return state

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)

        result = runner.invoke(app, ["generate", "--mode", "single"])
        assert result.exit_code == 0
        assert single_called == [True]
        assert multi_called == []

    def test_mode_auto_runs_phase0_when_mode_unknown(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--mode auto with no prior state runs phase 0 to determine mode."""
        monkeypatch.chdir(tmp_path)
        # Create state without mode set (fresh state defaults to "single" but
        # has mode in the object; simulate unknown by using a freshly loaded state
        # that has never had phase0 run).
        cg = tmp_path / ".code-generator"
        cg.mkdir(parents=True, exist_ok=True)
        # Write a state file that mimics a blank slate (mode="single" is the
        # default, but the test needs phase0 to determine it).
        # Since load_state returns "single" by default, and the generate command
        # treats "single"/"multi-cycle" as already-set, we test via
        # explicit mode="auto" override by patching.
        st = state_module.State(
            mode="single",  # type: ignore[arg-type]
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        state_module.save_state(cg / "state.json", st)

        from code_generator.orchestrator import cycle_loop, phase0_complexity

        phase0_called: list[bool] = []

        async def mock_phase0(state, *_args, **_kwargs):
            phase0_called.append(True)
            state.mode = "single"
            return state

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            return state

        monkeypatch.setattr(phase0_complexity, "run", mock_phase0)
        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)

        # With --mode single, phase0 should be skipped.
        result = runner.invoke(app, ["generate", "--mode", "single"])
        assert result.exit_code == 0
        # Phase 0 not called when mode is explicitly set.
        assert phase0_called == []


# ---------------------------------------------------------------------------
# Regression tests — Issue #34: --continue off-by-one resume
# ---------------------------------------------------------------------------


class TestContinueOffByOneRegression:
    """Regression tests for bug #34: --continue must resume at phase N+1, not N."""

    def test_continue_after_phase2_resumes_at_3_not_2(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue with state.phase=2 passes start_phase=3, not 2 (off-by-one guard)."""
        monkeypatch.chdir(tmp_path)
        _cg_dir_with_phase(tmp_path, phase=2, mode="single")

        captured: list[int] = []

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            captured.append(start_phase)
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue"])
        assert result.exit_code == 0
        assert captured == [3], f"Expected [3] but got {captured!r} — off-by-one regression"

    def test_continue_after_phase1_resumes_at_2_not_1(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue with state.phase=1 passes start_phase=2, not 1 (off-by-one guard)."""
        monkeypatch.chdir(tmp_path)
        _cg_dir_with_phase(tmp_path, phase=1, mode="single")

        captured: list[int] = []

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            captured.append(start_phase)
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue"])
        assert result.exit_code == 0
        assert captured == [2], f"Expected [2] but got {captured!r} — off-by-one regression"

    def test_continue_never_repeats_completed_phase(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """start_phase from --continue is always greater than the recorded completed phase."""
        monkeypatch.chdir(tmp_path)
        _cg_dir_with_phase(tmp_path, phase=4, mode="single")

        captured: list[int] = []

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            captured.append(start_phase)
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue"])
        assert result.exit_code == 0
        assert len(captured) == 1
        assert captured[0] > 4, (
            f"start_phase={captured[0]} must be > 4 (last completed) — re-runs same phase"
        )


# ---------------------------------------------------------------------------
# Edge-case tests — Issue #99
# ---------------------------------------------------------------------------


class TestResolveContinueEdgeCases:
    def test_resolve_continue_empty_cycles_list(self, tmp_path: Path) -> None:
        """current_cycle=1 with cycles=[] falls through to (1, _next_start_phase)."""
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as _resolve_continue_multi_cycle,
        )

        cg = _cg_dir_with_cycle_phase(tmp_path, current_cycle=1, phase=0)
        st = state_module.load_state(cg / "state.json")
        st.phase = None  # treat as fresh run
        sc, sp = _resolve_continue_multi_cycle(st)
        assert (sc, sp) == (1, 1)  # cycles=[] → falls through; phase=None → sp=1

    def test_resolve_continue_nonexistent_cycle_id(self, tmp_path: Path) -> None:
        """current_cycle not found in cycles list → safe fallback (current_cycle, 1), never reads st.phase."""
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as _resolve_continue_multi_cycle,
        )

        # Build state with cycle id=1 but current_cycle=3 (id mismatch — anomalous state).
        # st.phase=5 must NOT be read; fallback must return phase 1 unconditionally.
        cg = _cg_dir_with_completed_cycle(tmp_path, completed_cycle_id=1)
        st = state_module.load_state(cg / "state.json")
        st.current_cycle = 3
        st.phase = 5
        sc, sp = _resolve_continue_multi_cycle(st)
        assert (sc, sp) == (
            3,
            1,
        )  # safe default; cycle id=3 not in cycles list → never reads st.phase

    def test_next_start_phase_after_final_phase(self, tmp_path: Path) -> None:
        """_next_start_phase returns 8 when state.phase is the final phase 7."""
        from code_generator.commands._resume import next_start_phase as _next_start_phase

        cg = _cg_dir_with_phase(tmp_path, phase=7)
        st = state_module.load_state(cg / "state.json")
        assert _next_start_phase(st) == 8


def _make_cycle(
    *,
    cycle_id: int,
    phase: int | None,
    status: str = "open",
    n_closed_issues: int = 0,
) -> state_module.CycleState:
    """Build a minimal CycleState for test fixtures."""
    issues = [
        state_module.IssueState(number=i + 1, status="closed", agent="python-pro", labels=[])
        for i in range(n_closed_issues)
    ]
    return state_module.CycleState(
        id=cycle_id,
        name=f"cycle_{cycle_id}",
        milestone_number=None,
        milestone_title=f"Cycle {cycle_id}",
        status=status,
        phase=phase,  # type: ignore[arg-type]
        issues=issues,
        commit_sha=None,
    )


# ---------------------------------------------------------------------------
# Fix tests — Issue #106: --continue resume logic for multi-cycle mode
# ---------------------------------------------------------------------------


class TestResolveContinueMultiCycleIssue106:
    """Unit tests for the Issue #106 fix.

    Exercises ``resolve_continue_multi_cycle()`` directly to confirm it reads
    ``cycle.phase`` (per-cycle record) rather than ``st.phase`` (top-level).
    """

    def test_cycle2_phase6_top_level_phase_none_resumes_at_phase7(self, tmp_path: Path) -> None:
        """current_cycle=2, cycles[1].phase=6, top-level phase=None → start_cycle=2, start_phase=7."""
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as resolve,
        )

        st = state_module.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=2,
            phase=None,  # top-level phase is None — the bug scenario
            cycles=[
                _make_cycle(cycle_id=1, phase=7, status="completed"),
                _make_cycle(cycle_id=2, phase=6, status="open"),
            ],
        )
        sc, sp = resolve(st)
        assert sc == 2, f"Expected start_cycle=2, got {sc}"
        assert sp == 7, f"Expected start_phase=7, got {sp}"

    def test_cycle2_phase7_open_retries_commit_not_advance(self, tmp_path: Path) -> None:
        """current_cycle=2, cycles[1].phase=7, status='open' → start_cycle=2, start_phase=7 (retry commit)."""
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as resolve,
        )

        st = state_module.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=2,
            phase=None,
            cycles=[
                _make_cycle(cycle_id=1, phase=7, status="completed"),
                _make_cycle(cycle_id=2, phase=7, status="open"),
            ],
        )
        sc, sp = resolve(st)
        assert sc == 2, f"Expected start_cycle=2, got {sc}"
        assert sp == 7, f"Expected start_phase=7 (retry commit), got {sp}"

    def test_cycle1_completed_cycle2_phase_none_starts_at_cycle2_phase1(
        self, tmp_path: Path
    ) -> None:
        """current_cycle=1 completed, cycle 2 has phase=None → start_cycle=2, start_phase=1."""
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as resolve,
        )

        st = state_module.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=1,
            phase=None,
            cycles=[
                _make_cycle(cycle_id=1, phase=7, status="completed"),
            ],
        )
        sc, sp = resolve(st)
        assert sc == 2, f"Expected start_cycle=2, got {sc}"
        assert sp == 1, f"Expected start_phase=1, got {sp}"

    def test_single_cycle_phase3_resumes_at_phase4_regression_guard(self, tmp_path: Path) -> None:
        """Single-cycle state with phase=3 → start_phase=4 (regression guard, not affected by fix)."""
        from code_generator.commands._resume import next_start_phase

        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            phase=3,
        )
        assert next_start_phase(st) == 4

    def test_regression_fixture_2026_04_14_incident(self, tmp_path: Path) -> None:
        """Regression fixture mirroring the real 2026-04-14 state.json incident.

        Scenario: cycle 2 had phase=6, 15 closed issues, top-level phase=null.
        --continue must resolve to start_cycle=2, start_phase=7.
        """
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as resolve,
        )

        st = state_module.State(
            mode="multi-cycle",
            started_at="2026-04-14T00:00:00Z",
            updated_at="2026-04-14T12:00:00Z",
            current_cycle=2,
            phase=None,  # top-level phase always None in multi-cycle mode
            cycles=[
                _make_cycle(cycle_id=1, phase=7, status="completed", n_closed_issues=10),
                _make_cycle(cycle_id=2, phase=6, status="open", n_closed_issues=15),
            ],
        )
        sc, sp = resolve(st)
        assert sc == 2, (
            f"Regression (2026-04-14): expected start_cycle=2, got {sc} — "
            "bug restarts from cycle 1 when top-level phase=None"
        )
        assert sp == 7, (
            f"Regression (2026-04-14): expected start_phase=7, got {sp} — "
            "bug returns start_phase=1 because it reads st.phase (None) instead of cycle.phase (6)"
        )

    def test_cycle_phase_none_treated_as_never_started_resumes_at_phase1(
        self, tmp_path: Path
    ) -> None:
        """Boundary: cycle.phase=None → treated as cycle never started; resume at Phase 1."""
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as resolve,
        )

        st = state_module.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=2,
            phase=None,
            cycles=[
                _make_cycle(cycle_id=1, phase=7, status="completed"),
                _make_cycle(cycle_id=2, phase=None, status="open"),
            ],
        )
        sc, sp = resolve(st)
        assert sc == 2
        assert sp == 1, f"Expected start_phase=1 (phase=None means cycle never started), got {sp}"

    def test_cycle_phase_zero_treated_as_never_started_resumes_at_phase1(
        self, tmp_path: Path
    ) -> None:
        """Boundary: cycle.phase=0 → treated as cycle never started; resume at Phase 1."""
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as resolve,
        )

        st = state_module.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=1,
            phase=None,
            cycles=[
                _make_cycle(cycle_id=1, phase=0, status="open"),
            ],
        )
        sc, sp = resolve(st)
        assert sc == 1
        assert sp == 1, f"Expected start_phase=1 (phase=0 means cycle never started), got {sp}"

    def test_fallback_missing_cycle_record_never_reads_st_phase(self, tmp_path: Path) -> None:
        """AC7: cycle record not found → (current_cycle, 1) regardless of st.phase value.

        The fallback must never read st.phase (always None in multi-cycle mode).
        """
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as resolve,
        )

        # Anomalous state: current_cycle=3 but no CycleState for id=3.
        # st.phase=6 is set to prove the fallback does NOT read it.
        st = state_module.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=3,
            phase=6,  # must NOT be read by the fallback
            cycles=[
                _make_cycle(cycle_id=1, phase=7, status="completed"),
                _make_cycle(cycle_id=2, phase=7, status="completed"),
                # No cycle_id=3 record — anomalous state
            ],
        )
        sc, sp = resolve(st)
        assert sc == 3, f"Expected start_cycle=3, got {sc}"
        assert sp == 1, (
            f"Fallback must default to start_phase=1, not {sp}. "
            "If sp != 1 the fallback is reading st.phase instead of returning a safe default."
        )

    @pytest.mark.asyncio
    async def test_run_multi_cycle_log_includes_resumed_from(self, tmp_path: Path) -> None:
        """run_multi_cycle log line includes resumed_from=state.cycles[X-1].phase."""
        from unittest.mock import AsyncMock, MagicMock, patch

        from code_generator import state as st_mod
        from code_generator.orchestrator import cycle_loop

        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir()
        cycle = _make_cycle(cycle_id=2, phase=6, status="open")
        st = st_mod.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=2,
            phase=None,
            cycles=[
                _make_cycle(cycle_id=1, phase=7, status="completed"),
                cycle,
            ],
        )
        st_mod.save_state(state_dir / "state.json", st)

        log_messages: list[str] = []

        class _CapturingLogger(logging.Logger):
            def info(self, msg: str, *args: object, **kwargs: object) -> None:  # type: ignore[override]
                log_messages.append(msg % args if args else msg)

        capturing_log = _CapturingLogger("test")

        with (
            patch.object(cycle_loop, "setup_phase_logger", return_value=capturing_log),
            patch.object(cycle_loop, "_run_phases", new=AsyncMock(return_value=st)),
            patch.object(st_mod, "save_state"),
        ):
            await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=capturing_log,
                start_cycle=2,
                start_phase=7,
            )

        assert any("resumed_from" in msg for msg in log_messages), (
            f"Expected 'resumed_from' in log messages, got: {log_messages}"
        )
        assert any("state.cycles[1].phase=6" in msg for msg in log_messages), (
            f"Expected 'state.cycles[1].phase=6' in log, got: {log_messages}"
        )


class TestContinueAfterFinalPhase:
    def test_continue_single_mode_after_final_phase(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue when st.phase=7 passes start_phase=8 to run_single_mode."""
        monkeypatch.chdir(tmp_path)
        _cg_dir_with_phase(tmp_path, phase=7, mode="single")
        captured: list[int] = []

        async def mock_single(state, *_args, start_phase=1, **_kwargs):
            captured.append(start_phase)

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)
        result = runner.invoke(app, ["generate", "--continue"])
        assert result.exit_code == 0
        assert captured == [8]

    def test_dispatch_continue_with_cycle_override(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue --cycle 5 in multi-cycle mode: start_cycle=5 overrides continue-derived."""
        monkeypatch.chdir(tmp_path)
        _cg_dir_with_cycle_phase(tmp_path, current_cycle=2, phase=3, mode="multi-cycle")
        captured: list[dict] = []

        async def mock_multi(
            state, project_dir, *, runner_module, logger=None, start_cycle=None, start_phase=1
        ):
            captured.append({"start_cycle": start_cycle, "start_phase": start_phase})

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)
        _mock_phase0_single(monkeypatch)
        result = runner.invoke(app, ["generate", "--continue", "--cycle", "5"])
        assert result.exit_code == 0
        assert len(captured) == 1
        assert captured[0]["start_cycle"] == 5
        assert captured[0]["start_phase"] == 1  # no --phase given, defaults to 1


# ---------------------------------------------------------------------------
# Re-run detection: no-op exit path
# ---------------------------------------------------------------------------


def _cg_dir_with_hash(
    tmp_path: Path,
    *,
    mode: str = "single",
    phase: int | None = None,
    requirements_hash: str | None = None,
    cycles: list[state_module.CycleState] | None = None,
) -> tuple[Path, Path]:
    """Create .code-generator/ with state.json and requirements.md, return (cg_dir, req_path)."""
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    req = cg / "requirements.md"
    req.write_text("# Requirements\nBuild something.", encoding="utf-8")
    st = state_module.State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        phase=phase,
        requirements_hash=requirements_hash,
        cycles=cycles or [],
    )
    state_module.save_state(cg / "state.json", st)
    return cg, req


class TestNoOpDetection:
    def test_no_op_state_exits_0_with_message(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When state is complete and hash matches, exits 0 with 'nothing to do' message."""
        from code_generator.state import compute_requirements_hash

        monkeypatch.chdir(tmp_path)
        cg, req = _cg_dir_with_hash(tmp_path, mode="single", phase=7)
        current_hash = compute_requirements_hash(req)

        # Update state with the matching hash.
        st = state_module.load_state(cg / "state.json")
        st.requirements_hash = current_hash
        state_module.save_state(cg / "state.json", st)

        from code_generator.orchestrator import cycle_loop

        orchestrator_called: list[bool] = []

        async def mock_single(*args, **kwargs):
            orchestrator_called.append(True)

        async def mock_multi(*args, **kwargs):
            orchestrator_called.append(True)

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)

        result = runner.invoke(app, ["generate"])

        assert result.exit_code == 0
        assert orchestrator_called == []
        output = result.output.lower()
        assert "nothing to do" in output or "complete" in output

    def test_no_op_multi_cycle_all_completed_exits_0(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Multi-cycle mode with all cycles completed and matching hash exits 0."""
        from code_generator.state import CycleState, compute_requirements_hash

        monkeypatch.chdir(tmp_path)

        completed_cycle = CycleState(
            id=1,
            name="cycle-1",
            milestone_number=1,
            milestone_title="Cycle 1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
        )
        cg, req = _cg_dir_with_hash(
            tmp_path,
            mode="multi-cycle",
            cycles=[completed_cycle],
        )
        current_hash = compute_requirements_hash(req)

        st = state_module.load_state(cg / "state.json")
        st.requirements_hash = current_hash
        state_module.save_state(cg / "state.json", st)

        from code_generator.orchestrator import cycle_loop

        orchestrator_called: list[bool] = []

        async def mock_multi(*args, **kwargs):
            orchestrator_called.append(True)

        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)

        result = runner.invoke(app, ["generate"])

        assert result.exit_code == 0
        assert orchestrator_called == []

    def test_continue_flag_bypasses_no_op_detection(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue bypasses no-op detection and calls orchestrator even when run is complete."""
        from code_generator.state import compute_requirements_hash

        monkeypatch.chdir(tmp_path)
        cg, req = _cg_dir_with_hash(tmp_path, mode="single", phase=7)
        current_hash = compute_requirements_hash(req)

        st = state_module.load_state(cg / "state.json")
        st.requirements_hash = current_hash
        state_module.save_state(cg / "state.json", st)

        from code_generator.orchestrator import cycle_loop

        orchestrator_called: list[bool] = []

        async def mock_single(*args, **kwargs):
            orchestrator_called.append(True)

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue"])

        assert result.exit_code == 0
        assert orchestrator_called == [True]

    def test_phase_flag_bypasses_no_op_detection(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--phase N bypasses no-op detection and calls orchestrator even when run is complete."""
        from code_generator.state import compute_requirements_hash

        monkeypatch.chdir(tmp_path)
        cg, req = _cg_dir_with_hash(tmp_path, mode="single", phase=7)
        current_hash = compute_requirements_hash(req)

        st = state_module.load_state(cg / "state.json")
        st.requirements_hash = current_hash
        state_module.save_state(cg / "state.json", st)

        from code_generator.orchestrator import cycle_loop

        orchestrator_called: list[bool] = []

        async def mock_single(*args, **kwargs):
            orchestrator_called.append(True)

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--phase", "5"])

        assert result.exit_code == 0
        assert orchestrator_called == [True]

    def test_first_run_stores_hash_in_state(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """First run stores the requirements hash in state.json atomically."""
        from code_generator.state import compute_requirements_hash

        monkeypatch.chdir(tmp_path)
        cg, req = _cg_dir_with_hash(tmp_path, mode="single", phase=None)
        # Ensure no hash stored initially.
        st_before = state_module.load_state(cg / "state.json")
        assert st_before.requirements_hash is None

        expected_hash = compute_requirements_hash(req)

        from code_generator.orchestrator import cycle_loop

        async def mock_single(*args, **kwargs):
            pass

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate"])
        assert result.exit_code == 0

        st_after = state_module.load_state(cg / "state.json")
        assert st_after.requirements_hash == expected_hash

    def test_delta_detection_updates_hash_in_state(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Delta run (changed requirements) updates requirements_hash in state.json."""
        from code_generator.state import compute_requirements_hash

        monkeypatch.chdir(tmp_path)
        cg, req = _cg_dir_with_hash(tmp_path, mode="single", phase=3)
        # Store an old (different) hash.
        old_hash = "a" * 64
        st = state_module.load_state(cg / "state.json")
        st.requirements_hash = old_hash
        state_module.save_state(cg / "state.json", st)

        new_hash = compute_requirements_hash(req)
        assert new_hash != old_hash

        from code_generator.orchestrator import cycle_loop

        async def mock_single(*args, **kwargs):
            pass

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate"])
        assert result.exit_code == 0

        st_after = state_module.load_state(cg / "state.json")
        assert st_after.requirements_hash == new_hash


# ---------------------------------------------------------------------------
# --continue resets failed cycles back to open (retry-on-continue)
# ---------------------------------------------------------------------------


class TestContinueResetsFailedCycles:
    """Regression guard: `--continue` must retry cycles marked `status=failed`.

    When a cycle crashes mid-run, `cycle_loop.run_multi_cycle` sets
    `cycle.status = "failed"` and persists `state.last_error`. Without the
    reset, `_eligible_cycles` filters out failed cycles and `--continue`
    prints "all eligible cycles complete" without actually running anything.
    """

    def test_continue_resets_failed_cycle_to_open(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue flips cycles[0].status from 'failed' back to 'open' and clears last_error."""
        monkeypatch.chdir(tmp_path)

        cg = tmp_path / ".code-generator"
        cg.mkdir(parents=True, exist_ok=True)
        st = state_module.State(
            mode="multi-cycle",  # type: ignore[arg-type]
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=1,
            phase=None,
            cycles=[
                _make_cycle(cycle_id=1, phase=1, status="failed"),
                _make_cycle(cycle_id=2, phase=0, status="open"),
            ],
        )
        st.last_error = "SDK session exhausted max_turns budget"
        state_module.save_state(cg / "state.json", st)

        captured: list[dict] = []

        async def mock_multi(state, *_args, start_cycle=None, start_phase=1, **_kwargs):
            captured.append({"start_cycle": start_cycle, "start_phase": start_phase})
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue"])
        assert result.exit_code == 0, result.output

        st_after = state_module.load_state(cg / "state.json")
        assert st_after.cycles[0].status == "open"
        assert st_after.last_error is None
        assert captured == [{"start_cycle": 1, "start_phase": 2}]

    def test_continue_resets_only_target_cycle_when_cycle_flag_set(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue --cycle 2 resets cycle 2 only, leaves cycle 1 failed."""
        monkeypatch.chdir(tmp_path)

        cg = tmp_path / ".code-generator"
        cg.mkdir(parents=True, exist_ok=True)
        st = state_module.State(
            mode="multi-cycle",  # type: ignore[arg-type]
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=2,
            phase=None,
            cycles=[
                _make_cycle(cycle_id=1, phase=3, status="failed"),
                _make_cycle(cycle_id=2, phase=4, status="failed"),
            ],
        )
        state_module.save_state(cg / "state.json", st)

        async def mock_multi(*_args, **_kwargs):
            return None

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(
            app, ["generate", "--continue", "--cycle", "2", "--mode", "multi-cycle"]
        )
        assert result.exit_code == 0, result.output

        st_after = state_module.load_state(cg / "state.json")
        assert st_after.cycles[0].status == "failed"
        assert st_after.cycles[1].status == "open"

    def test_continue_without_failed_cycles_is_noop_on_reset(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue on a state with no failed cycles does not mutate status."""
        monkeypatch.chdir(tmp_path)

        cg = tmp_path / ".code-generator"
        cg.mkdir(parents=True, exist_ok=True)
        st = state_module.State(
            mode="multi-cycle",  # type: ignore[arg-type]
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=1,
            phase=None,
            cycles=[_make_cycle(cycle_id=1, phase=3, status="open")],
        )
        state_module.save_state(cg / "state.json", st)

        async def mock_multi(*_args, **_kwargs):
            return None

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_multi_cycle", mock_multi)
        _mock_phase0_single(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue"])
        assert result.exit_code == 0, result.output

        st_after = state_module.load_state(cg / "state.json")
        assert st_after.cycles[0].status == "open"
