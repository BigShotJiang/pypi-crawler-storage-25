"""Tests for the `code-generator init` command."""

from pathlib import Path

import pytest
from typer.testing import CliRunner

from code_generator import state as state_module
from code_generator.cli import app

runner = CliRunner()


def test_default_creates_dot_code_generator(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["init"])
    assert result.exit_code == 0
    assert (tmp_path / ".code-generator").is_dir()
    assert (tmp_path / ".code-generator" / "requirements.md").exists()


def test_default_requirements_md_contains_base_content(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    runner.invoke(app, ["init"])
    content = (tmp_path / ".code-generator" / "requirements.md").read_text()
    assert "## Tech Stack" in content
    assert "## Features" in content
    assert "## Description" in content


def test_fastapi_template_adds_api_endpoints_section(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["init", "--template", "fastapi"])
    assert result.exit_code == 0
    content = (tmp_path / ".code-generator" / "requirements.md").read_text()
    assert "## API Endpoints" in content
    assert "## Database Models" in content
    assert "## Authentication" in content


def test_angular_template_adds_pages_section(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    runner.invoke(app, ["init", "--template", "angular"])
    content = (tmp_path / ".code-generator" / "requirements.md").read_text()
    assert "## Pages and Routing" in content
    assert "## State and Data" in content
    assert "## Design System" in content


def test_nestjs_template_adds_modules_section(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    runner.invoke(app, ["init", "--template", "nestjs"])
    content = (tmp_path / ".code-generator" / "requirements.md").read_text()
    assert "## Modules" in content
    assert "## Authentication and Guards" in content
    assert "## Database" in content


def test_fullstack_template_adds_both_fastapi_and_angular_sections(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    runner.invoke(app, ["init", "--template", "fullstack"])
    content = (tmp_path / ".code-generator" / "requirements.md").read_text()
    assert "## API Endpoints" in content
    assert "## Pages and Routing" in content


def test_python_cli_template_adds_cli_commands_section(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    runner.invoke(app, ["init", "--template", "python-cli"])
    content = (tmp_path / ".code-generator" / "requirements.md").read_text()
    assert "## CLI Commands" in content
    assert "## Configuration" in content
    assert "## Output format" in content


def test_finance_template_adds_data_sources_section(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    runner.invoke(app, ["init", "--template", "finance"])
    content = (tmp_path / ".code-generator" / "requirements.md").read_text()
    assert "## Data Sources" in content
    assert "## Portfolio Models" in content
    assert "## Risk Measures" in content


def test_second_run_without_force_fails(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    runner.invoke(app, ["init"])
    result = runner.invoke(app, ["init"])
    assert result.exit_code != 0


def test_force_overwrites_existing(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    runner.invoke(app, ["init"])
    # Corrupt the file to confirm overwrite happens
    (tmp_path / ".code-generator" / "requirements.md").write_text("STALE")
    result = runner.invoke(app, ["init", "--force"])
    assert result.exit_code == 0
    content = (tmp_path / ".code-generator" / "requirements.md").read_text()
    assert "## Tech Stack" in content
    assert "STALE" not in content


def test_state_json_is_valid_and_loadable(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    runner.invoke(app, ["init"])
    state_path = tmp_path / ".code-generator" / "state.json"
    assert state_path.exists()
    loaded = state_module.load_state(state_path)
    assert loaded.mode == "unknown"


def test_unknown_template_exits_nonzero(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["init", "--template", "nonexistent"])
    assert result.exit_code != 0
