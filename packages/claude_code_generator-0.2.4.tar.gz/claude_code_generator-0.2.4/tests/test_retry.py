"""Tests for retry.with_backoff and retry.CircuitBreaker — Issue #13."""

from __future__ import annotations

import pytest

from code_generator.runner.retry import (
    CircuitBreaker,
    CircuitOpen,
    TransientRunnerError,
    _is_transient,
    with_backoff,
)
from code_generator.runner.sdk_runner import OverageAbort, RateLimitHit

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _rate_limit_hit() -> RateLimitHit:
    return RateLimitHit(resets_at=9_999_999_999, rate_limit_type="five_hour")


def _transient() -> TransientRunnerError:
    return TransientRunnerError("temporary failure")


async def _succeed(value: str = "ok") -> str:
    return value


async def _raise(exc: BaseException) -> str:
    raise exc


# ---------------------------------------------------------------------------
# with_backoff tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_backoff_schedule_matches_expected(monkeypatch: pytest.MonkeyPatch) -> None:
    """Backoff sleep calls should follow [10, 20, 40, 80, 120] sequence."""
    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    call_count = [0]

    async def factory() -> str:
        call_count[0] += 1
        if call_count[0] < 6:  # fail 5 times
            raise TransientRunnerError("oops")
        return "done"

    # Allows 6 attempts so 5 sleeps happen; but default is 5 attempts so we
    # expect it to exhaust attempts and re-raise.
    with pytest.raises(TransientRunnerError):
        await with_backoff(factory, attempts=5, sleep_fn=fake_sleep)

    assert sleep_calls == [10, 20, 40, 80, 120]


@pytest.mark.asyncio
async def test_transient_errors_retry_until_success() -> None:
    """TransientRunnerError retries; eventual success returns value."""
    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    call_count = [0]

    async def factory() -> str:
        call_count[0] += 1
        if call_count[0] < 3:
            raise TransientRunnerError("tmp")
        return "success"

    result = await with_backoff(factory, attempts=5, sleep_fn=fake_sleep)
    assert result == "success"
    assert call_count[0] == 3
    assert sleep_calls == [10, 20]


@pytest.mark.asyncio
async def test_non_transient_error_propagates_immediately() -> None:
    """ValueError is not transient — propagates without retry."""
    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    call_count = [0]

    async def factory() -> str:
        call_count[0] += 1
        raise ValueError("not transient")

    with pytest.raises(ValueError):
        await with_backoff(factory, attempts=5, sleep_fn=fake_sleep)

    assert call_count[0] == 1
    assert sleep_calls == []


@pytest.mark.asyncio
async def test_rate_limit_hit_propagates_without_backoff() -> None:
    """RateLimitHit bypasses backoff — propagates immediately."""
    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    call_count = [0]

    async def factory() -> str:
        call_count[0] += 1
        raise _rate_limit_hit()

    with pytest.raises(RateLimitHit):
        await with_backoff(factory, attempts=5, sleep_fn=fake_sleep)

    assert call_count[0] == 1
    assert sleep_calls == []


@pytest.mark.asyncio
async def test_overage_abort_propagates_without_backoff() -> None:
    """OverageAbort bypasses backoff — propagates immediately."""
    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    call_count = [0]

    async def factory() -> str:
        call_count[0] += 1
        raise OverageAbort("billing active")

    with pytest.raises(OverageAbort):
        await with_backoff(factory, attempts=5, sleep_fn=fake_sleep)

    assert call_count[0] == 1
    assert sleep_calls == []


# ---------------------------------------------------------------------------
# CircuitBreaker tests
# ---------------------------------------------------------------------------


def test_circuit_opens_after_max_failures() -> None:
    """CircuitBreaker opens after max_failures consecutive failures."""
    breaker = CircuitBreaker(max_failures=3)
    breaker.record_failure(TransientRunnerError("1"))
    breaker.record_failure(TransientRunnerError("2"))
    with pytest.raises(CircuitOpen):
        breaker.record_failure(TransientRunnerError("3"))


def test_success_resets_failure_counter() -> None:
    """A success resets the failure counter so circuit stays closed."""
    breaker = CircuitBreaker(max_failures=3)
    breaker.record_failure(TransientRunnerError("1"))
    breaker.record_failure(TransientRunnerError("2"))
    breaker.record_success()
    # Should not raise — counter was reset.
    breaker.record_failure(TransientRunnerError("after reset"))
    breaker.record_failure(TransientRunnerError("after reset 2"))
    with pytest.raises(CircuitOpen):
        breaker.record_failure(TransientRunnerError("trips again"))


def test_rate_limit_hit_does_not_trip_breaker() -> None:
    """RateLimitHit must not increment the failure counter."""
    breaker = CircuitBreaker(max_failures=3)
    # Calling record_failure with RateLimitHit should be a no-op for the counter.
    for _ in range(10):
        breaker.record_failure(_rate_limit_hit())
    # Counter was never incremented — no CircuitOpen raised above.
    # Verify by tripping with a real error after only 3 tries:
    breaker.record_failure(TransientRunnerError("a"))
    breaker.record_failure(TransientRunnerError("b"))
    with pytest.raises(CircuitOpen):
        breaker.record_failure(TransientRunnerError("c"))


def test_overage_abort_does_not_trip_breaker() -> None:
    """OverageAbort must not increment the failure counter."""
    breaker = CircuitBreaker(max_failures=3)
    for _ in range(10):
        breaker.record_failure(OverageAbort("billing"))
    # Still closed — only real transient errors count.
    breaker.record_failure(TransientRunnerError("x"))
    breaker.record_failure(TransientRunnerError("y"))
    with pytest.raises(CircuitOpen):
        breaker.record_failure(TransientRunnerError("z"))


@pytest.mark.asyncio
async def test_with_backoff_uses_breaker_on_failure() -> None:
    """with_backoff passes breaker; CircuitOpen raised after 3 failures."""
    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    breaker = CircuitBreaker(max_failures=3)
    call_count = [0]

    async def factory() -> str:
        call_count[0] += 1
        raise TransientRunnerError("fail")

    with pytest.raises(CircuitOpen):
        await with_backoff(factory, attempts=10, sleep_fn=fake_sleep, breaker=breaker)

    # Circuit opened after 3 failures; 4th call would trip it.
    assert call_count[0] == 3


@pytest.mark.asyncio
async def test_with_backoff_records_success_on_breaker() -> None:
    """with_backoff calls breaker.record_success when it succeeds."""
    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    breaker = CircuitBreaker(max_failures=3)
    # Prime one failure so we're at 1/3.
    breaker.record_failure(TransientRunnerError("a"))

    call_count = [0]

    async def factory() -> str:
        call_count[0] += 1
        if call_count[0] == 1:
            raise TransientRunnerError("one more fail")
        return "ok"

    result = await with_backoff(factory, attempts=5, sleep_fn=fake_sleep, breaker=breaker)
    assert result == "ok"

    # After the success, the breaker was reset — now it takes 3 fresh failures to trip.
    breaker.record_failure(TransientRunnerError("reset-1"))
    breaker.record_failure(TransientRunnerError("reset-2"))
    with pytest.raises(CircuitOpen):
        breaker.record_failure(TransientRunnerError("reset-3"))


# ---------------------------------------------------------------------------
# _is_transient tests (Issue #53)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "exc",
    [
        TimeoutError(),
        ConnectionError(),
        OSError(),
        TransientRunnerError(),
    ],
)
def test_is_transient_returns_true_for_transient_types(exc: BaseException) -> None:
    """_is_transient returns True for all registered transient exception types."""
    assert _is_transient(exc) is True


@pytest.mark.parametrize(
    "exc",
    [
        ValueError(),
        RuntimeError(),
        KeyError(),
    ],
)
def test_is_transient_returns_false_for_non_transient_types(exc: BaseException) -> None:
    """_is_transient returns False for non-transient exception types."""
    assert _is_transient(exc) is False


# ---------------------------------------------------------------------------
# with_backoff edge-case tests (Issue #53)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_with_backoff_attempts_1_runs_factory_once_no_sleep() -> None:
    """with_backoff(attempts=1) runs factory exactly once and sleeps zero times."""
    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    call_count = [0]

    async def factory() -> str:
        call_count[0] += 1
        return "done"

    result = await with_backoff(factory, attempts=1, sleep_fn=fake_sleep)

    assert result == "done"
    assert call_count[0] == 1
    assert sleep_calls == []


@pytest.mark.asyncio
async def test_with_backoff_attempts_0_raises_assertion_error() -> None:
    """with_backoff(attempts=0) raises AssertionError.

    range(0) means the loop body never executes, so last_exc stays None and
    the guard ``assert last_exc is not None`` fires.  This test documents that
    intentional edge-case behavior.
    """

    async def factory() -> str:
        return "should not run"

    with pytest.raises(AssertionError):
        await with_backoff(factory, attempts=0)
