"""Tests for code_generator.agents — tech-stack detector and §7 matrix."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from code_generator.agents import AgentSelection, detect

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Fixtures — one per matrix row
# ---------------------------------------------------------------------------


@pytest.fixture
def angular_fastapi_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nAngular + FastAPI + PostgreSQL\n\n## Other\n\nstuff",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def angular_nestjs_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nAngular + NestJS\n\n## Other\n\nstuff",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def angular_only_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nAngular 17, Tailwind CSS\n\n## Other\n\nstuff",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def angular_ng_space_req(tmp_path: Path) -> Path:
    """Angular detected via ' ng ' keyword."""
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nBuilt with ng router and signals\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def fastapi_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nFastAPI + SQLAlchemy + Postgres\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def python_api_req(tmp_path: Path) -> Path:
    """FastAPI detected via 'python api' keyword."""
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nPython API with uvicorn\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def nestjs_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nNestJS + Prisma + PostgreSQL\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def nest_keyword_req(tmp_path: Path) -> Path:
    """NestJS detected via 'nest' keyword."""
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nnest framework with TypeScript\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def portfolio_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nPortfolio optimization with riskfolio-lib\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def skfolio_req(tmp_path: Path) -> Path:
    """Portfolio detected via 'skfolio' keyword."""
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nskfolio + yfinance\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def baml_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nBAML + Python (LLM orchestration)\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def llm_function_req(tmp_path: Path) -> Path:
    """BAML detected via 'llm function' keyword."""
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nLLM function pipeline with structured output\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def typer_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nTyper CLI + Python 3.11\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def click_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nClick framework for Python\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def python_cli_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nPython CLI tool\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def generic_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nSomething totally unknown\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def missing_req(tmp_path: Path) -> Path:
    return tmp_path / "requirements.md"  # Does NOT exist.


@pytest.fixture
def no_tech_stack_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\nNo tech stack section here.\n\n",
        encoding="utf-8",
    )
    return p


# ---------------------------------------------------------------------------
# AgentSelection dataclass
# ---------------------------------------------------------------------------


class TestAgentSelection:
    def test_is_frozen(self) -> None:
        sel = AgentSelection(primary=("python-pro",), support=(), skills=("solid-principles",))
        from dataclasses import FrozenInstanceError  # type: ignore[attr-defined]

        with pytest.raises(FrozenInstanceError):
            sel.primary = ("other",)  # type: ignore[misc]

    def test_equality(self) -> None:
        a = AgentSelection(primary=("x",), support=("y",), skills=("z",))
        b = AgentSelection(primary=("x",), support=("y",), skills=("z",))
        assert a == b


# ---------------------------------------------------------------------------
# detect — full-stack combos (checked first)
# ---------------------------------------------------------------------------


class TestDetectAngularFastAPI:
    def test_primary_agents(self, angular_fastapi_req: Path) -> None:
        sel = detect(angular_fastapi_req)
        assert "frontend-developer" in sel.primary
        assert "python-pro" in sel.primary
        assert "fastapi-expert-agent" in sel.primary

    def test_support_agents(self, angular_fastapi_req: Path) -> None:
        sel = detect(angular_fastapi_req)
        assert "typescript-pro" in sel.support
        assert "supabase-connection-expert" in sel.support

    def test_skills(self, angular_fastapi_req: Path) -> None:
        sel = detect(angular_fastapi_req)
        assert "solid-principles" in sel.skills
        assert "python-expert" in sel.skills


class TestDetectAngularNestJS:
    def test_primary_agents(self, angular_nestjs_req: Path) -> None:
        sel = detect(angular_nestjs_req)
        assert "frontend-developer" in sel.primary
        assert "nestjs-expert" in sel.primary

    def test_support_agents(self, angular_nestjs_req: Path) -> None:
        sel = detect(angular_nestjs_req)
        assert "typescript-pro" in sel.support
        assert "supabase-connection-expert" in sel.support

    def test_skills(self, angular_nestjs_req: Path) -> None:
        sel = detect(angular_nestjs_req)
        assert "solid-principles" in sel.skills


# ---------------------------------------------------------------------------
# detect — single-stack
# ---------------------------------------------------------------------------


class TestDetectAngularOnly:
    def test_primary(self, angular_only_req: Path) -> None:
        sel = detect(angular_only_req)
        assert "frontend-developer" in sel.primary
        assert "python-pro" not in sel.primary

    def test_ng_space_keyword(self, angular_ng_space_req: Path) -> None:
        sel = detect(angular_ng_space_req)
        assert "frontend-developer" in sel.primary


class TestDetectFastAPI:
    def test_primary(self, fastapi_req: Path) -> None:
        sel = detect(fastapi_req)
        assert "python-pro" in sel.primary
        assert "fastapi-expert-agent" in sel.primary

    def test_python_api_keyword(self, python_api_req: Path) -> None:
        sel = detect(python_api_req)
        assert "fastapi-expert-agent" in sel.primary

    def test_skills(self, fastapi_req: Path) -> None:
        sel = detect(fastapi_req)
        assert "python-expert" in sel.skills


class TestDetectNestJS:
    def test_primary(self, nestjs_req: Path) -> None:
        sel = detect(nestjs_req)
        assert "nestjs-expert" in sel.primary

    def test_nest_keyword(self, nest_keyword_req: Path) -> None:
        sel = detect(nest_keyword_req)
        assert "nestjs-expert" in sel.primary


class TestDetectPortfolio:
    def test_riskfolio_keyword(self, portfolio_req: Path) -> None:
        sel = detect(portfolio_req)
        assert "riskfolio-expert" in sel.primary
        assert "python-pro" in sel.primary

    def test_skfolio_keyword(self, skfolio_req: Path) -> None:
        sel = detect(skfolio_req)
        assert "riskfolio-expert" in sel.primary

    def test_skills(self, portfolio_req: Path) -> None:
        sel = detect(portfolio_req)
        assert "skfolio" in sel.skills
        assert "yfinance" in sel.skills


class TestDetectBAML:
    def test_baml_keyword(self, baml_req: Path) -> None:
        sel = detect(baml_req)
        assert "baml-expert-agent" in sel.primary

    def test_llm_function_keyword(self, llm_function_req: Path) -> None:
        sel = detect(llm_function_req)
        assert "baml-expert-agent" in sel.primary

    def test_skills(self, baml_req: Path) -> None:
        sel = detect(baml_req)
        assert "solid-principles" in sel.skills


class TestDetectPythonCLI:
    def test_typer_keyword(self, typer_req: Path) -> None:
        sel = detect(typer_req)
        assert "python-pro" in sel.primary

    def test_click_keyword(self, click_req: Path) -> None:
        sel = detect(click_req)
        assert "python-pro" in sel.primary

    def test_python_cli_keyword(self, python_cli_req: Path) -> None:
        sel = detect(python_cli_req)
        assert "python-pro" in sel.primary

    def test_skills(self, typer_req: Path) -> None:
        sel = detect(typer_req)
        assert "solid-principles" in sel.skills
        assert "python-expert" in sel.skills


# ---------------------------------------------------------------------------
# detect — fallback
# ---------------------------------------------------------------------------


class TestDetectFallback:
    def test_missing_file(self, missing_req: Path) -> None:
        sel = detect(missing_req)
        assert sel.primary == ("python-pro",)
        assert sel.skills == ("solid-principles",)

    def test_no_tech_stack_section(self, no_tech_stack_req: Path) -> None:
        sel = detect(no_tech_stack_req)
        assert sel.primary == ("python-pro",)

    def test_unknown_keywords(self, generic_req: Path) -> None:
        sel = detect(generic_req)
        assert sel.primary == ("python-pro",)
        assert sel.skills == ("solid-principles",)


# ---------------------------------------------------------------------------
# Ordering: full-stack combos beat single-stack
# ---------------------------------------------------------------------------


class TestDetectOrdering:
    def test_angular_fastapi_beats_angular_only(self, tmp_path: Path) -> None:
        """When both angular and fastapi are present, the full-stack combo wins."""
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nAngular + FastAPI\n", encoding="utf-8")
        sel = detect(p)
        assert "fastapi-expert-agent" in sel.primary  # Not angular-only

    def test_angular_nestjs_beats_angular_only(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nAngular + NestJS\n", encoding="utf-8")
        sel = detect(p)
        assert "nestjs-expert" in sel.primary
