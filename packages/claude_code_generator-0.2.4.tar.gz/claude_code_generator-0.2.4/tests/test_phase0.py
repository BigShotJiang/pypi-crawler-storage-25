"""Tests for code_generator.orchestrator.phase0_complexity."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import phase0_complexity
from code_generator.orchestrator.phase0_complexity import (
    CyclePlan,
    Phase0Output,
    parse_phase0_output,
    parse_raw_cycle_plan,
)
from code_generator.runner.sdk_runner import RunResult
from code_generator.runner.types import Phase0SchemaError

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result(text: str) -> RunResult:
    return RunResult(text=text, session_id=None, tokens_in=None, tokens_out=None)


def _make_state(tmp_path: Path) -> _state.State:
    st = _state.load_state(tmp_path / "missing.json")
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    _state.save_state(state_dir / "state.json", st)
    return st


def _make_runner(text: str) -> MagicMock:
    runner = MagicMock()
    runner.run = AsyncMock(return_value=_make_run_result(text))
    return runner


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPhase0Run:
    @pytest.mark.asyncio
    async def test_single_mode_parsed(self, tmp_path: Path) -> None:
        payload = json.dumps({"mode": "single", "cycles": []})
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result(payload)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            result = await phase0_complexity.run(
                state,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert result.mode == "single"

    @pytest.mark.asyncio
    async def test_multi_cycle_mode_with_cycles(self, tmp_path: Path) -> None:
        cycles = [
            {
                "id": 1,
                "name": "DB",
                "milestone_title": "Cycle 1 — DB",
                "depends_on": [],
                "scope": "db",
            },
            {
                "id": 2,
                "name": "API",
                "milestone_title": "Cycle 2 — API",
                "depends_on": [1],
                "scope": "api",
            },
        ]
        payload = json.dumps({"mode": "multi-cycle", "cycles": cycles})
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result(payload)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            result = await phase0_complexity.run(
                state,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert result.mode == "multi-cycle"
        assert len(result.cycles) == 2
        assert result.cycles[0].name == "DB"
        assert result.cycles[1].depends_on == [1]

    @pytest.mark.asyncio
    async def test_json_embedded_in_prose(self, tmp_path: Path) -> None:
        """Parser strips surrounding prose and finds the first JSON object."""
        text = 'Sure! Here is your output: {"mode": "single", "cycles": []} — done.'
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result(text)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            result = await phase0_complexity.run(
                state,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert result.mode == "single"

    @pytest.mark.asyncio
    async def test_fallback_on_persistent_json_failure(self, tmp_path: Path) -> None:
        """After _MAX_JSON_RETRIES failures, mode falls back to 'single'."""
        state = _make_state(tmp_path)
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            return _make_run_result("not json at all")

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            result = await phase0_complexity.run(
                state,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert result.mode == "single"
        # Should have tried _MAX_JSON_RETRIES + 1 times total.
        assert call_count == phase0_complexity._MAX_JSON_RETRIES + 1

    @pytest.mark.asyncio
    async def test_invalid_mode_raises_schema_error(self, tmp_path: Path) -> None:
        """Valid JSON with invalid mode enum value raises Phase0SchemaError."""
        payload = json.dumps({"mode": "banana", "cycles": []})
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result(payload)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            with pytest.raises(Phase0SchemaError):
                await phase0_complexity.run(
                    state,
                    tmp_path,
                    runner_module=MagicMock(),
                    logger=logging.getLogger("test"),
                )

    @pytest.mark.asyncio
    async def test_options_use_opus_model(self, tmp_path: Path) -> None:
        payload = json.dumps({"mode": "single", "cycles": []})
        state = _make_state(tmp_path)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result(payload)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase0_complexity.run(
                state,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].model == "claude-opus-4-6"

    @pytest.mark.asyncio
    async def test_effort_hints_parsed_into_cycle(self, tmp_path: Path) -> None:
        """effort_hints array in each cycle JSON is stored in CycleState."""
        cycles = [
            {
                "id": 1,
                "name": "DB",
                "milestone_title": "Cycle 1 — DB",
                "depends_on": [],
                "scope": "db",
                "effort_hints": [
                    {"scope_keyword": "database migration", "effort": "high"},
                    {"scope_keyword": "simple seed script", "effort": "low"},
                ],
            }
        ]
        payload = json.dumps({"mode": "multi-cycle", "cycles": cycles})
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result(payload)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            result = await phase0_complexity.run(
                state,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        hints = result.cycles[0].effort_hints
        assert len(hints) == 2
        assert hints[0].scope_keyword == "database migration"
        assert hints[0].effort == "high"
        assert hints[1].scope_keyword == "simple seed script"
        assert hints[1].effort == "low"

    @pytest.mark.asyncio
    async def test_effort_hints_parsed_for_single_mode(self, tmp_path: Path) -> None:
        """Top-level effort_hints in single mode JSON is stored in State."""
        payload = json.dumps(
            {
                "mode": "single",
                "cycles": [],
                "effort_hints": [
                    {"scope_keyword": "complex auth flow", "effort": "high"},
                ],
            }
        )
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result(payload)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            result = await phase0_complexity.run(
                state,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(result.effort_hints) == 1
        assert result.effort_hints[0].scope_keyword == "complex auth flow"
        assert result.effort_hints[0].effort == "high"

    @pytest.mark.asyncio
    async def test_missing_effort_hints_defaults_to_empty_list(self, tmp_path: Path) -> None:
        """JSON without effort_hints results in empty list (backward compat)."""
        cycles = [
            {
                "id": 1,
                "name": "API",
                "milestone_title": "Cycle 1 — API",
                "depends_on": [],
                "scope": "api",
                # no effort_hints key
            }
        ]
        payload = json.dumps({"mode": "multi-cycle", "cycles": cycles})
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result(payload)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            result = await phase0_complexity.run(
                state,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert result.cycles[0].effort_hints == []


# ---------------------------------------------------------------------------
# Tests for Pydantic schema models and validation functions
# ---------------------------------------------------------------------------


class TestPhase0SchemaValidation:
    def test_valid_single_mode_round_trips(self) -> None:
        """Valid single-mode output parses correctly."""
        raw = {
            "mode": "single",
            "cycles": [],
            "reason": "Small project",
            "effort_hints": [{"scope_keyword": "auth", "effort": "high"}],
        }
        output = parse_phase0_output(raw)

        assert output.mode == "single"
        assert output.cycles == []
        assert output.reason == "Small project"
        assert len(output.effort_hints) == 1
        assert output.effort_hints[0].scope_keyword == "auth"
        assert output.effort_hints[0].effort == "high"

    def test_valid_multi_cycle_mode_round_trips(self) -> None:
        """Valid multi-cycle output with cycles parses correctly."""
        raw = {
            "mode": "multi-cycle",
            "cycles": [
                {
                    "id": 1,
                    "name": "DB",
                    "milestone_title": "Cycle 1 — DB",
                    "depends_on": [],
                    "scope": "database",
                    "estimated_issues": 4,
                    "effort_hints": [{"scope_keyword": "migration", "effort": "high"}],
                },
                {
                    "id": 2,
                    "name": "API",
                    "milestone_title": "Cycle 2 — API",
                    "depends_on": [1],
                    "scope": "rest api",
                },
            ],
        }
        output = parse_phase0_output(raw)

        assert output.mode == "multi-cycle"
        assert len(output.cycles) == 2
        assert output.cycles[0].id == 1
        assert output.cycles[0].estimated_issues == 4
        assert len(output.cycles[0].effort_hints) == 1
        assert output.cycles[1].depends_on == [1]
        assert output.cycles[1].estimated_issues is None
        assert output.cycles[1].effort_hints == []

    def test_invalid_mode_raises_phase0_schema_error(self) -> None:
        """Mode not in allowed enum raises Phase0SchemaError."""
        raw = {"mode": "banana", "cycles": []}

        with pytest.raises(Phase0SchemaError) as exc_info:
            parse_phase0_output(raw)

        assert exc_info.value.raw == raw

    def test_missing_mode_raises_phase0_schema_error(self) -> None:
        """Missing required mode field raises Phase0SchemaError."""
        raw = {"cycles": []}

        with pytest.raises(Phase0SchemaError) as exc_info:
            parse_phase0_output(raw)

        assert exc_info.value.raw == raw

    def test_phase0_schema_error_carries_raw_fragment(self) -> None:
        """Phase0SchemaError.raw holds the offending dict."""
        raw = {"mode": "INVALID", "cycles": []}

        with pytest.raises(Phase0SchemaError) as exc_info:
            parse_phase0_output(raw)

        assert exc_info.value.raw is raw

    def test_parse_raw_cycle_plan_valid(self) -> None:
        """Valid cycle list parses into CyclePlan instances."""
        raw = [
            {"id": 1, "name": "DB", "milestone_title": "Cycle 1", "depends_on": [], "scope": "db"},
        ]
        plans = parse_raw_cycle_plan(raw)

        assert len(plans) == 1
        assert isinstance(plans[0], CyclePlan)
        assert plans[0].id == 1
        assert plans[0].depends_on == []

    def test_parse_raw_cycle_plan_invalid_raises_schema_error(self) -> None:
        """Cycle missing required field raises Phase0SchemaError."""
        raw = [
            {"id": 1, "name": "DB", "milestone_title": "Cycle 1", "depends_on": []},
            # missing "scope"
        ]

        with pytest.raises(Phase0SchemaError) as exc_info:
            parse_raw_cycle_plan(raw)

        assert "scope" in str(exc_info.value)

    def test_phase0_output_model_fields(self) -> None:
        """Phase0Output has the exact fields required by the issue."""
        output = Phase0Output(mode="single", cycles=[])

        assert output.mode == "single"
        assert output.cycles == []
        assert output.reason == ""
        assert output.effort_hints == []
