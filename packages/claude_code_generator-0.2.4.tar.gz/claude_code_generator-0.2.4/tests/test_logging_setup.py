"""Tests for the per-phase structured logging module."""

import logging
from pathlib import Path

from rich.logging import RichHandler

from code_generator.logging_setup import setup_phase_logger


class TestSetupPhaseLogger:
    def test_returns_logger_with_correct_name(self, tmp_path: Path) -> None:
        """setup_phase_logger returns a logger named code_generator.phase.<name>."""
        logger = setup_phase_logger("phase0", tmp_path)

        assert logger.name == "code_generator.phase.phase0"

    def test_log_file_is_created(self, tmp_path: Path) -> None:
        """setup_phase_logger creates the log file under .code-generator/logs/."""
        setup_phase_logger("planning", tmp_path)

        log_file = tmp_path / ".code-generator" / "logs" / "planning.log"
        assert log_file.exists()

    def test_message_written_to_file(self, tmp_path: Path) -> None:
        """A message logged at INFO level appears in the log file."""
        logger = setup_phase_logger("impl", tmp_path)
        logger.info("hello from test")

        log_file = tmp_path / ".code-generator" / "logs" / "impl.log"
        content = log_file.read_text()
        assert "hello from test" in content

    def test_rich_handler_is_present(self, tmp_path: Path) -> None:
        """setup_phase_logger attaches a RichHandler for console output."""
        logger = setup_phase_logger("review", tmp_path)

        rich_handlers = [h for h in logger.handlers if isinstance(h, RichHandler)]
        assert len(rich_handlers) >= 1

    def test_idempotent_second_call_does_not_duplicate_handlers(self, tmp_path: Path) -> None:
        """Calling setup_phase_logger twice for the same phase does not add extra handlers."""
        logger_first = setup_phase_logger("commit", tmp_path)
        handler_count = len(logger_first.handlers)

        logger_second = setup_phase_logger("commit", tmp_path)

        assert logger_first is logger_second
        assert len(logger_second.handlers) == handler_count

    def test_propagation_disabled(self, tmp_path: Path) -> None:
        """Logger must not propagate to the root logger to avoid double output."""
        logger = setup_phase_logger("final", tmp_path)

        assert logger.propagate is False

    def test_file_handler_level_is_info(self, tmp_path: Path) -> None:
        """The file handler logs at INFO or lower (not WARNING+)."""
        logger = setup_phase_logger("debug_phase", tmp_path)
        logger.info("visible")
        logger.debug("possibly visible")

        log_file = tmp_path / ".code-generator" / "logs" / "debug_phase.log"
        content = log_file.read_text()
        assert "visible" in content

    def test_different_phases_get_separate_log_files(self, tmp_path: Path) -> None:
        """Each phase name produces its own distinct log file."""
        setup_phase_logger("alpha", tmp_path)
        setup_phase_logger("beta", tmp_path)

        assert (tmp_path / ".code-generator" / "logs" / "alpha.log").exists()
        assert (tmp_path / ".code-generator" / "logs" / "beta.log").exists()

    def test_custom_level_is_applied(self, tmp_path: Path) -> None:
        """setup_phase_logger respects the level parameter."""
        logger = setup_phase_logger("verbose", tmp_path, level=logging.DEBUG)

        assert logger.level == logging.DEBUG
