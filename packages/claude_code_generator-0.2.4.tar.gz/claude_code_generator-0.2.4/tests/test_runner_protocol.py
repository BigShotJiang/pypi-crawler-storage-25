"""Tests for runner/protocol.py — Issue #63.

Verifies that:
- ``RunnerProtocol`` is importable and is a ``Protocol``
- Both ``sdk_runner`` and ``subprocess_runner`` expose a ``run`` callable
  whose signature satisfies the protocol contract
- ``get_runner()`` return type annotation is ``RunnerProtocol``
- ``rate_limit.main_loop`` parameter ``runner`` is typed ``RunnerProtocol``
- No circular imports are introduced
"""

from __future__ import annotations

import inspect
from pathlib import Path
from typing import get_type_hints

# ---------------------------------------------------------------------------
# Protocol importability
# ---------------------------------------------------------------------------


def test_runner_protocol_importable() -> None:
    from code_generator.runner.protocol import RunnerProtocol

    assert RunnerProtocol is not None


def test_runner_protocol_is_protocol() -> None:
    """RunnerProtocol must be a typing.Protocol subclass."""
    from code_generator.runner.protocol import RunnerProtocol

    # All Protocol subclasses have _is_protocol = True
    assert getattr(RunnerProtocol, "_is_protocol", False) is True


def test_runner_protocol_has_run_method() -> None:
    from code_generator.runner.protocol import RunnerProtocol

    assert hasattr(RunnerProtocol, "run")
    assert callable(RunnerProtocol.run)


def test_runner_protocol_exported_from_runner_package() -> None:
    from code_generator.runner import RunnerProtocol

    assert RunnerProtocol is not None


# ---------------------------------------------------------------------------
# sdk_runner conforms to RunnerProtocol
# ---------------------------------------------------------------------------


def test_sdk_runner_has_run_attribute() -> None:
    from code_generator.runner import sdk_runner

    assert hasattr(sdk_runner, "run"), "sdk_runner must expose a top-level 'run' function"


def test_sdk_runner_run_is_coroutine_function() -> None:
    from code_generator.runner import sdk_runner

    assert inspect.iscoroutinefunction(sdk_runner.run), "sdk_runner.run must be an async function"


def test_sdk_runner_run_signature_matches_protocol() -> None:
    """sdk_runner.run must accept (prompt, options, *, logger, state_path)."""
    from code_generator.runner import sdk_runner

    sig = inspect.signature(sdk_runner.run)
    params = sig.parameters

    assert "prompt" in params, "sdk_runner.run must have 'prompt' parameter"
    assert "options" in params, "sdk_runner.run must have 'options' parameter"
    assert "logger" in params, "sdk_runner.run must have 'logger' keyword parameter"
    assert "state_path" in params, "sdk_runner.run must have 'state_path' keyword parameter"

    # logger and state_path must be keyword-only
    assert params["logger"].kind == inspect.Parameter.KEYWORD_ONLY
    assert params["state_path"].kind == inspect.Parameter.KEYWORD_ONLY


# ---------------------------------------------------------------------------
# subprocess_runner conforms to RunnerProtocol
# ---------------------------------------------------------------------------


def test_subprocess_runner_has_run_attribute() -> None:
    from code_generator.runner import subprocess_runner

    assert hasattr(subprocess_runner, "run"), (
        "subprocess_runner must expose a top-level 'run' function"
    )


def test_subprocess_runner_run_is_coroutine_function() -> None:
    from code_generator.runner import subprocess_runner

    assert inspect.iscoroutinefunction(subprocess_runner.run), (
        "subprocess_runner.run must be an async function"
    )


def test_subprocess_runner_run_signature_matches_protocol() -> None:
    """subprocess_runner.run must accept (prompt, options, *, logger, state_path)."""
    from code_generator.runner import subprocess_runner

    sig = inspect.signature(subprocess_runner.run)
    params = sig.parameters

    assert "prompt" in params, "subprocess_runner.run must have 'prompt' parameter"
    assert "options" in params, "subprocess_runner.run must have 'options' parameter"
    assert "logger" in params, "subprocess_runner.run must have 'logger' keyword parameter"
    assert "state_path" in params, "subprocess_runner.run must have 'state_path' keyword parameter"

    assert params["logger"].kind == inspect.Parameter.KEYWORD_ONLY
    assert params["state_path"].kind == inspect.Parameter.KEYWORD_ONLY


# ---------------------------------------------------------------------------
# get_runner() return type annotation
# ---------------------------------------------------------------------------


def test_get_runner_return_type_is_runner_protocol() -> None:
    """get_runner() must declare RunnerProtocol as its return type."""
    import code_generator.runner as runner_pkg
    from code_generator.runner.protocol import RunnerProtocol

    hints = get_type_hints(runner_pkg.get_runner)
    assert "return" in hints, "get_runner must have a return type annotation"
    assert hints["return"] is RunnerProtocol


# ---------------------------------------------------------------------------
# rate_limit.main_loop runner parameter
# ---------------------------------------------------------------------------


def test_rate_limit_main_loop_runner_param_type() -> None:
    """rate_limit.main_loop's ``runner`` parameter must be annotated RunnerProtocol.

    Because RunnerProtocol is guarded by TYPE_CHECKING and all annotations are
    stored as strings (PEP 563), we check the raw ``__annotations__`` string
    rather than resolving via ``get_type_hints``.
    """
    import code_generator.runner.rate_limit as rate_limit

    raw = rate_limit.main_loop.__annotations__
    assert "runner" in raw, "main_loop must have annotation for 'runner'"
    assert raw["runner"] == "RunnerProtocol"


# ---------------------------------------------------------------------------
# No circular imports
# ---------------------------------------------------------------------------


def test_protocol_no_circular_imports() -> None:
    """protocol.py can be imported without pulling in concrete runner modules."""
    import importlib

    mod = importlib.import_module("code_generator.runner.protocol")
    assert mod is not None


def test_all_runner_submodules_importable_after_protocol() -> None:
    import importlib

    for module_name in (
        "code_generator.runner.protocol",
        "code_generator.runner.types",
        "code_generator.runner.rate_limit",
        "code_generator.runner.retry",
        "code_generator.runner.sdk_runner",
        "code_generator.runner.subprocess_runner",
    ):
        mod = importlib.import_module(module_name)
        assert mod is not None, f"{module_name} failed to import"


# ---------------------------------------------------------------------------
# Structural conformance: a class satisfying RunnerProtocol is accepted
# ---------------------------------------------------------------------------


def test_concrete_runner_satisfies_protocol_at_runtime() -> None:
    """A class implementing run() with the correct signature is a valid RunnerProtocol."""
    from code_generator.runner.types import RunResult

    class _ConcreteRunner:
        async def run(
            self,
            prompt: str,  # noqa: ARG002
            options: object,  # noqa: ARG002
            *,
            logger: object,  # noqa: ARG002
            state_path: Path,  # noqa: ARG002
        ) -> RunResult:
            return RunResult(text="ok", session_id=None, tokens_in=0, tokens_out=0)

    runner = _ConcreteRunner()
    assert inspect.iscoroutinefunction(runner.run)
    sig = inspect.signature(runner.run)
    assert "prompt" in sig.parameters
    assert "logger" in sig.parameters
    assert "state_path" in sig.parameters
