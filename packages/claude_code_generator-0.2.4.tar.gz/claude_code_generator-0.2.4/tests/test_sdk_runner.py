"""Tests for sdk_runner — Issue #10.

All SDK types are duck-typed fakes. No real SDK calls are made.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any
from unittest.mock import patch

if TYPE_CHECKING:
    from pathlib import Path

import pytest

from code_generator.runner.sdk_runner import (
    ApiUpstreamError,
    MaxTurnsExceeded,
    OverageAbort,
    RateLimitHit,
    _extract_text,
    _extract_usage,
    _handle_rate_limit_event,
    _is_assistant_message,
    _is_rate_limit_event,
    _is_result_message,
    run,
)
from code_generator.runner.types import TokenUsage

# ---------------------------------------------------------------------------
# Fake SDK message types (duck-typed, no SDK imports needed)
# ---------------------------------------------------------------------------


class FakeTextBlock:
    def __init__(self, text: str) -> None:
        self.text = text


class FakeAssistantMessage:
    def __init__(self, text: str) -> None:
        self.content = [FakeTextBlock(text)]
        self.model = "claude-sonnet-4-6"
        self.usage = {"input_tokens": 10, "output_tokens": 20}
        self.session_id = "sess-abc"


class FakeResultMessage:
    def __init__(self, session_id: str = "sess-abc") -> None:
        self.session_id = session_id
        self.usage = {"input_tokens": 10, "output_tokens": 20}
        self.subtype = "success"
        self.duration_ms = 1000
        self.duration_api_ms = 900
        self.is_error = False
        self.num_turns = 1
        self.stop_reason = "end_turn"


class FakeRateLimitInfo:
    def __init__(
        self,
        status: str,
        resets_at: int | None = None,
        rate_limit_type: str | None = None,
        overage_status: str | None = None,
    ) -> None:
        self.status = status
        self.resets_at = resets_at
        self.rate_limit_type = rate_limit_type
        self.overage_status = overage_status


class FakeRateLimitEvent:
    def __init__(self, info: FakeRateLimitInfo, session_id: str = "sess-rl") -> None:
        self.rate_limit_info = info
        self.session_id = session_id
        self.uuid = "uuid-1"


def _make_fake_client(messages: list[Any]) -> Any:
    """Build a fake async-context-manager client that yields given messages."""

    class FakeClient:
        async def __aenter__(self) -> FakeClient:
            return self

        async def __aexit__(self, *_: Any) -> None:
            pass

        async def query(self, prompt: str) -> None:  # noqa: ARG002
            pass

        async def receive_messages(self):
            for msg in messages:
                yield msg

    return FakeClient()


def _make_options() -> Any:
    """Minimal fake ClaudeAgentOptions (plain object, duck-typed)."""

    class FakeOptions:
        def __init__(self) -> None:
            self.permission_mode: str | None = None
            self.resume: str | None = None
            self.model = "claude-sonnet-4-6"
            self.max_turns = 10
            self.allowed_tools: list[str] = []
            self.cwd: str | None = None

    return FakeOptions()


# ---------------------------------------------------------------------------
# Helper: patch SDK client in sdk_runner
# ---------------------------------------------------------------------------


def _patch_client(messages: list[Any]) -> Any:
    """Context-manager that replaces sdk_runner.ClaudeSDKClient with a fake."""
    fake = _make_fake_client(messages)
    return patch("code_generator.runner.sdk_runner.ClaudeSDKClient", return_value=fake)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_plain_text_response_populates_result(tmp_path: Path) -> None:
    """Plain text response returns populated RunResult."""
    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [
        FakeAssistantMessage("Hello, world!"),
        FakeResultMessage("sess-1"),
    ]
    options = _make_options()

    import logging

    logger = logging.getLogger("test")

    with _patch_client(messages):
        result = await run("do something", options, logger=logger, state_path=state_path)

    assert result.text == "Hello, world!"
    assert result.session_id == "sess-1"
    assert result.tokens_in == 10
    assert result.tokens_out == 20


@pytest.mark.asyncio
async def test_warning_rate_limit_continues_logs(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """allowed_warning status logs a warning and run completes normally."""
    state_path = tmp_path / ".code-generator" / "state.json"
    info = FakeRateLimitInfo(status="allowed_warning", overage_status=None)
    messages = [
        FakeRateLimitEvent(info),
        FakeAssistantMessage("Done."),
        FakeResultMessage("sess-2"),
    ]
    options = _make_options()

    import logging

    logger = logging.getLogger("test.warning")

    with _patch_client(messages), caplog.at_level(logging.WARNING):
        result = await run("do something", options, logger=logger, state_path=state_path)

    assert result.text == "Done."
    assert any(
        "warning" in r.message.lower() or "allowed_warning" in r.message for r in caplog.records
    )


@pytest.mark.asyncio
async def test_rejected_rate_limit_raises_and_persists_state(tmp_path: Path) -> None:
    """Rejected rate limit persists pause state and raises RateLimitHit."""
    state_path = tmp_path / ".code-generator" / "state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)

    info = FakeRateLimitInfo(
        status="rejected",
        resets_at=9_999_999_999,
        rate_limit_type="five_hour",
        overage_status=None,
    )
    messages = [FakeRateLimitEvent(info, session_id="sess-rl")]
    options = _make_options()

    import logging

    logger = logging.getLogger("test.rejected")

    with _patch_client(messages), pytest.raises(RateLimitHit) as exc_info:
        await run("do something", options, logger=logger, state_path=state_path)

    # Non-negotiable #5: +60s safety buffer must be applied.
    assert exc_info.value.resets_at == 9_999_999_999 + 60
    assert exc_info.value.rate_limit_type == "five_hour"

    # State file must exist with paused_until reflecting the +60s buffer.
    assert state_path.exists()
    import json

    raw = json.loads(state_path.read_text())
    assert raw["paused_until"] == 9_999_999_999 + 60


@pytest.mark.asyncio
async def test_overage_enabled_raises_overage_abort(tmp_path: Path) -> None:
    """Overage status 'allowed' raises OverageAbort immediately."""
    state_path = tmp_path / ".code-generator" / "state.json"
    info = FakeRateLimitInfo(
        status="allowed",
        overage_status="allowed",
    )
    messages = [FakeRateLimitEvent(info)]
    options = _make_options()

    import logging

    logger = logging.getLogger("test.overage")

    with _patch_client(messages), pytest.raises(OverageAbort):
        await run("do something", options, logger=logger, state_path=state_path)


@pytest.mark.asyncio
async def test_permission_mode_always_forced_to_bypass(tmp_path: Path) -> None:
    """permission_mode is always set to bypassPermissions regardless of caller input."""
    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [FakeAssistantMessage("ok"), FakeResultMessage()]
    options = _make_options()
    options.permission_mode = "plan"  # caller sets something else

    import logging

    logger = logging.getLogger("test.perm")

    captured_options: list[Any] = []

    class CapturingFakeClient:
        def __init__(self, opts: Any) -> None:
            captured_options.append(opts)

        async def __aenter__(self) -> CapturingFakeClient:
            return self

        async def __aexit__(self, *_: Any) -> None:
            pass

        async def query(self, prompt: str) -> None:
            pass

        async def receive_messages(self):
            for msg in messages:
                yield msg

    with patch(
        "code_generator.runner.sdk_runner.ClaudeSDKClient",
        side_effect=lambda options: CapturingFakeClient(options),
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    assert options.permission_mode == "bypassPermissions"


class FakeResultMessageWithError:
    """FakeResultMessage variant with is_error=True."""

    def __init__(self, session_id: str = "sess-err") -> None:
        self.session_id = session_id
        self.usage = {"input_tokens": 5, "output_tokens": 3}
        self.is_error = True
        self.num_turns = 1
        self.stop_reason = "error"


class FakeNonTextBlock:
    """A content block with no .text attribute (e.g. tool_use block)."""

    def __init__(self) -> None:
        self.type = "tool_use"
        self.id = "tu-1"


# ---------------------------------------------------------------------------
# Tests — _extract_text
# ---------------------------------------------------------------------------


def test_extract_text_with_empty_content_returns_empty_string() -> None:
    """_extract_text returns '' when AssistantMessage.content is empty."""

    class Msg:
        content: list = []

    assert _extract_text(Msg()) == ""


def test_extract_text_skips_non_text_blocks() -> None:
    """_extract_text ignores blocks without a .text attribute."""

    class Msg:
        content = [FakeNonTextBlock(), FakeTextBlock("hello")]

    assert _extract_text(Msg()) == "hello"


def test_extract_text_concatenates_multiple_text_blocks() -> None:
    """_extract_text joins all text blocks in order."""

    class Msg:
        content = [FakeTextBlock("foo"), FakeTextBlock(" bar")]

    assert _extract_text(Msg()) == "foo bar"


# ---------------------------------------------------------------------------
# Tests — _extract_usage
# ---------------------------------------------------------------------------


def test_extract_usage_with_dict_returns_token_usage() -> None:
    """_extract_usage returns a TokenUsage for a plain dict with input/output tokens."""

    class Msg:
        usage = {"input_tokens": 42, "output_tokens": 7}

    result = _extract_usage(Msg())
    assert isinstance(result, TokenUsage)
    assert result.input == 42
    assert result.output == 7
    assert result.cache_read == 0
    assert result.cache_write == 0


def test_extract_usage_with_object_returns_token_usage() -> None:
    """_extract_usage returns a TokenUsage for an object with attributes."""

    class UsageObj:
        input_tokens = 100
        output_tokens = 200

    class Msg:
        usage = UsageObj()

    result = _extract_usage(Msg())
    assert isinstance(result, TokenUsage)
    assert result.input == 100
    assert result.output == 200
    assert result.cache_read == 0
    assert result.cache_write == 0


def test_extract_usage_with_none_returns_zero_token_usage() -> None:
    """_extract_usage returns zero-initialized TokenUsage when usage is absent."""

    class Msg:
        usage = None

    result = _extract_usage(Msg())
    assert isinstance(result, TokenUsage)
    assert result.input == 0
    assert result.output == 0
    assert result.cache_read == 0
    assert result.cache_write == 0


# ---------------------------------------------------------------------------
# Tests — _handle_rate_limit_event (unit, no run() involved)
# ---------------------------------------------------------------------------


def test_handle_rate_limit_event_with_no_info_logs_warning(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """When rate_limit_info is absent, just log a warning — do not raise."""
    import logging

    logger = logging.getLogger("test.no_info")
    state_path = tmp_path / ".code-generator" / "state.json"

    class MsgNoInfo:
        rate_limit_info = None

    with caplog.at_level(logging.WARNING):
        _handle_rate_limit_event(MsgNoInfo(), logger, state_path)

    assert any("no rate_limit_info" in r.message for r in caplog.records)


def test_handle_rate_limit_event_rejected_without_resets_at_logs_warning(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """Rejected with no resets_at: log warning, do not raise."""
    import logging

    logger = logging.getLogger("test.no_resets")
    state_path = tmp_path / ".code-generator" / "state.json"

    info = FakeRateLimitInfo(status="rejected", resets_at=None, rate_limit_type="five_hour")
    event = FakeRateLimitEvent(info)

    with caplog.at_level(logging.WARNING):
        _handle_rate_limit_event(event, logger, state_path)

    assert any("no resets_at" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# Tests — duck-type discriminators
# ---------------------------------------------------------------------------


def test_is_rate_limit_event_true_for_rate_limit_event() -> None:
    """_is_rate_limit_event returns True for a message with rate_limit_info."""
    info = FakeRateLimitInfo(status="allowed")
    assert _is_rate_limit_event(FakeRateLimitEvent(info)) is True


def test_is_rate_limit_event_false_for_assistant_message() -> None:
    """_is_rate_limit_event returns False for an AssistantMessage."""
    assert _is_rate_limit_event(FakeAssistantMessage("hi")) is False


def test_is_assistant_message_true_for_assistant_message() -> None:
    """_is_assistant_message returns True for a message with content and model."""
    assert _is_assistant_message(FakeAssistantMessage("hi")) is True


def test_is_assistant_message_false_for_result_message() -> None:
    """_is_assistant_message returns False for a ResultMessage."""
    assert _is_assistant_message(FakeResultMessage()) is False


def test_is_result_message_true_for_result_message() -> None:
    """_is_result_message returns True for a message with session_id and is_error."""
    assert _is_result_message(FakeResultMessage()) is True


def test_is_result_message_false_for_assistant_message() -> None:
    """_is_result_message returns False for an AssistantMessage."""
    assert _is_result_message(FakeAssistantMessage("hi")) is False


# ---------------------------------------------------------------------------
# Tests — run() integration
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_multiple_assistant_messages_are_concatenated(tmp_path: Path) -> None:
    """Multiple AssistantMessage chunks are joined into a single result text."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [
        FakeAssistantMessage("chunk one "),
        FakeAssistantMessage("chunk two"),
        FakeResultMessage("sess-multi"),
    ]
    options = _make_options()
    logger = logging.getLogger("test.multi")

    with _patch_client(messages):
        result = await run("prompt", options, logger=logger, state_path=state_path)

    assert result.text == "chunk one chunk two"
    assert result.session_id == "sess-multi"


@pytest.mark.asyncio
async def test_is_error_result_message_raises_api_upstream_error(
    tmp_path: Path,
) -> None:
    """ResultMessage with is_error=True raises ApiUpstreamError."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [
        FakeAssistantMessage("some partial output"),
        FakeResultMessageWithError(),
    ]
    options = _make_options()
    logger = logging.getLogger("test.is_error")

    with _patch_client(messages), pytest.raises(ApiUpstreamError):
        await run("prompt", options, logger=logger, state_path=state_path)


class FakeResultMessageMaxTurns:
    """ResultMessage with subtype='error_max_turns' — the canonical signal.

    Per Anthropic docs, max_turns exhaustion sets subtype='error_max_turns'.
    stop_reason carries the model's last stop reason (e.g. 'tool_use'),
    NOT an indication that the agent loop terminated due to max_turns."""

    def __init__(self, session_id: str = "sess-maxturns") -> None:
        self.session_id = session_id
        self.usage = {"input_tokens": 37, "output_tokens": 1319}
        self.is_error = True
        self.num_turns = 5
        self.subtype = "error_max_turns"
        self.stop_reason = "tool_use"  # model was mid-tool-use when SDK cut off


@pytest.mark.asyncio
async def test_error_max_turns_subtype_raises_max_turns_exceeded(
    tmp_path: Path,
) -> None:
    """ResultMessage with subtype='error_max_turns' raises MaxTurnsExceeded,
    NOT ApiUpstreamError. This is the canonical SDK signal per Anthropic docs;
    the previous fix (branching on stop_reason='max_turns') never matched
    because stop_reason is the model's stop reason, not the loop's."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [
        FakeAssistantMessage("I'll examine the staged changes..."),
        FakeResultMessageMaxTurns(),
    ]
    options = _make_options()
    logger = logging.getLogger("test.max_turns")

    with _patch_client(messages), pytest.raises(MaxTurnsExceeded) as exc_info:
        await run("prompt", options, logger=logger, state_path=state_path)

    assert "max_turns" in str(exc_info.value)
    assert "num_turns=5" in str(exc_info.value)
    assert "error_max_turns" in str(exc_info.value)
    assert not isinstance(exc_info.value, ApiUpstreamError)


@pytest.mark.asyncio
async def test_stop_reason_max_tokens_does_not_raise_max_turns_exceeded(
    tmp_path: Path,
) -> None:
    """Defensive test: stop_reason='max_tokens' (model output ceiling) is
    NOT the same as subtype='error_max_turns' (agent-loop ceiling) and must
    NOT raise MaxTurnsExceeded. stop_reason='max_tokens' with is_error=True
    should fall through to ApiUpstreamError so the transient retry applies."""
    import logging

    class FakeResultMessageModelMaxTokens:
        def __init__(self) -> None:
            self.session_id = "sess-model-maxtok"
            self.usage = {"input_tokens": 10, "output_tokens": 4096}
            self.is_error = True
            self.num_turns = 1
            self.subtype = "error_during_execution"
            self.stop_reason = "max_tokens"

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [
        FakeAssistantMessage("partial output"),
        FakeResultMessageModelMaxTokens(),
    ]
    options = _make_options()
    logger = logging.getLogger("test.model_max_tokens")

    with _patch_client(messages), pytest.raises(ApiUpstreamError) as exc_info:
        await run("prompt", options, logger=logger, state_path=state_path)

    # Must NOT be MaxTurnsExceeded — different failure mode, different handling.
    assert not isinstance(exc_info.value, MaxTurnsExceeded)


@pytest.mark.asyncio
async def test_result_message_log_includes_subtype_and_stop_reason(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """The ResultMessage INFO log line must include BOTH subtype (canonical
    failure signal) and stop_reason (model's own termination reason) for
    diagnosability. A future regression should be detectable from logs alone."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [
        FakeAssistantMessage("hello"),
        FakeResultMessage("sess-log"),
    ]
    options = _make_options()
    logger = logging.getLogger("test.subtype_log")

    with caplog.at_level(logging.INFO, logger="test.subtype_log"), _patch_client(messages):
        await run("prompt", options, logger=logger, state_path=state_path)

    result_logs = [r.getMessage() for r in caplog.records if "ResultMessage" in r.getMessage()]
    assert result_logs, "expected at least one ResultMessage log line"
    assert "subtype=success" in result_logs[0]
    assert "stop_reason=end_turn" in result_logs[0]


@pytest.mark.asyncio
async def test_upstream_5xx_in_accumulated_text_raises_api_upstream_error(
    tmp_path: Path,
) -> None:
    """Text containing 'API Error: 500...' raises ApiUpstreamError on ResultMessage."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [
        FakeAssistantMessage("API Error: 500 internal server error"),
        FakeResultMessage("sess-5xx"),
    ]
    options = _make_options()
    logger = logging.getLogger("test.5xx")

    with _patch_client(messages), pytest.raises(ApiUpstreamError):
        await run("prompt", options, logger=logger, state_path=state_path)


@pytest.mark.asyncio
async def test_strip_dangerous_env_is_called(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """ANTHROPIC_API_KEY must be gone from os.environ after run() returns."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test-should-be-stripped")
    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [FakeAssistantMessage("ok"), FakeResultMessage()]
    options = _make_options()

    import logging

    logger = logging.getLogger("test.strip")

    with _patch_client(messages):
        await run("do something", options, logger=logger, state_path=state_path)

    assert "ANTHROPIC_API_KEY" not in os.environ


# ---------------------------------------------------------------------------
# Tests — effort plumbing — Issue #68
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_effort_non_none_sets_output_config_on_options(tmp_path: Path) -> None:
    """When options.effort is set, run() sets options.output_config = {'effort': value}."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [FakeAssistantMessage("ok"), FakeResultMessage()]
    options = _make_options()
    options.effort = "medium"
    logger = logging.getLogger("test.effort.set")

    captured_options: list[Any] = []

    class CapturingFakeClient:
        def __init__(self, opts: Any) -> None:
            captured_options.append(opts)

        async def __aenter__(self) -> CapturingFakeClient:
            return self

        async def __aexit__(self, *_: Any) -> None:
            pass

        async def query(self, prompt: str) -> None:
            pass

        async def receive_messages(self):
            for msg in messages:
                yield msg

    with patch(
        "code_generator.runner.sdk_runner.ClaudeSDKClient",
        side_effect=lambda options: CapturingFakeClient(options),
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    assert captured_options[0].output_config == {"effort": "medium"}


# ---------------------------------------------------------------------------
# Tests — session-start log includes effort= and max_turns= — Issue #103
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_session_start_log_includes_effort(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """When options.effort='medium', session-start log renders effort=medium."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [FakeAssistantMessage("ok"), FakeResultMessage()]
    options = _make_options()
    options.effort = "medium"
    logger = logging.getLogger("test.log.effort.medium")

    with caplog.at_level(logging.INFO, logger="test.log.effort.medium"), _patch_client(messages):
        await run("prompt", options, logger=logger, state_path=state_path)

    start_logs = [
        r.getMessage() for r in caplog.records if "SDK session starting" in r.getMessage()
    ]
    assert start_logs, "expected at least one 'SDK session starting' log line"
    assert "model=" in start_logs[0]
    assert "effort=medium" in start_logs[0]
    assert "effort=None" not in start_logs[0]


@pytest.mark.asyncio
async def test_session_start_log_effort_none_renders_default(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """When options.effort is None (unset), session-start log renders effort=default."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [FakeAssistantMessage("ok"), FakeResultMessage()]
    options = _make_options()  # no effort attr set
    logger = logging.getLogger("test.log.effort.none")

    with caplog.at_level(logging.INFO, logger="test.log.effort.none"), _patch_client(messages):
        await run("prompt", options, logger=logger, state_path=state_path)

    start_logs = [
        r.getMessage() for r in caplog.records if "SDK session starting" in r.getMessage()
    ]
    assert start_logs, "expected at least one 'SDK session starting' log line"
    assert "effort=default" in start_logs[0]
    assert "effort=None" not in start_logs[0]


# ---------------------------------------------------------------------------
# Tests — Issue #118: TokenUsage in log, RunResult, and error messages
# ---------------------------------------------------------------------------


class FakeResultMessageWithCache:
    """ResultMessage with cache token fields populated."""

    def __init__(self, session_id: str = "sess-cache") -> None:
        self.session_id = session_id
        self.usage = {
            "input_tokens": 100,
            "output_tokens": 50,
            "cache_creation_input_tokens": 30,
            "cache_read_input_tokens": 20,
        }
        self.subtype = "success"
        self.is_error = False
        self.num_turns = 1
        self.stop_reason = "end_turn"


@pytest.mark.asyncio
async def test_result_message_log_includes_all_four_token_fields(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """ResultMessage INFO log must include all four token fields:
    tokens_in, tokens_out, cache_read, cache_write."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [
        FakeAssistantMessage("hello"),
        FakeResultMessageWithCache(),
    ]
    options = _make_options()
    logger = logging.getLogger("test.four_token_fields")

    with caplog.at_level(logging.INFO, logger="test.four_token_fields"), _patch_client(messages):
        await run("prompt", options, logger=logger, state_path=state_path)

    result_logs = [r.getMessage() for r in caplog.records if "ResultMessage" in r.getMessage()]
    assert result_logs, "expected at least one ResultMessage log line"
    log_line = result_logs[0]
    assert "tokens_in=100" in log_line
    assert "tokens_out=50" in log_line
    assert "cache_read=20" in log_line
    assert "cache_write=30" in log_line


@pytest.mark.asyncio
async def test_run_result_usage_is_token_usage_with_correct_values(
    tmp_path: Path,
) -> None:
    """RunResult.usage must be a TokenUsage with all four fields populated."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [
        FakeAssistantMessage("hello"),
        FakeResultMessageWithCache(),
    ]
    options = _make_options()
    logger = logging.getLogger("test.run_result_usage")

    with _patch_client(messages):
        result = await run("prompt", options, logger=logger, state_path=state_path)

    assert isinstance(result.usage, TokenUsage)
    assert result.usage.input == 100
    assert result.usage.output == 50
    assert result.usage.cache_read == 20
    assert result.usage.cache_write == 30


@pytest.mark.asyncio
async def test_max_turns_exceeded_message_references_usage_input_output(
    tmp_path: Path,
) -> None:
    """MaxTurnsExceeded error message must reference usage.input / usage.output values."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [
        FakeAssistantMessage("some output"),
        FakeResultMessageMaxTurns(),
    ]
    options = _make_options()
    logger = logging.getLogger("test.max_turns_msg")

    with _patch_client(messages), pytest.raises(MaxTurnsExceeded) as exc_info:
        await run("prompt", options, logger=logger, state_path=state_path)

    error_msg = str(exc_info.value)
    # FakeResultMessageMaxTurns has input_tokens=37, output_tokens=1319
    assert "37" in error_msg, f"expected input token count 37 in: {error_msg}"
    assert "1319" in error_msg, f"expected output token count 1319 in: {error_msg}"


@pytest.mark.asyncio
async def test_api_upstream_error_message_references_usage_input_output(
    tmp_path: Path,
) -> None:
    """ApiUpstreamError message must reference usage.input / usage.output values."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [
        FakeAssistantMessage("some partial output"),
        FakeResultMessageWithError(),
    ]
    options = _make_options()
    logger = logging.getLogger("test.upstream_err_msg")

    with _patch_client(messages), pytest.raises(ApiUpstreamError) as exc_info:
        await run("prompt", options, logger=logger, state_path=state_path)

    error_msg = str(exc_info.value)
    # FakeResultMessageWithError has input_tokens=5, output_tokens=3
    assert "5" in error_msg, f"expected input token count 5 in: {error_msg}"
    assert "3" in error_msg, f"expected output token count 3 in: {error_msg}"


@pytest.mark.asyncio
async def test_effort_none_does_not_set_output_config_on_options(tmp_path: Path) -> None:
    """When options.effort is None (unset), run() does not set output_config on options."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    messages = [FakeAssistantMessage("ok"), FakeResultMessage()]
    options = _make_options()
    logger = logging.getLogger("test.effort.none")

    captured_options: list[Any] = []

    class CapturingFakeClient:
        def __init__(self, opts: Any) -> None:
            captured_options.append(opts)

        async def __aenter__(self) -> CapturingFakeClient:
            return self

        async def __aexit__(self, *_: Any) -> None:
            pass

        async def query(self, prompt: str) -> None:
            pass

        async def receive_messages(self):
            for msg in messages:
                yield msg

    with patch(
        "code_generator.runner.sdk_runner.ClaudeSDKClient",
        side_effect=lambda options: CapturingFakeClient(options),
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    assert not hasattr(captured_options[0], "output_config")
