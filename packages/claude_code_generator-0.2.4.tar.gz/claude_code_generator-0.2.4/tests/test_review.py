"""Tests for the `code-generator review` command."""

from __future__ import annotations

from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

if TYPE_CHECKING:
    from pathlib import Path

import pytest
from typer.testing import CliRunner

from code_generator.cli import app
from code_generator.env import DANGEROUS_VARS
from code_generator.runner.retry import CircuitOpen
from code_generator.runner.sdk_runner import OverageAbort, RunResult

runner = CliRunner()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def clear_dangerous_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Strip API-key vars so tests run without hitting the env safety check."""
    for var in DANGEROUS_VARS:
        monkeypatch.delenv(var, raising=False)


def _make_result(text: str = "Review complete.") -> RunResult:
    return RunResult(text=text, session_id="sess-review", tokens_in=10, tokens_out=50)


def _fake_runner_module(result: RunResult | Exception) -> MagicMock:
    """Return a fake runner module whose run() returns/raises the given value."""
    module = MagicMock()
    if isinstance(result, Exception):
        module.run = AsyncMock(side_effect=result)
    else:
        module.run = AsyncMock(return_value=result)
    return module


# ---------------------------------------------------------------------------
# Success path
# ---------------------------------------------------------------------------


def test_review_success_prints_result_and_exits_0(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Successful review run prints result text and exits 0."""
    monkeypatch.chdir(tmp_path)
    fake_runner = _fake_runner_module(_make_result("All good!"))

    with patch("code_generator.commands.review.get_runner", return_value=fake_runner):
        result = runner.invoke(app, ["review"])

    assert result.exit_code == 0
    assert "All good!" in result.output


def test_review_create_issues_flag_passes_through(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """--create-issues flag is accepted and run completes."""
    monkeypatch.chdir(tmp_path)
    fake_runner = _fake_runner_module(_make_result("Issues created."))

    with patch("code_generator.commands.review.get_runner", return_value=fake_runner):
        result = runner.invoke(app, ["review", "--create-issues"])

    assert result.exit_code == 0


def test_review_severity_flag_passes_through(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """--severity flag is accepted and run completes."""
    monkeypatch.chdir(tmp_path)
    fake_runner = _fake_runner_module(_make_result("High severity only."))

    with patch("code_generator.commands.review.get_runner", return_value=fake_runner):
        result = runner.invoke(app, ["review", "--severity", "high"])

    assert result.exit_code == 0


# ---------------------------------------------------------------------------
# Error paths
# ---------------------------------------------------------------------------


def test_overage_abort_exits_2(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """OverageAbort → stderr message + exit code 2."""
    monkeypatch.chdir(tmp_path)
    fake_runner = _fake_runner_module(OverageAbort("billing active"))

    with patch("code_generator.commands.review.get_runner", return_value=fake_runner):
        result = runner.invoke(app, ["review"])

    assert result.exit_code == 2


def test_circuit_open_exits_1(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """CircuitOpen → stderr message + exit code 1."""
    monkeypatch.chdir(tmp_path)
    fake_runner = _fake_runner_module(CircuitOpen("circuit tripped"))

    with patch("code_generator.commands.review.get_runner", return_value=fake_runner):
        result = runner.invoke(app, ["review"])

    assert result.exit_code == 1


# ---------------------------------------------------------------------------
# Env safety
# ---------------------------------------------------------------------------


def test_dangerous_env_var_exits_2_before_review(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Dangerous env var → exit 2 before any runner call."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
    result = runner.invoke(app, ["review"])
    assert result.exit_code == 2


# ---------------------------------------------------------------------------
# Prompt loading
# ---------------------------------------------------------------------------


def test_prompt_loads_without_crash(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Verify the prompt file is present and substitution works."""
    from code_generator.prompts import load_prompt

    prompt = load_prompt(
        "prompt-review.md",
        CREATE_ISSUES="false",
        SEVERITY_FILTER="low",
    )
    assert len(prompt) > 0
