"""Tests for environment safety module."""

import os

import pytest

from code_generator.env import (
    DANGEROUS_VARS,
    assert_safe_environment,
    build_agent_env,
    strip_dangerous_env,
)


def test_dangerous_vars_contains_all_six() -> None:
    """DANGEROUS_VARS must list exactly the six documented variables."""
    expected = {
        "ANTHROPIC_API_KEY",
        "ANTHROPIC_AUTH_TOKEN",
        "ANTHROPIC_BEDROCK_API_KEY",
        "ANTHROPIC_VERTEX_PROJECT_ID",
        "CLAUDE_CODE_USE_BEDROCK",
        "CLAUDE_CODE_USE_VERTEX",
    }
    assert set(DANGEROUS_VARS) == expected


class TestStripDangerousEnv:
    def test_strips_present_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """strip_dangerous_env removes every DANGEROUS_VAR that is present."""
        for var in DANGEROUS_VARS:
            monkeypatch.setenv(var, "value")

        strip_dangerous_env()

        for var in DANGEROUS_VARS:
            assert var not in os.environ

    def test_no_error_when_vars_absent(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """strip_dangerous_env must not raise when vars are not present."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)

        strip_dangerous_env()  # should not raise

    def test_leaves_other_vars_intact(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """strip_dangerous_env must not touch unrelated environment variables."""
        monkeypatch.setenv("MY_SAFE_VAR", "safe")
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)

        strip_dangerous_env()

        assert os.environ.get("MY_SAFE_VAR") == "safe"


class TestBuildAgentEnv:
    def test_excludes_all_dangerous_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """build_agent_env returns a copy with no dangerous vars."""
        for var in DANGEROUS_VARS:
            monkeypatch.setenv(var, "should-be-stripped")

        env = build_agent_env()

        for var in DANGEROUS_VARS:
            assert var not in env

    def test_preserves_safe_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """build_agent_env keeps all non-dangerous environment variables."""
        monkeypatch.setenv("PATH", "/usr/bin")
        monkeypatch.setenv("HOME", "/home/user")
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)

        env = build_agent_env()

        assert env.get("PATH") == "/usr/bin"
        assert env.get("HOME") == "/home/user"

    def test_does_not_mutate_os_environ(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """build_agent_env returns a copy, not a reference to os.environ."""
        for var in DANGEROUS_VARS:
            monkeypatch.setenv(var, "value")

        env = build_agent_env()

        assert env is not os.environ
        # Originals still present in os.environ (monkeypatch will restore them)
        for var in DANGEROUS_VARS:
            assert var in os.environ


class TestAssertSafeEnvironment:
    def test_passes_when_no_dangerous_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """assert_safe_environment succeeds silently when env is clean."""
        for var in DANGEROUS_VARS:
            monkeypatch.delenv(var, raising=False)

        assert_safe_environment()  # must not raise

    def test_strips_var_when_present(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """assert_safe_environment strips dangerous vars instead of aborting."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-123")
        for var in DANGEROUS_VARS:
            if var != "ANTHROPIC_API_KEY":
                monkeypatch.delenv(var, raising=False)

        assert_safe_environment()

        assert "ANTHROPIC_API_KEY" not in os.environ

    def test_warning_names_dangerous_vars(
        self, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """The printed warning lists the offending variable names."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-abc")
        monkeypatch.setenv("CLAUDE_CODE_USE_BEDROCK", "1")
        for var in DANGEROUS_VARS:
            if var not in ("ANTHROPIC_API_KEY", "CLAUDE_CODE_USE_BEDROCK"):
                monkeypatch.delenv(var, raising=False)

        assert_safe_environment()

        captured = capsys.readouterr()
        assert "ANTHROPIC_API_KEY" in captured.err
        assert "CLAUDE_CODE_USE_BEDROCK" in captured.err
        assert "ANTHROPIC_API_KEY" not in os.environ
        assert "CLAUDE_CODE_USE_BEDROCK" not in os.environ

    def test_strips_each_dangerous_var(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """assert_safe_environment strips any individual dangerous var."""
        for dangerous_var in DANGEROUS_VARS:
            for v in DANGEROUS_VARS:
                monkeypatch.delenv(v, raising=False)

            monkeypatch.setenv(dangerous_var, "present")
            assert_safe_environment()
            assert dangerous_var not in os.environ
