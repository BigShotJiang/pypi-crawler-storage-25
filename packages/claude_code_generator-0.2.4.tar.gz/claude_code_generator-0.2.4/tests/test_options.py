"""Tests for code_generator.runner.options — make_agent_options factory."""

from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch


class TestMakeAgentOptionsWithSdkAvailable:
    def test_returns_real_options_when_sdk_present(self) -> None:
        """When claude_agent_sdk is importable, returns a ClaudeAgentOptions instance."""
        fake_options = MagicMock()
        fake_cls = MagicMock(return_value=fake_options)
        fake_sdk = MagicMock(ClaudeAgentOptions=fake_cls)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            # Re-import so the module picks up the mocked SDK.
            import importlib

            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(model="claude-sonnet-4-6", max_turns=5)

        fake_cls.assert_called_once_with(model="claude-sonnet-4-6", max_turns=5)
        assert result is fake_options

    def test_real_options_carry_all_kwargs(self) -> None:
        """Every kwarg is forwarded to ClaudeAgentOptions without modification."""
        received: dict = {}

        def capture(**kw: object) -> MagicMock:
            received.update(kw)
            return MagicMock(**kw)

        fake_sdk = MagicMock(ClaudeAgentOptions=capture)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import importlib

            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            options_mod.make_agent_options(model="m", allowed_tools=["Read"], cwd="/tmp")

        assert received == {"model": "m", "allowed_tools": ["Read"], "cwd": "/tmp"}


class TestMakeAgentOptionsWithoutSdk:
    def test_returns_fallback_when_sdk_missing(self) -> None:
        """When claude_agent_sdk is absent, returns a duck-typed fallback object."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import importlib

            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(model="claude-opus-4-6", max_turns=10)

        assert result.model == "claude-opus-4-6"
        assert result.max_turns == 10

    def test_fallback_supports_arbitrary_attributes(self) -> None:
        """Fallback object exposes every kwarg as an attribute."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import importlib

            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                model="m",
                allowed_tools=["Read", "Grep"],
                cwd="/some/path",
                permission_mode="bypassPermissions",
            )

        assert result.model == "m"
        assert result.allowed_tools == ["Read", "Grep"]
        assert result.cwd == "/some/path"
        assert result.permission_mode == "bypassPermissions"

    def test_fallback_attributes_not_set_default_to_none(self) -> None:
        """Attributes not passed as kwargs are absent / not set by the fallback."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import importlib

            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(model="m")

        assert result.model == "m"
        # resume is not passed — must not raise, just not exist
        assert not hasattr(result, "resume")
