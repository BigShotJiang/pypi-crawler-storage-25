"""Tests for the prompt loader module."""

import pytest

from code_generator.prompts import (
    PLACEHOLDER_SPEC,
    PromptError,
    available_prompts,
    load_prompt,
)

# Expected filenames and their placeholder sets as defined in requirements.md §11
_EXPECTED_FILES = {
    "prompt-optimize-requirements.md": frozenset({"CURRENT_REQUIREMENTS"}),
    "prompt-phase-0-complexity.md": frozenset(),
    "prompt-phase-1-planning.md": frozenset(
        {
            "REQUIREMENTS_PATH",
            "MILESTONE_TITLE",
            "CYCLE_SCOPE",
            "COMPLETED_CYCLES",
            "EXISTING_ISSUES",
        }
    ),
    "prompt-phase-2-issue-review.md": frozenset(
        {"ISSUE_NUMBER", "PRIMARY_AGENT", "ISSUE_COMMENTS"}
    ),
    "prompt-phase-3-implementation.md": frozenset(
        {"ISSUE_NUMBER", "PRIMARY_AGENT", "SKILLS", "ISSUE_COMMENTS"}
    ),
    "prompt-phase-5-final-review.md": frozenset(
        {"MILESTONE_TITLE", "CYCLE_SCOPE", "OPEN_ISSUES_WITH_COMMENTS", "DIFF_SINCE_BASE"}
    ),
    "prompt-phase-6-test.md": frozenset({"MAX_RETRIES"}),
    "prompt-phase-7-commit.md": frozenset(
        {"CYCLE_NAME", "ISSUES_CLOSED", "STAGED_DIFF_STAT", "STAGED_FILES"}
    ),
    "prompt-review.md": frozenset({"CREATE_ISSUES", "SEVERITY_FILTER"}),
}


class TestPlaceholderSpec:
    def test_all_nine_files_registered(self) -> None:
        """PLACEHOLDER_SPEC must contain exactly the 9 documented prompt files."""
        assert set(PLACEHOLDER_SPEC.keys()) == set(_EXPECTED_FILES.keys())

    def test_placeholder_sets_match_spec(self) -> None:
        """Each file's placeholder set must match the requirements.md §11 definition."""
        for filename, expected in _EXPECTED_FILES.items():
            assert PLACEHOLDER_SPEC[filename] == expected, (
                f"{filename}: expected {expected}, got {PLACEHOLDER_SPEC[filename]}"
            )


class TestAvailablePrompts:
    def test_returns_all_nine_filenames(self) -> None:
        """available_prompts() must return all 9 prompt filenames."""
        prompts = available_prompts()

        assert len(prompts) == 9
        assert set(prompts) == set(_EXPECTED_FILES.keys())


class TestLoadPromptPhase0:
    def test_loads_with_no_placeholders(self) -> None:
        """prompt-phase-0-complexity.md loads successfully with no placeholders."""
        result = load_prompt("prompt-phase-0-complexity.md")

        assert isinstance(result, str)
        assert len(result) > 0

    def test_raises_on_extra_placeholder(self) -> None:
        """Passing extra placeholders for phase-0 raises PromptError."""
        with pytest.raises(PromptError, match="extra"):
            load_prompt("prompt-phase-0-complexity.md", UNEXPECTED="value")


class TestLoadPromptSubstitution:
    def test_phase_1_substitutes_all_placeholders(self) -> None:
        """load_prompt replaces all {NAME} tokens in phase-1 prompt."""
        result = load_prompt(
            "prompt-phase-1-planning.md",
            REQUIREMENTS_PATH="/path/to/req.md",
            MILESTONE_TITLE="Cycle 1 — Foundation",
            CYCLE_SCOPE="env + state + prompts + logging",
            COMPLETED_CYCLES="none",
            EXISTING_ISSUES="none",
        )

        assert "/path/to/req.md" in result
        assert "Cycle 1 — Foundation" in result
        assert "{REQUIREMENTS_PATH}" not in result
        assert "{MILESTONE_TITLE}" not in result
        assert "{CYCLE_SCOPE}" not in result
        assert "{COMPLETED_CYCLES}" not in result
        assert "{EXISTING_ISSUES}" not in result

    def test_phase_2_substitutes_placeholders(self) -> None:
        """load_prompt correctly handles phase-2 placeholders."""
        result = load_prompt(
            "prompt-phase-2-issue-review.md",
            ISSUE_NUMBER="42",
            PRIMARY_AGENT="python-pro",
            ISSUE_COMMENTS="## Issue Comments\n\n**alice**: nice",
        )

        assert "42" in result
        assert "python-pro" in result
        assert "{ISSUE_NUMBER}" not in result
        assert "{PRIMARY_AGENT}" not in result
        assert "{ISSUE_COMMENTS}" not in result
        assert "## Issue Comments" in result

    def test_phase_3_substitutes_placeholders(self) -> None:
        """load_prompt correctly handles phase-3 placeholders."""
        result = load_prompt(
            "prompt-phase-3-implementation.md",
            ISSUE_NUMBER="7",
            PRIMARY_AGENT="fastapi-expert-agent",
            SKILLS="skfolio,yfinance",
            ISSUE_COMMENTS="",
        )

        assert "{ISSUE_NUMBER}" not in result
        assert "{PRIMARY_AGENT}" not in result
        assert "{SKILLS}" not in result
        assert "{ISSUE_COMMENTS}" not in result

    def test_phase_5_substitutes_placeholders(self) -> None:
        """load_prompt correctly handles phase-5 placeholders."""
        result = load_prompt(
            "prompt-phase-5-final-review.md",
            MILESTONE_TITLE="Cycle 1",
            CYCLE_SCOPE="all modules",
            OPEN_ISSUES_WITH_COMMENTS="### Issue #1: test issue",
            DIFF_SINCE_BASE="",
        )

        assert "{MILESTONE_TITLE}" not in result
        assert "{CYCLE_SCOPE}" not in result
        assert "{OPEN_ISSUES_WITH_COMMENTS}" not in result
        assert "{DIFF_SINCE_BASE}" not in result

    def test_phase_6_substitutes_max_retries(self) -> None:
        """load_prompt correctly handles phase-6 MAX_RETRIES placeholder."""
        result = load_prompt("prompt-phase-6-test.md", MAX_RETRIES="3")

        assert "{MAX_RETRIES}" not in result

    def test_phase_7_substitutes_placeholders(self) -> None:
        """load_prompt correctly handles phase-7 placeholders."""
        result = load_prompt(
            "prompt-phase-7-commit.md",
            CYCLE_NAME="Cycle 1 — Foundation",
            ISSUES_CLOSED="#2 #3 #4 #5",
            STAGED_DIFF_STAT="src/foo.py | 5 +++++\n1 file changed",
            STAGED_FILES="src/foo.py",
        )

        assert "{CYCLE_NAME}" not in result
        assert "{ISSUES_CLOSED}" not in result
        assert "{STAGED_DIFF_STAT}" not in result
        assert "{STAGED_FILES}" not in result

    def test_review_substitutes_placeholders(self) -> None:
        """load_prompt correctly handles prompt-review.md placeholders."""
        result = load_prompt(
            "prompt-review.md",
            CREATE_ISSUES="true",
            SEVERITY_FILTER="high",
        )

        assert "{CREATE_ISSUES}" not in result
        assert "{SEVERITY_FILTER}" not in result

    def test_stray_braces_not_mangled(self) -> None:
        """Curly braces that are NOT placeholder tokens survive substitution intact."""
        result = load_prompt(
            "prompt-phase-0-complexity.md",
        )
        # The prompt contains JSON schema examples with braces like {"type": ...}
        # These must be preserved — verified by checking the file has braces.
        # We simply assert the result is non-empty and is a string.
        assert isinstance(result, str)
        assert len(result) > 10


class TestOptimizeRequirementsPrompt:
    """Tests for issue #144 — prompt-optimize-requirements.md registration and content."""

    _FILENAME = "prompt-optimize-requirements.md"

    def test_prompt_listed_in_available_prompts(self) -> None:
        """The new prompt must appear in available_prompts() return value."""
        assert self._FILENAME in available_prompts()

    def test_placeholder_spec_contains_current_requirements(self) -> None:
        """PLACEHOLDER_SPEC entry for the optimize prompt must declare CURRENT_REQUIREMENTS."""
        assert PLACEHOLDER_SPEC[self._FILENAME] == frozenset({"CURRENT_REQUIREMENTS"})

    def test_load_prompt_succeeds_with_current_requirements(self) -> None:
        """load_prompt('prompt-optimize-requirements.md', CURRENT_REQUIREMENTS=...) succeeds."""
        result = load_prompt(
            self._FILENAME, CURRENT_REQUIREMENTS="# My App\n## Description\nAn app."
        )

        assert isinstance(result, str)
        assert len(result) > 0
        assert "{CURRENT_REQUIREMENTS}" not in result
        assert "# My App" in result

    def test_load_prompt_raises_without_placeholder(self) -> None:
        """load_prompt raises PromptError when CURRENT_REQUIREMENTS is omitted."""
        with pytest.raises(PromptError, match="missing"):
            load_prompt(self._FILENAME)

    def test_load_prompt_raises_with_extra_placeholder(self) -> None:
        """load_prompt raises PromptError when an unexpected placeholder is supplied."""
        with pytest.raises(PromptError, match="extra"):
            load_prompt(self._FILENAME, CURRENT_REQUIREMENTS="content", UNEXPECTED="oops")

    def test_prompt_contains_constraints_section(self) -> None:
        """The prompt file must contain an explicit Constraints section."""
        import importlib.resources

        text = (
            importlib.resources.files("code_generator.prompts")
            .joinpath(self._FILENAME)
            .read_text(encoding="utf-8")
        )
        assert "## Constraints" in text or "### Constraints" in text

    def test_prompt_declares_yolo_mode(self) -> None:
        """The Constraints section must declare YOLO mode."""
        import importlib.resources

        text = (
            importlib.resources.files("code_generator.prompts")
            .joinpath(self._FILENAME)
            .read_text(encoding="utf-8")
        )
        assert (
            "YOLO" in text or "bypassPermissions" in text or "dangerously-skip-permissions" in text
        )

    def test_prompt_instructs_preserve_original_intent(self) -> None:
        """The prompt must instruct the model to preserve original intent."""
        import importlib.resources

        text = (
            importlib.resources.files("code_generator.prompts")
            .joinpath(self._FILENAME)
            .read_text(encoding="utf-8")
        )
        assert "preserve" in text.lower() and "intent" in text.lower()

    def test_prompt_instructs_no_invented_scope(self) -> None:
        """The prompt must forbid inventing new scope items."""
        import importlib.resources

        text = (
            importlib.resources.files("code_generator.prompts")
            .joinpath(self._FILENAME)
            .read_text(encoding="utf-8")
        )
        assert (
            "invent" in text.lower() or "never add" in text.lower() or "do not add" in text.lower()
        )

    def test_prompt_instructs_no_commentary_in_output(self) -> None:
        """The prompt must instruct 'output the full rewritten file, no commentary, no code fences'."""
        import importlib.resources

        text = (
            importlib.resources.files("code_generator.prompts")
            .joinpath(self._FILENAME)
            .read_text(encoding="utf-8")
        )
        assert "commentary" in text.lower() or "no preamble" in text.lower()
        assert "code fence" in text.lower() or "```" in text


class TestLoadPromptErrors:
    def test_unknown_filename_raises(self) -> None:
        """load_prompt raises PromptError for an unrecognized filename."""
        with pytest.raises(PromptError, match="unknown prompt file"):
            load_prompt("nonexistent.md")

    def test_missing_placeholder_raises(self) -> None:
        """load_prompt raises PromptError when a required placeholder is omitted."""
        with pytest.raises(PromptError, match="missing"):
            load_prompt(
                "prompt-phase-1-planning.md",
                REQUIREMENTS_PATH="/req.md",
            )

    def test_extra_placeholder_raises(self) -> None:
        """load_prompt raises PromptError when an unexpected placeholder is supplied."""
        with pytest.raises(PromptError, match="extra"):
            load_prompt(
                "prompt-phase-1-planning.md",
                REQUIREMENTS_PATH="/req.md",
                MILESTONE_TITLE="M1",
                CYCLE_SCOPE="scope",
                COMPLETED_CYCLES="none",
                EXISTING_ISSUES="none",
                UNEXPECTED_EXTRA="oops",
            )

    def test_prompt_error_is_value_error_subclass(self) -> None:
        """PromptError inherits from ValueError as documented."""
        assert issubclass(PromptError, ValueError)


class TestPhase7PromptHardening:
    """Tests for issue #142 — Phase 7 prompt hardening (sentinel, Wrong vs Right, all 11 types)."""

    _SENTINEL = "Any character before the commit type is a bug"

    def _load_raw(self) -> str:
        """Load the raw prompt-phase-7-commit.md text (no placeholder substitution)."""
        import importlib.resources

        return (
            importlib.resources.files("code_generator.prompts")
            .joinpath("prompt-phase-7-commit.md")
            .read_text(encoding="utf-8")
        )

    def test_sentinel_present_in_instructions_section(self) -> None:
        """AC1: sentinel string exists in the Instructions section of the prompt."""
        text = self._load_raw()
        instructions_start = text.find("### Instructions")
        assert instructions_start != -1, "### Instructions section not found"
        instructions_section = text[instructions_start:]
        assert self._SENTINEL in instructions_section, (
            f"Sentinel {self._SENTINEL!r} not found in ### Instructions section"
        )

    def test_sentinel_appears_before_step_1(self) -> None:
        """AC1 (precise): sentinel is the first substantive line after '### Instructions'."""
        text = self._load_raw()
        instructions_start = text.find("### Instructions")
        assert instructions_start != -1
        # After the heading, find sentinel and step "1."
        section = text[instructions_start:]
        sentinel_pos = section.find(self._SENTINEL)
        step1_pos = section.find("\n1.")
        assert sentinel_pos != -1, "Sentinel not found in Instructions section"
        assert sentinel_pos < step1_pos, (
            "Sentinel must appear before step 1 in the Instructions section"
        )

    def test_wrong_vs_right_section_exists(self) -> None:
        """AC2: ### Wrong vs Right section exists in the prompt."""
        text = self._load_raw()
        assert "### Wrong vs Right" in text, "### Wrong vs Right section not found in prompt"

    def test_wrong_vs_right_contains_bad_example(self) -> None:
        """AC2: the bad example ('I have enough context now') appears in Wrong vs Right."""
        text = self._load_raw()
        wvr_start = text.find("### Wrong vs Right")
        assert wvr_start != -1
        wvr_section = text[wvr_start:]
        assert "I have enough context now" in wvr_section, (
            "Bad example text not found in ### Wrong vs Right section"
        )

    def test_wrong_vs_right_has_strikethrough_bad_example(self) -> None:
        """AC2: bad example is formatted with strikethrough markdown (~~...~~)."""
        text = self._load_raw()
        wvr_start = text.find("### Wrong vs Right")
        assert wvr_start != -1
        wvr_section = text[wvr_start:]
        assert "~~" in wvr_section, (
            "Strikethrough (~~) markup not found in ### Wrong vs Right section"
        )

    def test_all_11_commit_types_listed(self) -> None:
        """AC3: all 11 conventional-commit types are listed in the prompt."""
        text = self._load_raw()
        required_types = [
            "feat",
            "fix",
            "refactor",
            "test",
            "docs",
            "chore",
            "perf",
            "build",
            "ci",
            "style",
            "revert",
        ]
        for commit_type in required_types:
            assert f"`{commit_type}`" in text or f"{commit_type}:" in text, (
                f"Commit type '{commit_type}' not found in prompt"
            )

    def test_existing_placeholders_preserved(self) -> None:
        """AC4: the four existing placeholders remain in the raw prompt text."""
        text = self._load_raw()
        for placeholder in (
            "{CYCLE_NAME}",
            "{ISSUES_CLOSED}",
            "{STAGED_DIFF_STAT}",
            "{STAGED_FILES}",
        ):
            assert placeholder in text, f"Placeholder {placeholder!r} missing from prompt"

    def test_no_new_placeholders_introduced(self) -> None:
        """AC4: no placeholders other than the existing four are present."""
        import re

        text = self._load_raw()
        found = set(re.findall(r"\{([A-Z_]+)\}", text))
        allowed = {"CYCLE_NAME", "ISSUES_CLOSED", "STAGED_DIFF_STAT", "STAGED_FILES"}
        unexpected = found - allowed
        assert not unexpected, f"Unexpected placeholders found: {unexpected}"

    def test_load_prompt_still_works_after_hardening(self) -> None:
        """AC5: load_prompt with all four placeholders still succeeds."""
        result = load_prompt(
            "prompt-phase-7-commit.md",
            CYCLE_NAME="Cycle 5",
            ISSUES_CLOSED="#142",
            STAGED_DIFF_STAT="src/code_generator/prompts/prompt-phase-7-commit.md | 30 +++++++",
            STAGED_FILES="src/code_generator/prompts/prompt-phase-7-commit.md",
        )
        assert isinstance(result, str)
        assert len(result) > 0
        assert "{CYCLE_NAME}" not in result
        assert "{ISSUES_CLOSED}" not in result
