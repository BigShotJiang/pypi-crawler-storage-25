"""TDD tests for _extract_commit_message — issue #140.

All ACs are tested before the function exists (Red phase).
"""

from __future__ import annotations

from code_generator.orchestrator.phase7_commit import _extract_commit_message

# ---------------------------------------------------------------------------
# AC 1 — preamble is stripped, conventional-commit body is preserved
# ---------------------------------------------------------------------------


def test_preamble_stripped_keeps_conventional_commit_body() -> None:
    """AC 1: leading prose before the first conventional-commit line is dropped."""
    raw = (
        "I have enough context now. This is a multi-cycle commit...\n\n"
        "feat(Phase 5): add diff review\n\n"
        "- body\n\n"
        "Closed issues: #113"
    )
    expected = "feat(Phase 5): add diff review\n\n- body\n\nClosed issues: #113"
    assert _extract_commit_message(raw, fallback="...") == expected


# ---------------------------------------------------------------------------
# AC 2 — pure conversational chatter returns the fallback verbatim
# ---------------------------------------------------------------------------


def test_pure_chatter_returns_fallback_verbatim() -> None:
    """AC 2: when no conventional-commit line is found, return fallback unchanged."""
    raw = "I've received the Phase 7 prompt...\n\n1. Execute Phase 7\n2. Test the prompt"
    fallback = "chore: cycle complete\n\nClosed issues: #1"
    assert _extract_commit_message(raw, fallback=fallback) == fallback


# ---------------------------------------------------------------------------
# AC 3 — whole-message fence is unwrapped
# ---------------------------------------------------------------------------


def test_whole_message_fence_is_unwrapped() -> None:
    """AC 3: message wrapped in a top-level triple-backtick fence is unwrapped."""
    raw = "```\nfeat: add X\n\nbody\n```"
    assert _extract_commit_message(raw, fallback="...") == "feat: add X\n\nbody"


def test_whole_message_fence_with_language_tag_is_unwrapped() -> None:
    """Variant of AC 3: opening fence with a language tag (```text) is also unwrapped."""
    raw = "```text\nfeat: add X\n\nbody\n```"
    assert _extract_commit_message(raw, fallback="...") == "feat: add X\n\nbody"


# ---------------------------------------------------------------------------
# AC 4 — embedded fence + trailing prose: preamble stripped AND fence removed
# ---------------------------------------------------------------------------


def test_embedded_fence_and_trailing_prose_are_removed() -> None:
    """AC 4: preamble before the fence is dropped; closing fence + trailing prose removed."""
    raw = (
        "I'll help you. Let me examine...\n\n"
        "```\n"
        "refactor: extract module\n\n"
        "body\n"
        "```\n\n"
        "This captures the changes."
    )
    expected = "refactor: extract module\n\nbody"
    assert _extract_commit_message(raw, fallback="...") == expected


# ---------------------------------------------------------------------------
# AC 5 — happy-path message round-trips unchanged
# ---------------------------------------------------------------------------


def test_happy_path_message_round_trips_unchanged() -> None:
    """AC 5: a clean conventional-commit message is returned as-is."""
    raw = "feat: add X\n\nbody\n\nClosed issues: #1"
    assert _extract_commit_message(raw, fallback="...") == raw


# ---------------------------------------------------------------------------
# Additional edge-case tests
# ---------------------------------------------------------------------------


def test_empty_raw_returns_fallback() -> None:
    """Empty input must return fallback."""
    assert _extract_commit_message("", fallback="chore: fallback") == "chore: fallback"


def test_whitespace_only_raw_returns_fallback() -> None:
    """Whitespace-only input must return fallback."""
    assert _extract_commit_message("   \n\t  ", fallback="chore: fallback") == "chore: fallback"


def test_all_conventional_commit_types_are_recognized() -> None:
    """Every type in the regex pattern is recognized as a valid commit start."""
    types = [
        "feat",
        "fix",
        "refactor",
        "test",
        "docs",
        "chore",
        "perf",
        "build",
        "ci",
        "style",
        "revert",
    ]
    for commit_type in types:
        raw = f"Preamble.\n\n{commit_type}: do something"
        result = _extract_commit_message(raw, fallback="FALLBACK")
        assert result == f"{commit_type}: do something", f"Type '{commit_type}' not recognized"


def test_breaking_change_exclamation_mark_recognized() -> None:
    """feat!: breaking change syntax is recognized."""
    raw = "Preamble.\n\nfeat!: breaking change"
    assert _extract_commit_message(raw, fallback="...") == "feat!: breaking change"


def test_scope_with_breaking_change_recognized() -> None:
    """feat(scope)!: breaking change with scope is recognized."""
    raw = "Preamble.\n\nfeat(api)!: breaking API change"
    assert _extract_commit_message(raw, fallback="...") == "feat(api)!: breaking API change"


def test_trailing_whitespace_stripped() -> None:
    """Result must have trailing whitespace stripped."""
    raw = "feat: add X\n\nbody\n\n   "
    result = _extract_commit_message(raw, fallback="...")
    assert result == result.rstrip()
