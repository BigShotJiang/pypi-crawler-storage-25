"""Tests for issue #66: RunnerProtocol annotations across orchestrator and commands.

Verifies that:
- Every orchestrator phase module annotates ``runner_module`` as ``RunnerProtocol``
- ``cycle_loop.py`` annotates all four ``runner_module`` parameters as ``RunnerProtocol``
- No ``runner_module: Any`` annotations remain in orchestrator/ or commands/
- ``commands/generate.py`` infers ``RunnerProtocol`` from ``get_runner()`` (no ``Any``)
- All imports are under ``TYPE_CHECKING`` to avoid runtime circular imports
"""

from __future__ import annotations

import ast
import importlib
from pathlib import Path

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ORCHESTRATOR_DIR = Path(__file__).parent.parent / "src" / "code_generator" / "orchestrator"
COMMANDS_DIR = Path(__file__).parent.parent / "src" / "code_generator" / "commands"

PHASE_MODULES = [
    "phase0_complexity",
    "phase1_plan",
    "phase2_review",
    "phase3_4_implement",
    "phase5_closure",
    "phase6_test",
    "phase7_commit",
]

CYCLE_LOOP_MODULE = "cycle_loop"


def _raw_annotations(func: object) -> dict[str, str]:
    """Return raw (unevaluated) string annotations from a callable."""
    return getattr(func, "__annotations__", {})


def _source(module_name: str, base: Path = ORCHESTRATOR_DIR) -> str:
    """Read source text for a module file."""
    return (base / f"{module_name}.py").read_text()


def _count_runner_module_any(source: str) -> int:
    """Count occurrences of ``runner_module: Any`` in source text."""
    return source.count("runner_module: Any")


# ---------------------------------------------------------------------------
# Zero runner_module: Any annotations
# ---------------------------------------------------------------------------


def test_no_runner_module_any_in_phase_modules() -> None:
    """No phase module should declare runner_module: Any."""
    for name in PHASE_MODULES:
        src = _source(name)
        assert _count_runner_module_any(src) == 0, f"{name}.py still contains 'runner_module: Any'"


def test_no_runner_module_any_in_cycle_loop() -> None:
    src = _source(CYCLE_LOOP_MODULE)
    assert _count_runner_module_any(src) == 0, "cycle_loop.py still contains 'runner_module: Any'"


def test_no_runner_module_any_in_generate_command() -> None:
    src = _source("generate", base=COMMANDS_DIR)
    assert _count_runner_module_any(src) == 0, (
        "commands/generate.py still contains 'runner_module: Any'"
    )


# ---------------------------------------------------------------------------
# runner_module typed as RunnerProtocol in all phase run() functions
# ---------------------------------------------------------------------------


def test_phase_modules_runner_module_annotated_as_runner_protocol() -> None:
    """Every phase module's run() must annotate runner_module as RunnerProtocol."""
    for name in PHASE_MODULES:
        mod = importlib.import_module(f"code_generator.orchestrator.{name}")
        run_fn = getattr(mod, "run", None)
        assert run_fn is not None, f"{name} has no run() function"

        raw = _raw_annotations(run_fn)
        assert "runner_module" in raw, f"{name}.run() has no 'runner_module' annotation"
        assert raw["runner_module"] == "RunnerProtocol", (
            f"{name}.run() annotates runner_module as {raw['runner_module']!r}, "
            "expected 'RunnerProtocol'"
        )


# ---------------------------------------------------------------------------
# cycle_loop: all four functions annotated
# ---------------------------------------------------------------------------


def test_cycle_loop_run_phases_runner_module_annotated() -> None:
    from code_generator.orchestrator import cycle_loop

    raw = _raw_annotations(cycle_loop._run_phases)  # type: ignore[attr-defined]
    assert raw.get("runner_module") == "RunnerProtocol", (
        f"cycle_loop._run_phases annotates runner_module as {raw.get('runner_module')!r}"
    )


def test_cycle_loop_run_single_mode_runner_module_annotated() -> None:
    from code_generator.orchestrator import cycle_loop

    raw = _raw_annotations(cycle_loop.run_single_mode)
    assert raw.get("runner_module") == "RunnerProtocol", (
        f"cycle_loop.run_single_mode annotates runner_module as {raw.get('runner_module')!r}"
    )


def test_cycle_loop_run_multi_cycle_runner_module_annotated() -> None:
    from code_generator.orchestrator import cycle_loop

    raw = _raw_annotations(cycle_loop.run_multi_cycle)
    assert raw.get("runner_module") == "RunnerProtocol", (
        f"cycle_loop.run_multi_cycle annotates runner_module as {raw.get('runner_module')!r}"
    )


def test_cycle_loop_run_cycle_phases_runner_module_annotated() -> None:
    from code_generator.orchestrator import cycle_loop

    raw = _raw_annotations(cycle_loop._run_cycle_phases)  # type: ignore[attr-defined]
    assert raw.get("runner_module") == "RunnerProtocol", (
        f"cycle_loop._run_cycle_phases annotates runner_module as {raw.get('runner_module')!r}"
    )


# ---------------------------------------------------------------------------
# RunnerProtocol imported under TYPE_CHECKING only
# ---------------------------------------------------------------------------


def _type_checking_imports(source: str) -> list[str]:
    """Return names imported inside ``if TYPE_CHECKING:`` blocks."""
    tree = ast.parse(source)
    names: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.If):
            test = node.test
            # Match both ``TYPE_CHECKING`` and ``typing.TYPE_CHECKING``
            is_tc = (isinstance(test, ast.Name) and test.id == "TYPE_CHECKING") or (
                isinstance(test, ast.Attribute) and test.attr == "TYPE_CHECKING"
            )
            if is_tc:
                for stmt in node.body:
                    if isinstance(stmt, ast.ImportFrom | ast.Import):
                        for alias in stmt.names:
                            names.append(alias.asname or alias.name)
    return names


def _top_level_imports(source: str) -> list[str]:
    """Return names imported at module top-level (outside any if block)."""
    tree = ast.parse(source)
    names: list[str] = []
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ImportFrom | ast.Import):
            for alias in node.names:
                names.append(alias.asname or alias.name)
    return names


def test_runner_protocol_imported_under_type_checking_in_phase_modules() -> None:
    """RunnerProtocol must be imported inside TYPE_CHECKING guard in phase modules."""
    for name in PHASE_MODULES:
        src = _source(name)
        tc_imports = _type_checking_imports(src)
        top_imports = _top_level_imports(src)
        assert "RunnerProtocol" in tc_imports, (
            f"{name}.py does not import RunnerProtocol under TYPE_CHECKING"
        )
        assert "RunnerProtocol" not in top_imports, (
            f"{name}.py imports RunnerProtocol at top level (should be under TYPE_CHECKING)"
        )


def test_runner_protocol_imported_under_type_checking_in_cycle_loop() -> None:
    src = _source(CYCLE_LOOP_MODULE)
    tc_imports = _type_checking_imports(src)
    top_imports = _top_level_imports(src)
    assert "RunnerProtocol" in tc_imports, (
        "cycle_loop.py does not import RunnerProtocol under TYPE_CHECKING"
    )
    assert "RunnerProtocol" not in top_imports, (
        "cycle_loop.py imports RunnerProtocol at top level (should be under TYPE_CHECKING)"
    )


# ---------------------------------------------------------------------------
# get_runner() return type
# ---------------------------------------------------------------------------


def test_get_runner_return_type_annotation() -> None:
    """get_runner() must declare RunnerProtocol as its return type."""
    from typing import get_type_hints

    import code_generator.runner as runner_pkg
    from code_generator.runner.protocol import RunnerProtocol

    hints = get_type_hints(runner_pkg.get_runner)
    assert "return" in hints, "get_runner() has no return type annotation"
    assert hints["return"] is RunnerProtocol, (
        f"get_runner() return type is {hints['return']!r}, expected RunnerProtocol"
    )
