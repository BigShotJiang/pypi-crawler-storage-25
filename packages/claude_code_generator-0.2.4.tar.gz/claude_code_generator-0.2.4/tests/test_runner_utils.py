"""Tests for runner.utils — Issue #39.

Verifies that looks_like_upstream_5xx lives in runner/utils.py (public name),
that both sdk_runner and subprocess_runner import from there, and that the
function correctly identifies Anthropic upstream 5xx error markers.
"""

from __future__ import annotations

import inspect

# ---------------------------------------------------------------------------
# Tests: looks_like_upstream_5xx public API in runner.utils
# ---------------------------------------------------------------------------


def test_looks_like_upstream_5xx_is_importable_from_runner_utils() -> None:
    """looks_like_upstream_5xx must be importable directly from runner.utils."""
    from code_generator.runner.utils import looks_like_upstream_5xx  # noqa: F401

    assert callable(looks_like_upstream_5xx)


def test_looks_like_upstream_5xx_returns_true_for_500_error() -> None:
    """Returns True when text contains 'API Error: 500'."""
    from code_generator.runner.utils import looks_like_upstream_5xx

    assert looks_like_upstream_5xx("API Error: 500 internal server error") is True


def test_looks_like_upstream_5xx_returns_true_for_503_error() -> None:
    """Returns True when text contains 'API Error: 503'."""
    from code_generator.runner.utils import looks_like_upstream_5xx

    assert looks_like_upstream_5xx("Upstream: API Error: 503 Service Unavailable") is True


def test_looks_like_upstream_5xx_returns_false_for_normal_text() -> None:
    """Returns False when text has no 5xx error marker."""
    from code_generator.runner.utils import looks_like_upstream_5xx

    assert looks_like_upstream_5xx("All good, no errors here.") is False


def test_looks_like_upstream_5xx_returns_false_for_4xx_error() -> None:
    """Returns False for 4xx errors — only 5xx are upstream errors."""
    from code_generator.runner.utils import looks_like_upstream_5xx

    assert looks_like_upstream_5xx("API Error: 404 not found") is False


def test_looks_like_upstream_5xx_returns_false_for_empty_string() -> None:
    """Returns False for an empty string."""
    from code_generator.runner.utils import looks_like_upstream_5xx

    assert looks_like_upstream_5xx("") is False


# ---------------------------------------------------------------------------
# Tests: sdk_runner no longer defines _looks_like_upstream_5xx locally
# ---------------------------------------------------------------------------


def test_sdk_runner_does_not_define_private_looks_like_upstream_5xx() -> None:
    """sdk_runner must not have a local _looks_like_upstream_5xx definition."""
    import code_generator.runner.sdk_runner as sdk_runner

    assert not hasattr(sdk_runner, "_looks_like_upstream_5xx"), (
        "sdk_runner still defines _looks_like_upstream_5xx — it should import "
        "looks_like_upstream_5xx from runner.utils instead"
    )


def test_sdk_runner_does_not_define_private_upstream_5xx_re() -> None:
    """sdk_runner must not define _UPSTREAM_5XX_RE — it belongs in runner.utils."""
    import code_generator.runner.sdk_runner as sdk_runner

    assert not hasattr(sdk_runner, "_UPSTREAM_5XX_RE"), (
        "sdk_runner still defines _UPSTREAM_5XX_RE — it should live in runner.utils"
    )


# ---------------------------------------------------------------------------
# Tests: subprocess_runner imports from runner.utils, not sdk_runner
# ---------------------------------------------------------------------------


def test_subprocess_runner_does_not_import_from_sdk_runner_private_name() -> None:
    """subprocess_runner must not import _looks_like_upstream_5xx from sdk_runner."""
    import code_generator.runner.subprocess_runner as subprocess_runner

    source = inspect.getsource(subprocess_runner)
    assert "_looks_like_upstream_5xx" not in source, (
        "subprocess_runner still references the private name _looks_like_upstream_5xx"
    )


def test_subprocess_runner_uses_utils_looks_like_upstream_5xx() -> None:
    """subprocess_runner's looks_like_upstream_5xx must be the one from runner.utils."""
    from code_generator.runner import subprocess_runner
    from code_generator.runner.utils import looks_like_upstream_5xx

    # The name bound in subprocess_runner should be the same function object.
    assert getattr(subprocess_runner, "looks_like_upstream_5xx", None) is looks_like_upstream_5xx
