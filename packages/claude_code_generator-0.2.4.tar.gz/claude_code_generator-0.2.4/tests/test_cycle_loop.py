"""Tests for code_generator.orchestrator.cycle_loop."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import cycle_loop

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------


def _make_logger() -> logging.Logger:
    return logging.getLogger("test.cycle_loop")


def _make_state(tmp_path: Path, mode: str = "single") -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
    )
    _state.save_state(state_dir / "state.json", st)
    return st


def _make_cycle(
    cycle_id: int,
    *,
    name: str | None = None,
    depends_on: list[int] | None = None,
    milestone_number: int | None = None,
    status: str = "open",
) -> _state.CycleState:
    return _state.CycleState(
        id=cycle_id,
        name=name or f"Cycle {cycle_id}",
        milestone_number=milestone_number,
        milestone_title=f"Milestone {cycle_id}",
        status=status,
        phase=0,
        issues=[],
        commit_sha=None,
        depends_on=depends_on or [],
    )


# ---------------------------------------------------------------------------
# Patch helpers — patch all phase modules in cycle_loop's namespace
# ---------------------------------------------------------------------------


def _make_phase_patches(phase_return_values: dict | None = None):
    """Return a context manager that patches all phase.run functions."""
    from code_generator.orchestrator import phase5_closure

    defaults = {
        "phase1_plan": AsyncMock(return_value=None),
        "phase2_review": AsyncMock(return_value=None),
        "phase3_4_implement": AsyncMock(return_value=None),
        "phase5_closure": AsyncMock(return_value=phase5_closure.FixResult()),
        "phase6_test": AsyncMock(return_value=None),
        "phase7_commit": AsyncMock(return_value=None),
    }
    if phase_return_values:
        defaults.update(phase_return_values)

    return defaults


# ---------------------------------------------------------------------------
# run_single_mode tests
# ---------------------------------------------------------------------------


class TestRunSingleMode:
    @pytest.mark.asyncio
    async def test_all_phases_called_in_order(self, tmp_path: Path) -> None:
        """Phases 1-7 are called in order for a full single-mode run."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        call_order: list[str] = []

        async def track(name):
            async def _inner(*a, **kw):
                call_order.append(name)
                if name == "phase5":
                    return phase5_closure.FixResult()

            return _inner

        p1 = await track("phase1")
        p2 = await track("phase2")
        p3 = await track("phase3")
        p5 = await track("phase5")
        p6 = await track("phase6")
        p7 = await track("phase7")

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", p2),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            result = await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert call_order == ["phase1", "phase2", "phase3", "phase5", "phase6", "phase7"]
        assert result is st

    @pytest.mark.asyncio
    async def test_start_phase_skips_earlier_phases(self, tmp_path: Path) -> None:
        """start_phase=3 skips phases 1 and 2."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        call_order: list[str] = []

        async def p1(*a, **kw):
            call_order.append("phase1")

        async def p2(*a, **kw):
            call_order.append("phase2")

        async def p3(*a, **kw):
            call_order.append("phase3")

        async def p5(*a, **kw):
            call_order.append("phase5")
            return phase5_closure.FixResult()

        async def p6(*a, **kw):
            call_order.append("phase6")

        async def p7(*a, **kw):
            call_order.append("phase7")

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", p2),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_phase=3,
            )

        assert "phase1" not in call_order
        assert "phase2" not in call_order
        assert "phase3" in call_order
        assert "phase5" in call_order
        assert "phase6" in call_order
        assert "phase7" in call_order

    @pytest.mark.asyncio
    async def test_state_phase_updated_after_each_phase(self, tmp_path: Path) -> None:
        """state.phase is incremented after each phase completes."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        phases_after_p1: list[int | None] = []

        async def p1(*a, **kw):
            pass

        async def p2(*a, **kw):
            phases_after_p1.append(st.phase)

        async def p3(*a, **kw):
            pass

        async def p5(*a, **kw):
            return phase5_closure.FixResult()

        async def p6(*a, **kw):
            pass

        async def p7(*a, **kw):
            pass

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", p2),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        # After phase 1, phase should be 1; p2 sees that value.
        assert phases_after_p1 == [1]

    @pytest.mark.asyncio
    async def test_fix_issues_trigger_reimplementation(self, tmp_path: Path) -> None:
        """When phase 5 returns new_issues, phase 3/4 is called a second time."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        p3_calls: list[int] = []
        new_issue = _state.IssueState(number=99, status="open", agent="python-pro")

        async def p3(*a, **kw):
            p3_calls.append(1)

        async def p5(*a, **kw):
            return phase5_closure.FixResult(new_issues=[new_issue])

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert len(p3_calls) == 2

    @pytest.mark.asyncio
    async def test_exception_propagates_from_phase(self, tmp_path: Path) -> None:
        """Exceptions from phases propagate out of run_single_mode."""
        from code_generator.runner.sdk_runner import OverageAbort

        st = _make_state(tmp_path)

        async def p1(*a, **kw):
            raise OverageAbort("billing active")

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            with pytest.raises(OverageAbort):
                await cycle_loop.run_single_mode(
                    st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
                )


# ---------------------------------------------------------------------------
# run_multi_cycle tests
# ---------------------------------------------------------------------------


class TestRunMultiCycle:
    @pytest.mark.asyncio
    async def test_two_independent_cycles_both_run(self, tmp_path: Path) -> None:
        """Two independent cycles (no deps) both execute."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, milestone_number=10)
        c2 = _make_cycle(2, milestone_number=11)
        st.cycles = [c1, c2]

        ran_cycles: list[int] = []

        async def p1(state, cycle, project_dir, *, runner_module, logger):
            if cycle is not None:
                ran_cycles.append(cycle.id)

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            result = await cycle_loop.run_multi_cycle(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert set(ran_cycles) == {1, 2}
        assert c1.status == "completed"
        assert c2.status == "completed"
        assert result is st

    @pytest.mark.asyncio
    async def test_dependency_order_honored(self, tmp_path: Path) -> None:
        """Cycle 2 (depends_on=[1]) runs only after cycle 1 completes."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, milestone_number=10)
        c2 = _make_cycle(2, depends_on=[1], milestone_number=11)
        st.cycles = [c1, c2]

        completion_order: list[int] = []

        original_run = cycle_loop._run_cycle_phases  # noqa: SLF001

        async def tracked_run(state, cycle, project_dir, runner_module, log, start_phase):
            await original_run(state, cycle, project_dir, runner_module, log, start_phase)
            completion_order.append(cycle.id)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "_run_cycle_phases", tracked_run),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_multi_cycle(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert completion_order == [1, 2]

    @pytest.mark.asyncio
    async def test_milestone_closed_after_cycle_success(self, tmp_path: Path) -> None:
        """close_milestone is called with the cycle's milestone_number."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, milestone_number=42)
        st.cycles = [c1]

        closed_milestones: list[int] = []

        def fake_close(number: int) -> None:
            closed_milestones.append(number)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone", fake_close),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_multi_cycle(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert closed_milestones == [42]

    @pytest.mark.asyncio
    async def test_start_cycle_skips_earlier_cycles(self, tmp_path: Path) -> None:
        """start_cycle=2 means cycle 1 is skipped."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, milestone_number=10)
        c2 = _make_cycle(2, milestone_number=11)
        st.cycles = [c1, c2]

        ran_cycles: list[int] = []

        async def p1(state, cycle, project_dir, *, runner_module, logger):
            if cycle is not None:
                ran_cycles.append(cycle.id)

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_cycle=2,
            )

        # Cycle 1 was skipped (not run) — only cycle 2 ran phases.
        assert 1 not in ran_cycles
        assert 2 in ran_cycles

    @pytest.mark.asyncio
    async def test_start_phase_applied_to_first_cycle_only(self, tmp_path: Path) -> None:
        """start_phase=3 skips phases 1-2 of the first cycle; cycle 2 starts at 1."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, milestone_number=10)
        c2 = _make_cycle(2, depends_on=[1], milestone_number=11)
        st.cycles = [c1, c2]

        phase_starts: list[int] = []

        original_run = cycle_loop._run_cycle_phases  # noqa: SLF001

        async def tracking_run(state, cycle, project_dir, runner_module, log, start_phase):
            phase_starts.append(start_phase)
            await original_run(state, cycle, project_dir, runner_module, log, start_phase)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "_run_cycle_phases", tracking_run),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_phase=3,
            )

        assert phase_starts == [3, 1]

    @pytest.mark.asyncio
    async def test_fresh_session_per_cycle(self, tmp_path: Path) -> None:
        """state.session_id is None at cycle entry (non-negotiable #6)."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        st.session_id = "old-session-abc"
        c1 = _make_cycle(1, milestone_number=10)
        st.cycles = [c1]

        session_ids_at_entry: list[str | None] = []

        async def p1(state, cycle, project_dir, *, runner_module, logger):
            session_ids_at_entry.append(state.session_id)

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_multi_cycle(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        # session_id must be None at the time phase1 is called.
        assert session_ids_at_entry == [None]

    @pytest.mark.asyncio
    async def test_failed_cycle_stops_remaining_cycles(self, tmp_path: Path) -> None:
        """A failed cycle sets status=failed, persists last_error, and re-raises."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, milestone_number=10)
        c2 = _make_cycle(2, depends_on=[1], milestone_number=11)
        st.cycles = [c1, c2]

        ran_cycles: list[int] = []

        async def p1_fail(state, cycle, project_dir, *, runner_module, logger):
            if cycle is not None:
                ran_cycles.append(cycle.id)
                raise ConnectionError("phase1 network error")

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1_fail),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            with pytest.raises(ConnectionError, match="phase1 network error"):
                await cycle_loop.run_multi_cycle(
                    st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
                )

        assert c1.status == "failed"
        assert c2.status == "open"  # Never started.
        assert st.last_error is not None
        assert "phase1 network error" in st.last_error
        assert ran_cycles == [1]  # Cycle 2 never ran.

    @pytest.mark.asyncio
    async def test_no_cycles_is_no_op(self, tmp_path: Path) -> None:
        """run_multi_cycle with no cycles returns state unchanged."""
        st = _make_state(tmp_path, mode="multi-cycle")
        st.cycles = []

        result = await cycle_loop.run_multi_cycle(
            st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
        )

        assert result is st


# ---------------------------------------------------------------------------
# Phase numbering correctness — run_single_mode
# ---------------------------------------------------------------------------


class TestSingleModePhaseNumbering:
    """Verify canonical phase numbers are stored and gates use correct thresholds."""

    @pytest.mark.asyncio
    async def test_state_phase_is_4_after_implement(self, tmp_path: Path) -> None:
        """state.phase == 4 (canonical) when closure is entered, after implement completes."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        phase_at_closure_entry: list[int | None] = []

        async def p5(*a, **kw):
            phase_at_closure_entry.append(st.phase)
            return phase5_closure.FixResult()

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert phase_at_closure_entry == [4], (
            f"Expected state.phase=4 after implement, got {phase_at_closure_entry}"
        )

    @pytest.mark.asyncio
    async def test_state_phase_is_5_after_closure(self, tmp_path: Path) -> None:
        """state.phase == 5 (canonical) when test is entered, after closure completes."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        phase_at_test_entry: list[int | None] = []

        async def p6(*a, **kw):
            phase_at_test_entry.append(st.phase)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert phase_at_test_entry == [5], (
            f"Expected state.phase=5 after closure, got {phase_at_test_entry}"
        )

    @pytest.mark.asyncio
    async def test_state_phase_is_6_after_test(self, tmp_path: Path) -> None:
        """state.phase == 6 (canonical) when commit is entered, after test completes."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        phase_at_commit_entry: list[int | None] = []

        async def p7(*a, **kw):
            phase_at_commit_entry.append(st.phase)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert phase_at_commit_entry == [6], (
            f"Expected state.phase=6 after test, got {phase_at_commit_entry}"
        )

    @pytest.mark.asyncio
    async def test_start_phase_5_runs_closure_not_implement(self, tmp_path: Path) -> None:
        """start_phase=5 runs closure/test/commit but skips implementation (canonical gate)."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        calls: list[str] = []

        async def p3(*a, **kw):
            calls.append("implement")

        async def p5(*a, **kw):
            calls.append("closure")
            return phase5_closure.FixResult()

        async def p6(*a, **kw):
            calls.append("test")

        async def p7(*a, **kw):
            calls.append("commit")

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_phase=5,
            )

        assert "implement" not in calls, "start_phase=5 must skip implement (gate <=4)"
        assert "closure" in calls, "start_phase=5 must run closure (gate <=5)"
        assert "test" in calls
        assert "commit" in calls

    @pytest.mark.asyncio
    async def test_start_phase_6_runs_test_and_commit_only(self, tmp_path: Path) -> None:
        """start_phase=6 skips impl and closure; runs only test and commit."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        calls: list[str] = []

        async def p3(*a, **kw):
            calls.append("implement")

        async def p5(*a, **kw):
            calls.append("closure")
            return phase5_closure.FixResult()

        async def p6(*a, **kw):
            calls.append("test")

        async def p7(*a, **kw):
            calls.append("commit")

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_phase=6,
            )

        assert "implement" not in calls
        assert "closure" not in calls
        assert "test" in calls, "start_phase=6 must run test (gate <=6)"
        assert "commit" in calls

    @pytest.mark.asyncio
    async def test_start_phase_7_runs_only_commit(self, tmp_path: Path) -> None:
        """start_phase=7 skips all phases except commit."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        calls: list[str] = []

        async def p5(*a, **kw):
            calls.append("closure")
            return phase5_closure.FixResult()

        async def p6(*a, **kw):
            calls.append("test")

        async def p7(*a, **kw):
            calls.append("commit")

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_phase=7,
            )

        assert "closure" not in calls, "start_phase=7 must skip closure (gate <=5)"
        assert "test" not in calls, "start_phase=7 must skip test (gate <=6)"
        assert "commit" in calls, "start_phase=7 must run commit (gate <=7)"


# ---------------------------------------------------------------------------
# Phase numbering correctness — _run_cycle_phases
# ---------------------------------------------------------------------------


class TestCyclePhaseNumbering:
    """Verify canonical phase numbers are stored in cycle.phase and gates match."""

    @pytest.mark.asyncio
    async def test_cycle_phase_is_4_after_implement(self, tmp_path: Path) -> None:
        """cycle.phase == 4 (canonical) when closure is entered, after implement."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        cycle = _make_cycle(1)
        phase_at_closure_entry: list[int] = []

        async def p5(*a, **kw):
            phase_at_closure_entry.append(cycle.phase)
            return phase5_closure.FixResult()

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop._run_cycle_phases(  # noqa: SLF001
                state=st,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=MagicMock(),
                log=_make_logger(),
                start_phase=1,
            )

        assert phase_at_closure_entry == [4]

    @pytest.mark.asyncio
    async def test_cycle_phase_is_5_after_closure(self, tmp_path: Path) -> None:
        """cycle.phase == 5 (canonical) when test is entered, after closure."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        cycle = _make_cycle(1)
        phase_at_test_entry: list[int] = []

        async def p6(*a, **kw):
            phase_at_test_entry.append(cycle.phase)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop._run_cycle_phases(  # noqa: SLF001
                state=st,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=MagicMock(),
                log=_make_logger(),
                start_phase=1,
            )

        assert phase_at_test_entry == [5]

    @pytest.mark.asyncio
    async def test_cycle_phase_is_6_after_test(self, tmp_path: Path) -> None:
        """cycle.phase == 6 (canonical) when commit is entered, after test."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        cycle = _make_cycle(1)
        phase_at_commit_entry: list[int] = []

        async def p7(*a, **kw):
            phase_at_commit_entry.append(cycle.phase)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop._run_cycle_phases(  # noqa: SLF001
                state=st,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=MagicMock(),
                log=_make_logger(),
                start_phase=1,
            )

        assert phase_at_commit_entry == [6]

    @pytest.mark.asyncio
    async def test_cycle_start_phase_5_runs_closure_not_implement(self, tmp_path: Path) -> None:
        """_run_cycle_phases start_phase=5 runs closure/test/commit, skips implement."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        cycle = _make_cycle(1)
        calls: list[str] = []

        async def p3(*a, **kw):
            calls.append("implement")

        async def p5(*a, **kw):
            calls.append("closure")
            return phase5_closure.FixResult()

        async def p6(*a, **kw):
            calls.append("test")

        async def p7(*a, **kw):
            calls.append("commit")

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop._run_cycle_phases(  # noqa: SLF001
                state=st,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=MagicMock(),
                log=_make_logger(),
                start_phase=5,
            )

        assert "implement" not in calls
        assert "closure" in calls
        assert "test" in calls
        assert "commit" in calls

    @pytest.mark.asyncio
    async def test_cycle_start_phase_6_skips_closure_runs_test(self, tmp_path: Path) -> None:
        """_run_cycle_phases start_phase=6 skips closure; runs test and commit."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        cycle = _make_cycle(1)
        calls: list[str] = []

        async def p5(*a, **kw):
            calls.append("closure")
            return phase5_closure.FixResult()

        async def p6(*a, **kw):
            calls.append("test")

        async def p7(*a, **kw):
            calls.append("commit")

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop._run_cycle_phases(  # noqa: SLF001
                state=st,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=MagicMock(),
                log=_make_logger(),
                start_phase=6,
            )

        assert "closure" not in calls
        assert "test" in calls
        assert "commit" in calls

    @pytest.mark.asyncio
    async def test_cycle_start_phase_7_runs_only_commit(self, tmp_path: Path) -> None:
        """_run_cycle_phases start_phase=7 skips all except commit."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        cycle = _make_cycle(1)
        calls: list[str] = []

        async def p5(*a, **kw):
            calls.append("closure")
            return phase5_closure.FixResult()

        async def p6(*a, **kw):
            calls.append("test")

        async def p7(*a, **kw):
            calls.append("commit")

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop._run_cycle_phases(  # noqa: SLF001
                state=st,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=MagicMock(),
                log=_make_logger(),
                start_phase=7,
            )

        assert "closure" not in calls
        assert "test" not in calls
        assert "commit" in calls


# ---------------------------------------------------------------------------
# Eligible cycle helper
# ---------------------------------------------------------------------------


class TestEligibleCycles:
    def test_returns_open_cycles_with_satisfied_deps(self, tmp_path: Path) -> None:
        st = _make_state(tmp_path)
        c1 = _make_cycle(1, status="completed")
        c2 = _make_cycle(2, depends_on=[1])
        c3 = _make_cycle(3, depends_on=[2])  # Dep not satisfied.
        st.cycles = [c1, c2, c3]

        eligible = cycle_loop._eligible_cycles(st, completed_ids={1})  # noqa: SLF001
        assert len(eligible) == 1
        assert eligible[0].id == 2

    def test_excludes_already_completed(self, tmp_path: Path) -> None:
        st = _make_state(tmp_path)
        c1 = _make_cycle(1, status="completed")
        st.cycles = [c1]

        eligible = cycle_loop._eligible_cycles(st, completed_ids={1})  # noqa: SLF001
        assert eligible == []

    def test_includes_cycles_with_no_deps(self, tmp_path: Path) -> None:
        st = _make_state(tmp_path)
        c1 = _make_cycle(1)
        c2 = _make_cycle(2)
        st.cycles = [c1, c2]

        eligible = cycle_loop._eligible_cycles(st, completed_ids=set())  # noqa: SLF001
        assert len(eligible) == 2

    # ------------------------------------------------------------------
    # Complex dependency graph tests
    # ------------------------------------------------------------------

    def test_linear_chain_only_head_eligible_initially(self, tmp_path: Path) -> None:
        """A→B→C: only A is eligible when nothing is completed."""
        st = _make_state(tmp_path)
        a = _make_cycle(1)
        b = _make_cycle(2, depends_on=[1])
        c = _make_cycle(3, depends_on=[2])
        st.cycles = [a, b, c]

        eligible = cycle_loop._eligible_cycles(st, completed_ids=set())  # noqa: SLF001

        assert len(eligible) == 1
        assert eligible[0].id == 1

    def test_linear_chain_middle_eligible_after_head_completes(self, tmp_path: Path) -> None:
        """A→B→C: after A completed, only B is eligible (not C)."""
        st = _make_state(tmp_path)
        a = _make_cycle(1, status="completed")
        b = _make_cycle(2, depends_on=[1])
        c = _make_cycle(3, depends_on=[2])
        st.cycles = [a, b, c]

        eligible = cycle_loop._eligible_cycles(st, completed_ids={1})  # noqa: SLF001

        assert len(eligible) == 1
        assert eligible[0].id == 2

    def test_diamond_middle_nodes_eligible_after_root_completes(self, tmp_path: Path) -> None:
        """A→{B,C}→D: B and C are eligible after A completes; D is not yet."""
        st = _make_state(tmp_path)
        a = _make_cycle(1, status="completed")
        b = _make_cycle(2, depends_on=[1])
        c = _make_cycle(3, depends_on=[1])
        d = _make_cycle(4, depends_on=[2, 3])
        st.cycles = [a, b, c, d]

        eligible = cycle_loop._eligible_cycles(st, completed_ids={1})  # noqa: SLF001
        eligible_ids = {cy.id for cy in eligible}

        assert eligible_ids == {2, 3}

    def test_diamond_sink_eligible_only_after_both_middle_nodes_complete(
        self, tmp_path: Path
    ) -> None:
        """A→{B,C}→D: D is eligible only after both B and C complete."""
        st = _make_state(tmp_path)
        a = _make_cycle(1, status="completed")
        b = _make_cycle(2, status="completed", depends_on=[1])
        c = _make_cycle(3, status="completed", depends_on=[1])
        d = _make_cycle(4, depends_on=[2, 3])
        st.cycles = [a, b, c, d]

        eligible = cycle_loop._eligible_cycles(st, completed_ids={1, 2, 3})  # noqa: SLF001

        assert len(eligible) == 1
        assert eligible[0].id == 4

    def test_diamond_sink_not_eligible_when_only_one_middle_node_completes(
        self, tmp_path: Path
    ) -> None:
        """A→{B,C}→D: D must NOT be eligible when only B is done (C still open)."""
        st = _make_state(tmp_path)
        a = _make_cycle(1, status="completed")
        b = _make_cycle(2, status="completed", depends_on=[1])
        c = _make_cycle(3, depends_on=[1])
        d = _make_cycle(4, depends_on=[2, 3])
        st.cycles = [a, b, c, d]

        eligible = cycle_loop._eligible_cycles(st, completed_ids={1, 2})  # noqa: SLF001
        eligible_ids = {cy.id for cy in eligible}

        assert 4 not in eligible_ids
        assert eligible_ids == {3}

    def test_two_dep_cycle_eligible_only_when_both_deps_completed(self, tmp_path: Path) -> None:
        """Cycle with depends_on=[1, 2] is ineligible when only one dep is satisfied."""
        st = _make_state(tmp_path)
        c1 = _make_cycle(1, status="completed")
        c2 = _make_cycle(2)
        c3 = _make_cycle(3, depends_on=[1, 2])
        st.cycles = [c1, c2, c3]

        eligible_partial = cycle_loop._eligible_cycles(st, completed_ids={1})  # noqa: SLF001
        assert 3 not in {cy.id for cy in eligible_partial}

        c2_completed = _make_cycle(2, status="completed")
        st.cycles = [c1, c2_completed, c3]
        eligible_full = cycle_loop._eligible_cycles(st, completed_ids={1, 2})  # noqa: SLF001
        assert 3 in {cy.id for cy in eligible_full}

    def test_all_cycles_completed_returns_empty_list(self, tmp_path: Path) -> None:
        """When every cycle has status != 'open', returns empty list."""
        st = _make_state(tmp_path)
        c1 = _make_cycle(1, status="completed")
        c2 = _make_cycle(2, status="completed", depends_on=[1])
        c3 = _make_cycle(3, status="completed", depends_on=[2])
        st.cycles = [c1, c2, c3]

        eligible = cycle_loop._eligible_cycles(st, completed_ids={1, 2, 3})  # noqa: SLF001

        assert eligible == []

    def test_unsatisfied_dep_id_not_in_completed_ids_excludes_cycle(self, tmp_path: Path) -> None:
        """Cycle is excluded when depends_on references an ID absent from completed_ids."""
        st = _make_state(tmp_path)
        c_orphan = _make_cycle(99, depends_on=[42])  # ID 42 never exists
        st.cycles = [c_orphan]

        eligible = cycle_loop._eligible_cycles(st, completed_ids=set())  # noqa: SLF001

        assert eligible == []


# ---------------------------------------------------------------------------
# Regression tests — Issue #33: phase numbering mismatch
# ---------------------------------------------------------------------------


class TestPhaseImplementConstant:
    """Regression tests for bug #33: _PHASE_IMPLEMENT must be 4, not 3."""

    def test_phase_implement_constant_is_4(self) -> None:
        """_PHASE_IMPLEMENT equals 4 (upper bound of combined phases 3+4)."""
        assert cycle_loop._PHASE_IMPLEMENT == 4  # noqa: SLF001

    @pytest.mark.asyncio
    async def test_start_phase_4_executes_implement_skips_plan_and_review(
        self, tmp_path: Path
    ) -> None:
        """_run_phases(start_phase=4) executes phase3_4 but skips plan and review."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        called: list[str] = []

        async def p1(*a, **kw):
            called.append("phase1")

        async def p2(*a, **kw):
            called.append("phase2")

        async def p3(*a, **kw):
            called.append("phase3_4")

        async def p5(*a, **kw):
            called.append("phase5")
            return phase5_closure.FixResult()

        async def p6(*a, **kw):
            called.append("phase6")

        async def p7(*a, **kw):
            called.append("phase7")

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", p2),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_phase=4,
            )

        assert "phase1" not in called
        assert "phase2" not in called
        assert "phase3_4" in called


# ---------------------------------------------------------------------------
# base_commit capture tests
# ---------------------------------------------------------------------------


class TestBaseCommitCapture:
    """Tests for base_commit capture at Phase 3/4 entry in _run_phases()."""

    @pytest.mark.asyncio
    async def test_single_mode_sets_base_commit(self, tmp_path: Path) -> None:
        """Single-mode run sets state.base_commit to the HEAD SHA before Phase 3/4."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        assert st.base_commit is None

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.git_ops, "git_rev_parse_head", return_value="abc1234"),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert st.base_commit == "abc1234"

    @pytest.mark.asyncio
    async def test_multi_cycle_sets_cycle_base_commit(self, tmp_path: Path) -> None:
        """Multi-cycle run sets cycle.base_commit to the HEAD SHA before Phase 3/4."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, milestone_number=10)
        st.cycles = [c1]
        assert c1.base_commit is None

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.git_ops, "git_rev_parse_head", return_value="def5678"),
        ):
            await cycle_loop.run_multi_cycle(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert c1.base_commit == "def5678"

    @pytest.mark.asyncio
    async def test_base_commit_not_overwritten_on_resume(self, tmp_path: Path) -> None:
        """If base_commit is already set, it is NOT overwritten on --continue resume."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        st.base_commit = "original_sha"

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.git_ops, "git_rev_parse_head", return_value="new_sha"),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert st.base_commit == "original_sha"

    @pytest.mark.asyncio
    async def test_git_error_is_caught_base_commit_remains_none(self, tmp_path: Path) -> None:
        """GitError from git_rev_parse_head is caught; base_commit stays None."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(
                cycle_loop.git_ops,
                "git_rev_parse_head",
                side_effect=cycle_loop.git_ops.GitError(128, "not a git repo"),
            ),
        ):
            # Should not raise — GitError is swallowed.
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert st.base_commit is None


# ---------------------------------------------------------------------------
# TestLastErrorCleanup
# ---------------------------------------------------------------------------


class TestLastErrorCleanup:
    """Stale last_error / rate_limit_type are cleared after each successful phase."""

    @pytest.mark.asyncio
    async def test_last_error_cleared_after_phase2_succeeds(self, tmp_path: Path) -> None:
        """Phase 1 leaves last_error='foo'; after Phase 2 succeeds, last_error is None."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        st.last_error = "foo"
        st.rate_limit_type = "upstream_5xx"

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.git_ops, "git_rev_parse_head", return_value="abc123"),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert st.last_error is None
        assert st.rate_limit_type is None

    @pytest.mark.asyncio
    async def test_last_error_not_cleared_when_phase_raises(self, tmp_path: Path) -> None:
        """When phase2 sets last_error and raises, the error persists (cleanup does NOT run)."""
        st = _make_state(tmp_path)

        async def _phase2_sets_error_and_raises(*a, **kw):
            st.last_error = "phase2 exploded"
            raise RuntimeError("phase2 exploded")

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", _phase2_sets_error_and_raises),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.git_ops, "git_rev_parse_head", return_value="abc123"),
        ):
            with pytest.raises(RuntimeError, match="phase2 exploded"):
                await cycle_loop.run_single_mode(
                    st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
                )

        # phase2 set last_error then raised; the cleanup block never ran, so it persists.
        assert st.last_error == "phase2 exploded"

    @pytest.mark.asyncio
    async def test_cleanup_runs_at_every_phase_boundary(self, tmp_path: Path) -> None:
        """Cleanup (last_error=None) is persisted to state.json after every phase."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)

        saved_last_errors: list[str | None] = []

        original_save = _state.save_state

        def _capturing_save(path, state_obj):
            original_save(path, state_obj)
            saved_last_errors.append(state_obj.last_error)

        p1 = AsyncMock()
        p2 = AsyncMock()
        p3 = AsyncMock()
        p5 = AsyncMock(return_value=phase5_closure.FixResult())
        p6 = AsyncMock()
        p7 = AsyncMock()

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", p2),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.git_ops, "git_rev_parse_head", return_value="abc123"),
            patch.object(_state, "save_state", side_effect=_capturing_save),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        # Every save after a phase should have last_error=None.
        assert all(v is None for v in saved_last_errors), (
            f"Expected all phase-boundary saves to have last_error=None, got: {saved_last_errors}"
        )

    @pytest.mark.asyncio
    async def test_last_error_cleared_in_multi_cycle_after_successful_phase(
        self, tmp_path: Path
    ) -> None:
        """In multi-cycle mode, last_error is cleared at each phase boundary."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        st.last_error = "stale_multi"
        c1 = _make_cycle(1, milestone_number=10)
        st.cycles = [c1]

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.git_ops, "git_rev_parse_head", return_value="abc123"),
        ):
            await cycle_loop.run_multi_cycle(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert st.last_error is None
        assert st.rate_limit_type is None
        assert st.base_commit is None
