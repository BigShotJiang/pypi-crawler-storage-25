"""Tests for rate_limit.main_loop — Issue #12.

Uses fake now_fn and sleep_fn so no wall-clock sleeping occurs.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any
from unittest.mock import AsyncMock

if TYPE_CHECKING:
    from pathlib import Path

import pytest

from code_generator import state as _state
from code_generator.runner.rate_limit import _wait_if_paused, main_loop
from code_generator.runner.sdk_runner import (
    ApiUpstreamError,
    MaxTurnsExceeded,
    OverageAbort,
    RateLimitHit,
    RunResult,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_result(text: str = "ok") -> RunResult:
    return RunResult(text=text, session_id="sess-ok", tokens_in=1, tokens_out=2)


class _FakeRunner:
    """Simulates a runner that raises RateLimitHit once then succeeds."""

    def __init__(self, side_effects: list[Any]) -> None:
        self._effects = iter(side_effects)
        self.call_count = 0

    async def run(
        self,
        prompt: str,
        options: Any,
        *,
        logger: Any,
        state_path: Path,
    ) -> RunResult:
        self.call_count += 1
        effect = next(self._effects)
        if isinstance(effect, BaseException):
            raise effect
        return effect


def _make_options() -> Any:
    class FakeOptions:
        def __init__(self) -> None:
            self.permission_mode: str | None = None
            self.resume: str | None = None
            self.model = "claude-sonnet-4-6"
            self.max_turns = 10
            self.allowed_tools: list[str] = []
            self.cwd: str | None = None

    return FakeOptions()


def _write_paused_state(state_path: Path, paused_until: int) -> None:
    state_path.parent.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_path)
    _state.mark_paused(
        st, resets_at=paused_until, rate_limit_type="five_hour", session_id="sess-paused"
    )
    _state.save_state(state_path, st)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_no_pause_runner_succeeds_on_first_try(tmp_path: Path) -> None:
    """No pause in state, runner succeeds → result returned, no sleep calls."""
    state_path = tmp_path / ".code-generator" / "state.json"
    runner = _FakeRunner([_make_result("hello")])
    options = _make_options()

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    import logging

    result = await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.ok"),
        now_fn=lambda: 1000.0,
        sleep_fn=fake_sleep,
    )

    assert result.text == "hello"
    assert sleep_calls == []
    assert runner.call_count == 1


@pytest.mark.asyncio
async def test_pause_on_entry_waits_then_succeeds(tmp_path: Path) -> None:
    """Paused state causes sleep before running; runner succeeds after."""
    state_path = tmp_path / ".code-generator" / "state.json"
    paused_until = 2000
    _write_paused_state(state_path, paused_until)

    runner = _FakeRunner([_make_result("after wait")])
    options = _make_options()

    # Time advances: starts at 1800, ends at 2001 (past paused_until)
    time_vals = [1800.0, 1860.0, 1920.0, 1980.0, 2001.0]
    time_iter = iter(time_vals)

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    import logging

    result = await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.pause"),
        now_fn=lambda: next(time_iter),
        sleep_fn=fake_sleep,
    )

    assert result.text == "after wait"
    assert len(sleep_calls) >= 1
    assert all(s <= 60 for s in sleep_calls)


@pytest.mark.asyncio
async def test_runner_raises_rate_limit_hit_once_then_succeeds(tmp_path: Path) -> None:
    """Runner raises RateLimitHit once, then succeeds on retry."""
    state_path = tmp_path / ".code-generator" / "state.json"

    # The runner raises RateLimitHit first, which also updates state.
    # The fake needs to do what the real runner would: persist pause state.
    class _PausingRunner:
        call_count = 0

        async def run(  # noqa: E501
            self, prompt: str, options: Any, *, logger: Any, state_path: Path
        ) -> RunResult:
            self.call_count += 1
            if self.call_count == 1:
                # Simulate what sdk_runner does: persist state before raising.
                st = _state.load_state(state_path)
                _state.mark_paused(
                    st, resets_at=5000, rate_limit_type="five_hour", session_id="s-rl"
                )
                _state.save_state(state_path, st)
                raise RateLimitHit(5000, "five_hour")
            return _make_result("retry success")

    runner = _PausingRunner()
    options = _make_options()

    # now_fn is called many times during is_paused checks and chunk calculations.
    # Use a counter-based approach: before paused_until=5000 then advance past it.
    call_count = [0]

    def advancing_now() -> float:
        call_count[0] += 1
        # First few calls: before RateLimitHit, not paused → return 1000
        # After runner raises, state has paused_until=5000:
        #   calls to is_paused(now=1000) → True → compute chunk → sleep → reload
        #   then is_paused(now=5001) → False → exit wait loop
        if call_count[0] <= 3:
            return 1000.0
        elif call_count[0] <= 5:
            return 1000.0  # inside _wait_if_paused: first is_paused + chunk calc
        else:
            return 5001.0  # past paused_until → exit loop

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    import logging

    result = await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.retry"),
        now_fn=advancing_now,
        sleep_fn=fake_sleep,
    )

    assert result.text == "retry success"
    assert runner.call_count == 2
    assert len(sleep_calls) >= 1


@pytest.mark.asyncio
async def test_overage_abort_propagates_without_retry(tmp_path: Path) -> None:
    """OverageAbort propagates unchanged — no retry loop."""
    state_path = tmp_path / ".code-generator" / "state.json"
    runner = _FakeRunner([OverageAbort("billing active")])
    options = _make_options()

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    import logging

    with pytest.raises(OverageAbort):
        await main_loop(
            runner,
            "prompt",
            options,
            state_path=state_path,
            logger=logging.getLogger("test.ml.overage"),
            now_fn=lambda: 1000.0,
            sleep_fn=fake_sleep,
        )

    assert sleep_calls == []


@pytest.mark.asyncio
async def test_successful_run_clears_paused_until(tmp_path: Path) -> None:
    """After a successful run, paused_until is cleared in state.json."""
    state_path = tmp_path / ".code-generator" / "state.json"
    _write_paused_state(state_path, 1)  # paused_until=1 → already expired

    runner = _FakeRunner([_make_result("done")])
    options = _make_options()

    import logging

    await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.clear"),
        now_fn=lambda: 2000.0,  # well past paused_until=1
        sleep_fn=AsyncMock(),
    )

    raw = json.loads(state_path.read_text())
    assert raw["paused_until"] is None


# ---------------------------------------------------------------------------
# _wait_if_paused edge cases (Issue #43)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_wait_if_paused_expired_pause_does_not_sleep(tmp_path: Path) -> None:
    """paused_until is in the past → is_paused returns False immediately; no sleep."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    _write_paused_state(state_path, paused_until=1000)

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    await _wait_if_paused(
        state_path,
        logging.getLogger("test.wip.expired"),
        now_fn=lambda: 2000.0,  # well past paused_until=1000
        sleep_fn=fake_sleep,
    )

    assert sleep_calls == []


@pytest.mark.asyncio
async def test_wait_if_paused_150s_remaining_three_chunks(tmp_path: Path) -> None:
    """150s remaining → sleep in three chunks: 60, 60, 30."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    _write_paused_state(state_path, paused_until=1150)

    # now_fn is called once per _wait_if_paused loop iteration (captured as local).
    # After 3 sleeps the 4th call returns 1150, so is_paused(1150>=1150) → False.
    now_vals = iter([1000.0, 1060.0, 1120.0, 1150.0])

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    await _wait_if_paused(
        state_path,
        logging.getLogger("test.wip.150s"),
        now_fn=lambda: next(now_vals),
        sleep_fn=fake_sleep,
    )

    assert sleep_calls == [60.0, 60.0, 30.0]


# ---------------------------------------------------------------------------
# main_loop upstream 5xx backoff (Issue #43)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_main_loop_upstream_backoff_all_five_tiers(tmp_path: Path) -> None:
    """ApiUpstreamError raised 5× → sleep tiers [60, 120, 240, 480, 600]; then success."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"

    errors: list[Any] = [
        ApiUpstreamError("err1"),
        ApiUpstreamError("err2"),
        ApiUpstreamError("err3"),
        ApiUpstreamError("err4"),
        ApiUpstreamError("err5"),
        _make_result("recovered"),
    ]
    runner = _FakeRunner(errors)
    options = _make_options()

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    result = await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.upstream.tiers"),
        now_fn=lambda: 1000.0,
        sleep_fn=fake_sleep,
    )

    assert result.text == "recovered"
    assert runner.call_count == 6
    assert sleep_calls == [60.0, 120.0, 240.0, 480.0, 600.0]


@pytest.mark.asyncio
async def test_main_loop_does_not_catch_max_turns_exceeded(tmp_path: Path) -> None:
    """MaxTurnsExceeded must propagate out of main_loop — deterministic failure,
    never retried via exponential backoff. This is the fix for the Phase 7
    infinite-loop bug where max_turns exhaustion was misclassified as upstream 5xx."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    runner = _FakeRunner([MaxTurnsExceeded("budget exhausted num_turns=5")])
    options = _make_options()

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    with pytest.raises(MaxTurnsExceeded, match="budget exhausted"):
        await main_loop(
            runner,
            "prompt",
            options,
            state_path=state_path,
            logger=logging.getLogger("test.ml.maxturns"),
            now_fn=lambda: 1000.0,
            sleep_fn=fake_sleep,
        )

    assert runner.call_count == 1, "main_loop must NOT retry MaxTurnsExceeded"
    assert sleep_calls == [], "main_loop must NOT sleep on MaxTurnsExceeded"


@pytest.mark.asyncio
async def test_main_loop_upstream_recovery_clears_last_error(tmp_path: Path) -> None:
    """After ApiUpstreamError then success, state.last_error is cleared to None."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"

    runner = _FakeRunner([ApiUpstreamError("transient"), _make_result("ok")])
    options = _make_options()

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    result = await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.upstream.recovery"),
        now_fn=lambda: 1000.0,
        sleep_fn=fake_sleep,
    )

    assert result.text == "ok"
    raw = json.loads(state_path.read_text())
    assert raw["last_error"] is None
    assert sleep_calls == [60.0]


@pytest.mark.asyncio
async def test_main_loop_rate_limit_resets_upstream_counter(tmp_path: Path) -> None:
    """RateLimitHit resets upstream_attempt to 0; subsequent ApiUpstreamError uses tier 0 (60s)."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"

    class _RateThenUpstreamRunner:
        call_count = 0

        async def run(
            self, prompt: str, options: Any, *, logger: Any, state_path: Path
        ) -> RunResult:
            self.call_count += 1
            if self.call_count == 1:
                st = _state.load_state(state_path)
                _state.mark_paused(
                    st, resets_at=5000, rate_limit_type="five_hour", session_id="s-rl"
                )
                _state.save_state(state_path, st)
                raise RateLimitHit(5000, "five_hour")
            if self.call_count == 2:
                raise ApiUpstreamError("5xx after rl")
            return _make_result("final")

    runner = _RateThenUpstreamRunner()
    options = _make_options()

    # now_fn sequence:
    #   call 1 — initial _wait_if_paused: now=1000, paused_until=None → False
    #   call 2 — _wait_if_paused after RateLimitHit: now=4900, is_paused(4900<5000)→True → sleep(60)
    #   call 3 — _wait_if_paused reload: now=5001, is_paused(5001>=5000)→False → exit
    #   call 4 — upstream error handling: paused_until = int(now_fn() + 60)
    now_vals = iter([1000.0, 4900.0, 5001.0, 1000.0])

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    result = await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.rl.then.upstream"),
        now_fn=lambda: next(now_vals),
        sleep_fn=fake_sleep,
    )

    assert result.text == "final"
    assert runner.call_count == 3
    # First sleep: waiting out the rate-limit pause (60s chunk of 5000-4900=100 → min(60,100)=60)
    # Second sleep: upstream backoff tier 0 → 60s (confirming counter was reset)
    assert sleep_calls == [60.0, 60.0]


# ---------------------------------------------------------------------------
# Issue #54: fill coverage gaps — tier saturation, mixed sequence,
#            missing state file, multi-cycle state integrity
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_main_loop_upstream_backoff_tier_saturation(tmp_path: Path) -> None:
    """6th and 7th ApiUpstreamError re-use 600s (capped) — no IndexError."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"

    errors: list[Any] = [
        ApiUpstreamError("err1"),
        ApiUpstreamError("err2"),
        ApiUpstreamError("err3"),
        ApiUpstreamError("err4"),
        ApiUpstreamError("err5"),
        ApiUpstreamError("err6"),
        ApiUpstreamError("err7"),
        _make_result("recovered"),
    ]
    runner = _FakeRunner(errors)
    options = _make_options()

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    result = await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.upstream.saturated"),
        now_fn=lambda: 1000.0,
        sleep_fn=fake_sleep,
    )

    assert result.text == "recovered"
    assert runner.call_count == 8
    # Tiers: 60, 120, 240, 480, 600; then capped at 600 for both extra errors.
    assert sleep_calls == [60.0, 120.0, 240.0, 480.0, 600.0, 600.0, 600.0]


@pytest.mark.asyncio
async def test_main_loop_upstream_ratelimit_upstream_resets_counter(tmp_path: Path) -> None:
    """upstream→rate-limit→upstream: counter resets after RateLimitHit, so 3rd uses tier 0."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"

    class _UpstreamRlUpstreamRunner:
        call_count = 0

        async def run(
            self, prompt: str, options: Any, *, logger: Any, state_path: Path
        ) -> RunResult:
            self.call_count += 1
            if self.call_count == 1:
                raise ApiUpstreamError("first upstream error")
            if self.call_count == 2:
                st = _state.load_state(state_path)
                _state.mark_paused(
                    st, resets_at=5000, rate_limit_type="five_hour", session_id="s-rl"
                )
                _state.save_state(state_path, st)
                raise RateLimitHit(5000, "five_hour")
            if self.call_count == 3:
                raise ApiUpstreamError("second upstream error after rl reset")
            return _make_result("success")

    runner = _UpstreamRlUpstreamRunner()
    options = _make_options()

    # now_fn sequence:
    #   1. Initial _wait_if_paused: now=1000, state absent → is_paused(None) → False
    #   2. ApiUpstreamError handler: int(now_fn() + 60) = int(1000 + 60) = 1060
    #   3. _wait_if_paused after RateLimitHit: now=4990, is_paused(4990<5000) → True → sleep(10)
    #   4. _wait_if_paused reload: now=5001, is_paused(5001>=5000) → False → exit
    #   5. ApiUpstreamError handler: int(now_fn() + 60) = int(1000 + 60) = 1060
    now_vals = iter([1000.0, 1000.0, 4990.0, 5001.0, 1000.0])

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    result = await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.upstream.rl.upstream"),
        now_fn=lambda: next(now_vals),
        sleep_fn=fake_sleep,
    )

    assert result.text == "success"
    assert runner.call_count == 4
    # sleep[0]: upstream tier 0 → 60s
    # sleep[1]: rate-limit wait chunk (min(60, 5000-4990)=10)
    # sleep[2]: upstream tier 0 again (counter was reset by RateLimitHit) → 60s
    assert sleep_calls == [60.0, 10.0, 60.0]


@pytest.mark.asyncio
async def test_wait_if_paused_nonexistent_state_file_does_not_crash(tmp_path: Path) -> None:
    """_wait_if_paused with a missing state file must not raise any exception."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    assert not state_path.exists()

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    # Must not raise; load_state returns a default with paused_until=None.
    await _wait_if_paused(
        state_path,
        logging.getLogger("test.wip.missing"),
        now_fn=lambda: 1000.0,
        sleep_fn=fake_sleep,
    )

    assert sleep_calls == []


@pytest.mark.asyncio
async def test_main_loop_state_integrity_across_two_pause_resume_cycles(
    tmp_path: Path,
) -> None:
    """paused_until tracks correctly across two consecutive RateLimitHit cycles."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"

    class _TwoRateLimitRunner:
        call_count = 0

        async def run(
            self, prompt: str, options: Any, *, logger: Any, state_path: Path
        ) -> RunResult:
            self.call_count += 1
            if self.call_count == 1:
                st = _state.load_state(state_path)
                _state.mark_paused(
                    st, resets_at=3000, rate_limit_type="five_hour", session_id="s-rl-1"
                )
                _state.save_state(state_path, st)
                raise RateLimitHit(3000, "five_hour")
            if self.call_count == 2:
                st = _state.load_state(state_path)
                _state.mark_paused(
                    st, resets_at=6000, rate_limit_type="five_hour", session_id="s-rl-2"
                )
                _state.save_state(state_path, st)
                raise RateLimitHit(6000, "five_hour")
            return _make_result("done after two pauses")

    runner = _TwoRateLimitRunner()
    options = _make_options()

    # now_fn sequence (one call per loop iteration, captured as local):
    #   1. Initial _wait_if_paused: now=1000, paused_until=None → False
    #   --- first RateLimitHit (paused_until=3000) ---
    #   2. _wait_if_paused: now=2900, is_paused(2900<3000)→True, remaining=100 → sleep(60)
    #   3. _wait_if_paused: now=3001, is_paused(3001>=3000)→False → exit
    #   --- second RateLimitHit (paused_until=6000) ---
    #   4. _wait_if_paused: now=5900, is_paused(5900<6000)→True, remaining=100 → sleep(60)
    #   5. _wait_if_paused: now=6001, is_paused(6001>=6000)→False → exit
    now_vals = iter([1000.0, 2900.0, 3001.0, 5900.0, 6001.0])

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    result = await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.two.pauses"),
        now_fn=lambda: next(now_vals),
        sleep_fn=fake_sleep,
    )

    assert result.text == "done after two pauses"
    assert runner.call_count == 3
    # Two 60s chunks (one per RateLimitHit window).
    assert sleep_calls == [60.0, 60.0]
    # Final state: paused_until cleared after success.
    raw = json.loads(state_path.read_text())
    assert raw["paused_until"] is None
    assert raw["rate_limit_type"] is None


# ---------------------------------------------------------------------------
# Issue #81: intermediate state persistence and pause marker clearing
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_main_loop_upstream_intermediate_state_persistence(tmp_path: Path) -> None:
    """After ApiUpstreamError but before recovery, state.json has rate_limit_type='upstream_5xx'
    and paused_until == int(now + tier_delay).  Verified inside fake_sleep (called after save)."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"

    NOW = 1000.0
    TIER_0_DELAY = 60  # _UPSTREAM_BACKOFF_SECS[0]
    expected_paused_until = int(NOW + TIER_0_DELAY)  # 1060

    snapshot: dict[str, Any] = {}

    async def fake_sleep(secs: float) -> None:
        # State is persisted *before* sleep_fn is called — snapshot mid-flow here.
        raw = json.loads(state_path.read_text())
        snapshot.update(raw)

    runner = _FakeRunner([ApiUpstreamError("transient 5xx"), _make_result("ok")])
    options = _make_options()

    await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.upstream.intermediate"),
        now_fn=lambda: NOW,
        sleep_fn=fake_sleep,
    )

    assert snapshot["rate_limit_type"] == "upstream_5xx"
    assert snapshot["paused_until"] == expected_paused_until
    assert snapshot["last_error"] == "upstream_5xx: transient 5xx"


# ---------------------------------------------------------------------------
# Issue #131: clamp paused_until to MAX_PAUSE_SECONDS (12 hours)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_wait_if_paused_clamps_48h_to_12h_and_logs_warning(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """paused_until = now + 48h is clamped to now + 12h; warning includes both values."""
    import json
    import logging

    from code_generator.runner.rate_limit import MAX_PAUSE_SECONDS

    state_path = tmp_path / ".code-generator" / "state.json"
    NOW = 1000.0
    FORTY_EIGHT_H = 172800
    TWELVE_H = MAX_PAUSE_SECONDS  # 43200

    _write_paused_state(state_path, paused_until=int(NOW + FORTY_EIGHT_H))

    # now_fn sequence:
    #   1st loop iter: now=1000.0 → clamp fires → is_paused(1000 < 44200) → True → sleep(60)
    #   2nd loop iter: now=44201.0 → no clamp → is_paused(44200 < 44201) → False → break
    now_vals = iter([NOW, NOW + TWELVE_H + 1])

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    with caplog.at_level(logging.WARNING, logger="code_generator.runner.rate_limit"):
        await _wait_if_paused(
            state_path,
            logging.getLogger("code_generator.runner.rate_limit"),
            now_fn=lambda: next(now_vals),
            sleep_fn=fake_sleep,
        )

    # Clamped value persisted to state.json
    raw = json.loads(state_path.read_text())
    assert raw["paused_until"] == int(NOW + TWELVE_H), (
        f"Expected paused_until={int(NOW + TWELVE_H)}, got {raw['paused_until']}"
    )

    # Warning log contains original and clamped values
    warning_messages = [r.message for r in caplog.records if r.levelno == logging.WARNING]
    assert warning_messages, "Expected at least one WARNING log entry"
    combined = " ".join(warning_messages)
    assert str(int(NOW + FORTY_EIGHT_H)) in combined, "Original paused_until missing from warning"
    assert str(int(NOW + TWELVE_H)) in combined, "Clamped paused_until missing from warning"

    # Slept exactly one 60s chunk after the clamp
    assert sleep_calls == [60.0]


@pytest.mark.asyncio
async def test_wait_if_paused_2h_does_not_clamp(tmp_path: Path) -> None:
    """paused_until = now + 2h (well under 12h limit) is NOT clamped; state unchanged."""
    import json
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    NOW = 1000.0
    TWO_H = 7200
    original_paused_until = int(NOW + TWO_H)  # 8200

    _write_paused_state(state_path, paused_until=original_paused_until)

    # now_fn sequence:
    #   1st loop iter: now=1000.0 → no clamp → is_paused(8200>1000) → True → sleep(60)
    #   2nd loop iter: now=8201.0 → no clamp → is_paused(8200>8201) → False → break
    now_vals = iter([NOW, NOW + TWO_H + 1])

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    await _wait_if_paused(
        state_path,
        logging.getLogger("test.wip.2h.no.clamp"),
        now_fn=lambda: next(now_vals),
        sleep_fn=fake_sleep,
    )

    # paused_until must NOT be modified
    raw = json.loads(state_path.read_text())
    assert raw["paused_until"] == original_paused_until, (
        f"paused_until must not be clamped for 2h pause, got {raw['paused_until']}"
    )

    # Normal sleep behaviour preserved
    assert sleep_calls == [60.0]


@pytest.mark.asyncio
async def test_main_loop_upstream_pause_markers_cleared_before_retry(tmp_path: Path) -> None:
    """After sleeping on upstream error, paused_until and rate_limit_type are None
    before the next runner.run() invocation."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    state_on_retry: dict[str, Any] = {}

    class _UpstreamThenStateCheckRunner:
        call_count = 0

        async def run(
            self, prompt: str, options: Any, *, logger: Any, state_path: Path
        ) -> RunResult:
            self.call_count += 1
            if self.call_count == 1:
                raise ApiUpstreamError("5xx error")
            # 2nd call: pause markers must already be cleared.
            raw = json.loads(state_path.read_text())
            state_on_retry.update(raw)
            return _make_result("recovered")

    runner = _UpstreamThenStateCheckRunner()
    options = _make_options()

    sleep_calls: list[float] = []

    async def fake_sleep(secs: float) -> None:
        sleep_calls.append(secs)

    result = await main_loop(
        runner,
        "prompt",
        options,
        state_path=state_path,
        logger=logging.getLogger("test.ml.upstream.cleared"),
        now_fn=lambda: 1000.0,
        sleep_fn=fake_sleep,
    )

    assert result.text == "recovered"
    assert runner.call_count == 2
    assert state_on_retry["paused_until"] is None
    assert state_on_retry["rate_limit_type"] is None
