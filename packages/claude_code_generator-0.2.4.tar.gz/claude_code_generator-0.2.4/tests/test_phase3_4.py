"""Tests for code_generator.orchestrator.phase3_4_implement."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import agents as _agents
from code_generator import state as _state
from code_generator.gh import GhError
from code_generator.orchestrator import phase3_4_implement
from code_generator.runner.sdk_runner import RunResult
from code_generator.runner.types import MaxTurnsExceeded, OverageAbort, RateLimitHit, TokenUsage

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result(text: str = "") -> RunResult:
    return RunResult(text=text, session_id=None, tokens_in=None, tokens_out=None)


def _make_state_with_issues(tmp_path: Path, numbers: list[int]) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    st.issues = [_state.IssueState(number=n, status="open", agent="python-pro") for n in numbers]
    _state.save_state(state_dir / "state.json", st)
    return st


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPhase3_4Run:
    @pytest.mark.asyncio
    async def test_closes_issues_on_success(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1, 2])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert all(i.status == "closed" for i in state.issues)

    @pytest.mark.asyncio
    async def test_skips_already_closed_issues(self, tmp_path: Path) -> None:
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = [
            _state.IssueState(number=1, status="closed", agent="python-pro"),
            _state.IssueState(number=2, status="open", agent="python-pro"),
        ]
        _state.save_state(state_dir / "state.json", st)

        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            return _make_run_result()

        with patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase3_4_implement.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 1  # Only issue #2 processed.

    @pytest.mark.asyncio
    async def test_retries_on_failure_then_closes(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RuntimeError("Temporary failure")
            return _make_run_result()

        with patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert state.issues[0].status == "closed"
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_leaves_issue_open_after_all_retries(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            raise RuntimeError("always fails")

        with patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=2,
            )

        assert state.issues[0].status == "open"

    @pytest.mark.asyncio
    async def test_session_id_cleared_before_each_issue(self, tmp_path: Path) -> None:
        """Non-negotiable #6: session_id must be None before each issue run."""
        state = _make_state_with_issues(tmp_path, [1, 2])
        state.session_id = "old-session"
        session_ids_at_call_time = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            # Read state from file at call time.
            st = _state.load_state(state_path)
            session_ids_at_call_time.append(st.session_id)
            return _make_run_result()

        with patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert all(sid is None for sid in session_ids_at_call_time)

    @pytest.mark.asyncio
    async def test_uses_sonnet_model(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].model == "claude-sonnet-4-6"

    @pytest.mark.asyncio
    async def test_uses_cycle_issues_in_multi_cycle(self, tmp_path: Path) -> None:
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=1,
            issues=[_state.IssueState(number=77, status="open", agent="python-pro")],
            commit_sha=None,
        )
        _state.save_state(state_dir / "state.json", st)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
        ):
            await phase3_4_implement.run(
                st,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert cycle.issues[0].status == "closed"

    @pytest.mark.asyncio
    async def test_retry_prompt_contains_error_message(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])
        prompts_seen = []
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            prompts_seen.append(prompt)
            if call_count < 2:
                raise RuntimeError("disk full")
            return _make_run_result()

        with patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        # The second prompt should contain the error text.
        assert "disk full" in prompts_seen[1]

    @pytest.mark.asyncio
    async def test_open_state_after_success_triggers_retry_then_closes(
        self, tmp_path: Path
    ) -> None:
        """Defense-in-depth: main_loop succeeds but issue_state returns 'open'.

        Expected behaviour: TransientRunnerError is raised internally, the loop
        retries, and on the second attempt issue_state returns 'closed', so the
        issue is ultimately marked closed in state.
        """
        state = _make_state_with_issues(tmp_path, [1])
        main_loop_call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal main_loop_call_count
            main_loop_call_count += 1
            return _make_run_result()

        # First call returns "open" (triggers retry); second returns "closed".
        issue_state_side_effects = ["open", "closed"]

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(
                phase3_4_implement._gh,
                "issue_state",
                side_effect=issue_state_side_effects,
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert state.issues[0].status == "closed"
        assert main_loop_call_count == 2  # Retried once after "open" response.

    @pytest.mark.asyncio
    async def test_gh_error_on_issue_state_proceeds_on_trust(self, tmp_path: Path) -> None:
        """Defense-in-depth: GhError from issue_state falls through as closed.

        When GitHub verification raises GhError the implementation should log a
        warning and proceed on trust (treat gh_state as 'closed'), leaving the
        issue marked closed in state.
        """
        state = _make_state_with_issues(tmp_path, [1])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(
                phase3_4_implement._gh,
                "issue_state",
                side_effect=GhError(1, "network timeout"),
            ),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert state.issues[0].status == "closed"


class TestEffortWiring:
    @pytest.mark.asyncio
    async def test_effort_high_when_issue_has_complexity_high_label(self, tmp_path: Path) -> None:
        """When an issue has complexity:high label, effort=high is set on options."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = [
            _state.IssueState(
                number=1,
                status="open",
                agent="python-pro",
                labels=["complexity:high", "area:api"],
            )
        ]
        _state.save_state(state_dir / "state.json", st)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase3_4_implement.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert hasattr(captured_options[0], "effort")
        assert captured_options[0].effort == "high"

    @pytest.mark.asyncio
    async def test_effort_medium_when_no_complexity_label(self, tmp_path: Path) -> None:
        """When no complexity:high label, effort=medium is set on options."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = [
            _state.IssueState(
                number=1,
                status="open",
                agent="python-pro",
                labels=["area:api", "priority:high"],
            )
        ]
        _state.save_state(state_dir / "state.json", st)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase3_4_implement.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert hasattr(captured_options[0], "effort")
        assert captured_options[0].effort == "medium"

    @pytest.mark.asyncio
    async def test_validate_effort_called_before_make_agent_options(self, tmp_path: Path) -> None:
        """validate_effort raises before the SDK call when effort/model combo is invalid."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = [_state.IssueState(number=1, status="open", agent="python-pro", labels=[])]
        _state.save_state(state_dir / "state.json", st)

        # Patch resolve_effort to return "max" — invalid with Sonnet model.
        with (
            patch.object(phase3_4_implement._effort, "resolve_effort", return_value="max"),
            pytest.raises(ValueError, match="max"),
        ):
            await phase3_4_implement.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    def test_find_effort_hint_returns_matching_hint(self) -> None:
        """_find_effort_hint() returns EffortLevel from a hint whose scope_keyword is in a label."""
        hints = [
            _state.EffortHint(scope_keyword="database", effort="high"),
            _state.EffortHint(scope_keyword="simple crud", effort="low"),
        ]
        result = phase3_4_implement._find_effort_hint(hints, ["area:database", "priority:low"])
        assert result == "high"

    def test_find_effort_hint_returns_none_when_no_match(self) -> None:
        """_find_effort_hint() returns None when no hint matches any label."""
        hints = [_state.EffortHint(scope_keyword="authentication", effort="high")]
        result = phase3_4_implement._find_effort_hint(hints, ["area:api", "priority:low"])
        assert result is None

    def test_find_effort_hint_returns_none_for_empty_hints(self) -> None:
        """_find_effort_hint() returns None gracefully when hints list is empty."""
        result = phase3_4_implement._find_effort_hint([], ["area:api"])
        assert result is None


class TestDefaultSkills:
    def test_returns_comma_joined_skills_from_agents_detect(self, tmp_path: Path) -> None:
        """_default_skills() returns a comma-joined string of detected skills."""
        req_dir = tmp_path / ".code-generator"
        req_dir.mkdir(parents=True)
        req_path = req_dir / "requirements.md"
        req_path.write_text("# Requirements\nsome content")

        fake_selection = _agents.AgentSelection(
            primary=("python-pro",),
            support=(),
            skills=("solid-principles", "python-expert"),
        )

        with patch.object(phase3_4_implement._agents, "detect", return_value=fake_selection):
            result = phase3_4_implement._default_skills(tmp_path)

        assert result == "solid-principles,python-expert"


class TestIssueCommentsInjection:
    @pytest.mark.asyncio
    async def test_prompt_contains_comments_section_when_issue_has_comments(
        self, tmp_path: Path
    ) -> None:
        """A fake issue with comments produces a prompt with ## Pre-fetched Issue Comments section."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        fake_comments = [
            {"author": {"login": "alice"}, "createdAt": "2026-01-01T00:00:00Z", "body": "LGTM"},
            {
                "author": {"login": "bob"},
                "createdAt": "2026-01-02T00:00:00Z",
                "body": "Please add tests.",
            },
        ]

        with (
            patch.object(
                phase3_4_implement._gh,
                "view_issue",
                return_value={"number": 1, "comments": fake_comments},
            ),
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        prompt = captured_prompts[0]
        assert "## Pre-fetched Issue Comments" in prompt
        assert "LGTM" in prompt
        assert "Please add tests." in prompt

    @pytest.mark.asyncio
    async def test_prompt_excludes_comments_section_when_issue_has_no_comments(
        self, tmp_path: Path
    ) -> None:
        """A fake issue with no comments produces a prompt without ## Pre-fetched Issue Comments header."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch.object(
                phase3_4_implement._gh,
                "view_issue",
                return_value={"number": 1, "comments": []},
            ),
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        assert "## Pre-fetched Issue Comments" not in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_gh_error_on_view_issue_continues_with_empty_comments(
        self, tmp_path: Path
    ) -> None:
        """GhError from view_issue logs a warning and continues with empty comments."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch.object(
                phase3_4_implement._gh,
                "view_issue",
                side_effect=GhError(1, "network error"),
            ),
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # Should not crash, issue marked closed, no ## Pre-fetched Issue Comments in prompt
        assert state.issues[0].status == "closed"
        assert len(captured_prompts) == 1
        assert "## Pre-fetched Issue Comments" not in captured_prompts[0]


# ---------------------------------------------------------------------------
# Tests for extracted helper functions (issue #86)
# ---------------------------------------------------------------------------


class TestBuildPrompt:
    def test_first_attempt_returns_base_prompt(self) -> None:
        """_build_prompt returns the base prompt unmodified on attempt 0."""
        issue = _state.IssueState(number=42, status="open", agent="python-pro")

        with patch.object(
            phase3_4_implement,
            "load_prompt",
            return_value="BASE PROMPT",
        ):
            result = phase3_4_implement._build_prompt(
                issue=issue,
                skills="solid-principles",
                comments_section="",
                attempt=0,
                last_err="",
            )

        assert result == "BASE PROMPT"

    def test_retry_attempt_appends_error_context(self) -> None:
        """_build_prompt appends the previous error message on attempt > 0."""
        issue = _state.IssueState(number=42, status="open", agent="python-pro")

        with patch.object(
            phase3_4_implement,
            "load_prompt",
            return_value="BASE PROMPT",
        ):
            result = phase3_4_implement._build_prompt(
                issue=issue,
                skills="solid-principles",
                comments_section="",
                attempt=1,
                last_err="disk full",
            )

        assert "BASE PROMPT" in result
        assert "disk full" in result
        assert "Be more explicit this time" in result

    def test_passes_issue_number_and_agent_to_load_prompt(self) -> None:
        """_build_prompt forwards issue number and agent to load_prompt."""
        issue = _state.IssueState(number=99, status="open", agent="frontend-developer")
        captured_kwargs: list[dict] = []

        def fake_load_prompt(name: str, **kwargs: object) -> str:
            captured_kwargs.append(kwargs)
            return "PROMPT"

        with patch.object(phase3_4_implement, "load_prompt", side_effect=fake_load_prompt):
            phase3_4_implement._build_prompt(
                issue=issue,
                skills="solid-principles,python-expert",
                comments_section="some comments",
                attempt=0,
                last_err="",
            )

        assert captured_kwargs[0]["ISSUE_NUMBER"] == "99"
        assert captured_kwargs[0]["PRIMARY_AGENT"] == "frontend-developer"
        assert captured_kwargs[0]["SKILLS"] == "solid-principles,python-expert"
        assert captured_kwargs[0]["ISSUE_COMMENTS"] == "some comments"


class TestResolveIssueEffort:
    def test_returns_high_when_complexity_high_label(self) -> None:
        """_resolve_issue_effort returns 'high' for a complexity:high label."""
        issue = _state.IssueState(
            number=1, status="open", agent="python-pro", labels=["complexity:high"]
        )
        effort_hints: list[_state.EffortHint] = []

        result = phase3_4_implement._resolve_issue_effort(
            issue, effort_hints, attempt=0, complexity="single"
        )

        assert result == "high"

    def test_returns_medium_when_no_complexity_label(self) -> None:
        """_resolve_issue_effort returns 'medium' when no complexity label."""
        issue = _state.IssueState(number=1, status="open", agent="python-pro", labels=["area:api"])
        effort_hints: list[_state.EffortHint] = []

        result = phase3_4_implement._resolve_issue_effort(
            issue, effort_hints, attempt=0, complexity="single"
        )

        assert result == "medium"

    def test_raises_when_invalid_effort_model_combo(self) -> None:
        """_resolve_issue_effort raises ValueError for invalid effort/model combos."""
        issue = _state.IssueState(number=1, status="open", agent="python-pro", labels=[])
        effort_hints: list[_state.EffortHint] = []

        with (
            patch.object(phase3_4_implement._effort, "resolve_effort", return_value="max"),
            pytest.raises(ValueError, match="max"),
        ):
            phase3_4_implement._resolve_issue_effort(
                issue, effort_hints, attempt=0, complexity="single"
            )


class TestVerifyIssueClosed:
    def test_no_exception_when_issue_is_closed(self) -> None:
        """_verify_issue_closed does not raise when GitHub reports 'closed'."""
        logger = logging.getLogger("test")

        with patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"):
            phase3_4_implement._verify_issue_closed(1, logger)  # must not raise

    def test_raises_transient_error_when_issue_still_open(self) -> None:
        """_verify_issue_closed raises TransientRunnerError when issue is 'open'."""
        from code_generator.runner.retry import TransientRunnerError

        logger = logging.getLogger("test")

        with (
            patch.object(phase3_4_implement._gh, "issue_state", return_value="open"),
            pytest.raises(TransientRunnerError, match="#1"),
        ):
            phase3_4_implement._verify_issue_closed(1, logger)

    def test_logs_warning_and_returns_on_gh_error(self) -> None:
        """_verify_issue_closed swallows GhError and logs a warning."""
        logger = logging.getLogger("test")

        with (
            patch.object(
                phase3_4_implement._gh,
                "issue_state",
                side_effect=phase3_4_implement._gh.GhError(1, "timeout"),
            ),
        ):
            phase3_4_implement._verify_issue_closed(1, logger)  # must not raise


class TestImplementSingleIssue:
    @pytest.mark.asyncio
    async def test_returns_true_on_success(self, tmp_path: Path) -> None:
        """_implement_single_issue returns True when the run succeeds."""
        state = _make_state_with_issues(tmp_path, [1])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
        ):
            success, _usage = await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert success is True

    @pytest.mark.asyncio
    async def test_returns_false_after_all_retries_exhausted(self, tmp_path: Path) -> None:
        """_implement_single_issue returns False when all retries fail."""
        state = _make_state_with_issues(tmp_path, [1])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"

        async def always_fails(runner, prompt, options, *, state_path, logger, **kw):
            raise RuntimeError("always fails")

        with patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=always_fails):
            success, _usage = await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=2,
            )

        assert success is False

    @pytest.mark.asyncio
    async def test_clears_session_id_before_each_attempt(self, tmp_path: Path) -> None:
        """_implement_single_issue clears session_id before every attempt."""
        state = _make_state_with_issues(tmp_path, [1])
        state.session_id = "stale-session"
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"
        session_ids_seen: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            st = _state.load_state(state_path)
            session_ids_seen.append(st.session_id)
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
        ):
            await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=1,
            )  # return value not checked here — only session_ids matter

        assert all(sid is None for sid in session_ids_seen)

    @pytest.mark.asyncio
    async def test_overage_abort_propagates_through_retry_loop(self, tmp_path: Path) -> None:
        """OverageAbort must escape _implement_single_issue, never be swallowed."""
        state = _make_state_with_issues(tmp_path, [1])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"

        async def raises_overage(runner, prompt, options, *, state_path, logger, **kw):
            raise OverageAbort("overage active")

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=raises_overage),
            pytest.raises(OverageAbort),
        ):
            await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

    @pytest.mark.asyncio
    async def test_rate_limit_hit_propagates_through_retry_loop(self, tmp_path: Path) -> None:
        """RateLimitHit must escape _implement_single_issue, never be swallowed."""
        state = _make_state_with_issues(tmp_path, [1])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"

        async def raises_rate_limit(runner, prompt, options, *, state_path, logger, **kw):
            raise RateLimitHit(resets_at=999999, rate_limit_type="test")

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=raises_rate_limit),
            pytest.raises(RateLimitHit),
        ):
            await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )


class TestMaxTurnsExceededFailFast:
    """ACs 1-4: MaxTurnsExceeded fail-fast in the Phase 3/4 retry loop."""

    @pytest.mark.asyncio
    async def test_max_turns_exceeded_short_circuits_retry_loop(self, tmp_path: Path) -> None:
        """AC1: MaxTurnsExceeded on first attempt exits loop after 1 attempt, returns failure."""
        state = _make_state_with_issues(tmp_path, [1])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"
        call_count = 0

        async def raises_max_turns(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            raise MaxTurnsExceeded("agent loop exhausted max_turns budget")

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=raises_max_turns),
            patch.object(phase3_4_implement._gh, "add_label", return_value=None),
        ):
            success, _usage = await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert success is False
        assert call_count == 1  # Must not retry.

    @pytest.mark.asyncio
    async def test_max_turns_exceeded_on_issue_n_does_not_abort_cycle(self, tmp_path: Path) -> None:
        """AC2: After MaxTurnsExceeded on issue #1, issue #2 is still processed normally."""
        state = _make_state_with_issues(tmp_path, [1, 2])
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise MaxTurnsExceeded("max_turns hit on issue #1")
            return _make_run_result()

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "add_label", return_value=None),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert state.issues[0].status == "open"  # MaxTurnsExceeded → left open
        assert state.issues[1].status == "closed"  # Next issue processed normally
        assert call_count == 2  # Issue #2 was reached after issue #1 failed

    @pytest.mark.asyncio
    async def test_max_turns_exceeded_adds_needs_manual_review_label(self, tmp_path: Path) -> None:
        """AC3: needs-manual-review label is added to the issue via gh.add_label."""
        state = _make_state_with_issues(tmp_path, [42])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"
        add_label_calls: list[tuple] = []

        async def raises_max_turns(runner, prompt, options, *, state_path, logger, **kw):
            raise MaxTurnsExceeded("exhausted")

        def fake_add_label(issue_number: int, label: str) -> None:
            add_label_calls.append((issue_number, label))

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=raises_max_turns),
            patch.object(phase3_4_implement._gh, "add_label", side_effect=fake_add_label),
        ):
            await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert (42, "needs-manual-review") in add_label_calls

    @pytest.mark.asyncio
    async def test_max_turns_exceeded_logs_error_with_max_turns_ceiling_and_attempt(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """AC4: ERROR log contains 'max_turns ceiling' and the attempt count."""
        state = _make_state_with_issues(tmp_path, [7])
        issue = state.issues[0]
        state_path = tmp_path / ".code-generator" / "state.json"

        async def raises_max_turns(runner, prompt, options, *, state_path, logger, **kw):
            raise MaxTurnsExceeded("budget exhausted")

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=raises_max_turns),
            patch.object(phase3_4_implement._gh, "add_label", return_value=None),
            caplog.at_level(logging.ERROR),
        ):
            await phase3_4_implement._implement_single_issue(
                issue=issue,
                state=state,
                state_path=state_path,
                skills="solid-principles",
                effort_hints=[],
                project_dir=tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        error_msgs = [m for m in caplog.messages if "max_turns ceiling" in m]
        assert len(error_msgs) >= 1
        # The log message must contain the attempt count (1/3).
        assert any("1" in m and "3" in m for m in error_msgs)


class TestPhase3_4TokenAccumulation:
    """ACs 12-13: per-issue + phase-total accumulation in Phase 3/4."""

    @pytest.mark.asyncio
    async def test_retried_issue_accumulates_tokens_from_all_attempts(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """AC 12: 2 issues (second requires 2 attempts) → per-issue total includes both attempts."""
        state = _make_state_with_issues(tmp_path, [1, 2])

        usage_issue1 = TokenUsage(input=100, output=10, cache_read=20, cache_write=2)
        # Issue 2: attempt 1 fails (exception, zero tokens), attempt 2 succeeds
        usage_issue2_attempt2 = TokenUsage(input=50, output=5, cache_read=10, cache_write=1)

        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # Issue 1, attempt 1: success
                return RunResult(text="", session_id=None, usage=usage_issue1)
            if call_count == 2:
                # Issue 2, attempt 1: fails (exception path → zero tokens in issue_total)
                raise RuntimeError("attempt 1 failed")
            # Issue 2, attempt 2: success
            return RunResult(text="", session_id=None, usage=usage_issue2_attempt2)

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh,
                "view_issue",
                return_value={"number": 1, "comments": []},
            ),
            caplog.at_level(logging.INFO),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        # Both issues processed
        assert all(i.status == "closed" for i in state.issues)

        # 2 per-issue token log lines (one per issue)
        per_issue_msgs = [m for m in caplog.messages if "tokens: in=" in m]
        assert len(per_issue_msgs) == 2, f"Expected 2 per-issue lines, got: {per_issue_msgs}"

        # Phase total = issue1 usage + issue2 attempt2 usage (attempt1 raised, zero tokens)
        expected_total = TokenUsage(input=150, output=15, cache_read=30, cache_write=3)
        assert state.token_usage.get("phase3_4") == expected_total

        # Phase-complete line emitted
        complete_msgs = [m for m in caplog.messages if "3/4 complete:" in m]
        assert len(complete_msgs) == 1

    @pytest.mark.asyncio
    async def test_failed_issue_zero_tokens_included_in_phase_total(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """AC 13: fully-failed issue contributes zero tokens; phase total = successful issues only."""
        state = _make_state_with_issues(tmp_path, [1, 2])
        # Issue 1 fails all retries; issue 2 succeeds
        usage_issue2 = TokenUsage(input=200, output=20, cache_read=40, cache_write=4)
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            # First 2 calls belong to issue 1 (max_retries=2): always fail
            if call_count <= 2:
                raise RuntimeError("issue 1 always fails")
            return RunResult(text="", session_id=None, usage=usage_issue2)

        with (
            patch.object(phase3_4_implement.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase3_4_implement._gh, "issue_state", return_value="closed"),
            patch.object(
                phase3_4_implement._gh,
                "view_issue",
                return_value={"number": 1, "comments": []},
            ),
            caplog.at_level(logging.INFO),
        ):
            await phase3_4_implement.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=2,
            )

        # Issue 1 still open, issue 2 closed
        assert state.issues[0].status == "open"
        assert state.issues[1].status == "closed"

        # 2 per-issue token lines (one per issue, even the failed one)
        per_issue_msgs = [m for m in caplog.messages if "tokens: in=" in m]
        assert len(per_issue_msgs) == 2, f"Expected 2 per-issue lines, got: {per_issue_msgs}"

        # Phase total = issue2 usage only (issue1 contributed zero — no RunResult from exceptions)
        assert state.token_usage.get("phase3_4") == usage_issue2

        # Phase-complete line still emitted
        complete_msgs = [m for m in caplog.messages if "3/4 complete:" in m]
        assert len(complete_msgs) == 1
