"""Tests for package version and CLI --version flag."""

import tomllib
from pathlib import Path

import typer.testing

import code_generator


def test_version_attribute_exists() -> None:
    """When importing code_generator, __version__ must be a non-empty string."""
    assert hasattr(code_generator, "__version__")
    assert isinstance(code_generator.__version__, str)
    assert code_generator.__version__ != ""


def test_version_format() -> None:
    """Version must follow semver-like format (e.g., 0.1.0)."""
    parts = code_generator.__version__.split(".")
    assert len(parts) == 3
    assert all(part.isdigit() for part in parts)


def test_cli_version_flag() -> None:
    """Running 'code-generator --version' must print the version and exit 0."""
    from code_generator.cli import app

    runner = typer.testing.CliRunner()
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert code_generator.__version__ in result.output


def test_pyproject_and_dunder_version_match() -> None:
    """pyproject.toml version and __version__ must stay in lockstep."""
    pyproject_path = Path(__file__).resolve().parents[1] / "pyproject.toml"
    with pyproject_path.open("rb") as f:
        data = tomllib.load(f)
    assert data["project"]["version"] == code_generator.__version__
