"""Tests for code_generator.gh — subprocess wrapper for the gh CLI."""

from __future__ import annotations

import json
import subprocess
from unittest.mock import MagicMock, patch

import pytest

from code_generator import gh

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fake_cp(stdout: str = "", returncode: int = 0, stderr: str = "") -> MagicMock:
    """Build a fake CompletedProcess-like object."""
    cp = MagicMock(spec=subprocess.CompletedProcess)
    cp.stdout = stdout
    cp.returncode = returncode
    cp.stderr = stderr
    return cp


# ---------------------------------------------------------------------------
# GhError
# ---------------------------------------------------------------------------


class TestGhError:
    def test_attributes(self) -> None:
        err = gh.GhError(1, "some error")
        assert err.returncode == 1
        assert err.stderr == "some error"
        assert "1" in str(err)
        assert "some error" in str(err)


# ---------------------------------------------------------------------------
# _run
# ---------------------------------------------------------------------------


class TestRun:
    def test_returns_stripped_stdout_on_zero_exit(self) -> None:
        with patch("subprocess.run", return_value=_fake_cp("  hello  ")) as mock_run:
            result = gh._run(["gh", "issue", "list"])
        assert result == "hello"
        mock_run.assert_called_once_with(
            ["gh", "issue", "list"],
            capture_output=True,
            text=True,
            check=False,
            input=None,
        )

    def test_raises_gh_error_on_non_zero(self) -> None:
        with (
            patch("subprocess.run", return_value=_fake_cp("", returncode=1, stderr="bad")),
            pytest.raises(gh.GhError) as exc_info,
        ):
            gh._run(["gh", "issue", "list"])
        assert exc_info.value.returncode == 1
        assert "bad" in exc_info.value.stderr

    def test_passes_input_kwarg(self) -> None:
        with patch("subprocess.run", return_value=_fake_cp("ok")) as mock_run:
            gh._run(["gh", "thing"], input="data")
        mock_run.assert_called_once_with(
            ["gh", "thing"],
            capture_output=True,
            text=True,
            check=False,
            input="data",
        )


# ---------------------------------------------------------------------------
# view_issue
# ---------------------------------------------------------------------------


class TestViewIssue:
    def test_returns_parsed_json(self) -> None:
        data = {"number": 5, "title": "Fix bug", "body": "body", "state": "open", "labels": []}
        with patch("subprocess.run", return_value=_fake_cp(json.dumps(data))):
            result = gh.view_issue(5)
        assert result == data

    def test_passes_correct_argv(self) -> None:
        data = {"number": 1, "title": "", "body": "", "state": "open", "labels": []}
        with patch("subprocess.run", return_value=_fake_cp(json.dumps(data))) as mock_run:
            gh.view_issue(1)
        argv = mock_run.call_args[0][0]
        assert "view" in argv
        assert "1" in argv
        assert "--json" in argv

    def test_propagates_json_decode_error_on_malformed_output(self) -> None:
        """view_issue propagates json.JSONDecodeError when gh returns malformed JSON."""
        with (
            patch("subprocess.run", return_value=_fake_cp("not valid json {")),
            pytest.raises(json.JSONDecodeError),
        ):
            gh.view_issue(5)

    def test_json_fields_include_comments(self) -> None:
        """view_issue requests 'comments' in the --json argument."""
        data = {
            "number": 1,
            "title": "",
            "body": "",
            "state": "open",
            "labels": [],
            "milestone": None,
            "comments": [],
        }
        with patch("subprocess.run", return_value=_fake_cp(json.dumps(data))) as mock_run:
            gh.view_issue(1)
        argv = mock_run.call_args[0][0]
        json_idx = argv.index("--json")
        fields = argv[json_idx + 1]
        assert "comments" in fields

    def test_returns_dict_with_comments_key(self) -> None:
        """view_issue returns a dict containing the comments key with structured data."""
        comments = [
            {"author": {"login": "user"}, "createdAt": "2026-01-01T00:00:00Z", "body": "A comment"}
        ]
        data = {
            "number": 5,
            "title": "T",
            "body": "B",
            "state": "open",
            "labels": [],
            "milestone": None,
            "comments": comments,
        }
        with patch("subprocess.run", return_value=_fake_cp(json.dumps(data))):
            result = gh.view_issue(5)
        assert "comments" in result
        assert result["comments"] == comments

    def test_custom_fields_appear_in_argv(self) -> None:
        """view_issue(42, fields=['number', 'title']) passes --json number,title to subprocess."""
        data = {"number": 42, "title": "T"}
        with patch("subprocess.run", return_value=_fake_cp(json.dumps(data))) as mock_run:
            gh.view_issue(42, fields=["number", "title"])
        argv = mock_run.call_args[0][0]
        json_idx = argv.index("--json")
        assert argv[json_idx + 1] == "number,title"

    def test_custom_fields_do_not_include_comments(self) -> None:
        """view_issue with custom fields omits comments from the --json argument."""
        data = {"number": 42, "title": "T"}
        with patch("subprocess.run", return_value=_fake_cp(json.dumps(data))) as mock_run:
            gh.view_issue(42, fields=["number", "title"])
        argv = mock_run.call_args[0][0]
        json_idx = argv.index("--json")
        assert "comments" not in argv[json_idx + 1]

    def test_fields_none_uses_default_field_list_with_comments(self) -> None:
        """view_issue() with fields=None keeps backward-compatible default field list."""
        data = {
            "number": 1,
            "title": "",
            "body": "",
            "state": "open",
            "labels": [],
            "milestone": None,
            "comments": [],
        }
        with patch("subprocess.run", return_value=_fake_cp(json.dumps(data))) as mock_run:
            gh.view_issue(1)
        argv = mock_run.call_args[0][0]
        json_idx = argv.index("--json")
        fields = argv[json_idx + 1]
        assert "comments" in fields
        assert "number" in fields
        assert "title" in fields
        assert "body" in fields


# ---------------------------------------------------------------------------
# list_issues
# ---------------------------------------------------------------------------


class TestListIssues:
    def test_returns_parsed_json(self) -> None:
        data = [{"number": 1, "title": "T", "state": "open", "labels": []}]
        with patch("subprocess.run", return_value=_fake_cp(json.dumps(data))):
            result = gh.list_issues()
        assert result == data

    def test_includes_milestone_filter(self) -> None:
        data: list = []
        with patch("subprocess.run", return_value=_fake_cp(json.dumps(data))) as mock_run:
            gh.list_issues(milestone="Cycle 1")
        argv = mock_run.call_args[0][0]
        assert "--milestone" in argv
        assert "Cycle 1" in argv

    def test_state_parameter(self) -> None:
        data: list = []
        with patch("subprocess.run", return_value=_fake_cp(json.dumps(data))) as mock_run:
            gh.list_issues(state="closed")
        argv = mock_run.call_args[0][0]
        idx = argv.index("--state")
        assert argv[idx + 1] == "closed"

    def test_returns_empty_list_on_empty_json_array(self) -> None:
        """list_issues returns [] when gh outputs an empty JSON array."""
        with patch("subprocess.run", return_value=_fake_cp("[]")):
            result = gh.list_issues()
        assert result == []

    def test_json_fields_include_comments(self) -> None:
        """list_issues requests 'comments' in the --json argument."""
        with patch("subprocess.run", return_value=_fake_cp("[]")) as mock_run:
            gh.list_issues()
        argv = mock_run.call_args[0][0]
        json_idx = argv.index("--json")
        fields = argv[json_idx + 1]
        assert "comments" in fields

    def test_custom_fields_appear_in_argv(self) -> None:
        """list_issues(fields=['number', 'labels']) passes --json number,labels to subprocess."""
        with patch("subprocess.run", return_value=_fake_cp("[]")) as mock_run:
            gh.list_issues(fields=["number", "labels"])
        argv = mock_run.call_args[0][0]
        json_idx = argv.index("--json")
        assert argv[json_idx + 1] == "number,labels"

    def test_custom_fields_do_not_include_comments(self) -> None:
        """list_issues with custom fields omits comments from the --json argument."""
        with patch("subprocess.run", return_value=_fake_cp("[]")) as mock_run:
            gh.list_issues(fields=["number", "labels"])
        argv = mock_run.call_args[0][0]
        json_idx = argv.index("--json")
        assert "comments" not in argv[json_idx + 1]

    def test_fields_none_uses_default_field_list_with_comments(self) -> None:
        """list_issues() with fields=None keeps backward-compatible default field list."""
        with patch("subprocess.run", return_value=_fake_cp("[]")) as mock_run:
            gh.list_issues()
        argv = mock_run.call_args[0][0]
        json_idx = argv.index("--json")
        fields = argv[json_idx + 1]
        assert "comments" in fields
        assert "number" in fields


# ---------------------------------------------------------------------------
# _repo_name_with_owner
# ---------------------------------------------------------------------------


class TestRepoNameWithOwner:
    def test_returns_owner_repo_string(self) -> None:
        """Happy path: gh succeeds and returns the 'owner/repo' string."""
        with patch("subprocess.run", return_value=_fake_cp("SilvioBaratto/code-generator")):
            result = gh._repo_name_with_owner()
        assert result == "SilvioBaratto/code-generator"

    def test_raises_gh_error_when_gh_fails(self) -> None:
        """When gh exits non-zero, GhError propagates to the caller."""
        with (
            patch(
                "subprocess.run",
                return_value=_fake_cp("", returncode=128, stderr="not a git repository"),
            ),
            pytest.raises(gh.GhError) as exc_info,
        ):
            gh._repo_name_with_owner()
        assert exc_info.value.returncode == 128
        assert "not a git repository" in exc_info.value.stderr


# ---------------------------------------------------------------------------
# issue_state
# ---------------------------------------------------------------------------


class TestIssueState:
    def test_returns_lowercased_open_state(self) -> None:
        """issue_state returns 'open' when gh outputs 'OPEN'."""
        with patch("subprocess.run", return_value=_fake_cp("OPEN\n")):
            result = gh.issue_state(5)
        assert result == "open"

    def test_returns_lowercased_closed_state(self) -> None:
        """issue_state returns 'closed' when gh outputs 'CLOSED'."""
        with patch("subprocess.run", return_value=_fake_cp("CLOSED")):
            result = gh.issue_state(5)
        assert result == "closed"

    def test_propagates_gh_error_on_failure(self) -> None:
        """issue_state propagates GhError when gh exits non-zero."""
        with (
            patch(
                "subprocess.run",
                return_value=_fake_cp("", returncode=1, stderr="issue not found"),
            ),
            pytest.raises(gh.GhError) as exc_info,
        ):
            gh.issue_state(99)
        assert exc_info.value.returncode == 1
        assert "issue not found" in exc_info.value.stderr


# ---------------------------------------------------------------------------
# agent_from_labels
# ---------------------------------------------------------------------------


class TestAgentFromLabels:
    def test_returns_python_pro_when_no_labels(self) -> None:
        """When no labels are present, the default agent is python-pro."""
        result = gh.agent_from_labels([])
        assert result == "python-pro"

    def test_returns_python_pro_when_no_agent_label(self) -> None:
        """When labels exist but none starts with 'agent:', return python-pro."""
        labels = [{"name": "priority:high"}, {"name": "area:orchestrator"}]
        result = gh.agent_from_labels(labels)
        assert result == "python-pro"

    def test_returns_agent_name_without_prefix(self) -> None:
        """When an agent: label is present, return the name without the prefix."""
        labels = [{"name": "priority:medium"}, {"name": "agent:frontend-developer"}]
        result = gh.agent_from_labels(labels)
        assert result == "frontend-developer"

    def test_returns_first_agent_label_encountered(self) -> None:
        """When multiple agent: labels are present, return the first match."""
        labels = [{"name": "agent:nestjs-expert"}, {"name": "agent:python-pro"}]
        result = gh.agent_from_labels(labels)
        assert result == "nestjs-expert"

    def test_handles_missing_name_key_gracefully(self) -> None:
        """Labels with no 'name' key do not cause an error."""
        labels = [{"id": 1}, {"name": "agent:baml-expert-agent"}]
        result = gh.agent_from_labels(labels)
        assert result == "baml-expert-agent"
