"""Tests for code_generator.gh.milestones — create_milestone, close_milestone, delete_milestone."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest

from code_generator.gh.core import GhError
from code_generator.gh.milestones import close_milestone, create_milestone, delete_milestone

# ---------------------------------------------------------------------------
# create_milestone
# ---------------------------------------------------------------------------


class TestCreateMilestone:
    def test_returns_milestone_number(self) -> None:
        with (
            patch(
                "code_generator.gh.milestones._repo_name_with_owner",
                return_value="owner/repo",
            ),
            patch(
                "code_generator.gh.milestones._run",
                return_value=json.dumps({"number": 3, "title": "Cycle 1"}),
            ),
        ):
            number = create_milestone("Cycle 1", "desc")
        assert number == 3

    def test_sends_correct_method(self) -> None:
        with (
            patch(
                "code_generator.gh.milestones._repo_name_with_owner",
                return_value="owner/repo",
            ),
            patch(
                "code_generator.gh.milestones._run",
                return_value=json.dumps({"number": 1, "title": "M"}),
            ) as mock_run,
        ):
            create_milestone("M")
        argv = mock_run.call_args[0][0]
        assert "--method" in argv
        assert "POST" in argv
        assert "milestones" in " ".join(argv)

    def test_uses_empty_string_as_default_description(self) -> None:
        """create_milestone sends description= when no description is given."""
        with (
            patch(
                "code_generator.gh.milestones._repo_name_with_owner",
                return_value="owner/repo",
            ),
            patch(
                "code_generator.gh.milestones._run",
                return_value=json.dumps({"number": 5, "title": "Sprint"}),
            ) as mock_run,
        ):
            create_milestone("Sprint")
        argv = mock_run.call_args[0][0]
        assert "description=" in " ".join(argv)

    def test_propagates_gh_error_when_gh_api_fails(self) -> None:
        """create_milestone propagates GhError when gh api exits non-zero."""
        with (
            patch(
                "code_generator.gh.milestones._repo_name_with_owner",
                return_value="owner/repo",
            ),
            patch(
                "code_generator.gh.milestones._run",
                side_effect=GhError(1, "Validation Failed"),
            ),
            pytest.raises(GhError) as exc_info,
        ):
            create_milestone("Duplicate Milestone")
        assert exc_info.value.returncode == 1
        assert "Validation Failed" in exc_info.value.stderr


# ---------------------------------------------------------------------------
# close_milestone
# ---------------------------------------------------------------------------


class TestCloseMilestone:
    def test_sends_patch_to_milestones_endpoint(self) -> None:
        with (
            patch(
                "code_generator.gh.milestones._repo_name_with_owner",
                return_value="owner/repo",
            ),
            patch("code_generator.gh.milestones._run", return_value="") as mock_run,
        ):
            close_milestone(2)
        argv = mock_run.call_args[0][0]
        assert "PATCH" in argv
        assert "milestones/2" in " ".join(argv)
        assert "state=closed" in " ".join(argv)

    def test_propagates_gh_error_when_gh_fails(self) -> None:
        """close_milestone propagates GhError when the gh api call fails."""
        with (
            patch(
                "code_generator.gh.milestones._repo_name_with_owner",
                return_value="owner/repo",
            ),
            patch(
                "code_generator.gh.milestones._run",
                side_effect=GhError(1, "milestone not found"),
            ),
            pytest.raises(GhError) as exc_info,
        ):
            close_milestone(999)
        assert exc_info.value.returncode == 1
        assert "milestone not found" in exc_info.value.stderr


# ---------------------------------------------------------------------------
# delete_milestone
# ---------------------------------------------------------------------------


class TestDeleteMilestone:
    def test_sends_delete_to_milestones_endpoint(self) -> None:
        """delete_milestone issues DELETE to repos/{nwo}/milestones/{number}."""
        with (
            patch(
                "code_generator.gh.milestones._repo_name_with_owner",
                return_value="owner/repo",
            ),
            patch("code_generator.gh.milestones._run", return_value="") as mock_run,
        ):
            delete_milestone(5)
        argv = mock_run.call_args[0][0]
        assert "--method" in argv
        assert "DELETE" in argv
        assert "milestones/5" in " ".join(argv)

    def test_propagates_gh_error_when_gh_fails(self) -> None:
        """delete_milestone propagates GhError when the gh api call fails."""
        with (
            patch(
                "code_generator.gh.milestones._repo_name_with_owner",
                return_value="owner/repo",
            ),
            patch(
                "code_generator.gh.milestones._run",
                side_effect=GhError(1, "not found"),
            ),
            pytest.raises(GhError) as exc_info,
        ):
            delete_milestone(999)
        assert exc_info.value.returncode == 1
        assert "not found" in exc_info.value.stderr
