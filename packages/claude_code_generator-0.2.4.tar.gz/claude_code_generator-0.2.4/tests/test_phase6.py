"""Tests for code_generator.orchestrator.phase6_test."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import phase6_test
from code_generator.orchestrator.phase6_test import TestsFailed
from code_generator.runner.sdk_runner import RunResult

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result(text: str = "") -> RunResult:
    return RunResult(text=text, session_id=None, tokens_in=None, tokens_out=None)


def _make_state(tmp_path: Path) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    _state.save_state(state_dir / "state.json", st)
    return st


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPhase6Run:
    @pytest.mark.asyncio
    async def test_passes_when_no_sentinel(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("All 42 tests passed. Coverage: 95%")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            # Should not raise.
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    @pytest.mark.asyncio
    async def test_raises_tests_failed_on_sentinel(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("TESTS FAILED after 3 retries")

        with (
            patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop),
            pytest.raises(TestsFailed),
        ):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    @pytest.mark.asyncio
    async def test_uses_sonnet_model(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("ok")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].model == "claude-sonnet-4-6"

    @pytest.mark.asyncio
    async def test_max_retries_placeholder_is_3(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        captured_prompts = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result("ok")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # The loaded prompt should have had {MAX_RETRIES} replaced with "3".
        assert "{MAX_RETRIES}" not in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_allowed_tools_correct(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("ok")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert set(captured_options[0].allowed_tools) == {"Read", "Edit", "Bash"}

    @pytest.mark.asyncio
    async def test_sentinel_is_case_sensitive(self, tmp_path: Path) -> None:
        """Lowercase 'tests failed' must NOT trigger TestsFailed."""
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("tests failed — some lowercase message")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            # Must not raise: sentinel is "TESTS FAILED" (uppercase only).
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    @pytest.mark.asyncio
    async def test_effort_escalates_across_retries(self, tmp_path: Path) -> None:
        """Effort level escalates with each retry: low→medium→high."""
        state = _make_state(tmp_path)
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("TESTS FAILED")  # always fail to exhaust retries

        with (
            patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop),
            pytest.raises(TestsFailed),
        ):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert len(captured_options) == 3
        assert captured_options[0].effort == "low"  # attempt 0
        assert captured_options[1].effort == "medium"  # attempt 1
        assert captured_options[2].effort == "high"  # attempt 2

    @pytest.mark.asyncio
    async def test_effort_low_on_first_attempt(self, tmp_path: Path) -> None:
        """First attempt (retry_count=0) uses effort=low."""
        state = _make_state(tmp_path)
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("all good")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].effort == "low"

    @pytest.mark.asyncio
    async def test_succeeds_on_second_attempt_with_medium_effort(self, tmp_path: Path) -> None:
        """When the first attempt fails and second succeeds, no exception is raised."""
        state = _make_state(tmp_path)
        call_count = 0
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            captured_options.append(options)
            if call_count == 1:
                return _make_run_result("TESTS FAILED")
            return _make_run_result("all tests passed")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 2
        assert captured_options[0].effort == "low"
        assert captured_options[1].effort == "medium"
