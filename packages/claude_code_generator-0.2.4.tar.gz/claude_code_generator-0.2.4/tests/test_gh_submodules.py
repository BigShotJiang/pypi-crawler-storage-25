"""Tests verifying each gh sub-module can be imported independently."""

from __future__ import annotations


class TestGhCommandRunnerProtocol:
    """Verify GhCommandRunner protocol and DI helpers exist and work."""

    def test_core_exports_gh_command_runner(self) -> None:
        from code_generator.gh.core import GhCommandRunner  # noqa: PLC0415

        assert GhCommandRunner is not None

    def test_core_exports_subprocess_gh_runner(self) -> None:
        from code_generator.gh.core import SubprocessGhRunner  # noqa: PLC0415

        assert callable(SubprocessGhRunner)

    def test_core_exports_set_runner(self) -> None:
        from code_generator.gh.core import set_runner  # noqa: PLC0415

        assert callable(set_runner)

    def test_core_exports_reset_runner(self) -> None:
        from code_generator.gh.core import reset_runner  # noqa: PLC0415

        assert callable(reset_runner)

    def test_package_exports_gh_command_runner(self) -> None:
        from code_generator.gh import GhCommandRunner  # noqa: PLC0415

        assert GhCommandRunner is not None

    def test_package_exports_set_runner(self) -> None:
        from code_generator.gh import set_runner  # noqa: PLC0415

        assert callable(set_runner)

    def test_package_exports_reset_runner(self) -> None:
        from code_generator.gh import reset_runner  # noqa: PLC0415

        assert callable(reset_runner)

    def test_fake_runner_intercepts_run_call(self) -> None:
        """Inject a fake runner and verify _run() delegates to it."""
        from code_generator.gh.core import _run, reset_runner, set_runner  # noqa: PLC0415

        calls: list[tuple[list[str], str | None]] = []

        class FakeGhRunner:
            def run(self, argv: list[str], *, input: str | None = None) -> str:
                calls.append((argv, input))
                return "fake-output"

        set_runner(FakeGhRunner())
        try:
            result = _run(["gh", "issue", "list"])
            assert result == "fake-output"
            assert calls == [(["gh", "issue", "list"], None)]
        finally:
            reset_runner()

    def test_reset_runner_restores_subprocess_runner(self) -> None:
        """After reset_runner(), the default SubprocessGhRunner is active."""
        from code_generator.gh.core import SubprocessGhRunner, reset_runner, set_runner  # noqa: PLC0415, I001

        class FakeGhRunner:
            def run(self, argv: list[str], *, input: str | None = None) -> str:
                return "fake"

        # Replace, then restore
        set_runner(FakeGhRunner())
        reset_runner()

        # Access the module-level _runner to verify it's a SubprocessGhRunner
        import code_generator.gh.core as core  # noqa: PLC0415

        assert isinstance(core._runner, SubprocessGhRunner)

    def test_fake_runner_passes_input_kwarg(self) -> None:
        """Verify _run() forwards the input= kwarg to the runner."""
        from code_generator.gh.core import _run, reset_runner, set_runner  # noqa: PLC0415

        received: list[str | None] = []

        class FakeGhRunner:
            def run(self, argv: list[str], *, input: str | None = None) -> str:
                received.append(input)
                return ""

        set_runner(FakeGhRunner())
        try:
            _run(["gh", "api", "/repos"], input="payload")
            assert received == ["payload"]
        finally:
            reset_runner()


class TestCoreImports:
    def test_core_exports_gh_error(self) -> None:
        from code_generator.gh.core import GhError  # noqa: PLC0415

        assert issubclass(GhError, RuntimeError)

    def test_core_exports_run(self) -> None:
        from code_generator.gh.core import _run  # noqa: PLC0415

        assert callable(_run)

    def test_core_exports_repo_name_with_owner(self) -> None:
        from code_generator.gh.core import _repo_name_with_owner  # noqa: PLC0415

        assert callable(_repo_name_with_owner)


class TestIssuesImports:
    def test_issues_exports_view_issue(self) -> None:
        from code_generator.gh.issues import view_issue  # noqa: PLC0415

        assert callable(view_issue)

    def test_issues_exports_list_issues(self) -> None:
        from code_generator.gh.issues import list_issues  # noqa: PLC0415

        assert callable(list_issues)

    def test_issues_exports_issue_state(self) -> None:
        from code_generator.gh.issues import issue_state  # noqa: PLC0415

        assert callable(issue_state)

    def test_issues_exports_agent_from_labels(self) -> None:
        from code_generator.gh.issues import agent_from_labels  # noqa: PLC0415

        assert callable(agent_from_labels)


class TestLabelsImports:
    def test_labels_exports_ensure_label(self) -> None:
        from code_generator.gh.labels import ensure_label  # noqa: PLC0415

        assert callable(ensure_label)

    def test_labels_exports_add_label(self) -> None:
        from code_generator.gh.labels import add_label  # noqa: PLC0415

        assert callable(add_label)

    def test_labels_exports_ensure_standard_labels(self) -> None:
        from code_generator.gh.labels import ensure_standard_labels  # noqa: PLC0415

        assert callable(ensure_standard_labels)


class TestMilestonesImports:
    def test_milestones_exports_create_milestone(self) -> None:
        from code_generator.gh.milestones import create_milestone  # noqa: PLC0415

        assert callable(create_milestone)

    def test_milestones_exports_close_milestone(self) -> None:
        from code_generator.gh.milestones import close_milestone  # noqa: PLC0415

        assert callable(close_milestone)


class TestPackageBackwardCompatibility:
    def test_package_exports_gh_error(self) -> None:
        from code_generator.gh import GhError  # noqa: PLC0415

        assert issubclass(GhError, RuntimeError)

    def test_package_exports_view_issue(self) -> None:
        from code_generator.gh import view_issue  # noqa: PLC0415

        assert callable(view_issue)

    def test_package_exports_list_issues(self) -> None:
        from code_generator.gh import list_issues  # noqa: PLC0415

        assert callable(list_issues)

    def test_package_exports_issue_state(self) -> None:
        from code_generator.gh import issue_state  # noqa: PLC0415

        assert callable(issue_state)

    def test_package_exports_agent_from_labels(self) -> None:
        from code_generator.gh import agent_from_labels  # noqa: PLC0415

        assert callable(agent_from_labels)

    def test_package_exports_ensure_label(self) -> None:
        from code_generator.gh import ensure_label  # noqa: PLC0415

        assert callable(ensure_label)

    def test_package_exports_add_label(self) -> None:
        from code_generator.gh import add_label  # noqa: PLC0415

        assert callable(add_label)

    def test_package_exports_ensure_standard_labels(self) -> None:
        from code_generator.gh import ensure_standard_labels  # noqa: PLC0415

        assert callable(ensure_standard_labels)

    def test_package_exports_create_milestone(self) -> None:
        from code_generator.gh import create_milestone  # noqa: PLC0415

        assert callable(create_milestone)

    def test_package_exports_close_milestone(self) -> None:
        from code_generator.gh import close_milestone  # noqa: PLC0415

        assert callable(close_milestone)

    def test_module_import_via_code_generator(self) -> None:
        from code_generator import gh  # noqa: PLC0415

        assert hasattr(gh, "GhError")
        assert hasattr(gh, "ensure_label")
        assert hasattr(gh, "create_milestone")
