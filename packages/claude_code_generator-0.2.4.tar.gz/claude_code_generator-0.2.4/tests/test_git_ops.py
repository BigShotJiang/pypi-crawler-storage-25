"""Tests for code_generator.git_ops."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from code_generator import git_ops
from code_generator.git_ops import GitError

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _cp(
    returncode: int = 0,
    stdout: str = "",
    stderr: str = "",
) -> MagicMock:
    cp = MagicMock(spec=subprocess.CompletedProcess)
    cp.returncode = returncode
    cp.stdout = stdout
    cp.stderr = stderr
    return cp


# ---------------------------------------------------------------------------
# GitError
# ---------------------------------------------------------------------------


class TestGitError:
    def test_is_runtime_error(self) -> None:
        assert issubclass(GitError, RuntimeError)

    def test_stores_returncode_and_stderr(self) -> None:
        err = GitError(128, "fatal: not a git repository")
        assert err.returncode == 128
        assert err.stderr == "fatal: not a git repository"

    def test_message_includes_returncode_and_stderr(self) -> None:
        err = GitError(1, "some error")
        assert "1" in str(err)
        assert "some error" in str(err)


# ---------------------------------------------------------------------------
# git_current_branch
# ---------------------------------------------------------------------------


class TestGitCurrentBranch:
    def test_returns_branch_name(self, tmp_path: Path) -> None:
        with patch("subprocess.run", return_value=_cp(stdout="main\n")):
            assert git_ops.git_current_branch(tmp_path) == "main"

    def test_strips_whitespace(self, tmp_path: Path) -> None:
        with patch("subprocess.run", return_value=_cp(stdout="  feature/foo  \n")):
            assert git_ops.git_current_branch(tmp_path) == "feature/foo"

    def test_raises_git_error_on_failure(self, tmp_path: Path) -> None:
        with patch(
            "subprocess.run",
            return_value=_cp(returncode=128, stderr="fatal: not a git repository"),
        ):
            with pytest.raises(GitError) as exc_info:
                git_ops.git_current_branch(tmp_path)
            assert exc_info.value.returncode == 128

    def test_detached_head_returns_head_literal(self, tmp_path: Path) -> None:
        """git rev-parse --abbrev-ref HEAD returns 'HEAD' in detached state."""
        with patch("subprocess.run", return_value=_cp(stdout="HEAD\n")):
            result = git_ops.git_current_branch(tmp_path)
        assert result == "HEAD"

    def test_passes_correct_cwd(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(kwargs)
            return _cp(stdout="main\n")

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_current_branch(tmp_path)

        assert calls[0]["cwd"] == tmp_path


# ---------------------------------------------------------------------------
# git_has_staged
# ---------------------------------------------------------------------------


class TestGitHasStaged:
    def test_returns_true_when_staged_changes_exist(self, tmp_path: Path) -> None:
        with patch("subprocess.run", return_value=_cp(returncode=1)):
            assert git_ops.git_has_staged(tmp_path) is True

    def test_returns_false_when_nothing_staged(self, tmp_path: Path) -> None:
        with patch("subprocess.run", return_value=_cp(returncode=0)):
            assert git_ops.git_has_staged(tmp_path) is False

    def test_does_not_raise_on_nonzero_exit(self, tmp_path: Path) -> None:
        """Exit code 1 means 'has changes'; it must not raise GitError."""
        with patch("subprocess.run", return_value=_cp(returncode=1)):
            result = git_ops.git_has_staged(tmp_path)
        assert result is True

    def test_passes_correct_cwd(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(kwargs)
            return _cp(returncode=0)

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_has_staged(tmp_path)

        assert calls[0]["cwd"] == tmp_path


# ---------------------------------------------------------------------------
# git_add_all
# ---------------------------------------------------------------------------


class TestGitAddAll:
    def test_runs_git_add_dot(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp()

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_add_all(tmp_path)

        assert calls == [["git", "add", "."]]

    def test_raises_git_error_on_failure(self, tmp_path: Path) -> None:
        with patch(
            "subprocess.run",
            return_value=_cp(returncode=1, stderr="error: pathspec failed"),
        ):
            with pytest.raises(GitError):
                git_ops.git_add_all(tmp_path)

    def test_passes_correct_cwd(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(kwargs)
            return _cp()

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_add_all(tmp_path)

        assert calls[0]["cwd"] == tmp_path


# ---------------------------------------------------------------------------
# git_commit
# ---------------------------------------------------------------------------


class TestGitCommit:
    def test_runs_git_commit_with_message(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp()

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_commit(tmp_path, "feat: add feature")

        assert calls == [["git", "commit", "-m", "feat: add feature"]]

    def test_raises_git_error_on_failure(self, tmp_path: Path) -> None:
        with patch(
            "subprocess.run",
            return_value=_cp(returncode=1, stderr="nothing to commit"),
        ):
            with pytest.raises(GitError):
                git_ops.git_commit(tmp_path, "chore: empty")

    def test_passes_message_verbatim(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp()

        msg = "fix: handle unicode — café ☕"
        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_commit(tmp_path, msg)

        assert calls[0][-1] == msg


# ---------------------------------------------------------------------------
# git_push
# ---------------------------------------------------------------------------


class TestGitPush:
    def test_runs_git_push_origin_branch(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp()

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_push(tmp_path, "main")

        assert calls == [["git", "push", "origin", "main"]]

    def test_raises_git_error_on_rejection(self, tmp_path: Path) -> None:
        with patch(
            "subprocess.run",
            return_value=_cp(returncode=1, stderr="rejected"),
        ):
            with pytest.raises(GitError) as exc_info:
                git_ops.git_push(tmp_path, "main")
            assert exc_info.value.returncode == 1

    def test_passes_correct_branch(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp()

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_push(tmp_path, "feature/my-branch")

        assert "feature/my-branch" in calls[0]


# ---------------------------------------------------------------------------
# git_pull_rebase
# ---------------------------------------------------------------------------


class TestGitPullRebase:
    def test_runs_git_pull_rebase(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp()

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_pull_rebase(tmp_path)

        assert calls == [["git", "pull", "--rebase"]]

    def test_raises_git_error_on_failure(self, tmp_path: Path) -> None:
        with patch(
            "subprocess.run",
            return_value=_cp(returncode=1, stderr="CONFLICT"),
        ):
            with pytest.raises(GitError):
                git_ops.git_pull_rebase(tmp_path)

    def test_passes_correct_cwd(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(kwargs)
            return _cp()

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_pull_rebase(tmp_path)

        assert calls[0]["cwd"] == tmp_path


# ---------------------------------------------------------------------------
# git_rev_parse_head
# ---------------------------------------------------------------------------


class TestGitRevParseHead:
    SHA = "a" * 40

    def test_returns_40_char_sha(self, tmp_path: Path) -> None:
        """git_rev_parse_head() returns the 40-char HEAD SHA, stripped."""
        with patch("subprocess.run", return_value=_cp(stdout=self.SHA + "\n")):
            result = git_ops.git_rev_parse_head(tmp_path)

        assert result == self.SHA
        assert len(result) == 40

    def test_strips_trailing_whitespace(self, tmp_path: Path) -> None:
        """git_rev_parse_head() strips whitespace/newlines from stdout."""
        sha = "b" * 40
        with patch("subprocess.run", return_value=_cp(stdout=sha + "\n  ")):
            result = git_ops.git_rev_parse_head(tmp_path)

        assert result == sha

    def test_raises_git_error_on_non_git_directory(self, tmp_path: Path) -> None:
        """git_rev_parse_head() raises GitError when cwd is not a git repo."""
        with patch(
            "subprocess.run",
            return_value=_cp(returncode=128, stderr="fatal: not a git repository"),
        ):
            with pytest.raises(GitError) as exc_info:
                git_ops.git_rev_parse_head(tmp_path)

        assert exc_info.value.returncode == 128

    def test_passes_correct_cwd(self, tmp_path: Path) -> None:
        """git_rev_parse_head() passes cwd correctly to the subprocess."""
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(kwargs)
            return _cp(stdout=self.SHA + "\n")

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_rev_parse_head(tmp_path)

        assert calls[0]["cwd"] == tmp_path

    def test_runs_git_rev_parse_head_command(self, tmp_path: Path) -> None:
        """git_rev_parse_head() issues 'git rev-parse HEAD'."""
        calls = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp(stdout=self.SHA + "\n")

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_rev_parse_head(tmp_path)

        assert calls == [["git", "rev-parse", "HEAD"]]

    def test_integration_real_git_repo(self, tmp_path: Path) -> None:
        """git_rev_parse_head() returns a real 40-char hex SHA in a live git repo."""
        import os
        import subprocess as sp

        git_env = {
            **os.environ,
            "GIT_AUTHOR_NAME": "test",
            "GIT_AUTHOR_EMAIL": "t@t.com",
            "GIT_COMMITTER_NAME": "test",
            "GIT_COMMITTER_EMAIL": "t@t.com",
        }
        sp.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
        sp.run(
            ["git", "commit", "--allow-empty", "-m", "init"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
            env=git_env,
        )

        sha = git_ops.git_rev_parse_head(tmp_path)

        assert len(sha) == 40
        assert all(c in "0123456789abcdef" for c in sha)


# ---------------------------------------------------------------------------
# git_diff
# ---------------------------------------------------------------------------


class TestGitDiff:
    def test_runs_git_diff_base_head(self, tmp_path: Path) -> None:
        calls: list[list[str]] = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp(stdout="diff output\n")

        with patch("subprocess.run", side_effect=fake_run):
            result = git_ops.git_diff(tmp_path, "abc123")

        assert calls == [["git", "diff", "abc123..HEAD"]]
        assert result == "diff output\n"

    def test_custom_head_ref(self, tmp_path: Path) -> None:
        calls: list[list[str]] = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp(stdout="")

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_diff(tmp_path, "abc123", "feature/x")

        assert calls == [["git", "diff", "abc123..feature/x"]]

    def test_stat_flag_appended(self, tmp_path: Path) -> None:
        calls: list[list[str]] = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp(stdout="1 file changed")

        with patch("subprocess.run", side_effect=fake_run):
            result = git_ops.git_diff(tmp_path, "abc123", stat=True)

        assert calls == [["git", "diff", "abc123..HEAD", "--stat"]]
        assert result == "1 file changed"

    def test_raises_git_error_on_failure(self, tmp_path: Path) -> None:
        with patch(
            "subprocess.run",
            return_value=_cp(returncode=128, stderr="fatal: bad revision"),
        ):
            with pytest.raises(GitError) as exc_info:
                git_ops.git_diff(tmp_path, "nonexistent")
            assert exc_info.value.returncode == 128

    def test_passes_correct_cwd(self, tmp_path: Path) -> None:
        calls: list[dict] = []

        def fake_run(argv, **kwargs):
            calls.append(kwargs)
            return _cp(stdout="")

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_diff(tmp_path, "abc123")

        assert calls[0]["cwd"] == tmp_path


# ---------------------------------------------------------------------------
# git_diff_cached
# ---------------------------------------------------------------------------


class TestGitDiffCached:
    def test_stat_false_runs_name_only(self, tmp_path: Path) -> None:
        """stat=False (default) issues 'git diff --cached --name-only'."""
        calls: list[list[str]] = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp(stdout="src/foo.py\n")

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_diff_cached(tmp_path)

        assert calls == [["git", "diff", "--cached", "--name-only"]]

    def test_stat_true_runs_stat(self, tmp_path: Path) -> None:
        """stat=True issues 'git diff --cached --stat'."""
        calls: list[list[str]] = []

        def fake_run(argv, **kwargs):
            calls.append(argv)
            return _cp(stdout="1 file changed\n")

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_diff_cached(tmp_path, stat=True)

        assert calls == [["git", "diff", "--cached", "--stat"]]

    def test_returns_stdout_name_only(self, tmp_path: Path) -> None:
        """Returns the raw stdout from git diff --cached --name-only."""
        with patch("subprocess.run", return_value=_cp(stdout="src/a.py\nsrc/b.py\n")):
            result = git_ops.git_diff_cached(tmp_path, stat=False)

        assert result == "src/a.py\nsrc/b.py\n"

    def test_returns_stdout_stat(self, tmp_path: Path) -> None:
        """Returns the raw stdout from git diff --cached --stat."""
        stat_output = "src/a.py | 10 ++++\n1 file changed, 10 insertions(+)\n"
        with patch("subprocess.run", return_value=_cp(stdout=stat_output)):
            result = git_ops.git_diff_cached(tmp_path, stat=True)

        assert result == stat_output

    def test_raises_git_error_on_failure(self, tmp_path: Path) -> None:
        """Raises GitError when git exits with non-zero."""
        with patch(
            "subprocess.run",
            return_value=_cp(returncode=128, stderr="fatal: not a git repo"),
        ):
            with pytest.raises(GitError) as exc_info:
                git_ops.git_diff_cached(tmp_path)
            assert exc_info.value.returncode == 128

    def test_passes_correct_cwd(self, tmp_path: Path) -> None:
        """Passes the cwd argument to the subprocess."""
        calls: list[dict] = []

        def fake_run(argv, **kwargs):
            calls.append(kwargs)
            return _cp(stdout="")

        with patch("subprocess.run", side_effect=fake_run):
            git_ops.git_diff_cached(tmp_path)

        assert calls[0]["cwd"] == tmp_path
