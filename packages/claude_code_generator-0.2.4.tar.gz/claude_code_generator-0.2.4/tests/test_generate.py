"""Tests for the `code-generator generate` command."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

import pytest
from typer.testing import CliRunner

from code_generator import state as state_module
from code_generator.cli import app
from code_generator.env import DANGEROUS_VARS

if TYPE_CHECKING:
    from pathlib import Path

runner = CliRunner()


@pytest.fixture(autouse=True)
def clear_dangerous_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Strip API-key vars so tests run without hitting the env safety check."""
    for var in DANGEROUS_VARS:
        monkeypatch.delenv(var, raising=False)


def _make_cg_dir(tmp_path: Path) -> Path:
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    state_module.save_state(cg_dir / "state.json", st)
    return cg_dir


def test_phase_and_continue_are_mutually_exclusive(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    _make_cg_dir(tmp_path)
    result = runner.invoke(app, ["generate", "--phase", "3", "--continue"])
    assert result.exit_code == 2


def test_cycle_without_multi_cycle_mode_exits_2(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    _make_cg_dir(tmp_path)
    result = runner.invoke(app, ["generate", "--cycle", "1", "--mode", "single"])
    assert result.exit_code == 2


def test_missing_cg_dir_exits_1(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["generate"])
    assert result.exit_code == 1


def test_dangerous_env_var_is_stripped_with_warning(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
    # No .code-generator dir → exits 1 after the env var is stripped in-process.
    result = runner.invoke(app, ["generate"])
    assert result.exit_code == 1
    assert "ANTHROPIC_API_KEY" not in os.environ
    assert "ANTHROPIC_API_KEY" in (result.stderr or "") or "Max subscription" in (
        result.output or ""
    )


def test_cycle_with_multi_cycle_mode_is_valid(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """--cycle with --mode multi-cycle is valid (no validation error)."""
    monkeypatch.chdir(tmp_path)
    _make_cg_dir(tmp_path)
    _patch_all_phases(monkeypatch)
    result = runner.invoke(app, ["generate", "--cycle", "1", "--mode", "multi-cycle"])
    # Either exits 0 (success) or 1 (runtime error) — not 2 (validation error).
    assert result.exit_code != 2


def test_cycle_with_continue_flag_is_valid(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    _make_cg_dir(tmp_path)
    _patch_all_phases(monkeypatch)
    result = runner.invoke(app, ["generate", "--cycle", "1", "--continue"])
    assert result.exit_code != 2


def _patch_all_phases(monkeypatch: pytest.MonkeyPatch) -> None:
    """Monkeypatch orchestrator modules to no-ops."""
    from code_generator.orchestrator import (
        cycle_loop,
        phase0_complexity,
        phase1_plan,
    )

    async def _noop_phase0(state, project_dir, *, runner_module, logger=None):
        state.mode = "single"
        return state

    async def _noop_single(state, project_dir, *, runner_module, logger=None, start_phase=1):
        return state

    async def _noop_multi(
        state, project_dir, *, runner_module, logger=None, start_cycle=None, start_phase=1
    ):
        return state

    async def _noop_phase1(*args, **kwargs):
        pass

    monkeypatch.setattr(phase0_complexity, "run", _noop_phase0)
    monkeypatch.setattr(cycle_loop, "run_single_mode", _noop_single)
    monkeypatch.setattr(cycle_loop, "run_multi_cycle", _noop_multi)
    monkeypatch.setattr(phase1_plan, "run", _noop_phase1)


def test_single_mode_pipeline_runs_successfully(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """With all phases monkeypatched, single-mode should exit 0."""
    monkeypatch.chdir(tmp_path)
    _make_cg_dir(tmp_path)
    _patch_all_phases(monkeypatch)
    result = runner.invoke(app, ["generate"])
    assert result.exit_code == 0


def test_dry_run_flag_accepted(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    _make_cg_dir(tmp_path)
    _patch_all_phases(monkeypatch)
    result = runner.invoke(app, ["generate", "--dry-run"])
    assert result.exit_code == 0


def test_multi_cycle_mode_dispatches_to_multi_cycle(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """--mode multi-cycle invokes run_multi_cycle, not run_single_mode."""
    from code_generator.orchestrator import cycle_loop, phase0_complexity

    monkeypatch.chdir(tmp_path)
    _make_cg_dir(tmp_path)

    async def _noop_phase0(state, project_dir, *, runner_module, logger=None):
        state.mode = "multi-cycle"
        return state

    called: list[str] = []

    async def _mock_multi(
        state, project_dir, *, runner_module, logger=None, start_cycle=None, start_phase=1
    ):
        called.append("multi")
        return state

    async def _mock_single(state, project_dir, *, runner_module, logger=None, start_phase=1):
        called.append("single")
        return state

    monkeypatch.setattr(phase0_complexity, "run", _noop_phase0)
    monkeypatch.setattr(cycle_loop, "run_multi_cycle", _mock_multi)
    monkeypatch.setattr(cycle_loop, "run_single_mode", _mock_single)

    result = runner.invoke(app, ["generate", "--mode", "multi-cycle"])
    assert result.exit_code == 0
    assert "multi" in called
    assert "single" not in called


# ─────────────────────────────────────────────────────────────────────────────
# Unit-test helpers
# ─────────────────────────────────────────────────────────────────────────────


def _make_state(
    *,
    paused_until: int | None = None,
    phase: int | None = None,
    current_cycle: int | None = None,
    mode: str = "unknown",
    cycles: list[state_module.CycleState] | None = None,
) -> state_module.State:
    """Build a minimal State for direct unit tests (no file I/O)."""
    from datetime import UTC, datetime

    now = datetime.now(tz=UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    return state_module.State(
        mode=mode,  # type: ignore[arg-type]
        started_at=now,
        updated_at=now,
        paused_until=paused_until,
        phase=phase,
        current_cycle=current_cycle,
        cycles=cycles or [],
    )


def _make_cycle(cycle_id: int, *, status: str, phase: int = 5) -> state_module.CycleState:
    """Build a minimal CycleState for direct unit tests."""
    return state_module.CycleState(
        id=cycle_id,
        name=f"cycle-{cycle_id}",
        milestone_number=cycle_id,
        milestone_title=f"Cycle {cycle_id}",
        status=status,
        phase=phase,
        issues=[],
        commit_sha=None,
    )


# ─────────────────────────────────────────────────────────────────────────────
# _check_paused — unit tests
# ─────────────────────────────────────────────────────────────────────────────


class TestCheckPaused:
    def test_returns_true_when_paused_until_is_in_future(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Returns True when the rate-limit pause window has not yet expired."""
        import code_generator.commands.generate as gen_mod
        from code_generator.commands.generate import _check_paused

        monkeypatch.setattr(gen_mod.time, "time", lambda: 1000.0)
        st = _make_state(paused_until=2000)

        assert _check_paused(st) is True

    def test_returns_false_when_paused_until_is_none(self) -> None:
        """Returns False immediately when no pause is recorded in state."""
        from code_generator.commands.generate import _check_paused

        st = _make_state(paused_until=None)

        assert _check_paused(st) is False

    def test_returns_false_when_paused_until_is_in_past(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Returns False when paused_until is set but the window has already expired."""
        import code_generator.commands.generate as gen_mod
        from code_generator.commands.generate import _check_paused

        monkeypatch.setattr(gen_mod.time, "time", lambda: 5000.0)
        st = _make_state(paused_until=3000)

        assert _check_paused(st) is False


# ─────────────────────────────────────────────────────────────────────────────
# _next_start_phase — unit tests
# ─────────────────────────────────────────────────────────────────────────────


class TestNextStartPhase:
    @pytest.mark.parametrize("phase,expected", [(0, 1), (1, 2), (4, 5), (7, 8)])
    def test_returns_phase_plus_one(self, phase: int, expected: int) -> None:
        """Returns last completed phase + 1 for any recorded phase value."""
        from code_generator.commands._resume import next_start_phase as _next_start_phase

        st = _make_state(phase=phase)

        assert _next_start_phase(st) == expected

    def test_returns_1_when_phase_is_none(self) -> None:
        """Defaults to phase 1 when no prior phase is recorded (fresh run)."""
        from code_generator.commands._resume import next_start_phase as _next_start_phase

        st = _make_state(phase=None)

        assert _next_start_phase(st) == 1


# ─────────────────────────────────────────────────────────────────────────────
# _resolve_continue_multi_cycle — unit tests
# ─────────────────────────────────────────────────────────────────────────────


class TestResolveContinueMultiCycle:
    def test_returns_none_1_when_no_current_cycle(self) -> None:
        """Returns (None, 1) when state has no recorded current cycle."""
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as _resolve_continue_multi_cycle,
        )

        st = _make_state(current_cycle=None)

        start_cycle, start_phase = _resolve_continue_multi_cycle(st)

        assert start_cycle is None
        assert start_phase == 1

    def test_advances_to_next_cycle_when_current_is_completed(self) -> None:
        """Returns (current_cycle + 1, 1) when the current cycle status is 'completed'."""
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as _resolve_continue_multi_cycle,
        )

        completed = _make_cycle(2, status="completed")
        st = _make_state(current_cycle=2, cycles=[completed])

        start_cycle, start_phase = _resolve_continue_multi_cycle(st)

        assert start_cycle == 3
        assert start_phase == 1

    def test_resumes_within_cycle_when_current_is_open(self) -> None:
        """Returns (current_cycle, next_phase) when the current cycle is still open."""
        from code_generator.commands._resume import (
            resolve_continue_multi_cycle as _resolve_continue_multi_cycle,
        )

        open_cycle = _make_cycle(1, status="open", phase=3)
        st = _make_state(current_cycle=1, phase=3, cycles=[open_cycle])

        start_cycle, start_phase = _resolve_continue_multi_cycle(st)

        assert start_cycle == 1
        assert start_phase == 4  # _next_start_phase: phase(3) + 1


# ─────────────────────────────────────────────────────────────────────────────
# _dispatch_async needs_phase0 logic — regression guard for issue #88
# ─────────────────────────────────────────────────────────────────────────────


def _patch_dispatch_internals(
    monkeypatch: pytest.MonkeyPatch,
) -> list[str]:
    """Patch all I/O modules used by _dispatch_async; return a call recorder."""
    import logging

    import code_generator.logging_setup as logging_setup_mod
    import code_generator.runner as runner_mod
    from code_generator.orchestrator import cycle_loop, phase0_complexity

    calls: list[str] = []

    async def _mock_phase0(state, project_dir, *, runner_module, logger=None) -> None:  # noqa: ARG001
        calls.append("phase0")
        state.mode = "single"

    async def _mock_single(
        state, project_dir, *, runner_module, logger=None, start_phase=1
    ) -> None:  # noqa: ARG001
        calls.append("single")

    async def _mock_multi(  # noqa: ARG001
        state, project_dir, *, runner_module, logger=None, start_cycle=None, start_phase=1
    ) -> None:
        calls.append("multi")

    monkeypatch.setattr(phase0_complexity, "run", _mock_phase0)
    monkeypatch.setattr(cycle_loop, "run_single_mode", _mock_single)
    monkeypatch.setattr(cycle_loop, "run_multi_cycle", _mock_multi)
    monkeypatch.setattr(
        logging_setup_mod, "setup_phase_logger", lambda name, path: logging.getLogger(name)
    )  # noqa: ARG005
    monkeypatch.setattr(runner_mod, "get_runner", lambda: object())

    return calls


class TestDispatchAsyncNeedsPhase0:
    async def test_calls_phase0_when_mode_auto_and_state_mode_unknown(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """phase0_complexity.run is invoked when mode='auto' and st.mode is not resolved."""
        from code_generator.commands._dispatch import dispatch_async as _dispatch_async

        calls = _patch_dispatch_internals(monkeypatch)
        st = _make_state(mode="unknown")

        await _dispatch_async(
            st, tmp_path, dry_run=False, start_phase=1, start_cycle=None, mode="auto"
        )

        assert "phase0" in calls

    async def test_skips_phase0_and_sets_mode_when_mode_is_single(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """phase0 is skipped and st.mode is forced to 'single' when mode='single'."""
        from code_generator.commands._dispatch import dispatch_async as _dispatch_async

        calls = _patch_dispatch_internals(monkeypatch)
        st = _make_state(mode="unknown")

        await _dispatch_async(
            st, tmp_path, dry_run=False, start_phase=1, start_cycle=None, mode="single"
        )

        assert "phase0" not in calls
        assert st.mode == "single"

    async def test_skips_phase0_and_sets_mode_when_mode_is_multi_cycle(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """phase0 is skipped and st.mode is forced to 'multi-cycle' when mode='multi-cycle'."""
        from code_generator.commands._dispatch import dispatch_async as _dispatch_async

        calls = _patch_dispatch_internals(monkeypatch)
        st = _make_state(mode="unknown")

        await _dispatch_async(
            st, tmp_path, dry_run=False, start_phase=1, start_cycle=None, mode="multi-cycle"
        )

        assert "phase0" not in calls
        assert st.mode == "multi-cycle"
