"""Memee MCP Server — institutional memory tools for Claude Code agents."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "memee",
    # Note: ``version=`` was removed — some mcp library versions reject it as
    # an unexpected kwarg (TypeError). FastMCP now surfaces version via tool
    # metadata rather than the constructor. Current FastMCP accepts
    # ``instructions=`` for the human-readable blurb; ``description=`` is
    # rejected on current releases.
    instructions=(
        "Institutional memory for AI agent teams. "
        "Record, search, and share knowledge across projects. "
        "Your agents forget. Memee doesn't."
    ),
)


_cached_engine = None
_cached_factory = None


def _get_session():
    """Return a new SQLAlchemy session bound to the cached engine.

    The engine + schema init are a per-process one-time cost. Previously
    every MCP tool call re-ran ``init_db()`` (new engine, CREATE IF NOT
    EXISTS on FTS triggers, alembic-version check) which added 20–50 ms
    of overhead to every invocation. Engine + sessionmaker are cached at
    the module level; the caller still gets a fresh Session per call.

    Callers SHOULD use ``_with_session`` decorator or wrap manually with
    ``try/finally session.close()``. Tool bodies that predate this refactor
    rely on CPython refcount cleanup, which releases the connection when the
    local goes out of scope.
    """
    from sqlalchemy.orm import sessionmaker

    from memee.storage.database import get_engine, init_db

    global _cached_engine, _cached_factory
    if _cached_engine is None:
        _cached_engine = get_engine()
        init_db(_cached_engine)
        _cached_factory = sessionmaker(bind=_cached_engine, autoflush=False)
    return _cached_factory()


def _with_session(fn):
    """Decorator that injects ``session`` kwarg and closes it on exit.

    Wrap a tool body with this to get deterministic session close — both on
    successful return and on exceptions. Use from new tools going forward;
    the existing bodies continue to work via refcount cleanup.

    Usage:
        @mcp.tool()
        @_with_session
        async def my_tool(arg: str, *, session):
            ...
    """
    import functools
    import inspect

    is_async = inspect.iscoroutinefunction(fn)

    if is_async:
        @functools.wraps(fn)
        async def wrapper(*args, **kwargs):
            session = _get_session()
            try:
                return await fn(*args, session=session, **kwargs)
            finally:
                try:
                    session.close()
                except Exception:
                    pass

        return wrapper

    @functools.wraps(fn)
    def sync_wrapper(*args, **kwargs):
        session = _get_session()
        try:
            return fn(*args, session=session, **kwargs)
        finally:
            try:
                session.close()
            except Exception:
                pass

    return sync_wrapper


def _parse_tags(tags: str) -> list[str]:
    return [t.strip() for t in tags.split(",") if t.strip()] if tags else []


def _clamp_limit(value, default: int = 10, maxv: int = 200) -> int:
    """Bound a caller-supplied limit. Protects against ``limit=999999``.

    Also handles ``float('inf')`` (OverflowError on int()) and string floats
    like ``"5.5"`` (which would ValueError under a direct ``int(...)``).
    """
    try:
        return max(1, min(int(float(value)), maxv))
    except (TypeError, ValueError, OverflowError):
        return default


def _safe_json(raw, default, *, arg_name: str = ""):
    """Parse JSON but never raise. Returns (value, error-message-or-None).

    If ``raw`` is empty/None, returns ``(default, None)``. If it fails to
    parse, returns ``(default, "bad json in <arg_name>")`` so the caller
    can surface a structured rejection instead of a 500.
    """
    if not raw:
        return default, None
    try:
        return json.loads(raw), None
    except (json.JSONDecodeError, TypeError):
        return default, f"bad json in {arg_name}" if arg_name else "bad json"


def _detect_model(model: str = "") -> str | None:
    """Detect model name from param or environment."""
    if model:
        return model
    from memee.engine.models import detect_current_model
    return detect_current_model()


def _memory_to_dict(memory) -> dict:
    return {
        "id": memory.id,
        "type": memory.type,
        "maturity": memory.maturity,
        "title": memory.title,
        "content": memory.content,
        "tags": memory.tags or [],
        "confidence_score": memory.confidence_score,
        "validation_count": memory.validation_count,
        "project_count": memory.project_count,
        "created_at": memory.created_at.isoformat() if memory.created_at else None,
    }


# ── Memory CRUD ──


@mcp.tool()
async def memory_record(
    type: str,
    title: str,
    content: str,
    tags: str = "",
    project_path: str = "",
    context: str = "{}",
    model: str = "",
    is_authoritative: bool = False,
) -> str:
    """Records a new memory in the organizational knowledge base.

    Types: pattern, decision, anti_pattern, lesson, observation.
    Tags are comma-separated. Context is JSON string with extra metadata.
    Model is auto-detected if not provided.

    Set ``is_authoritative=True`` for policies, personas, or hard
    constraints that the router's Layer 0.5 surfaces in every briefing
    whose tags overlap, regardless of similarity score.

    Suitable for capturing a learning from the current task that could
    inform future projects.
    """
    from memee.engine.quality_gate import merge_duplicate, run_quality_gate
    from memee.storage.models import Memory, Project, ProjectMemory

    session = _get_session()

    tag_list = _parse_tags(tags)
    ctx, ctx_err = _safe_json(context, {}, arg_name="context")
    if ctx_err:
        return json.dumps({"status": "rejected", "reason": ctx_err})
    model_name = _detect_model(model)

    # Quality gate
    gate = run_quality_gate(session, title, content, tag_list, type, source="llm")

    if not gate.accepted and gate.merged:
        existing = session.get(Memory, gate.merged_id)
        if existing:
            merge_duplicate(
                session, existing, content, tag_list,
                new_title=title, similarity=gate.dedup_similarity,
            )
            return json.dumps({"status": "merged", "existing_id": existing.id,
                               "title": existing.title})

    if not gate.accepted and gate.flagged and gate.reason == "large_cluster_manual_review":
        return json.dumps({
            "status": "flagged",
            "reason": gate.reason,
            "candidate_id": gate.merged_id,
            "similarity": gate.dedup_similarity,
            "issues": gate.issues,
        })

    if not gate.accepted:
        return json.dumps({"status": "rejected", "issues": gate.issues})

    memory = Memory(
        type=type,
        title=title,
        content=content,
        tags=tag_list,
        context=ctx,
        source_model=model_name,
        confidence_score=gate.initial_confidence,
        source_type=gate.source_type,
        quality_score=gate.quality_score,
        is_authoritative=bool(is_authoritative),
    )
    session.add(memory)

    if project_path:
        abs_path = str(Path(project_path).resolve())
        proj = session.query(Project).filter_by(path=abs_path).first()
        if proj:
            pm = ProjectMemory(project_id=proj.id, memory_id=memory.id)
            session.add(pm)

    session.commit()

    return json.dumps({
        "status": "recorded",
        "memory": _memory_to_dict(memory),
    })


@mcp.tool()
async def memory_search(
    query: str,
    type: str = "",
    tags: str = "",
    limit: int = 10,
    project_path: str = "",
) -> str:
    """Searches organizational memory using natural language.

    Returns memories ranked by relevance (BM25 + tag overlap + confidence).
    Suitable for finding existing knowledge that may be relevant to a
    problem.

    R13 ``project_path``: when set, memories validated in the named
    project receive a small rerank boost so in-stack proven patterns
    surface ahead of equivalents from elsewhere.

    The response includes a ``query_event_id`` — passing it to
    ``search_feedback`` after picking a result lets Memee track hit@k.
    """
    from memee.engine.search import search_memories
    from memee.storage.models import Project

    session = _get_session()
    try:
        tag_list = _parse_tags(tags) or None
        limit = _clamp_limit(limit, default=10, maxv=200)

        project_id = None
        if project_path:
            abs_path = str(Path(project_path).resolve())
            proj = session.query(Project).filter_by(path=abs_path).first()
            if proj:
                project_id = proj.id

        # Ask search_memories to hand back the exact event id it just wrote.
        # Pulling "latest SearchEvent" here instead races with concurrent callers
        # and can hand the wrong id to search_feedback → corrupted hit@k metrics.
        results, query_event_id = search_memories(
            session,
            query,
            tags=tag_list,
            memory_type=type or None,
            limit=limit,
            return_event_id=True,
            project_id=project_id,
        )

        return json.dumps({
            "count": len(results),
            "query_event_id": query_event_id,
            "results": [
                {
                    **_memory_to_dict(r["memory"]),
                    "score": r["total_score"],
                }
                for r in results
            ],
        })
    finally:
        session.close()


@mcp.tool()
async def search_feedback(
    query_event_id: str,
    accepted_memory_id: str,
    position: int = -1,
) -> str:
    """Mark which memory the agent actually used after a memory_search call.

    Pass the ``query_event_id`` you received from memory_search and the id of
    the memory that solved your task. ``position`` is the 0-based rank the
    memory had in the results (use -1 if unknown — hit@3 won't count that
    event but accepted_rate still will).

    Memee needs this signal to compute retrieval quality (hit@1, hit@3).
    Without feedback we can't tell good results from silent rejections.
    """
    from memee.engine.telemetry import mark_event_accepted

    session = _get_session()
    try:
        ok = mark_event_accepted(
            session,
            event_id=query_event_id,
            memory_id=accepted_memory_id,
            position=None if position is None or position < 0 else int(position),
        )
        return json.dumps({"ok": ok, "event_id": query_event_id})
    finally:
        session.close()


@mcp.tool()
async def memory_suggest(
    context: str,
    project_path: str = "",
    tags: str = "",
    limit: int = 5,
) -> str:
    """Get cross-project suggestions for current task context.

    Describe what you're working on and get relevant memories from other projects.
    Pattern Resonance finds matches by text relevance + tag overlap + maturity.
    """
    from memee.engine.search import search_memories

    session = _get_session()
    try:
        tag_list = _parse_tags(tags) or None
        limit = _clamp_limit(limit, default=5, maxv=200)

        results = search_memories(session, context, tags=tag_list, limit=limit)

        suggestions = []
        for r in results:
            m = r["memory"]
            suggestions.append({
                **_memory_to_dict(m),
                "resonance_score": r["total_score"],
            })

        return json.dumps({
            "context": context[:100],
            "suggestion_count": len(suggestions),
            "suggestions": suggestions,
        })
    finally:
        session.close()


@mcp.tool()
async def memory_validate(
    memory_id: str,
    evidence: str = "",
    project_path: str = "",
    model: str = "",
) -> str:
    """Confirm a memory worked in this context.

    Increases confidence score and may promote maturity level.
    Cross-project validations get 1.5x bonus.
    Cross-model validations get 2.0x bonus (AI peer review).
    Combined cross-project + cross-model = 3.0x maximum bonus.
    """
    from memee.engine.confidence import update_confidence
    from memee.storage.models import Memory, MemoryValidation, Project

    session = _get_session()
    memory = session.get(Memory, memory_id)
    if not memory:
        return json.dumps({"error": f"Memory not found: {memory_id}"})

    model_name = _detect_model(model)
    project_id = None
    if project_path:
        abs_path = str(Path(project_path).resolve())
        proj = session.query(Project).filter_by(path=abs_path).first()
        if proj:
            project_id = proj.id

    validation = MemoryValidation(
        memory_id=memory.id,
        project_id=project_id,
        validated=True,
        evidence=evidence,
        validator_model=model_name,
    )
    session.add(validation)

    old_maturity = memory.maturity
    new_score = update_confidence(
        memory, validated=True, project_id=project_id, model_name=model_name
    )
    memory.last_validated_at = datetime.now(timezone.utc)

    session.commit()

    return json.dumps({
        "status": "validated",
        "memory_id": memory.id,
        "confidence": new_score,
        "maturity_change": f"{old_maturity} -> {memory.maturity}",
    })


@mcp.tool()
async def memory_invalidate(
    memory_id: str,
    reason: str,
    project_path: str = "",
) -> str:
    """Report that a memory didn't hold in this context.

    Decreases confidence score. If invalidated enough times, gets deprecated.
    """
    from memee.engine.confidence import update_confidence
    from memee.storage.models import Memory, MemoryValidation, Project

    session = _get_session()
    memory = session.get(Memory, memory_id)
    if not memory:
        return json.dumps({"error": f"Memory not found: {memory_id}"})

    project_id = None
    if project_path:
        abs_path = str(Path(project_path).resolve())
        proj = session.query(Project).filter_by(path=abs_path).first()
        if proj:
            project_id = proj.id

    validation = MemoryValidation(
        memory_id=memory.id,
        project_id=project_id,
        validated=False,
        evidence=reason,
    )
    session.add(validation)

    old_maturity = memory.maturity
    new_score = update_confidence(memory, validated=False, project_id=project_id)

    session.commit()

    return json.dumps({
        "status": "invalidated",
        "memory_id": memory.id,
        "confidence": new_score,
        "maturity_change": f"{old_maturity} -> {memory.maturity}",
    })


# ── Decisions ──


@mcp.tool()
async def decision_record(
    chosen: str,
    title: str,
    alternatives: str = "[]",
    criteria: str = "[]",
    project_path: str = "",
    reversible: bool = True,
) -> str:
    """Record a technical decision: why X over Y.

    Decision archaeology: when an agent encounters the same choice in a new project,
    it sees the full history of what was chosen before and why.
    Alternatives is JSON array: [{"name": "X", "reason_rejected": "..."}]
    """
    from memee.engine.quality_gate import merge_duplicate, run_quality_gate
    from memee.storage.models import Decision, Memory, MemoryType, Project, ProjectMemory

    session = _get_session()

    alt_list, alt_err = _safe_json(alternatives, [], arg_name="alternatives")
    if alt_err:
        return json.dumps({"status": "rejected", "reason": alt_err})
    crit_list, crit_err = _safe_json(criteria, [], arg_name="criteria")
    if crit_err:
        return json.dumps({"status": "rejected", "reason": crit_err})
    content = f"Chose {chosen}. Alternatives: {alternatives}"

    gate = run_quality_gate(session, title, content, ["decision"], "decision", source="llm")
    # Dedup hit — fold into the existing memory instead of creating a twin.
    if not gate.accepted and gate.merged:
        existing = session.get(Memory, gate.merged_id)
        if existing:
            merge_duplicate(
                session, existing, content, ["decision"],
                new_title=title, similarity=gate.dedup_similarity,
            )
            return json.dumps({
                "status": "merged",
                "existing_id": existing.id,
                "title": existing.title,
            })
    if not gate.accepted:
        return json.dumps({"status": "rejected", "issues": gate.issues})

    # Persist the "decision" tag so future decision_record calls with the
    # same title+tag signature can be detected by the fingerprint gate.
    # Without this the second call can't match the first and we create a
    # twin row (this was the P2 dedup bug before the April 2026 fix).
    memory = Memory(
        type=MemoryType.DECISION.value,
        title=title,
        content=content,
        tags=["decision"],
        confidence_score=gate.initial_confidence,
        source_type=gate.source_type,
        quality_score=gate.quality_score,
    )
    session.add(memory)
    session.flush()

    decision = Decision(
        memory_id=memory.id,
        chosen=chosen,
        alternatives=alt_list,
        criteria=crit_list,
        reversible=reversible,
    )
    session.add(decision)

    if project_path:
        abs_path = str(Path(project_path).resolve())
        proj = session.query(Project).filter_by(path=abs_path).first()
        if proj:
            pm = ProjectMemory(project_id=proj.id, memory_id=memory.id)
            session.add(pm)

    session.commit()

    return json.dumps({
        "status": "recorded",
        "decision": {
            "memory_id": memory.id,
            "chosen": chosen,
            "alternatives": alt_list,
        },
    })


# ── Anti-Patterns ──


@mcp.tool()
async def antipattern_record(
    title: str,
    trigger: str,
    consequence: str,
    severity: str = "medium",
    alternative: str = "",
    tags: str = "",
) -> str:
    """Record an anti-pattern: what NOT to do, and why.

    Severity: low, medium, high, critical.
    Other agents will be warned when their approach matches this anti-pattern.
    """
    from memee.engine.quality_gate import merge_duplicate, run_quality_gate
    from memee.storage.models import AntiPattern, Memory, MemoryType

    session = _get_session()
    tag_list = _parse_tags(tags)
    content = f"Trigger: {trigger}\nConsequence: {consequence}\nAlternative: {alternative}"

    gate = run_quality_gate(session, title, content, tag_list, "anti_pattern", source="llm")
    # Dedup hit — fold into the existing anti-pattern instead of creating a twin.
    if not gate.accepted and gate.merged:
        existing = session.get(Memory, gate.merged_id)
        if existing:
            merge_duplicate(
                session, existing, content, tag_list,
                new_title=title, similarity=gate.dedup_similarity,
            )
            return json.dumps({
                "status": "merged",
                "existing_id": existing.id,
                "title": existing.title,
            })
    if not gate.accepted:
        return json.dumps({"status": "rejected", "issues": gate.issues})

    memory = Memory(
        type=MemoryType.ANTI_PATTERN.value,
        title=title,
        content=f"Trigger: {trigger}\nConsequence: {consequence}\nAlternative: {alternative}",
        tags=tag_list,
    )
    session.add(memory)
    session.flush()

    ap = AntiPattern(
        memory_id=memory.id,
        severity=severity,
        trigger=trigger,
        consequence=consequence,
        alternative=alternative,
    )
    session.add(ap)
    session.commit()

    return json.dumps({
        "status": "recorded",
        "anti_pattern": {
            "memory_id": memory.id,
            "title": title,
            "severity": severity,
        },
    })


@mcp.tool()
async def antipattern_check(
    context: str,
    tags: str = "",
) -> str:
    """Checks an approach against known anti-patterns.

    Returns warnings when the described context matches a recorded
    anti-pattern. Suitable for surfacing relevant lessons before
    implementation.
    """
    from memee.engine.search import search_anti_patterns

    session = _get_session()
    tag_list = _parse_tags(tags) or None

    results = search_anti_patterns(session, context, tags=tag_list)

    if not results:
        return json.dumps({"status": "clear", "message": "No matching anti-patterns."})

    warnings = []
    for r in results:
        m = r["memory"]
        ap = m.anti_pattern
        if ap:
            warnings.append({
                "memory_id": m.id,
                "title": m.title,
                "severity": ap.severity,
                "trigger": ap.trigger,
                "consequence": ap.consequence,
                "alternative": ap.alternative or "",
                "confidence": m.confidence_score,
            })

    return json.dumps({
        "status": "warning",
        "count": len(warnings),
        "warnings": warnings,
    })


# ── Autoresearch — REMOVED in v2.0.0 ──
# The 5 ``research_*`` MCP tools were deleted along with the research engine.
# Every Claude Code session was paying tokens to advertise tools nobody
# called. Use a dedicated experiment tracker (wandb, optuna) instead.


# ── Briefing (PUSH knowledge to agents) ──


@mcp.tool()
async def get_briefing(
    project_path: str = "",
    task: str = "",
    token_budget: int = 500,
) -> str:
    """Returns task-routed organizational knowledge for a project.

    Smart router selects only the patterns, warnings, and decisions
    relevant to the described task — token-budgeted, not exhaustive.

    Example: get_briefing(task="write unit tests for auth module")
    → testing + security patterns only (~300 tokens, not 14,000)

    Token-budgeted: max 500 tokens by default. Adjustable via
    ``token_budget``.
    """
    from memee.engine.router import smart_briefing

    session = _get_session()
    abs_path = str(Path(project_path).resolve()) if project_path else None
    return smart_briefing(session, abs_path, task=task, token_budget=token_budget)


@mcp.tool()
async def post_task_feedback(
    diff_text: str,
    project_path: str = "",
    outcome: str = "success",
    model: str = "",
) -> str:
    """Records the outcome of a task and closes the feedback loop.

    Accepts the git diff and outcome. Memee checks:
    - Whether recommended patterns were followed (validates them)
    - Whether any warnings were violated (records incident)
    - Teaching effectiveness score.
    """
    from memee.engine.feedback import post_task_review

    session = _get_session()
    model_name = _detect_model(model)
    result = post_task_review(
        session, diff_text, project_path,
        model=model_name or "", outcome=outcome,
    )
    return json.dumps(result)


# ── Analytics ──


@mcp.tool()
async def learning_status() -> str:
    """Organizational learning dashboard: memory stats, maturity distribution, learning rate.

    Returns counts and aggregates that describe the shape of the
    knowledge base.
    """
    from sqlalchemy import func

    from memee.storage.models import Memory, Project

    session = _get_session()

    total = session.query(func.count(Memory.id)).scalar() or 0
    if total == 0:
        return json.dumps({"status": "empty", "message": "No memories recorded yet."})

    maturity_counts = dict(
        session.query(Memory.maturity, func.count(Memory.id))
        .group_by(Memory.maturity)
        .all()
    )

    type_counts = dict(
        session.query(Memory.type, func.count(Memory.id))
        .group_by(Memory.type)
        .all()
    )

    avg_confidence = session.query(func.avg(Memory.confidence_score)).scalar() or 0
    project_count = session.query(func.count(Project.id)).scalar() or 0

    return json.dumps({
        "total_memories": total,
        "projects": project_count,
        "avg_confidence": round(avg_confidence, 3),
        "maturity_distribution": maturity_counts,
        "type_distribution": type_counts,
    })


@mcp.tool()
async def canon_list(category: str = "", limit: int = 100) -> str:
    """List all canonical best practices — the organizational truth.

    These are memories that have been validated across 5+ projects
    with 85%+ confidence. Filter by tag/category. ``limit`` is clamped
    to 500 to protect callers from accidental unbounded queries.
    """
    from memee.storage.models import MaturityLevel, Memory

    session = _get_session()
    limit = _clamp_limit(limit, default=100, maxv=500)

    q = session.query(Memory).filter(Memory.maturity == MaturityLevel.CANON.value)

    if category:
        q = q.filter(Memory.tags.contains(category))

    canons = q.limit(limit).all()

    return json.dumps({
        "count": len(canons),
        "canon": [_memory_to_dict(m) for m in canons],
    })


# ── Auto-Propagation ──


@mcp.tool()
async def propagate_patterns(
    confidence_threshold: float = 0.55,
    max_propagations: int = 500,
) -> str:
    """Auto-propagate validated patterns to projects with matching stacks.

    Finds memories above the confidence threshold and pushes them to all
    projects whose stack/tags overlap. This is how knowledge spreads
    across the organization automatically.
    """
    from memee.engine.propagation import run_propagation_cycle

    session = _get_session()
    stats = run_propagation_cycle(
        session, confidence_threshold, max_propagations=max_propagations
    )

    return json.dumps({
        "status": "completed",
        "memories_checked": stats["memories_checked"],
        "memories_propagated": stats["memories_propagated"],
        "new_links": stats["total_new_links"],
        "projects_reached": stats["projects_reached"],
    })


# ── Predictive Anti-Pattern Push ──


@mcp.tool()
async def predict_warnings(
    project_path: str = "",
) -> str:
    """Scans a project's stack against all known anti-patterns.

    Returns every warning whose tags overlap the project's stack.
    Suitable for surfacing relevant lessons up front rather than per
    file.
    """
    from memee.engine.predictive import scan_project_for_warnings
    from memee.storage.models import Project

    session = _get_session()

    if project_path:
        abs_path = str(Path(project_path).resolve())
        project = session.query(Project).filter_by(path=abs_path).first()
    else:
        project = session.query(Project).first()

    if not project:
        return json.dumps({"error": "Project not found. Register it first."})

    warnings = scan_project_for_warnings(session, project)

    return json.dumps({
        "project": project.name,
        "warning_count": len(warnings),
        "warnings": warnings,
    })


# ── Memory Inheritance ──


@mcp.tool()
async def inherit_knowledge(
    project_path: str,
    min_confidence: float = 0.6,
    max_inherit: int = 50,
) -> str:
    """Inherits validated patterns from similar-stack projects.

    For new projects: pulls proven patterns from projects with
    overlapping technology stacks so the canon doesn't start empty.
    """
    from memee.engine.inheritance import inherit_memories
    from memee.storage.models import Project

    session = _get_session()
    abs_path = str(Path(project_path).resolve())
    project = session.query(Project).filter_by(path=abs_path).first()

    if not project:
        return json.dumps({"error": f"Project not found at {project_path}"})

    stats = inherit_memories(
        session, project,
        min_memory_confidence=min_confidence,
        max_inherit=max_inherit,
    )

    return json.dumps({
        "project": project.name,
        "similar_projects": stats["similar_projects"],
        "memories_inherited": stats["memories_inherited"],
        "by_type": stats["by_type"],
    })


# ── Dream Mode ──


@mcp.tool()
async def run_dream() -> str:
    """Runs Dream Mode: a nightly knowledge processing cycle.

    Auto-connects related memories, finds contradictions, boosts
    well-connected memories, proposes promotions, and extracts
    meta-patterns. Designed to run on a schedule (nightly or weekly).
    """
    from memee.engine.dream import run_dream_cycle

    session = _get_session()
    stats = run_dream_cycle(session)

    return json.dumps({
        "status": "completed",
        "connections_created": stats["connections_created"],
        "contradictions_found": stats["contradictions_found"],
        "confidence_boosts": stats["confidence_boosts"],
        "promotions": f"{stats['promotions_applied']}/{stats['promotions_proposed']}",
        "meta_patterns": stats["meta_patterns"],
        "aging": stats.get("aging", {}),
    })


# ── Code Review ──


@mcp.tool()
async def review_code(
    diff_text: str,
    project_path: str = "",
) -> str:
    """Review a git diff against organizational memory.

    Paste or pipe a git diff and get:
    - WARNINGS: code matches known anti-patterns
    - CONFIRMATIONS: code follows validated best practices
    - SUGGESTIONS: related patterns that might help

    Use before merging to catch institutional knowledge violations.
    """
    from memee.engine.review import review_diff

    session = _get_session()
    result = review_diff(session, diff_text, project_path)

    return json.dumps({
        "warnings": result["warnings"],
        "confirmations": result["confirmations"],
        "suggestions": result["suggestions"],
        "stats": result.get("stats", {}),
    })


# ── CMAM (Claude Managed Agents Memory) sync ──


@mcp.tool()
async def sync_to_cmam(
    store_id: str = "",
    backend: str = "fs",
    local_root: str = "",
    dry_run: bool = False,
) -> str:
    """Push Memee's CANON memories + critical anti-patterns to a CMAM store.

    Canon is what Memee has confirmed across ≥5 projects with ≥10 validations.
    Critical anti-patterns propagate regardless. Once synced, a Claude agent
    running with managed memory sees this knowledge in /mnt/memory/ from the
    very first turn — no MCP call needed for baseline org context.

    backend="fs" writes to a local directory (mount into a container);
    backend="api" calls Anthropic's managed memory API (needs ANTHROPIC_API_KEY).
    """
    from memee.adapters.cmam import CMAMConfig, sync_to_cmam as _sync
    from memee.config import settings
    import os as _os
    from pathlib import Path as _Path

    cfg = CMAMConfig(
        store_id=store_id or settings.cmam_store_id,
        backend=backend or settings.cmam_backend,
        local_root=_Path(local_root) if local_root else settings.cmam_local_root,
        api_base=settings.cmam_api_base,
        api_key=_os.environ.get("ANTHROPIC_API_KEY"),
        redact=settings.cmam_redact,
    )
    session = _get_session()
    result = _sync(session, cfg, dry_run=dry_run)

    return json.dumps({
        "store_id": cfg.store_id,
        "backend": cfg.backend,
        "pushed": result.pushed,
        "updated": result.updated,
        "rejected": len(result.rejected),
        "store_count": result.store_count,
        "store_bytes": result.store_bytes,
        "warnings": result.warnings,
        "dry_run": dry_run,
    })
