from vyasa.extensions_builtin.themes import theme_registry
from vyasa.extensions_builtin.themes.base import resolve_theme_extension


def test_theme_registry_contains_builtin_theme_extensions():
    registry = theme_registry()

    assert "vyasa-sunlit" in registry
    assert "abyssal-serenity" in registry
    assert "dice" in registry


def test_dice_theme_extension_resolves_to_member_theme():
    registry = theme_registry()

    theme, resolved = resolve_theme_extension("dice", registry)

    assert resolved == "vyasa-sunlit"
    assert theme.get("theme_body_font")
