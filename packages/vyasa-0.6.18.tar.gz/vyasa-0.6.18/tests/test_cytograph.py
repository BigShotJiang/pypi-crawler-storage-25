from fasthtml.common import to_xml

from vyasa.extensions_builtin.markdown.renderer import from_md


def test_cytograph_block_renders_widget_payload_and_controls():
    md = """```cytograph
---
height: 42vh
layout: cola
initial_depth: 1
---
nodes:
  - id: root
    label: Root
    state: explored
  - id: child
    label: Child
edges:
  - source: root
    target: child
```"""

    html = to_xml(from_md(md))

    assert 'class="cytograph-container' in html
    assert 'style="height: 42vh;"' in html
    assert '"layout": "cola"' in html
    assert '"initial_depth": 1' in html
    assert '"label": "Root"' in html
    assert "resetCytograph('" in html
    assert "zoomCytographIn('" in html
    assert "zoomCytographOut('" in html


def test_cytograph_invalid_body_falls_back_to_empty_graph_payload():
    md = """```cytograph
---
layout: dagre
---
nodes: [broken
```"""

    html = to_xml(from_md(md))

    assert 'class="cytograph-container' in html
    assert '"nodes": []' in html
    assert '"edges": []' in html
    assert '"layout": "dagre"' in html


def test_cytograph_defaults_to_vyasa_layout_when_unspecified():
    md = """```cytograph
nodes:
  - id: root
    label: Root
    state: explored
edges: []
```"""

    html = to_xml(from_md(md))

    assert '"layout": "vyasa"' in html
    assert 'Layout: vyasa' in html


def test_large_cytograph_defaults_to_depth_one_and_compacts_path_labels():
    lines = ["```cytograph", "nodes:"]
    for idx in range(130):
        label = f"package/deep/module_{idx}.py"
        lines.extend([
            f"  - id: node_{idx}",
            f'    label: "{label}"',
            "    state: unexplored",
        ])
    lines.extend(["edges: []", "```"])
    md = "\n".join(lines)

    html = to_xml(from_md(md))

    assert '"initial_depth": 1' in html
    assert '"label": "module_0.py"' in html
    assert '"full_label": "package/deep/module_0.py"' in html


def test_cytograph_source_is_resolved_relative_to_current_path():
    md = """```cytograph
---
source: ./tree.json
---
```"""

    html = to_xml(from_md(md, current_path="demo/guide"))

    assert '"source": "/download/demo/tree.json"' in html
    assert '"initial_depth": 1' in html


def test_cytograph_non_markdown_source_uses_download_route():
    md = """```cytograph
---
source: ./tree.cytree
---
```"""

    html = to_xml(from_md(md, current_path="demo/guide"))

    assert '"source": "/download/demo/tree.cytree"' in html


def test_cytograph_allows_empty_body_when_source_backed():
    md = """```cytograph
---
source: ./tree.json
---
```"""

    html = to_xml(from_md(md, current_path="demo/guide"))

    assert '"source": "/download/demo/tree.json"' in html
    assert '"nodes": []' in html
    assert '"edges": []' in html
