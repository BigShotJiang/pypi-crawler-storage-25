# SPDX-License-Identifier: MIT
"""v0.4.2 — `./nebula trust-history` CLI + war room diversity tests.

Pins the observability layer for the content-based trust model.
Operators should be able to see how the dynamic-trust state of
their workspace evolves without having to run raw SQL.
"""

from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence.schema import ensure_schema


def _seed_trust(db_path: str, repo_identity: str, scores: list[float]) -> None:
    """Seed repo_trust_history with a sequence of scans."""
    conn = sqlite3.connect(db_path)
    try:
        for idx, score in enumerate(scores):
            conn.execute(
                """
                INSERT INTO repo_trust_history
                (repo_identity, quality_score, signals_json,
                 files_scanned, bytes_scanned, scan_duration_seconds, scanned_at)
                VALUES (?, ?, ?, ?, ?, ?, datetime('now', ?))
                """,
                (
                    repo_identity,
                    score,
                    json.dumps(
                        {
                            "spec_density": score,
                            "cryptographic_rigor": score,
                            "zenon_internals_depth": score,
                            "fund_safety_discipline": score,
                            "spec_impl_match": 0.4,
                            "reproducibility": 0.4,
                            "update_cadence": 0.5,
                            "novelty": 0.5,
                            "documentation_quality": score,
                        },
                        sort_keys=True,
                    ),
                    10,
                    1000,
                    0.1,
                    f"-{len(scores) - idx} minutes",
                ),
            )
        conn.commit()
    finally:
        conn.close()


class TestTierNameHelper:
    """_tier_name maps trust scores to human-readable tier names."""

    def test_core_tier(self):
        from scripts.nebula_cli import _tier_name

        assert _tier_name(0.95) == "core"
        assert _tier_name(0.90) == "core"

    def test_trusted_tier(self):
        from scripts.nebula_cli import _tier_name

        assert _tier_name(0.80) == "trusted"
        assert _tier_name(0.70) == "trusted"

    def test_attested_tier(self):
        from scripts.nebula_cli import _tier_name

        assert _tier_name(0.60) == "attested"
        assert _tier_name(0.50) == "attested"

    def test_default_tier(self):
        from scripts.nebula_cli import _tier_name

        assert _tier_name(0.40) == "default"
        assert _tier_name(0.30) == "default"


class TestTrustHistoryCLIOutput:
    """The CLI command produces readable output against a populated DB."""

    def test_empty_db_reports_no_history(self, tmp_path, capsys, monkeypatch):
        db = str(tmp_path / "empty.db")
        ensure_schema(db)

        monkeypatch.setattr("scripts.nebula_cli.DB", Path(db))
        monkeypatch.setattr(sys, "argv", ["nebula", "trust-history"])

        from scripts.nebula_cli import cmd_trust_history

        rc = cmd_trust_history()
        captured = capsys.readouterr()
        assert rc == 0
        assert "No repos scored yet" in captured.out

    def test_list_mode_shows_top_repos(self, tmp_path, capsys, monkeypatch):
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        _seed_trust(db, "repo-a", [0.85] * 55)
        _seed_trust(db, "repo-b", [0.75] * 55)
        _seed_trust(db, "repo-c", [0.60] * 25)

        monkeypatch.setattr("scripts.nebula_cli.DB", Path(db))
        monkeypatch.setattr(sys, "argv", ["nebula", "trust-history"])

        from scripts.nebula_cli import cmd_trust_history

        rc = cmd_trust_history()
        captured = capsys.readouterr()
        assert rc == 0
        assert "repo-a" in captured.out
        assert "repo-b" in captured.out
        assert "repo-c" in captured.out
        # Tier names are shown
        assert "trusted" in captured.out or "attested" in captured.out

    def test_specific_repo_shows_trajectory(self, tmp_path, capsys, monkeypatch):
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        _seed_trust(db, "target-repo", [0.80] * 55)

        monkeypatch.setattr("scripts.nebula_cli.DB", Path(db))
        monkeypatch.setattr(sys, "argv", ["nebula", "trust-history", "target-repo"])

        from scripts.nebula_cli import cmd_trust_history

        rc = cmd_trust_history()
        captured = capsys.readouterr()
        assert rc == 0
        assert "target-repo" in captured.out
        assert "Current dynamic trust" in captured.out
        assert "Scans recorded" in captured.out
        assert "Recent scans" in captured.out

    def test_top_flag_limits_output(self, tmp_path, capsys, monkeypatch):
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        for i in range(10):
            _seed_trust(db, f"repo-{i}", [0.70] * 55)

        monkeypatch.setattr("scripts.nebula_cli.DB", Path(db))
        monkeypatch.setattr(sys, "argv", ["nebula", "trust-history", "--top", "3"])

        from scripts.nebula_cli import cmd_trust_history

        rc = cmd_trust_history()
        captured = capsys.readouterr()
        assert rc == 0
        # Only 3 repos should show in the top output
        shown = sum(1 for i in range(10) if f"repo-{i}" in captured.out)
        assert shown == 3

    def test_unknown_repo_reports_no_history(self, tmp_path, capsys, monkeypatch):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        monkeypatch.setattr("scripts.nebula_cli.DB", Path(db))
        monkeypatch.setattr(sys, "argv", ["nebula", "trust-history", "never-scanned"])

        from scripts.nebula_cli import cmd_trust_history

        rc = cmd_trust_history()
        captured = capsys.readouterr()
        assert rc == 0
        assert "No trust history" in captured.out


class TestWarRoomDiversity:
    """War room commons-diversity section reports by tier, not by name."""

    def test_diversity_section_aggregates_by_tier(self, tmp_path):
        """Recent findings from trusted repos show up in the diversity section."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        # Seed trust history so compute_dynamic_trust promotes these
        _seed_trust(db, "trusted-repo-a", [0.85] * 55)
        _seed_trust(db, "trusted-repo-b", [0.85] * 55)
        _seed_trust(db, "core-repo", [0.90] * 105)

        # Insert recent findings with these source_repos
        conn = sqlite3.connect(db)
        conn.row_factory = sqlite3.Row
        try:
            for repo in ("trusted-repo-a", "trusted-repo-b", "core-repo"):
                conn.execute(
                    """INSERT INTO evidence
                       (domain, engine, evidence_type, finding, confidence,
                        source_repo, timestamp)
                       VALUES (?, ?, ?, ?, ?, ?, datetime('now'))""",
                    ("security", "engine-x", "bug", "finding text", 0.8, repo),
                )
            conn.commit()
        finally:
            conn.close()

        # Call the war room diversity section directly
        from core.war_room import WarRoom

        wr = WarRoom(db_path=db)
        parts: list[str] = []
        conn = wr._get_conn()
        try:
            wr._ctx_trusted_source_diversity(conn, parts)
        finally:
            conn.close()

        assert len(parts) == 1
        section = parts[0]
        assert "COMMONS DIVERSITY" in section
        assert "tier" in section.lower()
        # NO individual repo name should appear in the diversity section
        assert "trusted-repo-a" not in section
        assert "trusted-repo-b" not in section
        assert "core-repo" not in section

    def test_diversity_section_skipped_on_empty_db(self, tmp_path):
        """No recent findings → diversity section is skipped."""
        db = str(tmp_path / "empty.db")
        ensure_schema(db)

        from core.war_room import WarRoom

        wr = WarRoom(db_path=db)
        parts: list[str] = []
        conn = wr._get_conn()
        try:
            wr._ctx_trusted_source_diversity(conn, parts)
        finally:
            conn.close()

        assert parts == []

    def test_diversity_section_never_names_sources(self, tmp_path):
        """Anti-funnel pin: the war room diversity section NEVER names source_repos.

        This is the architectural invariant from task #46: the war
        room reports by tier, not by name, so no single source can
        become the "funnel tell" for a pseudonymous researcher.
        """
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        _seed_trust(db, "developer-commons", [0.90] * 105)

        conn = sqlite3.connect(db)
        try:
            conn.execute(
                """INSERT INTO evidence
                   (domain, engine, evidence_type, finding, confidence,
                    source_repo, timestamp)
                   VALUES (?, ?, ?, ?, ?, ?, datetime('now'))""",
                (
                    "development",
                    "spec_audit",
                    "gap",
                    "spec gap found",
                    0.9,
                    "developer-commons",
                ),
            )
            conn.commit()
        finally:
            conn.close()

        from core.war_room import WarRoom

        wr = WarRoom(db_path=db)
        parts: list[str] = []
        conn = wr._get_conn()
        try:
            wr._ctx_trusted_source_diversity(conn, parts)
        finally:
            conn.close()

        assert parts
        # The critical invariant: "developer-commons" (or any
        # specific source_repo name) MUST NOT appear in the output
        assert "developer-commons" not in parts[0], (
            "War room diversity section MUST NOT name individual "
            "source_repos — that's the funnel tell the v0.4.x "
            "architecture exists to break."
        )
