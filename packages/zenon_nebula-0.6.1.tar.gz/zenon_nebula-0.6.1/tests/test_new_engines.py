# SPDX-License-Identifier: MIT
"""Tests for new domain engines added to Nebula.

Covers: exploit_scanner, cve_monitor, attack_simulator, spec_drift,
ecosystem_gap, talent_radar, consensus_monitor, auto_contributor.
"""

import json
import os
import sqlite3
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

NEBULA_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NEBULA_ROOT))

os.environ.setdefault("ZENON_WORKSPACE_ROOT", os.path.expanduser("~/Repos/Zenon"))


@pytest.fixture
def fresh_db(tmp_path):
    """Create a fresh database with full schema."""
    db_path = str(tmp_path / "test.db")
    from core.persist_to_db import ensure_schema

    ensure_schema(db_path)
    return db_path


@pytest.fixture
def workspace_root():
    """Return workspace root, skip if unavailable."""
    ws = os.environ.get("ZENON_WORKSPACE_ROOT", "")
    if not ws or not Path(ws).exists():
        pytest.skip("No workspace available")
    return Path(ws)


# ========== exploit_scanner ==========


class TestExploitScanner:
    def test_exploit_patterns_defined(self):
        """All 10 exploit patterns are defined."""
        from domains.security.engines.exploit_scanner import EXPLOIT_PATTERNS

        assert len(EXPLOIT_PATTERNS) == 10

    def test_exploit_patterns_have_fields(self):
        """Each pattern has required fields."""
        from domains.security.engines.exploit_scanner import EXPLOIT_PATTERNS

        for p in EXPLOIT_PATTERNS:
            assert p.name, "Pattern missing name"
            assert p.description, f"Pattern {p.name} missing description"
            assert len(p.check_patterns) > 0, f"Pattern {p.name} has no check_patterns"
            assert p.severity in ("critical", "high", "medium", "low")

    def test_scan_all_returns_dict(self):
        """scan_all returns a valid dict even with no go-zenon."""
        from domains.security.engines.exploit_scanner import scan_all

        result = scan_all()
        assert isinstance(result, dict)
        assert "findings" in result
        assert "summary" in result
        assert isinstance(result["findings"], list)
        assert "total_patterns" in result["summary"]
        assert result["summary"]["total_patterns"] == 10

    def test_scan_all_with_workspace(self, workspace_root):
        """scan_all finds files if go-zenon exists."""
        from domains.security.engines.exploit_scanner import scan_all

        go_zenon = workspace_root / "core" / "go-zenon"
        if not go_zenon.exists():
            go_zenon = workspace_root / "zenon-network" / "go-zenon"
        if not go_zenon.exists():
            pytest.skip("go-zenon not in workspace")
        result = scan_all()
        # If go-zenon exists, should find bridge files
        if result["go_zenon_found"]:
            assert len(result["files_scanned"]) > 0

    def test_check_exploit_pattern_no_files(self):
        """check_exploit_pattern returns not_applicable when no files."""
        from domains.security.engines.exploit_scanner import (
            EXPLOIT_PATTERNS,
            check_exploit_pattern,
        )

        result = check_exploit_pattern(EXPLOIT_PATTERNS[0], [])
        assert result.status == "not_applicable"

    def test_check_exploit_pattern_with_vulnerable_file(self, tmp_path):
        """check_exploit_pattern detects vulnerable code."""
        from domains.security.engines.exploit_scanner import (
            ExploitPattern,
            check_exploit_pattern,
        )

        # Create a Go file with a vulnerable pattern but no mitigation
        go_file = tmp_path / "bridge.go"
        go_file.write_text(
            "package bridge\n\n"
            "func verifySignature(sig []byte) bool {\n"
            "    return ecrecover(sig) != nil\n"
            "}\n"
        )

        pattern = ExploitPattern(
            name="test_sig_bypass",
            description="Test pattern",
            check_patterns=[r"(?i)ecrecover"],
            safe_patterns=[r"(?i)isGuardian"],
            severity="critical",
        )
        result = check_exploit_pattern(pattern, [(go_file, "bridge.go")])
        assert result.status == "vulnerable"
        assert len(result.vulnerable_lines) > 0

    def test_check_exploit_pattern_mitigated(self, tmp_path):
        """check_exploit_pattern recognizes mitigations."""
        from domains.security.engines.exploit_scanner import (
            ExploitPattern,
            check_exploit_pattern,
        )

        go_file = tmp_path / "bridge.go"
        go_file.write_text(
            "package bridge\n\n"
            "func verifySignature(sig []byte) bool {\n"
            "    signer := ecrecover(sig)\n"
            "    return isGuardian(signer)\n"
            "}\n"
        )

        pattern = ExploitPattern(
            name="test_sig_bypass",
            description="Test pattern",
            check_patterns=[r"(?i)ecrecover"],
            safe_patterns=[r"(?i)isGuardian"],
            severity="critical",
        )
        result = check_exploit_pattern(pattern, [(go_file, "bridge.go")])
        assert result.status == "mitigated"

    def test_persist_findings(self, fresh_db):
        """persist_findings writes to DB without crash."""
        from domains.security.engines.exploit_scanner import persist_findings

        count = persist_findings(db_path=fresh_db)
        # At minimum, the summary finding is persisted
        assert count >= 1


# ========== cve_monitor ==========


class TestCVEMonitor:
    def test_known_cves_defined(self):
        """Known CVE database is non-empty."""
        from domains.security.engines.cve_monitor import KNOWN_CVES

        assert len(KNOWN_CVES) >= 15

    def test_parse_semver(self):
        """Version parsing handles various formats."""
        from domains.security.engines.cve_monitor import _parse_semver

        assert _parse_semver("v0.14.0") == (0, 14, 0)
        assert _parse_semver("1.2.3") == (1, 2, 3)
        assert _parse_semver("0.0.0-20231215") == (0, 0, 0)

    def test_version_lt(self):
        """Version comparison works."""
        from domains.security.engines.cve_monitor import _version_lt

        assert _version_lt("v0.14.0", "v0.17.0") is True
        assert _version_lt("v0.17.0", "v0.14.0") is False
        assert _version_lt("v0.14.0", "v0.14.0") is False

    def test_parse_go_mod(self, tmp_path):
        """parse_go_mod extracts dependencies from a go.mod file."""
        from domains.security.engines.cve_monitor import parse_go_mod

        go_mod = tmp_path / "go.mod"
        go_mod.write_text(
            "module example.com/test\n"
            "go 1.22\n"
            "require (\n"
            "\tgolang.org/x/crypto v0.14.0\n"
            "\tgithub.com/btcsuite/btcd v0.23.0\n"
            ")\n"
        )
        repo_path = tmp_path
        deps = parse_go_mod(repo_path)
        assert len(deps) == 2
        assert deps[0].name == "golang.org/x/crypto"
        assert deps[0].version == "v0.14.0"

    def test_parse_go_mod_no_file(self, tmp_path):
        """parse_go_mod returns empty for missing go.mod."""
        from domains.security.engines.cve_monitor import parse_go_mod

        deps = parse_go_mod(tmp_path)
        assert deps == []

    def test_parse_package_json(self, tmp_path):
        """parse_package_json extracts dependencies."""
        from domains.security.engines.cve_monitor import parse_package_json

        pkg = tmp_path / "package.json"
        pkg.write_text(
            json.dumps(
                {
                    "dependencies": {"secp256k1": "^4.0.2"},
                    "devDependencies": {"typescript": "5.0.0"},
                }
            )
        )
        deps = parse_package_json(tmp_path)
        assert len(deps) == 2
        names = {d.name for d in deps}
        assert "secp256k1" in names

    def test_check_dependencies_finds_vulnerable(self, tmp_path):
        """check_dependencies flags vulnerable versions."""
        from domains.security.engines.cve_monitor import (
            Dependency,
            check_dependencies,
        )

        deps = [
            Dependency(
                name="golang.org/x/crypto",
                version="v0.14.0",
                ecosystem="go",
                source_file=str(tmp_path / "go.mod"),
            ),
        ]
        findings = check_dependencies(deps, "test-repo")
        # Should find at least one CVE (x/crypto v0.14.0 < v0.17.0 for Terrapin)
        vulnerable = [f for f in findings if f.is_vulnerable]
        assert len(vulnerable) >= 1

    def test_scan_all_returns_valid_dict(self):
        """scan_all returns a valid dict with findings and summary keys."""
        from domains.security.engines.cve_monitor import scan_all

        # Mock live OSV API to avoid network calls/timeouts
        with patch("core.vuln_feed.scan_go_mod", return_value=[]):
            result = scan_all()
            assert isinstance(result, dict)
            assert "findings" in result
            assert "summary" in result

    def test_scan_all_local_only(self):
        """scan_all with local CVE check only (no live API)."""
        from domains.security.engines.cve_monitor import (
            KNOWN_CVES,
        )

        # Just verify the local check works against known CVEs
        assert len(KNOWN_CVES) >= 15

    def test_persist_findings(self, fresh_db):
        """persist_findings writes to DB."""
        from core.persist_to_db import ensure_schema, persist_finding

        ensure_schema(fresh_db)
        persist_finding(
            db_path=fresh_db,
            domain="security",
            engine="cve_monitor",
            evidence_type="cve_scan_summary",
            finding="Test CVE scan summary",
            confidence=0.85,
        )
        conn = sqlite3.connect(fresh_db)
        count = conn.execute("SELECT COUNT(*) FROM evidence WHERE engine='cve_monitor'").fetchone()[
            0
        ]
        conn.close()
        assert count >= 1


# ========== attack_simulator ==========


class TestAttackSimulator:
    def test_governance_takeover_cost(self):
        """Governance takeover calculates positive cost."""
        from domains.security.engines.attack_simulator import (
            NetworkStats,
            simulate_governance_takeover,
        )

        stats = NetworkStats(
            total_pillars=90,
            znn_price_usd=1.0,
            qsr_price_usd=0.1,
        )
        result = simulate_governance_takeover(stats)
        assert result.cost_znn > 0
        assert result.cost_qsr > 0
        assert result.attack_name == "governance_takeover"
        assert result.risk_level in ("critical", "high", "medium", "low")

    def test_delegation_concentration(self):
        """Delegation concentration calculates correctly."""
        from domains.security.engines.attack_simulator import (
            NetworkStats,
            simulate_delegation_concentration,
        )

        stats = NetworkStats(
            total_znn_supply=10_000_000,
            total_delegated_znn=3_000_000,
            znn_price_usd=1.0,
        )
        result = simulate_delegation_concentration(stats)
        assert result.cost_znn > 0
        assert result.attack_name == "delegation_concentration"

    def test_bridge_attack(self):
        """Bridge attack simulation runs."""
        from domains.security.engines.attack_simulator import (
            NetworkStats,
            simulate_bridge_attack,
        )

        stats = NetworkStats(
            active_pillars=15,
            znn_price_usd=1.0,
            qsr_price_usd=0.1,
        )
        result = simulate_bridge_attack(stats)
        assert result.cost_znn > 0
        assert result.attack_name == "bridge_attack"
        assert len(result.mitigations) > 0

    def test_spam_attack(self):
        """Spam attack calculates QSR cost."""
        from domains.security.engines.attack_simulator import (
            NetworkStats,
            simulate_spam_attack,
        )

        stats = NetworkStats(
            total_qsr_supply=50_000_000,
            qsr_price_usd=0.1,
        )
        result = simulate_spam_attack(stats)
        assert result.cost_qsr > 0
        assert result.attack_name == "spam_attack"

    def test_simulate_all_structure(self):
        """simulate_all returns valid structure with mocked RPC."""
        from domains.security.engines import attack_simulator

        # Mock the zenon_data singleton so no real RPC call happens.
        with patch.object(attack_simulator, "get_zenon_data") as mock_rpc:
            stub = mock_rpc.return_value
            stub.get_all_pillars.return_value = []
            stub.get_sentinel_count.return_value = 0
            stub.get_az_balance.return_value = {"znn": 0, "qsr": 0}
            result = attack_simulator.simulate_all()
            assert "attacks" in result
            assert "network_stats" in result
            assert "overall_risk" in result
            assert len(result["attacks"]) == 5

    def test_persist_findings(self, fresh_db):
        """persist_findings writes to DB."""
        from domains.security.engines import attack_simulator

        with patch.object(attack_simulator, "get_zenon_data") as mock_rpc:
            stub = mock_rpc.return_value
            stub.get_all_pillars.return_value = []
            stub.get_sentinel_count.return_value = 0
            stub.get_az_balance.return_value = {"znn": 0, "qsr": 0}
            count = attack_simulator.persist_findings(db_path=fresh_db)
            # Summary + 5 attack findings = 6
            assert count >= 6


# ========== spec_drift ==========


class TestSpecDrift:
    def test_normalize_spec_name(self):
        """Normalizes spec directory names correctly."""
        from domains.development.engines.spec_drift import _normalize_spec_name

        assert _normalize_spec_name("PTLC") == "ptlc"
        assert _normalize_spec_name("Bitcoin-SPV") == "bitcoin_spv"
        assert _normalize_spec_name("AtomicSwap") == "atomic_swap"
        assert _normalize_spec_name("multi_sig") == "multi_sig"

    def test_spec_to_impl_name_mapping(self):
        """Known spec names map to correct Go file stems."""
        from domains.development.engines.spec_drift import _spec_to_impl_name

        assert _spec_to_impl_name("ptlc") == "ptlc"
        assert _spec_to_impl_name("zenon_portal") == "portal"
        assert _spec_to_impl_name("multi_sig") == "multisig"

    def test_extract_spec_code_blocks(self):
        """Extracts fenced code blocks from markdown."""
        from domains.development.engines.spec_drift import _extract_spec_code_blocks

        md = (
            "# Title\n"
            "Some text.\n"
            "```go\n"
            "func Create(param1 Type1)\n"
            "```\n"
            "More text.\n"
            "```\n"
            "func Unlock(param2 Type2)\n"
            "```\n"
        )
        blocks = _extract_spec_code_blocks(md)
        assert len(blocks) == 2
        assert "Create" in blocks[0]
        assert "Unlock" in blocks[1]

    def test_extract_spec_methods(self, tmp_path):
        """extract_spec_methods finds method signatures in spec files."""
        from domains.development.engines.spec_drift import extract_spec_methods

        spec_dir = tmp_path / "PTLC"
        spec_dir.mkdir()
        (spec_dir / "ptlc_spec.md").write_text(
            "# PTLC Spec\n"
            "## Methods\n"
            "```go\n"
            "func Create(pointLocked Address, expirationTime uint64)\n"
            "func Unlock(id Hash, adaptorSignature []byte)\n"
            "```\n"
        )
        methods = extract_spec_methods(spec_dir)
        assert "Create" in methods
        assert "Unlock" in methods

    def test_detect_drift_nonexistent_spec(self, tmp_path):
        """detect_drift_for_spec handles missing spec dir gracefully."""
        from domains.development.engines.spec_drift import detect_drift_for_spec

        result = detect_drift_for_spec(tmp_path / "nonexistent")
        assert isinstance(result, list)
        assert len(result) == 0


# ========== ecosystem_gap ==========


class TestEcosystemGap:
    def test_checklist_defined(self):
        """Ecosystem checklist has entries."""
        from domains.product_market_fit.engines.ecosystem_gap import ECOSYSTEM_CHECKLIST

        assert len(ECOSYSTEM_CHECKLIST) >= 10

    def test_checklist_items_have_fields(self):
        """Each checklist item has required fields."""
        from domains.product_market_fit.engines.ecosystem_gap import ECOSYSTEM_CHECKLIST

        for item in ECOSYSTEM_CHECKLIST:
            assert "id" in item
            assert "label" in item
            assert "effort" in item
            assert item["effort"] in ("S", "M", "L")
            assert "impact" in item

    def test_assess_component_returns_dict(self):
        """assess_component returns a valid dict."""
        from domains.product_market_fit.engines.ecosystem_gap import assess_component

        component = {
            "id": "test_component",
            "label": "Test Component",
            "description": "A test component.",
            "effort": "S",
            "impact": "low",
            "checks": [],
            "known_projects": ["TestProject"],
        }
        result = assess_component(component)
        assert isinstance(result, dict)
        assert result["id"] == "test_component"
        assert "status" in result

    def test_assess_all_returns_list(self):
        """assess_all_components returns a list."""
        from domains.product_market_fit.engines.ecosystem_gap import assess_all_components

        result = assess_all_components()
        assert isinstance(result, list)
        assert len(result) > 0

    def test_prioritize_gaps(self):
        """prioritize_gaps sorts by impact and status."""
        from domains.product_market_fit.engines.ecosystem_gap import prioritize_gaps

        assessed = [
            {"id": "a", "status": "missing", "impact": "high", "effort": "S"},
            {"id": "b", "status": "present", "impact": "high", "effort": "S"},
            {"id": "c", "status": "missing", "impact": "low", "effort": "S"},
        ]
        result = prioritize_gaps(assessed)
        assert isinstance(result, list)
        # Missing items should be prioritized over present
        missing = [r for r in result if r["status"] == "missing"]
        assert len(missing) >= 1

    def test_run_ecosystem_gap_analysis(self, fresh_db):
        """Full analysis runs and returns results."""
        from domains.product_market_fit.engines.ecosystem_gap import run_ecosystem_gap_analysis

        result = run_ecosystem_gap_analysis(db_path=fresh_db)
        assert isinstance(result, dict)
        assert "components" in result or "assessed" in result or "gaps" in result


# ========== talent_radar ==========


class TestTalentRadar:
    def test_find_repos(self, workspace_root):
        """_find_repos discovers repos in the workspace."""
        from domains.community.engines.talent_radar import _find_repos

        repos = _find_repos()
        assert isinstance(repos, list)
        # Should find at least some repos
        if repos:
            org_dir, repo_name, full_path = repos[0]
            assert isinstance(org_dir, str)
            assert isinstance(repo_name, str)
            assert full_path.exists()

    def test_scan_contributors_returns_dict(self, workspace_root):
        """scan_contributors returns a valid dict."""
        from domains.community.engines.talent_radar import scan_contributors

        result = scan_contributors()
        assert isinstance(result, dict)
        assert "contributors" in result or "repo_stats" in result or "classifications" in result

    def test_git_log_nonexistent(self):
        """_get_contributors handles nonexistent paths gracefully."""
        from domains.community.engines.talent_radar import _get_contributors

        result = _get_contributors(Path("/nonexistent/path"))
        assert result == []


# ========== consensus_monitor ==========


class TestConsensusMonitor:
    def test_discover_external_repos(self, workspace_root):
        """discover_external_repos finds repos in workspace."""
        from domains.interoperability.engines.consensus_monitor import discover_external_repos

        result = discover_external_repos()
        assert isinstance(result, dict)
        # May or may not find external chain repos depending on workspace

    def test_chain_folder_patterns_defined(self):
        """Chain folder patterns are defined."""
        from domains.interoperability.engines.consensus_monitor import CHAIN_FOLDER_PATTERNS

        assert "bitcoin" in CHAIN_FOLDER_PATTERNS
        assert "ethereum" in CHAIN_FOLDER_PATTERNS
        assert "cosmos" in CHAIN_FOLDER_PATTERNS

    def test_bitcoin_critical_paths_defined(self):
        """Bitcoin critical paths list is non-empty."""
        from domains.interoperability.engines.consensus_monitor import BITCOIN_CRITICAL_PATHS

        assert len(BITCOIN_CRITICAL_PATHS) >= 10

    def test_ethereum_critical_paths_defined(self):
        """Ethereum critical paths list is non-empty."""
        from domains.interoperability.engines.consensus_monitor import ETHEREUM_CRITICAL_PATHS

        assert len(ETHEREUM_CRITICAL_PATHS) >= 10

    def test_generate_report_structure(self):
        """generate_report returns valid dict structure."""
        from domains.interoperability.engines.consensus_monitor import generate_report

        # Mock git calls to avoid timeouts
        with patch(
            "domains.interoperability.engines.consensus_monitor._run_git", return_value=(0, "")
        ):
            result = generate_report(days=7)
            assert isinstance(result, dict)
            # Should have chains and/or summary
            assert "chains" in result or "summary" in result or len(result) >= 0

    def test_is_git_repo(self, tmp_path):
        """_is_git_repo correctly identifies git repos."""
        from domains.interoperability.engines.consensus_monitor import _is_git_repo

        # Not a git repo
        assert _is_git_repo(tmp_path) is False
        # Make it look like a git repo
        (tmp_path / ".git").mkdir()
        assert _is_git_repo(tmp_path) is True


# ========== auto_contributor ==========


class TestAutoContributor:
    def test_actionable_types_defined(self):
        """Actionable evidence types are defined."""
        from domains.contribution.engines.auto_contributor import ACTIONABLE_TYPES

        assert "vulnerability" in ACTIONABLE_TYPES
        assert "mismatch" in ACTIONABLE_TYPES
        assert "coverage_gap" in ACTIONABLE_TYPES

    def test_priority_map_defined(self):
        """Priority map covers all actionable types."""
        from domains.contribution.engines.auto_contributor import ACTIONABLE_TYPES, PRIORITY_MAP

        for at in ACTIONABLE_TYPES:
            assert at in PRIORITY_MAP, f"Missing priority for {at}"

    def test_query_actionable_evidence_empty(self, fresh_db):
        """Empty DB returns no actionable evidence."""
        from domains.contribution.engines.auto_contributor import _query_actionable_evidence

        result = _query_actionable_evidence(fresh_db)
        assert result == []

    def test_query_actionable_evidence_with_data(self, fresh_db):
        """Returns high-confidence actionable findings."""
        from domains.contribution.engines.auto_contributor import _query_actionable_evidence

        conn = sqlite3.connect(fresh_db)
        conn.execute(
            """INSERT INTO evidence
               (domain, engine, evidence_type, finding, confidence, status,
                source_repo, source_file)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                "quality",
                "cross_repo_checker",
                "mismatch",
                "ZNS address mismatch between SDK and Go",
                0.99,
                "open",
                "znn_sdk_dart",
                "lib/src/model/primitives/address.dart",
            ),
        )
        conn.commit()
        conn.close()

        result = _query_actionable_evidence(fresh_db)
        assert len(result) >= 1
        assert result[0]["evidence_type"] == "mismatch"

    def test_generate_contributions_empty(self, fresh_db):
        """Empty DB produces no contributions."""
        from domains.contribution.engines.auto_contributor import generate_contributions

        result = generate_contributions(db_path=fresh_db)
        assert result == []

    def test_generate_contributions_from_seeded(self, fresh_db):
        """Generates contributions from seeded evidence."""
        from domains.contribution.engines.auto_contributor import generate_contributions

        conn = sqlite3.connect(fresh_db)
        for i, etype in enumerate(["vulnerability", "mismatch", "coverage_gap"]):
            conn.execute(
                """INSERT INTO evidence
                   (domain, engine, evidence_type, finding, confidence, status,
                    source_repo, source_file)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    "security" if etype == "vulnerability" else "quality",
                    "test_engine",
                    etype,
                    f"Test finding {etype} number {i}",
                    0.90,
                    "open",
                    "go-zenon",
                    f"test_{i}.go",
                ),
            )
        conn.commit()
        conn.close()

        result = generate_contributions(db_path=fresh_db)
        assert len(result) >= 1
        # Should be prioritized (vulnerability first)
        if len(result) > 1:
            assert result[0]["priority"] <= result[-1]["priority"]

    def test_determine_target_repo_sdk(self):
        """Target repo detection for SDK mismatches."""
        from domains.contribution.engines.auto_contributor import _determine_target_repo

        evidence = {
            "evidence_type": "address_mismatch",
            "finding": "Address mismatch in znn_sdk_dart for ZNS contract",
            "source_repo": "go-zenon",
        }
        result = _determine_target_repo(evidence)
        assert result == "znn_sdk_dart"

    def test_determine_fix_description(self):
        """Fix description generation works."""
        from domains.contribution.engines.auto_contributor import _determine_fix_description

        evidence = {
            "evidence_type": "address_mismatch",
            "finding": "ZNS address wrong",
            "source_file": "lib/model/address.dart",
            "raw_data": json.dumps({"expected": "z1abc", "actual": "z1xyz"}),
        }
        result = _determine_fix_description(evidence)
        assert "address mismatch" in result.lower()
        assert "z1abc" in result
