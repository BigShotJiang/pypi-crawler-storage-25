# SPDX-License-Identifier: MIT
"""Tests for core.telemetry -- opt-in crash + metrics reporting."""

import json
from unittest import mock

import pytest

from core import telemetry


@pytest.fixture(autouse=True)
def _isolate_telemetry(tmp_path, monkeypatch):
    """Redirect queue + instance_id to tmp_path so tests don't touch real data."""
    monkeypatch.setattr(telemetry, "TELEMETRY_QUEUE", tmp_path / "queue.json")
    monkeypatch.setattr(telemetry, "INSTANCE_ID_FILE", tmp_path / "instance_id")
    # Default: telemetry off so tests opt-in explicitly.
    monkeypatch.delenv("NEBULA_TELEMETRY", raising=False)
    monkeypatch.setenv("NEBULA_TELEMETRY_ENDPOINT", "http://127.0.0.1:1/")
    yield


def test_disabled_by_default():
    assert telemetry.is_enabled() is False


def test_enabled_when_env_set(monkeypatch):
    monkeypatch.setenv("NEBULA_TELEMETRY", "1")
    assert telemetry.is_enabled() is True


def test_instance_id_is_stable():
    a = telemetry.get_instance_id()
    b = telemetry.get_instance_id()
    assert a == b
    assert len(a) > 10  # looks like a uuid


def test_collect_environment_has_no_pii():
    env = telemetry.collect_environment()
    assert "version" in env
    assert "protocol_version" in env
    assert "python" in env
    assert "os" in env
    assert "instance_id" in env
    # No home dir leakage.
    blob = json.dumps(env)
    assert "/Users/" not in blob
    assert "/home/" not in blob


def test_report_crash_noop_when_disabled():
    try:
        raise ValueError("boom")
    except ValueError as exc:
        telemetry.report_crash(exc, context="test")
    # Queue should NOT exist -- disabled is a hard no-op.
    assert not telemetry.TELEMETRY_QUEUE.exists()


def test_report_crash_queues_on_network_failure(monkeypatch):
    monkeypatch.setenv("NEBULA_TELEMETRY", "1")
    try:
        raise ValueError("test leak: /Users/bob/code key=sk-abc123")
    except ValueError as exc:
        telemetry.report_crash(exc, context="unit test /Users/bob")

    assert telemetry.TELEMETRY_QUEUE.exists()
    events = json.loads(telemetry.TELEMETRY_QUEUE.read_text())
    assert len(events) == 1
    event = events[0]
    assert event["type"] == "crash"
    assert event["exception_type"] == "ValueError"
    # Local path must be sanitized out of every field.
    blob = json.dumps(event)
    assert "/Users/bob" not in blob


def test_report_metrics_drops_complex_values(monkeypatch):
    monkeypatch.setenv("NEBULA_TELEMETRY", "1")
    telemetry.report_metrics(
        {
            "count": 5,
            "rate": 0.5,
            "label": "ok",
            "obj": object(),  # must be dropped / stringified
        }
    )
    assert telemetry.TELEMETRY_QUEUE.exists()
    events = json.loads(telemetry.TELEMETRY_QUEUE.read_text())
    metrics = events[0]["metrics"]
    assert metrics["count"] == 5
    assert metrics["rate"] == 0.5
    assert metrics["label"] == "ok"
    assert metrics["obj"] == "<object>"


def test_report_engine_errors_filters_non_integers(monkeypatch):
    monkeypatch.setenv("NEBULA_TELEMETRY", "1")
    telemetry.report_engine_errors(
        {
            "upstream_watcher": 3,
            "bad": "not a number",
            "also_bad": None,
            "sig_tracker": 1,
        }
    )
    events = json.loads(telemetry.TELEMETRY_QUEUE.read_text())
    errors = events[0]["errors"]
    assert errors == {"upstream_watcher": 3, "sig_tracker": 1}


def test_flush_queue_drains_on_success(monkeypatch):
    monkeypatch.setenv("NEBULA_TELEMETRY", "1")

    # Queue something first (all sends fail via dead endpoint).
    telemetry.report_metrics({"x": 1})
    assert telemetry.TELEMETRY_QUEUE.exists()

    # Now pretend the endpoint works.
    with mock.patch.object(telemetry, "_post_event", return_value=True):
        sent = telemetry.flush_queue()
    assert sent >= 1
    # Drained queue is removed.
    assert not telemetry.TELEMETRY_QUEUE.exists()


def test_queue_is_capped(monkeypatch):
    monkeypatch.setenv("NEBULA_TELEMETRY", "1")
    monkeypatch.setattr(telemetry, "MAX_QUEUED_EVENTS", 5)
    for i in range(20):
        telemetry.report_metrics({"i": i})
    events = json.loads(telemetry.TELEMETRY_QUEUE.read_text())
    assert len(events) == 5
    # Most recent events kept.
    last = events[-1]["metrics"]["i"]
    assert last == 19
