# SPDX-License-Identifier: MIT
"""Rule freshness test.

Walks every CLAUDE.md, MAINTAINING.md, and .claude/rules/*.md file, extracts
file path references via regex, and fails if any referenced path no longer
exists. Stale rules mislead future sessions, so this is a hard gate.

The regex is conservative: it only matches paths that look like repo-relative
source references (endings in .py/.md/.yml/.yaml/.toml/.sh/.json and starting
with a known top-level directory or './'). It deliberately skips:
- URLs (http://, https://)
- Paths inside code blocks that are illustrative examples
- Glob patterns with *
- Absolute paths (/Users/..., /home/...)
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]

# Top-level directories we care about. A path reference starting with one of
# these is treated as a real claim about the repo's layout.
KNOWN_ROOTS = {
    "core",
    "domains",
    "tests",
    "scripts",
    "docs",
    "data",
    "benchmarks",
    ".github",
    ".claude",
    ".devcontainer",
    ".vscode",
}

# File extensions that should exist on disk when referenced.
TRACKED_EXTENSIONS = {
    ".py",
    ".md",
    ".yml",
    ".yaml",
    ".toml",
    ".sh",
    ".json",
    ".cfg",
    ".ini",
    ".txt",
}

# Whitelist of known-illustrative paths that may appear in rules but that we
# don't want to enforce the existence of (e.g., example file names in prompt
# templates that are meant as placeholders).
ILLUSTRATIVE = {
    "core/foo.py",
    "tests/test_foo.py",
    "core/foo/bar.py",
    "domains/<name>/domain.py",
    "domains/<name>/engines/X.py",
    "domains/<name>/engines/Y.py",
    "domains/<name>/shared.py",
    "domains/<name>/engines/*.py",
    "tests/test_<engine>.py",
    "tests/test_<module>.py",
    "tests/test_<domain>_domain.py",
    "tests/test_<domain>.py",
    "tests/test_<engine>_contract.py",
    "tests/test_*_contract.py",
    "docs/specs/PTLC/ptlc_spec.md",
    "docs/specs/PTLC",
    "docs/runbooks/<runbook>.md",
    "domains/<name>/engines/<engine>.py",
    "core/api/embedded",
    "core/go-zenon",
    "core/embedded",
    "core/embedded/X.go",
}

# Regex: roots[/subdir]+/filename.ext
PATH_RE = re.compile(
    r"(?<![A-Za-z0-9_./\-])"
    r"(?:" + "|".join(sorted(KNOWN_ROOTS)) + r")"
    r"(?:/[A-Za-z0-9_\-./]+)+?"
    r"(?:" + "|".join(ext.replace(".", r"\.") for ext in TRACKED_EXTENSIONS) + r")"
    r"(?![A-Za-z0-9_])"
)


def _collect_rule_files() -> list[Path]:
    """Return every file whose references we want to check."""
    files: list[Path] = []

    # Root-level
    for name in ("CLAUDE.md", "MAINTAINING.md", "README.md", "CONTRIBUTING.md", "SECURITY.md"):
        p = ROOT / name
        if p.exists():
            files.append(p)

    # Per-subsystem CLAUDE.md
    for pattern in (
        "core/CLAUDE.md",
        "core/persistence/CLAUDE.md",
        "domains/CLAUDE.md",
        "tests/CLAUDE.md",
        "scripts/CLAUDE.md",
    ):
        p = ROOT / pattern
        if p.exists():
            files.append(p)

    # .claude/rules/*.md
    rules_dir = ROOT / ".claude" / "rules"
    if rules_dir.exists():
        files.extend(sorted(rules_dir.glob("*.md")))

    # docs/runbooks/*.md
    runbooks = ROOT / "docs" / "runbooks"
    if runbooks.exists():
        files.extend(sorted(runbooks.glob("*.md")))

    return files


def _extract_references(text: str) -> set[str]:
    """Return all path-like references in the text."""
    return set(PATH_RE.findall(text))


def _is_illustrative(ref: str) -> bool:
    """Return True if the reference is an illustrative placeholder."""
    if ref in ILLUSTRATIVE:
        return True
    # Any reference containing a placeholder like <name> or * is illustrative.
    return bool("<" in ref or "*" in ref)


def test_rule_files_exist() -> None:
    """The rule-walker itself must find some files to walk."""
    files = _collect_rule_files()
    assert files, "No rule files found — did the repo layout change?"


@pytest.mark.parametrize("rule_file", _collect_rule_files(), ids=lambda p: str(p.relative_to(ROOT)))
def test_rule_references_are_fresh(rule_file: Path) -> None:
    """Every file path referenced in a rule must exist on disk."""
    text = rule_file.read_text(encoding="utf-8")
    refs = _extract_references(text)

    missing = []
    for ref in refs:
        if _is_illustrative(ref):
            continue
        candidate = ROOT / ref
        if not candidate.exists():
            missing.append(ref)

    assert not missing, (
        f"{rule_file.relative_to(ROOT)} references paths that do not exist:\n"
        + "\n".join(f"  - {m}" for m in sorted(missing))
        + "\n\nFix the rule or add the missing path. See .claude/rules/rule-hygiene.md."
    )
