# SPDX-License-Identifier: MIT
"""Tests for core.config — central configuration loader."""

import json

import pytest

import core.config as config_mod
from core.config import NebulaConfig, get_config, reload_config


@pytest.fixture(autouse=True)
def reset_config_cache():
    """Reset the cached NebulaConfig before and after each test."""
    config_mod._cached_config = None
    yield
    config_mod._cached_config = None


class TestBudget:
    def test_daily_budget_loaded(self):
        c = get_config()
        assert c.daily_api_budget_usd > 0

    def test_warning_threshold_is_fraction(self):
        c = get_config()
        assert 0.0 < c.budget_warning_threshold <= 1.0

    def test_pause_threshold_is_fraction(self):
        c = get_config()
        assert 0.0 < c.budget_pause_threshold <= 1.0

    def test_pause_threshold_geq_warning(self):
        c = get_config()
        assert c.budget_pause_threshold >= c.budget_warning_threshold

    def test_max_actions_per_hour_positive(self):
        c = get_config()
        assert c.max_actions_per_hour > 0


class TestZenonFacts:
    def test_facts_loaded(self):
        c = get_config()
        facts = c.zenon_facts
        assert isinstance(facts, dict)
        assert "pillar_lock_znn" in facts

    def test_facts_are_copy(self):
        """Mutating the returned dict must not affect the underlying config."""
        c = get_config()
        facts = c.zenon_facts
        facts["spurious"] = 123
        assert "spurious" not in get_config().zenon_facts


class TestRouting:
    def test_strategic_route_has_model(self):
        c = get_config()
        route = c.route("strategic_synthesis")
        assert "model" in route

    def test_unknown_route_empty(self):
        c = get_config()
        assert c.route("definitely_not_a_real_route") == {}


class TestTimeouts:
    def test_api_default_loaded(self):
        c = get_config()
        assert c.timeout("api_default") > 0

    def test_unknown_timeout_falls_back_to_api_default(self):
        c = get_config()
        unknown = c.timeout("xyz_never_configured")
        assert unknown == c.timeout("api_default")

    def test_explicit_default_used_when_no_config(self, tmp_path, monkeypatch):
        empty = NebulaConfig(timeouts={})
        assert empty.timeout("nothing", default=42) == 42


class TestEngines:
    def test_bridge_health_defaults(self):
        c = get_config()
        bh = c.engine("bridge_health")
        assert bh.get("min_relayers") == 3

    def test_unknown_engine_empty(self):
        c = get_config()
        assert c.engine("no_such_engine") == {}


class TestTrust:
    def test_zenon_network_fully_trusted(self):
        assert get_config().trust_for_org("zenon-network") == 1.0

    def test_unknown_org_gets_default(self):
        c = get_config()
        assert c.trust_for_org("TotallyUnknownOrg123") == c.default_trust

    def test_default_trust_capped(self):
        c = get_config()
        assert 0.0 <= c.default_trust <= 1.0


class TestEnvOverrides:
    def test_budget_env_override(self, monkeypatch):
        monkeypatch.setenv("NEBULA_DAILY_BUDGET_USD", "123.45")
        reload_config()
        assert get_config().daily_api_budget_usd == 123.45

    def test_timeout_env_override(self, monkeypatch):
        monkeypatch.setenv("NEBULA_API_TIMEOUT", "77")
        reload_config()
        assert get_config().timeout("api_default") == 77

    def test_invalid_env_value_ignored(self, monkeypatch):
        monkeypatch.setenv("NEBULA_DAILY_BUDGET_USD", "not_a_number")
        reload_config()
        # Should fall back to the JSON value, not crash
        assert get_config().daily_api_budget_usd > 0


class TestLocalOverride:
    def test_local_json_overrides_system(self, tmp_path, monkeypatch):
        """config/local.json should override any section via matching keys."""
        fake_config_dir = tmp_path / "config"
        fake_config_dir.mkdir()

        # Minimal system.json
        (fake_config_dir / "system.json").write_text(
            json.dumps({"budget": {"daily_api_budget_usd": 10.0, "max_actions_per_hour": 1}})
        )
        # local.json overrides budget
        (fake_config_dir / "local.json").write_text(
            json.dumps({"system": {"budget": {"daily_api_budget_usd": 999.0}}})
        )

        monkeypatch.setattr(config_mod, "CONFIG_DIR", fake_config_dir)
        reload_config()

        c = get_config()
        assert c.daily_api_budget_usd == 999.0
        # Non-overridden field should survive the deep merge
        assert c.max_actions_per_hour == 1


class TestCaching:
    def test_get_config_cached(self):
        c1 = get_config()
        c2 = get_config()
        assert c1 is c2

    def test_reload_config_returns_fresh(self):
        get_config()
        c2 = reload_config()
        # After reload, cached instance should be the new one
        assert get_config() is c2


class TestBackwardCompat:
    def test_trust_module_still_importable(self):
        from core.trust import DEFAULT_TRUST, TRUSTED_ORGS

        assert isinstance(TRUSTED_ORGS, dict)
        assert len(TRUSTED_ORGS) > 0
        assert isinstance(DEFAULT_TRUST, float)

    def test_model_router_still_works(self):
        from core.model_router import get_all_routes, get_model

        assert isinstance(get_all_routes(), dict)
        assert isinstance(get_model("strategic_synthesis"), str)
