# SPDX-License-Identifier: MIT
"""Tests for core.hallucination_guard -- Claim verification and tagging."""

import json
import sqlite3

import pytest

import core.hallucination_guard as guard_mod
from core.hallucination_guard import (
    HallucinationGuard,
    guard_before_publish,
)


@pytest.fixture(autouse=True)
def reset_protocol_facts():
    """Reset the cached protocol facts before each test."""
    guard_mod._PROTOCOL_FACTS = None
    yield
    guard_mod._PROTOCOL_FACTS = None


@pytest.fixture
def protocol_facts():
    """Provide known protocol facts for verification testing."""
    return {
        "daily_znn_emission": 4320,
        "daily_qsr_emission": 5000,
        "pillar_lock_znn": 15000,
        "sentinel_lock_znn": 5000,
        "sentinel_lock_qsr": 50000,
        "wznn_contract_eth": "0xb2e96a63479c2edd2fd62b382c89d5ca79f572d3",
        "max_qsr_supply": 79137247,
    }


@pytest.fixture
def guard(protocol_facts, tmp_path):
    """Create a guard with known facts and a temp DB."""
    guard_mod._PROTOCOL_FACTS = protocol_facts
    db_path = str(tmp_path / "test.db")
    return HallucinationGuard(db_path=db_path, dry_run=True)


@pytest.fixture
def db_with_evidence(tmp_path):
    """Create a DB with pre-seeded evidence."""
    db_path = str(tmp_path / "evidence.db")
    conn = sqlite3.connect(db_path)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS evidence (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            engine TEXT, evidence_type TEXT, finding TEXT,
            confidence REAL, raw_data TEXT
        );
    """)
    conn.execute(
        "INSERT INTO evidence (engine, evidence_type, finding, confidence, raw_data) "
        "VALUES (?, ?, ?, ?, ?)",
        (
            "block_engine",
            "block_check",
            "Zenon emission rate is 4320 ZNN daily",
            0.95,
            json.dumps({"provenance": "verified_by_api"}),
        ),
    )
    conn.commit()
    conn.close()
    return db_path


class TestProtocolConstantVerification:
    def test_correct_znn_emission_confirmed(self, guard):
        result = guard.check("The network emits 4320 ZNN per day.")
        confirmed = [c for c in result.claims if c.status == "CONFIRMED"]
        assert len(confirmed) >= 1

    def test_incorrect_znn_emission_flagged(self, guard):
        result = guard.check("The network emits 9999 ZNN per day.")
        inaccurate = [c for c in result.claims if not c.is_accurate]
        assert len(inaccurate) >= 1
        assert result.safe_to_publish is False

    def test_pillar_lock_amount(self, guard):
        result = guard.check("You need 15000 ZNN to run a pillar.")
        confirmed = [c for c in result.claims if c.status == "CONFIRMED"]
        assert len(confirmed) >= 1

    def test_sentinel_requirements(self, guard):
        result = guard.check(
            "You need 5000 ZNN to run a sentinel and 50000 QSR to create a sentinel."
        )
        confirmed = [c for c in result.claims if c.status == "CONFIRMED"]
        assert len(confirmed) >= 1


class TestKnownAddresses:
    def test_known_contract_address_confirmed(self, guard):
        result = guard.check(
            "The wZNN contract is at 0xb2e96a63479c2edd2fd62b382c89d5ca79f572d3 on Ethereum."
        )
        confirmed = [c for c in result.claims if c.status == "CONFIRMED"]
        assert len(confirmed) >= 1


class TestEvidenceStoreVerification:
    def test_verified_by_api_returns_verified(self, protocol_facts, db_with_evidence):
        guard_mod._PROTOCOL_FACTS = protocol_facts
        guard = HallucinationGuard(db_path=db_with_evidence, dry_run=True)
        result = guard.check("Zenon emission rate confirmed daily.")
        # May match protocol constant or evidence store
        statuses = {c.status for c in result.claims}
        assert (
            statuses.intersection({"CONFIRMED", "VERIFIED", "THEORY"}) or result.claims_checked == 0
        )


class TestUnverifiedClaims:
    def test_unverifiable_claim_tagged(self, guard):
        result = guard.check("The feeless architecture uses 42 plasma units per transaction.")
        if result.claims:
            unverified = [c for c in result.claims if c.status == "UNVERIFIED"]
            assert len(unverified) >= 1

    def test_too_many_unverified_unsafe(self, guard):
        # Bunch of made-up claims
        content = (
            "The network processes 99999 ZNN daily. "
            "The staking APY is 500%. "
            "Plasma fees are 0.01 USD per tx. "
            "The emission rate is 1 ZNN per block."
        )
        result = guard.check(content)
        if result.claims_checked > 0:
            # Either flagged as inaccurate or too many unverified
            assert not result.safe_to_publish or result.unverified_count == 0


class TestContentTagging:
    def test_tags_inserted_in_content(self, guard):
        content = "The network emits 4320 ZNN per day."
        result = guard.check(content)
        if result.claims:
            # Tagged content should contain a status tag
            assert "[CONFIRMED]" in result.content_tagged or "[UNVERIFIED]" in result.content_tagged

    def test_original_content_preserved(self, guard):
        content = "Some normal text about Zenon."
        result = guard.check(content)
        assert result.content_original == content


class TestGuardResult:
    def test_counts_are_consistent(self, guard):
        result = guard.check(
            "The network emits 4320 ZNN per day. "
            "Pillars require 15000 ZNN. "
            "Some unknown 999 ZNN claim."
        )
        total = (
            result.verified_count
            + result.confirmed_count
            + result.theory_count
            + result.unverified_count
        )
        assert total == result.claims_checked

    def test_warnings_for_inaccurate(self, guard):
        result = guard.check("The network emits 9999 ZNN per day.")
        assert len(result.warnings) > 0


class TestGuardBeforePublish:
    def test_integration_function(self, protocol_facts, tmp_path):
        guard_mod._PROTOCOL_FACTS = protocol_facts
        db_path = str(tmp_path / "pub.db")
        safe, tagged, warnings = guard_before_publish(
            "The network emits 4320 ZNN per day.",
            db_path=db_path,
        )
        assert isinstance(safe, bool)
        assert isinstance(tagged, str)
        assert isinstance(warnings, list)
