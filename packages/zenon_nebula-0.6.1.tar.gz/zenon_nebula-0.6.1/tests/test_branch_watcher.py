# SPDX-License-Identifier: MIT
"""v0.5.8 branch_watcher engine tests.

Pins the anti-doxxing invariants (no author reads, branch-name
sanitization) + the confidence-cap enforcement + graceful
degradation.
"""

from __future__ import annotations

import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from domains.intelligence.engines import branch_watcher as bw


class TestConfidenceCap:
    def test_confidence_capped_at_branch_tier(self):
        assert bw._capped_confidence(0.99) == 0.60
        assert bw._capped_confidence(0.70) == 0.60
        assert bw._capped_confidence(0.55) == 0.55
        assert bw._capped_confidence(0.40) == 0.40


class TestBranchNameSanitization:
    def test_user_prefix_stripped(self):
        assert bw._sanitize_branch_name("alice/feature-x") == "<user>/feature-x"
        assert bw._sanitize_branch_name("mehowz/bug-42") == "<user>/bug-42"
        assert bw._sanitize_branch_name("TminusZ/spec-draft") == "<user>/spec-draft"

    def test_non_user_prefix_untouched(self):
        assert bw._sanitize_branch_name("feature-x") == "feature-x"
        assert bw._sanitize_branch_name("fix-42") == "fix-42"
        assert bw._sanitize_branch_name("release-v1") == "release-v1"

    def test_short_prefix_not_matched(self):
        """Very short prefixes (< 3 chars) aren't treated as usernames."""
        assert bw._sanitize_branch_name("ab/xyz") == "ab/xyz"


class TestAntiDoxxingGuarantees:
    """Pin that executable code never reads git-author data."""

    @staticmethod
    def _executable_source() -> str:
        import re

        src = Path(bw.__file__).read_text()
        src = re.sub(r'""".*?"""', "", src, flags=re.DOTALL)
        src = re.sub(r"'''.*?'''", "", src, flags=re.DOTALL)
        src = re.sub(r"#.*$", "", src, flags=re.MULTILINE)
        return src

    def test_no_git_author_flag(self):
        src = self._executable_source()
        assert "--author" not in src, "branch_watcher MUST NOT invoke `git log --author`"

    def test_no_git_author_format_codes(self):
        src = self._executable_source()
        for code in ("%an", "%ae", "%aN", "%aE", "%cn", "%ce"):
            assert code not in src, f"branch_watcher MUST NOT use git format code {code}"

    def test_no_git_blame(self):
        src = self._executable_source()
        assert "git blame" not in src
        assert "blame" not in src

    def test_no_author_in_raw_data_keys(self):
        """Verify the raw_data persisted alongside findings never
        includes any author field."""
        src = self._executable_source()
        # The engine's persist_finding call should not mention author
        # keys in raw_data
        assert '"author"' not in src
        assert "'author'" not in src
        assert '"email"' not in src
        assert "'email'" not in src


class TestFormatFinding:
    def test_finding_never_contains_committer_markers(self):
        """The finding body may MENTION 'git-author data' as part of
        explaining what it doesn't include. The test checks for
        actual committer-identifying markers, not the literal word
        'author'."""
        body = bw._format_finding("go-zenon", "feature-x", 5, ["file1.go", "file2.go"])
        # Markers that would indicate real author data slipped through
        assert "@" not in body  # no email addresses
        assert "Signed-off-by" not in body
        assert "committer" not in body.lower()
        # Format markers must be present
        assert "WHAT:" in body
        assert "SO WHAT:" in body
        assert "NOW WHAT:" in body

    def test_sanitized_branch_name_in_body(self):
        body = bw._format_finding("repo", "alice/feature", 3, ["file.go"])
        assert "<user>/feature" in body
        assert "alice" not in body


class TestEntryPointDiscovery:
    def test_run_branch_watcher_is_discoverable(self):
        import inspect

        sig = inspect.signature(bw.run_branch_watcher)
        required_non_db = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty and p.name != "db_path"
        ]
        assert required_non_db == []


class TestDegradation:
    def test_workspace_missing_returns_empty(self, tmp_path, monkeypatch):
        from unittest.mock import patch

        with patch(
            "domains.intelligence.engines.branch_watcher.workspace_root",
            return_value=None,
        ):
            result = bw.run_branch_watcher(db_path=str(tmp_path / "x.db"))
        assert result["repos_scanned"] == 0
        assert result["workspace_root"] is None
