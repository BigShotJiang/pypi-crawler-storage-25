# SPDX-License-Identifier: MIT
"""v0.4.0 Phase C — dynamic trust regression tests.

Pins the new content-based trust model that replaces hardcoded-by-
name trust floors. Two promotion paths (gradual + rapid), demotion
on latest-quality drop, emergency quarantine ceiling as the
operator-controlled cap.

These tests are the anti-funnel invariants: a new pseudonymous repo
with high-quality content gets promoted identically to how a known
trusted repo would, and a known repo with declining quality gets
demoted identically. The trust tier depends on content, not on name.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence import connect
from core.persistence.schema import ensure_schema
from core.trust import (
    _TIER_ATTESTED,
    _TIER_CORE,
    _TIER_TRUSTED,
    DEFAULT_TRUST,
    compute_dynamic_trust,
)


def _write_scan_history(
    db_path: str,
    repo_identity: str,
    quality_scores: list[float],
    signals_override: dict | None = None,
) -> None:
    """Helper: write a sequence of scans to repo_trust_history."""
    conn = connect(db_path)
    try:
        for idx, score in enumerate(quality_scores):
            # Use reproducibility + spec_impl_match defaults that DON'T
            # qualify for rapid-recognition (keep gradual path isolated
            # in tests that expect gradual only).
            default_signals = {
                "spec_density": score,
                "cryptographic_rigor": score,
                "zenon_internals_depth": score,
                "fund_safety_discipline": score,
                "spec_impl_match": 0.4,
                "reproducibility": 0.4,
                "update_cadence": 0.5,
                "novelty": 0.5,
                "documentation_quality": score,
            }
            signals = {**default_signals, **(signals_override or {})}
            conn.execute(
                """
                INSERT INTO repo_trust_history
                (repo_identity, quality_score, signals_json,
                 files_scanned, bytes_scanned, scan_duration_seconds, scanned_at)
                VALUES (?, ?, ?, ?, ?, ?, datetime('now', ?))
                """,
                (
                    repo_identity,
                    score,
                    json.dumps(signals, sort_keys=True),
                    10,
                    1000,
                    0.1,
                    # Older scans get older timestamps so ORDER BY DESC
                    # sees the last entry in the list as "most recent"
                    f"-{len(quality_scores) - idx} minutes",
                ),
            )
        conn.commit()
    finally:
        conn.close()


class TestDefaultTrustFloor:
    """Every repo starts at DEFAULT_TRUST — no name-based floors."""

    def test_unknown_repo_returns_default(self, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        trust = compute_dynamic_trust("never-scanned", db_path=db)
        assert trust == DEFAULT_TRUST

    def test_no_history_rows_returns_default(self, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        trust = compute_dynamic_trust("fresh-repo", db_path=db)
        assert trust == DEFAULT_TRUST

    def test_missing_history_table_does_not_crash(self, tmp_path):
        """Pre-Phase-B DB without repo_trust_history gets default."""
        db = str(tmp_path / "empty.db")
        # Deliberately don't call ensure_schema
        try:
            conn = connect(db)
            conn.close()
        except Exception:
            pass
        trust = compute_dynamic_trust("anything", db_path=db)
        assert trust == DEFAULT_TRUST


class TestGradualPromotion:
    """Sustained content quality earns tier promotions."""

    def test_attested_tier_at_20_scans_over_0_6(self, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        _write_scan_history(db, "steady-producer", [0.65] * 25)
        trust = compute_dynamic_trust("steady-producer", db_path=db)
        assert trust == _TIER_ATTESTED

    def test_trusted_tier_at_50_scans_over_0_75(self, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        _write_scan_history(db, "trusted-producer", [0.80] * 55)
        trust = compute_dynamic_trust("trusted-producer", db_path=db)
        assert trust == _TIER_TRUSTED

    def test_core_tier_at_100_scans_over_0_85(self, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        _write_scan_history(db, "core-producer", [0.90] * 105)
        trust = compute_dynamic_trust("core-producer", db_path=db)
        assert trust == _TIER_CORE

    def test_below_threshold_stays_default(self, tmp_path):
        """Quality above 0 but below 0.6 stays at DEFAULT_TRUST."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        _write_scan_history(db, "mediocre", [0.55] * 50)
        trust = compute_dynamic_trust("mediocre", db_path=db)
        assert trust == DEFAULT_TRUST

    def test_scan_count_matters_not_just_quality(self, tmp_path):
        """10 scans of quality 0.9 stays at DEFAULT (< 20 scans)."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        # Use signals that don't trigger rapid path
        _write_scan_history(
            db,
            "few-but-good",
            [0.92] * 10,
            signals_override={"spec_impl_match": 0.3, "reproducibility": 0.3},
        )
        trust = compute_dynamic_trust("few-but-good", db_path=db)
        # With 10 scans and no rapid-recognition signals, stays at default
        assert trust == DEFAULT_TRUST


class TestRapidRecognition:
    """Single exceptional scan earns trusted tier (not core)."""

    def test_single_exceptional_scan_to_trusted(self, tmp_path):
        """One quality_score >= 0.90 with strong impl + repro → TRUSTED."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        _write_scan_history(
            db,
            "satoshi-style",
            [0.95],
            signals_override={"spec_impl_match": 0.95, "reproducibility": 0.85},
        )
        trust = compute_dynamic_trust("satoshi-style", db_path=db)
        assert trust == _TIER_TRUSTED

    def test_rapid_path_capped_below_core(self, tmp_path):
        """Rapid path never promotes past TRUSTED (0.7), not CORE (0.9)."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        _write_scan_history(
            db,
            "one-drop",
            [0.99],
            signals_override={"spec_impl_match": 1.0, "reproducibility": 1.0},
        )
        trust = compute_dynamic_trust("one-drop", db_path=db)
        assert trust == _TIER_TRUSTED
        assert trust < _TIER_CORE

    def test_high_quality_without_impl_or_repro_stays_default(self, tmp_path):
        """Gaming: high quality_score but low impl+repro doesn't trigger rapid."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        _write_scan_history(
            db,
            "gamer",
            [0.95],
            signals_override={"spec_impl_match": 0.1, "reproducibility": 0.1},
        )
        trust = compute_dynamic_trust("gamer", db_path=db)
        assert trust == DEFAULT_TRUST


class TestDemotion:
    """Trust drops when latest quality falls below floor."""

    def test_latest_below_0_4_drops_to_default(self, tmp_path):
        """Even after sustained quality history, a recent bad scan demotes."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        # 60 good scans followed by one bad scan (most recent)
        history = [0.90] * 60 + [0.30]
        _write_scan_history(db, "abandoned", history)
        trust = compute_dynamic_trust("abandoned", db_path=db)
        assert trust == DEFAULT_TRUST

    def test_steady_quality_above_floor_maintains_tier(self, tmp_path):
        """Latest quality above 0.4 doesn't trigger demotion."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        history = [0.85] * 55
        _write_scan_history(db, "steady", history)
        trust = compute_dynamic_trust("steady", db_path=db)
        assert trust == _TIER_TRUSTED


class TestAntiFunnelInvariant:
    """The architectural core: no repo gets unearned trust by name."""

    def test_two_repos_with_same_history_get_same_trust(self, tmp_path):
        """Anti-funnel invariant: content equivalence → trust equivalence."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        # "Famous name" and "unknown pseudonym" with identical history
        _write_scan_history(db, "developer-commons", [0.80] * 55)
        _write_scan_history(db, "new-pseudonymous-repo", [0.80] * 55)

        trust_a = compute_dynamic_trust("developer-commons", db_path=db)
        trust_b = compute_dynamic_trust("new-pseudonymous-repo", db_path=db)
        assert trust_a == trust_b, (
            "Two repos with identical content history MUST have "
            "identical trust scores. The v0.4.0 anti-funnel guarantee "
            "is that names grant no advantage."
        )
        assert trust_a == _TIER_TRUSTED

    def test_high_quality_pseudonymous_beats_low_quality_famous(self, tmp_path):
        """A new repo with better content > an old repo with worse content."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        # "Famous name" stopped producing quality work
        _write_scan_history(db, "developer-commons", [0.55] * 55)

        # New pseudonym publishes excellent work
        _write_scan_history(db, "mystery-researcher", [0.90] * 55)

        trust_famous = compute_dynamic_trust("developer-commons", db_path=db)
        trust_mystery = compute_dynamic_trust("mystery-researcher", db_path=db)
        assert trust_mystery > trust_famous
