# SPDX-License-Identifier: MIT
"""
Tests for core.knowledge_graph -- Cross-domain visualization.

Tests graph building with evidence/hypothesis/collision nodes,
edge construction, and export to JSON/mermaid/text formats.
"""

import json
import sqlite3
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.collision_engine import CollisionEngine
from core.knowledge_graph import (
    GraphEdge,
    GraphNode,
    KnowledgeGraph,
)
from core.persist_to_db import ensure_schema


@pytest.fixture
def db_path(tmp_path):
    """Create a DB with hypotheses, evidence, and collisions."""
    db = str(tmp_path / "test_engine.db")
    ensure_schema(db)

    conn = sqlite3.connect(db)

    # Hypothesis
    conn.execute(
        "INSERT INTO hypotheses (id, domain, title, confidence, status) "
        "VALUES ('H1', 'security', 'Fund lock bug', 0.85, 'INVESTIGATING')"
    )
    conn.execute(
        "INSERT INTO hypotheses (id, domain, title, confidence, status) "
        "VALUES ('H2', 'development', 'PTLC ready', 0.6, 'TESTING')"
    )

    # Evidence supporting H1 from two domains
    conn.execute(
        "INSERT INTO evidence (domain, engine, evidence_type, finding, "
        "confidence, supports_hypothesis) VALUES "
        "('security', 'adversarial', 'vuln', 'reentrancy found', 0.9, 'H1')"
    )
    conn.execute(
        "INSERT INTO evidence (domain, engine, evidence_type, finding, "
        "confidence, supports_hypothesis) VALUES "
        "('quality', 'spec_verifier', 'abi', 'ABI mismatch', 0.75, 'H1')"
    )

    # Evidence supporting H2
    conn.execute(
        "INSERT INTO evidence (domain, engine, evidence_type, finding, "
        "confidence, supports_hypothesis) VALUES "
        "('development', 'impl_coverage', 'coverage', 'PTLC 100%', 0.8, 'H2')"
    )

    # Evidence contradicting H2
    conn.execute(
        "INSERT INTO evidence (domain, engine, evidence_type, finding, "
        "confidence, contradicts_hypothesis) VALUES "
        "('quality', 'test_runner', 'test', 'PTLC test failing', 0.7, 'H2')"
    )

    conn.commit()
    conn.close()

    # Collision (created after conn is closed to avoid DB lock)
    ce = CollisionEngine(db_path=db)
    ce._persist_collision(
        type(
            "Collision",
            (),
            {
                "id": "col_test1",
                "collision_type": "convergent_evidence",
                "hypothesis_id": "H1",
                "title": "Cross-domain fund lock",
                "confidence": 0.85,
                "domains_involved": ["security", "quality"],
                "engines_involved": ["adversarial", "spec_verifier"],
                "engine_count": 2,
                "convergent": True,
                "actions": [{"action": "block_pr", "priority": 10, "details": "sec"}],
            },
        )()
    )
    return db


class TestGraphNode:
    def test_to_dict(self):
        node = GraphNode(
            id="e_1",
            label="Test evidence",
            node_type="evidence",
            domain="security",
            engine="adversarial",
            confidence=0.9,
        )
        d = node.to_dict()
        assert d["id"] == "e_1"
        assert d["type"] == "evidence"
        assert d["confidence"] == 0.9


class TestGraphEdge:
    def test_to_dict(self):
        edge = GraphEdge(
            source="e_1",
            target="h_H1",
            edge_type="supports",
            weight=0.9,
            label="supports",
        )
        d = edge.to_dict()
        assert d["source"] == "e_1"
        assert d["target"] == "h_H1"
        assert d["type"] == "supports"


class TestKnowledgeGraphBuild:
    """Test graph construction from DB data."""

    def test_build_produces_nodes(self, db_path):
        kg = KnowledgeGraph(db_path=db_path)
        graph = kg.build()

        assert graph.stats["total_nodes"] > 0
        assert graph.stats["evidence_count"] >= 4
        assert graph.stats["hypothesis_count"] >= 2

    def test_build_produces_edges(self, db_path):
        kg = KnowledgeGraph(db_path=db_path)
        graph = kg.build()

        assert graph.stats["total_edges"] > 0
        assert graph.stats["supports_edges"] >= 2
        assert graph.stats["contradicts_edges"] >= 1

    def test_cross_domain_edges(self, db_path):
        """Evidence from different domains supporting same hypothesis creates cross-domain edges."""
        kg = KnowledgeGraph(db_path=db_path)
        graph = kg.build()

        # H1 has evidence from security and quality -> cross domain edge
        assert graph.stats["cross_domain_edges"] >= 1

    def test_clusters_by_domain(self, db_path):
        kg = KnowledgeGraph(db_path=db_path)
        graph = kg.build()

        assert "by_domain" in graph.clusters
        assert len(graph.clusters["by_domain"]) >= 2

    def test_clusters_by_type(self, db_path):
        kg = KnowledgeGraph(db_path=db_path)
        graph = kg.build()

        assert "evidence" in graph.clusters["by_type"]
        assert "hypothesis" in graph.clusters["by_type"]

    def test_collision_nodes_loaded(self, db_path):
        kg = KnowledgeGraph(db_path=db_path)
        graph = kg.build()

        assert graph.stats["collision_count"] >= 1


class TestExportJSON:
    def test_export_json_creates_file(self, db_path, tmp_path):
        kg = KnowledgeGraph(db_path=db_path)
        output = str(tmp_path / "graph.json")
        json_str = kg.export_json(output_path=output)

        assert Path(output).exists()
        data = json.loads(json_str)
        assert "nodes" in data
        assert "edges" in data
        assert "generated_at" in data

    def test_export_json_auto_builds(self, db_path, tmp_path):
        """export_json auto-builds graph if not already built."""
        kg = KnowledgeGraph(db_path=db_path)
        assert kg._graph is None
        kg.export_json(output_path=str(tmp_path / "graph.json"))
        assert kg._graph is not None


class TestExportMermaid:
    def test_export_mermaid_creates_file(self, db_path, tmp_path):
        kg = KnowledgeGraph(db_path=db_path)
        output = str(tmp_path / "graph.md")
        mermaid = kg.export_mermaid(output_path=output)

        assert Path(output).exists()
        assert "```mermaid" in mermaid
        assert "graph TD" in mermaid

    def test_mermaid_contains_hypothesis_nodes(self, db_path, tmp_path):
        kg = KnowledgeGraph(db_path=db_path)
        mermaid = kg.export_mermaid(output_path=str(tmp_path / "g.md"))
        assert "h_H1" in mermaid
        assert "h_H2" in mermaid


class TestExportSummary:
    def test_summary_text(self, db_path):
        kg = KnowledgeGraph(db_path=db_path)
        summary = kg.export_summary()

        assert "Knowledge Graph:" in summary
        assert "Hypotheses:" in summary
        assert "Top evidence:" in summary

    def test_summary_auto_builds(self, db_path):
        kg = KnowledgeGraph(db_path=db_path)
        assert kg._graph is None
        kg.export_summary()
        assert kg._graph is not None


class TestMermaidSafe:
    def test_escapes_quotes(self):
        assert KnowledgeGraph._mermaid_safe('"hello"') == "'hello'"

    def test_escapes_angle_brackets(self):
        result = KnowledgeGraph._mermaid_safe("<tag>")
        # Angle brackets are HTML-escaped
        assert "<" not in result
        assert ">" not in result
        assert "lt;" in result
        assert "gt;" in result

    def test_escapes_ampersand(self):
        assert "&amp;" in KnowledgeGraph._mermaid_safe("a & b")
