# SPDX-License-Identifier: MIT
"""
Tests for core.curiosity -- Autonomous exploration engine.

Tests suggest_unexplored ranking, random_sample, coverage tracking,
and cross-repo pattern search.
"""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.curiosity import CuriosityEngine


@pytest.fixture
def workspace(tmp_path):
    """Create a fake workspace with several repos."""
    for name in ["repo_a", "repo_b", "repo_c"]:
        repo = tmp_path / name
        repo.mkdir()
        (repo / ".git").mkdir()
        # Add some source files
        (repo / "main.go").write_text("package main")
        (repo / "lib.py").write_text("# python lib")
    return str(tmp_path)


@pytest.fixture
def curiosity(workspace, monkeypatch):
    """Create a CuriosityEngine pointed at the fake workspace."""
    # Ensure curiosity data dirs exist in a temp location
    monkeypatch.setattr(
        "core.curiosity.CURIOSITY_DIR",
        Path(workspace) / ".curiosity_data",
    )
    monkeypatch.setattr(
        "core.curiosity.LAST_EXPLORED_PATH",
        Path(workspace) / ".curiosity_data" / "last_explored.json",
    )
    monkeypatch.setattr(
        "core.curiosity.EXPLORATION_LOG_PATH",
        Path(workspace) / ".curiosity_data" / "exploration_log.json",
    )
    return CuriosityEngine(workspace_root=workspace)


class TestSuggestUnexplored:
    """Test unexplored repo suggestions."""

    def test_never_explored_first(self, curiosity):
        """Never-explored repos appear first in suggestions."""
        suggestions = curiosity.suggest_unexplored(limit=10)
        # All repos are never-explored, so all should appear
        assert len(suggestions) >= 3
        for s in suggestions:
            assert s["reason"] == "never explored"

    def test_limit_respected(self, curiosity):
        """Limit parameter caps the number of suggestions."""
        suggestions = curiosity.suggest_unexplored(limit=1)
        assert len(suggestions) <= 1

    def test_explored_repos_deprioritized(self, curiosity):
        """Recently explored repos should not appear in suggestions."""
        # Mark a repo as explored
        curiosity._record_exploration("repo_a", "test", {})

        suggestions = curiosity.suggest_unexplored(limit=10, staleness_hours=168)
        names = [s["repo_name"] for s in suggestions]
        # repo_a was just explored, so it should not appear as stale
        assert "repo_a" not in names

    def test_stale_repos_appear(self, curiosity):
        """Repos explored long ago should reappear as stale."""
        curiosity.last_explored["repo_a"] = "2020-01-01T00:00:00+00:00"
        suggestions = curiosity.suggest_unexplored(limit=10, staleness_hours=168)
        names = [s["repo_name"] for s in suggestions]
        assert "repo_a" in names


class TestRandomSample:
    """Test random file sampling."""

    def test_returns_files(self, curiosity):
        """Random sample returns files from a repo."""
        sample = curiosity.random_sample("repo_a", count=5)
        # Should find at least main.go
        assert len(sample) >= 0  # May be 0 if no index and scan finds nothing

    def test_ext_filter(self, curiosity):
        """Extension filter limits file types."""
        sample = curiosity.random_sample("repo_a", count=5, ext_filter=".go")
        for f in sample:
            assert f.get("ext") == ".go"


class TestExplorationCoverage:
    """Test coverage tracking."""

    def test_coverage_starts_at_zero(self, curiosity):
        coverage = curiosity.get_exploration_coverage()
        assert coverage["total_repos"] >= 3
        assert coverage["ever_explored"] == 0
        assert coverage["coverage_percent"] == 0.0

    def test_coverage_increases_after_exploration(self, curiosity):
        curiosity._record_exploration("repo_a", "test", {})
        curiosity._record_exploration("repo_b", "test", {})

        coverage = curiosity.get_exploration_coverage()
        assert coverage["ever_explored"] == 2
        assert coverage["coverage_percent"] > 0

    def test_recent_coverage_tracks_7d(self, curiosity):
        curiosity._record_exploration("repo_a", "test", {})

        coverage = curiosity.get_exploration_coverage()
        assert coverage["explored_last_7d"] >= 1


class TestExplorationHistory:
    """Test exploration history tracking."""

    def test_history_records_events(self, curiosity):
        curiosity._record_exploration("repo_a", "test_action", {"key": "val"})

        history = curiosity.get_exploration_history(limit=10)
        assert len(history) == 1
        assert history[0]["repo"] == "repo_a"
        assert history[0]["action"] == "test_action"


class TestDiscoverRepos:
    """Test repo discovery in workspace."""

    def test_discovers_git_repos(self, curiosity):
        repos = curiosity._discover_repos()
        names = [r["name"] for r in repos]
        assert "repo_a" in names
        assert "repo_b" in names
        assert "repo_c" in names

    def test_skips_hidden_dirs(self, curiosity, workspace):
        """Hidden directories (starting with .) are skipped."""
        (Path(workspace) / ".hidden_repo").mkdir()
        (Path(workspace) / ".hidden_repo" / ".git").mkdir()

        repos = curiosity._discover_repos()
        names = [r["name"] for r in repos]
        assert ".hidden_repo" not in names
