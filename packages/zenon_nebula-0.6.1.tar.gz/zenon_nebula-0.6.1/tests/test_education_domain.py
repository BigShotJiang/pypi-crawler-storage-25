# SPDX-License-Identifier: MIT
"""Tests for domains.education.domain -- Documentation and onboarding."""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.education.domain import EducationDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestEducationDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(EducationDomain, DomainPlugin)

    def test_name(self):
        assert EducationDomain().name() == "education"

    def test_get_engines_non_empty(self):
        engines = EducationDomain().get_engines()
        assert len(engines) >= 1
        names = [e.name for e in engines]
        assert "doc_quality" in names

    def test_get_hypothesis_types_non_empty(self):
        types = EducationDomain().get_hypothesis_types()
        assert len(types) >= 1

    def test_get_aspiration_types(self):
        assert isinstance(EducationDomain().get_aspiration_types(), list)

    def test_get_collision_signals(self):
        signals = EducationDomain().get_collision_signals()
        assert isinstance(signals, list)
        # Should have undocumented_contract signal
        ids = [s.signal_id for s in signals]
        assert "undocumented_contract" in ids

    def test_get_war_room_contributions(self):
        assert isinstance(EducationDomain().get_war_room_contributions(), list)

    def test_get_self_improvement_metrics(self):
        metrics = EducationDomain().get_self_improvement_metrics()
        assert isinstance(metrics, dict)

    def test_get_db_schema_sql(self):
        sql = EducationDomain().get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action(self):
        action = EducationDomain().decide_next_action({})
        assert action is None or isinstance(action, dict)

    def test_registration(self):
        registry = DomainRegistry.instance()
        registry.register(EducationDomain())
        assert registry.get_domain("education") is not None
