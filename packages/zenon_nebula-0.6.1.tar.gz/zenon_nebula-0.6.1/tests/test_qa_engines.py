# SPDX-License-Identifier: MIT
"""Tests for Nebula's 6 QA engines.

Covers:
  - hypothesis_hardener
  - novelty_checker
  - anomaly_detector
  - finding_verifier
  - failure_classifier
  - plausibility_gate (+ its integration with persist_finding)
"""

import os
import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

NEBULA_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NEBULA_ROOT))

os.environ.setdefault("ZENON_WORKSPACE_ROOT", os.path.expanduser("~/Repos/Zenon"))


# --- Fixtures ------------------------------------------------------------


@pytest.fixture
def fresh_db(tmp_path):
    """Create a fresh database with full schema."""
    db_path = str(tmp_path / "test.db")
    from core.persist_to_db import ensure_schema

    ensure_schema(db_path)
    return db_path


def _insert_evidence(db_path, **kwargs):
    """Helper to insert a row bypassing persist_finding's gates."""
    defaults = {
        "domain": "security",
        "engine": "test_engine",
        "evidence_type": "vulnerability",
        "finding": "WHAT: Test finding for unit testing purposes. SO WHAT: just a test. NOW WHAT: nothing.",
        "confidence": 0.8,
        "supports_hypothesis": None,
        "source_repo": "zenon-network/go-zenon",
        "source_file": "vm/embedded/implementation/test.go",
        "source_commit": "abc123def456",
    }
    defaults.update(kwargs)
    conn = sqlite3.connect(db_path)
    try:
        cur = conn.execute(
            """INSERT INTO evidence
               (domain, engine, evidence_type, finding, confidence,
                supports_hypothesis, source_repo, source_file, source_commit,
                timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                defaults["domain"],
                defaults["engine"],
                defaults["evidence_type"],
                defaults["finding"],
                defaults["confidence"],
                defaults["supports_hypothesis"],
                defaults["source_repo"],
                defaults["source_file"],
                defaults["source_commit"],
                defaults.get("timestamp", datetime.now(timezone.utc).isoformat()),
            ),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def _insert_hypothesis(db_path, hid, title, confidence, domain="security"):
    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            """INSERT OR REPLACE INTO hypotheses
               (id, domain, title, confidence, status, evidence_for, evidence_against)
               VALUES (?, ?, ?, ?, 'INVESTIGATING', '[]', '[]')""",
            (hid, domain, title, confidence),
        )
        conn.commit()
    finally:
        conn.close()


# =========================================================================
# hypothesis_hardener
# =========================================================================


class TestHypothesisHardener:
    def test_harden_no_hypotheses(self, fresh_db):
        from core.hypothesis_hardener import harden_all

        report = harden_all(fresh_db, persist=False)
        assert report.hypotheses_checked == 0
        assert report.fragile_count == 0

    def test_harden_skips_low_confidence(self, fresh_db):
        """Hypotheses below threshold are not hardened."""
        from core.hypothesis_hardener import harden_all

        _insert_hypothesis(fresh_db, "H_low", "Low conf", 0.3)
        report = harden_all(fresh_db, persist=False)
        assert report.hypotheses_checked == 0

    def test_harden_detects_fragile_single_evidence(self, fresh_db):
        """Hypothesis with only 1 supporting evidence is fragile."""
        from core.hypothesis_hardener import harden_all

        _insert_hypothesis(fresh_db, "H_frag", "Fragile", 0.85)
        _insert_evidence(fresh_db, supports_hypothesis="H_frag", confidence=0.9)
        report = harden_all(fresh_db, persist=False)
        assert report.hypotheses_checked == 1
        assert report.fragile_count == 1
        assert report.results[0].is_fragile is True

    def test_harden_detects_single_source_bias(self, fresh_db):
        """Hypothesis with all evidence from one engine is biased."""
        from core.hypothesis_hardener import harden_all

        _insert_hypothesis(fresh_db, "H_bias", "Biased", 0.9)
        for _ in range(3):
            _insert_evidence(
                fresh_db,
                supports_hypothesis="H_bias",
                engine="only_engine",
                confidence=0.8,
                finding=f"same engine finding {_} with enough text to pass gate",
            )
        report = harden_all(fresh_db, persist=False)
        assert report.biased_count == 1
        assert report.results[0].bias_engine == "only_engine"

    def test_harden_detects_stale_evidence(self, fresh_db):
        """Hypothesis with old evidence is flagged as stale."""
        from core.hypothesis_hardener import harden_all

        _insert_hypothesis(fresh_db, "H_stale", "Stale", 0.8)
        old_ts = (datetime.now(timezone.utc) - timedelta(days=14)).isoformat()
        for i in range(3):
            _insert_evidence(
                fresh_db,
                supports_hypothesis="H_stale",
                engine=f"engine_{i}",
                confidence=0.75,
                timestamp=old_ts,
                finding=f"old finding {i} with enough text to pass plausibility",
            )
        report = harden_all(fresh_db, persist=False)
        assert report.stale_count == 1

    def test_harden_healthy_hypothesis(self, fresh_db):
        """A hypothesis with multi-source fresh evidence is not flagged."""
        from core.hypothesis_hardener import harden_all

        _insert_hypothesis(fresh_db, "H_good", "Good", 0.85)
        for i in range(5):
            _insert_evidence(
                fresh_db,
                supports_hypothesis="H_good",
                engine=f"engine_{i}",
                confidence=0.75 + i * 0.02,
                finding=f"healthy finding #{i} with plenty of text content",
            )
        report = harden_all(fresh_db, persist=False)
        assert report.hypotheses_checked == 1
        # 5 engines, fresh evidence -- not fragile (dropping best still leaves 4)
        # not biased (multi-engine), not stale (fresh)
        r = report.results[0]
        # With 5 strong confidences, bayesian combine of remaining 4 should stay high
        assert r.single_source_bias is False
        assert r.stale_evidence is False


# =========================================================================
# novelty_checker
# =========================================================================


class TestNoveltyChecker:
    def test_check_novelty_empty_db(self, fresh_db):
        from core.novelty_checker import check_novelty

        result = check_novelty(
            "WHAT: Novel finding about portal reentrancy. SO WHAT: critical. NOW WHAT: fix.",
            fresh_db,
        )
        assert result.level == "novel"
        assert result.novelty_score == 1.0

    def test_check_novelty_detects_duplicate(self, fresh_db):
        from core.novelty_checker import check_novelty

        text = "WHAT: Portal reentrancy vulnerability found in bridge contract. SO WHAT: funds at risk. NOW WHAT: audit."
        _insert_evidence(fresh_db, finding=text)
        # Same text again
        result = check_novelty(text, fresh_db)
        assert result.level == "duplicate"
        assert result.novelty_score < 0.2

    def test_check_novelty_detects_novel(self, fresh_db):
        from core.novelty_checker import check_novelty

        _insert_evidence(
            fresh_db,
            finding="WHAT: upstream commit xyz in go-zenon main. SO WHAT: track. NOW WHAT: review.",
        )
        # Use text with zero keyword overlap
        result = check_novelty(
            "WHAT: quantum kyber breakthrough. SO WHAT: ok. NOW WHAT: research.",
            fresh_db,
        )
        # Should at least be more novel than duplicate
        assert result.level in ("novel", "routine")
        assert result.novelty_score > 0.3

    def test_check_batch(self, fresh_db):
        from core.novelty_checker import check_batch

        # Insert 3 duplicates and 1 novel
        dup_text = "WHAT: same bridge reentrancy issue detected. SO WHAT: test. NOW WHAT: fix."
        for _ in range(3):
            _insert_evidence(
                fresh_db,
                engine=f"e{_}",
                finding=dup_text,
            )
        _insert_evidence(
            fresh_db,
            engine="novel_engine",
            finding="WHAT: quantum cryptography totally different topic. SO WHAT: new. NOW WHAT: ?",
        )
        result = check_batch(fresh_db)
        # Dedup in DB may handle exact dupes -- at least check structure
        assert "checked" in result
        assert "novel" in result
        assert "duplicates" in result


# =========================================================================
# anomaly_detector
# =========================================================================


class TestAnomalyDetector:
    def test_detect_empty_db(self, fresh_db):
        from core.anomaly_detector import detect_anomalies

        report = detect_anomalies(fresh_db)
        assert len(report.anomalies) == 0

    def test_detect_burst(self, fresh_db):
        from core.anomaly_detector import detect_anomalies

        # Insert 15 findings from the same engine (> BURST_THRESHOLD of 10)
        for i in range(15):
            _insert_evidence(
                fresh_db,
                engine="burst_engine",
                finding=f"burst finding #{i} with sufficient text length to pass gate",
            )
        report = detect_anomalies(fresh_db)
        burst_anomalies = [a for a in report.anomalies if a.anomaly_type == "burst"]
        assert len(burst_anomalies) == 1
        assert burst_anomalies[0].engine == "burst_engine"

    def test_detect_silence(self, fresh_db):
        from core.anomaly_detector import detect_anomalies

        # Insert old findings from an engine, but none recent
        old_ts = (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
        for i in range(3):
            _insert_evidence(
                fresh_db,
                engine="silent_engine",
                timestamp=old_ts,
                finding=f"old finding #{i} with enough text to pass plausibility",
            )
        report = detect_anomalies(fresh_db)
        silent = [a for a in report.anomalies if a.anomaly_type == "silence"]
        assert any(a.engine == "silent_engine" for a in silent)

    def test_check_finding_anomaly_confidence_outlier(self, fresh_db):
        from core.anomaly_detector import _get_engine_stats, check_finding_anomaly

        # Seed stable engine with varied but low confidence findings
        # (need non-zero stddev for Z-score to work)
        for i in range(10):
            _insert_evidence(
                fresh_db,
                engine="stable_engine",
                confidence=0.45 + (i % 3) * 0.02,  # 0.45, 0.47, 0.49
                finding=f"stable finding #{i} with enough text to pass plausibility",
            )
        stats = _get_engine_stats(fresh_db)
        assert stats["stable_engine"]["std"] > 0
        # Now check a wildly outlier confidence
        result = check_finding_anomaly(0.99, "stable_engine", stats)
        assert result is not None
        assert result.anomaly_type == "confidence_outlier"
        assert result.z_score > 2.0


# =========================================================================
# finding_verifier
# =========================================================================


class TestFindingVerifier:
    def test_verify_nonexistent(self, fresh_db):
        from core.finding_verifier import verify_finding

        report = verify_finding(99999, fresh_db)
        assert report.exists is False
        assert report.finding_id == 99999

    def test_verify_full_provenance(self, fresh_db):
        from core.finding_verifier import verify_finding

        fid = _insert_evidence(
            fresh_db,
            source_repo="zenon-network/go-zenon",
            source_file="vm/embedded/implementation/htlc.go",
            source_commit="abc123def",
        )
        # Add reproducible_command
        conn = sqlite3.connect(fresh_db)
        conn.execute(
            "UPDATE evidence SET reproducible_command = ? WHERE id = ?",
            ("grep -n 'htlc' vm/embedded/implementation/htlc.go", fid),
        )
        conn.commit()
        conn.close()

        report = verify_finding(fid, fresh_db)
        assert report.exists
        assert report.has_source_repo
        assert report.has_source_file
        assert report.has_source_commit
        assert report.has_reproducible_command
        assert report.provenance_score == 1.0

    def test_verify_weak_provenance(self, fresh_db):
        from core.finding_verifier import verify_finding

        fid = _insert_evidence(
            fresh_db,
            source_repo="",
            source_file="",
            source_commit="",
        )
        report = verify_finding(fid, fresh_db)
        assert report.exists
        assert report.provenance_score == 0.0
        assert any("No source_repo" in i for i in report.issues)

    def test_verify_batch(self, fresh_db):
        from core.finding_verifier import verify_batch

        for i in range(3):
            _insert_evidence(
                fresh_db,
                engine=f"e{i}",
                confidence=0.8,
                finding=f"finding #{i} with plenty of text for the plausibility gate",
            )
        reports = verify_batch(fresh_db, limit=10)
        assert len(reports) >= 1


# =========================================================================
# failure_classifier
# =========================================================================


class TestFailureClassifier:
    def test_classify_bug(self):
        from core.failure_classifier import FailureType, classify_failure

        ftype, reason = classify_failure("TypeError: expected int, got str")
        assert ftype == FailureType.BUG
        assert "TypeError" in reason

    def test_classify_attribute_error(self):
        from core.failure_classifier import FailureType, classify_failure

        ftype, _ = classify_failure("AttributeError: 'NoneType' object has no attribute 'foo'")
        assert ftype == FailureType.BUG

    def test_classify_infrastructure(self):
        from core.failure_classifier import FailureType, classify_failure

        ftype, _reason = classify_failure("ModuleNotFoundError: No module named 'foo'")
        assert ftype == FailureType.INFRASTRUCTURE

    def test_classify_network(self):
        from core.failure_classifier import FailureType, classify_failure

        ftype, _reason = classify_failure("ConnectionError: failed to connect to host")
        assert ftype == FailureType.INFRASTRUCTURE

    def test_classify_rate_limit(self):
        from core.failure_classifier import FailureType, classify_failure

        ftype, _reason = classify_failure("HTTP 429 Too Many Requests from GitHub API")
        assert ftype == FailureType.RATE_LIMIT

    def test_classify_rate_limit_text(self):
        from core.failure_classifier import FailureType, classify_failure

        ftype, _ = classify_failure("quota exceeded for today")
        assert ftype == FailureType.RATE_LIMIT

    def test_classify_data_404(self):
        from core.failure_classifier import FailureType, classify_failure

        ftype, _reason = classify_failure("HTTP 404 Not Found: /repos/foo/bar")
        assert ftype == FailureType.DATA

    def test_classify_empty_data(self):
        from core.failure_classifier import FailureType, classify_failure

        ftype, _ = classify_failure("empty response from server")
        assert ftype == FailureType.DATA

    def test_classify_empty_message(self):
        from core.failure_classifier import FailureType, classify_failure

        ftype, _ = classify_failure("")
        assert ftype == FailureType.BUG  # default

    def test_retry_strategy(self):
        from core.failure_classifier import FailureType, get_retry_strategy

        # Rate limit should retry
        assert get_retry_strategy(FailureType.RATE_LIMIT)["retry"] is True
        # Data should not retry
        assert get_retry_strategy(FailureType.DATA)["retry"] is False
        # Bug should not retry
        assert get_retry_strategy(FailureType.BUG)["retry"] is False

    def test_classify_from_actions_log(self, fresh_db):
        from core.failure_classifier import classify_from_actions_log

        conn = sqlite3.connect(fresh_db)
        conn.execute(
            """INSERT INTO actions_log (module, action, target, error)
               VALUES (?, ?, ?, ?)""",
            ("test_engine", "scan", "repo", "HTTP 429 rate limited"),
        )
        conn.commit()
        conn.close()
        results = classify_from_actions_log(fresh_db)
        assert len(results) == 1
        assert results[0]["failure_type"] == "rate_limit"


# =========================================================================
# plausibility_gate
# =========================================================================


class TestPlausibilityGate:
    def test_plausible_finding_passes(self):
        from core.plausibility_gate import check_plausibility

        verdict = check_plausibility(
            {
                "domain": "security",
                "engine": "vuln_scanner",
                "evidence_type": "vulnerability",
                "finding": "WHAT: Portal contract has reentrancy risk. SO WHAT: funds at risk. NOW WHAT: audit.",
                "confidence": 0.85,
                "source_repo": "zenon-network/go-zenon",
            }
        )
        assert verdict.plausible is True
        assert verdict.recommendation == "persist"

    def test_empty_finding_rejected(self):
        from core.plausibility_gate import check_plausibility

        verdict = check_plausibility(
            {
                "domain": "security",
                "engine": "e",
                "evidence_type": "vulnerability",
                "finding": "",
                "confidence": 0.8,
            }
        )
        assert verdict.plausible is False
        assert verdict.recommendation == "reject"

    def test_short_finding_rejected(self):
        from core.plausibility_gate import check_plausibility

        verdict = check_plausibility(
            {
                "domain": "security",
                "engine": "e",
                "evidence_type": "vulnerability",
                "finding": "x",
                "confidence": 0.8,
            }
        )
        assert verdict.plausible is False

    def test_excessive_confidence_capped(self):
        from core.plausibility_gate import SINGLE_ENGINE_CONFIDENCE_CAP, check_plausibility

        verdict = check_plausibility(
            {
                "domain": "security",
                "engine": "e",
                "evidence_type": "vulnerability",
                "finding": "WHAT: Test finding with enough content to pass gates. SO WHAT: ok. NOW WHAT: ok.",
                "confidence": 1.0,
            }
        )
        assert verdict.plausible is True
        assert verdict.adjusted_confidence == SINGLE_ENGINE_CONFIDENCE_CAP

    def test_zero_vuln_flagged(self):
        from core.plausibility_gate import check_plausibility

        verdict = check_plausibility(
            {
                "domain": "security",
                "engine": "scanner",
                "evidence_type": "vulnerability",
                "finding": "WHAT: Scan complete. Found 0 vulnerabilities in this contract. SO WHAT: clean. NOW WHAT: done.",
                "confidence": 0.9,
            }
        )
        assert any("zero vulnerabilities" in f.lower() for f in verdict.flags)

    def test_persist_finding_rejects_implausible(self, fresh_db):
        """Integration: persist_finding should use the plausibility gate."""
        from core.persist_to_db import persist_finding

        # Empty finding should be rejected
        result = persist_finding(
            db_path=fresh_db,
            domain="security",
            engine="test",
            evidence_type="vulnerability",
            finding="",  # empty -> reject
            confidence=0.8,
        )
        assert result == -1

    def test_persist_finding_caps_confidence(self, fresh_db):
        """Integration: persist_finding should cap excessive confidence."""
        from core.persist_to_db import persist_finding

        row_id = persist_finding(
            db_path=fresh_db,
            domain="security",
            engine="test",
            evidence_type="vulnerability",
            finding="WHAT: A proper security finding with enough text. SO WHAT: ok. NOW WHAT: fix.",
            confidence=1.0,
        )
        assert row_id > 0
        # Verify it was persisted with capped confidence
        conn = sqlite3.connect(fresh_db)
        row = conn.execute(
            "SELECT confidence FROM evidence WHERE id = ?",
            (row_id,),
        ).fetchone()
        conn.close()
        assert row[0] <= 0.96  # capped at 0.95
