# SPDX-License-Identifier: MIT
"""Tests for domains.product_market_fit.domain -- Competitive analysis and adoption."""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.product_market_fit.domain import ProductMarketFitDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestProductMarketFitDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(ProductMarketFitDomain, DomainPlugin)

    def test_name(self):
        assert ProductMarketFitDomain().name() == "product_market_fit"

    def test_get_engines_non_empty(self):
        engines = ProductMarketFitDomain().get_engines()
        assert len(engines) >= 2
        names = [e.name for e in engines]
        assert "landscape_scanner" in names

    def test_get_hypothesis_types_non_empty(self):
        types = ProductMarketFitDomain().get_hypothesis_types()
        assert len(types) >= 1

    def test_get_aspiration_types(self):
        assert isinstance(ProductMarketFitDomain().get_aspiration_types(), list)

    def test_get_collision_signals(self):
        assert isinstance(ProductMarketFitDomain().get_collision_signals(), list)

    def test_get_war_room_contributions(self):
        assert isinstance(ProductMarketFitDomain().get_war_room_contributions(), list)

    def test_get_self_improvement_metrics(self):
        metrics = ProductMarketFitDomain().get_self_improvement_metrics()
        assert isinstance(metrics, dict)

    def test_get_db_schema_sql(self):
        sql = ProductMarketFitDomain().get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action(self):
        action = ProductMarketFitDomain().decide_next_action({})
        assert action is None or isinstance(action, dict)


class TestLandscapeScannerCaching:
    """Regression: landscape_scanner must TTL-cache to avoid GitHub rate limit."""

    def test_cache_hit_skips_network(self, db_path):
        """A fresh competitive_landscape row must prevent any network call."""
        import sqlite3
        from unittest.mock import patch

        from domains.product_market_fit.engines.landscape_scanner import (
            COMPETITORS,
            run_competitive_scan,
        )

        # Seed every competitor with a fresh row.
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS competitive_landscape (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    project_name TEXT NOT NULL,
                    category TEXT DEFAULT 'btc_l2',
                    github_stars INTEGER DEFAULT 0,
                    github_contributors INTEGER DEFAULT 0,
                    commits_30d INTEGER DEFAULT 0,
                    market_cap_usd REAL DEFAULT 0.0,
                    tvl_usd REAL DEFAULT 0.0,
                    unique_features TEXT,
                    threat_level TEXT DEFAULT 'low',
                    notes TEXT
                )"""
            )
            for competitor in COMPETITORS:
                conn.execute(
                    "INSERT INTO competitive_landscape "
                    "(project_name, category, github_stars, github_contributors, "
                    "commits_30d, threat_level) VALUES (?, ?, ?, ?, ?, ?)",
                    (competitor["name"], competitor["category"], 100, 5, 10, "low"),
                )
            conn.commit()
        finally:
            conn.close()

        with patch(
            "domains.product_market_fit.engines.landscape_scanner.opsec_urlopen"
        ) as mock_http:
            result = run_competitive_scan(db_path=db_path)

        # Cache hit for every competitor → zero HTTP calls.
        assert mock_http.call_count == 0, (
            f"Expected zero network calls with fresh cache, got {mock_http.call_count}"
        )
        assert result["cached_hits"] == len(COMPETITORS)
        assert result["success"] is True

    def test_stale_cache_triggers_fetch(self, db_path):
        """A stale (>6h) row must trigger a fetch."""
        import sqlite3
        from unittest.mock import MagicMock, patch

        from domains.product_market_fit.engines.landscape_scanner import (
            COMPETITORS,
            run_competitive_scan,
        )

        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS competitive_landscape (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    project_name TEXT NOT NULL,
                    category TEXT DEFAULT 'btc_l2',
                    github_stars INTEGER DEFAULT 0,
                    github_contributors INTEGER DEFAULT 0,
                    commits_30d INTEGER DEFAULT 0,
                    market_cap_usd REAL DEFAULT 0.0,
                    tvl_usd REAL DEFAULT 0.0,
                    unique_features TEXT,
                    threat_level TEXT DEFAULT 'low',
                    notes TEXT
                )"""
            )
            # Insert a row dated 24h ago — well outside the 6h TTL.
            for competitor in COMPETITORS:
                conn.execute(
                    "INSERT INTO competitive_landscape "
                    "(timestamp, project_name, category, github_stars) "
                    "VALUES (datetime('now', '-24 hours'), ?, ?, ?)",
                    (competitor["name"], competitor["category"], 50),
                )
            conn.commit()
        finally:
            conn.close()

        # Mock urlopen to return empty repo metadata without hitting network.
        def fake_urlopen(*args, **kwargs):
            ctx = MagicMock()
            ctx.__enter__ = MagicMock(return_value=MagicMock(read=lambda: b"{}"))
            ctx.__exit__ = MagicMock(return_value=False)
            return ctx

        with patch(
            "domains.product_market_fit.engines.landscape_scanner.opsec_urlopen",
            side_effect=fake_urlopen,
        ) as mock_http:
            result = run_competitive_scan(db_path=db_path)

        assert mock_http.call_count > 0, "Stale cache should trigger network fetch"
        assert result["cached_hits"] == 0

    def test_registration(self):
        registry = DomainRegistry.instance()
        registry.register(ProductMarketFitDomain())
        assert registry.get_domain("product_market_fit") is not None
