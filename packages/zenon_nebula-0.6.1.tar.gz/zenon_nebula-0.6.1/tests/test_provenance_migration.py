# SPDX-License-Identifier: MIT
"""Tests for provenance column in evidence table (Gap 3 fix)."""

import os
import sqlite3
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.persist_to_db import ensure_schema, persist_finding


@pytest.fixture
def db_path():
    """Create a temporary database."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    yield path
    os.unlink(path)


class TestProvenanceColumn:
    """Verify the provenance column exists and is populated."""

    def test_schema_creates_provenance_column(self, db_path):
        ensure_schema(db_path)
        conn = sqlite3.connect(db_path)
        columns = {row[1] for row in conn.execute("PRAGMA table_info(evidence)").fetchall()}
        conn.close()
        assert "provenance" in columns

    def test_persist_finding_stores_provenance(self, db_path):
        ensure_schema(db_path)
        fid = persist_finding(
            db_path=db_path,
            engine="test",
            evidence_type="test",
            finding="test finding",
            confidence=0.5,
        )
        conn = sqlite3.connect(db_path)
        row = conn.execute("SELECT provenance FROM evidence WHERE id = ?", (fid,)).fetchone()
        conn.close()
        # No fingerprints -> provenance should be "hypothesis"
        assert row[0] == "hypothesis"

    def test_persist_finding_with_api_fingerprints(self, db_path):
        ensure_schema(db_path)
        fingerprints = [{"url": "https://api.example.com", "status_code": 200}]
        fid = persist_finding(
            db_path=db_path,
            engine="test",
            evidence_type="test",
            finding="api verified finding",
            confidence=0.8,
            fingerprints=fingerprints,
        )
        conn = sqlite3.connect(db_path)
        row = conn.execute("SELECT provenance FROM evidence WHERE id = ?", (fid,)).fetchone()
        conn.close()
        assert row[0] == "verified_by_api"

    def test_migration_adds_column_to_existing_db(self, db_path):
        """Simulate an old DB without provenance column, then migrate."""
        conn = sqlite3.connect(db_path)
        # Create table WITHOUT provenance column (old schema)
        conn.execute("""
            CREATE TABLE evidence (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                domain TEXT NOT NULL DEFAULT 'system',
                engine TEXT,
                evidence_type TEXT,
                finding TEXT,
                confidence REAL DEFAULT 0.0,
                supports_hypothesis TEXT,
                contradicts_hypothesis TEXT,
                verification_url TEXT,
                raw_data TEXT,
                published BOOLEAN DEFAULT FALSE,
                run_id TEXT,
                parent_finding_id INTEGER
            )
        """)
        conn.commit()
        # Insert a row without provenance
        conn.execute(
            "INSERT INTO evidence (engine, finding) VALUES (?, ?)",
            ("old_engine", "old finding"),
        )
        conn.commit()
        conn.close()

        # Now run ensure_schema which should add provenance column
        ensure_schema(db_path)

        conn = sqlite3.connect(db_path)
        columns = {row[1] for row in conn.execute("PRAGMA table_info(evidence)").fetchall()}
        assert "provenance" in columns

        # Old row should have default value
        row = conn.execute("SELECT provenance FROM evidence WHERE engine = 'old_engine'").fetchone()
        assert row[0] == "hypothesis"
        conn.close()
