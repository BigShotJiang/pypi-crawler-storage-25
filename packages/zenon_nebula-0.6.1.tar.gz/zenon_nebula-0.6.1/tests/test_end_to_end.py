# SPDX-License-Identifier: MIT
"""
End-to-End Integration Test — The A+ test.

Starts Nebula, runs cycles, verifies:
1. All 17 domains register
2. Multiple actions per cycle (not deadlock)
3. Evidence accumulates from multiple domains
4. War Room produces a battle plan
5. Cost tracking records LLM spend
6. Collision detection finds cross-domain convergence
7. Knowledge graph builds with nodes and edges
8. Self-improver generates a report
9. No crashes through entire run

This test uses real workspace data but mock LLM calls
to avoid API costs during testing.
"""

import json
import os
import sqlite3
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

NEBULA_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NEBULA_ROOT))

os.environ.setdefault("ZENON_WORKSPACE_ROOT", os.path.expanduser("~/Repos/Zenon"))


@pytest.fixture
def fresh_db(tmp_path):
    """Create a fresh database for the test."""
    db_path = str(tmp_path / "test_e2e.db")
    from core.persist_to_db import ensure_schema

    ensure_schema(db_path)
    return db_path


@pytest.fixture
def mock_anthropic():
    """Mock Anthropic API to avoid real LLM calls."""
    mock_response = MagicMock()
    mock_response.content = [
        MagicMock(
            type="text",
            text=json.dumps(
                {
                    "situation_assessment": "Test assessment from e2e test.",
                    "whats_working": [
                        {
                            "domain": "development",
                            "tactic": "spec tracking",
                            "evidence": "14 specs found",
                        }
                    ],
                    "whats_failing": [
                        {
                            "domain": "security",
                            "tactic": "adversarial review",
                            "recommendation": "run more reviews",
                        }
                    ],
                    "battle_plan_24h": {
                        "focus": "testing",
                        "actions": ["run integration tests", "verify all domains"],
                    },
                    "resource_allocation": {
                        "development": 30,
                        "security": 20,
                        "quality": 20,
                        "intelligence": 15,
                        "other": 15,
                    },
                    "cross_domain_opportunities": [],
                }
            ),
        )
    ]
    mock_response.usage = MagicMock(input_tokens=1000, output_tokens=500)

    mock_client = MagicMock()
    mock_client.messages.create.return_value = mock_response
    return mock_client


class TestEndToEnd:
    """Full integration test — the A+ bar."""

    def test_all_domains_register(self):
        """All 17 domains must register without errors."""
        import importlib

        from core.domain_registry import DomainRegistry

        DomainRegistry.reset()
        registry = DomainRegistry.instance()

        domains_dir = NEBULA_ROOT / "domains"
        registered = []
        failed = []

        for domain_dir in sorted(domains_dir.iterdir()):
            if not domain_dir.is_dir() or domain_dir.name.startswith("_"):
                continue
            if not (domain_dir / "domain.py").exists():
                continue

            try:
                mod = importlib.import_module(f"domains.{domain_dir.name}.domain")
                for attr_name in dir(mod):
                    attr = getattr(mod, attr_name)
                    if (
                        isinstance(attr, type)
                        and hasattr(attr, "get_engines")
                        and attr_name not in ("DomainPlugin", "ABC")
                    ):
                        try:
                            instance = attr()
                            registry.register(instance)
                            registered.append(domain_dir.name)
                            break
                        except Exception as e:
                            failed.append((domain_dir.name, str(e)))
            except Exception as e:
                failed.append((domain_dir.name, str(e)))

        assert len(registered) == 17, (
            f"Expected 17 domains, got {len(registered)}. Failed: {failed}"
        )
        assert len(failed) == 0, f"Domain registration failures: {failed}"

    def test_engines_have_content(self):
        """Every registered domain must have at least 1 engine."""
        from core.domain_registry import DomainRegistry

        DomainRegistry.reset()
        registry = DomainRegistry.instance()

        # Register all domains
        import importlib

        for d in (NEBULA_ROOT / "domains").iterdir():
            if d.is_dir() and (d / "domain.py").exists() and not d.name.startswith("_"):
                try:
                    mod = importlib.import_module(f"domains.{d.name}.domain")
                    for attr in dir(mod):
                        cls = getattr(mod, attr)
                        if (
                            isinstance(cls, type)
                            and hasattr(cls, "get_engines")
                            and attr not in ("DomainPlugin", "ABC")
                        ):
                            try:
                                registry.register(cls())
                                break
                            except Exception:
                                pass
                except Exception:
                    pass

        for domain in registry.get_all_domains():
            engines = domain.get_engines()
            assert len(engines) > 0, f"Domain '{domain.name}' has 0 engines"

    def test_spec_tracker_produces_real_data(self, fresh_db):
        """Spec tracker must find actual specs in the workspace."""
        workspace = os.environ.get("ZENON_WORKSPACE_ROOT", "")
        if not workspace or not Path(workspace).exists():
            pytest.skip("No workspace available")

        from domains.development.engines.spec_tracker import scan_all_specs

        specs = scan_all_specs()
        assert len(specs) >= 10, f"Expected 10+ specs, found {len(specs)}"

    def test_upstream_watcher_detects_commits(self, fresh_db):
        """Upstream watcher must detect commits in real repos."""
        workspace = os.environ.get("ZENON_WORKSPACE_ROOT", "")
        go_zenon = Path(workspace) / "core" / "go-zenon"
        if not go_zenon.exists():
            pytest.skip("go-zenon not available")

        from domains.intelligence.engines.upstream_watcher import scan_repo

        commits = scan_repo("go-zenon", str(go_zenon))
        assert isinstance(commits, list), "scan_repo should return a list"

    def test_collision_engine_detects_convergence(self, fresh_db):
        """Collision engine must detect convergence from seeded data."""
        conn = sqlite3.connect(fresh_db)
        # Seed evidence from multiple engines supporting same hypothesis
        for engine in ["engine1", "engine2", "engine3"]:
            conn.execute(
                "INSERT INTO evidence (domain, engine, finding, confidence, supports_hypothesis) VALUES (?, ?, ?, ?, ?)",
                ("test", engine, f"Finding from {engine} supports H001", 0.8, "H001"),
            )
        conn.execute(
            "INSERT INTO hypotheses (id, domain, title, confidence, status) VALUES (?, ?, ?, ?, ?)",
            ("H001", "test", "Test hypothesis", 0.5, "INVESTIGATING"),
        )
        conn.commit()
        conn.close()

        from core.collision_engine import CollisionEngine
        from core.domain_registry import DomainRegistry

        DomainRegistry.reset()
        ce = CollisionEngine(db_path=fresh_db)
        collisions = ce.detect_collisions(DomainRegistry.instance())
        assert len(collisions) >= 1, (
            "Expected at least 1 collision from 3 engines supporting same hypothesis"
        )

    def test_knowledge_graph_builds(self, fresh_db):
        """Knowledge graph must build with nodes and edges."""
        conn = sqlite3.connect(fresh_db)
        for i in range(5):
            conn.execute(
                "INSERT INTO evidence (domain, engine, finding, confidence) VALUES (?, ?, ?, ?)",
                ("test", f"engine{i}", f"Finding {i}", 0.5 + i * 0.1),
            )
        conn.execute(
            "INSERT INTO hypotheses (id, domain, title, confidence, status) VALUES (?, ?, ?, ?, ?)",
            ("H001", "test", "Test", 0.5, "INVESTIGATING"),
        )
        conn.commit()
        conn.close()

        from core.knowledge_graph import KnowledgeGraph

        kg = KnowledgeGraph(db_path=fresh_db)
        kg.build()
        summary_text = kg.export_summary()
        assert len(summary_text) > 0, "Knowledge graph has no nodes"
        assert "node" in summary_text.lower() or len(summary_text) > 10, (
            "Knowledge graph edges should be non-negative"
        )

    def test_mcp_tools_respond(self, fresh_db):
        """All 8 MCP tools must respond without errors."""
        # Seed some data
        conn = sqlite3.connect(fresh_db)
        conn.execute(
            "INSERT INTO evidence (domain, engine, finding, confidence) VALUES ('test', 'e', 'f', 0.5)"
        )
        conn.execute(
            "INSERT INTO hypotheses (id, domain, title, confidence, status) VALUES ('H1', 'test', 't', 0.5, 'INVESTIGATING')"
        )
        conn.commit()
        conn.close()

        # Monkey-patch DB path
        import scripts.mcp_server as mcp
        from scripts.mcp_server import handle_tool_call

        original_db = mcp.DB_PATH
        mcp.DB_PATH = Path(fresh_db)

        try:
            tools = [
                ("nebula_status", {}),
                ("nebula_spec_coverage", {}),
                ("nebula_security_findings", {}),
                ("nebula_battle_plan", {}),
                ("nebula_upstream_signals", {}),
                ("nebula_aspirations", {}),
                ("nebula_collisions", {}),
                ("nebula_query", {"sql": "SELECT COUNT(*) FROM evidence"}),
            ]

            for tool_name, args in tools:
                result = handle_tool_call(tool_name, args)
                parsed = json.loads(result)
                # STRICT: any error response is a failure. The previous
                # version of this assertion was too loose ("no such" in
                # error message) and silently passed the
                # `name 'os' is not defined` NameError that the
                # _sanitize_result helper was raising on every call.
                # Every MCP tool was returning an error dict between
                # v0.2.11 and v0.2.17.
                assert "error" not in parsed, f"MCP tool {tool_name} returned error: {parsed}"
        finally:
            mcp.DB_PATH = original_db

    def test_sync_from_url_routes_through_opsec(self, fresh_db, tmp_path, monkeypatch):
        """Regression: sync_from_url MUST use opsec_urlopen, never raw urlretrieve.

        Pre-v0.2.14 sync_from_url used urllib.request.urlretrieve, which
        sends the default ``Python-urllib/3.x`` User-Agent — a unique
        fingerprint that would link every sync request from the same
        operator back to a Nebula instance. This test asserts the
        opsec_urlopen wrapper is the one making the call.
        """
        import gzip
        import json
        from unittest.mock import MagicMock, patch

        from core.sync import sync_from_url

        monkeypatch.setenv("NEBULA_SNAPSHOT_URL", "https://example.com/snap.json.gz")

        # Build a minimal valid snapshot payload so import_snapshot doesn't crash.
        payload = {
            "version": 1,
            "exported_at": "2026-04-10T00:00:00+00:00",
            "evidence_height": 0,
            "evidence_count": 0,
            "hypotheses_count": 0,
            "excluded_domains": [],
            "evidence": [],
            "hypotheses": [],
        }
        body = gzip.compress(json.dumps(payload).encode())

        resp_ctx = MagicMock()
        resp_ctx.__enter__ = MagicMock(
            return_value=MagicMock(read=lambda: body, __iter__=lambda s: iter([body]))
        )
        resp_ctx.__exit__ = MagicMock(return_value=False)

        # Fake shutil.copyfileobj so it writes the body to the out file.
        def fake_copyfileobj(src, dst):
            dst.write(body)

        with (
            patch("core.sync.opsec_urlopen", return_value=resp_ctx) as mock_opsec,
            patch("core.sync.shutil.copyfileobj", side_effect=fake_copyfileobj),
        ):
            result = sync_from_url(fresh_db)

        assert mock_opsec.call_count == 1, (
            "sync_from_url must route downloads through opsec_urlopen"
        )
        assert "error" not in result

    def test_sync_from_url_survives_tempfile_failure(self, fresh_db, monkeypatch):
        """Regression: if NamedTemporaryFile raises, finally must not UnboundLocalError.

        The old code initialized tmp_path inside the try, so a failure
        before the assignment would trigger UnboundLocalError in the
        finally unlink and mask the real error.
        """
        from unittest.mock import patch

        from core.sync import sync_from_url

        monkeypatch.setenv("NEBULA_SNAPSHOT_URL", "https://example.com/snap.json.gz")

        def boom(*args, **kwargs):
            raise OSError("disk full (simulated)")

        with patch("core.sync.tempfile.NamedTemporaryFile", side_effect=boom):
            result = sync_from_url(fresh_db)

        # Must return a dict with the original error, not crash with
        # UnboundLocalError from the finally block.
        assert "error" in result
        assert "disk full" in result["error"]

    def test_evidence_sync_roundtrip(self, fresh_db, tmp_path):
        """Export snapshot, import to fresh DB, verify data matches."""
        # Seed evidence
        conn = sqlite3.connect(fresh_db)
        for i in range(10):
            conn.execute(
                "INSERT INTO evidence (domain, engine, finding, confidence) VALUES (?, ?, ?, ?)",
                ("development", f"engine{i}", f"Finding {i}", 0.5 + i * 0.05),
            )
        conn.execute(
            "INSERT INTO hypotheses (id, domain, title, confidence, status) VALUES ('H1', 'dev', 'Test', 0.7, 'OK')"
        )
        conn.commit()
        conn.close()

        from core.sync import export_snapshot, get_evidence_height, import_snapshot

        # Export
        snapshot_path = export_snapshot(fresh_db, str(tmp_path / "snapshot.json.gz"))
        assert Path(snapshot_path).exists(), "Snapshot file not created"

        # Import to new DB
        fresh_db2 = str(tmp_path / "test_import.db")
        from core.persist_to_db import ensure_schema

        ensure_schema(fresh_db2)

        stats = import_snapshot(fresh_db2, snapshot_path)
        assert stats["evidence_imported"] > 0, "No evidence imported"

        # Verify heights match
        get_evidence_height(fresh_db)
        h2 = get_evidence_height(fresh_db2)
        assert h2 > 0, "Import DB has no evidence"

    def test_trust_model_caps_unknown_repos(self):
        """Unknown repos must be capped at low confidence."""
        from core.trust import DEFAULT_TRUST, cap_confidence_by_trust

        capped = cap_confidence_by_trust(0.99, "/some/unknown/repo")
        assert capped <= DEFAULT_TRUST, (
            f"Unknown repo confidence {capped} exceeds default trust {DEFAULT_TRUST}"
        )

    def test_opsec_sanitizes_paths(self):
        """OPSEC guard must strip local paths."""
        from core.opsec import OPSECGuard

        text = "File at /Users/john/Projects/secret.py has issues"
        result = OPSECGuard.sanitize_prompt(text)
        assert "/Users/john" not in result, f"Local path not sanitized: {result}"

    def test_validation_spiral_tiers(self, fresh_db):
        """Validation spiral must promote findings through tiers."""
        from core.validation_spiral import check_tier_requirements, register_finding

        # Register a finding
        result = register_finding(finding_id=1, db_path=fresh_db)
        assert result is not None

        reqs = check_tier_requirements(1, target_tier=2, db_path=fresh_db)
        assert reqs is not None, "check_tier_requirements returned None"

    def test_red_team_challenges_hypotheses(self, fresh_db):
        """Red team must generate challenges for high-confidence hypotheses."""
        conn = sqlite3.connect(fresh_db)
        conn.execute(
            "INSERT INTO hypotheses (id, domain, title, confidence, status) VALUES (?, ?, ?, ?, ?)",
            ("H1", "test", "This hypothesis is very confident", 0.9, "COMPELLING"),
        )
        conn.execute(
            "INSERT INTO evidence (domain, engine, finding, confidence, supports_hypothesis) VALUES (?, ?, ?, ?, ?)",
            ("test", "engine1", "Supporting evidence", 0.8, "H1"),
        )
        conn.commit()
        conn.close()

        from core.red_team import challenge_hypotheses

        def mock_llm(prompt, **kwargs):
            return "STRONG challenge: This hypothesis has weak causal evidence. Alternative explanation: coincidence."

        challenges = challenge_hypotheses(fresh_db, llm_call=mock_llm)
        assert len(challenges) >= 1, "Red team produced no challenges"
        assert challenges[0]["strength"] in ("WEAK", "MODERATE", "STRONG"), (
            f"Invalid strength: {challenges[0]['strength']}"
        )
