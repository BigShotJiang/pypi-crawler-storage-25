# SPDX-License-Identifier: MIT
"""Tests for domains.investigation.domain -- Architecture and vision analysis."""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.investigation.domain import InvestigationDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestInvestigationDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(InvestigationDomain, DomainPlugin)

    def test_name(self):
        assert InvestigationDomain().name() == "investigation"

    def test_get_engines_non_empty(self):
        engines = InvestigationDomain().get_engines()
        assert len(engines) >= 1
        names = [e.name for e in engines]
        assert "architecture_analyzer" in names

    def test_get_hypothesis_types_non_empty(self):
        types = InvestigationDomain().get_hypothesis_types()
        assert len(types) >= 1

    def test_get_aspiration_types(self):
        assert isinstance(InvestigationDomain().get_aspiration_types(), list)

    def test_get_collision_signals(self):
        assert isinstance(InvestigationDomain().get_collision_signals(), list)

    def test_get_war_room_contributions(self):
        assert isinstance(InvestigationDomain().get_war_room_contributions(), list)

    def test_get_self_improvement_metrics(self):
        metrics = InvestigationDomain().get_self_improvement_metrics()
        assert isinstance(metrics, dict)

    def test_get_db_schema_sql(self):
        sql = InvestigationDomain().get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action(self):
        action = InvestigationDomain().decide_next_action({})
        assert action is None or isinstance(action, dict)

    def test_registration(self):
        registry = DomainRegistry.instance()
        registry.register(InvestigationDomain())
        assert registry.get_domain("investigation") is not None
