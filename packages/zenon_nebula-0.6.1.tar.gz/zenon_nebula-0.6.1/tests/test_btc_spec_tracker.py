# SPDX-License-Identifier: MIT
"""Tests for domains.development.engines.btc_spec_tracker."""

from __future__ import annotations

from pathlib import Path

from core.persistence.metrics import persist_metric, query_table
from domains.development.engines import btc_spec_tracker as tracker


def _insert_workspace_repo(
    db_path: str,
    repo_name: str,
    repo_path: Path,
    repo_type: str,
) -> None:
    """Seed a single ``workspace_repos`` row for tests."""
    persist_metric(
        db_path=db_path,
        table="workspace_repos",
        data={
            "repo_name": repo_name,
            "repo_path": str(repo_path),
            "repo_type": repo_type,
            "languages": "[]",
            "has_ci": 0,
            "has_tests": 0,
            "classified_at": "2026-04-10T00:00:00+00:00",
        },
    )


def test_module_import_smoke():
    """Entry point and scheduler alias both exported."""
    assert callable(tracker.track_btc_specs)
    assert callable(tracker.scan_btc_specs)


def test_empty_workspace_returns_empty(db_path):
    """No Bitcoin reference chain in catalog -> empty dict."""
    result = tracker.track_btc_specs(db_path=db_path)
    assert result == {}


def test_with_fake_workspace_no_bips(fake_workspace, db_path):
    """fake_workspace has no BTC reference repo -> empty dict."""
    result = tracker.track_btc_specs(db_path=db_path)
    assert result == {}


def test_detects_bips_without_zip(tmp_path, db_path):
    """Populated Bitcoin repo with BIPs but no ZIP counterparts emits findings."""
    bitcoin = tmp_path / "bitcoin"
    bitcoin.mkdir()
    bips = bitcoin / "bips"
    bips.mkdir()
    (bips / "bip-0032.md").write_text("# BIP 32: HD Wallets\n")
    (bips / "bip-0141.md").write_text("# BIP 141: SegWit\n")
    _insert_workspace_repo(
        db_path,
        "bitcoin",
        bitcoin,
        "blockchain_node_btc",
    )

    # Empty knowledge/developer-commons (no ZIPs).
    result = tracker.track_btc_specs(db_path=db_path)
    assert result.get("bips") == 2
    assert result.get("unmatched") == 2
    assert result.get("findings", 0) >= 2

    rows = query_table(
        db_path=db_path,
        table="evidence",
        where="engine = ?",
        params=("btc_spec_tracker",),
        limit=10,
    )
    assert rows
    joined = " ".join(r.get("finding") or "" for r in rows)
    assert "BIP-32" in joined or "BIP-141" in joined


def test_matching_zip_suppresses_finding(tmp_path, db_path):
    """When a ZIP with the same number exists, no finding is emitted."""
    bitcoin = tmp_path / "bitcoin"
    bitcoin.mkdir()
    (bitcoin / "bips").mkdir()
    (bitcoin / "bips" / "bip-0001.md").write_text("# BIP 1\n")
    _insert_workspace_repo(
        db_path,
        "bitcoin",
        bitcoin,
        "blockchain_node_btc",
    )

    dev_commons = tmp_path / "developer-commons"
    (dev_commons / "docs" / "specs").mkdir(parents=True)
    (dev_commons / "docs" / "specs" / "zip-0001.md").write_text("# ZIP 1\n")
    _insert_workspace_repo(
        db_path,
        "developer-commons",
        dev_commons,
        "specs",
    )

    result = tracker.track_btc_specs(db_path=db_path)
    assert result.get("bips") == 1
    # BIP 1 is matched to ZIP 1, so unmatched should be zero.
    assert result.get("unmatched") == 0
    assert result.get("findings", 0) == 0
