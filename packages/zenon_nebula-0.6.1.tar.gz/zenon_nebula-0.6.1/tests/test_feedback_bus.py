# SPDX-License-Identifier: MIT
"""Tests for core.feedback_bus -- SQLite-backed inter-agent message queue."""

import pytest

from core.feedback_bus import FeedbackBus


@pytest.fixture
def bus(tmp_path):
    """Create a FeedbackBus with a temp DB."""
    return FeedbackBus(db_path=str(tmp_path / "bus.db"))


class TestPost:
    def test_returns_message_id(self, bus):
        msg_id = bus.post("sender", "recipient", "finding", {"score": 0.9})
        assert isinstance(msg_id, str)
        assert len(msg_id) == 8

    def test_unknown_type_still_posts(self, bus):
        msg_id = bus.post("s", "r", "totally_fake_type", {})
        assert msg_id  # warns but posts anyway

    def test_domain_tag(self, bus):
        bus.post("s", "r", "finding", {"x": 1}, domain="marketing")
        messages = bus.read("r", domain="marketing")
        assert len(messages) == 1
        assert messages[0]["domain"] == "marketing"


class TestRead:
    def test_read_pending_messages(self, bus):
        bus.post("engine_a", "engine_b", "finding", {"val": 1})
        bus.post("engine_a", "engine_b", "question", {"q": "why?"})
        messages = bus.read("engine_b")
        assert len(messages) == 2

    def test_read_includes_broadcast(self, bus):
        bus.post("sender", "all", "signal", {"alert": True})
        messages = bus.read("any_recipient")
        assert len(messages) == 1

    def test_read_ignores_other_recipients(self, bus):
        bus.post("s", "target_a", "finding", {})
        messages = bus.read("target_b")
        assert len(messages) == 0

    def test_domain_filter(self, bus):
        bus.post("s", "r", "finding", {}, domain="intel")
        bus.post("s", "r", "finding", {}, domain="marketing")
        intel_msgs = bus.read("r", domain="intel")
        assert len(intel_msgs) == 1
        assert intel_msgs[0]["domain"] == "intel"

    def test_data_is_parsed_dict(self, bus):
        bus.post("s", "r", "finding", {"nested": {"key": "val"}})
        messages = bus.read("r")
        assert isinstance(messages[0]["data"], dict)
        assert messages[0]["data"]["nested"]["key"] == "val"


class TestAcknowledge:
    def test_acknowledge_removes_from_pending(self, bus):
        msg_id = bus.post("s", "r", "finding", {})
        assert bus.acknowledge(msg_id, acknowledged_by="test")
        messages = bus.read("r")
        assert len(messages) == 0

    def test_acknowledge_nonexistent_returns_false(self, bus):
        assert not bus.acknowledge("nonexistent")

    def test_double_acknowledge_returns_false(self, bus):
        msg_id = bus.post("s", "r", "finding", {})
        assert bus.acknowledge(msg_id)
        assert not bus.acknowledge(msg_id)

    def test_acknowledge_all(self, bus):
        bus.post("s", "r", "finding", {})
        bus.post("s", "r", "question", {})
        bus.post("s", "other", "finding", {})
        count = bus.acknowledge_all("r", acknowledged_by="bulk")
        assert count == 2
        assert bus.count_pending("r") == 0
        # "other" recipient's message still pending
        assert bus.count_pending("other") == 1


class TestReadByType:
    def test_filter_by_type(self, bus):
        bus.post("s", "r", "finding", {})
        bus.post("s", "r", "question", {})
        bus.post("s", "r", "finding", {})
        findings = bus.read_by_type("r", "finding")
        assert len(findings) == 2
        questions = bus.read_by_type("r", "question")
        assert len(questions) == 1


class TestHistory:
    def test_history_includes_acknowledged(self, bus):
        msg_id = bus.post("s", "r", "finding", {})
        bus.acknowledge(msg_id)
        bus.post("s", "r", "question", {})
        history = bus.get_history(limit=10)
        assert len(history) == 2

    def test_history_domain_filter(self, bus):
        bus.post("s", "r", "finding", {}, domain="a")
        bus.post("s", "r", "finding", {}, domain="b")
        history = bus.get_history(domain="a")
        assert len(history) == 1


class TestCountPending:
    def test_count_all_pending(self, bus):
        bus.post("s", "r1", "finding", {})
        bus.post("s", "r2", "finding", {})
        assert bus.count_pending() == 2

    def test_count_for_recipient(self, bus):
        bus.post("s", "r1", "finding", {})
        bus.post("s", "r2", "finding", {})
        assert bus.count_pending("r1") == 1


class TestPruning:
    def test_pruning_removes_old_acknowledged(self, bus, tmp_path, monkeypatch):
        """When messages exceed MAX_MESSAGES, acknowledged ones get pruned."""
        # Lower the limit for testing
        import core.feedback_bus as fb_mod

        monkeypatch.setattr(fb_mod, "MAX_MESSAGES", 10)

        # Create a fresh bus with the patched limit
        test_bus = FeedbackBus(db_path=str(tmp_path / "prune.db"))

        # Post and acknowledge 15 messages
        for i in range(15):
            mid = test_bus.post("s", "r", "finding", {"i": i})
            test_bus.acknowledge(mid)

        # Post one more to trigger pruning
        test_bus.post("s", "r", "finding", {"trigger": True})

        history = test_bus.get_history(limit=100)
        # Should have been pruned down; total should be <= MAX_MESSAGES + some slack
        assert len(history) <= 16
