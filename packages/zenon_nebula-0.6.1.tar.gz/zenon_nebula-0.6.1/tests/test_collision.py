# SPDX-License-Identifier: MIT
"""
Tests for core.collision_engine -- Cross-domain convergence detection.

Uses a temporary SQLite database with real schema and test data
to validate collision detection, signal checking, flywheel patterns,
and persistence.
"""

import sqlite3
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.collision_engine import Collision, CollisionEngine
from core.domain_registry import DomainRegistry
from core.persist_to_db import ensure_schema


@pytest.fixture
def db_path(tmp_path):
    """Create a temporary database with convergent evidence."""
    db = str(tmp_path / "test_engine.db")
    ensure_schema(db)

    conn = sqlite3.connect(db)

    # Hypothesis supported by multiple engines/domains
    conn.execute(
        "INSERT INTO hypotheses (id, domain, title, confidence, status) "
        "VALUES ('H_CONV', 'security', 'Fund lock in htlc', 0.8, "
        "'INVESTIGATING')"
    )

    # Evidence from security domain supporting H_CONV
    conn.execute(
        "INSERT INTO evidence (domain, engine, evidence_type, finding, "
        "confidence, supports_hypothesis) VALUES "
        "('security', 'adversarial_reviewer', 'vuln', "
        "'Fund lock path confirmed', 0.85, 'H_CONV')"
    )
    # Evidence from quality domain supporting H_CONV
    conn.execute(
        "INSERT INTO evidence (domain, engine, evidence_type, finding, "
        "confidence, supports_hypothesis) VALUES "
        "('quality', 'spec_verifier', 'abi', "
        "'ABI mismatch in htlc contract', 0.75, 'H_CONV')"
    )
    # Evidence from development domain supporting H_CONV
    conn.execute(
        "INSERT INTO evidence (domain, engine, evidence_type, finding, "
        "confidence, supports_hypothesis) VALUES "
        "('development', 'impl_coverage', 'gap', "
        "'htlc impl missing safety check', 0.65, 'H_CONV')"
    )

    # A non-convergent hypothesis (only 1 engine)
    conn.execute(
        "INSERT INTO hypotheses (id, domain, title, confidence, status) "
        "VALUES ('H_SINGLE', 'intelligence', 'Trend detected', 0.3, "
        "'INVESTIGATING')"
    )
    conn.execute(
        "INSERT INTO evidence (domain, engine, evidence_type, finding, "
        "confidence, supports_hypothesis) VALUES "
        "('intelligence', 'upstream_watcher', 'commit', "
        "'New commit detected', 0.5, 'H_SINGLE')"
    )

    conn.commit()
    conn.close()
    return db


class TestConvergentHypotheses:
    """Test multi-engine hypothesis convergence."""

    def test_detects_convergent(self, db_path):
        engine = CollisionEngine(db_path=db_path)
        convergent = engine.get_convergent_hypotheses()

        assert len(convergent) >= 1
        # H_CONV should be convergent (3 engines)
        h_conv = [h for h in convergent if h["hypothesis_id"] == "H_CONV"]
        assert len(h_conv) == 1
        assert h_conv[0]["engine_count"] >= 2
        assert h_conv[0]["convergent"] is True

    def test_non_convergent_excluded(self, db_path):
        engine = CollisionEngine(db_path=db_path)
        convergent = engine.get_convergent_hypotheses()

        # H_SINGLE should NOT appear (only 1 engine)
        h_single = [h for h in convergent if h["hypothesis_id"] == "H_SINGLE"]
        assert len(h_single) == 0

    def test_domains_involved(self, db_path):
        engine = CollisionEngine(db_path=db_path)
        convergent = engine.get_convergent_hypotheses()

        h_conv = [h for h in convergent if h["hypothesis_id"] == "H_CONV"]
        domains = set(h_conv[0]["domains_involved"])
        assert "security" in domains
        assert "quality" in domains


class TestCollisionDetection:
    """Test full collision detection pipeline."""

    def test_detect_collisions(self, db_path):
        engine = CollisionEngine(db_path=db_path)
        collisions = engine.detect_collisions()

        assert len(collisions) >= 1
        # Top collision should be H_CONV
        top = collisions[0]
        assert top.convergent is True
        assert top.engine_count >= 2

    def test_collision_persistence(self, db_path):
        engine = CollisionEngine(db_path=db_path)
        engine.detect_collisions()

        # Should be persisted
        active = engine.get_active_collisions()
        assert len(active) >= 1

    def test_collision_actions_generated(self, db_path):
        engine = CollisionEngine(db_path=db_path)
        collisions = engine.detect_collisions()

        # H_CONV has confidence 0.8 and security domain
        # Should generate at least alert + block_pr
        conv = [c for c in collisions if c.hypothesis_id == "H_CONV"]
        if conv:
            actions = conv[0].actions
            action_types = [a["action"] for a in actions]
            assert "block_pr" in action_types  # security involved

    def test_detect_with_registry(self, db_path):
        DomainRegistry.reset()
        registry = DomainRegistry.instance()

        from domains.quality.domain import QualityDomain
        from domains.security.domain import SecurityDomain

        registry.register(SecurityDomain())
        registry.register(QualityDomain())

        engine = CollisionEngine(db_path=db_path)
        collisions = engine.detect_collisions(registry=registry)

        assert len(collisions) >= 1
        DomainRegistry.reset()


class TestCollisionResolution:
    """Test collision resolution."""

    def test_resolve_collision(self, db_path):
        engine = CollisionEngine(db_path=db_path)
        collisions = engine.detect_collisions()

        assert len(collisions) >= 1
        col_id = collisions[0].id

        success = engine.resolve_collision(col_id, resolved_by="test")
        assert success is True

        # Should no longer be active
        active = engine.get_active_collisions()
        resolved_ids = [a["id"] for a in active]
        assert col_id not in resolved_ids


class TestCollisionDataclass:
    """Test Collision dataclass."""

    def test_auto_id(self):
        c = Collision(title="Test")
        assert c.id.startswith("col_")

    def test_to_dict(self):
        c = Collision(
            hypothesis_id="H001",
            title="Test collision",
            confidence=0.9,
            domains_involved=["security", "quality"],
            engine_count=3,
            convergent=True,
        )
        d = c.to_dict()
        assert d["hypothesis_id"] == "H001"
        assert d["confidence"] == 0.9
        assert len(d["domains_involved"]) == 2
