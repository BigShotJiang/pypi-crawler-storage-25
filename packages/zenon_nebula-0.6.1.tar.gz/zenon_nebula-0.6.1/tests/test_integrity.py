# SPDX-License-Identifier: MIT
"""v0.5.3 core/integrity.py tests.

Pins the integrity-check behavior: verified on clean tree, warning
on small divergence, quarantined on large divergence or missing
manifest, and graceful degradation on unreadable files.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core import integrity as ig


def _write_fake_tree(root: Path, files: dict[str, str]) -> None:
    """Create a fake source tree mirroring Nebula's layout."""
    for rel, content in files.items():
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")


def _generate_and_save_manifest(root: Path, version: str = "test") -> Path:
    """Generate a manifest for a fake tree and save it at the expected path."""
    manifest = ig.generate_manifest(repo_root=root, version=version)
    manifest_path = root / "core" / "integrity_manifest.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2))
    return manifest_path


class TestManifestGeneration:
    def test_generate_includes_version(self, tmp_path):
        _write_fake_tree(
            tmp_path,
            {
                "core/foo.py": "# foo\n",
                "domains/bar/__init__.py": "",
            },
        )
        manifest = ig.generate_manifest(repo_root=tmp_path, version="v0.5.3")
        assert manifest["version"] == "v0.5.3"
        assert manifest["file_count"] == 2
        assert "core/foo.py" in manifest["files"]
        assert "domains/bar/__init__.py" in manifest["files"]

    def test_generate_excludes_build_and_venv(self, tmp_path):
        _write_fake_tree(
            tmp_path,
            {
                "core/foo.py": "# foo\n",
                "build/lib/core/foo.py": "# stale\n",
                ".venv/lib/foo.py": "# venv\n",
            },
        )
        manifest = ig.generate_manifest(repo_root=tmp_path)
        files = manifest["files"]
        assert "core/foo.py" in files
        assert "build/lib/core/foo.py" not in files
        assert ".venv/lib/foo.py" not in files

    def test_hashes_are_deterministic(self, tmp_path):
        _write_fake_tree(tmp_path, {"core/foo.py": "constant\n"})
        m1 = ig.generate_manifest(repo_root=tmp_path)
        m2 = ig.generate_manifest(repo_root=tmp_path)
        assert m1["files"] == m2["files"]


class TestIntegrityCheck:
    def test_clean_tree_returns_verified(self, tmp_path):
        _write_fake_tree(
            tmp_path,
            {
                "core/foo.py": "# foo\n",
                "core/bar.py": "# bar\n",
                "domains/baz/engine.py": "# baz\n",
            },
        )
        manifest_path = _generate_and_save_manifest(tmp_path)
        report = ig.check_integrity(repo_root=tmp_path, manifest_path=manifest_path)
        assert report.status == "verified"
        assert report.matching_files == 3
        assert report.divergent_files == []
        assert report.missing_files == []
        assert report.divergence_ratio == 0.0

    def test_one_file_modified_returns_warning_or_quarantined(self, tmp_path):
        """A single modified file in a small tree triggers quarantine
        because the divergence ratio is 33% (1/3) which exceeds 5%.
        The test name reflects both possibilities for edge-case
        clarity."""
        _write_fake_tree(
            tmp_path,
            {
                "core/a.py": "original\n",
                "core/b.py": "original\n",
                "core/c.py": "original\n",
            },
        )
        manifest_path = _generate_and_save_manifest(tmp_path)

        # Modify one file after manifest generation
        (tmp_path / "core" / "a.py").write_text("modified\n")

        report = ig.check_integrity(repo_root=tmp_path, manifest_path=manifest_path)
        assert report.status == "quarantined"  # 33% diverged
        assert len(report.divergent_files) == 1
        assert "core/a.py" in report.divergent_files

    def test_large_tree_small_divergence_is_warning(self, tmp_path):
        """In a 30-file tree, modifying 1 file is 3.3% divergence → warning."""
        files = {f"core/f{i}.py": f"file {i}\n" for i in range(30)}
        _write_fake_tree(tmp_path, files)
        manifest_path = _generate_and_save_manifest(tmp_path)

        # Modify one of 30 files → 3.3% divergence
        (tmp_path / "core" / "f0.py").write_text("modified\n")

        report = ig.check_integrity(repo_root=tmp_path, manifest_path=manifest_path)
        assert report.status == "warning"
        assert report.divergence_ratio < 0.05
        assert len(report.divergent_files) == 1

    def test_many_files_modified_returns_quarantined(self, tmp_path):
        files = {f"core/f{i}.py": f"file {i}\n" for i in range(20)}
        _write_fake_tree(tmp_path, files)
        manifest_path = _generate_and_save_manifest(tmp_path)

        # Modify 10 of 20 → 50% divergence
        for i in range(10):
            (tmp_path / "core" / f"f{i}.py").write_text("modified\n")

        report = ig.check_integrity(repo_root=tmp_path, manifest_path=manifest_path)
        assert report.status == "quarantined"
        assert len(report.divergent_files) == 10

    def test_missing_manifest_returns_verified_for_local_trust(self, tmp_path):
        """v0.5.4 semantic: no manifest -> trust local by default.

        The quarantine path is for peer findings where the producer
        claims a release version but can't prove it; that lives in
        the attestation layer (Phase I), not here.
        """
        _write_fake_tree(tmp_path, {"core/foo.py": "x\n"})
        report = ig.check_integrity(repo_root=tmp_path, manifest_path=tmp_path / "nonexistent.json")
        assert report.status == "verified"
        assert "no integrity_manifest.json" in " ".join(report.notes)
        assert "trusting local code by default" in " ".join(report.notes)

    def test_missing_file_flagged(self, tmp_path):
        _write_fake_tree(
            tmp_path,
            {
                "core/a.py": "a\n",
                "core/b.py": "b\n",
                "core/c.py": "c\n",
                "core/d.py": "d\n",
                "core/e.py": "e\n",
            },
        )
        manifest_path = _generate_and_save_manifest(tmp_path)

        # Delete one file after manifest generation → 20% divergence
        (tmp_path / "core" / "a.py").unlink()

        report = ig.check_integrity(repo_root=tmp_path, manifest_path=manifest_path)
        assert "core/a.py" in report.missing_files
        assert report.status == "quarantined"


class TestCachedStatus:
    def test_cached_status_returns_valid_value(self):
        """The live instance must report one of the three valid statuses."""
        status = ig.get_cached_status()
        assert status in ("verified", "warning", "quarantined")

    def test_cache_is_reused(self):
        """Second call returns same value without re-hashing."""
        ig.reset_status_cache()
        s1 = ig.get_cached_status()
        s2 = ig.get_cached_status()
        assert s1 == s2

    def test_reset_allows_re_check(self):
        ig.reset_status_cache()
        s1 = ig.get_cached_status()
        ig.reset_status_cache()
        s2 = ig.get_cached_status()
        # Should still return the same value since the tree didn't change
        assert s1 == s2


class TestReportSerialization:
    def test_report_to_dict(self, tmp_path):
        _write_fake_tree(tmp_path, {"core/foo.py": "x\n"})
        manifest_path = _generate_and_save_manifest(tmp_path)
        report = ig.check_integrity(repo_root=tmp_path, manifest_path=manifest_path)

        d = report.to_dict()
        assert "status" in d
        assert "total_files" in d
        assert "matching_files" in d
        assert "manifest_version" in d
        assert "divergence_ratio" in d
        # Should be JSON-serializable
        json.dumps(d)
