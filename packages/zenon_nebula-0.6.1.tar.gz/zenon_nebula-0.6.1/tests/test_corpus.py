# SPDX-License-Identifier: MIT
"""Tests for core.corpus -- CorpusManager indexing, search, freshness."""

import json

import pytest

import core.corpus as corpus_mod
from core.corpus import CorpusManager


@pytest.fixture(autouse=True)
def temp_index_dir(tmp_path, monkeypatch):
    """Redirect corpus index to a temp directory."""
    idx_dir = tmp_path / "corpus_index"
    monkeypatch.setattr(corpus_mod, "INDEX_DIR", idx_dir)
    monkeypatch.setattr(corpus_mod, "MANIFEST_PATH", idx_dir / "manifest.json")
    return idx_dir


@pytest.fixture
def workspace(tmp_path):
    """Create a mock workspace with two repos."""
    ws = tmp_path / "workspace"
    ws.mkdir()

    # Repo A: a Python project
    repo_a = ws / "repo-alpha"
    repo_a.mkdir()
    (repo_a / ".git").mkdir()  # fake git dir
    src = repo_a / "src"
    src.mkdir()
    (src / "main.py").write_text("# Main entry point for repo alpha\nprint('hello')\n")
    (src / "utils.py").write_text("# Utility functions\ndef helper(): pass\n")
    (repo_a / "README.md").write_text("# Repo Alpha\nA test repository.\n")

    # Repo B: a Go project
    repo_b = ws / "repo-beta"
    repo_b.mkdir()
    (repo_b / ".git").mkdir()
    (repo_b / "main.go").write_text("package main\n\nfunc main() {}\n")
    (repo_b / "plasma.go").write_text("package main\n// plasma fee mechanism\n")

    return ws


class TestIndexRepo:
    def test_index_creates_json_file(self, workspace, temp_index_dir):
        cm = CorpusManager(workspace_root=str(workspace))
        result = cm.index_repo(str(workspace / "repo-alpha"))
        assert result["files_indexed"] >= 2  # main.py, utils.py, maybe README.md
        assert (temp_index_dir / "repo-alpha.json").exists()

    def test_index_records_manifest(self, workspace, temp_index_dir):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"))
        manifest = json.loads((temp_index_dir / "manifest.json").read_text())
        assert "repo-alpha" in manifest["repos"]
        assert "last_indexed" in manifest["repos"]["repo-alpha"]

    def test_index_captures_file_metadata(self, workspace, temp_index_dir):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"))
        data = json.loads((temp_index_dir / "repo-alpha.json").read_text())
        files = data["files"]
        paths = {f["path"] for f in files}
        assert any("main.py" in p for p in paths)
        # Check first_line captured
        main_entry = next(f for f in files if "main.py" in f["path"])
        assert "Main entry point" in main_entry["first_line"]

    def test_index_nonexistent_path(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        result = cm.index_repo("/nonexistent/path")
        assert "error" in result

    def test_index_skips_unchanged(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"), force=True)
        # Second call without force may skip if hash matches
        result = cm.index_repo(str(workspace / "repo-alpha"), force=False)
        # Either indexed or skipped -- both valid
        assert "files_indexed" in result or "skipped" in result

    def test_force_reindex(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"), force=True)
        result = cm.index_repo(str(workspace / "repo-alpha"), force=True)
        assert "files_indexed" in result


class TestSearch:
    def test_search_by_filename(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"), force=True)
        results = cm.search("main")
        assert len(results) >= 1
        assert any("main.py" in r["path"] for r in results)

    def test_search_by_first_line(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-beta"), force=True)
        results = cm.search("plasma")
        assert len(results) >= 1

    def test_search_with_repo_filter(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"), force=True)
        cm.index_repo(str(workspace / "repo-beta"), force=True)
        results = cm.search("main", repo_filter="repo-alpha")
        for r in results:
            assert r["repo_name"] == "repo-alpha"

    def test_search_with_ext_filter(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"), force=True)
        results = cm.search("main", ext_filter=".py")
        for r in results:
            assert r["ext"] == ".py"

    def test_search_empty_query(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        assert cm.search("") == []

    def test_search_no_results(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"), force=True)
        results = cm.search("zzzznonexistent")
        assert results == []


class TestFreshness:
    def test_freshness_tracking(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"), force=True)
        freshness = cm.track_freshness()
        assert len(freshness) >= 1
        entry = freshness[0]
        assert "repo_name" in entry
        assert "age_hours" in entry
        assert "stale" in entry

    def test_recently_indexed_not_stale(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"), force=True)
        freshness = cm.track_freshness()
        alpha = next(f for f in freshness if f["repo_name"] == "repo-alpha")
        assert alpha["stale"] is False
        assert alpha["age_hours"] < 1.0


class TestDiscoverRepos:
    def test_discovers_workspace_repos(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        repos = cm.discover_repos()
        names = {r["name"] for r in repos}
        assert "repo-alpha" in names
        assert "repo-beta" in names

    def test_has_git_flag(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        repos = cm.discover_repos()
        alpha = next(r for r in repos if r["name"] == "repo-alpha")
        assert alpha["has_git"] is True


class TestStats:
    def test_stats_after_indexing(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"), force=True)
        stats = cm.get_stats()
        assert stats["total_repos"] >= 1
        assert stats["total_files"] >= 2
        assert stats["total_size_bytes"] > 0


class TestGetFileContent:
    def test_reads_file(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"), force=True)
        content = cm.get_file_content("repo-alpha", "src/main.py")
        assert content is not None
        assert "hello" in content

    def test_nonexistent_repo(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        assert cm.get_file_content("ghost", "file.py") is None

    def test_nonexistent_file(self, workspace):
        cm = CorpusManager(workspace_root=str(workspace))
        cm.index_repo(str(workspace / "repo-alpha"), force=True)
        assert cm.get_file_content("repo-alpha", "nonexistent.py") is None
