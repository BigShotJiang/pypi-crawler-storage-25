# SPDX-License-Identifier: MIT
"""
Tests for core.cost_optimizer -- Minimize LLM spend by local-first approach.

Tests should_use_llm for LOCAL_ONLY, LLM_REQUIRED, and TRY_LOCAL_FIRST
categories, should_skip_engine with fresh/stale data, caching, and
estimate_savings.
"""

import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.cost_optimizer import CostOptimizer
from core.persist_to_db import ensure_schema


@pytest.fixture
def db_path(tmp_path):
    db = str(tmp_path / "test_engine.db")
    ensure_schema(db)
    return db


@pytest.fixture
def optimizer(db_path):
    return CostOptimizer(db_path=db_path)


class TestShouldUseLLM:
    """Test should_use_llm classification."""

    def test_local_only_returns_false(self, optimizer):
        """LOCAL_ONLY tasks never need an LLM."""
        for task in CostOptimizer.LOCAL_ONLY:
            assert optimizer.should_use_llm(task) is False, f"{task} should be local"

    def test_llm_required_returns_true(self, optimizer):
        """LLM_REQUIRED tasks always need an LLM."""
        for task in CostOptimizer.LLM_REQUIRED:
            assert optimizer.should_use_llm(task) is True, f"{task} should use LLM"

    def test_try_local_first_with_high_confidence(self, optimizer):
        """TRY_LOCAL_FIRST tasks skip LLM when local result is confident."""
        result = optimizer.should_use_llm(
            "signal_classification",
            context={"text": "", "file_path": "docs/specs/ptlc.md"},
        )
        # file_path contains "spec" -> local returns confidence 0.9 -> skip LLM
        assert result is False

    def test_try_local_first_with_low_confidence(self, optimizer):
        """TRY_LOCAL_FIRST tasks use LLM when local result is uncertain."""
        result = optimizer.should_use_llm(
            "signal_classification",
            context={"text": "something vague", "file_path": "random.txt"},
        )
        # Low confidence from local method -> use LLM
        assert result is True

    def test_unknown_task_defaults_to_llm(self, optimizer):
        """Unknown task types default to using LLM."""
        assert optimizer.should_use_llm("never_seen_before") is True

    def test_try_local_first_no_context_uses_llm(self, optimizer):
        """TRY_LOCAL_FIRST with no context falls through to LLM."""
        result = optimizer.should_use_llm("signal_classification", context=None)
        assert result is True

    def test_commit_categorization_conventional(self, optimizer):
        """Conventional commit messages are classified locally."""
        result = optimizer.should_use_llm(
            "commit_categorization",
            context={"message": "feat[sdk]: add PTLC support"},
        )
        assert result is False

    def test_commit_categorization_unconventional(self, optimizer):
        """Non-conventional commit messages need LLM."""
        result = optimizer.should_use_llm(
            "commit_categorization",
            context={"message": "updated some stuff"},
        )
        assert result is True

    def test_severity_assessment_critical(self, optimizer):
        """Critical severity keywords are detected locally."""
        result = optimizer.should_use_llm(
            "severity_assessment",
            context={"text": "fund loss possible through reentrancy"},
        )
        assert result is False

    def test_severity_assessment_ambiguous(self, optimizer):
        """Ambiguous severity needs LLM analysis."""
        result = optimizer.should_use_llm(
            "severity_assessment",
            context={"text": "parameter naming is inconsistent"},
        )
        assert result is True


class TestShouldSkipEngine:
    """Test community data freshness check."""

    def test_skip_when_fresh_data(self, optimizer, db_path):
        """Skip engine when fresh community data exists."""
        conn = sqlite3.connect(db_path)
        conn.execute(
            "INSERT INTO evidence (domain, engine, evidence_type, finding, confidence) "
            "VALUES ('security', 'vuln_scanner', 'scan', 'clean', 0.8)"
        )
        conn.commit()
        conn.close()

        assert optimizer.should_skip_engine("vuln_scanner", "security") is True

    def test_no_skip_when_no_data(self, optimizer):
        """Do not skip engine when no data exists at all."""
        assert optimizer.should_skip_engine("vuln_scanner", "security") is False

    def test_no_skip_when_data_stale(self, optimizer, db_path):
        """Do not skip when data is older than max_age_hours."""
        conn = sqlite3.connect(db_path)
        old_time = (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
        conn.execute(
            "INSERT INTO evidence (domain, engine, evidence_type, finding, "
            "confidence, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
            ("security", "vuln_scanner", "scan", "clean", 0.8, old_time),
        )
        conn.commit()
        conn.close()

        assert optimizer.should_skip_engine("vuln_scanner", "security", max_age_hours=24) is False


class TestCaching:
    """Test in-memory LLM response caching."""

    def test_cache_miss_returns_none(self, optimizer):
        assert optimizer.get_cached("unknown_key") is None

    def test_cache_hit_returns_result(self, optimizer):
        optimizer.set_cached("test_key", {"answer": 42})
        result = optimizer.get_cached("test_key")
        assert result == {"answer": 42}

    def test_cache_expires(self, optimizer):
        """Expired cache entries are not returned."""
        optimizer.set_cached("old_key", {"answer": 1})
        # Force expiration by backdating
        optimizer._cache["old_key"]["timestamp"] = datetime.now(timezone.utc) - timedelta(hours=2)
        assert optimizer.get_cached("old_key") is None


class TestEstimateSavings:
    """Test savings estimation from actions_log."""

    def test_empty_db_returns_zeros(self, optimizer):
        result = optimizer.estimate_savings(days=30)
        assert result["total_actions"] == 0
        assert result["local_actions"] == 0
        assert result["llm_actions"] == 0
        assert result["actual_cost"] == 0.0

    def test_counts_local_vs_llm(self, optimizer, db_path):
        """Correctly separates local (free) and LLM (paid) actions."""
        conn = sqlite3.connect(db_path)
        # Local action (cost 0)
        conn.execute(
            "INSERT INTO actions_log (domain, module, action, cost_usd) "
            "VALUES ('quality', 'build_checker', 'go_build', 0.0)"
        )
        # LLM action (cost > 0)
        conn.execute(
            "INSERT INTO actions_log (domain, module, action, cost_usd) "
            "VALUES ('security', 'adversarial', 'review', 0.05)"
        )
        conn.commit()
        conn.close()

        result = optimizer.estimate_savings(days=30)
        assert result["total_actions"] == 2
        assert result["llm_actions"] == 1
        assert result["local_actions"] == 1
        assert result["actual_cost"] == 0.05


class TestLocalClassifiers:
    """Test local classification methods directly."""

    def test_classify_signal_spec_path(self, optimizer):
        result = optimizer._classify_signal_locally(
            {"text": "", "file_path": "docs/specs/ptlc_spec.md"}
        )
        assert result["classification"] == "spec_change"
        assert result["confidence"] >= 0.8

    def test_classify_signal_security_path(self, optimizer):
        result = optimizer._classify_signal_locally(
            {"text": "", "file_path": "security/advisory.md"}
        )
        assert result["classification"] == "security_relevant"

    def test_classify_signal_breaking_change(self, optimizer):
        result = optimizer._classify_signal_locally(
            {"text": "breaking change: removed field", "file_path": ""}
        )
        assert result["classification"] == "breaking_change"

    def test_classify_signal_test_path(self, optimizer):
        result = optimizer._classify_signal_locally(
            {"text": "", "file_path": "vm/embedded/ptlc_test.go"}
        )
        assert result["classification"] == "test_change"

    def test_categorize_conventional_commit(self, optimizer):
        result = optimizer._categorize_commit_locally({"message": "fix[htlc]: correct unlock path"})
        assert result["category"] == "fix"
        assert result["confidence"] >= 0.9

    def test_assess_severity_critical(self, optimizer):
        result = optimizer._assess_severity_locally({"text": "fund loss possible"})
        assert result["severity"] == "critical"
