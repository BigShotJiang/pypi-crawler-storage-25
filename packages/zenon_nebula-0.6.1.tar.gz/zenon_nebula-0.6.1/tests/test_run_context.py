# SPDX-License-Identifier: MIT
"""
Tests for core.run_context -- Execution context and budget tracking.

Tests RunContext creation, budget tracking, singleton behavior,
environment hashing, and serialization.
"""

import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.run_context import BudgetTracker, RunContext


class TestBudgetTracker:
    """Test budget tracking."""

    def test_initial_state(self):
        bt = BudgetTracker(max_budget_usd=10.0)
        assert bt.total_cost_usd == 0.0
        assert bt.budget_remaining == 10.0
        assert bt.budget_percent_used == 0.0
        assert bt.is_over_budget() is False
        assert bt.is_warning() is False

    def test_record_call(self):
        bt = BudgetTracker(max_budget_usd=10.0)
        bt.record_call("claude-sonnet-4-6", 1000, 200, 0.05)

        assert bt.total_cost_usd == 0.05
        assert bt.budget_remaining == 9.95
        assert "claude-sonnet-4-6" in bt.calls_by_model
        assert bt.calls_by_model["claude-sonnet-4-6"]["calls"] == 1
        assert bt.calls_by_model["claude-sonnet-4-6"]["input_tokens"] == 1000
        assert bt.calls_by_model["claude-sonnet-4-6"]["output_tokens"] == 200

    def test_multiple_calls_accumulate(self):
        bt = BudgetTracker(max_budget_usd=1.0)
        bt.record_call("model_a", 100, 50, 0.3)
        bt.record_call("model_a", 200, 100, 0.4)

        assert bt.total_cost_usd == 0.7
        assert bt.calls_by_model["model_a"]["calls"] == 2
        assert bt.calls_by_model["model_a"]["input_tokens"] == 300

    def test_over_budget(self):
        bt = BudgetTracker(max_budget_usd=1.0)
        bt.record_call("model", 100, 50, 1.5)
        assert bt.is_over_budget() is True
        assert bt.budget_remaining == 0.0

    def test_warning_at_80_percent(self):
        bt = BudgetTracker(max_budget_usd=10.0)
        bt.record_call("model", 100, 50, 8.0)
        assert bt.is_warning() is True
        assert bt.is_warning(threshold_percent=90.0) is False

    def test_zero_budget(self):
        bt = BudgetTracker(max_budget_usd=0.0)
        assert bt.budget_percent_used == 100.0
        # 0.0 >= 0.0 is True, so immediately over budget
        assert bt.is_over_budget() is True


class TestRunContext:
    """Test RunContext creation and behavior."""

    def setup_method(self):
        """Reset singleton before each test."""
        RunContext.reset()

    def test_creation(self):
        ctx = RunContext(domain="security", engine="adversarial")
        assert ctx.domain == "security"
        assert ctx.engine == "adversarial"
        assert len(ctx.run_id) == 8
        assert ctx.findings_count == 0
        assert ctx.actions_count == 0
        assert ctx.errors == []

    def test_env_hash_computed(self):
        ctx = RunContext()
        assert isinstance(ctx.env_hash, str)
        assert len(ctx.env_hash) == 16

    def test_env_hash_deterministic(self):
        """Same environment produces same hash."""
        ctx1 = RunContext()
        RunContext.reset()
        ctx2 = RunContext()
        assert ctx1.env_hash == ctx2.env_hash

    def test_elapsed_seconds(self):
        ctx = RunContext()
        import time

        time.sleep(0.01)
        assert ctx.elapsed_seconds > 0

    def test_record_error(self):
        ctx = RunContext()
        ctx.record_error("something went wrong")
        assert len(ctx.errors) == 1
        assert "something went wrong" in ctx.errors[0]

    def test_to_dict(self):
        ctx = RunContext(domain="test", engine="test_engine")
        d = ctx.to_dict()

        assert d["domain"] == "test"
        assert d["engine"] == "test_engine"
        assert "run_id" in d
        assert "start_time" in d
        assert "elapsed_seconds" in d
        assert "env_hash" in d
        assert "findings_count" in d
        assert "budget_used_usd" in d
        assert "budget_remaining_usd" in d

    def test_repr(self):
        ctx = RunContext(domain="security", engine="scanner")
        r = repr(ctx)
        assert "security" in r
        assert "scanner" in r

    def test_budget_integration(self):
        ctx = RunContext()
        ctx.budget.record_call("model", 100, 50, 0.01)
        d = ctx.to_dict()
        assert d["budget_used_usd"] == 0.01

    def test_log_end(self):
        """log_end should not raise."""
        ctx = RunContext()
        ctx.findings_count = 5
        ctx.actions_count = 3
        ctx.log_end("test complete")


class TestRunContextSingleton:
    """Test singleton behavior."""

    def setup_method(self):
        RunContext.reset()

    def test_get_current_creates_singleton(self):
        ctx = RunContext.get_current(domain="system")
        ctx2 = RunContext.get_current()
        assert ctx is ctx2

    def test_reset_clears_singleton(self):
        ctx1 = RunContext.get_current()
        RunContext.reset()
        ctx2 = RunContext.get_current()
        assert ctx1 is not ctx2

    def test_unique_run_ids(self):
        ctx1 = RunContext()
        RunContext.reset()
        ctx2 = RunContext()
        assert ctx1.run_id != ctx2.run_id
