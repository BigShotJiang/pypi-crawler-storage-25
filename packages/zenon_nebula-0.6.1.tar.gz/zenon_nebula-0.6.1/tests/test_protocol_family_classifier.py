# SPDX-License-Identifier: MIT
"""Tests for domains.investigation.engines.protocol_family_classifier."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from core.persistence.metrics import persist_metric, query_table
from domains.investigation.engines import protocol_family_classifier as pfc


def _insert(db_path: str, name: str, repo_type: str, path: Path | None = None) -> None:
    """Seed a single ``workspace_repos`` row."""
    persist_metric(
        db_path=db_path,
        table="workspace_repos",
        data={
            "repo_name": name,
            "repo_path": str(path or Path("/tmp") / name),
            "repo_type": repo_type,
            "languages": "[]",
            "has_ci": 0,
            "has_tests": 0,
            "classified_at": "2026-04-10T00:00:00+00:00",
        },
    )


def test_module_import_smoke():
    """Entry point is callable and families list is well-formed."""
    assert callable(pfc.classify_protocol_families)
    assert "utxo_chain" in pfc.FAMILIES
    assert "unknown" in pfc.FAMILIES


def test_empty_workspace_returns_empty(db_path):
    """No workspace_repos rows -> empty dict."""
    result = pfc.classify_protocol_families(db_path=db_path)
    assert result == {}


def test_classifies_known_types(tmp_path, db_path):
    """Known repo types are mapped via _TYPE_TO_FAMILY."""
    _insert(db_path, "bitcoin", "blockchain_node_btc")
    _insert(db_path, "go-zenon", "node")
    _insert(db_path, "znn_sdk_dart", "sdk_dart")
    _insert(db_path, "developer-commons", "specs")
    _insert(db_path, "syrius", "wallet")

    result = pfc.classify_protocol_families(db_path=db_path, use_llm=False)
    counts = result["counts"]
    assert counts["utxo_chain"] >= 1
    assert counts["account_chain"] >= 1
    assert counts["sdk_consumer"] >= 1
    assert counts["documentation"] >= 1
    assert counts["tooling"] >= 1
    assert result["total"] == 5

    rows = query_table(
        db_path=db_path,
        table="evidence",
        where="engine = ?",
        params=("protocol_family_classifier",),
        limit=5,
    )
    assert rows


def test_name_heuristic_falls_back_for_unknown_types(db_path):
    """A repo with unknown repo_type but a named heuristic match resolves."""
    _insert(db_path, "zk-rollup-experiment", "unknown")
    _insert(db_path, "orbital-bridge", "unknown")
    _insert(db_path, "my-wiki", "unknown")
    _insert(db_path, "some-sdk", "unknown")

    result = pfc.classify_protocol_families(db_path=db_path, use_llm=False)
    counts = result["counts"]
    assert counts["zk_rollup"] >= 1
    assert counts["bridge"] >= 1
    assert counts["documentation"] >= 1
    assert counts["sdk_consumer"] >= 1


def test_llm_fallback_is_mocked(db_path):
    """When ``use_llm=True`` the classifier calls call_llm (mocked)."""
    _insert(db_path, "weirdname", "unknown")

    def fake_llm(prompt: str, system: str = "", model: str = "auto", **kw):
        return {
            "text": "tooling",
            "cost_usd": 0.0,
            "input_tokens": 0,
            "output_tokens": 0,
            "model": "mock",
        }

    with (
        patch(
            "domains.investigation.engines.protocol_family_classifier.call_llm",
            create=True,
            side_effect=fake_llm,
        ),
        patch(
            "core.llm_provider.call_llm",
            side_effect=fake_llm,
            create=True,
        ),
    ):
        result = pfc.classify_protocol_families(
            db_path=db_path,
            use_llm=True,
            max_llm_calls=2,
        )
    # weirdname should be classified as tooling (either via LLM or fallback).
    assert result["total"] == 1
