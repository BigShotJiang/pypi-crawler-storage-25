# SPDX-License-Identifier: MIT
"""Tests for core/api_templates/ -- API investigation template utilities.

These tests verify module structure, imports, and function signatures
without making actual HTTP calls. Live API tests would require network
access and are handled separately.
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


class TestWaybackImports:
    """Verify wayback module loads and has expected functions."""

    def test_import(self):
        from core.api_templates import wayback

        assert hasattr(wayback, "search_snapshots")
        assert hasattr(wayback, "get_snapshot_content")

    def test_search_snapshots_signature(self):
        import inspect

        from core.api_templates.wayback import search_snapshots

        sig = inspect.signature(search_snapshots)
        params = list(sig.parameters.keys())
        assert "url" in params
        assert "from_date" in params
        assert "to_date" in params
        assert "session" in params

    def test_get_snapshot_content_signature(self):
        import inspect

        from core.api_templates.wayback import get_snapshot_content

        sig = inspect.signature(get_snapshot_content)
        params = list(sig.parameters.keys())
        assert "url" in params
        assert "timestamp" in params

    def test_html_analysis_extracts_analytics(self):
        from core.api_templates.wayback import _extract_analytics

        html = '<script>ga("create", "UA-12345678-1", "auto")</script>'
        codes = _extract_analytics(html)
        assert len(codes) == 1
        assert codes[0]["type"] == "google_analytics_ua"
        assert codes[0]["code"] == "UA-12345678-1"

    def test_html_analysis_extracts_emails(self):
        from core.api_templates.wayback import _extract_emails

        html = '<a href="mailto:test@example.org">contact</a>'
        emails = _extract_emails(html)
        assert "test@example.org" in emails

    def test_html_analysis_filters_image_emails(self):
        from core.api_templates.wayback import _extract_emails

        html = 'img src="photo@user.png"'
        emails = _extract_emails(html)
        assert len(emails) == 0

    def test_extract_title(self):
        from core.api_templates.wayback import _extract_title

        html = "<html><head><title>Test Page</title></head></html>"
        assert _extract_title(html) == "Test Page"

    def test_extract_social_links(self):
        from core.api_templates.wayback import _extract_social_links

        html = '<a href="https://twitter.com/zenon_network">Twitter</a>'
        links = _extract_social_links(html)
        assert len(links) == 1
        assert links[0]["platform"] == "twitter"
        assert links[0]["handle"] == "zenon_network"


class TestBlockchainImports:
    """Verify blockchain module loads and has expected functions."""

    def test_import(self):
        from core.api_templates import blockchain

        assert hasattr(blockchain, "get_btc_address_info")
        assert hasattr(blockchain, "get_btc_block_info")
        assert hasattr(blockchain, "get_btc_tx_info")
        assert hasattr(blockchain, "get_eth_address_info")

    def test_infer_address_type(self):
        from core.api_templates.blockchain import _infer_address_type

        assert _infer_address_type("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa") == "p2pkh (legacy)"
        assert _infer_address_type("3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy") == "p2sh"
        assert "taproot" in _infer_address_type("bc1pxyz")

    def test_identify_miner(self):
        from core.api_templates.blockchain import _identify_miner

        assert _identify_miner("/F2Pool/ some text") == "F2Pool"
        assert _identify_miner("no pool here") == "Unknown"

    def test_unix_to_utc(self):
        from core.api_templates.blockchain import _unix_to_utc

        assert _unix_to_utc(0) == "unknown"
        assert "2021" in _unix_to_utc(1637748073)


class TestGithubDeepImports:
    """Verify github_deep module loads and has expected functions."""

    def test_import(self):
        from core.api_templates import github_deep

        assert hasattr(github_deep, "get_contributor_timeline")
        assert hasattr(github_deep, "get_code_frequency")
        assert hasattr(github_deep, "compare_repos")

    def test_function_signatures(self):
        import inspect

        from core.api_templates.github_deep import get_contributor_timeline

        sig = inspect.signature(get_contributor_timeline)
        params = list(sig.parameters.keys())
        assert "org" in params
        assert "repo" in params
        assert "session" in params


class TestMarketDataImports:
    """Verify market_data module loads and has expected functions."""

    def test_import(self):
        from core.api_templates import market_data

        assert hasattr(market_data, "get_dexscreener_pair")
        assert hasattr(market_data, "get_coingecko_data")
        assert hasattr(market_data, "get_uniswap_pool")

    def test_dexscreener_signature(self):
        import inspect

        from core.api_templates.market_data import get_dexscreener_pair

        sig = inspect.signature(get_dexscreener_pair)
        params = list(sig.parameters.keys())
        assert "pair_address" in params
        assert "chain" in params

    def test_coingecko_signature(self):
        import inspect

        from core.api_templates.market_data import get_coingecko_data

        sig = inspect.signature(get_coingecko_data)
        params = list(sig.parameters.keys())
        assert "coin_id" in params


class TestWebSearchImports:
    """Verify web_search module loads and has expected functions."""

    def test_import(self):
        from core.api_templates import web_search

        assert hasattr(web_search, "search")
        assert hasattr(web_search, "fetch_page")
        assert hasattr(web_search, "search_news")

    def test_html_to_text(self):
        from core.api_templates.web_search import _html_to_text

        html = "<p>Hello <b>world</b></p><script>evil()</script>"
        text = _html_to_text(html)
        assert "Hello" in text
        assert "world" in text
        assert "evil" not in text

    def test_extract_title(self):
        from core.api_templates.web_search import _extract_title

        assert _extract_title("<title>My Page</title>") == "My Page"
        assert _extract_title("<html>no title</html>") == ""

    def test_parse_ddg_empty(self):
        from core.api_templates.web_search import _parse_ddg_html

        results = _parse_ddg_html("", 10)
        assert results == []
