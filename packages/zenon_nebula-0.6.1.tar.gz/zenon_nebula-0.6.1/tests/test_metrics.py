# SPDX-License-Identifier: MIT
"""Tests for the stdlib Prometheus exporter in :mod:`core.metrics`.

Covers:

- Counter monotonicity and label identity.
- Gauge set / overwrite semantics.
- Observe summary aggregation (count, sum, min, max).
- Text exposition format contract (HELP, TYPE lines, escaping).
- Validation of names and labels.
- The /metrics HTTP endpoint exposed by the RPC server.
"""

from __future__ import annotations

import json
import threading
import urllib.request
from http.server import HTTPServer

import pytest

from core import metrics


@pytest.fixture(autouse=True)
def _reset_metrics():
    """Every test gets a clean metric registry."""
    metrics.reset()
    yield
    metrics.reset()


# --------------------------------------------------------------------------
# Counter
# --------------------------------------------------------------------------


def test_increment_default_delta_is_one():
    metrics.increment("nebula_test_counter")
    assert "nebula_test_counter 1" in metrics.render()


def test_increment_with_custom_value():
    metrics.increment("nebula_test_counter", value=5)
    metrics.increment("nebula_test_counter", value=2.5)
    assert "nebula_test_counter 7.5" in metrics.render()


def test_increment_refuses_negative_value():
    with pytest.raises(ValueError):
        metrics.increment("nebula_test_counter", value=-1)


def test_counter_labels_produce_distinct_series():
    metrics.increment("nebula_findings_total", {"domain": "security"})
    metrics.increment("nebula_findings_total", {"domain": "security"})
    metrics.increment("nebula_findings_total", {"domain": "quality"})
    text = metrics.render()
    assert 'nebula_findings_total{domain="security"} 2' in text
    assert 'nebula_findings_total{domain="quality"} 1' in text


def test_counter_label_order_is_deterministic():
    metrics.increment("ordered", {"b": "2", "a": "1"})
    text = metrics.render()
    # Labels must be sorted alphabetically in the output.
    assert 'ordered{a="1",b="2"} 1' in text


# --------------------------------------------------------------------------
# Gauge
# --------------------------------------------------------------------------


def test_gauge_set_overwrites():
    metrics.gauge("nebula_evidence_height", 10)
    metrics.gauge("nebula_evidence_height", 12345)
    assert "nebula_evidence_height 12345" in metrics.render()


def test_gauge_supports_float_values():
    metrics.gauge("nebula_budget_remaining", 12.34)
    assert "nebula_budget_remaining 12.34" in metrics.render()


def test_gauge_supports_zero():
    metrics.gauge("nebula_gauge_zero", 0)
    assert "nebula_gauge_zero 0" in metrics.render()


# --------------------------------------------------------------------------
# Observe / summary
# --------------------------------------------------------------------------


def test_observe_aggregates_count_sum_min_max():
    for v in (1.0, 2.0, 3.0, 4.0):
        metrics.observe("nebula_cycle_seconds", v)
    text = metrics.render()
    assert "nebula_cycle_seconds_count 4" in text
    assert "nebula_cycle_seconds_sum 10" in text
    assert "nebula_cycle_seconds_min 1" in text
    assert "nebula_cycle_seconds_max 4" in text


def test_observe_with_labels():
    metrics.observe("nebula_engine_runtime", 0.5, {"engine": "spec_tracker"})
    metrics.observe("nebula_engine_runtime", 1.5, {"engine": "spec_tracker"})
    text = metrics.render()
    assert 'nebula_engine_runtime_count{engine="spec_tracker"} 2' in text
    assert 'nebula_engine_runtime_sum{engine="spec_tracker"} 2' in text


# --------------------------------------------------------------------------
# Render format
# --------------------------------------------------------------------------


def test_describe_emits_help_and_type_lines():
    metrics.describe("described_metric", "A test description", "counter")
    metrics.increment("described_metric")
    text = metrics.render()
    assert "# HELP described_metric A test description" in text
    assert "# TYPE described_metric counter" in text


def test_render_ends_with_newline():
    metrics.increment("trailing_nl")
    text = metrics.render()
    assert text.endswith("\n")


def test_render_is_empty_when_no_metrics():
    # An empty registry renders as a trivial no-op string (possibly empty,
    # possibly a bare newline) — the contract is just "no metric lines".
    out = metrics.render()
    assert "nebula_" not in out
    assert "# HELP" not in out


def test_label_escaping_handles_quotes_and_backslashes():
    metrics.increment("escaping_test", {"path": 'a"b\\c'})
    text = metrics.render()
    assert 'path="a\\"b\\\\c"' in text


# --------------------------------------------------------------------------
# Validation
# --------------------------------------------------------------------------


def test_invalid_name_raises():
    with pytest.raises(ValueError):
        metrics.increment("1badname")
    with pytest.raises(ValueError):
        metrics.gauge("has space", 1)


def test_empty_name_raises():
    with pytest.raises(ValueError):
        metrics.increment("")


def test_describe_rejects_bad_type():
    with pytest.raises(ValueError):
        metrics.describe("x", "help", "bogus")


# --------------------------------------------------------------------------
# HTTP /metrics endpoint
# --------------------------------------------------------------------------


def test_rpc_get_metrics_returns_text_format():
    """Boot the RPC handler against a throwaway port and scrape /metrics."""
    from core.nebula_rpc import NebulRPCHandler

    metrics.increment("nebula_rpc_probe", {"who": "test"})
    metrics.gauge("nebula_rpc_uptime", 42)

    # Bind to an ephemeral port on localhost.
    # HTTPServer.server_bind() calls socket.getfqdn() which can hang on
    # sandboxed DNS — override bind_and_activate and bind manually.
    server = HTTPServer(("127.0.0.1", 0), NebulRPCHandler, bind_and_activate=False)
    server.server_name = "localhost"
    server.server_port = 0
    server.socket.bind(server.server_address)
    server.server_address = server.socket.getsockname()
    server.socket.listen(5)
    host, port = server.server_address[0], server.server_address[1]

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        with urllib.request.urlopen(f"http://{host}:{port}/metrics", timeout=2) as resp:
            assert resp.status == 200
            ctype = resp.headers.get("Content-Type", "")
            assert "text/plain" in ctype
            assert "version=0.0.4" in ctype
            body = resp.read().decode("utf-8")
        assert 'nebula_rpc_probe{who="test"} 1' in body
        assert "nebula_rpc_uptime 42" in body
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def test_rpc_get_root_still_returns_health_json():
    """Ensure the metrics handler didn't break the existing JSON health check."""
    from core.nebula_rpc import NebulRPCHandler

    # HTTPServer.server_bind() calls socket.getfqdn() which can hang on
    # sandboxed DNS — override bind_and_activate and bind manually.
    server = HTTPServer(("127.0.0.1", 0), NebulRPCHandler, bind_and_activate=False)
    server.server_name = "localhost"
    server.server_port = 0
    server.socket.bind(server.server_address)
    server.server_address = server.socket.getsockname()
    server.socket.listen(5)
    host, port = server.server_address[0], server.server_address[1]

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        with urllib.request.urlopen(f"http://{host}:{port}/", timeout=2) as resp:
            assert resp.status == 200
            body = json.loads(resp.read())
        assert "result" in body
        assert body["result"]["healthy"] is True
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
