# SPDX-License-Identifier: MIT
"""Tests for the v0.3.1 curiosity_scanner engine.

The engine wraps `core.curiosity.CuriosityEngine` (which shipped in an
earlier version but was never called from any domain) and turns it into
a live scheduled engine that writes WHAT/SO WHAT/NOW WHAT findings
with clickable GitHub permalinks. These tests pin the plumbing:

- graceful degradation when the workspace isn't installed
- pattern detection against a synthetic repo with known clue keywords
- that persisted findings carry source_repo / source_file / source_line
  / verification_url — the full provenance chain the community uses to
  verify a clue
- that MAX_MATCHES_PER_FILE caps findings per file (no flood on a file
  that naturally contains a keyword 50 times)
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence.schema import ensure_schema
from domains.investigation.engines import curiosity_scanner as cs


@pytest.fixture
def fake_workspace(tmp_path, monkeypatch):
    """Build a two-repo workspace with known clue patterns planted.

    - go-zenon/vm/embedded/magic.go contains `schnorr` and `taproot`
      inside a comment — classic cryptographic clue keywords.
    - knowledge/developer-commons/docs/specs/NewThing/spec.md contains
      `experimental` — a spec-side clue a researcher might drop.
    - flood_test.go contains `plasma` 10 times — exercises
      MAX_MATCHES_PER_FILE.
    """
    ws = tmp_path / "workspace"
    ws.mkdir()

    go_zenon = ws / "go-zenon"
    (go_zenon / "vm" / "embedded").mkdir(parents=True)
    (go_zenon / ".git").mkdir()
    (go_zenon / "vm" / "embedded" / "magic.go").write_text(
        "package embedded\n\n"
        "// This uses schnorr signatures for aggregation.\n"
        "// See also taproot for Bitcoin integration.\n"
        "func Sign() {}\n"
    )
    (go_zenon / "vm" / "embedded" / "flood_test.go").write_text(
        "package embedded\n\n" + "\n".join([f"// plasma line {i}" for i in range(10)]) + "\n"
    )

    dc = ws / "developer-commons" / "docs" / "specs" / "NewThing"
    dc.mkdir(parents=True)
    (ws / "developer-commons" / ".git").mkdir(parents=True)
    (dc / "spec.md").write_text(
        "# NewThing\n\n"
        "This is an experimental extension to the protocol.\n"
        "It relies on plasma budgets.\n"
    )

    monkeypatch.setenv("ZENON_WORKSPACE_ROOT", str(ws))
    return ws


class TestCuriosityScannerHappyPath:
    def test_detects_schnorr_and_taproot_in_go_source(self, fake_workspace, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        # Force suggest_unexplored to return go-zenon regardless of mtime.
        with (
            patch.object(
                cs.CuriosityEngine,
                "suggest_unexplored",
                return_value=[{"repo_name": "go-zenon", "path": str(fake_workspace / "go-zenon")}],
            ),
            patch.object(
                cs.CuriosityEngine,
                "random_sample",
                return_value=[{"path": "vm/embedded/magic.go"}],
            ),
        ):
            result = cs.run_curiosity_scan(db_path=db)

        assert result["repos_scanned"] == 1
        assert result["files_sampled"] == 1
        assert result["findings_persisted"] >= 2  # schnorr + taproot

    def test_persisted_finding_has_provenance(self, fake_workspace, tmp_path):
        import sqlite3

        db = str(tmp_path / "test.db")
        ensure_schema(db)

        with (
            patch.object(
                cs.CuriosityEngine,
                "suggest_unexplored",
                return_value=[{"repo_name": "go-zenon", "path": str(fake_workspace / "go-zenon")}],
            ),
            patch.object(
                cs.CuriosityEngine,
                "random_sample",
                return_value=[{"path": "vm/embedded/magic.go"}],
            ),
        ):
            cs.run_curiosity_scan(db_path=db)

        conn = sqlite3.connect(db)
        rows = conn.execute(
            "SELECT source_file, source_line, evidence_type, finding, confidence "
            "FROM evidence WHERE engine = 'curiosity_scanner'"
        ).fetchall()
        conn.close()

        assert len(rows) >= 2
        # Every row carries file + line + WHAT prose
        for source_file, source_line, evidence_type, finding, confidence in rows:
            assert source_file == "vm/embedded/magic.go"
            assert source_line is not None and source_line > 0
            assert evidence_type.startswith("curiosity_")
            assert "WHAT:" in finding and "SO WHAT:" in finding and "NOW WHAT:" in finding
            assert 0.3 < confidence < 0.8  # medium — curiosity is speculative

    def test_max_matches_per_file_caps_flood(self, fake_workspace, tmp_path):
        """A file with 10 plasma mentions emits at most MAX_MATCHES_PER_FILE findings."""
        import sqlite3

        db = str(tmp_path / "test.db")
        ensure_schema(db)

        with (
            patch.object(
                cs.CuriosityEngine,
                "suggest_unexplored",
                return_value=[{"repo_name": "go-zenon", "path": str(fake_workspace / "go-zenon")}],
            ),
            patch.object(
                cs.CuriosityEngine,
                "random_sample",
                return_value=[{"path": "vm/embedded/flood_test.go"}],
            ),
        ):
            cs.run_curiosity_scan(db_path=db)

        conn = sqlite3.connect(db)
        rows = conn.execute(
            "SELECT COUNT(*) FROM evidence "
            "WHERE engine='curiosity_scanner' AND source_file='vm/embedded/flood_test.go'"
        ).fetchone()
        conn.close()

        # The flood file has 10 hits of the same keyword (plasma). The
        # dedup-by-pattern guard in _scan_file_for_patterns short-
        # circuits after the first match for a given pattern, so we
        # expect exactly 1 finding from this file.
        assert rows[0] == 1


class TestCuriosityScannerDegradation:
    def test_workspace_missing_returns_empty(self, tmp_path, monkeypatch):
        """No workspace -> empty result, no crash."""
        monkeypatch.delenv("ZENON_WORKSPACE_ROOT", raising=False)
        with patch(
            "domains.investigation.engines.curiosity_scanner.workspace_root", return_value=None
        ):
            result = cs.run_curiosity_scan(db_path=str(tmp_path / "x.db"))
        assert result["repos_scanned"] == 0
        assert result["findings_persisted"] == 0
        assert result["workspace_root"] is None

    def test_no_stale_repos_returns_empty(self, fake_workspace, tmp_path):
        """suggest_unexplored returning [] leaves the scanner silent."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        with patch.object(cs.CuriosityEngine, "suggest_unexplored", return_value=[]):
            result = cs.run_curiosity_scan(db_path=db)

        assert result["repos_scanned"] == 0
        assert result["findings_persisted"] == 0


class TestCuriosityScannerEntryPoint:
    def test_run_curiosity_scan_is_discoverable(self):
        """Scheduler entry-point heuristic finds run_curiosity_scan."""
        assert callable(cs.run_curiosity_scan)
        # The scheduler discovery iterates prefixes including run_ — and
        # requires zero required args other than db_path. Confirm that.
        import inspect

        sig = inspect.signature(cs.run_curiosity_scan)
        required_non_db = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty and p.name != "db_path"
        ]
        assert required_non_db == []
