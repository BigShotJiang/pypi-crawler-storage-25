# SPDX-License-Identifier: MIT
"""v0.5.1 attack_vector_scanner engine tests.

Pins the engine's pattern detection, safelist enforcement, entry-
point discoverability, and graceful degradation.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence.schema import ensure_schema
from domains.security.engines import attack_vector_scanner as avs


class TestPatternDetection:
    """Each pattern finds the thing it's supposed to find."""

    def test_ssl_verify_false_detected(self):
        from domains.security.engines.attack_vector_scanner import _PATTERNS

        pattern = next(p for p in _PATTERNS if p["name"] == "ssl_verify_false")
        assert pattern["regex"].search("requests.get(url, verify=False)")

    def test_mktemp_race_detected(self):
        from domains.security.engines.attack_vector_scanner import _PATTERNS

        pattern = next(p for p in _PATTERNS if p["name"] == "mktemp_race_condition")
        assert pattern["regex"].search("path = tempfile.mktemp(suffix='.db')")

    def test_os_system_detected(self):
        from domains.security.engines.attack_vector_scanner import _PATTERNS

        pattern = next(p for p in _PATTERNS if p["name"] == "os_system_call")
        assert pattern["regex"].search("os.system(cmd)")

    def test_bare_except_pass_detected(self):
        from domains.security.engines.attack_vector_scanner import _PATTERNS

        pattern = next(p for p in _PATTERNS if p["name"] == "bare_except_pass")
        code = "try:\n    x()\nexcept:\n    pass\n"
        assert pattern["regex"].search(code)


class TestDocstringStripping:
    """Ban patterns that appear inside docstrings should not false-positive."""

    def test_strip_removes_triple_quoted_strings(self):
        src = '"""This docstring mentions os.system() as banned."""\nreturn 1\n'
        stripped = avs._strip_comments_and_docstrings(src)
        assert "os.system" not in stripped

    def test_strip_removes_line_comments(self):
        src = "x = 1  # os.system() is banned\n"
        stripped = avs._strip_comments_and_docstrings(src)
        assert "os.system" not in stripped


class TestSeverityMapping:
    def test_severity_to_confidence_monotonic(self):
        assert avs._severity_to_confidence("critical") > avs._severity_to_confidence("high")
        assert avs._severity_to_confidence("high") > avs._severity_to_confidence("medium")
        assert avs._severity_to_confidence("medium") > avs._severity_to_confidence("low")
        assert avs._severity_to_confidence("low") > avs._severity_to_confidence("info")
        # All in [0, 1]
        for sev in ("critical", "high", "medium", "low", "info"):
            assert 0.0 < avs._severity_to_confidence(sev) <= 1.0


class TestEntryPointDiscovery:
    def test_run_attack_vector_scanner_is_discoverable(self):
        import inspect

        sig = inspect.signature(avs.run_attack_vector_scanner)
        required_non_db = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty and p.name != "db_path"
        ]
        assert required_non_db == []


class TestEngineIntegration:
    def test_scanner_runs_against_real_codebase(self, tmp_path):
        """The engine runs against Nebula's own code without crashing.

        Against the current codebase, the scanner should find some
        low-severity hits (mostly `random.random` in sampling code
        that's allowlisted) but never crash. The test confirms the
        full loop works end-to-end.
        """
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        result = avs.run_attack_vector_scanner(db_path=db, max_files=10)

        assert result["files_scanned"] >= 1
        assert isinstance(result["hits_by_severity"], dict)
        assert result["findings_persisted"] >= 0

    def test_scanner_persists_findings_with_full_provenance(self, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        avs.run_attack_vector_scanner(db_path=db, max_files=40)

        conn = sqlite3.connect(db)
        rows = conn.execute(
            "SELECT source_file, source_line, evidence_type, finding "
            "FROM evidence WHERE engine = 'attack_vector_scanner'"
        ).fetchall()
        conn.close()

        # Scanner may or may not find issues on a clean codebase;
        # we just verify that any persisted rows have full provenance.
        for source_file, source_line, ev_type, finding in rows:
            assert source_file is not None
            assert source_line is not None and source_line > 0
            assert ev_type.startswith("nebula_self_vuln_")
            assert "WHAT:" in finding
            assert "SO WHAT:" in finding
            assert "NOW WHAT:" in finding


class TestAllowlistBehavior:
    def test_allowlist_entries_skip_specific_patterns_at_specific_paths(self):
        """Allowlist keyed on (pattern_name, file_path) prevents
        known-safe uses from producing findings."""
        from domains.security.engines.attack_vector_scanner import (
            _PATH_ALLOWLIST_PER_PATTERN,
        )

        # weak_random_for_crypto is allowlisted for curiosity_scanner
        assert (
            "domains/investigation/engines/curiosity_scanner.py"
            in _PATH_ALLOWLIST_PER_PATTERN["weak_random_for_crypto"]
        )
