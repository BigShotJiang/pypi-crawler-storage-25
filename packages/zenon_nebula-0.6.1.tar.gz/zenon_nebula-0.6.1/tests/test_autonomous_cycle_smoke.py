# SPDX-License-Identifier: MIT
"""v0.3.2 autonomous-cycle smoke tests.

These tests exist because we shipped two dead engines in a row:

- v0.3.0 shipped `spec_audit` — the engine was registered in
  `DevelopmentDomain.get_engines()`, passed 21 unit tests in isolation,
  and was documented in the README + CHANGELOG as a new feature. It
  was never invoked by the autonomous loop in 400+ cycles of a harden
  run because `DevelopmentDomain.decide_next_action` only ever
  returned `upstream_monitor` or `dependency_chain`.

- `core/curiosity.py` shipped three versions earlier with its own test
  suite. It was never imported by any domain or engine, so its 300
  lines of exploration machinery were dead code in production.

Both failures were architecturally identical: engine correct in
isolation, scheduler wiring broken. Unit tests couldn't catch the gap
because unit tests call engines directly; the missing layer is
"does the autonomous scheduler actually route to this engine?".

These smoke tests cover three failure classes:

1. **Import smoke** — every registered engine's module must import
   without error. Catches stale module_path strings, missing files,
   circular imports at registration time.
2. **Entry-point smoke** — every registered engine must expose a
   discoverable entry point using the same prefix list
   `scripts/autonomous.py::_execute_engine` walks. Catches engines
   that renamed their `run_foo` to `scan_foo` but forgot to keep a
   matching prefix, and engines that were refactored into classes
   with no module-level entry function.
3. **Scheduler reachability smoke** — every registered engine must be
   reachable via its domain's `decide_next_action` rotation. This is
   the load-bearing check that would have caught spec_audit and
   curiosity_scanner. An engine that passes tests 1 and 2 but fails
   test 3 is exactly the "dead engine" class — imports, has an entry
   point, crashes on nothing, and still never runs in production.

The `UNREACHABLE_ENGINES_ALLOWLIST` below is the living TODO list of
engines that are intentionally not in routine rotation. Every entry
has a one-line justification. Every removal from the allowlist is a
PR that fixes a dead engine. The set should shrink over time, never
grow.
"""

from __future__ import annotations

import importlib
import inspect
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainRegistry

# Import the same registration helper the production scheduler uses so
# the test sees the exact same engine set as a live `./nebula` run.
sys.path.insert(0, str(ENGINE_ROOT / "scripts"))
from autonomous import _register_domains

# Prefix list copied verbatim from scripts/autonomous.py::_execute_engine.
# If that list changes, update this list and bump the test comment so
# someone reviewing a PR notices the drift.
_ENTRY_POINT_PREFIXES = (
    "persist_findings",
    "run_all",
    "run_",
    "scan_all",
    "check_all",
    "refresh_",
    "scan_",
    "check_",
    "analyze_",
    "detect_",
    "process_",
    "assess_",
    "build_",
    "get_build",
    "classify_",
    "evaluate_",
    "fetch_",
    "calculate_",
    "generate_",
)

# Engines that are intentionally NOT in routine rotation for their
# domain's `decide_next_action`. This set is the living TODO list of
# dead engines in the autonomous loop: every entry is a registered
# engine that currently never fires because its domain's
# `decide_next_action` only returns one engine per cycle (or a small
# subset gated on specific stale tags).
#
# The goal is for this set to shrink over time. Each entry removal is
# a PR that rewrites the domain's decide_next_action to rotate through
# all its engines (same pattern DevelopmentDomain, InvestigationDomain,
# EducationDomain, InteroperabilityDomain, and MarketingDomain got).
#
# v0.3.2 baseline (captured after smoke-test first run): 45 engines
# across 12 domains. This is "paint the current reality in red so we
# can pay it down" — the smoke test now passes because every dead
# engine is either fixed (3 that had no entry point got wrappers) or
# explicitly listed here as known-dead.
#
# Progress tracking:
# - v0.3.1 rotated: development (7), investigation (4)
# - v0.3.2 rotated: education (2), interoperability (3), marketing (4)
# - v0.3.2 added entry points: config_drift_detector,
#   pr_description_gen, test_runner
# - v0.3.2 remaining: 45 dead engines across 12 domains
UNREACHABLE_ENGINES_ALLOWLIST: set[str] = {
    # Security domain (9 registered, only urgent-branch adversarial_reviewer
    # fires from rotation; vuln_scanner fires from stale "security_scan" tag).
    # Fix: rotate all 9 engines through decide_next_action.
    "adversarial_reviewer",
    "attack_simulator",
    "attack_vector_scanner",  # added v0.5.1
    "cross_chain_cve_monitor",
    "cve_monitor",
    "exploit_scanner",
    "report_generator",
    "static_analyzer",
    # Community (4 registered, only contributor_tracker fires from "contributors" tag).
    "health_scorer",
    "sentiment_tracker",
    "talent_radar",
    # Contribution (4 registered, only pr_description_gen fires — see v0.3.2 fix).
    "auto_contributor",
    "pr_readiness",
    "tminusz_contributor",
    # Devops (4 registered, only test_runner via v0.3.2 entry point fix).
    "devnet_manager",
    "integration_tests",
    "rpc_client",
    # Economics (6 registered, only funnel_tracker fires from "funnel" tag).
    "liquidity_monitor",
    "staking_analyzer",
    "supply_tracker",
    "whale_watcher",
    "yield_calculator",
    # Governance (5 registered, only proposal_analyzer fires from "proposals" tag).
    "governance_intel",
    "pillar_accountability",
    "treasury_monitor",
    "voting_patterns",
    # Intelligence (6 registered, only signal_detector fires from "architecture" tag).
    "branch_watcher",  # added v0.5.8
    "ecosystem_health",
    "repo_relationship_mapper",
    "signal_router",
    "upstream_watcher",
    # Network health (4 registered, only node_census fires from "node_census" tag).
    "bridge_health",
    "decentralization_scorer",
    "pillar_monitor",
    # Product market fit (6 registered, only landscape_scanner fires).
    "adoption_tracker",
    "ecosystem_gap",
    "fork_detector",
    "roadmap_predictor",
    "technical_positioning",
    # Quality (5 registered, only test_coverage fires from "docs" tag).
    "build_verifier",
    "cross_repo_checker",
    "reference_diff",
    "spec_verifier",
    # Self-maintenance (2 registered, only engine_health_monitor
    # and config_drift_detector; engine_health wired via stale tag,
    # config_drift_detector got v0.3.2 entry point fix but still
    # needs the domain rotation to actually invoke it).
    "config_drift_detector",
    "engine_health_monitor",
    # Standards (3 registered, only bip_zip_tracker fires from "bip_tracking").
    "crypto_compliance",
    "deployment_pipeline",
}


@pytest.fixture(autouse=True)
def _reset_registry():
    """Each smoke test works against a freshly-initialized registry.

    The singleton survives across tests by default; resetting here
    prevents cross-test contamination when a test registers a mock
    domain and another test expects only the real ones.
    """
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


def _registered_engines():
    """Return `[(domain_name, engine_def), ...]` for all production engines."""
    registry = DomainRegistry.instance()
    _register_domains(registry)
    pairs: list[tuple[str, object]] = []
    for domain in registry.get_all_domains():
        for engine in domain.get_engines():
            pairs.append((domain.name(), engine))
    return pairs


class TestImportSmoke:
    """Every registered engine's module must import cleanly."""

    def test_every_engine_module_imports(self):
        broken: list[tuple[str, str, str]] = []
        for domain_name, engine in _registered_engines():
            try:
                importlib.import_module(engine.module_path)
            except Exception as exc:
                broken.append((domain_name, engine.name, str(exc)))
        assert not broken, (
            "Registered engines with broken module_path — fix the "
            "module path, fix the import error, or unregister the "
            "engine:\n" + "\n".join(f"  {d}.{e}: {err}" for d, e, err in broken)
        )


class TestEntryPointSmoke:
    """Every registered engine must expose a discoverable entry point."""

    def _find_entry_point(self, mod):
        """Mirror scripts/autonomous.py::_execute_engine discovery logic."""

        def _is_callable_no_required_args(fn):
            try:
                sig = inspect.signature(fn)
            except (ValueError, TypeError):
                return False
            for p in sig.parameters.values():
                if (
                    p.default is inspect.Parameter.empty
                    and p.kind
                    in (
                        inspect.Parameter.POSITIONAL_OR_KEYWORD,
                        inspect.Parameter.POSITIONAL_ONLY,
                    )
                    and p.name not in ("db_path", "specs", "self", "registry")
                ):
                    return False
            return True

        for prefix in _ENTRY_POINT_PREFIXES:
            for attr_name in sorted(dir(mod)):
                if not attr_name.startswith(prefix):
                    continue
                candidate = getattr(mod, attr_name)
                if not callable(candidate):
                    continue
                if _is_callable_no_required_args(candidate):
                    return candidate
        return None

    def test_every_engine_has_zero_required_arg_entry_point(self):
        broken: list[tuple[str, str]] = []
        for domain_name, engine in _registered_engines():
            try:
                mod = importlib.import_module(engine.module_path)
            except Exception:
                # Covered by TestImportSmoke — skip here to avoid
                # double-reporting the same failure.
                continue
            entry_fn = self._find_entry_point(mod)
            if entry_fn is None:
                broken.append((domain_name, engine.name))
        assert not broken, (
            "Registered engines with no discoverable entry point. "
            "Add a module-level function whose name starts with one of: "
            f"{', '.join(_ENTRY_POINT_PREFIXES[:6])}, …, accepts "
            "`db_path` as its only required argument:\n"
            + "\n".join(f"  {d}.{e}" for d, e in broken)
        )


class TestSchedulerReachability:
    """Every registered engine must be reachable via scheduler rotation.

    This is the load-bearing check that would have caught the v0.3.0
    spec_audit dead-engine bug the moment the PR hit CI.
    """

    def test_every_domain_yields_at_least_one_engine_in_routine_rotation(self):
        """Entire-domain-dead smoke check.

        Weak form: every domain should surface at least ONE engine in
        routine rotation. A domain yielding zero is the worst-case
        bug — the domain is unreachable. Per-engine reachability is
        the stronger check below.
        """
        registry = DomainRegistry.instance()
        _register_domains(registry)

        context = {"trigger_level": "routine", "stale_data": []}
        exclude: set[str] = set()
        reached_domains: set[str] = set()

        for _ in range(200):
            action = registry.decide_next_action(context, exclude=exclude)
            if action is None:
                break
            domain = action.get("domain", "")
            if domain:
                reached_domains.add(domain)
            key = f"{domain}:{action.get('action', '')}"
            exclude.add(key)

        all_domains = {d.name() for d in registry.get_all_domains()}
        dead_domains = all_domains - reached_domains
        assert not dead_domains, (
            f"Domain(s) registered but never reachable via scheduler "
            f"rotation: {sorted(dead_domains)}. Every domain MUST yield "
            "at least one engine in routine rotation (trigger_level=routine, "
            "empty stale_data). Fix the domain's decide_next_action to "
            "return a fallback candidate."
        )

    def test_every_engine_is_reachable_unless_in_allowlist(self):
        """Per-engine reachability smoke check.

        Strong form: every registered engine should eventually appear
        in scheduler rotation under the bootstrap context
        (trigger=routine, all topic tags stale, all domain tags stale).
        Engines that legitimately aren't in routine rotation belong in
        UNREACHABLE_ENGINES_ALLOWLIST with a one-line justification.
        """
        registry = DomainRegistry.instance()
        _register_domains(registry)

        # Use the same stale-tag bootstrap the real autonomous loop
        # uses, so trigger-gated engines get their shot.
        all_topics = [
            "contributors",
            "health",
            "sentiment",
            "docs",
            "onboarding",
            "architecture",
            "vision",
            "history",
            "literature",
            "bridge",
            "evm",
            "consensus",
            "external_chains",
            "narratives",
            "positioning",
            "dominance",
            "competitive_data",
            "landscape",
            "adoption",
            "roadmap",
            "surface",
            "engine_health",
            "config_drift",
            "bip_tracking",
            "deployment",
            "liquidity",
            "supply",
            "whales",
            "yields",
            "funnel",
            "hype",
            "proposals",
            "voting",
            "pillar_accountability",
            "pillars",
            "sentinels",
            "decentralization",
            "node_census",
            "specs",
            "spec_coverage",
            "security_scan",
            "exploit_scan",
            "cve_scan",
            "attack_simulation",
        ]
        context = {"trigger_level": "routine", "stale_data": all_topics}
        exclude: set[str] = set()
        reached_engines: set[str] = set()

        for _ in range(500):
            action = registry.decide_next_action(context, exclude=exclude)
            if action is None:
                break
            engine_name = action.get("engine", "")
            if engine_name:
                reached_engines.add(engine_name)
            key = f"{action.get('domain', '')}:{action.get('action', '')}"
            exclude.add(key)

        all_engines = {e.name for _, e in _registered_engines()}
        unreachable = all_engines - reached_engines - UNREACHABLE_ENGINES_ALLOWLIST

        assert not unreachable, (
            f"Registered engines that never fire in rotation: "
            f"{sorted(unreachable)}. Either add them to their domain's "
            "decide_next_action candidate list, or add to "
            "UNREACHABLE_ENGINES_ALLOWLIST in this file with a one-line "
            "justification explaining why they're trigger-gated out of "
            "routine rotation.\n\n"
            "This is the exact class of bug that shipped spec_audit dead "
            "in v0.3.0 and curiosity_scanner's library dead for three "
            "releases before v0.3.1."
        )

    def test_spec_audit_reaches_rotation(self):
        """Pin the v0.3.1 fix: spec_audit is now in rotation."""
        registry = DomainRegistry.instance()
        _register_domains(registry)

        exclude: set[str] = set()
        context = {"trigger_level": "routine", "stale_data": []}
        reached = set()
        for _ in range(50):
            action = registry.decide_next_action(context, exclude=exclude)
            if action is None:
                break
            reached.add(action.get("engine", ""))
            exclude.add(f"{action.get('domain', '')}:{action.get('action', '')}")
        assert "spec_audit" in reached

    def test_curiosity_scanner_reaches_rotation(self):
        """Pin the v0.3.1 fix: curiosity_scanner is now in rotation."""
        registry = DomainRegistry.instance()
        _register_domains(registry)

        exclude: set[str] = set()
        context = {"trigger_level": "routine", "stale_data": []}
        reached = set()
        for _ in range(50):
            action = registry.decide_next_action(context, exclude=exclude)
            if action is None:
                break
            reached.add(action.get("engine", ""))
            exclude.add(f"{action.get('domain', '')}:{action.get('action', '')}")
        assert "curiosity_scanner" in reached


class TestAllowlistHygiene:
    """Meta-tests that keep the dead-engine allowlist honest."""

    def test_allowlist_entries_are_actually_registered_engines(self):
        """No typos / stale entries in UNREACHABLE_ENGINES_ALLOWLIST.

        Every entry in the allowlist must be a currently-registered
        engine, otherwise the allowlist is accumulating stale names
        that will silently hide real bugs.
        """
        registered = {e.name for _, e in _registered_engines()}
        stale = UNREACHABLE_ENGINES_ALLOWLIST - registered
        assert not stale, (
            f"UNREACHABLE_ENGINES_ALLOWLIST contains engines that are "
            f"no longer registered (or never were): {sorted(stale)}. "
            "Remove these entries so the allowlist stays tight."
        )
