# SPDX-License-Identifier: MIT
"""Regression tests for ``domains.economics.engines.liquidity_monitor``.

Pin the `{"pairs": null}` crash observed in the v0.2.23 + v0.3.0 harden
runs on cycle ~300 / ~75: DexScreener responded with a valid JSON object
whose `pairs` key was set to JSON null rather than an array, the old
guard only checked key presence, `None` flowed through, and
`.sort(...)` crashed the engine every single cycle for the rest of the
run.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from domains.economics.engines import liquidity_monitor as lm


class TestFetchDexPairsGuards:
    """Pin the DexScreener response-shape edge cases."""

    def test_pairs_null_returns_empty(self):
        """`{"pairs": null}` must not crash — pin for the harden regression."""
        with patch.object(lm, "_get", return_value={"pairs": None}):
            assert lm.fetch_dex_pairs() == []

    def test_pairs_missing_returns_empty(self):
        """`{}` (key absent) returns empty list."""
        with patch.object(lm, "_get", return_value={}):
            assert lm.fetch_dex_pairs() == []

    def test_pairs_empty_list_returns_empty(self):
        """`{"pairs": []}` returns empty list without sort."""
        with patch.object(lm, "_get", return_value={"pairs": []}):
            assert lm.fetch_dex_pairs() == []

    def test_none_response_returns_empty(self):
        """HTTP layer returning `None` (network error) returns empty list."""
        with patch.object(lm, "_get", return_value=None):
            assert lm.fetch_dex_pairs() == []

    def test_pairs_populated_are_sorted_by_liquidity_desc(self):
        """Real pair list is sorted by liquidity USD descending."""
        fake = {
            "pairs": [
                {"pairAddress": "0xlow", "liquidity": {"usd": 10_000}},
                {"pairAddress": "0xhigh", "liquidity": {"usd": 500_000}},
                {"pairAddress": "0xmid", "liquidity": {"usd": 100_000}},
            ]
        }
        with patch.object(lm, "_get", return_value=fake):
            pairs = lm.fetch_dex_pairs()
        assert [p["pairAddress"] for p in pairs] == ["0xhigh", "0xmid", "0xlow"]

    def test_pair_with_null_liquidity_does_not_crash_sort(self):
        """A pair whose `liquidity.usd` is `None` sorts as 0, not a crash."""
        fake = {
            "pairs": [
                {"pairAddress": "0xa", "liquidity": {"usd": None}},
                {"pairAddress": "0xb", "liquidity": {"usd": 5_000}},
            ]
        }
        with patch.object(lm, "_get", return_value=fake):
            pairs = lm.fetch_dex_pairs()
        assert pairs[0]["pairAddress"] == "0xb"
