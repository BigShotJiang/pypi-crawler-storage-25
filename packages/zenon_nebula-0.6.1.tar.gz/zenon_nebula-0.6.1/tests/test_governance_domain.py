# SPDX-License-Identifier: MIT
"""Tests for domains.governance.domain -- AZ treasury and voting analysis."""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.governance.domain import GovernanceDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestGovernanceDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(GovernanceDomain, DomainPlugin)

    def test_name(self):
        assert GovernanceDomain().name() == "governance"

    def test_get_engines_non_empty(self):
        engines = GovernanceDomain().get_engines()
        assert len(engines) >= 2
        names = [e.name for e in engines]
        assert "treasury_monitor" in names
        assert "proposal_analyzer" in names

    def test_get_hypothesis_types_non_empty(self):
        types = GovernanceDomain().get_hypothesis_types()
        assert len(types) >= 1
        ids = [t.type_id for t in types]
        assert "treasury_sustainability" in ids

    def test_get_aspiration_types(self):
        assert isinstance(GovernanceDomain().get_aspiration_types(), list)

    def test_get_collision_signals(self):
        assert isinstance(GovernanceDomain().get_collision_signals(), list)

    def test_get_war_room_contributions(self):
        assert isinstance(GovernanceDomain().get_war_room_contributions(), list)

    def test_get_self_improvement_metrics(self):
        metrics = GovernanceDomain().get_self_improvement_metrics()
        assert isinstance(metrics, dict)

    def test_get_db_schema_sql(self):
        sql = GovernanceDomain().get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action(self):
        action = GovernanceDomain().decide_next_action({})
        assert action is None or isinstance(action, dict)

    def test_registration(self):
        registry = DomainRegistry.instance()
        registry.register(GovernanceDomain())
        assert registry.get_domain("governance") is not None
