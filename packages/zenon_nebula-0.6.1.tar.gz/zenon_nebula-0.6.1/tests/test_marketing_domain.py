# SPDX-License-Identifier: MIT
"""Tests for domains.marketing.domain -- Marketing intelligence."""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.marketing.domain import MarketingDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestMarketingDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(MarketingDomain, DomainPlugin)

    def test_name(self):
        assert MarketingDomain().name() == "marketing"

    def test_get_engines_non_empty(self):
        engines = MarketingDomain().get_engines()
        assert len(engines) >= 1
        names = [e.name for e in engines]
        assert "narrative_analyzer" in names

    def test_get_hypothesis_types_non_empty(self):
        types = MarketingDomain().get_hypothesis_types()
        assert len(types) >= 1

    def test_get_aspiration_types(self):
        assert isinstance(MarketingDomain().get_aspiration_types(), list)

    def test_get_collision_signals(self):
        assert isinstance(MarketingDomain().get_collision_signals(), list)

    def test_get_war_room_contributions(self):
        assert isinstance(MarketingDomain().get_war_room_contributions(), list)

    def test_get_self_improvement_metrics(self):
        metrics = MarketingDomain().get_self_improvement_metrics()
        assert isinstance(metrics, dict)

    def test_get_db_schema_sql(self):
        sql = MarketingDomain().get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action(self):
        action = MarketingDomain().decide_next_action({})
        assert action is None or isinstance(action, dict)

    def test_priority_is_low(self):
        """Marketing should have lower priority than core domains."""
        assert MarketingDomain().get_priority() >= 5

    def test_registration(self):
        registry = DomainRegistry.instance()
        registry.register(MarketingDomain())
        assert registry.get_domain("marketing") is not None
