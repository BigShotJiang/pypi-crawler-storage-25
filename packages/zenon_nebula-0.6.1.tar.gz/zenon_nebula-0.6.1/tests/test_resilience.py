# SPDX-License-Identifier: MIT
"""
Tests for core.resilience -- Crash recovery and checkpoint system.

Tests CheckpointManager save/load/resume, engine completion/failure
tracking, should_pause after 5 failures, GracefulShutdown signal
handling, check_disk_space, and check_db_integrity.
"""

import signal
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persist_to_db import ensure_schema
from core.resilience import (
    CheckpointManager,
    GracefulShutdown,
    RetryWithBackoff,
    check_db_integrity,
    check_disk_space,
    startup_checks,
)


@pytest.fixture
def checkpoint(tmp_path):
    path = str(tmp_path / "checkpoint.json")
    return CheckpointManager(checkpoint_path=path)


class TestCheckpointManager:
    """Test checkpoint save/load/resume."""

    def test_fresh_state(self, checkpoint):
        """Fresh checkpoint starts with zero cycles."""
        assert checkpoint.state["cycle_number"] == 0
        assert checkpoint.state["total_cycles"] == 0
        assert checkpoint.state["engines_completed_this_cycle"] == []

    def test_save_and_reload(self, tmp_path):
        """Checkpoint persists across reloads."""
        path = str(tmp_path / "cp.json")
        cp = CheckpointManager(checkpoint_path=path)
        cp.state["cycle_number"] = 5
        cp.save()

        cp2 = CheckpointManager(checkpoint_path=path)
        assert cp2.state["cycle_number"] == 5

    def test_engine_completed(self, checkpoint):
        checkpoint.engine_completed("engine_a")
        assert "engine_a" in checkpoint.state["engines_completed_this_cycle"]
        assert checkpoint.state["consecutive_failures"] == 0

    def test_engine_completed_dedup(self, checkpoint):
        """Completing same engine twice does not create duplicates."""
        checkpoint.engine_completed("engine_a")
        checkpoint.engine_completed("engine_a")
        assert checkpoint.state["engines_completed_this_cycle"].count("engine_a") == 1

    def test_engine_failed(self, checkpoint):
        checkpoint.engine_failed("engine_x", "connection timeout")
        assert checkpoint.state["consecutive_failures"] == 1
        assert len(checkpoint.state["engines_failed_this_cycle"]) == 1
        assert checkpoint.state["engines_failed_this_cycle"][0]["engine"] == "engine_x"

    def test_cycle_completed(self, checkpoint):
        checkpoint.engine_completed("engine_a")
        checkpoint.cycle_completed()

        assert checkpoint.state["cycle_number"] == 1
        assert checkpoint.state["total_cycles"] == 1
        assert checkpoint.state["engines_completed_this_cycle"] == []
        assert checkpoint.state["consecutive_failures"] == 0

    def test_should_skip_engine(self, checkpoint):
        """Engine already completed this cycle should be skipped on resume."""
        checkpoint.engine_completed("engine_a")
        assert checkpoint.should_skip_engine("engine_a") is True
        assert checkpoint.should_skip_engine("engine_b") is False

    def test_should_pause_after_5_failures(self, checkpoint):
        """Pauses after 5 consecutive failures."""
        for i in range(4):
            checkpoint.engine_failed(f"engine_{i}", "error")
        assert checkpoint.should_pause() is False

        checkpoint.engine_failed("engine_4", "error")
        assert checkpoint.should_pause() is True

    def test_should_pause_resets_on_success(self, checkpoint):
        """Consecutive failures reset on engine success."""
        for i in range(4):
            checkpoint.engine_failed(f"engine_{i}", "error")
        checkpoint.engine_completed("good_engine")
        assert checkpoint.should_pause() is False

    def test_get_resume_info_mid_cycle(self, checkpoint):
        checkpoint.engine_completed("engine_a")
        checkpoint.engine_failed("engine_b", "error")

        info = checkpoint.get_resume_info()
        assert info["was_mid_cycle"] is True
        assert "engine_a" in info["engines_completed"]
        assert "engine_b" in info["engines_failed"]

    def test_get_resume_info_clean(self, checkpoint):
        info = checkpoint.get_resume_info()
        assert info["was_mid_cycle"] is False

    def test_commons_synced(self, checkpoint):
        checkpoint.commons_synced()
        assert checkpoint.state["last_commons_sync"] is not None

    def test_war_room_completed(self, checkpoint):
        checkpoint.war_room_completed()
        assert checkpoint.state["last_war_room"] is not None

    def test_corrupt_checkpoint_starts_fresh(self, tmp_path):
        """Corrupt checkpoint file is handled gracefully."""
        path = tmp_path / "cp.json"
        path.write_text("{invalid json")
        cp = CheckpointManager(checkpoint_path=str(path))
        assert cp.state["cycle_number"] == 0


class TestGracefulShutdown:
    """Test graceful shutdown signal handling."""

    def test_initial_state(self):
        gs = GracefulShutdown()
        assert gs.should_stop is False

    def test_signal_sets_shutdown(self):
        gs = GracefulShutdown()
        # Simulate signal
        gs._handle(signal.SIGTERM, None)
        assert gs.should_stop is True


class TestRetryWithBackoff:
    """Test exponential backoff iterator."""

    def test_iterates_max_retries(self):
        retry = RetryWithBackoff(max_retries=3)
        attempts = list(retry)
        assert attempts == [1, 2, 3]

    def test_stops_after_max(self):
        retry = RetryWithBackoff(max_retries=2)
        it = iter(retry)
        next(it)
        next(it)
        with pytest.raises(StopIteration):
            next(it)

    def test_wait_increases(self):
        """Backoff delay increases with attempts."""
        retry = RetryWithBackoff(max_retries=5, base_delay=0.001, max_delay=1.0)
        it = iter(retry)
        next(it)  # attempt 1
        d1 = retry.wait()
        next(it)  # attempt 2
        # We can't assert d2 > d1 due to jitter, but both should be small
        assert d1 >= 0


class TestDiskSpace:
    def test_returns_bool(self):
        result = check_disk_space(min_mb=1)
        assert isinstance(result, bool)

    def test_reasonable_threshold(self):
        """With a very low threshold, disk should have space."""
        assert check_disk_space(min_mb=1) is True


class TestDBIntegrity:
    def test_healthy_db(self, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        result = check_db_integrity(db)
        assert result["ok"] is True
        assert result["result"] == "ok"

    def test_nonexistent_db(self, tmp_path):
        """Non-existent DB path does not crash."""
        db = str(tmp_path / "nonexistent.db")
        result = check_db_integrity(db)
        # SQLite creates the file, so integrity_check returns ok
        assert isinstance(result["ok"], bool)


class TestStartupChecks:
    def test_returns_summary(self, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        result = startup_checks(db_path=db)
        assert "disk_space" in result
        assert "db_integrity" in result
        assert "checkpoint" in result
