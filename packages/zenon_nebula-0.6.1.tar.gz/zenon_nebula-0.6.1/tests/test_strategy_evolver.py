# SPDX-License-Identifier: MIT
"""
Tests for core.strategy_evolver -- OOBE evolution cycle.

Tests observe/analyze/discover/test/evolve phases, domain
classification (ACCELERATING/STABLE/DECLINING/STALLED), and
resource allocation.
"""

import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persist_to_db import ensure_schema
from core.strategy_evolver import (
    ACCEL_THRESHOLD,
    STABLE_FLOOR,
    StrategyEvolver,
)


@pytest.fixture
def db_path(tmp_path):
    db = str(tmp_path / "test_engine.db")
    ensure_schema(db)
    return db


def _insert_evidence(db_path, domain, count, days_ago=3):
    """Insert evidence records for a domain within recent window."""
    conn = sqlite3.connect(db_path)
    ts = (datetime.now(timezone.utc) - timedelta(days=days_ago)).isoformat()
    for i in range(count):
        conn.execute(
            "INSERT INTO evidence (domain, engine, evidence_type, finding, "
            "confidence, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
            (domain, "test_engine", "test", f"finding_{i}", 0.7, ts),
        )
    conn.commit()
    conn.close()


def _insert_old_evidence(db_path, domain, count):
    """Insert evidence from the previous week (8-14 days ago)."""
    conn = sqlite3.connect(db_path)
    ts = (datetime.now(timezone.utc) - timedelta(days=10)).isoformat()
    for i in range(count):
        conn.execute(
            "INSERT INTO evidence (domain, engine, evidence_type, finding, "
            "confidence, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
            (domain, "test_engine", "test", f"old_finding_{i}", 0.7, ts),
        )
    conn.commit()
    conn.close()


class TestObserve:
    """Test the OBSERVE phase."""

    def test_empty_db(self, db_path):
        evolver = StrategyEvolver(db_path=db_path)
        obs = evolver._observe()
        assert obs["total_evidence"] == 0
        assert obs["domains"] == {}

    def test_counts_evidence_by_domain(self, db_path):
        _insert_evidence(db_path, "security", 5)
        _insert_evidence(db_path, "quality", 3)

        evolver = StrategyEvolver(db_path=db_path)
        obs = evolver._observe()

        assert "security" in obs["domains"]
        assert obs["domains"]["security"]["evidence_7d"] == 5
        assert obs["domains"]["quality"]["evidence_7d"] == 3

    def test_old_evidence_excluded(self, db_path):
        """Evidence older than 7 days is not counted in observe."""
        _insert_old_evidence(db_path, "security", 10)

        evolver = StrategyEvolver(db_path=db_path)
        obs = evolver._observe()

        # Old evidence won't appear in 7d window
        if "security" in obs["domains"]:
            assert obs["domains"]["security"]["evidence_7d"] == 0
        else:
            pass  # Not in domains at all, which is also correct


class TestAnalyze:
    """Test the ANALYZE phase -- domain classification."""

    def test_accelerating_classification(self, db_path):
        """Domain with many findings and growth classified as ACCELERATING."""
        _insert_old_evidence(db_path, "security", 5)
        _insert_evidence(db_path, "security", ACCEL_THRESHOLD + 5)

        evolver = StrategyEvolver(db_path=db_path)
        obs = evolver._observe()
        analysis = evolver._analyze(obs)

        status = analysis["domain_statuses"]["security"]
        assert status["classification"] == "ACCELERATING"
        assert analysis["accelerating_count"] >= 1

    def test_stable_classification(self, db_path):
        """Domain with moderate activity classified as STABLE."""
        _insert_evidence(db_path, "quality", STABLE_FLOOR + 1)

        evolver = StrategyEvolver(db_path=db_path)
        obs = evolver._observe()
        analysis = evolver._analyze(obs)

        status = analysis["domain_statuses"]["quality"]
        assert status["classification"] == "STABLE"

    def test_stalled_classification(self, db_path):
        """Domain with zero findings classified as STALLED."""
        # Insert into actions_log so domain appears, but no evidence
        conn = sqlite3.connect(db_path)
        ts = (datetime.now(timezone.utc) - timedelta(days=3)).isoformat()
        conn.execute(
            "INSERT INTO actions_log (domain, module, action, timestamp) "
            "VALUES ('stalled_domain', 'test', 'check', ?)",
            (ts,),
        )
        conn.commit()
        conn.close()

        evolver = StrategyEvolver(db_path=db_path)
        obs = evolver._observe()
        analysis = evolver._analyze(obs)

        if "stalled_domain" in analysis["domain_statuses"]:
            status = analysis["domain_statuses"]["stalled_domain"]
            assert status["classification"] == "STALLED"

    def test_declining_classification(self, db_path):
        """Domain with fewer findings than previous week is DECLINING."""
        _insert_old_evidence(db_path, "declining_dom", 10)
        _insert_evidence(db_path, "declining_dom", 1)

        evolver = StrategyEvolver(db_path=db_path)
        obs = evolver._observe()
        analysis = evolver._analyze(obs)

        status = analysis["domain_statuses"]["declining_dom"]
        assert status["classification"] == "DECLINING"
        assert status["trend"] == "down"

    def test_empty_domains(self, db_path):
        evolver = StrategyEvolver(db_path=db_path)
        analysis = evolver._analyze({"domains": {}})
        assert analysis["domain_statuses"] == {}
        assert analysis["stalled_count"] == 0


class TestDiscover:
    """Test the DISCOVER phase."""

    def test_no_stalled_skips(self, db_path):
        """No stalled domains means discovery is skipped."""
        evolver = StrategyEvolver(db_path=db_path)
        analysis = {"stalled_count": 0, "domain_statuses": {}}
        result = evolver._discover(analysis)
        assert result["skipped"] is True

    def test_no_llm_skips(self, db_path):
        """Without LLM configured, discovery is skipped but reports stalled domains."""
        evolver = StrategyEvolver(db_path=db_path)
        analysis = {
            "stalled_count": 1,
            "domain_statuses": {"test_dom": {"classification": "STALLED"}},
        }
        result = evolver._discover(analysis)
        assert result["skipped"] is True
        assert "no LLM configured" in result["reason"]


class TestEvolve:
    """Test the EVOLVE phase -- resource allocation."""

    def test_accelerating_promoted(self, db_path):
        evolver = StrategyEvolver(db_path=db_path)
        analysis = {
            "domain_statuses": {
                "fast_dom": {"classification": "ACCELERATING"},
                "slow_dom": {"classification": "STALLED"},
            }
        }
        changes = evolver._evolve(analysis)

        assert "fast_dom" in changes["promoted"]
        assert "slow_dom" in changes["deprioritized"]
        assert changes["rebalanced"] is True

    def test_resource_allocation_proportional(self, db_path):
        evolver = StrategyEvolver(db_path=db_path)
        analysis = {
            "domain_statuses": {
                "accel": {"classification": "ACCELERATING"},
                "stable": {"classification": "STABLE"},
            }
        }
        changes = evolver._evolve(analysis)
        alloc = changes["resource_allocation"]

        # Accelerating should get higher allocation than stable
        assert alloc["accel"] > alloc["stable"]


class TestFullCycle:
    """Test the complete evolution cycle."""

    def test_dry_run(self, db_path):
        _insert_evidence(db_path, "security", 5)

        evolver = StrategyEvolver(db_path=db_path)
        result = evolver.run_evolution_cycle(dry_run=True)

        assert result["dry_run"] is True
        assert "observe" in result
        assert "analyze" in result
        assert "discover" in result
        assert "test" in result
        assert "evolve" in result
        assert "elapsed_seconds" in result

    def test_full_cycle_persists(self, db_path):
        _insert_evidence(db_path, "security", 5)

        evolver = StrategyEvolver(db_path=db_path)
        evolver.run_evolution_cycle(dry_run=False)

        conn = sqlite3.connect(db_path)
        count = conn.execute("SELECT COUNT(*) FROM strategy_cycles").fetchone()[0]
        conn.close()
        assert count >= 1

    def test_empty_db_cycle(self, db_path):
        """Full cycle on empty DB completes without error."""
        evolver = StrategyEvolver(db_path=db_path)
        result = evolver.run_evolution_cycle(dry_run=True)
        assert "elapsed_seconds" in result
