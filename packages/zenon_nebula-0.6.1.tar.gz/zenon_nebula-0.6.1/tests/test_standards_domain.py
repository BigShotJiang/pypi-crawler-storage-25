# SPDX-License-Identifier: MIT
"""Tests for domains.standards.domain -- BIP/SLIP compliance and crypto checks."""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.standards.domain import StandardsDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestStandardsDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(StandardsDomain, DomainPlugin)

    def test_name(self):
        assert StandardsDomain().name() == "standards"

    def test_get_engines_non_empty(self):
        engines = StandardsDomain().get_engines()
        assert len(engines) >= 1

    def test_get_hypothesis_types_non_empty(self):
        types = StandardsDomain().get_hypothesis_types()
        assert len(types) >= 1

    def test_get_aspiration_types(self):
        assert isinstance(StandardsDomain().get_aspiration_types(), list)

    def test_get_collision_signals(self):
        assert isinstance(StandardsDomain().get_collision_signals(), list)

    def test_get_war_room_contributions(self):
        assert isinstance(StandardsDomain().get_war_room_contributions(), list)

    def test_get_self_improvement_metrics(self):
        metrics = StandardsDomain().get_self_improvement_metrics()
        assert isinstance(metrics, dict)

    def test_get_db_schema_sql(self):
        sql = StandardsDomain().get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action(self):
        action = StandardsDomain().decide_next_action({})
        assert action is None or isinstance(action, dict)

    def test_registration(self):
        registry = DomainRegistry.instance()
        registry.register(StandardsDomain())
        assert registry.get_domain("standards") is not None
