# SPDX-License-Identifier: MIT
"""Tests for core.model_router -- LLM model routing and cost estimation."""

import pytest

import core.model_router as router_mod
from core.model_router import (
    estimate_cost,
    get_all_routes,
    get_cheap_claude,
    get_fast_model,
    get_investigation_model,
    get_max_tokens,
    get_model,
    get_route_info,
    get_strategic_model,
    get_validation_model,
    get_workhorse_model,
    reload_config,
)


@pytest.fixture(autouse=True)
def reset_config():
    """Reset the cached config before each test."""
    router_mod._config = None
    yield
    router_mod._config = None


class TestRouteSelection:
    def test_strategic_synthesis_route(self):
        model = get_model("strategic_synthesis")
        assert "opus" in model.lower() or model  # should return configured model

    def test_content_generation_route(self):
        model = get_model("content_generation")
        assert model  # non-empty

    def test_classification_route(self):
        model = get_model("classification")
        assert model

    def test_unknown_task_returns_fallback(self):
        model = get_model("totally_unknown_task_xyz")
        assert model  # should return the fallback, not empty

    def test_get_max_tokens(self):
        tokens = get_max_tokens("strategic_synthesis")
        assert isinstance(tokens, int)
        assert tokens > 0

    def test_get_max_tokens_unknown_defaults(self):
        tokens = get_max_tokens("nonexistent_route")
        assert tokens == 4000  # default


class TestConvenienceMethods:
    def test_strategic_model(self):
        m = get_strategic_model()
        assert isinstance(m, str)
        assert len(m) > 0

    def test_workhorse_model(self):
        m = get_workhorse_model()
        assert isinstance(m, str)

    def test_fast_model(self):
        m = get_fast_model()
        assert isinstance(m, str)

    def test_cheap_claude(self):
        m = get_cheap_claude()
        assert isinstance(m, str)

    def test_investigation_model(self):
        m = get_investigation_model()
        assert isinstance(m, str)

    def test_validation_model(self):
        m = get_validation_model()
        assert isinstance(m, str)


class TestRouteInfo:
    def test_existing_route_has_model(self):
        info = get_route_info("strategic_synthesis")
        assert "model" in info

    def test_unknown_route_returns_empty_dict(self):
        info = get_route_info("nonexistent")
        assert info == {}

    def test_get_all_routes(self):
        routes = get_all_routes()
        assert isinstance(routes, dict)
        assert len(routes) > 0
        assert "strategic_synthesis" in routes


class TestCostEstimation:
    def test_estimate_with_known_route(self):
        cost = estimate_cost("strategic_synthesis", input_tokens=1000, output_tokens=500)
        assert isinstance(cost, float)
        assert cost > 0

    def test_estimate_scales_with_tokens(self):
        cost_small = estimate_cost("strategic_synthesis", input_tokens=100, output_tokens=50)
        cost_large = estimate_cost("strategic_synthesis", input_tokens=10000, output_tokens=5000)
        assert cost_large > cost_small

    def test_zero_tokens_zero_cost(self):
        cost = estimate_cost("strategic_synthesis", input_tokens=0, output_tokens=0)
        assert cost == 0.0

    def test_unknown_route_uses_defaults(self):
        cost = estimate_cost("nonexistent", input_tokens=1000, output_tokens=500)
        assert isinstance(cost, float)
        assert cost > 0  # uses default cost rates


class TestFallbackBehavior:
    def test_missing_config_file(self, tmp_path, monkeypatch):
        """When config file doesn't exist, should use empty defaults."""
        monkeypatch.setattr(router_mod, "ENGINE_ROOT", tmp_path)
        router_mod._config = None
        model = get_model("strategic_synthesis")
        # Falls back to defaults.fallback_model or hardcoded "claude-sonnet-4-6"
        assert isinstance(model, str)

    def test_reload_config(self):
        reload_config()
        routes = get_all_routes()
        assert isinstance(routes, dict)
