# SPDX-License-Identifier: MIT
"""Tests for core.repo_graph."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from core import repo_graph


def _make_repo(root: Path, name: str, files: dict[str, str]) -> Path:
    """Create a fake git repo with the given files."""
    repo = root / name
    repo.mkdir(parents=True, exist_ok=True)
    (repo / ".git").mkdir(exist_ok=True)
    for rel, content in files.items():
        target = repo / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)
    return repo


# ---------------------------------------------------------------------------
# Smoke + API surface
# ---------------------------------------------------------------------------


def test_module_imports():
    """Core module must import with its full public surface."""
    assert callable(repo_graph.build_dependency_graph)
    assert callable(repo_graph.find_upstream_forks)
    assert callable(repo_graph.get_dependents)
    assert callable(repo_graph.persist_graph)
    assert isinstance(repo_graph.SCHEMA_SQL, str)
    assert "CREATE TABLE" in repo_graph.SCHEMA_SQL


def test_build_dependency_graph_missing_workspace_returns_empty(tmp_path):
    """Missing workspace should return an empty graph, never raise."""
    missing = tmp_path / "does" / "not" / "exist"
    graph = repo_graph.build_dependency_graph(str(missing))
    assert graph["nodes"] == []
    assert graph["edges"] == []


def test_build_dependency_graph_empty_workspace(tmp_path):
    """Empty workspace = empty graph."""
    graph = repo_graph.build_dependency_graph(str(tmp_path))
    assert graph["nodes"] == []
    assert graph["edges"] == []


# ---------------------------------------------------------------------------
# Manifest parsing
# ---------------------------------------------------------------------------


def test_parse_go_mod(tmp_path):
    """Parse a go.mod with require block and inline require."""
    go_mod = tmp_path / "go.mod"
    go_mod.write_text(
        "module github.com/example/root\n"
        "go 1.25\n"
        "require (\n"
        "    github.com/zenon-network/go-zenon v0.1.0\n"
        "    golang.org/x/crypto v0.31.0\n"
        ")\n"
        "require github.com/single/dep v1.0.0\n"
    )
    deps = repo_graph.parse_manifest(go_mod)
    names = {d["name"] for d in deps}
    assert "github.com/zenon-network/go-zenon" in names
    assert "golang.org/x/crypto" in names
    assert "github.com/single/dep" in names


def test_parse_pubspec_yaml(tmp_path):
    """Parse pubspec.yaml picking up nested dependency entries."""
    pub = tmp_path / "pubspec.yaml"
    pub.write_text(
        "name: my_app\n"
        "dependencies:\n"
        "  znn_sdk_dart: ^0.1.0\n"
        "  json_rpc_2: ^3.0.0\n"
        "dev_dependencies:\n"
        "  test: ^1.24.0\n"
    )
    deps = repo_graph.parse_manifest(pub)
    names = {d["name"] for d in deps}
    assert "znn_sdk_dart" in names
    assert "json_rpc_2" in names
    assert "test" in names


def test_parse_package_json(tmp_path):
    """Parse package.json dependencies + devDependencies."""
    pkg = tmp_path / "package.json"
    pkg.write_text(
        '{"name": "x", "dependencies": {"a": "^1.0.0"}, "devDependencies": {"b": "~2.0.0"}}'
    )
    deps = repo_graph.parse_manifest(pkg)
    names = {d["name"] for d in deps}
    assert "a" in names
    assert "b" in names


def test_parse_cargo_toml(tmp_path):
    """Parse Cargo.toml with inline and map-style dependencies."""
    cargo = tmp_path / "Cargo.toml"
    cargo.write_text(
        "[package]\n"
        'name = "demo"\n'
        'version = "0.1.0"\n'
        "\n"
        "[dependencies]\n"
        'serde = "1.0"\n'
        'tokio = { version = "1.35", features = ["full"] }\n'
    )
    deps = repo_graph.parse_manifest(cargo)
    names = {d["name"] for d in deps}
    assert "serde" in names
    assert "tokio" in names


def test_parse_requirements_txt(tmp_path):
    """Parse requirements.txt skipping comments and flags."""
    req = tmp_path / "requirements.txt"
    req.write_text("# comment\nrequests>=2.32.0\npytest~=7.4\n-r other.txt\n")
    deps = repo_graph.parse_manifest(req)
    names = {d["name"] for d in deps}
    assert "requests" in names
    assert "pytest" in names


def test_parse_manifest_unknown_returns_empty(tmp_path):
    """Unknown manifest names return empty list."""
    random_file = tmp_path / "random.toml"
    random_file.write_text("oops")
    assert repo_graph.parse_manifest(random_file) == []


# ---------------------------------------------------------------------------
# Graph building with real repo layout
# ---------------------------------------------------------------------------


def _populated_workspace(tmp_path: Path) -> Path:
    """Create a small workspace with two Go repos where repo B depends on A."""
    _make_repo(
        tmp_path,
        "repo_a",
        {
            "go.mod": "module github.com/example/repo_a\ngo 1.25\n",
        },
    )
    _make_repo(
        tmp_path,
        "repo_b",
        {
            "go.mod": (
                "module github.com/example/repo_b\n"
                "go 1.25\n"
                "require github.com/example/repo_a v0.0.1\n"
            ),
        },
    )
    return tmp_path


def test_build_dependency_graph_resolves_internal_module(tmp_path):
    """An intra-workspace module reference should resolve to a target repo."""
    workspace = _populated_workspace(tmp_path)
    graph = repo_graph.build_dependency_graph(str(workspace))
    assert len(graph["nodes"]) == 2
    edges = [e for e in graph["edges"] if e["source"] == "repo_b"]
    assert edges, "expected repo_b to have at least one edge"
    assert any(e["target"] == "repo_a" and e["resolved"] for e in edges)


def test_graph_summary_counts(tmp_path):
    """graph_summary returns reasonable counters."""
    workspace = _populated_workspace(tmp_path)
    graph = repo_graph.build_dependency_graph(str(workspace))
    summary = repo_graph.graph_summary(graph)
    assert summary["nodes"] == 2
    assert summary["edges"] >= 1
    assert summary["resolved_edges"] >= 1
    assert "go" in summary["by_ecosystem"]


# ---------------------------------------------------------------------------
# Persistence + dependents
# ---------------------------------------------------------------------------


def test_persist_graph_and_get_dependents(tmp_path, db_path):
    """persist_graph should round-trip into get_dependents."""
    workspace = _populated_workspace(tmp_path)
    graph = repo_graph.build_dependency_graph(str(workspace))
    inserted = repo_graph.persist_graph(graph, db_path)
    assert inserted >= 1
    dependents = repo_graph.get_dependents("repo_a", db_path)
    assert "repo_b" in dependents


def test_get_dependents_empty_for_unknown_repo(db_path):
    """Looking up an unknown repo returns an empty list (no table = empty)."""
    assert repo_graph.get_dependents("nonexistent", db_path) == []


# ---------------------------------------------------------------------------
# Fork detection (git remote parsing)
# ---------------------------------------------------------------------------


def test_find_upstream_forks_no_workspace(tmp_path):
    """Missing workspace yields empty list."""
    assert repo_graph.find_upstream_forks(str(tmp_path / "missing")) == []


def test_find_upstream_forks_detects_fork(tmp_path):
    """A repo with distinct origin + upstream remotes is a fork pair."""
    _make_repo(tmp_path, "fork_repo", {"README.md": "hi"})
    remote_output = (
        "origin\thttps://github.com/mehowz/fork_repo.git (fetch)\n"
        "origin\thttps://github.com/mehowz/fork_repo.git (push)\n"
        "upstream\thttps://github.com/upstream-org/fork_repo.git (fetch)\n"
        "upstream\thttps://github.com/upstream-org/fork_repo.git (push)\n"
    )
    with patch.object(repo_graph, "_git_remote_v", return_value=remote_output):
        pairs = repo_graph.find_upstream_forks(str(tmp_path))
    assert any(p[0] == "fork_repo" for p in pairs)


def test_normalize_remote_url_equivalence():
    """git@ and https URLs normalize to the same string."""
    ssh = repo_graph._normalize_remote_url("git@github.com:foo/bar.git")
    https = repo_graph._normalize_remote_url("https://github.com/foo/bar")
    assert ssh == https
