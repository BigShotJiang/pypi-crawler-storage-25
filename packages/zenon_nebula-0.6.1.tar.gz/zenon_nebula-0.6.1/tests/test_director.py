# SPDX-License-Identifier: MIT
"""
Tests for core.director -- Unified Director.

Uses a temporary SQLite database with real schema and test data
to validate landscape queries, engine prioritization, stall detection,
and aspiration generation (with mock LLM).
"""

import sqlite3

# Ensure engine root on path
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.director import Aspiration, UnifiedDirector
from core.domain_registry import DomainRegistry
from core.persist_to_db import ensure_schema


@pytest.fixture
def db_path(tmp_path):
    """Create a temporary database with schema and test data."""
    db = str(tmp_path / "test_engine.db")
    ensure_schema(db)

    conn = sqlite3.connect(db)

    # Insert evidence across domains
    for domain, engine, finding, conf in [
        ("intelligence", "upstream_watcher", "New commit on go-zenon", 0.9),
        ("intelligence", "signal_detector", "Breaking change detected", 0.7),
        ("development", "spec_tracker", "htlc spec found", 0.8),
        ("development", "impl_coverage", "SDK missing htlc impl", 0.6),
        ("security", "adversarial_reviewer", "Fund lock path in htlc.go", 0.85),
        ("security", "vuln_scanner", "Unchecked error in htlc.go", 0.5),
        ("quality", "spec_verifier", "ABI mismatch in htlc", 0.95),
        ("quality", "build_verifier", "Go build passes", 0.99),
        ("contribution", "pr_readiness", "PR tier1 pass", 0.7),
    ]:
        conn.execute(
            "INSERT INTO evidence (domain, engine, evidence_type, "
            "finding, confidence) VALUES (?, ?, ?, ?, ?)",
            (domain, engine, "test", finding, conf),
        )

    # Insert hypotheses
    for hyp_id, domain, title, conf in [
        ("H001", "security", "Fund lock vector in htlc.go", 0.7),
        ("H002", "development", "htlc spec coverage gap", 0.5),
        ("H003", "quality", "ABI mismatch htlc", 0.9),
    ]:
        conn.execute(
            "INSERT INTO hypotheses (id, domain, title, confidence, "
            "status) VALUES (?, ?, ?, ?, 'INVESTIGATING')",
            (hyp_id, domain, title, conf),
        )

    # Insert supporting evidence for convergence
    conn.execute(
        "INSERT INTO evidence (domain, engine, evidence_type, finding, "
        "confidence, supports_hypothesis) VALUES "
        "('security', 'adversarial_reviewer', 'test', "
        "'confirms fund lock', 0.85, 'H001')"
    )
    conn.execute(
        "INSERT INTO evidence (domain, engine, evidence_type, finding, "
        "confidence, supports_hypothesis) VALUES "
        "('quality', 'spec_verifier', 'test', "
        "'ABI shows fund lock', 0.75, 'H001')"
    )

    conn.commit()
    conn.close()
    return db


class TestEvidenceLandscape:
    """Test evidence landscape query."""

    def test_evidence_by_domain(self, db_path):
        director = UnifiedDirector(db_path=db_path)
        landscape = director.get_evidence_landscape()

        assert "evidence_by_domain" in landscape
        domains = landscape["evidence_by_domain"]
        assert "intelligence" in domains
        assert "security" in domains
        assert "quality" in domains
        assert domains["intelligence"]["count"] >= 2
        assert domains["security"]["count"] >= 2

    def test_evidence_by_engine(self, db_path):
        director = UnifiedDirector(db_path=db_path)
        landscape = director.get_evidence_landscape()

        engines = landscape["evidence_by_engine"]
        assert "upstream_watcher" in engines
        assert "spec_verifier" in engines
        assert engines["upstream_watcher"]["domain"] == "intelligence"

    def test_hypotheses_loaded(self, db_path):
        director = UnifiedDirector(db_path=db_path)
        landscape = director.get_evidence_landscape()

        assert len(landscape["hypotheses"]) == 3
        # Sorted by confidence desc
        assert landscape["hypotheses"][0]["id"] == "H003"

    def test_recent_findings(self, db_path):
        director = UnifiedDirector(db_path=db_path)
        landscape = director.get_evidence_landscape()

        assert len(landscape["recent_findings"]) > 0
        assert len(landscape["recent_findings"]) <= 30


class TestEnginePrioritization:
    """Test engine prioritization using real domain registry."""

    def test_prioritize_with_registry(self, db_path):
        DomainRegistry.reset()
        registry = DomainRegistry.instance()

        from domains.intelligence.domain import IntelligenceDomain
        from domains.security.domain import SecurityDomain

        registry.register(IntelligenceDomain())
        registry.register(SecurityDomain())

        director = UnifiedDirector(db_path=db_path)
        priorities = director.prioritize_engines(registry)

        assert len(priorities) > 0
        # Each entry has domain, engine, score, reason
        for p in priorities:
            assert "domain" in p
            assert "engine" in p
            assert "score" in p
            assert isinstance(p["score"], float)

        DomainRegistry.reset()

    def test_inactive_engines_score_high(self, db_path):
        DomainRegistry.reset()
        registry = DomainRegistry.instance()

        from domains.intelligence.domain import IntelligenceDomain

        registry.register(IntelligenceDomain())

        director = UnifiedDirector(db_path=db_path)
        priorities = director.prioritize_engines(registry)

        # ecosystem_health has no evidence, should score high
        eco_health = [p for p in priorities if p["engine"] == "ecosystem_health"]
        assert len(eco_health) == 1
        assert eco_health[0]["score"] >= 10.0

        DomainRegistry.reset()


class TestStallDetection:
    """Test stall detection."""

    def test_detect_stalled_hypotheses(self, db_path):
        director = UnifiedDirector(db_path=db_path)
        # With hours=0, everything is stalled
        stalled = director.detect_stalled(hours=0)

        # All INVESTIGATING hypotheses should appear
        hypothesis_stalls = [s for s in stalled if s["type"] == "hypothesis"]
        assert len(hypothesis_stalls) >= 1

    def test_stall_recommendations(self, db_path):
        director = UnifiedDirector(db_path=db_path)
        stalled = director.detect_stalled(hours=0)

        for item in stalled:
            assert item["recommendation"] in ("retire", "pivot", "escalate")


class TestAspirationGeneration:
    """Test aspiration generation with mock LLM."""

    def test_mock_llm_aspirations(self, db_path):
        # Mock LLM that returns structured aspirations
        def mock_llm(system, user):
            return [
                {
                    "title": "Cross-domain security audit",
                    "description": "Run security+quality convergence",
                    "target_domains": ["security", "quality"],
                    "priority": 9,
                    "reasoning": "ABI mismatch may have security impact",
                    "estimated_impact": "high",
                },
                {
                    "title": "Fill development coverage gaps",
                    "description": "Run impl_coverage on all specs",
                    "target_domains": ["development"],
                    "priority": 7,
                    "reasoning": "Low spec coverage detected",
                },
            ]

        director = UnifiedDirector(db_path=db_path, llm_call=mock_llm)
        aspirations = director.propose_aspirations()

        assert len(aspirations) == 2
        assert isinstance(aspirations[0], Aspiration)
        # Sorted by priority desc
        assert aspirations[0].priority >= aspirations[1].priority
        assert "security" in aspirations[0].target_domains

    def test_aspiration_to_dict(self, db_path):
        asp = Aspiration(
            title="Test",
            description="Test aspiration",
            target_domains=["security"],
            priority=8,
            reasoning="test reason",
        )
        d = asp.to_dict()
        assert d["title"] == "Test"
        assert d["priority"] == 8
        assert "id" in d
        assert d["id"].startswith("asp_")
