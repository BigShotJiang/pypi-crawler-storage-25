# SPDX-License-Identifier: MIT
"""Tests for core.api_fingerprint -- FingerprintedSession and provenance."""

from unittest.mock import MagicMock, patch

import pytest

from core.api_fingerprint import FingerprintedSession, classify_provenance


class TestClassifyProvenance:
    def test_empty_fingerprints_returns_hypothesis(self):
        assert classify_provenance([]) == "hypothesis"

    def test_successful_api_call_returns_verified(self):
        fps = [{"url": "https://api.example.com", "status_code": 200}]
        assert classify_provenance(fps) == "verified_by_api"

    def test_non_200_returns_computational(self):
        fps = [{"url": "https://api.example.com", "status_code": 403}]
        assert classify_provenance(fps) == "computational"

    def test_error_call_returns_hypothesis(self):
        fps = [{"url": "https://api.example.com", "status_code": 0, "error": "timeout"}]
        assert classify_provenance(fps) == "hypothesis"

    def test_mixed_calls(self):
        fps = [
            {"url": "https://api.a.com", "status_code": 0, "error": "fail"},
            {"url": "https://api.b.com", "status_code": 200},
        ]
        assert classify_provenance(fps) == "verified_by_api"

    def test_multiple_non_200(self):
        fps = [
            {"url": "https://a.com", "status_code": 404},
            {"url": "https://b.com", "status_code": 500},
        ]
        assert classify_provenance(fps) == "computational"


class TestFingerprintedSession:
    def test_initial_state(self):
        session = FingerprintedSession(engine_name="test_eng", domain="test_domain")
        assert session.get_fingerprints() == []
        assert session.get_call_count() == 0
        assert session.get_error_count() == 0
        assert session.has_api_evidence() is False
        assert session.get_total_latency_ms() == 0.0

    def test_engine_and_domain_stored(self):
        session = FingerprintedSession(engine_name="my_engine", domain="intel")
        assert session._engine_name == "my_engine"
        assert session._domain == "intel"

    @patch("core.api_fingerprint.requests.Session.request")
    def test_successful_request_logged(self, mock_request):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b'{"data": "test"}'
        mock_response.headers = {"content-type": "application/json"}
        mock_request.return_value = mock_response

        session = FingerprintedSession(engine_name="test", domain="d")
        session.request("GET", "https://api.example.com/data")

        fps = session.get_fingerprints()
        assert len(fps) == 1
        assert fps[0]["url"] == "https://api.example.com/data"
        assert fps[0]["method"] == "GET"
        assert fps[0]["status_code"] == 200
        assert fps[0]["engine"] == "test"
        assert fps[0]["domain"] == "d"
        assert "latency_ms" in fps[0]
        assert "timestamp" in fps[0]

    @patch("core.api_fingerprint.requests.Session.request")
    def test_multiple_calls_tracked(self, mock_request):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b"ok"
        mock_response.headers = {}
        mock_request.return_value = mock_response

        session = FingerprintedSession(engine_name="multi", domain="d")
        session.request("GET", "https://a.com")
        session.request("POST", "https://b.com")

        assert session.get_call_count() == 2
        assert session.has_api_evidence() is True
        urls = session.get_successful_urls()
        assert "https://a.com" in urls
        assert "https://b.com" in urls

    @patch("core.api_fingerprint.requests.Session.request")
    def test_failed_request_logged(self, mock_request):
        import requests

        mock_request.side_effect = requests.ConnectionError("connection refused")

        session = FingerprintedSession(engine_name="fail", domain="d")
        with pytest.raises(requests.ConnectionError):
            session.request("GET", "https://failing.example.com")

        fps = session.get_fingerprints()
        assert len(fps) == 1
        assert fps[0]["status_code"] == 0
        assert "error" in fps[0]
        assert session.get_error_count() == 1
        assert session.has_api_evidence() is False

    @patch("core.api_fingerprint.requests.Session.request")
    def test_fingerprint_hash_deterministic(self, mock_request):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b"data"
        mock_response.headers = {}
        mock_request.return_value = mock_response

        session = FingerprintedSession(engine_name="hash", domain="d")
        session.request("GET", "https://example.com")

        h1 = session.get_fingerprint_hash()
        h2 = session.get_fingerprint_hash()
        assert h1 == h2
        assert len(h1) == 64  # SHA-256 hex

    def test_get_fingerprints_returns_copy(self):
        session = FingerprintedSession()
        fps = session.get_fingerprints()
        fps.append({"fake": True})
        assert len(session.get_fingerprints()) == 0  # original unchanged

    @patch("core.api_fingerprint.requests.Session.request")
    def test_total_latency(self, mock_request):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b"x"
        mock_response.headers = {}
        mock_request.return_value = mock_response

        session = FingerprintedSession()
        session.request("GET", "https://example.com")
        session.request("GET", "https://example.com")

        assert session.get_total_latency_ms() >= 0.0

    @patch("core.api_fingerprint.requests.Session.request")
    def test_headers_sanitized(self, mock_request):
        """Verify OPSECGuard sanitizes headers before sending."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b""
        mock_response.headers = {}
        mock_request.return_value = mock_response

        session = FingerprintedSession()
        session.request(
            "GET", "https://example.com", headers={"Referer": "https://internal.corp.com"}
        )

        # The call should have sanitized headers (Referer stripped)
        call_kwargs = mock_request.call_args
        sent_headers = call_kwargs[1].get("headers", {}) if call_kwargs[1] else {}
        # Referer should have been stripped by OPSECGuard
        assert "Referer" not in sent_headers
