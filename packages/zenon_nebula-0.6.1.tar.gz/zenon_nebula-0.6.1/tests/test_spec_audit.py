# SPDX-License-Identifier: MIT
"""Regression tests for the spec_audit engine.

The 6 structural checks are pinned with one "flagged" test and one "not
flagged" test each (12 tests). 4 integration tests cover the orchestrator,
the persistence path, the contribution-file pipeline, and the engine
default repo registry. Total: 16 tests, all deterministic, no real
workspace or network.

Calibration source of truth: the smoke test against the real
TminusZ/zenon-developer-commons corpus produced 10 findings on 18 specs
with 0 false positives. These tests pin the same behavior so future
refactors can't drift.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from domains.development.engines.spec_audit import (
    _check_boundary_conditions,
    _check_missing_test_vectors,
    _check_missing_threat_model,
    _check_stale_cross_refs,
    _check_underspecified_errors,
    _check_untestable_claims,
    _count_abi_methods,
    audit_all_specs,
    audit_spec_dir,
    persist_audit_findings,
    run_spec_audit,
)

# ---------------------------------------------------------------------------
# Synthetic spec fixtures
# ---------------------------------------------------------------------------


def _write_spec(parent: Path, name: str, body: str) -> Path:
    """Create a spec file under ``parent`` and return its path."""
    parent.mkdir(parents=True, exist_ok=True)
    p = parent / name
    p.write_text(body, encoding="utf-8")
    return p


@pytest.fixture
def good_spec(tmp_path: Path) -> Path:
    """A well-formed spec that should pass every check."""
    body = """# Good Spec

## 1. Introduction

This spec defines a hypothetical embedded contract.

## 2. Method Specification

| Method | Signature |
|--------|-----------|
| `Create` | `Create(amount uint64, expiration int64)` |
| `Reclaim` | `Reclaim(entryId types.Hash)` |

```go
func (c *contract) Create(amount uint64, expiration int64) error {
    // expiration is exclusive — Reclaim at exactly expiration is rejected
    if amount == 0 {
        return ErrZeroAmount
    }
    return nil
}
```

## 3. Errors

| Code | Trigger | Recommendation |
|------|---------|----------------|
| `ErrZeroAmount` | amount is zero | reject the transaction |
| `ErrExpired` | timestamp >= expiration | use Reclaim instead |

## 4. Security Model

The adversary can submit arbitrary transactions but cannot solve the
discrete logarithm problem on secp256k1.

## 5. Conformance Tests

Input: `0xdeadbeef` -> Expected output: `0xfeedface`
"""
    return _write_spec(tmp_path / "GoodSpec", "good_spec.md", body)


@pytest.fixture
def fake_specs_dir(tmp_path: Path) -> Path:
    """A corpus of synthetic specs designed to trigger each check.

    Each spec has a known structural defect or a known clean property
    so the per-check tests can assert deterministically.
    """
    specs = tmp_path / "specs"

    # 1. Spec WITHOUT threat model (state-mutating, no Security section)
    _write_spec(
        specs / "NoThreatModel",
        "no_threat_model_spec.md",
        """# NoThreatModel

## ABI

| Method | Signature |
|--------|-----------|
| `CreateEntry` | `CreateEntry(amount uint64)` |

## Errors

| Code | Trigger |
|------|---------|
| `ErrBadAmount` | amount is invalid |

## Conformance Tests

Input: `0xaa` -> Output: `0xbb`
""",
    )

    # 2. Spec WITH threat model (should NOT be flagged)
    _write_spec(
        specs / "HasThreatModel",
        "has_threat_model_spec.md",
        """# HasThreatModel

## ABI

| Method | Signature |
|--------|-----------|
| `Withdraw` | `Withdraw(amount uint64)` |

## Errors

| Code | Trigger |
|------|---------|
| `ErrBadAmount` | amount is invalid |

## 4. Security Model

The adversary controls the network but not the chain.

## Conformance Tests

Input: `0xaa` -> Output: `0xbb`
""",
    )

    # 3. Spec WITHOUT test vectors but WITH ABI methods
    _write_spec(
        specs / "NoTestVectors",
        "no_test_vectors_spec.md",
        """# NoTestVectors

## Method Specification

| Method | Signature |
|--------|-----------|
| `Foo` | `Foo()` |
| `Bar` | `Bar()` |
| `Baz` | `Baz()` |

## Errors

| Code | Trigger |
|------|---------|
| `ErrFoo` | foo |

## Security Model

Adversary cannot.
""",
    )

    # 4. Spec WITH untestable language inside method spec section
    _write_spec(
        specs / "Untestable",
        "untestable_spec.md",
        """# Untestable

## Method Specification

The Withdraw method should normally complete in a reasonable time.
Implementations may use any sufficient algorithm.

## Errors

| Code | Trigger |
|------|---------|
| `ErrFoo` | foo |

## Security Model

Adversary controls.

## Test Vectors

Input: 0xaa -> Output: 0xbb
""",
    )

    # 5. Spec with broken cross-reference
    _write_spec(
        specs / "BrokenRef",
        "broken_ref_spec.md",
        """# BrokenRef

## Introduction

See the [other spec](../NotARealSpec/missing.md) for details.

## ABI

| Method | Signature |
|--------|-----------|
| `Foo` | `Foo()` |

## Security Model

Adversary X.

## Errors

| Code | Trigger |
|------|---------|
| `ErrA` | a |

## Test Vectors

Input: 0xaa -> Output: 0xbb
""",
    )

    # 6. Spec with valid cross-reference (the target exists)
    valid_target = specs / "ValidRef"
    _write_spec(
        valid_target,
        "valid_ref_spec.md",
        """# ValidRef

## Introduction

See the [other spec](../HasThreatModel/has_threat_model_spec.md) for details.

## Method Specification

| Method | Signature |
|--------|-----------|
| `Foo` | `Foo()` |

## Security Model

Adversary X.

## Errors

| Code | Trigger |
|------|---------|
| `ErrA` | a |

## Test Vectors

Input: 0xaa -> Output: 0xbb
""",
    )

    # 7. Spec missing boundary conditions
    _write_spec(
        specs / "NoBoundary",
        "no_boundary_spec.md",
        """# NoBoundary

## Method Specification

```go
func (c *contract) Schedule(amount uint64, deadline int64) error {
    return nil
}
```

## Security Model

Adversary X.

## Errors

| Code | Trigger |
|------|---------|
| `ErrA` | a |

## Test Vectors

Input: 0xaa -> Output: 0xbb
""",
    )

    # 8. Spec WITH explicit boundary clause
    _write_spec(
        specs / "HasBoundary",
        "has_boundary_spec.md",
        """# HasBoundary

## Method Specification

The deadline parameter is exclusive: a Reclaim at exactly the deadline
timestamp is rejected via strict inequality.

```go
func (c *contract) Schedule(amount uint64, deadline int64) error {
    return nil
}
```

## Security Model

Adversary X.

## Errors

| Code | Trigger |
|------|---------|
| `ErrA` | a |

## Test Vectors

Input: 0xaa -> Output: 0xbb
""",
    )

    # 9. Spec WITHOUT errors section but WITH state-mutating methods
    _write_spec(
        specs / "NoErrors",
        "no_errors_spec.md",
        """# NoErrors

## ABI

| Method | Signature |
|--------|-----------|
| `Withdraw` | `Withdraw(amount uint64)` |

## Security Model

Adversary X.

## Test Vectors

Input: 0xaa -> Output: 0xbb
""",
    )

    return specs


# ---------------------------------------------------------------------------
# 1) missing_threat_model — flagged + not flagged
# ---------------------------------------------------------------------------


class TestMissingThreatModel:
    def test_flagged_when_state_mutating_no_security_section(self, tmp_path):
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\n## ABI\n\n| Method |\n|--------|\n| `Withdraw` |\n",
        )
        findings = _check_missing_threat_model(spec, spec.read_text())
        assert len(findings) == 1
        assert findings[0]["category"] == "missing_threat_model"
        assert findings[0]["severity"] == "high"

    def test_not_flagged_when_security_section_present(self, tmp_path):
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\n## ABI\n\n| Method |\n|--------|\n| `Withdraw` |\n\n"
            "## 4. Security Model\n\nadversary X.\n",
        )
        findings = _check_missing_threat_model(spec, spec.read_text())
        assert findings == []

    def test_not_flagged_when_no_state_mutation(self, tmp_path):
        """Pure read-only specs don't need a threat model."""
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\nThis is a documentation page with no ABI.\n",
        )
        findings = _check_missing_threat_model(spec, spec.read_text())
        assert findings == []


# ---------------------------------------------------------------------------
# 2) missing_test_vectors — flagged + not flagged
# ---------------------------------------------------------------------------


class TestMissingTestVectors:
    def test_flagged_when_abi_methods_no_vectors(self, tmp_path):
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\n## ABI\n\n| Method |\n|--------|\n| `Foo` |\n| `Bar` |\n",
        )
        findings = _check_missing_test_vectors(spec, spec.read_text())
        assert len(findings) == 1
        assert findings[0]["category"] == "missing_test_vectors"
        assert "ABI method" in findings[0]["description"]

    def test_not_flagged_when_conformance_tests_section_present(self, tmp_path):
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\n## ABI\n\n| Method |\n|--------|\n| `Foo` |\n\n"
            "## 7. Conformance Tests\n\nInput: 0xaa -> Output: 0xbb\n",
        )
        findings = _check_missing_test_vectors(spec, spec.read_text())
        assert findings == []

    def test_not_flagged_when_no_abi_methods(self, tmp_path):
        spec = _write_spec(tmp_path / "X", "x.md", "# X\n\nProse only.\n")
        findings = _check_missing_test_vectors(spec, spec.read_text())
        assert findings == []


# ---------------------------------------------------------------------------
# 3) untestable_claims — flagged + not flagged
# ---------------------------------------------------------------------------


class TestUntestableClaims:
    def test_flagged_when_vague_phrase_in_method_section(self, tmp_path):
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\n## Method Specification\n\nReturns when sufficient time has passed.\n",
        )
        findings = _check_untestable_claims(spec, spec.read_text())
        assert len(findings) >= 1
        assert any("sufficient" in f["title"].lower() for f in findings)

    def test_not_flagged_in_top_level_prose(self, tmp_path):
        """Vague language in introductory prose is fine — only flag inside ABI sections."""
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\nThis spec describes a reasonable approach to typical workloads.\n",
        )
        findings = _check_untestable_claims(spec, spec.read_text())
        assert findings == []


# ---------------------------------------------------------------------------
# 4) stale_cross_refs — flagged + not flagged
# ---------------------------------------------------------------------------


class TestStaleCrossRefs:
    def test_flagged_when_target_does_not_exist(self, tmp_path):
        spec_dir = tmp_path / "X"
        spec = _write_spec(
            spec_dir,
            "x.md",
            "# X\n\nSee [other](../NoSuch/file.md).\n",
        )
        findings = _check_stale_cross_refs(spec, spec.read_text(), set())
        assert len(findings) == 1
        assert findings[0]["category"] == "stale_cross_ref"

    def test_not_flagged_when_target_exists(self, tmp_path):
        # Create a real target file
        target = tmp_path / "Y" / "y.md"
        target.parent.mkdir(parents=True)
        target.write_text("# Y", encoding="utf-8")

        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\nSee [other](../Y/y.md).\n",
        )
        findings = _check_stale_cross_refs(spec, spec.read_text(), set())
        assert findings == []

    def test_not_flagged_for_external_urls(self, tmp_path):
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\nSee [bitcoin](https://github.com/bitcoin/bitcoin/blob/master/src/main.md).\n",
        )
        findings = _check_stale_cross_refs(spec, spec.read_text(), set())
        assert findings == []


# ---------------------------------------------------------------------------
# 5) boundary_conditions — flagged + not flagged
# ---------------------------------------------------------------------------


class TestBoundaryConditions:
    def test_flagged_when_amount_param_no_boundary_clause(self, tmp_path):
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\n## Method Specification\n\n```go\n"
            "func (c *contract) Schedule(amount uint64, deadline int64) error {\n"
            "    return nil\n}\n```\n",
        )
        findings = _check_boundary_conditions(spec, spec.read_text())
        assert len(findings) >= 1
        assert findings[0]["category"] == "missing_boundary_condition"

    def test_not_flagged_when_explicit_boundary_clause_present(self, tmp_path):
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\n## Method Specification\n\nThe deadline is exclusive: "
            "Reclaim at exactly the deadline is rejected via strict inequality.\n\n"
            "```go\n"
            "func (c *contract) Schedule(amount uint64, deadline int64) error {\n"
            "    return nil\n}\n```\n",
        )
        findings = _check_boundary_conditions(spec, spec.read_text())
        assert findings == []


# ---------------------------------------------------------------------------
# 6) underspecified_errors — flagged + not flagged
# ---------------------------------------------------------------------------


class TestUnderspecifiedErrors:
    def test_flagged_when_state_mutating_no_errors_section(self, tmp_path):
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\n## ABI\n\n| Method |\n|--------|\n| `Withdraw` |\n",
        )
        findings = _check_underspecified_errors(spec, spec.read_text())
        assert len(findings) == 1
        assert findings[0]["category"] == "underspecified_errors"

    def test_not_flagged_when_errors_section_present(self, tmp_path):
        spec = _write_spec(
            tmp_path / "X",
            "x.md",
            "# X\n\n## ABI\n\n| Method |\n|--------|\n| `Withdraw` |\n\n"
            "## 6. Errors\n\n`ErrFoo` triggered when foo.\n",
        )
        findings = _check_underspecified_errors(spec, spec.read_text())
        assert findings == []


# ---------------------------------------------------------------------------
# Integration tests (orchestrator + persist + contribution + registry)
# ---------------------------------------------------------------------------


class TestSpecAuditEndToEnd:
    def test_audit_all_specs_returns_findings_dict(self, fake_specs_dir):
        results = audit_all_specs(specs_dir=fake_specs_dir)
        assert results["specs_scanned"] > 0
        assert results["total_findings"] > 0
        assert "findings" in results
        assert "by_severity" in results
        assert "summary" in results
        # The fake corpus has at least one finding from each check class
        all_categories = {
            f.get("category") for findings in results["findings"].values() for f in findings
        }
        assert "missing_threat_model" in all_categories
        assert "missing_test_vectors" in all_categories
        assert "underspecified_errors" in all_categories

    def test_persist_audit_findings_writes_provenance(self, fake_specs_dir, tmp_path):
        """Findings persisted with full provenance: repo, file, commit, line, URL."""
        from core.persistence.schema import ensure_schema

        db_path = str(tmp_path / "test.db")
        ensure_schema(db_path)

        results = audit_all_specs(specs_dir=fake_specs_dir)
        persist_audit_findings(results, db_path=db_path)

        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT source_repo, source_file, verification_url "
                "FROM evidence WHERE engine='spec_audit' "
                "AND evidence_type != 'spec_audit_summary' "
                "LIMIT 1"
            ).fetchone()
        finally:
            conn.close()

        assert row is not None, "expected at least one spec_audit evidence row"
        source_repo, source_file, verification_url = row
        assert source_repo == "knowledge/developer-commons"
        assert source_file is not None and source_file.endswith(".md")
        assert verification_url is not None
        assert verification_url.startswith(
            "https://github.com/TminusZ/zenon-developer-commons/blob/"
        )

    def test_contribution_files_written(self, fake_specs_dir, tmp_path):
        """run_spec_audit produces paste-ready issue files."""
        import domains.contribution.engines.tminusz_contributor as tc
        from core.persistence.schema import ensure_schema

        db_path = str(tmp_path / "test.db")
        ensure_schema(db_path)

        # Override the contributions dir to a tmp path so we don't pollute
        # the real data dir.
        contrib_dir = tmp_path / "contributions"
        original = tc.SPEC_AUDIT_CONTRIBUTIONS_DIR
        tc.SPEC_AUDIT_CONTRIBUTIONS_DIR = contrib_dir
        try:
            result = run_spec_audit(
                db_path=db_path,
                specs_dir=fake_specs_dir,
            )
        finally:
            tc.SPEC_AUDIT_CONTRIBUTIONS_DIR = original

        assert result["contribution_files_written"] > 0
        files = list(contrib_dir.glob("*.md"))
        assert len(files) > 0
        # Every issue file pastes cleanly into GitHub: starts with #, has
        # the canonical sections, has a clickable permalink.
        sample = files[0].read_text(encoding="utf-8")
        assert sample.startswith("# Spec audit:")
        assert "**Found by**: Nebula `spec_audit`" in sample
        assert "https://github.com/TminusZ/zenon-developer-commons/blob/" in sample
        assert "## What" in sample

    def test_engine_default_repo_registry_includes_spec_audit(self):
        """spec_audit is in the registry so source_repo auto-fills."""
        from core.persistence.findings import _ENGINE_DEFAULT_REPO

        assert "spec_audit" in _ENGINE_DEFAULT_REPO
        assert _ENGINE_DEFAULT_REPO["spec_audit"] == "knowledge/developer-commons"


# ---------------------------------------------------------------------------
# Helper smoke test (count_abi_methods) — not part of the 16, but pinned
# because it was the source of the v0.2.23 false positive
# ---------------------------------------------------------------------------


class TestAbiMethodCounting:
    def test_only_counts_abi_table_rows(self, tmp_path):
        """Generic markdown tables (not ABI tables) must NOT be counted."""
        source = """# X

| Field | Type |
|-------|------|
| `Foo` | `int` |
| `Bar` | `int` |

| Method | Signature |
|--------|-----------|
| `Withdraw` | `Withdraw()` |
"""
        # Only Withdraw (1 method) — not Foo and Bar (which are fields)
        assert _count_abi_methods(source) == 1

    def test_counts_function_signatures(self, tmp_path):
        source = """# X

```go
func (c *contract) Create(amount uint64) error {
    return nil
}
func (c *contract) Reclaim() error {
    return nil
}
```
"""
        assert _count_abi_methods(source) == 2
