# SPDX-License-Identifier: MIT
"""Tests for domains.security.engines.cross_chain_cve_monitor."""

from __future__ import annotations

from pathlib import Path

from core.persistence.metrics import persist_metric, query_table
from domains.security.engines import cross_chain_cve_monitor as monitor


def _insert_workspace_repo(
    db_path: str,
    repo_name: str,
    repo_path: Path,
    repo_type: str,
) -> None:
    """Seed workspace_repos with a single row for tests."""
    persist_metric(
        db_path=db_path,
        table="workspace_repos",
        data={
            "repo_name": repo_name,
            "repo_path": str(repo_path),
            "repo_type": repo_type,
            "languages": "[]",
            "has_ci": 0,
            "has_tests": 0,
            "classified_at": "2026-04-10T00:00:00+00:00",
        },
    )


def test_module_import_smoke():
    """Entry point exists and is callable."""
    assert callable(monitor.scan_cross_chain_cves)


def test_empty_workspace_returns_empty(db_path):
    """No reference chain in catalog -> empty dict."""
    result = monitor.scan_cross_chain_cves(db_path=db_path)
    assert result == {}


def test_scan_with_fake_workspace_no_reference_chain(fake_workspace, db_path):
    """fake_workspace has no BTC reference repo, so result is empty."""
    result = monitor.scan_cross_chain_cves(db_path=db_path)
    assert result == {}


def test_scan_emits_finding_when_primitive_matches(tmp_path, db_path):
    """When both reference and Zenon repos implement the same primitive,
    the engine emits a finding."""
    # Fake Bitcoin reference repo.
    ref = tmp_path / "bitcoin"
    ref.mkdir()
    (ref / "src").mkdir()
    (ref / "src" / "validation.cpp").write_text(
        "// Bitcoin validation logic\n"
        "bool VerifyMerkleProof(const uint256& hash) { return true; }\n"
    )
    _insert_workspace_repo(db_path, "bitcoin", ref, "blockchain_node_btc")

    # Fake Zenon go-zenon repo that also implements verifyMerkleProof.
    zenon = tmp_path / "go-zenon"
    zenon.mkdir()
    (zenon / "common").mkdir()
    (zenon / "common" / "merkle.go").write_text(
        "package common\nfunc VerifyMerkleProof(hash []byte) bool { return true }\n"
    )
    _insert_workspace_repo(db_path, "go-zenon", zenon, "node")

    result = monitor.scan_cross_chain_cves(db_path=db_path)
    assert result.get("reference_repos", 0) == 1
    assert result.get("findings", 0) >= 1

    rows = query_table(
        db_path=db_path,
        table="evidence",
        where="engine = ?",
        params=("cross_chain_cve_monitor",),
        limit=10,
    )
    assert rows
    assert any("merkle" in (r.get("finding") or "").lower() for r in rows)
