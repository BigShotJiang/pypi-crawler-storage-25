# SPDX-License-Identifier: MIT
"""v0.3.4 (task #46 Phase B) source_quality scoring tests.

Pins every content signal against a synthetic fake repo with known
properties so score stability across refactors is checkable.
Anti-doxxing guarantees are also tested — the scorer must not
touch git log author fields, must work on a .git-less directory,
must return a valid result even for empty / unreadable / missing
repos.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core import source_quality as sq


@pytest.fixture
def fake_highsig_repo(tmp_path):
    """A fake repo that should score high on every content signal.

    Deliberately packs: ABI method tables, structured section
    headings, hex test vectors, cryptographic primitive mentions,
    Zenon internals, fund-safety language.
    """
    repo = tmp_path / "fake-highsig-repo"
    repo.mkdir()
    (repo / ".git").mkdir()  # looks like a git repo for cadence scoring

    spec_dir = repo / "docs" / "specs" / "PTLC"
    spec_dir.mkdir(parents=True)

    (spec_dir / "spec.md").write_text(
        "# PTLC v2 — Point Time-Locked Contracts\n\n"
        "## 1. Introduction\n\n"
        "PTLC uses secp256k1 point-lock verification + schnorr aggregation "
        "to enable adaptor signatures on top of Zenon's embedded contract "
        "framework. This spec builds on BIP-340 taproot primitives.\n\n"
        "## 2. Motivation\n\n"
        "HTLCs reveal the hash preimage on-chain; PTLCs reveal a secp256k1 "
        "scalar instead, enabling privacy-preserving atomic swaps.\n\n"
        "## 3. Specification\n\n"
        "### 3.1 ABI Methods\n\n"
        "| Method | Signature | Description |\n"
        "|--------|-----------|-------------|\n"
        "| `Create` | `Create(point, amount, expiration)` | Create PTLC |\n"
        "| `Unlock` | `Unlock(scalar)` | Reveal scalar to unlock |\n"
        "| `Reclaim` | `Reclaim()` | After expiration, sender reclaims |\n"
        "| `Cancel` | `Cancel()` | Before unlock, sender cancels |\n\n"
        "## 4. Threat Model\n\n"
        "- Chain reorgs: reclaim path timeout must exceed reorg window\n"
        "- Frontrunning: expiration must be exclusive (`now < expiry`)\n"
        "- Reentrancy: each method is atomic w.r.t. plasma/ZNN transfers\n"
        "- Mempool observation: adaptor secret leaks iff Unlock finalizes\n\n"
        "## 5. Errors\n\n"
        "- `ErrPtlcNotFound` — caller references nonexistent PTLC\n"
        "- `ErrExpiryInFuture` — Reclaim called before expiration\n"
        "- `ErrInvalidScalar` — Unlock called with wrong adaptor secret\n\n"
        "## 6. Test Vectors\n\n"
        "```\n"
        "Input: 0x0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798\n"
        "Expected: 0xdeadbeef1234cafebabe5678901234abcdef0123456789abcdef0123456789ab\n"
        "```\n\n"
        "Another vector: 0x48656c6c6f20506c61736d61 -> 0x5a4e4e20616464726573730000\n\n"
        "## 7. Reference Implementation\n\n"
        "See go-zenon/vm/embedded/implementation/ptlc.go. The reference "
        "uses pillar-triggered spork activation and sentinel-verified "
        "momentum timestamps. Uses DealWithErr for all 'impossible' errors.\n"
    )

    return repo


@pytest.fixture
def fake_lowsig_repo(tmp_path):
    """A fake repo with no Zenon/crypto content (should score near 0)."""
    repo = tmp_path / "fake-lowsig-repo"
    repo.mkdir()
    (repo / ".git").mkdir()
    (repo / "README.md").write_text(
        "# Example\n\nThis is a test repository for other purposes.\n"
        "It contains no cryptocurrency, blockchain, or protocol content.\n"
    )
    return repo


@pytest.fixture
def missing_repo(tmp_path):
    """Path that doesn't exist (should not crash)."""
    return tmp_path / "does-not-exist"


class TestContentSignals:
    """Pin each individual content signal."""

    def test_spec_density_rewards_abi_tables_and_sections(self, fake_highsig_repo):
        content = (fake_highsig_repo / "docs/specs/PTLC/spec.md").read_text()
        score = sq.score_spec_density(content)
        assert score > 0.4, f"High-signal spec should score >0.4, got {score}"

    def test_spec_density_near_zero_on_lowsig(self, fake_lowsig_repo):
        content = (fake_lowsig_repo / "README.md").read_text()
        score = sq.score_spec_density(content)
        # A generic README with no ABI tables, no structured spec
        # headings, no hex blobs should score well under the
        # per-1000-lines saturation threshold. Allow some slack
        # because short files look dense by line count alone.
        assert score < 0.5

    def test_cryptographic_rigor_detects_primitives(self, fake_highsig_repo):
        content = (fake_highsig_repo / "docs/specs/PTLC/spec.md").read_text()
        score = sq.score_cryptographic_rigor(content)
        assert score > 0.5, f"PTLC spec should score high on crypto, got {score}"

    def test_zenon_internals_depth_detects_concepts(self, fake_highsig_repo):
        content = (fake_highsig_repo / "docs/specs/PTLC/spec.md").read_text()
        score = sq.score_zenon_internals_depth(content)
        assert score > 0.3, f"PTLC spec references Zenon internals, got {score}"

    def test_fund_safety_discipline_detects_adversarial_language(self, fake_highsig_repo):
        content = (fake_highsig_repo / "docs/specs/PTLC/spec.md").read_text()
        score = sq.score_fund_safety_discipline(content)
        assert score > 0.3

    def test_reproducibility_rewards_hex_vectors(self, fake_highsig_repo):
        content = (fake_highsig_repo / "docs/specs/PTLC/spec.md").read_text()
        score = sq.score_reproducibility(content)
        assert score > 0.1

    def test_documentation_quality_rewards_structure(self, fake_highsig_repo):
        content = (fake_highsig_repo / "docs/specs/PTLC/spec.md").read_text()
        score = sq.score_documentation_quality(content)
        assert score > 0.5, f"Structured spec should score high on docs, got {score}"

    def test_documentation_quality_low_on_unstructured(self, fake_lowsig_repo):
        content = (fake_lowsig_repo / "README.md").read_text()
        score = sq.score_documentation_quality(content)
        assert score < 0.2


class TestScoreRepo:
    """Integration: the top-level score_repo scorer."""

    def test_highsig_repo_scores_above_lowsig(self, fake_highsig_repo, fake_lowsig_repo):
        hi = sq.score_repo(fake_highsig_repo, repo_identity="ptlc-research")
        lo = sq.score_repo(fake_lowsig_repo, repo_identity="unrelated-repo")
        assert hi.quality_score > lo.quality_score
        # High-sig should clear at least 0.25 even on a stub-signal config
        assert hi.quality_score > 0.25

    def test_result_has_all_signals(self, fake_highsig_repo):
        result = sq.score_repo(fake_highsig_repo, repo_identity="r")
        expected_keys = {
            "spec_density",
            "cryptographic_rigor",
            "zenon_internals_depth",
            "fund_safety_discipline",
            "spec_impl_match",
            "reproducibility",
            "update_cadence",
            "novelty",
            "documentation_quality",
        }
        assert set(result.signals.keys()) == expected_keys

    def test_missing_repo_does_not_crash(self, missing_repo):
        result = sq.score_repo(missing_repo, repo_identity="missing")
        assert result.quality_score == 0.0
        assert result.files_scanned == 0
        assert "repo path not a directory" in result.notes

    def test_empty_repo_returns_valid_result(self, tmp_path):
        empty = tmp_path / "empty"
        empty.mkdir()
        result = sq.score_repo(empty, repo_identity="empty")
        assert 0.0 <= result.quality_score <= 1.0
        assert result.files_scanned == 0

    def test_score_is_bounded(self, fake_highsig_repo):
        result = sq.score_repo(fake_highsig_repo, repo_identity="r")
        assert 0.0 <= result.quality_score <= 1.0
        for name, value in result.signals.items():
            assert 0.0 <= value <= 1.0, f"{name}={value} out of [0,1]"


class TestAntiDoxxingGuarantees:
    """Pin the critical no-identity-ever invariant.

    These tests protect the design constraint: source_quality must
    never touch author-identifying data. If any of these fail, the
    anti-doxxing promise is broken and the whole content-based trust
    architecture becomes a deanonymization tool.
    """

    def _executable_source(self) -> str:
        """Return source with docstrings + comments stripped.

        The anti-doxxing bans apply to EXECUTABLE code, not to prose
        in docstrings that explicitly documents what we're banning.
        This helper strips triple-quoted strings and `#` comments so
        the regex bans only match real callable code.
        """
        import re

        src = Path(sq.__file__).read_text()
        # Strip triple-quoted strings (module + function docstrings)
        src = re.sub(r'""".*?"""', "", src, flags=re.DOTALL)
        src = re.sub(r"'''.*?'''", "", src, flags=re.DOTALL)
        # Strip # comments
        src = re.sub(r"#.*$", "", src, flags=re.MULTILINE)
        return src

    def test_no_git_author_reads_in_source_module(self):
        """Executable code must never call `git log --author` or similar."""
        src = self._executable_source()
        assert "--author" not in src, (
            "source_quality.py must never invoke `git log --author`. "
            "This is an anti-doxxing invariant — authorship data is "
            "banned from the scoring path."
        )
        # `author` can still show up in variable names unrelated to
        # identity; the strict check is the `--author` git flag + any
        # use of `%an` / `%ae` / `%aN` / `%aE` format codes.
        banned_git_format_codes = ["%an", "%ae", "%aN", "%aE"]
        for code in banned_git_format_codes:
            assert code not in src, (
                f"source_quality.py must not use git format code {code} "
                "(reveals author name/email)."
            )

    def test_no_stylistic_similarity_imports(self):
        """No similarity/distance functions imported from text-analysis libs."""
        src = self._executable_source()
        banned = [
            "levenshtein",
            "fuzzywuzzy",
            "difflib.SequenceMatcher",
            "sklearn",
            "spacy",
        ]
        for pattern in banned:
            assert pattern not in src, (
                f"source_quality.py must not import {pattern}. "
                "Stylistic similarity analysis across repos is "
                "deanonymization tech and banned by design."
            )

    def test_no_llm_calls(self):
        """The scorer must be pure local compute."""
        src = self._executable_source()
        assert "call_llm" not in src
        assert "api.x.ai" not in src
        assert "api.openai.com" not in src
        assert "api.anthropic.com" not in src

    def test_score_repo_with_no_git_dir_still_works(self, tmp_path):
        """A .git-less directory still scores (git isn't required)."""
        repo = tmp_path / "no-git"
        repo.mkdir()
        (repo / "spec.md").write_text("# Test\nsecp256k1 plasma sentinel\n")
        result = sq.score_repo(repo, repo_identity="no-git")
        assert result.files_scanned > 0
        # update_cadence should be 0 (no git), but other signals still score
        assert result.signals["update_cadence"] == 0.0


class TestSchemaMigration:
    """repo_trust_history table comes up on fresh DBs + migrated DBs."""

    def test_fresh_db_has_repo_trust_history_table(self, tmp_path):
        from core.persistence.schema import ensure_schema

        db = str(tmp_path / "fresh.db")
        ensure_schema(db)

        import sqlite3

        conn = sqlite3.connect(db)
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='repo_trust_history'"
        ).fetchone()
        conn.close()
        assert row is not None
