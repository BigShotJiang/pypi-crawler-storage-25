# SPDX-License-Identifier: MIT
"""Tests for domains.devops.domain -- Devnet management and integration testing."""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.devops.domain import DevOpsDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestDevOpsDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(DevOpsDomain, DomainPlugin)

    def test_name(self):
        assert DevOpsDomain().name() == "devops"

    def test_get_engines_non_empty(self):
        engines = DevOpsDomain().get_engines()
        assert len(engines) >= 2
        names = [e.name for e in engines]
        assert "devnet_manager" in names
        assert "test_runner" in names

    def test_get_hypothesis_types_non_empty(self):
        types = DevOpsDomain().get_hypothesis_types()
        assert len(types) >= 1

    def test_get_aspiration_types(self):
        assert isinstance(DevOpsDomain().get_aspiration_types(), list)

    def test_get_collision_signals(self):
        assert isinstance(DevOpsDomain().get_collision_signals(), list)

    def test_get_war_room_contributions(self):
        assert isinstance(DevOpsDomain().get_war_room_contributions(), list)

    def test_get_self_improvement_metrics(self):
        metrics = DevOpsDomain().get_self_improvement_metrics()
        assert isinstance(metrics, dict)

    def test_get_db_schema_sql(self):
        sql = DevOpsDomain().get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action(self):
        action = DevOpsDomain().decide_next_action({})
        # May return None or an action
        assert action is None or isinstance(action, dict)

    def test_registration(self):
        registry = DomainRegistry.instance()
        registry.register(DevOpsDomain())
        assert registry.get_domain("devops") is not None
