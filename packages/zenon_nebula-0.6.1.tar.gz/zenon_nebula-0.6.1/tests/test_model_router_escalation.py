# SPDX-License-Identifier: MIT
"""Tests for the executor-advisor escalation path in core.model_router.

Covers every branch of ``call_with_escalation`` so changes to the
routing rubric, confidence-gate defaults, or cost accounting land
with a loud failure.
"""

from __future__ import annotations

import json

import pytest

from core.model_router import (
    _default_plausibility_gate,
    _extract_confidence,
    call_with_escalation,
)

# ---------------------------------------------------------------------------
# Confidence extraction
# ---------------------------------------------------------------------------


class TestExtractConfidence:
    def test_dict_top_level_confidence(self):
        assert _extract_confidence({"confidence": 0.85}) == 0.85

    def test_dict_self_confidence_fallback(self):
        assert _extract_confidence({"self_confidence": 0.4}) == 0.4

    def test_dict_nested_result(self):
        assert _extract_confidence({"result": {"confidence": 0.7}}) == 0.7

    def test_dict_no_confidence_field(self):
        assert _extract_confidence({"text": "hello"}) is None

    def test_dict_out_of_range_ignored(self):
        assert _extract_confidence({"confidence": 1.5}) is None
        assert _extract_confidence({"confidence": -0.1}) is None

    def test_string_json_is_parsed(self):
        text = json.dumps({"confidence": 0.5, "answer": "x"})
        assert _extract_confidence(text) == 0.5

    def test_string_non_json_returns_none(self):
        assert _extract_confidence("just a plain sentence") is None

    def test_none_returns_none(self):
        assert _extract_confidence(None) is None

    def test_int_confidence_is_promoted_to_float(self):
        assert _extract_confidence({"confidence": 1}) == 1.0


# ---------------------------------------------------------------------------
# Default plausibility gate
# ---------------------------------------------------------------------------


class TestDefaultPlausibilityGate:
    def test_none_rejected(self):
        ok, reason = _default_plausibility_gate(None, min_confidence=0.6)
        assert ok is False
        assert "None" in reason

    def test_empty_dict_rejected(self):
        ok, _ = _default_plausibility_gate({}, min_confidence=0.6)
        assert ok is False

    def test_empty_string_rejected(self):
        ok, _ = _default_plausibility_gate("   ", min_confidence=0.6)
        assert ok is False

    def test_plain_text_above_threshold_accepted(self):
        ok, reason = _default_plausibility_gate("some answer", min_confidence=0.6)
        assert ok is True
        assert reason == "accepted"

    def test_low_confidence_rejected(self):
        payload = json.dumps({"confidence": 0.3, "answer": "maybe"})
        ok, reason = _default_plausibility_gate(payload, min_confidence=0.6)
        assert ok is False
        assert "0.30" in reason

    def test_high_confidence_accepted(self):
        payload = json.dumps({"confidence": 0.9, "answer": "yes"})
        ok, _ = _default_plausibility_gate(payload, min_confidence=0.6)
        assert ok is True


# ---------------------------------------------------------------------------
# call_with_escalation happy paths
# ---------------------------------------------------------------------------


def _fake_llm_factory(responses):
    """Return an llm_call mock that cycles through the supplied responses.

    Each response becomes a ``dict`` like the real ``call_llm`` output.
    """
    iterator = iter(responses)

    def _call(prompt, **kwargs):
        try:
            payload = next(iterator)
        except StopIteration as exc:
            raise AssertionError("llm_call invoked more times than expected") from exc
        return payload

    return _call


class TestCallWithEscalationNoEscalation:
    def test_executor_output_accepted_when_confidence_high(self):
        llm = _fake_llm_factory(
            [
                {"text": json.dumps({"confidence": 0.9, "answer": "accepted"}), "cost_usd": 0.0001},
            ]
        )
        result = call_with_escalation(
            "is the sky blue?",
            llm_call=llm,
        )
        assert result["tier"] == "executor"
        assert result["escalated"] is False
        assert result["escalation_reason"] == "accepted"
        assert result["total_cost_usd"] == 0.0001
        assert result["advisor_cost_usd"] == 0.0

    def test_executor_output_accepted_when_plain_text_non_empty(self):
        llm = _fake_llm_factory([{"text": "answer", "cost_usd": 0.0002}])
        result = call_with_escalation("q", llm_call=llm)
        assert result["escalated"] is False
        assert result["tier"] == "executor"


class TestCallWithEscalationEscalated:
    def test_escalates_on_low_confidence(self):
        llm = _fake_llm_factory(
            [
                {
                    "text": json.dumps({"confidence": 0.2, "answer": "unsure"}),
                    "cost_usd": 0.0001,
                },
                {
                    "text": json.dumps({"confidence": 0.95, "answer": "definitely"}),
                    "cost_usd": 0.005,
                },
            ]
        )
        result = call_with_escalation("q", llm_call=llm)
        assert result["escalated"] is True
        assert result["tier"] == "advisor"
        assert "0.20" in result["escalation_reason"]
        assert result["executor_cost_usd"] == 0.0001
        assert result["advisor_cost_usd"] == 0.005
        assert result["total_cost_usd"] == pytest.approx(0.0051)

    def test_escalates_on_empty_output(self):
        llm = _fake_llm_factory(
            [
                {"text": "", "cost_usd": 0.0001},
                {"text": "filled by advisor", "cost_usd": 0.003},
            ]
        )
        result = call_with_escalation("q", llm_call=llm)
        assert result["escalated"] is True
        assert result["output"] == "filled by advisor"

    def test_custom_gate_can_force_escalation(self):
        llm = _fake_llm_factory(
            [
                {"text": "short", "cost_usd": 0.0001},
                {"text": "a properly long advisor answer", "cost_usd": 0.004},
            ]
        )

        def require_long(output):
            if isinstance(output, str) and len(output) < 20:
                return False, "too short"
            return True, "accepted"

        result = call_with_escalation("q", llm_call=llm, gate=require_long)
        assert result["escalated"] is True
        assert result["escalation_reason"] == "too short"
        assert result["output"] == "a properly long advisor answer"

    def test_advisor_prompt_includes_executor_attempt(self):
        received_prompts = []

        def recording_call(prompt, **kwargs):
            received_prompts.append(prompt)
            if len(received_prompts) == 1:
                return {"text": "", "cost_usd": 0.0001}  # rejected
            return {"text": "done", "cost_usd": 0.002}

        result = call_with_escalation("what is X?", llm_call=recording_call)
        assert result["escalated"] is True
        assert len(received_prompts) == 2
        assert "what is X?" in received_prompts[1]
        assert "cheaper model was asked" in received_prompts[1]


class TestCallWithEscalationCap:
    def test_max_escalations_zero_keeps_executor_even_on_rejection(self):
        llm = _fake_llm_factory([{"text": "", "cost_usd": 0.0001}])
        result = call_with_escalation("q", llm_call=llm, max_escalations=0)
        assert result["escalated"] is False
        assert result["tier"] == "executor"
        assert result["output"] == ""

    def test_executor_attempt_always_populated(self):
        llm = _fake_llm_factory(
            [
                {"text": "bad", "cost_usd": 0.0001},
                {"text": "good", "cost_usd": 0.002},
            ]
        )

        def always_reject(output):
            return False, "testing"

        result = call_with_escalation("q", llm_call=llm, gate=always_reject)
        assert result["executor_attempt"] == "bad"
        assert result["output"] == "good"
