# SPDX-License-Identifier: MIT
"""Concurrent writer tests for persist_finding.

The 16-worker parallel runner means up to 16 threads can call
persist_finding on the same DB simultaneously. v0.2.13 set
busy_timeout=5000ms in core.persistence.connect to handle the
contention; this file pins that the contract holds under load.
"""

from __future__ import annotations

import sys
import threading
import time
from pathlib import Path
from unittest.mock import patch

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence.findings import persist_finding


@patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
class TestConcurrentWriters:
    def test_16_threads_no_database_locked(self, mock_prov, db_path):
        """16 threads writing simultaneously must not raise database-locked.

        This is the regression test for the v0.2.13 busy_timeout fix.
        Pre-fix, busy_timeout was 0 and contention raised
        sqlite3.OperationalError("database is locked") on the slowest
        threads. The 5000ms wait should be more than enough for 16
        small inserts to serialize cleanly.
        """
        errors: list[Exception] = []
        results: list[int] = []
        n_threads = 16
        n_writes_per_thread = 5

        def worker(thread_id: int):
            try:
                for i in range(n_writes_per_thread):
                    row_id = persist_finding(
                        db_path=db_path,
                        domain="test",
                        engine=f"thread_{thread_id}",
                        evidence_type="metric",
                        finding=f"WHAT: thread {thread_id} write {i}. SO WHAT: ok. NOW WHAT: ok.",
                        confidence=0.5,
                    )
                    results.append(row_id)
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(n_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        assert not errors, f"Concurrent writers should not raise: {errors}"
        # Each successful insert should have produced a positive row id
        assert len(results) == n_threads * n_writes_per_thread
        assert all(r > 0 for r in results), (
            f"Expected all positive row ids, got: {[r for r in results if r <= 0]}"
        )

    def test_concurrent_writes_finish_in_reasonable_time(self, mock_prov, db_path):
        """16 threads x 3 writes each must complete in < 30s.

        This is a soft latency test — if it ever takes longer, something
        is contending way more than expected and the busy_timeout is
        being hit. The actual measured time on a 2024 M-series Mac is
        ~1-2 seconds.
        """
        n_threads = 16
        n_writes = 3
        errors: list[Exception] = []

        def worker(tid: int):
            try:
                for i in range(n_writes):
                    persist_finding(
                        db_path=db_path,
                        domain="test",
                        engine=f"latency_{tid}",
                        evidence_type="metric",
                        finding=f"WHAT: latency {tid}/{i}. SO WHAT: ok. NOW WHAT: ok.",
                    )
            except Exception as exc:
                errors.append(exc)

        start = time.monotonic()
        threads = [threading.Thread(target=worker, args=(i,)) for i in range(n_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)
        elapsed = time.monotonic() - start

        assert not errors
        assert elapsed < 30, f"Concurrent writes took {elapsed:.1f}s — too slow"


class TestConcurrentReadersDuringWrite:
    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_readers_dont_block_writers(self, mock_prov, db_path):
        """WAL mode allows readers and a writer to coexist. Spin up
        multiple readers and a writer; nothing should fail.
        """
        from core.persistence import connect

        # Seed a row
        persist_finding(
            db_path=db_path,
            domain="test",
            engine="seed",
            evidence_type="metric",
            finding="WHAT: seed. SO WHAT: ok. NOW WHAT: ok.",
        )

        errors: list[Exception] = []
        stop = threading.Event()

        def reader():
            try:
                conn = connect(db_path)
                while not stop.is_set():
                    conn.execute("SELECT COUNT(*) FROM evidence").fetchone()
                conn.close()
            except Exception as exc:
                errors.append(exc)

        def writer():
            try:
                for i in range(20):
                    persist_finding(
                        db_path=db_path,
                        domain="test",
                        engine=f"wal_writer_{i}",
                        evidence_type="metric",
                        finding=f"WHAT: write {i}. SO WHAT: ok. NOW WHAT: ok.",
                    )
            except Exception as exc:
                errors.append(exc)

        readers = [threading.Thread(target=reader) for _ in range(8)]
        for r in readers:
            r.start()
        writer_t = threading.Thread(target=writer)
        writer_t.start()
        writer_t.join(timeout=30)
        stop.set()
        for r in readers:
            r.join(timeout=5)

        assert not errors, f"WAL readers/writer should coexist: {errors}"
