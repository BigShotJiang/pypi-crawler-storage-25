# SPDX-License-Identifier: MIT
"""Tests for domains.intelligence.engines.repo_relationship_mapper."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from domains.intelligence.engines import repo_relationship_mapper as mapper


def _make_repo(root: Path, name: str, files: dict[str, str]) -> Path:
    """Create a small fake git repo layout."""
    repo = root / name
    repo.mkdir(parents=True, exist_ok=True)
    (repo / ".git").mkdir(exist_ok=True)
    for rel, content in files.items():
        target = repo / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)
    return repo


def test_module_import_smoke():
    """Entry point and alias are exported and callable."""
    assert callable(mapper.refresh_relationships)
    assert callable(mapper.scan_relationships)


def test_refresh_relationships_empty_workspace_returns_empty(tmp_path, db_path):
    """An empty workspace should return an empty dict, not crash."""
    result = mapper.refresh_relationships(
        db_path=db_path,
        workspace=str(tmp_path),
    )
    assert result == {} or result.get("nodes") == 0


def test_refresh_relationships_missing_workspace(db_path):
    """A completely missing workspace returns {} gracefully."""
    result = mapper.refresh_relationships(
        db_path=db_path,
        workspace="/this/path/does/not/exist",
    )
    assert result == {}


def test_refresh_relationships_fake_workspace(fake_workspace, db_path):
    """Runs against the conftest fake_workspace and emits summary findings."""
    result = mapper.refresh_relationships(
        db_path=db_path,
        workspace=str(fake_workspace),
    )
    # fake_workspace contains two fake repos (go-zenon + znn_sdk_dart).
    assert result.get("nodes", 0) >= 1
    # Summary finding must be present.
    from core.persistence.metrics import query_table

    rows = query_table(
        db_path=db_path,
        table="evidence",
        where="engine = ?",
        params=("repo_relationship_mapper",),
        limit=100,
    )
    assert rows, "expected at least one finding"


def test_refresh_relationships_detects_version_drift(tmp_path, db_path):
    """Two consumers pinning different versions of a workspace repo -> drift."""
    _make_repo(
        tmp_path,
        "libx",
        {
            "go.mod": "module github.com/example/libx\ngo 1.25\n",
        },
    )
    _make_repo(
        tmp_path,
        "consumer_a",
        {
            "go.mod": (
                "module github.com/example/consumer_a\n"
                "go 1.25\n"
                "require github.com/example/libx v0.1.0\n"
            ),
        },
    )
    _make_repo(
        tmp_path,
        "consumer_b",
        {
            "go.mod": (
                "module github.com/example/consumer_b\n"
                "go 1.25\n"
                "require github.com/example/libx v0.2.0\n"
            ),
        },
    )
    # Patch git fork detection to avoid subprocess.
    with patch(
        "domains.intelligence.engines.repo_relationship_mapper.find_upstream_forks",
        return_value=[],
    ):
        result = mapper.refresh_relationships(
            db_path=db_path,
            workspace=str(tmp_path),
        )
    assert result.get("version_drift_findings", 0) >= 1


def test_scan_relationships_alias(tmp_path, db_path):
    """The scheduler-discoverable alias delegates to the canonical function."""
    # Use the missing workspace path to guarantee {} — we just want to
    # prove the alias returns the same type without raising.
    result = mapper.scan_relationships(
        db_path=db_path,
        workspace=str(tmp_path / "nothing"),
    )
    assert result == {}
