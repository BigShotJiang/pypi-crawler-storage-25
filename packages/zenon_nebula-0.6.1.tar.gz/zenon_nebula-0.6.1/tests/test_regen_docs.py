# SPDX-License-Identifier: MIT
"""Regression tests for scripts/regen_docs.py.

Pre-v0.2.18 the README version badge was a hand-edited literal that
nobody bumped on release. The badge had been stuck at `v0.2.0` since
forever. The user noticed and asked: "shouldn't this be part of the
pipeline?" — yes. ``regen_docs.rewrite_version_badge`` now updates it
from ``core/version.py`` and the release workflow's `--check` mode
fails CI on a stale badge.
"""

from __future__ import annotations

import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))


class TestVersionBadgeRegen:
    def test_rewrite_version_badge_updates_old_version(self, tmp_path):
        """A README with v0.2.0 must rewrite to the current version."""
        from scripts.regen_docs import rewrite_version_badge

        readme = tmp_path / "README.md"
        readme.write_text(
            "# Project\n\n"
            '<p align="center">\n'
            '  <img src="https://img.shields.io/badge/version-v0.2.0-informational" '
            'alt="Version v0.2.0">\n'
            "</p>\n"
        )

        changed, new = rewrite_version_badge(readme, "0.2.18")
        assert changed
        assert "version-v0.2.18-informational" in new
        assert 'alt="Version v0.2.18"' in new
        assert "0.2.0" not in new

    def test_rewrite_version_badge_idempotent(self, tmp_path):
        """If the badge is already current, no change."""
        from scripts.regen_docs import rewrite_version_badge

        readme = tmp_path / "README.md"
        readme.write_text(
            "# Project\n\n"
            '<img src="https://img.shields.io/badge/version-v0.2.18-informational" '
            'alt="Version v0.2.18">\n'
        )

        changed, _ = rewrite_version_badge(readme, "0.2.18")
        assert not changed

    def test_rewrite_version_badge_no_badge_no_change(self, tmp_path):
        """A README with no version badge is left alone."""
        from scripts.regen_docs import rewrite_version_badge

        readme = tmp_path / "README.md"
        readme.write_text("# Project\n\nNo badge here.\n")

        changed, _ = rewrite_version_badge(readme, "0.2.18")
        assert not changed

    def test_rewrite_version_badge_handles_other_colors(self, tmp_path):
        """The regex must work with other shields.io color suffixes."""
        from scripts.regen_docs import rewrite_version_badge

        readme = tmp_path / "README.md"
        readme.write_text(
            '<img src="https://img.shields.io/badge/version-v0.1.0-blue" alt="Version v0.1.0">\n'
        )

        changed, new = rewrite_version_badge(readme, "0.2.18")
        assert changed
        assert "version-v0.2.18-blue" in new

    def test_real_readme_badge_matches_core_version(self):
        """The real README.md must have a badge matching core.version."""
        import re

        from core.version import __version__

        readme = ENGINE_ROOT / "README.md"
        if not readme.exists():
            return  # not a smoke-tested layout

        contents = readme.read_text(encoding="utf-8")
        match = re.search(
            r"shields\.io/badge/version-v(\d+\.\d+\.\d+)-",
            contents,
        )
        if match is None:
            return  # no badge present in this checkout
        assert match.group(1) == __version__, (
            f"README badge says v{match.group(1)}, but core/version.py "
            f"says {__version__}. Run `python3 scripts/regen_docs.py`."
        )
