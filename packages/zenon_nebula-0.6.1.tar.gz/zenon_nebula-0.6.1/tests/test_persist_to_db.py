# SPDX-License-Identifier: MIT
"""Tests for core.persist_to_db -- Evidence persistence, Bayesian updates, dedup."""

import json
import sqlite3
from unittest.mock import patch

import pytest

from core.persist_to_db import (
    ensure_schema,
    get_all_evidence_for_hypothesis,
    get_findings_by_domain,
    get_findings_by_engine,
    get_hypothesis,
    persist_action,
    persist_ecosystem_event,
    persist_finding,
)

# After the core.persist_to_db -> core.persistence split, classify_provenance
# is imported into core.persistence.findings, which is where the real call
# site lives. Tests must patch that name, not the legacy shim.


@pytest.fixture
def db_path(tmp_path):
    """Return an in-memory-style temp DB path."""
    path = str(tmp_path / "test.db")
    ensure_schema(path)
    return path


@pytest.fixture
def db_with_hypothesis(db_path):
    """DB with a pre-seeded hypothesis at 0.5 confidence."""
    conn = sqlite3.connect(db_path)
    conn.execute(
        "INSERT INTO hypotheses (id, domain, title, confidence, status) "
        "VALUES ('hyp_1', 'test', 'Test Hypothesis', 0.5, 'INVESTIGATING')"
    )
    conn.commit()
    conn.close()
    return db_path


class TestSchemaCreation:
    def test_tables_exist(self, db_path):
        conn = sqlite3.connect(db_path)
        tables = {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        }
        conn.close()
        assert "evidence" in tables
        assert "hypotheses" in tables
        assert "actions_log" in tables
        assert "ecosystem_events" in tables

    def test_idempotent(self, db_path):
        # Calling twice should not raise
        ensure_schema(db_path)
        ensure_schema(db_path)


class TestPersistFinding:
    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_basic_insert(self, mock_prov, db_path):
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="test_engine",
            evidence_type="unit_test",
            finding="Found something important",
            confidence=0.75,
        )
        assert isinstance(row_id, int)
        assert row_id > 0

    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_raw_data_stored_as_json(self, mock_prov, db_path):
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="e1",
            evidence_type="t1",
            finding="data test",
            raw_data={"key": "value"},
        )
        conn = sqlite3.connect(db_path)
        row = conn.execute("SELECT raw_data FROM evidence WHERE id = ?", (row_id,)).fetchone()
        conn.close()
        parsed = json.loads(row[0])
        assert parsed["data"]["key"] == "value"
        assert "provenance" in parsed

    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_dedup_returns_existing_id(self, mock_prov, db_path):
        id1 = persist_finding(
            db_path=db_path,
            engine="e1",
            evidence_type="t1",
            finding="duplicate finding",
        )
        id2 = persist_finding(
            db_path=db_path,
            engine="e1",
            evidence_type="t1",
            finding="duplicate finding",
        )
        assert id1 == id2

    @patch("core.persistence.findings.classify_provenance", return_value="verified_by_api")
    def test_provenance_classification_stored(self, mock_prov, db_path):
        row_id = persist_finding(
            db_path=db_path,
            engine="e1",
            evidence_type="t1",
            finding="api-backed finding",
            fingerprints=[{"url": "https://example.com", "status_code": 200}],
        )
        conn = sqlite3.connect(db_path)
        row = conn.execute("SELECT raw_data FROM evidence WHERE id = ?", (row_id,)).fetchone()
        conn.close()
        parsed = json.loads(row[0])
        assert parsed["provenance"] == "verified_by_api"
        assert parsed["fingerprint_hash"] != ""


class TestEngineDefaultRepo:
    """v0.2.19 added _ENGINE_DEFAULT_REPO so engines that scan a known
    target get source_repo auto-filled. Pre-v0.2.19, 117 of 143
    persist_finding calls weren't passing source_repo at all and the
    evidence-chains trust model couldn't weight findings properly.
    """

    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_security_engines_default_to_go_zenon(self, mock_prov, db_path):
        row_id = persist_finding(
            db_path=db_path,
            domain="security",
            engine="adversarial_reviewer",
            evidence_type="bug",
            finding="WHAT: bug. SO WHAT: bad. NOW WHAT: fix.",
        )
        conn = sqlite3.connect(db_path)
        row = conn.execute("SELECT source_repo FROM evidence WHERE id = ?", (row_id,)).fetchone()
        conn.close()
        assert row[0] == "go-zenon"

    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_sdk_verifier_defaults_to_znn_sdk_dart(self, mock_prov, db_path):
        row_id = persist_finding(
            db_path=db_path,
            domain="quality",
            engine="sdk_verifier",
            evidence_type="abi_drift",
            finding="WHAT: drift. SO WHAT: drift. NOW WHAT: drift.",
        )
        conn = sqlite3.connect(db_path)
        row = conn.execute("SELECT source_repo FROM evidence WHERE id = ?", (row_id,)).fetchone()
        conn.close()
        assert row[0] == "znn_sdk_dart"

    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_explicit_source_repo_overrides_default(self, mock_prov, db_path):
        """An explicit source_repo arg must win over the engine default."""
        row_id = persist_finding(
            db_path=db_path,
            domain="security",
            engine="adversarial_reviewer",
            evidence_type="bug",
            finding="WHAT: x. SO WHAT: y. NOW WHAT: z.",
            source_repo="custom-fork/of-go-zenon",
        )
        conn = sqlite3.connect(db_path)
        row = conn.execute("SELECT source_repo FROM evidence WHERE id = ?", (row_id,)).fetchone()
        conn.close()
        assert row[0] == "custom-fork/of-go-zenon"

    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_unknown_engine_leaves_source_repo_null(self, mock_prov, db_path):
        """An engine not in the registry must NOT get a fake source_repo."""
        row_id = persist_finding(
            db_path=db_path,
            domain="economics",
            engine="treasury_monitor",  # live API, no repo
            evidence_type="balance",
            finding="WHAT: bal. SO WHAT: bal. NOW WHAT: bal.",
        )
        conn = sqlite3.connect(db_path)
        row = conn.execute("SELECT source_repo FROM evidence WHERE id = ?", (row_id,)).fetchone()
        conn.close()
        assert row[0] is None

    def test_registry_has_all_repo_scanning_engines(self):
        """The registry must include all engines from the security,
        quality, development, and intelligence/scanning domains.
        """
        from core.persistence.findings import _ENGINE_DEFAULT_REPO

        # Spot-check the most critical entries
        critical = {
            "adversarial_reviewer",
            "static_analyzer",
            "vuln_scanner",
            "spec_tracker",
            "spec_verifier",
            "sdk_verifier",
            "cross_repo_checker",
        }
        missing = critical - set(_ENGINE_DEFAULT_REPO.keys())
        assert not missing, f"Registry missing critical engines: {missing}"


class TestPersistAction:
    def test_basic_action(self, db_path):
        row_id = persist_action(
            db_path=db_path,
            domain="test",
            module="test_mod",
            action="ran_analysis",
            cost_usd=0.05,
            tokens_used=1000,
            model="claude-sonnet",
        )
        assert row_id > 0

    def test_action_with_error(self, db_path):
        row_id = persist_action(
            db_path=db_path,
            module="failing_mod",
            action="failed_call",
            error="Timeout after 30s",
        )
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM actions_log WHERE id = ?", (row_id,)).fetchone()
        conn.close()
        assert row["error"] == "Timeout after 30s"


class TestEcosystemEvent:
    def test_persist_event(self, db_path):
        row_id = persist_ecosystem_event(
            db_path=db_path,
            domain="intelligence",
            event_type="github_commit",
            source="go-zenon",
            details="New commit on main",
            commit_hash="abc123",
        )
        assert row_id > 0


class TestBayesianHypothesisUpdate:
    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_supporting_evidence_increases_confidence(self, mock_prov, db_with_hypothesis):
        persist_finding(
            db_path=db_with_hypothesis,
            engine="e1",
            evidence_type="support_test",
            finding="Supporting evidence",
            confidence=0.9,
            supports_hypothesis="hyp_1",
        )
        hyp = get_hypothesis(db_with_hypothesis, "hyp_1")
        assert hyp is not None
        assert hyp["confidence"] > 0.5

    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_contradicting_evidence_decreases_confidence(self, mock_prov, db_with_hypothesis):
        persist_finding(
            db_path=db_with_hypothesis,
            engine="e1",
            evidence_type="contradict_test",
            finding="Contradicting evidence",
            confidence=0.9,
            contradicts_hypothesis="hyp_1",
        )
        hyp = get_hypothesis(db_with_hypothesis, "hyp_1")
        assert hyp is not None
        assert hyp["confidence"] < 0.5

    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_confidence_clamped(self, mock_prov, db_with_hypothesis):
        # Push confidence high with multiple supporting findings
        for i in range(10):
            persist_finding(
                db_path=db_with_hypothesis,
                engine="e1",
                evidence_type=f"push_high_{i}",
                finding=f"Strong support {i}",
                confidence=0.99,
                supports_hypothesis="hyp_1",
            )
        hyp = get_hypothesis(db_with_hypothesis, "hyp_1")
        assert hyp["confidence"] <= 0.99


class TestQueryFunctions:
    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_get_findings_by_engine(self, mock_prov, db_path):
        persist_finding(db_path=db_path, engine="eng_a", evidence_type="t", finding="f1")
        persist_finding(db_path=db_path, engine="eng_b", evidence_type="t", finding="f2")
        results = get_findings_by_engine(db_path, "eng_a")
        assert len(results) == 1
        assert results[0]["engine"] == "eng_a"

    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_get_findings_by_domain(self, mock_prov, db_path):
        persist_finding(
            db_path=db_path, domain="alpha", engine="e", evidence_type="t", finding="f1"
        )
        persist_finding(db_path=db_path, domain="beta", engine="e", evidence_type="t", finding="f2")
        results = get_findings_by_domain(db_path, "alpha")
        assert len(results) == 1
        assert results[0]["domain"] == "alpha"

    @patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
    def test_get_all_evidence_for_hypothesis(self, mock_prov, db_with_hypothesis):
        persist_finding(
            db_path=db_with_hypothesis,
            engine="e",
            evidence_type="t",
            finding="supports",
            supports_hypothesis="hyp_1",
        )
        persist_finding(
            db_path=db_with_hypothesis,
            engine="e",
            evidence_type="t",
            finding="contradicts",
            contradicts_hypothesis="hyp_1",
        )
        evidence = get_all_evidence_for_hypothesis(db_with_hypothesis, "hyp_1")
        assert len(evidence) == 2
