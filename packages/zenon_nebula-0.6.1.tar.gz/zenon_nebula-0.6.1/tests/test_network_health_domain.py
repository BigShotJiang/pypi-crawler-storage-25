# SPDX-License-Identifier: MIT
"""Tests for domains.network_health.domain -- Node census and decentralization."""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.network_health.domain import NetworkHealthDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestNetworkHealthDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(NetworkHealthDomain, DomainPlugin)

    def test_name(self):
        assert NetworkHealthDomain().name() == "network_health"

    def test_get_engines_non_empty(self):
        engines = NetworkHealthDomain().get_engines()
        assert len(engines) >= 2
        names = [e.name for e in engines]
        assert "node_census" in names
        assert "bridge_health" in names

    def test_get_hypothesis_types_non_empty(self):
        types = NetworkHealthDomain().get_hypothesis_types()
        assert len(types) >= 1

    def test_get_aspiration_types(self):
        assert isinstance(NetworkHealthDomain().get_aspiration_types(), list)

    def test_get_collision_signals(self):
        assert isinstance(NetworkHealthDomain().get_collision_signals(), list)

    def test_get_war_room_contributions(self):
        assert isinstance(NetworkHealthDomain().get_war_room_contributions(), list)

    def test_get_self_improvement_metrics(self):
        metrics = NetworkHealthDomain().get_self_improvement_metrics()
        assert isinstance(metrics, dict)

    def test_get_db_schema_sql(self):
        sql = NetworkHealthDomain().get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action(self):
        action = NetworkHealthDomain().decide_next_action({})
        assert action is None or isinstance(action, dict)

    def test_high_priority(self):
        """Network health should be high priority (low number)."""
        assert NetworkHealthDomain().get_priority() <= 3

    def test_registration(self):
        registry = DomainRegistry.instance()
        registry.register(NetworkHealthDomain())
        assert registry.get_domain("network_health") is not None
