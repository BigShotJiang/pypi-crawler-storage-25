# SPDX-License-Identifier: MIT
"""
Tests for core.war_room -- Unified daily battle plan.

Uses a temporary SQLite database with real schema and test data
to validate context building, battle plan generation (with mock LLM),
and persistence.
"""

import sqlite3
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.collision_engine import CollisionEngine
from core.domain_registry import DomainRegistry
from core.persist_to_db import ensure_schema
from core.war_room import WarRoom


@pytest.fixture
def db_path(tmp_path):
    """Create a temporary database with multi-domain data."""
    db = str(tmp_path / "test_engine.db")
    ensure_schema(db)

    conn = sqlite3.connect(db)

    # Evidence across domains
    for domain, engine, finding, conf in [
        ("intelligence", "upstream_watcher", "3 new commits", 0.9),
        ("intelligence", "signal_detector", "Breaking change", 0.7),
        ("development", "spec_tracker", "htlc spec parsed", 0.8),
        ("security", "adversarial_reviewer", "No critical vulns", 0.95),
        ("quality", "spec_verifier", "ABI match 100%", 0.99),
        ("contribution", "pr_readiness", "PR tier1 pass", 0.8),
    ]:
        conn.execute(
            "INSERT INTO evidence (domain, engine, evidence_type, "
            "finding, confidence) VALUES (?, ?, 'test', ?, ?)",
            (domain, engine, finding, conf),
        )

    # Hypotheses
    conn.execute(
        "INSERT INTO hypotheses (id, domain, title, confidence, status) "
        "VALUES ('H001', 'security', 'Fund safety verified', 0.95, "
        "'INVESTIGATING')"
    )

    # Actions
    for module, action, cost in [
        ("upstream_watcher", "scan", 0.01),
        ("spec_tracker", "parse", 0.02),
        ("adversarial_reviewer", "review", 0.15),
    ]:
        conn.execute(
            "INSERT INTO actions_log (domain, module, action, cost_usd) VALUES ('system', ?, ?, ?)",
            (module, action, cost),
        )

    conn.commit()
    conn.close()

    # Ensure collisions table exists
    CollisionEngine(db_path=db)

    return db


class TestContextBuilding:
    """Test war room context aggregation."""

    def test_builds_context(self, db_path):
        war_room = WarRoom(db_path=db_path)
        context = war_room.build_context()

        assert "EVIDENCE" in context
        assert "HYPOTHESES" in context
        assert "RECENT ACTIONS" in context
        assert len(context) > 100

    def test_context_includes_all_domains(self, db_path):
        war_room = WarRoom(db_path=db_path)
        context = war_room.build_context()

        assert "intelligence" in context
        assert "security" in context
        assert "quality" in context
        assert "development" in context
        assert "contribution" in context

    def test_context_with_registry(self, db_path):
        DomainRegistry.reset()
        registry = DomainRegistry.instance()

        from domains.intelligence.domain import IntelligenceDomain
        from domains.security.domain import SecurityDomain

        registry.register(IntelligenceDomain())
        registry.register(SecurityDomain())

        war_room = WarRoom(db_path=db_path)
        context = war_room.build_context(registry=registry)

        assert "DOMAIN CONTRIBUTIONS" in context
        assert "Upstream Activity" in context
        assert "Security Posture" in context

        DomainRegistry.reset()


class TestBattlePlanGeneration:
    """Test battle plan generation with mock LLM."""

    def test_mock_llm_plan(self, db_path):
        mock_plan = {
            "situation_assessment": "System is healthy across all domains.",
            "whats_working": [
                {
                    "domain": "security",
                    "tactic": "adversarial review",
                    "evidence": "0 critical vulns",
                },
            ],
            "whats_failing": [
                {
                    "domain": "development",
                    "tactic": "coverage tracking",
                    "recommendation": "Run impl_coverage more frequently",
                },
            ],
            "battle_plan_24h": {
                "focus": "Fill development coverage gaps",
                "actions": [
                    "Run impl_coverage on all specs",
                    "Check for upstream breaking changes",
                ],
            },
            "resource_allocation": {
                "security": 0.3,
                "development": 0.3,
                "intelligence": 0.2,
                "quality": 0.1,
                "contribution": 0.1,
            },
            "cross_domain_opportunities": [
                {
                    "domains": ["security", "quality"],
                    "opportunity": "Joint ABI-security review",
                    "priority": 8,
                },
            ],
        }

        def mock_llm(system, prompt):
            return mock_plan

        war_room = WarRoom(db_path=db_path, llm_call=mock_llm)
        plan = war_room.run_assessment(dry_run=True)

        assert "situation_assessment" in plan
        assert plan["situation_assessment"] == ("System is healthy across all domains.")
        assert len(plan["whats_working"]) == 1
        assert len(plan["whats_failing"]) == 1
        assert "battle_plan_24h" in plan
        assert "generated_at" in plan

    def test_plan_persistence(self, db_path, tmp_path):
        """Test that battle plan is saved to file and DB."""
        mock_plan = {
            "situation_assessment": "Test plan.",
            "battle_plan_24h": {"focus": "test"},
        }

        def mock_llm(system, prompt):
            return mock_plan

        war_room = WarRoom(db_path=db_path, llm_call=mock_llm)
        war_room.run_assessment(dry_run=False)

        # Check DB
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT * FROM battle_plans ORDER BY id DESC LIMIT 1").fetchall()
        conn.close()

        assert len(rows) == 1
        assert rows[0]["situation_assessment"] == "Test plan."

    def test_get_current_plan(self, db_path):
        mock_plan = {
            "situation_assessment": "Current plan.",
            "battle_plan_24h": {"focus": "current"},
        }

        def mock_llm(system, prompt):
            return mock_plan

        war_room = WarRoom(db_path=db_path, llm_call=mock_llm)
        war_room.run_assessment(dry_run=False)

        current = war_room.get_current_plan()
        assert current is not None
        assert current["situation_assessment"] == "Current plan."


class TestJsonExtraction:
    """Test JSON extraction utility."""

    def test_extract_valid_json(self):
        text = 'Some text before {"key": "value"} and after'
        result = WarRoom._extract_json(text)
        assert result == {"key": "value"}

    def test_extract_nested_json(self):
        text = '{"a": {"b": [1, 2, 3]}, "c": true}'
        result = WarRoom._extract_json(text)
        assert result["a"]["b"] == [1, 2, 3]

    def test_extract_invalid_returns_empty(self):
        result = WarRoom._extract_json("no json here")
        assert result == {}
