# SPDX-License-Identifier: MIT
"""Tests for :mod:`core.shutdown`."""

from __future__ import annotations

import signal
import threading
import time

import pytest

from core import shutdown


@pytest.fixture(autouse=True)
def _reset_shutdown():
    shutdown.reset()
    yield
    shutdown.reset()


def test_is_shutting_down_default_is_false():
    assert shutdown.is_shutting_down() is False


def test_request_shutdown_flips_flag():
    shutdown.request_shutdown()
    assert shutdown.is_shutting_down() is True


def test_install_signal_handlers_is_idempotent():
    # First install returns True (or False on a non-main thread runner);
    # subsequent calls always return False.
    first = shutdown.install_signal_handlers()
    second = shutdown.install_signal_handlers()
    assert second is False
    # Either it installed cleanly (True) or we're off-main-thread and
    # it degraded gracefully (False). Both are acceptable.
    assert first in (True, False)


def test_wait_for_shutdown_with_timeout_returns_false_when_no_signal():
    start = time.perf_counter()
    result = shutdown.wait_for_shutdown(timeout=0.05)
    elapsed = time.perf_counter() - start
    assert result is False
    assert elapsed >= 0.04  # tolerate timer slop


def test_wait_for_shutdown_returns_true_when_flag_set():
    def _set_later():
        time.sleep(0.05)
        shutdown.request_shutdown()

    t = threading.Thread(target=_set_later, daemon=True)
    t.start()
    result = shutdown.wait_for_shutdown(timeout=2.0)
    t.join(timeout=2.0)
    assert result is True


def test_on_shutdown_registers_and_fires_callback():
    fired: list[int] = []

    def cb():
        fired.append(1)

    shutdown.on_shutdown(cb)
    shutdown.request_shutdown()
    assert fired == [1]


def test_on_shutdown_as_decorator():
    fired = threading.Event()

    @shutdown.on_shutdown
    def cb() -> None:
        fired.set()

    shutdown.request_shutdown()
    assert fired.is_set()


def test_shutdown_callback_exception_is_logged_not_raised():
    """A broken callback must not crash the signal handler."""

    def bad_cb():
        raise RuntimeError("boom")

    shutdown.on_shutdown(bad_cb)
    # If this raises, the test fails.
    shutdown.request_shutdown()
    assert shutdown.is_shutting_down()


def test_reset_clears_state():
    shutdown.request_shutdown()
    shutdown.reset()
    assert shutdown.is_shutting_down() is False


def test_signal_handler_installs_cleanly_for_sigterm_on_main_thread():
    """Confirm SIGTERM registers without raising.

    We don't actually raise the signal in the test — running
    ``os.kill`` against the test runner is too invasive — but
    confirming ``install_signal_handlers`` doesn't throw on a fresh
    process is valuable.
    """
    # install_signal_handlers is idempotent after the autouse reset,
    # so force=True via reinstalling a single signal directly is the
    # cleanest assertion.
    try:
        signal.signal(signal.SIGTERM, signal.SIG_DFL)
    except (ValueError, OSError):
        pytest.skip("platform does not support SIGTERM installation")
    ok = shutdown.install_signal_handlers((signal.SIGTERM,))
    assert isinstance(ok, bool)
