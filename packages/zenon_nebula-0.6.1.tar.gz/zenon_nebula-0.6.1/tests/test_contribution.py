# SPDX-License-Identifier: MIT
"""Tests for the Contribution domain plugin and its engines."""

import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainRegistry
from domains.contribution.domain import ContributionDomain
from domains.contribution.engines.pr_description_gen import (
    PR_TEMPLATE,
    generate_description,
    get_base_branch,
    get_branch_name,
    get_commits,
)
from domains.contribution.engines.pr_readiness import (
    TIER_WEIGHTS,
    assess_readiness,
    get_readiness_report,
    persist_readiness,
)
from domains.contribution.engines.tminusz_contributor import (
    check_all_contributions,
    check_contribution_status,
    contribute_test_vectors,
    extract_test_vectors,
    format_test_vectors_json,
    generate_implementation_notes,
    get_spec_dir,
)

# -- Fixtures --


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


@pytest.fixture
def tmp_db():
    """Create a temporary database with contribution domain schema."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    conn = sqlite3.connect(db_path)
    domain = ContributionDomain()
    conn.executescript(domain.get_db_schema_sql())
    conn.commit()
    conn.close()

    yield db_path
    os.unlink(db_path)


# -- Domain registration tests --


class TestContributionDomainRegistration:
    def test_domain_name(self):
        domain = ContributionDomain()
        assert domain.name() == "contribution"

    def test_domain_priority(self):
        domain = ContributionDomain()
        assert domain.get_priority() == 4

    def test_domain_registers_with_registry(self):
        registry = DomainRegistry.instance()
        domain = ContributionDomain()
        registry.register(domain)
        assert "contribution" in registry.get_domain_names()

    def test_domain_engines_count(self):
        domain = ContributionDomain()
        engines = domain.get_engines()
        assert len(engines) == 5  # v0.4.3 added workspace_recommender
        names = {e.name for e in engines}
        assert "pr_readiness" in names
        assert "pr_description_gen" in names
        assert "tminusz_contributor" in names
        assert "auto_contributor" in names
        assert "workspace_recommender" in names

    def test_domain_hypothesis_types(self):
        domain = ContributionDomain()
        types = domain.get_hypothesis_types()
        assert len(types) >= 2
        type_ids = {t.type_id for t in types}
        assert "pr_ready" in type_ids
        assert "pr_blocked" in type_ids

    def test_domain_db_schema(self):
        domain = ContributionDomain()
        sql = domain.get_db_schema_sql()
        assert "pr_tracking" in sql

    def test_decide_next_action_urgent(self):
        domain = ContributionDomain()
        action = domain.decide_next_action(
            {
                "trigger_level": "urgent",
                "stale_data": [],
            }
        )
        assert action["engine"] == "pr_readiness"

    def test_decide_next_action_routine(self):
        domain = ContributionDomain()
        action = domain.decide_next_action(
            {
                "trigger_level": "routine",
                "stale_data": [],
            }
        )
        assert action["engine"] == "pr_description_gen"

    def test_decide_next_action_stale_readiness(self):
        """v0.4.3 — rotation rewrite: routine context exhausts engines
        rather than stale-tag gating. The test now exercises the new
        rotation by draining the candidate list and asserting that
        pr_readiness IS in the rotation (it's not the first yield
        anymore, but it appears as the scheduler drains)."""
        domain = ContributionDomain()
        exclude: set[str] = set()
        seen_engines: set[str] = set()
        for _ in range(20):
            action = domain.decide_next_action(
                {"trigger_level": "routine", "stale_data": []},
                exclude=exclude,
            )
            if action is None:
                break
            seen_engines.add(action["engine"])
            exclude.add(f"contribution:{action['action']}")
        assert "pr_readiness" in seen_engines

    def test_duplicate_registration_raises(self):
        registry = DomainRegistry.instance()
        registry.register(ContributionDomain())
        with pytest.raises(ValueError):
            registry.register(ContributionDomain())


# -- PR readiness tests --


class TestPRReadiness:
    def test_tier_weights_sum_to_one(self):
        total = sum(TIER_WEIGHTS.values())
        assert abs(total - 1.0) < 0.01

    def test_assess_readiness_returns_structure(self, tmp_path):
        # Create a minimal repo to assess
        (tmp_path / "main.go").write_text("package main\n")
        result = assess_readiness(tmp_path, language="go")
        assert "score" in result
        assert "tier1_pass" in result
        assert "tier2_pass" in result
        assert "tier3_pass" in result
        assert "checklist" in result
        assert isinstance(result["checklist"], list)
        assert 0.0 <= result["score"] <= 1.0

    def test_assess_readiness_checklist_has_tiers(self, tmp_path):
        (tmp_path / "main.go").write_text("package main\n")
        result = assess_readiness(tmp_path, language="go")
        tiers = {c["tier"] for c in result["checklist"]}
        assert 1 in tiers
        assert 2 in tiers
        assert 3 in tiers

    def test_persist_readiness(self, tmp_db, tmp_path):
        (tmp_path / "main.go").write_text("package main\n")
        result = assess_readiness(tmp_path, language="go")
        row_id = persist_readiness(
            "test-repo",
            "feature-branch",
            result,
            db_path=tmp_db,
        )
        assert row_id > 0

        conn = sqlite3.connect(tmp_db)
        row = conn.execute("SELECT * FROM pr_tracking WHERE id = ?", (row_id,)).fetchone()
        conn.close()
        assert row is not None

    def test_get_readiness_report_empty(self, tmp_db):
        report = get_readiness_report(db_path=tmp_db)
        assert report == []

    def test_get_readiness_report_with_data(self, tmp_db, tmp_path):
        (tmp_path / "main.go").write_text("package main\n")
        result = assess_readiness(tmp_path, language="go")
        persist_readiness("test-repo", "main", result, db_path=tmp_db)

        report = get_readiness_report(db_path=tmp_db)
        assert len(report) == 1
        assert report[0]["repo_name"] == "test-repo"


# -- PR description gen tests --


class TestPRDescriptionGen:
    def test_pr_template_has_sections(self):
        assert "## Summary" in PR_TEMPLATE
        assert "## Spec Reference" in PR_TEMPLATE
        assert "## Changes" in PR_TEMPLATE
        assert "## Testing Evidence" in PR_TEMPLATE
        assert "## Cross-repo Dependencies" in PR_TEMPLATE

    def test_generate_description_on_engine_repo(self):
        repo_path = ENGINE_ROOT
        description = generate_description(repo_path)
        assert "## Summary" in description
        assert "## Changes" in description

    def test_get_branch_name(self):
        branch = get_branch_name(ENGINE_ROOT)
        assert branch is not None
        assert isinstance(branch, str)

    def test_get_base_branch(self):
        base = get_base_branch(ENGINE_ROOT)
        assert base in ("main", "master")

    def test_get_commits_returns_list(self):
        commits = get_commits(ENGINE_ROOT)
        assert isinstance(commits, list)

    def test_generate_description_non_repo(self, tmp_path):
        description = generate_description(tmp_path)
        assert "## Summary" in description
        # Should handle gracefully


# -- TminusZ contributor tests --


class TestTminusZContributor:
    def test_extract_test_vectors_returns_list(self):
        vectors = extract_test_vectors("htlc")
        assert isinstance(vectors, list)

    def test_format_test_vectors_json(self):
        vectors = [
            {"name": "test1", "source_file": "test.go", "contract": "htlc"},
        ]
        json_str = format_test_vectors_json("htlc", vectors)
        parsed = json.loads(json_str)
        assert parsed["contract"] == "htlc"
        assert parsed["version"] == "1.0"
        assert len(parsed["vectors"]) == 1

    def test_check_contribution_status_returns_dict(self):
        status = check_contribution_status("htlc")
        assert isinstance(status, dict)
        assert status["contract"] == "htlc"
        assert "has_test_vectors" in status
        assert "has_impl_notes" in status

    def test_check_all_contributions_returns_list(self):
        results = check_all_contributions(["htlc", "bridge"])
        assert len(results) == 2
        names = {r["contract"] for r in results}
        assert "htlc" in names
        assert "bridge" in names

    def test_generate_implementation_notes(self):
        notes = generate_implementation_notes("htlc")
        assert isinstance(notes, dict)
        assert notes["contract"] == "htlc"
        assert "notes" in notes
        assert "errata" in notes

    def test_contribute_test_vectors_dry_run(self):
        result = contribute_test_vectors("htlc", dry_run=True)
        assert isinstance(result, dict)
        assert result["contract"] == "htlc"
        assert result["written"] is False

    def test_get_spec_dir_returns_path_or_none(self):
        result = get_spec_dir("governance")
        # May or may not find it depending on workspace
        assert result is None or isinstance(result, Path)


# -- Cross-domain integration tests --


class TestCrossDomainIntegration:
    def test_all_four_domains_register(self):
        from domains.devops.domain import DevOpsDomain
        from domains.quality.domain import QualityDomain
        from domains.security.domain import SecurityDomain

        registry = DomainRegistry.instance()
        registry.register(SecurityDomain())
        registry.register(QualityDomain())
        registry.register(ContributionDomain())
        registry.register(DevOpsDomain())

        assert len(registry.get_domain_names()) == 4
        assert "security" in registry.get_domain_names()
        assert "quality" in registry.get_domain_names()
        assert "contribution" in registry.get_domain_names()
        assert "devops" in registry.get_domain_names()

    def test_priority_ordering(self):
        from domains.devops.domain import DevOpsDomain
        from domains.quality.domain import QualityDomain
        from domains.security.domain import SecurityDomain

        registry = DomainRegistry.instance()
        registry.register(SecurityDomain())
        registry.register(QualityDomain())
        registry.register(ContributionDomain())
        registry.register(DevOpsDomain())

        domains = registry.get_all_domains()
        priorities = [d.get_priority() for d in domains]
        assert priorities == sorted(priorities)
        assert domains[0].name() == "security"

    def test_combined_schema_sql(self):
        from domains.devops.domain import DevOpsDomain
        from domains.quality.domain import QualityDomain
        from domains.security.domain import SecurityDomain

        registry = DomainRegistry.instance()
        registry.register(SecurityDomain())
        registry.register(QualityDomain())
        registry.register(ContributionDomain())
        registry.register(DevOpsDomain())

        combined = registry.get_combined_schema_sql()
        assert "security_reviews" in combined
        assert "vuln_patterns" in combined
        assert "build_status" in combined
        assert "test_coverage" in combined
        assert "pr_tracking" in combined
        assert "devnet_runs" in combined
