# SPDX-License-Identifier: MIT
"""
Tests for core.self_improver -- Meta-analysis engine.

Tests module analysis from actions_log data, health classification,
cost efficiency scoring, improvement generation, and system-wide synthesis.
"""

import sqlite3
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persist_to_db import ensure_schema
from core.self_improver import SelfImprover


@pytest.fixture
def db_path(tmp_path):
    db = str(tmp_path / "test_engine.db")
    ensure_schema(db)
    return db


def _insert_actions(db_path, module, count, error_rate=0.0, cost=0.01):
    """Insert action log entries for a module."""
    conn = sqlite3.connect(db_path)
    for i in range(count):
        error = "test error" if (i / max(count, 1)) < error_rate else None
        conn.execute(
            "INSERT INTO actions_log (domain, module, action, result, "
            "cost_usd, tokens_used, error) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("test", module, f"action_{i}", f"result_{i}", cost, 100, error),
        )
    conn.commit()
    conn.close()


class TestAnalyzeModule:
    """Test single module analysis."""

    def test_insufficient_data(self, db_path):
        """Module with < 3 actions returns insufficient_data."""
        _insert_actions(db_path, "tiny_module", 2)
        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_module("tiny_module")

        assert report["status"] == "insufficient_data"
        assert report["actions_found"] == 2

    def test_healthy_module(self, db_path):
        """Module with low error rate is classified healthy."""
        _insert_actions(db_path, "good_module", 20, error_rate=0.0, cost=0.001)
        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_module("good_module")

        assert report["health"] == "healthy"
        assert report["stats"]["error_rate"] == 0.0

    def test_critical_module(self, db_path):
        """Module with >50% error rate is classified critical."""
        _insert_actions(db_path, "bad_module", 10, error_rate=0.6, cost=0.01)
        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_module("bad_module")

        assert report["health"] == "critical"
        assert report["stats"]["error_rate"] > 0.5

    def test_needs_attention_module(self, db_path):
        """Module with 20-50% error rate needs attention."""
        _insert_actions(db_path, "iffy_module", 10, error_rate=0.3, cost=0.01)
        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_module("iffy_module")

        assert report["health"] == "needs_attention"

    def test_cost_efficiency_wasteful(self, db_path):
        """High cost per action is flagged as wasteful."""
        _insert_actions(db_path, "expensive_module", 10, cost=0.50)
        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_module("expensive_module")

        assert report["cost_efficiency"] == "wasteful"

    def test_cost_efficiency_good(self, db_path):
        """Low cost per action is flagged as good."""
        _insert_actions(db_path, "cheap_module", 10, cost=0.001)
        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_module("cheap_module")

        assert report["cost_efficiency"] == "good"

    def test_improvements_generated_for_errors(self, db_path):
        """High error rate generates improvement recommendations."""
        _insert_actions(db_path, "error_module", 10, error_rate=0.4)
        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_module("error_module")

        assert len(report["improvements"]) >= 1
        assert any("error rate" in imp.lower() for imp in report["improvements"])

    def test_improvements_generated_for_cost(self, db_path):
        """High cost generates cost improvement recommendation."""
        _insert_actions(db_path, "pricey_module", 10, cost=0.50)
        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_module("pricey_module")

        assert any("cost" in imp.lower() for imp in report["improvements"])

    def test_nonexistent_module(self, db_path):
        """Module with no actions at all returns insufficient_data."""
        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_module("ghost_module")
        assert report["status"] == "insufficient_data"


class TestAnalyzeAll:
    """Test system-wide analysis."""

    def test_analyze_all_includes_core_modules(self, db_path):
        """analyze_all always includes core module names."""
        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_all()

        assert "modules" in report
        # Core modules are always checked
        assert "collision_engine" in report["modules"]
        assert "war_room" in report["modules"]

    def test_analyze_all_synthesis(self, db_path):
        """analyze_all produces a synthesis section."""
        _insert_actions(db_path, "good_mod", 10, error_rate=0.0, cost=0.001)
        _insert_actions(db_path, "bad_mod", 10, error_rate=0.6, cost=0.5)

        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_all()

        assert "synthesis" in report
        assert "system_health_score" in report["synthesis"]
        assert "health_counts" in report["synthesis"]
        assert "cost_ranking" in report["synthesis"]

    def test_synthesis_health_score(self, db_path):
        """Health score is 0-100 based on healthy module ratio."""
        _insert_actions(db_path, "mod_a", 10, error_rate=0.0, cost=0.001)
        _insert_actions(db_path, "mod_b", 10, error_rate=0.0, cost=0.001)

        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_all()

        score = report["synthesis"]["system_health_score"]
        assert 0 <= score <= 100

    def test_analysis_error_handling(self, db_path):
        """Errors in individual module analysis are captured."""
        improver = SelfImprover(db_path=db_path)
        report = improver.analyze_all()

        # Should complete without raising
        assert "completed_at" in report


class TestSaveReport:
    """Test report persistence."""

    def test_save_report_creates_file(self, db_path, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "core.self_improver.REPORT_FILE",
            tmp_path / "report.json",
        )

        improver = SelfImprover(db_path=db_path)
        report = {"modules": {}, "synthesis": {"system_health_score": 50}}
        improver.save_report(report)

        assert (tmp_path / "report.json").exists()
