# SPDX-License-Identifier: MIT
"""Tests for domains.quality.engines.reference_diff."""

from __future__ import annotations

from pathlib import Path

from core.persistence.metrics import persist_metric, query_table
from domains.quality.engines import reference_diff as diff


def _insert_workspace_repo(
    db_path: str,
    repo_name: str,
    repo_path: Path,
    repo_type: str,
) -> None:
    """Seed a single ``workspace_repos`` row for tests."""
    persist_metric(
        db_path=db_path,
        table="workspace_repos",
        data={
            "repo_name": repo_name,
            "repo_path": str(repo_path),
            "repo_type": repo_type,
            "languages": "[]",
            "has_ci": 0,
            "has_tests": 0,
            "classified_at": "2026-04-10T00:00:00+00:00",
        },
    )


def test_module_import_smoke():
    """Entry point and scheduler alias both exported."""
    assert callable(diff.diff_reference_implementations)
    assert callable(diff.check_reference_diff)


def test_empty_workspace_returns_empty(db_path):
    """No reference chain in catalog -> empty dict."""
    result = diff.diff_reference_implementations(db_path=db_path)
    assert result == {}


def test_fake_workspace_no_reference_chain(fake_workspace, db_path):
    """fake_workspace has no reference chain -> empty dict."""
    result = diff.diff_reference_implementations(db_path=db_path)
    assert result == {}


def test_detects_divergent_primitive(tmp_path, db_path):
    """A much larger reference implementation should flag divergence."""
    # Large reference implementation.
    ref = tmp_path / "bitcoin"
    ref.mkdir()
    (ref / "src").mkdir()
    ref_body = "\n".join(
        [
            "bool VerifyMerkleProof(const uint256& hash) {",
            *[f"    if (condition{i}) {{ return false; }}" for i in range(30)],
            "    return true;",
            "}",
        ]
    )
    (ref / "src" / "validation.cpp").write_text(ref_body)
    _insert_workspace_repo(db_path, "bitcoin", ref, "blockchain_node_btc")

    # Small Zenon implementation. Needs to be >= _MIN_LINE_COUNT lines
    # to participate in comparison, but still much smaller than the
    # reference implementation so the divergence ratio trips.
    zenon = tmp_path / "go-zenon"
    zenon.mkdir()
    (zenon / "common").mkdir()
    (zenon / "common" / "merkle.go").write_text(
        "func VerifyMerkleProof(h []byte) bool {\n"
        "    if h == nil {\n"
        "        return false\n"
        "    }\n"
        "    if len(h) == 0 {\n"
        "        return false\n"
        "    }\n"
        "    return true\n"
        "}\n"
    )
    _insert_workspace_repo(db_path, "go-zenon", zenon, "node")

    result = diff.diff_reference_implementations(db_path=db_path)
    assert result.get("reference_repos", 0) == 1
    # At least one divergence finding expected.
    assert result.get("findings", 0) >= 1
    rows = query_table(
        db_path=db_path,
        table="evidence",
        where="engine = ?",
        params=("reference_diff",),
        limit=10,
    )
    assert rows


def test_python_complexity_handles_control_flow():
    """Direct unit test for the python complexity helper."""
    code = (
        "def foo(x):\n"
        "    if x > 0:\n"
        "        for i in range(x):\n"
        "            if i % 2 == 0:\n"
        "                return i\n"
        "    return -1\n"
    )
    score = diff._python_complexity(code)
    assert score >= 3
