# SPDX-License-Identifier: MIT
"""Tests for the Development domain plugin and its engines."""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainRegistry
from core.feedback_bus import FeedbackBus
from domains.development.domain import DevelopmentDomain
from domains.development.engines.dependency_chain import (
    build_spec_dependency_graph,
    get_build_plan,
    get_pipeline_blockers,
    identify_blocked_specs,
    topological_sort,
)
from domains.development.engines.impl_coverage import (
    check_all_coverage,
    check_cli_dart,
    check_cli_go,
    check_coverage,
    check_docs,
    check_go_zenon,
    check_sdk_dart,
    get_coverage_report,
    get_gaps,
    persist_coverage,
)
from domains.development.engines.spec_tracker import (
    SPECS_DIR,
    _normalize_spec_name,
    _spec_to_impl_name,
    extract_abi_methods_from_go,
    extract_abi_methods_from_spec,
    persist_specs,
    scan_all_specs,
    scan_spec,
)
from domains.development.engines.upstream_monitor import (
    process_upstream_changes,
    read_intelligence_signals,
)
from domains.intelligence.domain import IntelligenceDomain

# -- Fixtures --


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


@pytest.fixture
def tmp_db():
    """Create a temporary database with both domain schemas."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    conn = sqlite3.connect(db_path)
    dev_domain = DevelopmentDomain()
    intel_domain = IntelligenceDomain()
    conn.executescript(dev_domain.get_db_schema_sql())
    conn.executescript(intel_domain.get_db_schema_sql())
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS feedback_bus (
            id TEXT PRIMARY KEY,
            sender TEXT NOT NULL,
            recipient TEXT NOT NULL,
            domain TEXT NOT NULL DEFAULT 'system',
            type TEXT NOT NULL,
            data TEXT NOT NULL DEFAULT '{}',
            timestamp TEXT NOT NULL,
            acknowledged BOOLEAN NOT NULL DEFAULT 0,
            acknowledged_at TEXT,
            acknowledged_by TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_bus_recipient
            ON feedback_bus(recipient, acknowledged);
    """)
    conn.commit()
    conn.close()
    yield db_path
    os.unlink(db_path)


@pytest.fixture
def real_specs():
    """Scan real specs from the workspace."""
    return scan_all_specs()


# -- Domain registration tests --


class TestDevelopmentDomainRegistration:
    """Test that DevelopmentDomain registers correctly."""

    def test_domain_name(self):
        domain = DevelopmentDomain()
        assert domain.name() == "development"

    def test_domain_registers_with_registry(self):
        registry = DomainRegistry.instance()
        domain = DevelopmentDomain()
        registry.register(domain)
        assert "development" in registry.get_domain_names()

    def test_domain_engines_count(self):
        domain = DevelopmentDomain()
        engines = domain.get_engines()
        assert len(engines) >= 4
        names = {e.name for e in engines}
        assert "spec_tracker" in names
        assert "impl_coverage" in names
        assert "upstream_monitor" in names
        assert "dependency_chain" in names

    def test_domain_db_schema(self):
        domain = DevelopmentDomain()
        sql = domain.get_db_schema_sql()
        assert "spec_coverage" in sql
        assert "go_zenon_status" in sql
        assert "sdk_dart_status" in sql

    def test_both_domains_register(self):
        registry = DomainRegistry.instance()
        registry.register(IntelligenceDomain())
        registry.register(DevelopmentDomain())
        assert len(registry.get_domain_names()) == 2
        assert "intelligence" in registry.get_domain_names()
        assert "development" in registry.get_domain_names()

    def test_combined_schema_sql(self):
        registry = DomainRegistry.instance()
        registry.register(IntelligenceDomain())
        registry.register(DevelopmentDomain())
        combined = registry.get_combined_schema_sql()
        assert "intelligence_signals" in combined
        assert "ecosystem_metrics" in combined
        assert "spec_coverage" in combined

    def test_decide_next_action_stale_coverage(self):
        domain = DevelopmentDomain()
        action = domain.decide_next_action(
            {
                "trigger_level": "routine",
                "stale_data": ["spec_coverage"],
            }
        )
        assert action["engine"] == "impl_coverage"


# -- Spec tracker tests --


class TestSpecTracker:
    """Test the spec tracker engine against real developer-commons."""

    def test_specs_dir_exists(self):
        assert SPECS_DIR.is_dir(), f"Specs dir not found: {SPECS_DIR}"

    def test_scan_all_specs_finds_specs(self, real_specs):
        assert len(real_specs) >= 8, f"Expected at least 8 specs, found {len(real_specs)}"
        names = {s["normalized_name"] for s in real_specs}
        # These specs definitely exist
        assert "atomic_swap" in names
        assert "bitcoin_spv" in names or "bitcoin-spv" in names.union(
            {s["name"] for s in real_specs}
        )
        assert "ptlc" in names
        assert "governance" in names

    def test_normalize_spec_name(self):
        assert _normalize_spec_name("AtomicSwap") == "atomic_swap"
        assert _normalize_spec_name("Bitcoin-SPV") == "bitcoin_spv"
        assert _normalize_spec_name("ZNS") == "zns"
        assert _normalize_spec_name("Zenon Portal") == "zenon_portal"

    def test_spec_to_impl_name(self):
        assert _spec_to_impl_name("atomic_swap") == "atomic_swap"
        assert _spec_to_impl_name("zenon_portal") == "portal"
        assert _spec_to_impl_name("multi_sig") == "multisig"

    def test_extract_abi_methods_from_spec(self):
        """AtomicSwap spec should have ABI methods defined."""
        spec_dir = SPECS_DIR / "AtomicSwap"
        if not spec_dir.is_dir():
            pytest.skip("AtomicSwap spec not found")

        methods = extract_abi_methods_from_spec(spec_dir)
        assert len(methods) >= 2, f"Expected at least 2 ABI methods, found {methods}"
        # AtomicSwap spec defines CreateSwap, ClaimSwap, ReclaimSwap
        method_lower = [m.lower() for m in methods]
        assert any("swap" in m for m in method_lower)

    def test_extract_abi_methods_from_go(self):
        """go-zenon should have ABI methods for atomic_swap."""
        methods = extract_abi_methods_from_go("atomic_swap")
        if not methods:
            pytest.skip("atomic_swap.go not found in any go-zenon repo")
        assert len(methods) >= 2
        method_lower = [m.lower() for m in methods]
        assert any("swap" in m for m in method_lower)

    def test_scan_spec_atomicswap(self):
        spec_dir = SPECS_DIR / "AtomicSwap"
        if not spec_dir.is_dir():
            pytest.skip("AtomicSwap spec dir not found")

        result = scan_spec(spec_dir)
        assert result is not None
        assert result["normalized_name"] == "atomic_swap"
        assert result["impl_name"] == "atomic_swap"
        assert len(result["md_files"]) >= 1

    def test_persist_specs(self, tmp_db, real_specs):
        count = persist_specs(real_specs, db_path=tmp_db)
        assert count >= 8

        # Verify in DB
        conn = sqlite3.connect(tmp_db)
        rows = conn.execute("SELECT COUNT(*) FROM spec_coverage").fetchone()
        conn.close()
        assert rows[0] >= 8


# -- Implementation coverage tests --


class TestImplCoverage:
    """Test implementation coverage checking against real repos."""

    def test_check_go_zenon_atomic_swap(self):
        """atomic_swap should exist in go-zenon."""
        status = check_go_zenon("atomic_swap")
        # At least definition should exist in one of the repos
        assert status in ("exists", "partial"), (
            f"atomic_swap.go not found in go-zenon (status={status})"
        )

    def test_check_go_zenon_ptlc(self):
        status = check_go_zenon("ptlc")
        assert status in ("exists", "partial"), f"ptlc.go not found in go-zenon (status={status})"

    def test_check_sdk_dart_atomic_swap(self):
        status = check_sdk_dart("atomic_swap")
        assert status in ("exists", "partial"), (
            f"atomic_swap.dart not found in SDK (status={status})"
        )

    def test_check_cli_dart_ptlc(self):
        status = check_cli_dart("ptlc")
        # ptlc may or may not have CLI support
        assert status in ("exists", "partial", "not_started")

    def test_check_cli_go_governance(self):
        status = check_cli_go("governance")
        assert status in ("exists", "partial", "not_started")

    def test_check_docs_governance(self):
        status = check_docs("governance")
        assert status == "exists", f"governance.md not found in wiki (status={status})"

    def test_check_docs_ptlc(self):
        status = check_docs("ptlc")
        assert status == "exists", f"ptlc.md not found in wiki (status={status})"

    def test_check_coverage_full_spec(self, real_specs):
        """Check coverage for a well-known spec like governance."""
        gov_spec = None
        for s in real_specs:
            if s["normalized_name"] == "governance":
                gov_spec = s
                break

        if gov_spec is None:
            pytest.skip("Governance spec not found")

        coverage = check_coverage(gov_spec)
        assert "go_zenon_status" in coverage
        assert "overall_coverage" in coverage
        assert coverage["overall_coverage"] > 0, "Governance should have at least some coverage"

    def test_check_all_coverage(self, real_specs):
        results = check_all_coverage(real_specs)
        assert len(results) >= 8

        # At least some specs should have non-zero coverage
        covered = [r for r in results if r.get("overall_coverage", 0) > 0]
        assert len(covered) >= 3, f"Expected at least 3 specs with coverage, found {len(covered)}"

    def test_persist_and_retrieve_coverage(self, tmp_db, real_specs):
        results = check_all_coverage(real_specs)
        count = persist_coverage(results, db_path=tmp_db)
        assert count >= 8

        report = get_coverage_report(tmp_db)
        assert len(report) >= 8

        gaps = get_gaps(tmp_db)
        assert isinstance(gaps, list)


# -- Upstream monitor tests --


class TestUpstreamMonitor:
    """Test upstream monitoring reads from feedback bus."""

    def test_read_empty_bus(self, tmp_db):
        signals = read_intelligence_signals(tmp_db)
        assert signals == []

    def test_process_with_signal(self, tmp_db, real_specs):
        """Post a signal to the bus and verify upstream_monitor processes it."""
        # First persist some specs so we have tracked specs
        persist_specs(real_specs, db_path=tmp_db)
        results = check_all_coverage(real_specs)
        persist_coverage(results, db_path=tmp_db)

        # Post a signal to the feedback bus
        bus = FeedbackBus(tmp_db)
        bus.post(
            sender="intelligence.signal_router",
            recipient="domain.development",
            message_type="signal",
            data={
                "signal_id": 99,
                "classifications": ["spec_change", "breaking_change"],
                "source_repo": "go-zenon",
                "commit_hash": "abc123",
                "message": "breaking: update ptlc embedded contract ABI",
                "files_changed": [
                    "vm/embedded/definition/ptlc.go",
                    "vm/embedded/implementation/ptlc.go",
                ],
            },
            domain="intelligence",
        )

        # Process
        impacts = process_upstream_changes(tmp_db)
        assert isinstance(impacts, list)
        # Should detect impact on ptlc spec
        if impacts:
            ptlc_impacts = [i for i in impacts if i["spec_name"] == "ptlc"]
            assert len(ptlc_impacts) >= 1
            assert ptlc_impacts[0]["severity"] in ("critical", "high")


# -- Dependency chain tests --


class TestDependencyChain:
    """Test dependency chain analysis."""

    def test_build_dependency_graph(self, real_specs):
        graph = build_spec_dependency_graph(real_specs)
        assert isinstance(graph, dict)
        assert len(graph) >= 5

    def test_topological_sort(self):
        graph = {
            "a": ["b", "c"],
            "b": ["c"],
            "c": [],
            "d": ["a"],
        }
        order = topological_sort(graph)
        assert order.index("c") < order.index("b")
        assert order.index("b") < order.index("a")
        assert order.index("a") < order.index("d")

    def test_topological_sort_handles_cycles(self):
        graph = {
            "a": ["b"],
            "b": ["a"],
            "c": [],
        }
        order = topological_sort(graph)
        assert len(order) == 3
        assert "c" in order

    def test_pipeline_blockers_all_not_started(self):
        spec_row = {
            "go_zenon_status": "not_started",
            "sdk_dart_status": "not_started",
            "cli_dart_status": "not_started",
            "cli_go_status": "not_started",
            "syrius_status": "not_started",
            "docs_status": "not_started",
            "infra_status": "not_started",
        }
        blockers = get_pipeline_blockers(spec_row)
        # SDK blocked by go_zenon, CLI blocked by SDK, etc.
        assert len(blockers) >= 5

    def test_pipeline_blockers_go_only(self):
        spec_row = {
            "go_zenon_status": "exists",
            "sdk_dart_status": "not_started",
            "cli_dart_status": "not_started",
            "cli_go_status": "not_started",
            "syrius_status": "not_started",
            "docs_status": "not_started",
            "infra_status": "not_started",
        }
        blockers = get_pipeline_blockers(spec_row)
        # SDK is not blocked (go exists), but CLI is blocked by SDK
        sdk_blockers = [b for b in blockers if b["stage"] == "sdk_dart"]
        assert len(sdk_blockers) == 0  # Not blocked -- go exists

    def test_identify_blocked_specs(self, tmp_db, real_specs):
        persist_specs(real_specs, db_path=tmp_db)
        results = check_all_coverage(real_specs)
        persist_coverage(results, db_path=tmp_db)

        blocked = identify_blocked_specs(real_specs, db_path=tmp_db)
        assert isinstance(blocked, list)
        # There should be at least some specs with blockers
        # (specs that don't have full pipeline coverage)

    def test_build_plan(self, tmp_db, real_specs):
        persist_specs(real_specs, db_path=tmp_db)
        results = check_all_coverage(real_specs)
        persist_coverage(results, db_path=tmp_db)

        plan = get_build_plan(real_specs, db_path=tmp_db)
        assert isinstance(plan, list)
        assert len(plan) >= 5

        for item in plan:
            assert "spec_name" in item
            assert "next_action" in item
            assert "overall_coverage" in item


# -- Signal routing integration tests --


class TestSignalRoutingIntegration:
    """Test the full signal flow from intelligence to development."""

    def test_intelligence_to_development_routing(self, tmp_db):
        """Verify a signal posted by intelligence arrives at development."""
        bus = FeedbackBus(tmp_db)

        # Intelligence posts a signal
        msg_id = bus.post(
            sender="intelligence.signal_router",
            recipient="domain.development",
            message_type="signal",
            data={
                "signal_id": 42,
                "classifications": ["spec_change"],
                "source_repo": "go-zenon",
                "commit_hash": "abc123",
                "message": "update governance spec",
                "files_changed": ["vm/embedded/definition/governance.go"],
            },
            domain="intelligence",
        )

        # Development reads it
        msgs = bus.read("domain.development")
        assert len(msgs) == 1
        assert msgs[0]["data"]["source_repo"] == "go-zenon"
        assert msgs[0]["sender"] == "intelligence.signal_router"

        # Acknowledge
        bus.acknowledge(msg_id, "development.upstream_monitor")
        remaining = bus.read("domain.development")
        assert len(remaining) == 0

    def test_both_domains_system_status(self):
        """Register both domains and verify system status."""
        registry = DomainRegistry.instance()
        registry.register(IntelligenceDomain())
        registry.register(DevelopmentDomain())

        status = registry.get_system_status()
        assert status["total_domains"] == 2
        assert status["total_engines"] >= 8  # at least 4 + 4
        assert "intelligence" in status["domains"]
        assert "development" in status["domains"]
