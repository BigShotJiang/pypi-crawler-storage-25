# SPDX-License-Identifier: MIT
"""
Tests for core.workspace_discovery -- Workspace scanning and repo detection.

Tests discover_workspace finds repos, detects languages, exclusion
paths work, _is_excluded logic, and DB table detection.
"""

import sqlite3
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.workspace_discovery import (
    _analyze_repo,
    _get_db_tables,
    _get_excluded_paths,
    _get_excluded_repos,
    _is_excluded,
    discover_workspace,
)


@pytest.fixture
def fake_workspace(tmp_path):
    """Create a fake workspace with several repo types."""
    # Go repo
    go_repo = tmp_path / "go-zenon"
    go_repo.mkdir()
    (go_repo / ".git").mkdir()
    (go_repo / "go.mod").write_text("module github.com/zenon/go-zenon")
    (go_repo / "main.go").write_text("package main")
    (go_repo / "cmd").mkdir()
    (go_repo / "cmd" / "znnd").mkdir()
    (go_repo / "cmd" / "znnd" / "main.go").write_text("package main")
    (go_repo / "vm").mkdir()
    (go_repo / "vm" / "embedded").mkdir()
    (go_repo / "vm" / "embedded" / "htlc.go").write_text("package embedded")

    # Dart SDK repo
    dart_repo = tmp_path / "znn_sdk_dart"
    dart_repo.mkdir()
    (dart_repo / ".git").mkdir()
    (dart_repo / "pubspec.yaml").write_text("name: znn_sdk_dart")
    (dart_repo / "lib").mkdir()
    (dart_repo / "lib" / "src").mkdir()
    (dart_repo / "lib" / "src" / "api").mkdir()
    (dart_repo / "lib" / "src" / "api" / "embedded.dart").write_text("class Embedded {}")
    (dart_repo / "lib" / "src" / "model").mkdir()
    (dart_repo / "lib" / "src" / "model" / "token.dart").write_text("class Token {}")
    # Add more dart files for language detection threshold
    for i in range(5):
        (dart_repo / "lib" / "src" / f"file_{i}.dart").write_text(f"// file {i}")

    # Python repo
    py_repo = tmp_path / "nebula"
    py_repo.mkdir()
    (py_repo / ".git").mkdir()
    for i in range(5):
        (py_repo / f"module_{i}.py").write_text(f"# module {i}")

    # CI repo
    ci_repo = tmp_path / "ci_repo"
    ci_repo.mkdir()
    (ci_repo / ".git").mkdir()
    (ci_repo / ".github").mkdir()
    (ci_repo / ".github" / "workflows").mkdir()
    (ci_repo / ".github" / "workflows" / "ci.yml").write_text("name: CI")

    # Non-git directory (not a repo)
    plain = tmp_path / "not_a_repo"
    plain.mkdir()
    (plain / "readme.txt").write_text("hello")

    return str(tmp_path)


class TestDiscoverWorkspace:
    """Test full workspace discovery."""

    def test_discovers_repos(self, fake_workspace):
        result = discover_workspace(fake_workspace)
        names = [r["name"] for r in result["repos"]]

        assert "go-zenon" in names
        assert "znn_sdk_dart" in names
        assert "nebula" in names
        assert "not_a_repo" not in names  # No .git

    def test_detects_languages(self, fake_workspace):
        result = discover_workspace(fake_workspace)
        langs = result["languages"]

        assert "go" in langs
        assert "dart" in langs
        assert "python" in langs

    def test_detects_ci(self, fake_workspace):
        result = discover_workspace(fake_workspace)
        ci_names = [c["repo"] for c in result["ci_pipelines"]]
        assert "ci_repo" in ci_names

    def test_summary_stats(self, fake_workspace):
        result = discover_workspace(fake_workspace)
        summary = result["summary"]

        assert summary["total_repos"] >= 4
        assert len(summary["total_languages"]) >= 3

    def test_nonexistent_workspace(self):
        result = discover_workspace("/nonexistent/workspace/path")
        assert "error" in result

    def test_empty_workspace(self, tmp_path):
        result = discover_workspace(str(tmp_path))
        assert result["repos"] == []


class TestAnalyzeRepo:
    """Test individual repo analysis."""

    def test_detects_go_language(self, fake_workspace):
        repo_path = Path(fake_workspace) / "go-zenon"
        info = _analyze_repo(repo_path, Path(fake_workspace))

        assert "go" in info["languages"]

    def test_detects_dart_language(self, fake_workspace):
        repo_path = Path(fake_workspace) / "znn_sdk_dart"
        info = _analyze_repo(repo_path, Path(fake_workspace))

        assert "dart" in info["languages"]

    def test_detects_ci(self, fake_workspace):
        repo_path = Path(fake_workspace) / "ci_repo"
        info = _analyze_repo(repo_path, Path(fake_workspace))

        assert info["has_ci"] is True

    def test_no_ci_detection(self, fake_workspace):
        repo_path = Path(fake_workspace) / "nebula"
        info = _analyze_repo(repo_path, Path(fake_workspace))

        assert info["has_ci"] is False


class TestExclusion:
    """Test exclusion logic."""

    def test_exclude_by_name(self, monkeypatch, tmp_path):
        monkeypatch.setenv("NEBULA_EXCLUDE_REPOS", "excluded_repo,another_one")
        repos = _get_excluded_repos()
        assert "excluded_repo" in repos
        assert "another_one" in repos

    def test_exclude_by_path(self, monkeypatch, tmp_path):
        monkeypatch.setenv("NEBULA_EXCLUDE_PATHS", str(tmp_path / "private"))
        paths = _get_excluded_paths(tmp_path)
        assert len(paths) == 1

    def test_is_excluded_by_name(self, tmp_path):
        repo = tmp_path / "secret_repo"
        repo.mkdir()
        result = _is_excluded(repo, tmp_path, [], {"secret_repo"})
        assert result is True

    def test_is_excluded_by_path(self, tmp_path):
        excluded = tmp_path / "private"
        excluded.mkdir()
        repo = excluded / "my_repo"
        repo.mkdir()

        result = _is_excluded(repo, tmp_path, [excluded.resolve()], set())
        assert result is True

    def test_not_excluded(self, tmp_path):
        repo = tmp_path / "public_repo"
        repo.mkdir()
        result = _is_excluded(repo, tmp_path, [], set())
        assert result is False

    def test_empty_env_vars(self, monkeypatch):
        monkeypatch.setenv("NEBULA_EXCLUDE_REPOS", "")
        monkeypatch.setenv("NEBULA_EXCLUDE_PATHS", "")
        assert _get_excluded_repos() == set()
        assert _get_excluded_paths(Path("/tmp")) == []

    def test_exclusion_applied_in_discovery(self, fake_workspace, monkeypatch):
        monkeypatch.setenv("NEBULA_EXCLUDE_REPOS", "go-zenon")
        result = discover_workspace(fake_workspace)
        names = [r["name"] for r in result["repos"]]
        assert "go-zenon" not in names


class TestGetDBTables:
    """Test SQLite table detection."""

    def test_valid_db(self, tmp_path):
        db = str(tmp_path / "test.db")
        conn = sqlite3.connect(db)
        conn.execute("CREATE TABLE users (id INTEGER)")
        conn.execute("CREATE TABLE orders (id INTEGER)")
        conn.close()

        tables = _get_db_tables(db)
        assert "users" in tables
        assert "orders" in tables

    def test_invalid_db(self, tmp_path):
        path = str(tmp_path / "not_a_db.db")
        (tmp_path / "not_a_db.db").write_text("not a database")
        tables = _get_db_tables(path)
        assert tables == []
