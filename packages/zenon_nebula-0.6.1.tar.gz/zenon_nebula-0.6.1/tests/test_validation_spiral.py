# SPDX-License-Identifier: MIT
"""Tests for core/validation_spiral.py -- 5-tier confidence promotion system."""

import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.persist_to_db import ensure_schema, persist_finding
from core.validation_spiral import (
    CONTRADICTION_PENALTY,
    MAX_CONTRADICTION_PENALTY,
    TIER_CONFIDENCE,
    TIER_LABELS,
    Tier,
    _compute_effective_confidence,
    add_contradiction,
    add_corroboration,
    check_tier_requirements,
    ensure_spiral_schema,
    get_validation_state,
    increment_stable_cycles,
    mark_api_verified,
    mark_contradiction_survived,
    promote_finding,
    register_finding,
    run_validation_round,
)


@pytest.fixture
def db_path():
    """Create a temporary database for testing."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    ensure_schema(path)
    ensure_spiral_schema(path)
    yield path
    os.unlink(path)


@pytest.fixture
def finding_id(db_path):
    """Persist a test finding and return its ID."""
    return persist_finding(
        db_path=db_path,
        domain="test",
        engine="test_engine",
        evidence_type="test_type",
        finding="Test finding for validation spiral",
        confidence=0.5,
    )


class TestTierConstants:
    """Verify tier constants are correct."""

    def test_tier_values(self):
        assert Tier.RAW == 1
        assert Tier.CORROBORATED == 2
        assert Tier.VERIFIED == 3
        assert Tier.VALIDATED == 4
        assert Tier.ESTABLISHED == 5

    def test_tier_confidence_values(self):
        assert TIER_CONFIDENCE[Tier.RAW] == 0.20
        assert TIER_CONFIDENCE[Tier.CORROBORATED] == 0.50
        assert TIER_CONFIDENCE[Tier.VERIFIED] == 0.70
        assert TIER_CONFIDENCE[Tier.VALIDATED] == 0.85
        assert TIER_CONFIDENCE[Tier.ESTABLISHED] == 0.95

    def test_tier_labels(self):
        assert TIER_LABELS[Tier.RAW] == "raw"
        assert TIER_LABELS[Tier.ESTABLISHED] == "established"

    def test_contradiction_constants(self):
        assert CONTRADICTION_PENALTY == 0.05
        assert MAX_CONTRADICTION_PENALTY == 0.30


class TestComputeEffectiveConfidence:
    """Test the confidence computation with contradiction penalties."""

    def test_no_contradictions(self):
        assert _compute_effective_confidence(Tier.RAW, 0) == 0.20
        assert _compute_effective_confidence(Tier.ESTABLISHED, 0) == 0.95

    def test_single_contradiction(self):
        result = _compute_effective_confidence(Tier.VERIFIED, 1)
        assert result == 0.65  # 0.70 - 0.05

    def test_max_contradiction_cap(self):
        # 10 contradictions should cap at -30%
        result = _compute_effective_confidence(Tier.ESTABLISHED, 10)
        assert result == 0.65  # 0.95 - 0.30

    def test_six_contradictions_equals_cap(self):
        result = _compute_effective_confidence(Tier.ESTABLISHED, 6)
        assert result == 0.65  # 0.95 - 0.30

    def test_floor_at_zero(self):
        # T1 (0.20) with 6 contradictions (0.30 penalty) should floor at 0.0
        result = _compute_effective_confidence(Tier.RAW, 6)
        assert result == 0.0


class TestRegisterFinding:
    """Test finding registration."""

    def test_register_new_finding(self, db_path, finding_id):
        result = register_finding(finding_id, engine="test_engine", db_path=db_path)
        assert result["finding_id"] == finding_id
        assert result["tier"] == Tier.RAW
        assert result["effective_confidence"] == 0.20

    def test_register_idempotent(self, db_path, finding_id):
        register_finding(finding_id, engine="test_engine", db_path=db_path)
        result = register_finding(finding_id, engine="other_engine", db_path=db_path)
        # Should return existing state without modification
        assert result["finding_id"] == finding_id

    def test_register_without_engine(self, db_path, finding_id):
        result = register_finding(finding_id, db_path=db_path)
        assert result["tier"] == Tier.RAW


class TestCheckTierRequirements:
    """Test tier requirement checking."""

    def test_unregistered_finding(self, db_path):
        result = check_tier_requirements(999, Tier.CORROBORATED, db_path)
        assert result["met"] is False

    def test_same_tier(self, db_path, finding_id):
        register_finding(finding_id, engine="test_engine", db_path=db_path)
        result = check_tier_requirements(finding_id, Tier.RAW, db_path)
        assert result["met"] is True

    def test_tier2_requires_corroboration(self, db_path, finding_id):
        register_finding(finding_id, engine="engine_a", db_path=db_path)
        result = check_tier_requirements(finding_id, Tier.CORROBORATED, db_path)
        assert result["met"] is False
        assert any("2+ engines" in m for m in result["missing"])

    def test_tier3_requires_api(self, db_path, finding_id):
        register_finding(finding_id, engine="engine_a", db_path=db_path)
        add_corroboration(finding_id, "engine_b", db_path)
        result = check_tier_requirements(finding_id, Tier.VERIFIED, db_path)
        assert result["met"] is False
        assert any("API" in m for m in result["missing"])

    def test_tier5_requires_stable_cycles(self, db_path, finding_id):
        register_finding(finding_id, engine="engine_a", db_path=db_path)
        result = check_tier_requirements(finding_id, Tier.ESTABLISHED, db_path)
        assert any("3+ validation cycles" in m for m in result["missing"])


class TestPromoteFinding:
    """Test tier promotion logic."""

    def test_promote_unregistered(self, db_path):
        result = promote_finding(999, db_path)
        assert result["promoted"] is False

    def test_promote_missing_requirements(self, db_path, finding_id):
        register_finding(finding_id, engine="engine_a", db_path=db_path)
        result = promote_finding(finding_id, db_path)
        assert result["promoted"] is False
        assert result["old_tier"] == Tier.RAW

    def test_promote_to_tier2(self, db_path, finding_id):
        register_finding(finding_id, engine="engine_a", db_path=db_path)
        add_corroboration(finding_id, "engine_b", db_path)
        result = promote_finding(finding_id, db_path)
        assert result["promoted"] is True
        assert result["new_tier"] == Tier.CORROBORATED
        assert result["confidence"] == 0.50

    def test_full_promotion_chain(self, db_path, finding_id):
        register_finding(finding_id, engine="engine_a", db_path=db_path)

        # T1 -> T2: corroboration
        add_corroboration(finding_id, "engine_b", db_path)
        result = promote_finding(finding_id, db_path)
        assert result["promoted"] is True
        assert result["new_tier"] == Tier.CORROBORATED

        # T2 -> T3: API verification
        mark_api_verified(finding_id, db_path)
        result = promote_finding(finding_id, db_path)
        assert result["promoted"] is True
        assert result["new_tier"] == Tier.VERIFIED

        # T3 -> T4: contradiction survived
        mark_contradiction_survived(finding_id, db_path)
        result = promote_finding(finding_id, db_path)
        assert result["promoted"] is True
        assert result["new_tier"] == Tier.VALIDATED

        # T4 -> T5: stable cycles
        for _ in range(3):
            increment_stable_cycles(finding_id, db_path)
        result = promote_finding(finding_id, db_path)
        assert result["promoted"] is True
        assert result["new_tier"] == Tier.ESTABLISHED
        assert result["confidence"] == 0.95

    def test_cannot_promote_beyond_established(self, db_path, finding_id):
        register_finding(finding_id, engine="engine_a", db_path=db_path)
        add_corroboration(finding_id, "engine_b", db_path)
        promote_finding(finding_id, db_path)
        mark_api_verified(finding_id, db_path)
        promote_finding(finding_id, db_path)
        mark_contradiction_survived(finding_id, db_path)
        promote_finding(finding_id, db_path)
        for _ in range(3):
            increment_stable_cycles(finding_id, db_path)
        promote_finding(finding_id, db_path)

        result = promote_finding(finding_id, db_path)
        assert result["promoted"] is False
        assert "maximum tier" in result["reason"]


class TestContradictions:
    """Test contradiction penalty system."""

    def test_add_contradiction(self, db_path, finding_id):
        register_finding(finding_id, engine="test", db_path=db_path)
        new_conf = add_contradiction(finding_id, db_path)
        assert new_conf == 0.15  # 0.20 - 0.05

    def test_multiple_contradictions(self, db_path, finding_id):
        register_finding(finding_id, engine="test", db_path=db_path)
        add_contradiction(finding_id, db_path)
        add_contradiction(finding_id, db_path)
        new_conf = add_contradiction(finding_id, db_path)
        assert new_conf == 0.05  # 0.20 - 3*0.05

    def test_contradiction_cap(self, db_path, finding_id):
        register_finding(finding_id, engine="test", db_path=db_path)
        # Add many contradictions
        for _ in range(10):
            new_conf = add_contradiction(finding_id, db_path)
        # Should be 0.20 - 0.30 = 0.0 (floored)
        assert new_conf == 0.0

    def test_contradiction_does_not_affect_tier(self, db_path, finding_id):
        register_finding(finding_id, engine="test", db_path=db_path)
        add_contradiction(finding_id, db_path)
        state = get_validation_state(finding_id, db_path)
        assert state["tier"] == Tier.RAW  # Tier stays the same


class TestValidationState:
    """Test state retrieval."""

    def test_get_unregistered(self, db_path):
        assert get_validation_state(999, db_path) is None

    def test_get_registered(self, db_path, finding_id):
        register_finding(finding_id, engine="test", db_path=db_path)
        state = get_validation_state(finding_id, db_path)
        assert state is not None
        assert state["tier"] == Tier.RAW
        assert state["tier_label"] == "raw"


class TestValidationRound:
    """Test batch validation round processing."""

    def test_round_with_no_findings(self, db_path):
        stats = run_validation_round(db_path)
        assert stats["processed"] == 0

    def test_round_increments_stable_cycles(self, db_path, finding_id):
        register_finding(finding_id, engine="test", db_path=db_path)
        stats = run_validation_round(db_path)
        assert stats["processed"] == 1
        assert stats["stable_incremented"] == 1

        state = get_validation_state(finding_id, db_path)
        assert state["stable_cycles"] == 1

    def test_round_promotes_eligible(self, db_path, finding_id):
        register_finding(finding_id, engine="engine_a", db_path=db_path)
        add_corroboration(finding_id, "engine_b", db_path)
        stats = run_validation_round(db_path)
        assert stats["promoted"] == 1

    def test_round_with_domain_filter(self, db_path, finding_id):
        register_finding(finding_id, engine="test", db_path=db_path)
        stats = run_validation_round(db_path, domain="nonexistent")
        assert stats["processed"] == 0

        stats = run_validation_round(db_path, domain="test")
        assert stats["processed"] == 1
