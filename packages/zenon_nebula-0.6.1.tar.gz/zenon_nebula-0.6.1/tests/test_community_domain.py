# SPDX-License-Identifier: MIT
"""
Tests for domains.community.domain -- Community contributor tracking.
"""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.community.domain import CommunityDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestCommunityDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(CommunityDomain, DomainPlugin)

    def test_name(self):
        assert CommunityDomain().name() == "community"

    def test_get_engines_non_empty(self):
        engines = CommunityDomain().get_engines()
        assert len(engines) >= 1
        for e in engines:
            assert e.name
            assert e.module_path

    def test_get_hypothesis_types_non_empty(self):
        types = CommunityDomain().get_hypothesis_types()
        assert len(types) >= 1
        for t in types:
            assert t.type_id
            assert t.label

    def test_get_aspiration_types(self):
        types = CommunityDomain().get_aspiration_types()
        assert isinstance(types, list)

    def test_get_collision_signals(self):
        signals = CommunityDomain().get_collision_signals()
        assert isinstance(signals, list)

    def test_get_war_room_contributions(self):
        contribs = CommunityDomain().get_war_room_contributions()
        assert isinstance(contribs, list)

    def test_get_self_improvement_metrics(self):
        metrics = CommunityDomain().get_self_improvement_metrics()
        assert isinstance(metrics, dict)

    def test_get_db_schema_sql(self):
        sql = CommunityDomain().get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action_stale(self):
        action = CommunityDomain().decide_next_action({"stale_data": ["contributors"]})
        assert action is not None
        assert action["engine"] == "contributor_tracker"

    def test_decide_next_action_default_when_nothing_stale(self):
        # The community domain now returns a routine default action
        # instead of None so the scheduler keeps it alive between
        # stale-tag cycles. Verify the default is well-formed.
        action = CommunityDomain().decide_next_action({})
        assert action is not None
        assert isinstance(action, dict)
        assert action.get("engine") == "contributor_tracker"

    def test_registration(self):
        registry = DomainRegistry.instance()
        domain = CommunityDomain()
        registry.register(domain)
        assert registry.get_domain("community") is domain
