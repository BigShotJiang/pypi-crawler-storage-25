# SPDX-License-Identifier: MIT
"""Tests for domains.interoperability.domain -- Bridge and EVM readiness."""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.interoperability.domain import InteroperabilityDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestInteroperabilityDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(InteroperabilityDomain, DomainPlugin)

    def test_name(self):
        assert InteroperabilityDomain().name() == "interoperability"

    def test_get_engines_non_empty(self):
        engines = InteroperabilityDomain().get_engines()
        assert len(engines) >= 1
        names = [e.name for e in engines]
        assert "bridge_compat" in names

    def test_get_hypothesis_types_non_empty(self):
        types = InteroperabilityDomain().get_hypothesis_types()
        assert len(types) >= 1

    def test_get_aspiration_types(self):
        assert isinstance(InteroperabilityDomain().get_aspiration_types(), list)

    def test_get_collision_signals(self):
        signals = InteroperabilityDomain().get_collision_signals()
        assert isinstance(signals, list)
        ids = [s.signal_id for s in signals]
        assert "bridge_incompatibility" in ids

    def test_get_war_room_contributions(self):
        assert isinstance(InteroperabilityDomain().get_war_room_contributions(), list)

    def test_get_self_improvement_metrics(self):
        metrics = InteroperabilityDomain().get_self_improvement_metrics()
        assert isinstance(metrics, dict)

    def test_get_db_schema_sql(self):
        sql = InteroperabilityDomain().get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action(self):
        action = InteroperabilityDomain().decide_next_action({})
        assert action is None or isinstance(action, dict)

    def test_registration(self):
        registry = DomainRegistry.instance()
        registry.register(InteroperabilityDomain())
        assert registry.get_domain("interoperability") is not None
