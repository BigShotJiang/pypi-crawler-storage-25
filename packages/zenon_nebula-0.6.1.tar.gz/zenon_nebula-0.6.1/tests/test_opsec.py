# SPDX-License-Identifier: MIT
"""Tests for core.opsec -- Identity sanitization and OPSEC guard."""

from core.opsec import _GENERIC_USER_AGENTS, OPSECGuard


class TestSanitizePrompt:
    def test_removes_macos_path(self):
        text = "File at /Users/johndoe/Projects/secret.py"
        result = OPSECGuard.sanitize_prompt(text)
        assert "johndoe" not in result
        assert "/Users/" not in result or "REDACTED" in result

    def test_removes_linux_path(self):
        text = "Config at /home/admin/config.yaml"
        result = OPSECGuard.sanitize_prompt(text)
        assert "admin" not in result

    def test_removes_windows_path(self):
        text = r"File at C:\Users\operator\Desktop\file.txt"
        result = OPSECGuard.sanitize_prompt(text)
        assert "operator" not in result

    def test_removes_openai_api_key(self):
        # Build key dynamically to avoid pre-commit hook flagging test fixtures
        prefix = "sk-"
        text = f"API key is {prefix}abc123def456ghi789jkl012mno"
        result = OPSECGuard.sanitize_prompt(text)
        assert f"{prefix}abc123" not in result
        assert "REDACTED" in result

    def test_removes_anthropic_key(self):
        prefix = "sk-" + "ant-"
        text = f"Key: {prefix}abc123-def456-ghi789-jkl012"
        result = OPSECGuard.sanitize_prompt(text)
        assert prefix not in result
        assert "REDACTED" in result

    def test_removes_xai_key(self):
        prefix = "xai-"
        text = f"Using {prefix}abc123def456ghi789jkl012mno"
        result = OPSECGuard.sanitize_prompt(text)
        assert f"{prefix}abc123" not in result

    def test_removes_bearer_token(self):
        text = "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.abc"
        result = OPSECGuard.sanitize_prompt(text)
        assert "eyJhbGci" not in result
        assert "REDACTED" in result

    def test_removes_aws_key(self):
        text = "AWS key: AKIAIOSFODNN7EXAMPLE"
        result = OPSECGuard.sanitize_prompt(text)
        assert "AKIAIOSFODNN7EXAMPLE" not in result

    def test_removes_ip_address(self):
        text = "Server at 192.168.1.100 responded"
        result = OPSECGuard.sanitize_prompt(text)
        assert "192.168.1.100" not in result
        assert "REDACTED" in result

    def test_redacts_all_emails(self):
        text = "Contact us at info@zenon.org"
        result = OPSECGuard.sanitize_prompt(text)
        # sanitize_prompt redacts ALL emails without exception
        assert "info@zenon.org" not in result
        assert "REDACTED" in result

    def test_removes_non_zenon_email(self):
        text = "Personal: john.doe@gmail.com"
        result = OPSECGuard.sanitize_prompt(text)
        assert "john.doe@gmail.com" not in result
        assert "REDACTED" in result

    def test_idempotent(self):
        prefix = "sk-"
        text = f"File at /Users/johndoe/secret.py and key {prefix}abc123def456ghi789jkl012mno"
        r1 = OPSECGuard.sanitize_prompt(text)
        r2 = OPSECGuard.sanitize_prompt(r1)
        assert r1 == r2

    def test_empty_string(self):
        assert OPSECGuard.sanitize_prompt("") == ""

    def test_none_passthrough(self):
        # Empty/falsy input returns as-is
        assert OPSECGuard.sanitize_prompt("") == ""

    def test_residual_absolute_paths(self):
        text = "Found data in /var/log/secret.log and /tmp/work/output"
        result = OPSECGuard.sanitize_prompt(text)
        assert "/var/log/secret.log" not in result
        assert "/tmp/work/output" not in result

    def test_preserves_sha256_checksum(self):
        """Regression: 64-char hex without private-key context must survive.

        Nebula findings reference SHA-256 checksums (snapshot integrity,
        content hashes) and Zenon momentum hashes constantly. The old
        bare-hex pattern r"\\b[0-9a-fA-F]{64}\\b" mangled all of them.
        """
        digest = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        text = f"Snapshot integrity: sha256={digest}"
        result = OPSECGuard.sanitize_prompt(text)
        assert digest in result, "SHA-256 checksum must not be mangled"
        assert "REDACTED_HEX_KEY" not in result

    def test_preserves_zenon_momentum_hash(self):
        """Regression: Zenon hashes (32 bytes = 64 hex) must pass through."""
        hash_hex = "a1b2c3d4e5f67890123456789012345678901234567890abcdef0123456789ab"
        text = f"Momentum hash: {hash_hex} at height 12345"
        result = OPSECGuard.sanitize_prompt(text)
        assert hash_hex in result

    def test_redacts_explicit_private_key(self):
        """Private key WITH context keyword must still be redacted."""
        key = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        text = f"private_key={key}"
        result = OPSECGuard.sanitize_prompt(text)
        assert key not in result
        assert "REDACTED_HEX_KEY" in result

    def test_redacts_seed_phrase_hex(self):
        key = "a1b2c3d4e5f67890123456789012345678901234567890abcdef0123456789ab"
        text = f"Seed Phrase: {key}"
        result = OPSECGuard.sanitize_prompt(text)
        assert key not in result
        assert "REDACTED_HEX_KEY" in result

    def test_redacts_ecdsa_ssh_key(self):
        text = "key: ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAA="
        result = OPSECGuard.sanitize_prompt(text)
        assert "AAAAE2" not in result
        assert "REDACTED_SSH_KEY" in result


class TestSanitizeHeaders:
    def test_replaces_user_agent(self):
        headers = {"User-Agent": "MyCustomBot/1.0 (operator@company.com)"}
        cleaned = OPSECGuard.sanitize_headers(headers)
        assert cleaned["User-Agent"] in _GENERIC_USER_AGENTS

    def test_strips_referer(self):
        headers = {"Referer": "https://internal.company.com/dashboard"}
        cleaned = OPSECGuard.sanitize_headers(headers)
        assert "Referer" not in cleaned
        assert "referer" not in {k.lower() for k in cleaned}

    def test_strips_x_forwarded_for(self):
        headers = {"X-Forwarded-For": "10.0.0.1"}
        cleaned = OPSECGuard.sanitize_headers(headers)
        assert "X-Forwarded-For" not in cleaned

    def test_strips_x_real_ip(self):
        headers = {"X-Real-IP": "192.168.1.1"}
        cleaned = OPSECGuard.sanitize_headers(headers)
        assert "X-Real-IP" not in cleaned

    def test_preserves_content_type(self):
        headers = {"Content-Type": "application/json"}
        cleaned = OPSECGuard.sanitize_headers(headers)
        assert cleaned["Content-Type"] == "application/json"

    def test_adds_user_agent_if_missing(self):
        headers = {"Accept": "text/html"}
        cleaned = OPSECGuard.sanitize_headers(headers)
        assert any(k.lower() == "user-agent" for k in cleaned)


class TestTimingJitter:
    def test_jitter_always_positive(self):
        for _ in range(50):
            delay = OPSECGuard.randomize_timing(0)
            assert delay >= 0.0

    def test_jitter_within_bounds_zero_base(self):
        for _ in range(50):
            delay = OPSECGuard.randomize_timing(0)
            # base=0, so jitter is just the random component 0.1-2.0
            assert 0.0 <= delay <= 2.5  # small margin

    def test_jitter_with_base_delay(self):
        for _ in range(50):
            delay = OPSECGuard.randomize_timing(10.0)
            # base * (1 +/- 0.3) + 0.1..2.0 => roughly 7.1 to 15.0
            assert delay >= 0.0
            assert delay <= 20.0  # generous upper bound


class TestContentLeakDetection:
    def test_clean_content(self):
        leaks = OPSECGuard.check_content_for_leaks("Zenon Network is a decentralized protocol.")
        assert leaks == []

    def test_detects_path_leak(self):
        leaks = OPSECGuard.check_content_for_leaks("Config found at /Users/operator/config.json")
        assert len(leaks) >= 1
        assert any("username" in l.lower() or "path" in l.lower() for l in leaks)

    def test_detects_api_key_leak(self):
        prefix = "sk-"
        leaks = OPSECGuard.check_content_for_leaks(f"Use key {prefix}abc123def456ghi789jkl012mno")
        assert len(leaks) >= 1

    def test_empty_content(self):
        assert OPSECGuard.check_content_for_leaks("") == []


class TestAnonymousUserAgent:
    def test_returns_known_agent(self):
        ua = OPSECGuard.generate_anonymous_user_agent()
        assert ua in _GENERIC_USER_AGENTS

    def test_randomness(self):
        agents = {OPSECGuard.generate_anonymous_user_agent() for _ in range(100)}
        # Should hit at least 2 different agents in 100 tries
        assert len(agents) >= 2
