# SPDX-License-Identifier: MIT
"""v0.3.4 source_quality_scorer engine tests.

Phase B engine wrapper that runs core.source_quality.score_repo on a
rotating subset of workspace repos and persists history rows. These
tests pin the engine entry point, history-table writes, and graceful
degradation paths.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence.schema import ensure_schema
from domains.investigation.engines import source_quality_scorer as sqs


@pytest.fixture
def fake_workspace(tmp_path, monkeypatch):
    """Build a workspace with two fake repos: one high-sig, one low-sig.

    Patches `domains.investigation.engines.source_quality_scorer.workspace_root`
    directly so the test is isolated from the real workspace that
    `core.workspace.workspace_root()` would otherwise find via its
    `~/Repos/Zenon` fallback.
    """
    ws = tmp_path / "workspace"
    ws.mkdir()

    # High-signal PTLC repo
    hi = ws / "ptlc-research"
    hi.mkdir()
    (hi / ".git").mkdir()
    (hi / "spec.md").write_text(
        "# PTLC\n\n"
        "## Specification\n\nsecp256k1 point-lock + schnorr + plasma + "
        "sentinel + pillar + momentum + spork + ZNN + QSR\n\n"
        "## Threat Model\n\nreclaim reentrancy frontrunning boundary\n\n"
        "## Test Vectors\n\n0xdeadbeef1234abcd5678cafebabef00d\n"
        "0x0279be667ef9dcbbac55a06295ce870b\n\n"
        "## Errors\n\n- ErrPtlcNotFound\n- ErrExpiryInFuture\n"
    )

    # Low-signal unrelated repo
    lo = ws / "unrelated-tool"
    lo.mkdir()
    (lo / ".git").mkdir()
    (lo / "README.md").write_text("# Tool\n\nA general-purpose utility.\n")

    monkeypatch.setattr(
        "domains.investigation.engines.source_quality_scorer.workspace_root",
        lambda: ws,
    )
    return ws


class TestEntryPointDiscovery:
    def test_run_source_quality_scorer_is_discoverable(self):
        """Scheduler's zero-required-arg entry-point discovery finds it."""
        import inspect

        sig = inspect.signature(sqs.run_source_quality_scorer)
        required_non_db = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty and p.name != "db_path"
        ]
        assert required_non_db == []

    def test_entry_point_name_matches_scheduler_prefix(self):
        """Name starts with `run_` so it matches the discovery prefix."""
        assert callable(sqs.run_source_quality_scorer)
        assert sqs.run_source_quality_scorer.__name__.startswith("run_")


class TestRunSourceQualityScorer:
    def test_happy_path_scores_workspace_repos(self, fake_workspace, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        result = sqs.run_source_quality_scorer(db_path=db, max_repos=5)

        assert result["repos_scanned"] >= 1
        assert result["history_rows_persisted"] >= 1
        assert result["findings_persisted"] >= 1
        assert 0.0 <= result["average_quality_score"] <= 1.0

    def test_history_rows_persisted_with_signals(self, fake_workspace, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        sqs.run_source_quality_scorer(db_path=db, max_repos=5)

        conn = sqlite3.connect(db)
        rows = conn.execute(
            "SELECT repo_identity, quality_score, signals_json, "
            "files_scanned, bytes_scanned "
            "FROM repo_trust_history"
        ).fetchall()
        conn.close()

        assert len(rows) >= 1
        for repo_id, score, signals_json, files, _bytes in rows:
            assert repo_id in ("ptlc-research", "unrelated-tool")
            assert 0.0 <= score <= 1.0
            assert signals_json is not None  # JSON signals persisted
            assert files >= 0

    def test_ptlc_scores_above_unrelated(self, fake_workspace, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        # Force scan of BOTH repos by setting max_repos high
        sqs.run_source_quality_scorer(db_path=db, max_repos=10)

        conn = sqlite3.connect(db)
        scores = dict(
            conn.execute("SELECT repo_identity, quality_score FROM repo_trust_history").fetchall()
        )
        conn.close()

        if "ptlc-research" in scores and "unrelated-tool" in scores:
            assert scores["ptlc-research"] > scores["unrelated-tool"]

    def test_finding_has_full_body(self, fake_workspace, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        sqs.run_source_quality_scorer(db_path=db, max_repos=5)

        conn = sqlite3.connect(db)
        row = conn.execute(
            "SELECT finding, evidence_type, confidence "
            "FROM evidence WHERE engine = 'source_quality_scorer' LIMIT 1"
        ).fetchone()
        conn.close()

        assert row is not None
        finding, ev_type, conf = row
        assert "WHAT:" in finding
        assert "SO WHAT:" in finding
        assert "NOW WHAT:" in finding
        assert ev_type == "repo_quality_score"
        assert 0.0 < conf <= 1.0

    def test_workspace_missing_returns_empty(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ZENON_WORKSPACE_ROOT", raising=False)
        with patch(
            "domains.investigation.engines.source_quality_scorer.workspace_root",
            return_value=None,
        ):
            result = sqs.run_source_quality_scorer(db_path=str(tmp_path / "x.db"), max_repos=5)
        assert result["repos_scanned"] == 0
        assert result["history_rows_persisted"] == 0
        assert result["workspace_root"] is None

    def test_empty_workspace_returns_empty(self, tmp_path, monkeypatch):
        empty_ws = tmp_path / "empty_ws"
        empty_ws.mkdir()
        monkeypatch.setattr(
            "domains.investigation.engines.source_quality_scorer.workspace_root",
            lambda: empty_ws,
        )

        db = str(tmp_path / "x.db")
        ensure_schema(db)

        result = sqs.run_source_quality_scorer(db_path=db, max_repos=5)
        assert result["repos_scanned"] == 0
