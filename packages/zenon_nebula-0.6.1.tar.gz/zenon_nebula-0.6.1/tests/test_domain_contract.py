# SPDX-License-Identifier: MIT
"""
Domain plugin contract test.

Iterates every domain package under ``domains/`` and verifies its
``DomainPlugin`` subclass satisfies the contract that the scheduler,
collision engine, and War Room rely on. Any new domain that violates
the contract fails this test.

Enforced invariants:
- Inherits from ``DomainPlugin``.
- ``name()`` returns a non-empty string.
- ``get_description()`` returns a non-empty string.
- ``get_priority()`` returns an int in 1..9.
- ``get_engines()`` returns a list of ``EngineDefinition`` with name,
  module_path, and priority populated.
- Every listed engine module imports cleanly.
- Every engine module exposes at least one discoverable entry point
  (``run_*``, ``scan_*``, ``check_*``, ``analyze_*``, ``detect_*``,
  ``refresh_*``, ``process_*``, ``assess_*``, ``build_*``, ``classify_*``,
  ``evaluate_*``, ``fetch_*``, ``calculate_*``, ``generate_*``,
  or ``persist_findings``).
- ``decide_next_action`` returns a dict or None for a "routine" cycle
  where every known topic tag is listed as stale (with every topic
  stale, domains must return a dict — not None — because that's when
  the scheduler would expect them to fire).
- ``trusts_engine`` default is True.
- ``is_private`` default is False (unless the domain explicitly opts in).
"""

from __future__ import annotations

import importlib
import inspect
from collections.abc import Iterator
from pathlib import Path

import pytest

from core.domain_registry import DomainPlugin, EngineDefinition

NEBULA_ROOT = Path(__file__).resolve().parents[1]
DOMAINS_ROOT = NEBULA_ROOT / "domains"

ENTRY_PREFIXES = (
    "run_",
    "scan_",
    "check_",
    "analyze_",
    "detect_",
    "refresh_",
    "process_",
    "assess_",
    "build_",
    "classify_",
    "evaluate_",
    "fetch_",
    "calculate_",
    "generate_",
)
ENTRY_EXACT = {"persist_findings"}

# Topic tags the scheduler flags stale on boot. Sourced from the
# ALL_TOPICS bootstrap list in scripts/autonomous.py plus every other
# tag checked by any domain's decide_next_action. If a domain checks
# a tag not in this list, the scheduler will never flag it stale and
# the domain will never fire — which is itself a bug the contract
# test should surface.
ALL_TOPICS = [
    # community
    "contributors",
    "health",
    "sentiment",
    "sigs",
    "talent",
    # education
    "docs",
    "onboarding",
    # investigation
    "architecture",
    "vision",
    "history",
    "literature",
    # interoperability
    "bridge",
    "evm",
    "consensus",
    "external_chains",
    # marketing
    "narratives",
    "positioning",
    "dominance",
    # product_market_fit
    "competitive_data",
    "landscape",
    "adoption",
    "roadmap",
    "surface",
    "ecosystem_gap",
    "forks",
    "predictions",
    "futures",
    # self_maintenance
    "engine_health",
    "config_drift",
    # standards
    "bip_tracking",
    "deployment",
    "crypto_compliance",
    # economics
    "liquidity",
    "supply",
    "whales",
    "yields",
    "funnel",
    "hype",
    "staking",
    "thesis",
    # governance
    "proposals",
    "voting",
    "pillar_accountability",
    "treasury",
    "governance_intel",
    # network_health
    "pillars",
    "sentinels",
    "decentralization",
    "node_census",
    "bridge_health",
    # development
    "specs",
    "impl_coverage",
    "upstream",
    "deps",
    "drift",
    # security
    "security_scan",
    "exploit_scan",
    "cve_scan",
    "attack_simulation",
    "security_report",
    "bridge_exploit_scan",
    # quality
    "spec_verification",
    "build_check",
    "cross_repo_check",
    "test_coverage",
    "sdk_verification",
    # devops
    "devnet",
    "rpc",
    "integration_tests",
    "test_runner",
    # intelligence
    "upstream_signals",
    "signal_detection",
    "signal_routing",
    "ecosystem_health",
    "community_scan",
    # contribution
    "pr_readiness",
    "pr_description",
    "tminusz_contribution",
    "auto_contribution",
]


def _iter_domain_modules() -> Iterator[tuple[str, object]]:
    """Yield (domain_dir_name, imported domain module) pairs."""
    if not DOMAINS_ROOT.is_dir():
        return
    for entry in sorted(DOMAINS_ROOT.iterdir()):
        if not entry.is_dir() or entry.name.startswith(("_", ".")):
            continue
        if not (entry / "domain.py").is_file():
            continue
        module_name = f"domains.{entry.name}.domain"
        module = importlib.import_module(module_name)
        yield entry.name, module


def _find_plugin_class(module) -> type | None:
    """Return the first concrete DomainPlugin subclass defined in module."""
    for attr_name in dir(module):
        attr = getattr(module, attr_name)
        if (
            isinstance(attr, type)
            and issubclass(attr, DomainPlugin)
            and attr is not DomainPlugin
            and not inspect.isabstract(attr)
        ):
            return attr
    return None


def _collect_domains() -> list[tuple[str, DomainPlugin]]:
    """Instantiate every registered domain plugin."""
    out: list[tuple[str, DomainPlugin]] = []
    for dir_name, module in _iter_domain_modules():
        cls = _find_plugin_class(module)
        assert cls is not None, (
            f"domains/{dir_name}/domain.py has no concrete DomainPlugin subclass"
        )
        try:
            instance = cls()
        except Exception as exc:
            pytest.fail(f"{cls.__name__} failed to instantiate: {exc}")
        out.append((dir_name, instance))
    return out


DOMAINS: list[tuple[str, DomainPlugin]] = _collect_domains()
DOMAIN_IDS = [name for name, _ in DOMAINS]


def _engine_entry_points(module) -> list[str]:
    """Return the list of entry-point function names on a module."""
    names = []
    for attr in dir(module):
        if attr.startswith("_"):
            continue
        obj = getattr(module, attr)
        if not callable(obj):
            continue
        if attr in ENTRY_EXACT or any(attr.startswith(p) for p in ENTRY_PREFIXES):
            names.append(attr)
    return names


# ----- Tests ---------------------------------------------------------------


def test_at_least_one_domain_registered():
    """Smoke test: the contract suite actually found domains."""
    assert DOMAINS, "No domains discovered under domains/*/domain.py"


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_inherits_from_domain_plugin(dir_name, plugin):
    """Plugin is a DomainPlugin subclass."""
    assert isinstance(plugin, DomainPlugin)


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_name_non_empty_string(dir_name, plugin):
    """name() returns a non-empty string."""
    name = plugin.name()
    assert isinstance(name, str)
    assert name, f"{dir_name}: name() returned empty string"


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_description_non_empty_string(dir_name, plugin):
    """get_description() returns a non-empty string."""
    desc = plugin.get_description()
    assert isinstance(desc, str)
    assert desc, f"{dir_name}: get_description() returned empty string"


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_priority_in_valid_range(dir_name, plugin):
    """get_priority() returns an int in 1..9."""
    pri = plugin.get_priority()
    assert isinstance(pri, int), f"{dir_name}: priority must be int, got {type(pri)}"
    assert 1 <= pri <= 9, f"{dir_name}: priority {pri} outside 1..9"


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_get_engines_returns_list(dir_name, plugin):
    """get_engines() returns list[EngineDefinition] with required fields."""
    engines = plugin.get_engines()
    assert isinstance(engines, list), f"{dir_name}: get_engines() must return list"
    assert engines, f"{dir_name}: domain registers zero engines"
    for e in engines:
        assert isinstance(e, EngineDefinition), (
            f"{dir_name}: engine {e!r} is not an EngineDefinition"
        )
        assert e.name, f"{dir_name}: engine has empty name"
        assert e.module_path, f"{dir_name}: engine {e.name} has empty module_path"
        assert isinstance(e.priority, int), f"{dir_name}: engine {e.name} priority must be int"


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_engine_modules_import_cleanly(dir_name, plugin):
    """Every engine module must import without raising."""
    for engine in plugin.get_engines():
        try:
            importlib.import_module(engine.module_path)
        except Exception as exc:
            pytest.fail(
                f"{dir_name}: engine {engine.name} module "
                f"{engine.module_path} failed to import: {exc}"
            )


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_engine_has_discoverable_entry_point(dir_name, plugin):
    """Every engine module exposes at least one run_/scan_/... function."""
    for engine in plugin.get_engines():
        module = importlib.import_module(engine.module_path)
        entry_points = _engine_entry_points(module)
        assert entry_points, (
            f"{dir_name}: engine {engine.name} at {engine.module_path} has "
            f"no discoverable entry point. Expected a top-level function "
            f"with one of the prefixes "
            f"{ENTRY_PREFIXES} or named 'persist_findings'."
        )


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_decide_next_action_routine_with_all_stale(dir_name, plugin):
    """With every topic tag stale, the domain must return a dict (not None)."""
    context = {
        "trigger_level": "routine",
        "stale_data": list(ALL_TOPICS),
        "budget_remaining": 100.0,
    }
    result = plugin.decide_next_action(context)
    assert result is not None, (
        f"{dir_name}: decide_next_action returned None even though every "
        f"topic tag is stale. This means the domain will never fire — "
        f"add a default branch."
    )
    assert isinstance(result, dict), (
        f"{dir_name}: decide_next_action must return dict or None, got {type(result)}"
    )


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_decide_next_action_accepts_empty_context(dir_name, plugin):
    """Must accept a routine context with no stale tags without crashing."""
    context = {"trigger_level": "routine", "stale_data": []}
    try:
        result = plugin.decide_next_action(context)
    except Exception as exc:
        pytest.fail(f"{dir_name}: decide_next_action raised on empty stale_data: {exc}")
    # Either None or a dict is acceptable here — the invariant is "do
    # not crash". The test_decide_next_action_routine_with_all_stale
    # test enforces the stronger property.
    assert result is None or isinstance(result, dict)


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_trusts_engine_default_true(dir_name, plugin):
    """Unknown engine names default to trusted unless domain opts out."""
    # Use a random-ish sentinel name that no domain would allow-list.
    result = plugin.trusts_engine("__contract_test_unknown_engine__")
    # Security/attribution-sensitive domains may override to False —
    # that is fine. The assertion is simply that the method exists and
    # returns a bool without crashing.
    assert isinstance(result, bool)


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_is_private_default_false(dir_name, plugin):
    """is_private() defaults to False for public domains."""
    result = plugin.is_private()
    assert isinstance(result, bool)
    # Do not assert False here — some domains (e.g. marketing with
    # private drafts) may legitimately opt in. Just verify the method
    # is implemented and returns a bool.


@pytest.mark.parametrize("dir_name,plugin", DOMAINS, ids=DOMAIN_IDS)
def test_should_export_default_true(dir_name, plugin):
    """should_export() returns bool for any finding shape."""
    sample = {
        "domain": plugin.name(),
        "engine": "contract_test",
        "evidence_type": "metric",
        "finding": "sample",
        "confidence": 0.5,
    }
    result = plugin.should_export(sample)
    assert isinstance(result, bool)
