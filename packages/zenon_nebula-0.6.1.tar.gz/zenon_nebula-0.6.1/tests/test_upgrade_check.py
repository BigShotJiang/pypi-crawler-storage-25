# SPDX-License-Identifier: MIT
"""v0.6.0 upgrade_check tests.

Pins safety invariants: opt-out env var, cache TTL, version
comparison math, fail-safe on network errors, CLI banner
formatting.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from unittest.mock import patch

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core import upgrade_check as uc


class TestVersionComparison:
    def test_patch_bump_detected(self):
        update, maj, minor, patch = uc._compare_versions("0.5.7", "0.5.8")
        assert update
        assert patch
        assert not minor
        assert not maj

    def test_minor_bump_detected(self):
        update, maj, minor, patch = uc._compare_versions("0.5.8", "0.6.0")
        assert update
        assert minor
        assert not patch
        assert not maj

    def test_major_bump_detected(self):
        update, maj, minor, patch = uc._compare_versions("0.6.0", "1.0.0")
        assert update
        assert maj
        assert not minor
        assert not patch

    def test_same_version_no_update(self):
        update, _, _, _ = uc._compare_versions("0.6.0", "0.6.0")
        assert not update

    def test_older_latest_no_update(self):
        """If PyPI has an OLDER version than us (e.g., yanked release),
        we don't 'downgrade' — just report no update."""
        update, _, _, _ = uc._compare_versions("0.6.0", "0.5.8")
        assert not update

    def test_malformed_version_returns_no_update(self):
        update, _, _, _ = uc._compare_versions("not-a-version", "0.5.0")
        assert not update

    def test_parse_version_suffix_preserved(self):
        parsed = uc._parse_version("0.5.0-alpha")
        assert parsed is not None
        assert parsed[0:3] == (0, 5, 0)
        assert parsed[3] == "alpha"


class TestOptOut:
    def test_skip_env_var_returns_no_update(self, monkeypatch):
        monkeypatch.setenv("NEBULA_SKIP_UPGRADE_CHECK", "1")
        status = uc.check_for_update(current_version="0.5.0")
        assert not status.update_available
        assert status.latest_version is None
        assert any("disabled" in n for n in status.notes)

    def test_env_var_not_set_allows_check(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NEBULA_SKIP_UPGRADE_CHECK", raising=False)
        monkeypatch.setattr(uc, "CACHE_PATH", tmp_path / "cache.json")
        with patch.object(uc, "_fetch_latest_version_from_pypi", return_value="0.6.0"):
            status = uc.check_for_update(current_version="0.5.0")
        assert status.update_available
        assert status.latest_version == "0.6.0"


class TestCache:
    def test_fresh_cache_used(self, tmp_path, monkeypatch):
        monkeypatch.setattr(uc, "CACHE_PATH", tmp_path / "cache.json")
        monkeypatch.delenv("NEBULA_SKIP_UPGRADE_CHECK", raising=False)

        # Seed a fresh cache
        from datetime import datetime, timezone

        (tmp_path / "cache.json").write_text(
            json.dumps(
                {
                    "checked_at": datetime.now(timezone.utc).isoformat(),
                    "latest_version": "0.7.0",
                }
            )
        )

        with patch.object(uc, "_fetch_latest_version_from_pypi") as mock_fetch:
            status = uc.check_for_update(current_version="0.5.0")
            # Cached — should NOT hit the network
            mock_fetch.assert_not_called()

        assert status.cache_hit
        assert status.latest_version == "0.7.0"
        assert status.update_available

    def test_stale_cache_triggers_refresh(self, tmp_path, monkeypatch):
        monkeypatch.setattr(uc, "CACHE_PATH", tmp_path / "cache.json")
        monkeypatch.delenv("NEBULA_SKIP_UPGRADE_CHECK", raising=False)

        from datetime import datetime, timedelta, timezone

        old = datetime.now(timezone.utc) - timedelta(hours=48)
        (tmp_path / "cache.json").write_text(
            json.dumps(
                {
                    "checked_at": old.isoformat(),
                    "latest_version": "0.5.0",  # stale — should be ignored
                }
            )
        )

        with patch.object(uc, "_fetch_latest_version_from_pypi", return_value="0.6.0"):
            status = uc.check_for_update(current_version="0.5.0")

        assert status.latest_version == "0.6.0"
        # Cache was stale, so _load_cache returned None → cache_hit=False
        assert not status.cache_hit

    def test_corrupt_cache_handled(self, tmp_path, monkeypatch):
        monkeypatch.setattr(uc, "CACHE_PATH", tmp_path / "cache.json")
        monkeypatch.delenv("NEBULA_SKIP_UPGRADE_CHECK", raising=False)

        (tmp_path / "cache.json").write_text("not valid json{")

        with patch.object(uc, "_fetch_latest_version_from_pypi", return_value="0.6.0"):
            status = uc.check_for_update(current_version="0.5.0")

        # Corrupt cache shouldn't crash — should fall through to fresh fetch
        assert status.latest_version == "0.6.0"


class TestFailSafe:
    def test_network_failure_returns_no_update(self, tmp_path, monkeypatch):
        monkeypatch.setattr(uc, "CACHE_PATH", tmp_path / "cache.json")
        monkeypatch.delenv("NEBULA_SKIP_UPGRADE_CHECK", raising=False)

        with patch.object(uc, "_fetch_latest_version_from_pypi", return_value=None):
            status = uc.check_for_update(current_version="0.5.0")

        # Network failure → latest_version=None → update_available=False
        assert not status.update_available
        assert status.latest_version is None
        assert any("could not determine" in n for n in status.notes)


class TestCLIFormatting:
    def test_no_update_returns_empty_string(self):
        from datetime import datetime, timezone

        status = uc.UpgradeStatus(
            current_version="0.5.0",
            latest_version="0.5.0",
            update_available=False,
            major_bump=False,
            minor_bump=False,
            patch_bump=False,
            checked_at=datetime.now(timezone.utc).isoformat(),
            cache_hit=False,
            notes=[],
        )
        assert uc.format_for_cli(status) == ""

    def test_patch_update_banner(self):
        from datetime import datetime, timezone

        status = uc.UpgradeStatus(
            current_version="0.5.7",
            latest_version="0.5.8",
            update_available=True,
            major_bump=False,
            minor_bump=False,
            patch_bump=True,
            checked_at=datetime.now(timezone.utc).isoformat(),
            cache_hit=False,
            notes=[],
        )
        banner = uc.format_for_cli(status)
        assert "0.5.7" in banner
        assert "0.5.8" in banner
        assert "patch" in banner.lower()

    def test_major_update_banner(self):
        from datetime import datetime, timezone

        status = uc.UpgradeStatus(
            current_version="0.5.8",
            latest_version="1.0.0",
            update_available=True,
            major_bump=True,
            minor_bump=False,
            patch_bump=False,
            checked_at=datetime.now(timezone.utc).isoformat(),
            cache_hit=False,
            notes=[],
        )
        banner = uc.format_for_cli(status)
        assert "MAJOR" in banner
