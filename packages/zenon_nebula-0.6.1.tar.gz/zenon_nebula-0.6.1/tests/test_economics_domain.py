# SPDX-License-Identifier: MIT
"""Tests for domains.economics.domain -- Tokenomics tracking."""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.economics.domain import EconomicsDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestEconomicsDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(EconomicsDomain, DomainPlugin)

    def test_name(self):
        assert EconomicsDomain().name() == "economics"

    def test_get_engines_non_empty(self):
        engines = EconomicsDomain().get_engines()
        assert len(engines) >= 2
        names = [e.name for e in engines]
        assert "supply_tracker" in names
        assert "staking_analyzer" in names

    def test_get_hypothesis_types_non_empty(self):
        types = EconomicsDomain().get_hypothesis_types()
        assert len(types) >= 1
        ids = [t.type_id for t in types]
        assert "staking_ratio_50pct" in ids

    def test_get_aspiration_types(self):
        assert isinstance(EconomicsDomain().get_aspiration_types(), list)

    def test_get_collision_signals(self):
        assert isinstance(EconomicsDomain().get_collision_signals(), list)

    def test_get_war_room_contributions(self):
        assert isinstance(EconomicsDomain().get_war_room_contributions(), list)

    def test_get_self_improvement_metrics(self):
        metrics = EconomicsDomain().get_self_improvement_metrics()
        assert isinstance(metrics, dict)

    def test_get_db_schema_sql(self):
        sql = EconomicsDomain().get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action(self):
        action = EconomicsDomain().decide_next_action({})
        assert action is None or isinstance(action, dict)

    def test_registration(self):
        registry = DomainRegistry.instance()
        registry.register(EconomicsDomain())
        assert registry.get_domain("economics") is not None
