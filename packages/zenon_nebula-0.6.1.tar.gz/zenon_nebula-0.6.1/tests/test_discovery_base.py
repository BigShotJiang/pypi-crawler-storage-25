# SPDX-License-Identifier: MIT
"""
Tests for core.discovery_base -- Abstract base class for discovery templates.

Tests that DiscoveryTemplate ABC can be subclassed, execute runs the
template methods in order, validation errors short-circuit execution,
and errors during run are captured.
"""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.discovery_base import DiscoveryTemplate, TemplateResult
from core.persist_to_db import ensure_schema


class StubTemplate(DiscoveryTemplate):
    """Concrete subclass for testing."""

    tier = 1
    analysis_type = "test_analysis"
    domain = "test_domain"
    required_apis = []

    def run(self, params, session):
        return {"status": "ok", "value": params.get("x", 0), "confidence": 0.8}


class FailingTemplate(DiscoveryTemplate):
    """Template that raises during run."""

    tier = 1
    analysis_type = "failing_analysis"
    domain = "test_domain"
    required_apis = []

    def run(self, params, session):
        raise RuntimeError("Intentional test failure")


class ValidatingTemplate(DiscoveryTemplate):
    """Template with parameter validation."""

    tier = 1
    analysis_type = "validated_analysis"
    domain = "test_domain"
    required_apis = []

    def validate_params(self, params):
        errors = []
        if "required_field" not in params:
            errors.append("missing required_field")
        return errors

    def run(self, params, session):
        return {"status": "ok"}


class TestTemplateResult:
    """Test TemplateResult dataclass."""

    def test_default_values(self):
        result = TemplateResult(
            template_name="test",
            analysis_type="test",
            domain="test",
            results={},
        )
        assert result.summary == ""
        assert result.fingerprints == []
        assert result.persisted_id is None
        assert result.elapsed_seconds == 0.0
        assert result.provenance == "hypothesis"


class TestDiscoveryTemplateABC:
    """Test that ABC enforcement works."""

    def test_cannot_instantiate_abstract(self):
        """DiscoveryTemplate itself cannot be instantiated."""
        with pytest.raises(TypeError):
            DiscoveryTemplate()

    def test_subclass_instantiation(self):
        """Concrete subclass can be instantiated."""
        template = StubTemplate()
        assert template.tier == 1
        assert template.analysis_type == "test_analysis"
        assert template.domain == "test_domain"


class TestExecute:
    """Test the execute() orchestration method."""

    def test_successful_execution(self, tmp_path):
        """Successful run returns populated TemplateResult."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        template = StubTemplate()
        result = template.execute({"x": 42}, db_path=db)

        assert isinstance(result, TemplateResult)
        assert result.template_name == "StubTemplate"
        assert result.results["status"] == "ok"
        assert result.results["value"] == 42
        assert result.elapsed_seconds >= 0
        assert result.summary  # make_summary should produce something

    def test_execution_failure_captured(self, tmp_path):
        """Exceptions during run are captured, not raised."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        template = FailingTemplate()
        result = template.execute({}, db_path=db)

        assert "error" in result.results
        assert "Intentional test failure" in result.results["error"]

    def test_validation_errors_short_circuit(self, tmp_path):
        """Validation errors prevent run from executing."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        template = ValidatingTemplate()
        result = template.execute({}, db_path=db)  # Missing required_field

        assert "validation_errors" in result.results
        assert "missing required_field" in result.results["validation_errors"]

    def test_validation_passes(self, tmp_path):
        """When validation passes, run executes normally."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        template = ValidatingTemplate()
        result = template.execute({"required_field": "present"}, db_path=db)

        assert result.results.get("status") == "ok"

    def test_make_summary_default(self):
        """Default make_summary produces a string listing keys."""
        template = StubTemplate()
        summary = template.make_summary({"a": 1, "b": 2, "c": 3})
        assert "3 result fields" in summary

    def test_make_summary_empty(self):
        template = StubTemplate()
        summary = template.make_summary({})
        assert "No results" in summary

    def test_run_id_propagated(self, tmp_path):
        """run_id is passed through to persistence."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        template = StubTemplate()
        result = template.execute({"x": 1}, db_path=db, run_id="test-run-123")

        assert isinstance(result, TemplateResult)
        # Result should complete without error
        assert "error" not in result.results
