# SPDX-License-Identifier: MIT
"""Boundary-condition tests for persist_finding.

The user asked for "maximum test coverage". persist_finding is the
canonical write path for the entire evidence store — every domain,
every engine routes through it. These tests pin its boundary
behavior so future refactors can't silently mangle Unicode, NUL bytes,
extreme lengths, or unusual confidence values.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path
from unittest.mock import patch

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence.findings import persist_finding


@patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
class TestUnicodeAndEncoding:
    def test_unicode_finding_text_round_trips(self, mock_prov, db_path):
        """Non-ASCII text must survive a round trip without mangling."""
        text = "WHAT: 日本語 / emoji 🚀 / accented café. SO WHAT: ok. NOW WHAT: ok."
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="unicode_test",
            evidence_type="metric",
            finding=text,
            confidence=0.5,
        )
        assert row_id > 0

        conn = sqlite3.connect(db_path)
        try:
            stored = conn.execute(
                "SELECT finding FROM evidence WHERE id = ?", (row_id,)
            ).fetchone()[0]
        finally:
            conn.close()
        assert stored == text

    def test_zero_width_joiner_survives(self, mock_prov, db_path):
        """ZWJ-composed emoji should not get truncated by sqlite."""
        # 👨‍💻 = man + ZWJ + laptop
        text = "WHAT: \U0001f468\u200d\U0001f4bb is here. SO WHAT: ok. NOW WHAT: ok."
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="emoji_test",
            evidence_type="metric",
            finding=text,
        )
        conn = sqlite3.connect(db_path)
        try:
            stored = conn.execute(
                "SELECT finding FROM evidence WHERE id = ?", (row_id,)
            ).fetchone()[0]
        finally:
            conn.close()
        assert "\u200d" in stored

    def test_chinese_full_width_space(self, mock_prov, db_path):
        """Full-width CJK space (U+3000) survives storage."""
        text = "WHAT:\u3000工作. SO WHAT:\u3000ok. NOW WHAT:\u3000ok."
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="cjk_test",
            evidence_type="metric",
            finding=text,
        )
        conn = sqlite3.connect(db_path)
        try:
            stored = conn.execute(
                "SELECT finding FROM evidence WHERE id = ?", (row_id,)
            ).fetchone()[0]
        finally:
            conn.close()
        assert "\u3000" in stored
        assert "工作" in stored


@patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
class TestExtremeLengths:
    def test_very_long_finding_text(self, mock_prov, db_path):
        """A 50KB finding text must be stored intact (no truncation)."""
        big = "A" * 50_000
        text = f"WHAT: {big}. SO WHAT: long. NOW WHAT: ok."
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="long_test",
            evidence_type="metric",
            finding=text,
        )
        conn = sqlite3.connect(db_path)
        try:
            stored = conn.execute(
                "SELECT LENGTH(finding) FROM evidence WHERE id = ?", (row_id,)
            ).fetchone()[0]
        finally:
            conn.close()
        assert stored >= 50_000

    def test_single_char_finding(self, mock_prov, db_path):
        """A 1-char finding should still persist (not crash, not dedup oddly)."""
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="tiny_test",
            evidence_type="metric",
            finding="x",
        )
        # Plausibility gate may reject very short text. Either it's
        # rejected (returns -1) or it's stored. Both are acceptable;
        # the contract is "no crash".
        assert row_id == -1 or row_id > 0


@patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
class TestConfidenceBoundaries:
    def test_confidence_zero(self, mock_prov, db_path):
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="conf_test",
            evidence_type="metric",
            finding="WHAT: zero. SO WHAT: low. NOW WHAT: skip.",
            confidence=0.0,
        )
        # Plausibility gate may reject confidence=0; either outcome is fine.
        assert row_id == -1 or row_id > 0

    def test_confidence_one(self, mock_prov, db_path):
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="conf_test",
            evidence_type="metric",
            finding="WHAT: max. SO WHAT: max. NOW WHAT: max.",
            confidence=1.0,
        )
        assert row_id > 0

    def test_confidence_negative_does_not_crash(self, mock_prov, db_path):
        """Negative confidence is invalid but must not crash the writer."""
        # Persist accepts whatever you give it; the plausibility gate
        # may clamp or reject, but the call returns an integer.
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="conf_test",
            evidence_type="metric",
            finding="WHAT: neg. SO WHAT: neg. NOW WHAT: neg.",
            confidence=-0.1,
        )
        assert isinstance(row_id, int)

    def test_confidence_above_one_does_not_crash(self, mock_prov, db_path):
        """Confidence > 1.0 is invalid but must not crash the writer."""
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="conf_test",
            evidence_type="metric",
            finding="WHAT: high. SO WHAT: high. NOW WHAT: high.",
            confidence=1.5,
        )
        assert isinstance(row_id, int)


@patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
class TestEmptyAndNull:
    def test_empty_finding_rejected(self, mock_prov, db_path):
        """Empty finding text MUST be rejected by the plausibility gate
        (this is the regression test for the v0.2.14 adversarial_reviewer bug).
        """
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="empty_test",
            evidence_type="metric",
            finding="",
            confidence=0.5,
        )
        assert row_id == -1, "Empty finding text must be rejected, not silently persisted"

    def test_whitespace_only_finding_handled(self, mock_prov, db_path):
        """A finding that's only whitespace is effectively empty."""
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="ws_test",
            evidence_type="metric",
            finding="   \n\t  ",
            confidence=0.5,
        )
        assert isinstance(row_id, int)


@patch("core.persistence.findings.classify_provenance", return_value="hypothesis")
class TestSpecialCharacters:
    def test_sql_injection_in_finding_text(self, mock_prov, db_path):
        """A finding text containing SQL must be safely parameterized."""
        evil = "WHAT: '; DROP TABLE evidence; -- SO WHAT: ok. NOW WHAT: ok."
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="sqli_test",
            evidence_type="metric",
            finding=evil,
        )
        assert row_id > 0

        # Table must still exist
        conn = sqlite3.connect(db_path)
        try:
            count = conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
        finally:
            conn.close()
        assert count >= 1

    def test_null_byte_in_finding(self, mock_prov, db_path):
        """A literal NUL byte in finding text — sqlite stores it as-is."""
        text = "WHAT: before\x00after. SO WHAT: ok. NOW WHAT: ok."
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="nul_test",
            evidence_type="metric",
            finding=text,
        )
        assert row_id > 0
        conn = sqlite3.connect(db_path)
        try:
            stored = conn.execute(
                "SELECT finding FROM evidence WHERE id = ?", (row_id,)
            ).fetchone()[0]
        finally:
            conn.close()
        # SQLite text storage handles NUL safely as long as it's not used
        # as a C-string terminator anywhere in the read path.
        assert "before" in stored

    def test_quotes_and_backslashes(self, mock_prov, db_path):
        text = """WHAT: he said "hello" and r'world' and \\n. SO WHAT: ok. NOW WHAT: ok."""
        row_id = persist_finding(
            db_path=db_path,
            domain="test",
            engine="quote_test",
            evidence_type="metric",
            finding=text,
        )
        assert row_id > 0
