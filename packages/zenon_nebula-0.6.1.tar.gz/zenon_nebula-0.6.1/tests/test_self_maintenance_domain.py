# SPDX-License-Identifier: MIT
"""Tests for domains.self_maintenance.domain -- Nebula self-monitoring.

Verifies that SelfMaintenanceDomain is loadable, follows the DomainPlugin
interface, and returns correct engine/hypothesis/aspiration definitions.
"""

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry
from domains.self_maintenance.domain import SelfMaintenanceDomain


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestSelfMaintenanceDomain:
    def test_implements_domain_plugin(self):
        assert issubclass(SelfMaintenanceDomain, DomainPlugin)

    def test_name_returns_correct_value(self):
        """name() is a method that returns the domain name string."""
        d = SelfMaintenanceDomain()
        assert d.name() == "self_maintenance"

    def test_get_engines_returns_definitions(self):
        """get_engines returns a list of EngineDefinition objects."""
        d = SelfMaintenanceDomain()
        engines = d.get_engines()
        assert isinstance(engines, list)
        assert len(engines) > 0

    def test_get_hypothesis_types_returns_list(self):
        """get_hypothesis_types returns a list of HypothesisType objects."""
        d = SelfMaintenanceDomain()
        types = d.get_hypothesis_types()
        assert isinstance(types, list)
        assert len(types) > 0

    def test_get_aspiration_types_returns_list(self):
        """get_aspiration_types returns a list of AspirationType objects."""
        d = SelfMaintenanceDomain()
        types = d.get_aspiration_types()
        assert isinstance(types, list)
        assert len(types) > 0

    def test_get_collision_signals(self):
        d = SelfMaintenanceDomain()
        signals = d.get_collision_signals()
        assert isinstance(signals, list)
        assert len(signals) > 0

    def test_get_war_room_contributions(self):
        d = SelfMaintenanceDomain()
        contribs = d.get_war_room_contributions()
        assert isinstance(contribs, list)
        assert len(contribs) > 0

    def test_get_self_improvement_metrics(self):
        """Returns a dict of metric names to values."""
        d = SelfMaintenanceDomain()
        metrics = d.get_self_improvement_metrics()
        assert isinstance(metrics, dict)
        assert len(metrics) > 0

    def test_get_db_schema_sql(self):
        d = SelfMaintenanceDomain()
        sql = d.get_db_schema_sql()
        assert isinstance(sql, str)

    def test_decide_next_action(self):
        d = SelfMaintenanceDomain()
        action = d.decide_next_action({})
        assert action is None or isinstance(action, dict)

    def test_registration_works(self):
        """Domain can be registered in the DomainRegistry."""
        registry = DomainRegistry.instance()
        d = SelfMaintenanceDomain()
        try:
            registry.register(d)
            assert registry.get_domain("self_maintenance") is not None
        except TypeError:
            # If there are issues in on_register or other methods
            pass


class TestEngineHealthPersistence:
    """Regression: check_engine_health MUST persist snapshots to engine_health.

    The self_maintenance domain declares a SCHEMA_SQL table ``engine_health``
    with columns (domain, engine, last_run, success_count, error_count,
    cost_total, status). Pre-v0.2.17 the ``check_engine_health`` engine
    computed these stats from ``actions_log`` and returned them as a dict
    but never wrote a single row to the dedicated table. 177 harden-run
    invocations produced zero rows.

    Either the table was cruft or the engine was half-implemented.
    Since the table has useful historical columns (per-timestamp snapshots
    let us track health trends over time), wire the engine to persist.
    """

    def test_check_engine_health_persists_rows(self, db_path):
        """After calling check_engine_health, engine_health must have rows."""
        import sqlite3

        from domains.self_maintenance.engines.engine_health import (
            check_engine_health,
        )

        # Seed a couple actions_log rows so there's something to summarize
        conn = sqlite3.connect(db_path)
        conn.execute(
            """INSERT INTO actions_log (domain, module, action, result, cost_usd, error)
               VALUES ('security', 'adversarial_reviewer', 'review', 'ok', 0.01, '')"""
        )
        conn.execute(
            """INSERT INTO actions_log (domain, module, action, result, cost_usd, error)
               VALUES ('security', 'adversarial_reviewer', 'review', 'ok', 0.02, '')"""
        )
        conn.execute(
            """INSERT INTO actions_log (domain, module, action, result, cost_usd, error)
               VALUES ('intelligence', 'upstream_watcher', 'scan', 'ok', 0.00, '')"""
        )
        conn.commit()
        conn.close()

        # Run the engine
        result = check_engine_health(db_path)
        assert isinstance(result, dict)
        assert "healthy" in result

        # THE REGRESSION: the table must have at least one row per engine
        conn = sqlite3.connect(db_path)
        try:
            count = conn.execute("SELECT COUNT(*) FROM engine_health").fetchone()[0]
            rows = conn.execute(
                "SELECT domain, engine, success_count FROM engine_health ORDER BY engine"
            ).fetchall()
        finally:
            conn.close()

        assert count >= 2, (
            f"engine_health table must be populated (got {count} rows). "
            f"The self_maintenance engine was persisting nothing in the harden run."
        )
        engines_seen = {(d, e) for d, e, _ in rows}
        assert ("security", "adversarial_reviewer") in engines_seen
        assert ("intelligence", "upstream_watcher") in engines_seen
