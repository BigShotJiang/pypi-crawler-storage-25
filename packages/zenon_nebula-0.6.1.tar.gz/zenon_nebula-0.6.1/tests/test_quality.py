# SPDX-License-Identifier: MIT
"""Tests for the Quality domain plugin and its engines."""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainRegistry
from domains.quality.domain import QualityDomain
from domains.quality.engines.build_verifier import (
    REPO_CONFIGS,
    check_repo,
    get_build_summary,
    persist_results,
)
from domains.quality.engines.cross_repo_checker import (
    EMBEDDED_CONTRACTS,
    check_address_consistency,
    check_all_contracts,
    check_method_consistency,
    get_inconsistencies,
    persist_checks,
)
from domains.quality.engines.spec_verifier import (
    compare_abi_bytes,
    compare_json_fields,
    verify_contract,
)
from domains.quality.engines.test_coverage import (
    analyze_all_contracts,
    analyze_contract,
    get_coverage_summary,
    get_gaps,
    persist_coverage,
)

# -- Fixtures --


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


@pytest.fixture
def tmp_db():
    """Create a temporary database with quality domain schema."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    conn = sqlite3.connect(db_path)
    domain = QualityDomain()
    conn.executescript(domain.get_db_schema_sql())
    conn.commit()
    conn.close()

    yield db_path
    os.unlink(db_path)


# -- Domain registration tests --


class TestQualityDomainRegistration:
    def test_domain_name(self):
        domain = QualityDomain()
        assert domain.name() == "quality"

    def test_domain_priority(self):
        domain = QualityDomain()
        assert domain.get_priority() == 2

    def test_domain_registers_with_registry(self):
        registry = DomainRegistry.instance()
        domain = QualityDomain()
        registry.register(domain)
        assert "quality" in registry.get_domain_names()

    def test_domain_engines_count(self):
        domain = QualityDomain()
        engines = domain.get_engines()
        assert len(engines) == 5
        names = {e.name for e in engines}
        assert "spec_verifier" in names
        assert "build_verifier" in names
        assert "cross_repo_checker" in names
        assert "test_coverage" in names
        assert "reference_diff" in names

    def test_domain_hypothesis_types(self):
        domain = QualityDomain()
        types = domain.get_hypothesis_types()
        assert len(types) >= 4
        type_ids = {t.type_id for t in types}
        assert "abi_mismatch" in type_ids
        assert "build_regression" in type_ids

    def test_domain_db_schema(self):
        domain = QualityDomain()
        sql = domain.get_db_schema_sql()
        assert "build_status" in sql
        assert "test_coverage" in sql
        assert "consistency_checks" in sql

    def test_decide_next_action_urgent(self):
        domain = QualityDomain()
        action = domain.decide_next_action(
            {
                "trigger_level": "urgent",
                "stale_data": [],
            }
        )
        assert action["engine"] == "build_verifier"

    def test_decide_next_action_routine(self):
        domain = QualityDomain()
        action = domain.decide_next_action(
            {
                "trigger_level": "routine",
                "stale_data": [],
            }
        )
        assert action["engine"] == "test_coverage"

    def test_decide_next_action_stale_abi(self):
        domain = QualityDomain()
        action = domain.decide_next_action(
            {
                "trigger_level": "routine",
                "stale_data": ["abi_verification"],
            }
        )
        assert action["engine"] == "spec_verifier"

    def test_duplicate_registration_raises(self):
        registry = DomainRegistry.instance()
        registry.register(QualityDomain())
        with pytest.raises(ValueError):
            registry.register(QualityDomain())


# -- Spec verifier tests --


class TestSpecVerifier:
    def test_compare_abi_bytes_identical(self):
        abi = '[{"type":"function","name":"test"}]'
        result = compare_abi_bytes(abi, abi)
        assert result["match"] is True
        assert result["go_hash"] == result["dart_hash"]

    def test_compare_abi_bytes_different(self):
        go_abi = '[{"type":"function","name":"testA"}]'
        dart_abi = '[{"type":"function","name":"testB"}]'
        result = compare_abi_bytes(go_abi, dart_abi)
        assert result["match"] is False

    def test_compare_abi_bytes_whitespace_normalized(self):
        abi1 = '[{"type": "function", "name": "test"}]'
        abi2 = '[{"type":"function","name":"test"}]'
        result = compare_abi_bytes(abi1, abi2)
        assert result["match"] is True

    def test_compare_json_fields_all_match(self):
        go_tags = {"Amount": "amount", "TokenStandard": "tokenStandard"}
        dart_keys = {"amount": "amount", "tokenStandard": "tokenStandard"}
        results = compare_json_fields(go_tags, dart_keys)
        for r in results:
            assert r["match"] is True

    def test_compare_json_fields_mismatch(self):
        go_tags = {"Amount": "amount"}
        dart_keys = {"total": "total"}
        results = compare_json_fields(go_tags, dart_keys)
        mismatches = [r for r in results if not r["match"]]
        assert len(mismatches) >= 1

    def test_verify_contract_returns_dict(self):
        result = verify_contract("nonexistent_xyz")
        assert isinstance(result, dict)
        assert result["contract_name"] == "nonexistent_xyz"

    def test_verify_contract_real_governance(self):
        """Test verification on a real contract if available."""
        result = verify_contract("governance")
        assert result["contract_name"] == "governance"
        # May or may not find definitions depending on repo layout


# -- Build verifier tests --


class TestBuildVerifier:
    def test_repo_configs_exist(self):
        assert len(REPO_CONFIGS) >= 3

    def test_check_repo_missing_path(self):
        config = {
            "repo_name": "nonexistent",
            "path": Path("/nonexistent/repo"),
            "language": "go",
            "commands": [("go build ./...", "build")],
        }
        results = check_repo(config)
        assert len(results) >= 1
        assert results[0]["success"] is False

    def test_persist_results(self, tmp_db):
        results = {
            "test_repo": [
                {
                    "language": "go",
                    "command": "go build ./...",
                    "success": True,
                    "output": "ok",
                    "duration_seconds": 1.5,
                },
            ],
        }
        count = persist_results(results, db_path=tmp_db)
        assert count == 1

        conn = sqlite3.connect(tmp_db)
        row = conn.execute("SELECT * FROM build_status").fetchone()
        conn.close()
        assert row is not None

    def test_get_build_summary_empty(self, tmp_db):
        summary = get_build_summary(db_path=tmp_db)
        assert isinstance(summary, dict)
        assert len(summary) == 0


# -- Cross-repo checker tests --


class TestCrossRepoChecker:
    def test_embedded_contracts_list(self):
        assert len(EMBEDDED_CONTRACTS) >= 8
        assert "htlc" in EMBEDDED_CONTRACTS
        assert "bridge" in EMBEDDED_CONTRACTS

    def test_check_address_consistency_returns_list(self):
        results = check_address_consistency("htlc")
        assert isinstance(results, list)

    def test_check_method_consistency_returns_list(self):
        results = check_method_consistency("htlc")
        assert isinstance(results, list)

    def test_check_all_contracts_returns_list(self):
        results = check_all_contracts(contract_names=["htlc"])
        assert isinstance(results, list)

    def test_persist_checks(self, tmp_db):
        checks = [
            {
                "check_type": "address",
                "contract_name": "htlc",
                "item_name": "htlc_address",
                "repo_a": "go-zenon",
                "value_a": "z1qtest",
                "repo_b": "sdk",
                "value_b": "z1qtest",
                "match": True,
            },
        ]
        count = persist_checks(checks, db_path=tmp_db)
        assert count == 1

    def test_get_inconsistencies_empty(self, tmp_db):
        results = get_inconsistencies(db_path=tmp_db)
        assert results == []

    def test_get_inconsistencies_with_data(self, tmp_db):
        checks = [
            {
                "check_type": "address",
                "contract_name": "htlc",
                "item_name": "htlc_address",
                "repo_a": "go-zenon",
                "value_a": "z1qa",
                "repo_b": "sdk",
                "value_b": "z1qb",
                "match": False,
            },
        ]
        persist_checks(checks, db_path=tmp_db)
        results = get_inconsistencies(db_path=tmp_db)
        assert len(results) == 1
        assert results[0]["contract_name"] == "htlc"


# -- Test coverage tests --


class TestTestCoverage:
    def test_analyze_contract_returns_dict(self):
        result = analyze_contract("htlc")
        assert isinstance(result, dict)
        assert result["contract_name"] == "htlc"
        assert "methods_total" in result
        assert "coverage_pct" in result

    def test_analyze_all_contracts_returns_list(self):
        results = analyze_all_contracts(contract_names=["htlc", "bridge"])
        assert len(results) == 2
        names = {r["contract_name"] for r in results}
        assert "htlc" in names
        assert "bridge" in names

    def test_get_gaps(self):
        results = [
            {
                "contract_name": "htlc",
                "untested_methods": ["MethodA"],
                "coverage_pct": 50.0,
            },
            {
                "contract_name": "bridge",
                "untested_methods": [],
                "coverage_pct": 100.0,
            },
        ]
        gaps = get_gaps(results)
        assert len(gaps) == 1
        assert gaps[0]["contract_name"] == "htlc"

    def test_persist_coverage(self, tmp_db):
        results = [
            {
                "contract_name": "htlc",
                "methods_total": 5,
                "methods_tested": 3,
                "go_test_count": 10,
                "dart_test_count": 2,
                "coverage_pct": 60.0,
            },
        ]
        count = persist_coverage(results, db_path=tmp_db)
        assert count == 2  # One for go, one for dart

        conn = sqlite3.connect(tmp_db)
        rows = conn.execute("SELECT * FROM test_coverage").fetchall()
        conn.close()
        assert len(rows) == 2

    def test_get_coverage_summary_empty(self, tmp_db):
        summary = get_coverage_summary(db_path=tmp_db)
        assert isinstance(summary, dict)
