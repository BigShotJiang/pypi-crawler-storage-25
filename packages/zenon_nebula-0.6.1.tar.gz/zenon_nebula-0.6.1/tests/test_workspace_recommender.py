# SPDX-License-Identifier: MIT
"""v0.4.3 Phase F — workspace_recommender engine tests.

Pins the safe-recommendation behavior: NEVER auto-clone, only
emit recommendation findings when the publishing peer has earned
dynamic trust, and mask the recommending peer's identity behind
the tier label.
"""

from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence.schema import ensure_schema
from domains.contribution.engines import workspace_recommender as wr


def _seed_trust(db_path: str, repo_identity: str, score: float, scans: int = 55) -> None:
    """Promote a repo to a dynamic trust tier via repo_trust_history."""
    conn = sqlite3.connect(db_path)
    try:
        for _ in range(scans):
            conn.execute(
                """
                INSERT INTO repo_trust_history
                (repo_identity, quality_score, signals_json,
                 files_scanned, bytes_scanned, scan_duration_seconds, scanned_at)
                VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
                """,
                (
                    repo_identity,
                    score,
                    json.dumps({"spec_impl_match": 0.4, "reproducibility": 0.4}),
                    10,
                    1000,
                    0.1,
                ),
            )
        conn.commit()
    finally:
        conn.close()


def _insert_finding_referencing(db_path: str, source_repo: str, count: int = 1) -> None:
    """Insert N recent evidence rows with a given source_repo."""
    conn = sqlite3.connect(db_path)
    try:
        for i in range(count):
            conn.execute(
                """
                INSERT INTO evidence
                (domain, engine, evidence_type, finding, confidence, source_repo, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
                """,
                (
                    "security",
                    "peer:remote",
                    "bug",
                    f"finding {i} from {source_repo}",
                    0.8,
                    source_repo,
                ),
            )
        conn.commit()
    finally:
        conn.close()


@pytest.fixture
def fake_workspace(tmp_path, monkeypatch):
    """Empty workspace so nothing is 'locally cloned'."""
    ws = tmp_path / "workspace"
    ws.mkdir()
    monkeypatch.setattr(
        "domains.contribution.engines.workspace_recommender.workspace_root",
        lambda: ws,
    )
    return ws


class TestEntryPointDiscovery:
    def test_run_workspace_recommender_is_discoverable(self):
        import inspect

        sig = inspect.signature(wr.run_workspace_recommender)
        required_non_db = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty and p.name != "db_path"
        ]
        assert required_non_db == []

    def test_entry_point_name_starts_with_run(self):
        assert wr.run_workspace_recommender.__name__.startswith("run_")


class TestRecommendationLogic:
    def test_trusted_peer_findings_generate_recommendation(self, fake_workspace, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        _seed_trust(db, "new-trusted-repo", 0.85)
        _insert_finding_referencing(db, "new-trusted-repo", count=3)

        result = wr.run_workspace_recommender(db_path=db)

        assert result["recent_source_repos"] >= 1
        assert result["qualifying_recommendations"] >= 1
        assert result["findings_persisted"] >= 1

    def test_untrusted_peer_findings_do_not_generate_recommendations(
        self, fake_workspace, tmp_path
    ):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        # No trust history → default 0.3, below the 0.5 threshold
        _insert_finding_referencing(db, "unknown-repo", count=2)

        result = wr.run_workspace_recommender(db_path=db)

        assert result["qualifying_recommendations"] == 0
        assert result["findings_persisted"] == 0

    def test_locally_cloned_repo_skipped(self, fake_workspace, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        # Repo exists in the fake workspace
        (fake_workspace / "cloned-repo").mkdir()
        (fake_workspace / "cloned-repo" / ".git").mkdir()

        _seed_trust(db, "cloned-repo", 0.85)
        _insert_finding_referencing(db, "cloned-repo", count=2)

        result = wr.run_workspace_recommender(db_path=db)

        assert result["locally_cloned"] >= 1
        # A locally-cloned repo is never recommended
        conn = sqlite3.connect(db)
        rows = conn.execute(
            "SELECT COUNT(*) FROM evidence "
            "WHERE engine = 'workspace_recommender' "
            "AND source_repo = 'cloned-repo'"
        ).fetchone()
        conn.close()
        assert rows[0] == 0

    def test_workspace_missing_returns_empty(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "domains.contribution.engines.workspace_recommender.workspace_root",
            lambda: None,
        )
        result = wr.run_workspace_recommender(db_path=str(tmp_path / "x.db"))
        assert result["workspace_root"] is None
        assert result["findings_persisted"] == 0

    def test_no_recent_findings_returns_empty(self, fake_workspace, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)
        result = wr.run_workspace_recommender(db_path=db)
        assert result["recent_source_repos"] == 0
        assert result["findings_persisted"] == 0


class TestAntiDoxxingGuarantees:
    """Pin the peer-identity masking invariant.

    The recommendation body must NEVER contain the recommending
    peer's identity (peer:xxx). It must only use the tier label.
    This prevents third parties from building "peer X recommends
    these 50 repos" profiles that would eventually deanonymize
    peer X by their taste.
    """

    def test_recommendation_body_never_contains_peer_id(self, fake_workspace, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        _seed_trust(db, "some-trusted-repo", 0.85)
        _insert_finding_referencing(db, "some-trusted-repo", count=2)

        wr.run_workspace_recommender(db_path=db)

        conn = sqlite3.connect(db)
        rows = conn.execute(
            "SELECT finding FROM evidence WHERE engine = 'workspace_recommender'"
        ).fetchall()
        conn.close()

        assert rows, "expected at least one recommendation finding"
        for (body,) in rows:
            assert "peer:" not in body.lower(), (
                "workspace_recommender MUST NOT leak peer:xxx identifiers "
                "in recommendation bodies — v0.4.x anti-funnel invariant"
            )
            # Must contain a tier label instead
            assert any(t in body for t in ("attested", "trusted", "core")), (
                "recommendation body should reference the tier label"
            )

    def test_recommendation_has_what_sowhat_nowwhat_body(self, fake_workspace, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        _seed_trust(db, "ws-test-repo", 0.85)
        _insert_finding_referencing(db, "ws-test-repo", count=1)

        wr.run_workspace_recommender(db_path=db)

        conn = sqlite3.connect(db)
        rows = conn.execute(
            "SELECT finding FROM evidence WHERE engine = 'workspace_recommender'"
        ).fetchall()
        conn.close()
        assert rows
        body = rows[0][0]
        assert "WHAT:" in body
        assert "SO WHAT:" in body
        assert "NOW WHAT:" in body
        assert "WARNING" in body  # safety warning about manual review


class TestNoAutoCloneGuarantee:
    """The engine NEVER clones anything — it only emits findings."""

    @staticmethod
    def _executable_source() -> str:
        """Return module source with docstrings + comments stripped.

        Docstrings are allowed to mention the bans they enforce
        (and must, for clarity). The bans only apply to executable
        code.
        """
        import re

        src = Path(wr.__file__).read_text()
        src = re.sub(r'""".*?"""', "", src, flags=re.DOTALL)
        src = re.sub(r"'''.*?'''", "", src, flags=re.DOTALL)
        src = re.sub(r"#.*$", "", src, flags=re.MULTILINE)
        return src

    def test_no_subprocess_git_clone_in_module(self):
        """Pin: workspace_recommender.py executable code must never
        invoke git clone.

        The anti-auto-clone invariant is load-bearing for the
        attack-vector analysis in task #46 Phase F. If a future
        change adds `git clone` or any subprocess invocation, this
        test fails loudly.
        """
        src = self._executable_source()
        assert "git clone" not in src, (
            "workspace_recommender MUST NOT invoke git clone — operator-initiated cloning only."
        )
        assert "subprocess.run" not in src and "subprocess.call" not in src, (
            "workspace_recommender MUST NOT invoke any subprocess — "
            "no auto-execution from peer signal."
        )
        assert "urllib.request.urlopen" not in src, (
            "workspace_recommender MUST NOT fetch URLs directly — "
            "that's peek mode territory (future Phase F+ extension)."
        )
