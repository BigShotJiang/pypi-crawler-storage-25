# SPDX-License-Identifier: MIT
"""Tests for core.evidence_vault -- SHA-256 integrity vault for findings."""

import json

import pytest

import core.evidence_vault as vault_mod
from core.evidence_vault import (
    _compute_content_hash,
    _compute_fingerprint_hash,
    archive_finding,
    get_publishable_findings,
    mark_as_published,
    verify_finding,
    verify_vault_integrity,
)


@pytest.fixture(autouse=True)
def temp_vault(tmp_path, monkeypatch):
    """Redirect the vault to a temp directory for every test."""
    monkeypatch.setattr(vault_mod, "VAULT_DIR", tmp_path / "vault")
    return tmp_path / "vault"


class TestHashFunctions:
    def test_fingerprint_hash_deterministic(self):
        fps = [{"url": "https://api.example.com", "status_code": 200}]
        h1 = _compute_fingerprint_hash(fps)
        h2 = _compute_fingerprint_hash(fps)
        assert h1 == h2
        assert len(h1) == 64  # SHA-256 hex

    def test_fingerprint_hash_changes_with_data(self):
        h1 = _compute_fingerprint_hash([{"a": 1}])
        h2 = _compute_fingerprint_hash([{"a": 2}])
        assert h1 != h2

    def test_content_hash_deterministic(self):
        data = {"key": "value", "nested": {"x": 1}}
        assert _compute_content_hash(data) == _compute_content_hash(data)

    def test_empty_fingerprints_hash(self):
        h = _compute_fingerprint_hash([])
        assert len(h) == 64


class TestArchiveFinding:
    def test_returns_vault_path(self):
        path = archive_finding(
            phase="evidence_1",
            analysis_type="block_check",
            fingerprints=[{"url": "https://api.example.com", "status_code": 200}],
            results_json={"height": 1000},
            domain="test",
        )
        assert path.startswith("test/evidence_1.json#")
        assert path.endswith("#0")

    def test_creates_file_on_disk(self, temp_vault):
        archive_finding(
            phase="phase_a",
            analysis_type="type_a",
            fingerprints=[],
            results_json={"x": 1},
            domain="d1",
        )
        file_path = temp_vault / "d1" / "phase_a.json"
        assert file_path.exists()
        data = json.loads(file_path.read_text())
        assert len(data) == 1
        assert data[0]["results"]["x"] == 1

    def test_multiple_entries_same_phase(self):
        p1 = archive_finding(
            phase="shared", analysis_type="t", fingerprints=[], results_json={"v": 1}, domain="d"
        )
        p2 = archive_finding(
            phase="shared", analysis_type="t", fingerprints=[], results_json={"v": 2}, domain="d"
        )
        assert p1.endswith("#0")
        assert p2.endswith("#1")

    def test_entry_contains_hashes(self, temp_vault):
        fps = [{"url": "test", "status": 200}]
        results = {"finding": "something"}
        archive_finding(
            phase="hashed", analysis_type="t", fingerprints=fps, results_json=results, domain="d"
        )
        data = json.loads((temp_vault / "d" / "hashed.json").read_text())
        entry = data[0]
        assert entry["fingerprint_hash"] == _compute_fingerprint_hash(fps)
        assert entry["content_hash"] == _compute_content_hash(results)


class TestVerifyFinding:
    def test_valid_entry_passes(self):
        path = archive_finding(
            phase="valid",
            analysis_type="t",
            fingerprints=[{"a": 1}],
            results_json={"b": 2},
            domain="d",
        )
        assert verify_finding(path) is True

    def test_tampered_fingerprint_fails(self, temp_vault):
        path = archive_finding(
            phase="tamper",
            analysis_type="t",
            fingerprints=[{"a": 1}],
            results_json={"b": 2},
            domain="d",
        )
        # Tamper with the file
        file_path = temp_vault / "d" / "tamper.json"
        data = json.loads(file_path.read_text())
        data[0]["fingerprints"] = [{"a": 999}]  # tamper
        file_path.write_text(json.dumps(data))
        assert verify_finding(path) is False

    def test_tampered_content_fails(self, temp_vault):
        path = archive_finding(
            phase="tamper_c",
            analysis_type="t",
            fingerprints=[],
            results_json={"original": True},
            domain="d",
        )
        file_path = temp_vault / "d" / "tamper_c.json"
        data = json.loads(file_path.read_text())
        data[0]["results"] = {"original": False}
        file_path.write_text(json.dumps(data))
        assert verify_finding(path) is False

    def test_invalid_path_returns_false(self):
        assert verify_finding("bad/path/no#index") is False

    def test_out_of_range_index(self):
        archive_finding(
            phase="single", analysis_type="t", fingerprints=[], results_json={}, domain="d"
        )
        assert verify_finding("d/single.json#99") is False


class TestGetPublishableFindings:
    def test_returns_unpublished_entries(self):
        archive_finding(
            phase="pub_test", analysis_type="t", fingerprints=[], results_json={"x": 1}, domain="d"
        )
        findings = get_publishable_findings(domain="d")
        assert len(findings) == 1
        assert findings[0]["published"] is False

    def test_excludes_published(self):
        path = archive_finding(
            phase="pub_test2", analysis_type="t", fingerprints=[], results_json={}, domain="d"
        )
        mark_as_published(path)
        findings = get_publishable_findings(domain="d")
        assert len(findings) == 0

    def test_excludes_tampered(self, temp_vault):
        archive_finding(
            phase="pub_tamper",
            analysis_type="t",
            fingerprints=[{"a": 1}],
            results_json={},
            domain="d",
        )
        # Tamper
        fp = temp_vault / "d" / "pub_tamper.json"
        data = json.loads(fp.read_text())
        data[0]["fingerprints"] = [{"a": 999}]
        fp.write_text(json.dumps(data))
        findings = get_publishable_findings(domain="d")
        assert len(findings) == 0

    def test_cross_domain_scan(self):
        archive_finding(
            phase="p1", analysis_type="t", fingerprints=[], results_json={}, domain="d1"
        )
        archive_finding(
            phase="p2", analysis_type="t", fingerprints=[], results_json={}, domain="d2"
        )
        findings = get_publishable_findings()  # no domain filter
        assert len(findings) == 2


class TestMarkAsPublished:
    def test_marks_entry(self, temp_vault):
        path = archive_finding(
            phase="mark_test", analysis_type="t", fingerprints=[], results_json={}, domain="d"
        )
        mark_as_published(path)
        data = json.loads((temp_vault / "d" / "mark_test.json").read_text())
        assert data[0]["published"] is True
        assert "published_at" in data[0]


class TestVaultIntegrity:
    def test_all_valid(self):
        archive_finding(
            phase="int1", analysis_type="t", fingerprints=[], results_json={}, domain="d"
        )
        archive_finding(
            phase="int2", analysis_type="t", fingerprints=[], results_json={}, domain="d"
        )
        result = verify_vault_integrity(domain="d")
        assert result["total"] == 2
        assert result["valid"] == 2
        assert result["tampered"] == 0

    def test_detects_tampered(self, temp_vault):
        archive_finding(
            phase="int_bad", analysis_type="t", fingerprints=[{"a": 1}], results_json={}, domain="d"
        )
        fp = temp_vault / "d" / "int_bad.json"
        data = json.loads(fp.read_text())
        data[0]["fingerprints"] = [{"a": 999}]
        fp.write_text(json.dumps(data))
        result = verify_vault_integrity(domain="d")
        assert result["tampered"] == 1
