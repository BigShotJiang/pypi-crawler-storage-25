# SPDX-License-Identifier: MIT
"""
Tests for core.parallel_runner -- Concurrent engine execution.

Tests detect_machine returns valid profile, ParallelEngineRunner runs
engines concurrently, and local vs LLM engine separation.
"""

import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.parallel_runner import (
    MachineProfile,
    ParallelEngineRunner,
    detect_machine,
    enable_wal_mode,
    get_performance_tips,
)


class TestDetectMachine:
    """Test machine detection."""

    def test_returns_machine_profile(self):
        profile = detect_machine()
        assert isinstance(profile, MachineProfile)

    def test_os_name_valid(self):
        profile = detect_machine()
        assert profile.os_name in ("darwin", "linux", "windows")

    def test_cpu_cores_positive(self):
        profile = detect_machine()
        assert profile.cpu_cores >= 1

    def test_ram_positive(self):
        profile = detect_machine()
        assert profile.ram_gb > 0

    def test_parallelism_positive(self):
        profile = detect_machine()
        assert profile.recommended_parallelism >= 1

    def test_strategy_set(self):
        profile = detect_machine()
        valid = {
            "sequential",
            "light_parallel",
            "moderate_parallel",
            "full_parallel",
            "max_parallel",
        }
        assert profile.recommended_strategy in valid


class TestParallelismTierMapping:
    """Pin the (cpu, ram) → parallelism tier mapping that drives autosizing.

    These scenarios are what the autonomous runner uses to decide how many
    threads to spin up. If you bump them, also update the operator-facing
    documentation in docs/operations/scaling.md.
    """

    def _profile_for(self, cores: int, ram_gb: float) -> MachineProfile:
        """Build a synthetic profile by patching detect_machine inputs."""
        from unittest.mock import patch

        with (
            patch("core.parallel_runner.multiprocessing.cpu_count", return_value=cores),
            patch("core.parallel_runner.platform.system", return_value="Linux"),
            patch("builtins.open", create=True) as mock_open,
        ):
            handle = mock_open.return_value.__enter__.return_value
            handle.__iter__ = lambda self: iter([f"MemTotal: {int(ram_gb * 1024 * 1024)} kB\n"])
            return detect_machine()

    def test_tiny_vps_1_core_1gb_runs_sequential(self):
        profile = self._profile_for(cores=1, ram_gb=1.0)
        assert profile.recommended_parallelism == 1
        assert profile.recommended_strategy == "sequential"

    def test_small_vps_2_cores_2gb_uses_light_parallel(self):
        profile = self._profile_for(cores=2, ram_gb=2.0)
        assert profile.recommended_parallelism == 2
        assert profile.recommended_strategy == "light_parallel"

    def test_medium_vps_4_cores_8gb_uses_moderate(self):
        profile = self._profile_for(cores=4, ram_gb=8.0)
        assert profile.recommended_parallelism == 4
        assert profile.recommended_strategy == "moderate_parallel"

    def test_workstation_8_cores_16gb_uses_full(self):
        profile = self._profile_for(cores=8, ram_gb=16.0)
        assert profile.recommended_parallelism >= 4
        assert profile.recommended_strategy in ("full_parallel", "max_parallel")

    def test_beefy_box_16_cores_64gb_uses_max(self):
        profile = self._profile_for(cores=16, ram_gb=64.0)
        assert profile.recommended_parallelism == 8
        assert profile.recommended_strategy == "max_parallel"


class TestParallelEngineRunner:
    """Test engine runner."""

    def test_runner_creation(self):
        runner = ParallelEngineRunner(max_workers=2)
        assert runner.max_workers == 2
        assert runner.profile is not None

    def test_run_engines_local(self):
        """Local engines run in parallel and produce results."""
        runner = ParallelEngineRunner(max_workers=2)

        engines = [
            {
                "name": "engine_a",
                "function": lambda: {"computed": True},
                "requires_llm": False,
            },
            {
                "name": "engine_b",
                "function": lambda: {"computed": True},
                "requires_llm": False,
            },
        ]

        results = runner.run_engines(engines)
        assert len(results) == 2

        for r in results:
            assert r["success"] is True
            assert r["duration"] >= 0

    def test_run_engines_llm_sequential(self):
        """LLM engines run sequentially."""
        call_order = []

        def llm_engine_a():
            call_order.append("a")
            return {"result": "a"}

        def llm_engine_b():
            call_order.append("b")
            return {"result": "b"}

        runner = ParallelEngineRunner(max_workers=2)
        engines = [
            {"name": "llm_a", "function": llm_engine_a, "requires_llm": True},
            {"name": "llm_b", "function": llm_engine_b, "requires_llm": True},
        ]

        results = runner.run_engines(engines)
        assert len(results) == 2
        # Both should have run
        assert "a" in call_order
        assert "b" in call_order

    def test_run_engines_mixed(self):
        """Mixed local and LLM engines both complete."""
        runner = ParallelEngineRunner(max_workers=2)
        engines = [
            {"name": "local_1", "function": lambda: "local", "requires_llm": False},
            {"name": "llm_1", "function": lambda: "llm", "requires_llm": True},
        ]

        results = runner.run_engines(engines)
        assert len(results) == 2
        names = [r["name"] for r in results]
        assert "local_1" in names
        assert "llm_1" in names

    def test_engine_failure_captured(self):
        """Engine exceptions are captured, not propagated."""
        runner = ParallelEngineRunner(max_workers=1)
        engines = [
            {
                "name": "bad_engine",
                "function": lambda: (_ for _ in ()).throw(ValueError("boom")),
                "requires_llm": False,
            },
        ]

        results = runner.run_engines(engines)
        assert len(results) == 1
        assert results[0]["success"] is False

    def test_run_domains_parallel(self):
        """run_domains_parallel executes domain actions concurrently."""
        runner = ParallelEngineRunner(max_workers=2)

        actions = [
            ("security", lambda: {"action": "scan", "priority": 1}),
            ("quality", lambda: {"action": "verify", "priority": 2}),
        ]

        results = runner.run_domains_parallel(actions)
        assert len(results) == 2
        domains = [r["domain"] for r in results]
        assert "security" in domains
        assert "quality" in domains


class TestEnableWAL:
    def test_enables_wal(self, tmp_path):
        import sqlite3

        db = str(tmp_path / "test.db")
        conn = sqlite3.connect(db)
        conn.execute("CREATE TABLE test (id INTEGER)")
        conn.close()

        enable_wal_mode(db)

        conn = sqlite3.connect(db)
        mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
        conn.close()
        assert mode == "wal"


class TestPerformanceTips:
    def test_returns_list(self):
        tips = get_performance_tips()
        assert isinstance(tips, list)
        assert len(tips) >= 1

    def test_includes_recommendation(self):
        tips = get_performance_tips()
        assert any("Recommended:" in t for t in tips)
