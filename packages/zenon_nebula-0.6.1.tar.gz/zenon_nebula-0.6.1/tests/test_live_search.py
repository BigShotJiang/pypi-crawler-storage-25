# SPDX-License-Identifier: MIT
"""Tests for core.live_search (Phase 17)."""

from __future__ import annotations

from core.live_search import SearchResult, _normalize_citation, search


class TestNormalizeCitation:
    def test_string_citation_passthrough(self):
        assert _normalize_citation("https://example.com") == "https://example.com"

    def test_dict_citation_preserves_url_title_snippet(self):
        raw = {"url": "https://x.com/a", "title": "A", "snippet": "s"}
        out = _normalize_citation(raw)
        assert isinstance(out, dict)
        assert out["url"] == "https://x.com/a"
        assert out["title"] == "A"
        assert out["snippet"] == "s"

    def test_dict_citation_source_fallback_to_url_key(self):
        raw = {"source": "https://x.com/b", "title": "B"}
        out = _normalize_citation(raw)
        assert out["url"] == "https://x.com/b"

    def test_dict_citation_extra_fields_preserved(self):
        raw = {"url": "u", "title": "t", "snippet": "s", "published_at": "2026-04-10"}
        out = _normalize_citation(raw)
        assert out["published_at"] == "2026-04-10"


class TestSearch:
    def test_search_happy_path_with_citations(self):
        captured = {}

        def fake_call(
            prompt,
            system=None,
            model=None,
            max_tokens=None,
            live_search=False,
            search_sources=None,
            **kwargs,
        ):
            captured["prompt"] = prompt
            captured["system"] = system
            captured["live_search"] = live_search
            captured["search_sources"] = search_sources
            return {
                "text": "Zenon Portal is in testnet. [1][2]",
                "cost_usd": 0.012,
                "input_tokens": 120,
                "output_tokens": 80,
                "model": "grok-4-fast-reasoning",
                "citations": [
                    {"url": "https://zenon.network/portal", "title": "Portal docs"},
                    "https://x.com/zenon/status/123",
                ],
                "num_sources_used": 2,
            }

        result = search("What's the status of the Zenon Portal bridge?", llm_call=fake_call)

        assert isinstance(result, SearchResult)
        assert captured["live_search"] is True
        assert "Zenon Portal" in result.text
        assert len(result.citations) == 2
        assert result.citations[0]["url"] == "https://zenon.network/portal"
        assert result.citations[1] == "https://x.com/zenon/status/123"
        assert result.num_sources_used == 2
        assert result.cost_usd == 0.012

    def test_search_custom_sources_passed_through(self):
        captured = {}

        def fake_call(prompt, **kwargs):
            captured.update(kwargs)
            return {
                "text": "",
                "cost_usd": 0.0,
                "input_tokens": 0,
                "output_tokens": 0,
                "model": "m",
                "citations": [],
            }

        search("q", sources=[{"type": "x"}], llm_call=fake_call)
        assert captured["search_sources"] == [{"type": "x"}]

    def test_search_returns_none_when_llm_call_fails(self):
        result = search("q", llm_call=lambda **kwargs: None)
        assert result is None

    def test_search_default_system_prompt_mentions_citations(self):
        captured = {}

        def fake_call(prompt, **kwargs):
            captured["system"] = kwargs.get("system")
            return {
                "text": "",
                "cost_usd": 0.0,
                "input_tokens": 0,
                "output_tokens": 0,
                "model": "m",
                "citations": [],
            }

        search("q", llm_call=fake_call)
        assert "citations" in (captured["system"] or "").lower()

    def test_search_empty_citations_handled(self):
        def fake_call(prompt, **kwargs):
            return {
                "text": "no sources found",
                "cost_usd": 0.001,
                "input_tokens": 10,
                "output_tokens": 5,
                "model": "m",
            }

        result = search("q", llm_call=fake_call)
        assert result is not None
        assert result.citations == []
