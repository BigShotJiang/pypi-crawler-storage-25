# SPDX-License-Identifier: MIT
"""v0.4.1 Phase D — pattern_discoverer engine tests.

Pins the two clue-detection paths (direct + indirect Satoshi-style)
and the engine's bounded-cost + graceful-degradation behavior.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence.schema import ensure_schema
from domains.investigation.engines import pattern_discoverer as pd

# ---------------------------------------------------------------------------
# Per-scanner tests: direct path
# ---------------------------------------------------------------------------


class TestDirectMarkers:
    """Explicit clue markers are detected."""

    def test_hash_comment_clue(self):
        content = "# Clue: the attacker can bypass the timelock at boundary\nx = 1\n"
        hits = pd._scan_direct_markers(content)
        assert len(hits) >= 1
        assert any(h["kind"] == "clue" for h in hits)
        assert any(h["confidence"] >= 0.70 for h in hits)

    def test_slash_comment_hint(self):
        content = "// Hint: look at the plasma cost calculation more carefully\n"
        hits = pd._scan_direct_markers(content)
        assert len(hits) >= 1
        assert any("plasma cost" in h["body"] for h in hits)

    def test_html_comment_note(self):
        content = "<!-- Note to readers: this is an open question -->\n"
        hits = pd._scan_direct_markers(content)
        assert any(h["kind"] == "note to readers" for h in hits)

    def test_yaml_hint_frontmatter(self):
        content = "hint: this spec intentionally leaves X unspecified\n"
        hits = pd._scan_direct_markers(content)
        assert any(h["kind"] == "yaml_hint" for h in hits)

    def test_community_section_heading(self):
        content = "# Intro\n\n## Open Questions\n\n- What about X?\n"
        hits = pd._scan_direct_markers(content)
        assert any(h["kind"] == "section_heading" for h in hits)

    def test_no_markers_returns_empty(self):
        content = "package main\n\nfunc Hello() {}\n"
        hits = pd._scan_direct_markers(content)
        assert hits == []


# ---------------------------------------------------------------------------
# Per-scanner tests: indirect (Satoshi-style) path
# ---------------------------------------------------------------------------


class TestIndirectPatterns:
    """Hidden patterns surface without semantic decoding."""

    def test_hex_decoding_to_english_flagged(self):
        # "hello zenon world" in hex
        # h=68 e=65 l=6c l=6c o=6f space=20 z=7a e=65 n=6e o=6f n=6e
        #   space=20 w=77 o=6f r=72 l=6c d=64
        content = "test_vector = 0x68656c6c6f207a656e6f6e20776f726c64\n"
        hits = pd._scan_indirect_patterns(content)
        assert len(hits) >= 1
        hex_hits = [h for h in hits if h["kind"] == "hex_to_ascii"]
        assert hex_hits
        assert "hello zenon" in hex_hits[0]["body"].lower()

    def test_random_hex_not_flagged(self):
        # Random hex that doesn't decode to ASCII
        content = "test_vector = 0xdeadbeefcafebabe1234567890abcdef\n"
        hits = pd._scan_indirect_patterns(content)
        hex_hits = [h for h in hits if h["kind"] == "hex_to_ascii"]
        assert len(hex_hits) == 0

    def test_base64_decoding_to_english_flagged(self):
        # "a message from the research team" in base64
        import base64

        msg = b"a message from the research team"
        encoded = base64.b64encode(msg).decode()
        content = f"payload = {encoded}\n"
        hits = pd._scan_indirect_patterns(content)
        b64_hits = [h for h in hits if h["kind"] == "base64_to_ascii"]
        assert len(b64_hits) >= 1

    def test_fibonacci_sequence_flagged(self):
        content = "values = [1, 2, 3, 5, 8, 13, 21, 34]\n"
        hits = pd._scan_indirect_patterns(content)
        fib_hits = [h for h in hits if h["kind"] == "fibonacci_sequence"]
        assert len(fib_hits) == 1
        assert fib_hits[0]["confidence"] < 0.6  # speculative

    def test_fibonacci_below_threshold_not_flagged(self):
        # Only 3 Fibonacci numbers — below the 4-hit threshold
        content = "values = [1, 2, 3, 99, 100]\n"
        hits = pd._scan_indirect_patterns(content)
        fib_hits = [h for h in hits if h["kind"] == "fibonacci_sequence"]
        assert len(fib_hits) == 0

    def test_pi_digits_embedded_flagged(self):
        content = 'encoded = "31415926535897932384"\n'
        hits = pd._scan_indirect_patterns(content)
        pi_hits = [h for h in hits if h["kind"] == "pi_digits_embedded"]
        assert len(pi_hits) == 1

    def test_bitcoin_genesis_timestamp_flagged(self):
        content = "timestamp = 1231006505\n"
        hits = pd._scan_indirect_patterns(content)
        sig_hits = [h for h in hits if "significant" in h["kind"]]
        assert len(sig_hits) >= 1
        assert "Bitcoin genesis" in sig_hits[0]["body"]

    def test_unrelated_numbers_not_flagged(self):
        content = "port = 8080\nmax_connections = 100\n"
        hits = pd._scan_indirect_patterns(content)
        assert len([h for h in hits if "significant" in h["kind"]]) == 0


# ---------------------------------------------------------------------------
# Decode helper tests
# ---------------------------------------------------------------------------


class TestDecodeHelpers:
    def test_decode_hex_to_ascii_rejects_too_short(self):
        # 4 bytes "test" - under _MIN_DECODED_LENGTH (6)
        assert pd._decode_hex_to_ascii("74657374") is None

    def test_decode_hex_to_ascii_accepts_printable(self):
        result = pd._decode_hex_to_ascii("68656c6c6f207a656e6f6e")
        assert result is not None
        assert "hello zenon" in result.lower()

    def test_decode_hex_rejects_non_printable(self):
        # Random binary
        assert pd._decode_hex_to_ascii("deadbeefcafebabe") is None

    def test_is_meaningful_decode_requires_telling_word_or_prose(self):
        assert pd._is_meaningful_decode("hello zenon research")
        assert not pd._is_meaningful_decode("a" * 20)  # no word or prose shape
        assert pd._is_meaningful_decode("this is a test message")


# ---------------------------------------------------------------------------
# Engine entry point + integration
# ---------------------------------------------------------------------------


@pytest.fixture
def fake_workspace_with_clues(tmp_path, monkeypatch):
    """Build a workspace with planted direct + indirect clues."""
    ws = tmp_path / "workspace"
    ws.mkdir()

    # Repo A: direct marker
    repo_a = ws / "repo-with-direct-clue"
    repo_a.mkdir()
    (repo_a / ".git").mkdir()
    (repo_a / "spec.md").write_text(
        "# Spec\n\n"
        "## Open Questions\n\n"
        "- How do we handle the expiry boundary?\n\n"
        "<!-- Clue: look at the reclaim path in htlc.go -->\n"
    )

    # Repo B: indirect pattern (hex decode)
    repo_b = ws / "repo-with-indirect-clue"
    repo_b.mkdir()
    (repo_b / ".git").mkdir()
    (repo_b / "test_vectors.go").write_text(
        "package test\n\nvar expected = 0x68656c6c6f207a656e6f6e20776f726c64\n"
    )

    monkeypatch.setattr(
        "domains.investigation.engines.pattern_discoverer.workspace_root",
        lambda: ws,
    )
    return ws


class TestEngineEntryPoint:
    def test_run_pattern_discoverer_is_discoverable(self):
        """Scheduler's zero-required-arg entry-point discovery finds it."""
        import inspect

        sig = inspect.signature(pd.run_pattern_discoverer)
        required_non_db = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty and p.name != "db_path"
        ]
        assert required_non_db == []

    def test_entry_point_name_matches_run_prefix(self):
        assert pd.run_pattern_discoverer.__name__.startswith("run_")


class TestEngineIntegration:
    def test_happy_path_finds_both_clue_types(self, fake_workspace_with_clues, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        result = pd.run_pattern_discoverer(db_path=db, max_repos=5, max_files_per_repo=20)

        assert result["repos_scanned"] >= 1
        assert result["files_scanned"] >= 1
        assert result["direct_hits"] + result["indirect_hits"] >= 1
        assert result["findings_persisted"] >= 1

    def test_persisted_findings_have_full_body(self, fake_workspace_with_clues, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        pd.run_pattern_discoverer(db_path=db, max_repos=5, max_files_per_repo=20)

        conn = sqlite3.connect(db)
        rows = conn.execute(
            "SELECT finding, evidence_type, confidence, source_file, source_line "
            "FROM evidence WHERE engine = 'pattern_discoverer'"
        ).fetchall()
        conn.close()

        assert len(rows) >= 1
        for body, ev_type, conf, source_file, source_line in rows:
            assert "WHAT:" in body
            assert "SO WHAT:" in body
            assert "NOW WHAT:" in body
            assert ev_type.startswith("pattern_")
            assert 0.3 <= conf <= 0.9
            assert source_file is not None
            assert source_line is not None and source_line > 0

    def test_direct_markers_have_higher_confidence_than_indirect(
        self, fake_workspace_with_clues, tmp_path
    ):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        pd.run_pattern_discoverer(db_path=db, max_repos=5, max_files_per_repo=20)

        conn = sqlite3.connect(db)
        rows = conn.execute(
            "SELECT evidence_type, confidence FROM evidence WHERE engine = 'pattern_discoverer'"
        ).fetchall()
        conn.close()

        direct_confidences: list[float] = []
        indirect_confidences: list[float] = []
        for ev_type, conf in rows:
            if ev_type in (
                "pattern_clue",
                "pattern_hint",
                "pattern_section_heading",
                "pattern_yaml_hint",
            ):
                direct_confidences.append(conf)
            elif (
                ev_type.startswith("pattern_hex")
                or ev_type.startswith("pattern_base64")
                or ev_type.startswith("pattern_fibonacci")
                or ev_type.startswith("pattern_pi")
            ):
                indirect_confidences.append(conf)

        if direct_confidences and indirect_confidences:
            assert max(direct_confidences) > max(indirect_confidences)

    def test_workspace_missing_returns_empty(self, tmp_path, monkeypatch):
        with patch(
            "domains.investigation.engines.pattern_discoverer.workspace_root",
            return_value=None,
        ):
            result = pd.run_pattern_discoverer(db_path=str(tmp_path / "x.db"))
        assert result["repos_scanned"] == 0
        assert result["workspace_root"] is None
