# SPDX-License-Identifier: MIT
"""Tests for core.domain_registry -- DomainPlugin ABC and DomainRegistry singleton."""

import pytest

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    DomainRegistry,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

# -- Mock domain plugin --


class MockDomain(DomainPlugin):
    """Minimal concrete domain for testing."""

    def __init__(self, domain_name: str = "mock", priority: int = 5):
        self._name = domain_name
        self._priority = priority
        self.on_register_called = False
        self.received_findings: list[dict] = []

    def name(self) -> str:
        return self._name

    def get_engines(self) -> list[EngineDefinition]:
        return [
            EngineDefinition(
                name=f"{self._name}_engine",
                description="A test engine",
                module_path=f"domains.{self._name}.engine",
                priority=3,
                tier=2,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        return [
            HypothesisType(
                type_id=f"{self._name}_hyp",
                label="Test hypothesis",
                description="For testing",
                initial_confidence=0.1,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        return [
            AspirationType(
                type_id=f"{self._name}_asp",
                label="Test aspiration",
                description="For testing",
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        return [
            CollisionSignal(
                signal_id=f"{self._name}_signal",
                label="Test signal",
                description="For testing",
                source_domains=[self._name],
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        return [
            WarRoomContribution(
                domain=self._name,
                section_title=f"{self._name} Report",
                metrics=["metric_a"],
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        return {"accuracy": 0.95}

    def decide_next_action(self, context: dict) -> dict | None:
        return {
            "action": "test_action",
            "reason": "testing",
            "priority": self._priority,
            "engine": f"{self._name}_engine",
        }

    def get_db_schema_sql(self) -> str:
        return f"-- {self._name} schema placeholder"

    def get_priority(self) -> int:
        return self._priority

    def on_register(self) -> None:
        self.on_register_called = True

    def on_finding(self, finding: dict) -> None:
        self.received_findings.append(finding)


@pytest.fixture(autouse=True)
def reset_registry():
    """Reset the singleton before each test."""
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestDomainPluginABC:
    def test_cannot_instantiate_abc(self):
        with pytest.raises(TypeError):
            DomainPlugin()

    def test_mock_implements_all_methods(self):
        d = MockDomain()
        assert d.name() == "mock"
        assert len(d.get_engines()) == 1
        assert len(d.get_hypothesis_types()) == 1
        assert len(d.get_aspiration_types()) == 1
        assert len(d.get_collision_signals()) == 1
        assert len(d.get_war_room_contributions()) == 1
        assert d.get_self_improvement_metrics()["accuracy"] == 0.95
        assert d.decide_next_action({}) is not None
        assert isinstance(d.get_db_schema_sql(), str)

    def test_default_description(self):
        d = MockDomain("alpha")
        assert "alpha" in d.get_description()

    def test_default_status(self):
        d = MockDomain()
        status = d.get_status()
        assert status["domain"] == "mock"
        assert status["engines"] == 1
        assert status["enabled_engines"] == 1


class TestDomainRegistry:
    def test_singleton_identity(self):
        r1 = DomainRegistry.instance()
        r2 = DomainRegistry.instance()
        assert r1 is r2

    def test_register_and_get_domain(self):
        reg = DomainRegistry.instance()
        d = MockDomain("test")
        reg.register(d)
        assert reg.get_domain("test") is d
        assert d.on_register_called

    def test_duplicate_registration_raises(self):
        reg = DomainRegistry.instance()
        reg.register(MockDomain("dup"))
        with pytest.raises(ValueError, match="already registered"):
            reg.register(MockDomain("dup"))

    def test_unregister(self):
        reg = DomainRegistry.instance()
        d = MockDomain("removable")
        reg.register(d)
        removed = reg.unregister("removable")
        assert removed is d
        assert reg.get_domain("removable") is None

    def test_unregister_nonexistent_returns_none(self):
        reg = DomainRegistry.instance()
        assert reg.unregister("ghost") is None

    def test_get_domain_names(self):
        reg = DomainRegistry.instance()
        reg.register(MockDomain("aaa"))
        reg.register(MockDomain("bbb"))
        names = reg.get_domain_names()
        assert "aaa" in names
        assert "bbb" in names

    def test_all_domains_sorted_by_priority(self):
        reg = DomainRegistry.instance()
        reg.register(MockDomain("low", priority=10))
        reg.register(MockDomain("high", priority=1))
        reg.register(MockDomain("mid", priority=5))
        domains = reg.get_all_domains()
        priorities = [d.get_priority() for d in domains]
        assert priorities == sorted(priorities)

    def test_all_engines_aggregated(self):
        reg = DomainRegistry.instance()
        reg.register(MockDomain("d1"))
        reg.register(MockDomain("d2"))
        engines = reg.get_all_engines()
        assert len(engines) == 2
        names = {e.name for e in engines}
        assert "d1_engine" in names
        assert "d2_engine" in names

    def test_all_hypothesis_types(self):
        reg = DomainRegistry.instance()
        reg.register(MockDomain("d1"))
        types = reg.get_all_hypothesis_types()
        assert len(types) == 1
        assert types[0].type_id == "d1_hyp"

    def test_all_collision_signals(self):
        reg = DomainRegistry.instance()
        reg.register(MockDomain("d1"))
        reg.register(MockDomain("d2"))
        signals = reg.get_all_collision_signals()
        assert len(signals) == 2

    def test_all_war_room_contributions(self):
        reg = DomainRegistry.instance()
        reg.register(MockDomain("d1"))
        contribs = reg.get_all_war_room_contributions()
        assert len(contribs) == 1
        assert contribs[0].domain == "d1"

    def test_decide_next_action_picks_highest_priority(self):
        reg = DomainRegistry.instance()
        reg.register(MockDomain("slow", priority=10))
        reg.register(MockDomain("fast", priority=1))
        action = reg.decide_next_action({})
        assert action is not None
        assert action["domain"] == "fast"
        assert action["priority"] == 1

    def test_decide_next_action_empty_registry(self):
        reg = DomainRegistry.instance()
        assert reg.decide_next_action({}) is None

    def test_broadcast_finding(self):
        reg = DomainRegistry.instance()
        d1 = MockDomain("listener1")
        d2 = MockDomain("listener2")
        reg.register(d1)
        reg.register(d2)
        finding = {"id": 1, "text": "test finding"}
        reg.broadcast_finding(finding)
        assert len(d1.received_findings) == 1
        assert d1.received_findings[0]["text"] == "test finding"
        assert len(d2.received_findings) == 1

    def test_combined_schema_sql(self):
        reg = DomainRegistry.instance()
        reg.register(MockDomain("d1"))
        sql = reg.get_combined_schema_sql()
        assert "d1" in sql

    def test_system_status(self):
        reg = DomainRegistry.instance()
        reg.register(MockDomain("d1"))
        reg.register(MockDomain("d2"))
        status = reg.get_system_status()
        assert status["total_domains"] == 2
        assert status["total_engines"] == 2
        assert "d1" in status["domains"]
        assert "d2" in status["domains"]
