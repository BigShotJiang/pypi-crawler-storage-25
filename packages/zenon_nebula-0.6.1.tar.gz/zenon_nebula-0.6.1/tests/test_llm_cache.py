# SPDX-License-Identifier: MIT
"""Tests for the application-level LLM prompt cache (Phase 15)."""

from __future__ import annotations

import time
from unittest.mock import patch

from core import llm_cache


def _seed(db_path, ttl=llm_cache.DEFAULT_TTL_SECONDS):
    key = llm_cache.make_cache_key(
        prompt="hello",
        system="sys",
        model="grok-4-fast-reasoning",
        max_tokens=1000,
        temperature=1.0,
        json_output=False,
    )
    result = {
        "text": "cached answer",
        "cost_usd": 0.0012,
        "input_tokens": 50,
        "output_tokens": 120,
        "model": "grok-4-fast-reasoning",
    }
    llm_cache.store(key, result, prompt_preview="hello", db_path=db_path)
    return key


class TestMakeCacheKey:
    def test_deterministic(self):
        k1 = llm_cache.make_cache_key(
            prompt="p",
            system="s",
            model="m",
            max_tokens=100,
            temperature=0.5,
            json_output=False,
        )
        k2 = llm_cache.make_cache_key(
            prompt="p",
            system="s",
            model="m",
            max_tokens=100,
            temperature=0.5,
            json_output=False,
        )
        assert k1 == k2

    def test_changes_with_prompt(self):
        base = {
            "system": "",
            "model": "m",
            "max_tokens": 100,
            "temperature": 0.5,
            "json_output": False,
        }
        k1 = llm_cache.make_cache_key(prompt="a", **base)
        k2 = llm_cache.make_cache_key(prompt="b", **base)
        assert k1 != k2

    def test_changes_with_temperature(self):
        base = {
            "prompt": "p",
            "system": "",
            "model": "m",
            "max_tokens": 100,
            "json_output": False,
        }
        k1 = llm_cache.make_cache_key(temperature=0.0, **base)
        k2 = llm_cache.make_cache_key(temperature=1.0, **base)
        assert k1 != k2

    def test_changes_with_json_output_flag(self):
        base = {"prompt": "p", "system": "", "model": "m", "max_tokens": 100, "temperature": 0.5}
        k1 = llm_cache.make_cache_key(json_output=False, **base)
        k2 = llm_cache.make_cache_key(json_output=True, **base)
        assert k1 != k2


class TestLookupAndStore:
    def test_store_then_lookup_returns_hit(self, db_path):
        key = _seed(db_path)
        result = llm_cache.lookup(key, db_path=db_path)
        assert result is not None
        assert result["text"] == "cached answer"
        assert result["cached"] is True
        assert result["cost_usd"] == 0.0  # no new api cost on hit
        assert result["cached_cost_saved_usd"] == 0.0012

    def test_lookup_miss_returns_none(self, db_path):
        assert llm_cache.lookup("nonexistent", db_path=db_path) is None

    def test_lookup_with_zero_ttl_skips_cache(self, db_path):
        key = _seed(db_path)
        assert llm_cache.lookup(key, ttl_seconds=0, db_path=db_path) is None

    def test_hit_counter_increments(self, db_path):
        key = _seed(db_path)
        llm_cache.lookup(key, db_path=db_path)
        llm_cache.lookup(key, db_path=db_path)
        llm_cache.lookup(key, db_path=db_path)
        s = llm_cache.stats(db_path=db_path)
        # 1 from store + 3 from lookups (the store sets hit_count=1,
        # each lookup bumps to 2, 3, 4)
        assert s["total_hits"] >= 3

    def test_stale_entry_returns_none(self, db_path):
        key = _seed(db_path)
        # Force staleness by shrinking TTL below any positive age.
        time.sleep(0.05)
        assert llm_cache.lookup(key, ttl_seconds=0, db_path=db_path) is None


class TestStats:
    def test_empty_cache_stats(self, db_path):
        s = llm_cache.stats(db_path=db_path)
        assert s["entries"] == 0
        assert s["total_hits"] == 0
        assert s["estimated_saved_usd"] == 0.0

    def test_populated_cache_stats(self, db_path):
        key = _seed(db_path)
        llm_cache.lookup(key, db_path=db_path)
        llm_cache.lookup(key, db_path=db_path)
        s = llm_cache.stats(db_path=db_path)
        assert s["entries"] == 1
        # initial store = hit_count 1; two lookups = hit_count 3
        assert s["total_hits"] == 3
        # estimated_saved_usd = cost_usd * (hit_count - 1) = 0.0012 * 2
        assert s["estimated_saved_usd"] == 0.0024


class TestPurge:
    def test_purge_all(self, db_path):
        _seed(db_path)
        assert llm_cache.stats(db_path=db_path)["entries"] == 1
        deleted = llm_cache.purge(db_path=db_path)
        assert deleted == 1
        assert llm_cache.stats(db_path=db_path)["entries"] == 0

    def test_purge_recent_no_op(self, db_path):
        _seed(db_path)
        # Purging rows older than an hour should leave a fresh entry alone
        deleted = llm_cache.purge(db_path=db_path, older_than_seconds=3600)
        assert deleted == 0
        assert llm_cache.stats(db_path=db_path)["entries"] == 1


class TestIntegrationWithCallLLM:
    def test_call_llm_uses_cache_on_repeat(self, db_path, monkeypatch):
        """Second identical call_llm invocation should hit the cache."""
        from core import llm_provider

        monkeypatch.setenv("XAI_API_KEY", "test-key")

        # Patch core.persistence to use db_path as the default so the
        # cache helpers route there automatically.
        monkeypatch.setattr(llm_cache, "DEFAULT_DB", db_path)

        call_count = {"n": 0}

        def fake_urlopen(req, timeout=120):
            call_count["n"] += 1

            class FakeResp:
                def read(self):
                    import json as _json

                    return _json.dumps(
                        {
                            "choices": [{"message": {"content": "test answer"}}],
                            "usage": {"prompt_tokens": 10, "completion_tokens": 5},
                        }
                    ).encode()

            return FakeResp()

        with patch("urllib.request.urlopen", fake_urlopen):
            a = llm_provider.call_llm(prompt="unique-prompt-xyz", model="grok-4-fast-reasoning")
            b = llm_provider.call_llm(prompt="unique-prompt-xyz", model="grok-4-fast-reasoning")

        assert a is not None and b is not None
        assert a["text"] == "test answer"
        assert b["text"] == "test answer"
        # Only the first call should have hit the network
        assert call_count["n"] == 1
        assert b.get("cached") is True

    def test_call_llm_skips_cache_when_ttl_zero(self, db_path, monkeypatch):
        from core import llm_provider

        monkeypatch.setenv("XAI_API_KEY", "test-key")
        monkeypatch.setattr(llm_cache, "DEFAULT_DB", db_path)

        calls = {"n": 0}

        def fake_urlopen(req, timeout=120):
            calls["n"] += 1

            class FakeResp:
                def read(self):
                    import json as _json

                    return _json.dumps(
                        {
                            "choices": [{"message": {"content": "fresh"}}],
                            "usage": {"prompt_tokens": 1, "completion_tokens": 1},
                        }
                    ).encode()

            return FakeResp()

        with patch("urllib.request.urlopen", fake_urlopen):
            llm_provider.call_llm(prompt="p", cache_ttl_seconds=0)
            llm_provider.call_llm(prompt="p", cache_ttl_seconds=0)

        # Both calls should hit the network — cache bypassed
        assert calls["n"] == 2
