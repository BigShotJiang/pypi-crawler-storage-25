# SPDX-License-Identifier: MIT
"""Layer 2 of the v0.5.0 layered attack-vector framework (task #47).

Greps the codebase for risky patterns with an allowlist. Catches the
obvious classes of attack surface automatically on every test run so
reviewers don't have to spot them by hand.

The patterns:
- `subprocess.run` without `timeout=` — command hang → scheduler lockup
- `urlopen` without `timeout=` — network hang → scheduler lockup
- `eval(` / `exec(` — arbitrary code execution
- `pickle.loads(` — deserialization RCE
- `shell=True` — command injection surface
- `yaml.load(` without `Loader=` — yaml RCE in older PyYAML versions
- SQL built with `+` string concatenation on user input — injection

Each pattern has a dedicated allowlist. Every allowlist entry needs a
comment explaining why the pattern is safe in that specific context.
The allowlist SHRINKS over time as the code gets cleaner; it never
grows without reviewer agreement.

When this test fails, the fix is either:
1. Tighten the use site (add timeout, use safe variant, sanitize input)
2. Add the use site to the allowlist with a one-line justification
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))


def _scan_files(*, exts: tuple[str, ...] = (".py",)) -> list[Path]:
    """Return every source file to scan."""
    roots = [ENGINE_ROOT / "core", ENGINE_ROOT / "domains", ENGINE_ROOT / "scripts"]
    files: list[Path] = []
    for root in roots:
        for path in root.rglob("*"):
            if any(part.startswith(".") or part == "__pycache__" for part in path.parts):
                continue
            if path.suffix in exts:
                files.append(path)
    return files


def _read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


# ---------------------------------------------------------------------------
# Pattern 1: subprocess.run without timeout
# ---------------------------------------------------------------------------

# Matches the START of a subprocess.run call. The body is extracted
# via a balanced-paren scan in _extract_call_body below — a naive
# `[^)]*` regex would stop at the first nested `)` (e.g., inside
# `cwd=str(repo_path)`) and wrongly declare the call timeout-less.
_SUBPROCESS_RUN_START_RE = re.compile(r"\bsubprocess\.run\s*\(")


def _extract_call_body(content: str, open_paren_idx: int) -> str:
    """Return the substring inside a balanced `(...)` starting at open_paren_idx.

    Handles nested parens + string literals with single/double/triple
    quotes. Returns empty string on mismatched parens (treats the
    call as body-less so the caller fails safe).
    """
    depth = 0
    i = open_paren_idx
    n = len(content)
    in_string: str | None = None
    body_start = -1

    while i < n:
        ch = content[i]
        if in_string:
            if ch == "\\" and i + 1 < n:
                i += 2
                continue
            if content[i : i + 3] == in_string:
                in_string = None
                i += 3
                continue
            if ch == in_string and len(in_string) == 1:
                in_string = None
        else:
            if content[i : i + 3] in ('"""', "'''"):
                in_string = content[i : i + 3]
                i += 3
                continue
            if ch in ('"', "'"):
                in_string = ch
            elif ch == "(":
                depth += 1
                if depth == 1:
                    body_start = i + 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    return content[body_start:i] if body_start >= 0 else ""
        i += 1
    return ""


# Allowlist for subprocess.run uses where timeout isn't applicable or
# the call site is already bounded by external means. Each entry is
# (relative_path, one-line justification).
SUBPROCESS_NO_TIMEOUT_ALLOWLIST: set[str] = {
    # Development-only scripts that are not in the autonomous loop
    "scripts/release.py",
    "scripts/update.py",
    "scripts/diagnose.py",
    "scripts/audit_architecture.py",
    "scripts/opsec_audit.py",
    "scripts/inspect_db.py",
    "scripts/generate_dep_graph.py",
    "scripts/regen_docs.py",
    "scripts/generate_lockfile.py",
    "scripts/add_license_headers.py",
    "scripts/new_engine.py",
    "scripts/nebula_cli.py",
    "scripts/pre_commit_checks.py",
}


def _subprocess_call_has_timeout(call_body: str) -> bool:
    """Return True if a subprocess.run(...) call string has timeout=."""
    return "timeout=" in call_body or "timeout =" in call_body


def test_subprocess_run_always_has_timeout_in_autonomous_paths():
    """Every subprocess.run in core/ or domains/ must have timeout=."""
    bad: list[str] = []
    for path in _scan_files():
        rel = str(path.relative_to(ENGINE_ROOT))
        if rel in SUBPROCESS_NO_TIMEOUT_ALLOWLIST:
            continue
        if not (rel.startswith("core/") or rel.startswith("domains/")):
            continue
        content = _read(path)
        for match in _SUBPROCESS_RUN_START_RE.finditer(content):
            # Position of the `(` after `subprocess.run`
            paren_idx = content.find("(", match.end() - 1)
            if paren_idx < 0:
                continue
            body = _extract_call_body(content, paren_idx)
            if not _subprocess_call_has_timeout(body):
                line = content[: match.start()].count("\n") + 1
                bad.append(f"{rel}:{line}")

    assert not bad, (
        "subprocess.run without timeout= in autonomous code paths "
        "(hang risk for the scheduler):\n  " + "\n  ".join(bad) + "\n\n"
        "Fix: add `timeout=N` to the call. If you have a legitimate "
        "reason to skip the timeout, add the file path to "
        "SUBPROCESS_NO_TIMEOUT_ALLOWLIST with a one-line justification."
    )


# ---------------------------------------------------------------------------
# Pattern 2: urlopen without timeout
# ---------------------------------------------------------------------------

_URLOPEN_RE = re.compile(r"\burlopen\s*\(([^)]*)\)", re.DOTALL)


URLOPEN_NO_TIMEOUT_ALLOWLIST: set[str] = {
    # These files route through opsec_urlopen which enforces its own
    # timeout — the wrapper is the enforcement point.
    "core/opsec.py",
}


def test_urlopen_always_has_timeout_in_autonomous_paths():
    """Every urlopen call must specify timeout= (or be behind opsec_urlopen)."""
    bad: list[str] = []
    for path in _scan_files():
        rel = str(path.relative_to(ENGINE_ROOT))
        if rel in URLOPEN_NO_TIMEOUT_ALLOWLIST:
            continue
        content = _read(path)
        # Skip files that only call opsec_urlopen (the wrapper enforces timeout)
        if "opsec_urlopen" in content and "urllib.request.urlopen" not in content:
            continue
        for match in _URLOPEN_RE.finditer(content):
            body = match.group(1)
            if "timeout" not in body:
                line = content[: match.start()].count("\n") + 1
                bad.append(f"{rel}:{line}")

    assert not bad, (
        "urlopen without timeout= (network hang risk):\n  "
        + "\n  ".join(bad)
        + "\n\nFix: add `timeout=N` or route via opsec_urlopen."
    )


# ---------------------------------------------------------------------------
# Pattern 3: eval / exec
# ---------------------------------------------------------------------------

_EVAL_RE = re.compile(r"\beval\s*\(")
_EXEC_RE = re.compile(r"\bexec\s*\(")

EVAL_EXEC_ALLOWLIST: set[str] = {
    # None currently — if you need eval/exec, you need a reviewer.
}


def test_no_eval_or_exec_in_autonomous_paths():
    """eval() and exec() are banned in core/ and domains/."""
    bad: list[str] = []
    for path in _scan_files():
        rel = str(path.relative_to(ENGINE_ROOT))
        if not (rel.startswith("core/") or rel.startswith("domains/")):
            continue
        if rel in EVAL_EXEC_ALLOWLIST:
            continue
        content = _read(path)
        for pattern_re, name in ((_EVAL_RE, "eval"), (_EXEC_RE, "exec")):
            for match in pattern_re.finditer(content):
                # Skip common false positives
                before = content[max(0, match.start() - 10) : match.start()]
                if before.endswith(("_", ".", "y")):
                    # y_eval, _eval, json.eval_...
                    continue
                line = content[: match.start()].count("\n") + 1
                bad.append(f"{rel}:{line} [{name}()]")

    assert not bad, (
        "eval() or exec() found in autonomous code (RCE risk):\n  "
        + "\n  ".join(bad)
        + "\n\nFix: use ast.literal_eval for data, or refactor to "
        "avoid dynamic code execution."
    )


# ---------------------------------------------------------------------------
# Pattern 4: pickle.loads
# ---------------------------------------------------------------------------

_PICKLE_LOADS_RE = re.compile(r"\bpickle\.loads?\s*\(")

PICKLE_ALLOWLIST: set[str] = {
    # None currently.
}


def test_no_pickle_in_autonomous_paths():
    """pickle.loads is a deserialization RCE — banned."""
    bad: list[str] = []
    for path in _scan_files():
        rel = str(path.relative_to(ENGINE_ROOT))
        if not (rel.startswith("core/") or rel.startswith("domains/")):
            continue
        if rel in PICKLE_ALLOWLIST:
            continue
        content = _read(path)
        for match in _PICKLE_LOADS_RE.finditer(content):
            line = content[: match.start()].count("\n") + 1
            bad.append(f"{rel}:{line}")

    assert not bad, (
        "pickle.loads found in autonomous code (deserialization RCE "
        "risk):\n  " + "\n  ".join(bad) + "\n\nFix: use json for data "
        "interchange."
    )


# ---------------------------------------------------------------------------
# Pattern 5: shell=True in subprocess
# ---------------------------------------------------------------------------

_SHELL_TRUE_RE = re.compile(r"shell\s*=\s*True")


def _strip_docstrings_and_comments(content: str) -> str:
    """Remove triple-quoted strings and # comments so bans only apply
    to executable code. Docstrings can legitimately MENTION banned
    patterns when explaining why they're banned (see
    pr_description_gen._run_git docstring referencing
    `shell=True`)."""
    stripped = re.sub(r'""".*?"""', "", content, flags=re.DOTALL)
    stripped = re.sub(r"'''.*?'''", "", stripped, flags=re.DOTALL)
    stripped = re.sub(r"#.*$", "", stripped, flags=re.MULTILINE)
    return stripped


def test_no_shell_true_in_subprocess_calls():
    """shell=True is command-injection-shaped surface area."""
    bad: list[str] = []
    for path in _scan_files():
        rel = str(path.relative_to(ENGINE_ROOT))
        if not (rel.startswith("core/") or rel.startswith("domains/")):
            continue
        content = _strip_docstrings_and_comments(_read(path))
        for match in _SHELL_TRUE_RE.finditer(content):
            line = content[: match.start()].count("\n") + 1
            bad.append(f"{rel}:{line}")

    assert not bad, (
        "shell=True found in subprocess calls (command injection "
        "surface):\n  " + "\n  ".join(bad) + "\n\nFix: pass the "
        "command as a list, not a string."
    )


# ---------------------------------------------------------------------------
# Pattern 6: yaml.load without Loader
# ---------------------------------------------------------------------------

_YAML_LOAD_RE = re.compile(r"\byaml\.load\s*\(([^)]*)\)", re.DOTALL)


def test_yaml_load_always_has_loader():
    """yaml.load without Loader= is an RCE surface in older PyYAML."""
    bad: list[str] = []
    for path in _scan_files():
        rel = str(path.relative_to(ENGINE_ROOT))
        content = _read(path)
        for match in _YAML_LOAD_RE.finditer(content):
            body = match.group(1)
            if "Loader" not in body:
                line = content[: match.start()].count("\n") + 1
                bad.append(f"{rel}:{line}")

    assert not bad, (
        "yaml.load without Loader= (RCE risk in older PyYAML):\n  "
        + "\n  ".join(bad)
        + "\n\nFix: use yaml.safe_load or pass Loader=yaml.SafeLoader."
    )


# ---------------------------------------------------------------------------
# Pattern 7: __import__ with dynamic input
# ---------------------------------------------------------------------------

_DYNAMIC_IMPORT_RE = re.compile(r"__import__\s*\([^)]*[+%f]")


def test_no_dynamic_import_from_string_concat():
    """__import__ built from string concatenation is a code-loading risk."""
    bad: list[str] = []
    for path in _scan_files():
        rel = str(path.relative_to(ENGINE_ROOT))
        if not (rel.startswith("core/") or rel.startswith("domains/")):
            continue
        content = _read(path)
        for match in _DYNAMIC_IMPORT_RE.finditer(content):
            line = content[: match.start()].count("\n") + 1
            bad.append(f"{rel}:{line}")

    assert not bad, (
        "__import__ built from dynamic string (code-loading risk):\n  "
        + "\n  ".join(bad)
        + "\n\nFix: use importlib.import_module with a literal "
        "or an explicit allowlist."
    )
