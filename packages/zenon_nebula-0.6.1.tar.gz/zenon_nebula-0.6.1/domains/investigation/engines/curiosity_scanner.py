# SPDX-License-Identifier: MIT
"""
CuriosityScanner -- Wrap core.curiosity.CuriosityEngine and publish findings.

The CuriosityEngine in `core/curiosity.py` has shipped for several versions
with all the machinery for exploration (random sampling, cross-repo pattern
search, per-repo staleness tracking, INTERESTING_PATTERNS keyword list) but
no engine in any domain actually called it — the autonomous loop never ran
it, its output never reached the evidence table, and the "curiosity engines
naturally discover clues" story was aspirational. This module is the thin
wrapper that turns that dead library into a live scheduled engine.

What it does each cycle:

1. Asks CuriosityEngine for the most-stale repos (staleness = "we haven't
   sampled it in >7 days") and picks one to explore.
2. Random-samples a handful of source-code files from that repo, prioritizing
   Go / Dart / Rust / Solidity / Python (via `PRIORITY_EXTENSIONS`).
3. Grep each sampled file for the curated `INTERESTING_PATTERNS` list —
   these are the suggestive keywords a researcher would drop as a clue
   (`satoshi`, `schnorr`, `taproot`, `experimental`, `untested`, `TODO`,
   `HACK`, etc.) plus core Zenon concepts worth re-examining (`plasma`,
   `sentinel`, `spork`, `accelerator`).
4. For every match: emit a finding with the WHAT/SO WHAT/NOW WHAT split,
   full provenance (source_repo/source_file/source_commit/source_line),
   and a clickable GitHub permalink so the community can jump straight
   to the line. Confidence is deliberately medium (0.55) — curiosity is
   speculative, and the hypothesis hardener promotes only the ones that
   corroborate with other engines.

The engine is the first load-bearing path for the clue-dropping channel
the external Nebula story depends on. It's also a good test case for the
v0.3.1 scheduler rotation fix: curiosity_scanner is a second engine in the
investigation domain, so its firing confirms the domain isn't stuck on
architecture_analyzer alone.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from core.curiosity import INTERESTING_PATTERNS, CuriosityEngine
from core.git_cache import get_repo_head, get_repo_identity
from core.persistence.findings import persist_finding
from core.persistence.schema import DEFAULT_DB
from core.workspace import workspace_root

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]

# We cap sample + scan sizes so a single cycle stays fast (< 5s on a
# cold workspace). Tuned against the live Zenon workspace (~160 repos,
# ~3M LOC) -- sampling 8 files across 3 stale repos per cycle surfaces
# 2-5 clue candidates on average without thrashing the filesystem.
MAX_REPOS_PER_CYCLE = 3
MAX_FILES_PER_REPO = 8
MAX_BYTES_PER_FILE = 256 * 1024  # skip huge generated files
MAX_MATCHES_PER_FILE = 3  # don't flood on files that naturally contain the pattern


# Pre-compile the interesting-patterns regex once at module load. Each
# pattern is matched case-insensitively with word boundaries so `plasma`
# matches in `plasma-txpool` but not in `displasma`. Compiled here rather
# than inside the hot loop because the autonomous runner may call this
# engine every cycle and regex compilation in Python isn't free at scale.
_PATTERN_RE = re.compile(
    r"\b(" + "|".join(re.escape(p) for p in INTERESTING_PATTERNS) + r")\b",
    re.IGNORECASE,
)


def _build_github_url(
    repo_identity: str | None,
    rel_path: str,
    line: int,
    commit: str,
) -> str | None:
    """Build a clickable GitHub permalink for a file + line.

    Returns None when we can't resolve a repo identity we're confident
    about — we'd rather omit the URL than invent one. Format matches
    the adversarial_reviewer + spec_audit permalink style so the
    community sees consistent links across engines.
    """
    if not repo_identity or "/" not in repo_identity:
        return None
    ref = commit or "main"
    encoded = rel_path.replace(" ", "%20")
    url = f"https://github.com/{repo_identity}/blob/{ref}/{encoded}"
    if line > 0:
        url = f"{url}#L{line}"
    return url


def _scan_file_for_patterns(
    file_path: Path,
    repo_path: Path,
    repo_identity: str | None,
    commit: str,
) -> list[dict[str, Any]]:
    """Read a file and emit one finding dict per interesting-pattern hit.

    Caps MAX_MATCHES_PER_FILE hits per file so files that naturally
    contain a keyword (e.g., a PTLC test file with 100x `point_lock`)
    don't drown the evidence table. The caller deduplicates across
    cycles via the engine+type+finding key in persist_finding.
    """
    try:
        if not file_path.is_file() or file_path.stat().st_size > MAX_BYTES_PER_FILE:
            return []
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    findings: list[dict[str, Any]] = []
    seen_patterns: set[str] = set()

    for match in _PATTERN_RE.finditer(content):
        pattern = match.group(1).lower()
        if pattern in seen_patterns:
            continue
        seen_patterns.add(pattern)

        line_no = content.count("\n", 0, match.start()) + 1
        try:
            rel_path = str(file_path.relative_to(repo_path))
        except ValueError:
            rel_path = file_path.name

        snippet_start = content.rfind("\n", 0, match.start()) + 1
        snippet_end = content.find("\n", match.end())
        if snippet_end == -1:
            snippet_end = len(content)
        snippet = content[snippet_start:snippet_end].strip()
        if len(snippet) > 200:
            snippet = snippet[:197] + "..."

        url = _build_github_url(repo_identity, rel_path, line_no, commit)

        findings.append(
            {
                "pattern": pattern,
                "rel_path": rel_path,
                "line": line_no,
                "snippet": snippet,
                "verification_url": url,
            }
        )

        if len(findings) >= MAX_MATCHES_PER_FILE:
            break

    return findings


def _format_finding(
    repo_name: str,
    rel_path: str,
    line: int,
    pattern: str,
    snippet: str,
) -> str:
    """Render the WHAT / SO WHAT / NOW WHAT body for a single hit.

    The format is identical to adversarial_reviewer + spec_audit so the
    community sees one consistent finding shape across engines. The
    prose deliberately frames the hit as "worth a second look" rather
    than "this is a bug" — curiosity is exploration, not judgment.
    """
    return (
        f"WHAT: Random sample of `{repo_name}/{rel_path}` line {line} "
        f"matched the curiosity keyword `{pattern}`. Context: "
        f"`{snippet}`. "
        f"SO WHAT: The curiosity engine surfaces code that hasn't been "
        f"re-examined recently and mentions concepts worth revisiting "
        f"(core Zenon primitives, cryptographic building blocks, "
        f"experimental markers). Random sampling over a stale corpus "
        f"is the most cost-effective way to find clues that no targeted "
        f"engine was specifically looking for — including clues a "
        f"researcher may have dropped deliberately for the community to "
        f"discover. "
        f"NOW WHAT: Click the permalink to read the surrounding context. "
        f"If the match looks intentional (new primitive, spec hint, "
        f"unexpected comment), raise it in the weekly review. If it's "
        f"routine code, the finding will fall out of relevance as the "
        f"hypothesis engine fails to corroborate it with other signals."
    )


def run_curiosity_scan(
    db_path: str = DEFAULT_DB,
    *,
    max_repos: int = MAX_REPOS_PER_CYCLE,
    max_files_per_repo: int = MAX_FILES_PER_REPO,
) -> dict[str, Any]:
    """Entry point: run one curiosity sweep over the stalest repos.

    Degrades gracefully if the workspace isn't installed: logs once and
    returns an empty result rather than crashing the scheduler.

    Args:
        db_path: SQLite DB to persist findings to.
        max_repos: How many repos to sample this cycle.
        max_files_per_repo: How many files to sample per repo.

    Returns:
        Summary dict with ``repos_scanned``, ``files_sampled``,
        ``findings_persisted``, and ``workspace_root`` so the scheduler
        + CLI can surface what the engine did.
    """
    ws = workspace_root()
    if ws is None:
        logger.info("curiosity_scanner: workspace not installed; skipping")
        return {
            "repos_scanned": 0,
            "files_sampled": 0,
            "findings_persisted": 0,
            "workspace_root": None,
            "reason": "workspace not installed",
        }

    try:
        curiosity = CuriosityEngine(workspace_root=str(ws))
    except Exception as exc:
        logger.warning("curiosity_scanner: failed to init CuriosityEngine: %s", exc)
        return {
            "repos_scanned": 0,
            "files_sampled": 0,
            "findings_persisted": 0,
            "workspace_root": str(ws),
            "reason": f"init failed: {exc}",
        }

    suggestions = curiosity.suggest_unexplored(limit=max_repos)
    if not suggestions:
        logger.debug("curiosity_scanner: no stale repos to sample")
        return {
            "repos_scanned": 0,
            "files_sampled": 0,
            "findings_persisted": 0,
            "workspace_root": str(ws),
        }

    total_files = 0
    total_findings = 0

    for suggestion in suggestions:
        repo_name = suggestion["repo_name"]
        repo_path = Path(suggestion["path"])

        # Resolve repo identity (`owner/repo`) + commit once per repo so
        # findings in the same repo share attribution without re-running
        # git for every hit.
        try:
            repo_identity = get_repo_identity(str(repo_path))
        except Exception:
            repo_identity = None
        try:
            commit = get_repo_head(str(repo_path)) or ""
        except Exception:
            commit = ""

        samples = curiosity.random_sample(repo_name, count=max_files_per_repo)
        if not samples:
            continue

        for sample in samples:
            file_rel = sample.get("path", "")
            if not file_rel:
                continue
            file_path = repo_path / file_rel
            total_files += 1

            hits = _scan_file_for_patterns(file_path, repo_path, repo_identity, commit)
            for hit in hits:
                body = _format_finding(
                    repo_name,
                    hit["rel_path"],
                    hit["line"],
                    hit["pattern"],
                    hit["snippet"],
                )
                try:
                    row_id = persist_finding(
                        db_path=db_path,
                        domain="investigation",
                        engine="curiosity_scanner",
                        evidence_type=f"curiosity_{hit['pattern']}",
                        finding=body,
                        confidence=0.55,
                        source_repo=repo_identity or repo_name,
                        source_file=hit["rel_path"],
                        source_commit=commit or None,
                        source_line=hit["line"],
                        verification_url=hit["verification_url"],
                    )
                    if row_id and row_id > 0:
                        total_findings += 1
                except Exception as exc:
                    logger.debug(
                        "curiosity_scanner: persist failed for %s:%d — %s",
                        hit["rel_path"],
                        hit["line"],
                        exc,
                    )

    logger.info(
        "curiosity_scanner: scanned %d repo(s), sampled %d file(s), persisted %d finding(s)",
        len(suggestions),
        total_files,
        total_findings,
    )
    return {
        "repos_scanned": len(suggestions),
        "files_sampled": total_files,
        "findings_persisted": total_findings,
        "workspace_root": str(ws),
    }
