# SPDX-License-Identifier: MIT
"""SourceQualityScorer — Phase B engine for content-based trust.

Wraps `core.source_quality.score_repo` and writes one row per scored
repo into the `repo_trust_history` table. Runs every cycle on a
rotating subset of workspace repos.

Phase B (v0.3.4) — **scoring runs but doesn't yet affect trust**.
The `get_repo_trust()` function still reads hardcoded floors. This
phase is deliberately behavior-neutral so operators can calibrate
the scoring against their real workspace and verify the scores look
sensible before Phase C flips the switch.

Phase C (v0.4.0) reads `repo_trust_history` in `compute_dynamic_trust`
and uses the rolling average to promote/demote trust tiers
automatically. That's the commit that breaks the "everything funnels
through one repo" tell.

Why this engine is in the investigation domain: scoring a repo for
its content quality is the same mental move as
`architecture_analyzer` or `vision_tracker` — code archaeology, not
code auditing. The security domain is for finding bugs; the
investigation domain is for characterizing the shape of the
ecosystem.

Safety caps (same reasoning as curiosity_scanner):
- MAX_REPOS_PER_CYCLE=3 so a single cycle stays under ~10 seconds
  on a cold workspace
- Rolling rotation via modulo on cycle counter so every repo gets
  scored roughly once per 1-2 days at default pacing
- Degrades gracefully when the workspace isn't installed
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

from core.persistence import connect
from core.persistence.findings import persist_finding
from core.persistence.schema import DEFAULT_DB
from core.source_quality import score_repo
from core.workspace import workspace_root

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]

# Same bounded-cost pattern as curiosity_scanner.
MAX_REPOS_PER_CYCLE = 3


def _persist_history_row(db_path: str, result) -> bool:
    """Write one scored repo to repo_trust_history. Returns success."""
    conn = connect(db_path)
    try:
        conn.execute(
            """
            INSERT INTO repo_trust_history
            (repo_identity, quality_score, signals_json,
             files_scanned, bytes_scanned, scan_duration_seconds, scanned_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                result.repo_identity,
                result.quality_score,
                json.dumps(result.signals, sort_keys=True),
                result.files_scanned,
                result.bytes_scanned,
                result.scan_duration_seconds,
                result.scanned_at,
            ),
        )
        conn.commit()
        return True
    except Exception as exc:
        logger.debug("repo_trust_history insert failed: %s", exc)
        return False
    finally:
        conn.close()


def _discover_repos(ws: Path) -> list[Path]:
    """Return every immediate or nested git repo under the workspace.

    Mirrors workspace_discovery.py's one-level-deep convention: a
    directory is a "repo" if it contains a `.git` subdirectory. We
    walk two levels down because the Zenon workspace layout groups
    repos by owner (zenon-network/go-zenon, core/go-zenon,
    knowledge/developer-commons, etc.).
    """
    repos: list[Path] = []
    if not ws.is_dir():
        return repos

    for top in sorted(ws.iterdir()):
        if not top.is_dir() or top.name.startswith("."):
            continue
        if (top / ".git").exists():
            repos.append(top)
            continue
        # Second level
        try:
            for child in sorted(top.iterdir()):
                if not child.is_dir() or child.name.startswith("."):
                    continue
                if (child / ".git").exists():
                    repos.append(child)
        except OSError:
            continue
    return repos


def run_source_quality_scorer(
    db_path: str | None = None,
    *,
    max_repos: int = MAX_REPOS_PER_CYCLE,
) -> dict[str, Any]:
    """Score a rotating subset of workspace repos and persist history.

    Degrades gracefully when the workspace isn't installed — logs
    once and returns an empty summary rather than crashing the
    scheduler.

    Args:
        db_path: SQLite DB (defaults to DEFAULT_DB).
        max_repos: How many repos to score this cycle.

    Returns:
        Summary dict with ``repos_scanned``, ``history_rows_persisted``,
        ``findings_persisted``, ``average_quality_score``,
        ``workspace_root``.
    """
    db_path = db_path or DEFAULT_DB

    ws = workspace_root()
    if ws is None:
        logger.info("source_quality_scorer: workspace not installed; skipping")
        return {
            "repos_scanned": 0,
            "history_rows_persisted": 0,
            "findings_persisted": 0,
            "average_quality_score": 0.0,
            "workspace_root": None,
            "reason": "workspace not installed",
        }

    repos = _discover_repos(Path(ws))
    if not repos:
        return {
            "repos_scanned": 0,
            "history_rows_persisted": 0,
            "findings_persisted": 0,
            "average_quality_score": 0.0,
            "workspace_root": str(ws),
        }

    # Rotate through repos based on wall-clock seconds so successive
    # cycles pick different subsets even without cycle-counter state.
    # Phase C will replace this with a persisted per-repo last-scanned
    # timestamp once repo_trust_history is being read by the trust
    # model; for Phase B a simple rotation is enough.
    offset = int(time.time() // 60) % max(1, len(repos))
    selected = [repos[(offset + i) % len(repos)] for i in range(min(max_repos, len(repos)))]

    history_rows = 0
    findings = 0
    scores: list[float] = []

    for repo_path in selected:
        try:
            result = score_repo(repo_path, repo_identity=repo_path.name, db_path=db_path)
        except Exception as exc:
            logger.debug(
                "source_quality_scorer: score_repo failed for %s: %s",
                repo_path,
                exc,
            )
            continue

        if _persist_history_row(db_path, result):
            history_rows += 1
        scores.append(result.quality_score)

        # Emit a finding per scored repo so operators can see the
        # scores via ./nebula findings --engine source_quality_scorer
        # without having to query repo_trust_history directly.
        body = (
            f"WHAT: Scored `{result.repo_identity}` on content-quality "
            f"signals. quality_score={result.quality_score:.3f} "
            f"(files={result.files_scanned}, "
            f"bytes={result.bytes_scanned}). Top signals: "
            + ", ".join(
                f"{k}={v:.2f}" for k, v in sorted(result.signals.items(), key=lambda kv: -kv[1])[:3]
            )
            + ". SO WHAT: Content-based trust tier promotion (Phase C / "
            "v0.4.0) reads rolling averages from this score, so a repo "
            "earning >0.75 sustained for 50+ cycles gets promoted to the "
            "trusted tier regardless of its name. Phase B (this release) "
            "scores but does not yet affect trust — use `./nebula query "
            f'"SELECT * FROM repo_trust_history WHERE '
            f"repo_identity='{result.repo_identity}'\"` to see the full "
            "signal breakdown. NOW WHAT: Calibration period. Review the "
            "scores against your own intuition over the next several "
            "cycles; any systematic misranking is a signal-weight tuning "
            "bug to fix before the Phase C trust flip."
        )

        try:
            row_id = persist_finding(
                db_path=db_path,
                domain="investigation",
                engine="source_quality_scorer",
                evidence_type="repo_quality_score",
                finding=body,
                confidence=0.70,
                source_repo=result.repo_identity,
                raw_data={"signals": result.signals, "files": result.files_scanned},
            )
            if row_id and row_id > 0:
                findings += 1
        except Exception as exc:
            logger.debug("persist_finding failed for %s: %s", repo_path, exc)

    average = sum(scores) / len(scores) if scores else 0.0

    logger.info(
        "source_quality_scorer: scored %d repo(s), avg quality %.3f, %d rows persisted",
        len(selected),
        average,
        history_rows,
    )
    return {
        "repos_scanned": len(selected),
        "history_rows_persisted": history_rows,
        "findings_persisted": findings,
        "average_quality_score": average,
        "workspace_root": str(ws),
    }
