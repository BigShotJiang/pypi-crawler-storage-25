# SPDX-License-Identifier: MIT
"""
VisionTracker -- Track core dev technical vision and project direction.

Reads commit messages from core devs to identify development themes,
analyzes spec progression in developer-commons for strategic direction,
reads Accelerator-Z proposals for community funding priorities, and
identifies the next phase of Zenon development.
"""

import logging
import os
import subprocess
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# Core devs to track (by known git author names)
CORE_DEV_PATTERNS = [
    "georgezgeorgez",
    "vilkris",
    "alienc0der",
    "CryptoFish",
    "TminusZ",
    "0x3639",
    "sumamu",
    "sol-znn",
    "digitalSloth",
]

# Repos most indicative of project direction
DIRECTION_REPOS = [
    ("core", "go-zenon"),
    ("hypercore-one", "go-zenon"),
    ("knowledge", "developer-commons"),
    ("hypercore-one", "hyperqube_z"),
    ("HyperCore-Team", "orchestrator"),
]

# Theme keywords for commit classification
THEME_KEYWORDS = {
    "bridge": ["bridge", "portal", "wrap", "unwrap", "orchestrat", "relay"],
    "interop": ["htlc", "ptlc", "swap", "atomic", "cross-chain"],
    "evm": ["evm", "solidity", "ethereum", "supernova", "hyperqube", "extension"],
    "governance": ["governance", "vote", "proposal", "pillar", "accelerator", "az"],
    "scalability": ["plasma", "scale", "throughput", "sharding", "performance"],
    "privacy": ["privacy", "confidential", "zero-knowledge", "zk", "stealth"],
    "defi": ["liquidity", "dex", "swap", "amm", "pool", "streaming"],
    "identity": ["did", "identity", "zns", "name-service", "credential"],
    "security": ["security", "audit", "vulnerability", "sentinel", "validator"],
    "infrastructure": ["node", "rpc", "api", "explorer", "indexer", "sdk"],
}


def _run_git(repo_path: str, *args: str, timeout: int = 30) -> tuple[int, str]:
    """Run a git command. Returns (returncode, stdout)."""
    cmd = ["git", "-C", repo_path, *list(args)]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def _read_file_text(filepath: Path, max_bytes: int = 200_000) -> str:
    """Read a text file, returning empty string on failure."""
    try:
        return filepath.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def _is_core_dev(author: str) -> bool:
    """Check if an author name matches a known core dev pattern."""
    author_lower = author.lower()
    return any(dev.lower() in author_lower for dev in CORE_DEV_PATTERNS)


def get_core_dev_commits(
    since_days: int = 180,
    max_per_repo: int = 200,
) -> list[dict]:
    """Get recent commits from core devs across direction repos.

    Returns list of commit dicts with: repo, hash, author, date, message.
    """
    commits = []

    for org_dir, repo_name in DIRECTION_REPOS:
        repo_path = str(ZENON_WORKSPACE / org_dir / repo_name)
        if not os.path.isdir(repo_path):
            continue

        code, output = _run_git(
            repo_path,
            "log",
            f"--since={since_days} days ago",
            f"--max-count={max_per_repo}",
            "--format=%H|%an|%aI|%s",
        )
        if code != 0 or not output:
            continue

        for line in output.strip().split("\n"):
            if not line.strip():
                continue
            parts = line.split("|", 3)
            if len(parts) < 4:
                continue

            author = parts[1]
            if _is_core_dev(author):
                commits.append(
                    {
                        "repo": f"{org_dir}/{repo_name}",
                        "hash": parts[0][:12],
                        "author": author,
                        "date": parts[2],
                        "message": parts[3],
                    }
                )

    return commits


def classify_commit_themes(commits: list[dict]) -> dict[str, list[dict]]:
    """Classify commits into development themes.

    Returns dict mapping theme -> list of matching commits.
    """
    theme_commits: dict[str, list[dict]] = defaultdict(list)

    for commit in commits:
        message_lower = commit["message"].lower()
        matched = False
        for theme, keywords in THEME_KEYWORDS.items():
            if any(kw in message_lower for kw in keywords):
                theme_commits[theme].append(commit)
                matched = True
        if not matched:
            theme_commits["other"].append(commit)

    return dict(theme_commits)


def analyze_spec_progression() -> dict:
    """Analyze the spec progression in developer-commons.

    Reads spec directories, checks their creation/modification dates,
    and identifies the progression trajectory.
    """
    specs_dir = ZENON_WORKSPACE / "knowledge" / "developer-commons" / "docs" / "specs"
    if not specs_dir.is_dir():
        return {"exists": False, "specs": []}

    specs = []
    for entry in sorted(specs_dir.iterdir()):
        if not entry.is_dir() or entry.name.startswith("."):
            continue

        md_files = list(entry.rglob("*.md"))
        if not md_files:
            continue

        # Get last modified time from git
        repo_path = str(ZENON_WORKSPACE / "knowledge" / "developer-commons")
        code, date_output = _run_git(
            repo_path,
            "log",
            "-1",
            "--format=%aI",
            "--",
            str(entry.relative_to(ZENON_WORKSPACE / "knowledge" / "developer-commons")),
        )

        specs.append(
            {
                "name": entry.name,
                "file_count": len(md_files),
                "last_modified": date_output if code == 0 else "unknown",
            }
        )

    return {
        "exists": True,
        "spec_count": len(specs),
        "specs": specs,
    }


def analyze_dev_focus(commits: list[dict]) -> dict:
    """Analyze where core devs are focusing their effort.

    Returns dict with: focus_areas (ranked), author_focus (per dev),
    recent_direction.
    """
    themes = classify_commit_themes(commits)

    # Rank themes by commit count
    focus_areas = sorted(
        [(theme, len(commits_list)) for theme, commits_list in themes.items()],
        key=lambda x: x[1],
        reverse=True,
    )

    # Per-author focus
    author_themes: dict[str, Counter] = defaultdict(Counter)
    for theme, theme_commits in themes.items():
        for commit in theme_commits:
            author_themes[commit["author"]][theme] += 1

    author_focus = {}
    for author, theme_counter in author_themes.items():
        top = theme_counter.most_common(3)
        author_focus[author] = [{"theme": t, "commits": c} for t, c in top]

    # Determine most recent direction (last 30 days commits)
    now = datetime.now(timezone.utc)
    recent = [
        c
        for c in commits
        if c.get("date") and _parse_date(c["date"]) and (now - _parse_date(c["date"])).days <= 30
    ]
    recent_themes = classify_commit_themes(recent)
    recent_direction = sorted(
        [(t, len(cl)) for t, cl in recent_themes.items()],
        key=lambda x: x[1],
        reverse=True,
    )[:3]

    return {
        "focus_areas": focus_areas,
        "author_focus": author_focus,
        "recent_direction": recent_direction,
        "total_core_dev_commits": len(commits),
    }


def _parse_date(date_str: str) -> datetime | None:
    """Parse an ISO date string, returning None on failure."""
    try:
        return datetime.fromisoformat(date_str)
    except (ValueError, TypeError):
        return None


def identify_next_phase() -> dict:
    """Identify the likely next phase of Zenon development.

    Based on spec progression and recent commit activity.
    """
    spec_info = analyze_spec_progression()
    commits = get_core_dev_commits(since_days=90)
    focus = analyze_dev_focus(commits)

    # Determine phase based on evidence
    evidence = []
    phase_scores: Counter = Counter()

    # Check spec progression
    if spec_info["exists"]:
        spec_names = [s["name"].lower() for s in spec_info["specs"]]
        if any("portal" in s or "bridge" in s for s in spec_names):
            phase_scores["interop_bridge"] += 3
            evidence.append("Portal/bridge specs exist in developer-commons")
        if any("ptlc" in s for s in spec_names):
            phase_scores["interop_bridge"] += 2
            evidence.append("PTLC spec exists (prerequisite for trustless bridge)")
        if any("governance" in s for s in spec_names):
            phase_scores["governance"] += 2
            evidence.append("Governance spec exists")
        if any("hyperqube" in s or "evm" in s for s in spec_names):
            phase_scores["evm_extension"] += 2
            evidence.append("EVM/HyperQube specs exist")

    # Check commit focus
    for theme, count in focus.get("focus_areas", []):
        if theme == "bridge":
            phase_scores["interop_bridge"] += count
        elif theme == "evm":
            phase_scores["evm_extension"] += count
        elif theme == "governance":
            phase_scores["governance"] += count
        elif theme == "interop":
            phase_scores["interop_bridge"] += count

    # Rank phases
    ranked = phase_scores.most_common()
    likely_next = ranked[0][0] if ranked else "unknown"

    phase_labels = {
        "interop_bridge": "Trustless BTC bridge via Portal + PTLC",
        "evm_extension": "EVM extension chain (HyperQube/Supernova)",
        "governance": "On-chain governance with Pillar voting",
        "unknown": "Insufficient data to determine",
    }

    return {
        "likely_next_phase": phase_labels.get(likely_next, likely_next),
        "phase_scores": dict(phase_scores),
        "evidence": evidence,
        "confidence": min(0.9, 0.3 + (ranked[0][1] * 0.05 if ranked else 0)),
    }


def generate_report() -> dict:
    """Generate a full vision tracking report."""
    commits = get_core_dev_commits()
    focus = analyze_dev_focus(commits)
    spec_prog = analyze_spec_progression()
    next_phase = identify_next_phase()

    return {
        "core_dev_commits": len(commits),
        "development_focus": focus,
        "spec_progression": spec_prog,
        "next_phase": next_phase,
        "unique_core_devs": len({c["author"] for c in commits}),
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run vision tracking and persist findings to evidence table."""
    from core.persist_to_db import ensure_schema, persist_finding

    ensure_schema(db_path)
    count = 0

    report = generate_report()

    # Overall vision finding
    focus_str = ", ".join(
        f"{t} ({c})" for t, c in report["development_focus"].get("focus_areas", [])[:5]
    )
    next_phase = report["next_phase"]["likely_next_phase"]
    commit_count = report["core_dev_commits"]
    dev_count = report["unique_core_devs"]
    persist_finding(
        db_path=db_path,
        domain="investigation",
        engine="vision_tracker",
        evidence_type="development_vision",
        finding=(
            f"WHAT: {commit_count} commits from {dev_count} core devs in "
            f"the last 180 days. Top focus: {focus_str}. "
            f"SO WHAT: Core dev activity {'is healthy' if commit_count > 50 else 'is low — possible slowdown or private development'}. "
            f"Next phase appears to be: {next_phase}. "
            f"NOW WHAT: Align our implementation priorities with the top focus "
            f"area; prepare SDK/CLI support for {next_phase}."
        ),
        confidence=report["next_phase"]["confidence"],
        raw_data=report,
        source_repo="go-zenon",
    )
    count += 1

    # Persist per-dev focus
    for author, themes in report["development_focus"].get("author_focus", {}).items():
        theme_str = ", ".join(f"{t['theme']} ({t['commits']})" for t in themes)
        top_theme = themes[0]["theme"] if themes else "unknown"
        persist_finding(
            db_path=db_path,
            domain="investigation",
            engine="vision_tracker",
            evidence_type="dev_focus",
            finding=(
                f"WHAT: Core dev {author} is focused on: {theme_str}. "
                f"SO WHAT: {author}'s primary area ({top_theme}) signals where "
                f"upstream review capacity exists — PRs in this area get faster reviews. "
                f"NOW WHAT: When submitting PRs touching {top_theme}, tag for "
                f"{author}'s review; align implementation order with their focus."
            ),
            confidence=0.80,
            raw_data={"author": author, "themes": themes},
            source_repo="go-zenon",
        )
        count += 1

    # Persist next phase prediction
    next_phase_data = report["next_phase"]
    evidence_str = "; ".join(next_phase_data["evidence"][:5])
    conf = next_phase_data["confidence"]
    persist_finding(
        db_path=db_path,
        domain="investigation",
        engine="vision_tracker",
        evidence_type="next_phase_prediction",
        finding=(
            f"WHAT: Predicted next phase: {next_phase_data['likely_next_phase']} "
            f"(confidence: {conf:.0%}). Evidence: {evidence_str}. "
            f"SO WHAT: {'High-confidence prediction — safe to invest implementation effort.' if conf >= 0.7 else 'Low-confidence — more signals needed before committing resources.'} "
            f"NOW WHAT: {'Begin full-stack implementation for this phase; prepare SDK + CLI + docs.' if conf >= 0.7 else 'Monitor upstream commits for 2 more weeks to confirm direction.'}"
        ),
        confidence=conf,
        raw_data=next_phase_data,
        source_repo="go-zenon",
    )
    count += 1

    logger.info("VisionTracker: persisted %d findings", count)
    return count
