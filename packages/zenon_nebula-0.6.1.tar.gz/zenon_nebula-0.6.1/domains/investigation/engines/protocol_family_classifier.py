# SPDX-License-Identifier: MIT
"""
ProtocolFamilyClassifier -- categorize every workspace repo by protocol family.

Classifies each entry in the ``workspace_repos`` catalog into one of:

- ``utxo_chain`` — Bitcoin-family UTXO blockchains
- ``account_chain`` — account-model blockchains (EVM, Cosmos, Zenon itself)
- ``zk_rollup`` — repos with zk/plonk/stark machinery
- ``bridge`` — cross-chain bridge implementations
- ``sdk_consumer`` — SDKs wrapping a node API
- ``documentation`` — specs, wikis, handbooks
- ``tooling`` — CLI tools, dev infrastructure, explorers
- ``unknown`` — no confident classification

Resolution order: :data:`core.workspace_discovery.REPO_SIGNATURES`
classification first, then directory-name heuristics, then an optional
LLM fallback via :func:`core.llm_provider.call_llm` capped at one call
per repo per run. The LLM classification (when available) is cached
back into ``workspace_repos.llm_classification`` so subsequent runs can
skip the network call.

Gracefully degrades when no workspace is present and never raises on
LLM failures.
"""

from __future__ import annotations

import json
import logging

from core.persist_to_db import persist_finding
from core.persistence.metrics import query_table
from core.persistence.schema import DEFAULT_DB, _get_connection, ensure_schema

logger = logging.getLogger(__name__)


FAMILIES = (
    "utxo_chain",
    "account_chain",
    "zk_rollup",
    "bridge",
    "sdk_consumer",
    "documentation",
    "tooling",
    "unknown",
)


# Direct mapping from REPO_SIGNATURES labels to protocol families.
_TYPE_TO_FAMILY: dict[str, str] = {
    "node": "account_chain",  # Zenon itself is account-model
    "sdk_dart": "sdk_consumer",
    "sdk_go": "sdk_consumer",
    "sdk_typescript": "sdk_consumer",
    "sdk_python": "sdk_consumer",
    "cli": "tooling",
    "cli_go": "tooling",
    "wallet": "tooling",
    "explorer": "tooling",
    "wiki": "documentation",
    "specs": "documentation",
    "bridge": "bridge",
    "website": "documentation",
    "devnet": "tooling",
    "blockchain_node_btc": "utxo_chain",
    "blockchain_node_evm": "account_chain",
    "blockchain_node_cosmos": "account_chain",
    "rust_blockchain": "account_chain",
    "generic_has_contracts": "tooling",
    "generic_has_rpc_api": "tooling",
    "generic_has_crypto_primitives": "tooling",
}


_NAME_HEURISTICS: list[tuple[str, str]] = [
    ("zk", "zk_rollup"),
    ("plonk", "zk_rollup"),
    ("snark", "zk_rollup"),
    ("stark", "zk_rollup"),
    ("rollup", "zk_rollup"),
    ("bridge", "bridge"),
    ("orchestrator", "bridge"),
    ("portal", "bridge"),
    ("wiki", "documentation"),
    ("docs", "documentation"),
    ("handbook", "documentation"),
    ("spec", "documentation"),
    ("sdk", "sdk_consumer"),
    ("client", "sdk_consumer"),
    ("cli", "tooling"),
    ("explorer", "tooling"),
    ("nebula", "tooling"),
]


def _classify_by_type(repo_type: str) -> str | None:
    """Return the mapped family for a known :data:`REPO_SIGNATURES` type."""
    if not repo_type:
        return None
    return _TYPE_TO_FAMILY.get(repo_type)


def _classify_by_name(repo_name: str) -> str | None:
    """Return a family using name-substring heuristics."""
    name = (repo_name or "").lower()
    for needle, family in _NAME_HEURISTICS:
        if needle in name:
            return family
    return None


def _call_llm_classifier(
    repo_name: str,
    repo_path: str,
    languages: list[str],
) -> str | None:
    """Ask the configured LLM to classify a repo into a protocol family.

    Returns ``None`` on any failure so the caller can fall back to
    ``unknown``. Never raises.
    """
    try:
        from core.llm_provider import call_llm
    except Exception as exc:
        logger.debug("protocol_family_classifier: llm import failed: %s", exc)
        return None
    prompt = (
        "Classify this repository into exactly one of these protocol "
        f"families: {', '.join(FAMILIES)}. Respond with ONLY the family "
        "name, nothing else.\n\n"
        f"Repo name: {repo_name}\n"
        f"Languages: {', '.join(languages) if languages else 'unknown'}\n"
        f"Path: {repo_path}"
    )
    try:
        result = call_llm(prompt=prompt, system="", model="auto")
    except Exception as exc:
        logger.debug("protocol_family_classifier: call_llm failed: %s", exc)
        return None
    if not isinstance(result, dict):
        return None
    text = (result.get("text") or "").strip().lower()
    for family in FAMILIES:
        if family in text:
            return family
    return None


def _update_llm_classification(
    db_path: str,
    repo_name: str,
    family: str,
) -> None:
    """Cache the chosen family into ``workspace_repos.llm_classification``."""
    try:
        ensure_schema(db_path)
        conn = _get_connection(db_path)
        try:
            conn.execute(
                "UPDATE workspace_repos SET llm_classification = ? WHERE repo_name = ?",
                (family, repo_name),
            )
            conn.commit()
        finally:
            conn.close()
    except Exception as exc:
        logger.debug(
            "protocol_family_classifier: cache update failed for %s: %s",
            repo_name,
            exc,
        )


def _load_languages(row: dict) -> list[str]:
    """Decode the ``languages`` JSON column from a ``workspace_repos`` row."""
    raw = row.get("languages")
    if not raw:
        return []
    try:
        value = json.loads(raw)
    except (TypeError, json.JSONDecodeError):
        return []
    if isinstance(value, list):
        return [str(v) for v in value]
    return []


def classify_protocol_families(
    db_path: str = DEFAULT_DB,
    use_llm: bool = False,
    max_llm_calls: int = 5,
    **_: object,
) -> dict:
    """Classify every repo in ``workspace_repos`` into a protocol family.

    Uses signature-based classification first, then name heuristics,
    then an optional LLM fallback. Writes a batched summary finding
    describing the counts per family. Individual ``unknown`` repos are
    NOT flagged to avoid noisy output.

    Args:
        db_path:       SQLite database path.
        use_llm:       When True, fall back to the LLM for unresolved repos.
        max_llm_calls: Maximum number of LLM invocations per run.

    Returns:
        Dict with per-family counts plus total repos classified.
    """
    rows = query_table(db_path=db_path, table="workspace_repos", limit=0)
    if not rows:
        return {}

    counts: dict[str, int] = dict.fromkeys(FAMILIES, 0)
    classified: list[dict] = []
    llm_budget = max_llm_calls if use_llm else 0

    for row in rows:
        repo_name = row.get("repo_name", "")
        if not repo_name:
            continue
        # Prefer any cached LLM decision from a prior run.
        family = (row.get("llm_classification") or "").strip().lower() or None
        if family not in FAMILIES:
            family = None
        if family is None:
            family = _classify_by_type(row.get("repo_type", ""))
        if family is None:
            family = _classify_by_name(repo_name)
        if family is None and llm_budget > 0:
            family = _call_llm_classifier(
                repo_name=repo_name,
                repo_path=row.get("repo_path", ""),
                languages=_load_languages(row),
            )
            if family:
                _update_llm_classification(db_path, repo_name, family)
                llm_budget -= 1
        if family is None:
            family = "unknown"
        counts[family] = counts.get(family, 0) + 1
        classified.append({"repo_name": repo_name, "family": family})

    total = sum(counts.values())
    summary_text = (
        f"WHAT: Protocol family classifier categorized {total} workspace "
        f"repos: "
        + ", ".join(f"{family}={counts[family]}" for family in FAMILIES if counts[family])
        + ". "
        + "SO WHAT: The family breakdown tells us which parts of the "
        "workspace are chains, which are SDK consumers, which are "
        "documentation, and which remain unclassified. Downstream "
        "engines can filter by family instead of hardcoding repo names. "
        "NOW WHAT: Use workspace_repos.repo_type + "
        "workspace_repos.llm_classification to target family-specific "
        "analysis (cross-chain CVEs, reference diffs, BIP tracking, "
        "bridge scans)."
    )
    persist_finding(
        db_path=db_path,
        domain="investigation",
        engine="protocol_family_classifier",
        evidence_type="protocol_family_summary",
        finding=summary_text,
        confidence=0.6,
        raw_data={"counts": counts, "classified": classified},
    )

    return {
        "total": total,
        "counts": counts,
        "llm_calls": (max_llm_calls - llm_budget) if use_llm else 0,
    }


__all__ = ["FAMILIES", "classify_protocol_families"]
