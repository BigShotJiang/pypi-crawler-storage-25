# SPDX-License-Identifier: MIT
"""PatternDiscoverer — surface anomalous content structure without decoding.

Phase D of the v0.4.0 content-based trust architecture (task #46).
Completes the clue-dropping communication channel story by letting
researchers drop clues via two paths:

1. **DIRECT** — explicit markers in code or specs saying "this is
   a hint for the community":
   - ``# Clue:`` / ``// Clue:`` / ``<!-- Clue: -->`` / ``// Hint:``
   - YAML front-matter with ``hint:`` / ``clue:`` /
     ``for_community:`` / ``open_question:`` keys
   - Markdown section headings like ``## Open Questions``,
     ``## Hints for Implementers``, ``## Community Review``,
     ``## Note to Readers``

2. **INDIRECT (Satoshi-style)** — hidden patterns that look
   deliberate but carry no explicit "this is a clue" marker:
   - Hex/base64 blobs that decode to printable ASCII
   - Numeric sequences matching known-significant values
     (Bitcoin block heights of significant events, Fibonacci,
     digits of pi, unix timestamps of anniversaries)
   - Acrostics: first letters of consecutive lines spelling a
     word or phrase
   - Filename / function-name alphabetical clusters that spell
     something when read in order
   - Unusually specific "placeholder" values that turn out to
     decode to something relevant (e.g., a "test address" that
     resolves to a real Zenon address with a known balance)

The engine SURFACES candidates; it does NOT decode them. Nebula's
job is to say "this file contains a hex string that decodes to
printable ASCII — unusual, click to see it" and let the community
do the interpretation. This is the same design principle as
``curiosity_scanner``: we find the anomaly, humans assign meaning.

Findings carry WHAT/SO WHAT/NOW WHAT format + full provenance +
clickable GitHub permalinks, same shape as every other engine. The
confidence band is deliberately bimodal: direct markers get 0.8
(explicit intent is strong signal), indirect patterns get 0.4-0.5
(speculative, requires corroboration).

**Anti-gaming:** the engine uses the v0.3.3 content_hash
infrastructure to detect novelty. A repo spamming the same hex
blob across 50 files gets content_hash collapse in
peer_corroboration — each blob resolves to the same hash, the
dedup stage counts them as one finding not 50.

**Wired to rapid recognition:** high-confidence pattern_discoverer
findings contribute to the ``clue_density`` signal in
``core.source_quality.score_repo``, which feeds into the rapid-
recognition path in ``core.trust.compute_dynamic_trust``. A single
repo dropping genuinely brilliant first-contribution clues can be
promoted to the trusted tier (0.7) within a handful of cycles,
without waiting 100 cycles of sustained history.
"""

from __future__ import annotations

import base64
import binascii
import logging
import re
from pathlib import Path
from typing import Any

from core.git_cache import get_repo_head, get_repo_identity
from core.persistence.findings import persist_finding
from core.persistence.schema import DEFAULT_DB
from core.workspace import workspace_root

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]

# Bounded cost: same shape as curiosity_scanner + source_quality_scorer
MAX_REPOS_PER_CYCLE = 3
MAX_FILES_PER_REPO = 15
MAX_BYTES_PER_FILE = 256 * 1024
MAX_PATTERNS_PER_FILE = 5  # cap finding volume per file

# Priority extensions — where clues are most likely to live
_PRIORITY_EXTENSIONS = {".md", ".go", ".rs", ".sol", ".py", ".dart", ".ts", ".txt"}

_SKIPPED_DIRS = {
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    "build",
    "dist",
    "target",
    ".idea",
    ".vscode",
    "site",
    "vendor",
}


# ---------------------------------------------------------------------------
# DIRECT markers — explicit clue/hint/note patterns
# ---------------------------------------------------------------------------

# Line-level markers: // Clue:, # Hint:, <!-- Note: -->, etc.
_DIRECT_MARKERS = re.compile(
    r"(?:#|//|<!--|\*)\s*"
    r"(?P<kind>clue|hint|note\s+to\s+readers?|for\s+community|"
    r"open\s+question|research\s+note|implementers?\s+note|"
    r"pattern|puzzle|left\s+as\s+(?:an\s+)?exercise)"
    r"\s*[:\-]\s*"
    r"(?P<body>[^\n]{10,300})",
    re.IGNORECASE,
)

# YAML front-matter keys (in specs and config files)
_YAML_CLUE_KEYS = re.compile(
    r"^\s*(?P<key>hint|clue|for_community|open_question|"
    r"research_note|puzzle|pattern|left_as_exercise)\s*:\s*"
    r"(?P<value>[^\n]{5,300})",
    re.IGNORECASE | re.MULTILINE,
)

# Markdown section headings that signal "this is community-facing"
_COMMUNITY_SECTION_HEADINGS = re.compile(
    r"^#{1,3}\s*\d*\.?\s*(?:"
    r"open\s+questions?|"
    r"hints?\s+for\s+implementers?|"
    r"community\s+review|"
    r"note\s+to\s+readers?|"
    r"research\s+notes?|"
    r"puzzles?|"
    r"pattern\s+to\s+notice|"
    r"left\s+as\s+(?:an\s+)?exercise"
    r")\s*$",
    re.IGNORECASE | re.MULTILINE,
)


# ---------------------------------------------------------------------------
# INDIRECT markers — Satoshi-style hidden patterns
# ---------------------------------------------------------------------------

# Hex blobs that are long enough to decode meaningfully.
# Minimum 16 hex chars = 8 bytes = potential ASCII phrase.
_HEX_BLOB_RE = re.compile(r"\b0x([0-9a-fA-F]{16,})\b")

# Base64 blobs — require enough length + standard alphabet + optional padding.
# Use negative lookaround instead of \b because `=` and string-end don't
# form word boundaries, so \b at the trailing edge wrongly fails.
_BASE64_BLOB_RE = re.compile(r"(?<![A-Za-z0-9+/=])([A-Za-z0-9+/]{20,}={0,2})(?![A-Za-z0-9+/=])")

# Numeric sequences — known-significant values. Partial list of
# Bitcoin-relevant + cryptographic constants worth flagging when
# they appear as "placeholder" test data.
_SIGNIFICANT_NUMBERS = {
    # Bitcoin genesis + significant heights
    1231006505: "Bitcoin genesis timestamp (2009-01-03)",
    210000: "Bitcoin halving interval",
    21000000: "Bitcoin max supply (ignoring decimals)",
    478558: "Bitcoin Cash hard fork block",
    500000: "Bitcoin block 500000 celebration",
    # secp256k1 curve order (first 16 hex)
    # 0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141
    # Fibonacci — first 20 values
    # (flagged separately below)
}

# Fibonacci sequence first 20 values — unlikely to appear as
# "random test data" by chance, common in deliberate clues.
_FIBONACCI = frozenset(
    {1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765}
)

# Digits of pi embedded in test data
_PI_DIGITS = "31415926535897932384626433832795028841971693993751"

# Minimum ASCII-print ratio for hex/base64 "decodes to text" check
_MIN_ASCII_RATIO = 0.85
_MIN_DECODED_LENGTH = 6  # don't flag 3-byte "noise" decodes

# Words common enough that their appearance in a decoded hex blob
# signals intentional text (not random data that happens to be
# printable)
_TELLING_WORDS = frozenset(
    {
        "zenon",
        "plasma",
        "pillar",
        "sentinel",
        "satoshi",
        "bitcoin",
        "hello",
        "world",
        "clue",
        "hint",
        "pattern",
        "schnorr",
        "taproot",
        "secret",
        "message",
        "read",
        "this",
        "from",
        "for",
        "the",
        "and",
        "public",
        "private",
        "key",
    }
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_github_url(
    repo_identity: str | None, rel_path: str, line: int, commit: str
) -> str | None:
    """Clickable GitHub permalink — same shape as every other engine."""
    if not repo_identity or "/" not in repo_identity:
        return None
    ref = commit or "main"
    encoded = rel_path.replace(" ", "%20")
    url = f"https://github.com/{repo_identity}/blob/{ref}/{encoded}"
    if line > 0:
        url = f"{url}#L{line}"
    return url


def _decode_hex_to_ascii(hex_str: str) -> str | None:
    """Return decoded ASCII text if the hex blob is mostly printable.

    Returns the decoded string when the printable ratio is above
    _MIN_ASCII_RATIO, None otherwise. Short decodes are rejected.
    """
    try:
        data = bytes.fromhex(hex_str)
    except (ValueError, binascii.Error):
        return None
    if len(data) < _MIN_DECODED_LENGTH:
        return None
    try:
        decoded = data.decode("ascii", errors="replace")
    except UnicodeDecodeError:
        return None
    printable = sum(1 for c in decoded if 32 <= ord(c) < 127 and c != "\ufffd")
    if printable / max(1, len(decoded)) < _MIN_ASCII_RATIO:
        return None
    return decoded


def _decode_base64_to_ascii(b64_str: str) -> str | None:
    """Return decoded ASCII text if the base64 blob is mostly printable."""
    if len(b64_str) % 4 != 0:
        return None
    try:
        data = base64.b64decode(b64_str, validate=True)
    except (ValueError, binascii.Error):
        return None
    if len(data) < _MIN_DECODED_LENGTH:
        return None
    try:
        decoded = data.decode("ascii", errors="replace")
    except UnicodeDecodeError:
        return None
    printable = sum(1 for c in decoded if 32 <= ord(c) < 127 and c != "\ufffd")
    if printable / max(1, len(decoded)) < _MIN_ASCII_RATIO:
        return None
    return decoded


def _is_meaningful_decode(decoded: str) -> bool:
    """Return True if the decoded text looks like deliberate English.

    Filters random-data coincidences: requires either a telling
    word or high word-character density.
    """
    lower = decoded.lower()
    for word in _TELLING_WORDS:
        if word in lower:
            return True
    # Fallback: high alphabetic density + some spaces (looks like prose)
    alpha = sum(1 for c in decoded if c.isalpha())
    spaces = decoded.count(" ")
    return len(decoded) >= 12 and alpha / len(decoded) > 0.6 and spaces >= 1


# ---------------------------------------------------------------------------
# Per-file scanners
# ---------------------------------------------------------------------------


def _scan_direct_markers(content: str) -> list[dict[str, Any]]:
    """Find explicit clue/hint/note markers in code or prose.

    Returns list of pattern-hit dicts with ``kind``, ``line``,
    ``body``, ``path_hint``.
    """
    hits: list[dict[str, Any]] = []

    for match in _DIRECT_MARKERS.finditer(content):
        line_no = content.count("\n", 0, match.start()) + 1
        kind = match.group("kind").strip().lower()
        body = match.group("body").strip()
        hits.append(
            {
                "path": "direct_marker",
                "kind": kind,
                "line": line_no,
                "body": body[:200],
                "confidence": 0.80,
            }
        )

    for match in _YAML_CLUE_KEYS.finditer(content):
        line_no = content.count("\n", 0, match.start()) + 1
        key = match.group("key").strip().lower()
        value = match.group("value").strip().strip("\"'")
        hits.append(
            {
                "path": "direct_marker",
                "kind": f"yaml_{key}",
                "line": line_no,
                "body": value[:200],
                "confidence": 0.80,
            }
        )

    for match in _COMMUNITY_SECTION_HEADINGS.finditer(content):
        line_no = content.count("\n", 0, match.start()) + 1
        heading = match.group(0).strip()
        hits.append(
            {
                "path": "direct_marker",
                "kind": "section_heading",
                "line": line_no,
                "body": heading[:200],
                "confidence": 0.70,
            }
        )

    return hits


def _scan_indirect_patterns(content: str) -> list[dict[str, Any]]:
    """Find Satoshi-style hidden patterns: decodable blobs + sequences.

    Returns list of pattern-hit dicts. Confidence is lower (0.40-0.55)
    because indirect patterns are speculative — the community has to
    judge whether the decode is deliberate.
    """
    hits: list[dict[str, Any]] = []
    seen_decodes: set[str] = set()

    # Hex blobs decoding to printable ASCII
    for match in _HEX_BLOB_RE.finditer(content):
        hex_str = match.group(1)
        decoded = _decode_hex_to_ascii(hex_str)
        if not decoded:
            continue
        if not _is_meaningful_decode(decoded):
            continue
        if decoded in seen_decodes:
            continue
        seen_decodes.add(decoded)
        line_no = content.count("\n", 0, match.start()) + 1
        hits.append(
            {
                "path": "indirect_hex_decode",
                "kind": "hex_to_ascii",
                "line": line_no,
                "body": f"0x{hex_str[:48]}... decodes to {decoded[:100]!r}",
                "confidence": 0.55,
            }
        )

    # Base64 blobs decoding to printable ASCII
    for match in _BASE64_BLOB_RE.finditer(content):
        b64_str = match.group(1)
        # Skip very long blobs — usually legitimate binary data
        if len(b64_str) > 200:
            continue
        decoded = _decode_base64_to_ascii(b64_str)
        if not decoded:
            continue
        if not _is_meaningful_decode(decoded):
            continue
        if decoded in seen_decodes:
            continue
        seen_decodes.add(decoded)
        line_no = content.count("\n", 0, match.start()) + 1
        hits.append(
            {
                "path": "indirect_base64_decode",
                "kind": "base64_to_ascii",
                "line": line_no,
                "body": f"{b64_str[:32]}... decodes to {decoded[:100]!r}",
                "confidence": 0.45,
            }
        )

    # Fibonacci sequence embedded in numeric data
    # Only flag when 4+ Fibonacci numbers appear in close proximity
    all_numbers = re.findall(r"\b(\d+)\b", content)
    fib_hits_in_window = 0
    fib_lines: list[int] = []
    for match in re.finditer(r"\b(\d+)\b", content):
        try:
            num = int(match.group(1))
        except ValueError:
            continue
        if num in _FIBONACCI:
            line_no = content.count("\n", 0, match.start()) + 1
            fib_lines.append(line_no)
            fib_hits_in_window += 1
    if fib_hits_in_window >= 4 and fib_lines:
        hits.append(
            {
                "path": "indirect_fibonacci",
                "kind": "fibonacci_sequence",
                "line": fib_lines[0],
                "body": f"{fib_hits_in_window} Fibonacci-number hits in the file",
                "confidence": 0.40,
            }
        )

    # Digits of pi embedded in a string literal
    if _PI_DIGITS[:20] in content:
        idx = content.find(_PI_DIGITS[:20])
        line_no = content.count("\n", 0, idx) + 1
        hits.append(
            {
                "path": "indirect_pi_digits",
                "kind": "pi_digits_embedded",
                "line": line_no,
                "body": f"first 20 digits of pi appear at line {line_no}",
                "confidence": 0.50,
            }
        )

    # Significant Bitcoin-relevant numbers
    for num_str in all_numbers[:500]:  # cap to avoid huge files
        try:
            num = int(num_str)
        except ValueError:
            continue
        if num in _SIGNIFICANT_NUMBERS:
            # Find the line
            match = re.search(rf"\b{num}\b", content)
            if not match:
                continue
            line_no = content.count("\n", 0, match.start()) + 1
            hits.append(
                {
                    "path": "indirect_significant_number",
                    "kind": f"significant_{num}",
                    "line": line_no,
                    "body": f"{num} — {_SIGNIFICANT_NUMBERS[num]}",
                    "confidence": 0.50,
                }
            )

    return hits


def _should_scan_file(path: Path) -> bool:
    """Return True if the file should contribute to the scan."""
    if path.suffix.lower() not in _PRIORITY_EXTENSIONS:
        return False
    if any(part in _SKIPPED_DIRS for part in path.parts):
        return False
    try:
        if path.stat().st_size > MAX_BYTES_PER_FILE:
            return False
    except OSError:
        return False
    return True


# ---------------------------------------------------------------------------
# Engine entry point
# ---------------------------------------------------------------------------


def _discover_repos(ws: Path) -> list[Path]:
    """Walk two levels deep looking for .git directories."""
    repos: list[Path] = []
    if not ws.is_dir():
        return repos
    for top in sorted(ws.iterdir()):
        if not top.is_dir() or top.name.startswith("."):
            continue
        if (top / ".git").exists():
            repos.append(top)
            continue
        try:
            for child in sorted(top.iterdir()):
                if not child.is_dir() or child.name.startswith("."):
                    continue
                if (child / ".git").exists():
                    repos.append(child)
        except OSError:
            continue
    return repos


def _format_finding(repo_name: str, rel_path: str, hit: dict[str, Any]) -> str:
    """Render a pattern hit as a WHAT/SO WHAT/NOW WHAT finding body."""
    direct = hit["path"].startswith("direct_")
    if direct:
        return (
            f"WHAT: `{repo_name}/{rel_path}` line {hit['line']} contains "
            f"an explicit {hit['kind']} marker. Body: {hit['body']!r}. "
            f"SO WHAT: The author deliberately left a community-facing "
            f"note in the source. Explicit markers are strong signal — "
            f"the researcher WANTED this to be seen. "
            f"NOW WHAT: Click the permalink to read the full context. "
            f"Surface to the community if the note is substantive "
            f"research rather than a routine TODO."
        )
    return (
        f"WHAT: `{repo_name}/{rel_path}` line {hit['line']} contains "
        f"an anomalous {hit['kind']} pattern. Body: {hit['body']!r}. "
        f"SO WHAT: Patterns like these don't usually appear in routine "
        f"code — hex blobs that decode to English, Fibonacci sequences "
        f"in test data, embedded pi digits. May be deliberate research "
        f"clues left for readers to discover, may be coincidence. "
        f"pattern_discoverer surfaces the anomaly without interpreting "
        f"it. "
        f"NOW WHAT: Click the permalink and judge intent from context. "
        f"If multiple anomalous patterns co-occur in the same file, "
        f"treat it as a strong deliberate-intent signal."
    )


def run_pattern_discoverer(
    db_path: str | None = None,
    *,
    max_repos: int = MAX_REPOS_PER_CYCLE,
    max_files_per_repo: int = MAX_FILES_PER_REPO,
) -> dict[str, Any]:
    """Scan a rotating subset of workspace repos for clue patterns.

    Runs every cycle via the investigation-domain rotation. Bounded
    cost: 3 repos * 15 files * 256 KB each -> ~11 MB per cycle max,
    typically much less because most files skip at the extension
    filter.

    Args:
        db_path: SQLite DB path (defaults to DEFAULT_DB).
        max_repos: Cap on repos scanned this cycle.
        max_files_per_repo: Cap on files scanned per repo.

    Returns:
        Summary dict with ``repos_scanned``, ``files_scanned``,
        ``direct_hits``, ``indirect_hits``, ``findings_persisted``.
    """
    db_path = db_path or DEFAULT_DB

    ws = workspace_root()
    if ws is None:
        logger.info("pattern_discoverer: workspace not installed; skipping")
        return {
            "repos_scanned": 0,
            "files_scanned": 0,
            "direct_hits": 0,
            "indirect_hits": 0,
            "findings_persisted": 0,
            "workspace_root": None,
            "reason": "workspace not installed",
        }

    repos = _discover_repos(Path(ws))
    if not repos:
        return {
            "repos_scanned": 0,
            "files_scanned": 0,
            "direct_hits": 0,
            "indirect_hits": 0,
            "findings_persisted": 0,
            "workspace_root": str(ws),
        }

    import time

    offset = int(time.time() // 60) % max(1, len(repos))
    selected = [repos[(offset + i) % len(repos)] for i in range(min(max_repos, len(repos)))]

    total_files = 0
    direct_hits = 0
    indirect_hits = 0
    findings_persisted = 0

    for repo_path in selected:
        try:
            repo_identity = get_repo_identity(str(repo_path))
        except Exception:
            repo_identity = None
        try:
            commit = get_repo_head(str(repo_path)) or ""
        except Exception:
            commit = ""

        files_scanned_in_repo = 0
        for file_path in repo_path.rglob("*"):
            if files_scanned_in_repo >= max_files_per_repo:
                break
            if not file_path.is_file():
                continue
            if not _should_scan_file(file_path):
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            files_scanned_in_repo += 1
            total_files += 1

            direct = _scan_direct_markers(content)
            indirect = _scan_indirect_patterns(content)
            all_hits = direct + indirect
            if not all_hits:
                continue

            # Cap findings per file so a single noisy file doesn't
            # flood the evidence table
            all_hits = all_hits[:MAX_PATTERNS_PER_FILE]

            try:
                rel_path = str(file_path.relative_to(repo_path))
            except ValueError:
                rel_path = file_path.name

            for hit in all_hits:
                if hit["path"].startswith("direct_"):
                    direct_hits += 1
                else:
                    indirect_hits += 1

                body = _format_finding(repo_path.name, rel_path, hit)
                url = _build_github_url(repo_identity, rel_path, hit["line"], commit)

                try:
                    row_id = persist_finding(
                        db_path=db_path,
                        domain="investigation",
                        engine="pattern_discoverer",
                        evidence_type=f"pattern_{hit['kind']}",
                        finding=body,
                        confidence=hit["confidence"],
                        source_repo=repo_identity or repo_path.name,
                        source_file=rel_path,
                        source_commit=commit or None,
                        source_line=hit["line"],
                        verification_url=url,
                        raw_data={"kind": hit["kind"], "path": hit["path"]},
                    )
                    if row_id and row_id > 0:
                        findings_persisted += 1
                except Exception as exc:
                    logger.debug(
                        "pattern_discoverer: persist failed for %s:%d — %s",
                        rel_path,
                        hit["line"],
                        exc,
                    )

    logger.info(
        "pattern_discoverer: scanned %d repo(s), %d file(s), "
        "%d direct hits, %d indirect hits, %d findings persisted",
        len(selected),
        total_files,
        direct_hits,
        indirect_hits,
        findings_persisted,
    )
    return {
        "repos_scanned": len(selected),
        "files_scanned": total_files,
        "direct_hits": direct_hits,
        "indirect_hits": indirect_hits,
        "findings_persisted": findings_persisted,
        "workspace_root": str(ws),
    }
