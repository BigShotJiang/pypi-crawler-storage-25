# SPDX-License-Identifier: MIT
"""
ArchitectureAnalyzer -- Understand Zenon's technical architecture from source.

Reads go-zenon to extract: which embedded contracts exist, how they're
wired, dependency chains between contracts, architectural patterns
(spork gates, dual-coin model, plasma). Persists architectural
insights as evidence.
"""

import contextlib
import logging
import os
import re
from collections import defaultdict
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# go-zenon locations (check multiple forks)
GO_ZENON_PATHS = [
    ZENON_WORKSPACE / "core" / "go-zenon",
    ZENON_WORKSPACE / "hypercore-one" / "go-zenon",
    ZENON_WORKSPACE / "zenon-network" / "go-zenon",
]

# Embedded contract directories relative to go-zenon root
DEFINITION_DIR = "vm/embedded/definition"
IMPLEMENTATION_DIR = "vm/embedded/implementation"
COMMON_TYPES_DIR = "common/types"

# Patterns for architectural analysis
SPORK_PATTERN = re.compile(
    r"(?:IsSporkActive|SporkAddress|spork|ActivateSpork)",
    re.IGNORECASE,
)
PLASMA_PATTERN = re.compile(
    r"(?:Plasma|plasma|GetPlasmaForBlock|FusePlasma|CancelFuse)",
    re.IGNORECASE,
)
DUAL_COIN_PATTERN = re.compile(
    r"(?:ZnnTokenStandard|QsrTokenStandard|znnZts|qsrZts)",
    re.IGNORECASE,
)
CONTRACT_ADDR_PATTERN = re.compile(
    r"(z1qxemdeddedx\w+)\s*=?\s*",
)
ABI_METHOD_PATTERN = re.compile(
    r'"name"\s*:\s*"(\w+)"',
)


def _read_file_text(filepath: Path, max_bytes: int = 500_000) -> str:
    """Read a text file, returning empty string on failure."""
    try:
        return filepath.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def _find_go_zenon() -> Path | None:
    """Find the best go-zenon directory (prefer core, then hypercore-one)."""
    for path in GO_ZENON_PATHS:
        if path.is_dir() and (path / "go.mod").is_file():
            return path
    return None


def extract_embedded_contracts(go_zenon: Path) -> list[dict]:
    """Extract all embedded contract definitions from go-zenon.

    Returns list of dicts with: name, file, address, methods, has_spork_gate.
    """
    contracts = []

    # Scan definition files
    def_dir = go_zenon / DEFINITION_DIR
    if not def_dir.is_dir():
        return contracts

    for go_file in sorted(def_dir.glob("*.go")):
        if go_file.name == "common.go" or go_file.name.endswith("_test.go"):
            continue

        text = _read_file_text(go_file)
        contract_name = go_file.stem

        # Extract contract address
        addresses = CONTRACT_ADDR_PATTERN.findall(text)

        # Extract ABI methods
        methods = ABI_METHOD_PATTERN.findall(text)

        # Check for spork gate
        has_spork = bool(SPORK_PATTERN.search(text))

        contracts.append(
            {
                "name": contract_name,
                "definition_file": str(go_file.relative_to(go_zenon)),
                "addresses": list(set(addresses)),
                "methods": sorted(set(methods)),
                "method_count": len(set(methods)),
                "has_spork_gate": has_spork,
            }
        )

    # Enrich with implementation data
    impl_dir = go_zenon / IMPLEMENTATION_DIR
    if impl_dir.is_dir():
        for contract in contracts:
            impl_file = impl_dir / f"{contract['name']}.go"
            if impl_file.is_file():
                text = _read_file_text(impl_file)
                contract["has_implementation"] = True
                contract["impl_lines"] = text.count("\n")
                contract["uses_plasma"] = bool(PLASMA_PATTERN.search(text))
                contract["uses_dual_coin"] = bool(DUAL_COIN_PATTERN.search(text))
            else:
                contract["has_implementation"] = False
                contract["impl_lines"] = 0

    return contracts


def extract_contract_dependencies(go_zenon: Path) -> dict[str, list[str]]:
    """Extract dependencies between embedded contracts.

    Reads implementation files and checks for cross-contract references
    (one contract calling another's methods or referencing its address).

    Returns dict mapping contract_name -> list of contract names it depends on.
    """
    deps: dict[str, list[str]] = defaultdict(list)

    impl_dir = go_zenon / IMPLEMENTATION_DIR
    def_dir = go_zenon / DEFINITION_DIR
    if not impl_dir.is_dir():
        return dict(deps)

    # Build a map of contract names to their addresses
    address_to_contract: dict[str, str] = {}
    for go_file in def_dir.glob("*.go"):
        name = go_file.stem
        text = _read_file_text(go_file)
        for addr in CONTRACT_ADDR_PATTERN.findall(text):
            address_to_contract[addr] = name

    # Scan implementations for cross-references
    for go_file in impl_dir.glob("*.go"):
        if go_file.name.endswith("_test.go"):
            continue
        contract_name = go_file.stem
        text = _read_file_text(go_file)

        # Check for references to other contracts' addresses
        for addr, ref_contract in address_to_contract.items():
            if ref_contract != contract_name and addr in text:
                if ref_contract not in deps[contract_name]:
                    deps[contract_name].append(ref_contract)

        # Check for imports of other contract definition packages
        for other_file in def_dir.glob("*.go"):
            other_name = other_file.stem
            if other_name == contract_name:
                continue
            # Look for references like "definition.ABIPtlc" or "PtlcAddress"
            capitalized = other_name.capitalize()
            if f"ABI{capitalized}" in text or f"{capitalized}Address" in text:
                if other_name not in deps[contract_name]:
                    deps[contract_name].append(other_name)

    return dict(deps)


def extract_architectural_patterns(go_zenon: Path) -> dict:
    """Extract high-level architectural patterns from go-zenon.

    Returns dict with pattern categories and their evidence.
    """
    patterns = {
        "spork_gated_contracts": [],
        "plasma_consuming_contracts": [],
        "dual_coin_contracts": [],
        "embedded_addresses": {},
        "go_module_version": None,
        "total_go_files": 0,
        "total_lines": 0,
    }

    # Count files and lines
    for go_file in go_zenon.rglob("*.go"):
        rel = str(go_file.relative_to(go_zenon))
        if "vendor" in rel or ".git" in rel:
            continue
        patterns["total_go_files"] += 1
        with contextlib.suppress(OSError):
            patterns["total_lines"] += go_file.read_text(errors="replace").count("\n")

    # Extract embedded addresses from common/types
    addr_file = go_zenon / COMMON_TYPES_DIR / "address.go"
    if addr_file.is_file():
        text = _read_file_text(addr_file)
        # Parse address constants
        for match in re.finditer(
            r'(\w+Address)\s*=\s*ParseAddressPanic\("(z1[a-z0-9]+)"\)',
            text,
        ):
            patterns["embedded_addresses"][match.group(1)] = match.group(2)

    # Go module version
    go_mod = go_zenon / "go.mod"
    if go_mod.is_file():
        text = _read_file_text(go_mod)
        ver_match = re.search(r"go\s+(\d+\.\d+)", text)
        if ver_match:
            patterns["go_module_version"] = ver_match.group(1)

    return patterns


def generate_report() -> dict:
    """Generate a full architecture analysis report."""
    go_zenon = _find_go_zenon()
    if not go_zenon:
        return {
            "error": "go-zenon not found in workspace",
            "searched_paths": [str(p) for p in GO_ZENON_PATHS],
        }

    contracts = extract_embedded_contracts(go_zenon)
    dependencies = extract_contract_dependencies(go_zenon)
    patterns = extract_architectural_patterns(go_zenon)

    # Classify contracts by category
    categories = {
        "financial": [],
        "governance": [],
        "infrastructure": [],
        "interop": [],
    }
    for c in contracts:
        name = c["name"].lower()
        if any(k in name for k in ["token", "stake", "plasma", "liquidity", "streaming"]):
            categories["financial"].append(c["name"])
        elif any(k in name for k in ["pillar", "sentinel", "accelerator", "spork", "governance"]):
            categories["governance"].append(c["name"])
        elif any(k in name for k in ["htlc", "ptlc", "swap", "portal", "bridge", "bitcoin"]):
            categories["interop"].append(c["name"])
        else:
            categories["infrastructure"].append(c["name"])

    # Enrich patterns with contract-level data
    for c in contracts:
        if c.get("has_spork_gate"):
            patterns["spork_gated_contracts"].append(c["name"])
        if c.get("uses_plasma"):
            patterns["plasma_consuming_contracts"].append(c["name"])
        if c.get("uses_dual_coin"):
            patterns["dual_coin_contracts"].append(c["name"])

    return {
        "go_zenon_path": str(go_zenon),
        "contracts": contracts,
        "contract_count": len(contracts),
        "dependencies": dependencies,
        "categories": categories,
        "patterns": patterns,
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run architecture analysis and persist findings to evidence table."""
    from core.persist_to_db import ensure_schema, persist_finding

    ensure_schema(db_path)
    count = 0

    report = generate_report()

    if "error" in report:
        searched = ", ".join(report.get("searched_paths", []))
        persist_finding(
            db_path=db_path,
            domain="investigation",
            engine="architecture_analyzer",
            evidence_type="architecture_error",
            finding=(
                f"WHAT: {report['error']}. "
                f"SO WHAT: Architecture analysis is blocked — no contract "
                f"data can be extracted without go-zenon source. "
                f"NOW WHAT: Clone or symlink go-zenon into one of: {searched}."
            ),
            confidence=0.50,
            raw_data=report,
            source_repo="go-zenon",
        )
        return 1

    # Overall architecture finding
    total_contracts = report["contract_count"]
    total_files = report["patterns"]["total_go_files"]
    total_lines = report["patterns"]["total_lines"]
    addr_count = len(report["patterns"]["embedded_addresses"])
    cat = report["categories"]
    persist_finding(
        db_path=db_path,
        domain="investigation",
        engine="architecture_analyzer",
        evidence_type="architecture_overview",
        finding=(
            f"WHAT: go-zenon has {total_contracts} embedded contracts across "
            f"{total_files} Go files (~{total_lines} lines), with {addr_count} "
            f"embedded addresses ({len(cat['financial'])} financial, "
            f"{len(cat['governance'])} governance, {len(cat['interop'])} interop, "
            f"{len(cat['infrastructure'])} infrastructure). "
            f"SO WHAT: This is the full contract surface area — SDK/CLI/docs "
            f"must cover all {total_contracts} contracts to reach upstream-ready. "
            f"NOW WHAT: Cross-reference against SDK coverage to find gaps; "
            f"prioritize interop contracts (bridge/PTLC) for upstream PRs."
        ),
        confidence=0.95,
        raw_data=report,
        source_repo="go-zenon",
    )
    count += 1

    # Persist per-contract findings
    for contract in report["contracts"]:
        deps = report["dependencies"].get(contract["name"], [])
        has_impl = contract.get("has_implementation", False)
        spork_gated = contract.get("has_spork_gate", False)
        name = contract["name"]
        method_count = contract["method_count"]

        issues = []
        if not has_impl:
            issues.append("missing implementation")
        if not spork_gated:
            issues.append("no spork gate")
        if deps:
            issues.append(f"depends on {', '.join(deps)}")

        if issues:
            now_what = f"Address: {'; '.join(issues)}."
        else:
            now_what = "Verify SDK/CLI coverage matches all methods."

        persist_finding(
            db_path=db_path,
            domain="investigation",
            engine="architecture_analyzer",
            evidence_type="contract_architecture",
            finding=(
                f"WHAT: Contract '{name}' has {method_count} ABI methods, "
                f"{'has' if has_impl else 'no'} implementation, "
                f"{'spork-gated' if spork_gated else 'not spork-gated'}. "
                f"SO WHAT: {'Fully wired — ready for SDK coverage check.' if has_impl and spork_gated else 'Incomplete — blocks upstream readiness.'} "
                f"NOW WHAT: {now_what}"
            ),
            confidence=0.90,
            raw_data={**contract, "dependencies": deps},
            source_repo="go-zenon",
        )
        count += 1

    # Persist dependency graph
    if report["dependencies"]:
        sorted_deps = sorted(
            report["dependencies"].items(),
            key=lambda x: len(x[1]),
            reverse=True,
        )
        most_connected = ", ".join(f"{k} ({len(v)} deps)" for k, v in sorted_deps[:5])
        dep_count = len(report["dependencies"])
        persist_finding(
            db_path=db_path,
            domain="investigation",
            engine="architecture_analyzer",
            evidence_type="dependency_graph",
            finding=(
                f"WHAT: {dep_count} contracts have cross-contract dependencies. "
                f"Most connected: {most_connected}. "
                f"SO WHAT: Highly connected contracts are riskier — a bug in a "
                f"dependency can cascade. These need priority security review. "
                f"NOW WHAT: Run /verify deep on the top-3 most connected "
                f"contracts first; test cross-contract interactions."
            ),
            confidence=0.90,
            raw_data={"dependencies": report["dependencies"]},
            source_repo="go-zenon",
        )
        count += 1

    logger.info("ArchitectureAnalyzer: persisted %d findings", count)
    return count
