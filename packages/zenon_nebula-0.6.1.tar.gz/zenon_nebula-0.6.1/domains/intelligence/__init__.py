# SPDX-License-Identifier: MIT
"""Intelligence domain -- ecosystem monitoring, signal detection, and routing."""

from domains.intelligence.domain import IntelligenceDomain

__all__ = ["IntelligenceDomain"]
