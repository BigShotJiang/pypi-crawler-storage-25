# SPDX-License-Identifier: MIT
"""Intelligence domain templates -- discovery and analysis report templates."""
