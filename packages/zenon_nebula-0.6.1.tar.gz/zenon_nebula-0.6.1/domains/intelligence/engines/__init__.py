# SPDX-License-Identifier: MIT
"""Intelligence domain engines -- signal detector, signal router, upstream watcher, and ecosystem health."""
