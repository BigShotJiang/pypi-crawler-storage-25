# SPDX-License-Identifier: MIT
"""
EcosystemHealth - Queries ecosystem metrics for the Zenon network.

Pulls live on-chain metrics directly from a Zenon node via
:mod:`core.zenon_data` (HTTP JSON-RPC). Also collects local workspace
proxy metrics (repo counts, spec counts, wiki pages) for engines that
need to operate without network access.

Tracks: node count, staking ratio, bridge TVL, active pillars,
active sentinels, delegation weight, and momentum height.
"""

import contextlib
import logging
import os
import sqlite3
import subprocess
from pathlib import Path

from core.persist_to_db import persist_metric, query_table
from core.persistence import connect
from core.zenon_data import get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")


def _workspace_root() -> Path:
    """Return the Zenon workspace root.

    Prefers ``ZENON_WORKSPACE_ROOT`` env var so Nebula remains portable.
    Falls back to two levels above the nebula checkout (``zenon-org/nebula``).
    """
    env_root = os.environ.get("ZENON_WORKSPACE_ROOT")
    if env_root:
        p = Path(env_root).expanduser()
        if p.is_dir():
            return p
    return ENGINE_ROOT.parents[1]


ZENON_WORKSPACE = _workspace_root()


def _persist_metric(db_path: str, metric_name: str, metric_value: float, source: str) -> int:
    """Persist a single metric to the ecosystem_metrics table."""
    return persist_metric(
        db_path=db_path,
        table="ecosystem_metrics",
        data={
            "metric_name": metric_name,
            "metric_value": metric_value,
            "source": source,
        },
    )


def _get_latest_metric(db_path: str, metric_name: str) -> dict | None:
    """Get the most recent value for a metric."""
    rows = query_table(
        db_path=db_path,
        table="ecosystem_metrics",
        where="metric_name = ?",
        params=(metric_name,),
        order_by="timestamp DESC",
        limit=1,
    )
    return rows[0] if rows else None


def _fetch_node_stats() -> dict | None:
    """Return live Zenon network stats via JSON-RPC.

    Pulls momentum height, pillar count, and sentinel count directly.
    Returns ``None`` when the node is unreachable.
    """
    rpc = get_zenon_data()
    if not rpc.is_reachable():
        return None
    momentum = rpc.get_frontier_momentum() or {}
    pillar_count = rpc.get_pillar_count()
    sentinel_count = rpc.get_sentinel_count()
    return {
        "momentum_height": momentum.get("height"),
        "pillar_count": pillar_count,
        "sentinel_count": sentinel_count,
    }


# -- Local fallback data sources --


def _count_local_repos() -> int:
    """Count the number of Zenon-related repos in the workspace."""
    count = 0
    workspace = ZENON_WORKSPACE
    if not workspace.is_dir():
        return 0
    for org_dir in workspace.iterdir():
        if not org_dir.is_dir() or org_dir.name.startswith("."):
            continue
        for repo_dir in org_dir.iterdir():
            if repo_dir.is_dir() and (repo_dir / ".git").is_dir():
                count += 1
    return count


def _count_go_zenon_definitions() -> int:
    """Count embedded contract definitions as a proxy for protocol scope."""
    definition_dirs = [
        ZENON_WORKSPACE / "core" / "go-zenon" / "vm" / "embedded" / "definition",
        ZENON_WORKSPACE / "zenon-network" / "go-zenon" / "vm" / "embedded" / "definition",
        ZENON_WORKSPACE / "hypercore-one" / "go-zenon" / "vm" / "embedded" / "definition",
    ]
    max_count = 0
    for d in definition_dirs:
        if d.is_dir():
            count = sum(1 for f in d.iterdir() if f.suffix == ".go" and f.name != "common.go")
            max_count = max(max_count, count)
    return max_count


def _count_specs() -> int:
    """Count specs in developer-commons."""
    specs_dir = ZENON_WORKSPACE / "knowledge" / "developer-commons" / "docs" / "specs"
    if not specs_dir.is_dir():
        return 0
    count = 0
    for entry in specs_dir.iterdir():
        if entry.is_dir() and not entry.name.startswith("."):
            count += 1
    return count


def _count_wiki_pages() -> int:
    """Count wiki pages as a proxy for documentation coverage."""
    wiki_dir = ZENON_WORKSPACE / "knowledge" / "znn-wiki"
    if not wiki_dir.is_dir():
        return 0
    return sum(1 for f in wiki_dir.iterdir() if f.suffix == ".md")


def _estimate_active_repos() -> int:
    """Count repos that had commits in the last 90 days."""
    active = 0
    workspace = ZENON_WORKSPACE
    if not workspace.is_dir():
        return 0
    for org_dir in workspace.iterdir():
        if not org_dir.is_dir() or org_dir.name.startswith("."):
            continue
        for repo_dir in org_dir.iterdir():
            if not repo_dir.is_dir() or not (repo_dir / ".git").is_dir():
                continue
            try:
                result = subprocess.run(
                    ["git", "-C", str(repo_dir), "log", "-1", "--since=90 days ago", "--format=%H"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode == 0 and result.stdout.strip():
                    active += 1
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass
    return active


def _get_latest_momentum_height() -> int | None:
    """Return the latest momentum height, or ``None`` when unavailable."""
    return get_zenon_data().get_height()


def collect_metrics_from_api(db_path: str = DEFAULT_DB) -> dict[str, float]:
    """Collect live network metrics via the Zenon RPC.

    Returns a dict of metric name -> value for metrics successfully
    retrieved. Empty when the node is unreachable.
    """
    metrics: dict[str, float] = {}
    stats = _fetch_node_stats()
    if not stats:
        return metrics
    if stats.get("momentum_height") is not None:
        with contextlib.suppress(TypeError, ValueError):
            metrics["momentum_height"] = float(stats["momentum_height"])
    if stats.get("pillar_count") is not None:
        with contextlib.suppress(TypeError, ValueError):
            metrics["active_pillars"] = float(stats["pillar_count"])
    if stats.get("sentinel_count") is not None:
        with contextlib.suppress(TypeError, ValueError):
            metrics["active_sentinels"] = float(stats["sentinel_count"])
    for name, value in metrics.items():
        _persist_metric(db_path, name, value, "zenon_rpc")
    return metrics


def collect_metrics_from_local(db_path: str = DEFAULT_DB) -> dict[str, float]:
    """Collect metrics from local workspace data as a fallback.

    These are proxy metrics derived from the local repo structure.
    """
    metrics: dict[str, float] = {}

    total_repos = _count_local_repos()
    metrics["total_repos"] = float(total_repos)

    active_repos = _estimate_active_repos()
    metrics["active_repos_90d"] = float(active_repos)

    definitions = _count_go_zenon_definitions()
    metrics["embedded_contracts"] = float(definitions)

    specs = _count_specs()
    metrics["spec_count"] = float(specs)

    wiki_pages = _count_wiki_pages()
    metrics["wiki_pages"] = float(wiki_pages)

    # Persist
    for name, value in metrics.items():
        _persist_metric(db_path, name, value, "local_workspace")

    return metrics


def collect_all_metrics(db_path: str = DEFAULT_DB) -> dict[str, float]:
    """Collect all available metrics, trying API first, then falling back to local.

    Returns combined dict of all metrics collected.
    """
    all_metrics: dict[str, float] = {}

    # Try API
    api_metrics = collect_metrics_from_api(db_path)
    all_metrics.update(api_metrics)

    # Always collect local metrics (different metric names)
    local_metrics = collect_metrics_from_local(db_path)
    all_metrics.update(local_metrics)

    source = "api+local" if api_metrics else "local_only"
    logger.info(
        "EcosystemHealth: collected %d metrics (source=%s)",
        len(all_metrics),
        source,
    )

    return all_metrics


def refresh_ecosystem_health(db_path: str = DEFAULT_DB, **_kw) -> dict:
    """Scheduler entry point: refresh all ecosystem health metrics.

    Wraps ``collect_all_metrics`` so the engine scheduler can discover
    a standard ``refresh_*`` entry point. Returns the same dict as
    ``collect_all_metrics`` plus the count.
    """
    metrics = collect_all_metrics(db_path)
    return {
        "engine": "ecosystem_health",
        "metric_count": len(metrics),
        "metrics": metrics,
    }


def get_health_summary(db_path: str = DEFAULT_DB) -> dict:
    """Get a summary of the latest ecosystem health metrics.

    Returns a dict with the latest value for each metric and its age.
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT metric_name,
                      metric_value,
                      source,
                      MAX(timestamp) as latest_timestamp
            FROM ecosystem_metrics
            GROUP BY metric_name
            ORDER BY metric_name"""
        ).fetchall()
        return {
            row["metric_name"]: {
                "value": row["metric_value"],
                "source": row["source"],
                "timestamp": row["latest_timestamp"],
            }
            for row in rows
        }
    finally:
        conn.close()
