# SPDX-License-Identifier: MIT
"""
SignalDetector -- Classifies incoming intelligence signals.

Reads raw signals from the upstream_watcher and classifies them to
determine which domain should care. Supports both rule-based and
LLM-assisted classification.

Tags applied:
    spec_change, security_relevant, breaking_change, new_contributor,
    new_feature, bug_fix, refactor, docs_change, governance_related
"""

import json
import logging
import re
from pathlib import Path

from core.persist_to_db import query_table
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Files that indicate spec-level changes
SPEC_FILE_PATTERNS = [
    re.compile(r"vm/embedded/definition/", re.IGNORECASE),
    re.compile(r"vm/embedded/implementation/", re.IGNORECASE),
    re.compile(r"abi/", re.IGNORECASE),
    re.compile(r"spec", re.IGNORECASE),
]

# Files that indicate security-relevant changes
SECURITY_FILE_PATTERNS = [
    re.compile(r"(crypto|sign|verify|hash|key|auth)", re.IGNORECASE),
    re.compile(r"bridge", re.IGNORECASE),
    re.compile(r"consensus", re.IGNORECASE),
]

# Files indicating governance changes
GOVERNANCE_FILE_PATTERNS = [
    re.compile(r"(accelerator|pillar|sentinel|vote|governance)", re.IGNORECASE),
]

# Known contributors (expanded as the system learns)
KNOWN_CONTRIBUTORS: set[str] = set()


def get_unprocessed_signals(db_path: str = DEFAULT_DB, limit: int = 100) -> list[dict]:
    """Get unprocessed signals from the intelligence_signals table."""
    return query_table(
        db_path=db_path,
        table="intelligence_signals",
        where="processed = FALSE AND signal_type != 'commit_checkpoint'",
        order_by="timestamp ASC",
        limit=limit,
    )


def _mark_processed(db_path: str, signal_id: int, routed_to: str = "") -> None:
    """Mark a signal as processed and optionally update routing."""
    conn = connect(db_path)
    try:
        if routed_to:
            conn.execute(
                """UPDATE intelligence_signals
                SET processed = TRUE, routed_to_domain = ?
                WHERE id = ?""",
                (routed_to, signal_id),
            )
        else:
            conn.execute(
                "UPDATE intelligence_signals SET processed = TRUE WHERE id = ?",
                (signal_id,),
            )
        conn.commit()
    finally:
        conn.close()


def _check_new_contributor(author: str, db_path: str) -> bool:
    """Check if an author is new (not seen in previous signals)."""
    if author in KNOWN_CONTRIBUTORS:
        return False

    conn = connect(db_path)
    try:
        row = conn.execute(
            """SELECT COUNT(*) FROM intelligence_signals
            WHERE details LIKE ? AND signal_type != 'new_contributor'""",
            (f'%"author": "{author}"%',),
        ).fetchone()
        count = row[0] if row else 0
        if count > 1:
            KNOWN_CONTRIBUTORS.add(author)
            return False
        return True
    finally:
        conn.close()


def classify_signal(signal: dict, db_path: str = DEFAULT_DB) -> dict:
    """Classify a signal and determine routing.

    Applies rule-based classification using file paths, commit messages,
    and author information.

    Returns:
        Dict with keys: signal_id, classifications, primary_domain, domains
    """
    signal_id = signal.get("id")
    raw_details = signal.get("details", "{}")
    if isinstance(raw_details, str):
        try:
            details = json.loads(raw_details)
        except json.JSONDecodeError:
            details = {}
    else:
        details = raw_details

    classifications = []
    domains = set()
    files = details.get("files_changed", [])
    details.get("message", "")
    author = details.get("author", "")
    existing_tags = details.get("tags", [])

    # Carry forward upstream_watcher tags
    classifications.extend(existing_tags)

    # File-based classification
    for filepath in files:
        for pattern in SPEC_FILE_PATTERNS:
            if pattern.search(filepath):
                if "spec_change" not in classifications:
                    classifications.append("spec_change")
                domains.add("development")
                domains.add("standards")
                break

        for pattern in SECURITY_FILE_PATTERNS:
            if pattern.search(filepath):
                if "security_relevant" not in classifications:
                    classifications.append("security_relevant")
                domains.add("security")
                break

        for pattern in GOVERNANCE_FILE_PATTERNS:
            if pattern.search(filepath):
                if "governance_related" not in classifications:
                    classifications.append("governance_related")
                domains.add("governance")
                break

    # Check for new contributor
    if author and _check_new_contributor(author, db_path):
        classifications.append("new_contributor")
        domains.add("contribution")

    # Default domain routing based on signal type
    base_type = signal.get("signal_type", "general_change")
    routing_defaults = {
        "spec_change": ["development", "standards"],
        "breaking_change": ["development", "security"],
        "new_feature": ["development", "marketing"],
        "bug_fix": ["development"],
        "security_relevant": ["security"],
        "docs_change": ["development"],
        "refactor": ["development"],
        "general_change": ["development"],
    }
    for default_domain in routing_defaults.get(base_type, ["development"]):
        domains.add(default_domain)

    # Deduplicate classifications
    classifications = list(dict.fromkeys(classifications))

    primary_domain = "development"
    if "security_relevant" in classifications:
        primary_domain = "security"
    elif "spec_change" in classifications:
        primary_domain = "development"
    elif "governance_related" in classifications:
        primary_domain = "governance"
    elif "new_contributor" in classifications:
        primary_domain = "contribution"

    return {
        "signal_id": signal_id,
        "classifications": classifications,
        "primary_domain": primary_domain,
        "domains": sorted(domains),
        "details": details,
    }


def process_signals(db_path: str = DEFAULT_DB, limit: int = 100) -> list[dict]:
    """Process all unprocessed signals: classify and update routing.

    Returns list of classified signal dicts.
    """
    raw_signals = get_unprocessed_signals(db_path, limit)
    classified = []

    for signal in raw_signals:
        result = classify_signal(signal, db_path)
        routed_to = ",".join(result["domains"])
        _mark_processed(db_path, result["signal_id"], routed_to)
        classified.append(result)

    logger.info(
        "SignalDetector: processed %d signals, classified %d",
        len(raw_signals),
        len(classified),
    )
    return classified
