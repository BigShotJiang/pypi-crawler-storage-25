# SPDX-License-Identifier: MIT
"""
RepoRelationshipMapper -- cross-repo dependency and fork drift tracker.

Uses :mod:`core.repo_graph` to build a workspace-wide dependency graph,
persists it into ``repo_dependencies``, detects upstream/fork pairs via
``git remote -v``, and raises findings for:

- Stale fork sync — a local fork whose HEAD is noticeably behind its
  declared upstream remote.
- Version drift — multiple dependents referencing the same workspace
  repo with conflicting version strings.

This engine activates on every cycle but degrades gracefully to an
empty result when no workspace is available. All findings follow the
WHAT / SO WHAT / NOW WHAT format and cap confidence at 0.6 since every
signal here is a heuristic over manifest data.
"""

from __future__ import annotations

import logging
import os
import subprocess
from collections import defaultdict
from pathlib import Path

from core.persist_to_db import persist_finding
from core.persistence.schema import DEFAULT_DB
from core.repo_graph import (
    build_dependency_graph,
    find_upstream_forks,
    graph_summary,
    persist_graph,
)
from core.workspace import workspace_root

logger = logging.getLogger(__name__)


# Heuristic confidence caps for this engine. Manifest parsing can't know
# whether a declared version is *actually* stale, so we stay conservative.
_MAX_CONFIDENCE = 0.6


def _resolve_workspace(workspace_override: str | None) -> str | None:
    """Resolve the workspace root honoring an explicit override first.

    When the caller passes an explicit ``workspace_override``, we honor
    that path verbatim — if it does not exist, we return ``None`` rather
    than silently falling back to the environment or discovery default.
    This lets tests (and callers that want to sandbox the engine) pass
    a nonexistent path to get a quick ``{}`` response.
    """
    if workspace_override:
        candidate = Path(workspace_override).expanduser()
        return str(candidate.resolve()) if candidate.exists() else None
    env = os.environ.get("ZENON_WORKSPACE_ROOT")
    if env and Path(env).exists():
        return str(Path(env).resolve())
    root = workspace_root()
    return str(root) if root is not None else None


def _fork_behind_upstream(repo_path: Path, timeout: int = 10) -> int | None:
    """Return how many commits local HEAD is behind ``upstream/HEAD``.

    Returns ``None`` when the information is unavailable (missing git,
    no upstream remote cached locally, etc.). Non-zero means the fork
    is lagging.
    """
    try:
        result = subprocess.run(
            [
                "git",
                "-C",
                str(repo_path),
                "rev-list",
                "--left-right",
                "--count",
                "HEAD...upstream/HEAD",
            ],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
        logger.debug("rev-list failed for %s: %s", repo_path, exc)
        return None
    if result.returncode != 0:
        return None
    try:
        _ahead, behind = result.stdout.strip().split()
        return int(behind)
    except (ValueError, AttributeError):
        return None


def _emit_version_drift_findings(graph: dict, db_path: str) -> int:
    """Emit findings for dependents pinning conflicting versions of a repo."""
    by_target: dict[str, dict[str, set[str]]] = defaultdict(
        lambda: defaultdict(set),
    )
    for edge in graph.get("edges") or []:
        target = edge.get("target")
        version = edge.get("version") or "unknown"
        source = edge.get("source", "")
        if not target or not source:
            continue
        by_target[target][version].add(source)

    emitted = 0
    for target_repo, by_version in by_target.items():
        # More than one distinct version -> drift candidate.
        if len(by_version) <= 1:
            continue
        version_list = sorted(by_version.keys())
        sources = sorted({src for versions in by_version.values() for src in versions})
        finding_text = (
            f"WHAT: {len(sources)} workspace repos reference '{target_repo}' "
            f"using {len(version_list)} distinct version strings: "
            f"{', '.join(version_list)}. "
            f"SO WHAT: Version drift between dependents makes cross-repo "
            f"upgrades risky — consumers pinned to different versions may "
            f"disagree on ABIs, JSON shapes, or constants. "
            f"NOW WHAT: Align dependents on a single target version or "
            f"document the intentional split. Affected: {', '.join(sources)}."
        )
        persist_finding(
            db_path=db_path,
            domain="intelligence",
            engine="repo_relationship_mapper",
            evidence_type="version_drift",
            finding=finding_text,
            confidence=_MAX_CONFIDENCE,
            raw_data={
                "target_repo": target_repo,
                "versions": {v: sorted(s) for v, s in by_version.items()},
            },
            source_repo=target_repo,
        )
        emitted += 1
    return emitted


def _find_repo_by_name(workspace: Path, fork_name: str) -> Path | None:
    """Locate a repo by name within the workspace, bounded to 4 levels deep.

    Avoids ``rglob`` so we don't walk unbounded real trees during
    scheduled runs. Returns the first directory whose name matches and
    contains a ``.git`` directory.
    """
    for depth in range(1, 5):
        pattern = "/".join(["*"] * depth) + f"/{fork_name}"
        for candidate in workspace.glob(pattern):
            if candidate.is_dir() and (candidate / ".git").exists():
                return candidate
    # Also check at the workspace root itself.
    direct = workspace / fork_name
    if direct.is_dir() and (direct / ".git").exists():
        return direct
    return None


def _emit_stale_fork_findings(
    pairs: list[tuple[str, str]],
    workspace: str,
    db_path: str,
) -> int:
    """Emit findings for forks that are behind their configured upstream."""
    emitted = 0
    workspace_path = Path(workspace)
    if not workspace_path.is_dir():
        return 0
    for fork_name, upstream_url in pairs:
        repo_path = _find_repo_by_name(workspace_path, fork_name)
        if repo_path is None:
            continue
        behind = _fork_behind_upstream(repo_path)
        if behind is None or behind <= 0:
            continue
        finding_text = (
            f"WHAT: Fork '{fork_name}' is {behind} commit(s) behind its "
            f"configured upstream '{upstream_url}'. "
            f"SO WHAT: Stale forks miss upstream security fixes, spec "
            f"updates, and bug patches. The longer the drift, the harder "
            f"a future merge becomes. "
            f"NOW WHAT: Run 'git fetch upstream && git merge upstream/<branch>' "
            f"on the fork, resolve conflicts, and re-run /verify before "
            f"pushing."
        )
        persist_finding(
            db_path=db_path,
            domain="intelligence",
            engine="repo_relationship_mapper",
            evidence_type="stale_fork",
            finding=finding_text,
            confidence=min(_MAX_CONFIDENCE, 0.3 + min(behind, 30) / 100),
            raw_data={
                "fork": fork_name,
                "upstream": upstream_url,
                "commits_behind": behind,
            },
            source_repo=fork_name,
        )
        emitted += 1
    return emitted


def _emit_graph_summary_finding(
    graph: dict,
    fork_pairs: list[tuple[str, str]],
    db_path: str,
) -> None:
    """Persist a single batched summary finding describing the graph."""
    summary = graph_summary(graph)
    nodes = summary.get("nodes", 0)
    edges = summary.get("edges", 0)
    resolved = summary.get("resolved_edges", 0)
    finding_text = (
        f"WHAT: Dependency graph built for workspace with {nodes} repos, "
        f"{edges} dependency edges ({resolved} resolved to workspace repos) "
        f"and {len(fork_pairs)} fork/upstream pairs. "
        f"SO WHAT: Downstream engines now have a queryable substrate for "
        f"change-impact analysis, version-drift detection and fork-sync "
        f"monitoring. "
        f"NOW WHAT: Use get_dependents(repo_name) from core.repo_graph to "
        f"route impact notifications when an upstream repo changes."
    )
    persist_finding(
        db_path=db_path,
        domain="intelligence",
        engine="repo_relationship_mapper",
        evidence_type="graph_summary",
        finding=finding_text,
        confidence=_MAX_CONFIDENCE,
        raw_data=summary,
    )


def refresh_relationships(
    db_path: str = DEFAULT_DB,
    workspace: str | None = None,
    **_: object,
) -> dict:
    """Rebuild the repo graph and persist cross-repo findings.

    Entry point for the autonomous scheduler. Returns an empty dict and
    degrades gracefully when no workspace is available.

    Args:
        db_path: SQLite database path.
        workspace: Optional override for the workspace root.

    Returns:
        Dict with counters for nodes, edges, forks, and findings emitted.
    """
    resolved_workspace = _resolve_workspace(workspace)
    if not resolved_workspace:
        logger.info("repo_relationship_mapper: no workspace available, skipping")
        return {}

    graph = build_dependency_graph(resolved_workspace)
    if not graph.get("nodes"):
        return {"nodes": 0, "edges": 0, "findings": 0}

    inserted = persist_graph(graph, db_path)
    fork_pairs = find_upstream_forks(resolved_workspace)

    drift_count = _emit_version_drift_findings(graph, db_path)
    stale_count = _emit_stale_fork_findings(fork_pairs, resolved_workspace, db_path)
    _emit_graph_summary_finding(graph, fork_pairs, db_path)

    return {
        "workspace": resolved_workspace,
        "nodes": len(graph.get("nodes") or []),
        "edges": len(graph.get("edges") or []),
        "edges_persisted": inserted,
        "fork_pairs": len(fork_pairs),
        "version_drift_findings": drift_count,
        "stale_fork_findings": stale_count,
        "findings": drift_count + stale_count + 1,
    }


# Scheduler-discoverable alias (prefix ``scan_``).
def scan_relationships(db_path: str = DEFAULT_DB, **kw: object) -> dict:
    """Alias wrapping :func:`refresh_relationships` for scheduler discovery."""
    return refresh_relationships(db_path=db_path, **kw)


__all__ = ["refresh_relationships", "scan_relationships"]
