# SPDX-License-Identifier: MIT
"""
SignalRouter -- Routes classified intelligence signals to domains via the feedback bus.

Reads classified signals from the signal_detector and posts them to the
feedback_bus with the correct recipient_domain. Configurable signal_type
to domain mapping.
"""

import json
import logging
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "repos.json"


def _load_routing_config() -> dict[str, list[str]]:
    """Load signal routing configuration."""
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH) as f:
            config = json.load(f)
            return config.get("signal_routing", {})
    return {}


# Default routing table (used if config not found)
DEFAULT_ROUTING: dict[str, list[str]] = {
    "spec_change": ["development", "standards"],
    "breaking_change": ["development", "security"],
    "new_feature": ["development", "marketing"],
    "bug_fix": ["development"],
    "security_relevant": ["security"],
    "new_contributor": ["contribution"],
    "governance_related": ["governance"],
    "docs_change": ["development"],
    "refactor": ["development"],
    "general_change": ["development"],
}


def get_routing_table() -> dict[str, list[str]]:
    """Get the current routing table (config overrides defaults)."""
    configured = _load_routing_config()
    merged = dict(DEFAULT_ROUTING)
    merged.update(configured)
    return merged


def route_signal(
    classified_signal: dict,
    bus,  # type: FeedbackBus (avoid import-time coupling to core.feedback_bus)
    routing_table: dict[str, list[str]] | None = None,
) -> list[str]:
    """Route a single classified signal to recipient domains via the feedback bus.

    Args:
        classified_signal: Output from signal_detector.classify_signal().
        bus: FeedbackBus instance.
        routing_table: Optional override for routing config.

    Returns:
        List of message IDs posted to the bus.
    """
    if routing_table is None:
        routing_table = get_routing_table()

    classifications = classified_signal.get("classifications", [])
    details = classified_signal.get("details", {})
    signal_id = classified_signal.get("signal_id")

    # Collect all target domains from all classifications
    target_domains: set[str] = set()
    for classification in classifications:
        targets = routing_table.get(classification, ["development"])
        target_domains.update(targets)

    # Also include explicitly listed domains from classifier
    for domain in classified_signal.get("domains", []):
        target_domains.add(domain)

    message_ids = []
    for domain in sorted(target_domains):
        payload = {
            "signal_id": signal_id,
            "classifications": classifications,
            "source_repo": details.get("repo", "unknown"),
            "commit_hash": details.get("commit_hash", ""),
            "author": details.get("author", ""),
            "message": details.get("message", ""),
            "files_changed": details.get("files_changed", []),
        }

        msg_id = bus.post(
            sender="intelligence.signal_router",
            recipient=f"domain.{domain}",
            message_type="signal",
            data=payload,
            domain="intelligence",
        )
        message_ids.append(msg_id)
        logger.debug(
            "Routed signal %s to domain.%s (msg_id=%s)",
            signal_id,
            domain,
            msg_id,
        )

    return message_ids


def route_all(classified_signals: list[dict], db_path: str = DEFAULT_DB) -> dict[str, int]:
    """Route all classified signals via the feedback bus.

    Args:
        classified_signals: List of outputs from signal_detector.process_signals().
        db_path: Database path for the feedback bus.

    Returns:
        Dict mapping domain name to number of signals routed to it.
    """
    from core.feedback_bus import FeedbackBus

    bus = FeedbackBus(db_path)
    routing_table = get_routing_table()

    domain_counts: dict[str, int] = {}

    for signal in classified_signals:
        route_signal(signal, bus, routing_table)

        for domain in signal.get("domains", []):
            domain_counts[domain] = domain_counts.get(domain, 0) + 1

    logger.info(
        "SignalRouter: routed %d signals to %d domains: %s",
        len(classified_signals),
        len(domain_counts),
        domain_counts,
    )
    return domain_counts


def process_pending_signals(db_path: str = DEFAULT_DB, **_kw) -> dict[str, int]:
    """Scheduler entry point: route any already-classified signals.

    Loads classified signals from the intelligence_signals table that
    have not yet been routed, posts them to the feedback bus, and
    marks them processed. Safe to call with no arguments.
    """
    import sqlite3

    try:
        conn = connect(db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT id, signal_type, details FROM intelligence_signals "
            "WHERE processed = 0 LIMIT 200"
        ).fetchall()
        conn.close()
    except Exception as exc:
        logger.debug("process_pending_signals: DB query failed: %s", exc)
        return {}

    classified: list[dict] = []
    for row in rows:
        try:
            details = json.loads(row["details"]) if row["details"] else {}
        except Exception:
            details = {}
        classified.append(
            {
                "id": row["id"],
                "signal_type": row["signal_type"],
                "domains": details.get("domains", []),
            }
        )

    if not classified:
        return {}
    return route_all(classified, db_path=db_path)
