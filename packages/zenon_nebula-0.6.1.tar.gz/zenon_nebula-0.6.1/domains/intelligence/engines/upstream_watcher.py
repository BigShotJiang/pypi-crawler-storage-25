# SPDX-License-Identifier: MIT
"""
UpstreamWatcher -- Monitors Zenon ecosystem repos for new commits.

Runs `git fetch` and `git log` on configured repositories to detect
new commits since the last check. Classifies each commit by type
(new spec, feature, bug fix, refactor) and persists signals to the
intelligence_signals table.
"""

import json
import logging
import os
import re
import subprocess
from pathlib import Path

from core.persist_to_db import persist_finding, persist_metric, query_table

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "repos.json"

# Patterns for commit classification
SPEC_PATTERNS = re.compile(
    r"(spec|specification|zip[-_]?\d+|proposal|rfc)",
    re.IGNORECASE,
)
FEATURE_PATTERNS = re.compile(
    r"(feat|feature|add|implement|introduce|new)",
    re.IGNORECASE,
)
BUGFIX_PATTERNS = re.compile(
    r"(fix|bug|patch|hotfix|resolve|repair|correct)",
    re.IGNORECASE,
)
REFACTOR_PATTERNS = re.compile(
    r"(refactor|clean|reorganize|restructure|simplify|rename)",
    re.IGNORECASE,
)
SECURITY_PATTERNS = re.compile(
    r"(security|vuln|cve|exploit|overflow|injection|sanitize)",
    re.IGNORECASE,
)
BREAKING_PATTERNS = re.compile(
    r"(break|incompatible|deprecat|remov|drop\s+support)",
    re.IGNORECASE,
)
DOCS_PATTERNS = re.compile(
    r"(doc|readme|wiki|comment|changelog|license)",
    re.IGNORECASE,
)


def _resolve_workspace_path(raw_path: str) -> str:
    """Resolve $ZENON_WORKSPACE in a path to the actual workspace root."""
    if "$ZENON_WORKSPACE" in raw_path:
        workspace = os.environ.get(
            "ZENON_WORKSPACE",
            str(ENGINE_ROOT.parents[1]),  # Default: two levels above engine root
        )
        return raw_path.replace("$ZENON_WORKSPACE", workspace)
    return raw_path


def _load_config() -> dict:
    """Load repo monitoring configuration."""
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH) as f:
            config = json.load(f)
        # Resolve workspace paths
        for repo_info in config.get("monitored_repos", {}).values():
            repo_info["paths"] = [_resolve_workspace_path(p) for p in repo_info.get("paths", [])]
        return config
    return {"monitored_repos": {}, "signal_routing": {}}


def _run_git(repo_path: str, *args: str, timeout: int = 30) -> tuple[int, str]:
    """Run a git command in the given repo. Returns (returncode, stdout)."""
    cmd = ["git", "-C", repo_path, *list(args)]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except subprocess.TimeoutExpired:
        logger.warning("Git command timed out: %s", " ".join(cmd))
        return 1, ""
    except FileNotFoundError:
        logger.error("git not found in PATH")
        return 1, ""


def classify_commit(message: str, files_changed: str = "") -> list[str]:
    """Classify a commit message into signal types.

    Returns a list of tags (a commit can match multiple types).
    """
    tags = []
    combined = f"{message} {files_changed}"

    if SPEC_PATTERNS.search(combined):
        tags.append("spec_change")
    if SECURITY_PATTERNS.search(combined):
        tags.append("security_relevant")
    if BREAKING_PATTERNS.search(combined):
        tags.append("breaking_change")
    if BUGFIX_PATTERNS.search(message):
        tags.append("bug_fix")
    elif FEATURE_PATTERNS.search(message):
        tags.append("new_feature")
    elif REFACTOR_PATTERNS.search(message):
        tags.append("refactor")
    elif DOCS_PATTERNS.search(combined):
        tags.append("docs_change")

    if not tags:
        tags.append("general_change")

    return tags


def _get_last_known_commit(db_path: str, repo_name: str, repo_path: str) -> str | None:
    """Get the last known commit hash for a repo from the DB."""
    try:
        rows = query_table(
            db_path=db_path,
            table="intelligence_signals",
            where="source = ? AND signal_type = 'commit_checkpoint'",
            params=(f"{repo_name}:{repo_path}",),
            order_by="timestamp DESC",
            limit=1,
        )
        if rows:
            data = json.loads(rows[0]["details"])
            return data.get("commit_hash")
    except Exception as exc:
        logger.debug("Failed to load last checkpoint for %s: %s", repo_name, exc)
    return None


def _save_checkpoint(db_path: str, repo_name: str, repo_path: str, commit_hash: str) -> None:
    """Save the current HEAD as a checkpoint."""
    persist_metric(
        db_path=db_path,
        table="intelligence_signals",
        data={
            "source": f"{repo_name}:{repo_path}",
            "signal_type": "commit_checkpoint",
            "details": json.dumps({"commit_hash": commit_hash}),
            "processed": True,
        },
    )


def _persist_signal(
    db_path: str, source: str, signal_type: str, details: dict, routed_to: str = ""
) -> int:
    """Persist a signal to the intelligence_signals table."""
    row_id = persist_metric(
        db_path=db_path,
        table="intelligence_signals",
        data={
            "source": source,
            "signal_type": signal_type,
            "details": json.dumps(details),
            "routed_to_domain": routed_to,
            "processed": False,
        },
    )
    return row_id if row_id > 0 else 0


def fetch_upstream(repo_path: str) -> bool:
    """Run git fetch on a repo. Tries 'upstream' remote first, then 'origin'.

    Returns True if fetch succeeded.
    """
    if not os.path.isdir(os.path.join(repo_path, ".git")):
        logger.debug("Not a git repo: %s", repo_path)
        return False

    # Try upstream first
    code, _ = _run_git(repo_path, "fetch", "upstream", timeout=60)
    if code != 0:
        # Fall back to origin
        code, _ = _run_git(repo_path, "fetch", "origin", timeout=60)

    return code == 0


def get_new_commits(
    repo_path: str, since_hash: str | None = None, max_commits: int = 50
) -> list[dict]:
    """Get new commits from a repo since a given hash.

    Returns list of dicts with keys: hash, author, date, message, files.
    """
    if not os.path.isdir(os.path.join(repo_path, ".git")):
        return []

    if since_hash:
        log_range = f"{since_hash}..HEAD"
    else:
        log_range = f"-{max_commits}"

    # Format: hash|author|date|subject
    fmt = "%H|%an|%aI|%s"
    code, output = _run_git(
        repo_path,
        "log",
        log_range,
        f"--format={fmt}",
        f"--max-count={max_commits}",
    )
    if code != 0 or not output:
        return []

    commits = []
    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        parts = line.split("|", 3)
        if len(parts) < 4:
            continue

        commit_hash, author, date, message = parts

        # Get changed files for this commit
        _, files_output = _run_git(
            repo_path,
            "diff-tree",
            "--no-commit-id",
            "--name-only",
            "-r",
            commit_hash,
        )

        commits.append(
            {
                "hash": commit_hash,
                "author": author,
                "date": date,
                "message": message,
                "files": files_output.split("\n") if files_output else [],
            }
        )

    return commits


def scan_repo(repo_name: str, repo_path: str, db_path: str = DEFAULT_DB) -> list[dict]:
    """Scan a single repo for new commits and classify them.

    Returns list of signal dicts that were persisted.
    """
    from core.git_cache import has_repo_changed

    if not os.path.isdir(repo_path):
        logger.debug("Repo path does not exist: %s", repo_path)
        return []

    if not has_repo_changed(repo_path):
        logger.debug("Skipping %s — HEAD unchanged", repo_path)
        return []

    signals = []
    last_hash = _get_last_known_commit(db_path, repo_name, repo_path)

    commits = get_new_commits(repo_path, since_hash=last_hash)
    if not commits:
        return []

    for commit in commits:
        files_str = " ".join(commit["files"])
        tags = classify_commit(commit["message"], files_str)

        for tag in tags:
            details = {
                "repo": repo_name,
                "repo_path": repo_path,
                "commit_hash": commit["hash"],
                "author": commit["author"],
                "date": commit["date"],
                "message": commit["message"],
                "files_changed": commit["files"][:20],  # Limit file list
                "tags": tags,
            }
            signal_id = _persist_signal(
                db_path,
                f"{repo_name}:{repo_path}",
                tag,
                details,
            )
            details["signal_id"] = signal_id
            signals.append(details)

    # Save checkpoint at the latest commit
    if commits:
        _save_checkpoint(db_path, repo_name, repo_path, commits[0]["hash"])

    logger.info(
        "UpstreamWatcher: %s (%s) -- %d new commits, %d signals",
        repo_name,
        repo_path,
        len(commits),
        len(signals),
    )

    # Persist actionable findings to unified evidence table
    # Group signals by tag to produce batched, contextual findings
    _persist_actionable_signals(signals, repo_name, db_path)

    return signals


def _assess_impact(signal: dict, repo_name: str) -> tuple[str, str]:
    """Assess SO WHAT and NOW WHAT for a signal based on its tags and context.

    Returns (so_what, now_what) strings.
    """
    tags = signal.get("tags", [])
    signal.get("message", "")
    author = signal.get("author", "unknown")
    files = signal.get("files_changed", [])
    files_str = ", ".join(files[:5])

    # Determine which of OUR work might be affected
    affected_areas = []
    for f in files:
        if "vm/embedded" in f:
            affected_areas.append("embedded contracts")
        if "rpc" in f or "api" in f:
            affected_areas.append("RPC API")
        if "consensus" in f:
            affected_areas.append("consensus")
        if "common/" in f:
            affected_areas.append("shared types/utils")
    affected_areas = sorted(set(affected_areas))

    if "security_relevant" in tags:
        so_what = (
            f"Security-relevant change by {author}. "
            f"If this patches a vulnerability, our fork may be affected. "
            f"If this changes security assumptions, our contracts may "
            f"need updating."
        )
        now_what = (
            f"Action: review commit immediately. Check if our "
            f"feature branches need the same fix. "
            f"Files: {files_str}"
        )
    elif "breaking_change" in tags:
        so_what = (
            f"Breaking change by {author} affecting "
            f"{', '.join(affected_areas) if affected_areas else 'unknown area'}. "
            f"Our feature branches may not compile or function "
            f"correctly after merging upstream."
        )
        now_what = (
            "Action: rebase our feature branches onto latest "
            "upstream and fix conflicts. Test compilation and "
            "run tests after rebase."
        )
    elif "spec_change" in tags:
        so_what = (
            f"Spec or proposal change by {author}. If this modifies "
            f"a spec we are implementing, our implementation may be "
            f"out of date."
        )
        now_what = (
            f"Action: diff the spec against our local copy. If "
            f"changed, update our implementation to match. "
            f"Files: {files_str}"
        )
    elif "new_feature" in tags and affected_areas:
        so_what = (
            f"New feature by {author} touching "
            f"{', '.join(affected_areas)}. This may introduce new "
            f"patterns, APIs, or contract methods we should adopt."
        )
        now_what = (
            "Action: review the feature for patterns we should "
            "follow. Check if it overlaps with our work. "
            "If it touches embedded contracts, update our SDK "
            "coverage matrix."
        )
    elif "bug_fix" in tags:
        so_what = (
            f"Bug fix by {author}. If this fixes a bug in code "
            f"we forked, our fork has the same bug."
        )
        now_what = (
            "Action: cherry-pick or merge the fix into our fork. Verify the fix applies cleanly."
        )
    else:
        so_what = (
            f"Change by {author} in {repo_name}"
            f"{' touching ' + ', '.join(affected_areas) if affected_areas else ''}."
        )
        now_what = "Action: no immediate action needed. Track for awareness."

    return so_what, now_what


def _persist_actionable_signals(
    signals: list[dict],
    repo_name: str,
    db_path: str,
) -> None:
    """Persist signals as actionable findings answering WHAT/SO WHAT/NOW WHAT."""
    if not signals:
        return

    # Group by unique commit to avoid duplicate findings
    seen_commits = set()
    for signal in signals:
        commit_hash = signal.get("commit_hash", "")
        if commit_hash in seen_commits:
            continue
        seen_commits.add(commit_hash)

        tags = signal.get("tags", ["general_change"])
        message = signal.get("message", "")
        author = signal.get("author", "unknown")
        files = signal.get("files_changed", [])

        # WHAT
        what = (
            f"[{repo_name}] {author} committed: '{message}' "
            f"({len(files)} file(s) changed). "
            f"Tags: {', '.join(tags)}."
        )

        # SO WHAT + NOW WHAT
        so_what, now_what = _assess_impact(signal, repo_name)

        finding = f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"

        # Higher confidence for security/breaking changes
        confidence = 0.7
        if "security_relevant" in tags:
            confidence = 0.9
        elif "breaking_change" in tags:
            confidence = 0.85

        persist_finding(
            db_path=db_path,
            domain="intelligence",
            engine="upstream_watcher",
            evidence_type=tags[0] if tags else "general_change",
            finding=finding,
            confidence=confidence,
            raw_data=signal,
            source_repo=repo_name,
            source_commit=commit_hash,
        )

    # Persist a batch summary if there are multiple commits
    if len(seen_commits) > 1:
        # Count by tag
        tag_counts: dict[str, int] = {}
        authors: set[str] = set()
        for s in signals:
            if s.get("commit_hash") in seen_commits:
                authors.add(s.get("author", "unknown"))
                for tag in s.get("tags", []):
                    tag_counts[tag] = tag_counts.get(tag, 0) + 1

        security_count = tag_counts.get("security_relevant", 0)
        breaking_count = tag_counts.get("breaking_change", 0)
        feature_count = tag_counts.get("new_feature", 0)

        summary_parts = [
            f"WHAT: {len(seen_commits)} new commits in {repo_name} "
            f"by {len(authors)} author(s) ({', '.join(sorted(authors))})."
        ]

        if security_count or breaking_count:
            summary_parts.append(
                f"SO WHAT: {security_count} security-relevant and "
                f"{breaking_count} breaking change(s) detected. "
                f"Our feature branches may need immediate attention."
            )
            summary_parts.append(
                "NOW WHAT: Review security/breaking commits first. "
                "Rebase feature branches if needed. Run tests after merge."
            )
        elif feature_count:
            summary_parts.append(
                f"SO WHAT: {feature_count} new feature(s) landed upstream. "
                f"May introduce new patterns or APIs to adopt."
            )
            summary_parts.append(
                "NOW WHAT: Review features for overlap with our work. Sync fork when convenient."
            )
        else:
            summary_parts.append("SO WHAT: Routine upstream activity. No urgent impact.")
            summary_parts.append("NOW WHAT: Sync fork at next session start.")

        persist_finding(
            db_path=db_path,
            domain="intelligence",
            engine="upstream_watcher",
            evidence_type="upstream_batch_summary",
            finding=" ".join(summary_parts),
            confidence=0.8,
            raw_data={"commit_count": len(seen_commits), "tag_counts": tag_counts},
            source_repo=repo_name,
        )


def scan_all(db_path: str = DEFAULT_DB, fetch: bool = False) -> dict[str, list[dict]]:
    """Scan all configured repos for new commits.

    Args:
        db_path: Path to the engine database.
        fetch: If True, run git fetch before scanning.

    Returns:
        Dict mapping repo_name to list of signals detected.
    """
    config = _load_config()
    all_signals: dict[str, list[dict]] = {}

    for repo_name, repo_info in config.get("monitored_repos", {}).items():
        for repo_path in repo_info.get("paths", []):
            if not os.path.isdir(repo_path):
                continue

            if fetch:
                fetch_upstream(repo_path)

            signals = scan_repo(repo_name, repo_path, db_path)
            if signals:
                key = f"{repo_name}:{repo_path}"
                all_signals[key] = signals

    total = sum(len(s) for s in all_signals.values())
    logger.info("UpstreamWatcher scan complete: %d signals from %d repos", total, len(all_signals))
    return all_signals


# ---------------------------------------------------------------------------
# Dynamic workspace-wide scanning (covers ALL repos, not just configured ones)
# ---------------------------------------------------------------------------

# Orgs to scan, ordered by priority (most important first)
PRIORITY_ORGS = [
    "core",
    "zenon-network",
    "hypercore-one",
    "HyperCore-Team",
    "zenonhub-io",
    "coordination",
    "community-sdks",
    "infrastructure",
    "knowledge",
    "zenon-org",
    "sol-znn",
    "digitalSloth",
    "georgezgeorgez",
    "DexterLabZ",
    "MoonBaZZe",
    "millerships",
    "investigation",
]

# Maximum repos to scan per cycle to avoid slowness.
# Sourced from config/engine_defaults.json with a safe fallback.
from core.config import get_config as _uw_get_config

MAX_REPOS_PER_CYCLE = _uw_get_config().engine("upstream_watcher").get("max_repos_per_cycle", 20)


def _discover_all_repos(workspace_root: str | None = None) -> list[dict]:
    """Discover all git repos in the workspace, sorted by priority.

    Uses workspace_discovery if available, falls back to direct scanning.
    Returns list of dicts with keys: name, path, org, priority.
    """
    root = Path(
        workspace_root or os.environ.get("ZENON_WORKSPACE_ROOT", "") or str(ENGINE_ROOT.parents[1])
    )
    if not root.exists():
        return []

    repos = []

    for org_idx, org in enumerate(PRIORITY_ORGS):
        org_dir = root / org
        if not org_dir.is_dir():
            continue

        # Scan for repos (up to 2 levels deep within org)
        for depth_pattern in ["*/.git", "*/*/.git"]:
            for git_dir in org_dir.glob(depth_pattern):
                repo_path = git_dir.parent
                repos.append(
                    {
                        "name": repo_path.name,
                        "path": str(repo_path),
                        "org": org,
                        "priority": org_idx,
                    }
                )

    # Also scan top-level repos not in any org directory
    for git_dir in root.glob("*/.git"):
        repo_path = git_dir.parent
        if repo_path.name not in PRIORITY_ORGS:
            repos.append(
                {
                    "name": repo_path.name,
                    "path": str(repo_path),
                    "org": "_root",
                    "priority": len(PRIORITY_ORGS),
                }
            )

    # Sort by priority (lowest number = highest importance)
    repos.sort(key=lambda r: r["priority"])
    return repos


def _get_repo_activity_score(repo_path: str) -> int:
    """Score a repo by recent activity. Higher = more active.

    Uses number of commits in last 30 days as a proxy.
    """
    code, output = _run_git(
        repo_path,
        "rev-list",
        "--count",
        "--since=30.days",
        "HEAD",
    )
    if code == 0 and output.strip().isdigit():
        return int(output.strip())
    return 0


def scan_all_dynamic(
    db_path: str = DEFAULT_DB,
    fetch: bool = False,
    max_repos: int = MAX_REPOS_PER_CYCLE,
    workspace_root: str | None = None,
    prioritize_active: bool = True,
) -> dict:
    """Scan ALL repos in the workspace dynamically — not just configured ones.

    This is the expanded version of scan_all() that covers the full workspace.
    Discovers repos via directory scanning, prioritizes by org importance and
    recent activity, and caps at max_repos per cycle to stay fast.

    Args:
        db_path:            Path to the engine database.
        fetch:              If True, run git fetch before scanning.
        max_repos:          Maximum number of repos to scan this cycle.
        workspace_root:     Override workspace root path.
        prioritize_active:  If True, sort recently-active repos first.

    Returns:
        Dict with signals, repos_scanned, repos_skipped, and summary.
    """
    all_repos = _discover_all_repos(workspace_root)
    total_discovered = len(all_repos)

    # Optionally re-sort by activity within each priority tier
    if prioritize_active and all_repos:
        # Sample activity scores for top candidates
        for repo in all_repos[: min(max_repos * 2, len(all_repos))]:
            repo["activity"] = _get_repo_activity_score(repo["path"])
        # Sort: primary by org priority, secondary by activity (descending)
        all_repos.sort(key=lambda r: (r["priority"], -r.get("activity", 0)))

    repos_to_scan = all_repos[:max_repos]
    repos_skipped = all_repos[max_repos:]

    all_signals: dict[str, list[dict]] = {}
    repos_scanned = []
    errors = []

    for repo in repos_to_scan:
        repo_name = f"{repo['org']}/{repo['name']}"
        repo_path = repo["path"]

        if not os.path.isdir(repo_path):
            continue

        try:
            if fetch:
                fetch_upstream(repo_path)

            signals = scan_repo(repo_name, repo_path, db_path)
            if signals:
                all_signals[repo_name] = signals

            repos_scanned.append(
                {
                    "name": repo_name,
                    "path": repo_path,
                    "signals": len(signals),
                }
            )
        except Exception as exc:
            errors.append({"repo": repo_name, "error": str(exc)})
            logger.warning(
                "UpstreamWatcher: error scanning %s: %s",
                repo_name,
                exc,
            )

    total_signals = sum(len(s) for s in all_signals.values())
    logger.info(
        "UpstreamWatcher dynamic scan: %d signals from %d repos "
        "(%d total discovered, %d skipped, %d errors)",
        total_signals,
        len(repos_scanned),
        total_discovered,
        len(repos_skipped),
        len(errors),
    )

    return {
        "signals": all_signals,
        "total_signals": total_signals,
        "repos_scanned": len(repos_scanned),
        "repos_discovered": total_discovered,
        "repos_skipped": len(repos_skipped),
        "errors": errors,
        "scanned_repos": repos_scanned,
        "skipped_orgs": [r["org"] for r in repos_skipped][:20] if repos_skipped else [],
    }
