# SPDX-License-Identifier: MIT
"""BranchWatcher — track what's being cooked on WIP branches.

Task #40 of the v0.5.x security line. Watches remote branches on
workspace repos that aren't yet merged to main/master. Surfaces
"someone is working on X" signals without leaking git-author
identity.

**Why this exists.** Pre-v0.5.8, every code-scanning engine
(`adversarial_reviewer`, `spec_drift`, `architecture_analyzer`, etc.)
walked the currently-checked-out branch of each workspace repo —
which on a fresh clone is always `main`. Feature branches on
ZenonOrg forks and core-dev forks were invisible. The
`anti-hallucination.md` rule already flagged this ("branch commits
should be capped at 0.6 confidence") but nothing implemented it.

This engine walks `git branch -r` on every workspace repo, finds
branches that are AHEAD of main/master (i.e., have their own
commits), and emits `branch_activity` findings with:

- Repo name
- Branch name
- Commits-ahead count
- Files touched (summary — NO git blame, NO author names)
- Confidence CAPPED at 0.6 (per the anti-hallucination rule)

The findings tell the community "N commits on branch feature/xyz in
go-zenon touching vm/embedded/htlc.go" — the WHAT without the WHO.

**Anti-doxxing guarantees (pinned by tests):**
- No `git log --author` reads. Ever.
- No `%an` / `%ae` / `%aN` / `%aE` format codes.
- Branch names that contain user identifiers (e.g., `user/feature-x`)
  are sanitized: the `user/` prefix is stripped if it looks like a
  real GitHub username.
- Commit author emails are never read, never persisted, never
  surfaced in findings.

**Trust-model integration:**
The `_capped_confidence` helper ensures no branch finding exceeds
0.6 confidence (the "branch source" tier from the
anti-hallucination rule). Even if the content itself is high
quality, the source is a WIP branch that hasn't been reviewed and
merged, so the trust model treats it as speculative.
"""

from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path
from typing import Any

from core.persistence.findings import persist_finding
from core.persistence.schema import DEFAULT_DB
from core.workspace import workspace_root

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]

# Safety caps — same shape as curiosity_scanner and friends
MAX_REPOS_PER_CYCLE = 5
MAX_BRANCHES_PER_REPO = 10
MAX_COMMITS_PER_BRANCH = 20

# Branch confidence ceiling from anti-hallucination rule #13
_BRANCH_CONFIDENCE_CAP = 0.60

# Branches we don't care about — already on main, already merged, etc.
_SKIPPED_BRANCHES = {
    "HEAD",
    "main",
    "master",
    "develop",
    "dev",
    "release",
    "stable",
}

# Common GitHub user-prefix patterns in branch names we strip for OPSEC
_USER_PREFIX_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]{2,38}/")


def _run_git(repo_path: str, *args: str, timeout: int = 30) -> tuple[int, str]:
    """Thin subprocess wrapper. Never reads author data."""
    try:
        result = subprocess.run(
            ["git", "-C", repo_path, *args],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def _list_remote_branches(repo_path: str) -> list[str]:
    """Return every remote branch name (without `origin/` prefix)."""
    code, output = _run_git(repo_path, "branch", "-r", "--no-color")
    if code != 0 or not output:
        return []
    branches: list[str] = []
    for line in output.split("\n"):
        name = line.strip()
        if not name or "->" in name:  # skip HEAD aliases
            continue
        # Strip the remote prefix (origin/, upstream/)
        parts = name.split("/", 1)
        if len(parts) == 2:
            name = parts[1]
        if name in _SKIPPED_BRANCHES:
            continue
        branches.append(name)
    return branches


def _main_branch(repo_path: str) -> str | None:
    """Return the repo's effective main branch name."""
    for candidate in ("main", "master"):
        code, _ = _run_git(repo_path, "rev-parse", "--verify", candidate)
        if code == 0:
            return candidate
    return None


def _commits_ahead(repo_path: str, branch: str, main_branch: str) -> int:
    """Return how many commits `branch` is ahead of `main_branch`."""
    code, output = _run_git(repo_path, "rev-list", "--count", f"{main_branch}..origin/{branch}")
    if code != 0 or not output.strip():
        return 0
    try:
        return int(output.strip())
    except ValueError:
        return 0


def _files_touched(repo_path: str, branch: str, main_branch: str, max_files: int = 30) -> list[str]:
    """Return files touched on `branch` since it diverged from `main_branch`.

    Uses `git diff --name-only` which reveals file paths but NOT
    authors, commit messages, or any other identifying data.
    """
    code, output = _run_git(repo_path, "diff", "--name-only", f"{main_branch}...origin/{branch}")
    if code != 0 or not output.strip():
        return []
    files = [f.strip() for f in output.strip().split("\n") if f.strip()]
    return files[:max_files]


def _sanitize_branch_name(branch: str) -> str:
    """Strip user-prefix patterns from branch names for OPSEC.

    A branch named `alice/feature-x` becomes `<user>/feature-x` in
    the output. Prevents recommendations from profiling by
    developer-name prefix.
    """
    if _USER_PREFIX_RE.match(branch):
        parts = branch.split("/", 1)
        if len(parts) == 2:
            return f"<user>/{parts[1]}"
    return branch


def _capped_confidence(raw: float) -> float:
    """Enforce the branch-source confidence ceiling."""
    return min(raw, _BRANCH_CONFIDENCE_CAP)


def _discover_repos(ws: Path) -> list[Path]:
    """Walk two levels deep for git repos (same shape as other scanners)."""
    repos: list[Path] = []
    if not ws.is_dir():
        return repos
    for top in sorted(ws.iterdir()):
        if not top.is_dir() or top.name.startswith("."):
            continue
        if (top / ".git").exists():
            repos.append(top)
            continue
        try:
            for child in sorted(top.iterdir()):
                if not child.is_dir() or child.name.startswith("."):
                    continue
                if (child / ".git").exists():
                    repos.append(child)
        except OSError:
            continue
    return repos


def _format_finding(
    repo_name: str,
    branch: str,
    commits_ahead: int,
    files: list[str],
) -> str:
    """WHAT/SO WHAT/NOW WHAT body — author-free by construction."""
    sanitized = _sanitize_branch_name(branch)
    files_preview = ", ".join(f"`{f}`" for f in files[:5])
    return (
        f"WHAT: Branch `{sanitized}` in `{repo_name}` is "
        f"{commits_ahead} commit(s) ahead of the main branch. "
        f"Touches {len(files)} file(s), preview: {files_preview}"
        + (" ..." if len(files) > 5 else "")
        + ". "
        f"SO WHAT: This is work-in-progress code that hasn't been "
        f"merged yet. It's a 'what's being cooked' signal — someone "
        f"is actively developing against `{repo_name}` right now. "
        f"Branch commits are capped at 0.60 confidence per the "
        f"anti-hallucination rule because the code hasn't been "
        f"reviewed, merged, or spork-activated. "
        f"NOW WHAT: Review the branch via "
        f"`git -C {repo_name} log origin/main..origin/{sanitized}` "
        f"if you want to see what's changing. Findings from this "
        f"engine never include git-author data — the engine knows "
        f"WHAT is being cooked, not WHO is cooking it."
    )


def run_branch_watcher(
    db_path: str | None = None,
    *,
    max_repos: int = MAX_REPOS_PER_CYCLE,
    max_branches_per_repo: int = MAX_BRANCHES_PER_REPO,
) -> dict[str, Any]:
    """Scan workspace repos for branches ahead of main and emit findings.

    Degrades gracefully on missing workspace or repos without git.

    Args:
        db_path: SQLite DB path (defaults to DEFAULT_DB).
        max_repos: Cap on repos scanned per cycle.
        max_branches_per_repo: Cap on branches inspected per repo.

    Returns:
        Summary dict with ``repos_scanned``, ``branches_found``,
        ``active_branches`` (branches ahead of main), and
        ``findings_persisted``.
    """
    db_path = db_path or DEFAULT_DB

    ws = workspace_root()
    if ws is None:
        logger.info("branch_watcher: workspace not installed; skipping")
        return {
            "repos_scanned": 0,
            "branches_found": 0,
            "active_branches": 0,
            "findings_persisted": 0,
            "workspace_root": None,
            "reason": "workspace not installed",
        }

    repos = _discover_repos(Path(ws))
    if not repos:
        return {
            "repos_scanned": 0,
            "branches_found": 0,
            "active_branches": 0,
            "findings_persisted": 0,
            "workspace_root": str(ws),
        }

    selected = repos[:max_repos]
    total_branches = 0
    active_branches = 0
    findings_persisted = 0

    for repo_path in selected:
        main_branch = _main_branch(str(repo_path))
        if not main_branch:
            continue
        branches = _list_remote_branches(str(repo_path))[:max_branches_per_repo]
        total_branches += len(branches)

        for branch in branches:
            commits = _commits_ahead(str(repo_path), branch, main_branch)
            if commits == 0:
                continue  # not ahead of main → nothing to flag
            active_branches += 1

            files = _files_touched(str(repo_path), branch, main_branch)
            body = _format_finding(repo_path.name, branch, commits, files)

            try:
                row_id = persist_finding(
                    db_path=db_path,
                    domain="intelligence",
                    engine="branch_watcher",
                    evidence_type="branch_activity",
                    finding=body,
                    confidence=_capped_confidence(0.55),
                    source_repo=repo_path.name,
                    raw_data={
                        "commits_ahead": commits,
                        "files_touched_count": len(files),
                        "branch_sanitized": _sanitize_branch_name(branch),
                        # Intentionally NOT persisting: author, email,
                        # commit messages, commit SHAs. Content-level
                        # signal only.
                    },
                )
                if row_id and row_id > 0:
                    findings_persisted += 1
            except Exception as exc:
                logger.debug(
                    "branch_watcher: persist failed for %s/%s: %s",
                    repo_path.name,
                    branch,
                    exc,
                )

    logger.info(
        "branch_watcher: scanned %d repo(s), %d branches, %d active, %d findings",
        len(selected),
        total_branches,
        active_branches,
        findings_persisted,
    )
    return {
        "repos_scanned": len(selected),
        "branches_found": total_branches,
        "active_branches": active_branches,
        "findings_persisted": findings_persisted,
        "workspace_root": str(ws),
    }
