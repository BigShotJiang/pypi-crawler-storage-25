# SPDX-License-Identifier: MIT
"""Intelligence domain configuration -- repo lists and monitoring parameters."""
