# SPDX-License-Identifier: MIT
"""
git_helpers -- Shared git-parsing primitives for community-domain engines.

Both :mod:`domains.community.engines.contributor_tracker` and
:mod:`domains.community.engines.talent_radar` walk the Zenon workspace,
enumerate every checked-out repo, and run ``git log`` to extract
contributor activity. This module is the single source of truth for
those primitives so the two engines can stay self-contained while
sharing the git parsing layer without importing from each other.

The helpers deliberately stay low-level: repo enumeration and a
timeout-aware ``git`` subprocess runner. Higher-level analytics -- bus
factor, monthly trend detection, language inference, contributor
classification -- remain in the engine modules that need them, because
each engine has its own semantics (contributor_tracker uses all-time
bus factor on ``CRITICAL_REPOS``; talent_radar uses 90-day activity on a
superset).
"""

import os
import subprocess
from collections.abc import Iterable
from pathlib import Path

# This module lives at domains/community/git_helpers.py, so parents[2]
# is the nebula repo root.
ENGINE_ROOT = Path(__file__).resolve().parents[2]

# Workspace root: use env var or derive from engine location.
# ENGINE_ROOT is .../<workspace>/zenon-org/nebula, so parents[1] is the
# workspace root.
ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# Top-level directories to scan for repos. Kept in a single place so
# both engines see the same workspace layout.
SCAN_DIRS: list[str] = [
    "core",
    "zenon-network",
    "hypercore-one",
    "HyperCore-Team",
    "community-sdks",
    "infrastructure",
    "knowledge",
    "zenon-org",
    "sol-znn",
    "digitalSloth",
    "georgezgeorgez",
    "zenonhub-io",
    "DexterLabZ",
    "MoonBaZZe",
    "millerships",
]


def run_git(repo_path: str, *args: str, timeout: int = 30) -> tuple[int, str]:
    """Run a git command in ``repo_path`` and return ``(returncode, stdout)``.

    Captures stdout as text and strips trailing whitespace. Returns
    ``(1, "")`` on timeout or when git is missing, so callers can treat
    failures uniformly without wrapping every call in try/except.
    """
    cmd = ["git", "-C", repo_path, *list(args)]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def find_repos(
    scan_dirs: Iterable[str] = SCAN_DIRS,
    workspace: Path = ZENON_WORKSPACE,
) -> list[tuple[str, str]]:
    """Find all git repos in the workspace.

    Returns a sorted list of ``(org_dir, repo_name)`` tuples for every
    directory under ``workspace/<org_dir>`` that contains a ``.git``
    entry. Non-existent scan dirs are skipped silently so portable
    installs without the full workspace still work.
    """
    repos: list[tuple[str, str]] = []
    for scan_dir in scan_dirs:
        parent = workspace / scan_dir
        if not parent.is_dir():
            continue
        for entry in sorted(parent.iterdir()):
            if entry.is_dir() and (entry / ".git").is_dir():
                repos.append((scan_dir, entry.name))
    return repos
