# SPDX-License-Identifier: MIT
"""
CommunityDomain -- DomainPlugin for contributor health and retention tracking.

Provides engines for analyzing git contributor data across the Zenon
workspace and scoring community health via GitHub metrics.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class CommunityDomain(DomainPlugin):
    """Community domain plugin -- contributor activity and health analysis."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "community"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Contributor activity tracking, retention analysis, bus factor "
            "detection, and community health scoring across Zenon repos."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 4

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="contributor_tracker",
                description=(
                    "Analyzes git logs across all Zenon repos to find unique "
                    "contributors, new vs returning, bus factor per repo."
                ),
                module_path="domains.community.engines.contributor_tracker",
                priority=4,
                tier=1,
                required_apis=["filesystem", "git"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="health_scorer",
                description=(
                    "Scores community health per repo: open issues, PR merge "
                    "time, commit frequency, contributor growth trend."
                ),
                module_path="domains.community.engines.health_scorer",
                priority=3,
                tier=2,
                required_apis=["filesystem", "git", "github_api"],
                max_runtime_seconds=180,
            ),
            EngineDefinition(
                name="talent_radar",
                description=(
                    "Finds contributor patterns from local git logs: core "
                    "contributors (active 30d, 2+ repos), at-risk (fading), "
                    "growth opportunities (single-repo), bus factor risks. "
                    "No API calls, no doxxing -- workspace git logs only."
                ),
                module_path="domains.community.engines.talent_radar",
                priority=4,
                tier=1,
                required_apis=["filesystem", "git"],
                max_runtime_seconds=180,
            ),
            EngineDefinition(
                name="sentiment_tracker",
                description=(
                    "Track development momentum via commit sentiment, "
                    "commit frequency, contributor arrivals/departures, "
                    "and a composite momentum score (0-100). "
                    "No LLM calls -- workspace git analysis only."
                ),
                module_path="domains.community.engines.sentiment_tracker",
                priority=3,
                tier=1,
                required_apis=["filesystem", "git"],
                max_runtime_seconds=180,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="community_growing",
                label="Community is growing",
                description=(
                    "Unique contributor count increasing month over month "
                    "across key Zenon repositories."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.75,
            ),
            HypothesisType(
                type_id="bus_factor_risk",
                label="Bus factor risk in critical repo",
                description=(
                    "A critical repo has bus factor of 1 -- single contributor "
                    "accounts for majority of commits."
                ),
                initial_confidence=0.5,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="development_momentum_healthy",
                label="Development momentum is healthy (60+)",
                description=(
                    "The development momentum score exceeds 60/100, "
                    "indicating healthy commit frequency, contributor "
                    "growth, and positive sentiment."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.75,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="bus_factor_3",
                label="Bus factor > 3 for all critical repos",
                description=(
                    "Every critical repo (go-zenon, syrius, SDKs) should have "
                    "at least 3 meaningful contributors to reduce key-person risk."
                ),
                priority=3,
                deadline_days=180,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="contributor_exodus",
                label="Contributor exodus detected",
                description=(
                    "Community shows declining contributors AND economics "
                    "domain shows declining staking participation."
                ),
                source_domains=["community", "economics"],
                convergence_threshold=0.7,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="community",
                section_title="Community Health",
                metrics=[
                    "total_contributors",
                    "active_contributors_30d",
                    "bus_factor_alerts",
                    "health_score",
                    "momentum_score",
                    "commit_frequency_weekly",
                    "new_contributors",
                    "departed_contributors",
                ],
                recommendations_prompt=(
                    "Based on contributor trends and bus factor risks, "
                    "what community actions should we prioritize?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "contributor_count": 0.0,
            "retention_rate": 0.0,
            "bus_factor_min": 0.0,
            "health_score": 0.0,
            "momentum_score": 0.0,
        }

    def decide_next_action(self, context: dict) -> dict | None:
        """Decide the highest-value next action given current state."""
        stale = context.get("stale_data", [])
        if "contributors" in stale:
            return {
                "action": "refresh_contributors",
                "reason": "Contributor data is stale.",
                "priority": 5,
                "engine": "contributor_tracker",
            }
        if "health" in stale:
            return {
                "action": "refresh_health_scores",
                "reason": "Community health scores are stale.",
                "priority": 5,
                "engine": "health_scorer",
            }
        if "sentiment" in stale:
            return {
                "action": "track_sentiment",
                "reason": "Development sentiment data is stale.",
                "priority": 4,
                "engine": "sentiment_tracker",
            }
        # Default: periodically refresh contributor data even when no
        # stale tag is set — ensures the domain fires at least once
        # per cycle instead of disappearing from the schedule.
        return {
            "action": "refresh_contributors",
            "reason": "Routine refresh (no stale tag matched).",
            "priority": 8,
            "engine": "contributor_tracker",
        }

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS community_activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    repo TEXT NOT NULL,
    author TEXT,
    commit_count INTEGER DEFAULT 0,
    period TEXT,
    bus_factor INTEGER,
    -- Extended fields used by domains/intelligence/engines/community_scanner
    -- to store per-item PR / issue / comment activity:
    source_type TEXT,
    title TEXT,
    body TEXT,
    url TEXT,
    labels TEXT,
    state TEXT,
    created_at TEXT,
    updated_at TEXT,
    sentiment TEXT,
    relevance_score REAL DEFAULT 0.0,
    processed BOOLEAN DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_community_repo
    ON community_activity(repo);
CREATE INDEX IF NOT EXISTS idx_community_author
    ON community_activity(author);
CREATE INDEX IF NOT EXISTS idx_community_period
    ON community_activity(period);

CREATE TABLE IF NOT EXISTS sentiment_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_commits INTEGER DEFAULT 0,
    repos_active INTEGER DEFAULT 0,
    unique_authors INTEGER DEFAULT 0,
    positive_commits INTEGER DEFAULT 0,
    neutral_commits INTEGER DEFAULT 0,
    negative_commits INTEGER DEFAULT 0,
    new_contributors INTEGER DEFAULT 0,
    departed_contributors INTEGER DEFAULT 0,
    momentum_score INTEGER DEFAULT 0,
    momentum_label TEXT DEFAULT 'unknown'
);

CREATE INDEX IF NOT EXISTS idx_sentiment_ts
    ON sentiment_snapshots(timestamp);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Community domain registered with %d engines.",
            len(self.get_engines()),
        )
