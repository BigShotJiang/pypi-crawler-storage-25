# SPDX-License-Identifier: MIT
"""
HealthScorer -- Score community health across Zenon repos.

Checks open issue counts, PR merge times, contributor growth trends,
and computes a composite health score (0-100) per repo and overall.
Uses `gh api` for GitHub data with graceful fallback to git-only data.
"""

import json
import logging
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# GitHub orgs and their local directory mappings
GH_ORG_MAP = {
    "zenon-network": "zenon-network",
    "hypercore-one": "hypercore-one",
    "HyperCore-Team": "HyperCore-Team",
    "ZenonOrg": "zenon-org",
}

# Repos we care about for health scoring (org/repo on GitHub)
KEY_REPOS = [
    ("zenon-network", "go-zenon"),
    ("zenon-network", "syrius"),
    ("zenon-network", "znn_sdk_dart"),
    ("zenon-network", "znn_cli_dart"),
    ("hypercore-one", "go-zenon"),
    ("hypercore-one", "hyperqube_z"),
    ("hypercore-one", "nomctl"),
    ("HyperCore-Team", "orchestrator"),
    ("HyperCore-Team", "evm-bridge-contracts"),
]


def _run_gh(args: list[str], timeout: int = 30) -> tuple[int, str]:
    """Run a gh CLI command. Returns (returncode, stdout)."""
    cmd = ["gh", *args]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def _run_git(repo_path: str, *args: str, timeout: int = 30) -> tuple[int, str]:
    """Run a git command in a repo. Returns (returncode, stdout)."""
    cmd = ["git", "-C", repo_path, *list(args)]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def get_open_issue_count(gh_org: str, repo: str) -> int | None:
    """Get open issue count for a GitHub repo via gh api."""
    code, output = _run_gh(
        [
            "api",
            f"repos/{gh_org}/{repo}",
            "--jq",
            ".open_issues_count",
        ]
    )
    if code == 0 and output.isdigit():
        return int(output)
    return None


def get_recent_pr_merge_times(
    gh_org: str,
    repo: str,
    limit: int = 20,
) -> list[float]:
    """Get merge times (in hours) for recently closed PRs.

    Returns list of merge durations in hours. Empty list on failure.
    """
    code, output = _run_gh(
        [
            "api",
            f"repos/{gh_org}/{repo}/pulls",
            "-X",
            "GET",
            "-f",
            "state=closed",
            "-f",
            f"per_page={limit}",
            "--jq",
            "[.[] | select(.merged_at != null) | {created: .created_at, merged: .merged_at}]",
        ],
        timeout=45,
    )
    if code != 0 or not output:
        return []

    try:
        prs = json.loads(output)
    except json.JSONDecodeError:
        return []

    durations = []
    for pr in prs:
        try:
            created = datetime.fromisoformat(pr["created"].replace("Z", "+00:00"))
            merged = datetime.fromisoformat(pr["merged"].replace("Z", "+00:00"))
            hours = (merged - created).total_seconds() / 3600
            if hours >= 0:
                durations.append(hours)
        except (KeyError, ValueError):
            continue

    return durations


def get_commit_frequency(repo_path: str, days: int = 90) -> float:
    """Get average commits per week for the last N days."""
    code, output = _run_git(
        repo_path,
        "rev-list",
        "--count",
        f"--since={days} days ago",
        "HEAD",
    )
    if code == 0 and output.isdigit():
        total = int(output)
        weeks = max(days / 7, 1)
        return round(total / weeks, 2)
    return 0.0


def get_days_since_last_commit(repo_path: str) -> int | None:
    """Get number of days since the last commit."""
    code, output = _run_git(repo_path, "log", "-1", "--format=%aI")
    if code != 0 or not output:
        return None
    try:
        last = datetime.fromisoformat(output)
        now = datetime.now(timezone.utc)
        return (now - last).days
    except ValueError:
        return None


def score_repo(
    gh_org: str,
    repo: str,
    local_dir: str | None = None,
) -> dict:
    """Score a single repo's community health.

    Returns a dict with individual metric scores and composite score.
    Scoring breakdown (each 0-25, total 0-100):
        - issue_score: lower open issues = better (25 if < 5, 0 if > 50)
        - pr_speed_score: faster PR merges = better (25 if avg < 24h)
        - activity_score: more recent commits = better
        - commit_freq_score: higher weekly commits = better
    """
    scores: dict[str, float] = {}
    details: dict = {"gh_org": gh_org, "repo": repo}

    # 1. Open issues score (0-25)
    issue_count = get_open_issue_count(gh_org, repo)
    details["open_issues"] = issue_count
    if issue_count is not None:
        if issue_count <= 5:
            scores["issue_score"] = 25.0
        elif issue_count <= 20:
            scores["issue_score"] = 25.0 - (issue_count - 5) * (15.0 / 15)
        elif issue_count <= 50:
            scores["issue_score"] = 10.0 - (issue_count - 20) * (10.0 / 30)
        else:
            scores["issue_score"] = 0.0
    else:
        scores["issue_score"] = 12.5  # Unknown -> neutral

    # 2. PR merge speed score (0-25)
    merge_times = get_recent_pr_merge_times(gh_org, repo)
    if merge_times:
        avg_hours = sum(merge_times) / len(merge_times)
        details["avg_pr_merge_hours"] = round(avg_hours, 1)
        details["prs_analyzed"] = len(merge_times)
        if avg_hours <= 24:
            scores["pr_speed_score"] = 25.0
        elif avg_hours <= 72:
            scores["pr_speed_score"] = 25.0 - (avg_hours - 24) * (10.0 / 48)
        elif avg_hours <= 168:
            scores["pr_speed_score"] = 15.0 - (avg_hours - 72) * (10.0 / 96)
        elif avg_hours <= 720:
            scores["pr_speed_score"] = 5.0 - (avg_hours - 168) * (5.0 / 552)
        else:
            scores["pr_speed_score"] = 0.0
    else:
        scores["pr_speed_score"] = 12.5  # Unknown -> neutral
        details["avg_pr_merge_hours"] = None

    # 3. Activity recency score (0-25)
    repo_path = local_dir
    if not repo_path:
        local_org = GH_ORG_MAP.get(gh_org, gh_org)
        repo_path = str(ZENON_WORKSPACE / local_org / repo)

    days_since = get_days_since_last_commit(repo_path) if os.path.isdir(repo_path) else None
    details["days_since_last_commit"] = days_since
    if days_since is not None:
        if days_since <= 7:
            scores["activity_score"] = 25.0
        elif days_since <= 30:
            scores["activity_score"] = 25.0 - (days_since - 7) * (10.0 / 23)
        elif days_since <= 90:
            scores["activity_score"] = 15.0 - (days_since - 30) * (10.0 / 60)
        elif days_since <= 365:
            scores["activity_score"] = 5.0 - (days_since - 90) * (5.0 / 275)
        else:
            scores["activity_score"] = 0.0
    else:
        scores["activity_score"] = 12.5

    # 4. Commit frequency score (0-25)
    if os.path.isdir(repo_path):
        commits_per_week = get_commit_frequency(repo_path)
        details["commits_per_week_90d"] = commits_per_week
        if commits_per_week >= 5:
            scores["commit_freq_score"] = 25.0
        elif commits_per_week >= 2:
            scores["commit_freq_score"] = 15.0 + (commits_per_week - 2) * (10.0 / 3)
        elif commits_per_week >= 0.5:
            scores["commit_freq_score"] = 5.0 + (commits_per_week - 0.5) * (10.0 / 1.5)
        elif commits_per_week > 0:
            scores["commit_freq_score"] = commits_per_week * 10.0
        else:
            scores["commit_freq_score"] = 0.0
    else:
        scores["commit_freq_score"] = 12.5

    # Clamp all scores
    for key in scores:
        scores[key] = round(max(0.0, min(25.0, scores[key])), 1)

    composite = round(sum(scores.values()), 1)
    return {
        "repo": f"{gh_org}/{repo}",
        "composite_score": composite,
        "scores": scores,
        "details": details,
    }


def score_all_repos() -> dict:
    """Score all key repos and compute overall health.

    Returns dict with per-repo scores, overall score, and summary.
    """
    results = []
    for gh_org, repo in KEY_REPOS:
        try:
            result = score_repo(gh_org, repo)
            results.append(result)
        except Exception as exc:
            logger.error("Failed to score %s/%s: %s", gh_org, repo, exc)

    if not results:
        return {
            "repos_scored": 0,
            "overall_score": 0.0,
            "results": [],
            "summary": "No repos could be scored.",
        }

    overall = round(
        sum(r["composite_score"] for r in results) / len(results),
        1,
    )

    # Categorize
    healthy = [r for r in results if r["composite_score"] >= 60]
    warning = [r for r in results if 30 <= r["composite_score"] < 60]
    critical = [r for r in results if r["composite_score"] < 30]

    summary = (
        f"{len(results)} repos scored. Overall health: {overall}/100. "
        f"{len(healthy)} healthy (>=60), "
        f"{len(warning)} warning (30-59), "
        f"{len(critical)} critical (<30)."
    )

    return {
        "repos_scored": len(results),
        "overall_score": overall,
        "healthy_count": len(healthy),
        "warning_count": len(warning),
        "critical_count": len(critical),
        "results": results,
        "summary": summary,
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run health scoring and persist findings to the evidence table.

    Returns the number of findings persisted.
    """
    from core.persist_to_db import ensure_schema, persist_finding

    ensure_schema(db_path)
    count = 0

    report = score_all_repos()

    # Persist overall summary
    overall = report["overall_score"]
    healthy_n = report.get("healthy_count", 0)
    warning_n = report.get("warning_count", 0)
    critical_n = report.get("critical_count", 0)
    total_n = report.get("repos_scored", 0)

    if critical_n > 0:
        critical_repos = [r["repo"] for r in report["results"] if r["composite_score"] < 30]
        impact = f"{critical_n} repo(s) in critical health ({', '.join(critical_repos)}) -- may indicate abandoned or stalled development."
        action = "Investigate critical repos: check for maintainer burnout, missing CI, or upstream abandonment. Escalate if core protocol repos."
    elif warning_n > total_n / 2:
        impact = f"Majority of repos ({warning_n}/{total_n}) in warning state -- ecosystem development is slowing."
        action = "Review warning repos for common issues (stale PRs, low commit frequency); consider contributor outreach."
    else:
        impact = f"Ecosystem is generally healthy with {healthy_n}/{total_n} repos in good shape."
        action = "Continue monitoring; focus attention on any repos trending downward."

    persist_finding(
        db_path=db_path,
        domain="community",
        engine="health_scorer",
        evidence_type="community_health_overall",
        finding=(
            f"WHAT: {total_n} repos scored, overall health {overall}/100. "
            f"{healthy_n} healthy, {warning_n} warning, {critical_n} critical. "
            f"SO WHAT: {impact} "
            f"NOW WHAT: {action}"
        ),
        confidence=0.85,
        raw_data=report,
        source_repo="workspace",
    )
    count += 1

    # Persist per-repo scores
    for result in report["results"]:
        label = "healthy"
        if result["composite_score"] < 30:
            label = "critical"
        elif result["composite_score"] < 60:
            label = "warning"

        result.get("details", {})
        scores = result.get("scores", {})

        # Find weakest dimension
        weakest = min(scores, key=scores.get) if scores else "unknown"
        weakest_val = scores.get(weakest, 0)

        if label == "critical":
            repo_action = f"Needs immediate attention. Weakest area: {weakest} ({weakest_val}/25). Check if repo is abandoned or needs new maintainer."
        elif label == "warning":
            repo_action = f"Improve {weakest} ({weakest_val}/25) to move from warning to healthy. Review recent activity and PR backlog."
        else:
            repo_action = "No action needed. Continue monitoring for regression."

        persist_finding(
            db_path=db_path,
            domain="community",
            engine="health_scorer",
            evidence_type=f"repo_health_{label}",
            finding=(
                f"WHAT: {result['repo']} health score {result['composite_score']}/100 ({label}). "
                f"SO WHAT: Weakest dimension is {weakest} ({weakest_val}/25)"
                f"{' -- this repo may be losing contributors or going stale' if label != 'healthy' else ''}. "
                f"NOW WHAT: {repo_action}"
            ),
            confidence=0.85,
            raw_data=result,
            source_repo=result.get("repo", "workspace"),
        )
        count += 1

    logger.info("HealthScorer: persisted %d findings", count)
    return count
