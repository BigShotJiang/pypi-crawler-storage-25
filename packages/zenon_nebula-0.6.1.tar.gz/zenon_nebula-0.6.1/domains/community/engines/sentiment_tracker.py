# SPDX-License-Identifier: MIT
"""
SentimentTracker -- Track development momentum and community health signals.

For: community managers/marketing.

Scans git commit messages across the Zenon workspace for development
sentiment signals. Tracks commit frequency over time, new contributor
arrivals vs departures, and produces a development momentum score (0-100).
No LLM calls -- pure workspace analysis.
"""

import logging
import re
import subprocess
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persist_to_db import persist_metric, query_table

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

from core.config import get_config
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

# Commit message sentiment classification (no LLM needed)
POSITIVE_PREFIXES = {"feat", "add", "improve", "enhance", "implement", "support"}
NEUTRAL_PREFIXES = {"refactor", "chore", "docs", "style", "ci", "build", "perf", "test"}
NEGATIVE_PREFIXES = {"fix", "revert", "break", "remove", "deprecate", "disable"}

# Repos to scan (core repos have higher weight)
CORE_REPOS = [
    "core/go-zenon",
    "core/znn_sdk_dart",
    "core/syrius",
    "zenon-network/go-zenon",
    "hypercore-one/go-zenon",
    "zenon-network/syrius",
    "hypercore-one/syrius",
]

# Weight multipliers — sourced from config/engine_defaults.json with safe fallbacks.
_st_cfg = get_config().engine("sentiment_tracker")
CORE_WEIGHT = _st_cfg.get("core_weight", 2.0)
COMMUNITY_WEIGHT = _st_cfg.get("community_weight", 1.0)


def _run_git(repo_path: str, args: list[str], timeout: int = 10) -> str | None:
    """Run a git command and return stdout, or None on failure."""
    try:
        result = subprocess.run(
            ["git", "-C", repo_path, *args],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def _find_repos() -> list[dict]:
    """Find all git repos in the Zenon workspace.

    Returns list of dicts with path, org, name, is_core.
    """
    repos = []
    workspace = ZENON_WORKSPACE
    if not workspace.is_dir():
        return repos

    for org_dir in workspace.iterdir():
        if not org_dir.is_dir() or org_dir.name.startswith("."):
            continue
        for repo_dir in org_dir.iterdir():
            if not repo_dir.is_dir() or not (repo_dir / ".git").is_dir():
                continue
            rel_path = f"{org_dir.name}/{repo_dir.name}"
            repos.append(
                {
                    "path": str(repo_dir),
                    "org": org_dir.name,
                    "name": repo_dir.name,
                    "rel_path": rel_path,
                    "is_core": rel_path in CORE_REPOS,
                }
            )
    return repos


# -- Data Collection --


def collect_commit_data(days: int = 30) -> dict:
    """Collect commit data from all repos for the given time window.

    Returns dict with commits, authors, repos_active, sentiment_counts.
    """
    since_date = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d")

    repos = _find_repos()
    all_commits = []
    authors_by_period = defaultdict(set)  # week -> set of authors
    repo_activity = {}
    sentiment_counts = Counter()

    for repo in repos:
        log_output = _run_git(
            repo["path"],
            [
                "log",
                f"--since={since_date}",
                "--format=%H|%an|%ae|%at|%s",
                "--all",
            ],
        )
        if not log_output:
            continue

        repo_commits = 0
        for line in log_output.split("\n"):
            if not line.strip():
                continue
            parts = line.split("|", 4)
            if len(parts) < 5:
                continue

            _commit_hash, author_name, _author_email, timestamp_str, subject = parts

            try:
                ts = int(timestamp_str)
                commit_date = datetime.fromtimestamp(ts, tz=timezone.utc)
            except (ValueError, OSError):
                continue

            # Classify sentiment
            subject_lower = subject.lower().strip()
            # Extract prefix from conventional commits
            prefix_match = re.match(r"^(\w+)[\[(:]", subject_lower)
            prefix = (
                prefix_match.group(1)
                if prefix_match
                else subject_lower.split()[0]
                if subject_lower
                else ""
            )

            if prefix in POSITIVE_PREFIXES:
                sentiment = "positive"
            elif prefix in NEGATIVE_PREFIXES:
                sentiment = "negative"
            else:
                sentiment = "neutral"

            sentiment_counts[sentiment] += 1

            # Track weekly activity
            week_key = commit_date.strftime("%Y-W%W")
            authors_by_period[week_key].add(author_name)

            weight = CORE_WEIGHT if repo["is_core"] else COMMUNITY_WEIGHT

            all_commits.append(
                {
                    "repo": repo["rel_path"],
                    "author": author_name,
                    "date": commit_date.isoformat(),
                    "subject": subject[:120],
                    "sentiment": sentiment,
                    "weight": weight,
                }
            )
            repo_commits += 1

        if repo_commits > 0:
            repo_activity[repo["rel_path"]] = repo_commits

    return {
        "commits": all_commits,
        "total_commit_count": len(all_commits),
        "repos_active": len(repo_activity),
        "repo_activity": repo_activity,
        "sentiment_counts": dict(sentiment_counts),
        "authors_by_week": {k: len(v) for k, v in sorted(authors_by_period.items())},
        "unique_authors": len({c["author"] for c in all_commits}),
        "days_scanned": days,
    }


def detect_new_and_departing_contributors(days: int = 90) -> dict:
    """Identify new contributors and those who stopped contributing.

    Compares the last 30 days against the preceding 60 days.
    """
    recent_since = (datetime.now(timezone.utc) - timedelta(days=30)).strftime("%Y-%m-%d")
    older_since = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d")

    repos = _find_repos()
    recent_authors = set()
    older_authors = set()

    for repo in repos:
        # Recent commits (last 30 days)
        recent_output = _run_git(
            repo["path"],
            ["log", f"--since={recent_since}", "--format=%an", "--all"],
        )
        if recent_output:
            for line in recent_output.split("\n"):
                if line.strip():
                    recent_authors.add(line.strip())

        # Older commits (30-90 days ago)
        older_output = _run_git(
            repo["path"],
            [
                "log",
                f"--since={older_since}",
                f"--until={recent_since}",
                "--format=%an",
                "--all",
            ],
        )
        if older_output:
            for line in older_output.split("\n"):
                if line.strip():
                    older_authors.add(line.strip())

    new_contributors = recent_authors - older_authors
    departed_contributors = older_authors - recent_authors
    retained_contributors = recent_authors & older_authors

    return {
        "new_contributors": sorted(new_contributors),
        "departed_contributors": sorted(departed_contributors),
        "retained_contributors": sorted(retained_contributors),
        "new_count": len(new_contributors),
        "departed_count": len(departed_contributors),
        "retained_count": len(retained_contributors),
        "net_change": len(new_contributors) - len(departed_contributors),
    }


# -- Scoring --


def calculate_momentum_score(
    commit_data: dict,
    contributor_changes: dict,
) -> dict:
    """Calculate development momentum score (0-100).

    Components:
    - Commit frequency (0-30 points)
    - Repo breadth (0-20 points)
    - Sentiment balance (0-20 points)
    - Contributor growth (0-30 points)
    """
    scores = {}

    # Commit frequency score: 30 points
    # Baseline: 10 commits/week = 100% of this component
    total_commits = commit_data.get("total_commit_count", 0)
    days = commit_data.get("days_scanned", 30)
    weekly_rate = (total_commits / max(days, 1)) * 7
    commit_score = min(30, round(weekly_rate / 10 * 30))
    scores["commit_frequency"] = commit_score

    # Repo breadth score: 20 points
    # Baseline: 5 active repos = 100% of this component
    repos_active = commit_data.get("repos_active", 0)
    breadth_score = min(20, round(repos_active / 5 * 20))
    scores["repo_breadth"] = breadth_score

    # Sentiment score: 20 points
    # More positive/neutral than negative = higher score
    sentiments = commit_data.get("sentiment_counts", {})
    positive = sentiments.get("positive", 0)
    neutral = sentiments.get("neutral", 0)
    negative = sentiments.get("negative", 0)
    total_s = positive + neutral + negative
    if total_s > 0:
        positive_ratio = (positive + neutral * 0.5) / total_s
        sentiment_score = round(positive_ratio * 20)
    else:
        sentiment_score = 0
    scores["sentiment_balance"] = sentiment_score

    # Contributor growth score: 30 points
    net_change = contributor_changes.get("net_change", 0)
    retained = contributor_changes.get("retained_count", 0)
    contributor_changes.get("new_count", 0)

    # Positive net change = growth; retained contributors = stability
    growth_score = min(15, max(0, net_change * 5 + 5))
    retention_score = min(
        15, round(retained / max(1, retained + contributor_changes.get("departed_count", 0)) * 15)
    )
    scores["contributor_growth"] = growth_score + retention_score

    total_score = sum(scores.values())

    return {
        "total_score": total_score,
        "max_score": 100,
        "components": scores,
        "label": _score_label(total_score),
    }


def _score_label(score: int) -> str:
    """Convert numeric score to human-readable label."""
    if score >= 80:
        return "thriving"
    elif score >= 60:
        return "healthy"
    elif score >= 40:
        return "moderate"
    elif score >= 20:
        return "sluggish"
    else:
        return "stagnant"


# -- Persistence --


def persist_sentiment_snapshot(
    commit_data: dict,
    contributor_changes: dict,
    momentum_score: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist sentiment tracking data to the database."""
    return persist_metric(
        db_path=db_path,
        table="sentiment_snapshots",
        data={
            "total_commits": commit_data.get("total_commit_count", 0),
            "repos_active": commit_data.get("repos_active", 0),
            "unique_authors": commit_data.get("unique_authors", 0),
            "positive_commits": commit_data.get("sentiment_counts", {}).get("positive", 0),
            "neutral_commits": commit_data.get("sentiment_counts", {}).get("neutral", 0),
            "negative_commits": commit_data.get("sentiment_counts", {}).get("negative", 0),
            "new_contributors": contributor_changes.get("new_count", 0),
            "departed_contributors": contributor_changes.get("departed_count", 0),
            "momentum_score": momentum_score.get("total_score", 0),
            "momentum_label": momentum_score.get("label", "unknown"),
        },
    )


def detect_momentum_trend(*, db_path: str = DEFAULT_DB, window: int = 10) -> dict:
    """Detect development momentum trend over recent snapshots."""
    rows = query_table(
        db_path=db_path,
        table="sentiment_snapshots",
        order_by="timestamp DESC",
        limit=window,
    )

    if len(rows) < 2:
        return {"trend": "insufficient_data", "data_points": len(rows)}

    scores = [r["momentum_score"] or 0 for r in reversed(rows)]
    n = len(scores)
    x_mean = (n - 1) / 2
    y_mean = sum(scores) / n
    num = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(scores))
    den = sum((i - x_mean) ** 2 for i in range(n))
    slope = num / den if den else 0.0

    if slope > 1:
        trend = "accelerating"
    elif slope < -1:
        trend = "decelerating"
    else:
        trend = "stable"

    return {
        "trend": trend,
        "slope": round(slope, 4),
        "latest_score": scores[-1],
        "data_points": n,
    }


# -- Finding Builder --


def _build_sentiment_finding(
    commit_data: dict,
    contributor_changes: dict,
    momentum_score: dict,
    trend: dict,
) -> str:
    """Build actionable finding for development sentiment.

    Answers WHAT / SO WHAT / NOW WHAT.
    """
    score = momentum_score.get("total_score", 0)
    label = momentum_score.get("label", "unknown")
    total_commits = commit_data.get("total_commit_count", 0)
    repos_active = commit_data.get("repos_active", 0)
    unique_authors = commit_data.get("unique_authors", 0)
    new_count = contributor_changes.get("new_count", 0)
    departed_count = contributor_changes.get("departed_count", 0)
    net_change = contributor_changes.get("net_change", 0)
    trend_dir = trend.get("trend", "unknown")

    sentiments = commit_data.get("sentiment_counts", {})
    positive = sentiments.get("positive", 0)
    negative = sentiments.get("negative", 0)

    # WHAT
    what = (
        f"Development momentum score {score}/100 ({label}). "
        f"{total_commits} commits this period across {repos_active} repos, "
        f"{unique_authors} unique contributors. "
        f"{new_count} new contributor(s), {departed_count} departed. "
        f"Commit sentiment: {positive} positive, {negative} negative."
    )

    # SO WHAT
    so_what_parts = []

    if label in ("thriving", "healthy"):
        so_what_parts.append(f"Development is {label} — strong signal for project viability.")
    elif label == "moderate":
        so_what_parts.append("Development activity is moderate — sufficient but not accelerating.")
    elif label in ("sluggish", "stagnant"):
        so_what_parts.append(
            f"Development is {label} — this may concern investors and "
            f"community members tracking project health."
        )

    if trend_dir == "accelerating":
        so_what_parts.append("Momentum is accelerating — increasing developer confidence.")
    elif trend_dir == "decelerating":
        so_what_parts.append("Momentum is decelerating — potential loss of developer interest.")

    if net_change > 0:
        so_what_parts.append(f"Net +{net_change} contributors — community is growing.")
    elif net_change < 0:
        so_what_parts.append(f"Net {net_change} contributors — community is shrinking.")

    so_what = (
        " ".join(so_what_parts)
        if so_what_parts
        else ("Development metrics are within normal parameters.")
    )

    # NOW WHAT
    now_what_parts = []

    if label in ("sluggish", "stagnant"):
        now_what_parts.append(
            "Highlight momentum in community updates to counter perception of inactivity."
        )
    if net_change < 0:
        now_what_parts.append(
            "Investigate why contributors are leaving — tooling issues, "
            "lack of documentation, or low engagement?"
        )
    if new_count > 0:
        now_what_parts.append(
            f"Welcome {new_count} new contributor(s) — onboarding support improves retention."
        )
    if not now_what_parts:
        now_what_parts.append("Continue tracking. Share momentum data in community updates.")

    now_what = " ".join(now_what_parts)

    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"


# -- Main Entry Point --


def run_sentiment_tracker(*, db_path: str = DEFAULT_DB, days: int = 30) -> dict:
    """Run full development sentiment analysis.

    Returns comprehensive sentiment and momentum status dict.
    """
    from core.persist_to_db import persist_finding

    commit_data = collect_commit_data(days=days)
    contributor_changes = detect_new_and_departing_contributors()
    momentum_score = calculate_momentum_score(commit_data, contributor_changes)

    snapshot_id = persist_sentiment_snapshot(
        commit_data,
        contributor_changes,
        momentum_score,
        db_path=db_path,
    )

    trend = detect_momentum_trend(db_path=db_path)

    finding_text = _build_sentiment_finding(
        commit_data,
        contributor_changes,
        momentum_score,
        trend,
    )

    persist_finding(
        db_path=db_path,
        domain="community",
        engine="sentiment_tracker",
        evidence_type="development_sentiment",
        finding=finding_text,
        confidence=0.80,
        raw_data={
            "momentum_score": momentum_score,
            "contributor_changes": {
                "new": contributor_changes["new_count"],
                "departed": contributor_changes["departed_count"],
                "retained": contributor_changes["retained_count"],
                "net_change": contributor_changes["net_change"],
            },
            "commit_summary": {
                "total": commit_data["total_commit_count"],
                "repos_active": commit_data["repos_active"],
                "unique_authors": commit_data["unique_authors"],
                "sentiment": commit_data["sentiment_counts"],
            },
            "trend": trend,
        },
        source_repo="local_workspace",
    )

    return {
        "success": True,
        "momentum_score": momentum_score,
        "commit_data_summary": {
            "total_commits": commit_data["total_commit_count"],
            "repos_active": commit_data["repos_active"],
            "unique_authors": commit_data["unique_authors"],
        },
        "contributor_changes": contributor_changes,
        "trend": trend,
        "snapshot_id": snapshot_id,
        "finding": finding_text,
    }
