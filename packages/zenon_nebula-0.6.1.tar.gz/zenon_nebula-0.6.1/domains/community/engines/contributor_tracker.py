# SPDX-License-Identifier: MIT
"""
ContributorTracker -- Analyze git logs across Zenon repos for contributor data.

Scans all git repositories in the Zenon workspace, extracts unique
contributors per repo, calculates bus factor, identifies new vs returning
contributors by month, and persists findings to the evidence table.
"""

import logging
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from domains.community.git_helpers import (
    SCAN_DIRS,
    ZENON_WORKSPACE,
    find_repos,
    run_git,
)

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# ``SCAN_DIRS``, ``ZENON_WORKSPACE``, ``run_git`` and ``find_repos`` are
# re-exported above for backward compatibility with any caller that
# historically imported them from this module.

# Repos considered critical for bus factor analysis
CRITICAL_REPOS = {
    "go-zenon",
    "syrius",
    "znn_sdk_dart",
    "znn_cli_dart",
    "nomctl",
    "orchestrator",
    "hyperqube_z",
}


def get_contributors_per_repo(
    since: str | None = None,
    until: str | None = None,
) -> dict[str, list[dict]]:
    """Get unique contributors for each repo in the workspace.

    Args:
        since: Git date string (e.g. '2026-03-01') for filtering.
        until: Git date string for upper bound.

    Returns:
        Dict mapping 'org/repo' to list of contributor dicts with
        keys: name, commit_count.
    """
    result: dict[str, list[dict]] = {}

    for org_dir, repo_name in find_repos():
        repo_path = str(ZENON_WORKSPACE / org_dir / repo_name)
        args = ["log", "--format=%an"]
        if since:
            args.append(f"--since={since}")
        if until:
            args.append(f"--until={until}")

        code, output = run_git(repo_path, *args)
        if code != 0 or not output:
            continue

        counts = Counter(output.strip().split("\n"))
        contributors = [
            {"name": name, "commit_count": count} for name, count in counts.most_common()
        ]
        if contributors:
            result[f"{org_dir}/{repo_name}"] = contributors

    return result


def get_all_time_contributors() -> dict[str, list[dict]]:
    """Get all-time contributors per repo (no date filter)."""
    return get_contributors_per_repo()


def get_monthly_contributors(year: int, month: int) -> dict[str, list[dict]]:
    """Get contributors for a specific month."""
    since = f"{year}-{month:02d}-01"
    if month == 12:
        until = f"{year + 1}-01-01"
    else:
        until = f"{year}-{month + 1:02d}-01"
    return get_contributors_per_repo(since=since, until=until)


def calculate_bus_factor(contributors: list[dict]) -> int:
    """Calculate bus factor for a repo based on commit distribution.

    Bus factor = minimum number of contributors whose combined commits
    account for >= 50% of total commits.
    """
    if not contributors:
        return 0

    total = sum(c["commit_count"] for c in contributors)
    if total == 0:
        return 0

    # Sort by commit count descending (already sorted from most_common)
    cumulative = 0
    for i, c in enumerate(contributors, 1):
        cumulative += c["commit_count"]
        if cumulative >= total * 0.5:
            return i

    return len(contributors)


def analyze_contributor_trends() -> dict:
    """Analyze contributor trends: current month vs previous month.

    Returns a dict with:
        - repos_scanned: int
        - total_unique_contributors: int
        - current_month_active: int
        - previous_month_active: int
        - new_this_month: list of contributor names not seen last month
        - bus_factor_alerts: repos with bus factor == 1
        - top_contributors: top 10 by total commits across all repos
    """
    now = datetime.now(timezone.utc)
    curr_year, curr_month = now.year, now.month
    if curr_month == 1:
        prev_year, prev_month = curr_year - 1, 12
    else:
        prev_year, prev_month = curr_year, curr_month - 1

    current = get_monthly_contributors(curr_year, curr_month)
    previous = get_monthly_contributors(prev_year, prev_month)
    all_time = get_all_time_contributors()

    # Unique contributor names across all repos
    curr_names: set[str] = set()
    prev_names: set[str] = set()
    for contribs in current.values():
        for c in contribs:
            curr_names.add(c["name"])
    for contribs in previous.values():
        for c in contribs:
            prev_names.add(c["name"])

    new_this_month = sorted(curr_names - prev_names)

    # All-time unique
    all_names: set[str] = set()
    global_counts: Counter = Counter()
    for contribs in all_time.values():
        for c in contribs:
            all_names.add(c["name"])
            global_counts[c["name"]] += c["commit_count"]

    # Bus factor alerts
    bus_factor_alerts = []
    for repo_key, contribs in all_time.items():
        bf = calculate_bus_factor(contribs)
        repo_name = repo_key.split("/")[-1]
        if bf <= 1 and repo_name in CRITICAL_REPOS:
            bus_factor_alerts.append(
                {
                    "repo": repo_key,
                    "bus_factor": bf,
                    "top_contributor": contribs[0]["name"] if contribs else "none",
                    "total_commits": sum(c["commit_count"] for c in contribs),
                }
            )

    top_contributors = [
        {"name": name, "total_commits": count} for name, count in global_counts.most_common(10)
    ]

    return {
        "repos_scanned": len(all_time),
        "total_unique_contributors": len(all_names),
        "current_month_active": len(curr_names),
        "previous_month_active": len(prev_names),
        "new_this_month": new_this_month,
        "bus_factor_alerts": bus_factor_alerts,
        "top_contributors": top_contributors,
        "current_month": f"{curr_year}-{curr_month:02d}",
        "previous_month": f"{prev_year}-{prev_month:02d}",
    }


def get_per_repo_summary() -> list[dict]:
    """Get a summary for each repo: contributors, bus factor, last commit.

    Returns list of dicts with keys: repo, contributor_count, bus_factor,
    top_contributor, total_commits, last_commit_date.
    """
    all_time = get_all_time_contributors()
    summaries = []

    for repo_key, contribs in sorted(all_time.items()):
        org_dir, repo_name = repo_key.split("/", 1)
        repo_path = str(ZENON_WORKSPACE / org_dir / repo_name)

        # Get last commit date
        code, date_output = run_git(
            repo_path,
            "log",
            "-1",
            "--format=%aI",
        )
        last_commit = date_output if code == 0 else "unknown"

        summaries.append(
            {
                "repo": repo_key,
                "contributor_count": len(contribs),
                "bus_factor": calculate_bus_factor(contribs),
                "top_contributor": contribs[0]["name"] if contribs else "none",
                "total_commits": sum(c["commit_count"] for c in contribs),
                "last_commit_date": last_commit,
            }
        )

    return summaries


def _build_trend_finding(trends: dict) -> str:
    """Build actionable contributor trend finding.

    Answers WHAT / SO WHAT / NOW WHAT.
    """
    total = trends["total_unique_contributors"]
    curr_active = trends["current_month_active"]
    prev_active = trends["previous_month_active"]
    new_count = len(trends["new_this_month"])
    repos = trends["repos_scanned"]
    curr_month = trends["current_month"]
    prev_month = trends["previous_month"]

    # WHAT
    what = (
        f"{repos} repos scanned, {total} all-time contributors. "
        f"Current month ({curr_month}): {curr_active} active. "
        f"Previous month ({prev_month}): {prev_active} active. "
        f"{new_count} new contributor(s) this month."
    )

    # SO WHAT
    so_what_parts = []

    if curr_active == 0:
        so_what_parts.append(
            "CRITICAL: Zero active contributors this month. "
            "Development has effectively halted. No code is being "
            "written, reviewed, or merged."
        )
    elif curr_active < prev_active:
        drop = prev_active - curr_active
        drop_pct = (drop / prev_active * 100) if prev_active > 0 else 0
        so_what_parts.append(
            f"Contributor activity dropped {drop_pct:.0f}% "
            f"({prev_active} -> {curr_active}). "
            f"{'Significant decline — ' if drop_pct > 30 else ''}"
            f"fewer developers actively maintaining the codebase."
        )
    elif curr_active > prev_active:
        gain = curr_active - prev_active
        so_what_parts.append(
            f"Contributor activity increased by {gain} "
            f"({prev_active} -> {curr_active}). "
            f"Positive trend for ecosystem health."
        )
    else:
        so_what_parts.append(f"Contributor activity stable at {curr_active} active contributors.")

    if new_count > 0:
        new_names = ", ".join(trends["new_this_month"][:5])
        more = f" (+{new_count - 5} more)" if new_count > 5 else ""
        so_what_parts.append(
            f"New contributors: {new_names}{more}. Fresh contributors "
            f"broaden the talent pool and reduce bus factor risk."
        )

    so_what = " ".join(so_what_parts)

    # NOW WHAT
    now_what_parts = []
    if curr_active == 0:
        now_what_parts.append(
            "Action: investigate why development has stalled. "
            "Our ZenonOrg contributions may be the only active "
            "development — prioritize accordingly."
        )
    elif curr_active < 3:
        now_what_parts.append(
            f"Action: only {curr_active} active contributor(s). "
            f"Our ZenonOrg work is critical for ecosystem continuity. "
            f"Prioritize upstream PRs to keep the codebase alive."
        )
    elif new_count > 0:
        now_what_parts.append(
            "Action: welcome new contributors. Review their PRs "
            "promptly to encourage continued participation."
        )
    else:
        now_what_parts.append("Action: continue monitoring. Stable contributor base is healthy.")

    now_what = " ".join(now_what_parts)

    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"


def _build_bus_factor_finding(alert: dict) -> str:
    """Build actionable bus factor alert.

    Answers WHAT / SO WHAT / NOW WHAT.
    """
    repo = alert["repo"]
    bf = alert["bus_factor"]
    top = alert["top_contributor"]
    commits = alert["total_commits"]

    # WHAT
    what = (
        f"Critical repo {repo} has bus factor {bf}. "
        f"Top contributor: {top} ({commits} total commits)."
    )

    # SO WHAT
    if bf == 0:
        so_what = (
            f"{repo} has NO contributors — the repo appears abandoned. "
            f"If this is a critical dependency, our work depends on "
            f"unmaintained code."
        )
    elif bf == 1:
        repo_name = repo.split("/")[-1]
        # Map repos to their expertise area
        expertise_map = {
            "go-zenon": "core protocol and consensus",
            "syrius": "wallet UI and user experience",
            "znn_sdk_dart": "Dart SDK and developer tooling",
            "znn_cli_dart": "CLI tooling",
            "nomctl": "Go CLI and node management",
            "orchestrator": "bridge orchestration",
            "hyperqube_z": "extension chain framework",
        }
        expertise = expertise_map.get(repo_name, "this codebase")
        so_what = (
            f"If {top} stops contributing, {expertise} expertise is "
            f"lost. No other contributor has enough context to maintain "
            f"{repo_name} effectively. This is a single point of failure "
            f"for the ecosystem."
        )
    else:
        so_what = (
            f"Bus factor is low at {bf}. Only {bf} contributor(s) account for >50% of commits."
        )

    # NOW WHAT
    if bf <= 1:
        now_what = (
            f"Action: our ZenonOrg contributions to {repo.split('/')[-1]} "
            f"help mitigate this risk. Continue building expertise and "
            f"submitting PRs. Document institutional knowledge in "
            f"code comments and wiki pages so it survives contributor "
            f"turnover."
        )
    else:
        now_what = (
            "Action: monitor for changes. If any top contributor "
            "becomes inactive, escalate bus factor concern."
        )

    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"


def _build_repo_finding(summary: dict, trends: dict) -> str:
    """Build actionable per-repo contributor finding."""
    repo = summary["repo"]
    count = summary["contributor_count"]
    bf = summary["bus_factor"]
    commits = summary["total_commits"]
    last_commit = summary.get("last_commit_date", "unknown")

    repo_name = repo.split("/")[-1]

    # Check if repo had recent activity
    curr_active_names = set()
    curr_contribs = trends.get("_current_contribs", {}).get(repo, [])
    for c in curr_contribs:
        curr_active_names.add(c["name"])

    active_count = len(curr_active_names)

    # WHAT
    what = (
        f"{repo}: {count} all-time contributors, {active_count} active "
        f"in current month, bus factor {bf}, {commits} total commits. "
        f"Last commit: {last_commit[:10] if last_commit != 'unknown' else 'unknown'}."
    )

    # SO WHAT
    if active_count == 0 and repo_name in CRITICAL_REPOS:
        so_what = (
            "Critical repo with ZERO active contributors this month. "
            "Effectively unmaintained until our ZenonOrg work."
        )
    elif active_count == 0:
        so_what = "No recent activity. May be stable or abandoned."
    elif bf <= 1 and repo_name in CRITICAL_REPOS:
        so_what = "Critical repo with bus factor 1 — fragile maintainership."
    else:
        so_what = "Contributor health is adequate for this repo."

    # NOW WHAT
    if active_count == 0 and repo_name in CRITICAL_REPOS:
        now_what = (
            f"Action: our ZenonOrg contributions are keeping "
            f"{repo_name} alive. Prioritize upstream PRs for visibility."
        )
    else:
        now_what = "Action: continue monitoring."

    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run full analysis and persist actionable findings.

    Skips work if none of the workspace repos have changed HEAD.
    Every finding answers WHAT / SO WHAT / NOW WHAT.
    Returns the number of findings persisted.
    """
    from core.git_cache import has_repo_changed
    from core.persist_to_db import ensure_schema, persist_finding

    # Check if any workspace repos changed since last scan.
    any_changed = False
    for scan_dir in SCAN_DIRS[:5]:  # Sample top-priority orgs
        parent = ZENON_WORKSPACE / scan_dir
        if not parent.is_dir():
            continue
        for entry in parent.iterdir():
            if entry.is_dir() and (entry / ".git").is_dir():
                if has_repo_changed(str(entry)):
                    any_changed = True
                    break
        if any_changed:
            break

    if not any_changed:
        logger.debug("Skipping contributor tracker — no repo HEAD changed")
        return 0

    ensure_schema(db_path)
    count = 0

    trends = analyze_contributor_trends()

    # Store current month contribs for per-repo analysis
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    curr_year, curr_month = now.year, now.month
    current_contribs = get_monthly_contributors(curr_year, curr_month)
    trends["_current_contribs"] = current_contribs

    # Persist actionable trend finding
    trend_finding = _build_trend_finding(trends)
    persist_finding(
        db_path=db_path,
        domain="community",
        engine="contributor_tracker",
        evidence_type="contributor_trend",
        finding=trend_finding,
        confidence=0.95,
        raw_data={k: v for k, v in trends.items() if k != "_current_contribs"},
        source_repo="workspace",
    )
    count += 1

    # Persist actionable bus factor alerts
    for alert in trends["bus_factor_alerts"]:
        alert_finding = _build_bus_factor_finding(alert)
        persist_finding(
            db_path=db_path,
            domain="community",
            engine="contributor_tracker",
            evidence_type="bus_factor_alert",
            finding=alert_finding,
            confidence=0.90,
            raw_data=alert,
            source_repo=alert["repo"],
        )
        count += 1

    # Persist actionable per-repo summaries (only for critical repos)
    for summary in get_per_repo_summary():
        repo_name = summary["repo"].split("/")[-1]
        if repo_name in CRITICAL_REPOS:
            repo_finding = _build_repo_finding(summary, trends)
            persist_finding(
                db_path=db_path,
                domain="community",
                engine="contributor_tracker",
                evidence_type="repo_contributor_summary",
                finding=repo_finding,
                confidence=0.95,
                raw_data=summary,
                source_repo=summary["repo"],
            )
            count += 1

    # Enrich with GitHub API data (stars, open issues) as supplementary context
    try:
        from core.github_api import get_repo_info

        # Pull the current top-contributor repos inside the function so we
        # don't depend on an outer-scope `all_time` (was an F821 NameError
        # waiting to happen).
        all_time = get_all_time_contributors()
        for repo_key in list(all_time.keys())[:10]:
            org_dir, repo_name = repo_key.split("/", 1)
            gh_org = {
                "core": "zenon-network",
                "hypercore-one": "hypercore-one",
                "HyperCore-Team": "HyperCore-Team",
                "zenon-org": "ZenonOrg",
                "knowledge": "zenon-network",
            }.get(org_dir)
            if not gh_org:
                continue
            info = get_repo_info(gh_org, repo_name)
            if info:
                persist_finding(
                    db_path=db_path,
                    domain="community",
                    engine="contributor_tracker",
                    evidence_type="repo_github_stats",
                    finding=(
                        f"WHAT: {repo_key} has {info['stars']} stars, "
                        f"{info['open_issues']} open issues, {info['forks']} forks. "
                        f"Last pushed: {info.get('pushed_at', 'unknown')[:10]}. "
                        f"SO WHAT: Stars and forks indicate community interest; "
                        f"open issues indicate maintenance demand. "
                        f"NOW WHAT: {'High open issue count — triage needed.' if info['open_issues'] > 20 else 'Issue count is manageable.'}"
                    ),
                    confidence=0.80,
                    raw_data=info,
                    source_repo=repo_key,
                )
                count += 1
    except Exception as exc:
        # GitHub API unavailable — git log data is sufficient
        logger.debug("ContributorTracker GitHub enrichment skipped: %s", exc)

    logger.info("ContributorTracker: persisted %d actionable findings", count)
    return count
