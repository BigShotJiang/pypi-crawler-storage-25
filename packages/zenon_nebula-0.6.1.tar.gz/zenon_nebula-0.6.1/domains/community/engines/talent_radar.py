# SPDX-License-Identifier: MIT
"""
TalentRadar -- Find contributor patterns across the Zenon workspace.

Scans git logs from all local repos (NO API calls, NO doxxing) to identify:
- Core contributors (active in last 30d across 2+ repos)
- At-risk contributors (active 6mo ago, nothing recent)
- Growth opportunities (single-repo contributors who could expand)
- Bus factor risk (repos with only 1 active contributor)

All data comes from local git history only.
"""

import logging
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persist_to_db import ensure_schema, persist_finding
from domains.community.git_helpers import (
    ZENON_WORKSPACE,
    run_git,
)
from domains.community.git_helpers import (
    find_repos as _find_repos_base,
)

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Repos considered critical for bus factor analysis (superset of
# contributor_tracker's CRITICAL_REPOS -- talent_radar also tracks
# wiki and developer-commons).
CRITICAL_REPOS = frozenset(
    {
        "go-zenon",
        "syrius",
        "znn_sdk_dart",
        "znn_cli_dart",
        "nomctl",
        "orchestrator",
        "hyperqube_z",
        "znn-wiki",
        "developer-commons",
    }
)


def _find_repos() -> list[tuple[str, str, Path]]:
    """Find all git repos in the workspace.

    Wraps contributor_tracker.find_repos() and adds the full Path,
    which talent_radar needs for language detection.

    Returns list of (org_dir, repo_name, full_path) tuples.
    """
    repos = []
    for org_dir, repo_name in _find_repos_base():
        full_path = ZENON_WORKSPACE / org_dir / repo_name
        repos.append((org_dir, repo_name, full_path))
    return repos


def _get_contributors(
    repo_path: Path,
    since: str | None = None,
) -> list[tuple[str, str]]:
    """Get contributor names and dates from git log.

    Returns list of (author_name, iso_date) tuples.
    """
    args = ["log", "--format=%aN\t%aI", "--no-merges"]
    if since:
        args.append(f"--since={since}")

    code, output = run_git(str(repo_path), *args, timeout=60)
    if code != 0 or not output:
        return []

    results = []
    for line in output.splitlines():
        parts = line.split("\t", 1)
        if len(parts) == 2:
            results.append((parts[0].strip(), parts[1].strip()))
    return results


def _get_contributor_languages(
    repo_path: Path,
    author: str,
) -> set[str]:
    """Determine what languages a contributor works with based on file extensions."""
    code, output = run_git(
        str(repo_path),
        "log",
        "--format=",
        "--name-only",
        "--no-merges",
        f"--author={author}",
        "--diff-filter=ACMR",
        timeout=30,
    )
    if code != 0 or not output:
        return set()

    ext_to_lang = {
        ".go": "Go",
        ".dart": "Dart",
        ".js": "JavaScript",
        ".ts": "TypeScript",
        ".py": "Python",
        ".php": "PHP",
        ".rs": "Rust",
        ".java": "Java",
        ".sol": "Solidity",
        ".md": "Docs",
        ".yml": "CI/Config",
        ".yaml": "CI/Config",
    }

    langs = set()
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue
        for ext, lang in ext_to_lang.items():
            if line.endswith(ext):
                langs.add(lang)
                break

    return langs


def scan_contributors() -> dict:
    """Scan all repos and build contributor profiles.

    Returns dict with:
    - contributors: dict mapping author -> profile
    - repo_stats: dict mapping repo_name -> stats
    - classifications: dict with core/atrisk/growth lists
    """
    repos = _find_repos()
    now = datetime.now(timezone.utc)
    thirty_days_ago = (now - timedelta(days=30)).isoformat()
    ninety_days_ago = (now - timedelta(days=90)).isoformat()
    (now - timedelta(days=180)).isoformat()

    # Gather all contributor data
    # contributor -> {repos: set, last_commit: date, commit_count: int, languages: set}
    contributors: dict[str, dict] = defaultdict(
        lambda: {
            "repos": set(),
            "org_dirs": set(),
            "last_commit": "",
            "commit_count": 0,
            "recent_30d": 0,
            "recent_90d": 0,
            "languages": set(),
        }
    )

    # repo_name -> {total_contributors, active_30d, active_90d, bus_factor}
    repo_stats: dict[str, dict] = {}

    for org_dir, repo_name, repo_path in repos:
        # Get all-time contributors
        all_contribs = _get_contributors(repo_path)
        # Get recent contributors
        recent_30d = _get_contributors(repo_path, since=thirty_days_ago)
        recent_90d = _get_contributors(repo_path, since=ninety_days_ago)

        repo_key = f"{org_dir}/{repo_name}"
        all_authors = set()
        active_30d_authors = set()
        active_90d_authors = set()

        for author, date_str in all_contribs:
            all_authors.add(author)
            profile = contributors[author]
            profile["repos"].add(repo_key)
            profile["org_dirs"].add(org_dir)
            profile["commit_count"] += 1
            if not profile["last_commit"] or date_str > profile["last_commit"]:
                profile["last_commit"] = date_str

        for author, _ in recent_30d:
            active_30d_authors.add(author)
            contributors[author]["recent_30d"] += 1

        for author, _ in recent_90d:
            active_90d_authors.add(author)
            contributors[author]["recent_90d"] += 1

        repo_stats[repo_key] = {
            "total_contributors": len(all_authors),
            "active_30d": len(active_30d_authors),
            "active_90d": len(active_90d_authors),
            "is_critical": repo_name in CRITICAL_REPOS,
        }

    # Determine languages per contributor (sample from first 3 repos)
    for author, profile in contributors.items():
        sampled = 0
        for org_dir, repo_name, repo_path in repos:
            repo_key = f"{org_dir}/{repo_name}"
            if repo_key in profile["repos"]:
                langs = _get_contributor_languages(repo_path, author)
                profile["languages"].update(langs)
                sampled += 1
                if sampled >= 3:
                    break

    # Classify contributors
    core_contributors = []
    at_risk = []
    growth_opportunities = []

    for author, profile in contributors.items():
        repo_count = len(profile["repos"])
        has_recent_30d = profile["recent_30d"] > 0
        has_recent_90d = profile["recent_90d"] > 0

        # Parse last commit date for staleness check
        last_commit_stale_6mo = False
        if profile["last_commit"]:
            try:
                last_dt = datetime.fromisoformat(
                    profile["last_commit"].replace("Z", "+00:00"),
                )
                days_since = (now - last_dt).days
                last_commit_stale_6mo = 90 < days_since <= 365
            except (ValueError, TypeError):
                pass

        # Core: active in last 30d across 2+ repos
        if has_recent_30d and repo_count >= 2:
            core_contributors.append(
                {
                    "author": author,
                    "repos": sorted(profile["repos"]),
                    "repo_count": repo_count,
                    "commit_count": profile["commit_count"],
                    "languages": sorted(profile["languages"]),
                }
            )

        # At-risk: was active 6mo ago but nothing in last 90d
        elif last_commit_stale_6mo and not has_recent_90d:
            at_risk.append(
                {
                    "author": author,
                    "repos": sorted(profile["repos"]),
                    "repo_count": repo_count,
                    "last_commit": profile["last_commit"][:10],
                    "languages": sorted(profile["languages"]),
                }
            )

        # Growth: only 1 repo but active
        elif repo_count == 1 and has_recent_90d:
            growth_opportunities.append(
                {
                    "author": author,
                    "repos": sorted(profile["repos"]),
                    "commit_count": profile["commit_count"],
                    "languages": sorted(profile["languages"]),
                }
            )

    # Bus factor analysis
    bus_factor_risks = []
    for repo_key, stats in repo_stats.items():
        if stats["is_critical"] and stats["active_90d"] <= 1:
            bus_factor_risks.append(
                {
                    "repo": repo_key,
                    "total_contributors": stats["total_contributors"],
                    "active_90d": stats["active_90d"],
                    "active_30d": stats["active_30d"],
                }
            )

    # Convert sets to lists for JSON serialization
    serializable_contributors = {}
    for author, profile in contributors.items():
        serializable_contributors[author] = {
            "repos": sorted(profile["repos"]),
            "repo_count": len(profile["repos"]),
            "commit_count": profile["commit_count"],
            "last_commit": profile["last_commit"][:10] if profile["last_commit"] else "",
            "recent_30d": profile["recent_30d"],
            "recent_90d": profile["recent_90d"],
            "languages": sorted(profile["languages"]),
        }

    return {
        "total_contributors": len(contributors),
        "total_repos_scanned": len(repos),
        "core_contributors": core_contributors,
        "at_risk": at_risk,
        "growth_opportunities": growth_opportunities,
        "bus_factor_risks": bus_factor_risks,
        "repo_stats": repo_stats,
        "contributors": serializable_contributors,
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run talent radar scan and persist findings to evidence table.

    Returns the number of findings persisted.
    """
    ensure_schema(db_path)
    report = scan_contributors()
    count = 0

    # Overall community health finding
    core_count = len(report["core_contributors"])
    at_risk_count = len(report["at_risk"])
    bus_risks = len(report["bus_factor_risks"])

    persist_finding(
        db_path=db_path,
        domain="community",
        engine="talent_radar",
        evidence_type="community_health",
        finding=(
            f"WHAT: {report['total_contributors']} total contributors across "
            f"{report['total_repos_scanned']} repos. {core_count} core "
            f"(active 30d, 2+ repos), {at_risk_count} at-risk (fading), "
            f"{len(report['growth_opportunities'])} growth opportunities. "
            f"SO WHAT: {'Healthy core team. ' if core_count >= 3 else 'Small core team -- high concentration risk. '}"
            f"{'WARNING: ' + str(bus_risks) + ' critical repos have bus factor <= 1. ' if bus_risks > 0 else ''}"
            f"NOW WHAT: "
            f"{'Focus on expanding contributor base for bus-factor-1 repos. ' if bus_risks > 0 else ''}"
            f"{'Re-engage ' + str(at_risk_count) + ' fading contributors. ' if at_risk_count > 0 else ''}"
            f"{'Encourage ' + str(len(report['growth_opportunities'])) + ' single-repo contributors to expand. ' if report['growth_opportunities'] else ''}"
        ),
        confidence=0.90,
        raw_data={
            "total_contributors": report["total_contributors"],
            "core_count": core_count,
            "at_risk_count": at_risk_count,
            "growth_count": len(report["growth_opportunities"]),
            "bus_factor_risks": bus_risks,
        },
        source_repo="workspace",
    )
    count += 1

    # Bus factor findings
    for risk in report["bus_factor_risks"]:
        persist_finding(
            db_path=db_path,
            domain="community",
            engine="talent_radar",
            evidence_type="bus_factor_risk",
            finding=(
                f"WHAT: {risk['repo']} has {risk['total_contributors']} total "
                f"contributors but only {risk['active_90d']} active in last "
                f"90 days (bus factor {risk['active_90d']}). "
                f"SO WHAT: If the primary maintainer stops, no one can review "
                f"PRs or fix critical bugs. "
                f"NOW WHAT: Our contributions to {risk['repo'].split('/')[-1]} "
                f"help mitigate this. Prioritize getting 2+ PRs merged to "
                f"establish as trusted contributor."
            ),
            confidence=0.85,
            raw_data=risk,
            source_repo=risk["repo"],
            supports_hypothesis="bus_factor_risk",
        )
        count += 1

    # At-risk contributor findings (aggregate, not per-person)
    if report["at_risk"]:
        at_risk_summary = ", ".join(
            f"{c['author']} ({c['last_commit']})" for c in report["at_risk"][:10]
        )
        persist_finding(
            db_path=db_path,
            domain="community",
            engine="talent_radar",
            evidence_type="contributor_churn",
            finding=(
                f"WHAT: {at_risk_count} contributors active 3-12 months ago "
                f"but silent in last 90 days: {at_risk_summary}. "
                f"SO WHAT: Losing experienced contributors shrinks the "
                f"review pool and slows development. "
                f"NOW WHAT: Community outreach may re-engage some. "
                f"Our active contributions partially compensate."
            ),
            confidence=0.80,
            raw_data={"at_risk": report["at_risk"][:20]},
            source_repo="workspace",
        )
        count += 1

    # Core contributors (positive finding)
    if report["core_contributors"]:
        core_summary = ", ".join(
            f"{c['author']} ({c['repo_count']} repos)" for c in report["core_contributors"][:10]
        )
        persist_finding(
            db_path=db_path,
            domain="community",
            engine="talent_radar",
            evidence_type="core_contributor_roster",
            finding=(
                f"WHAT: {core_count} core contributors active across "
                f"multiple repos in last 30 days: {core_summary}. "
                f"SO WHAT: These are the backbone of Zenon development. "
                f"NOW WHAT: Track their focus areas for collaboration "
                f"opportunities and to avoid duplicate work."
            ),
            confidence=0.90,
            raw_data={"core_contributors": report["core_contributors"]},
            source_repo="workspace",
            supports_hypothesis="community_growing",
        )
        count += 1

    logger.info("TalentRadar: persisted %d findings", count)
    return count
