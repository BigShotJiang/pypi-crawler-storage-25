# SPDX-License-Identifier: MIT
"""WorkspaceRecommender — safe clone recommendations from peer signal.

Phase F of the v0.4.0 content-based trust architecture (task #46).
Closes the loop from "a trusted peer found something interesting in
repo X" to "the operator has a one-click path to verify it locally"
without ever auto-cloning anything.

**Why not auto-clone?** Attack vectors are listed in task #46 Phase F:
distributed-download-as-a-service, legal/compliance exposure via
arbitrary content, identity linkage via authenticated git clones,
git-hook RCE on subsequent `git pull`, dependency confusion via
typosquatted names, transitive trust collapse, disk exhaustion.
Every one of those is a real attack on a Nebula fleet if we let
one peer's recommendation trigger every other peer's auto-clone.

**What we do instead.** Three safer layers, each independently
shippable and each strictly safer than the layer above:

1. **Recommendation findings.** When a peer's finding references a
   ``source_repo`` that the local instance doesn't have in its
   workspace AND the peer's dynamic trust tier is at least
   ``trusted`` (0.7), we emit a ``workspace_recommendation``
   finding with a WHAT/SO WHAT/NOW WHAT body. The operator sees
   it, decides manually whether to add the repo, and runs
   ``./nebula workspace add <repo>`` by hand. Nebula never acts
   without the operator's explicit command.

2. **Operator-initiated clone** (future ``./nebula workspace add``
   CLI command — not in this phase, tracked as a follow-up).
   Shallow clone, size-capped, logged to actions_log with full
   provenance.

3. **Peek mode** (future opt-in via ``NEBULA_ENABLE_PEEK_MODE=1``
   env var — also a follow-up). Fetches individual markdown /
   toml / yml files via GitHub's unauthenticated raw API without
   cloning the repo or creating a git working tree. Tracked as a
   Phase F+ extension.

This module is the RECOMMENDATION layer only (layer 1). It runs
every cycle, reads recent peer findings, and emits recommendations
where appropriate. It does not clone anything. It does not fetch
files. It only produces findings that say "here's a repo your
trusted peers found interesting — you may want to add it."

**Anti-doxxing guarantee for the recommender.** The recommendation
body reports the RECOMMENDING PEER'S TIER, not the peer's identity.
Operators reading a recommendation see "a peer at the trusted
tier" instead of "peer:bob123." This prevents third parties from
building profiles of "peer X recommends these 50 repos" which
would eventually deanonymize peer X by their taste. The masking
matches the war room's tier-not-name contract from v0.4.2.
"""

from __future__ import annotations

import logging
import sqlite3
from pathlib import Path
from typing import Any

from core.persistence import connect
from core.persistence.findings import persist_finding
from core.persistence.schema import DEFAULT_DB
from core.workspace import workspace_root

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]

# Only recommend repos where the publishing peer's dynamic trust
# is at least 0.5 (attested tier). Below that, the recommendation
# is indistinguishable from random noise.
_MIN_RECOMMENDER_TRUST = 0.5

# Don't recommend the same repo twice per run.
# (Longer-term dedup is handled by content_hash in persist_finding.)
_RECOMMENDATION_WINDOW_HOURS = 72


def _resolve_tier_name(trust: float) -> str:
    """Map a dynamic trust score to a tier label for the recommendation body."""
    if trust >= 0.90:
        return "core"
    if trust >= 0.70:
        return "trusted"
    if trust >= 0.50:
        return "attested"
    return "default"


def _is_locally_cloned(repo_identity: str, ws: Path) -> bool:
    """Return True if the repo_identity corresponds to a directory in ws.

    The match is best-effort: we check the basename against every
    two-level-deep subdirectory under ws. Canonical owner/repo
    identities from git_cache collapse to just "repo" here so we
    match by basename.
    """
    if not ws.is_dir():
        return False
    basename = repo_identity.rsplit("/", 1)[-1]
    for top in ws.iterdir():
        if not top.is_dir() or top.name.startswith("."):
            continue
        if top.name == basename:
            return True
        try:
            for child in top.iterdir():
                if not child.is_dir() or child.name.startswith("."):
                    continue
                if child.name == basename:
                    return True
        except OSError:
            continue
    return False


def _format_recommendation(
    repo_identity: str,
    recommender_tier: str,
    recent_finding_count: int,
    ws: Path,
) -> str:
    """Render a workspace_recommendation finding body.

    Never names the recommending peer — uses the tier label only.
    Operator gets a clear NOW WHAT with the exact command they
    could run AND an explicit warning about never running code
    they haven't reviewed.
    """
    return (
        f"WHAT: A peer at the `{recommender_tier}` trust tier is "
        f"producing findings from `{repo_identity}`, which is not "
        f"currently in your workspace. {recent_finding_count} "
        f"finding(s) referencing this repo surfaced in the last "
        f"{_RECOMMENDATION_WINDOW_HOURS}h. "
        f"SO WHAT: You cannot corroborate or reproduce those "
        f"findings locally without the repo present. Adding it "
        f"would unlock the content-scanning engines "
        f"(adversarial_reviewer, spec_audit, curiosity_scanner, "
        f"pattern_discoverer, source_quality_scorer) against the "
        f"new repo's content. The recommending peer's `{recommender_tier}` "
        f"tier means their content-quality score has been "
        f"sustained long enough to earn that tier — but that's "
        f"NOT an endorsement of the repo, only of the peer's "
        f"signal quality. "
        f"NOW WHAT: To review before cloning, visit "
        f"`https://github.com/{repo_identity}` in a browser and "
        f"inspect the content. To clone (future v0.4.x): "
        f"`./nebula workspace add {repo_identity}` will shallow-"
        f"clone the repo into your workspace. "
        f"WARNING: Nebula never auto-clones from peer "
        f"recommendations — you are the one who decides. Do NOT "
        f"add repos whose content you cannot visually verify first."
    )


def run_workspace_recommender(db_path: str | None = None) -> dict[str, Any]:
    """Scan recent peer findings and emit workspace recommendations.

    Reads evidence rows from the last ``_RECOMMENDATION_WINDOW_HOURS``
    hours, groups by ``source_repo``, checks which source_repos are
    NOT present in the local workspace, filters to source_repos whose
    most-recent discoverer_peer_id has dynamic trust >= 0.5, and
    emits one ``workspace_recommendation`` finding per qualifying
    repo.

    Degrades gracefully:
    - workspace missing -> empty result
    - no recent findings -> empty result
    - no qualifying source_repos -> empty result
    - trust module import failure -> empty result (safer than
      recommending repos we can't verify trust for)

    Args:
        db_path: SQLite DB (defaults to DEFAULT_DB).

    Returns:
        Summary dict with ``recent_source_repos``,
        ``locally_cloned``, ``qualifying_recommendations``,
        ``findings_persisted``, ``workspace_root``.
    """
    db_path = db_path or DEFAULT_DB

    ws = workspace_root()
    if ws is None:
        logger.info("workspace_recommender: workspace not installed; skipping")
        return {
            "recent_source_repos": 0,
            "locally_cloned": 0,
            "qualifying_recommendations": 0,
            "findings_persisted": 0,
            "workspace_root": None,
            "reason": "workspace not installed",
        }

    try:
        from core.trust import compute_dynamic_trust
    except Exception as exc:
        logger.debug("workspace_recommender: trust import failed: %s", exc)
        return {
            "recent_source_repos": 0,
            "locally_cloned": 0,
            "qualifying_recommendations": 0,
            "findings_persisted": 0,
            "workspace_root": str(ws),
            "reason": "trust module unavailable",
        }

    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            f"""
            SELECT source_repo, COUNT(*) AS finding_count
            FROM evidence
            WHERE source_repo IS NOT NULL
              AND source_repo != ''
              AND timestamp > datetime('now', '-{_RECOMMENDATION_WINDOW_HOURS} hours')
            GROUP BY source_repo
            """
        ).fetchall()
    except sqlite3.OperationalError as exc:
        logger.debug("workspace_recommender: evidence query failed: %s", exc)
        conn.close()
        return {
            "recent_source_repos": 0,
            "locally_cloned": 0,
            "qualifying_recommendations": 0,
            "findings_persisted": 0,
            "workspace_root": str(ws),
            "reason": "evidence table missing",
        }
    finally:
        if conn:
            conn.close()

    total_recent = len(rows)
    locally_cloned = 0
    qualifying = 0
    persisted = 0

    for row in rows:
        repo_identity = row["source_repo"]
        finding_count = row["finding_count"]

        if _is_locally_cloned(repo_identity, Path(ws)):
            locally_cloned += 1
            continue

        try:
            recommender_trust = compute_dynamic_trust(repo_identity, db_path=db_path)
        except Exception:
            continue

        if recommender_trust < _MIN_RECOMMENDER_TRUST:
            continue

        qualifying += 1
        tier_name = _resolve_tier_name(recommender_trust)
        body = _format_recommendation(repo_identity, tier_name, finding_count, Path(ws))

        try:
            row_id = persist_finding(
                db_path=db_path,
                domain="contribution",
                engine="workspace_recommender",
                evidence_type="workspace_recommendation",
                finding=body,
                confidence=min(0.75, recommender_trust),
                source_repo=repo_identity,
                raw_data={
                    "recommender_tier": tier_name,
                    "recent_finding_count": finding_count,
                    "window_hours": _RECOMMENDATION_WINDOW_HOURS,
                },
            )
            if row_id and row_id > 0:
                persisted += 1
        except Exception as exc:
            logger.debug(
                "workspace_recommender: persist failed for %s: %s",
                repo_identity,
                exc,
            )

    logger.info(
        "workspace_recommender: %d recent source_repos, "
        "%d locally cloned, %d qualifying, %d recommendations persisted",
        total_recent,
        locally_cloned,
        qualifying,
        persisted,
    )
    return {
        "recent_source_repos": total_recent,
        "locally_cloned": locally_cloned,
        "qualifying_recommendations": qualifying,
        "findings_persisted": persisted,
        "workspace_root": str(ws),
    }
