# SPDX-License-Identifier: MIT
"""
AutoContributor -- Generate contribution recommendations from high-confidence evidence.

Queries the evidence table for open findings with high confidence
(mismatches, vulnerabilities, coverage gaps, bugs) and generates
actionable contribution opportunities with priority rankings.

No LLM calls. Reads existing evidence to produce contribution plans.
"""

import contextlib
import json
import logging
import sqlite3
from pathlib import Path

from core.config import get_config
from core.persist_to_db import ensure_schema, persist_finding
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Evidence types that indicate actionable issues
ACTIONABLE_TYPES = frozenset(
    {
        "mismatch",
        "vulnerability",
        "coverage_gap",
        "bug_found",
        "address_mismatch",
        "field_mismatch",
        "abi_mismatch",
        "missing_method",
        "security_finding",
        "onboarding_gap",
    }
)

# Minimum confidence to consider a finding actionable.
# Sourced from config/engine_defaults.json with a safe fallback.
MIN_CONFIDENCE = get_config().engine("auto_contributor").get("min_confidence", 0.85)

# Priority ordering: security > bug > mismatch > coverage gap
PRIORITY_MAP = {
    "vulnerability": 1,
    "security_finding": 1,
    "address_mismatch": 2,
    "bug_found": 2,
    "mismatch": 3,
    "field_mismatch": 3,
    "abi_mismatch": 3,
    "missing_method": 4,
    "coverage_gap": 5,
    "onboarding_gap": 6,
}

PRIORITY_LABELS = {
    1: "CRITICAL",
    2: "HIGH",
    3: "MEDIUM",
    4: "MEDIUM",
    5: "LOW",
    6: "LOW",
}


def _query_actionable_evidence(db_path: str) -> list[dict]:
    """Query evidence table for high-confidence actionable findings.

    Returns list of dicts with id, evidence_type, finding, confidence,
    source_repo, source_file, raw_data.
    """
    try:
        conn = connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        placeholders = ", ".join("?" for _ in ACTIONABLE_TYPES)
        query = f"""
            SELECT id, evidence_type, finding, confidence,
                   source_repo, source_file, source_commit,
                   raw_data, domain, engine
            FROM evidence
            WHERE confidence >= ?
              AND evidence_type IN ({placeholders})
              AND status = 'open'
            ORDER BY confidence DESC, timestamp DESC
        """
        params = [MIN_CONFIDENCE, *list(ACTIONABLE_TYPES)]
        cursor.execute(query, params)

        rows = []
        for row in cursor.fetchall():
            rows.append(dict(row))
        conn.close()
        return rows

    except sqlite3.OperationalError as exc:
        logger.warning("Failed to query evidence table: %s", exc)
        return []


def _already_has_contribution(
    db_path: str,
    parent_id: int,
) -> bool:
    """Check if a contribution_opportunity already exists for this parent finding."""
    try:
        conn = connect(db_path)
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT COUNT(*) FROM evidence
            WHERE evidence_type = 'contribution_opportunity'
              AND parent_finding_id = ?
              AND status = 'open'
            """,
            (parent_id,),
        )
        count = cursor.fetchone()[0]
        conn.close()
        return count > 0
    except sqlite3.OperationalError:
        return False


def _determine_target_repo(evidence: dict) -> str:
    """Determine which repo a fix should be applied to.

    For mismatches, the fix usually goes to the SDK/CLI repo (not go-zenon,
    which is the source of truth). For vulnerabilities, it depends on where
    the vuln lives.
    """
    source_repo = evidence.get("source_repo", "")
    evidence_type = evidence.get("evidence_type", "")
    finding_text = evidence.get("finding", "")

    # Address/field/ABI mismatches: fix goes to whichever repo is wrong
    # Usually the SDK, since go-zenon is source of truth
    if evidence_type in ("address_mismatch", "field_mismatch", "abi_mismatch"):
        # If the finding mentions a specific SDK, target that
        if "znn_sdk_dart" in finding_text:
            return "znn_sdk_dart"
        if "nomctl" in finding_text:
            return "nomctl"
        if "znn_cli_dart" in finding_text:
            return "znn_cli_dart"
        # Default: the source_repo from the evidence
        return source_repo or "unknown"

    return source_repo or "unknown"


def _determine_fix_description(evidence: dict) -> str:
    """Generate a human-readable fix description from the evidence.

    Extracts what needs to change from the finding text and raw_data.
    """
    finding = evidence.get("finding", "")
    evidence_type = evidence.get("evidence_type", "")
    source_file = evidence.get("source_file", "")

    raw_data = {}
    if evidence.get("raw_data"):
        with contextlib.suppress(json.JSONDecodeError, TypeError):
            raw_data = (
                json.loads(evidence["raw_data"])
                if isinstance(
                    evidence["raw_data"],
                    str,
                )
                else evidence["raw_data"]
            )

    # Build fix description from finding content
    if evidence_type in ("address_mismatch", "field_mismatch", "abi_mismatch"):
        fix = f"Fix {evidence_type.replace('_', ' ')} in {source_file}."
        if "expected" in raw_data and "actual" in raw_data:
            fix += f" Expected: {raw_data['expected']}, found: {raw_data['actual']}."
        return fix

    if evidence_type == "missing_method":
        method = raw_data.get("method_name", "unknown")
        return f"Add missing method '{method}' to {source_file}."

    if evidence_type in ("vulnerability", "security_finding"):
        return f"Address security finding in {source_file}: {finding[:200]}"

    if evidence_type == "coverage_gap":
        return f"Close coverage gap: {finding[:200]}"

    if evidence_type == "bug_found":
        return f"Fix bug in {source_file}: {finding[:200]}"

    return f"Investigate and resolve: {finding[:200]}"


def generate_contributions(db_path: str = DEFAULT_DB) -> list[dict]:
    """Generate contribution recommendations from actionable evidence.

    Returns list of contribution dicts, each with:
    - parent_finding_id: the evidence this is based on
    - source_file: what file needs changing
    - fix_description: what the change should be
    - target_repo: which repo to PR to
    - priority: numeric priority (1=CRITICAL, 6=LOW)
    - priority_label: human-readable priority
    - evidence_type: type of the source evidence
    - confidence: confidence from the source evidence
    """
    evidence_rows = _query_actionable_evidence(db_path)
    contributions = []

    for ev in evidence_rows:
        # Skip if we already generated a contribution for this finding
        if _already_has_contribution(db_path, ev["id"]):
            continue

        target_repo = _determine_target_repo(ev)
        fix_description = _determine_fix_description(ev)
        priority = PRIORITY_MAP.get(ev["evidence_type"], 5)
        priority_label = PRIORITY_LABELS.get(priority, "LOW")

        contributions.append(
            {
                "parent_finding_id": ev["id"],
                "source_file": ev.get("source_file", ""),
                "fix_description": fix_description,
                "target_repo": target_repo,
                "priority": priority,
                "priority_label": priority_label,
                "evidence_type": ev["evidence_type"],
                "confidence": ev["confidence"],
                "original_finding": ev["finding"],
                "source_domain": ev.get("domain", ""),
                "source_engine": ev.get("engine", ""),
            }
        )

    # Sort by priority (ascending = highest priority first), then confidence
    contributions.sort(key=lambda c: (c["priority"], -c["confidence"]))
    return contributions


def persist_contributions(db_path: str = DEFAULT_DB) -> int:
    """Generate and persist contribution opportunities to the evidence table.

    Returns the number of new contribution findings persisted.
    """
    ensure_schema(db_path)
    contributions = generate_contributions(db_path)
    count = 0

    for contrib in contributions:
        finding_text = (
            f"WHAT: {contrib['source_engine']} found "
            f"{contrib['evidence_type']} in {contrib['target_repo']}"
            f"{' / ' + contrib['source_file'] if contrib['source_file'] else ''}. "
            f"SO WHAT: {contrib['original_finding'][:300]} "
            f"NOW WHAT: {contrib['fix_description']} "
            f"Priority: {contrib['priority_label']} "
            f"({contrib['evidence_type']})."
        )

        persist_finding(
            db_path=db_path,
            domain="contribution",
            engine="auto_contributor",
            evidence_type="contribution_opportunity",
            finding=finding_text,
            confidence=contrib["confidence"],
            raw_data=contrib,
            parent_finding_id=contrib["parent_finding_id"],
            source_repo=contrib["target_repo"],
            source_file=contrib.get("source_file", ""),
        )
        count += 1

    logger.info(
        "AutoContributor: generated %d contribution opportunities from %d actionable findings.",
        count,
        len(contributions),
    )
    return count
