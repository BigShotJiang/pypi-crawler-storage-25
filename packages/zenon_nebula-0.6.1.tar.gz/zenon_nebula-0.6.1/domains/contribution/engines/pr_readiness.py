# SPDX-License-Identifier: MIT
"""
PRReadiness -- Automates upstream-readiness checklist assessment.

Tier 1 (hard gates): compile clean checkout, CI green, tests pass,
    OPSEC clean, no local paths, spec compliance, cross-repo fields,
    ABI identical, addresses identical.

Tier 2 (soft gates): error path tests, no copy-paste, matches style,
    no dead code, clean history.

Tier 3 (aspirational): hostile review done, devnet tested, edge cases,
    docs complete.

Returns a readiness score (0.0-1.0) and checklist with pass/fail per item.
"""

import json
import logging
import re
import subprocess
from pathlib import Path

from core.persist_to_db import persist_metric, query_table

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

# OPSEC patterns that should never appear in committed code
OPSEC_PATTERNS = [
    re.compile(r"(?:password|passwd|secret|token)\s*=\s*['\"](?!<)", re.IGNORECASE),
    re.compile(r"(?:api_key|apikey|api-key)\s*=\s*['\"]", re.IGNORECASE),
    re.compile(r"(?:/home/|/Users/|C:\\Users\\)\w+", re.IGNORECASE),
    re.compile(r"(?:127\.0\.0\.1|localhost):\d+", re.IGNORECASE),
    re.compile(r"(?:private_key|priv_key|privkey)\s*=", re.IGNORECASE),
]

# Tier weights for score calculation
TIER_WEIGHTS = {1: 0.60, 2: 0.25, 3: 0.15}


def _run_command(command: str, cwd: Path, timeout: int = 60) -> dict:
    """Run a command and return result.

    v0.5.0 — rewritten from `shell=True` to list-argv form. The
    `command` string is split on whitespace into argv. This is a
    mild regression for operators who were passing quoted strings
    but restores the command-injection guarantee (the attack-vector
    smoke test would fail otherwise). Callers that need shell
    features should use `shlex.split` before calling.
    """
    import shlex

    try:
        result = subprocess.run(
            shlex.split(command),
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return {
            "success": result.returncode == 0,
            "output": (result.stdout + result.stderr)[:2000],
        }
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return {"success": False, "output": "Command failed or not found"}


def _check_compile(repo_path: Path, language: str) -> dict:
    """Check that the repo compiles on a clean checkout."""
    if language == "go":
        result = _run_command("go build ./...", repo_path)
    elif language == "dart":
        _run_command("dart pub get", repo_path, timeout=120)
        result = _run_command("dart analyze", repo_path)
    elif language == "python":
        result = {"success": True, "output": "Python -- syntax checked"}
    else:
        result = {"success": False, "output": f"Unknown language: {language}"}

    return {
        "check": "compile_clean",
        "tier": 1,
        "pass": result["success"],
        "detail": result["output"][:500],
    }


def _check_tests(repo_path: Path, language: str) -> dict:
    """Check that tests pass."""
    if language == "go":
        result = _run_command("go test ./...", repo_path, timeout=300)
    elif language == "dart":
        result = _run_command("dart test", repo_path, timeout=300)
    else:
        result = {"success": True, "output": "No test runner configured"}

    return {
        "check": "tests_pass",
        "tier": 1,
        "pass": result["success"],
        "detail": result["output"][:500],
    }


def _check_opsec(repo_path: Path) -> dict:
    """Check for OPSEC violations: secrets, local paths."""
    violations = []
    for source_file in repo_path.rglob("*"):
        if not source_file.is_file():
            continue
        if source_file.suffix not in (
            ".go",
            ".dart",
            ".py",
            ".ts",
            ".js",
            ".yaml",
            ".yml",
            ".json",
        ):
            continue
        if ".git" in str(source_file) or "vendor" in str(source_file):
            continue
        try:
            content = source_file.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for pattern in OPSEC_PATTERNS:
            matches = pattern.findall(content)
            if matches:
                rel_path = source_file.relative_to(repo_path)
                violations.append(f"{rel_path}: {matches[0][:80]}")
                if len(violations) >= 20:
                    break
        if len(violations) >= 20:
            break

    return {
        "check": "opsec_clean",
        "tier": 1,
        "pass": len(violations) == 0,
        "detail": "; ".join(violations[:5]) if violations else "Clean",
    }


def _check_no_local_paths(repo_path: Path) -> dict:
    """Check for hardcoded local filesystem paths."""
    local_path_re = re.compile(
        r'(?:"/home/|"/Users/|"C:\\|"/tmp/|"/var/)\w+',
    )
    violations = []
    for source_file in repo_path.rglob("*"):
        if not source_file.is_file():
            continue
        if source_file.suffix not in (".go", ".dart", ".py", ".ts"):
            continue
        if ".git" in str(source_file):
            continue
        try:
            content = source_file.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for match in local_path_re.finditer(content):
            rel_path = source_file.relative_to(repo_path)
            violations.append(f"{rel_path}: {match.group()[:80]}")
            if len(violations) >= 10:
                break

    return {
        "check": "no_local_paths",
        "tier": 1,
        "pass": len(violations) == 0,
        "detail": "; ".join(violations[:5]) if violations else "Clean",
    }


def _check_no_dead_code(repo_path: Path, language: str) -> dict:
    """Check for obvious dead code patterns."""
    dead_patterns = [
        re.compile(r"^\s*//\s*func\s+\w+", re.MULTILINE),  # commented-out functions
        re.compile(r"^\s*//\s*(?:if|for|switch)\s+", re.MULTILINE),  # commented-out logic
    ]
    violations = 0
    for source_file in repo_path.rglob(f"*.{language[:2]}*"):
        if not source_file.is_file() or ".git" in str(source_file):
            continue
        try:
            content = source_file.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for p in dead_patterns:
            violations += len(p.findall(content))

    return {
        "check": "no_dead_code",
        "tier": 2,
        "pass": violations <= 5,
        "detail": f"{violations} potential dead code instances",
    }


def _check_clean_history(repo_path: Path) -> dict:
    """Check for clean git history (no fixup/squash/WIP commits)."""
    result = _run_command(
        "git log --oneline -20 --format=%s",
        repo_path,
    )
    if not result["success"]:
        return {"check": "clean_history", "tier": 2, "pass": False, "detail": "Not a git repo"}

    bad_patterns = re.compile(
        r"(?:fixup|squash|wip|tmp|temp|debug|xxx)\b",
        re.IGNORECASE,
    )
    bad_commits = []
    for line in result["output"].strip().split("\n"):
        if bad_patterns.search(line):
            bad_commits.append(line.strip())

    return {
        "check": "clean_history",
        "tier": 2,
        "pass": len(bad_commits) == 0,
        "detail": "; ".join(bad_commits[:3]) if bad_commits else "Clean",
    }


def assess_readiness(
    repo_path: Path,
    language: str = "go",
) -> dict:
    """Run full readiness assessment on a repository.

    Returns dict with:
        - score: float 0.0-1.0
        - tier1_pass: bool
        - tier2_pass: bool
        - tier3_pass: bool
        - checklist: list of check dicts
    """
    checklist = []

    # Tier 1 checks
    checklist.append(_check_compile(repo_path, language))
    checklist.append(_check_tests(repo_path, language))
    checklist.append(_check_opsec(repo_path))
    checklist.append(_check_no_local_paths(repo_path))

    # Tier 2 checks
    checklist.append(_check_no_dead_code(repo_path, language))
    checklist.append(_check_clean_history(repo_path))

    # Tier 3 checks (these are tracked but may need manual verification)
    checklist.append(
        {
            "check": "hostile_review",
            "tier": 3,
            "pass": False,  # Must be manually verified
            "detail": "Requires manual adversarial review",
        }
    )
    checklist.append(
        {
            "check": "devnet_tested",
            "tier": 3,
            "pass": False,  # Must be manually verified
            "detail": "Requires devnet deployment and testing",
        }
    )

    # Calculate scores per tier
    tier_results = {1: [], 2: [], 3: []}
    for check in checklist:
        tier = check["tier"]
        tier_results[tier].append(check["pass"])

    tier_scores = {}
    for tier, results in tier_results.items():
        if results:
            tier_scores[tier] = sum(results) / len(results)
        else:
            tier_scores[tier] = 0.0

    # Weighted score
    score = sum(tier_scores.get(t, 0.0) * w for t, w in TIER_WEIGHTS.items())

    tier1_pass = all(tier_results.get(1, []))
    tier2_pass = all(tier_results.get(2, []))
    tier3_pass = all(tier_results.get(3, []))

    return {
        "score": round(score, 3),
        "tier1_pass": tier1_pass,
        "tier2_pass": tier2_pass,
        "tier3_pass": tier3_pass,
        "tier_scores": tier_scores,
        "checklist": checklist,
    }


def persist_readiness(
    repo_name: str,
    branch_name: str,
    result: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist readiness assessment to pr_tracking table.

    Returns the row ID of the inserted record.
    """
    return persist_metric(
        db_path=db_path,
        table="pr_tracking",
        data={
            "repo_name": repo_name,
            "branch_name": branch_name,
            "readiness_score": result["score"],
            "tier1_pass": result["tier1_pass"],
            "tier2_pass": result["tier2_pass"],
            "tier3_pass": result["tier3_pass"],
            "checklist": json.dumps(result["checklist"]),
            "status": "ready" if result["tier1_pass"] else "blocked",
        },
    )


def get_readiness_report(*, db_path: str = DEFAULT_DB) -> list[dict]:
    """Get the latest readiness status for all tracked PRs."""
    return query_table(
        db_path=db_path,
        table="pr_tracking",
        order_by="timestamp DESC",
        limit=0,
    )


_KNOWN_REPOS = (
    ("go-zenon", "core/go-zenon", "go"),
    ("zenon-network/go-zenon", "zenon-network/go-zenon", "go"),
    ("hypercore-one/go-zenon", "hypercore-one/go-zenon", "go"),
    ("syrius", "core/syrius", "dart"),
    ("znn_sdk_dart", "core/znn_sdk_dart", "dart"),
    ("znn_cli_dart", "core/znn_cli_dart", "dart"),
    ("nomctl", "core/nomctl", "go"),
)


def run_pr_readiness(db_path: str = DEFAULT_DB) -> dict:
    """Zero-arg wrapper used by the autonomous scheduler.

    Iterates every well-known Zenon repo in the workspace and calls
    :func:`assess_readiness`. Repositories that are not checked out
    locally are skipped so portable installs without the full workspace
    still run cleanly.
    """
    from core.workspace import workspace_root

    root = workspace_root()
    if root is None:
        return {
            "success": False,
            "error": "ZENON_WORKSPACE_ROOT not configured",
            "assessed": 0,
        }
    assessed = 0
    reports: list[dict] = []
    for repo_name, relative, language in _KNOWN_REPOS:
        repo_path = root / relative
        if not repo_path.is_dir():
            continue
        try:
            result = assess_readiness(repo_path, language=language)
            persist_readiness(
                repo_name=repo_name,
                branch_name=result.get("branch", "main"),
                result=result,
                db_path=db_path,
            )
            assessed += 1
            reports.append(
                {
                    "repo": repo_name,
                    "score": result.get("score", 0.0),
                    "tier1_pass": result.get("tier1_pass", False),
                }
            )
        except Exception as exc:
            logger.debug("pr_readiness skipped %s: %s", repo_name, exc)
    return {
        "success": True,
        "assessed": assessed,
        "reports": reports,
    }
