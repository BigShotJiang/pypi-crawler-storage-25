# SPDX-License-Identifier: MIT
"""
ContributionDomain -- DomainPlugin for PR readiness and upstream contribution.

Provides engines for PR readiness assessment (upstream-readiness checklist),
PR description generation, and TminusZ contribution tracking (test vectors,
implementation notes, errata).
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class ContributionDomain(DomainPlugin):
    """Contribution domain plugin -- PR readiness and upstream contribution."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "contribution"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "PR readiness assessment, PR description generation, "
            "and TminusZ upstream contribution tracking."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 4

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="pr_readiness",
                description=(
                    "Automates upstream-readiness checklist: Tier 1 "
                    "(compile, CI, tests, OPSEC, spec compliance, ABI), "
                    "Tier 2 (error paths, style, no dead code), "
                    "Tier 3 (hostile review, devnet, edge cases, docs)."
                ),
                module_path="domains.contribution.engines.pr_readiness",
                priority=1,
                tier=2,
                required_apis=["filesystem", "shell"],
                max_runtime_seconds=300,
            ),
            EngineDefinition(
                name="pr_description_gen",
                description=(
                    "Generates PR descriptions from commit history, "
                    "spec references, changes, testing evidence, "
                    "and cross-repo dependencies."
                ),
                module_path="domains.contribution.engines.pr_description_gen",
                priority=2,
                tier=2,
                required_apis=["git"],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="tminusz_contributor",
                description=(
                    "Contributes back to TminusZ repo: extracts test "
                    "vectors from Go tests, formats test_vectors.json, "
                    "tracks contributed specs, generates implementation "
                    "notes and errata."
                ),
                module_path="domains.contribution.engines.tminusz_contributor",
                priority=3,
                tier=2,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="auto_contributor",
                description=(
                    "Generates contribution recommendations from "
                    "high-confidence evidence (mismatches, vulnerabilities, "
                    "coverage gaps, bugs). No LLM -- reads existing "
                    "evidence to produce actionable fix plans."
                ),
                module_path="domains.contribution.engines.auto_contributor",
                priority=4,
                tier=1,
                required_apis=[],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="workspace_recommender",
                description=(
                    "Phase F of the v0.4.0 content-based trust "
                    "architecture. Scans recent peer findings for "
                    "source_repos not currently in the local workspace "
                    "and emits workspace_recommendation findings when "
                    "the recommending peer's dynamic trust is at least "
                    "attested tier. Never auto-clones — the operator "
                    "always decides. Masks the recommending peer's "
                    "identity behind the tier label so recommendations "
                    "can't be used to build profiles of specific peers."
                ),
                module_path="domains.contribution.engines.workspace_recommender",
                priority=5,
                tier=2,
                required_apis=["filesystem"],
                max_runtime_seconds=30,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="pr_ready",
                label="PR is upstream-ready",
                description=(
                    "A PR has passed all readiness tiers and is ready for upstream submission."
                ),
                initial_confidence=0.0,
                publishable_threshold=0.90,
            ),
            HypothesisType(
                type_id="pr_blocked",
                label="PR blocked by readiness gap",
                description=(
                    "A PR fails one or more Tier 1 readiness checks "
                    "and cannot be submitted upstream."
                ),
                initial_confidence=0.5,
                publishable_threshold=0.80,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="upstream_contribution",
                label="Upstream contribution rate",
                description=(
                    "Maximize the rate of PRs successfully submitted and merged upstream."
                ),
                priority=4,
            ),
            AspirationType(
                type_id="tminusz_coverage",
                label="TminusZ contribution coverage",
                description=(
                    "All implemented specs have test vectors and "
                    "implementation notes contributed back to TminusZ."
                ),
                priority=5,
                deadline_days=60,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="pr_quality_gate",
                label="PR quality gate",
                description=(
                    "A PR readiness assessment reveals quality issues "
                    "that the quality domain should investigate."
                ),
                source_domains=["contribution", "quality"],
                convergence_threshold=0.7,
            ),
            CollisionSignal(
                signal_id="pr_security_gate",
                label="PR security gate",
                description=(
                    "A PR readiness assessment reveals security issues "
                    "that the security domain should investigate."
                ),
                source_domains=["contribution", "security"],
                convergence_threshold=0.5,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="contribution",
                section_title="Contribution Pipeline",
                metrics=[
                    "prs_in_progress",
                    "prs_ready",
                    "prs_blocked",
                    "avg_readiness_score",
                    "specs_contributed_back",
                ],
                recommendations_prompt=(
                    "Based on current PR readiness status, which PRs "
                    "are closest to submission and what gaps remain?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "avg_readiness_score": 0.0,
            "prs_submitted": 0.0,
            "prs_merged": 0.0,
            "specs_contributed": 0.0,
        }

    def decide_next_action(self, context: dict, exclude: set[str] | None = None) -> dict | None:
        """Rotate through all contribution engines (v0.4.3)."""
        exclude = exclude or set()
        trigger = context.get("trigger_level", "routine")

        candidates: list[dict] = []

        if trigger in ("urgent", "critical"):
            candidates.append(
                {
                    "action": "check_pr_readiness",
                    "reason": "Urgent trigger -- verify PR readiness status.",
                    "priority": 4,
                    "engine": "pr_readiness",
                }
            )

        candidates.extend(
            [
                {
                    "action": "generate_pr_descriptions",
                    "reason": "Routine PR description generation.",
                    "priority": 7,
                    "engine": "pr_description_gen",
                },
                {
                    "action": "refresh_readiness",
                    "reason": "Routine PR readiness refresh.",
                    "priority": 5,
                    "engine": "pr_readiness",
                },
                {
                    "action": "check_contributions",
                    "reason": "Routine TminusZ contribution tracking.",
                    "priority": 6,
                    "engine": "tminusz_contributor",
                },
                {
                    "action": "auto_contribute",
                    "reason": "Routine auto-contribution generation.",
                    "priority": 6,
                    "engine": "auto_contributor",
                },
                {
                    "action": "recommend_workspace_additions",
                    "reason": "Routine workspace recommendations from peer signal.",
                    "priority": 5,
                    "engine": "workspace_recommender",
                },
            ]
        )

        for candidate in candidates:
            key = f"contribution:{candidate['action']}"
            if key not in exclude:
                return candidate
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS pr_tracking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    repo_name TEXT NOT NULL,
    branch_name TEXT,
    pr_number INTEGER,
    readiness_score REAL DEFAULT 0.0,
    tier1_pass BOOLEAN DEFAULT FALSE,
    tier2_pass BOOLEAN DEFAULT FALSE,
    tier3_pass BOOLEAN DEFAULT FALSE,
    checklist TEXT,
    status TEXT DEFAULT 'in_progress',
    submitted_at DATETIME,
    merged_at DATETIME
);

CREATE INDEX IF NOT EXISTS idx_pr_tracking_repo
    ON pr_tracking(repo_name);
CREATE INDEX IF NOT EXISTS idx_pr_tracking_status
    ON pr_tracking(status);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Contribution domain registered with %d engines.",
            len(self.get_engines()),
        )
