# SPDX-License-Identifier: MIT
"""
DependencyChain -- Manages spec build order and identifies blocked specs.

Knows the canonical build dependency order:
    go-zenon -> SDK -> CLI -> wallet -> docs

Parses cross-references between specs and identifies specs that are
blocked because a dependency is not yet implemented.
"""

import logging
from collections import defaultdict, deque
from pathlib import Path

from core.persist_to_db import query_table

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# The canonical implementation pipeline: each layer depends on the previous.
# A spec must be implemented in go-zenon before the SDK can wrap it,
# the SDK must exist before the CLI can use it, etc.
IMPLEMENTATION_PIPELINE = [
    "go_zenon",  # Protocol layer (definition + implementation)
    "sdk_dart",  # SDK bindings (model + API)
    "cli_dart",  # Dart CLI commands
    "cli_go",  # Go CLI commands (nomctl)
    "syrius",  # Wallet UI widgets
    "docs",  # Wiki documentation
    "infra",  # Explorer / ZenonHub integration
]

# Status column name -> pipeline stage mapping
STATUS_COLUMNS = {
    "go_zenon_status": "go_zenon",
    "sdk_dart_status": "sdk_dart",
    "cli_dart_status": "cli_dart",
    "cli_go_status": "cli_go",
    "syrius_status": "syrius",
    "docs_status": "docs",
    "infra_status": "infra",
}


def get_pipeline_blockers(spec_row: dict) -> list[dict]:
    """Identify pipeline blockers for a spec.

    If go-zenon has no implementation, then SDK/CLI/wallet/docs are all
    blocked. If SDK exists but CLI does not, CLI is the blocker for
    downstream.

    Returns list of blocker dicts with keys: stage, blocked_by, reason.
    """
    blockers = []
    prev_stage = None
    prev_status = None

    for col, stage in STATUS_COLUMNS.items():
        status = spec_row.get(col, "not_started")

        if prev_stage and prev_status in ("not_started",) and status == "not_started":
            blockers.append(
                {
                    "stage": stage,
                    "blocked_by": prev_stage,
                    "reason": (
                        f"{stage} cannot proceed because {prev_stage} is not yet implemented."
                    ),
                }
            )
        elif prev_stage and prev_status in ("not_started",) and status != "not_started":
            # This stage exists but its dependency doesn't -- out of order
            blockers.append(
                {
                    "stage": stage,
                    "blocked_by": prev_stage,
                    "reason": (
                        f"{stage} exists but {prev_stage} does not -- pipeline is out of order."
                    ),
                }
            )

        prev_stage = stage
        prev_status = status

    return blockers


def build_spec_dependency_graph(specs: list[dict]) -> dict[str, list[str]]:
    """Build a dependency graph from spec cross-references.

    Args:
        specs: List of spec dicts from spec_tracker.scan_all_specs(),
               each with a 'dependencies' key.

    Returns:
        Dict mapping spec_name -> list of spec names it depends on.
    """
    graph: dict[str, list[str]] = {}
    known_specs = {s.get("normalized_name", s.get("name", "")) for s in specs}

    for spec in specs:
        name = spec.get("normalized_name", spec.get("name", ""))
        deps = spec.get("dependencies", [])
        # Only include deps that are themselves known specs
        valid_deps = [d for d in deps if d in known_specs and d != name]
        graph[name] = valid_deps

    return graph


def topological_sort(graph: dict[str, list[str]]) -> list[str]:
    """Topological sort of the spec dependency graph.

    Returns specs in build order (dependencies first).
    Handles cycles gracefully by breaking them.
    """
    in_degree: dict[str, int] = defaultdict(int)
    for node in graph:
        if node not in in_degree:
            in_degree[node] = 0
        for dep in graph[node]:
            in_degree[dep]  # Ensure dep exists
            in_degree[node] += 0  # Don't count here

    # Actually compute in-degrees (reverse direction for build order)
    # We want: if A depends on B, then B should come first
    reverse_graph: dict[str, list[str]] = defaultdict(list)
    for node, deps in graph.items():
        for dep in deps:
            reverse_graph[dep].append(node)
            in_degree[node] += 1

    # Kahn's algorithm
    queue = deque(n for n in in_degree if in_degree[n] == 0)
    result = []

    while queue:
        node = queue.popleft()
        result.append(node)
        for dependent in reverse_graph.get(node, []):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)

    # Add any remaining nodes (cycles)
    remaining = [n for n in graph if n not in result]
    result.extend(sorted(remaining))

    return result


def identify_blocked_specs(
    specs: list[dict], coverage_data: list[dict] | None = None, db_path: str = DEFAULT_DB
) -> list[dict]:
    """Identify specs that are blocked due to unmet dependencies.

    Checks both:
    1. Cross-spec dependencies (spec A depends on spec B)
    2. Pipeline dependencies (SDK needs go-zenon first)

    Returns list of blocked spec dicts with blockers and reasons.
    """
    # Load coverage data if not provided
    if coverage_data is None:
        coverage_data = query_table(
            db_path=db_path,
            table="spec_coverage",
            limit=0,
        )

    coverage_by_name = {r["spec_name"]: r for r in coverage_data}

    # Build dependency graph
    dep_graph = build_spec_dependency_graph(specs)
    build_order = topological_sort(dep_graph)

    blocked = []
    for spec in specs:
        name = spec.get("normalized_name", spec.get("name", ""))
        issues = []

        # Check cross-spec dependencies
        for dep_name in dep_graph.get(name, []):
            dep_coverage = coverage_by_name.get(dep_name, {})
            dep_go = dep_coverage.get("go_zenon_status", "not_started")
            if dep_go == "not_started":
                issues.append(
                    {
                        "type": "spec_dependency",
                        "blocked_by": dep_name,
                        "reason": (
                            f"Depends on spec '{dep_name}' which has no go-zenon implementation."
                        ),
                    }
                )

        # Check pipeline blockers
        spec_coverage = coverage_by_name.get(name, {})
        if spec_coverage:
            pipeline_blockers = get_pipeline_blockers(spec_coverage)
            for blocker in pipeline_blockers:
                issues.append(
                    {
                        "type": "pipeline_dependency",
                        **blocker,
                    }
                )

        if issues:
            blocked.append(
                {
                    "spec_name": name,
                    "build_order_position": (
                        build_order.index(name) if name in build_order else -1
                    ),
                    "blockers": issues,
                }
            )

    blocked.sort(key=lambda b: b.get("build_order_position", 999))
    logger.info(
        "DependencyChain: %d of %d specs have blockers",
        len(blocked),
        len(specs),
    )
    return blocked


def get_build_plan(specs: list[dict], db_path: str = DEFAULT_DB) -> list[dict]:
    """Generate a prioritized build plan based on dependencies and coverage.

    Returns ordered list of specs with recommended next actions.
    """
    dep_graph = build_spec_dependency_graph(specs)
    build_order = topological_sort(dep_graph)

    rows = query_table(
        db_path=db_path,
        table="spec_coverage",
        limit=0,
    )
    coverage_by_name = {r["spec_name"]: r for r in rows}

    plan = []
    for spec_name in build_order:
        coverage = coverage_by_name.get(spec_name, {})
        overall = coverage.get("overall_coverage", 0.0)

        # Determine next action
        next_action = "start_go_zenon"  # Default: start at the beginning
        for col, stage in STATUS_COLUMNS.items():
            status = coverage.get(col, "not_started")
            if status == "not_started":
                next_action = f"implement_{stage}"
                break
        else:
            next_action = "complete" if overall >= 1.0 else "review"

        plan.append(
            {
                "spec_name": spec_name,
                "overall_coverage": overall,
                "dependencies": dep_graph.get(spec_name, []),
                "next_action": next_action,
            }
        )

    return plan
