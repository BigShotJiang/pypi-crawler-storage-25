# SPDX-License-Identifier: MIT
"""
SpecDrift -- Detect when implementations drift from TminusZ specs.

Compares ABI method signatures, parameter orders, and constants between
spec markdown files and go-zenon implementation files.  Produces findings
for every discrepancy so SDK authors know which source to trust.

No LLM required -- pure text comparison.
"""

import logging
import re
from pathlib import Path

from core.persist_to_db import ensure_schema, persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

SPECS_DIR = ZENON_WORKSPACE / "knowledge" / "developer-commons" / "docs" / "specs"

# Directories where go-zenon definition files live (checked in priority order)
GO_DEFINITION_DIRS = [
    ZENON_WORKSPACE / "core" / "go-zenon" / "vm" / "embedded" / "definition",
    ZENON_WORKSPACE / "zenon-network" / "go-zenon" / "vm" / "embedded" / "definition",
    ZENON_WORKSPACE / "hypercore-one" / "go-zenon" / "vm" / "embedded" / "definition",
]

GO_IMPL_DIRS = [
    ZENON_WORKSPACE / "core" / "go-zenon" / "vm" / "embedded" / "implementation",
    ZENON_WORKSPACE / "zenon-network" / "go-zenon" / "vm" / "embedded" / "implementation",
    ZENON_WORKSPACE / "hypercore-one" / "go-zenon" / "vm" / "embedded" / "implementation",
]

# ---------- regex patterns ----------

# Matches method signatures in spec code blocks, e.g.:
#   func (m *Method) Create(param1 Type1, param2 Type2)
#   CreatePtlc(hashLocked Address, pointLocked Address, ...)
SPEC_METHOD_SIG_PATTERN = re.compile(
    r"(?:func\s+\([^)]*\)\s+)?(\w+)\s*\(([^)]*)\)",
    re.MULTILINE,
)

# Matches ABI table rows:  | MethodName | description | ...
SPEC_ABI_TABLE_PATTERN = re.compile(
    r"^\|[^|]*\|\s*`?(\w+)`?\s*\|",
    re.MULTILINE,
)

# Matches method names from go-zenon ABI JSON embedded in definition files:
#   {"type": "function", "name": "Create", "inputs": [...]}
GO_ABI_NAME_PATTERN = re.compile(
    r'"name"\s*:\s*"(\w+)"',
    re.MULTILINE,
)

# Matches Go ABI input parameter names in JSON:
#   {"name": "hashLocked", "type": "address"}
GO_ABI_INPUT_PATTERN = re.compile(
    r'\{"name"\s*:\s*"(\w+)"\s*,\s*"type"\s*:\s*"(\w+)"',
    re.MULTILINE,
)

# Matches Go const definitions:
#   const FooName = "Bar"
#   const FooAmount = 100
GO_CONST_PATTERN = re.compile(
    r"const\s+(\w+)\s*=\s*(.+)",
    re.MULTILINE,
)

# Matches constant-like definitions in spec code blocks:
#   const MinLockDuration = 3600
SPEC_CONST_PATTERN = re.compile(
    r"(?:const|var|#define)?\s*(\w+)\s*[:=]\s*(\d[\d_]*(?:\.\d+)?)",
    re.MULTILINE,
)

# Spec name -> go-zenon file stem mapping
_IMPL_NAME_MAP = {
    "atomic_swap": "atomic_swap",
    "bitcoin_spv": "bitcoin_spv",
    "governance": "governance",
    "multi_sig": "multisig",
    "multisig": "multisig",
    "ptlc": "ptlc",
    "streaming": "streaming",
    "zns": "zns",
    "zenon_portal": "portal",
    "portal": "portal",
    "galv": "galv",
    "commit_channels": "commit_channels",
    "commitments": "commitments",
    "did": "did",
    "sentinel_validator": "sentinel_validator",
}


def _normalize_spec_name(raw_name: str) -> str:
    """Convert a spec directory name to snake_case."""
    name = raw_name.replace("-", "_").replace(" ", "_")
    name = re.sub(r"(?<=[a-z])(?=[A-Z])", "_", name)
    return name.lower()


def _spec_to_impl_name(spec_name: str) -> str:
    """Map normalized spec name to go-zenon file stem."""
    return _IMPL_NAME_MAP.get(spec_name, spec_name)


def _read_file(filepath: Path, max_bytes: int = 500_000) -> str:
    """Read a text file, returning empty string on failure."""
    try:
        text = filepath.read_text(encoding="utf-8", errors="replace")
        return text[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def _find_go_file(impl_name: str, dirs: list[Path]) -> Path | None:
    """Return the first matching .go file across search directories."""
    for d in dirs:
        candidate = d / f"{impl_name}.go"
        if candidate.exists():
            return candidate
    return None


# ---------- extraction ----------


def _extract_spec_code_blocks(text: str) -> list[str]:
    """Extract fenced code blocks from markdown text."""
    blocks: list[str] = []
    in_block = False
    current: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("```"):
            if in_block:
                blocks.append("\n".join(current))
                current = []
                in_block = False
            else:
                in_block = True
        elif in_block:
            current.append(line)
    return blocks


def extract_spec_methods(spec_dir: Path) -> dict[str, list[str]]:
    """Extract method names and their parameter names from spec files.

    Returns {method_name: [param1, param2, ...]} where param names are
    extracted from function signatures in code blocks.
    """
    methods: dict[str, list[str]] = {}

    for md_file in spec_dir.rglob("*.md"):
        text = _read_file(md_file)
        code_blocks = _extract_spec_code_blocks(text)

        for block in code_blocks:
            for match in SPEC_METHOD_SIG_PATTERN.finditer(block):
                name = match.group(1)
                params_str = match.group(2).strip()
                # Skip common false positives
                if name.lower() in (
                    "if",
                    "for",
                    "return",
                    "func",
                    "switch",
                    "case",
                    "range",
                    "make",
                    "append",
                    "len",
                    "cap",
                    "new",
                    "delete",
                    "copy",
                    "close",
                    "panic",
                    "recover",
                    "print",
                    "println",
                    "error",
                ):
                    continue
                params = _parse_param_names(params_str)
                # Prefer the version with more parameters (richer signature)
                if name not in methods or len(params) > len(methods[name]):
                    methods[name] = params

        # Also capture method names from ABI tables
        for match in SPEC_ABI_TABLE_PATTERN.finditer(text):
            name = match.group(1).strip()
            if name and name not in ("Method", "Name", "---", "Function"):
                if name not in methods:
                    methods[name] = []

    return methods


def _parse_param_names(params_str: str) -> list[str]:
    """Parse parameter names from a Go-style signature string.

    Handles both 'name Type' and 'name1, name2 Type' forms.
    """
    if not params_str.strip():
        return []

    names: list[str] = []
    for part in params_str.split(","):
        part = part.strip()
        if not part:
            continue
        tokens = part.split()
        if tokens:
            # In Go, the name comes first: 'hashLocked common.Address'
            candidate = tokens[0]
            # Skip if it looks like a type (starts with uppercase or is a
            # known Go type keyword)
            if (
                candidate
                and candidate[0].islower()
                and candidate
                not in (
                    "uint8",
                    "uint16",
                    "uint32",
                    "uint64",
                    "int8",
                    "int16",
                    "int32",
                    "int64",
                    "bool",
                    "string",
                    "byte",
                    "error",
                )
            ):
                names.append(candidate)
    return names


def extract_go_methods(impl_name: str) -> dict[str, list[str]]:
    """Extract ABI method names and parameter names from go-zenon definition.

    Returns {method_name: [param1, param2, ...]} from the ABI JSON.
    """
    go_file = _find_go_file(impl_name, GO_DEFINITION_DIRS)
    if not go_file:
        return {}

    text = _read_file(go_file)
    methods: dict[str, list[str]] = {}

    # Parse ABI JSON blocks to get method names with their inputs
    # The ABI JSON is typically embedded as a Go string literal
    current_method: str | None = None
    current_params: list[str] = []

    # Strategy: find "name":"MethodName" entries and the "inputs" that follow
    # We process the file line by line for robustness
    lines = text.splitlines()
    for i, line in enumerate(lines):
        name_match = re.search(r'"name"\s*:\s*"(\w+)"', line)
        if name_match:
            # Save previous method if any
            if current_method:
                methods[current_method] = current_params

            name = name_match.group(1)
            # Check if this is a function (not an event or constructor)
            # Look nearby for "type":"function"
            context = "\n".join(lines[max(0, i - 3) : i + 3])
            if '"type"' in context:
                type_match = re.search(r'"type"\s*:\s*"(\w+)"', context)
                if type_match and type_match.group(1) not in ("function",):
                    current_method = None
                    current_params = []
                    continue

            current_method = name
            current_params = []

            # Scan forward for inputs in the same ABI entry
            for j in range(i, min(i + 30, len(lines))):
                for param_match in GO_ABI_INPUT_PATTERN.finditer(lines[j]):
                    param_name = param_match.group(1)
                    if param_name not in ("type",):
                        current_params.append(param_name)

    # Save last method
    if current_method:
        methods[current_method] = current_params

    return methods


def extract_spec_constants(spec_dir: Path) -> dict[str, str]:
    """Extract numeric constants from spec code blocks.

    Returns {constant_name: value_string}.
    """
    constants: dict[str, str] = {}
    for md_file in spec_dir.rglob("*.md"):
        text = _read_file(md_file)
        for block in _extract_spec_code_blocks(text):
            for match in SPEC_CONST_PATTERN.finditer(block):
                name = match.group(1)
                value = match.group(2).replace("_", "")
                if name and name[0].isupper():
                    constants[name] = value
    return constants


def extract_go_constants(impl_name: str) -> dict[str, str]:
    """Extract constants from go-zenon definition and implementation files.

    Returns {constant_name: value_string}.
    """
    constants: dict[str, str] = {}

    for dirs in (GO_DEFINITION_DIRS, GO_IMPL_DIRS):
        go_file = _find_go_file(impl_name, dirs)
        if not go_file:
            continue
        text = _read_file(go_file)
        for match in GO_CONST_PATTERN.finditer(text):
            name = match.group(1)
            value = match.group(2).strip().strip('"').strip("'")
            constants[name] = value

    return constants


# ---------- drift detection ----------


def detect_drift_for_spec(spec_dir: Path) -> list[dict]:
    """Compare a single spec against its go-zenon implementation.

    Returns a list of drift finding dicts, each with:
        type, spec_name, detail, spec_value, go_value, severity
    """
    raw_name = spec_dir.name
    spec_name = _normalize_spec_name(raw_name)
    impl_name = _spec_to_impl_name(spec_name)
    drifts: list[dict] = []

    spec_methods = extract_spec_methods(spec_dir)
    go_methods = extract_go_methods(impl_name)

    if not spec_methods and not go_methods:
        # No methods on either side -- likely a non-contract spec
        return drifts

    spec_names = set(spec_methods.keys())
    go_names = set(go_methods.keys())

    # Methods in spec but missing from Go
    for method in sorted(spec_names - go_names):
        drifts.append(
            {
                "type": "method_missing_in_go",
                "spec_name": spec_name,
                "detail": f"Method '{method}' defined in spec but absent from go-zenon definition.",
                "spec_value": method,
                "go_value": None,
                "severity": "high",
            }
        )

    # Methods in Go but missing from spec
    for method in sorted(go_names - spec_names):
        drifts.append(
            {
                "type": "method_missing_in_spec",
                "spec_name": spec_name,
                "detail": f"Method '{method}' exists in go-zenon but is not documented in the spec.",
                "spec_value": None,
                "go_value": method,
                "severity": "medium",
            }
        )

    # For methods present in both, compare parameter order
    for method in sorted(spec_names & go_names):
        spec_params = spec_methods[method]
        go_params = go_methods[method]

        if not spec_params or not go_params:
            # Cannot compare if either side has no param info
            continue

        # Check parameter count mismatch
        if len(spec_params) != len(go_params):
            drifts.append(
                {
                    "type": "param_count_mismatch",
                    "spec_name": spec_name,
                    "detail": (
                        f"Method '{method}' has {len(spec_params)} params in spec "
                        f"({', '.join(spec_params)}) but {len(go_params)} in go-zenon "
                        f"({', '.join(go_params)})."
                    ),
                    "spec_value": spec_params,
                    "go_value": go_params,
                    "severity": "high",
                }
            )
            continue

        # Check parameter name mismatches (same count, different names)
        for idx, (sp, gp) in enumerate(zip(spec_params, go_params, strict=False)):
            if sp.lower() != gp.lower():
                # Check if it might be a reorder (same names, different position)
                if sp.lower() in [p.lower() for p in go_params]:
                    drifts.append(
                        {
                            "type": "param_order_swapped",
                            "spec_name": spec_name,
                            "detail": (
                                f"Method '{method}' param at position {idx}: "
                                f"spec has '{sp}', go-zenon has '{gp}' -- "
                                f"parameter order may be swapped."
                            ),
                            "spec_value": spec_params,
                            "go_value": go_params,
                            "severity": "critical",
                        }
                    )
                    break  # One swap finding per method is enough
                else:
                    drifts.append(
                        {
                            "type": "param_name_mismatch",
                            "spec_name": spec_name,
                            "detail": (
                                f"Method '{method}' param at position {idx}: "
                                f"spec calls it '{sp}', go-zenon calls it '{gp}'."
                            ),
                            "spec_value": sp,
                            "go_value": gp,
                            "severity": "medium",
                        }
                    )

    # Compare constants
    spec_consts = extract_spec_constants(spec_dir)
    go_consts = extract_go_constants(impl_name)

    for const_name, spec_val in spec_consts.items():
        if const_name in go_consts:
            go_val = go_consts[const_name]
            # Normalize for comparison (strip quotes, underscores)
            sv = spec_val.replace("_", "").strip('"')
            gv = go_val.replace("_", "").strip('"')
            if sv != gv:
                drifts.append(
                    {
                        "type": "constant_mismatch",
                        "spec_name": spec_name,
                        "detail": (
                            f"Constant '{const_name}': spec defines '{spec_val}', "
                            f"go-zenon defines '{go_val}'."
                        ),
                        "spec_value": spec_val,
                        "go_value": go_val,
                        "severity": "high",
                    }
                )

    return drifts


def detect_all_drift(
    specs_dir: Path = SPECS_DIR,
) -> list[dict]:
    """Scan all specs and detect drift against go-zenon implementations.

    Returns a flat list of drift findings across all specs.
    """
    if not specs_dir.is_dir():
        logger.warning("Specs directory not found: %s", specs_dir)
        return []

    all_drifts: list[dict] = []
    for entry in sorted(specs_dir.iterdir()):
        if entry.is_dir() and not entry.name.startswith("."):
            drifts = detect_drift_for_spec(entry)
            all_drifts.extend(drifts)

    logger.info(
        "SpecDrift: scanned %d spec directories, found %d drift items",
        sum(1 for e in specs_dir.iterdir() if e.is_dir() and not e.name.startswith(".")),
        len(all_drifts),
    )
    return all_drifts


def persist_drift_findings(
    drifts: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist drift findings to the unified evidence table.

    Returns the number of findings persisted.
    """
    ensure_schema(db_path)
    count = 0

    for drift in drifts:
        spec_name = drift["spec_name"]
        impl_name = _spec_to_impl_name(spec_name)
        severity = drift["severity"]
        drift_type = drift["type"]
        detail = drift["detail"]

        # Build the WHAT / SO WHAT / NOW WHAT finding
        if drift_type == "param_order_swapped":
            so_what = (
                "SDK implementations following the spec will produce wrong "
                "ABI encoding. Transactions will be rejected or misinterpreted."
            )
            now_what = (
                "Verify which is authoritative (spec or code) and align the other. "
                "Then update all SDKs to match the authoritative source."
            )
        elif drift_type == "method_missing_in_go":
            so_what = (
                "The spec defines functionality that has no implementation. "
                "SDK wrappers for this method will fail at runtime."
            )
            now_what = (
                f"Implement the missing method in go-zenon "
                f"vm/embedded/implementation/{impl_name}.go, or update the spec "
                f"to remove the method if it was dropped."
            )
        elif drift_type == "method_missing_in_spec":
            so_what = (
                "Undocumented methods create SDK coverage gaps. "
                "Contributors may not know this functionality exists."
            )
            now_what = (
                "Update the spec to document this method, or confirm it is "
                "internal-only and should not be exposed in SDKs."
            )
        elif drift_type == "param_count_mismatch":
            so_what = (
                "Different parameter counts mean the spec and implementation "
                "disagree on the contract interface. ABI encoding will fail."
            )
            now_what = (
                "Compare the spec signature with the Go ABI definition. "
                "Determine which is correct and update the other."
            )
        elif drift_type == "param_name_mismatch":
            so_what = (
                "Inconsistent parameter naming causes confusion for SDK "
                "authors and may lead to wrong field mapping."
            )
            now_what = (
                "Align parameter names between spec and go-zenon. "
                "Prefer the go-zenon name if the contract is already deployed."
            )
        elif drift_type == "constant_mismatch":
            so_what = (
                "Mismatched constants mean spec-following implementations "
                "will use wrong values, potentially causing fund loss or "
                "transaction rejection."
            )
            now_what = (
                "Determine which value is correct by checking the deployed "
                "contract behavior. Update the other source to match."
            )
        else:
            so_what = "Spec and implementation are inconsistent."
            now_what = "Investigate and align."

        confidence_map = {
            "critical": 0.95,
            "high": 0.85,
            "medium": 0.70,
        }
        confidence = confidence_map.get(severity, 0.60)

        finding_text = f"WHAT: {detail} SO WHAT: {so_what} NOW WHAT: {now_what}"

        persist_finding(
            db_path=db_path,
            domain="development",
            engine="spec_drift",
            evidence_type=f"spec_drift_{drift_type}",
            finding=finding_text,
            confidence=confidence,
            raw_data=drift,
            source_repo="knowledge/developer-commons",
            source_file=f"docs/specs/{spec_name}/",
        )
        count += 1

    logger.info("SpecDrift: persisted %d drift findings", count)
    return count


def run_spec_drift_analysis(
    *,
    specs_dir: Path = SPECS_DIR,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Run the full spec drift analysis pipeline.

    Returns a summary dict with drift counts by type and severity.
    """
    drifts = detect_all_drift(specs_dir)
    persisted = persist_drift_findings(drifts, db_path=db_path)

    # Summarize
    by_type: dict[str, int] = {}
    by_severity: dict[str, int] = {}
    by_spec: dict[str, int] = {}
    for d in drifts:
        by_type[d["type"]] = by_type.get(d["type"], 0) + 1
        by_severity[d["severity"]] = by_severity.get(d["severity"], 0) + 1
        by_spec[d["spec_name"]] = by_spec.get(d["spec_name"], 0) + 1

    return {
        "success": True,
        "total_drifts": len(drifts),
        "persisted": persisted,
        "by_type": by_type,
        "by_severity": by_severity,
        "by_spec": by_spec,
        "drifts": drifts,
    }
