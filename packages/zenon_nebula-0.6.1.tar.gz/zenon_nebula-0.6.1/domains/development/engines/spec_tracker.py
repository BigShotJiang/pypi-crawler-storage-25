# SPDX-License-Identifier: MIT
"""
SpecTracker -- Scans TminusZ / developer-commons specs.

Reads all directories in knowledge/developer-commons/docs/specs/ and
for each spec: extracts the name, lists ABI methods (from the spec doc
and from go-zenon definition files), identifies dependencies on other
specs, and persists results to the spec_coverage table.
"""

import logging
import re
from pathlib import Path

from core.persist_to_db import persist_finding
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

SPECS_DIR = ZENON_WORKSPACE / "knowledge" / "developer-commons" / "docs" / "specs"

# Cache last scan results for git-hash-gating (return cached when HEAD unchanged)
_LAST_SCAN_CACHE: dict = {}

# Patterns for extracting ABI methods from spec markdown
ABI_TABLE_PATTERN = re.compile(
    r"\|\s*`?(\w+)`?\s*\|\s*`?(\w+\([^)]*\))`?\s*\|",
    re.MULTILINE,
)
# Simpler pattern: method names from go-zenon ABI JSON in definition files
GO_ABI_METHOD_PATTERN = re.compile(
    r'"name"\s*:\s*"(\w+)"',
    re.MULTILINE,
)
# Pattern for cross-references to other specs
SPEC_REF_PATTERN = re.compile(
    r"(?:see|refer|depends? on|uses?|requires?|from)\s+(?:the\s+)?[`\"]?"
    r"([\w_-]+?)(?:\.(?:md|go))?[`\"]?\s+(?:spec|contract|module)",
    re.IGNORECASE,
)
# Direct file references
FILE_REF_PATTERN = re.compile(
    r"(?:bitcoin_spv|atomic_swap|bridge|htlc|governance|ptlc|liquidity|"
    r"multisig|streaming|zns|portal|pillar|sentinel|plasma|stake|token|"
    r"accelerator|spork|swap|galv|commit_channels|commitments|did|"
    r"sentinel_validator)(?:\.go|\.dart|\.md)?",
    re.IGNORECASE,
)


def _normalize_spec_name(raw_name: str) -> str:
    """Normalize a spec directory name to a canonical form.

    Examples:
        'AtomicSwap' -> 'atomic_swap'
        'Bitcoin-SPV' -> 'bitcoin_spv'
        'Zenon Portal' -> 'zenon_portal'  (but maps to 'portal' for impl lookup)
        'ZNS' -> 'zns'
    """
    # Replace hyphens and spaces with underscores
    name = raw_name.replace("-", "_").replace(" ", "_")
    # Insert underscores before uppercase letters (camelCase -> snake_case)
    name = re.sub(r"(?<=[a-z])(?=[A-Z])", "_", name)
    return name.lower()


def _spec_to_impl_name(spec_name: str) -> str:
    """Map a normalized spec name to expected implementation file stems.

    Some specs map to differently-named implementation files.
    """
    mappings = {
        "atomic_swap": "atomic_swap",
        "bitcoin_spv": "bitcoin_spv",
        "governance": "governance",
        "multi_sig": "multisig",
        "multisig": "multisig",
        "ptlc": "ptlc",
        "streaming": "streaming",
        "zns": "zns",
        "zenon_portal": "portal",
        "libp2p_transport": "libp2p",
        "galv": "galv",
        "interstellar_os_stack_example": "interstellar",
    }
    return mappings.get(spec_name, spec_name)


def _read_file_text(filepath: Path, max_bytes: int = 500_000) -> str:
    """Read a text file, returning empty string on failure."""
    try:
        text = filepath.read_text(encoding="utf-8", errors="replace")
        return text[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def extract_abi_methods_from_spec(spec_dir: Path) -> list[str]:
    """Extract ABI method names from markdown spec files in a directory."""
    methods: list[str] = []
    for md_file in spec_dir.rglob("*.md"):
        text = _read_file_text(md_file)
        # Look for ABI table rows
        for match in ABI_TABLE_PATTERN.finditer(text):
            method_name = match.group(1).strip()
            if method_name and method_name not in ("Method", "---"):
                methods.append(method_name)
    return sorted(set(methods))


def extract_abi_methods_from_go(impl_name: str) -> list[str]:
    """Extract ABI method names from go-zenon definition files."""
    methods: list[str] = []
    definition_dirs = [
        ZENON_WORKSPACE / "core" / "go-zenon" / "vm" / "embedded" / "definition",
        ZENON_WORKSPACE / "zenon-network" / "go-zenon" / "vm" / "embedded" / "definition",
        ZENON_WORKSPACE / "hypercore-one" / "go-zenon" / "vm" / "embedded" / "definition",
    ]
    for d in definition_dirs:
        go_file = d / f"{impl_name}.go"
        if go_file.exists():
            text = _read_file_text(go_file)
            for match in GO_ABI_METHOD_PATTERN.finditer(text):
                name = match.group(1)
                # Filter out common field names that aren't methods
                if name and not name[0].islower():
                    methods.append(name)
            if methods:
                break  # Use the first repo that has the file
    return sorted(set(methods))


def extract_dependencies(spec_dir: Path, spec_name: str) -> list[str]:
    """Extract cross-references to other specs from a spec directory."""
    deps: set[str] = set()
    own_impl = _spec_to_impl_name(spec_name)

    for md_file in spec_dir.rglob("*.md"):
        text = _read_file_text(md_file)

        # Look for explicit cross-references
        for match in SPEC_REF_PATTERN.finditer(text):
            ref = _normalize_spec_name(match.group(1))
            if ref != spec_name and ref != own_impl:
                deps.add(ref)

        # Look for file references to other contracts
        for match in FILE_REF_PATTERN.finditer(text):
            ref = match.group(0).split(".")[0].lower()
            if ref != own_impl and ref != spec_name:
                deps.add(ref)

    return sorted(deps)


def scan_spec(spec_dir: Path) -> dict | None:
    """Scan a single spec directory and extract metadata.

    Returns a dict with: name, normalized_name, impl_name, path,
    abi_methods_spec, abi_methods_go, dependencies, md_files.
    """
    raw_name = spec_dir.name
    normalized = _normalize_spec_name(raw_name)
    impl_name = _spec_to_impl_name(normalized)

    # Get markdown files
    md_files = sorted(str(f.relative_to(spec_dir)) for f in spec_dir.rglob("*.md"))
    if not md_files:
        return None

    abi_spec = extract_abi_methods_from_spec(spec_dir)
    abi_go = extract_abi_methods_from_go(impl_name)
    deps = extract_dependencies(spec_dir, normalized)

    return {
        "name": raw_name,
        "normalized_name": normalized,
        "impl_name": impl_name,
        "path": str(spec_dir),
        "abi_methods_spec": abi_spec,
        "abi_methods_go": abi_go,
        "dependencies": deps,
        "md_files": md_files,
    }


def scan_all_specs(specs_dir: Path = SPECS_DIR) -> list[dict]:
    """Scan all spec directories and return metadata for each.

    Returns list of spec dicts sorted by name.
    """
    # Skip work if the developer-commons repo HEAD hasn't moved (autonomous mode only)
    try:
        from core.git_cache import has_repo_changed

        specs_repo = specs_dir
        while specs_repo != specs_repo.parent:
            if (specs_repo / ".git").is_dir():
                break
            specs_repo = specs_repo.parent
        if (specs_repo / ".git").is_dir() and not has_repo_changed(str(specs_repo)):
            logger.debug("Skipping spec scan — developer-commons HEAD unchanged")
            return _LAST_SCAN_CACHE.get("specs", [])
    except Exception as exc:
        logger.debug("Repo change check failed: %s", exc)

    if not specs_dir.is_dir():
        logger.warning("Specs directory not found: %s", specs_dir)
        return []

    specs = []
    for entry in sorted(specs_dir.iterdir()):
        if entry.is_dir() and not entry.name.startswith("."):
            spec = scan_spec(entry)
            if spec:
                specs.append(spec)

    # Also scan top-level .md files that aren't READMEs (standalone specs)
    for md_file in sorted(specs_dir.glob("*.md")):
        if md_file.name.lower() in ("readme.md",):
            continue
        raw_name = md_file.stem
        normalized = _normalize_spec_name(raw_name)
        impl_name = _spec_to_impl_name(normalized)
        text = _read_file_text(md_file)

        abi_methods = []
        for match in ABI_TABLE_PATTERN.finditer(text):
            method_name = match.group(1).strip()
            if method_name and method_name not in ("Method", "---"):
                abi_methods.append(method_name)

        specs.append(
            {
                "name": raw_name,
                "normalized_name": normalized,
                "impl_name": impl_name,
                "path": str(md_file),
                "abi_methods_spec": sorted(set(abi_methods)),
                "abi_methods_go": extract_abi_methods_from_go(impl_name),
                "dependencies": [],
                "md_files": [md_file.name],
            }
        )

    logger.info("SpecTracker: scanned %d specs from %s", len(specs), specs_dir)
    _LAST_SCAN_CACHE["specs"] = specs
    return specs


def persist_specs(specs: list[dict], db_path: str = DEFAULT_DB) -> int:
    """Persist spec metadata to the spec_coverage table.

    Creates or updates rows. Returns the number of rows upserted.
    """
    conn = connect(db_path)
    count = 0
    try:
        for spec in specs:
            # Check if spec already exists
            existing = conn.execute(
                "SELECT id FROM spec_coverage WHERE spec_name = ?",
                (spec["normalized_name"],),
            ).fetchone()

            if existing:
                conn.execute(
                    """UPDATE spec_coverage
                    SET spec_path = ?, last_checked = CURRENT_TIMESTAMP
                    WHERE spec_name = ?""",
                    (spec["path"], spec["normalized_name"]),
                )
            else:
                conn.execute(
                    """INSERT INTO spec_coverage (spec_name, spec_path)
                    VALUES (?, ?)""",
                    (spec["normalized_name"], spec["path"]),
                )
            count += 1

        conn.commit()
    finally:
        conn.close()

    logger.info("SpecTracker: persisted %d specs to spec_coverage", count)
    return count


def persist_specs_as_evidence(specs: list[dict], db_path: str = DEFAULT_DB) -> int:
    """Persist spec findings to the unified evidence table with source provenance.

    Each spec gets a finding recording its existence, ABI method count,
    and implementation status, with source_repo and source_file tracing
    back to the spec document.

    Returns the number of findings persisted.
    """
    count = 0
    for spec in specs:
        spec_path = spec.get("path", "")
        abi_spec_count = len(spec.get("abi_methods_spec", []))
        abi_go_count = len(spec.get("abi_methods_go", []))
        deps = spec.get("dependencies", [])

        # Determine implementation gap
        spec_methods = set(spec.get("abi_methods_spec", []))
        go_methods = set(spec.get("abi_methods_go", []))
        missing_in_go = sorted(spec_methods - go_methods)
        extra_in_go = sorted(go_methods - spec_methods)

        if abi_spec_count == 0 and abi_go_count == 0:
            finding = (
                f"WHAT: Spec '{spec['name']}' has no ABI methods in spec doc or go-zenon. "
                f"SO WHAT: Either a non-contract spec or methods are undocumented. "
                f"NOW WHAT: Verify if this spec requires embedded contract methods; "
                f"if so, add ABI table to the spec doc."
            )
        elif missing_in_go:
            finding = (
                f"WHAT: Spec '{spec['name']}' defines {abi_spec_count} ABI methods "
                f"but go-zenon only implements {abi_go_count} ({', '.join(missing_in_go)} missing). "
                f"SO WHAT: Incomplete implementation means SDK/CLI cannot expose full spec functionality. "
                f"NOW WHAT: Implement missing methods in go-zenon vm/embedded/implementation/{spec.get('impl_name', spec['name'])}.go."
            )
        elif extra_in_go:
            finding = (
                f"WHAT: go-zenon has {abi_go_count} methods for '{spec['name']}' "
                f"but spec only documents {abi_spec_count} ({', '.join(extra_in_go)} undocumented). "
                f"SO WHAT: Undocumented methods create SDK/CLI coverage gaps and confuse contributors. "
                f"NOW WHAT: Update spec doc to include {', '.join(extra_in_go)}, or confirm they are internal-only."
            )
        else:
            dep_note = f" Depends on: {', '.join(deps)}." if deps else ""
            finding = (
                f"WHAT: Spec '{spec['name']}' has {abi_spec_count} ABI methods fully matched in go-zenon. "
                f"SO WHAT: Go implementation is spec-complete; ready for SDK/CLI wrapping.{dep_note} "
                f"NOW WHAT: Proceed to SDK implementation for '{spec.get('impl_name', spec['name'])}' if not already done."
            )

        persist_finding(
            db_path=db_path,
            domain="development",
            engine="spec_tracker",
            evidence_type="spec_scan",
            finding=finding,
            confidence=0.9,
            raw_data={
                "spec_name": spec.get("normalized_name", ""),
                "impl_name": spec.get("impl_name", ""),
                "abi_methods_spec": spec.get("abi_methods_spec", []),
                "abi_methods_go": spec.get("abi_methods_go", []),
                "dependencies": deps,
                "md_files": spec.get("md_files", []),
            },
            source_repo="knowledge/developer-commons",
            source_file=spec_path,
        )
        count += 1

    logger.info("SpecTracker: persisted %d spec findings to evidence", count)
    return count
