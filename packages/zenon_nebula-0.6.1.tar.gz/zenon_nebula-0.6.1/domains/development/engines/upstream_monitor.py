# SPDX-License-Identifier: MIT
"""
UpstreamMonitor -- Watches for upstream changes relevant to development.

Reads intelligence signals tagged as spec_change or breaking_change from
the feedback bus, checks whether those changes affect specs we have
tracked, and flags conflicts with our current implementation status.
"""

import json
import logging
import sqlite3
from pathlib import Path

from core.persist_to_db import query_table
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Signal types that indicate development-relevant upstream changes
RELEVANT_SIGNAL_TYPES = frozenset(
    {
        "spec_change",
        "breaking_change",
        "new_feature",
        "bug_fix",
    }
)


def _get_tracked_specs(db_path: str) -> dict[str, dict]:
    """Get all specs we are tracking from spec_coverage.

    Returns dict mapping spec_name -> coverage row dict.
    """
    rows = query_table(
        db_path=db_path,
        table="spec_coverage",
        limit=0,
    )
    return {row["spec_name"]: row for row in rows}


def _match_signal_to_specs(signal_data: dict, tracked_specs: dict[str, dict]) -> list[str]:
    """Determine which tracked specs a signal might affect.

    Matches based on:
    - Files changed that mention a spec name
    - Commit message referencing a spec
    - Repo + directory patterns
    """
    affected = []
    files = signal_data.get("files_changed", [])
    message = signal_data.get("message", "").lower()
    signal_data.get("source_repo", signal_data.get("repo", "")).lower()

    for spec_name, _spec_info in tracked_specs.items():
        name_lower = spec_name.lower()
        # Also check the hyphenated and un-underscored forms
        alt_names = [
            name_lower,
            name_lower.replace("_", "-"),
            name_lower.replace("_", ""),
        ]

        matched = False

        # Check files changed
        for filepath in files:
            fp_lower = filepath.lower()
            for alt in alt_names:
                if alt in fp_lower:
                    matched = True
                    break
            if matched:
                break

        # Check commit message
        if not matched:
            for alt in alt_names:
                if alt in message:
                    matched = True
                    break

        if matched:
            affected.append(spec_name)

    return affected


def _assess_impact(signal_data: dict, spec_name: str, spec_info: dict) -> dict:
    """Assess the impact of a signal on a specific spec.

    Returns a conflict/impact dict with severity and description.
    """
    classifications = signal_data.get("classifications", [])
    message = signal_data.get("message", "")
    repo = signal_data.get("source_repo", signal_data.get("repo", ""))

    # Determine severity
    severity = "low"
    if "breaking_change" in classifications:
        severity = "critical"
    elif "spec_change" in classifications or "security_relevant" in classifications:
        severity = "high"
    elif "bug_fix" in classifications:
        severity = "medium"

    # Check if we have implementations that could be affected
    impl_statuses = {
        "go_zenon": spec_info.get("go_zenon_status", "not_started"),
        "sdk_dart": spec_info.get("sdk_dart_status", "not_started"),
        "cli_dart": spec_info.get("cli_dart_status", "not_started"),
        "cli_go": spec_info.get("cli_go_status", "not_started"),
        "syrius": spec_info.get("syrius_status", "not_started"),
    }
    existing_impls = [k for k, v in impl_statuses.items() if v in ("exists", "partial")]

    description = f"Upstream {'/'.join(classifications)} in {repo} affects spec '{spec_name}'. "
    if existing_impls:
        description += f"Existing implementations in {', '.join(existing_impls)} may need updating."
    else:
        description += "No existing implementations affected."
        severity = "info" if severity != "critical" else severity

    return {
        "spec_name": spec_name,
        "severity": severity,
        "classifications": classifications,
        "source_repo": repo,
        "commit_hash": signal_data.get("commit_hash", ""),
        "message": message,
        "affected_implementations": existing_impls,
        "description": description,
    }


def read_intelligence_signals(db_path: str = DEFAULT_DB, limit: int = 100) -> list[dict]:
    """Read recent intelligence signals that are relevant to development.

    Reads from the feedback_bus messages addressed to domain.development.
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT * FROM feedback_bus
            WHERE acknowledged = 0
            AND (recipient = 'domain.development' OR recipient = 'all')
            AND type = 'signal'
            ORDER BY timestamp ASC
            LIMIT ?""",
            (limit,),
        ).fetchall()
        signals = []
        for row in rows:
            d = dict(row)
            try:
                d["data"] = json.loads(d.get("data", "{}"))
            except (json.JSONDecodeError, TypeError):
                d["data"] = {}
            signals.append(d)
        return signals
    except sqlite3.OperationalError:
        # feedback_bus table may not exist yet
        return []
    finally:
        conn.close()


def process_upstream_changes(db_path: str = DEFAULT_DB) -> list[dict]:
    """Process upstream intelligence signals and identify spec conflicts.

    Returns list of impact assessment dicts.
    """
    tracked_specs = _get_tracked_specs(db_path)
    if not tracked_specs:
        logger.info("UpstreamMonitor: no tracked specs, skipping.")
        return []

    signals = read_intelligence_signals(db_path)
    if not signals:
        logger.info("UpstreamMonitor: no pending signals for development.")
        return []

    impacts = []
    for signal in signals:
        data = signal.get("data", {})
        affected_specs = _match_signal_to_specs(data, tracked_specs)

        for spec_name in affected_specs:
            impact = _assess_impact(data, spec_name, tracked_specs[spec_name])
            impacts.append(impact)

        # Acknowledge the signal
        msg_id = signal.get("id")
        if msg_id:
            conn = connect(db_path)
            try:
                conn.execute(
                    """UPDATE feedback_bus
                    SET acknowledged = 1, acknowledged_by = 'development.upstream_monitor'
                    WHERE id = ?""",
                    (msg_id,),
                )
                conn.commit()
            finally:
                conn.close()

    # Sort by severity
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    impacts.sort(key=lambda i: severity_order.get(i.get("severity", "info"), 5))

    logger.info(
        "UpstreamMonitor: processed %d signals, found %d impacts",
        len(signals),
        len(impacts),
    )
    return impacts
