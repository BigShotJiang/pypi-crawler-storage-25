# SPDX-License-Identifier: MIT
"""
BtcSpecTracker -- map Bitcoin BIPs to Zenon ZIP counterparts.

Activates only when a Bitcoin-like reference chain is present in the
workspace and a ``bips/`` directory (or ``doc/bips.md``) can be located
inside it. For each discovered BIP the engine checks whether an
equivalent ZIP exists in ``knowledge/developer-commons`` (or any other
repo classified as ``specs``) and raises a finding for every BIP that
has no ZIP counterpart — a prioritization signal for TminusZ.

The engine degrades gracefully in three ways:

- If no Bitcoin-family reference repo is in the workspace catalog,
  returns ``{}``.
- If no BIP directory can be located inside the reference repo,
  returns ``{}``.
- If the Zenon knowledge repo is missing, every BIP is flagged with
  a lower confidence and the finding notes the gap.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

from core.persist_to_db import persist_finding
from core.persistence.metrics import query_table
from core.persistence.schema import DEFAULT_DB
from core.workspace import workspace_repo, workspace_root

logger = logging.getLogger(__name__)


_BIP_NUMBER_RE = re.compile(r"bip[-_]?(\d{1,4})", re.IGNORECASE)
_ZIP_NUMBER_RE = re.compile(r"zip[-_]?(\d{1,4})", re.IGNORECASE)

_BTC_REFERENCE_TYPES = {"blockchain_node_btc"}

_MAX_BIPS_SCANNED = 200
_MAX_FINDINGS = 40


def _find_btc_reference(db_path: str) -> Path | None:
    """Return the filesystem path of the first BTC reference repo, if any."""
    rows = query_table(
        db_path=db_path,
        table="workspace_repos",
        limit=0,
    )
    for row in rows:
        if row.get("repo_type") in _BTC_REFERENCE_TYPES:
            repo_path = Path(row.get("repo_path", ""))
            if repo_path.is_dir():
                return repo_path
    return None


def _find_bips_directory(reference_root: Path) -> Path | None:
    """Return the BIP-containing directory inside a BTC reference repo."""
    candidates = [
        reference_root / "bips",
        reference_root / "doc" / "bips",
        reference_root.parent / "bips",
    ]
    for candidate in candidates:
        if candidate.is_dir():
            return candidate
    # As a last resort, scan for any file named bip-*.mediawiki/md.
    for path in reference_root.rglob("bip-*.mediawiki"):
        return path.parent
    for path in reference_root.rglob("bip-*.md"):
        return path.parent
    return None


def _scan_bips(bips_dir: Path) -> dict[int, dict]:
    """Return ``{bip_number: {title, path}}`` for BIPs in ``bips_dir``."""
    out: dict[int, dict] = {}
    count = 0
    for path in sorted(bips_dir.iterdir()):
        if count >= _MAX_BIPS_SCANNED:
            break
        if not path.is_file():
            continue
        if path.suffix.lower() not in {".md", ".mediawiki", ".rst"}:
            continue
        match = _BIP_NUMBER_RE.search(path.name)
        if not match:
            continue
        try:
            number = int(match.group(1))
        except ValueError:
            continue
        title = path.stem
        out[number] = {"title": title, "path": str(path)}
        count += 1
    return out


def _scan_zips(db_path: str) -> dict[int, dict]:
    """Scan workspace spec repos for ZIPs, keyed by their ZIP number."""
    out: dict[int, dict] = {}
    # Prefer repos the workspace catalog has tagged as specs/wiki/knowledge.
    spec_rows = query_table(
        db_path=db_path,
        table="workspace_repos",
        where="repo_type IN (?, ?)",
        params=("specs", "wiki"),
        limit=0,
    )
    candidate_roots: list[Path] = []
    for row in spec_rows:
        repo_path = Path(row.get("repo_path", ""))
        if repo_path.is_dir():
            candidate_roots.append(repo_path)
    # Also include the conventional knowledge/developer-commons location.
    dev_commons = workspace_repo("knowledge/developer-commons")
    if dev_commons is not None and dev_commons not in candidate_roots:
        candidate_roots.append(dev_commons)

    for root in candidate_roots:
        for path in root.rglob("zip-*"):
            if not path.is_file():
                continue
            if path.suffix.lower() not in {".md", ".rst", ".mediawiki"}:
                continue
            match = _ZIP_NUMBER_RE.search(path.name)
            if not match:
                continue
            try:
                number = int(match.group(1))
            except ValueError:
                continue
            out.setdefault(
                number,
                {
                    "title": path.stem,
                    "path": str(path),
                },
            )
    return out


def track_btc_specs(
    db_path: str = DEFAULT_DB,
    **_: object,
) -> dict:
    """Flag Bitcoin BIPs with no corresponding Zenon ZIP.

    Returns ``{}`` when no Bitcoin reference chain is present in the
    workspace, or when the reference repo has no BIP directory. When
    the developer-commons repo is missing every BIP is still listed but
    the finding text explains the gap.

    Args:
        db_path: SQLite database path.

    Returns:
        Dict summarizing BIPs discovered, ZIPs discovered, unmatched
        BIPs, and the number of findings emitted.
    """
    reference_root = _find_btc_reference(db_path)
    if reference_root is None:
        logger.debug("btc_spec_tracker: no Bitcoin reference chain in workspace")
        return {}

    bips_dir = _find_bips_directory(reference_root)
    if bips_dir is None:
        logger.debug("btc_spec_tracker: no BIP directory inside reference")
        return {}

    bips = _scan_bips(bips_dir)
    if not bips:
        return {"bips": 0, "zips": 0, "unmatched": 0, "findings": 0}

    zips = _scan_zips(db_path)
    knowledge_present = bool(zips) or workspace_root() is not None

    unmatched = sorted(n for n in bips if n not in zips)
    findings = 0
    for bip_number in unmatched[:_MAX_FINDINGS]:
        bip_info = bips[bip_number]
        confidence = 0.6 if knowledge_present else 0.4
        finding_text = (
            f"WHAT: BIP-{bip_number} ('{bip_info['title']}') exists in "
            f"reference repo '{reference_root.name}' but no matching "
            f"ZIP was found in the Zenon knowledge base. "
            f"SO WHAT: Bitcoin BIPs frequently describe consensus or "
            f"interop primitives (PTLC, taproot, SPV) that Zenon either "
            f"implements or should consider. A missing ZIP counterpart "
            f"is a prioritization signal for TminusZ. "
            f"NOW WHAT: Read BIP-{bip_number}, decide whether Zenon needs "
            f"an equivalent ZIP, and either open a spec draft in "
            f"knowledge/developer-commons or document why it is out of "
            f"scope. "
            f"{'' if knowledge_present else 'Note: no knowledge/developer-commons repo was detected; the ZIP space could not be enumerated.'}"
        )
        persist_finding(
            db_path=db_path,
            domain="development",
            engine="btc_spec_tracker",
            evidence_type="bip_without_zip",
            finding=finding_text,
            confidence=confidence,
            raw_data={
                "bip_number": bip_number,
                "bip_title": bip_info["title"],
                "bip_path": bip_info["path"],
            },
            source_repo=reference_root.name,
            source_file=bip_info["path"],
        )
        findings += 1

    return {
        "reference_repo": reference_root.name,
        "bips": len(bips),
        "zips": len(zips),
        "unmatched": len(unmatched),
        "findings": findings,
    }


# Scheduler-discoverable alias (prefix ``scan_``).
def scan_btc_specs(db_path: str = DEFAULT_DB, **kw: object) -> dict:
    """Alias wrapping :func:`track_btc_specs` for scheduler discovery."""
    return track_btc_specs(db_path=db_path, **kw)


__all__ = ["scan_btc_specs", "track_btc_specs"]
