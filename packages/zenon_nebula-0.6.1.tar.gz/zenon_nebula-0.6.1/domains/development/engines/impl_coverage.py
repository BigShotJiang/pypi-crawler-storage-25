# SPDX-License-Identifier: MIT
"""
ImplCoverage -- Tracks implementation status per spec across all Zenon repos.

For each spec, checks existence of implementation files across:
  - go-zenon: vm/embedded/definition/<name>.go
  - znn_sdk_dart: model/embedded/<name>.dart, api/embedded/<name>.dart
  - znn_cli_dart: lib/<name>.dart
  - nomctl: znncli_<name>.go
  - syrius: widget references
  - wiki: <name>.md page
  - zenonhub: Livewire component or view references

Computes an overall coverage percentage and persists to spec_coverage.
"""

import logging
import os
import sqlite3
import subprocess
from pathlib import Path

from core.persist_to_db import persist_finding
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

_COVERAGE_CACHE: dict = {}

# Implementation status values
NOT_STARTED = "not_started"
EXISTS = "exists"
PARTIAL = "partial"
NOT_APPLICABLE = "n/a"


def _resolve_repo_path(org: str, repo: str) -> Path | None:
    """Find the best available path for an org/repo combination.

    Checks core/ first (our canonical forks), then hypercore-one/,
    then zenon-network/.
    """
    candidates = [
        ZENON_WORKSPACE / "core" / repo,
        ZENON_WORKSPACE / "hypercore-one" / repo,
        ZENON_WORKSPACE / "zenon-network" / repo,
    ]
    for p in candidates:
        if p.is_dir():
            return p
    return None


def _file_exists(base: Path, *parts: str) -> bool:
    """Check if a file exists under a base path."""
    return (base / os.path.join(*parts)).is_file()


def _dir_has_match(base: Path, subdir: str, pattern: str) -> bool:
    """Check if any file in base/subdir contains pattern in its name."""
    d = base / subdir
    if not d.is_dir():
        return False
    pattern_lower = pattern.lower()
    return any(pattern_lower in f.name.lower() for f in d.iterdir())


# -- Per-repo checkers --


def check_go_zenon(impl_name: str) -> str:
    """Check if go-zenon has a definition file for this spec."""
    repo = _resolve_repo_path("core", "go-zenon")
    if repo is None:
        return NOT_STARTED

    # Check definition file
    definition = repo / "vm" / "embedded" / "definition" / f"{impl_name}.go"
    implementation = repo / "vm" / "embedded" / "implementation" / f"{impl_name}.go"

    if definition.is_file() and implementation.is_file():
        return EXISTS
    if definition.is_file() or implementation.is_file():
        return PARTIAL
    return NOT_STARTED


def check_sdk_dart(impl_name: str) -> str:
    """Check if znn_sdk_dart has model and API files for this spec."""
    repo = _resolve_repo_path("core", "znn_sdk_dart")
    if repo is None:
        return NOT_STARTED

    model = repo / "lib" / "src" / "model" / "embedded" / f"{impl_name}.dart"
    api = repo / "lib" / "src" / "api" / "embedded" / f"{impl_name}.dart"

    if model.is_file() and api.is_file():
        return EXISTS
    if model.is_file() or api.is_file():
        return PARTIAL

    # Try alternate naming: some use singular/plural or different casing
    repo / "lib" / "src" / "model" / "embedded"
    repo / "lib" / "src" / "api" / "embedded"
    name_lower = impl_name.lower()

    model_found = _dir_has_match(repo, "lib/src/model/embedded", name_lower)
    api_found = _dir_has_match(repo, "lib/src/api/embedded", name_lower)

    if model_found and api_found:
        return EXISTS
    if model_found or api_found:
        return PARTIAL
    return NOT_STARTED


def check_cli_dart(impl_name: str) -> str:
    """Check if znn_cli_dart has a lib file for this spec."""
    repo = _resolve_repo_path("core", "znn_cli_dart")
    if repo is None:
        return NOT_STARTED

    # CLI files use the impl name directly
    cli_file = repo / "lib" / f"{impl_name}.dart"
    if cli_file.is_file():
        return EXISTS

    # Try alternate naming
    if _dir_has_match(repo, "lib", impl_name.lower()):
        return EXISTS

    return NOT_STARTED


def check_cli_go(impl_name: str) -> str:
    """Check if nomctl has a znncli_<name>.go file for this spec."""
    repo = _resolve_repo_path("core", "nomctl")
    if repo is None:
        return NOT_STARTED

    cli_file = repo / f"znncli_{impl_name}.go"
    if cli_file.is_file():
        return EXISTS

    # Try alternate naming
    for f in repo.iterdir():
        if f.is_file() and f.suffix == ".go":
            if impl_name.lower() in f.name.lower() and f.name.startswith("znncli_"):
                return EXISTS

    return NOT_STARTED


def check_syrius(impl_name: str) -> str:
    """Check if syrius has widgets related to this spec."""
    repo = _resolve_repo_path("core", "syrius")
    if repo is None:
        return NOT_STARTED

    widgets_dir = repo / "lib" / "widgets"
    if not widgets_dir.is_dir():
        return NOT_STARTED

    name_lower = impl_name.lower()

    # Check modular_widgets and tab_children_widgets for references
    for subdir in ("modular_widgets", "tab_children_widgets"):
        check_dir = widgets_dir / subdir
        if not check_dir.is_dir():
            continue
        for entry in check_dir.iterdir():
            if entry.is_dir() and name_lower in entry.name.lower():
                return EXISTS
            if entry.is_file() and name_lower in entry.name.lower():
                return EXISTS

    # Broader search: check if any dart file in lib/ references the contract
    lib_dir = repo / "lib"
    if lib_dir.is_dir():
        for dart_file in lib_dir.rglob("*.dart"):
            if name_lower in dart_file.name.lower():
                return PARTIAL

    return NOT_STARTED


def check_docs(impl_name: str) -> str:
    """Check if the wiki has a page for this spec."""
    wiki_dir = ZENON_WORKSPACE / "knowledge" / "znn-wiki"
    if not wiki_dir.is_dir():
        return NOT_STARTED

    # Direct name match
    wiki_file = wiki_dir / f"{impl_name}.md"
    if wiki_file.is_file():
        return EXISTS

    # Try alternate naming (hyphenated)
    alt_name = impl_name.replace("_", "-")
    wiki_file_alt = wiki_dir / f"{alt_name}.md"
    if wiki_file_alt.is_file():
        return EXISTS

    # Broader search
    name_lower = impl_name.lower()
    for f in wiki_dir.iterdir():
        if f.suffix == ".md" and name_lower in f.name.lower().replace("-", "_"):
            return EXISTS

    return NOT_STARTED


def check_infra(impl_name: str) -> str:
    """Check if zenonhub has controller/view support for this spec."""
    zenonhub_paths = [
        ZENON_WORKSPACE / "zenonhub-io" / "zenonhub",
        ZENON_WORKSPACE / "infrastructure" / "zenonhub",
    ]

    for base in zenonhub_paths:
        if not base.is_dir():
            continue

        name_lower = impl_name.lower()

        # Check Livewire components
        livewire_dir = base / "app" / "Livewire"
        if livewire_dir.is_dir():
            for entry in livewire_dir.rglob("*.php"):
                if name_lower in entry.name.lower().replace("-", "_"):
                    return EXISTS

        # Check views
        views_dir = base / "resources" / "views"
        if views_dir.is_dir():
            for entry in views_dir.rglob("*.blade.php"):
                if name_lower in entry.name.lower().replace("-", "_"):
                    return EXISTS

        # Check models
        models_dir = base / "app" / "Models"
        if models_dir.is_dir():
            for entry in models_dir.rglob("*.php"):
                if name_lower in entry.name.lower().replace("-", "_"):
                    return EXISTS

    return NOT_STARTED


# -- Main coverage functions --


def check_coverage(spec: dict) -> dict:
    """Check implementation coverage for a single spec across all repos.

    Args:
        spec: Dict from spec_tracker.scan_spec() with keys:
              normalized_name, impl_name, etc.

    Returns:
        Dict with status for each repo and overall_coverage float.
    """
    impl_name = spec.get("impl_name", spec.get("normalized_name", ""))

    statuses = {
        "go_zenon_status": check_go_zenon(impl_name),
        "sdk_dart_status": check_sdk_dart(impl_name),
        "cli_dart_status": check_cli_dart(impl_name),
        "cli_go_status": check_cli_go(impl_name),
        "syrius_status": check_syrius(impl_name),
        "docs_status": check_docs(impl_name),
        "infra_status": check_infra(impl_name),
    }

    # Compute overall coverage: each repo is weighted equally
    weights = {
        "go_zenon_status": 2.0,  # Core protocol -- most important
        "sdk_dart_status": 1.5,  # SDK is critical for developer access
        "cli_dart_status": 1.0,
        "cli_go_status": 1.0,
        "syrius_status": 1.0,
        "docs_status": 1.0,
        "infra_status": 0.5,  # Explorer is nice-to-have
    }

    total_weight = sum(weights.values())
    covered_weight = 0.0
    for key, status in statuses.items():
        if status == EXISTS:
            covered_weight += weights[key]
        elif status == PARTIAL:
            covered_weight += weights[key] * 0.5

    overall = round(covered_weight / total_weight, 4) if total_weight > 0 else 0.0
    statuses["overall_coverage"] = overall

    return statuses


def check_all_coverage(specs: list[dict]) -> list[dict]:
    """Check coverage for all specs.

    Skips work if none of the key repos have changed since last check.

    Args:
        specs: List of spec dicts from spec_tracker.scan_all_specs().

    Returns:
        List of dicts, each containing spec info merged with coverage info.
    """
    # Git hash gating: skip if no repo changed (return cached results)
    try:
        from core.git_cache import has_repo_changed

        key_repos = ["go-zenon", "znn_sdk_dart", "znn_cli_dart", "nomctl", "syrius"]
        any_changed = False
        for repo_name in key_repos:
            repo_path = _resolve_repo_path("core", repo_name)
            if repo_path and has_repo_changed(str(repo_path)):
                any_changed = True
                break
        if not any_changed and specs:
            logger.debug("Skipping impl coverage — no key repo HEAD changed")
            return _COVERAGE_CACHE.get("results", [])
    except Exception as exc:
        logger.debug("Repo change check failed: %s", exc)

    results = []
    for spec in specs:
        coverage = check_coverage(spec)
        result = {**spec, **coverage}
        results.append(result)

    # Sort by coverage (least covered first)
    results.sort(key=lambda r: r.get("overall_coverage", 0))

    covered = sum(1 for r in results if r.get("overall_coverage", 0) > 0.5)
    logger.info(
        "ImplCoverage: checked %d specs, %d have >50%% coverage",
        len(results),
        covered,
    )
    _COVERAGE_CACHE["results"] = results
    return results


def persist_coverage(results: list[dict], db_path: str = DEFAULT_DB) -> int:
    """Persist coverage results to the spec_coverage table.

    Updates existing rows or inserts new ones. Returns count of rows affected.
    """
    conn = connect(db_path)
    count = 0
    try:
        for r in results:
            spec_name = r.get("normalized_name", r.get("name", ""))
            existing = conn.execute(
                "SELECT id FROM spec_coverage WHERE spec_name = ?",
                (spec_name,),
            ).fetchone()

            if existing:
                conn.execute(
                    """UPDATE spec_coverage SET
                        spec_path = ?,
                        go_zenon_status = ?,
                        sdk_dart_status = ?,
                        cli_dart_status = ?,
                        cli_go_status = ?,
                        syrius_status = ?,
                        docs_status = ?,
                        infra_status = ?,
                        overall_coverage = ?,
                        last_checked = CURRENT_TIMESTAMP
                    WHERE spec_name = ?""",
                    (
                        r.get("path", ""),
                        r.get("go_zenon_status", NOT_STARTED),
                        r.get("sdk_dart_status", NOT_STARTED),
                        r.get("cli_dart_status", NOT_STARTED),
                        r.get("cli_go_status", NOT_STARTED),
                        r.get("syrius_status", NOT_STARTED),
                        r.get("docs_status", NOT_STARTED),
                        r.get("infra_status", NOT_STARTED),
                        r.get("overall_coverage", 0.0),
                        spec_name,
                    ),
                )
            else:
                conn.execute(
                    """INSERT INTO spec_coverage
                    (spec_name, spec_path, go_zenon_status, sdk_dart_status,
                     cli_dart_status, cli_go_status, syrius_status,
                     docs_status, infra_status, overall_coverage)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        spec_name,
                        r.get("path", ""),
                        r.get("go_zenon_status", NOT_STARTED),
                        r.get("sdk_dart_status", NOT_STARTED),
                        r.get("cli_dart_status", NOT_STARTED),
                        r.get("cli_go_status", NOT_STARTED),
                        r.get("syrius_status", NOT_STARTED),
                        r.get("docs_status", NOT_STARTED),
                        r.get("infra_status", NOT_STARTED),
                        r.get("overall_coverage", 0.0),
                    ),
                )
            count += 1

        conn.commit()
    finally:
        conn.close()

    logger.info("ImplCoverage: persisted coverage for %d specs", count)
    return count


def get_coverage_report(db_path: str = DEFAULT_DB) -> list[dict]:
    """Get the latest coverage report from the database."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT * FROM spec_coverage
            ORDER BY overall_coverage ASC"""
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_gaps(db_path: str = DEFAULT_DB) -> list[dict]:
    """Get specs with incomplete coverage, sorted by gap severity."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT * FROM spec_coverage
            WHERE overall_coverage < 1.0
            ORDER BY overall_coverage ASC"""
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def _get_head_commit(repo_path: Path) -> str | None:
    """Get the HEAD commit hash for a repo, or None on failure."""
    git_dir = repo_path / ".git"
    if not git_dir.exists():
        return None
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_path), "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception as exc:
        logger.debug("git rev-parse HEAD failed: %s", exc)
    return None


# Mapping from status check functions to repo names
_REPO_NAMES = {
    "go_zenon_status": "go-zenon",
    "sdk_dart_status": "znn_sdk_dart",
    "cli_dart_status": "znn_cli_dart",
    "cli_go_status": "nomctl",
    "syrius_status": "syrius",
    "docs_status": "znn-wiki",
    "infra_status": "zenonhub",
}


def _identify_gaps(statuses: dict) -> list[str]:
    """Return human-readable list of missing layers for a spec."""
    labels = {
        "go_zenon_status": "Go contract",
        "sdk_dart_status": "Dart SDK",
        "cli_dart_status": "Dart CLI",
        "cli_go_status": "Go CLI (nomctl)",
        "syrius_status": "Syrius wallet tab",
        "docs_status": "Wiki documentation",
        "infra_status": "ZenonHub explorer page",
    }
    gaps = []
    for key, label in labels.items():
        status = statuses.get(key, NOT_STARTED)
        if status == NOT_STARTED:
            gaps.append(label)
        elif status == PARTIAL:
            gaps.append(f"{label} (partial)")
    return gaps


# Priority tiers: specs ranked by ecosystem impact.
# BTC bridge path is highest priority, then governance, then advanced features.
_SPEC_PRIORITY = {
    "ptlc": 1,
    "bitcoin_spv": 1,
    "portal": 1,
    "atomic_swap": 2,
    "governance": 2,
    "multisig": 3,
    "streaming": 3,
    "zns": 3,
    "commit_channels": 4,
    "galv": 4,
    "did": 4,
    "sentinel_validator": 4,
    "commitments": 4,
}

_PRIORITY_LABELS = {
    1: "BTC bridge critical path",
    2: "governance/interop",
    3: "advanced features",
    4: "future roadmap",
}


def _build_actionable_finding(r: dict) -> str:
    """Build an actionable finding for a single spec.

    Answers: WHAT (coverage state), SO WHAT (why it matters),
    NOW WHAT (specific next action).
    """
    spec_name = r.get("normalized_name", r.get("name", ""))
    overall = r.get("overall_coverage", 0.0)
    pct = overall * 100

    gaps = _identify_gaps(r)
    priority_tier = _SPEC_PRIORITY.get(spec_name, 5)
    priority_label = _PRIORITY_LABELS.get(priority_tier, "unclassified")

    # WHAT
    if not gaps:
        what = f"{spec_name} has full stack coverage ({pct:.0f}%)."
    elif pct >= 70:
        what = f"{spec_name} has {pct:.0f}% coverage — missing: {', '.join(gaps)}."
    elif pct >= 30:
        what = f"{spec_name} has only {pct:.0f}% coverage — missing: {', '.join(gaps)}."
    else:
        what = f"{spec_name} has minimal coverage ({pct:.0f}%) — missing: {', '.join(gaps)}."

    # SO WHAT
    if not gaps:
        so_what = "Ready for upstream PR submission."
    elif priority_tier <= 2 and len(gaps) <= 2:
        so_what = (
            f"Near-complete on {priority_label}. "
            f"Finishing {len(gaps)} remaining layer(s) unblocks upstream PR."
        )
    elif priority_tier <= 2:
        so_what = (
            f"This is {priority_label} — high ecosystem impact. "
            f"{len(gaps)} missing layers block upstream submission."
        )
    else:
        so_what = (
            f"Priority tier: {priority_label}. "
            f"Not blocking bridge/governance work but needed for full stack."
        )

    # NOW WHAT
    if not gaps:
        now_what = "Action: run /verify, then open upstream PR."
    elif "Go contract" in gaps:
        now_what = "Action: implement Go contract first — all other layers depend on it."
    elif "Dart SDK" in gaps or "Dart SDK (partial)" in gaps:
        now_what = "Action: implement Dart SDK (model + API) — CLI and wallet depend on it."
    else:
        # Recommend the highest-impact remaining gap
        now_what = f"Action: implement {gaps[0]} next."

    return f"{what} {so_what} {now_what}"


def _build_summary_finding(results: list[dict]) -> str:
    """Build a cross-spec summary with prioritized recommendations."""
    if not results:
        return "No specs found to analyze."

    full_coverage = [r for r in results if r.get("overall_coverage", 0) >= 1.0]
    high_coverage = [r for r in results if 0.5 <= r.get("overall_coverage", 0) < 1.0]
    low_coverage = [r for r in results if r.get("overall_coverage", 0) < 0.5]

    parts = []

    # WHAT
    parts.append(
        f"Spec coverage: {len(full_coverage)} complete, "
        f"{len(high_coverage)} near-complete (>50%), "
        f"{len(low_coverage)} underbuilt (<50%) out of {len(results)} total."
    )

    # SO WHAT — identify the highest-priority gap
    bridge_specs = [
        r
        for r in results
        if _SPEC_PRIORITY.get(r.get("normalized_name", r.get("name", "")), 5) == 1
        and r.get("overall_coverage", 0) < 1.0
    ]
    if bridge_specs:
        names = [r.get("normalized_name", r.get("name", "")) for r in bridge_specs]
        parts.append(
            f"BTC bridge critical path has gaps in: {', '.join(names)}. "
            f"This blocks the trustless BTC bridge — Zenon's highest-impact feature."
        )
    elif high_coverage:
        almost = [r.get("normalized_name", r.get("name", "")) for r in high_coverage[:3]]
        parts.append(
            f"Near-complete specs that need small effort to finish: "
            f"{', '.join(almost)}. Finishing these yields quick upstream PRs."
        )

    # NOW WHAT — top 3 recommendations
    recs = []
    # 1. Highest-priority incomplete spec
    for r in sorted(
        results,
        key=lambda x: (
            _SPEC_PRIORITY.get(x.get("normalized_name", x.get("name", "")), 5),
            -x.get("overall_coverage", 0),
        ),
    ):
        name = r.get("normalized_name", r.get("name", ""))
        cov = r.get("overall_coverage", 0)
        if cov < 1.0:
            gaps = _identify_gaps(r)
            recs.append(f"1. Finish {name} ({gaps[0] if gaps else 'unknown'} missing)")
            break

    # 2. Quickest win (highest coverage that isn't 100%)
    for r in sorted(results, key=lambda x: -x.get("overall_coverage", 0)):
        cov = r.get("overall_coverage", 0)
        if 0.5 <= cov < 1.0:
            name = r.get("normalized_name", r.get("name", ""))
            gaps = _identify_gaps(r)
            recs.append(f"2. Quick win: {name} at {cov * 100:.0f}% — only needs {', '.join(gaps)}")
            break

    # 3. Full-stack specs ready for PR
    if full_coverage:
        names = [r.get("normalized_name", r.get("name", "")) for r in full_coverage[:3]]
        recs.append(f"3. PR-ready: {', '.join(names)} — run /verify and submit upstream")

    if recs:
        parts.append("Recommendations: " + ". ".join(recs) + ".")

    return " ".join(parts)


def persist_coverage_as_evidence(
    results: list[dict],
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist actionable coverage findings to the unified evidence table.

    Each spec gets a finding answering WHAT / SO WHAT / NOW WHAT.
    A summary finding ranks priorities and recommends next actions.

    Returns the number of findings persisted.
    """
    count = 0

    # Per-spec actionable findings
    for r in results:
        spec_name = r.get("normalized_name", r.get("name", ""))
        overall = r.get("overall_coverage", 0.0)

        finding = _build_actionable_finding(r)

        go_zenon = _resolve_repo_path("core", "go-zenon")
        source_commit = _get_head_commit(go_zenon) if go_zenon else None

        checked_repos = []
        for key, repo_name in _REPO_NAMES.items():
            if r.get(key, NOT_STARTED) != NOT_STARTED:
                checked_repos.append(repo_name)
        source_repo = ", ".join(checked_repos) if checked_repos else "go-zenon"

        persist_finding(
            db_path=db_path,
            domain="development",
            engine="impl_coverage",
            evidence_type="coverage_scan",
            finding=finding,
            confidence=0.9,
            raw_data={
                "spec_name": spec_name,
                "overall_coverage": overall,
                "gaps": _identify_gaps(r),
                "priority_tier": _SPEC_PRIORITY.get(spec_name, 5),
                "statuses": {k: r.get(k, NOT_STARTED) for k in _REPO_NAMES},
            },
            source_repo=source_repo,
            source_commit=source_commit,
        )
        count += 1

    # Cross-spec summary with prioritized recommendations
    summary = _build_summary_finding(results)
    persist_finding(
        db_path=db_path,
        domain="development",
        engine="impl_coverage",
        evidence_type="coverage_summary",
        finding=summary,
        confidence=0.9,
        raw_data={
            "total_specs": len(results),
            "full_coverage": sum(1 for r in results if r.get("overall_coverage", 0) >= 1.0),
            "partial_coverage": sum(1 for r in results if 0 < r.get("overall_coverage", 0) < 1.0),
            "no_coverage": sum(1 for r in results if r.get("overall_coverage", 0) == 0),
        },
        source_repo="workspace",
    )
    count += 1

    logger.info("ImplCoverage: persisted %d actionable findings to evidence", count)
    return count
