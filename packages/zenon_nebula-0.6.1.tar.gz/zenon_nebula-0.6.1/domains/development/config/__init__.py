# SPDX-License-Identifier: MIT
"""Development domain configuration -- repo lists and spec tracking parameters."""
