# SPDX-License-Identifier: MIT
"""Development domain -- spec tracking, coverage analysis, and build dependency management."""

from domains.development.domain import DevelopmentDomain

__all__ = ["DevelopmentDomain"]
