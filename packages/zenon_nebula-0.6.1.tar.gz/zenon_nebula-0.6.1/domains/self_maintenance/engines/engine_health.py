# SPDX-License-Identifier: MIT
"""Engine Health Monitor — Watches every engine across every domain.

Detects: stale engines (no run in 24h), high error rates (>20%),
cost overruns, and declining success rates. Reports to War Room,
triggers alerts via feedback bus, and persists a per-engine snapshot
row to the ``engine_health`` table on every invocation so historical
health trends are queryable.
"""

import sqlite3
from datetime import datetime, timedelta, timezone

from core.persistence import connect


def check_engine_health(db_path: str) -> dict:
    """Check health of all engines across all domains.

    Also persists a snapshot row per (domain, engine) to the
    ``engine_health`` table so the self-maintenance domain has
    historical data to trend on. Pre-v0.2.17 this engine computed
    stats and returned them in the response dict but never wrote a
    single row — 177 harden-run invocations produced 0 rows.

    Returns dict with:
    - healthy: list of engine names running normally
    - stale: list of engines with no run in 24h
    - erroring: list of engines with >20% error rate
    - expensive: list of engines exceeding budget allocation
    - summary: overall health score 0-100
    - persisted: count of snapshot rows written this call
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row

    results = {
        "healthy": [],
        "stale": [],
        "erroring": [],
        "expensive": [],
        "summary": 100,
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "persisted": 0,
    }

    try:
        # Check actions_log for each domain/module combination
        rows = conn.execute("""
            SELECT
                domain,
                module,
                COUNT(*) as total_actions,
                SUM(CASE WHEN error IS NOT NULL AND error != '' THEN 1 ELSE 0 END) as errors,
                SUM(cost_usd) as total_cost,
                MAX(timestamp) as last_run
            FROM actions_log
            GROUP BY domain, module
        """).fetchall()

        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(hours=24)

        for row in rows:
            engine_id = f"{row['domain']}.{row['module']}"
            total = row["total_actions"] or 0
            errors = row["errors"] or 0
            cost = row["total_cost"] or 0.0
            last_run = row["last_run"] or ""

            # Check staleness
            if last_run and last_run < cutoff.isoformat():
                results["stale"].append(
                    {
                        "engine": engine_id,
                        "description": (
                            f"WHAT: Engine '{engine_id}' last ran at {last_run}, over 24h ago. "
                            f"SO WHAT: Stale engine means its domain has no fresh data; findings are outdated. "
                            f"NOW WHAT: Check if the engine crashed or was disabled; restart the autonomous runner."
                        ),
                    }
                )
                results["summary"] -= 5

            # Check error rate
            if total > 0 and (errors / total) > 0.20:
                error_rate = round(errors / total, 2)
                results["erroring"].append(
                    {
                        "engine": engine_id,
                        "error_rate": error_rate,
                        "total": total,
                        "description": (
                            f"WHAT: Engine '{engine_id}' has {int(error_rate * 100)}% error rate ({errors}/{total} actions failed). "
                            f"SO WHAT: High error rate means this engine is producing unreliable data; dependent findings may be wrong. "
                            f"NOW WHAT: Check actions_log for the most common error message; fix the root cause (API down? schema changed? bad input?)."
                        ),
                    }
                )
                results["summary"] -= 10

            # Check cost (flag if >$5/day for any single engine)
            if cost > 5.0:
                results["expensive"].append(
                    {
                        "engine": engine_id,
                        "cost": round(cost, 2),
                        "description": (
                            f"WHAT: Engine '{engine_id}' has spent ${cost:.2f} total (threshold: $5). "
                            f"SO WHAT: Cost overrun risks exhausting the daily budget and starving other engines. "
                            f"NOW WHAT: Review this engine's LLM call frequency; reduce cycle rate or switch to cheaper model."
                        ),
                    }
                )
                results["summary"] -= 3

            stale_ids = {e["engine"] if isinstance(e, dict) else e for e in results["stale"]}
            erroring_ids = {e.get("engine", "") for e in results["erroring"]}
            if engine_id not in stale_ids and engine_id not in erroring_ids:
                results["healthy"].append(engine_id)

            # Persist a snapshot row per engine — one row per check so
            # trend queries can graph health over time. The table is
            # intentionally append-only (no upsert) so we can see
            # transient error spikes that would otherwise disappear.
            if engine_id in stale_ids:
                status = "stale"
            elif engine_id in erroring_ids:
                status = "erroring"
            elif cost > 5.0:
                status = "expensive"
            else:
                status = "healthy"
            success = max(0, total - errors)
            try:
                conn.execute(
                    """INSERT INTO engine_health
                       (domain, engine, last_run, success_count,
                        error_count, cost_total, status)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (
                        row["domain"],
                        row["module"],
                        last_run or None,
                        success,
                        errors,
                        float(cost),
                        status,
                    ),
                )
                results["persisted"] += 1
            except sqlite3.Error:
                # Degrade gracefully: the health check itself must not
                # crash the scheduler just because a snapshot write
                # failed. Missing rows are visible in the returned dict.
                pass

        conn.commit()
        results["summary"] = max(0, min(100, results["summary"]))

    finally:
        conn.close()

    return results


def detect_stall_cascade(db_path: str, threshold: int = 3) -> dict | None:
    """Detect if multiple domains have stalled simultaneously.

    A stall cascade suggests a systemic issue (DB corruption,
    API key expired, network problem) rather than a single engine bug.
    """
    health = check_engine_health(db_path)

    stale_domains = set()
    for entry in health["stale"]:
        engine_id = entry["engine"] if isinstance(entry, dict) else entry
        domain = engine_id.split(".")[0]
        stale_domains.add(domain)

    if len(stale_domains) >= threshold:
        return {
            "cascade_detected": True,
            "stale_domains": list(stale_domains),
            "description": (
                f"WHAT: {len(stale_domains)} domains have stalled simultaneously: {', '.join(sorted(stale_domains))}. "
                f"SO WHAT: Multi-domain stall indicates a systemic issue, not a single engine bug; all Nebula intelligence is stale. "
                f"NOW WHAT: Check in order: 1) Is the DB writable? 2) Are API keys valid? 3) Is the network connected? 4) Is budget remaining?"
            ),
        }

    return None
