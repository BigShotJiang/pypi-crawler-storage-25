# SPDX-License-Identifier: MIT
"""Self-Maintenance Domain — Nebula monitoring and healing itself.

This domain ensures Nebula stays healthy, current, and self-aware.
It watches for: stale engines, dead hypotheses, budget overruns,
test failures, documentation drift, and database bloat.

If Nebula is the brain, this domain is the immune system.
"""

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)


class SelfMaintenanceDomain(DomainPlugin):
    """Nebula's immune system — keeps the platform healthy."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "self_maintenance"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return "Monitors Nebula's own health: engine performance, data freshness, budget pacing, test coverage, documentation accuracy"

    def get_engines(self) -> list:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="engine_health_monitor",
                module_path="domains.self_maintenance.engines.engine_health",
                priority=9,
                description="Monitors each engine's success rate, error rate, staleness, cost efficiency",
            ),
            EngineDefinition(
                name="config_drift_detector",
                module_path="domains.self_maintenance.engines.config_drift",
                priority=8,
                description="Detects when config files, README, domain count, or engine count drift from reality",
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="nebula_healthy",
                label="Nebula is healthy",
                description="All engines running, no stale data, tests passing, budget on track",
            ),
            HypothesisType(
                type_id="self_improvement_working",
                label="Self-improvement is working",
                description="System quality metrics improving session over session",
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="zero_stale_engines",
                label="Zero stale engines",
                description="All engines have run within their expected cadence.",
            ),
            AspirationType(
                type_id="full_test_pass",
                label="100% test pass rate",
                description="All test suites across all domains pass without failure.",
            ),
            AspirationType(
                type_id="doc_matches_reality",
                label="Documentation matches reality",
                description="README claims, domain counts, and engine counts match actual state.",
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="engine_stall_cascade",
                label="Engine stall cascade",
                description="Multiple engines across different domains are stalled simultaneously",
                source_domains=["self_maintenance"],
            ),
            CollisionSignal(
                signal_id="budget_exhaustion_warning",
                label="Budget exhaustion warning",
                description="Daily budget >80% consumed before end of cycle",
                source_domains=["self_maintenance"],
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="self_maintenance",
                section_title="System Health",
                metrics=[
                    "engine_uptime_pct",
                    "stale_engine_count",
                    "error_rate_24h",
                ],
            ),
            WarRoomContribution(
                domain="self_maintenance",
                section_title="Budget Status",
                metrics=[
                    "budget_spent_today",
                    "budget_remaining",
                    "cost_per_finding",
                ],
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "engine_uptime_pct": 0.0,
            "test_pass_rate": 0.0,
            "stale_evidence_count": 0.0,
            "db_size_mb": 0.0,
            "budget_accuracy": 0.0,
            "doc_drift_score": 0.0,
        }

    def decide_next_action(self, context: dict) -> dict | None:
        """Self-maintenance runs every cycle to monitor engine health."""
        stale = context.get("stale_data", [])
        if "engine_health" in stale or not stale:
            return {
                "action": "check_engine_health",
                "reason": "Routine engine health check.",
                "priority": 8,
                "engine": "engine_health",
            }
        if "config_drift" in stale:
            return {
                "action": "check_config_drift",
                "reason": "Configuration drift monitoring.",
                "priority": 9,
                "engine": "config_drift",
            }
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
        CREATE TABLE IF NOT EXISTS engine_health (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            domain TEXT NOT NULL,
            engine TEXT NOT NULL,
            last_run DATETIME,
            success_count INTEGER DEFAULT 0,
            error_count INTEGER DEFAULT 0,
            cost_total REAL DEFAULT 0.0,
            status TEXT DEFAULT 'unknown'
        );

        CREATE TABLE IF NOT EXISTS maintenance_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            action TEXT NOT NULL,
            target TEXT,
            result TEXT,
            details TEXT
        );
        """
