# SPDX-License-Identifier: MIT
"""
BipZipTracker -- Track Bitcoin BIPs relevant to Zenon and Zenon ZIPs.

Monitors the bitcoin/bips GitHub repository for BIPs that are directly
relevant to Zenon (secp256k1, HD wallets, Taproot, SegWit, etc.) and
tracks Zenon-specific ZIPs from the developer-commons spec repository.
"""

import json
import logging
import sqlite3
from pathlib import Path
from urllib.error import URLError
from urllib.request import Request

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
import contextlib

from core.http import opsec_urlopen
from core.persistence import connect
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

GITHUB_API = "https://api.github.com"

# BIPs directly relevant to Zenon's Bitcoin alignment
RELEVANT_BIPS = [
    {"bip_number": 32, "title": "Hierarchical Deterministic Wallets", "relevance": "direct"},
    {
        "bip_number": 39,
        "title": "Mnemonic code for generating deterministic keys",
        "relevance": "direct",
    },
    {
        "bip_number": 44,
        "title": "Multi-Account Hierarchy for Deterministic Wallets",
        "relevance": "direct",
    },
    {"bip_number": 141, "title": "Segregated Witness (Consensus layer)", "relevance": "reference"},
    {
        "bip_number": 143,
        "title": "Transaction Signature Verification for Version 0 Witness Program",
        "relevance": "reference",
    },
    {
        "bip_number": 173,
        "title": "Base32 address format for native v0-16 witness outputs (Bech32)",
        "relevance": "reference",
    },
    {
        "bip_number": 174,
        "title": "Partially Signed Bitcoin Transactions (PSBT)",
        "relevance": "bridge",
    },
    {"bip_number": 340, "title": "Schnorr Signatures for secp256k1", "relevance": "direct"},
    {"bip_number": 341, "title": "Taproot: SegWit version 1 spending rules", "relevance": "bridge"},
    {"bip_number": 342, "title": "Validation of Taproot Scripts", "relevance": "bridge"},
    {
        "bip_number": 350,
        "title": "Bech32m format for v1+ witness addresses",
        "relevance": "reference",
    },
    {"bip_number": 370, "title": "PSBT Version 2", "relevance": "bridge"},
    {
        "bip_number": 86,
        "title": "Key Derivation for Single Key P2TR Outputs",
        "relevance": "bridge",
    },
]


def _api_get(url: str, timeout: int = 15) -> dict | None:
    """Make a GET request and return parsed JSON, or None on failure."""
    try:
        headers = {"User-Agent": "ZenonForge/1.0", "Accept": "application/vnd.github.v3+json"}
        req = Request(url, headers=headers)
        with opsec_urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except (URLError, json.JSONDecodeError, OSError) as exc:
        logger.warning("API request failed for %s: %s", url, exc)
        return None


def fetch_bip_status(bip_number: int) -> dict | None:
    """Fetch the current status of a BIP from the bitcoin/bips repo.

    Returns dict with status info or None on failure.
    """
    # Try to fetch the BIP file from GitHub
    padded = f"{bip_number:04d}"
    url = f"{GITHUB_API}/repos/bitcoin/bips/contents/bip-{padded}.mediawiki"
    data = _api_get(url)
    if data and "name" in data:
        return {
            "bip_number": bip_number,
            "exists": True,
            "url": f"https://github.com/bitcoin/bips/blob/master/bip-{padded}.mediawiki",
        }
    # Try .md extension
    url = f"{GITHUB_API}/repos/bitcoin/bips/contents/bip-{padded}.md"
    data = _api_get(url)
    if data and "name" in data:
        return {
            "bip_number": bip_number,
            "exists": True,
            "url": f"https://github.com/bitcoin/bips/blob/master/bip-{padded}.md",
        }
    return {"bip_number": bip_number, "exists": False, "url": None}


def scan_local_zips() -> list[dict]:
    """Scan local developer-commons repo for Zenon ZIP specifications.

    Looks for ZIP files in known spec locations.
    """
    zips = []
    spec_paths = [
        ZENON_WORKSPACE / "core" / "developer-commons",
        ZENON_WORKSPACE / "hypercore-one" / "developer-commons",
    ]

    for spec_root in spec_paths:
        if not spec_root.is_dir():
            continue

        # Look for ZIP-like files
        for pattern in ["**/ZIP-*.md", "**/zip-*.md", "**/ZIP*.md"]:
            for f in spec_root.glob(pattern):
                zip_info = _parse_zip_file(f)
                if zip_info:
                    zips.append(zip_info)

        # Also check for numbered spec files
        for pattern in ["**/*.md"]:
            for f in spec_root.glob(pattern):
                if any(kw in f.name.lower() for kw in ["zip", "spec", "proposal"]):
                    zip_info = _parse_zip_file(f)
                    if zip_info:
                        zips.append(zip_info)

    return zips


def _parse_zip_file(path: Path) -> dict | None:
    """Parse a ZIP specification file for metadata."""
    try:
        content = path.read_text(encoding="utf-8")[:2000]
    except (OSError, UnicodeDecodeError):
        return None

    # Extract title from first heading
    title = path.stem
    for line in content.split("\n"):
        if line.startswith("# "):
            title = line[2:].strip()
            break

    # Try to extract ZIP number from filename or content
    zip_number = None
    name_lower = path.name.lower()
    for prefix in ["zip-", "zip"]:
        if prefix in name_lower:
            rest = name_lower.split(prefix, 1)[1]
            digits = ""
            for c in rest:
                if c.isdigit():
                    digits += c
                else:
                    break
            if digits:
                zip_number = int(digits)
                break

    # Detect status from content
    status = "draft"
    content_lower = content.lower()
    if "status: final" in content_lower or "status: accepted" in content_lower:
        status = "final"
    elif "status: active" in content_lower:
        status = "active"
    elif "status: withdrawn" in content_lower:
        status = "withdrawn"

    return {
        "zip_number": zip_number,
        "title": title,
        "status": status,
        "path": str(path),
    }


def seed_relevant_bips(*, db_path: str = DEFAULT_DB) -> int:
    """Seed the bip_tracking table with known relevant BIPs.

    Returns number of BIPs seeded.
    """
    conn = connect(db_path)
    seeded = 0
    try:
        for bip in RELEVANT_BIPS:
            existing = conn.execute(
                "SELECT id FROM bip_tracking WHERE type = 'bip' AND bip_number = ?",
                (bip["bip_number"],),
            ).fetchone()
            if existing:
                continue
            conn.execute(
                """INSERT INTO bip_tracking
                   (bip_number, title, type, relevance, status, zenon_impl_status)
                   VALUES (?, ?, 'bip', ?, 'final', 'tracking')""",
                (bip["bip_number"], bip["title"], bip["relevance"]),
            )
            seeded += 1
        conn.commit()
    finally:
        conn.close()
    return seeded


def persist_zips(
    zips: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist found ZIPs to the bip_tracking table."""
    conn = connect(db_path)
    persisted = 0
    try:
        for z in zips:
            if z.get("zip_number") is None:
                continue
            existing = conn.execute(
                "SELECT id FROM bip_tracking WHERE type = 'zip' AND zip_number = ?",
                (z["zip_number"],),
            ).fetchone()
            if existing:
                conn.execute(
                    """UPDATE bip_tracking SET status = ?, last_checked = CURRENT_TIMESTAMP
                       WHERE type = 'zip' AND zip_number = ?""",
                    (z["status"], z["zip_number"]),
                )
            else:
                conn.execute(
                    """INSERT INTO bip_tracking
                       (zip_number, title, type, status, relevance, notes)
                       VALUES (?, ?, 'zip', ?, 'direct', ?)""",
                    (z["zip_number"], z["title"], z["status"], z.get("path", "")),
                )
                persisted += 1
        conn.commit()
    finally:
        conn.close()
    return persisted


def get_tracking_summary(*, db_path: str = DEFAULT_DB) -> dict:
    """Get summary of all tracked BIPs and ZIPs."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        bips = conn.execute(
            "SELECT * FROM bip_tracking WHERE type = 'bip' ORDER BY bip_number"
        ).fetchall()
        zips = conn.execute(
            "SELECT * FROM bip_tracking WHERE type = 'zip' ORDER BY zip_number"
        ).fetchall()

        return {
            "bips": [dict(r) for r in bips],
            "zips": [dict(r) for r in zips],
            "total_bips": len(bips),
            "total_zips": len(zips),
        }
    finally:
        conn.close()


def scan_hyperqube_standards() -> list[dict]:
    """Scan hyperqube_z and related repos for HyperQube standards.

    Looks for HQIPs (HyperQube Improvement Proposals) and extension chain
    specifications.
    """
    standards = []
    hq_paths = [
        ZENON_WORKSPACE / "hypercore-one" / "hyperqube_z",
        ZENON_WORKSPACE / "zenon-network" / "hyperqube_z",
        ZENON_WORKSPACE / "hypercore-one" / "hyperqube-z",
    ]

    for hq_dir in hq_paths:
        if not hq_dir.is_dir():
            continue

        for md_file in hq_dir.rglob("*.md"):
            if ".git" in str(md_file):
                continue
            content = ""
            try:
                content = md_file.read_text(encoding="utf-8")[:3000]
            except (OSError, UnicodeDecodeError):
                continue

            content_lower = content.lower()
            if any(
                kw in content_lower
                for kw in [
                    "hqip",
                    "hyperqube",
                    "extension chain",
                    "proposal",
                    "specification",
                    "standard",
                ]
            ):
                # Extract title
                title = md_file.stem
                for line in content.split("\n"):
                    if line.startswith("# "):
                        title = line[2:].strip()
                        break

                # Detect status
                status = "draft"
                if "status: final" in content_lower:
                    status = "final"
                elif "status: active" in content_lower:
                    status = "active"

                # Try to extract HQIP number
                hqip_num = None
                import re as re_mod

                num_match = re_mod.search(r"hqip[-_]?(\d+)", md_file.name.lower())
                if num_match:
                    hqip_num = int(num_match.group(1))

                standards.append(
                    {
                        "type": "hqip",
                        "number": hqip_num,
                        "title": title,
                        "status": status,
                        "path": str(md_file),
                        "source_repo": str(hq_dir.relative_to(ZENON_WORKSPACE)),
                    }
                )

    return standards


def scan_nostr_integration() -> list[dict]:
    """Scan for Nostr-related repos and integration standards.

    Looks at qubestr and any Nostr-related content.
    """
    findings = []
    nostr_paths = [
        ZENON_WORKSPACE / "hypercore-one" / "qubestr",
        ZENON_WORKSPACE / "zenon-network" / "qubestr",
    ]

    for nostr_dir in nostr_paths:
        if not nostr_dir.is_dir():
            continue

        # Count files by type
        file_counts = {}
        for f in nostr_dir.rglob("*"):
            if f.is_file() and ".git" not in str(f):
                ext = f.suffix or "no_ext"
                file_counts[ext] = file_counts.get(ext, 0) + 1

        # Read README for description
        readme = ""
        for name in ["README.md", "readme.md"]:
            readme_path = nostr_dir / name
            if readme_path.is_file():
                with contextlib.suppress(OSError, UnicodeDecodeError):
                    readme = readme_path.read_text(encoding="utf-8")[:500]
                break

        findings.append(
            {
                "type": "nostr_integration",
                "repo": str(nostr_dir.relative_to(ZENON_WORKSPACE)),
                "file_counts": file_counts,
                "description": readme[:200] if readme else "No README",
            }
        )

    return findings


def run_bip_zip_sync(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full BIP/ZIP/HQIP sync: seed BIPs, scan ZIPs, scan HQIPs, persist.

    Returns sync results.
    """
    bips_seeded = seed_relevant_bips(db_path=db_path)
    zips_found = scan_local_zips()
    zips_persisted = persist_zips(zips_found, db_path=db_path)
    hqips = scan_hyperqube_standards()
    nostr = scan_nostr_integration()

    summary = get_tracking_summary(db_path=db_path)

    # Persist HQIPs and Nostr findings to evidence table
    from core.persist_to_db import ensure_schema, persist_finding

    ensure_schema(db_path)

    for hqip in hqips:
        hqip_num = hqip.get("number", "unnumbered")
        hqip_status = hqip["status"]
        persist_finding(
            db_path=db_path,
            domain="standards",
            engine="bip_zip_tracker",
            evidence_type="hqip_standard",
            finding=(
                f"WHAT: HQIP '{hqip['title']}' (number: {hqip_num}) is in '{hqip_status}' status. "
                f"SO WHAT: {'This standard is finalized and should be implemented if not already.' if hqip_status == 'final' else 'This standard is still in draft; track for changes before implementing.' if hqip_status == 'draft' else f'Status is {hqip_status}; review for applicability.'} "
                f"NOW WHAT: {'Check if go-zenon and SDKs implement this HQIP; add to spec coverage matrix.' if hqip_status == 'final' else 'Monitor for status changes in the source repo; no implementation needed yet.'}"
            ),
            confidence=0.80,
            raw_data=hqip,
            source_repo=hqip.get("source_repo"),
            source_file=hqip.get("path"),
        )

    for entry in nostr:
        file_count = sum(entry["file_counts"].values()) if entry.get("file_counts") else 0
        persist_finding(
            db_path=db_path,
            domain="standards",
            engine="bip_zip_tracker",
            evidence_type="nostr_integration",
            finding=(
                f"WHAT: Nostr integration repo found at {entry['repo']} ({file_count} files). "
                f"SO WHAT: Nostr integration enables decentralized messaging and social features for Zenon; "
                f"repo activity level indicates development priority. "
                f"NOW WHAT: Review repo README for integration points with Zenon; "
                f"check if qubestr depends on any Zenon SDK changes."
            ),
            confidence=0.70,
            raw_data=entry,
            source_repo=entry.get("repo"),
        )

    return {
        "success": True,
        "bips_seeded": bips_seeded,
        "zips_found": len(zips_found),
        "zips_persisted": zips_persisted,
        "hqips_found": len(hqips),
        "nostr_repos_found": len(nostr),
        "total_bips_tracked": summary["total_bips"],
        "total_zips_tracked": summary["total_zips"],
    }
