# SPDX-License-Identifier: MIT
"""
CryptoCompliance -- Verify crypto primitives match Bitcoin standards.

Scans Zenon source code (go-zenon, SDKs) for cryptographic primitives
and verifies they match Bitcoin reference implementations:
- secp256k1 curve usage (not ed25519 or others)
- SHA-256d (double SHA-256) where required
- BIP-32/39/44 key derivation
- Proper entropy sources
- Signature scheme compliance
"""

import json
import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.persistence import connect
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

# Crypto compliance checks
COMPLIANCE_CHECKS = [
    {
        "check_name": "secp256k1_usage",
        "category": "elliptic_curve",
        "expected_standard": "secp256k1 (Bitcoin standard curve)",
        "search_patterns": [
            r"secp256k1",
            r"btcec",
            r"S256\(\)",
        ],
        "violation_patterns": [
            r"ed25519(?!.*//.*ignore)",
            r"curve25519(?!.*//.*ignore)",
            r"P256\(\)",
            r"P384\(\)",
            r"P521\(\)",
        ],
        "file_globs": ["**/*.go", "**/*.dart"],
    },
    {
        "check_name": "sha256d_usage",
        "category": "hash_function",
        "expected_standard": "SHA-256d (double SHA-256) for transaction hashing",
        "search_patterns": [
            r"chainhash\.DoubleHashB",
            r"chainhash\.HashB",
            r"sha256\.Sum256",
            r"crypto\.SHA256",
        ],
        "violation_patterns": [
            r"sha3\.",
            r"keccak",
            r"ripemd(?!.*btc)",
        ],
        "file_globs": ["**/*.go"],
    },
    {
        "check_name": "bip32_derivation",
        "category": "key_derivation",
        "expected_standard": "BIP-32 hierarchical deterministic key derivation",
        "search_patterns": [
            r"hdkeychain",
            r"bip32",
            r"DeriveChild",
            r"m/44'/73'/",
        ],
        "violation_patterns": [],
        "file_globs": ["**/*.go", "**/*.dart", "**/*.ts"],
    },
    {
        "check_name": "bip39_mnemonic",
        "category": "key_derivation",
        "expected_standard": "BIP-39 mnemonic seed phrase generation",
        "search_patterns": [
            r"bip39",
            r"mnemonic",
            r"MnemonicToSeed",
            r"NewMnemonic",
        ],
        "violation_patterns": [],
        "file_globs": ["**/*.go", "**/*.dart", "**/*.ts"],
    },
    {
        "check_name": "entropy_source",
        "category": "randomness",
        "expected_standard": "Cryptographically secure random number generator",
        "search_patterns": [
            r"crypto/rand",
            r"SecureRandom",
            r"crypto\.getRandomValues",
        ],
        "violation_patterns": [
            r"math/rand(?!.*//.*test)",
            r"Random\(\)(?!.*//.*test)",
        ],
        "file_globs": ["**/*.go", "**/*.dart"],
    },
    {
        "check_name": "signature_scheme",
        "category": "signatures",
        "expected_standard": "ECDSA with secp256k1 (Bitcoin-compatible signatures)",
        "search_patterns": [
            r"ecdsa\.Sign",
            r"btcec\.Sign",
            r"RecoverCompact",
        ],
        "violation_patterns": [
            r"ed25519\.Sign",
            r"nacl\.sign",
        ],
        "file_globs": ["**/*.go"],
    },
]


def _find_source_repos() -> list[Path]:
    """Find all Zenon source repositories to scan."""
    repos = []
    search_dirs = [
        ZENON_WORKSPACE / "core",
        ZENON_WORKSPACE / "network",
        ZENON_WORKSPACE / "hypercore-one",
    ]

    for parent in search_dirs:
        if not parent.is_dir():
            continue
        for child in parent.iterdir():
            if child.is_dir() and not child.name.startswith("."):
                repos.append(child)

    return repos


def run_single_check(
    check: dict,
    repos: list[Path],
) -> dict:
    """Run a single compliance check across all repos.

    Returns dict with check results: compliant, findings, violations.
    """
    findings = []
    violations = []

    for repo in repos:
        for glob in check["file_globs"]:
            for source_file in repo.rglob(glob):
                # Skip vendor, test, and generated files
                parts = source_file.parts
                if any(skip in parts for skip in ("vendor", "node_modules", ".git", "testdata")):
                    continue

                try:
                    content = source_file.read_text(encoding="utf-8")
                except (OSError, UnicodeDecodeError):
                    continue

                # Check for expected patterns
                for pattern in check["search_patterns"]:
                    for match in re.finditer(pattern, content):
                        line_num = content[: match.start()].count("\n") + 1
                        findings.append(
                            {
                                "file": str(source_file),
                                "line": line_num,
                                "match": match.group(),
                                "pattern": pattern,
                            }
                        )

                # Check for violation patterns
                for pattern in check["violation_patterns"]:
                    for match in re.finditer(pattern, content):
                        line_num = content[: match.start()].count("\n") + 1
                        violations.append(
                            {
                                "file": str(source_file),
                                "line": line_num,
                                "match": match.group(),
                                "pattern": pattern,
                                "severity": "high" if "key" in check["category"] else "medium",
                            }
                        )

    # Determine compliance
    compliant = len(violations) == 0 and len(findings) > 0

    return {
        "check_name": check["check_name"],
        "category": check["category"],
        "expected_standard": check["expected_standard"],
        "compliant": compliant,
        "findings_count": len(findings),
        "violations_count": len(violations),
        "findings": findings[:20],  # Limit for storage
        "violations": violations[:20],
    }


def persist_check_results(
    results: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist compliance check results to the database."""
    conn = connect(db_path)
    persisted = 0
    try:
        for r in results:
            # Store a summary in compliance_checks
            conn.execute(
                """INSERT INTO compliance_checks
                   (check_name, category, expected_standard,
                    actual_finding, compliant, severity, notes)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    r["check_name"],
                    r["category"],
                    r["expected_standard"],
                    (
                        f"WHAT: {r['check_name']} check found {r['findings_count']} standard matches "
                        f"and {r['violations_count']} violation(s). "
                        f"SO WHAT: {'Compliant with Bitcoin standard ({}).'.format(r['expected_standard']) if r['compliant'] else 'Non-compliant: violations found against {}; could cause cross-chain incompatibility or security weakness.'.format(r['expected_standard'])} "
                        f"NOW WHAT: {'No action needed.' if r['compliant'] else 'Review flagged files and replace non-standard primitives with Bitcoin-compatible equivalents.'}"
                    ),
                    r["compliant"],
                    "info" if r["compliant"] else "high",
                    json.dumps(r["violations"][:5]),
                ),
            )
            persisted += 1

        conn.commit()
    finally:
        conn.close()
    return persisted


def calculate_compliance_score(results: list[dict]) -> float:
    """Calculate overall compliance score from 0-100.

    Each passing check contributes equally. Violations reduce score.
    """
    if not results:
        return 0.0

    total = len(results)
    compliant = sum(1 for r in results if r["compliant"])
    violation_penalty = sum(min(r["violations_count"] * 5, 50) for r in results)

    base_score = (compliant / total) * 100
    return max(0.0, round(base_score - violation_penalty / total, 1))


def run_crypto_compliance_check(*, db_path: str = DEFAULT_DB) -> dict:
    """Run all crypto compliance checks.

    Returns comprehensive compliance status dict.
    """
    repos = _find_source_repos()
    if not repos:
        return {
            "success": True,
            "warning": "No source repositories found to scan.",
            "repos_scanned": 0,
            "results": [],
            "compliance_score": 0.0,
        }

    results = []
    for check in COMPLIANCE_CHECKS:
        result = run_single_check(check, repos)
        results.append(result)

    persisted = persist_check_results(results, db_path=db_path)
    score = calculate_compliance_score(results)

    # Summary
    compliant_checks = sum(1 for r in results if r["compliant"])
    total_violations = sum(r["violations_count"] for r in results)

    return {
        "success": True,
        "repos_scanned": len(repos),
        "checks_run": len(results),
        "checks_passed": compliant_checks,
        "total_violations": total_violations,
        "compliance_score": score,
        "persisted": persisted,
        "results": results,
    }
