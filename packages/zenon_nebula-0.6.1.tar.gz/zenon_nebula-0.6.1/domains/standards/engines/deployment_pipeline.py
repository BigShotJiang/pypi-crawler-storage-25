# SPDX-License-Identifier: MIT
"""
DeploymentPipeline -- Enforce the spec-to-spork deployment lifecycle.

Tracks specs through the mandatory lifecycle stages:
  spec -> review -> implement -> devnet -> testnet -> spork

Detects violations (skipped stages), stalled specs, and pipeline bottlenecks.
"""

import json
import logging
import sqlite3
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.persistence import connect
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

# Mandatory lifecycle stages in order
PIPELINE_STAGES = [
    "spec",
    "review",
    "implement",
    "devnet",
    "testnet",
    "spork",
]

# Stage index map for ordering checks
STAGE_INDEX = {stage: i for i, stage in enumerate(PIPELINE_STAGES)}


def scan_spec_pipeline_status() -> list[dict]:
    """Scan local repos for spec files and determine their pipeline stage.

    Checks developer-commons, go-zenon branches, and devnet configs
    to determine where each spec sits in the pipeline.
    """
    specs = []

    spec_paths = [
        ZENON_WORKSPACE / "core" / "developer-commons",
        ZENON_WORKSPACE / "hypercore-one" / "developer-commons",
    ]

    for spec_root in spec_paths:
        if not spec_root.is_dir():
            continue

        for md_file in spec_root.rglob("*.md"):
            spec_info = _analyze_spec_file(md_file, spec_root)
            if spec_info:
                specs.append(spec_info)

    return specs


def _analyze_spec_file(path: Path, spec_root: Path) -> dict | None:
    """Analyze a spec file to determine its pipeline stage."""
    try:
        content = path.read_text(encoding="utf-8")[:3000]
    except (OSError, UnicodeDecodeError):
        return None

    # Skip non-spec files
    if len(content) < 100:
        return None

    name = path.stem
    relative = str(path.relative_to(spec_root))

    # Determine current stage from content markers
    content_lower = content.lower()
    stage = "spec"  # default

    if any(kw in content_lower for kw in ["spork", "activated", "live on mainnet"]):
        stage = "spork"
    elif any(kw in content_lower for kw in ["testnet", "testing on testnet"]):
        stage = "testnet"
    elif any(kw in content_lower for kw in ["devnet", "testing on devnet"]):
        stage = "devnet"
    elif any(kw in content_lower for kw in ["implemented", "implementation complete"]):
        stage = "implement"
    elif any(kw in content_lower for kw in ["reviewed", "review complete", "approved"]):
        stage = "review"

    # Check for implementation evidence
    has_implementation = _check_implementation_exists(name)

    return {
        "spec_name": name,
        "spec_path": relative,
        "current_stage": stage,
        "stage_index": STAGE_INDEX.get(stage, 0),
        "has_implementation": has_implementation,
    }


def _check_implementation_exists(spec_name: str) -> bool:
    """Check if a spec has corresponding implementation in go-zenon."""
    go_zenon_paths = [
        ZENON_WORKSPACE / "core" / "go-zenon",
        ZENON_WORKSPACE / "network" / "go-zenon",
    ]

    normalized = spec_name.lower().replace("-", "_").replace(" ", "_")

    for go_zenon in go_zenon_paths:
        if not go_zenon.is_dir():
            continue
        # Check embedded contracts
        for subdir in ["vm/embedded/implementation", "vm/embedded/definition"]:
            impl_dir = go_zenon / subdir
            if impl_dir.is_dir():
                for f in impl_dir.glob("*.go"):
                    if normalized in f.stem.lower():
                        return True
    return False


def detect_pipeline_violations(specs: list[dict]) -> list[dict]:
    """Detect specs that have skipped pipeline stages.

    A violation occurs when a spec is at stage N but evidence
    for stage N-1 is missing.
    """
    violations = []

    for spec in specs:
        stage = spec["current_stage"]
        idx = STAGE_INDEX.get(stage, 0)

        # Check for skipped stages
        if idx >= STAGE_INDEX["implement"] and not spec["has_implementation"]:
            violations.append(
                {
                    "spec_name": spec["spec_name"],
                    "violation": "implementation_missing",
                    "claimed_stage": stage,
                    "description": (
                        f"WHAT: Spec '{spec['spec_name']}' claims stage '{stage}' but no Go implementation found. "
                        f"SO WHAT: Spec cannot be at '{stage}' without code in go-zenon; status is inaccurate. "
                        f"NOW WHAT: Either implement the contract in go-zenon or correct the spec's status marker."
                    ),
                }
            )

        if stage == "spork" and spec.get("stage_index", 0) < STAGE_INDEX["testnet"]:
            violations.append(
                {
                    "spec_name": spec["spec_name"],
                    "violation": "skipped_testnet",
                    "claimed_stage": stage,
                    "description": (
                        f"WHAT: Spec '{spec['spec_name']}' reached spork stage without testnet evidence. "
                        f"SO WHAT: Skipping testnet means untested code could activate on mainnet, risking fund loss or consensus failure. "
                        f"NOW WHAT: Deploy to HyperQube testnet and gather test results before any spork activation vote."
                    ),
                }
            )

    return violations


def detect_stalled_specs(
    specs: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> list[dict]:
    """Detect specs that haven't progressed in a long time.

    Compares current stage with previously recorded stage.
    """
    # For now, report specs stuck in early stages
    stalled = []
    for spec in specs:
        if spec["current_stage"] in ("spec", "review"):
            stalled.append(
                {
                    "spec_name": spec["spec_name"],
                    "stage": spec["current_stage"],
                    "description": (
                        f"WHAT: Spec '{spec['spec_name']}' remains in '{spec['current_stage']}' stage. "
                        f"SO WHAT: Stalled specs delay feature delivery and may indicate blocked dependencies or abandoned work. "
                        f"NOW WHAT: Check if spec has open review comments; if not, begin implementation or mark as deferred."
                    ),
                }
            )
    return stalled


def get_pipeline_summary(specs: list[dict]) -> dict:
    """Generate a summary of the pipeline status."""
    stage_counts = dict.fromkeys(PIPELINE_STAGES, 0)
    for spec in specs:
        stage = spec.get("current_stage", "spec")
        if stage in stage_counts:
            stage_counts[stage] += 1

    total = len(specs)
    completed_pct = 0.0
    if total > 0:
        completed_pct = round(stage_counts.get("spork", 0) / total * 100, 1)

    return {
        "total_specs": total,
        "stage_counts": stage_counts,
        "completion_pct": completed_pct,
        "specs_with_implementation": sum(1 for s in specs if s.get("has_implementation")),
    }


def persist_pipeline_status(
    summary: dict,
    violations: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist pipeline status as an evidence entry."""
    conn = connect(db_path)
    try:
        body = json.dumps(
            {
                "summary": summary,
                "violations": violations,
            },
            indent=2,
        )
        cursor = conn.execute(
            """INSERT INTO evidence
               (domain, engine, finding_type, title, body, confidence, source)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                "standards",
                "deployment_pipeline",
                "pipeline_status",
                (
                    f"WHAT: Deployment pipeline has {summary['total_specs']} specs tracked; "
                    f"{summary.get('specs_with_implementation', 0)} have implementations; "
                    f"{len(violations)} pipeline violation(s) detected; "
                    f"{summary.get('completion_pct', 0)}% reached spork stage. "
                    f"SO WHAT: {'Violations mean specs skipped mandatory stages (review/devnet/testnet), risking unvetted code reaching mainnet.' if violations else 'Pipeline is healthy; all specs are following the mandatory lifecycle.'} "
                    f"NOW WHAT: {'Address each violation: ensure missing implementations exist and testnet evidence is gathered before spork activation.' if violations else 'Continue monitoring; focus on advancing specs stuck in early stages.'}"
                ),
                body,
                0.8,
                "filesystem",
            ),
        )
        conn.commit()
        return cursor.lastrowid
    except sqlite3.OperationalError:
        logger.warning("Could not persist pipeline status to evidence table")
        return 0
    finally:
        conn.close()


def run_pipeline_check(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full pipeline check: scan specs, detect violations, report.

    Returns comprehensive pipeline status dict.
    """
    specs = scan_spec_pipeline_status()
    violations = detect_pipeline_violations(specs)
    stalled = detect_stalled_specs(specs, db_path=db_path)
    summary = get_pipeline_summary(specs)

    evidence_id = persist_pipeline_status(summary, violations, db_path=db_path)

    return {
        "success": True,
        "summary": summary,
        "violations": violations,
        "stalled_specs": stalled,
        "specs": specs,
        "evidence_id": evidence_id,
    }
