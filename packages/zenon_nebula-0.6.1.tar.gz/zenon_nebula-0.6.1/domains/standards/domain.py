# SPDX-License-Identifier: MIT
"""
StandardsDomain -- DomainPlugin for BIP/ZIP tracking, deployment pipeline, and crypto compliance.

Provides engines for tracking Bitcoin BIPs relevant to Zenon and Zenon ZIPs,
enforcing the spec-to-spork deployment lifecycle, and verifying crypto
primitives match Bitcoin reference implementations.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class StandardsDomain(DomainPlugin):
    """Standards domain plugin -- BIP/ZIP tracking and crypto compliance."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "standards"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "BIP/ZIP standards tracking, deployment pipeline enforcement "
            "(spec->review->implement->devnet->testnet->spork), and "
            "cryptographic compliance verification against Bitcoin references."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 3

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="bip_zip_tracker",
                description=(
                    "Track Bitcoin BIPs relevant to Zenon and Zenon ZIPs, "
                    "monitor their status and implementation progress."
                ),
                module_path="domains.standards.engines.bip_zip_tracker",
                priority=1,
                tier=1,
                required_apis=["github"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="deployment_pipeline",
                description=(
                    "Enforce the deployment lifecycle: spec -> review -> "
                    "implement -> devnet -> testnet -> spork."
                ),
                module_path="domains.standards.engines.deployment_pipeline",
                priority=2,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="crypto_compliance",
                description=(
                    "Verify crypto primitives in Zenon code match Bitcoin "
                    "standards: secp256k1, SHA-256d, BIP-32/39/44."
                ),
                module_path="domains.standards.engines.crypto_compliance",
                priority=3,
                tier=2,
                required_apis=["filesystem"],
                max_runtime_seconds=180,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="crypto_bitcoin_compliant",
                label="All crypto matches Bitcoin reference implementations",
                description=(
                    "Every cryptographic primitive used in Zenon (secp256k1, "
                    "SHA-256d, key derivation) matches Bitcoin Core reference "
                    "implementations."
                ),
                initial_confidence=0.4,
                publishable_threshold=0.90,
            ),
            HypothesisType(
                type_id="deployment_pipeline_healthy",
                label="Deployment pipeline is healthy",
                description=(
                    "All specs are progressing through the standard "
                    "lifecycle without skipping stages."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="bip_coverage_complete",
                label="Relevant BIP coverage complete",
                description=(
                    "All Bitcoin BIPs relevant to Zenon have been tracked "
                    "and their implementation status is known."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.80,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="full_bip_tracking",
                label="Full BIP/ZIP tracking",
                description=("Track all relevant BIPs and ZIPs with automated status updates."),
                priority=3,
            ),
            AspirationType(
                type_id="zero_pipeline_violations",
                label="Zero pipeline violations",
                description=("No spec should skip stages in the deployment pipeline."),
                priority=2,
                deadline_days=30,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="standards_development_overlap",
                label="Standards-development overlap",
                description=("A BIP/ZIP update affects specs tracked by the development domain."),
                source_domains=["standards", "development"],
                convergence_threshold=0.5,
            ),
            CollisionSignal(
                signal_id="standards_security_overlap",
                label="Standards-security overlap",
                description=(
                    "A crypto compliance finding intersects with a security vulnerability."
                ),
                source_domains=["standards", "security"],
                convergence_threshold=0.5,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="standards",
                section_title="Standards & Compliance",
                metrics=[
                    "bips_tracked",
                    "zips_tracked",
                    "crypto_compliance_score",
                    "pipeline_violations",
                    "specs_in_pipeline",
                ],
                recommendations_prompt=(
                    "Based on standards tracking and crypto compliance, "
                    "what standards work should be prioritized?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "bips_tracked": 0.0,
            "zips_tracked": 0.0,
            "compliance_checks_run": 0.0,
            "pipeline_coverage_pct": 0.0,
        }

    def decide_next_action(self, context: dict) -> dict | None:
        """Decide the highest-value next action given current state."""
        trigger = context.get("trigger_level", "routine")
        stale = context.get("stale_data", [])

        if trigger in ("urgent", "critical"):
            return {
                "action": "check_crypto_compliance",
                "reason": "Urgent trigger -- verify crypto primitives.",
                "priority": 3,
                "engine": "crypto_compliance",
            }

        if "bip_tracking" in stale:
            return {
                "action": "refresh_bip_tracking",
                "reason": "BIP/ZIP tracking data is stale.",
                "priority": 4,
                "engine": "bip_zip_tracker",
            }

        if "deployment_pipeline" in stale:
            return {
                "action": "check_pipeline",
                "reason": "Deployment pipeline status needs refresh.",
                "priority": 5,
                "engine": "deployment_pipeline",
            }

        return {
            "action": "check_crypto_compliance",
            "reason": "Routine crypto compliance check.",
            "priority": 6,
            "engine": "crypto_compliance",
        }

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS bip_tracking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bip_number INTEGER,
    zip_number INTEGER,
    title TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'bip',
    status TEXT DEFAULT 'draft',
    relevance TEXT DEFAULT 'direct',
    zenon_impl_status TEXT DEFAULT 'not_started',
    url TEXT,
    notes TEXT,
    last_checked DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(type, bip_number),
    UNIQUE(type, zip_number)
);

CREATE TABLE IF NOT EXISTS compliance_checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    check_name TEXT NOT NULL,
    category TEXT NOT NULL,
    target_file TEXT,
    expected_standard TEXT,
    actual_finding TEXT,
    compliant BOOLEAN DEFAULT TRUE,
    severity TEXT DEFAULT 'info',
    notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_bip_type
    ON bip_tracking(type);
CREATE INDEX IF NOT EXISTS idx_bip_status
    ON bip_tracking(status);
CREATE INDEX IF NOT EXISTS idx_compliance_category
    ON compliance_checks(category);
CREATE INDEX IF NOT EXISTS idx_compliance_compliant
    ON compliance_checks(compliant);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Standards domain registered with %d engines.",
            len(self.get_engines()),
        )
