# SPDX-License-Identifier: MIT
"""
YieldCalculator -- Calculate real yields from staking and delegation.

For: stakers/delegators.

Queries zenonhub API for reward data and calculates APR for delegation,
staking, and pillar operation. Compares yields across pillars and tracks
yield trends over time. No LLM calls.
"""

import logging
import os
from pathlib import Path

from core.persist_to_db import persist_metric, query_table
from core.zenon_data import EMBEDDED_ADDRESSES, TOKEN_DECIMALS, get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZNN_DECIMALS = 8
QSR_DECIMALS = 8

# Approximate blocks per year for APR calculation
# Zenon produces 1 momentum per ~10 seconds
MOMENTUMS_PER_DAY = 8640
MOMENTUMS_PER_YEAR = MOMENTUMS_PER_DAY * 365

# Protocol emission per momentum (approximate, changes with network)
ZNN_EMISSION_PER_MOMENTUM = 2.0  # ~2 ZNN per momentum to all reward pools
QSR_EMISSION_PER_MOMENTUM = 1.0  # ~1 QSR per momentum

# Fallback ZNN total supply if node does not expose it directly.
_DEFAULT_ZNN_TOTAL_SUPPLY = 11_400_000.0


def _int(value, default: int = 0) -> int:
    """Coerce a value to int, returning ``default`` on failure."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _float(value, default: float = 0.0) -> float:
    """Coerce a value to float, returning ``default`` on failure."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def fetch_pillar_reward_data() -> list[dict]:
    """Return pillar reward-sharing data for every registered pillar.

    Each entry contains ``name``, ``weight``, the two reward-percentage
    fields, and momentum production counts. Returns ``[]`` when the node
    is unreachable.
    """
    rpc = get_zenon_data()
    raw = rpc.get_all_pillars(page=0, count=500)
    return [
        {
            "name": p.get("name", "unknown"),
            "weight": _float(p.get("weight", p.get("delegatedWeight", 0))),
            "give_momentum_reward_pct": _int(p.get("giveMomentumRewardPercentage", 0)),
            "give_delegate_reward_pct": _int(p.get("giveDelegateRewardPercentage", 0)),
            "produced_momentums": _int(p.get("producedMomentums", 0)),
            "expected_momentums": _int(p.get("expectedMomentums", 0)),
        }
        for p in raw
    ]


def fetch_network_stats() -> dict | None:
    """Return aggregate network totals used for yield math.

    Reconstructed from multiple RPC calls since there is no single
    aggregate endpoint. Returns ``None`` when the node is unreachable.
    """
    rpc = get_zenon_data()
    if not rpc.is_reachable():
        return None

    pillars = rpc.get_all_pillars(page=0, count=500)
    total_delegated_raw = 0
    for pillar in pillars:
        total_delegated_raw += _int(pillar.get("weight", pillar.get("delegatedWeight", 0)))

    stake_balance = rpc.get_balance(EMBEDDED_ADDRESSES["stake"])
    try:
        znn_supply = float(os.environ.get("ZNN_TOTAL_SUPPLY", _DEFAULT_ZNN_TOTAL_SUPPLY))
    except ValueError:
        znn_supply = _DEFAULT_ZNN_TOTAL_SUPPLY

    return {
        "znn_supply": znn_supply,
        "qsr_supply": 0.0,
        "total_staked": stake_balance["znn"] / TOKEN_DECIMALS,
        "total_delegated": total_delegated_raw / TOKEN_DECIMALS,
        "pillar_count": len(pillars),
    }


# -- Yield Calculations --


def calculate_delegation_yields(
    pillars: list[dict],
    total_delegated: float,
) -> list[dict]:
    """Calculate estimated delegation APR for each pillar.

    Delegation rewards depend on:
    - Pillar's share of total delegation weight
    - Pillar's giveDelegateRewardPercentage
    - Total delegation reward pool

    Returns list of pillars with estimated delegation APR.
    """
    if not pillars or total_delegated <= 0:
        return []

    # Daily delegation reward pool (approximate)
    # ~50% of ZNN emission goes to pillar rewards, of which delegators
    # receive the giveDelegateRewardPercentage portion
    daily_pillar_reward_pool = ZNN_EMISSION_PER_MOMENTUM * MOMENTUMS_PER_DAY * 0.5
    total_weight = sum(p["weight"] for p in pillars)
    if total_weight <= 0:
        return []

    results = []
    for p in pillars:
        weight = p["weight"]
        if weight <= 0:
            results.append(
                {
                    "name": p["name"],
                    "delegation_apr_pct": 0.0,
                    "give_delegate_reward_pct": p["give_delegate_reward_pct"],
                    "weight": weight,
                    "note": "zero delegation weight",
                }
            )
            continue

        # Pillar's share of the daily reward pool
        pillar_daily_reward = daily_pillar_reward_pool * (weight / total_weight)

        # Amount shared with delegators
        delegate_share = p["give_delegate_reward_pct"] / 100.0
        daily_to_delegators = pillar_daily_reward * delegate_share

        # APR = (daily_reward * 365) / staked_amount * 100
        annual_to_delegators = daily_to_delegators * 365

        # Weight is in raw units; convert to ZNN for APR calc
        weight_znn = weight / (10**ZNN_DECIMALS) if weight > 1e6 else weight
        if weight_znn <= 0:
            weight_znn = 1

        apr = (annual_to_delegators / weight_znn) * 100

        results.append(
            {
                "name": p["name"],
                "delegation_apr_pct": round(apr, 2),
                "give_delegate_reward_pct": p["give_delegate_reward_pct"],
                "weight": weight,
            }
        )

    return sorted(results, key=lambda r: r["delegation_apr_pct"], reverse=True)


def calculate_staking_yield(
    total_staked: float,
    znn_supply: float,
) -> dict:
    """Calculate estimated staking APR.

    Staking rewards come from QSR emission distributed to stakers
    proportional to their ZNN staked amount and lock duration.
    """
    if total_staked <= 0 or znn_supply <= 0:
        return {"staking_apr_pct": 0.0, "note": "insufficient data"}

    # QSR staking rewards: ~50% of QSR emission goes to stakers
    daily_staking_rewards_qsr = QSR_EMISSION_PER_MOMENTUM * MOMENTUMS_PER_DAY * 0.5
    annual_staking_rewards_qsr = daily_staking_rewards_qsr * 365

    # APR in QSR terms (per ZNN staked)
    qsr_apr = (annual_staking_rewards_qsr / total_staked) * 100

    return {
        "staking_apr_qsr_pct": round(qsr_apr, 2),
        "total_staked_znn": round(total_staked, 2),
        "daily_rewards_qsr": round(daily_staking_rewards_qsr, 2),
        "note": "APR denominated in QSR per ZNN staked",
    }


def calculate_pillar_yield(
    pillar_count: int,
    znn_supply: float,
) -> dict:
    """Calculate estimated pillar operation yield.

    Pillar operators receive momentum rewards and voting rewards.
    Requires 15,000 ZNN collateral.
    """
    if pillar_count <= 0:
        return {"pillar_apr_pct": 0.0, "note": "no pillar data"}

    pillar_collateral_znn = 15_000.0

    # Momentum rewards: ~50% of ZNN emission split among pillars
    daily_momentum_pool = ZNN_EMISSION_PER_MOMENTUM * MOMENTUMS_PER_DAY * 0.5
    daily_per_pillar = daily_momentum_pool / pillar_count
    annual_per_pillar = daily_per_pillar * 365

    # APR on collateral
    apr = (annual_per_pillar / pillar_collateral_znn) * 100

    return {
        "pillar_apr_pct": round(apr, 2),
        "annual_reward_znn": round(annual_per_pillar, 2),
        "daily_reward_znn": round(daily_per_pillar, 2),
        "pillar_count": pillar_count,
        "collateral_znn": pillar_collateral_znn,
    }


def build_yield_comparison(delegation_yields: list[dict]) -> dict:
    """Build yield comparison summary across pillars."""
    if not delegation_yields:
        return {
            "avg_apr": 0.0,
            "max_apr": 0.0,
            "min_apr": 0.0,
            "top_5": [],
            "bottom_5": [],
        }

    aprs = [p["delegation_apr_pct"] for p in delegation_yields if p["delegation_apr_pct"] > 0]
    if not aprs:
        return {
            "avg_apr": 0.0,
            "max_apr": 0.0,
            "min_apr": 0.0,
            "top_5": [],
            "bottom_5": [],
        }

    return {
        "avg_apr": round(sum(aprs) / len(aprs), 2),
        "max_apr": round(max(aprs), 2),
        "min_apr": round(min(aprs), 2),
        "top_5": [
            {"name": p["name"], "apr": p["delegation_apr_pct"]} for p in delegation_yields[:5]
        ],
        "bottom_5": [
            {"name": p["name"], "apr": p["delegation_apr_pct"]}
            for p in delegation_yields[-5:]
            if p["delegation_apr_pct"] > 0
        ],
        "pillars_with_yields": len(aprs),
    }


# -- Persistence --


def persist_yield_snapshot(
    delegation_comparison: dict,
    staking_yield: dict,
    pillar_yield: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist yield data to the database."""
    return persist_metric(
        db_path=db_path,
        table="yield_snapshots",
        data={
            "avg_delegation_apr": delegation_comparison.get("avg_apr", 0),
            "max_delegation_apr": delegation_comparison.get("max_apr", 0),
            "min_delegation_apr": delegation_comparison.get("min_apr", 0),
            "staking_apr_qsr": staking_yield.get("staking_apr_qsr_pct", 0),
            "pillar_apr": pillar_yield.get("pillar_apr_pct", 0),
            "pillar_count": pillar_yield.get("pillar_count", 0),
        },
    )


def detect_yield_trend(*, db_path: str = DEFAULT_DB, window: int = 10) -> dict:
    """Detect delegation yield trend over recent snapshots."""
    rows = query_table(
        db_path=db_path,
        table="yield_snapshots",
        order_by="timestamp DESC",
        limit=window,
    )

    if len(rows) < 2:
        return {"trend": "insufficient_data", "data_points": len(rows)}

    aprs = [r["avg_delegation_apr"] or 0.0 for r in reversed(rows)]
    n = len(aprs)
    x_mean = (n - 1) / 2
    y_mean = sum(aprs) / n
    num = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(aprs))
    den = sum((i - x_mean) ** 2 for i in range(n))
    slope = num / den if den else 0.0

    if slope > 0.1:
        trend = "increasing"
    elif slope < -0.1:
        trend = "decreasing"
    else:
        trend = "stable"

    return {
        "trend": trend,
        "slope": round(slope, 4),
        "latest_avg_apr": aprs[-1],
        "data_points": n,
    }


# -- Finding Builder --


def _build_yield_finding(
    delegation_comparison: dict,
    staking_yield: dict,
    pillar_yield: dict,
    trend: dict,
) -> str:
    """Build actionable finding for yield analysis.

    Answers WHAT / SO WHAT / NOW WHAT.
    """
    avg_apr = delegation_comparison.get("avg_apr", 0)
    max_apr = delegation_comparison.get("max_apr", 0)
    min_apr = delegation_comparison.get("min_apr", 0)
    staking_apr = staking_yield.get("staking_apr_qsr_pct", 0)
    pillar_apr = pillar_yield.get("pillar_apr_pct", 0)
    trend_dir = trend.get("trend", "unknown")

    top_5 = delegation_comparison.get("top_5", [])
    top_name = top_5[0]["name"] if top_5 else "N/A"

    # WHAT
    what = (
        f"Average delegation APR: {avg_apr:.1f}%, "
        f"top pillar ({top_name}) pays {max_apr:.1f}%, "
        f"bottom pays {min_apr:.1f}%. "
        f"Staking APR (QSR): {staking_apr:.1f}%. "
        f"Pillar operation APR: {pillar_apr:.1f}%."
    )

    # SO WHAT
    so_what_parts = []

    if max_apr > avg_apr * 1.5:
        diff_pct = round((max_apr - avg_apr) / avg_apr * 100) if avg_apr > 0 else 0
        so_what_parts.append(
            f"Delegating to top-5 pillars yields {diff_pct}% more than average. "
            f"Significant yield dispersion across pillars."
        )

    if avg_apr < 3:
        so_what_parts.append(
            f"Average delegation yield ({avg_apr:.1f}%) is low — "
            f"may not attract new delegators vs DeFi alternatives."
        )
    elif avg_apr > 10:
        so_what_parts.append(
            f"Average delegation yield ({avg_apr:.1f}%) is competitive — "
            f"attractive for passive ZNN holders."
        )

    if trend_dir == "decreasing":
        so_what_parts.append(
            "Yields are declining — likely due to increasing delegation "
            "competition or emission schedule changes."
        )
    elif trend_dir == "increasing":
        so_what_parts.append(
            "Yields are increasing — possibly due to delegators leaving or emission adjustments."
        )

    so_what = (
        " ".join(so_what_parts)
        if so_what_parts
        else ("Yield metrics are within expected parameters.")
    )

    # NOW WHAT
    now_what_parts = []

    if max_apr > avg_apr * 1.3 and top_5:
        names = ", ".join(p["name"] for p in top_5[:3])
        now_what_parts.append(f"Consider redelegating to higher-performing pillars: {names}.")

    if staking_apr > avg_apr:
        now_what_parts.append(
            f"Staking ({staking_apr:.1f}% QSR) outperforms average "
            f"delegation ({avg_apr:.1f}% ZNN) — consider staking for "
            f"QSR accumulation."
        )

    if not now_what_parts:
        now_what_parts.append(
            "Monitor yields across cycles. Redelegate if pillar reward sharing changes."
        )

    now_what = " ".join(now_what_parts)

    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"


# -- Main Entry Point --


def run_yield_calculator(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full yield analysis: fetch, calculate, persist findings.

    Returns comprehensive yield status dict.
    """
    from core.persist_to_db import persist_finding

    pillars = fetch_pillar_reward_data()
    stats = fetch_network_stats()

    if not pillars or not stats:
        persist_finding(
            db_path=db_path,
            domain="economics",
            engine="yield_calculator",
            evidence_type="yield_error",
            finding=(
                "WHAT: Failed to fetch pillar or network data. "
                "SO WHAT: Cannot calculate yields — delegators and stakers "
                "lack current return data. "
                "NOW WHAT: Check ZENON_PUBLIC_RPC connectivity. Retry next cycle."
            ),
            confidence=0.5,
            source_repo="zenon_rpc",
        )
        return {
            "success": False,
            "error": "Failed to fetch pillar or network data.",
        }

    total_delegated = stats.get("total_delegated", 0)
    total_staked = stats.get("total_staked", 0)
    znn_supply = stats.get("znn_supply", 0)
    pillar_count = stats.get("pillar_count", 0)

    delegation_yields = calculate_delegation_yields(pillars, total_delegated)
    delegation_comparison = build_yield_comparison(delegation_yields)
    staking_yield = calculate_staking_yield(total_staked, znn_supply)
    pillar_yield = calculate_pillar_yield(pillar_count, znn_supply)

    snapshot_id = persist_yield_snapshot(
        delegation_comparison,
        staking_yield,
        pillar_yield,
        db_path=db_path,
    )

    trend = detect_yield_trend(db_path=db_path)

    finding_text = _build_yield_finding(
        delegation_comparison,
        staking_yield,
        pillar_yield,
        trend,
    )

    persist_finding(
        db_path=db_path,
        domain="economics",
        engine="yield_calculator",
        evidence_type="yield_analysis",
        finding=finding_text,
        confidence=0.80,
        raw_data={
            "delegation_comparison": delegation_comparison,
            "staking_yield": staking_yield,
            "pillar_yield": pillar_yield,
            "trend": trend,
        },
        source_repo="zenonhub_api",
    )

    return {
        "success": True,
        "delegation_comparison": delegation_comparison,
        "staking_yield": staking_yield,
        "pillar_yield": pillar_yield,
        "trend": trend,
        "snapshot_id": snapshot_id,
        "finding": finding_text,
    }
