# SPDX-License-Identifier: MIT
"""
SupplyTracker -- Track ZNN/QSR emission rate, burn rate, and circulating supply.

Queries zenonhub API for on-chain supply data, calculates emission and burn
rates from historical snapshots, and persists supply metrics.
"""

import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persist_to_db import persist_metric, query_table
from core.zenon_data import TOKEN_DECIMALS, ZTS_QSR, ZTS_ZNN, get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZNN_DECIMALS = 8
QSR_DECIMALS = 8

# Known emission parameters (from Zenon protocol)
# ZNN: 4320 ZNN/day (3 ZNN/momentum * 1440 momentums/day)
# QSR: 5000 QSR/day (approximate, from staking)
EXPECTED_ZNN_EMISSION_DAILY = 4320.0
EXPECTED_QSR_EMISSION_DAILY = 5000.0

# Well-known null/burn address on NoM. Funds sent here are irrecoverable.
NULL_BURN_ADDRESS = "z1qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqsggv2f"


def fetch_token_supply() -> dict | None:
    """Return ``{znn_total_supply, qsr_total_supply}`` in human units.

    Uses ``embedded.token.getByZts`` for both ZNN and QSR. Returns
    ``None`` when the node is unreachable.
    """
    rpc = get_zenon_data()
    znn_info = rpc.get_token_by_zts(ZTS_ZNN)
    qsr_info = rpc.get_token_by_zts(ZTS_QSR)
    if not znn_info and not qsr_info:
        return None
    znn_supply = 0.0
    qsr_supply = 0.0
    if isinstance(znn_info, dict):
        try:
            znn_supply = float(znn_info.get("totalSupply", 0)) / TOKEN_DECIMALS
        except (TypeError, ValueError):
            znn_supply = 0.0
    if isinstance(qsr_info, dict):
        try:
            qsr_supply = float(qsr_info.get("totalSupply", 0)) / TOKEN_DECIMALS
        except (TypeError, ValueError):
            qsr_supply = 0.0
    return {
        "znn_total_supply": znn_supply,
        "qsr_total_supply": qsr_supply,
    }


def fetch_burn_address_balance() -> dict:
    """Return ZNN/QSR locked at the known null burn address.

    These tokens are provably unspendable, which makes them equivalent to
    burned supply for deflation accounting. Returns zeros when the node is
    unreachable.
    """
    rpc = get_zenon_data()
    balance = rpc.get_balance(NULL_BURN_ADDRESS)
    return {
        "burned_znn": balance.get("znn", 0) / TOKEN_DECIMALS,
        "burned_qsr": balance.get("qsr", 0) / TOKEN_DECIMALS,
    }


def calculate_rates(*, db_path: str = DEFAULT_DB, window_days: int = 7) -> dict:
    """Calculate daily emission and burn rates from historical snapshots.

    Compares supply changes over the specified window.
    """
    cutoff = (datetime.now(timezone.utc) - timedelta(days=window_days)).isoformat()

    rows = query_table(
        db_path=db_path,
        table="supply_snapshots",
        where="timestamp >= ?",
        params=(cutoff,),
        order_by="timestamp ASC",
        limit=0,
    )

    if len(rows) < 2:
        return {
            "znn_emission_daily": EXPECTED_ZNN_EMISSION_DAILY,
            "znn_burn_daily": 0.0,
            "qsr_emission_daily": EXPECTED_QSR_EMISSION_DAILY,
            "qsr_burn_daily": 0.0,
            "data_points": len(rows),
            "source": "protocol_default",
        }

    first = rows[0]
    last = rows[-1]
    t0 = datetime.fromisoformat(first["timestamp"].replace("Z", "+00:00"))
    t1 = datetime.fromisoformat(last["timestamp"].replace("Z", "+00:00"))
    days = max((t1 - t0).total_seconds() / 86400, 1)

    znn_supply_delta = (last["znn_total_supply"] or 0) - (first["znn_total_supply"] or 0)
    qsr_supply_delta = (last["qsr_total_supply"] or 0) - (first["qsr_total_supply"] or 0)

    return {
        "znn_emission_daily": max(znn_supply_delta / days, 0),
        "znn_burn_daily": max(-znn_supply_delta / days, 0) if znn_supply_delta < 0 else 0.0,
        "qsr_emission_daily": max(qsr_supply_delta / days, 0),
        "qsr_burn_daily": max(-qsr_supply_delta / days, 0) if qsr_supply_delta < 0 else 0.0,
        "data_points": len(rows),
        "source": "calculated",
    }


def persist_supply_snapshot(
    supply: dict,
    rates: dict,
    burned: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist a supply snapshot to the database."""
    znn_total = supply.get("znn_total_supply", 0)
    qsr_total = supply.get("qsr_total_supply", 0)
    znn_circulating = znn_total - burned.get("burned_znn", 0)
    qsr_circulating = qsr_total - burned.get("burned_qsr", 0)

    return persist_metric(
        db_path=db_path,
        table="supply_snapshots",
        data={
            "znn_total_supply": znn_total,
            "znn_circulating": znn_circulating,
            "znn_emission_daily": rates.get("znn_emission_daily", 0),
            "znn_burn_daily": rates.get("znn_burn_daily", 0),
            "qsr_total_supply": qsr_total,
            "qsr_circulating": qsr_circulating,
            "qsr_emission_daily": rates.get("qsr_emission_daily", 0),
            "qsr_burn_daily": rates.get("qsr_burn_daily", 0),
        },
    )


def get_supply_history(
    *,
    db_path: str = DEFAULT_DB,
    limit: int = 30,
) -> list[dict]:
    """Get recent supply snapshots for trend analysis."""
    return query_table(
        db_path=db_path,
        table="supply_snapshots",
        order_by="timestamp DESC",
        limit=limit,
    )


def is_deflationary(*, db_path: str = DEFAULT_DB) -> dict:
    """Check if ZNN is currently deflationary (burn > emission).

    Returns analysis dict with boolean and rates.
    """
    rates = calculate_rates(db_path=db_path)
    znn_net = rates["znn_emission_daily"] - rates["znn_burn_daily"]
    qsr_net = rates["qsr_emission_daily"] - rates["qsr_burn_daily"]

    return {
        "znn_deflationary": znn_net < 0,
        "qsr_deflationary": qsr_net < 0,
        "znn_net_daily": round(znn_net, 2),
        "qsr_net_daily": round(qsr_net, 2),
        "znn_emission_daily": rates["znn_emission_daily"],
        "znn_burn_daily": rates["znn_burn_daily"],
    }


def run_supply_check(*, db_path: str = DEFAULT_DB) -> dict:
    """Run a full supply check: fetch data, calculate rates, persist.

    Returns comprehensive supply status dict.
    """
    supply = fetch_token_supply()
    if supply is None:
        return {
            "success": False,
            "error": "Failed to fetch token supply from API.",
        }

    burned = fetch_burn_address_balance()
    rates = calculate_rates(db_path=db_path)

    snapshot_id = persist_supply_snapshot(supply, rates, burned, db_path=db_path)

    deflationary = is_deflationary(db_path=db_path)

    # Persist actionable finding
    try:
        from core.persist_to_db import ensure_schema, persist_finding

        ensure_schema(db_path)

        znn_total = supply.get("znn_total_supply", 0)
        znn_circ = znn_total - burned["burned_znn"]
        znn_net = deflationary["znn_net_daily"]
        burn_pct = (burned["burned_znn"] / max(znn_total, 1)) * 100

        if deflationary["znn_deflationary"]:
            impact = f"ZNN is deflationary (net {znn_net:+,.0f}/day). Supply shrinking increases scarcity."
            action = "Deflationary trend is bullish for holders. Track if burn rate is sustainable or one-time event."
        else:
            impact = f"ZNN is inflationary (net +{znn_net:,.0f}/day). New supply dilutes existing holders."
            action = "Monitor burn mechanisms; if net emission stays high, advocate for increased burn or reduced rewards."

        persist_finding(
            db_path=db_path,
            domain="economics",
            engine="supply_tracker",
            evidence_type="supply_snapshot",
            finding=(
                f"WHAT: ZNN total supply {znn_total:,.0f}, circulating {znn_circ:,.0f}, "
                f"burned {burned['burned_znn']:,.0f} ({burn_pct:.1f}%). "
                f"Emission {rates.get('znn_emission_daily', 0):,.0f}/day, burn {rates.get('znn_burn_daily', 0):,.0f}/day. "
                f"SO WHAT: {impact} "
                f"NOW WHAT: {action}"
            ),
            confidence=0.75,
            source_repo="zenon_rpc",
            raw_data={
                "znn_total": znn_total,
                "znn_circulating": znn_circ,
                "burned_znn": burned["burned_znn"],
                "deflationary": deflationary,
            },
        )
    except Exception as exc:
        logger.debug("Supply finding persistence failed: %s", exc)

    return {
        "success": True,
        "znn_total_supply": supply.get("znn_total_supply", 0),
        "qsr_total_supply": supply.get("qsr_total_supply", 0),
        "znn_circulating": supply.get("znn_total_supply", 0) - burned["burned_znn"],
        "qsr_circulating": supply.get("qsr_total_supply", 0) - burned["burned_qsr"],
        "burned": burned,
        "rates": rates,
        "deflationary": deflationary,
        "snapshot_id": snapshot_id,
    }
