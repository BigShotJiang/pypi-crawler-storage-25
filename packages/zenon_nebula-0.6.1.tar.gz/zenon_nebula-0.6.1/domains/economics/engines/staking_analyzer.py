# SPDX-License-Identifier: MIT
"""
StakingAnalyzer -- Analyze staking ratio, delegation distribution, and lock durations.

Queries zenonhub API for staking and delegation data, calculates ratios,
measures delegation concentration, and tracks lock duration distribution.
"""

import logging
from pathlib import Path

from core.persist_to_db import persist_metric, query_table
from core.zenon_data import EMBEDDED_ADDRESSES, TOKEN_DECIMALS, get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZNN_DECIMALS = 8

# Published total ZNN supply fallback used when the node does not expose
# it. Zenon's total supply is governed by emission schedules; this fallback
# is used purely to compute ratios during offline/degraded conditions. Set
# via ``ZNN_TOTAL_SUPPLY`` to override.
_DEFAULT_TOTAL_SUPPLY_ZNN = 11_400_000.0


def fetch_pillar_delegation_data() -> list[dict]:
    """Return pillar delegation data as ``[{name, weight, produced_momentums}]``.

    Uses :mod:`core.zenon_data` HTTP JSON-RPC. Returns an empty list on
    failure so callers can surface a clean ``no data`` state.
    """
    rpc = get_zenon_data()
    raw = rpc.get_all_pillars(page=0, count=500)
    pillars: list[dict] = []
    for p in raw:
        try:
            weight = float(p.get("weight", p.get("delegatedWeight", 0)))
        except (TypeError, ValueError):
            weight = 0.0
        try:
            produced = int(p.get("producedMomentums", 0))
        except (TypeError, ValueError):
            produced = 0
        pillars.append(
            {
                "name": p.get("name", "unknown"),
                "weight": weight,
                "produced_momentums": produced,
            }
        )
    return pillars


def fetch_staking_info() -> dict | None:
    """Return network staking totals.

    Combines multiple RPC sources to derive:
        * ``total_staked``    (ZNN locked in the stake contract)
        * ``total_delegated`` (ZNN delegated to pillars, summed)
        * ``znn_supply``      (approximate total ZNN supply)

    The node does not expose a single aggregate endpoint, so totals are
    reconstructed. Returns ``None`` when the node is unreachable.
    """
    rpc = get_zenon_data()
    if not rpc.is_reachable():
        return None

    # Delegated total = sum of pillar weights.
    pillars = rpc.get_all_pillars(page=0, count=500)
    total_weight_raw = 0
    for p in pillars:
        try:
            total_weight_raw += int(p.get("weight", p.get("delegatedWeight", 0)))
        except (TypeError, ValueError):
            continue
    total_delegated = total_weight_raw / TOKEN_DECIMALS

    # Staked total via the stake contract balance.
    stake_balance = rpc.get_balance(EMBEDDED_ADDRESSES["stake"])
    total_staked = stake_balance.get("znn", 0) / TOKEN_DECIMALS

    # Supply is not on-chain queryable at the token level for ZNN from a
    # single RPC call; use a published reference value (overridable).
    import os

    try:
        znn_supply = float(os.environ.get("ZNN_TOTAL_SUPPLY", _DEFAULT_TOTAL_SUPPLY_ZNN))
    except ValueError:
        znn_supply = _DEFAULT_TOTAL_SUPPLY_ZNN

    return {
        "total_staked": total_staked,
        "total_delegated": total_delegated,
        "znn_supply": znn_supply,
    }


def calculate_staking_ratio(staking_info: dict) -> dict:
    """Calculate staking and delegation ratios.

    Returns dict with staking_ratio, delegation_ratio percentages.
    """
    supply = staking_info.get("znn_supply", 1)
    if supply <= 0:
        supply = 1

    staked = staking_info.get("total_staked", 0)
    delegated = staking_info.get("total_delegated", 0)

    return {
        "staking_ratio": round((staked / supply) * 100, 2),
        "delegation_ratio": round((delegated / supply) * 100, 2),
        "combined_ratio": round(((staked + delegated) / supply) * 100, 2),
        "total_staked": staked,
        "total_delegated": delegated,
        "total_supply": supply,
    }


def calculate_delegation_concentration(pillars: list[dict]) -> dict:
    """Calculate delegation concentration metrics.

    Returns HHI, Gini, top-5 share, and delegation breakdown.
    """
    if not pillars:
        return {"hhi": 1.0, "gini": 0.0, "top_5_share": 0.0}

    total_weight = sum(p["weight"] for p in pillars)
    if total_weight == 0:
        n = len(pillars)
        return {"hhi": 1 / n if n else 1.0, "gini": 0.0, "top_5_share": 0.0}

    shares = sorted(
        [p["weight"] / total_weight for p in pillars],
        reverse=True,
    )

    # HHI
    hhi = sum(s**2 for s in shares)

    # Top-5 share
    top_5 = sum(shares[:5]) if len(shares) >= 5 else sum(shares)

    # Gini
    n = len(shares)
    sorted_asc = sorted(shares)
    gini_num = sum((2 * i - n - 1) * s for i, s in enumerate(sorted_asc, 1))
    gini = abs(gini_num / (n * sum(sorted_asc))) if sum(sorted_asc) > 0 else 0

    # Top pillars by delegation
    sorted_pillars = sorted(pillars, key=lambda p: p["weight"], reverse=True)
    top_10 = [
        {
            "name": p["name"],
            "weight": p["weight"],
            "share_pct": round(p["weight"] / total_weight * 100, 2),
        }
        for p in sorted_pillars[:10]
    ]

    return {
        "hhi": round(hhi, 6),
        "gini": round(gini, 4),
        "top_5_share": round(top_5 * 100, 2),
        "top_10_pillars": top_10,
        "total_pillars": n,
    }


def persist_staking_snapshot(
    ratios: dict,
    concentration: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist staking metrics to the database."""
    return persist_metric(
        db_path=db_path,
        table="staking_metrics",
        data={
            "total_staked_znn": ratios.get("total_staked", 0),
            "total_delegated_znn": ratios.get("total_delegated", 0),
            "staking_ratio": ratios.get("combined_ratio", 0),
            "unique_stakers": 0,  # not directly available from API
            "unique_delegators": concentration.get("total_pillars", 0),
            "delegation_hhi": concentration.get("hhi", 0),
        },
    )


def get_staking_history(
    *,
    db_path: str = DEFAULT_DB,
    limit: int = 30,
) -> list[dict]:
    """Get recent staking metric snapshots."""
    return query_table(
        db_path=db_path,
        table="staking_metrics",
        order_by="timestamp DESC",
        limit=limit,
    )


def detect_staking_trend(*, db_path: str = DEFAULT_DB, window: int = 10) -> dict:
    """Detect staking ratio trend over recent snapshots."""
    history = get_staking_history(db_path=db_path, limit=window)
    if len(history) < 2:
        return {"trend": "insufficient_data", "data_points": len(history)}

    ratios = [h["staking_ratio"] or 0.0 for h in reversed(history)]
    n = len(ratios)
    x_mean = (n - 1) / 2
    y_mean = sum(ratios) / n
    num = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(ratios))
    den = sum((i - x_mean) ** 2 for i in range(n))
    slope = num / den if den else 0.0

    if slope > 0.1:
        trend = "increasing"
    elif slope < -0.1:
        trend = "decreasing"
    else:
        trend = "stable"

    return {
        "trend": trend,
        "slope": round(slope, 4),
        "latest_ratio": ratios[-1],
        "data_points": n,
    }


def _build_staking_finding(ratios: dict, concentration: dict, trend: dict) -> str:
    """Build actionable finding for staking analysis.

    Answers WHAT / SO WHAT / NOW WHAT.
    """
    staking_pct = ratios.get("staking_ratio", 0)
    delegation_pct = ratios.get("delegation_ratio", 0)
    combined_pct = ratios.get("combined_ratio", 0)
    top_5_share = concentration.get("top_5_share", 0)
    gini = concentration.get("gini", 0)
    hhi = concentration.get("hhi", 0)
    trend_dir = trend.get("trend", "unknown")
    slope = trend.get("slope", 0)

    # WHAT: factual state
    what = (
        f"Staking ratio: {staking_pct:.1f}%, delegation ratio: "
        f"{delegation_pct:.1f}% (combined {combined_pct:.1f}% of supply "
        f"locked). Delegation concentration: top 5 pillars hold "
        f"{top_5_share:.1f}% of delegated weight (Gini={gini:.3f}, "
        f"HHI={hhi:.4f}). Trend: {trend_dir} "
        f"(slope={slope:+.4f}/snapshot)."
    )

    # SO WHAT: risk assessment
    so_what_parts = []

    if combined_pct < 30:
        so_what_parts.append(
            "Combined lock-up below 30% — low network security. "
            "Insufficient economic stake makes the network vulnerable "
            "to governance attacks (cheap to acquire voting power)."
        )
    elif combined_pct < 50:
        so_what_parts.append(
            f"Combined lock-up at {combined_pct:.0f}% — moderate. "
            f"Network security is adequate but could be stronger."
        )
    else:
        so_what_parts.append(
            f"Combined lock-up at {combined_pct:.0f}% — healthy. "
            f"Strong economic commitment to the network."
        )

    if top_5_share > 50:
        so_what_parts.append(
            f"Delegation is HIGHLY concentrated — top 5 pillars control "
            f"{top_5_share:.0f}%. A coordinated action by 5 entities "
            f"could dominate governance decisions."
        )
    elif top_5_share > 33:
        so_what_parts.append(
            f"Delegation moderately concentrated. Top 5 pillars hold "
            f"{top_5_share:.0f}% — approaching governance influence "
            f"threshold."
        )

    if trend_dir == "decreasing" and slope < -0.5:
        so_what_parts.append(
            f"Staking ratio declining at {slope:.2f}/snapshot. "
            f"If trend continues, network security weakens over time."
        )
    elif trend_dir == "increasing" and slope > 0.5:
        so_what_parts.append(
            "Staking ratio increasing — positive signal for "
            "network security and participant confidence."
        )

    so_what = (
        " ".join(so_what_parts)
        if so_what_parts
        else ("Network staking metrics are within normal parameters.")
    )

    # NOW WHAT: specific actions
    now_what_parts = []

    if combined_pct < 30:
        now_what_parts.append(
            "Action: investigate why lock-up is low — are there "
            "better yield opportunities elsewhere? Consider proposing "
            "staking incentive adjustments via governance."
        )
    if top_5_share > 50:
        now_what_parts.append(
            "Action: monitor for further concentration. Consider "
            "community education about delegation diversity to "
            "reduce single-point-of-failure risk."
        )
    if trend_dir == "decreasing" and slope < -0.5:
        current = ratios.get("staking_ratio", 0)
        if slope != 0:
            snapshots_to_threshold = abs((current - 30) / slope)
            now_what_parts.append(
                f"Action: at current rate, staking drops below 30% "
                f"in ~{snapshots_to_threshold:.0f} snapshots. Monitor "
                f"closely and prepare governance proposal if needed."
            )

    if not now_what_parts:
        now_what_parts.append(
            "Action: no immediate action needed. Continue monitoring. "
            "Next check will detect trend changes."
        )

    now_what = " ".join(now_what_parts)

    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"


def _build_concentration_finding(concentration: dict, pillars: list[dict]) -> str:
    """Build actionable finding for delegation concentration."""
    top_10 = concentration.get("top_10_pillars", [])
    total_pillars = concentration.get("total_pillars", 0)
    top_5_share = concentration.get("top_5_share", 0)

    if not top_10:
        return (
            "WHAT: No pillar data available. "
            "SO WHAT: Cannot assess delegation health. "
            "NOW WHAT: Check ZENON_PUBLIC_RPC connectivity."
        )

    # Identify inactive pillars (0 produced momentums)
    inactive_names = [p["name"] for p in pillars if p.get("produced_momentums", 0) == 0]

    top_names = ", ".join(f"{p['name']} ({p.get('share_pct', 0):.1f}%)" for p in top_10[:5])

    what = (
        f"{total_pillars} pillars active. Top 5 by delegation: "
        f"{top_names}. Combined top-5 share: {top_5_share:.1f}%."
    )

    so_what_parts = []
    if len(inactive_names) > 0:
        so_what_parts.append(
            f"{len(inactive_names)} pillar(s) have produced 0 momentums "
            f"— they are consuming delegation weight without contributing "
            f"to consensus."
        )
    if top_5_share > 40:
        so_what_parts.append(
            f"High concentration: {top_5_share:.0f}% in top 5 creates "
            f"governance centralization risk."
        )

    so_what = (
        " ".join(so_what_parts)
        if so_what_parts
        else ("Delegation distribution is within acceptable parameters.")
    )

    now_what_parts = []
    if inactive_names:
        sample = ", ".join(inactive_names[:3])
        more = f" (+{len(inactive_names) - 3} more)" if len(inactive_names) > 3 else ""
        now_what_parts.append(
            f"Action: delegators should consider redelegating from "
            f"inactive pillars ({sample}{more}) to active ones "
            f"to improve network health."
        )
    if not now_what_parts:
        now_what_parts.append("Action: continue monitoring delegation distribution.")

    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {' '.join(now_what_parts)}"


def run_staking_analysis(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full staking analysis: fetch, calculate, persist actionable findings.

    Every finding answers WHAT / SO WHAT / NOW WHAT.
    Returns comprehensive staking status dict.
    """
    from core.persist_to_db import persist_finding

    staking_info = fetch_staking_info()
    pillars = fetch_pillar_delegation_data()

    if staking_info is None:
        persist_finding(
            db_path=db_path,
            domain="economics",
            engine="staking_analyzer",
            evidence_type="staking_error",
            finding=(
                "WHAT: Failed to fetch staking data from Zenon RPC. "
                "SO WHAT: Cannot assess network security posture - "
                "staking ratio, delegation health, and trend analysis "
                "are unavailable. "
                "NOW WHAT: Check ZENON_PUBLIC_RPC or ZENON_NODE_RPC "
                "connectivity. Retry in next cycle."
            ),
            confidence=0.5,
            source_repo="zenon_rpc",
        )
        return {
            "success": False,
            "error": "Failed to fetch staking info from API.",
        }

    ratios = calculate_staking_ratio(staking_info)
    concentration = calculate_delegation_concentration(pillars)

    snapshot_id = persist_staking_snapshot(ratios, concentration, db_path=db_path)

    trend = detect_staking_trend(db_path=db_path)

    # Persist actionable staking finding
    staking_finding = _build_staking_finding(ratios, concentration, trend)
    persist_finding(
        db_path=db_path,
        domain="economics",
        engine="staking_analyzer",
        evidence_type="staking_analysis",
        finding=staking_finding,
        confidence=0.85,
        raw_data={
            "ratios": ratios,
            "trend": trend,
            "concentration_summary": {
                "hhi": concentration.get("hhi"),
                "gini": concentration.get("gini"),
                "top_5_share": concentration.get("top_5_share"),
            },
        },
        source_repo="zenon_rpc",
    )

    # Persist delegation concentration finding
    concentration_finding = _build_concentration_finding(concentration, pillars)
    persist_finding(
        db_path=db_path,
        domain="economics",
        engine="staking_analyzer",
        evidence_type="delegation_concentration",
        finding=concentration_finding,
        confidence=0.85,
        raw_data={"concentration": concentration},
        source_repo="zenon_rpc",
    )

    return {
        "success": True,
        "ratios": ratios,
        "concentration": concentration,
        "trend": trend,
        "snapshot_id": snapshot_id,
        "finding": staking_finding,
    }
