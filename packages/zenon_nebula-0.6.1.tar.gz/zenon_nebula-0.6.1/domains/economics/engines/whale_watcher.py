# SPDX-License-Identifier: MIT
"""
WhaleWatcher -- Monitor large token movements and delegation changes.

For: traders/investors.

Tracks top account holdings, large transfers, delegation shifts,
and staking lock/unlock events. Flags anomalies like sudden large
unstaking, whale accumulation, or delegation concentration shifts.
"""

import logging
import sqlite3
from pathlib import Path

from core.persist_to_db import persist_metric, query_table
from core.persistence import connect
from core.zenon_data import TOKEN_DECIMALS, get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZNN_DECIMALS = 8
QSR_DECIMALS = 8

# Thresholds for whale detection
WHALE_THRESHOLD_ZNN = 100_000  # 100K ZNN = whale
LARGE_DELEGATION_CHANGE_PCT = 5.0  # 5% change = significant
TOP_ACCOUNTS_COUNT = 20


def fetch_top_accounts(count: int = TOP_ACCOUNTS_COUNT) -> list[dict]:
    """Return top-N accounts by ZNN balance.

    Zenon RPC does not provide a ``top accounts`` endpoint natively. We
    approximate by reading pillar owner balances, since pillar operators
    are the most common large-holder cohort. Returns ``[]`` when the
    node is unreachable or no data is available.
    """
    rpc = get_zenon_data()
    pillars = rpc.get_all_pillars(page=0, count=count * 5)
    owner_addresses: list[str] = []
    seen: set[str] = set()
    for pillar in pillars:
        owner = pillar.get("ownerAddress", "")
        if owner and owner not in seen:
            seen.add(owner)
            owner_addresses.append(owner)
    accounts: list[dict] = []
    for address in owner_addresses[: count * 2]:
        balance = rpc.get_balance(address)
        accounts.append(
            {
                "address": address,
                "znn_balance": balance["znn"] / TOKEN_DECIMALS,
                "qsr_balance": balance["qsr"] / TOKEN_DECIMALS,
            }
        )
    accounts.sort(key=lambda a: a["znn_balance"], reverse=True)
    return accounts[:count]


def fetch_pillar_delegations() -> list[dict]:
    """Return current pillar delegation weights.

    Returns ``[{name, weight, produced_momentums}]``. Empty list when the
    node is unreachable.
    """
    rpc = get_zenon_data()
    raw = rpc.get_all_pillars(page=0, count=500)
    out: list[dict] = []
    for p in raw:
        try:
            weight = float(p.get("weight", p.get("delegatedWeight", 0)))
        except (TypeError, ValueError):
            weight = 0.0
        try:
            produced = int(p.get("producedMomentums", 0))
        except (TypeError, ValueError):
            produced = 0
        out.append(
            {
                "name": p.get("name", "unknown"),
                "weight": weight,
                "produced_momentums": produced,
            }
        )
    return out


def fetch_recent_large_transactions(
    min_amount_znn: float = WHALE_THRESHOLD_ZNN,
) -> list[dict]:
    """Return recent large token transfers.

    The Zenon public RPC does not expose a paginated transaction firehose,
    so this helper returns an empty list until a data source is added.
    Engines that depend on transaction-level data should treat an empty
    result as ``no signal`` rather than ``error``.

    Args:
        min_amount_znn: Minimum ZNN amount (human units) to qualify.
    """
    del min_amount_znn
    return []


# -- Analysis --


def analyze_top_holders(accounts: list[dict]) -> dict:
    """Analyze top holder concentration.

    Returns dict with top_5_share, top_10_share, top_20_share,
    whale_count, and total_held.
    """
    if not accounts:
        return {
            "top_5_share_pct": 0.0,
            "top_10_share_pct": 0.0,
            "whale_count": 0,
            "total_held_znn": 0.0,
        }

    sorted_accs = sorted(
        accounts,
        key=lambda a: a["znn_balance"],
        reverse=True,
    )

    total_held = sum(a["znn_balance"] for a in sorted_accs)
    if total_held <= 0:
        total_held = 1  # avoid division by zero

    top_5_held = sum(a["znn_balance"] for a in sorted_accs[:5])
    top_10_held = sum(a["znn_balance"] for a in sorted_accs[:10])

    whale_count = sum(1 for a in sorted_accs if a["znn_balance"] >= WHALE_THRESHOLD_ZNN)

    return {
        "top_5_share_pct": round(top_5_held / total_held * 100, 2),
        "top_10_share_pct": round(top_10_held / total_held * 100, 2),
        "whale_count": whale_count,
        "total_held_znn": round(total_held, 2),
        "top_accounts": [
            {
                "address": a["address"][:12] + "...",
                "znn_balance": round(a["znn_balance"], 2),
            }
            for a in sorted_accs[:5]
        ],
    }


def detect_delegation_changes(
    current_pillars: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> list[dict]:
    """Compare current delegation weights against the last snapshot.

    Returns list of pillars with significant delegation changes.
    """
    # Subquery for latest snapshot — retained as raw SQL since query_table
    # cannot express the correlated MAX() lookup without a second call.
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT pillar_name, weight
               FROM whale_delegation_snapshots
               WHERE snapshot_id = (
                   SELECT MAX(snapshot_id) FROM whale_delegation_snapshots
               )"""
        ).fetchall()
        previous = {row["pillar_name"]: row["weight"] for row in rows}
    except sqlite3.OperationalError:
        previous = {}
    finally:
        conn.close()

    if not previous:
        return []

    changes = []
    for pillar in current_pillars:
        name = pillar["name"]
        current_weight = pillar["weight"]
        prev_weight = previous.get(name, 0)

        if prev_weight <= 0:
            continue

        change_pct = ((current_weight - prev_weight) / prev_weight) * 100

        if abs(change_pct) >= LARGE_DELEGATION_CHANGE_PCT:
            changes.append(
                {
                    "pillar_name": name,
                    "previous_weight": prev_weight,
                    "current_weight": current_weight,
                    "change_pct": round(change_pct, 2),
                    "direction": "gained" if change_pct > 0 else "lost",
                }
            )

    return sorted(changes, key=lambda c: abs(c["change_pct"]), reverse=True)


# -- Persistence --


def persist_whale_snapshot(
    holder_analysis: dict,
    delegation_changes: list[dict],
    large_txs: list[dict],
    pillars: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist whale watching data to the database."""
    snapshot_id = persist_metric(
        db_path=db_path,
        table="whale_snapshots",
        data={
            "top_5_share_pct": holder_analysis.get("top_5_share_pct", 0),
            "top_10_share_pct": holder_analysis.get("top_10_share_pct", 0),
            "whale_count": holder_analysis.get("whale_count", 0),
            "total_held_znn": holder_analysis.get("total_held_znn", 0),
            "large_tx_count": len(large_txs),
            "delegation_changes_count": len(delegation_changes),
        },
    )

    # Persist delegation weights for change detection
    for pillar in pillars:
        persist_metric(
            db_path=db_path,
            table="whale_delegation_snapshots",
            data={
                "snapshot_id": snapshot_id,
                "pillar_name": pillar["name"],
                "weight": pillar["weight"],
            },
        )

    return snapshot_id


def get_whale_history(*, db_path: str = DEFAULT_DB, limit: int = 30) -> list[dict]:
    """Get recent whale snapshots."""
    return query_table(
        db_path=db_path,
        table="whale_snapshots",
        order_by="timestamp DESC",
        limit=limit,
    )


def detect_whale_trend(*, db_path: str = DEFAULT_DB, window: int = 10) -> dict:
    """Detect whale accumulation/distribution trend."""
    history = get_whale_history(db_path=db_path, limit=window)
    if len(history) < 2:
        return {"trend": "insufficient_data", "data_points": len(history)}

    shares = [h["top_5_share_pct"] or 0.0 for h in reversed(history)]
    n = len(shares)
    x_mean = (n - 1) / 2
    y_mean = sum(shares) / n
    num = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(shares))
    den = sum((i - x_mean) ** 2 for i in range(n))
    slope = num / den if den else 0.0

    if slope > 0.1:
        trend = "accumulating"
    elif slope < -0.1:
        trend = "distributing"
    else:
        trend = "stable"

    return {
        "trend": trend,
        "slope": round(slope, 4),
        "latest_top_5_share": shares[-1],
        "data_points": n,
    }


# -- Finding Builders --


def _build_whale_finding(
    holder_analysis: dict,
    delegation_changes: list[dict],
    large_txs: list[dict],
    trend: dict,
) -> str:
    """Build actionable finding for whale watching.

    Answers WHAT / SO WHAT / NOW WHAT.
    """
    top_5 = holder_analysis.get("top_5_share_pct", 0)
    whale_count = holder_analysis.get("whale_count", 0)
    trend_dir = trend.get("trend", "unknown")

    # WHAT
    what_parts = [
        f"Top 5 accounts hold {top_5:.1f}% of tracked ZNN. "
        f"{whale_count} whale accounts (>{WHALE_THRESHOLD_ZNN:,} ZNN).",
    ]

    if large_txs:
        total_moved = sum(tx["amount"] for tx in large_txs)
        what_parts.append(
            f"{len(large_txs)} large transaction(s) detected, total {total_moved:,.0f} ZNN moved."
        )

    if delegation_changes:
        top_change = delegation_changes[0]
        what_parts.append(
            f"Delegation shift: {top_change['pillar_name']} "
            f"{top_change['direction']} {abs(top_change['change_pct']):.1f}%."
        )

    what = " ".join(what_parts)

    # SO WHAT
    so_what_parts = []

    if top_5 > 35:
        so_what_parts.append(
            f"High concentration: top 5 hold {top_5:.0f}%. "
            f"A single whale sell-off could crash price 20%+."
        )

    if trend_dir == "accumulating":
        so_what_parts.append(
            "Whale accumulation trend detected — bullish signal. "
            "Smart money is increasing positions."
        )
    elif trend_dir == "distributing":
        so_what_parts.append(
            "Whale distribution trend detected — bearish signal. "
            "Large holders are reducing positions."
        )

    if large_txs:
        so_what_parts.append(
            "Large movements often precede sell pressure on DEX "
            "or migration to new delegation targets."
        )

    for change in delegation_changes[:3]:
        if change["direction"] == "lost" and abs(change["change_pct"]) > 10:
            so_what_parts.append(
                f"Large undelegation from {change['pillar_name']} "
                f"({change['change_pct']:+.1f}%) may signal loss of "
                f"confidence in that pillar."
            )

    so_what = (
        " ".join(so_what_parts) if so_what_parts else ("Whale activity within normal parameters.")
    )

    # NOW WHAT
    now_what_parts = []

    if trend_dir == "distributing":
        now_what_parts.append("Monitor DEX for sell pressure in next 48h.")
    if large_txs:
        now_what_parts.append("Track destination addresses for follow-up movements.")
    if delegation_changes:
        now_what_parts.append("Monitor affected pillars for continued delegation loss.")
    if not now_what_parts:
        now_what_parts.append("Continue monitoring. Next scan will detect trend changes.")

    now_what = " ".join(now_what_parts)

    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"


# -- Main Entry Point --


def run_whale_watch(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full whale watching analysis: fetch, analyze, persist findings.

    Returns comprehensive whale watch status dict.
    """
    from core.persist_to_db import persist_finding

    accounts = fetch_top_accounts()
    pillars = fetch_pillar_delegations()
    large_txs = fetch_recent_large_transactions()

    if not accounts and not pillars:
        persist_finding(
            db_path=db_path,
            domain="economics",
            engine="whale_watcher",
            evidence_type="whale_error",
            finding=(
                "WHAT: Failed to fetch account and pillar data. "
                "SO WHAT: Cannot assess whale activity or delegation shifts. "
                "NOW WHAT: Check ZENON_PUBLIC_RPC connectivity. Retry next cycle."
            ),
            confidence=0.5,
            source_repo="zenon_rpc",
        )
        return {
            "success": False,
            "error": "Failed to fetch account and pillar data.",
        }

    holder_analysis = analyze_top_holders(accounts)
    delegation_changes = detect_delegation_changes(pillars, db_path=db_path)

    snapshot_id = persist_whale_snapshot(
        holder_analysis,
        delegation_changes,
        large_txs,
        pillars,
        db_path=db_path,
    )

    trend = detect_whale_trend(db_path=db_path)

    finding_text = _build_whale_finding(
        holder_analysis,
        delegation_changes,
        large_txs,
        trend,
    )

    persist_finding(
        db_path=db_path,
        domain="economics",
        engine="whale_watcher",
        evidence_type="whale_analysis",
        finding=finding_text,
        confidence=0.80,
        raw_data={
            "holder_analysis": holder_analysis,
            "delegation_changes": delegation_changes,
            "large_tx_count": len(large_txs),
            "trend": trend,
        },
        source_repo="zenonhub_api",
    )

    return {
        "success": True,
        "holder_analysis": holder_analysis,
        "delegation_changes": delegation_changes,
        "large_tx_count": len(large_txs),
        "trend": trend,
        "snapshot_id": snapshot_id,
        "finding": finding_text,
    }
