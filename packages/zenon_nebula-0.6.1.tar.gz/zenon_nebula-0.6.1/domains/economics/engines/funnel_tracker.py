# SPDX-License-Identifier: MIT
"""
FunnelTracker -- Track participation funnel from holder to pillar.

Maps the full participation funnel:
  holder -> delegator -> staker -> LP provider -> sentinel -> pillar

Fetches data from zenonhub to estimate counts at each funnel stage
and calculates conversion rates between stages.
"""

import json
import logging
import urllib.error
import urllib.request
from pathlib import Path

from core.http import opsec_request, opsec_urlopen  # noqa: F401  OPSEC-safe HTTP wrapper
from core.persist_to_db import persist_metric
from core.zenon_data import get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZNN_DECIMALS = 8

# Funnel stages in order
FUNNEL_STAGES = [
    "holder",
    "delegator",
    "staker",
    "lp_provider",
    "sentinel",
    "pillar",
]


def fetch_holder_count() -> int:
    """Return an estimate of distinct ZNN holders.

    Zenon RPC does not expose a ``distinct holders`` endpoint. We use the
    pillar delegation count as a lower bound: every delegator is a holder.
    Returns 0 when the node is unreachable.
    """
    rpc = get_zenon_data()
    pillars = rpc.get_all_pillars(page=0, count=500)
    total = 0
    for p in pillars:
        try:
            total += int(p.get("delegationCount", p.get("delegateCount", 0)))
        except (TypeError, ValueError):
            continue
    return total


def fetch_delegator_count() -> int:
    """Return the number of unique delegators across all pillars.

    Sums ``delegationCount`` across pillars and applies a conservative
    dedup assumption (70% unique). Returns 0 when the node is unreachable.
    """
    rpc = get_zenon_data()
    pillars = rpc.get_all_pillars(page=0, count=500)
    total = 0
    for p in pillars:
        try:
            total += int(p.get("delegationCount", p.get("delegateCount", 0)))
        except (TypeError, ValueError):
            continue
    return max(int(total * 0.7), 0)


def fetch_staker_count() -> int:
    """Return the estimated number of unique stakers.

    Not directly queryable via RPC; returns 0 when unknown. Future work
    can derive this from ``embedded.stake.getEntriesByAddress`` iteration.
    """
    return 0


def fetch_sentinel_count() -> int:
    """Return the number of active sentinels, or 0 when unreachable."""
    rpc = get_zenon_data()
    count = rpc.get_sentinel_count()
    if count is not None:
        return int(count)
    return len(rpc.get_all_sentinels(page=0, count=500))


def fetch_pillar_count() -> int:
    """Return the number of registered pillars, or 0 when unreachable."""
    rpc = get_zenon_data()
    count = rpc.get_pillar_count()
    if count is not None:
        return int(count)
    return len(rpc.get_all_pillars(page=0, count=500))


def estimate_lp_count() -> int:
    """Return a rough estimate of unique wZNN liquidity providers.

    Uses DexScreener 24-hour trader activity as a proxy. Returns 0 on
    any network or parse failure.
    """
    url = "https://api.dexscreener.com/latest/dex/tokens/0xb2e96a63479C2Edd2FD62b382c89D5CA79f572d3"
    req = urllib.request.Request(url, headers={"User-Agent": "nebula-funnel-tracker/1.0"})
    try:
        resp = opsec_urlopen(req, timeout=10)
        data = json.loads(resp.read())
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        logger.debug("DexScreener LP estimate failed: %s", exc)
        return 0
    pairs = data.get("pairs") or []
    if not pairs:
        return 0
    pair = pairs[0]
    txns = pair.get("txns", {}) if isinstance(pair, dict) else {}
    h24 = txns.get("h24", {}) if isinstance(txns, dict) else {}
    try:
        buys = int(h24.get("buys", 0))
        sells = int(h24.get("sells", 0))
    except (TypeError, ValueError):
        return 0
    daily_traders = buys + sells
    if daily_traders <= 0:
        return 0
    return max(int(daily_traders**0.5 * 3), 0)


def build_funnel(counts: dict) -> list[dict]:
    """Build the participation funnel with conversion rates.

    Args:
        counts: Dict mapping stage name to participant count.

    Returns:
        List of dicts with stage, count, and conversion_rate.
    """
    funnel = []
    prev_count = None

    for stage in FUNNEL_STAGES:
        count = counts.get(stage, 0)
        if prev_count and prev_count > 0:
            conversion = round((count / prev_count) * 100, 2)
        else:
            conversion = 100.0 if count > 0 else 0.0

        funnel.append(
            {
                "stage": stage,
                "count": count,
                "conversion_rate_pct": conversion,
            }
        )
        prev_count = count if count > 0 else prev_count

    return funnel


def persist_funnel(
    funnel: list[dict],
    health: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist funnel data as an actionable evidence entry.

    Uses the evidence table from the core schema.
    """
    # Build actionable finding text
    stage_summary = ", ".join(f"{s['stage']}={s['count']}" for s in funnel if s["count"] > 0)
    bottleneck_count = health.get("bottleneck_count", 0)
    overall_conv = health.get("overall_conversion_pct", 0)

    if bottleneck_count > 0:
        bottleneck_details = "; ".join(
            f"{b['from']}->{b['to']} at {b['conversion']:.1f}%"
            for b in health.get("bottlenecks", [])
        )
        finding = (
            f"WHAT: Participation funnel snapshot: {stage_summary}. "
            f"Overall holder-to-pillar conversion: {overall_conv:.4f}%. "
            f"SO WHAT: {bottleneck_count} bottleneck(s) detected ({bottleneck_details}) -- "
            f"low conversion at these stages limits network security and decentralization. "
            f"NOW WHAT: Investigate incentive gaps at bottleneck stages; "
            f"consider targeted campaigns or reward adjustments to improve conversion."
        )
    else:
        finding = (
            f"WHAT: Participation funnel snapshot: {stage_summary}. "
            f"Overall holder-to-pillar conversion: {overall_conv:.4f}%. "
            f"SO WHAT: No severe bottlenecks detected; funnel is progressing normally. "
            f"NOW WHAT: Continue monitoring; track week-over-week trends for early warning."
        )

    row_id = persist_metric(
        db_path=db_path,
        table="evidence",
        data={
            "domain": "economics",
            "engine": "funnel_tracker",
            "finding_type": "metric",
            "title": "Participation funnel snapshot",
            "body": finding,
            "confidence": 0.7,
            "source": "zenon_rpc+dexscreener",
        },
    )
    return row_id if row_id > 0 else 0


def calculate_funnel_health(funnel: list[dict]) -> dict:
    """Calculate funnel health metrics.

    Identifies bottlenecks (stages with unusually low conversion).
    """
    bottlenecks = []
    for i, stage in enumerate(funnel):
        if i == 0:
            continue
        if stage["conversion_rate_pct"] < 5.0 and stage["count"] > 0:
            bottlenecks.append(
                {
                    "from": funnel[i - 1]["stage"],
                    "to": stage["stage"],
                    "conversion": stage["conversion_rate_pct"],
                }
            )

    overall_conversion = 0.0
    if funnel and funnel[0]["count"] > 0 and funnel[-1]["count"] > 0:
        overall_conversion = round((funnel[-1]["count"] / funnel[0]["count"]) * 100, 4)

    return {
        "overall_conversion_pct": overall_conversion,
        "bottleneck_count": len(bottlenecks),
        "bottlenecks": bottlenecks,
        "widest_stage": max(funnel, key=lambda f: f["count"])["stage"] if funnel else None,
        "narrowest_stage": min(
            (f for f in funnel if f["count"] > 0),
            key=lambda f: f["count"],
            default={"stage": None},
        )["stage"],
    }


def run_funnel_tracking(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full funnel tracking: fetch all stage counts, build funnel, persist.

    Returns comprehensive funnel status dict.
    """
    counts = {
        "holder": fetch_holder_count(),
        "delegator": fetch_delegator_count(),
        "staker": fetch_staker_count(),
        "lp_provider": estimate_lp_count(),
        "sentinel": fetch_sentinel_count(),
        "pillar": fetch_pillar_count(),
    }

    funnel = build_funnel(counts)
    health = calculate_funnel_health(funnel)
    evidence_id = persist_funnel(funnel, health, db_path=db_path)

    return {
        "success": True,
        "counts": counts,
        "funnel": funnel,
        "health": health,
        "evidence_id": evidence_id,
    }
