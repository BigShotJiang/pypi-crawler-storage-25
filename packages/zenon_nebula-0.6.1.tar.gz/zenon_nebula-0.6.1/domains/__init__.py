# SPDX-License-Identifier: MIT
"""Forge Domains -- Plugin packages for each autonomous intelligence domain."""
