# SPDX-License-Identifier: MIT
"""
BridgeCompat -- Check bridge status across Zenon interoperability repos.

Reads HyperCore-Team/orchestrator for bridge contract versions, checks
evm-bridge-contracts for EVM bridge status, verifies SDK bridge support
matches upstream, and tracks which chains Zenon bridges to.
"""

import logging
import os
import re
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

ORCHESTRATOR_DIR = ZENON_WORKSPACE / "HyperCore-Team" / "orchestrator"
EVM_BRIDGE_DIR = ZENON_WORKSPACE / "HyperCore-Team" / "evm-bridge-contracts"
NOM_MULTICHAIN_DIR = ZENON_WORKSPACE / "HyperCore-Team" / "nom-multichain-docs"
SDK_DART_DIR = ZENON_WORKSPACE / "core" / "znn_sdk_dart"
GO_ZENON_DIR = ZENON_WORKSPACE / "core" / "go-zenon"

# Additional interop repos
BLOCKSCOUT_DIR = ZENON_WORKSPACE / "hypercore-one" / "blockscout"
DOCKERIZED_TESTNET_PATHS = [
    ZENON_WORKSPACE / "hypercore-one" / "dockerized-testnet",
    ZENON_WORKSPACE / "zenon-network" / "dockerized-testnet",
]
WALLET_CONNECT_PATHS = [
    ZENON_WORKSPACE / "hypercore-one" / "wallet-connect",
    ZENON_WORKSPACE / "DexterLabZ" / "wallet-connect",
]

# Known chain targets for bridge
KNOWN_CHAINS = ["ethereum", "bsc", "bitcoin"]


def _run_git(repo_path: str, *args: str, timeout: int = 30) -> tuple[int, str]:
    """Run a git command. Returns (returncode, stdout)."""
    cmd = ["git", "-C", repo_path, *list(args)]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def _read_file_text(filepath: Path, max_bytes: int = 300_000) -> str:
    """Read a text file, returning empty string on failure."""
    try:
        return filepath.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def scan_orchestrator() -> dict:
    """Scan HyperCore-Team/orchestrator for bridge configuration.

    Extracts: supported networks, contract addresses, version info,
    last commit, active branches.
    """
    result = {
        "exists": False,
        "networks": [],
        "contract_addresses": [],
        "version": None,
        "last_commit": None,
        "go_mod_deps": [],
    }

    if not ORCHESTRATOR_DIR.is_dir():
        return result
    result["exists"] = True

    # Get last commit info
    code, output = _run_git(
        str(ORCHESTRATOR_DIR),
        "log",
        "-1",
        "--format=%H|%aI|%s",
    )
    if code == 0 and output:
        parts = output.split("|", 2)
        if len(parts) >= 3:
            result["last_commit"] = {
                "hash": parts[0][:12],
                "date": parts[1],
                "message": parts[2],
            }

    # Scan for network configurations
    for go_file in ORCHESTRATOR_DIR.rglob("*.go"):
        text = _read_file_text(go_file)
        # Look for chain/network references
        for chain in KNOWN_CHAINS:
            if chain.lower() in text.lower() and chain not in result["networks"]:
                result["networks"].append(chain)

        # Look for contract address constants
        addr_matches = re.findall(
            r'(?:address|contract)\w*\s*[:=]\s*"(0x[a-fA-F0-9]{40})"',
            text,
            re.IGNORECASE,
        )
        for addr in addr_matches:
            if addr not in result["contract_addresses"]:
                result["contract_addresses"].append(addr)

    # Check go.mod for version and deps
    go_mod = ORCHESTRATOR_DIR / "go.mod"
    if go_mod.is_file():
        text = _read_file_text(go_mod)
        # Extract module version from go.mod
        version_match = re.search(r"go\s+(\d+\.\d+)", text)
        if version_match:
            result["version"] = version_match.group(1)

        # Extract key dependencies
        for dep_match in re.finditer(r"(github\.com/\S+)\s+v(\S+)", text):
            result["go_mod_deps"].append(
                {
                    "module": dep_match.group(1),
                    "version": dep_match.group(2),
                }
            )

    return result


def scan_evm_bridge_contracts() -> dict:
    """Scan evm-bridge-contracts for Solidity contract status.

    Extracts: contract files, Solidity versions, supported standards,
    deployment configs.
    """
    result = {
        "exists": False,
        "contract_files": [],
        "solidity_versions": [],
        "has_tests": False,
        "has_deployment_config": False,
        "token_standards": [],
        "last_commit": None,
    }

    if not EVM_BRIDGE_DIR.is_dir():
        return result
    result["exists"] = True

    # Get last commit
    code, output = _run_git(
        str(EVM_BRIDGE_DIR),
        "log",
        "-1",
        "--format=%H|%aI|%s",
    )
    if code == 0 and output:
        parts = output.split("|", 2)
        if len(parts) >= 3:
            result["last_commit"] = {
                "hash": parts[0][:12],
                "date": parts[1],
                "message": parts[2],
            }

    # Scan for Solidity files
    for sol_file in EVM_BRIDGE_DIR.rglob("*.sol"):
        rel_path = str(sol_file.relative_to(EVM_BRIDGE_DIR))
        if "node_modules" in rel_path or ".cache" in rel_path:
            continue
        result["contract_files"].append(rel_path)

        text = _read_file_text(sol_file)
        # Extract Solidity version
        ver_match = re.search(r"pragma\s+solidity\s+([^;]+);", text)
        if ver_match:
            ver = ver_match.group(1).strip()
            if ver not in result["solidity_versions"]:
                result["solidity_versions"].append(ver)

        # Check for ERC standards
        for std in ["ERC20", "ERC721", "ERC1155", "IERC20", "IERC721"]:
            if std in text and std not in result["token_standards"]:
                result["token_standards"].append(std)

    # Check for test files
    test_dirs = ["test", "tests"]
    for td in test_dirs:
        test_path = EVM_BRIDGE_DIR / td
        if test_path.is_dir() and list(test_path.rglob("*")):
            result["has_tests"] = True
            break

    # Check for deployment configs
    for config_name in ["hardhat.config", "truffle-config", "foundry.toml", "deploy"]:
        matches = list(EVM_BRIDGE_DIR.glob(f"{config_name}*"))
        if matches:
            result["has_deployment_config"] = True
            break

    return result


def check_sdk_bridge_support() -> dict:
    """Check if the Dart SDK has bridge-related API support.

    Looks for bridge/orchestrator/wrap/unwrap related methods.
    """
    result = {
        "has_bridge_api": False,
        "bridge_methods": [],
        "bridge_models": [],
    }

    if not SDK_DART_DIR.is_dir():
        return result

    api_dir = SDK_DART_DIR / "lib" / "src" / "api"
    model_dir = SDK_DART_DIR / "lib" / "src" / "model"

    # Scan API files for bridge methods
    if api_dir.is_dir():
        for dart_file in api_dir.rglob("*.dart"):
            text = _read_file_text(dart_file)
            if re.search(r"(bridge|wrap|unwrap|orchestrat)", text, re.IGNORECASE):
                result["has_bridge_api"] = True
                methods = re.findall(
                    r"Future<\w+>\s+(\w+)\s*\(",
                    text,
                )
                for m in methods:
                    if re.search(r"(bridge|wrap|unwrap)", m, re.IGNORECASE):
                        result["bridge_methods"].append(m)

    # Scan model files for bridge models
    if model_dir.is_dir():
        for dart_file in model_dir.rglob("*.dart"):
            text = _read_file_text(dart_file)
            classes = re.findall(r"class\s+(\w*(?:Bridge|Wrap|Orchestrat)\w*)", text)
            result["bridge_models"].extend(classes)

    return result


def check_go_zenon_bridge_contracts() -> dict:
    """Check go-zenon for bridge-related embedded contracts."""
    result = {
        "has_bridge_contract": False,
        "bridge_files": [],
        "bridge_methods": [],
    }

    if not GO_ZENON_DIR.is_dir():
        return result

    definition_dir = GO_ZENON_DIR / "vm" / "embedded" / "definition"
    impl_dir = GO_ZENON_DIR / "vm" / "embedded" / "implementation"

    for search_dir in [definition_dir, impl_dir]:
        if not search_dir.is_dir():
            continue
        for go_file in search_dir.glob("*.go"):
            text = _read_file_text(go_file)
            if re.search(r"(bridge|portal|htlc|ptlc|atomic.?swap)", text, re.IGNORECASE):
                rel = str(go_file.relative_to(GO_ZENON_DIR))
                if rel not in result["bridge_files"]:
                    result["bridge_files"].append(rel)
                    result["has_bridge_contract"] = True

    return result


def _find_first(paths: list) -> Path | None:
    """Return the first path that exists as a directory."""
    for p in paths:
        if Path(p).is_dir():
            return Path(p)
    return None


def scan_blockscout() -> dict:
    """Scan blockscout fork for EVM explorer compatibility.

    Checks version, customizations, and chain configuration.
    """
    result = {
        "exists": False,
        "customized": False,
        "chains_configured": [],
        "last_commit": None,
    }

    if not BLOCKSCOUT_DIR.is_dir():
        return result
    result["exists"] = True

    # Get last commit
    code, output = _run_git(
        str(BLOCKSCOUT_DIR),
        "log",
        "-1",
        "--format=%H|%aI|%s",
    )
    if code == 0 and output:
        parts = output.split("|", 2)
        if len(parts) >= 3:
            result["last_commit"] = {
                "hash": parts[0][:12],
                "date": parts[1],
                "message": parts[2],
            }

    # Check for Zenon customizations (diff from upstream patterns)
    for config_file in BLOCKSCOUT_DIR.rglob("*.yml"):
        text = _read_file_text(config_file)
        if "zenon" in text.lower() or "znn" in text.lower():
            result["customized"] = True
    for config_file in BLOCKSCOUT_DIR.rglob("*.env*"):
        text = _read_file_text(config_file)
        if "zenon" in text.lower() or "znn" in text.lower():
            result["customized"] = True

    # Check for chain configurations
    for chain in ["ethereum", "bsc", "zenon", "hyperqube"]:
        for f in BLOCKSCOUT_DIR.rglob("*"):
            if chain in f.name.lower() and chain not in result["chains_configured"]:
                result["chains_configured"].append(chain)

    return result


def scan_dockerized_testnet() -> dict:
    """Scan dockerized-testnet for devnet infrastructure.

    Checks for docker-compose configs, genesis files, and test scripts.
    """
    result = {
        "exists": False,
        "has_docker_compose": False,
        "has_genesis": False,
        "has_test_scripts": False,
        "services": [],
        "last_commit": None,
    }

    testnet_dir = _find_first(DOCKERIZED_TESTNET_PATHS)
    if not testnet_dir:
        return result
    result["exists"] = True

    # Get last commit
    code, output = _run_git(
        str(testnet_dir),
        "log",
        "-1",
        "--format=%H|%aI|%s",
    )
    if code == 0 and output:
        parts = output.split("|", 2)
        if len(parts) >= 3:
            result["last_commit"] = {
                "hash": parts[0][:12],
                "date": parts[1],
                "message": parts[2],
            }

    # Check for docker-compose
    for name in ["docker-compose.yml", "docker-compose.yaml", "compose.yml"]:
        compose_file = testnet_dir / name
        if compose_file.is_file():
            result["has_docker_compose"] = True
            text = _read_file_text(compose_file)
            # Extract service names
            services = re.findall(r"^\s{2}(\w[\w-]*):", text, re.MULTILINE)
            result["services"] = services[:20]
            break

    # Check for genesis
    for pattern in ["genesis.json", "**/genesis.json", "config.json"]:
        if list(testnet_dir.glob(pattern)):
            result["has_genesis"] = True
            break

    # Check for test scripts
    for pattern in ["*.sh", "scripts/*.sh", "test*.py", "scripts/*.py"]:
        if list(testnet_dir.glob(pattern)):
            result["has_test_scripts"] = True
            break

    return result


def scan_wallet_connect() -> dict:
    """Scan wallet-connect repos for WC integration status."""
    result = {
        "exists": False,
        "wc_version": None,
        "languages": [],
        "last_commit": None,
    }

    wc_dir = _find_first(WALLET_CONNECT_PATHS)
    if not wc_dir:
        return result
    result["exists"] = True

    # Get last commit
    code, output = _run_git(
        str(wc_dir),
        "log",
        "-1",
        "--format=%H|%aI|%s",
    )
    if code == 0 and output:
        parts = output.split("|", 2)
        if len(parts) >= 3:
            result["last_commit"] = {
                "hash": parts[0][:12],
                "date": parts[1],
                "message": parts[2],
            }

    # Detect WC version from package.json or source
    pkg_json = wc_dir / "package.json"
    if pkg_json.is_file():
        text = _read_file_text(pkg_json)
        result["languages"].append("javascript")
        if "walletconnect" in text.lower():
            # Try to detect version
            ver_match = re.search(r'"@walletconnect/\w+":\s*"([^"]+)"', text)
            if ver_match:
                result["wc_version"] = ver_match.group(1)

    # Detect languages
    lang_map = {".ts": "typescript", ".dart": "dart", ".py": "python", ".go": "go"}
    for ext, lang in lang_map.items():
        if list(wc_dir.rglob(f"*{ext}"))[:1] and lang not in result["languages"]:
            result["languages"].append(lang)

    return result


def check_bridge_contract_versions() -> dict:
    """Compare bridge contract versions against known upstream Ethereum contracts.

    Checks if the EVM bridge contracts are based on known audited templates.
    """
    result = {
        "openzeppelin_version": None,
        "uses_proxy_pattern": False,
        "uses_upgradeable": False,
        "import_sources": [],
    }

    if not EVM_BRIDGE_DIR.is_dir():
        return result

    for sol_file in EVM_BRIDGE_DIR.rglob("*.sol"):
        if "node_modules" in str(sol_file):
            continue
        text = _read_file_text(sol_file)

        # Check OpenZeppelin imports
        oz_imports = re.findall(r'import\s+"(@openzeppelin/[^"]+)"', text)
        for imp in oz_imports:
            if imp not in result["import_sources"]:
                result["import_sources"].append(imp)
            if "proxy" in imp.lower():
                result["uses_proxy_pattern"] = True
            if "upgradeable" in imp.lower():
                result["uses_upgradeable"] = True

    # Try to get OZ version from package.json
    pkg_json = EVM_BRIDGE_DIR / "package.json"
    if pkg_json.is_file():
        text = _read_file_text(pkg_json)
        ver_match = re.search(r'"@openzeppelin/contracts":\s*"([^"]+)"', text)
        if ver_match:
            result["openzeppelin_version"] = ver_match.group(1)

    return result


def generate_report() -> dict:
    """Generate a full bridge compatibility report."""
    orchestrator = scan_orchestrator()
    evm_bridge = scan_evm_bridge_contracts()
    sdk_bridge = check_sdk_bridge_support()
    go_bridge = check_go_zenon_bridge_contracts()
    blockscout = scan_blockscout()
    dockerized_testnet = scan_dockerized_testnet()
    wallet_connect = scan_wallet_connect()
    contract_versions = check_bridge_contract_versions()

    # Determine supported chains
    chains = set(orchestrator.get("networks", []))
    if evm_bridge["exists"]:
        chains.add("ethereum")  # EVM bridge implies Ethereum support

    # Compatibility assessment
    issues = []
    if not orchestrator["exists"]:
        issues.append("Orchestrator repo not found locally")
    if not evm_bridge["exists"]:
        issues.append("EVM bridge contracts repo not found locally")
    if orchestrator["exists"] and not orchestrator["networks"]:
        issues.append("No network configurations detected in orchestrator")
    if evm_bridge["exists"] and not evm_bridge["contract_files"]:
        issues.append("No Solidity contracts found in evm-bridge-contracts")
    if evm_bridge["exists"] and not evm_bridge["has_tests"]:
        issues.append("EVM bridge contracts have no test suite")
    if not sdk_bridge["has_bridge_api"]:
        issues.append("Dart SDK lacks bridge API methods")
    if not go_bridge["has_bridge_contract"]:
        issues.append("go-zenon lacks bridge-related embedded contracts")

    # Additional checks
    if blockscout["exists"] and not blockscout["customized"]:
        issues.append("Blockscout fork not customized for Zenon")
    if not any(p.is_dir() for p in DOCKERIZED_TESTNET_PATHS):
        issues.append("Dockerized testnet repo not found locally")
    if not wallet_connect["exists"]:
        issues.append("WalletConnect integration not found locally")

    return {
        "supported_chains": sorted(chains),
        "orchestrator": orchestrator,
        "evm_bridge": evm_bridge,
        "sdk_bridge": sdk_bridge,
        "go_bridge": go_bridge,
        "blockscout": blockscout,
        "dockerized_testnet": dockerized_testnet,
        "wallet_connect": wallet_connect,
        "contract_versions": contract_versions,
        "issues": issues,
        "issue_count": len(issues),
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run bridge analysis and persist findings to evidence table."""
    from core.persist_to_db import ensure_schema, persist_finding

    ensure_schema(db_path)
    count = 0

    report = generate_report()

    # Overall finding
    chains_str = ", ".join(report["supported_chains"]) or "none detected"
    has_issues = report["issue_count"] > 0
    persist_finding(
        db_path=db_path,
        domain="interoperability",
        engine="bridge_compat",
        evidence_type="bridge_status_overall",
        finding=(
            f"WHAT: Bridge supports {len(report['supported_chains'])} chain(s) ({chains_str}); "
            f"orchestrator {'present' if report['orchestrator']['exists'] else 'MISSING'}; "
            f"{len(report['evm_bridge']['contract_files'])} EVM contract files; "
            f"{report['issue_count']} compatibility issue(s). "
            f"SO WHAT: {'Issues found that could block bridge operation or cross-chain interop.' if has_issues else 'Bridge infrastructure is consistent across repos.'} "
            f"NOW WHAT: {'Fix the {} issue(s) listed below before attempting bridge operations.'.format(report['issue_count']) if has_issues else 'No action needed; re-check after upstream changes.'}"
        ),
        confidence=0.85,
        raw_data=report,
        source_repo="workspace",
    )
    count += 1

    # Persist individual issues with actionable context
    issue_actions = {
        "Orchestrator repo not found locally": "Clone HyperCore-Team/orchestrator into the workspace.",
        "EVM bridge contracts repo not found locally": "Clone HyperCore-Team/evm-bridge-contracts into the workspace.",
        "No network configurations detected in orchestrator": "Check orchestrator Go files for chain config; may need upstream sync.",
        "No Solidity contracts found in evm-bridge-contracts": "Verify evm-bridge-contracts checkout is on correct branch with .sol files.",
        "EVM bridge contracts have no test suite": "Add Hardhat/Foundry tests before deploying bridge contracts.",
        "Dart SDK lacks bridge API methods": "Implement bridge wrap/unwrap API methods in znn_sdk_dart.",
        "go-zenon lacks bridge-related embedded contracts": "Check go-zenon branch; bridge contracts may be on a feature branch.",
        "Blockscout fork not customized for Zenon": "Add Zenon chain config to Blockscout for EVM explorer support.",
        "Dockerized testnet repo not found locally": "Clone hypercore-one/dockerized-testnet for devnet testing.",
        "WalletConnect integration not found locally": "Clone wallet-connect repo if WC integration is needed.",
    }
    for issue in report["issues"]:
        action = issue_actions.get(issue, "Investigate and resolve this compatibility gap.")
        persist_finding(
            db_path=db_path,
            domain="interoperability",
            engine="bridge_compat",
            evidence_type="bridge_issue",
            finding=(
                f"WHAT: {issue}. "
                f"SO WHAT: This gap may block bridge deployment, testing, or SDK integration. "
                f"NOW WHAT: {action}"
            ),
            confidence=0.80,
            raw_data={"issue": issue},
            source_repo="workspace",
        )
        count += 1

    logger.info("BridgeCompat: persisted %d findings", count)
    return count
