# SPDX-License-Identifier: MIT
"""
EvmReadiness -- Check EVM extension chain readiness for Zenon.

Reads hypercore-one/hyperqube_z for HyperQube status, checks EVM
dependencies, tracks Supernova (alienc0der's EVM chain) via repo
activity, and verifies ERC-20 token standard compatibility.
"""

import logging
import os
import re
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

HYPERQUBE_DIR = ZENON_WORKSPACE / "hypercore-one" / "hyperqube_z"
SUPERNOVA_DIR = ZENON_WORKSPACE / "hypercore-one" / "supernova"
EVM_BRIDGE_DIR = ZENON_WORKSPACE / "HyperCore-Team" / "evm-bridge-contracts"
GO_ZENON_HCO = ZENON_WORKSPACE / "hypercore-one" / "go-zenon"
GO_ZENON_CORE = ZENON_WORKSPACE / "core" / "go-zenon"

# EVM-related Go packages to look for
EVM_DEPENDENCIES = [
    "go-ethereum",
    "geth",
    "evm",
    "solidity",
    "abi",
    "ethclient",
]


def _run_git(repo_path: str, *args: str, timeout: int = 30) -> tuple[int, str]:
    """Run a git command. Returns (returncode, stdout)."""
    cmd = ["git", "-C", repo_path, *list(args)]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def _read_file_text(filepath: Path, max_bytes: int = 300_000) -> str:
    """Read a text file, returning empty string on failure."""
    try:
        return filepath.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def _get_repo_activity(repo_path: Path) -> dict | None:
    """Get basic activity metrics for a repo."""
    if not (repo_path / ".git").is_dir():
        return None

    repo_str = str(repo_path)

    # Last commit
    code, output = _run_git(repo_str, "log", "-1", "--format=%H|%aI|%an|%s")
    if code != 0 or not output:
        return None

    parts = output.split("|", 3)
    if len(parts) < 4:
        return None

    # Commit count (last 90 days)
    _, count_out = _run_git(
        repo_str,
        "rev-list",
        "--count",
        "--since=90 days ago",
        "HEAD",
    )
    recent_commits = int(count_out) if count_out.isdigit() else 0

    # Total branches
    _, branches_out = _run_git(repo_str, "branch", "-a", "--list")
    branch_count = len(branches_out.strip().split("\n")) if branches_out else 0

    return {
        "last_commit_hash": parts[0][:12],
        "last_commit_date": parts[1],
        "last_commit_author": parts[2],
        "last_commit_message": parts[3],
        "recent_commits_90d": recent_commits,
        "branch_count": branch_count,
    }


def scan_hyperqube() -> dict:
    """Scan hyperqube_z for extension chain status.

    Checks: repo existence, activity, EVM references, configuration,
    and integration with go-zenon.
    """
    result = {
        "exists": False,
        "activity": None,
        "has_evm_references": False,
        "evm_file_count": 0,
        "config_files": [],
        "key_features": [],
    }

    if not HYPERQUBE_DIR.is_dir():
        return result
    result["exists"] = True
    result["activity"] = _get_repo_activity(HYPERQUBE_DIR)

    # Scan for EVM references
    evm_files = 0
    for ext in ["*.go", "*.sol", "*.ts", "*.js"]:
        for f in HYPERQUBE_DIR.rglob(ext):
            rel = str(f.relative_to(HYPERQUBE_DIR))
            if any(skip in rel for skip in ["node_modules", "vendor", ".git"]):
                continue
            text = _read_file_text(f)
            if re.search(r"(evm|ethereum|solidity|geth|ethclient)", text, re.IGNORECASE):
                evm_files += 1
                result["has_evm_references"] = True

    result["evm_file_count"] = evm_files

    # Check for configuration files
    for config_name in [
        "config.json",
        "config.yaml",
        "config.toml",
        "genesis.json",
        "hardhat.config",
        "foundry.toml",
    ]:
        matches = list(HYPERQUBE_DIR.rglob(config_name))
        for m in matches:
            rel = str(m.relative_to(HYPERQUBE_DIR))
            if "node_modules" not in rel:
                result["config_files"].append(rel)

    # Check for key features in go.mod
    go_mod = HYPERQUBE_DIR / "go.mod"
    if go_mod.is_file():
        text = _read_file_text(go_mod)
        for dep in EVM_DEPENDENCIES:
            if dep.lower() in text.lower():
                result["key_features"].append(f"depends on {dep}")

    return result


def scan_supernova() -> dict:
    """Scan for Supernova (alienc0der's EVM extension) repo activity."""
    result = {
        "exists": False,
        "activity": None,
    }

    # Check multiple possible locations
    for candidate in [
        SUPERNOVA_DIR,
        ZENON_WORKSPACE / "hypercore-one" / "CIPHER",
    ]:
        if candidate.is_dir() and (candidate / ".git").is_dir():
            result["exists"] = True
            result["activity"] = _get_repo_activity(candidate)
            result["path"] = str(candidate.relative_to(ZENON_WORKSPACE))
            break

    return result


def check_evm_deps_in_go_zenon() -> dict:
    """Check if go-zenon has EVM-related dependencies.

    Scans go.mod and source for ethereum/EVM imports.
    """
    result = {
        "go_zenon_core": {"has_evm_deps": False, "deps": []},
        "go_zenon_hco": {"has_evm_deps": False, "deps": []},
    }

    for label, go_dir in [("go_zenon_core", GO_ZENON_CORE), ("go_zenon_hco", GO_ZENON_HCO)]:
        go_mod = go_dir / "go.mod"
        if not go_mod.is_file():
            continue
        text = _read_file_text(go_mod)
        for dep_match in re.finditer(
            r"(github\.com/\S*(?:ethereum|geth|evm)\S*)\s+v(\S+)", text, re.IGNORECASE
        ):
            result[label]["deps"].append(
                {
                    "module": dep_match.group(1),
                    "version": dep_match.group(2),
                }
            )
            result[label]["has_evm_deps"] = True

    return result


def check_erc20_compatibility() -> dict:
    """Check ERC-20 standard compliance in bridge contracts.

    Looks for standard ERC-20 interface methods: totalSupply, balanceOf,
    transfer, approve, transferFrom, allowance.
    """
    result = {
        "erc20_compliant": False,
        "methods_found": [],
        "methods_missing": [],
    }

    required_methods = [
        "totalSupply",
        "balanceOf",
        "transfer",
        "approve",
        "transferFrom",
        "allowance",
    ]

    if not EVM_BRIDGE_DIR.is_dir():
        result["methods_missing"] = required_methods
        return result

    all_text = ""
    for sol_file in EVM_BRIDGE_DIR.rglob("*.sol"):
        rel = str(sol_file.relative_to(EVM_BRIDGE_DIR))
        if "node_modules" in rel:
            continue
        all_text += _read_file_text(sol_file) + "\n"

    for method in required_methods:
        if re.search(rf"function\s+{method}\s*\(", all_text):
            result["methods_found"].append(method)
        else:
            result["methods_missing"].append(method)

    result["erc20_compliant"] = len(result["methods_missing"]) == 0
    return result


def generate_report() -> dict:
    """Generate a full EVM readiness report."""
    hyperqube = scan_hyperqube()
    supernova = scan_supernova()
    go_evm = check_evm_deps_in_go_zenon()
    erc20 = check_erc20_compatibility()

    # Readiness score (0-100)
    score = 0
    if hyperqube["exists"]:
        score += 20
    if hyperqube.get("has_evm_references"):
        score += 10
    if hyperqube.get("activity") and hyperqube["activity"]["recent_commits_90d"] > 0:
        score += 15
    if supernova["exists"]:
        score += 10
    if go_evm["go_zenon_hco"]["has_evm_deps"]:
        score += 15
    if erc20["erc20_compliant"]:
        score += 20
    if hyperqube.get("config_files"):
        score += 10

    # Assessment
    if score >= 70:
        assessment = "EVM readiness is strong"
    elif score >= 40:
        assessment = "EVM readiness is partial -- key components exist but gaps remain"
    else:
        assessment = "EVM readiness is early-stage -- significant work needed"

    return {
        "readiness_score": score,
        "assessment": assessment,
        "hyperqube": hyperqube,
        "supernova": supernova,
        "go_zenon_evm_deps": go_evm,
        "erc20_compatibility": erc20,
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run EVM readiness analysis and persist findings to evidence table."""
    from core.persist_to_db import ensure_schema, persist_finding

    ensure_schema(db_path)
    count = 0

    report = generate_report()

    # Overall finding
    score = report["readiness_score"]
    missing_erc20 = report["erc20_compatibility"]["methods_missing"]
    persist_finding(
        db_path=db_path,
        domain="interoperability",
        engine="evm_readiness",
        evidence_type="evm_readiness_overall",
        finding=(
            f"WHAT: EVM readiness score is {score}/100. "
            f"HyperQube: {'present' if report['hyperqube']['exists'] else 'not found'}; "
            f"ERC-20 compliance: {'complete' if report['erc20_compatibility']['erc20_compliant'] else f'incomplete ({len(missing_erc20)} methods missing)'}. "
            f"SO WHAT: {'EVM extension chain infrastructure is mature enough for testnet trials.' if score >= 70 else 'Key gaps remain that block EVM extension chain launch.' if score >= 40 else 'EVM support is early-stage; significant development needed before extension chains are viable.'} "
            f"NOW WHAT: {'Proceed to HyperQube testnet deployment and ERC-20 integration testing.' if score >= 70 else 'Prioritize missing components: check HyperQube repo activity, add EVM deps to go-zenon, implement missing ERC-20 methods.' if score >= 40 else 'Track HyperQube and Supernova repos for progress; do not plan EVM-dependent features until score > 40.'}"
        ),
        confidence=0.80,
        raw_data=report,
        source_repo="workspace",
    )
    count += 1

    # Persist ERC-20 gaps
    for method in missing_erc20:
        persist_finding(
            db_path=db_path,
            domain="interoperability",
            engine="evm_readiness",
            evidence_type="erc20_gap",
            finding=(
                f"WHAT: ERC-20 method '{method}()' not found in evm-bridge-contracts. "
                f"SO WHAT: Without '{method}', wrapped tokens will not comply with ERC-20 standard; "
                f"DEXes and wallets will reject the token. "
                f"NOW WHAT: Implement 'function {method}(...)' in the bridge token Solidity contract "
                f"following the EIP-20 specification."
            ),
            confidence=0.75,
            raw_data={"method": method, "gap_type": "erc20"},
            source_repo="evm-bridge-contracts",
        )
        count += 1

    logger.info("EvmReadiness: persisted %d findings", count)
    return count
