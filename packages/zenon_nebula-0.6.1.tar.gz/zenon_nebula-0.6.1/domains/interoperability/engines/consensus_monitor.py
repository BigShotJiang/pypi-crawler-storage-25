# SPDX-License-Identifier: MIT
"""
ConsensusMonitor -- Monitor external chain codebases for changes affecting Zenon.

Scans locally cloned repositories of Bitcoin Core, go-ethereum, cosmos-sdk,
and other chains for changes across seven categories:

  1. Consensus / Validation -- difficulty, block validation, header format
  2. Cryptography -- signature schemes, hash functions, key derivation
  3. Staking / Delegation -- validator economics, delegation models
  4. Governance -- on-chain proposals, voting mechanisms
  5. Token Standards -- ERC-20, new token types, wrapping patterns
  6. Smart Contracts / VM -- opcodes, execution model, gas metering
  7. P2P / Networking -- peer discovery, protocol changes
  8. Bridge Patterns -- IBC, relay, light-client bridge designs

Cross-references findings against Zenon's codebase to flag anything that
could affect bridge safety, interop compatibility, or design direction.

This engine is FREE to run -- all analysis is local git log + file diffing.
No LLM or API calls.
"""

import logging
import os
import re
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

GO_ZENON_DIR = ZENON_WORKSPACE / "core" / "go-zenon"

# ---------------------------------------------------------------------------
# External chain definitions
# ---------------------------------------------------------------------------

# Each chain maps folder-name patterns to a chain identity.  When we scan
# the workspace for repos, any directory whose name matches a pattern is
# treated as that chain's local clone.

CHAIN_FOLDER_PATTERNS: dict[str, list[str]] = {
    "bitcoin": ["bitcoin", "bitcoin-core"],
    "ethereum": ["go-ethereum", "geth"],
    "cosmos": ["cosmos-sdk"],
}

# Additional exact-word matches in directory names.  We split the name on
# common delimiters (-, _) and check for these tokens to avoid false
# positives (e.g., "znn-typescript-sdk" should NOT match "eth").
CHAIN_TOKEN_HINTS: dict[str, str] = {
    "btc": "bitcoin",
    "btcd": "bitcoin",
    "eth": "ethereum",
    "evm": "ethereum",
    "geth": "ethereum",
    "cosmos": "cosmos",
    "ibc": "cosmos",
    "solana": "solana",
    "substrate": "polkadot",
    "polkadot": "polkadot",
    "avalanche": "avalanche",
    "avax": "avalanche",
    "cardano": "cardano",
}

# ---------------------------------------------------------------------------
# Consensus-critical paths per chain
# ---------------------------------------------------------------------------

# Files/directories whose changes are consensus-relevant.
# Each entry is (glob_pattern, severity, description).

BITCOIN_CRITICAL_PATHS: list[tuple[str, str, str]] = [
    # Consensus / Validation
    ("src/pow.cpp", "critical", "Proof-of-work / difficulty adjustment"),
    ("src/pow.h", "critical", "Proof-of-work header"),
    ("src/validation.cpp", "critical", "Block and transaction validation"),
    ("src/validation.h", "critical", "Validation header"),
    ("src/consensus/*", "critical", "Consensus parameters and rules"),
    # Cryptography
    ("src/secp256k1/*", "high", "secp256k1 library (Schnorr / ECDSA)"),
    ("src/key.cpp", "high", "Key handling / derivation"),
    ("src/key.h", "high", "Key types"),
    ("src/pubkey.cpp", "high", "Public key operations"),
    ("src/pubkey.h", "high", "Public key types"),
    ("src/hash.cpp", "medium", "Hash function implementations"),
    ("src/hash.h", "medium", "Hash function headers"),
    ("src/crypto/*", "high", "Cryptographic primitives"),
    # Script / Opcodes
    ("src/script/interpreter.cpp", "high", "Script interpreter / opcodes"),
    ("src/script/interpreter.h", "high", "Script interpreter header"),
    ("src/script/script.cpp", "high", "Script definitions (new opcodes)"),
    ("src/script/script.h", "high", "Script opcode constants"),
    ("src/script/sigcache.cpp", "medium", "Signature cache"),
    # Transaction / Block format
    ("src/primitives/transaction.h", "high", "Transaction format"),
    ("src/primitives/transaction.cpp", "high", "Transaction serialization"),
    ("src/primitives/block.h", "high", "Block header format"),
    ("src/primitives/block.cpp", "high", "Block serialization"),
    # Chain parameters / Soft-fork deployment
    ("src/chainparams.cpp", "medium", "Chain parameters (activation heights)"),
    ("src/deploymentinfo.cpp", "medium", "Soft-fork deployment info"),
    # P2P / Networking
    ("src/net.cpp", "medium", "P2P networking"),
    ("src/net.h", "medium", "P2P networking header"),
    ("src/net_processing.cpp", "medium", "P2P message processing"),
    ("src/protocol.cpp", "medium", "P2P protocol constants"),
    ("src/protocol.h", "medium", "P2P protocol header"),
]

ETHEREUM_CRITICAL_PATHS: list[tuple[str, str, str]] = [
    # Smart Contracts / VM
    ("core/vm/*", "critical", "EVM virtual machine / opcodes"),
    ("core/vm/instructions.go", "critical", "EVM opcode implementations"),
    ("core/vm/opcodes.go", "critical", "EVM opcode definitions"),
    ("core/vm/interpreter.go", "high", "EVM interpreter loop"),
    ("core/vm/gas_table.go", "high", "EVM gas costs"),
    # Transaction / Block types
    ("core/types/transaction*.go", "high", "Transaction type definitions"),
    ("core/types/block*.go", "high", "Block type definitions"),
    ("core/types/receipt*.go", "medium", "Receipt format"),
    # Consensus
    ("params/config.go", "high", "Chain config and fork schedule"),
    ("params/protocol_params.go", "high", "Protocol parameters"),
    ("consensus/*", "critical", "Consensus engine"),
    ("core/state_processor.go", "high", "State transition rules"),
    # Cryptography
    ("crypto/*", "high", "Cryptographic functions (secp256k1, keccak)"),
    ("accounts/keystore/*", "medium", "Key derivation and storage"),
    # Token standards (common types)
    ("core/types/log.go", "medium", "Event log format (ERC-20 events)"),
    # P2P / Networking
    ("p2p/*", "medium", "P2P networking layer"),
    ("eth/protocols/*", "medium", "Ethereum wire protocol"),
    ("eth/handler.go", "medium", "Eth protocol handler"),
    # Staking / Validator (PoS)
    ("beacon/engine/*", "high", "Beacon engine (PoS consensus)"),
    ("core/txpool/*", "medium", "Transaction pool / fee market"),
    # Light client (bridge-relevant)
    ("light/*", "high", "Light client protocol"),
    ("les/*", "medium", "Light Ethereum Subprotocol"),
]

COSMOS_CRITICAL_PATHS: list[tuple[str, str, str]] = [
    # Staking / Delegation
    ("x/staking/*", "high", "Staking module changes"),
    ("x/staking/keeper/*", "high", "Staking keeper (delegation logic)"),
    # Governance
    ("x/gov/*", "high", "Governance module"),
    ("x/gov/keeper/*", "high", "Governance keeper (proposal/voting)"),
    # Token / Bank
    ("x/bank/*", "high", "Bank module changes"),
    ("x/bank/keeper/*", "medium", "Bank keeper (token transfers)"),
    # Transaction format
    ("types/tx/*", "high", "Transaction format"),
    ("types/tx/signing/*", "high", "Transaction signing"),
    # Consensus / ABCI
    ("baseapp/*", "medium", "Base application / ABCI"),
    ("server/cmt/*", "medium", "CometBFT integration"),
    # Cryptography
    ("crypto/*", "high", "Cryptographic primitives"),
    ("crypto/keys/*", "medium", "Key types and derivation"),
    # IBC (bridge pattern)
    ("x/ibc/*", "high", "Inter-Blockchain Communication"),
    ("modules/light-clients/*", "high", "IBC light client implementations"),
    ("modules/core/*", "medium", "IBC core protocol"),
]

CHAIN_CRITICAL_PATHS: dict[str, list[tuple[str, str, str]]] = {
    "bitcoin": BITCOIN_CRITICAL_PATHS,
    "ethereum": ETHEREUM_CRITICAL_PATHS,
    "cosmos": COSMOS_CRITICAL_PATHS,
}

# ---------------------------------------------------------------------------
# Zenon files to cross-reference against external changes
# ---------------------------------------------------------------------------

# Chain-specific cross-references: maps (chain, category) to Zenon paths.
# These are checked first; if no match, the generic CATEGORY_CROSS_REFS below
# are used.  All paths are relative to go-zenon root.

CHAIN_CROSS_REFS: dict[tuple[str, str], list[str]] = {
    # Bitcoin -- bridge safety critical
    ("bitcoin", "consensus"): [
        "vm/embedded/implementation/bitcoin_spv.go",
        "vm/embedded/definition/bitcoin_spv.go",
        "consensus/",
    ],
    ("bitcoin", "validation"): [
        "vm/embedded/implementation/bitcoin_spv.go",
        "vm/embedded/implementation/portal.go",
    ],
    ("bitcoin", "script"): [
        "vm/embedded/implementation/ptlc.go",
        "vm/embedded/definition/ptlc.go",
        "vm/embedded/implementation/portal.go",
    ],
    ("bitcoin", "crypto"): [
        "vm/embedded/implementation/ptlc.go",
        "common/crypto/",
    ],
    ("bitcoin", "transaction"): [
        "vm/embedded/implementation/bitcoin_spv.go",
        "vm/embedded/implementation/portal.go",
        "vm/embedded/implementation/atomic_swap.go",
    ],
    ("bitcoin", "block"): [
        "vm/embedded/implementation/bitcoin_spv.go",
    ],
    ("bitcoin", "p2p"): [
        "protocol/",
    ],
    # Ethereum -- EVM/Supernova compatibility
    ("ethereum", "vm"): [
        "vm/embedded/implementation/evm.go",
        "vm/",
    ],
    ("ethereum", "types"): [
        "vm/embedded/implementation/evm.go",
        "common/types/",
    ],
    ("ethereum", "consensus"): [
        "vm/embedded/implementation/evm.go",
        "consensus/",
    ],
    ("ethereum", "crypto"): [
        "common/crypto/",
    ],
    ("ethereum", "p2p"): [
        "protocol/",
    ],
    ("ethereum", "staking"): [
        "vm/embedded/implementation/stake.go",
        "vm/embedded/implementation/pillar.go",
        "vm/embedded/implementation/sentinel.go",
    ],
    ("ethereum", "light_client"): [
        "vm/embedded/implementation/bitcoin_spv.go",
    ],
    # Cosmos -- governance and staking patterns
    ("cosmos", "staking"): [
        "vm/embedded/implementation/stake.go",
        "vm/embedded/implementation/pillar.go",
        "vm/embedded/implementation/sentinel.go",
    ],
    ("cosmos", "governance"): [
        "vm/embedded/implementation/accelerator.go",
        "vm/embedded/implementation/governance.go",
    ],
    ("cosmos", "ibc"): [
        "vm/embedded/implementation/portal.go",
        "vm/embedded/implementation/bitcoin_spv.go",
    ],
    ("cosmos", "crypto"): [
        "common/crypto/",
    ],
    ("cosmos", "transaction"): [
        "common/types/",
    ],
}

# Generic cross-references by category (used for any chain not in
# CHAIN_CROSS_REFS or as fallback).  Easy to extend.
CATEGORY_CROSS_REFS: dict[str, list[str]] = {
    "consensus": [
        "consensus/",
        "vm/embedded/implementation/bitcoin_spv.go",
    ],
    "validation": [
        "vm/embedded/implementation/bitcoin_spv.go",
        "vm/embedded/implementation/portal.go",
    ],
    "crypto": [
        "common/crypto/",
        "vm/embedded/implementation/ptlc.go",
    ],
    "script": [
        "vm/embedded/implementation/ptlc.go",
        "vm/embedded/implementation/portal.go",
    ],
    "vm": [
        "vm/",
    ],
    "transaction": [
        "common/types/",
        "vm/embedded/implementation/bitcoin_spv.go",
    ],
    "block": [
        "vm/embedded/implementation/bitcoin_spv.go",
    ],
    "staking": [
        "vm/embedded/implementation/stake.go",
        "vm/embedded/implementation/pillar.go",
        "vm/embedded/implementation/sentinel.go",
    ],
    "governance": [
        "vm/embedded/implementation/accelerator.go",
        "vm/embedded/implementation/governance.go",
    ],
    "token": [
        "vm/embedded/implementation/token.go",
        "vm/embedded/definition/token.go",
    ],
    "p2p": [
        "protocol/",
    ],
    "bridge": [
        "vm/embedded/implementation/portal.go",
        "vm/embedded/implementation/bitcoin_spv.go",
    ],
    "ibc": [
        "vm/embedded/implementation/portal.go",
        "vm/embedded/implementation/bitcoin_spv.go",
    ],
    "light_client": [
        "vm/embedded/implementation/bitcoin_spv.go",
    ],
}

# Keywords that classify a changed file path into a category.
PATH_CATEGORY_KEYWORDS: dict[str, str] = {
    # Consensus / Validation
    "pow": "consensus",
    "validation": "validation",
    "consensus": "consensus",
    "chainparams": "consensus",
    "params/config": "consensus",
    "deploymentinfo": "consensus",
    "state_processor": "validation",
    "baseapp": "consensus",
    # Cryptography
    "secp256k1": "crypto",
    "crypto/": "crypto",
    "key.cpp": "crypto",
    "key.h": "crypto",
    "pubkey": "crypto",
    "hash.cpp": "crypto",
    "hash.h": "crypto",
    "keystore": "crypto",
    "signing": "crypto",
    # Script / Opcodes
    "script": "script",
    "interpreter": "script",
    "opcodes": "script",
    "instructions.go": "vm",
    # Transaction / Block format
    "transaction": "transaction",
    "primitives/block": "block",
    "core/types/block": "block",
    "core/types/transaction": "transaction",
    "core/types/receipt": "transaction",
    "core/types/log": "token",
    "types/tx": "transaction",
    # VM
    "core/vm": "vm",
    "vm/": "vm",
    "gas_table": "vm",
    "gas.go": "vm",
    # Staking / Delegation
    "staking": "staking",
    "beacon/engine": "staking",
    "validator": "staking",
    # Governance
    "x/gov": "governance",
    "governance": "governance",
    # Token
    "x/bank": "token",
    "erc20": "token",
    # P2P / Networking
    "net.cpp": "p2p",
    "net.h": "p2p",
    "net_processing": "p2p",
    "protocol.cpp": "p2p",
    "protocol.h": "p2p",
    "p2p/": "p2p",
    "eth/protocols": "p2p",
    "eth/handler": "p2p",
    # Bridge / IBC
    "ibc": "ibc",
    "light-clients": "light_client",
    "light/": "light_client",
    "les/": "light_client",
    "bridge": "bridge",
    "relay": "bridge",
}

# ---------------------------------------------------------------------------
# Auto-classification for unknown repos
# ---------------------------------------------------------------------------

# Signature files/directories that indicate a repo is blockchain-related.
# Maps a path pattern (checked via os.path.exists relative to repo root)
# to a list of (category, description) tuples.

REPO_SIGNATURE_PATTERNS: list[tuple[str, list[tuple[str, str]]]] = [
    ("src/pow.cpp", [("consensus", "Bitcoin-style PoW consensus")]),
    ("src/consensus", [("consensus", "Consensus directory")]),
    ("consensus", [("consensus", "Consensus directory")]),
    ("core/vm", [("vm", "Smart contract VM")]),
    ("vm", [("vm", "Virtual machine")]),
    ("evm", [("vm", "EVM implementation")]),
    ("wasm", [("vm", "WASM runtime")]),
    ("x/staking", [("staking", "Cosmos-style staking module")]),
    ("staking", [("staking", "Staking system")]),
    ("x/gov", [("governance", "Cosmos-style governance")]),
    ("governance", [("governance", "Governance module")]),
    ("x/ibc", [("ibc", "IBC protocol")]),
    ("bridge", [("bridge", "Bridge implementation")]),
    ("relay", [("bridge", "Relay/bridge")]),
    ("crypto", [("crypto", "Cryptographic primitives")]),
    ("src/secp256k1", [("crypto", "secp256k1 library")]),
    ("p2p", [("p2p", "P2P networking")]),
    ("src/net.cpp", [("p2p", "P2P networking")]),
    ("light", [("light_client", "Light client")]),
]

# Go module deps that indicate blockchain relevance.
GO_BLOCKCHAIN_DEPS: dict[str, str] = {
    "go-ethereum": "ethereum",
    "cosmos-sdk": "cosmos",
    "tendermint": "cosmos",
    "cometbft": "cosmos",
    "btcd": "bitcoin",
    "libp2p": "p2p",
    "substrate": "polkadot",
}

# Cargo.toml deps that indicate blockchain relevance.
CARGO_BLOCKCHAIN_DEPS: dict[str, str] = {
    "substrate": "polkadot",
    "solana-sdk": "solana",
    "near-sdk": "near",
    "sp-runtime": "polkadot",
    "frame-support": "polkadot",
}

# Module-level cache for auto-classified repos.
_repo_classification_cache: dict[str, dict] = {}


def _classify_repo(repo_path: Path) -> dict | None:
    """Auto-classify a repo as blockchain-related based on signature files.

    Returns a dict with 'chain' (str or 'unknown'), 'categories' (list),
    and 'critical_paths' (list of tuples) -- or None if not blockchain-related.
    """
    cache_key = str(repo_path)
    if cache_key in _repo_classification_cache:
        return _repo_classification_cache[cache_key]

    categories: list[tuple[str, str]] = []

    # Check signature file patterns
    for pattern, cats in REPO_SIGNATURE_PATTERNS:
        check_path = repo_path / pattern
        if check_path.exists():
            categories.extend(cats)

    # Check go.mod for blockchain deps
    chain_hint: str | None = None
    go_mod = repo_path / "go.mod"
    if go_mod.is_file():
        text = _read_file_text(go_mod)
        for dep_key, dep_chain in GO_BLOCKCHAIN_DEPS.items():
            if dep_key in text:
                chain_hint = dep_chain
                break

    # Check Cargo.toml for blockchain deps
    cargo_toml = repo_path / "Cargo.toml"
    if cargo_toml.is_file() and chain_hint is None:
        text = _read_file_text(cargo_toml)
        for dep_key, dep_chain in CARGO_BLOCKCHAIN_DEPS.items():
            if dep_key in text:
                chain_hint = dep_chain
                break

    # Check package.json for blockchain deps
    pkg_json = repo_path / "package.json"
    if pkg_json.is_file() and chain_hint is None:
        text = _read_file_text(pkg_json)
        if "ethers" in text or "web3" in text:
            chain_hint = "ethereum"

    if not categories and chain_hint is None:
        _repo_classification_cache[cache_key] = None  # type: ignore[assignment]
        return None

    # Determine chain
    chain = chain_hint or "unknown"

    # Build generic critical paths from discovered categories
    # For unknown repos, watch all directories matching the category
    generic_paths: list[tuple[str, str, str]] = []
    seen_categories = set()
    for cat, _desc in categories:
        if cat not in seen_categories:
            seen_categories.add(cat)
            # Watch the signature directory itself
            for pattern, cats in REPO_SIGNATURE_PATTERNS:
                for c, d in cats:
                    if c == cat:
                        if pattern.endswith(".cpp") or pattern.endswith(".h"):
                            generic_paths.append(
                                (pattern, "high", d),
                            )
                        else:
                            generic_paths.append(
                                (pattern + "/*", "high", d),
                            )

    result = {
        "chain": chain,
        "categories": list(seen_categories),
        "critical_paths": generic_paths,
    }
    _repo_classification_cache[cache_key] = result
    return result


# Confidence by severity
SEVERITY_CONFIDENCE: dict[str, float] = {
    "critical": 0.95,
    "high": 0.85,
    "medium": 0.70,
}


# ---------------------------------------------------------------------------
# Git helpers
# ---------------------------------------------------------------------------


def _run_git(repo_path: str, *args: str, timeout: int = 30) -> tuple[int, str]:
    """Run a git command.  Returns (returncode, stdout)."""
    cmd = ["git", "-C", repo_path, *list(args)]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def _is_git_repo(path: Path) -> bool:
    """Check if *path* contains a .git directory."""
    return (path / ".git").is_dir()


def _read_file_text(filepath: Path, max_bytes: int = 300_000) -> str:
    """Read a text file, returning empty string on failure."""
    try:
        return filepath.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


# ---------------------------------------------------------------------------
# Repo discovery
# ---------------------------------------------------------------------------


def discover_external_repos() -> dict[str, list[Path]]:
    """Scan the workspace for external chain repositories.

    Returns a mapping of chain name to list of repo paths.
    Searches the top two directory levels under ZENON_WORKSPACE.

    Uses three strategies in order:
      1. Exact folder name match against CHAIN_FOLDER_PATTERNS
      2. Substring hint match against CHAIN_SUBSTRING_HINTS
      3. Auto-classification via signature files for unknown repos
    """
    found: dict[str, list[Path]] = {}

    if not ZENON_WORKSPACE.is_dir():
        logger.warning("Workspace root not found: %s", ZENON_WORKSPACE)
        return found

    # Skip Zenon's own repos -- we only want external chains.
    # Also skip repos whose names contain "znn" or "zenon" since those
    # are part of the Zenon ecosystem, not external chains.
    zenon_repo_names = {
        "go-zenon",
        "znn_sdk_dart",
        "znn_cli_dart",
        "syrius",
        "nomctl",
        "znn-sdk-go",
        "zenon-light-client",
        "orchestrator",
        "evm-bridge-contracts",
        "nom-multichain-docs",
        "wiki",
        "zenonhub",
        "nebula",
        "marketing",
        "engine",
        "forge",
        "hyperqube_z",
        "hyperqube-events",
        "qube-manager",
        "qubestr",
        "go-zdk",
        "bridge-dapp",
        "wallet-connect-syrius-demo",
        "blockscout",
        "dockerized-testnet",
        "wallet-connect",
        "supernova",
        "meta",
        "awesome-zenon",
        "developer-commons",
        "skills",
        "nexus",
        "probe",
        "seti",
    }

    # Collect candidate directories (depth 1 and 2)
    candidates: list[Path] = []
    try:
        for child in ZENON_WORKSPACE.iterdir():
            if not child.is_dir() or child.name.startswith("."):
                continue
            candidates.append(child)
            try:
                for grandchild in child.iterdir():
                    if grandchild.is_dir() and not grandchild.name.startswith("."):
                        candidates.append(grandchild)
            except PermissionError:
                continue
    except PermissionError:
        return found

    for candidate in candidates:
        if not _is_git_repo(candidate):
            continue
        dir_lower = candidate.name.lower()
        if dir_lower in zenon_repo_names:
            continue
        # Skip anything with "znn" or "zenon" in the name
        if "znn" in dir_lower or "zenon" in dir_lower:
            continue
        matched = False

        # Strategy 1: Exact folder name match
        for chain, patterns in CHAIN_FOLDER_PATTERNS.items():
            if dir_lower in [p.lower() for p in patterns]:
                found.setdefault(chain, []).append(candidate)
                matched = True
                break

        if matched:
            continue

        # Strategy 2: Token-based hint match (split name into tokens)
        name_tokens = set(re.split(r"[-_.]", dir_lower))
        for token, chain in CHAIN_TOKEN_HINTS.items():
            if token in name_tokens:
                found.setdefault(chain, []).append(candidate)
                matched = True
                break

        if matched:
            continue

        # Strategy 3: Auto-classify unknown repos
        classification = _classify_repo(candidate)
        if classification is not None:
            chain_name = classification["chain"]
            if chain_name == "unknown":
                chain_name = f"auto:{candidate.name}"
            found.setdefault(chain_name, []).append(candidate)

    return found


# ---------------------------------------------------------------------------
# Change detection
# ---------------------------------------------------------------------------


def _get_recent_commits(
    repo_path: str,
    days: int = 7,
    max_count: int = 200,
) -> list[dict]:
    """Return recent commits as list of dicts with hash, date, subject."""
    code, output = _run_git(
        repo_path,
        "log",
        f"--since={days} days ago",
        f"--max-count={max_count}",
        "--format=%H|%aI|%s",
    )
    if code != 0 or not output:
        return []

    commits = []
    for line in output.splitlines():
        parts = line.split("|", 2)
        if len(parts) >= 3:
            commits.append(
                {
                    "hash": parts[0],
                    "date": parts[1],
                    "subject": parts[2],
                }
            )
    return commits


def _get_changed_files_in_range(
    repo_path: str,
    commit_range: str,
    timeout: int = 30,
) -> list[str]:
    """Return list of files changed in the given commit range."""
    code, output = _run_git(
        repo_path,
        "diff",
        "--name-only",
        commit_range,
        timeout=timeout,
    )
    if code != 0 or not output:
        return []
    return [f for f in output.splitlines() if f.strip()]


def _get_diff_stat(
    repo_path: str,
    commit_range: str,
    file_path: str,
    timeout: int = 30,
) -> str:
    """Return a compact diff stat for a specific file in a range."""
    code, output = _run_git(
        repo_path,
        "diff",
        "--stat",
        commit_range,
        "--",
        file_path,
        timeout=timeout,
    )
    if code != 0:
        return ""
    return output


def _match_critical_path(
    file_path: str,
    critical_paths: list[tuple[str, str, str]],
) -> tuple[str, str] | None:
    """Check if *file_path* matches any critical path pattern.

    Returns (severity, description) or None.
    Uses simple glob-like matching (``*`` matches any segment).
    """
    for pattern, severity, desc in critical_paths:
        if _glob_match(file_path, pattern):
            return severity, desc
    return None


def _glob_match(file_path: str, pattern: str) -> bool:
    """Minimal glob matcher supporting trailing ``*`` and ``/*``."""
    if pattern.endswith("/*"):
        prefix = pattern[:-2]
        return file_path.startswith(prefix + "/") or file_path == prefix
    elif pattern.endswith("*"):
        prefix = pattern[:-1]
        return file_path.startswith(prefix)
    else:
        return file_path == pattern


def _categorize_path(file_path: str) -> str | None:
    """Map a changed file path to a cross-reference category."""
    lower = file_path.lower()
    for keyword, category in PATH_CATEGORY_KEYWORDS.items():
        if keyword in lower:
            return category
    return None


# ---------------------------------------------------------------------------
# Cross-reference against Zenon
# ---------------------------------------------------------------------------


def _check_zenon_impact(
    chain: str,
    category: str,
) -> list[dict]:
    """Check which Zenon files might be affected by an external change.

    Looks up chain-specific cross-references first, then falls back to
    generic category-based references.  Returns a list of dicts with
    path and exists flag.
    """
    # Chain-specific first
    zenon_files = CHAIN_CROSS_REFS.get((chain, category), [])
    # Fallback to generic
    if not zenon_files:
        zenon_files = CATEGORY_CROSS_REFS.get(category, [])

    impacts = []
    seen: set[str] = set()
    for rel_path in zenon_files:
        if rel_path in seen:
            continue
        seen.add(rel_path)
        full = GO_ZENON_DIR / rel_path
        exists = full.is_file() or full.is_dir()
        impacts.append(
            {
                "file": rel_path,
                "exists": exists,
            }
        )
    return impacts


# ---------------------------------------------------------------------------
# Main analysis
# ---------------------------------------------------------------------------


def analyze_chain(
    chain: str,
    repo_path: Path,
    days: int = 7,
) -> list[dict]:
    """Analyze a single external chain repo for consensus-critical changes.

    Returns a list of finding dicts ready for persistence.
    """
    findings: list[dict] = []
    repo_str = str(repo_path)
    critical_paths = CHAIN_CRITICAL_PATHS.get(chain, [])

    # For auto-classified repos, use their discovered critical paths
    if not critical_paths:
        classification = _classify_repo(repo_path)
        if classification and classification.get("critical_paths"):
            critical_paths = classification["critical_paths"]

    if not critical_paths:
        logger.debug("No critical paths defined for chain '%s'; skipping.", chain)
        return findings

    # Get recent commits
    commits = _get_recent_commits(repo_str, days=days)
    if not commits:
        logger.info(
            "No commits in last %d days for %s (%s).",
            days,
            chain,
            repo_path,
        )
        return findings

    # Build commit range for diff
    oldest_hash = commits[-1]["hash"]
    newest_hash = commits[0]["hash"]
    if oldest_hash == newest_hash:
        commit_range = f"{oldest_hash}~1..{newest_hash}"
    else:
        commit_range = f"{oldest_hash}..{newest_hash}"

    # Get all changed files in range
    changed_files = _get_changed_files_in_range(repo_str, commit_range)
    if not changed_files:
        return findings

    # Check each changed file against critical paths
    for file_path in changed_files:
        match = _match_critical_path(file_path, critical_paths)
        if match is None:
            continue

        severity, description = match
        category = _categorize_path(file_path)

        # Find commits that touched this specific file
        code, file_log = _run_git(
            repo_str,
            "log",
            f"--since={days} days ago",
            "--max-count=10",
            "--format=%H|%aI|%s",
            "--",
            file_path,
        )
        touching_commits = []
        if code == 0 and file_log:
            for line in file_log.splitlines():
                parts = line.split("|", 2)
                if len(parts) >= 3:
                    touching_commits.append(
                        {
                            "hash": parts[0][:12],
                            "date": parts[1],
                            "subject": parts[2],
                        }
                    )

        # Get diff stat for context
        diff_stat = _get_diff_stat(repo_str, commit_range, file_path)

        # Cross-reference against Zenon
        zenon_impacts = []
        if category:
            zenon_impacts = _check_zenon_impact(chain, category)

        # Build the WHAT / SO WHAT / NOW WHAT finding
        what = (
            f"{chain.title()} repo changed {file_path} "
            f"({description}). "
            f"{len(touching_commits)} commit(s) in last {days} days."
        )
        if touching_commits:
            latest = touching_commits[0]
            what += f" Latest: {latest['subject']} ({latest['hash']})"

        # SO WHAT depends on severity and Zenon impact
        if zenon_impacts:
            affected_files = [z["file"] for z in zenon_impacts if z["exists"]]
            missing_files = [z["file"] for z in zenon_impacts if not z["exists"]]
            if affected_files:
                so_what = (
                    f"Zenon's bridge/interop code may be affected. "
                    f"Files to review: {', '.join(affected_files)}. "
                    f"If {chain.title()}'s {description.lower()} changed, "
                    f"Zenon's implementation must match or the bridge could "
                    f"reject valid blocks / accept invalid ones."
                )
            elif missing_files:
                so_what = (
                    f"Expected Zenon files not found: {', '.join(missing_files)}. "
                    f"These contracts may not be implemented yet."
                )
            else:
                so_what = (
                    f"Change to {description.lower()} in {chain.title()} "
                    f"may affect Zenon bridge compatibility."
                )
        else:
            so_what = (
                f"Change to {description.lower()} in {chain.title()} "
                f"is consensus-relevant. No direct Zenon cross-reference "
                f"defined, but bridge operators should review."
            )

        # NOW WHAT
        if zenon_impacts and any(z["exists"] for z in zenon_impacts):
            affected = [z["file"] for z in zenon_impacts if z["exists"]]
            now_what = (
                f"Diff go-zenon/{affected[0]} against "
                f"{chain}/{file_path}. Verify Zenon's implementation "
                f"handles the new behavior. Run bridge tests if available."
            )
        else:
            now_what = (
                f"Review {chain}/{file_path} changes. Assess whether "
                f"Zenon's interop code needs updating. Create a tracking "
                f"issue if the change affects bridge assumptions."
            )

        confidence = SEVERITY_CONFIDENCE.get(severity, 0.70)

        source_commit = touching_commits[0]["hash"] if touching_commits else None

        findings.append(
            {
                "chain": chain,
                "severity": severity,
                "file_path": file_path,
                "description": description,
                "category": category,
                "finding": f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}",
                "confidence": confidence,
                "touching_commits": touching_commits,
                "diff_stat": diff_stat,
                "zenon_impacts": zenon_impacts,
                "source_repo": str(repo_path.name),
                "source_commit": source_commit,
                "source_file": file_path,
            }
        )

    return findings


def generate_report(days: int = 7) -> dict:
    """Scan all discovered external chain repos and produce a report.

    Returns a dict with per-chain findings and a summary.
    """
    repos = discover_external_repos()

    all_findings: list[dict] = []
    chain_summaries: dict[str, dict] = {}
    scanned_repos: list[str] = []

    for chain, paths in repos.items():
        chain_findings: list[dict] = []
        for repo_path in paths:
            from core.git_cache import has_repo_changed

            if not has_repo_changed(str(repo_path)):
                logger.info(
                    "Skipping unchanged repo: %s (%s)",
                    chain,
                    repo_path,
                )
                continue

            findings = analyze_chain(chain, repo_path, days=days)
            chain_findings.extend(findings)
            scanned_repos.append(str(repo_path.relative_to(ZENON_WORKSPACE)))

        all_findings.extend(chain_findings)

        # Per-chain summary
        critical_count = sum(1 for f in chain_findings if f["severity"] == "critical")
        high_count = sum(1 for f in chain_findings if f["severity"] == "high")
        medium_count = sum(1 for f in chain_findings if f["severity"] == "medium")
        chain_summaries[chain] = {
            "repos_found": len(paths),
            "total_findings": len(chain_findings),
            "critical": critical_count,
            "high": high_count,
            "medium": medium_count,
        }

    # Overall severity
    total_critical = sum(s["critical"] for s in chain_summaries.values())
    total_high = sum(s["high"] for s in chain_summaries.values())

    if total_critical > 0:
        overall = "ALERT: Critical consensus changes detected in external chains."
    elif total_high > 0:
        overall = "WARNING: High-severity changes detected in external chains."
    elif all_findings:
        overall = "Changes detected in external chains; review recommended."
    else:
        overall = "No consensus-critical changes detected in external chains."

    return {
        "scan_days": days,
        "chains_discovered": list(repos.keys()),
        "scanned_repos": scanned_repos,
        "chain_summaries": chain_summaries,
        "findings": all_findings,
        "total_findings": len(all_findings),
        "total_critical": total_critical,
        "total_high": total_high,
        "overall_assessment": overall,
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run consensus monitoring and persist findings to evidence table."""
    from core.persist_to_db import ensure_schema, persist_finding

    ensure_schema(db_path)
    count = 0

    report = generate_report()

    # Overall summary finding
    persist_finding(
        db_path=db_path,
        domain="interoperability",
        engine="consensus_monitor",
        evidence_type="consensus_monitor_summary",
        finding=(
            f"WHAT: Scanned {len(report['scanned_repos'])} external chain repo(s) "
            f"across {len(report['chains_discovered'])} chain(s) "
            f"({', '.join(report['chains_discovered']) or 'none found'}). "
            f"Found {report['total_findings']} consensus-relevant change(s) "
            f"({report['total_critical']} critical, {report['total_high']} high). "
            f"SO WHAT: {report['overall_assessment']} "
            f"NOW WHAT: {'Review critical findings immediately -- bridge safety may be at risk.' if report['total_critical'] > 0 else 'Review high-severity findings before next bridge deployment.' if report['total_high'] > 0 else 'No immediate action required. Re-scan after upstream syncs.'}"
        ),
        confidence=0.90,
        raw_data={
            "chains_discovered": report["chains_discovered"],
            "scanned_repos": report["scanned_repos"],
            "chain_summaries": report["chain_summaries"],
            "total_findings": report["total_findings"],
        },
        source_repo="workspace",
    )
    count += 1

    # Persist individual findings
    for finding in report["findings"]:
        persist_finding(
            db_path=db_path,
            domain="interoperability",
            engine="consensus_monitor",
            evidence_type=f"consensus_change_{finding['severity']}",
            finding=finding["finding"],
            confidence=finding["confidence"],
            source_repo=finding["source_repo"],
            source_file=finding["source_file"],
            source_commit=finding.get("source_commit"),
            raw_data={
                "chain": finding["chain"],
                "severity": finding["severity"],
                "category": finding["category"],
                "touching_commits": finding["touching_commits"],
                "diff_stat": finding["diff_stat"],
                "zenon_impacts": finding["zenon_impacts"],
            },
        )
        count += 1

    # Enrich with live chain heights from RPC endpoints (if configured)
    try:
        from core.universal_rpc import get_all_rpcs

        rpcs = get_all_rpcs()
        for chain_name, rpc in rpcs.items():
            try:
                height = rpc.get_block_height()
                if height is not None:
                    persist_finding(
                        db_path=db_path,
                        domain="interoperability",
                        engine="consensus_monitor",
                        evidence_type="live_chain_height",
                        finding=(
                            f"WHAT: Chain '{chain_name}' is at height {height:,}. "
                            f"SO WHAT: Live height confirms the chain is producing blocks "
                            f"and our RPC endpoint is reachable. "
                            f"NOW WHAT: Cross-reference with consensus changes above."
                        ),
                        confidence=0.95,
                        source_repo=chain_name,
                        raw_data={"chain": chain_name, "height": height, "rpc_url": rpc.url},
                    )
                    count += 1
            except Exception as exc:
                logger.debug("ConsensusMonitor per-chain probe failed: %s", exc)
                continue
    except Exception as exc:
        # RPC endpoints not configured — git analysis is sufficient
        logger.debug("ConsensusMonitor RPC sweep skipped: %s", exc)

    logger.info("ConsensusMonitor: persisted %d findings", count)
    return count
