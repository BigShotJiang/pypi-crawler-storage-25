# SPDX-License-Identifier: MIT
"""
InteroperabilityDomain -- DomainPlugin for cross-chain compatibility and bridge readiness.

Provides engines for checking bridge protocol compatibility and EVM
extension chain readiness across the Zenon ecosystem.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class InteroperabilityDomain(DomainPlugin):
    """Interoperability domain plugin -- bridge and EVM readiness analysis."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "interoperability"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Cross-chain bridge compatibility tracking, EVM extension chain "
            "readiness, and inter-protocol standard compliance."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 4

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="bridge_compat",
                description=(
                    "Checks bridge compatibility: orchestrator config, EVM "
                    "bridge contracts, SDK bridge support, go-zenon bridge contracts."
                ),
                module_path="domains.interoperability.engines.bridge_compat",
                priority=5,
                tier=1,
                required_apis=["filesystem", "git"],
                max_runtime_seconds=90,
            ),
            EngineDefinition(
                name="evm_readiness",
                description=(
                    "Checks EVM extension chain readiness: HyperQube status, "
                    "go-ethereum dependencies, ERC-20 compliance, Supernova progress."
                ),
                module_path="domains.interoperability.engines.evm_readiness",
                priority=5,
                tier=1,
                required_apis=["filesystem", "git"],
                max_runtime_seconds=90,
            ),
            EngineDefinition(
                name="consensus_monitor",
                description=(
                    "Monitors external chain codebases (Bitcoin Core, Ethereum, "
                    "Cosmos) for consensus-critical changes that could affect "
                    "Zenon's bridge and interoperability contracts."
                ),
                module_path="domains.interoperability.engines.consensus_monitor",
                priority=6,
                tier=1,
                required_apis=["filesystem", "git"],
                max_runtime_seconds=120,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="bridge_compatible",
                label="Zenon bridge is compatible with target chains",
                description=(
                    "Bridge contracts work correctly with Ethereum, Bitcoin, "
                    "and other target chains."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="evm_ready",
                label="EVM extension chain is production-ready",
                description=(
                    "HyperQube or Supernova EVM chain is ready for deployment "
                    "with full ERC standard compliance."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.85,
            ),
            HypothesisType(
                type_id="consensus_compatible",
                label="Zenon bridge is compatible with current external chain consensus",
                description=(
                    "External chains (Bitcoin, Ethereum) have not made "
                    "consensus-breaking changes that invalidate Zenon's "
                    "bridge or interop contracts."
                ),
                initial_confidence=0.5,
                publishable_threshold=0.80,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="full_evm_compat",
                label="Full EVM compatibility for extension chains",
                description=(
                    "Zenon extension chains should support ERC-20, ERC-721, "
                    "and ERC-1155 token standards."
                ),
                priority=3,
                deadline_days=180,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="bridge_incompatibility",
                label="Bridge incompatibility detected",
                description=(
                    "Interoperability shows bridge issue AND network health "
                    "shows stuck cross-chain transactions."
                ),
                source_domains=["interoperability", "network_health"],
                convergence_threshold=0.7,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="interoperability",
                section_title="Interoperability Status",
                metrics=[
                    "chains_supported",
                    "bridge_issues",
                    "evm_readiness_score",
                    "erc20_compliance",
                    "consensus_changes_critical",
                    "consensus_changes_high",
                ],
                recommendations_prompt=(
                    "Based on bridge compatibility and EVM readiness, "
                    "what interop work should be prioritized?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "chains_supported": 0.0,
            "bridge_issue_count": 0.0,
            "evm_readiness_score": 0.0,
            "consensus_changes_critical": 0.0,
            "consensus_changes_high": 0.0,
        }

    def decide_next_action(self, context: dict, exclude: set[str] | None = None) -> dict | None:
        """Rotate through all interoperability engines, honoring exclude.

        Pre-v0.3.2 returned None on routine context with empty
        stale_data, so bridge_compat / evm_readiness / consensus_monitor
        were all dead in the autonomous loop.
        """
        exclude = exclude or set()
        candidates: list[dict] = [
            {
                "action": "check_bridge_compat",
                "reason": "Routine bridge compatibility scan.",
                "priority": 5,
                "engine": "bridge_compat",
            },
            {
                "action": "check_evm_readiness",
                "reason": "Routine EVM readiness scan.",
                "priority": 5,
                "engine": "evm_readiness",
            },
            {
                "action": "check_consensus_changes",
                "reason": "Routine external-chain consensus scan.",
                "priority": 6,
                "engine": "consensus_monitor",
            },
        ]
        for candidate in candidates:
            key = f"interoperability:{candidate['action']}"
            if key not in exclude:
                return candidate
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return ""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Interoperability domain registered with %d engines.",
            len(self.get_engines()),
        )
