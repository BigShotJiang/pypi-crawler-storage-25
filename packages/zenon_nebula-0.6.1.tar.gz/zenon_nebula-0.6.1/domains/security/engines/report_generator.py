# SPDX-License-Identifier: MIT
"""
ReportGenerator -- Generates security report sections for PR descriptions.

Reads accumulated security findings from the database and produces
formatted report sections suitable for inclusion in PR descriptions
and war room briefings.
"""

import logging
import sqlite3
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

SEVERITY_EMOJI = {
    "critical": "CRITICAL",
    "high": "HIGH",
    "medium": "MEDIUM",
    "low": "LOW",
    "info": "INFO",
}

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


def get_findings(
    contract_name: str | None = None,
    *,
    severity_filter: str | None = None,
    unresolved_only: bool = True,
    db_path: str = DEFAULT_DB,
) -> list[dict]:
    """Retrieve security findings from the database.

    Args:
        contract_name: Filter by contract. None for all contracts.
        severity_filter: Filter by minimum severity (e.g. 'high' includes
                        critical and high).
        unresolved_only: If True, only return unresolved findings.
        db_path: Path to the SQLite database.
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        query = "SELECT * FROM security_reviews WHERE 1=1"
        params: list = []

        if contract_name:
            query += " AND contract_name = ?"
            params.append(contract_name)
        if unresolved_only:
            query += " AND resolved = 0"
        if severity_filter and severity_filter in SEVERITY_ORDER:
            threshold = SEVERITY_ORDER[severity_filter]
            allowed = [s for s, v in SEVERITY_ORDER.items() if v <= threshold]
            placeholders = ",".join("?" * len(allowed))
            query += f" AND severity IN ({placeholders})"
            params.extend(allowed)

        query += " ORDER BY severity, timestamp DESC"
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_summary_counts(
    contract_name: str | None = None,
    *,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Get finding counts grouped by severity."""
    conn = connect(db_path)
    try:
        query = """
            SELECT severity, COUNT(*) as count
            FROM security_reviews
            WHERE resolved = 0
        """
        params: list = []
        if contract_name:
            query += " AND contract_name = ?"
            params.append(contract_name)
        query += " GROUP BY severity"

        rows = conn.execute(query, params).fetchall()
        counts = dict.fromkeys(SEVERITY_ORDER, 0)
        for sev, count in rows:
            counts[sev] = count
        counts["total"] = sum(counts.values())
        return counts
    finally:
        conn.close()


def generate_pr_security_section(
    contract_name: str | None = None,
    *,
    db_path: str = DEFAULT_DB,
) -> str:
    """Generate a security section for a PR description.

    Returns a markdown-formatted string.
    """
    counts = get_summary_counts(contract_name, db_path=db_path)
    findings = get_findings(
        contract_name,
        severity_filter="high",
        db_path=db_path,
    )

    lines = ["## Security Review"]
    lines.append("")

    if counts["total"] == 0:
        lines.append("No security findings.")
        return "\n".join(lines)

    # Summary table
    lines.append("| Severity | Count |")
    lines.append("|----------|-------|")
    for sev in ("critical", "high", "medium", "low", "info"):
        if counts[sev] > 0:
            lines.append(f"| {SEVERITY_EMOJI[sev]} | {counts[sev]} |")
    lines.append(f"| **Total** | **{counts['total']}** |")
    lines.append("")

    # Critical and high findings detail
    if findings:
        lines.append("### Critical / High Findings")
        lines.append("")
        for f in findings:
            sev = SEVERITY_EMOJI.get(f["severity"], f["severity"])
            lines.append(f"- **[{sev}]** {f['title']}")
            if f.get("description"):
                desc = f["description"][:200]
                lines.append(f"  - {desc}")
            if f.get("file_path") and f.get("line_number"):
                lines.append(f"  - `{f['file_path']}:{f['line_number']}`")
        lines.append("")

    return "\n".join(lines)


def generate_war_room_section(*, db_path: str = DEFAULT_DB) -> str:
    """Generate a security section for the war room briefing."""
    counts = get_summary_counts(db_path=db_path)

    lines = ["### Security Posture"]
    lines.append("")
    lines.append(f"- Unresolved findings: {counts['total']}")
    lines.append(f"- Critical: {counts['critical']}")
    lines.append(f"- High: {counts['high']}")
    lines.append(f"- Medium: {counts['medium']}")
    lines.append(f"- Low: {counts['low']}")
    lines.append("")

    if counts["critical"] > 0 or counts["high"] > 0:
        lines.append(
            "**ACTION REQUIRED**: Critical or high severity findings need immediate attention."
        )
    else:
        lines.append("Security posture: acceptable.")

    return "\n".join(lines)


def generate_full_report(*, db_path: str = DEFAULT_DB) -> str:
    """Generate a comprehensive security report across all contracts."""
    conn = connect(db_path)
    try:
        contracts = conn.execute(
            """SELECT DISTINCT contract_name FROM security_reviews
               WHERE resolved = 0
               ORDER BY contract_name"""
        ).fetchall()
    finally:
        conn.close()

    lines = ["# Security Report"]
    lines.append("")

    if not contracts:
        lines.append("No security findings to report.")
        return "\n".join(lines)

    # Overall summary
    overall = get_summary_counts(db_path=db_path)
    lines.append("## Summary")
    lines.append("")
    lines.append(f"Total unresolved findings: {overall['total']}")
    lines.append(f"- Critical: {overall['critical']}")
    lines.append(f"- High: {overall['high']}")
    lines.append(f"- Medium: {overall['medium']}")
    lines.append(f"- Low: {overall['low']}")
    lines.append(f"- Info: {overall['info']}")
    lines.append("")

    # Per-contract sections
    for (contract_name,) in contracts:
        lines.append(f"## {contract_name}")
        lines.append("")
        section = generate_pr_security_section(
            contract_name,
            db_path=db_path,
        )
        # Strip the top-level header since we already have one
        section_lines = section.split("\n")
        if section_lines and section_lines[0].startswith("## Security"):
            section_lines = section_lines[1:]
        lines.extend(section_lines)
        lines.append("")

    return "\n".join(lines)
