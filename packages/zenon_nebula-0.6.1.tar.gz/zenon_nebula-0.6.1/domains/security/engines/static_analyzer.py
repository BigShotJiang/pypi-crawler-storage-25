# SPDX-License-Identifier: MIT
"""
StaticAnalyzer -- Structural and pattern-based checks on Go embedded contract source.

Since we cannot import Go AST packages from Python, this engine performs
line-level structural analysis that approximates AST checks, plus regex
pattern matching that was previously handled by a separate vuln_scanner
engine (merged here to eliminate duplication):

Structural checks:
- All error returns handled (no bare _ on error)
- ValidateSendBlock repacks data before returning
- ReceiveBlock calls ValidateSendBlock first
- Function bodies check all returned errors

Pattern-based checks (merged from vuln_scanner):
- unchecked error returns
- missing DealWithErr handling
- hardcoded Zenon addresses and amounts
- unsafe unsigned subtraction
- missing access control annotations
- TODO/FIXME markers in code
"""

import logging
import re
from pathlib import Path

from core.persist_to_db import persist_metric
from domains.security.analysis import (
    DEFAULT_PATTERNS,
    get_default_patterns,
    load_patterns,
    scan_file_with_patterns,
    seed_patterns,
)

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

GO_ZENON_PATHS = [
    ZENON_WORKSPACE / "core" / "go-zenon",
    ZENON_WORKSPACE / "network" / "go-zenon",
]

# Structural patterns that approximate AST checks

# Match function definitions
FUNC_DEF_RE = re.compile(
    r"^func\s+(?:\(\w+\s+\*?\w+\)\s+)?(\w+)\s*\(",
)
# Match error assignments with _
BARE_ERROR_RE = re.compile(r"\b_\s*=\s*(\w+(?:\.\w+)*\([^)]*\))")
# Match ValidateSendBlock definition
VALIDATE_SEND_RE = re.compile(r"func\s+\(\w+\s+\*?\w+\)\s+ValidateSendBlock\b")
# Match ReceiveBlock definition
RECEIVE_BLOCK_RE = re.compile(r"func\s+\(\w+\s+\*?\w+\)\s+ReceiveBlock\b")
# Match calls to ValidateSendBlock inside a function
CALLS_VALIDATE_RE = re.compile(r"\.ValidateSendBlock\s*\(")
# Match data repack patterns (definition.ABIxxx.PackMethod)
REPACK_RE = re.compile(r"definition\.\w+\.Pack\w+\(")
# Match error return
ERR_RETURN_RE = re.compile(r"return\s+.*\berr\b")
# Match if err != nil
ERR_CHECK_RE = re.compile(r"if\s+err\s*!=\s*nil")


class Finding:
    """A static analysis finding."""

    def __init__(
        self,
        check: str,
        severity: str,
        title: str,
        description: str,
        file_path: str,
        line_number: int,
    ):
        self.check = check
        self.severity = severity
        self.title = title
        self.description = description
        self.file_path = file_path
        self.line_number = line_number

    def to_dict(self) -> dict:
        """Serialize to a plain dict."""
        return {
            "check": self.check,
            "severity": self.severity,
            "title": self.title,
            "description": self.description,
            "file_path": self.file_path,
            "line_number": self.line_number,
        }


def _find_impl_files(contract_name: str | None = None) -> list[Path]:
    """Find Go implementation files."""
    files = []
    for go_zenon in GO_ZENON_PATHS:
        impl_dir = go_zenon / "vm" / "embedded" / "implementation"
        if not impl_dir.is_dir():
            continue
        if contract_name:
            path = impl_dir / f"{contract_name}.go"
            if path.is_file():
                files.append(path)
        else:
            files.extend(impl_dir.glob("*.go"))
    return files


def check_bare_error_discards(file_path: Path) -> list[Finding]:
    """Check for bare _ on error returns."""
    findings = []
    try:
        lines = file_path.read_text(encoding="utf-8").split("\n")
    except (OSError, UnicodeDecodeError):
        return findings

    for i, line in enumerate(lines, start=1):
        if BARE_ERROR_RE.search(line):
            findings.append(
                Finding(
                    check="bare_error_discard",
                    severity="high",
                    title="Bare _ discards error return",
                    description=(
                        f"WHAT: Error return discarded with _ at line {i}: {line.strip()}. "
                        f"SO WHAT: Silenced errors can mask state corruption or fund loss in embedded contracts. "
                        f"NOW WHAT: Replace _ with an explicit error check or use common.DealWithErr()."
                    ),
                    file_path=str(file_path),
                    line_number=i,
                )
            )
    return findings


def check_validate_send_repacks(file_path: Path) -> list[Finding]:
    """Check that ValidateSendBlock repacks data before returning."""
    findings = []
    try:
        content = file_path.read_text(encoding="utf-8")
        lines = content.split("\n")
    except (OSError, UnicodeDecodeError):
        return findings

    in_validate_send = False
    func_start_line = 0
    brace_depth = 0
    has_repack = False

    for i, line in enumerate(lines, start=1):
        if VALIDATE_SEND_RE.search(line):
            in_validate_send = True
            func_start_line = i
            brace_depth = 0
            has_repack = False

        if in_validate_send:
            brace_depth += line.count("{") - line.count("}")
            if REPACK_RE.search(line):
                has_repack = True
            # End of function
            if brace_depth <= 0 and i > func_start_line:
                if not has_repack:
                    findings.append(
                        Finding(
                            check="validate_send_no_repack",
                            severity="medium",
                            title="ValidateSendBlock does not repack data",
                            description=(
                                f"WHAT: ValidateSendBlock at line {func_start_line} does not repack send block data. "
                                f"SO WHAT: Without canonical repacking via definition.ABI.PackMethod(), "
                                f"malformed inputs may pass validation and cause inconsistent state across nodes. "
                                f"NOW WHAT: Add definition.ABI<Contract>.PackMethod() call in ValidateSendBlock "
                                f"to normalize the data before returning."
                            ),
                            file_path=str(file_path),
                            line_number=func_start_line,
                        )
                    )
                in_validate_send = False

    return findings


def check_receive_calls_validate(file_path: Path) -> list[Finding]:
    """Check that ReceiveBlock calls ValidateSendBlock first."""
    findings = []
    try:
        content = file_path.read_text(encoding="utf-8")
        lines = content.split("\n")
    except (OSError, UnicodeDecodeError):
        return findings

    in_receive = False
    func_start_line = 0
    brace_depth = 0
    first_meaningful_line = True
    found_validate_call = False

    for i, line in enumerate(lines, start=1):
        if RECEIVE_BLOCK_RE.search(line):
            in_receive = True
            func_start_line = i
            brace_depth = 0
            first_meaningful_line = True
            found_validate_call = False

        if in_receive:
            brace_depth += line.count("{") - line.count("}")

            stripped = line.strip()
            if stripped and not stripped.startswith("//") and i > func_start_line:
                if first_meaningful_line and CALLS_VALIDATE_RE.search(line):
                    found_validate_call = True
                if stripped and not stripped.startswith("{"):
                    first_meaningful_line = False

            # Check within first 10 lines of the function
            if i - func_start_line <= 10 and CALLS_VALIDATE_RE.search(line):
                found_validate_call = True

            if brace_depth <= 0 and i > func_start_line:
                if not found_validate_call:
                    findings.append(
                        Finding(
                            check="receive_no_validate",
                            severity="high",
                            title="ReceiveBlock does not call ValidateSendBlock",
                            description=(
                                f"WHAT: ReceiveBlock at line {func_start_line} does not call ValidateSendBlock. "
                                f"SO WHAT: Without validation, ReceiveBlock processes unverified send data, "
                                f"enabling malformed or malicious transactions to alter contract state. "
                                f"NOW WHAT: Add a ValidateSendBlock call at the top of ReceiveBlock "
                                f"and return on error before any state changes."
                            ),
                            file_path=str(file_path),
                            line_number=func_start_line,
                        )
                    )
                in_receive = False

    return findings


# ---------------------------------------------------------------------------
# Pattern-based checks (re-exported from domains.security.analysis so the
# legacy ``vuln_scanner`` wrapper and external callers keep their existing
# import path while the implementation lives in a shared domain module).
# ---------------------------------------------------------------------------

__all__ = [
    "BARE_ERROR_RE",
    "CALLS_VALIDATE_RE",
    # Module constants
    "DEFAULT_DB",
    # Pattern-based helpers (re-exported from domains.security.analysis)
    "DEFAULT_PATTERNS",
    "ERR_CHECK_RE",
    "ERR_RETURN_RE",
    "FUNC_DEF_RE",
    "GO_ZENON_PATHS",
    "RECEIVE_BLOCK_RE",
    "REPACK_RE",
    "VALIDATE_SEND_RE",
    # Structural checks (defined in this module)
    "Finding",
    "analyze_all_contracts",
    "analyze_contract",
    "analyze_file",
    "check_bare_error_discards",
    "check_receive_calls_validate",
    "check_validate_send_repacks",
    "get_default_patterns",
    "load_patterns",
    "persist_findings",
    "run_static_analysis",
    "scan_file_with_patterns",
    "seed_patterns",
]


# ---------------------------------------------------------------------------
# Combined analysis entry points
# ---------------------------------------------------------------------------


def analyze_file(file_path: Path) -> list[Finding]:
    """Run all static analysis checks on a single file.

    Structural checks only. Pattern-based checks are available via
    :func:`scan_file_with_patterns` and are exposed through the
    backward-compatible ``vuln_scanner`` wrapper module.
    """
    findings = []
    findings.extend(check_bare_error_discards(file_path))
    findings.extend(check_validate_send_repacks(file_path))
    findings.extend(check_receive_calls_validate(file_path))
    return findings


def analyze_contract(contract_name: str) -> list[dict]:
    """Run static analysis on a specific contract.

    Returns list of finding dicts.
    """
    files = _find_impl_files(contract_name)
    all_findings = []
    for f in files:
        all_findings.extend(analyze_file(f))
    return [f.to_dict() for f in all_findings]


def analyze_all_contracts() -> dict[str, list[dict]]:
    """Run static analysis on all embedded contracts.

    Returns dict mapping contract_name to list of finding dicts.
    """
    files = _find_impl_files()
    results: dict[str, list[dict]] = {}
    for f in files:
        contract_name = f.stem
        findings = analyze_file(f)
        if contract_name not in results:
            results[contract_name] = []
        results[contract_name].extend([fd.to_dict() for fd in findings])
    return results


def persist_findings(
    contract_name: str,
    findings: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist static analysis findings to security_reviews table."""
    if not findings:
        return 0
    count = 0
    for f in findings:
        rid = persist_metric(
            db_path=db_path,
            table="security_reviews",
            data={
                "contract_name": contract_name,
                "engine": "static_analyzer",
                "severity": f["severity"],
                "category": f["check"],
                "title": f["title"],
                "description": f["description"],
                "file_path": f.get("file_path", ""),
                "line_number": f.get("line_number", 0),
                "confidence": 0.9,
            },
        )
        if rid > 0:
            count += 1
    return count


def run_static_analysis(db_path: str = DEFAULT_DB) -> dict:
    """Zero-arg entry point for the autonomous scheduler.

    Runs :func:`analyze_all_contracts` and persists any findings. Safe
    to call on every cycle; portable installs without the Zenon
    workspace simply produce zero findings.
    """
    try:
        results = analyze_all_contracts()
    except Exception as exc:
        logger.debug("static_analyzer analyze_all_contracts failed: %s", exc)
        return {
            "success": False,
            "error": str(exc),
            "contracts_scanned": 0,
            "total_findings": 0,
        }
    total = sum(len(v) for v in results.values())
    persisted = 0
    for contract, findings in results.items():
        try:
            persisted += persist_findings(contract, findings, db_path=db_path)
        except Exception as exc:
            logger.debug("static_analyzer persist_findings(%s) failed: %s", contract, exc)
    return {
        "success": True,
        "contracts_scanned": len(results),
        "total_findings": total,
        "persisted": persisted,
    }
