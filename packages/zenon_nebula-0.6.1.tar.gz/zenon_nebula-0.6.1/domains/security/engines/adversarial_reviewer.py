# SPDX-License-Identifier: MIT
"""
AdversarialReviewer -- Contract security analysis with static checks + LLM.

Two modes:
1. Static analysis (free, no LLM): scans Go source for common vulnerability
   patterns — missing reclaim paths, unchecked errors, missing access control,
   missing spork gates, unbounded iteration, missing input validation.
2. LLM-driven review (paid): deep analysis via Claude for subtle issues.

Every finding answers: WHAT (the issue), SO WHAT (the risk), NOW WHAT (fix).
"""

import json
import logging
import re
from pathlib import Path

from core.persist_to_db import persist_finding, persist_metric
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

# Possible locations for go-zenon source
GO_ZENON_PATHS = [
    ZENON_WORKSPACE / "core" / "go-zenon",
    ZENON_WORKSPACE / "network" / "go-zenon",
]

REVIEW_CATEGORIES = [
    "fund_theft",
    "fund_lock",
    "dos_vector",
    "access_control_bypass",
    "integer_overflow",
    "reentrancy",
]

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}

# Contracts that handle user funds and MUST have a reclaim/refund path
FUND_HOLDING_CONTRACTS = {
    "htlc",
    "ptlc",
    "atomic_swap",
    "streaming",
    "multisig",
    "portal",
    "commit_channels",
}

ADVERSARIAL_PROMPT = """You are a hostile security auditor reviewing a Zenon
embedded contract implementation written in Go.

Contract name: {contract_name}

Source code:
```go
{source_code}
```

Analyze this code for the following vulnerability classes:
1. Fund theft paths -- can an attacker drain funds?
2. Fund lock paths -- can funds become permanently inaccessible?
3. DoS vectors -- can an attacker halt contract execution?
4. Access control bypasses -- can unauthorized callers invoke privileged methods?
5. Integer overflow / underflow -- are arithmetic operations safe?
6. Reentrancy -- can a malicious callback re-enter the contract?

For each finding, provide:
- category: one of {categories}
- severity: critical / high / medium / low / info
- title: short summary
- description: detailed explanation with code references
- line_hint: approximate line number if possible (0 if unknown)

Return a JSON array of findings.  If no issues found, return an empty array [].
Only return valid JSON, no markdown fences.
"""


def _find_contract_source(contract_name: str) -> Path | None:
    """Locate the Go implementation file for a contract."""
    for go_zenon in GO_ZENON_PATHS:
        if not go_zenon.is_dir():
            continue
        # Check implementation directory
        impl_path = go_zenon / "vm" / "embedded" / "implementation" / f"{contract_name}.go"
        if impl_path.is_file():
            return impl_path
        # Check definition directory
        def_path = go_zenon / "vm" / "embedded" / "definition" / f"{contract_name}.go"
        if def_path.is_file():
            return def_path
    return None


def _find_all_contract_files(contract_name: str) -> list[Path]:
    """Locate all Go files related to a contract (impl + definition)."""
    files = []
    for go_zenon in GO_ZENON_PATHS:
        if not go_zenon.is_dir():
            continue
        for subdir in ("implementation", "definition"):
            path = go_zenon / "vm" / "embedded" / subdir / f"{contract_name}.go"
            if path.is_file():
                files.append(path)
    return files


def read_contract_source(contract_name: str) -> str | None:
    """Read the combined source code for a contract."""
    files = _find_all_contract_files(contract_name)
    if not files:
        return None
    parts = []
    for f in files:
        parts.append(f"// === {f.relative_to(f.parents[4])} ===\n")
        parts.append(f.read_text(encoding="utf-8"))
        parts.append("\n\n")
    return "".join(parts)


def build_review_prompt(contract_name: str, source_code: str) -> str:
    """Build the adversarial review prompt for a contract."""
    return ADVERSARIAL_PROMPT.format(
        contract_name=contract_name,
        source_code=source_code,
        categories=", ".join(REVIEW_CATEGORIES),
    )


def parse_review_response(raw_response: str) -> list[dict]:
    """Parse the LLM response into structured findings.

    Handles both clean JSON and markdown-fenced JSON.
    """
    text = raw_response.strip()
    # Strip markdown fences if present
    if text.startswith("```"):
        lines = text.split("\n")
        lines = [l for l in lines if not l.startswith("```")]
        text = "\n".join(lines)
    try:
        findings = json.loads(text)
        if not isinstance(findings, list):
            findings = [findings]
    except json.JSONDecodeError:
        logger.warning("Failed to parse adversarial review response as JSON")
        return []

    # Validate and normalize findings
    valid = []
    for f in findings:
        if not isinstance(f, dict):
            continue
        finding = {
            "category": f.get("category", "unknown"),
            "severity": f.get("severity", "info").lower(),
            "title": f.get("title", "Untitled finding"),
            "description": f.get("description", ""),
            "line_hint": f.get("line_hint", 0),
        }
        if finding["severity"] not in SEVERITY_ORDER:
            finding["severity"] = "info"
        if finding["category"] not in REVIEW_CATEGORIES:
            finding["category"] = "unknown"
        valid.append(finding)
    return valid


# ---------------------------------------------------------------------------
# Static analysis checks (free, no LLM required)
# ---------------------------------------------------------------------------


def _check_reclaim_path(contract_name: str, source: str, file_path: str) -> list[dict]:
    """Check if fund-holding contracts have a reclaim/refund mechanism."""
    findings = []
    if contract_name not in FUND_HOLDING_CONTRACTS:
        return findings

    reclaim_patterns = re.compile(
        r"(Reclaim|Refund|Cancel|Revoke|Abort|Expire)",
        re.IGNORECASE,
    )
    if not reclaim_patterns.search(source):
        findings.append(
            {
                "category": "fund_lock",
                "severity": "critical",
                "title": f"No reclaim path found in {contract_name}",
                "description": (
                    f"WHAT: {contract_name} handles user funds but has no "
                    f"Reclaim/Refund/Cancel method visible in the source. "
                    f"SO WHAT: If a counterparty disappears or a timeout "
                    f"expires, user funds could be permanently locked with "
                    f"no recovery mechanism. This is the #1 cause of fund "
                    f"loss in time-locked contracts. "
                    f"NOW WHAT: Verify that a reclaim path exists. If missing, "
                    f"implement a time-based reclaim that returns funds to the "
                    f"creator after expiration. File: {file_path}"
                ),
                "line_hint": 0,
                "source_file": file_path,
            }
        )
    return findings


def _check_spork_gate(contract_name: str, source: str, file_path: str) -> list[dict]:
    """Check if the contract has a spork activation gate."""
    findings = []
    # Look for spork check patterns
    spork_patterns = re.compile(
        r"(IsSporkActive|SporkAddress|spork|checkActivation)",
        re.IGNORECASE,
    )
    # Only flag if this looks like a new/custom contract (not base contracts)
    base_contracts = {"pillar", "plasma", "sentinel", "stake", "token", "swap"}
    if contract_name in base_contracts:
        return findings

    if not spork_patterns.search(source):
        findings.append(
            {
                "category": "access_control_bypass",
                "severity": "high",
                "title": f"No spork gate in {contract_name}",
                "description": (
                    f"WHAT: {contract_name} has no spork activation check. "
                    f"SO WHAT: Without a spork gate, this contract activates "
                    f"immediately on deployment rather than requiring network-wide "
                    f"consensus via Pillar vote. A premature activation could "
                    f"corrupt state or allow exploitation before the network is "
                    f"ready. "
                    f"NOW WHAT: Add a spork gate check at the top of every public "
                    f"method: if !isSporkActive {{ return ErrSporkNotActive }}. "
                    f"File: {file_path}"
                ),
                "line_hint": 0,
                "source_file": file_path,
            }
        )
    return findings


def _check_unchecked_errors(contract_name: str, source: str, file_path: str) -> list[dict]:
    """Check for error returns that are silently discarded."""
    findings = []
    lines = source.split("\n")
    unchecked_lines = []

    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        # Pattern: function call with _ for error (common Go anti-pattern)
        if re.match(r".*,\s*_\s*[:=]+\s*\w+\.\w+\(", stripped):
            unchecked_lines.append(i)
        # Pattern: bare function call that likely returns error
        if (
            re.match(r"^\w+\.\w+\(.*\)$", stripped)
            and "log" not in stripped.lower()
            and "fmt." not in stripped
        ):
            # Could be an unchecked error, but many Go patterns are like this
            pass

    if unchecked_lines:
        lines_str = ", ".join(str(l) for l in unchecked_lines[:5])
        more = f" (+{len(unchecked_lines) - 5} more)" if len(unchecked_lines) > 5 else ""
        findings.append(
            {
                "category": "fund_lock",
                "severity": "medium",
                "title": f"Discarded error returns in {contract_name}",
                "description": (
                    f"WHAT: {len(unchecked_lines)} error return(s) are "
                    f"assigned to _ (discarded) at lines {lines_str}{more}. "
                    f"SO WHAT: Silently discarding errors can hide failed state "
                    f"transitions. If a balance update fails silently, funds "
                    f"could be debited without being credited (or vice versa). "
                    f"NOW WHAT: Review each discarded error. Use "
                    f"common.DealWithErr() for 'impossible' errors, or return "
                    f"the error explicitly. File: {file_path}"
                ),
                "line_hint": unchecked_lines[0] if unchecked_lines else 0,
                "source_file": file_path,
            }
        )
    return findings


def _check_access_control(contract_name: str, source: str, file_path: str) -> list[dict]:
    """Check for methods that modify state without sender verification."""
    findings = []
    # Look for methods that do SendBlock (state changes) without
    # checking param.Address or context.Address
    func_pattern = re.compile(
        r"func\s+\([^)]+\)\s+(\w+)\s*\([^)]*\)\s*\([^)]*\)\s*\{",
    )
    sender_check = re.compile(
        r"(param\.Address|context\.Address|block\.Address|sendBlock\.Address"
        r"|msg\.Sender|\.Address\s*==|\.Address\s*!=)",
    )
    # False-positive whitelist (v0.2.23). Pre-fix the regex parser
    # would flag GetPlasma, MarshalJSON, Key, etc. as state-modifying
    # because the function-boundary detection couldn't handle multi-line
    # signatures, so adjacent function bodies got merged. These methods
    # are READ-ONLY by contract — GetPlasma returns the plasma cost,
    # MarshalJSON serializes, Key generates a storage key. They cannot
    # modify state regardless of what the regex sees in the (wrongly
    # merged) body. Whitelist explicit names + name prefixes.
    READ_ONLY_NAMES = {
        "GetPlasma",
        "MarshalJSON",
        "UnmarshalJSON",
        "Key",
        "String",
        "Validate",
    }
    READ_ONLY_PREFIXES = ("Get", "Is", "Has", "List", "Find", "Lookup", "Read")

    # Find function boundaries roughly
    in_func = False
    func_name = ""
    func_start = 0
    func_body = []
    unguarded = []

    def _is_read_only(name: str) -> bool:
        """True for getters, serializers, and validators that can't mutate state."""
        if name in READ_ONLY_NAMES:
            return True
        return any(name.startswith(p) for p in READ_ONLY_PREFIXES)

    for i, line in enumerate(source.split("\n"), 1):
        m = func_pattern.search(line)
        if m:
            # Check previous function
            if in_func and func_body and not _is_read_only(func_name):
                body = "\n".join(func_body)
                has_state_change = bool(
                    re.search(
                        r"(\.Set|\.Delete|\.Save|SendBlock|ReceiveBlock)",
                        body,
                    )
                )
                has_auth = bool(sender_check.search(body))
                if has_state_change and not has_auth:
                    unguarded.append((func_name, func_start))

            func_name = m.group(1)
            func_start = i
            func_body = []
            in_func = True
        elif in_func:
            func_body.append(line)

    # Check last function
    if in_func and func_body and not _is_read_only(func_name):
        body = "\n".join(func_body)
        has_state_change = bool(
            re.search(
                r"(\.Set|\.Delete|\.Save|SendBlock|ReceiveBlock)",
                body,
            )
        )
        has_auth = bool(sender_check.search(body))
        if has_state_change and not has_auth:
            unguarded.append((func_name, func_start))

    if unguarded:
        methods = ", ".join(f"{name} (line {line})" for name, line in unguarded[:5])
        findings.append(
            {
                "category": "access_control_bypass",
                "severity": "high",
                "title": f"State-changing methods without sender check in {contract_name}",
                "description": (
                    f"WHAT: {len(unguarded)} method(s) modify state without "
                    f"verifying the caller's identity: {methods}. "
                    f"SO WHAT: Without access control, any address can call "
                    f"privileged operations — potentially stealing funds, "
                    f"canceling other users' contracts, or corrupting state. "
                    f"NOW WHAT: Add sender verification (param.Address check) "
                    f"to each flagged method. Verify this is not a false "
                    f"positive — some methods are intentionally public. "
                    f"File: {file_path}"
                ),
                "line_hint": unguarded[0][1] if unguarded else 0,
                "source_file": file_path,
            }
        )
    return findings


def _check_unbounded_iteration(contract_name: str, source: str, file_path: str) -> list[dict]:
    """Check for loops over user-controlled data without bounds."""
    findings = []
    lines = source.split("\n")
    unbounded = []

    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        # Pattern: for range over dynamic data (iterator, list, map)
        if re.match(r"for\s+.*range\s+", stripped):
            # Check if there is a break/limit within the next ~20 lines
            context = "\n".join(lines[i : i + 20])
            if not re.search(r"(break|return|limit|max|MAX|count\s*>=)", context):
                unbounded.append(i)

    if unbounded:
        lines_str = ", ".join(str(l) for l in unbounded[:5])
        findings.append(
            {
                "category": "dos_vector",
                "severity": "medium",
                "title": f"Potentially unbounded iteration in {contract_name}",
                "description": (
                    f"WHAT: Range loops at lines {lines_str} iterate over "
                    f"data without visible bounds or break conditions. "
                    f"SO WHAT: If an attacker can grow the iterated "
                    f"collection (e.g., by creating many entries), a single "
                    f"method call could consume all available gas/plasma and "
                    f"halt the network. This is the classic DoS vector in "
                    f"blockchain contracts. "
                    f"NOW WHAT: Add explicit iteration limits. If the loop "
                    f"must process all entries, add pagination or batch "
                    f"processing. Verify the collection has a size cap. "
                    f"File: {file_path}"
                ),
                "line_hint": unbounded[0] if unbounded else 0,
                "source_file": file_path,
            }
        )
    return findings


def _check_integer_safety(contract_name: str, source: str, file_path: str) -> list[dict]:
    """Check for arithmetic on native int types instead of big.Int."""
    findings = []
    # Look for amount/balance arithmetic NOT using big.Int
    lines = source.split("\n")
    risky_lines = []

    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        # Pattern: direct arithmetic on Amount/Balance with native operators
        if (
            re.search(r"(amount|balance|value|total)\s*[\+\-\*]", stripped, re.IGNORECASE)
            and "big.Int" not in stripped
            and "big.NewInt" not in stripped
        ):
            risky_lines.append(i)

    if risky_lines:
        lines_str = ", ".join(str(l) for l in risky_lines[:5])
        findings.append(
            {
                "category": "integer_overflow",
                "severity": "medium",
                "title": f"Native arithmetic on token amounts in {contract_name}",
                "description": (
                    f"WHAT: Lines {lines_str} perform arithmetic on "
                    f"amount/balance/value variables using native operators "
                    f"instead of big.Int. "
                    f"SO WHAT: Native int64 overflows silently in Go. An "
                    f"attacker could craft amounts near max_int64 to cause "
                    f"overflow, potentially creating tokens from nothing or "
                    f"draining balances. "
                    f"NOW WHAT: Use big.Int for ALL token amount arithmetic. "
                    f"Replace native +/-/* with big.Add/Sub/Mul. Verify each "
                    f"flagged line. File: {file_path}"
                ),
                "line_hint": risky_lines[0] if risky_lines else 0,
                "source_file": file_path,
            }
        )
    return findings


def static_review(contract_name: str, db_path: str = DEFAULT_DB) -> list[dict]:
    """Run free static analysis checks on a contract.

    No LLM needed. Checks for common vulnerability patterns and produces
    actionable findings with WHAT / SO WHAT / NOW WHAT.

    Returns list of finding dicts.
    """
    files = _find_all_contract_files(contract_name)
    if not files:
        return []

    # v0.2.23 split: per-contract checks run ONCE on the concatenated
    # source (so spork-gate / reclaim-path don't fire twice on the same
    # contract just because the contract has both an implementation and
    # a definition file). Per-file checks (access control, unchecked
    # errors, unbounded iteration, integer safety) run on each file
    # individually because they need precise line numbers.
    file_data: list[tuple[str, str]] = []  # (relative_path, source)
    for f in files:
        try:
            source = f.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        file_path = str(f.relative_to(f.parents[4]))
        file_data.append((file_path, source))

    if not file_data:
        return []

    all_findings: list[dict] = []

    # PER-CONTRACT checks: run once on the implementation file (or the
    # first available) using its path for the source_file attribution.
    # The spork-gate check looks for "is the spork pattern anywhere in
    # the contract" — pre-fix it ran on each file separately, producing
    # duplicates with different source_file values that escaped dedup.
    impl_file = next(
        (fp for fp, _ in file_data if "/implementation/" in fp),
        file_data[0][0],
    )
    combined_source = "\n".join(src for _, src in file_data)
    all_findings.extend(_check_reclaim_path(contract_name, combined_source, impl_file))
    all_findings.extend(_check_spork_gate(contract_name, combined_source, impl_file))

    # PER-FILE checks: line numbers must point to the right file.
    for file_path, source in file_data:
        all_findings.extend(_check_unchecked_errors(contract_name, source, file_path))
        all_findings.extend(_check_access_control(contract_name, source, file_path))
        all_findings.extend(_check_unbounded_iteration(contract_name, source, file_path))
        all_findings.extend(_check_integer_safety(contract_name, source, file_path))

    return all_findings


def static_review_all(
    contract_names: list[str] | None = None,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Run static analysis on all known contracts.

    Returns dict with per-contract findings and an actionable summary.
    """
    if contract_names is None:
        # Discover contracts from go-zenon implementation directory
        contract_names = []
        for go_zenon in GO_ZENON_PATHS:
            impl_dir = go_zenon / "vm" / "embedded" / "implementation"
            if impl_dir.is_dir():
                for f in sorted(impl_dir.iterdir()):
                    if f.suffix == ".go" and not f.name.startswith("_"):
                        name = f.stem
                        if name not in contract_names:
                            contract_names.append(name)

    all_results = {}
    total_critical = 0
    total_high = 0
    total_findings = 0

    for name in contract_names:
        findings = static_review(name, db_path=db_path)
        if findings:
            all_results[name] = findings
            for f in findings:
                total_findings += 1
                if f["severity"] == "critical":
                    total_critical += 1
                elif f["severity"] == "high":
                    total_high += 1

    # Build actionable summary
    if total_critical > 0:
        summary = (
            f"WHAT: Static analysis found {total_findings} issues across "
            f"{len(all_results)} contracts — {total_critical} CRITICAL, "
            f"{total_high} HIGH. "
            f"SO WHAT: Critical findings indicate possible fund loss or "
            f"unauthorized access. These MUST be resolved before any "
            f"upstream PR submission. "
            f"NOW WHAT: Fix critical issues first. Contracts with critical "
            f"findings: {', '.join(n for n, fs in all_results.items() if any(f['severity'] == 'critical' for f in fs))}."
        )
    elif total_high > 0:
        summary = (
            f"WHAT: Static analysis found {total_findings} issues across "
            f"{len(all_results)} contracts — {total_high} HIGH severity. "
            f"SO WHAT: High-severity findings could allow exploitation "
            f"under specific conditions. Review before upstream submission. "
            f"NOW WHAT: Review each high-severity finding. Some may be "
            f"false positives — verify against the actual contract logic."
        )
    elif total_findings > 0:
        summary = (
            f"WHAT: Static analysis found {total_findings} low/medium "
            f"issues across {len(all_results)} contracts. "
            f"SO WHAT: No critical or high-severity issues detected. "
            f"These are code quality improvements, not blockers. "
            f"NOW WHAT: Address medium issues during next refactor cycle. "
            f"Low/info findings can be tracked but are not urgent."
        )
    else:
        summary = (
            f"WHAT: Static analysis of {len(contract_names)} contracts "
            f"found no issues. "
            f"SO WHAT: No common vulnerability patterns detected by "
            f"automated checks. This does NOT mean the code is secure — "
            f"static analysis catches patterns, not logic bugs. "
            f"NOW WHAT: Run LLM-based adversarial review for deeper "
            f"analysis of logic vulnerabilities."
        )

    return {
        "contracts_scanned": len(contract_names),
        "contracts_with_findings": len(all_results),
        "total_findings": total_findings,
        "critical": total_critical,
        "high": total_high,
        "findings": all_results,
        "summary": summary,
    }


def _build_github_url(file_path: str, line: int, commit: str) -> str | None:
    """Build a permalink to the exact file:line on GitHub.

    ``file_path`` comes in as ``go-zenon/vm/embedded/...`` but the
    GitHub URL needs the path RELATIVE to the repo root, so we strip
    the leading ``go-zenon/``. Falls back to the ``main`` branch if
    the commit hash couldn't be resolved.
    """
    if not file_path:
        return None
    rel = file_path
    if rel.startswith("go-zenon/"):
        rel = rel[len("go-zenon/") :]
    ref = commit or "main"
    url = f"https://github.com/zenon-network/go-zenon/blob/{ref}/{rel}"
    if line and line > 0:
        url = f"{url}#L{line}"
    return url


def persist_static_findings(
    results: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist static analysis findings to both security_reviews and evidence.

    Returns count of findings persisted.
    """
    count = 0

    # v0.2.23: pull go-zenon HEAD once per persist call (NOT per
    # contract) so every finding gets a real source_commit and a
    # clickable GitHub permalink. Falls back gracefully when the
    # workspace isn't installed (then findings reference the `main`
    # branch instead of an exact commit).
    go_zenon_commit = ""
    try:
        from core.git_cache import get_repo_head
        from core.workspace import workspace_repo

        gz_path = workspace_repo("core/go-zenon")
        if gz_path is not None:
            go_zenon_commit = get_repo_head(str(gz_path)) or ""
    except Exception as exc:
        logger.debug("Could not resolve go-zenon HEAD: %s", exc)

    for contract_name, findings in results.get("findings", {}).items():
        for f in findings:
            line_hint = f.get("line_hint", 0)
            file_path = f.get("source_file", "")
            verification_url = _build_github_url(file_path, line_hint, go_zenon_commit)

            # Persist to security_reviews table
            persist_metric(
                db_path=db_path,
                table="security_reviews",
                data={
                    "contract_name": contract_name,
                    "engine": "adversarial_reviewer_static",
                    "severity": f["severity"],
                    "category": f["category"],
                    "title": f["title"],
                    "description": f["description"],
                    "line_number": line_hint,
                    "confidence": 0.7,
                },
            )

            # Persist to unified evidence with full source provenance
            persist_finding(
                db_path=db_path,
                domain="security",
                engine="adversarial_reviewer",
                evidence_type=f"static_{f['category']}",
                finding=f["description"],
                confidence=0.7,
                raw_data=f,
                source_repo="go-zenon",
                source_file=file_path,
                source_commit=go_zenon_commit or None,
                source_line=line_hint or None,
                verification_url=verification_url,
            )
            count += 1

    # Persist summary
    persist_finding(
        db_path=db_path,
        domain="security",
        engine="adversarial_reviewer",
        evidence_type="static_review_summary",
        finding=results.get("summary", ""),
        confidence=0.85,
        raw_data={
            "contracts_scanned": results.get("contracts_scanned", 0),
            "total_findings": results.get("total_findings", 0),
            "critical": results.get("critical", 0),
            "high": results.get("high", 0),
        },
        source_repo="go-zenon",
    )
    count += 1

    logger.info(
        "AdversarialReviewer: persisted %d static analysis findings",
        count,
    )
    return count


# ---------------------------------------------------------------------------
# LLM-based review (existing functionality, preserved)
# ---------------------------------------------------------------------------


def persist_findings(
    contract_name: str,
    findings: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist security findings to the database.

    Returns the number of findings persisted.
    """
    if not findings:
        return 0
    for f in findings:
        persist_metric(
            db_path=db_path,
            table="security_reviews",
            data={
                "contract_name": contract_name,
                "engine": "adversarial_reviewer",
                "severity": f["severity"],
                "category": f["category"],
                "title": f["title"],
                "description": f["description"],
                "line_number": f.get("line_hint", 0),
                "confidence": f.get("confidence", 0.7),
            },
        )
    return len(findings)


def get_review_summary(
    contract_name: str,
    *,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Get a summary of findings for a contract."""
    conn = connect(db_path)
    try:
        rows = conn.execute(
            """SELECT severity, COUNT(*) FROM security_reviews
               WHERE contract_name = ? AND engine = 'adversarial_reviewer'
               GROUP BY severity""",
            (contract_name,),
        ).fetchall()
        summary = dict.fromkeys(SEVERITY_ORDER, 0)
        for sev, count in rows:
            summary[sev] = count
        summary["total"] = sum(summary.values())
        return summary
    finally:
        conn.close()


def review_contract(
    contract_name: str,
    *,
    llm_call=None,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Run a full adversarial review of a contract.

    Always runs static analysis. Optionally runs LLM review if llm_call
    is provided.

    Args:
        contract_name: Name of the embedded contract (e.g. 'htlc').
        llm_call: Callable that takes a prompt string and returns LLM response.
                  If None, only static analysis runs (free).
        db_path: Path to the SQLite database.

    Returns:
        Dict with keys: contract_name, source_found, static_findings,
        llm_findings, persisted_count.
    """
    source = read_contract_source(contract_name)
    if source is None:
        return {
            "contract_name": contract_name,
            "source_found": False,
            "findings": [],
            "static_findings": [],
            "llm_findings": [],
            "persisted_count": 0,
        }

    # Always run static analysis (free)
    static = static_review(contract_name, db_path=db_path)

    result = {
        "contract_name": contract_name,
        "source_found": True,
        "findings": [],  # backward compat: populated by LLM review below
        "static_findings": static,
        "llm_findings": [],
        "persisted_count": 0,
    }

    # Persist static findings
    if static:
        critical_count = sum(1 for f in static if f["severity"] == "critical")
        high_count = sum(1 for f in static if f["severity"] == "high")
        # Build a real WHAT/SO WHAT/NOW WHAT summary so the downstream
        # plausibility gate doesn't reject the static_review_summary row.
        # Leaving summary="" here made every cycle of the harden run
        # log "Finding text is empty" and inflated the persisted count.
        if critical_count > 0:
            severity_blurb = (
                f"{critical_count} CRITICAL and {high_count} HIGH severity "
                "findings indicate possible fund loss or unauthorized access."
            )
            now_what = "Fix critical issues before any upstream PR submission."
        elif high_count > 0:
            severity_blurb = (
                f"{high_count} HIGH severity findings could allow exploitation "
                "under specific conditions."
            )
            now_what = "Review each high-severity finding and verify against contract logic."
        else:
            severity_blurb = "No critical or high severity issues detected."
            now_what = "Address medium findings during next refactor cycle."
        static_summary = (
            f"WHAT: Static analysis of {contract_name} found {len(static)} "
            f"issues. SO WHAT: {severity_blurb} NOW WHAT: {now_what}"
        )
        static_results = {
            "findings": {contract_name: static},
            "contracts_scanned": 1,
            "total_findings": len(static),
            "critical": critical_count,
            "high": high_count,
            "summary": static_summary,
        }
        result["persisted_count"] += persist_static_findings(
            static_results,
            db_path=db_path,
        )

    # Run LLM review if available
    if llm_call is not None:
        prompt = build_review_prompt(contract_name, source)
        raw = llm_call(prompt)
        llm_findings = parse_review_response(raw)
        result["llm_findings"] = llm_findings
        result["findings"] = llm_findings  # backward compat
        result["persisted_count"] += persist_findings(
            contract_name,
            llm_findings,
            db_path=db_path,
        )

    return result


# ---------------------------------------------------------------------------
# Auto-discoverable wrapper for the autonomous scheduler
# ---------------------------------------------------------------------------

KNOWN_CONTRACTS: tuple[str, ...] = (
    "htlc",
    "ptlc",
    "bridge",
    "governance",
    "plasma",
    "pillar",
    "sentinel",
    "spork",
    "stake",
    "swap",
    "token",
    "accelerator",
    "liquidity",
)


def run_all_contracts(
    *,
    db_path: str = DEFAULT_DB,
    llm_call=None,
) -> dict:
    """Run :func:`review_contract` against every known embedded contract.

    This is the zero-arg entry point the autonomous scheduler picks up
    automatically. Contracts whose source cannot be found (because the
    Zenon workspace is not present) are skipped silently so Nebula
    keeps running on portable installs.

    Args:
        db_path: Path to the engine SQLite database.
        llm_call: Optional LLM callable for deeper review.

    Returns:
        Dict with per-contract summary counts and a total.
    """
    summary = {
        "scanned": 0,
        "skipped": 0,
        "total_findings": 0,
        "per_contract": {},
    }
    for contract in KNOWN_CONTRACTS:
        try:
            result = review_contract(contract, llm_call=llm_call, db_path=db_path)
        except Exception as exc:  # defensive - never abort the sweep
            logger.debug("adversarial_reviewer skipped %s: %s", contract, exc)
            summary["skipped"] += 1
            continue
        if not result.get("source_found"):
            summary["skipped"] += 1
            continue
        summary["scanned"] += 1
        findings = len(result.get("static_findings", [])) + len(result.get("llm_findings", []))
        summary["total_findings"] += findings
        summary["per_contract"][contract] = findings
    return summary
