# SPDX-License-Identifier: MIT
"""
AttackSimulator -- Model economic attacks against Zenon's network.

Calculates the cost and feasibility of various attack vectors using
on-chain data from the zenonhub API and known protocol parameters.

Attack models:
1. Governance takeover -- pillar registration cost to control voting
2. Delegation concentration -- stake needed for 51% delegation weight
3. Bridge attack cost -- cost to compromise Portal relayers
4. Treasury drain -- governance attack to approve fraudulent AZ proposals
5. Spam attack cost -- plasma burn rate to fill blocks and halt network

No LLM calls.  Computation from API data + protocol constants.
"""

import logging
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path

from core.persist_to_db import ensure_schema, persist_finding
from core.zenon_data import TOKEN_DECIMALS, get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# ---------------------------------------------------------------------------
# Protocol constants (from go-zenon source)
# ---------------------------------------------------------------------------

# Pillar registration cost (ZNN)
PILLAR_REGISTRATION_ZNN = 15000
# Pillar registration QSR burned
PILLAR_REGISTRATION_QSR_BURN = 150000
# Sentinel registration cost
SENTINEL_REGISTRATION_ZNN = 5000
SENTINEL_REGISTRATION_QSR = 50000
# Minimum delegation amount
MIN_DELEGATION_ZNN = 1  # 1 ZNN minimum
# Plasma fuse cost (QSR per unit)
PLASMA_FUSE_QSR_PER_UNIT = 10
# Block time (seconds)
MOMENTUM_TIME_SECONDS = 10
# Max account blocks per momentum
MAX_ACCOUNT_BLOCKS_PER_MOMENTUM = 100
# AZ proposal amounts (max per proposal)
AZ_MAX_ZNN_PER_PHASE = 5000
AZ_MAX_QSR_PER_PHASE = 50000

API_TIMEOUT = 15


@dataclass
class NetworkStats:
    """Current network statistics sourced from the Zenon node."""

    total_pillars: int = 0
    total_sentinels: int = 0
    total_znn_supply: float = 0.0
    total_qsr_supply: float = 0.0
    total_delegated_znn: float = 0.0
    znn_price_usd: float = 0.0
    qsr_price_usd: float = 0.0
    az_funds_znn: float = 0.0
    az_funds_qsr: float = 0.0
    active_pillars: int = 0
    api_available: bool = False


def fetch_network_stats() -> NetworkStats:
    """Collect live network statistics via Zenon JSON-RPC.

    Falls back to conservative constants when the node is unreachable so
    the simulation models still run during degraded operation.
    """
    stats = NetworkStats()
    rpc = get_zenon_data()

    pillars = rpc.get_all_pillars(page=0, count=500)
    if pillars:
        stats.total_pillars = len(pillars)
        stats.active_pillars = sum(1 for p in pillars if p.get("isRevocable", True) is not False)
        delegated_raw = 0
        for p in pillars:
            try:
                delegated_raw += int(p.get("weight", p.get("delegatedWeight", 0)))
            except (TypeError, ValueError):
                continue
        stats.total_delegated_znn = delegated_raw / TOKEN_DECIMALS
        stats.api_available = True

    sentinel_count = rpc.get_sentinel_count()
    if sentinel_count is not None:
        stats.total_sentinels = int(sentinel_count)

    az_balance = rpc.get_az_balance()
    stats.az_funds_znn = az_balance["znn"] / TOKEN_DECIMALS
    stats.az_funds_qsr = az_balance["qsr"] / TOKEN_DECIMALS

    # Optional: fill prices from env overrides if the operator wants
    # deterministic simulations. Otherwise leave at 0 and the cost_usd
    # columns simply show 0.
    try:
        stats.znn_price_usd = float(os.environ.get("ZNN_PRICE_USD", 0) or 0)
    except ValueError:
        stats.znn_price_usd = 0.0
    try:
        stats.qsr_price_usd = float(os.environ.get("QSR_PRICE_USD", 0) or 0)
    except ValueError:
        stats.qsr_price_usd = 0.0

    # Conservative fallbacks if the node is unreachable.
    if stats.total_pillars == 0:
        stats.total_pillars = 90
    if stats.total_znn_supply == 0:
        stats.total_znn_supply = 10_000_000
    if stats.total_qsr_supply == 0:
        stats.total_qsr_supply = 50_000_000

    return stats


# ---------------------------------------------------------------------------
# Attack models
# ---------------------------------------------------------------------------


@dataclass
class AttackResult:
    """Result of an attack simulation."""

    attack_name: str
    risk_level: str  # "critical", "high", "medium", "low"
    cost_znn: float = 0.0
    cost_qsr: float = 0.0
    cost_usd: float = 0.0
    description: str = ""
    assumptions: list[str] = field(default_factory=list)
    mitigations: list[str] = field(default_factory=list)


def simulate_governance_takeover(stats: NetworkStats) -> AttackResult:
    """Calculate cost to register enough pillars to control governance voting.

    Governance proposals require >50% of voting pillars to approve.
    An attacker needs (total_pillars / 2) + 1 new pillars.
    """
    current = stats.total_pillars
    # Need more than 50% of total after adding attacker pillars
    # If attacker registers N pillars, total becomes current + N
    # Attacker needs N > (current + N) / 2, so N > current
    # In practice, not all pillars vote, so we model 60% participation
    participation_rate = 0.60
    voting_pillars = int(current * participation_rate)
    needed_pillars = voting_pillars + 1  # Simple majority of voting pillars

    cost_znn = needed_pillars * PILLAR_REGISTRATION_ZNN
    cost_qsr = needed_pillars * PILLAR_REGISTRATION_QSR_BURN
    cost_usd = cost_znn * stats.znn_price_usd + cost_qsr * stats.qsr_price_usd

    # Risk assessment
    if cost_usd > 0 and cost_usd < 1_000_000:
        risk = "critical"
    elif cost_usd > 0 and cost_usd < 10_000_000:
        risk = "high"
    elif cost_usd > 0:
        risk = "medium"
    else:
        risk = "medium"  # Cannot determine without price data

    return AttackResult(
        attack_name="governance_takeover",
        risk_level=risk,
        cost_znn=cost_znn,
        cost_qsr=cost_qsr,
        cost_usd=cost_usd,
        description=(
            f"Governance takeover requires registering {needed_pillars} "
            f"pillars to outvote {voting_pillars} active voters "
            f"(assuming {participation_rate:.0%} participation of "
            f"{current} total pillars). "
            f"Cost: {cost_znn:,.0f} ZNN + {cost_qsr:,.0f} QSR burned"
            f"{f' (${cost_usd:,.0f} USD)' if cost_usd > 0 else ''}."
        ),
        assumptions=[
            f"Total pillars: {current}",
            f"Participation rate: {participation_rate:.0%}",
            f"ZNN price: ${stats.znn_price_usd:.4f}"
            if stats.znn_price_usd
            else "ZNN price: unknown",
            f"QSR price: ${stats.qsr_price_usd:.4f}"
            if stats.qsr_price_usd
            else "QSR price: unknown",
        ],
        mitigations=[
            "Time-locked pillar registration (14-day revocation cooldown)",
            "Momentum-based voting (one pillar one vote, not stake-weighted)",
            "Community can detect mass pillar registrations on-chain",
            "Spork activation requires separate consensus mechanism",
        ],
    )


def simulate_delegation_concentration(stats: NetworkStats) -> AttackResult:
    """Calculate stake needed to control 51% of delegation weight.

    Delegation concentration affects reward distribution and could
    influence which pillars produce momentums.
    """
    total_delegated = stats.total_delegated_znn
    if total_delegated == 0:
        total_delegated = stats.total_znn_supply * 0.3  # Estimate 30% staked

    needed_znn = total_delegated * 0.51
    cost_usd = needed_znn * stats.znn_price_usd

    supply_pct = (needed_znn / stats.total_znn_supply * 100) if stats.total_znn_supply else 0

    if supply_pct > 30:
        risk = "low"
    elif supply_pct > 15:
        risk = "medium"
    else:
        risk = "high"

    return AttackResult(
        attack_name="delegation_concentration",
        risk_level=risk,
        cost_znn=needed_znn,
        cost_usd=cost_usd,
        description=(
            f"Controlling 51% of delegation weight requires "
            f"{needed_znn:,.0f} ZNN ({supply_pct:.1f}% of total supply)"
            f"{f' (${cost_usd:,.0f} USD)' if cost_usd > 0 else ''}. "
            f"Current total delegated: {total_delegated:,.0f} ZNN."
        ),
        assumptions=[
            f"Total delegated ZNN: {total_delegated:,.0f}",
            f"Total ZNN supply: {stats.total_znn_supply:,.0f}",
            f"ZNN price: ${stats.znn_price_usd:.4f}"
            if stats.znn_price_usd
            else "ZNN price: unknown",
        ],
        mitigations=[
            "Pillar selection is not purely delegation-weighted",
            "Delegation changes are visible on-chain",
            "Community monitoring of large delegation shifts",
            "Multiple pillar operators required for consensus",
        ],
    )


def simulate_bridge_attack(stats: NetworkStats) -> AttackResult:
    """Estimate cost to compromise Portal bridge relayers.

    Portal uses TSS (Threshold Signature Scheme) with guardian pillars.
    An attacker needs to compromise the threshold number of guardians.
    """
    # Portal guardian set is a subset of active pillars
    # Typical TSS threshold is 2/3 + 1
    guardian_count = min(stats.active_pillars, 15)  # Guardians are a subset
    if guardian_count == 0:
        guardian_count = 15  # Estimate
    threshold = (guardian_count * 2 // 3) + 1

    # Cost to compromise = cost to register and control threshold pillars
    cost_znn = threshold * PILLAR_REGISTRATION_ZNN
    cost_qsr = threshold * PILLAR_REGISTRATION_QSR_BURN
    cost_usd = cost_znn * stats.znn_price_usd + cost_qsr * stats.qsr_price_usd

    risk = "medium"  # TSS with 2/3 threshold is relatively secure
    if guardian_count < 7:
        risk = "high"  # Small guardian set is riskier

    return AttackResult(
        attack_name="bridge_attack",
        risk_level=risk,
        cost_znn=cost_znn,
        cost_qsr=cost_qsr,
        cost_usd=cost_usd,
        description=(
            f"Bridge attack requires compromising {threshold} of "
            f"{guardian_count} guardians (2/3 TSS threshold). "
            f"Minimum cost: {cost_znn:,.0f} ZNN + {cost_qsr:,.0f} QSR"
            f"{f' (${cost_usd:,.0f} USD)' if cost_usd > 0 else ''}. "
            f"Note: this models only the economic cost of pillar registration, "
            f"not the operational difficulty of key compromise."
        ),
        assumptions=[
            f"Guardian count: {guardian_count}",
            f"TSS threshold: {threshold} of {guardian_count}",
            "Assumes attacker must register new pillars (cannot compromise existing)",
            f"ZNN price: ${stats.znn_price_usd:.4f}"
            if stats.znn_price_usd
            else "ZNN price: unknown",
        ],
        mitigations=[
            "TSS requires threshold cooperation (no single point of failure)",
            "Guardian pillars are selected by governance (not self-elected)",
            "Bridge has time-lock on large withdrawals",
            "Halting mechanism can freeze bridge in emergency",
            "DKG ceremony requires participation (key cannot be stolen at rest)",
        ],
    )


def simulate_treasury_drain(stats: NetworkStats) -> AttackResult:
    """Calculate cost of a governance attack to drain AZ treasury.

    An attacker who controls governance could approve fraudulent
    Accelerator-Z proposals to drain the treasury.
    """
    # First, need governance control (same as governance takeover)
    governance = simulate_governance_takeover(stats)

    # AZ treasury value
    az_znn = stats.az_funds_znn if stats.az_funds_znn else 100_000  # Estimate
    az_qsr = stats.az_funds_qsr if stats.az_funds_qsr else 1_000_000
    treasury_usd = az_znn * stats.znn_price_usd + az_qsr * stats.qsr_price_usd

    # Attack cost vs reward
    attack_cost_usd = governance.cost_usd
    profit_usd = treasury_usd - attack_cost_usd if treasury_usd > attack_cost_usd else 0

    if profit_usd > 0 and attack_cost_usd > 0:
        risk = "high" if profit_usd > attack_cost_usd else "medium"
    else:
        risk = "low"

    return AttackResult(
        attack_name="treasury_drain",
        risk_level=risk,
        cost_znn=governance.cost_znn,
        cost_qsr=governance.cost_qsr,
        cost_usd=attack_cost_usd,
        description=(
            f"Treasury drain requires governance takeover "
            f"({governance.cost_znn:,.0f} ZNN) then approving fraudulent "
            f"AZ proposals. Treasury holds ~{az_znn:,.0f} ZNN + "
            f"~{az_qsr:,.0f} QSR"
            f"{f' (${treasury_usd:,.0f} USD)' if treasury_usd > 0 else ''}. "
            f"Max drain per phase: {AZ_MAX_ZNN_PER_PHASE} ZNN + "
            f"{AZ_MAX_QSR_PER_PHASE} QSR (rate-limited). "
            f"{f'Net profit potential: ${profit_usd:,.0f} USD. ' if profit_usd > 0 else 'Attack cost exceeds treasury value. '}"
        ),
        assumptions=[
            f"AZ treasury: ~{az_znn:,.0f} ZNN + ~{az_qsr:,.0f} QSR",
            f"Governance takeover cost: {governance.cost_znn:,.0f} ZNN",
            f"Max per phase: {AZ_MAX_ZNN_PER_PHASE} ZNN + {AZ_MAX_QSR_PER_PHASE} QSR",
        ],
        mitigations=[
            "AZ proposals have per-phase withdrawal limits",
            "Multi-phase approval process (project + phase votes)",
            "Community review period for all proposals",
            "Pillar operators can vote NO and alert the community",
            "Governance takeover itself is expensive and visible",
        ],
    )


def simulate_spam_attack(stats: NetworkStats) -> AttackResult:
    """Calculate cost to fill all plasma and halt the network.

    Spam attack requires fusing enough QSR for plasma to fill every
    momentum with junk transactions.
    """
    # Each momentum can hold MAX_ACCOUNT_BLOCKS_PER_MOMENTUM transactions
    # Each transaction needs plasma, which costs QSR to fuse
    # Minimum plasma per tx ~21000, fuse rate: 10 QSR per 2100 plasma
    min_plasma_per_tx = 21000
    qsr_per_tx = (min_plasma_per_tx / 2100) * PLASMA_FUSE_QSR_PER_UNIT

    # To fill blocks for 1 hour
    momentums_per_hour = 3600 / MOMENTUM_TIME_SECONDS
    txs_per_hour = momentums_per_hour * MAX_ACCOUNT_BLOCKS_PER_MOMENTUM
    qsr_for_one_hour = txs_per_hour * qsr_per_tx
    cost_usd_one_hour = qsr_for_one_hour * stats.qsr_price_usd

    # QSR is fused (locked), not burned -- recoverable after un-fuse
    # But attacker needs the capital upfront
    supply_pct = (qsr_for_one_hour / stats.total_qsr_supply * 100) if stats.total_qsr_supply else 0

    if supply_pct > 50:
        risk = "low"  # Too expensive
    elif supply_pct > 10:
        risk = "medium"
    else:
        risk = "high"  # Cheap enough to be feasible

    return AttackResult(
        attack_name="spam_attack",
        risk_level=risk,
        cost_qsr=qsr_for_one_hour,
        cost_usd=cost_usd_one_hour,
        description=(
            f"Filling all block space for 1 hour requires "
            f"{txs_per_hour:,.0f} transactions using "
            f"{qsr_for_one_hour:,.0f} QSR fused for plasma "
            f"({supply_pct:.1f}% of QSR supply)"
            f"{f' (${cost_usd_one_hour:,.0f} USD)' if cost_usd_one_hour > 0 else ''}. "
            f"QSR is fused (locked), not burned -- recoverable after attack."
        ),
        assumptions=[
            f"Momentums per hour: {momentums_per_hour:,.0f}",
            f"Max txs per momentum: {MAX_ACCOUNT_BLOCKS_PER_MOMENTUM}",
            f"QSR per tx (minimum): {qsr_per_tx:.0f}",
            f"Total QSR supply: {stats.total_qsr_supply:,.0f}",
            f"QSR price: ${stats.qsr_price_usd:.4f}"
            if stats.qsr_price_usd
            else "QSR price: unknown",
        ],
        mitigations=[
            "Plasma is fused, not burned (capital cost, not expenditure)",
            "Dynamic Plasma (planned) will increase cost under congestion",
            "Priority transactions can still get through with higher plasma",
            "Network can process legitimate traffic during partial spam",
            "Pillar operators can prioritize transactions",
        ],
    )


# ---------------------------------------------------------------------------
# Top-level API
# ---------------------------------------------------------------------------


def simulate_all() -> dict:
    """Run all attack simulations and return results.

    Returns dict with attack results and network stats used.
    """
    stats = fetch_network_stats()

    attacks = [
        simulate_governance_takeover(stats),
        simulate_delegation_concentration(stats),
        simulate_bridge_attack(stats),
        simulate_treasury_drain(stats),
        simulate_spam_attack(stats),
    ]

    # Determine overall risk level (worst case)
    risk_order = {"critical": 4, "high": 3, "medium": 2, "low": 1}
    max_risk = max(attacks, key=lambda a: risk_order.get(a.risk_level, 0))

    return {
        "attacks": [asdict(a) for a in attacks],
        "network_stats": asdict(stats),
        "overall_risk": max_risk.risk_level,
        "api_available": stats.api_available,
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run all attack simulations and persist findings.

    Returns the number of findings persisted.
    """
    ensure_schema(db_path)
    report = simulate_all()
    count = 0

    overall_risk = report["overall_risk"]
    api_ok = report["api_available"]
    n_attacks = len(report["attacks"])

    # Summary finding
    risk_counts = {}
    for atk in report["attacks"]:
        rl = atk["risk_level"]
        risk_counts[rl] = risk_counts.get(rl, 0) + 1

    risk_summary = ", ".join(
        f"{c} {r}"
        for r, c in sorted(
            risk_counts.items(),
            key=lambda x: -{"critical": 4, "high": 3, "medium": 2, "low": 1}.get(x[0], 0),
        )
    )

    persist_finding(
        db_path=db_path,
        domain="security",
        engine="attack_simulator",
        evidence_type="attack_simulation_summary",
        finding=(
            f"WHAT: Simulated {n_attacks} economic attack vectors against "
            f"Zenon network. Overall risk: {overall_risk.upper()}. "
            f"Breakdown: {risk_summary}. "
            f"{'API data: live network stats used. ' if api_ok else 'API data: unavailable, using conservative estimates. '}"
            f"SO WHAT: {'Critical/high risk attacks identified that could be economically feasible. ' if overall_risk in ('critical', 'high') else ''}"
            f"{'All simulated attacks have medium/low risk or are economically infeasible. ' if overall_risk in ('medium', 'low') else ''}"
            f"NOW WHAT: {'Review high-risk attack vectors and strengthen mitigations. ' if overall_risk in ('critical', 'high') else ''}"
            f"{'Continue monitoring as market conditions change attack economics. '}"
        ),
        confidence=0.70 if api_ok else 0.50,
        raw_data={
            "overall_risk": overall_risk,
            "risk_counts": risk_counts,
            "api_available": api_ok,
        },
        source_repo="workspace",
    )
    count += 1

    # Individual attack findings
    for atk in report["attacks"]:
        risk = atk["risk_level"]
        name = atk["attack_name"]

        persist_finding(
            db_path=db_path,
            domain="security",
            engine="attack_simulator",
            evidence_type=f"attack_{name}",
            finding=(
                f"WHAT: {name.replace('_', ' ').title()} -- "
                f"risk level: {risk.upper()}. "
                f"{atk['description']} "
                f"SO WHAT: {'This attack vector is economically feasible and poses a real threat. ' if risk in ('critical', 'high') else ''}"
                f"{'This attack is expensive enough to deter most adversaries. ' if risk in ('medium', 'low') else ''}"
                f"NOW WHAT: Mitigations: {'; '.join(atk['mitigations'][:3])}."
            ),
            confidence=0.75 if api_ok else 0.50,
            raw_data=atk,
            source_repo="workspace",
        )
        count += 1

    logger.info(
        "AttackSimulator: persisted %d findings (overall risk: %s)",
        count,
        overall_risk,
    )
    return count
