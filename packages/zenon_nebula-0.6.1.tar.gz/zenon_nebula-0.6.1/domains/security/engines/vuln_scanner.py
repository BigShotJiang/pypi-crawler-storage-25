# SPDX-License-Identifier: MIT
"""
VulnScanner -- Backward-compatible pattern-based vulnerability scanner.

Historically, vuln_scanner was a separate engine that ran regex-based
vulnerability patterns against Go contract source, while static_analyzer
handled structural checks. The two engines had overlapping responsibilities
(both read contract files, both report findings to ``security_reviews``),
so the regex patterns were merged into :mod:`static_analyzer`.

This module is now a thin compatibility wrapper:

- All patterns and pattern helpers are re-exported from
  :mod:`static_analyzer`.
- ``scan_file`` / ``scan_contract`` / ``scan_all_contracts`` delegate to
  :func:`static_analyzer.scan_file_with_patterns` so existing callers
  (tests, the scheduler, and cost-optimizer history keyed on the engine
  name ``"vuln_scanner"``) continue to work without changes.
- Findings persisted via :func:`persist_scan_results` still record the
  engine name ``"vuln_scanner"`` for database compatibility.

New code should prefer calling :mod:`static_analyzer` directly.
"""

import logging
from pathlib import Path

from core.persist_to_db import persist_finding, persist_metric
from core.workspace import workspace_root_or_nebula
from domains.security.analysis import (
    DEFAULT_PATTERNS,
    get_default_patterns,
    load_patterns,
    scan_file_with_patterns,
    seed_patterns,
)

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
ZENON_WORKSPACE = workspace_root_or_nebula()

GO_ZENON_PATHS = [
    ZENON_WORKSPACE / "core" / "go-zenon",
    ZENON_WORKSPACE / "network" / "go-zenon",
]


__all__ = [
    "DEFAULT_DB",
    "DEFAULT_PATTERNS",
    "GO_ZENON_PATHS",
    "get_default_patterns",
    "load_patterns",
    "persist_scan_results",
    "scan_all_contracts",
    "scan_contract",
    "scan_file",
    "seed_patterns",
]


def _find_contract_files(contract_name: str | None = None) -> list[Path]:
    """Find Go source files to scan.

    If ``contract_name`` is given, find files for that contract only.
    Otherwise, find all embedded contract files under ``implementation``
    and ``definition`` directories in every known go-zenon checkout.
    """
    files = []
    for go_zenon in GO_ZENON_PATHS:
        if not go_zenon.is_dir():
            continue
        for subdir in ("implementation", "definition"):
            dir_path = go_zenon / "vm" / "embedded" / subdir
            if not dir_path.is_dir():
                continue
            if contract_name:
                path = dir_path / f"{contract_name}.go"
                if path.is_file():
                    files.append(path)
            else:
                files.extend(dir_path.glob("*.go"))
    return files


def scan_file(file_path: Path, patterns: list[dict]) -> list[dict]:
    """Scan a single file against pattern list. Delegates to static_analyzer.

    Retained for backward compatibility with existing tests and callers
    that import ``scan_file`` from this module.
    """
    return scan_file_with_patterns(file_path, patterns)


def scan_contract(
    contract_name: str,
    *,
    patterns: list[dict] | None = None,
    db_path: str = DEFAULT_DB,
) -> list[dict]:
    """Scan a specific contract for pattern-based vulnerabilities.

    Returns a list of match dicts.
    """
    if patterns is None:
        patterns = load_patterns(db_path=db_path)
    files = _find_contract_files(contract_name)
    all_matches: list[dict] = []
    for f in files:
        all_matches.extend(scan_file_with_patterns(f, patterns))
    return all_matches


def scan_all_contracts(
    *,
    patterns: list[dict] | None = None,
    db_path: str = DEFAULT_DB,
) -> dict[str, list[dict]]:
    """Scan all embedded contracts for pattern-based vulnerabilities.

    Skips work if go-zenon HEAD hasn't changed since the last check.
    Returns a dict mapping ``contract_name`` to list of matches.
    """
    from core.git_cache import has_repo_changed

    any_changed = False
    for go_zenon in GO_ZENON_PATHS:
        if go_zenon.is_dir() and has_repo_changed(str(go_zenon)):
            any_changed = True
            break
    if not any_changed:
        logger.debug("Skipping vuln scan - go-zenon HEAD unchanged")
        return {}

    if patterns is None:
        patterns = load_patterns(db_path=db_path)
    files = _find_contract_files()
    results: dict[str, list[dict]] = {}
    for f in files:
        contract_name = f.stem
        matches = scan_file_with_patterns(f, patterns)
        if contract_name not in results:
            results[contract_name] = []
        results[contract_name].extend(matches)
    return results


# Category -> remediation advice used when persisting findings. Exposed
# at module level so report generators can reuse the same copy.
REMEDIATION_BY_CATEGORY = {
    "error_handling": (
        "Add explicit error checking with if err != nil or common.DealWithErr() for this call."
    ),
    "hardcoded_values": (
        "Replace the hardcoded value with a named constant from common/types/ or vm/constants/."
    ),
    "arithmetic": (
        "Add a guard to verify the first operand >= second "
        "before subtraction, or use checked arithmetic."
    ),
    "access_control": (
        "Verify the method checks caller identity (e.g. sender == owner) before modifying state."
    ),
    "code_quality": (
        "Resolve the TODO/FIXME or create a tracking issue and reference it in the comment."
    ),
}


def persist_scan_results(
    contract_name: str,
    matches: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist scan results to ``security_reviews`` and unified evidence.

    Keeps the engine name as ``vuln_scanner`` so existing history and
    cost-optimizer skip logic keyed on that name remain valid.

    Returns the number of findings persisted.
    """
    if not matches:
        return 0
    for m in matches:
        persist_metric(
            db_path=db_path,
            table="security_reviews",
            data={
                "contract_name": contract_name,
                "engine": "vuln_scanner",
                "severity": m["severity"],
                "category": m["category"],
                "title": m["pattern_name"],
                "description": m["description"],
                "file_path": m["file"],
                "line_number": m["line"],
                "confidence": 0.8,
            },
        )

        file_path = m["file"]
        line_num = m["line"]
        sev = m["severity"].upper()
        line_content = m.get("line_content", "")

        remediation = REMEDIATION_BY_CATEGORY.get(
            m["category"],
            f"Review and remediate the {m['category']} issue.",
        )

        persist_finding(
            db_path=db_path,
            domain="security",
            engine="vuln_scanner",
            evidence_type=f"vuln_{m['category']}",
            finding=(
                f"WHAT: [{sev}] {m['pattern_name']} in {contract_name} "
                f"at {file_path}:{line_num}"
                f"{': ' + line_content if line_content else ''}. "
                f"SO WHAT: {m['description']} "
                f"NOW WHAT: {remediation}"
            ),
            confidence=0.8 if m["severity"] == "high" else 0.5,
            raw_data={
                "contract_name": contract_name,
                "pattern_name": m["pattern_name"],
                "severity": m["severity"],
                "category": m["category"],
                "line_content": line_content,
            },
            source_repo="go-zenon",
            source_file=f"{file_path}:{line_num}",
            reproducible_command=(f"grep -n '{m['pattern_name']}' {file_path}"),
        )

    return len(matches)
