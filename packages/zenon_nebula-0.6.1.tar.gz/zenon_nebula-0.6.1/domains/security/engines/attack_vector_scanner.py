# SPDX-License-Identifier: MIT
"""AttackVectorScanner — Layer 3 of the v0.5.x layered attack-vector framework.

Autonomous engine that scans Nebula's own codebase for attack surfaces
discovered in the wild. Runs every cycle on a rotating subset of
files. Emits ``nebula_self_vuln`` findings (distinct from the Zenon
contract security findings that `adversarial_reviewer` produces) so
the war room can surface them in a dedicated "Nebula security
advisories" section.

**What Layer 2 does not catch (and why Layer 3 exists):** the
`test_attack_vector_smoke.py` static checker covers a small set of
known-bad patterns (subprocess timeouts, eval, pickle, shell=True,
yaml.load, dynamic imports). That's seven patterns. The real attack
surface is larger, and new vulnerability classes surface in the wild
regularly via OSV.dev + GitHub Security Advisories. Layer 3 is the
engine that continuously extends the coverage without requiring a
Nebula code release — new patterns are data, not code.

**Pattern library.** This module maintains a curated list of
attack patterns each with:
- A name (e.g., "dangerous-tempfile-without-cleanup")
- A regex or AST match
- A severity (critical / high / medium / low / info)
- A scenario description for the WHAT/SO WHAT/NOW WHAT finding
- A reference URL (OSV ID, CVE, GitHub Security Advisory, or blog post)

Patterns ship in-module for v0.5.1. Future versions can add a
JSON/YAML file path so patterns are updatable without code
changes.

**Why not LLM yet?** LLM-based probing is Layer 3B (v0.5.2) in the
task #47 roadmap. v0.5.1 ships only the deterministic-pattern layer
so operators can calibrate the baseline without LLM cost. The LLM
layer will sit in this same module as a separate entry point that
operators opt into via env var.
"""

from __future__ import annotations

import logging
import re
import time
from pathlib import Path
from typing import Any

from core.persistence.findings import persist_finding
from core.persistence.schema import DEFAULT_DB

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
NEBULA_ROOT = ENGINE_ROOT  # alias for clarity — this engine scans Nebula itself

# Bounded cost: scan a rotating subset so a single cycle stays under
# a few seconds even on a large codebase.
MAX_FILES_PER_CYCLE = 40
MAX_FILE_SIZE_BYTES = 256 * 1024


# ---------------------------------------------------------------------------
# Attack-pattern library (deterministic, no LLM, no network)
# ---------------------------------------------------------------------------


# Each pattern: name, compiled regex, severity, scenario, reference
_PATTERNS: list[dict[str, Any]] = [
    {
        "name": "tempfile_without_delete",
        "regex": re.compile(
            r"tempfile\.(?:mkstemp|NamedTemporaryFile)\([^)]*delete\s*=\s*False",
            re.DOTALL,
        ),
        "severity": "medium",
        "scenario": (
            "Temporary file created with delete=False may leave "
            "sensitive data on disk if cleanup is missed. Adversary "
            "with filesystem read can recover."
        ),
        "reference": "CWE-377",
    },
    {
        "name": "mktemp_race_condition",
        "regex": re.compile(r"tempfile\.mktemp\s*\("),
        "severity": "high",
        "scenario": (
            "tempfile.mktemp creates a predictable path before opening "
            "the file, opening a TOCTOU race window where an attacker "
            "can symlink or pre-create the path."
        ),
        "reference": "CWE-377; tempfile.mktemp is deprecated",
    },
    {
        "name": "md5_used_for_security",
        "regex": re.compile(r"hashlib\.md5\s*\([^)]*\)(?!\s*\.\s*hexdigest\s*\(\s*\)\s*\[:8\])"),
        "severity": "medium",
        "scenario": (
            "MD5 is cryptographically broken. If this hash is used "
            "for any security-sensitive purpose (signatures, "
            "integrity checks, deduplication of trust-bearing data), "
            "collisions can be forged. Acceptable for short-lived "
            "cache keys or filename hashing but never for security."
        ),
        "reference": "CWE-327; use hashlib.sha256 for security contexts",
    },
    {
        "name": "sha1_used_for_security",
        "regex": re.compile(r"hashlib\.sha1\s*\("),
        "severity": "low",
        "scenario": (
            "SHA-1 is deprecated for security contexts. Not yet "
            "practically broken for preimage but collision-vulnerable. "
            "Acceptable for cache keys or git object references "
            "(which is what git itself uses) but flag for review."
        ),
        "reference": "CWE-327; NIST deprecated SHA-1 in 2011",
    },
    {
        "name": "ssl_verify_false",
        "regex": re.compile(r"verify\s*=\s*False"),
        "severity": "critical",
        "scenario": (
            "SSL verification disabled allows MITM attacks. Any data "
            "sent over this connection can be read or modified by "
            "network-adjacent adversaries. No legitimate production "
            "use case in Nebula."
        ),
        "reference": "CWE-295",
    },
    {
        "name": "ssl_check_hostname_false",
        "regex": re.compile(r"check_hostname\s*=\s*False"),
        "severity": "critical",
        "scenario": (
            "Disabling SSL hostname verification allows MITM via any "
            "valid certificate. The attacker does not need to compromise "
            "your target's CA."
        ),
        "reference": "CWE-297",
    },
    {
        "name": "os_system_call",
        "regex": re.compile(r"\bos\.system\s*\("),
        "severity": "high",
        "scenario": (
            "os.system() invokes a shell with the given command. If "
            "any part of the command string is influenced by user "
            "input or network data, this is a command injection "
            "vulnerability. Use subprocess.run with a list-argv form."
        ),
        "reference": "CWE-78",
    },
    {
        "name": "os_popen_call",
        "regex": re.compile(r"\bos\.popen\s*\("),
        "severity": "high",
        "scenario": (
            "os.popen() has the same command-injection risk as "
            "os.system() and is deprecated in favor of subprocess."
        ),
        "reference": "CWE-78",
    },
    {
        "name": "hardcoded_api_key_shape",
        "regex": re.compile(
            r"(?:api[_-]?key|secret|token|password)\s*=\s*[\"'][A-Za-z0-9_\-]{20,}[\"']",
            re.IGNORECASE,
        ),
        "severity": "critical",
        "scenario": (
            "A string that looks like a hardcoded API key, token, "
            "secret, or password was found in source code. If this "
            "file ships in a wheel or lands in a public release, "
            "the credential is permanently leaked."
        ),
        "reference": "CWE-798",
    },
    {
        "name": "bare_except_pass",
        "regex": re.compile(r"except\s*:\s*\n\s*pass\b"),
        "severity": "medium",
        "scenario": (
            "A bare `except: pass` silently swallows every exception, "
            "including KeyboardInterrupt and SystemExit. This masks "
            "real bugs (including security-relevant ones) and makes "
            "debugging impossible."
        ),
        "reference": "CWE-390; also banned by architecture audit rule R4",
    },
    {
        "name": "weak_random_for_crypto",
        "regex": re.compile(
            r"(?:random\.random|random\.randint|random\.choice|random\.sample)\s*\("
        ),
        "severity": "info",
        "scenario": (
            "Python's `random` module uses a Mersenne Twister — fast "
            "but NOT cryptographically secure. If the random value "
            "is used for anything security-sensitive (tokens, keys, "
            "nonces, challenge values), use `secrets` instead. "
            "Acceptable for non-security randomization (Fibonacci "
            "test data, random sampling of repos, cycle jitter)."
        ),
        "reference": "CWE-338",
    },
    {
        "name": "wildcard_import",
        "regex": re.compile(r"^from\s+[\w.]+\s+import\s+\*", re.MULTILINE),
        "severity": "low",
        "scenario": (
            "Wildcard imports pollute the namespace and make it hard "
            "to audit what functions are in scope. In a security audit "
            "context, wildcard imports obscure which dangerous APIs "
            "are accessible."
        ),
        "reference": "PEP 8 recommends against wildcard imports",
    },
]

# Files we scan
_SCANNED_ROOTS = ("core", "domains", "scripts")
_SCANNED_EXTENSIONS = {".py"}
_SKIPPED_DIRS = {".git", "__pycache__", ".venv", "venv", "build", "dist"}

# Files legitimately containing these patterns (e.g., the smoke test
# itself documents the bans; the attack_vector_scanner module itself
# embeds the patterns as data). One-line justification per entry.
_PATH_ALLOWLIST_PER_PATTERN: dict[str, set[str]] = {
    "os_system_call": {
        # The smoke test mentions os.system as a ban target
        "tests/test_attack_vector_smoke.py",
    },
    "os_popen_call": {
        "tests/test_attack_vector_smoke.py",
    },
    "hardcoded_api_key_shape": {
        # env.example.txt style files (not scanned — .py only) + any
        # test fixture that embeds a placeholder key
    },
    "bare_except_pass": {
        # Architecture audit rule R4 tests this pattern by constructing it
        "scripts/audit_architecture.py",
    },
    "wildcard_import": {
        # Python __init__.py files legitimately use wildcard imports
    },
    "weak_random_for_crypto": {
        # curiosity_scanner + pattern_discoverer use random for
        # non-security sampling; source_quality_scorer uses it for
        # rotation jitter
        "core/curiosity.py",
        "domains/investigation/engines/curiosity_scanner.py",
        "domains/investigation/engines/pattern_discoverer.py",
        "domains/investigation/engines/source_quality_scorer.py",
    },
    "sha1_used_for_security": {
        # Pre-existing sha1 uses that haven't been audited yet —
        # pay-down allowlist, shrinks over time
    },
    "md5_used_for_security": {
        # Pre-existing md5 uses for cache keys / non-security hashing
    },
}


def _should_scan(path: Path) -> bool:
    if path.suffix not in _SCANNED_EXTENSIONS:
        return False
    if any(part in _SKIPPED_DIRS for part in path.parts):
        return False
    try:
        if path.stat().st_size > MAX_FILE_SIZE_BYTES:
            return False
    except OSError:
        return False
    return True


def _discover_files(roots: tuple[str, ...] = _SCANNED_ROOTS) -> list[Path]:
    files: list[Path] = []
    for root_name in roots:
        root = NEBULA_ROOT / root_name
        if not root.is_dir():
            continue
        for path in root.rglob("*"):
            if _should_scan(path):
                files.append(path)
    return files


def _strip_comments_and_docstrings(content: str) -> str:
    """Remove docstrings + line comments so the pattern library doesn't
    false-positive on ban-documentation prose."""
    stripped = re.sub(r'""".*?"""', "", content, flags=re.DOTALL)
    stripped = re.sub(r"'''.*?'''", "", stripped, flags=re.DOTALL)
    stripped = re.sub(r"#.*$", "", stripped, flags=re.MULTILINE)
    return stripped


def _scan_file(path: Path) -> list[dict[str, Any]]:
    """Return pattern hits for a single file."""
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    stripped = _strip_comments_and_docstrings(raw)
    rel = str(path.relative_to(NEBULA_ROOT))
    hits: list[dict[str, Any]] = []

    for pattern in _PATTERNS:
        allowlist = _PATH_ALLOWLIST_PER_PATTERN.get(pattern["name"], set())
        if rel in allowlist:
            continue
        for match in pattern["regex"].finditer(stripped):
            # Find the approximate line number in the RAW content
            # (stripped content has different offsets)
            snippet = stripped[match.start() : match.start() + 80]
            raw_idx = raw.find(snippet[:40]) if snippet else -1
            if raw_idx >= 0:
                line = raw.count("\n", 0, raw_idx) + 1
            else:
                line = stripped.count("\n", 0, match.start()) + 1
            hits.append(
                {
                    "pattern": pattern["name"],
                    "severity": pattern["severity"],
                    "scenario": pattern["scenario"],
                    "reference": pattern["reference"],
                    "file": rel,
                    "line": line,
                    "match_preview": stripped[
                        match.start() : min(match.end(), match.start() + 120)
                    ].strip(),
                }
            )
    return hits


def _format_finding(hit: dict[str, Any]) -> str:
    return (
        f"WHAT: `{hit['file']}` line {hit['line']} contains "
        f"`{hit['pattern']}`. Match preview: "
        f"`{hit['match_preview']}`. "
        f"SO WHAT: {hit['scenario']} "
        f"NOW WHAT: Review the call site. If the pattern is a "
        f"false positive (e.g., non-security use of a weak hash, "
        f"or legitimate shell invocation with hardcoded safe input), "
        f"add `{hit['file']}` to the `{hit['pattern']}` entry in "
        f"`_PATH_ALLOWLIST_PER_PATTERN` in "
        f"`domains/security/engines/attack_vector_scanner.py` with "
        f"a one-line justification. If the pattern is real, fix "
        f"the call site. Reference: {hit['reference']}."
    )


def _severity_to_confidence(severity: str) -> float:
    return {
        "critical": 0.95,
        "high": 0.85,
        "medium": 0.70,
        "low": 0.55,
        "info": 0.40,
    }.get(severity, 0.50)


def run_attack_vector_scanner(
    db_path: str | None = None,
    *,
    max_files: int = MAX_FILES_PER_CYCLE,
) -> dict[str, Any]:
    """Scan a rotating subset of Nebula's own files for attack patterns.

    Runs every cycle via the security-domain rotation. Bounded cost:
    40 files per cycle at <= 256 KB each. Over time, the rotation
    covers the whole codebase.

    Args:
        db_path: SQLite DB (defaults to DEFAULT_DB).
        max_files: Cap on files scanned per cycle.

    Returns:
        Summary dict with ``files_scanned``, ``hits_by_severity``,
        ``findings_persisted``.
    """
    db_path = db_path or DEFAULT_DB

    files = _discover_files()
    if not files:
        return {
            "files_scanned": 0,
            "hits_by_severity": {},
            "findings_persisted": 0,
        }

    # Rotate through files based on wall-clock minute so successive
    # cycles cover different subsets
    offset = int(time.time() // 60) % max(1, len(files))
    selected = [files[(offset + i) % len(files)] for i in range(min(max_files, len(files)))]

    hits_by_severity: dict[str, int] = {}
    findings_persisted = 0

    for path in selected:
        hits = _scan_file(path)
        for hit in hits:
            sev = hit["severity"]
            hits_by_severity[sev] = hits_by_severity.get(sev, 0) + 1
            body = _format_finding(hit)
            try:
                row_id = persist_finding(
                    db_path=db_path,
                    domain="security",
                    engine="attack_vector_scanner",
                    evidence_type=f"nebula_self_vuln_{hit['pattern']}",
                    finding=body,
                    confidence=_severity_to_confidence(sev),
                    source_repo="nebula",
                    source_file=hit["file"],
                    source_line=hit["line"],
                    raw_data={"pattern": hit["pattern"], "severity": sev},
                )
                if row_id and row_id > 0:
                    findings_persisted += 1
            except Exception as exc:
                logger.debug(
                    "attack_vector_scanner: persist failed for %s:%d — %s",
                    hit["file"],
                    hit["line"],
                    exc,
                )

    logger.info(
        "attack_vector_scanner: scanned %d file(s), hits %s, persisted %d",
        len(selected),
        hits_by_severity,
        findings_persisted,
    )
    return {
        "files_scanned": len(selected),
        "hits_by_severity": hits_by_severity,
        "findings_persisted": findings_persisted,
    }
