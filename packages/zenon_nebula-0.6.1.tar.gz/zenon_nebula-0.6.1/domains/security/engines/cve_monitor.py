# SPDX-License-Identifier: MIT
"""
CVEMonitor -- Dependency vulnerability scanner for Zenon workspace repos.

Parses dependency files (go.mod/go.sum, package.json/package-lock.json,
requirements.txt) and checks each dependency against a hardcoded list of
known critical CVEs relevant to cryptographic and blockchain software.

No LLM calls.  Pure version parsing and comparison.
"""

import json
import logging
import os
import re
from dataclasses import dataclass
from pathlib import Path

from core.persist_to_db import ensure_schema, persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# Repos to scan for dependencies
SCAN_REPOS: list[tuple[str, str]] = [
    ("core/go-zenon", "go"),
    ("zenon-network/go-zenon", "go"),
    ("HyperCore-Team/orchestrator", "go"),
    ("zenon-org/zenon-light-client", "node"),
    ("zenon-org/nebula", "python"),
]


# ---------------------------------------------------------------------------
# Version comparison utilities
# ---------------------------------------------------------------------------


def _parse_semver(version: str) -> tuple[int, ...]:
    """Parse a semver string into a tuple of ints for comparison.

    Handles formats like: v0.14.0, 1.2.3, 0.0.0-20231215, etc.
    Returns (0,) on parse failure so comparisons degrade gracefully.
    """
    version = version.lstrip("v")
    # Strip pre-release/build suffixes for core version comparison
    version = re.split(r"[-+]", version)[0]
    parts = version.split(".")
    result = []
    for p in parts:
        try:
            result.append(int(p))
        except ValueError:
            break
    return tuple(result) if result else (0,)


def _version_lt(a: str, b: str) -> bool:
    """Return True if version a < version b."""
    return _parse_semver(a) < _parse_semver(b)


# ---------------------------------------------------------------------------
# Known CVE database (hardcoded, crypto-relevant)
# ---------------------------------------------------------------------------


@dataclass
class KnownCVE:
    """A known CVE affecting a dependency."""

    cve_id: str
    package: str  # Go module path, npm package name, or PyPI name
    ecosystem: str  # "go", "node", "python"
    affected_below: str  # Versions below this are affected
    severity: str  # "critical", "high", "medium"
    description: str
    reference: str = ""


KNOWN_CVES: list[KnownCVE] = [
    # Go crypto
    KnownCVE(
        cve_id="CVE-2024-45337",
        package="golang.org/x/crypto",
        ecosystem="go",
        affected_below="v0.31.0",
        severity="critical",
        description=(
            "golang.org/x/crypto/ssh: Authorization bypass via "
            "ServerConfig.PublicKeyCallback. A misuse of the callback "
            "can allow unauthorized access."
        ),
        reference="https://pkg.go.dev/vuln/GO-2024-3321",
    ),
    KnownCVE(
        cve_id="CVE-2024-45338",
        package="golang.org/x/net",
        ecosystem="go",
        affected_below="v0.33.0",
        severity="high",
        description=(
            "golang.org/x/net/html: Excessive CPU consumption in html.Parse and html.ParseFragment."
        ),
        reference="https://pkg.go.dev/vuln/GO-2024-3333",
    ),
    KnownCVE(
        cve_id="CVE-2023-48795",
        package="golang.org/x/crypto",
        ecosystem="go",
        affected_below="v0.17.0",
        severity="high",
        description=(
            "Terrapin attack: SSH prefix truncation. Allows downgrade of SSH connection security."
        ),
        reference="https://pkg.go.dev/vuln/GO-2023-2402",
    ),
    KnownCVE(
        cve_id="CVE-2023-44487",
        package="golang.org/x/net",
        ecosystem="go",
        affected_below="v0.17.0",
        severity="critical",
        description=(
            "HTTP/2 Rapid Reset attack: DoS via stream cancellation. Affects any Go HTTP/2 server."
        ),
        reference="https://pkg.go.dev/vuln/GO-2023-2102",
    ),
    KnownCVE(
        cve_id="CVE-2024-34156",
        package="stdlib",
        ecosystem="go",
        affected_below="go1.22.7",
        severity="high",
        description=(
            "encoding/gob: Stack exhaustion via deeply nested "
            "structures. Affects Go runtime < 1.22.7."
        ),
        reference="https://pkg.go.dev/vuln/GO-2024-3106",
    ),
    # libp2p (used by go-zenon for networking)
    KnownCVE(
        cve_id="CVE-2023-40583",
        package="github.com/libp2p/go-libp2p",
        ecosystem="go",
        affected_below="v0.31.0",
        severity="high",
        description=(
            "go-libp2p: Large RSA keys can cause panics in the "
            "identify protocol. DoS via crafted peer identity."
        ),
        reference="https://github.com/libp2p/go-libp2p/security/advisories/GHSA-2h6c-j3gf-xp9r",
    ),
    KnownCVE(
        cve_id="CVE-2023-39533",
        package="github.com/libp2p/go-libp2p",
        ecosystem="go",
        affected_below="v0.29.2",
        severity="high",
        description=(
            "go-libp2p: Denial of service via unbounded memory allocation in QUIC connections."
        ),
        reference="https://github.com/libp2p/go-libp2p/security/advisories/GHSA-876p-8259-xjgg",
    ),
    # btcd / btcutil (Bitcoin libraries)
    KnownCVE(
        cve_id="CVE-2024-38365",
        package="github.com/btcsuite/btcd",
        ecosystem="go",
        affected_below="v0.24.2",
        severity="critical",
        description=(
            "btcd: Consensus failure due to mishandled FindAndDelete "
            "in script validation. Nodes using btcd could be split "
            "from the Bitcoin network."
        ),
        reference="https://github.com/btcsuite/btcd/security/advisories/GHSA-27vh-h6mc-q6g8",
    ),
    KnownCVE(
        cve_id="CVE-2022-44797",
        package="github.com/btcsuite/btcd",
        ecosystem="go",
        affected_below="v0.23.2",
        severity="critical",
        description=(
            "btcd: Block parsing DoS via large witness data. "
            "Attacker can crash btcd nodes with crafted blocks."
        ),
        reference="https://github.com/btcsuite/btcd/security/advisories/GHSA-2chg-86hq-7w38",
    ),
    # geth / go-ethereum
    KnownCVE(
        cve_id="CVE-2023-42319",
        package="github.com/ethereum/go-ethereum",
        ecosystem="go",
        affected_below="v1.13.1",
        severity="high",
        description=(
            "go-ethereum: DoS in RLP decoding via deeply nested data. Can crash geth nodes."
        ),
        reference="https://github.com/ethereum/go-ethereum/security",
    ),
    # secp256k1 (various implementations)
    KnownCVE(
        cve_id="CVE-2023-33460",
        package="github.com/decred/dcrd/dcrec/secp256k1",
        ecosystem="go",
        affected_below="v4.2.0",
        severity="medium",
        description=(
            "dcrd secp256k1: Timing side-channel in scalar "
            "multiplication. May leak private key bits."
        ),
        reference="https://github.com/decred/dcrd/issues/3169",
    ),
    # grpc-go
    KnownCVE(
        cve_id="CVE-2023-44487",
        package="google.golang.org/grpc",
        ecosystem="go",
        affected_below="v1.58.3",
        severity="critical",
        description=("grpc-go: HTTP/2 Rapid Reset attack. DoS via stream cancellation flood."),
        reference="https://github.com/grpc/grpc-go/security",
    ),
    # Node.js / npm
    KnownCVE(
        cve_id="CVE-2024-21538",
        package="cross-spawn",
        ecosystem="node",
        affected_below="7.0.5",
        severity="high",
        description=("cross-spawn: Regular expression DoS (ReDoS). Can hang Node.js processes."),
        reference="https://github.com/advisories/GHSA-3xgq-45jj-v275",
    ),
    KnownCVE(
        cve_id="CVE-2022-25898",
        package="secp256k1",
        ecosystem="node",
        affected_below="4.0.3",
        severity="high",
        description=(
            "secp256k1 npm: Signature malleability allows "
            "forging valid signatures from existing ones."
        ),
        reference="https://github.com/nicolo-ribaudo/tc39-proposal-secp256k1/issues/2",
    ),
    KnownCVE(
        cve_id="CVE-2023-26136",
        package="tough-cookie",
        ecosystem="node",
        affected_below="4.1.3",
        severity="medium",
        description=(
            "tough-cookie: Prototype pollution via cookie parsing. "
            "Can lead to unexpected behavior or DoS."
        ),
        reference="https://github.com/advisories/GHSA-72xf-g2v4-qvf3",
    ),
    KnownCVE(
        cve_id="CVE-2024-28863",
        package="tar",
        ecosystem="node",
        affected_below="6.2.1",
        severity="medium",
        description=(
            "node-tar: DoS via large or specially crafted tar archives. Can exhaust memory."
        ),
        reference="https://github.com/isaacs/node-tar/security/advisories/GHSA-f5x3-32g6-xq36",
    ),
    # Python
    KnownCVE(
        cve_id="CVE-2024-3651",
        package="idna",
        ecosystem="python",
        affected_below="3.7",
        severity="medium",
        description=(
            "python-idna: DoS via resource consumption when "
            "processing crafted internationalized domain names."
        ),
        reference="https://github.com/kjd/idna/issues/18",
    ),
    KnownCVE(
        cve_id="CVE-2024-35195",
        package="requests",
        ecosystem="python",
        affected_below="2.32.0",
        severity="medium",
        description=(
            "requests: Session cookies leak across redirects to "
            "different hosts. Credentials may be sent to attacker "
            "controlled servers."
        ),
        reference="https://github.com/psf/requests/security/advisories/GHSA-9wx4-h78v-vm56",
    ),
    KnownCVE(
        cve_id="CVE-2023-43804",
        package="urllib3",
        ecosystem="python",
        affected_below="2.0.7",
        severity="high",
        description=(
            "urllib3: Cookie header leaks during cross-origin "
            "redirects. Authorization cookies sent to wrong host."
        ),
        reference="https://github.com/urllib3/urllib3/security/advisories/GHSA-v845-jxx5-vc9f",
    ),
]


# ---------------------------------------------------------------------------
# Dependency parsers
# ---------------------------------------------------------------------------


@dataclass
class Dependency:
    """A parsed dependency with name and version."""

    name: str
    version: str
    ecosystem: str
    source_file: str


def parse_go_mod(repo_path: Path) -> list[Dependency]:
    """Parse go.mod for direct dependencies."""
    go_mod = repo_path / "go.mod"
    if not go_mod.is_file():
        return []

    deps: list[Dependency] = []
    content = go_mod.read_text(encoding="utf-8", errors="replace")
    in_require = False

    for line in content.split("\n"):
        line = line.strip()
        if line.startswith("require ("):
            in_require = True
            continue
        if in_require and line == ")":
            in_require = False
            continue
        if line.startswith("require "):
            # Single-line require
            parts = line.split()
            if len(parts) >= 3:
                deps.append(
                    Dependency(
                        name=parts[1],
                        version=parts[2],
                        ecosystem="go",
                        source_file=str(go_mod),
                    )
                )
        elif in_require and line and not line.startswith("//"):
            parts = line.split()
            if len(parts) >= 2:
                deps.append(
                    Dependency(
                        name=parts[0],
                        version=parts[1],
                        ecosystem="go",
                        source_file=str(go_mod),
                    )
                )

    return deps


def parse_package_json(repo_path: Path) -> list[Dependency]:
    """Parse package.json for dependencies."""
    pkg_json = repo_path / "package.json"
    if not pkg_json.is_file():
        return []

    deps: list[Dependency] = []
    try:
        data = json.loads(pkg_json.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []

    for dep_section in ("dependencies", "devDependencies"):
        for name, version_spec in data.get(dep_section, {}).items():
            # Strip ^, ~, >=, etc. to get base version
            version = re.sub(r"^[\^~>=<]+", "", version_spec)
            deps.append(
                Dependency(
                    name=name,
                    version=version,
                    ecosystem="node",
                    source_file=str(pkg_json),
                )
            )

    return deps


def parse_requirements_txt(repo_path: Path) -> list[Dependency]:
    """Parse requirements.txt for Python dependencies."""
    deps: list[Dependency] = []
    for req_file in ("requirements.txt", "requirements-full.txt"):
        req_path = repo_path / req_file
        if not req_path.is_file():
            continue
        try:
            content = req_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        for line in content.split("\n"):
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            # Handle name==version, name>=version, name~=version
            match = re.match(r"([a-zA-Z0-9_.-]+)\s*[><=~!]+\s*([0-9][0-9.]*)", line)
            if match:
                deps.append(
                    Dependency(
                        name=match.group(1).lower(),
                        version=match.group(2),
                        ecosystem="python",
                        source_file=str(req_path),
                    )
                )
            elif re.match(r"^[a-zA-Z0-9_.-]+$", line):
                # Unpinned dependency
                deps.append(
                    Dependency(
                        name=line.lower(),
                        version="unknown",
                        ecosystem="python",
                        source_file=str(req_path),
                    )
                )

    return deps


# ---------------------------------------------------------------------------
# CVE checking
# ---------------------------------------------------------------------------


@dataclass
class CVEFinding:
    """A dependency matching a known CVE."""

    cve: KnownCVE
    dependency: Dependency
    repo_name: str
    is_vulnerable: bool  # True if version is below affected_below


def check_dependencies(
    deps: list[Dependency],
    repo_name: str,
) -> list[CVEFinding]:
    """Check a list of dependencies against known CVEs."""
    findings: list[CVEFinding] = []

    for dep in deps:
        for cve in KNOWN_CVES:
            if cve.ecosystem != dep.ecosystem:
                continue
            # Match package name (partial match for Go module paths)
            if dep.ecosystem == "go":
                if cve.package not in dep.name and dep.name not in cve.package:
                    continue
            else:
                if cve.package != dep.name:
                    continue

            if dep.version == "unknown":
                # Cannot determine if vulnerable, flag as info
                findings.append(
                    CVEFinding(
                        cve=cve,
                        dependency=dep,
                        repo_name=repo_name,
                        is_vulnerable=False,  # Unknown, not confirmed
                    )
                )
                continue

            is_vuln = _version_lt(dep.version, cve.affected_below)
            findings.append(
                CVEFinding(
                    cve=cve,
                    dependency=dep,
                    repo_name=repo_name,
                    is_vulnerable=is_vuln,
                )
            )

    return findings


# ---------------------------------------------------------------------------
# Top-level API
# ---------------------------------------------------------------------------


def scan_all() -> dict:
    """Scan all configured repos for CVE-affected dependencies.

    Returns dict with findings and summary.
    """
    all_findings: list[dict] = []
    repos_scanned: list[str] = []
    total_deps = 0
    vulnerable_count = 0

    for repo_rel, ecosystem in SCAN_REPOS:
        repo_path = ZENON_WORKSPACE / repo_rel
        if not repo_path.is_dir():
            logger.debug("CVEMonitor: repo not found: %s", repo_path)
            continue

        repos_scanned.append(repo_rel)

        # Parse dependencies
        deps: list[Dependency] = []
        if ecosystem == "go":
            deps = parse_go_mod(repo_path)
        elif ecosystem == "node":
            deps = parse_package_json(repo_path)
        elif ecosystem == "python":
            deps = parse_requirements_txt(repo_path)

        total_deps += len(deps)

        # Check against known CVEs
        findings = check_dependencies(deps, repo_rel)
        for f in findings:
            status = "VULNERABLE" if f.is_vulnerable else "INFO"
            if f.is_vulnerable:
                vulnerable_count += 1

            all_findings.append(
                {
                    "cve_id": f.cve.cve_id,
                    "package": f.dependency.name,
                    "installed_version": f.dependency.version,
                    "affected_below": f.cve.affected_below,
                    "severity": f.cve.severity,
                    "description": f.cve.description,
                    "reference": f.cve.reference,
                    "repo": f.repo_name,
                    "source_file": f.dependency.source_file,
                    "status": status,
                    "ecosystem": f.dependency.ecosystem,
                }
            )

    # Supplement hardcoded CVE list with live OSV vulnerability feed
    live_vuln_count = 0
    try:
        from core.vuln_feed import scan_go_mod as osv_scan_go_mod

        for repo_rel, ecosystem in SCAN_REPOS:
            if ecosystem != "go":
                continue
            go_mod_path = str(ZENON_WORKSPACE / repo_rel / "go.mod")
            if not os.path.isfile(go_mod_path):
                continue
            live_vulns = osv_scan_go_mod(go_mod_path)
            for lv in live_vulns:
                # Deduplicate: skip if we already have a finding for this
                # module+CVE from the hardcoded list
                existing_ids = {(f["package"], f["cve_id"]) for f in all_findings}
                for vuln in lv.get("vulnerabilities", []):
                    vuln_id = vuln.get("id", "")
                    if (lv["module"], vuln_id) in existing_ids:
                        continue
                    live_vuln_count += 1
                    vulnerable_count += 1
                    all_findings.append(
                        {
                            "cve_id": vuln_id,
                            "package": lv["module"],
                            "installed_version": lv.get("version", "unknown"),
                            "affected_below": "",
                            "severity": vuln.get("severity", "UNKNOWN"),
                            "description": vuln.get("summary", vuln.get("details", "")[:200]),
                            "reference": "",
                            "repo": repo_rel,
                            "source_file": go_mod_path,
                            "status": "VULNERABLE",
                            "ecosystem": "go",
                            "source": "osv_live",
                        }
                    )
    except Exception as exc:
        logger.debug("Live OSV feed supplementary scan failed: %s", exc)

    return {
        "findings": all_findings,
        "summary": {
            "repos_scanned": len(repos_scanned),
            "total_dependencies": total_deps,
            "cves_checked": len(KNOWN_CVES),
            "vulnerable": vulnerable_count,
            "total_matches": len(all_findings),
            "live_osv_findings": live_vuln_count,
        },
        "repos_scanned": repos_scanned,
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run full CVE scan and persist all findings.

    Returns the number of findings persisted.
    """
    ensure_schema(db_path)
    report = scan_all()
    count = 0

    vuln = report["summary"]["vulnerable"]
    total_matches = report["summary"]["total_matches"]
    repos = report["summary"]["repos_scanned"]
    total_deps = report["summary"]["total_dependencies"]

    # Summary finding
    persist_finding(
        db_path=db_path,
        domain="security",
        engine="cve_monitor",
        evidence_type="cve_scan_summary",
        finding=(
            f"WHAT: CVE monitor scanned {total_deps} dependencies across "
            f"{repos} repos against {len(KNOWN_CVES)} known CVEs. "
            f"Found {vuln} confirmed vulnerable, {total_matches} total matches. "
            f"SO WHAT: {'CRITICAL -- vulnerable dependencies detected that may affect fund safety. ' if vuln else ''}"
            f"{'No vulnerable dependencies found in scanned repos. ' if not vuln else ''}"
            f"NOW WHAT: {f'Update {vuln} vulnerable dependencies immediately. ' if vuln else ''}"
            f"{'Continue monitoring. Expand CVE database as new advisories are published. ' if not vuln else ''}"
        ),
        confidence=0.85,
        raw_data=report["summary"],
        source_repo="workspace",
    )
    count += 1

    # Individual CVE findings
    for finding in report["findings"]:
        if finding["status"] != "VULNERABLE":
            continue  # Only persist confirmed vulnerabilities

        sev = finding["severity"].upper()
        cve_id = finding["cve_id"]
        pkg = finding["package"]
        installed = finding["installed_version"]
        fixed = finding["affected_below"]
        repo = finding["repo"]

        persist_finding(
            db_path=db_path,
            domain="security",
            engine="cve_monitor",
            evidence_type="cve_vulnerable_dep",
            finding=(
                f"WHAT: {repo} uses {pkg} {installed}. "
                f"{cve_id} ({sev}) affects versions below {fixed}. "
                f"SO WHAT: {finding['description']} "
                f"NOW WHAT: Update {pkg} to >= {fixed} in {repo}. "
                f"Ref: {finding['reference']}"
            ),
            confidence=0.90 if finding["severity"] == "critical" else 0.80,
            raw_data=finding,
            source_repo=repo,
            source_file=finding.get("source_file"),
        )
        count += 1

    logger.info(
        "CVEMonitor: persisted %d findings (%d vulnerable)",
        count,
        vuln,
    )
    return count
