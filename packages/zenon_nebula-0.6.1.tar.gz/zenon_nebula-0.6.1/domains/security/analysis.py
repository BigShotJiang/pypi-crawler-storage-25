# SPDX-License-Identifier: MIT
"""
analysis -- Shared pattern-matching primitives for security-domain engines.

Both :mod:`domains.security.engines.static_analyzer` and the legacy
:mod:`domains.security.engines.vuln_scanner` wrapper need the same
regex-based vulnerability pattern catalog, DB seed/load helpers, and
file-scanning loop. Hosting the shared code here keeps the engines from
importing each other while preserving the public API they expose.

The structural (AST-approximating) checks stay in ``static_analyzer``
because only that engine consumes them; only the regex-pattern layer is
genuinely shared.
"""

import logging
import re
import sqlite3
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)


# Built-in vulnerability patterns for Go embedded contracts.
# These are line-level regex checks. Severity and remediation are
# derived from the category.
DEFAULT_PATTERNS: list[dict] = [
    {
        "pattern_name": "unchecked_error_return",
        "pattern_regex": r"^\s*\w+\s*(?:,\s*_\s*)?=\s*\w+\.\w+\([^)]*\)\s*$",
        "severity": "high",
        "category": "error_handling",
        "description": (
            "Function return value not checked for error. "
            "Use DealWithErr or explicit error handling."
        ),
    },
    {
        "pattern_name": "bare_underscore_error",
        "pattern_regex": r"\b_\s*=\s*\w+\([^)]*\)",
        "severity": "high",
        "category": "error_handling",
        "description": (
            "Error return value explicitly discarded with _. "
            "All errors must be checked in embedded contracts."
        ),
    },
    {
        "pattern_name": "missing_deal_with_err",
        "pattern_regex": r"(?:err\s*!=\s*nil)\s*\{[^}]*return\b",
        "severity": "medium",
        "category": "error_handling",
        "description": (
            "Error checked but not handled with DealWithErr pattern. "
            "Consider using common.DealWithErr for consistency."
        ),
    },
    {
        "pattern_name": "hardcoded_address",
        "pattern_regex": r"(?:z1q[a-z0-9]{38})",
        "severity": "medium",
        "category": "hardcoded_values",
        "description": "Hardcoded Zenon address found. Use constants or configuration.",
    },
    {
        "pattern_name": "hardcoded_amount",
        "pattern_regex": r"(?:big\.NewInt\(\d{6,}\))",
        "severity": "low",
        "category": "hardcoded_values",
        "description": "Large hardcoded integer amount. Verify this is intentional.",
    },
    {
        "pattern_name": "unsafe_uint_subtract",
        "pattern_regex": r"\.Sub\(\s*\w+\s*,\s*\w+\s*\)",
        "severity": "medium",
        "category": "arithmetic",
        "description": (
            "Unsigned integer subtraction may underflow. "
            "Verify the first operand is always >= the second."
        ),
    },
    {
        "pattern_name": "missing_access_control",
        "pattern_regex": r"func\s*\(\w+\s*\*\w+\)\s*(?:ReceiveBlock|ProcessSend)\b",
        "severity": "info",
        "category": "access_control",
        "description": (
            "Public method on embedded contract. Verify access control checks are present."
        ),
    },
    {
        "pattern_name": "todo_fixme",
        "pattern_regex": r"(?://|/\*)\s*(?:TODO|FIXME|HACK|XXX|BUG)\b",
        "severity": "low",
        "category": "code_quality",
        "description": "TODO/FIXME comment found -- may indicate incomplete implementation.",
    },
]


def get_default_patterns() -> list[dict]:
    """Return a copy of the built-in vulnerability patterns."""
    return [dict(p) for p in DEFAULT_PATTERNS]


def seed_patterns(*, db_path: str) -> int:
    """Seed the ``vuln_patterns`` table with default patterns.

    Returns the number of patterns seeded. Idempotent: returns 0 if the
    table already has rows.
    """
    conn = connect(db_path)
    try:
        existing = conn.execute("SELECT COUNT(*) FROM vuln_patterns").fetchone()[0]
        if existing > 0:
            return 0

        for p in DEFAULT_PATTERNS:
            conn.execute(
                """INSERT INTO vuln_patterns
                   (pattern_name, pattern_regex, severity, category, description)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    p["pattern_name"],
                    p["pattern_regex"],
                    p["severity"],
                    p["category"],
                    p["description"],
                ),
            )
        conn.commit()
        return len(DEFAULT_PATTERNS)
    finally:
        conn.close()


def load_patterns(*, db_path: str) -> list[dict]:
    """Load enabled vulnerability patterns from the database.

    Falls back to :data:`DEFAULT_PATTERNS` if the table is empty or the
    database is unavailable.
    """
    try:
        conn = connect(db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT * FROM vuln_patterns WHERE enabled = 1").fetchall()
        conn.close()
        if rows:
            return [dict(r) for r in rows]
    except Exception as exc:
        logger.debug("Failed to load vuln patterns from DB: %s", exc)
    return get_default_patterns()


def scan_file_with_patterns(
    file_path: Path,
    patterns: list[dict],
) -> list[dict]:
    """Scan a single file against a list of regex patterns.

    Returns a list of match dicts compatible with the legacy
    vuln_scanner output shape.
    """
    try:
        content = file_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        logger.warning("Could not read %s: %s", file_path, exc)
        return []

    lines = content.split("\n")
    matches: list[dict] = []
    for pattern in patterns:
        try:
            regex = re.compile(pattern["pattern_regex"])
        except re.error:
            logger.warning(
                "Invalid regex in pattern %s",
                pattern["pattern_name"],
            )
            continue
        for line_num, line in enumerate(lines, start=1):
            if regex.search(line):
                matches.append(
                    {
                        "file": str(file_path),
                        "line": line_num,
                        "line_content": line.strip(),
                        "pattern_name": pattern["pattern_name"],
                        "severity": pattern["severity"],
                        "category": pattern["category"],
                        "description": pattern["description"],
                    }
                )
    return matches
