# SPDX-License-Identifier: MIT
"""
DocQuality -- Check documentation completeness across Zenon repos.

For each spec in developer-commons, checks whether a corresponding wiki
page exists. For each SDK contract, checks for API documentation. For
each CLI command, checks for help descriptions. Grades overall
documentation coverage and persists gaps as evidence.
"""

import logging
import os
import re
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

SPECS_DIR = ZENON_WORKSPACE / "knowledge" / "developer-commons" / "docs" / "specs"
WIKI_DIR = ZENON_WORKSPACE / "knowledge" / "znn-wiki"
SDK_DART_DIR = ZENON_WORKSPACE / "core" / "znn_sdk_dart"
SDK_DART_API_DIR = SDK_DART_DIR / "lib" / "src" / "api"
CLI_DART_DIR = ZENON_WORKSPACE / "core" / "znn_cli_dart"
NOMCTL_DIR = ZENON_WORKSPACE / "core" / "nomctl"

# Additional documentation sources to scan
CEX_INTEGRATION_GUIDE_PATHS = [
    ZENON_WORKSPACE / "zenon-network" / "CEX-Integration-Guide",
    ZENON_WORKSPACE / "hypercore-one" / "CEX-Integration-Guide",
]
TROUBLESHOOT_PATHS = [
    ZENON_WORKSPACE / "hypercore-one" / "troubleshoot",
    ZENON_WORKSPACE / "zenon-network" / "troubleshoot",
]
AWESOME_ZENON_PATHS = [
    ZENON_WORKSPACE / "knowledge" / "awesome-zenon",
    ZENON_WORKSPACE / "zenon-network" / "awesome-zenon",
    ZENON_WORKSPACE / "hypercore-one" / "awesome-zenon",
]

# Key repos that should have READMEs with build instructions
KEY_REPOS = {
    "go-zenon": ZENON_WORKSPACE / "core" / "go-zenon",
    "znn_sdk_dart": ZENON_WORKSPACE / "core" / "znn_sdk_dart",
    "znn_cli_dart": ZENON_WORKSPACE / "core" / "znn_cli_dart",
    "nomctl": ZENON_WORKSPACE / "core" / "nomctl",
    "syrius": ZENON_WORKSPACE / "core" / "syrius",
    "orchestrator": ZENON_WORKSPACE / "HyperCore-Team" / "orchestrator",
    "evm-bridge-contracts": ZENON_WORKSPACE / "HyperCore-Team" / "evm-bridge-contracts",
    "zenonhub": ZENON_WORKSPACE / "zenonhub-io" / "zenonhub",
    "znn_sdk_csharp": ZENON_WORKSPACE / "community-sdks" / "znn_sdk_csharp",
    "znn_sdk_rust": ZENON_WORKSPACE / "community-sdks" / "znn_sdk_rust",
    "znn_sdk_java": ZENON_WORKSPACE / "community-sdks" / "znn_sdk_java",
    "znn-php": ZENON_WORKSPACE / "community-sdks" / "znn-php",
}

# Spec name -> expected wiki page name patterns
SPEC_WIKI_MAP = {
    "ptlc": ["ptlc", "point-time-lock"],
    "bitcoin_spv": ["bitcoin", "spv"],
    "governance": ["governance"],
    "atomic_swap": ["atomic", "swap"],
    "portal": ["portal", "bridge"],
    "streaming": ["streaming", "stream"],
    "multisig": ["multisig", "multi-sig"],
    "zns": ["zns", "name-service"],
    "galv": ["galv"],
    "htlc": ["htlc", "hash-time-lock"],
    "plasma": ["plasma"],
    "pillar": ["pillar"],
    "sentinel": ["sentinel"],
    "staking": ["staking", "stake"],
    "token": ["token", "zts"],
    "accelerator": ["accelerator", "az"],
    "spork": ["spork"],
}


def _normalize_spec_name(raw_name: str) -> str:
    """Normalize a spec directory name to snake_case."""
    name = raw_name.replace("-", "_").replace(" ", "_")
    name = re.sub(r"(?<=[a-z])(?=[A-Z])", "_", name)
    return name.lower()


def _read_file_text(filepath: Path, max_bytes: int = 200_000) -> str:
    """Read a text file, returning empty string on failure."""
    try:
        text = filepath.read_text(encoding="utf-8", errors="replace")
        return text[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def get_spec_names() -> list[str]:
    """Get normalized names of all specs in developer-commons."""
    if not SPECS_DIR.is_dir():
        return []

    specs = []
    for entry in sorted(SPECS_DIR.iterdir()):
        if entry.is_dir() and not entry.name.startswith("."):
            # Check it has at least one markdown file
            if list(entry.rglob("*.md")):
                specs.append(_normalize_spec_name(entry.name))
    return specs


def get_wiki_pages() -> dict[str, str]:
    """Get all wiki pages as {lowercase_stem: full_path}.

    Scans the wiki directory for markdown files.
    """
    pages: dict[str, str] = {}
    if not WIKI_DIR.is_dir():
        return pages

    for md_file in WIKI_DIR.rglob("*.md"):
        stem = md_file.stem.lower().replace("-", "_").replace(" ", "_")
        pages[stem] = str(md_file)

    return pages


def check_spec_wiki_coverage() -> list[dict]:
    """Check which specs have corresponding wiki pages.

    Returns list of dicts with keys: spec, has_wiki, wiki_page, patterns_checked.
    """
    specs = get_spec_names()
    wiki_pages = get_wiki_pages()
    wiki_stems = set(wiki_pages.keys())
    wiki_content_index: dict[str, str] = {}

    # Build a content index for deeper matching
    for stem, path in wiki_pages.items():
        wiki_content_index[stem] = _read_file_text(Path(path)).lower()

    results = []
    for spec in specs:
        patterns = SPEC_WIKI_MAP.get(spec, [spec])
        found_page = None

        # Check by filename stem
        for pattern in patterns:
            normalized = pattern.lower().replace("-", "_").replace(" ", "_")
            for stem in wiki_stems:
                if normalized in stem or stem in normalized:
                    found_page = wiki_pages.get(stem)
                    break
            if found_page:
                break

        # Check by content if not found by name
        if not found_page:
            for stem, content in wiki_content_index.items():
                for pattern in patterns:
                    if pattern.lower() in content:
                        found_page = wiki_pages.get(stem)
                        break
                if found_page:
                    break

        results.append(
            {
                "spec": spec,
                "has_wiki": found_page is not None,
                "wiki_page": found_page,
                "patterns_checked": patterns,
            }
        )

    return results


def check_sdk_api_docs() -> list[dict]:
    """Check which SDK API classes have doc comments.

    Scans Dart API files for /// doc comments on public classes and methods.
    Returns list of dicts with keys: file, class_name, has_class_doc,
    methods_total, methods_documented.
    """
    results = []
    if not SDK_DART_API_DIR.is_dir():
        return results

    for dart_file in sorted(SDK_DART_API_DIR.glob("*.dart")):
        text = _read_file_text(dart_file)
        if not text:
            continue

        class_name = dart_file.stem
        has_class_doc = bool(re.search(r"///.*\nclass\s+\w+", text))

        # Count public methods and documented methods
        methods = re.findall(
            r"((?:///[^\n]*\n\s*)*)(Future|void|dynamic|int|String|bool|\w+)\s+(\w+)\s*\(", text
        )
        methods_total = 0
        methods_documented = 0
        for doc_block, _return_type, method_name in methods:
            if method_name.startswith("_"):
                continue
            methods_total += 1
            if "///" in doc_block:
                methods_documented += 1

        results.append(
            {
                "file": str(dart_file.relative_to(ZENON_WORKSPACE)),
                "class_name": class_name,
                "has_class_doc": has_class_doc,
                "methods_total": methods_total,
                "methods_documented": methods_documented,
            }
        )

    return results


def check_cli_help() -> dict:
    """Check CLI command documentation by scanning for help/description strings.

    Scans both znn_cli_dart and nomctl for command registrations with
    descriptions.

    Returns dict with keys: cli_dart_commands, nomctl_commands,
    commands_with_help, commands_without_help.
    """
    result = {
        "cli_dart": {"total": 0, "with_help": 0, "commands": []},
        "nomctl": {"total": 0, "with_help": 0, "commands": []},
    }

    # Scan znn_cli_dart
    if CLI_DART_DIR.is_dir():
        for dart_file in CLI_DART_DIR.rglob("*.dart"):
            text = _read_file_text(dart_file)
            # Look for command definitions with descriptions
            commands = re.findall(
                r"(?:description|help)\s*[:=]\s*['\"]([^'\"]+)['\"]",
                text,
            )
            for desc in commands:
                result["cli_dart"]["total"] += 1
                if len(desc.strip()) > 5:
                    result["cli_dart"]["with_help"] += 1
                    result["cli_dart"]["commands"].append(desc.strip()[:80])

    # Scan nomctl
    if NOMCTL_DIR.is_dir():
        for go_file in NOMCTL_DIR.rglob("*.go"):
            text = _read_file_text(go_file)
            # Look for cobra command definitions
            commands = re.findall(
                r'(?:Short|Long|Use)\s*:\s*"([^"]+)"',
                text,
            )
            for desc in commands:
                result["nomctl"]["total"] += 1
                if len(desc.strip()) > 3:
                    result["nomctl"]["with_help"] += 1
                    result["nomctl"]["commands"].append(desc.strip()[:80])

    return result


def _find_first(paths: list[Path]) -> Path | None:
    """Return the first path that exists, or None."""
    for p in paths:
        if p.is_dir():
            return p
    return None


def check_additional_docs() -> dict:
    """Check documentation quality of supplementary doc sources.

    Scans CEX Integration Guide, troubleshoot docs, and awesome-zenon lists.
    Returns dict with source -> status mapping.
    """
    sources = {}

    # CEX Integration Guide
    cex_path = _find_first(CEX_INTEGRATION_GUIDE_PATHS)
    if cex_path:
        md_count = sum(1 for _ in cex_path.rglob("*.md") if ".git" not in str(_))
        sources["cex_integration_guide"] = {
            "exists": True,
            "path": str(cex_path),
            "md_files": md_count,
        }
    else:
        sources["cex_integration_guide"] = {"exists": False}

    # Troubleshoot docs
    trouble_path = _find_first(TROUBLESHOOT_PATHS)
    if trouble_path:
        md_count = sum(1 for _ in trouble_path.rglob("*.md") if ".git" not in str(_))
        sources["troubleshoot"] = {
            "exists": True,
            "path": str(trouble_path),
            "md_files": md_count,
        }
    else:
        sources["troubleshoot"] = {"exists": False}

    # Awesome lists
    awesome_path = _find_first(AWESOME_ZENON_PATHS)
    if awesome_path:
        readme = awesome_path / "README.md"
        link_count = 0
        if readme.is_file():
            content = _read_file_text(readme)
            link_count = len(re.findall(r"\[.+?\]\(.+?\)", content))
        sources["awesome_zenon"] = {
            "exists": True,
            "path": str(awesome_path),
            "link_count": link_count,
        }
    else:
        sources["awesome_zenon"] = {"exists": False}

    return sources


def check_repo_readmes() -> list[dict]:
    """Check whether key repos have READMEs with build instructions.

    Scans each key repo for: README existence, build instructions,
    API documentation links, and contribution guide.
    """
    results = []
    build_keywords = re.compile(
        r"(build|install|compile|run|setup|getting.started|usage|quick.start)",
        re.IGNORECASE,
    )

    for repo_name, repo_path in KEY_REPOS.items():
        entry = {
            "repo": repo_name,
            "exists": repo_path.is_dir(),
            "has_readme": False,
            "has_build_instructions": False,
            "has_contribution_guide": False,
            "readme_length": 0,
            "grade": "F",
        }

        if not repo_path.is_dir():
            results.append(entry)
            continue

        # Check for README
        readme_path = None
        for name in ["README.md", "readme.md", "README.rst", "README.txt"]:
            candidate = repo_path / name
            if candidate.is_file():
                readme_path = candidate
                break

        if readme_path:
            entry["has_readme"] = True
            content = _read_file_text(readme_path)
            entry["readme_length"] = len(content)

            if build_keywords.search(content):
                entry["has_build_instructions"] = True

            if re.search(r"(contribut|pull.request|pr.guidelines)", content, re.IGNORECASE):
                entry["has_contribution_guide"] = True

        # Check for standalone CONTRIBUTING.md
        if not entry["has_contribution_guide"]:
            for name in ["CONTRIBUTING.md", "contributing.md"]:
                if (repo_path / name).is_file():
                    entry["has_contribution_guide"] = True
                    break

        # Grade
        score = 0
        if entry["has_readme"]:
            score += 30
        if entry["readme_length"] > 500:
            score += 20
        if entry["has_build_instructions"]:
            score += 30
        if entry["has_contribution_guide"]:
            score += 20

        if score >= 80:
            entry["grade"] = "A"
        elif score >= 60:
            entry["grade"] = "B"
        elif score >= 40:
            entry["grade"] = "C"
        elif score >= 20:
            entry["grade"] = "D"
        else:
            entry["grade"] = "F"

        results.append(entry)

    return results


def generate_report() -> dict:
    """Generate a full documentation quality report.

    Returns dict with spec_wiki_coverage, sdk_api_docs, cli_help,
    additional_docs, repo_readmes, and overall grade (A-F).
    """
    wiki_coverage = check_spec_wiki_coverage()
    sdk_docs = check_sdk_api_docs()
    cli_help = check_cli_help()
    additional_docs = check_additional_docs()
    repo_readmes = check_repo_readmes()

    # Calculate scores
    specs_total = len(wiki_coverage)
    specs_documented = sum(1 for s in wiki_coverage if s["has_wiki"])
    wiki_pct = (specs_documented / specs_total * 100) if specs_total else 0

    sdk_total_methods = sum(s["methods_total"] for s in sdk_docs)
    sdk_documented_methods = sum(s["methods_documented"] for s in sdk_docs)
    sdk_pct = (sdk_documented_methods / sdk_total_methods * 100) if sdk_total_methods else 0

    cli_total = cli_help["cli_dart"]["total"] + cli_help["nomctl"]["total"]
    cli_with_help = cli_help["cli_dart"]["with_help"] + cli_help["nomctl"]["with_help"]
    cli_pct = (cli_with_help / cli_total * 100) if cli_total else 0

    # Overall grade (weighted average)
    overall_pct = wiki_pct * 0.4 + sdk_pct * 0.3 + cli_pct * 0.3
    if overall_pct >= 90:
        grade = "A"
    elif overall_pct >= 75:
        grade = "B"
    elif overall_pct >= 60:
        grade = "C"
    elif overall_pct >= 40:
        grade = "D"
    else:
        grade = "F"

    # Identify gaps
    undocumented_specs = [s["spec"] for s in wiki_coverage if not s["has_wiki"]]
    undocumented_sdk_classes = [
        s["class_name"] for s in sdk_docs if s["methods_total"] > 0 and s["methods_documented"] == 0
    ]

    # Repo README scoring
    repos_with_readme = sum(1 for r in repo_readmes if r["has_readme"])
    repos_with_build = sum(1 for r in repo_readmes if r["has_build_instructions"])
    repos_total = sum(1 for r in repo_readmes if r["exists"])
    readme_pct = (repos_with_readme / repos_total * 100) if repos_total else 0

    # Additional docs scoring
    addl_present = sum(1 for v in additional_docs.values() if v.get("exists"))
    addl_total = len(additional_docs)
    addl_pct = (addl_present / addl_total * 100) if addl_total else 0

    return {
        "grade": grade,
        "overall_pct": round(overall_pct, 1),
        "wiki_coverage": {
            "total_specs": specs_total,
            "documented": specs_documented,
            "percentage": round(wiki_pct, 1),
            "undocumented": undocumented_specs,
            "details": wiki_coverage,
        },
        "sdk_api_docs": {
            "total_methods": sdk_total_methods,
            "documented_methods": sdk_documented_methods,
            "percentage": round(sdk_pct, 1),
            "undocumented_classes": undocumented_sdk_classes,
            "details": sdk_docs,
        },
        "cli_help": {
            "total_commands": cli_total,
            "with_help": cli_with_help,
            "percentage": round(cli_pct, 1),
            "details": cli_help,
        },
        "additional_docs": additional_docs,
        "repo_readmes": {
            "total_repos": repos_total,
            "with_readme": repos_with_readme,
            "with_build_instructions": repos_with_build,
            "percentage": round(readme_pct, 1),
            "repos_missing_readme": [
                r["repo"] for r in repo_readmes if r["exists"] and not r["has_readme"]
            ],
            "repos_missing_build_docs": [
                r["repo"]
                for r in repo_readmes
                if r["exists"] and r["has_readme"] and not r["has_build_instructions"]
            ],
            "details": repo_readmes,
        },
        "supplementary_docs": {
            "present": addl_present,
            "total": addl_total,
            "percentage": round(addl_pct, 1),
            "missing": [k for k, v in additional_docs.items() if not v.get("exists")],
        },
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run doc quality analysis and persist findings to evidence table.

    Skips work if none of the key documentation repos have changed.
    Returns the number of findings persisted.
    """
    from core.git_cache import has_repo_changed
    from core.persist_to_db import ensure_schema, persist_finding

    doc_repos = [WIKI_DIR, SDK_DART_DIR, CLI_DART_DIR, NOMCTL_DIR, SPECS_DIR]
    any_changed = False
    for repo_dir in doc_repos:
        # Walk up to the git root
        check = repo_dir
        while check != check.parent:
            if (check / ".git").is_dir():
                break
            check = check.parent
        if (check / ".git").is_dir() and has_repo_changed(str(check)):
            any_changed = True
            break

    if not any_changed:
        logger.debug("Skipping doc quality — no doc repo HEAD changed")
        return 0

    ensure_schema(db_path)
    count = 0

    report = generate_report()

    # Overall finding
    undoc_specs = report["wiki_coverage"]["undocumented"]
    undoc_classes = report["sdk_api_docs"]["undocumented_classes"]
    worst_area = (
        "wiki"
        if report["wiki_coverage"]["percentage"] <= report["sdk_api_docs"]["percentage"]
        else "SDK"
    )
    persist_finding(
        db_path=db_path,
        domain="education",
        engine="doc_quality",
        evidence_type="doc_quality_overall",
        finding=(
            f"WHAT: Documentation grade {report['grade']} ({report['overall_pct']}%) — "
            f"wiki {report['wiki_coverage']['documented']}/{report['wiki_coverage']['total_specs']} specs, "
            f"SDK {report['sdk_api_docs']['documented_methods']}/{report['sdk_api_docs']['total_methods']} methods, "
            f"CLI {report['cli_help']['with_help']}/{report['cli_help']['total_commands']} commands. "
            f"SO WHAT: Low documentation blocks new developer adoption; "
            f"{worst_area} is the weakest area and most urgently needs work. "
            f"NOW WHAT: Write wiki pages for: {', '.join(undoc_specs[:5]) or 'all covered'}; "
            f"add doc comments to SDK classes: {', '.join(undoc_classes[:5]) or 'all covered'}."
        ),
        confidence=0.90,
        raw_data=report,
        source_repo="workspace",
    )
    count += 1

    # Persist gaps for undocumented specs
    for spec in report["wiki_coverage"]["undocumented"]:
        persist_finding(
            db_path=db_path,
            domain="education",
            engine="doc_quality",
            evidence_type="doc_gap_wiki",
            finding=(
                f"WHAT: Spec '{spec}' has no corresponding wiki page. "
                f"SO WHAT: Developers cannot learn about {spec} without reading raw spec files or source code. "
                f"NOW WHAT: Create wiki page for {spec} based on spec in developer-commons/docs/specs/{spec}/."
            ),
            confidence=0.85,
            raw_data={"spec": spec, "gap_type": "wiki"},
            source_repo="knowledge/znn-wiki",
        )
        count += 1

    # Persist gaps for undocumented SDK classes
    for cls in report["sdk_api_docs"]["undocumented_classes"]:
        persist_finding(
            db_path=db_path,
            domain="education",
            engine="doc_quality",
            evidence_type="doc_gap_sdk",
            finding=(
                f"WHAT: SDK API class '{cls}' has zero documented methods. "
                f"SO WHAT: Developers using this class must read source code to understand usage — "
                f"increases onboarding friction and risk of misuse. "
                f"NOW WHAT: Add /// doc comments to all public methods in {cls}.dart."
            ),
            confidence=0.85,
            raw_data={"class": cls, "gap_type": "sdk_api_doc"},
            source_repo="znn_sdk_dart",
        )
        count += 1

    # Persist gaps for repos missing READMEs
    for repo_name in report.get("repo_readmes", {}).get("repos_missing_readme", []):
        persist_finding(
            db_path=db_path,
            domain="education",
            engine="doc_quality",
            evidence_type="doc_gap_readme",
            finding=(
                f"WHAT: Key repo '{repo_name}' has no README. "
                f"SO WHAT: First impression for any developer visiting this repo is a blank page — "
                f"they will leave without understanding what it does or how to build it. "
                f"NOW WHAT: Create README.md with project description, build instructions, and usage examples."
            ),
            confidence=0.90,
            raw_data={"repo": repo_name, "gap_type": "missing_readme"},
            source_repo=repo_name,
        )
        count += 1

    # Persist gaps for repos missing build instructions
    for repo_name in report.get("repo_readmes", {}).get("repos_missing_build_docs", []):
        persist_finding(
            db_path=db_path,
            domain="education",
            engine="doc_quality",
            evidence_type="doc_gap_build_docs",
            finding=(
                f"WHAT: Repo '{repo_name}' README exists but lacks build instructions. "
                f"SO WHAT: Developers can see what the project is but cannot build it without guessing — "
                f"most will give up. "
                f"NOW WHAT: Add a '## Build' section to {repo_name}/README.md with exact commands."
            ),
            confidence=0.80,
            raw_data={"repo": repo_name, "gap_type": "missing_build_docs"},
            source_repo=repo_name,
        )
        count += 1

    # Persist gaps for missing supplementary docs
    for doc_name in report.get("supplementary_docs", {}).get("missing", []):
        persist_finding(
            db_path=db_path,
            domain="education",
            engine="doc_quality",
            evidence_type="doc_gap_supplementary",
            finding=(
                f"WHAT: Supplementary doc source '{doc_name}' not found locally. "
                f"SO WHAT: This documentation resource may have been removed, relocated, "
                f"or never cloned — reducing available learning material. "
                f"NOW WHAT: Clone the repo if it exists upstream, or remove from tracking if deprecated."
            ),
            confidence=0.70,
            raw_data={"source": doc_name, "gap_type": "supplementary"},
            source_repo=doc_name,
        )
        count += 1

    logger.info("DocQuality: persisted %d findings", count)
    return count
