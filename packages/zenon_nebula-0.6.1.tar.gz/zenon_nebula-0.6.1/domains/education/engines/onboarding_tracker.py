# SPDX-License-Identifier: MIT
"""
OnboardingTracker -- Check developer onboarding experience quality.

Evaluates how easy it is for a new developer to get started with Zenon:
- Does each key repo have a README?
- Do READMEs contain build instructions?
- Do CI pipelines exist and pass? (via gh api)
- Are there code examples in SDK repos?
- Counts steps from "git clone" to "running node".
"""

import logging
import os
import re
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# Key repos a developer would encounter first
KEY_REPOS = [
    ("core", "go-zenon"),
    ("core", "syrius"),
    ("core", "znn_sdk_dart"),
    ("core", "znn_cli_dart"),
    ("core", "nomctl"),
    ("hypercore-one", "go-zenon"),
    ("hypercore-one", "hyperqube_z"),
    ("HyperCore-Team", "orchestrator"),
    ("knowledge", "developer-commons"),
    ("knowledge", "znn-wiki"),
    ("knowledge", "awesome-zenon"),
]

# Patterns indicating build instructions in README
BUILD_PATTERNS = [
    re.compile(r"(go\s+build|make\s+build|cargo\s+build)", re.IGNORECASE),
    re.compile(r"(dart\s+pub\s+get|flutter\s+build)", re.IGNORECASE),
    re.compile(r"(npm\s+install|yarn\s+install|pnpm\s+install)", re.IGNORECASE),
    re.compile(r"(pip\s+install|python\s+setup\.py)", re.IGNORECASE),
    re.compile(r"(## (Build|Install|Setup|Getting Started|Quick Start))", re.IGNORECASE),
    re.compile(r"```(bash|shell|sh)\n", re.IGNORECASE),
]

# Patterns indicating code examples
EXAMPLE_PATTERNS = [
    re.compile(r"(example|sample|demo|tutorial|quickstart)", re.IGNORECASE),
    re.compile(r"```(dart|go|typescript|python|javascript)\n", re.IGNORECASE),
]

# GitHub org mapping for CI checks
GH_ORG_MAP = {
    "core": "zenon-network",
    "hypercore-one": "hypercore-one",
    "HyperCore-Team": "HyperCore-Team",
    "knowledge": "zenon-network",
    "zenon-org": "ZenonOrg",
}


def _run_gh(args: list[str], timeout: int = 30) -> tuple[int, str]:
    """Run a gh CLI command. Returns (returncode, stdout)."""
    cmd = ["gh", *args]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def _read_file_text(filepath: Path, max_bytes: int = 200_000) -> str:
    """Read a text file, returning empty string on failure."""
    try:
        return filepath.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def check_readme(repo_path: Path) -> dict:
    """Check if a repo has a README and what it contains.

    Returns dict with: has_readme, has_build_instructions,
    has_examples, readme_length, sections.
    """
    result = {
        "has_readme": False,
        "has_build_instructions": False,
        "has_examples": False,
        "readme_length": 0,
        "sections": [],
    }

    # Check common README file names
    for name in ["README.md", "readme.md", "README.rst", "README.txt", "README"]:
        readme_path = repo_path / name
        if readme_path.is_file():
            result["has_readme"] = True
            text = _read_file_text(readme_path)
            result["readme_length"] = len(text)

            # Extract section headers
            sections = re.findall(r"^##?\s+(.+)$", text, re.MULTILINE)
            result["sections"] = sections[:20]

            # Check for build instructions
            for pattern in BUILD_PATTERNS:
                if pattern.search(text):
                    result["has_build_instructions"] = True
                    break

            # Check for examples
            for pattern in EXAMPLE_PATTERNS:
                if pattern.search(text):
                    result["has_examples"] = True
                    break

            break

    return result


def check_ci_status(local_dir: str, repo_name: str) -> dict:
    """Check CI pipeline status for a repo.

    Checks for:
    1. .github/workflows/ directory (GitHub Actions configured)
    2. gh api for latest workflow run status

    Returns dict with: has_ci, ci_configured, last_status, workflow_count.
    """
    repo_path = Path(local_dir)
    result = {
        "has_ci": False,
        "ci_configured": False,
        "last_status": "unknown",
        "workflow_count": 0,
    }

    # Check for GitHub Actions workflows
    workflows_dir = repo_path / ".github" / "workflows"
    if workflows_dir.is_dir():
        workflow_files = list(workflows_dir.glob("*.yml")) + list(workflows_dir.glob("*.yaml"))
        result["workflow_count"] = len(workflow_files)
        result["ci_configured"] = len(workflow_files) > 0

    # Try to get CI status from GitHub
    gh_org = GH_ORG_MAP.get(local_dir.split("/")[-2], "")
    if gh_org and result["ci_configured"]:
        code, output = _run_gh(
            [
                "api",
                f"repos/{gh_org}/{repo_name}/actions/runs",
                "-f",
                "per_page=1",
                "--jq",
                ".workflow_runs[0].conclusion // .workflow_runs[0].status",
            ]
        )
        if code == 0 and output:
            result["last_status"] = output
            result["has_ci"] = True

    return result


def check_code_examples(repo_path: Path) -> dict:
    """Check if SDK/library repos have code examples.

    Looks for example/ directory, test files with example patterns,
    and inline examples in source files.
    """
    result = {
        "has_example_dir": False,
        "has_example_files": False,
        "example_count": 0,
    }

    # Check for example directory
    for dirname in ["example", "examples", "sample", "samples", "demo"]:
        if (repo_path / dirname).is_dir():
            result["has_example_dir"] = True
            example_files = list((repo_path / dirname).rglob("*"))
            result["example_count"] = len(
                [f for f in example_files if f.is_file() and not f.name.startswith(".")]
            )
            break

    # Check for example test files
    if not result["has_example_dir"]:
        for test_dir in ["test", "tests", "test_integration"]:
            test_path = repo_path / test_dir
            if test_path.is_dir():
                for f in test_path.rglob("*example*"):
                    if f.is_file():
                        result["has_example_files"] = True
                        result["example_count"] += 1

    return result


def estimate_onboarding_steps(repo_path: Path) -> dict:
    """Estimate the number of steps from git clone to running.

    Reads README and build files to count distinct setup steps.
    Returns dict with: estimated_steps, steps_list, complexity.
    """
    steps = ["git clone"]
    check_readme(repo_path)

    # Check for dependency files
    if (repo_path / "go.mod").is_file():
        steps.append("go mod download")
    if (repo_path / "pubspec.yaml").is_file():
        steps.append("dart pub get")
    if (repo_path / "package.json").is_file():
        steps.append("npm install")
    if (repo_path / "requirements.txt").is_file():
        steps.append("pip install -r requirements.txt")
    if (repo_path / "Makefile").is_file():
        steps.append("make build")
    elif (repo_path / "go.mod").is_file():
        steps.append("go build ./...")
    elif (repo_path / "pubspec.yaml").is_file():
        steps.append("dart compile / flutter build")

    # Check for config files that need setup
    for config in [".env.example", "config.example.json", "config.yaml.example"]:
        if (repo_path / config).is_file():
            steps.append(f"configure {config}")

    step_count = len(steps)
    if step_count <= 3:
        complexity = "easy"
    elif step_count <= 5:
        complexity = "moderate"
    else:
        complexity = "complex"

    return {
        "estimated_steps": step_count,
        "steps_list": steps,
        "complexity": complexity,
    }


def generate_report() -> dict:
    """Generate a full onboarding quality report.

    Returns dict with per-repo analysis and overall onboarding score.
    """
    repo_reports = []

    for local_dir, repo_name in KEY_REPOS:
        repo_path = ZENON_WORKSPACE / local_dir / repo_name
        if not repo_path.is_dir():
            repo_reports.append(
                {
                    "repo": f"{local_dir}/{repo_name}",
                    "exists": False,
                }
            )
            continue

        readme_info = check_readme(repo_path)
        ci_info = check_ci_status(str(repo_path), repo_name)
        example_info = check_code_examples(repo_path)
        onboarding_info = estimate_onboarding_steps(repo_path)

        # Per-repo score (0-100)
        score = 0
        if readme_info["has_readme"]:
            score += 25
        if readme_info["has_build_instructions"]:
            score += 25
        if ci_info["ci_configured"]:
            score += 15
        if ci_info["has_ci"] and ci_info["last_status"] in ("success", "completed"):
            score += 10
        if example_info["has_example_dir"] or example_info["has_example_files"]:
            score += 15
        if onboarding_info["complexity"] == "easy":
            score += 10
        elif onboarding_info["complexity"] == "moderate":
            score += 5

        repo_reports.append(
            {
                "repo": f"{local_dir}/{repo_name}",
                "exists": True,
                "score": score,
                "readme": readme_info,
                "ci": ci_info,
                "examples": example_info,
                "onboarding": onboarding_info,
            }
        )

    existing = [r for r in repo_reports if r.get("exists", False)]
    overall_score = (
        round(sum(r.get("score", 0) for r in existing) / len(existing), 1) if existing else 0.0
    )

    # Identify critical gaps
    gaps = []
    for r in existing:
        if not r["readme"]["has_readme"]:
            gaps.append(f"{r['repo']}: missing README")
        elif not r["readme"]["has_build_instructions"]:
            gaps.append(f"{r['repo']}: README lacks build instructions")
        if not r["ci"]["ci_configured"]:
            gaps.append(f"{r['repo']}: no CI configured")

    return {
        "overall_score": overall_score,
        "repos_checked": len(repo_reports),
        "repos_existing": len(existing),
        "gaps": gaps,
        "repo_reports": repo_reports,
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run onboarding analysis and persist findings to evidence table.

    Returns the number of findings persisted.
    """
    from core.persist_to_db import ensure_schema, persist_finding

    ensure_schema(db_path)
    count = 0

    report = generate_report()

    # Overall finding
    gap_count = len(report["gaps"])
    sample_gaps = "; ".join(report["gaps"][:3]) if report["gaps"] else "none"
    persist_finding(
        db_path=db_path,
        domain="education",
        engine="onboarding_tracker",
        evidence_type="onboarding_overall",
        finding=(
            f"WHAT: Developer onboarding score {report['overall_score']}/100 across "
            f"{report['repos_existing']}/{report['repos_checked']} repos; {gap_count} critical gaps. "
            f"SO WHAT: {'Score below 50 means most developers will fail to onboard without external help. ' if report['overall_score'] < 50 else 'Moderate score — some developers can self-serve but gaps remain. '}"
            f"Top gaps: {sample_gaps}. "
            f"NOW WHAT: Fix the {min(gap_count, 3)} highest-impact gaps first: {sample_gaps}."
        ),
        confidence=0.85,
        raw_data=report,
        source_repo="workspace",
    )
    count += 1

    # Persist individual gaps
    for gap in report["gaps"]:
        # gap format is like "core/go-zenon: missing README" or "core/syrius: no CI configured"
        if ": missing README" in gap:
            repo = gap.split(":")[0]
            action = f"Create README.md in {repo} with description, build steps, and usage."
        elif ": README lacks build instructions" in gap:
            repo = gap.split(":")[0]
            action = f"Add '## Build' section with exact commands to {repo}/README.md."
        elif ": no CI configured" in gap:
            repo = gap.split(":")[0]
            action = f"Add .github/workflows/ with build+test pipeline for {repo}."
        else:
            action = f"Investigate and resolve: {gap}."
        persist_finding(
            db_path=db_path,
            domain="education",
            engine="onboarding_tracker",
            evidence_type="onboarding_gap",
            finding=(
                f"WHAT: {gap}. "
                f"SO WHAT: This blocks developer onboarding for this repo. "
                f"NOW WHAT: {action}"
            ),
            confidence=0.80,
            raw_data={"gap": gap},
            source_repo=gap.split(":")[0] if ":" in gap else "workspace",
        )
        count += 1

    # Enrich with GitHub CI status for key repos
    try:
        from core.github_api import get_ci_status

        for local_dir, repo_name in KEY_REPOS:
            gh_org = GH_ORG_MAP.get(local_dir)
            if not gh_org:
                continue
            ci = get_ci_status(gh_org, repo_name)
            if ci and ci.get("state") not in (None, "unknown"):
                ci_state = ci["state"]
                status_count = ci.get("total_count", 0)
                persist_finding(
                    db_path=db_path,
                    domain="education",
                    engine="onboarding_tracker",
                    evidence_type="repo_ci_status",
                    finding=(
                        f"WHAT: {local_dir}/{repo_name} CI status: {ci_state} "
                        f"({status_count} check(s)). "
                        f"SO WHAT: {'Failing CI blocks onboarding — new devs cannot verify their setup.' if ci_state == 'failure' else 'Passing CI confirms build instructions work.' if ci_state == 'success' else f'CI state is {ci_state} — may need investigation.'} "
                        f"NOW WHAT: {'Fix CI pipeline before recommending this repo to new developers.' if ci_state == 'failure' else 'No action needed.'}"
                    ),
                    confidence=0.85,
                    raw_data=ci,
                    source_repo=f"{local_dir}/{repo_name}",
                )
                count += 1
    except Exception as exc:
        # GitHub API unavailable — local checks are sufficient
        logger.debug("OnboardingTracker GitHub enrichment skipped: %s", exc)

    logger.info("OnboardingTracker: persisted %d findings", count)
    return count
