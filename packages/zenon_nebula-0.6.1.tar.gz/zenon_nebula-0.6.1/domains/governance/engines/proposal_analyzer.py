# SPDX-License-Identifier: MIT
"""
ProposalAnalyzer -- Parse AZ proposals and track lifecycle.

Fetches proposal data from zenonhub API, tracks status transitions
(submitted -> voting -> funded -> delivered), and persists to DB.
"""

import logging
import sqlite3
from pathlib import Path

from core.persistence import connect
from core.zenon_data import get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZNN_DECIMALS = 8
QSR_DECIMALS = 8

# Proposal status mapping (from znnd constants)
STATUS_MAP = {
    0: "submitted",
    1: "voting",
    2: "funded",
    3: "completed",
    4: "closed",
}


def fetch_all_proposals(max_pages: int = 10) -> list[dict]:
    """Return all Accelerator-Z projects using paginated RPC reads.

    Each page fetches up to 50 projects via ``embedded.accelerator.getAll``.
    Returns an empty list when the node is unreachable.

    Args:
        max_pages: Maximum number of pages to walk. Each page is 50 items.
    """
    rpc = get_zenon_data()
    all_proposals: list[dict] = []
    for page in range(max_pages):
        items = rpc.get_all_projects(page=page, count=50)
        if not items:
            break
        all_proposals.extend(items)
        if len(items) < 50:
            break
    return all_proposals


def parse_proposal(raw: dict) -> dict:
    """Parse a raw API proposal into a normalized structure."""
    status_code = raw.get("status", 0)
    return {
        "proposal_id": raw.get("id", ""),
        "title": raw.get("name", raw.get("title", "Untitled")),
        "description": raw.get("description", "")[:2000],
        "owner_address": raw.get("owner", raw.get("ownerAddress", "")),
        "znn_requested": float(raw.get("znnFundsNeeded", 0)) / (10**ZNN_DECIMALS),
        "qsr_requested": float(raw.get("qsrFundsNeeded", 0)) / (10**QSR_DECIMALS),
        "status": STATUS_MAP.get(status_code, f"unknown_{status_code}"),
        "votes_yes": raw.get("yesVotes", raw.get("votesYes", 0)),
        "votes_no": raw.get("noVotes", raw.get("votesNo", 0)),
        "votes_abstain": raw.get("abstainVotes", raw.get("votesAbstain", 0)),
        "created_at": raw.get("creationTimestamp", raw.get("createdAt", "")),
    }


def persist_proposals(
    proposals: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Persist parsed proposals to the az_proposals table.

    Uses INSERT OR REPLACE to update existing proposals.
    Returns dict with counts: inserted, updated, total.
    """
    conn = connect(db_path)
    inserted = 0
    updated = 0
    try:
        for p in proposals:
            # Check if exists
            existing = conn.execute(
                "SELECT id, status FROM az_proposals WHERE proposal_id = ?",
                (p["proposal_id"],),
            ).fetchone()

            if existing:
                old_status = existing[1]
                conn.execute(
                    """UPDATE az_proposals SET
                       title = ?, description = ?, status = ?,
                       votes_yes = ?, votes_no = ?, votes_abstain = ?,
                       last_updated = CURRENT_TIMESTAMP,
                       funded_at = CASE WHEN ? = 'funded' AND ? != 'funded'
                                        THEN CURRENT_TIMESTAMP ELSE funded_at END,
                       delivered_at = CASE WHEN ? = 'completed' AND ? != 'completed'
                                           THEN CURRENT_TIMESTAMP ELSE delivered_at END
                       WHERE proposal_id = ?""",
                    (
                        p["title"],
                        p["description"],
                        p["status"],
                        p["votes_yes"],
                        p["votes_no"],
                        p["votes_abstain"],
                        p["status"],
                        old_status,
                        p["status"],
                        old_status,
                        p["proposal_id"],
                    ),
                )
                updated += 1
            else:
                conn.execute(
                    """INSERT INTO az_proposals
                       (proposal_id, title, description, owner_address,
                        znn_requested, qsr_requested, status,
                        votes_yes, votes_no, votes_abstain, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        p["proposal_id"],
                        p["title"],
                        p["description"],
                        p["owner_address"],
                        p["znn_requested"],
                        p["qsr_requested"],
                        p["status"],
                        p["votes_yes"],
                        p["votes_no"],
                        p["votes_abstain"],
                        p["created_at"],
                    ),
                )
                inserted += 1
        conn.commit()
    finally:
        conn.close()

    return {"inserted": inserted, "updated": updated, "total": len(proposals)}


def get_proposal_lifecycle_stats(*, db_path: str = DEFAULT_DB) -> dict:
    """Get statistics on proposal lifecycle stages.

    Returns counts per status, avg time-to-fund, avg time-to-deliver.
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        # Status counts
        status_rows = conn.execute(
            """SELECT status, COUNT(*) as cnt FROM az_proposals
               GROUP BY status"""
        ).fetchall()
        status_counts = {r["status"]: r["cnt"] for r in status_rows}

        # Funding totals
        funding = conn.execute(
            """SELECT
                 SUM(CASE WHEN status IN ('funded', 'completed') THEN znn_requested ELSE 0 END) as znn_funded,
                 SUM(CASE WHEN status IN ('funded', 'completed') THEN qsr_requested ELSE 0 END) as qsr_funded,
                 SUM(znn_requested) as znn_total_requested,
                 SUM(qsr_requested) as qsr_total_requested,
                 COUNT(*) as total_proposals
               FROM az_proposals"""
        ).fetchone()

        return {
            "status_counts": status_counts,
            "total_proposals": funding["total_proposals"] or 0,
            "znn_funded": funding["znn_funded"] or 0.0,
            "qsr_funded": funding["qsr_funded"] or 0.0,
            "znn_total_requested": funding["znn_total_requested"] or 0.0,
            "qsr_total_requested": funding["qsr_total_requested"] or 0.0,
        }
    finally:
        conn.close()


def get_top_requesters(
    *,
    db_path: str = DEFAULT_DB,
    limit: int = 10,
) -> list[dict]:
    """Get addresses that have requested the most funding."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT owner_address,
                      COUNT(*) as proposal_count,
                      SUM(znn_requested) as total_znn,
                      SUM(qsr_requested) as total_qsr
               FROM az_proposals
               GROUP BY owner_address
               ORDER BY total_znn DESC
               LIMIT ?""",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def run_proposal_sync(*, db_path: str = DEFAULT_DB) -> dict:
    """Run a full proposal sync: fetch from API, parse, persist.

    Returns dict with sync results and lifecycle stats.
    """
    raw_proposals = fetch_all_proposals()
    if not raw_proposals:
        return {
            "success": False,
            "error": "Failed to fetch proposals from API.",
        }

    parsed = [parse_proposal(p) for p in raw_proposals]
    persist_result = persist_proposals(parsed, db_path=db_path)
    lifecycle = get_proposal_lifecycle_stats(db_path=db_path)

    # Persist actionable finding
    try:
        from core.persist_to_db import ensure_schema, persist_finding

        ensure_schema(db_path)

        status_counts = lifecycle.get("status_counts", {})
        total = lifecycle.get("total_proposals", 0)
        znn_funded = lifecycle.get("znn_funded", 0)
        znn_requested = lifecycle.get("znn_total_requested", 0)
        funded_count = status_counts.get("funded", 0) + status_counts.get("completed", 0)
        voting_count = status_counts.get("voting", 0)
        fund_rate = (funded_count / max(total, 1)) * 100

        if voting_count > 5:
            urgency = f"{voting_count} proposals awaiting votes -- pillar participation needed."
            action = (
                f"Review and vote on {voting_count} pending proposals to unblock funding pipeline."
            )
        elif fund_rate < 30:
            urgency = f"Only {fund_rate:.0f}% of proposals get funded -- high rejection may discourage builders."
            action = (
                "Analyze rejected proposals for common gaps; publish proposal-writing guidelines."
            )
        else:
            urgency = f"Funding rate {fund_rate:.0f}% is healthy."
            action = "Continue monitoring; check for proposal quality trends and repeat requesters."

        persist_finding(
            db_path=db_path,
            domain="governance",
            engine="proposal_analyzer",
            evidence_type="proposal_sync",
            finding=(
                f"WHAT: {total} AZ proposals tracked. {funded_count} funded ({fund_rate:.0f}%), "
                f"{voting_count} in voting, {znn_funded:,.0f}/{znn_requested:,.0f} ZNN disbursed. "
                f"SO WHAT: {urgency} "
                f"NOW WHAT: {action}"
            ),
            confidence=0.80,
            raw_data=lifecycle,
            source_repo="zenon_rpc",
        )
    except Exception as exc:
        logger.debug("Proposal finding persistence failed: %s", exc)

    return {
        "success": True,
        "fetched": len(raw_proposals),
        **persist_result,
        "lifecycle": lifecycle,
    }
