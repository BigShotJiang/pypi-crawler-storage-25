# SPDX-License-Identifier: MIT
"""
GovernanceIntel -- Analyze AZ proposal patterns and predict outcomes.

Queries az_proposals and pillar_votes tables (populated by proposal_analyzer
and voting_patterns engines), calculates aggregate governance health metrics,
detects stuck proposals, identifies voting blocs, and predicts pass/fail
for pending proposals based on historical pillar behavior.

No LLM required -- pure SQL aggregation and statistical analysis.
"""

import logging
import sqlite3
from collections import defaultdict
from pathlib import Path

from core.config import get_config
from core.persist_to_db import ensure_schema, persist_finding
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Thresholds — sourced from config/engine_defaults.json with safe fallbacks.
_gi_cfg = get_config().engine("governance_intel")
STUCK_PROPOSAL_DAYS = _gi_cfg.get("stuck_proposal_days", 30)
INACTIVE_PILLAR_DAYS = _gi_cfg.get("inactive_pillar_days", 90)
QUORUM_THRESHOLD = _gi_cfg.get("quorum_threshold", 15)  # Minimum yes votes for quorum
APPROVAL_VOTE_THRESHOLD = _gi_cfg.get("approval_vote_threshold", 0.5)  # >50% yes of votes cast


def _get_conn(db_path: str) -> sqlite3.Connection:
    """Return a connection with Row factory enabled."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


# ---------- metrics ----------


def calculate_funding_metrics(*, db_path: str = DEFAULT_DB) -> dict:
    """Calculate proposal funding statistics.

    Returns average time to approval, funding rate, total amounts.
    """
    conn = _get_conn(db_path)
    try:
        # Total requested vs approved
        totals = conn.execute(
            """SELECT
                 COUNT(*) as total_proposals,
                 SUM(znn_requested) as total_znn_requested,
                 SUM(qsr_requested) as total_qsr_requested,
                 SUM(CASE WHEN status IN ('funded', 'completed', 'delivered')
                     THEN znn_requested ELSE 0 END) as znn_approved,
                 SUM(CASE WHEN status IN ('funded', 'completed', 'delivered')
                     THEN qsr_requested ELSE 0 END) as qsr_approved,
                 SUM(CASE WHEN status IN ('funded', 'completed', 'delivered')
                     THEN 1 ELSE 0 END) as approved_count
               FROM az_proposals"""
        ).fetchone()

        total = totals["total_proposals"] or 0
        approved = totals["approved_count"] or 0
        znn_req = totals["total_znn_requested"] or 0
        qsr_req = totals["total_qsr_requested"] or 0
        znn_app = totals["znn_approved"] or 0
        qsr_app = totals["qsr_approved"] or 0

        approval_rate = (approved / total * 100) if total > 0 else 0.0
        znn_funding_rate = (znn_app / znn_req * 100) if znn_req > 0 else 0.0
        qsr_funding_rate = (qsr_app / qsr_req * 100) if qsr_req > 0 else 0.0

        # Average time to approval (for proposals with both created_at and funded_at)
        avg_days = conn.execute(
            """SELECT AVG(julianday(funded_at) - julianday(created_at))
               FROM az_proposals
               WHERE funded_at IS NOT NULL AND created_at IS NOT NULL"""
        ).fetchone()[0]

        return {
            "total_proposals": total,
            "approved_count": approved,
            "approval_rate_pct": round(approval_rate, 1),
            "total_znn_requested": round(znn_req, 2),
            "total_qsr_requested": round(qsr_req, 2),
            "znn_approved": round(znn_app, 2),
            "qsr_approved": round(qsr_app, 2),
            "znn_funding_rate_pct": round(znn_funding_rate, 1),
            "qsr_funding_rate_pct": round(qsr_funding_rate, 1),
            "avg_days_to_approval": round(avg_days, 1) if avg_days else None,
        }
    finally:
        conn.close()


def find_stuck_proposals(
    *,
    days_threshold: int = STUCK_PROPOSAL_DAYS,
    db_path: str = DEFAULT_DB,
) -> list[dict]:
    """Find proposals that have been pending longer than the threshold.

    Returns list of proposal dicts with age and vote counts.
    """
    conn = _get_conn(db_path)
    try:
        rows = conn.execute(
            """SELECT
                 p.proposal_id,
                 p.title,
                 p.owner_address,
                 p.znn_requested,
                 p.qsr_requested,
                 p.votes_yes,
                 p.votes_no,
                 p.votes_abstain,
                 p.created_at,
                 julianday('now') - julianday(p.created_at) as age_days
               FROM az_proposals p
               WHERE p.status IN ('submitted', 'voting', 'active')
                 AND p.created_at IS NOT NULL
                 AND julianday('now') - julianday(p.created_at) > ?
               ORDER BY age_days DESC""",
            (days_threshold,),
        ).fetchall()

        return [
            {
                "proposal_id": r["proposal_id"],
                "title": r["title"],
                "owner_address": r["owner_address"],
                "znn_requested": r["znn_requested"],
                "qsr_requested": r["qsr_requested"],
                "votes_yes": r["votes_yes"] or 0,
                "votes_no": r["votes_no"] or 0,
                "votes_abstain": r["votes_abstain"] or 0,
                "age_days": round(r["age_days"], 0),
            }
            for r in rows
        ]
    finally:
        conn.close()


def calculate_pillar_participation(*, db_path: str = DEFAULT_DB) -> dict:
    """Calculate per-pillar participation rates and find inactive pillars.

    Returns participation summary and list of most/least active pillars.
    """
    conn = _get_conn(db_path)
    try:
        total_proposals = (
            conn.execute("SELECT COUNT(DISTINCT proposal_id) FROM pillar_votes").fetchone()[0] or 1
        )

        # Per-pillar vote counts
        pillars = conn.execute(
            """SELECT
                 pillar_name,
                 COUNT(*) as votes_cast,
                 SUM(CASE WHEN vote = 'yes' THEN 1 ELSE 0 END) as yes_count,
                 SUM(CASE WHEN vote = 'no' THEN 1 ELSE 0 END) as no_count,
                 MAX(timestamp) as last_vote
               FROM pillar_votes
               GROUP BY pillar_name
               ORDER BY votes_cast DESC"""
        ).fetchall()

        active: list[dict] = []
        inactive: list[dict] = []

        for p in pillars:
            entry = {
                "pillar_name": p["pillar_name"],
                "votes_cast": p["votes_cast"],
                "participation_rate": round(p["votes_cast"] / total_proposals * 100, 1),
                "yes_rate": round((p["yes_count"] or 0) / max(p["votes_cast"], 1) * 100, 1),
                "last_vote": p["last_vote"],
            }

            # Check if last vote is older than INACTIVE_PILLAR_DAYS
            last_vote_age = (
                conn.execute(
                    "SELECT julianday('now') - julianday(?)",
                    (p["last_vote"],),
                ).fetchone()[0]
                if p["last_vote"]
                else 999
            )

            if last_vote_age and last_vote_age > INACTIVE_PILLAR_DAYS:
                inactive.append(entry)
            else:
                active.append(entry)

        return {
            "total_proposals_with_votes": total_proposals,
            "total_voting_pillars": len(pillars),
            "active_pillars": len(active),
            "inactive_pillars": len(inactive),
            "most_active": active[:10],
            "least_active": (active[-5:] if len(active) > 5 else active),
            "inactive_list": inactive[:20],
        }
    finally:
        conn.close()


def detect_voting_blocs(
    *,
    agreement_threshold: float = 0.80,
    min_shared_votes: int = 5,
    db_path: str = DEFAULT_DB,
) -> list[dict]:
    """Detect pairs of pillars that tend to vote together.

    Two pillars form a bloc if they agree on >= agreement_threshold
    fraction of proposals where both voted, with at least min_shared_votes
    in common.

    Returns list of bloc dicts sorted by agreement rate.
    """
    conn = _get_conn(db_path)
    try:
        # Get all votes as {pillar_name: {proposal_id: vote}}
        rows = conn.execute("SELECT pillar_name, proposal_id, vote FROM pillar_votes").fetchall()

        pillar_votes: dict[str, dict[str, str]] = defaultdict(dict)
        for r in rows:
            pillar_votes[r["pillar_name"]][r["proposal_id"]] = r["vote"]

        pillar_names = sorted(pillar_votes.keys())
        blocs: list[dict] = []

        for i in range(len(pillar_names)):
            for j in range(i + 1, len(pillar_names)):
                p1 = pillar_names[i]
                p2 = pillar_names[j]
                v1 = pillar_votes[p1]
                v2 = pillar_votes[p2]

                shared_proposals = set(v1.keys()) & set(v2.keys())
                if len(shared_proposals) < min_shared_votes:
                    continue

                agreements = sum(1 for pid in shared_proposals if v1[pid] == v2[pid])
                agreement_rate = agreements / len(shared_proposals)

                if agreement_rate >= agreement_threshold:
                    blocs.append(
                        {
                            "pillar_a": p1,
                            "pillar_b": p2,
                            "shared_votes": len(shared_proposals),
                            "agreements": agreements,
                            "agreement_rate": round(agreement_rate, 3),
                        }
                    )

        blocs.sort(key=lambda b: (-b["agreement_rate"], -b["shared_votes"]))
        return blocs[:50]  # Cap at 50 to avoid noise
    finally:
        conn.close()


def estimate_treasury_runway(*, db_path: str = DEFAULT_DB) -> dict | None:
    """Estimate how long the AZ treasury can sustain current funding rate.

    Uses the latest treasury snapshot and average monthly funding.
    Returns runway dict or None if insufficient data.
    """
    conn = _get_conn(db_path)
    try:
        # Latest treasury snapshot
        snapshot = conn.execute(
            """SELECT znn_balance, qsr_balance, znn_funded_30d, qsr_funded_30d
               FROM treasury_snapshots
               ORDER BY timestamp DESC LIMIT 1"""
        ).fetchone()

        if not snapshot:
            return None

        znn_balance = snapshot["znn_balance"] or 0
        qsr_balance = snapshot["qsr_balance"] or 0
        znn_monthly = snapshot["znn_funded_30d"] or 0
        qsr_monthly = snapshot["qsr_funded_30d"] or 0

        znn_runway = (znn_balance / znn_monthly) if znn_monthly > 0 else float("inf")
        qsr_runway = (qsr_balance / qsr_monthly) if qsr_monthly > 0 else float("inf")

        # Runway is limited by whichever runs out first
        effective_runway = min(znn_runway, qsr_runway)
        if effective_runway == float("inf"):
            effective_runway = -1  # -1 signals "no outflow"

        return {
            "znn_balance": round(znn_balance, 2),
            "qsr_balance": round(qsr_balance, 2),
            "znn_monthly_outflow": round(znn_monthly, 2),
            "qsr_monthly_outflow": round(qsr_monthly, 2),
            "znn_runway_months": round(znn_runway, 1) if znn_runway != float("inf") else -1,
            "qsr_runway_months": round(qsr_runway, 1) if qsr_runway != float("inf") else -1,
            "effective_runway_months": round(effective_runway, 1),
        }
    finally:
        conn.close()


def predict_proposal_outcome(
    proposal_id: str,
    *,
    db_path: str = DEFAULT_DB,
) -> dict | None:
    """Predict pass/fail for a pending proposal based on historical behavior.

    For each pillar that has NOT yet voted on this proposal, predict their
    likely vote based on their historical yes/no ratio. Sum predicted votes
    with actual votes to estimate outcome.

    Returns prediction dict or None if proposal not found.
    """
    conn = _get_conn(db_path)
    try:
        # Get current votes for this proposal
        proposal = conn.execute(
            """SELECT proposal_id, title, votes_yes, votes_no, votes_abstain
               FROM az_proposals WHERE proposal_id = ?""",
            (proposal_id,),
        ).fetchone()

        if not proposal:
            return None

        current_yes = proposal["votes_yes"] or 0
        current_no = proposal["votes_no"] or 0

        # Get pillars who already voted on this proposal
        voted = conn.execute(
            "SELECT pillar_name FROM pillar_votes WHERE proposal_id = ?",
            (proposal_id,),
        ).fetchall()
        voted_names = {r["pillar_name"] for r in voted}

        # Get historical yes rate for pillars who haven't voted
        pending_pillars = conn.execute(
            """SELECT pillar_name,
                 SUM(CASE WHEN vote = 'yes' THEN 1 ELSE 0 END) as yes_count,
                 COUNT(*) as total_votes
               FROM pillar_votes
               WHERE pillar_name NOT IN ({})
               GROUP BY pillar_name
               HAVING total_votes >= 3""".format(
                ",".join("?" * len(voted_names)) if voted_names else "''"
            ),
            tuple(voted_names) if voted_names else (),
        ).fetchall()

        predicted_yes = 0.0
        predicted_no = 0.0
        predictions: list[dict] = []

        for p in pending_pillars:
            yes_rate = (p["yes_count"] or 0) / max(p["total_votes"], 1)
            predicted_yes += yes_rate
            predicted_no += 1 - yes_rate
            predictions.append(
                {
                    "pillar": p["pillar_name"],
                    "historical_yes_rate": round(yes_rate, 2),
                    "predicted_vote": "yes" if yes_rate > 0.5 else "no",
                }
            )

        total_predicted_yes = current_yes + predicted_yes
        total_predicted_no = current_no + predicted_no
        total_predicted = total_predicted_yes + total_predicted_no

        pass_probability = total_predicted_yes / total_predicted if total_predicted > 0 else 0.0

        quorum_likely = total_predicted_yes >= QUORUM_THRESHOLD

        return {
            "proposal_id": proposal_id,
            "title": proposal["title"],
            "current_yes": current_yes,
            "current_no": current_no,
            "predicted_additional_yes": round(predicted_yes, 1),
            "predicted_additional_no": round(predicted_no, 1),
            "total_predicted_yes": round(total_predicted_yes, 1),
            "total_predicted_no": round(total_predicted_no, 1),
            "pass_probability": round(pass_probability, 3),
            "quorum_likely": quorum_likely,
            "pending_pillar_predictions": predictions[:20],
        }
    finally:
        conn.close()


# ---------- main entry point ----------


def run_governance_intel(*, db_path: str = DEFAULT_DB) -> dict:
    """Run the full governance intelligence analysis.

    Aggregates funding metrics, stuck proposals, participation,
    voting blocs, treasury runway, and outcome predictions.
    Persists actionable findings.

    Returns summary dict.
    """
    ensure_schema(db_path)

    funding = calculate_funding_metrics(db_path=db_path)
    stuck = find_stuck_proposals(db_path=db_path)
    participation = calculate_pillar_participation(db_path=db_path)
    blocs = detect_voting_blocs(db_path=db_path)
    runway = estimate_treasury_runway(db_path=db_path)

    # Predict outcomes for pending proposals
    conn = _get_conn(db_path)
    try:
        pending = conn.execute(
            """SELECT proposal_id FROM az_proposals
               WHERE status IN ('submitted', 'voting', 'active')"""
        ).fetchall()
    finally:
        conn.close()

    predictions: list[dict] = []
    for row in pending:
        pred = predict_proposal_outcome(row["proposal_id"], db_path=db_path)
        if pred:
            predictions.append(pred)

    findings_count = 0

    # Finding 1: Stuck proposals
    if stuck:
        stuck_ids = [s["title"] or s["proposal_id"] for s in stuck[:5]]
        stuck_ages = [int(s["age_days"]) for s in stuck[:5]]
        finding = (
            f"WHAT: {len(stuck)} AZ proposals stuck >{STUCK_PROPOSAL_DAYS} days "
            f"without reaching quorum. Oldest: {max(stuck_ages)} days. "
            f"Examples: {', '.join(stuck_ids[:3])}. "
            f"SO WHAT: Governance is stalling -- proposals cannot advance "
            f"without sufficient pillar participation. Requesters are blocked. "
            f"NOW WHAT: Community should reach out to inactive pillars; "
            f"consider whether quorum threshold needs adjustment."
        )
        persist_finding(
            db_path=db_path,
            domain="governance",
            engine="governance_intel",
            evidence_type="stuck_proposals",
            finding=finding,
            confidence=0.85,
            raw_data={"stuck_proposals": stuck},
            source_repo="zenonhub_api",
        )
        findings_count += 1

    # Finding 2: Inactive pillars
    inactive_count = participation.get("inactive_pillars", 0)
    if inactive_count > 0:
        inactive_names = [p["pillar_name"] for p in participation.get("inactive_list", [])[:5]]
        finding = (
            f"WHAT: {inactive_count} pillars have not voted on any proposal "
            f"in {INACTIVE_PILLAR_DAYS}+ days. "
            f"Examples: {', '.join(inactive_names) if inactive_names else 'N/A'}. "
            f"SO WHAT: Inactive pillars reduce effective governance participation, "
            f"making quorum harder to reach and concentrating power among active voters. "
            f"NOW WHAT: Publish pillar participation leaderboard; consider governance "
            f"incentives tied to voting activity."
        )
        persist_finding(
            db_path=db_path,
            domain="governance",
            engine="governance_intel",
            evidence_type="inactive_pillars",
            finding=finding,
            confidence=0.80,
            raw_data={"inactive_count": inactive_count, "inactive_list": inactive_names},
            source_repo="zenonhub_api",
        )
        findings_count += 1

    # Finding 3: Voting blocs
    if blocs:
        top_bloc = blocs[0]
        finding = (
            f"WHAT: {len(blocs)} voting bloc pairs detected "
            f"(>{int(0.80 * 100)}% agreement rate). "
            f"Strongest: {top_bloc['pillar_a']} + {top_bloc['pillar_b']} "
            f"agree {top_bloc['agreement_rate']:.0%} of the time "
            f"({top_bloc['shared_votes']} shared votes). "
            f"SO WHAT: Voting blocs indicate coordinated governance behavior. "
            f"This is not inherently bad but concentrates decision-making. "
            f"NOW WHAT: Monitor for bloc growth; ensure no single bloc can "
            f"unilaterally pass or block proposals."
        )
        persist_finding(
            db_path=db_path,
            domain="governance",
            engine="governance_intel",
            evidence_type="voting_blocs",
            finding=finding,
            confidence=0.75,
            raw_data={"bloc_count": len(blocs), "top_blocs": blocs[:10]},
            source_repo="zenonhub_api",
        )
        findings_count += 1

    # Finding 4: Treasury runway
    if runway and runway["effective_runway_months"] > 0:
        runway_months = runway["effective_runway_months"]
        urgency = (
            "critical" if runway_months < 6 else ("concerning" if runway_months < 12 else "healthy")
        )
        finding = (
            f"WHAT: AZ treasury has ~{runway_months:.0f} months runway at current "
            f"funding rate ({runway['znn_monthly_outflow']:.0f} ZNN/month, "
            f"{runway['qsr_monthly_outflow']:.0f} QSR/month). "
            f"Balances: {runway['znn_balance']:.0f} ZNN, {runway['qsr_balance']:.0f} QSR. "
            f"SO WHAT: Treasury sustainability is {urgency}. "
            f"{'Immediate action needed to reduce burn rate or increase inflows.' if urgency == 'critical' else ''}"
            f"{'Funding rate should be monitored closely.' if urgency == 'concerning' else ''}"
            f"{'Current pace is sustainable.' if urgency == 'healthy' else ''} "
            f"NOW WHAT: {'Reduce approval rate or increase treasury inflows.' if runway_months < 12 else 'Continue monitoring; publish quarterly treasury reports.'}"
        )
        confidence = 0.70 if runway_months < 12 else 0.80
        persist_finding(
            db_path=db_path,
            domain="governance",
            engine="governance_intel",
            evidence_type="treasury_runway",
            finding=finding,
            confidence=confidence,
            raw_data=runway,
            source_repo="zenonhub_api",
        )
        findings_count += 1

    # Finding 5: Funding overview
    if funding["total_proposals"] > 0:
        finding = (
            f"WHAT: {funding['total_proposals']} total AZ proposals, "
            f"{funding['approved_count']} approved ({funding['approval_rate_pct']}% rate). "
            f"ZNN funding rate: {funding['znn_funding_rate_pct']}% of requested. "
            f"QSR funding rate: {funding['qsr_funding_rate_pct']}% of requested. "
            f"{'Avg ' + str(funding['avg_days_to_approval']) + ' days to approval. ' if funding['avg_days_to_approval'] else ''}"
            f"SO WHAT: "
            f"{'Low approval rate suggests high bar or misaligned proposals.' if funding['approval_rate_pct'] < 30 else ''}"
            f"{'Moderate approval rate -- governance is selective.' if 30 <= funding['approval_rate_pct'] < 60 else ''}"
            f"{'High approval rate -- most proposals pass.' if funding['approval_rate_pct'] >= 60 else ''} "
            f"NOW WHAT: Track approval trends over time to detect governance shifts."
        )
        persist_finding(
            db_path=db_path,
            domain="governance",
            engine="governance_intel",
            evidence_type="funding_overview",
            finding=finding,
            confidence=0.85,
            raw_data=funding,
            source_repo="zenonhub_api",
        )
        findings_count += 1

    logger.info(
        "GovernanceIntel: analyzed %d proposals, %d stuck, %d blocs, "
        "%d predictions, %d findings persisted",
        funding.get("total_proposals", 0),
        len(stuck),
        len(blocs),
        len(predictions),
        findings_count,
    )

    return {
        "success": True,
        "funding": funding,
        "stuck_proposals": stuck,
        "participation": participation,
        "voting_blocs": blocs,
        "treasury_runway": runway,
        "predictions": predictions,
        "findings_persisted": findings_count,
    }
