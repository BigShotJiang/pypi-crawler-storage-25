# SPDX-License-Identifier: MIT
"""
TreasuryMonitor -- Track AZ treasury balance, funding rate, and runway estimation.

Queries the zenonhub API for current treasury balances, calculates funding
rate over trailing windows, and estimates runway in months.
"""

import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persist_to_db import persist_metric, query_table
from core.zenon_data import EMBEDDED_ADDRESSES, TOKEN_DECIMALS, get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZNN_DECIMALS = 8
QSR_DECIMALS = 8

# Accelerator-Z contract address (source of truth: core.zenon_data).
AZ_ADDRESS = EMBEDDED_ADDRESSES["accelerator"]


def fetch_treasury_balance() -> dict | None:
    """Return the Accelerator-Z treasury balance.

    Uses ``ledger.getAccountInfoByAddress`` on the AZ contract address.
    Returns ``{znn_balance, qsr_balance}`` in human units, or ``None``
    when the node is unreachable.
    """
    rpc = get_zenon_data()
    if not rpc.is_reachable():
        return None
    balances = rpc.get_balance(AZ_ADDRESS)
    return {
        "znn_balance": balances.get("znn", 0) / TOKEN_DECIMALS,
        "qsr_balance": balances.get("qsr", 0) / TOKEN_DECIMALS,
    }


def fetch_recent_proposals(page: int = 0, count: int = 50) -> list | None:
    """Return recent Accelerator-Z projects.

    Uses ``embedded.accelerator.getAll``. Returns ``None`` when the node
    is unreachable; returns an empty list when there are no projects.
    """
    rpc = get_zenon_data()
    if not rpc.is_reachable():
        return None
    return rpc.get_all_projects(page=page, count=count)


def calculate_funding_rate(
    *,
    db_path: str = DEFAULT_DB,
    window_days: int = 30,
) -> dict:
    """Calculate funding rate from treasury snapshots.

    Returns dict with znn_per_month, qsr_per_month, based on balance change
    over the specified window.
    """
    cutoff = (datetime.now(timezone.utc) - timedelta(days=window_days)).isoformat()

    rows = query_table(
        db_path=db_path,
        table="treasury_snapshots",
        where="timestamp >= ?",
        params=(cutoff,),
        order_by="timestamp ASC",
        limit=0,
    )

    if len(rows) < 2:
        return {
            "znn_per_month": 0.0,
            "qsr_per_month": 0.0,
            "data_points": len(rows),
        }

    first = rows[0]
    last = rows[-1]
    t0 = datetime.fromisoformat(first["timestamp"].replace("Z", "+00:00"))
    t1 = datetime.fromisoformat(last["timestamp"].replace("Z", "+00:00"))
    days_elapsed = max((t1 - t0).total_seconds() / 86400, 1)

    znn_delta = first["znn_balance"] - last["znn_balance"]
    qsr_delta = first["qsr_balance"] - last["qsr_balance"]

    return {
        "znn_per_month": (znn_delta / days_elapsed) * 30,
        "qsr_per_month": (qsr_delta / days_elapsed) * 30,
        "data_points": len(rows),
    }


def estimate_runway(
    znn_balance: float,
    qsr_balance: float,
    znn_per_month: float,
    qsr_per_month: float,
) -> float:
    """Estimate treasury runway in months.

    Uses the more constraining of ZNN or QSR burn rate.
    Returns months of runway, or float('inf') if no outflow detected.
    """
    runways = []
    if znn_per_month > 0:
        runways.append(znn_balance / znn_per_month)
    if qsr_per_month > 0:
        runways.append(qsr_balance / qsr_per_month)

    if not runways:
        return float("inf")

    return min(runways)


def persist_snapshot(
    znn_balance: float,
    qsr_balance: float,
    runway_months: float,
    active_proposals: int = 0,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist a treasury snapshot to the database.

    Returns the row ID of the inserted snapshot.
    """
    funding = calculate_funding_rate(db_path=db_path)
    return persist_metric(
        db_path=db_path,
        table="treasury_snapshots",
        data={
            "znn_balance": znn_balance,
            "qsr_balance": qsr_balance,
            "znn_funded_30d": funding["znn_per_month"],
            "qsr_funded_30d": funding["qsr_per_month"],
            "runway_months": runway_months if runway_months != float("inf") else -1,
            "active_proposals": active_proposals,
        },
    )


def _build_treasury_finding(
    balance: dict,
    funding: dict,
    runway: float,
    active_proposals: int,
    proposals: list | None,
) -> str:
    """Build actionable treasury finding answering WHAT / SO WHAT / NOW WHAT."""
    znn = balance["znn_balance"]
    qsr = balance["qsr_balance"]
    znn_rate = funding.get("znn_per_month", 0)
    qsr_rate = funding.get("qsr_per_month", 0)

    # WHAT
    what_parts = [f"AZ treasury holds {znn:,.0f} ZNN and {qsr:,.0f} QSR."]
    if znn_rate > 0 or qsr_rate > 0:
        what_parts.append(f"Funding rate: {znn_rate:,.0f} ZNN/month and {qsr_rate:,.0f} QSR/month.")
    if runway != float("inf") and runway > 0:
        what_parts.append(f"Estimated runway: {runway:.1f} months.")
    else:
        what_parts.append("No measurable outflow — runway is indefinite.")
    what_parts.append(f"{active_proposals} active proposals.")

    what = " ".join(what_parts)

    # SO WHAT — risk assessment
    so_what_parts = []

    if runway != float("inf") and runway < 6:
        so_what_parts.append(
            f"CRITICAL: Treasury runway is only {runway:.1f} months. "
            f"At current funding rate, the treasury will be depleted "
            f"within 6 months. Development funding will halt."
        )
    elif runway != float("inf") and runway < 12:
        so_what_parts.append(
            f"Treasury runway is {runway:.1f} months — under 1 year. "
            f"Funding rate may need adjustment to sustain long-term "
            f"development."
        )
    elif runway != float("inf"):
        so_what_parts.append(
            f"Treasury runway is {runway:.1f} months — healthy. "
            f"Sufficient to fund development at current pace."
        )

    # Check for overdue proposals
    overdue = []
    if proposals:
        for p in proposals:
            status = p.get("status", 0)
            if status in (0, 1):  # submitted or voting
                # Check if proposal is old (created > 60 days ago)
                created = p.get("creationTimestamp", 0)
                if created > 0:
                    import time

                    age_days = (time.time() - created) / 86400
                    if age_days > 60:
                        name = p.get("name", p.get("id", "unknown"))
                        overdue.append({"name": name, "age_days": int(age_days)})

    if overdue:
        so_what_parts.append(
            f"{len(overdue)} proposal(s) have been pending for >60 days "
            f"without resolution. Stale proposals tie up community "
            f"attention and may indicate governance bottlenecks."
        )

    if active_proposals > 20:
        so_what_parts.append(
            f"{active_proposals} active proposals — high volume may "
            f"dilute Pillar voting attention and slow decision-making."
        )

    so_what = (
        " ".join(so_what_parts)
        if so_what_parts
        else ("Treasury health is within normal parameters.")
    )

    # NOW WHAT
    now_what_parts = []

    if runway != float("inf") and runway < 6:
        now_what_parts.append(
            "Action: URGENT — propose funding rate reduction or "
            "investigate treasury replenishment mechanisms. Alert "
            "community governance channels."
        )
    elif runway != float("inf") and runway < 12:
        now_what_parts.append(
            "Action: monitor funding rate closely. Consider proposing "
            "funding efficiency improvements at next governance cycle."
        )

    if overdue:
        names = ", ".join(o["name"] for o in overdue[:3])
        more = f" (+{len(overdue) - 3} more)" if len(overdue) > 3 else ""
        now_what_parts.append(
            f"Action: flag overdue proposals for community review: {names}{more}."
        )

    if not now_what_parts:
        now_what_parts.append(
            "Action: no immediate action needed. Continue monitoring "
            "treasury health at regular intervals."
        )

    now_what = " ".join(now_what_parts)

    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"


def run_treasury_check(*, db_path: str = DEFAULT_DB) -> dict:
    """Run a full treasury check with actionable findings.

    Every finding answers WHAT / SO WHAT / NOW WHAT.
    Returns dict with balance, funding_rate, runway_months, snapshot_id.
    """
    from core.persist_to_db import persist_finding

    balance = fetch_treasury_balance()
    if balance is None:
        persist_finding(
            db_path=db_path,
            domain="governance",
            engine="treasury_monitor",
            evidence_type="treasury_error",
            finding=(
                "WHAT: Failed to fetch AZ treasury balance from Zenon RPC. "
                "SO WHAT: Cannot assess treasury health, runway, or funding "
                "sustainability. Governance decisions lack financial context. "
                "NOW WHAT: Check ZENON_PUBLIC_RPC or ZENON_NODE_RPC "
                "connectivity. Retry in next cycle."
            ),
            confidence=0.5,
            source_repo="zenon_rpc",
        )
        return {
            "success": False,
            "error": "Failed to fetch treasury balance from API.",
        }

    funding = calculate_funding_rate(db_path=db_path)
    runway = estimate_runway(
        balance["znn_balance"],
        balance["qsr_balance"],
        funding["znn_per_month"],
        funding["qsr_per_month"],
    )

    # Count active proposals and check for overdue ones
    proposals = fetch_recent_proposals()
    active = 0
    if proposals:
        active = sum(
            1
            for p in proposals
            if p.get("status", 0) in (0, 1)  # submitted or voting
        )

    snapshot_id = persist_snapshot(
        balance["znn_balance"],
        balance["qsr_balance"],
        runway,
        active,
        db_path=db_path,
    )

    # Build and persist actionable finding
    finding_text = _build_treasury_finding(
        balance,
        funding,
        runway,
        active,
        proposals,
    )
    persist_finding(
        db_path=db_path,
        domain="governance",
        engine="treasury_monitor",
        evidence_type="treasury_analysis",
        finding=finding_text,
        confidence=0.85,
        raw_data={
            "znn_balance": balance["znn_balance"],
            "qsr_balance": balance["qsr_balance"],
            "znn_per_month": funding["znn_per_month"],
            "qsr_per_month": funding["qsr_per_month"],
            "runway_months": runway if runway != float("inf") else -1,
            "active_proposals": active,
        },
        source_repo="zenonhub_api",
    )

    return {
        "success": True,
        "znn_balance": balance["znn_balance"],
        "qsr_balance": balance["qsr_balance"],
        "znn_per_month": funding["znn_per_month"],
        "qsr_per_month": funding["qsr_per_month"],
        "runway_months": runway,
        "active_proposals": active,
        "snapshot_id": snapshot_id,
        "finding": finding_text,
    }


def get_treasury_history(
    *,
    db_path: str = DEFAULT_DB,
    limit: int = 30,
) -> list[dict]:
    """Get recent treasury snapshots for trend analysis."""
    return query_table(
        db_path=db_path,
        table="treasury_snapshots",
        order_by="timestamp DESC",
        limit=limit,
    )
