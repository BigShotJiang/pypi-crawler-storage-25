# SPDX-License-Identifier: MIT
"""
PillarAccountability -- Score pillars on governance participation and contribution.

For: delegators choosing pillars.

Queries voting history, proposal sponsorship, and communication presence
to produce a composite accountability score per pillar. Helps delegators
make informed delegation decisions based on pillar governance engagement.
No LLM calls.
"""

import logging
import sqlite3
from pathlib import Path

from core.persistence import connect
from core.zenon_data import get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Score component weights (total = 100)
VOTING_PARTICIPATION_WEIGHT = 40  # How often they vote
PROPOSAL_SPONSORSHIP_WEIGHT = 20  # Do they create proposals
UPTIME_WEIGHT = 25  # Do they produce momentums
REWARD_SHARING_WEIGHT = 15  # Do they share rewards fairly


def _int(value, default: int = 0) -> int:
    """Coerce a value to int, returning ``default`` on failure."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _float(value, default: float = 0.0) -> float:
    """Coerce a value to float, returning ``default`` on failure."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def fetch_all_pillars() -> list[dict]:
    """Return all pillars with accountability-relevant fields.

    Returns an empty list when the node is unreachable.
    """
    rpc = get_zenon_data()
    raw = rpc.get_all_pillars(page=0, count=500)
    return [
        {
            "name": p.get("name", "unknown"),
            "owner_address": p.get("ownerAddress", ""),
            "weight": _float(p.get("weight", p.get("delegatedWeight", 0))),
            "produced_momentums": _int(p.get("producedMomentums", 0)),
            "expected_momentums": _int(p.get("expectedMomentums", 0)),
            "give_momentum_reward_pct": _int(p.get("giveMomentumRewardPercentage", 0)),
            "give_delegate_reward_pct": _int(p.get("giveDelegateRewardPercentage", 0)),
        }
        for p in raw
    ]


def fetch_proposals() -> list[dict]:
    """Return all Accelerator-Z projects as simplified dicts.

    Returns an empty list when the node is unreachable.
    """
    rpc = get_zenon_data()
    raw = rpc.get_all_projects(page=0, count=200)
    return [
        {
            "id": p.get("id", ""),
            "owner": p.get("owner") or p.get("ownerAddress", ""),
            "name": p.get("name", ""),
            "status": p.get("status", ""),
            "votes_yes": _int(p.get("votesYes", p.get("yesVotes", 0))),
            "votes_no": _int(p.get("votesNo", p.get("noVotes", 0))),
            "votes_abstain": _int(p.get("votesAbstain", p.get("abstainVotes", 0))),
        }
        for p in raw
    ]


def fetch_pillar_votes_from_db(*, db_path: str = DEFAULT_DB) -> dict:
    """Read pillar voting data from the local DB (populated by voting_patterns engine).

    Returns dict of pillar_name -> {votes_cast, total_proposals}.
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT pillar_name, COUNT(*) as votes_cast
               FROM pillar_votes
               GROUP BY pillar_name"""
        ).fetchall()
        total_proposals = conn.execute(
            "SELECT COUNT(DISTINCT proposal_id) FROM pillar_votes"
        ).fetchone()
        total = total_proposals[0] if total_proposals else 0

        return {
            row["pillar_name"]: {
                "votes_cast": row["votes_cast"],
                "total_proposals": total,
            }
            for row in rows
        }
    except sqlite3.OperationalError:
        return {}
    finally:
        conn.close()


# -- Scoring --


def _score_voting_participation(
    pillar_name: str,
    voting_data: dict,
    proposals: list[dict],
) -> float:
    """Score voting participation (0 to VOTING_PARTICIPATION_WEIGHT).

    Based on: how many proposals did this pillar vote on out of total.
    """
    pillar_votes = voting_data.get(pillar_name, {})
    votes_cast = pillar_votes.get("votes_cast", 0)
    total_proposals = pillar_votes.get("total_proposals", 0)

    # If no DB voting data, estimate from proposals
    if total_proposals == 0 and proposals:
        total_proposals = len(proposals)
        # Count proposals where this pillar's votes are included
        # (limited by API data availability)
        votes_cast = 0  # cannot determine without per-pillar vote data

    if total_proposals == 0:
        return 0.0

    participation_rate = votes_cast / total_proposals
    return round(participation_rate * VOTING_PARTICIPATION_WEIGHT, 1)


def _score_proposal_sponsorship(
    pillar_owner: str,
    proposals: list[dict],
) -> float:
    """Score proposal sponsorship (0 to PROPOSAL_SPONSORSHIP_WEIGHT).

    Pillars that create proposals show active governance engagement.
    """
    if not proposals or not pillar_owner:
        return 0.0

    sponsored = sum(1 for p in proposals if p.get("owner", "") == pillar_owner)

    if sponsored >= 3:
        return float(PROPOSAL_SPONSORSHIP_WEIGHT)
    elif sponsored >= 1:
        return round(sponsored / 3 * PROPOSAL_SPONSORSHIP_WEIGHT, 1)
    return 0.0


def _score_uptime(pillar: dict) -> float:
    """Score uptime (0 to UPTIME_WEIGHT).

    Based on produced/expected momentum ratio.
    """
    expected = pillar.get("expected_momentums", 0)
    produced = pillar.get("produced_momentums", 0)

    if expected <= 0:
        return 0.0

    uptime_ratio = min(1.0, produced / expected)
    return round(uptime_ratio * UPTIME_WEIGHT, 1)


def _score_reward_sharing(pillar: dict) -> float:
    """Score reward sharing (0 to REWARD_SHARING_WEIGHT).

    Pillars that share more rewards with delegators score higher.
    Fair = high delegate reward %; selfish = 0%.
    """
    delegate_pct = pillar.get("give_delegate_reward_pct", 0)

    # 100% = full score, 0% = zero score, linear
    return round((delegate_pct / 100.0) * REWARD_SHARING_WEIGHT, 1)


def calculate_accountability_scores(
    pillars: list[dict],
    proposals: list[dict],
    voting_data: dict,
) -> list[dict]:
    """Calculate composite accountability score for each pillar.

    Returns sorted list of pillars with scores and breakdowns.
    """
    scored = []
    for p in pillars:
        voting_score = _score_voting_participation(
            p["name"],
            voting_data,
            proposals,
        )
        sponsorship_score = _score_proposal_sponsorship(
            p.get("owner_address", ""),
            proposals,
        )
        uptime_score = _score_uptime(p)
        reward_score = _score_reward_sharing(p)

        total = voting_score + sponsorship_score + uptime_score + reward_score

        scored.append(
            {
                "name": p["name"],
                "total_score": round(total, 1),
                "breakdown": {
                    "voting_participation": voting_score,
                    "proposal_sponsorship": sponsorship_score,
                    "uptime": uptime_score,
                    "reward_sharing": reward_score,
                },
                "weight": p["weight"],
                "give_delegate_reward_pct": p.get("give_delegate_reward_pct", 0),
            }
        )

    return sorted(scored, key=lambda s: s["total_score"], reverse=True)


def classify_pillars(scored_pillars: list[dict]) -> dict:
    """Classify pillars into tiers based on accountability score.

    Returns dict with tier lists and summary stats.
    """
    if not scored_pillars:
        return {"exemplary": [], "good": [], "average": [], "poor": []}

    exemplary = [p for p in scored_pillars if p["total_score"] >= 75]
    good = [p for p in scored_pillars if 50 <= p["total_score"] < 75]
    average = [p for p in scored_pillars if 25 <= p["total_score"] < 50]
    poor = [p for p in scored_pillars if p["total_score"] < 25]

    scores = [p["total_score"] for p in scored_pillars]

    return {
        "exemplary": [p["name"] for p in exemplary],
        "good": [p["name"] for p in good],
        "average": [p["name"] for p in average],
        "poor": [p["name"] for p in poor],
        "mean_score": round(sum(scores) / len(scores), 1),
        "median_score": sorted(scores)[len(scores) // 2],
        "exemplary_count": len(exemplary),
        "poor_count": len(poor),
    }


# -- Persistence --


def persist_accountability_snapshot(
    scored_pillars: list[dict],
    classification: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist accountability scores to the database."""
    conn = connect(db_path)
    try:
        # Get next batch ID
        row = conn.execute(
            "SELECT COALESCE(MAX(batch_id), 0) + 1 FROM pillar_accountability_scores"
        ).fetchone()
        batch_id = row[0] if row else 1

        for p in scored_pillars:
            breakdown = p.get("breakdown", {})
            conn.execute(
                """INSERT INTO pillar_accountability_scores
                   (batch_id, pillar_name, total_score,
                    voting_score, sponsorship_score, uptime_score,
                    reward_score)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    batch_id,
                    p["name"],
                    p["total_score"],
                    breakdown.get("voting_participation", 0),
                    breakdown.get("proposal_sponsorship", 0),
                    breakdown.get("uptime", 0),
                    breakdown.get("reward_sharing", 0),
                ),
            )
        conn.commit()
        return batch_id
    finally:
        conn.close()


# -- Finding Builder --


def _build_accountability_finding(
    scored_pillars: list[dict],
    classification: dict,
) -> str:
    """Build actionable finding for pillar accountability.

    Answers WHAT / SO WHAT / NOW WHAT.
    """
    total = len(scored_pillars)
    mean_score = classification.get("mean_score", 0)
    exemplary_count = classification.get("exemplary_count", 0)
    poor_count = classification.get("poor_count", 0)

    top_3 = scored_pillars[:3]
    bottom_3 = scored_pillars[-3:] if len(scored_pillars) >= 3 else scored_pillars

    top_names = ", ".join(f"{p['name']} ({p['total_score']:.0f}/100)" for p in top_3)
    bottom_names = ", ".join(f"{p['name']} ({p['total_score']:.0f}/100)" for p in bottom_3)

    # WHAT
    what = (
        f"{total} pillars scored. Mean accountability: {mean_score:.0f}/100. "
        f"{exemplary_count} exemplary (75+), {poor_count} poor (<25). "
        f"Top: {top_names}. Bottom: {bottom_names}."
    )

    # SO WHAT
    so_what_parts = []

    if poor_count > total * 0.3:
        so_what_parts.append(
            f"{poor_count} pillars ({poor_count * 100 // total}%) score poorly — "
            f"governance participation is weak across a significant portion "
            f"of the pillar set."
        )

    if mean_score < 40:
        so_what_parts.append(
            f"Mean score {mean_score:.0f} is low — most pillars are not "
            f"actively participating in governance, reducing decision quality."
        )
    elif mean_score > 60:
        so_what_parts.append(
            f"Mean score {mean_score:.0f} is healthy — the pillar set "
            f"is generally engaged in governance."
        )

    score_spread = (
        scored_pillars[0]["total_score"] - scored_pillars[-1]["total_score"]
        if scored_pillars
        else 0
    )
    if score_spread > 60:
        so_what_parts.append("Wide score spread indicates very uneven governance engagement.")

    so_what = (
        " ".join(so_what_parts)
        if so_what_parts
        else ("Pillar accountability metrics are within expected parameters.")
    )

    # NOW WHAT
    now_what_parts = []

    if poor_count > 0:
        poor_names = ", ".join(classification.get("poor", [])[:5])
        now_what_parts.append(
            f"Delegators should consider accountability scores when choosing "
            f"delegation targets. Low-scoring pillars: {poor_names}."
        )

    if exemplary_count > 0:
        ex_names = ", ".join(classification.get("exemplary", [])[:5])
        now_what_parts.append(f"Exemplary pillars deserve recognition: {ex_names}.")

    now_what_parts.append(
        "Share accountability rankings in community channels to "
        "incentivize better governance participation."
    )

    now_what = " ".join(now_what_parts)

    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"


# -- Main Entry Point --


def run_pillar_accountability(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full pillar accountability analysis.

    Returns comprehensive accountability scoring dict.
    """
    from core.persist_to_db import persist_finding

    pillars = fetch_all_pillars()
    proposals = fetch_proposals()
    voting_data = fetch_pillar_votes_from_db(db_path=db_path)

    if not pillars:
        persist_finding(
            db_path=db_path,
            domain="governance",
            engine="pillar_accountability",
            evidence_type="accountability_error",
            finding=(
                "WHAT: Failed to fetch pillar data. "
                "SO WHAT: Cannot score pillar accountability — delegators "
                "lack governance engagement data. "
                "NOW WHAT: Check ZENON_PUBLIC_RPC connectivity. Retry next cycle."
            ),
            confidence=0.5,
            source_repo="zenon_rpc",
        )
        return {
            "success": False,
            "error": "Failed to fetch pillar data.",
        }

    scored_pillars = calculate_accountability_scores(
        pillars,
        proposals,
        voting_data,
    )
    classification = classify_pillars(scored_pillars)

    batch_id = persist_accountability_snapshot(
        scored_pillars,
        classification,
        db_path=db_path,
    )

    finding_text = _build_accountability_finding(scored_pillars, classification)

    persist_finding(
        db_path=db_path,
        domain="governance",
        engine="pillar_accountability",
        evidence_type="pillar_accountability",
        finding=finding_text,
        confidence=0.80,
        raw_data={
            "classification": classification,
            "top_5": [{"name": p["name"], "score": p["total_score"]} for p in scored_pillars[:5]],
            "bottom_5": [
                {"name": p["name"], "score": p["total_score"]} for p in scored_pillars[-5:]
            ],
        },
        source_repo="zenonhub_api",
    )

    return {
        "success": True,
        "scored_pillars_count": len(scored_pillars),
        "classification": classification,
        "top_5": scored_pillars[:5],
        "bottom_5": scored_pillars[-5:],
        "batch_id": batch_id,
        "finding": finding_text,
    }
