# SPDX-License-Identifier: MIT
"""
VotingPatterns -- Analyze pillar voting behavior, participation, and concentration.

Fetches voting data per proposal, builds per-pillar voting profiles,
calculates participation rates, and detects concentration risk.
"""

import logging
import sqlite3
from pathlib import Path

from core.config import get_config
from core.persist_to_db import query_table
from core.persistence import connect
from core.zenon_data import get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Expected total pillars (for participation rate calculations).
# Sourced from config/engine_defaults.json with a safe fallback.
EXPECTED_PILLARS = get_config().engine("voting_patterns").get("expected_pillars", 90)


def fetch_pillar_list() -> list[dict]:
    """Return the list of registered pillars, or ``[]`` when unreachable."""
    return get_zenon_data().get_all_pillars(page=0, count=500)


def fetch_proposal_votes(proposal_id: str) -> list[dict]:
    """Return the vote breakdown for a specific Accelerator-Z project.

    Uses ``embedded.accelerator.getVoteBreakdown``. Returns an empty list
    when the RPC call fails or the project has no votes.

    Args:
        proposal_id: Hash / ID of the project whose votes we want.
    """
    rpc = get_zenon_data()
    result = rpc.call("embedded.accelerator.getVoteBreakdown", [proposal_id])
    if not isinstance(result, dict):
        return []
    votes_list = result.get("votes") or result.get("list") or []
    if not isinstance(votes_list, list):
        return []
    parsed: list[dict] = []
    for entry in votes_list:
        if not isinstance(entry, dict):
            continue
        parsed.append(
            {
                "pillar_name": entry.get("name") or entry.get("pillarName") or "unknown",
                "vote": _normalize_vote(entry.get("vote", 0)),
            }
        )
    return parsed


def _normalize_vote(vote_val) -> str:
    """Normalize vote value to yes/no/abstain."""
    if isinstance(vote_val, str):
        return vote_val.lower()
    vote_map = {0: "abstain", 1: "yes", 2: "no"}
    return vote_map.get(vote_val, "abstain")


def persist_votes(
    proposal_id: str,
    votes: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist votes to the pillar_votes table.

    Uses INSERT OR REPLACE to handle re-syncs.
    Returns number of votes persisted.
    """
    if not votes:
        return 0
    conn = connect(db_path)
    try:
        for v in votes:
            conn.execute(
                """INSERT OR REPLACE INTO pillar_votes
                   (proposal_id, pillar_name, vote)
                   VALUES (?, ?, ?)""",
                (proposal_id, v["pillar_name"], v["vote"]),
            )
        conn.commit()
        return len(votes)
    finally:
        conn.close()


def calculate_participation_rate(*, db_path: str = DEFAULT_DB) -> dict:
    """Calculate overall and per-proposal participation rates.

    Returns dict with overall_rate, per_proposal_avg, unique_voters.
    """
    conn = connect(db_path)
    try:
        # Count unique proposals and voters
        stats = conn.execute(
            """SELECT
                 COUNT(DISTINCT proposal_id) as proposals,
                 COUNT(DISTINCT pillar_name) as unique_voters,
                 COUNT(*) as total_votes
               FROM pillar_votes"""
        ).fetchone()

        proposals = stats[0] or 1
        unique_voters = stats[1] or 0
        total_votes = stats[2] or 0

        # Per-proposal average voters
        avg_voters_per_proposal = total_votes / proposals

        return {
            "total_proposals_with_votes": proposals,
            "unique_voters": unique_voters,
            "total_votes_cast": total_votes,
            "avg_voters_per_proposal": round(avg_voters_per_proposal, 1),
            "overall_participation_rate": round(
                avg_voters_per_proposal / EXPECTED_PILLARS * 100, 1
            ),
        }
    finally:
        conn.close()


def calculate_voting_concentration(*, db_path: str = DEFAULT_DB) -> dict:
    """Analyze voting power concentration using Herfindahl index.

    Returns concentration metrics and top voters.
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        # Get vote counts per pillar
        rows = conn.execute(
            """SELECT pillar_name, COUNT(*) as vote_count
               FROM pillar_votes
               GROUP BY pillar_name
               ORDER BY vote_count DESC"""
        ).fetchall()

        if not rows:
            return {
                "hhi": 0.0,
                "top_5_share": 0.0,
                "gini_coefficient": 0.0,
                "top_voters": [],
            }

        total_votes = sum(r["vote_count"] for r in rows)
        shares = [r["vote_count"] / total_votes for r in rows]

        # Herfindahl-Hirschman Index (0 = perfect competition, 1 = monopoly)
        hhi = sum(s**2 for s in shares)

        # Top-5 share
        top_5_share = sum(shares[:5]) if len(shares) >= 5 else sum(shares)

        # Gini coefficient
        n = len(shares)
        if n > 1:
            sorted_shares = sorted(shares)
            cumulative = 0.0
            gini_sum = 0.0
            for i, s in enumerate(sorted_shares, 1):
                cumulative += s
                gini_sum += (2 * i - n - 1) * s
            gini = gini_sum / (n * sum(sorted_shares))
        else:
            gini = 0.0

        top_voters = [{"pillar": r["pillar_name"], "votes": r["vote_count"]} for r in rows[:10]]

        return {
            "hhi": round(hhi, 4),
            "top_5_share": round(top_5_share, 4),
            "gini_coefficient": round(abs(gini), 4),
            "total_voters": n,
            "top_voters": top_voters,
        }
    finally:
        conn.close()


def get_pillar_voting_profile(
    pillar_name: str,
    *,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Get voting profile for a specific pillar.

    Returns yes/no/abstain counts and participation rate.
    """
    conn = connect(db_path)
    try:
        rows = conn.execute(
            """SELECT vote, COUNT(*) as cnt
               FROM pillar_votes
               WHERE pillar_name = ?
               GROUP BY vote""",
            (pillar_name,),
        ).fetchall()

        total_proposals = (
            conn.execute("SELECT COUNT(DISTINCT proposal_id) FROM pillar_votes").fetchone()[0] or 1
        )

        profile = {"yes": 0, "no": 0, "abstain": 0}
        for vote, cnt in rows:
            if vote in profile:
                profile[vote] = cnt

        total = sum(profile.values())
        return {
            "pillar_name": pillar_name,
            "votes_cast": total,
            "yes": profile["yes"],
            "no": profile["no"],
            "abstain": profile["abstain"],
            "participation_rate": round(total / total_proposals * 100, 1),
            "yes_rate": round(profile["yes"] / max(total, 1) * 100, 1),
        }
    finally:
        conn.close()


def run_voting_analysis(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full voting pattern analysis.

    Syncs votes for all known proposals, then calculates metrics.
    """
    proposals = query_table(
        db_path=db_path,
        table="az_proposals",
        limit=0,
    )

    synced = 0
    for row in proposals:
        pid = row["proposal_id"]
        votes = fetch_proposal_votes(pid)
        if votes:
            persist_votes(pid, votes, db_path=db_path)
            synced += 1

    participation = calculate_participation_rate(db_path=db_path)
    concentration = calculate_voting_concentration(db_path=db_path)

    # Persist actionable finding
    try:
        from core.persist_to_db import ensure_schema, persist_finding

        ensure_schema(db_path)

        part_rate = participation.get("overall_participation_rate", 0)
        hhi = concentration.get("hhi", 0)
        top5 = concentration.get("top_5_share", 0)
        unique_voters = participation.get("unique_voters", 0)

        if part_rate < 30:
            part_impact = f"Only {part_rate:.0f}% participation -- most pillars are not voting, weakening governance legitimacy."
            part_action = "Engage inactive pillars; consider governance notifications or participation incentives."
        elif part_rate < 60:
            part_impact = f"Moderate {part_rate:.0f}% participation -- governance functions but lacks broad consensus."
            part_action = "Encourage wider pillar engagement; publish voting summaries to increase transparency."
        else:
            part_impact = f"Strong {part_rate:.0f}% participation -- governance decisions carry broad mandate."
            part_action = "Maintain current engagement levels; monitor for decline."

        if hhi > 0.15:
            conc_warning = (
                f" CONCENTRATION RISK: HHI={hhi:.3f}, top-5 pillars control {top5:.0%} of votes."
            )
            conc_action = " Address concentration by encouraging diverse pillar voting."
        else:
            conc_warning = f" Voting power well-distributed (HHI={hhi:.3f})."
            conc_action = ""

        persist_finding(
            db_path=db_path,
            domain="governance",
            engine="voting_patterns",
            evidence_type="voting_analysis",
            finding=(
                f"WHAT: {unique_voters} unique pillar voters, {part_rate:.0f}% avg participation rate. "
                f"{conc_warning} "
                f"SO WHAT: {part_impact} "
                f"NOW WHAT: {part_action}{conc_action}"
            ),
            confidence=0.80,
            raw_data={"participation": participation, "concentration": concentration},
            source_repo="zenon_rpc",
        )
    except Exception as exc:
        logger.debug("Voting pattern finding persistence failed: %s", exc)

    return {
        "success": True,
        "proposals_synced": synced,
        "participation": participation,
        "concentration": concentration,
    }
