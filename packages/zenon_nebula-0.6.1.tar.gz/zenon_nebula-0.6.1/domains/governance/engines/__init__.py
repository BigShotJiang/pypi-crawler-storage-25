# SPDX-License-Identifier: MIT
"""Governance domain engines -- proposal analyzer, treasury monitor, and voting patterns."""
