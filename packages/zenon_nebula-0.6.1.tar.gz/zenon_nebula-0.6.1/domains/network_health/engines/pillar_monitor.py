# SPDX-License-Identifier: MIT
"""
PillarMonitor -- Real-time pillar health monitoring for pillar operators.

For: pillar operators.

Tracks pillar uptime (producing momentums vs missing), delegation changes
per pillar, alerts on weight drops, missed momentums, and approaching
depillarize thresholds. Compares pillar performance quartiles.
"""

import logging
import sqlite3
from pathlib import Path

from core.config import get_config
from core.persistence import connect
from core.zenon_data import get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZNN_DECIMALS = 8

# Thresholds — sourced from config/engine_defaults.json with safe fallbacks.
_pm_cfg = get_config().engine("pillar_monitor")
WEIGHT_DROP_ALERT_PCT = _pm_cfg.get(
    "weight_drop_alert_pct", 5.0
)  # alert if delegation drops >this% between snapshots
MIN_PILLAR_WEIGHT = _pm_cfg.get(
    "min_pillar_weight", 0
)  # pillars with 0 weight are at depillarize risk
MISSED_MOMENTUM_ALERT = _pm_cfg.get(
    "missed_momentum_alert", 10
)  # alert if expected - produced > threshold


def _int(value, default: int = 0) -> int:
    """Coerce a value to int, returning ``default`` on failure."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _float(value, default: float = 0.0) -> float:
    """Coerce a value to float, returning ``default`` on failure."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def fetch_all_pillars() -> list[dict]:
    """Return all pillars with stats as a list of normalized dicts.

    Returns an empty list when the node is unreachable.
    """
    rpc = get_zenon_data()
    raw_pillars = rpc.get_all_pillars(page=0, count=500)
    return [
        {
            "name": p.get("name", "unknown"),
            "owner_address": p.get("ownerAddress", ""),
            "weight": _float(p.get("weight", p.get("delegatedWeight", 0))),
            "produced_momentums": _int(p.get("producedMomentums", 0)),
            "expected_momentums": _int(p.get("expectedMomentums", 0)),
            "rank": _int(p.get("rank", 0)),
            "give_momentum_reward_pct": _int(p.get("giveMomentumRewardPercentage", 0)),
            "give_delegate_reward_pct": _int(p.get("giveDelegateRewardPercentage", 0)),
        }
        for p in raw_pillars
    ]


# -- Analysis --


def calculate_uptime(pillars: list[dict]) -> list[dict]:
    """Calculate uptime percentage for each pillar.

    Returns pillars enriched with uptime_pct and missed_momentums.
    """
    enriched = []
    for p in pillars:
        expected = p.get("expected_momentums", 0)
        produced = p.get("produced_momentums", 0)

        if expected > 0:
            uptime_pct = round((produced / expected) * 100, 2)
            missed = expected - produced
        else:
            uptime_pct = 0.0
            missed = 0

        enriched.append(
            {
                **p,
                "uptime_pct": uptime_pct,
                "missed_momentums": max(0, missed),
            }
        )

    return sorted(enriched, key=lambda x: x["uptime_pct"], reverse=True)


def calculate_quartiles(pillars: list[dict]) -> dict:
    """Split pillars into performance quartiles by uptime.

    Returns dict with quartile boundaries and pillar lists.
    """
    if not pillars:
        return {"q1": [], "q2": [], "q3": [], "q4": []}

    sorted_by_uptime = sorted(
        pillars,
        key=lambda p: p.get("uptime_pct", 0),
        reverse=True,
    )
    n = len(sorted_by_uptime)
    q_size = max(1, n // 4)

    return {
        "top_quartile": [p["name"] for p in sorted_by_uptime[:q_size]],
        "bottom_quartile": [p["name"] for p in sorted_by_uptime[-q_size:]],
        "median_uptime": sorted_by_uptime[n // 2].get("uptime_pct", 0),
        "mean_uptime": round(
            sum(p.get("uptime_pct", 0) for p in sorted_by_uptime) / n,
            2,
        )
        if n
        else 0,
        "total_pillars": n,
    }


def detect_delegation_drops(
    current_pillars: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> list[dict]:
    """Detect pillars with significant delegation weight drops.

    Compares current weights against the last snapshot.
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT pillar_name, weight
               FROM pillar_monitor_snapshots
               WHERE batch_id = (
                   SELECT MAX(batch_id) FROM pillar_monitor_snapshots
               )"""
        ).fetchall()
        previous = {row["pillar_name"]: row["weight"] for row in rows}
    except sqlite3.OperationalError:
        previous = {}
    finally:
        conn.close()

    if not previous:
        return []

    drops = []
    for pillar in current_pillars:
        name = pillar["name"]
        current_w = pillar["weight"]
        prev_w = previous.get(name, 0)

        if prev_w <= 0:
            continue

        change_pct = ((current_w - prev_w) / prev_w) * 100

        if change_pct < -WEIGHT_DROP_ALERT_PCT:
            drops.append(
                {
                    "pillar_name": name,
                    "previous_weight": prev_w,
                    "current_weight": current_w,
                    "change_pct": round(change_pct, 2),
                    "rank": pillar.get("rank", 0),
                }
            )

    return sorted(drops, key=lambda d: d["change_pct"])


def find_at_risk_pillars(pillars: list[dict]) -> list[dict]:
    """Identify pillars at risk of depillarization or poor performance.

    At risk = low uptime, zero delegation, or very low weight.
    """
    at_risk = []
    if not pillars:
        return at_risk

    # Find weight threshold: bottom 10% by weight
    sorted_by_weight = sorted(pillars, key=lambda p: p["weight"])
    weight_threshold = sorted_by_weight[max(0, len(sorted_by_weight) // 10)]["weight"]

    for p in pillars:
        risks = []

        if p.get("uptime_pct", 100) < 50:
            risks.append(f"low uptime ({p['uptime_pct']:.1f}%)")
        if p.get("missed_momentums", 0) > MISSED_MOMENTUM_ALERT:
            risks.append(f"missed {p['missed_momentums']} momentums")
        if p["weight"] <= weight_threshold and p["weight"] > 0:
            risks.append("bottom 10% by delegation weight")
        if p["weight"] == 0:
            risks.append("zero delegation weight")

        if risks:
            at_risk.append(
                {
                    "pillar_name": p["name"],
                    "weight": p["weight"],
                    "uptime_pct": p.get("uptime_pct", 0),
                    "risks": risks,
                }
            )

    return at_risk


# -- Persistence --


def persist_pillar_snapshot(
    pillars: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist pillar monitoring data to the database."""
    conn = connect(db_path)
    try:
        # Get next batch ID
        row = conn.execute(
            "SELECT COALESCE(MAX(batch_id), 0) + 1 FROM pillar_monitor_snapshots"
        ).fetchone()
        batch_id = row[0] if row else 1

        for p in pillars:
            conn.execute(
                """INSERT INTO pillar_monitor_snapshots
                   (batch_id, pillar_name, weight, produced_momentums,
                    expected_momentums, uptime_pct, rank)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    batch_id,
                    p["name"],
                    p["weight"],
                    p.get("produced_momentums", 0),
                    p.get("expected_momentums", 0),
                    p.get("uptime_pct", 0),
                    p.get("rank", 0),
                ),
            )
        conn.commit()
        return batch_id
    finally:
        conn.close()


# -- Finding Builders --


def _build_pillar_health_finding(
    pillars: list[dict],
    quartiles: dict,
    drops: list[dict],
    at_risk: list[dict],
) -> str:
    """Build actionable finding for pillar health monitoring.

    Answers WHAT / SO WHAT / NOW WHAT.
    """
    total = quartiles.get("total_pillars", 0)
    median_up = quartiles.get("median_uptime", 0)
    mean_up = quartiles.get("mean_uptime", 0)

    # WHAT
    what_parts = [
        f"{total} pillars monitored. Median uptime: {median_up:.1f}%, mean: {mean_up:.1f}%.",
    ]

    if drops:
        top_drop = drops[0]
        what_parts.append(
            f"Delegation alert: '{top_drop['pillar_name']}' lost "
            f"{abs(top_drop['change_pct']):.1f}% delegation weight."
        )

    if at_risk:
        what_parts.append(f"{len(at_risk)} pillar(s) flagged at-risk.")

    what = " ".join(what_parts)

    # SO WHAT
    so_what_parts = []

    if median_up < 90:
        so_what_parts.append(
            f"Median uptime {median_up:.0f}% is below healthy threshold "
            f"(90%). Network momentum production may be degraded."
        )

    if len(drops) >= 3:
        so_what_parts.append(
            f"{len(drops)} pillars lost significant delegation — "
            f"indicates delegator reshuffling or dissatisfaction."
        )

    for risk in at_risk[:3]:
        risk_desc = ", ".join(risk["risks"])
        so_what_parts.append(f"'{risk['pillar_name']}': {risk_desc}.")

    so_what = (
        " ".join(so_what_parts)
        if so_what_parts
        else ("Pillar network operating within normal parameters.")
    )

    # NOW WHAT
    now_what_parts = []

    if drops:
        names = ", ".join(d["pillar_name"] for d in drops[:3])
        now_what_parts.append(
            f"Operators of {names}: review delegation strategy and "
            f"community engagement to retain delegators."
        )

    if at_risk:
        now_what_parts.append(
            "At-risk pillars should check node configuration and "
            "ensure they are producing momentums consistently."
        )

    bottom_q = quartiles.get("bottom_quartile", [])
    if bottom_q:
        now_what_parts.append(
            f"Bottom quartile: {', '.join(bottom_q[:5])}. "
            f"Delegators should consider performance when choosing pillars."
        )

    if not now_what_parts:
        now_what_parts.append("Continue monitoring. All pillars performing adequately.")

    now_what = " ".join(now_what_parts)

    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"


# -- Main Entry Point --


def run_pillar_monitor(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full pillar health monitoring: fetch, analyze, persist findings.

    Returns comprehensive pillar health status dict.
    """
    from core.persist_to_db import persist_finding

    raw_pillars = fetch_all_pillars()

    if not raw_pillars:
        persist_finding(
            db_path=db_path,
            domain="network_health",
            engine="pillar_monitor",
            evidence_type="pillar_error",
            finding=(
                "WHAT: Failed to fetch pillar data from API. "
                "SO WHAT: Cannot assess pillar health or delegation shifts. "
                "NOW WHAT: Check ZENON_PUBLIC_RPC or ZENON_NODE_RPC. Retry next cycle."
            ),
            confidence=0.5,
            source_repo="zenon_rpc",
        )
        return {
            "success": False,
            "error": "Failed to fetch pillar data.",
        }

    pillars = calculate_uptime(raw_pillars)
    quartiles = calculate_quartiles(pillars)
    drops = detect_delegation_drops(pillars, db_path=db_path)
    at_risk = find_at_risk_pillars(pillars)

    batch_id = persist_pillar_snapshot(pillars, db_path=db_path)

    finding_text = _build_pillar_health_finding(
        pillars,
        quartiles,
        drops,
        at_risk,
    )

    persist_finding(
        db_path=db_path,
        domain="network_health",
        engine="pillar_monitor",
        evidence_type="pillar_health",
        finding=finding_text,
        confidence=0.85,
        raw_data={
            "quartiles": quartiles,
            "delegation_drops": drops,
            "at_risk_count": len(at_risk),
            "at_risk_pillars": [r["pillar_name"] for r in at_risk],
        },
        source_repo="zenon_rpc",
    )

    return {
        "success": True,
        "total_pillars": len(pillars),
        "quartiles": quartiles,
        "delegation_drops": drops,
        "at_risk": at_risk,
        "batch_id": batch_id,
        "finding": finding_text,
    }
