# SPDX-License-Identifier: MIT
"""
NodeCensus - Count nodes, track version distribution, detect upgrade adoption.

Queries the Zenon node via :mod:`core.zenon_data` for pillar/sentinel counts
and version metadata, tracks version distribution over time, and persists
snapshots to ``node_snapshots``.
"""

import logging
from collections import Counter
from pathlib import Path

from core.persist_to_db import persist_metric, query_table
from core.zenon_data import get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")


def fetch_pillar_count() -> int:
    """Return the number of registered pillars.

    Falls back to counting the full pillar list if the node does not
    report a paginated ``count`` field. Returns 0 when the node is
    unreachable so downstream logic can keep running.
    """
    rpc = get_zenon_data()
    count = rpc.get_pillar_count()
    if count is not None:
        return int(count)
    pillars = rpc.get_all_pillars(page=0, count=500)
    return len(pillars)


def fetch_sentinel_count() -> int:
    """Return the number of active sentinels.

    Returns 0 when the node is unreachable.
    """
    rpc = get_zenon_data()
    count = rpc.get_sentinel_count()
    if count is not None:
        return int(count)
    sentinels = rpc.get_all_sentinels(page=0, count=500)
    return len(sentinels)


def fetch_node_versions() -> list[str]:
    """Return node version strings from pillar metadata.

    The node RPC does not expose a version endpoint, but pillar registration
    data often contains operator-reported versions. Missing data is returned
    as an empty list (no fabrication).
    """
    rpc = get_zenon_data()
    pillars = rpc.get_all_pillars(page=0, count=500)
    versions: list[str] = []
    for pillar in pillars:
        version = pillar.get("version") or pillar.get("currentVersion") or ""
        if version:
            versions.append(str(version))
    return versions


def compute_version_distribution(versions: list[str]) -> dict:
    """Compute version distribution from a list of version strings.

    Returns dict with version -> count, plus latest_version and latest_pct.
    """
    if not versions:
        return {
            "distribution": {},
            "latest_version": "unknown",
            "latest_version_pct": 0.0,
            "total": 0,
        }

    counter = Counter(versions)
    # Assume the most common version is "latest" (heuristic)
    most_common = counter.most_common(1)[0]
    total = len(versions)

    return {
        "distribution": dict(counter),
        "latest_version": most_common[0],
        "latest_version_pct": round(most_common[1] / total * 100, 1),
        "total": total,
    }


def estimate_total_nodes(
    pillar_count: int,
    sentinel_count: int,
) -> int:
    """Estimate total network nodes.

    Includes pillars, sentinels, and estimated full nodes.
    Full node estimate is a rough heuristic: pillars + sentinels + ~20% overhead.
    """
    known = pillar_count + sentinel_count
    # Conservative estimate: at least 20% more nodes than pillars+sentinels
    estimated_full_nodes = max(int(known * 0.2), 10)
    return known + estimated_full_nodes


def persist_snapshot(
    total_nodes: int,
    pillar_count: int,
    sentinel_count: int,
    version_info: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist a node census snapshot to the database.

    Returns the row ID of the inserted snapshot.
    """
    return persist_metric(
        db_path=db_path,
        table="node_snapshots",
        data={
            "total_nodes": total_nodes,
            "pillar_count": pillar_count,
            "sentinel_count": sentinel_count,
            "version_distribution": version_info.get("distribution", {}),
            "latest_version": version_info.get("latest_version", "unknown"),
            "latest_version_pct": version_info.get("latest_version_pct", 0.0),
        },
    )


def get_census_history(
    *,
    db_path: str = DEFAULT_DB,
    limit: int = 30,
) -> list[dict]:
    """Get recent node census snapshots for trend analysis."""
    return query_table(
        db_path=db_path,
        table="node_snapshots",
        order_by="timestamp DESC",
        limit=limit,
    )


def detect_version_upgrade_trend(
    *,
    db_path: str = DEFAULT_DB,
    window: int = 10,
) -> dict:
    """Detect whether nodes are upgrading to the latest version.

    Compares latest_version_pct across recent snapshots.
    """
    history = get_census_history(db_path=db_path, limit=window)
    if len(history) < 2:
        return {"trend": "insufficient_data", "data_points": len(history)}

    pcts = [h["latest_version_pct"] or 0.0 for h in reversed(history)]
    # Simple linear trend
    n = len(pcts)
    x_mean = (n - 1) / 2
    y_mean = sum(pcts) / n
    numerator = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(pcts))
    denominator = sum((i - x_mean) ** 2 for i in range(n))

    if denominator == 0:
        slope = 0.0
    else:
        slope = numerator / denominator

    if slope > 0.5:
        trend = "upgrading"
    elif slope < -0.5:
        trend = "degrading"
    else:
        trend = "stable"

    return {
        "trend": trend,
        "slope": round(slope, 3),
        "latest_pct": pcts[-1],
        "data_points": n,
    }


def run_node_census(*, db_path: str = DEFAULT_DB) -> dict:
    """Run a full node census: fetch counts, versions, persist snapshot.

    Returns dict with census results.
    """
    pillar_count = fetch_pillar_count()
    sentinel_count = fetch_sentinel_count()
    if pillar_count == 0:
        logger.info("Pillar count is 0 - node may be unreachable.")
    if sentinel_count == 0:
        logger.info("Sentinel count is 0 - node may be unreachable.")

    versions = fetch_node_versions()
    version_info = compute_version_distribution(versions)
    total_nodes = estimate_total_nodes(pillar_count, sentinel_count)

    snapshot_id = persist_snapshot(
        total_nodes,
        pillar_count,
        sentinel_count,
        version_info,
        db_path=db_path,
    )

    upgrade_trend = detect_version_upgrade_trend(db_path=db_path)

    # Persist actionable node census finding
    try:
        from core.persist_to_db import persist_finding

        latest_ver = version_info.get("latest_version", "unknown")
        latest_pct = version_info.get("latest_version_pct", 0)
        trend_dir = upgrade_trend.get("trend", "unknown")

        what = (
            f"Network has ~{total_nodes} nodes: {pillar_count} pillars, "
            f"{sentinel_count} sentinels. "
            f"Version distribution: {latest_ver} at {latest_pct:.0f}% adoption. "
            f"Upgrade trend: {trend_dir}."
        )

        if pillar_count < 30:
            so_what = (
                f"Only {pillar_count} pillars -- below healthy threshold. "
                f"Low pillar count weakens consensus security and "
                f"decentralization."
            )
            now_what = (
                "Action: investigate barriers to pillar creation. "
                "Monitor for further decline. Consider community outreach "
                "to encourage new pillar operators."
            )
        elif latest_pct < 50 and latest_ver != "unknown":
            so_what = (
                "Less than half the network runs the latest version. "
                "Fragmented versions may delay spork activation and "
                "reduce network cohesion."
            )
            now_what = (
                "Action: encourage node operators to upgrade. "
                "Track version adoption rate over coming snapshots."
            )
        else:
            so_what = (
                f"Node count and version adoption are within healthy "
                f"parameters. {pillar_count} pillars provide adequate "
                f"consensus security."
            )
            now_what = (
                "Action: no immediate action needed. Continue monitoring "
                "node count trends and version adoption."
            )

        persist_finding(
            db_path=db_path,
            domain="network_health",
            engine="node_census",
            evidence_type="node_census",
            finding=f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}",
            confidence=0.80,
            raw_data={
                "total_nodes": total_nodes,
                "pillar_count": pillar_count,
                "sentinel_count": sentinel_count,
                "version_info": version_info,
                "upgrade_trend": upgrade_trend,
            },
            source_repo="zenon_rpc",
        )
    except Exception as exc:
        logger.debug("Node census finding persistence failed: %s", exc)

    return {
        "success": True,
        "total_nodes": total_nodes,
        "pillar_count": pillar_count,
        "sentinel_count": sentinel_count,
        "version_info": version_info,
        "upgrade_trend": upgrade_trend,
        "snapshot_id": snapshot_id,
    }
