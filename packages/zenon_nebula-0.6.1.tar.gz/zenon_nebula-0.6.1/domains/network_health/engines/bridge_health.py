# SPDX-License-Identifier: MIT
"""
BridgeHealth -- Track bridge TVL, relayer count, and stuck transactions.

Monitors the Orbital bridge (and future bridges) by querying zenonhub API
for wrap/unwrap status, relayer activity, and TVL estimates.
"""

import json
import logging
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.config import get_config
from core.http import opsec_request, opsec_urlopen  # noqa: F401  OPSEC-safe HTTP wrapper
from core.persist_to_db import persist_metric, query_table
from core.zenon_data import EMBEDDED_ADDRESSES, get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Bridge contract address (embedded bridge contract on NoM).
BRIDGE_ADDRESS = EMBEDDED_ADDRESSES["bridge"]

# Thresholds for health alerts — sourced from config/engine_defaults.json
# with safe fallbacks. Names preserved for backward compatibility.
_bh_cfg = get_config().engine("bridge_health")
STUCK_TX_THRESHOLD = _bh_cfg.get("stuck_tx_threshold", 5)  # More than this = warning
MIN_RELAYERS = _bh_cfg.get("min_relayers", 3)  # Fewer than this = critical
TVL_DROP_PCT = _bh_cfg.get("tvl_drop_pct", 20.0)  # TVL drop > this% in 24h = alert


def fetch_bridge_info() -> dict | None:
    """Return bridge contract info (orchestrator, admin, guardians).

    Pulled via ``embedded.bridge.getBridgeInfo``. Returns ``None`` when the
    node is unreachable so callers can surface a clean ``no data`` state.
    """
    rpc = get_zenon_data()
    info = rpc.get_bridge_info()
    if isinstance(info, dict):
        return info
    return None


def fetch_pending_wraps() -> list[dict]:
    """Return unsigned/pending wrap requests.

    Wraps move ZNN/QSR from NoM to an EVM chain as wZNN/wQSR. The embedded
    bridge RPC exposes ``getAllUnsignedWrapTokenRequests``. Returns an
    empty list on failure.
    """
    rpc = get_zenon_data()
    result = rpc.call("embedded.bridge.getAllUnsignedWrapTokenRequests", [0, 50])
    if isinstance(result, dict) and isinstance(result.get("list"), list):
        return result["list"]
    if isinstance(result, list):
        return result
    return []


def fetch_pending_unwraps() -> list[dict]:
    """Return pending unredeemed unwrap requests.

    Unwraps move wZNN/wQSR from an EVM chain back to NoM. The embedded
    bridge RPC exposes ``getAllUnredeemedUnwrapTokenRequests``. Returns an
    empty list on failure.
    """
    rpc = get_zenon_data()
    result = rpc.call("embedded.bridge.getAllUnredeemedUnwrapTokenRequests", [0, 50])
    if isinstance(result, dict) and isinstance(result.get("list"), list):
        return result["list"]
    if isinstance(result, list):
        return result
    return []


def count_stuck_transactions(
    wraps: list[dict],
    unwraps: list[dict],
    stuck_threshold_hours: int = 6,
) -> dict:
    """Count transactions that have been pending longer than threshold.

    Returns dict with stuck_wraps, stuck_unwraps, total_stuck.
    """
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=stuck_threshold_hours)

    stuck_wraps = 0
    stuck_unwraps = 0

    for w in wraps:
        status = w.get("redeemed", w.get("status", 0))
        if status in (0, False, "pending"):
            ts = w.get("creationTimestamp", w.get("timestamp", 0))
            if isinstance(ts, (int, float)) and ts > 0:
                tx_time = datetime.fromtimestamp(ts, tz=timezone.utc)
                if tx_time < cutoff:
                    stuck_wraps += 1

    for u in unwraps:
        status = u.get("redeemed", u.get("status", 0))
        if status in (0, False, "pending"):
            ts = u.get("creationTimestamp", u.get("timestamp", 0))
            if isinstance(ts, (int, float)) and ts > 0:
                tx_time = datetime.fromtimestamp(ts, tz=timezone.utc)
                if tx_time < cutoff:
                    stuck_unwraps += 1

    return {
        "stuck_wraps": stuck_wraps,
        "stuck_unwraps": stuck_unwraps,
        "total_stuck": stuck_wraps + stuck_unwraps,
        "threshold_hours": stuck_threshold_hours,
    }


def extract_bridge_tvl(bridge_info: dict | None) -> dict:
    """Extract TVL information from bridge info response.

    Returns dict with tvl_znn, tvl_eth, estimated tvl_usd.
    """
    if not bridge_info:
        return {"tvl_znn": 0.0, "tvl_qsr": 0.0, "tvl_usd": 0.0}

    # Prefer a direct balance lookup on the bridge contract itself since
    # older ``bridgeInfo`` payloads did not carry balances.
    rpc = get_zenon_data()
    balances = rpc.get_bridge_balance()
    tvl_znn = float(balances.get("znn", 0)) / 1e8
    tvl_qsr = float(balances.get("qsr", 0)) / 1e8

    # Attempt to get price for USD estimate
    znn_price = _get_znn_price()
    tvl_usd = tvl_znn * znn_price if znn_price else 0.0

    return {
        "tvl_znn": tvl_znn,
        "tvl_qsr": tvl_qsr,
        "tvl_usd": round(tvl_usd, 2),
    }


def _get_znn_price() -> float:
    """Return the current wZNN price in USD, or 0.0 on failure.

    Uses DexScreener's Uniswap v2 wZNN/ETH pair lookup. Any network or
    parse error results in 0.0 so callers can degrade gracefully.
    """
    url = "https://api.dexscreener.com/latest/dex/tokens/0xb2e96a63479C2Edd2FD62b382c89D5CA79f572d3"
    req = urllib.request.Request(url, headers={"User-Agent": "nebula-bridge-health/1.0"})
    try:
        resp = opsec_urlopen(req, timeout=get_config().timeout("dexscreener"))
        data = json.loads(resp.read())
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        logger.debug("DexScreener price fetch failed: %s", exc)
        return 0.0
    pairs = data.get("pairs") or []
    if not pairs:
        return 0.0
    try:
        return float(pairs[0].get("priceUsd", 0))
    except (TypeError, ValueError):
        return 0.0


def count_active_relayers(bridge_info: dict | None) -> dict:
    """Count active relayers from bridge info.

    Returns dict with active, total, and health status.
    """
    if not bridge_info:
        return {
            "active_relayers": 0,
            "total_relayers": 0,
            "status": "unknown",
        }

    # Try to extract guardian/relayer info
    guardians = bridge_info.get("guardians", bridge_info.get("relayers", []))
    if isinstance(guardians, list):
        total = len(guardians)
        # Assume all listed guardians are active unless marked otherwise
        active = sum(1 for g in guardians if g.get("active", True) is not False)
    elif isinstance(guardians, int):
        total = guardians
        active = guardians
    else:
        total = 0
        active = 0

    if active >= MIN_RELAYERS:
        status = "healthy"
    elif active > 0:
        status = "degraded"
    else:
        status = "critical"

    return {
        "active_relayers": active,
        "total_relayers": total,
        "status": status,
    }


def persist_bridge_snapshot(
    tvl: dict,
    relayers: dict,
    stuck: dict,
    pending_wraps: int,
    pending_unwraps: int,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist a bridge health snapshot to the database.

    Returns the row ID of the inserted record.
    """
    return persist_metric(
        db_path=db_path,
        table="bridge_metrics",
        data={
            "tvl_znn": tvl.get("tvl_znn", 0.0),
            "tvl_usd": tvl.get("tvl_usd", 0.0),
            "active_relayers": relayers.get("active_relayers", 0),
            "total_relayers": relayers.get("total_relayers", 0),
            "stuck_transactions": stuck.get("total_stuck", 0),
            "pending_wraps": pending_wraps,
            "pending_unwraps": pending_unwraps,
        },
    )


def detect_tvl_drop(*, db_path: str = DEFAULT_DB) -> dict | None:
    """Detect significant TVL drops by comparing latest two snapshots.

    Returns alert dict if drop exceeds threshold, or None.
    """
    rows = query_table(
        db_path=db_path,
        table="bridge_metrics",
        order_by="timestamp DESC",
        limit=2,
    )

    if len(rows) < 2:
        return None

    current = rows[0]["tvl_znn"] or 0
    previous = rows[1]["tvl_znn"] or 0

    if previous == 0:
        return None

    drop_pct = ((previous - current) / previous) * 100

    if drop_pct >= TVL_DROP_PCT:
        return {
            "alert": "tvl_significant_drop",
            "drop_pct": round(drop_pct, 1),
            "current_tvl_znn": current,
            "previous_tvl_znn": previous,
        }

    return None


def run_bridge_health_check(*, db_path: str = DEFAULT_DB) -> dict:
    """Run a full bridge health check.

    Returns comprehensive bridge status dict.
    """
    bridge_info = fetch_bridge_info()
    wraps = fetch_pending_wraps()
    unwraps = fetch_pending_unwraps()

    tvl = extract_bridge_tvl(bridge_info)
    relayers = count_active_relayers(bridge_info)
    stuck = count_stuck_transactions(wraps, unwraps)

    snapshot_id = persist_bridge_snapshot(
        tvl,
        relayers,
        stuck,
        len(wraps),
        len(unwraps),
        db_path=db_path,
    )

    tvl_alert = detect_tvl_drop(db_path=db_path)

    # Determine overall health
    alerts = []
    if stuck["total_stuck"] > STUCK_TX_THRESHOLD:
        alerts.append(
            f"WHAT: {stuck['total_stuck']} bridge transactions stuck for >{stuck['threshold_hours']}h "
            f"({stuck['stuck_wraps']} wraps, {stuck['stuck_unwraps']} unwraps). "
            f"SO WHAT: Users cannot complete cross-chain transfers; funds are locked until resolved. "
            f"NOW WHAT: Check relayer liveness and orchestrator logs; restart stalled relayers; "
            f"escalate to HyperCore-Team if stuck >48h."
        )
    if relayers["status"] == "critical":
        alerts.append(
            f"WHAT: Only {relayers['active_relayers']}/{relayers['total_relayers']} bridge relayers active "
            f"(minimum required: {MIN_RELAYERS}). "
            f"SO WHAT: Bridge is non-functional or at risk of halting; wrap/unwrap requests will fail. "
            f"NOW WHAT: Check orchestrator node status; verify relayer keys and connectivity; "
            f"alert bridge operators immediately."
        )
    elif relayers["status"] == "degraded":
        alerts.append(
            f"WHAT: {relayers['active_relayers']}/{relayers['total_relayers']} bridge relayers active "
            f"(below optimal {MIN_RELAYERS}). "
            f"SO WHAT: Bridge is operational but has reduced redundancy; a single relayer failure could halt it. "
            f"NOW WHAT: Investigate offline relayers; coordinate with operators to restore full quorum."
        )
    if tvl_alert:
        alerts.append(
            f"WHAT: Bridge TVL dropped {tvl_alert['drop_pct']}% since last check "
            f"(from {tvl_alert['previous_tvl_znn']:.1f} to {tvl_alert['current_tvl_znn']:.1f} ZNN). "
            f"SO WHAT: Large TVL drops may indicate a security incident, mass exit, or bridge exploit. "
            f"NOW WHAT: Check bridge contract events for unusual unwrap activity; verify no exploit; "
            f"compare with market conditions to rule out organic withdrawals."
        )

    overall = "healthy"
    if any("Critical" in a for a in alerts):
        overall = "critical"
    elif alerts:
        overall = "degraded"

    # Persist actionable bridge health finding
    try:
        from core.persist_to_db import persist_finding

        tvl_znn = tvl.get("tvl_znn", 0)
        tvl_usd = tvl.get("tvl_usd", 0)
        active_rel = relayers.get("active_relayers", 0)
        total_rel = relayers.get("total_relayers", 0)
        total_stuck = stuck.get("total_stuck", 0)
        n_wraps = len(wraps)
        n_unwraps = len(unwraps)

        what = (
            f"Bridge health: {overall}. TVL: {tvl_znn:,.1f} ZNN "
            f"(${tvl_usd:,.0f} USD). Relayers: {active_rel}/{total_rel} active. "
            f"Pending: {n_wraps} wraps, {n_unwraps} unwraps. "
            f"Stuck (>{stuck.get('threshold_hours', 6)}h): {total_stuck}."
        )

        if overall == "critical":
            so_what = (
                "Bridge is in critical state. Users may be unable to complete "
                "cross-chain transfers. Funds could be locked until relayers "
                "are restored."
            )
            now_what = (
                "Action: URGENT -- check relayer and orchestrator status. "
                "Escalate to HyperCore-Team. Alert community channels about "
                "bridge disruption."
            )
        elif overall == "degraded":
            so_what = (
                "Bridge is operational but degraded. Reduced redundancy or "
                "stuck transactions indicate potential reliability issues."
            )
            now_what = (
                "Action: investigate offline relayers and stuck transactions. "
                "Monitor for further degradation. Prepare escalation if "
                "condition persists."
            )
        else:
            so_what = (
                "Bridge is operating normally. TVL is stable, relayer quorum "
                "is met, and no significant transaction backlog."
            )
            now_what = (
                "Action: no immediate action needed. Continue monitoring "
                "TVL trends and relayer liveness."
            )

        confidence = 0.85 if overall == "healthy" else 0.75

        persist_finding(
            db_path=db_path,
            domain="network_health",
            engine="bridge_health",
            evidence_type="bridge_health_check",
            finding=f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}",
            confidence=confidence,
            raw_data={
                "overall_health": overall,
                "tvl": tvl,
                "relayers": relayers,
                "stuck": stuck,
                "alerts": alerts,
            },
            source_repo="zenon_rpc",
        )
    except Exception as exc:
        logger.debug("Bridge health finding persistence failed: %s", exc)

    return {
        "success": True,
        "overall_health": overall,
        "tvl": tvl,
        "relayers": relayers,
        "stuck_transactions": stuck,
        "pending_wraps": len(wraps),
        "pending_unwraps": len(unwraps),
        "alerts": alerts,
        "snapshot_id": snapshot_id,
    }
