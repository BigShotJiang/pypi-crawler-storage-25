# SPDX-License-Identifier: MIT
"""
DecentralizationScorer -- Score network decentralization across multiple dimensions.

Evaluates: pillar weight distribution (Nakamoto coefficient), hosting provider
concentration (if detectable), and geographic spread estimation.  Produces a
composite decentralization score from 0 (centralized) to 100 (maximally decentralized).
"""

import json
import logging
import math
from pathlib import Path

from core.persist_to_db import persist_metric
from core.zenon_data import get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Weights for composite score
WEIGHT_NAKAMOTO = 0.40
WEIGHT_DELEGATION = 0.30
WEIGHT_PILLAR_COUNT = 0.30


def fetch_pillar_weights() -> list[dict]:
    """Return pillar delegation weights as ``[{name, weight}, ...]``.

    Uses :mod:`core.zenon_data` HTTP JSON-RPC. Returns an empty list when
    the node is unreachable so callers can short-circuit cleanly.
    """
    rpc = get_zenon_data()
    raw = rpc.get_all_pillars(page=0, count=500)
    pillars: list[dict] = []
    for pillar in raw:
        try:
            weight = float(pillar.get("weight", pillar.get("delegatedWeight", 0)))
        except (TypeError, ValueError):
            weight = 0.0
        name = pillar.get("name", "unknown")
        pillars.append({"name": name, "weight": weight})
    return pillars


def calculate_nakamoto_coefficient(pillars: list[dict]) -> int:
    """Calculate Nakamoto coefficient: minimum number of pillars to control >50% weight.

    Higher is better (more decentralized).
    """
    if not pillars:
        return 0

    total_weight = sum(p["weight"] for p in pillars)
    if total_weight == 0:
        return len(pillars)  # Equal weight = max decentralization

    sorted_pillars = sorted(pillars, key=lambda p: p["weight"], reverse=True)
    cumulative = 0.0
    threshold = total_weight * 0.5

    for i, p in enumerate(sorted_pillars, 1):
        cumulative += p["weight"]
        if cumulative > threshold:
            return i

    return len(sorted_pillars)


def calculate_delegation_hhi(pillars: list[dict]) -> float:
    """Calculate Herfindahl-Hirschman Index for delegation distribution.

    Returns value between 0 (perfect distribution) and 1 (monopoly).
    Lower is better for decentralization.
    """
    if not pillars:
        return 1.0

    total_weight = sum(p["weight"] for p in pillars)
    if total_weight == 0:
        # Equal weight assumed
        n = len(pillars)
        return 1.0 / n if n > 0 else 1.0

    shares = [p["weight"] / total_weight for p in pillars]
    return sum(s**2 for s in shares)


def calculate_gini(weights: list[float]) -> float:
    """Calculate Gini coefficient for a list of weights.

    Returns 0 (perfect equality) to 1 (perfect inequality).
    """
    if not weights or len(weights) < 2:
        return 0.0

    sorted_w = sorted(weights)
    n = len(sorted_w)
    total = sum(sorted_w)
    if total == 0:
        return 0.0

    cumulative = 0.0
    weighted_sum = 0.0
    for i, w in enumerate(sorted_w, 1):
        cumulative += w
        weighted_sum += (2 * i - n - 1) * w

    return abs(weighted_sum / (n * total))


def score_pillar_count(count: int) -> float:
    """Score based on absolute pillar count (0-100).

    Diminishing returns: 30 pillars = ~50, 100 pillars = ~80, 200+ = ~95.
    """
    if count <= 0:
        return 0.0
    # Logarithmic scoring with saturation
    return min(100.0, 20 * math.log2(count))


def score_nakamoto(coefficient: int, total_pillars: int) -> float:
    """Score Nakamoto coefficient relative to total pillars (0-100).

    A coefficient of total/3 or higher is excellent.
    """
    if total_pillars <= 0 or coefficient <= 0:
        return 0.0

    ratio = coefficient / total_pillars
    # Scale: 0.33+ = 100, 0.10 = 50, 0.01 = 10
    return min(100.0, max(0.0, ratio * 300))


def score_delegation_distribution(hhi: float, gini: float) -> float:
    """Score delegation distribution (0-100).

    Lower HHI and Gini = better decentralization = higher score.
    """
    hhi_score = max(0.0, 100.0 * (1.0 - hhi * 10))  # HHI < 0.1 is good
    gini_score = max(0.0, 100.0 * (1.0 - gini))
    return (hhi_score + gini_score) / 2


def compute_composite_score(
    pillar_count_score: float,
    nakamoto_score: float,
    delegation_score: float,
) -> float:
    """Compute weighted composite decentralization score (0-100)."""
    return (
        WEIGHT_PILLAR_COUNT * pillar_count_score
        + WEIGHT_NAKAMOTO * nakamoto_score
        + WEIGHT_DELEGATION * delegation_score
    )


def persist_decentralization_score(
    score: float,
    details: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist decentralization score as an evidence entry.

    Uses the evidence table from the core schema.
    """
    title = (
        f"WHAT: Network decentralization score is {score:.1f}/100 "
        f"(Nakamoto coefficient: {details['nakamoto_coefficient']}, "
        f"Gini: {details['gini']}, {details['pillar_count']} pillars). "
        f"SO WHAT: {'Score is healthy; weight distribution is well-spread across pillars.' if score >= 60 else 'Low score signals delegation concentration risk; a few pillars could collude to control consensus.' if score >= 30 else 'Critical centralization risk; network security depends on very few pillars.'} "
        f"NOW WHAT: {'Monitor for delegation shifts that could reduce the Nakamoto coefficient.' if score >= 60 else 'Encourage delegators to spread weight to smaller pillars; track top-5 pillar weight share trend.' if score >= 30 else 'Urgently flag to community; propose delegation incentive changes to reduce concentration.'}"
    )
    row_id = persist_metric(
        db_path=db_path,
        table="evidence",
        data={
            "domain": "network_health",
            "engine": "decentralization_scorer",
            "finding_type": "metric",
            "title": title,
            "body": json.dumps(details, indent=2),
            "confidence": min(score / 100.0, 1.0),
            "source": "zenon_rpc",
        },
    )
    return row_id if row_id > 0 else 0


def run_decentralization_scoring(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full decentralization scoring analysis.

    Returns composite score and component breakdowns.
    """
    pillars = fetch_pillar_weights()

    if not pillars:
        return {
            "success": False,
            "error": "Failed to fetch pillar data from API.",
        }

    pillar_count = len(pillars)
    weights = [p["weight"] for p in pillars]

    nakamoto = calculate_nakamoto_coefficient(pillars)
    hhi = calculate_delegation_hhi(pillars)
    gini = calculate_gini(weights)

    pc_score = score_pillar_count(pillar_count)
    nk_score = score_nakamoto(nakamoto, pillar_count)
    dl_score = score_delegation_distribution(hhi, gini)
    composite = compute_composite_score(pc_score, nk_score, dl_score)

    details = {
        "pillar_count": pillar_count,
        "nakamoto_coefficient": nakamoto,
        "hhi": round(hhi, 6),
        "gini": round(gini, 4),
        "scores": {
            "pillar_count": round(pc_score, 1),
            "nakamoto": round(nk_score, 1),
            "delegation": round(dl_score, 1),
            "composite": round(composite, 1),
        },
        "top_5_pillars": sorted(pillars, key=lambda p: p["weight"], reverse=True)[:5],
    }

    evidence_id = persist_decentralization_score(composite, details, db_path=db_path)

    return {
        "success": True,
        "composite_score": round(composite, 1),
        "nakamoto_coefficient": nakamoto,
        "hhi": round(hhi, 6),
        "gini": round(gini, 4),
        "pillar_count": pillar_count,
        "evidence_id": evidence_id,
        "details": details,
    }
