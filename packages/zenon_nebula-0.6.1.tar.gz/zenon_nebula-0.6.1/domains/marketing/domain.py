# SPDX-License-Identifier: MIT
"""
MarketingDomain -- DomainPlugin for marketing intelligence and ecosystem positioning.

Provides engines for analyzing narrative effectiveness and understanding
Zenon's competitive positioning in the crypto market. Marketing INTELLIGENCE
only -- content distribution remains in zenon-org/marketing.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class MarketingDomain(DomainPlugin):
    """Marketing domain plugin -- narrative analysis and ecosystem positioning."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "marketing"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Marketing intelligence: narrative effectiveness analysis, "
            "ecosystem positioning, competitive comparison, and market gap "
            "identification. Content distribution handled by zenon-org/marketing."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 6

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="narrative_analyzer",
                description=(
                    "Analyzes which marketing narratives resonate by reading "
                    "strategy angle data and categorizing by theme."
                ),
                module_path="domains.marketing.engines.narrative_analyzer",
                priority=6,
                tier=2,
                required_apis=["filesystem"],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="ecosystem_positioning",
                description=(
                    "Compares Zenon's development activity vs comparable "
                    "projects, identifies market gaps and differentiators."
                ),
                module_path="domains.marketing.engines.ecosystem_positioning",
                priority=6,
                tier=2,
                required_apis=["filesystem", "git", "github_api"],
                max_runtime_seconds=180,
            ),
            EngineDefinition(
                name="narrative_dominance",
                description=(
                    "Scores per-angle narrative dominance from workspace "
                    "signals (commits, docs, specs). Online variants scan "
                    "the web and compare against competitors."
                ),
                module_path="domains.marketing.engines.narrative_dominance",
                priority=6,
                tier=2,
                required_apis=["filesystem", "git"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="bitcoin_narrative_builder",
                description=(
                    "Surfaces Bitcoin-adjacent narratives (covenants, "
                    "Lightning, Ordinals, L2s) and maps them to Zenon's "
                    "relevant tech angles."
                ),
                module_path="domains.marketing.engines.bitcoin_narrative_builder",
                priority=6,
                tier=2,
                required_apis=["http"],
                max_runtime_seconds=60,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="narrative_resonance",
                label="Narrative resonance detected",
                description=(
                    "A marketing narrative is gaining traction based on "
                    "engagement signals and community response."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.75,
            ),
            HypothesisType(
                type_id="market_positioning",
                label="Market positioning opportunity",
                description=(
                    "A gap in the crypto market has been identified that "
                    "Zenon's features could fill."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.70,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="clear_positioning",
                label="Clear market positioning established",
                description=(
                    "Zenon has identified and is communicating its top 3 "
                    "differentiators consistently."
                ),
                priority=5,
                deadline_days=90,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="marketing_pmf_overlap",
                label="Marketing-PMF overlap",
                description=(
                    "Marketing narrative intersects with product-market "
                    "fit signals from the PMF domain."
                ),
                source_domains=["marketing", "product_market_fit"],
                convergence_threshold=0.6,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="marketing",
                section_title="Marketing Intelligence",
                metrics=[
                    "top_narrative",
                    "differentiator_count",
                    "competitive_position",
                    "market_gaps",
                ],
                recommendations_prompt=(
                    "Based on narrative analysis and competitive positioning, "
                    "what messaging should we emphasize?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "narrative_categories_tracked": 0.0,
            "positioning_confidence": 0.0,
            "differentiator_strength": 0.0,
        }

    def decide_next_action(self, context: dict, exclude: set[str] | None = None) -> dict | None:
        """Rotate through all marketing engines, honoring exclude.

        Pre-v0.3.2 returned None on routine context with empty
        stale_data, so all four marketing engines were dead in the
        autonomous loop.
        """
        exclude = exclude or set()
        candidates: list[dict] = [
            {
                "action": "analyze_narratives",
                "reason": "Routine narrative analysis.",
                "priority": 7,
                "engine": "narrative_analyzer",
            },
            {
                "action": "update_positioning",
                "reason": "Routine ecosystem positioning.",
                "priority": 7,
                "engine": "ecosystem_positioning",
            },
            {
                "action": "check_narrative_dominance",
                "reason": "Routine narrative dominance scan.",
                "priority": 7,
                "engine": "narrative_dominance",
            },
            {
                "action": "build_bitcoin_narrative",
                "reason": "Routine Bitcoin-adjacent narrative hunt.",
                "priority": 7,
                "engine": "bitcoin_narrative_builder",
            },
        ]
        for candidate in candidates:
            key = f"marketing:{candidate['action']}"
            if key not in exclude:
                return candidate
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return ""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Marketing domain registered with %d engines.",
            len(self.get_engines()),
        )

    def is_private(self) -> bool:
        """Marketing is entirely private.

        Drafts, leads, outreach, narrative analysis and positioning are
        all competitive intelligence that must never leave the local
        instance. This matches transport.PRIVATE_DOMAINS.
        """
        return True
