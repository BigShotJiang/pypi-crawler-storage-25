# SPDX-License-Identifier: MIT
"""
EcosystemPositioning -- Where Zenon sits in the crypto market.

Compares Zenon's GitHub activity vs comparable projects, analyzes
competitive positioning based on available repo/development data,
identifies market gaps Zenon could fill, and persists positioning
insights as evidence.
"""

import json
import logging
import os
import subprocess
from collections import Counter
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# Comparable projects (L1s with BTC bridge or dual-token) for positioning
COMPARABLE_PROJECTS = {
    "zenon-network": {
        "label": "Zenon Network",
        "github_org": "zenon-network",
        "category": "L1 with BTC bridge",
    },
    "thorchain": {
        "label": "THORChain",
        "github_org": "thorchain",
        "category": "Cross-chain DEX",
    },
    "stacks": {
        "label": "Stacks",
        "github_org": "stacks-network",
        "category": "Bitcoin L2",
    },
    "lightning": {
        "label": "Lightning Network",
        "github_org": "lightningnetwork",
        "category": "Bitcoin L2",
    },
}


def _run_gh(args: list[str], timeout: int = 30) -> tuple[int, str]:
    """Run a gh CLI command. Returns (returncode, stdout)."""
    cmd = ["gh", *args]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def _run_git(repo_path: str, *args: str, timeout: int = 30) -> tuple[int, str]:
    """Run a git command. Returns (returncode, stdout)."""
    cmd = ["git", "-C", repo_path, *list(args)]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def get_github_org_stats(org: str) -> dict | None:
    """Get GitHub org stats via gh api.

    Returns dict with: public_repo_count, total_stars, total_forks,
    top_repos (by stars).
    """
    # Get org repos
    code, output = _run_gh(
        [
            "api",
            f"orgs/{org}/repos",
            "-X",
            "GET",
            "-f",
            "per_page=100",
            "-f",
            "type=public",
            "--jq",
            "[.[] | {name: .name, stars: .stargazers_count, "
            "forks: .forks_count, language: .language, "
            "updated: .updated_at}]",
        ],
        timeout=45,
    )

    if code != 0 or not output:
        return None

    try:
        repos = json.loads(output)
    except json.JSONDecodeError:
        return None

    if not repos:
        return None

    total_stars = sum(r.get("stars", 0) for r in repos)
    total_forks = sum(r.get("forks", 0) for r in repos)
    top_repos = sorted(repos, key=lambda r: r.get("stars", 0), reverse=True)[:5]

    # Language distribution
    languages: Counter = Counter()
    for r in repos:
        lang = r.get("language")
        if lang:
            languages[lang] += 1

    return {
        "org": org,
        "public_repos": len(repos),
        "total_stars": total_stars,
        "total_forks": total_forks,
        "top_repos": top_repos,
        "languages": dict(languages.most_common(5)),
    }


def get_zenon_local_stats() -> dict:
    """Get Zenon development stats from local workspace repos.

    This works without GitHub API and provides more accurate data.
    """
    stats = {
        "total_repos": 0,
        "total_commits_90d": 0,
        "unique_contributors_90d": set(),
        "languages": Counter(),
        "repo_details": [],
    }

    scan_dirs = ["core", "zenon-network", "hypercore-one", "HyperCore-Team"]
    for scan_dir in scan_dirs:
        parent = ZENON_WORKSPACE / scan_dir
        if not parent.is_dir():
            continue
        for entry in sorted(parent.iterdir()):
            if not entry.is_dir() or not (entry / ".git").is_dir():
                continue

            stats["total_repos"] += 1
            repo_path = str(entry)

            # Recent commits
            code, count_out = _run_git(
                repo_path,
                "rev-list",
                "--count",
                "--since=90 days ago",
                "HEAD",
            )
            recent = int(count_out) if code == 0 and count_out.isdigit() else 0
            stats["total_commits_90d"] += recent

            # Contributors
            code, authors_out = _run_git(
                repo_path,
                "log",
                "--since=90 days ago",
                "--format=%an",
            )
            if code == 0 and authors_out:
                for name in authors_out.strip().split("\n"):
                    if name.strip():
                        stats["unique_contributors_90d"].add(name.strip())

            # Detect language
            for lang, ext in [
                ("Go", "*.go"),
                ("Dart", "*.dart"),
                ("TypeScript", "*.ts"),
                ("Python", "*.py"),
                ("Solidity", "*.sol"),
            ]:
                if list(entry.rglob(ext))[:1]:
                    stats["languages"][lang] += 1

            stats["repo_details"].append(
                {
                    "repo": f"{scan_dir}/{entry.name}",
                    "recent_commits_90d": recent,
                }
            )

    # Convert set to count
    stats["unique_contributors_90d"] = len(stats["unique_contributors_90d"])

    return stats


# ---------------------------------------------------------------------------
# Top 50 L1 feature matrix (deterministic, no API calls)
#
# Encodes whether each ecosystem shipped (as of 2026-04): a DEX, a mobile
# wallet, an NFT standard, a native BTC bridge, trustless cross-chain swaps
# (PTLC/atomic swaps), on-chain governance, and a feeless model.
#
# Hand-curated from public docs. It is intentionally rough - the purpose is
# a "where is Zenon a statistical outlier" check, not a leaderboard.
# ---------------------------------------------------------------------------

L1_FEATURE_MATRIX: dict[str, dict[str, bool]] = {
    # (dex, mobile_wallet, nft, btc_bridge, trustless_swap, governance, feeless)
    "bitcoin": {
        "dex": False,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": True,
        "governance": False,
        "feeless": False,
    },
    "ethereum": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "solana": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "bnb": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "xrp": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "cardano": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "avalanche": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "polkadot": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "tron": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "cosmos": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "near": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "aptos": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "sui": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "hedera": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "algorand": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "tezos": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "fantom": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "internet_computer": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": True,
        "feeless": True,
    },
    "filecoin": {
        "dex": False,
        "mobile": True,
        "nft": False,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "monero": {
        "dex": False,
        "mobile": True,
        "nft": False,
        "btc_bridge": False,
        "trustless_swap": True,
        "governance": False,
        "feeless": False,
    },
    "zcash": {
        "dex": False,
        "mobile": True,
        "nft": False,
        "btc_bridge": False,
        "trustless_swap": True,
        "governance": False,
        "feeless": False,
    },
    "litecoin": {
        "dex": False,
        "mobile": True,
        "nft": False,
        "btc_bridge": False,
        "trustless_swap": True,
        "governance": False,
        "feeless": False,
    },
    "dash": {
        "dex": False,
        "mobile": True,
        "nft": False,
        "btc_bridge": False,
        "trustless_swap": True,
        "governance": True,
        "feeless": False,
    },
    "iota": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": True,
    },
    "nano": {
        "dex": False,
        "mobile": True,
        "nft": False,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": True,
    },
    "kaspa": {
        "dex": False,
        "mobile": True,
        "nft": False,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "ergo": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "stacks": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "thorchain": {
        "dex": True,
        "mobile": True,
        "nft": False,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "injective": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "sei": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "celo": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "mina": {
        "dex": True,
        "mobile": True,
        "nft": False,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "waves": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "neo": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "eos": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": True,
        "feeless": True,
    },
    "harmony": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "klaytn": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "flow": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "chia": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": True,
        "governance": False,
        "feeless": False,
    },
    "conflux": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "kadena": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "oasis": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "zilliqa": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "radix": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "elrond": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "vechain": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "theta": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": False,
        "trustless_swap": False,
        "governance": True,
        "feeless": False,
    },
    "rsk": {
        "dex": True,
        "mobile": True,
        "nft": True,
        "btc_bridge": True,
        "trustless_swap": False,
        "governance": False,
        "feeless": False,
    },
    "decred": {
        "dex": False,
        "mobile": True,
        "nft": False,
        "btc_bridge": False,
        "trustless_swap": True,
        "governance": True,
        "feeless": False,
    },
}

FEATURE_LABELS: dict[str, str] = {
    "dex": "native DEX",
    "mobile": "mobile wallet",
    "nft": "NFT standard",
    "btc_bridge": "BTC bridge (any kind)",
    "trustless_swap": "trustless cross-chain swaps (PTLC/atomic)",
    "governance": "on-chain governance",
    "feeless": "feeless transaction model",
}


def detect_zenon_features() -> dict[str, dict]:
    """Inspect the workspace to detect which features Zenon has shipped.

    Each entry is ``{status: "yes"|"in_progress"|"no", evidence: str}``.
    "in_progress" means spec exists but not shipped; "yes" means present
    in go-zenon main or in a released SDK.
    """
    features: dict[str, dict] = {}
    go_zenon = ZENON_WORKSPACE / "core" / "go-zenon"
    impl_dir = go_zenon / "vm" / "embedded" / "implementation"
    specs_dir = ZENON_WORKSPACE / "knowledge" / "developer-commons" / "docs" / "specs"

    def _impl_has(names: list[str]) -> Path | None:
        if not impl_dir.is_dir():
            return None
        for name in names:
            p = impl_dir / f"{name}.go"
            if p.is_file():
                return p
        return None

    def _spec_has(token: str) -> Path | None:
        if not specs_dir.is_dir():
            return None
        token = token.lower()
        for entry in specs_dir.rglob("*.md"):
            if token in entry.stem.lower() or token in entry.parent.name.lower():
                return entry
        return None

    # DEX / liquidity
    liq = _impl_has(["liquidity", "swap"])
    features["dex"] = {
        "status": "yes" if liq else "no",
        "evidence": (
            f"{liq.relative_to(ZENON_WORKSPACE)}"
            if liq
            else "no liquidity/swap contract found in go-zenon"
        ),
    }

    # Mobile wallet - approximated by Syrius platform support
    syrius = ZENON_WORKSPACE / "core" / "syrius"
    mobile_plat = False
    if syrius.is_dir():
        for plat in ("android", "ios"):
            if (syrius / plat).is_dir():
                mobile_plat = True
                break
    features["mobile"] = {
        "status": "in_progress"
        if not mobile_plat and syrius.is_dir()
        else ("yes" if mobile_plat else "no"),
        "evidence": (
            "Syrius wallet Android/iOS targets found"
            if mobile_plat
            else "Syrius wallet present but no android/ios target"
            if syrius.is_dir()
            else "no syrius wallet in workspace"
        ),
    }

    # NFT standard - Zenon's ZTS is fungible, no native NFT standard. Mark
    # no unless a zts_nft or similar is found.
    nft_impl = _impl_has(["nft", "zts_nft"])
    features["nft"] = {
        "status": "yes" if nft_impl else "no",
        "evidence": (
            f"{nft_impl.relative_to(ZENON_WORKSPACE)}"
            if nft_impl
            else "no NFT-specific contract in go-zenon; ZTS tokens are fungible"
        ),
    }

    # BTC bridge - portal + bitcoin_spv
    bridge_impl = _impl_has(["portal", "bitcoin_spv"])
    bridge_spec = _spec_has("Portal") or _spec_has("Bitcoin-SPV")
    if bridge_impl:
        features["btc_bridge"] = {
            "status": "yes",
            "evidence": f"{bridge_impl.relative_to(ZENON_WORKSPACE)} shipped",
        }
    elif bridge_spec:
        features["btc_bridge"] = {
            "status": "in_progress",
            "evidence": f"spec exists at {bridge_spec.relative_to(ZENON_WORKSPACE)}",
        }
    else:
        features["btc_bridge"] = {"status": "no", "evidence": "no spec, no impl"}

    # Trustless cross-chain swaps - PTLC or HTLC
    swap_impl = _impl_has(["ptlc", "htlc", "atomic_swap"])
    swap_spec = _spec_has("PTLC") or _spec_has("AtomicSwap")
    if swap_impl:
        features["trustless_swap"] = {
            "status": "yes",
            "evidence": f"{swap_impl.relative_to(ZENON_WORKSPACE)} shipped",
        }
    elif swap_spec:
        features["trustless_swap"] = {
            "status": "in_progress",
            "evidence": f"spec exists at {swap_spec.relative_to(ZENON_WORKSPACE)}",
        }
    else:
        features["trustless_swap"] = {"status": "no", "evidence": "no spec, no impl"}

    # On-chain governance
    gov_impl = _impl_has(["governance"])
    gov_spec = _spec_has("Governance")
    if gov_impl:
        features["governance"] = {
            "status": "yes",
            "evidence": f"{gov_impl.relative_to(ZENON_WORKSPACE)} shipped",
        }
    elif gov_spec:
        features["governance"] = {
            "status": "in_progress",
            "evidence": f"spec exists at {gov_spec.relative_to(ZENON_WORKSPACE)}",
        }
    else:
        features["governance"] = {"status": "no", "evidence": "no spec, no impl"}

    # Feeless - Zenon's signature property, validated by plasma impl
    plasma_impl = _impl_has(["plasma"])
    features["feeless"] = {
        "status": "yes" if plasma_impl else "no",
        "evidence": (
            f"{plasma_impl.relative_to(ZENON_WORKSPACE)} implements feeless plasma model"
            if plasma_impl
            else "no plasma contract found"
        ),
    }

    return features


def compare_zenon_to_top_l1s() -> dict:
    """Compare Zenon's feature set against the top ~50 L1s.

    Produces, for each feature:
    - yes_count: how many L1s have it
    - no_count: how many do not
    - zenon_status: "yes" / "in_progress" / "no"
    - is_outlier: True when Zenon's status disagrees with the majority

    The outlier check is the actionable part: anywhere Zenon is "yes"
    while the majority is "no" (or vice versa) is a positioning lever.
    """
    zenon = detect_zenon_features()
    total_l1s = len(L1_FEATURE_MATRIX)
    rows: list[dict] = []
    for feature, label in FEATURE_LABELS.items():
        yes_count = sum(1 for p in L1_FEATURE_MATRIX.values() if p.get(feature))
        zenon_status = zenon.get(feature, {}).get("status", "no")
        majority_yes = yes_count >= total_l1s / 2
        zenon_yes = zenon_status == "yes"
        is_outlier_up = not majority_yes and zenon_yes
        is_outlier_down = majority_yes and not zenon_yes
        rows.append(
            {
                "feature": feature,
                "label": label,
                "yes_count": yes_count,
                "no_count": total_l1s - yes_count,
                "total": total_l1s,
                "zenon_status": zenon_status,
                "zenon_evidence": zenon.get(feature, {}).get("evidence", ""),
                "is_outlier_advantage": is_outlier_up,
                "is_outlier_gap": is_outlier_down,
            }
        )
    return {
        "total_l1s_compared": total_l1s,
        "feature_comparison": rows,
    }


def identify_market_gaps() -> list[dict]:
    """Identify market gaps Zenon could fill based on architecture analysis.

    Reads local evidence and architecture data to find positioning opportunities.
    """
    gaps = []

    # Check for BTC bridge positioning
    portal_dir = ZENON_WORKSPACE / "knowledge" / "developer-commons" / "docs" / "specs"
    has_portal = False
    has_ptlc = False
    if portal_dir.is_dir():
        for entry in portal_dir.iterdir():
            name_lower = entry.name.lower()
            if "portal" in name_lower:
                has_portal = True
            if "ptlc" in name_lower:
                has_ptlc = True

    if has_portal and has_ptlc:
        gaps.append(
            {
                "gap": "Trustless BTC bridge without wrapped tokens",
                "evidence": "Portal + PTLC specs exist, enabling native BTC swaps",
                "competitors": "THORChain uses liquidity pools (custodial risk), "
                "Stacks uses sBTC (trusted federation)",
                "strength": "high",
            }
        )

    # Check for feeless positioning
    go_zenon = ZENON_WORKSPACE / "core" / "go-zenon"
    if go_zenon.is_dir():
        plasma_files = list(go_zenon.rglob("*plasma*"))
        if plasma_files:
            gaps.append(
                {
                    "gap": "Feeless L1 with anti-spam via Plasma",
                    "evidence": f"Plasma implementation exists ({len(plasma_files)} files)",
                    "competitors": "IOTA (feeless but centralized coordinator), "
                    "Nano (feeless but no smart contracts)",
                    "strength": "medium",
                }
            )

    # Check for dual-ledger positioning
    definition_dir = go_zenon / "vm" / "embedded" / "definition" if go_zenon.is_dir() else None
    if definition_dir and definition_dir.is_dir():
        has_dual = False
        for go_file in definition_dir.glob("*.go"):
            try:
                text = go_file.read_text(errors="replace")
                if "ZnnTokenStandard" in text and "QsrTokenStandard" in text:
                    has_dual = True
                    break
            except OSError:
                pass
        if has_dual:
            gaps.append(
                {
                    "gap": "Dual-coin economic model (utility + collateral)",
                    "evidence": "ZNN and QSR token standards in embedded contracts",
                    "competitors": "Most L1s use single token (less economic flexibility)",
                    "strength": "medium",
                }
            )

    # Fair launch positioning (always applicable)
    gaps.append(
        {
            "gap": "Fair launch L1 (no premine, no VC, no ICO)",
            "evidence": "Historical launch mechanism with no known insider allocation",
            "competitors": "Most post-2020 L1s have VC funding and insider allocations",
            "strength": "high",
        }
    )

    return gaps


def compare_activity() -> dict:
    """Compare Zenon's GitHub activity with comparable projects.

    Returns comparison data. Falls back to local-only data if
    GitHub API is unavailable.
    """
    zenon_local = get_zenon_local_stats()
    comparisons = []

    # Try to get GitHub stats for comparable projects
    for _project_id, project_info in COMPARABLE_PROJECTS.items():
        org_stats = get_github_org_stats(project_info["github_org"])
        if org_stats:
            comparisons.append(
                {
                    "project": project_info["label"],
                    "category": project_info["category"],
                    "github_org": project_info["github_org"],
                    "stats": org_stats,
                }
            )

    return {
        "zenon": {
            "total_repos": zenon_local["total_repos"],
            "commits_90d": zenon_local["total_commits_90d"],
            "contributors_90d": zenon_local["unique_contributors_90d"],
            "languages": dict(zenon_local["languages"].most_common(5)),
        },
        "comparisons": comparisons,
        "comparison_count": len(comparisons),
    }


def generate_report() -> dict:
    """Generate a full ecosystem positioning report."""
    activity = compare_activity()
    market_gaps = identify_market_gaps()
    l1_comparison = compare_zenon_to_top_l1s()

    # Positioning summary
    strengths = [g for g in market_gaps if g["strength"] == "high"]
    positioning = (
        f"Zenon has {len(strengths)} strong market differentiators"
        if strengths
        else "Zenon positioning needs strengthening"
    )

    return {
        "positioning_summary": positioning,
        "activity_comparison": activity,
        "market_gaps": market_gaps,
        "l1_comparison": l1_comparison,
        "differentiator_count": len(market_gaps),
        "strong_differentiators": len(strengths),
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run positioning analysis and persist findings to evidence table."""
    from core.persist_to_db import ensure_schema, persist_finding

    ensure_schema(db_path)
    count = 0

    report = generate_report()

    # Overall positioning finding
    z = report["activity_comparison"]["zenon"]
    comp_count = report["activity_comparison"]["comparison_count"]
    strong_count = report.get("strong_differentiators", 0)
    persist_finding(
        db_path=db_path,
        domain="marketing",
        engine="ecosystem_positioning",
        evidence_type="ecosystem_position",
        finding=(
            f"WHAT: Zenon has {strong_count} strong market differentiators, "
            f"{z['total_repos']} repos, {z['commits_90d']} commits (90d), "
            f"{z['contributors_90d']} contributors (90d) vs {comp_count} competitors. "
            f"SO WHAT: {'Strong differentiators provide clear messaging angles' if strong_count >= 2 else 'Few differentiators — positioning needs strengthening'}; "
            f"{'active development signals health' if z['commits_90d'] > 50 else 'low commit velocity may signal stagnation to observers'}. "
            f"NOW WHAT: {'Use differentiators in outreach content' if strong_count >= 2 else 'Identify and develop unique positioning angles'}; "
            f"{'maintain dev momentum' if z['commits_90d'] > 50 else 'increase visible development activity to attract contributors'}."
        ),
        confidence=0.75,
        raw_data=report,
        source_repo="workspace",
    )
    count += 1

    # Persist L1 feature comparison findings - one per feature
    total_l1s = report["l1_comparison"]["total_l1s_compared"]
    for row in report["l1_comparison"]["feature_comparison"]:
        row["feature"]
        label = row["label"]
        zenon_status = row["zenon_status"]
        yes_count = row["yes_count"]
        evidence = row["zenon_evidence"]

        if row["is_outlier_advantage"]:
            severity = "advantage"
            finding_text = (
                f"WHAT: Zenon has {label} (status: {zenon_status}) while only "
                f"{yes_count}/{total_l1s} top L1s do. Evidence: {evidence}. "
                f"SO WHAT: This is a differentiation lever - most competitors "
                f"lack this feature, so Zenon can own the narrative without "
                f"fighting for mindshare. "
                f"NOW WHAT: Lead outbound messaging with '{label}' this "
                f"quarter; publish a comparative thread that names which L1s "
                f"lack it."
            )
            confidence = 0.85
        elif row["is_outlier_gap"]:
            severity = "gap"
            finding_text = (
                f"WHAT: Zenon does NOT have {label} (status: {zenon_status}), "
                f"but {yes_count}/{total_l1s} top L1s do. Evidence: {evidence}. "
                f"SO WHAT: This is a material gap - users shopping across L1s "
                f"will notice the absence and it directly blocks adoption use "
                f"cases that require this feature. "
                f"NOW WHAT: Either ship {label} (check TminusZ specs for an "
                f"existing proposal) or publish a counter-narrative explaining "
                f"why Zenon intentionally omits it and what replaces it."
            )
            confidence = 0.80
        else:
            severity = "aligned"
            finding_text = (
                f"WHAT: Zenon {label}: {zenon_status} "
                f"({yes_count}/{total_l1s} top L1s have it). Evidence: {evidence}. "
                f"SO WHAT: Zenon is aligned with the market consensus here - "
                f"neither a differentiator nor a gap. "
                f"NOW WHAT: No urgent action; keep parity and look for "
                f"adjacent features to differentiate on."
            )
            confidence = 0.60

        persist_finding(
            db_path=db_path,
            domain="marketing",
            engine="ecosystem_positioning",
            evidence_type=f"l1_comparison_{severity}",
            finding=finding_text,
            confidence=confidence,
            raw_data=row,
            source_repo="workspace",
        )
        count += 1

    # Persist market gaps
    for gap in report["market_gaps"]:
        competitors = gap.get("competitors", "N/A")
        persist_finding(
            db_path=db_path,
            domain="marketing",
            engine="ecosystem_positioning",
            evidence_type="market_gap",
            finding=(
                f"WHAT: Market gap identified — {gap['gap']} (strength: {gap['strength']}). "
                f"SO WHAT: Competitors ({competitors}) have weaker approaches here, "
                f"giving Zenon a {'strong' if gap['strength'] == 'high' else 'moderate'} narrative advantage. "
                f"NOW WHAT: Create targeted content highlighting this gap; "
                f"use evidence ({gap['evidence']}) in developer outreach and social media."
            ),
            confidence=0.70 if gap["strength"] == "high" else 0.55,
            raw_data=gap,
            source_repo="workspace",
        )
        count += 1

    logger.info("EcosystemPositioning: persisted %d findings", count)
    return count
