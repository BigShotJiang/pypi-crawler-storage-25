# SPDX-License-Identifier: MIT
"""
BitcoinNarrativeBuilder - Surface Bitcoin-adjacent narratives where
Zenon's tech (SPV relay, PTLC, feeless plasma, dual-coin) earns a seat
at the table.

The engine is deliberately read-only and deterministic:

    1. Scan a small set of Bitcoin-adjacent sources for trending topics.
       Each source is read via HTTP and a keyword matcher classifies
       the discussion into a narrative bucket (covenants, Lightning,
       Ordinals/Runes, Stacks/L2s, BitVM).
    2. For each bucket, compute a ``resonance_score`` from mention
       density and recency.
    3. Cross-reference the bucket with a table of Zenon angles to
       produce a WHAT/SO WHAT/NOW WHAT finding that tells the marketing
       domain where to publish research next.

No LLM call is required at run time. External HTTP errors degrade
gracefully to ``no_signal``.
"""

from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from core.http import opsec_request, opsec_urlopen  # noqa: F401  OPSEC-safe HTTP wrapper

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

REQUEST_TIMEOUT = 15

# Sources that expose public, polite JSON feeds of Bitcoin-adjacent
# conversation. Each entry is (url, parser_key). No authentication is
# required for any of these as of the 2026-04-09 check.
SOURCES: tuple[tuple[str, str], ...] = (
    (
        "https://stacker.news/api/items?type=top&sort=recent&limit=40",
        "stacker_news",
    ),
    (
        "https://hn.algolia.com/api/v1/search?tags=story&"
        "query=bitcoin%20bridge%20OR%20PTLC%20OR%20BitVM%20OR%20covenant",
        "hn_algolia",
    ),
    (
        "https://www.reddit.com/r/Bitcoin/top.json?t=week&limit=40",
        "reddit_top",
    ),
)


NARRATIVE_BUCKETS: dict[str, dict] = {
    "covenants": {
        "label": "Bitcoin covenants (CTV, APO, OP_CAT)",
        "keywords": (
            "covenant",
            "ctv",
            "op_ctv",
            "op_cat",
            "apo",
            "checksig",
            "op_vault",
        ),
        "zenon_angles": (
            "PTLC + covenants enable true trustless escrow on both sides.",
            "Zenon can demo a covenant-free atomic swap via PTLC today.",
        ),
    },
    "lightning": {
        "label": "Lightning Network",
        "keywords": (
            "lightning",
            "ln",
            "lnd",
            "ldk",
            "bolt12",
            "bolt 12",
            "phoenix",
            "splice",
        ),
        "zenon_angles": (
            "NoM's feeless plasma complements Lightning for micro-routing.",
            "Zenon PTLC maps directly onto Lightning payment points.",
        ),
    },
    "ordinals_runes": {
        "label": "Ordinals / Runes / BRC-20",
        "keywords": (
            "ordinal",
            "rune",
            "brc-20",
            "brc20",
            "inscription",
            "arc-20",
        ),
        "zenon_angles": (
            "Zenon offers a token registry with zero fee-market friction.",
            "Ordinals activity validates demand for programmable Bitcoin.",
        ),
    },
    "l2_bridges": {
        "label": "Bitcoin L2s and bridges",
        "keywords": (
            "bitvm",
            "rollup",
            "stacks",
            "rgb",
            "fedimint",
            "ark",
            "bridge",
            "sidechain",
        ),
        "zenon_angles": (
            "Portal V2 is a trustless BTC bridge without relayer quorum.",
            "Zenon SPV relay verifies Bitcoin headers directly on NoM.",
        ),
    },
    "mining_policy": {
        "label": "Mining policy / consensus changes",
        "keywords": (
            "softfork",
            "consensus",
            "mempool policy",
            "filter",
            "block size",
            "halving",
        ),
        "zenon_angles": (
            "NoM's PoW+PoS dual consensus avoids mining centralization.",
            "Zenon's feeless model removes MEV as an attack surface.",
        ),
    },
}


# ---------------------------------------------------------------------------
# Source parsers
# ---------------------------------------------------------------------------


@dataclass
class Post:
    """Normalized discussion item from a Bitcoin-adjacent source."""

    source: str
    title: str
    url: str
    score: int
    comments: int


def _http_get_json(url: str) -> dict | None:
    """HTTP GET a URL and return parsed JSON, or ``None`` on failure."""
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "nebula-bitcoin-narrative/1.0",
            "Accept": "application/json",
        },
    )
    try:
        with opsec_urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            raw = resp.read()
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        logger.debug("Narrative source fetch failed (%s): %s", url, exc)
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        logger.debug("Narrative source bad JSON (%s): %s", url, exc)
        return None


def _parse_stacker_news(payload: dict) -> list[Post]:
    """Normalize Stacker News API payloads."""
    items = payload.get("data", {}).get("items", {}).get("items") or []
    posts: list[Post] = []
    for item in items:
        title = str(item.get("title") or "")
        if not title:
            continue
        posts.append(
            Post(
                source="stacker_news",
                title=title,
                url=str(item.get("url") or item.get("id") or ""),
                score=int(item.get("sats") or 0),
                comments=int(item.get("nComments") or 0),
            )
        )
    return posts


def _parse_hn_algolia(payload: dict) -> list[Post]:
    """Normalize HN Algolia search payloads."""
    hits = payload.get("hits") or []
    posts: list[Post] = []
    for hit in hits:
        title = str(hit.get("title") or "")
        if not title:
            continue
        posts.append(
            Post(
                source="hn_algolia",
                title=title,
                url=str(
                    hit.get("url")
                    or f"https://news.ycombinator.com/item?id={hit.get('objectID', '')}"
                ),
                score=int(hit.get("points") or 0),
                comments=int(hit.get("num_comments") or 0),
            )
        )
    return posts


def _parse_reddit_top(payload: dict) -> list[Post]:
    """Normalize Reddit /r/Bitcoin top.json payloads."""
    children = payload.get("data", {}).get("children") or []
    posts: list[Post] = []
    for child in children:
        data = child.get("data") or {}
        title = str(data.get("title") or "")
        if not title:
            continue
        posts.append(
            Post(
                source="reddit_top",
                title=title,
                url=str(data.get("url_overridden_by_dest") or data.get("url") or ""),
                score=int(data.get("ups") or 0),
                comments=int(data.get("num_comments") or 0),
            )
        )
    return posts


_PARSERS = {
    "stacker_news": _parse_stacker_news,
    "hn_algolia": _parse_hn_algolia,
    "reddit_top": _parse_reddit_top,
}


def fetch_all_sources() -> list[Post]:
    """Return the union of posts from every configured source."""
    posts: list[Post] = []
    for url, key in SOURCES:
        payload = _http_get_json(url)
        parser = _PARSERS.get(key)
        if not payload or not parser:
            continue
        try:
            posts.extend(parser(payload))
        except Exception as exc:  # defensive - never break on schema drift
            logger.debug("Parser %s failed: %s", key, exc)
    return posts


# ---------------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------------


@dataclass
class BucketResult:
    """Aggregated data for a single narrative bucket."""

    key: str
    label: str
    matches: list[Post]
    total_score: int
    total_comments: int
    angles: tuple[str, ...]

    @property
    def resonance_score(self) -> float:
        """Return a 0..1 resonance score.

        We weight post score 70% and comment count 30%, then normalize
        against a soft cap so a handful of viral posts do not drown out
        steady discussion.
        """
        raw = 0.7 * self.total_score + 0.3 * self.total_comments
        return round(min(raw / 2500.0, 1.0), 4)


def classify(posts: list[Post]) -> list[BucketResult]:
    """Bucket posts into narrative categories using keyword matching."""
    results: list[BucketResult] = []
    for key, bucket in NARRATIVE_BUCKETS.items():
        hits: list[Post] = []
        keywords = bucket["keywords"]
        for post in posts:
            title_lower = post.title.lower()
            if any(kw in title_lower for kw in keywords):
                hits.append(post)
        results.append(
            BucketResult(
                key=key,
                label=bucket["label"],
                matches=hits,
                total_score=sum(p.score for p in hits),
                total_comments=sum(p.comments for p in hits),
                angles=tuple(bucket["zenon_angles"]),
            )
        )
    return results


# ---------------------------------------------------------------------------
# Finding builder
# ---------------------------------------------------------------------------


def _build_finding(bucket: BucketResult) -> str:
    """Return a WHAT/SO WHAT/NOW WHAT finding for a bucket."""
    top = sorted(bucket.matches, key=lambda p: p.score, reverse=True)[:3]
    top_titles = "; ".join(f"'{p.title[:60]}'" for p in top) or "no top posts"
    angle_line = " | ".join(bucket.angles)
    return (
        f"WHAT: Bitcoin narrative '{bucket.label}' has "
        f"{len(bucket.matches)} recent posts (score={bucket.total_score}, "
        f"comments={bucket.total_comments}). Top: {top_titles}. "
        f"SO WHAT: Resonance score {bucket.resonance_score:.2f}. The "
        f"Bitcoin community is actively discussing this theme, so "
        f"Zenon's angles can ride the same wave. "
        f"NOW WHAT: Publish research with one of these angles - {angle_line}."
    )


def run_bitcoin_narrative_scan(*, db_path: str = DEFAULT_DB) -> dict:
    """Scan Bitcoin-adjacent sources and persist narrative findings.

    Returns a status dict with per-bucket counts and persisted
    evidence ids. Safe to call on every cycle.
    """
    from core.persist_to_db import ensure_schema, persist_finding

    ensure_schema(db_path)
    posts = fetch_all_sources()
    if not posts:
        persist_finding(
            db_path=db_path,
            domain="marketing",
            engine="bitcoin_narrative_builder",
            evidence_type="bitcoin_narrative_no_signal",
            finding=(
                "WHAT: No Bitcoin-adjacent posts fetched this cycle. "
                "SO WHAT: Narrative scanner has no signal - likely a "
                "transient network or rate-limit issue. "
                "NOW WHAT: Retry next cycle; if persistent, check "
                "Stacker News / HN / Reddit availability."
            ),
            confidence=0.50,
            source_repo="bitcoin_narrative_builder",
        )
        return {"success": False, "error": "no_signal", "buckets": []}

    buckets = classify(posts)
    evidence_ids: list[int] = []
    summary = []
    for bucket in buckets:
        if not bucket.matches:
            continue
        finding = _build_finding(bucket)
        ev_id = persist_finding(
            db_path=db_path,
            domain="marketing",
            engine="bitcoin_narrative_builder",
            evidence_type=f"bitcoin_narrative_{bucket.key}",
            finding=finding,
            confidence=min(0.85, 0.55 + bucket.resonance_score / 2),
            raw_data={
                "label": bucket.label,
                "match_count": len(bucket.matches),
                "total_score": bucket.total_score,
                "total_comments": bucket.total_comments,
                "resonance": bucket.resonance_score,
                "top_posts": [
                    {
                        "source": p.source,
                        "title": p.title,
                        "score": p.score,
                        "comments": p.comments,
                        "url": p.url,
                    }
                    for p in sorted(bucket.matches, key=lambda p: p.score, reverse=True)[:5]
                ],
                "angles": list(bucket.angles),
            },
            source_repo="bitcoin_narrative_builder",
        )
        if ev_id:
            evidence_ids.append(ev_id)
        summary.append(
            {
                "bucket": bucket.key,
                "matches": len(bucket.matches),
                "resonance": bucket.resonance_score,
            }
        )
    return {
        "success": True,
        "post_count": len(posts),
        "buckets": summary,
        "evidence_ids": evidence_ids,
    }


__all__ = [
    "BucketResult",
    "Post",
    "classify",
    "fetch_all_sources",
    "run_bitcoin_narrative_scan",
]
