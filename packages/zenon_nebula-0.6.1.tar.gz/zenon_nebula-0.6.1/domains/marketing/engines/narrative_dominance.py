# SPDX-License-Identifier: MIT
"""
NarrativeDominance -- Track which narratives dominate in Zenon community and crypto.

Generalized from marketing's narrative_dominance.py. Scans the web for Zenon
mentions, classifies them by narrative angle, ranks by engagement potential,
detects emerging narratives, and compares against competitor projects.

All findings are persisted to the evidence table in the marketing domain.
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from core.api_fingerprint import FingerprintedSession
from core.api_templates.web_search import search as web_search
from core.llm_provider import call_llm
from core.persist_to_db import ensure_schema, persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Known narrative categories for Zenon
NARRATIVE_CATEGORIES: dict[str, dict] = {
    "btc_bridge": {
        "label": "BTC Bridge / Trustless Interop",
        "keywords": ["bitcoin", "btc", "bridge", "portal", "trustless", "swap", "atomic", "spv"],
    },
    "feeless": {
        "label": "Feeless Transactions",
        "keywords": ["feeless", "no fees", "fee-less", "plasma", "zero fee", "gasless"],
    },
    "fair_launch": {
        "label": "Fair Launch / No Premine",
        "keywords": ["fair launch", "no premine", "no ico", "no vc", "community", "cypherpunk"],
    },
    "dual_ledger": {
        "label": "Dual Ledger Architecture",
        "keywords": ["dual ledger", "dual-ledger", "block lattice", "dag", "momentum"],
    },
    "defi_yield": {
        "label": "DeFi / Yield",
        "keywords": ["defi", "yield", "staking", "delegation", "orbital", "liquidity"],
    },
    "tech_innovation": {
        "label": "Technical Innovation",
        "keywords": ["ptlc", "schnorr", "taproot", "extension chain", "hyperqube"],
    },
    "mystery_origin": {
        "label": "Mystery / Origin Story",
        "keywords": ["satoshi", "anonymous", "mystery", "genesis", "kaine", "disappeared"],
    },
    "evm_supernova": {
        "label": "Supernova EVM",
        "keywords": ["supernova", "evm", "smart contract", "bagswap", "dex"],
    },
}

# Competitor projects for comparison
COMPETITORS = [
    {"name": "Stacks", "ticker": "STX", "narrative": "Bitcoin L2 / smart contracts"},
    {"name": "Lightning Network", "ticker": "LN", "narrative": "Bitcoin payments"},
    {"name": "Ergo", "ticker": "ERG", "narrative": "UTXO smart contracts / fair launch"},
    {"name": "Kaspa", "ticker": "KAS", "narrative": "DAG / proof of work / fast"},
    {"name": "Radix", "ticker": "XRD", "narrative": "DeFi / sharding"},
]


def scan_narratives(
    *,
    session: FingerprintedSession | None = None,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Search for Zenon mentions and classify by narrative angle.

    Returns dict with: mentions (list), category_counts, total_mentions.
    """
    if session is None:
        session = FingerprintedSession(engine_name="narrative_dominance")

    search_queries = [
        "Zenon Network ZNN",
        "Zenon crypto Bitcoin bridge",
        "wZNN DeFi yield",
        "Zenon Network feeless",
        "Zenon Supernova EVM",
    ]

    all_mentions: list[dict] = []

    for query in search_queries:
        try:
            results = web_search(query, session=session, max_results=5)
            if results:
                for r in results:
                    mention = {
                        "title": r.get("title", ""),
                        "snippet": r.get("snippet", r.get("description", "")),
                        "url": r.get("url", r.get("link", "")),
                        "query": query,
                    }
                    # Classify narrative category
                    mention["categories"] = _classify_mention(mention)
                    all_mentions.append(mention)
        except Exception as exc:
            logger.debug("Narrative scan failed for '%s': %s", query, exc)

    # Count category occurrences
    category_counts: dict[str, int] = {}
    for mention in all_mentions:
        for cat in mention.get("categories", []):
            category_counts[cat] = category_counts.get(cat, 0) + 1

    result = {
        "mentions": all_mentions,
        "category_counts": category_counts,
        "total_mentions": len(all_mentions),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    return result


def rank_narratives(
    *,
    scan_data: dict | None = None,
    session: FingerprintedSession | None = None,
    db_path: str = DEFAULT_DB,
) -> list[dict]:
    """Rank narratives by engagement and prevalence.

    Args:
        scan_data: Pre-computed data from scan_narratives().
        session: FingerprintedSession for API calls.
        db_path: Database path.

    Returns:
        Sorted list of dicts with: category, label, count, share_pct, rank.
    """
    if scan_data is None:
        scan_data = scan_narratives(session=session, db_path=db_path)

    counts = scan_data.get("category_counts", {})
    total = max(sum(counts.values()), 1)

    rankings: list[dict] = []
    for cat_id, count in counts.items():
        cat_info = NARRATIVE_CATEGORIES.get(cat_id, {})
        rankings.append(
            {
                "category": cat_id,
                "label": cat_info.get("label", cat_id),
                "count": count,
                "share_pct": round(count / total * 100, 1),
            }
        )

    # Sort by count descending
    rankings.sort(key=lambda r: r["count"], reverse=True)

    # Add rank
    for i, r in enumerate(rankings, 1):
        r["rank"] = i

    # Persist top narrative finding
    if rankings:
        try:
            ensure_schema(db_path)
            top_3 = ", ".join(f"{r['label']} ({r['share_pct']:.0f}%)" for r in rankings[:3])
            bottom_narratives = (
                ", ".join(f"{r['label']} ({r['share_pct']:.0f}%)" for r in rankings[-2:])
                if len(rankings) >= 2
                else "N/A"
            )
            persist_finding(
                db_path=db_path,
                domain="marketing",
                engine="narrative_dominance",
                evidence_type="narrative_ranking",
                finding=(
                    f"WHAT: Narrative ranking from {scan_data['total_mentions']} web mentions — "
                    f"top: {top_3}; bottom: {bottom_narratives}. "
                    f"SO WHAT: Top narratives reflect current community mindshare; "
                    f"bottom narratives are either weak or untapped opportunities. "
                    f"NOW WHAT: Amplify top narratives in content; test whether bottom "
                    f"narratives can gain traction with targeted content experiments."
                ),
                confidence=0.65 if scan_data["total_mentions"] > 5 else 0.40,
                raw_data={
                    "rankings": rankings,
                    "total_mentions": scan_data["total_mentions"],
                },
                source_repo="web_search",
            )
        except Exception as exc:
            logger.debug("Narrative ranking persistence failed: %s", exc)

    return rankings


def detect_emerging_narratives(
    *,
    scan_data: dict | None = None,
    session: FingerprintedSession | None = None,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Use LLM to identify new narrative angles nobody is pushing yet.

    Returns dict with: emerging_narratives (list), confidence, reasoning.
    """
    if scan_data is None:
        scan_data = scan_narratives(session=session, db_path=db_path)

    # Build context from scan results
    mentions_text = ""
    for m in scan_data.get("mentions", [])[:15]:
        title = m.get("title", "")
        snippet = m.get("snippet", "")[:150]
        if title:
            mentions_text += f"- {title}: {snippet}\n"

    known_categories = ", ".join(f"{info['label']}" for info in NARRATIVE_CATEGORIES.values())

    prompt = (
        f"Given these recent web mentions about Zenon Network:\n\n"
        f"{mentions_text if mentions_text else 'No recent mentions found.'}\n\n"
        f"Known narrative categories: {known_categories}\n\n"
        f"Identify narrative angles that are EMERGING but not yet dominant. "
        f"These are angles appearing in 1-2 mentions that could grow, or angles "
        f"completely absent that represent untapped potential.\n\n"
        f"Respond ONLY with valid JSON:\n"
        f'{{"emerging_narratives": ['
        f'{{"angle": "short name", "description": "why this is emerging", '
        f'"evidence": "what triggered this observation", "potential": 0.0-1.0}}], '
        f'"confidence": 0.0-1.0, '
        f'"reasoning": "2-3 sentences"}}'
    )

    try:
        llm_result = call_llm(
            prompt=prompt,
            system=(
                "You are a crypto narrative strategist. Identify underexploited "
                "messaging angles for blockchain projects. Focus on angles that "
                "resonate with specific audiences but are not yet saturated."
            ),
            model="auto",
            max_tokens=800,
            temperature=0.5,
        )

        if llm_result and llm_result.get("text"):
            parsed = _parse_json(llm_result["text"])
        else:
            parsed = {}

    except Exception as exc:
        logger.warning("Emerging narrative detection failed: %s", exc)
        parsed = {}

    result = {
        "emerging_narratives": parsed.get("emerging_narratives", []),
        "confidence": parsed.get("confidence", 0.0),
        "reasoning": parsed.get("reasoning", "Analysis unavailable."),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "scan_mentions_count": scan_data.get("total_mentions", 0),
    }

    # Persist emerging narratives
    if result["emerging_narratives"]:
        try:
            ensure_schema(db_path)
            angles = ", ".join(n.get("angle", "?") for n in result["emerging_narratives"][:3])
            persist_finding(
                db_path=db_path,
                domain="marketing",
                engine="narrative_dominance",
                evidence_type="emerging_narratives",
                finding=(
                    f"WHAT: Emerging narrative angles detected: {angles}. "
                    f"SO WHAT: These angles are appearing in early mentions but not yet saturated — "
                    f"first-mover advantage in messaging is available. "
                    f"NOW WHAT: Create 1-2 content pieces per emerging angle to test resonance; "
                    f"track engagement to decide which to scale."
                ),
                confidence=result["confidence"],
                raw_data=result,
                source_repo="web_search",
            )
        except Exception as exc:
            logger.debug("Emerging narrative persistence failed: %s", exc)

    return result


def compare_to_competitors(
    *,
    session: FingerprintedSession | None = None,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Compare Zenon's narrative positioning against competitor projects.

    Searches for each competitor and analyzes which narratives they push
    vs what Zenon pushes.

    Returns dict with competitor_narratives, zenon_advantages,
    narrative_gaps, recommendations.
    """
    if session is None:
        session = FingerprintedSession(engine_name="narrative_dominance")

    competitor_data: list[dict] = []

    for comp in COMPETITORS:
        try:
            results = web_search(
                f"{comp['name']} {comp['ticker']} crypto narrative",
                session=session,
                max_results=3,
            )
            snippets = []
            if results:
                for r in results[:3]:
                    title = r.get("title", "")
                    snippet = r.get("snippet", r.get("description", ""))[:150]
                    if title:
                        snippets.append(f"{title}: {snippet}")

            competitor_data.append(
                {
                    "name": comp["name"],
                    "ticker": comp["ticker"],
                    "expected_narrative": comp["narrative"],
                    "recent_mentions": snippets,
                    "mention_count": len(snippets),
                }
            )
        except Exception as exc:
            logger.debug("Competitor scan failed for %s: %s", comp["name"], exc)
            competitor_data.append(
                {
                    "name": comp["name"],
                    "ticker": comp["ticker"],
                    "expected_narrative": comp["narrative"],
                    "recent_mentions": [],
                    "mention_count": 0,
                }
            )

    # Use LLM to synthesize competitive positioning
    comp_summary = "\n".join(
        f"- {c['name']} ({c['ticker']}): {c['expected_narrative']}. "
        f"Recent mentions: {len(c['recent_mentions'])}"
        for c in competitor_data
    )

    prompt = (
        f"Compare Zenon Network's narrative positioning against these competitors:\n\n"
        f"{comp_summary}\n\n"
        f"Zenon's core narratives: BTC bridge (trustless Bitcoin interop via SPV), "
        f"feeless transactions (Plasma), dual-ledger DAG architecture, fair launch "
        f"(no premine/ICO/VC), Supernova EVM extension chain, mystery origin story.\n\n"
        f"Respond ONLY with valid JSON:\n"
        f'{{"zenon_advantages": ["list of narrative areas where Zenon has unique positioning"], '
        f'"narrative_gaps": ["areas where competitors dominate and Zenon is absent"], '
        f'"recommendations": ["3-5 specific narrative moves Zenon should make"], '
        f'"confidence": 0.0-1.0}}'
    )

    try:
        llm_result = call_llm(
            prompt=prompt,
            system=(
                "You are a competitive positioning analyst for crypto projects. "
                "Be specific about which narratives are owned by which projects "
                "and where opportunities exist for differentiation."
            ),
            model="auto",
            max_tokens=800,
            temperature=0.4,
        )

        if llm_result and llm_result.get("text"):
            parsed = _parse_json(llm_result["text"])
        else:
            parsed = {}

    except Exception as exc:
        logger.warning("Competitor comparison failed: %s", exc)
        parsed = {}

    result = {
        "competitors": competitor_data,
        "zenon_advantages": parsed.get("zenon_advantages", []),
        "narrative_gaps": parsed.get("narrative_gaps", []),
        "recommendations": parsed.get("recommendations", []),
        "confidence": parsed.get("confidence", 0.0),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    # Persist competitive analysis
    try:
        ensure_schema(db_path)
        advantages = (
            ", ".join(result["zenon_advantages"][:3])
            if result["zenon_advantages"]
            else "none identified"
        )
        gaps_text = ", ".join(result["narrative_gaps"][:3]) if result["narrative_gaps"] else "none"
        top_rec = (
            result["recommendations"][0]
            if result["recommendations"]
            else "review raw_data for details"
        )
        persist_finding(
            db_path=db_path,
            domain="marketing",
            engine="narrative_dominance",
            evidence_type="competitive_analysis",
            finding=(
                f"WHAT: Competitive narrative analysis vs {len(COMPETITORS)} projects — "
                f"Zenon advantages: {advantages}; gaps: {gaps_text}. "
                f"SO WHAT: {len(result['narrative_gaps'])} narrative gaps mean competitors "
                f"own mindshare in those areas; {len(result['zenon_advantages'])} advantages "
                f"are defensible positioning assets. "
                f"NOW WHAT: {top_rec}. See raw_data for {len(result['recommendations'])} total recommendations."
            ),
            confidence=result["confidence"],
            raw_data=result,
            source_repo="web_search",
        )
    except Exception as exc:
        logger.debug("Competitive analysis persistence failed: %s", exc)

    return result


# -- Internal helpers --


def score_workspace_dominance(db_path: str = DEFAULT_DB) -> dict:
    """Score narrative dominance from workspace signals (no LLM, no web).

    For each narrative category, compute a composite dominance score from:
    - Spec progress: how many TminusZ specs mention this angle
    - Commit activity: recent commit messages classified into this angle
    - Code surface: number of .go files touching this angle
    - SDK surface: matching Dart/TS files in the SDK repos

    This is the offline, deterministic analog of ``scan_narratives``. It
    reflects *what Zenon actually ships*, which is a better proxy for
    narrative strength than web chatter anyway when the goal is to decide
    which angles are credible to push.

    Returns a dict with per-category scores and a ranked list.
    """
    from domains.marketing.narrative_shared import analyze_from_workspace

    workspace = analyze_from_workspace()
    combined = workspace.get("combined", {})

    rankings: list[dict] = []
    total = max(sum(combined.values()), 1)
    for cat_id, score in sorted(combined.items(), key=lambda kv: kv[1], reverse=True):
        if score <= 0:
            continue
        cat_info = NARRATIVE_CATEGORIES.get(cat_id, {})
        rankings.append(
            {
                "category": cat_id,
                "label": cat_info.get("label", cat_id),
                "score": score,
                "share_pct": round(score / total * 100, 1),
                "commits": workspace["commit_hits"].get(cat_id, 0),
                "readmes": workspace["readme_hits"].get(cat_id, 0),
                "specs": workspace["spec_hits"].get(cat_id, 0),
            }
        )
    for i, r in enumerate(rankings, 1):
        r["rank"] = i

    # Concentration index (Herfindahl-Hirschman-like). A value of 1.0 means
    # one narrative dominates entirely; 1/N means perfectly balanced.
    if total > 1:
        shares = [r["share_pct"] / 100 for r in rankings]
        hhi = round(sum(s * s for s in shares), 4)
    else:
        hhi = 0.0

    try:
        ensure_schema(db_path)
        if rankings:
            top_3 = ", ".join(f"{r['label']} ({r['share_pct']:.0f}%)" for r in rankings[:3])
            top = rankings[0]
            dormant = [
                NARRATIVE_CATEGORIES[cat]["label"]
                for cat in NARRATIVE_CATEGORIES
                if cat not in {r["category"] for r in rankings}
            ]
            dormant_text = ", ".join(dormant[:3]) if dormant else "none"
            concentration_verdict = (
                "over-concentrated" if hhi >= 0.40 else "balanced" if hhi <= 0.20 else "moderate"
            )
            persist_finding(
                db_path=db_path,
                domain="marketing",
                engine="narrative_dominance",
                evidence_type="workspace_narrative_dominance",
                finding=(
                    f"WHAT: Workspace narrative dominance from "
                    f"{workspace.get('repo_count', 0)} repos "
                    f"({workspace.get('total_hits', 0)} keyword hits). "
                    f"Top three: {top_3}. Concentration index HHI={hhi:.2f} "
                    f"({concentration_verdict}). Dormant: {dormant_text}. "
                    f"SO WHAT: Because this signal is derived from what the "
                    f"project actually ships (commits + docs + specs), it is "
                    f"the most credible frame for outbound messaging -- any "
                    f"angle claimed here can be backed by the code. "
                    f"A {concentration_verdict} HHI means the narrative mix "
                    f"is {'too dependent on a single angle - diversify' if hhi >= 0.40 else 'healthy'}. "
                    f"NOW WHAT: Pin outbound content to {top['label']} this "
                    f"cycle, and commission one piece on each dormant angle "
                    f"to test whether it resonates with a different audience."
                ),
                confidence=0.75 if rankings else 0.40,
                raw_data={
                    "rankings": rankings,
                    "hhi": hhi,
                    "repo_count": workspace.get("repo_count", 0),
                    "total_hits": workspace.get("total_hits", 0),
                    "sources_scanned": workspace.get("sources_scanned", []),
                },
                source_repo="workspace",
            )
    except Exception as exc:
        logger.debug("Workspace dominance persistence failed: %s", exc)

    return {
        "rankings": rankings,
        "hhi": hhi,
        "repo_count": workspace.get("repo_count", 0),
        "total_hits": workspace.get("total_hits", 0),
    }


def run_narrative_dominance(db_path: str = DEFAULT_DB) -> dict:
    """Zero-arg scheduler entry point.

    Always runs the offline workspace dominance path so the engine produces
    findings on every cycle, even without web search or LLM access. If a
    FingerprintedSession is available the caller can still invoke
    ``scan_narratives`` / ``rank_narratives`` / ``detect_emerging_narratives``
    / ``compare_to_competitors`` separately for the online analyses.
    """
    result = score_workspace_dominance(db_path=db_path)
    return {
        "success": True,
        "mode": "offline_workspace",
        "rankings_count": len(result["rankings"]),
        "hhi": result["hhi"],
        "total_hits": result["total_hits"],
    }


def _classify_mention(mention: dict) -> list[str]:
    """Classify a mention into narrative categories based on keywords."""
    text = (mention.get("title", "") + " " + mention.get("snippet", "")).lower()

    matched: list[str] = []
    for cat_id, cat_info in NARRATIVE_CATEGORIES.items():
        for keyword in cat_info["keywords"]:
            if keyword in text:
                matched.append(cat_id)
                break

    return matched


def _parse_json(text: str) -> dict:
    """Best-effort JSON extraction from LLM response."""
    if text.startswith("```"):
        lines = text.split("\n")
        text = "\n".join(line for line in lines if not line.strip().startswith("```"))

    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return parsed
    except json.JSONDecodeError:
        pass

    start = text.find("{")
    end = text.rfind("}") + 1
    if start >= 0 and end > start:
        try:
            parsed = json.loads(text[start:end])
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass

    return {}
