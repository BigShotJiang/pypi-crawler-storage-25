# SPDX-License-Identifier: MIT
"""
NarrativeAnalyzer -- Analyze which marketing narratives resonate.

Three data sources, fused:

1. Marketing DB (private): strategy angles and content performance tables
   from zenon-org/marketing. Richest source when available.
2. Our own evidence DB: marketing-domain findings and hypotheses accumulated
   by sibling engines.
3. Workspace corpus (always available): commit messages, READMEs, docs, and
   spec titles in the Zenon workspace. Produces a deterministic narrative
   mix from what the project actually ships and talks about.

The workspace corpus path is deliberately zero-network and zero-LLM, so the
engine always produces >0 findings even on a fresh install with no marketing
DB and no web connectivity.
"""

import json
import logging
import sqlite3
from pathlib import Path

from core.persistence import connect
from domains.marketing.narrative_shared import (
    NARRATIVE_CATEGORIES,
    ZENON_WORKSPACE,
    analyze_from_workspace,
)

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Marketing DB location (in the private marketing repo)
MARKETING_DB_CANDIDATES = [
    ZENON_WORKSPACE / "zenon-org" / "marketing" / "data" / "wznn_ignition.db",
    ZENON_WORKSPACE / "zenon-org" / "marketing" / "data" / "engine.db",
]


def _find_marketing_db() -> str | None:
    """Find the marketing database file."""
    for candidate in MARKETING_DB_CANDIDATES:
        if candidate.is_file():
            return str(candidate)
    return None


def _query_marketing_db(db_path: str, query: str) -> list[dict]:
    """Execute a query against the marketing DB, returning list of row dicts."""
    try:
        conn = connect(db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(query).fetchall()
        conn.close()
        return [dict(row) for row in rows]
    except (sqlite3.Error, Exception) as exc:
        logger.debug("Marketing DB query failed: %s", exc)
        return []


def _get_table_names(db_path: str) -> list[str]:
    """Get all table names from a database."""
    try:
        conn = connect(db_path)
        rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        conn.close()
        return [r[0] for r in rows]
    except (sqlite3.Error, Exception):
        return []


def analyze_from_marketing_db() -> dict | None:
    """Analyze narrative performance from marketing DB data.

    Returns dict with angle performance data, or None if DB unavailable.
    """
    db_path = _find_marketing_db()
    if not db_path:
        return None

    tables = _get_table_names(db_path)

    result = {
        "db_path": db_path,
        "tables_found": tables,
        "strategy_angles": [],
        "content_performance": [],
        "category_scores": {},
    }

    # Try to read strategy_angles table
    if "strategy_angles" in tables:
        angles = _query_marketing_db(
            db_path,
            "SELECT * FROM strategy_angles ORDER BY ROWID DESC LIMIT 100",
        )
        result["strategy_angles"] = angles

        # Score categories based on angle data
        for angle in angles:
            angle_text = json.dumps(angle).lower()
            for cat_id, cat_info in NARRATIVE_CATEGORIES.items():
                for keyword in cat_info["keywords"]:
                    if keyword in angle_text:
                        if cat_id not in result["category_scores"]:
                            result["category_scores"][cat_id] = {
                                "label": cat_info["label"],
                                "mentions": 0,
                                "angles": [],
                            }
                        result["category_scores"][cat_id]["mentions"] += 1
                        # Store angle reference (trimmed)
                        angle_ref = str(angle.get("angle", angle.get("title", "")))[:100]
                        if (
                            angle_ref
                            and angle_ref not in result["category_scores"][cat_id]["angles"]
                        ):
                            result["category_scores"][cat_id]["angles"].append(angle_ref)
                        break

    # Try to read content/evidence tables for engagement data
    for table in ["evidence", "content", "content_performance", "ecosystem_events"]:
        if table in tables:
            rows = _query_marketing_db(
                db_path,
                f"SELECT * FROM {table} ORDER BY ROWID DESC LIMIT 50",
            )
            if rows:
                result["content_performance"].extend(rows[:20])

    return result


def analyze_from_evidence_db() -> dict:
    """Analyze narratives from our own evidence table (engine.db).

    Looks for marketing-related findings and hypothesis data.
    """
    result = {
        "marketing_findings": [],
        "narrative_hypotheses": [],
    }

    try:
        conn = connect(DEFAULT_DB)
        conn.row_factory = sqlite3.Row

        # Get marketing-domain findings
        rows = conn.execute(
            "SELECT * FROM evidence WHERE domain = 'marketing' ORDER BY timestamp DESC LIMIT 50"
        ).fetchall()
        result["marketing_findings"] = [dict(r) for r in rows]

        # Get narrative-related hypotheses
        rows = conn.execute(
            "SELECT * FROM hypotheses WHERE domain = 'marketing' "
            "OR id LIKE 'narrative_%' "
            "ORDER BY confidence DESC LIMIT 20"
        ).fetchall()
        result["narrative_hypotheses"] = [dict(r) for r in rows]

        conn.close()
    except (sqlite3.Error, Exception) as exc:
        logger.debug("Evidence DB query failed: %s", exc)

    return result


def generate_report() -> dict:
    """Generate a full narrative analysis report."""
    marketing_data = analyze_from_marketing_db()
    evidence_data = analyze_from_evidence_db()
    workspace_data = analyze_from_workspace()

    # Build narrative ranking. Prefer the marketing DB when it is
    # present and has content; otherwise fall back to the workspace
    # corpus so we always produce a ranking.
    category_ranking: list[dict] = []

    if marketing_data and marketing_data.get("category_scores"):
        for cat_id, score_data in sorted(
            marketing_data["category_scores"].items(),
            key=lambda x: x[1]["mentions"],
            reverse=True,
        ):
            category_ranking.append(
                {
                    "category": cat_id,
                    "label": score_data["label"],
                    "mentions": score_data["mentions"],
                    "sample_angles": score_data["angles"][:3],
                    "source": "marketing_db",
                }
            )

    workspace_total = workspace_data.get("total_hits", 0)
    if not category_ranking and workspace_total > 0:
        combined = workspace_data["combined"]
        for cat_id, score in sorted(
            combined.items(),
            key=lambda kv: kv[1],
            reverse=True,
        ):
            if score <= 0:
                continue
            category_ranking.append(
                {
                    "category": cat_id,
                    "label": NARRATIVE_CATEGORIES[cat_id]["label"],
                    "mentions": score,
                    "share_pct": round(score / workspace_total * 100, 1),
                    "commits": workspace_data["commit_hits"].get(cat_id, 0),
                    "readmes": workspace_data["readme_hits"].get(cat_id, 0),
                    "specs": workspace_data["spec_hits"].get(cat_id, 0),
                    "source": "workspace_corpus",
                }
            )

    has_marketing_db = marketing_data is not None
    has_evidence = len(evidence_data.get("marketing_findings", [])) > 0
    has_workspace = workspace_total > 0

    # Generate insights - WHAT / SO WHAT / NOW WHAT style.
    insights: list[str] = []
    if category_ranking:
        top = category_ranking[0]
        share = top.get("share_pct")
        share_text = f" ({share:.0f}% share)" if share is not None else ""
        insights.append(
            f"Strongest narrative: {top['label']} with {top['mentions']} mentions{share_text}"
        )
        if len(category_ranking) >= 2:
            second = category_ranking[1]
            s_share = second.get("share_pct")
            s_text = f" ({s_share:.0f}%)" if s_share is not None else ""
            insights.append(
                f"Second narrative: {second['label']} with {second['mentions']} mentions{s_text}"
            )
        # Flag underused narratives - categories with zero or near-zero hits.
        underused = [r["label"] for r in category_ranking if r["mentions"] <= 1]
        missing = [
            NARRATIVE_CATEGORIES[cat]["label"]
            for cat in NARRATIVE_CATEGORIES
            if cat not in {r["category"] for r in category_ranking}
        ]
        dormant = underused + missing
        if dormant:
            insights.append(f"Dormant narratives ({len(dormant)}): {', '.join(dormant[:5])}")

        # Concentration check - if the top narrative dominates, flag the
        # imbalance. Good marketing rotates angles instead of hammering one.
        top_share = top.get("share_pct")
        if top_share is not None and top_share >= 60:
            insights.append(
                f"Narrative imbalance: top angle is {top_share:.0f}% "
                "of the mix - recommend balancing across 2-3 angles"
            )
    if not has_marketing_db:
        insights.append("Marketing DB not found -- workspace corpus used as fallback")
    if not has_workspace:
        insights.append(
            "Workspace corpus empty -- no Zenon repos detected under ZENON_WORKSPACE_ROOT"
        )

    return {
        "has_marketing_db": has_marketing_db,
        "has_evidence_data": has_evidence,
        "has_workspace_data": has_workspace,
        "category_ranking": category_ranking,
        "insights": insights,
        "marketing_db_data": {
            "tables": marketing_data.get("tables_found", []) if marketing_data else [],
            "angle_count": len(marketing_data.get("strategy_angles", [])) if marketing_data else 0,
        },
        "evidence_data": {
            "finding_count": len(evidence_data.get("marketing_findings", [])),
            "hypothesis_count": len(evidence_data.get("narrative_hypotheses", [])),
        },
        "workspace_data": {
            "sources_scanned": workspace_data.get("sources_scanned", []),
            "repo_count": workspace_data.get("repo_count", 0),
            "total_hits": workspace_total,
            "commit_hits": workspace_data.get("commit_hits", {}),
            "readme_hits": workspace_data.get("readme_hits", {}),
            "spec_hits": workspace_data.get("spec_hits", {}),
        },
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run narrative analysis and persist findings to evidence table."""
    from core.persist_to_db import ensure_schema, persist_finding

    ensure_schema(db_path)
    count = 0

    report = generate_report()

    # Overall narrative finding
    if report["category_ranking"]:
        top_narratives = ", ".join(
            f"{r['label']} ({r['mentions']})" for r in report["category_ranking"][:3]
        )
        underused = [r["label"] for r in report["category_ranking"] if r["mentions"] <= 1]
        underused_text = ", ".join(underused[:3]) if underused else "none"
        source_note = (
            "marketing DB"
            if report["has_marketing_db"]
            and report["category_ranking"][0].get("source") == "marketing_db"
            else f"{report['workspace_data']['repo_count']} workspace repos"
        )
        finding_text = (
            f"WHAT: {len(report['category_ranking'])} narrative categories identified "
            f"from {source_note}; top narratives: {top_narratives}. "
            f"SO WHAT: Dominant narratives show where the project's actual "
            f"messaging lands; underused angles ({underused_text}) may be "
            f"untapped opportunities. "
            f"NOW WHAT: Double down on top narrative in next content cycle; "
            f"A/B test underused angles ({underused_text}) to find hidden resonance."
        )
    else:
        finding_text = (
            f"WHAT: Insufficient data for narrative ranking. "
            f"Marketing DB: {'found' if report['has_marketing_db'] else 'not found'}. "
            f"Workspace hits: {report['workspace_data']['total_hits']}. "
            f"Evidence findings: {report['evidence_data']['finding_count']}. "
            f"SO WHAT: Cannot determine which narratives resonate without data -- "
            f"marketing strategy is flying blind. "
            f"NOW WHAT: {'Populate marketing DB with strategy angles and content data.' if not report['has_marketing_db'] else 'Collect more evidence via web scanning and content performance tracking.'}"
        )

    persist_finding(
        db_path=db_path,
        domain="marketing",
        engine="narrative_analyzer",
        evidence_type="narrative_analysis",
        finding=finding_text,
        confidence=0.70 if report["category_ranking"] else 0.40,
        raw_data=report,
        source_repo="workspace",
    )
    count += 1

    # Persist individual insights (already concise actionable text)
    for insight in report.get("insights", []):
        persist_finding(
            db_path=db_path,
            domain="marketing",
            engine="narrative_analyzer",
            evidence_type="narrative_insight",
            finding=(
                f"WHAT: {insight}. "
                f"SO WHAT: This shapes which messaging angles to prioritize. "
                f"NOW WHAT: Incorporate into next content planning cycle."
            ),
            confidence=0.65,
            raw_data={"insight": insight},
            source_repo="workspace",
        )
        count += 1

    logger.info("NarrativeAnalyzer: persisted %d findings", count)
    return count
