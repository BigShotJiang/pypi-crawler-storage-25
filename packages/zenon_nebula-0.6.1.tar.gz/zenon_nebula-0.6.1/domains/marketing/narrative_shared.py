# SPDX-License-Identifier: MIT
"""
narrative_shared -- Shared workspace-scanning helpers for marketing engines.

Both :mod:`domains.marketing.engines.narrative_analyzer` and
:mod:`domains.marketing.engines.narrative_dominance` need to derive a
deterministic "what is this project actually shipping and talking about"
score by walking the Zenon workspace -- reading recent commit messages,
top-level READMEs, and spec titles -- and tallying keyword hits against
a narrative category table.

Hosting :func:`analyze_from_workspace` here lets both engines depend on
the same implementation without importing across engine boundaries. The
category table lives here too, because the scoring function needs it at
call time; ``narrative_dominance`` maintains its own separate,
campaign-facing category set and only consumes the raw ``combined``
counter returned by :func:`analyze_from_workspace`.
"""

import logging
import os
import re
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

# This module lives at domains/marketing/narrative_shared.py, so
# parents[2] is the nebula repo root and parents[1] above that is the
# Zenon workspace root.
ENGINE_ROOT = Path(__file__).resolve().parents[2]

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))


# Narrative categories and their keyword signals. Kept identical to the
# historical narrative_analyzer definition so results are stable.
NARRATIVE_CATEGORIES = {
    "btc_bridge": {
        "keywords": ["bitcoin", "btc", "bridge", "portal", "trustless", "swap", "atomic"],
        "label": "BTC Bridge / Trustless Interop",
    },
    "privacy": {
        "keywords": ["privacy", "confidential", "anonymous", "stealth", "zero-knowledge"],
        "label": "Privacy & Confidentiality",
    },
    "feeless": {
        "keywords": ["feeless", "no fees", "fee-less", "plasma", "zero fee", "gasless"],
        "label": "Feeless Transactions",
    },
    "fair_launch": {
        "keywords": [
            "fair launch",
            "no premine",
            "no ico",
            "no vc",
            "community",
            "decentralized launch",
        ],
        "label": "Fair Launch / No Premine",
    },
    "dual_coin": {
        "keywords": ["dual coin", "dual-coin", "znn", "qsr", "two-token", "dual ledger"],
        "label": "Dual Coin Model",
    },
    "network_of_momentum": {
        "keywords": ["momentum", "nom", "block lattice", "dag", "directed acyclic"],
        "label": "Network of Momentum Architecture",
    },
    "defi": {
        "keywords": ["defi", "liquidity", "yield", "staking", "delegation", "dex"],
        "label": "DeFi / Yield",
    },
    "tech_innovation": {
        "keywords": ["innovation", "novel", "breakthrough", "cutting-edge", "research"],
        "label": "Technical Innovation",
    },
}


def _run_git(repo_path: Path, *args: str, timeout: int = 30) -> tuple[int, str]:
    """Run a git command, returning (returncode, stdout)."""
    cmd = ["git", "-C", str(repo_path), *list(args)]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def _score_text(text: str) -> dict[str, int]:
    """Count keyword hits per narrative category in a blob of text."""
    text_lower = text.lower()
    hits: dict[str, int] = {}
    for cat_id, cat_info in NARRATIVE_CATEGORIES.items():
        count = 0
        for keyword in cat_info["keywords"]:
            # Whole-word / substring hybrid: use word boundary when the
            # keyword is alphanumeric, otherwise plain substring so phrases
            # like "no premine" still match.
            if re.fullmatch(r"[a-z0-9]+", keyword):
                count += len(re.findall(rf"\b{re.escape(keyword)}\b", text_lower))
            elif keyword in text_lower:
                count += text_lower.count(keyword)
        if count:
            hits[cat_id] = count
    return hits


def _merge_counts(a: dict[str, int], b: dict[str, int]) -> dict[str, int]:
    """Sum two category count dicts."""
    merged = dict(a)
    for k, v in b.items():
        merged[k] = merged.get(k, 0) + v
    return merged


def analyze_from_workspace() -> dict:
    """Derive narrative mix from workspace commits, READMEs, and specs.

    This is the zero-network, zero-LLM path. It walks a small set of
    high-signal repos and tallies keyword hits against the narrative
    category table. The result is a deterministic "what is this project
    actually talking about" score.

    Returns a dict with:
    - sources_scanned: list of what we read
    - commit_hits: category counter from recent commit messages
    - readme_hits: category counter from README files
    - spec_hits: category counter from TminusZ spec file titles
    - combined: weighted sum
    - total_hits: total keyword occurrences across all sources
    """
    scan_dirs = ("core", "zenon-network", "hypercore-one", "knowledge")
    repo_paths: list[Path] = []
    for scan_dir in scan_dirs:
        parent = ZENON_WORKSPACE / scan_dir
        if not parent.is_dir():
            continue
        for entry in sorted(parent.iterdir()):
            if entry.is_dir() and (entry / ".git").is_dir():
                repo_paths.append(entry)

    commit_hits: dict[str, int] = {}
    readme_hits: dict[str, int] = {}
    spec_hits: dict[str, int] = {}
    sources_scanned: list[str] = []

    # Limit the set to keep the runtime short and meaningful. Core protocol
    # repos dominate the narrative signal we care about.
    priority_repos = [
        "go-zenon",
        "syrius",
        "znn_sdk_dart",
        "znn_cli_dart",
        "zenon-node",
        "zenonhub",
        "wiki",
        "awesome-zenon",
        "developer-commons",
    ]
    ordered: list[Path] = []
    for repo in repo_paths:
        if repo.name in priority_repos:
            ordered.append(repo)
    # Cap at 10 repos so we do not run `git log` on every fork.
    for repo in repo_paths:
        if repo not in ordered and len(ordered) < 10:
            ordered.append(repo)

    for repo in ordered:
        # Recent commit messages (last 500 lines, full subject lines only)
        code, out = _run_git(
            repo,
            "log",
            "--pretty=%s",
            "-n",
            "500",
        )
        if code == 0 and out:
            commit_hits = _merge_counts(commit_hits, _score_text(out))
            sources_scanned.append(f"git_log:{repo.name}")

        # Top-level README files
        for readme_name in ("README.md", "README", "README.rst"):
            readme_path = repo / readme_name
            if readme_path.is_file():
                try:
                    text = readme_path.read_text(
                        encoding="utf-8",
                        errors="replace",
                    )[:60_000]
                except OSError:
                    continue
                readme_hits = _merge_counts(readme_hits, _score_text(text))
                sources_scanned.append(f"readme:{repo.name}")
                break

    # Spec titles - structural signal from developer-commons
    specs_dir = ZENON_WORKSPACE / "knowledge" / "developer-commons" / "docs" / "specs"
    if specs_dir.is_dir():
        for entry in specs_dir.rglob("*.md"):
            # Score the filename and the first 4 KB of the spec body.
            title_text = entry.stem.replace("_", " ").replace("-", " ")
            spec_hits = _merge_counts(spec_hits, _score_text(title_text))
            try:
                body = entry.read_text(encoding="utf-8", errors="replace")[:4_000]
            except OSError:
                continue
            spec_hits = _merge_counts(spec_hits, _score_text(body))
            sources_scanned.append(f"spec:{entry.name}")

    # Weighted combination: commits (3x) matter more than READMEs (2x)
    # which matter more than specs (1x). Commits reflect what is actually
    # being built right now; READMEs reflect current messaging; specs
    # reflect forward direction but have not shipped yet.
    combined: dict[str, int] = {}
    for cat_id in NARRATIVE_CATEGORIES:
        combined[cat_id] = (
            3 * commit_hits.get(cat_id, 0)
            + 2 * readme_hits.get(cat_id, 0)
            + 1 * spec_hits.get(cat_id, 0)
        )

    total_hits = sum(combined.values())
    return {
        "sources_scanned": sources_scanned,
        "commit_hits": commit_hits,
        "readme_hits": readme_hits,
        "spec_hits": spec_hits,
        "combined": combined,
        "total_hits": total_hits,
        "repo_count": len(ordered),
    }
