# SPDX-License-Identifier: MIT
"""Forge Marketing Domain -- placeholder pending migration from zenon-org/marketing."""
