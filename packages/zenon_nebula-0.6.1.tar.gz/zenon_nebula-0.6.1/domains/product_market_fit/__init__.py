# SPDX-License-Identifier: MIT
"""Forge Product-Market Fit Domain -- competitive analysis, positioning, and adoption tracking."""
