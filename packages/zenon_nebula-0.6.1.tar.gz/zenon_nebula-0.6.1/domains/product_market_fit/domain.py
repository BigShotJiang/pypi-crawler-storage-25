# SPDX-License-Identifier: MIT
"""
ProductMarketFitDomain -- DomainPlugin for competitive analysis, positioning, and adoption.

Provides engines for scanning competing projects, analyzing Zenon's technical
advantages, predicting roadmap priorities, and tracking developer adoption.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class ProductMarketFitDomain(DomainPlugin):
    """Product-Market Fit domain plugin -- competitive analysis and adoption tracking."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "product_market_fit"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Competitive landscape scanning, technical positioning analysis, "
            "roadmap priority prediction, and developer adoption tracking."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 4

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="landscape_scanner",
                description=(
                    "Track competing projects: Stacks, THORChain, Lightning, "
                    "RSK. Monitor their GitHub activity, releases, and metrics."
                ),
                module_path="domains.product_market_fit.engines.landscape_scanner",
                priority=1,
                tier=2,
                required_apis=["github", "dexscreener"],
                max_runtime_seconds=180,
            ),
            EngineDefinition(
                name="technical_positioning",
                description=(
                    "Analyze Zenon's unique advantages vs competitors: "
                    "dual-coin, embedded contracts, BTC alignment."
                ),
                module_path="domains.product_market_fit.engines.technical_positioning",
                priority=2,
                tier=2,
                required_apis=[],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="roadmap_predictor",
                description=(
                    "Predict next priorities based on spec progression, "
                    "community signals, and competitive pressure."
                ),
                module_path="domains.product_market_fit.engines.roadmap_predictor",
                priority=3,
                tier=3,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="adoption_tracker",
                description=(
                    "Track developer adoption: dApp count, integration "
                    "count, SDK downloads, GitHub stars."
                ),
                module_path="domains.product_market_fit.engines.adoption_tracker",
                priority=4,
                tier=2,
                required_apis=["github"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="fork_detector",
                description=(
                    "Scans workspace for non-Zenon repos that could be "
                    "forked/adapted: explorers, wallets, DEXs, bridges, "
                    "tools. Estimates adaptation effort by counting "
                    "chain-specific constants. No LLM -- file scanning only."
                ),
                module_path="domains.product_market_fit.engines.fork_detector",
                priority=5,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=300,
            ),
            EngineDefinition(
                name="ecosystem_gap",
                description=(
                    "Compare Zenon's ecosystem against a standard L1 "
                    "checklist (DEX, stablecoin, lending, hardware wallet, "
                    "etc.) and prioritize missing components."
                ),
                module_path="domains.product_market_fit.engines.ecosystem_gap",
                priority=6,
                tier=2,
                required_apis=["filesystem"],
                max_runtime_seconds=60,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="btc_bridge_killer_feature",
                label="Trustless BTC bridge is killer feature",
                description=(
                    "Zenon's trustless BTC bridge is the primary "
                    "differentiator that drives adoption over competitors."
                ),
                initial_confidence=0.4,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="developer_ecosystem_growing",
                label="Developer ecosystem growing",
                description=(
                    "The number of active developers, dApps, and integrations is trending upward."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.75,
            ),
            HypothesisType(
                type_id="competitive_moat_strengthening",
                label="Competitive moat strengthening",
                description=(
                    "Zenon's technical advantages are becoming harder for competitors to replicate."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.80,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="full_competitive_coverage",
                label="Full competitive landscape coverage",
                description=(
                    "Track all major competing projects with weekly activity and metric updates."
                ),
                priority=4,
            ),
            AspirationType(
                type_id="adoption_dashboard",
                label="Adoption metrics dashboard",
                description=(
                    "Maintain a comprehensive adoption dashboard with "
                    "daily resolution across all metrics."
                ),
                priority=4,
                deadline_days=90,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="pmf_development_overlap",
                label="PMF-development overlap",
                description=(
                    "A competitive threat identified by PMF analysis "
                    "intersects with a spec tracked by development."
                ),
                source_domains=["product_market_fit", "development"],
                convergence_threshold=0.5,
            ),
            CollisionSignal(
                signal_id="pmf_economics_overlap",
                label="PMF-economics overlap",
                description=(
                    "Adoption metrics intersect with tokenomics trends "
                    "requiring cross-domain analysis."
                ),
                source_domains=["product_market_fit", "economics"],
                convergence_threshold=0.6,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="product_market_fit",
                section_title="Product-Market Fit",
                metrics=[
                    "active_competitors",
                    "zenon_github_stars",
                    "dapp_count",
                    "integration_count",
                    "developer_count_trend",
                    "competitive_position_score",
                ],
                recommendations_prompt=(
                    "Based on competitive landscape and adoption metrics, "
                    "what product priorities should be flagged?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "competitors_tracked": 0.0,
            "adoption_data_freshness_hours": 0.0,
            "positioning_last_updated_hours": 0.0,
            "roadmap_prediction_accuracy": 0.0,
        }

    def decide_next_action(self, context: dict) -> dict | None:
        """Decide the highest-value next action given current state."""
        trigger = context.get("trigger_level", "routine")
        stale = context.get("stale_data", [])

        if trigger in ("urgent", "critical"):
            return {
                "action": "scan_competitors",
                "reason": "Urgent trigger -- check competitive landscape.",
                "priority": 4,
                "engine": "landscape_scanner",
            }

        if "competitive_data" in stale:
            return {
                "action": "scan_competitors",
                "reason": "Competitive data is stale.",
                "priority": 5,
                "engine": "landscape_scanner",
            }

        if "adoption_metrics" in stale:
            return {
                "action": "track_adoption",
                "reason": "Adoption metrics are stale.",
                "priority": 5,
                "engine": "adoption_tracker",
            }

        return {
            "action": "update_positioning",
            "reason": "Routine positioning analysis.",
            "priority": 6,
            "engine": "technical_positioning",
        }

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS competitive_landscape (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    project_name TEXT NOT NULL,
    category TEXT DEFAULT 'btc_l2',
    github_stars INTEGER DEFAULT 0,
    github_contributors INTEGER DEFAULT 0,
    commits_30d INTEGER DEFAULT 0,
    market_cap_usd REAL DEFAULT 0.0,
    tvl_usd REAL DEFAULT 0.0,
    unique_features TEXT,
    threat_level TEXT DEFAULT 'low',
    notes TEXT
);

CREATE TABLE IF NOT EXISTS adoption_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    metric_name TEXT NOT NULL,
    metric_value REAL DEFAULT 0.0,
    metric_category TEXT DEFAULT 'general',
    source TEXT,
    notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_competitive_project
    ON competitive_landscape(project_name);
CREATE INDEX IF NOT EXISTS idx_competitive_ts
    ON competitive_landscape(timestamp);
CREATE INDEX IF NOT EXISTS idx_adoption_metric
    ON adoption_metrics(metric_name);
CREATE INDEX IF NOT EXISTS idx_adoption_ts
    ON adoption_metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_adoption_category
    ON adoption_metrics(metric_category);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Product-Market Fit domain registered with %d engines.",
            len(self.get_engines()),
        )
