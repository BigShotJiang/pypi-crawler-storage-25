# SPDX-License-Identifier: MIT
"""
TechnicalPositioning -- Analyze Zenon's unique advantages vs competitors.

Evaluates Zenon's technical differentiators across multiple dimensions:
- Dual-coin model (ZNN + QSR)
- Embedded smart contracts (no EVM dependency)
- Bitcoin alignment (secp256k1, BIP standards)
- Trustless BTC bridge (no federation, no wrapped tokens)
- Dual-ledger architecture (block-lattice + meta-DAG)
- Feeless transactions (via QSR plasma)
"""

import json
import logging
from pathlib import Path

from core.persist_to_db import persist_metric

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Zenon's technical differentiators with scoring dimensions
DIFFERENTIATORS = [
    {
        "feature": "Dual-Coin Model",
        "dimension": "tokenomics",
        "description": (
            "ZNN for value transfer and staking, QSR for feeless "
            "transactions via plasma. Separates governance from utility."
        ),
        "competitors_with_similar": [],
        "moat_strength": 8,  # 1-10
    },
    {
        "feature": "Embedded Smart Contracts",
        "dimension": "smart_contracts",
        "description": (
            "Contracts are embedded in the protocol layer (Go), not "
            "running on a VM. Deterministic execution, no gas wars."
        ),
        "competitors_with_similar": [],
        "moat_strength": 9,
    },
    {
        "feature": "Bitcoin Cryptographic Alignment",
        "dimension": "btc_alignment",
        "description": (
            "Uses secp256k1, BIP-32/39/44 key derivation, and Bitcoin-"
            "compatible address formats. Native BTC interoperability."
        ),
        "competitors_with_similar": ["Stacks", "RSK"],
        "moat_strength": 7,
    },
    {
        "feature": "Trustless BTC Bridge",
        "dimension": "bridge",
        "description": (
            "TSS-based bridge with decentralized orchestrator. No "
            "federation, no wrapped tokens on the Zenon side."
        ),
        "competitors_with_similar": ["THORChain"],
        "moat_strength": 9,
    },
    {
        "feature": "Dual-Ledger Architecture",
        "dimension": "architecture",
        "description": (
            "Block-lattice for account chains + meta-DAG for consensus. "
            "Asynchronous transaction processing, high throughput."
        ),
        "competitors_with_similar": [],
        "moat_strength": 8,
    },
    {
        "feature": "Feeless Transactions",
        "dimension": "user_experience",
        "description": (
            "Transactions consume plasma (fused from QSR) instead of "
            "paying gas fees. Better UX for end users."
        ),
        "competitors_with_similar": [],
        "moat_strength": 7,
    },
    {
        "feature": "Sentinel-Pillar-Delegator Model",
        "dimension": "consensus",
        "description": (
            "Three-tier participation: pillars produce momentums, "
            "sentinels validate, delegators provide economic security."
        ),
        "competitors_with_similar": [],
        "moat_strength": 7,
    },
]

# Competitive comparison matrix
COMPARISON_DIMENSIONS = [
    "btc_alignment",
    "smart_contracts",
    "bridge",
    "tokenomics",
    "architecture",
    "user_experience",
    "consensus",
]


def score_zenon_positioning() -> dict:
    """Calculate Zenon's competitive positioning scores.

    Returns scores per dimension and an overall positioning score.
    """
    dimension_scores = {}
    for diff in DIFFERENTIATORS:
        dim = diff["dimension"]
        moat = diff["moat_strength"]
        # Reduce moat if competitors have similar features
        competitor_penalty = len(diff["competitors_with_similar"]) * 1.5
        adjusted = max(1, moat - competitor_penalty)
        dimension_scores[dim] = round(adjusted, 1)

    # Overall score: weighted average
    overall = sum(dimension_scores.values()) / len(dimension_scores)

    return {
        "dimension_scores": dimension_scores,
        "overall_score": round(overall, 1),
        "max_score": 10.0,
        "strongest_dimension": max(dimension_scores, key=dimension_scores.get),
        "weakest_dimension": min(dimension_scores, key=dimension_scores.get),
    }


def generate_positioning_matrix() -> list[dict]:
    """Generate a competitive positioning matrix.

    Compares Zenon vs each competitor across all dimensions.
    """
    competitors = {
        "Stacks": {
            "btc_alignment": 7,
            "smart_contracts": 6,
            "bridge": 3,
            "tokenomics": 5,
            "architecture": 5,
            "user_experience": 5,
            "consensus": 6,
        },
        "THORChain": {
            "btc_alignment": 5,
            "smart_contracts": 3,
            "bridge": 8,
            "tokenomics": 7,
            "architecture": 6,
            "user_experience": 6,
            "consensus": 7,
        },
        "Lightning": {
            "btc_alignment": 10,
            "smart_contracts": 2,
            "bridge": 1,
            "tokenomics": 1,
            "architecture": 7,
            "user_experience": 6,
            "consensus": 8,
        },
        "RSK": {
            "btc_alignment": 6,
            "smart_contracts": 7,
            "bridge": 4,
            "tokenomics": 3,
            "architecture": 4,
            "user_experience": 4,
            "consensus": 5,
        },
        "Liquid": {
            "btc_alignment": 8,
            "smart_contracts": 3,
            "bridge": 5,
            "tokenomics": 2,
            "architecture": 4,
            "user_experience": 3,
            "consensus": 3,
        },
    }

    zenon_scores = score_zenon_positioning()["dimension_scores"]

    matrix = []
    for comp_name, comp_scores in competitors.items():
        advantages = []
        disadvantages = []
        for dim in COMPARISON_DIMENSIONS:
            z_score = zenon_scores.get(dim, 5)
            c_score = comp_scores.get(dim, 5)
            if z_score > c_score + 1:
                advantages.append(dim)
            elif c_score > z_score + 1:
                disadvantages.append(dim)

        matrix.append(
            {
                "competitor": comp_name,
                "zenon_advantages": advantages,
                "zenon_disadvantages": disadvantages,
                "dimension_comparison": {
                    dim: {
                        "zenon": zenon_scores.get(dim, 5),
                        "competitor": comp_scores.get(dim, 5),
                    }
                    for dim in COMPARISON_DIMENSIONS
                },
            }
        )

    return matrix


def persist_positioning(
    scores: dict,
    matrix: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist positioning analysis as evidence."""
    strongest = scores.get("strongest_dimension", "?")
    weakest = scores.get("weakest_dimension", "?")
    all_advantages = set()
    all_disadvantages = set()
    for m in matrix:
        all_advantages.update(m["zenon_advantages"])
        all_disadvantages.update(m["zenon_disadvantages"])

    body = json.dumps(
        {
            "scores": scores,
            "matrix_summary": [
                {
                    "competitor": m["competitor"],
                    "advantages": m["zenon_advantages"],
                    "disadvantages": m["zenon_disadvantages"],
                }
                for m in matrix
            ],
        },
        indent=2,
    )

    title = (
        f"WHAT: Technical positioning score {scores['overall_score']}/10 "
        f"(strongest: {strongest}, weakest: {weakest}). "
        f"SO WHAT: Zenon leads in {', '.join(sorted(all_advantages)) or 'no dimensions'} "
        f"but trails in {', '.join(sorted(all_disadvantages)) or 'no dimensions'} "
        f"vs {len(matrix)} competitors. "
        f"NOW WHAT: Double down on {strongest} in messaging; "
        f"invest in improving {weakest} or reframe it as a deliberate design trade-off."
    )

    row_id = persist_metric(
        db_path=db_path,
        table="evidence",
        data={
            "domain": "product_market_fit",
            "engine": "technical_positioning",
            "finding_type": "analysis",
            "title": title,
            "body": body,
            "confidence": 0.75,
            "source": "internal_analysis",
        },
    )
    return row_id if row_id > 0 else 0


def run_positioning_analysis(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full technical positioning analysis.

    Returns comprehensive positioning status dict.
    """
    scores = score_zenon_positioning()
    matrix = generate_positioning_matrix()
    evidence_id = persist_positioning(scores, matrix, db_path=db_path)

    return {
        "success": True,
        "scores": scores,
        "matrix": matrix,
        "differentiators": DIFFERENTIATORS,
        "evidence_id": evidence_id,
    }
