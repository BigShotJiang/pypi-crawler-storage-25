# SPDX-License-Identifier: MIT
"""
RoadmapPredictor -- Predict next priorities based on spec progression and signals.

Analyzes the current state of specs, community signals, competitive pressure,
and technical dependencies to predict what the Zenon ecosystem should
prioritize next.
"""

import json
import logging
import sqlite3
from pathlib import Path

from core.persist_to_db import persist_metric
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

# Priority categories
PRIORITY_CATEGORIES = [
    "bridge_btc",
    "embedded_contracts",
    "sdk_tooling",
    "wallet_ux",
    "governance",
    "documentation",
    "testing_qa",
    "infrastructure",
]

# Weight factors for prioritization
WEIGHT_SPEC_READINESS = 0.30
WEIGHT_DEPENDENCY_UNBLOCKED = 0.25
WEIGHT_COMPETITIVE_PRESSURE = 0.20
WEIGHT_COMMUNITY_DEMAND = 0.15
WEIGHT_SECURITY_URGENCY = 0.10


def scan_spec_readiness() -> list[dict]:
    """Scan specs to determine which are closest to next milestone.

    Returns list of specs with readiness scores.
    """
    spec_paths = [
        ZENON_WORKSPACE / "core" / "developer-commons",
        ZENON_WORKSPACE / "hypercore-one" / "developer-commons",
    ]

    specs = []
    for spec_root in spec_paths:
        if not spec_root.is_dir():
            continue
        for md_file in spec_root.rglob("*.md"):
            info = _analyze_spec_for_priority(md_file)
            if info:
                specs.append(info)

    return specs


def _analyze_spec_for_priority(path: Path) -> dict | None:
    """Analyze a spec file for prioritization signals."""
    try:
        content = path.read_text(encoding="utf-8")[:3000]
    except (OSError, UnicodeDecodeError):
        return None

    if len(content) < 100:
        return None

    name = path.stem
    content_lower = content.lower()

    # Detect category
    category = "embedded_contracts"  # default
    if any(kw in content_lower for kw in ["bridge", "btc", "bitcoin", "wrap"]):
        category = "bridge_btc"
    elif any(kw in content_lower for kw in ["sdk", "dart", "typescript", "api"]):
        category = "sdk_tooling"
    elif any(kw in content_lower for kw in ["wallet", "syrius", "ui", "ux"]):
        category = "wallet_ux"
    elif any(kw in content_lower for kw in ["governance", "accelerator", "vote"]):
        category = "governance"
    elif any(kw in content_lower for kw in ["doc", "wiki", "tutorial"]):
        category = "documentation"
    elif any(kw in content_lower for kw in ["test", "devnet", "ci", "cd"]):
        category = "testing_qa"

    # Readiness score based on content completeness
    readiness = 0.3  # default
    if any(kw in content_lower for kw in ["implementation", "implemented"]):
        readiness = 0.7
    elif any(kw in content_lower for kw in ["reviewed", "approved"]):
        readiness = 0.6
    elif any(kw in content_lower for kw in ["draft", "wip", "work in progress"]):
        readiness = 0.2

    # Check for dependency mentions
    has_dependencies = any(
        kw in content_lower for kw in ["depends on", "requires", "prerequisite", "blocked by"]
    )

    return {
        "spec_name": name,
        "category": category,
        "readiness_score": readiness,
        "has_dependencies": has_dependencies,
        "path": str(path),
    }


def assess_competitive_pressure(*, db_path: str = DEFAULT_DB) -> dict:
    """Assess which categories face competitive pressure.

    Reads from competitive_landscape table.
    """
    pressure = dict.fromkeys(PRIORITY_CATEGORIES, 0.0)

    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT * FROM competitive_landscape
               WHERE id IN (
                   SELECT MAX(id) FROM competitive_landscape
                   GROUP BY project_name
               )"""
        ).fetchall()

        for row in rows:
            threat = row["threat_level"]
            features = (row["unique_features"] or "").lower()
            multiplier = {"critical": 1.0, "high": 0.7, "medium": 0.4, "low": 0.1}.get(threat, 0.1)

            if "bridge" in features or "btc" in features:
                pressure["bridge_btc"] += multiplier
            if "smart contract" in features or "evm" in features:
                pressure["embedded_contracts"] += multiplier
            if "swap" in features or "dex" in features:
                pressure["sdk_tooling"] += multiplier

    except sqlite3.OperationalError:
        pass  # Table may not exist yet
    finally:
        conn.close()

    return pressure


def generate_priority_ranking(
    specs: list[dict],
    competitive_pressure: dict,
) -> list[dict]:
    """Generate a ranked list of priorities.

    Combines spec readiness, competitive pressure, and other signals.
    """
    # Aggregate by category
    category_scores = dict.fromkeys(PRIORITY_CATEGORIES, 0.0)
    category_specs = {cat: [] for cat in PRIORITY_CATEGORIES}

    for spec in specs:
        cat = spec["category"]
        if cat not in category_scores:
            continue

        # Readiness contribution
        readiness_contrib = spec["readiness_score"] * WEIGHT_SPEC_READINESS

        # Dependency status (unblocked specs score higher)
        dep_contrib = (0.0 if spec["has_dependencies"] else 1.0) * WEIGHT_DEPENDENCY_UNBLOCKED

        spec_score = readiness_contrib + dep_contrib
        category_scores[cat] += spec_score
        category_specs[cat].append(spec["spec_name"])

    # Add competitive pressure
    for cat, pressure in competitive_pressure.items():
        if cat in category_scores:
            category_scores[cat] += pressure * WEIGHT_COMPETITIVE_PRESSURE

    # Normalize and rank
    max_score = max(category_scores.values()) if category_scores else 1
    if max_score == 0:
        max_score = 1

    rankings = []
    for cat in sorted(category_scores, key=category_scores.get, reverse=True):
        rankings.append(
            {
                "category": cat,
                "score": round(category_scores[cat], 3),
                "normalized_score": round(category_scores[cat] / max_score * 100, 1),
                "related_specs": category_specs.get(cat, [])[:5],
            }
        )

    return rankings


def persist_predictions(
    rankings: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist roadmap predictions as evidence."""
    top_3 = [r["category"] for r in rankings[:3]]
    top_3_with_scores = ", ".join(
        f"{r['category']} ({r['normalized_score']}%)" for r in rankings[:3]
    )
    bottom = rankings[-1] if rankings else None
    bottom_text = f"{bottom['category']} ({bottom['normalized_score']}%)" if bottom else "N/A"
    title = (
        f"WHAT: Top priorities: {top_3_with_scores}. "
        f"SO WHAT: These categories have the strongest combination of spec readiness, "
        f"unblocked dependencies, and competitive pressure — lowest priority is {bottom_text}. "
        f"NOW WHAT: Focus next development sprint on {top_3[0]} specs; "
        f"review {top_3[1]} and {top_3[2]} for parallel work opportunities."
    )
    row_id = persist_metric(
        db_path=db_path,
        table="evidence",
        data={
            "domain": "product_market_fit",
            "engine": "roadmap_predictor",
            "finding_type": "prediction",
            "title": title,
            "body": json.dumps(rankings, indent=2),
            "confidence": 0.6,
            "source": "spec_analysis+competitive",
        },
    )
    return row_id if row_id > 0 else 0


def run_roadmap_prediction(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full roadmap prediction analysis.

    Returns ranked priorities with justifications.
    """
    specs = scan_spec_readiness()
    pressure = assess_competitive_pressure(db_path=db_path)
    rankings = generate_priority_ranking(specs, pressure)
    evidence_id = persist_predictions(rankings, db_path=db_path)

    return {
        "success": True,
        "specs_analyzed": len(specs),
        "rankings": rankings,
        "competitive_pressure": pressure,
        "evidence_id": evidence_id,
    }
