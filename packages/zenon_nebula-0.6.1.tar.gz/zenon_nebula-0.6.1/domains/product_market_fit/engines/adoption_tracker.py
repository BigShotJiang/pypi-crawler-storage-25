# SPDX-License-Identifier: MIT
"""
AdoptionTracker -- Track developer adoption, dApp count, and integrations.

Monitors GitHub activity across the Zenon ecosystem, counts dApps and
integrations, and tracks developer growth over time.
"""

import json
import logging
from pathlib import Path
from urllib.error import URLError
from urllib.request import Request

from core.http import opsec_urlopen
from core.persist_to_db import persist_metric, query_table

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

GITHUB_API = "https://api.github.com"

# Zenon GitHub organizations to track
ZENON_ORGS = [
    "zenon-network",
    "hypercore-one",
    "zenon-tools",
    "Big-Staker",
]

# Known dApps and integrations
KNOWN_DAPPS = [
    {"name": "Syrius Wallet", "category": "wallet", "repo": "zenon-network/syrius"},
    {"name": "ZenonHub", "category": "explorer", "repo": None},
    {"name": "Zenon Tools", "category": "analytics", "repo": "zenon-tools/nom-tools"},
    {"name": "Orbital Bridge", "category": "bridge", "repo": None},
    {
        "name": "ZENON CLI (znn-cli-dart)",
        "category": "tooling",
        "repo": "zenon-network/znn-cli-dart",
    },
    {"name": "nomctl", "category": "tooling", "repo": None},
]

KNOWN_INTEGRATIONS = [
    {"name": "Uniswap wZNN", "category": "dex", "platform": "ethereum"},
    {"name": "WalletConnect", "category": "wallet_connect", "platform": "multi"},
]


def _api_get(url: str, timeout: int = 15) -> dict | None:
    """Make a GET request and return parsed JSON, or None on failure."""
    try:
        headers = {
            "User-Agent": "ZenonForge/1.0",
            "Accept": "application/vnd.github.v3+json",
        }
        req = Request(url, headers=headers)
        with opsec_urlopen(req, timeout=timeout) as resp:
            data = resp.read().decode("utf-8")
            return json.loads(data)
    except (URLError, json.JSONDecodeError, OSError) as exc:
        logger.warning("API request failed for %s: %s", url, exc)
        return None


def fetch_org_metrics(org: str) -> dict:
    """Fetch metrics for a GitHub organization.

    Returns dict with repos, stars, contributors.
    """
    org_data = _api_get(f"{GITHUB_API}/orgs/{org}")
    public_repos = 0
    if org_data:
        public_repos = org_data.get("public_repos", 0)

    # Get repos for star counting
    repos_data = _api_get(f"{GITHUB_API}/orgs/{org}/repos?per_page=100&sort=stars")
    total_stars = 0
    active_repos = 0
    if repos_data and isinstance(repos_data, list):
        for repo in repos_data:
            total_stars += repo.get("stargazers_count", 0)
            # Active = pushed within 90 days
            if repo.get("pushed_at"):
                active_repos += 1

    return {
        "org": org,
        "public_repos": public_repos,
        "total_stars": total_stars,
        "active_repos": active_repos,
    }


def count_unique_contributors(orgs: list[str]) -> int:
    """Estimate unique contributors across all Zenon orgs.

    Fetches contributor lists from top repos and deduplicates.
    """
    all_contributors = set()

    for org in orgs:
        repos_data = _api_get(f"{GITHUB_API}/orgs/{org}/repos?per_page=10&sort=pushed")
        if not repos_data or not isinstance(repos_data, list):
            continue

        for repo in repos_data[:5]:  # Top 5 most recently pushed
            repo_name = repo.get("full_name", "")
            if not repo_name:
                continue

            contribs = _api_get(f"{GITHUB_API}/repos/{repo_name}/contributors?per_page=100")
            if contribs and isinstance(contribs, list):
                for c in contribs:
                    login = c.get("login", "")
                    if login and not login.endswith("[bot]"):
                        all_contributors.add(login)

    return len(all_contributors)


def count_dapps_and_integrations() -> dict:
    """Count known dApps and integrations.

    Also attempts to discover new ones from GitHub topics.
    """
    # Start with known dApps
    dapp_count = len(KNOWN_DAPPS)
    integration_count = len(KNOWN_INTEGRATIONS)

    # Try to discover more via GitHub topic search
    topic_data = _api_get(f"{GITHUB_API}/search/repositories?q=topic:zenon&per_page=100")
    discovered_repos = 0
    if topic_data and "items" in topic_data:
        discovered_repos = len(topic_data["items"])
        # Count repos that look like dApps (not forks of core)
        for repo in topic_data["items"]:
            if not repo.get("fork", False) and repo.get("stargazers_count", 0) > 0:
                name = repo.get("full_name", "")
                # Check if not already in known list
                known_names = [d.get("repo", "") for d in KNOWN_DAPPS]
                if name not in known_names:
                    dapp_count += 1

    return {
        "dapp_count": dapp_count,
        "integration_count": integration_count,
        "discovered_repos": discovered_repos,
        "known_dapps": [d["name"] for d in KNOWN_DAPPS],
        "known_integrations": [i["name"] for i in KNOWN_INTEGRATIONS],
    }


def persist_adoption_metrics(
    metrics: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist adoption metrics to the database."""
    persisted = 0
    for key, value in metrics.items():
        if isinstance(value, (int, float)):
            rid = persist_metric(
                db_path=db_path,
                table="adoption_metrics",
                data={
                    "metric_name": key,
                    "metric_value": float(value),
                    "metric_category": "adoption",
                    "source": "github",
                },
            )
            if rid > 0:
                persisted += 1
    return persisted


def get_adoption_history(
    *,
    db_path: str = DEFAULT_DB,
    metric_name: str | None = None,
    limit: int = 30,
) -> list[dict]:
    """Get recent adoption metric snapshots."""
    if metric_name:
        return query_table(
            db_path=db_path,
            table="adoption_metrics",
            where="metric_name = ?",
            params=(metric_name,),
            order_by="timestamp DESC",
            limit=limit,
        )
    return query_table(
        db_path=db_path,
        table="adoption_metrics",
        order_by="timestamp DESC",
        limit=limit,
    )


def detect_adoption_trend(*, db_path: str = DEFAULT_DB) -> dict:
    """Detect overall adoption trend from metrics history."""
    key_metrics = ["total_stars", "unique_contributors", "dapp_count"]
    trends = {}

    for metric in key_metrics:
        history = get_adoption_history(db_path=db_path, metric_name=metric, limit=10)
        if len(history) < 2:
            trends[metric] = "insufficient_data"
            continue

        values = [h["metric_value"] for h in reversed(history)]
        if values[-1] > values[0] * 1.05:
            trends[metric] = "growing"
        elif values[-1] < values[0] * 0.95:
            trends[metric] = "declining"
        else:
            trends[metric] = "stable"

    return trends


def run_adoption_tracking(*, db_path: str = DEFAULT_DB) -> dict:
    """Run full adoption tracking: fetch metrics, count dApps, persist.

    Returns comprehensive adoption status dict.
    """
    # Fetch org-level metrics
    org_results = []
    total_stars = 0
    total_repos = 0
    total_active = 0

    for org in ZENON_ORGS:
        metrics = fetch_org_metrics(org)
        org_results.append(metrics)
        total_stars += metrics["total_stars"]
        total_repos += metrics["public_repos"]
        total_active += metrics["active_repos"]

    # Count contributors
    contributor_count = count_unique_contributors(ZENON_ORGS)

    # Count dApps and integrations
    dapps = count_dapps_and_integrations()

    # Flatten metrics for persistence
    flat_metrics = {
        "total_stars": total_stars,
        "total_repos": total_repos,
        "active_repos": total_active,
        "unique_contributors": contributor_count,
        "dapp_count": dapps["dapp_count"],
        "integration_count": dapps["integration_count"],
    }

    persisted = persist_adoption_metrics(flat_metrics, db_path=db_path)
    trends = detect_adoption_trend(db_path=db_path)

    return {
        "success": True,
        "orgs_tracked": len(ZENON_ORGS),
        "org_metrics": org_results,
        "total_stars": total_stars,
        "total_repos": total_repos,
        "active_repos": total_active,
        "unique_contributors": contributor_count,
        "dapps": dapps,
        "trends": trends,
        "metrics_persisted": persisted,
    }
