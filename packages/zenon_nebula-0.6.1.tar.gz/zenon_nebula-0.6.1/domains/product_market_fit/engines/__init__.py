# SPDX-License-Identifier: MIT
"""PMF domain engines -- competitive scanner, technical positioning, roadmap, adoption, product surface.

Also includes:
    prediction_engine   -- Strategic trajectory predictions from evidence + LLM
    future_detector     -- Scan for BIPs, competitor launches, ecosystem shifts
    comparative_engine  -- Cross-project pattern matching against Bitcoin/Monero/Grin
    product_surface     -- Map user-facing products and identify coverage gaps
    fork_detector       -- Scan workspace for non-Zenon repos adaptable for Zenon
"""
