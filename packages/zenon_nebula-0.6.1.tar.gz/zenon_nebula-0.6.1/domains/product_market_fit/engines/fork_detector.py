# SPDX-License-Identifier: MIT
"""
ForkDetector -- Find repos in adjacent ecosystems adaptable for Zenon.

Scans all repos in the workspace that are NOT Zenon-specific and classifies
them by category (explorer, wallet, DEX, bridge, tool). Estimates adaptation
effort by counting files with chain-specific constants.

No LLM calls. File scanning only.
"""

import logging
import os
import re
import subprocess
from collections import Counter
from pathlib import Path

from core.config import get_config
from core.persist_to_db import ensure_schema, persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# Top-level directories to scan
SCAN_DIRS = [
    "core",
    "zenon-network",
    "hypercore-one",
    "HyperCore-Team",
    "community-sdks",
    "infrastructure",
    "knowledge",
    "zenon-org",
    "sol-znn",
    "digitalSloth",
    "georgezgeorgez",
    "zenonhub-io",
    "DexterLabZ",
    "MoonBaZZe",
    "millerships",
    "coordination",
    "investigation",
]

# Patterns that indicate a Zenon-native repo (skip these)
ZENON_INDICATORS = re.compile(
    r"(zenon|znn|znnd|syrius|pillar|sentinel|plasma|momentum|qsr)",
    re.IGNORECASE,
)

# Category detection patterns
CATEGORY_PATTERNS = {
    "explorer": [
        re.compile(r"(explorer|block.*scan|block.*view|chain.*view)", re.IGNORECASE),
        re.compile(r"(getBlock|getTransaction|/api/v\d+/block)", re.IGNORECASE),
    ],
    "wallet": [
        re.compile(r"(wallet|keystore|mnemonic|bip39|bip44|seed.*phrase)", re.IGNORECASE),
        re.compile(r"(signTransaction|sendTransaction|getBalance)", re.IGNORECASE),
    ],
    "dex": [
        re.compile(r"(dex|swap|liquidity|amm|order.*book|trading.*pair)", re.IGNORECASE),
        re.compile(r"(addLiquidity|removeLiquidity|swap.*exact)", re.IGNORECASE),
    ],
    "bridge": [
        re.compile(r"(bridge|relay|cross.*chain|interop|wrapped)", re.IGNORECASE),
        re.compile(r"(lockAndMint|burnAndRelease|relayer)", re.IGNORECASE),
    ],
    "tool": [
        re.compile(r"(cli|tool|util|monitor|dashboard|faucet|indexer)", re.IGNORECASE),
    ],
    "sdk": [
        re.compile(r"(sdk|client.*lib|api.*client|rpc.*client)", re.IGNORECASE),
    ],
}

# Chain-specific constants that would need replacing
CHAIN_SPECIFIC_PATTERNS = [
    # Ethereum / EVM
    re.compile(r"0x[0-9a-fA-F]{40}"),  # ETH addresses
    re.compile(r"chain[_\s]*[Ii]d\s*[:=]\s*\d+"),  # Chain IDs
    re.compile(r"(etherscan|infura|alchemy|metamask)", re.IGNORECASE),
    # Cosmos
    re.compile(r"(cosmos1[a-z0-9]{38}|osmo1[a-z0-9]{38})", re.IGNORECASE),
    re.compile(r"(cosmoshub|osmosis|tendermint)", re.IGNORECASE),
    # Bitcoin
    re.compile(r"(bc1[a-z0-9]{25,}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})", re.IGNORECASE),
    re.compile(r"(blockstream|mempool\.space)", re.IGNORECASE),
    # Solana
    re.compile(r"(solana|phantom|anchor|metaplex)", re.IGNORECASE),
    # Polkadot
    re.compile(r"(polkadot|substrate|kusama|parachain)", re.IGNORECASE),
    # Generic RPC
    re.compile(r"(rpc.*url|api.*endpoint|node.*url|provider.*url)", re.IGNORECASE),
]

# File extensions to scan for chain-specific references
SCANNABLE_EXTENSIONS = frozenset(
    {
        ".go",
        ".dart",
        ".js",
        ".ts",
        ".tsx",
        ".jsx",
        ".py",
        ".rs",
        ".java",
        ".kt",
        ".swift",
        ".json",
        ".yaml",
        ".yml",
        ".toml",
        ".env.example",
        ".config",
    }
)

# Max file size to scan (skip large generated files).
# Sourced from config/engine_defaults.json with a safe fallback.
MAX_FILE_SIZE = get_config().engine("fork_detector").get("max_file_size", 500_000)


def _is_zenon_repo(repo_path: Path, repo_name: str) -> bool:
    """Check if a repo is Zenon-native (should be skipped).

    Checks repo name and remote URLs for Zenon indicators.
    """
    # Check name
    if ZENON_INDICATORS.search(repo_name):
        return True

    # Check remote URLs
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_path), "remote", "-v"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0 and ZENON_INDICATORS.search(result.stdout):
            return True
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return False


def _classify_repo(repo_path: Path) -> list[str]:
    """Classify a repo into categories based on file contents and structure.

    Returns list of matching category names.
    """
    categories = []

    # Check directory names and file names for category signals
    try:
        all_names = []
        for item in repo_path.rglob("*"):
            if item.is_file() and not any(
                p in str(item)
                for p in [
                    "node_modules",
                    ".git",
                    "__pycache__",
                    "vendor",
                    "build",
                    "dist",
                ]
            ):
                all_names.append(item.name)
            # Limit scan depth
            if len(all_names) > 500:
                break

        name_text = " ".join(all_names)

        for category, patterns in CATEGORY_PATTERNS.items():
            for pattern in patterns:
                if pattern.search(name_text):
                    categories.append(category)
                    break

    except PermissionError:
        pass

    # Also check README for category hints
    for readme_name in ["README.md", "readme.md"]:
        readme_path = repo_path / readme_name
        if readme_path.is_file():
            try:
                text = readme_path.read_text(
                    encoding="utf-8",
                    errors="replace",
                )[:50000]
                for category, patterns in CATEGORY_PATTERNS.items():
                    if category not in categories:
                        for pattern in patterns:
                            if pattern.search(text):
                                categories.append(category)
                                break
            except OSError:
                pass
            break

    return list(set(categories))


def _count_chain_specific_files(repo_path: Path) -> dict:
    """Count files that contain chain-specific constants.

    Returns dict with: total_files, chain_specific_files, chain_refs_count,
    files_needing_change (list of paths).
    """
    total_files = 0
    chain_files = 0
    chain_refs = 0
    files_needing_change = []

    try:
        for filepath in repo_path.rglob("*"):
            # Skip non-files and excluded directories
            if not filepath.is_file():
                continue
            rel = filepath.relative_to(repo_path)
            rel_str = str(rel)
            if any(
                skip in rel_str
                for skip in [
                    "node_modules",
                    ".git",
                    "__pycache__",
                    "vendor",
                    "build",
                    "dist",
                    ".next",
                    ".cache",
                ]
            ):
                continue

            # Check extension
            if filepath.suffix not in SCANNABLE_EXTENSIONS:
                continue

            # Skip large files
            try:
                if filepath.stat().st_size > MAX_FILE_SIZE:
                    continue
            except OSError:
                continue

            total_files += 1

            try:
                content = filepath.read_text(
                    encoding="utf-8",
                    errors="replace",
                )
            except OSError:
                continue

            file_refs = 0
            for pattern in CHAIN_SPECIFIC_PATTERNS:
                matches = pattern.findall(content)
                file_refs += len(matches)

            if file_refs > 0:
                chain_files += 1
                chain_refs += file_refs
                files_needing_change.append(
                    {
                        "file": rel_str,
                        "references": file_refs,
                    }
                )

    except PermissionError:
        pass

    # Sort by reference count descending
    files_needing_change.sort(key=lambda f: -f["references"])

    return {
        "total_files": total_files,
        "chain_specific_files": chain_files,
        "chain_refs_count": chain_refs,
        "files_needing_change": files_needing_change[:20],  # Top 20
    }


def _estimate_effort(
    total_files: int,
    chain_specific_files: int,
) -> str:
    """Estimate adaptation effort based on file counts."""
    if chain_specific_files == 0:
        return "TRIVIAL"
    ratio = chain_specific_files / max(total_files, 1)
    if chain_specific_files <= 5 or ratio < 0.05:
        return "LOW"
    if chain_specific_files <= 20 or ratio < 0.15:
        return "MEDIUM"
    if chain_specific_files <= 50 or ratio < 0.30:
        return "HIGH"
    return "VERY_HIGH"


def _find_repos() -> list[tuple[str, str, Path]]:
    """Find all git repos in the workspace.

    Returns list of (org_dir, repo_name, full_path) tuples.
    """
    repos = []
    for scan_dir in SCAN_DIRS:
        parent = ZENON_WORKSPACE / scan_dir
        if not parent.is_dir():
            continue
        for child in sorted(parent.iterdir()):
            if child.is_dir() and (child / ".git").exists():
                repos.append((scan_dir, child.name, child))
    return repos


def scan_forkable_repos() -> list[dict]:
    """Scan workspace for non-Zenon repos that could be adapted.

    Returns list of dicts per forkable repo with category, effort, and details.
    """
    repos = _find_repos()
    forkable = []

    for org_dir, repo_name, repo_path in repos:
        # Skip Zenon-native repos
        if _is_zenon_repo(repo_path, repo_name):
            continue

        # Classify
        categories = _classify_repo(repo_path)
        if not categories:
            continue  # Not an interesting category

        # Count chain-specific files
        chain_info = _count_chain_specific_files(repo_path)
        if chain_info["total_files"] == 0:
            continue  # Empty or unreadable repo

        effort = _estimate_effort(
            chain_info["total_files"],
            chain_info["chain_specific_files"],
        )

        # Determine primary language
        ext_counter = Counter()
        try:
            for f in repo_path.rglob("*"):
                if f.is_file() and f.suffix in SCANNABLE_EXTENSIONS:
                    ext_counter[f.suffix] += 1
                if sum(ext_counter.values()) > 200:
                    break
        except PermissionError:
            pass

        ext_to_lang = {
            ".go": "Go",
            ".dart": "Dart",
            ".js": "JavaScript",
            ".ts": "TypeScript",
            ".py": "Python",
            ".rs": "Rust",
            ".java": "Java",
        }
        primary_lang = "Unknown"
        for ext, _ in ext_counter.most_common(3):
            if ext in ext_to_lang:
                primary_lang = ext_to_lang[ext]
                break

        forkable.append(
            {
                "org_dir": org_dir,
                "repo_name": repo_name,
                "repo_key": f"{org_dir}/{repo_name}",
                "categories": categories,
                "primary_language": primary_lang,
                "total_files": chain_info["total_files"],
                "chain_specific_files": chain_info["chain_specific_files"],
                "chain_refs_count": chain_info["chain_refs_count"],
                "effort": effort,
                "files_needing_change": chain_info["files_needing_change"],
            }
        )

    # Sort by effort (easiest first)
    effort_order = {
        "TRIVIAL": 0,
        "LOW": 1,
        "MEDIUM": 2,
        "HIGH": 3,
        "VERY_HIGH": 4,
    }
    forkable.sort(key=lambda r: effort_order.get(r["effort"], 5))

    return forkable


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run fork detection and persist findings to evidence table.

    Returns the number of findings persisted.
    """
    ensure_schema(db_path)
    forkable = scan_forkable_repos()
    count = 0

    if not forkable:
        persist_finding(
            db_path=db_path,
            domain="product_market_fit",
            engine="fork_detector",
            evidence_type="fork_scan_result",
            finding=(
                "WHAT: Scanned workspace for non-Zenon repos adaptable as "
                "Zenon tooling. SO WHAT: No suitable candidates found in "
                "current workspace. NOW WHAT: Consider adding repos from "
                "adjacent ecosystems (Cosmos explorers, Bitcoin wallets, etc.) "
                "to the workspace for future scanning."
            ),
            confidence=0.70,
            raw_data={"candidates_found": 0},
            source_repo="workspace",
        )
        return 1

    # Summary finding
    by_effort = Counter(r["effort"] for r in forkable)
    by_category = Counter(cat for r in forkable for cat in r["categories"])
    persist_finding(
        db_path=db_path,
        domain="product_market_fit",
        engine="fork_detector",
        evidence_type="fork_scan_summary",
        finding=(
            f"WHAT: Found {len(forkable)} non-Zenon repos in workspace "
            f"that could be adapted. Categories: "
            f"{', '.join(f'{cat}={n}' for cat, n in by_category.most_common())}. "
            f"Effort distribution: "
            f"{', '.join(f'{eff}={n}' for eff, n in by_effort.most_common())}. "
            f"SO WHAT: These are potential building blocks for Zenon "
            f"infrastructure without building from scratch. "
            f"NOW WHAT: Prioritize LOW/MEDIUM effort repos in categories "
            f"where Zenon currently has gaps (explorer, wallet, DEX)."
        ),
        confidence=0.80,
        raw_data={
            "total_candidates": len(forkable),
            "by_effort": dict(by_effort),
            "by_category": dict(by_category),
        },
        source_repo="workspace",
    )
    count += 1

    # Per-repo findings (top 10 most promising)
    for repo in forkable[:10]:
        top_files = ", ".join(f["file"] for f in repo["files_needing_change"][:3])
        persist_finding(
            db_path=db_path,
            domain="product_market_fit",
            engine="fork_detector",
            evidence_type="fork_candidate",
            finding=(
                f"WHAT: {repo['repo_key']} is a {'/'.join(repo['categories'])} "
                f"({repo['primary_language']}) with {repo['total_files']} files, "
                f"{repo['chain_specific_files']} reference chain-specific "
                f"constants. "
                f"SO WHAT: Could be adapted for Zenon by changing "
                f"{repo['chain_specific_files']} files. "
                f"Estimated effort: {repo['effort']}. "
                f"{'Key files: ' + top_files + '. ' if top_files else ''}"
                f"NOW WHAT: Fork to ZenonOrg, create feature branch, "
                f"replace chain-specific constants with Zenon equivalents."
            ),
            confidence=0.75,
            raw_data=repo,
            source_repo=repo["repo_key"],
        )
        count += 1

    logger.info(
        "ForkDetector: persisted %d findings from %d candidates.",
        count,
        len(forkable),
    )
    return count
