# SPDX-License-Identifier: MIT
"""
EcosystemGap -- Compare Zenon's ecosystem against top L1 checklists.

Defines a standard checklist of ecosystem components every successful L1
needs, then checks Zenon's workspace repos and known projects to determine
which exist, which are incomplete, and which are entirely missing.
Prioritizes gaps by estimated effort and user impact.

No LLM required -- checklist-based filesystem and data scan.
"""

import logging
from pathlib import Path

from core.persist_to_db import ensure_schema, persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()


# ---------- ecosystem checklist ----------

# Each component: id, label, description, effort (S/M/L), impact (low/med/high),
# and a list of (repo_subpath, indicator_files) tuples to check.
# If any indicator file exists, the component is at least partially present.

ECOSYSTEM_CHECKLIST: list[dict] = [
    {
        "id": "native_dex",
        "label": "Native DEX",
        "description": "Decentralized exchange running on Zenon (not wrapped on Ethereum).",
        "effort": "L",
        "impact": "high",
        "checks": [
            ("infrastructure/zenonhub", ["*dex*", "*swap*", "*amm*"]),
            ("core/go-zenon/vm/embedded", ["*swap*", "*liquidity*", "*dex*"]),
        ],
        "known_projects": [],
    },
    {
        "id": "lending_protocol",
        "label": "Lending / Borrowing Protocol",
        "description": "On-chain lending and borrowing (Aave/Compound equivalent).",
        "effort": "L",
        "impact": "high",
        "checks": [
            ("core/go-zenon/vm/embedded", ["*lend*", "*borrow*"]),
        ],
        "known_projects": [],
    },
    {
        "id": "stablecoin",
        "label": "Stablecoin (native or bridged)",
        "description": "USD-pegged stablecoin available on-chain (native mint or bridge).",
        "effort": "M",
        "impact": "high",
        "checks": [
            ("core/go-zenon", ["*stable*", "*usd*"]),
            ("HyperCore-Team", ["*bridge*"]),
        ],
        "known_projects": ["wZNN bridge exists but no stablecoin bridged yet"],
    },
    {
        "id": "nft_marketplace",
        "label": "NFT Marketplace",
        "description": "Platform for minting and trading NFTs on Zenon.",
        "effort": "M",
        "impact": "low",
        "checks": [
            ("infrastructure", ["*nft*"]),
            ("core/go-zenon/vm/embedded", ["*nft*"]),
        ],
        "known_projects": [],
    },
    {
        "id": "block_explorer",
        "label": "Block Explorer (full-featured)",
        "description": "Full-featured block explorer with contract interaction, token tracking, rich search.",
        "effort": "M",
        "impact": "high",
        "checks": [
            ("infrastructure/zenonhub", []),
            ("zenonhub-io", []),
            ("zenon-network/zenon.info", []),
        ],
        "known_projects": ["zenonhub.io (active)", "zenon.info"],
    },
    {
        "id": "mobile_wallet",
        "label": "Mobile Wallet",
        "description": "Native mobile wallet for iOS and Android.",
        "effort": "M",
        "impact": "high",
        "checks": [
            ("core/syrius", ["android", "ios", "mobile"]),
            ("community-sdks", ["*mobile*", "*flutter*"]),
        ],
        "known_projects": ["Syrius (desktop + mobile via Flutter)"],
    },
    {
        "id": "hardware_wallet",
        "label": "Hardware Wallet Support (Ledger/Trezor)",
        "description": "Integration with Ledger and/or Trezor hardware wallets.",
        "effort": "M",
        "impact": "med",
        "checks": [
            ("core", ["*ledger*", "*trezor*", "*hardware*"]),
            ("community-sdks", ["*ledger*"]),
            ("HyperCore-Team", ["*ledger*"]),
        ],
        "known_projects": [],
    },
    {
        "id": "sdk_3_languages",
        "label": "SDK in 3+ Languages",
        "description": "Official or community SDKs in at least 3 programming languages.",
        "effort": "S",
        "impact": "med",
        "checks": [
            ("community-sdks", []),
            ("core/znn_sdk_dart", []),
        ],
        "known_projects": [
            "Dart (official)",
            "Go (community)",
            "TypeScript (community)",
            "PHP (community)",
            "Python (community)",
            "Rust (community)",
            "Java (community)",
        ],
    },
    {
        "id": "bridge_2_chains",
        "label": "Bridge to 2+ Chains",
        "description": "Cross-chain bridge connecting Zenon to at least 2 other networks.",
        "effort": "L",
        "impact": "high",
        "checks": [
            ("HyperCore-Team", ["*bridge*"]),
            ("core/go-zenon/vm/embedded", ["*portal*", "*bridge*", "*bitcoin_spv*"]),
        ],
        "known_projects": [
            "Ethereum bridge (wZNN/wQSR)",
            "Bitcoin bridge (Portal spec, in development)",
        ],
    },
    {
        "id": "fiat_onramp",
        "label": "Fiat On-Ramp",
        "description": "Direct fiat-to-ZNN purchase (Moonpay, Transak, or exchange listing).",
        "effort": "M",
        "impact": "high",
        "checks": [],
        "known_projects": ["CEX listings (limited)"],
    },
    {
        "id": "developer_grants",
        "label": "Developer Grants Program",
        "description": "Formal grant program for ecosystem development (Accelerator-Z).",
        "effort": "S",
        "impact": "med",
        "checks": [
            ("core/go-zenon/vm/embedded", ["*accelerator*"]),
        ],
        "known_projects": ["Accelerator-Z (on-chain, active)"],
    },
    {
        "id": "testnet_faucet",
        "label": "Testnet with Faucet",
        "description": "Public testnet with a token faucet for developers to test.",
        "effort": "S",
        "impact": "med",
        "checks": [
            ("infrastructure", ["*faucet*", "*testnet*"]),
        ],
        "known_projects": [],
    },
    {
        "id": "documentation_site",
        "label": "Documentation Site",
        "description": "Comprehensive developer documentation website.",
        "effort": "S",
        "impact": "med",
        "checks": [
            ("knowledge/wiki", []),
            ("knowledge/developer-commons", []),
            ("infrastructure", ["*docs*"]),
        ],
        "known_projects": ["zenon.wiki", "developer-commons"],
    },
    {
        "id": "active_community",
        "label": "Active Discord / Telegram",
        "description": "Active community channels with developer support.",
        "effort": "S",
        "impact": "med",
        "checks": [],
        "known_projects": ["Telegram (active)", "Discord (active)"],
    },
    {
        "id": "defi_aggregator",
        "label": "DeFi Aggregator Integration",
        "description": "Listed on DeFi aggregators (DefiLlama, DappRadar, etc.).",
        "effort": "S",
        "impact": "low",
        "checks": [],
        "known_projects": [],
    },
]


# ---------- status detection ----------


def _dir_exists(subpath: str) -> bool:
    """Check if a directory exists relative to the workspace."""
    return (ZENON_WORKSPACE / subpath).is_dir()


def _glob_match(base_dir: Path, patterns: list[str]) -> list[str]:
    """Search for files matching glob patterns, return found paths."""
    found: list[str] = []
    if not base_dir.is_dir():
        return found
    for pattern in patterns:
        for match in base_dir.rglob(pattern):
            found.append(str(match.relative_to(ZENON_WORKSPACE)))
    return found


def assess_component(component: dict) -> dict:
    """Assess the status of a single ecosystem component.

    Returns the component dict augmented with:
        status: 'exists' | 'incomplete' | 'missing'
        evidence: list of found files/projects
        notes: human-readable status description
    """
    evidence: list[str] = []
    known = component.get("known_projects", [])

    # Check filesystem
    for repo_subpath, patterns in component.get("checks", []):
        base = ZENON_WORKSPACE / repo_subpath
        if base.is_dir():
            if not patterns:
                # Directory existence is enough
                evidence.append(f"repo:{repo_subpath}")
            else:
                matches = _glob_match(base, patterns)
                evidence.extend(matches[:5])

    # Determine status
    has_evidence = len(evidence) > 0
    has_known = len(known) > 0

    if has_evidence and has_known:
        status = "exists"
        notes = f"Found in workspace and known: {', '.join(known[:2])}."
    elif has_evidence:
        status = "incomplete"
        notes = f"Found in workspace ({len(evidence)} matches) but no confirmed live project."
    elif has_known:
        # Known projects exist but no repo evidence
        status = (
            "exists"
            if any("active" in k.lower() or "official" in k.lower() for k in known)
            else "incomplete"
        )
        notes = f"Known: {', '.join(known[:2])}."
    else:
        status = "missing"
        notes = "No workspace repos or known projects found."

    return {
        **component,
        "status": status,
        "evidence": evidence,
        "notes": notes,
    }


def assess_all_components() -> list[dict]:
    """Assess all ecosystem components and return results."""
    results = []
    for component in ECOSYSTEM_CHECKLIST:
        assessed = assess_component(component)
        results.append(assessed)
    return results


# ---------- prioritization ----------


_EFFORT_RANK = {"S": 1, "M": 2, "L": 3}
_IMPACT_RANK = {"low": 1, "med": 2, "high": 3}


def prioritize_gaps(assessed: list[dict]) -> list[dict]:
    """Filter to missing/incomplete items and sort by impact desc, effort asc.

    Returns the prioritized gap list.
    """
    gaps = [a for a in assessed if a["status"] in ("missing", "incomplete")]
    gaps.sort(
        key=lambda g: (
            -_IMPACT_RANK.get(g["impact"], 0),
            _EFFORT_RANK.get(g["effort"], 99),
        ),
    )
    return gaps


# ---------- persistence ----------


def persist_ecosystem_findings(
    assessed: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist ecosystem gap findings to the evidence table.

    Generates one finding per missing/incomplete component, plus a
    summary finding covering the overall ecosystem health.

    Returns number of findings persisted.
    """
    ensure_schema(db_path)
    count = 0

    total = len(assessed)
    exists_count = sum(1 for a in assessed if a["status"] == "exists")
    incomplete_count = sum(1 for a in assessed if a["status"] == "incomplete")
    missing_count = sum(1 for a in assessed if a["status"] == "missing")

    # Summary finding
    coverage_pct = round(exists_count / max(total, 1) * 100, 0)
    round((exists_count + incomplete_count) / max(total, 1) * 100, 0)

    summary = (
        f"WHAT: Zenon ecosystem covers {exists_count}/{total} ({coverage_pct}%) "
        f"standard L1 components fully, {incomplete_count} partially, "
        f"{missing_count} missing entirely. "
        f"SO WHAT: Compared to top-50 L1s, Zenon has gaps that limit user "
        f"onboarding and developer adoption. "
        f"{'Critical gaps: ' + ', '.join(a['label'] for a in assessed if a['status'] == 'missing' and a['impact'] == 'high') + '. ' if any(a['status'] == 'missing' and a['impact'] == 'high' for a in assessed) else ''}"
        f"NOW WHAT: Prioritize high-impact gaps; native DEX and stablecoin "
        f"support are prerequisites for meaningful DeFi activity."
    )
    persist_finding(
        db_path=db_path,
        domain="product_market_fit",
        engine="ecosystem_gap",
        evidence_type="ecosystem_summary",
        finding=summary,
        confidence=0.80,
        raw_data={
            "total_components": total,
            "exists": exists_count,
            "incomplete": incomplete_count,
            "missing": missing_count,
            "coverage_pct": coverage_pct,
        },
        source_repo="workspace_scan",
    )
    count += 1

    # Per-gap findings
    gaps = prioritize_gaps(assessed)
    for gap in gaps:
        effort_label = {"S": "Small", "M": "Medium", "L": "Large"}.get(gap["effort"], gap["effort"])
        impact_label = gap["impact"].capitalize()

        if gap["status"] == "missing":
            so_what = (
                f"Every other top-50 L1 has a {gap['label'].lower()}. "
                f"Its absence makes Zenon less competitive and limits adoption."
            )
        else:
            so_what = (
                f"A {gap['label'].lower()} exists but is incomplete or "
                f"unmaintained, giving users a degraded experience."
            )

        finding = (
            f"WHAT: Zenon {'has no' if gap['status'] == 'missing' else 'has incomplete'} "
            f"{gap['label']} -- {gap['description']} "
            f"Status: {gap['notes']} "
            f"SO WHAT: {so_what} "
            f"NOW WHAT: Evaluate implementation approaches. "
            f"Estimated effort: {effort_label}. Impact: {impact_label}."
        )

        persist_finding(
            db_path=db_path,
            domain="product_market_fit",
            engine="ecosystem_gap",
            evidence_type=f"ecosystem_gap_{gap['id']}",
            finding=finding,
            confidence=0.75,
            raw_data={
                "component_id": gap["id"],
                "status": gap["status"],
                "effort": gap["effort"],
                "impact": gap["impact"],
                "evidence": gap.get("evidence", []),
                "known_projects": gap.get("known_projects", []),
            },
            source_repo="workspace_scan",
        )
        count += 1

    logger.info(
        "EcosystemGap: persisted %d findings (%d gaps + 1 summary)",
        count,
        count - 1,
    )
    return count


# ---------- main entry point ----------


def run_ecosystem_gap_analysis(*, db_path: str = DEFAULT_DB) -> dict:
    """Run the full ecosystem gap analysis pipeline.

    Returns a summary dict with component assessments and gap list.
    """
    assessed = assess_all_components()
    gaps = prioritize_gaps(assessed)
    persisted = persist_ecosystem_findings(assessed, db_path=db_path)

    # Build summary
    status_counts = {"exists": 0, "incomplete": 0, "missing": 0}
    for a in assessed:
        status_counts[a["status"]] = status_counts.get(a["status"], 0) + 1

    high_impact_missing = [
        a["label"] for a in gaps if a["status"] == "missing" and a["impact"] == "high"
    ]

    return {
        "success": True,
        "total_components": len(assessed),
        "status_counts": status_counts,
        "gaps": [
            {
                "id": g["id"],
                "label": g["label"],
                "status": g["status"],
                "effort": g["effort"],
                "impact": g["impact"],
                "notes": g["notes"],
            }
            for g in gaps
        ],
        "high_impact_missing": high_impact_missing,
        "findings_persisted": persisted,
        "components": [
            {
                "id": a["id"],
                "label": a["label"],
                "status": a["status"],
                "effort": a["effort"],
                "impact": a["impact"],
                "notes": a["notes"],
            }
            for a in assessed
        ],
    }
