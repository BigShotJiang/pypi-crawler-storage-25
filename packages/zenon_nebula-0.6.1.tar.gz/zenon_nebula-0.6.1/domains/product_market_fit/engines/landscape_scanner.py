# SPDX-License-Identifier: MIT
"""
CompetitiveScanner -- Track competing projects in the BTC L2 / Bitcoin DeFi space.

Monitors GitHub activity, market metrics, and feature sets for:
- Stacks (STX) -- Bitcoin smart contracts
- THORChain (RUNE) -- cross-chain DEX with BTC
- Lightning Network -- BTC payment channels
- RSK (RBTC) -- Bitcoin sidechain with EVM
- Liquid Network -- Bitcoin federation sidechain
"""

import json
import logging
import os
import sqlite3
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request

from core.http import opsec_urlopen
from core.persist_to_db import persist_metric
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

GITHUB_API = "https://api.github.com"
DEXSCREENER_BASE = "https://api.dexscreener.com/latest/dex"

# Competitive landscape data changes over days/weeks, not seconds. Cycling
# every 30s and re-fetching 15 GitHub endpoints every time blows through the
# unauthenticated 60 req/hr limit in under 5 minutes. TTL-cache the last
# successful snapshot and short-circuit fetch when it's still fresh.
GITHUB_FETCH_TTL_HOURS = 6

# Module-level flag so we only warn once per process when rate-limited.
# Prevents log spam during the inevitable ~6h backoff window.
_RATE_LIMITED_LOGGED = False

# Competitor definitions with GitHub repos and token info
COMPETITORS = [
    {
        "name": "Stacks",
        "category": "btc_smart_contracts",
        "github_org": "stacks-network",
        "primary_repo": "stacks-core",
        "token_address": None,
        "coingecko_id": "blockstack",
        "unique_features": "PoX consensus, Clarity smart contracts, direct BTC settlement",
    },
    {
        "name": "THORChain",
        "category": "cross_chain_dex",
        "github_org": "thorchain",
        "primary_repo": "thornode",
        "token_address": None,
        "coingecko_id": "thorchain",
        "unique_features": "Native cross-chain swaps, continuous liquidity pools, BTC integration",
    },
    {
        "name": "Lightning Network",
        "category": "btc_payments",
        "github_org": "lightningnetwork",
        "primary_repo": "lnd",
        "token_address": None,
        "coingecko_id": None,
        "unique_features": "Instant BTC payments, payment channels, Taproot Assets",
    },
    {
        "name": "RSK",
        "category": "btc_sidechain",
        "github_org": "rsksmart",
        "primary_repo": "rskj",
        "token_address": None,
        "coingecko_id": "rootstock",
        "unique_features": "EVM compatible, merge-mined with BTC, Powpeg bridge",
    },
    {
        "name": "Liquid Network",
        "category": "btc_federation",
        "github_org": "ElementsProject",
        "primary_repo": "elements",
        "token_address": None,
        "coingecko_id": None,
        "unique_features": "Confidential transactions, federation model, L-BTC",
    },
]


def _api_get(url: str, timeout: int = 15) -> dict | None:
    """Make a GET request and return parsed JSON, or None on failure.

    Uses ``GITHUB_TOKEN`` env var to bump the unauthenticated 60 req/hr
    limit to 5000 req/hr when available. Distinguishes rate-limit 403s
    from other failures so operators know what to fix, and suppresses
    repeat warnings within a single process.
    """
    global _RATE_LIMITED_LOGGED
    try:
        headers = {
            "Accept": "application/vnd.github.v3+json",
        }
        token = os.environ.get("GITHUB_TOKEN")
        if token and "api.github.com" in url:
            headers["Authorization"] = f"token {token}"
        req = Request(url, headers=headers)
        with opsec_urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except HTTPError as exc:
        if exc.code == 403 and "api.github.com" in url:
            if not _RATE_LIMITED_LOGGED:
                logger.warning(
                    "GitHub API rate-limited (HTTP 403). Set GITHUB_TOKEN env "
                    "var to bump limit from 60/hr to 5000/hr. Suppressing "
                    "further rate-limit warnings for this process."
                )
                _RATE_LIMITED_LOGGED = True
        else:
            logger.warning("API request failed for %s: HTTP %s", url, exc.code)
        return None
    except (URLError, json.JSONDecodeError, OSError) as exc:
        logger.warning("API request failed for %s: %s", url, exc)
        return None


def _last_snapshot(
    project_name: str,
    *,
    db_path: str = DEFAULT_DB,
) -> dict | None:
    """Return the most recent competitive_landscape row for a project, or None.

    Only returns rows that are younger than ``GITHUB_FETCH_TTL_HOURS``.
    Swallows errors (missing table, missing DB) so callers fall back to
    a live fetch on any failure.
    """
    try:
        conn = connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute(
                "SELECT * FROM competitive_landscape "
                "WHERE project_name = ? "
                "AND timestamp > datetime('now', ?) "
                "ORDER BY id DESC LIMIT 1",
                (project_name, f"-{GITHUB_FETCH_TTL_HOURS} hours"),
            ).fetchone()
        finally:
            conn.close()
        return dict(row) if row else None
    except sqlite3.Error:
        return None


def fetch_github_metrics(org: str, repo: str) -> dict:
    """Fetch GitHub metrics for a competitor's primary repository.

    Returns dict with stars, contributors, recent commits.
    """
    # Repo info (stars, forks)
    repo_data = _api_get(f"{GITHUB_API}/repos/{org}/{repo}")
    stars = 0
    forks = 0
    if repo_data:
        stars = repo_data.get("stargazers_count", 0)
        forks = repo_data.get("forks_count", 0)

    # Contributor count (from first page)
    contributors = 0
    contrib_data = _api_get(f"{GITHUB_API}/repos/{org}/{repo}/contributors?per_page=1&anon=true")
    if contrib_data is not None:
        # GitHub returns Link header with last page for total count
        # For simplicity, we fetch page count
        contributors = len(contrib_data) if isinstance(contrib_data, list) else 0
        # Try to get actual count from org level
        org_data = _api_get(f"{GITHUB_API}/orgs/{org}")
        if org_data:
            contributors = org_data.get("public_repos", contributors)

    # Recent commit activity (last 30 days via commit count)
    commits_data = _api_get(f"{GITHUB_API}/repos/{org}/{repo}/stats/participation")
    commits_30d = 0
    if commits_data and "all" in commits_data:
        # Last 4 weeks of weekly commit counts
        weekly = commits_data["all"]
        commits_30d = sum(weekly[-4:]) if len(weekly) >= 4 else sum(weekly)

    return {
        "stars": stars,
        "forks": forks,
        "contributors": contributors,
        "commits_30d": commits_30d,
    }


def assess_threat_level(github_metrics: dict) -> str:
    """Assess competitive threat level based on activity.

    Returns: 'low', 'medium', 'high', or 'critical'.
    """
    stars = github_metrics.get("stars", 0)
    commits = github_metrics.get("commits_30d", 0)

    if stars > 5000 and commits > 100:
        return "critical"
    if stars > 1000 or commits > 50:
        return "high"
    if stars > 200 or commits > 20:
        return "medium"
    return "low"


def persist_competitive_snapshot(
    competitor: dict,
    github_metrics: dict,
    threat_level: str,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist a competitive landscape snapshot."""
    return persist_metric(
        db_path=db_path,
        table="competitive_landscape",
        data={
            "project_name": competitor["name"],
            "category": competitor["category"],
            "github_stars": github_metrics.get("stars", 0),
            "github_contributors": github_metrics.get("contributors", 0),
            "commits_30d": github_metrics.get("commits_30d", 0),
            "unique_features": competitor.get("unique_features", ""),
            "threat_level": threat_level,
        },
    )


def get_competitive_summary(*, db_path: str = DEFAULT_DB) -> dict:
    """Get the latest competitive landscape summary."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        # Get latest snapshot for each competitor
        rows = conn.execute(
            """SELECT * FROM competitive_landscape
               WHERE id IN (
                   SELECT MAX(id) FROM competitive_landscape
                   GROUP BY project_name
               )
               ORDER BY github_stars DESC"""
        ).fetchall()

        competitors = [dict(r) for r in rows]
        threat_counts = {}
        for c in competitors:
            level = c.get("threat_level", "low")
            threat_counts[level] = threat_counts.get(level, 0) + 1

        return {
            "competitors": competitors,
            "total_tracked": len(competitors),
            "threat_distribution": threat_counts,
        }
    finally:
        conn.close()


def run_competitive_scan(*, db_path: str = DEFAULT_DB) -> dict:
    """Run a full competitive landscape scan.

    Reuses any snapshot younger than :data:`GITHUB_FETCH_TTL_HOURS` instead
    of refetching. Competitive data changes slowly; cycling every 30s and
    refetching burns the unauthenticated GitHub 60 req/hr limit in minutes.

    Returns comprehensive competitive analysis dict.
    """
    results = []
    cached_hits = 0
    for competitor in COMPETITORS:
        fresh = _last_snapshot(competitor["name"], db_path=db_path)
        if fresh is not None:
            # Short-circuit: reuse cached metrics without any network I/O.
            github = {
                "stars": fresh.get("github_stars", 0),
                "forks": 0,  # not stored historically; benign default
                "contributors": fresh.get("github_contributors", 0),
                "commits_30d": fresh.get("commits_30d", 0),
            }
            threat = fresh.get("threat_level", "low")
            snapshot_id = fresh.get("id", 0)
            cached_hits += 1
            logger.debug(
                "landscape_scanner: cache hit for %s (age within %dh)",
                competitor["name"],
                GITHUB_FETCH_TTL_HOURS,
            )
        else:
            github = fetch_github_metrics(
                competitor["github_org"],
                competitor["primary_repo"],
            )
            threat = assess_threat_level(github)
            snapshot_id = persist_competitive_snapshot(
                competitor,
                github,
                threat,
                db_path=db_path,
            )

        results.append(
            {
                "name": competitor["name"],
                "category": competitor["category"],
                "github": github,
                "threat_level": threat,
                "snapshot_id": snapshot_id,
            }
        )

    summary = get_competitive_summary(db_path=db_path)

    return {
        "success": True,
        "competitors_scanned": len(results),
        "cached_hits": cached_hits,
        "results": results,
        "summary": summary,
    }
