# SPDX-License-Identifier: MIT
"""
CrossRepoChecker -- Constant consistency verification across repositories.

For each contract:
- Reads the address from Go definition, greps in all SDKs, verifies identical
- For each ABI method: verifies name identical across repos
- Reports any inconsistency
"""

import logging
import re
import sqlite3
from pathlib import Path

from core.persist_to_db import persist_finding
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

GO_ZENON_PATHS = [
    ZENON_WORKSPACE / "core" / "go-zenon",
    ZENON_WORKSPACE / "network" / "go-zenon",
]

SDK_PATHS = {
    "znn_sdk_dart": ZENON_WORKSPACE / "sdk" / "znn_sdk_dart",
    "znn_cli_dart": ZENON_WORKSPACE / "tools" / "znn_cli_dart",
}

# Pattern: address constant in Go
GO_ADDRESS_PATTERN = re.compile(
    r'(?:Address\w*)\s*=\s*types\.ParseAddressPanic\s*\(\s*"(z1q[a-z0-9]+)"\s*\)',
)

# Pattern: address constant in Dart
DART_ADDRESS_PATTERN = re.compile(
    r"""Address\.parse\s*\(\s*['"]?(z1q[a-z0-9]+)['"]?\s*\)""",
)

# Pattern: ABI method name in Go definition
GO_METHOD_NAME_PATTERN = re.compile(
    r'"name"\s*:\s*"(\w+)"',
)

# Pattern: method reference in Dart
DART_METHOD_PATTERN = re.compile(
    r"""encodeFunction\s*\(\s*['"](\w+)['"]""",
)

# Known embedded contract names
EMBEDDED_CONTRACTS = [
    "accelerator",
    "bridge",
    "htlc",
    "liquidity",
    "pillar",
    "plasma",
    "sentinel",
    "stake",
    "swap",
    "token",
]


def _find_go_addresses(contract_name: str) -> list[str]:
    """Find address constants for a contract in go-zenon."""
    addresses = []
    for go_zenon in GO_ZENON_PATHS:
        def_file = go_zenon / "vm" / "embedded" / "definition" / f"{contract_name}.go"
        if not def_file.is_file():
            continue
        try:
            content = def_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for match in GO_ADDRESS_PATTERN.finditer(content):
            addresses.append(match.group(1))
    return addresses


def _find_dart_addresses(
    contract_name: str,
    sdk_path: Path,
) -> list[str]:
    """Find address constants for a contract in a Dart repo."""
    addresses = []
    if not sdk_path.is_dir():
        return addresses

    for dart_file in sdk_path.rglob("*.dart"):
        if "__pycache__" in str(dart_file):
            continue
        try:
            content = dart_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if contract_name not in content.lower():
            continue
        for match in DART_ADDRESS_PATTERN.finditer(content):
            addresses.append(match.group(1))

    return addresses


def _find_go_method_names(contract_name: str) -> list[str]:
    """Find ABI method names for a contract in go-zenon."""
    methods = []
    for go_zenon in GO_ZENON_PATHS:
        def_file = go_zenon / "vm" / "embedded" / "definition" / f"{contract_name}.go"
        if not def_file.is_file():
            continue
        try:
            content = def_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for match in GO_METHOD_NAME_PATTERN.finditer(content):
            methods.append(match.group(1))
    return sorted(set(methods))


def check_address_consistency(contract_name: str) -> list[dict]:
    """Check that addresses are consistent across repos.

    Returns list of comparison dicts.
    """
    go_addresses = _find_go_addresses(contract_name)
    if not go_addresses:
        return []

    results = []
    go_addr = go_addresses[0]  # Primary address

    for sdk_name, sdk_path in SDK_PATHS.items():
        dart_addresses = _find_dart_addresses(contract_name, sdk_path)
        if dart_addresses:
            match = go_addr in dart_addresses
            results.append(
                {
                    "check_type": "address",
                    "contract_name": contract_name,
                    "item_name": f"{contract_name}_address",
                    "repo_a": "go-zenon",
                    "value_a": go_addr,
                    "repo_b": sdk_name,
                    "value_b": dart_addresses[0] if dart_addresses else "",
                    "match": match,
                }
            )
        else:
            results.append(
                {
                    "check_type": "address",
                    "contract_name": contract_name,
                    "item_name": f"{contract_name}_address",
                    "repo_a": "go-zenon",
                    "value_a": go_addr,
                    "repo_b": sdk_name,
                    "value_b": "(not found)",
                    "match": False,
                }
            )

    return results


def check_method_consistency(contract_name: str) -> list[dict]:
    """Check that ABI method names are consistent across repos.

    Returns list of comparison dicts.
    """
    go_methods = _find_go_method_names(contract_name)
    if not go_methods:
        return []

    results = []
    for method_name in go_methods:
        for sdk_name, sdk_path in SDK_PATHS.items():
            found = False
            if sdk_path.is_dir():
                for dart_file in sdk_path.rglob("*.dart"):
                    try:
                        content = dart_file.read_text(encoding="utf-8")
                        if method_name in content:
                            found = True
                            break
                    except (OSError, UnicodeDecodeError):
                        continue

            results.append(
                {
                    "check_type": "method_name",
                    "contract_name": contract_name,
                    "item_name": method_name,
                    "repo_a": "go-zenon",
                    "value_a": method_name,
                    "repo_b": sdk_name,
                    "value_b": method_name if found else "(not found)",
                    "match": found,
                }
            )

    return results


def check_all_contracts(
    *,
    contract_names: list[str] | None = None,
) -> list[dict]:
    """Run consistency checks for all contracts.

    Skips work if none of the inspected repos have changed.
    Returns list of all comparison dicts.
    """
    from core.git_cache import has_repo_changed

    # Check if go-zenon or any SDK path has changed.
    any_changed = False
    for go_zenon in GO_ZENON_PATHS:
        if go_zenon.is_dir() and has_repo_changed(str(go_zenon)):
            any_changed = True
            break
    if not any_changed:
        for sdk_path in SDK_PATHS.values():
            if sdk_path.is_dir() and has_repo_changed(str(sdk_path)):
                any_changed = True
                break

    if not any_changed:
        logger.debug("Skipping cross-repo check — no repo HEAD changed")
        return []

    if contract_names is None:
        contract_names = EMBEDDED_CONTRACTS

    all_results = []
    for name in contract_names:
        all_results.extend(check_address_consistency(name))
        all_results.extend(check_method_consistency(name))
    return all_results


def _build_actionable_mismatch(r: dict) -> str:
    """Build an actionable finding for a single mismatch.

    Answers WHAT / SO WHAT / NOW WHAT.
    """
    contract = r["contract_name"]
    check_type = r["check_type"]
    item = r["item_name"]
    repo_a = r["repo_a"]
    repo_b = r["repo_b"]
    val_a = r.get("value_a", "")
    val_b = r.get("value_b", "")

    if check_type == "address":
        if val_b == "(not found)":
            return (
                f"WHAT: {contract} address exists in {repo_a} ({val_a}) "
                f"but is missing from {repo_b}. "
                f"SO WHAT: {repo_b} clients cannot interact with the "
                f"{contract} contract at all — any attempt will fail "
                f"or target the wrong address. "
                f"NOW WHAT: Add the {contract} address constant to "
                f"{repo_b}. Copy EXACTLY from {repo_a}: {val_a}."
            )
        else:
            return (
                f"WHAT: {contract} address MISMATCH — {repo_a} uses "
                f"'{val_a}' but {repo_b} has '{val_b}'. "
                f"SO WHAT: Every {repo_b} transaction targeting {contract} "
                f"will be sent to the WRONG address. Funds will be "
                f"irretrievably lost. This is a critical data corruption "
                f"bug. "
                f"NOW WHAT: Fix {repo_b} IMMEDIATELY. The Go source "
                f"({repo_a}) is the canonical truth. Replace '{val_b}' "
                f"with '{val_a}' in {repo_b}."
            )
    elif check_type == "method_name":
        if val_b == "(not found)":
            return (
                f"WHAT: ABI method '{item}' exists in {repo_a} for "
                f"{contract} but is missing from {repo_b}. "
                f"SO WHAT: {repo_b} clients cannot call {contract}.{item}(). "
                f"This is a gap in SDK coverage — users cannot access "
                f"this contract functionality from {repo_b}. "
                f"NOW WHAT: Implement the '{item}' method wrapper in "
                f"{repo_b}. Match the Go ABI signature exactly."
            )
        else:
            return (
                f"WHAT: Method name mismatch for {contract}.{item} — "
                f"{repo_a} uses '{val_a}' but {repo_b} has '{val_b}'. "
                f"SO WHAT: ABI encoding will produce wrong method "
                f"selectors. Transactions will be rejected by the "
                f"contract or routed to the wrong method. "
                f"NOW WHAT: Fix the method name in {repo_b} to match "
                f"{repo_a} exactly: '{val_a}'."
            )
    else:
        return (
            f"WHAT: {check_type} mismatch for {contract}.{item} — "
            f"{repo_a}='{val_a}' vs {repo_b}='{val_b}'. "
            f"SO WHAT: Inconsistent constants cause silent runtime "
            f"failures. "
            f"NOW WHAT: Align {repo_b} with {repo_a} (canonical source)."
        )


def _build_summary_finding(results: list[dict]) -> str:
    """Build a cross-contract consistency summary with prioritized actions."""
    if not results:
        return (
            "WHAT: No contracts checked. "
            "SO WHAT: Cannot verify cross-repo consistency. "
            "NOW WHAT: Ensure contract names are configured correctly."
        )

    total = len(results)
    mismatches = [r for r in results if not r["match"]]
    total - len(mismatches)

    if not mismatches:
        return (
            f"WHAT: All {total} cross-repo checks passed across "
            f"{len({r['contract_name'] for r in results})} contracts. "
            f"SO WHAT: Addresses and ABI method names are consistent "
            f"between Go source and all SDKs. Safe to proceed with "
            f"upstream PRs. "
            f"NOW WHAT: No action needed. Re-run after any address or "
            f"ABI changes."
        )

    # Group mismatches by severity
    address_mismatches = [r for r in mismatches if r["check_type"] == "address"]
    method_mismatches = [r for r in mismatches if r["check_type"] == "method_name"]
    affected_contracts = sorted({r["contract_name"] for r in mismatches})

    parts = []
    parts.append(
        f"WHAT: {len(mismatches)} mismatches found out of {total} checks "
        f"across {len(affected_contracts)} contracts "
        f"({', '.join(affected_contracts)})."
    )

    if address_mismatches:
        parts.append(
            f"SO WHAT: {len(address_mismatches)} ADDRESS mismatch(es) — "
            f"these cause FUND LOSS. SDK clients will send transactions "
            f"to wrong addresses. This blocks ALL upstream PR submissions."
        )
    elif method_mismatches:
        parts.append(
            f"SO WHAT: {len(method_mismatches)} method name "
            f"mismatch(es) — these cause transaction failures. "
            f"SDK clients cannot call the affected methods correctly."
        )

    # Prioritized actions
    actions = []
    if address_mismatches:
        actions.append(
            f"1. FIX {len(address_mismatches)} address mismatch(es) "
            f"IMMEDIATELY — copy from Go source, verify byte-for-byte"
        )
    if method_mismatches:
        actions.append(
            f"{'2' if address_mismatches else '1'}. Fix "
            f"{len(method_mismatches)} method name mismatch(es) in SDKs"
        )
    actions.append(
        f"{'3' if len(actions) >= 2 else str(len(actions) + 1)}. Re-run checker to verify all fixes"
    )

    parts.append("NOW WHAT: " + ". ".join(actions) + ".")
    return " ".join(parts)


def persist_checks(
    results: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist consistency check results with actionable findings.

    Every mismatch answers: WHAT (the inconsistency), SO WHAT (the impact),
    NOW WHAT (how to fix it). Includes a summary with prioritized actions.

    Returns number of records inserted.
    """
    if not results:
        return 0
    conn = connect(db_path)
    try:
        for r in results:
            conn.execute(
                """INSERT INTO consistency_checks
                   (check_type, contract_name, item_name,
                    repo_a, value_a, repo_b, value_b, match)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    r["check_type"],
                    r["contract_name"],
                    r["item_name"],
                    r["repo_a"],
                    r.get("value_a", ""),
                    r["repo_b"],
                    r.get("value_b", ""),
                    r["match"],
                ),
            )

        conn.commit()

        # Persist actionable findings for mismatches
        mismatches = [r for r in results if not r["match"]]
        for r in mismatches:
            repo_a = r["repo_a"]
            repo_b = r["repo_b"]
            source_repo = f"{repo_a}, {repo_b}"

            contract = r["contract_name"]
            if repo_a == "go-zenon":
                source_file = f"vm/embedded/definition/{contract}.go"
            else:
                source_file = contract

            severity_boost = 0.99 if r["check_type"] == "address" else 0.95
            finding_text = _build_actionable_mismatch(r)

            persist_finding(
                db_path=db_path,
                domain="quality",
                engine="cross_repo_checker",
                evidence_type=f"consistency_{r['check_type']}",
                finding=finding_text,
                confidence=severity_boost,
                raw_data=r,
                source_repo=source_repo,
                source_file=source_file,
            )

        # Persist summary finding
        summary = _build_summary_finding(results)
        persist_finding(
            db_path=db_path,
            domain="quality",
            engine="cross_repo_checker",
            evidence_type="consistency_summary",
            finding=summary,
            confidence=0.95,
            raw_data={
                "total_checks": len(results),
                "mismatches": len(mismatches),
                "affected_contracts": sorted({r["contract_name"] for r in mismatches}),
            },
            source_repo="go-zenon",
        )

        return len(results)
    finally:
        conn.close()


def get_inconsistencies(*, db_path: str = DEFAULT_DB) -> list[dict]:
    """Get all inconsistencies (non-matching checks) from database."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT * FROM consistency_checks
               WHERE match = 0
               ORDER BY contract_name, check_type"""
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()
