# SPDX-License-Identifier: MIT
"""
BuildVerifier -- Multi-language build verification.

Runs build and static analysis commands across repos:
- Go: go build ./... + go vet ./...
- Dart: dart pub get + dart analyze
- TypeScript: npx tsc --noEmit
- Python: python3 -m py_compile per file

Records results to the build_status table.
"""

import logging
import sqlite3
import subprocess
import time
from pathlib import Path

from core.persist_to_db import persist_metric
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

# Repo configurations: (repo_name, path, language, commands)
REPO_CONFIGS = [
    {
        "repo_name": "go-zenon",
        "path": ZENON_WORKSPACE / "core" / "go-zenon",
        "language": "go",
        "commands": [
            ("go build ./...", "build"),
            ("go vet ./...", "vet"),
        ],
    },
    {
        "repo_name": "znn_sdk_dart",
        "path": ZENON_WORKSPACE / "sdk" / "znn_sdk_dart",
        "language": "dart",
        "commands": [
            ("dart pub get", "deps"),
            ("dart analyze", "analyze"),
        ],
    },
    {
        "repo_name": "znn_cli_dart",
        "path": ZENON_WORKSPACE / "tools" / "znn_cli_dart",
        "language": "dart",
        "commands": [
            ("dart pub get", "deps"),
            ("dart analyze", "analyze"),
        ],
    },
    {
        "repo_name": "engine",
        "path": ENGINE_ROOT,
        "language": "python",
        "commands": [],  # Python files checked individually
    },
]


def _run_command(
    command: str,
    cwd: Path,
    *,
    timeout: int = 120,
) -> dict:
    """Run a command and return result dict.

    v0.5.0 — rewritten from shell=True to list-argv via shlex.
    """
    import shlex

    start = time.time()
    try:
        result = subprocess.run(
            shlex.split(command),
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        elapsed = time.time() - start
        return {
            "command": command,
            "success": result.returncode == 0,
            "output": (result.stdout + result.stderr)[:5000],
            "returncode": result.returncode,
            "duration_seconds": round(elapsed, 2),
        }
    except subprocess.TimeoutExpired:
        elapsed = time.time() - start
        return {
            "command": command,
            "success": False,
            "output": f"Command timed out after {timeout}s",
            "returncode": -1,
            "duration_seconds": round(elapsed, 2),
        }
    except FileNotFoundError:
        return {
            "command": command,
            "success": False,
            "output": f"Command not found: {command.split()[0]}",
            "returncode": -1,
            "duration_seconds": 0.0,
        }


def _check_python_files(repo_path: Path) -> list[dict]:
    """Check all Python files in a repo using py_compile."""
    results = []
    for py_file in repo_path.rglob("*.py"):
        if "__pycache__" in str(py_file) or ".venv" in str(py_file):
            continue
        result = _run_command(
            f"python3 -m py_compile {py_file}",
            cwd=repo_path,
            timeout=10,
        )
        result["file"] = str(py_file.relative_to(repo_path))
        results.append(result)
    return results


def check_repo(repo_config: dict) -> list[dict]:
    """Run build checks for a single repo.

    Returns list of result dicts.
    """
    repo_name = repo_config["repo_name"]
    repo_path = repo_config["path"]
    language = repo_config["language"]

    if not repo_path.is_dir():
        return [
            {
                "repo_name": repo_name,
                "language": language,
                "command": "check_exists",
                "success": False,
                "output": f"Repo not found at {repo_path}",
                "duration_seconds": 0.0,
            }
        ]

    results = []

    if language == "python":
        py_results = _check_python_files(repo_path)
        for r in py_results:
            r["repo_name"] = repo_name
            r["language"] = language
        results.extend(py_results)
    else:
        for cmd, cmd_type in repo_config["commands"]:
            result = _run_command(cmd, cwd=repo_path)
            result["repo_name"] = repo_name
            result["language"] = language
            result["command_type"] = cmd_type
            results.append(result)

    return results


def check_all_repos(
    *,
    configs: list[dict] | None = None,
) -> dict[str, list[dict]]:
    """Run build checks for all configured repos.

    Returns dict mapping repo_name to list of result dicts.
    """
    if configs is None:
        configs = REPO_CONFIGS
    all_results = {}
    for config in configs:
        repo_name = config["repo_name"]
        all_results[repo_name] = check_repo(config)
    return all_results


def persist_results(
    results: dict[str, list[dict]],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist build results to build_status table.

    Returns total number of records inserted.
    """
    count = 0
    for repo_name, repo_results in results.items():
        for r in repo_results:
            rid = persist_metric(
                db_path=db_path,
                table="build_status",
                data={
                    "repo_name": repo_name,
                    "language": r.get("language", "unknown"),
                    "build_command": r.get("command", "unknown"),
                    "success": r.get("success", False),
                    "output": r.get("output", "")[:5000],
                    "duration_seconds": r.get("duration_seconds", 0.0),
                },
            )
            if rid > 0:
                count += 1
    return count


def get_build_summary(*, db_path: str = DEFAULT_DB) -> dict:
    """Get a summary of the latest build status per repo."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT repo_name, language,
                      SUM(CASE WHEN success THEN 1 ELSE 0 END) as pass_count,
                      COUNT(*) as total_count,
                      MAX(timestamp) as last_checked
               FROM build_status
               GROUP BY repo_name, language
               ORDER BY repo_name"""
        ).fetchall()
        return {
            row["repo_name"]: {
                "language": row["language"],
                "pass_count": row["pass_count"],
                "total_count": row["total_count"],
                "pass_rate": (
                    row["pass_count"] / row["total_count"] if row["total_count"] > 0 else 0.0
                ),
                "last_checked": row["last_checked"],
            }
            for row in rows
        }
    finally:
        conn.close()
