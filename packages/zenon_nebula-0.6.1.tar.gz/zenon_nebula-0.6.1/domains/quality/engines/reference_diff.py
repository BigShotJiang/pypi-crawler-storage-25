# SPDX-License-Identifier: MIT
"""
ReferenceDiff -- structural comparison of shared primitives across chains.

For consensus-critical primitives (merkle proof validation, secp256k1
signature verification, SPV header checks), this engine finds matching
function-like blocks in Zenon repos vs. reference-chain repos and
computes a cheap structural diff:

- line count
- cyclomatic complexity (Python ``ast`` for Python sources; regex-based
  control-flow counter for Go/Rust/C++)

Any primitive whose Zenon and reference sides diverge by more than a
configurable threshold is flagged as a divergence candidate.

The engine degrades gracefully to ``{}`` when no reference chain is
present. Confidence is capped at 0.6 because structural similarity is
only a proxy for semantic equivalence.
"""

from __future__ import annotations

import ast
import logging
import re
from pathlib import Path

from core.persist_to_db import persist_finding
from core.persistence.metrics import query_table
from core.persistence.schema import DEFAULT_DB

logger = logging.getLogger(__name__)


_REFERENCE_TYPES = {
    "blockchain_node_btc",
    "blockchain_node_evm",
    "blockchain_node_cosmos",
    "rust_blockchain",
}

_ZENON_TYPES = {
    "node",
    "sdk_dart",
    "sdk_go",
    "sdk_typescript",
    "sdk_python",
    "cli",
    "cli_go",
    "bridge",
}

# Primitives we care about. Each entry is (label, function_name_regex).
_PRIMITIVES: list[tuple[str, re.Pattern[str]]] = [
    (
        "merkle_proof_verify",
        re.compile(
            r"\b(verify[_ ]?merkle[_ ]?proof|merkle[_ ]?verify)\b",
            re.IGNORECASE,
        ),
    ),
    (
        "header_validate",
        re.compile(
            r"\b(validate[_ ]?header|verify[_ ]?header|check[_ ]?header)\b",
            re.IGNORECASE,
        ),
    ),
    (
        "secp256k1_verify",
        re.compile(
            r"\b(secp256k1[_ ]?verify|schnorr[_ ]?verify|ecdsa[_ ]?verify)\b",
            re.IGNORECASE,
        ),
    ),
]

_SOURCE_SUFFIXES = {".go", ".rs", ".cpp", ".cc", ".c", ".h", ".hpp", ".py"}
# Skip build artifacts AND any directory that commonly holds secrets
# even if it somehow ended up inside a workspace repo. Defensive hardening
# for operators who put ``.env`` / credentials inside a scanned repo.
_SKIP_DIRS = {
    ".git",
    "node_modules",
    "vendor",
    "build",
    "dist",
    "target",
    "__pycache__",
    # Secret-bearing paths — never read these even if they're inside a repo
    ".ssh",
    ".aws",
    ".gnupg",
    ".gpg",
    ".config",
    "secrets",
    ".secrets",
    ".vault",
    ".env.d",
}

_MAX_FILES_PER_REPO = 300
_DIVERGENCE_RATIO = 1.8  # 80% bigger/smaller triggers a finding
_MIN_LINE_COUNT = 5  # stub functions are ignored


# ---------------------------------------------------------------------------
# Complexity helpers
# ---------------------------------------------------------------------------


def _python_complexity(source: str) -> int:
    """Return a simple cyclomatic complexity for a Python snippet.

    Counts decision points (``if``, ``for``, ``while``, ``except``,
    ``and``, ``or``, ``elif``) in the AST. Returns 1 on parse failure so
    callers always get a usable lower bound.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 1
    count = 1
    for node in ast.walk(tree):
        if isinstance(
            node,
            (
                ast.If,
                ast.For,
                ast.AsyncFor,
                ast.While,
                ast.ExceptHandler,
                ast.IfExp,
                ast.With,
                ast.AsyncWith,
            ),
        ):
            count += 1
        elif isinstance(node, ast.BoolOp):
            count += max(0, len(node.values) - 1)
    return count


_GO_RUST_CPP_DECISION_RE = re.compile(r"\b(if|for|while|case|switch|catch|else if|elif|&&|\|\|)\b")


def _regex_complexity(source: str) -> int:
    """Approximate complexity by counting decision-point keywords."""
    return 1 + len(_GO_RUST_CPP_DECISION_RE.findall(source))


def _compute_complexity(source: str, suffix: str) -> int:
    """Dispatch to the right complexity function based on file suffix."""
    if suffix == ".py":
        return _python_complexity(source)
    return _regex_complexity(source)


# ---------------------------------------------------------------------------
# File iteration + function block extraction
# ---------------------------------------------------------------------------


def _iter_source_files(repo_path: Path) -> list[Path]:
    """Iterate source files under a repo, skipping vendor/build noise."""
    if not repo_path.is_dir():
        return []
    out: list[Path] = []
    for path in repo_path.rglob("*"):
        if len(out) >= _MAX_FILES_PER_REPO:
            break
        if not path.is_file():
            continue
        if any(seg in _SKIP_DIRS for seg in path.parts):
            continue
        if path.suffix.lower() not in _SOURCE_SUFFIXES:
            continue
        try:
            if path.stat().st_size > 512 * 1024:
                continue
        except OSError:
            continue
        out.append(path)
    return out


_FUNCTION_HEADER_RE = re.compile(r"^\s*(func|fn|def|static\s+\w+\s+\w+|\w[\w\s\*&<>,]*\s+\w+\s*\()")


def _extract_function_blocks(source: str) -> list[tuple[str, str]]:
    """Return ``(header_line, body)`` tuples for function-shaped blocks.

    The parser is intentionally loose — it finds the first ``{`` (for
    C/Go/Rust/C++) or the first ``:`` followed by indented lines (for
    Python) and tracks brace/indent depth until the block closes. Good
    enough for grep-style structural comparison without bringing in a
    real parser for every language.
    """
    blocks: list[tuple[str, str]] = []
    lines = source.splitlines()
    i = 0
    while i < len(lines):
        header = lines[i]
        if not _FUNCTION_HEADER_RE.match(header):
            i += 1
            continue
        if header.lstrip().startswith("def "):
            body_lines = [header]
            base_indent = len(header) - len(header.lstrip())
            i += 1
            while i < len(lines):
                nxt = lines[i]
                if not nxt.strip():
                    body_lines.append(nxt)
                    i += 1
                    continue
                indent = len(nxt) - len(nxt.lstrip())
                if indent <= base_indent:
                    break
                body_lines.append(nxt)
                i += 1
            blocks.append((header, "\n".join(body_lines)))
            continue
        # Brace-delimited languages.
        if "{" not in header:
            # Header may continue on next line(s).
            collected = [header]
            j = i + 1
            while j < len(lines) and "{" not in lines[j]:
                collected.append(lines[j])
                j += 1
                if j - i > 5:
                    break
            if j >= len(lines):
                i += 1
                continue
            collected.append(lines[j])
            header_block = "\n".join(collected)
            i = j
        else:
            header_block = header
        depth = header_block.count("{") - header_block.count("}")
        body_lines = [header_block]
        i += 1
        while i < len(lines) and depth > 0:
            nxt = lines[i]
            depth += nxt.count("{") - nxt.count("}")
            body_lines.append(nxt)
            i += 1
        blocks.append((header_block, "\n".join(body_lines)))
    return blocks


def _collect_primitive_blocks(
    repo_path: Path,
    label_patterns: list[tuple[str, re.Pattern[str]]],
) -> dict[str, list[dict]]:
    """Return ``{primitive_label: [block_stats]}`` for a repo.

    Each block stat dict has keys ``file``, ``line_count``, ``complexity``.
    """
    out: dict[str, list[dict]] = {}
    for path in _iter_source_files(repo_path):
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        blocks = _extract_function_blocks(text)
        if not blocks:
            continue
        for header, body in blocks:
            for label, pattern in label_patterns:
                if not pattern.search(header):
                    continue
                line_count = len(body.splitlines())
                if line_count < _MIN_LINE_COUNT:
                    continue
                complexity = _compute_complexity(body, path.suffix.lower())
                out.setdefault(label, []).append(
                    {
                        "file": str(path.relative_to(repo_path)),
                        "line_count": line_count,
                        "complexity": complexity,
                    }
                )
    return out


def _best_block(blocks: list[dict]) -> dict:
    """Return the most representative block (largest line count)."""
    return max(blocks, key=lambda b: b["line_count"])


def _emit_divergence_finding(
    label: str,
    reference_repo: str,
    reference_block: dict,
    zenon_repo: str,
    zenon_block: dict,
    db_path: str,
) -> None:
    """Persist a single divergence finding."""
    line_ratio = max(reference_block["line_count"], zenon_block["line_count"]) / max(
        1, min(reference_block["line_count"], zenon_block["line_count"])
    )
    comp_ratio = max(reference_block["complexity"], zenon_block["complexity"]) / max(
        1, min(reference_block["complexity"], zenon_block["complexity"])
    )
    finding_text = (
        f"WHAT: Primitive '{label}' diverges structurally between "
        f"reference repo '{reference_repo}' "
        f"({reference_block['file']}, {reference_block['line_count']} lines, "
        f"complexity {reference_block['complexity']}) "
        f"and Zenon repo '{zenon_repo}' "
        f"({zenon_block['file']}, {zenon_block['line_count']} lines, "
        f"complexity {zenon_block['complexity']}). "
        f"Line-count ratio {line_ratio:.2f}, complexity ratio {comp_ratio:.2f}. "
        f"SO WHAT: A large structural delta for a consensus-critical "
        f"primitive is a smell — either the Zenon implementation is "
        f"missing cases the reference chain handles, or it handles "
        f"cases the reference chain intentionally rejects. "
        f"NOW WHAT: Diff the two function bodies side by side, identify "
        f"branches present in one but not the other, and determine "
        f"whether each divergence is intentional."
    )
    persist_finding(
        db_path=db_path,
        domain="quality",
        engine="reference_diff",
        evidence_type="reference_divergence",
        finding=finding_text,
        confidence=0.6,
        raw_data={
            "primitive": label,
            "reference_repo": reference_repo,
            "reference_block": reference_block,
            "zenon_repo": zenon_repo,
            "zenon_block": zenon_block,
            "line_ratio": line_ratio,
            "complexity_ratio": comp_ratio,
        },
        source_repo=zenon_repo,
        source_file=zenon_block["file"],
    )


def diff_reference_implementations(
    db_path: str = DEFAULT_DB,
    **_: object,
) -> dict:
    """Compare consensus primitives between reference chains and Zenon.

    Returns ``{}`` when no reference chain is present in the workspace
    catalog. Otherwise walks both sides, computes structural metrics
    per primitive, and emits a divergence finding for every primitive
    whose line-count ratio exceeds ``_DIVERGENCE_RATIO``.

    Args:
        db_path: SQLite database path.

    Returns:
        Dict describing reference/zenon repo counts and the number of
        divergence findings emitted.
    """
    repos = query_table(db_path=db_path, table="workspace_repos", limit=0)
    reference_repos = [r for r in repos if r.get("repo_type") in _REFERENCE_TYPES]
    if not reference_repos:
        return {}
    zenon_repos = [r for r in repos if r.get("repo_type") in _ZENON_TYPES]
    if not zenon_repos:
        return {}

    reference_blocks: dict[str, dict[str, dict]] = {}
    for row in reference_repos:
        repo_path = Path(row.get("repo_path", ""))
        if not repo_path.is_dir():
            continue
        hits = _collect_primitive_blocks(repo_path, _PRIMITIVES)
        for label, blocks in hits.items():
            reference_blocks.setdefault(label, {})[row["repo_name"]] = _best_block(blocks)

    if not reference_blocks:
        return {"reference_repos": len(reference_repos), "findings": 0}

    findings = 0
    for row in zenon_repos:
        repo_path = Path(row.get("repo_path", ""))
        if not repo_path.is_dir():
            continue
        hits = _collect_primitive_blocks(repo_path, _PRIMITIVES)
        for label, zenon_list in hits.items():
            ref_map = reference_blocks.get(label)
            if not ref_map:
                continue
            zenon_block = _best_block(zenon_list)
            for reference_repo, reference_block in ref_map.items():
                line_ratio = max(reference_block["line_count"], zenon_block["line_count"]) / max(
                    1, min(reference_block["line_count"], zenon_block["line_count"])
                )
                if line_ratio < _DIVERGENCE_RATIO:
                    continue
                _emit_divergence_finding(
                    label=label,
                    reference_repo=reference_repo,
                    reference_block=reference_block,
                    zenon_repo=row["repo_name"],
                    zenon_block=zenon_block,
                    db_path=db_path,
                )
                findings += 1

    return {
        "reference_repos": len(reference_repos),
        "zenon_repos": len(zenon_repos),
        "primitives_tracked": len(_PRIMITIVES),
        "findings": findings,
    }


# Scheduler-discoverable alias (prefix ``check_``).
def check_reference_diff(db_path: str = DEFAULT_DB, **kw: object) -> dict:
    """Alias for :func:`diff_reference_implementations` to satisfy the scheduler."""
    return diff_reference_implementations(db_path=db_path, **kw)


__all__ = ["check_reference_diff", "diff_reference_implementations"]
