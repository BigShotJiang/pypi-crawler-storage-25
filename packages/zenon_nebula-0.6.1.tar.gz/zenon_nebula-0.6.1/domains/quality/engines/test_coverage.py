# SPDX-License-Identifier: MIT
"""
TestCoverage -- Test gap detection across contracts and languages.

For each contract:
- Counts test functions in Go, Dart, etc.
- Identifies methods with zero test coverage
- Reports gaps
"""

import logging
import re
import sqlite3
from pathlib import Path

from core.persist_to_db import persist_metric
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

GO_ZENON_PATHS = [
    ZENON_WORKSPACE / "core" / "go-zenon",
    ZENON_WORKSPACE / "network" / "go-zenon",
]

DART_SDK_PATHS = [
    ZENON_WORKSPACE / "sdk" / "znn_sdk_dart",
]

# Go test function pattern
GO_TEST_FUNC_PATTERN = re.compile(r"func\s+(Test\w+)\s*\(")
# Dart test function pattern
DART_TEST_PATTERN = re.compile(r"(?:test|testWidgets)\s*\(\s*['\"]([^'\"]+)")
# Go ABI method names (for counting total methods)
GO_METHOD_PATTERN = re.compile(r'"name"\s*:\s*"(\w+)"')

EMBEDDED_CONTRACTS = [
    "accelerator",
    "bridge",
    "htlc",
    "liquidity",
    "pillar",
    "plasma",
    "sentinel",
    "stake",
    "swap",
    "token",
]


def _count_go_tests(contract_name: str) -> tuple[int, list[str]]:
    """Count Go test functions for a contract.

    Returns (count, list_of_test_names).
    """
    tests = []
    for go_zenon in GO_ZENON_PATHS:
        # Check for test files in various locations
        for test_dir in [
            go_zenon / "vm" / "embedded" / "implementation",
            go_zenon / "vm" / "embedded",
            go_zenon,
        ]:
            if not test_dir.is_dir():
                continue
            for test_file in test_dir.rglob("*_test.go"):
                try:
                    content = test_file.read_text(encoding="utf-8")
                except (OSError, UnicodeDecodeError):
                    continue
                if contract_name not in content.lower():
                    continue
                for match in GO_TEST_FUNC_PATTERN.finditer(content):
                    tests.append(match.group(1))

    return len(tests), tests


def _count_dart_tests(contract_name: str) -> tuple[int, list[str]]:
    """Count Dart test functions for a contract.

    Returns (count, list_of_test_names).
    """
    tests = []
    for sdk_path in DART_SDK_PATHS:
        test_dir = sdk_path / "test"
        if not test_dir.is_dir():
            continue
        for test_file in test_dir.rglob("*.dart"):
            try:
                content = test_file.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            if contract_name not in content.lower():
                continue
            for match in DART_TEST_PATTERN.finditer(content):
                tests.append(match.group(1))

    return len(tests), tests


def _get_contract_methods(contract_name: str) -> list[str]:
    """Get all ABI method names for a contract from Go definition."""
    methods = []
    for go_zenon in GO_ZENON_PATHS:
        def_file = go_zenon / "vm" / "embedded" / "definition" / f"{contract_name}.go"
        if not def_file.is_file():
            continue
        try:
            content = def_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for match in GO_METHOD_PATTERN.finditer(content):
            methods.append(match.group(1))
    return sorted(set(methods))


def _check_method_tested(
    method_name: str,
    test_names: list[str],
) -> bool:
    """Heuristic: check if a method name appears in any test name."""
    method_lower = method_name.lower()
    return any(method_lower in test_name.lower() for test_name in test_names)


def analyze_contract(contract_name: str) -> dict:
    """Analyze test coverage for a single contract.

    Returns dict with go and dart test counts, method coverage, gaps.
    """
    methods = _get_contract_methods(contract_name)
    go_count, go_tests = _count_go_tests(contract_name)
    dart_count, dart_tests = _count_dart_tests(contract_name)

    all_tests = go_tests + dart_tests
    methods_tested = sum(1 for m in methods if _check_method_tested(m, all_tests))

    untested_methods = [m for m in methods if not _check_method_tested(m, all_tests)]

    coverage_pct = methods_tested / len(methods) * 100.0 if methods else 0.0

    return {
        "contract_name": contract_name,
        "methods_total": len(methods),
        "methods_tested": methods_tested,
        "untested_methods": untested_methods,
        "go_test_count": go_count,
        "dart_test_count": dart_count,
        "coverage_pct": round(coverage_pct, 1),
    }


def analyze_all_contracts(
    *,
    contract_names: list[str] | None = None,
) -> list[dict]:
    """Analyze test coverage for all contracts."""
    if contract_names is None:
        contract_names = EMBEDDED_CONTRACTS
    return [analyze_contract(name) for name in contract_names]


def get_gaps(results: list[dict]) -> list[dict]:
    """Extract contracts with coverage gaps.

    Returns list of dicts with contract_name and untested_methods.
    """
    gaps = []
    for r in results:
        if r["untested_methods"]:
            gaps.append(
                {
                    "contract_name": r["contract_name"],
                    "untested_methods": r["untested_methods"],
                    "coverage_pct": r["coverage_pct"],
                }
            )
    return gaps


def persist_coverage(
    results: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist test coverage results to database.

    Returns number of records inserted.
    """
    count = 0
    for r in results:
        # Go coverage
        rid = persist_metric(
            db_path=db_path,
            table="test_coverage",
            data={
                "contract_name": r["contract_name"],
                "language": "go",
                "test_count": r["go_test_count"],
                "methods_tested": r["methods_tested"],
                "methods_total": r["methods_total"],
                "coverage_pct": r["coverage_pct"],
            },
        )
        if rid > 0:
            count += 1

        # Dart coverage
        rid = persist_metric(
            db_path=db_path,
            table="test_coverage",
            data={
                "contract_name": r["contract_name"],
                "language": "dart",
                "test_count": r["dart_test_count"],
                "methods_tested": r["methods_tested"],
                "methods_total": r["methods_total"],
                "coverage_pct": r["coverage_pct"],
            },
        )
        if rid > 0:
            count += 1

    return count


def get_coverage_summary(*, db_path: str = DEFAULT_DB) -> dict:
    """Get a summary of test coverage across all contracts."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT contract_name, language,
                      MAX(test_count) as test_count,
                      MAX(methods_tested) as methods_tested,
                      MAX(methods_total) as methods_total,
                      MAX(coverage_pct) as coverage_pct
               FROM test_coverage
               GROUP BY contract_name, language
               ORDER BY contract_name, language"""
        ).fetchall()
        return {f"{row['contract_name']}_{row['language']}": dict(row) for row in rows}
    finally:
        conn.close()
