# SPDX-License-Identifier: MIT
"""
SpecVerifier -- ABI and struct field verification across Go and Dart.

Automates the manual ABI comparison process:
1. Reads go-zenon ABI JSON for a contract (from definition files)
2. Reads Dart SDK ABI definition string
3. Byte-level comparison of ABI hashes
4. Reads Go struct JSON tags vs Dart fromJson keys
5. Reports MATCH or MISMATCH per field
"""

import hashlib
import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.persistence import connect
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

GO_ZENON_PATHS = [
    ZENON_WORKSPACE / "core" / "go-zenon",
    ZENON_WORKSPACE / "network" / "go-zenon",
]

DART_SDK_PATHS = [
    ZENON_WORKSPACE / "sdk" / "znn_sdk_dart",
]

# Pattern to extract ABI JSON from Go definition files
GO_ABI_PATTERN = re.compile(
    r"(?:ABIVariable|abiDefinition|ABIContract)\s*(?:,\s*_)?\s*=\s*"
    r"abi\.JSONToABI(?:Contract)?\s*\(\s*`([^`]+)`\s*\)",
    re.DOTALL,
)

# Simpler pattern: find JSON arrays in backtick strings
GO_ABI_JSON_PATTERN = re.compile(
    r'`(\s*\[\s*\{[^`]*"type"\s*:\s*"function"[^`]*\}[^`]*\])\s*`',
    re.DOTALL,
)

# Pattern to extract ABI string from Dart SDK
DART_ABI_PATTERN = re.compile(
    r"String\s+\w*[Aa][Bb][Ii]\w*\s*=\s*'([^']+)'",
    re.DOTALL,
)

# Alternative: Dart triple-quote ABI
DART_ABI_TRIPLE_PATTERN = re.compile(
    r'String\s+\w*[Aa][Bb][Ii]\w*\s*=\s*"""([^"]+)"""',
    re.DOTALL,
)

# Go struct JSON tag pattern
GO_JSON_TAG_PATTERN = re.compile(
    r'(\w+)\s+\w+.*?`json:"(\w+)(?:,\w+)*"`',
)

# Dart fromJson key pattern
DART_FROM_JSON_PATTERN = re.compile(
    r"(\w+)\s*=\s*json\s*\[\s*'(\w+)'\s*\]",
)


def _find_go_definition(contract_name: str) -> Path | None:
    """Find the Go definition file for a contract."""
    for go_zenon in GO_ZENON_PATHS:
        path = go_zenon / "vm" / "embedded" / "definition" / f"{contract_name}.go"
        if path.is_file():
            return path
    return None


def _find_dart_abi_file(contract_name: str) -> Path | None:
    """Find the Dart SDK file containing ABI for a contract."""
    for sdk_path in DART_SDK_PATHS:
        if not sdk_path.is_dir():
            continue
        # Search in lib/src/model/embedded/ and lib/src/abi/
        for search_dir in [
            sdk_path / "lib" / "src" / "abi",
            sdk_path / "lib" / "src" / "model" / "embedded",
        ]:
            if not search_dir.is_dir():
                continue
            for dart_file in search_dir.glob("*.dart"):
                if contract_name in dart_file.stem.lower():
                    return dart_file
    return None


def extract_go_abi_json(contract_name: str) -> str | None:
    """Extract the raw ABI JSON string from a Go definition file."""
    path = _find_go_definition(contract_name)
    if path is None:
        return None
    try:
        content = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None

    # Try the specific pattern first
    match = GO_ABI_PATTERN.search(content)
    if match:
        return match.group(1).strip()

    # Fall back to finding JSON arrays
    match = GO_ABI_JSON_PATTERN.search(content)
    if match:
        return match.group(1).strip()

    return None


def extract_dart_abi_string(contract_name: str) -> str | None:
    """Extract the ABI string from the Dart SDK."""
    path = _find_dart_abi_file(contract_name)
    if path is None:
        return None
    try:
        content = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None

    match = DART_ABI_PATTERN.search(content)
    if match:
        return match.group(1).strip()

    match = DART_ABI_TRIPLE_PATTERN.search(content)
    if match:
        return match.group(1).strip()

    return None


def compare_abi_bytes(go_abi: str, dart_abi: str) -> dict:
    """Byte-level comparison of ABI strings.

    Returns dict with: match (bool), go_hash, dart_hash, go_len, dart_len.
    """
    # Normalize whitespace for fair comparison
    go_norm = re.sub(r"\s+", "", go_abi)
    dart_norm = re.sub(r"\s+", "", dart_abi)

    go_hash = hashlib.sha256(go_norm.encode()).hexdigest()
    dart_hash = hashlib.sha256(dart_norm.encode()).hexdigest()

    return {
        "match": go_hash == dart_hash,
        "go_hash": go_hash,
        "dart_hash": dart_hash,
        "go_len": len(go_norm),
        "dart_len": len(dart_norm),
    }


def extract_go_json_tags(contract_name: str) -> dict[str, str]:
    """Extract Go struct field JSON tags.

    Returns dict of field_name -> json_tag.
    """
    tags = {}
    for go_zenon in GO_ZENON_PATHS:
        for subdir in ("definition", "implementation"):
            path = go_zenon / "vm" / "embedded" / subdir / f"{contract_name}.go"
            if not path.is_file():
                continue
            try:
                content = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            for match in GO_JSON_TAG_PATTERN.finditer(content):
                tags[match.group(1)] = match.group(2)
    return tags


def extract_dart_from_json_keys(contract_name: str) -> dict[str, str]:
    """Extract Dart fromJson key mappings.

    Returns dict of field_name -> json_key.
    """
    keys = {}
    path = _find_dart_abi_file(contract_name)
    if path is None:
        return keys
    try:
        content = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return keys

    for match in DART_FROM_JSON_PATTERN.finditer(content):
        keys[match.group(1)] = match.group(2)
    return keys


def compare_json_fields(
    go_tags: dict[str, str],
    dart_keys: dict[str, str],
) -> list[dict]:
    """Compare Go JSON tags against Dart fromJson keys.

    Returns list of comparison results per field.
    """
    results = []
    all_json_keys = set(go_tags.values()) | set(dart_keys.values())

    for json_key in sorted(all_json_keys):
        go_fields = [f for f, t in go_tags.items() if t == json_key]
        dart_fields = [f for f, k in dart_keys.items() if k == json_key]

        results.append(
            {
                "json_key": json_key,
                "go_fields": go_fields,
                "dart_fields": dart_fields,
                "in_go": len(go_fields) > 0,
                "in_dart": len(dart_fields) > 0,
                "match": len(go_fields) > 0 and len(dart_fields) > 0,
            }
        )

    return results


def verify_contract(contract_name: str) -> dict:
    """Run full ABI and field verification for a contract.

    Returns a dict with:
        - contract_name
        - abi_comparison: result of byte-level ABI comparison (or None)
        - field_comparison: list of field comparison results
        - go_definition_found, dart_definition_found
    """
    result = {
        "contract_name": contract_name,
        "go_definition_found": False,
        "dart_definition_found": False,
        "abi_comparison": None,
        "field_comparison": [],
    }

    go_abi = extract_go_abi_json(contract_name)
    dart_abi = extract_dart_abi_string(contract_name)

    if go_abi is not None:
        result["go_definition_found"] = True
    if dart_abi is not None:
        result["dart_definition_found"] = True

    if go_abi and dart_abi:
        result["abi_comparison"] = compare_abi_bytes(go_abi, dart_abi)

    go_tags = extract_go_json_tags(contract_name)
    dart_keys = extract_dart_from_json_keys(contract_name)
    if go_tags or dart_keys:
        result["field_comparison"] = compare_json_fields(go_tags, dart_keys)

    return result


def verify_all_contracts(contract_names: list[str]) -> list[dict]:
    """Run verification for all given contracts."""
    return [verify_contract(name) for name in contract_names]


def persist_verification(
    results: list[dict],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist consistency check results to consistency_checks table.

    Returns number of records inserted.
    """
    conn = connect(db_path)
    count = 0
    try:
        for r in results:
            name = r["contract_name"]

            # ABI comparison
            if r.get("abi_comparison"):
                abi = r["abi_comparison"]
                conn.execute(
                    """INSERT INTO consistency_checks
                       (check_type, contract_name, item_name,
                        repo_a, value_a, repo_b, value_b, match)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        "abi_bytes",
                        name,
                        "abi_json",
                        "go-zenon",
                        abi["go_hash"],
                        "znn_sdk_dart",
                        abi["dart_hash"],
                        abi["match"],
                    ),
                )
                count += 1

            # Field comparisons
            for fc in r.get("field_comparison", []):
                conn.execute(
                    """INSERT INTO consistency_checks
                       (check_type, contract_name, item_name,
                        repo_a, value_a, repo_b, value_b, match)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        "json_field",
                        name,
                        fc["json_key"],
                        "go-zenon",
                        ",".join(fc["go_fields"]),
                        "znn_sdk_dart",
                        ",".join(fc["dart_fields"]),
                        fc["match"],
                    ),
                )
                count += 1

        conn.commit()
        return count
    finally:
        conn.close()


# Default contract list — matches the set of TminusZ spec names the
# quality domain tracks today. Kept intentionally small; callers who
# need a different set should pass it explicitly.
_DEFAULT_CONTRACTS = [
    "htlc",
    "ptlc",
    "atomic_swap",
    "multisig",
    "streaming",
    "zns",
    "governance",
    "bitcoin_spv",
    "commit_channels",
]


def check_spec_verifier(
    db_path: str = DEFAULT_DB,
    contract_names: list[str] | None = None,
    **_kw,
) -> dict:
    """Scheduler entry point: verify spec consistency across go-zenon and SDK.

    Runs ``verify_all_contracts`` across the default contract list (or
    the list passed in) and persists the results. Returns a summary
    dict with counts. Degrades gracefully when the workspace is
    missing — returns an empty summary rather than raising.
    """
    contracts = contract_names or _DEFAULT_CONTRACTS
    try:
        results = verify_all_contracts(contracts)
        persisted = persist_verification(results, db_path=db_path)
    except Exception as exc:
        logger.debug("check_spec_verifier skipped: %s", exc)
        return {"engine": "spec_verifier", "checked": 0, "persisted": 0}
    return {
        "engine": "spec_verifier",
        "checked": len(results),
        "persisted": persisted,
    }
