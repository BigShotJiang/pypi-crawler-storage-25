# SPDX-License-Identifier: MIT
"""Forge Quality Domain -- Spec verification, build quality, and cross-repo consistency checks."""
