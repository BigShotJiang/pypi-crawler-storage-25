#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
Devnet integration test runner for Zenon embedded contracts.

Orchestrates the full test lifecycle:
1. Start a fresh devnet node
2. Wait for the node to begin producing momentums
3. Run all contract integration tests
4. Report results
5. Tear down the devnet

Exit codes:
    0 = all tests passed
    1 = one or more tests failed
    2 = devnet setup/teardown error

Usage:
    # Set the znnd binary path
    export ZENON_BINARY=/path/to/go-zenon/build/znnd

    # Optionally set genesis directory (auto-detected if not set)
    export ZENON_GENESIS_DIR=/path/to/full-devnet

    # Run all tests
    python3 test_runner.py

    # Run with custom ports (useful if default ports are in use)
    python3 test_runner.py --http-port 36997 --ws-port 36998

    # Skip full lifecycle tests (only run query/infrastructure tests)
    python3 test_runner.py --skip-lifecycle

    # Keep devnet running after tests (for debugging)
    python3 test_runner.py --keep-alive
"""

import argparse
import os
import sys
import time
from pathlib import Path

# Ensure the engines directory is on the Python path
ENGINES_DIR = Path(__file__).resolve().parent
if str(ENGINES_DIR) not in sys.path:
    sys.path.insert(0, str(ENGINES_DIR))

from domains.devops.infrastructure import (
    DevnetError,
    DevnetManager,
    ZenonRpcClient,
)
from domains.devops.test_suites import (
    FullLifecycleTests,
    get_all_test_classes,
    run_all_tests,
)

# ---------------------------------------------------------------------------
# Scheduler entry point (v0.3.2)
# ---------------------------------------------------------------------------
#
# The rest of this file is a long-running CLI harness that spins up a
# devnet, runs the full contract lifecycle test suite, and tears down
# — appropriate for `python3 test_runner.py` on an operator's workstation
# but NOT appropriate for the autonomous scheduler (takes minutes, needs
# shell access, needs binaries). Before v0.3.2 the engine was registered
# in DevOpsDomain.get_engines() but there was no zero-required-arg
# function matching the entry-point discovery prefixes, so the scheduler
# skipped it every cycle — exactly the "dead engine" class of bug that
# `test_autonomous_cycle_smoke.py::TestEntryPointSmoke` catches.
#
# The wrapper below is a fast readiness check: does the devnet binary
# exist, is it executable, is the genesis directory present? It emits
# a finding describing devnet readiness without actually starting a
# devnet. Operators who want the full lifecycle run still invoke
# `python3 domains/devops/engines/test_runner.py` by hand.


def check_devnet_readiness(db_path: str | None = None) -> dict:
    """Report devnet availability as a finding (fast, no devnet started).

    Checks:
    - ZENON_BINARY env var points to an existing executable file
    - Optional ZENON_GENESIS_DIR points to an existing directory
    - The expected go-zenon path exists in the workspace

    Persists one finding describing readiness so the war room + CLI
    can surface "devnet ready / devnet missing" without an operator
    having to run the full harness.

    Args:
        db_path: SQLite DB path (defaults to DEFAULT_DB).

    Returns:
        Summary dict with ``ready`` (bool), ``details`` (list of
        readiness checks), ``findings_persisted``.
    """
    from core.persistence.findings import persist_finding
    from core.persistence.schema import DEFAULT_DB
    from core.workspace import workspace_repo

    db_path = db_path or DEFAULT_DB
    checks: list[tuple[str, bool, str]] = []

    binary_env = os.environ.get("ZENON_BINARY", "")
    if binary_env:
        bp = Path(binary_env)
        checks.append(
            (
                "ZENON_BINARY",
                bp.is_file() and os.access(bp, os.X_OK),
                str(bp),
            )
        )
    else:
        # Fall back to checking for a built binary in the go-zenon repo
        gz = workspace_repo("core/go-zenon") or workspace_repo("network/go-zenon")
        if gz:
            candidate = Path(gz) / "build" / "znnd"
            checks.append(
                (
                    "workspace go-zenon build/znnd",
                    candidate.is_file() and os.access(candidate, os.X_OK),
                    str(candidate),
                )
            )
        else:
            checks.append(("ZENON_BINARY", False, "unset; no workspace go-zenon"))

    genesis_env = os.environ.get("ZENON_GENESIS_DIR", "")
    if genesis_env:
        gp = Path(genesis_env)
        checks.append(("ZENON_GENESIS_DIR", gp.is_dir(), str(gp)))

    ready = all(ok for _, ok, _ in checks) and len(checks) > 0

    detail_lines = "\n".join(
        f"  - {name}: {'OK' if ok else 'MISSING'} ({path})" for name, ok, path in checks
    )
    if ready:
        body = (
            f"WHAT: Devnet readiness checks passed ({len(checks)} checks). "
            f"The full devnet integration harness "
            f"(`python3 domains/devops/engines/test_runner.py`) can be "
            f"run against the current binary without further setup.\n"
            f"{detail_lines}\n"
            f"SO WHAT: The full contract lifecycle test suite exercises "
            f"every embedded contract against a real consensus loop. "
            f"Keeping it runnable on-demand is what lets operators "
            f"verify a wheel before shipping it to mainnet users. "
            f"NOW WHAT: Run the full harness periodically (weekly or "
            f"before any release) to keep the devnet path warm."
        )
        severity = "info"
    else:
        body = (
            f"WHAT: Devnet readiness checks FAILED. The full devnet "
            f"integration harness can't run in the current environment.\n"
            f"{detail_lines}\n"
            f"SO WHAT: Without a working devnet binary the integration "
            f"test suite can't exercise embedded contracts against a "
            f"real consensus loop, so any 'test_runner' engine runs "
            f"are skipped until this is fixed. "
            f"NOW WHAT: Either set ZENON_BINARY to a built znnd binary, "
            f"or build the go-zenon workspace repo "
            f"(`cd core/go-zenon && go build ./cmd/znnd`)."
        )
        severity = "warning"

    persisted = 0
    try:
        row = persist_finding(
            db_path=db_path,
            domain="devops",
            engine="test_runner",
            evidence_type="devnet_readiness",
            finding=body,
            confidence=0.90 if ready else 0.70,
            source_repo="go-zenon",
            raw_data={"checks": [{"name": n, "ok": ok, "path": p} for n, ok, p in checks]},
        )
        if row and row > 0:
            persisted += 1
    except Exception as exc:
        # Graceful degradation — the readiness finding is informational,
        # so a persist failure here (e.g. DB locked) shouldn't take the
        # scheduler down. Log at debug so real problems still surface.
        import logging

        logging.getLogger(__name__).debug("devnet readiness persist failed: %s", exc)

    return {
        "ready": ready,
        "severity": severity,
        "details": [{"name": n, "ok": ok, "path": p} for n, ok, p in checks],
        "findings_persisted": persisted,
    }


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Run Zenon devnet integration tests",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--znnd-binary",
        default=None,
        help="Path to znnd binary (overrides ZENON_BINARY env var)",
    )
    parser.add_argument(
        "--genesis-dir",
        default=None,
        help="Path to devnet genesis directory (overrides ZENON_GENESIS_DIR)",
    )
    parser.add_argument(
        "--http-port",
        type=int,
        default=35997,
        help="HTTP RPC port (default: 35997)",
    )
    parser.add_argument(
        "--ws-port",
        type=int,
        default=35998,
        help="WebSocket RPC port (default: 35998)",
    )
    parser.add_argument(
        "--p2p-port",
        type=int,
        default=35995,
        help="P2P port (default: 35995)",
    )
    parser.add_argument(
        "--startup-timeout",
        type=float,
        default=30.0,
        help="Seconds to wait for devnet to start (default: 30)",
    )
    parser.add_argument(
        "--skip-lifecycle",
        action="store_true",
        help="Skip full lifecycle tests (requires tx signing)",
    )
    parser.add_argument(
        "--keep-alive",
        action="store_true",
        help="Keep devnet running after tests for debugging",
    )
    parser.add_argument(
        "--data-dir",
        default=None,
        help="Use a specific data directory (default: temp dir)",
    )
    return parser.parse_args()


def print_banner() -> None:
    """Print the test runner banner."""
    print()
    print("=" * 70)
    print("  ZENON DEVNET INTEGRATION TEST RUNNER")
    print("=" * 70)
    print()


def print_summary(suites: list) -> int:
    """Print test summary and return exit code."""
    print()
    print("=" * 70)
    print("  TEST RESULTS SUMMARY")
    print("=" * 70)
    print()

    total_passed = 0
    total_failed = 0

    for suite in suites:
        status = "PASS" if suite.all_passed else "FAIL"
        print(f"  [{status}] {suite.name}: {suite.passed}/{suite.total} passed")

        for result in suite.results:
            if not result.passed:
                print(f"         FAIL: {result.name}")
                # Print first line of error message
                if result.message:
                    first_line = result.message.split("\n")[0]
                    print(f"               {first_line}")

        total_passed += suite.passed
        total_failed += suite.failed

    print()
    print(
        f"  Total: {total_passed + total_failed} tests, "
        f"{total_passed} passed, {total_failed} failed"
    )
    print("=" * 70)

    return 0 if total_failed == 0 else 1


def check_prerequisites(args: argparse.Namespace) -> None:
    """Check that all prerequisites are met before starting tests."""
    binary = args.znnd_binary or os.environ.get("ZENON_BINARY")
    if not binary:
        print("ERROR: znnd binary not specified.")
        print("  Set ZENON_BINARY environment variable or use --znnd-binary flag.")
        print()
        print("  Example:")
        print("    export ZENON_BINARY=/path/to/go-zenon/build/znnd")
        print("    python3 test_runner.py")
        sys.exit(2)

    if not os.path.isfile(binary):
        print(f"ERROR: znnd binary not found at: {binary}")
        print("  Build it with: cd go-zenon && make znnd")
        sys.exit(2)

    # Check for requests library
    try:
        import requests
    except ImportError:
        print("ERROR: 'requests' library required. Install with: pip3 install requests")
        sys.exit(2)

    # Check for optional websocket library
    try:
        import websocket

        print("WebSocket library available (will use WS transport)")
    except ImportError:
        print("WebSocket library not found (will use HTTP transport)")
        print("  Install for better performance: pip3 install websocket-client")

    print()


def main() -> int:
    """Entry point for the test runner."""
    args = parse_args()
    print_banner()
    check_prerequisites(args)

    devnet = None
    rpc = None

    try:
        # ------------------------------------------------------------------
        # Phase 1: Start devnet
        # ------------------------------------------------------------------
        print("Phase 1: Starting devnet...")
        print()

        devnet = DevnetManager(
            znnd_binary=args.znnd_binary,
            genesis_dir=args.genesis_dir,
            http_port=args.http_port,
            ws_port=args.ws_port,
            p2p_port=args.p2p_port,
            data_dir=args.data_dir,
        )
        devnet.start_devnet(timeout=args.startup_timeout)

        # Wait for a few momentums to ensure the chain is advancing
        print("Waiting for initial momentums...")
        devnet.wait_for_momentum(3, timeout=30)
        status = devnet.get_status()
        print(f"Devnet ready at height {status['height']}")
        print()

        # ------------------------------------------------------------------
        # Phase 2: Run tests
        # ------------------------------------------------------------------
        print("Phase 2: Running integration tests...")

        rpc = ZenonRpcClient(
            ws_url=devnet.ws_url,
            http_url=devnet.http_url,
        )

        if args.skip_lifecycle:
            # Run only infrastructure and per-contract query tests
            suites = []
            for cls in get_all_test_classes():
                if cls is FullLifecycleTests:
                    continue
                test = cls(rpc, devnet)
                suites.append(test.run_all())
        else:
            suites = run_all_tests(rpc, devnet)

        # ------------------------------------------------------------------
        # Phase 3: Report results
        # ------------------------------------------------------------------
        exit_code = print_summary(suites)

        # ------------------------------------------------------------------
        # Phase 4: Teardown
        # ------------------------------------------------------------------
        if args.keep_alive:
            print()
            print("Devnet still running (--keep-alive):")
            print(f"  HTTP: {devnet.http_url}")
            print(f"  WS:   {devnet.ws_url}")
            print(f"  Data: {devnet.data_dir}")
            print(f"  PID:  {devnet._process.pid if devnet._process else 'unknown'}")
            print()
            print("Press Ctrl+C to stop the devnet and exit.")
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print("\nShutting down...")
        else:
            print()
            print("Phase 4: Tearing down devnet...")

        return exit_code

    except DevnetError as e:
        print(f"\nDEVNET ERROR: {e}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
        return 2
    except Exception as e:
        print(f"\nUNEXPECTED ERROR: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return 2
    finally:
        if rpc:
            rpc.close()
        if devnet and devnet.is_running and not args.keep_alive:
            devnet.stop_devnet()


if __name__ == "__main__":
    sys.exit(main())
