# SPDX-License-Identifier: MIT
"""
integration_tests -- Engine shim that re-exports the devnet test suites.

The actual integration test classes and runner live in
:mod:`domains.devops.test_suites` so that peer engines
(:mod:`domains.devops.engines.test_runner`) can consume them without
importing across engine boundaries.

This shim stays in place because the engine scheduler discovers engines
by module path (``domains.devops.engines.integration_tests``) and looks
for the ``run_all_tests`` entry point in this module.
"""

from domains.devops.test_suites import (
    EMBEDDED_CONTRACTS,
    REQUIRED_SPORKS,
    AssertionError,
    AtomicSwapTests,
    ContractTest,
    DevnetInfrastructureTests,
    FullLifecycleTests,
    GovernanceTests,
    MultisigTests,
    PtlcTests,
    StreamingTests,
    TestResult,
    TestSuite,
    ZnsTests,
    get_all_test_classes,
    run_all_tests,
)

__all__ = [
    "EMBEDDED_CONTRACTS",
    "REQUIRED_SPORKS",
    "AssertionError",
    "AtomicSwapTests",
    "ContractTest",
    "DevnetInfrastructureTests",
    "FullLifecycleTests",
    "GovernanceTests",
    "MultisigTests",
    "PtlcTests",
    "StreamingTests",
    "TestResult",
    "TestSuite",
    "ZnsTests",
    "get_all_test_classes",
    "run_all_tests",
    "run_integration_tests",
]


def run_integration_tests(db_path: str | None = None) -> dict:
    """Scheduler-friendly wrapper around :func:`run_all_tests`.

    The underlying ``run_all_tests`` requires both an ``rpc`` client and
    a ``DevnetManager``; those in turn require a running ``znnd`` binary
    on disk. In most Nebula runs the devnet is not spun up, so we
    probe for it and report a structured skip instead of crashing the
    cycle.

    Returns:
        A dict describing what happened: either a ``status="ran"`` block
        with suite counts, or a ``status="skipped"`` block with the
        reason so the autonomous runner can still persist an action.
    """
    from domains.devops.infrastructure import DevnetManager, ZenonRpcClient

    # Probe for an existing running devnet at the default ports first.
    try:
        rpc = ZenonRpcClient()
    except Exception as exc:  # pragma: no cover — defensive
        return {
            "status": "skipped",
            "reason": f"rpc_client_init_failed: {exc}",
        }

    try:
        ledger_info = rpc.call("ledger.getFrontierMomentum") or {}
    except Exception as exc:
        return {
            "status": "skipped",
            "reason": "devnet_not_running",
            "probe_error": str(exc)[:200],
        }

    # Devnet is reachable — proceed with suite run using default manager.
    try:
        devnet = DevnetManager()
    except Exception as exc:  # pragma: no cover — defensive
        return {
            "status": "skipped",
            "reason": f"devnet_manager_init_failed: {exc}",
        }

    try:
        suites = run_all_tests(rpc=rpc, devnet=devnet)
    except Exception as exc:
        return {
            "status": "error",
            "reason": str(exc)[:200],
        }

    passed = sum(
        1 for suite in suites for r in getattr(suite, "results", []) if getattr(r, "passed", False)
    )
    failed = sum(
        1
        for suite in suites
        for r in getattr(suite, "results", [])
        if not getattr(r, "passed", True)
    )
    return {
        "status": "ran",
        "suites": len(suites),
        "passed": passed,
        "failed": failed,
        "frontier_height": ledger_info.get("height") if isinstance(ledger_info, dict) else None,
    }
