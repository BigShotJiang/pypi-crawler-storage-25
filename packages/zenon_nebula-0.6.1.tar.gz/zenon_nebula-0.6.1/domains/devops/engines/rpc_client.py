# SPDX-License-Identifier: MIT
"""
rpc_client -- Engine shim that re-exports the shared JSON-RPC client.

The full :class:`ZenonRpcClient` implementation now lives in
:mod:`domains.devops.infrastructure`. This shim keeps the module path
available for the engine scheduler and for any callers that still
import ``ZenonRpcClient`` or ``RpcError`` from here.
"""

from domains.devops.infrastructure import (
    HAS_WEBSOCKET,
    RpcError,
    ZenonRpcClient,
)

__all__ = [
    "HAS_WEBSOCKET",
    "RpcError",
    "ZenonRpcClient",
    "check_rpc_client",
]


def check_rpc_client(db_path: str | None = None, **_kw) -> dict:
    """Scheduler entry point: report whether the RPC client is importable.

    Does not open a connection to any node on its own — connecting is
    the caller's responsibility. Returns a minimal status dict so the
    scheduler has something to log.
    """
    return {
        "engine": "rpc_client",
        "has_websocket": bool(HAS_WEBSOCKET),
        "client_available": ZenonRpcClient is not None,
    }
