# SPDX-License-Identifier: MIT
"""
devnet_manager -- Engine shim that re-exports the shared devnet layer.

Historically this module owned the devnet constants and the
:class:`DevnetManager` class. That code now lives in
:mod:`domains.devops.infrastructure` so other engines can depend on it
without importing from peer engine modules.

This file stays in place because the engine scheduler discovers engines
by module path (``domains.devops.engines.devnet_manager``). Callers that
still import ``DevnetManager``, ``DevnetError``, or any of the contract
address / token standard constants from here continue to work via the
re-exports below.
"""

from domains.devops.infrastructure import (
    ATOMIC_SWAP_CONTRACT,
    DEFAULT_HTTP_PORT,
    DEFAULT_P2P_PORT,
    DEFAULT_WS_PORT,
    DEVNET_FUNDED_ADDRESS,
    DEVNET_PRODUCER_ADDRESS,
    DEVNET_WALLET_PASSWORD,
    GENESIS_SPORKS,
    GOVERNANCE_CONTRACT,
    MULTISIG_CONTRACT,
    PILLAR_CONTRACT,
    PTLC_CONTRACT,
    QSR_TOKEN_STANDARD,
    SPORK_CONTRACT,
    STREAMING_CONTRACT,
    ZNN_TOKEN_STANDARD,
    ZNS_CONTRACT,
    DevnetError,
    DevnetManager,
)

__all__ = [
    "ATOMIC_SWAP_CONTRACT",
    "DEFAULT_HTTP_PORT",
    "DEFAULT_P2P_PORT",
    "DEFAULT_WS_PORT",
    "DEVNET_FUNDED_ADDRESS",
    "DEVNET_PRODUCER_ADDRESS",
    "DEVNET_WALLET_PASSWORD",
    "GENESIS_SPORKS",
    "GOVERNANCE_CONTRACT",
    "MULTISIG_CONTRACT",
    "PILLAR_CONTRACT",
    "PTLC_CONTRACT",
    "QSR_TOKEN_STANDARD",
    "SPORK_CONTRACT",
    "STREAMING_CONTRACT",
    "ZNN_TOKEN_STANDARD",
    "ZNS_CONTRACT",
    "DevnetError",
    "DevnetManager",
    "check_devnet_status",
]


def check_devnet_status(db_path: str | None = None, **_kw) -> dict:
    """Scheduler entry point: report whether a devnet manager is available.

    The devnet manager does not auto-start a node on every cycle — that
    would be destructive. Instead this entry point reports whether the
    manager layer is importable and whether a node process appears to
    be running. The full lifecycle (start/stop/deploy) is exercised by
    tests and on-demand by the scheduler when the integration test
    engine needs a live node.
    """
    from domains.devops.infrastructure import DevnetManager as _DM

    try:
        mgr = _DM()
        status = mgr.status() if hasattr(mgr, "status") else {"available": True}
    except Exception as exc:
        status = {"available": False, "error": str(exc)}
    return {"engine": "devnet_manager", "status": status}
