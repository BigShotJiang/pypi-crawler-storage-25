# SPDX-License-Identifier: MIT
"""
Integration tests for Zenon embedded contracts on a live devnet.

Each contract test follows the full lifecycle pattern observed in the Go
unit tests (go-zenon/vm/embedded/tests/), but against a real znnd node
instead of the in-memory mock.

IMPORTANT PREREQUISITES:
    The devnet genesis.json must pre-activate all required sporks.
    The Go mock tests activate sporks programmatically via InsertSendBlock,
    but on a real node we need either:
      (a) Pre-activated sporks in genesis, OR
      (b) A transaction signing library to send spork-create/activate txs

    The full-devnet genesis already has: az, htlc, bridge-liq
    For PTLC, Governance, AtomicSwap, Multisig, Streaming, ZNS you must
    add their sporks to genesis.json.  See REQUIRED_SPORKS below.

Devnet genesis accounts (from full-devnet/genesis.json):
    Producer/Spork: z1qrhfj5m3jqpt45x4jkhdszs5ug8p2f0qdlvqlr
        - Also the pillar "Local" block producer
        - Also the spork address (can create/activate sporks)

    Funded account:  z1qqjnwjjpnue8xmmpanz6csze6tcmtzzdtfsww7
        - 4000 ZNN (400000000000 base units)
        - 40000 QSR (4000000000000 base units)

    Accelerator:     z1qxemdeddedxaccelerat0rxxxxxxxxxxp4tk22
        - 77213.59999888 ZNN
        - 772135.99988800 QSR
"""

import time
import traceback
from dataclasses import dataclass, field

from domains.devops.infrastructure import (
    ATOMIC_SWAP_CONTRACT,
    DEVNET_FUNDED_ADDRESS,
    DEVNET_PRODUCER_ADDRESS,
    GENESIS_SPORKS,
    GOVERNANCE_CONTRACT,
    MULTISIG_CONTRACT,
    PTLC_CONTRACT,
    SPORK_CONTRACT,
    STREAMING_CONTRACT,
    ZNS_CONTRACT,
    DevnetManager,
    RpcError,
    ZenonRpcClient,
)

# ---------------------------------------------------------------------------
# Sporks required by each contract (name -> description)
# These must be added to genesis.json SporkConfig.Sporks with activated=true
# ---------------------------------------------------------------------------

REQUIRED_SPORKS = {
    "ptlc": {
        "name": "spork-ptlc",
        "description": "activate spork for ptlc",
        "depends_on": ["htlc"],
    },
    "governance": {
        "name": "spork-governance",
        "description": "activate spork for governance",
        "depends_on": ["bitcoin-spv"],
    },
    "atomic-swap": {
        "name": "spork-atomic-swap",
        "description": "activate spork for atomic swap",
        "depends_on": ["governance"],
    },
    "multisig": {
        "name": "spork-multisig",
        "description": "activate spork for multisig",
        "depends_on": ["atomic-swap"],
    },
    "streaming": {
        "name": "spork-streaming",
        "description": "activate spork for streaming",
        "depends_on": ["multisig"],
    },
    "zns": {
        "name": "spork-zns",
        "description": "activate spork for zns",
        "depends_on": ["streaming"],
    },
}

# Embedded contract addresses (Zenon address format)
EMBEDDED_CONTRACTS = {
    "spork": SPORK_CONTRACT,
    "ptlc": PTLC_CONTRACT,
    "governance": GOVERNANCE_CONTRACT,
    "atomic-swap": ATOMIC_SWAP_CONTRACT,
    "multisig": MULTISIG_CONTRACT,
    "streaming": STREAMING_CONTRACT,
    "zns": ZNS_CONTRACT,
}


# ---------------------------------------------------------------------------
# Test result tracking
# ---------------------------------------------------------------------------


@dataclass
class TestResult:
    """Result of a single integration test."""

    name: str
    passed: bool
    message: str = ""
    duration: float = 0.0


@dataclass
class TestSuite:
    """Collection of integration test methods."""

    name: str
    results: list[TestResult] = field(default_factory=list)

    @property
    def passed(self) -> int:
        """Number of tests that passed."""
        return sum(1 for r in self.results if r.passed)

    @property
    def failed(self) -> int:
        """Number of tests that failed."""
        return sum(1 for r in self.results if not r.passed)

    @property
    def total(self) -> int:
        """Total number of tests."""
        return len(self.results)

    @property
    def all_passed(self) -> bool:
        """True if all tests passed."""
        return self.failed == 0


# ---------------------------------------------------------------------------
# Base test class
# ---------------------------------------------------------------------------


class ContractTest:
    """Base class for embedded contract integration tests."""

    def __init__(self, rpc: ZenonRpcClient, devnet: DevnetManager):
        self.rpc = rpc
        self.devnet = devnet
        self.suite = TestSuite(name=self.__class__.__name__)

    def run_test(self, name: str, test_fn) -> TestResult:
        """Run a single test function and record the result."""
        start = time.time()
        try:
            test_fn()
            duration = time.time() - start
            result = TestResult(name=name, passed=True, duration=duration)
            print(f"  PASS  {name} ({duration:.2f}s)")
        except Exception as e:
            duration = time.time() - start
            tb = traceback.format_exc()
            result = TestResult(
                name=name,
                passed=False,
                message=f"{e}\n{tb}",
                duration=duration,
            )
            print(f"  FAIL  {name} ({duration:.2f}s): {e}")
        self.suite.results.append(result)
        return result

    def wait_momentums(self, count: int = 2) -> None:
        """Wait for N momentums to be produced."""
        self.devnet.wait_for_momentums(count)

    def assert_equal(self, actual, expected, msg: str = "") -> None:
        """Assert two values are equal."""
        if actual != expected:
            raise AssertionError(f"{msg}: expected {expected!r}, got {actual!r}")

    def assert_true(self, condition: bool, msg: str = "") -> None:
        """Assert a value is truthy."""
        if not condition:
            raise AssertionError(f"Assertion failed: {msg}")

    def assert_not_none(self, value, msg: str = "") -> None:
        """Assert a value is not None."""
        if value is None:
            raise AssertionError(f"Expected non-None value: {msg}")

    def assert_raises(self, exc_type, fn, msg: str = "") -> None:
        """Assert that calling fn raises an exception."""
        try:
            fn()
            raise AssertionError(f"Expected {exc_type.__name__} but no exception raised: {msg}")
        except exc_type:
            pass

    def run_all(self) -> TestSuite:
        """Override in subclass to run all tests."""
        raise NotImplementedError


class AssertionError(Exception):
    """Test assertion failure (distinct from builtin AssertionError for clarity)."""


# ---------------------------------------------------------------------------
# Infrastructure tests (always run first)
# ---------------------------------------------------------------------------


class DevnetInfrastructureTests(ContractTest):
    """Tests that verify the devnet itself is working."""

    def run_all(self) -> TestSuite:
        """Run all tests in this suite and return results."""
        print(f"\n{'=' * 60}")
        print(f"Running: {self.suite.name}")
        print(f"{'=' * 60}")

        self.run_test("node_is_running", self.test_node_running)
        self.run_test("rpc_responds", self.test_rpc_responds)
        self.run_test("momentums_advancing", self.test_momentums_advancing)
        self.run_test("genesis_pillar_exists", self.test_pillar_exists)
        self.run_test("genesis_sporks_active", self.test_genesis_sporks)
        self.run_test("funded_account_has_balance", self.test_funded_account)
        self.run_test("producer_account_has_balance", self.test_producer_account)

        return self.suite

    def test_node_running(self) -> None:
        """Run a specific integration test."""
        status = self.devnet.get_status()
        self.assert_not_none(status, "get_status returned None")
        self.assert_true(status["running"], "Node is not running")

    def test_rpc_responds(self) -> None:
        """Run a specific integration test."""
        momentum = self.rpc.get_frontier_momentum()
        self.assert_not_none(momentum, "getFrontierMomentum returned None")
        self.assert_true(
            "height" in momentum,
            f"Momentum missing 'height' field: {momentum}",
        )

    def test_momentums_advancing(self) -> None:
        """Run a specific integration test."""
        m1 = self.rpc.get_frontier_momentum()
        h1 = m1["height"]
        self.devnet.wait_for_momentums(2)
        m2 = self.rpc.get_frontier_momentum()
        h2 = m2["height"]
        self.assert_true(h2 > h1, f"Momentums not advancing: {h1} -> {h2}")

    def test_pillar_exists(self) -> None:
        """Run a specific integration test."""
        pillars = self.rpc.pillar_get_all()
        self.assert_not_none(pillars, "pillar_get_all returned None")
        count = pillars.get("count", 0)
        self.assert_true(count >= 1, f"Expected at least 1 pillar, got {count}")

    def test_genesis_sporks(self) -> None:
        """Run a specific integration test."""
        sporks = self.rpc.spork_get_all()
        self.assert_not_none(sporks, "spork_get_all returned None")

        active_names = set()
        for s in sporks.get("list", []):
            if s.get("activated"):
                active_names.add(s["name"])

        for name in GENESIS_SPORKS:
            self.assert_true(
                name in active_names,
                f"Genesis spork '{name}' not found in active sporks: {active_names}",
            )

    def test_funded_account(self) -> None:
        """Run a specific integration test."""
        info = self.rpc.get_account_info_by_address(DEVNET_FUNDED_ADDRESS)
        self.assert_not_none(info, "Account info is None")

        # The genesis grants this address ZNN and QSR
        balances = info.get("balanceInfoMap", {})
        if balances:
            # Check that at least one token has a non-zero balance
            has_balance = any(int(v.get("balance", "0")) > 0 for v in balances.values())
            self.assert_true(
                has_balance,
                f"Funded account {DEVNET_FUNDED_ADDRESS} has no balance: {balances}",
            )
        # If balanceInfoMap is empty, the account simply hasn't received
        # blocks yet, which is OK for a fresh genesis

    def test_producer_account(self) -> None:
        """Run a specific integration test."""
        info = self.rpc.get_account_info_by_address(DEVNET_PRODUCER_ADDRESS)
        self.assert_not_none(info, "Producer account info is None")


# ---------------------------------------------------------------------------
# PTLC contract tests
# ---------------------------------------------------------------------------


class PtlcTests(ContractTest):
    """
    PTLC (Point Time-Locked Contract) lifecycle tests.

    Go test reference: go-zenon/vm/embedded/tests/ptlc_test.go
    Spork dependency chain: htlc -> ptlc

    Test flow:
    1. Verify PTLC spork is active
    2. Create PTLC (lock ZNN for recipient with point-lock)
    3. Query by ID, verify fields
    4. Unlock with correct scalar, verify funds moved
    5. Create another PTLC, let it expire, reclaim

    NOTE: Creating/unlocking PTLCs requires transaction signing.
    These tests verify the RPC query layer. Full lifecycle tests
    require a signing library or pre-submitted transactions.
    """

    def run_all(self) -> TestSuite:
        """Run all tests in this suite and return results."""
        print(f"\n{'=' * 60}")
        print(f"Running: {self.suite.name}")
        print(f"{'=' * 60}")

        self.run_test("ptlc_spork_check", self.test_spork_check)
        self.run_test("ptlc_query_nonexistent", self.test_query_nonexistent)
        self.run_test("ptlc_contract_address_valid", self.test_contract_address)

        return self.suite

    def test_spork_check(self) -> None:
        """Verify the PTLC spork is active (or document that it needs activation)."""
        sporks = self.rpc.spork_get_all()
        active = {s["name"]: s for s in sporks.get("list", []) if s.get("activated")}

        # PTLC requires htlc spork (already in genesis)
        self.assert_true(
            "htlc" in active,
            "HTLC spork (prerequisite for PTLC) is not active",
        )

        if "spork-ptlc" not in active:
            print(
                "    INFO: PTLC spork not pre-activated in genesis. "
                "Add to genesis.json SporkConfig.Sporks for full lifecycle testing."
            )

    def test_query_nonexistent(self) -> None:
        """Query a non-existent PTLC ID. Should return an error or null."""
        fake_id = "0000000000000000000000000000000000000000000000000000000000000000"
        try:
            self.rpc.ptlc_get_by_id(fake_id)
            # Some implementations return null for non-existent entries
            # rather than raising an error
        except RpcError:
            pass  # Expected: data non-existent

    def test_contract_address(self) -> None:
        """Verify the PTLC contract address is queryable."""
        info = self.rpc.get_account_info_by_address(PTLC_CONTRACT)
        self.assert_not_none(info, "PTLC contract address not queryable")


# ---------------------------------------------------------------------------
# Governance contract tests
# ---------------------------------------------------------------------------


class GovernanceTests(ContractTest):
    """
    Governance contract lifecycle tests.

    Go test reference: go-zenon/vm/embedded/tests/governance_test.go
    Spork dependency chain: htlc -> ptlc -> bitcoin-spv -> governance

    Test flow:
    1. Verify Governance spork is active
    2. Create proposal (from pillar address)
    3. Cast votes from pillars
    4. Wait for voting period to end
    5. Execute proposal, verify status changed
    """

    def run_all(self) -> TestSuite:
        """Run all tests in this suite and return results."""
        print(f"\n{'=' * 60}")
        print(f"Running: {self.suite.name}")
        print(f"{'=' * 60}")

        self.run_test("governance_spork_check", self.test_spork_check)
        self.run_test("governance_query_empty", self.test_query_empty)
        self.run_test("governance_contract_address_valid", self.test_contract_address)

        return self.suite

    def test_spork_check(self) -> None:
        """Run a specific integration test."""
        sporks = self.rpc.spork_get_all()
        active = {s["name"]: s for s in sporks.get("list", []) if s.get("activated")}

        if "spork-governance" not in active:
            print(
                "    INFO: Governance spork not pre-activated. "
                "Add to genesis.json for full lifecycle testing."
            )

    def test_query_empty(self) -> None:
        """Query proposals when none exist. Should return empty list."""
        try:
            result = self.rpc.governance_get_all_proposals()
            if result:
                count = result.get("count", 0)
                # Fresh devnet should have 0 proposals (or possibly some from genesis)
                self.assert_true(
                    isinstance(count, int),
                    f"Expected integer count, got: {type(count)}",
                )
        except RpcError as e:
            # If governance spork is not active, the RPC call may fail
            print(f"    INFO: Governance query failed (spork likely inactive): {e}")

    def test_contract_address(self) -> None:
        """Run a specific integration test."""
        info = self.rpc.get_account_info_by_address(GOVERNANCE_CONTRACT)
        self.assert_not_none(info, "Governance contract address not queryable")


# ---------------------------------------------------------------------------
# Atomic Swap contract tests
# ---------------------------------------------------------------------------


class AtomicSwapTests(ContractTest):
    """
    Atomic Swap contract lifecycle tests.

    Go test reference: go-zenon/vm/embedded/tests/atomic_swap_test.go
    Spork dependency chain: ... -> governance -> atomic-swap

    Test flow:
    1. Create swap (lock ZNN, specify counterparty and BTC tx hash)
    2. Claim with valid Merkle proof against BTC block header
    3. Create another, let expire, reclaim
    """

    def run_all(self) -> TestSuite:
        """Run all tests in this suite and return results."""
        print(f"\n{'=' * 60}")
        print(f"Running: {self.suite.name}")
        print(f"{'=' * 60}")

        self.run_test("atomic_swap_spork_check", self.test_spork_check)
        self.run_test("atomic_swap_query_nonexistent", self.test_query_nonexistent)
        self.run_test("atomic_swap_contract_address_valid", self.test_contract_address)

        return self.suite

    def test_spork_check(self) -> None:
        """Run a specific integration test."""
        sporks = self.rpc.spork_get_all()
        active = {s["name"]: s for s in sporks.get("list", []) if s.get("activated")}

        if "spork-atomic-swap" not in active:
            print(
                "    INFO: AtomicSwap spork not pre-activated. "
                "Add to genesis.json for full lifecycle testing."
            )

    def test_query_nonexistent(self) -> None:
        """Run a specific integration test."""
        fake_id = "0000000000000000000000000000000000000000000000000000000000000000"
        try:
            self.rpc.atomic_swap_get_by_id(fake_id)
        except RpcError:
            pass  # Expected

    def test_contract_address(self) -> None:
        """Run a specific integration test."""
        info = self.rpc.get_account_info_by_address(ATOMIC_SWAP_CONTRACT)
        self.assert_not_none(info, "AtomicSwap contract address not queryable")


# ---------------------------------------------------------------------------
# Multisig contract tests
# ---------------------------------------------------------------------------


class MultisigTests(ContractTest):
    """
    Multisig contract lifecycle tests.

    Go test reference: go-zenon/vm/embedded/tests/multisig_test.go
    Spork dependency chain: ... -> atomic-swap -> multisig

    Test flow:
    1. Create multisig wallet (2-of-3 with User1, User2, User3)
    2. Submit a proposal (transfer funds)
    3. Collect signatures from owners
    4. Execute when threshold reached
    """

    def run_all(self) -> TestSuite:
        """Run all tests in this suite and return results."""
        print(f"\n{'=' * 60}")
        print(f"Running: {self.suite.name}")
        print(f"{'=' * 60}")

        self.run_test("multisig_spork_check", self.test_spork_check)
        self.run_test("multisig_query_nonexistent", self.test_query_nonexistent)
        self.run_test("multisig_contract_address_valid", self.test_contract_address)

        return self.suite

    def test_spork_check(self) -> None:
        """Run a specific integration test."""
        sporks = self.rpc.spork_get_all()
        active = {s["name"]: s for s in sporks.get("list", []) if s.get("activated")}

        if "spork-multisig" not in active:
            print(
                "    INFO: Multisig spork not pre-activated. "
                "Add to genesis.json for full lifecycle testing."
            )

    def test_query_nonexistent(self) -> None:
        """Run a specific integration test."""
        fake_id = "0000000000000000000000000000000000000000000000000000000000000000"
        try:
            self.rpc.multisig_get_by_id(fake_id)
        except RpcError:
            pass  # Expected

    def test_contract_address(self) -> None:
        """Run a specific integration test."""
        info = self.rpc.get_account_info_by_address(MULTISIG_CONTRACT)
        self.assert_not_none(info, "Multisig contract address not queryable")


# ---------------------------------------------------------------------------
# Streaming contract tests
# ---------------------------------------------------------------------------


class StreamingTests(ContractTest):
    """
    Streaming payment contract lifecycle tests.

    Go test reference: go-zenon/vm/embedded/tests/streaming_test.go
    Spork dependency chain: ... -> multisig -> streaming

    Test flow:
    1. Create stream (User1 locks 1000 ZNN for User2, 1 hour duration)
    2. Wait for partial vesting
    3. Claim vested portion
    4. Wait for full vesting
    5. Claim remainder
    """

    def run_all(self) -> TestSuite:
        """Run all tests in this suite and return results."""
        print(f"\n{'=' * 60}")
        print(f"Running: {self.suite.name}")
        print(f"{'=' * 60}")

        self.run_test("streaming_spork_check", self.test_spork_check)
        self.run_test("streaming_query_nonexistent", self.test_query_nonexistent)
        self.run_test("streaming_contract_address_valid", self.test_contract_address)

        return self.suite

    def test_spork_check(self) -> None:
        """Run a specific integration test."""
        sporks = self.rpc.spork_get_all()
        active = {s["name"]: s for s in sporks.get("list", []) if s.get("activated")}

        if "spork-streaming" not in active:
            print(
                "    INFO: Streaming spork not pre-activated. "
                "Add to genesis.json for full lifecycle testing."
            )

    def test_query_nonexistent(self) -> None:
        """Run a specific integration test."""
        fake_id = "0000000000000000000000000000000000000000000000000000000000000000"
        try:
            self.rpc.streaming_get_by_id(fake_id)
        except RpcError:
            pass  # Expected

    def test_contract_address(self) -> None:
        """Run a specific integration test."""
        info = self.rpc.get_account_info_by_address(STREAMING_CONTRACT)
        self.assert_not_none(info, "Streaming contract address not queryable")


# ---------------------------------------------------------------------------
# ZNS contract tests
# ---------------------------------------------------------------------------


class ZnsTests(ContractTest):
    """
    Zenon Name Service (ZNS) contract lifecycle tests.

    Go test reference: go-zenon/vm/embedded/tests/zns_test.go
    Spork dependency chain: ... -> streaming -> zns

    Test flow:
    1. Register name "alice" (send 1 ZNN to ZNS contract)
    2. Resolve "alice", verify it returns the registrant address
    3. Register another name, update address, verify
    """

    def run_all(self) -> TestSuite:
        """Run all tests in this suite and return results."""
        print(f"\n{'=' * 60}")
        print(f"Running: {self.suite.name}")
        print(f"{'=' * 60}")

        self.run_test("zns_spork_check", self.test_spork_check)
        self.run_test("zns_resolve_nonexistent", self.test_resolve_nonexistent)
        self.run_test("zns_contract_address_valid", self.test_contract_address)

        return self.suite

    def test_spork_check(self) -> None:
        """Run a specific integration test."""
        sporks = self.rpc.spork_get_all()
        active = {s["name"]: s for s in sporks.get("list", []) if s.get("activated")}

        if "spork-zns" not in active:
            print(
                "    INFO: ZNS spork not pre-activated. "
                "Add to genesis.json for full lifecycle testing."
            )

    def test_resolve_nonexistent(self) -> None:
        """Resolve a name that does not exist."""
        try:
            self.rpc.zns_resolve_name("nonexistent-name-12345")
            # Should return null / empty for unregistered names
        except RpcError:
            pass  # Expected

    def test_contract_address(self) -> None:
        """Run a specific integration test."""
        info = self.rpc.get_account_info_by_address(ZNS_CONTRACT)
        self.assert_not_none(info, "ZNS contract address not queryable")


# ---------------------------------------------------------------------------
# Full lifecycle tests (require transaction signing capability)
# ---------------------------------------------------------------------------


class FullLifecycleTests(ContractTest):
    """
    Full end-to-end lifecycle tests that exercise create/query/mutate/verify
    flows against a live devnet.

    These tests require:
    1. All contract sporks pre-activated in genesis.json
    2. A transaction signing library (ed25519 + Zenon block construction)

    The tests below document the EXACT sequence that should be executed,
    matching the patterns from the Go test suite. When a signing library
    becomes available, uncomment the transaction-sending code.

    Go test reference addresses (from chain/genesis/mock/embedded_genesis.go):
        Spork:  derived from seed 0x01234567890123456789012345678900, index 1
        User1:  derived from seed 0x01234567890123456789012345678902, index 1
                Balance: 12000 ZNN, 120000 QSR
        User2:  derived from seed 0x01234567890123456789012345678902, index 2
                Balance: 8000 ZNN, 80000 QSR

    For the devnet (full-devnet/genesis.json):
        Producer/Spork: z1qrhfj5m3jqpt45x4jkhdszs5ug8p2f0qdlvqlr
        Funded:         z1qqjnwjjpnue8xmmpanz6csze6tcmtzzdtfsww7
                        4000 ZNN, 40000 QSR
    """

    def run_all(self) -> TestSuite:
        """Run all tests in this suite and return results."""
        print(f"\n{'=' * 60}")
        print(f"Running: {self.suite.name}")
        print(f"{'=' * 60}")

        self.run_test("ptlc_full_lifecycle", self.test_ptlc_lifecycle)
        self.run_test("governance_full_lifecycle", self.test_governance_lifecycle)
        self.run_test("atomic_swap_full_lifecycle", self.test_atomic_swap_lifecycle)
        self.run_test("multisig_full_lifecycle", self.test_multisig_lifecycle)
        self.run_test("streaming_full_lifecycle", self.test_streaming_lifecycle)
        self.run_test("zns_full_lifecycle", self.test_zns_lifecycle)

        return self.suite

    def test_ptlc_lifecycle(self) -> None:
        """
        Full PTLC lifecycle:
        1. Create PTLC: lock 10 ZNN from producer to funded_account
           - toAddress: PTLC contract
           - data: ABIPtlc.CreatePtlc(recipient, expirationTime, pointLock)
           - tokenStandard: ZNN
           - amount: 10 * 1e8
        2. Query by ID (= send block hash), verify fields match
        3. Unlock with correct scalar (0x0...01 -> generator point G)
           - data: ABIPtlc.UnlockPtlc(ptlcId, scalar)
        4. Verify funds moved to recipient
        5. Create another PTLC with short expiry
        6. Wait past expiration
        7. Reclaim via ABIPtlc.ReclaimPtlc(ptlcId)
        8. Verify funds returned to creator

        Test vectors (from ptlc_test.go):
            scalar:    0x0000...0001 (32 bytes)
            pointLock: 0x0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798 (33 bytes)
        """
        # Verify spork prerequisites
        sporks = self.rpc.spork_get_all()
        active_names = {s["name"] for s in sporks.get("list", []) if s.get("activated")}

        if "htlc" not in active_names:
            print("    SKIP: HTLC spork not active (prerequisite for PTLC)")
            return

        # Verify contract is queryable
        info = self.rpc.get_account_info_by_address(PTLC_CONTRACT)
        self.assert_not_none(info, "PTLC contract not reachable")

        print("    INFO: Full PTLC lifecycle requires transaction signing capability.")
        print("    The test sequence is documented in this method's docstring.")
        print("    To enable: implement ed25519 signing or add znn-cli integration.")

    def test_governance_lifecycle(self) -> None:
        """
        Full Governance lifecycle:
        1. Create proposal from pillar address:
           - toAddress: Governance contract
           - data: ABIGovernance.CreateProposal(title, description, url, votingPeriod)
           - votingPeriod: 4500 momentums
        2. Query proposal by ID, verify fields
        3. Cast YES vote from pillar:
           - data: ABIGovernance.Vote(proposalId, voteType=0 for YES)
        4. Wait for voting period to end (advance momentums)
        5. Execute proposal:
           - data: ABIGovernance.Execute(proposalId)
        6. Verify status changed to Executed
        """
        info = self.rpc.get_account_info_by_address(GOVERNANCE_CONTRACT)
        self.assert_not_none(info, "Governance contract not reachable")

        print("    INFO: Full Governance lifecycle requires transaction signing capability.")

    def test_atomic_swap_lifecycle(self) -> None:
        """
        Full Atomic Swap lifecycle:
        1. Create swap:
           - toAddress: AtomicSwap contract
           - data: ABIAtomicSwap.CreateSwap(counterparty, btcTxHash, expirationTime)
           - tokenStandard: ZNN, amount: 100 ZNN
        2. Query by ID, verify counterparty and status
        3. Claim with valid Bitcoin SPV proof:
           - data: ABIAtomicSwap.ClaimSwap(swapId, blockHeader, merkleProof, txIndex)
        4. Verify funds transferred to counterparty
        5. Create another swap with short expiry
        6. Wait past expiration
        7. Reclaim: ABIAtomicSwap.ReclaimSwap(swapId)
        8. Verify funds returned
        """
        info = self.rpc.get_account_info_by_address(ATOMIC_SWAP_CONTRACT)
        self.assert_not_none(info, "AtomicSwap contract not reachable")

        print("    INFO: Full AtomicSwap lifecycle requires transaction signing capability.")

    def test_multisig_lifecycle(self) -> None:
        """
        Full Multisig lifecycle:
        1. Create 2-of-3 multisig with User1, User2, User3:
           - toAddress: Multisig contract
           - data: ABIMultisig.CreateMultisig(threshold=2, ownerCount=3, owners)
           - owners: concatenated 20-byte addresses
        2. Query by ID, verify threshold and owners
        3. Submit proposal to transfer funds:
           - data: ABIMultisig.SubmitProposal(multisigId, toAddress, amount, token, data)
        4. Approve from User2:
           - data: ABIMultisig.ApproveProposal(proposalId)
        5. Execute (threshold reached):
           - data: ABIMultisig.ExecuteProposal(proposalId)
        6. Verify funds transferred
        """
        info = self.rpc.get_account_info_by_address(MULTISIG_CONTRACT)
        self.assert_not_none(info, "Multisig contract not reachable")

        print("    INFO: Full Multisig lifecycle requires transaction signing capability.")

    def test_streaming_lifecycle(self) -> None:
        """
        Full Streaming lifecycle:
        1. Create stream: User1 locks 1000 ZNN for User2, 1 hour:
           - toAddress: Streaming contract
           - data: ABIStreaming.CreateStream(recipient, startTime, endTime)
           - tokenStandard: ZNN, amount: 1000 ZNN
        2. Query by ID, verify sender/recipient/amount/times
        3. Advance time, claim vested portion:
           - data: ABIStreaming.ClaimStream(streamId)
        4. Verify partial payment received
        5. Advance past end time, claim remainder
        6. Verify stream fully claimed
        """
        info = self.rpc.get_account_info_by_address(STREAMING_CONTRACT)
        self.assert_not_none(info, "Streaming contract not reachable")

        print("    INFO: Full Streaming lifecycle requires transaction signing capability.")

    def test_zns_lifecycle(self) -> None:
        """
        Full ZNS lifecycle:
        1. Register name "alice":
           - toAddress: ZNS contract
           - data: ABIZns.RegisterName("alice")
           - tokenStandard: ZNN, amount: 1 ZNN (registration fee)
        2. Resolve "alice", verify it returns registrant address
        3. Get entry by name, verify owner
        4. Update name to point to different address:
           - data: ABIZns.UpdateName("alice", newAddress)
        5. Resolve again, verify updated
        """
        info = self.rpc.get_account_info_by_address(ZNS_CONTRACT)
        self.assert_not_none(info, "ZNS contract not reachable")

        print("    INFO: Full ZNS lifecycle requires transaction signing capability.")


# ---------------------------------------------------------------------------
# Module-level runner (used by test_runner.py)
# ---------------------------------------------------------------------------


def get_all_test_classes():
    """Return all test classes in execution order."""
    return [
        DevnetInfrastructureTests,
        PtlcTests,
        GovernanceTests,
        AtomicSwapTests,
        MultisigTests,
        StreamingTests,
        ZnsTests,
        FullLifecycleTests,
    ]


def run_all_tests(rpc: ZenonRpcClient, devnet: DevnetManager) -> list[TestSuite]:
    """Run all integration test suites and return results."""
    suites = []
    for cls in get_all_test_classes():
        test = cls(rpc, devnet)
        suite = test.run_all()
        suites.append(suite)
    return suites
