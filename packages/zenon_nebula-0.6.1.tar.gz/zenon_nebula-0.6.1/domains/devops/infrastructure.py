# SPDX-License-Identifier: MIT
"""
infrastructure -- Shared devops primitives: devnet lifecycle + RPC client.

Both :mod:`domains.devops.engines.devnet_manager` and
:mod:`domains.devops.engines.rpc_client` used to own separate pieces of
this layer, and :mod:`domains.devops.engines.integration_tests` +
:mod:`domains.devops.engines.test_runner` imported across engine
boundaries to glue everything together. That violated the plugin
architecture (engines should not depend on peer engines).

This module consolidates the shared layer in one place:

- Devnet constants (contract addresses, token standards, ports, default
  accounts, genesis spork set).
- :class:`DevnetError` + :class:`DevnetManager` -- znnd process lifecycle.
- :class:`RpcError` + :class:`ZenonRpcClient` -- JSON-RPC client (with
  WebSocket and HTTP transports).

The engine modules in ``domains/devops/engines/`` still exist because
the scheduler auto-discovers engines by ``module_path``; they are now
thin re-export shims around this infrastructure module.
"""

import atexit
import contextlib
import json
import logging
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

import requests

logger = logging.getLogger(__name__)


try:
    import websocket as ws_lib

    HAS_WEBSOCKET = True
except ImportError:
    HAS_WEBSOCKET = False


# ---------------------------------------------------------------------------
# Constants derived from full-devnet genesis
# ---------------------------------------------------------------------------

# Default ports (matches full-devnet/config.json)
DEFAULT_HTTP_PORT = 35997
DEFAULT_WS_PORT = 35998
DEFAULT_P2P_PORT = 35995

# The pillar / spork address in the devnet genesis
DEVNET_PRODUCER_ADDRESS = "z1qrhfj5m3jqpt45x4jkhdszs5ug8p2f0qdlvqlr"

# Pre-funded test account from genesis
DEVNET_FUNDED_ADDRESS = "z1qqjnwjjpnue8xmmpanz6csze6tcmtzzdtfsww7"

# Wallet password for the devnet producer keystore
DEVNET_WALLET_PASSWORD = "Don'tTrust.Verify"

# Token standards
ZNN_TOKEN_STANDARD = "zts1znnxxxxxxxxxxxxx9z4ulx"
QSR_TOKEN_STANDARD = "zts1qsrxxxxxxxxxxxxxmrhjll"

# Embedded contract addresses
SPORK_CONTRACT = "z1qxemdeddedxsp0rkxxxxxxxxxxxxxxxx956u48"
PILLAR_CONTRACT = "z1qxemdeddedxpyllarxxxxxxxxxxxxxxxsy3fmg"
PTLC_CONTRACT = "z1qxemdeddedxptlcxxxxxxxxxxxxxxxxx6lqady"
GOVERNANCE_CONTRACT = "z1qxemdeddedxg0vernancexxxxxxxxxxxklyh23"
ATOMIC_SWAP_CONTRACT = "z1qxemdeddedx2wrz6nvvvvvvvvvvvvvgv4am6a"
MULTISIG_CONTRACT = "z1qxemdeddedxmultysygxxxxxxxxxxxxx42zwd4"
STREAMING_CONTRACT = "z1qxemdeddedxstra6myngxxxxxxxxxxxxh2l7c8"
ZNS_CONTRACT = "z1qxemdeddedxznsxxxxxxxxxxxxxxxxxxgvdpj4"

# Pre-activated sporks in the devnet genesis
GENESIS_SPORKS = {
    "az": "6d2b1e6cb4025f2f45533f0fe22e9b7ce2014d91cc960471045fa64eee5a6ba3",
    "htlc": "ceb7e3808ef17ea910adda2f3ab547be4cdfb54de8400ce3683258d06be1354b",
    "bridge-liq": "ddd43466769461c5b5d109c639da0f50a7eeb96ad6e7274b1928a35c431d7b1b",
}


# ---------------------------------------------------------------------------
# Devnet lifecycle manager
# ---------------------------------------------------------------------------


class DevnetError(Exception):
    """Raised when devnet operations fail."""


class DevnetManager:
    """Manages a local znnd devnet node lifecycle."""

    def __init__(
        self,
        znnd_binary: str | None = None,
        genesis_dir: str | None = None,
        http_port: int = DEFAULT_HTTP_PORT,
        ws_port: int = DEFAULT_WS_PORT,
        p2p_port: int = DEFAULT_P2P_PORT,
        data_dir: str | None = None,
    ):
        self.znnd_binary = znnd_binary or os.environ.get("ZENON_BINARY")
        if not self.znnd_binary:
            raise DevnetError(
                "ZENON_BINARY environment variable not set and no binary path provided. "
                "Point it at the znnd binary, e.g. /path/to/go-zenon/build/znnd"
            )

        self.znnd_binary = str(Path(self.znnd_binary).resolve())
        if not os.path.isfile(self.znnd_binary):
            raise DevnetError(f"znnd binary not found at {self.znnd_binary}")

        # Genesis directory with genesis.json + wallet/
        self.genesis_dir = genesis_dir or os.environ.get("ZENON_GENESIS_DIR")
        if not self.genesis_dir:
            # Try the canonical location relative to the binary
            candidate = Path(self.znnd_binary).resolve().parent.parent.parent / "full-devnet"
            if candidate.is_dir():
                self.genesis_dir = str(candidate)
            else:
                raise DevnetError(
                    "ZENON_GENESIS_DIR not set and full-devnet directory not found. "
                    "Set ZENON_GENESIS_DIR to the directory containing genesis.json and wallet/"
                )

        self.genesis_file = os.path.join(self.genesis_dir, "genesis.json")
        self.wallet_source = os.path.join(self.genesis_dir, "wallet")

        if not os.path.isfile(self.genesis_file):
            raise DevnetError(f"genesis.json not found at {self.genesis_file}")

        self.http_port = http_port
        self.ws_port = ws_port
        self.p2p_port = p2p_port

        # Working data directory (fresh per run unless overridden)
        if data_dir:
            self._data_dir_obj = None
            self.data_dir = data_dir
        else:
            self._data_dir_obj = None  # will be created on start
            self.data_dir = None

        self._process: subprocess.Popen | None = None
        self._pid_file: str | None = None

        # Register cleanup on exit
        atexit.register(self._cleanup)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def http_url(self) -> str:
        """HTTP JSON-RPC URL for the devnet node."""
        return f"http://127.0.0.1:{self.http_port}"

    @property
    def ws_url(self) -> str:
        """WebSocket URL for the devnet node."""
        return f"ws://127.0.0.1:{self.ws_port}"

    @property
    def is_running(self) -> bool:
        """True if the devnet process is alive."""
        if self._process is None:
            return False
        return self._process.poll() is None

    def start_devnet(self, timeout: float = 30.0) -> None:
        """Start the znnd devnet node and wait for RPC to become ready."""
        if self.is_running:
            raise DevnetError("Devnet is already running")

        # Create a fresh data directory
        if self.data_dir is None:
            self._data_dir_obj = tempfile.mkdtemp(prefix="zenon-devnet-")
            self.data_dir = self._data_dir_obj
        else:
            os.makedirs(self.data_dir, exist_ok=True)

        # Copy wallet keystore into the data directory
        wallet_dst = os.path.join(self.data_dir, "wallet")
        if os.path.isdir(self.wallet_source):
            if os.path.exists(wallet_dst):
                shutil.rmtree(wallet_dst)
            shutil.copytree(self.wallet_source, wallet_dst)
        else:
            print(
                f"WARNING: Wallet source {self.wallet_source} not found. "
                "The node will not be able to produce momentums.",
                file=sys.stderr,
            )
            os.makedirs(wallet_dst, exist_ok=True)

        # Write node config
        config = self._build_config()
        config_path = os.path.join(self.data_dir, "config.json")
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)

        # Start znnd
        log_path = os.path.join(self.data_dir, "znnd.log")
        log_file = open(log_path, "w")

        self._process = subprocess.Popen(
            [self.znnd_binary, "--data", self.data_dir],
            stdout=log_file,
            stderr=subprocess.STDOUT,
            preexec_fn=os.setsid,  # new process group for clean kill
        )

        # Write PID file
        self._pid_file = os.path.join(self.data_dir, "znnd.pid")
        with open(self._pid_file, "w") as f:
            f.write(str(self._process.pid))

        print(f"Started znnd (PID {self._process.pid}), data: {self.data_dir}")
        print(f"  HTTP: {self.http_url}  WS: {self.ws_url}")
        print(f"  Log:  {log_path}")

        # Wait for RPC to be ready
        self._wait_for_rpc(timeout)
        print("Devnet RPC is ready.")

    def stop_devnet(self, timeout: float = 10.0) -> None:
        """Gracefully stop the devnet node."""
        if not self.is_running:
            print("Devnet is not running.")
            return

        pid = self._process.pid
        print(f"Stopping znnd (PID {pid})...")

        # Send SIGTERM to the process group
        with contextlib.suppress(ProcessLookupError):
            os.killpg(os.getpgid(pid), signal.SIGTERM)

        try:
            self._process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            print("Graceful shutdown timed out, sending SIGKILL...")
            with contextlib.suppress(ProcessLookupError):
                os.killpg(os.getpgid(pid), signal.SIGKILL)
            self._process.wait(timeout=5)

        self._process = None
        print("Devnet stopped.")

    def reset_devnet(self, timeout: float = 30.0) -> None:
        """Stop, wipe data, and restart fresh."""
        self.stop_devnet()

        if self.data_dir and os.path.isdir(self.data_dir):
            print(f"Wiping data directory: {self.data_dir}")
            shutil.rmtree(self.data_dir)

        self.data_dir = None
        self.start_devnet(timeout)

    def wait_for_momentum(self, target_height: int, timeout: float = 60.0) -> int:
        """
        Wait until the frontier momentum reaches at least `target_height`.
        Returns the actual frontier height.
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            status = self.get_status()
            if status and status["height"] >= target_height:
                return status["height"]
            time.sleep(0.5)
        raise DevnetError(
            f"Timed out waiting for momentum height {target_height} "
            f"(current: {self.get_status().get('height', 'unknown')})"
        )

    def wait_for_momentums(self, count: int, timeout: float = 60.0) -> int:
        """
        Wait for `count` additional momentums from the current height.
        Returns the new frontier height.
        """
        status = self.get_status()
        current = status["height"] if status else 0
        return self.wait_for_momentum(current + count, timeout)

    def get_status(self) -> dict | None:
        """
        Check node status via RPC.

        Returns dict with keys: running, height, timestamp, hash
        or None if RPC is unreachable.
        """
        if not self.is_running:
            return {"running": False, "height": 0, "timestamp": 0, "hash": ""}

        try:
            resp = self._rpc_call("ledger.getFrontierMomentum")
            if resp and "result" in resp:
                m = resp["result"]
                return {
                    "running": True,
                    "height": m.get("height", 0),
                    "timestamp": m.get("timestamp", 0),
                    "hash": m.get("hash", ""),
                }
        except Exception as exc:
            logger.debug("Failed to fetch devnet status: %s", exc)

        return {"running": True, "height": 0, "timestamp": 0, "hash": ""}

    def get_account_info(self, address: str) -> dict | None:
        """Get account info (balances) for an address."""
        resp = self._rpc_call("ledger.getAccountInfoByAddress", [address])
        if resp and "result" in resp:
            return resp["result"]
        return None

    def rpc_call(self, method: str, params=None) -> dict:
        """Public convenience wrapper for raw JSON-RPC calls."""
        return self._rpc_call(method, params)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_config(self) -> dict:
        """Build the znnd config.json for the devnet node."""
        return {
            "DataPath": self.data_dir,
            "WalletPath": os.path.join(self.data_dir, "wallet"),
            "GenesisFile": self.genesis_file,
            "Name": "devnet-integration-test",
            "LogLevel": "info",
            "Producer": {
                "Address": DEVNET_PRODUCER_ADDRESS,
                "Index": 0,
                "KeyFilePath": os.path.join(self.data_dir, "wallet", DEVNET_PRODUCER_ADDRESS),
                "Password": DEVNET_WALLET_PASSWORD,
            },
            "RPC": {
                "EnableHTTP": True,
                "EnableWS": True,
                "HTTPHost": "127.0.0.1",
                "HTTPPort": self.http_port,
                "WSHost": "127.0.0.1",
                "WSPort": self.ws_port,
                "HTTPCors": ["*"],
                "WSOrigins": ["*"],
            },
            "Net": {
                "ListenHost": "127.0.0.1",
                "ListenPort": self.p2p_port,
                "MinPeers": 0,
                "MinConnectedPeers": 0,
                "MaxPeers": 10,
                "MaxPendingPeers": 5,
                "Seeders": [],
            },
        }

    def _rpc_call(self, method: str, params=None) -> dict:
        """Make an HTTP JSON-RPC call to the node."""
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params or [],
        }
        resp = requests.post(
            self.http_url,
            json=payload,
            timeout=5,
        )
        return resp.json()

    def _wait_for_rpc(self, timeout: float) -> None:
        """Poll the RPC endpoint until it responds or timeout."""
        deadline = time.time() + timeout
        last_err = None
        while time.time() < deadline:
            if not self.is_running:
                # Node crashed during startup
                log_path = os.path.join(self.data_dir, "znnd.log") if self.data_dir else "<unknown>"
                raise DevnetError(
                    f"znnd process exited during startup (exit code {self._process.returncode}). "
                    f"Check log: {log_path}"
                )
            try:
                resp = self._rpc_call("ledger.getFrontierMomentum")
                if "result" in resp:
                    return
            except Exception as e:
                last_err = e
            time.sleep(0.5)
        raise DevnetError(
            f"Timed out ({timeout}s) waiting for RPC to become ready. Last error: {last_err}"
        )

    def _cleanup(self) -> None:
        """Cleanup handler called on exit."""
        if self.is_running:
            try:
                self.stop_devnet(timeout=5)
            except Exception as e:
                print(f"Warning: cleanup failed: {e}", file=sys.stderr)


# ---------------------------------------------------------------------------
# JSON-RPC client
# ---------------------------------------------------------------------------


class RpcError(Exception):
    """Raised when an RPC call returns an error."""

    def __init__(self, code: int, message: str, data: Any = None):
        self.code = code
        self.message = message
        self.data = data
        super().__init__(f"RPC error {code}: {message}")


class ZenonRpcClient:
    """
    JSON-RPC client for znnd.

    Prefers WebSocket for persistent connection but falls back to HTTP.
    All RPC methods use the standard `module.method` naming convention
    matching the Go API registration (e.g. ledger.getFrontierMomentum,
    embedded.spork.getAll).
    """

    def __init__(
        self,
        ws_url: str = "ws://127.0.0.1:35998",
        http_url: str = "http://127.0.0.1:35997",
        use_websocket: bool = True,
    ):
        self.ws_url = ws_url
        self.http_url = http_url
        self._ws: Any | None = None
        self._req_id = 0
        self._use_ws = use_websocket and HAS_WEBSOCKET

        if self._use_ws:
            try:
                self._connect_ws()
            except Exception as exc:
                logger.debug("WebSocket unavailable, falling back to HTTP JSON-RPC: %s", exc)
                self._use_ws = False

    def close(self) -> None:
        """Close the WebSocket connection if open."""
        if self._ws:
            try:
                self._ws.close()
            except Exception as exc:
                logger.debug("WebSocket close error: %s", exc)
            self._ws = None

    # ------------------------------------------------------------------
    # Low-level RPC
    # ------------------------------------------------------------------

    def call(self, method: str, params: list | None = None) -> Any:
        """
        Make a JSON-RPC call and return the result.
        Raises RpcError if the response contains an error.
        """
        self._req_id += 1
        payload = {
            "jsonrpc": "2.0",
            "id": self._req_id,
            "method": method,
            "params": params or [],
        }

        if self._use_ws:
            return self._call_ws(payload)
        return self._call_http(payload)

    # ------------------------------------------------------------------
    # Ledger API
    # ------------------------------------------------------------------

    def get_frontier_momentum(self) -> dict:
        """ledger.getFrontierMomentum"""
        return self.call("ledger.getFrontierMomentum")

    def get_momentum_by_hash(self, hash_: str) -> dict:
        """ledger.getMomentumByHash"""
        return self.call("ledger.getMomentumByHash", [hash_])

    def get_momentums_by_height(self, height: int, count: int) -> dict:
        """ledger.getMomentumsByHeight"""
        return self.call("ledger.getMomentumsByHeight", [height, count])

    def get_account_info_by_address(self, address: str) -> dict:
        """ledger.getAccountInfoByAddress"""
        return self.call("ledger.getAccountInfoByAddress", [address])

    def get_unreceived_blocks(self, address: str, page: int = 0, size: int = 50) -> dict:
        """ledger.getUnreceivedBlocksByAddress"""
        return self.call("ledger.getUnreceivedBlocksByAddress", [address, page, size])

    def get_unconfirmed_blocks(self, address: str, page: int = 0, size: int = 50) -> dict:
        """ledger.getUnconfirmedBlocksByAddress"""
        return self.call("ledger.getUnconfirmedBlocksByAddress", [address, page, size])

    def get_frontier_account_block(self, address: str) -> dict | None:
        """ledger.getFrontierAccountBlock"""
        return self.call("ledger.getFrontierAccountBlock", [address])

    def get_account_block_by_hash(self, hash_: str) -> dict | None:
        """ledger.getAccountBlockByHash"""
        return self.call("ledger.getAccountBlockByHash", [hash_])

    def get_account_blocks_by_page(self, address: str, page: int = 0, size: int = 50) -> dict:
        """ledger.getAccountBlocksByPage"""
        return self.call("ledger.getAccountBlocksByPage", [address, page, size])

    def publish_raw_transaction(self, block: dict) -> None:
        """
        ledger.publishRawTransaction

        Submit a fully formed and signed account block to the network.
        The block dict must include all required fields: version, chainIdentifier,
        blockType, hash, previousHash, height, momentumAcknowledged, address,
        toAddress, amount, tokenStandard, data, signature, publicKey, etc.
        """
        return self.call("ledger.publishRawTransaction", [block])

    # ------------------------------------------------------------------
    # Spork API
    # ------------------------------------------------------------------

    def spork_get_all(self, page: int = 0, size: int = 50) -> dict:
        """embedded.spork.getAll"""
        return self.call("embedded.spork.getAll", [page, size])

    # ------------------------------------------------------------------
    # PTLC API
    # ------------------------------------------------------------------

    def ptlc_get_by_id(self, ptlc_id: str) -> dict:
        """embedded.ptlc.getById"""
        return self.call("embedded.ptlc.getById", [ptlc_id])

    def ptlc_get_proxy_unlock_status(self, address: str) -> bool:
        """embedded.ptlc.getProxyUnlockStatus"""
        return self.call("embedded.ptlc.getProxyUnlockStatus", [address])

    # ------------------------------------------------------------------
    # Governance API
    # ------------------------------------------------------------------

    def governance_get_proposal_by_id(self, proposal_id: str) -> dict:
        """embedded.governance.getProposalById"""
        return self.call("embedded.governance.getProposalById", [proposal_id])

    def governance_get_all_proposals(self, page: int = 0, size: int = 50) -> dict:
        """embedded.governance.getAllProposals"""
        return self.call("embedded.governance.getAllProposals", [page, size])

    # ------------------------------------------------------------------
    # Atomic Swap API
    # ------------------------------------------------------------------

    def atomic_swap_get_by_id(self, swap_id: str) -> dict:
        """embedded.atomicSwap.getSwapById"""
        return self.call("embedded.atomicSwap.getSwapById", [swap_id])

    # ------------------------------------------------------------------
    # Multisig API
    # ------------------------------------------------------------------

    def multisig_get_by_id(self, multisig_id: str) -> dict:
        """embedded.multisig.getMultisigById"""
        return self.call("embedded.multisig.getMultisigById", [multisig_id])

    def multisig_get_proposal_by_id(self, proposal_id: str) -> dict:
        """embedded.multisig.getProposalById"""
        return self.call("embedded.multisig.getProposalById", [proposal_id])

    # ------------------------------------------------------------------
    # Streaming API
    # ------------------------------------------------------------------

    def streaming_get_by_id(self, stream_id: str) -> dict:
        """embedded.streaming.getStreamById"""
        return self.call("embedded.streaming.getStreamById", [stream_id])

    # ------------------------------------------------------------------
    # ZNS API
    # ------------------------------------------------------------------

    def zns_resolve_name(self, name: str) -> str | None:
        """embedded.zns.resolveName"""
        return self.call("embedded.zns.resolveName", [name])

    def zns_get_entry_by_name(self, name: str) -> dict | None:
        """embedded.zns.getEntryByName"""
        return self.call("embedded.zns.getEntryByName", [name])

    # ------------------------------------------------------------------
    # Pillar API
    # ------------------------------------------------------------------

    def pillar_get_all(self, page: int = 0, size: int = 50) -> dict:
        """embedded.pillar.getAll"""
        return self.call("embedded.pillar.getAll", [page, size])

    # ------------------------------------------------------------------
    # SPV API
    # ------------------------------------------------------------------

    def spv_get_header_chain_info(self) -> dict:
        """embedded.bitcoinSpv.getHeaderChainInfo"""
        return self.call("embedded.bitcoinSpv.getHeaderChainInfo")

    # ------------------------------------------------------------------
    # Transaction lifecycle helpers
    # ------------------------------------------------------------------

    def send_transaction(self, block: dict) -> dict:
        """
        Send a signed transaction and return the submitted block.

        This is a convenience wrapper around publish_raw_transaction that
        also checks for errors in the response.
        """
        self.publish_raw_transaction(block)
        return block

    def wait_for_receive(
        self,
        address: str,
        timeout: float = 30.0,
        poll_interval: float = 0.5,
    ) -> list[dict]:
        """
        Wait until the address has no more unreceived blocks, meaning
        all pending sends have been received by the node.

        Returns the list of unreceived blocks that were present (empty
        if all were already received).
        """
        deadline = time.time() + timeout
        last_unreceived = []
        while time.time() < deadline:
            result = self.get_unreceived_blocks(address)
            blocks = result.get("list", []) if result else []
            if not blocks:
                return last_unreceived
            last_unreceived = blocks
            time.sleep(poll_interval)
        return last_unreceived

    def wait_for_account_block(
        self,
        address: str,
        min_height: int,
        timeout: float = 30.0,
    ) -> dict | None:
        """
        Wait until the address has an account block at height >= min_height.
        Returns the frontier account block.
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            block = self.get_frontier_account_block(address)
            if block and block.get("height", 0) >= min_height:
                return block
            time.sleep(0.5)
        return None

    def activate_spork(
        self,
        spork_name: str,
        spork_description: str,
        devnet_manager: Any,
        wait_momentums: int = 10,
    ) -> str | None:
        """
        Helper to activate a new spork on the devnet.

        This requires the devnet to be running with the spork address as producer.
        Since we cannot sign transactions from Python without the Zenon SDK,
        this method documents the expected flow for use when a signing library
        is available.

        The Go test pattern for spork activation is:
        1. Send a SporkCreate tx from the spork address to SporkContract
        2. Wait for one momentum
        3. Query spork_get_all to get the new spork ID
        4. Send a SporkActivate tx from the spork address with that ID
        5. Wait for enforcement height (~9 momentums ahead)

        Returns the spork ID if the activation could be verified, None otherwise.

        NOTE: Full activation requires transaction signing capability.
        See integration_tests.py for the expected lifecycle.
        """
        # Step 1: Check current sporks
        current = self.spork_get_all()
        current_ids = set()
        if current and "list" in current:
            current_ids = {s["id"] for s in current["list"]}

        # Without a signing library, we cannot programmatically create the
        # spork-create and spork-activate transactions. This is the main
        # limitation of the Python integration test framework.
        #
        # Options to resolve this:
        # 1. Use znn-cli (the Zenon CLI tool) to send transactions
        # 2. Implement ed25519 + Zenon account block signing in Python
        # 3. Use the Dart SDK (znn_sdk_dart) via subprocess
        # 4. Pre-activate all needed sporks in the genesis config
        #
        # Option 4 is the most practical for integration testing:
        # Add all sporks to the genesis.json SporkConfig.Sporks array
        # with "activated": true, just like az/htlc/bridge-liq already are.

        print(
            f"SPORK ACTIVATION NOTE: To activate '{spork_name}', either:\n"
            f"  1. Add it to genesis.json SporkConfig.Sporks with activated=true\n"
            f"  2. Use znn-cli to create and activate it manually\n"
            f"  3. Implement transaction signing in this framework\n"
            f"Current active sporks: {list(current_ids)}"
        )
        return None

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _connect_ws(self) -> None:
        """Establish a WebSocket connection."""
        self._ws = ws_lib.create_connection(self.ws_url, timeout=5)

    def _call_ws(self, payload: dict) -> Any:
        """Send an RPC request over WebSocket."""
        if not self._ws:
            try:
                self._connect_ws()
            except Exception as exc:
                logger.debug("WS connect failed, falling back to HTTP: %s", exc)
                self._use_ws = False
                return self._call_http(payload)

        try:
            self._ws.send(json.dumps(payload))
            raw = self._ws.recv()
        except Exception as exc:
            # Reconnect and retry once
            logger.debug("WS send/recv failed, reconnecting: %s", exc)
            try:
                self._connect_ws()
                self._ws.send(json.dumps(payload))
                raw = self._ws.recv()
            except Exception as exc2:
                logger.debug("WS retry failed, falling back to HTTP: %s", exc2)
                self._use_ws = False
                return self._call_http(payload)

        resp = json.loads(raw)
        if "error" in resp:
            err = resp["error"]
            raise RpcError(err.get("code", -1), err.get("message", "unknown"), err.get("data"))
        return resp.get("result")

    def _call_http(self, payload: dict) -> Any:
        """Send an RPC request over HTTP."""
        resp = requests.post(self.http_url, json=payload, timeout=10)
        data = resp.json()
        if "error" in data:
            err = data["error"]
            raise RpcError(err.get("code", -1), err.get("message", "unknown"), err.get("data"))
        return data.get("result")


__all__ = [
    "ATOMIC_SWAP_CONTRACT",
    # Constants
    "DEFAULT_HTTP_PORT",
    "DEFAULT_P2P_PORT",
    "DEFAULT_WS_PORT",
    "DEVNET_FUNDED_ADDRESS",
    "DEVNET_PRODUCER_ADDRESS",
    "DEVNET_WALLET_PASSWORD",
    "GENESIS_SPORKS",
    "GOVERNANCE_CONTRACT",
    "HAS_WEBSOCKET",
    "MULTISIG_CONTRACT",
    "PILLAR_CONTRACT",
    "PTLC_CONTRACT",
    "QSR_TOKEN_STANDARD",
    "SPORK_CONTRACT",
    "STREAMING_CONTRACT",
    "ZNN_TOKEN_STANDARD",
    "ZNS_CONTRACT",
    # Devnet lifecycle
    "DevnetError",
    "DevnetManager",
    # RPC client
    "RpcError",
    "ZenonRpcClient",
]
