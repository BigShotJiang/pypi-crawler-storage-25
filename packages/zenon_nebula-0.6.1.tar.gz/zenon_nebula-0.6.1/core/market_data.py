# SPDX-License-Identifier: MIT
"""
Market Data Client -- CoinGecko, DefiLlama, DexScreener, LunarCrush, and more.

Lightweight implementations using urllib (no requests dependency). All free
public APIs except LunarCrush (requires LUNARCRUSH_API_KEY), Dune Analytics
(requires DUNE_API_KEY), and Etherscan (requires ETHERSCAN_API_KEY).

All functions return dicts/lists and handle errors gracefully -- returning
None or empty collections on failure so callers can fall back to other
data sources.

Usage:
    from core.market_data import get_price, get_protocol_tvl, get_fear_greed

    price = get_price("zenon-2")
    tvl = get_protocol_tvl("zenon-finance")
    sentiment = get_fear_greed()
"""

import json
import logging
import os
import time
import urllib.error
import urllib.request

from core.http import opsec_request, opsec_urlopen  # noqa: F401  OPSEC-safe HTTP wrapper

logger = logging.getLogger(__name__)

# API base URLs
COINGECKO_BASE = "https://api.coingecko.com/api/v3"
DEFILLAMA_BASE = "https://api.llama.fi"
DEXSCREENER_BASE = "https://api.dexscreener.com/latest/dex"
LUNARCRUSH_BASE = "https://lunarcrush.com/api4/public"
FEAR_GREED_URL = "https://api.alternative.me/fng/"
UNISWAP_SUBGRAPH = "https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3"
DUNE_API_BASE = "https://api.dune.com/api/v1"

REQUEST_TIMEOUT = 15

# Rate limiting: 1 request per second (polite for free APIs)
_RATE_LIMIT_SECONDS = 1.0
_last_request_time = 0.0


def _rate_limit() -> None:
    """Enforce minimum delay between API requests."""
    global _last_request_time
    now = time.monotonic()
    elapsed = now - _last_request_time
    if elapsed < _RATE_LIMIT_SECONDS:
        time.sleep(_RATE_LIMIT_SECONDS - elapsed)
    _last_request_time = time.monotonic()


def _get(url: str, headers: dict | None = None) -> dict | list | None:
    """Make an HTTP GET request and return parsed JSON.

    Args:
        url:     Full URL to fetch.
        headers: Optional additional HTTP headers.

    Returns:
        Parsed JSON response, or None on any error.
    """
    _rate_limit()
    hdrs = {"User-Agent": "Nebula/0.1", "Accept": "application/json"}
    if headers:
        hdrs.update(headers)

    req = urllib.request.Request(url, headers=hdrs)
    try:
        with opsec_urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        logger.warning("HTTP %d from %s", exc.code, url.split("?")[0])
        return None
    except (urllib.error.URLError, OSError, json.JSONDecodeError) as exc:
        logger.warning("Request to %s failed: %s", url.split("?")[0], exc)
        return None


def _post(url: str, body: dict, headers: dict | None = None) -> dict | None:
    """Make an HTTP POST request with JSON body and return parsed JSON.

    Args:
        url:     Full URL to post to.
        body:    Dict to serialize as JSON request body.
        headers: Optional additional HTTP headers.

    Returns:
        Parsed JSON response, or None on any error.
    """
    _rate_limit()
    hdrs = {
        "User-Agent": "Nebula/0.1",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    if headers:
        hdrs.update(headers)

    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=hdrs, method="POST")
    try:
        with opsec_urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        logger.warning("HTTP %d from POST %s", exc.code, url.split("?")[0])
        return None
    except (urllib.error.URLError, OSError, json.JSONDecodeError) as exc:
        logger.warning("POST to %s failed: %s", url.split("?")[0], exc)
        return None


# ---------------------------------------------------------------------------
# CoinGecko (free, no key required)
# ---------------------------------------------------------------------------


def get_price(coin_id: str = "zenon-2") -> dict | None:
    """Fetch current price and market data for a coin.

    Args:
        coin_id: CoinGecko coin identifier.

    Returns:
        Dict with: usd, btc, market_cap, volume_24h, change_24h.
        Returns None on error.
    """
    url = (
        f"{COINGECKO_BASE}/simple/price"
        f"?ids={coin_id}"
        f"&vs_currencies=usd,btc"
        f"&include_market_cap=true"
        f"&include_24hr_vol=true"
        f"&include_24hr_change=true"
    )
    data = _get(url)
    if not data or coin_id not in data:
        return None

    coin = data[coin_id]
    return {
        "usd": coin.get("usd", 0),
        "btc": coin.get("btc", 0),
        "market_cap": coin.get("usd_market_cap", 0),
        "volume_24h": coin.get("usd_24h_vol", 0),
        "change_24h": coin.get("usd_24h_change", 0),
    }


def get_market_chart(coin_id: str = "zenon-2", days: int = 30) -> dict | None:
    """Fetch price history for a coin.

    Args:
        coin_id: CoinGecko coin identifier.
        days:    Number of days of history (1, 7, 14, 30, 90, 180, 365, max).

    Returns:
        Dict with: prices (list of [timestamp_ms, price] pairs),
        market_caps, total_volumes. Returns None on error.
    """
    url = f"{COINGECKO_BASE}/coins/{coin_id}/market_chart?vs_currency=usd&days={days}"
    data = _get(url)
    if not data:
        return None

    return {
        "prices": data.get("prices", []),
        "market_caps": data.get("market_caps", []),
        "total_volumes": data.get("total_volumes", []),
    }


def get_coin_info(coin_id: str = "zenon-2") -> dict | None:
    """Fetch detailed coin information.

    Args:
        coin_id: CoinGecko coin identifier.

    Returns:
        Dict with: name, symbol, description, links, market_data (price,
        market_cap, volume, supply, ath/atl). Returns None on error.
    """
    url = (
        f"{COINGECKO_BASE}/coins/{coin_id}"
        f"?localization=false&tickers=false"
        f"&community_data=false&developer_data=false"
    )
    data = _get(url)
    if not data:
        return None

    market = data.get("market_data", {})
    desc = data.get("description", {}).get("en", "")

    return {
        "name": data.get("name", ""),
        "symbol": data.get("symbol", ""),
        "description": desc[:1000] if desc else "",
        "links": {
            "homepage": (data.get("links", {}).get("homepage", [""]) or [""])[0],
            "blockchain_site": [u for u in data.get("links", {}).get("blockchain_site", []) if u][
                :3
            ],
            "repos_url": data.get("links", {}).get("repos_url", {}).get("github", []),
        },
        "market_data": {
            "price_usd": market.get("current_price", {}).get("usd", 0),
            "price_btc": market.get("current_price", {}).get("btc", 0),
            "market_cap": market.get("market_cap", {}).get("usd", 0),
            "volume_24h": market.get("total_volume", {}).get("usd", 0),
            "change_24h": market.get("price_change_percentage_24h", 0),
            "change_7d": market.get("price_change_percentage_7d", 0),
            "change_30d": market.get("price_change_percentage_30d", 0),
            "circulating_supply": market.get("circulating_supply", 0),
            "total_supply": market.get("total_supply", 0),
            "max_supply": market.get("max_supply"),
            "ath_usd": market.get("ath", {}).get("usd", 0),
            "atl_usd": market.get("atl", {}).get("usd", 0),
        },
    }


# ---------------------------------------------------------------------------
# DefiLlama (free, no key required)
# ---------------------------------------------------------------------------


def get_protocol_tvl(protocol: str = "zenon-finance") -> dict | None:
    """Fetch current TVL for a specific protocol.

    Args:
        protocol: DefiLlama protocol slug.

    Returns:
        Dict with: name, tvl, chain_tvls, symbol, chains.
        Returns None on error or if protocol not found.
    """
    data = _get(f"{DEFILLAMA_BASE}/protocol/{protocol}")
    if not data:
        return None

    return {
        "name": data.get("name", ""),
        "tvl": data.get("currentChainTvls", {}),
        "total_tvl": sum(
            v
            for k, v in data.get("currentChainTvls", {}).items()
            if isinstance(v, (int, float)) and not k.endswith("-borrowed")
        ),
        "symbol": data.get("symbol", ""),
        "chains": data.get("chains", []),
    }


def get_tvl_history(protocol: str = "zenon-finance", days: int = 30) -> list | None:
    """Fetch TVL history for a protocol.

    Args:
        protocol: DefiLlama protocol slug.
        days:     Number of days of history to return.

    Returns:
        List of dicts with: date (unix timestamp), totalLiquidityUSD.
        Returns None on error.
    """
    data = _get(f"{DEFILLAMA_BASE}/protocol/{protocol}")
    if not data or "tvl" not in data:
        return None

    tvl_entries = data.get("tvl", [])
    if not tvl_entries:
        return []

    # Return only the last N days
    return tvl_entries[-days:]


def get_chain_tvl(chain: str = "zenon") -> dict | None:
    """Fetch TVL for a specific blockchain/chain.

    Args:
        chain: Chain name as listed on DefiLlama.

    Returns:
        Dict with: name, tvl. Returns None if chain not found.
    """
    data = _get(f"{DEFILLAMA_BASE}/v2/chains")
    if not data or not isinstance(data, list):
        return None

    for entry in data:
        if entry.get("name", "").lower() == chain.lower():
            return {
                "name": entry.get("name", ""),
                "tvl": entry.get("tvl", 0),
            }

    return None


def get_yields() -> list[dict]:
    """Fetch yield farming opportunities from DefiLlama.

    Returns:
        List of dicts with: pool, project, chain, tvl_usd, apy, symbol.
        Returns empty list on error.
    """
    data = _get("https://yields.llama.fi/pools")
    if not data or "data" not in data:
        return []

    pools = []
    for pool in data["data"]:
        pools.append(
            {
                "pool": pool.get("pool", ""),
                "project": pool.get("project", ""),
                "chain": pool.get("chain", ""),
                "tvl_usd": pool.get("tvlUsd", 0),
                "apy": pool.get("apy", 0),
                "symbol": pool.get("symbol", ""),
            }
        )

    return pools


# ---------------------------------------------------------------------------
# DexScreener (free, no key required)
# ---------------------------------------------------------------------------

WZNN_CONTRACT = "0xb2e96a63479c2edd2fd62b382c89d5ca79f572d3"


def get_dexscreener_data(contract: str = WZNN_CONTRACT) -> dict | None:
    """Fetch token data from DexScreener.

    Uses the highest-liquidity pair for the given token contract.

    Args:
        contract: ERC-20 token contract address.

    Returns:
        Dict with: price_usd, volume_24h, liquidity_usd, price_change_1h,
        price_change_24h, pair_address, dex, chain, txns_24h_buys,
        txns_24h_sells, fdv. Returns None on error.
    """
    data = _get(f"{DEXSCREENER_BASE}/tokens/{contract}")
    if not data:
        return None

    pairs = data.get("pairs", [])
    if not pairs:
        return None

    # Use the highest-liquidity pair
    pair = max(pairs, key=lambda p: float(p.get("liquidity", {}).get("usd", 0) or 0))
    return {
        "price_usd": float(pair.get("priceUsd", 0) or 0),
        "price_change_1h": float(pair.get("priceChange", {}).get("h1", 0) or 0),
        "price_change_24h": float(pair.get("priceChange", {}).get("h24", 0) or 0),
        "volume_24h": float(pair.get("volume", {}).get("h24", 0) or 0),
        "liquidity_usd": float(pair.get("liquidity", {}).get("usd", 0) or 0),
        "pair_address": pair.get("pairAddress", ""),
        "dex": pair.get("dexId", ""),
        "chain": pair.get("chainId", ""),
        "txns_24h_buys": pair.get("txns", {}).get("h24", {}).get("buys", 0),
        "txns_24h_sells": pair.get("txns", {}).get("h24", {}).get("sells", 0),
        "fdv": float(pair.get("fdv", 0) or 0),
    }


# ---------------------------------------------------------------------------
# LunarCrush (requires LUNARCRUSH_API_KEY)
# ---------------------------------------------------------------------------


def get_lunarcrush_metrics(coin: str = "ZNN") -> dict | None:
    """Fetch social metrics from LunarCrush.

    Requires LUNARCRUSH_API_KEY environment variable.

    Args:
        coin: Coin symbol or slug.

    Returns:
        Dict with: galaxy_score, alt_rank, social_dominance, sentiment,
        social_volume, categories. Returns None if no API key or on error.
    """
    api_key = os.environ.get("LUNARCRUSH_API_KEY", "").strip()
    if not api_key:
        return None

    data = _get(
        f"{LUNARCRUSH_BASE}/coins/{coin.lower()}/v1",
        headers={"Authorization": f"Bearer {api_key}"},
    )
    if not data:
        return None

    return {
        "galaxy_score": data.get("galaxy_score"),
        "alt_rank": data.get("alt_rank"),
        "social_dominance": data.get("social_dominance"),
        "sentiment": data.get("sentiment"),
        "social_volume": data.get("social_volume"),
        "categories": data.get("categories", []),
    }


# ---------------------------------------------------------------------------
# Fear & Greed Index (free, no key required)
# ---------------------------------------------------------------------------


def get_fear_greed() -> dict | None:
    """Fetch the Crypto Fear & Greed Index.

    Returns:
        Dict with: value (0-100), classification (e.g. "Extreme Fear",
        "Fear", "Neutral", "Greed", "Extreme Greed"), timestamp.
        Returns None on error.
    """
    data = _get(f"{FEAR_GREED_URL}?limit=1")
    if not data or "data" not in data:
        return None

    entry = data["data"][0] if data["data"] else {}
    if not entry:
        return None

    return {
        "value": int(entry.get("value", 50)),
        "classification": entry.get("value_classification", "Neutral"),
        "timestamp": entry.get("timestamp", ""),
    }


# ---------------------------------------------------------------------------
# Uniswap V3 Subgraph (free, no key required)
# ---------------------------------------------------------------------------


def get_uniswap_pool_data(pool_address: str = "") -> dict | None:
    """Query Uniswap V3 subgraph for pool depth and volume.

    Args:
        pool_address: Uniswap V3 pool contract address. If empty, uses
                      WZNN_UNISWAP_POOL env var.

    Returns:
        Dict with: pool_tvl, pool_volume, pool_tx_count, pool_fee_tier,
        token0_price, token1_price. Returns None on error.
    """
    addr = pool_address or os.environ.get("WZNN_UNISWAP_POOL", "").strip()
    if not addr:
        return None

    query = (
        f'{{ pool(id: "{addr.lower()}") {{ '
        "token0Price token1Price volumeUSD totalValueLockedUSD "
        "txCount feeTier liquidity "
        "} }"
    )

    data = _post(UNISWAP_SUBGRAPH, {"query": query})
    if not data:
        return None

    pool = (data.get("data") or {}).get("pool")
    if not pool:
        return None

    return {
        "pool_tvl": float(pool.get("totalValueLockedUSD", 0) or 0),
        "pool_volume": float(pool.get("volumeUSD", 0) or 0),
        "pool_tx_count": int(pool.get("txCount", 0) or 0),
        "pool_fee_tier": pool.get("feeTier"),
        "token0_price": float(pool.get("token0Price", 0) or 0),
        "token1_price": float(pool.get("token1Price", 0) or 0),
        "liquidity": pool.get("liquidity", "0"),
    }


# ---------------------------------------------------------------------------
# Dune Analytics (requires DUNE_API_KEY)
# ---------------------------------------------------------------------------


def get_dune_query(query_id: int, api_key: str = "") -> dict | None:
    """Execute a Dune Analytics query and return results.

    Args:
        query_id: Dune query ID (from dashboard URL).
        api_key:  Dune API key. If empty, uses DUNE_API_KEY env var.

    Returns:
        Dict with: execution_id, state, result (rows if complete).
        Returns None if no API key or on error.
    """
    key = api_key or os.environ.get("DUNE_API_KEY", "").strip()
    if not key:
        return None

    headers = {"X-Dune-API-Key": key}

    # Get the latest results for this query (avoids triggering a new execution)
    data = _get(
        f"{DUNE_API_BASE}/query/{query_id}/results",
        headers=headers,
    )
    if not data:
        return None

    result = data.get("result", {})
    return {
        "execution_id": data.get("execution_id", ""),
        "state": data.get("state", ""),
        "rows": result.get("rows", []),
        "metadata": result.get("metadata", {}),
    }


# ---------------------------------------------------------------------------
# Etherscan token info (requires ETHERSCAN_API_KEY)
# ---------------------------------------------------------------------------


def get_token_holders(contract: str = WZNN_CONTRACT, api_key: str = "") -> dict | None:
    """Fetch ERC-20 token holder count from Etherscan.

    Args:
        contract: Token contract address.
        api_key:  Etherscan API key. If empty, uses ETHERSCAN_API_KEY env var.

    Returns:
        Dict with: holder_count, token_name, token_symbol.
        Returns None if no API key or on error.
    """
    key = api_key or os.environ.get("ETHERSCAN_API_KEY", "").strip()
    if not key:
        return None

    url = (
        f"https://api.etherscan.io/api"
        f"?module=token&action=tokeninfo"
        f"&contractaddress={contract}&apikey={key}"
    )
    data = _get(url)
    if not data:
        return None

    result = data.get("result")
    if isinstance(result, list) and result:
        info = result[0]
        return {
            "holder_count": int(info.get("holdersCount", 0) or 0),
            "token_name": info.get("tokenName", ""),
            "token_symbol": info.get("symbol", ""),
        }

    return None
