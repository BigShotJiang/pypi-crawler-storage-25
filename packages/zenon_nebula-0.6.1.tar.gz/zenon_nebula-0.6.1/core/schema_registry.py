# SPDX-License-Identifier: MIT
"""
SchemaRegistry - single source of truth for Nebula's SQLite schema.

Historically schema lived in three places:
    1. ``core/persist_to_db.SCHEMA_SQL``  (core tables)
    2. ``domains/*/domain.get_db_schema_sql()``  (domain-owned tables)
    3. Hardcoded inside individual engines, with no CREATE TABLE
       companion, causing "no such table"/"no such column" errors.

This module walks both the core package and every installed domain
and collects their declared schema fragments at startup, then runs
them all in a single ``executescript`` against the target DB. Engines
are encouraged to declare their own ``SCHEMA_SQL`` module-level
constant so the table that an engine writes to ships alongside the
code that writes it.

The registry is idempotent: every CREATE is ``IF NOT EXISTS`` and
every missing column migration uses ``ALTER TABLE ... ADD COLUMN``.

Usage::

    from core.schema_registry import apply_all_schemas

    stats = apply_all_schemas("data/engine.db")
    # stats = {"applied": 23, "errors": [...], "tables": [...]}
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
import sqlite3
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

NEBULA_ROOT = Path(__file__).resolve().parents[1]


def _core_schemas() -> list[tuple[str, str]]:
    """Return the core ``SCHEMA_SQL`` block as a (source, sql) tuple."""
    schemas: list[tuple[str, str]] = []
    try:
        from core import persist_to_db  # local import to avoid cycles
    except Exception as exc:
        logger.warning("Cannot import core.persist_to_db: %s", exc)
        return schemas
    sql = getattr(persist_to_db, "SCHEMA_SQL", None)
    if isinstance(sql, str) and sql.strip():
        schemas.append(("core/persist_to_db", sql))
    return schemas


def _domain_modules() -> list[str]:
    """Return fully-qualified names of every ``domains.<x>.domain`` module."""
    out: list[str] = []
    domains_dir = NEBULA_ROOT / "domains"
    if not domains_dir.is_dir():
        return out
    for entry in sorted(domains_dir.iterdir()):
        if not entry.is_dir() or entry.name.startswith("_") or entry.name.startswith("."):
            continue
        module_name = f"domains.{entry.name}.domain"
        if (entry / "domain.py").is_file():
            out.append(module_name)
    return out


def _domain_plugin_schemas() -> list[tuple[str, str]]:
    """Collect schema from domain plugin classes (legacy path)."""
    schemas: list[tuple[str, str]] = []
    for module_name in _domain_modules():
        try:
            module = importlib.import_module(module_name)
        except Exception as exc:
            logger.debug("Skipping domain module %s: %s", module_name, exc)
            continue
        for attr_name in dir(module):
            attr = getattr(module, attr_name, None)
            if not isinstance(attr, type):
                continue
            getter = getattr(attr, "get_db_schema_sql", None)
            if not callable(getter):
                continue
            try:
                instance = attr()
            except Exception as exc:
                logger.debug("Cannot instantiate %s.%s: %s", module_name, attr_name, exc)
                continue
            try:
                sql = getter(instance) if hasattr(getter, "__self__") is False else getter()
            except Exception as exc:
                logger.debug("%s.%s schema getter failed: %s", module_name, attr_name, exc)
                continue
            if isinstance(sql, str) and sql.strip():
                schemas.append((f"{module_name}.{attr_name}", sql))
    return schemas


def _engine_schemas() -> list[tuple[str, str]]:
    """Collect ``SCHEMA_SQL`` constants declared at engine module level."""
    schemas: list[tuple[str, str]] = []
    domains_dir = NEBULA_ROOT / "domains"
    if not domains_dir.is_dir():
        return schemas
    for domain_dir in sorted(domains_dir.iterdir()):
        engines_dir = domain_dir / "engines"
        if not engines_dir.is_dir():
            continue
        for engine_path in sorted(engines_dir.glob("*.py")):
            if engine_path.name.startswith("_"):
                continue
            module_name = f"domains.{domain_dir.name}.engines.{engine_path.stem}"
            try:
                module = importlib.import_module(module_name)
            except Exception as exc:
                logger.debug("Skipping engine %s: %s", module_name, exc)
                continue
            sql = getattr(module, "SCHEMA_SQL", None)
            if isinstance(sql, str) and sql.strip():
                schemas.append((module_name, sql))
    return schemas


def _core_module_schemas() -> list[tuple[str, str]]:
    """Collect ``SCHEMA_SQL`` constants declared in core/ modules.

    Some core modules (e.g. :mod:`core.aspiration_engine`) own small
    tables of their own. We pick those up automatically so they are
    created before engines try to use them.
    """
    schemas: list[tuple[str, str]] = []
    try:
        import core  # noqa: F401  - namespace package import
    except Exception as exc:
        logger.debug("Cannot import core package: %s", exc)
        return schemas
    core_pkg_path = NEBULA_ROOT / "core"
    if not core_pkg_path.is_dir():
        return schemas
    for info in pkgutil.iter_modules([str(core_pkg_path)]):
        if info.ispkg or info.name.startswith("_"):
            continue
        if info.name == "persist_to_db":
            continue  # already covered
        module_name = f"core.{info.name}"
        try:
            module = importlib.import_module(module_name)
        except Exception as exc:
            logger.debug("Skipping core module %s: %s", module_name, exc)
            continue
        sql = getattr(module, "SCHEMA_SQL", None)
        if isinstance(sql, str) and sql.strip():
            schemas.append((module_name, sql))
    return schemas


def collect_all_schemas() -> list[tuple[str, str]]:
    """Return every known schema fragment in execution order.

    Execution order is deliberately:
        1. Core package (``evidence``, ``hypotheses``, etc. first).
        2. Additional ``core/*.py`` modules with their own tables.
        3. Domain plugin classes (legacy).
        4. Engine modules.

    Downstream fragments can safely reference tables declared by
    earlier fragments.
    """
    return [
        *_core_schemas(),
        *_core_module_schemas(),
        *_domain_plugin_schemas(),
        *_engine_schemas(),
    ]


def apply_all_schemas(db_path: str) -> dict:
    """Apply every registered schema fragment to ``db_path``.

    Each fragment is executed with ``executescript`` inside a try/except
    so a broken fragment cannot prevent the rest of the schema from
    landing. Returns a summary dict with counts and the final list of
    tables present in the database.
    """
    fragments = collect_all_schemas()
    applied = 0
    errors: list[str] = []

    conn = connect(db_path)
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        for source, sql in fragments:
            try:
                conn.executescript(sql)
                conn.commit()
                applied += 1
            except sqlite3.Error as exc:
                msg = f"{source}: {exc}"
                errors.append(msg)
                logger.warning("Schema registry apply failed %s", msg)
        tables = sorted(
            r[0]
            for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        )
    finally:
        conn.close()

    logger.info(
        "Schema registry: %d/%d fragments applied, %d tables present",
        applied,
        len(fragments),
        len(tables),
    )
    return {
        "applied": applied,
        "total_fragments": len(fragments),
        "errors": errors,
        "tables": tables,
    }


def verify_schema_usage(db_path: str) -> dict:
    """Return a summary of current tables and columns for diagnostics.

    This is a passive report - it never mutates the database. Useful
    for the ``nebula schema`` CLI command.
    """
    conn = connect(db_path)
    try:
        tables = sorted(
            r[0]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        )
        table_columns: dict[str, list[str]] = {}
        for table in tables:
            cols = [row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()]
            table_columns[table] = cols
    finally:
        conn.close()
    return {"tables": tables, "columns": table_columns}


__all__ = [
    "apply_all_schemas",
    "collect_all_schemas",
    "verify_schema_usage",
]
