# SPDX-License-Identifier: MIT
"""Upgrade Check — v0.6.0 operator-facing upgrade notifier.

Task #50 Track 2. Checks PyPI for the latest `zenon-nebula` release
and tells the operator whether an upgrade is available. Designed to
be safe, bounded, opt-out-able, and cached so it never slows down
the CLI.

**Resolution order:**
1. If `NEBULA_SKIP_UPGRADE_CHECK=1` env var is set → return "no check".
2. Look for a cached result in `data/upgrade_check.json` with a TTL.
   The default TTL is 24 hours so most CLI invocations hit the cache
   and never touch the network.
3. If the cache is stale or missing, fetch the PyPI JSON endpoint
   for `zenon-nebula` with a hard 5-second timeout (short enough that
   network flakiness doesn't block the CLI even when offline).
4. Compare the current version to the latest, return a structured
   `UpgradeStatus` dataclass the CLI can render.

**Safety invariants:**
- Never blocks the CLI for more than 5 seconds.
- Never blocks if the PyPI endpoint is unreachable.
- Never blocks if the cache file is corrupt.
- Never downloads the wheel — only reads the metadata JSON.
- Never runs pip install automatically. The notifier shows the
  operator what to do; the operator decides.
- Respects `NEBULA_SKIP_UPGRADE_CHECK` so operators in restricted
  environments (air-gapped, corporate proxies, privacy-first) can
  opt out entirely.
- All timeouts fail-safe to "no update available" rather than
  surfacing errors to the user — the goal is a helpful prompt, not
  a noisy warning.

**What this does NOT do:**
- Does NOT perform the upgrade. That's task #50 Track 2 Phase B
  (ship a future `./nebula upgrade` command that verifies sigstore
  signatures before running pip install).
- Does NOT rollback. That's task #50 Track 2 Phase C.
- Does NOT pull CHANGELOG for the latest version (just version
  number). The CHANGELOG fetch is a follow-up enhancement.
"""

from __future__ import annotations

import json
import logging
import os
import re
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
CACHE_PATH = ENGINE_ROOT / "data" / "upgrade_check.json"
PYPI_JSON_URL = "https://pypi.org/pypi/zenon-nebula/json"

# Cache TTL — hitting PyPI more often than this is rude and slow.
_CACHE_TTL_HOURS = 24

# Hard timeout for the PyPI fetch. Tight because the CLI shouldn't
# hang waiting for an optional feature.
_FETCH_TIMEOUT_SECONDS = 5

# Semver-ish regex
_VERSION_RE = re.compile(r"^(\d+)\.(\d+)\.(\d+)(?:[.-]?(.*))?$")


@dataclass
class UpgradeStatus:
    """Result of an upgrade check. Safe to JSON-serialize."""

    current_version: str
    latest_version: str | None
    update_available: bool
    major_bump: bool
    minor_bump: bool
    patch_bump: bool
    checked_at: str
    cache_hit: bool
    notes: list[str]

    def to_dict(self) -> dict:
        """Return a JSON-serializable dict of this status."""
        return {
            "current_version": self.current_version,
            "latest_version": self.latest_version,
            "update_available": self.update_available,
            "major_bump": self.major_bump,
            "minor_bump": self.minor_bump,
            "patch_bump": self.patch_bump,
            "checked_at": self.checked_at,
            "cache_hit": self.cache_hit,
            "notes": self.notes,
        }


def _parse_version(version: str) -> tuple[int, int, int, str] | None:
    """Return `(major, minor, patch, suffix)` or None on malformed input."""
    match = _VERSION_RE.match(version.strip())
    if not match:
        return None
    major = int(match.group(1))
    minor = int(match.group(2))
    patch = int(match.group(3))
    suffix = match.group(4) or ""
    return (major, minor, patch, suffix)


def _compare_versions(current: str, latest: str) -> tuple[bool, bool, bool, bool]:
    """Compare two versions.

    Returns `(update_available, major_bump, minor_bump, patch_bump)`.
    Pre-release suffixes (alpha, rc, etc.) are treated as less-than
    the same version without a suffix, matching PEP 440 semantics
    loosely.
    """
    c = _parse_version(current)
    lv = _parse_version(latest)
    if c is None or lv is None:
        return (False, False, False, False)

    if lv[0] > c[0]:
        return (True, True, False, False)
    if lv[0] == c[0] and lv[1] > c[1]:
        return (True, False, True, False)
    if lv[0] == c[0] and lv[1] == c[1] and lv[2] > c[2]:
        return (True, False, False, True)
    return (False, False, False, False)


def _load_cache() -> dict | None:
    """Return the cached upgrade check result, or None if stale/missing."""
    if not CACHE_PATH.is_file():
        return None
    try:
        raw = json.loads(CACHE_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    checked_at = raw.get("checked_at")
    if not checked_at:
        return None
    try:
        checked_dt = datetime.fromisoformat(checked_at.replace("Z", "+00:00"))
    except ValueError:
        return None
    if checked_dt.tzinfo is None:
        checked_dt = checked_dt.replace(tzinfo=timezone.utc)
    age = datetime.now(timezone.utc) - checked_dt
    if age > timedelta(hours=_CACHE_TTL_HOURS):
        return None
    return raw


def _save_cache(payload: dict) -> None:
    """Best-effort cache write. Never crashes the caller."""
    try:
        CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        CACHE_PATH.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except OSError as exc:
        logger.debug("upgrade_check cache write failed: %s", exc)


def _fetch_latest_version_from_pypi() -> str | None:
    """Hit PyPI's JSON endpoint once with a hard timeout."""
    try:
        req = urllib.request.Request(
            PYPI_JSON_URL,
            headers={"User-Agent": "zenon-nebula/upgrade-check"},
        )
        with urllib.request.urlopen(req, timeout=_FETCH_TIMEOUT_SECONDS) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
        latest = data.get("info", {}).get("version")
        if isinstance(latest, str):
            return latest
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        logger.debug("PyPI fetch failed: %s", exc)
    except Exception as exc:
        logger.debug("unexpected upgrade-check error: %s", exc)
    return None


def check_for_update(
    current_version: str | None = None,
    *,
    force_refresh: bool = False,
) -> UpgradeStatus:
    """Return the upgrade status for the current install.

    Args:
        current_version: Override the local version. Defaults to
            `core.version.__version__`.
        force_refresh: Skip the cache even if fresh. Used by
            ``./nebula upgrade --check`` to force a live lookup.

    Returns:
        UpgradeStatus dataclass with current/latest + diff info.
    """
    notes: list[str] = []

    if current_version is None:
        try:
            from core.version import __version__

            current_version = __version__
        except Exception:
            current_version = "unknown"

    # Opt-out via env var
    if os.environ.get("NEBULA_SKIP_UPGRADE_CHECK") == "1":
        notes.append("NEBULA_SKIP_UPGRADE_CHECK=1 — upgrade check disabled")
        return UpgradeStatus(
            current_version=current_version,
            latest_version=None,
            update_available=False,
            major_bump=False,
            minor_bump=False,
            patch_bump=False,
            checked_at=datetime.now(timezone.utc).isoformat(),
            cache_hit=False,
            notes=notes,
        )

    cached = None if force_refresh else _load_cache()
    if cached is not None:
        notes.append("cached result (TTL 24h)")
        latest = cached.get("latest_version")
    else:
        latest = _fetch_latest_version_from_pypi()
        payload = {
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "latest_version": latest,
        }
        _save_cache(payload)
        notes.append("fetched from pypi")

    if latest is None:
        notes.append("could not determine latest version")
        return UpgradeStatus(
            current_version=current_version,
            latest_version=None,
            update_available=False,
            major_bump=False,
            minor_bump=False,
            patch_bump=False,
            checked_at=datetime.now(timezone.utc).isoformat(),
            cache_hit=cached is not None,
            notes=notes,
        )

    update, major, minor, patch = _compare_versions(current_version, latest)

    return UpgradeStatus(
        current_version=current_version,
        latest_version=latest,
        update_available=update,
        major_bump=major,
        minor_bump=minor,
        patch_bump=patch,
        checked_at=datetime.now(timezone.utc).isoformat(),
        cache_hit=cached is not None,
        notes=notes,
    )


def format_for_cli(status: UpgradeStatus) -> str:
    """Human-readable one-line update banner for the CLI."""
    if not status.update_available:
        return ""
    bump_kind = "MAJOR" if status.major_bump else "minor" if status.minor_bump else "patch"
    return (
        f"Update available: {status.current_version} -> {status.latest_version} "
        f"({bump_kind}). Run `./nebula upgrade` to review."
    )
