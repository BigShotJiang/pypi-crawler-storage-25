# SPDX-License-Identifier: MIT
"""
Persona Panel -- Multi-perspective reasoning for richer analysis.

Generalized from marketing's persona_panel.py. Five domain-agnostic personas
independently evaluate evidence via LLM calls, producing an ensemble verdict.
The panel surfaces blind spots by forcing evaluation through fundamentally
different lenses.

Personas:
    1. Security Expert -- paranoid threat modeler, every finding is an attack vector
    2. Economist -- tokenomics and incentive design, sustainability
    3. Community Builder -- contributor retention, onboarding, ecosystem health
    4. Core Dev -- architectural implications, what should be built next
    5. Newcomer -- fresh eyes, confusion points, excitement signals

Usage:
    from core.persona_panel import get_multi_perspective, synthesize_perspectives

    perspectives = get_multi_perspective(
        evidence_summary="New PTLC contract passes all 17 tests...",
    )
    synthesis = synthesize_perspectives(perspectives)
"""

import json
import logging
from collections import Counter
from datetime import datetime, timezone

from core.llm_provider import call_llm
from core.persist_to_db import persist_finding

logger = logging.getLogger(__name__)


PERSONAS: dict[str, dict[str, str]] = {
    "security_expert": {
        "name": "Security Expert",
        "system_prompt": (
            "You are a paranoid security researcher. Every finding is a potential "
            "attack vector. What risks does this evidence reveal? Look for: fund "
            "safety issues, reentrancy, access control gaps, denial of service, "
            "cryptographic weaknesses, and economic exploits."
        ),
    },
    "economist": {
        "name": "Economist",
        "system_prompt": (
            "You are a tokenomics expert. What do these findings mean for Zenon's "
            "economic sustainability? Analyze: staking incentives, liquidity depth, "
            "supply contraction, demand creation, fee market dynamics, and game-theoretic "
            "incentive alignment."
        ),
    },
    "community_builder": {
        "name": "Community Builder",
        "system_prompt": (
            "You are focused on community growth. What do these findings mean for "
            "contributor retention, developer onboarding, ecosystem health? Consider: "
            "documentation quality, tooling gaps, communication clarity, governance "
            "participation, and barriers to entry."
        ),
    },
    "core_dev": {
        "name": "Core Dev",
        "system_prompt": (
            "You think like a Zenon core developer. What architectural implications "
            "do these findings have? What should be built next? Consider: protocol "
            "correctness, consensus safety, backward compatibility, spork activation "
            "readiness, and cross-layer dependencies."
        ),
    },
    "newcomer": {
        "name": "Newcomer",
        "system_prompt": (
            "You just discovered Zenon. Based on these findings, would you contribute? "
            "What is confusing? What is exciting? What would make you stay or leave? "
            "Consider: learning curve, wow factor, comparison to projects you know, "
            "and whether the value proposition is clear."
        ),
    },
}


# Maps each domain to the persona most likely to have relevant insight
_DOMAIN_PERSONA_MAP: dict[str, str] = {
    "security": "security_expert",
    "economics": "economist",
    "community": "community_builder",
    "development": "core_dev",
    "devops": "core_dev",
    "quality": "core_dev",
    "marketing": "community_builder",
    "education": "newcomer",
    "governance": "economist",
    "intelligence": "security_expert",
    "interoperability": "core_dev",
    "investigation": "security_expert",
    "network_health": "security_expert",
    "product_market_fit": "newcomer",
    "standards": "core_dev",
    "contribution": "community_builder",
    "self_maintenance": "core_dev",
}


_EVALUATION_INSTRUCTIONS = (
    "\n\nRespond ONLY with valid JSON matching this schema:\n"
    '{"significance": "BREAKTHROUGH|SIGNIFICANT|INCREMENTAL|NOISE", '
    '"reasoning": "2-3 sentences from your persona perspective", '
    '"score": 0.0-1.0, '
    '"key_insight": "one sentence unique insight from your perspective"}'
)


def _parse_json_response(text: str) -> dict:
    """Best-effort JSON extraction from LLM response."""
    # Strip markdown code fences
    if text.startswith("```"):
        lines = text.split("\n")
        text = "\n".join(line for line in lines if not line.strip().startswith("```"))

    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return parsed
    except json.JSONDecodeError:
        pass

    # Try to find JSON object in the text
    start = text.find("{")
    end = text.rfind("}") + 1
    if start >= 0 and end > start:
        try:
            parsed = json.loads(text[start:end])
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass

    # Fallback
    return {
        "significance": "NOISE",
        "reasoning": text[:300],
        "score": 0.0,
        "key_insight": "",
    }


def _get_persona_vote(
    persona_id: str,
    persona: dict,
    evidence_summary: str,
    context: str = "",
    model: str = "auto",
) -> dict:
    """Get a single persona's evaluation of the evidence.

    Args:
        persona_id: Key into PERSONAS dict.
        persona: Persona definition with name and system_prompt.
        evidence_summary: The evidence text to evaluate.
        context: Optional additional context.
        model: LLM model to use (default: auto).

    Returns:
        Dict with significance, reasoning, score, key_insight.
    """
    system = persona["system_prompt"] + _EVALUATION_INSTRUCTIONS

    prompt = f"## Evidence to Evaluate\n\n{evidence_summary}"
    if context:
        prompt += f"\n\n## Additional Context\n\n{context}"

    try:
        result = call_llm(
            prompt=prompt,
            system=system,
            model=model,
            max_tokens=512,
            temperature=0.4,
        )
        if result is None:
            return {
                "significance": "NOISE",
                "reasoning": "LLM call returned no result.",
                "score": 0.0,
                "key_insight": "",
                "error": True,
            }

        return _parse_json_response(result["text"])

    except Exception as exc:
        logger.error(
            "Persona '%s' vote failed: %s",
            persona["name"],
            exc,
        )
        return {
            "significance": "NOISE",
            "reasoning": f"Evaluation failed: {exc}",
            "score": 0.0,
            "key_insight": "",
            "error": True,
        }


def get_multi_perspective(
    evidence_summary: str,
    context: str = "",
    model: str = "auto",
    personas: dict[str, dict] | None = None,
) -> dict[str, dict]:
    """Get all persona perspectives on the same evidence.

    Args:
        evidence_summary: The evidence text to evaluate.
        context: Optional additional context.
        model: LLM model to use.
        personas: Custom personas dict (default: global PERSONAS).

    Returns:
        Dict mapping persona_id -> vote dict with
        significance, reasoning, score, key_insight.
    """
    if personas is None:
        personas = PERSONAS

    perspectives: dict[str, dict] = {}
    for persona_id, persona in personas.items():
        vote = _get_persona_vote(
            persona_id,
            persona,
            evidence_summary,
            context,
            model,
        )
        perspectives[persona_id] = vote
        logger.debug(
            "Persona %s: %s (score=%.2f)",
            persona_id,
            vote.get("significance", "?"),
            vote.get("score", 0),
        )

    return perspectives


def synthesize_perspectives(
    perspectives: dict[str, dict],
    db_path: str | None = None,
    domain: str = "system",
) -> dict:
    """Combine all persona perspectives into a unified synthesis.

    Args:
        perspectives: Output of get_multi_perspective().
        db_path: Optional DB path for persisting the synthesis.
        domain: Domain label for persistence.

    Returns:
        Dict with: ensemble_verdict, unanimous, dissent, mean_score,
        confidence_spread, key_insights, perspectives, timestamp.
    """
    if not perspectives:
        return {
            "ensemble_verdict": "NOISE",
            "unanimous": True,
            "dissent": [],
            "mean_score": 0.0,
            "confidence_spread": 0.0,
            "key_insights": [],
            "perspectives": {},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    # Ensemble verdict: majority significance level
    significance_votes = [v.get("significance", "NOISE") for v in perspectives.values()]
    most_common = Counter(significance_votes).most_common(1)[0][0]

    # Calculate confidence spread (std dev of scores)
    scores = [v.get("score", 0.5) for v in perspectives.values()]
    mean_score = sum(scores) / len(scores) if scores else 0.5
    variance = sum((s - mean_score) ** 2 for s in scores) / len(scores) if scores else 0
    confidence_spread = variance**0.5

    # Collect key insights from each persona
    key_insights = [
        {
            "persona": pid,
            "insight": v.get("key_insight", ""),
            "significance": v.get("significance", "NOISE"),
        }
        for pid, v in perspectives.items()
        if v.get("key_insight")
    ]

    result = {
        "ensemble_verdict": most_common,
        "unanimous": len(set(significance_votes)) == 1,
        "dissent": [pid for pid, v in perspectives.items() if v.get("significance") != most_common],
        "mean_score": round(mean_score, 3),
        "confidence_spread": round(confidence_spread, 3),
        "key_insights": key_insights,
        "perspectives": perspectives,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    # Persist if DB path provided
    if db_path:
        try:
            persist_finding(
                db_path=db_path,
                domain=domain,
                engine="persona_panel",
                evidence_type="multi_perspective_synthesis",
                finding=(
                    f"Panel verdict: {most_common} "
                    f"(unanimous={result['unanimous']}, "
                    f"mean_score={result['mean_score']:.2f}, "
                    f"spread={result['confidence_spread']:.2f})"
                ),
                confidence=result["mean_score"],
                raw_data=result,
            )
        except Exception as exc:
            logger.debug("Panel synthesis persistence failed: %s", exc)

    return result


def get_persona_for_domain(domain_name: str) -> str:
    """Return the most relevant persona ID for a given domain.

    Args:
        domain_name: Domain name (e.g. "security", "economics").

    Returns:
        Persona ID string (e.g. "security_expert").
    """
    return _DOMAIN_PERSONA_MAP.get(domain_name, "core_dev")
