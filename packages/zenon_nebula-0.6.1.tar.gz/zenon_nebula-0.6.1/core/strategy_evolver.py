# SPDX-License-Identifier: MIT
"""
Strategy Evolver -- OOBE (Observe-Analyze-Discover-Test-Evolve) cycle.

Runs the full evolution loop across all domains:

  OBSERVE   -- Aggregate metrics from all domains
  ANALYZE   -- Classify each domain as ACCELERATING / STABLE / DECLINING / STALLED
  DISCOVER  -- Propose new cross-domain strategies via LLM
  TEST      -- Run experimental approaches
  EVOLVE    -- Promote winners, retire losers, rebalance resources

Intended to run on a weekly cycle. Domain health is tracked over time
and informs resource allocation decisions.
"""

import contextlib
import json
import logging
import sqlite3
from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Classification thresholds (evidence-per-week)
ACCEL_THRESHOLD = 10  # findings above this = ACCELERATING
STABLE_FLOOR = 3  # findings above this = STABLE
STALLED_CEILING = 0  # zero findings = STALLED

# Weeks of decline before auto-deprioritization
DECLINE_WEEKS_THRESHOLD = 3

STRATEGY_SCHEMA = """
CREATE TABLE IF NOT EXISTS strategy_cycles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    cycle_type TEXT DEFAULT 'weekly',
    domain_statuses TEXT DEFAULT '{}',
    strategies_proposed TEXT DEFAULT '[]',
    strategies_promoted TEXT DEFAULT '[]',
    strategies_retired TEXT DEFAULT '[]',
    resource_allocation TEXT DEFAULT '{}',
    elapsed_seconds REAL DEFAULT 0.0
);

CREATE INDEX IF NOT EXISTS idx_strategy_cycles_ts
    ON strategy_cycles(timestamp);
"""

# Exposed at module level so core.schema_registry applies the table
# during boot even if StrategyEvolver is never instantiated.
SCHEMA_SQL = STRATEGY_SCHEMA


class StrategyEvolver:
    """OOBE evolution loop across all domains.

    Observes domain metrics, analyzes health, discovers new strategies,
    tests them, and evolves the system's approach over time.
    """

    def __init__(
        self,
        db_path: str = DEFAULT_DB,
        llm_call: Callable | None = None,
    ):
        self.db_path = db_path
        self._llm_call = llm_call
        self._ensure_schema()

    def _get_conn(self) -> sqlite3.Connection:
        conn = connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        conn = self._get_conn()
        try:
            conn.executescript(STRATEGY_SCHEMA)
            conn.commit()
        finally:
            conn.close()

    # ==================================================================
    # Main entry point
    # ==================================================================

    def run_evolution_cycle(
        self,
        registry=None,
        dry_run: bool = False,
    ) -> dict:
        """One full OBSERVE -> ANALYZE -> DISCOVER -> TEST -> EVOLVE loop.

        Args:
            registry: DomainRegistry for domain queries.
            dry_run: Skip destructive operations.

        Returns:
            Dict with results from each phase.
        """
        start = datetime.now(timezone.utc)
        results = {
            "cycle_started_at": start.isoformat(),
            "dry_run": dry_run,
        }

        logger.info("=== Strategy Evolution START ===")

        results["observe"] = self._observe(registry)
        results["analyze"] = self._analyze(results["observe"])
        results["discover"] = self._discover(results["analyze"])
        results["test"] = self._test()
        results["evolve"] = self._evolve(results["analyze"], dry_run=dry_run)

        elapsed = (datetime.now(timezone.utc) - start).total_seconds()
        results["elapsed_seconds"] = round(elapsed, 2)

        if not dry_run:
            self._persist_cycle(results)

        logger.info("=== Strategy Evolution END (%.1fs) ===", elapsed)
        return results

    # ==================================================================
    # OBSERVE
    # ==================================================================

    def _observe(self, registry=None) -> dict:
        """Aggregate metrics from all domains."""
        observation = {
            "domains": {},
            "total_evidence": 0,
            "total_actions": 0,
            "total_cost": 0.0,
        }

        conn = self._get_conn()
        try:
            # Evidence by domain (last 7 days)
            cutoff = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()

            try:
                rows = conn.execute(
                    "SELECT domain, count(*) as cnt, "
                    "avg(confidence) as avg_conf "
                    "FROM evidence WHERE timestamp > ? "
                    "GROUP BY domain",
                    (cutoff,),
                ).fetchall()
                for row in rows:
                    observation["domains"][row["domain"]] = {
                        "evidence_7d": row["cnt"],
                        "avg_confidence_7d": round(row["avg_conf"] or 0, 3),
                    }
            except sqlite3.OperationalError:
                pass

            # Actions by domain (last 7 days)
            try:
                rows = conn.execute(
                    "SELECT domain, count(*) as cnt, "
                    "sum(cost_usd) as total_cost, "
                    "sum(CASE WHEN error IS NOT NULL "
                    "AND error != '' THEN 1 ELSE 0 END) as errors "
                    "FROM actions_log WHERE timestamp > ? "
                    "GROUP BY domain",
                    (cutoff,),
                ).fetchall()
                for row in rows:
                    d = observation["domains"].setdefault(row["domain"], {})
                    d["actions_7d"] = row["cnt"]
                    d["cost_7d"] = round(row["total_cost"] or 0, 4)
                    d["errors_7d"] = row["errors"]
                    observation["total_actions"] += row["cnt"]
                    observation["total_cost"] += row["total_cost"] or 0
            except sqlite3.OperationalError:
                pass

            # Total evidence
            with contextlib.suppress(sqlite3.OperationalError):
                observation["total_evidence"] = conn.execute(
                    "SELECT count(*) FROM evidence"
                ).fetchone()[0]

            # Self-improvement metrics from registry
            if registry:
                for domain in registry.get_all_domains():
                    d = observation["domains"].setdefault(domain.name(), {})
                    d["self_metrics"] = domain.get_self_improvement_metrics()

        finally:
            conn.close()

        return observation

    # ==================================================================
    # ANALYZE
    # ==================================================================

    def _analyze(self, observation: dict) -> dict:
        """Classify each domain as ACCELERATING/STABLE/DECLINING/STALLED."""
        domain_statuses = {}
        conn = self._get_conn()

        try:
            for domain_name, metrics in observation.get("domains", {}).items():
                evidence_7d = metrics.get("evidence_7d", 0)

                # Get previous week for trend
                cutoff_14d = (datetime.now(timezone.utc) - timedelta(days=14)).isoformat()
                cutoff_7d = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()

                try:
                    prev = conn.execute(
                        "SELECT count(*) as cnt FROM evidence "
                        "WHERE domain = ? "
                        "AND timestamp > ? AND timestamp <= ?",
                        (domain_name, cutoff_14d, cutoff_7d),
                    ).fetchone()
                    evidence_prev = prev["cnt"] if prev else 0
                except sqlite3.OperationalError:
                    evidence_prev = 0

                # Classify
                if evidence_7d >= ACCEL_THRESHOLD:
                    if evidence_prev > 0 and evidence_7d > evidence_prev * 1.3:
                        classification = "ACCELERATING"
                    else:
                        classification = "STABLE"
                elif evidence_7d >= STABLE_FLOOR:
                    classification = "STABLE"
                elif evidence_7d == STALLED_CEILING:
                    classification = "STALLED"
                else:
                    if evidence_prev > evidence_7d:
                        classification = "DECLINING"
                    else:
                        classification = "STABLE"

                domain_statuses[domain_name] = {
                    "classification": classification,
                    "evidence_7d": evidence_7d,
                    "evidence_prev_7d": evidence_prev,
                    "trend": (
                        "up"
                        if evidence_7d > evidence_prev
                        else "down"
                        if evidence_7d < evidence_prev
                        else "flat"
                    ),
                }

        finally:
            conn.close()

        return {
            "domain_statuses": domain_statuses,
            "stalled_count": sum(
                1 for s in domain_statuses.values() if s["classification"] == "STALLED"
            ),
            "accelerating_count": sum(
                1 for s in domain_statuses.values() if s["classification"] == "ACCELERATING"
            ),
        }

    # ==================================================================
    # DISCOVER
    # ==================================================================

    def _discover(self, analysis: dict) -> dict:
        """Propose new cross-domain strategies via LLM."""
        stalled = analysis.get("stalled_count", 0)
        if stalled == 0:
            return {"skipped": True, "reason": "no stalled domains"}

        if not self._llm_call:
            return {
                "skipped": True,
                "reason": "no LLM configured",
                "stalled_domains": [
                    name
                    for name, s in analysis.get("domain_statuses", {}).items()
                    if s["classification"] == "STALLED"
                ],
            }

        prompt = (
            f"Domain health analysis:\n"
            f"{json.dumps(analysis['domain_statuses'], indent=2)}\n\n"
            f"{stalled} domain(s) are STALLED. Propose strategies to "
            f"unstick them. Consider cross-domain approaches where one "
            f"domain's output feeds another.\n\n"
            f"Return a JSON array of strategy objects with keys: "
            f"title, target_domains, approach, expected_outcome."
        )

        result = self._llm_call("strategy_discovery", prompt)
        strategies = result if isinstance(result, list) else []

        return {
            "strategies_proposed": len(strategies),
            "strategies": strategies,
        }

    # ==================================================================
    # TEST
    # ==================================================================

    def _test(self) -> dict:
        """Evaluate running experiments. Placeholder for future expansion."""
        return {"evaluated": 0, "note": "experiment framework pending"}

    # ==================================================================
    # EVOLVE
    # ==================================================================

    def _evolve(self, analysis: dict, dry_run: bool = False) -> dict:
        """Promote winners, retire losers, rebalance resources."""
        changes = {"promoted": [], "deprioritized": [], "rebalanced": False}

        domain_statuses = analysis.get("domain_statuses", {})

        # Resource allocation: proportional to classification
        weights = {
            "ACCELERATING": 3.0,
            "STABLE": 2.0,
            "DECLINING": 1.0,
            "STALLED": 0.5,
        }
        total_weight = sum(weights.get(s["classification"], 1.0) for s in domain_statuses.values())

        allocation = {}
        for name, status in domain_statuses.items():
            w = weights.get(status["classification"], 1.0)
            allocation[name] = round(w / max(total_weight, 1), 3)

            if status["classification"] == "ACCELERATING":
                changes["promoted"].append(name)
            elif status["classification"] == "STALLED":
                changes["deprioritized"].append(name)

        changes["resource_allocation"] = allocation
        changes["rebalanced"] = True

        return changes

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _persist_cycle(self, results: dict) -> None:
        """Save cycle results to the strategy_cycles table."""
        conn = self._get_conn()
        try:
            conn.execute(
                "INSERT INTO strategy_cycles "
                "(domain_statuses, strategies_proposed, "
                "strategies_promoted, strategies_retired, "
                "resource_allocation, elapsed_seconds) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    json.dumps(results.get("analyze", {}).get("domain_statuses", {}), default=str),
                    json.dumps(results.get("discover", {}).get("strategies", []), default=str),
                    json.dumps(results.get("evolve", {}).get("promoted", []), default=str),
                    json.dumps(results.get("evolve", {}).get("deprioritized", []), default=str),
                    json.dumps(
                        results.get("evolve", {}).get("resource_allocation", {}), default=str
                    ),
                    results.get("elapsed_seconds", 0),
                ),
            )
            conn.commit()
        finally:
            conn.close()

        from core.persist_to_db import persist_action

        persist_action(
            db_path=self.db_path,
            domain="system",
            module="strategy_evolver",
            action="evolution_cycle",
            result=json.dumps(
                {
                    "accelerating": results.get("analyze", {}).get("accelerating_count", 0),
                    "stalled": results.get("analyze", {}).get("stalled_count", 0),
                },
                default=str,
            ),
        )
