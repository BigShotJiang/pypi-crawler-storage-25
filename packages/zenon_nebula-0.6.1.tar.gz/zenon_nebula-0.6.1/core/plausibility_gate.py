# SPDX-License-Identifier: MIT
"""Plausibility Gate -- catches implausible results before persistence.

Adapted from a proven external research pattern for blockchain intelligence.

Before a finding is persisted, runs sanity checks:
  - Confidence > 0.99 from a single engine -> suspicious (cap at 0.95)
  - Finding text is empty or under 20 chars -> reject
  - Finding references a repo that doesn't exist in workspace -> flag
  - Finding claims "0 vulnerabilities" for a contract with known issues -> suspicious
  - Evidence type doesn't match domain expectations -> flag

Function: check_plausibility(finding_dict) -> dict with plausible: bool, flags: list
Wire into persist_finding() as an optional pre-check.
No LLM calls.
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# Confidence cap for single-engine findings
SINGLE_ENGINE_CONFIDENCE_CAP = 0.95

# Minimum finding text length (permissive: only catches near-empty findings)
MIN_FINDING_LENGTH = 2

# Known domain -> expected evidence types mapping
_DOMAIN_EVIDENCE_TYPES: dict[str, set[str]] = {
    "security": {
        "vulnerability",
        "security_finding",
        "hostile_review",
        "bug_found",
        "audit_result",
        "cve",
        "advisory",
        "qa_hardening",
        "qa_anomaly",
        "qa_plausibility",
    },
    "intelligence": {
        "upstream_commit",
        "github_commit",
        "commit_scan",
        "pr_scan",
        "release_scan",
        "github_event",
        "spec_update",
    },
    "development": {
        "spec_coverage",
        "implementation",
        "verification",
        "build_result",
        "test_result",
        "mismatch",
        "spec_update",
    },
    "quality": {
        "build_failure",
        "test_failure",
        "mismatch",
        "verification",
        "qa_hardening",
        "qa_anomaly",
        "qa_plausibility",
        "qa_novelty",
        "compliance_check",
    },
    "economics": {
        "liquidity_drop",
        "liquidity_change",
        "volume_spike",
        "market_anomaly",
        "price_data",
        "dex_metric",
        "bridge_metric",
    },
    "network_health": {
        "block_data",
        "momentum_data",
        "pillar_status",
        "sentinel_status",
        "plasma_metric",
        "node_metric",
    },
}

# Known repos in the workspace (partial list for validation)
_KNOWN_REPO_PATTERNS = [
    r"go-zenon",
    r"znn_sdk_dart",
    r"syrius",
    r"zenon-light-client",
    r"nomctl",
    r"znn_cli_dart",
    r"zenon-wiki",
    r"zenonhub",
    r"developer-commons",
    r"marketing",
    r"nebula",
]


@dataclass
class PlausibilityVerdict:
    """Result of a plausibility check."""

    plausible: bool = True
    flags: list[str] = field(default_factory=list)
    adjusted_confidence: float | None = None
    recommendation: str = "persist"  # "persist" | "reject" | "flag"


def _check_confidence(finding: dict) -> list[str]:
    """Check for suspicious confidence values."""
    flags = []
    confidence = finding.get("confidence", 0.0)

    if confidence > 0.99:
        flags.append(
            f"Confidence {confidence:.3f} exceeds 0.99 -- "
            f"capped to {SINGLE_ENGINE_CONFIDENCE_CAP}. "
            f"Perfect confidence from a single engine is implausible."
        )

    if confidence < 0.0 or confidence > 1.0:
        flags.append(f"Confidence {confidence} is outside valid range [0.0, 1.0].")

    return flags


def _check_finding_text(finding: dict) -> list[str]:
    """Check for empty or too-short finding text."""
    flags = []
    text = finding.get("finding", "") or ""

    if not text.strip():
        flags.append("Finding text is empty -- nothing to persist.")

    elif len(text.strip()) < MIN_FINDING_LENGTH:
        flags.append(
            f"Finding text is only {len(text.strip())} chars "
            f"(minimum: {MIN_FINDING_LENGTH}) -- too short to be meaningful."
        )

    return flags


def _check_repo_reference(finding: dict) -> list[str]:
    """Check if referenced repo exists in workspace."""
    flags = []
    source_repo = finding.get("source_repo", "") or ""

    if not source_repo:
        return flags

    workspace = os.environ.get("ZENON_WORKSPACE_ROOT", "")
    if not workspace:
        return flags

    # Check if repo path exists
    repo_name = source_repo.split("/")[-1] if "/" in source_repo else source_repo
    matched = any(re.search(pat, repo_name) for pat in _KNOWN_REPO_PATTERNS)

    if not matched:
        # Check filesystem
        candidates = [
            os.path.join(workspace, source_repo),
            os.path.join(workspace, "core", repo_name),
            os.path.join(workspace, "zenon-network", repo_name),
            os.path.join(workspace, "zenon-org", repo_name),
        ]
        if not any(os.path.isdir(c) for c in candidates):
            flags.append(
                f"Source repo '{source_repo}' not found in workspace -- "
                f"finding may reference a nonexistent repository."
            )

    return flags


def _check_domain_evidence_match(finding: dict) -> list[str]:
    """Check if evidence type is plausible for the declared domain."""
    flags = []
    domain = finding.get("domain", "")
    evidence_type = finding.get("evidence_type", "")

    if not domain or not evidence_type:
        return flags

    expected_types = _DOMAIN_EVIDENCE_TYPES.get(domain)
    if expected_types and evidence_type not in expected_types:
        flags.append(
            f"Evidence type '{evidence_type}' is unusual for domain '{domain}'. "
            f"Expected one of: {', '.join(sorted(expected_types)[:5])}..."
        )

    return flags


def _check_zero_vuln_claim(finding: dict) -> list[str]:
    """Check for suspicious 'zero vulnerabilities' claims."""
    flags = []
    text = (finding.get("finding", "") or "").lower()

    zero_vuln_patterns = [
        r"0 vulnerabilit",
        r"zero vulnerabilit",
        r"no vulnerabilit.*found",
        r"no issues.*found",
        r"clean.*audit",
        r"100%.*secure",
    ]

    for pat in zero_vuln_patterns:
        if re.search(pat, text):
            flags.append(
                "Finding claims zero vulnerabilities or perfect security -- "
                "this is suspicious for any non-trivial codebase. "
                "Verify the scan actually executed properly."
            )
            break

    return flags


def check_plausibility(finding: dict) -> PlausibilityVerdict:
    """Run plausibility checks on a finding before persistence.

    Args:
        finding: Dict with keys matching persist_finding() parameters:
                 domain, engine, evidence_type, finding, confidence,
                 source_repo, source_file, etc.

    Returns:
        PlausibilityVerdict with plausible flag, issues list, and
        optional adjusted confidence.
    """
    verdict = PlausibilityVerdict()
    all_flags: list[str] = []

    # Run all checks
    all_flags.extend(_check_confidence(finding))
    all_flags.extend(_check_finding_text(finding))
    all_flags.extend(_check_repo_reference(finding))
    all_flags.extend(_check_domain_evidence_match(finding))
    all_flags.extend(_check_zero_vuln_claim(finding))

    verdict.flags = all_flags

    # Determine verdict
    confidence = finding.get("confidence", 0.0)
    text = (finding.get("finding", "") or "").strip()

    if not text:
        # Empty finding -- reject outright
        verdict.plausible = False
        verdict.recommendation = "reject"
    elif len(text) < MIN_FINDING_LENGTH:
        verdict.plausible = False
        verdict.recommendation = "reject"
    elif confidence > 0.99:
        # Cap confidence but allow persistence
        verdict.plausible = True
        verdict.adjusted_confidence = SINGLE_ENGINE_CONFIDENCE_CAP
        verdict.recommendation = "persist"
    elif all_flags:
        # Has flags but may still be valid
        verdict.plausible = True
        verdict.recommendation = "flag"
    else:
        verdict.plausible = True
        verdict.recommendation = "persist"

    if all_flags:
        logger.debug(
            "Plausibility check: %d flags for finding from %s/%s: %s",
            len(all_flags),
            finding.get("domain", "?"),
            finding.get("engine", "?"),
            "; ".join(all_flags[:3]),
        )

    return verdict
