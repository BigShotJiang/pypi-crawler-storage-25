# SPDX-License-Identifier: MIT
"""
Parallel Runner — Execute domain engines concurrently based on machine specs.

**Agent pattern:** *parallelization via sectioning* (Anthropic
"Building Effective Agents" taxonomy). Each domain engine is an
independent section of the work. The runner fans them out onto worker
threads/processes sized to the host, then gathers the section results
into a single cycle summary. Each section's work is self-contained --
there are no inter-engine dependencies within a cycle, which is what
makes sectioning safe.

Detects: CPU cores, RAM, OS, network speed.
Adapts: runs N engines in parallel where N = optimal for this machine.

Strategies by platform:
  - Mac (8-16 cores, 16-64GB): 4-8 parallel engines
  - Linux VPS (2-8 cores, 4-32GB): 2-4 parallel engines
  - Windows (4-16 cores, 8-64GB): 4-8 parallel engines
  - Low-end VPS (1-2 cores, 1-2GB): sequential, but batch free engines

Key insight:
  - Local engines (git, grep, filesystem) are I/O bound → parallelize aggressively
  - LLM engines are network bound → parallelize but respect rate limits
  - DB writes are serialized by SQLite → use WAL mode for concurrent reads
"""

import logging
import multiprocessing
import os
import platform
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ENGINE_ROOT / "data" / "engine.db"


@dataclass
class MachineProfile:
    """Detected machine capabilities."""

    os_name: str
    cpu_cores: int
    ram_gb: float
    is_vps: bool
    recommended_parallelism: int
    recommended_strategy: str


def detect_machine() -> MachineProfile:
    """Detect machine specs and recommend parallelism level."""
    os_name = platform.system().lower()  # linux, darwin, windows
    cpu_cores = multiprocessing.cpu_count()

    # RAM detection
    ram_gb = 0.0
    try:
        if os_name == "darwin":
            import subprocess

            result = subprocess.run(
                ["sysctl", "-n", "hw.memsize"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            ram_gb = int(result.stdout.strip()) / (1024**3)
        elif os_name == "linux":
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        ram_gb = int(line.split()[1]) / (1024**2)
                        break
        elif os_name == "windows":
            import subprocess

            result = subprocess.run(
                ["wmic", "computersystem", "get", "TotalPhysicalMemory"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            for line in result.stdout.strip().split("\n"):
                line = line.strip()
                if line.isdigit():
                    ram_gb = int(line) / (1024**3)
    except Exception:
        ram_gb = 4.0  # Conservative default

    # VPS detection heuristics
    is_vps = False
    if os_name == "linux":
        try:
            with open("/sys/class/dmi/id/product_name") as f:
                product = f.read().strip().lower()
                is_vps = any(
                    v in product
                    for v in [
                        "virtual",
                        "kvm",
                        "vmware",
                        "xen",
                        "qemu",
                        "digitalocean",
                        "linode",
                        "vultr",
                        "hetzner",
                    ]
                )
        except (FileNotFoundError, PermissionError):
            # If we can't read DMI, check for common VPS indicators
            is_vps = os.path.exists("/etc/cloud") or cpu_cores <= 4

    # Recommend parallelism
    if ram_gb < 2 or cpu_cores <= 1:
        parallelism = 1
        strategy = "sequential"
    elif ram_gb < 4 or cpu_cores <= 2:
        parallelism = 2
        strategy = "light_parallel"
    elif ram_gb < 16 or cpu_cores <= 4:
        parallelism = min(4, cpu_cores)
        strategy = "moderate_parallel"
    elif ram_gb < 32 or cpu_cores <= 8:
        parallelism = min(6, cpu_cores)
        strategy = "full_parallel"
    else:
        parallelism = min(8, cpu_cores)
        strategy = "max_parallel"

    return MachineProfile(
        os_name=os_name,
        cpu_cores=cpu_cores,
        ram_gb=round(ram_gb, 1),
        is_vps=is_vps,
        recommended_parallelism=parallelism,
        recommended_strategy=strategy,
    )


def enable_wal_mode(db_path: str = str(DB_PATH)) -> None:
    """Enable WAL mode for concurrent read access.

    WAL (Write-Ahead Logging) allows multiple readers while one writer
    commits. Essential for parallel engine execution hitting the same DB.
    """
    conn = connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")  # Faster writes, still safe
    conn.close()
    logger.info("SQLite WAL mode enabled for %s", db_path)


class ParallelEngineRunner:
    """Runs domain engines in parallel based on machine capabilities.

    Local engines (I/O bound) use ThreadPoolExecutor — threads share GIL but
    that's fine for subprocess calls (git, gh, build commands).

    LLM engines (network bound) run in separate threads with rate limiting.
    """

    def __init__(self, max_workers: int | None = None):
        profile = detect_machine()
        self.max_workers = max_workers or profile.recommended_parallelism
        self.profile = profile
        logger.info(
            "Parallel runner: %s, %d cores, %.1fGB RAM, strategy=%s, workers=%d",
            profile.os_name,
            profile.cpu_cores,
            profile.ram_gb,
            profile.recommended_strategy,
            self.max_workers,
        )

    def run_engines(
        self,
        engines: list[dict],
        timeout_per_engine: int = 300,
    ) -> list[dict]:
        """Run a batch of engines in parallel.

        Args:
            engines: list of dicts with 'name', 'function', 'args'
            timeout_per_engine: max seconds per engine

        Returns:
            list of result dicts with 'name', 'success', 'result', 'duration'
        """
        results = []

        # Separate free (local) engines from paid (LLM) engines
        local_engines = [e for e in engines if not e.get("requires_llm", False)]
        llm_engines = [e for e in engines if e.get("requires_llm", False)]

        # Run local engines in parallel (I/O bound — use threads)
        if local_engines:
            logger.info(
                "Running %d local engines in parallel (max %d workers)",
                len(local_engines),
                self.max_workers,
            )
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = {}
                for engine in local_engines:
                    future = executor.submit(self._run_one_engine, engine, timeout_per_engine)
                    futures[future] = engine["name"]

                for future in as_completed(futures):
                    name = futures[future]
                    try:
                        result = future.result(timeout=timeout_per_engine)
                        results.append(result)
                    except Exception as e:
                        results.append(
                            {
                                "name": name,
                                "success": False,
                                "result": str(e),
                                "duration": 0,
                            }
                        )

        # Run LLM engines sequentially (respect API rate limits)
        for engine in llm_engines:
            logger.info("Running LLM engine: %s (sequential)", engine["name"])
            result = self._run_one_engine(engine, timeout_per_engine)
            results.append(result)

        return results

    def run_domains_parallel(
        self,
        domain_actions: list[tuple[str, Callable]],
        timeout: int = 60,
    ) -> list[dict]:
        """Run one action per domain in parallel.

        Each domain's decide_next_action() runs concurrently, then results
        are collected for the Director to rank.
        """
        results = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {}
            for domain_name, action_fn in domain_actions:
                future = executor.submit(action_fn)
                futures[future] = domain_name

            for future in as_completed(futures, timeout=timeout):
                domain_name = futures[future]
                try:
                    result = future.result(timeout=timeout)
                    results.append({"domain": domain_name, "action": result})
                except Exception as e:
                    results.append({"domain": domain_name, "action": None, "error": str(e)})

        return results

    def _run_one_engine(self, engine: dict, timeout: int) -> dict:
        """Run a single engine and capture result + timing."""
        name = engine["name"]
        fn = engine["function"]
        args = engine.get("args", ())
        kwargs = engine.get("kwargs", {})

        start = datetime.now(timezone.utc)
        try:
            result = fn(*args, **kwargs)
            duration = (datetime.now(timezone.utc) - start).total_seconds()
            return {
                "name": name,
                "success": True,
                "result": result,
                "duration": round(duration, 2),
            }
        except Exception as e:
            duration = (datetime.now(timezone.utc) - start).total_seconds()
            logger.warning("Engine %s failed: %s", name, e)
            return {
                "name": name,
                "success": False,
                "result": str(e),
                "duration": round(duration, 2),
            }


def get_performance_tips(profile: MachineProfile | None = None) -> list[str]:
    """Get optimization tips based on detected machine."""
    if profile is None:
        profile = detect_machine()

    tips = []

    if profile.ram_gb < 4:
        tips.append("Low RAM: disable concurrent build verification to avoid OOM")
    if profile.cpu_cores <= 2:
        tips.append("Few cores: run engines sequentially for stability")
    if profile.is_vps:
        tips.append("VPS detected: use SETI for search (avoids heavy Grok API calls)")
        tips.append("VPS: schedule intensive scans during off-peak hours")
    if profile.os_name == "darwin":
        tips.append("macOS: excellent for local development, all tools available")
    if profile.os_name == "linux" and not profile.is_vps:
        tips.append("Linux workstation: max performance, enable all parallel engines")
    if profile.cpu_cores >= 8 and profile.ram_gb >= 16:
        tips.append("Powerful machine: enable max_parallel strategy for fastest cycles")

    tips.append(
        f"Recommended: {profile.recommended_parallelism} parallel workers ({profile.recommended_strategy})"
    )

    return tips
