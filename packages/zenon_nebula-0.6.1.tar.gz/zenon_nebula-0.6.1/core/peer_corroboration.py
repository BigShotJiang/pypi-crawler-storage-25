# SPDX-License-Identifier: MIT
"""
Peer Corroboration — Multi-source evidence strengthening.

When multiple independent sources (local engines, peer instances) find
similar issues, the combined confidence should be HIGHER than any single
source. This is the core value proposition of decentralized intelligence.

Algorithm:
  1. Group findings by semantic similarity (fuzzy text matching)
  2. For each cluster of similar findings:
     - Count independent sources (different engines/peers)
     - Apply Bayesian update: P(real) increases with each independent confirmation
     - Create a corroboration record linking them
  3. Feed corroboration data to Collision Engine and War Room

The key insight: if Alice's scanner and Bob's scanner independently find
the same Portal reentrancy risk, that's MUCH stronger evidence than either
alone — because it's unlikely two independent analyses would hallucinate
the same false positive.
"""

import json
import logging
import sqlite3
from difflib import SequenceMatcher

from core.persistence import connect

logger = logging.getLogger(__name__)

# Minimum similarity ratio to consider two findings as "about the same thing"
# 0.4 catches findings about the same issue described differently
SIMILARITY_THRESHOLD = 0.4

# Maximum findings to compare per run (O(n^2) so cap it)
MAX_FINDINGS_TO_COMPARE = 500


def _similarity(a: str, b: str) -> float:
    """Similarity score combining sequence matching and keyword overlap."""
    if not a or not b:
        return 0.0

    # Extract key terms (skip WHAT/SO WHAT/NOW WHAT boilerplate)
    def extract_key(text):
        """Extract the key content from a finding, stripping boilerplate."""
        what_end = text.find("SO WHAT:")
        if what_end > 0:
            return text[:what_end].replace("WHAT:", "").strip().lower()
        return text[:200].lower()

    key_a = extract_key(a)
    key_b = extract_key(b)

    # Method 1: Sequence similarity
    seq_sim = SequenceMatcher(None, key_a, key_b).ratio()

    # Method 2: Keyword overlap (Jaccard on significant words)
    # Strip folder-specific terms that differ between installations
    stop_words = {
        "the",
        "a",
        "an",
        "is",
        "are",
        "was",
        "in",
        "of",
        "to",
        "for",
        "and",
        "or",
        "that",
        "this",
        "with",
        "has",
        "have",
        "not",
        "from",
        "found",
        "detected",
        "missing",
        "could",
        "should",
        "would",
        "can",
    }
    words_a = {w for w in key_a.split() if len(w) > 2 and w not in stop_words}
    words_b = {w for w in key_b.split() if len(w) > 2 and w not in stop_words}

    if words_a and words_b:
        intersection = words_a & words_b
        union = words_a | words_b
        keyword_sim = len(intersection) / len(union) if union else 0.0
    else:
        keyword_sim = 0.0

    # Take the higher of the two methods
    return max(seq_sim, keyword_sim)


def _bayesian_combine(confidences: list[float]) -> float:
    """Combine multiple independent confidence estimates using Bayesian update.

    If two independent sources both say P(real) = 0.8, the combined
    probability is higher than 0.8 because it's unlikely both are wrong.

    Formula: P(real | multiple sources) using odds form:
      odds_combined = product(odds_i)
      where odds_i = P_i / (1 - P_i)
    """
    if not confidences:
        return 0.0
    if len(confidences) == 1:
        return confidences[0]

    # Clamp to avoid division by zero
    clamped = [max(0.01, min(0.99, c)) for c in confidences]

    # Convert to odds, multiply, convert back
    combined_odds = 1.0
    for c in clamped:
        combined_odds *= c / (1.0 - c)

    combined = combined_odds / (1.0 + combined_odds)
    return min(combined, 0.99)  # cap at 99%


# ---------------------------------------------------------------------------
# v0.4.0 Phase C — content-hash merge + multi-source diversity bonus
# ---------------------------------------------------------------------------
#
# Pre-v0.4.0 corroboration merged findings by TEXT SIMILARITY across
# engines, which meant two peers publishing the same finding under
# different source_repos still got counted as "similar but separate"
# and the SimilarityMatcher had to decide via fuzzy text matching.
#
# v0.4.0 adds a canonical merge path: findings with matching
# content_hash (from v0.3.3 Phase A) are automatically merged into
# the same corroboration cluster regardless of text similarity. The
# text-similarity path is kept as a fallback for legacy rows without
# content_hash AND for edge cases where two engines describe the
# same issue in different prose.
#
# The diversity bonus is the anti-funnel payoff: a cluster with
# supporting evidence from N distinct source_repos (each with
# dynamic trust >= 0.5) gets a corroboration bonus proportional to N.
# Five mid-trust peers outweigh one maximum-trust peer — which is
# the whole point of the content-based trust rewrite.

# Minimum source trust for diversity bonus participation. Unknown
# repos (trust = 0.3 default) don't contribute to the bonus because
# the bonus rewards INDEPENDENT AUDITED SOURCES, not just volume.
_DIVERSITY_MIN_TRUST = 0.5

# Bonus magnitude: each additional trusted source contributes this
# much to the combined confidence, capped at MAX_DIVERSITY_BONUS.
_DIVERSITY_BONUS_PER_SOURCE = 0.04
_MAX_DIVERSITY_BONUS = 0.12


def _compute_diversity_bonus(source_repos: set[str], db_path: str) -> float:
    """Return a bonus based on the number of distinct trusted source_repos.

    Reads the dynamic trust of each source_repo and counts the ones
    above the diversity threshold. The first trusted source is
    baseline (no bonus), each additional one adds _DIVERSITY_BONUS_PER_SOURCE,
    capped at _MAX_DIVERSITY_BONUS.

    Trust is read from core.trust.compute_dynamic_trust which in turn
    reads repo_trust_history — so the bonus is content-derived, not
    name-derived. A new pseudonymous high-quality repo contributes
    to the bonus identically to developer-commons.
    """
    if not source_repos:
        return 0.0
    try:
        from core.trust import compute_dynamic_trust
    except Exception:
        return 0.0

    trusted_sources = 0
    for repo in source_repos:
        if not repo:
            continue
        try:
            if compute_dynamic_trust(repo, db_path=db_path) >= _DIVERSITY_MIN_TRUST:
                trusted_sources += 1
        except Exception:
            continue

    if trusted_sources <= 1:
        return 0.0

    bonus = (trusted_sources - 1) * _DIVERSITY_BONUS_PER_SOURCE
    return min(bonus, _MAX_DIVERSITY_BONUS)


def find_corroborations(db_path: str, domain: str = "") -> list[dict]:
    """Find groups of similar findings from independent sources.

    v0.4.0 merge strategy (layered):
    1. Group by matching ``content_hash`` first — these are the
       canonical, load-bearing corroborations. Two peers finding
       the same bug in the same file at the same line collapse
       into one cluster.
    2. For rows without ``content_hash`` (legacy pre-v0.3.3 rows
       or rows from peers still on older versions), fall back to
       text-similarity grouping against the legacy
       `_similarity()` path.
    3. Build the cluster's combined confidence via Bayesian update
       over the individual confidences, then apply the
       multi-source diversity bonus.

    Returns list of corroboration records:
    {
        "finding_ids": [1, 5, 23],
        "sources": [engine names, legacy attribute],
        "source_repos": [canonical repo identities for diversity],
        "individual_confidences": [0.85, 0.90, 0.75],
        "combined_confidence": 0.97,
        "diversity_bonus": 0.08,
        "representative_finding": "...",
        "source_count": 3,
    }
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row

    try:
        # v0.5.4 (task #48 Phase H) — filter out findings from
        # quarantined instances before corroboration even considers
        # them. A bad peer running modified code can still produce
        # evidence rows via transport import, but their
        # integrity_status will be 'quarantined' and peer-
        # corroboration drops them here. Findings with NULL
        # integrity_status (pre-v0.5.4 rows or findings from peers
        # still on older versions) are kept for backward compat.
        query = """SELECT id, engine, finding, confidence, domain,
                          source_repo, content_hash, integrity_status
                   FROM evidence
                   WHERE confidence > 0
                     AND (integrity_status IS NULL
                          OR integrity_status != 'quarantined')
                   ORDER BY timestamp DESC
                   LIMIT ?"""
        params = [MAX_FINDINGS_TO_COMPARE]

        if domain:
            query = """SELECT id, engine, finding, confidence, domain,
                              source_repo, content_hash, integrity_status
                       FROM evidence
                       WHERE confidence > 0 AND domain = ?
                         AND (integrity_status IS NULL
                              OR integrity_status != 'quarantined')
                       ORDER BY timestamp DESC
                       LIMIT ?"""
            params = [domain, MAX_FINDINGS_TO_COMPARE]

        rows = conn.execute(query, params).fetchall()
    finally:
        conn.close()

    if len(rows) < 2:
        return []

    # Stage 1: group by content_hash (v0.4.0 canonical path)
    clusters: list[list[dict]] = []
    clustered: set = set()
    by_hash: dict[str, list[dict]] = {}

    for row in rows:
        row_dict = dict(row)
        h = row_dict.get("content_hash")
        if h:
            by_hash.setdefault(h, []).append(row_dict)

    for _hash, bucket in by_hash.items():
        # Only cluster when 2+ distinct (engine, source_repo) combinations
        # agree on the same content_hash. A single engine producing the
        # same content_hash multiple times isn't corroboration.
        distinct_sources = {(r["engine"], r.get("source_repo") or "") for r in bucket}
        if len(distinct_sources) >= 2:
            clusters.append(bucket)
            for r in bucket:
                clustered.add(r["id"])

    # Stage 2: text-similarity fallback for rows without content_hash
    # (legacy pre-v0.3.3 rows or rows from older peers). This is the
    # original matching logic, unchanged — v0.4.0 doesn't remove it
    # because removing it would break corroboration for old rows
    # during the migration window.
    for i, row_a in enumerate(rows):
        if row_a["id"] in clustered:
            continue
        if row_a["content_hash"]:
            continue

        cluster = [dict(row_a)]
        clustered.add(row_a["id"])

        for j, row_b in enumerate(rows):
            if i == j or row_b["id"] in clustered:
                continue
            if row_b["content_hash"]:
                continue
            if row_a["engine"] == row_b["engine"]:
                continue

            sim = _similarity(row_a["finding"] or "", row_b["finding"] or "")
            if sim >= SIMILARITY_THRESHOLD:
                cluster.append(dict(row_b))
                clustered.add(row_b["id"])

        if len(cluster) >= 2:
            clusters.append(cluster)

    # Build corroboration records
    corroborations = []
    for cluster in clusters:
        sources = list({r["engine"] for r in cluster})
        source_repos = {r.get("source_repo") or "" for r in cluster}
        source_repos.discard("")

        # v0.5.4 — cap confidence at 0.5 for findings from instances
        # with integrity_status=warning. Drops go through the
        # query-level WHERE, but warnings still flow in; we just
        # don't trust them at full weight.
        confidences: list[float] = []
        for r in cluster:
            c = r["confidence"]
            istatus = r.get("integrity_status")
            if istatus == "warning":
                c = min(c, 0.5)
            confidences.append(c)
        combined = _bayesian_combine(confidences)

        # v0.4.0 diversity bonus: multi-source trust-weighted bonus
        diversity_bonus = _compute_diversity_bonus(source_repos, db_path)
        combined_with_bonus = min(0.99, combined + diversity_bonus)

        corroborations.append(
            {
                "finding_ids": [r["id"] for r in cluster],
                "sources": sources,
                "source_repos": sorted(source_repos),
                "individual_confidences": confidences,
                "combined_confidence": round(combined_with_bonus, 4),
                "diversity_bonus": round(diversity_bonus, 4),
                "representative_finding": cluster[0]["finding"][:200],
                "source_count": len(sources),
                "domain": cluster[0]["domain"],
            }
        )

    # Sort by source count (most corroborated first)
    corroborations.sort(key=lambda c: (-c["source_count"], -c["combined_confidence"]))

    return corroborations


def apply_corroborations(db_path: str) -> int:
    """Find corroborations and update finding confidences + related_findings.

    For each corroboration cluster:
    - Update all findings in the cluster to the combined confidence
    - Link them via related_findings
    - Log the corroboration

    Returns count of findings updated.
    """
    corroborations = find_corroborations(db_path)
    if not corroborations:
        return 0

    conn = connect(db_path)
    updated = 0

    try:
        for corr in corroborations:
            ids = corr["finding_ids"]
            combined = corr["combined_confidence"]
            related = json.dumps(ids)

            for fid in ids:
                # Only boost confidence (never lower it)
                conn.execute(
                    """UPDATE evidence
                       SET confidence = MAX(confidence, ?),
                           related_findings = ?
                       WHERE id = ?""",
                    (combined, related, fid),
                )
                updated += 1

        conn.commit()
    finally:
        conn.close()

    if updated:
        logger.info(
            "Corroboration: %d clusters, %d findings updated (max combined conf: %.2f)",
            len(corroborations),
            updated,
            max(c["combined_confidence"] for c in corroborations),
        )

    return updated
