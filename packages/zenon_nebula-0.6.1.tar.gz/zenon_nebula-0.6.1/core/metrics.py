# SPDX-License-Identifier: MIT
"""Prometheus-compatible metrics exporter (stdlib only).

Nebula emits operational metrics in the Prometheus text exposition
format without taking a runtime dependency on the `prometheus_client`
package. Everything in this module is pure Python stdlib and is safe
to import before any third-party dependency has been resolved.

The module supports three metric types:

* **Counter** — monotonically increasing scalar (use ``increment``).
* **Gauge** — arbitrary scalar that may go up and down (use ``gauge``).
* **Histogram (summary-like)** — observations aggregated into count,
  sum, and min/max buckets (use ``observe``).

Labels are supported on all three types. Every metric identity is the
tuple ``(name, sorted(label_items))`` so the same name with different
label sets produces distinct series.

Rendering :func:`render` returns a single ``str`` in the Prometheus
text format version ``0.0.4``. The HTTP Content-Type must be set to::

    text/plain; version=0.0.4

Thread safety
-------------
All mutating operations take a single module-level lock. This keeps
the implementation simple and fast enough for Nebula's scale (hundreds
of unique series, low-rate updates). If contention becomes a problem,
swap to per-metric locks without changing the public API.

Example
-------
>>> from core import metrics
>>> metrics.increment("nebula_findings_total", {"domain": "security"})
>>> metrics.gauge("nebula_evidence_height", 12345)
>>> metrics.observe("nebula_cycle_duration_seconds", 4.2)
>>> text = metrics.render()
>>> print(text)

The exporter is wired into the RPC server in
:mod:`core.nebula_rpc` so operators can scrape metrics via
``GET /metrics``.
"""

from __future__ import annotations

import math
import threading
from typing import Any

__all__ = [
    "describe",
    "gauge",
    "increment",
    "observe",
    "render",
    "reset",
]

# --------------------------------------------------------------------------
# Internal state
# --------------------------------------------------------------------------

_LOCK = threading.Lock()

# {(name, labels_tuple): value}
_counters: dict[tuple[str, tuple[tuple[str, str], ...]], float] = {}
_gauges: dict[tuple[str, tuple[tuple[str, str], ...]], float] = {}

# Histograms store aggregated stats instead of full buckets because we
# don't know a priori which buckets operators care about. A real
# histogram exporter is a future enhancement; this gives us summary-
# compatible output today.
# {(name, labels_tuple): {count, sum, min, max}}
_histograms: dict[
    tuple[str, tuple[tuple[str, str], ...]],
    dict[str, float],
] = {}

# {name: help_text} — optional per-metric description.
_help: dict[str, str] = {}
# {name: type} — "counter", "gauge", or "summary".
_type: dict[str, str] = {}


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------


def _normalize_labels(labels: dict[str, Any] | None) -> tuple[tuple[str, str], ...]:
    """Turn a label dict into a canonical, sortable, hashable tuple.

    Label values are coerced to str. None is treated as empty labels.
    """
    if not labels:
        return ()
    items = []
    for key, value in labels.items():
        if not isinstance(key, str):
            raise TypeError(f"metric label key must be str, got {type(key).__name__}")
        if value is None:
            value = ""
        items.append((key, str(value)))
    items.sort()
    return tuple(items)


def _validate_name(name: str) -> None:
    """Prometheus metric names must match [a-zA-Z_:][a-zA-Z0-9_:]*."""
    if not name:
        raise ValueError("metric name must be non-empty")
    first = name[0]
    if not (first.isalpha() or first in "_:"):
        raise ValueError(f"invalid metric name: {name!r}")
    for c in name[1:]:
        if not (c.isalnum() or c in "_:"):
            raise ValueError(f"invalid metric name: {name!r}")


def _escape_label_value(value: str) -> str:
    """Escape label values for the text exposition format."""
    return value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


def _format_labels(labels: tuple[tuple[str, str], ...]) -> str:
    if not labels:
        return ""
    parts = [f'{k}="{_escape_label_value(v)}"' for k, v in labels]
    return "{" + ",".join(parts) + "}"


def _format_value(value: float) -> str:
    """Render a float the way Prometheus expects."""
    if math.isnan(value):
        return "NaN"
    if math.isinf(value):
        return "+Inf" if value > 0 else "-Inf"
    if value == int(value) and abs(value) < 1e16:
        return str(int(value))
    return repr(value)


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------


def describe(name: str, help_text: str, metric_type: str) -> None:
    """Attach a HELP and TYPE line to a metric name.

    This is optional — metrics work without being described — but the
    output is friendlier to Prometheus scrapers when present. Calling
    ``describe`` multiple times for the same name overwrites the
    previous values.
    """
    _validate_name(name)
    if metric_type not in ("counter", "gauge", "summary"):
        raise ValueError(f"metric_type must be counter/gauge/summary, got {metric_type!r}")
    with _LOCK:
        _help[name] = help_text
        _type[name] = metric_type


def increment(
    name: str,
    labels: dict[str, Any] | None = None,
    value: float = 1.0,
) -> None:
    """Add ``value`` to a counter (default 1.0). Negative values are refused."""
    _validate_name(name)
    if value < 0:
        raise ValueError("counters cannot be decremented")
    key = (name, _normalize_labels(labels))
    with _LOCK:
        _counters[key] = _counters.get(key, 0.0) + value
        _type.setdefault(name, "counter")


def gauge(
    name: str,
    value: float,
    labels: dict[str, Any] | None = None,
) -> None:
    """Set the current value of a gauge."""
    _validate_name(name)
    key = (name, _normalize_labels(labels))
    with _LOCK:
        _gauges[key] = float(value)
        _type.setdefault(name, "gauge")


def observe(
    name: str,
    value: float,
    labels: dict[str, Any] | None = None,
) -> None:
    """Record a single observation for a summary-style metric."""
    _validate_name(name)
    v = float(value)
    key = (name, _normalize_labels(labels))
    with _LOCK:
        stats = _histograms.get(key)
        if stats is None:
            _histograms[key] = {
                "count": 1.0,
                "sum": v,
                "min": v,
                "max": v,
            }
        else:
            stats["count"] += 1.0
            stats["sum"] += v
            if v < stats["min"]:
                stats["min"] = v
            if v > stats["max"]:
                stats["max"] = v
        _type.setdefault(name, "summary")


def reset() -> None:
    """Clear every metric. Intended for tests."""
    with _LOCK:
        _counters.clear()
        _gauges.clear()
        _histograms.clear()
        _help.clear()
        _type.clear()


def render() -> str:
    """Render all registered metrics in Prometheus text format 0.0.4.

    Series are sorted by name + label tuple for deterministic output.
    """
    with _LOCK:
        # Group series by metric name so HELP/TYPE lines only appear once.
        names: set[str] = set()
        names.update(k[0] for k in _counters)
        names.update(k[0] for k in _gauges)
        names.update(k[0] for k in _histograms)
        lines: list[str] = []
        for name in sorted(names):
            help_text = _help.get(name)
            metric_type = _type.get(name, "untyped")
            if help_text:
                lines.append(f"# HELP {name} {help_text}")
            lines.append(f"# TYPE {name} {metric_type}")

            counter_items = sorted((k[1], v) for k, v in _counters.items() if k[0] == name)
            for label_key, value in counter_items:
                lines.append(f"{name}{_format_labels(label_key)} {_format_value(value)}")

            gauge_items = sorted((k[1], v) for k, v in _gauges.items() if k[0] == name)
            for label_key, value in gauge_items:
                lines.append(f"{name}{_format_labels(label_key)} {_format_value(value)}")

            histogram_items = sorted((k[1], v) for k, v in _histograms.items() if k[0] == name)
            for label_key, stats in histogram_items:
                label_str = _format_labels(label_key)
                lines.append(f"{name}_count{label_str} {_format_value(stats['count'])}")
                lines.append(f"{name}_sum{label_str} {_format_value(stats['sum'])}")
                lines.append(f"{name}_min{label_str} {_format_value(stats['min'])}")
                lines.append(f"{name}_max{label_str} {_format_value(stats['max'])}")

        # Prometheus text exposition requires a trailing newline.
        lines.append("")
        return "\n".join(lines)


CONTENT_TYPE = "text/plain; version=0.0.4; charset=utf-8"
