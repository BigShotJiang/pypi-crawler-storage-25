# SPDX-License-Identifier: MIT
"""
SelfExtensionLoop -- Autonomous curiosity follow-through.

When an engine finds something interesting, this module automatically
spawns deeper investigation in that direction. The core cycle:

  1. Scan for unvalidated/low-confidence findings
  2. Generate follow-up questions from them
  3. Execute questions via registered handlers
  4. Validate results
  5. If new SIGNIFICANT findings -> loop back to step 1
  6. Check termination conditions (budget, iterations, saturation)

Generalized from marketing's self_extension.py. Domain-agnostic: callers
register question generators and execution handlers per domain.

Reads:  evidence table, hypotheses table
Writes: evidence table, cost_tracking table, feedback_bus
"""

import logging
import sqlite3
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Significance threshold -- findings at or above this confidence trigger re-looping
SIGNIFICANCE_THRESHOLD = 0.7


# ---------------------------------------------------------------------------
# Budget tracker
# ---------------------------------------------------------------------------


class APIBudget:
    """Tracks cumulative API spend against a USD limit.

    Persists spend to the cost_tracking table so it survives restarts.
    """

    def __init__(
        self,
        limit_usd: float = 5.0,
        db_path: str = DEFAULT_DB,
        module_name: str = "self_extension",
    ) -> None:
        self.limit_usd = limit_usd
        self.db_path = db_path
        self.module_name = module_name
        self._spent: float = 0.0
        self._load_from_db()

    def _load_from_db(self) -> None:
        """Load cumulative spend from the database."""
        conn = connect(self.db_path)
        try:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS cost_tracking (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    module TEXT NOT NULL,
                    amount_usd REAL NOT NULL,
                    description TEXT,
                    timestamp TEXT DEFAULT (datetime('now'))
                )"""
            )
            conn.commit()

            row = conn.execute(
                "SELECT COALESCE(SUM(amount_usd), 0) FROM cost_tracking WHERE module = ?",
                (self.module_name,),
            ).fetchone()
            self._spent = row[0] if row else 0.0
        finally:
            conn.close()

    def spend(self, amount: float, description: str = "") -> None:
        """Record a spend event."""
        self._spent += amount
        conn = connect(self.db_path)
        try:
            conn.execute(
                "INSERT INTO cost_tracking (module, amount_usd, description) VALUES (?, ?, ?)",
                (self.module_name, amount, description),
            )
            conn.commit()
        finally:
            conn.close()
        logger.debug(
            "Budget: spent $%.4f (total $%.4f / $%.2f)",
            amount,
            self._spent,
            self.limit_usd,
        )

    def is_exhausted(self) -> bool:
        """True if the budget limit has been reached."""
        return self._spent >= self.limit_usd

    def remaining(self) -> float:
        """Remaining budget in USD."""
        return max(0.0, self.limit_usd - self._spent)

    @property
    def spent(self) -> float:
        """Total amount spent so far in USD."""
        return self._spent


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------


@dataclass
class SelfExtensionResult:
    """Summary of a self-extension run."""

    iterations_run: int = 0
    findings_generated: int = 0
    hypotheses_updated: int = 0
    budget_spent: float = 0.0
    termination_reason: str = ""
    significant_findings: list = field(default_factory=list)


# ---------------------------------------------------------------------------
# Question and execution handler types
# ---------------------------------------------------------------------------

# A question generator takes a list of findings (dicts) and domain name,
# returns a list of question dicts.
QuestionGenerator = Callable[[list[dict], str], list[dict]]

# An execution handler takes a question dict and domain name,
# returns an optional finding dict (or None if nothing found).
ExecutionHandler = Callable[[dict, str], dict | None]

# A validation handler takes a list of finding dicts,
# returns a list of validated finding dicts with "validation_status" key.
ValidationHandler = Callable[[list[dict]], list[dict]]


# ---------------------------------------------------------------------------
# Default validator
# ---------------------------------------------------------------------------


def _default_validator(findings: list[dict]) -> list[dict]:
    """Simple validator that checks confidence thresholds."""
    validated = []
    for finding in findings:
        confidence = finding.get("confidence", 0.5)
        if confidence >= 0.8:
            status = "validated_novel"
        elif confidence >= 0.6:
            status = "validated"
        elif confidence < 0.3:
            status = "low_confidence"
        else:
            status = "unvalidated"

        validated.append(
            {
                **finding,
                "validation_status": status,
                "significant": confidence >= SIGNIFICANCE_THRESHOLD,
            }
        )
    return validated


# ---------------------------------------------------------------------------
# SelfExtensionLoop
# ---------------------------------------------------------------------------


class SelfExtensionLoop:
    """Autonomous loop that discovers, executes, validates, and re-discovers.

    Register domain-specific handlers before calling :meth:`run`::

        loop = SelfExtensionLoop(max_iterations=5, max_api_budget_usd=2.0)
        loop.register_question_generator(my_question_gen)
        loop.register_execution_handler(my_executor)
        result = loop.run(domain="intelligence")
    """

    def __init__(
        self,
        db_path: str = DEFAULT_DB,
        max_iterations: int = 10,
        max_api_budget_usd: float = 5.0,
    ) -> None:
        self.db_path = db_path
        self.max_iterations = max_iterations
        self.budget = APIBudget(
            limit_usd=max_api_budget_usd,
            db_path=db_path,
        )
        self._question_gen: QuestionGenerator | None = None
        self._executor: ExecutionHandler | None = None
        self._validator: ValidationHandler = _default_validator
        self._recent_findings_counts: list[int] = []

    def register_question_generator(self, gen: QuestionGenerator) -> None:
        """Register a function that generates follow-up questions from findings."""
        self._question_gen = gen

    def register_execution_handler(self, handler: ExecutionHandler) -> None:
        """Register a function that executes a question and returns a finding."""
        self._executor = handler

    def register_validator(self, validator: ValidationHandler) -> None:
        """Register a custom validation handler. Replaces the default."""
        self._validator = validator

    def run(self, domain: str = "system") -> SelfExtensionResult:
        """Execute the self-extension loop until termination.

        Args:
            domain: Domain to scope evidence scanning and question generation.

        Returns:
            SelfExtensionResult with run statistics.
        """
        result = SelfExtensionResult()
        initial_budget = self.budget.spent

        logger.info(
            "Self-extension loop starting: domain=%s max_iter=%d budget=$%.2f",
            domain,
            self.max_iterations,
            self.budget.remaining(),
        )

        for iteration in range(1, self.max_iterations + 1):
            logger.info("=== Iteration %d/%d ===", iteration, self.max_iterations)

            if self._check_termination(iteration):
                result.termination_reason = self._get_termination_reason(iteration)
                logger.info("Terminating: %s", result.termination_reason)
                break

            iteration_findings = 0

            # Step 1: Scan for unvalidated findings
            unvalidated = self._scan_unvalidated(domain)
            logger.info(
                "Domain %s: %d unvalidated findings to process",
                domain,
                len(unvalidated),
            )

            if not unvalidated and iteration > 1:
                self._recent_findings_counts.append(0)
                continue

            # Step 2: Generate follow-up questions
            questions: list[dict] = []
            if self._question_gen:
                try:
                    questions = self._question_gen(unvalidated, domain)
                except Exception as exc:
                    logger.error("Question generation failed: %s", exc)

            # Step 3+4: Execute questions
            if self._executor:
                iteration_findings += self._execute_questions(
                    questions[:5],
                    domain,
                    iteration,
                    result,
                )

            # Step 5: Validate recent findings
            recent = self._get_recent_findings(domain, limit=max(iteration_findings, 5))
            if recent:
                validated = self._validator(recent)
                result.hypotheses_updated += sum(
                    1 for f in validated if f.get("validation_status", "").startswith("validated")
                )

            self._recent_findings_counts.append(iteration_findings)
            result.iterations_run = iteration

        # Final accounting
        result.budget_spent = round(self.budget.spent - initial_budget, 4)

        if not result.termination_reason:
            result.termination_reason = "max_iterations_reached"

        logger.info(
            "Self-extension complete: %d iterations, %d findings, $%.4f spent -- %s",
            result.iterations_run,
            result.findings_generated,
            result.budget_spent,
            result.termination_reason,
        )
        return result

    def _execute_questions(
        self,
        questions: list[dict],
        domain: str,
        iteration: int,
        result: SelfExtensionResult,
    ) -> int:
        """Execute a batch of questions and record significant findings."""
        count = 0
        for q in questions:
            if self.budget.is_exhausted():
                break
            try:
                finding = self._executor(q, domain)
            except Exception as exc:
                logger.error("Execution failed for question: %s", exc)
                continue
            if not finding:
                continue
            count += 1
            result.findings_generated += 1
            confidence = finding.get("confidence", 0.3)
            if confidence >= SIGNIFICANCE_THRESHOLD:
                result.significant_findings.append(
                    {
                        "question": q.get("question", ""),
                        "confidence": confidence,
                        "iteration": iteration,
                    }
                )
        return count

    # ------------------------------------------------------------------
    # Termination logic
    # ------------------------------------------------------------------

    def _check_termination(self, iteration: int) -> bool:
        """Check if the loop should terminate."""
        if self.budget.is_exhausted():
            return True
        if iteration > self.max_iterations:
            return True
        # No new findings in last 2 iterations
        if len(self._recent_findings_counts) >= 2:
            last_two = self._recent_findings_counts[-2:]
            if all(c == 0 for c in last_two):
                return True
        # All hypotheses converged
        return bool(self._all_hypotheses_converged())

    def _get_termination_reason(self, iteration: int) -> str:
        """Return a human-readable termination reason."""
        if self.budget.is_exhausted():
            return f"budget_exhausted (${self.budget.spent:.2f}/${self.budget.limit_usd:.2f})"
        if iteration > self.max_iterations:
            return f"max_iterations ({self.max_iterations})"
        if len(self._recent_findings_counts) >= 2:
            if all(c == 0 for c in self._recent_findings_counts[-2:]):
                return "no_new_findings (2 consecutive dry iterations)"
        if self._all_hypotheses_converged():
            return "confidence_saturation (all hypotheses >90% or <10%)"
        return "unknown"

    def _all_hypotheses_converged(self) -> bool:
        """Check if all hypotheses have confidence >0.9 or <0.1."""
        conn = connect(self.db_path)
        try:
            try:
                rows = conn.execute(
                    "SELECT confidence FROM hypotheses WHERE status = 'active'"
                ).fetchall()
            except sqlite3.OperationalError:
                return False
            if not rows:
                return False
            return all((r[0] is not None and (r[0] > 0.9 or r[0] < 0.1)) for r in rows)
        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Scanning helpers
    # ------------------------------------------------------------------

    def _scan_unvalidated(self, domain: str) -> list[dict]:
        """Query evidence table for unvalidated findings."""
        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            try:
                rows = conn.execute(
                    """SELECT id, engine, evidence_type, finding,
                              confidence, supports_hypothesis, timestamp
                       FROM evidence
                       WHERE published = 0
                       ORDER BY ABS(confidence - 0.5) ASC, timestamp DESC
                       LIMIT 20""",
                ).fetchall()
                return [dict(r) for r in rows]
            except sqlite3.OperationalError:
                return []
        finally:
            conn.close()

    def _get_recent_findings(self, domain: str, limit: int = 10) -> list[dict]:
        """Get the most recent findings for validation."""
        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            try:
                rows = conn.execute(
                    "SELECT * FROM evidence ORDER BY timestamp DESC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            except sqlite3.OperationalError:
                return []
        finally:
            conn.close()
