# SPDX-License-Identifier: MIT
"""Application-level LLM prompt cache (Phase 15).

Nebula runs continuous cycles; many call sites send the same system
prompt repeatedly (war_room's strategist preamble, director's scoring
template, finding_verifier's provenance checker, etc.). This module
caches completions by hashing the full request tuple so repeat calls
don't hit the xAI API twice.

The cache is:

- **Pure stdlib** — hashlib + json + sqlite3 via core.persistence.
- **TTL-bounded** — default 24 hours; caller can override per-call.
- **Deterministic-input only** — the cache key includes ``temperature``,
  so non-deterministic (``temperature>0``) calls with the same prompt
  still hit cache if the caller opts in. Callers that need fresh
  outputs pass ``cache_ttl_seconds=0`` to skip the cache.
- **Respects budget semantics** — a cache hit is recorded as a
  zero-cost ``call_llm`` result with ``cached=True`` in the return dict.
- **Opt-out per call** — passing ``cache_ttl_seconds=0`` bypasses the
  cache entirely. The default is on so the typical Nebula cycle
  amortizes the cost of stable system prompts automatically.

The cache table is declared via module-level ``SCHEMA_SQL`` and picked
up by ``core.schema_registry`` at boot. Cache reads use a short-lived
sqlite3 connection via ``core.persistence._get_connection`` (never a
raw ``sqlite3.connect`` — the core boundary rules forbid that outside
the persistence package).
"""

from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

DEFAULT_TTL_SECONDS = 86_400  # 24 hours


# Schema (picked up by core.schema_registry)
SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS llm_cache (
    key TEXT PRIMARY KEY,
    model TEXT NOT NULL,
    prompt_preview TEXT,
    response_text TEXT NOT NULL,
    input_tokens INTEGER NOT NULL DEFAULT 0,
    output_tokens INTEGER NOT NULL DEFAULT 0,
    cost_usd REAL NOT NULL DEFAULT 0.0,
    hit_count INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    last_hit_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_llm_cache_created ON llm_cache(created_at);
"""


def make_cache_key(
    *,
    prompt: str,
    system: str,
    model: str,
    max_tokens: int,
    temperature: float,
    json_output: bool,
) -> str:
    """Return a stable cache key for a complete LLM call request.

    The key covers every field that materially affects the model's
    output. Adding a new field to ``call_llm`` without adding it
    here will produce wrong cache hits — keep this in sync.
    """
    payload = {
        "prompt": prompt,
        "system": system,
        "model": model,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "json_output": json_output,
    }
    blob = json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _resolve_db_path(db_path: str | None) -> str:
    """Return the effective db_path, honouring module-level DEFAULT_DB.

    Looking up ``DEFAULT_DB`` at call time (rather than binding it as
    a default argument) means tests can monkeypatch the module
    attribute to redirect the cache at a temporary database.
    """
    return db_path or DEFAULT_DB


def _get_conn(db_path: str | None) -> sqlite3.Connection:
    """Return a short-lived read/write connection via core.persistence."""
    from core.persistence.schema import _get_connection

    return _get_connection(_resolve_db_path(db_path))


def lookup(
    cache_key: str,
    *,
    db_path: str | None = None,
    ttl_seconds: int = DEFAULT_TTL_SECONDS,
) -> dict | None:
    """Return a cached response for ``cache_key`` if fresh, else None.

    A cache entry is "fresh" if its ``created_at`` is within
    ``ttl_seconds``. Cache hits bump the ``hit_count`` and
    ``last_hit_at`` columns atomically so we can track hit rates.
    """
    if ttl_seconds <= 0:
        return None
    try:
        conn = _get_conn(db_path)
    except Exception as exc:
        logger.debug("llm_cache: connection unavailable: %s", exc)
        return None

    try:
        row = conn.execute(
            "SELECT model, response_text, input_tokens, output_tokens, cost_usd,"
            " created_at FROM llm_cache WHERE key = ?",
            (cache_key,),
        ).fetchone()
        if row is None:
            return None

        created_at_str = row[5]
        try:
            created_at = datetime.fromisoformat(created_at_str.replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            return None
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=timezone.utc)
        age = (datetime.now(timezone.utc) - created_at).total_seconds()
        if age > ttl_seconds:
            return None

        # Bump hit counters best-effort; never let a counter failure
        # break the cache hit.
        try:
            conn.execute(
                "UPDATE llm_cache SET hit_count = hit_count + 1, last_hit_at = ? WHERE key = ?",
                (_now_iso(), cache_key),
            )
            conn.commit()
        except sqlite3.OperationalError as exc:
            logger.debug("llm_cache: hit counter update failed: %s", exc)

        return {
            "text": row[1],
            "cost_usd": 0.0,  # cache hit = no new API cost
            "input_tokens": row[2],
            "output_tokens": row[3],
            "model": row[0],
            "cached": True,
            "cached_cost_saved_usd": float(row[4] or 0.0),
        }
    finally:
        try:
            conn.close()
        except Exception as exc:
            logger.debug("llm_cache: connection close failed: %s", exc)


def store(
    cache_key: str,
    result: dict[str, Any],
    *,
    prompt_preview: str = "",
    db_path: str | None = None,
) -> None:
    """Write a completion to the cache. Never raises on failure.

    ``result`` is the same dict shape that ``call_llm`` returns:
    ``{"text", "cost_usd", "input_tokens", "output_tokens", "model"}``.
    """
    try:
        conn = _get_conn(db_path)
    except Exception as exc:
        logger.debug("llm_cache: store skipped (no connection): %s", exc)
        return

    try:
        now = _now_iso()
        conn.execute(
            "INSERT OR REPLACE INTO llm_cache"
            " (key, model, prompt_preview, response_text, input_tokens,"
            "  output_tokens, cost_usd, hit_count, created_at, last_hit_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)",
            (
                cache_key,
                result.get("model", "unknown"),
                prompt_preview[:300],
                result.get("text", ""),
                int(result.get("input_tokens", 0)),
                int(result.get("output_tokens", 0)),
                float(result.get("cost_usd", 0.0)),
                now,
                now,
            ),
        )
        conn.commit()
    except sqlite3.OperationalError as exc:
        logger.debug("llm_cache: store insert failed: %s", exc)
    finally:
        try:
            conn.close()
        except Exception as exc:
            logger.debug("llm_cache: connection close failed: %s", exc)


def stats(db_path: str | None = None) -> dict:
    """Return aggregate hit-rate + savings stats for operator tooling."""
    try:
        conn = _get_conn(db_path)
    except Exception:
        return {"entries": 0, "total_hits": 0, "estimated_saved_usd": 0.0}

    try:
        row = conn.execute(
            "SELECT COUNT(*),"
            " COALESCE(SUM(hit_count), 0),"
            " COALESCE(SUM(cost_usd * (hit_count - 1)), 0.0)"
            " FROM llm_cache"
        ).fetchone()
        return {
            "entries": int(row[0] or 0),
            "total_hits": int(row[1] or 0),
            "estimated_saved_usd": round(float(row[2] or 0.0), 6),
        }
    except sqlite3.OperationalError as exc:
        logger.debug("llm_cache: stats query failed: %s", exc)
        return {"entries": 0, "total_hits": 0, "estimated_saved_usd": 0.0}
    finally:
        try:
            conn.close()
        except Exception as exc:
            logger.debug("llm_cache: connection close failed: %s", exc)


def purge(db_path: str | None = None, *, older_than_seconds: int | None = None) -> int:
    """Delete cache entries. Returns the number of rows removed.

    - ``older_than_seconds=None`` deletes every row (full flush).
    - Otherwise deletes only rows whose ``created_at`` is older than
      the given window.
    """
    try:
        conn = _get_conn(db_path)
    except Exception:
        return 0
    try:
        if older_than_seconds is None:
            cursor = conn.execute("DELETE FROM llm_cache")
        else:
            cutoff = datetime.now(timezone.utc).timestamp() - older_than_seconds
            cutoff_iso = datetime.fromtimestamp(cutoff, tz=timezone.utc).isoformat()
            cursor = conn.execute("DELETE FROM llm_cache WHERE created_at < ?", (cutoff_iso,))
        conn.commit()
        return cursor.rowcount or 0
    except sqlite3.OperationalError as exc:
        logger.debug("llm_cache: purge failed: %s", exc)
        return 0
    finally:
        try:
            conn.close()
        except Exception as exc:
            logger.debug("llm_cache: connection close failed: %s", exc)
