# SPDX-License-Identifier: MIT
"""Cooperative graceful-shutdown helpers.

Long-running Nebula processes (``scripts/autonomous.py`` and the RPC /
MCP servers) need a clean way to handle SIGINT and SIGTERM without
ripping the process down mid-write. This module offers a minimal
cooperative primitive:

1. Call :func:`install_signal_handlers` once at process start.
2. Inside your main loop, check :func:`is_shutting_down` after each
   iteration and break out when it returns ``True``.
3. Use :func:`wait_for_shutdown` to block until a signal arrives
   (or until the optional timeout expires).
4. Optionally register a callback via :func:`on_shutdown` that gets
   invoked inside the signal handler.

The implementation is stdlib-only. It keeps a module-level
``threading.Event`` that the signal handler sets, so any thread can
observe the shutdown state cheaply.

Example
-------
>>> from core import shutdown
>>> shutdown.install_signal_handlers()
>>> while not shutdown.is_shutting_down():
...     do_one_cycle()
>>> cleanup()
"""

from __future__ import annotations

import logging
import signal
import threading
from collections.abc import Callable

logger = logging.getLogger(__name__)

__all__ = [
    "install_signal_handlers",
    "is_shutting_down",
    "on_shutdown",
    "request_shutdown",
    "reset",
    "wait_for_shutdown",
]

# Module state. The Event is the source of truth; everything else is
# convenience.
_shutdown_event = threading.Event()
_installed_lock = threading.Lock()
_installed = False
_callbacks: list[Callable[[], None]] = []


def install_signal_handlers(
    signals: tuple[int, ...] = (signal.SIGINT, signal.SIGTERM),
) -> bool:
    """Install handlers for SIGINT / SIGTERM (and any extra signals).

    Returns ``True`` when handlers were installed fresh, ``False`` if
    they were already installed in this process. Safe to call from
    any thread and safe to call multiple times.

    Signal handling is a main-thread-only API on most platforms; this
    function silently degrades to a no-op when called from a non-main
    thread and returns ``False``.
    """
    global _installed
    with _installed_lock:
        if _installed:
            return False
        # Signal installation only works on the main thread on POSIX.
        if threading.current_thread() is not threading.main_thread():
            logger.debug("install_signal_handlers called off the main thread; skipping")
            return False
        for sig in signals:
            try:
                signal.signal(sig, _handle_signal)
            except (ValueError, OSError) as exc:
                # Windows or a sandboxed runtime. Log and carry on —
                # the Event can still be set manually via
                # request_shutdown().
                logger.debug("cannot install handler for %s: %s", sig, exc)
        _installed = True
        return True


def _handle_signal(signum: int, _frame) -> None:  # pragma: no cover - signal
    """Signal handler: flip the Event and fire any registered callbacks."""
    name = (
        signal.Signals(signum).name
        if signum in signal.Signals.__members__.values()
        else str(signum)
    )
    logger.info("shutdown signal received: %s", name)
    _shutdown_event.set()
    for cb in list(_callbacks):
        try:
            cb()
        except Exception as exc:
            logger.warning("shutdown callback raised: %s", exc)


def is_shutting_down() -> bool:
    """Return ``True`` once a shutdown signal has been received."""
    return _shutdown_event.is_set()


def request_shutdown() -> None:
    """Manually request shutdown (equivalent to catching a signal).

    Useful in tests and in graceful self-exit paths.
    """
    logger.info("shutdown requested programmatically")
    _shutdown_event.set()
    for cb in list(_callbacks):
        try:
            cb()
        except Exception as exc:
            logger.warning("shutdown callback raised: %s", exc)


def reset() -> None:
    """Clear the shutdown flag and the callback list.

    Intended for tests. Does NOT uninstall signal handlers (signals
    stay hooked for the lifetime of the process).
    """
    _shutdown_event.clear()
    _callbacks.clear()


def on_shutdown(callback: Callable[[], None]) -> Callable[[], None]:
    """Register a callback to run when shutdown is requested.

    Returns the callback unchanged so it can be used as a decorator::

        @on_shutdown
        def flush_buffers() -> None:
            ...

    Callbacks run in the signal handler's context; keep them fast
    and exception-free. Anything slow should live in the main loop's
    post-shutdown cleanup path.
    """
    if callback not in _callbacks:
        _callbacks.append(callback)
    return callback


def wait_for_shutdown(timeout: float | None = None) -> bool:
    """Block until shutdown is requested (or the optional timeout).

    Args:
        timeout: Maximum seconds to wait. ``None`` waits forever.

    Returns:
        ``True`` if shutdown was requested before the timeout elapsed,
        ``False`` if the timeout expired first.
    """
    return _shutdown_event.wait(timeout=timeout)
