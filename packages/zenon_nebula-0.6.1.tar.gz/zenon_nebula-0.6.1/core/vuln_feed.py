# SPDX-License-Identifier: MIT
"""
Vulnerability Feed -- Query public CVE/vulnerability databases.

Uses the OSV.dev API and Go vulnerability database to check dependencies
for known vulnerabilities. No API keys required.

Supports scanning go.mod and package.json files to check all dependencies
in a single pass.

Usage:
    from core.vuln_feed import check_osv, scan_go_mod, scan_package_json

    vulns = check_osv("golang.org/x/crypto", ecosystem="Go", version="0.17.0")
    go_results = scan_go_mod("/path/to/go.mod")
    npm_results = scan_package_json("/path/to/package.json")
"""

import json
import logging
import os
import re
import time
import urllib.error
import urllib.request

logger = logging.getLogger(__name__)

OSV_API_URL = "https://api.osv.dev/v1/query"
GO_VULN_DB = "https://vuln.go.dev"
REQUEST_TIMEOUT = 15

# Rate limiting: 1 req/sec to be polite
_RATE_LIMIT_SECONDS = 1.0
_last_request_time = 0.0


def _rate_limit() -> None:
    """Enforce minimum delay between vulnerability API requests."""
    global _last_request_time
    now = time.monotonic()
    elapsed = now - _last_request_time
    if elapsed < _RATE_LIMIT_SECONDS:
        time.sleep(_RATE_LIMIT_SECONDS - elapsed)
    _last_request_time = time.monotonic()


def _post_json(url: str, body: dict) -> dict | None:
    """Make an HTTP POST request with JSON body.

    Args:
        url:  Full URL to post to.
        body: Dict to serialize as JSON.

    Returns:
        Parsed JSON response, or None on error.
    """
    _rate_limit()
    data = json.dumps(body).encode("utf-8")
    # OPSEC: use the safe HTTP wrapper so OSV (and any other CVE
    # feed) can't fingerprint us as "Nebula/0.1" and link requests
    # across operators.
    from core.http import opsec_request, opsec_urlopen

    req = opsec_request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    try:
        with opsec_urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        logger.warning("HTTP %d from POST %s", exc.code, url)
        return None
    except (urllib.error.URLError, OSError, json.JSONDecodeError) as exc:
        logger.warning("POST to %s failed: %s", url, exc)
        return None


def _get_json(url: str) -> dict | list | None:
    """Make an HTTP GET request and return parsed JSON.

    Args:
        url: Full URL to fetch.

    Returns:
        Parsed JSON response, or None on error.
    """
    _rate_limit()
    from core.http import opsec_request, opsec_urlopen

    req = opsec_request(url, headers={"Accept": "application/json"})
    try:
        with opsec_urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        logger.warning("HTTP %d from %s", exc.code, url)
        return None
    except (urllib.error.URLError, OSError, json.JSONDecodeError) as exc:
        logger.warning("Request to %s failed: %s", url, exc)
        return None


def _format_vulns(osv_response: dict | None) -> list[dict]:
    """Extract vulnerability details from an OSV API response.

    Args:
        osv_response: Raw OSV API response dict.

    Returns:
        List of dicts with: id, summary, details (truncated), severity,
        affected_ranges, aliases, references.
    """
    if not osv_response:
        return []

    vulns = []
    for v in osv_response.get("vulns", []):
        # Extract severity from database_specific or severity field
        severity = "UNKNOWN"
        for sev in v.get("severity", []):
            if sev.get("type") == "CVSS_V3":
                score_str = sev.get("score", "")
                # CVSS vector string contains the score
                severity = score_str
                break
        if severity == "UNKNOWN":
            db_specific = v.get("database_specific", {})
            severity = db_specific.get("severity", "UNKNOWN")

        # Extract affected version ranges
        affected_ranges = []
        for affected in v.get("affected", []):
            for rng in affected.get("ranges", []):
                events = rng.get("events", [])
                range_info = {"type": rng.get("type", "")}
                for event in events:
                    if "introduced" in event:
                        range_info["introduced"] = event["introduced"]
                    if "fixed" in event:
                        range_info["fixed"] = event["fixed"]
                affected_ranges.append(range_info)

        details = v.get("details", "") or ""
        vulns.append(
            {
                "id": v.get("id", ""),
                "summary": v.get("summary", ""),
                "details": details[:500],
                "severity": severity,
                "affected_ranges": affected_ranges,
                "aliases": v.get("aliases", []),
                "references": [
                    {"type": ref.get("type", ""), "url": ref.get("url", "")}
                    for ref in v.get("references", [])[:5]
                ],
                "published": v.get("published", ""),
                "modified": v.get("modified", ""),
            }
        )

    return vulns


def check_osv(
    package: str,
    ecosystem: str = "Go",
    version: str = "",
) -> list[dict]:
    """Query OSV.dev for known vulnerabilities in a package.

    Args:
        package:   Package name (e.g. "golang.org/x/crypto").
        ecosystem: Package ecosystem ("Go", "npm", "PyPI", "crates.io", etc.).
        version:   Specific version to check. If empty, returns all known
                   vulnerabilities for the package.

    Returns:
        List of vulnerability dicts. Empty list if none found or on error.
    """
    body: dict = {
        "package": {
            "name": package,
            "ecosystem": ecosystem,
        },
    }
    if version:
        body["version"] = version

    result = _post_json(OSV_API_URL, body)
    return _format_vulns(result)


def check_go_vulns(module_path: str) -> list[dict]:
    """Query the Go vulnerability database for a specific module.

    Args:
        module_path: Go module path (e.g. "golang.org/x/crypto").

    Returns:
        List of vulnerability dicts. Uses OSV.dev with Go ecosystem.
    """
    return check_osv(module_path, ecosystem="Go")


def _parse_go_mod(go_mod_path: str) -> list[dict]:
    """Parse a go.mod file and extract dependencies.

    Args:
        go_mod_path: Absolute path to go.mod file.

    Returns:
        List of dicts with: module (path), version.
    """
    if not os.path.isfile(go_mod_path):
        logger.warning("go.mod not found at %s", go_mod_path)
        return []

    deps = []
    in_require = False

    try:
        with open(go_mod_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()

                # Handle block require
                if line.startswith("require ("):
                    in_require = True
                    continue
                if line == ")":
                    in_require = False
                    continue

                # Handle single-line require
                if line.startswith("require ") and "(" not in line:
                    parts = line.split()
                    if len(parts) >= 3:
                        deps.append(
                            {
                                "module": parts[1],
                                "version": parts[2].lstrip("v"),
                            }
                        )
                    continue

                # Inside require block
                if in_require:
                    # Skip comments and indirect markers
                    clean = line.split("//")[0].strip()
                    if not clean:
                        continue
                    parts = clean.split()
                    if len(parts) >= 2:
                        deps.append(
                            {
                                "module": parts[0],
                                "version": parts[1].lstrip("v"),
                            }
                        )
    except OSError as exc:
        logger.warning("Failed to read go.mod at %s: %s", go_mod_path, exc)

    return deps


def scan_go_mod(go_mod_path: str) -> list[dict]:
    """Parse a go.mod file and check each dependency against OSV.

    Args:
        go_mod_path: Absolute path to go.mod file.

    Returns:
        List of dicts with: module, version, vulnerabilities (list).
        Only includes dependencies that have known vulnerabilities.
    """
    deps = _parse_go_mod(go_mod_path)
    if not deps:
        return []

    results = []
    for dep in deps:
        vulns = check_osv(dep["module"], ecosystem="Go", version=dep["version"])
        if vulns:
            results.append(
                {
                    "module": dep["module"],
                    "version": dep["version"],
                    "vulnerabilities": vulns,
                }
            )

    return results


def _parse_package_json(package_json_path: str) -> list[dict]:
    """Parse a package.json file and extract dependencies.

    Args:
        package_json_path: Absolute path to package.json file.

    Returns:
        List of dicts with: package (name), version.
    """
    if not os.path.isfile(package_json_path):
        logger.warning("package.json not found at %s", package_json_path)
        return []

    try:
        with open(package_json_path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("Failed to read package.json at %s: %s", package_json_path, exc)
        return []

    deps = []
    for dep_section in ("dependencies", "devDependencies"):
        for name, version_spec in data.get(dep_section, {}).items():
            # Strip semver range operators to get a base version
            version = re.sub(r"^[\^~>=<]*", "", version_spec).strip()
            if version:
                deps.append({"package": name, "version": version})

    return deps


def scan_package_json(package_json_path: str) -> list[dict]:
    """Parse a package.json file and check each dependency against OSV.

    Args:
        package_json_path: Absolute path to package.json file.

    Returns:
        List of dicts with: package, version, vulnerabilities (list).
        Only includes dependencies that have known vulnerabilities.
    """
    deps = _parse_package_json(package_json_path)
    if not deps:
        return []

    results = []
    for dep in deps:
        vulns = check_osv(dep["package"], ecosystem="npm", version=dep["version"])
        if vulns:
            results.append(
                {
                    "package": dep["package"],
                    "version": dep["version"],
                    "vulnerabilities": vulns,
                }
            )

    return results
