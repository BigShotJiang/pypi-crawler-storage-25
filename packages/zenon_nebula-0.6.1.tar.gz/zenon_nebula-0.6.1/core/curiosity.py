# SPDX-License-Identifier: MIT
"""
CuriosityEngine -- Drives exploration beyond the current focus.

Periodically looks at repos, files, and topics nobody has asked about.
Suggests unexplored areas, performs random sampling, and finds cross-repo
patterns. Maintains a "last_explored" tracker per repo so the system
organically covers the entire workspace over time.

Storage:
    data/curiosity/exploration_log.json  -- history of explorations
    data/curiosity/last_explored.json    -- per-repo last-explored timestamps
"""

import json
import logging
import os
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
CURIOSITY_DIR = ENGINE_ROOT / "data" / "curiosity"
EXPLORATION_LOG_PATH = CURIOSITY_DIR / "exploration_log.json"
LAST_EXPLORED_PATH = CURIOSITY_DIR / "last_explored.json"

# Patterns that hint at interesting, under-examined code
INTERESTING_PATTERNS = [
    "TODO",
    "FIXME",
    "HACK",
    "XXX",
    "BUG",
    "deprecated",
    "experimental",
    "untested",
    "genesis",
    "satoshi",
    "plasma",
    "pillar",
    "sentinel",
    "bridge",
    "spork",
    "momentum",
    "accelerator",
    "cryptographic",
    "consensus",
    "merkle",
    "schnorr",
    "taproot",
    "htlc",
    "ptlc",
    "atomic",
]

# File types that are especially interesting for discovery
PRIORITY_EXTENSIONS = {".go", ".dart", ".rs", ".sol", ".py"}


class CuriosityEngine:
    """Drives autonomous exploration across the workspace.

    The curiosity engine ensures the system does not get tunnel-visioned
    on whatever it last investigated. It periodically surfaces repos,
    files, and patterns that haven't been looked at recently.

    Usage::

        curiosity = CuriosityEngine()
        suggestions = curiosity.suggest_unexplored(limit=5)
        sample = curiosity.random_sample(repo_name="go-zenon", count=3)
        patterns = curiosity.find_cross_repo_patterns("plasma")
    """

    def __init__(self, workspace_root: str | None = None):
        """Initialize the curiosity engine.

        Args:
            workspace_root: Root directory containing all repos.
                           Defaults to ZENON_WORKSPACE_ROOT env var
                           or one level above engine root.
        """
        self.workspace_root = Path(
            workspace_root
            or os.environ.get("ZENON_WORKSPACE_ROOT", "")
            or str(ENGINE_ROOT.parents[0])
        )
        self._ensure_dirs()
        self.last_explored: dict = self._load_last_explored()
        self.exploration_log: list[dict] = self._load_exploration_log()

    def _ensure_dirs(self) -> None:
        """Create data directories if needed."""
        CURIOSITY_DIR.mkdir(parents=True, exist_ok=True)

    def _load_last_explored(self) -> dict:
        """Load the last-explored timestamps per repo."""
        if LAST_EXPLORED_PATH.exists():
            try:
                return json.loads(LAST_EXPLORED_PATH.read_text())
            except (json.JSONDecodeError, OSError):
                pass
        return {}

    def _save_last_explored(self) -> None:
        """Persist the last-explored timestamps."""
        LAST_EXPLORED_PATH.write_text(json.dumps(self.last_explored, indent=2))

    def _load_exploration_log(self) -> list[dict]:
        """Load the exploration history."""
        if EXPLORATION_LOG_PATH.exists():
            try:
                data = json.loads(EXPLORATION_LOG_PATH.read_text())
                if isinstance(data, list):
                    return data
            except (json.JSONDecodeError, OSError):
                pass
        return []

    def _save_exploration_log(self) -> None:
        """Persist the exploration history (keep last 500 entries)."""
        trimmed = self.exploration_log[-500:]
        EXPLORATION_LOG_PATH.write_text(json.dumps(trimmed, indent=2))

    def _record_exploration(self, repo_name: str, action: str, details: dict) -> None:
        """Record an exploration event."""
        now = datetime.now(timezone.utc).isoformat()
        self.last_explored[repo_name] = now
        self._save_last_explored()

        self.exploration_log.append(
            {
                "timestamp": now,
                "repo": repo_name,
                "action": action,
                "details": details,
            }
        )
        self._save_exploration_log()

    def _discover_repos(self) -> list[dict]:
        """Discover all directories under workspace root."""
        repos = []
        if not self.workspace_root.exists():
            return repos

        for entry in sorted(self.workspace_root.iterdir()):
            if entry.is_dir() and not entry.name.startswith("."):
                has_git = (entry / ".git").exists()
                repos.append(
                    {
                        "name": entry.name,
                        "path": str(entry),
                        "has_git": has_git,
                    }
                )
        return repos

    def suggest_unexplored(self, limit: int = 5, staleness_hours: float = 168.0) -> list[dict]:
        """Suggest repos that haven't been explored recently.

        Ranks repos by how long ago they were last explored, prioritizing
        those never explored, then those most stale.

        Args:
            limit: Maximum number of suggestions.
            staleness_hours: Threshold for considering a repo stale (default 1 week).

        Returns:
            List of suggestion dicts with repo info and staleness score.
        """
        now = datetime.now(timezone.utc)
        repos = self._discover_repos()
        scored = []

        for repo in repos:
            name = repo["name"]
            last = self.last_explored.get(name)

            if last is None:
                age_hours = float("inf")
                reason = "never explored"
            else:
                try:
                    last_dt = datetime.fromisoformat(last)
                    if last_dt.tzinfo is None:
                        last_dt = last_dt.replace(tzinfo=timezone.utc)
                    age_hours = (now - last_dt).total_seconds() / 3600
                except (ValueError, TypeError):
                    age_hours = float("inf")
                    reason = "invalid timestamp"

                if age_hours >= staleness_hours:
                    reason = f"stale ({age_hours:.0f}h since last exploration)"
                else:
                    reason = f"explored {age_hours:.0f}h ago"

            scored.append(
                {
                    "repo_name": name,
                    "path": repo["path"],
                    "has_git": repo["has_git"],
                    "age_hours": age_hours,
                    "reason": reason if age_hours >= staleness_hours or last is None else None,
                }
            )

        # Sort: never explored first, then most stale
        scored.sort(key=lambda x: -x["age_hours"])

        # Filter to only suggestions (stale or never explored)
        suggestions = [
            s
            for s in scored
            if s["age_hours"] >= staleness_hours or s["reason"] == "never explored"
        ]

        return suggestions[:limit]

    def random_sample(
        self, repo_name: str, count: int = 5, ext_filter: str | None = None
    ) -> list[dict]:
        """Randomly sample files from a repo for exploration.

        Useful for discovering code patterns nobody thought to look at.
        Prioritizes source code files over documentation.

        Args:
            repo_name: Name of the repository to sample from.
            count: Number of files to return.
            ext_filter: Optional extension filter (e.g. ".go").

        Returns:
            List of file info dicts with path, size, and first line.
        """
        # Try corpus index first
        index_path = ENGINE_ROOT / "data" / "corpus_index" / f"{repo_name}.json"
        if index_path.exists():
            try:
                data = json.loads(index_path.read_text())
                files = data.get("files", [])
            except (json.JSONDecodeError, OSError):
                files = []
        else:
            # Fall back to direct filesystem scan
            files = self._scan_repo_files(repo_name)

        if ext_filter:
            files = [f for f in files if f.get("ext") == ext_filter]

        if not files:
            return []

        # Weight toward priority extensions (source code)
        priority = [f for f in files if f.get("ext") in PRIORITY_EXTENSIONS]
        others = [f for f in files if f.get("ext") not in PRIORITY_EXTENSIONS]

        # 70% chance of sampling priority files, 30% others
        sampled = []
        priority_count = min(int(count * 0.7), len(priority))
        other_count = min(count - priority_count, len(others))

        if priority:
            sampled.extend(random.sample(priority, min(priority_count, len(priority))))
        if others:
            sampled.extend(random.sample(others, min(other_count, len(others))))

        # Fill remaining from all files
        remaining = count - len(sampled)
        if remaining > 0 and files:
            unsampled = [f for f in files if f not in sampled]
            sampled.extend(random.sample(unsampled, min(remaining, len(unsampled))))

        self._record_exploration(
            repo_name,
            "random_sample",
            {
                "count": len(sampled),
                "ext_filter": ext_filter,
            },
        )

        return sampled

    def find_cross_repo_patterns(self, pattern: str, max_repos: int = 20) -> list[dict]:
        """Search for a pattern across all indexed repos.

        Finds files whose path or first line contains the pattern,
        grouped by repository. Useful for discovering how a concept
        (e.g. "plasma", "bridge") is implemented across the workspace.

        Args:
            pattern: Search term (case-insensitive).
            max_repos: Maximum number of repos to search.

        Returns:
            List of match dicts grouped by repo.
        """
        pattern_lower = pattern.lower()
        results = []
        index_dir = ENGINE_ROOT / "data" / "corpus_index"

        if not index_dir.exists():
            logger.warning("Corpus index not found -- run CorpusManager.index_repo() first")
            return results

        searched = 0
        for idx_path in sorted(index_dir.glob("*.json")):
            if idx_path.name == "manifest.json":
                continue
            if searched >= max_repos:
                break

            try:
                data = json.loads(idx_path.read_text())
                repo_name = data.get("repo_name", idx_path.stem)
                matches = []

                for file_entry in data.get("files", []):
                    searchable = (
                        file_entry.get("path", "").lower()
                        + " "
                        + file_entry.get("first_line", "").lower()
                    )
                    if pattern_lower in searchable:
                        matches.append(
                            {
                                "path": file_entry.get("path"),
                                "ext": file_entry.get("ext"),
                                "first_line": file_entry.get("first_line", ""),
                                "size": file_entry.get("size", 0),
                            }
                        )

                if matches:
                    results.append(
                        {
                            "repo_name": repo_name,
                            "match_count": len(matches),
                            "matches": matches[:20],  # Cap per repo
                        }
                    )
                    self._record_exploration(
                        repo_name,
                        "pattern_search",
                        {
                            "pattern": pattern,
                            "matches": len(matches),
                        },
                    )

                searched += 1

            except (json.JSONDecodeError, OSError):
                continue

        results.sort(key=lambda x: -x["match_count"])
        return results

    def find_interesting_files(self, repo_name: str, max_results: int = 20) -> list[dict]:
        """Find files containing interesting patterns in a repo.

        Scans for TODO, FIXME, genesis, cryptographic, and other
        markers that hint at under-examined code.

        Args:
            repo_name: Repository to scan.
            max_results: Maximum files to return.

        Returns:
            List of file entries with matched patterns.
        """
        index_path = ENGINE_ROOT / "data" / "corpus_index" / f"{repo_name}.json"
        if not index_path.exists():
            return []

        try:
            data = json.loads(index_path.read_text())
        except (json.JSONDecodeError, OSError):
            return []

        interesting = []
        for file_entry in data.get("files", []):
            first_line = file_entry.get("first_line", "").lower()
            path_lower = file_entry.get("path", "").lower()
            searchable = path_lower + " " + first_line

            matched_patterns = [p for p in INTERESTING_PATTERNS if p.lower() in searchable]

            if matched_patterns:
                entry = dict(file_entry)
                entry["matched_patterns"] = matched_patterns
                entry["interest_score"] = len(matched_patterns)
                interesting.append(entry)

        interesting.sort(key=lambda x: -x["interest_score"])

        self._record_exploration(
            repo_name,
            "interesting_scan",
            {
                "found": len(interesting),
            },
        )

        return interesting[:max_results]

    def get_exploration_coverage(self) -> dict:
        """Calculate how much of the workspace has been explored.

        Returns:
            Dict with coverage statistics.
        """
        repos = self._discover_repos()
        total = len(repos)
        explored = sum(1 for r in repos if r["name"] in self.last_explored)

        now = datetime.now(timezone.utc)
        recently_explored = 0
        for r in repos:
            last = self.last_explored.get(r["name"])
            if last:
                try:
                    last_dt = datetime.fromisoformat(last)
                    if last_dt.tzinfo is None:
                        last_dt = last_dt.replace(tzinfo=timezone.utc)
                    if (now - last_dt) < timedelta(days=7):
                        recently_explored += 1
                except (ValueError, TypeError):
                    pass

        return {
            "total_repos": total,
            "ever_explored": explored,
            "explored_last_7d": recently_explored,
            "coverage_percent": round((explored / max(total, 1)) * 100, 1),
            "recent_coverage_percent": round((recently_explored / max(total, 1)) * 100, 1),
        }

    def get_exploration_history(self, limit: int = 20) -> list[dict]:
        """Return recent exploration events."""
        return self.exploration_log[-limit:]

    def _scan_repo_files(self, repo_name: str) -> list[dict]:
        """Scan a repo directly when no index is available."""
        repo_info = None
        # Check manifest for path
        manifest_path = ENGINE_ROOT / "data" / "corpus_index" / "manifest.json"
        if manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text())
                repo_info = manifest.get("repos", {}).get(repo_name, {})
            except (json.JSONDecodeError, OSError):
                pass

        if repo_info:
            repo_path = Path(repo_info.get("path", ""))
        else:
            repo_path = self.workspace_root / repo_name

        if not repo_path.exists():
            return []

        from core.corpus import INDEXABLE_EXTENSIONS, MAX_FILE_SIZE_BYTES

        files = []
        try:
            for root, dirs, filenames in os.walk(repo_path):
                dirs[:] = [
                    d
                    for d in dirs
                    if not d.startswith(".")
                    and d
                    not in {
                        "node_modules",
                        "vendor",
                        "__pycache__",
                        "build",
                        "dist",
                        "venv",
                        ".venv",
                    }
                ]
                for fname in filenames:
                    fpath = Path(root) / fname
                    ext = fpath.suffix.lower()
                    if ext not in INDEXABLE_EXTENSIONS:
                        continue
                    try:
                        stat = fpath.stat()
                        if stat.st_size > MAX_FILE_SIZE_BYTES or stat.st_size == 0:
                            continue
                        rel_path = str(fpath.relative_to(repo_path))
                        first_line = ""
                        try:
                            with open(fpath, encoding="utf-8", errors="ignore") as f:
                                first_line = f.readline().strip()[:200]
                        except (OSError, UnicodeDecodeError):
                            pass
                        files.append(
                            {
                                "path": rel_path,
                                "size": stat.st_size,
                                "ext": ext,
                                "first_line": first_line,
                            }
                        )
                    except OSError:
                        continue

                    if len(files) >= 2000:
                        break
        except OSError:
            pass

        return files
