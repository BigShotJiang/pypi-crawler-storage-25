# SPDX-License-Identifier: MIT
"""
Collision Engine -- Cross-domain convergence detection for the Nebula.

**Agent pattern:** *parallelization with voting* (Anthropic "Building
Effective Agents" taxonomy). Multiple domain engines run independently
against the same evidence space; the collision engine watches for cases
where independent engines converge on the same finding or hypothesis.
A collision is effectively a vote -- when two or more engines agree, the
underlying signal gets a confidence boost and may trigger an escalation.

Detects when multiple domains converge on the same hypothesis or finding.
Cross-domain patterns:
  - security + quality finding the same bug
  - development + intelligence detecting the same spec change
  - all domains signalling PR readiness
  - flywheel patterns where output accelerates across engines

When convergent evidence is detected, triggers actions: block PR, boost
priority, alert, or escalate to the war room.

Persists collisions to the collisions table for audit and visualization.
"""

import json
import logging
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Confidence thresholds
BREAKTHROUGH_THRESHOLD = 0.85
SIGNIFICANT_THRESHOLD = 0.70

COLLISIONS_SCHEMA = """
CREATE TABLE IF NOT EXISTS collisions (
    id TEXT PRIMARY KEY,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    collision_type TEXT NOT NULL,
    hypothesis_id TEXT,
    title TEXT,
    confidence REAL DEFAULT 0.0,
    domains_involved TEXT DEFAULT '[]',
    engines_involved TEXT DEFAULT '[]',
    engine_count INTEGER DEFAULT 0,
    convergent BOOLEAN DEFAULT FALSE,
    actions_taken TEXT DEFAULT '[]',
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at DATETIME,
    resolved_by TEXT
);

CREATE INDEX IF NOT EXISTS idx_collisions_type
    ON collisions(collision_type);
CREATE INDEX IF NOT EXISTS idx_collisions_resolved
    ON collisions(resolved);
CREATE INDEX IF NOT EXISTS idx_collisions_hypothesis
    ON collisions(hypothesis_id);
"""


@dataclass
class Collision:
    """A point where multiple domains converge on the same finding."""

    id: str = ""
    collision_type: str = "convergent_evidence"
    hypothesis_id: str = ""
    title: str = ""
    confidence: float = 0.0
    domains_involved: list[str] = field(default_factory=list)
    engines_involved: list[str] = field(default_factory=list)
    engine_count: int = 0
    convergent: bool = False
    actions: list[dict] = field(default_factory=list)

    def __post_init__(self):
        if not self.id:
            self.id = f"col_{uuid.uuid4().hex[:8]}"

    def to_dict(self) -> dict:
        """Serialize collision record to a plain dict."""
        return {
            "id": self.id,
            "collision_type": self.collision_type,
            "hypothesis_id": self.hypothesis_id,
            "title": self.title,
            "confidence": self.confidence,
            "domains_involved": self.domains_involved,
            "engines_involved": self.engines_involved,
            "engine_count": self.engine_count,
            "convergent": self.convergent,
            "actions": self.actions,
        }


class CollisionEngine:
    """Cross-domain convergence detection and action triggering.

    Reads collision signals registered by all domains, detects when
    multiple domains produce findings about the same hypothesis or
    topic, and triggers appropriate actions.
    """

    def __init__(self, db_path: str = DEFAULT_DB):
        self.db_path = db_path
        self._ensure_schema()

    def _get_conn(self) -> sqlite3.Connection:
        conn = connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        conn = self._get_conn()
        try:
            conn.executescript(COLLISIONS_SCHEMA)
            conn.commit()
        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Core collision detection
    # ------------------------------------------------------------------

    def detect_collisions(self, registry=None) -> list[Collision]:
        """Find convergent evidence across all domains.

        Checks:
        1. Hypotheses supported by multiple independent engines
        2. Cross-domain signals that match registered CollisionSignals
        3. Flywheel patterns (accelerating output across engines)

        Args:
            registry: Optional DomainRegistry for collision signal defs.

        Returns:
            List of Collision objects sorted by engine_count descending.
        """
        collisions: list[Collision] = []

        # 1. Multi-engine hypothesis convergence
        convergent = self.get_convergent_hypotheses()
        for hyp in convergent:
            collision = Collision(
                collision_type="convergent_evidence",
                hypothesis_id=hyp["hypothesis_id"],
                title=hyp["title"],
                confidence=hyp["confidence"],
                domains_involved=hyp.get("domains_involved", []),
                engines_involved=hyp.get("supporting_engines", []),
                engine_count=hyp["engine_count"],
                convergent=True,
            )

            # Generate actions for high-confidence convergence
            if collision.confidence >= SIGNIFICANT_THRESHOLD:
                collision.actions = self._generate_actions(collision)

            collisions.append(collision)

        # 2. Registered collision signals
        if registry:
            signal_collisions = self._check_registered_signals(registry)
            collisions.extend(signal_collisions)

        # 3. Flywheel patterns
        flywheel = self._detect_flywheel_patterns()
        collisions.extend(flywheel)

        # Persist new collisions
        for collision in collisions:
            self._persist_collision(collision)

        # Log
        from core.persist_to_db import persist_action

        if collisions:
            persist_action(
                db_path=self.db_path,
                domain="system",
                module="collision_engine",
                action="detect_collisions",
                result=f"{len(collisions)} collisions detected",
            )

        logger.info("Collision detection: %d total collisions", len(collisions))
        return sorted(collisions, key=lambda c: -c.engine_count)

    # ------------------------------------------------------------------
    # Multi-engine hypothesis convergence
    # ------------------------------------------------------------------

    def get_convergent_hypotheses(self) -> list[dict]:
        """Get hypotheses with evidence from 2+ independent engines/domains."""
        conn = self._get_conn()
        try:
            convergent: list[dict] = []

            try:
                hypotheses = conn.execute(
                    "SELECT id, domain, title, confidence, status "
                    "FROM hypotheses WHERE confidence > 0 "
                    "ORDER BY confidence DESC"
                ).fetchall()
            except sqlite3.OperationalError:
                return []

            for hyp in hypotheses:
                # Supporting engines
                supporting = conn.execute(
                    "SELECT DISTINCT engine, domain FROM evidence WHERE supports_hypothesis = ?",
                    (hyp["id"],),
                ).fetchall()
                supporting_engines = [r["engine"] for r in supporting]
                supporting_domains = list({r["domain"] for r in supporting})

                # Contradicting engines
                contradicting = conn.execute(
                    "SELECT DISTINCT engine FROM evidence WHERE contradicts_hypothesis = ?",
                    (hyp["id"],),
                ).fetchall()

                if len(supporting_engines) >= 2:
                    convergent.append(
                        {
                            "hypothesis_id": hyp["id"],
                            "title": hyp["title"],
                            "confidence": hyp["confidence"],
                            "status": hyp["status"],
                            "supporting_engines": supporting_engines,
                            "contradicting_engines": [r["engine"] for r in contradicting],
                            "domains_involved": supporting_domains,
                            "engine_count": len(supporting_engines),
                            "convergent": True,
                        }
                    )

            convergent.sort(key=lambda h: (-h["engine_count"], -h["confidence"]))
            return convergent

        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Registered collision signals
    # ------------------------------------------------------------------

    def _check_registered_signals(self, registry) -> list[Collision]:
        """Check collision signals registered by domain plugins."""
        collisions: list[Collision] = []
        conn = self._get_conn()

        try:
            all_signals = registry.get_all_collision_signals()

            for signal in all_signals:
                # Check if source domains have recent overlapping evidence
                domain_evidence = {}
                for domain_name in signal.source_domains:
                    try:
                        rows = conn.execute(
                            "SELECT id, engine, finding, confidence "
                            "FROM evidence WHERE domain = ? "
                            "AND timestamp > datetime('now', '-24 hours') "
                            "AND confidence >= ?",
                            (domain_name, signal.convergence_threshold),
                        ).fetchall()
                        if rows:
                            domain_evidence[domain_name] = [dict(r) for r in rows]
                    except sqlite3.OperationalError:
                        pass

                # Collision if 2+ source domains have recent evidence
                if len(domain_evidence) >= 2:
                    all_engines = []
                    for findings in domain_evidence.values():
                        all_engines.extend(f["engine"] for f in findings)

                    max_conf = max(
                        f["confidence"] for findings in domain_evidence.values() for f in findings
                    )

                    collision = Collision(
                        collision_type=f"signal:{signal.signal_id}",
                        title=signal.label,
                        confidence=max_conf,
                        domains_involved=list(domain_evidence.keys()),
                        engines_involved=list(set(all_engines)),
                        engine_count=len(set(all_engines)),
                        convergent=True,
                    )
                    collision.actions = self._generate_actions(collision)
                    collisions.append(collision)

        finally:
            conn.close()

        return collisions

    # ------------------------------------------------------------------
    # Flywheel detection
    # ------------------------------------------------------------------

    def _detect_flywheel_patterns(self) -> list[Collision]:
        """Detect flywheel patterns -- same metric accelerating across
        multiple engines simultaneously."""
        conn = self._get_conn()
        flywheels: list[Collision] = []

        try:
            now = datetime.now(timezone.utc)
            week_ago = (now - timedelta(days=7)).isoformat()
            mid_week = (now - timedelta(days=3.5)).isoformat()

            try:
                first_half = conn.execute(
                    "SELECT engine, domain, count(*) as cnt FROM evidence "
                    "WHERE timestamp > ? AND timestamp <= ? "
                    "GROUP BY engine",
                    (week_ago, mid_week),
                ).fetchall()

                second_half = conn.execute(
                    "SELECT engine, domain, count(*) as cnt FROM evidence "
                    "WHERE timestamp > ? GROUP BY engine",
                    (mid_week,),
                ).fetchall()
            except sqlite3.OperationalError:
                return []

            first_counts = {r["engine"]: r["cnt"] for r in first_half}
            second_counts = {r["engine"]: r["cnt"] for r in second_half}
            second_domains = {r["engine"]: r["domain"] for r in second_half}

            accelerating = []
            for engine, count in second_counts.items():
                prev = first_counts.get(engine, 0)
                if prev > 0 and count > prev * 1.5:
                    accelerating.append(
                        {
                            "engine": engine,
                            "domain": second_domains.get(engine, "unknown"),
                            "first_half": prev,
                            "second_half": count,
                            "acceleration": round(count / prev, 2),
                        }
                    )

            if len(accelerating) >= 2:
                domains = list({a["domain"] for a in accelerating})
                flywheel = Collision(
                    collision_type="flywheel",
                    title="Cross-domain acceleration detected",
                    confidence=0.0,
                    domains_involved=domains,
                    engines_involved=[a["engine"] for a in accelerating],
                    engine_count=len(accelerating),
                    convergent=True,
                    actions=[
                        {
                            "action": "flywheel_alert",
                            "details": (
                                f"{len(accelerating)} engines accelerating: "
                                + ", ".join(
                                    f"{a['engine']}={a['acceleration']}x" for a in accelerating
                                )
                            ),
                            "priority": 10,
                        }
                    ],
                )
                flywheels.append(flywheel)

        finally:
            conn.close()

        return flywheels

    # ------------------------------------------------------------------
    # Action generation
    # ------------------------------------------------------------------

    def _generate_actions(self, collision: Collision) -> list[dict]:
        """Generate actions for a collision based on its type and confidence."""
        actions = []

        if collision.confidence >= BREAKTHROUGH_THRESHOLD:
            actions.append(
                {
                    "action": "escalate_to_war_room",
                    "details": (
                        f"BREAKTHROUGH convergence: '{collision.title}' "
                        f"confirmed by {collision.engine_count} engines"
                    ),
                    "priority": 10,
                }
            )
            actions.append(
                {
                    "action": "boost_priority",
                    "details": (f"Boost priority for hypothesis '{collision.hypothesis_id}'"),
                    "priority": 9,
                }
            )
        elif collision.confidence >= SIGNIFICANT_THRESHOLD:
            actions.append(
                {
                    "action": "alert",
                    "details": (
                        f"Growing convergence: '{collision.title}' "
                        f"supported by {collision.engine_count} engines"
                    ),
                    "priority": 7,
                }
            )

        # Security-related collisions always get block_pr
        if "security" in collision.domains_involved:
            actions.append(
                {
                    "action": "block_pr",
                    "details": (f"Security-relevant collision detected: '{collision.title}'"),
                    "priority": 10,
                }
            )

        return actions

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _persist_collision(self, collision: Collision) -> None:
        """Save a collision to the database, deduplicating by type+title."""
        conn = self._get_conn()
        try:
            # Dedup: check for existing unresolved collision with same type+title
            existing = conn.execute(
                "SELECT id FROM collisions WHERE collision_type = ? AND title = ? AND resolved = 0",
                (collision.collision_type, collision.title),
            ).fetchone()

            if existing:
                # Update existing collision (refresh timestamp + metrics)
                conn.execute(
                    "UPDATE collisions SET confidence = ?, "
                    "engine_count = ?, engines_involved = ?, "
                    "domains_involved = ?, actions_taken = ?, "
                    "timestamp = CURRENT_TIMESTAMP "
                    "WHERE id = ?",
                    (
                        collision.confidence,
                        collision.engine_count,
                        json.dumps(collision.engines_involved),
                        json.dumps(collision.domains_involved),
                        json.dumps(collision.actions),
                        existing["id"],
                    ),
                )
            else:
                # New collision
                conn.execute(
                    "INSERT INTO collisions "
                    "(id, collision_type, hypothesis_id, title, confidence, "
                    "domains_involved, engines_involved, engine_count, "
                    "convergent, actions_taken) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        collision.id,
                        collision.collision_type,
                        collision.hypothesis_id,
                        collision.title,
                        collision.confidence,
                        json.dumps(collision.domains_involved),
                        json.dumps(collision.engines_involved),
                        collision.engine_count,
                        collision.convergent,
                        json.dumps(collision.actions),
                    ),
                )
            conn.commit()
        except sqlite3.IntegrityError:
            pass  # duplicate
        finally:
            conn.close()

    def get_active_collisions(self) -> list[dict]:
        """Get all unresolved collisions."""
        conn = self._get_conn()
        try:
            rows = conn.execute(
                "SELECT * FROM collisions WHERE resolved = 0 ORDER BY confidence DESC"
            ).fetchall()
            result = []
            for row in rows:
                d = dict(row)
                for key in ("domains_involved", "engines_involved", "actions_taken"):
                    try:
                        d[key] = json.loads(d.get(key, "[]"))
                    except (json.JSONDecodeError, TypeError):
                        d[key] = []
                result.append(d)
            return result
        finally:
            conn.close()

    def resolve_collision(self, collision_id: str, resolved_by: str = "system") -> bool:
        """Mark a collision as resolved."""
        conn = self._get_conn()
        try:
            now = datetime.now(timezone.utc).isoformat()
            cursor = conn.execute(
                "UPDATE collisions SET resolved = 1, resolved_at = ?, "
                "resolved_by = ? WHERE id = ? AND resolved = 0",
                (now, resolved_by, collision_id),
            )
            conn.commit()
            return cursor.rowcount > 0
        finally:
            conn.close()
