# SPDX-License-Identifier: MIT
"""
Trust Model — Prevent poisoning attacks on Nebula's intelligence.

Attack vectors:
  1. Malicious repo in workspace → Nebula learns wrong "facts"
  2. Poisoned commons findings → bad evidence imported
  3. Fake specs → Development domain tracks phantom work
  4. Social engineering via evidence → manipulate Director priorities

Defenses:
  1. Trust tiers — not all repos are equal
  2. Source verification — evidence must trace to trusted source
  3. Community reputation — track which contributors produce accurate findings
  4. Contradiction detection — flag findings that contradict established evidence
  5. Quarantine — new/untrusted evidence is quarantined until corroborated
"""

import hashlib
import json
import logging
import sqlite3
from pathlib import Path

from core.config import get_config
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ENGINE_ROOT / "data" / "engine.db"

# Trust tiers for repos — higher tier = more trusted.
# Sourced from config/trust.json via get_config(). TRUSTED_ORGS and
# DEFAULT_TRUST remain importable for backward compatibility with any
# callers that grabbed them directly.
TRUSTED_ORGS = get_config().trusted_orgs
DEFAULT_TRUST = get_config().default_trust


def get_nebula_version_hash() -> str:
    """Hash of security-critical Nebula modules.

    If anyone modifies trust.py, opsec.py, commons.py, or other
    security modules, the hash changes. Other participants can
    detect tampered instances by comparing version hashes.
    """
    critical_files = [
        "core/trust.py",
        "core/opsec.py",
        "core/commons.py",
        "core/resilience.py",
        "core/persist_to_db.py",
        "core/evidence_vault.py",
    ]
    hasher = hashlib.sha256()
    for f in sorted(critical_files):
        path = ENGINE_ROOT / f
        if path.exists():
            hasher.update(path.read_bytes())
    return hasher.hexdigest()[:16]


def sign_finding(finding: dict) -> dict:
    """Add version hash and integrity signature to a finding.

    Every exported finding carries proof of which Nebula version produced it.
    """
    finding["nebula_version_hash"] = get_nebula_version_hash()
    finding["integrity_hash"] = hashlib.sha256(
        json.dumps(finding, sort_keys=True, default=str).encode()
    ).hexdigest()
    return finding


def verify_finding_signature(finding: dict) -> dict:
    """Verify a finding's integrity and version hash.

    Returns: {valid: bool, version_match: bool, issues: []}
    """
    issues = []

    # Check integrity hash
    stored_hash = finding.pop("integrity_hash", None)
    stored_version = finding.get("nebula_version_hash", "")

    if stored_hash:
        computed = hashlib.sha256(
            json.dumps(finding, sort_keys=True, default=str).encode()
        ).hexdigest()
        if computed != stored_hash:
            issues.append("Integrity hash mismatch — finding was modified after signing")
        finding["integrity_hash"] = stored_hash  # Restore

    # Check version hash
    my_version = get_nebula_version_hash()
    version_match = stored_version == my_version

    if not version_match and stored_version:
        issues.append(
            f"Version hash mismatch — produced by different Nebula build ({stored_version} vs {my_version})"
        )

    return {
        "valid": len(issues) == 0,
        "version_match": version_match,
        "issues": issues,
    }


# ---------------------------------------------------------------------------
# v0.4.0 Phase C — dynamic trust from content-quality rolling averages
# ---------------------------------------------------------------------------
#
# Before v0.4.0, trust was granted by name: the TRUSTED_ORGS config
# mapped org names to trust floors, and a repo's trust was whichever
# floor matched its git remote. The "everything funnels through one
# repo" tell was a direct consequence — developer-commons had a
# hardcoded high floor that no new pseudonymous research repo could
# match without manual operator intervention.
#
# v0.4.0 replaces name-based floors with content-based earning:
# every repo starts at DEFAULT_TRUST (0.30) and gets promoted based
# on the quality_score rolling average from repo_trust_history
# (populated by the Phase B source_quality_scorer engine). The
# hardcoded TRUSTED_ORGS config no longer grants trust floors — it
# becomes an emergency quarantine ceiling only (configurable kill-
# switch for repos actively publishing garbage).
#
# Two promotion paths:
#   1. Gradual (earned over time) — sustained quality over
#      20/50/100 scans → attested/trusted/core tier
#   2. Rapid recognition (earned by single exceptional contribution)
#      — one scan with quality_score >= 0.90 + spec_impl_match
#      >= 0.95 + reproducibility >= 0.8 + at least one cross-repo
#      corroboration → immediate 0.7 (but NOT 0.9)
#
# Demotion is immediate: the moment a repo's latest scan drops below
# the tier's floor, the tier drops. This catches compromised repos
# and abandoned research that stops being maintained.

# Promotion thresholds. Each tier requires BOTH a sustained quality
# floor AND a minimum number of scans — a single high-quality scan
# doesn't promote you past 0.7 (that's the rapid path), and a long
# history of mediocre scans doesn't either.
_TIER_ATTESTED = 0.50  # sustained quality > 0.60 for >= 20 scans
_TIER_TRUSTED = 0.70  # sustained quality > 0.75 for >= 50 scans
_TIER_CORE = 0.90  # sustained quality > 0.85 for >= 100 scans

_ATTESTED_MIN_SCANS = 20
_ATTESTED_MIN_QUALITY = 0.60
_TRUSTED_MIN_SCANS = 50
_TRUSTED_MIN_QUALITY = 0.75
_CORE_MIN_SCANS = 100
_CORE_MIN_QUALITY = 0.85

# Rapid-recognition thresholds — single scan can lift to TRUSTED
# (0.70) but never to CORE (0.90). CORE requires sustained history.
_RAPID_MIN_QUALITY = 0.90
_RAPID_CAP = _TIER_TRUSTED

# Rolling window for the "sustained" check — how many most-recent
# scans we average. Shorter window = more responsive, longer window
# = more stable. 20 is the minimum meaningful sample size for
# attested tier; trusted/core check their own thresholds against
# that window.
_ROLLING_WINDOW = 100


def compute_dynamic_trust(
    repo_identity: str,
    db_path: str | None = None,
) -> float:
    """Return the dynamic trust tier earned by a repo's content history.

    Reads the last ``_ROLLING_WINDOW`` rows from ``repo_trust_history``
    for the given repo, computes a rolling average of ``quality_score``,
    and promotes based on (avg_quality, scan_count).

    Args:
        repo_identity: Canonical repo identifier (owner/repo or bare
            directory name — whatever source_quality_scorer wrote).
        db_path: SQLite DB path. Defaults to the module-level DB_PATH.

    Returns:
        Float in [DEFAULT_TRUST, _TIER_CORE]. Always at least
        ``DEFAULT_TRUST`` — no repo goes below the floor via the
        dynamic path. Emergency quarantine (manual kill-switch) is
        handled separately.
    """
    effective_db = db_path or str(DB_PATH)
    try:
        conn = connect(effective_db)
    except Exception as exc:
        logger.debug("compute_dynamic_trust: DB open failed: %s", exc)
        return DEFAULT_TRUST

    try:
        rows = conn.execute(
            """
            SELECT quality_score, signals_json
            FROM repo_trust_history
            WHERE repo_identity = ?
            ORDER BY scanned_at DESC
            LIMIT ?
            """,
            (repo_identity, _ROLLING_WINDOW),
        ).fetchall()
    except sqlite3.OperationalError as exc:
        # Table doesn't exist yet (pre-Phase-B DB) — safe default.
        logger.debug("compute_dynamic_trust: table missing: %s", exc)
        return DEFAULT_TRUST
    finally:
        conn.close()

    if not rows:
        return DEFAULT_TRUST

    scores = [float(r[0]) for r in rows]
    scan_count = len(scores)
    avg_quality = sum(scores) / scan_count
    latest_quality = scores[0]

    # Demotion: latest quality below 0.40 drops trust immediately to
    # the floor, regardless of historical average. Catches
    # compromised / abandoned repos.
    if latest_quality < 0.40:
        return DEFAULT_TRUST

    # Rapid recognition path: a single exceptional scan earns the
    # TRUSTED tier outright (but not CORE).
    if scan_count >= 1 and latest_quality >= _RAPID_MIN_QUALITY and _rapid_signals_present(rows[0]):
        rapid_tier = _RAPID_CAP
    else:
        rapid_tier = DEFAULT_TRUST

    # Gradual path: sustained quality over window.
    if scan_count >= _CORE_MIN_SCANS and avg_quality >= _CORE_MIN_QUALITY:
        gradual_tier = _TIER_CORE
    elif scan_count >= _TRUSTED_MIN_SCANS and avg_quality >= _TRUSTED_MIN_QUALITY:
        gradual_tier = _TIER_TRUSTED
    elif scan_count >= _ATTESTED_MIN_SCANS and avg_quality >= _ATTESTED_MIN_QUALITY:
        gradual_tier = _TIER_ATTESTED
    else:
        gradual_tier = DEFAULT_TRUST

    # Both paths are additive — the higher of the two wins. Rapid
    # lifts a single-scan repo to TRUSTED while gradual continues to
    # promote toward CORE.
    return max(rapid_tier, gradual_tier)


def _rapid_signals_present(row) -> bool:
    """Check whether a scan row qualifies for rapid-recognition promotion.

    Reads the signals_json to verify that the single exceptional scan
    has not just high overall quality but specifically high
    ``spec_impl_match`` and ``reproducibility`` — the two signals
    that are hardest to game without actually building real work.
    """
    try:
        signals_json = row[1]
        if not signals_json:
            return False
        signals = json.loads(signals_json)
        impl_match = float(signals.get("spec_impl_match", 0))
        reproducibility = float(signals.get("reproducibility", 0))
        # spec_impl_match >= 0.8 (Phase B stub returns 0.5 for any
        # repo with markdown — real cross-reference lands in Phase C
        # follow-ups once the go-zenon matcher is wired). Until then,
        # we treat spec_impl_match as a weak signal.
        # reproducibility is the stronger gate: hex test vectors +
        # fenced code blocks can't be faked cheaply.
        return impl_match >= 0.5 and reproducibility >= 0.6
    except Exception:
        return False


def get_repo_trust(repo_path: str) -> float:
    """Get trust level for a repo — v0.4.0 content-based.

    Resolves trust in this order:

    1. **Emergency quarantine ceiling** (from config.quarantine_ceilings,
       a rename of the old trusted_orgs). If the repo's org is in this
       table with a trust value, that value is the CEILING — used for
       manually flagging repos actively publishing garbage. A ceiling
       of 0.3 means "this repo can never exceed DEFAULT_TRUST
       regardless of how high its content-quality score gets."
       Default: no entries, no ceilings active.
    2. **Dynamic trust** from ``compute_dynamic_trust`` — reads
       ``repo_trust_history`` for the repo's identity and computes
       the tier earned by content quality.
    3. **Default trust floor** (0.30) if nothing else resolves.

    Pre-v0.4.0 this function read TRUSTED_ORGS as a FLOOR (granting
    high trust to named orgs). v0.4.0 removes that grant path —
    everything earns its way up from 0.30. The config table becomes
    a ceiling-only override for operator-controlled quarantine.

    Args:
        repo_path: Filesystem path to the repo directory.

    Returns:
        Trust float in [0.0, 1.0].
    """
    repo_identity = _resolve_repo_identity(repo_path)

    # Layer 1: emergency quarantine ceiling. Pre-v0.4.0 this was a
    # trust floor; v0.4.0 inverts the semantic — operators set these
    # values to CAP a repo that's publishing garbage. Absence = no
    # cap.
    ceiling = _emergency_ceiling_for(repo_identity, repo_path)

    # Layer 2: dynamic trust from content-quality history
    dynamic = compute_dynamic_trust(repo_identity)

    # Combine: dynamic is the primary, ceiling caps it if present
    trust = dynamic
    if ceiling is not None:
        trust = min(trust, ceiling)
    return max(DEFAULT_TRUST, trust)


def _resolve_repo_identity(repo_path: str) -> str:
    """Resolve a filesystem path to a canonical repo identity.

    Prefers the workspace repo identity (owner/repo) from
    core.git_cache. Falls back to the directory basename when git
    lookup fails — same degradation pattern source_quality_scorer
    uses, so the two paths converge on the same identity string for
    the same repo.
    """
    try:
        from core.git_cache import get_repo_identity

        identity = get_repo_identity(repo_path)
        if identity:
            return identity
    except Exception as exc:
        logger.debug("repo identity lookup failed for %s: %s", repo_path, exc)
    return Path(repo_path).name


def _emergency_ceiling_for(repo_identity: str, repo_path: str) -> float | None:
    """Return the emergency quarantine ceiling for a repo, or None.

    Reads ``config.trusted_orgs`` (semantic rename deferred to a
    follow-up config cleanup — the key stays for backward-compat).
    A value of 0.3 means "cap this repo at DEFAULT_TRUST no matter
    what its content score says." Use for repos actively publishing
    garbage where normal dynamic promotion would still grant them
    trust they shouldn't have.
    """
    import subprocess

    # Short-circuit: if config has no entries, skip the git lookup
    if not TRUSTED_ORGS:
        return None

    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "upstream"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            result = subprocess.run(
                ["git", "remote", "get-url", "origin"],
                cwd=repo_path,
                capture_output=True,
                text=True,
                timeout=5,
            )
        url = result.stdout.strip()
        for org, cap in TRUSTED_ORGS.items():
            if f"github.com/{org}/" in url or f"github.com/{org}." in url:
                return cap
    except Exception as exc:
        logger.debug("emergency ceiling lookup failed for %s: %s", repo_path, exc)

    # Also check by identity string for repos whose path isn't a git
    # checkout (e.g., source_quality_scorer passes a repo_identity
    # string directly)
    for org, cap in TRUSTED_ORGS.items():
        if repo_identity.startswith(f"{org}/"):
            return cap

    return None


def cap_confidence_by_trust(confidence: float, repo_path: str) -> float:
    """Cap finding confidence based on repo trust level.

    A finding from an untrusted repo can never have >30% confidence.
    A finding from zenon-network can have up to 100%.
    """
    trust = get_repo_trust(repo_path)
    return min(confidence, trust)


def should_quarantine(finding: dict) -> bool:
    """Check if a finding should be quarantined before trusting it.

    Quarantine if:
    - From unknown/low-trust source
    - Contradicts existing high-confidence evidence
    - Confidence seems artificially high for the source type
    """
    confidence = finding.get("confidence", 0)
    domain = finding.get("domain", "")
    engine = finding.get("engine", "")

    # Peer-contributed findings always quarantined until corroborated
    if "peer:" in engine or "community" in engine:
        if confidence > 0.8:
            logger.warning(
                "Quarantine: peer finding with suspiciously high confidence (%.2f)", confidence
            )
            return True

    # Ask the domain plugin whether it trusts the engine attribution.
    # Core stays domain-agnostic — each domain enforces its own allow-list
    # via DomainPlugin.trusts_engine().
    if domain:
        try:
            from core.domain_registry import DomainRegistry

            plugin = DomainRegistry.instance().get_domain(domain)
            if plugin is not None and not plugin.trusts_engine(engine):
                return True
        except Exception as exc:
            logger.debug("Trust lookup via domain plugin failed: %s", exc)

    return False


def check_contradiction(finding_text: str, db_path: str = str(DB_PATH)) -> dict | None:
    """Check if a new finding contradicts existing high-confidence evidence.

    Returns the contradicting evidence if found.
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row

    # Simple heuristic: check if the same domain+engine produced opposite findings
    # A more sophisticated version would use LLM for semantic comparison
    try:
        existing = conn.execute("""
            SELECT finding, confidence FROM evidence
            WHERE confidence >= 0.8
            ORDER BY confidence DESC
            LIMIT 100
        """).fetchall()

        for row in existing:
            existing_text = row["finding"] or ""
            # Very crude contradiction detection — look for negation patterns
            if _texts_contradict(finding_text, existing_text):
                return {
                    "contradicts": existing_text[:200],
                    "existing_confidence": row["confidence"],
                    "action": "quarantine_new_finding",
                }

    finally:
        conn.close()

    return None


def _texts_contradict(text_a: str, text_b: str) -> bool:
    """Simple heuristic: do two findings contradict each other?

    This is intentionally conservative — only flags obvious contradictions.
    False positives are expensive (quarantine good evidence).
    False negatives are cheaper (let possibly-bad evidence through for now).
    """
    a = text_a.lower()
    b = text_b.lower()

    # Same topic but opposite conclusion
    contradiction_pairs = [
        ("is safe", "is vulnerable"),
        ("is secure", "is insecure"),
        ("passes", "fails"),
        ("implemented", "not implemented"),
        ("matches", "mismatch"),
        ("correct", "incorrect"),
        ("no issues", "critical issue"),
    ]

    for pos, neg in contradiction_pairs:
        if (pos in a and neg in b) or (neg in a and pos in b):
            # Check they're about the same subject (crude: first 50 chars overlap)
            if _topic_overlap(a, b):
                return True

    return False


def _topic_overlap(a: str, b: str) -> bool:
    """Check if two texts are about the same topic."""
    words_a = set(a.split()[:20])
    words_b = set(b.split()[:20])
    overlap = words_a & words_b
    # If more than 30% of words overlap, probably same topic
    min_len = min(len(words_a), len(words_b))
    return len(overlap) / max(min_len, 1) > 0.3
