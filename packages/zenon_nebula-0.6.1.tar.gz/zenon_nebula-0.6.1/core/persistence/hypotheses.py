# SPDX-License-Identifier: MIT
"""
Hypothesis lifecycle: create, Bayesian confidence updates, finding resolution.

Owns:
- create_hypothesis
- _update_hypothesis_confidence: Bayesian posterior update
- get_hypothesis / get_all_evidence_for_hypothesis: read helpers
- resolve_finding / auto_resolve_findings: mark findings resolved
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime, timezone

from core.persistence.schema import (
    DEFAULT_DB,
    _get_connection,
    ensure_schema,
)

logger = logging.getLogger(__name__)


def create_hypothesis(
    db_path: str = DEFAULT_DB,
    hypothesis_id: str = "",
    domain: str = "system",
    title: str = "",
    confidence: float = 0.5,
    status: str = "INVESTIGATING",
) -> bool:
    """Create a hypothesis if it does not already exist.

    Args:
        db_path:        SQLite database path.
        hypothesis_id:  Deterministic ID (e.g. ``H_upstream_breaking_go-zenon``).
        domain:         Which domain owns this hypothesis.
        title:          Human-readable title.
        confidence:     Initial confidence (0.0-1.0, default 0.5).
        status:         Initial status (default INVESTIGATING).

    Returns:
        True if a new hypothesis was inserted, False if it already existed.
    """
    if not hypothesis_id:
        raise ValueError("hypothesis_id is required")

    conn = _get_connection(db_path)
    try:
        ensure_schema(db_path)
        existing = conn.execute(
            "SELECT id FROM hypotheses WHERE id = ?", (hypothesis_id,)
        ).fetchone()
        if existing:
            logger.debug("Hypothesis %s already exists, skipping creation", hypothesis_id)
            return False

        conn.execute(
            """INSERT INTO hypotheses (id, domain, title, confidence, status, last_updated)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                hypothesis_id,
                domain,
                title,
                confidence,
                status,
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        conn.commit()
        logger.info("Hypothesis created: id=%s domain=%s title=%s", hypothesis_id, domain, title)
        return True
    finally:
        conn.close()


def _update_hypothesis_confidence(
    conn: sqlite3.Connection,
    hypothesis_id: str,
    finding_confidence: float,
    direction: str,
) -> None:
    """Update hypothesis confidence based on new evidence using Bayesian update.

    Uses Bayesian update: new_confidence = prior * likelihood / normalizer
    For support: likelihood proportional to finding confidence
    For contradiction: likelihood inversely proportional
    """
    row = conn.execute(
        "SELECT confidence FROM hypotheses WHERE id = ?", (hypothesis_id,)
    ).fetchone()

    if not row:
        return

    prior = row[0]

    if direction == "support":
        # Bayesian update toward higher confidence
        likelihood = 0.5 + (finding_confidence * 0.4)  # 0.5 to 0.9
        posterior = (prior * likelihood) / (prior * likelihood + (1 - prior) * (1 - likelihood))
    else:
        # Bayesian update toward lower confidence
        likelihood = 0.5 - (finding_confidence * 0.4)  # 0.1 to 0.5
        posterior = (prior * likelihood) / (prior * likelihood + (1 - prior) * (1 - likelihood))

    # Clamp to [0.01, 0.99]
    posterior = max(0.01, min(0.99, posterior))

    evidence_for = json.dumps(
        [
            r[0]
            for r in conn.execute(
                "SELECT id FROM evidence WHERE supports_hypothesis = ?",
                (hypothesis_id,),
            ).fetchall()
        ]
    )

    evidence_against = json.dumps(
        [
            r[0]
            for r in conn.execute(
                "SELECT id FROM evidence WHERE contradicts_hypothesis = ?",
                (hypothesis_id,),
            ).fetchall()
        ]
    )

    conn.execute(
        """UPDATE hypotheses
        SET confidence = ?, last_updated = ?, evidence_for = ?, evidence_against = ?
        WHERE id = ?""",
        (
            round(posterior, 4),
            datetime.now(timezone.utc).isoformat(),
            evidence_for,
            evidence_against,
            hypothesis_id,
        ),
    )
    conn.commit()
    logger.info(
        "Hypothesis %s updated: %.2f -> %.2f (%s)",
        hypothesis_id,
        prior,
        posterior,
        direction,
    )


def get_hypothesis(db_path: str, hypothesis_id: str) -> dict | None:
    """Get a hypothesis by ID."""
    conn = _get_connection(db_path)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute("SELECT * FROM hypotheses WHERE id = ?", (hypothesis_id,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_all_evidence_for_hypothesis(db_path: str, hypothesis_id: str) -> list[dict]:
    """Get all evidence supporting or contradicting a hypothesis."""
    conn = _get_connection(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT * FROM evidence
            WHERE supports_hypothesis = ? OR contradicts_hypothesis = ?
            ORDER BY confidence DESC""",
            (hypothesis_id, hypothesis_id),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def resolve_finding(
    finding_id: int,
    resolved_by: str = "",
    related_finding_id: int | None = None,
    db_path: str = DEFAULT_DB,
) -> bool:
    """Mark a finding as resolved.

    Args:
        finding_id: ID of the finding to resolve
        resolved_by: What resolved it (commit hash, PR link, etc.)
        related_finding_id: ID of the finding that proves this is fixed
        db_path: SQLite database path

    Returns:
        True if updated, False if finding not found
    """
    conn = sqlite3.connect(db_path)
    try:
        # Link related findings
        related = None
        if related_finding_id:
            existing = conn.execute(
                "SELECT related_findings FROM evidence WHERE id = ?",
                (finding_id,),
            ).fetchone()
            if existing:
                current = existing[0] or "[]"
                try:
                    ids = json.loads(current)
                except (json.JSONDecodeError, TypeError):
                    ids = []
                ids.append(related_finding_id)
                related = json.dumps(ids)

        cursor = conn.execute(
            """UPDATE evidence
               SET status = 'resolved',
                   resolved_by = ?,
                   resolved_at = CURRENT_TIMESTAMP,
                   related_findings = COALESCE(?, related_findings)
               WHERE id = ?""",
            (resolved_by, related, finding_id),
        )
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()


def auto_resolve_findings(db_path: str = DEFAULT_DB) -> int:
    """Auto-resolve findings where a newer finding from the same engine shows the issue is fixed.

    For example: if Quality found "wrong address" and later found "address matches",
    the first finding should be auto-resolved.

    Returns count of findings resolved.
    """
    conn = sqlite3.connect(db_path)
    resolved = 0
    try:
        # Find pairs: same engine, same domain, one says "bug_found" and a later one says "verification"
        bugs = conn.execute(
            """SELECT id, domain, engine, finding FROM evidence
               WHERE evidence_type IN ('bug_found', 'mismatch', 'issue')
               AND status = 'open'"""
        ).fetchall()

        for bug in bugs:
            bug_id, domain, _engine, _finding = bug
            # Check if there's a newer verification from same domain
            fix = conn.execute(
                """SELECT id FROM evidence
                   WHERE domain = ? AND evidence_type IN ('verification', 'fix', 'resolved')
                   AND timestamp > (SELECT timestamp FROM evidence WHERE id = ?)
                   AND id != ?
                   LIMIT 1""",
                (domain, bug_id, bug_id),
            ).fetchone()

            if fix:
                conn.execute(
                    "UPDATE evidence SET status = 'resolved', resolved_by = 'auto_resolved', resolved_at = CURRENT_TIMESTAMP, related_findings = ? WHERE id = ?",
                    (json.dumps([fix[0]]), bug_id),
                )
                resolved += 1

        conn.commit()
    finally:
        conn.close()

    if resolved > 0:
        logger.info("Auto-resolved %d findings", resolved)
    return resolved


__all__ = [
    "_update_hypothesis_confidence",
    "auto_resolve_findings",
    "create_hypothesis",
    "get_all_evidence_for_hypothesis",
    "get_hypothesis",
    "resolve_finding",
]
