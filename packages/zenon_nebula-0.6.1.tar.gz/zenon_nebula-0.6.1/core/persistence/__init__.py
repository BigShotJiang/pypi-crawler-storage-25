# SPDX-License-Identifier: MIT
"""
core.persistence — split of the former core.persist_to_db god file.

Submodules:
- schema:     SCHEMA_SQL DDL, ensure_schema(), maintain_db(), _get_connection()
- findings:   persist_finding(), classify_provenance, finding read helpers
- hypotheses: create_hypothesis(), Bayesian updates, resolve helpers
- metrics:    persist_metric(), query_table(), persist_cost(),
              persist_action(), persist_ecosystem_event()

The top-level ``core.persist_to_db`` module is a thin shim that re-exports
everything from this package so legacy imports continue to work unchanged.
"""

from core.persistence.findings import (
    classify_provenance,
    get_findings_by_domain,
    get_findings_by_engine,
    persist_finding,
)
from core.persistence.hypotheses import (
    _update_hypothesis_confidence,
    auto_resolve_findings,
    create_hypothesis,
    get_all_evidence_for_hypothesis,
    get_hypothesis,
    resolve_finding,
)
from core.persistence.metrics import (
    persist_action,
    persist_cost,
    persist_ecosystem_event,
    persist_metric,
    query_table,
)
from core.persistence.schema import (
    _SCHEMA_APPLIED,
    DEFAULT_DB,
    SCHEMA_SQL,
    _get_connection,
    connect,
    ensure_schema,
    maintain_db,
)

__all__ = [
    "DEFAULT_DB",
    # schema
    "SCHEMA_SQL",
    "_SCHEMA_APPLIED",
    "_get_connection",
    "_update_hypothesis_confidence",
    "auto_resolve_findings",
    # findings
    "classify_provenance",
    # canonical connection helper (use this — never bare sqlite3.connect)
    "connect",
    # hypotheses
    "create_hypothesis",
    "ensure_schema",
    "get_all_evidence_for_hypothesis",
    "get_findings_by_domain",
    "get_findings_by_engine",
    "get_hypothesis",
    "maintain_db",
    # metrics
    "persist_action",
    "persist_cost",
    "persist_ecosystem_event",
    "persist_finding",
    "persist_metric",
    "query_table",
    "resolve_finding",
]
