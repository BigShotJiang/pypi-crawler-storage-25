# SPDX-License-Identifier: MIT
"""
Generic metric, action, cost, and event persistence helpers.

Owns:
- persist_metric: generic dict -> INSERT for any table
- query_table: generic SELECT helper
- persist_action: transparency log for engine actions
- persist_cost: LLM API cost tracking
- persist_ecosystem_event: GitHub commits, forum posts, etc.
"""

from __future__ import annotations

import json
import logging
import sqlite3

from core.persistence.schema import (
    DEFAULT_DB,
    _get_connection,
    ensure_schema,
)

logger = logging.getLogger(__name__)


def persist_action(
    db_path: str = DEFAULT_DB,
    domain: str = "system",
    module: str = "",
    action: str = "",
    target: str | None = None,
    result: str | None = None,
    cost_usd: float = 0.0,
    tokens_used: int = 0,
    model: str | None = None,
    error: str | None = None,
) -> int:
    """Log an action to the transparency log.

    Returns:
        Row ID of the inserted action.
    """
    conn = _get_connection(db_path)
    try:
        ensure_schema(db_path)
        cursor = conn.execute(
            """INSERT INTO actions_log
            (domain, module, action, target, result, cost_usd,
             tokens_used, model, error)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (domain, module, action, target, result, cost_usd, tokens_used, model, error),
        )
        conn.commit()
        return cursor.lastrowid
    finally:
        conn.close()


def persist_ecosystem_event(
    db_path: str = DEFAULT_DB,
    domain: str = "system",
    event_type: str = "",
    source: str = "",
    details: str = "",
    commit_hash: str | None = None,
    narrative_angle: str | None = None,
) -> int:
    """Persist an ecosystem event (GitHub commit, forum post, etc.)."""
    conn = _get_connection(db_path)
    try:
        ensure_schema(db_path)
        cursor = conn.execute(
            """INSERT INTO ecosystem_events
            (domain, event_type, source, details, commit_hash, narrative_angle)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (domain, event_type, source, details, commit_hash, narrative_angle),
        )
        conn.commit()
        row_id = cursor.lastrowid
        logger.info(
            "Ecosystem event: domain=%s type=%s source=%s id=%d", domain, event_type, source, row_id
        )
        return row_id
    finally:
        conn.close()


def persist_cost(
    db_path: str = DEFAULT_DB,
    domain: str = "system",
    provider: str = "xai",
    model: str = "",
    module: str = "",
    tokens_input: int = 0,
    tokens_output: int = 0,
    cost_usd: float = 0.0,
    task_type: str = "",
) -> None:
    """Persist an LLM API call cost to the cost_tracking table."""
    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            """INSERT INTO cost_tracking
               (domain, provider, model, module, tokens_input, tokens_output, cost_usd, task_type)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (domain, provider, model, module, tokens_input, tokens_output, cost_usd, task_type),
        )
        conn.commit()
    finally:
        conn.close()


def persist_metric(
    db_path: str = DEFAULT_DB,
    table: str = "",
    data: dict | None = None,
) -> int:
    """Generic metric persistence — INSERT dict into named table.

    Safer than raw ``sqlite3.connect`` in engines — enforces schema
    bootstrap, error handling, and connection management. All engine
    writes should go through this (or a more specific helper) rather
    than opening raw connections.

    Dict and list values are auto-serialized to JSON strings before
    insertion, matching the convention used elsewhere in this module.

    Args:
        db_path: Database path.
        table:   Target table name (must exist in schema).
        data:    Dict of column_name -> value to insert.

    Returns:
        Row ID of the inserted record, or -1 on error.
    """
    if not data or not table:
        return -1

    ensure_schema(db_path)
    conn = _get_connection(db_path)
    try:
        columns = list(data.keys())
        placeholders = ["?"] * len(columns)
        values = [json.dumps(v) if isinstance(v, (dict, list)) else v for v in data.values()]

        sql = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({', '.join(placeholders)})"
        cursor = conn.execute(sql, values)
        conn.commit()
        return cursor.lastrowid if cursor.lastrowid is not None else -1
    except sqlite3.OperationalError as exc:
        logger.warning(
            "persist_metric to %s failed: %s (data keys: %s)",
            table,
            exc,
            list(data.keys()),
        )
        return -1
    except sqlite3.IntegrityError as exc:
        logger.debug(
            "persist_metric to %s integrity error: %s (data keys: %s)",
            table,
            exc,
            list(data.keys()),
        )
        return -1
    finally:
        conn.close()


def query_table(
    db_path: str = DEFAULT_DB,
    table: str = "",
    where: str = "",
    params: tuple = (),
    order_by: str = "",
    limit: int = 100,
) -> list[dict]:
    """Generic read helper — SELECT from named table with filters.

    Returns list of dicts for easy consumption by engines. Silently
    returns an empty list if the table does not exist or the query
    fails — engines should treat missing data as "no data" rather
    than an error.

    Args:
        db_path:  Database path.
        table:    Source table name.
        where:    Optional WHERE clause body (without the keyword).
        params:   Parameters for the WHERE clause placeholders.
        order_by: Optional ORDER BY clause body (without the keyword).
        limit:    Row limit (0 for no limit).
    """
    if not table:
        return []

    conn = _get_connection(db_path)
    conn.row_factory = sqlite3.Row
    try:
        sql = f"SELECT * FROM {table}"
        if where:
            sql += f" WHERE {where}"
        if order_by:
            sql += f" ORDER BY {order_by}"
        if limit:
            sql += f" LIMIT {int(limit)}"

        return [dict(r) for r in conn.execute(sql, params).fetchall()]
    except sqlite3.OperationalError as exc:
        logger.warning("query_table from %s failed: %s", table, exc)
        return []
    finally:
        conn.close()


__all__ = [
    "persist_action",
    "persist_cost",
    "persist_ecosystem_event",
    "persist_metric",
    "query_table",
]
