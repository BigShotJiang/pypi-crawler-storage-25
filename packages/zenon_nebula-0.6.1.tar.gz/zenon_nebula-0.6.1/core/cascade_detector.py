# SPDX-License-Identifier: MIT
"""
CascadeDetector -- Detect when a hypothesis is accelerating.

Tracks metric time series and detects cascades: when metric A moving
causes metric B to follow with a time lag. Emits a "flywheel" signal
when 2+ domains are accelerating simultaneously.

Generalized from marketing's cascade_detector. Domain-agnostic: works
with any metric source registered via add_metric_source().

Reads:  evidence table, feedback_bus
Writes: cascade_patterns table, feedback_bus
"""

import json
import logging
import sqlite3
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class MetricTimeSeries:
    """A time series of metric observations."""

    metric_id: str
    label: str
    timestamps: list[datetime] = field(default_factory=list)
    values: list[float] = field(default_factory=list)

    @property
    def length(self) -> int:
        """Number of observations in the time series."""
        return len(self.values)


@dataclass
class CascadeResult:
    """Result of a cascade correlation analysis."""

    hypothesis_id: str
    cause_metric: str
    effect_metric: str
    best_lag_hours: float
    correlation: float
    p_value: float
    significant: bool
    description: str
    action_recommendation: str = ""


@dataclass
class CascadeHypothesis:
    """A hypothesis about a causal relationship between two metrics."""

    id: str
    cause: str
    effect: str
    expected_lag_hours: float
    lag_range: tuple[int, int]
    description: str
    min_correlation: float = 0.4


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS cascade_patterns (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    hypothesis_id   TEXT NOT NULL,
    cause_metric    TEXT NOT NULL,
    effect_metric   TEXT NOT NULL,
    best_lag_hours  REAL,
    correlation     REAL,
    p_value         REAL,
    significant     INTEGER DEFAULT 0,
    description     TEXT,
    recommendation  TEXT,
    raw_data        TEXT
);
CREATE INDEX IF NOT EXISTS idx_cascade_hypothesis
    ON cascade_patterns(hypothesis_id);
"""

# Exposed at module level so core.schema_registry applies the table
# even if CascadeDetector is never instantiated before the first write.
SCHEMA_SQL = _CREATE_TABLE_SQL


def _ensure_tables(db_path: str) -> None:
    """Create cascade_patterns table if not present."""
    conn = connect(db_path)
    try:
        # executescript handles the multi-statement DDL above
        # (CREATE TABLE + CREATE INDEX).
        conn.executescript(_CREATE_TABLE_SQL)
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# CascadeDetector
# ---------------------------------------------------------------------------


class CascadeDetector:
    """Detect metric cascades and flywheel patterns across domains.

    Register metric loaders via :meth:`register_metric`, define cascade
    hypotheses via :meth:`add_hypothesis`, then call :meth:`detect_all`
    to test all hypotheses.

    When 2+ domains show simultaneous acceleration, emits a "flywheel"
    signal on the feedback bus.
    """

    def __init__(self, db_path: str = DEFAULT_DB) -> None:
        self.db_path = db_path
        self._metric_loaders: dict[str, Callable[..., MetricTimeSeries]] = {}
        self._hypotheses: list[CascadeHypothesis] = []
        _ensure_tables(db_path)

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register_metric(
        self,
        metric_id: str,
        loader: Callable[..., MetricTimeSeries],
    ) -> None:
        """Register a metric loader function.

        The loader should accept ``(metric_id: str, days: int)``
        and return a :class:`MetricTimeSeries`.
        """
        self._metric_loaders[metric_id] = loader
        logger.debug("Registered metric loader: %s", metric_id)

    def add_hypothesis(self, hypothesis: CascadeHypothesis) -> None:
        """Add a cascade hypothesis to test."""
        self._hypotheses.append(hypothesis)

    # ------------------------------------------------------------------
    # Metric loading
    # ------------------------------------------------------------------

    def load_metric(self, metric_id: str, days: int = 90) -> MetricTimeSeries:
        """Load a metric using its registered loader."""
        loader = self._metric_loaders.get(metric_id)
        if loader is None:
            logger.warning("No loader registered for metric: %s", metric_id)
            return MetricTimeSeries(metric_id=metric_id, label=metric_id)
        try:
            return loader(metric_id, days)
        except Exception as exc:
            logger.error("Metric loader for %s failed: %s", metric_id, exc)
            return MetricTimeSeries(metric_id=metric_id, label=metric_id)

    def load_metric_from_evidence(
        self,
        metric_id: str,
        days: int = 90,
        evidence_type_filter: str | None = None,
    ) -> MetricTimeSeries:
        """Load a metric from the evidence table confidence values.

        Useful as a generic loader for any domain -- counts high-confidence
        evidence per day as a proxy for domain acceleration.
        """
        series = MetricTimeSeries(metric_id=metric_id, label=metric_id)
        try:
            conn = connect(self.db_path)
            cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

            query = """
                SELECT date(timestamp) AS day,
                       COUNT(*) AS cnt,
                       AVG(confidence) AS avg_conf
                FROM evidence
                WHERE timestamp > ?
            """
            params: list = [cutoff]
            if evidence_type_filter:
                query += " AND evidence_type = ?"
                params.append(evidence_type_filter)
            query += " GROUP BY day ORDER BY day ASC"

            rows = conn.execute(query, params).fetchall()
            conn.close()

            for day_str, count, avg_conf in rows:
                ts = datetime.strptime(day_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
                series.timestamps.append(ts)
                series.values.append(float(count) * float(avg_conf or 0.5))
        except sqlite3.Error as exc:
            logger.warning("Could not load evidence metric %s: %s", metric_id, exc)

        return series

    # ------------------------------------------------------------------
    # Correlation analysis
    # ------------------------------------------------------------------

    def compute_lagged_correlation(
        self,
        cause: MetricTimeSeries,
        effect: MetricTimeSeries,
        lag_range_hours: tuple[int, int] = (0, 168),
        step_hours: int = 6,
    ) -> tuple[float, float, float]:
        """Compute correlation between cause and effect with time lag.

        Tests multiple lag values and returns the best correlation.

        Returns:
            Tuple of (best_lag_hours, best_correlation, p_value).
        """
        try:
            import numpy as np
        except ImportError:
            logger.error("numpy required for cascade detection")
            return (0.0, 0.0, 1.0)

        if cause.length < 5 or effect.length < 5:
            return (0.0, 0.0, 1.0)

        cause_daily = self._resample_daily(cause)
        effect_daily = self._resample_daily(effect)

        common_dates = sorted(set(cause_daily.keys()) & set(effect_daily.keys()))
        if len(common_dates) < 5:
            return (0.0, 0.0, 1.0)

        cause_values = np.array([cause_daily[d] for d in common_dates])
        effect_values = np.array([effect_daily[d] for d in common_dates])

        cause_norm = (cause_values - cause_values.mean()) / (cause_values.std() + 1e-10)
        effect_norm = (effect_values - effect_values.mean()) / (effect_values.std() + 1e-10)

        best_lag = 0.0
        best_corr = 0.0
        best_p = 1.0

        min_lag_days = lag_range_hours[0] // 24
        max_lag_days = lag_range_hours[1] // 24 + 1
        step_days = max(step_hours // 24, 1)

        for lag_days in range(min_lag_days, max_lag_days, step_days):
            if lag_days >= len(cause_norm):
                break

            if lag_days == 0:
                c, e = cause_norm, effect_norm
            else:
                c = cause_norm[:-lag_days] if lag_days < len(cause_norm) else cause_norm[:1]
                e = effect_norm[lag_days:]

            n = min(len(c), len(e))
            if n < 5:
                continue

            c, e = c[:n], e[:n]
            corr = float(np.corrcoef(c, e)[0, 1])
            if np.isnan(corr):
                continue

            t_stat = corr * np.sqrt((n - 2) / (1 - corr**2 + 1e-10))
            p_value = 2.0 * (1.0 - min(0.9999, abs(t_stat) / (abs(t_stat) + n)))

            if abs(corr) > abs(best_corr):
                best_lag = lag_days * 24.0
                best_corr = corr
                best_p = float(p_value)

        return (best_lag, best_corr, best_p)

    @staticmethod
    def _resample_daily(series: MetricTimeSeries) -> dict[str, float]:
        """Resample a time series to daily resolution (average per day)."""
        daily: dict[str, list[float]] = {}
        for ts, val in zip(series.timestamps, series.values, strict=False):
            day = ts.strftime("%Y-%m-%d")
            daily.setdefault(day, []).append(val)
        return {day: sum(vals) / len(vals) for day, vals in daily.items()}

    # ------------------------------------------------------------------
    # Cascade detection
    # ------------------------------------------------------------------

    def detect_cascade(self, hypothesis: CascadeHypothesis) -> CascadeResult:
        """Test a single cascade hypothesis."""
        cause_series = self.load_metric(hypothesis.cause)
        effect_series = self.load_metric(hypothesis.effect)

        best_lag, corr, p_value = self.compute_lagged_correlation(
            cause_series,
            effect_series,
            lag_range_hours=hypothesis.lag_range,
        )

        significant = abs(corr) >= hypothesis.min_correlation and p_value < 0.1

        return CascadeResult(
            hypothesis_id=hypothesis.id,
            cause_metric=hypothesis.cause,
            effect_metric=hypothesis.effect,
            best_lag_hours=best_lag,
            correlation=round(corr, 4),
            p_value=round(p_value, 6),
            significant=significant,
            description=hypothesis.description,
        )

    def detect_all(self) -> list[CascadeResult]:
        """Test all cascade hypotheses.

        If 2+ significant cascades are detected from different domains,
        emits a "flywheel" signal via the feedback bus.

        Returns:
            List of CascadeResult for each hypothesis.
        """
        results = []
        for hypothesis in self._hypotheses:
            try:
                result = self.detect_cascade(hypothesis)
                results.append(result)
                self._persist_cascade(result)

                if result.significant:
                    logger.info(
                        "CASCADE DETECTED: %s -> %s (r=%.3f, lag=%.0fh)",
                        result.cause_metric,
                        result.effect_metric,
                        result.correlation,
                        result.best_lag_hours,
                    )
            except Exception as exc:
                logger.error("Cascade test '%s' failed: %s", hypothesis.id, exc)

        # Flywheel detection: 2+ significant cascades
        significant = [r for r in results if r.significant]
        if len(significant) >= 2:
            self._emit_flywheel(significant)

        logger.info(
            "Cascade analysis complete: %d/%d significant",
            len(significant),
            len(results),
        )
        return results

    # ------------------------------------------------------------------
    # Flywheel detection
    # ------------------------------------------------------------------

    def _emit_flywheel(self, significant: list[CascadeResult]) -> None:
        """Emit a flywheel signal when multiple cascades fire simultaneously."""
        try:
            from core.feedback_bus import FeedbackBus

            bus = FeedbackBus(db_path=self.db_path)
            bus.post(
                sender="cascade_detector",
                recipient="all",
                message_type="breakthrough",
                data={
                    "event": "flywheel_detected",
                    "cascades": [
                        {
                            "cause": r.cause_metric,
                            "effect": r.effect_metric,
                            "correlation": r.correlation,
                            "lag_hours": r.best_lag_hours,
                        }
                        for r in significant
                    ],
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )
            logger.info(
                "FLYWHEEL SIGNAL: %d simultaneous cascades detected",
                len(significant),
            )
        except Exception as exc:
            logger.debug("Could not emit flywheel signal: %s", exc)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _persist_cascade(self, result: CascadeResult) -> None:
        """Store cascade analysis result in the database."""
        try:
            conn = connect(self.db_path)
            conn.execute(
                """INSERT INTO cascade_patterns
                   (hypothesis_id, cause_metric, effect_metric, best_lag_hours,
                    correlation, p_value, significant, description, recommendation, raw_data)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    result.hypothesis_id,
                    result.cause_metric,
                    result.effect_metric,
                    result.best_lag_hours,
                    result.correlation,
                    result.p_value,
                    1 if result.significant else 0,
                    result.description,
                    result.action_recommendation,
                    json.dumps(
                        {
                            "hypothesis_id": result.hypothesis_id,
                            "correlation": result.correlation,
                            "lag_hours": result.best_lag_hours,
                            "p_value": result.p_value,
                        }
                    ),
                ),
            )
            conn.commit()
            conn.close()
        except sqlite3.Error as exc:
            logger.warning("Failed to persist cascade: %s", exc)

    # ------------------------------------------------------------------
    # Reporting
    # ------------------------------------------------------------------

    def get_cascade_report(self) -> dict:
        """Generate a summary report of all detected cascades."""
        try:
            conn = connect(self.db_path)
            rows = conn.execute(
                """SELECT hypothesis_id, cause_metric, effect_metric,
                          best_lag_hours, correlation, p_value, significant,
                          description, recommendation, ts
                   FROM cascade_patterns
                   ORDER BY ts DESC LIMIT 50""",
            ).fetchall()
            conn.close()
        except sqlite3.Error:
            rows = []

        patterns = []
        for row in rows:
            patterns.append(
                {
                    "hypothesis_id": row[0],
                    "cause": row[1],
                    "effect": row[2],
                    "lag_hours": row[3],
                    "correlation": row[4],
                    "p_value": row[5],
                    "significant": bool(row[6]),
                    "description": row[7],
                    "recommendation": row[8],
                    "detected_at": row[9],
                }
            )

        significant = [p for p in patterns if p["significant"]]

        return {
            "total_tested": len(patterns),
            "significant_cascades": len(significant),
            "patterns": significant,
            "all_patterns": patterns,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
