# SPDX-License-Identifier: MIT
"""
Red Team — The adversary within. Challenges every conclusion Nebula reaches.

Ported from marketing repo's engine9_redteam/hypothesis_challenger.py,
generalized to challenge ALL domains, not just investigation hypotheses.

What it does:
  - Takes every hypothesis above a confidence threshold and tries to disprove it
  - For every collision (multi-domain convergence), asks: coincidence or real?
  - For every War Room recommendation, asks: what could go wrong?
  - For every Director aspiration, asks: is this actually the priority?
  - Generates contradiction evidence that LOWERS confidence where warranted

Why it matters:
  Without a red team, Nebula develops confirmation bias. Evidence accumulates,
  confidence rises, and nobody asks "but what if we're wrong?" The red team
  is that question, asked systematically, every cycle.

The red team doesn't need to be right. It needs to make the system PROVE
its conclusions are robust. Findings that survive red team challenge are
genuinely strong. Findings that crumble were never reliable.
"""

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ENGINE_ROOT / "data" / "engine.db"

# Confidence threshold: only challenge findings above this level
# Below this, evidence is too weak to bother challenging
CHALLENGE_THRESHOLD = 0.50

# Maximum contradictions per cycle (avoid overwhelming the system)
MAX_CHALLENGES_PER_CYCLE = 10


def _persist_challenge(conn, hyp: dict, strength: str, text: str) -> None:
    """Persist a moderate/strong challenge as contradiction evidence and lower confidence."""
    if strength not in ("MODERATE", "STRONG"):
        return
    penalty = 0.05 if strength == "MODERATE" else 0.10
    conn.execute(
        """INSERT INTO evidence (domain, engine, evidence_type, finding, confidence,
           contradicts_hypothesis) VALUES (?, ?, ?, ?, ?, ?)""",
        (
            "system",
            "red_team",
            "contradiction",
            f"Red team challenge: {text[:500]}",
            penalty,
            hyp["id"],
        ),
    )
    new_conf = max(0.01, hyp["confidence"] - penalty)
    conn.execute(
        "UPDATE hypotheses SET confidence = ? WHERE id = ?",
        (new_conf, hyp["id"]),
    )
    logger.info(
        "Red team lowered %s from %.0f%% to %.0f%% (%s challenge)",
        hyp["id"],
        hyp["confidence"] * 100,
        new_conf * 100,
        strength,
    )


def challenge_hypotheses(db_path: str = str(DB_PATH), llm_call=None) -> list:
    """Challenge every hypothesis above the confidence threshold.

    For each hypothesis:
    1. Gather all supporting evidence
    2. Ask LLM: "What are the strongest arguments AGAINST this hypothesis?"
    3. If LLM finds compelling counter-arguments, create contradiction evidence
    4. Confidence drops via Bayesian update

    Args:
        db_path: SQLite database path
        llm_call: Callable for LLM reasoning (injectable for testing)

    Returns:
        List of challenges generated
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row

    hypotheses = conn.execute(
        "SELECT id, domain, title, confidence FROM hypotheses WHERE confidence >= ?",
        (CHALLENGE_THRESHOLD,),
    ).fetchall()

    challenges = []

    for hyp in hypotheses:
        # Gather supporting evidence
        support = conn.execute(
            "SELECT finding, confidence FROM evidence WHERE supports_hypothesis = ? ORDER BY confidence DESC LIMIT 10",
            (hyp["id"],),
        ).fetchall()

        if not support:
            continue

        evidence_summary = "\n".join(
            f"- [{r['confidence']:.0%}] {r['finding'][:200]}" for r in support
        )

        if llm_call:
            prompt = (
                f"HYPOTHESIS: {hyp['title']} (current confidence: {hyp['confidence']:.0%})\n\n"
                f"SUPPORTING EVIDENCE:\n{evidence_summary}\n\n"
                f"YOUR TASK: You are the RED TEAM. Your job is to challenge this hypothesis.\n"
                f"1. What are the 3 strongest arguments AGAINST this hypothesis?\n"
                f"2. What alternative explanations fit the same evidence?\n"
                f"3. What evidence would DISPROVE this hypothesis?\n"
                f"4. Rate your challenge strength: WEAK (hypothesis is solid), "
                f"MODERATE (some doubts), STRONG (hypothesis is likely wrong)\n\n"
                f"Be intellectually honest. If the evidence is genuinely strong, say so. "
                f"Don't manufacture doubt for its own sake."
            )

            try:
                response = llm_call(prompt, system="You are a rigorous scientific skeptic.")
                text = response if isinstance(response, str) else response.get("text", "")
                challenge_strength = _assess_challenge_strength(text)

                challenges.append(
                    {
                        "hypothesis_id": hyp["id"],
                        "hypothesis_title": hyp["title"],
                        "confidence_before": hyp["confidence"],
                        "challenge": text[:2000],
                        "strength": challenge_strength,
                        "domain": hyp["domain"],
                    }
                )

                # Persist as contradiction evidence if challenge is moderate+
                _persist_challenge(conn, hyp, challenge_strength, text)

            except Exception as e:
                logger.warning("Red team challenge failed for %s: %s", hyp["id"], e)

        if len(challenges) >= MAX_CHALLENGES_PER_CYCLE:
            break

    conn.commit()
    conn.close()

    logger.info("Red team: %d hypotheses challenged", len(challenges))
    return challenges


def challenge_collisions(db_path: str = str(DB_PATH), llm_call=None) -> list:
    """Challenge high-confidence collisions.

    When multiple domains converge on the same finding, the collision
    engine marks it as strong evidence. But convergence could be:
    - Real signal (domains independently found the same truth)
    - Shared bias (all domains reading the same flawed source)
    - Coincidence (unrelated findings that look similar)

    The red team asks: which is it?
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row

    collisions = conn.execute(
        "SELECT * FROM collisions WHERE resolved = 0 AND confidence >= ? ORDER BY confidence DESC LIMIT 5",
        (0.80,),
    ).fetchall()

    challenges = []

    for col in collisions:
        if llm_call:
            prompt = (
                f"COLLISION DETECTED: {col['title']}\n"
                f"Confidence: {col['confidence']:.0%}\n"
                f"Domains: {col['domains_involved']}\n"
                f"Engines: {col['engines_involved']}\n\n"
                f"Three possibilities:\n"
                f"1. REAL: Independent domains genuinely found the same truth\n"
                f"2. BIAS: All domains are reading the same flawed data source\n"
                f"3. COINCIDENCE: Unrelated findings that superficially look similar\n\n"
                f"Which is most likely, and why? Be specific."
            )

            try:
                response = llm_call(prompt, system="You are a rigorous analyst.")
                text = response if isinstance(response, str) else response.get("text", "")
                challenges.append(
                    {
                        "collision_id": col["id"],
                        "title": col["title"],
                        "challenge": text[:1000],
                    }
                )
            except Exception as e:
                logger.warning("Red team collision challenge failed: %s", e)

    conn.close()
    return challenges


def challenge_battle_plan(plan: dict, llm_call=None) -> dict | None:
    """Challenge the War Room's battle plan before it's acted on.

    Asks: What could go wrong if we follow this plan?
    What are we ignoring? What assumptions might be wrong?
    """
    if not plan or not llm_call:
        return None

    focus = plan.get("battle_plan_24h", plan.get("focus", ""))
    assessment = plan.get("situation_assessment", "")

    prompt = (
        f"BATTLE PLAN:\n{json.dumps(focus, indent=2, default=str)[:1500]}\n\n"
        f"SITUATION:\n{assessment[:500]}\n\n"
        f"RED TEAM CHALLENGE:\n"
        f"1. What could go WRONG if we follow this plan?\n"
        f"2. What important thing is this plan IGNORING?\n"
        f"3. What assumption in this plan might be WRONG?\n"
        f"4. Is there a simpler approach that would work better?\n"
    )

    try:
        response = llm_call(prompt, system="You are a strategic adversary reviewing a battle plan.")
        text = response if isinstance(response, str) else response.get("text", "")
        return {
            "challenge": text[:2000],
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.warning("Red team plan challenge failed: %s", e)
        return None


def run_red_team_cycle(db_path: str = str(DB_PATH), llm_call=None) -> dict:
    """Run a complete red team cycle.

    Called by the autonomous runner after the War Room produces a plan.
    Challenges hypotheses, collisions, and the battle plan.
    """
    results = {
        "hypothesis_challenges": [],
        "collision_challenges": [],
        "plan_challenge": None,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    # Challenge hypotheses
    results["hypothesis_challenges"] = challenge_hypotheses(db_path, llm_call)

    # Challenge collisions
    results["collision_challenges"] = challenge_collisions(db_path, llm_call)

    # Challenge the latest battle plan
    conn = connect(db_path)
    plan_row = conn.execute(
        "SELECT raw_plan FROM battle_plans ORDER BY timestamp DESC LIMIT 1"
    ).fetchone()
    conn.close()

    if plan_row and plan_row[0]:
        try:
            plan = json.loads(plan_row[0])
            results["plan_challenge"] = challenge_battle_plan(plan, llm_call)
        except json.JSONDecodeError:
            pass

    total = (
        len(results["hypothesis_challenges"])
        + len(results["collision_challenges"])
        + (1 if results["plan_challenge"] else 0)
    )
    logger.info("Red team cycle complete: %d total challenges", total)

    return results


def _assess_challenge_strength(text: str) -> str:
    """Determine challenge strength from LLM response."""
    text_lower = text.lower()
    if "strong" in text_lower and "challenge" in text_lower:
        return "STRONG"
    if "hypothesis is likely wrong" in text_lower:
        return "STRONG"
    if "moderate" in text_lower:
        return "MODERATE"
    if "some doubts" in text_lower or "alternative" in text_lower:
        return "MODERATE"
    if "weak" in text_lower and "solid" in text_lower:
        return "WEAK"
    if "evidence is strong" in text_lower or "hypothesis holds" in text_lower:
        return "WEAK"
    # Default to moderate if unclear
    return "MODERATE"
