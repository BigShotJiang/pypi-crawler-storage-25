# SPDX-License-Identifier: MIT
"""
Legacy module — all functionality moved to the ``core.persistence`` package.

This file exists purely as a backward-compatibility shim so that existing
``from core.persist_to_db import X`` calls continue to resolve unchanged.

The implementation lives in:
- core.persistence.schema     — SCHEMA_SQL, ensure_schema, maintain_db, _get_connection
- core.persistence.findings   — persist_finding, classify_provenance, finding queries
- core.persistence.hypotheses — create_hypothesis, Bayesian updates, resolve helpers
- core.persistence.metrics    — persist_metric, query_table, persist_cost, persist_action,
                                persist_ecosystem_event
"""

from core.persistence.findings import (
    classify_provenance,
    get_findings_by_domain,
    get_findings_by_engine,
    persist_finding,
)
from core.persistence.hypotheses import (
    _update_hypothesis_confidence,
    auto_resolve_findings,
    create_hypothesis,
    get_all_evidence_for_hypothesis,
    get_hypothesis,
    resolve_finding,
)
from core.persistence.metrics import (
    persist_action,
    persist_cost,
    persist_ecosystem_event,
    persist_metric,
    query_table,
)
from core.persistence.schema import (
    _SCHEMA_APPLIED,
    DEFAULT_DB,
    SCHEMA_SQL,
    _get_connection,
    ensure_schema,
    maintain_db,
)

__all__ = [
    "DEFAULT_DB",
    # schema
    "SCHEMA_SQL",
    "_SCHEMA_APPLIED",
    "_get_connection",
    "_update_hypothesis_confidence",
    "auto_resolve_findings",
    # findings
    "classify_provenance",
    # hypotheses
    "create_hypothesis",
    "ensure_schema",
    "get_all_evidence_for_hypothesis",
    "get_findings_by_domain",
    "get_findings_by_engine",
    "get_hypothesis",
    "maintain_db",
    # metrics
    "persist_action",
    "persist_cost",
    "persist_ecosystem_event",
    "persist_finding",
    "persist_metric",
    "query_table",
    "resolve_finding",
]
