# SPDX-License-Identifier: MIT
"""
ModelRouter -- Routes task types to optimal LLM models.

**Agent pattern:** *routing* (Anthropic "Building Effective Agents"
taxonomy). A cheap up-front classifier (rules-based in our case) maps
each request to a model tier. Nebula is xAI-only, so all tiers resolve
to Grok variants; the router exists to keep callers from hardcoding a
model ID -- a rule enforced by ``.claude/rules/anti-hallucination.md``.

Reads configuration from ``config/model_routing.json``.

Phase 13 adds an *executor-advisor* escalation path on top of the
router via :func:`call_with_escalation`: the executor runs the call
at the cheap tier and, when the output fails a caller-supplied
plausibility check, the advisor re-runs it at a heavier tier with
the executor's attempt included in the prompt. Adapted from
Anthropic's Advisor Strategy (see
``docs/decisions/0009-executor-advisor-pattern.md``) to xAI-only
Nebula. The executor-advisor loop keeps the mean cost low while
preserving a high-quality path for cases the cheap tier can't
handle.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from core.config import get_config

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]

_config: dict | None = None


def _load_config() -> dict:
    """Load model routing configuration via the central config loader.

    Retained as a module-level cache so existing tests that poke
    ``router_mod._config`` continue to work. The authoritative source is
    ``core.config.get_config().routing``.
    """
    global _config
    if _config is None:
        _config = get_config().routing or {"routes": {}, "defaults": {}}
    return _config


def get_model(task: str) -> str:
    """Get the model ID for a task type.

    Args:
        task: Task type key matching a route in model_routing.json.
              Examples: "strategic_synthesis", "content_generation",
              "classification", "x_search", "investigation".

    Returns:
        Model ID string (e.g. "grok-4.20-0309-reasoning").
    """
    config = _load_config()
    route = config.get("routes", {}).get(task, {})
    return route.get(
        "model", config.get("defaults", {}).get("fallback_model", "grok-4.20-0309-non-reasoning")
    )


def get_max_tokens(task: str) -> int:
    """Get the max tokens setting for a task type."""
    config = _load_config()
    route = config.get("routes", {}).get(task, {})
    return route.get("max_tokens", 4000)


def get_route_info(task: str) -> dict:
    """Get full route info for a task type including cost data."""
    config = _load_config()
    return config.get("routes", {}).get(task, {})


def get_all_routes() -> dict:
    """Get all configured routes."""
    config = _load_config()
    return config.get("routes", {})


# -- Convenience methods for common model tiers --


def get_strategic_model() -> str:
    """Claude Opus for strategic/synthesis -- highest quality."""
    return get_model("strategic_synthesis")


def get_workhorse_model() -> str:
    """Claude Sonnet for content/research -- best cost/quality."""
    return get_model("content_generation")


def get_fast_model() -> str:
    """Cheapest capable model -- Grok fast for classification."""
    return get_model("x_search")


def get_cheap_claude() -> str:
    """Cheapest Claude model -- Haiku for classification."""
    return get_model("classification")


def get_grok_fast() -> str:
    """Grok fast reasoning -- cheapest for X search and monitoring."""
    return get_model("x_search")


def get_grok_fast_no_reasoning() -> str:
    """Grok fast without reasoning -- for simple classification."""
    return get_model("fast_classification")


def get_grok_heavy() -> str:
    """Grok heavy reasoning -- cheaper than Opus for deep analysis."""
    return get_model("deep_analysis")


def get_investigation_model() -> str:
    """Model for deep investigation -- 1M context, best reasoning."""
    return get_model("investigation")


def get_validation_model() -> str:
    """Model for evidence validation and fact-checking."""
    return get_model("validation")


def estimate_cost(task: str, input_tokens: int, output_tokens: int) -> float:
    """Estimate the cost of an API call in USD.

    Args:
        task: Task type key.
        input_tokens: Estimated input token count.
        output_tokens: Estimated output token count.

    Returns:
        Estimated cost in USD.
    """
    config = _load_config()
    route = config.get("routes", {}).get(task, {})
    input_cost = route.get("cost_per_mtok_input", 3.0)
    output_cost = route.get("cost_per_mtok_output", 15.0)
    return (input_tokens * input_cost + output_tokens * output_cost) / 1_000_000


def reload_config() -> None:
    """Force reload of config from disk (useful after config changes)."""
    global _config
    _config = None
    # Invalidate the central cache too so both views stay in sync.
    try:
        from core import config as _cfg_mod

        _cfg_mod.reload_config()
    except ImportError as exc:
        logger.debug("central config reload skipped: %s", exc)
    _load_config()


# ---------------------------------------------------------------------------
# Executor-advisor escalation (Phase 13, ADR-0009)
# ---------------------------------------------------------------------------


def _extract_confidence(output: Any) -> float | None:
    """Pull a self-reported confidence score out of an LLM response.

    Returns None if the output has no recognizable confidence field.
    We look at (in order): a top-level ``confidence`` key, a
    ``self_confidence`` key, and a JSON-decoded version of the raw
    text if the output is a string.
    """
    if isinstance(output, dict):
        for key in ("confidence", "self_confidence"):
            value = output.get(key)
            if isinstance(value, (int, float)) and 0.0 <= float(value) <= 1.0:
                return float(value)
        # Some callers wrap the payload in a "result" field.
        nested = output.get("result")
        if isinstance(nested, dict):
            return _extract_confidence(nested)
        return None
    if isinstance(output, str):
        text = output.strip()
        if not text.startswith("{"):
            return None
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            return None
        return _extract_confidence(parsed)
    return None


def _default_plausibility_gate(output: Any, *, min_confidence: float) -> tuple[bool, str]:
    """Default rubric for whether an executor output is good enough.

    Returns ``(accepted, reason)``. Escalates when:
    - the output is empty or None
    - the output is a string that fails JSON parsing when the
      caller asked for JSON
    - the output carries a confidence score below ``min_confidence``

    Callers that want richer checks (schema validation, finding
    verifier, plausibility gate, etc.) should pass their own
    ``gate`` callable to :func:`call_with_escalation`.
    """
    if output is None:
        return False, "executor returned None"
    if isinstance(output, (dict, list)) and not output:
        return False, "executor returned empty container"
    if isinstance(output, str) and not output.strip():
        return False, "executor returned empty string"

    confidence = _extract_confidence(output)
    if confidence is not None and confidence < min_confidence:
        return False, f"executor confidence {confidence:.2f} < {min_confidence:.2f}"

    return True, "accepted"


def call_with_escalation(
    prompt: str,
    *,
    executor_task: str = "fast_classification",
    advisor_task: str = "strategic_synthesis",
    system: str | None = None,
    max_escalations: int = 1,
    min_confidence: float = 0.6,
    gate: Callable[[Any], tuple[bool, str]] | None = None,
    llm_call: Callable[..., Any] | None = None,
) -> dict:
    """Run a prompt through the executor-advisor escalation loop.

    The executor tier is a cheap Grok variant (``fast_classification``
    by default). If the executor's output is rejected by ``gate``,
    the prompt is re-run against the heavier advisor tier
    (``strategic_synthesis`` by default) with the executor's attempt
    included as additional context. ``max_escalations`` caps the
    number of advisor invocations per call (default 1).

    Args:
        prompt: The user prompt to run.
        executor_task: Routing key for the cheap tier.
        advisor_task: Routing key for the heavier tier.
        system: Optional system prompt.
        max_escalations: Maximum number of advisor invocations
            per call. 1 is almost always right; higher values risk
            runaway cost.
        min_confidence: Default plausibility gate threshold for
            self-reported confidence scores. Ignored if a custom
            ``gate`` is supplied.
        gate: Optional callable ``(output) -> (accepted, reason)``.
            Overrides the default confidence-based gate. Use this
            to wire in schema validation, finding_verifier, or
            plausibility_gate from caller code.
        llm_call: Injectable LLM dispatcher for testing. Defaults
            to :func:`core.llm_provider.call_llm`. Must accept the
            same kwargs as ``call_llm`` and return a dict with at
            minimum a ``text`` field.

    Returns:
        A dict with:
            - ``output`` — the final chosen response (advisor if
              escalated, executor otherwise)
            - ``tier`` — ``"executor"`` or ``"advisor"``
            - ``executor_model`` — model used for the executor
            - ``advisor_model`` — model that would be used for
              escalation (always populated even if unused)
            - ``escalated`` — bool
            - ``escalation_reason`` — the gate's rejection reason,
              or ``"accepted"`` if the executor output was kept
            - ``executor_cost_usd``, ``advisor_cost_usd``,
              ``total_cost_usd`` — cost breakdown
            - ``executor_attempt`` — the executor's raw output
              (always populated, even on escalation, for
              debugging and metrics)
    """
    if llm_call is None:
        from core.llm_provider import call_llm as _default_call

        llm_call = _default_call

    executor_model = get_model(executor_task)
    advisor_model = get_model(advisor_task)

    if gate is None:

        def _gate(output: Any) -> tuple[bool, str]:
            return _default_plausibility_gate(output, min_confidence=min_confidence)

        gate = _gate

    # --- Executor pass ---
    executor_result = llm_call(
        prompt=prompt,
        system=system,
        model=executor_model,
        max_tokens=get_max_tokens(executor_task),
    )
    executor_text = (
        executor_result.get("text") if isinstance(executor_result, dict) else str(executor_result)
    )
    executor_cost = (
        float(executor_result.get("cost_usd", 0.0)) if isinstance(executor_result, dict) else 0.0
    )

    accepted, reason = gate(executor_text)

    # Emit a metric whether we escalate or not — the escalation rate
    # is a load-bearing operational signal.
    try:
        from core import metrics

        metrics.increment(
            "nebula_router_calls_total",
            {"task": executor_task, "tier": "executor", "accepted": str(accepted).lower()},
        )
    except Exception as exc:
        logger.debug("router metrics increment failed: %s", exc)

    if accepted or max_escalations <= 0:
        return {
            "output": executor_text,
            "tier": "executor",
            "executor_model": executor_model,
            "advisor_model": advisor_model,
            "escalated": False,
            "escalation_reason": reason,
            "executor_cost_usd": executor_cost,
            "advisor_cost_usd": 0.0,
            "total_cost_usd": executor_cost,
            "executor_attempt": executor_text,
        }

    logger.info(
        "router escalating %s -> %s (reason=%s)",
        executor_task,
        advisor_task,
        reason,
    )

    # --- Advisor pass ---
    escalated_prompt = (
        f"{prompt}\n\n"
        f"---\n"
        f"A cheaper model was asked this same question and produced:\n\n"
        f"{executor_text}\n\n"
        f"The response was rejected for this reason: {reason}\n"
        f"Please produce a corrected, higher-quality answer."
    )
    advisor_result = llm_call(
        prompt=escalated_prompt,
        system=system,
        model=advisor_model,
        max_tokens=get_max_tokens(advisor_task),
    )
    advisor_text = (
        advisor_result.get("text") if isinstance(advisor_result, dict) else str(advisor_result)
    )
    advisor_cost = (
        float(advisor_result.get("cost_usd", 0.0)) if isinstance(advisor_result, dict) else 0.0
    )

    try:
        from core import metrics

        metrics.increment(
            "nebula_router_escalations_total",
            {"executor_task": executor_task, "advisor_task": advisor_task},
        )
    except Exception as exc:
        logger.debug("router metrics increment failed: %s", exc)

    return {
        "output": advisor_text,
        "tier": "advisor",
        "executor_model": executor_model,
        "advisor_model": advisor_model,
        "escalated": True,
        "escalation_reason": reason,
        "executor_cost_usd": executor_cost,
        "advisor_cost_usd": advisor_cost,
        "total_cost_usd": executor_cost + advisor_cost,
        "executor_attempt": executor_text,
    }
