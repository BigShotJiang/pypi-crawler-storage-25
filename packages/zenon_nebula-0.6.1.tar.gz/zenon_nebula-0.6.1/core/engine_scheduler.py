# SPDX-License-Identifier: MIT
"""Tiered engine scheduling for Nebula autonomous runner.

Not every domain needs to run every cycle.  Security and quality
checks are critical and run every cycle (Tier 1).  Development,
intelligence, and devops run every 5 cycles (Tier 2).  Everything
else runs every 20 cycles (Tier 3).  All domains run on cycle 1
to bootstrap state.
"""


# -- Tier definitions -------------------------------------------------------
#
# NOTE: All domains now run every cycle. We rely on per-engine cooldowns
# (set inside the runner) to avoid wasting work on unproductive engines.
# Previously Tier 2/3 domains were throttled to every 5/20 cycles which meant
# only 2 of 17 domains fired on typical cycles -- a correctness bug for
# diagnostics that expect every domain to produce per-cycle findings.

TIER_1_INTERVAL = 1  # every cycle
TIER_2_INTERVAL = 1  # every cycle (was 5)
TIER_3_INTERVAL = 1  # every cycle (was 20)

TIER_1_DOMAINS = frozenset(
    {
        "security",
        "quality",
    }
)

TIER_2_DOMAINS = frozenset(
    {
        "development",
        "intelligence",
        "devops",
        "network_health",
    }
)

TIER_3_DOMAINS = frozenset(
    {
        "marketing",
        "education",
        "product_market_fit",
        "investigation",
        "economics",
        "governance",
        "community",
        "interoperability",
        "standards",
        "self_maintenance",
        "contribution",
    }
)

# Pre-computed lookup: domain_name -> cycle interval
_DOMAIN_INTERVAL: dict[str, int] = {}
for _name in TIER_1_DOMAINS:
    _DOMAIN_INTERVAL[_name] = TIER_1_INTERVAL
for _name in TIER_2_DOMAINS:
    _DOMAIN_INTERVAL[_name] = TIER_2_INTERVAL
for _name in TIER_3_DOMAINS:
    _DOMAIN_INTERVAL[_name] = TIER_3_INTERVAL


# -- Public API --------------------------------------------------------------


def should_run_domain(domain_name: str, cycle_number: int) -> bool:
    """Return True if *domain_name* should execute in *cycle_number*.

    Rules:
    - Cycle 1 is the bootstrap cycle -- every domain runs.
    - Tier 1 domains run every cycle.
    - Tier 2 domains run when ``cycle_number % 5 == 0``.
    - Tier 3 domains run when ``cycle_number % 20 == 0``.
    - Unknown domains default to Tier 3 cadence (conservative).
    """
    if cycle_number == 1:
        return True

    interval = _DOMAIN_INTERVAL.get(domain_name, TIER_3_INTERVAL)
    if interval == 1:
        return True
    return cycle_number % interval == 0
