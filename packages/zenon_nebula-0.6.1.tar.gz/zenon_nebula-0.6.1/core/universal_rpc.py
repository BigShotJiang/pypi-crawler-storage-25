# SPDX-License-Identifier: MIT
"""Universal RPC -- Multi-chain RPC client for Nebula.

Provides a uniform interface to query block height, latest block,
and connection status across any blockchain that speaks JSON-RPC.

Chains are auto-discovered from env vars: any var ending in ``_RPC``
whose value looks like a URL is registered.

Usage:
    from core.universal_rpc import get_all_rpcs

    rpcs = get_all_rpcs()
    for name, rpc in rpcs.items():
        if rpc.is_connected():
            print(f"{name}: height {rpc.get_block_height()}")
"""

import json
import logging
import os
import re
from abc import ABC, abstractmethod
from typing import Any
from urllib.parse import urlparse

from core.http import opsec_request, opsec_urlopen

logger = logging.getLogger(__name__)

try:
    from urllib.error import URLError
    from urllib.request import Request

    HAS_URLLIB = True
except ImportError:
    HAS_URLLIB = False

try:
    import websocket as ws_lib

    HAS_WEBSOCKET = True
except ImportError:
    HAS_WEBSOCKET = False


# ------------------------------------------------------------------
# Base class
# ------------------------------------------------------------------


class ChainRPC(ABC):
    """Base class for blockchain JSON-RPC clients.

    Subclasses implement the three core methods using chain-specific
    RPC method names.  All methods return ``None`` on failure so callers
    can fall back gracefully.
    """

    def __init__(self, url: str, timeout: float = 5.0):
        self._url = url
        self._timeout = timeout

    @property
    def url(self) -> str:
        """The RPC endpoint URL."""
        return self._url

    @abstractmethod
    def get_block_height(self) -> int | None:
        """Return the current chain height, or None if unavailable."""

    @abstractmethod
    def get_latest_block(self) -> dict | None:
        """Return minimal info about the latest block/momentum."""

    @abstractmethod
    def is_connected(self) -> bool:
        """Return True if the node is reachable right now."""


# ------------------------------------------------------------------
# Zenon (WebSocket)
# ------------------------------------------------------------------


class ZenonRPC(ChainRPC):
    """Zenon node RPC -- wraps the existing ZenonNodeClient."""

    def __init__(self, url: str | None = None, timeout: float = 5.0):
        _url = url or os.environ.get("ZENON_NODE_RPC", "ws://127.0.0.1:35998")
        super().__init__(_url, timeout)
        self._client: Any = None

    def _ensure_client(self) -> Any:
        if self._client is None:
            from core.node_rpc import ZenonNodeClient

            self._client = ZenonNodeClient(url=self._url, timeout=self._timeout)
        return self._client

    def get_block_height(self) -> int | None:
        """Return the current momentum height from the Zenon node."""
        momentum = self._ensure_client().get_frontier_momentum()
        if momentum and "height" in momentum:
            return int(momentum["height"])
        return None

    def get_latest_block(self) -> dict | None:
        """Return frontier momentum data from the Zenon node."""
        return self._ensure_client().get_frontier_momentum()

    def is_connected(self) -> bool:
        """Return True if the Zenon node is reachable."""
        return self._ensure_client().is_connected()


# ------------------------------------------------------------------
# Bitcoin (HTTP JSON-RPC with optional basic auth)
# ------------------------------------------------------------------


class BitcoinRPC(ChainRPC):
    """Bitcoin Core JSON-RPC over HTTP.

    Supports basic auth embedded in the URL:
        http://user:pass@localhost:8332
    """

    def _call(self, method: str, params: list | None = None) -> Any | None:
        if not HAS_URLLIB:
            return None
        parsed = urlparse(self._url)
        # Build a clean URL without credentials
        clean_url = f"{parsed.scheme}://{parsed.hostname}"
        if parsed.port:
            clean_url += f":{parsed.port}"
        clean_url += parsed.path or "/"

        payload = json.dumps(
            {
                "jsonrpc": "1.0",
                "id": "nebula",
                "method": method,
                "params": params or [],
            }
        ).encode()

        req = Request(clean_url, data=payload, method="POST")
        req.add_header("Content-Type", "application/json")

        # Basic auth from URL userinfo
        if parsed.username:
            import base64

            credentials = f"{parsed.username}:{parsed.password or ''}"
            encoded = base64.b64encode(credentials.encode()).decode()
            req.add_header("Authorization", f"Basic {encoded}")

        try:
            with opsec_urlopen(req, timeout=self._timeout) as resp:
                data = json.loads(resp.read())
                if data.get("error"):
                    logger.debug("Bitcoin RPC error: %s", data["error"])
                    return None
                return data.get("result")
        except Exception as exc:
            logger.debug("Bitcoin RPC call %s failed: %s", method, exc)
            return None

    def get_block_height(self) -> int | None:
        """Return the current Bitcoin block height."""
        result = self._call("getblockcount")
        if result is not None:
            return int(result)
        return None

    def get_latest_block(self) -> dict | None:
        """Return the latest Bitcoin block header as a dict."""
        height = self.get_block_height()
        if height is None:
            return None
        block_hash = self._call("getblockhash", [height])
        if block_hash is None:
            return None
        # verbosity 1 = JSON without tx details
        return self._call("getblock", [block_hash, 1])

    def is_connected(self) -> bool:
        """Return True if the Bitcoin node is reachable."""
        return self.get_block_height() is not None


# ------------------------------------------------------------------
# Ethereum (HTTP JSON-RPC)
# ------------------------------------------------------------------


class EthereumRPC(ChainRPC):
    """Ethereum JSON-RPC over HTTP (also works for EVM-compatible chains)."""

    def _call(self, method: str, params: list | None = None) -> Any | None:
        if not HAS_URLLIB:
            return None
        payload = json.dumps(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": method,
                "params": params or [],
            }
        ).encode()

        req = Request(self._url, data=payload, method="POST")
        req.add_header("Content-Type", "application/json")

        try:
            with opsec_urlopen(req, timeout=self._timeout) as resp:
                data = json.loads(resp.read())
                if data.get("error"):
                    logger.debug("Ethereum RPC error: %s", data["error"])
                    return None
                return data.get("result")
        except Exception as exc:
            logger.debug("Ethereum RPC call %s failed: %s", method, exc)
            return None

    def get_block_height(self) -> int | None:
        """Return the current Ethereum block number."""
        result = self._call("eth_blockNumber")
        if result is not None:
            return int(result, 16)
        return None

    def get_latest_block(self) -> dict | None:
        """Return the latest Ethereum block header."""
        # false = don't include full tx objects
        return self._call("eth_getBlockByNumber", ["latest", False])

    def is_connected(self) -> bool:
        """Return True if the Ethereum node is reachable."""
        return self.get_block_height() is not None


# ------------------------------------------------------------------
# Auto-discovery and factory
# ------------------------------------------------------------------

# Mapping of known env var prefixes to RPC classes
_CHAIN_CLASSES: dict[str, type[ChainRPC]] = {
    "ZENON": ZenonRPC,
    "BITCOIN": BitcoinRPC,
    "ETHEREUM": EthereumRPC,
}

# URL pattern for auto-detection
_URL_PATTERN = re.compile(r"^(https?|wss?)://")


def _is_url(value: str) -> bool:
    """Return True if value looks like an RPC URL."""
    return bool(_URL_PATTERN.match(value.strip()))


def _class_for_url(url: str) -> type[ChainRPC]:
    """Pick an RPC class based on URL scheme.

    WebSocket URLs get ZenonRPC (the only WS chain we support today).
    HTTP URLs default to EthereumRPC (generic JSON-RPC over HTTP).
    """
    parsed = urlparse(url.strip())
    if parsed.scheme in ("ws", "wss"):
        return ZenonRPC
    return EthereumRPC


def get_all_rpcs() -> dict[str, ChainRPC]:
    """Return all configured RPC clients from env vars.

    Any env var matching ``*_RPC`` with a URL value is registered.
    Known prefixes (ZENON, BITCOIN, ETHEREUM) use their specialised
    class; unknown prefixes fall back to scheme-based detection.
    """
    rpcs: dict[str, ChainRPC] = {}
    for key, value in os.environ.items():
        if not key.endswith("_RPC") or not value or not _is_url(value):
            continue
        # Derive chain name: BITCOIN_RPC -> bitcoin, ZENON_NODE_RPC -> zenon_node
        chain_name = key.removesuffix("_RPC").lower()

        # Pick class: known prefix first, then scheme-based fallback
        prefix = key.removesuffix("_RPC").split("_")[0]
        cls = _CHAIN_CLASSES.get(prefix, _class_for_url(value))

        try:
            rpcs[chain_name] = cls(url=value)
        except Exception as exc:
            logger.warning("Failed to create %s RPC client: %s", chain_name, exc)

    return rpcs
