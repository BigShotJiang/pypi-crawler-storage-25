# SPDX-License-Identifier: MIT
"""
Evidence Vault -- SHA-256 integrity vault for verified findings.

Every finding archived here gets a cryptographic fingerprint hash so that
downstream consumers can verify the data has not been tampered with since
archival. Generalized from marketing to support multi-domain archival.

Storage layout:
    data/vault/{domain}/{phase}.json  -- one JSON file per phase per domain.
"""

import hashlib
import json
import logging
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
VAULT_DIR = ENGINE_ROOT / "data" / "vault"


def _ensure_vault_dir(domain: str = "system") -> Path:
    """Create the vault directory for a domain if it does not exist."""
    domain_dir = VAULT_DIR / domain
    domain_dir.mkdir(parents=True, exist_ok=True)
    return domain_dir


def _compute_fingerprint_hash(fingerprints: list[dict]) -> str:
    """SHA-256 hash of fingerprints JSON for integrity verification."""
    fp_text = json.dumps(fingerprints, sort_keys=True)
    return hashlib.sha256(fp_text.encode()).hexdigest()


def _compute_content_hash(data: dict) -> str:
    """SHA-256 hash of content data for integrity verification."""
    return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()


def _load_phase_file(phase: str, domain: str = "system") -> list[dict]:
    """Load existing vault entries for a phase, or return empty list."""
    path = VAULT_DIR / domain / f"{phase}.json"
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text())
        if isinstance(data, list):
            return data
        logger.warning("Vault file %s is not a JSON array -- resetting.", path)
        return []
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("Could not read vault file %s: %s", path, exc)
        return []


def _save_phase_file(phase: str, entries: list[dict], domain: str = "system") -> Path:
    """Write vault entries back to the phase file."""
    domain_dir = _ensure_vault_dir(domain)
    path = domain_dir / f"{phase}.json"
    path.write_text(json.dumps(entries, indent=2))
    return path


# -- Public API --


def archive_finding(
    phase: str,
    analysis_type: str,
    fingerprints: list[dict],
    results_json: dict,
    domain: str = "system",
    confidence: float = 0.0,
) -> str:
    """Archive a verified finding to the evidence vault.

    Args:
        phase:          Investigation phase label (e.g. "evidence_42").
        analysis_type:  Template analysis type key.
        fingerprints:   API fingerprints from FingerprintedSession.
        results_json:   The results dict to archive.
        domain:         Domain this finding belongs to.
        confidence:     Confidence score of the finding.

    Returns:
        Vault entry path string: "{domain}/{phase}.json#{index}"
    """
    fingerprint_hash = _compute_fingerprint_hash(fingerprints)
    content_hash = _compute_content_hash(results_json)

    entry = {
        "phase": phase,
        "domain": domain,
        "analysis_type": analysis_type,
        "confidence": confidence,
        "results": results_json,
        "fingerprints": fingerprints,
        "fingerprint_hash": fingerprint_hash,
        "content_hash": content_hash,
        "archived_at": datetime.now(timezone.utc).isoformat(),
        "published": False,
    }

    entries = _load_phase_file(phase, domain)
    entries.append(entry)
    _save_phase_file(phase, entries, domain)

    index = len(entries) - 1
    vault_path = f"{domain}/{phase}.json#{index}"

    logger.info(
        "Archived finding: %s type=%s hash=%s..%s",
        vault_path,
        analysis_type,
        fingerprint_hash[:8],
        fingerprint_hash[-8:],
    )
    return vault_path


def verify_finding(vault_path: str) -> bool:
    """Verify the integrity of a vault entry by recomputing its fingerprint hash.

    Args:
        vault_path: Entry path in format "{domain}/{phase}.json#{index}".

    Returns:
        True if the stored hash matches the recomputed hash.
    """
    # Parse path: "domain/phase.json#index"
    path_part, _, index_str = vault_path.partition("#")
    parts = path_part.replace(".json", "").split("/")

    if len(parts) == 2:
        domain, phase = parts
    elif len(parts) == 1:
        domain, phase = "system", parts[0]
    else:
        logger.error("Invalid vault path format: %s", vault_path)
        return False

    try:
        index = int(index_str)
    except (ValueError, TypeError):
        logger.error("Invalid vault path index: %s", vault_path)
        return False

    entries = _load_phase_file(phase, domain)
    if index < 0 or index >= len(entries):
        logger.error("Vault index %d out of range for %s/%s", index, domain, phase)
        return False

    entry = entries[index]

    # Verify fingerprint hash
    stored_fp_hash = entry.get("fingerprint_hash", "")
    recomputed_fp_hash = _compute_fingerprint_hash(entry.get("fingerprints", []))
    fp_valid = stored_fp_hash == recomputed_fp_hash

    # Verify content hash if present
    stored_content_hash = entry.get("content_hash", "")
    if stored_content_hash:
        recomputed_content_hash = _compute_content_hash(entry.get("results", {}))
        content_valid = stored_content_hash == recomputed_content_hash
    else:
        content_valid = True  # Legacy entries without content hash

    is_valid = fp_valid and content_valid
    if not is_valid:
        logger.warning(
            "Integrity check FAILED for %s: fp=%s content=%s",
            vault_path,
            fp_valid,
            content_valid,
        )
    return is_valid


def get_publishable_findings(domain: str | None = None) -> list[dict]:
    """Return all vault entries eligible for publication.

    Scans phase files in the vault directory. Returns entries where
    'published' is False and integrity hash is valid.
    """
    _ensure_vault_dir("system")
    publishable = []

    search_dirs = []
    if domain:
        d = VAULT_DIR / domain
        if d.exists():
            search_dirs.append((domain, d))
    else:
        if VAULT_DIR.exists():
            for d in VAULT_DIR.iterdir():
                if d.is_dir():
                    search_dirs.append((d.name, d))

    for domain_name, domain_dir in search_dirs:
        for phase_path in sorted(domain_dir.glob("*.json")):
            phase = phase_path.stem
            entries = _load_phase_file(phase, domain_name)

            for i, entry in enumerate(entries):
                if entry.get("published", False):
                    continue

                stored_hash = entry.get("fingerprint_hash", "")
                recomputed = _compute_fingerprint_hash(entry.get("fingerprints", []))
                if stored_hash != recomputed:
                    logger.warning(
                        "Skipping tampered entry %s/%s.json#%d",
                        domain_name,
                        phase,
                        i,
                    )
                    continue

                entry_copy = dict(entry)
                entry_copy["vault_path"] = f"{domain_name}/{phase}.json#{i}"
                publishable.append(entry_copy)

    return publishable


def mark_as_published(vault_path: str) -> None:
    """Mark a vault entry as published."""
    path_part, _, index_str = vault_path.partition("#")
    parts = path_part.replace(".json", "").split("/")

    if len(parts) == 2:
        domain, phase = parts
    elif len(parts) == 1:
        domain, phase = "system", parts[0]
    else:
        logger.error("Invalid vault path format: %s", vault_path)
        return

    try:
        index = int(index_str)
    except (ValueError, TypeError):
        logger.error("Invalid vault path index: %s", vault_path)
        return

    entries = _load_phase_file(phase, domain)
    if index < 0 or index >= len(entries):
        logger.error("Vault index %d out of range", index)
        return

    entries[index]["published"] = True
    entries[index]["published_at"] = datetime.now(timezone.utc).isoformat()
    _save_phase_file(phase, entries, domain)
    logger.info("Marked as published: %s", vault_path)


def verify_vault_integrity(domain: str | None = None) -> dict:
    """Verify all vault entries are untampered.

    Returns dict with keys: total, valid, tampered, errors, by_domain.
    """
    results = {"total": 0, "valid": 0, "tampered": 0, "errors": 0, "by_domain": {}}

    if not VAULT_DIR.exists():
        return results

    search_dirs = []
    if domain:
        d = VAULT_DIR / domain
        if d.exists():
            search_dirs.append((domain, d))
    else:
        for d in VAULT_DIR.iterdir():
            if d.is_dir():
                search_dirs.append((d.name, d))

    for domain_name, domain_dir in search_dirs:
        domain_results = {"total": 0, "valid": 0, "tampered": 0, "errors": 0}

        for phase_path in domain_dir.glob("*.json"):
            try:
                entries = json.loads(phase_path.read_text())
                if not isinstance(entries, list):
                    entries = [entries]

                for entry in entries:
                    domain_results["total"] += 1
                    results["total"] += 1

                    try:
                        stored_hash = entry.get("fingerprint_hash", "")
                        recomputed = _compute_fingerprint_hash(entry.get("fingerprints", []))
                        if stored_hash == recomputed:
                            domain_results["valid"] += 1
                            results["valid"] += 1
                        else:
                            domain_results["tampered"] += 1
                            results["tampered"] += 1
                            logger.warning("Integrity FAIL: %s", phase_path.name)
                    except Exception as exc:
                        logger.debug("Integrity check error for %s: %s", phase_path.name, exc)
                        domain_results["errors"] += 1
                        results["errors"] += 1

            except Exception as exc:
                results["errors"] += 1
                logger.debug("Vault read error %s: %s", phase_path.name, exc)

        results["by_domain"][domain_name] = domain_results

    return results
