# SPDX-License-Identifier: MIT
"""
SynthesisEngine -- Persistent hypothesis graph for cross-finding synthesis.

Maintains a NetworkX graph where nodes are findings (from the evidence
table) and edges are evidence relationships (convergence, contradiction,
subsumption, temporal, causal, methodological).

Periodically invokes an LLM to synthesize convergent chains, propose
new relationships, and compute theory coherence scores.

Generalized from marketing's SynthesisEngine. Domain-agnostic: works
with any evidence stored in the standard evidence/hypotheses tables.
"""

import json
import logging
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from core.persistence import connect

try:
    import networkx as nx
except ImportError:
    nx = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
DEFAULT_GRAPH_PATH = str(ENGINE_ROOT / "data" / "hypothesis_graph.json")

# Relationship types between findings
RELATIONSHIP_TYPES = {
    "convergence": "Both findings point toward the same conclusion",
    "contradiction": "Findings conflict with each other",
    "subsumption": "One finding is a subset / special case of the other",
    "temporal": "Findings are temporally ordered (A preceded B)",
    "causal": "Finding A is a plausible cause of finding B",
    "methodological": "Findings come from independent methods but agree",
}

# Minimum findings before triggering synthesis
SYNTHESIS_THRESHOLD = 5


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class Theory:
    """A synthesized theory derived from the hypothesis graph."""

    title: str
    hypothesis_id: str
    mechanism: str
    evidence_chain: list[dict]
    coherence_score: float
    gaps: list[str]
    publishable: bool
    generated_at: str = ""
    word_count: int = 0

    def __post_init__(self) -> None:
        if not self.generated_at:
            self.generated_at = datetime.now(timezone.utc).isoformat()
        if not self.word_count:
            self.word_count = len(self.mechanism.split())


@dataclass
class SynthesisResult:
    """Result of a synthesis cycle."""

    new_edges: list[dict] = field(default_factory=list)
    convergent_chains: list[list[str]] = field(default_factory=list)
    synthesis_hypotheses: list[dict] = field(default_factory=list)
    coherence_score: float = 0.0
    total_nodes: int = 0
    total_edges: int = 0


# ---------------------------------------------------------------------------
# HypothesisGraph
# ---------------------------------------------------------------------------


class HypothesisGraph:
    """NetworkX-backed graph of findings and their relationships.

    Nodes represent findings from the evidence table.
    Edges represent evidence relationships (convergence, contradiction, etc.).
    """

    def __init__(self) -> None:
        if nx is None:
            raise ImportError("networkx is required for HypothesisGraph")
        self._graph: nx.DiGraph = nx.DiGraph()
        self._finding_count_at_last_synthesis: int = 0

    @property
    def node_count(self) -> int:
        """Total number of nodes in the hypothesis graph."""
        return self._graph.number_of_nodes()

    @property
    def edge_count(self) -> int:
        """Total number of edges in the hypothesis graph."""
        return self._graph.number_of_edges()

    @property
    def findings_since_last_synthesis(self) -> int:
        """Number of findings added since the last synthesis run."""
        return self.node_count - self._finding_count_at_last_synthesis

    @property
    def needs_synthesis(self) -> bool:
        """True if enough new findings have accumulated to warrant synthesis."""
        return self.findings_since_last_synthesis >= SYNTHESIS_THRESHOLD

    # -- Mutation -----------------------------------------------------------

    def add_finding(
        self,
        finding_id: int,
        engine: str,
        evidence_type: str,
        confidence: float,
        finding_text: str = "",
        supports_hypothesis: str | None = None,
        contradicts_hypothesis: str | None = None,
        timestamp: str | None = None,
    ) -> None:
        """Add a finding as a node in the graph."""
        self._graph.add_node(
            finding_id,
            engine=engine,
            evidence_type=evidence_type,
            confidence=confidence,
            finding_text=finding_text[:500],
            supports_hypothesis=supports_hypothesis,
            contradicts_hypothesis=contradicts_hypothesis,
            timestamp=timestamp or datetime.now(timezone.utc).isoformat(),
            node_type="finding",
        )

    def add_relationship(
        self,
        finding_a: int,
        finding_b: int,
        relationship_type: str,
        strength: float = 0.5,
        reasoning: str = "",
    ) -> None:
        """Add a directed edge between two findings."""
        if relationship_type not in RELATIONSHIP_TYPES:
            logger.warning(
                "Unknown relationship type '%s', defaulting to 'convergence'",
                relationship_type,
            )
            relationship_type = "convergence"

        self._graph.add_edge(
            finding_a,
            finding_b,
            relationship_type=relationship_type,
            strength=max(0.0, min(1.0, strength)),
            reasoning=reasoning[:300],
            created_at=datetime.now(timezone.utc).isoformat(),
        )

    def mark_synthesis_done(self) -> None:
        """Record that synthesis was just performed."""
        self._finding_count_at_last_synthesis = self.node_count

    # -- Query --------------------------------------------------------------

    def get_evidence_chains(self, hypothesis_id: str) -> list[list[dict]]:
        """Return all chains of evidence supporting a hypothesis."""
        supporting_nodes = [
            n
            for n, d in self._graph.nodes(data=True)
            if d.get("supports_hypothesis") == hypothesis_id
        ]

        if len(supporting_nodes) < 2:
            return [[self._node_to_dict(n)] for n in supporting_nodes]

        chains: list[list[dict]] = []
        for i, source in enumerate(supporting_nodes):
            for target in supporting_nodes[i + 1 :]:
                for direction in [(source, target), (target, source)]:
                    try:
                        for path in nx.all_simple_paths(
                            self._graph,
                            direction[0],
                            direction[1],
                            cutoff=6,
                        ):
                            chains.append([self._node_to_dict(n) for n in path])
                    except nx.NetworkXError:
                        pass

        if not chains:
            chains = [[self._node_to_dict(n)] for n in supporting_nodes]

        return chains

    def compute_mechanism_completeness(self, hypothesis_id: str) -> float:
        """Compute investigation completeness for a hypothesis.

        Factors: distinct engines, evidence types, average confidence,
        presence of counter-evidence, degree of interconnection.
        """
        supporting = [
            (n, d)
            for n, d in self._graph.nodes(data=True)
            if d.get("supports_hypothesis") == hypothesis_id
        ]
        contradicting = [
            (n, d)
            for n, d in self._graph.nodes(data=True)
            if d.get("contradicts_hypothesis") == hypothesis_id
        ]

        if not supporting:
            return 0.0

        all_evidence = supporting + contradicting

        engines = {d.get("engine", "") for _, d in all_evidence}
        engine_score = min(1.0, len(engines) / 3.0)

        ev_types = {d.get("evidence_type", "") for _, d in all_evidence}
        type_score = min(1.0, len(ev_types) / 4.0)

        avg_conf = sum(d.get("confidence", 0) for _, d in supporting) / len(supporting)
        confidence_score = min(1.0, avg_conf / 0.7)

        maturity_score = 0.5 if contradicting else 0.0
        if contradicting and avg_conf > 0.6:
            maturity_score = 1.0

        related_ids = [n for n, _ in all_evidence]
        subgraph = self._graph.subgraph(related_ids)
        max_edges = len(related_ids) * (len(related_ids) - 1)
        interconnection = subgraph.number_of_edges() / max_edges if max_edges > 0 else 0.0

        completeness = (
            engine_score * 0.25
            + type_score * 0.25
            + confidence_score * 0.25
            + maturity_score * 0.15
            + interconnection * 0.10
        )

        return round(min(1.0, completeness), 3)

    def identify_gaps(self) -> list[dict]:
        """Identify hypotheses with weak spots needing more evidence."""
        hypothesis_ids: set[str] = set()
        for _, d in self._graph.nodes(data=True):
            for key in ("supports_hypothesis", "contradicts_hypothesis"):
                h = d.get(key)
                if h:
                    hypothesis_ids.add(h)

        gaps: list[dict] = []
        for h_id in hypothesis_ids:
            supporting = [
                d for _, d in self._graph.nodes(data=True) if d.get("supports_hypothesis") == h_id
            ]
            contradicting = [
                d
                for _, d in self._graph.nodes(data=True)
                if d.get("contradicts_hypothesis") == h_id
            ]

            engines_used = {d.get("engine") for d in supporting}
            avg_conf = (
                sum(d.get("confidence", 0) for d in supporting) / len(supporting)
                if supporting
                else 0.0
            )

            if len(engines_used) < 2:
                gaps.append(
                    {
                        "hypothesis_id": h_id,
                        "gap_type": "few_engines",
                        "description": (
                            f"Only {len(engines_used)} engine(s) contributed evidence. "
                            "Need independent corroboration from at least 2 engines."
                        ),
                        "severity": "high",
                    }
                )

            if supporting and avg_conf < 0.5:
                gaps.append(
                    {
                        "hypothesis_id": h_id,
                        "gap_type": "low_confidence",
                        "description": (
                            f"Average confidence is {avg_conf:.2f}. "
                            "Need stronger evidence (target: >= 0.5)."
                        ),
                        "severity": "high" if avg_conf < 0.3 else "medium",
                    }
                )

            if supporting and not contradicting:
                gaps.append(
                    {
                        "hypothesis_id": h_id,
                        "gap_type": "no_counter_evidence",
                        "description": (
                            "No contradicting evidence found. Hypothesis may be "
                            "untested -- consider adversarial investigation."
                        ),
                        "severity": "medium",
                    }
                )

            supporting_ids = [
                n for n, d in self._graph.nodes(data=True) if d.get("supports_hypothesis") == h_id
            ]
            if len(supporting_ids) >= 2:
                subgraph = self._graph.subgraph(supporting_ids)
                if subgraph.number_of_edges() == 0:
                    gaps.append(
                        {
                            "hypothesis_id": h_id,
                            "gap_type": "isolated_findings",
                            "description": (
                                f"{len(supporting_ids)} supporting findings are completely "
                                "disconnected. Need to establish relationships between them."
                            ),
                            "severity": "medium",
                        }
                    )

        severity_order = {"high": 0, "medium": 1, "low": 2}
        gaps.sort(key=lambda g: severity_order.get(g["severity"], 3))
        return gaps

    # -- Persistence --------------------------------------------------------

    def save_graph(self, path: str = DEFAULT_GRAPH_PATH) -> None:
        """Persist the graph to a JSON file."""
        Path(path).parent.mkdir(parents=True, exist_ok=True)

        data: dict = {
            "metadata": {
                "saved_at": datetime.now(timezone.utc).isoformat(),
                "node_count": self.node_count,
                "edge_count": self.edge_count,
                "finding_count_at_last_synthesis": self._finding_count_at_last_synthesis,
            },
            "nodes": [{"id": nid, **attrs} for nid, attrs in self._graph.nodes(data=True)],
            "edges": [
                {"source": u, "target": v, **attrs} for u, v, attrs in self._graph.edges(data=True)
            ],
        }

        with open(path, "w") as f:
            json.dump(data, f, indent=2)

        logger.info("Graph saved: %d nodes, %d edges", self.node_count, self.edge_count)

    def load_graph(self, path: str = DEFAULT_GRAPH_PATH) -> bool:
        """Load the graph from a JSON file. Returns True on success."""
        if not Path(path).exists():
            return False

        try:
            with open(path) as f:
                data = json.load(f)

            self._graph = nx.DiGraph()

            for node_data in data.get("nodes", []):
                node_data = dict(node_data)
                node_id = node_data.pop("id")
                self._graph.add_node(node_id, **node_data)

            for edge_data in data.get("edges", []):
                edge_data = dict(edge_data)
                source = edge_data.pop("source")
                target = edge_data.pop("target")
                self._graph.add_edge(source, target, **edge_data)

            metadata = data.get("metadata", {})
            self._finding_count_at_last_synthesis = metadata.get(
                "finding_count_at_last_synthesis",
                0,
            )
            logger.info("Graph loaded: %d nodes, %d edges", self.node_count, self.edge_count)
            return True

        except (json.JSONDecodeError, OSError, KeyError) as exc:
            logger.error("Failed to load graph: %s", exc)
            return False

    # -- Internals ----------------------------------------------------------

    def _node_to_dict(self, node_id: int) -> dict:
        attrs = dict(self._graph.nodes[node_id])
        attrs["finding_id"] = node_id
        return attrs

    def get_all_nodes(self) -> list[dict]:
        """Return all nodes as dicts."""
        return [self._node_to_dict(n) for n in self._graph.nodes]

    def get_all_edges(self) -> list[dict]:
        """Return all edges as dicts with source, target, and attributes."""
        return [{"source": u, "target": v, **d} for u, v, d in self._graph.edges(data=True)]

    def get_connected_components(self) -> list[list[int]]:
        """Return connected components as sorted lists of node IDs."""
        undirected = self._graph.to_undirected()
        return [sorted(c) for c in nx.connected_components(undirected)]


# ---------------------------------------------------------------------------
# SynthesisEngine
# ---------------------------------------------------------------------------


class SynthesisEngine:
    """Orchestrates cross-finding synthesis via the HypothesisGraph and an LLM.

    Usage:
        engine = SynthesisEngine(db_path="data/engine.db")
        engine.build_graph()
        if engine.graph.needs_synthesis:
            result = engine.synthesize()
    """

    def __init__(
        self,
        db_path: str = DEFAULT_DB,
        graph_path: str = DEFAULT_GRAPH_PATH,
    ) -> None:
        self.db_path = db_path
        self.graph_path = graph_path
        self.graph = HypothesisGraph()
        self.graph.load_graph(self.graph_path)

    # -- Graph construction -------------------------------------------------

    def build_graph(self) -> HypothesisGraph:
        """Construct/update the graph from the evidence table."""
        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute(
                """SELECT id, engine, evidence_type, finding, confidence,
                          supports_hypothesis, contradicts_hypothesis, timestamp
                   FROM evidence ORDER BY timestamp ASC"""
            ).fetchall()

            existing_ids = set(self.graph._graph.nodes)
            new_count = 0

            for row in rows:
                if row["id"] not in existing_ids:
                    self.graph.add_finding(
                        finding_id=row["id"],
                        engine=row["engine"] or "",
                        evidence_type=row["evidence_type"] or "",
                        confidence=row["confidence"] or 0.0,
                        finding_text=row["finding"] or "",
                        supports_hypothesis=row["supports_hypothesis"],
                        contradicts_hypothesis=row["contradicts_hypothesis"],
                        timestamp=row["timestamp"],
                    )
                    new_count += 1

            self._auto_link_by_hypothesis()
            logger.info("Graph built: %d new findings added", new_count)
        finally:
            conn.close()

        return self.graph

    def _auto_link_by_hypothesis(self) -> None:
        """Create edges between findings sharing a hypothesis reference."""
        hypothesis_supporters: dict[str, list[int]] = {}
        for node_id, data in self.graph._graph.nodes(data=True):
            h = data.get("supports_hypothesis")
            if h:
                hypothesis_supporters.setdefault(h, []).append(node_id)

        for supporters in hypothesis_supporters.values():
            for i, a in enumerate(supporters):
                for b in supporters[i + 1 :]:
                    if not self.graph._graph.has_edge(a, b):
                        self.graph.add_relationship(
                            a,
                            b,
                            relationship_type="convergence",
                            strength=0.3,
                            reasoning="Both support the same hypothesis",
                        )

    # -- Synthesis context builder ------------------------------------------

    def build_synthesis_context(self) -> str:
        """Build a context string for LLM-based synthesis.

        Returns a formatted summary of nodes, edges, and gaps that
        can be passed to any LLM for synthesis.
        """
        nodes = self.graph.get_all_nodes()
        edges = self.graph.get_all_edges()
        gaps = self.graph.identify_gaps()

        node_lines = []
        for n in nodes[:100]:
            node_lines.append(
                f"  - Finding #{n['finding_id']}: engine={n.get('engine')}, "
                f"type={n.get('evidence_type')}, confidence={n.get('confidence', 0):.2f}, "
                f"supports={n.get('supports_hypothesis', 'none')}, "
                f"text={n.get('finding_text', '')[:200]}"
            )

        edge_lines = [
            f"  - #{e['source']} -> #{e['target']}: "
            f"{e.get('relationship_type', '?')} (strength={e.get('strength', 0):.2f})"
            for e in edges[:100]
        ]

        gap_lines = [
            f"  - [{g['severity'].upper()}] {g['hypothesis_id']}: {g['description']}"
            for g in gaps[:20]
        ]

        return (
            f"## Findings ({len(nodes)} total)\n"
            + "\n".join(node_lines[:50])
            + f"\n\n## Existing Relationships ({len(edges)} total)\n"
            + "\n".join(edge_lines[:50])
            + f"\n\n## Identified Gaps ({len(gaps)} total)\n"
            + "\n".join(gap_lines[:20])
        )

    def apply_synthesis_result(self, result_data: dict) -> SynthesisResult:
        """Apply LLM synthesis output to the graph.

        Args:
            result_data: Dict with keys ``new_relationships``,
                ``convergent_chains``, ``synthesis_hypotheses``,
                ``coherence_score``.

        Returns:
            SynthesisResult summarizing what changed.
        """
        new_edges: list[dict] = []
        for rel in result_data.get("new_relationships", []):
            finding_a = rel.get("finding_a")
            finding_b = rel.get("finding_b")
            if finding_a in self.graph._graph.nodes and finding_b in self.graph._graph.nodes:
                self.graph.add_relationship(
                    finding_a,
                    finding_b,
                    relationship_type=rel.get("relationship_type", "convergence"),
                    strength=rel.get("strength", 0.5),
                    reasoning=rel.get("reasoning", ""),
                )
                new_edges.append(rel)

        self.graph.mark_synthesis_done()
        self.graph.save_graph(self.graph_path)

        return SynthesisResult(
            new_edges=new_edges,
            convergent_chains=result_data.get("convergent_chains", []),
            synthesis_hypotheses=result_data.get("synthesis_hypotheses", []),
            coherence_score=result_data.get("coherence_score", 0.0),
            total_nodes=self.graph.node_count,
            total_edges=self.graph.edge_count,
        )
