# SPDX-License-Identifier: MIT
"""
Blockchain API Templates -- Bitcoin via Blockstream Esplora, Ethereum via public API.

All calls go through FingerprintedSession for provenance. Rate-limited to
avoid overloading public APIs.

Functions:
    get_btc_address_info  -- Address balance, tx count, funded/spent totals.
    get_btc_block_info    -- Block header, coinbase, miner identification.
    get_btc_tx_info       -- Transaction inputs, outputs, fee, confirmation.
    get_eth_address_info  -- ETH balance and tx count via public RPC.
"""

import logging
import time
from datetime import datetime, timezone

from core.api_fingerprint import FingerprintedSession

logger = logging.getLogger(__name__)

ESPLORA_BASE = "https://blockstream.info/api"

# Rate limit: max 2 requests/second to Esplora
_RATE_LIMIT_SECONDS = 0.5
_last_request_time = 0.0

# Common mining pool signatures for block analysis
POOL_SIGNATURES = {
    "Foundry USA": ["Foundry USA", "/Foundry/"],
    "F2Pool": ["/F2Pool/"],
    "AntPool": ["/AntPool/"],
    "ViaBTC": ["/ViaBTC/"],
    "Binance Pool": ["/Binance/"],
    "SlushPool": ["/slush/", "/Braiins"],
    "Poolin": ["/Poolin/"],
    "BTC.com": ["/BTC.COM/"],
    "MARA Pool": ["/MARA Pool/", "MARA"],
    "Luxor": ["/Luxor/"],
}


def _rate_limit() -> None:
    """Enforce rate limiting between Esplora requests."""
    global _last_request_time
    now = time.monotonic()
    elapsed = now - _last_request_time
    if elapsed < _RATE_LIMIT_SECONDS:
        time.sleep(_RATE_LIMIT_SECONDS - elapsed)
    _last_request_time = time.monotonic()


def _unix_to_utc(ts: int) -> str:
    """Convert a Unix timestamp to human-readable UTC string."""
    if ts == 0:
        return "unknown"
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def _infer_address_type(address: str) -> str:
    """Infer Bitcoin address type from its prefix."""
    if address.startswith("bc1q") and len(address) == 42:
        return "p2wpkh"
    elif address.startswith("bc1q") and len(address) == 62:
        return "p2wsh"
    elif address.startswith("bc1p"):
        return "p2tr (taproot)"
    elif address.startswith("1"):
        return "p2pkh (legacy)"
    elif address.startswith("3"):
        return "p2sh"
    return "unknown"


def _identify_miner(coinbase_ascii: str) -> str:
    """Identify mining pool from coinbase ASCII message."""
    for pool, sigs in POOL_SIGNATURES.items():
        for sig in sigs:
            if sig.lower() in coinbase_ascii.lower():
                return pool
    return "Unknown"


def get_btc_address_info(
    address: str,
    session: FingerprintedSession | None = None,
) -> dict:
    """Query a Bitcoin address via Blockstream Esplora.

    Args:
        address:  Bitcoin address string.
        session:  FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, address, address_type, tx_count, balance_btc,
        funded/spent totals, first/last seen timestamps, fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="blockstream_address")

    _rate_limit()
    try:
        resp = session.get(f"{ESPLORA_BASE}/address/{address}", timeout=15)
        resp.raise_for_status()
        data = resp.json()

        chain_stats = data.get("chain_stats", {})
        mempool_stats = data.get("mempool_stats", {})
        funded_sats = chain_stats.get("funded_txo_sum", 0)
        spent_sats = chain_stats.get("spent_txo_sum", 0)
        balance_sats = funded_sats - spent_sats

        # Get recent transactions for first/last seen
        _rate_limit()
        resp_txs = session.get(
            f"{ESPLORA_BASE}/address/{address}/txs",
            timeout=15,
        )
        resp_txs.raise_for_status()
        txs = resp_txs.json()

        first_seen = None
        last_seen = None
        if txs:
            confirmed = [tx for tx in txs if tx.get("status", {}).get("confirmed")]
            if confirmed:
                last_seen = confirmed[0]["status"].get("block_time")
                first_seen = confirmed[-1]["status"].get("block_time")

        return {
            "status": "success",
            "address": address,
            "address_type": _infer_address_type(address),
            "tx_count": chain_stats.get("tx_count", 0),
            "funded_txo_count": chain_stats.get("funded_txo_count", 0),
            "funded_txo_sum_sats": funded_sats,
            "funded_txo_sum_btc": funded_sats / 1e8,
            "spent_txo_count": chain_stats.get("spent_txo_count", 0),
            "spent_txo_sum_sats": spent_sats,
            "spent_txo_sum_btc": spent_sats / 1e8,
            "balance_sats": balance_sats,
            "balance_btc": balance_sats / 1e8,
            "mempool_tx_count": mempool_stats.get("tx_count", 0),
            "first_seen_timestamp": first_seen,
            "last_seen_timestamp": last_seen,
            "fingerprints": session.get_fingerprints(),
        }

    except Exception as exc:
        logger.error("BTC address query failed for %s: %s", address, exc)
        return {
            "status": "error",
            "address": address,
            "error": str(exc),
            "fingerprints": session.get_fingerprints(),
        }


def get_btc_block_info(
    height: int,
    session: FingerprintedSession | None = None,
) -> dict:
    """Fetch and analyze a Bitcoin block by height.

    Args:
        height:   Block height.
        session:  FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, block_height, block_hash, timestamp, tx_count,
        miner_identified, coinbase_message_ascii, fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="blockstream_block")

    _rate_limit()
    try:
        # Block hash from height
        resp = session.get(
            f"{ESPLORA_BASE}/block-height/{height}",
            timeout=15,
        )
        resp.raise_for_status()
        block_hash = resp.text.strip()

        # Full block header
        _rate_limit()
        resp = session.get(f"{ESPLORA_BASE}/block/{block_hash}", timeout=15)
        resp.raise_for_status()
        block_data = resp.json()

        # Coinbase transaction (first tx in block)
        _rate_limit()
        resp = session.get(
            f"{ESPLORA_BASE}/block/{block_hash}/txs/0",
            timeout=15,
        )
        resp.raise_for_status()
        txs_page0 = resp.json()

        coinbase_message = ""
        coinbase_scriptsig = ""
        coinbase_tx = txs_page0[0] if txs_page0 else None
        if coinbase_tx and coinbase_tx.get("vin"):
            scriptsig_hex = coinbase_tx["vin"][0].get("scriptsig", "")
            coinbase_scriptsig = scriptsig_hex
            try:
                raw_bytes = bytes.fromhex(scriptsig_hex)
                coinbase_message = "".join(chr(b) if 32 <= b < 127 else "." for b in raw_bytes)
            except (ValueError, UnicodeDecodeError):
                coinbase_message = "[decode failed]"

        ts = block_data.get("timestamp", 0)
        return {
            "status": "success",
            "block_height": height,
            "block_hash": block_hash,
            "timestamp": ts,
            "timestamp_human": _unix_to_utc(ts),
            "tx_count": block_data.get("tx_count"),
            "size": block_data.get("size"),
            "weight": block_data.get("weight"),
            "difficulty": block_data.get("difficulty"),
            "nonce": block_data.get("nonce"),
            "merkle_root": block_data.get("merkle_root"),
            "previous_blockhash": block_data.get("previousblockhash"),
            "miner_identified": _identify_miner(coinbase_message),
            "coinbase_message_ascii": coinbase_message,
            "coinbase_scriptsig_hex": coinbase_scriptsig,
            "fingerprints": session.get_fingerprints(),
        }

    except Exception as exc:
        logger.error("BTC block query failed for height %d: %s", height, exc)
        return {
            "status": "error",
            "block_height": height,
            "error": str(exc),
            "fingerprints": session.get_fingerprints(),
        }


def get_btc_tx_info(
    txid: str,
    session: FingerprintedSession | None = None,
) -> dict:
    """Fetch a Bitcoin transaction by txid.

    Args:
        txid:     Transaction hash.
        session:  FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, txid, confirmed, block_height, fee,
        input_count, output_count, total_output_sats, fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="blockstream_tx")

    _rate_limit()
    try:
        resp = session.get(f"{ESPLORA_BASE}/tx/{txid}", timeout=15)
        resp.raise_for_status()
        tx = resp.json()

        status = tx.get("status", {})
        confirmed = status.get("confirmed", False)

        total_output_sats = sum(out.get("value", 0) for out in tx.get("vout", []))

        return {
            "status": "success",
            "txid": txid,
            "confirmed": confirmed,
            "block_height": status.get("block_height"),
            "block_hash": status.get("block_hash"),
            "block_time": status.get("block_time"),
            "block_time_human": _unix_to_utc(status.get("block_time", 0)),
            "fee": tx.get("fee"),
            "size": tx.get("size"),
            "weight": tx.get("weight"),
            "input_count": len(tx.get("vin", [])),
            "output_count": len(tx.get("vout", [])),
            "total_output_sats": total_output_sats,
            "total_output_btc": total_output_sats / 1e8,
            "fingerprints": session.get_fingerprints(),
        }

    except Exception as exc:
        logger.error("BTC tx query failed for %s: %s", txid, exc)
        return {
            "status": "error",
            "txid": txid,
            "error": str(exc),
            "fingerprints": session.get_fingerprints(),
        }


def get_eth_address_info(
    address: str,
    rpc_url: str = "https://eth.llamarpc.com",
    session: FingerprintedSession | None = None,
) -> dict:
    """Query an Ethereum address balance and nonce via JSON-RPC.

    Uses a public RPC endpoint (LlamaRPC by default). No API key needed.

    Args:
        address:  Ethereum address (0x...).
        rpc_url:  JSON-RPC endpoint URL.
        session:  FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, address, balance_wei, balance_eth, nonce, fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="eth_address")

    try:
        # eth_getBalance
        resp_bal = session.post(
            rpc_url,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "eth_getBalance",
                "params": [address, "latest"],
            },
            timeout=15,
        )
        resp_bal.raise_for_status()
        bal_result = resp_bal.json().get("result", "0x0")
        balance_wei = int(bal_result, 16)

        # eth_getTransactionCount (nonce)
        resp_nonce = session.post(
            rpc_url,
            json={
                "jsonrpc": "2.0",
                "id": 2,
                "method": "eth_getTransactionCount",
                "params": [address, "latest"],
            },
            timeout=15,
        )
        resp_nonce.raise_for_status()
        nonce_result = resp_nonce.json().get("result", "0x0")
        nonce = int(nonce_result, 16)

        return {
            "status": "success",
            "address": address,
            "balance_wei": balance_wei,
            "balance_eth": balance_wei / 1e18,
            "nonce": nonce,
            "fingerprints": session.get_fingerprints(),
        }

    except Exception as exc:
        logger.error("ETH address query failed for %s: %s", address, exc)
        return {
            "status": "error",
            "address": address,
            "error": str(exc),
            "fingerprints": session.get_fingerprints(),
        }
