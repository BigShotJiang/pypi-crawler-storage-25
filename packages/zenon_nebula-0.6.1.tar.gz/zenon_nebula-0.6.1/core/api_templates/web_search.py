# SPDX-License-Identifier: MIT
"""
Web Search Templates -- Search and fetch web content.

Tries SETI MCP server first (free, integrated), falls back to direct
web fetch. All calls go through FingerprintedSession for provenance.

Functions:
    search          -- Web search via SETI or fallback.
    fetch_page      -- Fetch and extract text from a URL.
    search_news     -- Search for recent news about a topic.
"""

import logging
import re
import time

from core.api_fingerprint import FingerprintedSession

logger = logging.getLogger(__name__)

_RATE_LIMIT_SECONDS = 1.0
_last_request_time = 0.0


def _rate_limit() -> None:
    """Enforce rate limiting."""
    global _last_request_time
    now = time.monotonic()
    elapsed = now - _last_request_time
    if elapsed < _RATE_LIMIT_SECONDS:
        time.sleep(_RATE_LIMIT_SECONDS - elapsed)
    _last_request_time = time.monotonic()


def _try_seti_search(query: str) -> list[dict] | None:
    """Try searching via SETI MCP server if available.

    SETI provides free web search via the MCP protocol. Returns None
    if SETI is not available.
    """
    # SETI integration is MCP-based and not directly callable via HTTP.
    # When running inside Claude Code, SETI is available as an MCP tool.
    # Outside Claude Code, this returns None and we fall back.
    return None


def search(
    query: str,
    max_results: int = 10,
    session: FingerprintedSession | None = None,
) -> dict:
    """Perform a web search.

    Tries SETI first (free MCP-based search). If unavailable, performs
    a simple DuckDuckGo HTML search as fallback.

    Args:
        query:        Search query string.
        max_results:  Maximum number of results.
        session:      FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, query, results (list of {title, url, snippet}),
        source, fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="web_search")

    # Try SETI first
    seti_results = _try_seti_search(query)
    if seti_results is not None:
        return {
            "status": "success",
            "query": query,
            "source": "seti",
            "result_count": len(seti_results),
            "results": seti_results[:max_results],
            "fingerprints": session.get_fingerprints(),
        }

    # Fallback: DuckDuckGo HTML (no API key needed)
    _rate_limit()
    try:
        resp = session.get(
            "https://html.duckduckgo.com/html/",
            params={"q": query},
            timeout=15,
        )
        resp.raise_for_status()

        results = _parse_ddg_html(resp.text, max_results)

        return {
            "status": "success",
            "query": query,
            "source": "duckduckgo",
            "result_count": len(results),
            "results": results,
            "fingerprints": session.get_fingerprints(),
        }

    except Exception as exc:
        logger.error("Web search failed for %r: %s", query, exc)
        return {
            "status": "error",
            "query": query,
            "error": str(exc),
            "fingerprints": session.get_fingerprints(),
        }


def fetch_page(
    url: str,
    session: FingerprintedSession | None = None,
    max_length: int = 50000,
) -> dict:
    """Fetch a URL and extract readable text content.

    Strips HTML tags and returns plain text. Useful for extracting
    content from articles, blog posts, etc.

    Args:
        url:         URL to fetch.
        session:     FingerprintedSession (created if not provided).
        max_length:  Maximum text length to return.

    Returns:
        Dict with: status, url, title, text, text_length, fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="web_fetch")

    _rate_limit()
    try:
        resp = session.get(url, timeout=20)
        resp.raise_for_status()

        html = resp.text
        title = _extract_title(html)
        text = _html_to_text(html)

        if len(text) > max_length:
            text = text[:max_length] + "... [truncated]"

        return {
            "status": "success",
            "url": url,
            "title": title,
            "text": text,
            "text_length": len(text),
            "content_type": resp.headers.get("content-type", ""),
            "fingerprints": session.get_fingerprints(),
        }

    except Exception as exc:
        logger.error("Page fetch failed for %s: %s", url, exc)
        return {
            "status": "error",
            "url": url,
            "error": str(exc),
            "fingerprints": session.get_fingerprints(),
        }


def search_news(
    query: str,
    days: int = 7,
    max_results: int = 10,
    session: FingerprintedSession | None = None,
) -> dict:
    """Search for recent news about a topic.

    Appends a time qualifier to the query to focus on recent results.

    Args:
        query:        Search query string.
        days:         How many days back to search.
        max_results:  Maximum number of results.
        session:      FingerprintedSession (created if not provided).

    Returns:
        Same format as search(), with time-filtered results.
    """
    # DuckDuckGo time filter via query modifier
    time_query = f"{query} site:news OR site:blog"
    if days <= 1:
        time_query = f"{query} today"
    elif days <= 7:
        time_query = f"{query} this week"
    elif days <= 30:
        time_query = f"{query} this month"

    return search(
        query=time_query,
        max_results=max_results,
        session=session,
    )


def _parse_ddg_html(html: str, max_results: int) -> list[dict]:
    """Parse DuckDuckGo HTML search results into structured data."""
    results = []

    # DuckDuckGo HTML results are in <a class="result__a"> tags
    # and <a class="result__snippet"> tags
    link_pattern = re.compile(
        r'<a[^>]+class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>',
        re.DOTALL,
    )
    snippet_pattern = re.compile(
        r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>',
        re.DOTALL,
    )

    links = link_pattern.findall(html)
    snippets = snippet_pattern.findall(html)

    for i, (url, title_html) in enumerate(links[:max_results]):
        title = re.sub(r"<[^>]+>", "", title_html).strip()
        snippet = ""
        if i < len(snippets):
            snippet = re.sub(r"<[^>]+>", "", snippets[i]).strip()

        # DuckDuckGo uses redirect URLs; extract the real URL
        if "uddg=" in url:
            import urllib.parse

            parsed = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            url = parsed.get("uddg", [url])[0]

        if title and url:
            results.append(
                {
                    "title": title[:200],
                    "url": url,
                    "snippet": snippet[:300],
                }
            )

    return results


def _extract_title(html: str) -> str:
    """Extract page title from HTML."""
    match = re.search(r"<title[^>]*>(.*?)</title>", html, re.IGNORECASE | re.DOTALL)
    return match.group(1).strip()[:200] if match else ""


def _html_to_text(html: str) -> str:
    """Convert HTML to plain text by stripping tags."""
    # Remove script and style elements
    text = re.sub(r"<script[^>]*>.*?</script>", " ", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<style[^>]*>.*?</style>", " ", text, flags=re.DOTALL | re.IGNORECASE)
    # Remove HTML tags
    text = re.sub(r"<[^>]+>", " ", text)
    # Decode common HTML entities
    text = text.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    text = text.replace("&quot;", '"').replace("&#39;", "'").replace("&nbsp;", " ")
    # Collapse whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text
