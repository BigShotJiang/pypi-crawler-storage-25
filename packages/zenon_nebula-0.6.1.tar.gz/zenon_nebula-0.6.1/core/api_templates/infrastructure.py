# SPDX-License-Identifier: MIT
"""
Infrastructure Forensics -- WHOIS, SSL, DNS, and timezone correlation.

Provides utilities for:
- DNS lookup: resolve A/AAAA/MX/NS records
- WHOIS history: domain registration analysis
- SSL certificate analysis: issuer, validity, SAN entries
- Wayback Machine infrastructure: CDN, analytics, hosting fingerprinting
- Commit timezone correlation: compare timezone patterns across repos

NOT a DiscoveryTemplate -- these are lower-level utilities that any
domain engine or template can call.

Generalized from marketing's infrastructure_fingerprint.py,
timezone_correlation.py, and domain_forensics.py.
"""

import logging
import re
import socket
import subprocess
from collections import defaultdict

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DNS lookup
# ---------------------------------------------------------------------------


def dns_lookup(domain: str) -> dict:
    """Perform DNS lookups for a domain.

    Resolves A records (IPv4) and attempts to detect CDN/hosting
    from reverse DNS.

    Args:
        domain: Domain name to look up.

    Returns:
        Dict with ip_addresses, reverse_dns, and detected CDN hints.
    """
    result: dict = {
        "domain": domain,
        "ip_addresses": [],
        "reverse_dns": [],
        "cdn_hints": [],
    }

    try:
        # A record
        addrs = socket.getaddrinfo(domain, None, socket.AF_INET, socket.SOCK_STREAM)
        ips = list({addr[4][0] for addr in addrs})
        result["ip_addresses"] = ips

        # Reverse DNS for each IP
        for ip in ips[:3]:
            try:
                hostname, _, _ = socket.gethostbyaddr(ip)
                result["reverse_dns"].append({"ip": ip, "hostname": hostname})

                # CDN detection from reverse DNS
                hostname_lower = hostname.lower()
                cdn_patterns = {
                    "cloudflare": "cloudflare",
                    "cloudfront": "amazonaws.com",
                    "akamai": "akamai",
                    "fastly": "fastly",
                    "google": "google",
                    "netlify": "netlify",
                    "vercel": "vercel",
                    "digitalocean": "digitalocean",
                    "hetzner": "hetzner",
                    "ovh": "ovh",
                }
                for cdn_name, pattern in cdn_patterns.items():
                    if pattern in hostname_lower:
                        result["cdn_hints"].append(cdn_name)

            except (socket.herror, socket.gaierror):
                pass

    except (socket.gaierror, OSError) as exc:
        result["error"] = str(exc)

    return result


# ---------------------------------------------------------------------------
# SSL certificate analysis
# ---------------------------------------------------------------------------


def ssl_certificate_info(domain: str, port: int = 443) -> dict:
    """Fetch SSL certificate details for a domain.

    Uses the openssl CLI tool to connect and extract certificate info.

    Args:
        domain: Domain name.
        port:   Port (default 443).

    Returns:
        Dict with issuer, subject, validity dates, and SAN entries.
    """
    result: dict = {
        "domain": domain,
        "issuer": "",
        "subject": "",
        "not_before": "",
        "not_after": "",
        "san_entries": [],
    }

    try:
        proc = subprocess.run(
            [
                "openssl",
                "s_client",
                "-connect",
                f"{domain}:{port}",
                "-servername",
                domain,
                "-showcerts",
            ],
            input=b"",
            capture_output=True,
            timeout=10,
        )
        cert_text = proc.stdout.decode("utf-8", errors="replace")

        # Extract certificate and parse with openssl x509
        cert_match = re.search(
            r"-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----",
            cert_text,
            re.DOTALL,
        )
        if cert_match:
            cert_pem = cert_match.group(0)
            x509_proc = subprocess.run(
                ["openssl", "x509", "-noout", "-text"],
                input=cert_pem.encode(),
                capture_output=True,
                timeout=5,
            )
            x509_text = x509_proc.stdout.decode("utf-8", errors="replace")

            # Parse issuer
            issuer_match = re.search(r"Issuer:\s*(.+)", x509_text)
            if issuer_match:
                result["issuer"] = issuer_match.group(1).strip()

            # Parse subject
            subject_match = re.search(r"Subject:\s*(.+)", x509_text)
            if subject_match:
                result["subject"] = subject_match.group(1).strip()

            # Parse validity
            not_before = re.search(r"Not Before:\s*(.+)", x509_text)
            if not_before:
                result["not_before"] = not_before.group(1).strip()
            not_after = re.search(r"Not After\s*:\s*(.+)", x509_text)
            if not_after:
                result["not_after"] = not_after.group(1).strip()

            # Parse SAN (Subject Alternative Names)
            san_match = re.search(
                r"X509v3 Subject Alternative Name:\s*\n\s*(.+)",
                x509_text,
            )
            if san_match:
                san_line = san_match.group(1).strip()
                result["san_entries"] = [
                    entry.strip().replace("DNS:", "") for entry in san_line.split(",")
                ]

    except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
        result["error"] = str(exc)

    return result


# ---------------------------------------------------------------------------
# Wayback Machine infrastructure fingerprinting
# ---------------------------------------------------------------------------


def wayback_infrastructure_scan(
    domain: str,
    session=None,
) -> dict:
    """Scan Wayback Machine snapshots for infrastructure fingerprints.

    Looks for shared analytics codes (GA/GTM), CDN providers,
    frameworks, and hosting patterns across historical snapshots.

    Args:
        domain:  Domain to scan.
        session: Optional FingerprintedSession or requests.Session.

    Returns:
        Dict with analytics_codes, cdns, frameworks, and hosting hints.
    """
    if session is None:
        try:
            from core.api_fingerprint import FingerprintedSession

            session = FingerprintedSession(engine_name="infrastructure_forensics")
        except ImportError:
            import requests

            session = requests.Session()

    result: dict = {
        "domain": domain,
        "analytics_codes": [],
        "cdns": [],
        "frameworks": [],
        "snapshot_count": 0,
    }

    # Fetch a recent snapshot from Wayback CDX API
    try:
        cdx_url = (
            f"https://web.archive.org/cdx/search/cdx"
            f"?url={domain}&output=json&limit=5&fl=timestamp,original"
            f"&filter=statuscode:200&sort=reverse"
        )
        resp = session.get(cdx_url, timeout=15)
        if resp.status_code != 200:
            result["error"] = f"CDX API returned {resp.status_code}"
            return result

        rows = resp.json()
        if len(rows) <= 1:
            result["snapshot_count"] = 0
            return result

        result["snapshot_count"] = len(rows) - 1  # First row is header

        # Analyze up to 3 snapshots
        analytics_codes: list[str] = []
        for row in rows[1:4]:
            timestamp = row[0]
            original_url = row[1]
            wb_url = f"https://web.archive.org/web/{timestamp}/{original_url}"

            try:
                snap_resp = session.get(wb_url, timeout=15)
                if snap_resp.status_code == 200:
                    html = snap_resp.text

                    # Google Analytics
                    ga_matches = re.findall(r"UA-\d{4,10}-\d{1,4}", html)
                    analytics_codes.extend(ga_matches)

                    # Google Tag Manager
                    gtm_matches = re.findall(r"GTM-[A-Z0-9]{4,8}", html)
                    analytics_codes.extend(gtm_matches)

                    # Framework detection
                    if "wp-content" in html:
                        result["frameworks"].append("WordPress")
                    if "next/static" in html or "__NEXT_DATA__" in html:
                        result["frameworks"].append("Next.js")
                    if "gatsby" in html.lower():
                        result["frameworks"].append("Gatsby")
                    if "react" in html.lower():
                        result["frameworks"].append("React")

            except Exception as exc:
                logger.debug("Snapshot %s analysis failed: %s", wb_url, exc)

        result["analytics_codes"] = list(set(analytics_codes))

    except Exception as exc:
        result["error"] = str(exc)

    return result


# ---------------------------------------------------------------------------
# Timezone correlation
# ---------------------------------------------------------------------------


def correlate_timezones(repo_timezones: dict[str, dict]) -> dict:
    """Correlate timezone patterns across multiple repositories.

    Takes output from code_forensics.extract_commit_timezones() for
    multiple repos and computes overlap/correlation.

    Args:
        repo_timezones: Dict mapping repo name to timezone analysis dict.

    Returns:
        Dict with timezone_overlap, correlation_score, and shared_peak_hours.
    """
    # Extract dominant timezones
    dominant: dict[str, str] = {}
    peak_hours: dict[str, list[int]] = {}

    for repo, tz_data in repo_timezones.items():
        if tz_data.get("status") != "success":
            continue
        dominant[repo] = tz_data.get("dominant_timezone", "unknown")
        peak_hours[repo] = [h["hour"] for h in tz_data.get("peak_hours", [])[:3]]

    # Compute overlap
    tz_groups: dict[str, list[str]] = defaultdict(list)
    for repo, tz in dominant.items():
        tz_groups[tz].append(repo)

    # Find repos sharing a timezone
    shared_tz: list[dict] = []
    for tz, repos in tz_groups.items():
        if len(repos) > 1:
            shared_tz.append({"timezone": tz, "repos": repos})

    # Peak hour overlap
    repo_names = list(peak_hours.keys())
    hour_overlaps: list[dict] = []
    for i, name_a in enumerate(repo_names):
        for name_b in repo_names[i + 1 :]:
            shared = set(peak_hours[name_a]) & set(peak_hours[name_b])
            if shared:
                hour_overlaps.append(
                    {
                        "repos": [name_a, name_b],
                        "shared_peak_hours": sorted(shared),
                        "overlap_count": len(shared),
                    }
                )

    # Simple correlation score based on timezone + hour overlap
    total_pairs = max(len(repo_names) * (len(repo_names) - 1) // 2, 1)
    tz_match_count = sum(len(g["repos"]) * (len(g["repos"]) - 1) // 2 for g in shared_tz)
    correlation = round(tz_match_count / total_pairs, 3) if total_pairs > 0 else 0.0

    return {
        "repo_count": len(repo_timezones),
        "dominant_timezones": dominant,
        "shared_timezones": shared_tz,
        "peak_hour_overlaps": hour_overlaps,
        "correlation_score": correlation,
    }
