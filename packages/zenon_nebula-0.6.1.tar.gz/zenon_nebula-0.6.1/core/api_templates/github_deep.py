# SPDX-License-Identifier: MIT
"""
Deep GitHub Analysis -- Contributor timelines, code frequency, repo comparison.

Uses `gh api` for authenticated access where available, falls back to
FingerprintedSession with the public GitHub API.

Functions:
    get_contributor_timeline  -- Commit frequency over time per contributor.
    get_code_frequency        -- Weekly additions/deletions for a repo.
    compare_repos             -- Compare activity, languages, contributors.
"""

import json
import logging
import subprocess
import time
from datetime import datetime, timezone

from core.api_fingerprint import FingerprintedSession

logger = logging.getLogger(__name__)

GITHUB_API_BASE = "https://api.github.com"

# Rate limit: stay well under GitHub's 60 req/hour for unauthenticated
_RATE_LIMIT_SECONDS = 1.0
_last_request_time = 0.0


def _rate_limit() -> None:
    """Enforce rate limiting between GitHub API requests."""
    global _last_request_time
    now = time.monotonic()
    elapsed = now - _last_request_time
    if elapsed < _RATE_LIMIT_SECONDS:
        time.sleep(_RATE_LIMIT_SECONDS - elapsed)
    _last_request_time = time.monotonic()


def _gh_api(endpoint: str) -> dict | None:
    """Call GitHub API via gh CLI for authenticated access.

    Falls back to None if gh is not available or returns an error.
    """
    try:
        result = subprocess.run(
            ["gh", "api", endpoint, "--jq", "."],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0 and result.stdout.strip():
            return json.loads(result.stdout)
    except (subprocess.TimeoutExpired, json.JSONDecodeError, FileNotFoundError):
        pass
    return None


def get_contributor_timeline(
    org: str,
    repo: str,
    session: FingerprintedSession | None = None,
) -> dict:
    """Get commit frequency over time for each contributor.

    Uses GitHub's statistics API which provides weekly commit counts
    per contributor.

    Args:
        org:      GitHub organization or user.
        repo:     Repository name.
        session:  FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, repo, contributors (list of dicts with
        login, total_commits, weekly_data), fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="github_deep")

    full_repo = f"{org}/{repo}"

    # Try gh api first for authenticated access
    data = _gh_api(f"repos/{full_repo}/stats/contributors")

    if data is None:
        _rate_limit()
        try:
            resp = session.get(
                f"{GITHUB_API_BASE}/repos/{full_repo}/stats/contributors",
                timeout=30,
            )
            # GitHub returns 202 if stats are being computed
            if resp.status_code == 202:
                time.sleep(3)
                _rate_limit()
                resp = session.get(
                    f"{GITHUB_API_BASE}/repos/{full_repo}/stats/contributors",
                    timeout=30,
                )
            if resp.status_code != 200:
                return {
                    "status": "error",
                    "repo": full_repo,
                    "error": f"HTTP {resp.status_code}",
                    "fingerprints": session.get_fingerprints(),
                }
            data = resp.json()
        except Exception as exc:
            logger.error("Contributor timeline failed for %s: %s", full_repo, exc)
            return {
                "status": "error",
                "repo": full_repo,
                "error": str(exc),
                "fingerprints": session.get_fingerprints(),
            }

    if not isinstance(data, list):
        return {
            "status": "error",
            "repo": full_repo,
            "error": "Unexpected response format",
            "fingerprints": session.get_fingerprints(),
        }

    contributors = []
    for entry in data:
        author = entry.get("author") or {}
        weeks = entry.get("weeks", [])

        # Filter to weeks with actual commits
        active_weeks = [
            {
                "week_start": datetime.fromtimestamp(w["w"], tz=timezone.utc).strftime("%Y-%m-%d"),
                "additions": w.get("a", 0),
                "deletions": w.get("d", 0),
                "commits": w.get("c", 0),
            }
            for w in weeks
            if w.get("c", 0) > 0
        ]

        contributors.append(
            {
                "login": author.get("login", "unknown"),
                "total_commits": entry.get("total", 0),
                "first_active": active_weeks[0]["week_start"] if active_weeks else None,
                "last_active": active_weeks[-1]["week_start"] if active_weeks else None,
                "active_weeks": len(active_weeks),
                "weekly_data": active_weeks,
            }
        )

    # Sort by total commits descending
    contributors.sort(key=lambda c: c["total_commits"], reverse=True)

    return {
        "status": "success",
        "repo": full_repo,
        "contributor_count": len(contributors),
        "contributors": contributors,
        "fingerprints": session.get_fingerprints(),
    }


def get_code_frequency(
    org: str,
    repo: str,
    session: FingerprintedSession | None = None,
) -> dict:
    """Get weekly additions/deletions for a repository.

    Args:
        org:      GitHub organization or user.
        repo:     Repository name.
        session:  FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, repo, weeks (list of dicts with week_start,
        additions, deletions), fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="github_deep")

    full_repo = f"{org}/{repo}"

    data = _gh_api(f"repos/{full_repo}/stats/code_frequency")

    if data is None:
        _rate_limit()
        try:
            resp = session.get(
                f"{GITHUB_API_BASE}/repos/{full_repo}/stats/code_frequency",
                timeout=30,
            )
            if resp.status_code == 202:
                time.sleep(3)
                _rate_limit()
                resp = session.get(
                    f"{GITHUB_API_BASE}/repos/{full_repo}/stats/code_frequency",
                    timeout=30,
                )
            if resp.status_code != 200:
                return {
                    "status": "error",
                    "repo": full_repo,
                    "error": f"HTTP {resp.status_code}",
                    "fingerprints": session.get_fingerprints(),
                }
            data = resp.json()
        except Exception as exc:
            logger.error("Code frequency failed for %s: %s", full_repo, exc)
            return {
                "status": "error",
                "repo": full_repo,
                "error": str(exc),
                "fingerprints": session.get_fingerprints(),
            }

    if not isinstance(data, list):
        return {
            "status": "error",
            "repo": full_repo,
            "error": "Unexpected response format",
            "fingerprints": session.get_fingerprints(),
        }

    weeks = []
    total_additions = 0
    total_deletions = 0
    for entry in data:
        if len(entry) >= 3:
            additions = entry[1]
            deletions = abs(entry[2])
            total_additions += additions
            total_deletions += deletions
            if additions > 0 or deletions > 0:
                weeks.append(
                    {
                        "week_start": datetime.fromtimestamp(entry[0], tz=timezone.utc).strftime(
                            "%Y-%m-%d"
                        ),
                        "additions": additions,
                        "deletions": deletions,
                    }
                )

    return {
        "status": "success",
        "repo": full_repo,
        "total_additions": total_additions,
        "total_deletions": total_deletions,
        "active_weeks": len(weeks),
        "weeks": weeks,
        "fingerprints": session.get_fingerprints(),
    }


def compare_repos(
    repo_a: str,
    repo_b: str,
    session: FingerprintedSession | None = None,
) -> dict:
    """Compare two GitHub repositories on activity, languages, and contributors.

    Args:
        repo_a:   First repo in "org/name" format.
        repo_b:   Second repo in "org/name" format.
        session:  FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, comparison (dict with per-repo stats and diff).
    """
    if session is None:
        session = FingerprintedSession(engine_name="github_deep")

    def _fetch_repo_info(repo_full: str) -> dict | None:
        data = _gh_api(f"repos/{repo_full}")
        if data:
            return data
        _rate_limit()
        try:
            resp = session.get(
                f"{GITHUB_API_BASE}/repos/{repo_full}",
                timeout=15,
            )
            if resp.status_code == 200:
                return resp.json()
        except Exception as exc:
            logger.debug("Repo info fetch failed for %s: %s", repo_full, exc)
        return None

    def _fetch_languages(repo_full: str) -> dict | None:
        """Fetch language breakdown for a repo."""
        data = _gh_api(f"repos/{repo_full}/languages")
        if data:
            return data
        _rate_limit()
        try:
            resp = session.get(
                f"{GITHUB_API_BASE}/repos/{repo_full}/languages",
                timeout=15,
            )
            if resp.status_code == 200:
                return resp.json()
        except Exception as exc:
            logger.debug("Languages fetch failed for %s: %s", repo_full, exc)
        return None

    info_a = _fetch_repo_info(repo_a)
    info_b = _fetch_repo_info(repo_b)

    if not info_a or not info_b:
        return {
            "status": "error",
            "error": f"Could not fetch repo info for {repo_a if not info_a else repo_b}",
            "fingerprints": session.get_fingerprints(),
        }

    langs_a = _fetch_languages(repo_a) or {}
    langs_b = _fetch_languages(repo_b) or {}

    def _extract_stats(info: dict, langs: dict) -> dict:
        return {
            "stars": info.get("stargazers_count", 0),
            "forks": info.get("forks_count", 0),
            "open_issues": info.get("open_issues_count", 0),
            "size_kb": info.get("size", 0),
            "primary_language": info.get("language", "unknown"),
            "languages": langs,
            "created_at": info.get("created_at", ""),
            "updated_at": info.get("updated_at", ""),
            "pushed_at": info.get("pushed_at", ""),
            "default_branch": info.get("default_branch", "main"),
        }

    stats_a = _extract_stats(info_a, langs_a)
    stats_b = _extract_stats(info_b, langs_b)

    # Compute shared languages
    all_langs = set(langs_a.keys()) | set(langs_b.keys())
    shared_langs = set(langs_a.keys()) & set(langs_b.keys())

    return {
        "status": "success",
        "repo_a": {"name": repo_a, **stats_a},
        "repo_b": {"name": repo_b, **stats_b},
        "comparison": {
            "shared_languages": sorted(shared_langs),
            "unique_to_a": sorted(set(langs_a.keys()) - shared_langs),
            "unique_to_b": sorted(set(langs_b.keys()) - shared_langs),
            "language_overlap_pct": (
                round(len(shared_langs) / len(all_langs) * 100, 1) if all_langs else 0
            ),
            "star_ratio": (round(stats_a["stars"] / max(stats_b["stars"], 1), 2)),
        },
        "fingerprints": session.get_fingerprints(),
    }
