# SPDX-License-Identifier: MIT
"""
Code Forensics -- Analyze code style patterns and compare across repos.

Provides utilities for:
- Code style fingerprinting: variable naming, comment density, function
  length distribution, import patterns, error handling style
- Stylometric comparison: similarity matrices across repo fingerprints
- Commit timezone analysis: extract timezone patterns from git log

Generalized from marketing's code_style_fingerprint.py and
stylometric_comparison.py. Domain-agnostic: works with any git repos.

NOT a DiscoveryTemplate -- these are lower-level utilities that any
domain engine or template can call.
"""

import logging
import re
import subprocess
from collections import Counter
from pathlib import Path

logger = logging.getLogger(__name__)

# File extensions to analyze per language
LANGUAGE_EXTENSIONS: dict[str, list[str]] = {
    "python": [".py"],
    "go": [".go"],
    "dart": [".dart"],
    "javascript": [".js", ".jsx"],
    "typescript": [".ts", ".tsx"],
    "rust": [".rs"],
    "java": [".java"],
}

# Directories to skip during analysis
SKIP_DIRS = frozenset(
    {
        ".git",
        "node_modules",
        "vendor",
        "build",
        "dist",
        "__pycache__",
        ".dart_tool",
        ".pub-cache",
        "packages",
        "target",
        "venv",
        ".venv",
    }
)

MAX_FILES_PER_REPO = 200
MAX_FILE_SIZE_BYTES = 500_000


# ---------------------------------------------------------------------------
# Code style fingerprinting
# ---------------------------------------------------------------------------


def fingerprint_repo(repo_path: Path) -> dict:
    """Generate a code style fingerprint for a repository.

    Analyzes all source files (up to MAX_FILES_PER_REPO) and produces
    a fingerprint dict with:
    - naming_style: camelCase vs snake_case ratios
    - comment_density: comments per line of code
    - avg_function_length: average lines per function
    - import_patterns: top import patterns
    - error_handling_style: try/except patterns
    - language_distribution: lines per language

    Args:
        repo_path: Path to the git repository root.

    Returns:
        Dict with fingerprint data.
    """
    if not repo_path.is_dir():
        return {"status": "not_found", "path": str(repo_path)}

    files = _collect_source_files(repo_path)
    if not files:
        return {"status": "no_source_files", "path": str(repo_path)}

    # Aggregate metrics across all files
    total_lines = 0
    total_comments = 0
    total_functions = 0
    total_function_lines = 0
    naming_counts = Counter()
    import_patterns: list[str] = []
    error_handling_count = 0
    language_lines: dict[str, int] = {}

    for file_path, language in files:
        try:
            content = file_path.read_text(errors="replace")
            lines = content.splitlines()
        except OSError:
            continue

        line_count = len(lines)
        total_lines += line_count
        language_lines[language] = language_lines.get(language, 0) + line_count

        # Comment density
        comment_count = sum(1 for line in lines if _is_comment(line, language))
        total_comments += comment_count

        # Naming style
        identifiers = _extract_identifiers(content)
        for ident in identifiers:
            if "_" in ident and ident.lower() == ident:
                naming_counts["snake_case"] += 1
            elif any(c.isupper() for c in ident[1:]):
                naming_counts["camelCase"] += 1

        # Function lengths
        func_lengths = _extract_function_lengths(content, language)
        total_functions += len(func_lengths)
        total_function_lines += sum(func_lengths)

        # Import patterns
        import_patterns.extend(_extract_imports(content, language))

        # Error handling
        error_handling_count += content.count("try:") + content.count("try {")
        error_handling_count += content.count("catch") + content.count("except")

    # Build fingerprint
    total_naming = sum(naming_counts.values()) or 1
    fingerprint = {
        "status": "success",
        "repo": repo_path.name,
        "file_count": len(files),
        "total_lines": total_lines,
        "naming_style": {
            "snake_case_ratio": round(naming_counts.get("snake_case", 0) / total_naming, 3),
            "camelCase_ratio": round(naming_counts.get("camelCase", 0) / total_naming, 3),
        },
        "comment_density": round(total_comments / max(total_lines, 1), 4),
        "avg_function_length": (round(total_function_lines / max(total_functions, 1), 1)),
        "function_count": total_functions,
        "error_handling_density": round(error_handling_count / max(total_lines, 1) * 100, 3),
        "top_imports": Counter(import_patterns).most_common(10),
        "language_distribution": language_lines,
    }

    return fingerprint


def compute_similarity(fp_a: dict, fp_b: dict) -> float:
    """Compute similarity score (0.0-1.0) between two repo fingerprints.

    Compares naming style, comment density, function length, and
    error handling density using weighted cosine-like distance.

    Args:
        fp_a: First fingerprint dict (from fingerprint_repo).
        fp_b: Second fingerprint dict (from fingerprint_repo).

    Returns:
        Similarity score between 0.0 (very different) and 1.0 (identical).
    """
    if fp_a.get("status") != "success" or fp_b.get("status") != "success":
        return 0.0

    scores: list[float] = []

    # Naming style similarity
    a_snake = fp_a.get("naming_style", {}).get("snake_case_ratio", 0)
    b_snake = fp_b.get("naming_style", {}).get("snake_case_ratio", 0)
    scores.append(1.0 - abs(a_snake - b_snake))

    # Comment density similarity
    a_cd = fp_a.get("comment_density", 0)
    b_cd = fp_b.get("comment_density", 0)
    max_cd = max(a_cd, b_cd, 0.001)
    scores.append(1.0 - abs(a_cd - b_cd) / max_cd)

    # Function length similarity
    a_fl = fp_a.get("avg_function_length", 0)
    b_fl = fp_b.get("avg_function_length", 0)
    max_fl = max(a_fl, b_fl, 1.0)
    scores.append(1.0 - abs(a_fl - b_fl) / max_fl)

    # Error handling density similarity
    a_eh = fp_a.get("error_handling_density", 0)
    b_eh = fp_b.get("error_handling_density", 0)
    max_eh = max(a_eh, b_eh, 0.001)
    scores.append(1.0 - abs(a_eh - b_eh) / max_eh)

    return round(sum(scores) / len(scores), 4) if scores else 0.0


def build_similarity_matrix(fingerprints: dict[str, dict]) -> dict[str, float]:
    """Build a pairwise similarity matrix from multiple fingerprints.

    Args:
        fingerprints: Dict mapping repo name to fingerprint dict.

    Returns:
        Dict mapping "repo_a <-> repo_b" to similarity score.
    """
    names = [n for n, fp in fingerprints.items() if fp.get("status") == "success"]
    matrix: dict[str, float] = {}

    for i, name_a in enumerate(names):
        for name_b in names[i + 1 :]:
            sim = compute_similarity(fingerprints[name_a], fingerprints[name_b])
            matrix[f"{name_a} <-> {name_b}"] = sim

    return matrix


# ---------------------------------------------------------------------------
# Commit timezone analysis
# ---------------------------------------------------------------------------


def extract_commit_timezones(repo_path: Path, limit: int = 500) -> dict:
    """Extract timezone offset distribution from git commit timestamps.

    Args:
        repo_path: Path to the git repository.
        limit:     Maximum number of commits to analyze.

    Returns:
        Dict with timezone_distribution (offset -> count), peak_hours,
        and inferred_region.
    """
    if not (repo_path / ".git").is_dir():
        return {"status": "not_a_git_repo"}

    try:
        result = subprocess.run(
            ["git", "log", f"--max-count={limit}", "--format=%aI"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            return {"status": "git_log_failed", "error": result.stderr[:200]}

        offsets: Counter = Counter()
        hours: Counter = Counter()

        for line in result.stdout.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            # Parse ISO timestamp like 2025-05-15T10:30:00+02:00
            match = re.search(r"([+-]\d{2}:\d{2})$", line)
            if match:
                offsets[match.group(1)] += 1
            # Extract hour
            hour_match = re.search(r"T(\d{2}):", line)
            if hour_match:
                hours[int(hour_match.group(1))] += 1

        # Peak working hours
        peak_hours = sorted(hours.items(), key=lambda x: -x[1])[:5]

        return {
            "status": "success",
            "commit_count": sum(offsets.values()),
            "timezone_distribution": dict(offsets.most_common()),
            "peak_hours": [{"hour": h, "count": c} for h, c in peak_hours],
            "dominant_timezone": offsets.most_common(1)[0][0] if offsets else "unknown",
        }

    except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
        return {"status": "error", "error": str(exc)}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _collect_source_files(
    repo_path: Path,
) -> list[tuple[Path, str]]:
    """Collect source files from a repo, respecting skip dirs and limits."""
    files: list[tuple[Path, str]] = []
    count = 0

    for lang, exts in LANGUAGE_EXTENSIONS.items():
        for ext in exts:
            for fp in repo_path.rglob(f"*{ext}"):
                if count >= MAX_FILES_PER_REPO:
                    return files
                if any(skip in fp.parts for skip in SKIP_DIRS):
                    continue
                if fp.stat().st_size > MAX_FILE_SIZE_BYTES:
                    continue
                files.append((fp, lang))
                count += 1

    return files


def _is_comment(line: str, language: str) -> bool:
    """Check if a line is a comment."""
    stripped = line.strip()
    if not stripped:
        return False
    if language in ("python",):
        return stripped.startswith("#")
    if language in ("go", "dart", "javascript", "typescript", "rust", "java"):
        return stripped.startswith("//") or stripped.startswith("/*") or stripped.startswith("*")
    return False


def _extract_identifiers(content: str) -> list[str]:
    """Extract likely identifiers from source code."""
    # Match word-like tokens that look like variable/function names
    return re.findall(r"\b([a-zA-Z_][a-zA-Z0-9_]{2,30})\b", content)


def _extract_function_lengths(content: str, language: str) -> list[int]:
    """Estimate function/method lengths in lines."""
    lengths: list[int] = []

    if language == "python":
        # Rough: count lines between def/class declarations
        lines = content.splitlines()
        current_length = 0
        in_function = False
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("def ") or stripped.startswith("async def "):
                if in_function and current_length > 0:
                    lengths.append(current_length)
                in_function = True
                current_length = 0
            elif in_function:
                current_length += 1
        if in_function and current_length > 0:
            lengths.append(current_length)

    elif language in ("go", "dart", "javascript", "typescript", "java", "rust"):
        # Rough: count lines between func/fn declarations and closing brace
        lines = content.splitlines()
        brace_depth = 0
        current_length = 0
        in_function = False
        for line in lines:
            stripped = line.strip()
            if re.match(r"(func |fn |function |def )", stripped):
                in_function = True
                current_length = 0
                brace_depth = 0
            if in_function:
                current_length += 1
                brace_depth += stripped.count("{") - stripped.count("}")
                if brace_depth <= 0 and current_length > 1:
                    lengths.append(current_length)
                    in_function = False

    return lengths


def _extract_imports(content: str, language: str) -> list[str]:
    """Extract import statements."""
    imports: list[str] = []
    for line in content.splitlines():
        stripped = line.strip()
        if language == "python" and (
            stripped.startswith("import ") or stripped.startswith("from ")
        ):
            # Normalize to top-level package
            parts = stripped.split()
            if len(parts) >= 2:
                pkg = parts[1].split(".")[0]
                imports.append(pkg)
        elif language == "go" and stripped.startswith('"'):
            pkg = stripped.strip('"').split("/")[-1]
            imports.append(pkg)
        elif language in ("dart",) and stripped.startswith("import "):
            imports.append(stripped)
    return imports
