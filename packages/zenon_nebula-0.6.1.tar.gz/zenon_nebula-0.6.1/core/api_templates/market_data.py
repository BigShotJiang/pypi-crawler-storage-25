# SPDX-License-Identifier: MIT
"""
Market & DeFi Data Templates -- DexScreener, CoinGecko, Uniswap pool info.

All calls go through FingerprintedSession for provenance. Uses free/public
endpoints only -- no API keys required.

Functions:
    get_dexscreener_pair  -- Price, volume, liquidity for a DEX pair.
    get_coingecko_data    -- Market cap, price, 24h change for a coin.
    get_uniswap_pool      -- Reserves and TVL for a Uniswap V3 pool.
"""

import contextlib
import logging
import time

from core.api_fingerprint import FingerprintedSession

logger = logging.getLogger(__name__)

DEXSCREENER_BASE = "https://api.dexscreener.com/latest/dex"
COINGECKO_BASE = "https://api.coingecko.com/api/v3"

_RATE_LIMIT_SECONDS = 1.0
_last_request_time = 0.0


def _rate_limit() -> None:
    """Enforce rate limiting between requests."""
    global _last_request_time
    now = time.monotonic()
    elapsed = now - _last_request_time
    if elapsed < _RATE_LIMIT_SECONDS:
        time.sleep(_RATE_LIMIT_SECONDS - elapsed)
    _last_request_time = time.monotonic()


def get_dexscreener_pair(
    pair_address: str,
    chain: str = "ethereum",
    session: FingerprintedSession | None = None,
) -> dict:
    """Fetch DEX pair data from DexScreener.

    Args:
        pair_address:  The pair/pool contract address.
        chain:         Blockchain name (e.g. "ethereum", "bsc").
        session:       FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, pair_address, price_usd, volume_24h,
        liquidity_usd, price_change_h1, price_change_h24, fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="dexscreener")

    _rate_limit()
    try:
        resp = session.get(
            f"{DEXSCREENER_BASE}/pairs/{chain}/{pair_address}",
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()

        pair = data.get("pair") or (data.get("pairs", [{}])[0] if data.get("pairs") else {})
        if not pair:
            return {
                "status": "not_found",
                "pair_address": pair_address,
                "chain": chain,
                "fingerprints": session.get_fingerprints(),
            }

        return {
            "status": "success",
            "pair_address": pair_address,
            "chain": chain,
            "base_token": pair.get("baseToken", {}).get("symbol", ""),
            "quote_token": pair.get("quoteToken", {}).get("symbol", ""),
            "price_usd": float(pair.get("priceUsd", 0) or 0),
            "price_native": float(pair.get("priceNative", 0) or 0),
            "volume_h24": float(pair.get("volume", {}).get("h24", 0) or 0),
            "volume_h6": float(pair.get("volume", {}).get("h6", 0) or 0),
            "volume_h1": float(pair.get("volume", {}).get("h1", 0) or 0),
            "liquidity_usd": float(pair.get("liquidity", {}).get("usd", 0) or 0),
            "price_change_h1": float(pair.get("priceChange", {}).get("h1", 0) or 0),
            "price_change_h6": float(pair.get("priceChange", {}).get("h6", 0) or 0),
            "price_change_h24": float(pair.get("priceChange", {}).get("h24", 0) or 0),
            "txns_h24_buys": pair.get("txns", {}).get("h24", {}).get("buys", 0),
            "txns_h24_sells": pair.get("txns", {}).get("h24", {}).get("sells", 0),
            "fdv": float(pair.get("fdv", 0) or 0),
            "market_cap": float(pair.get("marketCap", 0) or 0),
            "dex_id": pair.get("dexId", ""),
            "pair_url": pair.get("url", ""),
            "fingerprints": session.get_fingerprints(),
        }

    except Exception as exc:
        logger.error("DexScreener query failed for %s: %s", pair_address, exc)
        return {
            "status": "error",
            "pair_address": pair_address,
            "error": str(exc),
            "fingerprints": session.get_fingerprints(),
        }


def get_coingecko_data(
    coin_id: str,
    session: FingerprintedSession | None = None,
) -> dict:
    """Fetch coin data from CoinGecko (free API, no key required).

    Args:
        coin_id:  CoinGecko coin ID (e.g. "zenon-2", "bitcoin").
        session:  FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, coin_id, price_usd, market_cap, volume_24h,
        price_change_24h_pct, ath, atl, fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="coingecko")

    _rate_limit()
    try:
        resp = session.get(
            f"{COINGECKO_BASE}/coins/{coin_id}",
            params={
                "localization": "false",
                "tickers": "false",
                "community_data": "false",
                "developer_data": "false",
            },
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()

        market = data.get("market_data", {})

        return {
            "status": "success",
            "coin_id": coin_id,
            "name": data.get("name", ""),
            "symbol": data.get("symbol", ""),
            "price_usd": market.get("current_price", {}).get("usd", 0),
            "market_cap_usd": market.get("market_cap", {}).get("usd", 0),
            "volume_24h_usd": market.get("total_volume", {}).get("usd", 0),
            "price_change_24h_pct": market.get("price_change_percentage_24h", 0),
            "price_change_7d_pct": market.get("price_change_percentage_7d", 0),
            "price_change_30d_pct": market.get("price_change_percentage_30d", 0),
            "ath_usd": market.get("ath", {}).get("usd", 0),
            "ath_date": market.get("ath_date", {}).get("usd", ""),
            "atl_usd": market.get("atl", {}).get("usd", 0),
            "atl_date": market.get("atl_date", {}).get("usd", ""),
            "circulating_supply": market.get("circulating_supply", 0),
            "total_supply": market.get("total_supply", 0),
            "max_supply": market.get("max_supply"),
            "fully_diluted_valuation": market.get("fully_diluted_valuation", {}).get("usd", 0),
            "fingerprints": session.get_fingerprints(),
        }

    except Exception as exc:
        logger.error("CoinGecko query failed for %s: %s", coin_id, exc)
        return {
            "status": "error",
            "coin_id": coin_id,
            "error": str(exc),
            "fingerprints": session.get_fingerprints(),
        }


def get_uniswap_pool(
    pool_address: str,
    rpc_url: str = "https://eth.llamarpc.com",
    session: FingerprintedSession | None = None,
) -> dict:
    """Query a Uniswap V3 pool for basic info via JSON-RPC.

    Uses eth_call to read the pool contract's slot0 and liquidity.
    This is a simplified query -- for full pool analytics, use a
    subgraph or dedicated API.

    Args:
        pool_address:  Uniswap V3 pool contract address.
        rpc_url:       Ethereum JSON-RPC endpoint.
        session:       FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, pool_address, liquidity_raw, slot0_raw, fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="uniswap_pool")

    try:
        # slot0() selector = 0x3850c7bd
        _rate_limit()
        resp_slot0 = session.post(
            rpc_url,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "eth_call",
                "params": [
                    {"to": pool_address, "data": "0x3850c7bd"},
                    "latest",
                ],
            },
            timeout=15,
        )
        resp_slot0.raise_for_status()
        slot0_raw = resp_slot0.json().get("result", "0x")

        # liquidity() selector = 0x1a686502
        _rate_limit()
        resp_liq = session.post(
            rpc_url,
            json={
                "jsonrpc": "2.0",
                "id": 2,
                "method": "eth_call",
                "params": [
                    {"to": pool_address, "data": "0x1a686502"},
                    "latest",
                ],
            },
            timeout=15,
        )
        resp_liq.raise_for_status()
        liquidity_raw = resp_liq.json().get("result", "0x")

        # Parse liquidity (uint128)
        liquidity = 0
        if liquidity_raw and liquidity_raw != "0x":
            with contextlib.suppress(ValueError):
                liquidity = int(liquidity_raw, 16)

        return {
            "status": "success",
            "pool_address": pool_address,
            "liquidity_raw": liquidity_raw,
            "liquidity": liquidity,
            "slot0_raw": slot0_raw,
            "fingerprints": session.get_fingerprints(),
        }

    except Exception as exc:
        logger.error("Uniswap pool query failed for %s: %s", pool_address, exc)
        return {
            "status": "error",
            "pool_address": pool_address,
            "error": str(exc),
            "fingerprints": session.get_fingerprints(),
        }
