# SPDX-License-Identifier: MIT
"""
On-Chain Forensics -- Address clustering and transaction pattern analysis.

Provides utilities for:
- Bitcoin address clustering via common-input-ownership heuristic
- Transaction temporal pattern detection (time-of-day, day-of-week)
- Address activity timeline construction

Uses Blockstream Esplora API for Bitcoin data. Domain-agnostic: works
with any set of Bitcoin addresses.

NOT a DiscoveryTemplate -- these are lower-level utilities that any
domain engine or template can call.

Generalized from marketing's address_clustering.py and btc_temporal_scan.py.
"""

import logging
from collections import Counter, defaultdict
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

ESPLORA_BASE = "https://blockstream.info/api"


# ---------------------------------------------------------------------------
# Address clustering (common-input-ownership)
# ---------------------------------------------------------------------------


def cluster_addresses(
    addresses: list[str],
    session=None,
) -> dict:
    """Group Bitcoin addresses by common-input-ownership heuristic.

    For each address, fetches transactions from Esplora and identifies
    cases where multiple target addresses appear as inputs in the same
    transaction -- implying common ownership.

    Args:
        addresses: List of Bitcoin addresses to analyze.
        session:   Optional FingerprintedSession or requests.Session.

    Returns:
        Dict with clusters, linking_evidence, and address_tx_counts.
    """
    if session is None:
        session = _get_session("address_clustering")

    address_set = set(addresses)
    address_txs: dict[str, list[str]] = {}
    links: list[dict] = []

    for addr in addresses:
        logger.debug("Fetching transactions for %s...", addr[:16])
        try:
            resp = session.get(f"{ESPLORA_BASE}/address/{addr}/txs", timeout=15)
            resp.raise_for_status()
            txs = resp.json()

            txids: list[str] = []
            for tx in txs:
                txid = tx.get("txid", "")
                txids.append(txid)

                # Extract all input addresses
                input_addrs: set[str] = set()
                for vin in tx.get("vin", []):
                    prevout = vin.get("prevout", {})
                    input_addr = prevout.get("scriptpubkey_address")
                    if input_addr:
                        input_addrs.add(input_addr)

                # Check if multiple target addresses co-appear as inputs
                overlap = input_addrs & address_set
                if len(overlap) > 1:
                    links.append(
                        {
                            "txid": txid,
                            "co_spent_addresses": sorted(overlap),
                            "all_input_count": len(input_addrs),
                            "output_count": len(tx.get("vout", [])),
                            "block_height": tx.get("status", {}).get("block_height"),
                        }
                    )

                address_txs[addr] = txids

        except Exception as exc:
            logger.warning("Failed to fetch txs for %s: %s", addr[:16], exc)
            address_txs[addr] = []

    # Build clusters using union-find
    clusters = _union_find_clusters(addresses, links)

    return {
        "address_count": len(addresses),
        "link_count": len(links),
        "clusters": clusters,
        "linking_evidence": links,
        "address_tx_counts": {addr: len(txids) for addr, txids in address_txs.items()},
    }


def _union_find_clusters(
    addresses: list[str],
    links: list[dict],
) -> list[list[str]]:
    """Build clusters from linking evidence using union-find."""
    parent: dict[str, str] = {addr: addr for addr in addresses}

    def find(x: str) -> str:
        """Find root representative with path compression."""
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: str, b: str) -> None:
        """Merge the sets containing a and b."""
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for link in links:
        addrs = link.get("co_spent_addresses", [])
        for i in range(len(addrs) - 1):
            if addrs[i] in parent and addrs[i + 1] in parent:
                union(addrs[i], addrs[i + 1])

    # Group by root
    groups: dict[str, list[str]] = defaultdict(list)
    for addr in addresses:
        root = find(addr)
        groups[root].append(addr)

    # Return clusters with more than one member first, then singletons
    multi = [sorted(g) for g in groups.values() if len(g) > 1]
    singles = [sorted(g) for g in groups.values() if len(g) == 1]
    return multi + singles


# ---------------------------------------------------------------------------
# Transaction temporal patterns
# ---------------------------------------------------------------------------


def analyze_temporal_patterns(
    addresses: list[str],
    session=None,
) -> dict:
    """Analyze time-of-day and day-of-week patterns in transactions.

    For each address, fetches confirmed transactions and extracts
    block timestamps to build temporal distribution.

    Args:
        addresses: List of Bitcoin addresses.
        session:   Optional HTTP session.

    Returns:
        Dict with hour_distribution, day_distribution, and activity_timeline.
    """
    if session is None:
        session = _get_session("temporal_patterns")

    hour_counts: Counter = Counter()
    day_counts: Counter = Counter()
    timeline: list[dict] = []

    for addr in addresses:
        try:
            resp = session.get(f"{ESPLORA_BASE}/address/{addr}/txs", timeout=15)
            if resp.status_code != 200:
                continue

            txs = resp.json()
            for tx in txs:
                status = tx.get("status", {})
                if not status.get("confirmed"):
                    continue
                block_time = status.get("block_time")
                if not block_time:
                    continue

                dt = datetime.fromtimestamp(block_time, tz=timezone.utc)
                hour_counts[dt.hour] += 1
                day_counts[dt.strftime("%A")] += 1

                # Determine if this address is sender or receiver
                is_sender = any(
                    vin.get("prevout", {}).get("scriptpubkey_address") == addr
                    for vin in tx.get("vin", [])
                )
                is_receiver = any(
                    vout.get("scriptpubkey_address") == addr for vout in tx.get("vout", [])
                )

                timeline.append(
                    {
                        "address": addr[:16] + "...",
                        "txid": tx.get("txid", "")[:16] + "...",
                        "timestamp": dt.isoformat(),
                        "hour": dt.hour,
                        "day": dt.strftime("%A"),
                        "direction": (
                            "send"
                            if is_sender and not is_receiver
                            else "receive"
                            if is_receiver and not is_sender
                            else "self_transfer"
                        ),
                        "block_height": status.get("block_height"),
                    }
                )

        except Exception as exc:
            logger.debug("Temporal analysis failed for %s: %s", addr[:16], exc)

    # Sort timeline chronologically
    timeline.sort(key=lambda x: x.get("timestamp", ""))

    # Peak activity hours
    peak_hours = sorted(hour_counts.items(), key=lambda x: -x[1])[:5]

    return {
        "address_count": len(addresses),
        "transaction_count": len(timeline),
        "hour_distribution": dict(sorted(hour_counts.items())),
        "day_distribution": dict(day_counts.most_common()),
        "peak_hours": [{"hour": h, "count": c} for h, c in peak_hours],
        "activity_timeline": timeline[:100],  # Limit for size
    }


# ---------------------------------------------------------------------------
# Address activity timeline
# ---------------------------------------------------------------------------


def address_activity_summary(
    address: str,
    session=None,
) -> dict:
    """Build a comprehensive activity summary for a single Bitcoin address.

    Args:
        address: Bitcoin address.
        session: Optional HTTP session.

    Returns:
        Dict with balance, tx_count, first/last activity, and value flows.
    """
    if session is None:
        session = _get_session("address_activity")

    result: dict = {
        "address": address,
        "funded_txo_count": 0,
        "spent_txo_count": 0,
        "total_received_sat": 0,
        "total_sent_sat": 0,
        "balance_sat": 0,
        "first_seen": None,
        "last_seen": None,
    }

    try:
        resp = session.get(f"{ESPLORA_BASE}/address/{address}", timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            chain = data.get("chain_stats", {})
            mempool = data.get("mempool_stats", {})

            result["funded_txo_count"] = chain.get("funded_txo_count", 0)
            result["spent_txo_count"] = chain.get("spent_txo_count", 0)
            result["total_received_sat"] = chain.get("funded_txo_sum", 0)
            result["total_sent_sat"] = chain.get("spent_txo_sum", 0)
            result["balance_sat"] = (
                chain.get("funded_txo_sum", 0)
                - chain.get("spent_txo_sum", 0)
                + mempool.get("funded_txo_sum", 0)
                - mempool.get("spent_txo_sum", 0)
            )

        # Get first and last transaction timestamps
        txs_resp = session.get(
            f"{ESPLORA_BASE}/address/{address}/txs",
            timeout=15,
        )
        if txs_resp.status_code == 200:
            txs = txs_resp.json()
            timestamps = []
            for tx in txs:
                bt = tx.get("status", {}).get("block_time")
                if bt:
                    timestamps.append(bt)
            if timestamps:
                result["first_seen"] = datetime.fromtimestamp(
                    min(timestamps),
                    tz=timezone.utc,
                ).isoformat()
                result["last_seen"] = datetime.fromtimestamp(
                    max(timestamps),
                    tz=timezone.utc,
                ).isoformat()

    except Exception as exc:
        result["error"] = str(exc)

    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _get_session(engine_name: str):
    """Get a session, preferring FingerprintedSession if available."""
    try:
        from core.api_fingerprint import FingerprintedSession

        return FingerprintedSession(engine_name=engine_name)
    except ImportError:
        import requests

        return requests.Session()
