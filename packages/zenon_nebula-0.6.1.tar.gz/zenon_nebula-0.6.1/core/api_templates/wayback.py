# SPDX-License-Identifier: MIT
"""
Wayback Machine CDX API -- Search and fetch archived web snapshots.

Uses the public CDX server at web.archive.org. All calls go through
FingerprintedSession for provenance.

Functions:
    search_snapshots  -- Search CDX index for archived snapshots of a URL.
    get_snapshot_content -- Fetch the HTML of a specific archived snapshot.
"""

import logging
import re
import time

from core.api_fingerprint import FingerprintedSession

logger = logging.getLogger(__name__)

CDX_API = "https://web.archive.org/cdx/search/cdx"
WAYBACK_BASE = "https://web.archive.org/web"

# Rate limit: 1 request per second to be polite to the Internet Archive
_RATE_LIMIT_SECONDS = 1.0
_last_request_time = 0.0


def _rate_limit() -> None:
    """Enforce rate limiting between requests."""
    global _last_request_time
    now = time.monotonic()
    elapsed = now - _last_request_time
    if elapsed < _RATE_LIMIT_SECONDS:
        time.sleep(_RATE_LIMIT_SECONDS - elapsed)
    _last_request_time = time.monotonic()


def search_snapshots(
    url: str,
    from_date: str | None = None,
    to_date: str | None = None,
    limit: int = 50,
    session: FingerprintedSession | None = None,
) -> dict:
    """Search the Wayback Machine CDX API for archived snapshots.

    Args:
        url:        The URL to search for.
        from_date:  Start date in YYYYMMDD format (inclusive).
        to_date:    End date in YYYYMMDD format (inclusive).
        limit:      Maximum number of results.
        session:    FingerprintedSession (created if not provided).

    Returns:
        Dict with keys: status, url, snapshot_count, snapshots, fingerprints.
        Each snapshot has: timestamp, original, statuscode, mimetype, wayback_url.
    """
    if session is None:
        session = FingerprintedSession(engine_name="wayback_cdx")

    _rate_limit()

    params = {
        "url": url,
        "output": "json",
        "limit": limit,
        "fl": "timestamp,original,statuscode,mimetype,digest,length",
    }
    if from_date:
        params["from"] = from_date
    if to_date:
        params["to"] = to_date

    try:
        resp = session.get(CDX_API, params=params, timeout=30)
        resp.raise_for_status()
        data = resp.json()

        if not data or len(data) < 2:
            return {
                "status": "no_results",
                "url": url,
                "snapshot_count": 0,
                "snapshots": [],
                "fingerprints": session.get_fingerprints(),
            }

        headers = data[0]
        snapshots = []
        for row in data[1:]:
            entry = dict(zip(headers, row, strict=False))
            ts = entry.get("timestamp", "")
            entry["wayback_url"] = f"{WAYBACK_BASE}/{ts}/{entry.get('original', url)}"
            if len(ts) >= 8:
                entry["date_human"] = f"{ts[:4]}-{ts[4:6]}-{ts[6:8]}"
            snapshots.append(entry)

        return {
            "status": "success",
            "url": url,
            "snapshot_count": len(snapshots),
            "first_snapshot": snapshots[0].get("timestamp", ""),
            "last_snapshot": snapshots[-1].get("timestamp", ""),
            "snapshots": snapshots,
            "fingerprints": session.get_fingerprints(),
        }

    except Exception as exc:
        logger.error("Wayback CDX search failed for %s: %s", url, exc)
        return {
            "status": "error",
            "url": url,
            "error": str(exc),
            "fingerprints": session.get_fingerprints(),
        }


def get_snapshot_content(
    url: str,
    timestamp: str | None = None,
    session: FingerprintedSession | None = None,
) -> dict:
    """Fetch archived page content from the Wayback Machine.

    If no timestamp is given, finds the most recent available snapshot.

    Args:
        url:        The original URL.
        timestamp:  Wayback timestamp (YYYYMMDDhhmmss). None for latest.
        session:    FingerprintedSession (created if not provided).

    Returns:
        Dict with: status, url, timestamp, html, html_size_bytes,
        analysis (meta_tags, social_links, emails, etc.), fingerprints.
    """
    if session is None:
        session = FingerprintedSession(engine_name="wayback_snapshot")

    _rate_limit()

    try:
        if not timestamp:
            timestamp = _find_latest_snapshot(session, url)
            if not timestamp:
                return {
                    "status": "no_snapshots",
                    "url": url,
                    "error": "No snapshots found",
                    "fingerprints": session.get_fingerprints(),
                }

        # id_ suffix prevents Wayback toolbar injection
        wayback_url = f"{WAYBACK_BASE}/{timestamp}id_/{url}"
        _rate_limit()
        resp = session.get(wayback_url, timeout=30)

        if resp.status_code != 200:
            return {
                "status": "fetch_failed",
                "url": url,
                "timestamp": timestamp,
                "status_code": resp.status_code,
                "fingerprints": session.get_fingerprints(),
            }

        html = resp.text
        analysis = _analyze_html(html)

        return {
            "status": "success",
            "url": url,
            "timestamp": timestamp,
            "wayback_url": wayback_url.replace("id_/", "/"),
            "html_size_bytes": len(html),
            "html": html[:50000],  # Cap to prevent memory issues
            "analysis": analysis,
            "fingerprints": session.get_fingerprints(),
        }

    except Exception as exc:
        logger.error("Wayback snapshot failed for %s: %s", url, exc)
        return {
            "status": "error",
            "url": url,
            "error": str(exc),
            "fingerprints": session.get_fingerprints(),
        }


def _find_latest_snapshot(
    session: FingerprintedSession,
    url: str,
) -> str | None:
    """Find the most recent snapshot timestamp via CDX API."""
    _rate_limit()
    resp = session.get(
        CDX_API,
        params={
            "url": url,
            "output": "json",
            "limit": 1,
            "sort": "reverse",
            "fl": "timestamp",
        },
        timeout=15,
    )
    if resp.status_code != 200:
        return None
    data = resp.json()
    if len(data) >= 2:
        return data[1][0]
    return None


def _analyze_html(html: str) -> dict:
    """Extract forensic signals from archived HTML."""
    return {
        "analytics_codes": _extract_analytics(html),
        "meta_tags": _extract_meta_tags(html),
        "social_links": _extract_social_links(html),
        "emails": _extract_emails(html),
        "title": _extract_title(html),
    }


def _extract_analytics(html: str) -> list[dict]:
    """Extract tracking codes (GA, GTM, Facebook Pixel, etc.)."""
    codes = []
    for match in re.finditer(r"UA-(\d{4,10})-(\d{1,4})", html):
        codes.append({"type": "google_analytics_ua", "code": match.group(0)})
    for match in re.finditer(r"G-[A-Z0-9]{8,12}", html):
        codes.append({"type": "google_analytics_ga4", "code": match.group(0)})
    for match in re.finditer(r"GTM-[A-Z0-9]{4,8}", html):
        codes.append({"type": "google_tag_manager", "code": match.group(0)})
    for match in re.finditer(r"fbq\s*\(\s*['\"]init['\"],\s*['\"](\d+)['\"]", html):
        codes.append({"type": "facebook_pixel", "code": match.group(1)})

    # Deduplicate
    seen = set()
    unique = []
    for c in codes:
        key = (c["type"], c["code"])
        if key not in seen:
            seen.add(key)
            unique.append(c)
    return unique


def _extract_meta_tags(html: str) -> dict:
    """Extract meta tags (og:, twitter:, description, etc.)."""
    tags = {}
    for match in re.finditer(
        r'<meta\s+(?:name|property)=["\']([^"\']+)["\']\s+content=["\']([^"\']*)["\']',
        html,
        re.IGNORECASE,
    ):
        tags[match.group(1)] = match.group(2)[:200]
    for match in re.finditer(
        r'<meta\s+content=["\']([^"\']*?)["\']\s+(?:name|property)=["\']([^"\']+)["\']',
        html,
        re.IGNORECASE,
    ):
        tags[match.group(2)] = match.group(1)[:200]
    return tags


def _extract_social_links(html: str) -> list[dict]:
    """Extract social media links."""
    patterns = {
        "twitter": r"https?://(?:www\.)?(?:twitter\.com|x\.com)/([A-Za-z0-9_]+)",
        "telegram": r"https?://(?:www\.)?t\.me/([A-Za-z0-9_]+)",
        "discord": r"https?://(?:www\.)?discord\.(?:gg|com/invite)/([A-Za-z0-9_-]+)",
        "github": r"https?://(?:www\.)?github\.com/([A-Za-z0-9_-]+(?:/[A-Za-z0-9_.-]+)?)",
        "medium": r"https?://(?:www\.)?medium\.com/@?([A-Za-z0-9_.-]+)",
        "reddit": r"https?://(?:www\.)?reddit\.com/r/([A-Za-z0-9_]+)",
    }
    links = []
    seen = set()
    for platform, pattern in patterns.items():
        for match in re.finditer(pattern, html):
            handle = match.group(1)
            key = (platform, handle.lower())
            if key not in seen:
                seen.add(key)
                links.append(
                    {
                        "platform": platform,
                        "handle": handle,
                        "url": match.group(0),
                    }
                )
    return links


def _extract_emails(html: str) -> list[str]:
    """Extract email addresses."""
    pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
    emails = list(set(re.findall(pattern, html)))
    filtered = [
        e
        for e in emails
        if not e.endswith((".png", ".jpg", ".gif", ".svg")) and "example.com" not in e
    ]
    return sorted(filtered)


def _extract_title(html: str) -> str:
    """Extract page title."""
    match = re.search(r"<title[^>]*>(.*?)</title>", html, re.IGNORECASE | re.DOTALL)
    return match.group(1).strip()[:200] if match else ""
