# SPDX-License-Identifier: MIT
"""
API Investigation Templates -- Reusable API wrappers with provenance tracking.

Each template module provides typed helper functions that use FingerprintedSession
for full provenance. These are NOT DiscoveryTemplates -- they are lower-level
utilities that any domain engine or template can call.

Modules:
    wayback         -- Wayback Machine CDX API (snapshot search, content fetch)
    blockchain      -- Bitcoin blockchain via Blockstream Esplora
    github_deep     -- Deep GitHub analysis beyond gh CLI
    market_data     -- DeFi/market data (DexScreener, CoinGecko, Uniswap)
    web_search      -- Web search (SETI first, Grok fallback)
    code_forensics  -- Code style fingerprinting, stylometric comparison
    infrastructure  -- DNS, SSL, Wayback infra, timezone correlation
    onchain         -- Bitcoin address clustering, temporal patterns
"""
