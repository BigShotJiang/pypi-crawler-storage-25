# SPDX-License-Identifier: MIT
"""Backward-compatibility shim for ``core.hypotheses.hardener``.

The real implementation lives in :mod:`core.hypotheses.hardener` and
the dataclasses in :mod:`core.hypotheses.models`. This module re-exports
the public API so existing call sites keep working unchanged.
"""

from core.hypotheses.hardener import (  # noqa: F401
    CONFIDENCE_THRESHOLD,
    FRAGILITY_THRESHOLD,
    STALE_EVIDENCE_DAYS,
    _bayesian_combine,
    _get_high_confidence_hypotheses,
    _get_supporting_evidence,
    harden_all,
    harden_hypothesis,
)
from core.hypotheses.models import (
    HardeningReport,
    HardeningResult,
)

__all__ = [
    "CONFIDENCE_THRESHOLD",
    "FRAGILITY_THRESHOLD",
    "STALE_EVIDENCE_DAYS",
    "HardeningReport",
    "HardeningResult",
    "harden_all",
    "harden_hypothesis",
]
