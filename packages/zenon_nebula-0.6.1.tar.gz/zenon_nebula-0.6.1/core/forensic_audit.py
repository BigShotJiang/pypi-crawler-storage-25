# SPDX-License-Identifier: MIT
"""
ForensicAuditTrail -- Append-only, chain-hashed audit log.

Every action, every finding, every decision gets a hash linking to the
previous entry. Tamper-evident: if any entry is modified after the fact,
verify_chain() detects the break.

Generalized from marketing's forensic_audit.py. Domain-agnostic: works
with any entity type and action.

Writes: data/forensic_audit.jsonl (append-only JSONL)
"""

import hashlib
import json
import logging
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]


class ForensicAuditTrail:
    """Append-only forensic audit trail with SHA-256 chain hashing.

    Each entry includes the hash of the previous entry, forming a
    tamper-evident chain. If any entry is modified after the fact,
    :meth:`verify_chain` will detect the break.

    Usage::

        trail = ForensicAuditTrail()
        trail.log("CREATE", "evidence", "42", actor="signal_detector",
                  details={"finding": "new commit detected"})
        result = trail.verify_chain()
        assert result["chain_intact"]
    """

    def __init__(self, audit_file: str | None = None) -> None:
        if audit_file:
            self._audit_file = Path(audit_file)
        else:
            self._audit_file = ENGINE_ROOT / "data" / "forensic_audit.jsonl"
        self._audit_file.parent.mkdir(parents=True, exist_ok=True)
        self._last_hash = self._get_last_hash()

    @property
    def audit_file(self) -> Path:
        """Path to the audit trail file."""
        return self._audit_file

    def log(
        self,
        action: str,
        entity_type: str,
        entity_id: str,
        actor: str,
        details: dict,
        run_id: str = "",
        domain: str = "system",
    ) -> str:
        """Append an immutable audit entry. Returns the entry hash.

        Args:
            action:      CREATE, UPDATE, DELETE, VERIFY, ARCHIVE, INVESTIGATE,
                         PROMOTE, RETIRE, or any custom verb.
            entity_type: evidence, hypothesis, aspiration, experiment, template, etc.
            entity_id:   Unique identifier for the entity.
            actor:       Engine name or module that performed the action.
            details:     Arbitrary dict of action-specific data.
            run_id:      Which run produced this entry (optional).
            domain:      Domain that produced this entry (optional).

        Returns:
            SHA-256 hash of the entry.
        """
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "action": action,
            "entity_type": entity_type,
            "entity_id": str(entity_id),
            "actor": actor,
            "domain": domain,
            "details": details,
            "run_id": run_id,
            "prev_hash": self._last_hash,
        }

        # Compute SHA-256 of entry (includes prev_hash for chain integrity)
        entry_json = json.dumps(entry, sort_keys=True)
        entry_hash = hashlib.sha256(entry_json.encode()).hexdigest()
        entry["hash"] = entry_hash

        # Append to JSONL (append-only, never modify)
        with open(self._audit_file, "a") as f:
            f.write(json.dumps(entry) + "\n")

        self._last_hash = entry_hash
        logger.debug(
            "Audit: %s %s/%s by %s hash=%s..%s",
            action,
            entity_type,
            entity_id,
            actor,
            entry_hash[:8],
            entry_hash[-8:],
        )
        return entry_hash

    def verify_chain(self) -> dict:
        """Verify the entire audit chain is untampered.

        Returns:
            Dict with keys: ``total``, ``valid``, ``broken_at`` (list of line
            numbers), ``chain_intact`` (bool).
        """
        results: dict = {
            "total": 0,
            "valid": 0,
            "broken_at": [],
            "chain_intact": True,
        }

        if not self._audit_file.exists():
            return results

        expected_prev = "GENESIS"

        with open(self._audit_file) as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                results["total"] += 1

                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    results["broken_at"].append(line_num)
                    results["chain_intact"] = False
                    continue

                stored_hash = entry.pop("hash", "")

                # Verify the hash of the entry content
                entry_json = json.dumps(entry, sort_keys=True)
                recomputed = hashlib.sha256(entry_json.encode()).hexdigest()

                if recomputed != stored_hash:
                    results["broken_at"].append(line_num)
                    results["chain_intact"] = False
                    continue

                # Verify chain linkage
                if entry.get("prev_hash") != expected_prev:
                    results["broken_at"].append(line_num)
                    results["chain_intact"] = False

                expected_prev = stored_hash
                results["valid"] += 1

        return results

    def get_entries_for(self, entity_type: str, entity_id: str) -> list[dict]:
        """Get all audit entries for a specific entity."""
        matches: list[dict] = []
        if not self._audit_file.exists():
            return matches

        with open(self._audit_file) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    if entry.get("entity_type") == entity_type and entry.get("entity_id") == str(
                        entity_id
                    ):
                        matches.append(entry)
                except json.JSONDecodeError:
                    continue

        return matches

    def get_entries_by_run(self, run_id: str) -> list[dict]:
        """Get all audit entries for a specific run."""
        matches: list[dict] = []
        if not self._audit_file.exists():
            return matches

        with open(self._audit_file) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    if entry.get("run_id") == run_id:
                        matches.append(entry)
                except json.JSONDecodeError:
                    continue

        return matches

    def get_entries_by_actor(self, actor: str) -> list[dict]:
        """Get all audit entries produced by a specific actor."""
        matches: list[dict] = []
        if not self._audit_file.exists():
            return matches

        with open(self._audit_file) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    if entry.get("actor") == actor:
                        matches.append(entry)
                except json.JSONDecodeError:
                    continue

        return matches

    @property
    def entry_count(self) -> int:
        """Total number of entries in the audit trail."""
        if not self._audit_file.exists():
            return 0
        count = 0
        with open(self._audit_file) as f:
            for line in f:
                if line.strip():
                    count += 1
        return count

    def _get_last_hash(self) -> str:
        """Get hash of last entry for chain continuation."""
        if not self._audit_file.exists():
            return "GENESIS"

        last_line = ""
        try:
            with open(self._audit_file) as f:
                for line in f:
                    stripped = line.strip()
                    if stripped:
                        last_line = stripped
        except OSError:
            return "GENESIS"

        if not last_line:
            return "GENESIS"

        try:
            entry = json.loads(last_line)
            return entry.get("hash", "GENESIS")
        except json.JSONDecodeError:
            return "GENESIS"
