# SPDX-License-Identifier: MIT
"""Canonical Finding model.

Every Nebula engine currently produces raw dicts when persisting
evidence. This module defines the typed shape those dicts aspire to
so engines can migrate incrementally. :func:`core.persist_to_db.persist_finding`
accepts either a :class:`Finding` or a plain dict so adoption can be
gradual -- no forced migration.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Finding:
    """Canonical finding shape used by all engines."""

    domain: str
    engine: str
    evidence_type: str
    finding: str
    confidence: float = 0.5
    source_repo: str | None = None
    source_file: str | None = None
    source_commit: str | None = None
    source_line: int | None = None
    supports_hypothesis: str | None = None
    contradicts_hypothesis: str | None = None
    raw_data: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dict for DB persistence.

        Drops fields whose value is ``None`` so persist_finding keeps
        its existing default behaviour for optional columns.
        """
        return {k: v for k, v in self.__dict__.items() if v is not None}

    @classmethod
    def from_row(cls, row: dict) -> Finding:
        """Reconstitute from a DB row.

        Ignores columns that aren't part of this dataclass so the model
        is resilient to the evidence table gaining new columns.
        """
        return cls(**{k: v for k, v in dict(row).items() if k in cls.__dataclass_fields__})


__all__ = ["Finding"]
