# SPDX-License-Identifier: MIT
"""Canonical data models used across Nebula domains and engines.

Models live here so every engine can import a typed object instead of
trafficking raw dicts. Starting point: :class:`core.models.finding.Finding`.
"""

from core.models.finding import Finding

__all__ = ["Finding"]
