# SPDX-License-Identifier: MIT
"""OPSEC-safe HTTP wrapper.

Every outbound HTTP request Nebula makes SHOULD go through this module.
It wraps ``urllib.request`` with three guarantees:

1. **Anonymous User-Agent** — rotates across a pool of real browser
   strings so external APIs can't fingerprint "this is Python-urllib/3.14"
   and link requests across Nebula operators.
2. **Stripped identifying headers** — Referer, X-Forwarded-For, X-Real-IP,
   X-Request-ID, and a dozen other fingerprinting headers are dropped.
3. **Zero accidental leaks** — the body is NEVER logged, NEVER retained,
   and NEVER passed to telemetry. The only place a body goes is the
   intended destination.

The wrapper is a drop-in replacement for ``urllib.request.urlopen``:

    # OLD (fingerprints the operator):
    import urllib.request
    with urllib.request.urlopen(url, timeout=10) as resp:
        data = resp.read()

    # NEW (OPSEC-safe):
    from core.http import opsec_urlopen
    with opsec_urlopen(url, timeout=10) as resp:
        data = resp.read()

For builder-style calls that need custom headers:

    from core.http import opsec_request, opsec_urlopen
    req = opsec_request(
        url,
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
    )
    with opsec_urlopen(req, timeout=10) as resp:
        data = resp.read()

This module exists because ``core/api_fingerprint.py`` was the only
place OPSECGuard headers were actually applied — every other call site
was sending the raw ``Python-urllib/3.x`` User-Agent, which is a clean
fingerprint that would let a surveilled API operator link requests
across Nebula instances. See ``docs/SECURITY-OPSEC-AUDIT.md`` for the
full audit trail and threat model.
"""

from __future__ import annotations

import logging
import urllib.request
from typing import Any

from core.opsec import OPSECGuard

logger = logging.getLogger(__name__)


def _safe_headers(headers: dict | None) -> dict:
    """Return a sanitized header dict ready for outbound use.

    - Rotates the User-Agent via OPSECGuard
    - Strips forbidden fingerprinting headers
    - Preserves caller-supplied headers that are safe
    """
    return OPSECGuard.sanitize_headers(dict(headers or {}))


def opsec_request(
    url: str,
    *,
    data: bytes | None = None,
    headers: dict | None = None,
    method: str | None = None,
) -> urllib.request.Request:
    """Build a ``urllib.request.Request`` with OPSEC-safe headers.

    Args:
        url: The target URL.
        data: Optional request body (bytes).
        headers: Optional caller headers. Will be merged with OPSEC
            defaults and sanitized.
        method: Optional HTTP method override (default inferred from
            ``data`` presence by urllib).

    Returns:
        A ``urllib.request.Request`` ready for ``opsec_urlopen``.
    """
    safe = _safe_headers(headers)
    if method is not None:
        return urllib.request.Request(url, data=data, headers=safe, method=method)
    return urllib.request.Request(url, data=data, headers=safe)


def opsec_urlopen(
    url_or_request: str | urllib.request.Request,
    *,
    data: bytes | None = None,
    timeout: float = 30,
    **kwargs: Any,
) -> Any:
    """Drop-in replacement for ``urllib.request.urlopen`` that forces
    OPSEC-safe headers on every outbound call.

    Accepts either a URL string or a pre-built ``Request`` object. If a
    URL is passed, a safe ``Request`` is constructed automatically. If a
    ``Request`` is passed, its headers are normalized through
    OPSECGuard (so callers who forgot to use ``opsec_request`` still
    get protection — defense in depth).

    Args:
        url_or_request: URL string or ``urllib.request.Request``.
        data: Request body (only honored when ``url_or_request`` is a URL).
        timeout: Socket timeout in seconds (default 30).
        **kwargs: Additional arguments passed to ``urlopen``
            (e.g. ``context=`` for TLS).

    Returns:
        Whatever ``urlopen`` returns (an ``http.client.HTTPResponse``).
    """
    if isinstance(url_or_request, str):
        req = opsec_request(url_or_request, data=data)
    else:
        # Normalize headers on a pre-built Request too.
        req = url_or_request
        existing = dict(req.header_items())
        safe = _safe_headers(existing)
        # Replace headers by rebuilding. urllib.request.Request stores
        # headers in a case-preserving dict; clearing + re-adding is
        # the documented pattern.
        for k in list(req.headers):
            del req.headers[k]
        for k, v in safe.items():
            req.add_header(k, v)

    return urllib.request.urlopen(req, timeout=timeout, **kwargs)
