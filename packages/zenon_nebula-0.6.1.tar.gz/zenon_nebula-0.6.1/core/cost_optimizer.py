# SPDX-License-Identifier: MIT
"""
Cost Optimizer — Minimize LLM spend by doing everything possible locally first.

Philosophy (from zenon-red):
    - LLMs for REASONING (strategy, synthesis, adversarial review)
    - Local compute for EVERYTHING ELSE (grep, regex, git, AST, math)
    - Self-hosted search via SETI instead of paid search APIs
    - Cache repeated queries
    - TOON format to reduce token count

The cheapest LLM call is the one you don't make.

Cost strategy with community:
    - 15 local engines run free (spec tracking, builds, git, regex)
    - Pull community findings from commons (free — others already ran these)
    - Skip local engines if community already has fresh data for that check
    - Only pay for LLM calls: Director, War Room, adversarial review
    - One participant running Opus benefits everyone via commons
    - Target: $0.50-2/day for a participant who pulls from active community
"""

import logging
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ENGINE_ROOT / "data" / "engine.db"


class CostOptimizer:
    """Decides: should this task use an LLM or can it be done locally?"""

    # Tasks that NEVER need an LLM
    LOCAL_ONLY = {
        "file_exists",  # os.path.exists
        "grep_pattern",  # subprocess grep
        "count_files",  # glob
        "git_log",  # subprocess git
        "json_parse",  # json.loads
        "regex_match",  # re.match
        "field_comparison",  # dict comparison
        "hash_computation",  # hashlib
        "build_check",  # subprocess go build / dart analyze
        "test_run",  # subprocess go test
        "address_verification",  # string comparison
        "abi_diff",  # byte comparison
    }

    # Tasks that ALWAYS need an LLM
    LLM_REQUIRED = {
        "adversarial_review",  # Creative attack thinking
        "strategic_synthesis",  # War Room battle plans
        "aspiration_proposal",  # Director decisions
        "content_generation",  # Writing text
        "investigation",  # Deep research
        "competitive_analysis",  # Reasoning about competitors
    }

    # Tasks that MIGHT need an LLM (try local first)
    TRY_LOCAL_FIRST = {
        "signal_classification": "_classify_signal_locally",
        "commit_categorization": "_categorize_commit_locally",
        "severity_assessment": "_assess_severity_locally",
        "spec_compliance": "_check_spec_locally",
    }

    def __init__(self, db_path: str = str(DB_PATH)):
        self.db_path = db_path
        self._cache = {}
        self._cache_ttl = timedelta(hours=1)

    def should_skip_engine(self, engine_name: str, domain: str, max_age_hours: int = 24) -> bool:
        """Check if we can skip running an engine because community already has fresh data.

        If commons imported fresh findings for this domain+engine within max_age_hours,
        we don't need to run the same engine locally. Save compute + API costs.
        """
        conn = connect(self.db_path)
        try:
            cutoff = (datetime.now(timezone.utc) - timedelta(hours=max_age_hours)).isoformat()
            row = conn.execute(
                """SELECT COUNT(*) FROM evidence
                   WHERE domain = ? AND engine = ? AND timestamp > ?""",
                (domain, engine_name, cutoff),
            ).fetchone()
            has_fresh_data = (row[0] or 0) > 0
            if has_fresh_data:
                logger.debug("Skipping %s.%s — fresh community data exists", domain, engine_name)
            return has_fresh_data
        finally:
            conn.close()

    def should_use_llm(self, task: str, context: dict | None = None) -> bool:
        """Decide if a task needs an LLM or can be done locally.

        Returns True if LLM is needed, False if local compute suffices.
        """
        if task in self.LOCAL_ONLY:
            return False
        if task in self.LLM_REQUIRED:
            return True
        if task in self.TRY_LOCAL_FIRST:
            # Try local first — if it produces a confident result, skip LLM
            method_name = self.TRY_LOCAL_FIRST[task]
            method = getattr(self, method_name, None)
            if method and context:
                result = method(context)
                if result and result.get("confidence", 0) >= 0.8:
                    return False  # Local result is good enough
        return True  # Default: use LLM

    def get_cached(self, cache_key: str) -> dict | None:
        """Check if we have a cached LLM response for this exact query."""
        if cache_key in self._cache:
            entry = self._cache[cache_key]
            if datetime.now(timezone.utc) - entry["timestamp"] < self._cache_ttl:
                logger.debug("Cache hit: %s (saved one LLM call)", cache_key[:50])
                return entry["result"]
            else:
                del self._cache[cache_key]
        return None

    def set_cached(self, cache_key: str, result: dict) -> None:
        """Cache an LLM response to avoid repeat calls."""
        self._cache[cache_key] = {
            "result": result,
            "timestamp": datetime.now(timezone.utc),
        }

    def estimate_savings(self, days: int = 30) -> dict:
        """Estimate how much money local-first approach saved.

        Reads actions_log to count: local actions (free) vs LLM actions (paid).
        """
        conn = connect(self.db_path)
        try:
            cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

            total_actions = (
                conn.execute(
                    "SELECT COUNT(*) FROM actions_log WHERE timestamp > ?", (cutoff,)
                ).fetchone()[0]
                or 0
            )

            llm_actions = conn.execute(
                "SELECT COUNT(*), SUM(cost_usd) FROM actions_log WHERE timestamp > ? AND cost_usd > 0",
                (cutoff,),
            ).fetchone()
            llm_count = llm_actions[0] or 0
            llm_cost = llm_actions[1] or 0.0

            local_count = total_actions - llm_count
            # Estimate: if local actions had used LLM, avg cost per LLM call
            avg_llm_cost = (llm_cost / llm_count) if llm_count > 0 else 0.02
            estimated_savings = local_count * avg_llm_cost

            return {
                "period_days": days,
                "total_actions": total_actions,
                "local_actions": local_count,
                "llm_actions": llm_count,
                "actual_cost": round(llm_cost, 2),
                "estimated_savings": round(estimated_savings, 2),
                "local_percentage": round(
                    (local_count / total_actions * 100) if total_actions else 0, 1
                ),
            }
        finally:
            conn.close()

    # --- Local classification methods ---

    def _classify_signal_locally(self, context: dict) -> dict | None:
        """Try to classify a signal without LLM using regex patterns."""
        text = context.get("text", "").lower()
        path = context.get("file_path", "").lower()

        if any(w in path for w in ["spec", "specification", "design"]):
            return {"classification": "spec_change", "confidence": 0.9}
        if any(w in path for w in ["security", "vuln", "cve"]):
            return {"classification": "security_relevant", "confidence": 0.85}
        if any(w in text for w in ["breaking change", "deprecated", "removed"]):
            return {"classification": "breaking_change", "confidence": 0.8}
        if any(w in path for w in ["test", "_test.go", "_test.dart"]):
            return {"classification": "test_change", "confidence": 0.9}
        if any(w in path for w in [".md", "doc", "wiki"]):
            return {"classification": "docs_change", "confidence": 0.9}

        return {"classification": "unknown", "confidence": 0.3}  # Low confidence = use LLM

    def _categorize_commit_locally(self, context: dict) -> dict | None:
        """Categorize a commit message using conventional commit parsing."""
        message = context.get("message", "")
        match = re.match(
            r"^(feat|fix|docs|test|chore|ci|refactor|perf|build|style|revert)(\[.*?\])?:", message
        )
        if match:
            return {"category": match.group(1), "confidence": 0.95}
        return {"category": "unknown", "confidence": 0.2}

    def _assess_severity_locally(self, context: dict) -> dict | None:
        """Assess severity of a finding using keyword matching."""
        text = context.get("text", "").lower()
        if any(w in text for w in ["fund loss", "steal", "locked permanently", "critical"]):
            return {"severity": "critical", "confidence": 0.85}
        if any(w in text for w in ["unauthorized", "bypass", "overflow", "high"]):
            return {"severity": "high", "confidence": 0.8}
        if any(w in text for w in ["missing check", "inconsistent", "medium"]):
            return {"severity": "medium", "confidence": 0.75}
        return {"severity": "info", "confidence": 0.5}

    def _check_spec_locally(self, context: dict) -> dict | None:
        """Check spec compliance using file existence and string matching — no LLM needed."""
        spec_name = context.get("spec_name", "")
        workspace = context.get("workspace", "")
        if not spec_name or not workspace:
            return None

        checks = {}
        root = Path(workspace)

        # These are pure filesystem checks — zero LLM cost
        checks["go_definition"] = (
            root / f"core/go-zenon/vm/embedded/definition/{spec_name.lower()}.go"
        ).exists()
        checks["sdk_model"] = any(
            (root / "core/znn_sdk_dart/lib/src/model/embedded").glob(f"*{spec_name.lower()}*")
        )
        checks["sdk_api"] = any(
            (root / "core/znn_sdk_dart/lib/src/api/embedded").glob(f"*{spec_name.lower()}*")
        )

        passed = sum(1 for v in checks.values() if v)
        total = len(checks)

        return {
            "checks": checks,
            "coverage": passed / total if total else 0,
            "confidence": 0.95,  # Filesystem checks are definitive
        }
