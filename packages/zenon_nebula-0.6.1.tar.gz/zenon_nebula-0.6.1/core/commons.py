# SPDX-License-Identifier: MIT
"""
Nebula Commons — Shared intelligence layer for the Zenon community.

Participants run their own Nebula instance, discover findings through their
engines, and share verified evidence with the community via a shared git repo.

ONLY verified findings get shared:
- provenance must be "verified_by_api" or "verified_by_implementation"
- confidence must be >= 0.80
- finding must have passed local /verify checks
- OPSEC: no private data, no identity leaks, no marketing strategies

Others pull from commons into their local DB, enriching everyone's
intelligence without trusting any single participant.

Flow:
    Local Nebula → evidence DB → commons.export_verified() → push to git
    Remote git → commons.import_findings() → local evidence DB → enriches all domains

Auto-sync cycle (runs every autonomous cycle):
    1. git pull on commons repo (get community findings)
    2. import_all_new() — import any new findings files
    3. Run local engines (produce own findings)
    4. export_verified() — export own verified findings
    5. git push to commons repo (share back)

Future: anchor hashes on-chain via Commitments contract for tamper-proof provenance.
"""

import hashlib
import json
import logging
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ENGINE_ROOT / "data" / "engine.db"


class NebulCommons:
    """Interface between local Nebula and the shared community commons."""

    def __init__(
        self,
        db_path: str = str(DB_PATH),
        commons_path: str | None = None,
        participant_id: str = "anonymous",
    ):
        self.db_path = db_path
        self.commons_path = Path(commons_path) if commons_path else None
        self.participant_id = participant_id

    def export_verified(self, output_dir: str | None = None) -> dict:
        """Export verified findings for sharing with the community.

        Only exports findings that meet ALL criteria:
        - provenance = 'verified_by_api' or 'verified_by_implementation'
        - confidence >= 0.80
        - not already exported

        Returns dict with export stats.
        """
        out = (
            Path(output_dir)
            if output_dir
            else (self.commons_path or ENGINE_ROOT / "data" / "commons_export")
        )
        out.mkdir(parents=True, exist_ok=True)

        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row

        try:
            rows = conn.execute("""
                SELECT id, domain, engine, evidence_type, finding, confidence,
                       supports_hypothesis, contradicts_hypothesis, provenance, timestamp
                FROM evidence
                WHERE provenance IN ('verified_by_api', 'verified_by_implementation')
                  AND confidence >= 0.80
                  AND published = 0
            """).fetchall()

            exported = []
            export_ids = []
            for row in rows:
                finding = dict(row)
                row_id = finding.get("id")  # Save before sanitize strips it
                # Strip any potential OPSEC-sensitive data
                finding = self._sanitize_for_commons(finding)
                if finding is None:
                    continue

                # Add provenance metadata
                finding["contributor"] = self.participant_id
                finding["exported_at"] = datetime.now(timezone.utc).isoformat()
                finding["integrity_hash"] = hashlib.sha256(
                    json.dumps(finding, sort_keys=True).encode()
                ).hexdigest()

                exported.append(finding)
                if row_id is not None:
                    export_ids.append(row_id)

            if exported:
                # Write as dated JSON file
                filename = f"findings_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{self.participant_id}.json"
                filepath = out / filename
                filepath.write_text(json.dumps(exported, indent=2))

                # Mark as published in local DB
                ids = export_ids
                placeholders = ",".join("?" * len(ids))
                conn.execute(
                    f"UPDATE evidence SET published = 1 WHERE id IN ({placeholders})",
                    ids,
                )
                conn.commit()

                logger.info("Exported %d findings to %s", len(exported), filepath)

            return {
                "exported_count": len(exported),
                "output_file": str(filepath) if exported else None,
                "domains": list({f["domain"] for f in exported}),
            }

        finally:
            conn.close()

    def import_findings(self, findings_file: str) -> dict:
        """Import findings from the community commons into local DB.

        Validates integrity hashes, deduplicates, and imports as
        'community_contributed' provenance.

        Args:
            findings_file: Path to JSON file with community findings.

        Returns dict with import stats.
        """
        filepath = Path(findings_file)
        if not filepath.exists():
            return {"error": "File not found", "imported": 0}

        findings = json.loads(filepath.read_text())
        if not isinstance(findings, list):
            return {"error": "Expected JSON array", "imported": 0}

        conn = connect(self.db_path)
        imported = 0
        skipped = 0

        try:
            for finding in findings:
                # Verify integrity
                stored_hash = finding.pop("integrity_hash", None)
                computed_hash = hashlib.sha256(
                    json.dumps(finding, sort_keys=True).encode()
                ).hexdigest()

                if stored_hash and stored_hash != computed_hash:
                    logger.warning(
                        "Integrity check failed for finding from %s",
                        finding.get("contributor", "unknown"),
                    )
                    skipped += 1
                    continue

                # Dedup: skip if we already have this finding
                existing = conn.execute(
                    "SELECT id FROM evidence WHERE finding = ? AND domain = ? AND engine = ?",
                    (
                        finding.get("finding", ""),
                        finding.get("domain", ""),
                        finding.get("engine", ""),
                    ),
                ).fetchone()

                if existing:
                    skipped += 1
                    continue

                # Import with community provenance
                conn.execute(
                    """INSERT INTO evidence
                       (domain, engine, evidence_type, finding, confidence,
                        supports_hypothesis, contradicts_hypothesis, provenance, published)
                       VALUES (?, ?, ?, ?, ?, ?, ?, 'community_contributed', 1)""",
                    (
                        finding.get("domain", ""),
                        finding.get("engine", ""),
                        finding.get("evidence_type", ""),
                        finding.get("finding", ""),
                        finding.get("confidence", 0.0),
                        finding.get("supports_hypothesis", ""),
                        finding.get("contradicts_hypothesis", ""),
                    ),
                )
                imported += 1

            conn.commit()

        finally:
            conn.close()

        return {
            "imported": imported,
            "skipped": skipped,
            "total_in_file": len(findings),
        }

    def auto_sync(self) -> dict:
        """Full auto-sync cycle — pull community findings, import, export ours.

        This runs every autonomous cycle. No manual intervention needed.

        Transport mode:
            NEBULA_TRANSPORT=git  — use git pull/push (default for CI/server)
            Otherwise             — skip git ops (local-only mode, IDE-safe)

        Flow:
            1. git pull commons repo (get latest community findings)
            2. Import all new JSON files we haven't seen
            3. Export our own verified findings
            4. git push to commons repo (share back)

        Returns dict with pull/import/export stats.
        """
        if not self.commons_path or not self.commons_path.exists():
            return {"error": "Commons path not configured or doesn't exist"}

        stats = {"pulled": False, "imported": 0, "exported": 0, "pushed": False}

        transport = os.environ.get("NEBULA_TRANSPORT", "").lower()
        use_git = transport == "git"

        if use_git:
            import subprocess

            # Step 1: Pull latest from community
            try:
                result = subprocess.run(
                    ["git", "pull", "--rebase", "origin", "main"],
                    cwd=str(self.commons_path),
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                stats["pulled"] = result.returncode == 0
                if not stats["pulled"]:
                    logger.warning("Commons git pull failed: %s", result.stderr[:200])
            except Exception as e:
                logger.warning("Commons pull error: %s", e)
        else:
            logger.debug("Git transport disabled (NEBULA_TRANSPORT != 'git'). Skipping pull.")

        # Step 2: Import all new findings files
        findings_dir = self.commons_path / "findings"
        if findings_dir.exists():
            imported_marker = self.commons_path / ".imported_files"
            already_imported = set()
            if imported_marker.exists():
                already_imported = set(imported_marker.read_text().strip().split("\n"))

            newly_imported = []
            for f in sorted(findings_dir.glob("*.json")):
                if f.name in already_imported:
                    continue
                result = self.import_findings(str(f))
                stats["imported"] += result.get("imported", 0)
                newly_imported.append(f.name)

            # Track what we've imported
            if newly_imported:
                with open(imported_marker, "a") as fh:
                    fh.write("\n".join(newly_imported) + "\n")

        # Step 3: Export our verified findings
        export_dir = self.commons_path / "findings"
        export_dir.mkdir(parents=True, exist_ok=True)
        export_result = self.export_verified(str(export_dir))
        stats["exported"] = export_result.get("exported_count", 0)

        # Step 4: Push back to community (only if we exported something and git enabled)
        if stats["exported"] > 0 and use_git:
            import subprocess

            try:
                subprocess.run(
                    ["git", "add", "findings/"],
                    cwd=str(self.commons_path),
                    capture_output=True,
                    timeout=10,
                )
                subprocess.run(
                    [
                        "git",
                        "commit",
                        "-m",
                        f"evidence: {stats['exported']} findings from {self.participant_id}",
                    ],
                    cwd=str(self.commons_path),
                    capture_output=True,
                    timeout=10,
                )
                result = subprocess.run(
                    ["git", "push", "origin", "main"],
                    cwd=str(self.commons_path),
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                stats["pushed"] = result.returncode == 0
            except Exception as e:
                logger.warning("Commons push error: %s", e)

        logger.info(
            "Commons sync: pulled=%s imported=%d exported=%d pushed=%s",
            stats["pulled"],
            stats["imported"],
            stats["exported"],
            stats["pushed"],
        )
        return stats

    def import_all_new(self) -> dict:
        """Import all unprocessed findings files from commons directory."""
        if not self.commons_path:
            return {"error": "Commons path not configured"}

        findings_dir = self.commons_path / "findings"
        if not findings_dir.exists():
            return {"imported": 0, "files_processed": 0}

        total_imported = 0
        files_processed = 0
        for f in sorted(findings_dir.glob("*.json")):
            result = self.import_findings(str(f))
            total_imported += result.get("imported", 0)
            files_processed += 1

        return {"imported": total_imported, "files_processed": files_processed}

    def generate_on_chain_anchor(self, finding_ids: list) -> dict | None:
        """Generate a commitment hash for on-chain anchoring.

        Creates a Merkle root of finding hashes that can be committed
        to the Zenon Commitments contract for tamper-proof provenance.

        Future: submit to z1qxemdeddedxcommitments... contract.
        """
        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row

        try:
            placeholders = ",".join("?" * len(finding_ids))
            rows = conn.execute(
                f"SELECT * FROM evidence WHERE id IN ({placeholders})",
                finding_ids,
            ).fetchall()

            if not rows:
                return None

            # Hash each finding
            hashes = []
            for row in rows:
                data = json.dumps(dict(row), sort_keys=True, default=str)
                h = hashlib.sha256(data.encode()).hexdigest()
                hashes.append(h)

            # Simple Merkle root (pairwise hashing)
            while len(hashes) > 1:
                if len(hashes) % 2 == 1:
                    hashes.append(hashes[-1])  # Duplicate last for odd count
                hashes = [
                    hashlib.sha256((hashes[i] + hashes[i + 1]).encode()).hexdigest()
                    for i in range(0, len(hashes), 2)
                ]

            return {
                "merkle_root": hashes[0],
                "finding_count": len(finding_ids),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "contract": "z1qxemdeddedxcommitments...",
                "status": "ready_for_submission",
            }

        finally:
            conn.close()

    def _sanitize_for_commons(self, finding: dict) -> dict | None:
        """Strip OPSEC-sensitive data before sharing.

        POLICY: Share everything except credentials and identity.
        The more we share, the smarter the network gets.

        Returns None only if finding contains genuinely private data.
        """
        text = finding.get("finding", "")

        # NEVER share: local filesystem paths (reveals identity/machine)
        if "/Users/" in text or "/home/" in text or "C:\\Users" in text:
            return None

        # NEVER share: API keys or tokens
        import re

        if re.search(r"(sk-|xai-|ghp_|gho_|Bearer\s)", text):
            return None

        # Delegate privacy policy to the domain plugin — core stays
        # domain-agnostic. Each domain decides what may be exported via
        # DomainPlugin.should_export() / is_private().
        domain_name = finding.get("domain")
        if domain_name:
            try:
                from core.domain_registry import DomainRegistry

                plugin = DomainRegistry.instance().get_domain(domain_name)
                if plugin is not None:
                    if plugin.is_private():
                        return None
                    if not plugin.should_export(finding):
                        return None
            except Exception as exc:
                logger.debug("Domain export check failed for %s: %s", domain_name, exc)

        # Defense in depth: cross-check against the static PRIVATE_DOMAINS
        # list in core.transport, in case a private domain wasn't registered
        # with the runtime registry (e.g. during tests or partial loads).
        try:
            from core.transport import PRIVATE_DOMAINS

            if domain_name in PRIVATE_DOMAINS:
                return None
        except ImportError as exc:
            logger.debug("core.transport PRIVATE_DOMAINS unavailable: %s", exc)

        # DO share: everything else
        # - Security findings (vulnerabilities, audit results)
        # - Quality metrics (build status, test results, spec compliance)
        # - Development progress (spec coverage, implementation status)
        # - Governance analysis (voting patterns, treasury health)
        # - Network health (node census, bridge metrics)
        # - Economics (staking ratios, liquidity, supply dynamics)
        # - Standards compliance (BIP tracking, crypto checks)
        # - Investigation methodology (NOT findings about people)
        # - Marketing insights about market fit (NOT strategies or content)
        # - Model performance data (which LLMs work best for which tasks)
        # - Bug patterns and anti-patterns discovered

        # Remove internal IDs (not meaningful to others)
        finding.pop("id", None)
        finding.pop("run_id", None)
        finding.pop("parent_finding_id", None)

        return finding
