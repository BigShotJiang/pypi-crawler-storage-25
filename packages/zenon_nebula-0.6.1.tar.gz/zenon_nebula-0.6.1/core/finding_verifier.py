# SPDX-License-Identifier: MIT
"""Finding Verifier -- provenance trace for any finding.

Adapted from a proven external research pattern for blockchain intelligence.

Given a finding ID, produces a verification report:
  - source_repo, source_file, source_commit -- can the finding be reproduced?
  - What engine produced it? What cycle?
  - Is there a reproducible_command?
  - Has the source changed since the finding was created? (uses git_cache)
  - Is the finding still valid or has the underlying code changed?

No LLM calls.
"""

from __future__ import annotations

import logging
import sqlite3
from dataclasses import dataclass, field

from core.persistence import connect

logger = logging.getLogger(__name__)


@dataclass
class VerificationReport:
    """Complete verification report for a single finding."""

    finding_id: int
    exists: bool = False
    domain: str = ""
    engine: str = ""
    evidence_type: str = ""
    finding_text: str = ""
    confidence: float = 0.0
    timestamp: str = ""

    # Source provenance
    source_repo: str = ""
    source_file: str = ""
    source_commit: str = ""
    source_line: int | None = None
    reproducible_command: str = ""

    # Verification checks
    has_source_repo: bool = False
    has_source_file: bool = False
    has_source_commit: bool = False
    has_reproducible_command: bool = False
    source_changed_since: bool = False  # True = source moved since finding
    current_head: str = ""

    # Provenance quality score (0.0 to 1.0)
    provenance_score: float = 0.0

    # Linked hypothesis
    supports_hypothesis: str = ""
    contradicts_hypothesis: str = ""

    # Issues found
    issues: list[str] = field(default_factory=list)


def _check_source_changed(source_repo: str, source_commit: str) -> tuple[bool, str]:
    """Check if the source repo HEAD has moved since the finding's commit.

    Returns (changed: bool, current_head: str).
    """
    if not source_repo or not source_commit:
        return False, ""

    try:
        import os

        workspace = os.environ.get("ZENON_WORKSPACE_ROOT", "")
        if not workspace:
            return False, ""

        # Try to find the repo in the workspace
        # source_repo might be "owner/repo" or a path
        candidates = [
            os.path.join(workspace, source_repo),
            # Try common org prefixes
            os.path.join(workspace, "core", source_repo.split("/")[-1]),
            os.path.join(workspace, "zenon-network", source_repo.split("/")[-1]),
            os.path.join(workspace, "zenon-org", source_repo.split("/")[-1]),
        ]

        for candidate in candidates:
            if os.path.isdir(candidate):
                from core.git_cache import get_repo_head

                current = get_repo_head(candidate)
                if current:
                    changed = current != source_commit
                    return changed, current
    except Exception as exc:
        logger.debug("Source change check failed: %s", exc)

    return False, ""


def verify_finding(finding_id: int, db_path: str) -> VerificationReport:
    """Produce a verification report for a finding.

    Args:
        finding_id: The evidence row ID to verify.
        db_path: Path to the SQLite database.

    Returns:
        VerificationReport with provenance details and quality assessment.
    """
    report = VerificationReport(finding_id=finding_id)

    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute(
            """SELECT id, domain, engine, evidence_type, finding, confidence,
                      timestamp, supports_hypothesis, contradicts_hypothesis,
                      source_repo, source_file, source_commit, source_line,
                      reproducible_command, provenance, run_id
               FROM evidence WHERE id = ?""",
            (finding_id,),
        ).fetchone()
    finally:
        conn.close()

    if not row:
        report.issues.append(f"Finding #{finding_id} does not exist in the database.")
        return report

    report.exists = True
    report.domain = row["domain"] or ""
    report.engine = row["engine"] or ""
    report.evidence_type = row["evidence_type"] or ""
    report.finding_text = row["finding"] or ""
    report.confidence = row["confidence"] or 0.0
    report.timestamp = row["timestamp"] or ""
    report.supports_hypothesis = row["supports_hypothesis"] or ""
    report.contradicts_hypothesis = row["contradicts_hypothesis"] or ""

    # Source provenance
    report.source_repo = row["source_repo"] or ""
    report.source_file = row["source_file"] or ""
    report.source_commit = row["source_commit"] or ""
    report.source_line = row["source_line"]
    report.reproducible_command = row["reproducible_command"] or ""

    # Check what provenance info exists
    report.has_source_repo = bool(report.source_repo)
    report.has_source_file = bool(report.source_file)
    report.has_source_commit = bool(report.source_commit)
    report.has_reproducible_command = bool(report.reproducible_command)

    # Calculate provenance quality score
    score = 0.0
    if report.has_source_repo:
        score += 0.25
    if report.has_source_file:
        score += 0.25
    if report.has_source_commit:
        score += 0.25
    if report.has_reproducible_command:
        score += 0.25
    report.provenance_score = score

    # Check if source has changed since the finding
    if report.has_source_repo and report.has_source_commit:
        changed, current = _check_source_changed(
            report.source_repo,
            report.source_commit,
        )
        report.source_changed_since = changed
        report.current_head = current
        if changed:
            report.issues.append(
                f"Source repo '{report.source_repo}' HEAD has moved from "
                f"{report.source_commit[:8]} to {current[:8]} since this finding."
            )

    # Flag issues
    if not report.has_source_repo:
        report.issues.append("No source_repo recorded -- finding cannot be traced to source.")
    if not report.has_source_commit:
        report.issues.append("No source_commit recorded -- finding cannot be version-pinned.")
    if report.provenance_score < 0.5:
        report.issues.append(
            f"Weak provenance (score={report.provenance_score:.2f}) -- "
            f"finding is hard to independently verify."
        )
    if report.confidence > 0.9 and report.provenance_score < 0.5:
        report.issues.append(
            "High confidence with weak provenance -- confidence may be overstated."
        )

    return report


def verify_batch(
    db_path: str,
    limit: int = 50,
    domain: str = "",
    min_confidence: float = 0.5,
) -> list[VerificationReport]:
    """Verify provenance for recent high-confidence findings.

    Returns list of VerificationReport, sorted by provenance_score ascending
    (worst provenance first).
    """
    conn = connect(db_path)
    try:
        if domain:
            rows = conn.execute(
                """SELECT id FROM evidence
                   WHERE domain = ? AND confidence >= ?
                   ORDER BY timestamp DESC LIMIT ?""",
                (domain, min_confidence, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT id FROM evidence
                   WHERE confidence >= ?
                   ORDER BY timestamp DESC LIMIT ?""",
                (min_confidence, limit),
            ).fetchall()
    finally:
        conn.close()

    reports = [verify_finding(row[0], db_path) for row in rows]
    reports.sort(key=lambda r: r.provenance_score)
    return reports
