# SPDX-License-Identifier: MIT
"""Live Search convenience wrapper around ``core.llm_provider.call_llm``.

xAI's Live Search is a first-class feature of Grok's Chat Completions
API: pass ``search_parameters`` in the request body and the model
performs a live web / X / news search during generation, returning
citations alongside the text response.

This module provides a thin helper so engines don't have to repeat the
boilerplate. The underlying API is in :mod:`core.llm_provider`; this
module exists to:

- Document the pattern and recommended source filters
- Normalize the citation shape across Grok versions (some return
  ``citations`` at the top level, some inside ``choices[0].message``)
- Provide a minimal ``search(query, ...)`` entry point for the common
  "ask a question, get sources" flow used by narrative_analyzer,
  community_scanner, and sentiment_tracker

Phase 17 / ADR-0011. This is opt-in — no existing engine is silently
rewritten. Engines that want live search import this module and call
``search(...)`` explicitly.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SearchResult:
    """Structured Live Search result.

    Attributes:
        text: The model's synthesized response.
        citations: List of source URLs or structured source dicts.
        num_sources_used: How many sources the model actually read
            (may be None if xAI didn't report it).
        cost_usd: Total cost of the underlying LLM call.
        model: The Grok model that handled the call.
    """

    text: str
    citations: list[Any]
    num_sources_used: int | None
    cost_usd: float
    model: str


def _normalize_citation(citation: Any) -> dict | str:
    """Return a citation in a stable shape across Grok versions."""
    if isinstance(citation, str):
        return citation
    if isinstance(citation, dict):
        return {
            "url": citation.get("url") or citation.get("source") or "",
            "title": citation.get("title", ""),
            "snippet": citation.get("snippet", ""),
            **{k: v for k, v in citation.items() if k not in ("url", "title", "snippet")},
        }
    return str(citation)


def search(
    query: str,
    *,
    system: str | None = None,
    sources: list[dict] | None = None,
    model: str = "auto",
    max_tokens: int = 2000,
    llm_call=None,
) -> SearchResult | None:
    """Run a Live Search query via Grok and return a structured result.

    Args:
        query: The search question or prompt.
        system: Optional system prompt. Defaults to a short instruction
            telling Grok to include sources.
        sources: Source filter list, e.g. ``[{"type": "web"}, {"type": "news"}]``.
            Defaults to web + news + X. Pass a narrower list to
            constrain (e.g. ``[{"type": "x"}]`` for X-only).
        model: Grok model ID or ``"auto"``.
        max_tokens: Max response tokens.
        llm_call: Injectable LLM dispatcher for testing. Defaults to
            :func:`core.llm_provider.call_llm`.

    Returns:
        A :class:`SearchResult`, or None if the underlying call failed.
    """
    if llm_call is None:
        from core.llm_provider import call_llm as _default_call

        llm_call = _default_call

    if system is None:
        system = (
            "You have access to Live Search. Answer the user's question "
            "using fresh web / news / X sources and include citations "
            "for every factual claim."
        )

    result = llm_call(
        prompt=query,
        system=system,
        model=model,
        max_tokens=max_tokens,
        live_search=True,
        search_sources=sources,
    )
    if result is None:
        return None

    citations_raw = result.get("citations") or []
    citations = [_normalize_citation(c) for c in citations_raw]

    return SearchResult(
        text=result.get("text", ""),
        citations=citations,
        num_sources_used=result.get("num_sources_used"),
        cost_usd=float(result.get("cost_usd", 0.0)),
        model=result.get("model", "unknown"),
    )
