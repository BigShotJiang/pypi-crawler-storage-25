# SPDX-License-Identifier: MIT
"""MCP Bridge -- Call tools on external MCP servers from Nebula engines.

Allows Nebula to consume tools exposed by other MCP servers (SETI for
web search, a peer Nebula instance, etc.).

Configuration via env:
    NEBULA_MCP_PEERS=seti:localhost:3001,peer_nebula:localhost:3002

Usage:
    from core.mcp_bridge import call_tool, list_peers

    result = call_tool("seti", "web_search", {"query": "zenon network"})
    peers  = list_peers()  # -> ["seti", "peer_nebula"]
"""

import json
import logging
import os
import subprocess
from typing import Any

from core.http import opsec_request, opsec_urlopen  # noqa: F401  OPSEC-safe HTTP wrapper

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Peer registry
# ------------------------------------------------------------------


class MCPPeer:
    """An external MCP server that Nebula can call tools on.

    Uses stdio transport: launches the peer as a subprocess and
    communicates via JSON-RPC over stdin/stdout.
    """

    def __init__(self, name: str, host: str, port: int):
        self.name = name
        self.host = host
        self.port = port

    def __repr__(self) -> str:
        return f"MCPPeer({self.name!r}, {self.host}:{self.port})"


# Module-level registry, populated on first access
_peers: dict[str, MCPPeer] | None = None


def _parse_peers() -> dict[str, MCPPeer]:
    """Parse NEBULA_MCP_PEERS env var into MCPPeer objects.

    Format: name:host:port,name:host:port,...
    """
    raw = os.environ.get("NEBULA_MCP_PEERS", "").strip()
    if not raw:
        return {}

    peers: dict[str, MCPPeer] = {}
    for entry in raw.split(","):
        entry = entry.strip()
        if not entry:
            continue
        parts = entry.split(":")
        if len(parts) != 3:
            logger.warning("Invalid MCP peer entry %r — expected name:host:port", entry)
            continue
        name, host, port_str = parts
        try:
            port = int(port_str)
        except ValueError:
            logger.warning("Invalid port in MCP peer entry %r", entry)
            continue
        peers[name] = MCPPeer(name, host, port)
        logger.info("Registered MCP peer: %s at %s:%d", name, host, port)

    return peers


def _get_peers() -> dict[str, MCPPeer]:
    """Lazy-load the peer registry."""
    global _peers
    if _peers is None:
        _peers = _parse_peers()
    return _peers


# ------------------------------------------------------------------
# Public API
# ------------------------------------------------------------------


def list_peers() -> list[str]:
    """Return names of all registered MCP peers."""
    return list(_get_peers().keys())


def call_tool(
    peer_name: str,
    tool_name: str,
    arguments: dict[str, Any] | None = None,
    timeout: float = 30.0,
) -> Any | None:
    """Call a tool on an external MCP server via HTTP JSON-RPC.

    Args:
        peer_name:  Registered peer name (from NEBULA_MCP_PEERS).
        tool_name:  The MCP tool name to invoke.
        arguments:  Tool arguments dict.
        timeout:    Request timeout in seconds.

    Returns:
        The tool result (parsed from MCP response), or None on failure.
    """
    peers = _get_peers()
    peer = peers.get(peer_name)
    if peer is None:
        logger.error("Unknown MCP peer %r. Available: %s", peer_name, list(peers.keys()))
        return None

    url = f"http://{peer.host}:{peer.port}"
    payload = json.dumps(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments or {},
            },
        }
    ).encode()

    try:
        from urllib.request import Request

        req = Request(url, data=payload, method="POST")
        req.add_header("Content-Type", "application/json")
        with opsec_urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())

        if "error" in data:
            logger.warning(
                "MCP peer %s returned error for %s: %s",
                peer_name,
                tool_name,
                data["error"],
            )
            return None

        result = data.get("result", {})
        # MCP tools/call returns {content: [{type, text}]}
        content = result.get("content", [])
        if content and isinstance(content, list):
            texts = [c.get("text", "") for c in content if c.get("type") == "text"]
            combined = "\n".join(texts)
            # Try to parse as JSON for structured data
            try:
                return json.loads(combined)
            except (json.JSONDecodeError, ValueError):
                return combined
        return result

    except Exception as exc:
        logger.debug("MCP call to %s/%s failed: %s", peer_name, tool_name, exc)
        return None


def call_tool_stdio(
    command: list[str],
    tool_name: str,
    arguments: dict[str, Any] | None = None,
    timeout: float = 30.0,
) -> Any | None:
    """Call a tool on an MCP server via stdio subprocess transport.

    For MCP servers that use stdin/stdout instead of HTTP.

    Args:
        command:    Command to start the MCP server (e.g., ["python3", "server.py"]).
        tool_name:  The MCP tool name to invoke.
        arguments:  Tool arguments dict.
        timeout:    Subprocess timeout in seconds.

    Returns:
        The tool result, or None on failure.
    """
    # Build the MCP protocol messages
    init_msg = json.dumps(
        {
            "jsonrpc": "2.0",
            "id": 0,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "nebula-bridge", "version": "1.0.0"},
            },
        }
    )
    call_msg = json.dumps(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments or {},
            },
        }
    )

    stdin_data = init_msg + "\n" + call_msg + "\n"

    try:
        proc = subprocess.run(
            command,
            input=stdin_data,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        # Parse the last JSON line (the tool call response)
        lines = [l.strip() for l in proc.stdout.strip().split("\n") if l.strip()]
        if not lines:
            logger.debug("stdio MCP server produced no output")
            return None

        # The last line should be the tools/call response
        data = json.loads(lines[-1])
        result = data.get("result", {})
        content = result.get("content", [])
        if content and isinstance(content, list):
            texts = [c.get("text", "") for c in content if c.get("type") == "text"]
            combined = "\n".join(texts)
            try:
                return json.loads(combined)
            except (json.JSONDecodeError, ValueError):
                return combined
        return result

    except subprocess.TimeoutExpired:
        logger.warning("stdio MCP call timed out after %.0fs", timeout)
        return None
    except Exception as exc:
        logger.debug("stdio MCP call failed: %s", exc)
        return None
