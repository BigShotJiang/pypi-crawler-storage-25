# SPDX-License-Identifier: MIT
"""
ZenonData - Centralized accessor for live Zenon chain data.

Provides a single helper surface that every domain engine can use to fetch
network state. The underlying transport is HTTP JSON-RPC against a public
Zenon node (no WebSocket required, no third-party REST shim):

    POST https://my.hc1node.com:35997
    {"jsonrpc":"2.0","id":1,"method":"ledger.getFrontierMomentum","params":[]}

Priority order:
    1. ZENON_NODE_RPC (local znnd via WebSocket, see ``core.node_rpc``)
    2. ZENON_PUBLIC_RPC (HTTP JSON-RPC, default: public hc1node)
    3. None - engines degrade gracefully (empty dicts/lists)

Env vars:
    ZENON_NODE_RPC       WebSocket URL of a local node (optional)
    ZENON_PUBLIC_RPC     HTTP URL of a public node. Default:
                         https://my.hc1node.com:35997
    ZENONHUB_API_URL     Legacy - no longer used for chain data. Kept so
                         users who set it in .env do not see warnings.

Why not ZenonHub REST?
    The ``https://zenonhub.io/api/nom/...`` REST shape does not exist. The
    2026-04-09 API audit confirmed every ``/nom/...`` path returns 404. All
    prior engines that relied on it were silently producing 0 findings.

Public methods (Zenon RPC namespaces)::

    ledger.getFrontierMomentum
    ledger.getAccountInfoByAddress         [address]
    embedded.pillar.getAll                 [page, count]
    embedded.sentinel.getAllActive         [page, count]
    embedded.accelerator.getAll            [page, count]
    embedded.token.getAll                  [page, count]
    embedded.bridge.getBridgeInfo          []
    embedded.stake.getEntriesByAddress     [address, page, count]
    stats.networkInfo                      []
"""

from __future__ import annotations

import json
import logging
import os
import ssl
import threading
import urllib.error
import urllib.request
from typing import Any

from core.http import opsec_request, opsec_urlopen  # noqa: F401  OPSEC-safe HTTP wrapper

logger = logging.getLogger(__name__)

# Default public Zenon HTTP JSON-RPC endpoint. Verified working as of
# 2026-04-09 during the API audit. Users can override with ZENON_PUBLIC_RPC.
DEFAULT_PUBLIC_RPC = "https://my.hc1node.com:35997"

RPC_TIMEOUT = 15.0

# Known well-known addresses on the Zenon network. These are public and
# documented in every existing wiki. They are intentionally listed here
# so engines can query balances without hardcoding the constants.
EMBEDDED_ADDRESSES: dict[str, str] = {
    "accelerator": "z1qxemdeddedxaccelerat0rxxxxxxxxxxp4tk22",
    "bridge": "z1qxemdeddedxdrydgexxxxxxxxxxxxxxxmqgr0d",
    "pillar": "z1qxemdeddedxpyllarxxxxxxxxxxxxxxxsy3fmg",
    "plasma": "z1qxemdeddedxplasmaxxxxxxxxxxxxxxxsctrp0",
    "sentinel": "z1qxemdeddedxsentynelxxxxxxxxxxxxxwy0r2r",
    "stake": "z1qxemdeddedxstakexxxxxxxxxxxxxxxxjv8v62",
    "swap": "z1qxemdeddedxswapxxxxxxxxxxxxxxxxxxl4yww",
    "token": "z1qxemdeddedxt0kenxxxxxxxxxxxxxxxxh9amk0",
}

# ZTS token identifiers. Used by engines that want to translate amounts
# back into human-readable numbers.
ZTS_ZNN = "zts1znnxxxxxxxxxxxxx9z4ulx"
ZTS_QSR = "zts1qsrxxxxxxxxxxxxxmrhjll"

# Precision for ZNN and QSR (both are 1e8-denominated).
TOKEN_DECIMALS = 10**8


class ZenonRpcError(RuntimeError):
    """Raised when the JSON-RPC endpoint returns an ``error`` field."""


def _public_rpc_url() -> str:
    """Return the configured public HTTP RPC URL."""
    return os.environ.get("ZENON_PUBLIC_RPC", DEFAULT_PUBLIC_RPC).rstrip("/")


def _ssl_context() -> ssl.SSLContext:
    """Return a tolerant SSL context for public RPC endpoints.

    Some community-operated Zenon nodes use certificates that do not always
    chain cleanly on every OS. We still want TLS; we just relax hostname
    verification for the fallback node so hardening runs can still make
    progress in headless environments. Users pointing at their own node
    should set ``ZENON_PUBLIC_RPC`` to a trusted URL.
    """
    ctx = ssl.create_default_context()
    if os.environ.get("ZENON_RPC_INSECURE", "1") == "1":
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    return ctx


class ZenonData:
    """Thread-safe HTTP JSON-RPC client for Zenon nodes.

    This class wraps a minimal subset of the ``ledger``, ``embedded``, and
    ``stats`` RPC namespaces. Every helper returns ``None`` (or an empty
    list/dict) on failure so engines can keep running during offline or
    flaky-network conditions.

    A module-level singleton is exposed via :func:`get_zenon_data`.
    """

    def __init__(self, url: str | None = None, timeout: float = RPC_TIMEOUT):
        """Initialize the client.

        Args:
            url: HTTP JSON-RPC base URL. Defaults to ``ZENON_PUBLIC_RPC`` or
                 :data:`DEFAULT_PUBLIC_RPC`.
            timeout: Per-request timeout in seconds.
        """
        self._url = (url or _public_rpc_url()).rstrip("/")
        self._timeout = timeout
        self._req_id = 0
        self._lock = threading.Lock()
        self._context = _ssl_context()

    # ------------------------------------------------------------------
    # Low-level RPC
    # ------------------------------------------------------------------

    def call(self, method: str, params: list | None = None) -> Any | None:
        """Make a JSON-RPC 2.0 call. Returns ``None`` on transport failure.

        Args:
            method: Dotted RPC method name (e.g. ``"ledger.getFrontierMomentum"``).
            params: Positional parameter list. Defaults to ``[]``.

        Returns:
            The parsed ``result`` field, or ``None`` if the call failed.
        """
        with self._lock:
            self._req_id += 1
            payload = {
                "jsonrpc": "2.0",
                "id": self._req_id,
                "method": method,
                "params": params or [],
            }
        body = json.dumps(payload).encode()
        req = urllib.request.Request(
            self._url,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "nebula-zenon-rpc/1.0",
            },
        )
        try:
            resp = opsec_urlopen(req, timeout=self._timeout, context=self._context)
            raw = resp.read()
        except (urllib.error.URLError, ssl.SSLError, TimeoutError) as exc:
            logger.debug("RPC transport error (%s): %s", method, exc)
            return None
        except Exception as exc:  # pragma: no cover - defensive
            logger.debug("RPC unknown error (%s): %s", method, exc)
            return None

        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError as exc:
            logger.debug("RPC bad JSON for %s: %s", method, exc)
            return None

        if parsed.get("error"):
            err = parsed["error"]
            logger.debug(
                "RPC error from %s: code=%s message=%s",
                method,
                err.get("code"),
                err.get("message"),
            )
            return None
        return parsed.get("result")

    # ------------------------------------------------------------------
    # Ledger
    # ------------------------------------------------------------------

    def get_frontier_momentum(self) -> dict | None:
        """Return the latest momentum dict (``height``, ``hash``, ``timestamp``)."""
        return self.call("ledger.getFrontierMomentum")

    def get_height(self) -> int | None:
        """Return just the latest momentum height as an int."""
        momentum = self.get_frontier_momentum()
        if isinstance(momentum, dict):
            h = momentum.get("height")
            if isinstance(h, int):
                return h
            try:
                return int(h)
            except (TypeError, ValueError):
                return None
        return None

    def get_account_info(self, address: str) -> dict | None:
        """Return account info (balances by ZTS) for an address.

        Args:
            address: ``z1q...`` formatted Zenon address.
        """
        return self.call("ledger.getAccountInfoByAddress", [address])

    def get_balance(self, address: str) -> dict[str, int]:
        """Return ``{"znn": raw, "qsr": raw}`` balances for an address.

        Raw values are the on-chain integer amounts. Divide by ``1e8`` to
        get human-readable ZNN/QSR.
        """
        out = {"znn": 0, "qsr": 0}
        info = self.get_account_info(address)
        if not isinstance(info, dict):
            return out
        balances = info.get("balanceInfoMap") or {}
        znn = balances.get(ZTS_ZNN) or {}
        qsr = balances.get(ZTS_QSR) or {}
        try:
            out["znn"] = int(znn.get("balance", 0) or 0)
        except (TypeError, ValueError):
            out["znn"] = 0
        try:
            out["qsr"] = int(qsr.get("balance", 0) or 0)
        except (TypeError, ValueError):
            out["qsr"] = 0
        return out

    # ------------------------------------------------------------------
    # Pillars
    # ------------------------------------------------------------------

    def get_all_pillars(self, page: int = 0, count: int = 500) -> list[dict]:
        """Return all registered pillars as a list of dicts.

        Returns an empty list on failure.
        """
        result = self.call("embedded.pillar.getAll", [page, count])
        return self._extract_list(result)

    def get_pillar_count(self) -> int | None:
        """Return the total number of registered pillars."""
        result = self.call("embedded.pillar.getAll", [0, 1])
        if isinstance(result, dict) and "count" in result:
            try:
                return int(result["count"])
            except (TypeError, ValueError):
                return None
        return None

    # ------------------------------------------------------------------
    # Sentinels
    # ------------------------------------------------------------------

    def get_all_sentinels(self, page: int = 0, count: int = 500) -> list[dict]:
        """Return all active sentinels as a list of dicts."""
        result = self.call("embedded.sentinel.getAllActive", [page, count])
        return self._extract_list(result)

    def get_sentinel_count(self) -> int | None:
        """Return the total number of active sentinels."""
        result = self.call("embedded.sentinel.getAllActive", [0, 1])
        if isinstance(result, dict) and "count" in result:
            try:
                return int(result["count"])
            except (TypeError, ValueError):
                return None
        return None

    # ------------------------------------------------------------------
    # Accelerator-Z
    # ------------------------------------------------------------------

    def get_all_projects(self, page: int = 0, count: int = 100) -> list[dict]:
        """Return Accelerator-Z projects/proposals as a list of dicts."""
        result = self.call("embedded.accelerator.getAll", [page, count])
        return self._extract_list(result)

    def get_az_balance(self) -> dict[str, int]:
        """Return the Accelerator-Z treasury balance as ``{"znn":.., "qsr":..}``."""
        return self.get_balance(EMBEDDED_ADDRESSES["accelerator"])

    # ------------------------------------------------------------------
    # Token
    # ------------------------------------------------------------------

    def get_all_tokens(self, page: int = 0, count: int = 100) -> list[dict]:
        """Return all registered tokens as a list of dicts."""
        result = self.call("embedded.token.getAll", [page, count])
        return self._extract_list(result)

    def get_token_by_zts(self, zts: str) -> dict | None:
        """Return token metadata for a ``zts...`` identifier."""
        return self.call("embedded.token.getByZts", [zts])

    # ------------------------------------------------------------------
    # Bridge
    # ------------------------------------------------------------------

    def get_bridge_info(self) -> dict | None:
        """Return the embedded bridge contract info (orchestrator, admin, etc.)."""
        return self.call("embedded.bridge.getBridgeInfo")

    def get_bridge_balance(self) -> dict[str, int]:
        """Return the bridge contract's ZNN/QSR balance."""
        return self.get_balance(EMBEDDED_ADDRESSES["bridge"])

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def get_network_info(self) -> dict | None:
        """Return node/network stats (connected peers, version, etc.)."""
        return self.call("stats.networkInfo")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_list(result: Any) -> list[dict]:
        """Normalize a paginated RPC result into a plain list of dicts."""
        if result is None:
            return []
        if isinstance(result, list):
            return [item for item in result if isinstance(item, dict)]
        if isinstance(result, dict):
            inner = result.get("list")
            if isinstance(inner, list):
                return [item for item in inner if isinstance(item, dict)]
        return []

    def is_reachable(self) -> bool:
        """Return ``True`` if a cheap RPC call succeeds.

        Uses ``ledger.getFrontierMomentum`` which always returns a small
        payload regardless of chain state. Failure is silent.
        """
        return self.get_frontier_momentum() is not None


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_singleton_lock = threading.Lock()
_singleton: ZenonData | None = None


def get_zenon_data() -> ZenonData:
    """Return the module-level :class:`ZenonData` singleton.

    Safe to call from multiple threads. The singleton is created lazily so
    importing this module has zero network cost.
    """
    global _singleton
    with _singleton_lock:
        if _singleton is None:
            _singleton = ZenonData()
        return _singleton


def reset_zenon_data() -> None:
    """Drop the singleton so the next call re-reads env vars.

    Intended for tests and for runtime configuration changes.
    """
    global _singleton
    with _singleton_lock:
        _singleton = None
