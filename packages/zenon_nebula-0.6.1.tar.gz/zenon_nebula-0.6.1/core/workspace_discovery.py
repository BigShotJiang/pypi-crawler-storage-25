# SPDX-License-Identifier: MIT
"""
Workspace Discovery — Nebula adapts to whatever the participant has.

On first run (or periodically), scans the workspace and builds a map of:
- What repos exist (by finding .git directories)
- What languages each repo uses (Go, Dart, TS, Python, Rust, PHP, etc.)
- What databases exist (SQLite, JSON data files)
- What specs/docs exist
- What CI pipelines exist
- What external APIs are reachable

Domains read this map to know what they can work with.
No hardcoded repo names. No assumed directory structure.
"""

import json
import logging
import os
import sqlite3
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ENGINE_ROOT / "data" / "engine.db"


# Schema for the workspace_repos catalog. The schema_registry picks this
# up automatically from the module-level SCHEMA_SQL constant.
SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS workspace_repos (
    repo_name TEXT PRIMARY KEY,
    repo_path TEXT NOT NULL,
    repo_type TEXT,
    languages TEXT,
    has_ci INTEGER DEFAULT 0,
    has_tests INTEGER DEFAULT 0,
    classified_at TEXT,
    llm_classification TEXT
);

CREATE INDEX IF NOT EXISTS idx_workspace_repos_type
    ON workspace_repos(repo_type);
"""

# Language detection by file extension
LANG_EXTENSIONS = {
    ".go": "go",
    ".dart": "dart",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".js": "javascript",
    ".py": "python",
    ".rs": "rust",
    ".php": "php",
    ".sol": "solidity",
    ".java": "java",
    ".cs": "csharp",
    ".cpp": "cpp",
    ".c": "c",
    ".rb": "ruby",
}

# Content-based repo classification (what kind of project is this?)
#
# Zenon-specific signatures come first (most specific). Generic blockchain
# and fallback signatures live underneath so Nebula can classify reference
# chains (Bitcoin Core, go-ethereum, Cosmos SDK, Substrate, etc.) dropped
# into the workspace alongside the Zenon repos.
REPO_SIGNATURES = {
    # -- Zenon core ecosystem --
    "node": ["go.mod", "cmd/znnd", "vm/embedded"],
    "sdk_dart": ["pubspec.yaml", "lib/src/api", "lib/src/model"],
    "sdk_go": ["go.mod", "api/embedded"],
    "sdk_typescript": ["package.json", "src/api", "tsconfig.json"],
    "sdk_python": ["setup.py", "pyproject.toml"],
    "cli": ["pubspec.yaml", "lib/global.dart", "lib/utils/args.dart"],
    "cli_go": ["go.mod", "znncli.go"],
    "wallet": ["pubspec.yaml", "lib/widgets", "flutter"],
    "explorer": ["routes/web.php", "app/Http/Controllers"],
    "wiki": ["index.md", "navigation.md"],
    "specs": ["docs/specs"],
    "bridge": ["contracts", "orchestrator"],
    "website": ["index.html", "pages"],
    "devnet": ["genesis.json", "config.json"],
    # -- Reference blockchain families --
    # Bitcoin Core / btcd / knots — native/C++ Bitcoin full nodes.
    "blockchain_node_btc": [
        "src/validation.h",
        "src/consensus",
        "bitcoin-cli.cpp",
        "src/script/interpreter.h",
        "doc/bips.md",
    ],
    # go-ethereum / erigon / op-geth — Ethereum execution clients.
    "blockchain_node_evm": [
        "core/vm",
        "eth/",
        "cmd/geth",
        "consensus/ethash",
        "params/config.go",
    ],
    # Cosmos SDK / cosmos-sdk based chains.
    "blockchain_node_cosmos": [
        "app.go",
        "x/auth",
        "cosmos-sdk",
        "types/coin.go",
        "baseapp",
    ],
    # Rust blockchains — Substrate, Solana, NEAR, etc.
    "rust_blockchain": [
        "Cargo.toml",
        "consensus",
        "runtime",
        "node/src",
    ],
    # -- Generic capability fallbacks --
    # Repos that have "contracts" of some kind (vm/embedded, contracts/,
    # contracts-bedrock, etc.) but didn't match a more specific signature.
    "generic_has_contracts": [
        "contracts",
        "contracts-bedrock",
        "pallets",
        "programs",
    ],
    # Repos that expose an RPC/HTTP API surface.
    "generic_has_rpc_api": [
        "rpc",
        "api",
        "json-rpc",
        "openapi.yaml",
    ],
    # Repos that contain cryptographic primitives (BLS, secp256k1, etc.).
    "generic_has_crypto_primitives": [
        "crypto",
        "secp256k1",
        "bls",
        "schnorr",
        "merkle",
    ],
}

# Ordered scan — more specific signatures first, generics last. Python
# dicts preserve insertion order (3.7+), so REPO_SIGNATURES above is
# already in the right order, but we export this alias for clarity and
# so callers can rely on it remaining stable.
REPO_SIGNATURE_ORDER: list[str] = list(REPO_SIGNATURES.keys())


def discover_workspace(workspace_root: str | None = None) -> dict:
    """Scan the workspace and build a complete map of what exists.

    Returns a dict with:
    - repos: list of discovered repos with metadata
    - languages: dict of language -> count of repos using it
    - databases: list of found database files
    - specs: list of found spec directories/files
    - ci_pipelines: list of repos with CI
    - summary: human-readable summary
    """
    root = Path(workspace_root or os.environ.get("ZENON_WORKSPACE_ROOT", ""))
    if not root.exists():
        return {"error": f"Workspace root not found: {root}", "repos": []}

    result = {
        "workspace_root": str(root),
        "discovered_at": datetime.now(timezone.utc).isoformat(),
        "repos": [],
        "languages": defaultdict(int),
        "databases": [],
        "specs": [],
        "ci_pipelines": [],
        "apis_reachable": {},
    }

    # Load exclusion lists from environment
    exclude_paths = _get_excluded_paths(root)
    exclude_repos = _get_excluded_repos()

    # Find all git repos (up to 4 levels deep)
    for depth in range(1, 5):
        pattern = "/".join(["*"] * depth) + "/.git"
        for git_dir in root.glob(pattern):
            repo_path = git_dir.parent

            # Skip excluded paths
            if _is_excluded(repo_path, root, exclude_paths, exclude_repos):
                continue

            if any(r["path"] == str(repo_path) for r in result["repos"]):
                continue

            repo_info = _analyze_repo(repo_path, root)
            result["repos"].append(repo_info)

            for lang in repo_info.get("languages", []):
                result["languages"][lang] += 1

            if repo_info.get("has_ci"):
                result["ci_pipelines"].append(
                    {
                        "repo": repo_info["name"],
                        "path": repo_info["path"],
                    }
                )

    # Find databases
    for db_file in root.rglob("*.db"):
        if ".git" not in str(db_file) and "node_modules" not in str(db_file):
            result["databases"].append(
                {
                    "path": str(db_file),
                    "name": db_file.name,
                    "size_mb": round(db_file.stat().st_size / 1024 / 1024, 2),
                    "tables": _get_db_tables(str(db_file)),
                }
            )

    for db_file in root.rglob("*.sqlite"):
        if ".git" not in str(db_file):
            result["databases"].append(
                {
                    "path": str(db_file),
                    "name": db_file.name,
                    "size_mb": round(db_file.stat().st_size / 1024 / 1024, 2),
                }
            )

    # Find specs
    for md_dir in root.rglob("specs"):
        if md_dir.is_dir() and ".git" not in str(md_dir):
            for spec in md_dir.iterdir():
                if spec.is_dir() or spec.suffix == ".md":
                    result["specs"].append(
                        {
                            "name": spec.name,
                            "path": str(spec),
                            "type": "directory" if spec.is_dir() else "file",
                        }
                    )

    # Summary
    result["summary"] = {
        "total_repos": len(result["repos"]),
        "total_languages": dict(result["languages"]),
        "total_databases": len(result["databases"]),
        "total_specs": len(result["specs"]),
        "total_ci": len(result["ci_pipelines"]),
    }

    result["languages"] = dict(result["languages"])

    # Upsert each discovered repo into the workspace_repos catalog so
    # downstream engines have a cached, queryable view of what exists.
    _upsert_workspace_repos(result.get("repos", []))

    return result


def _upsert_workspace_repos(repos: list[dict]) -> None:
    """Persist the discovered repo catalog into ``workspace_repos``.

    Uses ``persist_metric`` for inserts and falls back to a manual UPDATE
    when the row already exists (SQLite doesn't support UPSERT through
    the persist_metric helper). Failures are logged and swallowed so a
    bad row never breaks the discovery cycle.
    """
    if not repos:
        return
    try:
        # Local import keeps core bootstrap graph clean and avoids any
        # accidental cycle with the persistence package.
        from core.persistence.metrics import persist_metric, query_table
        from core.persistence.schema import _get_connection
    except Exception as exc:
        logger.debug("workspace_repos upsert skipped (import error): %s", exc)
        return

    now_iso = datetime.now(timezone.utc).isoformat()
    for repo in repos:
        name = repo.get("name") or ""
        if not name:
            continue
        row = {
            "repo_name": name,
            "repo_path": repo.get("path", ""),
            "repo_type": repo.get("repo_type", "unknown"),
            "languages": json.dumps(repo.get("languages", [])),
            "has_ci": 1 if repo.get("has_ci") else 0,
            "has_tests": 1 if repo.get("has_tests") else 0,
            "classified_at": now_iso,
        }
        existing = query_table(
            table="workspace_repos",
            where="repo_name = ?",
            params=(name,),
            limit=1,
        )
        if existing:
            # Manual UPDATE — persist_metric only INSERTs and the
            # primary key would collide.
            try:
                conn = _get_connection(str(DB_PATH))
                try:
                    conn.execute(
                        """UPDATE workspace_repos
                           SET repo_path = ?,
                               repo_type = ?,
                               languages = ?,
                               has_ci = ?,
                               has_tests = ?,
                               classified_at = ?
                         WHERE repo_name = ?""",
                        (
                            row["repo_path"],
                            row["repo_type"],
                            row["languages"],
                            row["has_ci"],
                            row["has_tests"],
                            row["classified_at"],
                            name,
                        ),
                    )
                    conn.commit()
                finally:
                    conn.close()
            except Exception as exc:
                logger.debug("workspace_repos UPDATE failed for %s: %s", name, exc)
        else:
            persist_metric(table="workspace_repos", data=row)


def _analyze_repo(repo_path: Path, workspace_root: Path) -> dict:
    """Analyze a single repo — detect language, type, activity."""
    relative = str(repo_path.relative_to(workspace_root))
    info = {
        "name": repo_path.name,
        "relative_path": relative,
        "path": str(repo_path),
        "languages": [],
        "repo_type": "unknown",
        "has_ci": False,
        "has_tests": False,
    }

    # Detect languages by scanning repo contents. Defensive exclusion
    # list: skip build noise AND any directory that commonly holds
    # secrets (``.ssh``, ``.aws``, ``.gnupg``, ``.env.d``, etc.) even
    # if it somehow ended up inside a workspace repo. Operators who
    # put secrets inside a workspace by mistake shouldn't have them
    # counted toward language statistics.
    _SKIP_SEGMENTS = frozenset(
        {
            ".git",
            "node_modules",
            "vendor",
            "build",
            "dist",
            "target",
            "__pycache__",
            ".ssh",
            ".aws",
            ".gnupg",
            ".gpg",
            "secrets",
            ".secrets",
            ".vault",
            ".env.d",
        }
    )
    lang_counts = defaultdict(int)
    for f in repo_path.rglob("*"):
        if any(seg in _SKIP_SEGMENTS for seg in f.parts):
            continue
        # Also skip files that look like secrets (``.env``, ``credentials``,
        # ``*.pem``, ``*.key``).
        name_lower = f.name.lower()
        if (
            name_lower.startswith(".env")
            or name_lower in {"credentials", "credentials.json", "secrets.json"}
            or name_lower.endswith((".pem", ".key", ".p12", ".pfx"))
        ):
            continue
        if f.is_file() and f.suffix in LANG_EXTENSIONS:
            lang_counts[LANG_EXTENSIONS[f.suffix]] += 1

    # Top languages (more than 3 files)
    info["languages"] = [
        lang for lang, count in sorted(lang_counts.items(), key=lambda x: -x[1]) if count >= 3
    ]

    # Detect repo type by content signatures
    for repo_type, signatures in REPO_SIGNATURES.items():
        matches = sum(
            1
            for sig in signatures
            if (repo_path / sig).exists() or any(repo_path.glob(f"**/{sig}"))
        )
        if matches >= 2:
            info["repo_type"] = repo_type
            break

    # Check for CI
    info["has_ci"] = (repo_path / ".github" / "workflows").exists()

    # Check for tests
    info["has_tests"] = any(
        [
            any(repo_path.glob("**/test_*.py")),
            any(repo_path.glob("**/*_test.go")),
            any(repo_path.glob("**/*_test.dart")),
            any(repo_path.glob("**/*.spec.ts")),
            any(repo_path.glob("**/*.test.ts")),
        ]
    )

    return info


def _get_db_tables(db_path: str) -> list:
    """Get table names from a SQLite database."""
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        tables = [
            r[0]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            ).fetchall()
        ]
        conn.close()
        return tables
    except Exception as exc:
        logger.debug("Failed to read DB tables from %s: %s", db_path, exc)
        return []


def persist_discovery(discovery: dict, db_path: str = str(DB_PATH)) -> None:
    """Save workspace discovery to the evidence table."""
    conn = connect(db_path)
    summary = discovery.get("summary", {})
    conn.execute(
        """INSERT INTO evidence (domain, engine, evidence_type, finding, confidence)
           VALUES (?, ?, ?, ?, ?)""",
        (
            "intelligence",
            "workspace_discovery",
            "workspace_scan",
            json.dumps(summary, indent=2),
            0.99,
        ),
    )
    conn.commit()
    conn.close()


def get_repos_by_language(workspace_root: str | None = None, language: str = "go") -> list:
    """Get all repos that use a specific language. Used by domain engines."""
    discovery = discover_workspace(workspace_root)
    return [r for r in discovery["repos"] if language in r.get("languages", [])]


def get_repos_by_type(workspace_root: str | None = None, repo_type: str = "node") -> list:
    """Get all repos of a specific type. Used by domain engines."""
    discovery = discover_workspace(workspace_root)
    return [r for r in discovery["repos"] if r.get("repo_type") == repo_type]


def find_databases(workspace_root: str | None = None) -> list:
    """Find all SQLite databases in the workspace."""
    discovery = discover_workspace(workspace_root)
    return discovery.get("databases", [])


def _get_excluded_paths(workspace_root: Path) -> list[Path]:
    """Get excluded paths from NEBULA_EXCLUDE_PATHS env var."""
    raw = os.environ.get("NEBULA_EXCLUDE_PATHS", "")
    if not raw.strip():
        return []
    paths = []
    for p in raw.split(","):
        p = p.strip()
        if not p:
            continue
        path = Path(p)
        if not path.is_absolute():
            path = workspace_root / path
        paths.append(path.resolve())
    return paths


def _get_excluded_repos() -> set:
    """Get excluded repo names from NEBULA_EXCLUDE_REPOS env var."""
    raw = os.environ.get("NEBULA_EXCLUDE_REPOS", "")
    if not raw.strip():
        return set()
    return {r.strip() for r in raw.split(",") if r.strip()}


def _is_excluded(
    repo_path: Path, workspace_root: Path, exclude_paths: list[Path], exclude_repos: set
) -> bool:
    """Check if a repo should be excluded from scanning."""
    # Check by repo name
    if repo_path.name in exclude_repos:
        logger.debug("Excluding repo by name: %s", repo_path.name)
        return True

    # Check by path
    resolved = repo_path.resolve()
    for excluded in exclude_paths:
        if resolved == excluded or str(resolved).startswith(str(excluded)):
            logger.debug("Excluding repo by path: %s", repo_path)
            return True

    return False
