# SPDX-License-Identifier: MIT
"""Anomaly Detector -- flags surprising findings for attention.

Adapted from a proven external research pattern for blockchain intelligence.

For each new finding, computes how unusual it is compared to recent
findings from the same engine:
  - Z-score on confidence: if 2+ stddev from engine's average, flag it.
  - Burst detection: >10 findings from one engine in one cycle = suspicious.
  - Silence detection: sudden drop to zero from previously active engine.
  - Confidence outlier: much higher/lower than engine average.

No LLM calls. Pure statistics.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from core.persistence import connect

logger = logging.getLogger(__name__)

# Thresholds
UNEXPECTED_THRESHOLD = 2.0  # Z > 2.0 = unexpected
ANOMALOUS_THRESHOLD = 3.0  # Z > 3.0 = anomalous
BURST_THRESHOLD = 10  # >10 findings from one engine in one cycle
MIN_HISTORY = 5  # Need at least N prior findings for stats
RECENT_HOURS = 24  # Window for burst/silence detection


@dataclass
class AnomalyResult:
    """Result of anomaly detection for a single check."""

    anomaly_type: str  # "confidence_outlier" | "burst" | "silence"
    engine: str
    level: str  # "normal" | "unexpected" | "anomalous"
    description: str
    z_score: float = 0.0
    metric_value: float = 0.0
    prior_mean: float = 0.0
    prior_std: float = 0.0
    prior_count: int = 0


@dataclass
class AnomalyReport:
    """Aggregated anomaly detection report."""

    anomalies: list[AnomalyResult] = field(default_factory=list)
    engines_checked: int = 0
    findings_checked: int = 0


def _get_engine_stats(db_path: str) -> dict[str, dict]:
    """Compute per-engine confidence statistics from all evidence.

    Returns {engine_name: {"count": N, "sum": S, "sum_sq": SS, "mean": M, "std": D}}
    """
    conn = connect(db_path)
    try:
        rows = conn.execute(
            """SELECT engine, COUNT(*) as cnt,
                      SUM(confidence) as s,
                      SUM(confidence * confidence) as ss
               FROM evidence
               WHERE engine IS NOT NULL AND engine != ''
               GROUP BY engine"""
        ).fetchall()
    finally:
        conn.close()

    stats: dict[str, dict] = {}
    for row in rows:
        engine = row[0]
        n = row[1]
        s = row[2] or 0.0
        ss = row[3] or 0.0
        mean = s / n if n > 0 else 0.0
        variance = max((ss / n) - (mean * mean), 0.0) if n > 0 else 0.0
        std = math.sqrt(variance) if variance > 0 else 0.0
        stats[engine] = {
            "count": n,
            "sum": s,
            "sum_sq": ss,
            "mean": mean,
            "std": std,
        }
    return stats


def _get_recent_counts(db_path: str, hours: float = RECENT_HOURS) -> dict[str, int]:
    """Count findings per engine in the recent window."""
    conn = connect(db_path)
    try:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        rows = conn.execute(
            """SELECT engine, COUNT(*) as cnt
               FROM evidence
               WHERE engine IS NOT NULL AND engine != '' AND timestamp >= ?
               GROUP BY engine""",
            (cutoff,),
        ).fetchall()
    finally:
        conn.close()
    return {row[0]: row[1] for row in rows}


def _get_previously_active_engines(db_path: str, hours: float = RECENT_HOURS) -> set[str]:
    """Find engines that were active before the recent window but not in it."""
    conn = connect(db_path)
    try:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        older_cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours * 3)).isoformat()

        # Engines active in the older window
        older = conn.execute(
            """SELECT DISTINCT engine FROM evidence
               WHERE engine IS NOT NULL AND engine != ''
               AND timestamp >= ? AND timestamp < ?""",
            (older_cutoff, cutoff),
        ).fetchall()
        older_engines = {r[0] for r in older}

        # Engines active in the recent window
        recent = conn.execute(
            """SELECT DISTINCT engine FROM evidence
               WHERE engine IS NOT NULL AND engine != ''
               AND timestamp >= ?""",
            (cutoff,),
        ).fetchall()
        recent_engines = {r[0] for r in recent}
    finally:
        conn.close()

    return older_engines - recent_engines


def check_finding_anomaly(
    confidence: float,
    engine: str,
    engine_stats: dict[str, dict],
) -> AnomalyResult | None:
    """Check if a single finding's confidence is anomalous for its engine.

    Args:
        confidence: The finding's confidence score.
        engine: The engine that produced the finding.
        engine_stats: Pre-computed per-engine statistics.

    Returns:
        AnomalyResult if anomalous, None otherwise.
    """
    if not engine or engine not in engine_stats:
        return None

    stats = engine_stats[engine]
    n = stats["count"]
    mean = stats["mean"]
    std = stats["std"]

    if n < MIN_HISTORY or std < 1e-10:
        return None

    z = abs(confidence - mean) / std
    if z < UNEXPECTED_THRESHOLD:
        return None

    level = "anomalous" if z >= ANOMALOUS_THRESHOLD else "unexpected"
    direction = "higher" if confidence > mean else "lower"

    return AnomalyResult(
        anomaly_type="confidence_outlier",
        engine=engine,
        level=level,
        z_score=round(z, 2),
        metric_value=confidence,
        prior_mean=round(mean, 4),
        prior_std=round(std, 4),
        prior_count=n,
        description=(
            f"WHAT: Finding from '{engine}' has confidence {confidence:.2f}, "
            f"which is {direction} than typical ({mean:.2f} +/- {std:.2f}, Z={z:.1f}). "
            f"SO WHAT: This is statistically {level} -- may indicate unusual conditions. "
            f"NOW WHAT: Verify the finding manually; check for data quality issues."
        ),
    )


def detect_anomalies(db_path: str) -> AnomalyReport:
    """Run full anomaly detection across all engines.

    Checks:
      1. Burst detection -- engines producing too many findings at once.
      2. Silence detection -- previously active engines going quiet.
      3. (Finding-level confidence checks run per-finding via check_finding_anomaly.)

    Returns:
        AnomalyReport with all detected anomalies.
    """
    report = AnomalyReport()
    engine_stats = _get_engine_stats(db_path)
    report.engines_checked = len(engine_stats)

    # 1. Burst detection
    recent_counts = _get_recent_counts(db_path)
    for engine, count in recent_counts.items():
        if count > BURST_THRESHOLD:
            report.anomalies.append(
                AnomalyResult(
                    anomaly_type="burst",
                    engine=engine,
                    level="unexpected",
                    metric_value=float(count),
                    description=(
                        f"WHAT: Engine '{engine}' produced {count} findings in the "
                        f"last {RECENT_HOURS}h (threshold: {BURST_THRESHOLD}). "
                        f"SO WHAT: Burst production may indicate a real event or a runaway loop. "
                        f"NOW WHAT: Check if the engine is cycling correctly; "
                        f"review recent findings for quality."
                    ),
                )
            )

    # 2. Silence detection
    silent_engines = _get_previously_active_engines(db_path)
    for engine in silent_engines:
        report.anomalies.append(
            AnomalyResult(
                anomaly_type="silence",
                engine=engine,
                level="unexpected",
                description=(
                    f"WHAT: Engine '{engine}' was active previously but produced "
                    f"zero findings in the last {RECENT_HOURS}h. "
                    f"SO WHAT: The engine may have crashed, been disabled, or lost its data source. "
                    f"NOW WHAT: Check engine health; verify data sources are accessible."
                ),
            )
        )

    if report.anomalies:
        logger.info(
            "Anomaly detection: %d anomalies found across %d engines",
            len(report.anomalies),
            report.engines_checked,
        )

    return report


def detect_and_persist(db_path: str) -> AnomalyReport:
    """Run anomaly detection and persist findings.

    Returns:
        AnomalyReport with all detected anomalies.
    """
    report = detect_anomalies(db_path)

    for anomaly in report.anomalies:
        try:
            from core.persist_to_db import persist_finding

            persist_finding(
                db_path=db_path,
                domain="quality",
                engine="anomaly_detector",
                evidence_type="qa_anomaly",
                finding=anomaly.description,
                confidence=0.85 if anomaly.level == "anomalous" else 0.7,
            )
        except Exception as exc:
            logger.debug("Failed to persist anomaly finding: %s", exc)

    return report
