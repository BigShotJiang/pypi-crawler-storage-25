# SPDX-License-Identifier: MIT
"""
DomainRegistry -- Domain plugin system for the Zenon Unified Engine.

Every domain (marketing, investigation, intelligence, development, etc.)
registers a DomainPlugin that declares its engines, hypothesis types,
aspiration types, collision signals, war room contributions, and
self-improvement metrics.

The DomainRegistry is a singleton that collects all plugins and provides
cross-domain queries.
"""

import logging
import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


# -- Data classes --


@dataclass
class EngineDefinition:
    """Defines an engine within a domain."""

    name: str
    description: str
    module_path: str
    priority: int = 5
    enabled: bool = True
    tier: int = 1  # 1 (basic API) to 5 (generative)
    required_apis: list[str] = field(default_factory=list)
    max_runtime_seconds: int = 300


@dataclass
class HypothesisType:
    """Defines a type of hypothesis a domain can generate."""

    type_id: str
    label: str
    description: str
    initial_confidence: float = 0.0
    publishable_threshold: float = 0.80


@dataclass
class AspirationType:
    """Defines an aspiration (goal) a domain can pursue."""

    type_id: str
    label: str
    description: str
    priority: int = 5
    deadline_days: int | None = None


@dataclass
class CollisionSignal:
    """Defines a signal that can trigger cross-domain collisions.

    When two domains produce findings that converge on the same topic,
    the collision engine detects this and escalates.
    """

    signal_id: str
    label: str
    description: str
    source_domains: list[str] = field(default_factory=list)
    convergence_threshold: float = 0.7


@dataclass
class WarRoomContribution:
    """What a domain contributes to the daily war room briefing."""

    domain: str
    section_title: str
    metrics: list[str] = field(default_factory=list)
    recommendations_prompt: str = ""


# -- Abstract Base Class --


class DomainPlugin(ABC):
    """Abstract base class for domain plugins.

    Every domain must implement this interface to register with the engine.
    """

    @abstractmethod
    def name(self) -> str:
        """Return the domain name (e.g. 'marketing', 'investigation')."""

    @abstractmethod
    def get_engines(self) -> list[EngineDefinition]:
        """Return all engines this domain provides."""

    @abstractmethod
    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""

    @abstractmethod
    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""

    @abstractmethod
    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that can trigger cross-domain collisions."""

    @abstractmethod
    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return what this domain contributes to the war room briefing."""

    @abstractmethod
    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement tracking.

        Returns:
            Dict of metric_name -> current_value.
            Example: {"findings_per_day": 12.5, "accuracy_rate": 0.92}
        """

    @abstractmethod
    def decide_next_action(self, context: dict) -> dict | None:
        """Given current state, decide the highest-value next action.

        Args:
            context: Dict containing current system state (trigger level,
                     budget remaining, stale data indicators, etc.)

        Returns:
            Action dict with keys: action, reason, priority, engine.
            None if no action is needed.
        """

    @abstractmethod
    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables.

        The core tables (evidence, hypotheses, actions_log, etc.) are
        already created by persist_to_db. This method returns DDL for
        any domain-specific tables the domain needs.

        Return empty string if no additional tables are needed.
        """

    # -- Optional overrides --

    def get_description(self) -> str:
        """Human-readable description of this domain."""
        return f"Domain: {self.name()}"

    def get_priority(self) -> int:
        """Domain priority (lower = higher priority). Default 5."""
        return 5

    def on_register(self) -> None:
        """Called when the domain is registered with the engine.

        Override for initialization logic (e.g. ensuring domain-specific
        tables exist).
        """

    def on_finding(self, finding: dict) -> None:
        """Called when any domain persists a finding.

        Override to react to cross-domain findings (e.g. collision detection).
        """

    def trusts_engine(self, engine: str) -> bool:
        """Return True if the given engine name is trusted for this domain.

        Core uses this during quarantine decisions to verify a finding
        attributed to this domain actually came from one of the domain's
        own engines.

        Default: trust any engine. Domains with sensitive attribution
        (e.g. security) should override to enforce an allow-list.
        """
        return True

    def should_export(self, finding: dict) -> bool:
        """Return True if the given finding may be exported to commons.

        Core uses this during commons sanitization to enforce per-domain
        privacy policy. Default: allow export. Domains holding private
        content (e.g. marketing drafts, investigation identity data)
        should override to block export for specific evidence types.
        """
        return True

    def is_private(self) -> bool:
        """Return True if this domain is entirely private.

        Private domains never share any findings to commons regardless of
        evidence type. Default: public. Override in domains whose findings
        should never leave the local instance.
        """
        return False

    def get_status(self) -> dict:
        """Return current domain status for health monitoring."""
        return {
            "domain": self.name(),
            "engines": len(self.get_engines()),
            "hypothesis_types": len(self.get_hypothesis_types()),
            "enabled_engines": sum(1 for e in self.get_engines() if e.enabled),
        }


# -- Registry Singleton --


class DomainRegistry:
    """Singleton registry for all domain plugins.

    Thread-safe. Domains register themselves at import time or during
    application startup.

    Usage::

        registry = DomainRegistry.instance()
        registry.register(MarketingDomain())
        registry.register(InvestigationDomain())

        # Query across domains
        all_engines = registry.get_all_engines()
        marketing = registry.get_domain("marketing")
    """

    _instance: Optional["DomainRegistry"] = None
    _lock = threading.Lock()

    @classmethod
    def instance(cls) -> "DomainRegistry":
        """Get the singleton registry instance."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton (for testing)."""
        with cls._lock:
            cls._instance = None

    def __init__(self):
        self._domains: dict[str, DomainPlugin] = {}

    def register(self, plugin: DomainPlugin) -> None:
        """Register a domain plugin.

        Args:
            plugin: DomainPlugin instance to register.

        Raises:
            ValueError: If a domain with the same name is already registered.
        """
        name = plugin.name()
        if name in self._domains:
            raise ValueError(
                f"Domain '{name}' is already registered. Use unregister() first to replace it."
            )
        self._domains[name] = plugin
        plugin.on_register()
        logger.info(
            "Registered domain: %s (%d engines, %d hypothesis types)",
            name,
            len(plugin.get_engines()),
            len(plugin.get_hypothesis_types()),
        )

    def unregister(self, name: str) -> DomainPlugin | None:
        """Unregister a domain plugin by name. Returns the removed plugin."""
        return self._domains.pop(name, None)

    def get_domain(self, name: str) -> DomainPlugin | None:
        """Get a registered domain plugin by name."""
        return self._domains.get(name)

    def get_all_domains(self) -> list[DomainPlugin]:
        """Get all registered domain plugins, sorted by priority."""
        return sorted(
            self._domains.values(),
            key=lambda d: d.get_priority(),
        )

    def get_domain_names(self) -> list[str]:
        """Get names of all registered domains."""
        return list(self._domains.keys())

    def get_all_engines(self) -> list[EngineDefinition]:
        """Get all engines across all domains."""
        engines = []
        for domain in self._domains.values():
            engines.extend(domain.get_engines())
        return engines

    def get_all_hypothesis_types(self) -> list[HypothesisType]:
        """Get all hypothesis types across all domains."""
        types = []
        for domain in self._domains.values():
            types.extend(domain.get_hypothesis_types())
        return types

    def get_all_collision_signals(self) -> list[CollisionSignal]:
        """Get all collision signals across all domains."""
        signals = []
        for domain in self._domains.values():
            signals.extend(domain.get_collision_signals())
        return signals

    def get_all_war_room_contributions(self) -> list[WarRoomContribution]:
        """Get all war room contributions across all domains."""
        contributions = []
        for domain in self._domains.values():
            contributions.extend(domain.get_war_room_contributions())
        return contributions

    def decide_next_action(self, context: dict, exclude: set | None = None) -> dict | None:
        """Return the next domain action that hasn't been excluded yet.

        Iterates all domains in priority order (lowest priority number first),
        returning the first action whose domain:action key isn't in exclude.
        This enables round-robin across all 17 domains instead of only picking
        the globally-highest-priority action every time.

        Args:
            context: System state dict.
            exclude: Set of "domain:action" keys already selected this cycle.

        Returns:
            The next action not yet excluded, or None if all domains exhausted.
        """
        exclude = exclude or set()

        # Sort domains by priority (lower number = higher priority)
        sorted_domains = sorted(self.get_all_domains(), key=lambda d: d.get_priority())

        # We pass `exclude` through to domains that opt in to multi-engine
        # rotation. A domain opts in by adding `exclude` as a named parameter
        # to its `decide_next_action` signature — introspected here so that
        # single-engine domains don't need any code change and multi-engine
        # domains (development, investigation, security, …) can iterate
        # through their engines returning a DIFFERENT action when their
        # first-choice engine has already been selected this cycle. Without
        # this, every domain could fire at most one engine per cycle and
        # engines like spec_audit / curiosity_scanner would never run in
        # the autonomous loop even though they were registered.
        import inspect

        for domain in sorted_domains:
            try:
                try:
                    sig = inspect.signature(domain.decide_next_action)
                    accepts_exclude = "exclude" in sig.parameters
                except (TypeError, ValueError):
                    accepts_exclude = False

                if accepts_exclude:
                    action = domain.decide_next_action(context, exclude=exclude)
                else:
                    action = domain.decide_next_action(context)
                if not action:
                    continue

                action_key = f"{domain.name()}:{action.get('action', '')}"
                if action_key in exclude:
                    continue

                action["domain"] = domain.name()
                return action
            except Exception as exc:
                logger.error(
                    "Domain %s.decide_next_action() failed: %s",
                    domain.name(),
                    exc,
                )

        return None

    def broadcast_finding(self, finding: dict) -> None:
        """Broadcast a finding to all registered domains for collision detection."""
        for domain in self._domains.values():
            try:
                domain.on_finding(finding)
            except Exception as exc:
                logger.error(
                    "Domain %s.on_finding() failed: %s",
                    domain.name(),
                    exc,
                )

    def get_combined_schema_sql(self) -> str:
        """Get combined DDL from all domains for database initialization."""
        parts = []
        for domain in self._domains.values():
            sql = domain.get_db_schema_sql()
            if sql and sql.strip():
                parts.append(f"-- Domain: {domain.name()}")
                parts.append(sql)
        return "\n\n".join(parts)

    def get_system_status(self) -> dict:
        """Get status of all domains for health monitoring."""
        return {
            "total_domains": len(self._domains),
            "domains": {name: domain.get_status() for name, domain in self._domains.items()},
            "total_engines": len(self.get_all_engines()),
            "total_hypothesis_types": len(self.get_all_hypothesis_types()),
        }
