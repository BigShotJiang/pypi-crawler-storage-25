# SPDX-License-Identifier: MIT
"""Structured logging configuration for Nebula.

Two output formats are supported:

* ``text`` — human-readable console format (the default). Friendly for
  local development.
* ``json`` — one JSON record per line. Friendly for log aggregation
  (Loki, Elasticsearch, CloudWatch, Datadog, etc.). OPSEC-clean: no
  file paths, no user identity, just the message and structured
  metadata.

Both formats honour standard logging fields (level, logger name,
message, timestamp) and any ``extra=`` dict passed to a log call.

The format is selected via the ``NEBULA_LOG_FORMAT`` environment
variable — set to ``json`` for structured output, anything else for
text. ``NEBULA_LOG_LEVEL`` overrides the default level (``INFO``).

Wiring
------
Call :func:`configure_logging` once at process start, before any
logger is used. ``scripts/autonomous.py`` should call it from its
``main()`` entry point; the MCP server, RPC server, and every ad-hoc
script should do the same.

``configure_logging`` is idempotent: calling it repeatedly with the
same parameters is a no-op, so it's safe to invoke from multiple
bootstrap paths.

Example
-------
>>> from core.logging_config import configure_logging
>>> configure_logging(format="json", level="DEBUG")
>>> import logging
>>> logging.getLogger(__name__).info("nebula booted", extra={"cycles": 5})
{"timestamp": "2026-04-10T...", "level": "INFO",
 "logger": "__main__", "message": "nebula booted", "cycles": 5}
"""

from __future__ import annotations

import datetime as _dt
import json
import logging
import os
import sys
from typing import Any

__all__ = [
    "JsonFormatter",
    "TextFormatter",
    "configure_logging",
]


# Keys that Python's logging module owns — we never want to stamp them
# as "extra" fields because they are already first-class in the record.
_RESERVED_RECORD_KEYS = frozenset(
    {
        "name",
        "msg",
        "args",
        "levelname",
        "levelno",
        "pathname",
        "filename",
        "module",
        "exc_info",
        "exc_text",
        "stack_info",
        "lineno",
        "funcName",
        "created",
        "msecs",
        "relativeCreated",
        "thread",
        "threadName",
        "processName",
        "process",
        "getMessage",
        "message",
        "asctime",
        "taskName",
    }
)


class JsonFormatter(logging.Formatter):
    """Emit one JSON object per log record.

    Fields:
        timestamp: ISO 8601 UTC.
        level:     record level (INFO / WARNING / ...).
        logger:    logger name (usually the module).
        message:   already-interpolated message text.
        <extra>:   any non-reserved attributes added via ``extra={}``.
        exc_info:  stringified traceback if the record carried one.
    """

    def format(self, record: logging.LogRecord) -> str:
        """Render a log record as a single JSON-encoded line (overrides logging.Formatter.format)."""
        payload: dict[str, Any] = {
            "timestamp": _dt.datetime.fromtimestamp(
                record.created, tz=_dt.timezone.utc
            ).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key, value in record.__dict__.items():
            if key in _RESERVED_RECORD_KEYS:
                continue
            if key.startswith("_"):
                continue
            try:
                json.dumps(value)
            except (TypeError, ValueError):
                value = repr(value)
            payload[key] = value
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


class TextFormatter(logging.Formatter):
    """Human-readable console format with millisecond precision."""

    def __init__(self) -> None:
        super().__init__(
            fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )


# Module-level guard: configure_logging is idempotent.
_CONFIGURED: dict[str, Any] = {}


def configure_logging(
    format: str | None = None,
    level: str | int | None = None,
    *,
    stream: Any = None,
    force: bool = False,
) -> None:
    """Install a single handler on the root logger.

    Args:
        format: ``"text"`` or ``"json"``. If omitted, read from
            ``NEBULA_LOG_FORMAT`` (default ``text``).
        level: Logging level name or integer. If omitted, read from
            ``NEBULA_LOG_LEVEL`` (default ``INFO``).
        stream: File-like object to write to. Defaults to
            :data:`sys.stderr` so stdout stays reserved for program
            output.
        force: Reinstall the handler even if ``configure_logging``
            has already been called.
    """
    fmt_name = (format or os.environ.get("NEBULA_LOG_FORMAT") or "text").lower()
    lvl_raw = level if level is not None else os.environ.get("NEBULA_LOG_LEVEL", "INFO")
    if isinstance(lvl_raw, str):
        lvl = logging.getLevelName(lvl_raw.upper())
        if not isinstance(lvl, int):
            lvl = logging.INFO
    else:
        lvl = int(lvl_raw)

    if not force and _CONFIGURED.get("format") == fmt_name and _CONFIGURED.get("level") == lvl:
        return

    handler = logging.StreamHandler(stream or sys.stderr)
    if fmt_name == "json":
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(TextFormatter())

    root = logging.getLogger()
    # Remove the previous Nebula handler so we don't double-log across
    # repeated calls.
    for existing in list(root.handlers):
        if getattr(existing, "_nebula_handler", False):
            root.removeHandler(existing)
    handler._nebula_handler = True  # type: ignore[attr-defined]
    root.addHandler(handler)
    root.setLevel(lvl)

    _CONFIGURED["format"] = fmt_name
    _CONFIGURED["level"] = lvl
