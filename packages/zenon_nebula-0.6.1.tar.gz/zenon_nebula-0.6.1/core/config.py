# SPDX-License-Identifier: MIT
"""
Central configuration loader for Nebula.

Loads config from (in order of precedence):
1. Environment variables (highest priority)
2. config/local.json (user overrides, gitignored)
3. config/*.json (defaults, committed templates live as *.example.json)
4. Module defaults (lowest priority)

This module is a THIN loader. It reads the existing config/*.json files
(system, model_routing, guardrails, domains, trust, timeouts, engine_defaults)
and exposes typed convenience methods. It does not invent new config — the
JSON files remain the source of truth.

Usage:
    from core.config import get_config

    config = get_config()
    budget = config.budget_warning_threshold
    model = config.routing("strategic_synthesis")
    timeout = config.timeout("github_api")
    threshold = config.engine("bridge_health").get("min_relayers", 3)
    trust = config.trust_for_org("zenon-network")
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ENGINE_ROOT / "config"

# Env var name -> (config path, type_hint) for overrides.
# Only the most load-bearing knobs are promoted to env vars. Everything
# else is read from JSON files so we don't grow a parallel env-var empire.
_ENV_OVERRIDES: dict[str, tuple[str, type]] = {
    "NEBULA_DAILY_BUDGET_USD": ("system.budget.daily_api_budget_usd", float),
    "NEBULA_BUDGET_WARNING_PCT": ("system.budget.budget_warning_at_percent", float),
    "NEBULA_BUDGET_PAUSE_PCT": ("system.budget.budget_pause_at_percent", float),
    "NEBULA_MAX_ACTIONS_PER_HOUR": ("system.budget.max_actions_per_hour", int),
    "NEBULA_API_TIMEOUT": ("timeouts.api_default", int),
    "NEBULA_RPC_TIMEOUT": ("timeouts.rpc_default", int),
    "NEBULA_LLM_TIMEOUT": ("timeouts.llm_default", int),
}


def _read_json(path: Path) -> dict:
    """Read a JSON file, returning {} on any failure."""
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return {}
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("Failed to load %s: %s", path.name, exc)
        return {}


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base. override wins on conflicts."""
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _set_by_dotpath(data: dict, dotpath: str, value: Any) -> None:
    """Set a nested value by 'a.b.c' path, creating intermediate dicts."""
    keys = dotpath.split(".")
    node = data
    for key in keys[:-1]:
        if key not in node or not isinstance(node[key], dict):
            node[key] = {}
        node = node[key]
    node[keys[-1]] = value


@dataclass
class NebulaConfig:
    """Typed view over the merged Nebula configuration.

    Holds four top-level dicts (system, routing, timeouts, engines, trust,
    guardrails, domains) and exposes convenience accessors.
    """

    system: dict = field(default_factory=dict)
    routing: dict = field(default_factory=dict)
    timeouts: dict = field(default_factory=dict)
    engines: dict = field(default_factory=dict)
    trust: dict = field(default_factory=dict)
    guardrails: dict = field(default_factory=dict)
    domains: dict = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Budget (from system.json)
    # ------------------------------------------------------------------

    @property
    def daily_api_budget_usd(self) -> float:
        """Return the daily API budget cap in USD (default 50)."""
        return float(self.system.get("budget", {}).get("daily_api_budget_usd", 50.0))

    @property
    def budget_warning_threshold(self) -> float:
        """Fraction (0-1) of daily budget at which to warn."""
        pct = self.system.get("budget", {}).get("budget_warning_at_percent", 80)
        return float(pct) / 100.0

    @property
    def budget_pause_threshold(self) -> float:
        """Fraction (0-1) of daily budget at which to pause."""
        pct = self.system.get("budget", {}).get("budget_pause_at_percent", 100)
        return float(pct) / 100.0

    @property
    def max_actions_per_hour(self) -> int:
        """Return the scheduler's per-hour action cap (default 500)."""
        return int(self.system.get("budget", {}).get("max_actions_per_hour", 500))

    @property
    def zenon_facts(self) -> dict:
        """Protocol constants (pillar lock, emissions, etc.)."""
        return dict(self.system.get("zenon_facts", {}))

    # ------------------------------------------------------------------
    # Model routing
    # ------------------------------------------------------------------

    def route(self, task: str) -> dict:
        """Return full route info dict for a task (model, cost, max_tokens)."""
        return dict(self.routing.get("routes", {}).get(task, {}))

    def routing_defaults(self) -> dict:
        """Return the default model-routing block as a plain dict."""
        return dict(self.routing.get("defaults", {}))

    # ------------------------------------------------------------------
    # Timeouts
    # ------------------------------------------------------------------

    def timeout(self, name: str, default: int | None = None) -> int:
        """Get a named timeout (seconds). Falls back to api_default, then default arg."""
        value = self.timeouts.get(name)
        if value is None:
            value = self.timeouts.get("api_default", default if default is not None else 30)
        return int(value)

    # ------------------------------------------------------------------
    # Engine thresholds
    # ------------------------------------------------------------------

    def engine(self, name: str) -> dict:
        """Return the defaults dict for an engine (empty if unknown)."""
        return dict(self.engines.get("engines", {}).get(name, {}))

    # ------------------------------------------------------------------
    # Trust
    # ------------------------------------------------------------------

    @property
    def default_trust(self) -> float:
        """Return the baseline trust score used for unknown sources."""
        return float(self.trust.get("default_trust", 0.3))

    @property
    def trusted_orgs(self) -> dict:
        """Return the configured org -> trust score mapping as a dict."""
        return dict(self.trust.get("trusted_orgs", {}))

    def trust_for_org(self, org: str) -> float:
        """Return trust level for a GitHub org, or default_trust if unknown."""
        return float(self.trusted_orgs.get(org, self.default_trust))


_cached_config: NebulaConfig | None = None


def _apply_env_overrides(bundle: dict) -> None:
    """Apply env var overrides to the merged config bundle (in-place)."""
    for env_var, (dotpath, caster) in _ENV_OVERRIDES.items():
        raw = os.environ.get(env_var)
        if raw is None or raw == "":
            continue
        try:
            value = caster(raw)
        except (TypeError, ValueError):
            logger.warning("Invalid %s=%r (expected %s), ignoring", env_var, raw, caster.__name__)
            continue
        _set_by_dotpath(bundle, dotpath, value)


def _load_all() -> NebulaConfig:
    """Load all JSON config files, merge with local.json and env overrides."""
    # Each top-level section is its own file so local.json can override
    # any of them via matching top-level keys.
    sections = {
        "system": _read_json(CONFIG_DIR / "system.json"),
        "routing": _read_json(CONFIG_DIR / "model_routing.json"),
        "timeouts": _read_json(CONFIG_DIR / "timeouts.json"),
        "engines": _read_json(CONFIG_DIR / "engine_defaults.json"),
        "trust": _read_json(CONFIG_DIR / "trust.json"),
        "guardrails": _read_json(CONFIG_DIR / "guardrails.json"),
        "domains": _read_json(CONFIG_DIR / "domains.json"),
    }

    # local.json can override any section via top-level keys matching
    # the section name (e.g. {"system": {...}, "timeouts": {...}}).
    local = _read_json(CONFIG_DIR / "local.json")
    if local:
        for section_name, overrides in local.items():
            if section_name in sections and isinstance(overrides, dict):
                sections[section_name] = _deep_merge(sections[section_name], overrides)

    # Env overrides are applied against a flat bundle so dotpaths work.
    _apply_env_overrides(sections)

    return NebulaConfig(**sections)


def get_config() -> NebulaConfig:
    """Return the cached NebulaConfig, loading it on first call."""
    global _cached_config
    if _cached_config is None:
        _cached_config = _load_all()
    return _cached_config


def reload_config() -> NebulaConfig:
    """Force reload from disk. Useful in tests and after config edits."""
    global _cached_config
    _cached_config = None
    return get_config()
