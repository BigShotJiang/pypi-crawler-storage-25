# SPDX-License-Identifier: MIT
"""
FeedbackBus -- SQLite-backed persistent inter-agent message queue.

Allows engines, domains, the validation spiral, and the self-extension
loop to leave messages for each other that survive process restarts.

Upgraded from marketing's JSON-file implementation to SQLite for
concurrency safety and better query performance.

Message types:
    - "finding"             : Engine produced a notable finding
    - "question"            : Validation spiral generated a follow-up question
    - "aspiration"          : Director proposed a new aspiration
    - "contradiction"       : Contradiction detected between findings
    - "stall_alert"         : An engine or hypothesis has stalled
    - "breakthrough"        : High-significance finding (FLYWHEEL trigger)
    - "signal"              : Generic signal from one engine to another
    - "dependency_resolved" : A blocking dependency has been resolved
    - "gate_passed"         : A quality gate has been passed
    - "pr_ready"            : A pull request or deliverable is ready for review
"""

import json
import logging
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

VALID_MESSAGE_TYPES = frozenset(
    {
        "finding",
        "question",
        "aspiration",
        "contradiction",
        "stall_alert",
        "breakthrough",
        "signal",
        "dependency_resolved",
        "gate_passed",
        "pr_ready",
    }
)

_BUS_SCHEMA = """
CREATE TABLE IF NOT EXISTS feedback_bus (
    id TEXT PRIMARY KEY,
    sender TEXT NOT NULL,
    recipient TEXT NOT NULL,
    domain TEXT NOT NULL DEFAULT 'system',
    type TEXT NOT NULL,
    data TEXT NOT NULL DEFAULT '{}',
    timestamp TEXT NOT NULL,
    acknowledged BOOLEAN NOT NULL DEFAULT 0,
    acknowledged_at TEXT,
    acknowledged_by TEXT
);

CREATE INDEX IF NOT EXISTS idx_bus_recipient ON feedback_bus(recipient, acknowledged);
CREATE INDEX IF NOT EXISTS idx_bus_type ON feedback_bus(type, acknowledged);
CREATE INDEX IF NOT EXISTS idx_bus_domain ON feedback_bus(domain);
CREATE INDEX IF NOT EXISTS idx_bus_timestamp ON feedback_bus(timestamp);
"""

# Exposed at module level so core.schema_registry picks it up and
# applies the table during startup. See core/schema_registry.py.
SCHEMA_SQL = _BUS_SCHEMA

# Maximum messages retained before pruning acknowledged ones
MAX_MESSAGES = 5000


class FeedbackBus:
    """SQLite-backed persistent inter-agent message queue.

    Thread-safe via SQLite's built-in locking. Suitable for multi-process
    use with WAL mode enabled.

    Usage::

        bus = FeedbackBus()
        msg_id = bus.post("engine_a", "engine_b", "finding", {"score": 0.9})
        messages = bus.read("engine_b")
        bus.acknowledge(msg_id)
    """

    def __init__(self, db_path: str = DEFAULT_DB):
        self.db_path = db_path
        self._ensure_schema()

    def _get_conn(self) -> sqlite3.Connection:
        """Open a connection with WAL mode."""
        conn = connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        """Create the feedback_bus table if it does not exist."""
        conn = self._get_conn()
        try:
            conn.executescript(_BUS_SCHEMA)
            conn.commit()
        finally:
            conn.close()

    def post(
        self,
        sender: str,
        recipient: str,
        message_type: str,
        data: dict,
        domain: str = "system",
    ) -> str:
        """Post a message to the bus.

        Args:
            sender:       Module/engine name posting the message.
            recipient:    Target module (e.g. "director", "all").
            message_type: One of the documented message types.
            data:         Payload dict -- structure depends on message_type.
            domain:       Domain context for the message.

        Returns:
            The message ID (8-char UUID).
        """
        if message_type not in VALID_MESSAGE_TYPES:
            logger.warning(
                "Unknown message type '%s' from %s -- posting anyway",
                message_type,
                sender,
            )

        msg_id = str(uuid.uuid4())[:8]
        now = datetime.now(timezone.utc).isoformat()

        conn = self._get_conn()
        try:
            conn.execute(
                """INSERT INTO feedback_bus
                (id, sender, recipient, domain, type, data, timestamp, acknowledged)
                VALUES (?, ?, ?, ?, ?, ?, ?, 0)""",
                (msg_id, sender, recipient, domain, message_type, json.dumps(data), now),
            )

            # Prune if over limit
            count = conn.execute("SELECT COUNT(*) FROM feedback_bus").fetchone()[0]
            if count > MAX_MESSAGES:
                conn.execute(
                    """DELETE FROM feedback_bus
                    WHERE id IN (
                        SELECT id FROM feedback_bus
                        WHERE acknowledged = 1
                        ORDER BY timestamp ASC
                        LIMIT ?
                    )""",
                    (count - MAX_MESSAGES + 500,),
                )

            conn.commit()

            logger.debug(
                "FeedbackBus: %s -> %s [%s] domain=%s id=%s",
                sender,
                recipient,
                message_type,
                domain,
                msg_id,
            )
            return msg_id

        finally:
            conn.close()

    def read(self, recipient: str, domain: str | None = None) -> list[dict]:
        """Get all pending (unacknowledged) messages for a recipient.

        Also returns messages addressed to "all".

        Args:
            recipient: Target module name.
            domain:    Optional domain filter.

        Returns:
            List of message dicts.
        """
        conn = self._get_conn()
        try:
            if domain:
                rows = conn.execute(
                    """SELECT * FROM feedback_bus
                    WHERE acknowledged = 0
                    AND (recipient = ? OR recipient = 'all')
                    AND domain = ?
                    ORDER BY timestamp ASC""",
                    (recipient, domain),
                ).fetchall()
            else:
                rows = conn.execute(
                    """SELECT * FROM feedback_bus
                    WHERE acknowledged = 0
                    AND (recipient = ? OR recipient = 'all')
                    ORDER BY timestamp ASC""",
                    (recipient,),
                ).fetchall()

            return [self._row_to_dict(r) for r in rows]
        finally:
            conn.close()

    def read_by_type(
        self, recipient: str, message_type: str, domain: str | None = None
    ) -> list[dict]:
        """Get pending messages of a specific type for a recipient."""
        conn = self._get_conn()
        try:
            if domain:
                rows = conn.execute(
                    """SELECT * FROM feedback_bus
                    WHERE acknowledged = 0
                    AND (recipient = ? OR recipient = 'all')
                    AND type = ? AND domain = ?
                    ORDER BY timestamp ASC""",
                    (recipient, message_type, domain),
                ).fetchall()
            else:
                rows = conn.execute(
                    """SELECT * FROM feedback_bus
                    WHERE acknowledged = 0
                    AND (recipient = ? OR recipient = 'all')
                    AND type = ?
                    ORDER BY timestamp ASC""",
                    (recipient, message_type),
                ).fetchall()

            return [self._row_to_dict(r) for r in rows]
        finally:
            conn.close()

    def acknowledge(self, message_id: str, acknowledged_by: str = "unknown") -> bool:
        """Mark a message as acknowledged.

        Returns True if the message was found and acknowledged.
        """
        conn = self._get_conn()
        try:
            now = datetime.now(timezone.utc).isoformat()
            cursor = conn.execute(
                """UPDATE feedback_bus
                SET acknowledged = 1, acknowledged_at = ?, acknowledged_by = ?
                WHERE id = ? AND acknowledged = 0""",
                (now, acknowledged_by, message_id),
            )
            conn.commit()
            return cursor.rowcount > 0
        finally:
            conn.close()

    def acknowledge_all(self, recipient: str, acknowledged_by: str = "unknown") -> int:
        """Acknowledge all pending messages for a recipient.

        Returns the number of messages acknowledged.
        """
        conn = self._get_conn()
        try:
            now = datetime.now(timezone.utc).isoformat()
            cursor = conn.execute(
                """UPDATE feedback_bus
                SET acknowledged = 1, acknowledged_at = ?, acknowledged_by = ?
                WHERE acknowledged = 0
                AND (recipient = ? OR recipient = 'all')""",
                (now, acknowledged_by, recipient),
            )
            conn.commit()
            return cursor.rowcount
        finally:
            conn.close()

    def get_history(self, limit: int = 50, domain: str | None = None) -> list[dict]:
        """Return the most recent messages regardless of acknowledgment."""
        conn = self._get_conn()
        try:
            if domain:
                rows = conn.execute(
                    """SELECT * FROM feedback_bus
                    WHERE domain = ?
                    ORDER BY timestamp DESC LIMIT ?""",
                    (domain, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    """SELECT * FROM feedback_bus
                    ORDER BY timestamp DESC LIMIT ?""",
                    (limit,),
                ).fetchall()
            return [self._row_to_dict(r) for r in rows]
        finally:
            conn.close()

    def count_pending(self, recipient: str | None = None) -> int:
        """Count unacknowledged messages, optionally for a specific recipient."""
        conn = self._get_conn()
        try:
            if recipient:
                row = conn.execute(
                    """SELECT COUNT(*) FROM feedback_bus
                    WHERE acknowledged = 0
                    AND (recipient = ? OR recipient = 'all')""",
                    (recipient,),
                ).fetchone()
            else:
                row = conn.execute(
                    "SELECT COUNT(*) FROM feedback_bus WHERE acknowledged = 0"
                ).fetchone()
            return row[0]
        finally:
            conn.close()

    @staticmethod
    def _row_to_dict(row: sqlite3.Row) -> dict:
        """Convert a sqlite3.Row to a dict with parsed data field."""
        d = dict(row)
        try:
            d["data"] = json.loads(d.get("data", "{}"))
        except (json.JSONDecodeError, TypeError):
            d["data"] = {}
        return d
