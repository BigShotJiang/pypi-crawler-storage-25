# SPDX-License-Identifier: MIT
"""
Adaptive Model Router — Learns which model performs best for each task.

Extends model_router.py with intelligence:
1. Try cheaper model first, escalate only if quality is insufficient
2. Track quality scores per model per task type
3. Multi-model verification for critical tasks
4. Auto-adjust routing based on performance data
5. Prompt caching for repeated context patterns

The static router (model_router.py) provides defaults.
This module overrides those defaults when it has enough data to be smarter.
"""

import logging
import sqlite3
from pathlib import Path

from core import model_router
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ENGINE_ROOT / "data" / "engine.db"


# Exposed at module level so core.schema_registry applies the tables
# during boot, before any engine tries to write to them.
SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS model_performance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    task_type TEXT NOT NULL,
    model TEXT NOT NULL,
    quality_score REAL,
    cost_usd REAL,
    latency_ms REAL,
    tokens_input INTEGER,
    tokens_output INTEGER,
    escalated BOOLEAN DEFAULT FALSE,
    domain TEXT,
    engine TEXT
);

CREATE TABLE IF NOT EXISTS routing_overrides (
    task_type TEXT PRIMARY KEY,
    preferred_model TEXT NOT NULL,
    reason TEXT,
    confidence REAL DEFAULT 0.5,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_perf_task ON model_performance(task_type);
CREATE INDEX IF NOT EXISTS idx_perf_model ON model_performance(model);
"""


def ensure_tables(db_path: str = str(DB_PATH)) -> None:
    """Create adaptive routing tables if they don't exist."""
    conn = connect(db_path)
    conn.executescript(SCHEMA_SQL)
    conn.commit()
    conn.close()


class AdaptiveRouter:
    """Intelligent model router that learns from outcomes.

    Strategy:
    - For non-critical tasks: try cheapest viable model first
    - If quality score < threshold: escalate to next tier
    - For critical tasks (security, fund safety): always use dual-model verification
    - Track everything, let self-improver optimize monthly
    """

    # Cost tiers (cheapest → most expensive)
    TIERS = [
        {"task": "fast_classification", "tier": 1, "critical": False},
        {"task": "x_search", "tier": 1, "critical": False},
        {"task": "classification", "tier": 2, "critical": False},
        {"task": "content_generation", "tier": 3, "critical": False},
        {"task": "deep_analysis", "tier": 3, "critical": False},
        {"task": "validation", "tier": 3, "critical": True},
        {"task": "strategic_synthesis", "tier": 4, "critical": True},
        {"task": "investigation", "tier": 4, "critical": True},
    ]

    CRITICAL_TASKS = {
        "validation",
        "strategic_synthesis",
        "investigation",
        "security_review",
        "fund_safety_check",
    }

    QUALITY_THRESHOLD = 0.7  # Below this, escalate to next tier
    MIN_SAMPLES = 10  # Need this many samples before overriding defaults

    def __init__(self, db_path: str = str(DB_PATH)):
        self.db_path = db_path
        ensure_tables(db_path)

    def get_model(self, task: str, critical: bool = False) -> str:
        """Get the best model for a task, considering learned performance.

        Args:
            task: Task type key
            critical: If True, always use top-tier model (no cost optimization)

        Returns:
            Model ID string
        """
        # Critical tasks always get the best
        if critical or task in self.CRITICAL_TASKS:
            return model_router.get_model(task)

        # Check for learned override
        override = self._get_override(task)
        if override:
            return override

        # Fall back to static config
        return model_router.get_model(task)

    def get_escalation_model(self, task: str) -> str | None:
        """Get the next-tier model to escalate to if current model quality is low.

        Returns None if already at highest tier.
        """
        current = model_router.get_model(task)
        # xAI-only escalation tiers (cheapest → flagship reasoning)
        tier_map = {
            "grok-4-1-fast-non-reasoning": "grok-4-1-fast-reasoning",
            "grok-4-1-fast-reasoning": "grok-4.20-0309-non-reasoning",
            "grok-4.20-0309-non-reasoning": "grok-4.20-0309-reasoning",
            "grok-4.20-0309-reasoning": "grok-4.20-multi-agent-0309",
            "grok-4.20-multi-agent-0309": None,  # Already at top
        }
        return tier_map.get(current)

    def record_performance(
        self,
        task: str,
        model: str,
        quality_score: float,
        cost_usd: float = 0.0,
        latency_ms: float = 0.0,
        tokens_input: int = 0,
        tokens_output: int = 0,
        escalated: bool = False,
        domain: str = "",
        engine: str = "",
    ) -> None:
        """Record a model's performance on a task for future optimization."""
        conn = connect(self.db_path)
        conn.execute(
            """INSERT INTO model_performance
               (task_type, model, quality_score, cost_usd, latency_ms,
                tokens_input, tokens_output, escalated, domain, engine)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                task,
                model,
                quality_score,
                cost_usd,
                latency_ms,
                tokens_input,
                tokens_output,
                escalated,
                domain,
                engine,
            ),
        )
        conn.commit()
        conn.close()

    def should_dual_verify(self, task: str) -> bool:
        """Should this task be verified by a second model?

        Critical tasks (security, fund safety) always get dual verification.
        Other tasks only if the primary model's quality history is inconsistent.
        """
        if task in self.CRITICAL_TASKS:
            return True

        conn = connect(self.db_path)
        try:
            row = conn.execute(
                """SELECT AVG(quality_score) as avg_q, COUNT(*) as n,
                          MIN(quality_score) as min_q
                   FROM model_performance
                   WHERE task_type = ?""",
                (task,),
            ).fetchone()

            if row and row[1] >= self.MIN_SAMPLES:
                avg_quality = row[0] or 0
                min_quality = row[2] or 0
                # High variance (min far from avg) = inconsistent = verify
                if avg_quality - min_quality > 0.3:
                    return True
        finally:
            conn.close()

        return False

    def optimize_routes(self) -> list:
        """Analyze performance data and propose route optimizations.

        Called by self-improver weekly. Returns list of proposed changes.
        """
        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row
        proposals = []

        try:
            # For each task type, find the best cost/quality ratio
            tasks = conn.execute("SELECT DISTINCT task_type FROM model_performance").fetchall()

            for task_row in tasks:
                task = task_row["task_type"]
                models = conn.execute(
                    """SELECT model,
                              AVG(quality_score) as avg_quality,
                              AVG(cost_usd) as avg_cost,
                              COUNT(*) as samples
                       FROM model_performance
                       WHERE task_type = ?
                       GROUP BY model
                       HAVING samples >= ?""",
                    (task, self.MIN_SAMPLES),
                ).fetchall()

                if len(models) < 2:
                    continue  # Need at least 2 models to compare

                # Find cheapest model that meets quality threshold
                viable = [m for m in models if (m["avg_quality"] or 0) >= self.QUALITY_THRESHOLD]

                if viable:
                    cheapest = min(viable, key=lambda m: m["avg_cost"] or 999)
                    current = model_router.get_model(task)

                    if cheapest["model"] != current:
                        savings = (model_router.estimate_cost(task, 500, 500) or 0) - (
                            cheapest["avg_cost"] or 0
                        )
                        proposals.append(
                            {
                                "task": task,
                                "current_model": current,
                                "proposed_model": cheapest["model"],
                                "quality": round(cheapest["avg_quality"], 3),
                                "estimated_monthly_savings": round(savings * 30, 2),
                                "samples": cheapest["samples"],
                            }
                        )

        finally:
            conn.close()

        return proposals

    def _get_override(self, task: str) -> str | None:
        """Check if there's a learned routing override for this task."""
        conn = connect(self.db_path)
        try:
            row = conn.execute(
                "SELECT preferred_model, confidence FROM routing_overrides WHERE task_type = ?",
                (task,),
            ).fetchone()
            if row and row[1] >= 0.7:  # Only use high-confidence overrides
                return row[0]
        finally:
            conn.close()
        return None
