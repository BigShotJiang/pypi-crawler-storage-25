# SPDX-License-Identifier: MIT
"""
Validation Spiral -- 5-tier confidence promotion system.

Adapted from a proven external research validation architecture.
Findings don't jump straight to
high confidence -- they progress through tiers with increasing verification:

    Tier 1 (raw):           Single engine, unverified.          confidence=0.20
    Tier 2 (corroborated):  Same finding from 2+ engines.       confidence=0.50
    Tier 3 (verified):      Verified against external API data. confidence=0.70
    Tier 4 (validated):     Survived contradiction checks.      confidence=0.85
    Tier 5 (established):   Stable across multiple cycles.      confidence=0.95

Contradiction penalty: -5% per contradiction, capped at -30%.
"""

import json
import logging
import sqlite3
from datetime import datetime, timezone
from enum import IntEnum

from core.persist_to_db import (
    DEFAULT_DB,
    _get_connection,
    ensure_schema,
    persist_action,
)

logger = logging.getLogger(__name__)


class Tier(IntEnum):
    """Validation tiers with ascending confidence thresholds."""

    RAW = 1
    CORROBORATED = 2
    VERIFIED = 3
    VALIDATED = 4
    ESTABLISHED = 5


TIER_CONFIDENCE: dict[Tier, float] = {
    Tier.RAW: 0.20,
    Tier.CORROBORATED: 0.50,
    Tier.VERIFIED: 0.70,
    Tier.VALIDATED: 0.85,
    Tier.ESTABLISHED: 0.95,
}

TIER_LABELS: dict[Tier, str] = {
    Tier.RAW: "raw",
    Tier.CORROBORATED: "corroborated",
    Tier.VERIFIED: "verified",
    Tier.VALIDATED: "validated",
    Tier.ESTABLISHED: "established",
}

# Contradiction penalty: -5% each, capped at -30%
CONTRADICTION_PENALTY = 0.05
MAX_CONTRADICTION_PENALTY = 0.30

# Schema extension for the validation_tier column
_SPIRAL_SCHEMA = """
CREATE TABLE IF NOT EXISTS validation_state (
    finding_id INTEGER PRIMARY KEY,
    tier INTEGER NOT NULL DEFAULT 1,
    tier_label TEXT NOT NULL DEFAULT 'raw',
    base_confidence REAL NOT NULL DEFAULT 0.20,
    contradiction_count INTEGER NOT NULL DEFAULT 0,
    effective_confidence REAL NOT NULL DEFAULT 0.20,
    corroborating_engines TEXT DEFAULT '[]',
    verified_by_api BOOLEAN DEFAULT FALSE,
    contradiction_survived BOOLEAN DEFAULT FALSE,
    stable_cycles INTEGER DEFAULT 0,
    last_promoted DATETIME,
    last_checked DATETIME,
    FOREIGN KEY (finding_id) REFERENCES evidence(id)
);

CREATE INDEX IF NOT EXISTS idx_vs_tier ON validation_state(tier);
CREATE INDEX IF NOT EXISTS idx_vs_confidence ON validation_state(effective_confidence);
"""

# Exposed at module level so core.schema_registry applies it during
# startup. Engines that import validation_spiral used to rely on
# ensure_spiral_schema() being called first, which was not guaranteed.
SCHEMA_SQL = _SPIRAL_SCHEMA


def ensure_spiral_schema(db_path: str = DEFAULT_DB) -> None:
    """Create the validation_state table if it doesn't exist."""
    ensure_schema(db_path)
    conn = _get_connection(db_path)
    try:
        conn.executescript(_SPIRAL_SCHEMA)
        conn.commit()
    finally:
        conn.close()


def _compute_effective_confidence(
    tier: Tier,
    contradiction_count: int,
) -> float:
    """Compute effective confidence from tier and contradiction count.

    Base confidence comes from the tier. Each contradiction applies a 5%
    penalty, capped at 30%.
    """
    base = TIER_CONFIDENCE[tier]
    penalty = min(
        contradiction_count * CONTRADICTION_PENALTY,
        MAX_CONTRADICTION_PENALTY,
    )
    return round(max(0.0, base - penalty), 4)


def register_finding(
    finding_id: int,
    engine: str = "",
    db_path: str = DEFAULT_DB,
) -> dict:
    """Register a new finding at Tier 1 (raw).

    Should be called when a finding is first persisted. If the finding is
    already registered, returns its current state without modification.

    Returns:
        Dict with tier, tier_label, effective_confidence.
    """
    ensure_spiral_schema(db_path)
    conn = _get_connection(db_path)
    try:
        existing = conn.execute(
            "SELECT * FROM validation_state WHERE finding_id = ?",
            (finding_id,),
        ).fetchone()
        if existing:
            cols = [
                desc[0]
                for desc in conn.execute("SELECT * FROM validation_state LIMIT 0").description
            ]
            return dict(zip(cols, existing, strict=False))

        now = datetime.now(timezone.utc).isoformat()
        base_conf = TIER_CONFIDENCE[Tier.RAW]
        conn.execute(
            """INSERT INTO validation_state
            (finding_id, tier, tier_label, base_confidence, effective_confidence,
             corroborating_engines, last_checked)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                finding_id,
                Tier.RAW,
                TIER_LABELS[Tier.RAW],
                base_conf,
                base_conf,
                json.dumps([engine] if engine else []),
                now,
            ),
        )
        conn.commit()
        logger.info(
            "Finding %d registered at Tier 1 (raw) confidence=%.2f",
            finding_id,
            base_conf,
        )
        return {
            "finding_id": finding_id,
            "tier": Tier.RAW,
            "tier_label": TIER_LABELS[Tier.RAW],
            "base_confidence": base_conf,
            "effective_confidence": base_conf,
            "contradiction_count": 0,
        }
    finally:
        conn.close()


def check_tier_requirements(
    finding_id: int,
    target_tier: Tier,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Check what requirements must be met for a finding to reach a target tier.

    Returns:
        Dict with keys: met (bool), requirements (list[str]), missing (list[str]).
    """
    ensure_spiral_schema(db_path)
    conn = _get_connection(db_path)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute(
            "SELECT * FROM validation_state WHERE finding_id = ?",
            (finding_id,),
        ).fetchone()
        if not row:
            return {
                "met": False,
                "requirements": ["Finding must be registered first"],
                "missing": ["Finding not in validation_state"],
            }

        state = dict(row)
        current_tier = Tier(state["tier"])
        requirements = []
        missing = []

        if target_tier <= current_tier:
            return {"met": True, "requirements": [], "missing": []}

        # Tier 2: need 2+ corroborating engines
        if target_tier >= Tier.CORROBORATED:
            engines = json.loads(state.get("corroborating_engines", "[]"))
            req = "Corroboration from 2+ engines"
            requirements.append(req)
            if len(set(engines)) < 2:
                missing.append(f"{req} (have {len(set(engines))})")

        # Tier 3: need API verification
        if target_tier >= Tier.VERIFIED:
            req = "Verified against external API data (HTTP 200)"
            requirements.append(req)
            if not state.get("verified_by_api"):
                missing.append(req)

        # Tier 4: need to survive contradiction checks
        if target_tier >= Tier.VALIDATED:
            req = "Survived contradiction check cycle"
            requirements.append(req)
            if not state.get("contradiction_survived"):
                missing.append(req)

        # Tier 5: need stability across multiple cycles
        if target_tier >= Tier.ESTABLISHED:
            req = "Stable across 3+ validation cycles"
            requirements.append(req)
            if state.get("stable_cycles", 0) < 3:
                missing.append(f"{req} (have {state.get('stable_cycles', 0)})")

        return {
            "met": len(missing) == 0,
            "requirements": requirements,
            "missing": missing,
        }
    finally:
        conn.close()


def promote_finding(
    finding_id: int,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Attempt to promote a finding to the next tier.

    Checks whether the finding meets the requirements for the next tier.
    If all requirements are met, promotes it and updates confidence.

    Returns:
        Dict with: promoted (bool), old_tier, new_tier, confidence, reason.
    """
    ensure_spiral_schema(db_path)
    conn = _get_connection(db_path)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute(
            "SELECT * FROM validation_state WHERE finding_id = ?",
            (finding_id,),
        ).fetchone()
        if not row:
            return {
                "promoted": False,
                "reason": "Finding not registered in validation_state",
            }

        state = dict(row)
        current_tier = Tier(state["tier"])

        if current_tier >= Tier.ESTABLISHED:
            return {
                "promoted": False,
                "old_tier": current_tier,
                "new_tier": current_tier,
                "confidence": state["effective_confidence"],
                "reason": "Already at maximum tier (ESTABLISHED)",
            }

        next_tier = Tier(current_tier + 1)
        reqs = check_tier_requirements(finding_id, next_tier, db_path)

        if not reqs["met"]:
            return {
                "promoted": False,
                "old_tier": current_tier,
                "new_tier": current_tier,
                "confidence": state["effective_confidence"],
                "reason": f"Missing requirements: {reqs['missing']}",
            }

        # Promote
        new_confidence = _compute_effective_confidence(
            next_tier,
            state["contradiction_count"],
        )
        now = datetime.now(timezone.utc).isoformat()

        conn.execute(
            """UPDATE validation_state
            SET tier = ?, tier_label = ?, base_confidence = ?,
                effective_confidence = ?, last_promoted = ?, last_checked = ?
            WHERE finding_id = ?""",
            (
                next_tier,
                TIER_LABELS[next_tier],
                TIER_CONFIDENCE[next_tier],
                new_confidence,
                now,
                now,
                finding_id,
            ),
        )
        conn.commit()

        # Also update the evidence table confidence
        conn.execute(
            "UPDATE evidence SET confidence = ? WHERE id = ?",
            (new_confidence, finding_id),
        )
        conn.commit()

        logger.info(
            "Finding %d promoted: Tier %d (%s) -> Tier %d (%s) confidence=%.2f",
            finding_id,
            current_tier,
            TIER_LABELS[current_tier],
            next_tier,
            TIER_LABELS[next_tier],
            new_confidence,
        )

        return {
            "promoted": True,
            "old_tier": current_tier,
            "new_tier": next_tier,
            "old_label": TIER_LABELS[current_tier],
            "new_label": TIER_LABELS[next_tier],
            "confidence": new_confidence,
            "reason": f"All requirements met for {TIER_LABELS[next_tier]}",
        }

    finally:
        conn.close()


def add_corroboration(
    finding_id: int,
    engine: str,
    db_path: str = DEFAULT_DB,
) -> None:
    """Record that an additional engine corroborates this finding."""
    ensure_spiral_schema(db_path)
    conn = _get_connection(db_path)
    try:
        row = conn.execute(
            "SELECT corroborating_engines FROM validation_state WHERE finding_id = ?",
            (finding_id,),
        ).fetchone()
        if not row:
            logger.warning("Finding %d not registered, cannot add corroboration", finding_id)
            return

        engines = json.loads(row[0] or "[]")
        if engine not in engines:
            engines.append(engine)
            conn.execute(
                "UPDATE validation_state SET corroborating_engines = ? WHERE finding_id = ?",
                (json.dumps(engines), finding_id),
            )
            conn.commit()
            logger.info(
                "Finding %d corroborated by %s (now %d engines)",
                finding_id,
                engine,
                len(engines),
            )
    finally:
        conn.close()


def mark_api_verified(
    finding_id: int,
    db_path: str = DEFAULT_DB,
) -> None:
    """Mark that this finding has been verified against external API data."""
    ensure_spiral_schema(db_path)
    conn = _get_connection(db_path)
    try:
        conn.execute(
            "UPDATE validation_state SET verified_by_api = TRUE WHERE finding_id = ?",
            (finding_id,),
        )
        conn.commit()
        logger.info("Finding %d marked as API-verified", finding_id)
    finally:
        conn.close()


def mark_contradiction_survived(
    finding_id: int,
    db_path: str = DEFAULT_DB,
) -> None:
    """Mark that this finding has survived a contradiction check cycle."""
    ensure_spiral_schema(db_path)
    conn = _get_connection(db_path)
    try:
        conn.execute(
            "UPDATE validation_state SET contradiction_survived = TRUE WHERE finding_id = ?",
            (finding_id,),
        )
        conn.commit()
        logger.info("Finding %d survived contradiction check", finding_id)
    finally:
        conn.close()


def increment_stable_cycles(
    finding_id: int,
    db_path: str = DEFAULT_DB,
) -> int:
    """Increment the stable cycle counter for a finding.

    Returns:
        New stable_cycles count.
    """
    ensure_spiral_schema(db_path)
    conn = _get_connection(db_path)
    try:
        row = conn.execute(
            "SELECT stable_cycles FROM validation_state WHERE finding_id = ?",
            (finding_id,),
        ).fetchone()
        if not row:
            return 0
        new_count = (row[0] or 0) + 1
        conn.execute(
            "UPDATE validation_state SET stable_cycles = ? WHERE finding_id = ?",
            (new_count, finding_id),
        )
        conn.commit()
        logger.info("Finding %d stable cycles: %d", finding_id, new_count)
        return new_count
    finally:
        conn.close()


def add_contradiction(
    finding_id: int,
    db_path: str = DEFAULT_DB,
) -> float:
    """Record a contradiction against a finding.

    Applies the -5% penalty (capped at -30%) and returns the new effective
    confidence.
    """
    ensure_spiral_schema(db_path)
    conn = _get_connection(db_path)
    try:
        row = conn.execute(
            "SELECT tier, contradiction_count FROM validation_state WHERE finding_id = ?",
            (finding_id,),
        ).fetchone()
        if not row:
            return 0.0

        tier = Tier(row[0])
        new_count = row[1] + 1
        new_confidence = _compute_effective_confidence(tier, new_count)

        conn.execute(
            """UPDATE validation_state
            SET contradiction_count = ?, effective_confidence = ?,
                last_checked = ?
            WHERE finding_id = ?""",
            (
                new_count,
                new_confidence,
                datetime.now(timezone.utc).isoformat(),
                finding_id,
            ),
        )
        conn.commit()

        # Sync to evidence table
        conn.execute(
            "UPDATE evidence SET confidence = ? WHERE id = ?",
            (new_confidence, finding_id),
        )
        conn.commit()

        logger.info(
            "Finding %d contradiction #%d: confidence now %.2f",
            finding_id,
            new_count,
            new_confidence,
        )
        return new_confidence
    finally:
        conn.close()


def get_validation_state(
    finding_id: int,
    db_path: str = DEFAULT_DB,
) -> dict | None:
    """Get the current validation state for a finding."""
    ensure_spiral_schema(db_path)
    conn = _get_connection(db_path)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute(
            "SELECT * FROM validation_state WHERE finding_id = ?",
            (finding_id,),
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def run_validation_round(
    db_path: str = DEFAULT_DB,
    domain: str | None = None,
) -> dict:
    """Process all findings that could potentially be promoted.

    Iterates through all registered findings, attempts promotion for each
    that has not yet reached Tier 5. Also increments stable_cycles for
    findings whose tier did not change since the last round.

    Args:
        db_path: Database path.
        domain:  If set, only process findings from this domain.

    Returns:
        Dict with: processed, promoted, stable_incremented, errors.
    """
    ensure_spiral_schema(db_path)
    conn = _get_connection(db_path)
    conn.row_factory = sqlite3.Row
    try:
        if domain:
            rows = conn.execute(
                """SELECT vs.finding_id, vs.tier, vs.last_promoted
                FROM validation_state vs
                JOIN evidence e ON e.id = vs.finding_id
                WHERE vs.tier < ? AND e.domain = ?""",
                (Tier.ESTABLISHED, domain),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT finding_id, tier, last_promoted FROM validation_state WHERE tier < ?",
                (Tier.ESTABLISHED,),
            ).fetchall()
    finally:
        conn.close()

    stats = {
        "processed": 0,
        "promoted": 0,
        "stable_incremented": 0,
        "errors": 0,
    }

    for row in rows:
        finding_id = row["finding_id"]
        stats["processed"] += 1

        try:
            result = promote_finding(finding_id, db_path)
            if result.get("promoted"):
                stats["promoted"] += 1
            else:
                # Not promoted -- increment stable cycle (tier unchanged)
                increment_stable_cycles(finding_id, db_path)
                stats["stable_incremented"] += 1
        except Exception as exc:
            logger.error(
                "Validation round error for finding %d: %s",
                finding_id,
                exc,
            )
            stats["errors"] += 1

    # Log the round
    try:
        persist_action(
            db_path=db_path,
            domain=domain or "system",
            module="validation_spiral",
            action="validation_round",
            result=json.dumps(stats),
        )
    except Exception as exc:
        logger.debug("Failed to persist validation round: %s", exc)

    logger.info(
        "Validation round complete: %d processed, %d promoted, %d stable, %d errors",
        stats["processed"],
        stats["promoted"],
        stats["stable_incremented"],
        stats["errors"],
    )
    return stats
