# SPDX-License-Identifier: MIT
"""Backward-compatibility shim for ``core.mission.aspirations``.

The aspiration engine lives in :mod:`core.mission.aspirations` now,
alongside the canonical aspiration templates and the mission
definition. This shim keeps legacy callers (``scripts/autonomous.py``,
tests, downstream tooling) working unchanged.
"""

from core.mission.aspirations import (  # noqa: F401
    ASPIRATIONS,
    COLLECT_EVERY_N_CYCLES,
    DEFAULT_DB,
    SCHEMA_SQL,
    STALL_CYCLES,
    AspirationRow,
    AspirationTemplate,
    _count_support,
    _discover_domain_aspirations,
    _now,
    _row_to_aspiration,
    aspirations_for_pillar,
    collect_aspirations,
    ensure_aspirations_schema,
    list_aspirations,
    mark_achieved,
    summary,
    sweep,
)

__all__ = [
    "COLLECT_EVERY_N_CYCLES",
    "SCHEMA_SQL",
    "STALL_CYCLES",
    "AspirationRow",
    "AspirationTemplate",
    "collect_aspirations",
    "ensure_aspirations_schema",
    "list_aspirations",
    "mark_achieved",
    "summary",
    "sweep",
]
