# SPDX-License-Identifier: MIT
"""
Workspace helpers - resolve the Zenon workspace root portably.

Every engine that scans sibling repos (``go-zenon``, ``syrius``, etc.)
used to do::

    ENGINE_ROOT = Path(__file__).resolve().parents[3]
    ZENON_WORKSPACE = ENGINE_ROOT.parents[1]

which breaks the moment someone clones Nebula to a directory that is
not two levels below the Zenon workspace. This module centralizes the
resolution logic and honors the ``ZENON_WORKSPACE_ROOT`` environment
variable, falling back gracefully when the workspace does not exist.

Usage::

    from core.workspace import workspace_root, workspace_repo

    root = workspace_root()          # Path or None
    go_zenon = workspace_repo("core/go-zenon")

The helper never raises. Engines that need a repo should treat a
``None`` return as ``not installed`` and persist a graceful ``no data``
finding instead of crashing.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

_NEBULA_ROOT = Path(__file__).resolve().parents[1]


@lru_cache(maxsize=1)
def workspace_root() -> Path | None:
    """Return the Zenon workspace root.

    Resolution order:
        1. ``ZENON_WORKSPACE_ROOT`` env var (if set and exists).
        2. ``~/Repos/Zenon`` (conventional location on developer
           machines). Only returned when the directory actually exists.
        3. The parent-walking fallback used by the original engines
           (``<nebula_root>/../..``), again only when it exists.

    Returns ``None`` when no candidate resolves to a real directory.
    """
    env = os.environ.get("ZENON_WORKSPACE_ROOT")
    if env:
        candidate = Path(env).expanduser().resolve()
        if candidate.is_dir():
            return candidate

    home_candidate = (Path.home() / "Repos" / "Zenon").resolve()
    if home_candidate.is_dir():
        return home_candidate

    try:
        fallback = _NEBULA_ROOT.parents[1]
    except IndexError:
        return None
    if fallback.is_dir():
        return fallback
    return None


def workspace_repo(relative: str) -> Path | None:
    """Return a path inside the workspace root, or ``None`` when missing.

    Args:
        relative: Path relative to the workspace root, e.g.
            ``"core/go-zenon"`` or ``"zenon-network/syrius"``.

    Returns:
        ``Path`` when the directory exists on disk, ``None`` otherwise.
    """
    root = workspace_root()
    if root is None:
        return None
    candidate = root / relative
    return candidate if candidate.exists() else None


def workspace_root_or_nebula() -> Path:
    """Return the workspace root, falling back to the Nebula checkout.

    Useful for engines that must have *some* base directory to work
    against (e.g. doc scanners that should at worst scan Nebula's own
    ``docs/`` tree).
    """
    root = workspace_root()
    return root if root is not None else _NEBULA_ROOT


def reset_cache() -> None:
    """Reset the memoized workspace root.

    Intended for tests that temporarily manipulate environment
    variables. Production code should not need this.
    """
    workspace_root.cache_clear()
