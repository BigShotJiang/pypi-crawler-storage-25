# SPDX-License-Identifier: MIT
"""Source Quality Scorer — content-based repo evaluation.

Phase B of the v0.4.0 content-based trust architecture (task #46).
This module scores every scanned repo on purely-deterministic content
signals with ZERO identity input. The score then drives dynamic trust
tier promotion in Phase C (v0.4.0) — see task #46 for the full
architecture rationale.

**Agent pattern:** *deterministic evaluator* (Anthropic "Building
Effective Agents" taxonomy). No LLM. No authorship inference. No
stylistic similarity between repos. The evaluator reads a repo's
content and returns a numeric score; the trust model consumes that
score without knowing who wrote the repo.

## Core principle

Trust is earned by content quality sustained over time, not granted
by name. A new pseudonymous repo that publishes high-signal Zenon-
aware work gets promoted automatically in Phase C. A famous repo that
stops publishing quality work gets demoted automatically. The
funnel-through-one-name tell that Phase 0 (hardcoded trust) creates
goes away because no repo has a hardcoded floor.

## Nine signals, each in [0, 1]

1. **spec_density** — real spec content per KB of markdown. ABI
   definitions, threat-model sections, test-vector blocks, error
   tables counted per 1000 lines.
2. **cryptographic_rigor** — density of real crypto primitives in
   code or prose: `point-lock`, `secp256k1`, `schnorr`, `taproot`,
   `merkle`, `sighash`, `ECDH`, `BIP`, `HTLC`, `PTLC`.
3. **zenon_internals_depth** — density of Zenon-specific concepts
   used with correct syntax: `pillar`, `sentinel`, `plasma`,
   `spork`, `momentum`, `accelerator`, `embedded contract`, `QSR`,
   `ZNN`, `znnd`.
4. **fund_safety_discipline** — presence of adversarial thinking:
   `reclaim`, `timeout`, `boundary`, `adversarial`, `attack`,
   `exploit`, explicit `## Errors` / `## Threat Model` sections.
5. **spec_impl_match** — does what the repo publishes actually work?
   If the repo claims an ABI method, does it match go-zenon's actual
   implementation? (Phase B stub — full match-checker ships in
   Phase C with the trust flip.)
6. **reproducibility** — presence of machine-verifiable test
   vectors, hex-encoded inputs/outputs, example transactions that
   can be executed.
7. **update_cadence** — commit frequency in a bounded recent
   window. Used for freshness, NOT for authorship — we read commit
   timestamps only, never author fields.
8. **novelty** — content the repo published first that no other
   scanned repo had. Computed via the content_hash infrastructure
   from v0.3.3. Phase B stub — full novelty scoring ships with the
   trust history table in Phase C.
9. **documentation_quality** — presence of structured sections
   (Introduction, Motivation, Specification, Errors, Test Vectors,
   References) in markdown files, indicating a serious author.

Each signal is 0-1, weighted, combined into a single
`quality_score` in [0, 1]. Weights are tunable via
`DEFAULT_WEIGHTS` and are applied in `combine_signals`.

## What this module explicitly does NOT do

- No `git log --author` reads. Ever.
- No stylistic similarity analysis between repos.
- No cross-repo authorship hypotheses.
- No external API calls (pure local-filesystem analysis).
- No LLM calls.
- No identity-adjacent features of any kind.

The anti-doxxing guarantees in `.claude/rules/opsec.md` are the
design constraint — if a future change to this module needs any of
the above, that's a bug, not a feature.
"""

from __future__ import annotations

import logging
import re
import subprocess
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Pattern libraries (deterministic, no external state)
# ---------------------------------------------------------------------------

# Cryptographic primitives that indicate the author engages with real
# crypto. Boolean-match only — we don't care how many times, just that
# they appear at all in code / comments / prose. Density computed
# separately as per-1000-LOC.
_CRYPTO_PATTERNS = [
    r"\bpoint[-_ ]?lock\b",
    r"\bsecp256k1\b",
    r"\bschnorr\b",
    r"\btaproot\b",
    r"\bmerkle\b",
    r"\bsighash\b",
    r"\becdh\b",
    r"\bbip[-_ ]?\d+\b",
    r"\bhtlc\b",
    r"\bptlc\b",
    r"\bcompressed[-_ ]?point\b",
    r"\bdiscrete[-_ ]?log\b",
    r"\bmusig\b",
    r"\bfrost\b",
]
_CRYPTO_RE = re.compile("|".join(_CRYPTO_PATTERNS), re.IGNORECASE)

# Zenon-specific concepts. Requires correct syntax — "plasma" on its
# own counts, "plasma-txpool" counts, but "plasma-physics" wouldn't
# (the negative-context check isn't word-boundary-based). Keeping the
# patterns strict.
_ZENON_INTERNALS_PATTERNS = [
    r"\bpillar\b",
    r"\bsentinel\b",
    r"\bplasma\b",
    r"\bspork\b",
    r"\bmomentum\b",
    r"\baccelerator\b",
    r"\bembedded[-_ ]?contract\b",
    r"\bqsr\b",
    r"\bznn\b",
    r"\bznnd\b",
    r"\bnom[-_ ]?consensus\b",
    r"\bdual[-_ ]?coin\b",
    r"\bdeal[-_ ]?with[-_ ]?err\b",
    r"\bhyperqube\b",
]
_ZENON_RE = re.compile("|".join(_ZENON_INTERNALS_PATTERNS), re.IGNORECASE)

# Adversarial / fund-safety discipline. Presence indicates the author
# thinks about attackers.
_FUND_SAFETY_PATTERNS = [
    r"\breclaim\b",
    r"\btime[-_ ]?lock\b",
    r"\bexpir(?:ation|y|ed)\b",
    r"\bboundary\b",
    r"\badversari(?:al|es|y)\b",
    r"\battack[-_ ]?vector\b",
    r"\bexploit\b",
    r"\brefund[-_ ]?path\b",
    r"\breentrancy\b",
    r"\bfront[-_ ]?running\b",
    r"\bmempool\b",
    r"\bchain[-_ ]?reorg\b",
]
_FUND_SAFETY_RE = re.compile("|".join(_FUND_SAFETY_PATTERNS), re.IGNORECASE)

# Markdown section headings that indicate a serious spec author:
# Introduction, Motivation, Specification, Errors, Test Vectors, etc.
_STRUCTURED_SECTION_HEADINGS = re.compile(
    r"^#{1,3}\s+\d*\.?\s*(?:"
    r"introduction|motivation|specification|rationale|threat[-_ ]?model|"
    r"security[-_ ]?model|security[-_ ]?considerations|errors?|"
    r"error[-_ ]?returns?|failure[-_ ]?modes?|test[-_ ]?vectors?|"
    r"conformance[-_ ]?tests?|reference[-_ ]?implementation|abi|"
    r"examples?|worked[-_ ]?examples?|reference|references|"
    r"backward[-_ ]?compatibility|deployment|activation"
    r")\s*$",
    re.IGNORECASE | re.MULTILINE,
)

# ABI-method tables in markdown. Only counts rows inside tables whose
# header row contains a method/function/abi marker — same logic as
# spec_audit._count_abi_methods, reused here for consistency.
_ABI_TABLE_HEADER = re.compile(r"\b(method|function|abi|signature|operation|api)\b", re.IGNORECASE)

# Test vector detection — fenced code blocks OR table rows with hex
# strings. A spec that ships hex inputs/outputs that an implementer
# can mechanically verify is high-signal.
_HEX_BLOB_RE = re.compile(r"\b0x[0-9a-fA-F]{8,}\b")

# Files we scan. Markdown + common source code extensions.
_SCANNED_EXTENSIONS = {
    ".md",
    ".go",
    ".rs",
    ".sol",
    ".dart",
    ".py",
    ".ts",
    ".js",
    ".txt",
}

# Files we never scan (noise, binary, or generated).
_SKIPPED_DIR_NAMES = {
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    "build",
    "dist",
    "target",
    ".idea",
    ".vscode",
    "site",
    "vendor",
}

# Size caps so we don't hang on huge repos
_MAX_FILE_SIZE_BYTES = 1 * 1024 * 1024  # 1 MB per file
_MAX_FILES_SCANNED = 500  # per repo per scoring pass
_MAX_TOTAL_BYTES_SCANNED = 50 * 1024 * 1024  # 50 MB per repo per pass


# ---------------------------------------------------------------------------
# Default signal weights (tunable via DEFAULT_WEIGHTS)
# ---------------------------------------------------------------------------

DEFAULT_WEIGHTS: dict[str, float] = {
    "spec_density": 0.14,
    "cryptographic_rigor": 0.14,
    "zenon_internals_depth": 0.18,
    "fund_safety_discipline": 0.12,
    "spec_impl_match": 0.10,  # stub in Phase B
    "reproducibility": 0.10,
    "update_cadence": 0.08,
    "novelty": 0.08,  # stub in Phase B
    "documentation_quality": 0.06,
}


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class SourceQuality:
    """Content-derived quality score for a repo.

    Attributes:
        repo_identity: The owner/repo string identifier (no paths).
        quality_score: Overall score in [0, 1], weighted combination
            of the per-signal scores.
        signals: Per-signal scores, each in [0, 1].
        files_scanned: How many files contributed to the score.
        bytes_scanned: Total bytes read (bounded by
            _MAX_TOTAL_BYTES_SCANNED).
        scan_duration_seconds: Wall-clock time to compute the score.
        scanned_at: ISO-8601 UTC timestamp.
    """

    repo_identity: str
    quality_score: float
    signals: dict[str, float]
    files_scanned: int
    bytes_scanned: int
    scan_duration_seconds: float
    scanned_at: str
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Return a JSON-serializable dict."""
        return asdict(self)


# ---------------------------------------------------------------------------
# Per-signal scorers
# ---------------------------------------------------------------------------


def _score_boolean_density(content: str, pattern_re: re.Pattern, saturation: int = 10) -> float:
    """Sigmoid-ish score on pattern hit count.

    Returns 0 at zero hits, 1 at ``saturation`` hits, linear in between.
    This avoids rewarding repos that spam the same keyword 100x while
    still giving diminishing-returns credit for genuine breadth.

    Args:
        content: Text to scan.
        pattern_re: Compiled regex.
        saturation: Hit count at which the score hits 1.0.
    """
    hits = len(pattern_re.findall(content))
    if hits == 0:
        return 0.0
    return min(1.0, hits / saturation)


def score_spec_density(markdown_content: str) -> float:
    """Density of real spec content per 1000 lines of markdown.

    Counts ABI table rows, structured section headings, and
    test-vector-adjacent hex blobs per 1000 lines. A dense spec
    easily hits 1.0; a sparse one stays near 0.

    Small-file smoothing: files under ``MIN_LINES_FOR_DENSITY`` lines
    get scaled by ``(line_count / MIN_LINES_FOR_DENSITY)`` so a 4-line
    README that happens to contain one structured heading doesn't
    score 1.0 — it has to have genuine volume to hit saturation.
    """
    if not markdown_content:
        return 0.0
    line_count = max(1, markdown_content.count("\n"))

    # ABI method table rows (strict header check, same as spec_audit)
    abi_method_rows = 0
    table_blocks = re.findall(r"((?:^\|[^\n]*\n)+)", markdown_content, flags=re.MULTILINE)
    for block in table_blocks:
        block_lines = block.strip().split("\n")
        if not block_lines:
            continue
        header = block_lines[0].lower()
        if not _ABI_TABLE_HEADER.search(header):
            continue
        for line in block_lines[2:]:
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if cells and cells[0]:
                abi_method_rows += 1

    # Structured section headings
    headings = len(_STRUCTURED_SECTION_HEADINGS.findall(markdown_content))

    # Hex blobs (test vectors or example transactions)
    hex_blobs = len(_HEX_BLOB_RE.findall(markdown_content))

    # Combine: density per 1000 lines, sigmoid-capped, small-file smoothed
    min_lines_for_density = 50
    items = abi_method_rows + headings + hex_blobs
    per_1000 = items / line_count * 1000
    raw_score = min(1.0, per_1000 / 15.0)  # saturates around 15 items/1000 lines

    # Small-file smoothing: a 4-line README with one heading shouldn't
    # hit 1.0. Scale by volume until the file has enough content to
    # justify its density number.
    if line_count < min_lines_for_density:
        volume_scale = line_count / min_lines_for_density
        raw_score *= volume_scale

    return raw_score


def score_cryptographic_rigor(text: str) -> float:
    """Score 0-1 on cryptographic-primitive mentions."""
    return _score_boolean_density(text, _CRYPTO_RE, saturation=8)


def score_zenon_internals_depth(text: str) -> float:
    """Score 0-1 on Zenon-specific concept density."""
    return _score_boolean_density(text, _ZENON_RE, saturation=15)


def score_fund_safety_discipline(text: str) -> float:
    """Score 0-1 on adversarial / fund-safety language density."""
    return _score_boolean_density(text, _FUND_SAFETY_RE, saturation=8)


def score_reproducibility(text: str) -> float:
    """Score 0-1 on machine-verifiable test data presence.

    Hex blobs of reasonable length + fenced code blocks with inputs
    and outputs are strong indicators that the author intends the
    spec to be mechanically verifiable.
    """
    hex_count = len(_HEX_BLOB_RE.findall(text))
    # Fenced code blocks
    fence_count = text.count("```")
    blocks = max(0, fence_count // 2)

    # Weight hex more than generic fences (generic fences can be
    # config examples, hex is almost always real test data)
    score = (hex_count / 20.0) * 0.7 + (blocks / 15.0) * 0.3
    return min(1.0, score)


def score_documentation_quality(markdown_content: str) -> float:
    """Score 0-1 on structured section presence in markdown."""
    hits = len(_STRUCTURED_SECTION_HEADINGS.findall(markdown_content))
    return min(1.0, hits / 8.0)  # saturates at 8 structured sections


def score_update_cadence(repo_path: Path) -> float:
    """Score 0-1 on commit frequency in the last 30 days.

    Reads commit TIMESTAMPS only — never author fields, never commit
    message content (that's curiosity_scanner's job). 5+ commits in
    the window = 1.0, 0 commits = 0.0, linear in between.
    """
    if not (repo_path / ".git").exists():
        return 0.0
    try:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
        result = subprocess.run(
            [
                "git",
                "log",
                f"--since={cutoff}",
                "--format=%H",
                "--max-count=50",
            ],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return 0.0
        commits = [line for line in result.stdout.split("\n") if line.strip()]
        return min(1.0, len(commits) / 5.0)
    except (subprocess.TimeoutExpired, OSError) as exc:
        logger.debug("git log failed for %s: %s", repo_path, exc)
        return 0.0


def score_spec_impl_match(repo_path: Path) -> float:
    """Stub in Phase B — full implementation lands in Phase C.

    Phase B returns 0.5 (neutral) for any repo that has at least one
    markdown spec file. Phase C will cross-reference every ABI method
    claimed in the spec against the actual go-zenon implementation
    and return a precision score.
    """
    for md_file in repo_path.rglob("*.md"):
        if any(part in _SKIPPED_DIR_NAMES for part in md_file.parts):
            continue
        return 0.5
    return 0.0


def score_novelty(repo_identity: str, db_path: str | None = None) -> float:
    """Stub in Phase B — full implementation lands in Phase C.

    Phase B returns 0.5 (neutral) so novelty doesn't dominate the
    score before the repo_trust_history table is populated. Phase C
    will compute novelty as the fraction of content_hashes this repo
    published first that no other scanned repo had at the time.
    """
    return 0.5


# ---------------------------------------------------------------------------
# Top-level scorer
# ---------------------------------------------------------------------------


def _should_scan_file(path: Path) -> bool:
    """Return True if the file should contribute to the score."""
    if path.suffix.lower() not in _SCANNED_EXTENSIONS:
        return False
    if any(part in _SKIPPED_DIR_NAMES for part in path.parts):
        return False
    try:
        if path.stat().st_size > _MAX_FILE_SIZE_BYTES:
            return False
    except OSError:
        return False
    return True


def _read_repo_content(repo_path: Path) -> tuple[str, str, int, int]:
    """Read bounded content from a repo.

    Returns (markdown_content, all_content, files_scanned, bytes_scanned).
    """
    markdown_parts: list[str] = []
    all_parts: list[str] = []
    files_scanned = 0
    bytes_scanned = 0

    for file_path in repo_path.rglob("*"):
        if files_scanned >= _MAX_FILES_SCANNED:
            break
        if bytes_scanned >= _MAX_TOTAL_BYTES_SCANNED:
            break
        if not file_path.is_file():
            continue
        if not _should_scan_file(file_path):
            continue

        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        files_scanned += 1
        bytes_scanned += len(content.encode("utf-8", errors="replace"))
        all_parts.append(content)
        if file_path.suffix.lower() == ".md":
            markdown_parts.append(content)

    return (
        "\n\n".join(markdown_parts),
        "\n\n".join(all_parts),
        files_scanned,
        bytes_scanned,
    )


def score_repo(
    repo_path: Path | str,
    repo_identity: str | None = None,
    db_path: str | None = None,
    weights: dict[str, float] | None = None,
) -> SourceQuality:
    """Score a single repo on content-quality signals.

    Args:
        repo_path: Absolute path to the repo directory.
        repo_identity: Canonical owner/repo string. Defaults to the
            repo directory name if not provided.
        db_path: SQLite DB path (for novelty signal — stub in Phase B).
        weights: Optional override for DEFAULT_WEIGHTS.

    Returns:
        SourceQuality dataclass with overall score + per-signal
        breakdown. Always returns a valid result even for
        missing / empty / unreadable repos (quality_score=0 in that
        case).
    """
    start = datetime.now(timezone.utc)
    repo_path = Path(repo_path)
    if repo_identity is None:
        repo_identity = repo_path.name

    weights = weights or DEFAULT_WEIGHTS
    notes: list[str] = []

    if not repo_path.is_dir():
        return SourceQuality(
            repo_identity=repo_identity,
            quality_score=0.0,
            signals=dict.fromkeys(weights, 0.0),
            files_scanned=0,
            bytes_scanned=0,
            scan_duration_seconds=0.0,
            scanned_at=start.isoformat(),
            notes=["repo path not a directory"],
        )

    markdown_content, all_content, files_scanned, bytes_scanned = _read_repo_content(repo_path)

    if files_scanned == 0:
        notes.append("no scannable files found")

    signals: dict[str, float] = {
        "spec_density": score_spec_density(markdown_content),
        "cryptographic_rigor": score_cryptographic_rigor(all_content),
        "zenon_internals_depth": score_zenon_internals_depth(all_content),
        "fund_safety_discipline": score_fund_safety_discipline(all_content),
        "spec_impl_match": score_spec_impl_match(repo_path),
        "reproducibility": score_reproducibility(all_content),
        "update_cadence": score_update_cadence(repo_path),
        "novelty": score_novelty(repo_identity, db_path=db_path),
        "documentation_quality": score_documentation_quality(markdown_content),
    }

    # Weighted combination
    quality_score = 0.0
    total_weight = 0.0
    for key, weight in weights.items():
        if key in signals:
            quality_score += signals[key] * weight
            total_weight += weight
    if total_weight > 0:
        quality_score = quality_score / total_weight
    quality_score = max(0.0, min(1.0, quality_score))

    duration = (datetime.now(timezone.utc) - start).total_seconds()

    return SourceQuality(
        repo_identity=repo_identity,
        quality_score=quality_score,
        signals=signals,
        files_scanned=files_scanned,
        bytes_scanned=bytes_scanned,
        scan_duration_seconds=duration,
        scanned_at=start.isoformat(),
        notes=notes,
    )
