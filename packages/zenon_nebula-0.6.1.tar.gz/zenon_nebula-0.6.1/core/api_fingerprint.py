# SPDX-License-Identifier: MIT
"""
FingerprintedSession -- Tracks every HTTP call for provenance verification.

Every API call made by any engine is logged with URL, method, status, latency,
and response size. This prevents hallucination: findings MUST be traceable to
real API responses.

Generalized from marketing domain to support multi-domain operation with
domain tagging on every fingerprint.
"""

import hashlib
import json
import logging
import time
from datetime import datetime, timezone

import requests

from core.opsec import OPSECGuard

logger = logging.getLogger(__name__)


class FingerprintedSession(requests.Session):
    """HTTP session wrapper that fingerprints every API call.

    All outbound headers are automatically sanitized via OPSECGuard to
    prevent operator identification through User-Agent, Referer, or
    other revealing headers.

    Usage::

        session = FingerprintedSession(engine_name="github_watcher", domain="intelligence")
        resp = session.get("https://api.github.com/repos/zenon-network/go-zenon")
        fingerprints = session.get_fingerprints()
        provenance = classify_provenance(fingerprints)
    """

    def __init__(self, engine_name: str = "unknown", domain: str = "system"):
        super().__init__()
        self._fingerprints: list[dict] = []
        self._engine_name = engine_name
        self._domain = domain
        self.headers.update(
            {
                "User-Agent": OPSECGuard.generate_anonymous_user_agent(),
            }
        )

    def request(self, method: str, url: str, **kwargs) -> requests.Response:
        """Override to fingerprint every request and sanitize headers."""
        # Sanitize all outbound headers via OPSECGuard before every request
        merged_headers = dict(self.headers)
        merged_headers.update(kwargs.get("headers", {}))
        kwargs["headers"] = OPSECGuard.sanitize_headers(merged_headers)

        start = time.monotonic()
        try:
            response = super().request(method, url, **kwargs)
            latency_ms = (time.monotonic() - start) * 1000

            self._fingerprints.append(
                {
                    "url": url,
                    "method": method.upper(),
                    "status_code": response.status_code,
                    "response_size_bytes": len(response.content),
                    "latency_ms": round(latency_ms, 1),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "engine": self._engine_name,
                    "domain": self._domain,
                    "content_type": response.headers.get("content-type", ""),
                }
            )
            return response

        except requests.RequestException as exc:
            latency_ms = (time.monotonic() - start) * 1000
            self._fingerprints.append(
                {
                    "url": url,
                    "method": method.upper(),
                    "status_code": 0,
                    "error": str(exc),
                    "latency_ms": round(latency_ms, 1),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "engine": self._engine_name,
                    "domain": self._domain,
                }
            )
            raise

    def get_fingerprints(self) -> list[dict]:
        """Return all API calls made by this session."""
        return self._fingerprints.copy()

    def get_fingerprint_hash(self) -> str:
        """SHA-256 hash of all fingerprints for integrity verification."""
        fp_text = json.dumps(self._fingerprints, sort_keys=True)
        return hashlib.sha256(fp_text.encode()).hexdigest()

    def get_successful_urls(self) -> list[str]:
        """Return URLs that returned HTTP 200."""
        return [fp["url"] for fp in self._fingerprints if fp.get("status_code") == 200]

    def has_api_evidence(self) -> bool:
        """True if at least one successful API call was made."""
        return any(fp.get("status_code") == 200 for fp in self._fingerprints)

    def get_call_count(self) -> int:
        """Total number of API calls made."""
        return len(self._fingerprints)

    def get_error_count(self) -> int:
        """Number of failed API calls."""
        return sum(1 for fp in self._fingerprints if fp.get("status_code", 0) == 0)

    def get_total_latency_ms(self) -> float:
        """Total latency across all API calls."""
        return sum(fp.get("latency_ms", 0) for fp in self._fingerprints)


def classify_provenance(fingerprints: list[dict]) -> str:
    """Classify the provenance of results based on API fingerprints.

    Returns:
        "verified_by_api"  -- HTTP 200 responses from external APIs
        "computational"    -- API called but results derived computationally
        "hypothesis"       -- No API evidence, pure LLM reasoning
    """
    if not fingerprints:
        return "hypothesis"

    successful = [fp for fp in fingerprints if fp.get("status_code") == 200]
    if len(successful) >= 1:
        return "verified_by_api"

    attempted = [fp for fp in fingerprints if fp.get("status_code", 0) > 0]
    if len(attempted) >= 1:
        return "computational"

    return "hypothesis"
