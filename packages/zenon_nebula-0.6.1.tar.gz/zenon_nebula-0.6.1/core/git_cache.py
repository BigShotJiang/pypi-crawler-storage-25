# SPDX-License-Identifier: MIT
"""Git hash gating for Nebula autonomous runner.

Caches HEAD commit hashes per repo so engines can skip work
when nothing has changed upstream. Resets on process restart,
which is fine -- a fresh run re-scans everything once.
"""

import subprocess

# Module-level caches
_head_cache: dict[str, str] = {}  # repo_path -> last-seen HEAD hash
_identity_cache: dict[str, str] = {}  # repo_path -> canonical identity (owner/repo)


def get_repo_head(repo_path: str) -> str:
    """Return the HEAD commit hash for *repo_path*.

    Returns an empty string if the path is not a git repository
    or git is otherwise unavailable.
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        pass
    return ""


def has_repo_changed(repo_path: str) -> bool:
    """Check whether *repo_path* HEAD differs from the cached value.

    Returns True on the first call for a given path (cache miss)
    or when HEAD has moved since the last check.  Returns False
    when HEAD is unchanged.  Always updates the cache.
    """
    current = get_repo_head(repo_path)
    if not current:
        # Not a git repo or git failed -- treat as changed so
        # callers don't silently skip work.
        return True

    previous = _head_cache.get(repo_path)
    _head_cache[repo_path] = current
    return previous is None or previous != current


def get_repo_identity(repo_path: str) -> str:
    """Return a canonical identity for a git repo, regardless of folder name.

    Uses the origin remote URL normalized to a comparable form:
      git@github.com:zenon-network/go-zenon.git → zenon-network/go-zenon
      https://github.com/ZenonOrg/go-zenon.git  → ZenonOrg/go-zenon

    Falls back to folder name if no remote is configured.
    """
    cached = _identity_cache.get(repo_path)
    if cached is not None:
        return cached

    identity = _resolve_identity(repo_path)
    _identity_cache[repo_path] = identity
    return identity


def _resolve_identity(repo_path: str) -> str:
    """Resolve repo identity from git remote, then upstream, then folder name.

    Priority:
      1. origin remote URL → owner/repo (canonical)
      2. upstream remote URL → owner/repo (fork detection)
      3. Folder name (plain directory, not a git repo)
    """
    for remote_name in ("origin", "upstream"):
        try:
            result = subprocess.run(
                ["git", "remote", "get-url", remote_name],
                cwd=repo_path,
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                url = result.stdout.strip()
                return normalize_remote_url(url)
        except (OSError, subprocess.TimeoutExpired):
            pass

    # Fallback: just use the folder name (works for plain dirs too)
    import os

    return os.path.basename(os.path.normpath(repo_path))


def normalize_remote_url(url: str) -> str:
    """Normalize a git remote URL to owner/repo form.

    Handles:
      git@github.com:owner/repo.git → owner/repo
      https://github.com/owner/repo.git → owner/repo
      https://github.com/owner/repo → owner/repo
      ssh://git@github.com/owner/repo → owner/repo
    """
    url = url.strip()

    # SSH: git@github.com:owner/repo.git
    if ":" in url and "@" in url.split(":")[0]:
        path = url.split(":")[-1]
    # HTTPS/SSH: https://github.com/owner/repo.git
    elif "/" in url:
        # Strip protocol
        path = url.split("//")[-1] if "//" in url else url
        # Strip hostname
        parts = path.split("/")
        if len(parts) >= 3:
            path = "/".join(parts[-2:])
        else:
            path = parts[-1]
    else:
        return url

    # Strip .git suffix
    if path.endswith(".git"):
        path = path[:-4]

    return path


def reset_cache() -> None:
    """Clear all cached HEAD hashes and identities."""
    _head_cache.clear()
    _identity_cache.clear()
