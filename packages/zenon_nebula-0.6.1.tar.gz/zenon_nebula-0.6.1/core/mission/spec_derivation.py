# SPDX-License-Identifier: MIT
"""
Spec-derived mission — read TminusZ specs, synthesise Nebula's north star.

Nebula's mission used to be a hardcoded five-pillar block in
``core/mission/definition.py``. That was fine for bootstrap but it has
three structural problems:

1. **No provenance.** The pillars were our opinion. A reviewer could
   not trace any pillar back to an on-disk source of truth.
2. **Drift.** As TminusZ publishes new specs, the implicit mission
   evolves — but the hardcoded pillars did not.
3. **Objectivity.** Nebula scores engines against the mission. If the
   mission is our opinion, Nebula is grading engines against us,
   not against what the protocol is actually designed around.

This module fixes all three by deriving the mission at runtime:

1. :func:`find_spec_directories` walks the workspace for every repo
   that looks like it contains a spec corpus (most importantly
   ``knowledge/developer-commons/docs/specs``).
2. :func:`extract_spec_goals` parses each ``.md`` file in those
   directories and pulls out ``Abstract`` / ``Motivation`` /
   ``Rationale`` / ``Goals`` / ``Principles`` sections.
3. :func:`synthesize_mission` ships the extracted text to
   :func:`core.llm_provider.call_llm` and asks it to distil a
   mission name + 3-7 pillars with provenance.
4. :func:`persist_derived_mission` stores the result in the
   ``derived_mission`` table (declared in core schema) so the Director
   and status surfaces can read it.
5. :func:`refresh_if_stale` re-derives when the stored mission is
   older than ``max_age_days`` or the spec repo commit has changed.

If the workspace is missing (CI, cold-start) every function degrades
gracefully: the walker returns ``[]``, the extractor returns ``[]``,
and ``load_current_mission`` returns ``None``. Callers fall back to
the hardcoded pillars via :func:`core.mission.definition.get_active_mission`.

Module-level ``SCHEMA_SQL`` is exposed for documentation and for the
schema_registry, but the canonical copy lives in
``core/persistence/schema.py`` so fresh core databases pick it up on
first boot without waiting on submodule walks.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from core.persistence.metrics import persist_metric, query_table
from core.workspace import workspace_root

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Schema (authoritative copy lives in core/persistence/schema.py — this
# constant is kept here for documentation, schema_registry pickup, and
# so that any future schema audit can confirm this module owns the table)
# ---------------------------------------------------------------------------

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS derived_mission (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    pillars_json TEXT NOT NULL,
    source_commit TEXT,
    source_repo TEXT,
    derived_at TEXT NOT NULL,
    llm_model TEXT,
    llm_cost_usd REAL DEFAULT 0.0,
    raw_synthesis TEXT
);
CREATE INDEX IF NOT EXISTS idx_derived_mission_derived_at
    ON derived_mission(derived_at);
"""


# Spec directory names we recognise. We keep this list small and
# deliberate — speculative matches trigger false positives in
# sprawling workspaces.
_SPEC_DIR_CANDIDATES: tuple[tuple[str, ...], ...] = (
    ("docs", "specs"),
    ("specs",),
    ("zips",),
    ("docs", "zips"),
)

# Sections we care about when summarising a spec. Order matters: when
# we truncate to fit an LLM context window we keep the earlier ones.
_SECTION_HEADERS: tuple[str, ...] = (
    "abstract",
    "motivation",
    "rationale",
    "goals",
    "principles",
)

# Max characters of spec text handed to the LLM in one call. Keeps
# synthesis costs bounded regardless of corpus size.
_MAX_SYNTHESIS_CHARS = 40_000


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------


def find_spec_directories() -> list[Path]:
    """Walk the Zenon workspace and return every directory that looks like a spec corpus.

    A directory qualifies when its relative path, under a repo root,
    matches one of the known layouts in ``_SPEC_DIR_CANDIDATES``
    (``docs/specs``, ``specs``, ``zips``, ``docs/zips``).

    The walker only inspects the first two levels below the workspace
    root (repos sit at ``<workspace>/<org>/<repo>`` or
    ``<workspace>/<repo>``) to keep the scan cheap on large trees. It
    never raises; when no workspace is present it logs once at INFO
    level and returns an empty list.

    Returns:
        Absolute :class:`pathlib.Path` objects, one per detected spec
        directory. Order is deterministic (sorted by path) so callers
        get reproducible extraction order.
    """
    root = workspace_root()
    if root is None:
        logger.info(
            "find_spec_directories: no Zenon workspace present — "
            "spec derivation will fall back to hardcoded pillars."
        )
        return []

    found: set[Path] = set()
    # Walk two levels deep: <workspace>/* and <workspace>/*/*.
    repo_candidates: list[Path] = []
    try:
        for entry in root.iterdir():
            if not entry.is_dir() or entry.name.startswith("."):
                continue
            repo_candidates.append(entry)
            try:
                for child in entry.iterdir():
                    if child.is_dir() and not child.name.startswith("."):
                        repo_candidates.append(child)
            except OSError as exc:
                logger.debug("spec walk skipped %s: %s", entry, exc)
    except OSError as exc:
        logger.warning("spec walk of %s failed: %s", root, exc)
        return []

    for repo in repo_candidates:
        for layout in _SPEC_DIR_CANDIDATES:
            candidate = repo.joinpath(*layout)
            if candidate.is_dir():
                found.add(candidate.resolve())

    return sorted(found)


# ---------------------------------------------------------------------------
# Extraction
# ---------------------------------------------------------------------------


_HEADER_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$", re.MULTILINE)


def _split_sections(text: str) -> list[tuple[str, str]]:
    """Return ``[(header_lower, body)]`` tuples from a markdown doc.

    The body of each section runs from just after its header line up
    to (but not including) the next header line of equal or greater
    depth. Unlike a full markdown parser this does not understand
    front-matter, code fences, or nested headers — by design. We want
    a cheap, deterministic split that exposes the top-level spec
    structure for keyword filtering.
    """
    headers = list(_HEADER_RE.finditer(text))
    if not headers:
        return []
    sections: list[tuple[str, str]] = []
    for idx, match in enumerate(headers):
        start = match.end()
        end = headers[idx + 1].start() if idx + 1 < len(headers) else len(text)
        title = match.group(2).strip().lower()
        body = text[start:end].strip()
        sections.append((title, body))
    return sections


def extract_spec_goals(spec_dir: Path) -> list[dict[str, str]]:
    """Walk ``spec_dir`` and extract goal-bearing sections from every ``.md`` file.

    For every markdown file under ``spec_dir`` (recursively) this
    parses top-level headers and keeps only the sections whose title
    matches one of :data:`_SECTION_HEADERS` (``abstract``,
    ``motivation``, ``rationale``, ``goals``, ``principles``).
    Matching is case-insensitive and allows the header to start with
    an extra token (e.g. ``## 2. Motivation``) — we split on
    whitespace and check every token.

    Args:
        spec_dir: Absolute path to a directory returned by
            :func:`find_spec_directories`.

    Returns:
        List of dicts with ``file`` (relative to ``spec_dir``),
        ``section`` (lowercase canonical header name), and ``text``
        (the section body). Returns an empty list when the directory
        is missing, unreadable, or contains no matching sections.
    """
    if not spec_dir.is_dir():
        return []

    goals: list[dict[str, str]] = []
    try:
        md_files = sorted(spec_dir.rglob("*.md"))
    except OSError as exc:
        logger.warning("extract_spec_goals rglob failed for %s: %s", spec_dir, exc)
        return []

    for md_path in md_files:
        try:
            raw = md_path.read_text(encoding="utf-8", errors="ignore")
        except OSError as exc:
            logger.debug("Cannot read %s: %s", md_path, exc)
            continue

        for header, body in _split_sections(raw):
            canonical = _match_canonical_header(header)
            if canonical is None:
                continue
            if not body:
                continue
            try:
                rel = str(md_path.relative_to(spec_dir))
            except ValueError:
                rel = md_path.name
            goals.append({"file": rel, "section": canonical, "text": body})

    return goals


def _match_canonical_header(header: str) -> str | None:
    """Return the canonical section name for ``header`` or None.

    Accepts headers with leading numbering (``"2. motivation"``),
    trailing punctuation, or parenthetical suffixes. Matching is
    strictly token-based against :data:`_SECTION_HEADERS`.
    """
    stripped = re.sub(r"[^a-z0-9\s]", " ", header.lower())
    tokens = stripped.split()
    for token in tokens:
        if token in _SECTION_HEADERS:
            return token
    return None


# ---------------------------------------------------------------------------
# Synthesis
# ---------------------------------------------------------------------------


_SYNTHESIS_SYSTEM_PROMPT = (
    "You are distilling the mission of a blockchain project from its "
    "authoritative specifications. You are NOT writing marketing copy. "
    "You are NOT promoting anything. You are producing a structured "
    "mission statement a deterministic scoring engine will consume.\n\n"
    "Return STRICT JSON with this shape:\n"
    "{\n"
    '  "name": "<short mission name, <= 80 chars>",\n'
    '  "one_liner": "<one sentence capturing the mission>",\n'
    '  "pillars": [\n'
    '    {"name": "<pillar name>", '
    '"description": "<one sentence>", '
    '"priority": <1-10 integer>, '
    '"evidence_files": ["<file1>", "<file2>"]}\n'
    "  ]\n"
    "}\n\n"
    "Rules:\n"
    "- 3 to 7 pillars, no more, no fewer.\n"
    "- Pillars must be derived from the provided spec excerpts, not "
    "general blockchain knowledge.\n"
    "- Each pillar's description must be traceable to at least one "
    "file in evidence_files.\n"
    "- Priority is a relative importance ranking (10 = most important).\n"
    "- Return ONLY the JSON object, no prose, no markdown fences."
)


def _git_head(path: Path) -> str | None:
    """Return the HEAD commit hash for a git repo at ``path`` (or None)."""
    if not (path / ".git").exists():
        return None
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        logger.debug("git rev-parse failed in %s: %s", path, exc)
        return None
    if result.returncode != 0:
        return None
    commit = result.stdout.strip()
    return commit or None


def _find_source_repo(spec_goals: list[dict[str, str]]) -> tuple[Path | None, str | None]:
    """Infer the owning repo (and its HEAD commit) for a set of extracted goals.

    The strategy: the spec directory passed to :func:`extract_spec_goals`
    lives inside some git repo. Walk upwards from the first extracted
    file until we find a ``.git`` directory. Returns the repo path and
    HEAD commit, or ``(None, None)`` when we cannot determine either.

    Args:
        spec_goals: The exact list returned by extract calls for a
            single spec directory. The first entry's ``file`` path is
            sufficient because every entry shares the same root.
    """
    # The extractor returns files relative to spec_dir, so we have to
    # reconstruct the absolute path through the workspace. Callers that
    # need commit provenance should pass the spec_dir explicitly via
    # synthesize_mission's source_repo_path argument; this helper is
    # only a fallback.
    return (None, None)


def _fallback_synthesis(goals: list[dict[str, str]]) -> dict[str, Any]:
    """Deterministic fallback mission when the LLM is unavailable.

    Produces a single "read_the_specs" pillar pointing at the files
    that were successfully extracted. This is NOT a real mission —
    it's a sentinel so callers can tell synthesis failed without
    crashing. Consumers check ``provenance`` on the returned mission
    to decide whether to trust it.
    """
    files = sorted({g["file"] for g in goals})[:10]
    return {
        "name": "Spec corpus reference (fallback)",
        "one_liner": (
            "Synthesis unavailable — treat the spec corpus as the "
            "source of truth until the mission can be re-derived."
        ),
        "pillars": [
            {
                "name": "spec_corpus_reference",
                "description": (
                    "Implement and verify every spec in the corpus. "
                    "This pillar exists only because automated "
                    "synthesis was not available at derivation time."
                ),
                "priority": 5,
                "evidence_files": files,
            }
        ],
    }


def synthesize_mission(
    goals: list[dict[str, str]],
    *,
    llm_call: Callable[..., Any] | None = None,
    source_repo_path: Path | None = None,
) -> dict[str, Any]:
    """Turn extracted spec goals into a structured mission via the LLM.

    The caller is expected to have produced ``goals`` via one or more
    :func:`extract_spec_goals` passes. This function builds a single
    prompt (truncated to :data:`_MAX_SYNTHESIS_CHARS` characters) and
    asks the LLM to return a JSON object with ``name``, ``one_liner``,
    and a ``pillars`` list of 3 to 7 entries.

    Args:
        goals: Output of :func:`extract_spec_goals`. Empty input
            returns an empty (but well-formed) mission dict — never
            raises.
        llm_call: Optional callable with the same shape as
            :func:`core.llm_provider.call_llm`. Tests inject this to
            avoid real API traffic. When ``None`` the real provider
            is imported lazily.
        source_repo_path: Optional path to the git repo that owns the
            spec corpus. Used to record ``source_commit`` and
            ``source_repo`` on the returned mission for provenance.

    Returns:
        Dict with keys ``name``, ``one_liner``, ``pillars``,
        ``source_commit``, ``source_repo``, ``derived_at``,
        ``llm_model``, ``llm_cost_usd``, ``raw_synthesis``, and
        ``provenance`` (``"synthesized"`` on LLM success, ``"fallback"``
        when synthesis was unavailable, ``"empty"`` when no goals were
        provided).
    """
    now = datetime.now(timezone.utc).isoformat()
    source_commit: str | None = None
    source_repo: str | None = None
    if source_repo_path is not None and source_repo_path.exists():
        source_commit = _git_head(source_repo_path)
        source_repo = source_repo_path.name

    if not goals:
        empty = _fallback_synthesis([])
        empty.update(
            {
                "pillars": [],
                "source_commit": source_commit,
                "source_repo": source_repo,
                "derived_at": now,
                "llm_model": None,
                "llm_cost_usd": 0.0,
                "raw_synthesis": "",
                "provenance": "empty",
            }
        )
        return empty

    # Build the user prompt. Truncate deterministically.
    chunks: list[str] = []
    used = 0
    for goal in goals:
        entry = f"FILE: {goal['file']}\nSECTION: {goal['section']}\n{goal['text']}\n\n"
        if used + len(entry) > _MAX_SYNTHESIS_CHARS:
            break
        chunks.append(entry)
        used += len(entry)
    user_prompt = (
        "The following excerpts come from authoritative Zenon Network "
        "specifications. Distil them into the mission JSON format "
        "described in the system prompt.\n\n" + "".join(chunks)
    )

    # Resolve the LLM call. Keep the real import lazy so tests never
    # pay the cost of the provider module unless they opt in.
    caller = llm_call
    if caller is None:
        from core.llm_provider import call_llm

        caller = call_llm

    raw_text = ""
    llm_cost = 0.0
    llm_model: str | None = None
    try:
        llm_result = caller(
            prompt=user_prompt,
            system=_SYNTHESIS_SYSTEM_PROMPT,
            model="auto",
            max_tokens=4000,
            json_output=True,
        )
    except TypeError:
        # Test doubles may not accept every keyword arg; retry with
        # the minimum required surface.
        try:
            llm_result = caller(user_prompt, _SYNTHESIS_SYSTEM_PROMPT)
        except Exception as exc:
            logger.warning("synthesize_mission LLM fallback failed: %s", exc)
            llm_result = None
    except Exception as exc:
        logger.warning("synthesize_mission LLM call failed: %s", exc)
        llm_result = None

    if isinstance(llm_result, dict):
        raw_text = str(llm_result.get("text", ""))
        llm_cost = float(llm_result.get("cost_usd", 0.0) or 0.0)
        llm_model = llm_result.get("model")
    elif isinstance(llm_result, str):
        raw_text = llm_result
    elif llm_result is None:
        raw_text = ""
    else:
        raw_text = str(llm_result)

    parsed = _parse_synthesis(raw_text)
    if parsed is None:
        mission = _fallback_synthesis(goals)
        provenance = "fallback"
    else:
        mission = parsed
        provenance = "synthesized"

    mission.setdefault("pillars", [])
    mission.update(
        {
            "source_commit": source_commit,
            "source_repo": source_repo,
            "derived_at": now,
            "llm_model": llm_model,
            "llm_cost_usd": llm_cost,
            "raw_synthesis": raw_text,
            "provenance": provenance,
        }
    )
    return mission


def _parse_synthesis(raw_text: str) -> dict[str, Any] | None:
    """Best-effort JSON parse of synthesis output.

    Returns ``None`` when the text does not contain a valid JSON
    object with a ``pillars`` list. Also enforces the 3-to-7 pillar
    contract: if the LLM returns fewer than 3 or more than 7, we
    treat the synthesis as invalid and let the caller fall back.
    """
    if not raw_text:
        return None
    start = raw_text.find("{")
    end = raw_text.rfind("}") + 1
    if start < 0 or end <= start:
        return None
    try:
        parsed = json.loads(raw_text[start:end])
    except json.JSONDecodeError:
        return None
    if not isinstance(parsed, dict):
        return None
    pillars = parsed.get("pillars")
    if not isinstance(pillars, list):
        return None
    if not (3 <= len(pillars) <= 7):
        return None
    # Normalise pillar shape so downstream code can rely on keys.
    clean: list[dict[str, Any]] = []
    for pillar in pillars:
        if not isinstance(pillar, dict):
            continue
        name = str(pillar.get("name", "")).strip()
        if not name:
            continue
        clean.append(
            {
                "name": name,
                "description": str(pillar.get("description", "")).strip(),
                "priority": int(pillar.get("priority", 5) or 5),
                "evidence_files": [str(f) for f in (pillar.get("evidence_files") or []) if f],
            }
        )
    if len(clean) < 3:
        return None
    parsed["pillars"] = clean
    parsed.setdefault("name", "Spec-derived mission")
    parsed.setdefault("one_liner", "")
    return parsed


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------


def persist_derived_mission(mission: dict[str, Any], db_path: str) -> int:
    """Insert a synthesised mission into the ``derived_mission`` table.

    Uses :func:`core.persistence.metrics.persist_metric` so the call
    goes through the sanctioned write path (schema bootstrap,
    connection tuning, error handling). Never raises.

    Args:
        mission: Dict produced by :func:`synthesize_mission`.
        db_path: Target SQLite database.

    Returns:
        Row ID of the inserted mission, or ``-1`` when the insert
        failed (logged at warning level by ``persist_metric``).
    """
    data = {
        "name": str(mission.get("name", "Spec-derived mission")),
        "pillars_json": json.dumps(mission.get("pillars", [])),
        "source_commit": mission.get("source_commit"),
        "source_repo": mission.get("source_repo"),
        "derived_at": mission.get("derived_at") or datetime.now(timezone.utc).isoformat(),
        "llm_model": mission.get("llm_model"),
        "llm_cost_usd": float(mission.get("llm_cost_usd", 0.0) or 0.0),
        "raw_synthesis": str(mission.get("raw_synthesis", "")),
    }
    return persist_metric(db_path=db_path, table="derived_mission", data=data)


def load_current_mission(db_path: str) -> dict[str, Any] | None:
    """Return the most recently derived mission, or ``None`` if there is none.

    The query orders by ``id DESC`` so the latest insert wins even
    when two rows share the same ``derived_at`` timestamp. Returns
    the mission as a dict with the same shape as
    :func:`synthesize_mission` output, plus ``provenance='stored'``
    and a deserialised ``pillars`` list.
    """
    rows = query_table(
        db_path=db_path,
        table="derived_mission",
        order_by="id DESC",
        limit=1,
    )
    if not rows:
        return None
    row = rows[0]
    try:
        pillars = json.loads(row.get("pillars_json") or "[]")
    except json.JSONDecodeError:
        pillars = []
    return {
        "name": row.get("name", ""),
        "pillars": pillars,
        "source_commit": row.get("source_commit"),
        "source_repo": row.get("source_repo"),
        "derived_at": row.get("derived_at", ""),
        "llm_model": row.get("llm_model"),
        "llm_cost_usd": float(row.get("llm_cost_usd") or 0.0),
        "raw_synthesis": row.get("raw_synthesis", ""),
        "provenance": "stored",
    }


# ---------------------------------------------------------------------------
# Refresh loop
# ---------------------------------------------------------------------------


def _parse_iso(ts: str) -> datetime | None:
    """Parse an ISO 8601 string, returning ``None`` on failure."""
    if not ts:
        return None
    try:
        parsed = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def refresh_if_stale(
    db_path: str,
    *,
    max_age_days: int = 30,
    llm_call: Callable[..., Any] | None = None,
) -> bool:
    """Re-derive the mission when the stored copy is stale.

    The stored mission is considered stale when any of the following
    is true:

    - No mission has ever been derived (the table is empty).
    - The stored ``derived_at`` timestamp is older than
      ``max_age_days``.
    - The stored ``source_commit`` no longer matches the current HEAD
      of the owning spec repo (the corpus moved under our feet).

    When stale, the function runs the full
    discover → extract → synthesise → persist flow. When not stale,
    it is a no-op.

    Args:
        db_path: Target database.
        max_age_days: Freshness horizon in days.
        llm_call: Optional injected LLM callable (test hook).

    Returns:
        ``True`` when a refresh happened, ``False`` otherwise.
    """
    current = load_current_mission(db_path)
    now = datetime.now(timezone.utc)

    # Decide whether we need to refresh.
    needs_refresh = current is None
    current_head: str | None = None
    spec_dirs: list[Path] = []
    owning_repo: Path | None = None

    if not needs_refresh and current is not None:
        derived_at = _parse_iso(current.get("derived_at", ""))
        if derived_at is None or now - derived_at > timedelta(days=max_age_days):
            needs_refresh = True

    # Always discover directories so we can compare commits even when
    # the age check hasn't tripped yet.
    spec_dirs = find_spec_directories()
    if spec_dirs:
        owning_repo = _owning_repo_for(spec_dirs[0])
        current_head = _git_head(owning_repo) if owning_repo else None

    if (
        not needs_refresh
        and current is not None
        and current_head
        and current.get("source_commit")
        and current_head != current.get("source_commit")
    ):
        needs_refresh = True

    if not needs_refresh:
        return False

    if not spec_dirs:
        # Nothing to derive from. Do not overwrite an existing stored
        # mission with an empty one — that would be strictly worse
        # than the stale version. Just log and bail.
        logger.info(
            "refresh_if_stale: no spec directories found; "
            "leaving existing derived_mission (if any) in place."
        )
        return False

    goals: list[dict[str, str]] = []
    for spec_dir in spec_dirs:
        goals.extend(extract_spec_goals(spec_dir))

    if not goals:
        logger.info(
            "refresh_if_stale: spec directories present but no goal-"
            "bearing sections found; skipping derivation."
        )
        return False

    mission = synthesize_mission(
        goals,
        llm_call=llm_call,
        source_repo_path=owning_repo,
    )
    persist_derived_mission(mission, db_path)
    logger.info(
        "refresh_if_stale: re-derived mission name=%s pillars=%d provenance=%s",
        mission.get("name"),
        len(mission.get("pillars", [])),
        mission.get("provenance"),
    )
    return True


def _owning_repo_for(spec_dir: Path) -> Path | None:
    """Return the nearest ancestor directory of ``spec_dir`` with a ``.git``.

    Walks upward from ``spec_dir`` until it finds ``.git`` or hits
    the workspace root. Returns ``None`` when neither is found.
    """
    root = workspace_root()
    current: Path | None = spec_dir
    while current is not None:
        if (current / ".git").exists():
            return current
        if root is not None and current == root:
            return None
        if current.parent == current:
            return None
        current = current.parent
    return None


__all__ = [
    "SCHEMA_SQL",
    "extract_spec_goals",
    "find_spec_directories",
    "load_current_mission",
    "persist_derived_mission",
    "refresh_if_stale",
    "synthesize_mission",
]
