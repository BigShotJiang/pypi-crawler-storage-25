# SPDX-License-Identifier: MIT
"""
Mission - Nebula's north star.

Nebula is not a generic monitoring tool. Every engine, every finding,
every War Room battle plan exists to advance a single mission: make
Zenon the next big L1 by making ZNN / wZNN / QSR / wQSR appreciate
through technical excellence, ecosystem expansion, and narrative
dominance.

This module encodes that mission as data so the Director, the
Breakthrough engine, the Aspiration engine, and the War Room can all
align their outputs against it. When a new engine is added, it should
be tagged with one or more mission pillars so ``mission_alignment()``
can grade its work.

The mission is deliberately written as values a deterministic scorer
can use. There is no LLM in this file.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

# ---------------------------------------------------------------------------
# Mission statement
# ---------------------------------------------------------------------------

MISSION_ONE_LINER = (
    "Make Zenon the next big L1 and make ZNN, wZNN, QSR, and wQSR "
    "appreciate through technical excellence, ecosystem expansion, "
    "and narrative dominance."
)

MISSION_LONG = (
    "Nebula exists to compound Zenon's advantage across five fronts:\n"
    "  1. Technical excellence  - ship specs, fix bugs before they're\n"
    "     exploited, and contribute back to TminusZ/developer-commons.\n"
    "  2. Ecosystem expansion   - fill product gaps (DEX, lending,\n"
    "     wallets, bridges) and grow the contributor base.\n"
    "  3. Narrative dominance   - surface Bitcoin-SPV, anon-founder,\n"
    "     feeless PoW/PoS, and research-commons stories that resonate.\n"
    "  4. Security hardening    - find vulnerabilities before exploits,\n"
    "     protect the bridge, monitor dependency CVEs.\n"
    "  5. Adoption growth       - grow delegators, stakers, and new\n"
    "     pillar operators while keeping decentralization high.\n"
)


# ---------------------------------------------------------------------------
# Pillars and targets
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MissionPillar:
    """One strategic pillar Nebula is graded against.

    Attributes:
        key: Short identifier used in mission-alignment scoring.
        title: Human-readable title.
        description: One-sentence summary.
        weight: Relative importance (0..1). All pillar weights should
            sum to 1.0. Used when composing an overall mission score.
        target_audiences: Which participant archetypes care about this.
        relevant_domains: Names of domain plugins whose output tends to
            contribute to this pillar. Used by the Director to route
            evidence to the right scorer.
        signal_keywords: Lowercase keywords that, when found in an
            evidence finding, bump its alignment score for this pillar.
    """

    key: str
    title: str
    description: str
    weight: float
    target_audiences: tuple[str, ...]
    relevant_domains: tuple[str, ...]
    signal_keywords: tuple[str, ...]


PILLARS: tuple[MissionPillar, ...] = (
    MissionPillar(
        key="technical_excellence",
        title="Technical excellence",
        description=(
            "Ship specs, harden contracts, fix bugs before exploits, "
            "and contribute back to TminusZ."
        ),
        weight=0.28,
        target_audiences=("developers", "pillar_operators"),
        relevant_domains=(
            "development",
            "quality",
            "devops",
            "contribution",
            "standards",
        ),
        signal_keywords=(
            "spec",
            "abi",
            "contract",
            "vm",
            "test",
            "fuzz",
            "bug",
            "regression",
            "audit",
            "verification",
            "verified",
            "embedded",
            "ptlc",
            "portal",
        ),
    ),
    MissionPillar(
        key="ecosystem_expansion",
        title="Ecosystem expansion",
        description=(
            "Grow the product surface: DEX, lending, wallets, bridges, "
            "and the contributor pool around them."
        ),
        weight=0.20,
        target_audiences=("developers", "community", "builders"),
        relevant_domains=(
            "product_market_fit",
            "community",
            "interoperability",
            "education",
        ),
        signal_keywords=(
            "dex",
            "lending",
            "wallet",
            "bridge",
            "contributor",
            "tvl",
            "dapp",
            "integration",
            "sdk",
            "onboarding",
            "docs",
            "gap",
            "fork",
            "competitor",
        ),
    ),
    MissionPillar(
        key="narrative_dominance",
        title="Narrative dominance",
        description=(
            "Make Zenon unavoidable in the stories that matter: "
            "trustless BTC bridging, anon-first builders, feeless "
            "plasma, dual-coin economics."
        ),
        weight=0.20,
        target_audiences=("community", "delegators", "investors"),
        relevant_domains=(
            "marketing",
            "investigation",
            "intelligence",
        ),
        signal_keywords=(
            "narrative",
            "story",
            "cypherpunk",
            "bitcoin",
            "anon",
            "ordinal",
            "covenant",
            "lightning",
            "positioning",
            "brand",
            "thesis",
            "momentum",
            "reddit",
            "twitter",
            "x.com",
        ),
    ),
    MissionPillar(
        key="security_hardening",
        title="Security hardening",
        description=(
            "Find vulnerabilities before attackers do. Protect the "
            "bridge, fund-safe contracts, and dependency supply chain."
        ),
        weight=0.20,
        target_audiences=("security_researchers", "pillar_operators"),
        relevant_domains=(
            "security",
            "quality",
            "interoperability",
            "network_health",
        ),
        signal_keywords=(
            "vuln",
            "cve",
            "exploit",
            "attack",
            "bridge",
            "tss",
            "reentrancy",
            "overflow",
            "adversarial",
            "hostile",
            "severity",
            "cvss",
            "security",
            "fund-safety",
        ),
    ),
    MissionPillar(
        key="adoption_growth",
        title="Adoption growth",
        description=(
            "Grow delegators, stakers, and pillar operators while "
            "keeping the network genuinely decentralized."
        ),
        weight=0.12,
        target_audiences=("delegators", "stakers", "pillar_operators"),
        relevant_domains=(
            "economics",
            "network_health",
            "governance",
            "community",
        ),
        signal_keywords=(
            "delegation",
            "staking",
            "pillar",
            "sentinel",
            "apr",
            "yield",
            "nakamoto",
            "decentralization",
            "treasury",
            "proposal",
            "vote",
            "participation",
        ),
    ),
)


# ---------------------------------------------------------------------------
# Alignment scoring
# ---------------------------------------------------------------------------


def pillar_by_key(key: str) -> MissionPillar | None:
    """Return the :class:`MissionPillar` with the given ``key``.

    Args:
        key: Pillar key as declared in :data:`PILLARS`.

    Returns:
        The matching pillar, or ``None`` when no pillar matches.
    """
    for pillar in PILLARS:
        if pillar.key == key:
            return pillar
    return None


def _tokenize(text: str) -> set[str]:
    """Return a lowercase set of alphanumeric tokens in ``text``."""
    buf: list[str] = []
    current: list[str] = []
    for ch in text.lower():
        if ch.isalnum() or ch == "_":
            current.append(ch)
            continue
        if current:
            buf.append("".join(current))
            current = []
    if current:
        buf.append("".join(current))
    return set(buf)


def mission_alignment(
    *,
    domain: str = "",
    evidence_text: str = "",
    explicit_pillars: Iterable[str] = (),
) -> dict[str, float]:
    """Grade a finding against every mission pillar.

    The algorithm is deterministic and cheap: it combines three signals
    per pillar:
        * ``domain_boost``  - +0.4 if ``domain`` is listed in
          ``pillar.relevant_domains``.
        * ``keyword_boost`` - up to +0.4 based on keyword hits in
          ``evidence_text``.
        * ``explicit_boost`` - +0.3 when the caller explicitly tags the
          finding with a pillar key.

    The returned ``overall`` field is a weighted average across pillars
    using their ``weight`` attribute.

    Args:
        domain: Domain plugin that produced the evidence.
        evidence_text: The finding text (WHAT / SO WHAT / NOW WHAT).
        explicit_pillars: Pillar keys the producer wants to tag.

    Returns:
        Dict mapping pillar key to alignment score in ``[0, 1]``, plus
        an ``overall`` key with the weighted composite.
    """
    tokens = _tokenize(evidence_text)
    explicit = set(explicit_pillars)

    scores: dict[str, float] = {}
    for pillar in PILLARS:
        domain_boost = 0.4 if domain in pillar.relevant_domains else 0.0
        matches = sum(1 for kw in pillar.signal_keywords if kw in tokens)
        if pillar.signal_keywords:
            keyword_ratio = min(matches / max(len(pillar.signal_keywords) / 3, 1), 1.0)
        else:
            keyword_ratio = 0.0
        keyword_boost = 0.4 * keyword_ratio
        explicit_boost = 0.3 if pillar.key in explicit else 0.0
        score = min(domain_boost + keyword_boost + explicit_boost, 1.0)
        scores[pillar.key] = round(score, 4)

    overall = sum(scores[p.key] * p.weight for p in PILLARS) / max(
        sum(p.weight for p in PILLARS), 1e-9
    )
    scores["overall"] = round(overall, 4)
    return scores


def mission_digest() -> str:
    """Return a compact one-line mission summary for logs and status."""
    parts = [p.title for p in PILLARS]
    return f"Mission: {MISSION_ONE_LINER} Pillars: {', '.join(parts)}."


# ---------------------------------------------------------------------------
# Active mission resolution
# ---------------------------------------------------------------------------

#: Provenance tag attached to the hardcoded fallback mission. Consumers
#: can use this to tell whether they are scoring against a derived
#: mission (``"stored"`` / ``"synthesized"``) or the interim placeholder
#: that ships with the repo.
FALLBACK_PROVENANCE = "hardcoded_v0.2.0"


def _hardcoded_mission_dict() -> dict:
    """Return the hardcoded mission as the same dict shape as a derived one.

    Kept as a private helper so :func:`get_active_mission` can return
    a single normalised shape regardless of whether the data came
    from the DB or from this module.
    """
    return {
        "name": "Make Zenon the next big L1 (interim v0.2.0)",
        "one_liner": MISSION_ONE_LINER,
        "pillars": [
            {
                "name": p.key,
                "title": p.title,
                "description": p.description,
                "priority": round(p.weight * 10) or 1,
                "weight": p.weight,
                "evidence_files": [],
            }
            for p in PILLARS
        ],
        "source_commit": None,
        "source_repo": None,
        "derived_at": "",
        "llm_model": None,
        "llm_cost_usd": 0.0,
        "raw_synthesis": "",
        "provenance": FALLBACK_PROVENANCE,
    }


def get_active_mission(db_path: str | None = None) -> dict:
    """Return the mission Nebula should be scoring against right now.

    Resolution order:

    1. If ``db_path`` is provided and
       :func:`core.mission.spec_derivation.load_current_mission`
       returns a mission, return it unchanged. Its ``provenance``
       field is ``"stored"``.
    2. Otherwise return the hardcoded mission (the interim v0.2.0
       placeholder) with ``provenance=FALLBACK_PROVENANCE`` so
       callers can tell they are using the fallback.

    This helper never raises. When spec_derivation is unavailable (for
    any reason: missing module, corrupt DB, import failure) it logs
    the exception at debug level and returns the fallback.

    Args:
        db_path: Optional path to the SQLite database. ``None`` skips
            the lookup and goes straight to the fallback — useful for
            unit tests that don't want to touch the DB.

    Returns:
        A dict with the same keys as
        :func:`core.mission.spec_derivation.synthesize_mission`.
    """
    if db_path:
        try:
            from core.mission.spec_derivation import load_current_mission

            stored = load_current_mission(db_path)
        except Exception as exc:  # pragma: no cover - defensive
            import logging as _logging

            _logging.getLogger(__name__).debug(
                "get_active_mission: spec_derivation.load_current_mission failed: %s",
                exc,
            )
            stored = None
        if stored is not None and stored.get("pillars"):
            return stored
    return _hardcoded_mission_dict()
