# SPDX-License-Identifier: MIT
"""
Aspirations - canonical templates + active lifecycle management.

This module owns two things:

1. Aspiration templates (ASPIRATIONS) -- the canonical long-lived goals
   Nebula pursues, each tied to a mission pillar.

2. AspirationEngine -- the sweep/scoring/retirement loop that keeps
   those templates alive in the ``aspirations_tracked`` table.

Every domain plugin can also expose aspiration templates (things it
wants Nebula to pursue) via ``get_aspiration_types``. Those templates
were previously decorative - no code actually tracked which aspirations
were alive, which were making progress, and which had stalled.

The engine closes that loop:

    1. Collect aspirations from the ASPIRATIONS constant and from every
       domain plugin that implements ``get_aspiration_types``.
    2. Persist them into an ``aspirations`` table so progress is
       visible across runs.
    3. On every sweep, score each aspiration on three axes:
           alignment  - mission_alignment(...) of its description
           support    - count of distinct engines that produced
                        evidence_type ``aspiration_progress:<title>``
           feasibility - inverse of stall count (older + unchanged =
                        lower feasibility)
    4. Retire aspirations that have produced no progress in
       :data:`STALL_CYCLES` sweeps.

The engine is deterministic and has zero LLM cost.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from core.mission.definition import mission_alignment
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Retire an aspiration after this many sweeps with zero progress.
STALL_CYCLES = 50

# Sweep cadence hint (in cycles) - the scheduler decides when to run.
COLLECT_EVERY_N_CYCLES = 10

# Schema registry: the single source of truth for this module's table.
# ``core.schema_registry`` picks this up automatically at startup.
SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS aspirations_tracked (
    title TEXT PRIMARY KEY,
    pillar TEXT NOT NULL,
    description TEXT NOT NULL,
    success_criteria TEXT NOT NULL,
    related_domains TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    alignment REAL NOT NULL DEFAULT 0,
    support INTEGER NOT NULL DEFAULT 0,
    feasibility REAL NOT NULL DEFAULT 1,
    stall_count INTEGER NOT NULL DEFAULT 0,
    last_updated TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_aspirations_tracked_status
    ON aspirations_tracked(status);
CREATE INDEX IF NOT EXISTS idx_aspirations_tracked_pillar
    ON aspirations_tracked(pillar);
"""


# ---------------------------------------------------------------------------
# Template data model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AspirationTemplate:
    """Canonical aspiration Nebula pursues whenever conditions allow.

    Attributes:
        title: Short name used as a key in the aspirations table.
        pillar: Which mission pillar the aspiration advances.
        description: Concrete outcome the aspiration targets.
        success_criteria: Bullet-style checklist items an engine can
            verify to mark the aspiration ``achieved``.
        related_domains: Domain plugins whose work contributes directly.
    """

    title: str
    pillar: str
    description: str
    success_criteria: tuple[str, ...]
    related_domains: tuple[str, ...] = field(default_factory=tuple)


ASPIRATIONS: tuple[AspirationTemplate, ...] = (
    AspirationTemplate(
        title="ship_ptlc_full_stack",
        pillar="technical_excellence",
        description="Ship PTLC across go-zenon, SDKs, CLIs, and wallet.",
        success_criteria=(
            "go-zenon PTLC contract passes /verify deep",
            "Dart SDK fields match go-zenon JSON tags",
            "nomctl + znn_cli_dart expose PTLC commands",
            "Syrius wallet has PTLC swap tab",
        ),
        related_domains=("development", "quality", "contribution"),
    ),
    AspirationTemplate(
        title="portal_v2_bridge",
        pillar="technical_excellence",
        description="Deploy Portal V2 trustless BTC bridge on testnet.",
        success_criteria=(
            "Relayer bonding implemented",
            "Bitcoin SPV header chain verified",
            "DKG ceremony documented",
            "Testnet soak test passes",
        ),
        related_domains=(
            "development",
            "interoperability",
            "security",
        ),
    ),
    AspirationTemplate(
        title="zero_critical_cves",
        pillar="security_hardening",
        description="Keep the dependency graph free of critical CVEs.",
        success_criteria=(
            "No critical CVEs in go-zenon go.sum",
            "No critical CVEs in Syrius pubspec.lock",
            "Weekly vuln_feed scan finds 0 critical",
        ),
        related_domains=("security", "quality"),
    ),
    AspirationTemplate(
        title="grow_pillar_operators",
        pillar="adoption_growth",
        description="Increase active pillar operators by 20% QoQ.",
        success_criteria=(
            "Pillar count trend positive over 10 cycles",
            "Nakamoto coefficient >= 10",
            "New operators onboarded in last 30 days >= 3",
        ),
        related_domains=("network_health", "economics", "community"),
    ),
    AspirationTemplate(
        title="bitcoin_narrative_beachhead",
        pillar="narrative_dominance",
        description="Earn a spot in every major Bitcoin-bridge discussion.",
        success_criteria=(
            "3 Bitcoin-adjacent publications mention Zenon/PTLC",
            "Stacker News post reaches top-20",
            "Bitcoin Core dev acknowledges SPV proof of concept",
        ),
        related_domains=("marketing", "investigation", "intelligence"),
    ),
    AspirationTemplate(
        title="dex_liquidity_renaissance",
        pillar="ecosystem_expansion",
        description="Restart wZNN DEX liquidity growth.",
        success_criteria=(
            "wZNN/ETH pool TVL trend positive 4 weeks",
            "Daily volume > $250k rolling 7d",
            "At least 2 new LPs onboarded",
        ),
        related_domains=("economics", "product_market_fit"),
    ),
)


def aspirations_for_pillar(pillar_key: str) -> tuple[AspirationTemplate, ...]:
    """Return aspiration templates tied to a particular pillar."""
    return tuple(a for a in ASPIRATIONS if a.pillar == pillar_key)


# ---------------------------------------------------------------------------
# Live row model
# ---------------------------------------------------------------------------


@dataclass
class AspirationRow:
    """A live row from the ``aspirations`` table."""

    title: str
    pillar: str
    description: str
    success_criteria: tuple[str, ...]
    related_domains: tuple[str, ...]
    status: str  # "active" | "progressing" | "stalled" | "retired" | "achieved"
    alignment: float
    support: int
    feasibility: float
    stall_count: int
    last_updated: str

    @property
    def score(self) -> float:
        """Composite priority score used for sorting."""
        return round(
            0.5 * self.alignment + 0.3 * min(self.support / 5.0, 1.0) + 0.2 * self.feasibility,
            4,
        )


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------


def ensure_aspirations_schema(db_path: str = DEFAULT_DB) -> None:
    """Create the ``aspirations`` table if it does not exist."""
    conn = connect(db_path)
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS aspirations_tracked (
                title TEXT PRIMARY KEY,
                pillar TEXT NOT NULL,
                description TEXT NOT NULL,
                success_criteria TEXT NOT NULL,
                related_domains TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'active',
                alignment REAL NOT NULL DEFAULT 0,
                support INTEGER NOT NULL DEFAULT 0,
                feasibility REAL NOT NULL DEFAULT 1,
                stall_count INTEGER NOT NULL DEFAULT 0,
                last_updated TEXT NOT NULL
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_aspirations_tracked_status "
            "ON aspirations_tracked(status)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_aspirations_tracked_pillar "
            "ON aspirations_tracked(pillar)"
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Collection
# ---------------------------------------------------------------------------


def _discover_domain_aspirations() -> list[AspirationTemplate]:
    """Walk registered domains and pull their aspiration templates.

    Every domain may expose a ``get_aspiration_types()`` classmethod or
    module-level function. Each entry may be a string (used as title
    only) or a full :class:`AspirationTemplate`. Non-conforming entries
    are ignored so a broken plugin can't take the sweep down.
    """
    try:
        from core.domain_registry import DomainRegistry
    except Exception as exc:
        logger.debug("DomainRegistry unavailable: %s", exc)
        return []

    out: list[AspirationTemplate] = []
    try:
        registry = DomainRegistry()
        registry.discover()
    except Exception as exc:
        logger.debug("Domain discovery failed: %s", exc)
        return out

    for plugin in getattr(registry, "domains", {}).values():
        getter = getattr(plugin, "get_aspiration_types", None)
        if not callable(getter):
            continue
        try:
            raw = getter() or []
        except Exception as exc:
            logger.debug("Domain %s aspiration getter failed: %s", plugin, exc)
            continue
        for entry in raw:
            if isinstance(entry, AspirationTemplate):
                out.append(entry)
                continue
            if not isinstance(entry, str):
                continue
            out.append(
                AspirationTemplate(
                    title=entry,
                    pillar="technical_excellence",
                    description=f"Domain-defined aspiration: {entry}",
                    success_criteria=(),
                    related_domains=(getattr(plugin, "name", ""),),
                )
            )
    return out


def collect_aspirations() -> list[AspirationTemplate]:
    """Return the union of mission-level and domain-level aspirations."""
    seen: dict[str, AspirationTemplate] = {}
    for template in ASPIRATIONS:
        seen[template.title] = template
    for template in _discover_domain_aspirations():
        seen.setdefault(template.title, template)
    return list(seen.values())


# ---------------------------------------------------------------------------
# Persistence + scoring
# ---------------------------------------------------------------------------


def _now() -> str:
    """Return the current UTC timestamp as ISO 8601."""
    return datetime.now(timezone.utc).isoformat()


def _row_to_aspiration(row: sqlite3.Row) -> AspirationRow:
    """Convert a DB row back into an :class:`AspirationRow`."""
    try:
        criteria = tuple(json.loads(row["success_criteria"] or "[]"))
    except (TypeError, json.JSONDecodeError):
        criteria = ()
    try:
        domains = tuple(json.loads(row["related_domains"] or "[]"))
    except (TypeError, json.JSONDecodeError):
        domains = ()
    return AspirationRow(
        title=row["title"],
        pillar=row["pillar"],
        description=row["description"],
        success_criteria=criteria,
        related_domains=domains,
        status=row["status"],
        alignment=float(row["alignment"] or 0.0),
        support=int(row["support"] or 0),
        feasibility=float(row["feasibility"] or 0.0),
        stall_count=int(row["stall_count"] or 0),
        last_updated=row["last_updated"] or "",
    )


def _count_support(conn: sqlite3.Connection, title: str) -> int:
    """Return the number of distinct engines backing an aspiration.

    Engines signal progress by persisting evidence with
    ``evidence_type = 'aspiration_progress:<title>'``.
    """
    try:
        row = conn.execute(
            """SELECT COUNT(DISTINCT engine) FROM evidence
               WHERE evidence_type = ?""",
            (f"aspiration_progress:{title}",),
        ).fetchone()
    except sqlite3.OperationalError:
        return 0
    return int(row[0] if row else 0)


def sweep(
    *,
    db_path: str = DEFAULT_DB,
) -> list[AspirationRow]:
    """Refresh every aspiration's status/score and retire stale ones.

    Returns the list of post-sweep aspirations sorted by score (desc).
    Idempotent - safe to call every cycle or every N cycles.
    """
    ensure_aspirations_schema(db_path)
    templates = collect_aspirations()
    now = _now()

    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        # Upsert templates
        for template in templates:
            alignment = mission_alignment(
                domain=(template.related_domains or ("",))[0],
                evidence_text=template.description,
                explicit_pillars=(template.pillar,),
            )["overall"]
            conn.execute(
                """INSERT INTO aspirations_tracked (
                       title, pillar, description, success_criteria,
                       related_domains, status, alignment, support,
                       feasibility, stall_count, last_updated
                   ) VALUES (?, ?, ?, ?, ?, 'active', ?, 0, 1.0, 0, ?)
                   ON CONFLICT(title) DO UPDATE SET
                       pillar = excluded.pillar,
                       description = excluded.description,
                       success_criteria = excluded.success_criteria,
                       related_domains = excluded.related_domains,
                       alignment = excluded.alignment,
                       last_updated = excluded.last_updated
                """,
                (
                    template.title,
                    template.pillar,
                    template.description,
                    json.dumps(list(template.success_criteria)),
                    json.dumps(list(template.related_domains)),
                    alignment,
                    now,
                ),
            )

        # Recalculate support / feasibility / status / stall.
        rows = conn.execute(
            "SELECT * FROM aspirations_tracked WHERE status != 'retired'"
        ).fetchall()
        updated: list[AspirationRow] = []
        for row in rows:
            title = row["title"]
            previous_support = int(row["support"] or 0)
            support = _count_support(conn, title)
            if support > previous_support:
                new_stall = 0
                new_status = "progressing"
            else:
                new_stall = int(row["stall_count"] or 0) + 1
                new_status = row["status"] if new_stall < STALL_CYCLES else "retired"
                if new_status == "active" and new_stall > 0:
                    new_status = "stalled"
            feasibility = max(0.0, 1.0 - new_stall / STALL_CYCLES)
            conn.execute(
                """UPDATE aspirations_tracked SET
                       support = ?,
                       feasibility = ?,
                       stall_count = ?,
                       status = ?,
                       last_updated = ?
                   WHERE title = ?""",
                (support, feasibility, new_stall, new_status, now, title),
            )
            refreshed = conn.execute(
                "SELECT * FROM aspirations_tracked WHERE title = ?", (title,)
            ).fetchone()
            if refreshed:
                updated.append(_row_to_aspiration(refreshed))
        conn.commit()
    finally:
        conn.close()

    updated.sort(key=lambda a: a.score, reverse=True)
    return updated


# ---------------------------------------------------------------------------
# Query helpers
# ---------------------------------------------------------------------------


def list_aspirations(
    *,
    db_path: str = DEFAULT_DB,
    statuses: Iterable[str] = ("active", "progressing", "stalled"),
) -> list[AspirationRow]:
    """Return aspirations filtered by ``statuses``.

    Sorted by composite score descending. Returns an empty list when
    the table does not yet exist.
    """
    ensure_aspirations_schema(db_path)
    placeholders = ",".join("?" for _ in statuses)
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        if placeholders:
            rows = conn.execute(
                f"SELECT * FROM aspirations_tracked WHERE status IN ({placeholders})",
                tuple(statuses),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM aspirations_tracked").fetchall()
    finally:
        conn.close()
    out = [_row_to_aspiration(r) for r in rows]
    out.sort(key=lambda a: a.score, reverse=True)
    return out


def mark_achieved(
    title: str,
    *,
    db_path: str = DEFAULT_DB,
) -> bool:
    """Mark an aspiration as ``achieved``.

    Returns ``True`` when a row was updated. Engines that can verify
    success criteria (e.g. ``contribution/auto_contributor``) should
    call this to close out aspirations cleanly.
    """
    ensure_aspirations_schema(db_path)
    conn = connect(db_path)
    try:
        cursor = conn.execute(
            """UPDATE aspirations_tracked
               SET status = 'achieved', last_updated = ?
               WHERE title = ?""",
            (_now(), title),
        )
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()


def summary(
    *,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Return a compact dict with counts per status and top-3 titles."""
    ensure_aspirations_schema(db_path)
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            "SELECT status, COUNT(*) AS n FROM aspirations_tracked GROUP BY status"
        ).fetchall()
        counts = {row["status"]: int(row["n"]) for row in rows}
        top = conn.execute(
            """SELECT title, pillar, alignment, support, feasibility
               FROM aspirations_tracked
               WHERE status IN ('active', 'progressing', 'stalled')
               ORDER BY alignment DESC, support DESC
               LIMIT 3"""
        ).fetchall()
    finally:
        conn.close()
    return {
        "counts": counts,
        "top": [
            {
                "title": row["title"],
                "pillar": row["pillar"],
                "alignment": float(row["alignment"] or 0.0),
                "support": int(row["support"] or 0),
                "feasibility": float(row["feasibility"] or 0.0),
            }
            for row in top
        ],
    }


__all__ = [
    "ASPIRATIONS",
    "COLLECT_EVERY_N_CYCLES",
    "STALL_CYCLES",
    "AspirationRow",
    "AspirationTemplate",
    "aspirations_for_pillar",
    "collect_aspirations",
    "ensure_aspirations_schema",
    "list_aspirations",
    "mark_achieved",
    "summary",
    "sweep",
]
