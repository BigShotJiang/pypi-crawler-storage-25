# SPDX-License-Identifier: MIT
"""Mission package -- north-star definition and aspiration lifecycle.

Combines ``core.mission.definition`` (mission statement, pillars,
alignment scoring) and ``core.mission.aspirations`` (canonical
aspiration templates + the engine that tracks their progress) into
one conceptual unit. All legacy imports from ``core.mission`` keep
working unchanged.
"""

from core.mission.aspirations import (
    ASPIRATIONS,
    COLLECT_EVERY_N_CYCLES,
    STALL_CYCLES,
    AspirationRow,
    AspirationTemplate,
    aspirations_for_pillar,
    collect_aspirations,
    ensure_aspirations_schema,
    list_aspirations,
    mark_achieved,
    summary,
    sweep,
)
from core.mission.definition import (
    FALLBACK_PROVENANCE,
    MISSION_LONG,
    MISSION_ONE_LINER,
    PILLARS,
    MissionPillar,
    _tokenize,
    get_active_mission,
    mission_alignment,
    mission_digest,
    pillar_by_key,
)
from core.mission.spec_derivation import (
    extract_spec_goals,
    find_spec_directories,
    load_current_mission,
    persist_derived_mission,
    refresh_if_stale,
    synthesize_mission,
)

__all__ = [
    # Aspirations
    "ASPIRATIONS",
    "COLLECT_EVERY_N_CYCLES",
    "FALLBACK_PROVENANCE",
    # Definition
    "MISSION_LONG",
    "MISSION_ONE_LINER",
    "PILLARS",
    "STALL_CYCLES",
    "AspirationRow",
    "AspirationTemplate",
    "MissionPillar",
    "aspirations_for_pillar",
    "collect_aspirations",
    "ensure_aspirations_schema",
    "extract_spec_goals",
    "find_spec_directories",
    "get_active_mission",
    "list_aspirations",
    "load_current_mission",
    "mark_achieved",
    "mission_alignment",
    "mission_digest",
    "persist_derived_mission",
    "pillar_by_key",
    "refresh_if_stale",
    "summary",
    "sweep",
    "synthesize_mission",
]
