# SPDX-License-Identifier: MIT
"""
Nebula Ask — Natural language questions answered from evidence.

Ask Nebula anything and get answers grounded in real data from the
evidence database, spec coverage, battle plans, and hypotheses.

Usage:
    nebula ask "what tminusz specs should we code next?"
    nebula ask "what are the biggest security risks right now?"
    nebula ask "which pillars are underperforming?"
    nebula ask "is the bridge safe?"

Architecture:
    Question → gather relevant context from DB → send to LLM → answer
    The LLM never invents data — it reasons over what Nebula actually found.
"""

import logging
import sqlite3
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Keywords that map questions to specific DB queries
TOPIC_KEYWORDS = {
    "spec": ["spec", "tminusz", "implement", "coverage", "code next", "build next"],
    "security": [
        "security",
        "vulnerability",
        "vuln",
        "exploit",
        "attack",
        "bridge safe",
        "cve",
        "risk",
    ],
    "governance": ["governance", "proposal", "vote", "pillar", "az", "treasury", "accelerator"],
    "economics": ["staking", "delegation", "yield", "liquidity", "price", "whale", "supply"],
    "development": ["upstream", "commit", "pr", "pull request", "breaking change", "drift"],
    "network": ["bridge", "node", "sentinel", "decentralization", "health", "uptime"],
    "hypothesis": ["hypothesis", "theory", "confidence", "believe", "think"],
    "plan": ["plan", "priority", "focus", "next", "should we", "what to do"],
}


def _detect_topics(question: str) -> list[str]:
    """Detect which topics a question is about."""
    q = question.lower()
    topics = []
    for topic, keywords in TOPIC_KEYWORDS.items():
        if any(kw in q for kw in keywords):
            topics.append(topic)
    if not topics:
        topics = ["plan"]  # default: strategic question
    return topics


def _gather_context(question: str, db_path: str = DEFAULT_DB) -> str:
    """Gather relevant evidence from DB based on the question."""
    topics = _detect_topics(question)
    parts = []

    conn = connect(db_path)
    conn.row_factory = sqlite3.Row

    try:
        # Always include: basic stats
        evidence_count = conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
        hypothesis_count = conn.execute("SELECT COUNT(*) FROM hypotheses").fetchone()[0]
        parts.append(f"Nebula has {evidence_count} findings and {hypothesis_count} hypotheses.")

        # Topic-specific context
        if "spec" in topics:
            try:
                rows = conn.execute(
                    "SELECT spec_name, overall_coverage, go_status, sdk_dart_status "
                    "FROM spec_coverage ORDER BY overall_coverage ASC LIMIT 10"
                ).fetchall()
                if rows:
                    specs = "\n".join(
                        f"  {r['spec_name']}: {r['overall_coverage']}% coverage "
                        f"(Go: {r['go_status']}, Dart: {r['sdk_dart_status']})"
                        for r in rows
                    )
                    parts.append(f"SPEC COVERAGE (lowest first):\n{specs}")
            except Exception as exc:
                logger.debug("ask context gather failed: %s", exc)

            # Recent spec-related findings
            try:
                rows = conn.execute(
                    "SELECT finding FROM evidence WHERE domain = 'development' "
                    "ORDER BY timestamp DESC LIMIT 5"
                ).fetchall()
                if rows:
                    findings = "\n".join(f"  - {r['finding'][:150]}" for r in rows)
                    parts.append(f"RECENT DEVELOPMENT FINDINGS:\n{findings}")
            except Exception as exc:
                logger.debug("ask context gather failed: %s", exc)

        if "security" in topics:
            try:
                rows = conn.execute(
                    "SELECT finding, confidence FROM evidence "
                    "WHERE domain = 'security' AND COALESCE(status, 'open') = 'open' "
                    "ORDER BY confidence DESC LIMIT 10"
                ).fetchall()
                if rows:
                    findings = "\n".join(
                        f"  [{r['confidence']:.0%}] {r['finding'][:150]}" for r in rows
                    )
                    parts.append(f"OPEN SECURITY FINDINGS:\n{findings}")
            except Exception as exc:
                logger.debug("ask context gather failed: %s", exc)

        if "governance" in topics:
            try:
                rows = conn.execute(
                    "SELECT finding FROM evidence WHERE domain = 'governance' "
                    "ORDER BY timestamp DESC LIMIT 5"
                ).fetchall()
                if rows:
                    findings = "\n".join(f"  - {r['finding'][:150]}" for r in rows)
                    parts.append(f"GOVERNANCE FINDINGS:\n{findings}")
            except Exception as exc:
                logger.debug("ask context gather failed: %s", exc)

        if "economics" in topics:
            try:
                rows = conn.execute(
                    "SELECT finding FROM evidence WHERE domain = 'economics' "
                    "ORDER BY timestamp DESC LIMIT 5"
                ).fetchall()
                if rows:
                    findings = "\n".join(f"  - {r['finding'][:150]}" for r in rows)
                    parts.append(f"ECONOMICS FINDINGS:\n{findings}")
            except Exception as exc:
                logger.debug("ask context gather failed: %s", exc)

        if "development" in topics:
            try:
                rows = conn.execute(
                    "SELECT finding FROM evidence WHERE domain = 'intelligence' "
                    "ORDER BY timestamp DESC LIMIT 10"
                ).fetchall()
                if rows:
                    findings = "\n".join(f"  - {r['finding'][:150]}" for r in rows)
                    parts.append(f"UPSTREAM INTELLIGENCE:\n{findings}")
            except Exception as exc:
                logger.debug("ask context gather failed: %s", exc)

        if "network" in topics:
            try:
                rows = conn.execute(
                    "SELECT finding FROM evidence WHERE domain = 'network_health' "
                    "ORDER BY timestamp DESC LIMIT 5"
                ).fetchall()
                if rows:
                    findings = "\n".join(f"  - {r['finding'][:150]}" for r in rows)
                    parts.append(f"NETWORK HEALTH:\n{findings}")
            except Exception as exc:
                logger.debug("ask context gather failed: %s", exc)

        if "hypothesis" in topics:
            try:
                rows = conn.execute(
                    "SELECT id, title, confidence, status FROM hypotheses ORDER BY confidence DESC"
                ).fetchall()
                if rows:
                    hyps = "\n".join(
                        f"  {r['id']} [{r['confidence']:.0%}] {r['title']}" for r in rows
                    )
                    parts.append(f"HYPOTHESES:\n{hyps}")
            except Exception as exc:
                logger.debug("ask context gather failed: %s", exc)

        if "plan" in topics:
            try:
                row = conn.execute(
                    "SELECT situation_assessment, battle_plan_24h "
                    "FROM battle_plans ORDER BY timestamp DESC LIMIT 1"
                ).fetchone()
                if row:
                    parts.append(f"LATEST BATTLE PLAN:\n  {row['situation_assessment'][:300]}")
                    parts.append(f"  Focus: {row['battle_plan_24h'][:300]}")
            except Exception as exc:
                logger.debug("ask context gather failed: %s", exc)

        # Always include: domain evidence distribution
        try:
            rows = conn.execute(
                "SELECT domain, COUNT(*) as cnt FROM evidence GROUP BY domain ORDER BY cnt DESC"
            ).fetchall()
            if rows:
                dist = ", ".join(f"{r['domain']}:{r['cnt']}" for r in rows)
                parts.append(f"EVIDENCE DISTRIBUTION: {dist}")
        except Exception as exc:
            logger.debug("ask context gather failed: %s", exc)

    finally:
        conn.close()

    return "\n\n".join(parts)


def ask(question: str, db_path: str = DEFAULT_DB) -> str:
    """Ask Nebula a natural language question.

    Gathers relevant context from the evidence database and sends
    the question + context to the LLM for a grounded answer.

    Args:
        question: Natural language question.
        db_path: Path to Nebula's evidence database.

    Returns:
        Answer string grounded in Nebula's data.
    """
    context = _gather_context(question, db_path)

    system = (
        "You are Nebula, an autonomous intelligence platform for the Zenon Network. "
        "You answer questions based ONLY on the evidence data provided below. "
        "Never invent data. If you don't have enough evidence to answer, say so. "
        "Be specific — reference actual findings, confidence levels, and data. "
        "Keep answers concise and actionable."
    )

    prompt = (
        f"Question: {question}\n\n"
        f"Here is what Nebula knows:\n\n{context}\n\n"
        f"Answer the question based on this evidence. Be specific and actionable."
    )

    try:
        from core.llm_provider import call_llm
        from core.model_router import get_model

        model = get_model("content_generation")  # cheap but capable
        result = call_llm(prompt=prompt, system=system, model=model, max_tokens=2000)
        if isinstance(result, dict):
            return result.get("text", "No response from LLM.")
        return str(result) if result else "No response from LLM."
    except Exception as exc:
        return f"LLM unavailable ({exc}). Raw context:\n\n{context}"
