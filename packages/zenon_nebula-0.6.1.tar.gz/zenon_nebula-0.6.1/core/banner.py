# SPDX-License-Identifier: MIT
"""Terminal banner and simple color helpers for the Nebula CLI.

No third-party dependencies — ANSI codes only, with automatic detection of
whether the output stream is a TTY. Safe to call from any context; if the
terminal doesn't support color (dumb TTY, redirected output, NO_COLOR env
var set) the helpers emit plain text.

Respects the NO_COLOR convention (https://no-color.org/) and the
FORCE_COLOR env var.
"""

from __future__ import annotations

import os
import sys

from core.version import __version__

# https://no-color.org/ — unconditional opt-out
_NO_COLOR = "NO_COLOR" in os.environ
_FORCE_COLOR = os.environ.get("FORCE_COLOR", "").lower() in {"1", "true", "yes"}


def _supports_color(stream=sys.stdout) -> bool:
    """Return True if the given stream supports ANSI color output."""
    if _NO_COLOR:
        return False
    if _FORCE_COLOR:
        return True
    if not hasattr(stream, "isatty") or not stream.isatty():
        return False
    return os.environ.get("TERM") != "dumb"


class Color:
    """Minimal ANSI palette. All values collapse to empty strings when the
    output stream does not support color."""

    def __init__(self, enabled: bool):
        codes = {
            "reset": "\033[0m",
            "bold": "\033[1m",
            "dim": "\033[2m",
            "red": "\033[31m",
            "green": "\033[32m",
            "yellow": "\033[33m",
            "blue": "\033[34m",
            "magenta": "\033[35m",
            "cyan": "\033[36m",
            "white": "\033[37m",
            "bright_black": "\033[90m",
            "bright_red": "\033[91m",
            "bright_green": "\033[92m",
            "bright_yellow": "\033[93m",
            "bright_blue": "\033[94m",
            "bright_magenta": "\033[95m",
            "bright_cyan": "\033[96m",
        }
        for name, code in codes.items():
            setattr(self, name, code if enabled else "")


def colors(stream=sys.stdout) -> Color:
    """Get a Color palette for the given stream."""
    return Color(_supports_color(stream))


BANNER = r"""
     ███╗   ██╗███████╗██████╗ ██╗   ██╗██╗      █████╗
     ████╗  ██║██╔════╝██╔══██╗██║   ██║██║     ██╔══██╗
     ██╔██╗ ██║█████╗  ██████╔╝██║   ██║██║     ███████║
     ██║╚██╗██║██╔══╝  ██╔══██╗██║   ██║██║     ██╔══██║
     ██║ ╚████║███████╗██████╔╝╚██████╔╝███████╗██║  ██║
     ╚═╝  ╚═══╝╚══════╝╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝
"""

TAGLINE = "autonomous intelligence for the Network of Momentum"


def print_banner(stream=sys.stdout, compact: bool = False) -> None:
    """Print the Nebula banner to the given stream.

    If compact=True, prints a one-line version instead of the full ASCII
    art — suitable for status headers and embedded use.
    """
    c = colors(stream)
    if compact:
        print(
            f"{c.bright_magenta}{c.bold}nebula{c.reset} {c.dim}v{__version__} — {TAGLINE}{c.reset}",
            file=stream,
        )
        return

    # Multi-color gradient across the banner lines
    gradient = [c.bright_blue, c.bright_magenta, c.bright_magenta, c.magenta, c.magenta, c.cyan]
    lines = BANNER.strip("\n").splitlines()
    for i, line in enumerate(lines):
        color = gradient[i % len(gradient)] if c.reset else ""
        print(f"{color}{line}{c.reset}", file=stream)
    print(
        f"{c.dim}         v{__version__} — {TAGLINE}{c.reset}\n",
        file=stream,
    )


def section(title: str, stream=sys.stdout) -> None:
    """Print a section header."""
    c = colors(stream)
    print(f"\n{c.bold}{c.bright_cyan}{title}{c.reset}", file=stream)
    print(f"{c.dim}{'─' * max(40, len(title))}{c.reset}", file=stream)


def kv(key: str, value, stream=sys.stdout) -> None:
    """Print a key / value pair with dim key and bold value."""
    c = colors(stream)
    print(f"  {c.dim}{key:<18}{c.reset} {c.bold}{value}{c.reset}", file=stream)


def ok(msg: str, stream=sys.stdout) -> None:
    """Print a success-marker line (green check)."""
    c = colors(stream)
    print(f"  {c.green}✓{c.reset} {msg}", file=stream)


def warn(msg: str, stream=sys.stdout) -> None:
    """Print a warning-marker line (yellow bang)."""
    c = colors(stream)
    print(f"  {c.yellow}!{c.reset} {msg}", file=stream)


def fail(msg: str, stream=sys.stderr) -> None:
    """Print a failure-marker line (red cross) to stderr."""
    c = colors(stream)
    print(f"  {c.red}✗{c.reset} {msg}", file=stream)
