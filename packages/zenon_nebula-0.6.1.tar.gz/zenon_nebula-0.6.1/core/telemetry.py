# SPDX-License-Identifier: MIT
"""
Nebula Telemetry -- opt-in crash reporting and error tracking.

Sends anonymous diagnostic data to maintainers so issues can be caught
across all running instances without requiring users to file GitHub issues.

Opt-in via NEBULA_TELEMETRY=1 in .env (default: disabled).

What gets sent:
- Version (e.g., 0.1.2)
- Python version (e.g., 3.11.5)
- OS (e.g., darwin, linux)
- Crash reports: stack traces with local paths + API keys stripped
- Error counts by engine (e.g., "upstream_watcher: 3 timeouts, 0 other errors")
- Schema / protocol version
- Aggregate metrics (total evidence, domain counts -- no finding content)

What never gets sent:
- Finding text / evidence content
- API keys (sanitized via OPSECGuard)
- Local paths (sanitized)
- Repository names or commits
- LLM prompts or responses
- User identity (random pseudonym UUID stored locally)

Transport: POST to https://telemetry.nebula.zenon.org/v1/report (configurable).
Fallback: write to ``data/telemetry_queue.json`` for later retry -- the queue
is flushed on the next successful send so no data is lost if the endpoint is
temporarily unreachable.

All public functions are no-ops when ``NEBULA_TELEMETRY`` is not set to "1",
so calling them from anywhere in the codebase is safe and never leaks data
without explicit user opt-in.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import sys
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
TELEMETRY_QUEUE = ENGINE_ROOT / "data" / "telemetry_queue.json"
INSTANCE_ID_FILE = ENGINE_ROOT / "data" / "instance_id"
DEFAULT_ENDPOINT = "https://telemetry.nebula.zenon.org/v1/report"

# Cap the queue so a long outage cannot bloat the filesystem.
MAX_QUEUED_EVENTS = 1000

# Truncation limits to keep payloads small and bounded.
MAX_CONTEXT_CHARS = 200
MAX_MESSAGE_CHARS = 500
MAX_TRACEBACK_CHARS = 5000

# HTTP timeout for telemetry requests (seconds). Kept short so telemetry
# failures never slow down the main loop.
HTTP_TIMEOUT = 5


def is_enabled() -> bool:
    """Return True when telemetry has been opted in via ``NEBULA_TELEMETRY=1``."""
    return os.environ.get("NEBULA_TELEMETRY", "0") == "1"


def get_instance_id() -> str:
    """Return a stable pseudonymous instance ID.

    The ID is a random UUID generated once per install and stored in
    ``data/instance_id``. It contains no PII and exists only so maintainers
    can correlate crash reports coming from the same instance over time.
    Deleting the file resets the ID.
    """
    try:
        if INSTANCE_ID_FILE.exists():
            existing = INSTANCE_ID_FILE.read_text().strip()
            if existing:
                return existing
    except OSError:
        pass

    new_id = str(uuid.uuid4())
    try:
        INSTANCE_ID_FILE.parent.mkdir(parents=True, exist_ok=True)
        INSTANCE_ID_FILE.write_text(new_id)
    except OSError as exc:
        # If we cannot persist the ID, return an ephemeral one so callers
        # still get a usable value. Not persistent, but not a fatal error.
        logger.debug("Could not persist instance_id: %s", exc)
    return new_id


def collect_environment() -> dict:
    """Return basic environment info (version, python, os, arch, id).

    Contains no PII. Safe to include in every telemetry payload.
    """
    try:
        from core.version import PROTOCOL_VERSION, get_version

        version = get_version()
        protocol_version = PROTOCOL_VERSION
    except Exception:
        version = "unknown"
        protocol_version = 0

    return {
        "version": version,
        "protocol_version": protocol_version,
        "python": sys.version.split()[0],
        "os": platform.system().lower(),
        "arch": platform.machine(),
        "instance_id": get_instance_id(),
    }


def report_crash(
    exc: BaseException,
    context: str = "",
    extra: dict | None = None,
) -> None:
    """Report a crash to the telemetry endpoint (if opted in).

    The stack trace is sanitized via ``OPSECGuard.sanitize_prompt`` before
    sending so local paths and API keys never leave the machine. Never
    raises -- telemetry failures are logged at DEBUG only.
    """
    if not is_enabled():
        return

    try:
        import traceback

        from core.opsec import OPSECGuard

        # traceback.format_exc() reads sys.exc_info; if we were not called
        # from inside an except block, format the passed exception directly.
        tb_text = traceback.format_exc()
        if not tb_text or tb_text.strip() == "NoneType: None":
            tb_text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))

        sanitized_tb = OPSECGuard.sanitize_prompt(tb_text)
        sanitized_message = OPSECGuard.sanitize_prompt(str(exc))
        sanitized_context = OPSECGuard.sanitize_prompt(context)

        event = {
            "type": "crash",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "context": sanitized_context[:MAX_CONTEXT_CHARS],
            "exception_type": type(exc).__name__,
            "exception_message": sanitized_message[:MAX_MESSAGE_CHARS],
            "traceback": sanitized_tb[:MAX_TRACEBACK_CHARS],
            "env": collect_environment(),
            "extra": _sanitize_extra(extra),
        }
        _queue_or_send(event)
    except Exception as telemetry_exc:
        logger.debug("Telemetry crash reporting failed: %s", telemetry_exc)


def report_metrics(metrics: dict) -> None:
    """Report aggregate metrics (evidence counts, engine health, cost totals).

    Metrics must be pre-aggregated numbers -- never pass finding text.
    """
    if not is_enabled():
        return

    try:
        event = {
            "type": "metrics",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "env": collect_environment(),
            "metrics": _sanitize_extra(metrics),
        }
        _queue_or_send(event)
    except Exception as exc:
        logger.debug("Telemetry metrics reporting failed: %s", exc)


def report_engine_errors(errors_by_engine: dict) -> None:
    """Report per-engine error counts so maintainers see what's failing.

    ``errors_by_engine`` is a mapping of ``engine_name -> count`` (both
    scalar). Anything else is coerced/dropped.
    """
    if not is_enabled():
        return

    try:
        clean: dict = {}
        for key, value in (errors_by_engine or {}).items():
            try:
                clean[str(key)[:128]] = int(value)
            except (TypeError, ValueError):
                continue

        if not clean:
            return

        event = {
            "type": "engine_errors",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "env": collect_environment(),
            "errors": clean,
        }
        _queue_or_send(event)
    except Exception as exc:
        logger.debug("Engine error reporting failed: %s", exc)


def flush_queue() -> int:
    """Attempt to send any queued events. Returns the number delivered.

    Public wrapper around ``_flush_queue`` so other modules (e.g. the
    autonomous runner or the ``nebula doctor`` command) can trigger a
    manual flush without caring about the implementation details.
    """
    if not is_enabled():
        return 0
    try:
        return _flush_queue()
    except Exception as exc:
        logger.debug("Telemetry flush failed: %s", exc)
        return 0


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _sanitize_extra(extra: dict | None) -> dict:
    """Best-effort sanitization of caller-provided ``extra`` / metrics dicts.

    Scalars pass through; strings go through OPSECGuard; anything else is
    coerced to ``repr`` so callers cannot accidentally leak finding objects.
    """
    if not extra:
        return {}

    try:
        from core.opsec import OPSECGuard
    except Exception:
        OPSECGuard = None  # type: ignore[assignment]

    clean: dict[str, Any] = {}
    for key, value in extra.items():
        safe_key = str(key)[:128]
        if isinstance(value, (int, float, bool)) or value is None:
            clean[safe_key] = value
        elif isinstance(value, str):
            if OPSECGuard is not None:
                try:
                    clean[safe_key] = OPSECGuard.sanitize_prompt(value)[:500]
                    continue
                except Exception as exc:
                    logger.debug("OPSEC sanitize_prompt failed: %s", exc)
            clean[safe_key] = value[:500]
        else:
            # Drop complex objects rather than risk leaking their contents.
            clean[safe_key] = f"<{type(value).__name__}>"
    return clean


def _endpoint() -> str:
    return os.environ.get("NEBULA_TELEMETRY_ENDPOINT", DEFAULT_ENDPOINT)


def _user_agent() -> str:
    try:
        from core.version import get_version

        return f"nebula/{get_version()}"
    except Exception as exc:
        logger.debug("version lookup for user-agent failed: %s", exc)
        return "nebula/unknown"


def _post_event(event: dict) -> bool:
    """POST a single event. Returns True on success.

    Uses the OPSEC-safe HTTP wrapper so telemetry POSTs never carry
    a fingerprintable Python-urllib/3.x User-Agent or any identifying
    headers. The telemetry collector operator can still see the
    originating IP (unavoidable), but the request shape is
    indistinguishable from any other browser-like HTTP call.
    """
    from core.http import opsec_request, opsec_urlopen

    req = opsec_request(
        _endpoint(),
        data=json.dumps(event).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            # _user_agent() is still called so operators who customize
            # it (via NEBULA_TELEMETRY_UA) see their override, but
            # sanitize_headers will replace it with an anonymous one
            # unless the override is a real browser string.
            "User-Agent": _user_agent(),
        },
    )
    try:
        with opsec_urlopen(req, timeout=HTTP_TIMEOUT) as resp:
            # 2xx is success; other statuses are treated as transient.
            return 200 <= getattr(resp, "status", 200) < 300
    except (urllib.error.URLError, TimeoutError, OSError):
        return False


def _queue_or_send(event: dict) -> None:
    """Try to send ``event`` immediately; on failure queue it for retry."""
    if _post_event(event):
        # Successful send -- opportunistically flush any backlog.
        try:
            _flush_queue()
        except Exception as exc:
            logger.debug("telemetry flush failed: %s", exc)
        return
    _queue_event(event)


def _queue_event(event: dict) -> None:
    """Persist ``event`` to the on-disk retry queue."""
    try:
        TELEMETRY_QUEUE.parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        return

    queue: list[dict] = []
    if TELEMETRY_QUEUE.exists():
        try:
            loaded = json.loads(TELEMETRY_QUEUE.read_text())
            if isinstance(loaded, list):
                queue = loaded
        except (json.JSONDecodeError, OSError):
            queue = []

    queue.append(event)
    queue = queue[-MAX_QUEUED_EVENTS:]

    try:
        TELEMETRY_QUEUE.write_text(json.dumps(queue, indent=2))
    except OSError as exc:
        logger.debug("Could not write telemetry queue: %s", exc)


def _flush_queue() -> int:
    """Attempt to drain the queue. Returns number of events delivered."""
    if not TELEMETRY_QUEUE.exists():
        return 0

    try:
        loaded = json.loads(TELEMETRY_QUEUE.read_text())
    except (json.JSONDecodeError, OSError):
        return 0

    if not isinstance(loaded, list) or not loaded:
        return 0

    sent = 0
    remaining: list[dict] = []
    for event in loaded:
        if _post_event(event):
            sent += 1
        else:
            remaining.append(event)

    try:
        if remaining:
            TELEMETRY_QUEUE.write_text(json.dumps(remaining, indent=2))
        else:
            TELEMETRY_QUEUE.unlink(missing_ok=True)
    except OSError:
        pass
    return sent
