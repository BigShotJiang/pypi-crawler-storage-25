# SPDX-License-Identifier: MIT
"""
Universal Explorer API — Connect to any blockchain explorer.

Supports multiple explorer APIs with a unified interface. Auto-detects
explorer type from URL patterns. Falls back to generic REST client.

Built-in adapters:
  - ZenonHub (zenonhub.io)
  - Etherscan-compatible (Etherscan, BscScan, PolygonScan, etc.)
  - Blockchair (Bitcoin, Ethereum, Litecoin, etc.)
  - Mempool.space (Bitcoin mempool + blocks)
  - Generic REST (any JSON API)

Usage:
    from core.explorer_api import get_explorer, get_all_explorers

    # Auto-detect from URL
    explorer = get_explorer("https://zenonhub.io/api")
    balance = explorer.get_balance("z1qz...")

    # Get all configured explorers
    explorers = get_all_explorers()

Configuration via env:
    ZENONHUB_API_URL=https://zenonhub.io/api
    ETHERSCAN_API_URL=https://api.etherscan.io/api
    ETHERSCAN_API_KEY=...
    BLOCKCHAIR_API_URL=https://api.blockchair.com
    MEMPOOL_API_URL=https://mempool.space/api
    # Generic: any EXPLORER_*_URL var gets registered
    EXPLORER_SOLANA_URL=https://api.solscan.io
    EXPLORER_AVALANCHE_URL=https://api.snowtrace.io/api
"""

import json
import logging
import os
import urllib.request
from urllib.parse import urlparse

from core.http import opsec_request, opsec_urlopen  # noqa: F401  OPSEC-safe HTTP wrapper

logger = logging.getLogger(__name__)

# Request timeout for explorer APIs
REQUEST_TIMEOUT = 15


class ExplorerAPI:
    """Base class for blockchain explorer APIs."""

    def __init__(self, base_url: str, chain: str = "unknown", api_key: str = ""):
        self.base_url = base_url.rstrip("/")
        self.chain = chain
        self.api_key = api_key

    def get_balance(self, address: str) -> dict | None:
        """Get address balance. Returns {balance, token, raw} or None."""
        return None

    def get_transactions(self, address: str, limit: int = 20) -> list[dict]:
        """Get recent transactions for an address."""
        return []

    def get_block_height(self) -> int | None:
        """Get current block/momentum height."""
        return None

    def get_token_info(self, token_id: str) -> dict | None:
        """Get token metadata."""
        return None

    def get_validators(self) -> list[dict]:
        """Get validator/pillar/node list."""
        return []

    def get_proposals(self) -> list[dict]:
        """Get governance proposals."""
        return []

    def is_available(self) -> bool:
        """Check if explorer is reachable."""
        try:
            self.get_block_height()
            return True
        except Exception:
            return False

    def _get(self, path: str, params: dict | None = None) -> dict:
        """Make a GET request to the explorer API."""
        url = f"{self.base_url}/{path.lstrip('/')}"
        if params:
            query = "&".join(f"{k}={v}" for k, v in params.items())
            url = f"{url}?{query}"

        headers = {"Accept": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        req = urllib.request.Request(url, headers=headers)
        try:
            resp = opsec_urlopen(req, timeout=REQUEST_TIMEOUT)
            return json.loads(resp.read())
        except Exception as exc:
            logger.debug("Explorer API request failed for %s: %s", url, exc)
            raise


class ZenonHubExplorer(ExplorerAPI):
    """Zenon chain adapter.

    Historically this adapter spoke a fictional REST shape
    ``https://zenonhub.io/api/nom/...`` which does not actually exist. The
    2026-04-09 API audit confirmed every ``/nom/*`` path returns 404. This
    adapter now delegates to :mod:`core.zenon_data` which talks HTTP
    JSON-RPC directly to a Zenon node (public by default, configurable via
    ``ZENON_PUBLIC_RPC``).

    The class name is kept for backwards compatibility with consumers that
    call ``get_explorer("https://zenonhub.io/api")``.
    """

    def __init__(self, base_url: str = "", api_key: str = ""):
        # base_url and api_key are accepted for backwards compatibility with
        # callers that still pass the old zenonhub.io URL. They are unused.
        del base_url, api_key
        super().__init__("zenon-rpc", chain="zenon", api_key="")
        # Late import to avoid a hard dependency cycle on module load.
        from core.zenon_data import get_zenon_data

        self._rpc = get_zenon_data()

    def get_block_height(self) -> int | None:
        """Return the current momentum height from the configured Zenon node."""
        return self._rpc.get_height()

    def get_balance(self, address: str) -> dict | None:
        """Return ZNN and QSR balances for a Zenon address.

        Args:
            address: ``z1q...`` formatted address.

        Returns:
            Dict with ``address``, ``balance_znn``, ``balance_qsr``, ``chain``
            or ``None`` if the node is unreachable.
        """
        raw = self._rpc.get_balance(address)
        if raw == {"znn": 0, "qsr": 0} and not self._rpc.is_reachable():
            return None
        return {
            "address": address,
            "balance_znn": raw["znn"],
            "balance_qsr": raw["qsr"],
            "chain": "zenon",
        }

    def get_validators(self) -> list[dict]:
        """Return the pillar list as simplified dicts."""
        pillars = self._rpc.get_all_pillars()
        return [
            {
                "name": p.get("name"),
                "weight": p.get("weight", 0),
                "produced": p.get("currentStats", {}).get("producedMomentums", 0)
                if isinstance(p.get("currentStats"), dict)
                else p.get("producedMomentums", 0),
                "delegators": p.get("delegationCount", p.get("delegateCount", 0)),
            }
            for p in pillars
        ]

    def get_proposals(self) -> list[dict]:
        """Return Accelerator-Z projects as simplified dicts."""
        projects = self._rpc.get_all_projects(page=0, count=50)
        return [
            {
                "id": p.get("id"),
                "name": p.get("name"),
                "status": p.get("status"),
                "znn_requested": p.get("znnFundsNeeded", 0),
                "qsr_requested": p.get("qsrFundsNeeded", 0),
            }
            for p in projects
        ]


class EtherscanExplorer(ExplorerAPI):
    """Etherscan-compatible API adapter (works with BscScan, PolygonScan, etc.)."""

    def __init__(self, base_url: str = "", api_key: str = "", chain: str = "ethereum"):
        url = base_url or os.environ.get("ETHERSCAN_API_URL", "https://api.etherscan.io/api")
        key = api_key or os.environ.get("ETHERSCAN_API_KEY", "")
        super().__init__(url, chain=chain, api_key=key)

    def get_block_height(self) -> int | None:
        """Get latest block number via Etherscan proxy."""
        try:
            params = {"module": "proxy", "action": "eth_blockNumber"}
            if self.api_key:
                params["apikey"] = self.api_key
            data = self._get("", params)
            hex_val = data.get("result", "0x0")
            return int(hex_val, 16)
        except Exception:
            return None

    def get_balance(self, address: str) -> dict | None:
        """Get ETH balance for an address via Etherscan."""
        try:
            params = {"module": "account", "action": "balance", "address": address, "tag": "latest"}
            if self.api_key:
                params["apikey"] = self.api_key
            data = self._get("", params)
            wei = int(data.get("result", "0"))
            return {
                "address": address,
                "balance": wei / 1e18,
                "balance_raw": wei,
                "chain": self.chain,
            }
        except Exception:
            return None

    def get_transactions(self, address: str, limit: int = 20) -> list[dict]:
        """Get recent transactions for an address via Etherscan."""
        try:
            params = {
                "module": "account",
                "action": "txlist",
                "address": address,
                "sort": "desc",
                "page": "1",
                "offset": str(limit),
            }
            if self.api_key:
                params["apikey"] = self.api_key
            data = self._get("", params)
            return data.get("result", [])[:limit]
        except Exception:
            return []


class BlockchairExplorer(ExplorerAPI):
    """Blockchair API adapter (Bitcoin, Ethereum, Litecoin, etc.)."""

    def __init__(self, base_url: str = "", chain: str = "bitcoin"):
        url = base_url or os.environ.get("BLOCKCHAIR_API_URL", "https://api.blockchair.com")
        super().__init__(url, chain=chain)

    def get_block_height(self) -> int | None:
        """Get latest block height from Blockchair."""
        try:
            data = self._get(f"{self.chain}/stats")
            return data.get("data", {}).get("blocks", None)
        except Exception:
            return None

    def get_balance(self, address: str) -> dict | None:
        """Get address balance from Blockchair."""
        try:
            data = self._get(f"{self.chain}/dashboards/address/{address}")
            addr_data = data.get("data", {}).get(address, {}).get("address", {})
            return {
                "address": address,
                "balance": addr_data.get("balance", 0) / 1e8,
                "balance_raw": addr_data.get("balance", 0),
                "chain": self.chain,
            }
        except Exception:
            return None


class MempoolExplorer(ExplorerAPI):
    """Mempool.space API adapter (Bitcoin mempool + blocks)."""

    def __init__(self, base_url: str = ""):
        url = base_url or os.environ.get("MEMPOOL_API_URL", "https://mempool.space/api")
        super().__init__(url, chain="bitcoin")

    def get_block_height(self) -> int | None:
        """Get current Bitcoin tip height from Mempool.space."""
        try:
            data = self._get("blocks/tip/height")
            return int(data) if isinstance(data, (int, str)) else None
        except Exception:
            return None

    def get_balance(self, address: str) -> dict | None:
        """Get Bitcoin address balance from Mempool.space."""
        try:
            data = self._get(f"address/{address}")
            funded = data.get("chain_stats", {}).get("funded_txo_sum", 0)
            spent = data.get("chain_stats", {}).get("spent_txo_sum", 0)
            balance = funded - spent
            return {
                "address": address,
                "balance": balance / 1e8,
                "balance_raw": balance,
                "chain": "bitcoin",
            }
        except Exception:
            return None


class GenericExplorer(ExplorerAPI):
    """Generic REST API explorer — works with any JSON API."""

    def get_block_height(self) -> int | None:
        """Try common API patterns to find block height."""
        # Try common endpoint patterns
        for path in ["status", "stats", "info", "v1/status", "api/status"]:
            try:
                data = self._get(path)
                for key in ["height", "block_height", "blockHeight", "blocks", "latest_block"]:
                    if key in data:
                        return int(data[key])
                    if isinstance(data.get("data"), dict) and key in data["data"]:
                        return int(data["data"][key])
            except Exception:
                continue
        return None


# ---------------------------------------------------------------------------
# Factory + Registry
# ---------------------------------------------------------------------------


def _detect_explorer_type(url: str) -> str:
    """Detect explorer type from URL."""
    host = urlparse(url).hostname or ""
    if "zenonhub" in host:
        return "zenonhub"
    elif "etherscan" in host or "bscscan" in host or "polygonscan" in host or "snowtrace" in host:
        return "etherscan"
    elif "blockchair" in host:
        return "blockchair"
    elif "mempool" in host:
        return "mempool"
    return "generic"


def get_explorer(url: str, chain: str = "", api_key: str = "") -> ExplorerAPI:
    """Create an explorer client from a URL. Auto-detects type."""
    explorer_type = _detect_explorer_type(url)

    if explorer_type == "zenonhub":
        return ZenonHubExplorer(url, api_key)
    elif explorer_type == "etherscan":
        return EtherscanExplorer(url, api_key, chain or "ethereum")
    elif explorer_type == "blockchair":
        return BlockchairExplorer(url, chain or "bitcoin")
    elif explorer_type == "mempool":
        return MempoolExplorer(url)
    else:
        return GenericExplorer(url, chain or "unknown", api_key)


def get_all_explorers() -> dict[str, ExplorerAPI]:
    """Get all configured explorers from environment variables.

    Reads:
      ZENONHUB_API_URL → zenonhub
      ETHERSCAN_API_URL → etherscan
      BLOCKCHAIR_API_URL → blockchair
      MEMPOOL_API_URL → mempool
      EXPLORER_*_URL → generic (any custom explorer)
    """
    explorers = {}

    # Built-in explorers
    zenonhub_url = os.environ.get("ZENONHUB_API_URL")
    if zenonhub_url:
        explorers["zenon"] = ZenonHubExplorer(zenonhub_url)

    etherscan_url = os.environ.get("ETHERSCAN_API_URL")
    if etherscan_url:
        explorers["ethereum"] = EtherscanExplorer(etherscan_url)

    blockchair_url = os.environ.get("BLOCKCHAIR_API_URL")
    if blockchair_url:
        explorers["bitcoin"] = BlockchairExplorer(blockchair_url)

    mempool_url = os.environ.get("MEMPOOL_API_URL")
    if mempool_url:
        explorers["bitcoin_mempool"] = MempoolExplorer(mempool_url)

    # Generic: any EXPLORER_*_URL env var
    for key, value in os.environ.items():
        if key.startswith("EXPLORER_") and key.endswith("_URL") and value:
            chain_name = key[9:-4].lower()  # EXPLORER_SOLANA_URL → solana
            if chain_name not in explorers:
                explorers[chain_name] = get_explorer(value, chain=chain_name)

    return explorers
