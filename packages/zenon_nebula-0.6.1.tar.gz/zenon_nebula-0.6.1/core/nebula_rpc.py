# SPDX-License-Identifier: MIT
"""
Nebula RPC — Query any Nebula instance's status, height, and findings.

Exposes Nebula state over HTTP JSON-RPC, similar to how blockchain nodes
expose their state. Other Nebula instances, Nexus, or any HTTP client
can query a running Nebula.

Methods:
  nebula_status       — domains, evidence count, hypothesis count, uptime
  nebula_height       — current evidence chain height
  nebula_findings     — recent findings (with filters)
  nebula_hypotheses   — all hypotheses with confidence
  nebula_domains      — registered domains and engines
  nebula_costs        — LLM cost breakdown
  nebula_peers        — known peer instances
  nebula_health       — is this instance healthy?

Usage:
    # Start RPC server
    nebula rpc --port 8484

    # Query from anywhere
    curl http://localhost:8484 -d '{"method": "nebula_height", "id": 1}'

    # Or from another Nebula instance
    from core.nebula_rpc import query_peer
    height = query_peer("http://peer:8484", "nebula_height")

Configuration:
    NEBULA_RPC_PORT=8484
    NEBULA_RPC_HOST=0.0.0.0
"""

import json
import logging
import os
import sqlite3
import time
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from core.http import opsec_request, opsec_urlopen  # noqa: F401  OPSEC-safe HTTP wrapper
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
DEFAULT_PORT = int(os.environ.get("NEBULA_RPC_PORT", "8484"))
# Default to localhost for OPSEC — only expose externally if explicitly configured.
# Cross-network sharing should go through Nexus (SpacetimeDB), not direct RPC.
DEFAULT_HOST = os.environ.get("NEBULA_RPC_HOST", "127.0.0.1")

# Track when this instance started
_START_TIME = time.time()


def _get_db(db_path: str = DEFAULT_DB) -> sqlite3.Connection | None:
    """Get DB connection with row factory."""
    try:
        conn = connect(db_path)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception:
        return None


# ---------------------------------------------------------------------------
# RPC Methods
# ---------------------------------------------------------------------------


def rpc_status(db_path: str = DEFAULT_DB, **kwargs) -> dict:
    """Full instance status."""
    conn = _get_db(db_path)
    if not conn:
        return {"error": "database unavailable"}

    try:
        evidence = conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
        hypotheses = conn.execute("SELECT COUNT(*) FROM hypotheses").fetchone()[0]
        domains = conn.execute("SELECT COUNT(DISTINCT domain) FROM evidence").fetchone()[0]
        engines = conn.execute("SELECT COUNT(DISTINCT engine) FROM evidence").fetchone()[0]
        height = conn.execute("SELECT COALESCE(MAX(id), 0) FROM evidence").fetchone()[0]

        try:
            status_counts = {
                r[0]: r[1]
                for r in conn.execute(
                    "SELECT COALESCE(status, 'open'), COUNT(*) FROM evidence GROUP BY 1"
                ).fetchall()
            }
        except Exception:
            status_counts = {}

        try:
            last_activity = conn.execute("SELECT MAX(timestamp) FROM evidence").fetchone()[0]
        except Exception:
            last_activity = None

        return {
            "height": height,
            "evidence_count": evidence,
            "hypothesis_count": hypotheses,
            "domains_active": domains,
            "engines_active": engines,
            "findings_open": status_counts.get("open", 0),
            "findings_resolved": status_counts.get("resolved", 0),
            "last_activity": last_activity,
            "uptime_seconds": int(time.time() - _START_TIME),
            "participant_id": os.environ.get("NEBULA_PARTICIPANT_ID", "anonymous"),
            "version": _get_version(),
        }
    finally:
        conn.close()


def rpc_height(db_path: str = DEFAULT_DB, **kwargs) -> dict:
    """Evidence chain height."""
    conn = _get_db(db_path)
    if not conn:
        return {"height": 0}
    try:
        height = conn.execute("SELECT COALESCE(MAX(id), 0) FROM evidence").fetchone()[0]
        count = conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
        return {"height": height, "count": count}
    finally:
        conn.close()


def _scrub_row(row: dict) -> dict:
    """Pass text-bearing fields of a DB row through sanitize_for_sharing.

    This runs on every RPC response so findings that happen to contain a
    local path or a secret that leaked into a finding (despite
    sanitize_prompt on the way in) don't leak out over the RPC. Costs
    ~1ms per row which is fine at Nebula's query rate.
    """
    try:
        from core.opsec import OPSECGuard
    except Exception:
        return row

    cleaned = dict(row)
    participant = os.environ.get("NEBULA_PARTICIPANT_ID", "anonymous")
    for field in ("finding", "title", "description", "source_file", "raw_data"):
        if field in cleaned and isinstance(cleaned[field], str):
            cleaned[field] = OPSECGuard.sanitize_for_sharing(
                cleaned[field], participant_id=participant
            )
    return cleaned


def rpc_findings(
    db_path: str = DEFAULT_DB, domain: str = "", status: str = "", limit: int = 20, **kwargs
) -> dict:
    """Recent findings with optional filters. Text fields are sanitized."""
    conn = _get_db(db_path)
    if not conn:
        return {"findings": []}
    try:
        query = "SELECT id, domain, engine, evidence_type, finding, confidence, status, timestamp FROM evidence"
        conditions = []
        params = []
        if domain:
            conditions.append("domain = ?")
            params.append(domain)
        if status:
            conditions.append("COALESCE(status, 'open') = ?")
            params.append(status)
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY id DESC LIMIT ?"
        params.append(limit)

        rows = conn.execute(query, params).fetchall()
        # Sanitize before returning — RPC responses must never leak
        # local paths or participant IDs, even when bound to localhost.
        # See docs/SECURITY-OPSEC-AUDIT.md.
        findings = [_scrub_row(dict(r)) for r in rows]
        return {"findings": findings, "count": len(findings)}
    finally:
        conn.close()


def rpc_hypotheses(db_path: str = DEFAULT_DB, **kwargs) -> dict:
    """All hypotheses with confidence. Text fields are sanitized."""
    conn = _get_db(db_path)
    if not conn:
        return {"hypotheses": []}
    try:
        rows = conn.execute(
            "SELECT id, domain, title, confidence, status FROM hypotheses ORDER BY confidence DESC"
        ).fetchall()
        # Sanitize before returning (see rpc_findings comment).
        hypotheses = [_scrub_row(dict(r)) for r in rows]
        return {"hypotheses": hypotheses}
    finally:
        conn.close()


def rpc_domains(db_path: str = DEFAULT_DB, **kwargs) -> dict:
    """Registered domains and their evidence counts."""
    conn = _get_db(db_path)
    if not conn:
        return {"domains": {}}
    try:
        rows = conn.execute(
            "SELECT domain, COUNT(*) as count, ROUND(AVG(confidence), 3) as avg_conf "
            "FROM evidence GROUP BY domain ORDER BY count DESC"
        ).fetchall()
        return {
            "domains": {
                r["domain"]: {"count": r["count"], "avg_confidence": r["avg_conf"]} for r in rows
            }
        }
    finally:
        conn.close()


def rpc_costs(db_path: str = DEFAULT_DB, **kwargs) -> dict:
    """LLM cost breakdown."""
    conn = _get_db(db_path)
    if not conn:
        return {"costs": {}}
    try:
        rows = conn.execute(
            "SELECT provider, model, COUNT(*) as calls, ROUND(SUM(cost_usd), 4) as total "
            "FROM cost_tracking GROUP BY provider, model ORDER BY total DESC"
        ).fetchall()
        total = conn.execute("SELECT COALESCE(SUM(cost_usd), 0) FROM cost_tracking").fetchone()[0]
        return {
            "breakdown": [dict(r) for r in rows],
            "total_usd": round(total, 4),
        }
    finally:
        conn.close()


def rpc_health(**kwargs) -> dict:
    """Health check — is this instance alive and functional?"""
    return {
        "healthy": True,
        "uptime_seconds": int(time.time() - _START_TIME),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# Method registry
RPC_METHODS = {
    "nebula_status": rpc_status,
    "nebula_height": rpc_height,
    "nebula_findings": rpc_findings,
    "nebula_hypotheses": rpc_hypotheses,
    "nebula_domains": rpc_domains,
    "nebula_costs": rpc_costs,
    "nebula_health": rpc_health,
}


def _get_version() -> str:
    """Get Nebula version from git or fallback."""
    import subprocess

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
            cwd=str(ENGINE_ROOT),
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (OSError, subprocess.SubprocessError) as exc:
        logger.debug("git rev-parse failed: %s", exc)
    return "unknown"


# ---------------------------------------------------------------------------
# HTTP JSON-RPC Server
# ---------------------------------------------------------------------------


class NebulRPCHandler(BaseHTTPRequestHandler):
    """HTTP JSON-RPC handler for Nebula queries."""

    db_path = DEFAULT_DB

    def do_POST(self):
        """Handle JSON-RPC POST request."""
        try:
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length)) if length else {}

            method = body.get("method", "")
            params = body.get("params", {})
            req_id = body.get("id", 1)

            if method not in RPC_METHODS:
                self._respond({"error": f"unknown method: {method}", "id": req_id})
                return

            result = RPC_METHODS[method](db_path=self.db_path, **params)
            self._respond({"result": result, "id": req_id})

        except Exception as exc:
            self._respond({"error": str(exc), "id": 0})

    def do_GET(self):
        """Handle GET requests.

        Two endpoints:
          * ``/metrics`` — Prometheus text exposition (see core.metrics).
          * anything else — JSON health check.
        """
        if self.path.split("?", 1)[0].rstrip("/") == "/metrics":
            try:
                from core import metrics as _metrics

                body = _metrics.render().encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", _metrics.CONTENT_TYPE)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            except Exception as exc:  # pragma: no cover - defensive
                logger.debug("metrics endpoint failed: %s", exc)
                self._respond({"error": "metrics unavailable", "id": 0})
                return

        result = rpc_health()
        self._respond({"result": result, "id": 0})

    def _respond(self, data: dict):
        """Send JSON response."""
        body = json.dumps(data, default=str).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        """Suppress default logging."""
        pass


def start_rpc_server(host: str = DEFAULT_HOST, port: int = DEFAULT_PORT, db_path: str = DEFAULT_DB):
    """Start the Nebula RPC server."""
    NebulRPCHandler.db_path = db_path
    server = HTTPServer((host, port), NebulRPCHandler)
    logger.info("Nebula RPC server listening on %s:%d", host, port)
    print(f"Nebula RPC server listening on {host}:{port}")
    print(f'  curl http://localhost:{port} -d \'{{"method": "nebula_status", "id": 1}}\'')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()


# ---------------------------------------------------------------------------
# Client — query a remote Nebula instance
# ---------------------------------------------------------------------------


def query_peer(url: str, method: str, params: dict | None = None) -> dict | None:
    """Query a remote Nebula instance via JSON-RPC.

    Args:
        url: Peer RPC URL (e.g., "http://peer:8484")
        method: RPC method name (e.g., "nebula_height")
        params: Optional parameters dict

    Returns:
        Result dict or None on failure.
    """
    body = json.dumps(
        {
            "method": method,
            "params": params or {},
            "id": 1,
        }
    ).encode()

    req = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json"},
    )
    try:
        resp = opsec_urlopen(req, timeout=10)
        data = json.loads(resp.read())
        return data.get("result")
    except Exception as exc:
        logger.debug("Peer query failed (%s %s): %s", url, method, exc)
        return None


def discover_peers() -> list[dict]:
    """Discover Nebula peers from NEBULA_RPC_PEERS env var.

    Format: NEBULA_RPC_PEERS=http://peer1:8484,http://peer2:8484

    Returns list of {url, healthy, height} for each peer.
    """
    peers_str = os.environ.get("NEBULA_RPC_PEERS", "")
    if not peers_str:
        return []

    peers = []
    for url in peers_str.split(","):
        url = url.strip()
        if not url:
            continue
        health = query_peer(url, "nebula_health")
        height_data = query_peer(url, "nebula_height")
        peers.append(
            {
                "url": url,
                "healthy": health is not None and health.get("healthy", False),
                "height": height_data.get("height", 0) if height_data else 0,
            }
        )

    return peers
