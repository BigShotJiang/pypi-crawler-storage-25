# SPDX-License-Identifier: MIT
"""
ZenonNodeClient -- WebSocket JSON-RPC client for connecting to a local znnd node.

Provides real-time chain data to any Nebula domain that needs it.
Falls back gracefully: if the node is unavailable, all methods return None
so domains can fall back to the zenonhub API.

Usage:
    ZENON_NODE_RPC=ws://localhost:35998 in .env

    client = ZenonNodeClient()
    if client.is_connected():
        momentum = client.get_frontier_momentum()
"""

import json
import logging
import os
import threading
from typing import Any, Optional

logger = logging.getLogger(__name__)

try:
    import websocket as ws_lib

    HAS_WEBSOCKET = True
except ImportError:
    HAS_WEBSOCKET = False


class RpcError(Exception):
    """Raised when a JSON-RPC call returns an error response."""

    def __init__(self, code: int, message: str, data: Any = None):
        self.code = code
        self.message = message
        self.data = data
        super().__init__(f"RPC error {code}: {message}")


class ZenonNodeClient:
    """WebSocket JSON-RPC client for znnd.

    Thread-safe: uses a lock around send/recv to support concurrent callers.
    Auto-reconnects on connection loss (single retry per call).
    """

    def __init__(
        self,
        url: str | None = None,
        timeout: float = 5.0,
    ):
        """Initialize the client.

        Args:
            url:     WebSocket URL. Defaults to ZENON_NODE_RPC env var,
                     then ws://127.0.0.1:35998.
            timeout: Connection and recv timeout in seconds.
        """
        self._url = url or os.environ.get("ZENON_NODE_RPC", "ws://127.0.0.1:35998")
        self._timeout = timeout
        self._ws: Any | None = None
        self._req_id = 0
        self._lock = threading.Lock()
        self._connected = False

        if not HAS_WEBSOCKET:
            logger.info(
                "websocket-client not installed; node RPC disabled. "
                "Install with: pip install websocket-client"
            )
            return

        self._try_connect()

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    def _try_connect(self) -> bool:
        """Attempt to open a WebSocket connection. Returns success."""
        if not HAS_WEBSOCKET:
            return False
        try:
            self._ws = ws_lib.create_connection(self._url, timeout=self._timeout)
            self._connected = True
            logger.info("Connected to Zenon node at %s", self._url)
            return True
        except Exception as exc:
            self._connected = False
            self._ws = None
            logger.debug("Could not connect to %s: %s", self._url, exc)
            return False

    def close(self) -> None:
        """Close the WebSocket connection."""
        with self._lock:
            if self._ws:
                try:
                    self._ws.close()
                except Exception as exc:
                    logger.debug("WebSocket close error: %s", exc)
                self._ws = None
            self._connected = False

    def is_connected(self) -> bool:
        """Return True if the WebSocket is currently open."""
        return self._connected and self._ws is not None

    def reconnect(self) -> bool:
        """Close and reopen the connection. Returns success."""
        self.close()
        with self._lock:
            return self._try_connect()

    # ------------------------------------------------------------------
    # Low-level RPC
    # ------------------------------------------------------------------

    def _call(self, method: str, params: list | None = None) -> Any | None:
        """Make a JSON-RPC 2.0 call. Returns None if not connected."""
        if not HAS_WEBSOCKET:
            return None

        with self._lock:
            if not self._ws and not self._try_connect():
                return None

            self._req_id += 1
            payload = {
                "jsonrpc": "2.0",
                "id": self._req_id,
                "method": method,
                "params": params or [],
            }

            try:
                return self._send_recv(payload)
            except Exception as exc:
                # Single reconnect attempt
                logger.debug("RPC call %s failed, reconnecting: %s", method, exc)
                try:
                    self._try_connect()
                    if self._ws:
                        return self._send_recv(payload)
                except Exception as exc:
                    logger.debug("RPC call %s failed after reconnect: %s", method, exc)
                    self._connected = False
                return None

    def _send_recv(self, payload: dict) -> Any:
        """Send payload and parse response. Raises on RPC error or transport failure."""
        self._ws.send(json.dumps(payload))
        raw = self._ws.recv()
        resp = json.loads(raw)
        if "error" in resp:
            err = resp["error"]
            raise RpcError(
                err.get("code", -1),
                err.get("message", "unknown"),
                err.get("data"),
            )
        return resp.get("result")

    # ------------------------------------------------------------------
    # Ledger API
    # ------------------------------------------------------------------

    def get_frontier_momentum(self) -> dict | None:
        """Get the latest momentum (height, hash, timestamp).

        Returns dict with keys: height, hash, timestamp, etc.
        Returns None if node is unavailable.
        """
        return self._call("ledger.getFrontierMomentum")

    def get_account_info(self, address: str) -> dict | None:
        """Get account info including balance and nonce.

        Args:
            address: Zenon address string (z1q...).

        Returns dict with balanceInfoMap, or None if unavailable.
        """
        return self._call("ledger.getAccountInfoByAddress", [address])

    # ------------------------------------------------------------------
    # Embedded: Pillar
    # ------------------------------------------------------------------

    def get_all_pillars(self, page: int = 0, count: int = 1000) -> list | None:
        """Get all registered pillars.

        Returns list of pillar info dicts (name, weight, delegations, etc.),
        or None if unavailable.
        """
        result = self._call("embedded.pillar.getAll", [page, count])
        if result and "list" in result:
            return result["list"]
        return result

    # ------------------------------------------------------------------
    # Embedded: Sentinel
    # ------------------------------------------------------------------

    def get_all_sentinels(self, page: int = 0, count: int = 1000) -> list | None:
        """Get all registered sentinels.

        Returns list of sentinel info dicts, or None if unavailable.
        """
        result = self._call("embedded.sentinel.getAllActive", [page, count])
        if result and "list" in result:
            return result["list"]
        return result

    # ------------------------------------------------------------------
    # Embedded: Stake
    # ------------------------------------------------------------------

    def get_staking_info(self) -> dict | None:
        """Get network-wide staking info (total staked, APR, etc.).

        Uses the stats.networkInfo method which includes staking data.
        Returns None if unavailable.
        """
        return self._call("stats.networkInfo")

    # ------------------------------------------------------------------
    # Embedded: Plasma
    # ------------------------------------------------------------------

    def get_plasma_info(self, address: str) -> dict | None:
        """Get plasma info for an address.

        Args:
            address: Zenon address string (z1q...).

        Returns dict with currentPlasma, maxPlasma, qsrAmount, etc.
        Returns None if unavailable.
        """
        return self._call("embedded.plasma.get", [address])

    # ------------------------------------------------------------------
    # Embedded: Accelerator-Z
    # ------------------------------------------------------------------

    def get_az_treasury(self) -> dict | None:
        """Get Accelerator-Z treasury info (balance, funding data).

        Returns dict with znnAmount, qsrAmount, etc.
        Returns None if unavailable.
        """
        return self._call("embedded.accelerator.getFrontierMomentum")

    # ------------------------------------------------------------------
    # Generic call for domains that need custom RPC
    # ------------------------------------------------------------------

    def call(self, method: str, params: list | None = None) -> Any | None:
        """Generic RPC call for domains needing methods not wrapped above.

        Args:
            method: Full RPC method name (e.g. "embedded.token.getAll").
            params: List of positional parameters.

        Returns the result value, or None if unavailable.
        """
        return self._call(method, params)


def get_client() -> Optional["ZenonNodeClient"]:
    """Return ZenonNodeClient if ZENON_NODE_RPC is configured, None otherwise.

    Convenience for engines that want to try the local node before
    falling back to the zenonhub REST API.  Returns None when the
    websocket-client library is missing or the node is unreachable.
    """
    if not HAS_WEBSOCKET:
        return None
    if not os.environ.get("ZENON_NODE_RPC"):
        return None
    client = ZenonNodeClient()
    if client.is_connected():
        return client
    return None
