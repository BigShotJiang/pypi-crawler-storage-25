# SPDX-License-Identifier: MIT
"""
File Extractors — Extract text from non-code file formats.

Enables Nebula to learn from images (OCR), PDFs, Office docs, and other
formats commonly found in project repos alongside code.

Supported formats:
  - Images (.png, .jpg, .jpeg, .gif, .bmp, .tiff) → OCR via pytesseract
  - PDFs (.pdf) → text extraction via PyPDF2/pdfplumber
  - Office docs (.docx, .xlsx, .pptx) → text via python-docx/openpyxl
  - Rich text (.rtf) → basic text extraction
  - CSV/TSV (.csv, .tsv) → read as text

All extractors are optional — if a library isn't installed, that format
is silently skipped. Core Nebula never fails because of a missing
optional dependency.

Install extras for full format support:
    pip install pytesseract Pillow PyPDF2 python-docx openpyxl
"""

import logging
from pathlib import Path

from core.http import opsec_request, opsec_urlopen  # noqa: F401  OPSEC-safe HTTP wrapper

logger = logging.getLogger(__name__)

# Extensions this module can handle
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".webp"}
PDF_EXTENSIONS = {".pdf"}
OFFICE_EXTENSIONS = {".docx", ".xlsx", ".pptx"}
RICH_TEXT_EXTENSIONS = {".rtf"}
DATA_EXTENSIONS = {".csv", ".tsv"}

ALL_EXTRACTABLE = (
    IMAGE_EXTENSIONS | PDF_EXTENSIONS | OFFICE_EXTENSIONS | RICH_TEXT_EXTENSIONS | DATA_EXTENSIONS
)


def can_extract(file_path: str) -> bool:
    """Check if we can extract text from this file type."""
    return Path(file_path).suffix.lower() in ALL_EXTRACTABLE


def extract_text(file_path: str) -> str | None:
    """Extract text content from a non-code file.

    Returns extracted text or None if extraction fails/unsupported.
    """
    path = Path(file_path)
    ext = path.suffix.lower()

    if not path.exists():
        return None

    try:
        if ext in IMAGE_EXTENSIONS:
            return _extract_image(path)
        elif ext in PDF_EXTENSIONS:
            return _extract_pdf(path)
        elif ext == ".docx":
            return _extract_docx(path)
        elif ext == ".xlsx":
            return _extract_xlsx(path)
        elif ext == ".pptx":
            return _extract_pptx(path)
        elif ext in DATA_EXTENSIONS:
            return _extract_csv(path)
        elif ext == ".rtf":
            return _extract_rtf(path)
    except Exception as exc:
        logger.debug("Failed to extract text from %s: %s", file_path, exc)

    return None


def _extract_image(path: Path) -> str | None:
    """Extract text/understanding from an image.

    Priority:
      1. Grok vision API (best quality, understands diagrams + text)
      2. pytesseract OCR (local, free, text-only)
    """
    # Try Grok vision first (understands diagrams, architecture, not just text)
    try:
        result = _extract_image_via_llm(path)
        if result:
            return result
    except Exception as exc:
        logger.debug("LLM vision failed for %s: %s", path, exc)

    # Fallback: local OCR
    try:
        import pytesseract
        from PIL import Image

        img = Image.open(path)
        text = pytesseract.image_to_string(img)
        return text.strip() if text.strip() else None
    except ImportError:
        logger.debug("pytesseract/Pillow not installed — skipping image OCR")
        return None


def _extract_image_via_llm(path: Path) -> str | None:
    """Use xAI Grok vision to understand an image.

    Adapted from a reference vision-OCR extractor pattern:
    Image → base64 → xAI vision API → text.

    Uses grok-4-1-fast-reasoning for vision (cheapest reasoning tier).
    Understands diagrams, architecture, screenshots — not just OCR.
    """
    import base64
    import json
    import os
    import urllib.request

    api_key = os.environ.get("XAI_API_KEY")
    if not api_key:
        return None

    image_data = path.read_bytes()
    if len(image_data) > 5 * 1024 * 1024:
        return None

    b64 = base64.b64encode(image_data).decode("utf-8")

    ext = path.suffix.lower()
    media_types = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".bmp": "image/bmp",
    }
    media_type = media_types.get(ext, "image/png")

    # Reference vision pattern: developer role for system prompt, user role with image
    body = {
        "model": "grok-4-1-fast-reasoning",
        "messages": [
            {
                "role": "developer",
                "content": (
                    "You are a document analysis specialist. Transcribe ALL text "
                    "from this image verbatim. For diagrams, flowcharts, or architecture "
                    "drawings, describe the components and their relationships. "
                    "For tables, use markdown table format. Note any images or "
                    "non-text elements as [IMAGE: description]."
                ),
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Transcribe and analyze this image completely."},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:{media_type};base64,{b64}",
                        },
                    },
                ],
            },
        ],
        "max_tokens": 4000,
    }

    req = urllib.request.Request(
        "https://api.x.ai/v1/chat/completions",
        data=json.dumps(body).encode(),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
    )
    resp = opsec_urlopen(req, timeout=60)
    data = json.loads(resp.read())
    text = data["choices"][0]["message"]["content"]
    return text.strip() if text.strip() else None


def extract_pdf_via_vision(pdf_path: str, max_pages: int = 50) -> str | None:
    """Extract text from PDF using page-by-page vision OCR.

    Reference vision pattern: PDF → 300 DPI images → xAI vision per page.
    Falls back to PyPDF2 text extraction if pdf2image not available.

    Args:
        pdf_path: Path to PDF file
        max_pages: Maximum pages to process (default: 50)

    Returns:
        Concatenated text with page separators, or None if extraction fails.
    """
    import os

    if not os.environ.get("XAI_API_KEY"):
        return _extract_pdf(Path(pdf_path))

    try:
        from pdf2image import convert_from_path
    except ImportError:
        logger.debug("pdf2image not installed — falling back to text extraction")
        return _extract_pdf(Path(pdf_path))

    import base64
    import io
    import json
    import urllib.request

    api_key = os.environ.get("XAI_API_KEY")
    pages = []

    try:
        images = convert_from_path(pdf_path, dpi=300, last_page=max_pages)
    except Exception as exc:
        logger.debug("pdf2image conversion failed: %s", exc)
        return _extract_pdf(Path(pdf_path))

    for i, img in enumerate(images, 1):
        try:
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

            body = {
                "model": "grok-4-1-fast-reasoning",
                "messages": [
                    {
                        "role": "developer",
                        "content": (
                            "You are a document OCR specialist. Transcribe this page "
                            "completely and verbatim. Preserve layout, tables, headers, "
                            "and all text exactly as it appears."
                        ),
                    },
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": f"Page {i} of {len(images)}. Transcribe verbatim.",
                            },
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/png;base64,{b64}",
                                },
                            },
                        ],
                    },
                ],
                "max_tokens": 4000,
            }

            req = urllib.request.Request(
                "https://api.x.ai/v1/chat/completions",
                data=json.dumps(body).encode(),
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {api_key}",
                },
            )
            resp = opsec_urlopen(req, timeout=60)
            data = json.loads(resp.read())
            text = data["choices"][0]["message"]["content"]
            pages.append(f"--- Page {i} ---\n{text.strip()}")
        except Exception as exc:
            pages.append(f"--- Page {i} (OCR error: {exc}) ---")

    return "\n\n".join(pages) if pages else None


def _extract_pdf(path: Path) -> str | None:
    """Extract text from a PDF.

    Priority: vision OCR (best for scanned docs) → PyPDF2 → pdfplumber.
    """
    # Try vision OCR for scanned/image PDFs (reference pattern)
    try:
        result = extract_pdf_via_vision(str(path))
        if result:
            return result
    except Exception as exc:
        logger.debug("Vision PDF extraction failed, trying text fallback: %s", exc)

    # Fallback: text extraction (works for text-based PDFs)
    try:
        from PyPDF2 import PdfReader

        reader = PdfReader(str(path))
        pages = []
        for page in reader.pages[:50]:  # cap at 50 pages
            text = page.extract_text()
            if text:
                pages.append(text)
        return "\n\n".join(pages) if pages else None
    except ImportError:
        pass

    try:
        import pdfplumber

        with pdfplumber.open(str(path)) as pdf:
            pages = []
            for page in pdf.pages[:50]:
                text = page.extract_text()
                if text:
                    pages.append(text)
            return "\n\n".join(pages) if pages else None
    except ImportError:
        logger.debug("PyPDF2/pdfplumber not installed — skipping PDF extraction")
        return None


def _extract_docx(path: Path) -> str | None:
    """Extract text from a Word document."""
    try:
        from docx import Document

        doc = Document(str(path))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        return "\n".join(paragraphs) if paragraphs else None
    except ImportError:
        logger.debug("python-docx not installed — skipping .docx extraction")
        return None


def _extract_xlsx(path: Path) -> str | None:
    """Extract text from an Excel spreadsheet."""
    try:
        from openpyxl import load_workbook

        wb = load_workbook(str(path), read_only=True, data_only=True)
        lines = []
        for sheet in wb.sheetnames[:5]:  # cap at 5 sheets
            ws = wb[sheet]
            lines.append(f"[Sheet: {sheet}]")
            for row in ws.iter_rows(max_row=200, values_only=True):
                cells = [str(c) for c in row if c is not None]
                if cells:
                    lines.append("\t".join(cells))
        wb.close()
        return "\n".join(lines) if lines else None
    except ImportError:
        logger.debug("openpyxl not installed — skipping .xlsx extraction")
        return None


def _extract_pptx(path: Path) -> str | None:
    """Extract text from a PowerPoint presentation."""
    try:
        from pptx import Presentation

        prs = Presentation(str(path))
        texts = []
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    texts.append(shape.text)
        return "\n\n".join(texts) if texts else None
    except ImportError:
        logger.debug("python-pptx not installed — skipping .pptx extraction")
        return None


def _extract_csv(path: Path) -> str | None:
    """Read CSV/TSV as plain text (capped at 200 lines)."""
    try:
        text = path.read_text(errors="replace")
        lines = text.splitlines()[:200]
        return "\n".join(lines) if lines else None
    except Exception:
        return None


def _extract_rtf(path: Path) -> str | None:
    """Basic RTF text extraction — strip RTF control words."""
    try:
        raw = path.read_text(errors="replace")
        # Very basic RTF stripping — remove {\rtf..} control sequences
        import re

        text = re.sub(r"\\[a-z]+\d*\s?", "", raw)
        text = re.sub(r"[{}]", "", text)
        return text.strip() if text.strip() else None
    except Exception:
        return None
