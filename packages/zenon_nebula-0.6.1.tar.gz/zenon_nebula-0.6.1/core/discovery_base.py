# SPDX-License-Identifier: MIT
"""
DiscoveryTemplate -- Abstract base class for all discovery templates.

Generalized from marketing's DiscoveryTemplate. Every template:
- Declares its tier, analysis_type, domain, and API dependencies
- Runs with a FingerprintedSession for full provenance tracking
- Persists results with fingerprint hashes for integrity verification
- Supports multi-domain operation via the domain field
"""

import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import ClassVar

from core.api_fingerprint import FingerprintedSession
from core.persist_to_db import persist_finding

logger = logging.getLogger(__name__)


@dataclass
class TemplateResult:
    """Result container returned by every template execution."""

    template_name: str
    analysis_type: str
    domain: str
    results: dict
    summary: str = ""
    fingerprints: list = field(default_factory=list)
    persisted_id: int | None = None
    elapsed_seconds: float = 0.0
    provenance: str = "hypothesis"


class DiscoveryTemplate(ABC):
    """Base class for all discovery templates across all domains.

    Subclasses must define:
        tier            : int   -- 1 (basic API) to 5 (generative)
        analysis_type   : str   -- DB key (e.g. "blockstream_block", "code_review")
        domain          : str   -- "marketing", "investigation", "intelligence", etc.
        required_apis   : list  -- API dependencies (e.g. ["github", "etherscan"])

    Subclasses must implement:
        run(params, session) -> dict
    """

    tier: ClassVar[int]
    analysis_type: ClassVar[str]
    domain: ClassVar[str]
    required_apis: ClassVar[list[str]]
    max_runtime_seconds: ClassVar[int] = 300

    # -- Abstract interface --

    @abstractmethod
    def run(self, params: dict, session: FingerprintedSession) -> dict:
        """Core logic -- must return results dict.

        All HTTP calls should go through *session* so they are fingerprinted.
        """

    # -- Optional overrides --

    def make_summary(self, results: dict) -> str:
        """Human-readable summary of results."""
        if not results:
            return "No results produced."
        keys = list(results.keys())
        return f"Produced {len(keys)} result fields: {', '.join(keys[:8])}"

    def validate_params(self, params: dict) -> list[str]:
        """Return list of validation errors, empty if valid."""
        return []

    # -- Main API --

    def execute(
        self,
        params: dict,
        db_path: str = "",
        run_id: str | None = None,
        parent_finding_id: int | None = None,
    ) -> TemplateResult:
        """Main API -- handles session creation, validation, persistence.

        Args:
            params:              Template-specific parameters.
            db_path:             Path to the SQLite database.
            run_id:              Run ID for traceability.
            parent_finding_id:   Parent finding for lineage.

        Returns:
            TemplateResult with results, fingerprints, and persistence metadata.
        """
        template_name = self.__class__.__name__

        # Import here to avoid circular dependency
        from pathlib import Path

        engine_root = Path(__file__).resolve().parents[1]
        effective_db = db_path or str(engine_root / "data" / "engine.db")

        # Validate
        errors = self.validate_params(params)
        if errors:
            logger.warning(
                "Validation failed for %s: %s",
                template_name,
                errors,
            )
            return TemplateResult(
                template_name=template_name,
                analysis_type=self.analysis_type,
                domain=self.domain,
                results={"validation_errors": errors},
                summary=f"Validation failed: {'; '.join(errors)}",
            )

        # Run with fingerprinted session
        session = FingerprintedSession(
            engine_name=template_name,
            domain=self.domain,
        )
        start = time.monotonic()

        try:
            results = self.run(params, session)
        except Exception as exc:
            elapsed = time.monotonic() - start
            logger.exception(
                "Template %s failed after %.1fs",
                template_name,
                elapsed,
            )
            return TemplateResult(
                template_name=template_name,
                analysis_type=self.analysis_type,
                domain=self.domain,
                results={"error": str(exc)},
                summary=f"Execution error: {exc}",
                fingerprints=session.get_fingerprints(),
                elapsed_seconds=round(elapsed, 2),
            )

        elapsed = time.monotonic() - start
        fingerprints = session.get_fingerprints()
        summary = self.make_summary(results)

        # Determine provenance from fingerprints
        from core.api_fingerprint import classify_provenance

        provenance = classify_provenance(fingerprints)

        # Persist to database
        persisted_id = None
        try:
            persisted_id = persist_finding(
                db_path=effective_db,
                domain=self.domain,
                engine=template_name,
                evidence_type=self.analysis_type,
                finding=summary,
                confidence=results.get("confidence", 0.5),
                raw_data=results,
                fingerprints=fingerprints,
                run_id=run_id,
                parent_finding_id=parent_finding_id,
            )
        except Exception as exc:
            logger.error(
                "Failed to persist finding for %s: %s",
                template_name,
                exc,
            )

        logger.info(
            "Template %s completed in %.1fs -- %d API calls -- provenance=%s -- persisted_id=%s",
            template_name,
            elapsed,
            len(fingerprints),
            provenance,
            persisted_id,
        )

        return TemplateResult(
            template_name=template_name,
            analysis_type=self.analysis_type,
            domain=self.domain,
            results=results,
            summary=summary,
            fingerprints=fingerprints,
            persisted_id=persisted_id,
            elapsed_seconds=round(elapsed, 2),
            provenance=provenance,
        )
