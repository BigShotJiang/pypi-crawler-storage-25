# SPDX-License-Identifier: MIT
"""
Knowledge Graph -- Cross-domain visualization for the Nebula.

Nodes: evidence items, hypotheses, aspirations, specs, PRs (all tagged by domain)
Edges: supports, contradicts, depends_on, implements, blocks, same_engine, temporal
Clusters: by domain, by engine, by hypothesis

Export formats:
  - Mermaid diagram (for markdown/GitHub rendering)
  - JSON (for web visualization)
  - Summary text (for LLM context injection)
"""

import contextlib
import json
import logging
import sqlite3
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
GRAPH_JSON_PATH = ENGINE_ROOT / "data" / "knowledge_graph.json"
GRAPH_MERMAID_PATH = ENGINE_ROOT / "data" / "knowledge_graph.md"

TEMPORAL_PROXIMITY_HOURS = 48


@dataclass
class GraphNode:
    """A node in the knowledge graph."""

    id: str
    label: str
    node_type: str  # evidence, hypothesis, aspiration, collision
    domain: str = ""
    engine: str = ""
    confidence: float = 0.0
    created_at: str = ""
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Serialize graph node to a plain dict."""
        return {
            "id": self.id,
            "label": self.label,
            "type": self.node_type,
            "domain": self.domain,
            "engine": self.engine,
            "confidence": self.confidence,
            "created_at": self.created_at,
            "metadata": self.metadata,
        }


@dataclass
class GraphEdge:
    """An edge in the knowledge graph."""

    source: str
    target: str
    edge_type: str  # supports, contradicts, depends_on, implements, blocks, same_engine, temporal
    weight: float = 1.0
    label: str = ""

    def to_dict(self) -> dict:
        """Serialize graph edge to a plain dict."""
        return {
            "source": self.source,
            "target": self.target,
            "type": self.edge_type,
            "weight": self.weight,
            "label": self.label,
        }


@dataclass
class KnowledgeGraphData:
    """The full knowledge graph."""

    nodes: list[GraphNode] = field(default_factory=list)
    edges: list[GraphEdge] = field(default_factory=list)
    clusters: dict = field(default_factory=dict)
    stats: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Serialize the full knowledge graph to a dict."""
        return {
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
            "clusters": self.clusters,
            "stats": self.stats,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }


class KnowledgeGraph:
    """Cross-domain knowledge graph builder and exporter."""

    def __init__(self, db_path: str = DEFAULT_DB):
        self.db_path = db_path
        self._graph: KnowledgeGraphData | None = None

    # ------------------------------------------------------------------
    # Data loading
    # ------------------------------------------------------------------

    def _load_evidence(self) -> list[GraphNode]:
        nodes = []
        try:
            conn = connect(self.db_path)
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT id, domain, engine, evidence_type, finding, "
                "confidence, supports_hypothesis, "
                "contradicts_hypothesis, timestamp "
                "FROM evidence ORDER BY timestamp DESC"
            ).fetchall()
            conn.close()

            for row in rows:
                nodes.append(
                    GraphNode(
                        id=f"e_{row['id']}",
                        label=(row["finding"] or "")[:80] or f"Evidence #{row['id']}",
                        node_type="evidence",
                        domain=row["domain"] or "",
                        engine=row["engine"] or "",
                        confidence=row["confidence"] or 0.0,
                        created_at=row["timestamp"] or "",
                        metadata={
                            "evidence_type": row["evidence_type"],
                            "supports_hypothesis": row["supports_hypothesis"],
                            "contradicts_hypothesis": row["contradicts_hypothesis"],
                            "db_id": row["id"],
                        },
                    )
                )
        except sqlite3.Error as exc:
            logger.warning("Could not load evidence: %s", exc)

        return nodes

    def _load_hypotheses(self) -> list[GraphNode]:
        nodes = []
        try:
            conn = connect(self.db_path)
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT id, domain, title, confidence, status, "
                "last_updated FROM hypotheses ORDER BY confidence DESC"
            ).fetchall()
            conn.close()

            for row in rows:
                nodes.append(
                    GraphNode(
                        id=f"h_{row['id']}",
                        label=row["title"] or f"Hypothesis {row['id']}",
                        node_type="hypothesis",
                        domain=row["domain"] or "",
                        confidence=row["confidence"] or 0.0,
                        created_at=row["last_updated"] or "",
                        metadata={
                            "status": row["status"],
                        },
                    )
                )
        except sqlite3.Error as exc:
            logger.warning("Could not load hypotheses: %s", exc)

        return nodes

    def _load_collisions(self) -> list[GraphNode]:
        nodes = []
        try:
            conn = connect(self.db_path)
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT id, collision_type, title, confidence, "
                "domains_involved, engines_involved, timestamp "
                "FROM collisions WHERE resolved = 0 "
                "ORDER BY confidence DESC"
            ).fetchall()
            conn.close()

            for row in rows:
                domains = []
                with contextlib.suppress(json.JSONDecodeError):
                    domains = json.loads(row["domains_involved"] or "[]")

                nodes.append(
                    GraphNode(
                        id=f"c_{row['id']}",
                        label=row["title"] or f"Collision {row['id']}",
                        node_type="collision",
                        domain=",".join(domains) if domains else "",
                        confidence=row["confidence"] or 0.0,
                        created_at=row["timestamp"] or "",
                        metadata={
                            "collision_type": row["collision_type"],
                        },
                    )
                )
        except sqlite3.Error as exc:
            logger.warning("Could not load collisions: %s", exc)

        return nodes

    # ------------------------------------------------------------------
    # Edge building
    # ------------------------------------------------------------------

    def _build_hypothesis_edges(
        self,
        evidence_nodes: list[GraphNode],
        hypothesis_nodes: list[GraphNode],
    ) -> list[GraphEdge]:
        edges = []
        hyp_ids = {n.id for n in hypothesis_nodes}

        for node in evidence_nodes:
            supports = node.metadata.get("supports_hypothesis", "")
            contradicts = node.metadata.get("contradicts_hypothesis", "")

            if supports:
                target = f"h_{supports}"
                if target in hyp_ids:
                    edges.append(
                        GraphEdge(
                            source=node.id,
                            target=target,
                            edge_type="supports",
                            weight=node.confidence,
                            label="supports",
                        )
                    )

            if contradicts:
                target = f"h_{contradicts}"
                if target in hyp_ids:
                    edges.append(
                        GraphEdge(
                            source=node.id,
                            target=target,
                            edge_type="contradicts",
                            weight=node.confidence,
                            label="contradicts",
                        )
                    )

        return edges

    def _build_engine_edges(self, evidence_nodes: list[GraphNode]) -> list[GraphEdge]:
        edges = []
        by_engine: dict[str, list[str]] = defaultdict(list)

        for node in evidence_nodes:
            if node.engine:
                by_engine[node.engine].append(node.id)

        for engine, node_ids in by_engine.items():
            ids = node_ids[:20]
            for i in range(len(ids)):
                for j in range(i + 1, min(i + 3, len(ids))):
                    edges.append(
                        GraphEdge(
                            source=ids[i],
                            target=ids[j],
                            edge_type="same_engine",
                            weight=0.3,
                            label=engine,
                        )
                    )

        return edges

    def _build_cross_domain_edges(self, evidence_nodes: list[GraphNode]) -> list[GraphEdge]:
        """Build edges between evidence from different domains that share
        the same hypothesis."""
        edges = []
        by_hypothesis: dict[str, list[GraphNode]] = defaultdict(list)

        for node in evidence_nodes:
            hyp = node.metadata.get("supports_hypothesis")
            if hyp:
                by_hypothesis[hyp].append(node)

        for hyp_id, nodes in by_hypothesis.items():
            domains = {n.domain for n in nodes}
            if len(domains) >= 2:
                # Connect evidence from different domains
                for i in range(len(nodes)):
                    for j in range(i + 1, len(nodes)):
                        if nodes[i].domain != nodes[j].domain:
                            edges.append(
                                GraphEdge(
                                    source=nodes[i].id,
                                    target=nodes[j].id,
                                    edge_type="cross_domain",
                                    weight=0.5,
                                    label=f"both support {hyp_id}",
                                )
                            )

        return edges[:100]  # Cap to avoid explosion

    # ------------------------------------------------------------------
    # Build
    # ------------------------------------------------------------------

    def build(self) -> KnowledgeGraphData:
        """Build the complete knowledge graph."""
        logger.info("Building knowledge graph...")

        evidence = self._load_evidence()
        hypotheses = self._load_hypotheses()
        collisions = self._load_collisions()

        all_nodes = evidence + hypotheses + collisions

        all_edges = []
        all_edges.extend(self._build_hypothesis_edges(evidence, hypotheses))
        all_edges.extend(self._build_engine_edges(evidence))
        all_edges.extend(self._build_cross_domain_edges(evidence))

        graph = KnowledgeGraphData(nodes=all_nodes, edges=all_edges)

        # Clusters
        clusters = {
            "by_domain": defaultdict(list),
            "by_engine": defaultdict(list),
            "by_type": defaultdict(list),
        }
        for node in graph.nodes:
            clusters["by_type"][node.node_type].append(node.id)
            if node.domain:
                for d in node.domain.split(","):
                    clusters["by_domain"][d.strip()].append(node.id)
            if node.engine:
                clusters["by_engine"][node.engine].append(node.id)

        graph.clusters = {k: dict(v) for k, v in clusters.items()}

        # Stats
        graph.stats = {
            "total_nodes": len(all_nodes),
            "evidence_count": len(evidence),
            "hypothesis_count": len(hypotheses),
            "collision_count": len(collisions),
            "total_edges": len(all_edges),
            "supports_edges": sum(1 for e in all_edges if e.edge_type == "supports"),
            "contradicts_edges": sum(1 for e in all_edges if e.edge_type == "contradicts"),
            "cross_domain_edges": sum(1 for e in all_edges if e.edge_type == "cross_domain"),
            "unique_domains": len(graph.clusters.get("by_domain", {})),
            "unique_engines": len(graph.clusters.get("by_engine", {})),
            "built_at": datetime.now(timezone.utc).isoformat(),
        }

        self._graph = graph
        logger.info(
            "Knowledge graph: %d nodes, %d edges, %d domains",
            graph.stats["total_nodes"],
            graph.stats["total_edges"],
            graph.stats["unique_domains"],
        )
        return graph

    # ------------------------------------------------------------------
    # Export: JSON
    # ------------------------------------------------------------------

    def export_json(self, output_path: str | None = None) -> str:
        """Export the knowledge graph as JSON to a file and return the JSON string."""
        if self._graph is None:
            self.build()

        data = self._graph.to_dict()
        json_str = json.dumps(data, indent=2, default=str)

        path = Path(output_path) if output_path else GRAPH_JSON_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json_str)

        return json_str

    # ------------------------------------------------------------------
    # Export: Mermaid
    # ------------------------------------------------------------------

    def export_mermaid(self, output_path: str | None = None) -> str:
        """Export the knowledge graph as a Mermaid diagram."""
        if self._graph is None:
            self.build()

        lines = ["```mermaid", "graph TD"]
        lines.append("    classDef evidence fill:#4CAF50,stroke:#2E7D32,color:#fff;")
        lines.append("    classDef hypothesis fill:#2196F3,stroke:#1565C0,color:#fff;")
        lines.append("    classDef collision fill:#F44336,stroke:#C62828,color:#fff;")
        lines.append("")

        node_ids_used = set()

        # Hypotheses
        for node in self._graph.nodes:
            if node.node_type == "hypothesis":
                safe = self._mermaid_safe(node.label[:60])
                lines.append(f'    {node.id}["{safe}"]')
                node_ids_used.add(node.id)

        # Collisions
        for node in self._graph.nodes:
            if node.node_type == "collision":
                safe = self._mermaid_safe(node.label[:60])
                lines.append(f"    {node.id}{{{{{safe}}}}}")
                node_ids_used.add(node.id)

        # Top evidence
        evidence = [n for n in self._graph.nodes if n.node_type == "evidence"]
        evidence.sort(key=lambda n: n.confidence, reverse=True)
        for node in evidence[:30]:
            safe = self._mermaid_safe(node.label[:50])
            domain_tag = f" [{node.domain}]" if node.domain else ""
            lines.append(f'    {node.id}[/"{safe}{domain_tag}"\\]')
            node_ids_used.add(node.id)

        # Edges
        lines.append("")
        arrows = {
            "supports": "-->|supports|",
            "contradicts": "-.->|contradicts|",
            "same_engine": "---",
            "cross_domain": "==>",
        }
        for edge in self._graph.edges:
            if edge.source in node_ids_used and edge.target in node_ids_used:
                arrow = arrows.get(edge.edge_type, "-->")
                lines.append(f"    {edge.source} {arrow} {edge.target}")

        # Class assignments
        lines.append("")
        for node in self._graph.nodes:
            if node.id in node_ids_used:
                lines.append(f"    class {node.id} {node.node_type};")

        lines.append("```")
        mermaid_str = "\n".join(lines)

        path = Path(output_path) if output_path else GRAPH_MERMAID_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"# Nebula Knowledge Graph\n\n{mermaid_str}\n")

        return mermaid_str

    # ------------------------------------------------------------------
    # Export: Summary text
    # ------------------------------------------------------------------

    def export_summary(self) -> str:
        """Return a concise text summary of the knowledge graph."""
        if self._graph is None:
            self.build()

        s = self._graph.stats
        lines = [
            f"Knowledge Graph: {s['total_nodes']} nodes, "
            f"{s['total_edges']} edges, "
            f"{s['unique_domains']} domains.",
            f"Evidence: {s['evidence_count']}. "
            f"Hypotheses: {s['hypothesis_count']}. "
            f"Collisions: {s['collision_count']}.",
            "",
            "Hypotheses:",
        ]

        for node in self._graph.nodes:
            if node.node_type == "hypothesis":
                supports = sum(
                    1
                    for e in self._graph.edges
                    if e.target == node.id and e.edge_type == "supports"
                )
                lines.append(
                    f"- [{node.domain}] {node.label} "
                    f"(confidence={node.confidence:.2f}, "
                    f"{supports} supporting)"
                )

        lines.append("")
        lines.append("Top evidence:")
        evidence = sorted(
            [n for n in self._graph.nodes if n.node_type == "evidence"],
            key=lambda n: n.confidence,
            reverse=True,
        )
        for node in evidence[:10]:
            lines.append(f"- [{node.domain}:{node.engine}] ({node.confidence:.2f}) {node.label}")

        # Cross-domain connections
        cross = [e for e in self._graph.edges if e.edge_type == "cross_domain"]
        if cross:
            lines.append(f"\nCross-domain connections: {len(cross)}")

        return "\n".join(lines)

    @staticmethod
    def _mermaid_safe(text: str) -> str:
        return (
            text.replace('"', "'")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("&", "&amp;")
            .replace("\n", " ")
        )
