# SPDX-License-Identifier: MIT
"""
Unified Director -- Cross-domain strategic analysis for the Nebula.

**Agent pattern:** *orchestrator-workers* (Anthropic "Building Effective
Agents" taxonomy). The Director is the orchestrator: it surveys the full
evidence landscape, decides what should happen next, and dispatches
concrete actions to domain engines, which act as the workers. The
Director never executes an engine directly; it produces a prioritized
action list consumed by ``scripts/autonomous.py`` which in turn invokes
the engines.

Reads the evidence landscape from all registered domains, queries hypothesis
status, aspiration progress, and feedback bus messages. Calls
``core.llm_provider.call_llm`` to identify gaps, propose cross-domain
aspirations, and return a prioritized action list.
"""

import json
import logging
import sqlite3
import uuid
from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persistence import connect


def _get_strategic_model() -> str:
    """Get the best available model for strategic reasoning. No hardcoded models."""
    try:
        from core.model_router import get_model

        return get_model("strategic_synthesis")
    except Exception as exc:
        logger.debug("Model router unavailable, using fallback: %s", exc)
        return "grok-4.20-0309-reasoning"  # Last resort fallback


logger = logging.getLogger(__name__)


def _extract_json(text: str) -> dict:
    """Best-effort extraction of a JSON object from LLM output."""
    start = text.find("{")
    end = text.rfind("}") + 1
    if start >= 0 and end > start:
        try:
            return json.loads(text[start:end])
        except json.JSONDecodeError:
            pass
    return {}


ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Aspiration tool schema for structured output
ASPIRATION_TOOL = {
    "name": "propose_aspirations",
    "description": "Propose a prioritized list of cross-domain aspirations.",
    "input_schema": {
        "type": "object",
        "properties": {
            "aspirations": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string"},
                        "description": {"type": "string"},
                        "target_domains": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                        "priority": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 10,
                        },
                        "target_hypothesis": {"type": "string"},
                        "recommended_engines": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                        "estimated_impact": {
                            "type": "string",
                            "enum": ["low", "medium", "high", "breakthrough"],
                        },
                        "reasoning": {"type": "string"},
                    },
                    "required": [
                        "title",
                        "description",
                        "target_domains",
                        "priority",
                        "reasoning",
                    ],
                },
            },
        },
        "required": ["aspirations"],
    },
}


class Aspiration:
    """A prioritized cross-domain aspiration proposed by the director."""

    def __init__(
        self,
        title: str,
        description: str,
        target_domains: list[str],
        priority: int,
        reasoning: str,
        target_hypothesis: str | None = None,
        recommended_engines: list[str] | None = None,
        estimated_impact: str = "medium",
        id: str | None = None,
        mission_alignment: float = 0.0,
        pillar_scores: dict[str, float] | None = None,
    ):
        self.id = id or f"asp_{uuid.uuid4().hex[:8]}"
        self.title = title
        self.description = description
        self.target_domains = target_domains
        self.priority = priority
        self.reasoning = reasoning
        self.target_hypothesis = target_hypothesis
        self.recommended_engines = recommended_engines or []
        self.estimated_impact = estimated_impact
        self.mission_alignment = mission_alignment
        self.pillar_scores = pillar_scores or {}

    @property
    def ranked_priority(self) -> float:
        """Return priority boosted by mission alignment.

        LLM-supplied priority sits in ``[0, 10]``. Mission alignment in
        ``[0, 1]`` contributes up to +4 so a pillar-aligned aspiration
        can outrank a higher LLM priority that misses the mission.
        """
        return float(self.priority) + 4.0 * float(self.mission_alignment or 0.0)

    def to_dict(self) -> dict:
        """Serialize aspiration to a plain dict."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "target_domains": self.target_domains,
            "priority": self.priority,
            "reasoning": self.reasoning,
            "target_hypothesis": self.target_hypothesis,
            "recommended_engines": self.recommended_engines,
            "estimated_impact": self.estimated_impact,
            "mission_alignment": self.mission_alignment,
            "pillar_scores": self.pillar_scores,
            "ranked_priority": self.ranked_priority,
        }


class UnifiedDirector:
    """Cross-domain strategic director for the Nebula.

    Reads evidence landscape from ALL registered domains, identifies
    gaps and opportunities, and proposes cross-domain aspirations.
    """

    def __init__(
        self,
        db_path: str = DEFAULT_DB,
        llm_call: Callable | None = None,
    ):
        self.db_path = db_path
        self._llm_call = llm_call  # injectable for testing

        # Log which mission is active so it's visible in boot logs.
        # Derived mission (from TminusZ specs) is preferred; fallback
        # to the hardcoded interim pillars when none is stored.
        try:
            from core.mission import get_active_mission

            active = get_active_mission(db_path)
            logger.info(
                "UnifiedDirector active mission: name=%s provenance=%s pillars=%d",
                active.get("name", "unknown"),
                active.get("provenance", "unknown"),
                len(active.get("pillars", [])),
            )
        except Exception as exc:  # pragma: no cover - defensive
            logger.debug("Could not resolve active mission at boot: %s", exc)

    # ------------------------------------------------------------------
    # Evidence landscape
    # ------------------------------------------------------------------

    def get_evidence_landscape(self) -> dict:
        """Build a comprehensive picture of the current evidence state
        across ALL domains."""
        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            landscape: dict = {}

            # Evidence counts by domain
            try:
                rows = conn.execute(
                    "SELECT domain, count(*) as cnt, "
                    "avg(confidence) as avg_conf, "
                    "max(timestamp) as last_activity "
                    "FROM evidence GROUP BY domain"
                ).fetchall()
                landscape["evidence_by_domain"] = {
                    row["domain"]: {
                        "count": row["cnt"],
                        "avg_confidence": round(row["avg_conf"], 3) if row["avg_conf"] else 0,
                        "last_activity": row["last_activity"],
                    }
                    for row in rows
                }
            except sqlite3.OperationalError:
                landscape["evidence_by_domain"] = {}

            # Evidence counts by engine
            try:
                rows = conn.execute(
                    "SELECT engine, domain, count(*) as cnt, "
                    "avg(confidence) as avg_conf, "
                    "max(timestamp) as last_run "
                    "FROM evidence GROUP BY engine"
                ).fetchall()
                landscape["evidence_by_engine"] = {
                    row["engine"]: {
                        "domain": row["domain"],
                        "count": row["cnt"],
                        "avg_confidence": round(row["avg_conf"], 3) if row["avg_conf"] else 0,
                        "last_run": row["last_run"],
                    }
                    for row in rows
                }
            except sqlite3.OperationalError:
                landscape["evidence_by_engine"] = {}

            # Hypotheses across all domains
            try:
                hypotheses = [
                    dict(row)
                    for row in conn.execute(
                        "SELECT id, domain, title, confidence, status, "
                        "last_updated FROM hypotheses "
                        "ORDER BY confidence DESC"
                    ).fetchall()
                ]
                landscape["hypotheses"] = hypotheses
            except sqlite3.OperationalError:
                landscape["hypotheses"] = []

            # Recent findings (last 30 across all domains)
            try:
                recent = [
                    dict(row)
                    for row in conn.execute(
                        "SELECT domain, engine, evidence_type, finding, "
                        "confidence, timestamp "
                        "FROM evidence ORDER BY timestamp DESC LIMIT 30"
                    ).fetchall()
                ]
                landscape["recent_findings"] = recent
            except sqlite3.OperationalError:
                landscape["recent_findings"] = []

            # Actions summary (last 7 days)
            try:
                actions = [
                    dict(row)
                    for row in conn.execute(
                        "SELECT domain, module, action, count(*) as cnt, "
                        "sum(cost_usd) as total_cost "
                        "FROM actions_log "
                        "WHERE timestamp > datetime('now', '-7 days') "
                        "GROUP BY domain, module, action"
                    ).fetchall()
                ]
                landscape["recent_actions"] = actions
            except sqlite3.OperationalError:
                landscape["recent_actions"] = []

            # Feedback bus pending messages
            try:
                pending = conn.execute(
                    "SELECT type, count(*) as cnt FROM feedback_bus "
                    "WHERE acknowledged = 0 GROUP BY type"
                ).fetchall()
                landscape["pending_messages"] = {row["type"]: row["cnt"] for row in pending}
            except sqlite3.OperationalError:
                landscape["pending_messages"] = {}

            return landscape

        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Aspiration generation
    # ------------------------------------------------------------------

    def propose_aspirations(
        self,
        registry=None,
    ) -> list[Aspiration]:
        """Use Claude Opus to propose cross-domain aspirations.

        Reads all hypotheses, evidence, and performance metrics, then
        identifies gaps and opportunities across all domains.

        Args:
            registry: Optional DomainRegistry instance for richer context.

        Returns:
            List of Aspiration objects sorted by priority (descending).
        """
        landscape = self.get_evidence_landscape()

        # Enrich with domain info from registry
        domain_descriptions = {}
        inactive_engines = []
        if registry:
            for domain in registry.get_all_domains():
                domain_descriptions[domain.name()] = domain.get_description()
                for engine in domain.get_engines():
                    if engine.name not in landscape.get("evidence_by_engine", {}):
                        inactive_engines.append(f"{domain.name()}/{engine.name}")

        landscape["domain_descriptions"] = domain_descriptions
        landscape["inactive_engines"] = inactive_engines

        try:
            from core.mission import MISSION_LONG, MISSION_ONE_LINER, get_active_mission

            active = get_active_mission(self.db_path)
            active_pillars = active.get("pillars") or []
            if active_pillars and active.get("provenance") in ("stored", "synthesized"):
                # Derived mission from TminusZ specs — prefer it.
                pillar_lines = "\n".join(
                    f"  - {p.get('name', '?')} "
                    f"(priority {p.get('priority', 5)}): "
                    f"{p.get('description', '')}"
                    for p in active_pillars
                )
                mission_block = (
                    f"MISSION (non-negotiable, derived from Zenon specs): "
                    f"{active.get('one_liner') or active.get('name', '')}\n\n"
                    f"Grade every aspiration against these pillars:\n"
                    f"{pillar_lines}\n\n"
                )
            else:
                from core.mission import PILLARS

                pillar_lines = "\n".join(
                    f"  - {p.title} (weight {p.weight:.2f}): {p.description}" for p in PILLARS
                )
                mission_block = (
                    f"MISSION (non-negotiable, interim fallback pillars): "
                    f"{MISSION_ONE_LINER}\n\n"
                    f"{MISSION_LONG}\n"
                    f"Grade every aspiration against these pillars:\n{pillar_lines}\n\n"
                )
        except Exception:
            mission_block = ""

        system_prompt = (
            f"{mission_block}"
            "You are the Unified Director for Nebula -- a multi-domain "
            "autonomous intelligence platform for the Zenon Network.\n\n"
            "You analyze the evidence landscape across ALL domains and propose "
            "cross-domain aspirations that maximize mission progress.\n\n"
            "Focus areas:\n"
            "1. Which domains have stale or missing evidence\n"
            "2. Which hypotheses need more investigation\n"
            "3. Which engines have never run or have old data\n"
            "4. Where cross-domain convergence could strengthen findings\n"
            "5. Security gaps that need urgent attention\n"
            "6. Development coverage gaps\n"
            "7. Quality issues that affect multiple domains\n\n"
            "Return aspirations ordered by priority (10=highest). Be specific. "
            "Every aspiration should advance at least one mission pillar."
        )

        landscape_json = json.dumps(landscape, indent=2, default=str)

        user_prompt = (
            f"Current evidence landscape:\n\n"
            f"```json\n{landscape_json}\n```\n\n"
            f"Propose the top cross-domain aspirations.\n\n"
            f"Return a JSON object with key 'aspirations' containing a list of objects, "
            f"each with: title, description, target_domains (list), priority (1-10), "
            f"reasoning, target_hypothesis (optional), recommended_engines (list, optional), "
            f"estimated_impact (low/medium/high/breakthrough).\n\n"
            f"Return ONLY the JSON object."
        )

        if self._llm_call:
            raw_result = self._llm_call(system_prompt, user_prompt)
        else:
            from core.llm_provider import call_llm

            llm_result = call_llm(
                prompt=user_prompt,
                system=system_prompt,
                model=_get_strategic_model(),
                max_tokens=16000,
            )

            if isinstance(llm_result, dict):
                response_text = llm_result.get("text", "")
            else:
                response_text = str(llm_result) if llm_result else ""

            raw_result = response_text

        # Parse aspirations from JSON response
        raw_aspirations = []
        if isinstance(raw_result, list):
            raw_aspirations = raw_result
        elif isinstance(raw_result, dict):
            raw_aspirations = raw_result.get("aspirations", [])
        elif isinstance(raw_result, str):
            parsed = _extract_json(raw_result)
            raw_aspirations = parsed.get("aspirations", [])

        try:
            from core.mission import mission_alignment as _score_mission
        except Exception:
            _score_mission = None

        aspirations: list[Aspiration] = []
        for a in raw_aspirations:
            if not isinstance(a, dict):
                continue
            targets = a.get("target_domains", []) or []
            primary_domain = targets[0] if isinstance(targets, list) and targets else ""
            evidence_text = " ".join(
                filter(
                    None,
                    [a.get("title", ""), a.get("description", ""), a.get("reasoning", "")],
                )
            )
            if _score_mission is not None:
                scores = _score_mission(
                    domain=primary_domain,
                    evidence_text=evidence_text,
                )
                overall = float(scores.pop("overall", 0.0))
                pillar_scores = {k: float(v) for k, v in scores.items()}
            else:
                overall = 0.0
                pillar_scores = {}
            aspirations.append(
                Aspiration(
                    title=a.get("title", "untitled"),
                    description=a.get("description", ""),
                    target_domains=targets,
                    priority=int(a.get("priority", 5) or 5),
                    reasoning=a.get("reasoning", ""),
                    target_hypothesis=a.get("target_hypothesis"),
                    recommended_engines=a.get("recommended_engines", []),
                    estimated_impact=a.get("estimated_impact", "medium"),
                    mission_alignment=overall,
                    pillar_scores=pillar_scores,
                )
            )

        aspirations.sort(key=lambda a: -a.ranked_priority)

        # Persist action
        from core.persist_to_db import persist_action

        persist_action(
            db_path=self.db_path,
            domain="system",
            module="unified_director",
            action="propose_aspirations",
            result=f"{len(aspirations)} aspirations proposed",
        )

        logger.info(
            "Unified director proposed %d cross-domain aspirations",
            len(aspirations),
        )
        return aspirations

    # ------------------------------------------------------------------
    # Engine prioritization
    # ------------------------------------------------------------------

    def prioritize_engines(self, registry=None) -> list[dict]:
        """Rank which engines should run next based on evidence gaps.

        Returns list of {domain, engine, score, reason} dicts.
        """
        landscape = self.get_evidence_landscape()
        evidence = landscape.get("evidence_by_engine", {})
        now = datetime.now(timezone.utc)

        scored: list[dict] = []

        if registry:
            for domain in registry.get_all_domains():
                for engine_def in domain.get_engines():
                    score = 0.0
                    reasons = []

                    if engine_def.name not in evidence:
                        score += 10.0
                        reasons.append("never_run")
                    else:
                        info = evidence[engine_def.name]
                        # Staleness
                        if info.get("last_run"):
                            try:
                                last = datetime.fromisoformat(
                                    info["last_run"].replace("Z", "+00:00")
                                )
                                hours = (now - last).total_seconds() / 3600
                                staleness = min(hours / 12, 5.0)
                                score += staleness
                                if staleness > 2:
                                    reasons.append(f"stale_{int(hours)}h")
                            except (ValueError, TypeError):
                                score += 3.0
                                reasons.append("unparseable_timestamp")

                        # Low count
                        count = info.get("count", 0)
                        if count < 3:
                            score += 3.0
                            reasons.append("low_count")

                        # Low confidence
                        avg = info.get("avg_confidence", 0.5)
                        if avg < 0.4:
                            score += 2.0
                            reasons.append("low_confidence")

                    # Priority boost from engine definition
                    score += max(0, (10 - engine_def.priority))

                    scored.append(
                        {
                            "domain": domain.name(),
                            "engine": engine_def.name,
                            "score": round(score, 2),
                            "reason": ", ".join(reasons) or "routine",
                        }
                    )

        scored.sort(key=lambda x: -x["score"])
        logger.info(
            "Engine priorities: %s",
            [(s["engine"], s["score"]) for s in scored[:5]],
        )
        return scored

    # ------------------------------------------------------------------
    # Stall detection
    # ------------------------------------------------------------------

    def detect_stalled(self, hours: int = 72) -> list[dict]:
        """Identify hypotheses and engines with no progress in the window."""
        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()

        stalled: list[dict] = []

        try:
            # Stalled hypotheses
            try:
                hypotheses = conn.execute(
                    "SELECT id, domain, title, confidence, status "
                    "FROM hypotheses WHERE status = 'INVESTIGATING'"
                ).fetchall()

                for h in hypotheses:
                    recent = conn.execute(
                        "SELECT count(*) FROM evidence "
                        "WHERE (supports_hypothesis = ? "
                        "OR contradicts_hypothesis = ?) "
                        "AND timestamp > ?",
                        (h["id"], h["id"], cutoff),
                    ).fetchone()[0]

                    if recent == 0:
                        confidence = h["confidence"] or 0
                        if confidence > 0.8:
                            rec = "retire"
                        elif confidence < 0.2:
                            rec = "pivot"
                        else:
                            rec = "escalate"

                        stalled.append(
                            {
                                "type": "hypothesis",
                                "id": h["id"],
                                "domain": h["domain"],
                                "title": h["title"],
                                "confidence": confidence,
                                "recommendation": rec,
                            }
                        )
            except sqlite3.OperationalError:
                pass

            # Stalled engines
            try:
                engines = conn.execute(
                    "SELECT engine, domain, max(timestamp) as last_run, "
                    "count(*) as total FROM evidence GROUP BY engine"
                ).fetchall()

                for e in engines:
                    if e["last_run"] and e["last_run"] < cutoff:
                        stalled.append(
                            {
                                "type": "engine",
                                "id": e["engine"],
                                "domain": e["domain"],
                                "title": f"Engine: {e['engine']}",
                                "total_findings": e["total"],
                                "recommendation": "escalate",
                            }
                        )
            except sqlite3.OperationalError:
                pass

        finally:
            conn.close()

        logger.info("Stall detection: %d items found", len(stalled))
        return stalled
