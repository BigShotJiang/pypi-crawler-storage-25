# SPDX-License-Identifier: MIT
"""
GitHub API Client -- Lightweight REST client using urllib (no SDK dependency).

Uses GITHUB_TOKEN env var for authenticated requests (5,000 req/hr) when
available, falls back to unauthenticated (60 req/hr).

All functions return dicts/lists and handle errors gracefully -- returning
None or empty collections on failure so callers can fall back to other
data sources without crashing.

Usage:
    from core.github_api import get_repo_info, get_recent_prs, is_available

    if is_available():
        info = get_repo_info("zenon-network", "go-zenon")
        prs = get_recent_prs("zenon-network", "go-zenon")
"""

import json
import logging
import os
import time
import urllib.error
import urllib.request

logger = logging.getLogger(__name__)

GITHUB_API_BASE = "https://api.github.com"
REQUEST_TIMEOUT = 15

# Rate limiting: stay well under GitHub's limits
_RATE_LIMIT_SECONDS = 1.0
_last_request_time = 0.0

# Hard backoff after a 403. The unauthenticated GitHub API allows
# 60 requests per hour and resets on a rolling window. Once we trip
# the limit, we stop ALL calls for one hour rather than re-burning
# attempts every cycle. The v0.2.16 harden run logged 776 GitHub 403
# warnings in 215 cycles before this short-circuit was added — every
# engine that depended on this module was hammering on every cycle
# and producing nothing useful.
_RATE_LIMIT_BACKOFF_SECONDS = 60 * 60  # 1 hour
_rate_limited_until = 0.0
_rate_limit_logged = False


def _rate_limit() -> None:
    """Enforce minimum delay between GitHub API requests."""
    global _last_request_time
    now = time.monotonic()
    elapsed = now - _last_request_time
    if elapsed < _RATE_LIMIT_SECONDS:
        time.sleep(_RATE_LIMIT_SECONDS - elapsed)
    _last_request_time = time.monotonic()


def _build_headers() -> dict[str, str]:
    """Build HTTP headers, including auth token if available.

    The User-Agent is intentionally NOT set here. ``core.http.opsec_urlopen``
    rotates a real browser UA on every outbound request via
    ``OPSECGuard.sanitize_headers``. Setting one here would be confusing
    (callers might think they're picking the UA when they aren't) and
    historically pre-v0.2.5 we shipped ``Nebula/0.1`` from this exact
    function as a stable fingerprint, which is the bug
    ``docs/SECURITY-OPSEC-AUDIT.md`` calls out by name.
    """
    headers = {
        "Accept": "application/vnd.github.v3+json",
    }
    token = os.environ.get("GITHUB_TOKEN", "").strip()
    if token:
        headers["Authorization"] = f"token {token}"
    return headers


def _get(endpoint: str, params: dict | None = None) -> dict | list | None:
    """Make a GET request to the GitHub API.

    Args:
        endpoint: API path (e.g. "/repos/owner/repo").
        params:   Query parameters dict.

    Returns:
        Parsed JSON response, or None on any error.
    """
    global _rate_limited_until, _rate_limit_logged

    # Hard short-circuit if we're inside the post-403 backoff window.
    # No network call, no log spam, no wasted plasma.
    now = time.monotonic()
    if now < _rate_limited_until:
        return None

    _rate_limit()

    url = f"{GITHUB_API_BASE}{endpoint}"
    if params:
        query = "&".join(f"{k}={v}" for k, v in params.items())
        url = f"{url}?{query}"

    # Use the OPSEC-safe HTTP wrapper so the GitHub API can't
    # fingerprint us as "Python-urllib/3.x" across instances.
    from core.http import opsec_request, opsec_urlopen

    req = opsec_request(url, headers=_build_headers())
    try:
        with opsec_urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 403:
            # Set the backoff timer so every subsequent call short-
            # circuits cleanly. Log only on the first hit so we don't
            # spam 776 identical warnings (the harden run baseline).
            _rate_limited_until = time.monotonic() + _RATE_LIMIT_BACKOFF_SECONDS
            if not _rate_limit_logged:
                logger.warning(
                    "GitHub API rate-limited (HTTP 403). Backing off "
                    "for %d seconds. Set GITHUB_TOKEN env var to bump "
                    "the limit from 60/hr to 5000/hr. Suppressing "
                    "further rate-limit warnings until backoff expires.",
                    _RATE_LIMIT_BACKOFF_SECONDS,
                )
                _rate_limit_logged = True
        else:
            logger.warning("GitHub API %s returned HTTP %d", endpoint, exc.code)
        return None
    except (urllib.error.URLError, OSError, json.JSONDecodeError) as exc:
        logger.warning("GitHub API request to %s failed: %s", endpoint, exc)
        return None


def is_available() -> bool:
    """Check if the GitHub API is reachable.

    Makes a lightweight call to /rate_limit. Returns True if the API
    responds successfully, False otherwise.
    """
    result = _get("/rate_limit")
    return result is not None


def get_repo_info(owner: str, repo: str) -> dict | None:
    """Fetch repository metadata.

    Args:
        owner: Repository owner (org or user).
        repo:  Repository name.

    Returns:
        Dict with: name, full_name, description, stars, forks, open_issues,
        language, license, created_at, updated_at, pushed_at, default_branch,
        archived, fork. Returns None on error.
    """
    data = _get(f"/repos/{owner}/{repo}")
    if data is None:
        return None

    return {
        "name": data.get("name", ""),
        "full_name": data.get("full_name", ""),
        "description": data.get("description", ""),
        "stars": data.get("stargazers_count", 0),
        "forks": data.get("forks_count", 0),
        "open_issues": data.get("open_issues_count", 0),
        "language": data.get("language", ""),
        "license": (data.get("license") or {}).get("spdx_id", ""),
        "created_at": data.get("created_at", ""),
        "updated_at": data.get("updated_at", ""),
        "pushed_at": data.get("pushed_at", ""),
        "default_branch": data.get("default_branch", "main"),
        "archived": data.get("archived", False),
        "fork": data.get("fork", False),
        "size_kb": data.get("size", 0),
        "watchers": data.get("subscribers_count", 0),
    }


def get_recent_issues(owner: str, repo: str, limit: int = 20) -> list[dict]:
    """Fetch recent open issues (excluding pull requests).

    Args:
        owner: Repository owner.
        repo:  Repository name.
        limit: Maximum number of issues to return.

    Returns:
        List of dicts with: number, title, state, user, labels, created_at,
        updated_at, comments. Returns empty list on error.
    """
    data = _get(
        f"/repos/{owner}/{repo}/issues",
        params={"state": "open", "per_page": str(min(limit, 100)), "sort": "updated"},
    )
    if not data or not isinstance(data, list):
        return []

    issues = []
    for item in data:
        # GitHub API includes PRs in the issues endpoint; filter them out
        if item.get("pull_request"):
            continue
        issues.append(
            {
                "number": item.get("number", 0),
                "title": item.get("title", ""),
                "state": item.get("state", ""),
                "user": (item.get("user") or {}).get("login", ""),
                "labels": [lbl.get("name", "") for lbl in item.get("labels", [])],
                "created_at": item.get("created_at", ""),
                "updated_at": item.get("updated_at", ""),
                "comments": item.get("comments", 0),
            }
        )
        if len(issues) >= limit:
            break

    return issues


def get_recent_prs(owner: str, repo: str, state: str = "open", limit: int = 20) -> list[dict]:
    """Fetch recent pull requests.

    Args:
        owner: Repository owner.
        repo:  Repository name.
        state: PR state filter ("open", "closed", "all").
        limit: Maximum number of PRs to return.

    Returns:
        List of dicts with: number, title, state, user, head_ref, base_ref,
        created_at, updated_at, merged_at, draft. Returns empty list on error.
    """
    data = _get(
        f"/repos/{owner}/{repo}/pulls",
        params={
            "state": state,
            "per_page": str(min(limit, 100)),
            "sort": "updated",
            "direction": "desc",
        },
    )
    if not data or not isinstance(data, list):
        return []

    prs = []
    for item in data[:limit]:
        prs.append(
            {
                "number": item.get("number", 0),
                "title": item.get("title", ""),
                "state": item.get("state", ""),
                "user": (item.get("user") or {}).get("login", ""),
                "head_ref": (item.get("head") or {}).get("ref", ""),
                "base_ref": (item.get("base") or {}).get("ref", ""),
                "created_at": item.get("created_at", ""),
                "updated_at": item.get("updated_at", ""),
                "merged_at": item.get("merged_at"),
                "draft": item.get("draft", False),
            }
        )

    return prs


def get_ci_status(owner: str, repo: str, branch: str = "main") -> dict | None:
    """Fetch the latest CI/check run status for a branch.

    Uses the combined status endpoint for simplicity.

    Args:
        owner:  Repository owner.
        repo:   Repository name.
        branch: Branch name to check.

    Returns:
        Dict with: state ("success", "pending", "failure", "error"),
        total_count, statuses (list of context+state pairs).
        Returns None on error.
    """
    data = _get(f"/repos/{owner}/{repo}/commits/{branch}/status")
    if data is None:
        return None

    return {
        "state": data.get("state", "unknown"),
        "total_count": data.get("total_count", 0),
        "statuses": [
            {
                "context": s.get("context", ""),
                "state": s.get("state", ""),
                "description": s.get("description", ""),
                "target_url": s.get("target_url", ""),
            }
            for s in data.get("statuses", [])
        ],
    }


def get_releases(owner: str, repo: str, limit: int = 5) -> list[dict]:
    """Fetch recent releases.

    Args:
        owner: Repository owner.
        repo:  Repository name.
        limit: Maximum number of releases to return.

    Returns:
        List of dicts with: tag_name, name, published_at, draft, prerelease,
        author, body (truncated to 500 chars), assets_count.
        Returns empty list on error.
    """
    data = _get(
        f"/repos/{owner}/{repo}/releases",
        params={"per_page": str(min(limit, 100))},
    )
    if not data or not isinstance(data, list):
        return []

    releases = []
    for item in data[:limit]:
        body = item.get("body", "") or ""
        releases.append(
            {
                "tag_name": item.get("tag_name", ""),
                "name": item.get("name", ""),
                "published_at": item.get("published_at", ""),
                "draft": item.get("draft", False),
                "prerelease": item.get("prerelease", False),
                "author": (item.get("author") or {}).get("login", ""),
                "body": body[:500],
                "assets_count": len(item.get("assets", [])),
            }
        )

    return releases


def get_contributors(owner: str, repo: str) -> list[dict]:
    """Fetch contributor list with commit counts.

    Args:
        owner: Repository owner.
        repo:  Repository name.

    Returns:
        List of dicts with: login, contributions (commit count), avatar_url,
        type ("User" or "Bot"). Sorted by contributions descending.
        Returns empty list on error.
    """
    data = _get(
        f"/repos/{owner}/{repo}/contributors",
        params={"per_page": "100", "anon": "false"},
    )
    if not data or not isinstance(data, list):
        return []

    return [
        {
            "login": c.get("login", ""),
            "contributions": c.get("contributions", 0),
            "avatar_url": c.get("avatar_url", ""),
            "type": c.get("type", "User"),
        }
        for c in data
    ]
