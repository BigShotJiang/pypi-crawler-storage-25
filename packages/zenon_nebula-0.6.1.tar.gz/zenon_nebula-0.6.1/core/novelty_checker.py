# SPDX-License-Identifier: MIT
"""Novelty Checker -- determines if a finding is novel vs duplicate.

Adapted from a proven external research pattern (originally a
literature novelty checker) for blockchain intelligence. Instead of
checking an external literature index, checks existing findings in
the local DB using text similarity (reuses peer_corroboration._similarity).

Score: 1.0 = completely new, 0.0 = exact duplicate.
Flags truly novel findings (novelty > 0.8) for attention.
Flags potential duplicates (novelty < 0.2) for cleanup.

No LLM calls. Pure text similarity.
"""

from __future__ import annotations

import logging
import sqlite3
from dataclasses import dataclass

from core.persistence import connect

logger = logging.getLogger(__name__)

# Thresholds
NOVEL_THRESHOLD = 0.8  # Above this = truly novel
DUPLICATE_THRESHOLD = 0.2  # Below this = likely duplicate
MAX_COMPARE = 500  # Max recent findings to compare against


@dataclass
class NoveltyResult:
    """Result of a novelty check for a single finding."""

    finding_id: int | None
    finding_text: str
    novelty_score: float  # 0.0 (duplicate) to 1.0 (novel)
    level: str  # "novel" | "routine" | "duplicate"
    most_similar_id: int | None = None
    most_similar_text: str = ""
    similarity_to_closest: float = 0.0


def _similarity(a: str, b: str) -> float:
    """Similarity score combining sequence matching and keyword overlap.

    Reuses the algorithm from peer_corroboration to stay consistent.
    """
    if not a or not b:
        return 0.0

    from difflib import SequenceMatcher

    def extract_key(text: str) -> str:
        """Extract key content, stripping WHAT/SO WHAT/NOW WHAT boilerplate."""
        what_end = text.find("SO WHAT:")
        if what_end > 0:
            return text[:what_end].replace("WHAT:", "").strip().lower()
        return text[:200].lower()

    key_a = extract_key(a)
    key_b = extract_key(b)

    # Method 1: Sequence similarity
    seq_sim = SequenceMatcher(None, key_a, key_b).ratio()

    # Method 2: Keyword overlap (Jaccard)
    stop_words = {
        "the",
        "a",
        "an",
        "is",
        "are",
        "was",
        "in",
        "of",
        "to",
        "for",
        "and",
        "or",
        "that",
        "this",
        "with",
        "has",
        "have",
        "not",
        "from",
        "found",
        "detected",
        "missing",
        "could",
        "should",
        "would",
        "can",
    }
    words_a = {w for w in key_a.split() if len(w) > 2 and w not in stop_words}
    words_b = {w for w in key_b.split() if len(w) > 2 and w not in stop_words}

    if words_a and words_b:
        intersection = words_a & words_b
        union = words_a | words_b
        keyword_sim = len(intersection) / len(union) if union else 0.0
    else:
        keyword_sim = 0.0

    return max(seq_sim, keyword_sim)


def _get_recent_findings(db_path: str, domain: str = "") -> list[dict]:
    """Fetch recent findings for comparison."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        if domain:
            rows = conn.execute(
                """SELECT id, finding, engine, domain
                   FROM evidence
                   WHERE domain = ? AND finding IS NOT NULL AND finding != ''
                   ORDER BY timestamp DESC LIMIT ?""",
                (domain, MAX_COMPARE),
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT id, finding, engine, domain
                   FROM evidence
                   WHERE finding IS NOT NULL AND finding != ''
                   ORDER BY timestamp DESC LIMIT ?""",
                (MAX_COMPARE,),
            ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def check_novelty(
    finding_text: str,
    db_path: str,
    finding_id: int | None = None,
    domain: str = "",
) -> NoveltyResult:
    """Check how novel a finding is compared to existing findings.

    Args:
        finding_text: The finding text to check.
        db_path: Path to the SQLite database.
        finding_id: Optional ID of the finding (excluded from comparison).
        domain: Optional domain filter for comparison scope.

    Returns:
        NoveltyResult with novelty score and classification.
    """
    if not finding_text or len(finding_text.strip()) < 10:
        return NoveltyResult(
            finding_id=finding_id,
            finding_text=finding_text,
            novelty_score=1.0,
            level="novel",
        )

    existing = _get_recent_findings(db_path, domain)

    # Exclude the finding itself if it has an ID
    if finding_id is not None:
        existing = [e for e in existing if e["id"] != finding_id]

    if not existing:
        return NoveltyResult(
            finding_id=finding_id,
            finding_text=finding_text,
            novelty_score=1.0,
            level="novel",
        )

    # Find the most similar existing finding
    best_sim = 0.0
    best_match: dict | None = None

    for e in existing:
        sim = _similarity(finding_text, e["finding"])
        if sim > best_sim:
            best_sim = sim
            best_match = e

    # Novelty = 1 - max_similarity
    novelty = 1.0 - best_sim

    if novelty >= NOVEL_THRESHOLD:
        level = "novel"
    elif novelty <= DUPLICATE_THRESHOLD:
        level = "duplicate"
    else:
        level = "routine"

    result = NoveltyResult(
        finding_id=finding_id,
        finding_text=finding_text[:200],
        novelty_score=round(novelty, 3),
        level=level,
        most_similar_id=best_match["id"] if best_match else None,
        most_similar_text=(best_match["finding"] or "")[:200] if best_match else "",
        similarity_to_closest=round(best_sim, 3),
    )

    if level == "novel":
        logger.info(
            "Novel finding detected (novelty=%.2f): %s",
            novelty,
            finding_text[:80],
        )
    elif level == "duplicate":
        logger.debug(
            "Duplicate finding (novelty=%.2f, similar to #%s): %s",
            novelty,
            best_match["id"] if best_match else "?",
            finding_text[:80],
        )

    return result


def check_batch(
    db_path: str,
    domain: str = "",
    limit: int = 100,
) -> dict:
    """Check novelty for recent findings and report duplicates.

    Returns summary dict with counts and lists of novel/duplicate finding IDs.
    """
    existing = _get_recent_findings(db_path, domain)
    if len(existing) < 2:
        return {"checked": len(existing), "novel": [], "duplicates": []}

    novel_ids: list[int] = []
    duplicate_ids: list[int] = []

    for i, finding in enumerate(existing[:limit]):
        # Compare against all OTHER findings
        others = [e for j, e in enumerate(existing) if j != i]
        best_sim = 0.0
        for other in others:
            sim = _similarity(finding["finding"], other["finding"])
            if sim > best_sim:
                best_sim = sim

        novelty = 1.0 - best_sim
        if novelty >= NOVEL_THRESHOLD:
            novel_ids.append(finding["id"])
        elif novelty <= DUPLICATE_THRESHOLD:
            duplicate_ids.append(finding["id"])

    return {
        "checked": min(len(existing), limit),
        "novel": novel_ids,
        "duplicates": duplicate_ids,
        "novel_count": len(novel_ids),
        "duplicate_count": len(duplicate_ids),
    }
