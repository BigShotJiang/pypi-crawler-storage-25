# SPDX-License-Identifier: MIT
"""
PromptBuilder -- Guardrail-injected, OPSEC-sanitized prompt assembly.

Every LLM call in Nebula should go through PromptBuilder to ensure:
1. Guardrails from config/guardrails.json are injected automatically
2. OPSEC sanitization strips identifying information
3. Saturated/exhausted approaches are excluded from proposals
4. Domain-specific system prompts are consistent

Generalized from marketing's prompt_builder.py. Domain-agnostic: callers
register their own system prompts by domain name.

Reads: config/guardrails.json
Uses:  core.opsec.OPSECGuard
"""

import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
GUARDRAILS_PATH = ENGINE_ROOT / "config" / "guardrails.json"

# ---------------------------------------------------------------------------
# Critical rules injected into every prompt
# ---------------------------------------------------------------------------

CRITICAL_RULES = """
## CRITICAL RULES -- VIOLATION OF ANY RULE INVALIDATES THE ENTIRE OUTPUT

1. DATA-FIRST: Every claim MUST be backed by verifiable data from API calls.
   No speculative assertions presented as facts.

2. NO HALLUCINATION: Never fabricate data, API responses, transaction hashes,
   block heights, addresses, timestamps, or any on-chain data. If data is
   unavailable, say so explicitly.

3. PROVENANCE REQUIRED: All findings must include the provenance trail.
   Findings without provenance are automatically classified as "hypothesis"
   -- not evidence.

4. NO FABRICATED DATA: Do not invent statistics, metrics, or figures.
   Use only data retrieved from verified API endpoints.

5. PROVENANCE CHAIN: Every finding must be traceable: API call -> raw response
   -> extracted data -> analysis -> conclusion. Break in the chain = invalid.
""".strip()


# ---------------------------------------------------------------------------
# Domain prompt registry
# ---------------------------------------------------------------------------

_DOMAIN_PROMPTS: dict[str, str] = {}


def register_domain_prompt(domain: str, system_prompt: str) -> None:
    """Register a system prompt for a domain.

    Args:
        domain:        Domain key (e.g. "investigation", "intelligence").
        system_prompt: The base system prompt for this domain. CRITICAL_RULES
                       will be prepended automatically.
    """
    _DOMAIN_PROMPTS[domain] = system_prompt
    logger.debug("Registered domain prompt: %s", domain)


def get_registered_domains() -> list[str]:
    """Return all domain keys with registered prompts."""
    return list(_DOMAIN_PROMPTS.keys())


# ---------------------------------------------------------------------------
# Classification / reasoning prompts (reusable across domains)
# ---------------------------------------------------------------------------

SIGNIFICANCE_PROMPT = """Classify the significance of the following finding.

Return EXACTLY one of:
- BREAKTHROUGH -- Changes fundamental understanding; rare, high-confidence,
  verifiable, and surprising. Demands immediate deep investigation.
- SIGNIFICANT -- Materially advances an active hypothesis or opens a new
  credible line of inquiry. Worth dedicated follow-up.
- INCREMENTAL -- Adds a data point to an existing picture without changing
  direction. Archive and continue.
- NOISE -- No meaningful signal. Low confidence, unverifiable, or already
  known. Discard or deprioritise.

Respond with a JSON object:
{
  "classification": "<BREAKTHROUGH|SIGNIFICANT|INCREMENTAL|NOISE>",
  "reasoning": "<1-2 sentences explaining why>",
  "confidence": <0.0 to 1.0>
}

Finding to classify:
"""

QUESTION_GENERATOR_PROMPT = """Given the following findings and current hypotheses,
generate follow-up investigation questions.

Requirements:
- Each question must be answerable via available APIs or data sources.
- Prioritise questions that would CONFIRM or REFUTE existing hypotheses.
- Include at least one question that challenges the current leading theory.
- Questions should be specific and actionable, not vague.

Return a JSON array of objects:
[
  {
    "question": "<specific investigation question>",
    "target_api": "<API or data source to query>",
    "expected_impact": "<what answering this would change>",
    "priority": <1-5, 1=highest>
  }
]

Current findings and hypotheses:
"""

SYNTHESIS_PROMPT = """Synthesise the following validated findings into a coherent theory.

Rules:
- Only incorporate findings with provenance classification "verified_by_api"
  or "computational". Exclude pure hypotheses.
- Clearly separate what the data SHOWS from what you INFER.
- Identify contradictions between findings and address them explicitly.
- Rate the overall theory confidence (0.0-1.0) based on evidence strength.
- Suggest what additional evidence would raise or lower confidence.

Return a JSON object:
{
  "theory_summary": "<2-3 sentence summary>",
  "supporting_evidence": ["<finding_id>", ...],
  "contradicting_evidence": ["<finding_id>", ...],
  "inferences": ["<inference 1>", ...],
  "confidence": <0.0 to 1.0>,
  "gaps": ["<what additional data would help>", ...]
}

Validated findings:
"""

DIRECTOR_PROMPT = """You are the Investigation Director. Given the current state of all
active hypotheses, recent findings, and available investigation templates,
propose the next set of investigation actions.

Rules:
- Prioritise actions that resolve the highest-uncertainty hypotheses.
- Do not propose actions using saturated/exhausted approaches (listed below).
- Balance exploitation (deepening known leads) with exploration (new angles).
- Each proposed action must specify the template to run and parameters.

Return a JSON array:
[
  {
    "action": "<description>",
    "template": "<template class name>",
    "params": { ... },
    "rationale": "<why this action now>",
    "expected_value": "<what we hope to learn>",
    "priority": <1-5, 1=highest>
  }
]

Current state:
"""


# ---------------------------------------------------------------------------
# Guardrail loading
# ---------------------------------------------------------------------------


def _load_guardrails() -> list[dict]:
    """Load guardrails from config/guardrails.json."""
    try:
        with open(GUARDRAILS_PATH) as f:
            data = json.load(f)
        return data.get("guardrails", [])
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        logger.warning("Could not load guardrails from %s: %s", GUARDRAILS_PATH, exc)
        return []


def _format_guardrails(guardrails: list[dict]) -> str:
    """Format guardrails into a prompt-ready block."""
    if not guardrails:
        return ""
    lines = ["## GUARDRAILS (from config/guardrails.json)"]
    for g in guardrails:
        severity = g.get("severity", "MEDIUM")
        rule = g.get("rule", "")
        lines.append(f"- [{severity}] {rule}")
    return "\n".join(lines)


def _format_saturation(saturated_classes: list[str]) -> str:
    """Format saturated/exhausted approaches as an exclusion block."""
    if not saturated_classes:
        return ""
    lines = [
        "## SATURATED APPROACHES -- DO NOT USE THESE",
        "The following investigation approaches have been exhausted and should",
        "not be proposed or repeated:",
    ]
    for cls in saturated_classes:
        lines.append(f"- {cls}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_system_prompt(
    domain: str,
    saturated_classes: list[str] | None = None,
    context: str | None = None,
    include_critical_rules: bool = True,
) -> str:
    """Build a complete system prompt with guardrails and OPSEC sanitization.

    Args:
        domain:              Domain key matching a registered prompt, or a raw
                             prompt string if no domain is registered.
        saturated_classes:   List of template/approach labels that are exhausted
                             and should be excluded from proposals.
        context:             Optional extra context to append (e.g. active
                             hypotheses summary, current phase).
        include_critical_rules: Whether to prepend CRITICAL_RULES. Default True.

    Returns:
        Fully assembled, OPSEC-sanitized system prompt string.
    """
    # Select base prompt
    base = _DOMAIN_PROMPTS.get(domain, "")
    if not base:
        # Allow raw domain string as a prompt fallback
        if len(domain) > 50:
            base = domain
        else:
            base = f"You are a specialist in the '{domain}' domain."

    # Inject critical rules
    if include_critical_rules:
        base = f"{CRITICAL_RULES}\n\n{base}"

    # Inject guardrails
    guardrails = _load_guardrails()
    guardrails_block = _format_guardrails(guardrails)

    # Inject saturation exclusions
    saturation_block = _format_saturation(saturated_classes or [])

    # Assemble
    parts = [base]
    if guardrails_block:
        parts.append(guardrails_block)
    if saturation_block:
        parts.append(saturation_block)
    if context:
        parts.append(f"## CURRENT CONTEXT\n{context}")

    prompt = "\n\n".join(parts)

    # OPSEC: strip all identifying information before the prompt reaches an LLM
    try:
        from core.opsec import OPSECGuard

        prompt = OPSECGuard.sanitize_prompt(prompt)
    except ImportError:
        logger.debug("OPSECGuard not available -- skipping sanitization")

    return prompt


def build_user_prompt(
    content: str,
    sanitize: bool = True,
) -> str:
    """Sanitize a user prompt before sending to an LLM.

    Args:
        content:  Raw user prompt text.
        sanitize: Whether to run OPSEC sanitization. Default True.

    Returns:
        Sanitized prompt string.
    """
    if sanitize:
        try:
            from core.opsec import OPSECGuard

            return OPSECGuard.sanitize_prompt(content)
        except ImportError:
            pass
    return content
