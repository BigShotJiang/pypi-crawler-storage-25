# SPDX-License-Identifier: MIT
"""
Hypothesis Evolution Engine -- Automated hypothesis lifecycle for Nebula.

Scans recent evidence for patterns, creates hypotheses from clusters,
links evidence to hypotheses, triggers Bayesian confidence updates,
and manages hypothesis lifecycle (retire stale, promote compelling).

No LLM calls -- all pattern matching is local and deterministic.
"""

import logging
import re
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# How far back to scan for evidence patterns (hours)
EVIDENCE_WINDOW_HOURS = 72

# Lifecycle thresholds
RETIRE_CONFIDENCE = 0.05
RETIRE_AGE_DAYS = 7
PROMOTE_CONFIDENCE = 0.90

# Minimum cluster size to create a hypothesis
MIN_CLUSTER_SIZE = 3

# Evidence types used by the generic pattern matchers below. Patterns
# key off evidence_type rather than a hardcoded domain name so that core
# can detect security/quality clusters produced by any domain without
# knowing which domains exist.
_SECURITY_EVIDENCE_TYPES = (
    "vulnerability",
    "security_finding",
    "hostile_review",
    "bug_found",
)
_QUALITY_REGRESSION_EVIDENCE_TYPES = (
    "build_failure",
    "test_failure",
    "mismatch",
    "bug_found",
)


# ---------------------------------------------------------------------------
# Pattern definitions
# ---------------------------------------------------------------------------

# Each pattern defines:
#   id_template:  deterministic hypothesis ID (may include {placeholders})
#   domain:       which domain owns the hypothesis
#   title_template: human-readable title
#   match:        function(rows) -> list[dict] of matched groups
#                 each dict has 'key' (for id template) and 'evidence_ids'


def _pattern_upstream_breaking(rows: list[dict]) -> list[dict]:
    """Detect clusters of upstream commits tagged as breaking or major."""
    breaking = [
        r
        for r in rows
        if r["evidence_type"] in ("upstream_commit", "github_commit", "commit_scan")
        and any(
            kw in (r["finding"] or "").lower()
            for kw in ("breaking", "major", "refactor", "v2", "rewrite")
        )
    ]
    if len(breaking) < MIN_CLUSTER_SIZE:
        return []
    # Group by source_repo
    by_repo: dict[str, list[dict]] = {}
    for r in breaking:
        repo = r.get("source_repo") or r.get("engine") or "unknown"
        by_repo.setdefault(repo, []).append(r)
    results = []
    for repo, items in by_repo.items():
        if len(items) >= MIN_CLUSTER_SIZE:
            results.append(
                {
                    "key": re.sub(r"[^a-zA-Z0-9_-]", "_", repo),
                    "evidence_ids": [i["id"] for i in items],
                }
            )
    return results


def _pattern_security_cluster(rows: list[dict]) -> list[dict]:
    """Detect multiple security-flavoured findings in the same contract/repo.

    Generic over domain: any engine in any domain can produce a security
    finding and this pattern will cluster it, as long as the evidence_type
    identifies the row as security-related. Core stays domain-agnostic.
    """
    security = [r for r in rows if r["evidence_type"] in _SECURITY_EVIDENCE_TYPES]
    if len(security) < MIN_CLUSTER_SIZE:
        return []
    by_target: dict[str, list[dict]] = {}
    for r in security:
        target = r.get("source_repo") or r.get("source_file") or r.get("engine") or "unknown"
        by_target.setdefault(target, []).append(r)
    results = []
    for target, items in by_target.items():
        if len(items) >= MIN_CLUSTER_SIZE:
            results.append(
                {
                    "key": re.sub(r"[^a-zA-Z0-9_-]", "_", target),
                    "evidence_ids": [i["id"] for i in items],
                }
            )
    return results


def _pattern_spec_progress(rows: list[dict]) -> list[dict]:
    """Detect rapid spec implementation progress across repos."""
    spec = [
        r
        for r in rows
        if r["evidence_type"] in ("spec_coverage", "implementation", "verification", "spec_update")
        and r.get("confidence", 0) >= 0.6
    ]
    if len(spec) < MIN_CLUSTER_SIZE:
        return []
    return [
        {
            "key": "full_stack",
            "evidence_ids": [i["id"] for i in spec],
        }
    ]


def _pattern_quality_regression(rows: list[dict]) -> list[dict]:
    """Detect build failures or test failures clustering.

    Generic over domain: matches on evidence_type alone so any engine in
    any domain can contribute to a quality regression cluster.
    """
    failures = [r for r in rows if r["evidence_type"] in _QUALITY_REGRESSION_EVIDENCE_TYPES]
    if len(failures) < MIN_CLUSTER_SIZE:
        return []
    by_repo: dict[str, list[dict]] = {}
    for r in failures:
        repo = r.get("source_repo") or "unknown"
        by_repo.setdefault(repo, []).append(r)
    results = []
    for repo, items in by_repo.items():
        if len(items) >= MIN_CLUSTER_SIZE:
            results.append(
                {
                    "key": re.sub(r"[^a-zA-Z0-9_-]", "_", repo),
                    "evidence_ids": [i["id"] for i in items],
                }
            )
    return results


def _pattern_liquidity_anomaly(rows: list[dict]) -> list[dict]:
    """Detect liquidity drops combined with volume spikes."""
    liquidity = [
        r
        for r in rows
        if r["evidence_type"]
        in ("liquidity_drop", "liquidity_change", "volume_spike", "market_anomaly")
    ]
    if len(liquidity) < MIN_CLUSTER_SIZE:
        return []
    return [
        {
            "key": "market",
            "evidence_ids": [i["id"] for i in liquidity],
        }
    ]


def _pattern_stalled_domain(rows: list[dict]) -> list[dict]:
    """Detect domains producing no new evidence (stall signal)."""
    stall = [
        r for r in rows if r["evidence_type"] in ("stall_alert", "stalled_engine", "no_progress")
    ]
    if len(stall) < MIN_CLUSTER_SIZE:
        return []
    by_domain: dict[str, list[dict]] = {}
    for r in stall:
        d = r.get("domain") or "unknown"
        by_domain.setdefault(d, []).append(r)
    results = []
    for domain, items in by_domain.items():
        if len(items) >= MIN_CLUSTER_SIZE:
            results.append(
                {
                    "key": re.sub(r"[^a-zA-Z0-9_-]", "_", domain),
                    "evidence_ids": [i["id"] for i in items],
                }
            )
    return results


def _pattern_convergent_findings(rows: list[dict]) -> list[dict]:
    """Detect multiple domains finding the same thing (cross-domain convergence)."""
    # Group by similar finding text (first 80 chars normalized)
    by_text: dict[str, list[dict]] = {}
    for r in rows:
        key = re.sub(r"\s+", " ", (r["finding"] or "")[:80].lower().strip())
        if len(key) > 10:  # skip tiny findings
            by_text.setdefault(key, []).append(r)
    results = []
    for text, items in by_text.items():
        domains = {r.get("domain") for r in items}
        if len(domains) >= 2 and len(items) >= MIN_CLUSTER_SIZE:
            slug = re.sub(r"[^a-zA-Z0-9_-]", "_", text[:40])
            results.append(
                {
                    "key": slug,
                    "evidence_ids": [i["id"] for i in items],
                }
            )
    return results


def _pattern_peer_agreement(rows: list[dict]) -> list[dict]:
    """Detect peer-corroborated findings clustering around a theme."""
    corroborated = [
        r
        for r in rows
        if r.get("confidence", 0) >= 0.7
        and r["evidence_type"] in ("corroborated", "peer_verified", "peer_agreement")
    ]
    if len(corroborated) < MIN_CLUSTER_SIZE:
        return []
    return [
        {
            "key": "peer_consensus",
            "evidence_ids": [i["id"] for i in corroborated],
        }
    ]


# Registry of all patterns
PATTERNS = [
    {
        "id_template": "H_upstream_breaking_{key}",
        "domain": "intelligence",
        "title_template": "Major upstream changes detected in {key}",
        "match": _pattern_upstream_breaking,
    },
    {
        "id_template": "H_security_cluster_{key}",
        "domain": "security",
        "title_template": "Systemic security issues in {key}",
        "match": _pattern_security_cluster,
    },
    {
        "id_template": "H_spec_progress_{key}",
        "domain": "development",
        "title_template": "Rapid spec implementation progress ({key})",
        "match": _pattern_spec_progress,
    },
    {
        "id_template": "H_quality_regression_{key}",
        "domain": "quality",
        "title_template": "Quality regression in {key}",
        "match": _pattern_quality_regression,
    },
    {
        "id_template": "H_liquidity_anomaly_{key}",
        "domain": "market",
        "title_template": "Liquidity anomaly detected ({key})",
        "match": _pattern_liquidity_anomaly,
    },
    {
        "id_template": "H_stalled_{key}",
        "domain": "system",
        "title_template": "Domain {key} appears stalled",
        "match": _pattern_stalled_domain,
    },
    {
        "id_template": "H_convergent_{key}",
        "domain": "system",
        "title_template": "Cross-domain convergence: {key}",
        "match": _pattern_convergent_findings,
    },
    {
        "id_template": "H_peer_consensus_{key}",
        "domain": "system",
        "title_template": "Peer-corroborated consensus ({key})",
        "match": _pattern_peer_agreement,
    },
]


# ---------------------------------------------------------------------------
# Core engine
# ---------------------------------------------------------------------------


def _get_recent_evidence(db_path: str, hours: float = EVIDENCE_WINDOW_HOURS) -> list[dict]:
    """Fetch evidence from the last N hours."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        rows = conn.execute(
            """SELECT id, timestamp, domain, engine, evidence_type, finding,
                      confidence, supports_hypothesis, contradicts_hypothesis,
                      source_repo, source_file, source_commit, status
               FROM evidence
               WHERE timestamp >= ?
               ORDER BY timestamp DESC""",
            (cutoff,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def _get_all_hypotheses(db_path: str) -> list[dict]:
    """Fetch all hypotheses."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute("SELECT * FROM hypotheses").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def _link_evidence_to_hypothesis(db_path: str, evidence_id: int, hypothesis_id: str) -> None:
    """Set supports_hypothesis on an evidence row and trigger Bayesian update."""
    conn = connect(db_path)
    try:
        # Only link if not already linked
        current = conn.execute(
            "SELECT supports_hypothesis, confidence FROM evidence WHERE id = ?",
            (evidence_id,),
        ).fetchone()
        if not current:
            return
        if current[0]:
            # Already linked to a hypothesis, skip
            return

        conn.execute(
            "UPDATE evidence SET supports_hypothesis = ? WHERE id = ?",
            (hypothesis_id, evidence_id),
        )
        conn.commit()

        # Trigger Bayesian update
        from core.persist_to_db import _update_hypothesis_confidence

        _update_hypothesis_confidence(conn, hypothesis_id, current[1] or 0.5, "support")
    finally:
        conn.close()


def _manage_lifecycle(db_path: str) -> dict:
    """Retire low-confidence stale hypotheses, promote high-confidence ones.

    Returns:
        Dict with counts of retired and promoted hypotheses.
    """
    now = datetime.now(timezone.utc)
    cutoff = (now - timedelta(days=RETIRE_AGE_DAYS)).isoformat()

    conn = connect(db_path)
    retired = 0
    promoted = 0
    try:
        # Retire: confidence below threshold AND older than age limit
        cursor = conn.execute(
            """UPDATE hypotheses
               SET status = 'RETIRED', last_updated = ?
               WHERE status = 'INVESTIGATING'
                 AND confidence <= ?
                 AND last_updated <= ?""",
            (now.isoformat(), RETIRE_CONFIDENCE, cutoff),
        )
        retired = cursor.rowcount

        # Promote: confidence above threshold
        cursor = conn.execute(
            """UPDATE hypotheses
               SET status = 'COMPELLING', last_updated = ?
               WHERE status = 'INVESTIGATING'
                 AND confidence >= ?""",
            (now.isoformat(), PROMOTE_CONFIDENCE),
        )
        promoted = cursor.rowcount

        conn.commit()
    finally:
        conn.close()

    if retired:
        logger.info("Retired %d low-confidence hypotheses", retired)
    if promoted:
        logger.info("Promoted %d hypotheses to COMPELLING", promoted)

    return {"retired": retired, "promoted": promoted}


def evolve(db_path: str = DEFAULT_DB) -> dict:
    """Run one hypothesis evolution cycle.

    1. Scan recent evidence for pattern clusters.
    2. Create hypotheses from detected patterns.
    3. Link unlinked evidence to matching hypotheses.
    4. Manage lifecycle (retire/promote).

    Returns:
        Summary dict with counts of created, linked, retired, promoted.
    """
    recent = _get_recent_evidence(db_path)
    if not recent:
        logger.debug("No recent evidence to analyze for hypothesis evolution")
        return {"created": 0, "linked": 0, "retired": 0, "promoted": 0}

    created = 0
    linked = 0

    from core.persist_to_db import create_hypothesis

    for pattern in PATTERNS:
        matches = pattern["match"](recent)
        for match in matches:
            key = match["key"]
            h_id = pattern["id_template"].format(key=key)
            title = pattern["title_template"].format(key=key)
            domain = pattern["domain"]

            # Create hypothesis (idempotent — skips if exists)
            was_new = create_hypothesis(
                db_path=db_path,
                hypothesis_id=h_id,
                domain=domain,
                title=title,
                confidence=0.5,
                status="INVESTIGATING",
            )
            if was_new:
                created += 1

            # Link evidence that contributed to this pattern
            for eid in match["evidence_ids"]:
                _link_evidence_to_hypothesis(db_path, eid, h_id)
                linked += 1

    # Lifecycle management
    lifecycle = _manage_lifecycle(db_path)

    summary = {
        "created": created,
        "linked": linked,
        "retired": lifecycle["retired"],
        "promoted": lifecycle["promoted"],
        "patterns_checked": len(PATTERNS),
        "evidence_scanned": len(recent),
    }

    if created or linked or lifecycle["retired"] or lifecycle["promoted"]:
        logger.info(
            "Hypothesis evolution: created=%d linked=%d retired=%d promoted=%d (scanned %d evidence)",
            created,
            linked,
            lifecycle["retired"],
            lifecycle["promoted"],
            len(recent),
        )
    else:
        logger.debug("Hypothesis evolution: no changes (scanned %d evidence)", len(recent))

    return summary
