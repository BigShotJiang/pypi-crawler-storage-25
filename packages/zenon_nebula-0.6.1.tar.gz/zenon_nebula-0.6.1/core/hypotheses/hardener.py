# SPDX-License-Identifier: MIT
"""Hypothesis Hardener -- sensitivity analysis for high-confidence hypotheses.

**Agent pattern:** *evaluator-optimizer loop* (Anthropic "Building
Effective Agents" taxonomy). This module is the evaluator: it inspects
an existing hypothesis, stress-tests it by removing evidence / checking
source diversity / checking staleness, and reports fragility findings.
The downstream loop -- currently manual, eventually automatic -- lets
the optimizer step re-examine weak hypotheses, gather more evidence,
and re-run the evaluator. The ``CONFIDENCE_THRESHOLD`` +
``FRAGILITY_THRESHOLD`` constants define the evaluator's rubric.

Adapted from a proven external research pattern for blockchain intelligence.

For each hypothesis above a confidence threshold, runs stress tests:
  1. Remove the strongest supporting evidence -> recalculate confidence.
     If it drops below 30%, the hypothesis is fragile (single-evidence dependent).
  2. Check if all supporting evidence comes from the same engine -> single-source bias.
  3. Check if supporting evidence is older than 7 days without refresh -> stale evidence.

Produces QA findings in WHAT / SO WHAT / NOW WHAT format.
No LLM calls. Pure DB queries + math.
"""

from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timedelta, timezone

from core.hypotheses.models import HardeningReport, HardeningResult
from core.persistence import connect

logger = logging.getLogger(__name__)

# Thresholds
CONFIDENCE_THRESHOLD = 0.70  # Only harden hypotheses above this
FRAGILITY_THRESHOLD = 0.30  # If drops below this after removing best evidence, fragile
STALE_EVIDENCE_DAYS = 7  # Evidence older than this without refresh is stale


def _bayesian_combine(confidences: list[float]) -> float:
    """Combine independent confidence estimates using odds-form Bayesian update."""
    if not confidences:
        return 0.0
    if len(confidences) == 1:
        return confidences[0]
    clamped = [max(0.01, min(0.99, c)) for c in confidences]
    combined_odds = 1.0
    for c in clamped:
        combined_odds *= c / (1.0 - c)
    return min(combined_odds / (1.0 + combined_odds), 0.99)


def _get_high_confidence_hypotheses(db_path: str) -> list[dict]:
    """Fetch hypotheses above the confidence threshold."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT id, title, confidence, evidence_for, evidence_against, status
               FROM hypotheses
               WHERE confidence >= ? AND status != 'RETIRED'""",
            (CONFIDENCE_THRESHOLD,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def _get_supporting_evidence(db_path: str, hypothesis_id: str) -> list[dict]:
    """Fetch all evidence rows supporting a hypothesis."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT id, engine, confidence, timestamp, domain
               FROM evidence
               WHERE supports_hypothesis = ?
               ORDER BY confidence DESC""",
            (hypothesis_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def harden_hypothesis(db_path: str, hypothesis: dict) -> HardeningResult:
    """Run stress tests on a single hypothesis."""
    h_id = hypothesis["id"]
    h_title = hypothesis.get("title") or h_id
    h_conf = hypothesis.get("confidence", 0.0)

    result = HardeningResult(
        hypothesis_id=h_id,
        hypothesis_title=h_title,
        original_confidence=h_conf,
    )

    evidence = _get_supporting_evidence(db_path, h_id)
    result.total_evidence = len(evidence)

    if not evidence:
        # No supporting evidence at all -- fragile by definition
        result.is_fragile = True
        result.fragile_drop_to = 0.0
        result.finding_text = (
            f"WHAT: Hypothesis {h_id} ({h_title}) has confidence {h_conf:.2f} "
            f"but zero supporting evidence rows. "
            f"SO WHAT: Confidence is unsupported -- likely a stale initial estimate. "
            f"NOW WHAT: Seek evidence or retire the hypothesis."
        )
        return result

    # -- Stress test 1: Remove strongest evidence, recalculate --
    confidences = [e["confidence"] for e in evidence if e["confidence"] > 0]
    if len(confidences) >= 2:
        # Remove the highest confidence evidence
        result.strongest_evidence_id = evidence[0]["id"]  # sorted DESC
        without_strongest = confidences[1:]  # drop first (highest)
        recalc = _bayesian_combine(without_strongest)
        result.fragile_drop_to = recalc
        if recalc < FRAGILITY_THRESHOLD:
            result.is_fragile = True
    elif len(confidences) == 1:
        # Single evidence -- removing it means zero
        result.strongest_evidence_id = evidence[0]["id"]
        result.fragile_drop_to = 0.0
        result.is_fragile = True

    # -- Stress test 2: Single-source bias --
    engines = {e["engine"] for e in evidence if e.get("engine")}
    if len(engines) == 1:
        result.single_source_bias = True
        result.bias_engine = engines.pop()

    # -- Stress test 3: Stale evidence --
    cutoff = (datetime.now(timezone.utc) - timedelta(days=STALE_EVIDENCE_DAYS)).isoformat()
    stale = [e for e in evidence if (e.get("timestamp") or "") < cutoff]
    if stale and len(stale) == len(evidence):
        # ALL evidence is stale
        result.stale_evidence = True
        result.stale_count = len(stale)

    # -- Build finding text --
    issues = []
    if result.is_fragile:
        issues.append(
            f"WHAT: {h_id} drops to {result.fragile_drop_to:.2f} if evidence "
            f"#{result.strongest_evidence_id} is removed. "
            f"SO WHAT: Hypothesis depends on single finding. "
            f"NOW WHAT: Seek independent corroboration."
        )
    if result.single_source_bias:
        issues.append(
            f"WHAT: All {result.total_evidence} evidence items for {h_id} come from "
            f"engine '{result.bias_engine}'. "
            f"SO WHAT: Single-source bias -- if that engine is wrong, the hypothesis is wrong. "
            f"NOW WHAT: Run different engines against the same question."
        )
    if result.stale_evidence:
        issues.append(
            f"WHAT: All {result.stale_count} evidence items for {h_id} are older than "
            f"{STALE_EVIDENCE_DAYS} days. "
            f"SO WHAT: Stale evidence may no longer reflect current state. "
            f"NOW WHAT: Re-run engines to refresh evidence."
        )

    result.finding_text = " | ".join(issues) if issues else ""
    return result


def harden_all(
    db_path: str,
    persist: bool = True,
) -> HardeningReport:
    """Run hardening on all eligible hypotheses.

    Args:
        db_path: Path to the SQLite database.
        persist: If True, persist QA findings to the evidence table.

    Returns:
        HardeningReport with all results.
    """
    hypotheses = _get_high_confidence_hypotheses(db_path)
    report = HardeningReport(hypotheses_checked=len(hypotheses))

    for h in hypotheses:
        result = harden_hypothesis(db_path, h)
        report.results.append(result)
        if result.is_fragile:
            report.fragile_count += 1
        if result.single_source_bias:
            report.biased_count += 1
        if result.stale_evidence:
            report.stale_count += 1

        # Persist QA findings
        if persist and result.finding_text:
            try:
                from core.persist_to_db import persist_finding

                persist_finding(
                    db_path=db_path,
                    domain="quality",
                    engine="hypothesis_hardener",
                    evidence_type="qa_hardening",
                    finding=result.finding_text,
                    confidence=0.9,
                    supports_hypothesis=None,
                    contradicts_hypothesis=result.hypothesis_id if result.is_fragile else None,
                )
            except Exception as exc:
                logger.debug("Failed to persist hardening finding: %s", exc)

    if report.results:
        logger.info(
            "Hypothesis hardening: checked=%d fragile=%d biased=%d stale=%d",
            report.hypotheses_checked,
            report.fragile_count,
            report.biased_count,
            report.stale_count,
        )

    return report
