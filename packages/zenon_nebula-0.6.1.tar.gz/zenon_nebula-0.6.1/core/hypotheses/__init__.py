# SPDX-License-Identifier: MIT
"""Unified hypothesis package.

Combines models, pattern-detection evolution, and hardening stress
tests into a single conceptual unit. Legacy imports from
``core.hypothesis_engine`` and ``core.hypothesis_hardener`` continue
to work via shim modules at those paths.
"""

from core.hypotheses.engine import (
    DEFAULT_DB,
    EVIDENCE_WINDOW_HOURS,
    MIN_CLUSTER_SIZE,
    PATTERNS,
    PROMOTE_CONFIDENCE,
    RETIRE_AGE_DAYS,
    RETIRE_CONFIDENCE,
    evolve,
)
from core.hypotheses.hardener import (
    CONFIDENCE_THRESHOLD,
    FRAGILITY_THRESHOLD,
    STALE_EVIDENCE_DAYS,
    harden_all,
    harden_hypothesis,
)
from core.hypotheses.models import (
    HardeningReport,
    HardeningResult,
    Hypothesis,
)

__all__ = [
    # Hardener
    "CONFIDENCE_THRESHOLD",
    # Engine
    "DEFAULT_DB",
    "EVIDENCE_WINDOW_HOURS",
    "FRAGILITY_THRESHOLD",
    "MIN_CLUSTER_SIZE",
    "PATTERNS",
    "PROMOTE_CONFIDENCE",
    "RETIRE_AGE_DAYS",
    "RETIRE_CONFIDENCE",
    "STALE_EVIDENCE_DAYS",
    "HardeningReport",
    "HardeningResult",
    # Models
    "Hypothesis",
    "evolve",
    "harden_all",
    "harden_hypothesis",
]
