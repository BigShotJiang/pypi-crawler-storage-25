# SPDX-License-Identifier: MIT
"""Hypothesis data models.

Canonical dataclasses for hypotheses and hardening results used across
Nebula's hypothesis lifecycle (creation, evolution, hardening).
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Hypothesis:
    """Canonical in-memory shape of a hypothesis row.

    Mirrors the ``hypotheses`` table. Engines that want a typed view of
    a hypothesis (instead of a raw ``dict``) should use this class. The
    DB layer still exposes rows as dicts for backward compatibility.
    """

    id: str
    domain: str
    title: str
    confidence: float = 0.5
    status: str = "INVESTIGATING"
    evidence_for: int = 0
    evidence_against: int = 0
    created_at: str | None = None
    last_updated: str | None = None
    raw_data: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to a plain dict suitable for DB persistence."""
        return {k: v for k, v in self.__dict__.items() if v is not None}

    @classmethod
    def from_row(cls, row: dict) -> Hypothesis:
        """Reconstitute from a DB row (``sqlite3.Row`` or ``dict``)."""
        data = dict(row)
        allowed = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        return cls(**allowed)


@dataclass
class HardeningResult:
    """Result of hardening a single hypothesis."""

    hypothesis_id: str
    hypothesis_title: str
    original_confidence: float
    is_fragile: bool = False
    fragile_drop_to: float = 0.0
    strongest_evidence_id: int | None = None
    single_source_bias: bool = False
    bias_engine: str | None = None
    stale_evidence: bool = False
    stale_count: int = 0
    total_evidence: int = 0
    finding_text: str = ""


@dataclass
class HardeningReport:
    """Aggregated report from hardening all eligible hypotheses."""

    results: list[HardeningResult] = field(default_factory=list)
    hypotheses_checked: int = 0
    fragile_count: int = 0
    biased_count: int = 0
    stale_count: int = 0


__all__ = [
    "HardeningReport",
    "HardeningResult",
    "Hypothesis",
]
