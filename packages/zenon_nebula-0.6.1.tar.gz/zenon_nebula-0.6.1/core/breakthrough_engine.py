# SPDX-License-Identifier: MIT
"""
BreakthroughEngine - Actively hunt for high-impact discoveries.

**Agent pattern:** *orchestrator-workers* with an internal voting step
(Anthropic "Building Effective Agents" taxonomy). The breakthrough
engine orchestrates: it queries each domain's recent findings, scores
them on convergence + mission_impact, and promotes the top-N. The
voting step is the convergence_score -- a breakthrough candidate only
earns a breakthrough_candidate tag when multiple independent engines
agree.

Most engines look for incremental signal. The breakthrough engine looks
for moments of discontinuity: cross-domain convergence, anomaly spikes,
hidden patterns, contrarian evidence, and mission-critical finds.

A breakthrough candidate earns a special ``breakthrough_candidate``
evidence type and is scored on two axes:

    convergence_score   (0..1) - how many independent signals agree
    mission_impact      (0..1) - how much a confirmed finding advances
                                 :mod:`core.mission`

The War Room reads breakthrough candidates first when it drafts the
next battle plan. Over time the trust model learns which candidates
turn into real wins and adjusts the score thresholds.

This module is deterministic. No LLM calls. The only ``expensive''
path is peer corroboration, which is also deterministic.
"""

from __future__ import annotations

import logging
import sqlite3
import statistics
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.mission import PILLARS, mission_alignment
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Anomaly amplification threshold (sigma).
SIGMA_THRESHOLD = 3.0

# Minimum convergence count to flag as a breakthrough (independent engines).
MIN_CONVERGENCE = 2

# Evidence types that never promote - administrative noise we don't want to
# accidentally amplify through the breakthrough flow.
_SKIP_TYPES = {
    "cycle_summary",
    "scheduler_tick",
    "heartbeat",
    "system_error",
}


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class BreakthroughCandidate:
    """A finding promoted to ``breakthrough_candidate`` status."""

    source_evidence_ids: list[int]
    domains: list[str]
    engines: list[str]
    evidence_type: str
    summary: str
    convergence_score: float
    mission_impact: float
    pillar_scores: dict[str, float]
    reasons: list[str] = field(default_factory=list)

    @property
    def rank(self) -> float:
        """Composite rank used to sort candidates for the War Room."""
        return round(0.5 * self.convergence_score + 0.5 * self.mission_impact, 4)

    def to_raw(self) -> dict:
        """Return a plain dict suitable for ``persist_finding(raw_data=...)``."""
        return {
            "source_evidence_ids": self.source_evidence_ids,
            "domains": sorted(set(self.domains)),
            "engines": sorted(set(self.engines)),
            "evidence_type": self.evidence_type,
            "convergence_score": self.convergence_score,
            "mission_impact": self.mission_impact,
            "pillar_scores": self.pillar_scores,
            "reasons": self.reasons,
            "rank": self.rank,
        }


# ---------------------------------------------------------------------------
# Convergence detection
# ---------------------------------------------------------------------------


def _recent_evidence(
    conn: sqlite3.Connection,
    *,
    hours: int,
) -> list[sqlite3.Row]:
    """Return evidence rows newer than ``hours`` ago."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    try:
        rows = conn.execute(
            """SELECT id, domain, engine, finding, evidence_type,
                      confidence, timestamp
               FROM evidence
               WHERE timestamp >= ?
                 AND COALESCE(evidence_type,'') != ''
               ORDER BY timestamp DESC""",
            (cutoff,),
        ).fetchall()
    except sqlite3.OperationalError as exc:
        logger.debug("Breakthrough: evidence table missing: %s", exc)
        return []
    return list(rows)


def _group_by_type(
    rows: Iterable[sqlite3.Row],
) -> dict[str, list[sqlite3.Row]]:
    """Group evidence rows by ``evidence_type``."""
    groups: dict[str, list[sqlite3.Row]] = {}
    for row in rows:
        ev_type = row["evidence_type"] or ""
        if ev_type in _SKIP_TYPES:
            continue
        groups.setdefault(ev_type, []).append(row)
    return groups


def detect_convergence(
    *,
    db_path: str = DEFAULT_DB,
    hours: int = 24,
) -> list[BreakthroughCandidate]:
    """Return breakthrough candidates from cross-domain convergence.

    Two or more distinct engines producing the same ``evidence_type``
    inside ``hours`` count as convergence. The resulting candidate
    aggregates every domain+engine that contributed.

    Args:
        db_path: Path to ``engine.db``.
        hours: Lookback window in hours.
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = _recent_evidence(conn, hours=hours)
    finally:
        conn.close()

    candidates: list[BreakthroughCandidate] = []
    for ev_type, group in _group_by_type(rows).items():
        engines = {row["engine"] for row in group}
        if len(engines) < MIN_CONVERGENCE:
            continue
        domains = sorted({row["domain"] for row in group})
        summary = (
            f"Cross-engine convergence on '{ev_type}': "
            f"{len(engines)} engines across {len(domains)} domain(s) "
            f"reported the same signal in the last {hours}h."
        )
        alignment = mission_alignment(
            domain=domains[0] if domains else "",
            evidence_text=" ".join(row["finding"] or "" for row in group[:5]),
        )
        convergence_score = min(1.0, (len(engines) - 1) / 5)
        candidates.append(
            BreakthroughCandidate(
                source_evidence_ids=[row["id"] for row in group],
                domains=domains,
                engines=sorted(engines),
                evidence_type=ev_type,
                summary=summary,
                convergence_score=convergence_score,
                mission_impact=alignment["overall"],
                pillar_scores={k: v for k, v in alignment.items() if k != "overall"},
                reasons=[
                    f"{len(engines)} independent engines agree",
                    f"Signal appeared in {len(domains)} domain(s)",
                ],
            )
        )
    return candidates


# ---------------------------------------------------------------------------
# Anomaly amplification
# ---------------------------------------------------------------------------


def detect_anomalies(
    *,
    db_path: str = DEFAULT_DB,
    hours: int = 24,
    min_samples: int = 8,
) -> list[BreakthroughCandidate]:
    """Promote evidence that is a statistical outlier in its engine.

    For every engine with at least ``min_samples`` recent findings, we
    compute the mean and standard deviation of ``confidence``. Any
    finding with confidence more than :data:`SIGMA_THRESHOLD` sigmas
    above the mean becomes a breakthrough candidate.
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = _recent_evidence(conn, hours=hours * 4)
    finally:
        conn.close()

    by_engine: dict[str, list[sqlite3.Row]] = {}
    for row in rows:
        if row["evidence_type"] in _SKIP_TYPES:
            continue
        by_engine.setdefault(row["engine"], []).append(row)

    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    candidates: list[BreakthroughCandidate] = []
    for engine, engine_rows in by_engine.items():
        if len(engine_rows) < min_samples:
            continue
        confidences = [float(r["confidence"] or 0.0) for r in engine_rows]
        if not confidences:
            continue
        try:
            mean = statistics.fmean(confidences)
            stdev = statistics.pstdev(confidences) or 0.0
        except statistics.StatisticsError:
            continue
        if stdev == 0:
            continue
        for row in engine_rows:
            try:
                ts = datetime.fromisoformat((row["timestamp"] or "").replace("Z", "+00:00"))
            except ValueError:
                continue
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            if ts < cutoff:
                continue
            conf = float(row["confidence"] or 0.0)
            sigma = (conf - mean) / stdev
            if sigma < SIGMA_THRESHOLD:
                continue
            alignment = mission_alignment(
                domain=row["domain"] or "",
                evidence_text=row["finding"] or "",
            )
            summary = (
                f"{engine} produced a {sigma:.1f}-sigma outlier in its "
                f"confidence distribution (conf={conf:.2f}, "
                f"mean={mean:.2f}, stdev={stdev:.2f})."
            )
            candidates.append(
                BreakthroughCandidate(
                    source_evidence_ids=[row["id"]],
                    domains=[row["domain"] or ""],
                    engines=[engine],
                    evidence_type=f"anomaly_{row['evidence_type']}",
                    summary=summary,
                    convergence_score=min(1.0, sigma / 6.0),
                    mission_impact=alignment["overall"],
                    pillar_scores={k: v for k, v in alignment.items() if k != "overall"},
                    reasons=[
                        f"{sigma:.1f} sigma above engine baseline",
                        "Confidence distribution is stable elsewhere",
                    ],
                )
            )
    return candidates


# ---------------------------------------------------------------------------
# Mission-critical surfacing
# ---------------------------------------------------------------------------


def detect_mission_critical(
    *,
    db_path: str = DEFAULT_DB,
    hours: int = 24,
    min_alignment: float = 0.65,
) -> list[BreakthroughCandidate]:
    """Return recent evidence whose mission alignment exceeds a threshold.

    Any single finding with ``mission_alignment.overall`` at or above
    ``min_alignment`` becomes a breakthrough candidate without needing
    convergence or anomaly support. This catches single-source finds
    that obviously advance the mission (e.g. a confirmed spec ship,
    a new critical CVE, a major narrative opportunity).
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = _recent_evidence(conn, hours=hours)
    finally:
        conn.close()

    candidates: list[BreakthroughCandidate] = []
    for row in rows:
        if row["evidence_type"] in _SKIP_TYPES:
            continue
        alignment = mission_alignment(
            domain=row["domain"] or "",
            evidence_text=row["finding"] or "",
        )
        if alignment["overall"] < min_alignment:
            continue
        best_pillar = max(
            (p for p in PILLARS),
            key=lambda p: alignment.get(p.key, 0.0),
        )
        summary = (
            f"Mission-critical finding advances pillar '{best_pillar.key}' "
            f"(alignment {alignment['overall']:.2f})."
        )
        candidates.append(
            BreakthroughCandidate(
                source_evidence_ids=[row["id"]],
                domains=[row["domain"] or ""],
                engines=[row["engine"] or ""],
                evidence_type=f"mission_critical_{row['evidence_type']}",
                summary=summary,
                convergence_score=float(row["confidence"] or 0.0),
                mission_impact=alignment["overall"],
                pillar_scores={k: v for k, v in alignment.items() if k != "overall"},
                reasons=[
                    f"Aligns strongly with '{best_pillar.title}'",
                    f"Base confidence {float(row['confidence'] or 0.0):.2f}",
                ],
            )
        )
    return candidates


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------


def _candidate_key(candidate: BreakthroughCandidate) -> str:
    """Deterministic key used to deduplicate candidates across detectors."""
    ids = sorted(candidate.source_evidence_ids)
    return f"{candidate.evidence_type}|{','.join(str(i) for i in ids)}"


def run_breakthrough_hunt(
    *,
    db_path: str = DEFAULT_DB,
    hours: int = 24,
    top_n: int = 10,
) -> list[BreakthroughCandidate]:
    """Run every detector and return the top-N breakthrough candidates.

    Args:
        db_path: Path to ``engine.db``.
        hours: Lookback window in hours for all detectors.
        top_n: Maximum number of candidates to return after dedup.

    Returns:
        A list sorted by :attr:`BreakthroughCandidate.rank` descending.
    """
    all_candidates: dict[str, BreakthroughCandidate] = {}
    for detector in (
        detect_convergence,
        detect_anomalies,
        detect_mission_critical,
    ):
        try:
            for candidate in detector(db_path=db_path, hours=hours):
                key = _candidate_key(candidate)
                existing = all_candidates.get(key)
                if existing is None or candidate.rank > existing.rank:
                    all_candidates[key] = candidate
        except Exception as exc:  # defensive - never abort the run
            logger.warning(
                "Breakthrough detector %s failed: %s",
                detector.__name__,
                exc,
            )

    ranked = sorted(
        all_candidates.values(),
        key=lambda c: c.rank,
        reverse=True,
    )
    return ranked[:top_n]


def persist_breakthroughs(
    candidates: list[BreakthroughCandidate],
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist breakthrough candidates as normal evidence rows.

    The evidence type is ``breakthrough_candidate`` so downstream
    consumers can filter on it. Returns the number of rows persisted.
    """
    if not candidates:
        return 0
    try:
        from core.persist_to_db import ensure_schema, persist_finding
    except Exception as exc:
        logger.warning("Breakthrough persistence unavailable: %s", exc)
        return 0
    ensure_schema(db_path)
    persisted = 0
    for candidate in candidates:
        finding = (
            f"WHAT: {candidate.summary} "
            f"SO WHAT: Mission impact {candidate.mission_impact:.2f}, "
            f"convergence {candidate.convergence_score:.2f}, "
            f"rank {candidate.rank:.2f}. "
            f"NOW WHAT: War Room should review next cycle. "
            f"Reasons: {'; '.join(candidate.reasons)}."
        )
        persist_finding(
            db_path=db_path,
            domain="breakthrough",
            engine="breakthrough_engine",
            evidence_type="breakthrough_candidate",
            finding=finding,
            confidence=max(
                0.55,
                min(0.95, 0.5 + 0.5 * candidate.rank),
            ),
            raw_data=candidate.to_raw(),
            source_repo="nebula",
        )
        persisted += 1
    logger.info("Breakthrough engine persisted %d candidates", persisted)
    return persisted


def export_report(
    candidates: list[BreakthroughCandidate],
) -> str:
    """Return a plain-text report summarising candidates.

    Handy for the nightly ``nebula findings`` rollup.
    """
    if not candidates:
        return "No breakthrough candidates in the current window."
    lines = ["Breakthrough candidates (ranked):", ""]
    for idx, candidate in enumerate(candidates, start=1):
        top_pillar = max(
            candidate.pillar_scores.items(),
            key=lambda kv: kv[1],
            default=("none", 0.0),
        )[0]
        lines.append(f"{idx:>2}. [{candidate.rank:.2f}] {candidate.evidence_type}")
        lines.append(f"    {candidate.summary}")
        lines.append(
            f"    pillar={top_pillar} "
            f"mission={candidate.mission_impact:.2f} "
            f"conv={candidate.convergence_score:.2f}"
        )
        lines.append(
            f"    engines={','.join(candidate.engines)} domains={','.join(candidate.domains)}"
        )
        lines.append("")
    return "\n".join(lines).rstrip()


__all__ = [
    "BreakthroughCandidate",
    "detect_anomalies",
    "detect_convergence",
    "detect_mission_critical",
    "export_report",
    "persist_breakthroughs",
    "run_breakthrough_hunt",
]
