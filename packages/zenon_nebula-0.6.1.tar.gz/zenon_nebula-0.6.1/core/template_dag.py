# SPDX-License-Identifier: MIT
"""
TemplateDAG -- DAG-based execution orchestrator for DiscoveryTemplates.

Manages execution ordering, parallel dispatch via ThreadPoolExecutor,
checkpoint/recovery, and template auto-discovery. Each node wraps a
DiscoveryTemplate subclass and stores its TemplateResult on completion.

After each node finishes, the DAGExecutor optionally calls into a
validation callback so every significant finding enters processing
immediately.

Generalized from marketing's template_dag.py. Domain-agnostic: works
with any DiscoveryTemplate subclass from any domain.

Requires: networkx
"""

import importlib
import inspect
import json
import logging
import os
import sys
import time
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

try:
    import networkx as nx
except ImportError:
    nx = None  # type: ignore[assignment]

from core.discovery_base import DiscoveryTemplate, TemplateResult

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
DEFAULT_CHECKPOINT_DIR = str(ENGINE_ROOT / "data" / "checkpoints")


# ---------------------------------------------------------------------------
# Node state
# ---------------------------------------------------------------------------


class NodeState(str, Enum):
    """Execution state of a DAG node."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class DAGNode:
    """Metadata attached to each node in the DAG."""

    name: str
    template_class: type  # subclass of DiscoveryTemplate
    params: dict = field(default_factory=dict)
    depends_on: list[str] = field(default_factory=list)
    state: NodeState = NodeState.PENDING
    result: TemplateResult | None = None
    error: str | None = None
    started_at: str | None = None
    finished_at: str | None = None


# ---------------------------------------------------------------------------
# TemplateDAG
# ---------------------------------------------------------------------------


class TemplateDAG:
    """Directed acyclic graph of DiscoveryTemplate execution nodes."""

    def __init__(self) -> None:
        if nx is None:
            raise ImportError("networkx is required for TemplateDAG")
        self._graph: nx.DiGraph = nx.DiGraph()
        self._nodes: dict[str, DAGNode] = {}

    # -- Mutation -----------------------------------------------------------

    def add_node(
        self,
        name: str,
        template_class: type,
        params: dict | None = None,
        depends_on: list[str] | None = None,
    ) -> None:
        """Register a template as a node in the DAG.

        Args:
            name:           Unique node identifier.
            template_class: A DiscoveryTemplate subclass.
            params:         Parameters forwarded to ``template.execute()``.
            depends_on:     List of node names that must complete first.

        Raises:
            ValueError: If the name collides, or adding the edge creates a cycle.
        """
        if name in self._nodes:
            raise ValueError(f"Node '{name}' already exists in DAG")

        depends_on = depends_on or []
        params = params or {}

        node = DAGNode(
            name=name,
            template_class=template_class,
            params=params,
            depends_on=depends_on,
        )
        self._nodes[name] = node
        self._graph.add_node(name)

        for dep in depends_on:
            if dep not in self._nodes:
                raise ValueError(f"Dependency '{dep}' for node '{name}' does not exist in the DAG")
            self._graph.add_edge(dep, name)

        # Cycle check
        if not nx.is_directed_acyclic_graph(self._graph):
            self._graph.remove_node(name)
            del self._nodes[name]
            raise ValueError(f"Adding node '{name}' with deps {depends_on} creates a cycle")

    # -- Queries ------------------------------------------------------------

    def get_execution_order(self) -> list[str]:
        """Return a topological ordering of all node names."""
        return list(nx.topological_sort(self._graph))

    def get_ready_nodes(self) -> list[str]:
        """Return node names whose dependencies are all completed."""
        ready = []
        for name, node in self._nodes.items():
            if node.state != NodeState.PENDING:
                continue
            deps_failed = any(
                self._nodes[dep].state in (NodeState.FAILED, NodeState.SKIPPED)
                for dep in node.depends_on
            )
            if deps_failed:
                node.state = NodeState.SKIPPED
                node.error = "Dependency failed or skipped"
                continue
            deps_met = all(self._nodes[dep].state == NodeState.COMPLETED for dep in node.depends_on)
            if deps_met:
                ready.append(name)
        return ready

    def mark_completed(self, name: str, result: TemplateResult) -> None:
        """Mark a node as completed and store its result."""
        node = self._nodes[name]
        node.state = NodeState.COMPLETED
        node.result = result
        node.finished_at = datetime.now(timezone.utc).isoformat()

    def mark_failed(self, name: str, error: str) -> None:
        """Mark a node as failed with an error message."""
        node = self._nodes[name]
        node.state = NodeState.FAILED
        node.error = error
        node.finished_at = datetime.now(timezone.utc).isoformat()

    def mark_running(self, name: str) -> None:
        """Mark a node as currently running."""
        node = self._nodes[name]
        node.state = NodeState.RUNNING
        node.started_at = datetime.now(timezone.utc).isoformat()

    def get_results(self, name: str) -> TemplateResult | None:
        """Get the results of a completed node, or None."""
        node = self._nodes.get(name)
        return node.result if node else None

    def get_node(self, name: str) -> DAGNode | None:
        """Get a DAGNode by name."""
        return self._nodes.get(name)

    def is_complete(self) -> bool:
        """True when every node is in a terminal state."""
        return all(
            n.state in (NodeState.COMPLETED, NodeState.FAILED, NodeState.SKIPPED)
            for n in self._nodes.values()
        )

    @property
    def node_count(self) -> int:
        """Total number of nodes in the DAG."""
        return len(self._nodes)

    @property
    def completed_count(self) -> int:
        """Number of nodes that completed successfully."""
        return sum(1 for n in self._nodes.values() if n.state == NodeState.COMPLETED)

    @property
    def failed_count(self) -> int:
        """Number of nodes that failed or were skipped."""
        return sum(
            1 for n in self._nodes.values() if n.state in (NodeState.FAILED, NodeState.SKIPPED)
        )

    def summary(self) -> dict:
        """Return a compact status dict."""
        return {
            "total": self.node_count,
            "completed": self.completed_count,
            "failed": self.failed_count,
            "pending": sum(1 for n in self._nodes.values() if n.state == NodeState.PENDING),
            "running": sum(1 for n in self._nodes.values() if n.state == NodeState.RUNNING),
        }

    # -- Checkpoint / Recovery ----------------------------------------------

    def save_checkpoint(self, path: str) -> None:
        """Serialize DAG state to JSON for crash recovery."""
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        data: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "nodes": {},
        }
        for name, node in self._nodes.items():
            node_data: dict[str, Any] = {
                "template_class_name": node.template_class.__name__,
                "template_module": node.template_class.__module__,
                "params": node.params,
                "depends_on": node.depends_on,
                "state": node.state.value,
                "error": node.error,
                "started_at": node.started_at,
                "finished_at": node.finished_at,
            }
            if node.result:
                node_data["result_summary"] = {
                    "template_name": node.result.template_name,
                    "analysis_type": node.result.analysis_type,
                    "summary": node.result.summary,
                    "persisted_id": node.result.persisted_id,
                    "elapsed_seconds": node.result.elapsed_seconds,
                }
            data["nodes"][name] = node_data

        with open(path, "w") as f:
            json.dump(data, f, indent=2)
        logger.info("Checkpoint saved to %s (%d nodes)", path, len(self._nodes))

    @classmethod
    def load_checkpoint(
        cls,
        path: str,
        template_registry: dict[str, type] | None = None,
    ) -> "TemplateDAG":
        """Restore DAG state from a JSON checkpoint.

        Args:
            path:              Path to the checkpoint JSON.
            template_registry: Mapping of class name -> template class.

        Returns:
            A TemplateDAG with node states restored. Completed/failed nodes
            keep their terminal state; pending/running nodes reset to pending.
        """
        template_registry = template_registry or {}

        with open(path) as f:
            data = json.load(f)

        dag = cls()
        node_data_map = data.get("nodes", {})

        # Topological ordering from stored depends_on
        remaining = dict(node_data_map)
        ordered_names: list[str] = []
        added: set[str] = set()
        while remaining:
            progress = False
            for name, nd in list(remaining.items()):
                deps = nd.get("depends_on", [])
                if all(d in added for d in deps):
                    ordered_names.append(name)
                    added.add(name)
                    del remaining[name]
                    progress = True
            if not progress:
                ordered_names.extend(remaining.keys())
                break

        for name in ordered_names:
            nd = node_data_map[name]
            class_name = nd["template_class_name"]
            tpl_class = template_registry.get(class_name)
            if tpl_class is None:
                logger.warning(
                    "Template class '%s' not in registry -- node '%s' will use base",
                    class_name,
                    name,
                )
                tpl_class = DiscoveryTemplate  # type: ignore[assignment]

            try:
                dag.add_node(
                    name=name,
                    template_class=tpl_class,
                    params=nd.get("params", {}),
                    depends_on=nd.get("depends_on", []),
                )
            except ValueError as e:
                logger.warning("Skipping node '%s' during checkpoint load: %s", name, e)
                continue

            node = dag._nodes[name]
            saved_state = nd.get("state", "pending")
            if saved_state in (
                NodeState.COMPLETED.value,
                NodeState.FAILED.value,
                NodeState.SKIPPED.value,
            ):
                node.state = NodeState(saved_state)
            else:
                node.state = NodeState.PENDING
            node.error = nd.get("error")
            node.started_at = nd.get("started_at")
            node.finished_at = nd.get("finished_at")

        logger.info("Checkpoint loaded from %s (%d nodes)", path, dag.node_count)
        return dag


# ---------------------------------------------------------------------------
# DAGExecutor
# ---------------------------------------------------------------------------


class DAGExecutor:
    """Execute a TemplateDAG with parallel dispatch.

    Uses ThreadPoolExecutor for concurrent template execution, respecting
    DAG dependencies. After each node completes, optionally triggers a
    callback for downstream processing of findings.
    """

    def __init__(
        self,
        dag: TemplateDAG,
        db_path: str = DEFAULT_DB,
        max_api_threads: int = 5,
        max_compute_threads: int = 4,
        checkpoint_dir: str = DEFAULT_CHECKPOINT_DIR,
        on_complete: Callable[[str, TemplateResult], None] | None = None,
    ) -> None:
        """
        Args:
            dag:                 The TemplateDAG to execute.
            db_path:             SQLite database path.
            max_api_threads:     Threads for API-bound templates (tier 1-2).
            max_compute_threads: Threads for compute-bound templates (tier 3-5).
            checkpoint_dir:      Directory for checkpoint files.
            on_complete:         Optional callback ``(node_name, result)`` called
                                 after each successful node completion.
        """
        self.dag = dag
        self.db_path = db_path
        self.max_api_threads = max_api_threads
        self.max_compute_threads = max_compute_threads
        self.checkpoint_dir = checkpoint_dir
        self.on_complete = on_complete

    def run(self) -> dict:
        """Execute the full DAG, returning a summary dict."""
        start = time.monotonic()
        os.makedirs(self.checkpoint_dir, exist_ok=True)
        checkpoint_path = os.path.join(
            self.checkpoint_dir,
            f"dag_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json",
        )

        logger.info(
            "DAG execution starting: %d nodes, api_threads=%d, compute_threads=%d",
            self.dag.node_count,
            self.max_api_threads,
            self.max_compute_threads,
        )

        with (
            ThreadPoolExecutor(
                max_workers=self.max_api_threads,
                thread_name_prefix="api",
            ) as api_pool,
            ThreadPoolExecutor(
                max_workers=self.max_compute_threads,
                thread_name_prefix="compute",
            ) as compute_pool,
        ):
            futures: dict[Future, str] = {}

            while not self.dag.is_complete():
                ready = self.dag.get_ready_nodes()

                if not ready and not futures:
                    logger.warning("DAG stalled: no ready nodes and no in-flight futures")
                    break

                for node_name in ready:
                    node = self.dag.get_node(node_name)
                    if node is None:
                        continue

                    self.dag.mark_running(node_name)

                    tier = getattr(node.template_class, "tier", 3)
                    pool = api_pool if tier <= 2 else compute_pool

                    future = pool.submit(self._execute_node, node)
                    futures[future] = node_name

                if not futures:
                    break

                # Wait for at least one to complete
                for future in as_completed(futures):
                    node_name = futures.pop(future)
                    try:
                        result = future.result()
                        self.dag.mark_completed(node_name, result)
                        logger.info(
                            "Node '%s' completed in %.1fs",
                            node_name,
                            result.elapsed_seconds,
                        )
                        if self.on_complete:
                            try:
                                self.on_complete(node_name, result)
                            except Exception as exc:
                                logger.error(
                                    "on_complete callback failed for '%s': %s",
                                    node_name,
                                    exc,
                                )
                    except Exception as exc:
                        self.dag.mark_failed(node_name, str(exc))
                        logger.error("Node '%s' failed: %s", node_name, exc)

                    try:
                        self.dag.save_checkpoint(checkpoint_path)
                    except Exception as exc:
                        logger.warning("Checkpoint save failed: %s", exc)

                    break  # Re-check ready nodes after each completion

        elapsed = time.monotonic() - start
        summary = self.dag.summary()
        summary["elapsed_seconds"] = round(elapsed, 2)

        logger.info(
            "DAG execution complete: %d/%d succeeded in %.1fs",
            summary["completed"],
            summary["total"],
            elapsed,
        )
        return summary

    def _execute_node(self, node: DAGNode) -> TemplateResult:
        """Instantiate and execute a single template node."""
        template = node.template_class()
        return template.execute(
            params=node.params,
            db_path=self.db_path,
        )


# ---------------------------------------------------------------------------
# Template auto-discovery
# ---------------------------------------------------------------------------


def discover_templates(directory: str | Path) -> dict[str, type]:
    """Scan a directory for DiscoveryTemplate subclasses.

    Imports every .py file in *directory* (non-recursively) and collects
    concrete subclasses of DiscoveryTemplate that define ``analysis_type``.

    Args:
        directory: Path to scan for template modules.

    Returns:
        Dict mapping ``analysis_type`` -> template class.
    """
    directory = Path(directory)
    if not directory.is_dir():
        logger.warning("Template directory does not exist: %s", directory)
        return {}

    dir_str = str(directory)
    if dir_str not in sys.path:
        sys.path.insert(0, dir_str)

    registry: dict[str, type] = {}

    for py_file in sorted(directory.glob("*.py")):
        if py_file.name.startswith("_"):
            continue

        module_name = py_file.stem
        try:
            spec = importlib.util.spec_from_file_location(module_name, str(py_file))
            if spec is None or spec.loader is None:
                continue
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)  # type: ignore[union-attr]
        except Exception as exc:
            logger.debug("Skipping %s: %s", py_file.name, exc)
            continue

        for _, obj in inspect.getmembers(mod, inspect.isclass):
            if (
                issubclass(obj, DiscoveryTemplate)
                and obj is not DiscoveryTemplate
                and hasattr(obj, "analysis_type")
                and not inspect.isabstract(obj)
            ):
                analysis_type = getattr(obj, "analysis_type", None)
                if analysis_type:
                    registry[analysis_type] = obj
                    logger.debug(
                        "Discovered template: %s -> %s",
                        analysis_type,
                        obj.__name__,
                    )

    logger.info(
        "Template discovery in %s: found %d templates",
        directory,
        len(registry),
    )
    return registry
