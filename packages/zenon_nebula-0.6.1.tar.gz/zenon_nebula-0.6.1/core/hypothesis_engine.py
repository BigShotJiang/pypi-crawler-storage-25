# SPDX-License-Identifier: MIT
"""Backward-compatibility shim for ``core.hypotheses.engine``.

The real implementation lives in :mod:`core.hypotheses.engine`. This
module re-exports the public API (and the private helpers that tests
import directly) so existing call sites keep working unchanged.
"""

from core.hypotheses.engine import (  # noqa: F401
    DEFAULT_DB,
    ENGINE_ROOT,
    EVIDENCE_WINDOW_HOURS,
    MIN_CLUSTER_SIZE,
    PATTERNS,
    PROMOTE_CONFIDENCE,
    RETIRE_AGE_DAYS,
    RETIRE_CONFIDENCE,
    _get_all_hypotheses,
    _get_recent_evidence,
    _link_evidence_to_hypothesis,
    _manage_lifecycle,
    _pattern_convergent_findings,
    _pattern_liquidity_anomaly,
    _pattern_peer_agreement,
    _pattern_quality_regression,
    _pattern_security_cluster,
    _pattern_spec_progress,
    _pattern_stalled_domain,
    _pattern_upstream_breaking,
    evolve,
)

__all__ = [
    "DEFAULT_DB",
    "EVIDENCE_WINDOW_HOURS",
    "MIN_CLUSTER_SIZE",
    "PATTERNS",
    "PROMOTE_CONFIDENCE",
    "RETIRE_AGE_DAYS",
    "RETIRE_CONFIDENCE",
    "evolve",
]
