# SPDX-License-Identifier: MIT
"""
Zenon Unified Engine -- Core Framework

Multi-domain autonomous engine for Zenon Network ecosystem operations.
Generalized from the marketing domain's discovery_core and mystery_engine
patterns into a domain-agnostic plugin architecture.

Core modules:
    domain_registry     -- DomainPlugin ABC + DomainRegistry singleton
    persist_to_db       -- SQLite persistence with domain column, Bayesian updates
    api_fingerprint     -- FingerprintedSession for HTTP provenance tracking
    feedback_bus        -- SQLite-backed inter-agent message queue
    model_router        -- LLM routing by task type (Opus/Sonnet/Haiku/Grok)
    evidence_vault      -- SHA-256 integrity vault for verified findings
    opsec               -- Identity sanitization for all external communications
    hallucination_guard -- Anti-hallucination claim verification
    discovery_base      -- DiscoveryTemplate ABC for investigation/analysis templates
    run_context         -- Execution context with budget tracking
    corpus              -- Indexed corpus manager for 160+ repos
    curiosity           -- Autonomous exploration and discovery engine

Quality assurance modules (make findings reliable, not just numerous):
    hypothesis_hardener -- Stress-tests high-confidence hypotheses for fragility
    novelty_checker     -- Detects novel findings vs duplicates via text similarity
    anomaly_detector    -- Z-score + burst + silence detection per engine
    finding_verifier    -- Provenance trace and source-drift check per finding
    failure_classifier  -- Classifies engine errors for intelligent retry
    plausibility_gate   -- Pre-persistence sanity checks (wired into persist_finding)
"""

# Single source of truth: core/version.py. Prevents the drift that
# caused v0.2.0's first smoke test to fail with
#   Installed version: 0.1.0 != tag 0.2.0
from core.version import __version__, __version_info__  # noqa: F401
