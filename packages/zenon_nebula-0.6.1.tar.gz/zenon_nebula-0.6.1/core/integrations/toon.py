# SPDX-License-Identifier: MIT
"""
TOON Format — Token-Oriented Object Notation for 40% fewer LLM tokens.

From zenon-red: https://toonformat.dev

TOON is a compact serialization format designed for LLM consumption.
Instead of JSON's verbose syntax, TOON uses minimal delimiters:

JSON (57 tokens):
    {"name": "PTLC", "status": "implemented", "coverage": 0.95}

TOON (~34 tokens):
    name=PTLC status=implemented coverage=0.95

For Nebula, this means:
- War Room battle plans use 40% fewer tokens
- Director evidence landscapes are more compact
- LLM context windows fit more data
- API costs reduced proportionally
"""

import json
from typing import Any


def to_toon(data: Any, depth: int = 0) -> str:
    """Convert Python object to TOON format.

    Compact, LLM-friendly serialization.
    """
    if data is None:
        return "~"
    if isinstance(data, bool):
        return "true" if data else "false"
    if isinstance(data, (int, float)):
        return str(data)
    if isinstance(data, str):
        # Quote only if contains spaces or special chars
        if " " in data or "=" in data or "\n" in data:
            return f'"{data}"'
        return data

    indent = "  " * depth

    if isinstance(data, dict):
        if not data:
            return "{}"
        lines = []
        for k, v in data.items():
            val = to_toon(v, depth + 1)
            if isinstance(v, (dict, list)) and v:
                lines.append(f"{indent}{k}:")
                lines.append(val)
            else:
                lines.append(f"{indent}{k}={val}")
        return "\n".join(lines)

    if isinstance(data, (list, tuple)):
        if not data:
            return "[]"
        lines = []
        for item in data:
            val = to_toon(item, depth + 1)
            lines.append(f"{indent}- {val}")
        return "\n".join(lines)

    return str(data)


def from_json_to_toon(json_str: str) -> str:
    """Convert JSON string to TOON format."""
    data = json.loads(json_str)
    return to_toon(data)


def estimate_token_savings(data: Any) -> dict:
    """Estimate token savings from using TOON vs JSON.

    Rough heuristic: 1 token ~= 4 chars for English text.
    """
    json_str = json.dumps(data, indent=2)
    toon_str = to_toon(data)

    json_tokens = len(json_str) / 4
    toon_tokens = len(toon_str) / 4
    savings_pct = (1 - toon_tokens / json_tokens) * 100 if json_tokens > 0 else 0

    return {
        "json_chars": len(json_str),
        "toon_chars": len(toon_str),
        "estimated_json_tokens": int(json_tokens),
        "estimated_toon_tokens": int(toon_tokens),
        "savings_pct": round(savings_pct, 1),
    }
