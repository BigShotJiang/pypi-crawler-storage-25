# SPDX-License-Identifier: MIT
"""
Probe Integration — Nexus task management via zenon-red's CLI.

Nebula registers as a Nexus agent and can:
- Claim tasks from the community task board
- Report progress on claimed tasks
- Submit completed work
- Send messages to other agents
- Vote on proposals

Requires Probe to be installed: npm install -g @zenon-red/probe
"""

import json
import logging
import subprocess

logger = logging.getLogger(__name__)

PROBE_CLI = "probe"


def claim_task(task_id: str) -> dict | None:
    """Claim a Nexus task for this Nebula instance."""
    return _run_probe("task", "claim", task_id)


def report_progress(task_id: str, message: str) -> dict | None:
    """Report progress on a claimed task."""
    return _run_probe("task", "update", task_id, "--status", "in_progress", "--message", message)


def submit_work(task_id: str, pr_url: str = "", notes: str = "") -> dict | None:
    """Mark a task as complete with submission details."""
    cmd = ["task", "update", task_id, "--status", "completed"]
    if pr_url:
        cmd.extend(["--pr", pr_url])
    if notes:
        cmd.extend(["--message", notes])
    return _run_probe(*cmd)


def send_message(channel: str, message: str) -> dict | None:
    """Send a message to a Nexus channel."""
    return _run_probe("message", "send", channel, message)


def get_tasks(status: str = "open", limit: int = 20) -> list:
    """Get tasks from Nexus."""
    result = _run_probe("task", "list", "--status", status, "--limit", str(limit))
    if result and isinstance(result, list):
        return result
    return []


def heartbeat(agent_name: str = "nebula", status: str = "active") -> dict | None:
    """Send heartbeat to Nexus — tells the network Nebula is alive."""
    return _run_probe("agent", "heartbeat", "--name", agent_name, "--status", status)


def is_available() -> bool:
    """Check if Probe is installed."""
    try:
        result = subprocess.run([PROBE_CLI, "--version"], capture_output=True, timeout=5)
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _run_probe(*args) -> dict | None:
    """Run a Probe CLI command and parse output."""
    try:
        cmd = [PROBE_CLI, *list(args), "--format", "json"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0 and result.stdout.strip():
            return json.loads(result.stdout)
    except FileNotFoundError:
        logger.debug("Probe CLI not found. Install with: npm install -g @zenon-red/probe")
    except (json.JSONDecodeError, subprocess.TimeoutExpired, Exception) as e:
        logger.debug("Probe error: %s", e)
    return None
