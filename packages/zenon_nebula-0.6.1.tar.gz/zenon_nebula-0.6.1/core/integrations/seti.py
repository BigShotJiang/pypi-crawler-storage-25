# SPDX-License-Identifier: MIT
"""
SETI Integration — Free web search via zenon-red's SearXNG MCP server.

Replaces paid search API calls (Grok x_search, Google, etc.) with
self-hosted SearXNG. Zero cost, unlimited queries, private.

Usage:
    results = search("Zenon Network Bitcoin bridge")
    results = search("PTLC atomic swap", categories=["it", "science"])

Requires SETI to be running locally or as MCP server.
Falls back to subprocess CLI if MCP not available.
"""

import json
import logging
import subprocess

logger = logging.getLogger(__name__)

SETI_CLI = "seti"  # Assumes seti is on PATH (npm install -g @zenon-red/seti)


def search(
    query: str,
    categories: list | None = None,
    max_results: int = 10,
    enrich: bool = False,
) -> list:
    """Search the web via SETI (free, self-hosted).

    Args:
        query: Search query string
        categories: SearXNG categories (e.g., ["it", "science", "news"])
        max_results: Maximum results to return
        enrich: If True, fetch full page content via Jina Reader

    Returns:
        List of result dicts with: title, url, snippet, (content if enriched)
    """
    cmd = [SETI_CLI, "search", query, "--format", "json", "--limit", str(max_results)]

    if categories:
        cmd.extend(["--categories", ",".join(categories)])
    if enrich:
        cmd.append("--enrich")

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0 and result.stdout.strip():
            data = json.loads(result.stdout)
            if isinstance(data, list):
                return data
            elif isinstance(data, dict) and "results" in data:
                return data["results"][:max_results]
    except FileNotFoundError:
        logger.warning("SETI CLI not found. Install with: npm install -g @zenon-red/seti")
    except subprocess.TimeoutExpired:
        logger.warning("SETI search timed out for query: %s", query[:50])
    except (json.JSONDecodeError, Exception) as e:
        logger.warning("SETI search error: %s", e)

    return []


def is_available() -> bool:
    """Check if SETI is installed and working."""
    try:
        result = subprocess.run([SETI_CLI, "--version"], capture_output=True, timeout=5)
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
