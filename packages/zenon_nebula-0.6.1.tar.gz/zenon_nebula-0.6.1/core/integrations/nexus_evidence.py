# SPDX-License-Identifier: MIT
"""
NexusEvidenceBridge -- Bidirectional sync between Nebula evidence and Nexus.

When findings are verified locally, publish them as Nexus table entries
via Probe. When Nexus has new entries from other participants, pull them
into the local evidence DB.

Requires Probe to be installed: npm install -g @zenon-red/probe

This is the bridge between Nebula's local SQLite evidence store and
Nexus's SpacetimeDB distributed state. Enables multi-agent collaboration
on evidence gathering and hypothesis testing.

Reads:  evidence table (local)
Writes: evidence table (local), Nexus tables (remote via Probe)
"""

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Nexus table names for evidence exchange
NEXUS_EVIDENCE_TABLE = "nebula_evidence"
NEXUS_HYPOTHESIS_TABLE = "nebula_hypotheses"

# Minimum confidence to publish to Nexus
MIN_PUBLISH_CONFIDENCE = 0.6

# Agent identity for Nexus
NEBULA_AGENT_NAME = "nebula"


# ---------------------------------------------------------------------------
# NexusEvidenceBridge
# ---------------------------------------------------------------------------


class NexusEvidenceBridge:
    """Bidirectional evidence sync between Nebula and Nexus.

    Usage::

        bridge = NexusEvidenceBridge()
        if bridge.is_available():
            bridge.publish_verified_evidence()
            bridge.pull_remote_evidence()
    """

    def __init__(self, db_path: str = DEFAULT_DB) -> None:
        self.db_path = db_path
        self._probe_available: bool | None = None

    def is_available(self) -> bool:
        """Check if Probe CLI is installed and Nexus is reachable."""
        if self._probe_available is None:
            try:
                from core.integrations.probe import is_available

                self._probe_available = is_available()
            except ImportError:
                self._probe_available = False
        return self._probe_available

    # ------------------------------------------------------------------
    # Publish: Nebula -> Nexus
    # ------------------------------------------------------------------

    def publish_verified_evidence(
        self,
        min_confidence: float = MIN_PUBLISH_CONFIDENCE,
        limit: int = 50,
    ) -> dict:
        """Publish high-confidence local evidence to Nexus.

        Only publishes evidence that:
        - Has confidence >= min_confidence
        - Has provenance of 'verified_by_api' or 'computational'
        - Has not already been published (published=0)

        Args:
            min_confidence: Minimum confidence threshold.
            limit:          Maximum number of findings to publish per call.

        Returns:
            Dict with published_count, skipped_count, errors.
        """
        if not self.is_available():
            return {"published_count": 0, "error": "Probe not available"}

        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row
        published_count = 0
        skipped_count = 0
        errors: list[str] = []

        try:
            rows = conn.execute(
                """SELECT id, engine, evidence_type, finding, confidence,
                          supports_hypothesis, contradicts_hypothesis,
                          provenance, domain, timestamp
                   FROM evidence
                   WHERE published = 0
                     AND confidence >= ?
                     AND provenance IN ('verified_by_api', 'computational')
                   ORDER BY confidence DESC
                   LIMIT ?""",
                (min_confidence, limit),
            ).fetchall()

            for row in rows:
                try:
                    success = self._publish_to_nexus(dict(row))
                    if success:
                        # Mark as published locally
                        conn.execute(
                            "UPDATE evidence SET published = 1 WHERE id = ?",
                            (row["id"],),
                        )
                        published_count += 1
                    else:
                        skipped_count += 1
                except Exception as exc:
                    errors.append(f"Evidence #{row['id']}: {exc}")
                    skipped_count += 1

            conn.commit()

        finally:
            conn.close()

        logger.info(
            "Published %d findings to Nexus (%d skipped, %d errors)",
            published_count,
            skipped_count,
            len(errors),
        )

        return {
            "published_count": published_count,
            "skipped_count": skipped_count,
            "errors": errors,
        }

    def _publish_to_nexus(self, evidence: dict) -> bool:
        """Publish a single evidence record to Nexus via Probe.

        Args:
            evidence: Dict with evidence fields.

        Returns:
            True if published successfully.
        """
        try:
            from core.integrations.probe import send_message

            payload = {
                "source_agent": NEBULA_AGENT_NAME,
                "evidence_id": evidence.get("id"),
                "engine": evidence.get("engine", ""),
                "evidence_type": evidence.get("evidence_type", ""),
                "finding": (evidence.get("finding") or "")[:500],
                "confidence": evidence.get("confidence", 0.0),
                "supports_hypothesis": evidence.get("supports_hypothesis", ""),
                "contradicts_hypothesis": evidence.get("contradicts_hypothesis", ""),
                "provenance": evidence.get("provenance", "hypothesis"),
                "domain": evidence.get("domain", "system"),
                "timestamp": evidence.get("timestamp", ""),
            }

            result = send_message(
                NEXUS_EVIDENCE_TABLE,
                json.dumps(payload),
            )

            return result is not None

        except ImportError:
            logger.debug("Probe integration not available")
            return False
        except Exception as exc:
            logger.warning("Failed to publish evidence to Nexus: %s", exc)
            return False

    # ------------------------------------------------------------------
    # Pull: Nexus -> Nebula
    # ------------------------------------------------------------------

    def pull_remote_evidence(self, limit: int = 50) -> dict:
        """Pull new evidence from Nexus into the local database.

        Queries Nexus for evidence published by other agents and
        imports any that are not already in the local DB (dedup by
        source_agent + evidence_id).

        Args:
            limit: Maximum entries to pull per call.

        Returns:
            Dict with imported_count, duplicate_count, errors.
        """
        if not self.is_available():
            return {"imported_count": 0, "error": "Probe not available"}

        try:
            from core.integrations.probe import get_tasks

            # Use Probe to query Nexus for evidence table entries
            # The API uses tasks as a generic query mechanism
            entries = get_tasks(status="evidence", limit=limit)
            if not entries:
                return {"imported_count": 0, "duplicate_count": 0, "errors": []}

        except (ImportError, Exception) as exc:
            return {"imported_count": 0, "error": str(exc)}

        imported = 0
        duplicates = 0
        errors: list[str] = []

        conn = connect(self.db_path)
        try:
            for entry in entries:
                try:
                    data = entry if isinstance(entry, dict) else json.loads(entry)

                    # Skip our own evidence
                    if data.get("source_agent") == NEBULA_AGENT_NAME:
                        duplicates += 1
                        continue

                    # Check for duplicates
                    source_agent = data.get("source_agent", "unknown")
                    data.get("evidence_id", "")
                    finding_text = data.get("finding", "")

                    existing = conn.execute(
                        """SELECT COUNT(*) FROM evidence
                           WHERE engine = ? AND finding = ?""",
                        (f"nexus:{source_agent}", finding_text),
                    ).fetchone()[0]

                    if existing > 0:
                        duplicates += 1
                        continue

                    # Import into local evidence table
                    conn.execute(
                        """INSERT INTO evidence
                           (engine, evidence_type, finding, confidence,
                            supports_hypothesis, contradicts_hypothesis,
                            provenance, domain, published)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)""",
                        (
                            f"nexus:{source_agent}",
                            data.get("evidence_type", "external"),
                            finding_text,
                            data.get("confidence", 0.5),
                            data.get("supports_hypothesis", ""),
                            data.get("contradicts_hypothesis", ""),
                            "external_agent",
                            data.get("domain", "system"),
                        ),
                    )
                    imported += 1

                except Exception as exc:
                    errors.append(str(exc))

            conn.commit()

        finally:
            conn.close()

        logger.info(
            "Pulled %d findings from Nexus (%d duplicates, %d errors)",
            imported,
            duplicates,
            len(errors),
        )

        return {
            "imported_count": imported,
            "duplicate_count": duplicates,
            "errors": errors,
        }

    # ------------------------------------------------------------------
    # Hypothesis sync
    # ------------------------------------------------------------------

    def publish_hypotheses(self) -> dict:
        """Publish active hypotheses to Nexus for community visibility.

        Returns:
            Dict with published_count, errors.
        """
        if not self.is_available():
            return {"published_count": 0, "error": "Probe not available"}

        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row
        published_count = 0
        errors: list[str] = []

        try:
            rows = conn.execute("SELECT * FROM hypotheses WHERE status = 'active'").fetchall()

            for row in rows:
                try:
                    from core.integrations.probe import send_message

                    payload = {
                        "source_agent": NEBULA_AGENT_NAME,
                        "hypothesis_id": row["id"],
                        "title": row["title"],
                        "confidence": row["confidence"],
                        "status": row["status"],
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }
                    result = send_message(
                        NEXUS_HYPOTHESIS_TABLE,
                        json.dumps(payload),
                    )
                    if result is not None:
                        published_count += 1
                except Exception as exc:
                    errors.append(f"Hypothesis {row['id']}: {exc}")

        except sqlite3.OperationalError:
            errors.append("hypotheses table not found")
        finally:
            conn.close()

        logger.info(
            "Published %d hypotheses to Nexus (%d errors)",
            published_count,
            len(errors),
        )

        return {
            "published_count": published_count,
            "errors": errors,
        }

    # ------------------------------------------------------------------
    # Full sync
    # ------------------------------------------------------------------

    def sync(self) -> dict:
        """Run a full bidirectional sync: publish + pull.

        Returns:
            Dict with publish_result and pull_result.
        """
        publish_result = self.publish_verified_evidence()
        pull_result = self.pull_remote_evidence()

        return {
            "publish_result": publish_result,
            "pull_result": pull_result,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
