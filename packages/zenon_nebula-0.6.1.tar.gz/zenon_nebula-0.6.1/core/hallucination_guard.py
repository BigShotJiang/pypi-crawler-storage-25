# SPDX-License-Identifier: MIT
"""
HallucinationGuard -- Verifies constants and claims against source files.

Generalized from marketing domain. Checks:
- Protocol constants against config/system.json
- Method/field names against a code knowledge base
- Addresses against known contract addresses
- Claims against evidence store

Output tags claims as:
  [VERIFIED]   -- backed by evidence with API provenance
  [CONFIRMED]  -- matches hardcoded protocol constants
  [THEORY]     -- LLM reasoning without direct source
  [UNVERIFIED] -- no backing found (flag for review)
"""

import contextlib
import json
import logging
import re
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
SYSTEM_CONFIG = ENGINE_ROOT / "config" / "system.json"
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# -- Protocol constants cache --

_PROTOCOL_FACTS: dict | None = None


def _load_protocol_facts() -> dict:
    """Load verified protocol constants from config/system.json."""
    global _PROTOCOL_FACTS
    if _PROTOCOL_FACTS is not None:
        return _PROTOCOL_FACTS
    try:
        config = json.loads(SYSTEM_CONFIG.read_text())
        _PROTOCOL_FACTS = config.get("zenon_facts", {})
    except (json.JSONDecodeError, OSError, FileNotFoundError):
        _PROTOCOL_FACTS = {}
    return _PROTOCOL_FACTS


# Mapping of natural language claim patterns to protocol fact keys
CLAIM_PATTERNS: dict[str, dict] = {
    r"(\d[\d,.]*)\s*ZNN\s*(per\s+day|daily|/day|emission)": {
        "fact_key": "daily_znn_emission",
        "type": "number",
    },
    r"(\d[\d,.]*)\s*QSR\s*(per\s+day|daily|/day|emission)": {
        "fact_key": "daily_qsr_emission",
        "type": "number",
    },
    r"(\d[\d,.]*)\s*ZNN\s*(orbital|LP\s*reward)": {
        "fact_key": "orbital_daily_znn",
        "type": "number",
    },
    r"(\d[\d,.]*)\s*QSR\s*(orbital|LP\s*reward)": {
        "fact_key": "orbital_daily_qsr",
        "type": "number",
    },
    r"(\d[\d,.]*)\s*ZNN\s*(to\s+(run|launch|create|deploy)\s+a\s+)?pillar": {
        "fact_key": "pillar_lock_znn",
        "type": "number",
    },
    r"(\d[\d,.]*)\s*QSR\s*(burn|to\s+burn).*(pillar)": {
        "fact_key": "pillar_min_burn_qsr",
        "type": "number",
    },
    r"(\d[\d,.]*)\s*ZNN\s*(to\s+(run|launch|create).*)?sentinel": {
        "fact_key": "sentinel_lock_znn",
        "type": "number",
    },
    r"(\d[\d,.]*)\s*QSR\s*(to\s+(run|launch|create).*)?sentinel": {
        "fact_key": "sentinel_lock_qsr",
        "type": "number",
    },
    r"max.*QSR.*supply.*?(\d[\d,.]+)": {
        "fact_key": "max_qsr_supply",
        "type": "number",
    },
}


@dataclass
class ClaimResult:
    """Result of checking a single claim."""

    claim_text: str
    status: str  # VERIFIED, CONFIRMED, THEORY, UNVERIFIED
    evidence: str | None = None
    source: str | None = None
    correct_value: str | None = None
    is_accurate: bool = True


@dataclass
class GuardResult:
    """Full hallucination check result."""

    content_original: str
    content_tagged: str
    claims_checked: int
    verified_count: int
    confirmed_count: int
    theory_count: int
    unverified_count: int
    inaccurate_count: int
    claims: list[ClaimResult] = field(default_factory=list)
    safe_to_publish: bool = True
    warnings: list[str] = field(default_factory=list)


class HallucinationGuard:
    """Verifies factual claims against known sources before publishing."""

    def __init__(self, db_path: str = DEFAULT_DB, dry_run: bool = True):
        self.db_path = db_path
        self.dry_run = dry_run
        self.protocol_facts = _load_protocol_facts()

    def _extract_claims_regex(self, content: str) -> list[str]:
        """Extract sentences containing numbers or Zenon-specific terms."""
        keywords = [
            r"\d+[\d,.]*\s*(ZNN|QSR|USD|%|APY|APR)",
            r"(emission|supply|pillar|sentinel|delegation|staking|orbital|plasma)",
            r"(feeless|dual.?ledger|block.?lattice|DAG|SPV|taproot)",
            r"(BIP|Bitcoin|Ethereum|merge.?min|Wormhole|BagSwap)",
        ]
        sentences = re.split(r"(?<=[.!?])\s+", content)
        claims = []
        for sentence in sentences:
            for pattern in keywords:
                if re.search(pattern, sentence, re.IGNORECASE):
                    claims.append(sentence.strip())
                    break
        return claims[:50]

    def _check_protocol_constants(self, claim: str) -> ClaimResult | None:
        """Check claim against hardcoded protocol constants in system.json."""
        for pattern, info in CLAIM_PATTERNS.items():
            match = re.search(pattern, claim, re.IGNORECASE)
            if match:
                claimed_value_str = match.group(1).replace(",", "")
                try:
                    claimed_value = float(claimed_value_str)
                except ValueError:
                    continue

                fact_key = info["fact_key"]
                actual_value = self.protocol_facts.get(fact_key)

                if actual_value is not None:
                    is_accurate = abs(claimed_value - actual_value) < 1
                    return ClaimResult(
                        claim_text=claim,
                        status="CONFIRMED" if is_accurate else "UNVERIFIED",
                        evidence=f"config/system.json: {fact_key} = {actual_value}",
                        source="protocol_constants",
                        correct_value=str(actual_value),
                        is_accurate=is_accurate,
                    )
        return None

    def _check_evidence_store(self, claim: str) -> ClaimResult | None:
        """Search evidence store for backing data."""
        try:
            conn = connect(self.db_path)
            conn.row_factory = sqlite3.Row

            terms = self._extract_search_terms(claim)
            if not terms:
                return None

            like_clauses = " OR ".join("finding LIKE ?" for _ in terms[:5])
            params = [f"%{term}%" for term in terms[:5]]

            rows = conn.execute(
                f"""SELECT id, engine, evidence_type, finding, confidence, raw_data
                    FROM evidence
                    WHERE ({like_clauses})
                    ORDER BY confidence DESC
                    LIMIT 5""",
                params,
            ).fetchall()
            conn.close()

            if rows:
                best = rows[0]
                raw_data = {}
                with contextlib.suppress(json.JSONDecodeError, TypeError):
                    raw_data = json.loads(best["raw_data"]) if best["raw_data"] else {}

                provenance = raw_data.get("provenance", "hypothesis")

                if provenance in ("verified_by_api", "computational"):
                    return ClaimResult(
                        claim_text=claim,
                        status="VERIFIED",
                        evidence=f"Evidence #{best['id']}: {best['finding'][:100]}",
                        source=f"evidence_store:{best['engine']}",
                        is_accurate=True,
                    )
                elif best["confidence"] >= 0.7:
                    return ClaimResult(
                        claim_text=claim,
                        status="THEORY",
                        evidence=f"Evidence #{best['id']} (conf={best['confidence']:.2f})",
                        source=f"evidence_store:{best['engine']}",
                        is_accurate=True,
                    )

        except (sqlite3.OperationalError, sqlite3.DatabaseError) as exc:
            logger.debug("Evidence store check failed: %s", exc)

        return None

    def _check_known_addresses(self, claim: str) -> ClaimResult | None:
        """Check if claim contains known contract addresses."""
        known = self.protocol_facts
        addr_checks = {
            "wznn_contract_eth": known.get("wznn_contract_eth", ""),
        }
        for key, addr in addr_checks.items():
            if addr and addr.lower() in claim.lower():
                return ClaimResult(
                    claim_text=claim,
                    status="CONFIRMED",
                    evidence=f"Known address: {key} = {addr}",
                    source="protocol_constants",
                    is_accurate=True,
                )
        return None

    def _extract_search_terms(self, claim: str) -> list[str]:
        """Extract meaningful search terms from a claim."""
        stop_words = {
            "the",
            "a",
            "an",
            "is",
            "are",
            "was",
            "were",
            "be",
            "been",
            "have",
            "has",
            "had",
            "do",
            "does",
            "did",
            "will",
            "would",
            "could",
            "should",
            "may",
            "might",
            "can",
            "shall",
            "this",
            "that",
            "these",
            "those",
            "for",
            "and",
            "but",
            "not",
            "with",
            "from",
            "by",
            "at",
            "in",
            "on",
            "to",
            "of",
            "as",
            "if",
            "than",
            "about",
            "into",
            "through",
            "during",
            "before",
            "after",
        }
        words = re.findall(r"\b[a-zA-Z]{3,}\b", claim)
        terms = [w.lower() for w in words if w.lower() not in stop_words]
        zenon_terms = [
            t
            for t in terms
            if t
            in {
                "zenon",
                "znn",
                "qsr",
                "pillar",
                "sentinel",
                "plasma",
                "momentum",
                "orbital",
                "delegation",
                "staking",
                "emission",
                "taproot",
                "spv",
                "feeless",
                "accelerator",
                "supernova",
                "bagswap",
                "wormhole",
            }
        ]
        return (zenon_terms + terms)[:8]

    def _tag_content(self, content: str, claims: list[ClaimResult]) -> str:
        """Tag content with claim verification status."""
        tagged = content
        for claim in claims:
            tag = f"[{claim.status}]"
            if claim.claim_text in tagged:
                tagged = tagged.replace(
                    claim.claim_text,
                    f"{tag} {claim.claim_text}",
                    1,
                )
        return tagged

    def check(self, content: str) -> GuardResult:
        """Run full hallucination check on content.

        Verification pipeline order:
        1. Protocol constants (fastest, most reliable)
        2. Known addresses
        3. Evidence store
        4. Fallback: mark as UNVERIFIED
        """
        logger.info(
            "HallucinationGuard: checking content (%d chars, dry_run=%s)",
            len(content),
            self.dry_run,
        )

        raw_claims = self._extract_claims_regex(content)
        logger.info("Extracted %d claims to verify", len(raw_claims))

        checked_claims: list[ClaimResult] = []
        for claim_text in raw_claims:
            result = self._check_protocol_constants(claim_text)
            if result:
                checked_claims.append(result)
                continue

            result = self._check_known_addresses(claim_text)
            if result:
                checked_claims.append(result)
                continue

            result = self._check_evidence_store(claim_text)
            if result:
                checked_claims.append(result)
                continue

            checked_claims.append(
                ClaimResult(
                    claim_text=claim_text,
                    status="UNVERIFIED",
                    evidence="No backing found in protocol constants or evidence store",
                )
            )

        verified = sum(1 for c in checked_claims if c.status == "VERIFIED")
        confirmed = sum(1 for c in checked_claims if c.status == "CONFIRMED")
        theory = sum(1 for c in checked_claims if c.status == "THEORY")
        unverified = sum(1 for c in checked_claims if c.status == "UNVERIFIED")
        inaccurate = sum(1 for c in checked_claims if not c.is_accurate)

        tagged_content = self._tag_content(content, checked_claims)

        warnings: list[str] = []
        safe = True

        if inaccurate > 0:
            safe = False
            for c in checked_claims:
                if not c.is_accurate:
                    warnings.append(
                        f"INACCURATE: '{c.claim_text[:80]}' -- correct value: {c.correct_value}"
                    )

        if checked_claims and unverified > len(checked_claims) * 0.3:
            safe = False
            pct = unverified / len(checked_claims) * 100
            warnings.append(
                f"Too many unverified claims: {unverified}/{len(checked_claims)} ({pct:.0f}%)"
            )

        if unverified > 0:
            warnings.append(
                f"{unverified} claim(s) could not be verified -- review before publishing"
            )

        return GuardResult(
            content_original=content,
            content_tagged=tagged_content,
            claims_checked=len(checked_claims),
            verified_count=verified,
            confirmed_count=confirmed,
            theory_count=theory,
            unverified_count=unverified,
            inaccurate_count=inaccurate,
            claims=checked_claims,
            safe_to_publish=safe,
            warnings=warnings,
        )

    def check_file(self, file_path: str) -> GuardResult:
        """Check content from a file."""
        path = Path(file_path)
        if not path.exists():
            return GuardResult(
                content_original="",
                content_tagged="",
                claims_checked=0,
                verified_count=0,
                confirmed_count=0,
                theory_count=0,
                unverified_count=0,
                inaccurate_count=0,
                safe_to_publish=False,
                warnings=[f"File not found: {file_path}"],
            )
        return self.check(path.read_text())


def guard_before_publish(content: str, db_path: str = DEFAULT_DB) -> tuple[bool, str, list[str]]:
    """Integration point for distribution pipeline.

    Returns:
        (safe_to_publish, tagged_content, warnings)
    """
    guard = HallucinationGuard(db_path=db_path, dry_run=False)
    result = guard.check(content)
    return result.safe_to_publish, result.content_tagged, result.warnings
