# SPDX-License-Identifier: MIT
"""
Self-Improver -- Meta-analysis engine for the Nebula.

Reviews each engine's performance (actions, successes, errors, costs),
identifies which engines are most effective, which waste budget, and
which are stalled. Proposes specific improvements per engine and
generates an improvement report.

Runs weekly alongside the strategy evolver. Uses LLM for synthesis
when available, falls back to rule-based analysis otherwise.
"""

import json
import logging
import sqlite3
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
REPORT_FILE = ENGINE_ROOT / "data" / "self_improvement_report.json"

SYSTEM_PROMPT = (
    "You are a meta-improvement engine for the Nebula -- "
    "a multi-domain autonomous system covering intelligence, development, "
    "security, quality, and contribution tracking.\n\n"
    "Review each module's performance and propose specific, actionable "
    "improvements. Not code changes -- strategy changes, priority shifts, "
    "and resource reallocation.\n\n"
    "Be specific. Reference actual numbers."
)


class SelfImprover:
    """Meta-analysis engine that reviews all engines and proposes improvements.

    Analyzes actions_log for each module, computes success rates, error
    rates, cost efficiency, and proposes changes.
    """

    def __init__(
        self,
        db_path: str = DEFAULT_DB,
        llm_call: Callable | None = None,
    ):
        self.db_path = db_path
        self._llm_call = llm_call

    def _get_conn(self) -> sqlite3.Connection:
        conn = connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row
        return conn

    # ------------------------------------------------------------------
    # Module-level analysis
    # ------------------------------------------------------------------

    def analyze_module(self, module_name: str) -> dict:
        """Analyze a single module's performance from actions_log.

        Returns:
            Dict with health, stats, and improvement recommendations.
        """
        conn = self._get_conn()
        try:
            try:
                actions = conn.execute(
                    "SELECT action, result, cost_usd, tokens_used, "
                    "error, timestamp "
                    "FROM actions_log WHERE module = ? "
                    "ORDER BY id DESC LIMIT 50",
                    (module_name,),
                ).fetchall()
            except sqlite3.OperationalError:
                actions = []
        finally:
            conn.close()

        total = len(actions)
        if total < 3:
            return {
                "module": module_name,
                "status": "insufficient_data",
                "actions_found": total,
                "improvements": [],
            }

        errors = sum(1 for a in actions if a["error"])
        total_cost = sum(a["cost_usd"] or 0 for a in actions)
        total_tokens = sum(a["tokens_used"] or 0 for a in actions)
        error_rate = errors / max(total, 1)
        avg_cost = total_cost / max(total, 1)

        # Rule-based health assessment
        if error_rate > 0.5:
            health = "critical"
        elif error_rate > 0.2:
            health = "needs_attention"
        else:
            health = "healthy"

        if avg_cost > 0.10:
            cost_efficiency = "wasteful"
        elif avg_cost > 0.01:
            cost_efficiency = "acceptable"
        else:
            cost_efficiency = "good"

        # Generate improvements
        improvements = []
        if error_rate > 0.2:
            improvements.append(
                f"High error rate ({error_rate * 100:.0f}%). Investigate root cause of failures."
            )
        if avg_cost > 0.10:
            improvements.append(
                f"High cost per action (${avg_cost:.4f}). Consider using cheaper model tier."
            )
        if total_tokens > 100000:
            improvements.append(f"High token usage ({total_tokens}). Consider prompt optimization.")
        if total < 10:
            improvements.append(
                f"Low activity ({total} actions). May need more frequent execution."
            )

        report = {
            "module": module_name,
            "health": health,
            "cost_efficiency": cost_efficiency,
            "stats": {
                "total_actions": total,
                "error_count": errors,
                "error_rate": round(error_rate, 4),
                "total_cost": round(total_cost, 4),
                "avg_cost_per_action": round(avg_cost, 6),
                "total_tokens": total_tokens,
            },
            "improvements": improvements,
            "analyzed_at": datetime.now(timezone.utc).isoformat(),
        }

        # LLM synthesis if available
        if self._llm_call and total >= 5:
            actions_text = "\n".join(
                f"  [{a['timestamp']}] {a['action']}: "
                f"{(a['result'] or '')[:100]} "
                f"(${a['cost_usd'] or 0:.4f})"
                f"{' ERROR' if a['error'] else ''}"
                for a in actions[:20]
            )
            prompt = (
                f"MODULE: {module_name}\n"
                f"STATS: {total} actions, {errors} errors, "
                f"${total_cost:.4f} total cost\n\n"
                f"ACTIONS:\n{actions_text}\n\n"
                f"Propose specific improvements."
            )
            llm_improvements = self._llm_call(SYSTEM_PROMPT, prompt)
            if isinstance(llm_improvements, list):
                report["improvements"].extend(llm_improvements)

        return report

    # ------------------------------------------------------------------
    # System-wide analysis
    # ------------------------------------------------------------------

    def analyze_all(self, registry=None) -> dict:
        """Run improvement analysis for all active modules.

        Args:
            registry: DomainRegistry to discover module names.

        Returns:
            Combined improvement report.
        """
        logger.info("=== SELF IMPROVER: Full system review ===")

        # Discover module names from actions_log
        conn = self._get_conn()
        try:
            try:
                modules = conn.execute(
                    "SELECT DISTINCT module FROM actions_log "
                    "WHERE module IS NOT NULL AND module != '' "
                    "ORDER BY module"
                ).fetchall()
                module_names = [r["module"] for r in modules]
            except sqlite3.OperationalError:
                module_names = []
        finally:
            conn.close()

        # Also include core modules that may not have actions yet
        core_modules = [
            "unified_director",
            "collision_engine",
            "war_room",
            "strategy_evolver",
            "self_improver",
            "knowledge_graph",
        ]
        for m in core_modules:
            if m not in module_names:
                module_names.append(m)

        report = {
            "started_at": datetime.now(timezone.utc).isoformat(),
            "modules": {},
        }

        for name in module_names:
            try:
                report["modules"][name] = self.analyze_module(name)
            except Exception as exc:
                logger.error("Failed to analyze %s: %s", name, exc)
                report["modules"][name] = {
                    "module": name,
                    "status": "error",
                    "error": str(exc),
                }

        # Cross-module synthesis
        report["synthesis"] = self._synthesize(report["modules"])
        report["completed_at"] = datetime.now(timezone.utc).isoformat()

        return report

    def _synthesize(self, module_reports: dict) -> dict:
        """Synthesize cross-module recommendations."""
        # Cost ranking
        cost_ranking = sorted(
            [
                (name, r.get("stats", {}).get("total_cost", 0))
                for name, r in module_reports.items()
                if r.get("stats")
            ],
            key=lambda x: -x[1],
        )

        # Health summary
        health_counts = {}
        for r in module_reports.values():
            h = r.get("health", "unknown")
            health_counts[h] = health_counts.get(h, 0) + 1

        # Score 0-100
        total = len(module_reports)
        healthy = sum(1 for r in module_reports.values() if r.get("health") == "healthy")
        score = int((healthy / max(total, 1)) * 100) if total else 0

        # Top improvements
        all_improvements = []
        for name, r in module_reports.items():
            for imp in r.get("improvements", [])[:2]:
                all_improvements.append({"module": name, "rec": imp})

        synthesis = {
            "system_health_score": score,
            "health_counts": health_counts,
            "cost_ranking": [
                {"module": name, "cost": round(cost, 4)} for name, cost in cost_ranking[:10]
            ],
            "top_improvements": all_improvements[:10],
            "total_modules_analyzed": total,
        }

        # LLM synthesis
        if self._llm_call:
            summaries = "\n".join(
                f"{name}: health={r.get('health', '?')}, "
                f"cost=${r.get('stats', {}).get('total_cost', 0):.4f}"
                for name, r in module_reports.items()
            )
            prompt = (
                f"Module summaries:\n{summaries}\n\nWhat is the single highest-ROI improvement?"
            )
            result = self._llm_call(SYSTEM_PROMPT, prompt)
            if isinstance(result, str):
                synthesis["highest_roi_improvement"] = result

        return synthesis

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save_report(self, report: dict) -> None:
        """Save improvement report to file."""
        REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
        REPORT_FILE.write_text(json.dumps(report, indent=2, default=str))
        logger.info("Report saved to %s", REPORT_FILE)

        from core.persist_to_db import persist_action

        persist_action(
            db_path=self.db_path,
            domain="system",
            module="self_improver",
            action="generate_report",
            result=json.dumps(
                {
                    "modules": len(report.get("modules", {})),
                    "score": report.get("synthesis", {}).get("system_health_score", 0),
                },
                default=str,
            ),
        )
