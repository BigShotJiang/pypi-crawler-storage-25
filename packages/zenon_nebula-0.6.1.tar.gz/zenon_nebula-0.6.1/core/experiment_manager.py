# SPDX-License-Identifier: MIT
"""
ExperimentManager -- A/B test different strategies, measure outcomes.

Manages the full lifecycle of experiments: creation, deployment,
measurement, promotion/retirement. Each experiment runs for a
configurable evaluation window before metrics are compared against
the baseline.

Generalized from marketing's experiment_manager.py. Domain-agnostic:
works with any strategy that can produce measurable outcomes.

Reads:  experiments table, experiment_metrics table
Writes: experiments table, experiment_metrics table, feedback_bus
"""

import contextlib
import json
import logging
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")


# ---------------------------------------------------------------------------
# SQL DDL
# ---------------------------------------------------------------------------

_CREATE_EXPERIMENTS_TABLE = """
CREATE TABLE IF NOT EXISTS experiments (
    id TEXT PRIMARY KEY,
    domain TEXT NOT NULL DEFAULT 'system',
    strategy_id TEXT,
    variant_label TEXT DEFAULT 'experimental',
    status TEXT DEFAULT 'created',
    config TEXT,
    deployment_started_at DATETIME,
    evaluation_window_hours INTEGER DEFAULT 72,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME,
    metrics TEXT,
    vs_baseline REAL,
    passed BOOLEAN,
    notes TEXT
)
"""

_CREATE_METRICS_TABLE = """
CREATE TABLE IF NOT EXISTS experiment_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    experiment_id TEXT NOT NULL,
    metric_name TEXT NOT NULL,
    metric_value REAL,
    recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (experiment_id) REFERENCES experiments(id)
)
"""

# Exposed at module level so core.schema_registry applies both tables
# during boot instead of relying on ExperimentManager.__init__ to
# run first.
SCHEMA_SQL = _CREATE_EXPERIMENTS_TABLE + ";\n" + _CREATE_METRICS_TABLE + ";\n"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ExperimentResult:
    """Measurement result for an experiment."""

    experiment_id: str
    passed: bool
    metrics: dict
    vs_baseline: float
    domain: str = ""


@dataclass
class Experiment:
    """In-memory representation of an experiment row."""

    id: str
    domain: str
    strategy_id: str
    variant_label: str
    status: str
    config: dict
    evaluation_window_hours: int
    created_at: str = ""
    deployment_started_at: str | None = None
    completed_at: str | None = None
    metrics: dict = field(default_factory=dict)
    vs_baseline: float = 0.0
    passed: bool = False
    notes: str = ""


# ---------------------------------------------------------------------------
# ExperimentManager
# ---------------------------------------------------------------------------


class ExperimentManager:
    """Manages A/B testing of strategies across domains.

    Usage::

        mgr = ExperimentManager()
        eid = mgr.create_experiment("intelligence", "strategy_alpha",
                                    config={"threshold": 0.7})
        mgr.deploy(eid)
        # ... wait for evaluation window ...
        mgr.record_metric(eid, "accuracy", 0.85)
        mgr.record_metric(eid, "latency_ms", 120.0)
        result = mgr.measure(eid, baseline_metrics={"accuracy": 0.80})
        if result.passed:
            mgr.promote(eid)
        else:
            mgr.retire(eid, reason="accuracy below baseline")
    """

    def __init__(self, db_path: str = DEFAULT_DB) -> None:
        self.db_path = db_path
        self._ensure_tables()

    # ------------------------------------------------------------------
    # DB setup
    # ------------------------------------------------------------------

    def _ensure_tables(self) -> None:
        """Create required tables if they do not exist."""
        conn = connect(self.db_path)
        try:
            conn.execute(_CREATE_EXPERIMENTS_TABLE)
            conn.execute(_CREATE_METRICS_TABLE)
            conn.commit()
        finally:
            conn.close()

    def _connect(self) -> sqlite3.Connection:
        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    # ------------------------------------------------------------------
    # Public API -- lifecycle
    # ------------------------------------------------------------------

    def create_experiment(
        self,
        domain: str,
        strategy_id: str,
        config: dict | None = None,
        variant_label: str = "experimental",
        evaluation_window_hours: int = 72,
    ) -> str:
        """Register a new experiment.

        Args:
            domain:                   Domain this experiment belongs to.
            strategy_id:              Identifier for the strategy being tested.
            config:                   Experiment-specific configuration.
            variant_label:            Label for this variant (e.g. "A", "B").
            evaluation_window_hours:  Hours before evaluation.

        Returns:
            The experiment ID (UUID-based).
        """
        experiment_id = f"exp_{uuid.uuid4().hex[:12]}"
        conn = connect(self.db_path)
        try:
            conn.execute(
                """INSERT INTO experiments
                   (id, domain, strategy_id, variant_label, status, config,
                    evaluation_window_hours)
                   VALUES (?, ?, ?, ?, 'created', ?, ?)""",
                (
                    experiment_id,
                    domain,
                    strategy_id,
                    variant_label,
                    json.dumps(config or {}),
                    evaluation_window_hours,
                ),
            )
            conn.commit()
        finally:
            conn.close()

        logger.info(
            "Created experiment %s: domain=%s strategy=%s",
            experiment_id,
            domain,
            strategy_id,
        )
        return experiment_id

    def deploy(self, experiment_id: str) -> None:
        """Mark an experiment as deployed, recording the start time."""
        now = datetime.now(timezone.utc).isoformat()
        conn = connect(self.db_path)
        try:
            conn.execute(
                """UPDATE experiments
                   SET status = 'running', deployment_started_at = ?
                   WHERE id = ?""",
                (now, experiment_id),
            )
            conn.commit()
        finally:
            conn.close()

        logger.info("Deployed experiment %s at %s", experiment_id, now)

    def record_metric(
        self,
        experiment_id: str,
        metric_name: str,
        metric_value: float,
    ) -> None:
        """Record a metric observation for an experiment.

        Args:
            experiment_id: The experiment to record for.
            metric_name:   Name of the metric (e.g. "accuracy", "latency_ms").
            metric_value:  Numeric value of the observation.
        """
        conn = connect(self.db_path)
        try:
            conn.execute(
                """INSERT INTO experiment_metrics
                   (experiment_id, metric_name, metric_value)
                   VALUES (?, ?, ?)""",
                (experiment_id, metric_name, metric_value),
            )
            conn.commit()
        finally:
            conn.close()

    def measure(
        self,
        experiment_id: str,
        baseline_metrics: dict[str, float] | None = None,
        pass_threshold: float = -0.10,
    ) -> ExperimentResult:
        """Evaluate an experiment against baseline metrics.

        Args:
            experiment_id:    The experiment to evaluate.
            baseline_metrics: Dict of metric_name -> baseline value. If None,
                              computes baseline from other experiments in the
                              same domain with status 'completed_success'.
            pass_threshold:   Minimum relative improvement vs baseline to pass.
                              Default -0.10 (allow 10% dip for novelty).

        Returns:
            ExperimentResult with pass/fail and metrics.
        """
        conn = self._connect()
        try:
            exp = conn.execute(
                "SELECT * FROM experiments WHERE id = ?", (experiment_id,)
            ).fetchone()
            if not exp:
                raise ValueError(f"Experiment {experiment_id} not found")

            domain = exp["domain"]

            # Aggregate experiment metrics
            exp_metrics = self._aggregate_metrics(conn, experiment_id)

            # Compute baseline if not provided
            if baseline_metrics is None:
                baseline_metrics = self._compute_baseline(conn, domain)

            # Compare: experiment vs baseline for each shared metric
            comparisons: dict[str, float] = {}
            for metric_name, exp_value in exp_metrics.items():
                baseline_value = baseline_metrics.get(metric_name, 0.0)
                if baseline_value != 0.0:
                    relative = (exp_value - baseline_value) / abs(baseline_value)
                else:
                    relative = 1.0 if exp_value > 0 else 0.0
                comparisons[metric_name] = relative

            # Overall pass: average relative improvement >= threshold
            if comparisons:
                avg_relative = sum(comparisons.values()) / len(comparisons)
            else:
                avg_relative = 0.0

            passed = avg_relative >= pass_threshold

            metrics = {
                "experiment_values": exp_metrics,
                "baseline_values": baseline_metrics,
                "comparisons": comparisons,
                "avg_relative_improvement": round(avg_relative, 4),
            }

            # Persist to experiment row
            conn_w = connect(self.db_path)
            try:
                conn_w.execute(
                    """UPDATE experiments
                       SET metrics = ?, vs_baseline = ?, passed = ?
                       WHERE id = ?""",
                    (json.dumps(metrics), avg_relative, passed, experiment_id),
                )
                conn_w.commit()
            finally:
                conn_w.close()

        finally:
            conn.close()

        result = ExperimentResult(
            experiment_id=experiment_id,
            passed=passed,
            metrics=metrics,
            vs_baseline=round(avg_relative, 4),
            domain=domain,
        )

        logger.info(
            "Measured experiment %s: passed=%s vs_baseline=%.2f%%",
            experiment_id,
            passed,
            avg_relative * 100,
        )
        return result

    def promote(self, experiment_id: str) -> None:
        """Promote a successful experiment."""
        now = datetime.now(timezone.utc).isoformat()
        conn = connect(self.db_path)
        try:
            conn.execute(
                """UPDATE experiments
                   SET status = 'completed_success', completed_at = ?
                   WHERE id = ?""",
                (now, experiment_id),
            )
            conn.commit()
        finally:
            conn.close()

        self._emit_event(experiment_id, "promoted")
        logger.info("Promoted experiment %s", experiment_id)

    def retire(self, experiment_id: str, reason: str = "") -> None:
        """Retire a failed experiment."""
        now = datetime.now(timezone.utc).isoformat()
        conn = connect(self.db_path)
        try:
            conn.execute(
                """UPDATE experiments
                   SET status = 'completed_failed', completed_at = ?,
                       notes = ?
                   WHERE id = ?""",
                (now, reason, experiment_id),
            )
            conn.commit()
        finally:
            conn.close()

        self._emit_event(experiment_id, "retired")
        logger.info("Retired experiment %s: %s", experiment_id, reason or "underperformed")

    def evaluate_all(self) -> list[ExperimentResult]:
        """Batch evaluate all experiments past their evaluation window."""
        now = datetime.now(timezone.utc)
        conn = self._connect()
        try:
            rows = conn.execute(
                """SELECT id, deployment_started_at, evaluation_window_hours, domain
                   FROM experiments
                   WHERE status = 'running'
                     AND deployment_started_at IS NOT NULL"""
            ).fetchall()
        finally:
            conn.close()

        evaluations: list[ExperimentResult] = []
        for row in rows:
            started = datetime.fromisoformat(row["deployment_started_at"])
            if started.tzinfo is None:
                started = started.replace(tzinfo=timezone.utc)
            window_hours = row["evaluation_window_hours"] or 72
            if now - started >= timedelta(hours=window_hours):
                try:
                    result = self.measure(row["id"])
                    evaluations.append(result)
                except Exception as exc:
                    logger.error("Failed to measure experiment %s: %s", row["id"], exc)

        logger.info("Evaluated %d experiments past their window", len(evaluations))
        return evaluations

    def get_experiment(self, experiment_id: str) -> Experiment | None:
        """Load a single experiment by ID."""
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT * FROM experiments WHERE id = ?", (experiment_id,)
            ).fetchone()
            if not row:
                return None
            return self._row_to_experiment(row)
        finally:
            conn.close()

    def list_experiments(
        self,
        domain: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> list[Experiment]:
        """List experiments, optionally filtered by domain and/or status."""
        conn = self._connect()
        try:
            query = "SELECT * FROM experiments WHERE 1=1"
            params: list = []
            if domain:
                query += " AND domain = ?"
                params.append(domain)
            if status:
                query += " AND status = ?"
                params.append(status)
            query += " ORDER BY created_at DESC LIMIT ?"
            params.append(limit)

            rows = conn.execute(query, params).fetchall()
            return [self._row_to_experiment(r) for r in rows]
        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _aggregate_metrics(
        conn: sqlite3.Connection,
        experiment_id: str,
    ) -> dict[str, float]:
        """Aggregate metric observations for an experiment (average per metric)."""
        rows = conn.execute(
            """SELECT metric_name, AVG(metric_value) as avg_value
               FROM experiment_metrics
               WHERE experiment_id = ?
               GROUP BY metric_name""",
            (experiment_id,),
        ).fetchall()
        return {row["metric_name"]: row["avg_value"] or 0.0 for row in rows}

    @staticmethod
    def _compute_baseline(
        conn: sqlite3.Connection,
        domain: str,
    ) -> dict[str, float]:
        """Compute baseline metrics from successful experiments in the same domain."""
        exp_ids = conn.execute(
            """SELECT id FROM experiments
               WHERE domain = ? AND status = 'completed_success'
               ORDER BY completed_at DESC LIMIT 10""",
            (domain,),
        ).fetchall()

        if not exp_ids:
            return {}

        placeholders = ",".join("?" for _ in exp_ids)
        id_list = [row["id"] for row in exp_ids]

        rows = conn.execute(
            f"""SELECT metric_name, AVG(metric_value) as avg_value
                FROM experiment_metrics
                WHERE experiment_id IN ({placeholders})
                GROUP BY metric_name""",
            id_list,
        ).fetchall()

        return {row["metric_name"]: row["avg_value"] or 0.0 for row in rows}

    @staticmethod
    def _row_to_experiment(row: sqlite3.Row) -> Experiment:
        """Convert a DB row to an Experiment dataclass."""
        metrics = {}
        if row["metrics"]:
            with contextlib.suppress(json.JSONDecodeError, TypeError):
                metrics = json.loads(row["metrics"])
        config = {}
        if row["config"]:
            with contextlib.suppress(json.JSONDecodeError, TypeError):
                config = json.loads(row["config"])

        return Experiment(
            id=row["id"],
            domain=row["domain"],
            strategy_id=row["strategy_id"] or "",
            variant_label=row["variant_label"] or "experimental",
            status=row["status"] or "created",
            config=config,
            evaluation_window_hours=row["evaluation_window_hours"] or 72,
            created_at=row["created_at"] or "",
            deployment_started_at=row["deployment_started_at"],
            completed_at=row["completed_at"],
            metrics=metrics,
            vs_baseline=row["vs_baseline"] or 0.0,
            passed=bool(row["passed"]),
            notes=row["notes"] or "",
        )

    def _emit_event(self, experiment_id: str, event_type: str) -> None:
        """Emit an experiment lifecycle event to the feedback bus."""
        try:
            from core.feedback_bus import FeedbackBus

            bus = FeedbackBus(db_path=self.db_path)
            bus.post(
                sender="experiment_manager",
                recipient="all",
                message_type="signal",
                data={
                    "event": f"experiment_{event_type}",
                    "experiment_id": experiment_id,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )
        except Exception as exc:
            logger.debug("Could not emit experiment event: %s", exc)
