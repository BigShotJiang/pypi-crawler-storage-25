# SPDX-License-Identifier: MIT
"""
LLM Provider — xAI Grok only.

Nebula uses xAI Grok exclusively for all LLM tasks. This module provides
a single entry point (`call_llm`) that routes to xAI's OpenAI-compatible
Chat Completions API with automatic cost tracking, retry/backoff, and
prompt sanitization.

Why xAI only:
    - Cheapest capable frontier model (grok-4.20 at $2/$6 per MTok)
    - 2M context window (fits entire Nebula state in one prompt)
    - Lowest hallucination rate among frontier models
    - Single provider = simpler trust model, simpler billing
    - Multi-provider support was removed to reduce attack surface

Usage:
    from core.llm_provider import call_llm

    result = call_llm(
        prompt="Analyze this evidence and propose priorities.",
        system="You are a strategic analyst.",
        model="auto",  # or a specific grok-* model ID
    )
    # result = {"text": "...", "cost_usd": 0.0012, "input_tokens": 50,
    #           "output_tokens": 200, "model": "grok-4.20-0309-reasoning"}

Configuration:
    XAI_API_KEY   Required. Your xAI API key from https://console.x.ai

Model routing is defined in config/model_routing.json. Task types map to
specific Grok models (strategic_synthesis -> grok-4.20-0309-reasoning,
classification -> grok-4-1-fast-non-reasoning, etc.).
"""

import json
import logging
import os
import time
import urllib.error
import urllib.request

logger = logging.getLogger(__name__)

XAI_BASE_URL = "https://api.x.ai/v1"
XAI_ENDPOINT = f"{XAI_BASE_URL}/chat/completions"

# Pricing per 1M tokens (input, output) in USD.
# Verified against https://console.x.ai model catalog.
MODEL_PRICING: dict[str, tuple[float, float]] = {
    # grok-4.20 flagship: 2M context, lowest hallucination rate
    "grok-4.20-0309-reasoning": (2.0, 6.0),
    "grok-4.20-0309-non-reasoning": (2.0, 6.0),
    "grok-4.20-multi-agent-0309": (2.0, 6.0),
    # grok-4-1-fast: cheapest tier for classification/routing
    "grok-4-1-fast-reasoning": (0.20, 0.50),
    "grok-4-1-fast-non-reasoning": (0.20, 0.50),
    # Shorthand aliases used in older code
    "grok-4.20-reasoning": (2.0, 6.0),
    "grok-4.20": (2.0, 6.0),
    "grok-4.20-multi-agent": (2.0, 6.0),
}

# Default models by tier (used when model="auto")
DEFAULT_BEST = "grok-4.20-0309-reasoning"
DEFAULT_CHEAPEST = "grok-4-1-fast-non-reasoning"

# ---------------------------------------------------------------------------
# Circuit breaker (Phase 1, Step 2)
# ---------------------------------------------------------------------------
#
# Worst case for a single call_llm() invocation is ~6.2 minutes (3 retries
# x 120s socket timeout + exponential backoff sleeps). With 16-worker
# parallelism, 16 engines can stall simultaneously if xAI is hung. Without
# a circuit breaker, every cycle for the next several minutes piles MORE
# stalled workers on top of the existing ones.
#
# The circuit breaker is process-wide. After CIRCUIT_FAILURE_THRESHOLD
# consecutive failures it OPENS — every subsequent call_llm() returns
# None immediately without making a network request, for
# CIRCUIT_OPEN_SECONDS. After the cool-down it goes HALF-OPEN: the next
# call is allowed through. If that call succeeds, the breaker CLOSES
# and counters reset. If it fails, the breaker re-opens for another
# cool-down window.
#
# Tunables intentionally NOT exposed via env vars in this first cut —
# we want all instances to have identical behavior so the test contract
# pins reality. Future PRs can add env overrides if real operators ask.
CIRCUIT_FAILURE_THRESHOLD = 5
CIRCUIT_OPEN_SECONDS = 5 * 60  # 5 minutes
_circuit_consecutive_failures = 0
_circuit_open_until = 0.0
_circuit_open_logged = False


def _circuit_is_open() -> bool:
    """Return True if the breaker is currently open (calls should fail-fast)."""
    return time.monotonic() < _circuit_open_until


def _circuit_record_failure() -> None:
    """Bump the failure counter; open the breaker if we hit the threshold."""
    global _circuit_consecutive_failures, _circuit_open_until, _circuit_open_logged
    _circuit_consecutive_failures += 1
    if _circuit_consecutive_failures >= CIRCUIT_FAILURE_THRESHOLD:
        _circuit_open_until = time.monotonic() + CIRCUIT_OPEN_SECONDS
        if not _circuit_open_logged:
            logger.warning(
                "LLM circuit breaker OPEN: %d consecutive xAI failures. "
                "Skipping LLM calls for %d seconds. Check XAI_API_KEY, "
                "rate limits, and the xAI status page. Suppressing further "
                "circuit-open warnings until the breaker closes.",
                _circuit_consecutive_failures,
                CIRCUIT_OPEN_SECONDS,
            )
            _circuit_open_logged = True


def _circuit_record_success() -> None:
    """Reset the breaker on a successful call."""
    global _circuit_consecutive_failures, _circuit_open_until, _circuit_open_logged
    if _circuit_consecutive_failures > 0 or _circuit_open_until > 0:
        logger.info(
            "LLM circuit breaker CLOSED after success (was %d consecutive failures)",
            _circuit_consecutive_failures,
        )
    _circuit_consecutive_failures = 0
    _circuit_open_until = 0.0
    _circuit_open_logged = False


def reset_circuit_breaker() -> None:
    """Manually reset the breaker. For tests and operator override."""
    _circuit_record_success()


def _compute_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Compute cost in USD from token counts and model pricing."""
    pricing = MODEL_PRICING.get(model)
    if not pricing:
        return 0.0
    input_price, output_price = pricing
    return (input_tokens * input_price + output_tokens * output_price) / 1_000_000


def get_available_providers() -> dict:
    """Detect which providers have API keys configured.

    Nebula supports only xAI. Returns empty dict if XAI_API_KEY is missing.
    This function is kept for backward compatibility with code that calls
    ``get_available_providers()``.
    """
    providers: dict = {}
    if os.environ.get("XAI_API_KEY"):
        providers["xai"] = {
            "models": list(MODEL_PRICING.keys()),
            "best": DEFAULT_BEST,
            "cheapest": DEFAULT_CHEAPEST,
        }
    return providers


def call_llm(
    prompt: str,
    system: str = "",
    model: str = "auto",
    max_tokens: int = 4000,
    temperature: float = 1.0,
    json_output: bool = False,
    cache_ttl_seconds: int = 86_400,
    live_search: bool = False,
    search_sources: list[dict] | None = None,
) -> dict | None:
    """Universal LLM call — routes everything through xAI Grok.

    Args:
        prompt: User message
        system: System prompt (sent with developer role per xAI docs)
        model: Model ID or "auto" (picks DEFAULT_BEST)
        max_tokens: Max response tokens
        temperature: 0.0 (deterministic) to 1.0 (creative)
        json_output: If True, request JSON response format
        cache_ttl_seconds: Look up the prompt cache before hitting xAI.
            Default 86400 (24h). Pass 0 to skip the cache entirely
            (use for streaming, agent tool calls, or any call that
            must be fresh).
        live_search: If True, enable xAI's Live Search tool on this
            call (Phase 17, ADR-0011). Grok will search the web / X
            during response generation and include citations in the
            returned dict under ``citations``. Live Search calls are
            NEVER cached (live by definition) — the cache is
            automatically bypassed regardless of ``cache_ttl_seconds``.
        search_sources: Optional list of source filters for Live
            Search, e.g. ``[{"type": "web"}, {"type": "news"}]``. When
            unset, defaults to web + X + news, matching xAI's default.

    Returns:
        Dict with keys: text, cost_usd, input_tokens, output_tokens, model.
        ``cached=True`` is added when the result came from the local
        prompt cache. ``citations=[...]`` is added when Live Search
        was used and xAI returned sources. None if the call fails
        after all retries.
    """
    # Live Search bypasses the cache (by design — searches must be fresh).
    if live_search:
        cache_ttl_seconds = 0
    # Sanitize prompts before sending
    from core.opsec import OPSECGuard

    prompt = OPSECGuard.sanitize_prompt(prompt)
    if system:
        system = OPSECGuard.sanitize_prompt(system)

    api_key = os.environ.get("XAI_API_KEY")
    if not api_key:
        logger.error("XAI_API_KEY not set — Nebula requires xAI for LLM calls")
        return None

    # Circuit breaker: if too many recent calls have failed, fail-fast
    # without consuming the worker thread for 6+ minutes on the inevitable
    # 3 x 120s timeouts. See module-level commentary for the threshold
    # and cool-down. Cache hits are still served — only the network path
    # is gated.
    if _circuit_is_open():
        logger.debug(
            "LLM circuit breaker OPEN — short-circuiting call (%d failures)",
            _circuit_consecutive_failures,
        )
        return None

    # Resolve "auto" to the default best model
    if model == "auto":
        model = DEFAULT_BEST

    # --- Prompt cache lookup (Phase 15, opt-out via cache_ttl_seconds=0) ---
    cache_key = None
    if cache_ttl_seconds > 0:
        try:
            from core import llm_cache

            cache_key = llm_cache.make_cache_key(
                prompt=prompt,
                system=system,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                json_output=json_output,
            )
            hit = llm_cache.lookup(cache_key, ttl_seconds=cache_ttl_seconds)
            if hit is not None:
                logger.debug("llm_cache hit for %s...", cache_key[:12])
                return hit
        except Exception as exc:
            logger.debug("llm_cache lookup skipped: %s", exc)
            cache_key = None

    # Build request
    messages = []
    if system:
        # xAI recommends "developer" role for system context
        messages.append({"role": "developer", "content": system})
    messages.append({"role": "user", "content": prompt})

    body = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    if json_output:
        body["response_format"] = {"type": "json_object"}
    if live_search:
        # xAI Live Search API — see docs.x.ai. "on" forces a search
        # every call; "auto" lets the model decide. Nebula engines
        # that ask for live_search explicitly want a fresh search,
        # so use "on".
        body["search_parameters"] = {
            "mode": "on",
            "return_citations": True,
            "sources": search_sources or [{"type": "web"}, {"type": "news"}, {"type": "x"}],
        }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }
    encoded = json.dumps(body).encode()

    # OPSEC: route through the safe HTTP wrapper so the User-Agent
    # is rotated to a real browser string instead of Python-urllib/3.x.
    # The Authorization header is preserved (opsec_urlopen only strips
    # forbidden fingerprinting headers and rotates User-Agent). xAI
    # already knows which account we are via the API key — this just
    # prevents "this is a Python-urllib user" fingerprinting on top.
    from core.http import opsec_urlopen

    # Retry with exponential backoff on rate limits and server errors
    last_exc = None
    for attempt in range(3):
        try:
            req = urllib.request.Request(XAI_ENDPOINT, data=encoded, headers=headers)
            resp = opsec_urlopen(req, timeout=120)
            data = json.loads(resp.read())

            # Defensive parsing — an xAI response can be malformed in
            # ways that the old `data["choices"][0]["message"]["content"]`
            # would crash on: empty choices list, missing message, API
            # error payload, nil content. Handle all of them without
            # crashing the caller.
            if not isinstance(data, dict):
                logger.warning("xAI returned non-dict response: %r", type(data))
                last_exc = ValueError(f"non-dict response: {type(data)}")
                continue
            if "error" in data and not data.get("choices"):
                err = data.get("error")
                err_msg = err.get("message") if isinstance(err, dict) else str(err)
                logger.warning("xAI error response: %s", err_msg)
                last_exc = RuntimeError(f"xAI error: {err_msg}")
                # Don't retry on explicit 4xx errors in the body
                break
            choices = data.get("choices") or []
            if not choices:
                logger.warning("xAI returned no choices: %r", data)
                last_exc = ValueError("no choices in response")
                continue
            first_choice = choices[0] if isinstance(choices, list) else {}
            message = first_choice.get("message", {}) if isinstance(first_choice, dict) else {}
            raw_text = message.get("content") if isinstance(message, dict) else None
            if raw_text is None:
                # Some models return content=null with finish_reason=length etc.
                finish = (
                    first_choice.get("finish_reason") if isinstance(first_choice, dict) else None
                )
                logger.warning("xAI choice has no content (finish_reason=%s)", finish)
                raw_text = ""
            # OPSEC: sanitize the response before storing. If the prompt
            # accidentally contained a secret (despite sanitize_prompt)
            # and the model echoed it back, this catches the echo at the
            # return boundary. Idempotent — running sanitize_prompt on
            # already-sanitized text is safe.
            text = OPSECGuard.sanitize_prompt(raw_text) if raw_text else raw_text
            usage = data.get("usage", {})
            input_tokens = usage.get("prompt_tokens", 0)
            output_tokens = usage.get("completion_tokens", 0)

            result = {
                "text": text,
                "cost_usd": _compute_cost(model, input_tokens, output_tokens),
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "model": model,
            }

            # xAI Live Search returns citations in the top-level response
            # when search_parameters was supplied. Normalize them into the
            # result dict so callers don't have to dig.
            if live_search:
                citations = data.get("citations") or []
                if not citations and isinstance(data.get("choices"), list):
                    choice = data["choices"][0]
                    citations = (
                        choice.get("citations") or choice.get("message", {}).get("citations") or []
                    )
                result["citations"] = citations
                usage_details = usage.get("num_sources_used")
                if usage_details is not None:
                    result["num_sources_used"] = usage_details

            # Auto-track cost
            try:
                from core.persist_to_db import persist_cost

                persist_cost(
                    domain="system",
                    provider="xai",
                    model=model,
                    module="llm_provider",
                    tokens_input=input_tokens,
                    tokens_output=output_tokens,
                    cost_usd=result["cost_usd"],
                )
            except Exception as exc:
                logger.debug("Cost tracking failed: %s", exc)

            # Cache the successful completion for repeat calls (Phase 15).
            if cache_key is not None:
                try:
                    from core import llm_cache

                    llm_cache.store(
                        cache_key,
                        result,
                        prompt_preview=prompt[:300],
                    )
                except Exception as exc:
                    logger.debug("llm_cache store skipped: %s", exc)

            # Success: reset the circuit breaker.
            _circuit_record_success()
            return result

        except urllib.error.HTTPError as e:
            last_exc = e
            if e.code in (429, 502, 503, 529):
                delay = min(2**attempt * 2, 30)
                logger.debug("xAI rate limited (%d), retrying in %ds", e.code, delay)
                time.sleep(delay)
            else:
                logger.warning("xAI HTTP error %d: %s", e.code, e.reason)
                # Permanent error → record breaker failure and bail.
                _circuit_record_failure()
                return None
        except Exception as e:
            last_exc = e
            logger.warning("xAI call failed (attempt %d/3): %s", attempt + 1, e)
            time.sleep(2**attempt)

    logger.error("xAI call failed after 3 retries: %s", last_exc)
    # All retries exhausted → record breaker failure.
    _circuit_record_failure()
    return None
