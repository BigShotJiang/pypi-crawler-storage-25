# SPDX-License-Identifier: MIT
"""
CorpusManager -- Manages the indexed corpus of all repos in the workspace.

Provides indexing, search, and freshness tracking across all repositories.
The LLM can query this to find relevant code, documentation, and patterns
across the entire workspace without re-reading every file.

Storage:
    data/corpus_index/manifest.json     -- repo list with last-indexed timestamps
    data/corpus_index/{repo_name}.json  -- per-repo file index with metadata
"""

import hashlib
import json
import logging
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
INDEX_DIR = ENGINE_ROOT / "data" / "corpus_index"
MANIFEST_PATH = INDEX_DIR / "manifest.json"

# File extensions to index (source code and documentation)
INDEXABLE_EXTENSIONS = frozenset(
    {
        ".py",
        ".go",
        ".dart",
        ".js",
        ".ts",
        ".rs",
        ".java",
        ".cs",
        ".sol",
        ".toml",
        ".yaml",
        ".yml",
        ".json",
        ".md",
        ".txt",
        ".sh",
        ".bash",
        ".html",
        ".css",
        ".sql",
        ".proto",
    }
)

# Additional extensions handled by file_extractors (images, PDFs, docs)
from core.file_extractors import ALL_EXTRACTABLE

EXTRACTABLE_EXTENSIONS = ALL_EXTRACTABLE

# Maximum file size to index (skip binaries and huge files)
MAX_FILE_SIZE_BYTES = 512 * 1024  # 512 KB

# Maximum files per repo to index
MAX_FILES_PER_REPO = 2000


class CorpusManager:
    """Manages the indexed corpus of workspace repositories.

    Usage::

        corpus = CorpusManager()
        corpus.index_repo("/path/to/repo")
        results = corpus.search("plasma fee mechanism")
        content = corpus.get_file_content("/path/to/repo", "src/main.go")
    """

    def __init__(self, workspace_root: str | None = None):
        """Initialize the corpus manager.

        Args:
            workspace_root: Root directory containing all repos.
                           Defaults to ZENON_WORKSPACE_ROOT env var
                           or two levels above engine root.
        """
        self.workspace_root = Path(
            workspace_root
            or os.environ.get("ZENON_WORKSPACE_ROOT", "")
            or str(ENGINE_ROOT.parents[0])
        )
        self.manifest: dict = self._load_manifest()

    def _ensure_index_dir(self) -> None:
        """Create index directory if needed."""
        INDEX_DIR.mkdir(parents=True, exist_ok=True)

    def _load_manifest(self) -> dict:
        """Load the manifest of indexed repos."""
        if MANIFEST_PATH.exists():
            try:
                return json.loads(MANIFEST_PATH.read_text())
            except (json.JSONDecodeError, OSError):
                pass
        return {"repos": {}, "last_full_scan": None}

    def _save_manifest(self) -> None:
        """Save the manifest to disk."""
        self._ensure_index_dir()
        MANIFEST_PATH.write_text(json.dumps(self.manifest, indent=2))

    def discover_repos(self) -> list[dict]:
        """Discover all git repositories under the workspace root.

        Returns:
            List of dicts with keys: name, path, has_git.
        """
        repos = []
        if not self.workspace_root.exists():
            logger.warning("Workspace root does not exist: %s", self.workspace_root)
            return repos

        for entry in sorted(self.workspace_root.iterdir()):
            if entry.is_dir() and not entry.name.startswith("."):
                has_git = (entry / ".git").exists()
                repos.append(
                    {
                        "name": entry.name,
                        "path": str(entry),
                        "has_git": has_git,
                    }
                )

        logger.info(
            "Discovered %d repos under %s",
            len(repos),
            self.workspace_root,
        )
        return repos

    def index_repo(self, repo_path: str, force: bool = False) -> dict:
        """Index a single repository.

        Scans all source files, records path, size, extension, and first-line
        summary. Skips files that haven't changed since last index unless force=True.

        Args:
            repo_path: Absolute path to the repository.
            force: Re-index even if the repo hasn't changed.

        Returns:
            Index summary dict with file count, total size, etc.
        """
        repo_path_obj = Path(repo_path)
        repo_name = repo_path_obj.name

        if not repo_path_obj.exists():
            logger.warning("Repo path does not exist: %s", repo_path)
            return {"error": f"Path does not exist: {repo_path}"}

        # Check if repo has changed since last index
        repo_info = self.manifest.get("repos", {}).get(repo_name, {})
        if not force and repo_info:
            repo_info.get("last_indexed", "")
            current_hash = self._compute_repo_hash(repo_path_obj)
            if repo_info.get("content_hash") == current_hash:
                logger.debug("Repo %s unchanged, skipping", repo_name)
                return {"skipped": True, "reason": "unchanged"}

        start = time.monotonic()
        files_indexed, total_size, extensions = self._walk_repo_files(repo_path_obj)
        elapsed = time.monotonic() - start

        # Save index
        self._ensure_index_dir()
        index_path = INDEX_DIR / f"{repo_name}.json"
        index_data = {
            "repo_name": repo_name,
            "indexed_at": datetime.now(timezone.utc).isoformat(),
            "file_count": len(files_indexed),
            "total_size_bytes": total_size,
            "extensions": extensions,
            "files": files_indexed,
        }
        index_path.write_text(json.dumps(index_data, indent=2))

        # Update manifest
        self.manifest.setdefault("repos", {})[repo_name] = {
            "path": str(repo_path_obj),
            "last_indexed": datetime.now(timezone.utc).isoformat(),
            "file_count": len(files_indexed),
            "total_size_bytes": total_size,
            "content_hash": self._compute_repo_hash(repo_path_obj),
        }
        self._save_manifest()

        logger.info(
            "Indexed %s: %d files, %d bytes in %.1fs",
            repo_name,
            len(files_indexed),
            total_size,
            elapsed,
        )

        return {
            "repo_name": repo_name,
            "files_indexed": len(files_indexed),
            "total_size_bytes": total_size,
            "extensions": extensions,
            "elapsed_seconds": round(elapsed, 2),
        }

    def search(
        self,
        query: str,
        repo_filter: str | None = None,
        ext_filter: str | None = None,
        max_results: int = 50,
    ) -> list[dict]:
        """Search the indexed corpus for files matching a query.

        Performs simple keyword matching against file paths and first lines.
        For full-text search, use the LLM with get_file_content().

        Args:
            query:       Search terms (space-separated).
            repo_filter: Optional repo name to search within.
            ext_filter:  Optional file extension filter (e.g. ".go").
            max_results: Maximum number of results.

        Returns:
            List of matching file entries with repo_name added.
        """
        terms = query.lower().split()
        if not terms:
            return []

        results = []
        repos_to_search = []

        if repo_filter:
            idx_path = INDEX_DIR / f"{repo_filter}.json"
            if idx_path.exists():
                repos_to_search.append((repo_filter, idx_path))
        else:
            if INDEX_DIR.exists():
                for idx_path in INDEX_DIR.glob("*.json"):
                    if idx_path.name == "manifest.json":
                        continue
                    repos_to_search.append((idx_path.stem, idx_path))

        for repo_name, idx_path in repos_to_search:
            try:
                data = json.loads(idx_path.read_text())
                for file_entry in data.get("files", []):
                    if ext_filter and file_entry.get("ext") != ext_filter:
                        continue

                    searchable = (
                        file_entry.get("path", "").lower()
                        + " "
                        + file_entry.get("first_line", "").lower()
                    )

                    if all(term in searchable for term in terms):
                        entry = dict(file_entry)
                        entry["repo_name"] = repo_name
                        results.append(entry)

                        if len(results) >= max_results:
                            return results

            except (json.JSONDecodeError, OSError):
                continue

        return results

    def get_file_content(self, repo_name: str, rel_path: str) -> str | None:
        """Read the content of a file from a repo.

        Args:
            repo_name: Repository name.
            rel_path:  Relative path within the repo.

        Returns:
            File content as string, or None if not found.
        """
        repo_info = self.manifest.get("repos", {}).get(repo_name, {})
        if not repo_info:
            return None

        full_path = Path(repo_info["path"]) / rel_path
        if not full_path.exists():
            return None

        try:
            return full_path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            return None

    def track_freshness(self) -> list[dict]:
        """Check which repos are stale (not indexed recently).

        Returns:
            List of repos with their freshness status.
        """
        freshness = []
        now = datetime.now(timezone.utc)

        for repo_name, info in self.manifest.get("repos", {}).items():
            last_indexed = info.get("last_indexed", "")
            if last_indexed:
                try:
                    indexed_dt = datetime.fromisoformat(last_indexed)
                    if indexed_dt.tzinfo is None:
                        indexed_dt = indexed_dt.replace(tzinfo=timezone.utc)
                    age_hours = (now - indexed_dt).total_seconds() / 3600
                except (ValueError, TypeError):
                    age_hours = float("inf")
            else:
                age_hours = float("inf")

            freshness.append(
                {
                    "repo_name": repo_name,
                    "last_indexed": last_indexed,
                    "age_hours": round(age_hours, 1),
                    "stale": age_hours > 168,  # > 1 week
                    "file_count": info.get("file_count", 0),
                }
            )

        return sorted(freshness, key=lambda x: x["age_hours"], reverse=True)

    def get_stats(self) -> dict:
        """Get aggregate stats across all indexed repos."""
        total_files = 0
        total_size = 0
        all_extensions: dict[str, int] = {}

        for _repo_name, info in self.manifest.get("repos", {}).items():
            total_files += info.get("file_count", 0)
            total_size += info.get("total_size_bytes", 0)

        # Count extensions from index files
        if INDEX_DIR.exists():
            for idx_path in INDEX_DIR.glob("*.json"):
                if idx_path.name == "manifest.json":
                    continue
                try:
                    data = json.loads(idx_path.read_text())
                    for ext, count in data.get("extensions", {}).items():
                        all_extensions[ext] = all_extensions.get(ext, 0) + count
                except (json.JSONDecodeError, OSError):
                    pass

        return {
            "total_repos": len(self.manifest.get("repos", {})),
            "total_files": total_files,
            "total_size_bytes": total_size,
            "extensions": all_extensions,
        }

    @staticmethod
    def _walk_repo_files(repo_path: Path) -> tuple[list[dict], int, dict]:
        """Walk a repo directory and collect file metadata.

        Returns:
            Tuple of (files_indexed, total_size, extensions_count).
        """
        files_indexed: list[dict] = []
        total_size = 0
        extensions: dict[str, int] = {}
        skip_dirs = {
            "node_modules",
            "vendor",
            "__pycache__",
            "build",
            "dist",
            ".git",
            "venv",
            ".venv",
        }

        for root, dirs, files in os.walk(repo_path):
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in skip_dirs]

            for fname in files:
                if len(files_indexed) >= MAX_FILES_PER_REPO:
                    break

                fpath = Path(root) / fname
                ext = fpath.suffix.lower()
                if ext not in INDEXABLE_EXTENSIONS:
                    continue

                try:
                    stat = fpath.stat()
                    if stat.st_size > MAX_FILE_SIZE_BYTES or stat.st_size == 0:
                        continue

                    rel_path = str(fpath.relative_to(repo_path))
                    first_line = ""
                    try:
                        with open(fpath, encoding="utf-8", errors="ignore") as f:
                            first_line = f.readline().strip()[:200]
                    except (OSError, UnicodeDecodeError):
                        pass

                    files_indexed.append(
                        {
                            "path": rel_path,
                            "size": stat.st_size,
                            "ext": ext,
                            "first_line": first_line,
                            "modified": datetime.fromtimestamp(
                                stat.st_mtime, tz=timezone.utc
                            ).isoformat(),
                        }
                    )
                    total_size += stat.st_size
                    extensions[ext] = extensions.get(ext, 0) + 1
                except OSError:
                    continue

        return files_indexed, total_size, extensions

    def _compute_repo_hash(self, repo_path: Path) -> str:
        """Compute a quick hash of repo state using git."""
        try:
            result = subprocess.run(
                ["git", "log", "-1", "--format=%H"],
                capture_output=True,
                text=True,
                cwd=str(repo_path),
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            pass

        # Fallback: hash of directory listing
        try:
            files = sorted(str(p) for p in repo_path.rglob("*") if p.is_file())
            return hashlib.sha256("\n".join(files[:100]).encode()).hexdigest()[:16]
        except OSError:
            return ""
