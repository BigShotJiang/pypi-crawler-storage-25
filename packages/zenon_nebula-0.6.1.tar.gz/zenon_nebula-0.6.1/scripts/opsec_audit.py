#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Run an OPSEC audit against your live Nebula instance.

This script scans the local evidence database, log files, and any
data files under ``data/`` for patterns that should never be there:
- Local filesystem paths (``/Users/``, ``/home/``, ``C:\\Users\\``)
- API keys (OpenAI, xAI, Anthropic, GitHub, AWS, GCP)
- Email addresses
- IP addresses
- SSH / wallet private keys
- Bearer tokens

It reports what it finds and exits non-zero if any leaks are
detected. Use it to verify that Nebula's OPSEC claims hold for
your instance — if this script reports clean, the community
audit doc is honest for you.

Usage:
    python3 scripts/opsec_audit.py              # scan + report
    python3 scripts/opsec_audit.py --json       # machine-readable
    python3 scripts/opsec_audit.py --quiet      # exit code only

Exit codes:
    0 — no leaks detected
    1 — leaks detected (see output)
    2 — audit could not run (DB unreadable, etc.)
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DEFAULT_DB = DATA_DIR / "engine.db"


# Fields in the evidence table that might contain free-form text
# and therefore might contain leaks. These are the fields that
# sanitize_for_sharing and sanitize_prompt are supposed to scrub.
EVIDENCE_TEXT_FIELDS = ("finding", "raw_data", "source_file")
HYPOTHESIS_TEXT_FIELDS = ("title", "description", "last_reasoning")


def _load_leak_checker():
    """Return a checker that categorizes hits by severity.

    Two categories:

    - **critical**: secrets that should NEVER be in the DB under any
      threat model (API keys, GitHub PATs, private keys, wallet keys,
      bearer tokens). If these appear, sanitize_prompt is broken or
      a secret bypassed it.

    - **local-only**: operator's own filesystem paths and emails that
      are fine in the LOCAL database (the operator owns their data)
      but would leak if the DB were exported. These are scrubbed on
      every outbound path (snapshot export, RPC responses) via
      sanitize_for_sharing. Their presence locally is informational,
      not a bug.

    Returns a function ``(text) -> {"critical": [...], "local": [...]}``.
    """
    import re

    critical_patterns = [
        (r"sk-[a-zA-Z0-9]{20,}", "OpenAI-style API key"),
        (r"xai-[a-zA-Z0-9]{20,}", "xAI API key"),
        (r"sk-ant-[a-zA-Z0-9-]+", "Anthropic API key"),
        (r"ghp_[a-zA-Z0-9]{36}", "GitHub PAT"),
        (r"gho_[a-zA-Z0-9]{36}", "GitHub OAuth token"),
        (r"AKIA[0-9A-Z]{16}", "AWS access key"),
        (r"AIza[0-9A-Za-z_-]{35}", "GCP API key"),
        (r"Bearer\s+[a-zA-Z0-9._\-]{20,}", "Bearer token"),
        (r"ssh-(rsa|ed25519|dss|ecdsa)\s+[A-Za-z0-9+/=]+", "SSH public key material"),
        (r"-----BEGIN (RSA|EC|OPENSSH|DSA) PRIVATE KEY-----", "PEM private key"),
    ]
    local_patterns = [
        (r"/Users/\w+/", "macOS username path"),
        (r"/home/\w+/", "Linux username path"),
        (r"C:\\Users\\\w+\\", "Windows username path"),
        (r"\b[\w.+-]+@[\w.-]+\.\w{2,}\b", "email address"),
        (r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", "IP address"),
    ]

    critical_compiled = [(re.compile(p, re.IGNORECASE), desc) for p, desc in critical_patterns]
    local_compiled = [(re.compile(p, re.IGNORECASE), desc) for p, desc in local_patterns]

    def check(content: str) -> dict:
        if not content:
            return {"critical": [], "local": []}
        critical: list[str] = []
        local: list[str] = []
        for pat, desc in critical_compiled:
            m = pat.findall(content)
            if m:
                critical.append(f"{desc}: {len(m)} matches")
        for pat, desc in local_compiled:
            m = pat.findall(content)
            if m:
                local.append(f"{desc}: {len(m)} matches")
        return {"critical": critical, "local": local}

    return check


def _scan_sqlite(db_path: Path, checker) -> dict:
    """Walk the evidence + hypotheses tables looking for leaks."""
    if not db_path.exists():
        return {"status": "skipped", "reason": f"no db at {db_path}", "critical": [], "local": []}

    critical_findings: list[dict] = []
    local_findings: list[dict] = []
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except sqlite3.OperationalError as exc:
        return {"status": "error", "reason": str(exc), "critical": [], "local": []}

    try:
        try:
            rows = conn.execute(
                "SELECT id, domain, engine, finding, raw_data, source_file FROM evidence"
            ).fetchall()
        except sqlite3.OperationalError:
            rows = []
        for row in rows:
            for i, field in enumerate(("finding", "raw_data", "source_file"), start=3):
                text = row[i]
                if not isinstance(text, str):
                    continue
                hits = checker(text)
                if hits["critical"]:
                    critical_findings.append(
                        {
                            "source": f"evidence.id={row[0]}",
                            "domain": row[1],
                            "engine": row[2],
                            "field": field,
                            "leaks": hits["critical"],
                        }
                    )
                if hits["local"]:
                    local_findings.append(
                        {
                            "source": f"evidence.id={row[0]}",
                            "domain": row[1],
                            "engine": row[2],
                            "field": field,
                            "leaks": hits["local"],
                        }
                    )

        try:
            rows = conn.execute("SELECT id, domain, title FROM hypotheses").fetchall()
        except sqlite3.OperationalError:
            rows = []
        for row in rows:
            text = row[2] or ""
            hits = checker(text)
            if hits["critical"]:
                critical_findings.append(
                    {
                        "source": f"hypotheses.id={row[0]}",
                        "domain": row[1],
                        "field": "title",
                        "leaks": hits["critical"],
                    }
                )
            if hits["local"]:
                local_findings.append(
                    {
                        "source": f"hypotheses.id={row[0]}",
                        "domain": row[1],
                        "field": "title",
                        "leaks": hits["local"],
                    }
                )
    finally:
        conn.close()

    return {
        "status": "ok",
        "reason": f"scanned {db_path.name}",
        "critical": critical_findings,
        "local": local_findings,
    }


def _scan_text_files(data_dir: Path, checker, glob_pattern: str, label: str) -> dict:
    """Walk files matching glob and apply the checker to each.

    Used for both logs (``*.log``) and loose JSON (``*.json``).
    """
    if not data_dir.is_dir():
        return {"status": "skipped", "reason": f"no dir at {data_dir}", "critical": [], "local": []}

    critical_findings: list[dict] = []
    local_findings: list[dict] = []
    for f in sorted(data_dir.rglob(glob_pattern)):
        if "snapshots" in f.parts:
            continue  # snapshots have their own sanitize path
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        hits = checker(text)
        if hits["critical"]:
            critical_findings.append(
                {
                    "source": str(f.relative_to(data_dir)),
                    "leaks": hits["critical"],
                }
            )
        if hits["local"]:
            local_findings.append(
                {
                    "source": str(f.relative_to(data_dir)),
                    "leaks": hits["local"],
                }
            )
    return {
        "status": "ok",
        "reason": f"scanned {label} under {data_dir.name}",
        "critical": critical_findings,
        "local": local_findings,
    }


def run_audit(db_path: Path = DEFAULT_DB, data_dir: Path = DATA_DIR) -> dict:
    """Run the complete audit and return a summary dict."""
    checker = _load_leak_checker()
    results = {
        "db": _scan_sqlite(db_path, checker),
        "logs": _scan_text_files(data_dir, checker, "*.log", "logs"),
        "json_files": _scan_text_files(data_dir, checker, "*.json", "json files"),
    }
    critical_total = sum(len(r["critical"]) for r in results.values())
    local_total = sum(len(r["local"]) for r in results.values())
    results["summary"] = {
        "critical_total": critical_total,
        "local_total": local_total,
        "clean": critical_total == 0,
    }
    return results


def print_report(results: dict) -> None:
    crit = results["summary"]["critical_total"]
    loc = results["summary"]["local_total"]
    print("=" * 66)
    print("  Nebula OPSEC Audit")
    print("=" * 66)
    print()
    print("  CRITICAL = secrets that must NEVER be in your data (API keys, PATs,")
    print("             private keys, bearer tokens). If present, sanitize_prompt")
    print("             is broken — report immediately.")
    print()
    print("  LOCAL    = filesystem paths / emails / IPs. These are fine in your")
    print("             LOCAL DB (your data, your machine). Sanitized automatically")
    print("             on every outbound path (snapshot export, RPC, LLM call).")
    print()
    print("-" * 66)
    print("  CRITICAL findings")
    print("-" * 66)
    if crit == 0:
        print("  [OK] No secrets found. Your sanitize_prompt path is working.")
    else:
        for section in ("db", "logs", "json_files"):
            for leak in results[section]["critical"][:10]:
                print(f"  [!] {section}/{leak['source']}: {', '.join(leak['leaks'])}")
        if crit > 30:
            print(f"  ... and {crit - 30} more")
    print()
    print("-" * 66)
    print(f"  LOCAL-ONLY findings (informational — {loc} total)")
    print("-" * 66)
    for section in ("db", "logs", "json_files"):
        n = len(results[section]["local"])
        status = "clean" if n == 0 else f"{n} local refs"
        print(f"  {section:12s}: {status}")
    print()
    if crit == 0:
        print("  Result: PASS. No critical leaks.")
        if loc > 0:
            print(f"  (You have {loc} local paths/emails/IPs in your DB — that's")
            print("   fine for local use. They're scrubbed on every export path.)")
        print()
        print("  Your instance matches the claims in docs/SECURITY-OPSEC-AUDIT.md.")
    else:
        print(f"  Result: FAIL. {crit} critical leaks found.")
        print("  This means a secret (API key, private key, etc.) reached your")
        print("  DB without being sanitized. Please:")
        print("    - investigate where the secret came from (engine, prompt, etc.)")
        print("    - file a private disclosure per SECURITY.md")
        print("    - strengthen the OPSECGuard patterns in core/opsec.py")
    print("=" * 66)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="opsec-audit")
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    parser.add_argument("--quiet", action="store_true", help="exit code only, no output")
    parser.add_argument("--db", default=str(DEFAULT_DB), help="path to engine.db")
    args = parser.parse_args(argv)

    try:
        results = run_audit(Path(args.db), DATA_DIR)
    except Exception as exc:
        print(f"audit failed: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(results, indent=2, default=str))
    elif not args.quiet:
        print_report(results)

    return 0 if results["summary"]["clean"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
