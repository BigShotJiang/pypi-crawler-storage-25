#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Add or verify SPDX license headers on Nebula source files.

Walks ``core/``, ``domains/``, ``scripts/``, and ``tests/`` and inserts a
single-line SPDX license header at the top of every Python source file that
does not already have one. Designed to be safe to re-run and to plug into
CI in ``--check`` mode so pull requests that add new source files without
a license tag fail fast.

The canonical header we enforce:

    # SPDX-License-Identifier: MIT

When a file starts with a shebang (``#!/usr/bin/env python3``) the header
is inserted on line 2 instead of line 1 so the shebang keeps working.

Empty ``__init__.py`` files are skipped because they are markers, not
code. Files that already contain any ``SPDX-License-Identifier`` line
are left alone.

Usage:
    python3 scripts/add_license_headers.py              # write in place
    python3 scripts/add_license_headers.py --check      # exit 1 if any
                                                        # file is missing
                                                        # the header
    python3 scripts/add_license_headers.py --dry-run    # preview
    python3 scripts/add_license_headers.py --verbose    # show each file

Exit codes:
    0 - success (headers in place in write mode, or all good in --check)
    1 - one or more files missing the header (--check only)
    2 - bad usage / IO error
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

HEADER = "# SPDX-License-Identifier: MIT"
SPDX_TAG = "SPDX-License-Identifier"

SCAN_DIRS = ("core", "domains", "scripts", "tests")

EXCLUDED_DIRS = {
    ".venv",
    "venv",
    "__pycache__",
    ".git",
    "build",
    "dist",
    ".mypy_cache",
    ".ruff_cache",
    ".pytest_cache",
    "site",
    "data",
    "fixtures",
}


def _iter_py_files(base: Path):
    """Yield every tracked .py file under base, skipping build artefacts."""
    for p in base.rglob("*.py"):
        if any(part in EXCLUDED_DIRS for part in p.parts):
            continue
        yield p


def _is_skippable_init(path: Path) -> bool:
    """Empty __init__.py files get skipped because they are markers.

    A non-empty __init__.py gets a header like any other source file.
    """
    if path.name != "__init__.py":
        return False
    try:
        return path.stat().st_size == 0
    except OSError:
        return True


def has_header(text: str) -> bool:
    """Return True if the file already carries any SPDX header."""
    # Scan only the first 20 lines so we don't read through huge fixtures.
    head = "\n".join(text.splitlines()[:20])
    return SPDX_TAG in head


def insert_header(text: str) -> str:
    """Return a copy of ``text`` with the canonical header inserted.

    Preserves a leading shebang if one is present by inserting the
    header on line 2.
    """
    if text.startswith("#!"):
        nl = text.find("\n")
        if nl == -1:
            # File is a single shebang line with no trailing newline.
            return text + "\n" + HEADER + "\n"
        return text[: nl + 1] + HEADER + "\n" + text[nl + 1 :]
    return HEADER + "\n" + text


def process_file(path: Path, *, check: bool, dry_run: bool, verbose: bool) -> bool:
    """Handle one file. Return True if the file was (or would be) updated."""
    if _is_skippable_init(path):
        return False
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"error reading {path}: {exc}", file=sys.stderr)
        return False
    if has_header(text):
        return False

    if check:
        rel = path.relative_to(ROOT)
        print(f"missing SPDX header: {rel}", file=sys.stderr)
        return True

    new_text = insert_header(text)
    if dry_run:
        if verbose:
            rel = path.relative_to(ROOT)
            print(f"would add header: {rel}")
        return True

    try:
        path.write_text(new_text, encoding="utf-8")
    except OSError as exc:
        print(f"error writing {path}: {exc}", file=sys.stderr)
        return False
    if verbose:
        rel = path.relative_to(ROOT)
        print(f"added header: {rel}")
    return True


def collect_targets(extra_dirs: list[str] | None = None) -> list[Path]:
    dirs = list(SCAN_DIRS)
    if extra_dirs:
        dirs.extend(extra_dirs)
    paths: list[Path] = []
    for d in dirs:
        base = ROOT / d
        if not base.is_dir():
            continue
        paths.extend(sorted(_iter_py_files(base)))
    return paths


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Add or verify SPDX-License-Identifier headers.",
    )
    ap.add_argument(
        "--check",
        action="store_true",
        help="Exit 1 if any file is missing the header. Read-only.",
    )
    ap.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview changes without writing anything.",
    )
    ap.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Print each file that gets (or would get) a header.",
    )
    ap.add_argument(
        "--extra-dir",
        action="append",
        default=[],
        help="Additional directory (relative to repo root) to scan.",
    )
    args = ap.parse_args(argv)

    if args.check and args.dry_run:
        print("error: --check and --dry-run are mutually exclusive", file=sys.stderr)
        return 2

    targets = collect_targets(args.extra_dir)
    updated = 0
    for path in targets:
        if process_file(
            path,
            check=args.check,
            dry_run=args.dry_run,
            verbose=args.verbose,
        ):
            updated += 1

    if args.check:
        if updated:
            print(
                f"\n{updated} file(s) missing SPDX header. "
                f"Run: python3 scripts/add_license_headers.py",
                file=sys.stderr,
            )
            return 1
        if args.verbose:
            print(f"all {len(targets)} file(s) have SPDX headers")
        return 0

    if args.dry_run:
        print(f"dry-run: {updated} file(s) would be updated")
    else:
        print(f"updated {updated} file(s) of {len(targets)} scanned")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
