#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Collect a diagnostic bundle for bug reports.

Dumps a zip archive under ``data/diagnostics/`` containing:

* Nebula version (``./nebula version``)
* Doctor output (``./nebula doctor``)
* Python version and platform
* ``pip freeze`` output
* Last 100 rows of the major evidence tables
* Last 1000 lines of every log file under ``data/``
* SQLite schema dump (``sqlite_master``)
* Whitelisted environment variables (``NEBULA_*``, ``XAI_*`` with
  keys redacted to their first 4 characters)

Every text file in the bundle is sanitized via :mod:`core.opsec`
when that module is available, so identity and path leaks never
reach the zip.

Usage:
    python3 scripts/diagnose.py              # write bundle, print path
    python3 scripts/diagnose.py --quiet      # silent except for the path
    python3 scripts/diagnose.py -o OUT.zip   # custom output path

Exit codes:
    0 — bundle written successfully
    1 — unrecoverable failure during collection
    2 — bad usage
"""

from __future__ import annotations

import argparse
import io
import json
import os
import platform
import sqlite3
import subprocess
import sys
import textwrap
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DEFAULT_DB = DATA_DIR / "engine.db"
DIAGNOSTICS_DIR = DATA_DIR / "diagnostics"

ENV_ALLOWLIST_PREFIXES = ("NEBULA_", "XAI_", "ZENON_")
REDACT_SUFFIXES = ("_KEY", "_TOKEN", "_SECRET", "_PASSWORD")

MAJOR_TABLES = (
    "evidence",
    "hypotheses",
    "collisions",
    "actions_log",
    "cost_tracking",
)


def _try_opsec_scrub(text: str) -> str:
    """Pass text through core.opsec sanitizer if available.

    This was previously broken — it imported a non-existent
    ``core.opsec.sanitize`` function and silently fell through
    to returning the raw text on every bundle. The actual
    function is ``OPSECGuard.sanitize_prompt``.
    """
    if not text:
        return text
    try:
        from core.opsec import OPSECGuard
    except Exception:
        return text
    try:
        return OPSECGuard.sanitize_prompt(text)
    except Exception:
        return text


def _nebula(*args: str, timeout: int = 15) -> str:
    """Run the ``./nebula`` controller and return stdout + stderr."""
    cmd = [sys.executable, str(ROOT / "nebula"), *args]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(ROOT),
        )
    except Exception as exc:
        return f"<nebula {' '.join(args)} failed: {exc}>\n"
    return (result.stdout or "") + (result.stderr or "")


def _pip_freeze(timeout: int = 30) -> str:
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "freeze"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except Exception as exc:
        return f"<pip freeze failed: {exc}>\n"
    return result.stdout or ""


def _collect_environment() -> str:
    lines = ["# Environment (allowlisted NEBULA_*, XAI_*, ZENON_* only)"]
    for key in sorted(os.environ):
        if not any(key.startswith(p) for p in ENV_ALLOWLIST_PREFIXES):
            continue
        value = os.environ[key]
        if any(key.endswith(s) for s in REDACT_SUFFIXES):
            # Redact secret values to the first 4 chars + ellipsis.
            redacted = (value[:4] + "...") if value else "<empty>"
            lines.append(f"{key}={redacted}")
        else:
            lines.append(f"{key}={value}")
    return "\n".join(lines) + "\n"


def _collect_platform() -> str:
    info = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "python_version": sys.version,
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "node": "<redacted>",  # hostname is PII; don't leak it
    }
    return json.dumps(info, indent=2)


def _collect_db_rows(db_path: Path, table: str, limit: int = 100) -> str:
    """Return the last ``limit`` rows of a table as CSV-ish text."""
    if not db_path.exists():
        return f"<database missing: {db_path}>\n"
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            cur = conn.execute(
                f'SELECT * FROM "{table}" ORDER BY ROWID DESC LIMIT ?',
                (limit,),
            )
            cols = [d[0] for d in (cur.description or [])]
            rows = cur.fetchall()
        finally:
            conn.close()
    except sqlite3.Error as exc:
        return f"<table {table}: {exc}>\n"
    out = io.StringIO()
    out.write("\t".join(cols) + "\n")
    for row in rows:
        out.write("\t".join("" if v is None else str(v) for v in row) + "\n")
    return out.getvalue()


def _collect_schema_dump(db_path: Path) -> str:
    if not db_path.exists():
        return f"<database missing: {db_path}>\n"
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            rows = conn.execute(
                "SELECT type, name, tbl_name, sql FROM sqlite_master ORDER BY type, name"
            ).fetchall()
        finally:
            conn.close()
    except sqlite3.Error as exc:
        return f"<schema dump failed: {exc}>\n"
    out = io.StringIO()
    for kind, name, tbl, sql in rows:
        out.write(f"-- {kind} {name} ({tbl})\n")
        if sql:
            out.write(sql + ";\n")
        out.write("\n")
    return out.getvalue()


def _tail_file(path: Path, lines: int = 1000) -> str:
    """Return the last ``lines`` lines of ``path`` as text."""
    try:
        with path.open("rb") as fh:
            # Cheap tail: read the whole file for logs under a few MB.
            raw = fh.read()
    except OSError as exc:
        return f"<cannot read {path.name}: {exc}>\n"
    text = raw.decode("utf-8", errors="replace")
    return "\n".join(text.splitlines()[-lines:])


def _collect_logs() -> list[tuple[str, str]]:
    """Return a list of (archive_name, text) tuples for every log file."""
    results: list[tuple[str, str]] = []
    if not DATA_DIR.is_dir():
        return results
    for log in sorted(DATA_DIR.rglob("*.log")):
        if not log.is_file():
            continue
        try:
            rel = log.relative_to(DATA_DIR)
        except ValueError:
            rel = log.name
        results.append((f"logs/{rel}", _tail_file(log)))
    return results


def build_bundle(output: Path, *, verbose: bool = True) -> int:
    """Write a diagnostic zip to ``output``. Returns exit code."""
    output.parent.mkdir(parents=True, exist_ok=True)

    sections: list[tuple[str, str]] = []

    def add(name: str, text: str) -> None:
        sections.append((name, _try_opsec_scrub(text)))

    try:
        add(
            "README.txt",
            textwrap.dedent(f"""\
            Nebula diagnostic bundle
            Generated: {datetime.now(timezone.utc).isoformat()}

            This archive is safe to attach to a bug report. Secrets have
            been redacted and identity / path leaks stripped via
            core.opsec when available. Review the contents before
            sharing if you want to be extra careful.
        """),
        )
        add("version.txt", _nebula("version"))
        add("doctor.txt", _nebula("doctor"))
        add("platform.json", _collect_platform())
        add("environment.txt", _collect_environment())
        add("pip-freeze.txt", _pip_freeze())
        add("schema.sql", _collect_schema_dump(DEFAULT_DB))
        for table in MAJOR_TABLES:
            add(f"tables/{table}.tsv", _collect_db_rows(DEFAULT_DB, table))
        for name, text in _collect_logs():
            add(name, text)
    except Exception as exc:
        print(f"diagnose: collection failed: {exc}", file=sys.stderr)
        return 1

    try:
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as zf:
            for name, text in sections:
                zf.writestr(name, text)
    except OSError as exc:
        print(f"diagnose: cannot write {output}: {exc}", file=sys.stderr)
        return 1

    if verbose:
        print(f"diagnostic bundle written: {output}")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="Output zip path. Defaults to data/diagnostics/<timestamp>.zip",
    )
    ap.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Print only the output path on success.",
    )
    args = ap.parse_args(argv)

    if args.output is None:
        DIAGNOSTICS_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        out = DIAGNOSTICS_DIR / f"nebula-diagnose-{stamp}.zip"
    else:
        out = args.output

    rc = build_bundle(out, verbose=not args.quiet)
    if rc == 0 and args.quiet:
        print(out)
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
