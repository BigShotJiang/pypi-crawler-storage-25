#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Generate ``requirements.lock`` from ``requirements.txt``.

Two modes:

* **pip-compile mode** (preferred): when the ``pip-tools`` package is
  importable, this script shells out to ``pip-compile`` to produce a
  fully-resolved lockfile with transitive dependencies and hashes.
* **fallback mode**: when ``pip-tools`` is not available, it walks the
  currently-installed distributions via :mod:`importlib.metadata`,
  captures everything that maps back to ``requirements.txt`` plus
  each transitive dependency, and writes a lockfile with exact pinned
  versions. This is less rigorous than pip-compile (no hashes, no
  fresh resolution) but is enough for reproducibility on the same
  interpreter.

Usage:
    python3 scripts/generate_lockfile.py
    python3 scripts/generate_lockfile.py --check   # exit 1 if stale

Exit codes:
    0 — lockfile written (or up to date in --check)
    1 — lockfile is stale (--check only)
    2 — bad usage or IO error
"""

from __future__ import annotations

import argparse
import importlib.metadata as im
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIREMENTS = ROOT / "requirements.txt"
LOCKFILE = ROOT / "requirements.lock"

HEADER = """\
# Generated from requirements.txt. Regenerate with:
#   pip-compile requirements.txt -o requirements.lock
# or (fallback, stdlib-only):
#   python3 scripts/generate_lockfile.py
#
# This lockfile pins every transitive dependency so `pip install -r
# requirements.lock` produces a reproducible environment. Update it
# whenever requirements.txt changes.
"""

_PKG_RE = re.compile(r"^([A-Za-z0-9_.\-]+)")


def parse_requirements(path: Path) -> list[str]:
    """Return the base package names declared in a requirements file."""
    names: list[str] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # Strip inline comments and markers.
        if "#" in line:
            line = line.split("#", 1)[0].strip()
        m = _PKG_RE.match(line)
        if m:
            names.append(m.group(1))
    return names


def _distributions() -> dict[str, im.Distribution]:
    """Return {normalized_name: Distribution} for every installed dist."""
    out: dict[str, im.Distribution] = {}
    for dist in im.distributions():
        name = dist.metadata.get("Name") if dist.metadata else None
        if not name:
            continue
        out[name.lower().replace("_", "-")] = dist
    return out


def _collect_transitive(
    seeds: list[str],
    dists: dict[str, im.Distribution],
) -> dict[str, str]:
    """Walk ``Requires-Dist`` edges for every seed and return pinned versions."""
    result: dict[str, str] = {}
    queue = [s.lower().replace("_", "-") for s in seeds]
    seen: set[str] = set()

    while queue:
        key = queue.pop()
        if key in seen:
            continue
        seen.add(key)
        dist = dists.get(key)
        if dist is None:
            # Not installed — emit a TODO entry so the operator knows.
            continue
        canonical_name = dist.metadata.get("Name", key)
        result[canonical_name] = dist.version

        for req in dist.requires or []:
            dep_name = _PKG_RE.match(req)
            if not dep_name:
                continue
            dep_key = dep_name.group(1).lower().replace("_", "-")
            if dep_key not in seen:
                queue.append(dep_key)
    return result


def render_lockfile(pinned: dict[str, str]) -> str:
    lines = [HEADER]
    for name in sorted(pinned, key=str.lower):
        lines.append(f"{name}=={pinned[name]}")
    lines.append("")
    return "\n".join(lines)


def _pip_compile_mode(check: bool) -> int:
    """Run ``pip-compile`` if available. Return exit code or None."""
    try:
        import piptools  # noqa: F401
    except ImportError:
        return -1
    args = [
        sys.executable,
        "-m",
        "piptools",
        "compile",
        "-o",
        str(LOCKFILE),
        str(REQUIREMENTS),
    ]
    if check:
        args.append("--dry-run")
    result = subprocess.run(args, cwd=str(ROOT))
    return result.returncode


def _fallback_mode(check: bool) -> int:
    """Resolve via importlib.metadata on the active interpreter."""
    seeds = parse_requirements(REQUIREMENTS)
    dists = _distributions()
    pinned = _collect_transitive(seeds, dists)
    content = render_lockfile(pinned)

    if check:
        if not LOCKFILE.exists():
            print("requirements.lock missing — regenerate it.", file=sys.stderr)
            return 1
        current = LOCKFILE.read_text(encoding="utf-8")
        if current.strip() != content.strip():
            print(
                "requirements.lock is stale — regenerate with python3 scripts/generate_lockfile.py",
                file=sys.stderr,
            )
            return 1
        return 0

    LOCKFILE.write_text(content, encoding="utf-8")
    print(f"wrote {LOCKFILE.relative_to(ROOT)} with {len(pinned)} pins")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--check",
        action="store_true",
        help="Exit 1 if the lockfile would change.",
    )
    ap.add_argument(
        "--no-pip-compile",
        action="store_true",
        help="Skip pip-compile even if pip-tools is available.",
    )
    args = ap.parse_args(argv)

    if not REQUIREMENTS.exists():
        print(f"requirements.txt missing: {REQUIREMENTS}", file=sys.stderr)
        return 2

    if not args.no_pip_compile:
        rc = _pip_compile_mode(args.check)
        if rc != -1:
            return rc

    return _fallback_mode(args.check)


if __name__ == "__main__":
    raise SystemExit(main())
