#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
inspect_db.py — evidence archaeology tool for the Nebula DB.

Usage:
    ./scripts/inspect_db.py recent --domain security --limit 10
    ./scripts/inspect_db.py breakthroughs
    ./scripts/inspect_db.py stale-engines
    ./scripts/inspect_db.py duplicate-findings
    ./scripts/inspect_db.py low-confidence --threshold 0.3
    ./scripts/inspect_db.py by-engine --engine upstream_watcher
    ./scripts/inspect_db.py cost-leaders
    ./scripts/inspect_db.py hypothesis <id>
    ./scripts/inspect_db.py domain-health

Read-only. Uses sqlite3 directly. No external dependencies.
"""

from __future__ import annotations

import argparse
import sqlite3
import sys
from pathlib import Path

DEFAULT_DB = Path(__file__).resolve().parents[1] / "data" / "engine.db"


def _connect(db_path: str) -> sqlite3.Connection:
    """Open a read-only connection to the Nebula DB."""
    if not Path(db_path).exists():
        print(f"error: database not found at {db_path}", file=sys.stderr)
        sys.exit(2)
    uri = f"file:{db_path}?mode=ro"
    conn = sqlite3.connect(uri, uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def _print_table(rows: list, headers: list[str], widths: list[int] | None = None) -> None:
    """Print a simple left-aligned aligned-column table."""
    if not rows:
        print("(no rows)")
        return
    if widths is None:
        widths = [len(h) for h in headers]
        for row in rows:
            for i, val in enumerate(row):
                widths[i] = max(widths[i], len(str(val)))
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    sep = "  ".join("-" * w for w in widths)
    print(fmt.format(*headers))
    print(sep)
    for row in rows:
        print(fmt.format(*[str(v) if v is not None else "" for v in row]))
    print(f"({len(rows)} row{'s' if len(rows) != 1 else ''})")


def _truncate(s: str | None, n: int) -> str:
    """Trim a string to n chars with ellipsis."""
    if s is None:
        return ""
    s = str(s).replace("\n", " ").strip()
    return s if len(s) <= n else s[: n - 1] + "..."


# ─────────────────────────── subcommands ───────────────────────────


def cmd_recent(conn: sqlite3.Connection, args) -> None:
    """Show the most recent findings, optionally filtered by domain."""
    q = "SELECT id, timestamp, domain, engine, confidence, finding FROM evidence"
    params: list = []
    if args.domain:
        q += " WHERE domain = ?"
        params.append(args.domain)
    q += " ORDER BY timestamp DESC LIMIT ?"
    params.append(args.limit)
    rows = [
        (
            r["id"],
            _truncate(r["timestamp"], 19),
            r["domain"],
            r["engine"],
            f"{r['confidence']:.2f}" if r["confidence"] is not None else "",
            _truncate(r["finding"], 60),
        )
        for r in conn.execute(q, params).fetchall()
    ]
    _print_table(rows, ["id", "timestamp", "domain", "engine", "conf", "finding"])


def cmd_breakthroughs(conn: sqlite3.Connection, args) -> None:
    """Show high-confidence cross-domain findings or COMPELLING hypotheses."""
    print("── high-confidence findings (conf >= 0.9) ──")
    rows = [
        (r["id"], r["domain"], r["engine"], f"{r['confidence']:.2f}", _truncate(r["finding"], 80))
        for r in conn.execute(
            "SELECT id, domain, engine, confidence, finding FROM evidence "
            "WHERE confidence >= 0.9 ORDER BY timestamp DESC LIMIT ?",
            (args.limit,),
        ).fetchall()
    ]
    _print_table(rows, ["id", "domain", "engine", "conf", "finding"])
    print()
    print("── compelling hypotheses ──")
    hrows = [
        (r["id"], r["domain"], f"{r['confidence']:.2f}", r["status"], _truncate(r["title"], 70))
        for r in conn.execute(
            "SELECT id, domain, confidence, status, title FROM hypotheses "
            "WHERE status IN ('COMPELLING','CONFIRMED') OR confidence >= 0.85 "
            "ORDER BY confidence DESC LIMIT ?",
            (args.limit,),
        ).fetchall()
    ]
    _print_table(hrows, ["id", "domain", "conf", "status", "title"])


def cmd_stale_engines(conn: sqlite3.Connection, args) -> None:
    """List engines that have not written a finding in the last N days."""
    rows = [
        (r["engine"], r["domain"], r["last_run"], r["total"])
        for r in conn.execute(
            "SELECT engine, domain, MAX(timestamp) AS last_run, COUNT(*) AS total "
            "FROM evidence WHERE engine IS NOT NULL "
            "GROUP BY engine ORDER BY last_run ASC"
        ).fetchall()
    ]
    _print_table(rows, ["engine", "domain", "last_run", "total_findings"])


def cmd_duplicate_findings(conn: sqlite3.Connection, args) -> None:
    """Show findings that appear more than once with the same finding text."""
    rows = [
        (r["count"], r["domain"], r["engine"], _truncate(r["finding"], 80))
        for r in conn.execute(
            "SELECT COUNT(*) AS count, domain, engine, finding "
            "FROM evidence WHERE finding IS NOT NULL "
            "GROUP BY domain, engine, finding HAVING count > 1 "
            "ORDER BY count DESC LIMIT ?",
            (args.limit,),
        ).fetchall()
    ]
    _print_table(rows, ["count", "domain", "engine", "finding"])


def cmd_low_confidence(conn: sqlite3.Connection, args) -> None:
    """Show findings below a confidence threshold (likely noise)."""
    rows = [
        (
            r["id"],
            r["domain"],
            r["engine"],
            f"{r['confidence']:.2f}" if r["confidence"] is not None else "",
            _truncate(r["finding"], 70),
        )
        for r in conn.execute(
            "SELECT id, domain, engine, confidence, finding FROM evidence "
            "WHERE confidence < ? ORDER BY confidence ASC LIMIT ?",
            (args.threshold, args.limit),
        ).fetchall()
    ]
    _print_table(rows, ["id", "domain", "engine", "conf", "finding"])


def cmd_by_engine(conn: sqlite3.Connection, args) -> None:
    """Show findings from a specific engine."""
    rows = [
        (
            r["id"],
            _truncate(r["timestamp"], 19),
            f"{r['confidence']:.2f}" if r["confidence"] is not None else "",
            _truncate(r["finding"], 80),
        )
        for r in conn.execute(
            "SELECT id, timestamp, confidence, finding FROM evidence "
            "WHERE engine = ? ORDER BY timestamp DESC LIMIT ?",
            (args.engine, args.limit),
        ).fetchall()
    ]
    _print_table(rows, ["id", "timestamp", "conf", "finding"])


def cmd_cost_leaders(conn: sqlite3.Connection, args) -> None:
    """Show the modules and models that have cost the most USD."""
    print("── top modules by total cost ──")
    rows = [
        (r["module"] or "(none)", r["model"] or "(none)", f"${r['total']:.4f}", r["calls"])
        for r in conn.execute(
            "SELECT module, model, "
            "SUM(COALESCE(cost_usd,0) + COALESCE(amount_usd,0)) AS total, "
            "COUNT(*) AS calls FROM cost_tracking "
            "GROUP BY module, model ORDER BY total DESC LIMIT ?",
            (args.limit,),
        ).fetchall()
    ]
    _print_table(rows, ["module", "model", "cost_usd", "calls"])
    print()
    print("── top domains by total cost ──")
    drows = [
        (r["domain"], f"${r['total']:.4f}", r["calls"])
        for r in conn.execute(
            "SELECT domain, "
            "SUM(COALESCE(cost_usd,0) + COALESCE(amount_usd,0)) AS total, "
            "COUNT(*) AS calls FROM cost_tracking "
            "GROUP BY domain ORDER BY total DESC LIMIT ?",
            (args.limit,),
        ).fetchall()
    ]
    _print_table(drows, ["domain", "cost_usd", "calls"])


def cmd_hypothesis(conn: sqlite3.Connection, args) -> None:
    """Show a single hypothesis and all evidence linked to it."""
    h = conn.execute("SELECT * FROM hypotheses WHERE id = ?", (args.id,)).fetchone()
    if not h:
        print(f"no hypothesis found with id={args.id}")
        return
    print(f"id         : {h['id']}")
    print(f"domain     : {h['domain']}")
    print(f"title      : {h['title']}")
    print(f"confidence : {h['confidence']}")
    print(f"status     : {h['status']}")
    print(f"updated    : {h['last_updated']}")
    print()
    print("── supporting evidence ──")
    srows = [
        (r["id"], r["engine"], f"{r['confidence']:.2f}", _truncate(r["finding"], 80))
        for r in conn.execute(
            "SELECT id, engine, confidence, finding FROM evidence "
            "WHERE supports_hypothesis = ? ORDER BY confidence DESC LIMIT 20",
            (args.id,),
        ).fetchall()
    ]
    _print_table(srows, ["id", "engine", "conf", "finding"])
    print()
    print("── contradicting evidence ──")
    crows = [
        (r["id"], r["engine"], f"{r['confidence']:.2f}", _truncate(r["finding"], 80))
        for r in conn.execute(
            "SELECT id, engine, confidence, finding FROM evidence "
            "WHERE contradicts_hypothesis = ? ORDER BY confidence DESC LIMIT 20",
            (args.id,),
        ).fetchall()
    ]
    _print_table(crows, ["id", "engine", "conf", "finding"])


def cmd_domain_health(conn: sqlite3.Connection, args) -> None:
    """Per-domain summary: finding count, avg confidence, last run."""
    rows = [
        (
            r["domain"],
            r["total"],
            f"{r['avg_conf']:.2f}" if r["avg_conf"] is not None else "",
            r["engines"],
            _truncate(r["last_run"], 19),
        )
        for r in conn.execute(
            "SELECT domain, COUNT(*) AS total, "
            "AVG(confidence) AS avg_conf, "
            "COUNT(DISTINCT engine) AS engines, "
            "MAX(timestamp) AS last_run FROM evidence "
            "GROUP BY domain ORDER BY total DESC"
        ).fetchall()
    ]
    _print_table(rows, ["domain", "findings", "avg_conf", "engines", "last_run"])


# ─────────────────────────── entry point ───────────────────────────


def build_parser() -> argparse.ArgumentParser:
    """Build the argparse subcommand tree."""
    p = argparse.ArgumentParser(description="Read-only explorer for the Nebula evidence database.")
    p.add_argument(
        "--db",
        default=str(DEFAULT_DB),
        help=f"path to engine.db (default: {DEFAULT_DB})",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("recent", help="most recent findings")
    r.add_argument("--domain")
    r.add_argument("--limit", type=int, default=20)
    r.set_defaults(func=cmd_recent)

    b = sub.add_parser("breakthroughs", help="high-confidence findings and hypotheses")
    b.add_argument("--limit", type=int, default=15)
    b.set_defaults(func=cmd_breakthroughs)

    s = sub.add_parser("stale-engines", help="engines ordered by oldest last-run")
    s.set_defaults(func=cmd_stale_engines)

    d = sub.add_parser("duplicate-findings", help="findings that repeat")
    d.add_argument("--limit", type=int, default=20)
    d.set_defaults(func=cmd_duplicate_findings)

    lc = sub.add_parser("low-confidence", help="findings below a threshold")
    lc.add_argument("--threshold", type=float, default=0.3)
    lc.add_argument("--limit", type=int, default=20)
    lc.set_defaults(func=cmd_low_confidence)

    be = sub.add_parser("by-engine", help="findings from a specific engine")
    be.add_argument("--engine", required=True)
    be.add_argument("--limit", type=int, default=30)
    be.set_defaults(func=cmd_by_engine)

    cl = sub.add_parser("cost-leaders", help="top cost modules/models/domains")
    cl.add_argument("--limit", type=int, default=10)
    cl.set_defaults(func=cmd_cost_leaders)

    h = sub.add_parser("hypothesis", help="show a single hypothesis + its evidence")
    h.add_argument("id")
    h.set_defaults(func=cmd_hypothesis)

    dh = sub.add_parser("domain-health", help="per-domain activity summary")
    dh.set_defaults(func=cmd_domain_health)

    return p


def main(argv: list[str] | None = None) -> int:
    """CLI entry point."""
    parser = build_parser()
    args = parser.parse_args(argv)
    conn = _connect(args.db)
    try:
        args.func(conn, args)
    finally:
        conn.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
