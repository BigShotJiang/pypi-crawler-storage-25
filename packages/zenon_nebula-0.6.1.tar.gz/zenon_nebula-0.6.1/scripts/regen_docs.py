#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Regenerate documentation from authoritative sources.

Single script that pulls numbers and structure directly from the codebase so
that no one has to hand-edit stat blocks in README.md, CLAUDE.md, or the docs
tree. Run this before every commit to source files; a pre-commit hook also
invokes it in --check mode.

What it regenerates:
- Stat blocks in README.md, CLAUDE.md, docs/ARCHITECTURE.md (between
  <!-- nebula:stats:start --> and <!-- nebula:stats:end --> markers)
- docs/DOMAINS.md — full domain + engine catalog, pulled from DomainRegistry
- docs/reference/cli.md — CLI reference, parsed from scripts/autonomous.py
  argparse

Usage:
    python3 scripts/regen_docs.py            # rewrite files in place
    python3 scripts/regen_docs.py --check    # exit 1 if any file would change
    python3 scripts/regen_docs.py --stats    # print computed stats and exit

Exit codes:
    0 — success (files up to date in --check, or rewritten successfully)
    1 — files were stale (--check only)
    2 — error collecting stats or importing registry
"""

from __future__ import annotations

import argparse
import ast
import difflib
import re
import sys
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATS_START = "<!-- nebula:stats:start -->"
STATS_END = "<!-- nebula:stats:end -->"

EXCLUDED_DIRS = {
    ".venv",
    "venv",
    "__pycache__",
    ".git",
    "build",
    "dist",
    ".mypy_cache",
    ".ruff_cache",
    ".pytest_cache",
}


@dataclass
class Stats:
    """Stats collected from the codebase."""

    py_files: int
    total_lines: int
    core_modules: int
    domain_count: int
    engine_count: int
    test_files: int
    scripts: int
    schema_tables: int
    mcp_tools: int


def _iter_py_files(base: Path):
    for p in base.rglob("*.py"):
        if any(part in EXCLUDED_DIRS for part in p.parts):
            continue
        yield p


def collect_stats() -> Stats:
    """Walk the repo and collect the numbers that appear in docs."""
    py_files = list(_iter_py_files(ROOT))
    total_lines = 0
    for p in py_files:
        # Read as text with universal newlines so the count is stable
        # across LF/CRLF filesystems. Iterating the binary file handle
        # produced different counts on macOS (LF) vs CI (git autocrlf).
        try:
            total_lines += len(p.read_text(encoding="utf-8", errors="ignore").splitlines())
        except OSError:
            continue

    core = [p for p in py_files if p.is_relative_to(ROOT / "core")]
    core_modules = [p for p in core if p.name != "__init__.py"]

    domains_dir = ROOT / "domains"
    domain_count = 0
    engine_count = 0
    if domains_dir.is_dir():
        for d in sorted(domains_dir.iterdir()):
            if not d.is_dir() or d.name.startswith("_") or d.name.startswith("."):
                continue
            domain_count += 1
            engines_dir = d / "engines"
            if engines_dir.is_dir():
                engine_count += sum(1 for f in engines_dir.glob("*.py") if f.name != "__init__.py")

    test_files = [
        p for p in py_files if p.is_relative_to(ROOT / "tests") and p.name.startswith("test_")
    ]
    scripts = [p for p in py_files if p.is_relative_to(ROOT / "scripts")]

    schema_tables = _count_schema_tables()
    mcp_tools = _count_mcp_tools()

    return Stats(
        py_files=len(py_files),
        total_lines=total_lines,
        core_modules=len(core_modules),
        domain_count=domain_count,
        engine_count=engine_count,
        test_files=len(test_files),
        scripts=len(scripts),
        schema_tables=schema_tables,
        mcp_tools=mcp_tools,
    )


def _count_schema_tables() -> int:
    """Count CREATE TABLE statements across every SCHEMA_SQL in the repo."""
    total = 0
    pattern = re.compile(r"CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS", re.IGNORECASE)
    for p in _iter_py_files(ROOT):
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if "SCHEMA_SQL" not in text and "CREATE TABLE" not in text:
            continue
        total += len(pattern.findall(text))
    return total


def _count_mcp_tools() -> int:
    """Parse scripts/mcp_server.py and count entries in the TOOLS list."""
    mcp = ROOT / "scripts" / "mcp_server.py"
    if not mcp.exists():
        return 0
    try:
        tree = ast.parse(mcp.read_text(encoding="utf-8"))
    except SyntaxError:
        return 0
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "TOOLS":
                    if isinstance(node.value, ast.List):
                        return len(node.value.elts)
    return 0


def render_stats_block(stats: Stats) -> str:
    """Render the shared stat block that goes into README, CLAUDE.md, etc."""
    return (
        f"{STATS_START}\n"
        f"<!-- Regenerated by scripts/regen_docs.py. Do not edit by hand. -->\n"
        f"\n"
        f"| Metric | Count |\n"
        f"|--------|-------|\n"
        f"| Python files | {stats.py_files} |\n"
        f"| Lines of code | {stats.total_lines:,} |\n"
        f"| Core modules | {stats.core_modules} |\n"
        f"| Domains | {stats.domain_count} |\n"
        f"| Engines | {stats.engine_count} |\n"
        f"| Test files | {stats.test_files} |\n"
        f"| Scripts | {stats.scripts} |\n"
        f"| Schema tables | {stats.schema_tables} |\n"
        f"| MCP tools | {stats.mcp_tools} |\n"
        f"\n"
        f"{STATS_END}"
    )


def collect_domain_catalog() -> list[dict]:
    """Read every domains/*/domain.py and pull name, description, engines.

    Falls back to filesystem scanning if the plugin refuses to import
    (e.g., dependency not installed in the current env). Never raises.
    """
    catalog = []
    domains_dir = ROOT / "domains"
    if not domains_dir.is_dir():
        return catalog

    for d in sorted(domains_dir.iterdir()):
        if not d.is_dir() or d.name.startswith("_") or d.name.startswith("."):
            continue

        entry = {
            "name": d.name,
            "description": _extract_description(d / "domain.py"),
            "priority": _extract_priority(d / "domain.py"),
            "engines": [],
        }

        engines_dir = d / "engines"
        if engines_dir.is_dir():
            for f in sorted(engines_dir.glob("*.py")):
                if f.name == "__init__.py":
                    continue
                entry["engines"].append(
                    {
                        "file": f.name,
                        "name": f.stem,
                        "purpose": _extract_module_docstring_summary(f),
                    }
                )
        catalog.append(entry)
    return catalog


def _extract_description(domain_py: Path) -> str:
    """Pull the return value of get_description() from a DomainPlugin."""
    if not domain_py.exists():
        return ""
    try:
        tree = ast.parse(domain_py.read_text(encoding="utf-8"))
    except SyntaxError:
        return ""
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "get_description":
            for stmt in node.body:
                if isinstance(stmt, ast.Return) and isinstance(stmt.value, ast.Constant):
                    if isinstance(stmt.value.value, str):
                        return stmt.value.value
    return ""


def _extract_priority(domain_py: Path) -> int:
    if not domain_py.exists():
        return 5
    try:
        tree = ast.parse(domain_py.read_text(encoding="utf-8"))
    except SyntaxError:
        return 5
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "get_priority":
            for stmt in node.body:
                if isinstance(stmt, ast.Return) and isinstance(stmt.value, ast.Constant):
                    if isinstance(stmt.value.value, int):
                        return stmt.value.value
    return 5


def _extract_module_docstring_summary(py_file: Path) -> str:
    """Return the first sentence of a module's docstring, or empty string."""
    try:
        tree = ast.parse(py_file.read_text(encoding="utf-8"))
    except (OSError, SyntaxError):
        return ""
    doc = ast.get_docstring(tree)
    if not doc:
        return ""
    first = doc.strip().split("\n")[0].strip()
    return first.rstrip(".")


def render_domains_md(catalog: list[dict]) -> str:
    """Render the full docs/DOMAINS.md from the domain catalog."""
    lines = [
        "# Domains & Engines",
        "",
        "<!-- Regenerated by scripts/regen_docs.py. Do not edit by hand. -->",
        "",
        f"Nebula ships {len(catalog)} domains. Each domain is a plugin under",
        "`domains/<name>/` with a `DomainPlugin` subclass in `domain.py` and one",
        "engine per file under `engines/`. The loader auto-registers every domain",
        "at boot — see `core/domain_registry.py`.",
        "",
        "## Domains",
        "",
        "| Domain | Priority | Engines | Description |",
        "|--------|----------|---------|-------------|",
    ]
    for d in catalog:
        lines.append(
            f"| `{d['name']}` | {d['priority']} | {len(d['engines'])} | {d['description']} |"
        )
    lines.append("")

    for d in catalog:
        lines.append(f"## `{d['name']}`")
        lines.append("")
        if d["description"]:
            lines.append(d["description"])
            lines.append("")
        if not d["engines"]:
            lines.append("_No engines registered._")
            lines.append("")
            continue
        lines.append("| Engine | Purpose |")
        lines.append("|--------|---------|")
        for eng in d["engines"]:
            purpose = eng["purpose"] or "_(no module docstring)_"
            lines.append(f"| `{eng['name']}` | {purpose} |")
        lines.append("")
    return "\n".join(lines) + "\n"


def render_cli_reference() -> str:
    """Parse scripts/autonomous.py argparse and build a CLI reference.

    Extremely conservative: we don't actually import autonomous.py (it has
    side effects). Instead, we parse the AST and look for argparse .add_argument
    calls. Unparseable commands degrade to a stub line.
    """
    autonomous = ROOT / "scripts" / "autonomous.py"
    nebula_sh = ROOT / "nebula"

    lines = [
        "# CLI Reference",
        "",
        "<!-- Regenerated by scripts/regen_docs.py. Do not edit by hand. -->",
        "",
        "The `./nebula` wrapper forwards to `scripts/autonomous.py`. All flags",
        "below are derived from its argparse definition via AST walk — if you",
        "add a new flag, run `python3 scripts/regen_docs.py` to refresh.",
        "",
    ]

    if not autonomous.exists():
        lines.append("_`scripts/autonomous.py` not found — CLI reference unavailable._\n")
        return "\n".join(lines)

    try:
        tree = ast.parse(autonomous.read_text(encoding="utf-8"))
    except SyntaxError as exc:
        lines.append(f"_Parse error in `scripts/autonomous.py`: {exc}_\n")
        return "\n".join(lines)

    add_arg_calls = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr != "add_argument":
            continue
        names = [
            a.value for a in node.args if isinstance(a, ast.Constant) and isinstance(a.value, str)
        ]
        kwargs = {}
        for kw in node.keywords:
            if kw.arg and isinstance(kw.value, ast.Constant):
                kwargs[kw.arg] = kw.value.value
        if names:
            add_arg_calls.append((names, kwargs))

    lines.append("## Flags")
    lines.append("")
    lines.append("| Flag | Type | Default | Help |")
    lines.append("|------|------|---------|------|")
    for names, kwargs in add_arg_calls:
        flag = ", ".join(f"`{n}`" for n in names)
        typ = kwargs.get("type", "str")
        if hasattr(typ, "__name__"):
            typ = typ.__name__
        default = kwargs.get("default", "")
        if default is None:
            default = ""
        help_text = kwargs.get("help", "")
        lines.append(f"| {flag} | {typ} | `{default}` | {help_text} |")
    lines.append("")

    if nebula_sh.exists():
        lines.append("## Subcommands (via `./nebula <cmd>`)")
        lines.append("")
        lines.append("The `./nebula` wrapper recognises the following subcommands")
        lines.append("before delegating remaining arguments to `scripts/autonomous.py`.")
        lines.append("Run `./nebula --help` for the authoritative list at any commit.")
        lines.append("")

    return "\n".join(lines) + "\n"


def rewrite_version_badge(path: Path, version: str) -> tuple[bool, str]:
    """Update the shields.io version badge in README.md to match core/version.py.

    Pre-v0.2.18 the badge was a hand-edited literal `v0.2.0` that nobody
    bumped on release. Now it's regenerated from `core/version.py` on
    every `regen_docs.py` run, and the release workflow runs
    `regen_docs.py --check` so a stale badge fails CI before tagging.

    Matches both the old `version-v0.2.0-informational` shape and any
    valid semver patch number after `version-v`. The replacement
    preserves the badge color and the alt text.
    """
    if not path.exists():
        return (False, "")
    original = path.read_text(encoding="utf-8")
    pattern = re.compile(
        r'(<img\s+src="https://img\.shields\.io/badge/version-v)'
        r"\d+\.\d+\.\d+"
        r'(-[a-z]+"\s+alt="Version v)'
        r"\d+\.\d+\.\d+"
        r'(">)'
    )
    new_contents, n = pattern.subn(rf"\g<1>{version}\g<2>{version}\g<3>", original)
    return (n > 0 and new_contents != original, new_contents)


def rewrite_stats_block(path: Path, new_block: str) -> tuple[bool, str]:
    """Return (changed, new_contents) for a file that has stat markers.

    If the file has no markers, inject the block after the first H1 heading
    (only when the file is README.md or CLAUDE.md — other files must carry
    markers explicitly).
    """
    if not path.exists():
        return (False, "")
    original = path.read_text(encoding="utf-8")
    if STATS_START in original and STATS_END in original:
        pattern = re.compile(
            re.escape(STATS_START) + r".*?" + re.escape(STATS_END),
            re.DOTALL,
        )
        new_contents = pattern.sub(new_block, original)
    elif path.name in {"README.md", "CLAUDE.md"}:
        h1 = re.search(r"^# .+$", original, re.MULTILINE)
        if not h1:
            return (False, original)
        insert_at = h1.end()
        new_contents = original[:insert_at] + "\n\n" + new_block + original[insert_at:]
    else:
        return (False, original)
    return (new_contents != original, new_contents)


def diff_preview(old: str, new: str, path: Path) -> str:
    diff = difflib.unified_diff(
        old.splitlines(keepends=True),
        new.splitlines(keepends=True),
        fromfile=str(path) + " (current)",
        tofile=str(path) + " (regenerated)",
        n=2,
    )
    return "".join(diff)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="Exit 1 if any file would change.")
    ap.add_argument("--stats", action="store_true", help="Print computed stats and exit.")
    ap.add_argument("--verbose", "-v", action="store_true")
    args = ap.parse_args()

    try:
        stats = collect_stats()
    except Exception as exc:
        print(f"error collecting stats: {exc}", file=sys.stderr)
        return 2

    if args.stats:
        print(f"py_files       {stats.py_files}")
        print(f"total_lines    {stats.total_lines}")
        print(f"core_modules   {stats.core_modules}")
        print(f"domains        {stats.domain_count}")
        print(f"engines        {stats.engine_count}")
        print(f"test_files     {stats.test_files}")
        print(f"scripts        {stats.scripts}")
        print(f"schema_tables  {stats.schema_tables}")
        print(f"mcp_tools      {stats.mcp_tools}")
        return 0

    stats_block = render_stats_block(stats)
    domain_catalog = collect_domain_catalog()
    domains_md = render_domains_md(domain_catalog)
    cli_md = render_cli_reference()

    targets: list[tuple[Path, str]] = []

    # Resolve the current version from core/version.py so the README
    # badge stays in lockstep with the actual shipped version.
    current_version: str | None = None
    try:
        sys.path.insert(0, str(ROOT))
        from core.version import __version__ as current_version
    except Exception as exc:
        print(f"warn: could not import core.version: {exc}", file=sys.stderr)

    for md in [ROOT / "README.md", ROOT / "CLAUDE.md", ROOT / "docs" / "ARCHITECTURE.md"]:
        if not md.exists():
            continue
        # Stat block first; the version badge fixup operates on the
        # already-updated text so two changes in the same file get
        # collapsed into a single write.
        changed, new_contents = rewrite_stats_block(md, stats_block)
        # Now apply the version badge rewrite to the (possibly already
        # updated) contents.
        if current_version and md.name == "README.md":
            badge_changed, badge_contents = rewrite_version_badge(md, current_version)
            if badge_changed:
                # Re-apply the badge fix to whatever stats_block left.
                if changed:
                    # rewrite_stats_block produced new_contents — apply
                    # the badge regex to that, not to the original file.
                    pattern = re.compile(
                        r'(<img\s+src="https://img\.shields\.io/badge/version-v)'
                        r"\d+\.\d+\.\d+"
                        r'(-[a-z]+"\s+alt="Version v)'
                        r"\d+\.\d+\.\d+"
                        r'(">)'
                    )
                    new_contents = pattern.sub(
                        rf"\g<1>{current_version}\g<2>{current_version}\g<3>",
                        new_contents,
                    )
                else:
                    new_contents = badge_contents
                changed = True
        if changed:
            targets.append((md, new_contents))

    domains_md_path = ROOT / "docs" / "DOMAINS.md"
    if not domains_md_path.exists() or domains_md_path.read_text(encoding="utf-8") != domains_md:
        targets.append((domains_md_path, domains_md))

    # docs/reference/cli.md is hand-maintained. Only auto-generate it when
    # it's missing or when it still carries our machine-generated banner.
    cli_ref_path = ROOT / "docs" / "reference" / "cli.md"
    if not cli_ref_path.exists():
        targets.append((cli_ref_path, cli_md))
    else:
        existing = cli_ref_path.read_text(encoding="utf-8")
        # Marker in the auto-generated version. If the human rewrote it
        # without this marker, we leave it alone.
        marker = "<!-- Regenerated by scripts/regen_docs.py. Do not edit by hand. -->"
        if marker in existing and existing != cli_md:
            targets.append((cli_ref_path, cli_md))

    if args.check:
        if not targets:
            if args.verbose:
                print("docs are up to date")
            return 0
        print(
            "docs are stale — run `python3 scripts/regen_docs.py` to regenerate:", file=sys.stderr
        )
        for path, new_contents in targets:
            old = path.read_text(encoding="utf-8") if path.exists() else ""
            print(diff_preview(old, new_contents, path.relative_to(ROOT)), file=sys.stderr)
        return 1

    for path, new_contents in targets:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(new_contents, encoding="utf-8")
        print(f"regenerated {path.relative_to(ROOT)}")

    if not targets:
        print("docs were already up to date")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
