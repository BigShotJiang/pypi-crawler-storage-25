# SPDX-License-Identifier: MIT
"""Nebula MCP Server — Exposes Nebula intelligence to any LLM via MCP protocol.

Works with Claude Code, Cursor, OpenCode, or any MCP-compatible agent.

Usage:
    # Register with Claude Code:
    claude mcp add nebula python3 /path/to/nebula/scripts/mcp_server.py

    # Or in .mcp.json:
    {
        "mcpServers": {
            "nebula": {
                "type": "stdio",
                "command": "python3",
                "args": ["/path/to/nebula/scripts/mcp_server.py"]
            }
        }
    }

Tools exposed:
    - nebula_status: Get current state across all domains
    - nebula_spec_coverage: Get spec implementation coverage matrix
    - nebula_security_findings: Get open security findings
    - nebula_battle_plan: Get latest War Room battle plan
    - nebula_upstream_signals: Get unprocessed upstream signals
    - nebula_aspirations: Get active aspirations across domains
    - nebula_collisions: Get unresolved cross-domain collisions
    - nebula_query: Run arbitrary SQL on evidence store (read-only)
"""

import json
import sqlite3
import sys
from pathlib import Path

# Resolve paths relative to this script
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
DB_PATH = PROJECT_ROOT / "data" / "engine.db"

TOOLS = [
    {
        "name": "nebula_status",
        "description": "Get Nebula's current state: domain health, engine status, budget, test results. Run this at session start.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "nebula_spec_coverage",
        "description": "Get spec implementation coverage matrix — which specs are implemented in which repos (go-zenon, SDK, CLI, wallet, docs).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "spec_name": {
                    "type": "string",
                    "description": "Optional: filter by spec name (e.g., 'PTLC'). Omit for all specs.",
                },
            },
        },
    },
    {
        "name": "nebula_security_findings",
        "description": "Get open security findings that need attention before pushing code.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "severity": {
                    "type": "string",
                    "description": "Filter by severity: critical, high, medium, low. Omit for all.",
                },
            },
        },
    },
    {
        "name": "nebula_battle_plan",
        "description": "Get the latest War Room battle plan — what to work on today.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "nebula_upstream_signals",
        "description": "Get unprocessed upstream signals — new commits, specs, or issues detected.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Max signals to return. Default 10.",
                },
            },
        },
    },
    {
        "name": "nebula_aspirations",
        "description": "Get active aspirations (goals) across all domains.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "domain": {
                    "type": "string",
                    "description": "Filter by domain name. Omit for all domains.",
                },
            },
        },
    },
    {
        "name": "nebula_collisions",
        "description": "Get unresolved cross-domain collisions — convergent findings that need action.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "nebula_query",
        "description": "Run a read-only SQL query on Nebula's evidence store. Use for custom queries not covered by other tools.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "sql": {
                    "type": "string",
                    "description": "SQL SELECT query to execute.",
                },
            },
            "required": ["sql"],
        },
    },
]


def get_db():
    """Get read-only DB connection."""
    if not DB_PATH.exists():
        return None
    conn = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def _sanitize_result(result):
    """Deep-sanitize any DB-derived result before returning to the MCP client.

    An MCP client is an external agent (Claude Code, Cursor, etc.) that
    the operator consented to connect, but consent isn't a license to
    leak local paths or secrets. Same sanitization policy as the RPC
    path: `sanitize_for_sharing` on every text-bearing field.
    """
    try:
        import os
        import sys

        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        from core.opsec import OPSECGuard
    except Exception:
        return result

    participant = os.environ.get("NEBULA_PARTICIPANT_ID", "anonymous")
    text_fields = {
        "finding",
        "title",
        "description",
        "source_file",
        "raw_data",
        "situation_assessment",
        "battle_plan_24h",
        "resource_allocation",
        "raw_plan",
        "reasoning",
        "last_reasoning",
        "details",
        "message",
    }

    def _clean(value):
        if isinstance(value, str):
            return OPSECGuard.sanitize_for_sharing(value, participant_id=participant)
        if isinstance(value, list):
            return [_clean(v) for v in value]
        if isinstance(value, dict):
            return {
                k: (
                    OPSECGuard.sanitize_for_sharing(v, participant_id=participant)
                    if isinstance(v, str) and k in text_fields
                    else _clean(v)
                )
                for k, v in value.items()
            }
        return value

    return _clean(result)


def handle_tool_call(name: str, args: dict) -> str:
    """Execute a tool and return JSON result."""
    conn = get_db()
    if conn is None:
        return json.dumps({"error": "Nebula database not found. Run scripts/setup.sh first."})

    try:
        if name == "nebula_status":
            # Aggregate status across domains
            domains = conn.execute(
                "SELECT DISTINCT domain FROM actions_log ORDER BY domain"
            ).fetchall()
            evidence_count = conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
            hypothesis_count = conn.execute("SELECT COUNT(*) FROM hypotheses").fetchone()[0]
            # Finding lifecycle stats
            try:
                status_counts = {
                    r[0]: r[1]
                    for r in conn.execute(
                        "SELECT COALESCE(status, 'open'), COUNT(*) FROM evidence GROUP BY COALESCE(status, 'open')"
                    ).fetchall()
                }
            except Exception:
                status_counts = {}
            return json.dumps(
                {
                    "domains_active": [r["domain"] for r in domains],
                    "total_evidence": evidence_count,
                    "total_hypotheses": hypothesis_count,
                    "findings_open": status_counts.get("open", 0),
                    "findings_resolved": status_counts.get("resolved", 0),
                    "findings_verified": status_counts.get("verified", 0),
                    "db_path": str(DB_PATH),
                }
            )

        elif name == "nebula_spec_coverage":
            spec = args.get("spec_name")
            if spec:
                rows = conn.execute(
                    "SELECT * FROM spec_coverage WHERE spec_name LIKE ?",
                    (f"%{spec}%",),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM spec_coverage ORDER BY overall_coverage ASC"
                ).fetchall()
            return json.dumps(_sanitize_result([dict(r) for r in rows]))

        elif name == "nebula_security_findings":
            severity = args.get("severity")
            if severity:
                rows = conn.execute(
                    "SELECT * FROM security_reviews WHERE mitigated=0 AND severity=? ORDER BY timestamp DESC",
                    (severity,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM security_reviews WHERE mitigated=0 ORDER BY severity, timestamp DESC"
                ).fetchall()
            return json.dumps(_sanitize_result([dict(r) for r in rows]))

        elif name == "nebula_battle_plan":
            row = conn.execute(
                "SELECT raw_plan, situation_assessment, battle_plan_24h, resource_allocation, timestamp FROM battle_plans ORDER BY timestamp DESC LIMIT 1"
            ).fetchone()
            if row:
                return json.dumps(
                    _sanitize_result(
                        {
                            "situation": row["situation_assessment"],
                            "battle_plan": row["battle_plan_24h"],
                            "resources": row["resource_allocation"],
                            "raw": row["raw_plan"],
                            "timestamp": row["timestamp"],
                        }
                    )
                )
            return json.dumps({"note": "No battle plan yet. Run autonomous.py --once"})

        elif name == "nebula_upstream_signals":
            limit = args.get("limit", 10)
            rows = conn.execute(
                "SELECT * FROM intelligence_signals WHERE processed=0 ORDER BY timestamp DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return json.dumps(_sanitize_result([dict(r) for r in rows]))

        elif name == "nebula_aspirations":
            domain = args.get("domain")
            if domain:
                rows = conn.execute(
                    "SELECT * FROM aspirations WHERE status='ACTIVE' AND domain=? ORDER BY priority DESC",
                    (domain,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM aspirations WHERE status='ACTIVE' ORDER BY priority DESC"
                ).fetchall()
            return json.dumps(_sanitize_result([dict(r) for r in rows]))

        elif name == "nebula_collisions":
            rows = conn.execute(
                "SELECT * FROM collisions WHERE resolved=0 ORDER BY timestamp DESC"
            ).fetchall()
            return json.dumps(_sanitize_result([dict(r) for r in rows]))

        elif name == "nebula_query":
            sql = args.get("sql", "")
            if not sql.strip().upper().startswith("SELECT"):
                return json.dumps({"error": "Only SELECT queries allowed (read-only)"})
            rows = conn.execute(sql).fetchall()
            return json.dumps(_sanitize_result([dict(r) for r in rows]))

        else:
            return json.dumps({"error": f"Unknown tool: {name}"})

    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        conn.close()


def main():
    """MCP stdio server loop."""
    import readline  # noqa: F401 — enables line editing

    for line in sys.stdin:
        try:
            msg = json.loads(line.strip())

            if msg.get("method") == "initialize":
                response = {
                    "jsonrpc": "2.0",
                    "id": msg.get("id"),
                    "result": {
                        "protocolVersion": "2024-11-05",
                        "serverInfo": {
                            "name": "zenon-nebula",
                            "version": "1.0.0",
                        },
                        "capabilities": {"tools": {}},
                    },
                }
                print(json.dumps(response), flush=True)

            elif msg.get("method") == "tools/list":
                response = {
                    "jsonrpc": "2.0",
                    "id": msg.get("id"),
                    "result": {"tools": TOOLS},
                }
                print(json.dumps(response), flush=True)

            elif msg.get("method") == "tools/call":
                params = msg.get("params", {})
                tool_name = params.get("name", "")
                tool_args = params.get("arguments", {})
                result = handle_tool_call(tool_name, tool_args)
                response = {
                    "jsonrpc": "2.0",
                    "id": msg.get("id"),
                    "result": {
                        "content": [{"type": "text", "text": result}],
                    },
                }
                print(json.dumps(response), flush=True)

            elif msg.get("method") == "notifications/initialized":
                pass  # Client acknowledgment, no response needed

            else:
                response = {
                    "jsonrpc": "2.0",
                    "id": msg.get("id"),
                    "error": {
                        "code": -32601,
                        "message": f"Method not found: {msg.get('method')}",
                    },
                }
                print(json.dumps(response), flush=True)

        except json.JSONDecodeError:
            continue
        except Exception as e:
            error_response = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32603, "message": str(e)},
            }
            print(json.dumps(error_response), flush=True)


if __name__ == "__main__":
    main()
