#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
Nebula safe updater.

Workflow:
  1. Backup current state (DB, config, git HEAD) to ``data/backups/backup_<ts>/``
  2. git fetch + fast-forward merge from origin/main
  3. Check PROTOCOL_VERSION compatibility (warn on major bump)
  4. pip install new dependencies
  5. Run ensure_schema() to apply migrations
  6. Run smoke tests (a small, fast, high-signal subset)
  7. If all pass: done. If any fail: rollback git + DB, report failure.

Usage:
    python3 scripts/update.py              # interactive
    python3 scripts/update.py --force      # skip confirmation
    python3 scripts/update.py --check      # check if updates available (no changes)
    python3 scripts/update.py --dry-run    # show what would happen, don't apply
    python3 scripts/update.py --rollback   # revert to most recent backup
    python3 scripts/update.py --list       # list available backups

Exit codes:
    0   update succeeded (or rollback succeeded, or up-to-date on --check)
    1   update aborted or failed (state restored to pre-update backup)
    2   invalid arguments / environment
    3   updates available (only on --check, for scripting)
"""

from __future__ import annotations

import argparse
import contextlib
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
BACKUP_DIR = DATA / "backups"

# Keep backup pruning conservative -- updates are infrequent and a DB file
# is small relative to the repo itself.
MAX_BACKUPS = 10

# Smoke tests: small, fast, high signal. If any fails we rollback.
# Missing files are filtered out at runtime so a rename doesn't silently
# skip every test.
SMOKE_TEST_CANDIDATES = [
    "tests/test_persist_to_db.py",
    "tests/test_persistence_schema.py",
    "tests/test_end_to_end.py",
    "tests/test_new_core.py",
]


def _resolve_smoke_tests() -> list[str]:
    """Return the smoke tests that actually exist on disk right now."""
    present = [t for t in SMOKE_TEST_CANDIDATES if (ROOT / t).exists()]
    if not present:
        print("  warn: no smoke tests found on disk — update will proceed with no safety net")
    return present


def _current_branch() -> str:
    """Return the current git branch (falls back to 'main' on detached HEAD)."""
    r = subprocess.run(
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    branch = (r.stdout or "").strip()
    if not branch or branch == "HEAD":
        return "main"
    return branch


def _has_network() -> bool:
    """Return True if DNS resolves github.com — cheap offline check."""
    try:
        import socket

        socket.gethostbyname("github.com")
        return True
    except (OSError, Exception):
        return False


def _has_git() -> bool:
    """Return True if git is on PATH."""
    from shutil import which

    return which("git") is not None


# ---------------------------------------------------------------------------
# Backup / rollback
# ---------------------------------------------------------------------------


def backup_current_state() -> Path:
    """Snapshot DB, config, and version info under ``data/backups/``.

    Returns the backup directory path. Safe to call even if no DB exists yet.
    """
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup = BACKUP_DIR / f"backup_{timestamp}"
    backup.mkdir(parents=True, exist_ok=True)

    # Copy DB (may not exist on a fresh install)
    db = DATA / "engine.db"
    if db.exists():
        try:
            shutil.copy2(db, backup / "engine.db")
        except OSError as exc:
            print(f"  warn: could not copy engine.db: {exc}")

    # Copy .env (may contain user tweaks worth preserving across rollback).
    env = ROOT / ".env"
    if env.exists():
        with contextlib.suppress(OSError):
            shutil.copy2(env, backup / ".env")

    # Record current git commit so rollback knows where to reset.
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            cwd=ROOT,
            check=False,
        )
        (backup / "git_commit").write_text(result.stdout.strip())
    except (OSError, subprocess.SubprocessError) as exc:
        print(f"  warn: could not record git commit: {exc}")

    # Record current version for provenance.
    try:
        sys.path.insert(0, str(ROOT))
        from core.version import get_version

        (backup / "version").write_text(get_version())
    except Exception as exc:
        print(f"  warn: could not record version: {exc}")

    _prune_old_backups()
    return backup


def _prune_old_backups() -> None:
    """Keep only the most recent ``MAX_BACKUPS`` backups on disk."""
    if not BACKUP_DIR.exists():
        return
    backups = sorted(BACKUP_DIR.glob("backup_*"), reverse=True)
    for old in backups[MAX_BACKUPS:]:
        with contextlib.suppress(OSError):
            shutil.rmtree(old)


def rollback(backup: Path) -> None:
    """Revert git + DB to the supplied backup state."""
    print(f"Rolling back to {backup.name}...")

    commit_file = backup / "git_commit"
    if commit_file.exists():
        commit = commit_file.read_text().strip()
        if commit:
            r = subprocess.run(
                ["git", "reset", "--hard", commit],
                cwd=ROOT,
                capture_output=True,
                text=True,
                check=False,
            )
            if r.returncode != 0:
                print(f"  git reset failed: {r.stderr.strip()}")

    backup_db = backup / "engine.db"
    live_db = DATA / "engine.db"
    if backup_db.exists():
        try:
            shutil.copy2(backup_db, live_db)
        except OSError as exc:
            print(f"  warn: could not restore engine.db: {exc}")

    print("Rollback complete.")


# ---------------------------------------------------------------------------
# Update steps
# ---------------------------------------------------------------------------


def fetch_latest(branch: str | None = None) -> bool:
    """``git fetch`` + fast-forward merge from ``origin/<branch>``.

    Uses the current checkout branch by default. Never force-pushes; if a
    fast-forward isn't possible the update is aborted so the user can
    resolve manually.
    """
    branch = branch or _current_branch()
    print(f"Fetching origin/{branch}...")
    r = subprocess.run(
        ["git", "fetch", "origin", branch],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode != 0:
        print(f"  fetch failed: {r.stderr.strip()}")
        return False

    r = subprocess.run(
        ["git", "merge", f"origin/{branch}", "--ff-only"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode != 0:
        print(f"  merge failed (non-fast-forward?): {r.stderr.strip()}")
        return False
    if r.stdout.strip():
        print(f"  {r.stdout.strip()}")
    return True


def check_for_updates() -> tuple[bool, str]:
    """Return (updates_available, human_summary).

    Never modifies the working tree. Fetches refs, then compares HEAD with
    origin/<current_branch>.
    """
    if not _has_git():
        return False, "git not available on PATH"
    if not _has_network():
        return False, "no network connectivity (cannot reach github.com)"

    branch = _current_branch()
    r = subprocess.run(
        ["git", "fetch", "--quiet", "origin", branch],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode != 0:
        return False, f"git fetch failed: {r.stderr.strip()}"

    local = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    ).stdout.strip()
    remote = subprocess.run(
        ["git", "rev-parse", f"origin/{branch}"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    ).stdout.strip()

    if not local or not remote:
        return False, "could not resolve HEAD or origin ref"
    if local == remote:
        return False, f"up to date on {branch} ({local[:8]})"

    # Count how many commits behind
    r = subprocess.run(
        ["git", "rev-list", "--count", f"{local}..{remote}"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    behind = r.stdout.strip() or "?"
    return True, f"{behind} commits behind origin/{branch} ({local[:8]} -> {remote[:8]})"


def check_protocol_compatibility(pre_version: str) -> None:
    """Warn loudly if a major version bump will break cross-instance sharing."""
    try:
        sys.path.insert(0, str(ROOT))
        # Force reload so we see the post-pull module.
        import importlib

        from core import version as _vmod

        importlib.reload(_vmod)
        new_version = _vmod.get_version()
        new_proto = _vmod.PROTOCOL_VERSION
    except Exception as exc:
        print(f"  warn: could not read new version: {exc}")
        return

    print(f"  version: {pre_version} -> {new_version}")
    print(f"  protocol: v{new_proto}")

    try:
        old_major = int(pre_version.split(".")[0])
        new_major = int(new_version.split(".")[0])
        if new_major > old_major:
            print(
                "  WARNING: major version bump. Instances running older "
                "versions will not be able to share findings with this one "
                "until they also update."
            )
    except (ValueError, IndexError):
        pass


def install_dependencies() -> bool:
    """Install pinned dependencies from requirements.txt."""
    print("Installing dependencies...")
    req = ROOT / "requirements.txt"
    if not req.exists():
        print(f"  warn: {req} not found, skipping")
        return True
    r = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r", str(req)],
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode != 0:
        print(f"  pip install failed:\n{r.stderr[-2000:]}")
        return False
    return True


def apply_migrations() -> bool:
    """Run ``ensure_schema()`` so new tables/columns appear in the live DB.

    Tries ``core.persistence.schema`` first (the canonical path after the
    persistence package split), falling back to the legacy
    ``core.persist_to_db`` shim for pre-refactor clones.
    """
    print("Applying schema migrations...")
    script = (
        "import sys; sys.path.insert(0, '.')\n"
        "try:\n"
        "    from core.persistence.schema import ensure_schema\n"
        "except ImportError:\n"
        "    from core.persist_to_db import ensure_schema\n"
        "ensure_schema()\n"
    )
    r = subprocess.run(
        [sys.executable, "-c", script],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode != 0:
        print(f"  migration failed:\n{r.stderr[-2000:]}")
        return False
    return True


def run_smoke_tests() -> bool:
    """Run a fast, high-signal subset of the test suite.

    If any of the smoke tests fail we rollback, so they need to be reliable
    and fast -- not an exhaustive regression run. Missing candidate files
    are filtered out via ``_resolve_smoke_tests`` so a rename never silently
    produces an empty run.
    """
    tests = _resolve_smoke_tests()
    if not tests:
        print("  no smoke tests resolved — skipping (flagged above).")
        return True
    print(f"Running smoke tests ({len(tests)} file(s))...")
    cmd = [sys.executable, "-m", "pytest", *tests, "-q", "-x"]
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, check=False)
    if r.returncode != 0:
        print("  smoke tests FAILED:")
        tail = (r.stdout + r.stderr)[-2000:]
        for line in tail.splitlines():
            print(f"    {line}")
        return False
    print("  smoke tests passed.")
    return True


# ---------------------------------------------------------------------------
# Main entry points
# ---------------------------------------------------------------------------


def _current_version() -> str:
    try:
        sys.path.insert(0, str(ROOT))
        from core.version import get_version

        return get_version()
    except Exception:
        return "unknown"


def update(force: bool = False, dry_run: bool = False) -> int:
    """Run the full update pipeline.

    - ``dry_run=True`` runs preflight + network check + update availability
      check and reports what WOULD happen, without touching anything.
    - ``force=True`` skips the interactive confirmation prompt.
    """
    if not _has_git():
        print("git is not on PATH. Install git first.")
        return 2
    if not _has_network():
        print("No network connectivity (cannot reach github.com). Check your connection.")
        return 1

    branch = _current_branch()
    has_update, summary = check_for_updates()
    print(f"Current branch: {branch}")
    print(f"Update check:   {summary}")

    if dry_run:
        if not has_update:
            print("\nDry run: no update would be applied.")
            return 0
        print("\nDry run: would back up, fetch, install deps, migrate, and smoke test.")
        print("No changes were made.")
        return 0

    if not has_update:
        print("Nothing to do.")
        return 0

    if not force:
        print("\nThis will update Nebula to the latest version on this branch.")
        print("A backup will be created before updating. Rollback on failure.")
        try:
            answer = input("Continue? [y/N] ").strip().lower()
        except EOFError:
            answer = ""
        if answer != "y":
            print("Aborted.")
            return 1

    pre_version = _current_version()

    backup = backup_current_state()
    print(f"Backup created: {backup.relative_to(ROOT)}")

    if not fetch_latest(branch=branch):
        print("Fetch failed -- no changes made.")
        return 1

    check_protocol_compatibility(pre_version)

    if not install_dependencies():
        rollback(backup)
        return 1

    if not apply_migrations():
        rollback(backup)
        return 1

    if not run_smoke_tests():
        rollback(backup)
        return 1

    print("\nUpdate complete.")
    print(f"Current version: {_current_version()}")
    return 0


def do_rollback() -> int:
    """Rollback to the most recent backup."""
    if not BACKUP_DIR.exists():
        print("No backups found.")
        return 1
    backups = sorted(BACKUP_DIR.glob("backup_*"), reverse=True)
    if not backups:
        print("No backups found.")
        return 1
    latest = backups[0]
    rollback(latest)
    return 0


def list_backups() -> int:
    """Print available backups and exit."""
    if not BACKUP_DIR.exists():
        print("No backups found.")
        return 0
    backups = sorted(BACKUP_DIR.glob("backup_*"), reverse=True)
    if not backups:
        print("No backups found.")
        return 0
    print(f"Backups in {BACKUP_DIR}:")
    for b in backups:
        version = (b / "version").read_text().strip() if (b / "version").exists() else "?"
        commit = (b / "git_commit").read_text().strip()[:8] if (b / "git_commit").exists() else "?"
        print(f"  {b.name}  version={version}  commit={commit}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="nebula-update",
        description="Safely update Nebula with automatic rollback on failure.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Skip the interactive confirmation prompt.",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Check whether updates are available and exit (no changes).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        dest="dry_run",
        help="Show what would happen without applying any changes.",
    )
    parser.add_argument(
        "--rollback",
        action="store_true",
        help="Revert to the most recent backup and exit.",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        dest="list_backups",
        help="List available backups and exit.",
    )
    args = parser.parse_args()

    if args.list_backups:
        return list_backups()
    if args.rollback:
        return do_rollback()
    if args.check:
        has_update, summary = check_for_updates()
        print(summary)
        return 3 if has_update else 0
    return update(force=args.force, dry_run=args.dry_run)


if __name__ == "__main__":
    sys.exit(main())
