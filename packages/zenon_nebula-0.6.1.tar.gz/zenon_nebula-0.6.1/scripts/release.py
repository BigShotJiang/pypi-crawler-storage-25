#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Release manager for Nebula.

Usage:
    python3 scripts/release.py bump patch|minor|major   # bump version
    python3 scripts/release.py changelog                 # print [Unreleased] notes
    python3 scripts/release.py validate                  # pre-tag validation gate
    python3 scripts/release.py tag                       # tag the current version
    python3 scripts/release.py publish                   # placeholder (handled by CI)

The `validate` command runs the full pre-tag gate: working tree clean,
version matches between core/version.py and pyproject.toml, CHANGELOG has
an entry for the version, docs are fresh, dep graph clean, tests pass.
Release CI runs the same gate before tagging.
"""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION_FILE = ROOT / "core" / "version.py"
PYPROJECT_FILE = ROOT / "pyproject.toml"
CHANGELOG_FILE = ROOT / "CHANGELOG.md"


# ---------------------------------------------------------------------------
# Version helpers
# ---------------------------------------------------------------------------


def read_version() -> tuple[int, int, int]:
    """Read the current version tuple from core/version.py."""
    content = VERSION_FILE.read_text(encoding="utf-8")
    match = re.search(r'__version__\s*=\s*"(\d+)\.(\d+)\.(\d+)"', content)
    if not match:
        print("error: could not parse __version__ from core/version.py", file=sys.stderr)
        sys.exit(2)
    return tuple(int(x) for x in match.groups())  # type: ignore[return-value]


def read_version_str() -> str:
    major, minor, patch = read_version()
    return f"{major}.{minor}.{patch}"


def read_pyproject_version() -> str:
    """Read the version declared in pyproject.toml (PEP 621 [project])."""
    content = PYPROJECT_FILE.read_text(encoding="utf-8")
    match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
    if not match:
        print("error: could not parse version from pyproject.toml", file=sys.stderr)
        sys.exit(2)
    return match.group(1)


def write_version(major: int, minor: int, patch: int) -> None:
    """Update version strings in core/version.py and pyproject.toml."""
    version_str = f"{major}.{minor}.{patch}"

    # core/version.py
    content = VERSION_FILE.read_text(encoding="utf-8")
    content = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        f'__version__ = "{version_str}"',
        content,
    )
    content = re.sub(
        r"__version_info__\s*=\s*\([^)]+\)",
        f"__version_info__ = ({major}, {minor}, {patch})",
        content,
    )
    VERSION_FILE.write_text(content, encoding="utf-8")

    # pyproject.toml — only replace the top-level [project].version line
    pyproject = PYPROJECT_FILE.read_text(encoding="utf-8")
    pyproject = re.sub(
        r'^version\s*=\s*"[^"]+"',
        f'version = "{version_str}"',
        pyproject,
        count=1,
        flags=re.MULTILINE,
    )
    PYPROJECT_FILE.write_text(pyproject, encoding="utf-8")

    print(f"version bumped to {version_str}")


def bump(kind: str) -> int:
    major, minor, patch = read_version()
    if kind == "major":
        major, minor, patch = major + 1, 0, 0
    elif kind == "minor":
        minor, patch = minor + 1, 0
    elif kind == "patch":
        patch += 1
    else:
        print(f"error: unknown bump type: {kind}", file=sys.stderr)
        return 2
    write_version(major, minor, patch)
    new_version = f"{major}.{minor}.{patch}"
    # Phase 19: lock the current codebase stats into the CHANGELOG
    # section for this version so historical releases carry their
    # frozen-at-tag metrics. This fires right after the version bump
    # so the stats match the commit the tag will eventually point at.
    try:
        stamped = stamp_changelog_stats(new_version)
        if stamped:
            print(f"stats stamped into CHANGELOG.md [{new_version}]")
    except Exception as exc:
        print(f"warn: could not stamp stats for {new_version}: {exc}", file=sys.stderr)
    return 0


# ---------------------------------------------------------------------------
# Stats stamping (Phase 19) — release-locked historical metrics
# ---------------------------------------------------------------------------


def _collect_stats_snapshot() -> dict[str, int] | None:
    """Return the current codebase stats via scripts/regen_docs.py.

    Uses the same underlying counter as regen_docs so the numbers are
    always consistent with whatever the stat-block regenerator would
    produce at this commit. Returns None if the counter can't be
    imported (e.g. during a fresh clone with no scripts/).
    """
    try:
        sys.path.insert(0, str(ROOT))
        from scripts.regen_docs import collect_stats
    except ImportError:
        return None

    try:
        stats = collect_stats()
    except Exception:
        return None
    return {
        "py_files": stats.py_files,
        "total_lines": stats.total_lines,
        "core_modules": stats.core_modules,
        "domains": stats.domain_count,
        "engines": stats.engine_count,
        "test_files": stats.test_files,
        "scripts": stats.scripts,
        "schema_tables": stats.schema_tables,
        "mcp_tables": stats.mcp_tools,
    }


def _render_stats_block(stats: dict[str, int]) -> str:
    """Render a compact stats block to inject into a CHANGELOG section."""
    return (
        "_Codebase snapshot at tag:_ "
        f"{stats['py_files']} py files, "
        f"{stats['total_lines']:,} LOC, "
        f"{stats['core_modules']} core modules, "
        f"{stats['domains']} domains, "
        f"{stats['engines']} engines, "
        f"{stats['test_files']} test files, "
        f"{stats['schema_tables']} schema tables."
    )


def stamp_changelog_stats(version: str) -> bool:
    """Inject a 'Codebase snapshot at tag' line into a CHANGELOG section.

    If the section for ``version`` already has a snapshot line, it is
    overwritten. Returns True if the CHANGELOG was rewritten, False
    if nothing changed (e.g., the section doesn't exist).
    """
    if not CHANGELOG_FILE.exists():
        return False
    snapshot = _collect_stats_snapshot()
    if snapshot is None:
        return False
    stats_line = _render_stats_block(snapshot)
    content = CHANGELOG_FILE.read_text(encoding="utf-8")

    section_re = re.compile(
        rf"(^## \[{re.escape(version)}\][^\n]*\n)(?:_Codebase snapshot at tag:_ [^\n]*\n\n?)?",
        re.MULTILINE,
    )
    match = section_re.search(content)
    if not match:
        # Section doesn't exist yet — nothing to stamp. bump() is typically
        # followed by moving [Unreleased] to [X.Y.Z] manually, so an
        # "unknown version" at stamp time is fine.
        return False

    replacement = f"{match.group(1)}\n{stats_line}\n\n"
    new_content = section_re.sub(replacement, content, count=1)
    if new_content == content:
        return False
    CHANGELOG_FILE.write_text(new_content, encoding="utf-8")
    return True


# ---------------------------------------------------------------------------
# Changelog
# ---------------------------------------------------------------------------


def generate_changelog() -> int:
    """Print a draft [Unreleased] section generated from conventional commits."""
    try:
        last_tag = subprocess.check_output(
            ["git", "describe", "--tags", "--abbrev=0"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except subprocess.CalledProcessError:
        last_tag = ""

    log_range = f"{last_tag}..HEAD" if last_tag else "HEAD"
    try:
        commits = (
            subprocess.check_output(
                ["git", "log", "--pretty=format:%s", log_range],
                text=True,
            )
            .strip()
            .splitlines()
        )
    except subprocess.CalledProcessError as exc:
        print(f"error: git log failed: {exc}", file=sys.stderr)
        return 2

    added, fixed, changed, security = [], [], [], []
    for commit in commits:
        if not commit:
            continue
        summary = commit.split(":", 1)[-1].strip() if ":" in commit else commit
        if commit.startswith("feat"):
            added.append(summary)
        elif commit.startswith("fix"):
            fixed.append(summary)
        elif commit.startswith(("refactor", "perf", "docs", "chore", "ci", "build")):
            changed.append(summary)
        elif commit.startswith("security"):
            security.append(summary)

    print("## [Unreleased]")
    if added:
        print("\n### Added")
        for a in added:
            print(f"- {a}")
    if fixed:
        print("\n### Fixed")
        for f in fixed:
            print(f"- {f}")
    if changed:
        print("\n### Changed")
        for c in changed:
            print(f"- {c}")
    if security:
        print("\n### Security")
        for s in security:
            print(f"- {s}")
    return 0


def _changelog_has_entry(version: str) -> bool:
    """Return True if CHANGELOG.md has a [version] section."""
    if not CHANGELOG_FILE.exists():
        return False
    content = CHANGELOG_FILE.read_text(encoding="utf-8")
    return bool(re.search(rf"^## \[{re.escape(version)}\]", content, re.MULTILINE))


# ---------------------------------------------------------------------------
# Tag + pre-tag validation
# ---------------------------------------------------------------------------


def _run(cmd: list[str], *, check: bool = False, capture: bool = True):
    return subprocess.run(
        cmd,
        cwd=ROOT,
        capture_output=capture,
        text=True,
        check=check,
    )


def _working_tree_clean() -> bool:
    r = _run(["git", "status", "--porcelain"])
    return r.returncode == 0 and r.stdout.strip() == ""


def _tag_exists(tag: str) -> bool:
    r = _run(["git", "rev-parse", "--verify", "--quiet", f"refs/tags/{tag}"])
    return r.returncode == 0


def validate(target_version: str | None = None) -> int:
    """Run the full pre-tag validation gate.

    - Working tree clean (or --dirty-ok supplied; not currently supported).
    - core/version.py and pyproject.toml agree.
    - Optional target_version matches the current version.
    - CHANGELOG.md has an entry for the current version (or [Unreleased] is
      non-empty — for dev builds).
    - scripts/regen_docs.py --check clean.
    - scripts/generate_dep_graph.py clean (0 violations).
    - Full pytest run green.

    Returns 0 on success, 1 on validation failure, 2 on setup error.
    """
    ok = True

    def check(label: str, passed: bool, detail: str = "") -> None:
        nonlocal ok
        mark = "OK  " if passed else "FAIL"
        suffix = f" — {detail}" if detail and not passed else ""
        print(f"  [{mark}] {label}{suffix}")
        if not passed:
            ok = False

    print("Release validation")
    print("=" * 50)

    # 1. Working tree clean
    check("working tree clean", _working_tree_clean(), "uncommitted changes present")

    # 2. core/version.py ↔ pyproject.toml agree
    core_version = read_version_str()
    pyproject_version = read_pyproject_version()
    check(
        f"version files agree ({core_version})",
        core_version == pyproject_version,
        f"core/version.py={core_version} pyproject.toml={pyproject_version}",
    )

    # 3. Optional target_version matches
    if target_version:
        stripped = target_version.lstrip("v")
        check(
            f"current version matches target ({stripped})",
            core_version == stripped,
            f"current={core_version} target={stripped}",
        )

    # 4. CHANGELOG entry
    has_entry = _changelog_has_entry(core_version)
    if not has_entry:
        # Dev builds may only have [Unreleased] — that's acceptable except
        # when the caller passed an explicit target version.
        if target_version:
            check(
                f"CHANGELOG has section for {core_version}",
                False,
                f"add `## [{core_version}] - YYYY-MM-DD` to CHANGELOG.md",
            )
        else:
            # Check Unreleased is non-empty
            content = CHANGELOG_FILE.read_text(encoding="utf-8") if CHANGELOG_FILE.exists() else ""
            m = re.search(r"^## \[Unreleased\](.+?)^## \[", content, re.MULTILINE | re.DOTALL)
            unreleased_body = m.group(1).strip() if m else ""
            check(
                "CHANGELOG [Unreleased] non-empty",
                bool(unreleased_body),
                "add entries under ## [Unreleased]",
            )
    else:
        check(f"CHANGELOG has section for {core_version}", True)

    # 5. Docs fresh
    r = _run([sys.executable, "scripts/regen_docs.py", "--check"])
    check("docs regeneration clean", r.returncode == 0, (r.stderr or "").strip()[:200])

    # 6. Dependency graph clean
    if (ROOT / "scripts" / "generate_dep_graph.py").exists():
        r = _run([sys.executable, "scripts/generate_dep_graph.py", "--check"])
        if r.returncode == 127:
            # --check may not be supported; fall back to plain run
            r = _run([sys.executable, "scripts/generate_dep_graph.py"])
        check(
            "dependency graph clean", r.returncode == 0, (r.stderr or r.stdout or "").strip()[-200:]
        )

    # 7. Architecture audit
    if (ROOT / "scripts" / "audit_architecture.py").exists():
        r = _run([sys.executable, "scripts/audit_architecture.py"])
        check(
            "architecture audit clean",
            r.returncode == 0,
            (r.stderr or r.stdout or "").strip()[-200:],
        )

    # 8. Tests pass
    r = _run([sys.executable, "-m", "pytest", "tests/", "-q", "--timeout=60", "-x"])
    check("test suite green", r.returncode == 0, (r.stdout + r.stderr).strip()[-300:])

    # 9. License headers (optional — only if the checker exists)
    if (ROOT / "scripts" / "add_license_headers.py").exists():
        r = _run([sys.executable, "scripts/add_license_headers.py", "--check"])
        check(
            "SPDX headers present", r.returncode == 0, (r.stderr or r.stdout or "").strip()[-200:]
        )

    print()
    if ok:
        print("Release validation PASSED.")
        return 0
    print("Release validation FAILED. Fix the items above before tagging.")
    return 1


def tag_release(force: bool = False) -> int:
    """Create an annotated git tag for the current version.

    Runs validate() first unless --force is passed. The tag is NOT pushed;
    run `git push origin v<version>` once you've confirmed.
    """
    if not force:
        rc = validate()
        if rc != 0:
            print("Refusing to tag on a failing validation. Use --force to override (unwise).")
            return rc

    version_str = f"v{read_version_str()}"
    if _tag_exists(version_str):
        print(f"error: tag {version_str} already exists", file=sys.stderr)
        return 1

    r = _run(
        ["git", "tag", "-a", version_str, "-m", f"Release {version_str}"],
        capture=False,
    )
    if r.returncode != 0:
        print(f"error: git tag failed (exit {r.returncode})", file=sys.stderr)
        return 1
    print(f"Tagged {version_str}. Push with: git push origin {version_str}")
    return 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(prog="nebula-release")
    sub = parser.add_subparsers(dest="command", required=True)

    p_bump = sub.add_parser("bump", help="Bump version")
    p_bump.add_argument("kind", choices=["major", "minor", "patch"])

    sub.add_parser("changelog", help="Print draft [Unreleased] notes from conventional commits")

    p_validate = sub.add_parser("validate", help="Run the pre-tag validation gate")
    p_validate.add_argument("--target", help="Target version this release is for (e.g. v0.2.0)")

    p_tag = sub.add_parser("tag", help="Create an annotated tag for the current version")
    p_tag.add_argument("--force", action="store_true", help="Skip validation (unwise)")

    p_stats = sub.add_parser(
        "stamp-stats",
        help="Inject a 'Codebase snapshot at tag' line into a CHANGELOG section",
    )
    p_stats.add_argument(
        "version",
        help="Version to stamp (e.g. 0.2.0). Must already have a section in CHANGELOG.md.",
    )

    sub.add_parser("publish", help="Publish to PyPI (handled by CI — this is a stub)")

    args = parser.parse_args()

    if args.command == "bump":
        return bump(args.kind)
    if args.command == "changelog":
        return generate_changelog()
    if args.command == "validate":
        return validate(target_version=args.target)
    if args.command == "tag":
        return tag_release(force=args.force)
    if args.command == "stamp-stats":
        version = args.version.lstrip("v")
        stamped = stamp_changelog_stats(version)
        if stamped:
            print(f"stats stamped into CHANGELOG.md [{version}]")
            return 0
        print(f"nothing to stamp (section [{version}] not found or unchanged)")
        return 1
    if args.command == "publish":
        print("Publishing is handled by .github/workflows/release.yml on tag push.")
        print("Run `./scripts/release.py tag` after `./scripts/release.py validate` passes.")
        return 0
    parser.print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
