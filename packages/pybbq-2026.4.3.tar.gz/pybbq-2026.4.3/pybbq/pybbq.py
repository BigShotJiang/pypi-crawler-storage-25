import 	numpy 				as np
import 	time
from 	datetime 			import datetime
from 	typing import List
# System and files
import 	sys
import	os
import 	shutil
import 	yaml
import 	logging
import  itertools
import 	pandas 				as pd

# CLI utilities (logo, terminal helpers)
from .lib.cli import print_logo

# File management utilities
from .lib.file_utils import FileManager
from .lib.cooling_utils import CoolingCalculator
from .lib.materials import resistivity, conductivity, heat_capacity, is_copper
from .lib.math_utils import powerlaw, powerlaw_v2, powerlaw_jac_v2, split_temperature_array
from .lib.geometry import geomspace_sections, nearest_index
from .lib.output_utils import SolverOutputFormatter, ProgressTracker

# Material functions
from steammaterials.STEAM_materials import STEAM_materials

# Matplotlib
import 	matplotlib.pyplot 		as plt
from 	matplotlib 				import cm

# Scipy
import 	scipy
import 	scipy.integrate
from 	scipy.optimize 			import fsolve
from 	scipy.interpolate 		import RegularGridInterpolator
from 	scipy.interpolate 		import interp1d

# Constants for improved code maintainability
DEFAULT_RTOL = 1e-6
DEFAULT_ATOL = 1e-8
DEFAULT_MAX_STEP = 0.001
STEFAN_BOLTZMANN_CONSTANT = 5.670374419e-8  # W/(m^2*K^4)
TEMPERATURE_TOLERANCE = 1e-6
CONVERGENCE_TOLERANCE = 1e-8
MAX_ITERATIONS = 1000
COOLING_COEFFICIENT_FACTOR = 1e6
HEAT_CAPACITY_MIN = 1.0e-99  # Minimum heat capacity to prevent division by zero
CONDUCTIVITY_MIN = 1.0e-10   # Minimum thermal conductivity
MINIMUM_TEMPERATURE = 0.1  # Minimum allowed temperature [K]
MAXIMUM_TEMPERATURE = 1200.0  # Maximum temperature for adiabatic sim [K];
DEFAULT_N_VALUE = 30.0 # Default n_value

class pyBBQ:
    """
    # Tim Mulder - BBQ (Bus-Bar-Quench) - Python 
    # tim.mulder@cern.ch // tim.mulder@gmail.com
    # Part of the CERN-STEAM modeling toolset.
    """

    def reset(self):
        """
        Resets all parameters.
        """
        # Input dictionaries:
        self.geometry_options = {}
        self.quench_heater = {}
        self.operational_parameters = {}
        self.materials = {}
        self.protection_settings = {}
        self.solver_settings = {}
        self.cooling = {}

        # Version and name
        self.sim_name = ''

        ### Initial Parameters ###
        # Conductor:
        self.material: str = None  # Materials: 'NbTi', 'Nb3Sn', 'ReBCO'
        self.CuSC: float = None  # Copper to superconductor ratio, only for HTS material
        self.shape: str = None  # Shape of the busbar: 'round' or 'rectangular'
        self.width: float = None  # Width in [m]
        self.height: float = None  # Height in [m]
        self.radius: float = 0.0  # Radius [round wire]
        self.strands: int = 1  # Amount of strands in a multistrand cable (needed for cooling)
        self.strand_dmt: float = 0.0  # Diameter of the strands
        self.wetted_p: float = 0.0  # Wetted perimeter
        self.wetted_A: float = 0.0  # Wetted area
        self.non_void: float = 1.0  # Void factor, Default 1.0
        self.CuSC_1: float = None
        self.CuSC_2: float = None
        self.M_element: float = None  # Mass of each element
        self.density: float = None  # Density of the conductor
        self.A_Conductor: float = None
        self.A_Conductor_Stab: float = None
        self.A_Conductor_SC: float = None
        self.A_Conductor_Substrate: float = None
        self.conductor_area: dict = None
        self.L_element: float = None
        self.V_element: float = None
        self.T_substrate: float = None
        self.T_stabilizer: float = None
        self.T_ReBCO: float = None
        self.W_tape: float = None

        # Derived geometric properties
        self.section_lengths = None
        self.section_volume = None
        self.section_mass = None
        self.section_outer_area = None

        # Mirror symmetry
        self.symmetry: bool = True
        self.symmetry_factor: float = 2.0  # Symmetry factor -> V = V_sim * 2, assuming mirror symmetry.

        # External current files
        self.external_current_bool: bool = False
        self.external_current_path: str = ''
        self.external_current_fit = None
        self.external_current_column = 1  # Column of the current to use, for example, with a cliq discharge there are 2 current columns.

        # Insulation:
        self.layers: int = 0  # Number of insulation layers.
        self.insulation_thickness: float = 0.0  # Total thickness of the insulation [m]
        self.thickness: float = 0.0  # Thickness of each layer [m] (calculated)
        self.A_insulation: List[float] = None
        self.V_insulation: List[float] = None
        self.L_insulation: List[float] = None

        # Model:
        self.busbar_length: float = 5.  # Length of the busbar [m]
        self.sections: int = 100  # Number of sections [-]
        self.T1: float = 1.9  # Temperature end 1 [K]
        self.Imax: float = None
        self.B_min: float = 0.0

        # Cooling:
        self.c1: (int, float) = 500.  # For He1 cooling
        self.c2: (int, float) = 5e4  # For He1 cooling
        self.c3: (int, float) = 250  # For He1 cooling
        self.c4: (int, float) = 200  # Not used, transient cooling regime
        self.c5: (int, float) = 200  # [600] Cooling parameter for superfluid -> H(T) = c5*(T1^p-T0^p)
        self.c6: (int, float) = 200  # [250] Cooling parameter for filmboiling -> H(T) = c6*(T1-T0)
        self.p: (int, float) = 4.0  # [3.4] Cooling parameter for superfluid -> H(T) = c5*(T1^p-T0^p)
        self.h1: (int, float) = 10  # For He1 cooling
        self.h2: (int, float) = 1e4  # For He1 cooling
        self.Pmax: (int, float) = 35e3  # Maximum power before going to the film boiling regime
        self.Tstar: float = 0.  # Calculated
        self.T_star_1: float = 0.  # Calculated
        self.T_star_2: float = 0.  # Calculated
        self.Helium_cooling: bool = False  # Turns external helium cooling on or off.
        self.Helium_cooling_internal: bool = False  # Turns internal helium cooling on or off.
        self.cooled_perimeter: float = None

        # Load:
        self.Current: (int, float) = 0.0  # Operating current [A]
        self.Inductance: float = 0.0  # Inductance of the load, assumed much larger than the inductance of the busbar [H]
        self.DumpV: float = None  # V
        self.DumpR: float = 1e99  # Ohm
        self.TimeConstant: float = 0.0
        self.decay: str = 'exponential'
        self.decay_rate: float = 10.0

        # Magnetic Field
        self.Calc_b_from_geometry: bool = False
        self.Background_Bx = 0.0  # Background magnetic field in the x direction
        self.Background_By = 0.0  # Background magnetic field in the y direction
        self.Background_Bz = 0.0  # Background magnetic field in the z direction
        self.Self_Field: float = 0.0  # T/A average self field
        self.B_gradient_type: str = None  # 'fit' to make a fit
        self.Background_positions = None  # position values for the fit.
        self.B0 = 0.0  # Calculated magnetic field
        self.B0_float = None  # If B0 is a float
        self.B0_init = None  # Initial external magnetic field
        self.B0_dump: bool = False  # When protection is activated, current and thus external field is ramped down.
        self.thetaFieldTape: float = 0.0  # theta angle of the magnetic field of the tape

        # Materials:
        self.Jc_4K_5T_NbTi: float = 2810000000.
        self.NbTi_Scaling: float = 1.0
        self.Nb3Sn_scaling_parameters: dict = {}
        self.Nb3Sn_Scaling: float = 1.0
        self.RRR: (int, float) = 180.
        self.RRR_T_ref: (int, float) = 295.
        self.RRR_array = []
        self.T_ref_RRR = []
        self.ones = []
        self.zeros = []
        self.my_interpolating_function = None
        self.n_value: int | float = 30.0

        # Bottura params
        self.Tc0: float = 9.2
        self.Bc20: float = 14.5
        self.C0: float = 27.04
        self.alpha: float = 0.57
        self.beta: float = 0.9
        self.gamma: float = 2.32
        self.Jc_ref: float = 1

        # Approximation functions
        self.Nb3Sn_fitname = 'summers'
        self.Bottura_approx = 'CFUN_Jc_NbTi_Bottura_v1'  # for Jc_NbTi
        self.Summers_approx = 'CFUN_Jc_Nb3Sn_Summers_v1'  # for Jc_Nb3Sn
        self.Bordini_approx = 'CFUN_Jc_Nb3Sn_Bordini_v1'  # for Jc_Nb3Sn

        self._SKIP_RHO = frozenset({'void', 'total', 'rebco', 'ybco', 'nbti', 'nb3sn', 'kapton'})
        self._SKIP_K = frozenset({'void', 'total', 'rebco', 'ybco', 'nbti', 'nb3sn', 'kapton'})
        self._SKIP_CV = frozenset({'void', 'total', 'rebco', 'ybco', 'kapton'})
        self._SKIP_CV_ALL = frozenset({'void', 'total', 'rebco', 'ybco'})
        self._NO_SKIP_SC = frozenset({'rebco', 'ybco', 'nbti', 'nb3sn'})

        # Insulation
        self.insulation_material: str = 'kapton'  # Defaulted to kapton

        # Function Names
        self.SC_Jc = 'CFUN_HTS_JcFit_SUPERPOWER_v1'
        self.Cu_Cv = 'CFUN_CvCu_v1'
        self.Cu_k = 'CFUN_kCu_v1'
        self.Cu_rho = 'CFUN_rhoCu_NIST_v2'
        self.Kapton_Cv = 'CFUN_CvKapton_v1'
        self.Kapton_k = 'CFUN_kKapton_v1'
        self.Hast_Cv = 'CFUN_CvHast_v1'
        self.NbTi_Cv = 'CFUN_CvNbTi_v1'
        self.Nb3Sn_Cv = 'CFUN_CvNb3Sn_v1'

        # Density
        self.current_density: float = None
        self.cross_sectional_area: float = None

        # Default reference values:
        self.NbTi_scaling_parameters = {'Jc': 2752000000.0, 'T': 4.2, 'B': 5.0, 'Tc0': 9.2, 'Bc20': 14.5, 'C0': 27.04, 'alpha': 0.57, 'beta': 0.9, 'gamma': 2.32}
        self.ReBCO_scaling_parameters = {'Ic_ref': 8235.0, 'T_ref': 4.5, 'B_ref': 4.8}
        self.HTS_Ic_REF: dict = {'Ic': 170, 'T_ref': 77.0, 'B_ref': 0.0, 'n-value': 15}  # Old version, still used in legacy mode.

        # Initialization of the hot-spot
        self.Power: (int, float) = 0.0  # Heat nodes x with y power
        self.Heating_nodes: List[int] = [0]  # List of nodes to heat
        self.Heating_mode: str = None  # 'time', 'constant', exponential.
        self.Heat_until: float = None
        self.Heating_time: (int, float) = None
        self.Heating_time_constant: float = None
        self.Heating_sig_C: (int, float) = 500.0  # Default 500 is sufficient for ms pulses.

        # Quench detection and protection
        self.protection: bool = True
        self.Detection_Voltage: float = 100e-3  # Voltage [V] on which a 'quench is detected
        self.Validation_Delay: float = 0.0  # Validation delay -> Detection time = Time when detection V is reached + validation time. No check is made if the voltage stayed above this value for the entire time.
        self.Protection_Delay: float = 0.0  # Delay time [s] after detection of a 'quench'
        self.Prot_Method: str = 'Dump_Resistance'  # Method of protection: 'Dump_Resistance', 'Diodes' # TODO should be checked / updated
        self.Prot_Resistance: float = 0.0  # Value of the dump resistor [0 Ohm]
        self.Detection_Time: (int, float) = 1e99  # Detection time
        self.Detected: bool = False  # Becomes true if a quench is detected

        # Output:
        self.results = None  # ODE Results
        self.NZPV_proped: float = 0.0  # Results NZPV array (not resetted for during parametric sweeps)
        self.T: list = []  # Results temperature array
        self.I: list = []  # Results current array
        self.B: list = []  # Results bfield array
        self.t: list = []  # Results time array
        self.Tmax: list = []  # Results Tmax array
        self.T_array: list = []
        self.Vtot: list = []  # Results Vtot array
        self.Ptot: list = []  # Results Ptot array
        self.Pheater: list = []  # Results list for the heater power
        self.NZPV_array = None  # Results NZPV array
        self.t_adiabatic: list = []  # Adiabatic simulation: time array [s]
        self.T_adiabatic: list = []  # Adiabatic simulation: temperature array [K]
        self.t_start_adiabatic: float = None  # Start the adiabatic simulation at t = t_start_adiabatic
        self.t_adiabatic_x05: list = []  # Adiabatic (from x=0.5): time array [s]
        self.T_adiabatic_x05: list = []  # Adiabatic (from x=0.5): temperature array [K]
        self.MIIT_adiabatic_x05: list = []  # Adiabatic (from x=0.5): cumulative MIIT starting at 0.0 [A^2s]
        self._adiabatic_current_interp = None  # Built at runtime by run_adiabatic_simulation()
        self._adiabatic_bfield_interp = None  # Built at runtime by run_adiabatic_simulation()
        self.T_miit_curve: list = []  # T vs MIIT reference curve: temperature [K]
        self.MIIT_curve: list = []  # T vs MIIT reference curve: MIIT [MA²s]

        # Analysis:
        self.Tref: float = 8.  # Reference for the 'quench' proparation velocity
        self.Posref: List[float] = [0.4, 0.5]  # Relative positions, exact nodes and distances will be calculated

        # Solver Settings:
        self.output: bool = False
        self.print_every: int = 10
        self.store_every: int = 50
        self.dt: float = 0.001
        self.t0: List[float] = [0.0, 10.]
        self.min_step: float = 1e-9
        self.max_step: float = 1e-3
        self.rtol: DEFAULT_RTOL
        self.atol: DEFAULT_RTOL
        self.cores: int = 1
        self.max_timestep = 0.0025
        self.min_timestep = 0.0001
        self.sampling_time_dT = 10.0
        self.time_step_rules = None

        # Plotting:
        self.open_plots = False  # If set to 'True' it will open the plot in a matplotlib window
        self.fig_results = None  # Fig 1: The main results figure
        self.fig_nzpv = None  # Fig 2: The NZPV figure
        self.fig_miit = None  # Fig 3: The MIIT figure
        self.fig_t_miit = None  # Fig 4: The T vs MIIT figure (pre-simulation reference)
        self.ax_t_miit = None  # Fig 4, ax: T vs MIIT axes
        self.ax1 = None  # Fig 1, ax 1: Temperature profiles
        self.ax2 = None  # Fig 1, ax 2: Current over time
        self.ax3 = None  # Fig 1, ax 3: Voltage profiles
        self.ax4 = None  # Fig 1, ax 4: Hot spot temperature over time
        self.ax5 = None  # Fig 1, ax 5: Total voltage over time
        self.ax6 = None  # Fig 1, ax 6: Total Power over time
        self.ax7 = None  # Fig 2, ax 1: Time till Tref
        self.ax8 = None  # Fig 2, ax 2: NZPV
        self.color = None  # List of colors
        self.x_plot = None  # x-axis of some plots
        self.plot_nr: int = None  # Number of the line, needed for the correct color

        # Output formatting settings:
        self.output_verbosity: str = 'normal'  # 'minimal', 'normal', 'detailed'
        self.output_format: str = 'single_line'  # 'single_line', 'multiline'
        self.output_precision: dict = None  # Will be set with defaults in __init__

        # Paths and storage
        self.init_path: str = ''  # Initial path
        self.path: str = ''  # General path
        self.output_path: str = ''  # Result folders files are stored here
        self.specific_output_path: str = ''  # Result files are stored here
        self.input_path: str = ''  # Any input files are stored here
        self.delimiter: str = ','  # Delimiter for the output file, commonly ',' or '\t'
        self.file_main: str = ''  # Path to the main output csv
        self.file_temperature: str = ''  # Path of the temperature data output csv
        self.file_voltage: str = ''  # Path of the voltage data output csv
        self.file_NZPV: str = ''  # Path of the NZPV data output csv
        self.file_sweeper: str = ''  # Path of the sweeper data output
        self.file_summary: str = ''  # Path of the summary data output csv
        self.voltage_output: bool = True  # Storing the full voltage output file
        self.temperature_output: bool = True  # Storing the full temperature output file
        self.main_output: bool = True  # Storing the main output results
        self.NZPV_output: bool = True  # Storing the NZPV output results
        self.summary_output: bool = True  # Storing the summary output results
        self.sweeper: bool = False  # Adjusted output for the parametric sweeper
        self.sweeper_nr: str = '0'  # Number of the sweeper result
        self.sweeperfull: bool = False  # True if the full output needs to be stored.
        self.uniquify_path: bool = True  # Uniquefies the output path, otherwise it deletes the existing folder and makes a new one.
        self.yaml_path: str = ''  # Path of the yaml input file

    def __init__(self, yaml_path: str = 'None', output_folder: str = 'None', option: str = 'Normal') -> None:
        """ Initializes the BBQ-class, if a yaml file is provided it will read it, otherwise standard values are taken.

        Args:
            yaml_path: path to the yaml file.
            output_folder: path to the output folder.
            option: simulation option type.
        """

        # (re)set all class attributes:
        self.reset()

        # Load the yaml file
        if yaml_path != 'None':
            self.yaml_path = yaml_path
            self.load_yaml()

        if output_folder != 'None':
            self.init_path = output_folder
        else:
            self.init_path = os.getcwd()

        if option == 'Sweep':
            # In case pyBBQ is run by the sweeper, the output will be adjusted.
            self.sweeper = True
            self.voltage_output = False
            self.temperature_output = False
            self.main_output = False
            self.NZPV_output = False
            self.summary_output = False
            self.sweeper_nr = yaml_path.split('.')[0].split('_')[-1]
        elif option == 'SweepFull':
            # In case pyBBQ is run by the sweeper, the output will be adjusted.
            self.sweeper = True
            self.sweeperfull = True
            self.sweeper_nr = yaml_path.split('.')[0].split('_')[-1]

        # Retrieving the tag:
        self.sim_name = self.solver_settings['sim_name'] if 'sim_name' in self.solver_settings else self.sim_name

        # Creating the folders.
        self.create_folders()

        # New function, being tested.
        self.derive_geometry()

        # Initial calculations
        self.calc_init_values()

        self.normalisation_areas()

        # Initialize cooling calculator with current parameters
        self.cooling_calculator = CoolingCalculator(
            T_helium=self.T1,
            c1=self.c1,
            c2=self.c2,
            c3=self.c3,
            c5=self.c5,
            c6=self.c6,
            p=self.p,
            h1=self.h1,
            h2=self.h2
        )
        
        # Initialize output formatter
        if self.output_precision is None:
            self.output_precision = {
                'time': 4,
                'temperature': 3,
                'current': 3,
                'voltage': 3,
                'magnetic_field': 3,
                'current_density': 3,
                'timestep': 6
            }
        
        self.output_formatter = SolverOutputFormatter(
            precision=self.output_precision,
            verbosity=self.output_verbosity
        )
        
        # Initialize progress tracker
        self.progress_tracker = ProgressTracker(
            total_time=self.t0[1],
            update_interval=self.print_every
        )
        
        # Calculate the current sharing properties
        self.new_calc_current_sharing()

        if self.conductor_area is not None:
            self.compute_T_vs_MIIT()
        self.start()
        self.run_adiabatic_simulation()
        self.append_adiabatic_to_main_csv()
        self.plot_results()
        self.calculate_NZPV()

        if self.sweeper: self.store_sweeper()

        logging.info("*** Simulation Finished ***")

    def load_yaml(self):
        with open(self.yaml_path) as file:
            contents = yaml.load(file, Loader=yaml.FullLoader)

        for i in contents:
            setattr(self, i, contents[i])

    def calc_init_values(self):
        """
            Some calculations and definitions of attributes using the input values
        """
        if not self.symmetry: self.symmetry_factor = 1.0
        if self.sim_name == '': self.sim_name = datetime.now().strftime("%Y-%m-%d")
        self.sections = int(self.sections)
        self.layers = self.layers if self.layers is not None else 0

        self.RRR_array = np.ones((1, self.sections)) * self.RRR  		# Making the arrays here, such that this step is not repeated a lot of times in the loops
        self.T_ref_RRR = np.ones((1, self.sections)) * self.RRR_T_ref  	# Making the arrays here, such that this step is not repeated a lot of times in the loops
        self.ones = np.ones((self.sections, )) 						# Making the arrays here, such that this step is not repeated a lot of times in the loops
        self.zeros = np.zeros((1, self.sections)) 						# Making the arrays here, such that this step is not repeated a lot of times in the loops
        self.Tstar = ((self.Pmax / self.c5) + self.T1 ** self.p) ** (1 / self.p) - self.T1
        self.wetted_A = self.strands * np.pi * self.strand_dmt * self.busbar_length /self.sections
        if self.CuSC is not None:
            self.CuSC_1 = self.CuSC/(self.CuSC+1)
            self.CuSC_2 = 1/(self.CuSC+1)
        self.thickness = self.insulation_thickness / self.layers if self.layers > 0 else 1e-9
        self.T_star_1 = self.h1/self.c1+self.T1
        self.T_star_2 = (self.h2/self.c2)**(1/2.5)+self.T1
        self.cores =  os.cpu_count() - 2 if self.cores is None else self.cores
        self.dt = float(self.dt)
        self.Imax = self.Current * 1.1

        # Protection
        if self.DumpV is not None:
            self.DumpR = self.DumpV/self.Current
        if self.Inductance is not None or self.DumpR is not None:
            self.TimeConstant = self.Inductance / self.DumpR
        else:
            self.TimeConstant = None
            logging.info('Protection time constant set to None as on or both Inductance and DumpR values are None.')
        self.TimeConstant = 1e-99 if self.TimeConstant == 0.0 else self.TimeConstant  # To prevent a division by zero for some very specific cases.

        # Heating

        # If the users sets a certain heater parameter, but not the corresponding heating mode, it will pre-select the heating mode.
        if self.Heating_mode is None:
            if self.Heat_until is not None:
                self.Heating_mode = 'constant'
            elif self.Heating_time is not None:
                self.Heating_mode = 'time'
            elif self.Heating_time_constant is not None:
                self.Heating_mode = 'exponential'

        # If the users sets a certain heater mode, but not the corresponding heating parameter, it will pre-select the heating parameter.
        if self.Heating_mode == 'constant' and self.Heat_until is None:
            logging.info('Heat_until is not set, setting it to 999 K.')
            self.Heat_until = 999
        elif self.Heating_mode == 'time' and self.Heating_time is None:
            logging.info('Heating_time is not set, setting it to 0.015 s.')
            self.Heating_time = 0.015
        elif self.Heating_mode == 'exponential' and self.Heating_time_constant is None:
            logging.info('Heating_time_constant is not set, setting it to 0.001 s.')
            self.Heating_time_constant = 0.001

        if self.Heating_mode is None:
            logging.warning('No heating mode is selected, make sure a Heating_mode (constant, time or exponential) or one of the heating parameters (Heat_until, Heating_time or Heating_time_constant) is defined.')

        if self.B_gradient_type == 'fit':
            x = np.linspace(self.Background_positions[0], self.Background_positions[-1], self.sections)
            B0 =  (np.array(self.Background_Bx) ** 2 + np.array(self.Background_By) ** 2 + np.array(self.Background_Bz) ** 2) ** 0.5
            B_fit = interp1d(self.Background_positions, B0, bounds_error=False, fill_value=(B0[0], B0[-1]))
            self.B0_float = False
            self.B0_init = B_fit(x)
            self.B0 = self.B0_init
            # Saving the figure
            B_fig = plt.figure()
            axc = B_fig.add_subplot(111)
            axc.plot(self.Background_positions, B0, ls='', marker='o', mfc='white')
            axc.plot(x, self.B0)
            axc.set_xlabel('Position, m')
            axc.set_ylabel('Magnetic Field, T')
            B_fig.savefig(self.specific_output_path + os.sep + 'Magnetic_field_gradient.png', dpi=300)
            plt.close(B_fig)
        else:
            if type(self.Background_Bx) in [float, int] or type(self.Background_Bx) in [float, int] or type(self.Background_Bx) in [float, int]:
                self.B0_init = (self.Background_Bx ** 2 + self.Background_By ** 2 + self.Background_Bz ** 2) ** 0.5
                self.B0_float = True
                self.B0 = np.ones((self.sections,)) * self.B0_init
            else:
                self.B0_init = (np.linspace(self.Background_Bx[0], self.Background_Bx[1], self.sections) ** 2 + np.linspace(self.Background_By[0], self.Background_By[1], self.sections) ** 2 + np.linspace(self.Background_Bz[0], self.Background_Bz[1], self.sections) ** 2) ** 0.5
                self.B0_float = False
                self.B0 = self.B0_init

        if self.external_current_bool:
            # If an external current is used, it will be fitted to be used within pybbq
            df = pd.read_excel(self.external_current_path, index_col=None)
            time_array = df[df.columns[0]].values
            current_array = df[df.columns[self.external_current_column]].values
            self.Current = current_array[0]
            self.external_current_fit = interp1d(time_array, current_array, bounds_error=False, fill_value=(current_array[0], current_array[-1]))
            self.Imax = np.max(self.external_current_fit(np.linspace(time_array[0], time_array[-1], 10000))) * 1.05

            # Saving the figure
            current_fig = plt.figure()
            axc = current_fig.add_subplot(111)
            axc.plot(time_array, current_array, ls='', marker='o', mfc='white')
            axc.plot(np.linspace(time_array[0], time_array[-1], 10000), self.external_current_fit(np.linspace(time_array[0], time_array[-1], 10000)))
            axc.set_xlabel('Time, s')
            axc.set_ylabel('Current, A')
            current_fig.savefig(self.specific_output_path + os.sep + 'Time_vs_Current.png', dpi=300)
            plt.close(current_fig)

    def derive_geometry(self):
        """
            Calculated the derived geometry parameters.
        """
        geometry_options = self.geometry_options
        quench_heater = self.quench_heater
        operational_parameters = self.operational_parameters
        materials = self.materials
        protection_settings = self.protection_settings
        solver_settings = self.solver_settings
        cooling = self.cooling

        expected_keys_geometry = ['insulation_layers', 'insulation_thickness', 'insulation_material', 'busbar_length', 'sections', 'spacing', 'shape', 'strand_dmt', 'cross_sectional_area', 'strands', 'width', 'height']
        expected_keys_quench_heaters = ['heating_nodes', 'power', 'additional_heating_nodes', 'heating_length', 'heating_mode', 'heating_time', 'heat_until', 'heating_time_constant', 'heating_sig_c']
        expected_keys_protection = ['protection', 'Inductance', 'DumpV', 'DumpR', 'Detection_Voltage', 'Protection_Delay', 'Validation_Delay', 'B0_dump', 'decay', 'decay_rate']
        expected_keys_materials = ['superconductor', 'scaling_parameters', 'Nb3Sn_fitname', 'fitname', 'n_value']
        expected_keys_operational_parameters = ['current_density', 'current', 'external_current', 'external_current', 'external_current_path', 'T_initial', 'Self_Field', 'B_gradient_type', 'Background_Bx', 'Background_By', 'Background_Bz', 'Background_positions']
        expected_keys_solver_settings = ['Tref', 'Posref', 'dt', 't0', 'print_every', 'store_every', 'max_timestep', 'min_timestep', 'min_step', 'max_step', 'atol', 'rtol', 'symmetry', 'sim_name', 'open_plots', 'time_step_rules']
        expected_keys_cooling = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'p', 'h1', 'h2', 'Pmax', 'Helium_cooling', 'Helium_cooling_internal', 'cooled_perimeter']

        for key in geometry_options.keys():
            if key not in expected_keys_geometry:
                raise ValueError(f"{key!r} is not a valid option in the materials dictionary. Expected one of {expected_keys_geometry}.")

        for key in quench_heater.keys():
            if key not in expected_keys_quench_heaters:
                raise ValueError(f"{key!r} is not a valid option in the materials dictionary. Expected one of {expected_keys_quench_heaters}.")

        for key in materials.keys():
            if key not in expected_keys_materials:
                raise ValueError(f"{key!r} is not a valid option in the materials dictionary. Expected one of {expected_keys_materials}.")

        for key in operational_parameters.keys():
            if key not in expected_keys_operational_parameters:
                raise ValueError(f"{key!r} is not a valid option in the operational_parameters dictionary. Expected one of {expected_keys_operational_parameters}.")

        for key in protection_settings.keys():
            if key not in expected_keys_protection:
                raise ValueError(f"{key!r} is not a valid option in the operational_parameters dictionary. Expected one of {expected_keys_protection}.")

        for key in solver_settings.keys():
            if key not in expected_keys_solver_settings:
                raise ValueError(f"{key!r} is not a valid option in the solver_settings dictionary. Expected one of {expected_keys_solver_settings}.")

        for key in cooling.keys():
            if key not in expected_keys_cooling:
                raise ValueError(f"{key!r} is not a valid option in the solver_settings dictionary. Expected one of {expected_keys_cooling}.")


        ### Solver settings and analysis:
        self.Tref = solver_settings['Tref'] if 'Tref' in solver_settings else None
        self.Posref = solver_settings['Posref'] if 'Posref' in solver_settings else self.Posref
        self.dt = solver_settings['dt'] if 'dt' in solver_settings else self.dt
        self.t0 = solver_settings['t0'] if 't0' in solver_settings else self.t0
        self.print_every = solver_settings['print_every'] if 'print_every' in solver_settings else self.print_every
        self.store_every = solver_settings['store_every'] if 'store_every' in solver_settings else self.store_every
        self.max_timestep = solver_settings['max_timestep'] if 'max_timestep' in solver_settings else self.max_timestep
        self.min_timestep = solver_settings['min_timestep'] if 'min_timestep' in solver_settings else self.min_timestep
        self.min_step = solver_settings['min_step'] if 'min_step' in solver_settings else self.min_step
        self.max_step = solver_settings['max_step'] if 'max_step' in solver_settings else self.max_step
        self.atol = solver_settings['atol'] if 'atol' in solver_settings else DEFAULT_ATOL
        self.rtol = solver_settings['rtol'] if 'rtol' in solver_settings else DEFAULT_RTOL
        self.symmetry = solver_settings['symmetry'] if 'symmetry' in solver_settings else True
        self.open_plots = solver_settings['open_plots'] if 'open_plots' in solver_settings else self.open_plots
        self.time_step_rules = solver_settings['time_step_rules'] if 'time_step_rules' in solver_settings else self.time_step_rules

        # Setting some variables in self. Will be removed later.
        self.sections = geometry_options['sections']
        self.busbar_length = geometry_options['busbar_length']
        self.shape = geometry_options['shape']
        self.strand_dmt = geometry_options['strand_dmt'] if 'strand_dmt' in geometry_options else 0.0

        ## Some checks:
        if self.shape.lower() not in ['round', 'rectangular']:
            raise Exception("Shape should either be round or rectangular.")

        # Optional parameter
        if 'cross_sectional_area' in geometry_options:
            self.cross_sectional_area = geometry_options['cross_sectional_area']

        if self.cross_sectional_area is None:
            self.cross_sectional_area = float(sum(self.conductor_area.values()))*1e6

        ### Operational Parameters: ###
        self.current_density = operational_parameters['current_density'] if 'current_density' in operational_parameters else None
        self.Current = operational_parameters['current'] if 'current' in operational_parameters else None
        self.external_current_bool = operational_parameters['external_current'] if 'external_current' in operational_parameters else False
        self.external_current_path = operational_parameters['external_current_path'] if 'external_current_path' in operational_parameters else None
        self.T1 = operational_parameters['T_initial'] if 'T_initial' in operational_parameters else None
        self.Self_Field = operational_parameters['Self_Field'] if 'Self_Field' in operational_parameters else 0.0
        self.B_gradient_type = operational_parameters['B_gradient_type'] if 'B_gradient_type' in operational_parameters else self.B_gradient_type
        self.Background_Bx = operational_parameters['Background_Bx'] if 'Background_Bx' in operational_parameters else self.Background_Bx
        self.Background_By = operational_parameters['Background_By'] if 'Background_By' in operational_parameters else self.Background_By
        self.Background_Bz = operational_parameters['Background_Bz'] if 'Background_Bz' in operational_parameters else self.Background_Bz
        self.Background_positions = operational_parameters['Background_positions'] if 'Background_positions' in operational_parameters else self.Background_positions

        if self.current_density is None and self.Current is not None:
            self.current_density = self.Current / self.cross_sectional_area
            logging.info(f'Current density calculated: {self.current_density} A/mm2, calculated from {self.Current} A / {self.cross_sectional_area} mm2.')
        elif self.current_density is not None and self.Current is None:
            self.Current = self.current_density * self.cross_sectional_area
            logging.info(f'Current calculated: {self.current_density} A, calculated from {self.current_density} A/mm2 * {self.cross_sectional_area} mm2.')
        elif self.external_current_bool and self.external_current_path is not None:
            logging.info(f'The current profile will be loaded from: {self.external_current_path}.')
        elif self.current_density is not None and self.Current is not None:
            error = np.abs((self.Current - self.current_density * self.cross_sectional_area)/(self.current_density * self.cross_sectional_area))*100
            if error < 0.01:
                logging.info(f'Both the current ({self.Current} A) and the current_density {self.current_density} A/mm2) were set, and the error ({error}) is smaller than 0.01 percent.')
            else:
                raise ValueError(f'Both the current ({self.Current} A) and the current_density {self.current_density} A/mm2) were set, and the error ({error}) is larger than 0.01 percent.')
        else:
            logging.warning(f'Neither the current nor current_density is set. This is likely a mistake!')

        if self.T1 is None:
            logging.warning(f'No initial temperature was set!')

        ### Materials: ###
        superconductor = materials['superconductor'] if 'superconductor' in materials else ''
        allowed_values = ['nbti', 'nb3sn', 'rebco', 'ybco', 'gdbco', 'lbco', 'smbco', 'eubco']
        if superconductor.lower() == 'nbti':
            self.material = 'nbti'
            self.Tref = 9.0 if self.Tref is None else self.Tref
        elif superconductor.lower() == 'nb3sn':
            self.material = 'nb3sn'
            self.Tref = 15.0 if self.Tref is None else self.Tref
        elif superconductor.lower() in ['rebco', 'ybco', 'gdbco', 'lbco', 'smbco', 'eubco']:
            self.material = 'rebco'
            self.Tref = 80.0 if self.Tref is None else self.Tref
        else:
            raise ValueError(f"{superconductor!r} is not a valid superconductor option. Expected one of {allowed_values}.")

        scaling_parameters = materials['scaling_parameters'] if 'scaling_parameters' in materials else {}

        if self.material == 'nbti':
            self.NbTi_scaling_parameters = scaling_parameters
            self.fitname = materials['fitname'].lower() if 'fitname' in materials else self.Bottura_approx
        elif self.material == 'nb3sn':
            self.Nb3Sn_scaling_parameters = scaling_parameters
            self.Nb3sn_fitname = materials['Nb3Sn_fitname'].lower() if 'Nb3Sn_fitname' in materials else None
            if self.Nb3sn_fitname is None:
                raise ValueError(f"No fitname is provided in the material dictionary. Expected either 'summers' or 'bordini'.")
            elif self.Nb3sn_fitname not in ['summers', 'bordini']:
                raise ValueError(f"{self.fitname!r} is not a valid superconductor option. Expected one of {['summers', 'bordini']}.")
            else:
                if self.Nb3sn_fitname == 'summers':
                    self.fitname = materials['fitname'].lower() if 'fitname' in materials else self.Summers_approx
                elif self.Nb3sn_fitname == 'bordini':
                    self.fitname = materials['fitname'].lower() if 'fitname' in materials else self.Bordini_approx
        elif self.material == 'rebco':
            self.ReBCO_scaling_parameters = scaling_parameters
            self.fitname = materials['fitname'].lower() if 'fitname' in materials else self.SC_Jc

        logging.info(f"The superconductor is {self.material!r} with the following scaling parameters: {scaling_parameters}, and the {self.fitname!r} fitname.")

        n_value = materials['n_value'] if 'n_value' in materials else None
        if n_value is not None:
            self.n_value = n_value
        else:
            self.n_value = DEFAULT_N_VALUE
            logging.warning(f'The n_value was set to the default value of {DEFAULT_N_VALUE}!')

        # Protection:
        self.protection = protection_settings['protection'] if 'protection' in protection_settings else True

        if self.protection:
            self.Inductance = protection_settings['Inductance'] if 'Inductance' in protection_settings else None
            self.DumpV = protection_settings['DumpV'] if 'DumpV' in protection_settings else None
            self.DumpR = protection_settings['DumpR'] if 'DumpR' in protection_settings else self.DumpR
            self.Detection_Voltage = protection_settings['Detection_Voltage'] if 'Detection_Voltage' in protection_settings else self.Detection_Voltage
            self.Protection_Delay = protection_settings['Protection_Delay'] if 'Protection_Delay' in protection_settings else self.Protection_Delay
            self.Validation_Delay = protection_settings['Validation_Delay'] if 'Validation_Delay' in protection_settings else self.Validation_Delay
            self.B0_dump = protection_settings['B0_dump'] if 'B0_dump' in protection_settings else self.B0_dump
            self.decay = protection_settings['decay'].lower() if 'decay' in protection_settings else self.decay
            self.decay_rate  = protection_settings['decay_rate'] if 'decay_rate' in protection_settings else 0.0

            if self.DumpV is not None and self.DumpR is None:
                self.DumpR = self.DumpV / self.Current
            elif self.DumpR is not None and self.DumpV is None:
                self.DumpV = self.DumpR * self.Current

            logging.info(f"Protection is set to {self.protection} with the following paramaters:")
            logging.info(f"Quench protection is triggered when the voltage threshold of {self.Detection_Voltage} V is reached and validated for {self.Validation_Delay} s.")
            logging.info(f"The protection scheme is then activated after {self.Protection_Delay} s")

            if self.decay == 'exponential':
                logging.info(f"An exponential decay rate is selected with the following values:")
                logging.info(f"dI/dt = - I / ({self.Inductance} H / ({self.DumpR} Ohm Dump Resistance + Wire Resistance * {self.symmetry_factor} (symmetry factor)))")
            elif self.decay == 'constant':
                logging.info(f"An constant decay rate of dI/dt = - {self.decay_rate} A/s is selected. ")
            elif self.decay == 'no_load_fast':
                logging.info(f"An exponential decay rate of dI/dt = - I / 0.001 A/s is selected. ")
            else:
                logging.warning(f"No decay method was selected.")
        else:
            logging.warning(f"Quench protection in not enabled. You can enable it by setting 'protection' to 'True' in the protection_settings dictionary.")

        self.c1 = cooling['c1'] if 'c1' in cooling else self.c1
        self.c2 = cooling['c2'] if 'c2' in cooling else self.c2
        self.c3 = cooling['c3'] if 'c3' in cooling else self.c3
        self.c4 = cooling['c4'] if 'c4' in cooling else self.c4
        self.c5 = cooling['c5'] if 'c5' in cooling else self.c5
        self.c6 = cooling['c6'] if 'c6' in cooling else self.c6
        self.h1 = cooling['h1'] if 'h1' in cooling else self.h1
        self.h2 = cooling['h2'] if 'h2' in cooling else self.h2
        self.Pmax = cooling['Pmax'] if 'Pmax' in cooling else self.Pmax
        self.Helium_cooling = cooling['Helium_cooling'] if 'Helium_cooling' in cooling else self.Helium_cooling
        self.Helium_cooling_internal = cooling['Helium_cooling_internal'] if 'Helium_cooling_internal' in cooling else self.Helium_cooling_internal
        self.cooled_perimeter = cooling['cooled_perimeter'] if 'cooled_perimeter' in cooling else self.cooled_perimeter

        # Insulation
        self.layers = int(geometry_options['insulation_layers']) if 'insulation_layers' in geometry_options else 0
        self.insulation_thickness = geometry_options['insulation_thickness'] if 'insulation_thickness' in geometry_options else 0.0
        self.insulation_material = geometry_options['insulation_material'] if 'insulation_material' in geometry_options else 'kapton'

        if self.layers > 0:
            logging.info(f'Insulation is set with the following parameters: {self.insulation_material} material, {self.layers} layers and {self.insulation_thickness} m thickness.')

        # Creating the nodes of the heater.
        self.Heating_nodes = quench_heater['heating_nodes']
        self.Power = quench_heater['power']  # Power in W/m

        if 'heating_length' in quench_heater and 'additional_heating_nodes' in quench_heater:
            self.Heating_section_lengths = quench_heater['heating_length']/quench_heater['additional_heating_nodes'] * np.ones(quench_heater['additional_heating_nodes'])
            self.Heating_center_points = np.linspace(0, quench_heater['heating_length'], quench_heater['additional_heating_nodes']*2+1)[1::2]
            offset_length = quench_heater['heating_length']  # Offset to be removed from the busbar length
            offset_sections = quench_heater['additional_heating_nodes']  # Offset to be removed from the number of sections.
        else:
            self.Heating_section_lengths = None
            self.Heating_center_points = None
            offset_length = 0.0
            offset_sections = 0

        self.Heating_mode = quench_heater['heating_mode'] if 'heating_mode' in quench_heater else None
        self.Heating_time = quench_heater['heating_time'] if 'heating_time' in quench_heater else None
        self.Heat_until = quench_heater['heat_until'] if 'heat_until' in quench_heater else None
        self.Heating_time_constant  = quench_heater['heating_time_constant'] if 'heating_time_constant' in quench_heater else None
        self.Heating_sig_C = quench_heater['heating_sig_c'] if 'heating_sig_c' in quench_heater else self.Heating_sig_C

        if self.Heating_mode=='time':
            if self.Heating_sig_C < (1 / self.Heating_time * 50.0):
                logging.warning(f'Heating_sig_C ({self.Heating_sig_C}) is likely too low for the heating time that was set, it should be 2 or 3 orders of magnitude larger than 1 / the heating time.')
        # self.Heating_sig_C = 1/(quench_heater['heating_time']) * 1000.0 if 'heating_time' in quench_heater else self.Heating_sig_C # Should be 2 or 3 orders of magnitude larger than 1 / the heating time.

        # Creating the section length.
        busbar_length = geometry_options['busbar_length'] - offset_length
        sections = geometry_options['sections'] - int(offset_sections)
        if geometry_options['spacing'] == 'linspace':
            self.section_lengths = busbar_length / sections * np.ones(int(sections))
            self.center_points = np.linspace(offset_length, busbar_length, sections*2+1)[1::2]
        elif geometry_options['spacing'] == 'geomspace':
            if 'heating_length' in self.quench_heater and 'additional_heating_nodes' in self.quench_heater:
                first_length = self.quench_heater['heating_length']/self.quench_heater['additional_heating_nodes']
            else:
                first_length = 1.0e-9
            self.center_points, self.section_lengths = geomspace_sections(busbar_length, sections, first_length=first_length)

        # Exporting the center positions to the results output folder:
        np.savetxt(self.specific_output_path + os.sep + 'center_points.csv' , self.center_points, delimiter=",")

        # Adding the heater section and the normal busbar sections.
        self.section_lengths = np.concatenate((self.Heating_section_lengths, self.section_lengths)) if self.Heating_section_lengths is not None else self.section_lengths
        self.center_points = np.concatenate((self.Heating_center_points, self.center_points)) if self.Heating_center_points is not None else self.center_points

        # Calculating the volume and the cross sectional area based on the
        # height and width of the conductor, or the strand diameter.
        if geometry_options['shape'] == 'rectangular':
            A_total = geometry_options['height'] * geometry_options['width']
            self.section_volume = A_total * self.section_lengths
            self.section_outer_area = 2 * geometry_options['height'] * self.section_lengths
            self.section_outer_area += 2 * geometry_options['width'] * self.section_lengths
        elif geometry_options['shape'] == 'round':
            A_total = np.pi * (self.strand_dmt / 2) ** 2
            self.section_volume = A_total * self.section_lengths
            self.section_outer_area = 2 * np.pi * (self.strand_dmt / 2) * self.section_lengths

        # Length of a single element [m].
        self.L_element = self.busbar_length / self.sections

        ## Insulation ##

        # Check if keys are in the geometry option dictionary.
        if ('insulation_material' in geometry_options and
                'insulation_layers' in geometry_options and
                'insulation_thickness' in geometry_options):
            n_layers = int(geometry_options['insulation_layers'])
            t_total = geometry_options['insulation_thickness']
            # If layers or thickness is zero, there is no insulation.
            if n_layers > 0 and t_total > 0:
                # Each computational insulation layer has equal thickness.
                t_layer = t_total / n_layers

                # A_insulation[i]: lateral interface area at the inner boundary
                # of layer i (= outer boundary of layer i-1), per section [m²].
                # V_insulation[i]: volume of layer i per section [m³].
                # L_insulation[i]: effective half-length used in the harmonic-
                # mean conductance formula 2*k1*k2/(k1+k2)*A/L*ΔT:
                #   i=0  → half-distance from conductor centre to inner surface
                #   i>0  → thickness of one insulation layer
                self.A_insulation = []
                self.V_insulation = []

                if geometry_options['shape'] == 'round':
                    r = self.strand_dmt / 2
                    self.L_insulation = [r] + [t_layer] * n_layers
                    for i in range(n_layers):
                        r_in  = r + i * t_layer
                        r_out = r + (i + 1) * t_layer
                        self.A_insulation.append(
                            2 * np.pi * r_in * self.section_lengths
                        )
                        self.V_insulation.append(
                            np.pi * (r_out**2 - r_in**2) * self.section_lengths
                        )

                elif geometry_options['shape'] == 'rectangular':
                    w = geometry_options['width']
                    h = geometry_options['height']
                    # Harmonic-mean half-length for the conductor↔layer-0 interface.
                    L0 = 2 / (1 / (0.5 * (h + t_layer)) + 1 / (0.5 * (w + t_layer)))
                    self.L_insulation = [L0] + [t_layer] * n_layers
                    for i in range(n_layers):
                        w_i = w + 2 * i * t_layer
                        h_i = h + 2 * i * t_layer
                        w_o = w + 2 * (i + 1) * t_layer
                        h_o = h + 2 * (i + 1) * t_layer
                        self.A_insulation.append(
                            2 * (w_i + h_i) * self.section_lengths
                        )
                        self.V_insulation.append(
                            (w_o * h_o - w_i * h_i) * self.section_lengths
                        )

    def create_folders(self):
        """Creates the output folders using FileManager utility."""
        print(f"The current working directory is {self.init_path}")

        if self.sweeper and self.sweeperfull:
            option = 'SweepFull'
        elif self.sweeper:
            option = 'Sweep'
        else:
            option = 'Normal'
        
        # Create FileManager and setup output structure
        file_manager = FileManager(self.init_path, self.sim_name, option)
        paths = file_manager.setup_output_structure(
            sections=self.sections,
            layers=self.layers,
            delimiter=self.delimiter,
            uniquify=self.uniquify_path,
            sweeper_nr=self.sweeper_nr
        )
        
        # Update class attributes with paths from FileManager
        for key, value in paths.items():
            setattr(self, key, value)
        
        # Start logging
        file_manager.start_logger()
        
        # Copy input yaml to output folder
        if hasattr(self, 'yaml_path') and self.yaml_path:
            yaml_dest_name = os.path.basename(self.yaml_path)
            shutil.copy(self.yaml_path, os.path.join(self.specific_output_path, yaml_dest_name))

    def store_results(self, T, V):
        if self.main_output:
            try:
                # Update MIIT = integral of I^2 dt using the trapezoidal rule.
                # When only one time point exists (t=0) the increment is zero.
                if len(self.t) >= 2:
                    dt = self.t[-1] - self.t[-2]
                    self.MIIT += 0.5 * (self.I[-2]**2 + self.I[-1]**2) * dt

                with open(self.file_main, 'a+') as f:
                    data = [
                        str(self.t[-1]),
                        str(self.Tmax[-1]),
                        str(self.I[-1]),
                        str(self.Vtot[-1]),
                        str(self.Ptot[-1]),
                        str(self.Pheater[-1]),
                        str(self.I[-1]*self.DumpR if self.t[-1] > (self.Detection_Time+self.Protection_Delay) else 0.0),
                        str(self.MIIT),
                    ]
                    f.write(self.delimiter.join(data) + '\n')
            except OSError:
                logging.info("Writing on %s has failed." % self.file_main)

        if self.temperature_output:
            try:
                with open(self.file_temperature, 'a+') as f:
                    data = [str(self.t[-1])] + [str(i) for i in T.tolist()]
                    f.write(self.delimiter.join(data) + '\n')
            except OSError:
                logging.info("Writing on %s has failed." % self.file_temperature)

        if self.voltage_output:
            try:
                with open(self.file_voltage, 'a+') as f:
                    data = [str(self.t[-1])] + [str(i) for i in V]
                    f.write(self.delimiter.join(data) + '\n')
            except OSError:
                logging.info("Writing on %s has failed." % self.file_voltage)

    def store_sweeper(self):
        """ Stores the results for the parametric sweep
        """
        try:
            with open(self.file_sweeper, 'a+') as f:
                data = [str(np.max(self.Tmax)), str(self.NZPV_proped)]
                f.write(self.delimiter.join(data) + '\n')
        except OSError:
            logging.info("Writing on %s has failed." % self.file_sweeper)


    def new_calc_current_sharing(self):
        """
            Method to calculate the current sharing based on the conductor geometry and performance parameters.
            This function will replace the one below at a later time. Please ignore this function for now.
        """

        ## Note: I am currently working on this function, it is not yet ready.

        ## First: we need to select either LTS or HTS
        if self.material.lower() in ['nbti', 'nb3sn']:
            superconductor_group = 'LTS'
        elif self.material.lower() in ['rebco', 'ybco']:
            superconductor_group = 'HTS'
        else:
            superconductor_group = None

        self.all_mats = list(self.conductor_area.keys())

        # Creating the normal and SC dictionaries
        self.Normal_rho_FIT = {}
        self.Normal_k_FIT = {}
        self.Normal_Cv_FIT = {}
        self.SC_Ic_Scaling = {}

        # Lut minmax
        self.lut_limits = {
            'IIc_min': 1e-9,
            'IIc_max': 1e3,
            'IIc_count': 200,
            'U_min': 1e-15,
            'U_max': 1e3,
            'U_count': 200,
        }

        # Limits depending on the material group.
        if superconductor_group == 'LTS':
            T       = np.linspace(1.0, 20.0, 200)       # Temperature range for the superconductor
            B       = np.geomspace(0.0001, 30.0, 200)    # Magnetic field range, geomspace, so 100 T is fine
            Deg     = None
        else:
            T       = np.linspace(1.0, 100.0, 100)      # Temperature range for the superconductor
            B       = np.geomspace(0.0001, 100.0, 100)   # Magnetic field range, geomspace, so 100 T is fine
            Degr    = np.linspace(0, 360, 360)          # Angle
        T_rho       = np.linspace(1.0, 1000.0, 3000)    # Temperature range for the normal conducting parts

        # I/Ic[-] and U[V/m] for the current sharing lookup table.
        IIc = np.concatenate((
            np.geomspace(self.lut_limits['IIc_min'], 0.4, int(self.lut_limits['IIc_count'] * 0.15), endpoint=False),
            np.linspace(0.4, 5.0, int(self.lut_limits['IIc_count'] * 0.35), endpoint=False),
            np.linspace(5.0, 100.0, int(self.lut_limits['IIc_count'] * 0.25), endpoint=False),
            np.geomspace(100.0, self.lut_limits['IIc_max'], int(self.lut_limits['IIc_count'] * 0.25)),
        ))

        U = np.concatenate((
            np.geomspace(self.lut_limits['U_min'], 1e-4, int(self.lut_limits['U_count'] * 0.2), endpoint=False),
            np.geomspace(1e-4, 100.0, int(self.lut_limits['U_count'] * 0.4), endpoint=False),
            np.linspace(100.0, self.lut_limits['U_max'], int(self.lut_limits['U_count'] * 0.4))
        ))

        # Making the resistivity, thermal conductivity and heat capacity interpolation function
        input_list = np.array([i for i in itertools.product(T_rho, B)])
        for mat in self.all_mats:
            T_2d = input_list[:, 0].reshape(1, -1)
            B_2d = input_list[:, 1].reshape(1, -1)
            R  = resistivity( T_2d, B_2d, {mat: 1.0}).flatten()
            k  = conductivity(T_2d, B_2d, {mat: 1.0}).flatten()
            Cv = heat_capacity(T_2d, B_2d, {mat: 1.0}).flatten()

            # Reshape the arrays to match the 2D grid structure
            rho_fit = RegularGridInterpolator((T_rho, B), R.reshape((len(T_rho), len(B))))
            k_fit   = RegularGridInterpolator((T_rho, B), k.reshape((len(T_rho), len(B))))
            Cv_fit  = RegularGridInterpolator((T_rho, B), Cv.reshape((len(T_rho), len(B))))

            # The fits are added to a dictionary.
            self.Normal_rho_FIT[mat] = rho_fit
            self.Normal_k_FIT[mat]   = k_fit
            self.Normal_Cv_FIT[mat]  = Cv_fit

        ## Calculating the conductor properties such as its Resistance per meter.

        # Only normal-conducting materials contribute to electrical and thermal resistance.
        _SC_VOID = frozenset({'void', 'total', 'rebco', 'ybco', 'nbti', 'nb3sn', 'kapton'})
        normal_mats = [m for m in self.all_mats if m.lower() not in _SC_VOID]

        # Electrical Resistance in [Ohm/m]
        R = np.zeros_like(input_list[:, 0])
        for mat in normal_mats:
            R += self.conductor_area[mat] / self.Normal_rho_FIT[mat]((input_list[:, 0], input_list[:, 1]))
        R = 1 / R # Because it is a parallel resistance.

        # Fitting the electrical resistance
        self.R_fit = RegularGridInterpolator((T_rho, B), R.reshape((len(T_rho), len(B))), bounds_error=False, fill_value=1e-99)

        # Thermal Resistance
        R = np.zeros_like(input_list[:, 0])
        for mat in normal_mats:
            R += self.Normal_k_FIT[mat]((input_list[:, 0], input_list[:, 1])) * self.conductor_area[mat]
        R = 1 / R # Because it is a parallel resistance.

        # Fitting the Resistance
        self.R_thermal_fit = RegularGridInterpolator((T_rho, B), R.reshape((len(T_rho), len(B))), bounds_error=False, fill_value=1e-99)

        ## Making the I/Ic and U interpolation functions.
        logging.info('Generating the current sharing look-up-table.')
        input_list = np.array([j for j in itertools.product(IIc, U)])
        x = np.zeros((len(input_list), 1))
        for j in range(len(input_list)):
            # Solves the powerlaw function, these should refer to powerlaw_v2() and powerlaw_jac_v2() from math_utils.py.
            # Extract scalar value from fsolve result to avoid ValueError
            result = fsolve(powerlaw_v2, 1.0, args=(input_list[j][0], input_list[j][1], self.n_value), fprime=powerlaw_jac_v2, maxfev=1000000, xtol=1e-9)
            x[j] = result[0] if isinstance(result, np.ndarray) else result
        
        # Clips the x to the [0, 1] range.
        x = np.clip(x, 0, 1)

        # The current sharing interpolation function.
        self.SC_Cur_Sharing = RegularGridInterpolator((IIc, U), x.reshape((len(IIc), len(U))), bounds_error=False, fill_value=1e-99)

        ## Making the critical current (Ic) fit
        # Three different type of superconductors are implemented: NbTi, Nb3Sn and ReBCO

        if superconductor_group == 'LTS':
            # This is for the NbTi and Nb3Sn materials:
            input_list = np.array([j for j in itertools.product(T, B)])
            if self.material.lower() == 'nbti':
                fitname = self.Bottura_approx # The Bottura fit is the only supported NbTi fit.
            elif self.material.lower() == 'nb3sn':  
                if self.Nb3Sn_fitname.lower() == 'bordini':
                    fitname = self.Bordini_approx
                elif self.Nb3Sn_fitname.lower() == 'summers':
                    fitname = self.Summers_approx
                else:
                    # If the material is Nb3Sn and the fitname is not in the list, the Bordini fit is chosen.
                    fitname = self.Bordini_approx
                    # In that case also the fitting parameters are set to the default ones:
                    self.Nb3Sn_scaling_parameters: {'T': 4.2, 'B': 12.0, 'Ic': 740.0, 'Tc0': 18.0, 'Bc20': 29.0}
                    logging.warning('Fitname not recognized, set to the Bordini fit.') # User should get a warning.
        elif superconductor_group == 'HTS':
            # This is for the ReBCO material:
            input_list = np.array([j for j in itertools.product(T, B)])
            fitname = self.SC_Jc

        # This should be a helper function:
        if self.material.lower() == 'nbti':
            # Getting the scaling parameters
            # This one will replace the parameters now set as attributes.

            # Check if the values are in the dictionary, thus must improve and also provide warnings if things are not there.
            Ic_ref = float(self.NbTi_scaling_parameters['Ic']) if 'Ic' in self.NbTi_scaling_parameters.keys() else None
            Jc_ref = float(self.NbTi_scaling_parameters['Jc']) if 'Jc' in self.NbTi_scaling_parameters.keys() else None
            T_scaling = float(self.NbTi_scaling_parameters['T']) if 'T' in self.NbTi_scaling_parameters.keys() else None
            B_scaling = float(self.NbTi_scaling_parameters['B']) if 'B' in self.NbTi_scaling_parameters.keys() else None
            Tc0 = float(self.NbTi_scaling_parameters['Tc0']) if 'Tc0' in self.NbTi_scaling_parameters.keys() else 9.2
            Bc20 = float(self.NbTi_scaling_parameters['Bc20']) if 'Bc20' in self.NbTi_scaling_parameters.keys() else 14.5
            C0 = float(self.NbTi_scaling_parameters['C0']) if 'C0' in self.NbTi_scaling_parameters.keys() else 27.04
            alpha = float(self.NbTi_scaling_parameters['alpha']) if 'alpha' in self.NbTi_scaling_parameters.keys() else 0.57
            beta = float(self.NbTi_scaling_parameters['beta']) if 'beta' in self.NbTi_scaling_parameters.keys() else 0.9
            gamma = float(self.NbTi_scaling_parameters['gamma']) if 'gamma' in self.NbTi_scaling_parameters.keys() else 2.32

            if Jc_ref is not None and Ic_ref is None:
                Ic_ref = Jc_ref * self._A_SC # Converting current density [A/m^2] -> [A]
                logging.info(f'Ic_ref calculated by using Jc_ref * A_SC = {Ic_ref:.2f} A.')

            if None in [Ic_ref, T_scaling, B_scaling]:
                logging.warning(f'WARNING: None found in NbTi Jc scaling dictionary, no scaling is applied: Ic_ref: {Ic_ref}, T_scaling: {T_scaling}, B_scaling: {B_scaling}.')
            else:
                sm_args = [Tc0, Bc20, 1.0, C0, alpha, beta, gamma, 1.0, 1.0]
                numpy2d_sm_input = np.array([[T_scaling], [B_scaling], [Tc0], [Bc20], [1.0], [C0], [alpha], [beta], [gamma], [1.0], [1.0]])

        elif self.material.lower() == 'nb3sn':
            # Getting the scaling parameters
            Ic_ref = float(self.Nb3Sn_scaling_parameters['Ic']) if 'Ic' in self.Nb3Sn_scaling_parameters.keys() else None
            T_scaling = float(self.Nb3Sn_scaling_parameters['T']) if 'T' in self.Nb3Sn_scaling_parameters.keys() else None
            B_scaling = float(self.Nb3Sn_scaling_parameters['B']) if 'B' in self.Nb3Sn_scaling_parameters.keys() else None
            e_scaling = float(self.Nb3Sn_scaling_parameters['e']) if 'e' in self.Nb3Sn_scaling_parameters.keys() else -0.003
            Tc0 = float(self.Nb3Sn_scaling_parameters['Tc0']) if 'Tc0' in self.Nb3Sn_scaling_parameters.keys() else 18.3
            Bc20 = float(self.Nb3Sn_scaling_parameters['Bc20']) if 'Bc20' in self.Nb3Sn_scaling_parameters.keys() else 28.7
            C0 = float(self.Nb3Sn_scaling_parameters['C0']) if 'C0' in self.Nb3Sn_scaling_parameters.keys() else 10500e6
            J0 = float(self.Nb3Sn_scaling_parameters['J0']) if 'J0' in self.Nb3Sn_scaling_parameters.keys() else 1. # Instead of C0 & e_scaling
            Alpha = float(self.Nb3Sn_scaling_parameters['Alpha']) if 'Alpha' in self.Nb3Sn_scaling_parameters.keys() else 1. # Instead of C0 & e_scaling
        
            if None in [Ic_ref, T_scaling, B_scaling]:
                logging.warning("WARNING: None found in Nb3Sn Jc scaling dictionary, no scaling is applied.")
            else:
                if self.Nb3Sn_fitname.lower() == 'summers':
                    sm_args = [J0, Tc0, Bc20]
                    numpy2d_sm_input =  np.array([[T_scaling], [B_scaling], [J0], [Tc0], [Bc20]])
                elif self.Nb3Sn_fitname.lower() == 'bordini':
                    sm_args = [C0, Tc0, Bc20, Alpha]
                    numpy2d_sm_input = np.array([[T_scaling], [B_scaling], [C0], [Tc0], [Bc20], [Alpha]])

        elif self.material.lower() == 'rebco':

            # Getting the scaling parameters
            Ic_ref = float(self.ReBCO_scaling_parameters['Ic_ref']) if 'Ic_ref' in self.ReBCO_scaling_parameters else None
            T_scaling = float(self.ReBCO_scaling_parameters['T_ref']) if 'T_ref' in self.ReBCO_scaling_parameters else None
            B_scaling = float(self.ReBCO_scaling_parameters['B_ref']) if 'B_ref' in self.ReBCO_scaling_parameters else None
            Deg = float(self.ReBCO_scaling_parameters['deg']) if 'deg' in self.ReBCO_scaling_parameters.keys() else 0.0
            if None in [Ic_ref, T_scaling, B_scaling, Deg]:
                logging.warning("WARNING: None found in ReBCO Jc scaling dictionary, no scaling is applied.")
            else:
                sm_args = [Deg]
                numpy2d_sm_input = np.array([T_scaling, B_scaling, Deg])

        # Initiating the steam material function.
        sm_sc_Ic = STEAM_materials(fitname)

        # Calculated the critical current scaling value:
        Ic = sm_sc_Ic.evaluate(numpy2d_sm_input)
        self.SC_Ic_Scaling = Ic_ref / Ic 

        # Preparing the temporary array. Stack the columns and transpose.
        stack = np.hstack((input_list, np.full((input_list.shape[0], len(sm_args)), sm_args))).T

        # Retrieving all critical current values for the interpolation function.
        Ic = STEAM_materials(fitname).evaluate(stack) * self.SC_Ic_Scaling

        # Replace nan's with zeros (needed for the NbTi fit occasionally):
        Ic = np.nan_to_num(Ic, nan=1e-9)

        # This is the fit that will be used for all types of superconductors.
        self.SC_Ic_Fit = RegularGridInterpolator((T, B), Ic.reshape((len(T), len(B))), bounds_error=False, fill_value=1e-9)

        # Testing
        self.plot_SC_Ic_fit()
        self.plot_x_fit()
        self.plot_material_properties()
        self.plot_conductor_properties()
        self.plot_R_conductor()

    def plot_material_properties(self):
        """
            Generates a plot of the material properties.
        """

        fig = plt.figure(figsize=(12,4))
        ax1 = fig.add_subplot(131, projection='3d') # Ax for the resistance
        ax2 = fig.add_subplot(132, projection='3d') # Ax for the thermal conductivity
        ax3 = fig.add_subplot(133, projection='3d') # Ax for the volumetric 

        # The input temperature array:
        T = np.linspace(2.0, 6.0, 100)

        # The magnetic field is set at 5 T.
        B = np.linspace(11.9, 12.1, 100)

        # Clipping B
        B = np.clip(B, self.B_min, 1000)

        # Making the mesh grid.
        xv, yv = np.meshgrid(T, B)

        for mat in self.all_mats:
            ax1.plot_surface(xv, yv, self.Normal_rho_FIT[mat]((xv, yv)), label=mat, alpha=0.5)
            ax2.plot_surface(xv, yv, self.Normal_k_FIT[mat]((xv, yv)), label=mat, alpha=0.5)
            ax3.plot_surface(xv, yv, self.Normal_Cv_FIT[mat]((xv, yv)), label=mat, alpha=0.5)

        ax1.set_xlabel('T [K]')
        ax1.set_ylabel('B [T]')
        ax1.set_zlabel('R [Ohm]')
        ax1.legend()
        ax2.set_xlabel('T [K]')
        ax2.set_ylabel('B [T]')
        ax2.set_zlabel('k [W/m/K]')
        ax2.legend()
        ax3.set_xlabel('T [K]')
        ax3.set_ylabel('B [T]')
        ax3.set_zlabel('Cv [J/K/m3]')
        ax3.legend()
        fig.savefig(self.specific_output_path + os.sep + 'material_properties.png', dpi=300)
        plt.close(fig)

    def plot_conductor_properties(self):
        """
            Generates a plot of the conductor properties.
        """
        ## First: we need to select either LTS or HTS
        if self.material.lower() in ['nbti', 'nb3sn']:
            T = np.linspace(2, 30, 100)
            B = np.linspace(0, 20, 100)
        elif self.material.lower() in ['rebco', 'ybco']:
            T = np.linspace(2, 100, 100)
            B = np.linspace(0, 50, 100)
        else:
            logging.info('WARNING: material not in the material list. R_conductor plot not generated.')

        # Clipping B
        B = np.clip(B, self.B_min, 1000)

        # A Surface plot for the conductor Resistance as function of T and B.
        xv, yv = np.meshgrid(T, B)
        Ic = self.R_fit((xv, yv))

        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.plot_surface(xv, yv, Ic)

        ax.set_xlabel('T [K]')
        ax.set_ylabel('B [T]')
        ax.set_zlabel('R [Ohm/m]') 
        # ax.view_init(elev=30, azim=45)
        fig.savefig(self.specific_output_path + os.sep + 'R_fit_new.png', dpi=300)
        plt.close(fig)

    def plot_R_conductor(self):
        """
            Generates a plot of the conductor resistance.
        """

        ## First: we need to select either LTS or HTS
        if self.material.lower() in ['nbti', 'nb3sn']:
            T = np.linspace(2, 30, 300)
            B = np.linspace(0, 20, 300)
        elif self.material.lower() in ['rebco', 'ybco']:
            T = np.linspace(2, 100, 300)
            B = np.linspace(0, 50, 300)
        else:
            logging.info('WARNING: material not in the material list. Ic plot not generated.')

        # Clipping B
        B = np.clip(B, self.B_min, 1000)

        # There should be a surface plot here.
        xv, yv = np.meshgrid(T, B)
        Ic = self.SC_Ic_Fit((xv, yv))

        # We take the operating current.
        I = self.Current
        IIc = I/Ic # Current to critical current ratio.

        # For U [V/m], which is I total * normal resistance, we take 1e-5.
        R = self.R_fit((xv, yv))
        U = R * I

        # Filling in the interpolation function
        x = self.SC_Cur_Sharing((IIc, U))

        R_conductor = R * (1-x)

        # Plotting
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.plot_surface(xv, yv, R_conductor)

        ax.set_xlabel('T [K]')
        ax.set_ylabel('B [T]')
        ax.set_zlabel('Conductor Resistance [Ohm / m]') 
        ax.view_init(elev=19, azim=-127)
        fig.savefig(self.specific_output_path + os.sep + 'R_conductor.png', dpi=300)
        plt.close(fig)

    def plot_SC_Ic_fit(self):
        """
            Generates a plot of the critical current interpolation function.
        """

        ## First: we need to select either LTS or HTS
        if self.material.lower() in ['nbti', 'nb3sn']:
            T = np.linspace(2, 30, 100)
            B = np.linspace(0, 20, 100)
        elif self.material.lower() in ['rebco', 'ybco']:
            T = np.linspace(2, 100, 100)
            B = np.linspace(0, 50, 100)
        else:
            logging.info('WARNING: material not in the material list. Ic plot not generated.')

        # Clipping B
        B = np.clip(B, self.B_min, 1000)

        # There should be a surface plot here.
        xv, yv = np.meshgrid(T, B)
        Ic = self.SC_Ic_Fit((xv, yv))

        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.plot_surface(xv, yv, Ic)

        ax.set_xlabel('T [K]')
        ax.set_ylabel('B [T]')
        ax.set_zlabel('Ic [A]') 
        ax.view_init(elev=30, azim=45)
        fig.savefig(self.specific_output_path + os.sep + 'Ic_fit_new.png', dpi=300)
        plt.close(fig)

    def plot_x_fit(self):
        """
            Generates a plot of the current sharing interpolation function.
        """

        ## First: we need to select either LTS or HTS
        if self.material.lower() in ['nbti', 'nb3sn']:
            T = np.linspace(2, 30, 100)
            B = np.linspace(0, 20, 100)
        elif self.material.lower() in ['rebco', 'ybco']:
            T = np.linspace(2, 100, 100)
            B = np.linspace(0, 50, 100)
        else:
            logging.info('WARNING: material not in the material list. Ic plot not generated.')

        # Clipping B
        B = np.clip(B, self.B_min, 1000)

        # There should be a surface plot here.
        xv, yv = np.meshgrid(T, B)
        Ic = self.SC_Ic_Fit((xv, yv))

        # We take the operating current.
        I = self.Current
        IIc = I/Ic # Current to critical current ratio.

        # For U [V/m], which is I total * normal resistance, we take 1e-5.
        U = np.ones(IIc.shape) * 1e-5

        # Filling in the interpolation function
        x = self.SC_Cur_Sharing((IIc, U))

        # Plotting
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.plot_surface(xv, yv, x)

        ax.set_xlabel('T [K]')
        ax.set_ylabel('B [T]')
        ax.set_zlabel('Current Sharing Coefficient [-]') 
        ax.view_init(elev=26, azim=41)
        fig.savefig(self.specific_output_path + os.sep + 'current_sharing_x.png', dpi=300)
        plt.close(fig)

    def calculate_NZPV(self):
        """Calculated the normal zone propagation velocity using two reference points.

        No inputs as is uses all stored data in the class.

        """
        try:
            pos1 = nearest_index(self.center_points, self.Posref[0] * self.busbar_length)
            pos2 = nearest_index(self.center_points, self.Posref[1] * self.busbar_length)
            distance = (self.center_points[pos2]-self.center_points[pos1])

            time1 = self.NZPV_array[pos1]
            time2 = self.NZPV_array[pos2]
            self.NZPV_proped = distance/(time2-time1) if (time2-time1) > 0 else 0.0
        except:
            self.NZPV_proped = 0.0

        logging.info("NZPV (m/s):" + str(self.NZPV_proped))

        if self.summary_output:
            try:
                with open(self.file_summary, 'a+') as f:
                    data = [str(self.Current), str(self.NZPV_proped)]
                    f.write(self.delimiter.join(data) + '\n')
            except OSError:
                logging.info("Writing on %s has failed." % self.file_summary)


    def normalisation_areas(self):
        # Pre-compute normalisation areas once
        if self.conductor_area is not None:
            self._A_rho = sum(v for k, v in self.conductor_area.items() if k.lower() not in self._SKIP_RHO)
            self._A_SC = sum(v for k, v in self.conductor_area.items() if k.lower() in self._NO_SKIP_SC)
            self._A_k = sum(v for k, v in self.conductor_area.items() if k.lower() not in self._SKIP_K)
            self._A_cv  = sum(v for k, v in self.conductor_area.items() if k.lower() not in self._SKIP_CV)
            self._A_cv_all = sum(v for k, v in self.conductor_area.items() if k.lower() not in self._SKIP_CV_ALL)

    def get_power(self, t, max_T = 0.0):
        if self.Heating_mode == 'time':
            return self.Power * (1-self.sig(t-self.Heating_time, self.Heating_sig_C))
        elif self.Heating_mode == 'constant':
            return self.Power  * (1-self.sig(max_T-self.Heat_until, self.Heating_sig_C))
        elif self.Heating_mode == 'exponential':
            return self.Power * np.exp(-t/self.Heating_time_constant)
        else:
            return 0.0

    def mat_props(self, T, prop, mat, I=0):
        """Calculate material properties.

        Args:
            T:    Temperature array [K]
            prop: Property type ('k', 'Cv', 'rho', 'Jc')
            mat:  Material type ('insulation', 'conductor', 'superconductor')
            I:    Current [A]

        Returns:
            1-D array of material property values.
        """
        begin = time.time()

        T_2d = np.where(T < 1.9, 1.9, T).reshape(1, -1)

        if mat == 'insulation':
            area_dict = {self.insulation_material: 1.0}
            B_2d = np.zeros(T_2d.shape)
        else:
            area_dict = self.conductor_area
            B_raw = self.B0 + np.ones(self.sections) * self.Self_Field * I
            B_2d  = B_raw.reshape(1, -1)

        if prop == 'rho':
            out = resistivity( T_2d, B_2d, area_dict)
        elif prop == 'k':
            out = conductivity(T_2d, B_2d, area_dict)
        elif prop == 'Cv':
            out = heat_capacity(T_2d, B_2d, area_dict)
        elif prop == 'Jc' and mat == 'superconductor':
            B_eff = (self.B0 + np.ones(self.sections) * self.Self_Field * I).reshape(1, -1)
            numpy2d = np.vstack((T_2d, abs(B_eff)))
            sm  = STEAM_materials('CFUN_JcNbTiLowCurrent_v1', numpy2d.shape[0], numpy2d.shape[1])
            out = sm.evaluate(numpy2d)
        else:
            out = np.zeros(T_2d.shape)
        return out.flatten()

    @staticmethod
    def sig(x1, c = 100.0):
        """Sigmoidal function for 0 to 1, used to smoothen some hard transitions.
        
        Numerically stable implementation that avoids overflow for large c values.

        Args:
            x1: x-position, transition at 0.
            c: size of the transition [100]

        Output: A value between 0 and 1.

        """
        # Numerically stable sigmoid implementation
        # For large positive c*x1: exp(-c*x1) ≈ 0, so sigmoid ≈ 1
        # For large negative c*x1: exp(-c*x1) would overflow, so we use the identity:
        # sigmoid(x) = exp(x) / (1 + exp(x)) when x >= 0
        # sigmoid(x) = 1 / (1 + exp(-x)) when x < 0
        
        z = np.clip(c * x1, -20, 20)
        # Use the numerically stable form based on the sign of z
        return 1 / (1 + np.exp(-z))

    def solve_adiabatic(self, t: float, X: np.ndarray) -> np.ndarray:
        """ODE for a single adiabatic conductor element — temperature estimate.

        Models one isolated element with:
          - No cooling (adiabatic boundary condition)
          - No heat conduction to neighbours
          - Full Joule heating driven by I(t) from the main simulation
          - Fully resistive (x = 0): the entire current flows through the
            stabiliser resistance, giving the maximum possible dissipation

        Because every joule of resistive heating stays in the element, this gives
        an upper bound on the temperature rise compared to the full spatial simulation.

        Must be called after start() via run_adiabatic_simulation(), which builds
        the current interpolant self._adiabatic_current_interp.

        Args:
            t: current time [s]
            X: state vector with a single temperature [K]

        Returns:
            dTdt: np.ndarray([dT/dt]) in [K/s]
        """
        T_val = np.clip(float(X[0]), None, MAXIMUM_TEMPERATURE)

        # Current and B_field at this time, interpolated from the main simulation result.
        I = float(self._adiabatic_current_interp(t))
        B = float(self._adiabatic_bfield_interp(t))

        # Electrical resistivity of the stabiliser at T [Ohm*m].
        T_2d = np.array([[max(T_val, 1.9)]])
        B_2d = np.ones((1, 1))*B
        rho = resistivity(T_2d, B_2d, self.conductor_area)[0, 0]

        # Resistance of this element: R = rho / A_rho  [Ohm]
        # A_rho matches resistivity()'s normalisation: normal conductors only.
        R = rho / self._A_rho

        # Joule heating power [W]. The strand is fully resistive (x = 0),
        # so all of the current dissipates as heat.
        Q_joule = I**2 * R

        # Volumetric heat capacity [J/(m^3*K)].
        # A_cv matches heat_capacity()'s normalisation: includes NbTi/Nb3Sn volume.
        Cv = heat_capacity(T_2d, B_2d, self.conductor_area)[0, 0]

        # Heat equation (adiabatic): dT/dt = Q / (Cv * A_cv)
        dTdt = Q_joule / (Cv * self._A_cv)

        return np.array([dTdt])

    def run_adiabatic_simulation(self) -> None:
        """Run an adiabatic single-element simulation using the main current profile.

        This is a post-processing step that provides a upper bound on
        temperature rise: one isolated element, no cooling, no conduction. Any
        element in the real simulation will be cooler than this because heat
        always spreads to neighbours and/or the helium bath.

        The current profile I(t) is taken directly from the main simulation
        results (self.t, self.I) via a linear interpolant, so this method must
        be called after start().

        The same ODE integrator settings (rtol, atol, min_step, max_timestep)
        as the main simulation are reused for consistency.

        Results:
            self.t_adiabatic: np.ndarray — time points [s]
            self.T_adiabatic: np.ndarray — element temperature [K]
        """
        logging.info("Running adiabatic single-element simulation...")

        # Build a piecewise-linear interpolant for I(t).
        # Outside the simulated range, current is clamped to the boundary value
        # (constant before t[0] and after t[-1]).
        self._adiabatic_current_interp = interp1d(
            self.t, self.I,
            kind='linear',
            bounds_error=False,
            fill_value=(self.I[0], self.I[-1]),
        )

        self._adiabatic_bfield_interp = interp1d(
            self.t, self.B,
            kind='linear',
            bounds_error=False,
            fill_value=(self.I[0], self.I[-1]),
        )

        # Start the element at the helium bath temperature T1.
        T0 = np.array([self.T1])
        t_start = float(self.t[0])

        # Use the same BDF integrator as the main simulation for consistency.
        solver = scipy.integrate.ode(self.solve_adiabatic).set_integrator(
            'vode', method='bdf',
            min_step=1.0e-20,
            rtol=self.rtol,
            atol=self.atol,
            nsteps=int(1e9),
            order=15,
        )
        solver.set_initial_value(T0, t_start)

        t_list: list = [t_start]
        T_list: list = [float(T0[0])]

        # Step to exactly each time point of the main simulation so that
        # t_adiabatic == self.t with no interpolation needed later.
        # The VODE integrator still uses its internal adaptive stepping for
        # accuracy; we only control which times it reports output at.
        for t_target in self.t[1:]:
            if not solver.successful() or T_list[-1] >= MAXIMUM_TEMPERATURE:
                break
            solver.integrate(float(t_target))
            t_list.append(float(solver.t))
            T_list.append(float(solver.y[0]))

        self.t_adiabatic = np.array(t_list)
        self.T_adiabatic = np.array(T_list)

        logging.info(
            f"Adiabatic simulation complete. "
            f"T_max_adiabatic = {np.max(self.T_adiabatic):.1f} K"
        )

        # Second adiabatic simulation starting at t_start_adiabatic (when x first < 0.5).
        if self.t_start_adiabatic is not None:
            logging.info("Running adiabatic simulation starting at x=0.5...")
            t_arr = np.array(self.t)
            idx_x05 = int(np.searchsorted(t_arr, float(self.t_start_adiabatic)))
            t_start_x05 = float(t_arr[idx_x05])
            T0_x05 = np.array([self.T1])

            solver_x05 = scipy.integrate.ode(self.solve_adiabatic).set_integrator(
                'vode', method='bdf',
                min_step=1.0e-20,
                rtol=self.rtol,
                atol=self.atol,
                nsteps=int(1e9),
                order=15,
            )
            solver_x05.set_initial_value(T0_x05, t_start_x05)

            t_list_x05: list = [t_start_x05]
            T_list_x05: list = [float(T0_x05[0])]

            for t_target in self.t[idx_x05 + 1:]:
                if not solver_x05.successful() or T_list_x05[-1] >= MAXIMUM_TEMPERATURE:
                    break
                solver_x05.integrate(float(t_target))
                t_list_x05.append(float(solver_x05.t))
                T_list_x05.append(float(solver_x05.y[0]))

            self.t_adiabatic_x05 = np.array(t_list_x05)
            self.T_adiabatic_x05 = np.array(T_list_x05)
            I_x05 = np.array(self.I)[idx_x05:idx_x05 + len(t_list_x05)]
            I_sq_avg_x05 = 0.5 * (I_x05[:-1]**2 + I_x05[1:]**2)
            self.MIIT_adiabatic_x05 = np.concatenate(
                [[0.0], np.cumsum(I_sq_avg_x05 * np.diff(self.t_adiabatic_x05))]
            )
            logging.info(
                f"Adiabatic (x=0.5) simulation complete. "
                f"T_max = {np.max(self.T_adiabatic_x05):.1f} K"
            )

    def append_adiabatic_to_main_csv(self) -> None:
        """Rewrite file_main with T_adiabatic added as the last column.

        Because run_adiabatic_simulation() steps to exactly the same time
        points as the main simulation (self.t), the lookup is a simple
        nearest-neighbour match — in practice the times are identical.

        The column is appended in-place: the existing file is read, updated,
        and written back.
        """
        if not self.main_output:
            return
        if not os.path.exists(self.file_main):
            logging.info("file_main not found; skipping adiabatic CSV append.")
            return

        with open(self.file_main, 'r') as f:
            lines = f.readlines()

        has_x05 = len(self.T_adiabatic_x05) > 0

        updated_lines = []
        for line in lines:
            parts = line.strip().split(self.delimiter)
            try:
                t_val = float(parts[0])
            except ValueError:
                # Header row — append column names and continue.
                parts.append('T_adiabatic [K]')
                if has_x05:
                    parts.append('T_adiabatic_x05 [K]')
                    parts.append('MIIT_adiabatic_x05 [A2s]')
                updated_lines.append(self.delimiter.join(parts) + '\n')
                continue
            # Find the index in t_adiabatic closest to this row's time.
            # Since time steps are forced to match, this is exact in practice.
            idx = int(np.argmin(np.abs(self.t_adiabatic - t_val)))
            parts.append(str(self.T_adiabatic[idx]))
            if has_x05:
                # Only available for times >= t_start_adiabatic; use '' before that.
                if t_val >= self.t_adiabatic_x05[0]:
                    idx_x05 = int(np.argmin(np.abs(self.t_adiabatic_x05 - t_val)))
                    parts.append(str(self.T_adiabatic_x05[idx_x05]))
                    parts.append(str(self.MIIT_adiabatic_x05[idx_x05]))
                else:
                    parts.append('')
                    parts.append('')
            updated_lines.append(self.delimiter.join(parts) + '\n')

        with open(self.file_main, 'w') as f:
            f.writelines(updated_lines)

        logging.info("Appended T_adiabatic column to %s." % self.file_main)

    def compute_T_vs_MIIT(
        self,
        B: float = None,
        T_init: float = None,
        T_max: float = 300.0,
    ) -> tuple:
        """Compute the expected temperature as a function of MIIT (adiabatic).

        Integrates the material-property ODE:

            dT/d(MIIT) = rho(T, B) / (sum(conductor_area)² * Cv(T, B))

        from *T_init* to *T_max*.  This gives a reference curve for the
        expected hot-spot temperature as a function of the heat-load integral
        MIIT = ∫I²dt [A²s], fully independent of any particular current
        profile.

        The derivation follows directly from ``solve_adiabatic``:
          A        = sum(conductor_area.values())
          R        = rho * L / A
          dT/dt    = I² * R / (Cv * A * L)
                   = I² * rho / (A² * Cv)
          d(MIIT)/dt = I²
          ⟹  dT/d(MIIT) = rho / (A² * Cv)

        Only available when *conductor_area* is defined (enables full
        multi-material property calculations via ``materials.py``).

        Args:
            B:      Magnetic field [T] at which material properties are
                    evaluated.
            T_init: Starting temperature [K].  Defaults to ``self.T1``.
            T_max:  Temperature [K] at which to stop integration. Default 300 K.

        Returns:
            (MIIT_curve, T_miit_curve): 1-D arrays of MIIT [MA²s] and
            temperature [K].  Also stored as ``self.MIIT_curve`` and
            ``self.T_miit_curve``.  Returns empty arrays if prerequisites
            are not met.
        """
        if self.conductor_area is None:
            logging.warning("compute_T_vs_MIIT: conductor_area not defined, skipping.")
            return np.array([]), np.array([])

        I0 = float(self.Current)

        if B is None:
            B = float(np.max(self.B0_init+I0*self.Self_Field))

        if T_init is None:
            T_init = float(self.T1) if self.T1 is not None else 1.9

        B_val   = abs(float(B))

        # materials.py normalizes rho and Cv to the non-void conductor area.
        # The ODE must use the same area so that R = rho_eff * L / A_conductor
        # and C = Cv_eff * A_conductor * L are consistent.

        print(f"[T vs MIIT] Current: {I0:.2f} A (constant), B-Field: {B_val:.2f} T (constant)")
        print(f"[T vs MIIT] Conductor areas:")
        print(f"[T vs MIIT] A_rho (used in ODE): {self._A_rho:.6e} m²")
        print(f"[T vs MIIT] A_cv (used in ODE): {self._A_cv:.6e} m²")

        def dTdt(t, y):
            T_val = max(float(y[0]), MINIMUM_TEMPERATURE)
            T_2d  = np.array([[T_val]])
            B_2d  = np.array([[B_val]])
            rho = resistivity(T_2d, B_2d, self.conductor_area)[0, 0]
            Cv  = max(heat_capacity(T_2d, B_2d, self.conductor_area)[0, 0], HEAT_CAPACITY_MIN)
            return [I0**2 * rho / (self._A_rho * self._A_cv * Cv)]

        def T_reached_max(t, y):
            return y[0] - T_max
        T_reached_max.terminal  = True
        T_reached_max.direction = 1

        logging.info(
            f"Computing T vs MIIT curve: T_init={T_init:.2f} K, "
            f"T_max={T_max:.1f} K, B={B_val:.2f} T"
        )
        result = scipy.integrate.solve_ivp(
            dTdt,
            [0.0, 1e6],
            [float(T_init)],
            method='RK45',
            rtol=DEFAULT_RTOL,
            atol=DEFAULT_ATOL,
            events=T_reached_max,
            dense_output=False,
        )

        t_arr   = result.t
        T_arr   = result.y[0]
        # Cumulative MIIT = ∫I²dt = I0² * t  (constant current)
        miit_arr = I0**2 * t_arr

        self.T_miit_curve  = T_arr
        self.MIIT_curve    = miit_arr / 1e6  # A²s → MA²s

        logging.info(
            f"T vs MIIT curve complete: T_final = {self.T_miit_curve[-1]:.1f} K "
            f"at MIIT = {self.MIIT_curve[-1]:.4f} MA\u00b2s"
        )

        if self.main_output and self.specific_output_path:
            miit_csv = self.specific_output_path + os.sep + 'T_vs_MIIT.csv'
            with open(miit_csv, 'w') as f:
                f.write('MIIT [MA2s],T [K]\n')
                for m, t_val in zip(self.MIIT_curve, self.T_miit_curve):
                    f.write(f'{m},{t_val}\n')
            logging.info(f"T vs MIIT curve saved to {miit_csv}")

            self.fig_t_miit = plt.figure(figsize=(6, 4))
            self.ax_t_miit = self.fig_t_miit.add_subplot(111)
            self.ax_t_miit.plot(self.T_miit_curve, self.MIIT_curve,
                                label='Reference (pre-computed, constant I and B)')
            self.ax_t_miit.set_xlabel('Temperature, K')
            self.ax_t_miit.set_ylabel('MIIT, MA\u00b2s')
            self.ax_t_miit.set_title('Expected T vs MIIT (adiabatic)')
            self.ax_t_miit.set_xlim(float(T_init), 300.0)
            self.fig_t_miit.tight_layout()
            self.fig_t_miit.savefig(
                self.specific_output_path + os.sep + 'T_vs_MIIT.png', dpi=300
            )
            logging.info("T vs MIIT figure saved (pre-simulation).")

        return self.MIIT_curve, self.T_miit_curve

    def solve_this_v2(self, t, X):
        """ This function provides the dT/dt's of the system.
        These values will then be integrated by scipy's ode solver.

        This is version 2, which is more general for any kind of conductor.

        Args:
            t: time in seconds
            X: Temperatures and current value.

        Output: dT/dt

        """

        ## Generating the output array (b) based on the shape of X.
        b = np.zeros(X.shape)

        ## Temperatures are split into sections.
        T = (np.array(split_temperature_array(X[:-1], self.sections, self.layers))) 

        # The difference between temperatures.
        dT = np.diff(T[0])

        ## Generating an array full of zeros. # TODO this one is made every time and should only be made once and then copied.
        Q = np.array([np.zeros((T[i].shape[0])) for i in range(len(T))])  	# Empty heat balance array

        ## An external current can be used in case we want to used measured data.
        if self.external_current_bool and self.Detected:
            I = self.external_current_fit(t - self.Detection_Time)
        else:
            I = X[-1]  # Getting the current

        ## Ramps down the background magnetic field if the current is ramped down.
        sf = self.Self_Field * I
        if self.B0_float:
            self.B0 = np.ones((self.sections, )) * (self.B0_init) * I / self.Current if self.B0_dump else np.ones((self.sections, )) * self.B0_init
        else:
            self.B0 = (self.B0_init) * I / self.Current if self.B0_dump else self.B0_init
        B = np.clip(self.B0 + sf, self.B_min, None)

        # Section length needed to scale the heating power and Resistance, the R was in Ohm/m --> R * L = Ohm.
        L = self.section_lengths

        T_2d = np.where(T[0] < 1.9, 1.9, T[0]).reshape(1, -1)
        B_2d = B.reshape(1, -1)

        ## Adding heat to the conductor.
        for i in self.Heating_nodes:
            # Power in W/m to W for individual sections.
            Q[0][i] += self.get_power(t, np.max(T)) * L[i]         # Initializing the hot-spot by heating nodes

        ## Calculate thermal conductivity using material property functions
        # k normalised to A_k; thermal resistance from node centre to boundary = L/(2*k*A_k)
        k = conductivity(T_2d, B_2d, self.conductor_area).flatten()
        R_thermal = L / (2 * k * self._A_k)                          # 1) Thermal resistance centre-to-boundary [K/W]
        R_between_centers = R_thermal[0:-1] + R_thermal[1:]    # 2) Thermal resistance between adjacent nodes
        Qcon = np.asarray(dT, dtype=np.float64) / np.asarray(R_between_centers, dtype=np.float64)  # 3) Heat flow [W]
        Q[0][0:-1] += Qcon                                      # 4a) Filling Q, W
        Q[0][1:]   -= Qcon                                      # 4b) Filling Q, W

        ## Calculate thermal conduction in the radial direction through insulation.
        # Follows the same harmonic-mean conductance formula as solve_this:
        #   Q = 2*k1*k2/(k1+k2) * A/L * dT
        # where A is the interface area and L is the effective half-length.
        if self.layers > 0:
            # k (conductor) is already computed above via conductivity().
            k_insulation = []
            for i in range(self.layers):
                T_ins_2d = np.where(T[i + 1] < 1.9, 1.9, T[i + 1]).reshape(1, -1)
                B_ins_2d = np.zeros(T_ins_2d.shape)
                k_ins = conductivity(T_ins_2d, B_ins_2d, {self.insulation_material: 1.0}).flatten()
                k_insulation.append(k_ins)
                k_prev = k if i == 0 else k_insulation[i - 1]
                kk  = k_prev * k_ins
                k_k = k_prev + k_ins
                dT_rad   = T[i + 1] - T[i]
                Qcon_rad = (2 * kk / k_k * self.A_insulation[i] / self.L_insulation[i]
                            * dT_rad)
                Q[i]     += Qcon_rad
                Q[i + 1] -= Qcon_rad

        ## Ohmic heating
        Ic = np.clip(self.SC_Ic_Fit((T[0], B)), 1e-9, None)                         # 1) Calculating the critical current.
        rho = resistivity(T_2d, B_2d, self.conductor_area).flatten()
        R = rho / self._A_rho                                                             # 2) Normal-state resistance per unit length [Ω/m], normalised to normal-conductor area only.
        U = np.clip(I * R, self.lut_limits['U_min'], self.lut_limits['U_max'])      # 3) Calculating the normal conducting U at full current.
        IIc = np.clip(I/Ic, self.lut_limits['IIc_min'], self.lut_limits['IIc_max']) # 4) Calculating I divided by Ic.
        x = self.SC_Cur_Sharing((IIc, U))                                           # 5) Getting the current sharing coefficent x.

        # 5) One newton iteration, this make the value for x more accurate.
        err = powerlaw_v2(x, IIc, U, self.n_value)
        x -= err / powerlaw_jac_v2(x, IIc, U, self.n_value)

        P = I**2 * R * (1-x) * L                    # 5) Power generated in the stabilizer, so if x = 1 in SC state --> P = 0
        Q[0] += np.asarray(P, dtype=np.float64)     # 6) Adding the power to the Q array.

        # Helium cooling on the outermost surface.
        if self.Helium_cooling:
            h = self.cooling_calculator.helium_II(T[0]) if self.T1 <= 2.2 else self.cooling_calculator.helium_I(T[0])
            if self.layers == 0:
                # No insulation: coolant contacts the conductor directly.
                Q[0] -= h * self.cooled_perimeter * L * (T[0] - self.T1)
            else:
                # Coolant contacts the outer insulation layer.
                k_outer = k_insulation[-1]
                Q[-1] -= (
                    (h * self.A_insulation[-1] * k_outer)
                    / (0.5 * self.L_insulation[-1] * h + k_outer)
                    * (T[-1] - self.T1)
                )

        ## Calculating dTdt

        # 1) Volumetric heat capacity of the conductor.
        # heat_capacity() normalises to A_cv which includes NbTi/Nb3Sn — their volume stores heat.
        Cv_conductor = heat_capacity(T_2d, B_2d, self.conductor_area).flatten()

        # 2) dT/dt of the conductor.
        dTdt = Q[0] / (Cv_conductor * self._A_cv * L)

        # 3) dT/dt of each insulation layer.
        dTdt_insulation = []
        for i in range(self.layers):
            T_ins_2d = np.where(T[i + 1] < 1.9, 1.9, T[i + 1]).reshape(1, -1)
            B_ins_2d = np.zeros(T_ins_2d.shape)
            Cv_ins = heat_capacity(T_ins_2d, B_ins_2d, {self.insulation_material: 1.0}).flatten()
            dTdt_insulation.append(Q[i + 1] / (Cv_ins * self.V_insulation[i]))

        ## Calculating the dI/dt.
        if self.external_current_bool and self.Detected:
            dIdt = 0.0
        elif self.Detected == False or t < (self.Detection_Time + self.Protection_Delay):
            dIdt = 0.0
        else:
            if self.decay == 'exponential':
                dIdt = - I / (self.Inductance / (self.DumpR + np.sum(R * (1-x) * L)*self.symmetry_factor))
            elif self.decay == 'constant' and I > 0.0:
                dIdt = - self.decay_rate
            elif self.decay == 'no_load_fast':
                dIdt = - I / 0.001
            else:
                dIdt = 0.0

        # Filling the output array:
        b[0:self.sections] = dTdt[0:self.sections]
        for i in range(self.layers):
            b[self.sections * (i + 1):self.sections * (i + 2)] = dTdt_insulation[i]
        b[-1] = dIdt

        return b

    def start(self):
        
        # Starts the integrator
        n_every = 0
        s_every = 0

        # Resetting the result arrays.
        self.t = []
        self.I = []
        self.Tmax = []
        self.T_array = []
        self.V_array = []
        self.Vtot = []
        self.Ptot = []
        self.Pheater = []
        self.NZPV_array = np.zeros(self.sections)
        self.MIIT = 0.0  # Running integral of I^2 dt [A^2 s]

        # Initial conditions:
        x0 = np.append(np.ones(((self.layers+1)*self.sections, )) * self.T1, self.Current)
        y_prev = x0.copy() # Copying the input to use for the adaptive time stepper.

        # Calculate the initial state.
        X = x0
        T = X[:-1]
        I = self.get_current_from_state(0.0, X)
        B = self.get_B_from_I(I)
        V, Vsum, x = self.get_V_from_state(X, B)
        Ptot, Pheater = self.get_power_from_state(0.0, X, V)

        # Store the initial state (t=0) before the integration loop starts.
        self.t.append(0.0)
        self.T_array.append(T)
        self.I.append(I)
        self.B.append(np.max(B))
        self.V_array.append(V)
        self.Vtot.append(Vsum)
        self.Tmax.append(np.max(T))
        self.Ptot.append(Ptot)
        self.Pheater.append(Pheater)
        self.store_results(T, V)

        # Setting up of the solver
        self.results = scipy.integrate.ode(self.solve_this_v2).set_integrator('vode', method='bdf', min_step=self.min_step, max_step=self.max_step, rtol=self.rtol, atol=self.atol, nsteps=int(1e9), order=15)
        self.results.set_initial_value(x0, 0.0)
        while self.results.successful() and self.results.t < self.t0[1] and np.max(T[:-1]) < 1000.0:
            self.results.integrate(self.results.t+self.dt)

            # Getting Values
            X = self.results.y
            T = X[:-1]
            I = self.get_current_from_state(self.results.t, X)
            B = self.get_B_from_I(I)
            V, Vsum, x = self.get_V_from_state(X, B)
            Ptot, Pheater = self.get_power_from_state(self.results.t, X, V)

            # Appending values
            self.t.append(self.results.t)
            self.T_array.append(T)
            self.I.append(I)
            self.B.append(np.max(B))
            self.V_array.append(V)
            self.Vtot.append(Vsum)
            self.Tmax.append(np.max(T))
            self.Ptot.append(Ptot)
            self.Pheater.append(Pheater)
            self.NZPV_array = np.where((self.NZPV_array == 0.0) & (split_temperature_array(T, self.sections, self.layers)[0] > self.Tref), self.t[-1], self.NZPV_array)

            if np.mod(n_every, self.print_every) == 0:
                # Use improved output formatting
                output_msg = self._format_solver_output(
                    time_val=self.results.t,
                    temperature_array=T,
                    current=I,
                    voltage_sum=Vsum,
                    magnetic_field=B,
                    current_sharing=x,
                    timestep=self.dt,
                    cross_sectional_area=self._A_rho
                )
                logging.info(output_msg)
            n_every += 1

            # Protection
            if Vsum > self.Detection_Voltage and self.Detected == False and self.protection==True:
                self.Detection_Time = self.t[-1] + self.Validation_Delay
                self.Detected = True
                print('*** Quench Detected ***')

            # Storing and Plotting
            if np.mod(s_every, self.store_every) == 0:
                self.store_results(T, V)
            s_every += 1

            if min(x) < 0.5 and self.t_start_adiabatic is None:
                self.t_start_adiabatic = self.results.t


            self.dt = self.adaptive_timestep_controller(self.results.t, X, y_prev, self.dt, fixed_rules=self.time_step_rules, dt_min = self.min_timestep, dt_max = self.max_timestep)
            y_prev = X
        self.store_results(T, V) # Stores last result.

    def get_current_from_state(self, t, X):
        # Helper to get current from the ODE results
        if self.external_current_bool and self.Detected:
            I = self.external_current_fit(t - self.Detection_Time)
        else:
            I = X[-1]
        return I

    def get_B_from_I(self, I=0):
        # Helper to calculate the magnetic field from a current.
        # B = (self.B0 + np.ones((self.sections,)) * self.Self_Field * I).reshape(self.ones.shape)
        SF = self.Self_Field * I
        if self.B0_float:
            B = np.ones((self.sections,)) * self.B0_init * I / self.Current if self.B0_dump else np.ones((self.sections,)) * self.B0_init
        else:
            B = self.B0_init * I / self.Current if self.B0_dump else self.B0_init
        return B + SF

    def get_V_from_state(self, X, B):
        T = X[:-1]
        I = X[-1]
        T_split = split_temperature_array(T, self.sections, self.layers)
        Ic = np.clip(self.SC_Ic_Fit((T_split[0], B)), 1e-9, None)  # 1) Calculating the critical current.
        R = self.R_fit((T_split[0], B))  # 2) Calculating the normal conducting resistance.
        U = np.clip(I * R, self.lut_limits['U_min'], self.lut_limits['U_max'])  # 3) Calculating the normal conducting U at full current.
        IIc = np.clip(I / Ic, self.lut_limits['IIc_min'], self.lut_limits['IIc_max'])  # 4) Calculating I divided by Ic.
        x = self.SC_Cur_Sharing((IIc, U))
        V = I * (1 - x) * R * self.section_lengths
        Vsum = self.symmetry_factor * np.sum(V)
        return V, Vsum, x

    def get_power_from_state(self, t, X, V):
        Ptot = np.sum(V * X[-1])
        T = X[:-1]
        Pheater = np.sum(self.section_lengths[self.Heating_nodes] * self.get_power(t, np.max(T)))
        return Ptot, Pheater

    def sampling_timestep(self):
        # Selects an appropriate time step
        dT = self.sampling_time_dT
        dt = self.t[-1] - self.t[-2]

        # Check maximum temperature based timestep
        dTdt = max(abs(self.T_array[-1] - self.T_array[-2]) / dt)
        T_ts = dT / dTdt

        # Taking the smallest of the two:
        sampling_ts = T_ts

        # Checking if the timestep is not too big
        if sampling_ts > self.max_timestep:
            sampling_ts = self.max_timestep
        elif sampling_ts < self.min_timestep:
            sampling_ts = self.min_timestep

        return sampling_ts

    def adaptive_timestep_controller(self, t, y, y_prev, dt_prev, 
                                 fixed_rules=None,
                                 dt_min=1e-6, dt_max=0.5,
                                 growth_limit=1.5,
                                 shrink_limit=0.5,
                                 sensitivity=0.1):
        """
        Compute the next time step based on result changes, with optional fixed intervals.

        Parameters
        ----------
        t : float
            Current simulation time.
        y, y_prev : array_like
            Current and previous solution states.
        dt_prev : float
            Previous timestep size.
        fixed_rules : list of tuples
            Each tuple is (t_min, t_max, dt_fixed) defining fixed dt in that time range.
        dt_min, dt_max : float
            Bounds for dt.
        growth_limit, shrink_limit : float
            Max factors by which dt can grow or shrink per step.
        sensitivity : float
            Controls how strongly dt responds to relative change in y.

        Returns
        -------
        float
            The next timestep size.
        """
        # If inside a fixed dt region, return that dt
        if fixed_rules:
            for rule in fixed_rules:
                # Accept tuples of 2 or 3 elements:
                # (t_min, t_max, dt_fixed) or (t_min, t_max)
                if len(rule) == 3:
                    t_min, t_max, dt_fixed = rule
                elif len(rule) == 2:
                    t_min, t_max = rule
                    dt_fixed = dt_prev  # reuse previous dt if not provided
                else:
                    raise ValueError(f"Invalid rule format: {rule}")

                if t_min <= t < t_max:
                    return dt_fixed

        # Estimate relative change magnitude
        y = np.asarray(y)
        y_prev = np.asarray(y_prev)
        # delta = np.linalg.norm(y - y_prev) / (np.linalg.norm(y_prev) + 1e-12)
        delta = np.max(np.abs(y - y_prev) / (np.abs(y_prev) + 1e-12))

        # Map large delta -> smaller dt, small delta -> larger dt
        # factor = 1.0 / (1.0 + sensitivity * delta)
        # dt_new = dt_prev * factor

        dt_new = sensitivity/(delta/dt_prev)

        # Limit how much dt can change per step
        dt_new = np.clip(dt_new, shrink_limit * dt_prev, growth_limit * dt_prev)

        # Enforce absolute dt bounds
        dt_new = np.clip(dt_new, dt_min, dt_max)

        return dt_new
    
    def _format_solver_output(
        self,
        time_val: float,
        temperature_array: np.ndarray,
        current: float,
        voltage_sum: float,
        magnetic_field: np.ndarray,
        current_sharing: np.ndarray,
        timestep: float,
        cross_sectional_area: float
    ) -> str:
        """
        Format solver output using the configured output formatter.
        
        Args:
            time_val: Current simulation time
            temperature_array: Array of temperatures
            current: Current value
            voltage_sum: Sum of voltages
            magnetic_field: Magnetic field array
            current_sharing: Current sharing array
            timestep: Current timestep
            
        Returns:
            str: Formatted output string
        """
        if self.output_format == 'multiline':
            return self.output_formatter.format_multiline_output(
                time_val=time_val,
                temperature_array=temperature_array,
                current=current,
                voltage_sum=voltage_sum,
                magnetic_field=magnetic_field,
                current_sharing=current_sharing,
                timestep=timestep,
                cross_sectional_area=cross_sectional_area
            )
        else:
            return self.output_formatter.format_solver_output(
                time_val=time_val,
                temperature_array=temperature_array,
                current=current,
                voltage_sum=voltage_sum,
                magnetic_field=magnetic_field,
                current_sharing=current_sharing,
                timestep=timestep,
                cross_sectional_area=cross_sectional_area
            )
    
    def set_output_options(self, verbosity: str = None, format_type: str = None, precision: dict = None) -> None:
        """
        Configure output formatting options.
        
        Args:
            verbosity: Output verbosity level ('minimal', 'normal', 'detailed')
            format_type: Output format ('single_line', 'multiline')
            precision: Dictionary of precision settings for different parameters
        """
        if verbosity is not None:
            self.output_verbosity = verbosity
            self.output_formatter.set_verbosity(verbosity)
        
        if format_type is not None:
            self.output_format = format_type
            
        if precision is not None:
            for param, prec in precision.items():
                self.output_formatter.set_precision(param, prec)

    def plot_results(self):
        if self.main_output:
            self.fig_results = plt.figure(figsize=(18, 8))
            self.ax1 = self.fig_results.add_subplot(241)
            self.ax2 = self.fig_results.add_subplot(242)
            self.ax3 = self.fig_results.add_subplot(243)
            self.ax4 = self.fig_results.add_subplot(244)
            self.ax5 = self.fig_results.add_subplot(245)
            self.ax6 = self.fig_results.add_subplot(246)
            self.ax9 = self.fig_results.add_subplot(247)
            self.ax10 = self.fig_results.add_subplot(248)

            self.ax1.set_xlabel('Position, m')
            self.ax1.set_ylabel('Temperature, K')

            self.ax2.set_xlabel('Time, s')
            self.ax2.set_ylabel('Current, A')

            self.ax3.set_xlabel('Position, m')
            self.ax3.set_ylabel('Voltage profiles, V')

            self.ax4.set_xlabel('Time, s')
            self.ax4.set_ylabel('Hot-Spot Temperature, K')

            self.ax5.set_xlabel('Time, s')
            self.ax5.set_ylabel('Total Voltage, V')

            self.ax6.set_xlabel('Time, s')
            self.ax6.set_ylabel('Heat Dissipation, W')

            self.ax9.set_xlabel('Time, s')
            self.ax9.set_ylabel('Dump Resistor Voltage, V')

            self.ax10.set_xlabel('Time, s')
            self.ax10.set_ylabel('Voltage Rate, V/s')

            self.x_plot = self.center_points

            self.plot_nr = 0
            lenT = len(self.T_array)
            index_plot = np.arange(lenT)[::int(np.ceil(lenT/50))]
            # self.color = cm.viridis(np.linspace(0, 1, len(self.T_array)))
            self.color = cm.viridis(np.linspace(0, 1, len(index_plot)))
            for i in range(len(index_plot)):
                self.ax1.plot(self.x_plot, split_temperature_array(self.T_array[index_plot[i]], self.sections, self.layers)[0], color=self.color[i])
                self.ax3.plot(self.x_plot, self.V_array[index_plot[i]].reshape(self.center_points.shape), color=self.color[i])
            self.ax2.plot(self.t, self.I)
            self.ax4.plot(self.t, self.Tmax, label='Hot-spot (simulated)')

            if len(self.T_adiabatic) > 0:
                self.ax4.plot(
                    self.t_adiabatic, self.T_adiabatic,
                    ls='--', color='red', label='Adiabatic',
                )
            if len(self.T_adiabatic_x05) > 0:
                self.ax4.plot(
                    self.t_adiabatic_x05, self.T_adiabatic_x05,
                    ls='--', color='orange', label='Adiabatic starting at x=0.5',
                )
            if len(self.T_adiabatic) > 0 or len(self.T_adiabatic_x05) > 0:
                self.ax4.legend(fontsize='small')
            self.ax5.plot(self.t, self.Vtot)
            self.ax6.plot(self.t, self.Ptot, label='Internal heat dissipation')
            self.ax6.plot(self.t, self.Pheater, label='External power')
            self.ax6.legend()
            self.ax9.plot(self.t, [self.I[i]*self.DumpR if self.t[i] > (self.Detection_Time+self.Protection_Delay) else 0.0 for i in range(len(self.t))])
            logging.info('Saving main results figure.')
            self.ax10.plot(self.t[1:], np.diff(self.Vtot)/np.diff(self.t))
            self.fig_results.savefig(self.specific_output_path + os.sep + 'main_results.png', dpi=300)

            if self.open_plots:
                plt.show()
            plt.close(self.fig_results)

        if self.NZPV_output:
            # NZPV
            self.fig_nzpv = plt.figure(figsize=(8, 5))
            self.ax7 = self.fig_nzpv.add_subplot(121)
            self.ax8 = self.fig_nzpv.add_subplot(122)

            self.ax7.set_xlabel('Position, section nr.')
            self.ax8.set_xlabel('Position, section nr.')

            self.ax7.set_ylabel('Time till T_ref, s')
            self.ax8.set_ylabel('NZPV, m/s')
            self.ax7.plot(self.NZPV_array)
            self.NZPV_array = np.where(self.NZPV_array == 0.0, np.inf, self.NZPV_array)
            self.ax8.plot((self.busbar_length / self.sections) / np.diff(self.NZPV_array))

            self.ax8.set_ylim((0, 200))
            logging.info('Saving NZPV figure.')
            self.fig_nzpv.savefig(self.specific_output_path + os.sep + 'NZPV.png', dpi=300)
            if self.open_plots:
                plt.show()
            plt.close(self.fig_nzpv)

        # MIIT: cumulative integral of I^2 over time [MA^2*s].
        # This is the standard quench-protection figure of merit that relates
        # directly to the energy deposited in the conductor's resistance.
        if self.main_output:
            t_arr = np.array(self.t)
            I_arr = np.array(self.I)

            # Trapezoidal rule: average I^2 over each interval times the interval width.
            I_sq_avg = 0.5 * (I_arr[:-1]**2 + I_arr[1:]**2)
            miit = np.concatenate([[0.0], np.cumsum(I_sq_avg * np.diff(t_arr))]) / 1e6

            has_T_miit = len(self.T_miit_curve) > 0 and len(self.MIIT_curve) > 0
            ncols = 2 if has_T_miit else 1
            self.fig_miit = plt.figure(figsize=(6 * ncols, 4))

            ax_miit = self.fig_miit.add_subplot(1, ncols, 1)
            ax_miit.plot(t_arr, miit)
            ax_miit.set_xlabel('Time, s')
            ax_miit.set_ylabel('MIIT, MA\u00b2s')
            ax_miit.set_title('Cumulative I\u00b2t')

            if has_T_miit:
                ax_T_miit = self.fig_miit.add_subplot(1, ncols, 2)
                ax_T_miit.plot(self.T_miit_curve, self.MIIT_curve)
                # Mark the MIIT reached in the simulation
                miit_final = miit[-1]
                if miit_final <= self.MIIT_curve[-1]:
                    T_at_sim_miit = np.interp(miit_final, self.MIIT_curve, self.T_miit_curve)  # MIIT_curve is monotone increasing
                    ax_T_miit.axhline(miit_final, color='red', ls='--', lw=0.8,
                                      label=f'Sim. MIIT = {miit_final:.3f} MA\u00b2s')
                    ax_T_miit.axvline(T_at_sim_miit, color='red', ls=':', lw=0.8,
                                      label=f'T = {T_at_sim_miit:.1f} K')
                    ax_T_miit.legend(fontsize='small')
                ax_T_miit.set_xlabel('Temperature, K')
                ax_T_miit.set_ylabel('MIIT, MA\u00b2s')
                ax_T_miit.set_xlim(self.T_miit_curve[0], 300.0)
                ax_T_miit.set_title('Expected T vs MIIT (adiabatic)')

            self.fig_miit.tight_layout()
            logging.info('Saving MIIT figure.')
            self.fig_miit.savefig(self.specific_output_path + os.sep + 'MIIT.png', dpi=300)
            if self.open_plots:
                plt.show()
            plt.close(self.fig_miit)

        # Update the T vs MIIT figure with simulation results and overwrite.
        if self.fig_t_miit is not None and self.ax_t_miit is not None and self.main_output:
            t_arr = np.array(self.t)
            I_arr = np.array(self.I)
            I_sq_avg = 0.5 * (I_arr[:-1]**2 + I_arr[1:]**2)
            miit_sim = np.concatenate([[0.0], np.cumsum(I_sq_avg * np.diff(t_arr))]) / 1e6

            # T_max (hot-spot) vs cumulative MIIT
            self.ax_t_miit.plot(self.Tmax, miit_sim,
                                label='Hot-spot (simulated)', color='tab:orange')

            # T_adiabatic vs cumulative MIIT (same time grid as main simulation,
            # but may be shorter if adiabatic sim stopped early at MAXIMUM_TEMPERATURE)
            if len(self.T_adiabatic) > 0:
                n_ad = len(self.T_adiabatic)
                self.ax_t_miit.plot(self.T_adiabatic, miit_sim[:n_ad],
                                    ls='--', color='red', label='Adiabatic (simulated)')

            if len(self.T_adiabatic_x05) > 0:
                self.ax_t_miit.plot(
                    self.T_adiabatic_x05,
                    self.MIIT_adiabatic_x05 / 1e6,
                    ls='--', color='orange', label='Adiabatic starting at x=0.5',
                )

            self.ax_t_miit.legend(fontsize='small')
            self.fig_t_miit.tight_layout()
            logging.info('Updating T vs MIIT figure with simulation results.')
            self.fig_t_miit.savefig(
                self.specific_output_path + os.sep + 'T_vs_MIIT.png', dpi=300
            )
            if self.open_plots:
                plt.show()
            plt.close(self.fig_t_miit)
            logging.info("T vs MIIT figure updated and saved.")

if __name__ == "__main__":
    print_logo()
    if len(sys.argv) > 3:
        print('Loading the provided yaml file: ' + sys.argv[1])
        if sys.argv[3] == 'Sweep':
            pybbq = pyBBQ(sys.argv[1], sys.argv[2], 'Sweep')
        elif sys.argv[3] == 'SweepFull':
            pybbq = pyBBQ(sys.argv[1], sys.argv[2], 'SweepFull')
        else:
            pybbq = pyBBQ(sys.argv[1], sys.argv[2])
    elif len(sys.argv) > 2:
        print('Loading the provided yaml file: ' + sys.argv[1])
        pybbq = pyBBQ(sys.argv[1], sys.argv[2])
    elif len(sys.argv) > 1:
        print('Loading the provided yaml file: ' + sys.argv[1])
        pybbq = pyBBQ(sys.argv[1])
    else:
        print('No input yaml file provided.')
