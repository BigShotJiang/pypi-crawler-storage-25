"""
Output formatting utilities for pyBBQ solver.

This module provides structured output formatting to improve readability,
maintainability, and performance of solver output logging.
"""

import logging
import numpy as np
from datetime import datetime
from typing import Dict, Any, Optional, List


class SolverOutputFormatter:
    """
    Handles formatted output for the pyBBQ solver with configurable verbosity levels.
    """
    
    def __init__(self, precision: Dict[str, int] = None, verbosity: str = 'normal'):
        """
        Initialize the output formatter.
        
        Args:
            precision: Dictionary specifying decimal places for different parameter types
            verbosity: Output verbosity level ('minimal', 'normal', 'detailed')
        """
        self.precision = precision or {
            'time': 4,
            'temperature': 3, 
            'current': 3,
            'voltage': 3,
            'magnetic_field': 3,
            'current_density': 3,
            'timestep': 6
        }
        self.verbosity = verbosity
        
        # Define output templates for different verbosity levels
        self.templates = {
            'minimal': self._get_minimal_template(),
            'normal': self._get_normal_template(),
            'detailed': self._get_detailed_template()
        }
    
    def _get_minimal_template(self) -> List[str]:
        """Get minimal output parameters."""
        return [
            'timestamp', 'time', 'temperature_max', 'current', 'voltage_total'
        ]
    
    def _get_normal_template(self) -> List[str]:
        """Get normal output parameters."""
        return [
            'timestamp', 'time', 'temperature_min', 'temperature_max', 
            'current', 'voltage_total', 'magnetic_field_max', 'timestep'
        ]
    
    def _get_detailed_template(self) -> List[str]:
        """Get detailed output parameters."""
        return [
            'timestamp', 'time', 'temperature_min', 'temperature_max',
            'current', 'voltage_total', 'magnetic_field_max', 'magnetic_field_min',
            'current_density_max', 'timestep'
        ]
    
    def format_solver_output(
        self,
        time_val: float,
        temperature_array: np.ndarray,
        current: float,
        voltage_sum: float,
        magnetic_field: np.ndarray,
        current_sharing: np.ndarray,
        timestep: float,
        cross_sectional_area: float
    ) -> str:
        """
        Format solver output with improved readability and structure.
        
        Args:
            time_val: Current simulation time
            temperature_array: Array of temperatures
            current: Current value
            voltage_sum: Sum of voltages
            magnetic_field: Magnetic field array
            current_sharing: Current sharing array
            timestep: Current timestep
            cross_sectional_area: Cross sectional area for current density calculation
            
        Returns:
            str: Formatted output string
        """
        # Calculate derived values
        params = self._calculate_parameters(
            time_val, temperature_array, current, voltage_sum,
            magnetic_field, current_sharing, timestep, cross_sectional_area
        )
        
        # Get template for current verbosity level
        template = self.templates[self.verbosity]
        
        # Format output based on template
        return self._format_output_string(params, template)
    
    def _calculate_parameters(
        self,
        time_val: float,
        temperature_array: np.ndarray,
        current: float,
        voltage_sum: float,
        magnetic_field: np.ndarray,
        current_sharing: np.ndarray,
        timestep: float,
        cross_sectional_area: float
    ) -> Dict[str, Any]:
        """Calculate all possible output parameters."""
        
        # Calculate current density (max value where current sharing is minimal)
        max_je = (1 - np.min(current_sharing)) * current / (cross_sectional_area * 1e6)
        
        return {
            'timestamp': datetime.now().strftime("%H:%M:%S"),
            'time': time_val,
            'temperature_min': np.min(temperature_array),
            'temperature_max': np.max(temperature_array),
            'current': current,
            'voltage_total': voltage_sum,
            'magnetic_field_max': np.max(magnetic_field),
            'magnetic_field_min': np.min(magnetic_field),
            'current_density_max': max_je,
            'timestep': timestep
        }
    
    def _format_output_string(self, params: Dict[str, Any], template: List[str]) -> str:
        """Format the output string based on template and parameters."""
        
        # Format individual components
        formatted_parts = []
        
        for param in template:
            if param == 'timestamp':
                formatted_parts.append(f"{params['timestamp']}")
            elif param == 'time':
                formatted_parts.append(f"t: {params['time']:.{self.precision['time']}f}s")
            elif param == 'temperature_min':
                formatted_parts.append(f"Tmin: {params['temperature_min']:.{self.precision['temperature']}f}K")
            elif param == 'temperature_max':
                formatted_parts.append(f"Tmax: {params['temperature_max']:.{self.precision['temperature']}f}K")
            elif param == 'current':
                formatted_parts.append(f"I: {params['current']:.{self.precision['current']}f}A")
            elif param == 'voltage_total':
                formatted_parts.append(f"V: {params['voltage_total']:.{self.precision['voltage']}f}V")
            elif param == 'magnetic_field_max':
                formatted_parts.append(f"Bmax: {params['magnetic_field_max']:.{self.precision['magnetic_field']}f}T")
            elif param == 'magnetic_field_min':
                formatted_parts.append(f"Bmin: {params['magnetic_field_min']:.{self.precision['magnetic_field']}f}T")
            elif param == 'current_density_max':
                formatted_parts.append(f"Je_max: {params['current_density_max']:.{self.precision['current_density']}f}A/mm²")
            elif param == 'timestep':
                formatted_parts.append(f"dt: {params['timestep']:.{self.precision['timestep']}f}s")
        
        return " || ".join(formatted_parts)
    
    def format_multiline_output(
        self,
        time_val: float,
        temperature_array: np.ndarray,
        current: float,
        voltage_sum: float,
        magnetic_field: np.ndarray,
        current_sharing: np.ndarray,
        timestep: float,
        cross_sectional_area: float
    ) -> str:
        """
        Format output in a multiline format for better readability.
        
        Returns:
            str: Multiline formatted output
        """
        params = self._calculate_parameters(
            time_val, temperature_array, current, voltage_sum,
            magnetic_field, current_sharing, timestep, cross_sectional_area
        )
        
        lines = [
            f"[{params['timestamp']}] Solver Status:",
            f"  Time: {params['time']:.{self.precision['time']}f} s",
            f"  Temperature: {params['temperature_min']:.{self.precision['temperature']}f} - {params['temperature_max']:.{self.precision['temperature']}f} K",
            f"  Current: {params['current']:.{self.precision['current']}f} A",
            f"  Voltage: {params['voltage_total']:.{self.precision['voltage']}f} V",
            f"  Magnetic Field: {params['magnetic_field_min']:.{self.precision['magnetic_field']}f} - {params['magnetic_field_max']:.{self.precision['magnetic_field']}f} T",
            f"  Max Current Density: {params['current_density_max']:.{self.precision['current_density']}f} A/mm²",
            f"  Timestep: {params['timestep']:.{self.precision['timestep']}f} s"
        ]
        
        return "\n".join(lines)
    
    def set_verbosity(self, verbosity: str) -> None:
        """Change the verbosity level."""
        if verbosity in self.templates:
            self.verbosity = verbosity
        else:
            raise ValueError(f"Invalid verbosity level: {verbosity}. Must be one of {list(self.templates.keys())}")
    
    def set_precision(self, parameter: str, precision: int) -> None:
        """Set precision for a specific parameter."""
        if parameter in self.precision:
            self.precision[parameter] = precision
        else:
            raise ValueError(f"Unknown parameter: {parameter}. Available parameters: {list(self.precision.keys())}")


class ProgressTracker:
    """
    Track and display simulation progress with estimated completion time.
    """
    
    def __init__(self, total_time: float, update_interval: int = 10):
        """
        Initialize progress tracker.
        
        Args:
            total_time: Total simulation time
            update_interval: How often to update progress (every N iterations)
        """
        self.total_time = total_time
        self.update_interval = update_interval
        self.start_time = datetime.now()
        self.last_update = 0
    
    def update_progress(self, current_time: float, iteration: int) -> Optional[str]:
        """
        Update progress and return progress string if it's time to display.
        
        Args:
            current_time: Current simulation time
            iteration: Current iteration number
            
        Returns:
            Optional[str]: Progress string if update is due, None otherwise
        """
        if iteration % self.update_interval != 0:
            return None
        
        progress_percent = (current_time / self.total_time) * 100
        elapsed_time = datetime.now() - self.start_time
        
        if current_time > 0:
            estimated_total = elapsed_time.total_seconds() * (self.total_time / current_time)
            estimated_remaining = estimated_total - elapsed_time.total_seconds()
            eta = datetime.now().timestamp() + estimated_remaining
            eta_str = datetime.fromtimestamp(eta).strftime("%H:%M:%S")
        else:
            eta_str = "Unknown"
        
        return (f"Progress: {progress_percent:.1f}% | "
                f"Elapsed: {elapsed_time.total_seconds():.0f}s | "
                f"ETA: {eta_str}")


def create_output_formatter(precision: Dict[str, int] = None, verbosity: str = 'normal') -> SolverOutputFormatter:
    """
    Factory function to create a SolverOutputFormatter instance.
    
    Args:
        precision: Dictionary specifying decimal places for different parameter types
        verbosity: Output verbosity level
        
    Returns:
        SolverOutputFormatter: Configured formatter instance
    """
    return SolverOutputFormatter(precision, verbosity)
