"""
Material property functions for pyBBQ.

Four public functions cover everything needed for thermo-electromagnetic
conductor simulations:

    parse_material_name  -- split a key like 'cu100' into ('cu', 100)
    resistivity          -- effective rho via parallel combination [Ω·m]
    conductivity         -- effective k via weighted average [W/(m·K)]
    heat_capacity        -- effective Cv via weighted average [J/(m³·K)]

All three property functions accept a *conductor_area* dict that maps
material-name keys to cross-sectional areas (or any proportional values).
Fractions are computed internally, so absolute areas and unit fractions
both work.

Mixing rules
------------
resistivity  : parallel   1/rho_eff = Σ f_i / rho_i     (normal conductors)
conductivity : average    k_eff     = Σ f_i · k_i        (normal conductors)
heat_capacity: average    Cv_eff    = Σ f_i · Cv_i       (all with known Cv)

Excluded materials
------------------
'void', 'total'         -- always excluded (no material)
'rebco', 'ybco'         -- excluded from all (no per-T functions available)
'nbti', 'nb3sn'         -- excluded from rho and k (not normal conductors),
                           included in heat_capacity with B-dependent functions
'kapton'                -- excluded from rho (insulator), included in k / Cv
"""

import re
import numpy as np
from steammaterials.STEAM_materials import STEAM_materials

# -------------------------------------------------------------------
# Internal skip sets
# -------------------------------------------------------------------
_ALWAYS_SKIP   = frozenset({'void', 'total', 'rebco', 'ybco'})
_SC_KEYS       = frozenset({'nbti', 'nb3sn'})          # excluded from rho/k
_INSULATOR_KEYS = frozenset({'kapton'})                 # excluded from rho

# Material names whose digits are part of the designation, not an RRR suffix.
_COMPOUND_NAMES = frozenset({'nb3sn', 'nbti', 'al6061', 'al1350'})


# -------------------------------------------------------------------
# Public helpers
# -------------------------------------------------------------------

def parse_material_name(key: str) -> tuple[str, int | None]:
    """Split a material key into its base name and optional RRR integer.

    Only a *trailing* digit sequence is treated as an RRR (e.g. ``'cu100'``
    → RRR 100).  Material names that contain digits as part of their own
    designation (e.g. ``'nb3sn'``, ``'al6061'``) are returned unchanged.

    Examples::

        parse_material_name('cu50')      -> ('cu', 50)
        parse_material_name('Cu100')     -> ('cu', 100)
        parse_material_name('copper')    -> ('copper', None)
        parse_material_name('nb3sn')     -> ('nb3sn', None)
        parse_material_name('al6061')    -> ('al6061', None)
        parse_material_name('hastelloy') -> ('hastelloy', None)
    """
    k = key.lower()
    if k in _COMPOUND_NAMES:
        return k, None
    m = re.match(r'^([a-z]+)(\d+)$', k)
    if m:
        return m.group(1), int(m.group(2))
    return k, None


def is_copper(key: str) -> bool:
    """Return ``True`` if *key* refers to any copper variant (with or without RRR)."""
    base, _ = parse_material_name(key)
    return base in ('cu', 'copper')


# -------------------------------------------------------------------
# Public property functions
# -------------------------------------------------------------------

def resistivity(
    T: np.ndarray,
    B: np.ndarray,
    conductor_area: dict,
    B_min: float = 0.11,
    RRR: float = 100.0,
) -> np.ndarray:
    """Effective electrical resistivity via parallel combination.

    Only normal-conducting materials contribute.  Superconductors (NbTi,
    Nb3Sn), HTS (ReBCO/YBCO), insulators (kapton), void, and total are
    skipped.

    Args:
        T:              Temperature array, shape (1, n) [K].
        B:              Magnetic field array, shape (1, n) [T].
        conductor_area: Dict mapping material name → area (or fraction).
        B_min:          Lower bound on |B| for the copper magnetoresistance
                        fit [T].  Default 0.11 T.
        RRR:    Fallback RRR for copper keys without an embedded
                        number (e.g. ``'copper'``).  Default 100.

    Returns:
        np.ndarray of shape (1, n) [Ω·m].
    """
    skip = _ALWAYS_SKIP | _SC_KEYS | _INSULATOR_KEYS
    eligible = {k: v for k, v in conductor_area.items() if k.lower() not in skip}
    if not eligible:
        return np.zeros(T.shape)

    total = sum(eligible.values())
    B_eff = np.where(np.abs(B) < B_min, B_min, np.abs(B))

    inv_rho = np.zeros(T.shape)
    for mat_name, area in eligible.items():
        f = area / total
        inv_rho += f / _rho_single(mat_name, T, B_eff, RRR)
    return 1.0 / inv_rho


def conductivity(
    T: np.ndarray,
    B: np.ndarray,
    conductor_area: dict,
    RRR: float = 100.0,
) -> np.ndarray:
    """Effective thermal conductivity via weighted average.

    Copper uses the Wiedemann-Franz law (k = L₀·T/ρ) with the per-variant
    RRR encoded in the key.  All other normal-conducting and insulating
    materials use their STEAM fit functions.  Superconductors and HTS are
    excluded.

    Args:
        T:              Temperature array, shape (1, n) [K].
        B:              Magnetic field array, shape (1, n) [T].
        conductor_area: Dict mapping material name → area (or fraction).
        default_RRR:    Fallback RRR for copper keys without an embedded
                        number.  Default 100.

    Returns:
        np.ndarray of shape (1, n) [W/(m·K)].
    """
    skip = _ALWAYS_SKIP | _SC_KEYS
    eligible = {k: v for k, v in conductor_area.items() if k.lower() not in skip}
    if not eligible:
        return np.zeros(T.shape)

    total = sum(eligible.values())
    B_eff = np.where(np.abs(B) < 0.1, 0.1, np.abs(B))

    k_eff = np.zeros(T.shape)
    for mat_name, area in eligible.items():
        f     = area / total
        base, _ = parse_material_name(mat_name)
        if base in ('cu', 'copper'):
            rho_i = _rho_single(mat_name, T, B_eff, RRR)
            k_i   = 2.44e-8 * T / rho_i                         # Wiedemann-Franz
        elif base in ('hastelloy', 'hast'):
            k_i = STEAM_materials('CFUN_kHast_v1', T.shape[0], T.shape[1]).evaluate(T)
        elif base in ('silver', 'ag'):
            k_i = STEAM_materials('CFUN_kAg_v1', T.shape[0], T.shape[1]).evaluate(T)
        elif base == 'al6061':
            k_i = STEAM_materials('CFUN_kAl6061_v1', T.shape[0], T.shape[1]).evaluate(T)
        elif base in ('al1350', 'al'):
            k_i = STEAM_materials('CFUN_kAl1350_v1', T.shape[0], T.shape[1]).evaluate(T)
        elif base == 'kapton':
            k_i = STEAM_materials('CFUN_kKapton_v1', T.shape[0], T.shape[1]).evaluate(T)
        else:
            continue
        k_eff += f * np.asarray(k_i).reshape(T.shape)
    return k_eff


def heat_capacity(
    T: np.ndarray,
    B: np.ndarray,
    conductor_area: dict,
) -> np.ndarray:
    """Effective volumetric heat capacity via weighted average.

    NbTi and Nb3Sn are included using their B-dependent STEAM functions.
    HTS materials (ReBCO/YBCO) are excluded (no per-T function available).

    Args:
        T:              Temperature array, shape (1, n) [K].
        B:              Magnetic field array, shape (1, n) [T].
                        Used for the NbTi and Nb3Sn fits.
        conductor_area: Dict mapping material name → area (or fraction).

    Returns:
        np.ndarray of shape (1, n) [J/(m³·K)].
    """
    eligible = {k: v for k, v in conductor_area.items() if k.lower() not in _ALWAYS_SKIP}
    if not eligible:
        return np.zeros(T.shape)

    total = sum(eligible.values())
    B_abs = np.abs(B).reshape(T.shape)

    cv_eff = np.zeros(T.shape)
    for mat_name, area in eligible.items():
        f    = area / total
        base, _ = parse_material_name(mat_name)
        if base in ('cu', 'copper'):
            cv_i = STEAM_materials('CFUN_CvCu_NIST_v1', T.shape[0], T.shape[1]).evaluate(T)
        elif base in ('hastelloy', 'hast'):
            cv_i = STEAM_materials('CFUN_CvHast_v1', T.shape[0], T.shape[1]).evaluate(T)
        elif base in ('silver', 'ag'):
            cv_i = STEAM_materials('CFUN_CvAg_v1', T.shape[0], T.shape[1]).evaluate(T)
        elif base == 'al6061':
            cv_i = STEAM_materials('CFUN_CvAlAlloy_v1', T.shape[0], T.shape[1]).evaluate(T)
        elif base in ('al1350', 'al'):
            cv_i = STEAM_materials('CFUN_CvAl_v1', T.shape[0], T.shape[1]).evaluate(T)
        elif base == 'kapton':
            cv_i = STEAM_materials('CFUN_CvKapton_v1', T.shape[0], T.shape[1]).evaluate(T)
        elif base == 'nbti':
            inp  = np.vstack((T, B_abs, np.zeros(T.shape), np.ones(T.shape), np.ones(T.shape)))
            cv_i = STEAM_materials('CFUN_CvNbTi_v1', inp.shape[0], inp.shape[1]).evaluate(inp)
        elif base == 'nb3sn':
            inp  = np.vstack((T, B_abs))
            cv_i = STEAM_materials('CFUN_CvNb3Sn_v1', inp.shape[0], inp.shape[1]).evaluate(inp)
        else:
            print(f'Skipped base {base} in the Cv material function as it is not recognized.')
            continue
        cv_eff += f * np.asarray(cv_i).reshape(T.shape)
    return cv_eff


# -------------------------------------------------------------------
# Internal helper
# -------------------------------------------------------------------

def _rho_single(
    mat_name: str,
    T: np.ndarray,
    B: np.ndarray,
    RRR: float = 100.0,
) -> np.ndarray:
    """Resistivity of a single material on a (1, n) grid.

    Args:
        mat_name:    Material key (e.g. ``'cu100'``, ``'hastelloy'``).
        T:           Temperature array, shape (1, n) [K].
        B:           Magnetic field array, shape (1, n) [T] (already ≥ B_min).
        RRR: Fallback RRR for copper without embedded number.

    Returns:
        np.ndarray of shape (1, n) [Ω·m].

    Raises:
        ValueError: If the material has no known resistivity function.
    """
    base, rrr = parse_material_name(mat_name)
    if base in ('cu', 'copper'):
        rrr_val = float(rrr) if rrr is not None else RRR
        inp = np.vstack((T, B, np.ones(T.shape) * rrr_val))
        out = STEAM_materials('CFUN_rhoCu_NIST_v3', inp.shape[0], inp.shape[1]).evaluate(inp)
    elif base in ('hastelloy', 'hast'):
        out = STEAM_materials('CFUN_rhoHast_v2', T.shape[0], T.shape[1]).evaluate(T)
    elif base in ('silver', 'ag'):
        rrr_val = float(rrr) if rrr is not None else 20 # Selecting 20 as default RRR for silver.
        inp = np.vstack((T, B, np.ones(T.shape) * rrr_val, 295.0 * np.ones(T.shape)))
        out = STEAM_materials('CFUN_rhoAg_v1', inp.shape[0], inp.shape[1]).evaluate(inp)
    elif base == 'al6061':
        out = STEAM_materials('CFUN_rhoAl6061_v1', T.shape[0], T.shape[1]).evaluate(T)
    elif base in ('al1350', 'al'):
        out = STEAM_materials('CFUN_rhoAl1350_v1', T.shape[0], T.shape[1]).evaluate(T)
    else:
        raise ValueError(f"No resistivity function for material '{mat_name}'.")
    return np.asarray(out).reshape(T.shape)
