"""
File and folder utility functions for pyBBQ.

This module provides helper functions for creating directories, files, and managing
paths to keep the main pyBBQ class clean and organized.
"""

import os
import shutil
import time
import logging
from typing import List, Optional
from datetime import datetime
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version('pybbq')
except PackageNotFoundError:
    __version__ = 'unknown'


class FileManager:
    """
    Helper class for managing files and folders in pyBBQ simulations.
    
    This class encapsulates all file and folder creation logic to reduce
    complexity in the main pyBBQ class and improve maintainability.
    """
    
    def __init__(self, init_path: str, sim_name: str = '', option: str = 'Normal'):
        """
        Initialize the FileManager with basic configuration.
        
        Args:
            init_path: Initial working directory path
            sim_name: Name of the simulation
            option: Simulation option ('Normal', 'Test', 'Test-pyBBQ', 'Sweep', 'SweepFull')
        """
        self.init_path = init_path
        self.sim_name = sim_name if sim_name else datetime.now().strftime("%Y-%m-%d")
        self.option = option
        
        # Path attributes to be set during folder creation
        self.path = ''
        self.output_path = ''
        self.specific_output_path = ''
        
    def create_directory(self, path: str, description: str = "directory") -> bool:
        """
        Create a directory with error handling and logging.

        Args:
            path: Directory path to create
            description: Description of the directory for logging
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            os.makedirs(path, exist_ok=True)
            print(f"Successfully created the {description} {path}")
            return True
        except OSError as e:
            print(f"Creation of the {description} {path} failed: {e}")
            return False
    
    def copy_file_with_timestamp(self, source_path: str, dest_dir: str, 
                                prefix: str = '', use_timestamp: bool = True) -> str:
        """
        Copy a file to destination directory with optional timestamp prefix.

        Args:
            source_path: Source file path
            dest_dir: Destination directory
            prefix: Prefix for the copied file name
            use_timestamp: Whether to add timestamp to filename
            
        Returns:
            str: Path of the copied file
        """
        source_filename = os.path.basename(source_path)
        
        if use_timestamp and self.option not in ['Test', 'Test-pyBBQ']:
            timestamp = time.strftime("%Y-%m-%d_%H%M")
            dest_filename = f"{timestamp}_{prefix}_{source_filename}" if prefix else f"{timestamp}_{source_filename}"
        else:
            dest_filename = f"{prefix}_{source_filename}" if prefix else source_filename
            
        dest_path = os.path.join(dest_dir, dest_filename)
        
        try:
            shutil.copy(source_path, dest_path)
            return dest_path
        except Exception as e:
            print(f"Failed to copy {source_path} to {dest_path}: {e}")
            return ""
    
    def create_csv_file(self, file_path: str, columns: List[str], 
                       delimiter: str = ',', description: str = "file") -> bool:
        """
        Create a CSV file with headers.

        Args:
            file_path: Path where the CSV file should be created
            columns: List of column headers
            delimiter: CSV delimiter
            description: Description for logging
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            with open(file_path, 'w+', encoding='utf-8') as f:
                f.write(delimiter.join(columns) + '\n')
            logging.info(f"Successfully created {description}: {file_path}")
            return True
        except OSError as e:
            logging.info(f"Creation of {description} {file_path} has failed: {e}")
            return False
    
    @staticmethod
    def uniquify_path(path_original: str) -> str:
        """
        Create a unique path by appending a counter if the path already exists.

        Args:
            path_original: Original path to uniquify
            
        Returns:
            str: Unique path
        """
        counter = 1
        path = f"{path_original} - {counter}"
        
        while os.path.isdir(path):
            counter += 1
            path = f"{path_original} - {counter}"
            
        return path
    
    def setup_output_structure(self, sections: int, layers: int, delimiter: str = ',',
                             uniquify: bool = True, sweeper_nr: str = '0') -> dict:
        """
        Set up the complete output directory structure and create output files.

        Args:
            sections: Number of sections in the simulation
            layers: Number of insulation layers
            delimiter: CSV delimiter for output files
            uniquify: Whether to create unique directory names
            sweeper_nr: Sweeper number for parametric sweeps
            
        Returns:
            dict: Dictionary containing all created paths and file paths
        """
        paths = {}
        
        if self.option == 'Test':
            paths.update(self._setup_test_structure())
        elif self.option == 'Test-pyBBQ':
            paths.update(self._setup_pybbq_test_structure())
        elif self.option in ['Sweep', 'SweepFull']:
            paths.update(self._setup_sweeper_structure(sweeper_nr, delimiter))
        else:
            paths.update(self._setup_normal_structure(uniquify))
            
        # Create output CSV files if not in sweeper mode
        if self.option not in ['Sweep', 'SweepFull'] or self.option == 'SweepFull':
            file_paths = self._create_output_files(sections, layers, delimiter)
            paths.update(file_paths)
            
        return paths
    
    def _setup_test_structure(self) -> dict:
        """Setup directory structure for test mode."""
        self.create_directory(self.init_path)
        
        self.output_path = os.path.join(self.init_path, 'steam_sdk_test')
        self.create_directory(self.output_path, "test output directory")
        
        self.specific_output_path = self.output_path
        
        return {
            'output_path': self.output_path,
            'specific_output_path': self.specific_output_path,
        }
    
    def _setup_pybbq_test_structure(self) -> dict:
        """Setup directory structure for pyBBQ test mode."""
        self.create_directory(self.init_path)
        
        self.output_path = os.path.join(self.init_path, 'pybbq_test')
        self.create_directory(self.output_path, "pyBBQ test output directory")
        
        self.specific_output_path = self.output_path
        
        return {
            'output_path': self.output_path,
            'specific_output_path': self.specific_output_path,
        }
    
    def _setup_sweeper_structure(self, sweeper_nr: str, delimiter: str) -> dict:
        """Setup directory structure for sweeper mode."""
        self.output_path = self.init_path
        
        # Create sweeper result file
        file_sweeper = os.path.join(self.init_path, f'sweeper_result_{sweeper_nr}.csv')
        columns = ['Hot-spot Temperature [K]', 'NZPV [m/s]']
        self.create_csv_file(file_sweeper, columns, delimiter, "sweeper result file")
        
        if self.option == 'SweepFull':
            # Create full results directory for detailed sweeper output
            self.specific_output_path = os.path.join(self.init_path, f'sweeper_{sweeper_nr}')
            self.create_directory(self.specific_output_path, f"sweeper_{sweeper_nr} directory")
        else:
            self.specific_output_path = self.init_path
            
        return {
            'output_path': self.output_path,
            'specific_output_path': self.specific_output_path,
            'file_sweeper': file_sweeper
        }
    
    def _setup_normal_structure(self, uniquify: bool) -> dict:
        """Setup directory structure for normal simulation mode."""
        # Create main Output directory
        self.path = os.path.join(self.init_path, "output")
        self.create_directory(self.path, "main output directory")
        
        # Create Results directory
        self.output_path = os.path.join(self.path, "results")
        self.create_directory(self.output_path, "results directory")
        
        # Create specific simulation directory
        base_sim_path = os.path.join(self.output_path, self.sim_name)
        
        if uniquify:
            self.specific_output_path = self.uniquify_path(base_sim_path)
        else:
            self.specific_output_path = base_sim_path
            if os.path.exists(self.specific_output_path):
                try:
                    shutil.rmtree(self.specific_output_path)
                except OSError as e:
                    print(f"Error removing existing directory: {e}")
                    
        self.create_directory(self.specific_output_path, "specific simulation directory")

        return {
            'path': self.path,
            'output_path': self.output_path,
            'specific_output_path': self.specific_output_path,
        }
    
    def _create_output_files(self, sections: int, layers: int, delimiter: str) -> dict:
        """
        Create all output CSV files with appropriate headers.

        Args:
            sections: Number of sections in simulation
            layers: Number of insulation layers
            delimiter: CSV delimiter
            
        Returns:
            dict: Dictionary with file paths
        """
        file_paths = {}
        
        # Define file paths
        file_paths['file_main'] = os.path.join(self.specific_output_path, 'main.csv')
        file_paths['file_temperature'] = os.path.join(self.specific_output_path, 'temperature.csv')
        file_paths['file_voltage'] = os.path.join(self.specific_output_path, 'voltage.csv')
        file_paths['file_NZPV'] = os.path.join(self.specific_output_path, 'NZPV.csv')
        file_paths['file_summary'] = os.path.join(self.specific_output_path, 'summary.csv')
        
        # Define column headers for each file
        columns_main = [
            'time [s]', 'T_peak [K]', 'Current [A]', 'Voltage [V]',
            'Ohmic Heating [W]', 'Heater Power [W]', 'Dump Resistor Voltage [V]',
            'MIIT [A2s]'
        ]
        columns_temperature = ['time [s]'] + [f'T{i}' for i in range(int(sections * (layers + 1)))]
        columns_voltage = ['time [s]'] + [f'V{i}' for i in range(int(sections))]
        columns_NZPV = ['Position [m]', 'time [s]', 'NZPV [m/s]', 'Current [A]']
        columns_summary = ['Current [A]', 'NZPV [m/s]']
        
        # Create files
        file_configs = [
            (file_paths['file_main'], columns_main, "main results file"),
            (file_paths['file_temperature'], columns_temperature, "temperature results file"),
            (file_paths['file_voltage'], columns_voltage, "voltage results file"),
            (file_paths['file_NZPV'], columns_NZPV, "NZPV results file"),
            (file_paths['file_summary'], columns_summary, "summary results file")
        ]
        
        for file_path, columns, description in file_configs:
            self.create_csv_file(file_path, columns, delimiter, description)
            
        return file_paths
    
    def start_logger(self) -> None:
        """
        Initialize logging for the simulation.

        Sets up both file and console logging with appropriate formatting.
        """
        log_file = os.path.join(self.specific_output_path, "logfile")
        
        # Clear any existing handlers
        for handler in logging.root.handlers[:]:
            logging.root.removeHandler(handler)
            
        # Configure logging
        logging.basicConfig(
            level=logging.INFO,
            filename=log_file,
            filemode="w",
            format="%(asctime)-15s %(levelname)-8s %(message)s"
        )
        
        # Add console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        formatter = logging.Formatter("%(asctime)-15s %(levelname)-8s %(message)s")
        console_handler.setFormatter(formatter)
        logging.getLogger().addHandler(console_handler)
        
        logging.info('Logging started after path creation.')
        logging.info(f'PyBBQ v{__version__}, Date: {datetime.now().strftime("%Y-%m-%d %H:%M")}')


def create_file_manager(init_path: str, sim_name: str = '', option: str = 'Normal') -> FileManager:
    """
    Factory function to create a FileManager instance.
    
    Args:
        init_path: Initial working directory path
        sim_name: Name of the simulation
        option: Simulation option
        
    Returns:
        FileManager: Configured FileManager instance
    """
    return FileManager(init_path, sim_name, option)
