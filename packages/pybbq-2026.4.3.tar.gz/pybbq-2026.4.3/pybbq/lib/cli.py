"""
cli.py - Command-line interface utilities for pyBBQ.

Handles terminal output such as the startup logo.
"""

import sys


# ANSI escape code for yellow text and reset.
# These are widely supported on modern terminals (Linux, macOS, Windows 10+).
_YELLOW = "\033[93m"
_RESET = "\033[0m"

# Unicode block-art logo. Uses box-drawing and block characters that may not
# render on terminals with limited code-page support (e.g. Windows cp437/cp850).
_LOGO_UNICODE = r"""
  ██████╗ ██╗   ██╗██████╗ ██████╗  ██████╗
  ██╔══██╗╚██╗ ██╔╝██╔══██╗██╔══██╗██╔═══██╗
  ██████╔╝ ╚████╔╝ ██████╔╝██████╔╝██║   ██║
  ██╔═══╝   ╚██╔╝  ██╔══██╗██╔══██╗██║▄▄ ██║
  ██║        ██║   ██████╔╝██████╔╝╚██████╔╝
  ╚═╝        ╚═╝   ╚═════╝ ╚═════╝  ╚══▀▀═╝
"""

# Pure-ASCII fallback logo for terminals that cannot display Unicode block art.
_LOGO_ASCII = r"""
  ____       ____  ____   ___
 |  _ \ _   | __ )|  _ \ / _ \
 | |_) | | | |  _ \| |_) | | | |
 |  __/| |_| | |_) |  _ <| |_| |
 |_|    \__, |____/|_| \_\\__\_\
         |___/
"""


def _supports_unicode() -> bool:
    """Return True if the current stdout encoding can represent Unicode art.

    We test by attempting to encode a representative block character. If the
    encoding raises UnicodeEncodeError (common on Windows with cp850/cp437
    code pages), we fall back to pure ASCII.
    """
    encoding = getattr(sys.stdout, "encoding", None) or "ascii"
    try:
        "█".encode(encoding)
        return True
    except (UnicodeEncodeError, LookupError):
        return False


def main() -> None:
    """Console script entry point for pybbq.

    Parses command-line arguments and launches the pyBBQ solver.
    Usage: pybbq <input.yaml> [output_dir] [--mode {Sweep,SweepFull}]
    """
    import argparse
    # Local import to avoid circular dependency (pyBBQ imports from cli)
    from pybbq.pybbq import pyBBQ
    from pybbq._version import __version__

    parser = argparse.ArgumentParser(
        prog='pybbq',
        description=(
            'pyBBQ — Python Bus-Bar Quench model.\n'
            'Thermo-electromagnetic simulation of transients in superconductors.\n'
            '1.5D, homogenised, ODE-solver-based.'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            'examples:\n'
            '  pybbq input.yaml\n'
            '  pybbq input.yaml output/results/my_run\n'
            '  pybbq input.yaml output/results/my_run --mode Sweep\n'
            '\n'
            'The input file is a YAML file describing the conductor geometry,\n'
            'materials, cooling, protection settings, and solver options.\n'
            'Results are written to output/results/<sim_name>/ by default.'
        ),
    )
    parser.add_argument(
        'input_yaml',
        metavar='input.yaml',
        help='path to the YAML input file',
    )
    parser.add_argument(
        'output_dir',
        metavar='output_dir',
        nargs='?',
        default=None,
        help='output directory (overrides the path derived from sim_name in the input file)',
    )
    parser.add_argument(
        '--mode',
        choices=['Sweep', 'SweepFull'],
        default=None,
        help=(
            'run mode: '
            '"Sweep" performs a parameter sweep; '
            '"SweepFull" performs a full parameter sweep (all combinations). '
            'Omit for a single simulation run.'
        ),
    )
    parser.add_argument(
        '--version',
        action='version',
        version=f'%(prog)s {__version__}',
    )

    args = parser.parse_args()

    print_logo()
    print('Loading the provided yaml file: ' + args.input_yaml)

    if args.output_dir is not None:
        pyBBQ(args.input_yaml, args.output_dir, args.mode)
    else:
        pyBBQ(args.input_yaml)


def print_logo() -> None:
    """Print the pyBBQ startup logo to stdout in yellow.

    Automatically selects the Unicode block-art version when the terminal
    supports it, and falls back to a plain ASCII version otherwise.
    """
    logo = _LOGO_UNICODE if _supports_unicode() else _LOGO_ASCII
    # colour is applied only when stdout is a real terminal (not redirected
    # to a file or pipe) to avoid polluting captured output with escape codes.
    if sys.stdout.isatty():
        print(f"{_YELLOW}{logo}{_RESET}")
    else:
        print(logo)
