"""
Current sharing calculation utilities for pyBBQ.

This module contains functions for calculating current sharing in superconductors,
including multiprocessing utilities for HTS calculations.
"""

import numpy as np
from scipy.optimize import fsolve
from .math_utils import powerlaw


def hts_multi_core_fsolve(splitted_list: list) -> list:
    """Multicore solver for HTS current sharing calculations.
    
    This function is used in multiprocessing to solve current sharing equations
    for High Temperature Superconductor (HTS) materials in parallel.
    
    Args:
        splitted_list: List of parameter sets for fsolve
                      Each element contains [i, j, k, I, Ic, R] where:
                      - i, j, k: indices
                      - I: Current [A]
                      - Ic: Critical current [A] 
                      - R: Resistance [Ohm]
    
    Returns:
        List of current sharing coefficients
    """
    print('** Starting Thread **')
    
    # Define local powerlaw function with fixed n-value
    # TODO: n-value should be variable
    def powerlaw_local(xs, I, Ic, R, n=30, E0=1e-4):
        return E0 * (I * xs / Ic) ** n - R * I * (1 - xs)
    
    results = []
    for vals in splitted_list:
        # vals[3] = I, vals[4] = Ic, vals[5] = R
        result = fsolve(powerlaw_local, np.float64(1.0), args=(vals[3], vals[4], vals[5]), maxfev=1000000)
        results.append(result)
    
    return results


class CurrentSharingCalculator:
    """Class for calculating current sharing in superconductors."""
    
    def __init__(self, material_type: str):
        """Initialize calculator for specific material type.
        
        Args:
            material_type: Type of superconductor ('NbTi', 'Nb3Sn', 'ReBCO', etc.)
        """
        self.material_type = material_type
        
    def calculate_sharing_coefficient(self, T: float, B: float, I: float, Ic: float, R: float, n_value: float = 30) -> float:
        """Calculate current sharing coefficient for given conditions.
        
        Args:
            T: Temperature [K]
            B: Magnetic field [T]
            I: Operating current [A]
            Ic: Critical current [A]
            R: Resistance [Ohm]
            n_value: n-value of superconductor
            
        Returns:
            Current sharing coefficient (0-1)
        """
        if Ic <= 0:
            return 0.0
            
        try:
            result = fsolve(powerlaw, 1.0, args=(I, Ic, R, n_value), maxfev=1000000)
            return np.clip(result[0], 0.0, 1.0)
        except:
            return 0.0
