import numpy as np
from scipy.optimize import root_scalar
from .materials import is_copper

def geomspace_sections(l, n, ratio=None, first_length=None):
    """
    Split total length l into n geometrically spaced sections.

    Parameters
    ----------
    l : float
        Total length.
    n : int
        Number of sections.
    ratio : float, optional
        Ratio between successive section lengths.
    first_length : float, optional
        Length of the first section. If provided, ratio is computed automatically.

    Returns
    -------
    centers : ndarray
        Section centers.
    lengths : ndarray
        Section lengths.
    """

    if ratio is None and first_length is None:
        raise ValueError("Either 'ratio' or 'first_length' must be provided.")
    if ratio is not None and first_length is not None:
        raise ValueError("Provide only one of 'ratio' or 'first_length', not both.")

    # Compute ratio if first_length is provided
    if first_length is not None:
        # The total length formula:
        # l = first_length * (r^n - 1) / (r - 1)
        # We’ll solve for r > 1 using log-safe arithmetic

        def equation(r):
            if np.isclose(r, 1.0):
                return first_length * n - l  # limit as r -> 1
            # use expm1 for numerical stability: expm1(x) = exp(x) - 1
            x = n * np.log(r)
            # safe computation of (r^n - 1)/(r - 1)
            numerator = np.expm1(x)
            denominator = r - 1
            return first_length * numerator / denominator - l

        # Initial guess: approximate ratio near 1
        r_guess = 1 + 2 * (l - first_length * n) / (first_length * n**2)
        r_guess = max(r_guess, 1.0000001)

        # Find an upper bound dynamically
        r_upper = 1.1
        while True:
            try:
                if equation(r_upper) > 0:
                    break
            except OverflowError:
                break
            r_upper *= 2
            if r_upper > 1e6:
                break  # prevent runaway

        sol = root_scalar(equation, bracket=[1.0, r_upper], method='bisect')
        if not sol.converged:
            raise RuntimeError("Failed to compute geometric ratio.")
        ratio = sol.root

    # Compute section lengths
    if first_length is not None:
        lengths = first_length * ratio**np.arange(n)
    else:
        first_length = l * (ratio - 1) / (ratio**n - 1)
        lengths = first_length * ratio**np.arange(n)

    # Compute centers
    boundaries = np.concatenate(([0.0], np.cumsum(lengths)))
    centers = boundaries[:-1] + lengths / 2

    return centers, lengths

def nearest_index(array, value):
    """
    Return the index of the element in 'array' closest to 'value'.
    """
    array = np.asarray(array)
    return np.abs(array - value).argmin()


def reconcile_conductor_areas(
    conductor_composition: dict | None,
    conductor_area: dict | None,
    A_total: float,
    rtol: float = 1e-3,
) -> tuple[dict, dict]:
    """Reconcile conductor_composition (fractions) and conductor_area (m²).

    Exactly one of the two dicts may be ``None``; the missing one is derived
    from the other.  If both are provided their values are checked for mutual
    consistency.  In all cases the resulting areas are verified to sum to
    *A_total* within the given relative tolerance.

    **Copper grouping:** ``conductor_composition`` always uses a single
    ``'copper'`` key for all copper variants, regardless of RRR.
    ``conductor_area`` keeps individual keys (e.g. ``'cu50'``, ``'cu100'``)
    so that the resistivity calculator can access the per-variant RRR via
    ``parse_material_name``.  When deriving or validating, all copper-variant
    areas are summed before comparing against the ``'copper'`` fraction.

    Args:
        conductor_composition: Volume fraction per material (void included).
            All copper variants must be grouped under ``'copper'``.
            Values should sum to 1.0.
        conductor_area: Cross-sectional area [m²] per material.
            Copper variants may appear as separate keys (e.g. ``'cu50'``).
        A_total: Total conductor cross-sectional area [m²] from geometry.
        rtol: Relative tolerance for all numerical checks (default 0.1 %).

    Returns:
        ``(conductor_composition, conductor_area)`` — both fully populated.

    Raises:
        ValueError: If neither dict is provided, the grouped keys differ,
            values are inconsistent, or areas do not sum to *A_total*.
    """
    if conductor_composition is None and conductor_area is None:
        raise ValueError(
            "At least one of 'conductor_composition' or 'conductor_area' "
            "must be provided in the input."
        )

    if conductor_composition is not None and conductor_area is None:
        # Derive per-material areas from volume fractions.
        # conductor_composition already groups all copper variants under
        # 'copper', so the derived conductor_area mirrors that grouping.
        conductor_area = {
            k: v * A_total for k, v in conductor_composition.items()
        }

    elif conductor_area is not None and conductor_composition is None:
        # Derive volume fractions from per-material areas.
        # Multiple copper variants (e.g. 'cu50', 'cu100') are summed into a
        # single 'copper' key so that conductor_composition is material-type
        # based.  conductor_area keeps the individual keys so the resistivity
        # calculator can read the per-variant RRR.
        conductor_composition = {}
        for k, v in conductor_area.items():
            comp_key = 'copper' if is_copper(k) else k
            conductor_composition[comp_key] = (
                conductor_composition.get(comp_key, 0.0) + v / A_total
            )

    else:
        # Both provided — validate mutual consistency.
        # conductor_composition uses a single 'copper' key; conductor_area may
        # have split copper variants.  Build a grouped view of conductor_area
        # for a fair comparison.
        area_grouped: dict[str, float] = {}
        for k, v in conductor_area.items():
            comp_key = 'copper' if is_copper(k) else k
            area_grouped[comp_key] = area_grouped.get(comp_key, 0.0) + v

        keys_comp = set(conductor_composition.keys())
        keys_grouped = set(area_grouped.keys())
        if keys_comp != keys_grouped:
            raise ValueError(
                "conductor_composition and conductor_area must cover the same "
                "materials (copper variants in conductor_area are grouped).\n"
                f"  composition keys:    {sorted(keys_comp)}\n"
                f"  area keys (grouped): {sorted(keys_grouped)}"
            )
        for key in conductor_composition:
            expected = conductor_composition[key] * A_total
            actual = area_grouped[key]
            # Tolerance is scaled to A_total so near-zero materials
            # (e.g. 'other': 0.0) are handled correctly.
            if abs(actual - expected) > rtol * A_total:
                raise ValueError(
                    f"Inconsistency for material '{key}': "
                    f"conductor_composition implies {expected:.6e} m², "
                    f"but conductor_area gives {actual:.6e} m² "
                    f"(allowed deviation {rtol * A_total:.3e} m²)."
                )

    # Final check: areas must sum to the total geometric area.
    area_sum = sum(conductor_area.values())
    if abs(area_sum - A_total) > rtol * A_total:
        raise ValueError(
            f"conductor areas sum to {area_sum:.6e} m², but the total "
            f"conductor cross-sectional area from geometry is "
            f"{A_total:.6e} m² "
            f"(relative error {abs(area_sum - A_total) / A_total:.3e} > "
            f"rtol={rtol}). "
            "Check that all material fractions/areas sum to the full "
            "cross-sectional area (void included)."
        )

    return conductor_composition, conductor_area
