"""
Mathematical utility functions for pyBBQ.

This module contains mathematical helper functions used throughout the pyBBQ simulation.
"""

import numpy as np


def powerlaw(xs: float, I: float, Ic: float, R: float, n: float = 30, E0: float = 1e-4) -> float:
    """Power law function for current sharing calculations.
    
    Args:
        xs: Current sharing coefficient
        I: Current [A]
        Ic: Critical current [A] 
        R: Resistance [Ohm]
        n: n-value for superconductor
        E0: Electric field criterion [V/m]
        
    Returns:
        Power law result
    """
    return E0 * (I * xs / Ic) ** n - R * I * (1 - xs)


def powerlaw_jac(xs: float, I: float, Ic: float, R: float, n: float = 30, E0: float = 1e-4) -> float:
    """Jacobian of the power law function for current sharing calculations.
    
    Args:
        xs: Current sharing coefficient
        I: Current [A]
        Ic: Critical current [A] 
        R: Resistance [Ohm]
        n: n-value for superconductor
        E0: Electric field criterion [V/m]
        
    Returns:
        Jacobian of power law
    """
    return E0 * n * (I / Ic) ** n * xs ** (n - 1) + R * I


def split_temperature_array(T: np.ndarray, sections: int, layers: int) -> list:
    """Splits the temperature array into sections to reduce matrix operations.

    Args:
        T: Temperature array
        sections: Number of sections
        layers: Number of layers

    Returns:
        List of split temperature arrays
    """
    return np.array([T[0+i*sections:sections+i*sections] for i in range(layers+1)])

def powerlaw_v2(x, IIc, U, n=21.0, E0=1e-4):
    """
    Superconductor power law.

    This function is used in new_calc_current_sharing() in @pybbq.py.
    
    Args:
        x: Current sharing factor (0-1)
        IIc: Current ratio I/Ic
        U: Voltage parameter
        n: n-value (default 21.0)
        E0: Electric field constant (default 1e-4)
        
    Returns:
        Power law result: E0 * (IIc)^n * x^n - U * (1 - x)
    """
    IIc_pow_n = np.power(IIc, n)
    x_pow_n = np.power(x, n)
    one_minus_x = 1.0 - x
        
    return E0 * IIc_pow_n * x_pow_n - U * one_minus_x

def powerlaw_jac_v2(x, IIc, U, n=21.0, E0=1e-4):
    """
    Jacobian of superconductor power law.
    
    OPTIMIZED: Vectorized computation and mathematical simplification for better performance.
    Simplified from: n * E0 * IIc * (IIc * x)^(n-1) + U
    To: n * E0 * IIc^n * x^(n-1) + U

    This function is used in new_calc_current_sharing() in @pybbq.py.
    
    Args:
        x: Current sharing factor (0-1)
        IIc: Current ratio I/Ic  
        U: Voltage parameter
        n: n-value (default 21.0)
        E0: Electric field constant (default 1e-4)
        
    Returns:
        Jacobian: n * E0 * IIc^n * x^(n-1) + U
    """
    # Use numpy operations for vectorized computation
    IIc_pow_n = np.power(IIc, n)
    x_pow_n_minus_1 = np.power(x, n - 1.0)
        
    return n * E0 * IIc_pow_n * x_pow_n_minus_1 + U
