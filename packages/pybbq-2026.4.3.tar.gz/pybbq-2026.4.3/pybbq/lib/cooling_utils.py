"""
Cooling utility functions for pyBBQ.

This module provides helper functions for calculating heat transfer coefficients
between conductors and helium coolants (He-I and He-II).
"""

import numpy as np
from typing import Union


def sig(x1: Union[float, np.ndarray], c: float = 100.0) -> Union[float, np.ndarray]:
    """
    Sigmoidal function for 0 to 1, used to smoothen some hard transitions.

    Args:
        x1: x-position, transition at 0
        c: size of the transition (default: 100)

    Returns:
        A value between 0 and 1
    """
    return 1 / (1 + np.exp(-c * x1))


def helium_I_heat_transfer(T: np.ndarray, T_helium: float, c1: float, c2: float, 
                          c3: float, T_star_1: float, T_star_2: float) -> np.ndarray:
    """
    Calculate heat transfer coefficient between the outer layer and liquid He-I.
    
    This function implements the heat transfer model for normal liquid helium (He-I)
    based on different heat transfer regimes.
    
    Args:
        T: Temperature of the outermost layer [K]
        T_helium: Helium temperature [K]
        c1: Cooling parameter for regime 1 [W/(m²·K²)]
        c2: Cooling parameter for regime 2 [W/(m²·K^3.5)]
        c3: Cooling parameter for regime 3 [W/(m²·K²)]
        T_star_1: Transition temperature 1 [K]
        T_star_2: Transition temperature 2 [K]
        
    Returns:
        Heat transfer coefficient [W/(m²·K)]
    """
    # Ensure nothing can be colder than the helium temperature
    T = np.where(T < T_helium, T_helium, T)
    
    # Calculate heat transfer in different regimes with smooth transitions
    h1 = c1 * (T - T_helium) * (1 - sig(T - T_star_1, 100))
    h2 = (c2 * (T - T_helium) ** 2.5 * 
          sig(T - T_star_1, 100) * 
          (1 - sig(T - T_star_2, 100)))
    h3 = c3 * (T - T_helium) * sig(T - T_star_2, 100)
    
    # Transient cooling regime is ignored, see:
    # Source: CUDI: A MODEL FOR CALCULATION OF ELECTRODYNAMIC AND THERMAL 
    # BEHAVIOUR OF SUPERCONDUCTING RUTHERFORD CABLES - A. P. Verweij
    

    # Handle division by zero when T equals T_helium
    # When there's no temperature difference, heat transfer coefficient should be zero
    delta_T = T - T_helium
    heat_flux = h1 + h2 + h3
    
    # Use np.where to handle division by zero gracefully
    # When delta_T is very small (< 1e-12), return 0 instead of dividing
    heat_transfer_coeff = np.where(
        np.abs(delta_T) < 1e-12,
        0.0,
        heat_flux / delta_T
    )
    
    return np.clip(heat_transfer_coeff, None, 1e9)


def helium_II_heat_transfer(T: np.ndarray, T_helium: float, c5: float, c6: float, 
                           p: float, Tstar: float) -> np.ndarray:
    """
    Calculate heat transfer coefficient between the outer layer and liquid He-II.
    
    This function implements the heat transfer model for superfluid helium (He-II)
    which has different heat transfer characteristics than normal helium.
    
    Args:
        T: Temperature of the outermost layer [K]
        T_helium: Helium temperature [K]
        c5: Cooling parameter for superfluid regime [W/(m²·K^(p+1))]
        c6: Cooling parameter for film boiling regime [W/(m²·K²)]
        p: Cooling parameter exponent for superfluid regime [-]
        Tstar: Transition temperature between regimes [K]
        
    Returns:
        Heat transfer coefficient [W/(m²·K)]
    """
    # Ensure minimum temperature above helium temperature
    T = np.where(T < (T_helium + 1e-3), T_helium + 1e-3, T)
    
    # Calculate heat transfer in different regimes
    # Superfluid regime: H(T) = c5*(T^p - T_helium^p)
    h5 = (c5 * (T**p - T_helium**p)) * (1 - sig(T - T_helium - Tstar, 100))
    
    # Film boiling regime: H(T) = c6*(T - T_helium)
    h6 = (c6 * (T - T_helium)) * sig(T - T_helium - Tstar, 100)

    # Handle division by zero when T equals T_helium
    # When there's no temperature difference, heat transfer coefficient should be zero
    delta_T = T - T_helium
    heat_flux = h5 + h6

    # Use np.where to handle division by zero gracefully
    # When delta_T is very small (< 1e-12), return 0 instead of dividing
    heat_transfer_coeff = np.where(
        np.abs(delta_T) < 1e-12,
        0.0,
        heat_flux / delta_T
    )
    
    return np.clip(heat_transfer_coeff, None, 1e9)


class CoolingCalculator:
    """
    Helper class to encapsulate cooling calculations with instance parameters.
    
    This class provides a convenient way to calculate heat transfer coefficients
    while maintaining the cooling parameters as instance variables.
    """
    
    def __init__(self, T_helium: float, c1: float = 500., c2: float = 5e4, 
                 c3: float = 250., c5: float = 200., c6: float = 200., 
                 p: float = 4.0, h1: float = 10., h2: float = 1e4):
        """
        Initialize cooling calculator with helium and cooling parameters.
        
        Args:
            T_helium: Helium temperature [K]
            c1: He-I cooling parameter 1 [W/(m²·K²)]
            c2: He-I cooling parameter 2 [W/(m²·K^3.5)]
            c3: He-I cooling parameter 3 [W/(m²·K²)]
            c5: He-II cooling parameter for superfluid [W/(m²·K^(p+1))]
            c6: He-II cooling parameter for film boiling [W/(m²·K²)]
            p: He-II cooling exponent [-]
            h1: He-I parameter 1 [W/(m²·K)]
            h2: He-I parameter 2 [W/(m²·K)]
        """
        self.T_helium = T_helium
        self.c1 = c1
        self.c2 = c2
        self.c3 = c3
        self.c5 = c5
        self.c6 = c6
        self.p = p
        self.h1 = h1
        self.h2 = h2
        
        # Calculate transition temperatures
        self.T_star_1 = h1 / c1 + T_helium
        self.T_star_2 = (h2 / c2) ** (1 / 2.5) + T_helium
        self.Tstar = ((35e3 / c5) + T_helium**p)**(1/p) - T_helium  # Pmax = 35e3
    
    def helium_I(self, T: np.ndarray) -> np.ndarray:
        """Calculate He-I heat transfer coefficient."""
        return helium_I_heat_transfer(T, self.T_helium, self.c1, self.c2, self.c3,
                                     self.T_star_1, self.T_star_2)
    
    def helium_II(self, T: np.ndarray) -> np.ndarray:
        """Calculate He-II heat transfer coefficient."""
        return helium_II_heat_transfer(T, self.T_helium, self.c5, self.c6, 
                                      self.p, self.Tstar)
