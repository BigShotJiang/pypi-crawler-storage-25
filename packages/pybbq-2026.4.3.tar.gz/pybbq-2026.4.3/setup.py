"""
Minimal setup.py for compatibility with older tools.
All project metadata and configuration is defined in pyproject.toml.
"""
from setuptools import setup

if __name__ == "__main__":
    setup()
