import numpy as np


def normalize(v):
    s = v.sum()
    if s == 0:
        return v
    return v / s


def check_HMM_tables(T, B):
    assert type(T) == dict == type(B)
    K = set(T.keys())
    for v in T.values():
        assert set(v.keys()) == K
        for v2 in v.values():
            assert 0. <= v2 <= 1.
    for v in B.values():
        assert set(v.keys()) == K
        for v2 in v.values():
            assert 0. <= v2 <= 1.


class ForwardBackward2:
    """
    Hidden Markov Model Forward-Backward algorithm.

    Conventions:
        - T[h1][h2] = P(next=h2 | current=h1)  (rows=from, cols=to)
        - B[obs][h] = P(obs | state=h)
        - T_mat[i, j] = T[h_i][h_j]
        - emit_vec[t] = vector of length n_states, emit_vec[i] = B[o_t][h_i]
    """

    def __init__(self, T, B):
        check_HMM_tables(T, B)
        self.T = T
        self.B = B

        self.hidden_states = sorted(T.keys())
        self.n_states = len(self.hidden_states)

        self.T_mat = None
        self.emit_map = None

        self.obs_seq = None
        self.pi = None

        self.alpha = None       # forward variables,  shape (T_len, n_states)
        self.beta = None        # backward variables, shape (T_len, n_states)
        self.gamma = None       # smoothed posteriors, shape (T_len, n_states)

        self.preproc()

    # ------------------------------------------------------------------
    # Preprocessing: dict -> matrix
    # ------------------------------------------------------------------

    def preproc(self):
        self._build_T_mat()
        self._build_emit_map()

    def _build_T_mat(self):
        """
        T_mat[i, j] = T[h_i][h_j] = P(next=h_j | current=h_i)
        rows = from, cols = to
        """
        n = self.n_states
        self.T_mat = np.zeros((n, n))
        for i, h1 in enumerate(self.hidden_states):
            for j, h2 in enumerate(self.hidden_states):
                self.T_mat[i, j] = self.T[h1][h2]

    def _build_emit_map(self):
        """
        emit_map[obs] = vector of length n_states
        emit_map[obs][i] = B[obs][h_i] = P(obs | state=h_i)
        """
        self.emit_map = {}
        for obs in self.B.keys():
            v = np.array([self.B[obs][h] for h in self.hidden_states])
            self.emit_map[obs] = v

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def run(self, obs_seq, pi=None):
        """
        Run the full forward-backward algorithm.

        Parameters
        ----------
        obs_seq : list
            Sequence of observations (keys in B).
        pi : np.ndarray of shape (n_states,), optional
            Initial state distribution. Defaults to uniform.

        Returns
        -------
        gamma : np.ndarray, shape (T_len, n_states)
            Smoothed state posteriors at each time step.
        """
        self._load(obs_seq, pi)
        self.forward()
        self.backward()
        self.smooth()
        return self.gamma

    # ------------------------------------------------------------------
    # Core steps
    # ------------------------------------------------------------------

    def forward(self):
        """
        Compute forward variables alpha.

        alpha[t, i] = P(o_1, ..., o_t, state_t = h_i)

        Recurrence:
            alpha[0, i] = pi[i] * emit(o_0)[i]
            alpha[t, i] = emit(o_t)[i] * (alpha[t-1] @ T_mat)[i]
        """
        T_len = len(self.obs_seq)
        self.alpha = np.zeros((T_len, self.n_states))

        # Base case
        self.alpha[0] = normalize(self.pi * self._emit(0))

        # Recurrence
        for t in range(1, T_len):
            self.alpha[t] = normalize(
                (self.alpha[t - 1] @ self.T_mat) * self._emit(t)
            )

    def backward(self):
        """
        Compute backward variables beta.

        beta[t, i] = P(o_{t+1}, ..., o_T | state_t = h_i)

        Recurrence:
            beta[T-1, i] = 1
            beta[t, i]   = (T_mat @ (beta[t+1] * emit(o_{t+1})))[i]
        """
        T_len = len(self.obs_seq)
        self.beta = np.zeros((T_len, self.n_states))

        # Base case
        self.beta[T_len - 1] = np.ones(self.n_states)

        # Recurrence
        for t in range(T_len - 2, -1, -1):
            self.beta[t] = normalize(
                self.T_mat @ (self.beta[t + 1] * self._emit(t + 1))
            )

    def smooth(self):
        """
        Compute smoothed posteriors gamma.

        gamma[t, i] = P(state_t = h_i | o_1, ..., o_T)
                    ∝ alpha[t, i] * beta[t, i]
        """
        T_len = len(self.obs_seq)
        self.gamma = np.zeros((T_len, self.n_states))

        for t in range(T_len):
            self.gamma[t] = normalize(self.alpha[t] * self.beta[t])

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _load(self, obs_seq, pi):
        for o in obs_seq:
            assert o in self.B
        self.obs_seq = obs_seq

        if pi is None:
            self.pi = np.ones(self.n_states) / self.n_states
        else:
            assert len(pi) == self.n_states
            self.pi = np.array(pi, dtype=float)

        self.alpha = None
        self.beta = None
        self.gamma = None

    def _emit(self, t):
        """Return emission vector for time step t."""
        return self.emit_map[self.obs_seq[t]]