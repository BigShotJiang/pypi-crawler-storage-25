import asyncio
import os
import time
from typing import Any, Dict, Optional, Tuple

import httpx
from pydantic import ValidationError as PydanticValidationError

from .errors import (
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    InternalError,
    KeplarsError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from .models import (
    KeplarsConfig,
    RateLimitInfo,
)
from .resources import (
    EmailsResource,
    AsyncEmailsResource,
)
from .contacts import ContactsResource, AsyncContactsResource
from .audiences import AudiencesResource, AsyncAudiencesResource
from .automations import AutomationsResource, AsyncAutomationsResource
from .domains import DomainsResource, AsyncDomainsResource
from .utils import calculate_exponential_backoff


class Keplars:
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        retry_delay: float = 1.0,
    ) -> None:
        if not api_key:
            api_key = os.environ.get("KEPLARS_API_KEY")
            if not api_key:
                raise ValueError(
                    "API key is required. Set KEPLARS_API_KEY or pass api_key parameter."
                )

        resolved_base_url = (
            base_url
            or os.environ.get("KEPLARS_BASE_URL")
            or "https://api.keplars.com"
        ).rstrip("/")

        self._config = KeplarsConfig(
            api_key=api_key,
            base_url=resolved_base_url,
            timeout=timeout,
            max_retries=max_retries,
            retry_delay=retry_delay,
        )

        self._client = httpx.Client(
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "keplars-email-python/1.0.0",
            },
        )

        self.emails = EmailsResource(self)
        self.contacts = ContactsResource(self)
        self.audiences = AudiencesResource(self)
        self.automations = AutomationsResource(self)
        self.domains = DomainsResource(self)

    def __enter__(self) -> "Keplars":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    def _request(
        self, method: str, path: str, data: Optional[Dict[str, Any]] = None, retry_count: int = 0
    ) -> Tuple[Dict[str, Any], Optional[RateLimitInfo]]:
        url = self._config.base_url + path

        try:
            response = self._client.request(method, url, json=data)
            rate_limit_info = self._extract_rate_limit_info(response)

            if not response.is_success:
                self._handle_error_response(response, retry_count)

            return response.json(), rate_limit_info

        except httpx.HTTPError as e:
            if self._is_retryable_error(e) and retry_count < self._config.max_retries:
                delay = calculate_exponential_backoff(retry_count, self._config.retry_delay)
                time.sleep(delay)
                return self._request(method, path, data, retry_count + 1)

            raise NetworkError(f"Network request failed: {str(e)}", e) from e

    def _extract_rate_limit_info(self, response: httpx.Response) -> Optional[RateLimitInfo]:
        limit = response.headers.get("X-RateLimit-Limit")
        remaining = response.headers.get("X-RateLimit-Remaining")
        reset = response.headers.get("X-RateLimit-Reset")

        if limit and remaining and reset:
            return RateLimitInfo(
                limit=int(limit),
                remaining=int(remaining),
                reset=int(reset),
            )

        return None

    def _handle_error_response(self, response: httpx.Response, retry_count: int) -> None:
        try:
            error_data = response.json()
        except (ValueError, PydanticValidationError):
            raise KeplarsError(
                f"HTTP {response.status_code}: {response.text}",
                "INTERNAL_ERROR",
                None,
                response.status_code,
            )

        message = error_data.get("message", f"HTTP {response.status_code}")

        if response.status_code == 400:
            raise ValidationError(message, None, None)
        elif response.status_code == 401:
            raise AuthenticationError(message, None)
        elif response.status_code == 403:
            raise AuthorizationError(message, None)
        elif response.status_code == 404:
            raise NotFoundError(message, None)
        elif response.status_code == 409:
            raise ConflictError(message, None)
        elif response.status_code == 429:
            raise RateLimitError(message, 60, None)
        elif response.status_code >= 500:
            if retry_count < self._config.max_retries:
                delay = calculate_exponential_backoff(retry_count, self._config.retry_delay)
                time.sleep(delay)
            raise InternalError(message, None)
        else:
            raise KeplarsError(message, "INTERNAL_ERROR", None, response.status_code)

    def _is_retryable_error(self, error: Exception) -> bool:
        if isinstance(error, httpx.NetworkError):
            return True
        if isinstance(error, httpx.TimeoutException):
            return True
        return False


class AsyncKeplars:
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        retry_delay: float = 1.0,
    ) -> None:
        if not api_key:
            api_key = os.environ.get("KEPLARS_API_KEY")
            if not api_key:
                raise ValueError(
                    "API key is required. Set KEPLARS_API_KEY or pass api_key parameter."
                )

        resolved_base_url = (
            base_url
            or os.environ.get("KEPLARS_BASE_URL")
            or "https://api.keplars.com"
        ).rstrip("/")

        self._config = KeplarsConfig(
            api_key=api_key,
            base_url=resolved_base_url,
            timeout=timeout,
            max_retries=max_retries,
            retry_delay=retry_delay,
        )

        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "keplars-email-python/1.0.0",
            },
        )

        self.emails = AsyncEmailsResource(self)
        self.contacts = AsyncContactsResource(self)
        self.audiences = AsyncAudiencesResource(self)
        self.automations = AsyncAutomationsResource(self)
        self.domains = AsyncDomainsResource(self)

    async def __aenter__(self) -> "AsyncKeplars":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        await self._client.aclose()

    async def _request(
        self, method: str, path: str, data: Optional[Dict[str, Any]] = None, retry_count: int = 0
    ) -> Tuple[Dict[str, Any], Optional[RateLimitInfo]]:
        url = self._config.base_url + path

        try:
            response = await self._client.request(method, url, json=data)
            rate_limit_info = self._extract_rate_limit_info(response)

            if not response.is_success:
                await self._handle_error_response(response, retry_count)

            return response.json(), rate_limit_info

        except httpx.HTTPError as e:
            if self._is_retryable_error(e) and retry_count < self._config.max_retries:
                delay = calculate_exponential_backoff(retry_count, self._config.retry_delay)
                await asyncio.sleep(delay)
                return await self._request(method, path, data, retry_count + 1)

            raise NetworkError(f"Network request failed: {str(e)}", e) from e

    def _extract_rate_limit_info(self, response: httpx.Response) -> Optional[RateLimitInfo]:
        limit = response.headers.get("X-RateLimit-Limit")
        remaining = response.headers.get("X-RateLimit-Remaining")
        reset = response.headers.get("X-RateLimit-Reset")

        if limit and remaining and reset:
            return RateLimitInfo(
                limit=int(limit),
                remaining=int(remaining),
                reset=int(reset),
            )

        return None

    async def _handle_error_response(self, response: httpx.Response, retry_count: int) -> None:
        try:
            error_data = response.json()
        except (ValueError, PydanticValidationError):
            raise KeplarsError(
                f"HTTP {response.status_code}: {response.text}",
                "INTERNAL_ERROR",
                None,
                response.status_code,
            )

        message = error_data.get("message", f"HTTP {response.status_code}")

        if response.status_code == 400:
            raise ValidationError(message, None, None)
        elif response.status_code == 401:
            raise AuthenticationError(message, None)
        elif response.status_code == 403:
            raise AuthorizationError(message, None)
        elif response.status_code == 404:
            raise NotFoundError(message, None)
        elif response.status_code == 409:
            raise ConflictError(message, None)
        elif response.status_code == 429:
            raise RateLimitError(message, 60, None)
        elif response.status_code >= 500:
            if retry_count < self._config.max_retries:
                delay = calculate_exponential_backoff(retry_count, self._config.retry_delay)
                await asyncio.sleep(delay)
            raise InternalError(message, None)
        else:
            raise KeplarsError(message, "INTERNAL_ERROR", None, response.status_code)

    def _is_retryable_error(self, error: Exception) -> bool:
        if isinstance(error, httpx.NetworkError):
            return True
        if isinstance(error, httpx.TimeoutException):
            return True
        return False
