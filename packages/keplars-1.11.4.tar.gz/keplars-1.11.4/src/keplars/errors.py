from typing import Any, Dict, List, Optional


class KeplarsError(Exception):
    def __init__(
        self,
        message: str,
        code: str,
        request_id: Optional[str] = None,
        status_code: Optional[int] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.request_id = request_id
        self.status_code = status_code


class ValidationError(KeplarsError):
    def __init__(
        self,
        message: str,
        details: Optional[List[Dict[str, Any]]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message, "VALIDATION_ERROR", request_id, 400)
        self.details = details


class AuthenticationError(KeplarsError):
    def __init__(self, message: str, request_id: Optional[str] = None) -> None:
        super().__init__(message, "AUTHENTICATION_ERROR", request_id, 401)


class AuthorizationError(KeplarsError):
    def __init__(self, message: str, request_id: Optional[str] = None) -> None:
        super().__init__(message, "AUTHORIZATION_ERROR", request_id, 403)


class DomainNotVerifiedError(KeplarsError):
    def __init__(
        self,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message, "DOMAIN_NOT_VERIFIED", request_id, 403)
        self.details = details


class RateLimitError(KeplarsError):
    def __init__(self, message: str, retry_after: int, request_id: Optional[str] = None) -> None:
        super().__init__(message, "RATE_LIMIT_EXCEEDED", request_id, 429)
        self.retry_after = retry_after


class NotFoundError(KeplarsError):
    def __init__(self, message: str, request_id: Optional[str] = None) -> None:
        super().__init__(message, "NOT_FOUND", request_id, 404)


class PlanLimitError(KeplarsError):
    def __init__(
        self,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message, "PLAN_LIMIT_EXCEEDED", request_id, 403)
        self.details = details


class QuotaExceededError(KeplarsError):
    def __init__(
        self,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message, "QUOTA_EXCEEDED", request_id, 403)
        self.details = details


class ConflictError(KeplarsError):
    def __init__(self, message: str, request_id: Optional[str] = None) -> None:
        super().__init__(message, "CONFLICT", request_id, 409)


class InternalError(KeplarsError):
    def __init__(self, message: str, request_id: Optional[str] = None) -> None:
        super().__init__(message, "INTERNAL_ERROR", request_id, 500)


class NetworkError(KeplarsError):
    def __init__(self, message: str, original_error: Exception) -> None:
        super().__init__(message, "NETWORK_ERROR")
        self.original_error = original_error