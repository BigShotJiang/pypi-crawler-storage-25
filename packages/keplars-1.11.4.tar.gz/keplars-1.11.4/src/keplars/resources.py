from typing import Any, TYPE_CHECKING

from .models import (
    SendEmailRequest,
    SendEmailResponse,
    ScheduleEmailRequest,
    ScheduledEmailResponse,
)

if TYPE_CHECKING:
    from .client import Keplars, AsyncKeplars


class EmailsResource:
    def __init__(self, client: "Keplars") -> None:
        self._client = client

    def send_instant(self, **kwargs: Any) -> SendEmailResponse:
        request = SendEmailRequest(**kwargs)
        request_dict = request.model_dump(by_alias=True, exclude_none=True)
        response_data, _ = self._client._request(
            "POST", "/api/v1/public/send-email/instant", request_dict
        )
        return SendEmailResponse(**response_data)

    def send_high(self, **kwargs: Any) -> SendEmailResponse:
        request = SendEmailRequest(**kwargs)
        request_dict = request.model_dump(by_alias=True, exclude_none=True)
        response_data, _ = self._client._request(
            "POST", "/api/v1/public/send-email/high", request_dict
        )
        return SendEmailResponse(**response_data)

    def send_async(self, **kwargs: Any) -> SendEmailResponse:
        request = SendEmailRequest(**kwargs)
        request_dict = request.model_dump(by_alias=True, exclude_none=True)
        response_data, _ = self._client._request(
            "POST", "/api/v1/public/send-email/async", request_dict
        )
        return SendEmailResponse(**response_data)

    def send_bulk(self, **kwargs: Any) -> SendEmailResponse:
        request = SendEmailRequest(**kwargs)
        request_dict = request.model_dump(by_alias=True, exclude_none=True)
        response_data, _ = self._client._request(
            "POST", "/api/v1/public/send-email/bulk", request_dict
        )
        return SendEmailResponse(**response_data)

    def send(self, **kwargs: Any) -> SendEmailResponse:
        return self.send_async(**kwargs)

    def schedule(self, **kwargs: Any) -> ScheduledEmailResponse:
        request = ScheduleEmailRequest(**kwargs)
        request_dict = request.model_dump(by_alias=True, exclude_none=True)
        response_data, _ = self._client._request(
            "POST", "/api/v1/public/send-email/schedule", request_dict
        )
        return ScheduledEmailResponse(**response_data)


class AsyncEmailsResource:
    def __init__(self, client: "AsyncKeplars") -> None:
        self._client = client

    async def send_instant(self, **kwargs: Any) -> SendEmailResponse:
        request = SendEmailRequest(**kwargs)
        request_dict = request.model_dump(by_alias=True, exclude_none=True)
        response_data, _ = await self._client._request(
            "POST", "/api/v1/public/send-email/instant", request_dict
        )
        return SendEmailResponse(**response_data)

    async def send_high(self, **kwargs: Any) -> SendEmailResponse:
        request = SendEmailRequest(**kwargs)
        request_dict = request.model_dump(by_alias=True, exclude_none=True)
        response_data, _ = await self._client._request(
            "POST", "/api/v1/public/send-email/high", request_dict
        )
        return SendEmailResponse(**response_data)

    async def send_async(self, **kwargs: Any) -> SendEmailResponse:
        request = SendEmailRequest(**kwargs)
        request_dict = request.model_dump(by_alias=True, exclude_none=True)
        response_data, _ = await self._client._request(
            "POST", "/api/v1/public/send-email/async", request_dict
        )
        return SendEmailResponse(**response_data)

    async def send_bulk(self, **kwargs: Any) -> SendEmailResponse:
        request = SendEmailRequest(**kwargs)
        request_dict = request.model_dump(by_alias=True, exclude_none=True)
        response_data, _ = await self._client._request(
            "POST", "/api/v1/public/send-email/bulk", request_dict
        )
        return SendEmailResponse(**response_data)

    async def send(self, **kwargs: Any) -> SendEmailResponse:
        return await self.send_async(**kwargs)

    async def schedule(self, **kwargs: Any) -> ScheduledEmailResponse:
        request = ScheduleEmailRequest(**kwargs)
        request_dict = request.model_dump(by_alias=True, exclude_none=True)
        response_data, _ = await self._client._request(
            "POST", "/api/v1/public/send-email/schedule", request_dict
        )
        return ScheduledEmailResponse(**response_data)
