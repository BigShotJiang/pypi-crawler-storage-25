from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import Keplars, AsyncKeplars


class AutomationsResource:
    def __init__(self, client: "Keplars") -> None:
        self._client = client

    def list(self, page: Optional[int] = None, limit: Optional[int] = None) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit

        query = ""
        if params:
            query = "?" + "&".join(f"{k}={v}" for k, v in params.items())

        response_data, _ = self._client._request(
            "GET", f"/api/v1/public/automations/get-all{query}"
        )
        return response_data

    def get(self, id: str) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "GET", f"/api/v1/public/automations/get-automation/{id}"
        )
        return response_data

    def enroll(self, id: str, email: str) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "POST",
            f"/api/v1/public/automations/add-automation/{id}/enroll",
            {"email": email},
        )
        return response_data

    def unenroll(self, id: str, email: str) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "DELETE",
            f"/api/v1/public/automations/delete-automation/{id}/subscribers",
            {"email": email},
        )
        return response_data


class AsyncAutomationsResource:
    def __init__(self, client: "AsyncKeplars") -> None:
        self._client = client

    async def list(
        self, page: Optional[int] = None, limit: Optional[int] = None
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit

        query = ""
        if params:
            query = "?" + "&".join(f"{k}={v}" for k, v in params.items())

        response_data, _ = await self._client._request(
            "GET", f"/api/v1/public/automations/get-all{query}"
        )
        return response_data

    async def get(self, id: str) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "GET", f"/api/v1/public/automations/get-automation/{id}"
        )
        return response_data

    async def enroll(self, id: str, email: str) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "POST",
            f"/api/v1/public/automations/add-automation/{id}/enroll",
            {"email": email},
        )
        return response_data

    async def unenroll(self, id: str, email: str) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "DELETE",
            f"/api/v1/public/automations/delete-automation/{id}/subscribers",
            {"email": email},
        )
        return response_data
