from typing import Any, Dict, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import Keplars, AsyncKeplars


class DomainsResource:
    def __init__(self, client: "Keplars") -> None:
        self._client = client

    def add(self, domain: str) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "POST", "/api/v1/public/domains/add-domain", {"domain": domain}
        )
        return response_data

    def list(self) -> Dict[str, Any]:
        response_data, _ = self._client._request("GET", "/api/v1/public/domains/get-domains")
        return response_data

    def get_status(self, domain_id: str) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "GET", f"/api/v1/public/domains/domain-status/{domain_id}"
        )
        return response_data

    def verify(self, domain_id: str) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "POST", f"/api/v1/public/domains/verify-domain/{domain_id}"
        )
        return response_data

    def delete(self, domain_id: str) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "DELETE", f"/api/v1/public/domains/delete-domain/{domain_id}"
        )
        return response_data

    def create_api_key(self, **kwargs: Any) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "POST", "/api/v1/public/domains/api-keys/create", kwargs
        )
        return response_data


class AsyncDomainsResource:
    def __init__(self, client: "AsyncKeplars") -> None:
        self._client = client

    async def add(self, domain: str) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "POST", "/api/v1/public/domains/add-domain", {"domain": domain}
        )
        return response_data

    async def list(self) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "GET", "/api/v1/public/domains/get-domains"
        )
        return response_data

    async def get_status(self, domain_id: str) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "GET", f"/api/v1/public/domains/domain-status/{domain_id}"
        )
        return response_data

    async def verify(self, domain_id: str) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "POST", f"/api/v1/public/domains/verify-domain/{domain_id}"
        )
        return response_data

    async def delete(self, domain_id: str) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "DELETE", f"/api/v1/public/domains/delete-domain/{domain_id}"
        )
        return response_data

    async def create_api_key(self, **kwargs: Any) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "POST", "/api/v1/public/domains/api-keys/create", kwargs
        )
        return response_data
