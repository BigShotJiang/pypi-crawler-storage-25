import hashlib
import hmac
import re
import time
from typing import Any, Dict


def calculate_exponential_backoff(retry_count: int, base_delay: float) -> float:
    import random

    exponential_delay = base_delay * (2**retry_count)
    jitter = random.random() * 0.3 * exponential_delay
    return float(min(exponential_delay + jitter, 30.0))


def verify_webhook_signature(
    payload: str,
    signature: str,
    timestamp: str,
    secret: str,
    tolerance_seconds: int = 300,
) -> bool:
    current_timestamp = int(time.time())
    payload_timestamp = int(timestamp)

    if abs(current_timestamp - payload_timestamp) > tolerance_seconds:
        return False

    signed_payload = f"{timestamp}.{payload}"
    expected_signature = hmac.new(
        secret.encode(), signed_payload.encode(), hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(signature, expected_signature)


def render_template(template: str, variables: Dict[str, Any]) -> str:
    def replace_var(match: re.Match[str]) -> str:
        key = match.group(1)
        value = variables.get(key)
        return str(value) if value is not None else match.group(0)

    return re.sub(r"\{\{(\w+)\}\}", replace_var, template)


def validate_email(email: str) -> bool:
    email_regex = r"^[^\s@]+@[^\s@]+\.[^\s@]+$"
    return bool(re.match(email_regex, email))
