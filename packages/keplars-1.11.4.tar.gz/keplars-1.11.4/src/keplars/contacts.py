from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import Keplars, AsyncKeplars


class ContactsResource:
    def __init__(self, client: "Keplars") -> None:
        self._client = client

    def add(self, **kwargs: Any) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "POST", "/api/v1/public/contacts/add-contact", kwargs
        )
        return response_data

    def get(self, email: str) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "GET", f"/api/v1/public/contacts/get-contact?email={email}"
        )
        return response_data

    def list(
        self,
        audience_id: Optional[str] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if audience_id is not None:
            params["audience_id"] = audience_id
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit

        query = ""
        if params:
            query = "?" + "&".join(f"{k}={v}" for k, v in params.items())

        response_data, _ = self._client._request(
            "GET", f"/api/v1/public/contacts/get-contacts{query}"
        )
        return response_data

    def update(self, email: str, **kwargs: Any) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "PATCH",
            f"/api/v1/public/contacts/update-contact?email={email}",
            kwargs,
        )
        return response_data

    def delete(self, email: str) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "DELETE", f"/api/v1/public/contacts/delete-contact?email={email}"
        )
        return response_data


class AsyncContactsResource:
    def __init__(self, client: "AsyncKeplars") -> None:
        self._client = client

    async def add(self, **kwargs: Any) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "POST", "/api/v1/public/contacts/add-contact", kwargs
        )
        return response_data

    async def get(self, email: str) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "GET", f"/api/v1/public/contacts/get-contact?email={email}"
        )
        return response_data

    async def list(
        self,
        audience_id: Optional[str] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if audience_id is not None:
            params["audience_id"] = audience_id
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit

        query = ""
        if params:
            query = "?" + "&".join(f"{k}={v}" for k, v in params.items())

        response_data, _ = await self._client._request(
            "GET", f"/api/v1/public/contacts/get-contacts{query}"
        )
        return response_data

    async def update(self, email: str, **kwargs: Any) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "PATCH",
            f"/api/v1/public/contacts/update-contact?email={email}",
            kwargs,
        )
        return response_data

    async def delete(self, email: str) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "DELETE", f"/api/v1/public/contacts/delete-contact?email={email}"
        )
        return response_data
