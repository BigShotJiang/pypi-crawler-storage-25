from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import Keplars, AsyncKeplars


class AudiencesResource:
    def __init__(self, client: "Keplars") -> None:
        self._client = client

    def create(self, name: str, description: Optional[str] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        response_data, _ = self._client._request(
            "POST", "/api/v1/public/audiences/add-audience", body
        )
        return response_data

    def list(self, page: Optional[int] = None, limit: Optional[int] = None) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit

        query = ""
        if params:
            query = "?" + "&".join(f"{k}={v}" for k, v in params.items())

        response_data, _ = self._client._request(
            "GET", f"/api/v1/public/audiences/get-audiences{query}"
        )
        return response_data

    def get(self, id: str) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "GET", f"/api/v1/public/audiences/get-audience?id={id}"
        )
        return response_data

    def delete(self, id: str) -> Dict[str, Any]:
        response_data, _ = self._client._request(
            "DELETE", f"/api/v1/public/audiences/delete-audience?id={id}"
        )
        return response_data


class AsyncAudiencesResource:
    def __init__(self, client: "AsyncKeplars") -> None:
        self._client = client

    async def create(self, name: str, description: Optional[str] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        response_data, _ = await self._client._request(
            "POST", "/api/v1/public/audiences/add-audience", body
        )
        return response_data

    async def list(
        self, page: Optional[int] = None, limit: Optional[int] = None
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit

        query = ""
        if params:
            query = "?" + "&".join(f"{k}={v}" for k, v in params.items())

        response_data, _ = await self._client._request(
            "GET", f"/api/v1/public/audiences/get-audiences{query}"
        )
        return response_data

    async def get(self, id: str) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "GET", f"/api/v1/public/audiences/get-audience?id={id}"
        )
        return response_data

    async def delete(self, id: str) -> Dict[str, Any]:
        response_data, _ = await self._client._request(
            "DELETE", f"/api/v1/public/audiences/delete-audience?id={id}"
        )
        return response_data
