import os
import re
import json
import logging
import tushare as ts
import pandas as pd
from dotenv import load_dotenv
from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from toon_format import encode
from typing import Dict, List, Optional, Union
from .technical_analysis import TechnicalAnalysis, get_llm_snapshot
from .stock_lookup import get_ts_code
from .read_candles import read_candles, read_candles_full
from .stock_lookup import get_ts_code



load_dotenv()

mcp = FastMCP(name="china-stock-analysis-mcp")

def get_pro():
    ts.set_token(os.getenv("TUSHARE_TOKEN"))
    return ts.pro_api()

def apply_qfq(df_daily: pd.DataFrame, df_adj: pd.DataFrame) -> pd.DataFrame:
    df = pd.merge(df_daily, df_adj[['trade_date', 'adj_factor']], on='trade_date', how='left')
    df = df.sort_values('trade_date').reset_index(drop=True)
    latest_adj = df['adj_factor'].iloc[-1]
    for col in ['open', 'high', 'low', 'close']:
        df[col] = df[col] * df['adj_factor'] / latest_adj
    return df.sort_values('trade_date', ascending=False).reset_index(drop=True)

def resolve_ts_code(name_or_code: str) -> str:
    """
    将公司名称或股票代码统一解析为 ts_code。
    若出错则抛出 ToolError。
    """
    if re.match(r'^\d{6}\.(SZ|SH|BJ)$', name_or_code.strip(), re.IGNORECASE):
        return name_or_code.strip()

    resolved = get_ts_code(name_or_code.strip())
    if not resolved:
        raise ToolError(f"找不到公司 '{name_or_code}' 对应的股票代码")
    if isinstance(resolved, list):
        if len(resolved) == 1:
            return resolved[0]
        else:
            raise ToolError(
                f"公司名称 '{name_or_code}' 匹配到多个结果，请使用更精确的名称或直接输入股票代码。"
                f"候选: {', '.join(resolved)}"
            )
    return resolved
@mcp.tool()
def get_stock_technical_snapshot(
    ts_code: str,
    limit: int = 100,
    use_qfq: bool = True
) -> str:
    """
    获取股票技术分析快照，供 LLM 分析使用。

    Args:
        ts_code: 支持完整的股票代码(如 '002230.SZ'), 不完整的股票代码(如 '002230') 或公司名称（如 '科大讯飞'）
        limit:   获取最近 N 根日线，默认 100
        use_qfq: 是否使用前复权价格，默认 True

    Returns:
        JSON 字符串，包含趋势、动量、波动率、成交量及信号标签
    """
    try:
        resolved_code = resolve_ts_code(ts_code)
        pro = get_pro()
        df_daily = pro.daily(ts_code=resolved_code, limit=limit)

        if use_qfq:
            df_adj = pro.adj_factor(ts_code=resolved_code, trade_date='')
            df = apply_qfq(df_daily, df_adj)
        else:
            df = df_daily

        ta = TechnicalAnalysis(df)
        indicators = ta.get_all_indicators()
        snapshot = get_llm_snapshot(indicators)

        return encode(snapshot)
    except ToolError:
        raise  # 重新抛出 ToolError，让 MCP 正确处理
    except Exception as e:
        logging.exception(f"获取技术分析快照失败: {ts_code}")
        raise ToolError(f"获取技术分析数据失败: {str(e)}")


def clean_income_df(df: pd.DataFrame) -> pd.DataFrame:
    """
    清洗 income 接口返回的原始数据：
    - 只保留合并报表 (report_type=1)
    - 同一报告期保留 update_flag 最新且字段最完整的一条
    """
    df = df[df['report_type'] == '1'].copy()
    df['update_flag'] = pd.to_numeric(df['update_flag'], errors='coerce').fillna(0).astype(int)
    df['non_null_count'] = df.notna().sum(axis=1)
    df = (
        df.sort_values(
            ['end_date', 'update_flag', 'non_null_count'],
            ascending=[True, False, False]
        )
        .drop_duplicates(subset='end_date', keep='first')
        .drop(columns=['non_null_count'])
        .reset_index(drop=True)
    )
    return df

def remove_nulls(obj):
    """递归移除字典/列表中所有值为 None 的字段"""
    if isinstance(obj, dict):
        return {
            k: remove_nulls(v)
            for k, v in obj.items()
            if v is not None and remove_nulls(v) != {}
        }
    elif isinstance(obj, list):
        return [remove_nulls(item) for item in obj]
    else:
        return obj

@mcp.tool()
def get_income_data(
    ts_code: str,
    limit: int = 10
) -> str:
    """
    获取股票利润表数据，包含近几期财务指标及同比变化趋势，供 LLM 分析使用。
    Args:
        ts_code: 股票代码(如 '002230.SZ'), 不完整的股票代码(如 '002230')或公司名称（如 '科大讯飞'）
        limit:   获取最近 N 期报告，默认 8（约2年季报）
    Returns:
        JSON 字符串，包含各期财务指标（万元）、利润率、费用率及同比增速
    """
    try:
        resolved_code = resolve_ts_code(ts_code)
        pro = get_pro()

        df = pro.income(
            ts_code=resolved_code,
            limit=limit,
            fields=(
                'ts_code,end_date,report_type,update_flag,'
                'total_revenue,revenue,'
                'operate_profit,total_profit,n_income_attr_p,'
                'rd_exp,sell_exp,admin_exp,fin_exp,'
                'assets_impair_loss,ebit,ebitda,basic_eps,diluted_eps'
            )
        )

        df = clean_income_df(df)

        def to_wan(val):
            """元 -> 万元，保留1位小数"""
            if pd.isna(val):
                return None
            return round(val / 10000, 1)

        def safe_rate(numerator, denominator, scale=100):
            """安全计算百分比"""
            if pd.isna(numerator) or pd.isna(denominator) or denominator == 0:
                return None
            return round(numerator / denominator * scale, 2)

        def yoy_growth(current, previous):
            """同比增速"""
            if pd.isna(current) or pd.isna(previous) or previous == 0:
                return None
            return round((current - previous) / abs(previous) * 100, 2)

        periods = []
        for i, row in df.iterrows():
            rev = row['revenue']
            net = row['n_income_attr_p']
            op  = row['operate_profit']
            rd  = row['rd_exp']

            yoy_idx = i - 4  # type: ignore
            yoy_row = df.iloc[yoy_idx] if yoy_idx >= 0 else None

            period = {
                "报告期": row['end_date'],
                "规模": {
                    "营业总收入_万元": to_wan(row['total_revenue']),
                    "营业收入_万元":   to_wan(rev),
                },
                "利润": {
                    "营业利润_万元":   to_wan(op),
                    "归母净利润_万元": to_wan(net),
                    "EBIT_万元":       to_wan(row['ebit']),
                    "EBITDA_万元":     to_wan(row['ebitda']),
                    "基本每股收益":    round(row['basic_eps'], 4) if pd.notna(row['basic_eps']) else None,
                },
                "利润率_%": {
                    "营业利润率":   safe_rate(op,  rev),
                    "归母净利润率": safe_rate(net, rev),
                },
                "费用": {
                    "研发费用_万元": to_wan(rd),
                    "销售费用_万元": to_wan(row['sell_exp']),
                    "管理费用_万元": to_wan(row['admin_exp']),
                    "财务费用_万元": to_wan(row['fin_exp']),
                },
                "费用率_%": {
                    "研发费用率": safe_rate(rd,             rev),
                    "销售费用率": safe_rate(row['sell_exp'], rev),
                    "管理费用率": safe_rate(row['admin_exp'], rev),
                },
                "风险": {
                    "资产减值损失_万元": to_wan(row['assets_impair_loss']),
                    "减值预警": (
                        abs(row['assets_impair_loss']) > abs(net) * 0.1
                        if pd.notna(row['assets_impair_loss']) and pd.notna(net) and net != 0
                        else False
                    ),
                },
                "同比增速_%": {
                    "营业收入同比":   yoy_growth(rev, yoy_row['revenue'])         if yoy_row is not None else None,
                    "归母净利润同比": yoy_growth(net, yoy_row['n_income_attr_p']) if yoy_row is not None else None,
                    "研发费用同比":   yoy_growth(rd,  yoy_row['rd_exp'])          if yoy_row is not None else None,
                }
            }
            periods.append(period)

        result = {
            "ts_code":  resolved_code,
            "数据期数": len(periods),
            "说明":     "金额单位为万元，增速单位为%，同比基于去年同期季报",
            "财务历史": periods
        }

        result = remove_nulls(result)

        return encode(result)
    except ToolError:
        raise
    except Exception as e:
        logging.exception(f"获取利润表数据失败: {ts_code}")
        raise ToolError(f"获取利润表数据失败: {str(e)}")
@mcp.tool()
def read_candles_type(
    ts_code: str,
    limit: int = 100,
    use_qfq: bool = True,
    recent_n: Optional[int] = None
) -> str:
    """
    识别 K 线形态（单根、两根、三根、五根组合），返回 JSON 字符串。

    Args:
        ts_code: 支持股票代码(如 '002230.SZ'), 不完整的股票代码(如 '002230')或公司名称（如 '科大讯飞'）
        limit:   获取最近 N 根日线，默认 100
        use_qfq: 是否使用前复权价格，默认 True
        recent_n: 仅分析最近 N 根 K 线，默认 None（使用全量数据）

    Returns:
        JSON 字符串，包含形态识别结果，按形态类型分组
    """
    try:
        resolved_code = resolve_ts_code(ts_code)
        pro = get_pro()
        df_daily = pro.daily(ts_code=resolved_code, limit=limit)

        if use_qfq:
            df_adj = pro.adj_factor(ts_code=resolved_code, trade_date='')
            df = apply_qfq(df_daily, df_adj)
        else:
            df = df_daily

        return encode(json.loads(read_candles(df, recent_n=recent_n)))
    except ToolError:
        raise
    except Exception as e:
        logging.exception(f"识别K线形态失败: {ts_code}")
        raise ToolError(f"识别K线形态失败: {str(e)}")
