"""
Format of content returned by and .
"""

from enum import Enum, auto
import ctypes

class VisionOutputFormat(Enum):
    """Format of content returned by and .."""
    
    JSON = 0
    # Structured JSON with elements sorted by reading order (default). Contains paragraph text, tables, key-value regions, word-level coordinates, and per-page metadata.
    
    MARKDOWN = 1
    # Markdown text optimized for human reading and LLM consumption. Uses standard markdown primitives (headings, paragraphs, tables, blockquotes for footnotes). Loses structural information like coordinates.
    
    IR_LITE = 2
    # IR Lite intermediate representation optimized for LLM position retrieval. Preserves spatial coordinates with a compact token-efficient format.
    
    
    @classmethod
    def from_value(cls, value: int) -> 'VisionOutputFormat':
        """
        Create an enum instance from an integer value.
        
        Args:
            value: The integer value to convert
            
        Returns:
            The corresponding VisionOutputFormat instance
            
        Raises:
            ValueError: If the value doesn't correspond to a valid enum member
        """
        for member in cls:
            if member.value == value:
                return member
        raise ValueError(f"Invalid {cls.__name__} value: {value}")
    
    def to_ctype(self) -> ctypes.c_int:
        """
        Convert to ctypes representation for native calls.
        
        Returns:
            ctypes.c_int: The enum value as a ctypes integer
        """
        return ctypes.c_int(self.value)
    
    def __str__(self) -> str:
        """String representation of the enum value."""
        return f"{self.__class__.__name__}.{self.name}"
    
    def __repr__(self) -> str:
        """Detailed representation of the enum value."""
        return f"<{self.__class__.__name__}.{self.name}: {self.value}>"

__all__ = ['VisionOutputFormat']
