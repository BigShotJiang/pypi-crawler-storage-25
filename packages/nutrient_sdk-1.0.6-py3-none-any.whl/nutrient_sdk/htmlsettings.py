"""
HtmlSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class HtmlSettingsError(NutrientException):
    """Exception raised by HtmlSettings operations."""
    pass

_lib.BridgeHtmlSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeHtmlSettingsGetLastErrorCode.argtypes = []

_lib.BridgeHtmlSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeHtmlSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeHtmlSettingsFreeErrorString.restype = None
_lib.BridgeHtmlSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeHtmlSettingsGetLayout.restype = ctypes.c_int32
_lib.BridgeHtmlSettingsGetLayout.argtypes = [ctypes.c_void_p]

_lib.BridgeHtmlSettingsSetLayoutHtmlLayoutType.restype = None
_lib.BridgeHtmlSettingsSetLayoutHtmlLayoutType.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgeHtmlSettingsGetImageExport.restype = ctypes.c_int32
_lib.BridgeHtmlSettingsGetImageExport.argtypes = [ctypes.c_void_p]

_lib.BridgeHtmlSettingsSetImageExportImageExportMode.restype = None
_lib.BridgeHtmlSettingsSetImageExportImageExportMode.argtypes = [ctypes.c_void_p, ctypes.c_int32]


class HtmlSettings:
    """
    Settings for Html. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate HtmlSettings directly. Use static factory methods instead."""
        raise TypeError("HtmlSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeHtmlSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "HtmlSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeHtmlSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeHtmlSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"HtmlSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=HtmlSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("HtmlSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_layout(self) -> Any:
        """
        The layout type to use when saving HTML documents.

        Returns:
            Any: The value of the Layout property.

        Raises:
            HtmlSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeHtmlSettingsGetLayout(self._handle)
        self._check_error()
        return result

    def set_layout(self, value: Any) -> None:
        """
        The layout type to use when saving HTML documents.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            HtmlSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeHtmlSettingsSetLayoutHtmlLayoutType(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    def get_image_export(self) -> Any:
        """
        Controls how images are exported when converting documents to HTML.

        Returns:
            Any: The value of the ImageExport property.

        Raises:
            HtmlSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeHtmlSettingsGetImageExport(self._handle)
        self._check_error()
        return result

    def set_image_export(self, value: Any) -> None:
        """
        Controls how images are exported when converting documents to HTML.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            HtmlSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeHtmlSettingsSetImageExportImageExportMode(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    @property
    def layout(self) -> Any:
        """
        The layout type to use when saving HTML documents.

        Returns:
            Any: The value of the Layout property.
        """
        return self.get_layout()

    @layout.setter
    def layout(self, value: Any) -> None:
        """
        Sets the layout.

        Args:
            value (Any): The value to set.
        """
        self.set_layout(value)

    @property
    def image_export(self) -> Any:
        """
        Controls how images are exported when converting documents to HTML.

        Returns:
            Any: The value of the ImageExport property.
        """
        return self.get_image_export()

    @image_export.setter
    def image_export(self, value: Any) -> None:
        """
        Sets the image export.

        Args:
            value (Any): The value to set.
        """
        self.set_image_export(value)
