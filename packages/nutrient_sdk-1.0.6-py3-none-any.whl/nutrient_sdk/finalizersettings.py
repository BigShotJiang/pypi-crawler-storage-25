"""
FinalizerSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class FinalizerSettingsError(NutrientException):
    """Exception raised by FinalizerSettings operations."""
    pass

_lib.BridgeFinalizerSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeFinalizerSettingsGetLastErrorCode.argtypes = []

_lib.BridgeFinalizerSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeFinalizerSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeFinalizerSettingsFreeErrorString.restype = None
_lib.BridgeFinalizerSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeFinalizerSettingsGetEnableValidation.restype = ctypes.c_bool
_lib.BridgeFinalizerSettingsGetEnableValidation.argtypes = [ctypes.c_void_p]

_lib.BridgeFinalizerSettingsSetEnableValidationBoolean.restype = None
_lib.BridgeFinalizerSettingsSetEnableValidationBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgeFinalizerSettingsGetMinimumDocumentConfidence.restype = ctypes.c_float
_lib.BridgeFinalizerSettingsGetMinimumDocumentConfidence.argtypes = [ctypes.c_void_p]

_lib.BridgeFinalizerSettingsSetMinimumDocumentConfidenceSingle.restype = None
_lib.BridgeFinalizerSettingsSetMinimumDocumentConfidenceSingle.argtypes = [ctypes.c_void_p, ctypes.c_float]


class FinalizerSettings:
    """
    Settings for Finalizer. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate FinalizerSettings directly. Use static factory methods instead."""
        raise TypeError("FinalizerSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeFinalizerSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "FinalizerSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeFinalizerSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeFinalizerSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"FinalizerSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=FinalizerSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("FinalizerSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_enable_validation(self) -> bool:
        """
        Indicates whether validation of the final document layout is enabled.

        Returns:
            bool: The value of the EnableValidation property.

        Raises:
            FinalizerSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeFinalizerSettingsGetEnableValidation(self._handle)
        self._check_error()
        return result

    def set_enable_validation(self, value: bool) -> None:
        """
        Indicates whether validation of the final document layout is enabled.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            FinalizerSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeFinalizerSettingsSetEnableValidationBoolean(self._handle, value)
        self._check_error()

    def get_minimum_document_confidence(self) -> float:
        """
        Minimum overall confidence threshold for the final document (0.0 - 1.0). Documents with average confidence below this threshold will trigger a validation warning.

        Returns:
            float: The value of the MinimumDocumentConfidence property.

        Raises:
            FinalizerSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeFinalizerSettingsGetMinimumDocumentConfidence(self._handle)
        self._check_error()
        return result

    def set_minimum_document_confidence(self, value: float) -> None:
        """
        Minimum overall confidence threshold for the final document (0.0 - 1.0). Documents with average confidence below this threshold will trigger a validation warning.

        Args:
            value (float)

        Returns:
            None: The result of the operation

        Raises:
            FinalizerSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeFinalizerSettingsSetMinimumDocumentConfidenceSingle(self._handle, value)
        self._check_error()

    @property
    def enable_validation(self) -> bool:
        """
        Indicates whether validation of the final document layout is enabled.

        Returns:
            bool: The value of the EnableValidation property.
        """
        return self.get_enable_validation()

    @enable_validation.setter
    def enable_validation(self, value: bool) -> None:
        """
        Sets the enable validation.

        Args:
            value (bool): The value to set.
        """
        self.set_enable_validation(value)

    @property
    def minimum_document_confidence(self) -> float:
        """
        Minimum overall confidence threshold for the final document (0.0 - 1.0). Documents with average confidence below this threshold will trigger a validation warning.

        Returns:
            float: The value of the MinimumDocumentConfidence property.
        """
        return self.get_minimum_document_confidence()

    @minimum_document_confidence.setter
    def minimum_document_confidence(self, value: float) -> None:
        """
        Sets the minimum document confidence.

        Args:
            value (float): The value to set.
        """
        self.set_minimum_document_confidence(value)
