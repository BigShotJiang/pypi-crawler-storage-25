"""
Signature module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class SignatureError(NutrientException):
    """Exception raised by Signature operations."""
    pass

_lib.BridgeSignatureInitNSDKH.restype = ctypes.c_void_p
_lib.BridgeSignatureInitNSDKH.argtypes = []

_lib.BridgeSignatureCloseNSDKH.restype = None
_lib.BridgeSignatureCloseNSDKH.argtypes = [ctypes.c_void_p]

_lib.BridgeSignatureGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeSignatureGetLastErrorCode.argtypes = []

_lib.BridgeSignatureGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeSignatureGetLastErrorMessage.argtypes = []

_lib.BridgeSignatureFreeErrorString.restype = None
_lib.BridgeSignatureFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeSignatureSignDocumentStringDigitalSignatureOptions.restype = None
_lib.BridgeSignatureSignDocumentStringDigitalSignatureOptions.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeSignatureSignFieldDocumentStringStringDigitalSignatureOptionsSignatureAppearance.restype = None
_lib.BridgeSignatureSignFieldDocumentStringStringDigitalSignatureOptionsSignatureAppearance.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]


class Signature:
    """
    Provides functionality for signing PDF documents. Supports both digital signatures (with certificate) and electronic signatures (visual only).

    The class enables adding signatures to PDF documents: Digital signatures use PFX/P12 certificates to cryptographically sign the document.Electronic signatures add visual representation (image/text) without cryptographic signing. For PAdES-B compliance, use CAdES signature mode (the default). For PAdES-T compliance, configure a in the signature options.
    """

    def __init__(self):
        """Initialize a new Signature instance."""
        self._handle = _lib.BridgeSignatureInitNSDKH()
        if not self._handle:
            self._check_error()
        self._closed = False

    def __del__(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def close(self):
        """Close and cleanup the native resources."""
        if not self._closed and self._handle:
            _lib.BridgeSignatureCloseNSDKH(self._handle)
            self._handle = None
            self._closed = True

    def _check_error(self):
        error_code = _lib.BridgeSignatureGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "Signature")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeSignatureGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeSignatureFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"Signature: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=SignatureError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("Signature instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def sign(self, document: 'Document', output_path: str, options: 'DigitalSignatureOptions') -> None:
        """
        Applies an invisible digital signature to a document.

        Args:
            document ('Document')
            output_path (str)
            options ('DigitalSignatureOptions')

        Returns:
            None: The result of the operation

        Raises:
            SignatureError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeSignatureSignDocumentStringDigitalSignatureOptions(self._handle, document._handle if document else None, output_path.encode('utf-8') if output_path else None, options._handle if options else None)
        self._check_error()

    def sign_field(self, document: 'Document', output_path: str, field_name: str, options: 'DigitalSignatureOptions', appearance: 'SignatureAppearance') -> None:
        """
        Applies a signature to a document using an existing signature field. Supports both digital signatures (with certificate) and electronic signatures (visual only).

        Args:
            document ('Document')
            output_path (str)
            field_name (str)
            options ('DigitalSignatureOptions')
            appearance ('SignatureAppearance')

        Returns:
            None: The result of the operation

        Raises:
            SignatureError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeSignatureSignFieldDocumentStringStringDigitalSignatureOptionsSignatureAppearance(self._handle, document._handle if document else None, output_path.encode('utf-8') if output_path else None, field_name.encode('utf-8') if field_name else None, options._handle if options else None, appearance._handle if appearance else None)
        self._check_error()
