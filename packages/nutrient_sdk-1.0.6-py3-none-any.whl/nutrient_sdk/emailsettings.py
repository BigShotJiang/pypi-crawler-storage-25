"""
EmailSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class EmailSettingsError(NutrientException):
    """Exception raised by EmailSettings operations."""
    pass

_lib.BridgeEmailSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeEmailSettingsGetLastErrorCode.argtypes = []

_lib.BridgeEmailSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeEmailSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeEmailSettingsFreeErrorString.restype = None
_lib.BridgeEmailSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeEmailSettingsGetLanguage.restype = ctypes.c_void_p
_lib.BridgeEmailSettingsGetLanguage.argtypes = [ctypes.c_void_p]

_lib.BridgeEmailSettingsSetLanguageString.restype = None
_lib.BridgeEmailSettingsSetLanguageString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]


class EmailSettings:
    """
    Settings for Email. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate EmailSettings directly. Use static factory methods instead."""
        raise TypeError("EmailSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeEmailSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "EmailSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeEmailSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeEmailSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"EmailSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=EmailSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("EmailSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_language(self) -> str:
        """
        The preferred language for conversion, as a BCP 47 language tag (e.g. "fr-FR", "en-US"). Controls date/time formatting and label translations in the converted document.

        Returns:
            str: The value of the Language property.

        Raises:
            EmailSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeEmailSettingsGetLanguage(self._handle)
        self._check_error()
        return sdk_loader.convert_string_handle(result)

    def set_language(self, value: str) -> None:
        """
        The preferred language for conversion, as a BCP 47 language tag (e.g. "fr-FR", "en-US"). Controls date/time formatting and label translations in the converted document.

        Args:
            value (str)

        Returns:
            None: The result of the operation

        Raises:
            EmailSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeEmailSettingsSetLanguageString(self._handle, value.encode('utf-8') if value else None)
        self._check_error()

    @property
    def language(self) -> str:
        """
        The preferred language for conversion, as a BCP 47 language tag (e.g. "fr-FR", "en-US"). Controls date/time formatting and label translations in the converted document.

        Returns:
            str: The value of the Language property.
        """
        return self.get_language()

    @language.setter
    def language(self, value: str) -> None:
        """
        Sets the language.

        Args:
            value (str): The value to set.
        """
        self.set_language(value)
