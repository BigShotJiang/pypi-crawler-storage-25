"""
Strategy for how zones are sent to the VLM for classification.
"""

from enum import Enum, auto
import ctypes

class VlmClassificationStrategy(Enum):
    """Strategy for how zones are sent to the VLM for classification.."""
    
    ONE_SHOT = 0
    # Send a single full-page image with bounding box coordinates in the prompt. The VLM performs spatial reasoning to classify each zone by its bbox.
    
    MULTI_ZONE = 1
    # Crop each zone from the source image and send multiple zone images per VLM call. The VLM classifies each cropped image by its visual content. Supports batching (BatchSize) and parallel execution (MaxConcurrency).
    
    
    @classmethod
    def from_value(cls, value: int) -> 'VlmClassificationStrategy':
        """
        Create an enum instance from an integer value.
        
        Args:
            value: The integer value to convert
            
        Returns:
            The corresponding VlmClassificationStrategy instance
            
        Raises:
            ValueError: If the value doesn't correspond to a valid enum member
        """
        for member in cls:
            if member.value == value:
                return member
        raise ValueError(f"Invalid {cls.__name__} value: {value}")
    
    def to_ctype(self) -> ctypes.c_int:
        """
        Convert to ctypes representation for native calls.
        
        Returns:
            ctypes.c_int: The enum value as a ctypes integer
        """
        return ctypes.c_int(self.value)
    
    def __str__(self) -> str:
        """String representation of the enum value."""
        return f"{self.__class__.__name__}.{self.name}"
    
    def __repr__(self) -> str:
        """Detailed representation of the enum value."""
        return f"<{self.__class__.__name__}.{self.name}: {self.value}>"

__all__ = ['VlmClassificationStrategy']
