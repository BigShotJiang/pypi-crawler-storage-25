"""
InstantJsonSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class InstantJsonSettingsError(NutrientException):
    """Exception raised by InstantJsonSettings operations."""
    pass

_lib.BridgeInstantJsonSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeInstantJsonSettingsGetLastErrorCode.argtypes = []

_lib.BridgeInstantJsonSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeInstantJsonSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeInstantJsonSettingsFreeErrorString.restype = None
_lib.BridgeInstantJsonSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeInstantJsonSettingsGetRenderTheme.restype = ctypes.c_int32
_lib.BridgeInstantJsonSettingsGetRenderTheme.argtypes = [ctypes.c_void_p]

_lib.BridgeInstantJsonSettingsSetRenderThemeInstantJsonRenderTheme.restype = None
_lib.BridgeInstantJsonSettingsSetRenderThemeInstantJsonRenderTheme.argtypes = [ctypes.c_void_p, ctypes.c_int32]


class InstantJsonSettings:
    """
    Settings for InstantJson. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate InstantJsonSettings directly. Use static factory methods instead."""
        raise TypeError("InstantJsonSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeInstantJsonSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "InstantJsonSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeInstantJsonSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeInstantJsonSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"InstantJsonSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=InstantJsonSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("InstantJsonSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_render_theme(self) -> Any:
        """
        The annotation appearance theme to use when importing Instant JSON.

        Returns:
            Any: The value of the RenderTheme property.

        Raises:
            InstantJsonSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeInstantJsonSettingsGetRenderTheme(self._handle)
        self._check_error()
        return result

    def set_render_theme(self, value: Any) -> None:
        """
        The annotation appearance theme to use when importing Instant JSON.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            InstantJsonSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeInstantJsonSettingsSetRenderThemeInstantJsonRenderTheme(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    @property
    def render_theme(self) -> Any:
        """
        The annotation appearance theme to use when importing Instant JSON.

        Returns:
            Any: The value of the RenderTheme property.
        """
        return self.get_render_theme()

    @render_theme.setter
    def render_theme(self, value: Any) -> None:
        """
        Sets the render theme.

        Args:
            value (Any): The value to set.
        """
        self.set_render_theme(value)
