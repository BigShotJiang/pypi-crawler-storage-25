"""
OpenAIApiEndpointSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class OpenAIApiEndpointSettingsError(NutrientException):
    """Exception raised by OpenAIApiEndpointSettings operations."""
    pass

_lib.BridgeOpenAIApiEndpointSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeOpenAIApiEndpointSettingsGetLastErrorCode.argtypes = []

_lib.BridgeOpenAIApiEndpointSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeOpenAIApiEndpointSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeOpenAIApiEndpointSettingsFreeErrorString.restype = None
_lib.BridgeOpenAIApiEndpointSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsGetApiKey.restype = ctypes.c_void_p
_lib.BridgeOpenAIApiEndpointSettingsGetApiKey.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsSetApiKeyString.restype = None
_lib.BridgeOpenAIApiEndpointSettingsSetApiKeyString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsGetApiEndpoint.restype = ctypes.c_void_p
_lib.BridgeOpenAIApiEndpointSettingsGetApiEndpoint.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsSetApiEndpointString.restype = None
_lib.BridgeOpenAIApiEndpointSettingsSetApiEndpointString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsGetModel.restype = ctypes.c_void_p
_lib.BridgeOpenAIApiEndpointSettingsGetModel.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsSetModelString.restype = None
_lib.BridgeOpenAIApiEndpointSettingsSetModelString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsGetTemperature.restype = ctypes.c_double
_lib.BridgeOpenAIApiEndpointSettingsGetTemperature.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsSetTemperatureDouble.restype = None
_lib.BridgeOpenAIApiEndpointSettingsSetTemperatureDouble.argtypes = [ctypes.c_void_p, ctypes.c_double]

_lib.BridgeOpenAIApiEndpointSettingsGetMaxTokens.restype = ctypes.c_int32
_lib.BridgeOpenAIApiEndpointSettingsGetMaxTokens.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsSetMaxTokensInt32.restype = None
_lib.BridgeOpenAIApiEndpointSettingsSetMaxTokensInt32.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgeOpenAIApiEndpointSettingsGetSystemPrompt.restype = ctypes.c_void_p
_lib.BridgeOpenAIApiEndpointSettingsGetSystemPrompt.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsSetSystemPromptString.restype = None
_lib.BridgeOpenAIApiEndpointSettingsSetSystemPromptString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsGetStream.restype = ctypes.c_bool
_lib.BridgeOpenAIApiEndpointSettingsGetStream.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsSetStreamBoolean.restype = None
_lib.BridgeOpenAIApiEndpointSettingsSetStreamBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgeOpenAIApiEndpointSettingsGetClassificationStrategy.restype = ctypes.c_int32
_lib.BridgeOpenAIApiEndpointSettingsGetClassificationStrategy.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsSetClassificationStrategyVlmClassificationStrategy.restype = None
_lib.BridgeOpenAIApiEndpointSettingsSetClassificationStrategyVlmClassificationStrategy.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgeOpenAIApiEndpointSettingsGetSendFullPageReference.restype = ctypes.c_bool
_lib.BridgeOpenAIApiEndpointSettingsGetSendFullPageReference.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsSetSendFullPageReferenceBoolean.restype = None
_lib.BridgeOpenAIApiEndpointSettingsSetSendFullPageReferenceBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgeOpenAIApiEndpointSettingsGetBatchSize.restype = ctypes.c_int32
_lib.BridgeOpenAIApiEndpointSettingsGetBatchSize.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsSetBatchSizeInt32.restype = None
_lib.BridgeOpenAIApiEndpointSettingsSetBatchSizeInt32.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgeOpenAIApiEndpointSettingsGetMaxConcurrency.restype = ctypes.c_int32
_lib.BridgeOpenAIApiEndpointSettingsGetMaxConcurrency.argtypes = [ctypes.c_void_p]

_lib.BridgeOpenAIApiEndpointSettingsSetMaxConcurrencyInt32.restype = None
_lib.BridgeOpenAIApiEndpointSettingsSetMaxConcurrencyInt32.argtypes = [ctypes.c_void_p, ctypes.c_int32]


class OpenAIApiEndpointSettings:
    """
    Settings for OpenAIApiEndpoint. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate OpenAIApiEndpointSettings directly. Use static factory methods instead."""
        raise TypeError("OpenAIApiEndpointSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeOpenAIApiEndpointSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "OpenAIApiEndpointSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeOpenAIApiEndpointSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeOpenAIApiEndpointSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"OpenAIApiEndpointSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=OpenAIApiEndpointSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("OpenAIApiEndpointSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_api_key(self) -> str:
        """
        OpenAI API key for authentication.

        Returns:
            str: The value of the ApiKey property.

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeOpenAIApiEndpointSettingsGetApiKey(self._handle)
        self._check_error()
        return sdk_loader.convert_string_handle(result)

    def set_api_key(self, value: str) -> None:
        """
        OpenAI API key for authentication.

        Args:
            value (str)

        Returns:
            None: The result of the operation

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeOpenAIApiEndpointSettingsSetApiKeyString(self._handle, value.encode('utf-8') if value else None)
        self._check_error()

    def get_api_endpoint(self) -> str:
        """
        API endpoint URL for OpenAI-compatible chat completions

        Returns:
            str: The value of the ApiEndpoint property.

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeOpenAIApiEndpointSettingsGetApiEndpoint(self._handle)
        self._check_error()
        return sdk_loader.convert_string_handle(result)

    def set_api_endpoint(self, value: str) -> None:
        """
        API endpoint URL for OpenAI-compatible chat completions

        Args:
            value (str)

        Returns:
            None: The result of the operation

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeOpenAIApiEndpointSettingsSetApiEndpointString(self._handle, value.encode('utf-8') if value else None)
        self._check_error()

    def get_model(self) -> str:
        """
        Model identifier to use for classification

        Returns:
            str: The value of the Model property.

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeOpenAIApiEndpointSettingsGetModel(self._handle)
        self._check_error()
        return sdk_loader.convert_string_handle(result)

    def set_model(self, value: str) -> None:
        """
        Model identifier to use for classification

        Args:
            value (str)

        Returns:
            None: The result of the operation

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeOpenAIApiEndpointSettingsSetModelString(self._handle, value.encode('utf-8') if value else None)
        self._check_error()

    def get_temperature(self) -> float:
        """
        Temperature for response generation (0.0 = deterministic, 1.0 = creative)

        Returns:
            float: The value of the Temperature property.

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeOpenAIApiEndpointSettingsGetTemperature(self._handle)
        self._check_error()
        return result

    def set_temperature(self, value: float) -> None:
        """
        Temperature for response generation (0.0 = deterministic, 1.0 = creative)

        Args:
            value (float)

        Returns:
            None: The result of the operation

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeOpenAIApiEndpointSettingsSetTemperatureDouble(self._handle, value)
        self._check_error()

    def get_max_tokens(self) -> int:
        """
        Maximum tokens in response (-1 = unlimited)

        Returns:
            int: The value of the MaxTokens property.

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeOpenAIApiEndpointSettingsGetMaxTokens(self._handle)
        self._check_error()
        return result

    def set_max_tokens(self, value: int) -> None:
        """
        Maximum tokens in response (-1 = unlimited)

        Args:
            value (int)

        Returns:
            None: The result of the operation

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeOpenAIApiEndpointSettingsSetMaxTokensInt32(self._handle, value)
        self._check_error()

    def get_system_prompt(self) -> str:
        """
        Optional custom system prompt for zone classification. When empty, the module uses a default prompt based on the ClassificationStrategy.

        Returns:
            str: The value of the SystemPrompt property.

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeOpenAIApiEndpointSettingsGetSystemPrompt(self._handle)
        self._check_error()
        return sdk_loader.convert_string_handle(result)

    def set_system_prompt(self, value: str) -> None:
        """
        Optional custom system prompt for zone classification. When empty, the module uses a default prompt based on the ClassificationStrategy.

        Args:
            value (str)

        Returns:
            None: The result of the operation

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeOpenAIApiEndpointSettingsSetSystemPromptString(self._handle, value.encode('utf-8') if value else None)
        self._check_error()

    def get_stream(self) -> bool:
        """
        Whether to stream responses from the API

        Returns:
            bool: The value of the Stream property.

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeOpenAIApiEndpointSettingsGetStream(self._handle)
        self._check_error()
        return result

    def set_stream(self, value: bool) -> None:
        """
        Whether to stream responses from the API

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeOpenAIApiEndpointSettingsSetStreamBoolean(self._handle, value)
        self._check_error()

    def get_classification_strategy(self) -> Any:
        """
        Strategy for how zones are sent to the VLM for classification.

        Returns:
            Any: The value of the ClassificationStrategy property.

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeOpenAIApiEndpointSettingsGetClassificationStrategy(self._handle)
        self._check_error()
        return result

    def set_classification_strategy(self, value: Any) -> None:
        """
        Strategy for how zones are sent to the VLM for classification.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeOpenAIApiEndpointSettingsSetClassificationStrategyVlmClassificationStrategy(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    def get_send_full_page_reference(self) -> bool:
        """
        Whether to send the full page image as reference context alongside cropped zones. Only used when UseZoneCropping is true.

        Returns:
            bool: The value of the SendFullPageReference property.

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeOpenAIApiEndpointSettingsGetSendFullPageReference(self._handle)
        self._check_error()
        return result

    def set_send_full_page_reference(self, value: bool) -> None:
        """
        Whether to send the full page image as reference context alongside cropped zones. Only used when UseZoneCropping is true.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeOpenAIApiEndpointSettingsSetSendFullPageReferenceBoolean(self._handle, value)
        self._check_error()

    def get_batch_size(self) -> int:
        """
        Number of zone images to include per VLM API call.

        Returns:
            int: The value of the BatchSize property.

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeOpenAIApiEndpointSettingsGetBatchSize(self._handle)
        self._check_error()
        return result

    def set_batch_size(self, value: int) -> None:
        """
        Number of zone images to include per VLM API call.

        Args:
            value (int)

        Returns:
            None: The result of the operation

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeOpenAIApiEndpointSettingsSetBatchSizeInt32(self._handle, value)
        self._check_error()

    def get_max_concurrency(self) -> int:
        """
        Maximum number of concurrent VLM API calls.

        Returns:
            int: The value of the MaxConcurrency property.

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeOpenAIApiEndpointSettingsGetMaxConcurrency(self._handle)
        self._check_error()
        return result

    def set_max_concurrency(self, value: int) -> None:
        """
        Maximum number of concurrent VLM API calls.

        Args:
            value (int)

        Returns:
            None: The result of the operation

        Raises:
            OpenAIApiEndpointSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeOpenAIApiEndpointSettingsSetMaxConcurrencyInt32(self._handle, value)
        self._check_error()

    @property
    def api_key(self) -> str:
        """
        OpenAI API key for authentication.

        Returns:
            str: The value of the ApiKey property.
        """
        return self.get_api_key()

    @api_key.setter
    def api_key(self, value: str) -> None:
        """
        Sets the api key.

        Args:
            value (str): The value to set.
        """
        self.set_api_key(value)

    @property
    def api_endpoint(self) -> str:
        """
        API endpoint URL for OpenAI-compatible chat completions

        Returns:
            str: The value of the ApiEndpoint property.
        """
        return self.get_api_endpoint()

    @api_endpoint.setter
    def api_endpoint(self, value: str) -> None:
        """
        Sets the api endpoint.

        Args:
            value (str): The value to set.
        """
        self.set_api_endpoint(value)

    @property
    def model(self) -> str:
        """
        Model identifier to use for classification

        Returns:
            str: The value of the Model property.
        """
        return self.get_model()

    @model.setter
    def model(self, value: str) -> None:
        """
        Sets the model.

        Args:
            value (str): The value to set.
        """
        self.set_model(value)

    @property
    def temperature(self) -> float:
        """
        Temperature for response generation (0.0 = deterministic, 1.0 = creative)

        Returns:
            float: The value of the Temperature property.
        """
        return self.get_temperature()

    @temperature.setter
    def temperature(self, value: float) -> None:
        """
        Sets the temperature.

        Args:
            value (float): The value to set.
        """
        self.set_temperature(value)

    @property
    def max_tokens(self) -> int:
        """
        Maximum tokens in response (-1 = unlimited)

        Returns:
            int: The value of the MaxTokens property.
        """
        return self.get_max_tokens()

    @max_tokens.setter
    def max_tokens(self, value: int) -> None:
        """
        Sets the max tokens.

        Args:
            value (int): The value to set.
        """
        self.set_max_tokens(value)

    @property
    def system_prompt(self) -> str:
        """
        Optional custom system prompt for zone classification. When empty, the module uses a default prompt based on the ClassificationStrategy.

        Returns:
            str: The value of the SystemPrompt property.
        """
        return self.get_system_prompt()

    @system_prompt.setter
    def system_prompt(self, value: str) -> None:
        """
        Sets the system prompt.

        Args:
            value (str): The value to set.
        """
        self.set_system_prompt(value)

    @property
    def stream(self) -> bool:
        """
        Whether to stream responses from the API

        Returns:
            bool: The value of the Stream property.
        """
        return self.get_stream()

    @stream.setter
    def stream(self, value: bool) -> None:
        """
        Sets the stream.

        Args:
            value (bool): The value to set.
        """
        self.set_stream(value)

    @property
    def classification_strategy(self) -> Any:
        """
        Strategy for how zones are sent to the VLM for classification.

        Returns:
            Any: The value of the ClassificationStrategy property.
        """
        return self.get_classification_strategy()

    @classification_strategy.setter
    def classification_strategy(self, value: Any) -> None:
        """
        Sets the classification strategy.

        Args:
            value (Any): The value to set.
        """
        self.set_classification_strategy(value)

    @property
    def send_full_page_reference(self) -> bool:
        """
        Whether to send the full page image as reference context alongside cropped zones. Only used when UseZoneCropping is true.

        Returns:
            bool: The value of the SendFullPageReference property.
        """
        return self.get_send_full_page_reference()

    @send_full_page_reference.setter
    def send_full_page_reference(self, value: bool) -> None:
        """
        Sets the send full page reference.

        Args:
            value (bool): The value to set.
        """
        self.set_send_full_page_reference(value)

    @property
    def batch_size(self) -> int:
        """
        Number of zone images to include per VLM API call.

        Returns:
            int: The value of the BatchSize property.
        """
        return self.get_batch_size()

    @batch_size.setter
    def batch_size(self, value: int) -> None:
        """
        Sets the batch size.

        Args:
            value (int): The value to set.
        """
        self.set_batch_size(value)

    @property
    def max_concurrency(self) -> int:
        """
        Maximum number of concurrent VLM API calls.

        Returns:
            int: The value of the MaxConcurrency property.
        """
        return self.get_max_concurrency()

    @max_concurrency.setter
    def max_concurrency(self, value: int) -> None:
        """
        Sets the max concurrency.

        Args:
            value (int): The value to set.
        """
        self.set_max_concurrency(value)
