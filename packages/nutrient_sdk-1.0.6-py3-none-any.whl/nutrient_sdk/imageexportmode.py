"""
Specifies how images are handled during document export to markup formats (Markdown, HTML).
"""

from enum import Enum, auto
import ctypes

class ImageExportMode(Enum):
    """Specifies how images are handled during document export to markup formats (Markdown, HTML).."""
    
    NONE = 0
    # Images are not included in the exported output.
    
    EMBEDDED = 1
    # Images are embedded inline as base64-encoded data URIs.
    
    EXTERNAL = 2
    # Images are saved as separate files in a sibling "{output}_resources" folder next to the output file and referenced by relative path. Requires writing to a file path (or a ) so the resources folder can be derived from the output file name.
    
    
    @classmethod
    def from_value(cls, value: int) -> 'ImageExportMode':
        """
        Create an enum instance from an integer value.
        
        Args:
            value: The integer value to convert
            
        Returns:
            The corresponding ImageExportMode instance
            
        Raises:
            ValueError: If the value doesn't correspond to a valid enum member
        """
        for member in cls:
            if member.value == value:
                return member
        raise ValueError(f"Invalid {cls.__name__} value: {value}")
    
    def to_ctype(self) -> ctypes.c_int:
        """
        Convert to ctypes representation for native calls.
        
        Returns:
            ctypes.c_int: The enum value as a ctypes integer
        """
        return ctypes.c_int(self.value)
    
    def __str__(self) -> str:
        """String representation of the enum value."""
        return f"{self.__class__.__name__}.{self.name}"
    
    def __repr__(self) -> str:
        """Detailed representation of the enum value."""
        return f"<{self.__class__.__name__}.{self.name}: {self.value}>"

__all__ = ['ImageExportMode']
