"""
PresentationSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class PresentationSettingsError(NutrientException):
    """Exception raised by PresentationSettings operations."""
    pass

_lib.BridgePresentationSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgePresentationSettingsGetLastErrorCode.argtypes = []

_lib.BridgePresentationSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgePresentationSettingsGetLastErrorMessage.argtypes = []

_lib.BridgePresentationSettingsFreeErrorString.restype = None
_lib.BridgePresentationSettingsFreeErrorString.argtypes = [ctypes.c_void_p]


class PresentationSettings:
    """
    Settings for Presentation. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate PresentationSettings directly. Use static factory methods instead."""
        raise TypeError("PresentationSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgePresentationSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "PresentationSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgePresentationSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgePresentationSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"PresentationSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=PresentationSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("PresentationSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance
