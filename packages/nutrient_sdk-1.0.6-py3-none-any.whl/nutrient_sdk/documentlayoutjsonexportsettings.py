"""
DocumentLayoutJsonExportSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class DocumentLayoutJsonExportSettingsError(NutrientException):
    """Exception raised by DocumentLayoutJsonExportSettings operations."""
    pass

_lib.BridgeDocumentLayoutJsonExportSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeDocumentLayoutJsonExportSettingsGetLastErrorCode.argtypes = []

_lib.BridgeDocumentLayoutJsonExportSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeDocumentLayoutJsonExportSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeDocumentLayoutJsonExportSettingsFreeErrorString.restype = None
_lib.BridgeDocumentLayoutJsonExportSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeDocumentLayoutJsonExportSettingsGetContent.restype = ctypes.c_int32
_lib.BridgeDocumentLayoutJsonExportSettingsGetContent.argtypes = [ctypes.c_void_p]

_lib.BridgeDocumentLayoutJsonExportSettingsSetContentJsonExportContent.restype = None
_lib.BridgeDocumentLayoutJsonExportSettingsSetContentJsonExportContent.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgeDocumentLayoutJsonExportSettingsGetFormat.restype = ctypes.c_int32
_lib.BridgeDocumentLayoutJsonExportSettingsGetFormat.argtypes = [ctypes.c_void_p]

_lib.BridgeDocumentLayoutJsonExportSettingsSetFormatJsonExportFormat.restype = None
_lib.BridgeDocumentLayoutJsonExportSettingsSetFormatJsonExportFormat.argtypes = [ctypes.c_void_p, ctypes.c_int32]


class DocumentLayoutJsonExportSettings:
    """
    Settings for DocumentLayoutJsonExport. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate DocumentLayoutJsonExportSettings directly. Use static factory methods instead."""
        raise TypeError("DocumentLayoutJsonExportSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeDocumentLayoutJsonExportSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "DocumentLayoutJsonExportSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeDocumentLayoutJsonExportSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeDocumentLayoutJsonExportSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"DocumentLayoutJsonExportSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=DocumentLayoutJsonExportSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("DocumentLayoutJsonExportSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_content(self) -> Any:
        """
        The content elements to include in JSON output.

        Returns:
            Any: The value of the Content property.

        Raises:
            DocumentLayoutJsonExportSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeDocumentLayoutJsonExportSettingsGetContent(self._handle)
        self._check_error()
        return result

    def set_content(self, value: Any) -> None:
        """
        The content elements to include in JSON output.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            DocumentLayoutJsonExportSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeDocumentLayoutJsonExportSettingsSetContentJsonExportContent(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    def get_format(self) -> Any:
        """
        The formatting options for JSON output.

        Returns:
            Any: The value of the Format property.

        Raises:
            DocumentLayoutJsonExportSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeDocumentLayoutJsonExportSettingsGetFormat(self._handle)
        self._check_error()
        return result

    def set_format(self, value: Any) -> None:
        """
        The formatting options for JSON output.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            DocumentLayoutJsonExportSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeDocumentLayoutJsonExportSettingsSetFormatJsonExportFormat(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    @property
    def content(self) -> Any:
        """
        The content elements to include in JSON output.

        Returns:
            Any: The value of the Content property.
        """
        return self.get_content()

    @content.setter
    def content(self, value: Any) -> None:
        """
        Sets the content.

        Args:
            value (Any): The value to set.
        """
        self.set_content(value)

    @property
    def format(self) -> Any:
        """
        The formatting options for JSON output.

        Returns:
            Any: The value of the Format property.
        """
        return self.get_format()

    @format.setter
    def format(self, value: Any) -> None:
        """
        Sets the format.

        Args:
            value (Any): The value to set.
        """
        self.set_format(value)
