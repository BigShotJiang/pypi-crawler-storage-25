"""
SdkSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class SdkSettingsError(NutrientException):
    """Exception raised by SdkSettings operations."""
    pass

_lib.BridgeSdkSettingsInitNSDKH.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsInitNSDKH.argtypes = []

_lib.BridgeSdkSettingsCloseNSDKH.restype = None
_lib.BridgeSdkSettingsCloseNSDKH.argtypes = [ctypes.c_void_p]

_lib.BridgeSdkSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeSdkSettingsGetLastErrorCode.argtypes = []

_lib.BridgeSdkSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeSdkSettingsFreeErrorString.restype = None
_lib.BridgeSdkSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeSdkSettingsLoadInstanceString.restype = None
_lib.BridgeSdkSettingsLoadInstanceString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeSdkSettingsExportInstanceString.restype = None
_lib.BridgeSdkSettingsExportInstanceString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeSdkSettingsLoadString.restype = None
_lib.BridgeSdkSettingsLoadString.argtypes = [ctypes.c_void_p]

_lib.BridgeSdkSettingsExportString.restype = None
_lib.BridgeSdkSettingsExportString.argtypes = [ctypes.c_void_p]

_lib.BridgeSdkSettingsGetAiAugmenterSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetAiAugmenterSettings.argtypes = []

_lib.BridgeSdkSettingsGetAiProcessingSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetAiProcessingSettings.argtypes = []

_lib.BridgeSdkSettingsGetCadSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetCadSettings.argtypes = []

_lib.BridgeSdkSettingsGetClaudeApiSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetClaudeApiSettings.argtypes = []

_lib.BridgeSdkSettingsGetContentExtractionSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetContentExtractionSettings.argtypes = []

_lib.BridgeSdkSettingsGetConversionSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetConversionSettings.argtypes = []

_lib.BridgeSdkSettingsGetCustomVlmApiSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetCustomVlmApiSettings.argtypes = []

_lib.BridgeSdkSettingsGetDeskewSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetDeskewSettings.argtypes = []

_lib.BridgeSdkSettingsGetDocumentLayoutJsonExportSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetDocumentLayoutJsonExportSettings.argtypes = []

_lib.BridgeSdkSettingsGetEmailSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetEmailSettings.argtypes = []

_lib.BridgeSdkSettingsGetFinalizerSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetFinalizerSettings.argtypes = []

_lib.BridgeSdkSettingsGetFormRecognitionSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetFormRecognitionSettings.argtypes = []

_lib.BridgeSdkSettingsGetHandwritingSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetHandwritingSettings.argtypes = []

_lib.BridgeSdkSettingsGetHtmlSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetHtmlSettings.argtypes = []

_lib.BridgeSdkSettingsGetImageSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetImageSettings.argtypes = []

_lib.BridgeSdkSettingsGetInferenceLayoutSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetInferenceLayoutSettings.argtypes = []

_lib.BridgeSdkSettingsGetInstantJsonSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetInstantJsonSettings.argtypes = []

_lib.BridgeSdkSettingsGetJbig2Settings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetJbig2Settings.argtypes = []

_lib.BridgeSdkSettingsGetJpegSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetJpegSettings.argtypes = []

_lib.BridgeSdkSettingsGetMarkdownSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetMarkdownSettings.argtypes = []

_lib.BridgeSdkSettingsGetOcrSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetOcrSettings.argtypes = []

_lib.BridgeSdkSettingsGetOpenAIApiEndpointSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetOpenAIApiEndpointSettings.argtypes = []

_lib.BridgeSdkSettingsGetOpenAILanguagesDetectionSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetOpenAILanguagesDetectionSettings.argtypes = []

_lib.BridgeSdkSettingsGetOpenAIPictureAltSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetOpenAIPictureAltSettings.argtypes = []

_lib.BridgeSdkSettingsGetOpenSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetOpenSettings.argtypes = []

_lib.BridgeSdkSettingsGetPdfPageSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetPdfPageSettings.argtypes = []

_lib.BridgeSdkSettingsGetPdfSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetPdfSettings.argtypes = []

_lib.BridgeSdkSettingsGetPresentationSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetPresentationSettings.argtypes = []

_lib.BridgeSdkSettingsGetReadingOrderSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetReadingOrderSettings.argtypes = []

_lib.BridgeSdkSettingsGetSegmenterSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetSegmenterSettings.argtypes = []

_lib.BridgeSdkSettingsGetSpreadsheetSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetSpreadsheetSettings.argtypes = []

_lib.BridgeSdkSettingsGetTableRecognitionSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetTableRecognitionSettings.argtypes = []

_lib.BridgeSdkSettingsGetTiffSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetTiffSettings.argtypes = []

_lib.BridgeSdkSettingsGetVisionDescriptorSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetVisionDescriptorSettings.argtypes = []

_lib.BridgeSdkSettingsGetVisionSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetVisionSettings.argtypes = []

_lib.BridgeSdkSettingsGetWordsDetectionSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetWordsDetectionSettings.argtypes = []

_lib.BridgeSdkSettingsGetWordSettings.restype = ctypes.c_void_p
_lib.BridgeSdkSettingsGetWordSettings.argtypes = []


class SdkSettings:
    """
    Manages configuration settings for the Nutrient SDK. Provides functionality to load, export, and access various SDK settings through a type-safe registry system. This is a singleton class - use the static methods to access SDK settings.
    """

    def __init__(self):
        """Initialize a new SdkSettings instance."""
        self._handle = _lib.BridgeSdkSettingsInitNSDKH()
        if not self._handle:
            self._check_error()
        self._closed = False

    def __del__(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def close(self):
        """Close and cleanup the native resources."""
        if not self._closed and self._handle:
            _lib.BridgeSdkSettingsCloseNSDKH(self._handle)
            self._handle = None
            self._closed = True

    def _check_error(self):
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "SdkSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeSdkSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeSdkSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"SdkSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=SdkSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("SdkSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def load_instance(self, path: str) -> None:
        """
        Loads SDK settings from a JSON file.

        Args:
            path (str)

        Returns:
            None: The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeSdkSettingsLoadInstanceString(self._handle, path.encode('utf-8') if path else None)
        self._check_error()

    def export_instance(self, path: str) -> None:
        """
        Exports the current SDK settings to a JSON file.

        Args:
            path (str)

        Returns:
            None: The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeSdkSettingsExportInstanceString(self._handle, path.encode('utf-8') if path else None)
        self._check_error()

    @classmethod
    def load(cls, path: str) -> None:
        """
        Static method to load SDK settings from a JSON file.

        Args:
            path (str)

        Returns:
            None: The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        _lib.BridgeSdkSettingsLoadString(path.encode('utf-8') if path else None)
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "Load")

    @classmethod
    def export(cls, path: str) -> None:
        """
        Static method to export the current SDK settings to a JSON file.

        Args:
            path (str)

        Returns:
            None: The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        _lib.BridgeSdkSettingsExportString(path.encode('utf-8') if path else None)
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "Export")

    @classmethod
    def get_ai_augmenter_settings(cls) -> 'AiAugmenterSettings':
        """
        Gets the settings for aiaugmenter.

        Returns:
            'AiAugmenterSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetAiAugmenterSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetAiAugmenterSettings")
        return import_module('.aiaugmentersettings', package=__package__).AiAugmenterSettings._from_handle(result)

    @classmethod
    def get_ai_processing_settings(cls) -> 'AiProcessingSettings':
        """
        Gets the settings for aiprocessing.

        Returns:
            'AiProcessingSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetAiProcessingSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetAiProcessingSettings")
        return import_module('.aiprocessingsettings', package=__package__).AiProcessingSettings._from_handle(result)

    @classmethod
    def get_cad_settings(cls) -> 'CadSettings':
        """
        Gets the settings for CAD.

        Returns:
            'CadSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetCadSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetCadSettings")
        return import_module('.cadsettings', package=__package__).CadSettings._from_handle(result)

    @classmethod
    def get_claude_api_settings(cls) -> 'ClaudeApiSettings':
        """
        Gets the settings for claudeapi.

        Returns:
            'ClaudeApiSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetClaudeApiSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetClaudeApiSettings")
        return import_module('.claudeapisettings', package=__package__).ClaudeApiSettings._from_handle(result)

    @classmethod
    def get_content_extraction_settings(cls) -> 'ContentExtractionSettings':
        """
        Gets the settings for contentextraction.

        Returns:
            'ContentExtractionSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetContentExtractionSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetContentExtractionSettings")
        return import_module('.contentextractionsettings', package=__package__).ContentExtractionSettings._from_handle(result)

    @classmethod
    def get_conversion_settings(cls) -> 'ConversionSettings':
        """
        Gets the settings for conversion.

        Returns:
            'ConversionSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetConversionSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetConversionSettings")
        return import_module('.conversionsettings', package=__package__).ConversionSettings._from_handle(result)

    @classmethod
    def get_custom_vlm_api_settings(cls) -> 'CustomVlmApiSettings':
        """
        Gets the settings for customvlmapi.

        Returns:
            'CustomVlmApiSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetCustomVlmApiSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetCustomVlmApiSettings")
        return import_module('.customvlmapisettings', package=__package__).CustomVlmApiSettings._from_handle(result)

    @classmethod
    def get_deskew_settings(cls) -> 'DeskewSettings':
        """
        Gets the settings for deskew.

        Returns:
            'DeskewSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetDeskewSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetDeskewSettings")
        return import_module('.deskewsettings', package=__package__).DeskewSettings._from_handle(result)

    @classmethod
    def get_document_layout_json_export_settings(cls) -> 'DocumentLayoutJsonExportSettings':
        """
        Gets the settings for documentlayoutjsonexport.

        Returns:
            'DocumentLayoutJsonExportSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetDocumentLayoutJsonExportSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetDocumentLayoutJsonExportSettings")
        return import_module('.documentlayoutjsonexportsettings', package=__package__).DocumentLayoutJsonExportSettings._from_handle(result)

    @classmethod
    def get_email_settings(cls) -> 'EmailSettings':
        """
        Gets the settings for email.

        Returns:
            'EmailSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetEmailSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetEmailSettings")
        return import_module('.emailsettings', package=__package__).EmailSettings._from_handle(result)

    @classmethod
    def get_finalizer_settings(cls) -> 'FinalizerSettings':
        """
        Gets the settings for finalizer.

        Returns:
            'FinalizerSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetFinalizerSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetFinalizerSettings")
        return import_module('.finalizersettings', package=__package__).FinalizerSettings._from_handle(result)

    @classmethod
    def get_form_recognition_settings(cls) -> 'FormRecognitionSettings':
        """
        Gets the settings for formrecognition.

        Returns:
            'FormRecognitionSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetFormRecognitionSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetFormRecognitionSettings")
        return import_module('.formrecognitionsettings', package=__package__).FormRecognitionSettings._from_handle(result)

    @classmethod
    def get_handwriting_settings(cls) -> 'HandwritingSettings':
        """
        Gets the settings for handwriting.

        Returns:
            'HandwritingSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetHandwritingSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetHandwritingSettings")
        return import_module('.handwritingsettings', package=__package__).HandwritingSettings._from_handle(result)

    @classmethod
    def get_html_settings(cls) -> 'HtmlSettings':
        """
        Gets the settings for HTML.

        Returns:
            'HtmlSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetHtmlSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetHtmlSettings")
        return import_module('.htmlsettings', package=__package__).HtmlSettings._from_handle(result)

    @classmethod
    def get_image_settings(cls) -> 'ImageSettings':
        """
        Gets the settings for image.

        Returns:
            'ImageSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetImageSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetImageSettings")
        return import_module('.imagesettings', package=__package__).ImageSettings._from_handle(result)

    @classmethod
    def get_inference_layout_settings(cls) -> 'InferenceLayoutSettings':
        """
        Gets the settings for inferencelayout.

        Returns:
            'InferenceLayoutSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetInferenceLayoutSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetInferenceLayoutSettings")
        return import_module('.inferencelayoutsettings', package=__package__).InferenceLayoutSettings._from_handle(result)

    @classmethod
    def get_instant_json_settings(cls) -> 'InstantJsonSettings':
        """
        Gets the settings for instantjson.

        Returns:
            'InstantJsonSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetInstantJsonSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetInstantJsonSettings")
        return import_module('.instantjsonsettings', package=__package__).InstantJsonSettings._from_handle(result)

    @classmethod
    def get_jbig2_settings(cls) -> 'Jbig2Settings':
        """
        Gets the settings for jbig2.

        Returns:
            'Jbig2Settings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetJbig2Settings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetJbig2Settings")
        return import_module('.jbig2settings', package=__package__).Jbig2Settings._from_handle(result)

    @classmethod
    def get_jpeg_settings(cls) -> 'JpegSettings':
        """
        Gets the settings for jpeg.

        Returns:
            'JpegSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetJpegSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetJpegSettings")
        return import_module('.jpegsettings', package=__package__).JpegSettings._from_handle(result)

    @classmethod
    def get_markdown_settings(cls) -> 'MarkdownSettings':
        """
        Gets the settings for markdown.

        Returns:
            'MarkdownSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetMarkdownSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetMarkdownSettings")
        return import_module('.markdownsettings', package=__package__).MarkdownSettings._from_handle(result)

    @classmethod
    def get_ocr_settings(cls) -> 'OcrSettings':
        """
        Gets the settings for ocr.

        Returns:
            'OcrSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetOcrSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetOcrSettings")
        return import_module('.ocrsettings', package=__package__).OcrSettings._from_handle(result)

    @classmethod
    def get_open_ai_api_endpoint_settings(cls) -> 'OpenAIApiEndpointSettings':
        """
        Gets the settings for openaiapiendpoint.

        Returns:
            'OpenAIApiEndpointSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetOpenAIApiEndpointSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetOpenAIApiEndpointSettings")
        return import_module('.openaiapiendpointsettings', package=__package__).OpenAIApiEndpointSettings._from_handle(result)

    @classmethod
    def get_open_ai_languages_detection_settings(cls) -> 'OpenAILanguagesDetectionSettings':
        """
        Gets the settings for openailanguagesdetection.

        Returns:
            'OpenAILanguagesDetectionSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetOpenAILanguagesDetectionSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetOpenAILanguagesDetectionSettings")
        return import_module('.openailanguagesdetectionsettings', package=__package__).OpenAILanguagesDetectionSettings._from_handle(result)

    @classmethod
    def get_open_ai_picture_alt_settings(cls) -> 'OpenAIPictureAltSettings':
        """
        Gets the settings for openaipicturealt.

        Returns:
            'OpenAIPictureAltSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetOpenAIPictureAltSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetOpenAIPictureAltSettings")
        return import_module('.openaipicturealtsettings', package=__package__).OpenAIPictureAltSettings._from_handle(result)

    @classmethod
    def get_open_settings(cls) -> 'OpenSettings':
        """
        Gets the settings for opening documents.

        Returns:
            'OpenSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetOpenSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetOpenSettings")
        return import_module('.opensettings', package=__package__).OpenSettings._from_handle(result)

    @classmethod
    def get_pdf_page_settings(cls) -> 'PdfPageSettings':
        """
        Gets the settings for PDF page.

        Returns:
            'PdfPageSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetPdfPageSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetPdfPageSettings")
        return import_module('.pdfpagesettings', package=__package__).PdfPageSettings._from_handle(result)

    @classmethod
    def get_pdf_settings(cls) -> 'PdfSettings':
        """
        Gets the settings for PDF.

        Returns:
            'PdfSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetPdfSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetPdfSettings")
        return import_module('.pdfsettings', package=__package__).PdfSettings._from_handle(result)

    @classmethod
    def get_presentation_settings(cls) -> 'PresentationSettings':
        """
        Gets the settings for presentation.

        Returns:
            'PresentationSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetPresentationSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetPresentationSettings")
        return import_module('.presentationsettings', package=__package__).PresentationSettings._from_handle(result)

    @classmethod
    def get_reading_order_settings(cls) -> 'ReadingOrderSettings':
        """
        Gets the settings for readingorder.

        Returns:
            'ReadingOrderSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetReadingOrderSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetReadingOrderSettings")
        return import_module('.readingordersettings', package=__package__).ReadingOrderSettings._from_handle(result)

    @classmethod
    def get_segmenter_settings(cls) -> 'SegmenterSettings':
        """
        Gets the settings for segmenter.

        Returns:
            'SegmenterSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetSegmenterSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetSegmenterSettings")
        return import_module('.segmentersettings', package=__package__).SegmenterSettings._from_handle(result)

    @classmethod
    def get_spreadsheet_settings(cls) -> 'SpreadsheetSettings':
        """
        Gets the settings for spreadsheet.

        Returns:
            'SpreadsheetSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetSpreadsheetSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetSpreadsheetSettings")
        return import_module('.spreadsheetsettings', package=__package__).SpreadsheetSettings._from_handle(result)

    @classmethod
    def get_table_recognition_settings(cls) -> 'TableRecognitionSettings':
        """
        Gets the settings for tablerecognition.

        Returns:
            'TableRecognitionSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetTableRecognitionSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetTableRecognitionSettings")
        return import_module('.tablerecognitionsettings', package=__package__).TableRecognitionSettings._from_handle(result)

    @classmethod
    def get_tiff_settings(cls) -> 'TiffSettings':
        """
        Gets the settings for tiff.

        Returns:
            'TiffSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetTiffSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetTiffSettings")
        return import_module('.tiffsettings', package=__package__).TiffSettings._from_handle(result)

    @classmethod
    def get_vision_descriptor_settings(cls) -> 'VisionDescriptorSettings':
        """
        Gets the settings for visiondescriptor.

        Returns:
            'VisionDescriptorSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetVisionDescriptorSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetVisionDescriptorSettings")
        return import_module('.visiondescriptorsettings', package=__package__).VisionDescriptorSettings._from_handle(result)

    @classmethod
    def get_vision_settings(cls) -> 'VisionSettings':
        """
        Gets the settings for vision.

        Returns:
            'VisionSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetVisionSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetVisionSettings")
        return import_module('.visionsettings', package=__package__).VisionSettings._from_handle(result)

    @classmethod
    def get_words_detection_settings(cls) -> 'WordsDetectionSettings':
        """
        Gets the settings for wordsdetection.

        Returns:
            'WordsDetectionSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetWordsDetectionSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetWordsDetectionSettings")
        return import_module('.wordsdetectionsettings', package=__package__).WordsDetectionSettings._from_handle(result)

    @classmethod
    def get_word_settings(cls) -> 'WordSettings':
        """
        Gets the settings for Word documents.

        Returns:
            'WordSettings': The result of the operation

        Raises:
            SdkSettingsError: If the operation fails
        """

        result = _lib.BridgeSdkSettingsGetWordSettings()
        error_code = _lib.BridgeSdkSettingsGetLastErrorCode()
        if error_code != 0:
            cls._raise_native_error(error_code, "GetWordSettings")
        return import_module('.wordsettings', package=__package__).WordSettings._from_handle(result)

    @sdk_helpers.classproperty
    def ai_augmenter_settings(cls) -> 'AiAugmenterSettings':
        """
        Gets the settings for aiaugmenter.

        Returns:
            'AiAugmenterSettings': The value
        """
        return cls.get_ai_augmenter_settings()

    @sdk_helpers.classproperty
    def ai_processing_settings(cls) -> 'AiProcessingSettings':
        """
        Gets the settings for aiprocessing.

        Returns:
            'AiProcessingSettings': The value
        """
        return cls.get_ai_processing_settings()

    @sdk_helpers.classproperty
    def cad_settings(cls) -> 'CadSettings':
        """
        Gets the settings for CAD.

        Returns:
            'CadSettings': The value
        """
        return cls.get_cad_settings()

    @sdk_helpers.classproperty
    def claude_api_settings(cls) -> 'ClaudeApiSettings':
        """
        Gets the settings for claudeapi.

        Returns:
            'ClaudeApiSettings': The value
        """
        return cls.get_claude_api_settings()

    @sdk_helpers.classproperty
    def content_extraction_settings(cls) -> 'ContentExtractionSettings':
        """
        Gets the settings for contentextraction.

        Returns:
            'ContentExtractionSettings': The value
        """
        return cls.get_content_extraction_settings()

    @sdk_helpers.classproperty
    def conversion_settings(cls) -> 'ConversionSettings':
        """
        Gets the settings for conversion.

        Returns:
            'ConversionSettings': The value
        """
        return cls.get_conversion_settings()

    @sdk_helpers.classproperty
    def custom_vlm_api_settings(cls) -> 'CustomVlmApiSettings':
        """
        Gets the settings for customvlmapi.

        Returns:
            'CustomVlmApiSettings': The value
        """
        return cls.get_custom_vlm_api_settings()

    @sdk_helpers.classproperty
    def deskew_settings(cls) -> 'DeskewSettings':
        """
        Gets the settings for deskew.

        Returns:
            'DeskewSettings': The value
        """
        return cls.get_deskew_settings()

    @sdk_helpers.classproperty
    def document_layout_json_export_settings(cls) -> 'DocumentLayoutJsonExportSettings':
        """
        Gets the settings for documentlayoutjsonexport.

        Returns:
            'DocumentLayoutJsonExportSettings': The value
        """
        return cls.get_document_layout_json_export_settings()

    @sdk_helpers.classproperty
    def email_settings(cls) -> 'EmailSettings':
        """
        Gets the settings for email.

        Returns:
            'EmailSettings': The value
        """
        return cls.get_email_settings()

    @sdk_helpers.classproperty
    def finalizer_settings(cls) -> 'FinalizerSettings':
        """
        Gets the settings for finalizer.

        Returns:
            'FinalizerSettings': The value
        """
        return cls.get_finalizer_settings()

    @sdk_helpers.classproperty
    def form_recognition_settings(cls) -> 'FormRecognitionSettings':
        """
        Gets the settings for formrecognition.

        Returns:
            'FormRecognitionSettings': The value
        """
        return cls.get_form_recognition_settings()

    @sdk_helpers.classproperty
    def handwriting_settings(cls) -> 'HandwritingSettings':
        """
        Gets the settings for handwriting.

        Returns:
            'HandwritingSettings': The value
        """
        return cls.get_handwriting_settings()

    @sdk_helpers.classproperty
    def html_settings(cls) -> 'HtmlSettings':
        """
        Gets the settings for HTML.

        Returns:
            'HtmlSettings': The value
        """
        return cls.get_html_settings()

    @sdk_helpers.classproperty
    def image_settings(cls) -> 'ImageSettings':
        """
        Gets the settings for image.

        Returns:
            'ImageSettings': The value
        """
        return cls.get_image_settings()

    @sdk_helpers.classproperty
    def inference_layout_settings(cls) -> 'InferenceLayoutSettings':
        """
        Gets the settings for inferencelayout.

        Returns:
            'InferenceLayoutSettings': The value
        """
        return cls.get_inference_layout_settings()

    @sdk_helpers.classproperty
    def instant_json_settings(cls) -> 'InstantJsonSettings':
        """
        Gets the settings for instantjson.

        Returns:
            'InstantJsonSettings': The value
        """
        return cls.get_instant_json_settings()

    @sdk_helpers.classproperty
    def jbig2_settings(cls) -> 'Jbig2Settings':
        """
        Gets the settings for jbig2.

        Returns:
            'Jbig2Settings': The value
        """
        return cls.get_jbig2_settings()

    @sdk_helpers.classproperty
    def jpeg_settings(cls) -> 'JpegSettings':
        """
        Gets the settings for jpeg.

        Returns:
            'JpegSettings': The value
        """
        return cls.get_jpeg_settings()

    @sdk_helpers.classproperty
    def markdown_settings(cls) -> 'MarkdownSettings':
        """
        Gets the settings for markdown.

        Returns:
            'MarkdownSettings': The value
        """
        return cls.get_markdown_settings()

    @sdk_helpers.classproperty
    def ocr_settings(cls) -> 'OcrSettings':
        """
        Gets the settings for ocr.

        Returns:
            'OcrSettings': The value
        """
        return cls.get_ocr_settings()

    @sdk_helpers.classproperty
    def open_ai_api_endpoint_settings(cls) -> 'OpenAIApiEndpointSettings':
        """
        Gets the settings for openaiapiendpoint.

        Returns:
            'OpenAIApiEndpointSettings': The value
        """
        return cls.get_open_ai_api_endpoint_settings()

    @sdk_helpers.classproperty
    def open_ai_languages_detection_settings(cls) -> 'OpenAILanguagesDetectionSettings':
        """
        Gets the settings for openailanguagesdetection.

        Returns:
            'OpenAILanguagesDetectionSettings': The value
        """
        return cls.get_open_ai_languages_detection_settings()

    @sdk_helpers.classproperty
    def open_ai_picture_alt_settings(cls) -> 'OpenAIPictureAltSettings':
        """
        Gets the settings for openaipicturealt.

        Returns:
            'OpenAIPictureAltSettings': The value
        """
        return cls.get_open_ai_picture_alt_settings()

    @sdk_helpers.classproperty
    def open_settings(cls) -> 'OpenSettings':
        """
        Gets the settings for opening documents.

        Returns:
            'OpenSettings': The value
        """
        return cls.get_open_settings()

    @sdk_helpers.classproperty
    def pdf_page_settings(cls) -> 'PdfPageSettings':
        """
        Gets the settings for PDF page.

        Returns:
            'PdfPageSettings': The value
        """
        return cls.get_pdf_page_settings()

    @sdk_helpers.classproperty
    def pdf_settings(cls) -> 'PdfSettings':
        """
        Gets the settings for PDF.

        Returns:
            'PdfSettings': The value
        """
        return cls.get_pdf_settings()

    @sdk_helpers.classproperty
    def presentation_settings(cls) -> 'PresentationSettings':
        """
        Gets the settings for presentation.

        Returns:
            'PresentationSettings': The value
        """
        return cls.get_presentation_settings()

    @sdk_helpers.classproperty
    def reading_order_settings(cls) -> 'ReadingOrderSettings':
        """
        Gets the settings for readingorder.

        Returns:
            'ReadingOrderSettings': The value
        """
        return cls.get_reading_order_settings()

    @sdk_helpers.classproperty
    def segmenter_settings(cls) -> 'SegmenterSettings':
        """
        Gets the settings for segmenter.

        Returns:
            'SegmenterSettings': The value
        """
        return cls.get_segmenter_settings()

    @sdk_helpers.classproperty
    def spreadsheet_settings(cls) -> 'SpreadsheetSettings':
        """
        Gets the settings for spreadsheet.

        Returns:
            'SpreadsheetSettings': The value
        """
        return cls.get_spreadsheet_settings()

    @sdk_helpers.classproperty
    def table_recognition_settings(cls) -> 'TableRecognitionSettings':
        """
        Gets the settings for tablerecognition.

        Returns:
            'TableRecognitionSettings': The value
        """
        return cls.get_table_recognition_settings()

    @sdk_helpers.classproperty
    def tiff_settings(cls) -> 'TiffSettings':
        """
        Gets the settings for tiff.

        Returns:
            'TiffSettings': The value
        """
        return cls.get_tiff_settings()

    @sdk_helpers.classproperty
    def vision_descriptor_settings(cls) -> 'VisionDescriptorSettings':
        """
        Gets the settings for visiondescriptor.

        Returns:
            'VisionDescriptorSettings': The value
        """
        return cls.get_vision_descriptor_settings()

    @sdk_helpers.classproperty
    def vision_settings(cls) -> 'VisionSettings':
        """
        Gets the settings for vision.

        Returns:
            'VisionSettings': The value
        """
        return cls.get_vision_settings()

    @sdk_helpers.classproperty
    def words_detection_settings(cls) -> 'WordsDetectionSettings':
        """
        Gets the settings for wordsdetection.

        Returns:
            'WordsDetectionSettings': The value
        """
        return cls.get_words_detection_settings()

    @sdk_helpers.classproperty
    def word_settings(cls) -> 'WordSettings':
        """
        Gets the settings for Word documents.

        Returns:
            'WordSettings': The value
        """
        return cls.get_word_settings()
