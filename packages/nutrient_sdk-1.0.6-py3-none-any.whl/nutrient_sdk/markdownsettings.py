"""
MarkdownSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class MarkdownSettingsError(NutrientException):
    """Exception raised by MarkdownSettings operations."""
    pass

_lib.BridgeMarkdownSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeMarkdownSettingsGetLastErrorCode.argtypes = []

_lib.BridgeMarkdownSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeMarkdownSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeMarkdownSettingsFreeErrorString.restype = None
_lib.BridgeMarkdownSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeMarkdownSettingsGetImageExport.restype = ctypes.c_int32
_lib.BridgeMarkdownSettingsGetImageExport.argtypes = [ctypes.c_void_p]

_lib.BridgeMarkdownSettingsSetImageExportImageExportMode.restype = None
_lib.BridgeMarkdownSettingsSetImageExportImageExportMode.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgeMarkdownSettingsGetEnableInlineFormatting.restype = ctypes.c_bool
_lib.BridgeMarkdownSettingsGetEnableInlineFormatting.argtypes = [ctypes.c_void_p]

_lib.BridgeMarkdownSettingsSetEnableInlineFormattingBoolean.restype = None
_lib.BridgeMarkdownSettingsSetEnableInlineFormattingBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgeMarkdownSettingsGetEmitPageBoundaryMarkers.restype = ctypes.c_bool
_lib.BridgeMarkdownSettingsGetEmitPageBoundaryMarkers.argtypes = [ctypes.c_void_p]

_lib.BridgeMarkdownSettingsSetEmitPageBoundaryMarkersBoolean.restype = None
_lib.BridgeMarkdownSettingsSetEmitPageBoundaryMarkersBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgeMarkdownSettingsGetEnableSemanticBlockFormatting.restype = ctypes.c_bool
_lib.BridgeMarkdownSettingsGetEnableSemanticBlockFormatting.argtypes = [ctypes.c_void_p]

_lib.BridgeMarkdownSettingsSetEnableSemanticBlockFormattingBoolean.restype = None
_lib.BridgeMarkdownSettingsSetEnableSemanticBlockFormattingBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgeMarkdownSettingsGetIncludeHeadersAndFooters.restype = ctypes.c_bool
_lib.BridgeMarkdownSettingsGetIncludeHeadersAndFooters.argtypes = [ctypes.c_void_p]

_lib.BridgeMarkdownSettingsSetIncludeHeadersAndFootersBoolean.restype = None
_lib.BridgeMarkdownSettingsSetIncludeHeadersAndFootersBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgeMarkdownSettingsGetUseHtmlTables.restype = ctypes.c_bool
_lib.BridgeMarkdownSettingsGetUseHtmlTables.argtypes = [ctypes.c_void_p]

_lib.BridgeMarkdownSettingsSetUseHtmlTablesBoolean.restype = None
_lib.BridgeMarkdownSettingsSetUseHtmlTablesBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]


class MarkdownSettings:
    """
    Settings for Markdown. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate MarkdownSettings directly. Use static factory methods instead."""
        raise TypeError("MarkdownSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeMarkdownSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "MarkdownSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeMarkdownSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeMarkdownSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"MarkdownSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=MarkdownSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("MarkdownSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_image_export(self) -> Any:
        """
        Controls how images are exported when converting documents to Markdown.

        Returns:
            Any: The value of the ImageExport property.

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeMarkdownSettingsGetImageExport(self._handle)
        self._check_error()
        return result

    def set_image_export(self, value: Any) -> None:
        """
        Controls how images are exported when converting documents to Markdown.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeMarkdownSettingsSetImageExportImageExportMode(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    def get_enable_inline_formatting(self) -> bool:
        """
        Controls whether inline text formatting (bold, italic) is preserved in the Markdown output using standard markers (**bold**, *italic*).

        Returns:
            bool: The value of the EnableInlineFormatting property.

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeMarkdownSettingsGetEnableInlineFormatting(self._handle)
        self._check_error()
        return result

    def set_enable_inline_formatting(self, value: bool) -> None:
        """
        Controls whether inline text formatting (bold, italic) is preserved in the Markdown output using standard markers (**bold**, *italic*).

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeMarkdownSettingsSetEnableInlineFormattingBoolean(self._handle, value)
        self._check_error()

    def get_emit_page_boundary_markers(self) -> bool:
        """
        When enabled, the converter emits a unique HTML-comment marker at the start of every page (<!-- nutrient-page-start: N -->, where N is the 1-indexed physical page number). The markers are invisible when the Markdown is rendered to HTML but allow downstream tooling to slice the output reliably back into per-page chunks.

        Returns:
            bool: The value of the EmitPageBoundaryMarkers property.

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeMarkdownSettingsGetEmitPageBoundaryMarkers(self._handle)
        self._check_error()
        return result

    def set_emit_page_boundary_markers(self, value: bool) -> None:
        """
        When enabled, the converter emits a unique HTML-comment marker at the start of every page (<!-- nutrient-page-start: N -->, where N is the 1-indexed physical page number). The markers are invisible when the Markdown is rendered to HTML but allow downstream tooling to slice the output reliably back into per-page chunks.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeMarkdownSettingsSetEmitPageBoundaryMarkersBoolean(self._handle, value)
        self._check_error()

    def get_enable_semantic_block_formatting(self) -> bool:
        """
        Controls whether footnotes and captions are rendered with semantic Markdown markers (> , *…*) and whether pictures are emitted at all (![alt] / [Figure]). When , footnotes and captions render as plain paragraphs and pictures are dropped entirely. List items always render with - regardless.

        Returns:
            bool: The value of the EnableSemanticBlockFormatting property.

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeMarkdownSettingsGetEnableSemanticBlockFormatting(self._handle)
        self._check_error()
        return result

    def set_enable_semantic_block_formatting(self, value: bool) -> None:
        """
        Controls whether footnotes and captions are rendered with semantic Markdown markers (> , *…*) and whether pictures are emitted at all (![alt] / [Figure]). When , footnotes and captions render as plain paragraphs and pictures are dropped entirely. List items always render with - regardless.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeMarkdownSettingsSetEnableSemanticBlockFormattingBoolean(self._handle, value)
        self._check_error()

    def get_include_headers_and_footers(self) -> bool:
        """
        Controls whether running headers and footers are included in the Markdown output. When included, they render as plain text paragraphs.

        Returns:
            bool: The value of the IncludeHeadersAndFooters property.

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeMarkdownSettingsGetIncludeHeadersAndFooters(self._handle)
        self._check_error()
        return result

    def set_include_headers_and_footers(self, value: bool) -> None:
        """
        Controls whether running headers and footers are included in the Markdown output. When included, they render as plain text paragraphs.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeMarkdownSettingsSetIncludeHeadersAndFootersBoolean(self._handle, value)
        self._check_error()

    def get_use_html_tables(self) -> bool:
        """
        Controls how tables are rendered in the Markdown output. When enabled, tables are emitted as HTML (<table>/<tr>/<td>) preserving row/column spans where available; when disabled, tables render as pipe-style Markdown.

        Returns:
            bool: The value of the UseHtmlTables property.

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeMarkdownSettingsGetUseHtmlTables(self._handle)
        self._check_error()
        return result

    def set_use_html_tables(self, value: bool) -> None:
        """
        Controls how tables are rendered in the Markdown output. When enabled, tables are emitted as HTML (<table>/<tr>/<td>) preserving row/column spans where available; when disabled, tables render as pipe-style Markdown.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            MarkdownSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeMarkdownSettingsSetUseHtmlTablesBoolean(self._handle, value)
        self._check_error()

    @property
    def image_export(self) -> Any:
        """
        Controls how images are exported when converting documents to Markdown.

        Returns:
            Any: The value of the ImageExport property.
        """
        return self.get_image_export()

    @image_export.setter
    def image_export(self, value: Any) -> None:
        """
        Sets the image export.

        Args:
            value (Any): The value to set.
        """
        self.set_image_export(value)

    @property
    def enable_inline_formatting(self) -> bool:
        """
        Controls whether inline text formatting (bold, italic) is preserved in the Markdown output using standard markers (**bold**, *italic*).

        Returns:
            bool: The value of the EnableInlineFormatting property.
        """
        return self.get_enable_inline_formatting()

    @enable_inline_formatting.setter
    def enable_inline_formatting(self, value: bool) -> None:
        """
        Sets the enable inline formatting.

        Args:
            value (bool): The value to set.
        """
        self.set_enable_inline_formatting(value)

    @property
    def emit_page_boundary_markers(self) -> bool:
        """
        When enabled, the converter emits a unique HTML-comment marker at the start of every page (<!-- nutrient-page-start: N -->, where N is the 1-indexed physical page number). The markers are invisible when the Markdown is rendered to HTML but allow downstream tooling to slice the output reliably back into per-page chunks.

        Returns:
            bool: The value of the EmitPageBoundaryMarkers property.
        """
        return self.get_emit_page_boundary_markers()

    @emit_page_boundary_markers.setter
    def emit_page_boundary_markers(self, value: bool) -> None:
        """
        Sets the emit page boundary markers.

        Args:
            value (bool): The value to set.
        """
        self.set_emit_page_boundary_markers(value)

    @property
    def enable_semantic_block_formatting(self) -> bool:
        """
        Controls whether footnotes and captions are rendered with semantic Markdown markers (> , *…*) and whether pictures are emitted at all (![alt] / [Figure]). When , footnotes and captions render as plain paragraphs and pictures are dropped entirely. List items always render with - regardless.

        Returns:
            bool: The value of the EnableSemanticBlockFormatting property.
        """
        return self.get_enable_semantic_block_formatting()

    @enable_semantic_block_formatting.setter
    def enable_semantic_block_formatting(self, value: bool) -> None:
        """
        Sets the enable semantic block formatting.

        Args:
            value (bool): The value to set.
        """
        self.set_enable_semantic_block_formatting(value)

    @property
    def include_headers_and_footers(self) -> bool:
        """
        Controls whether running headers and footers are included in the Markdown output. When included, they render as plain text paragraphs.

        Returns:
            bool: The value of the IncludeHeadersAndFooters property.
        """
        return self.get_include_headers_and_footers()

    @include_headers_and_footers.setter
    def include_headers_and_footers(self, value: bool) -> None:
        """
        Sets the include headers and footers.

        Args:
            value (bool): The value to set.
        """
        self.set_include_headers_and_footers(value)

    @property
    def use_html_tables(self) -> bool:
        """
        Controls how tables are rendered in the Markdown output. When enabled, tables are emitted as HTML (<table>/<tr>/<td>) preserving row/column spans where available; when disabled, tables render as pipe-style Markdown.

        Returns:
            bool: The value of the UseHtmlTables property.
        """
        return self.get_use_html_tables()

    @use_html_tables.setter
    def use_html_tables(self, value: bool) -> None:
        """
        Sets the use html tables.

        Args:
            value (bool): The value to set.
        """
        self.set_use_html_tables(value)
