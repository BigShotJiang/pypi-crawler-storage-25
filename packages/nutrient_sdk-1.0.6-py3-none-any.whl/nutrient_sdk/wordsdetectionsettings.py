"""
WordsDetectionSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class WordsDetectionSettingsError(NutrientException):
    """Exception raised by WordsDetectionSettings operations."""
    pass

_lib.BridgeWordsDetectionSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeWordsDetectionSettingsGetLastErrorCode.argtypes = []

_lib.BridgeWordsDetectionSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeWordsDetectionSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeWordsDetectionSettingsFreeErrorString.restype = None
_lib.BridgeWordsDetectionSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeWordsDetectionSettingsGetConfidenceThreshold.restype = ctypes.c_float
_lib.BridgeWordsDetectionSettingsGetConfidenceThreshold.argtypes = [ctypes.c_void_p]

_lib.BridgeWordsDetectionSettingsSetConfidenceThresholdSingle.restype = None
_lib.BridgeWordsDetectionSettingsSetConfidenceThresholdSingle.argtypes = [ctypes.c_void_p, ctypes.c_float]


class WordsDetectionSettings:
    """
    Settings for WordsDetection. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate WordsDetectionSettings directly. Use static factory methods instead."""
        raise TypeError("WordsDetectionSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeWordsDetectionSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "WordsDetectionSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeWordsDetectionSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeWordsDetectionSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"WordsDetectionSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=WordsDetectionSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("WordsDetectionSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_confidence_threshold(self) -> float:
        """
        Detection confidence threshold (0.0 to 1.0). Detections with confidence below this threshold will be filtered out.

        Returns:
            float: The value of the ConfidenceThreshold property.

        Raises:
            WordsDetectionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeWordsDetectionSettingsGetConfidenceThreshold(self._handle)
        self._check_error()
        return result

    def set_confidence_threshold(self, value: float) -> None:
        """
        Detection confidence threshold (0.0 to 1.0). Detections with confidence below this threshold will be filtered out.

        Args:
            value (float)

        Returns:
            None: The result of the operation

        Raises:
            WordsDetectionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeWordsDetectionSettingsSetConfidenceThresholdSingle(self._handle, value)
        self._check_error()

    @property
    def confidence_threshold(self) -> float:
        """
        Detection confidence threshold (0.0 to 1.0). Detections with confidence below this threshold will be filtered out.

        Returns:
            float: The value of the ConfidenceThreshold property.
        """
        return self.get_confidence_threshold()

    @confidence_threshold.setter
    def confidence_threshold(self, value: float) -> None:
        """
        Sets the confidence threshold.

        Args:
            value (float): The value to set.
        """
        self.set_confidence_threshold(value)
