"""
PdfSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class PdfSettingsError(NutrientException):
    """Exception raised by PdfSettings operations."""
    pass

_lib.BridgePdfSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgePdfSettingsGetLastErrorCode.argtypes = []

_lib.BridgePdfSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgePdfSettingsGetLastErrorMessage.argtypes = []

_lib.BridgePdfSettingsFreeErrorString.restype = None
_lib.BridgePdfSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsGetConformance.restype = ctypes.c_int32
_lib.BridgePdfSettingsGetConformance.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsSetConformancePdfConformance.restype = None
_lib.BridgePdfSettingsSetConformancePdfConformance.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgePdfSettingsGetMode.restype = ctypes.c_int32
_lib.BridgePdfSettingsGetMode.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsSetModePdfSettingsMode.restype = None
_lib.BridgePdfSettingsSetModePdfSettingsMode.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgePdfSettingsGetSavePreferences.restype = ctypes.c_int32
_lib.BridgePdfSettingsGetSavePreferences.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsSetSavePreferencesPdfSavePreferences.restype = None
_lib.BridgePdfSettingsSetSavePreferencesPdfSavePreferences.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgePdfSettingsGetBitonalImageCompression.restype = ctypes.c_int32
_lib.BridgePdfSettingsGetBitonalImageCompression.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsSetBitonalImageCompressionPdfCompression.restype = None
_lib.BridgePdfSettingsSetBitonalImageCompressionPdfCompression.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgePdfSettingsGetColorImageCompression.restype = ctypes.c_int32
_lib.BridgePdfSettingsGetColorImageCompression.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsSetColorImageCompressionPdfCompression.restype = None
_lib.BridgePdfSettingsSetColorImageCompressionPdfCompression.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgePdfSettingsGetEnableColorDetection.restype = ctypes.c_bool
_lib.BridgePdfSettingsGetEnableColorDetection.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsSetEnableColorDetectionBoolean.restype = None
_lib.BridgePdfSettingsSetEnableColorDetectionBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgePdfSettingsGetUseDeflateOnJpeg.restype = ctypes.c_bool
_lib.BridgePdfSettingsGetUseDeflateOnJpeg.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsSetUseDeflateOnJpegBoolean.restype = None
_lib.BridgePdfSettingsSetUseDeflateOnJpegBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgePdfSettingsGetZlibLevel.restype = ctypes.c_int32
_lib.BridgePdfSettingsGetZlibLevel.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsSetZlibLevelInt32.restype = None
_lib.BridgePdfSettingsSetZlibLevelInt32.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgePdfSettingsGetEnableLinearization.restype = ctypes.c_bool
_lib.BridgePdfSettingsGetEnableLinearization.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsSetEnableLinearizationBoolean.restype = None
_lib.BridgePdfSettingsSetEnableLinearizationBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgePdfSettingsGetOptimize.restype = ctypes.c_bool
_lib.BridgePdfSettingsGetOptimize.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsSetOptimizeBoolean.restype = None
_lib.BridgePdfSettingsSetOptimizeBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgePdfSettingsGetForceImageDpi.restype = ctypes.c_int32
_lib.BridgePdfSettingsGetForceImageDpi.argtypes = [ctypes.c_void_p]

_lib.BridgePdfSettingsSetForceImageDpiInt32.restype = None
_lib.BridgePdfSettingsSetForceImageDpiInt32.argtypes = [ctypes.c_void_p, ctypes.c_int32]


class PdfSettings:
    """
    Settings for Pdf. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate PdfSettings directly. Use static factory methods instead."""
        raise TypeError("PdfSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgePdfSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "PdfSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgePdfSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgePdfSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"PdfSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=PdfSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("PdfSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_conformance(self) -> Any:
        """
        The PDF conformance level for the output document.

        Returns:
            Any: The value of the Conformance property.

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfSettingsGetConformance(self._handle)
        self._check_error()
        return result

    def set_conformance(self, value: Any) -> None:
        """
        The PDF conformance level for the output document.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfSettingsSetConformancePdfConformance(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    def get_mode(self) -> Any:
        """
        The mode options for PDF processing.

        Returns:
            Any: The value of the Mode property.

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfSettingsGetMode(self._handle)
        self._check_error()
        return result

    def set_mode(self, value: Any) -> None:
        """
        The mode options for PDF processing.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfSettingsSetModePdfSettingsMode(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    def get_save_preferences(self) -> Any:
        """
        Preferences for saving PDF documents.

        Returns:
            Any: The value of the SavePreferences property.

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfSettingsGetSavePreferences(self._handle)
        self._check_error()
        return result

    def set_save_preferences(self, value: Any) -> None:
        """
        Preferences for saving PDF documents.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfSettingsSetSavePreferencesPdfSavePreferences(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    def get_bitonal_image_compression(self) -> Any:
        """
        The compression method to use for bitonal (black and white) images in PDF documents.

        Returns:
            Any: The value of the BitonalImageCompression property.

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfSettingsGetBitonalImageCompression(self._handle)
        self._check_error()
        return result

    def set_bitonal_image_compression(self, value: Any) -> None:
        """
        The compression method to use for bitonal (black and white) images in PDF documents.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfSettingsSetBitonalImageCompressionPdfCompression(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    def get_color_image_compression(self) -> Any:
        """
        The compression method to use for color images in PDF documents.

        Returns:
            Any: The value of the ColorImageCompression property.

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfSettingsGetColorImageCompression(self._handle)
        self._check_error()
        return result

    def set_color_image_compression(self, value: Any) -> None:
        """
        The compression method to use for color images in PDF documents.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfSettingsSetColorImageCompressionPdfCompression(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    def get_enable_color_detection(self) -> bool:
        """
        Indicates whether automatic color detection is enabled to determine if an image is bitonal or color.

        Returns:
            bool: The value of the EnableColorDetection property.

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfSettingsGetEnableColorDetection(self._handle)
        self._check_error()
        return result

    def set_enable_color_detection(self, value: bool) -> None:
        """
        Indicates whether automatic color detection is enabled to determine if an image is bitonal or color.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfSettingsSetEnableColorDetectionBoolean(self._handle, value)
        self._check_error()

    def get_use_deflate_on_jpeg(self) -> bool:
        """
        Indicates whether Deflate compression should be applied to JPEG images.

        Returns:
            bool: The value of the UseDeflateOnJpeg property.

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfSettingsGetUseDeflateOnJpeg(self._handle)
        self._check_error()
        return result

    def set_use_deflate_on_jpeg(self, value: bool) -> None:
        """
        Indicates whether Deflate compression should be applied to JPEG images.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfSettingsSetUseDeflateOnJpegBoolean(self._handle, value)
        self._check_error()

    def get_zlib_level(self) -> int:
        """
        The compression level for Zlib/Deflate compression. Higher values provide better compression but take longer to process.

        Returns:
            int: The value of the ZlibLevel property.

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfSettingsGetZlibLevel(self._handle)
        self._check_error()
        return result

    def set_zlib_level(self, value: int) -> None:
        """
        The compression level for Zlib/Deflate compression. Higher values provide better compression but take longer to process.

        Args:
            value (int)

        Returns:
            None: The result of the operation

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfSettingsSetZlibLevelInt32(self._handle, value)
        self._check_error()

    def get_enable_linearization(self) -> bool:
        """
        Indicates whether PDF linearization (fast web view) is enabled. Linearized PDFs can be displayed page-by-page while still downloading.

        Returns:
            bool: The value of the EnableLinearization property.

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfSettingsGetEnableLinearization(self._handle)
        self._check_error()
        return result

    def set_enable_linearization(self, value: bool) -> None:
        """
        Indicates whether PDF linearization (fast web view) is enabled. Linearized PDFs can be displayed page-by-page while still downloading.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfSettingsSetEnableLinearizationBoolean(self._handle, value)
        self._check_error()

    def get_optimize(self) -> bool:
        """
        Indicates whether PDF optimization is enabled to reduce file size.

        Returns:
            bool: The value of the Optimize property.

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfSettingsGetOptimize(self._handle)
        self._check_error()
        return result

    def set_optimize(self, value: bool) -> None:
        """
        Indicates whether PDF optimization is enabled to reduce file size.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfSettingsSetOptimizeBoolean(self._handle, value)
        self._check_error()

    def get_force_image_dpi(self) -> int:
        """
        Forces all images in the PDF to a specific DPI (dots per inch) resolution. A value of 0 means no DPI forcing is applied.

        Returns:
            int: The value of the ForceImageDpi property.

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfSettingsGetForceImageDpi(self._handle)
        self._check_error()
        return result

    def set_force_image_dpi(self, value: int) -> None:
        """
        Forces all images in the PDF to a specific DPI (dots per inch) resolution. A value of 0 means no DPI forcing is applied.

        Args:
            value (int)

        Returns:
            None: The result of the operation

        Raises:
            PdfSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfSettingsSetForceImageDpiInt32(self._handle, value)
        self._check_error()

    @property
    def conformance(self) -> Any:
        """
        The PDF conformance level for the output document.

        Returns:
            Any: The value of the Conformance property.
        """
        return self.get_conformance()

    @conformance.setter
    def conformance(self, value: Any) -> None:
        """
        Sets the conformance.

        Args:
            value (Any): The value to set.
        """
        self.set_conformance(value)

    @property
    def mode(self) -> Any:
        """
        The mode options for PDF processing.

        Returns:
            Any: The value of the Mode property.
        """
        return self.get_mode()

    @mode.setter
    def mode(self, value: Any) -> None:
        """
        Sets the mode.

        Args:
            value (Any): The value to set.
        """
        self.set_mode(value)

    @property
    def save_preferences(self) -> Any:
        """
        Preferences for saving PDF documents.

        Returns:
            Any: The value of the SavePreferences property.
        """
        return self.get_save_preferences()

    @save_preferences.setter
    def save_preferences(self, value: Any) -> None:
        """
        Sets the save preferences.

        Args:
            value (Any): The value to set.
        """
        self.set_save_preferences(value)

    @property
    def bitonal_image_compression(self) -> Any:
        """
        The compression method to use for bitonal (black and white) images in PDF documents.

        Returns:
            Any: The value of the BitonalImageCompression property.
        """
        return self.get_bitonal_image_compression()

    @bitonal_image_compression.setter
    def bitonal_image_compression(self, value: Any) -> None:
        """
        Sets the bitonal image compression.

        Args:
            value (Any): The value to set.
        """
        self.set_bitonal_image_compression(value)

    @property
    def color_image_compression(self) -> Any:
        """
        The compression method to use for color images in PDF documents.

        Returns:
            Any: The value of the ColorImageCompression property.
        """
        return self.get_color_image_compression()

    @color_image_compression.setter
    def color_image_compression(self, value: Any) -> None:
        """
        Sets the color image compression.

        Args:
            value (Any): The value to set.
        """
        self.set_color_image_compression(value)

    @property
    def enable_color_detection(self) -> bool:
        """
        Indicates whether automatic color detection is enabled to determine if an image is bitonal or color.

        Returns:
            bool: The value of the EnableColorDetection property.
        """
        return self.get_enable_color_detection()

    @enable_color_detection.setter
    def enable_color_detection(self, value: bool) -> None:
        """
        Sets the enable color detection.

        Args:
            value (bool): The value to set.
        """
        self.set_enable_color_detection(value)

    @property
    def use_deflate_on_jpeg(self) -> bool:
        """
        Indicates whether Deflate compression should be applied to JPEG images.

        Returns:
            bool: The value of the UseDeflateOnJpeg property.
        """
        return self.get_use_deflate_on_jpeg()

    @use_deflate_on_jpeg.setter
    def use_deflate_on_jpeg(self, value: bool) -> None:
        """
        Sets the use deflate on jpeg.

        Args:
            value (bool): The value to set.
        """
        self.set_use_deflate_on_jpeg(value)

    @property
    def zlib_level(self) -> int:
        """
        The compression level for Zlib/Deflate compression. Higher values provide better compression but take longer to process.

        Returns:
            int: The value of the ZlibLevel property.
        """
        return self.get_zlib_level()

    @zlib_level.setter
    def zlib_level(self, value: int) -> None:
        """
        Sets the zlib level.

        Args:
            value (int): The value to set.
        """
        self.set_zlib_level(value)

    @property
    def enable_linearization(self) -> bool:
        """
        Indicates whether PDF linearization (fast web view) is enabled. Linearized PDFs can be displayed page-by-page while still downloading.

        Returns:
            bool: The value of the EnableLinearization property.
        """
        return self.get_enable_linearization()

    @enable_linearization.setter
    def enable_linearization(self, value: bool) -> None:
        """
        Sets the enable linearization.

        Args:
            value (bool): The value to set.
        """
        self.set_enable_linearization(value)

    @property
    def optimize(self) -> bool:
        """
        Indicates whether PDF optimization is enabled to reduce file size.

        Returns:
            bool: The value of the Optimize property.
        """
        return self.get_optimize()

    @optimize.setter
    def optimize(self, value: bool) -> None:
        """
        Sets the optimize.

        Args:
            value (bool): The value to set.
        """
        self.set_optimize(value)

    @property
    def force_image_dpi(self) -> int:
        """
        Forces all images in the PDF to a specific DPI (dots per inch) resolution. A value of 0 means no DPI forcing is applied.

        Returns:
            int: The value of the ForceImageDpi property.
        """
        return self.get_force_image_dpi()

    @force_image_dpi.setter
    def force_image_dpi(self, value: int) -> None:
        """
        Sets the force image dpi.

        Args:
            value (int): The value to set.
        """
        self.set_force_image_dpi(value)
