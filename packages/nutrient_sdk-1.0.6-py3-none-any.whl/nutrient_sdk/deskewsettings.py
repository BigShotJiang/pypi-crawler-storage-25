"""
DeskewSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class DeskewSettingsError(NutrientException):
    """Exception raised by DeskewSettings operations."""
    pass

_lib.BridgeDeskewSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeDeskewSettingsGetLastErrorCode.argtypes = []

_lib.BridgeDeskewSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeDeskewSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeDeskewSettingsFreeErrorString.restype = None
_lib.BridgeDeskewSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeDeskewSettingsGetEnableDeskew.restype = ctypes.c_bool
_lib.BridgeDeskewSettingsGetEnableDeskew.argtypes = [ctypes.c_void_p]

_lib.BridgeDeskewSettingsSetEnableDeskewBoolean.restype = None
_lib.BridgeDeskewSettingsSetEnableDeskewBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgeDeskewSettingsGetInverseDeskew.restype = ctypes.c_bool
_lib.BridgeDeskewSettingsGetInverseDeskew.argtypes = [ctypes.c_void_p]

_lib.BridgeDeskewSettingsSetInverseDeskewBoolean.restype = None
_lib.BridgeDeskewSettingsSetInverseDeskewBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgeDeskewSettingsGetSkewTolerance.restype = ctypes.c_float
_lib.BridgeDeskewSettingsGetSkewTolerance.argtypes = [ctypes.c_void_p]

_lib.BridgeDeskewSettingsSetSkewToleranceSingle.restype = None
_lib.BridgeDeskewSettingsSetSkewToleranceSingle.argtypes = [ctypes.c_void_p, ctypes.c_float]

_lib.BridgeDeskewSettingsGetSkewBinarizationMethod.restype = ctypes.c_void_p
_lib.BridgeDeskewSettingsGetSkewBinarizationMethod.argtypes = [ctypes.c_void_p]

_lib.BridgeDeskewSettingsSetSkewBinarizationMethodString.restype = None
_lib.BridgeDeskewSettingsSetSkewBinarizationMethodString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]


class DeskewSettings:
    """
    Settings for Deskew. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate DeskewSettings directly. Use static factory methods instead."""
        raise TypeError("DeskewSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeDeskewSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "DeskewSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeDeskewSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeDeskewSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"DeskewSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=DeskewSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("DeskewSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_enable_deskew(self) -> bool:
        """
        Indicates whether automatic deskewing is enabled.

        Returns:
            bool: The value of the EnableDeskew property.

        Raises:
            DeskewSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeDeskewSettingsGetEnableDeskew(self._handle)
        self._check_error()
        return result

    def set_enable_deskew(self, value: bool) -> None:
        """
        Indicates whether automatic deskewing is enabled.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            DeskewSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeDeskewSettingsSetEnableDeskewBoolean(self._handle, value)
        self._check_error()

    def get_inverse_deskew(self) -> bool:
        """
        Indicates whether the inverse deskew transform is enabled. When disabled, bounding boxes remain in deskewed-image coordinates.

        Returns:
            bool: The value of the InverseDeskew property.

        Raises:
            DeskewSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeDeskewSettingsGetInverseDeskew(self._handle)
        self._check_error()
        return result

    def set_inverse_deskew(self, value: bool) -> None:
        """
        Indicates whether the inverse deskew transform is enabled. When disabled, bounding boxes remain in deskewed-image coordinates.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            DeskewSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeDeskewSettingsSetInverseDeskewBoolean(self._handle, value)
        self._check_error()

    def get_skew_tolerance(self) -> float:
        """
        Maximum skew angle tolerance in degrees.

        Returns:
            float: The value of the SkewTolerance property.

        Raises:
            DeskewSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeDeskewSettingsGetSkewTolerance(self._handle)
        self._check_error()
        return result

    def set_skew_tolerance(self, value: float) -> None:
        """
        Maximum skew angle tolerance in degrees.

        Args:
            value (float)

        Returns:
            None: The result of the operation

        Raises:
            DeskewSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeDeskewSettingsSetSkewToleranceSingle(self._handle, value)
        self._check_error()

    def get_skew_binarization_method(self) -> str:
        """
        Binarization method for skew detection. Supported values: "default" (internal Modified Otsu), "sauvola" (better for poor contrast), "otsu" (explicit Modified Otsu).

        Returns:
            str: The value of the SkewBinarizationMethod property.

        Raises:
            DeskewSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeDeskewSettingsGetSkewBinarizationMethod(self._handle)
        self._check_error()
        return sdk_loader.convert_string_handle(result)

    def set_skew_binarization_method(self, value: str) -> None:
        """
        Binarization method for skew detection. Supported values: "default" (internal Modified Otsu), "sauvola" (better for poor contrast), "otsu" (explicit Modified Otsu).

        Args:
            value (str)

        Returns:
            None: The result of the operation

        Raises:
            DeskewSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeDeskewSettingsSetSkewBinarizationMethodString(self._handle, value.encode('utf-8') if value else None)
        self._check_error()

    @property
    def enable_deskew(self) -> bool:
        """
        Indicates whether automatic deskewing is enabled.

        Returns:
            bool: The value of the EnableDeskew property.
        """
        return self.get_enable_deskew()

    @enable_deskew.setter
    def enable_deskew(self, value: bool) -> None:
        """
        Sets the enable deskew.

        Args:
            value (bool): The value to set.
        """
        self.set_enable_deskew(value)

    @property
    def inverse_deskew(self) -> bool:
        """
        Indicates whether the inverse deskew transform is enabled. When disabled, bounding boxes remain in deskewed-image coordinates.

        Returns:
            bool: The value of the InverseDeskew property.
        """
        return self.get_inverse_deskew()

    @inverse_deskew.setter
    def inverse_deskew(self, value: bool) -> None:
        """
        Sets the inverse deskew.

        Args:
            value (bool): The value to set.
        """
        self.set_inverse_deskew(value)

    @property
    def skew_tolerance(self) -> float:
        """
        Maximum skew angle tolerance in degrees.

        Returns:
            float: The value of the SkewTolerance property.
        """
        return self.get_skew_tolerance()

    @skew_tolerance.setter
    def skew_tolerance(self, value: float) -> None:
        """
        Sets the skew tolerance.

        Args:
            value (float): The value to set.
        """
        self.set_skew_tolerance(value)

    @property
    def skew_binarization_method(self) -> str:
        """
        Binarization method for skew detection. Supported values: "default" (internal Modified Otsu), "sauvola" (better for poor contrast), "otsu" (explicit Modified Otsu).

        Returns:
            str: The value of the SkewBinarizationMethod property.
        """
        return self.get_skew_binarization_method()

    @skew_binarization_method.setter
    def skew_binarization_method(self, value: str) -> None:
        """
        Sets the skew binarization method.

        Args:
            value (str): The value to set.
        """
        self.set_skew_binarization_method(value)
