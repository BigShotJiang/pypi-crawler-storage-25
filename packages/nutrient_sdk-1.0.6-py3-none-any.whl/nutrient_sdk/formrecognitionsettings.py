"""
FormRecognitionSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class FormRecognitionSettingsError(NutrientException):
    """Exception raised by FormRecognitionSettings operations."""
    pass

_lib.BridgeFormRecognitionSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeFormRecognitionSettingsGetLastErrorCode.argtypes = []

_lib.BridgeFormRecognitionSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeFormRecognitionSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeFormRecognitionSettingsFreeErrorString.restype = None
_lib.BridgeFormRecognitionSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeFormRecognitionSettingsGetModelPath.restype = ctypes.c_void_p
_lib.BridgeFormRecognitionSettingsGetModelPath.argtypes = [ctypes.c_void_p]

_lib.BridgeFormRecognitionSettingsSetModelPathString.restype = None
_lib.BridgeFormRecognitionSettingsSetModelPathString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeFormRecognitionSettingsGetUseCpuOnly.restype = ctypes.c_bool
_lib.BridgeFormRecognitionSettingsGetUseCpuOnly.argtypes = [ctypes.c_void_p]

_lib.BridgeFormRecognitionSettingsSetUseCpuOnlyBoolean.restype = None
_lib.BridgeFormRecognitionSettingsSetUseCpuOnlyBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]

_lib.BridgeFormRecognitionSettingsGetConfidenceThreshold.restype = ctypes.c_float
_lib.BridgeFormRecognitionSettingsGetConfidenceThreshold.argtypes = [ctypes.c_void_p]

_lib.BridgeFormRecognitionSettingsSetConfidenceThresholdSingle.restype = None
_lib.BridgeFormRecognitionSettingsSetConfidenceThresholdSingle.argtypes = [ctypes.c_void_p, ctypes.c_float]

_lib.BridgeFormRecognitionSettingsGetNumSelect.restype = ctypes.c_int32
_lib.BridgeFormRecognitionSettingsGetNumSelect.argtypes = [ctypes.c_void_p]

_lib.BridgeFormRecognitionSettingsSetNumSelectInt32.restype = None
_lib.BridgeFormRecognitionSettingsSetNumSelectInt32.argtypes = [ctypes.c_void_p, ctypes.c_int32]

_lib.BridgeFormRecognitionSettingsGetNumClasses.restype = ctypes.c_int32
_lib.BridgeFormRecognitionSettingsGetNumClasses.argtypes = [ctypes.c_void_p]

_lib.BridgeFormRecognitionSettingsSetNumClassesInt32.restype = None
_lib.BridgeFormRecognitionSettingsSetNumClassesInt32.argtypes = [ctypes.c_void_p, ctypes.c_int32]


class FormRecognitionSettings:
    """
    Settings for FormRecognition. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate FormRecognitionSettings directly. Use static factory methods instead."""
        raise TypeError("FormRecognitionSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeFormRecognitionSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "FormRecognitionSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeFormRecognitionSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeFormRecognitionSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"FormRecognitionSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=FormRecognitionSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("FormRecognitionSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_model_path(self) -> str:
        """
        Path to the TorchScript RF-DETR model file (model.onnx).

        Returns:
            str: The value of the ModelPath property.

        Raises:
            FormRecognitionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeFormRecognitionSettingsGetModelPath(self._handle)
        self._check_error()
        return sdk_loader.convert_string_handle(result)

    def set_model_path(self, value: str) -> None:
        """
        Path to the TorchScript RF-DETR model file (model.onnx).

        Args:
            value (str)

        Returns:
            None: The result of the operation

        Raises:
            FormRecognitionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeFormRecognitionSettingsSetModelPathString(self._handle, value.encode('utf-8') if value else None)
        self._check_error()

    def get_use_cpu_only(self) -> bool:
        """
        Enable CPU mode for ONNX. When true, forces CPU execution. When false, attempts to use GPU if available (CUDA/MPS).

        Returns:
            bool: The value of the UseCpuOnly property.

        Raises:
            FormRecognitionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeFormRecognitionSettingsGetUseCpuOnly(self._handle)
        self._check_error()
        return result

    def set_use_cpu_only(self, value: bool) -> None:
        """
        Enable CPU mode for ONNX. When true, forces CPU execution. When false, attempts to use GPU if available (CUDA/MPS).

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            FormRecognitionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeFormRecognitionSettingsSetUseCpuOnlyBoolean(self._handle, value)
        self._check_error()

    def get_confidence_threshold(self) -> float:
        """
        Confidence threshold for form field predictions. Default is 0.5 as specified in the RF-DETR model.

        Returns:
            float: The value of the ConfidenceThreshold property.

        Raises:
            FormRecognitionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeFormRecognitionSettingsGetConfidenceThreshold(self._handle)
        self._check_error()
        return result

    def set_confidence_threshold(self, value: float) -> None:
        """
        Confidence threshold for form field predictions. Default is 0.5 as specified in the RF-DETR model.

        Args:
            value (float)

        Returns:
            None: The result of the operation

        Raises:
            FormRecognitionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeFormRecognitionSettingsSetConfidenceThresholdSingle(self._handle, value)
        self._check_error()

    def get_num_select(self) -> int:
        """
        Number of top predictions to select during postprocessing. Default is 300 as specified in the RF-DETR configuration.

        Returns:
            int: The value of the NumSelect property.

        Raises:
            FormRecognitionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeFormRecognitionSettingsGetNumSelect(self._handle)
        self._check_error()
        return result

    def set_num_select(self, value: int) -> None:
        """
        Number of top predictions to select during postprocessing. Default is 300 as specified in the RF-DETR configuration.

        Args:
            value (int)

        Returns:
            None: The result of the operation

        Raises:
            FormRecognitionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeFormRecognitionSettingsSetNumSelectInt32(self._handle, value)
        self._check_error()

    def get_num_classes(self) -> int:
        """
        Number of object classes (TextBox, ChoiceButton, Signature).

        Returns:
            int: The value of the NumClasses property.

        Raises:
            FormRecognitionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeFormRecognitionSettingsGetNumClasses(self._handle)
        self._check_error()
        return result

    def set_num_classes(self, value: int) -> None:
        """
        Number of object classes (TextBox, ChoiceButton, Signature).

        Args:
            value (int)

        Returns:
            None: The result of the operation

        Raises:
            FormRecognitionSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeFormRecognitionSettingsSetNumClassesInt32(self._handle, value)
        self._check_error()

    @property
    def model_path(self) -> str:
        """
        Path to the TorchScript RF-DETR model file (model.onnx).

        Returns:
            str: The value of the ModelPath property.
        """
        return self.get_model_path()

    @model_path.setter
    def model_path(self, value: str) -> None:
        """
        Sets the model path.

        Args:
            value (str): The value to set.
        """
        self.set_model_path(value)

    @property
    def use_cpu_only(self) -> bool:
        """
        Enable CPU mode for ONNX. When true, forces CPU execution. When false, attempts to use GPU if available (CUDA/MPS).

        Returns:
            bool: The value of the UseCpuOnly property.
        """
        return self.get_use_cpu_only()

    @use_cpu_only.setter
    def use_cpu_only(self, value: bool) -> None:
        """
        Sets the use cpu only.

        Args:
            value (bool): The value to set.
        """
        self.set_use_cpu_only(value)

    @property
    def confidence_threshold(self) -> float:
        """
        Confidence threshold for form field predictions. Default is 0.5 as specified in the RF-DETR model.

        Returns:
            float: The value of the ConfidenceThreshold property.
        """
        return self.get_confidence_threshold()

    @confidence_threshold.setter
    def confidence_threshold(self, value: float) -> None:
        """
        Sets the confidence threshold.

        Args:
            value (float): The value to set.
        """
        self.set_confidence_threshold(value)

    @property
    def num_select(self) -> int:
        """
        Number of top predictions to select during postprocessing. Default is 300 as specified in the RF-DETR configuration.

        Returns:
            int: The value of the NumSelect property.
        """
        return self.get_num_select()

    @num_select.setter
    def num_select(self, value: int) -> None:
        """
        Sets the num select.

        Args:
            value (int): The value to set.
        """
        self.set_num_select(value)

    @property
    def num_classes(self) -> int:
        """
        Number of object classes (TextBox, ChoiceButton, Signature).

        Returns:
            int: The value of the NumClasses property.
        """
        return self.get_num_classes()

    @num_classes.setter
    def num_classes(self, value: int) -> None:
        """
        Sets the num classes.

        Args:
            value (int): The value to set.
        """
        self.set_num_classes(value)
