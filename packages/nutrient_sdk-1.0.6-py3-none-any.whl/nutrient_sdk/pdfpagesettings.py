"""
PdfPageSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class PdfPageSettingsError(NutrientException):
    """Exception raised by PdfPageSettings operations."""
    pass

_lib.BridgePdfPageSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgePdfPageSettingsGetLastErrorCode.argtypes = []

_lib.BridgePdfPageSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgePdfPageSettingsGetLastErrorMessage.argtypes = []

_lib.BridgePdfPageSettingsFreeErrorString.restype = None
_lib.BridgePdfPageSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgePdfPageSettingsGetPageSize.restype = ctypes.c_int32
_lib.BridgePdfPageSettingsGetPageSize.argtypes = [ctypes.c_void_p]

_lib.BridgePdfPageSettingsSetPageSizePdfPageSizes.restype = None
_lib.BridgePdfPageSettingsSetPageSizePdfPageSizes.argtypes = [ctypes.c_void_p, ctypes.c_int32]


class PdfPageSettings:
    """
    Settings for PdfPage. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate PdfPageSettings directly. Use static factory methods instead."""
        raise TypeError("PdfPageSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgePdfPageSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "PdfPageSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgePdfPageSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgePdfPageSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"PdfPageSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=PdfPageSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("PdfPageSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_page_size(self) -> Any:
        """
        The page size for PDF documents.

        Returns:
            Any: The value of the PageSize property.

        Raises:
            PdfPageSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgePdfPageSettingsGetPageSize(self._handle)
        self._check_error()
        return result

    def set_page_size(self, value: Any) -> None:
        """
        The page size for PDF documents.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            PdfPageSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgePdfPageSettingsSetPageSizePdfPageSizes(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    @property
    def page_size(self) -> Any:
        """
        The page size for PDF documents.

        Returns:
            Any: The value of the PageSize property.
        """
        return self.get_page_size()

    @page_size.setter
    def page_size(self, value: Any) -> None:
        """
        Sets the page size.

        Args:
            value (Any): The value to set.
        """
        self.set_page_size(value)
