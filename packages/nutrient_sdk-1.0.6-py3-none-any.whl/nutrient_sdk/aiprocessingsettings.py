"""
AiProcessingSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class AiProcessingSettingsError(NutrientException):
    """Exception raised by AiProcessingSettings operations."""
    pass

_lib.BridgeAiProcessingSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeAiProcessingSettingsGetLastErrorCode.argtypes = []

_lib.BridgeAiProcessingSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeAiProcessingSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeAiProcessingSettingsFreeErrorString.restype = None
_lib.BridgeAiProcessingSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeAiProcessingSettingsGetProvider.restype = ctypes.c_void_p
_lib.BridgeAiProcessingSettingsGetProvider.argtypes = [ctypes.c_void_p]

_lib.BridgeAiProcessingSettingsSetProviderString.restype = None
_lib.BridgeAiProcessingSettingsSetProviderString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeAiProcessingSettingsGetModel.restype = ctypes.c_void_p
_lib.BridgeAiProcessingSettingsGetModel.argtypes = [ctypes.c_void_p]

_lib.BridgeAiProcessingSettingsSetModelString.restype = None
_lib.BridgeAiProcessingSettingsSetModelString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeAiProcessingSettingsGetEndpoint.restype = ctypes.c_void_p
_lib.BridgeAiProcessingSettingsGetEndpoint.argtypes = [ctypes.c_void_p]

_lib.BridgeAiProcessingSettingsSetEndpointString.restype = None
_lib.BridgeAiProcessingSettingsSetEndpointString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeAiProcessingSettingsGetApiKey.restype = ctypes.c_void_p
_lib.BridgeAiProcessingSettingsGetApiKey.argtypes = [ctypes.c_void_p]

_lib.BridgeAiProcessingSettingsSetApiKeyString.restype = None
_lib.BridgeAiProcessingSettingsSetApiKeyString.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

_lib.BridgeAiProcessingSettingsGetTemperature.restype = ctypes.c_double
_lib.BridgeAiProcessingSettingsGetTemperature.argtypes = [ctypes.c_void_p]

_lib.BridgeAiProcessingSettingsSetTemperatureNullableDouble.restype = None
_lib.BridgeAiProcessingSettingsSetTemperatureNullableDouble.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_bool]

_lib.BridgeAiProcessingSettingsGetMaxAttempts.restype = ctypes.c_int32
_lib.BridgeAiProcessingSettingsGetMaxAttempts.argtypes = [ctypes.c_void_p]

_lib.BridgeAiProcessingSettingsSetMaxAttemptsNullableInt32.restype = None
_lib.BridgeAiProcessingSettingsSetMaxAttemptsNullableInt32.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_bool]


class AiProcessingSettings:
    """
    Settings for AiProcessing. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate AiProcessingSettings directly. Use static factory methods instead."""
        raise TypeError("AiProcessingSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeAiProcessingSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "AiProcessingSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeAiProcessingSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeAiProcessingSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"AiProcessingSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=AiProcessingSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("AiProcessingSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_provider(self) -> str:
        """
        Provider discriminator. One of "openai", "azure", or "local".

        Returns:
            str: The value of the Provider property.

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeAiProcessingSettingsGetProvider(self._handle)
        self._check_error()
        return sdk_loader.convert_string_handle(result)

    def set_provider(self, value: str) -> None:
        """
        Provider discriminator. One of "openai", "azure", or "local".

        Args:
            value (str)

        Returns:
            None: The result of the operation

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeAiProcessingSettingsSetProviderString(self._handle, value.encode('utf-8') if value else None)
        self._check_error()

    def get_model(self) -> str:
        """
        Model identifier (e.g. "gpt-4o", an Azure deployment name, or a local model id).

        Returns:
            str: The value of the Model property.

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeAiProcessingSettingsGetModel(self._handle)
        self._check_error()
        return sdk_loader.convert_string_handle(result)

    def set_model(self, value: str) -> None:
        """
        Model identifier (e.g. "gpt-4o", an Azure deployment name, or a local model id).

        Args:
            value (str)

        Returns:
            None: The result of the operation

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeAiProcessingSettingsSetModelString(self._handle, value.encode('utf-8') if value else None)
        self._check_error()

    def get_endpoint(self) -> str:
        """
        Endpoint URL for Azure or local providers. Ignored for the public OpenAI provider.

        Returns:
            str: The value of the Endpoint property.

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeAiProcessingSettingsGetEndpoint(self._handle)
        self._check_error()
        return sdk_loader.convert_string_handle(result)

    def set_endpoint(self, value: str) -> None:
        """
        Endpoint URL for Azure or local providers. Ignored for the public OpenAI provider.

        Args:
            value (str)

        Returns:
            None: The result of the operation

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeAiProcessingSettingsSetEndpointString(self._handle, value.encode('utf-8') if value else None)
        self._check_error()

    def get_api_key(self) -> str:
        """
        API key for the configured provider.

        Returns:
            str: The value of the ApiKey property.

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeAiProcessingSettingsGetApiKey(self._handle)
        self._check_error()
        return sdk_loader.convert_string_handle(result)

    def set_api_key(self, value: str) -> None:
        """
        API key for the configured provider.

        Args:
            value (str)

        Returns:
            None: The result of the operation

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeAiProcessingSettingsSetApiKeyString(self._handle, value.encode('utf-8') if value else None)
        self._check_error()

    def get_temperature(self) -> Optional[float]:
        """
        Sampling temperature passed to the model. uses the provider default.

        Returns:
            Optional[float]: The value of the Temperature property.

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeAiProcessingSettingsGetTemperature(self._handle)
        self._check_error()
        return result

    def set_temperature(self, value: Optional[float]) -> None:
        """
        Sampling temperature passed to the model. uses the provider default.

        Args:
            value (Optional[float])

        Returns:
            None: The result of the operation

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeAiProcessingSettingsSetTemperatureNullableDouble(self._handle, value if value is not None else 0, value is not None)
        self._check_error()

    def get_max_attempts(self) -> Optional[int]:
        """
        Maximum retry attempts on structured-output failure. uses the capacity default of 1.

        Returns:
            Optional[int]: The value of the MaxAttempts property.

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeAiProcessingSettingsGetMaxAttempts(self._handle)
        self._check_error()
        return result

    def set_max_attempts(self, value: Optional[int]) -> None:
        """
        Maximum retry attempts on structured-output failure. uses the capacity default of 1.

        Args:
            value (Optional[int])

        Returns:
            None: The result of the operation

        Raises:
            AiProcessingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeAiProcessingSettingsSetMaxAttemptsNullableInt32(self._handle, value if value is not None else 0, value is not None)
        self._check_error()

    @property
    def provider(self) -> str:
        """
        Provider discriminator. One of "openai", "azure", or "local".

        Returns:
            str: The value of the Provider property.
        """
        return self.get_provider()

    @provider.setter
    def provider(self, value: str) -> None:
        """
        Sets the provider.

        Args:
            value (str): The value to set.
        """
        self.set_provider(value)

    @property
    def model(self) -> str:
        """
        Model identifier (e.g. "gpt-4o", an Azure deployment name, or a local model id).

        Returns:
            str: The value of the Model property.
        """
        return self.get_model()

    @model.setter
    def model(self, value: str) -> None:
        """
        Sets the model.

        Args:
            value (str): The value to set.
        """
        self.set_model(value)

    @property
    def endpoint(self) -> str:
        """
        Endpoint URL for Azure or local providers. Ignored for the public OpenAI provider.

        Returns:
            str: The value of the Endpoint property.
        """
        return self.get_endpoint()

    @endpoint.setter
    def endpoint(self, value: str) -> None:
        """
        Sets the endpoint.

        Args:
            value (str): The value to set.
        """
        self.set_endpoint(value)

    @property
    def api_key(self) -> str:
        """
        API key for the configured provider.

        Returns:
            str: The value of the ApiKey property.
        """
        return self.get_api_key()

    @api_key.setter
    def api_key(self, value: str) -> None:
        """
        Sets the api key.

        Args:
            value (str): The value to set.
        """
        self.set_api_key(value)

    @property
    def temperature(self) -> Optional[float]:
        """
        Sampling temperature passed to the model. uses the provider default.

        Returns:
            Optional[float]: The value of the Temperature property.
        """
        return self.get_temperature()

    @temperature.setter
    def temperature(self, value: Optional[float]) -> None:
        """
        Sets the temperature.

        Args:
            value (Optional[float]): The value to set.
        """
        self.set_temperature(value)

    @property
    def max_attempts(self) -> Optional[int]:
        """
        Maximum retry attempts on structured-output failure. uses the capacity default of 1.

        Returns:
            Optional[int]: The value of the MaxAttempts property.
        """
        return self.get_max_attempts()

    @max_attempts.setter
    def max_attempts(self, value: Optional[int]) -> None:
        """
        Sets the max attempts.

        Args:
            value (Optional[int]): The value to set.
        """
        self.set_max_attempts(value)
