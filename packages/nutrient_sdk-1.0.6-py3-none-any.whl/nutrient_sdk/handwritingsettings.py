"""
HandwritingSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class HandwritingSettingsError(NutrientException):
    """Exception raised by HandwritingSettings operations."""
    pass

_lib.BridgeHandwritingSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeHandwritingSettingsGetLastErrorCode.argtypes = []

_lib.BridgeHandwritingSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeHandwritingSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeHandwritingSettingsFreeErrorString.restype = None
_lib.BridgeHandwritingSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeHandwritingSettingsGetWordRefiningMethod.restype = ctypes.c_int32
_lib.BridgeHandwritingSettingsGetWordRefiningMethod.argtypes = [ctypes.c_void_p]

_lib.BridgeHandwritingSettingsSetWordRefiningMethodWordRefiningMethod.restype = None
_lib.BridgeHandwritingSettingsSetWordRefiningMethodWordRefiningMethod.argtypes = [ctypes.c_void_p, ctypes.c_int32]


class HandwritingSettings:
    """
    Settings for Handwriting. Values fall back through three levels: document → SDK → built-in default. Writes target the document only when set on a document's settings, otherwise the SDK globally when set on SdkSettings.
    """

    def __init__(self):
        """Cannot instantiate HandwritingSettings directly. Use static factory methods instead."""
        raise TypeError("HandwritingSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeHandwritingSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "HandwritingSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeHandwritingSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeHandwritingSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"HandwritingSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=HandwritingSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("HandwritingSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_word_refining_method(self) -> Any:
        """
        Controls the method used to refine detected handwritten words when AI-augmented text is available for the zone.

        Returns:
            Any: The value of the WordRefiningMethod property.

        Raises:
            HandwritingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeHandwritingSettingsGetWordRefiningMethod(self._handle)
        self._check_error()
        return result

    def set_word_refining_method(self, value: Any) -> None:
        """
        Controls the method used to refine detected handwritten words when AI-augmented text is available for the zone.

        Args:
            value (Any)

        Returns:
            None: The result of the operation

        Raises:
            HandwritingSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeHandwritingSettingsSetWordRefiningMethodWordRefiningMethod(self._handle, value.value if isinstance(value, Enum) else value)
        self._check_error()

    @property
    def word_refining_method(self) -> Any:
        """
        Controls the method used to refine detected handwritten words when AI-augmented text is available for the zone.

        Returns:
            Any: The value of the WordRefiningMethod property.
        """
        return self.get_word_refining_method()

    @word_refining_method.setter
    def word_refining_method(self, value: Any) -> None:
        """
        Sets the word refining method.

        Args:
            value (Any): The value to set.
        """
        self.set_word_refining_method(value)
