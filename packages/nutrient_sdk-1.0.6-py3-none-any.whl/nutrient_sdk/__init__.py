"""Nutrient SDK for Python."""

from importlib.metadata import version as _pkg_version, PackageNotFoundError
try:
    __version__ = _pkg_version("nutrient-sdk")
except PackageNotFoundError:
    # Running from a source tree without an installed wheel.
    __version__ = "0.0.0"

__author__ = "Nutrient"
__license__ = "Commercial"

from .base_exception import (
    NutrientException,
    SDKError,
    InitializationError,
    LicenseError,
    DocumentError,
    ConversionError,
    ValidationError,
    IOError,
    MemoryError,
    TimeoutError,
    NotImplementedError,
    PermissionError,
    ErrorInfo,
    handle_native_error
)

from .iexporter import IExporter, IExporterBase

from .alreadyopenforeditionexception import AlreadyOpenForEditionException
from .barcodeexception import BarcodeException
from .barcodeinvaliddataexception import BarcodeInvalidDataException
from .barcodeinvalidnotnumericdataexception import BarcodeInvalidNotNumericDataException
from .barcodeinvalidlengthexception import BarcodeInvalidLengthException
from .barcodeinvalidstartexception import BarcodeInvalidStartException
from .barcodeinvalidstopexception import BarcodeInvalidStopException
from .barcodeinvalidtypeexception import BarcodeInvalidTypeException
from .barcodeinvalidwidthexception import BarcodeInvalidWidthException
from .exportexception import ExportException
from .featureunlicensedexception import FeatureUnLicensedException
from .filenotfoundexception import FileNotFoundException
from .implicitconversionexception import ImplicitConversionException
from .incompatibletypeexception import IncompatibleTypeException
from .indexoutofboundsexception import IndexOutOfBoundsException
from .invalidargumentexception import InvalidArgumentException
from .invalidlicenseexception import InvalidLicenseException
from .invalidsettingsexception import InvalidSettingsException
from .invalidstateexception import InvalidStateException
from .invalidtemplateexception import InvalidTemplateException
from .nulloremptyparameterexception import NullOrEmptyParameterException
from .nutrientargumentnullexception import NutrientArgumentNullException
from .unsupportedconversion import UnsupportedConversion
from .visionexception import VisionException
from .sdkexception import SdkException

from .sdksettings import SdkSettings
from .document import Document
from .license import License
from .vision import Vision
from .digitalsignatureoptions import DigitalSignatureOptions
from .signature import Signature
from .signatureappearance import SignatureAppearance
from .timestampconfiguration import TimestampConfiguration
from .htmlexporter import HtmlExporter
from .imageexporter import ImageExporter
from .markdownexporter import MarkdownExporter
from .pdfexporter import PdfExporter
from .presentationexporter import PresentationExporter
from .spreadsheetexporter import SpreadsheetExporter
from .svgexporter import SvgExporter
from .wordexporter import WordExporter
from .pdfeditor import PdfEditor
from .wordeditor import WordEditor
from .pdfpage import PdfPage
from .pdfpagecollection import PdfPageCollection
from .pdfcheckboxfield import PdfCheckBoxField
from .pdfformfield import PdfFormField
from .pdfcomboboxfield import PdfComboBoxField
from .pdfformfieldcollection import PdfFormFieldCollection
from .pdflistboxfield import PdfListBoxField
from .pdfpushbuttonfield import PdfPushButtonField
from .pdfradiobuttonfield import PdfRadioButtonField
from .pdfsignaturefield import PdfSignatureField
from .pdftextfield import PdfTextField
from .pdfannotation import PdfAnnotation
from .pdfannotationcollection import PdfAnnotationCollection
from .pdflinkannotation import PdfLinkAnnotation
from .pdfmarkupannotation import PdfMarkupAnnotation
from .pdffreetextannotation import PdfFreeTextAnnotation
from .pdfwidgetannotation import PdfWidgetAnnotation
from .pdfstampannotation import PdfStampAnnotation
from .pdfredactannotation import PdfRedactAnnotation
from .pdfshapeannotation import PdfShapeAnnotation
from .pdflineannotation import PdfLineAnnotation
from .pdfcircleannotation import PdfCircleAnnotation
from .pdfsquareannotation import PdfSquareAnnotation
from .pdftextannotation import PdfTextAnnotation
from .pdfhighlightannotation import PdfHighlightAnnotation
from .pdfunderlineannotation import PdfUnderlineAnnotation
from .pdfstrikeoutannotation import PdfStrikeOutAnnotation
from .pdfsquigglyannotation import PdfSquigglyAnnotation
from .internallogic import InternalLogic
from .color import Color
from .aiaugmentersettings import AiAugmenterSettings
from .aiprocessingsettings import AiProcessingSettings
from .cadsettings import CadSettings
from .documentlayoutjsonexportsettings import DocumentLayoutJsonExportSettings
from .pdfmetadata import PdfMetadata
from .claudeapisettings import ClaudeApiSettings
from .contentextractionsettings import ContentExtractionSettings
from .conversionsettings import ConversionSettings
from .customvlmapisettings import CustomVlmApiSettings
from .deskewsettings import DeskewSettings
from .emailsettings import EmailSettings
from .finalizersettings import FinalizerSettings
from .formrecognitionsettings import FormRecognitionSettings
from .handwritingsettings import HandwritingSettings
from .htmlsettings import HtmlSettings
from .imagesettings import ImageSettings
from .inferencelayoutsettings import InferenceLayoutSettings
from .instantjsonsettings import InstantJsonSettings
from .jbig2settings import Jbig2Settings
from .jpegsettings import JpegSettings
from .markdownsettings import MarkdownSettings
from .ocrsettings import OcrSettings
from .openaiapiendpointsettings import OpenAIApiEndpointSettings
from .openailanguagesdetectionsettings import OpenAILanguagesDetectionSettings
from .openaipicturealtsettings import OpenAIPictureAltSettings
from .opensettings import OpenSettings
from .pdfpagesettings import PdfPageSettings
from .pdfsettings import PdfSettings
from .presentationsettings import PresentationSettings
from .readingordersettings import ReadingOrderSettings
from .segmentersettings import SegmenterSettings
from .spreadsheetsettings import SpreadsheetSettings
from .tablerecognitionsettings import TableRecognitionSettings
from .tiffsettings import TiffSettings
from .visiondescriptorsettings import VisionDescriptorSettings
from .visionsettings import VisionSettings
from .wordsdetectionsettings import WordsDetectionSettings
from .wordsettings import WordSettings
from .documentsettings import DocumentSettings

from .wordrefiningmethod import WordRefiningMethod
from .imagesettingmode import ImageSettingMode
from .renderinglayoutmode import RenderingLayoutMode
from .htmllayouttype import HtmlLayoutType
from .imageexportformat import ImageExportFormat
from .unitmode import UnitMode
from .imageexportmode import ImageExportMode
from .instantjsonrendertheme import InstantJsonRenderTheme
from .jsonexportcontent import JsonExportContent
from .jsonexportformat import JsonExportFormat
from .documenttype import DocumentType
from .signaturehashalgorithm import SignatureHashAlgorithm
from .tiffcompression import TiffCompression
from .descriptionlevel import DescriptionLevel
from .vlmclassificationstrategy import VlmClassificationStrategy
from .pdfborderstyle import PdfBorderStyle
from .pdfpagesizes import PdfPageSizes
from .vlmprovider import VlmProvider
from .pdfformfieldtype import PdfFormFieldType
from .visionfeatures import VisionFeatures
from .visionengine import VisionEngine
from .visionoutputformat import VisionOutputFormat
from .documentmarkupmode import DocumentMarkupMode
from .documentbookmarksource import DocumentBookmarkSource
from .pdfrubberstampicon import PdfRubberStampIcon
from .pdflineendingstyle import PdfLineEndingStyle
from .pagecachemode import PageCacheMode
from .opensettingsmode import OpenSettingsMode
from .documentformat import DocumentFormat
from .implicitconversion import ImplicitConversion
from .pdfconformance import PdfConformance
from .pdfsettingsmode import PdfSettingsMode
from .pdfsavepreferences import PdfSavePreferences
from .pdfcompression import PdfCompression
from .textdirection import TextDirection

from .sdk_loader import (
    initialize_sdk,
    shutdown_sdk,
    get_sdk_version,
    is_sdk_initialized,
    SDKError
)

__all__ = [
    'initialize_sdk',
    'shutdown_sdk',
    'get_sdk_version',
    'is_sdk_initialized',
    'NutrientException',
    'SDKError',
    'InitializationError',
    'LicenseError',
    'DocumentError',
    'ConversionError',
    'ValidationError',
    'IOError',
    'MemoryError',
    'TimeoutError',
    'NotImplementedError',
    'PermissionError',
    'ErrorInfo',
    'handle_native_error',
    'IExporter',
    'IExporterBase',
    'AlreadyOpenForEditionException',
    'BarcodeException',
    'BarcodeInvalidDataException',
    'BarcodeInvalidNotNumericDataException',
    'BarcodeInvalidLengthException',
    'BarcodeInvalidStartException',
    'BarcodeInvalidStopException',
    'BarcodeInvalidTypeException',
    'BarcodeInvalidWidthException',
    'ExportException',
    'FeatureUnLicensedException',
    'FileNotFoundException',
    'ImplicitConversionException',
    'IncompatibleTypeException',
    'IndexOutOfBoundsException',
    'InvalidArgumentException',
    'InvalidLicenseException',
    'InvalidSettingsException',
    'InvalidStateException',
    'InvalidTemplateException',
    'NullOrEmptyParameterException',
    'NutrientArgumentNullException',
    'UnsupportedConversion',
    'VisionException',
    'SdkException',
    'SdkSettings',
    'Document',
    'License',
    'Vision',
    'DigitalSignatureOptions',
    'Signature',
    'SignatureAppearance',
    'TimestampConfiguration',
    'HtmlExporter',
    'ImageExporter',
    'MarkdownExporter',
    'PdfExporter',
    'PresentationExporter',
    'SpreadsheetExporter',
    'SvgExporter',
    'WordExporter',
    'PdfEditor',
    'WordEditor',
    'PdfPage',
    'PdfPageCollection',
    'PdfCheckBoxField',
    'PdfFormField',
    'PdfComboBoxField',
    'PdfFormFieldCollection',
    'PdfListBoxField',
    'PdfPushButtonField',
    'PdfRadioButtonField',
    'PdfSignatureField',
    'PdfTextField',
    'PdfAnnotation',
    'PdfAnnotationCollection',
    'PdfLinkAnnotation',
    'PdfMarkupAnnotation',
    'PdfFreeTextAnnotation',
    'PdfWidgetAnnotation',
    'PdfStampAnnotation',
    'PdfRedactAnnotation',
    'PdfShapeAnnotation',
    'PdfLineAnnotation',
    'PdfCircleAnnotation',
    'PdfSquareAnnotation',
    'PdfTextAnnotation',
    'PdfHighlightAnnotation',
    'PdfUnderlineAnnotation',
    'PdfStrikeOutAnnotation',
    'PdfSquigglyAnnotation',
    'InternalLogic',
    'Color',
    'AiAugmenterSettings',
    'AiProcessingSettings',
    'CadSettings',
    'DocumentLayoutJsonExportSettings',
    'PdfMetadata',
    'ClaudeApiSettings',
    'ContentExtractionSettings',
    'ConversionSettings',
    'CustomVlmApiSettings',
    'DeskewSettings',
    'EmailSettings',
    'FinalizerSettings',
    'FormRecognitionSettings',
    'HandwritingSettings',
    'HtmlSettings',
    'ImageSettings',
    'InferenceLayoutSettings',
    'InstantJsonSettings',
    'Jbig2Settings',
    'JpegSettings',
    'MarkdownSettings',
    'OcrSettings',
    'OpenAIApiEndpointSettings',
    'OpenAILanguagesDetectionSettings',
    'OpenAIPictureAltSettings',
    'OpenSettings',
    'PdfPageSettings',
    'PdfSettings',
    'PresentationSettings',
    'ReadingOrderSettings',
    'SegmenterSettings',
    'SpreadsheetSettings',
    'TableRecognitionSettings',
    'TiffSettings',
    'VisionDescriptorSettings',
    'VisionSettings',
    'WordsDetectionSettings',
    'WordSettings',
    'DocumentSettings',
    'WordRefiningMethod',
    'ImageSettingMode',
    'RenderingLayoutMode',
    'HtmlLayoutType',
    'ImageExportFormat',
    'UnitMode',
    'ImageExportMode',
    'InstantJsonRenderTheme',
    'JsonExportContent',
    'JsonExportFormat',
    'DocumentType',
    'SignatureHashAlgorithm',
    'TiffCompression',
    'DescriptionLevel',
    'VlmClassificationStrategy',
    'PdfBorderStyle',
    'PdfPageSizes',
    'VlmProvider',
    'PdfFormFieldType',
    'VisionFeatures',
    'VisionEngine',
    'VisionOutputFormat',
    'DocumentMarkupMode',
    'DocumentBookmarkSource',
    'PdfRubberStampIcon',
    'PdfLineEndingStyle',
    'PageCacheMode',
    'OpenSettingsMode',
    'DocumentFormat',
    'ImplicitConversion',
    'PdfConformance',
    'PdfSettingsMode',
    'PdfSavePreferences',
    'PdfCompression',
    'TextDirection',
]

_initialized = False

def _auto_initialize():
    global _initialized
    if not _initialized:
        try:
            initialize_sdk()
            _initialized = True
        except SDKError as e:
            import warnings
            warnings.warn(f"Failed to auto-initialize Nutrient SDK: {e}", RuntimeWarning)

import os
if not os.environ.get('NUTRIENT_NO_AUTO_INIT'):
    _auto_initialize()

import atexit

def _cleanup():
    global _initialized
    if _initialized:
        try:
            shutdown_sdk()
            _initialized = False
        except:
            pass  # Ignore errors during cleanup

atexit.register(_cleanup)
