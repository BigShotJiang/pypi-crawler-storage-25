"""
Method used to refine handwritten word text when AI-augmented text is available.
"""

from enum import Enum, auto
import ctypes

class WordRefiningMethod(Enum):
    """Method used to refine handwritten word text when AI-augmented text is available.."""
    
    HEURISTIC = 0
    # Uses heuristic character-level alignment to redistribute AI-augmented word boundaries across detected bounding boxes.
    
    VLM = 1
    # Uses an additional AI model call to correct each detected word's text individually.
    
    
    @classmethod
    def from_value(cls, value: int) -> 'WordRefiningMethod':
        """
        Create an enum instance from an integer value.
        
        Args:
            value: The integer value to convert
            
        Returns:
            The corresponding WordRefiningMethod instance
            
        Raises:
            ValueError: If the value doesn't correspond to a valid enum member
        """
        for member in cls:
            if member.value == value:
                return member
        raise ValueError(f"Invalid {cls.__name__} value: {value}")
    
    def to_ctype(self) -> ctypes.c_int:
        """
        Convert to ctypes representation for native calls.
        
        Returns:
            ctypes.c_int: The enum value as a ctypes integer
        """
        return ctypes.c_int(self.value)
    
    def __str__(self) -> str:
        """String representation of the enum value."""
        return f"{self.__class__.__name__}.{self.name}"
    
    def __repr__(self) -> str:
        """Detailed representation of the enum value."""
        return f"<{self.__class__.__name__}.{self.name}: {self.value}>"

__all__ = ['WordRefiningMethod']
