"""AgentShift — CLI transpiler for converting AI agents between platforms."""

__version__ = "0.4.1"
