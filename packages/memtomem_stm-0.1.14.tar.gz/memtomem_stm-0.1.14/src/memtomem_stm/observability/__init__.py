"""Observability — Langfuse tracing integration."""
