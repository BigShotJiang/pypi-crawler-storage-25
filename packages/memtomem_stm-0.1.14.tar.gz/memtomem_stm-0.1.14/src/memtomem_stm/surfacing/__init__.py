"""Proactive memory surfacing engine."""
