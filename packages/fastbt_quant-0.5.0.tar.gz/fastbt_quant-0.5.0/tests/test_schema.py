"""Tests for fastbt.schema — Pydantic models for JSON declarative strategies."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from fastbt.schema import (
    Condition,
    ConditionGroup,
    IndicatorRef,
    PositionSizing,
    StopsConfig,
    StrategySpec,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SMA10 = {"indicator": "sma", "params": {"period": 10}, "output": "value"}
_SMA30 = {"indicator": "sma", "params": {"period": 30}, "output": "value"}
_RSI14 = {"indicator": "rsi", "params": {"period": 14}, "output": "value"}


def _minimal_spec(**overrides: object) -> dict:
    """Return a minimal valid spec dict, with optional overrides."""
    spec: dict = {
        "version": "0.0.3",
        "entry": {"all": [{"left": _SMA10, "operator": "crosses_above", "right": _SMA30}]},
        "exit": {"any": [{"left": _RSI14, "operator": ">", "right": 70}]},
    }
    spec.update(overrides)
    return spec


# ---------------------------------------------------------------------------
# 1. Valid spec with all fields
# ---------------------------------------------------------------------------


def test_valid_full_spec() -> None:
    spec = _minimal_spec(
        position_sizing={"method": "percent_equity", "pct": 95},
    )
    model = StrategySpec.model_validate(spec)
    assert model.version == "0.0.3"
    assert model.position_sizing.method == "percent_equity"
    assert model.position_sizing.pct == 95


# ---------------------------------------------------------------------------
# 2. Valid spec with minimal fields (defaults applied)
# ---------------------------------------------------------------------------


def test_valid_minimal_spec_defaults() -> None:
    model = StrategySpec.model_validate(_minimal_spec())
    assert model.position_sizing.method == "fixed_qty"
    assert model.position_sizing.qty == 100


# ---------------------------------------------------------------------------
# 3. Invalid version
# ---------------------------------------------------------------------------


def test_invalid_version() -> None:
    with pytest.raises(ValidationError, match="version"):
        StrategySpec.model_validate(_minimal_spec(version="0.0.1"))


# ---------------------------------------------------------------------------
# 4. Missing entry/exit
# ---------------------------------------------------------------------------


def test_missing_entry() -> None:
    spec = _minimal_spec()
    del spec["entry"]
    with pytest.raises(ValidationError, match="entry"):
        StrategySpec.model_validate(spec)


def test_missing_exit() -> None:
    spec = _minimal_spec()
    del spec["exit"]
    with pytest.raises(ValidationError, match="exit"):
        StrategySpec.model_validate(spec)


# ---------------------------------------------------------------------------
# 5. Unknown operator
# ---------------------------------------------------------------------------


def test_unknown_operator() -> None:
    with pytest.raises(ValidationError, match="operator"):
        Condition.model_validate({"left": _SMA10, "operator": "INVALID", "right": _SMA30})


# ---------------------------------------------------------------------------
# 6. Invalid source
# ---------------------------------------------------------------------------


def test_invalid_source() -> None:
    with pytest.raises(ValidationError, match="source"):
        IndicatorRef.model_validate(
            {"indicator": "sma", "params": {"period": 10}, "output": "value", "source": "vwap"}
        )


# ---------------------------------------------------------------------------
# 7. ConditionGroup with both all AND any
# ---------------------------------------------------------------------------


def test_condition_group_both_all_and_any() -> None:
    cond = {"left": _SMA10, "operator": ">", "right": 50.0}
    with pytest.raises(ValidationError, match="Exactly one"):
        ConditionGroup.model_validate({"all": [cond], "any": [cond]})


# ---------------------------------------------------------------------------
# 8. ConditionGroup with neither all nor any
# ---------------------------------------------------------------------------


def test_condition_group_neither() -> None:
    with pytest.raises(ValidationError, match="Exactly one"):
        ConditionGroup.model_validate({})


# ---------------------------------------------------------------------------
# 9. Condition with two floats (no IndicatorRef)
# ---------------------------------------------------------------------------


def test_condition_two_floats() -> None:
    with pytest.raises(ValidationError, match="IndicatorRef"):
        Condition.model_validate({"left": 10.0, "operator": ">", "right": 20.0})


# ---------------------------------------------------------------------------
# 10. PositionSizing wrong field for method
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("method", "fields"),
    [
        ("fixed_qty", {"pct": 50}),
        ("percent_equity", {"qty": 100}),
        ("fixed_cash", {"qty": 100}),
    ],
)
def test_position_sizing_wrong_field(method: str, fields: dict) -> None:
    with pytest.raises(ValidationError):
        PositionSizing.model_validate({"method": method, **fields})


# ---------------------------------------------------------------------------
# 11. Nested ConditionGroup (all containing any)
# ---------------------------------------------------------------------------


def test_nested_condition_group() -> None:
    spec = _minimal_spec(
        entry={
            "all": [
                {"left": _SMA10, "operator": "crosses_above", "right": _SMA30},
                {
                    "any": [
                        {"left": _RSI14, "operator": ">", "right": 30.0},
                        {"left": _RSI14, "operator": "<", "right": 70.0},
                    ]
                },
            ]
        }
    )
    model = StrategySpec.model_validate(spec)
    assert model.entry.all is not None
    assert len(model.entry.all) == 2
    nested = model.entry.all[1]
    assert isinstance(nested, ConditionGroup)
    assert nested.any is not None
    assert len(nested.any) == 2


# ---------------------------------------------------------------------------
# 12. JSON round-trip
# ---------------------------------------------------------------------------


def test_json_round_trip() -> None:
    original = StrategySpec.model_validate(_minimal_spec())
    json_str = original.model_dump_json()
    restored = StrategySpec.model_validate_json(json_str)
    assert original == restored


# ---------------------------------------------------------------------------
# 13. IndicatorRef with offset
# ---------------------------------------------------------------------------


def test_indicator_ref_offset() -> None:
    ref = IndicatorRef.model_validate(
        {"indicator": "sma", "params": {"period": 10}, "output": "value", "offset": -1}
    )
    assert ref.offset == -1


# ---------------------------------------------------------------------------
# 14. IndicatorRef with non-default source
# ---------------------------------------------------------------------------


def test_indicator_ref_non_default_source() -> None:
    ref = IndicatorRef.model_validate(
        {"indicator": "atr", "params": {"period": 14}, "output": "value", "source": "hlc3"}
    )
    assert ref.source == "hlc3"


# ---------------------------------------------------------------------------
# 15. IndicatorRef registry validation (D12 — fail-fast at schema boundary)
# ---------------------------------------------------------------------------


def test_indicator_ref_unknown_indicator_raises() -> None:
    with pytest.raises(ValidationError, match="not found"):
        IndicatorRef.model_validate(
            {"indicator": "ghost_indicator", "params": {}, "output": "value"}
        )


def test_indicator_ref_unknown_param_raises() -> None:
    with pytest.raises(ValidationError, match="Unknown params"):
        IndicatorRef.model_validate(
            {"indicator": "rsi", "params": {"periood": 14}, "output": "value"}
        )


def test_indicator_ref_unknown_output_raises() -> None:
    with pytest.raises(ValidationError, match="Invalid output 'k_line'"):
        IndicatorRef.model_validate(
            {"indicator": "macd", "params": {}, "output": "k_line"}
        )


def test_indicator_ref_multi_output_valid() -> None:
    # macd has output_names=["macd", "signal", "histogram"] — all should validate
    for out in ("macd", "signal", "histogram"):
        ref = IndicatorRef.model_validate(
            {"indicator": "macd", "params": {}, "output": out}
        )
        assert ref.output == out


def test_indicator_ref_default_params_accepted() -> None:
    # Indicators with no required params (e.g. obv, vwap) should accept empty params
    ref = IndicatorRef.model_validate(
        {"indicator": "obv", "params": {}, "output": "value"}
    )
    assert ref.indicator == "obv"


# ---------------------------------------------------------------------------
# 16. StopsConfig and back-compat shim (D4, D11)
# ---------------------------------------------------------------------------


def test_stops_config_all_fields_default_none() -> None:
    cfg = StopsConfig()
    assert cfg.stop_loss_pct is None
    assert cfg.vol_trailing_multiplier is None
    assert cfg.vol_trailing_lookback == 60  # only field with non-None default
    assert cfg.has_stop_loss is False


def test_stops_config_to_engine_dict_omits_none() -> None:
    cfg = StopsConfig(stop_loss_pct=5.0, take_profit_pct=10.0)
    out = cfg.to_engine_dict()
    assert out == {"stop_loss_pct": 5.0, "take_profit_pct": 10.0}


def test_stops_config_vol_trailing_lookback_only_emitted_when_active() -> None:
    # vol_trailing_lookback default 60 should NOT leak into engine dict when
    # vol_trailing_multiplier is None (the band is inactive)
    cfg = StopsConfig(stop_loss_pct=5.0)
    assert "vol_trailing_lookback" not in cfg.to_engine_dict()


def test_stops_config_vol_trailing_lookback_emitted_with_multiplier() -> None:
    cfg = StopsConfig(vol_trailing_multiplier=2.0, vol_trailing_lookback=90)
    out = cfg.to_engine_dict()
    assert out["vol_trailing_multiplier"] == 2.0
    assert out["vol_trailing_lookback"] == 90


def test_stops_config_vol_trailing_all_three_fields() -> None:
    cfg = StopsConfig(
        vol_trailing_multiplier=2.0,
        vol_trailing_lookback=60,
        vol_trailing_fallback_pct=10.0,
    )
    out = cfg.to_engine_dict()
    assert out == {
        "vol_trailing_multiplier": 2.0,
        "vol_trailing_lookback": 60,
        "vol_trailing_fallback_pct": 10.0,
    }


def test_strategyspec_nested_stops_form() -> None:
    spec = _minimal_spec(stops={"stop_loss_pct": 5.0, "take_profit_pct": 10.0})
    model = StrategySpec.model_validate(spec)
    assert model.stops is not None
    assert model.stops.stop_loss_pct == 5.0
    assert model.stops.take_profit_pct == 10.0


def test_strategyspec_legacy_flat_stops_normalized() -> None:
    # Pre-v0.4.0 flat shape — stops at top level — must still validate (D4 shim)
    spec = _minimal_spec(stop_loss_pct=5.0, take_profit_pct=10.0)
    model = StrategySpec.model_validate(spec)
    assert model.stops is not None
    assert model.stops.stop_loss_pct == 5.0
    assert model.stops.take_profit_pct == 10.0


def test_strategyspec_legacy_flat_vol_trailing_normalized() -> None:
    # New vol_trailing fields work in the legacy flat shape too (Part A of v0.4.0)
    spec = _minimal_spec(
        vol_trailing_multiplier=2.0,
        vol_trailing_lookback=90,
        vol_trailing_fallback_pct=10.0,
    )
    model = StrategySpec.model_validate(spec)
    assert model.stops is not None
    assert model.stops.vol_trailing_multiplier == 2.0
    assert model.stops.vol_trailing_lookback == 90
    assert model.stops.vol_trailing_fallback_pct == 10.0


def test_strategyspec_no_stops_returns_none() -> None:
    spec = _minimal_spec()
    model = StrategySpec.model_validate(spec)
    assert model.stops is None


def test_strategyspec_both_flat_and_nested_raises() -> None:
    # D11: silent precedence in financial config is a foot-gun — error loudly.
    spec = _minimal_spec(
        stop_loss_pct=5.0,
        stops={"stop_loss_pct": 3.0},
    )
    with pytest.raises(ValidationError, match="Cannot mix flat and nested stops"):
        StrategySpec.model_validate(spec)


def test_strategyspec_empty_nested_stops_treated_as_unset() -> None:
    # An explicitly empty `stops: {}` should not block flat fields — but in
    # practice we forbid mixing, so this asserts an empty dict still allows
    # flat lift.
    spec = _minimal_spec(stops={}, stop_loss_pct=5.0)
    model = StrategySpec.model_validate(spec)
    assert model.stops is not None
    assert model.stops.stop_loss_pct == 5.0


def test_strategyspec_risk_pct_with_nested_stop_loss_ok() -> None:
    spec = _minimal_spec(
        position_sizing={"method": "risk_pct", "risk_fraction": 0.01},
        stops={"stop_loss_pct": 2.0},
    )
    model = StrategySpec.model_validate(spec)
    assert model.position_sizing.method == "risk_pct"
    assert model.stops.stop_loss_pct == 2.0


def test_strategyspec_risk_pct_with_legacy_flat_stop_loss_ok() -> None:
    spec = _minimal_spec(
        position_sizing={"method": "risk_pct", "risk_fraction": 0.01},
        stop_loss_pct=2.0,
    )
    model = StrategySpec.model_validate(spec)
    assert model.stops is not None
    assert model.stops.stop_loss_pct == 2.0


def test_strategyspec_risk_pct_without_any_stop_loss_raises() -> None:
    spec = _minimal_spec(
        position_sizing={"method": "risk_pct", "risk_fraction": 0.01},
    )
    with pytest.raises(ValidationError, match="risk_pct sizing requires"):
        StrategySpec.model_validate(spec)


def test_strategyspec_risk_pct_with_take_profit_only_raises() -> None:
    # Take-profit isn't a stop-loss; risk_pct still needs an actual stop-loss.
    spec = _minimal_spec(
        position_sizing={"method": "risk_pct", "risk_fraction": 0.01},
        stops={"take_profit_pct": 5.0},
    )
    with pytest.raises(ValidationError, match="risk_pct sizing requires"):
        StrategySpec.model_validate(spec)


# ---------------------------------------------------------------------------
# 17. kind discriminator (D1) and version 0.4.0
# ---------------------------------------------------------------------------


def test_strategyspec_kind_defaults_to_single() -> None:
    model = StrategySpec.model_validate(_minimal_spec())
    assert model.kind == "single"


def test_strategyspec_kind_explicit_single() -> None:
    spec = _minimal_spec()
    spec["kind"] = "single"
    model = StrategySpec.model_validate(spec)
    assert model.kind == "single"


def test_strategyspec_kind_portfolio_rejected() -> None:
    spec = _minimal_spec()
    spec["kind"] = "portfolio"
    with pytest.raises(ValidationError):
        StrategySpec.model_validate(spec)


def test_strategyspec_version_040_accepted() -> None:
    spec = _minimal_spec(version="0.4.0")
    model = StrategySpec.model_validate(spec)
    assert model.version == "0.4.0"


def test_strategyspec_legacy_versions_still_accepted() -> None:
    for v in ("0.0.3", "0.2.0"):
        spec = _minimal_spec(version=v)
        model = StrategySpec.model_validate(spec)
        assert model.version == v


def test_strategyspec_unknown_version_rejected() -> None:
    with pytest.raises(ValidationError):
        StrategySpec.model_validate(_minimal_spec(version="0.5.0"))
