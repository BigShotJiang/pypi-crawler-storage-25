"""Tests for RebalanceSchedule."""

import pandas as pd
import pytest

from fastbt.schedule import RebalanceSchedule


class TestEveryBar:
    def test_always_true(self):
        s = RebalanceSchedule.every_bar()
        ts = pd.Timestamp("2024-01-15")
        assert s.should_rebalance(ts, 0) is True
        assert s.should_rebalance(ts, 1) is True
        assert s.should_rebalance(ts, 999) is True

    def test_repr(self):
        assert "every_bar" in repr(RebalanceSchedule.every_bar())


class TestEveryNBars:
    def test_modulo(self):
        s = RebalanceSchedule.every_n_bars(3)
        results = [s.should_rebalance(pd.Timestamp("2024-01-01"), i) for i in range(10)]
        assert results == [True, False, False, True, False, False, True, False, False, True]

    def test_every_1_is_every_bar(self):
        s = RebalanceSchedule.every_n_bars(1)
        for i in range(5):
            assert s.should_rebalance(pd.Timestamp("2024-01-01"), i) is True

    def test_zero_raises(self):
        with pytest.raises(ValueError, match="n must be >= 1"):
            RebalanceSchedule.every_n_bars(0)

    def test_negative_raises(self):
        with pytest.raises(ValueError, match="n must be >= 1"):
            RebalanceSchedule.every_n_bars(-1)

    def test_repr(self):
        assert "every_5_bars" in repr(RebalanceSchedule.every_n_bars(5))


class TestWeekly:
    def test_fires_on_correct_day(self):
        s = RebalanceSchedule.weekly(day=4)  # Friday
        # 2024-01-05 is a Friday
        friday = pd.Timestamp("2024-01-05")
        assert friday.weekday() == 4
        assert s.should_rebalance(friday, 0) is True

    def test_skips_other_days(self):
        s = RebalanceSchedule.weekly(day=4)  # Friday
        # 2024-01-08 is a Monday
        monday = pd.Timestamp("2024-01-08")
        assert monday.weekday() == 0
        assert s.should_rebalance(monday, 0) is False

    def test_monday_schedule(self):
        s = RebalanceSchedule.weekly(day=0)  # Monday
        monday = pd.Timestamp("2024-01-08")
        tuesday = pd.Timestamp("2024-01-09")
        assert s.should_rebalance(monday, 0) is True
        assert s.should_rebalance(tuesday, 1) is False

    def test_invalid_day_raises(self):
        with pytest.raises(ValueError, match="day must be 0-6"):
            RebalanceSchedule.weekly(day=7)

    def test_negative_day_raises(self):
        with pytest.raises(ValueError, match="day must be 0-6"):
            RebalanceSchedule.weekly(day=-1)

    def test_repr(self):
        assert "weekly(fri)" in repr(RebalanceSchedule.weekly(4))
        assert "weekly(mon)" in repr(RebalanceSchedule.weekly(0))


class TestMonthlyFirst:
    def test_fires_on_month_change(self):
        s = RebalanceSchedule.monthly("first")
        index = pd.bdate_range("2024-01-01", "2024-03-31")
        s._prepare(index)

        results = {}
        for i, ts in enumerate(index):
            if s.should_rebalance(ts, i):
                results[ts] = True

        # Should fire on first trading day of Jan, Feb, Mar
        fired_months = {ts.month for ts in results}
        assert fired_months == {1, 2, 3}

        # Should fire on exactly 3 days
        assert len(results) == 3

    def test_fires_on_first_bar(self):
        s = RebalanceSchedule.monthly("first")
        ts = pd.Timestamp("2024-06-15")  # mid-month, but it's bar 0
        assert s.should_rebalance(ts, 0) is True

    def test_prepare_resets_state(self):
        s = RebalanceSchedule.monthly("first")
        index = pd.bdate_range("2024-01-01", "2024-01-31")
        # First run
        s._prepare(index)
        s.should_rebalance(index[0], 0)
        # Second run should reset
        s._prepare(index)
        assert s.should_rebalance(index[0], 0) is True


class TestMonthlyLast:
    def test_fires_on_last_trading_day(self):
        s = RebalanceSchedule.monthly("last")
        index = pd.bdate_range("2024-01-01", "2024-03-31")
        s._prepare(index)

        fired = [ts for i, ts in enumerate(index) if s.should_rebalance(ts, i)]

        # Should fire on last trading day of Jan, Feb, Mar
        assert len(fired) == 3
        fired_months = {ts.month for ts in fired}
        assert fired_months == {1, 2, 3}

        # Each fired day should be the last business day of its month
        for ts in fired:
            month_days = [d for d in index if d.month == ts.month and d.year == ts.year]
            assert ts == month_days[-1]

    def test_without_prepare_raises(self):
        s = RebalanceSchedule.monthly("last")
        with pytest.raises(RuntimeError, match="_prepare"):
            s.should_rebalance(pd.Timestamp("2024-01-31"), 0)

    def test_single_month_data(self):
        s = RebalanceSchedule.monthly("last")
        index = pd.bdate_range("2024-01-01", "2024-01-31")
        s._prepare(index)

        fired = [ts for i, ts in enumerate(index) if s.should_rebalance(ts, i)]
        assert len(fired) == 1
        assert fired[0] == index[-1]


class TestMonthlyInvalid:
    def test_invalid_when_raises(self):
        with pytest.raises(ValueError, match="must be 'first' or 'last'"):
            RebalanceSchedule.monthly("middle")

    def test_repr(self):
        assert "monthly(first)" in repr(RebalanceSchedule.monthly("first"))
        assert "monthly(last)" in repr(RebalanceSchedule.monthly("last"))


class TestMonthlyDayN:
    def test_fires_on_exact_day_when_trading_day(self):
        # Jan 15, 2024 is a Monday — a trading day
        s = RebalanceSchedule.monthly(day=15)
        index = pd.bdate_range("2024-01-01", "2024-03-31")
        s._prepare(index)

        fired = [ts for i, ts in enumerate(index) if s.should_rebalance(ts, i)]
        # Three months → three fires
        assert len(fired) == 3
        # First fire is exactly Jan 15
        assert fired[0] == pd.Timestamp("2024-01-15")

    def test_fires_after_weekend_when_day_is_saturday(self):
        # Jun 15, 2024 is a Saturday → fire on Mon Jun 17
        s = RebalanceSchedule.monthly(day=15)
        index = pd.bdate_range("2024-06-01", "2024-06-30")
        s._prepare(index)

        fired = [ts for i, ts in enumerate(index) if s.should_rebalance(ts, i)]
        assert len(fired) == 1
        assert fired[0] == pd.Timestamp("2024-06-17")  # Mon after Sat 15th

    def test_clamps_to_last_trading_day_when_day_n_doesnt_exist(self):
        # Feb 30 doesn't exist; clamp to last trading day of Feb
        s = RebalanceSchedule.monthly(day=30)
        index = pd.bdate_range("2024-02-01", "2024-02-29")
        s._prepare(index)

        fired = [ts for i, ts in enumerate(index) if s.should_rebalance(ts, i)]
        assert len(fired) == 1
        # Last business day of Feb 2024 is Thu Feb 29
        assert fired[0] == pd.Timestamp("2024-02-29")

    def test_one_rebalance_per_month_invariant(self):
        # Year-long range with day=30 — every month must get exactly one fire
        s = RebalanceSchedule.monthly(day=30)
        index = pd.bdate_range("2024-01-01", "2024-12-31")
        s._prepare(index)

        fired = [ts for i, ts in enumerate(index) if s.should_rebalance(ts, i)]
        # 12 months → 12 fires, no duplicates
        assert len(fired) == 12
        fired_months = [(ts.year, ts.month) for ts in fired]
        assert len(set(fired_months)) == 12

    def test_day_1_is_first_trading_day(self):
        # day=1 is equivalent to monthly("first") in spirit
        s = RebalanceSchedule.monthly(day=1)
        index = pd.bdate_range("2024-01-01", "2024-03-31")
        s._prepare(index)

        fired = [ts for i, ts in enumerate(index) if s.should_rebalance(ts, i)]
        # Three months → three fires, each on the first trading day
        assert len(fired) == 3
        for ts in fired:
            month_days = [d for d in index if d.month == ts.month and d.year == ts.year]
            assert ts == month_days[0]

    def test_invalid_day_raises(self):
        with pytest.raises(ValueError, match="day must be 1..31"):
            RebalanceSchedule.monthly(day=0)
        with pytest.raises(ValueError, match="day must be 1..31"):
            RebalanceSchedule.monthly(day=32)
        with pytest.raises(ValueError, match="day must be 1..31"):
            RebalanceSchedule.monthly(day=-1)

    def test_without_prepare_raises(self):
        s = RebalanceSchedule.monthly(day=15)
        with pytest.raises(RuntimeError, match="_prepare"):
            s.should_rebalance(pd.Timestamp("2024-01-15"), 0)

    def test_repr_includes_day(self):
        assert "monthly(day=15)" in repr(RebalanceSchedule.monthly(day=15))


class TestCustom:
    def test_custom_predicate(self):
        # Fire on even bar indices only
        s = RebalanceSchedule.custom(lambda ts, i: i % 2 == 0)
        ts = pd.Timestamp("2024-01-01")
        assert s.should_rebalance(ts, 0) is True
        assert s.should_rebalance(ts, 1) is False
        assert s.should_rebalance(ts, 2) is True

    def test_repr(self):
        assert "custom" in repr(RebalanceSchedule.custom(lambda ts, i: True))


class TestPrepare:
    def test_noop_by_default(self):
        s = RebalanceSchedule.every_bar()
        index = pd.bdate_range("2024-01-01", "2024-01-31")
        # Should not raise
        s._prepare(index)
        # Should still work normally
        assert s.should_rebalance(index[0], 0) is True
