"""Direct broker tests — focuses on symbol-aware order draining."""

from __future__ import annotations

import pandas as pd

from fastbt.broker import PaperBroker
from fastbt.types import Bar, OrderSide


def _bar(symbol: str, open_: float, close: float, ts: str = "2023-01-02") -> Bar:
    return Bar(
        timestamp=pd.Timestamp(ts),
        symbol=symbol,
        open=open_,
        high=max(open_, close) + 1,
        low=min(open_, close) - 1,
        close=close,
        volume=1000.0,
    )


class TestSymbolAwareDraining:
    """Pending orders must fill at THEIR OWN symbol's bar price.

    Pre-fix bug: _drain_pending(price) ignored order.symbol, so the first
    on_bar_open call drained every pending order at one common price.
    """

    def test_two_symbols_fill_at_own_open(self):
        broker = PaperBroker(initial_cash=1_000_000, fill_policy="next_open")
        ts = pd.Timestamp("2023-01-01")

        # Submit BUYs for two very different price points
        broker.submit_market("CHEAP", OrderSide.BUY, 10, ts)
        broker.submit_market("PRICEY", OrderSide.BUY, 5, ts)

        broker.on_bar_open(_bar("CHEAP", open_=100.0, close=101.0))
        broker.on_bar_open(_bar("PRICEY", open_=3000.0, close=3010.0))

        fills = broker.fills()
        assert len(fills) == 2
        by_sym = {f.symbol: f.price for f in fills}
        assert by_sym["CHEAP"] == 100.0
        assert by_sym["PRICEY"] == 3000.0

    def test_call_order_does_not_change_fills(self):
        """Bug regression: regardless of which bar is processed first, each
        order fills at its own symbol's open."""
        broker = PaperBroker(initial_cash=1_000_000, fill_policy="next_open")
        ts = pd.Timestamp("2023-01-01")
        broker.submit_market("CHEAP", OrderSide.BUY, 10, ts)
        broker.submit_market("PRICEY", OrderSide.BUY, 5, ts)

        # Reverse order vs. previous test
        broker.on_bar_open(_bar("PRICEY", open_=3000.0, close=3010.0))
        broker.on_bar_open(_bar("CHEAP", open_=100.0, close=101.0))

        by_sym = {f.symbol: f.price for f in broker.fills()}
        assert by_sym["CHEAP"] == 100.0
        assert by_sym["PRICEY"] == 3000.0

    def test_unrelated_symbol_bar_does_not_drain(self):
        broker = PaperBroker(initial_cash=1_000_000, fill_policy="next_open")
        ts = pd.Timestamp("2023-01-01")
        broker.submit_market("A", OrderSide.BUY, 10, ts)

        broker.on_bar_open(_bar("B", open_=999.0, close=999.0))
        # A's order must remain pending — no B bar should fill an A order.
        assert len(broker.fills()) == 0

        broker.on_bar_open(_bar("A", open_=100.0, close=101.0))
        fills = broker.fills()
        assert len(fills) == 1
        assert fills[0].symbol == "A"
        assert fills[0].price == 100.0

    def test_close_policy_also_symbol_aware(self):
        """current_close fill policy must filter by symbol too."""
        broker = PaperBroker(initial_cash=1_000_000, fill_policy="current_close")
        ts = pd.Timestamp("2023-01-01")
        broker.submit_market("CHEAP", OrderSide.BUY, 10, ts)
        broker.submit_market("PRICEY", OrderSide.BUY, 5, ts)

        # First close call must NOT drain everything at one symbol's close.
        broker.on_bar_close(_bar("CHEAP", open_=100.0, close=105.0))
        broker.on_bar_close(_bar("PRICEY", open_=3000.0, close=3050.0))

        by_sym = {f.symbol: f.price for f in broker.fills()}
        assert by_sym["CHEAP"] == 105.0
        assert by_sym["PRICEY"] == 3050.0

    def test_multiple_orders_same_symbol_all_fill(self):
        """A symbol with multiple pending orders should fill them all on its bar."""
        broker = PaperBroker(initial_cash=1_000_000, fill_policy="next_open")
        ts = pd.Timestamp("2023-01-01")
        broker.submit_market("A", OrderSide.BUY, 10, ts)
        broker.submit_market("A", OrderSide.BUY, 5, ts)

        broker.on_bar_open(_bar("A", open_=100.0, close=101.0))

        fills = broker.fills()
        assert len(fills) == 2
        assert all(f.symbol == "A" and f.price == 100.0 for f in fills)
