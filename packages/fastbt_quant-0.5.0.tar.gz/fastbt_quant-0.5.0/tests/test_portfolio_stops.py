"""Tests for portfolio_backtest stop integration (v0.3.0)."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from fastbt.engine import StopOutEvent, portfolio_backtest
from fastbt.portfolio_strategy import PortfolioStrategy


def _ohlcv_from_closes(closes: list[float], start: str = "2024-01-01") -> pd.DataFrame:
    """Build a deterministic OHLCV DataFrame from a list of closes."""
    dates = pd.bdate_range(start, periods=len(closes))
    return pd.DataFrame(
        {
            "open": closes,
            "high": [c * 1.005 for c in closes],
            "low": [c * 0.995 for c in closes],
            "close": closes,
            "volume": [10_000] * len(closes),
        },
        index=dates,
    )


class _EqualWeightAll(PortfolioStrategy):
    """Allocate equal weight to every symbol every rebalance."""

    def on_rebalance(self, ctx):
        n = len(ctx.symbols)
        if n == 0:
            return {}
        w = 1.0 / n
        return {s: w for s in ctx.symbols}


# ---------------------------------------------------------------------------
# REGRESSION: no-stop config behaves identically
# ---------------------------------------------------------------------------


class TestRegression:
    def test_no_stop_kwargs_means_no_stops(self):
        # Drop scenario for one symbol
        crash = [100.0] * 5 + [50.0] * 5  # 50% crash on bar 5
        stable = [100.0] * 10
        data = {
            "CRASH": _ohlcv_from_closes(crash),
            "STABLE": _ohlcv_from_closes(stable),
        }
        result = portfolio_backtest(
            _EqualWeightAll(),
            data,
            fill_policy="current_close",
            initial_cash=100_000,
        )
        # No stops configured → no stop_outs recorded
        assert result.stop_outs == []

    def test_default_stop_outs_is_empty_list(self):
        data = {"A": _ohlcv_from_closes([100.0] * 10)}
        result = portfolio_backtest(
            _EqualWeightAll(),
            data,
            fill_policy="current_close",
        )
        assert isinstance(result.stop_outs, list)
        assert result.stop_outs == []


# ---------------------------------------------------------------------------
# Per-symbol stop firing
# ---------------------------------------------------------------------------


class TestPortfolioStopLoss:
    def test_stop_fires_on_crashing_symbol(self):
        # CRASH drops 30% on bar 5; STABLE flat
        crash = [100.0] * 5 + [70.0] * 10
        stable = [100.0] * 15
        data = {
            "CRASH": _ohlcv_from_closes(crash),
            "STABLE": _ohlcv_from_closes(stable),
        }
        result = portfolio_backtest(
            _EqualWeightAll(),
            data,
            fill_policy="current_close",
            initial_cash=100_000,
            stop_loss_pct=10.0,
        )
        # CRASH should hit its 10% stop; STABLE should not
        crash_stops = [e for e in result.stop_outs if e.symbol == "CRASH"]
        stable_stops = [e for e in result.stop_outs if e.symbol == "STABLE"]
        assert len(crash_stops) >= 1
        assert len(stable_stops) == 0
        # Verify event payload shape
        e = crash_stops[0]
        assert isinstance(e, StopOutEvent)
        assert e.kind == "sl"
        assert e.entry_price > 0
        assert e.exit_price > 0
        assert e.pnl < 0  # crash → losing trade
        assert e.days_held >= 0

    def test_stops_only_recorded_for_long_positions(self):
        # No positions opened (no rebalance triggered on bar 0) → no stops
        data = {
            "A": _ohlcv_from_closes([100.0] * 5),
        }

        class _NoOp(PortfolioStrategy):
            def on_rebalance(self, ctx):
                return {}

        result = portfolio_backtest(
            _NoOp(),
            data,
            fill_policy="current_close",
            stop_loss_pct=10.0,
        )
        assert result.stop_outs == []


# ---------------------------------------------------------------------------
# Same-bar cooldown
# ---------------------------------------------------------------------------


class TestSameBarCooldown:
    def test_stopped_symbol_not_re_entered_same_bar(self):
        # Every-bar rebalance + a crash on one symbol
        # Bar 0: rebalance, both bought
        # Bar 5: CRASH drops, stop fires, then SAME-BAR rebalance must skip CRASH
        crash = [100.0] * 5 + [50.0] * 5  # 50% drop bar 5
        stable = [100.0] * 10
        data = {
            "CRASH": _ohlcv_from_closes(crash),
            "STABLE": _ohlcv_from_closes(stable),
        }
        result = portfolio_backtest(
            _EqualWeightAll(),
            data,
            fill_policy="current_close",
            initial_cash=100_000,
            stop_loss_pct=10.0,
        )
        # CRASH should have stopped at least once
        crash_stops = [e for e in result.stop_outs if e.symbol == "CRASH"]
        assert len(crash_stops) >= 1

        # Verify the stop happened (cooldown is internal, hard to observe directly,
        # but the integration test below verifies the behavior)

    def test_stopped_symbol_can_re_enter_next_bar(self):
        # CRASH drops bar 2 → stop fires + cooldown excludes from bar-2 rebalance
        # CRASH then recovers bar 3 onward → strategy can rebuy on bar 3
        crash = [100.0, 100.0, 50.0, 100.0, 100.0, 100.0, 100.0]
        stable = [100.0] * 7
        data = {
            "CRASH": _ohlcv_from_closes(crash),
            "STABLE": _ohlcv_from_closes(stable),
        }
        result = portfolio_backtest(
            _EqualWeightAll(),
            data,
            fill_policy="current_close",
            initial_cash=100_000,
            stop_loss_pct=10.0,
        )
        crash_stops = [e for e in result.stop_outs if e.symbol == "CRASH"]
        assert len(crash_stops) >= 1
        # After cooldown, CRASH should appear in weight_history again
        # (Strategy rebuys on bar 3+ once eligible)
        crash_weights_after_stop = result.weight_history["CRASH"].iloc[3:]
        assert (crash_weights_after_stop > 0).any()


# ---------------------------------------------------------------------------
# stop_config() hook on PortfolioStrategy
# ---------------------------------------------------------------------------


class TestStopConfigHook:
    def test_strategy_stop_config_used(self):
        class _StopFromStrategy(_EqualWeightAll):
            def stop_config(self):
                return {"stop_loss_pct": 5.0}

        # CRASH drops 8% — within 5% stop band of strategy config
        crash = [100.0] * 3 + [92.0] * 5
        data = {"CRASH": _ohlcv_from_closes(crash)}
        result = portfolio_backtest(
            _StopFromStrategy(),
            data,
            fill_policy="current_close",
            initial_cash=100_000,
        )
        assert len(result.stop_outs) >= 1
        assert result.stop_outs[0].kind == "sl"

    def test_kwargs_override_strategy_stop_config(self):
        # Strategy config says 20% stop, kwargs say 5% — kwargs win
        class _LooseStops(_EqualWeightAll):
            def stop_config(self):
                return {"stop_loss_pct": 20.0}

        crash = [100.0] * 3 + [92.0] * 5  # 8% drop
        data = {"CRASH": _ohlcv_from_closes(crash)}
        result = portfolio_backtest(
            _LooseStops(),
            data,
            fill_policy="current_close",
            initial_cash=100_000,
            stop_loss_pct=5.0,
        )
        # 5% kwarg overrides 20% strategy config → 8% drop fires
        assert len(result.stop_outs) >= 1


# ---------------------------------------------------------------------------
# vol_trailing in portfolio mode
# ---------------------------------------------------------------------------


class TestVolTrailingPortfolio:
    def test_vol_trailing_falls_back_when_history_short(self):
        # Short history (< 60 bars) → vol_trailing uses fallback_pct=10
        crash = [100.0] * 3 + [85.0] * 5  # 15% drop
        data = {"CRASH": _ohlcv_from_closes(crash)}
        result = portfolio_backtest(
            _EqualWeightAll(),
            data,
            fill_policy="current_close",
            initial_cash=100_000,
            vol_trailing_multiplier=2.0,
            vol_trailing_lookback=60,
            vol_trailing_fallback_pct=10.0,
        )
        assert len(result.stop_outs) >= 1
        assert result.stop_outs[0].kind == "vol_ts"

    def test_vol_trailing_uses_history_when_long_enough(self):
        # 80 bars of stable data + a vol spike
        rng = np.random.default_rng(42)
        prices = list(100 + rng.standard_normal(80).cumsum() * 0.5)
        prices.extend([prices[-1] * 0.7] * 5)  # 30% drop after 80 bars
        data = {"X": _ohlcv_from_closes(prices)}
        result = portfolio_backtest(
            _EqualWeightAll(),
            data,
            fill_policy="current_close",
            initial_cash=100_000,
            vol_trailing_multiplier=2.0,
            vol_trailing_lookback=60,
            vol_trailing_fallback_pct=50.0,  # absurd to detect fallback path
        )
        # The 30% drop is well past any reasonable vol*2 band → stop fires
        assert len(result.stop_outs) >= 1
        assert result.stop_outs[0].kind == "vol_ts"
