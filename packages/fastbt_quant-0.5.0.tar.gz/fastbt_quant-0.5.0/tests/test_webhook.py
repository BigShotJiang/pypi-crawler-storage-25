"""Tests for webhook dispatcher — HMAC, retry, backoff."""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
from unittest.mock import AsyncMock, MagicMock

import pytest

from fastbt.signal_types import PositionState, SignalPayload, SignalType
from fastbt.webhook import WebhookConfig, WebhookDispatcher


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_signal(
    signal_type: SignalType = SignalType.ENTRY_LONG,
) -> SignalPayload:
    return SignalPayload(
        version="0.2.0",
        type=signal_type,
        symbol="NIFTY",
        timestamp="2024-01-15T09:30:00",
        bar={"open": 100, "high": 101, "low": 99, "close": 100.5, "volume": 10000},
        position=PositionState(qty=100, avg_entry_price=100.5, unrealized_pnl=0.0, side="long"),
        reason="Test signal",
        side="buy",
        qty=100.0,
        price=100.5,
    )


class _FakeResponse:
    def __init__(self, status: int):
        self.status = status


def _run(coro):
    """Run an async coroutine synchronously."""
    return asyncio.get_event_loop().run_until_complete(coro)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestWebhookConfig:
    def test_defaults(self):
        cfg = WebhookConfig(urls=["http://example.com/hook"])
        assert cfg.secret is None
        assert cfg.max_retries == 3
        assert cfg.backoff_base == 1.0
        assert cfg.timeout == 10.0


class TestDispatchSkipsNoAction:
    def test_no_action_not_sent(self):
        cfg = WebhookConfig(urls=["http://example.com/hook"])
        dispatcher = WebhookDispatcher(cfg)
        dispatcher._session = MagicMock()

        signal = _make_signal(SignalType.NO_ACTION)
        results = _run(dispatcher.dispatch(signal))
        assert results == [True]
        dispatcher._session.post.assert_not_called()


class TestSuccessfulDelivery:
    def test_single_url_success(self):
        cfg = WebhookConfig(urls=["http://example.com/hook"])
        dispatcher = WebhookDispatcher(cfg)
        mock_session = AsyncMock()
        mock_session.post.return_value = _FakeResponse(200)
        dispatcher._session = mock_session

        signal = _make_signal()
        results = _run(dispatcher.dispatch(signal))
        assert results == [True]
        mock_session.post.assert_called_once()

    def test_multiple_urls(self):
        cfg = WebhookConfig(
            urls=["http://a.com/hook", "http://b.com/hook", "http://c.com/hook"]
        )
        dispatcher = WebhookDispatcher(cfg)
        mock_session = AsyncMock()
        mock_session.post.return_value = _FakeResponse(200)
        dispatcher._session = mock_session

        signal = _make_signal()
        results = _run(dispatcher.dispatch(signal))
        assert results == [True, True, True]
        assert mock_session.post.call_count == 3


class TestHMACSignature:
    def test_signature_header_present(self):
        secret = "my-secret-key"
        cfg = WebhookConfig(urls=["http://example.com/hook"], secret=secret)
        dispatcher = WebhookDispatcher(cfg)
        mock_session = AsyncMock()
        mock_session.post.return_value = _FakeResponse(200)
        dispatcher._session = mock_session

        signal = _make_signal()
        _run(dispatcher.dispatch(signal))

        call_kwargs = mock_session.post.call_args
        headers = call_kwargs.kwargs.get("headers") or call_kwargs[1].get("headers")
        assert "X-Fastbt-Signature" in headers

        body = call_kwargs.kwargs.get("data") or call_kwargs[1].get("data")
        expected_sig = hmac.new(
            secret.encode("utf-8"), body, hashlib.sha256
        ).hexdigest()
        assert headers["X-Fastbt-Signature"] == expected_sig

    def test_no_signature_without_secret(self):
        cfg = WebhookConfig(urls=["http://example.com/hook"])
        dispatcher = WebhookDispatcher(cfg)
        mock_session = AsyncMock()
        mock_session.post.return_value = _FakeResponse(200)
        dispatcher._session = mock_session

        signal = _make_signal()
        _run(dispatcher.dispatch(signal))

        call_kwargs = mock_session.post.call_args
        headers = call_kwargs.kwargs.get("headers") or call_kwargs[1].get("headers")
        assert "X-Fastbt-Signature" not in headers


class TestEventHeader:
    def test_event_header_matches_signal_type(self):
        cfg = WebhookConfig(urls=["http://example.com/hook"])
        dispatcher = WebhookDispatcher(cfg)
        mock_session = AsyncMock()
        mock_session.post.return_value = _FakeResponse(200)
        dispatcher._session = mock_session

        signal = _make_signal(SignalType.STOP_LOSS_HIT)
        _run(dispatcher.dispatch(signal))

        call_kwargs = mock_session.post.call_args
        headers = call_kwargs.kwargs.get("headers") or call_kwargs[1].get("headers")
        assert headers["X-Fastbt-Event"] == "stop_loss_hit"


class TestRetry:
    def test_retry_on_500(self):
        cfg = WebhookConfig(
            urls=["http://example.com/hook"],
            max_retries=2,
            backoff_base=0.01,
        )
        dispatcher = WebhookDispatcher(cfg)
        mock_session = AsyncMock()
        mock_session.post.side_effect = [
            _FakeResponse(500),
            _FakeResponse(500),
            _FakeResponse(200),
        ]
        dispatcher._session = mock_session

        signal = _make_signal()
        results = _run(dispatcher.dispatch(signal))
        assert results == [True]
        assert mock_session.post.call_count == 3

    def test_retry_on_exception(self):
        cfg = WebhookConfig(
            urls=["http://example.com/hook"],
            max_retries=1,
            backoff_base=0.01,
        )
        dispatcher = WebhookDispatcher(cfg)
        mock_session = AsyncMock()
        mock_session.post.side_effect = [
            ConnectionError("refused"),
            _FakeResponse(200),
        ]
        dispatcher._session = mock_session

        signal = _make_signal()
        results = _run(dispatcher.dispatch(signal))
        assert results == [True]
        assert mock_session.post.call_count == 2

    def test_max_retries_exhausted(self):
        cfg = WebhookConfig(
            urls=["http://example.com/hook"],
            max_retries=2,
            backoff_base=0.01,
        )
        dispatcher = WebhookDispatcher(cfg)
        mock_session = AsyncMock()
        mock_session.post.return_value = _FakeResponse(500)
        dispatcher._session = mock_session

        signal = _make_signal()
        results = _run(dispatcher.dispatch(signal))
        assert results == [False]
        assert mock_session.post.call_count == 3

    def test_no_retry_on_4xx(self):
        cfg = WebhookConfig(
            urls=["http://example.com/hook"],
            max_retries=3,
            backoff_base=0.01,
        )
        dispatcher = WebhookDispatcher(cfg)
        mock_session = AsyncMock()
        mock_session.post.return_value = _FakeResponse(400)
        dispatcher._session = mock_session

        signal = _make_signal()
        results = _run(dispatcher.dispatch(signal))
        assert results == [False]
        assert mock_session.post.call_count == 1


class TestPayloadBody:
    def test_body_is_valid_json(self):
        cfg = WebhookConfig(urls=["http://example.com/hook"])
        dispatcher = WebhookDispatcher(cfg)
        mock_session = AsyncMock()
        mock_session.post.return_value = _FakeResponse(200)
        dispatcher._session = mock_session

        signal = _make_signal()
        _run(dispatcher.dispatch(signal))

        call_kwargs = mock_session.post.call_args
        body = call_kwargs.kwargs.get("data") or call_kwargs[1].get("data")
        parsed = json.loads(body)
        assert parsed["type"] == "entry_long"
        assert parsed["symbol"] == "NIFTY"
        assert parsed["version"] == "0.2.0"
