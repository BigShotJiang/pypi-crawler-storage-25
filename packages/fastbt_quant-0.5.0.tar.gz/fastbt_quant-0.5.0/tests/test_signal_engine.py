"""Tests for signal_engine — stateful bar-by-bar signal processor."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from fastbt import Strategy, backtest
from fastbt.signal_engine import SignalEngine
from fastbt.signal_types import PositionState, SignalPayload, SignalType
from fastbt.types import Bar


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _bar(
    close: float,
    ts: str,
    open_: float | None = None,
    high: float | None = None,
    low: float | None = None,
    volume: float = 1000.0,
    symbol: str = "SYMBOL",
) -> Bar:
    o = open_ if open_ is not None else close
    h = high if high is not None else max(close, o) + 1
    lo = low if low is not None else min(close, o) - 1
    return Bar(
        timestamp=pd.Timestamp(ts),
        symbol=symbol,
        open=o,
        high=h,
        low=lo,
        close=close,
        volume=volume,
    )


class _BuyOnBar1(Strategy):
    """Buy on bar 1 (after warmup bar 0). Never exit."""

    def on_bar(self, ctx):
        if ctx.position.is_flat and len(ctx.history) > 1:
            ctx.buy(qty=100)


class _BuyOnceOnBar1(Strategy):
    """Buy exactly on bar 1. Never re-enter after stop."""

    def __init__(self, params=None):
        super().__init__(params)
        self._bought = False

    def on_bar(self, ctx):
        bar_idx = len(ctx.history) - 1
        if bar_idx == 1 and not self._bought:
            ctx.buy(qty=100)
            self._bought = True


class _BuyAndSell(Strategy):
    """Buy on bar 1, sell on bar 3."""

    def on_bar(self, ctx):
        bar_idx = len(ctx.history) - 1
        if bar_idx == 1 and ctx.position.is_flat:
            ctx.buy(qty=100)
        elif bar_idx == 3 and ctx.position.is_long:
            ctx.close()


class _SellShort(Strategy):
    """Short sell on bar 1."""

    def on_bar(self, ctx):
        if ctx.position.is_flat and len(ctx.history) > 1:
            ctx.sell(qty=100)


# ---------------------------------------------------------------------------
# Basic signal detection
# ---------------------------------------------------------------------------


class TestFirstBar:
    def test_first_bar_returns_no_action(self):
        engine = SignalEngine(_BuyOnBar1(), fill_policy="current_close")
        signal = engine.process_bar(_bar(100, "2024-01-01"))
        assert signal.type == SignalType.NO_ACTION
        assert signal.symbol == "SYMBOL"
        assert signal.version == "0.2.0"
        assert signal.side is None
        assert signal.qty is None
        assert signal.price is None

    def test_first_bar_position_is_flat(self):
        engine = SignalEngine(_BuyOnBar1(), fill_policy="current_close")
        signal = engine.process_bar(_bar(100, "2024-01-01"))
        assert signal.position.side == "flat"
        assert signal.position.qty == 0


class TestEntrySignals:
    def test_entry_long_signal(self):
        engine = SignalEngine(_BuyOnBar1(), fill_policy="current_close")
        engine.process_bar(_bar(100, "2024-01-01"))
        signal = engine.process_bar(_bar(102, "2024-01-02"))
        assert signal.type == SignalType.ENTRY_LONG
        assert signal.side == "buy"
        assert signal.qty == 100
        assert signal.price is not None
        assert signal.position.side == "long"
        assert signal.position.qty == 100

    def test_entry_short_signal(self):
        engine = SignalEngine(
            _SellShort(),
            fill_policy="current_close",
            initial_cash=100_000,
        )
        engine.process_bar(_bar(100, "2024-01-01"))
        signal = engine.process_bar(_bar(98, "2024-01-02"))
        assert signal.type == SignalType.ENTRY_SHORT
        assert signal.side == "sell"
        assert signal.qty == 100
        assert signal.position.side == "short"


class TestExitSignal:
    def test_exit_signal(self):
        engine = SignalEngine(_BuyAndSell(), fill_policy="current_close")
        engine.process_bar(_bar(100, "2024-01-01"))  # bar 0
        engine.process_bar(_bar(102, "2024-01-02"))  # bar 1: entry
        engine.process_bar(_bar(104, "2024-01-03"))  # bar 2: hold
        signal = engine.process_bar(_bar(106, "2024-01-04"))  # bar 3: exit
        assert signal.type == SignalType.EXIT_SIGNAL
        assert signal.position.side == "flat"

    def test_hold_returns_no_action(self):
        engine = SignalEngine(_BuyAndSell(), fill_policy="current_close")
        engine.process_bar(_bar(100, "2024-01-01"))
        engine.process_bar(_bar(102, "2024-01-02"))  # entry
        signal = engine.process_bar(_bar(104, "2024-01-03"))  # hold
        assert signal.type == SignalType.NO_ACTION


# ---------------------------------------------------------------------------
# Stop hit signals
# ---------------------------------------------------------------------------


class TestStopLossSignal:
    def test_stop_loss_hit_signal(self):
        engine = SignalEngine(
            _BuyOnceOnBar1(),
            fill_policy="current_close",
            stop_loss_pct=5.0,
        )
        engine.process_bar(_bar(100, "2024-01-01"))  # bar 0
        engine.process_bar(_bar(100, "2024-01-02"))  # bar 1: buy fills at close=100
        # Bar 2: low breaches SL at 95 (5% below 100)
        signal = engine.process_bar(
            _bar(90, "2024-01-03", open_=98, high=99, low=88)
        )
        assert signal.type == SignalType.STOP_LOSS_HIT
        assert signal.position.side == "flat"


class TestTakeProfitSignal:
    def test_take_profit_hit_signal(self):
        engine = SignalEngine(
            _BuyOnceOnBar1(),
            fill_policy="current_close",
            take_profit_pct=10.0,
        )
        engine.process_bar(_bar(100, "2024-01-01"))
        engine.process_bar(_bar(100, "2024-01-02"))  # buy at 100
        # Bar 2: high breaches TP at 110 (10% above 100)
        signal = engine.process_bar(
            _bar(112, "2024-01-03", open_=105, high=115, low=104)
        )
        assert signal.type == SignalType.TAKE_PROFIT_HIT
        assert signal.position.side == "flat"


class TestTrailingStopSignal:
    def test_trailing_stop_hit_signal(self):
        engine = SignalEngine(
            _BuyOnceOnBar1(),
            fill_policy="current_close",
            trailing_stop_pct=5.0,
        )
        engine.process_bar(_bar(100, "2024-01-01"))
        engine.process_bar(_bar(100, "2024-01-02"))  # buy at 100
        # Bar 2: high=120 sets high-water, trail=114. low=110 > 114? No.
        # Actually trail = 120 * 0.95 = 114, low=110 < 114 → triggers
        signal = engine.process_bar(
            _bar(112, "2024-01-03", open_=105, high=120, low=110)
        )
        assert signal.type == SignalType.TRAILING_STOP_HIT
        assert signal.position.side == "flat"


# ---------------------------------------------------------------------------
# Warmup
# ---------------------------------------------------------------------------


class TestWarmup:
    def test_warmup_bars_respected(self):
        engine = SignalEngine(
            _BuyOnBar1(),
            fill_policy="current_close",
            warmup_bars=3,
        )
        # Bars 0-2 are warmup — strategy.on_bar should NOT be called
        signals = []
        for i in range(5):
            sig = engine.process_bar(_bar(100 + i, f"2024-01-{i+1:02d}"))
            signals.append(sig)
        # First 3 bars: NO_ACTION (warmup, strategy not called)
        for s in signals[:3]:
            assert s.type == SignalType.NO_ACTION
        # Bar 3: strategy runs but _BuyOnBar1 checks len(history)>1, which is True
        # so it tries to buy. With current_close, fill happens at close.
        assert signals[3].type == SignalType.ENTRY_LONG


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------


class TestStatus:
    def test_initial_status(self):
        engine = SignalEngine(
            _BuyOnBar1(), fill_policy="current_close", initial_cash=50_000
        )
        st = engine.status()
        assert st["symbol"] == "SYMBOL"
        assert st["bar_count"] == 0
        assert st["cash"] == 50_000
        assert st["fills_count"] == 0
        assert st["position"]["qty"] == 0
        assert st["last_bar_timestamp"] is None

    def test_status_after_entry(self):
        engine = SignalEngine(
            _BuyOnBar1(), fill_policy="current_close", initial_cash=50_000
        )
        engine.process_bar(_bar(100, "2024-01-01"))
        engine.process_bar(_bar(100, "2024-01-02"))
        st = engine.status()
        assert st["bar_count"] == 2
        assert st["position"]["qty"] == 100
        assert st["position"]["side"] == "long"
        assert st["fills_count"] == 1
        assert st["last_bar_timestamp"] is not None


# ---------------------------------------------------------------------------
# Timestamp ordering and idempotency
# ---------------------------------------------------------------------------


class TestTimestampOrdering:
    def test_out_of_order_raises(self):
        engine = SignalEngine(_BuyOnBar1(), fill_policy="current_close")
        engine.process_bar(_bar(100, "2024-01-02"))
        with pytest.raises(ValueError, match="before or equal"):
            engine.process_bar(_bar(101, "2024-01-01"))

    def test_equal_timestamp_raises_for_different_bar(self):
        """Equal timestamp to last bar is idempotent, not an error."""
        engine = SignalEngine(_BuyOnBar1(), fill_policy="current_close")
        bar1 = _bar(100, "2024-01-01")
        engine.process_bar(bar1)
        # Same timestamp → idempotent return
        signal = engine.process_bar(bar1)
        assert signal.type == SignalType.NO_ACTION

    def test_gaps_allowed(self):
        engine = SignalEngine(_BuyOnBar1(), fill_policy="current_close")
        engine.process_bar(_bar(100, "2024-01-01"))
        # Skip to Jan 10 — should be fine
        signal = engine.process_bar(_bar(102, "2024-01-10"))
        assert signal.type == SignalType.ENTRY_LONG


class TestIdempotency:
    def test_duplicate_timestamp_returns_cached(self):
        engine = SignalEngine(_BuyOnBar1(), fill_policy="current_close")
        bar = _bar(100, "2024-01-01")
        sig1 = engine.process_bar(bar)
        sig2 = engine.process_bar(bar)
        assert sig1 is sig2  # exact same object

    def test_idempotent_after_entry(self):
        engine = SignalEngine(_BuyOnBar1(), fill_policy="current_close")
        engine.process_bar(_bar(100, "2024-01-01"))
        bar2 = _bar(102, "2024-01-02")
        sig1 = engine.process_bar(bar2)
        sig2 = engine.process_bar(bar2)
        assert sig1 is sig2
        assert sig1.type == SignalType.ENTRY_LONG
        # Verify fills didn't double
        assert engine.status()["fills_count"] == 1


# ---------------------------------------------------------------------------
# Commission and slippage
# ---------------------------------------------------------------------------


class TestCommissionSlippage:
    def test_slippage_affects_fill_price(self):
        engine = SignalEngine(
            _BuyOnBar1(),
            fill_policy="current_close",
            slippage_pct=1.0,
        )
        engine.process_bar(_bar(100, "2024-01-01"))
        signal = engine.process_bar(_bar(100, "2024-01-02"))
        # Buy fills at close * (1 + 0.01) = 101.0
        assert signal.type == SignalType.ENTRY_LONG
        assert signal.price == pytest.approx(101.0)

    def test_commission_deducted(self):
        engine = SignalEngine(
            _BuyOnBar1(),
            fill_policy="current_close",
            initial_cash=100_000,
            commission_pct=0.1,
        )
        engine.process_bar(_bar(100, "2024-01-01"))
        engine.process_bar(_bar(100, "2024-01-02"))
        # Buy 100 @ 100 = 10,000. Commission = 10,000 * 0.001 = 10.
        # Cash = 100,000 - 10,000 - 10 = 89,990
        st = engine.status()
        assert st["cash"] == pytest.approx(89_990.0)


# ---------------------------------------------------------------------------
# Python Strategy subclass (not JsonStrategy)
# ---------------------------------------------------------------------------


class TestPythonStrategy:
    def test_custom_strategy(self):
        class _MACross(Strategy):
            def on_bar(self, ctx):
                close = ctx.history["close"]
                if len(close) < 3:
                    return
                fast = close.rolling(2).mean().iloc[-1]
                slow = close.rolling(3).mean().iloc[-1]
                if fast > slow and ctx.position.is_flat:
                    ctx.buy(qty=50)
                elif fast < slow and ctx.position.is_long:
                    ctx.close()

        engine = SignalEngine(_MACross(), fill_policy="current_close")
        # Feed bars with rising then falling prices
        bars = [
            _bar(100, "2024-01-01"),
            _bar(101, "2024-01-02"),
            _bar(103, "2024-01-03"),  # fast > slow → buy
            _bar(104, "2024-01-04"),
            _bar(99, "2024-01-05"),   # fast < slow → sell
        ]
        signals = [engine.process_bar(b) for b in bars]
        types = [s.type for s in signals]
        assert SignalType.ENTRY_LONG in types
        assert SignalType.EXIT_SIGNAL in types


# ---------------------------------------------------------------------------
# PARITY TEST: signal engine vs backtest()
# ---------------------------------------------------------------------------


class TestParity:
    """Prove that bar-by-bar via SignalEngine matches backtest() fills exactly.

    Uses fill_policy=current_close and a Python strategy (no stops) so the
    execution ordering difference (on_bar_close timing) doesn't affect results.
    """

    def test_parity_200_bars(self, synthetic_ohlcv):
        """200 bars through backtest vs bar-by-bar through SignalEngine.
        Fills must match in count, side, qty, and price.
        """

        class _SmaCross(Strategy):
            def on_bar(self, ctx):
                close = ctx.history["close"]
                if len(close) < 10:
                    return
                fast = close.rolling(5).mean().iloc[-1]
                slow = close.rolling(10).mean().iloc[-1]
                if fast > slow and ctx.position.is_flat:
                    ctx.buy(qty=100)
                elif fast < slow and ctx.position.is_long:
                    ctx.close()

        # --- Backtest ---
        bt_result = backtest(
            _SmaCross(),
            synthetic_ohlcv,
            fill_policy="current_close",
            initial_cash=100_000,
            commission_pct=0.1,
            slippage_pct=0.05,
        )
        bt_fills = bt_result.fills

        # --- Signal engine bar-by-bar ---
        engine = SignalEngine(
            _SmaCross(),
            fill_policy="current_close",
            initial_cash=100_000,
            commission_pct=0.1,
            slippage_pct=0.05,
        )
        for ts, row in synthetic_ohlcv.iterrows():
            bar = Bar(
                timestamp=ts,
                symbol="SYMBOL",
                open=float(row["open"]),
                high=float(row["high"]),
                low=float(row["low"]),
                close=float(row["close"]),
                volume=float(row["volume"]),
            )
            engine.process_bar(bar)

        se_fills = engine._broker.fills()

        # Fills must match
        assert len(se_fills) == len(bt_fills), (
            f"Fill count mismatch: signal_engine={len(se_fills)}, "
            f"backtest={len(bt_fills)}"
        )
        for i, (se_f, bt_f) in enumerate(zip(se_fills, bt_fills)):
            assert se_f.side == bt_f.side, f"Fill {i} side mismatch"
            assert se_f.qty == bt_f.qty, f"Fill {i} qty mismatch"
            assert se_f.price == pytest.approx(bt_f.price, rel=1e-9), (
                f"Fill {i} price mismatch: signal={se_f.price}, bt={bt_f.price}"
            )
            assert se_f.timestamp == bt_f.timestamp, f"Fill {i} ts mismatch"

    def test_parity_with_warmup(self, synthetic_ohlcv):
        """Parity with warmup_bars set."""

        class _BuyAfterWarmup(Strategy):
            def on_bar(self, ctx):
                if ctx.position.is_flat and len(ctx.history) > 20:
                    ctx.buy(qty=50)

        bt_result = backtest(
            _BuyAfterWarmup(),
            synthetic_ohlcv,
            fill_policy="current_close",
            initial_cash=100_000,
            warmup_bars=15,
        )
        bt_fills = bt_result.fills

        engine = SignalEngine(
            _BuyAfterWarmup(),
            fill_policy="current_close",
            initial_cash=100_000,
            warmup_bars=15,
        )
        for ts, row in synthetic_ohlcv.iterrows():
            bar = Bar(
                timestamp=ts,
                symbol="SYMBOL",
                open=float(row["open"]),
                high=float(row["high"]),
                low=float(row["low"]),
                close=float(row["close"]),
                volume=float(row["volume"]),
            )
            engine.process_bar(bar)

        se_fills = engine._broker.fills()
        assert len(se_fills) == len(bt_fills)
        for i, (se_f, bt_f) in enumerate(zip(se_fills, bt_fills)):
            assert se_f.side == bt_f.side
            assert se_f.qty == bt_f.qty
            assert se_f.price == pytest.approx(bt_f.price, rel=1e-9)
