"""Tests for fastbt.result.Metrics — focused on v0.3.0 additions:
CAGR, Sortino, annual_volatility, risk_free_rate parameter.
"""

from __future__ import annotations

import math

import numpy as np
import pandas as pd
import pytest

from fastbt.result import Metrics


def _equity(values: list[float]) -> pd.Series:
    """Helper — build an equity curve indexed by business days."""
    dates = pd.bdate_range("2024-01-01", periods=len(values))
    return pd.Series(values, index=dates, name="equity")


# ---------------------------------------------------------------------------
# REGRESSION: defaults preserve existing behavior
# ---------------------------------------------------------------------------


class TestRegression:
    def test_default_construction_works_with_8_args(self) -> None:
        # Old code path — must keep working after we added 3 new fields
        m = Metrics(0, 0, 0, 0, 0, 0, 0, 0)
        assert m.cagr == 0.0
        assert m.sortino == 0.0
        assert m.annual_volatility == 0.0

    def test_risk_free_rate_zero_matches_old_sharpe(self) -> None:
        # Sharpe with risk_free_rate=0 must equal the pre-v0.3.0 calculation
        # (returns.mean() / returns.std()) * sqrt(252)
        rng = np.random.default_rng(1)
        returns = rng.normal(0.001, 0.01, 252)
        equity_values = 100_000 * np.exp(np.cumsum(returns))
        equity = _equity(list(equity_values))

        m = Metrics.from_equity_curve(equity, 100_000.0, [], risk_free_rate=0.0)

        rets = equity.pct_change().dropna()
        expected_sharpe = float(
            (rets.mean() / rets.std()) * np.sqrt(252)
        )
        assert m.sharpe == pytest.approx(round(expected_sharpe, 2))


# ---------------------------------------------------------------------------
# CAGR
# ---------------------------------------------------------------------------


class TestCAGR:
    def test_one_year_ten_percent(self) -> None:
        # 252 bdays, 10% total return → CAGR ≈ 10%
        equity = _equity([100_000.0, *[100_000 * (1.10 ** (i / 251))
                                       for i in range(1, 252)]])
        m = Metrics.from_equity_curve(equity, 100_000.0, [])
        assert m.cagr == pytest.approx(10.0, abs=0.5)

    def test_two_year_compounded(self) -> None:
        # 504 bdays, ending at 1.21 → CAGR should be ~10%
        equity = _equity([100_000 * (1.10 ** (i / 251)) for i in range(504)])
        m = Metrics.from_equity_curve(equity, 100_000.0, [])
        assert m.cagr == pytest.approx(10.0, abs=0.5)

    def test_negative_return(self) -> None:
        # Loss of 20% over 252 bars
        equity = _equity([100_000 * (0.80 ** (i / 251)) for i in range(252)])
        m = Metrics.from_equity_curve(equity, 100_000.0, [])
        assert m.cagr < 0
        assert not math.isnan(m.cagr)

    def test_total_loss_returns_negative_100(self) -> None:
        equity = _equity([100_000.0, 50_000.0, 0.01])
        m = Metrics.from_equity_curve(equity, 100_000.0, [])
        # Final near 0 → growth ratio near 0 → CAGR very negative.
        # We don't pin the exact value; just verify it's strongly negative.
        assert m.cagr < -50.0

    def test_zero_initial_cash(self) -> None:
        equity = _equity([0.0, 0.0, 0.0])
        m = Metrics.from_equity_curve(equity, 0.0, [])
        assert m.cagr == 0.0


# ---------------------------------------------------------------------------
# Sortino
# ---------------------------------------------------------------------------


class TestSortino:
    def test_all_positive_returns_returns_999(self) -> None:
        # Strictly increasing equity → no downside → 999.99
        equity = _equity([100_000 + i * 100 for i in range(50)])
        m = Metrics.from_equity_curve(equity, 100_000.0, [])
        assert m.sortino == 999.99

    def test_zero_excess_zero_downside_returns_zero(self) -> None:
        # Flat equity → returns are all 0 → sortino = 0
        equity = _equity([100_000.0] * 50)
        m = Metrics.from_equity_curve(equity, 100_000.0, [])
        assert m.sortino == 0.0

    def test_mixed_returns_positive_excess(self) -> None:
        rng = np.random.default_rng(7)
        returns = rng.normal(0.002, 0.01, 200)  # positive drift
        equity_values = 100_000 * np.exp(np.cumsum(returns))
        equity = _equity(list(equity_values))
        m = Metrics.from_equity_curve(equity, 100_000.0, [])
        # Positive excess and real downside → sortino is finite and positive
        assert 0 < m.sortino < 999.99

    def test_negative_drift_negative_sortino(self) -> None:
        rng = np.random.default_rng(13)
        returns = rng.normal(-0.002, 0.01, 200)  # negative drift
        equity_values = 100_000 * np.exp(np.cumsum(returns))
        equity = _equity(list(equity_values))
        m = Metrics.from_equity_curve(equity, 100_000.0, [])
        assert m.sortino < 0

    def test_risk_free_rate_lowers_sortino(self) -> None:
        # Same equity curve, higher rf → lower sortino
        rng = np.random.default_rng(21)
        returns = rng.normal(0.001, 0.01, 252)
        equity = _equity(list(100_000 * np.exp(np.cumsum(returns))))
        m_zero = Metrics.from_equity_curve(equity, 100_000.0, [],
                                          risk_free_rate=0.0)
        m_high = Metrics.from_equity_curve(equity, 100_000.0, [],
                                          risk_free_rate=10.0)
        assert m_high.sortino < m_zero.sortino


# ---------------------------------------------------------------------------
# annual_volatility
# ---------------------------------------------------------------------------


class TestAnnualVolatility:
    def test_known_daily_std(self) -> None:
        # Construct returns with std ~= 0.01, then ann_vol ~= 0.01 * sqrt(252) * 100
        rng = np.random.default_rng(5)
        returns = rng.normal(0.0, 0.01, 252)
        equity = _equity(list(100_000 * np.exp(np.cumsum(returns))))
        m = Metrics.from_equity_curve(equity, 100_000.0, [])
        # Expected ~15.87, allow tolerance for sample noise
        assert m.annual_volatility == pytest.approx(15.87, abs=2.0)

    def test_flat_equity_zero_vol(self) -> None:
        equity = _equity([100_000.0] * 50)
        m = Metrics.from_equity_curve(equity, 100_000.0, [])
        assert m.annual_volatility == 0.0


# ---------------------------------------------------------------------------
# risk_free_rate parameter
# ---------------------------------------------------------------------------


class TestRiskFreeRate:
    def test_high_rf_lowers_sharpe(self) -> None:
        rng = np.random.default_rng(11)
        returns = rng.normal(0.001, 0.01, 252)
        equity = _equity(list(100_000 * np.exp(np.cumsum(returns))))

        m_zero = Metrics.from_equity_curve(equity, 100_000.0, [],
                                          risk_free_rate=0.0)
        m_six = Metrics.from_equity_curve(equity, 100_000.0, [],
                                         risk_free_rate=6.0)
        assert m_six.sharpe < m_zero.sharpe

    def test_rf_default_is_zero(self) -> None:
        rng = np.random.default_rng(11)
        returns = rng.normal(0.001, 0.01, 252)
        equity = _equity(list(100_000 * np.exp(np.cumsum(returns))))

        m_default = Metrics.from_equity_curve(equity, 100_000.0, [])
        m_explicit_zero = Metrics.from_equity_curve(
            equity, 100_000.0, [], risk_free_rate=0.0,
        )
        assert m_default.sharpe == m_explicit_zero.sharpe
        assert m_default.sortino == m_explicit_zero.sortino
