"""Tests for JsonPortfolioStrategy — lifecycle dispatch + JSON↔Python parity tests.

The 4 parity tests at the bottom (D8 — IRON RULE) prove the JSON layer produces
numerically identical equity curves and metrics as the Python `MomentumTopN`
example for each allocator. ``rtol=1e-10`` is the determinism contract — see
TODOS.md "Determinism contract for JSON↔Python parity tests".
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from fastbt import (
    PortfolioStrategy,
    RebalanceSchedule,
    portfolio_backtest,
)
from fastbt.allocators import (
    annualized_volatility,
    equal_weight,
    inverse_volatility,
    momentum_score,
    momentum_weighted,
    risk_parity,
)
from fastbt.indicators import roc
from fastbt.json_portfolio_strategy import (
    JsonPortfolioStrategy,
    _compute_metric_value,
    schedule_from_spec,
)
from fastbt.portfolio_schema import PortfolioStrategySpec


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _synthetic_etf(
    n_bars: int,
    drift: float,
    vol: float,
    start_price: float,
    seed: int,
) -> pd.DataFrame:
    """Identical to examples/momentum_portfolio.py — same generator means the
    parity tests can produce bit-identical inputs to both runs."""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2022-01-01", periods=n_bars)
    returns = rng.normal(loc=drift, scale=vol, size=n_bars)
    close = start_price * np.exp(np.cumsum(returns))
    open_ = close * (1 + rng.normal(0, 0.003, n_bars))
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, 0.003, n_bars)))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, 0.003, n_bars)))
    volume = rng.integers(50_000, 500_000, n_bars).astype(float)
    return pd.DataFrame(
        {"open": open_, "high": high, "low": low, "close": close, "volume": volume},
        index=dates,
    )


def _make_universe(n_bars: int = 800) -> dict[str, pd.DataFrame]:
    return {
        "EQUITY": _synthetic_etf(n_bars, 0.0008, 0.012, 100.0, seed=1),
        "BONDS": _synthetic_etf(n_bars, 0.0002, 0.004, 100.0, seed=2),
        "GOLD": _synthetic_etf(n_bars, 0.0004, 0.010, 100.0, seed=3),
        "SMALL": _synthetic_etf(n_bars, 0.0010, 0.020, 100.0, seed=4),
        "INTL": _synthetic_etf(n_bars, 0.0005, 0.013, 100.0, seed=5),
    }


def _full_spec(allocate_method: str, **alloc_kwargs) -> dict:
    """Spec mirroring momentum_portfolio.py with parameterized allocator."""
    allocate: dict = {"method": allocate_method}
    allocate.update(alloc_kwargs)
    return {
        "kind": "portfolio",
        "version": "0.4.0",
        "universe": {"min_history": 90},
        "rank": {
            "score": "weighted_metrics",
            "metrics": [
                {"indicator": "roc", "params": {"period": 30}, "output": "value", "weight": 0.25},
                {"indicator": "roc", "params": {"period": 90}, "output": "value", "weight": 0.35},
                {"indicator": "roc", "params": {"period": 180}, "output": "value", "weight": 0.25},
                {"indicator": "roc", "params": {"period": 360}, "output": "value", "weight": 0.15},
            ],
        },
        "select": {"top_n": 3, "direction": "desc"},
        "allocate": allocate,
        "schedule": {"type": "monthly", "day": 1},
        "stops": {
            "vol_trailing_multiplier": 2.0,
            "vol_trailing_lookback": 60,
            "vol_trailing_fallback_pct": 10.0,
        },
        "min_drift_pct": 2.0,
        "initial_cash": 1_000_000,
        "commission_pct": 0.05,
        "slippage_pct": 0.02,
        "risk_free_rate": 6.0,
    }


# Python equivalent of the JSON spec — used by parity tests.
class _PythonMomentumTopN(PortfolioStrategy):
    """Mirror of examples/momentum_portfolio.py:MomentumTopN."""

    WEIGHTS = {"r30d": 0.25, "r90d": 0.35, "r180d": 0.25, "r360d": 0.15}

    def __init__(self, allocator_name: str, vol_lookback: int = 60, top_n: int = 3):
        super().__init__()
        self.allocator_name = allocator_name
        self.vol_lookback = vol_lookback
        self.top_n = top_n

    def universe(self, ctx):
        return [s for s in ctx.symbols if len(ctx.history[s]) >= 90]

    def rank(self, ctx, universe):
        scored = []
        for sym in universe:
            close = ctx.history[sym]["close"]
            metrics = {
                "r30d": float(roc(close, 30).iloc[-1]) if len(close) > 30 else None,
                "r90d": float(roc(close, 90).iloc[-1]) if len(close) > 90 else None,
                "r180d": float(roc(close, 180).iloc[-1]) if len(close) > 180 else None,
                "r360d": float(roc(close, 360).iloc[-1]) if len(close) > 360 else None,
            }
            scored.append((sym, momentum_score(metrics, self.WEIGHTS)))
        return sorted(scored, key=lambda x: x[1], reverse=True)

    def select(self, ctx, ranked):
        return [sym for sym, _ in ranked[: self.top_n]]

    def allocate(self, ctx, selected):
        if self.allocator_name == "equal_weight":
            return equal_weight(selected)
        if self.allocator_name == "momentum_weighted":
            scores = dict(self.rank(ctx, selected))
            return momentum_weighted(selected, scores)
        if self.allocator_name == "inverse_volatility":
            vols = {
                s: annualized_volatility(ctx.history[s]["close"], self.vol_lookback)
                for s in selected
            }
            return inverse_volatility(selected, vols)
        if self.allocator_name == "risk_parity":
            vols = {
                s: annualized_volatility(ctx.history[s]["close"], self.vol_lookback)
                for s in selected
            }
            return risk_parity(selected, vols)
        raise ValueError(self.allocator_name)


# ---------------------------------------------------------------------------
# 1. Lifecycle dispatch — universe filter
# ---------------------------------------------------------------------------


class TestUniverseFilter:
    def test_min_history_excludes_short_symbols(self):
        spec = PortfolioStrategySpec.model_validate(
            {
                "kind": "portfolio",
                "version": "0.4.0",
                "universe": {"min_history": 100},
                "allocate": {"method": "equal_weight"},
            }
        )
        strategy = JsonPortfolioStrategy(spec)

        class FakeCtx:
            symbols = ["A", "B"]
            history = {
                "A": pd.DataFrame({"close": range(50)}),
                "B": pd.DataFrame({"close": range(150)}),
            }

        assert strategy.universe(FakeCtx()) == ["B"]

    def test_max_symbols_truncates(self):
        spec = PortfolioStrategySpec.model_validate(
            {
                "kind": "portfolio",
                "version": "0.4.0",
                "universe": {"max_symbols": 2},
                "allocate": {"method": "equal_weight"},
            }
        )
        strategy = JsonPortfolioStrategy(spec)

        class FakeCtx:
            symbols = ["A", "B", "C", "D"]
            history = {s: pd.DataFrame({"close": [1, 2, 3]}) for s in symbols}

        assert strategy.universe(FakeCtx()) == ["A", "B"]

    def test_min_avg_volume_excludes_low_volume(self):
        spec = PortfolioStrategySpec.model_validate(
            {
                "kind": "portfolio",
                "version": "0.4.0",
                "universe": {"min_avg_volume": 1000.0},
                "allocate": {"method": "equal_weight"},
            }
        )
        strategy = JsonPortfolioStrategy(spec)

        class FakeCtx:
            symbols = ["A", "B"]
            history = {
                "A": pd.DataFrame({"close": [1.0, 2.0], "volume": [100.0, 100.0]}),
                "B": pd.DataFrame({"close": [1.0, 2.0], "volume": [5000.0, 5000.0]}),
            }

        assert strategy.universe(FakeCtx()) == ["B"]

    def test_no_filters_returns_all(self):
        spec = PortfolioStrategySpec.model_validate(
            {
                "kind": "portfolio",
                "version": "0.4.0",
                "allocate": {"method": "equal_weight"},
            }
        )
        strategy = JsonPortfolioStrategy(spec)

        class FakeCtx:
            symbols = ["A", "B"]
            history = {s: pd.DataFrame({"close": [1, 2]}) for s in symbols}

        assert strategy.universe(FakeCtx()) == ["A", "B"]


# ---------------------------------------------------------------------------
# 2. Lifecycle dispatch — select
# ---------------------------------------------------------------------------


class TestSelect:
    def _strategy(self, **select_kwargs):
        spec = PortfolioStrategySpec.model_validate(
            {
                "kind": "portfolio",
                "version": "0.4.0",
                "rank": {
                    "score": "weighted_metrics",
                    "metrics": [
                        {"indicator": "roc", "params": {"period": 30}, "output": "value", "weight": 1.0}
                    ],
                },
                "select": select_kwargs,
                "allocate": {"method": "equal_weight"},
            }
        )
        return JsonPortfolioStrategy(spec)

    def test_top_n_desc(self):
        strategy = self._strategy(top_n=2, direction="desc")
        ranked = [("A", 5.0), ("B", 3.0), ("C", 1.0)]
        assert strategy.select(None, ranked) == ["A", "B"]

    def test_top_n_asc(self):
        strategy = self._strategy(top_n=2, direction="asc")
        ranked = [("A", 5.0), ("B", 3.0), ("C", 1.0)]
        # asc reverses the input — pick lowest 2
        assert strategy.select(None, ranked) == ["C", "B"]

    def test_no_top_n_returns_all(self):
        strategy = self._strategy()
        ranked = [("A", 5.0), ("B", 3.0)]
        assert strategy.select(None, ranked) == ["A", "B"]


# ---------------------------------------------------------------------------
# 3. Lifecycle dispatch — allocate
# ---------------------------------------------------------------------------


class TestAllocate:
    def _strategy(self, allocate: dict):
        spec = PortfolioStrategySpec.model_validate(
            {
                "kind": "portfolio",
                "version": "0.4.0",
                "allocate": allocate,
            }
        )
        return JsonPortfolioStrategy(spec)

    def test_equal_weight(self):
        strategy = self._strategy({"method": "equal_weight"})
        out = strategy.allocate(None, ["A", "B", "C"])
        assert all(abs(v - 1 / 3) < 1e-12 for v in out.values())

    def test_inverse_volatility(self):
        strategy = self._strategy(
            {"method": "inverse_volatility", "vol_lookback": 30}
        )

        class FakeCtx:
            history = {
                "A": pd.DataFrame({"close": np.linspace(100, 110, 100)}),
                "B": pd.DataFrame({"close": np.linspace(100, 130, 100)}),
            }

        weights = strategy.allocate(FakeCtx(), ["A", "B"])
        # Weights should sum to ~1 and the lower-vol symbol gets more
        assert abs(sum(weights.values()) - 1.0) < 1e-12

    def test_empty_selected_returns_empty(self):
        strategy = self._strategy({"method": "equal_weight"})
        assert strategy.allocate(None, []) == {}


# ---------------------------------------------------------------------------
# 4. stop_config forwarding
# ---------------------------------------------------------------------------


class TestPortfolioStopConfig:
    def test_no_stops_returns_none(self):
        spec = PortfolioStrategySpec.model_validate(
            {
                "kind": "portfolio",
                "version": "0.4.0",
                "allocate": {"method": "equal_weight"},
            }
        )
        assert JsonPortfolioStrategy(spec).stop_config() is None

    def test_vol_trailing_forwarded(self):
        spec = PortfolioStrategySpec.model_validate(
            {
                "kind": "portfolio",
                "version": "0.4.0",
                "allocate": {"method": "equal_weight"},
                "stops": {
                    "vol_trailing_multiplier": 2.0,
                    "vol_trailing_fallback_pct": 10.0,
                },
            }
        )
        cfg = JsonPortfolioStrategy(spec).stop_config()
        assert cfg["vol_trailing_multiplier"] == 2.0
        assert cfg["vol_trailing_fallback_pct"] == 10.0


# ---------------------------------------------------------------------------
# 5. schedule_from_spec
# ---------------------------------------------------------------------------


class TestScheduleFromSpec:
    def test_every_bar(self):
        spec = PortfolioStrategySpec.model_validate(
            {
                "kind": "portfolio",
                "version": "0.4.0",
                "allocate": {"method": "equal_weight"},
                "schedule": {"type": "every_bar"},
            }
        )
        sched = schedule_from_spec(spec)
        assert isinstance(sched, RebalanceSchedule)

    def test_monthly_day_n(self):
        spec = PortfolioStrategySpec.model_validate(
            {
                "kind": "portfolio",
                "version": "0.4.0",
                "allocate": {"method": "equal_weight"},
                "schedule": {"type": "monthly", "day": 15},
            }
        )
        sched = schedule_from_spec(spec)
        assert "monthly" in repr(sched)


# ---------------------------------------------------------------------------
# 6. PARITY TESTS (D8 — IRON RULE)
# ---------------------------------------------------------------------------
#
# Each allocator gets a JSON↔Python parity test. The JSON-driven backtest must
# produce IDENTICAL equity curves and metrics (rtol=1e-10) as the Python
# equivalent. This is the strongest correctness guarantee the JSON layer can
# offer — every other test in this module is a microtest that supports these.
# ---------------------------------------------------------------------------


def _run_json(allocator: str, **alloc_kwargs):
    data = _make_universe(800)
    spec_dict = _full_spec(allocator, **alloc_kwargs)
    spec = PortfolioStrategySpec.model_validate(spec_dict)
    strategy = JsonPortfolioStrategy(spec)
    schedule = schedule_from_spec(spec)
    return portfolio_backtest(
        strategy,
        data,
        initial_cash=spec.initial_cash,
        commission_pct=spec.commission_pct,
        slippage_pct=spec.slippage_pct,
        schedule=schedule,
        min_drift_pct=spec.min_drift_pct,
        risk_free_rate=spec.risk_free_rate,
    )


def _run_python(allocator: str, vol_lookback: int = 60):
    data = _make_universe(800)
    strategy = _PythonMomentumTopN(allocator, vol_lookback=vol_lookback, top_n=3)
    return portfolio_backtest(
        strategy,
        data,
        initial_cash=1_000_000,
        commission_pct=0.05,
        slippage_pct=0.02,
        schedule=RebalanceSchedule.monthly(day=1),
        min_drift_pct=2.0,
        vol_trailing_multiplier=2.0,
        vol_trailing_lookback=60,
        vol_trailing_fallback_pct=10.0,
        risk_free_rate=6.0,
    )


def _assert_parity(json_result, py_result):
    pd.testing.assert_series_equal(
        json_result.equity_curve,
        py_result.equity_curve,
        check_exact=False,
        rtol=1e-10,
    )
    j_m = json_result.metrics
    p_m = py_result.metrics
    assert j_m.cagr == pytest.approx(p_m.cagr, rel=1e-10)
    assert j_m.sharpe == pytest.approx(p_m.sharpe, rel=1e-10)
    assert j_m.sortino == pytest.approx(p_m.sortino, rel=1e-10)
    assert j_m.max_drawdown_pct == pytest.approx(p_m.max_drawdown_pct, rel=1e-10)
    assert j_m.num_trades == p_m.num_trades


def test_parity_equal_weight():
    json_result = _run_json("equal_weight")
    py_result = _run_python("equal_weight")
    _assert_parity(json_result, py_result)


def test_parity_momentum_weighted():
    json_result = _run_json("momentum_weighted")
    py_result = _run_python("momentum_weighted")
    _assert_parity(json_result, py_result)


def test_parity_inverse_volatility():
    json_result = _run_json("inverse_volatility", vol_lookback=60)
    py_result = _run_python("inverse_volatility", vol_lookback=60)
    _assert_parity(json_result, py_result)


def test_parity_risk_parity():
    json_result = _run_json("risk_parity", vol_lookback=60)
    py_result = _run_python("risk_parity", vol_lookback=60)
    _assert_parity(json_result, py_result)


# ---------------------------------------------------------------------------
# 7. _compute_metric_value direct tests (lower-level)
# ---------------------------------------------------------------------------


def test_compute_metric_value_roc():
    from fastbt.portfolio_schema import WeightedIndicatorRef as W

    hist = pd.DataFrame(
        {
            "open": np.linspace(100, 110, 50),
            "high": np.linspace(101, 111, 50),
            "low": np.linspace(99, 109, 50),
            "close": np.linspace(100, 110, 50),
            "volume": [1000.0] * 50,
        }
    )
    ref = W.model_validate(
        {"indicator": "roc", "params": {"period": 30}, "output": "value", "weight": 1.0}
    )
    val = _compute_metric_value(ref, hist)
    # Computed via the same indicator function — exact match expected
    expected = float(roc(hist["close"], 30).iloc[-1])
    assert val == pytest.approx(expected, rel=1e-12)


def test_compute_metric_value_returns_none_on_short_history():
    from fastbt.portfolio_schema import WeightedIndicatorRef as W

    hist = pd.DataFrame(
        {
            "open": [100.0] * 5,
            "high": [101.0] * 5,
            "low": [99.0] * 5,
            "close": [100.0, 101.0, 102.0, 103.0, 104.0],
            "volume": [1000.0] * 5,
        }
    )
    ref = W.model_validate(
        {"indicator": "roc", "params": {"period": 30}, "output": "value", "weight": 1.0}
    )
    # roc returns NaN for the first `period` values — should produce None here
    val = _compute_metric_value(ref, hist)
    assert val is None
