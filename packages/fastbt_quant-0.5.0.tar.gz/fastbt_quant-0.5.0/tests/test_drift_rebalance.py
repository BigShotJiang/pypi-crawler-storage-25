"""Tests for drift-aware rebalancing in _rebalance_to_weights (v0.3.0)."""

from __future__ import annotations

import pandas as pd
import pytest

from fastbt.broker import PaperBroker
from fastbt.engine import _rebalance_to_weights, portfolio_backtest
from fastbt.portfolio_strategy import PortfolioStrategy
from fastbt.types import OrderSide


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ohlcv(closes: list[float]) -> pd.DataFrame:
    dates = pd.bdate_range("2024-01-01", periods=len(closes))
    return pd.DataFrame(
        {
            "open": closes,
            "high": [c * 1.005 for c in closes],
            "low": [c * 0.995 for c in closes],
            "close": closes,
            "volume": [10_000] * len(closes),
        },
        index=dates,
    )


class _FixedTargets(PortfolioStrategy):
    """Returns fixed target weights every rebalance."""

    def __init__(self, weights: dict[str, float]):
        super().__init__()
        self._weights = dict(weights)

    def on_rebalance(self, ctx):
        return self._weights


# ---------------------------------------------------------------------------
# Direct unit tests on _rebalance_to_weights
# ---------------------------------------------------------------------------


class TestRebalanceUnit:
    def _broker(self) -> PaperBroker:
        return PaperBroker(initial_cash=100_000)

    def test_empty_portfolio_all_buys(self):
        broker = self._broker()
        _rebalance_to_weights(
            broker,
            target_weights={"A": 0.5, "B": 0.5},
            marks={"A": 100.0, "B": 200.0},
            equity=100_000.0,
            ts=pd.Timestamp("2024-01-01"),
        )
        # Two buys submitted, no sells
        pending = broker._pending
        assert len(pending) == 2
        assert all(o.side == OrderSide.BUY for o in pending)

    def test_no_drift_no_trades_with_threshold(self):
        # Pre-load the broker with positions matching targets
        broker = self._broker()
        # Manually buy 500 of A at 100 = 50_000 = 50% of equity
        broker.submit_market("A", OrderSide.BUY, 500, pd.Timestamp("2024-01-01"))
        broker._fill_at_price(broker._pending[0], 100.0, pd.Timestamp("2024-01-01"))
        broker._pending.clear()
        broker.submit_market("B", OrderSide.BUY, 250, pd.Timestamp("2024-01-01"))
        broker._fill_at_price(broker._pending[0], 200.0, pd.Timestamp("2024-01-01"))
        broker._pending.clear()

        _rebalance_to_weights(
            broker,
            target_weights={"A": 0.5, "B": 0.5},
            marks={"A": 100.0, "B": 200.0},
            equity=100_000.0,
            ts=pd.Timestamp("2024-01-02"),
            min_drift_pct=2.0,
        )
        # Already at target, drift < 2%, no trades
        assert len(broker._pending) == 0

    def test_full_exit_always_trades_even_under_threshold(self):
        # Position in A, target weight 0 → must sell regardless of threshold
        broker = self._broker()
        broker.submit_market("A", OrderSide.BUY, 100, pd.Timestamp("2024-01-01"))
        broker._fill_at_price(broker._pending[0], 100.0, pd.Timestamp("2024-01-01"))
        broker._pending.clear()

        _rebalance_to_weights(
            broker,
            target_weights={},  # full exit
            marks={"A": 100.0},
            equity=100_000.0,
            ts=pd.Timestamp("2024-01-02"),
            min_drift_pct=99.0,  # absurdly high — would block normal drift
        )
        # Full exit always executes
        assert len(broker._pending) == 1
        assert broker._pending[0].side == OrderSide.SELL

    def test_new_entry_always_trades_even_under_threshold(self):
        broker = self._broker()
        # Tiny target — would be < threshold normally
        _rebalance_to_weights(
            broker,
            target_weights={"A": 0.01},
            marks={"A": 100.0},
            equity=100_000.0,
            ts=pd.Timestamp("2024-01-01"),
            min_drift_pct=10.0,  # 1% target, 0% current → 1% drift, < 10% threshold
        )
        # New entry always executes
        assert len(broker._pending) == 1
        assert broker._pending[0].side == OrderSide.BUY

    def test_sells_submitted_before_buys(self):
        broker = self._broker()
        # Hold A, want to drop to 0 and pick up B
        broker.submit_market("A", OrderSide.BUY, 500, pd.Timestamp("2024-01-01"))
        broker._fill_at_price(broker._pending[0], 100.0, pd.Timestamp("2024-01-01"))
        broker._pending.clear()

        _rebalance_to_weights(
            broker,
            target_weights={"B": 0.5},  # exit A, enter B
            marks={"A": 100.0, "B": 200.0},
            equity=100_000.0,
            ts=pd.Timestamp("2024-01-02"),
        )
        # First order should be the SELL of A
        assert broker._pending[0].symbol == "A"
        assert broker._pending[0].side == OrderSide.SELL
        # Then the BUY of B
        assert broker._pending[1].symbol == "B"
        assert broker._pending[1].side == OrderSide.BUY

    def test_drift_above_threshold_trades(self):
        # Hold A at 50% but target 60% — drift = 10%, threshold = 5% → trade
        broker = self._broker()
        broker.submit_market("A", OrderSide.BUY, 500, pd.Timestamp("2024-01-01"))
        broker._fill_at_price(broker._pending[0], 100.0, pd.Timestamp("2024-01-01"))
        broker._pending.clear()

        _rebalance_to_weights(
            broker,
            target_weights={"A": 0.60},
            marks={"A": 100.0},
            equity=100_000.0,
            ts=pd.Timestamp("2024-01-02"),
            min_drift_pct=5.0,
        )
        assert len(broker._pending) == 1
        assert broker._pending[0].side == OrderSide.BUY


# ---------------------------------------------------------------------------
# REGRESSION: min_drift_pct=0 produces identical trades to today
# ---------------------------------------------------------------------------


class TestRegression:
    def test_default_min_drift_pct_is_zero(self):
        # Same scenario, with min_drift_pct=0 (default) and explicit 0
        # should produce identical trades
        scenarios = []
        for explicit_zero in (False, True):
            broker = PaperBroker(initial_cash=100_000)
            broker.submit_market("A", OrderSide.BUY, 500, pd.Timestamp("2024-01-01"))
            broker._fill_at_price(broker._pending[0], 100.0, pd.Timestamp("2024-01-01"))
            broker._pending.clear()
            kwargs = {"min_drift_pct": 0.0} if explicit_zero else {}
            _rebalance_to_weights(
                broker,
                target_weights={"A": 0.501},  # 0.1% drift — would be skipped at 1%
                marks={"A": 100.0},
                equity=100_000.0,
                ts=pd.Timestamp("2024-01-02"),
                **kwargs,
            )
            scenarios.append([(o.symbol, o.side, o.qty) for o in broker._pending])
        assert scenarios[0] == scenarios[1]

    def test_min_drift_zero_trades_every_delta(self):
        # Even a 1-share delta should produce a trade with min_drift_pct=0
        broker = PaperBroker(initial_cash=100_000)
        broker.submit_market("A", OrderSide.BUY, 500, pd.Timestamp("2024-01-01"))
        broker._fill_at_price(broker._pending[0], 100.0, pd.Timestamp("2024-01-01"))
        broker._pending.clear()

        _rebalance_to_weights(
            broker,
            target_weights={"A": 0.501},  # 1 extra share at $100
            marks={"A": 100.0},
            equity=100_000.0,
            ts=pd.Timestamp("2024-01-02"),
            min_drift_pct=0.0,
        )
        assert len(broker._pending) == 1


# ---------------------------------------------------------------------------
# Integration: portfolio_backtest with min_drift_pct
# ---------------------------------------------------------------------------


class TestPortfolioIntegration:
    def test_drift_threshold_reduces_trades(self):
        # Use prices that drift slightly each bar; with min_drift_pct=0,
        # every bar trades; with min_drift_pct=5.0, most rebalances skip.
        prices = [100.0 + i * 0.1 for i in range(50)]  # tiny drift
        data = {
            "A": _ohlcv(prices),
            "B": _ohlcv(prices),
        }

        result_noisy = portfolio_backtest(
            _FixedTargets({"A": 0.5, "B": 0.5}),
            data,
            fill_policy="current_close",
            initial_cash=100_000,
            min_drift_pct=0.0,
        )
        result_quiet = portfolio_backtest(
            _FixedTargets({"A": 0.5, "B": 0.5}),
            data,
            fill_policy="current_close",
            initial_cash=100_000,
            min_drift_pct=5.0,
        )
        # Threshold reduces fill count
        assert len(result_quiet.fills) <= len(result_noisy.fills)

    def test_drift_threshold_preserves_correctness(self):
        # Equity should still track targets within the threshold
        prices = [100.0] * 30
        data = {
            "A": _ohlcv(prices),
            "B": _ohlcv(prices),
        }
        result = portfolio_backtest(
            _FixedTargets({"A": 0.5, "B": 0.5}),
            data,
            fill_policy="current_close",
            initial_cash=100_000,
            min_drift_pct=2.0,
        )
        # Ending weights should be close to 50/50
        last = result.weight_history.iloc[-1]
        assert last["A"] == pytest.approx(0.5, abs=0.05)
        assert last["B"] == pytest.approx(0.5, abs=0.05)
