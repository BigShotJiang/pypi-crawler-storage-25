"""Tests for stop-loss, take-profit, and trailing stop engine primitives."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from fastbt import Strategy, backtest
from fastbt.engine import StopOutEvent, StopResult, StopTracker
from fastbt.types import Bar, Position


def _bar(
    open_: float,
    high: float,
    low: float,
    close: float,
    ts: str = "2023-01-01",
    symbol: str = "X",
) -> Bar:
    return Bar(
        timestamp=pd.Timestamp(ts),
        symbol=symbol,
        open=open_,
        high=high,
        low=low,
        close=close,
        volume=1000.0,
    )


# ---------------------------------------------------------------------------
# StopTracker unit tests
# ---------------------------------------------------------------------------


class TestStopLoss:
    def test_long_sl_triggers_on_bar_low(self):
        tracker = StopTracker(stop_loss_pct=5.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)
        # SL at 95.0 (5% below 100). Bar low = 94 → triggers
        bar = _bar(open_=99.0, high=101.0, low=94.0, close=98.0)
        result = tracker.check("X", bar, pos)
        assert result is not None
        assert result.price == pytest.approx(95.0)
        assert result.kind == "sl"

    def test_long_sl_no_trigger(self):
        tracker = StopTracker(stop_loss_pct=5.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)
        # Bar low = 96 → above SL at 95
        bar = _bar(open_=99.0, high=101.0, low=96.0, close=98.0)
        result = tracker.check("X", bar, pos)
        assert result is None

    def test_short_sl_triggers_on_bar_high(self):
        tracker = StopTracker(stop_loss_pct=5.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=-100, avg_entry_price=100.0)
        # SL at 105.0 (5% above 100). Bar high = 106 → triggers
        bar = _bar(open_=101.0, high=106.0, low=99.0, close=102.0)
        result = tracker.check("X", bar, pos)
        assert result is not None
        assert result.price == pytest.approx(105.0)
        assert result.kind == "sl"

    def test_stop_loss_points(self):
        tracker = StopTracker(stop_loss_points=10.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)
        # SL at 90.0 (100 - 10). Bar low = 89 → triggers
        bar = _bar(open_=95.0, high=96.0, low=89.0, close=91.0)
        result = tracker.check("X", bar, pos)
        assert result is not None
        assert result.price == pytest.approx(90.0)
        assert result.kind == "sl"


class TestTakeProfit:
    def test_long_tp_triggers_on_bar_high(self):
        tracker = StopTracker(take_profit_pct=10.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)
        # TP at 110.0. Bar high = 112 → triggers
        bar = _bar(open_=105.0, high=112.0, low=104.0, close=108.0)
        result = tracker.check("X", bar, pos)
        assert result is not None
        assert result.price == pytest.approx(110.0)
        assert result.kind == "tp"

    def test_short_tp_triggers_on_bar_low(self):
        tracker = StopTracker(take_profit_pct=10.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=-100, avg_entry_price=100.0)
        # TP at 90.0 (10% below 100). Bar low = 88 → triggers
        bar = _bar(open_=95.0, high=96.0, low=88.0, close=91.0)
        result = tracker.check("X", bar, pos)
        assert result is not None
        assert result.price == pytest.approx(90.0)
        assert result.kind == "tp"

    def test_take_profit_points(self):
        tracker = StopTracker(take_profit_points=15.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)
        # TP at 115. Bar high = 120 → triggers
        bar = _bar(open_=110.0, high=120.0, low=108.0, close=118.0)
        result = tracker.check("X", bar, pos)
        assert result is not None
        assert result.price == pytest.approx(115.0)
        assert result.kind == "tp"


class TestTrailingStop:
    def test_trailing_triggers_when_low_breaches(self):
        tracker = StopTracker(trailing_stop_pct=5.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)

        # Bar 1: high=110 → highest=110, trail=110*0.95=104.5. low=99 < 104.5 → triggers
        bar1 = _bar(open_=100.0, high=110.0, low=99.0, close=108.0, ts="2023-01-01")
        result = tracker.check("X", bar1, pos)
        assert result is not None
        assert result.price == pytest.approx(110.0 * 0.95)
        assert result.kind == "ts"

    def test_trailing_triggers_after_pullback(self):
        tracker = StopTracker(trailing_stop_pct=10.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)

        # Bar 1: high=120, trail=108. low=99 < 108 → triggers
        bar1 = _bar(open_=100.0, high=120.0, low=99.0, close=115.0, ts="2023-01-01")
        result = tracker.check("X", bar1, pos)
        assert result is not None
        assert result.price == pytest.approx(120.0 * 0.90)
        assert result.kind == "ts"

    def test_trailing_no_trigger_on_gentle_pullback(self):
        tracker = StopTracker(trailing_stop_pct=10.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)

        # Bar 1: gentle rise, low stays above trailing level
        bar1 = _bar(open_=100.0, high=105.0, low=100.0, close=104.0, ts="2023-01-01")
        result = tracker.check("X", bar1, pos)
        # highest = 105, trail = 105 * 0.9 = 94.5, low = 100 → no trigger
        assert result is None

    def test_trailing_resets_on_new_position(self):
        tracker = StopTracker(trailing_stop_pct=5.0)
        tracker.on_position_opened("X", entry_price=100.0)

        # Simulate price going to 200
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)
        bar = _bar(open_=100.0, high=200.0, low=100.0, close=195.0)
        tracker.check("X", bar, pos)  # updates highest to 200

        # Close and reopen
        tracker.on_position_closed("X")
        tracker.on_position_opened("X", entry_price=50.0)

        # New position: highest should be 50, not 200
        pos2 = Position(symbol="X", qty=100, avg_entry_price=50.0)
        bar2 = _bar(open_=50.0, high=52.0, low=49.0, close=51.0, ts="2023-01-02")
        result = tracker.check("X", bar2, pos2)
        # trail = 52 * 0.95 = 49.4, low = 49 → triggers at 49.4
        assert result is not None
        assert result.price == pytest.approx(52.0 * 0.95)
        assert result.kind == "ts"

    def test_short_trailing_tracks_lowest(self):
        tracker = StopTracker(trailing_stop_pct=5.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=-100, avg_entry_price=100.0)

        # Bar 1: price drops, lowest = 90
        bar1 = _bar(open_=98.0, high=99.0, low=90.0, close=92.0, ts="2023-01-01")
        result = tracker.check("X", bar1, pos)
        # trail = 90 * 1.05 = 94.5. high = 99 > 94.5 → triggers!
        assert result is not None
        assert result.price == pytest.approx(90.0 * 1.05)
        assert result.kind == "ts"


class TestSameBarConflict:
    def test_sl_tp_same_bar_closest_to_open_wins(self):
        # SL at 90, TP at 120. Open at 100.
        # SL distance from open: |100-90| = 10
        # TP distance from open: |100-120| = 20
        # SL is closer to open → SL wins
        tracker = StopTracker(stop_loss_points=10.0, take_profit_points=20.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)
        bar = _bar(open_=100.0, high=125.0, low=85.0, close=95.0)
        result = tracker.check("X", bar, pos)
        assert result is not None
        assert result.price == pytest.approx(90.0)  # SL wins
        assert result.kind == "sl"

    def test_tp_closer_to_open_wins(self):
        # SL at 80, TP at 105. Open at 100.
        # SL distance from open: |100-80| = 20
        # TP distance from open: |100-105| = 5
        # TP is closer to open → TP wins
        tracker = StopTracker(stop_loss_points=20.0, take_profit_points=5.0)
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)
        bar = _bar(open_=100.0, high=110.0, low=75.0, close=90.0)
        result = tracker.check("X", bar, pos)
        assert result is not None
        assert result.price == pytest.approx(105.0)  # TP wins
        assert result.kind == "tp"


class TestNoStops:
    def test_no_stops_configured(self):
        tracker = StopTracker()
        assert tracker.is_active is False

    def test_flat_position_returns_none(self):
        tracker = StopTracker(stop_loss_pct=5.0)
        pos = Position(symbol="X", qty=0)
        bar = _bar(open_=100.0, high=200.0, low=50.0, close=100.0)
        result = tracker.check("X", bar, pos)
        assert result is None


# ---------------------------------------------------------------------------
# Integration: stops in backtest()
# ---------------------------------------------------------------------------


class _AlwaysBuyStrategy(Strategy):
    """Buy on bar 1 if flat. Never exit via on_bar (relies on stops)."""

    def on_bar(self, ctx):
        if ctx.position.is_flat and len(ctx.history) > 1:
            ctx.buy(qty=100)


class TestStopsInBacktest:
    def _make_data(self, prices: list[tuple[float, float, float, float]]) -> pd.DataFrame:
        """Create OHLCV DataFrame from (open, high, low, close) tuples."""
        dates = pd.date_range("2023-01-01", periods=len(prices), freq="D")
        data = {
            "open": [p[0] for p in prices],
            "high": [p[1] for p in prices],
            "low": [p[2] for p in prices],
            "close": [p[3] for p in prices],
            "volume": [1000.0] * len(prices),
        }
        return pd.DataFrame(data, index=dates)

    def test_stop_loss_closes_position(self):
        # Bar 0: open=100, high=101, low=99, close=100 (buy fills here at next_open)
        # Bar 1: open=100, high=101, low=99, close=100 (buy order fills at open=100)
        # Bar 2: open=98, high=98, low=88, close=90 (SL at 95 triggers, low=88 < 95)
        prices = [
            (100, 101, 99, 100),
            (100, 101, 99, 100),
            (98, 98, 88, 90),
            (90, 91, 89, 90),
        ]
        data = self._make_data(prices)
        strategy = _AlwaysBuyStrategy()
        result = backtest(
            strategy,
            data,
            initial_cash=100_000,
            stop_loss_pct=5.0,
        )
        # Should have 2 fills: buy + stop-loss sell
        assert len(result.fills) >= 2
        assert result.fills[-1].side.value == "sell"

    def test_take_profit_closes_position(self):
        prices = [
            (100, 101, 99, 100),
            (100, 101, 99, 100),   # buy fills at open=100
            (102, 115, 101, 112),  # TP at 110 triggers (high=115)
            (112, 113, 111, 112),
        ]
        data = self._make_data(prices)
        strategy = _AlwaysBuyStrategy()
        result = backtest(
            strategy,
            data,
            initial_cash=100_000,
            take_profit_pct=10.0,
        )
        assert len(result.fills) >= 2
        assert result.fills[-1].side.value == "sell"

    def test_stop_fill_includes_slippage(self):
        prices = [
            (100, 101, 99, 100),
            (100, 101, 99, 100),
            (98, 98, 88, 90),
            (90, 91, 89, 90),
        ]
        data = self._make_data(prices)
        strategy = _AlwaysBuyStrategy()
        result = backtest(
            strategy,
            data,
            initial_cash=100_000,
            stop_loss_pct=5.0,
            slippage_pct=1.0,
        )
        # Stop at 95, slippage for sell = 95 * (1 - 0.01) = 94.05
        if len(result.fills) >= 2:
            stop_fill = result.fills[-1]
            assert stop_fill.price < 95.0  # slippage applied

    def test_no_stops_no_effect(self, synthetic_ohlcv):
        strategy = _AlwaysBuyStrategy()
        result = backtest(strategy, data=synthetic_ohlcv, initial_cash=100_000)
        # Without stops, strategy buys once and holds forever (never exits via on_bar)
        buy_fills = [f for f in result.fills if f.side.value == "buy"]
        sell_fills = [f for f in result.fills if f.side.value == "sell"]
        assert len(buy_fills) == 1
        assert len(sell_fills) == 0

    def test_vol_trailing_uses_fallback_when_history_missing(self):
        # vol_trailing with no history → falls back to fallback_pct (10%)
        tracker = StopTracker(
            vol_trailing_multiplier=2.0,
            vol_trailing_lookback=60,
            vol_trailing_fallback_pct=10.0,
        )
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)
        # Bar low = 89 → below fallback stop at 90 → triggers
        bar = _bar(open_=95.0, high=96.0, low=89.0, close=92.0)
        result = tracker.check("X", bar, pos)
        assert result is not None
        assert result.kind == "vol_ts"
        assert result.price == pytest.approx(90.0)

    def test_vol_trailing_no_trigger_inside_band(self):
        tracker = StopTracker(
            vol_trailing_multiplier=2.0,
            vol_trailing_fallback_pct=10.0,
        )
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)
        # Bar low = 95 → above fallback stop at 90 → no trigger
        bar = _bar(open_=99.0, high=100.0, low=95.0, close=97.0)
        result = tracker.check("X", bar, pos)
        assert result is None

    def test_vol_trailing_uses_history_when_available(self):
        # Construct a price history with known vol, verify stop band uses it
        rng = np.random.default_rng(3)
        prices = pd.Series(100 + rng.standard_normal(100).cumsum())

        tracker = StopTracker(
            vol_trailing_multiplier=2.0,
            vol_trailing_lookback=60,
            vol_trailing_fallback_pct=50.0,  # absurd fallback to detect use
        )
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)
        # Bar low far below entry but above realistic vol band
        bar = _bar(open_=99.0, high=100.0, low=70.0, close=80.0)
        result = tracker.check("X", bar, pos, history=prices)
        # With realistic noise, vol*2 should be much smaller than fallback (50%)
        # so stop level should be much higher than fallback stop of 50
        if result is not None:
            assert result.kind == "vol_ts"
            # Vol-based band should be much tighter than fallback
            assert result.price > 50.0

    def test_vol_trailing_hwm_ratchets_up(self):
        # As HWM increases, stop should increase too
        tracker = StopTracker(
            vol_trailing_multiplier=2.0,
            vol_trailing_fallback_pct=10.0,
        )
        tracker.on_position_opened("X", entry_price=100.0)
        pos = Position(symbol="X", qty=100, avg_entry_price=100.0)

        # First bar: HWM=100 → stop=90 (fallback). Bar low 92 → no trigger.
        bar1 = _bar(open_=100.0, high=100.0, low=92.0, close=99.0)
        assert tracker.check("X", bar1, pos) is None

        # Second bar: high pushes HWM to 120 → stop=108. Bar low 109 → no trigger.
        bar2 = _bar(open_=99.0, high=120.0, low=109.0, close=115.0)
        assert tracker.check("X", bar2, pos) is None

        # Third bar: HWM stays at 120 → stop still 108. Bar low 107 → triggers.
        bar3 = _bar(open_=115.0, high=116.0, low=107.0, close=110.0)
        result = tracker.check("X", bar3, pos)
        assert result is not None
        assert result.price == pytest.approx(108.0)

    def test_vol_trailing_inactive_when_no_multiplier(self):
        tracker = StopTracker()
        # No vol_trailing config → not active
        assert not tracker.is_active

    def test_vol_trailing_active_flag(self):
        tracker = StopTracker(
            vol_trailing_multiplier=2.0,
            vol_trailing_fallback_pct=10.0,
        )
        assert tracker.is_active

    def test_stop_outs_recorded_on_trigger(self, synthetic_ohlcv):
        # Tight stop forces multiple stop-outs over the synthetic series
        strategy = _AlwaysBuyStrategy()
        result = backtest(
            strategy,
            data=synthetic_ohlcv,
            initial_cash=100_000,
            stop_loss_pct=2.0,
        )
        # If any stops fired, each should produce a StopOutEvent
        if any(f.side.value == "sell" for f in result.fills):
            assert len(result.stop_outs) >= 1
            event = result.stop_outs[0]
            assert isinstance(event, StopOutEvent)
            assert event.kind == "sl"
            assert event.entry_price > 0
            assert event.exit_price > 0
            assert event.days_held >= 0

    def test_no_stop_outs_when_no_stops_configured(self, synthetic_ohlcv):
        strategy = _AlwaysBuyStrategy()
        result = backtest(strategy, data=synthetic_ohlcv, initial_cash=100_000)
        assert result.stop_outs == []

    def test_strategy_sees_flat_after_stop(self):
        """After a stop fires, strategy.on_bar sees a flat position."""
        positions_seen: list[float] = []

        class _TrackingStrategy(Strategy):
            def on_bar(self, ctx):
                positions_seen.append(ctx.position.qty)
                if ctx.position.is_flat and len(ctx.history) > 1:
                    ctx.buy(qty=100)

        # Timeline with next_open fill policy:
        # Bar 0: on_bar → flat, history=1, no buy
        # Bar 1: on_bar → flat, history=2, submits buy (pending)
        # Bar 2: on_bar_open fills buy at open=100. Stop tracker learns about
        #         position AFTER on_bar. on_bar sees long (100 qty).
        # Bar 3: on_bar_open (nothing pending). Stop check: entry=100,
        #         SL=95, bar low=85 < 95 → triggers! on_bar sees flat.
        prices = [
            (100, 101, 99, 100),   # bar 0
            (100, 101, 99, 100),   # bar 1: buy submitted
            (100, 101, 99, 100),   # bar 2: buy fills, position is long
            (96, 96, 85, 88),      # bar 3: SL triggers before on_bar
            (88, 89, 87, 88),      # bar 4: strategy can re-enter
        ]
        data = self._make_data(prices)
        result = backtest(
            _TrackingStrategy(),
            data,
            initial_cash=100_000,
            stop_loss_pct=5.0,
        )
        # Bar 3: stop fires before on_bar → strategy sees flat
        assert len(positions_seen) >= 4
        assert positions_seen[3] == 0.0
