"""Tests for signal_server — HTTP endpoints for bar submission and status."""

from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from aiohttp.test_utils import TestClient, TestServer

from fastbt.signal_engine import SignalEngine
from fastbt.signal_server import SignalServer
from fastbt.signal_types import SignalType
from fastbt.strategy import Strategy
from fastbt.webhook import WebhookDispatcher


# ---------------------------------------------------------------------------
# Strategies for testing
# ---------------------------------------------------------------------------


class _BuyOnBar1(Strategy):
    def on_bar(self, ctx):
        if ctx.position.is_flat and len(ctx.history) > 1:
            ctx.buy(qty=100)


class _BuyAndSell(Strategy):
    def on_bar(self, ctx):
        bar_idx = len(ctx.history) - 1
        if bar_idx == 1 and ctx.position.is_flat:
            ctx.buy(qty=100)
        elif bar_idx == 3 and ctx.position.is_long:
            ctx.close()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _bar_json(ts="2024-01-01", close=100.0, open_=None, high=None, low=None, volume=1000.0):
    o = open_ if open_ is not None else close
    h = high if high is not None else max(close, o) + 1
    lo = low if low is not None else min(close, o) - 1
    return {
        "timestamp": ts,
        "open": o,
        "high": h,
        "low": lo,
        "close": close,
        "volume": volume,
    }


async def _make_client(aiohttp_client_fn, strategy=None, dispatcher=None):
    """Create a test client with a fresh engine."""
    strat = strategy or _BuyOnBar1()
    engine = SignalEngine(strat, fill_policy="current_close")
    server = SignalServer(engine, dispatcher=dispatcher)
    app = server.create_app()
    if dispatcher is not None:
        # Remove lifecycle handlers when using mocks
        app.on_startup.clear()
        app.on_cleanup.clear()
    return await aiohttp_client_fn(app)


# ---------------------------------------------------------------------------
# POST /bar
# ---------------------------------------------------------------------------


@pytest.mark.asyncio(loop_scope="function")
async def test_valid_bar_returns_200(aiohttp_client):
    client = await _make_client(aiohttp_client)
    resp = await client.post("/bar", json=_bar_json("2024-01-01"))
    assert resp.status == 200
    data = await resp.json()
    assert data["type"] == "no_action"
    assert data["version"] == "0.2.0"


@pytest.mark.asyncio(loop_scope="function")
async def test_entry_signal_returned(aiohttp_client):
    client = await _make_client(aiohttp_client)
    await client.post("/bar", json=_bar_json("2024-01-01"))
    resp = await client.post("/bar", json=_bar_json("2024-01-02", close=102))
    assert resp.status == 200
    data = await resp.json()
    assert data["type"] == "entry_long"
    assert data["side"] == "buy"
    assert data["qty"] == 100


@pytest.mark.asyncio(loop_scope="function")
async def test_invalid_json_returns_400(aiohttp_client):
    client = await _make_client(aiohttp_client)
    resp = await client.post(
        "/bar",
        data=b"not json",
        headers={"Content-Type": "application/json"},
    )
    assert resp.status == 400
    data = await resp.json()
    assert "error" in data


@pytest.mark.asyncio(loop_scope="function")
async def test_missing_fields_returns_400(aiohttp_client):
    client = await _make_client(aiohttp_client)
    resp = await client.post("/bar", json={"timestamp": "2024-01-01", "open": 100})
    assert resp.status == 400
    data = await resp.json()
    assert "Missing fields" in data["error"]


@pytest.mark.asyncio(loop_scope="function")
async def test_out_of_order_returns_422(aiohttp_client):
    client = await _make_client(aiohttp_client)
    await client.post("/bar", json=_bar_json("2024-01-02"))
    resp = await client.post("/bar", json=_bar_json("2024-01-01"))
    assert resp.status == 422
    data = await resp.json()
    assert "before or equal" in data["error"]


# ---------------------------------------------------------------------------
# GET /status
# ---------------------------------------------------------------------------


@pytest.mark.asyncio(loop_scope="function")
async def test_initial_status(aiohttp_client):
    client = await _make_client(aiohttp_client)
    resp = await client.get("/status")
    assert resp.status == 200
    data = await resp.json()
    assert data["bar_count"] == 0
    assert data["position"]["qty"] == 0
    assert data["fills_count"] == 0


@pytest.mark.asyncio(loop_scope="function")
async def test_status_after_trade(aiohttp_client):
    client = await _make_client(aiohttp_client)
    await client.post("/bar", json=_bar_json("2024-01-01"))
    await client.post("/bar", json=_bar_json("2024-01-02", close=102))
    resp = await client.get("/status")
    data = await resp.json()
    assert data["bar_count"] == 2
    assert data["position"]["qty"] == 100
    assert data["position"]["side"] == "long"
    assert data["fills_count"] == 1


# ---------------------------------------------------------------------------
# Full trade lifecycle
# ---------------------------------------------------------------------------


@pytest.mark.asyncio(loop_scope="function")
async def test_full_entry_hold_exit(aiohttp_client):
    client = await _make_client(aiohttp_client, strategy=_BuyAndSell())

    resp = await client.post("/bar", json=_bar_json("2024-01-01"))
    assert (await resp.json())["type"] == "no_action"

    resp = await client.post("/bar", json=_bar_json("2024-01-02"))
    assert (await resp.json())["type"] == "entry_long"

    resp = await client.post("/bar", json=_bar_json("2024-01-03"))
    assert (await resp.json())["type"] == "no_action"

    resp = await client.post("/bar", json=_bar_json("2024-01-04"))
    assert (await resp.json())["type"] == "exit_signal"

    resp = await client.get("/status")
    data = await resp.json()
    assert data["position"]["side"] == "flat"
    assert data["fills_count"] == 2


# ---------------------------------------------------------------------------
# Idempotency
# ---------------------------------------------------------------------------


@pytest.mark.asyncio(loop_scope="function")
async def test_duplicate_bar_returns_same_signal(aiohttp_client):
    client = await _make_client(aiohttp_client)
    bar = _bar_json("2024-01-01")
    resp1 = await client.post("/bar", json=bar)
    resp2 = await client.post("/bar", json=bar)
    data1 = await resp1.json()
    data2 = await resp2.json()
    assert data1 == data2


# ---------------------------------------------------------------------------
# Webhook integration
# ---------------------------------------------------------------------------


@pytest.mark.asyncio(loop_scope="function")
async def test_webhook_fires_on_entry(aiohttp_client):
    mock_dispatcher = AsyncMock(spec=WebhookDispatcher)
    mock_dispatcher.dispatch.return_value = [True]
    client = await _make_client(aiohttp_client, dispatcher=mock_dispatcher)

    # Bar 0: no action → webhook NOT called
    await client.post("/bar", json=_bar_json("2024-01-01"))
    mock_dispatcher.dispatch.assert_not_called()

    # Bar 1: entry → webhook SHOULD be called
    await client.post("/bar", json=_bar_json("2024-01-02"))
    await asyncio.sleep(0.05)
    mock_dispatcher.dispatch.assert_called_once()
    payload = mock_dispatcher.dispatch.call_args[0][0]
    assert payload.type == SignalType.ENTRY_LONG
