"""Tests for short selling — negative positions, margin, position flips."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from fastbt.broker import PaperBroker
from fastbt.types import Bar, OrderSide, OrderStatus, Position


def _bar(price: float, ts: str = "2023-01-01", symbol: str = "X") -> Bar:
    return Bar(
        timestamp=pd.Timestamp(ts),
        symbol=symbol,
        open=price,
        high=price + 1,
        low=price - 1,
        close=price,
        volume=1000.0,
    )


class TestShortPositions:
    def test_sell_short_creates_negative_position(self):
        broker = PaperBroker(initial_cash=100_000)
        bar = _bar(100.0)
        broker.submit_market("X", OrderSide.SELL, 50, bar.timestamp)
        broker.on_bar_open(bar)  # next_open: nothing pending yet
        broker.on_bar_close(bar)
        # Force fill by using current_close policy
        broker2 = PaperBroker(initial_cash=100_000, fill_policy="current_close")
        broker2.submit_market("X", OrderSide.SELL, 50, bar.timestamp)
        broker2.on_bar_close(bar)
        pos = broker2.position("X")
        assert pos.qty == -50
        assert pos.is_short

    def test_short_pnl_positive_when_price_drops(self):
        broker = PaperBroker(initial_cash=100_000, fill_policy="current_close")
        bar1 = _bar(100.0, "2023-01-01")
        broker.submit_market("X", OrderSide.SELL, 100, bar1.timestamp)
        broker.on_bar_close(bar1)
        # Price drops to 90 — cover
        bar2 = _bar(90.0, "2023-01-02")
        broker.submit_market("X", OrderSide.BUY, 100, bar2.timestamp)
        broker.on_bar_close(bar2)
        # Sold at 100, bought at 90 → profit = 10 * 100 = 1000
        assert broker.cash() == 100_000 + 1000

    def test_short_pnl_negative_when_price_rises(self):
        broker = PaperBroker(initial_cash=100_000, fill_policy="current_close")
        bar1 = _bar(100.0, "2023-01-01")
        broker.submit_market("X", OrderSide.SELL, 100, bar1.timestamp)
        broker.on_bar_close(bar1)
        bar2 = _bar(110.0, "2023-01-02")
        broker.submit_market("X", OrderSide.BUY, 100, bar2.timestamp)
        broker.on_bar_close(bar2)
        # Sold at 100, bought at 110 → loss = 10 * 100 = 1000
        assert broker.cash() == 100_000 - 1000

    def test_short_equity_calculation(self):
        broker = PaperBroker(initial_cash=100_000, fill_policy="current_close")
        bar = _bar(100.0)
        broker.submit_market("X", OrderSide.SELL, 50, bar.timestamp)
        broker.on_bar_close(bar)
        # Cash increased by 50 * 100 = 5000 (short sale proceeds)
        # Market value = -50 * 100 = -5000
        # Equity = cash + mv = 105000 + (-5000) = 100000
        eq = broker.equity({"X": 100.0})
        assert eq == pytest.approx(100_000)

    def test_short_market_value_negative(self):
        pos = Position(symbol="X", qty=-100, avg_entry_price=50.0)
        assert pos.market_value(60.0) == -6000.0
        assert pos.unrealized_pnl(60.0) == -1000.0  # (60-50)*(-100)


class TestPositionFlips:
    def test_flip_long_to_short(self):
        broker = PaperBroker(initial_cash=100_000, fill_policy="current_close")
        bar = _bar(100.0)
        broker.submit_market("X", OrderSide.BUY, 100, bar.timestamp)
        broker.on_bar_close(bar)
        assert broker.position("X").qty == 100

        bar2 = _bar(105.0, "2023-01-02")
        broker.submit_market("X", OrderSide.SELL, 150, bar2.timestamp)
        broker.on_bar_close(bar2)
        pos = broker.position("X")
        assert pos.qty == -50
        assert pos.avg_entry_price == 105.0

    def test_flip_short_to_long(self):
        broker = PaperBroker(initial_cash=100_000, fill_policy="current_close")
        bar = _bar(100.0)
        broker.submit_market("X", OrderSide.SELL, 100, bar.timestamp)
        broker.on_bar_close(bar)
        assert broker.position("X").qty == -100

        bar2 = _bar(95.0, "2023-01-02")
        broker.submit_market("X", OrderSide.BUY, 150, bar2.timestamp)
        broker.on_bar_close(bar2)
        pos = broker.position("X")
        assert pos.qty == 50
        assert pos.avg_entry_price == 95.0

    def test_flip_resets_avg_entry_price(self):
        broker = PaperBroker(initial_cash=100_000, fill_policy="current_close")
        bar1 = _bar(100.0, "2023-01-01")
        broker.submit_market("X", OrderSide.BUY, 100, bar1.timestamp)
        broker.on_bar_close(bar1)
        assert broker.position("X").avg_entry_price == 100.0

        bar2 = _bar(110.0, "2023-01-02")
        broker.submit_market("X", OrderSide.SELL, 200, bar2.timestamp)
        broker.on_bar_close(bar2)
        # Flipped to short 100 at 110
        assert broker.position("X").avg_entry_price == 110.0


class TestMargin:
    def test_margin_rejects_insufficient_cash(self):
        # margin_pct=50 → need 50% of short value in cash
        # Selling 1000 shares at $100 = $100,000 value → need $50,000
        # But we only have $10,000
        broker = PaperBroker(
            initial_cash=10_000, fill_policy="current_close", margin_pct=50.0
        )
        bar = _bar(100.0)
        oid = broker.submit_market("X", OrderSide.SELL, 1000, bar.timestamp)
        broker.on_bar_close(bar)
        # Should be rejected
        pos = broker.position("X")
        assert pos.is_flat

    def test_margin_allows_sufficient_cash(self):
        broker = PaperBroker(
            initial_cash=100_000, fill_policy="current_close", margin_pct=50.0
        )
        bar = _bar(100.0)
        broker.submit_market("X", OrderSide.SELL, 100, bar.timestamp)
        broker.on_bar_close(bar)
        # 100 * 100 = $10,000 → need $5,000 margin. We have $100,000.
        pos = broker.position("X")
        assert pos.qty == -100

    def test_margin_auto_liquidation(self):
        broker = PaperBroker(
            initial_cash=60_000,
            fill_policy="current_close",
            margin_pct=50.0,
            maintenance_pct=25.0,
        )
        bar1 = _bar(100.0, "2023-01-01")
        broker.submit_market("X", OrderSide.SELL, 100, bar1.timestamp)
        broker.on_bar_close(bar1)
        assert broker.position("X").qty == -100

        # Price rises sharply → equity drops below maintenance margin
        # Short at 100, price goes to 200
        # Cash = 60000 + 100*100 = 160000 (from short sale)
        # Market value = -100 * 200 = -20000
        # Equity = 160000 + (-20000) = 140000? Wait, let me recalculate.
        # Actually: cash = 60000, sell 100 at 100 → cash += 100*100 = 160000
        # equity at 200 = 160000 + (-100*200) = 160000 - 20000 = 140000
        # maintenance required = 100*200 * 0.25 = 5000
        # 140000 > 5000, so no liquidation yet

        # Let me use a more extreme case:
        # initial_cash = 11000, sell 100 at 100 → cash = 21000
        # price goes to 200 → equity = 21000 + (-100*200) = 21000 - 20000 = 1000
        # maintenance = 100*200*0.25 = 5000
        # 1000 < 5000 → liquidation!
        broker2 = PaperBroker(
            initial_cash=11_000,
            fill_policy="current_close",
            margin_pct=10.0,  # low margin to allow the short
            maintenance_pct=25.0,
        )
        bar1 = _bar(100.0, "2023-01-01")
        broker2.submit_market("X", OrderSide.SELL, 100, bar1.timestamp)
        broker2.on_bar_close(bar1)
        assert broker2.position("X").qty == -100

        # Trigger maintenance margin check at price 200
        closed = broker2.check_maintenance_margin({"X": 200.0}, pd.Timestamp("2023-01-02"))
        assert len(closed) > 0
        assert broker2.position("X").is_flat
