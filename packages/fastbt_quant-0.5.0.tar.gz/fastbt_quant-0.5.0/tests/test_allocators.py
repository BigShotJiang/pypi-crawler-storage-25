"""Tests for fastbt.allocators."""

from __future__ import annotations

import math

import numpy as np
import pandas as pd
import pytest

from fastbt.allocators import (
    annualized_volatility,
    equal_weight,
    inverse_volatility,
    momentum_score,
    momentum_weighted,
    risk_parity,
)


# ---------------------------------------------------------------------------
# annualized_volatility
# ---------------------------------------------------------------------------


class TestAnnualizedVolatility:
    def test_returns_float_with_sufficient_history(self) -> None:
        rng = np.random.default_rng(42)
        prices = pd.Series(100 + rng.standard_normal(100).cumsum())
        result = annualized_volatility(prices, lookback=60)
        assert isinstance(result, float)
        assert result > 0

    def test_returns_none_for_insufficient_history(self) -> None:
        prices = pd.Series([100.0] * 30)  # need lookback+1 = 61 bars
        assert annualized_volatility(prices, lookback=60) is None

    def test_returns_zero_for_flat_prices(self) -> None:
        prices = pd.Series([100.0] * 100)
        result = annualized_volatility(prices, lookback=60)
        assert result == 0.0

    def test_uses_ddof_1_by_default(self) -> None:
        # Compare against manual sample-std calc
        prices = pd.Series([100.0, 101.0, 102.0, 100.0, 101.0, 99.0])
        returns = prices.pct_change().dropna()
        expected = float(returns.std(ddof=1) * math.sqrt(252) * 100.0)
        result = annualized_volatility(prices, lookback=5)
        assert result == pytest.approx(expected)

    def test_ddof_0_supported(self) -> None:
        prices = pd.Series([100.0, 101.0, 102.0, 100.0, 101.0, 99.0])
        returns = prices.pct_change().dropna()
        expected = float(returns.std(ddof=0) * math.sqrt(252) * 100.0)
        result = annualized_volatility(prices, lookback=5, ddof=0)
        assert result == pytest.approx(expected)

    def test_uses_only_last_lookback_bars(self) -> None:
        # Long history with stable tail and noisy head — only tail matters
        rng = np.random.default_rng(7)
        noisy = 100 + rng.standard_normal(200).cumsum()
        stable = pd.Series([200.0] * 100)
        prices = pd.concat([pd.Series(noisy), stable]).reset_index(drop=True)
        result = annualized_volatility(prices, lookback=60)
        # Last 60 bars are flat → vol should be 0
        assert result == 0.0


# ---------------------------------------------------------------------------
# momentum_score
# ---------------------------------------------------------------------------


class TestMomentumScore:
    def test_weighted_sum(self) -> None:
        score = momentum_score(
            {"a": 10.0, "b": 20.0},
            {"a": 0.5, "b": 0.5},
        )
        assert score == pytest.approx(15.0)

    def test_skips_none_values(self) -> None:
        score = momentum_score(
            {"a": 10.0, "b": None, "c": 20.0},
            {"a": 0.3, "b": 0.4, "c": 0.3},
        )
        # 0.3 * 10 + 0.3 * 20 = 9.0  (b skipped, weights NOT renormalized)
        assert score == pytest.approx(9.0)

    def test_all_none_returns_zero(self) -> None:
        score = momentum_score(
            {"a": None, "b": None},
            {"a": 0.5, "b": 0.5},
        )
        assert score == 0.0

    def test_missing_metric_skipped(self) -> None:
        # Weight points to a metric that isn't in the dict
        score = momentum_score(
            {"a": 10.0},
            {"a": 0.3, "missing": 0.7},
        )
        assert score == pytest.approx(3.0)

    def test_negative_values_summed(self) -> None:
        # Negative scores are valid and summed (no clamping at this layer)
        score = momentum_score(
            {"a": -5.0, "b": 10.0},
            {"a": 1.0, "b": 1.0},
        )
        assert score == pytest.approx(5.0)


# ---------------------------------------------------------------------------
# equal_weight
# ---------------------------------------------------------------------------


class TestEqualWeight:
    def test_three_symbols(self) -> None:
        result = equal_weight(["A", "B", "C"])
        assert result == {"A": pytest.approx(1 / 3),
                          "B": pytest.approx(1 / 3),
                          "C": pytest.approx(1 / 3)}

    def test_empty_list(self) -> None:
        assert equal_weight([]) == {}

    def test_weights_sum_to_one(self) -> None:
        result = equal_weight(["A", "B", "C", "D", "E"])
        assert sum(result.values()) == pytest.approx(1.0)

    def test_single_symbol(self) -> None:
        assert equal_weight(["A"]) == {"A": pytest.approx(1.0)}


# ---------------------------------------------------------------------------
# momentum_weighted
# ---------------------------------------------------------------------------


class TestMomentumWeighted:
    def test_proportional_to_positive_scores(self) -> None:
        result = momentum_weighted(
            ["A", "B"],
            {"A": 30.0, "B": 70.0},
        )
        assert result["A"] == pytest.approx(0.3)
        assert result["B"] == pytest.approx(0.7)
        assert sum(result.values()) == pytest.approx(1.0)

    def test_negative_score_gets_zero(self) -> None:
        result = momentum_weighted(
            ["A", "B", "C"],
            {"A": 50.0, "B": -10.0, "C": 50.0},
        )
        assert result["B"] == 0.0
        assert result["A"] == pytest.approx(0.5)
        assert result["C"] == pytest.approx(0.5)

    def test_all_non_positive_falls_back_to_equal(self) -> None:
        result = momentum_weighted(
            ["A", "B"],
            {"A": -5.0, "B": -10.0},
        )
        assert result == {"A": pytest.approx(0.5), "B": pytest.approx(0.5)}

    def test_missing_score_treated_as_zero(self) -> None:
        result = momentum_weighted(["A", "B"], {"A": 10.0})
        assert result["A"] == pytest.approx(1.0)
        assert result["B"] == 0.0

    def test_empty_symbols(self) -> None:
        assert momentum_weighted([], {"A": 1.0}) == {}

    def test_weights_sum_to_one(self) -> None:
        result = momentum_weighted(
            ["A", "B", "C"],
            {"A": 1.0, "B": 2.0, "C": 3.0},
        )
        assert sum(result.values()) == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# inverse_volatility
# ---------------------------------------------------------------------------


class TestInverseVolatility:
    def test_lower_vol_gets_higher_weight(self) -> None:
        # vols A=20, B=40 → inverse = 1/20, 1/40 → weights = 2/3, 1/3
        result = inverse_volatility(["A", "B"], {"A": 20.0, "B": 40.0})
        assert result["A"] == pytest.approx(2 / 3)
        assert result["B"] == pytest.approx(1 / 3)

    def test_missing_vol_excluded(self) -> None:
        result = inverse_volatility(
            ["A", "B", "C"],
            {"A": 20.0, "B": None, "C": 20.0},
        )
        assert "B" not in result
        assert result["A"] == pytest.approx(0.5)
        assert result["C"] == pytest.approx(0.5)

    def test_zero_vol_excluded(self) -> None:
        # Zero vol would div-by-zero; treat as "no vol"
        result = inverse_volatility(
            ["A", "B"],
            {"A": 20.0, "B": 0.0},
        )
        assert "B" not in result
        assert result["A"] == pytest.approx(1.0)

    def test_negative_vol_excluded(self) -> None:
        # Defensive: negative vol shouldn't happen but shouldn't crash
        result = inverse_volatility(
            ["A", "B"],
            {"A": 20.0, "B": -10.0},
        )
        assert "B" not in result

    def test_all_none_falls_back_to_equal(self) -> None:
        result = inverse_volatility(["A", "B"], {"A": None, "B": None})
        assert result == {"A": pytest.approx(0.5), "B": pytest.approx(0.5)}

    def test_empty_symbols(self) -> None:
        assert inverse_volatility([], {"A": 20.0}) == {}

    def test_weights_sum_to_one(self) -> None:
        result = inverse_volatility(
            ["A", "B", "C"],
            {"A": 10.0, "B": 20.0, "C": 30.0},
        )
        assert sum(result.values()) == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# risk_parity
# ---------------------------------------------------------------------------


class TestRiskParity:
    def test_alias_of_inverse_volatility(self) -> None:
        # With zero-correlation assumption, identical to inverse_volatility
        symbols = ["A", "B", "C"]
        vols = {"A": 15.0, "B": 25.0, "C": 35.0}
        assert risk_parity(symbols, vols) == inverse_volatility(symbols, vols)
