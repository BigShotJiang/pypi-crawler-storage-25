"""Tests for the fastbt CLI."""

from __future__ import annotations

import json
import textwrap

import pandas as pd
import pytest

from fastbt.cli import main


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _has_parquet_engine() -> bool:
    try:
        import pyarrow  # noqa: F401
        return True
    except ImportError:
        pass
    try:
        import fastparquet  # noqa: F401
        return True
    except ImportError:
        return False

_STRATEGY_JSON = {
    "version": "0.0.3",
    "entry": {
        "all": [
            {
                "left": {
                    "indicator": "sma",
                    "params": {"period": 3},
                    "output": "value",
                    "source": "close",
                },
                "operator": "crosses_above",
                "right": {
                    "indicator": "sma",
                    "params": {"period": 5},
                    "output": "value",
                    "source": "close",
                },
            }
        ]
    },
    "exit": {
        "all": [
            {
                "left": {
                    "indicator": "sma",
                    "params": {"period": 3},
                    "output": "value",
                    "source": "close",
                },
                "operator": "crosses_below",
                "right": {
                    "indicator": "sma",
                    "params": {"period": 5},
                    "output": "value",
                    "source": "close",
                },
            }
        ]
    },
    "position_sizing": {"method": "fixed_qty", "qty": 10},
}


def _write_strategy(tmp_path):
    """Write a valid strategy JSON and return its path."""
    p = tmp_path / "strat.json"
    p.write_text(json.dumps(_STRATEGY_JSON))
    return str(p)


def _write_ohlcv_csv(tmp_path, n=30):
    """Write a valid OHLCV CSV and return its path."""
    dates = pd.bdate_range("2024-01-01", periods=n)
    closes = [100 + i * 0.5 for i in range(n)]
    df = pd.DataFrame(
        {
            "open": closes,
            "high": [c * 1.01 for c in closes],
            "low": [c * 0.99 for c in closes],
            "close": closes,
            "volume": [1000] * n,
        },
        index=dates,
    )
    p = tmp_path / "data.csv"
    df.to_csv(str(p))
    return str(p)


def _write_ohlcv_parquet(tmp_path, n=30):
    """Write a valid OHLCV Parquet and return its path."""
    dates = pd.bdate_range("2024-01-01", periods=n)
    closes = [100 + i * 0.5 for i in range(n)]
    df = pd.DataFrame(
        {
            "open": closes,
            "high": [c * 1.01 for c in closes],
            "low": [c * 0.99 for c in closes],
            "close": closes,
            "volume": [1000] * n,
        },
        index=dates,
    )
    p = tmp_path / "data.parquet"
    df.to_parquet(str(p))
    return str(p)


# ---------------------------------------------------------------------------
# Tests: run subcommand
# ---------------------------------------------------------------------------


class TestRunCommand:
    def test_run_with_csv_prints_summary(self, tmp_path, capsys):
        strat = _write_strategy(tmp_path)
        data = _write_ohlcv_csv(tmp_path)
        main(["run", strat, "--data", data])
        out = capsys.readouterr().out
        assert "fastbt v" in out
        assert "Total Return:" in out
        assert "Sharpe Ratio:" in out

    @pytest.mark.skipif(
        not _has_parquet_engine(),
        reason="pyarrow/fastparquet not installed",
    )
    def test_run_with_parquet_prints_summary(self, tmp_path, capsys):
        strat = _write_strategy(tmp_path)
        data = _write_ohlcv_parquet(tmp_path)
        main(["run", strat, "--data", data])
        out = capsys.readouterr().out
        assert "fastbt v" in out
        assert "Trades:" in out

    def test_run_quiet_suppresses_output(self, tmp_path, capsys):
        strat = _write_strategy(tmp_path)
        data = _write_ohlcv_csv(tmp_path)
        main(["run", strat, "--data", data, "--quiet"])
        out = capsys.readouterr().out
        assert out == ""

    def test_run_with_save_creates_file(self, tmp_path, capsys):
        strat = _write_strategy(tmp_path)
        data = _write_ohlcv_csv(tmp_path)
        save_path = str(tmp_path / "result.json")
        main(["run", strat, "--data", data, "--save", save_path])
        assert (tmp_path / "result.json").exists()
        saved = json.loads((tmp_path / "result.json").read_text())
        assert "version" in saved
        assert "equity_curve" in saved

    def test_run_with_custom_params(self, tmp_path, capsys):
        strat = _write_strategy(tmp_path)
        data = _write_ohlcv_csv(tmp_path)
        main([
            "run", strat, "--data", data,
            "--symbol", "TEST",
            "--cash", "50000",
            "--commission", "0.1",
            "--slippage", "0.05",
            "--warmup", "5",
        ])
        out = capsys.readouterr().out
        assert "TEST" in out
        assert "$50,000.00" in out


# ---------------------------------------------------------------------------
# Tests: error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_missing_strategy_file(self, tmp_path, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main(["run", str(tmp_path / "nonexistent.json"), "--data", "x.csv"])
        assert exc_info.value.code == 1
        err = capsys.readouterr().err
        assert "File not found" in err

    def test_invalid_json_strategy(self, tmp_path, capsys):
        bad = tmp_path / "bad.json"
        bad.write_text("{not valid json}")
        with pytest.raises(SystemExit) as exc_info:
            main(["run", str(bad), "--data", str(tmp_path / "data.csv")])
        assert exc_info.value.code == 1
        err = capsys.readouterr().err
        assert "Invalid JSON" in err

    def test_invalid_strategy_schema(self, tmp_path, capsys):
        bad = tmp_path / "bad.json"
        bad.write_text(json.dumps({"version": "0.0.3"}))
        with pytest.raises(SystemExit) as exc_info:
            main(["run", str(bad), "--data", str(tmp_path / "data.csv")])
        assert exc_info.value.code == 1
        err = capsys.readouterr().err
        assert "Error:" in err

    def test_missing_data_file(self, tmp_path, capsys):
        strat = _write_strategy(tmp_path)
        with pytest.raises(SystemExit) as exc_info:
            main(["run", strat, "--data", str(tmp_path / "nope.csv")])
        assert exc_info.value.code == 1
        err = capsys.readouterr().err
        assert "File not found" in err

    def test_invalid_data_columns(self, tmp_path, capsys):
        strat = _write_strategy(tmp_path)
        # Write CSV with wrong columns
        bad_csv = tmp_path / "bad.csv"
        df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]}, index=pd.bdate_range("2024-01-01", periods=3))
        df.to_csv(str(bad_csv))
        with pytest.raises(SystemExit) as exc_info:
            main(["run", strat, "--data", str(bad_csv)])
        assert exc_info.value.code == 1
        err = capsys.readouterr().err
        assert "Error:" in err

    def test_missing_data_flag(self, capsys):
        with pytest.raises(SystemExit):
            main(["run", "strat.json"])


# ---------------------------------------------------------------------------
# Tests: show subcommand
# ---------------------------------------------------------------------------


class TestShowCommand:
    def test_show_displays_saved_result(self, tmp_path, capsys):
        # First run and save
        strat = _write_strategy(tmp_path)
        data = _write_ohlcv_csv(tmp_path)
        save_path = str(tmp_path / "result.json")
        main(["run", strat, "--data", data, "--save", save_path, "--quiet"])

        # Then show
        main(["show", save_path])
        out = capsys.readouterr().out
        assert "fastbt v" in out
        assert "Total Return:" in out

    def test_show_invalid_file(self, tmp_path, capsys):
        bad = tmp_path / "bad.json"
        bad.write_text("not json")
        with pytest.raises(SystemExit) as exc_info:
            main(["show", str(bad)])
        assert exc_info.value.code == 1


# ---------------------------------------------------------------------------
# Tests: top-level
# ---------------------------------------------------------------------------


class TestMainEntryPoint:
    def test_no_args_prints_help(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main([])
        assert exc_info.value.code == 0
        out = capsys.readouterr().out
        assert "usage:" in out.lower() or "fastbt" in out.lower()

    def test_unknown_subcommand(self, capsys):
        with pytest.raises(SystemExit):
            main(["bogus"])
