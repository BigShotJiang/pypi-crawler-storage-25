"""Tests for fastbt.loader.load_strategy — the unified JSON dispatch entry point."""

from __future__ import annotations

import json

import pytest
from pydantic import ValidationError

from fastbt.json_portfolio_strategy import JsonPortfolioStrategy
from fastbt.json_strategy import JsonStrategy
from fastbt.loader import load_strategy


def _single_spec(**overrides) -> dict:
    spec: dict = {
        "version": "0.4.0",
        "entry": {
            "all": [
                {
                    "left": {"indicator": "sma", "params": {"period": 10}, "output": "value"},
                    "operator": "crosses_above",
                    "right": {"indicator": "sma", "params": {"period": 30}, "output": "value"},
                }
            ]
        },
        "exit": {
            "all": [
                {
                    "left": {"indicator": "rsi", "params": {"period": 14}, "output": "value"},
                    "operator": ">",
                    "right": 70,
                }
            ]
        },
    }
    spec.update(overrides)
    return spec


def _portfolio_spec(**overrides) -> dict:
    spec: dict = {
        "kind": "portfolio",
        "version": "0.4.0",
        "allocate": {"method": "equal_weight"},
    }
    spec.update(overrides)
    return spec


# ---------------------------------------------------------------------------
# 1. Dispatch by explicit kind
# ---------------------------------------------------------------------------


def test_load_single_with_explicit_kind():
    spec = _single_spec()
    spec["kind"] = "single"
    s = load_strategy(spec)
    assert isinstance(s, JsonStrategy)


def test_load_portfolio_with_kind():
    s = load_strategy(_portfolio_spec())
    assert isinstance(s, JsonPortfolioStrategy)


# ---------------------------------------------------------------------------
# 2. Smart kind defaulting (D10) — back-compat for legacy single-symbol JSON
# ---------------------------------------------------------------------------


def test_load_legacy_single_no_kind_field():
    # Pre-v0.4.0 JSON files don't have `kind` — must still load as single-symbol.
    spec = _single_spec()
    assert "kind" not in spec
    s = load_strategy(spec)
    assert isinstance(s, JsonStrategy)


def test_load_no_kind_no_entry_exit_raises():
    # No kind field AND doesn't look like single-symbol — user must disambiguate.
    spec = {"version": "0.4.0", "allocate": {"method": "equal_weight"}}
    with pytest.raises(ValueError, match="missing 'kind' field"):
        load_strategy(spec)


def test_load_no_kind_partial_shape_raises():
    # Has `entry` but no `exit` — not a complete single-symbol shape, so we
    # require explicit kind. (Avoids misrouting incomplete portfolio JSON.)
    spec = {"version": "0.4.0", "entry": {"all": []}}
    with pytest.raises(ValueError, match="missing 'kind' field"):
        load_strategy(spec)


# ---------------------------------------------------------------------------
# 3. JSON string / bytes input
# ---------------------------------------------------------------------------


def test_load_from_json_string():
    s = load_strategy(json.dumps(_portfolio_spec()))
    assert isinstance(s, JsonPortfolioStrategy)


def test_load_from_json_bytes():
    s = load_strategy(json.dumps(_portfolio_spec()).encode("utf-8"))
    assert isinstance(s, JsonPortfolioStrategy)


def test_load_invalid_json_string_raises():
    with pytest.raises(ValueError, match="Could not parse input as JSON"):
        load_strategy("{not valid json}")


def test_load_wrong_input_type_raises():
    with pytest.raises(TypeError, match="dict, str, or bytes"):
        load_strategy(12345)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# 4. Validation errors propagate
# ---------------------------------------------------------------------------


def test_load_invalid_single_spec_raises_pydantic():
    spec = _single_spec(version="0.99.0")
    with pytest.raises(ValidationError):
        load_strategy(spec)


def test_load_invalid_portfolio_allocator_raises_pydantic():
    spec = _portfolio_spec(allocate={"method": "ghost_method"})
    with pytest.raises(ValidationError):
        load_strategy(spec)


# ---------------------------------------------------------------------------
# 5. Params forwarding
# ---------------------------------------------------------------------------


def test_load_forwards_params_to_single():
    s = load_strategy(_single_spec(), params={"warmup": 50})
    assert s.params == {"warmup": 50}


def test_load_forwards_params_to_portfolio():
    s = load_strategy(_portfolio_spec(), params={"top_n": 5})
    assert s.params == {"top_n": 5}
