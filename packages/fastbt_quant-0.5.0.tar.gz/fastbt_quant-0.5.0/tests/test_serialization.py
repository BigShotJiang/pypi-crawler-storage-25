"""Tests for fastbt.serialization — save/load round-trips."""

from __future__ import annotations

import json

import pandas as pd
import pytest

from fastbt import __version__
from fastbt.portfolio_result import PortfolioResult
from fastbt.result import BacktestResult, Metrics
from fastbt.serialization import load_result, save_result
from fastbt.types import Fill, OrderSide


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_backtest_result(n_bars: int = 10, n_fills: int = 2) -> BacktestResult:
    dates = pd.bdate_range("2024-01-01", periods=n_bars)
    equity = pd.Series(
        [100000 + i * 100 for i in range(n_bars)], index=dates, name="equity"
    )
    fills: list[Fill] = []
    if n_fills >= 1:
        fills.append(
            Fill(
                order_id="1",
                symbol="SYM",
                side=OrderSide.BUY,
                qty=100,
                price=50.0,
                timestamp=dates[1],
                commission=0.5,
            )
        )
    if n_fills >= 2:
        fills.append(
            Fill(
                order_id="2",
                symbol="SYM",
                side=OrderSide.SELL,
                qty=100,
                price=55.0,
                timestamp=dates[5],
                commission=0.5,
            )
        )
    metrics = Metrics(
        total_return=900.0,
        total_return_pct=0.9,
        max_drawdown_pct=0.5,
        sharpe=1.5,
        num_trades=1,
        win_rate_pct=100.0,
        profit_factor=999.99,
        avg_trade_pnl=900.0,
    )
    return BacktestResult(
        equity_curve=equity,
        fills=fills,
        metrics=metrics,
        initial_cash=100000.0,
        final_cash=100900.0,
    )


def _make_portfolio_result() -> PortfolioResult:
    dates = pd.bdate_range("2024-01-01", periods=5)
    equity = pd.Series(
        [100000, 100500, 101000, 100800, 101500], index=dates, name="equity"
    )
    fills = [
        Fill(
            order_id="1",
            symbol="A",
            side=OrderSide.BUY,
            qty=50,
            price=100.0,
            timestamp=dates[0],
        ),
        Fill(
            order_id="2",
            symbol="B",
            side=OrderSide.BUY,
            qty=50,
            price=200.0,
            timestamp=dates[0],
        ),
    ]
    metrics = Metrics(
        total_return=1500.0,
        total_return_pct=1.5,
        max_drawdown_pct=0.2,
        sharpe=1.8,
        num_trades=2,
        win_rate_pct=100.0,
        profit_factor=999.99,
        avg_trade_pnl=750.0,
    )
    weight_history = pd.DataFrame(
        {"A": [0.5, 0.5, 0.5, 0.5, 0.5], "B": [0.5, 0.5, 0.5, 0.5, 0.5]},
        index=dates,
    )
    return PortfolioResult(
        equity_curve=equity,
        fills=fills,
        metrics=metrics,
        initial_cash=100000.0,
        final_cash=101500.0,
        weight_history=weight_history,
        per_symbol_pnl={"A": 800.0, "B": 700.0},
        turnover=0.045,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestSaveLoadRoundTrip:
    def test_save_load_round_trip_backtest(self, tmp_path):
        original = _make_backtest_result()
        path = str(tmp_path / "bt.json")
        save_result(original, path)
        loaded = load_result(path)

        assert isinstance(loaded, BacktestResult)
        assert loaded.initial_cash == original.initial_cash
        assert loaded.final_cash == original.final_cash
        assert loaded.metrics == original.metrics
        assert len(loaded.fills) == len(original.fills)
        assert len(loaded.equity_curve) == len(original.equity_curve)

    def test_save_load_round_trip_portfolio(self, tmp_path):
        original = _make_portfolio_result()
        path = str(tmp_path / "pf.json")
        save_result(original, path)
        loaded = load_result(path)

        assert isinstance(loaded, PortfolioResult)
        assert loaded.initial_cash == original.initial_cash
        assert loaded.final_cash == original.final_cash
        assert loaded.metrics == original.metrics
        assert len(loaded.fills) == len(original.fills)
        assert loaded.per_symbol_pnl == original.per_symbol_pnl
        assert loaded.turnover == original.turnover
        pd.testing.assert_frame_equal(
            loaded.weight_history, original.weight_history, check_freq=False
        )


class TestPreservation:
    def test_save_load_preserves_equity_curve(self, tmp_path):
        original = _make_backtest_result()
        path = str(tmp_path / "bt.json")
        save_result(original, path)
        loaded = load_result(path)

        pd.testing.assert_series_equal(
            loaded.equity_curve, original.equity_curve, check_freq=False
        )

    def test_save_load_preserves_fills_with_enums(self, tmp_path):
        original = _make_backtest_result(n_fills=2)
        path = str(tmp_path / "bt.json")
        save_result(original, path)
        loaded = load_result(path)

        assert loaded.fills[0].side == OrderSide.BUY
        assert loaded.fills[1].side == OrderSide.SELL
        for orig, load in zip(original.fills, loaded.fills):
            assert orig.order_id == load.order_id
            assert orig.symbol == load.symbol
            assert orig.side == load.side
            assert orig.qty == load.qty
            assert orig.price == load.price
            assert orig.timestamp == load.timestamp
            assert orig.commission == load.commission

    def test_save_load_preserves_metrics(self, tmp_path):
        original = _make_backtest_result()
        path = str(tmp_path / "bt.json")
        save_result(original, path)
        loaded = load_result(path)

        assert loaded.metrics.total_return == original.metrics.total_return
        assert loaded.metrics.total_return_pct == original.metrics.total_return_pct
        assert loaded.metrics.max_drawdown_pct == original.metrics.max_drawdown_pct
        assert loaded.metrics.sharpe == original.metrics.sharpe
        assert loaded.metrics.num_trades == original.metrics.num_trades
        assert loaded.metrics.win_rate_pct == original.metrics.win_rate_pct
        assert loaded.metrics.profit_factor == original.metrics.profit_factor
        assert loaded.metrics.avg_trade_pnl == original.metrics.avg_trade_pnl

    def test_save_load_preserves_weight_history(self, tmp_path):
        original = _make_portfolio_result()
        path = str(tmp_path / "pf.json")
        save_result(original, path)
        loaded = load_result(path)

        pd.testing.assert_frame_equal(
            loaded.weight_history, original.weight_history, check_freq=False
        )

    def test_save_load_preserves_per_symbol_pnl(self, tmp_path):
        original = _make_portfolio_result()
        path = str(tmp_path / "pf.json")
        save_result(original, path)
        loaded = load_result(path)

        assert loaded.per_symbol_pnl == {"A": 800.0, "B": 700.0}


class TestErrorHandling:
    def test_load_invalid_json_errors(self, tmp_path):
        path = tmp_path / "bad.json"
        path.write_text("this is not json {{{")
        with pytest.raises(json.JSONDecodeError):
            load_result(str(path))

    def test_load_missing_version_errors(self, tmp_path):
        path = tmp_path / "no_version.json"
        path.write_text(json.dumps({"result_type": "backtest"}))
        with pytest.raises(ValueError, match="does not match"):
            load_result(str(path))

    def test_load_version_mismatch_errors(self, tmp_path):
        path = tmp_path / "wrong_version.json"
        path.write_text(json.dumps({"version": "99.99.99", "result_type": "backtest"}))
        with pytest.raises(ValueError, match="99.99.99"):
            load_result(str(path))


class TestEdgeCases:
    def test_save_creates_valid_json_file(self, tmp_path):
        result = _make_backtest_result()
        path = str(tmp_path / "bt.json")
        save_result(result, path)

        with open(path) as f:
            data = json.loads(f.read())
        assert data["version"] == __version__
        assert data["result_type"] == "backtest"

    def test_save_load_with_zero_trades(self, tmp_path):
        result = _make_backtest_result(n_fills=0)
        path = str(tmp_path / "empty.json")
        save_result(result, path)
        loaded = load_result(path)

        assert isinstance(loaded, BacktestResult)
        assert loaded.fills == []
        assert loaded.metrics == result.metrics
