"""Tests for PortfolioResult."""

import pandas as pd
import pytest

from fastbt.engine import portfolio_backtest
from fastbt.portfolio_result import PortfolioResult, _compute_turnover
from fastbt.portfolio_strategy import PortfolioStrategy


def _make_ohlcv(closes, start="2024-01-01"):
    dates = pd.bdate_range(start, periods=len(closes))
    return pd.DataFrame(
        {
            "open": closes,
            "high": [c * 1.01 for c in closes],
            "low": [c * 0.99 for c in closes],
            "close": closes,
            "volume": [1000] * len(closes),
        },
        index=dates,
    )


class EqualWeight(PortfolioStrategy):
    def on_rebalance(self, ctx):
        n = len(ctx.symbols)
        w = 1.0 / n if n > 0 else 0.0
        return {s: w for s in ctx.symbols}


class FixedWeight(PortfolioStrategy):
    def on_rebalance(self, ctx):
        return self.params.get("weights", {})


def _run_simple_backtest():
    data = {
        "AAPL": _make_ohlcv([100.0, 100.0, 110.0, 110.0, 100.0]),
        "GOOG": _make_ohlcv([200.0, 200.0, 200.0, 220.0, 200.0]),
    }
    return portfolio_backtest(
        EqualWeight(),
        data,
        initial_cash=100_000.0,
        fill_policy="current_close",
    )


class TestPortfolioMetrics:
    def test_sharpe_and_drawdown_computed(self):
        result = _run_simple_backtest()
        # Metrics should be populated
        assert isinstance(result.metrics.sharpe, float)
        assert isinstance(result.metrics.max_drawdown_pct, float)
        assert isinstance(result.metrics.total_return_pct, float)

    def test_total_return_matches_equity_curve(self):
        result = _run_simple_backtest()
        expected_return = (result.equity_curve.iloc[-1] - result.initial_cash)
        assert result.metrics.total_return == pytest.approx(expected_return, abs=1.0)


class TestPerSymbolPnl:
    def test_per_symbol_pnl_breakdown(self):
        result = _run_simple_backtest()
        assert "AAPL" in result.per_symbol_pnl
        assert "GOOG" in result.per_symbol_pnl
        # Each should be a float
        assert isinstance(result.per_symbol_pnl["AAPL"], float)
        assert isinstance(result.per_symbol_pnl["GOOG"], float)


class TestWeightHistory:
    def test_weight_history_dataframe_shape(self):
        result = _run_simple_backtest()
        assert isinstance(result.weight_history, pd.DataFrame)
        assert len(result.weight_history) == len(result.equity_curve)
        assert "AAPL" in result.weight_history.columns
        assert "GOOG" in result.weight_history.columns

    def test_weight_history_values_correct(self):
        """Weights should be between 0 and 1 and sum to at most 1."""
        result = _run_simple_backtest()
        for col in result.weight_history.columns:
            assert (result.weight_history[col] >= -0.01).all(), f"Negative weight in {col}"
        row_sums = result.weight_history.sum(axis=1)
        assert (row_sums <= 1.01).all(), "Weight sum exceeds 1.0"


class TestTurnover:
    def test_turnover_calculation(self):
        result = _run_simple_backtest()
        assert isinstance(result.turnover, float)
        assert result.turnover >= 0.0

    def test_turnover_zero_for_stable_weights(self):
        """If weights don't change, turnover should be near zero."""
        data = {"AAPL": _make_ohlcv([100.0] * 10)}
        result = portfolio_backtest(
            FixedWeight(params={"weights": {"AAPL": 0.5}}),
            data,
            fill_policy="current_close",
        )
        # With constant prices and constant weights, turnover should be very small
        assert result.turnover < 0.01

    def test_compute_turnover_helper(self):
        wh = pd.DataFrame({
            "A": [0.5, 0.3, 0.7],
            "B": [0.5, 0.7, 0.3],
        })
        turnover = _compute_turnover(wh)
        # Bar 1→2: |0.5-0.3| + |0.5-0.7| = 0.4, /2 = 0.2
        # Bar 2→3: |0.3-0.7| + |0.7-0.3| = 0.8, /2 = 0.4
        # Mean = (0.2 + 0.4) / 2 = 0.3
        assert turnover == pytest.approx(0.3, abs=0.001)


class TestRepr:
    def test_repr_shows_summary(self):
        result = _run_simple_backtest()
        r = repr(result)
        assert "PortfolioResult" in r
        assert "symbols=" in r
        assert "trades=" in r
        assert "return=" in r
        assert "sharpe=" in r


class TestFills:
    def test_fills_include_all_symbols(self):
        result = _run_simple_backtest()
        symbols_in_fills = {f.symbol for f in result.fills}
        assert "AAPL" in symbols_in_fills
        assert "GOOG" in symbols_in_fills
