"""Tests for signal_types module."""

from __future__ import annotations

import json

from fastbt.signal_types import PositionState, SignalPayload, SignalType
from fastbt.types import Position


class TestSignalType:
    def test_all_values(self):
        expected = {
            "entry_long",
            "entry_short",
            "exit_signal",
            "stop_loss_hit",
            "take_profit_hit",
            "trailing_stop_hit",
            "position_update",
            "no_action",
        }
        assert {s.value for s in SignalType} == expected

    def test_str_enum(self):
        assert str(SignalType.ENTRY_LONG) == "SignalType.ENTRY_LONG"
        assert SignalType.ENTRY_LONG.value == "entry_long"


class TestPositionState:
    def test_from_position_long(self):
        pos = Position(symbol="X", qty=100, avg_entry_price=50.0)
        state = PositionState.from_position(pos, current_price=55.0)
        assert state.qty == 100
        assert state.avg_entry_price == 50.0
        assert state.unrealized_pnl == 500.0
        assert state.side == "long"

    def test_from_position_short(self):
        pos = Position(symbol="X", qty=-50, avg_entry_price=100.0)
        state = PositionState.from_position(pos, current_price=90.0)
        assert state.qty == -50
        assert state.side == "short"
        assert state.unrealized_pnl == 500.0  # (100 - 90) * -(-50) = 500

    def test_from_position_flat(self):
        pos = Position(symbol="X", qty=0.0, avg_entry_price=0.0)
        state = PositionState.from_position(pos, current_price=100.0)
        assert state.qty == 0.0
        assert state.side == "flat"
        assert state.unrealized_pnl == 0.0


class TestSignalPayload:
    def _make_payload(self, signal_type=SignalType.ENTRY_LONG, **kwargs):
        defaults = dict(
            version="0.2.0",
            type=signal_type,
            symbol="NIFTY",
            timestamp="2024-01-15T09:30:00",
            bar={"open": 100, "high": 101, "low": 99, "close": 100.5, "volume": 10000},
            position=PositionState(qty=100, avg_entry_price=100.5, unrealized_pnl=0.0, side="long"),
            reason="SMA crossover",
            side="buy",
            qty=100.0,
            price=100.5,
        )
        defaults.update(kwargs)
        return SignalPayload(**defaults)

    def test_to_dict(self):
        payload = self._make_payload()
        d = payload.to_dict()
        assert d["type"] == "entry_long"
        assert d["symbol"] == "NIFTY"
        assert d["version"] == "0.2.0"
        assert d["side"] == "buy"
        assert d["qty"] == 100.0
        assert d["price"] == 100.5
        assert d["position"]["side"] == "long"

    def test_to_json_roundtrip(self):
        payload = self._make_payload()
        json_str = payload.to_json()
        parsed = json.loads(json_str)
        assert parsed["type"] == "entry_long"
        assert parsed["symbol"] == "NIFTY"
        assert parsed["bar"]["close"] == 100.5

    def test_no_action_null_fields(self):
        payload = self._make_payload(
            signal_type=SignalType.NO_ACTION,
            side=None,
            qty=None,
            price=None,
            reason="No conditions met",
            position=PositionState(qty=0, avg_entry_price=0, unrealized_pnl=0, side="flat"),
        )
        d = payload.to_dict()
        assert d["type"] == "no_action"
        assert d["side"] is None
        assert d["qty"] is None
        assert d["price"] is None

    def test_stop_loss_signal(self):
        payload = self._make_payload(
            signal_type=SignalType.STOP_LOSS_HIT,
            side="sell",
            reason="Stop loss 5% hit at 95.0",
        )
        assert payload.type == SignalType.STOP_LOSS_HIT
        assert payload.to_dict()["type"] == "stop_loss_hit"

    def test_frozen(self):
        payload = self._make_payload()
        try:
            payload.type = SignalType.NO_ACTION  # type: ignore[misc]
            assert False, "Should raise"
        except AttributeError:
            pass
