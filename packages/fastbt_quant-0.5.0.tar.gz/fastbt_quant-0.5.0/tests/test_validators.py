"""Tests for OHLCV validator."""

from __future__ import annotations

import pandas as pd
import pytest

from fastbt.validators import OHLCVValidationError, validate_ohlcv


def test_valid_ohlcv_passes(synthetic_ohlcv):
    validate_ohlcv(synthetic_ohlcv)


def test_mixed_case_columns_are_accepted():
    df = pd.DataFrame(
        {"Open": [1.0], "High": [2.0], "Low": [0.5], "Close": [1.5], "Volume": [100.0]},
        index=pd.DatetimeIndex(["2023-01-01"]),
    )
    validate_ohlcv(df)


def test_missing_column_raises():
    df = pd.DataFrame(
        {"open": [1.0], "high": [1.0], "low": [1.0], "close": [1.0]},
        index=pd.DatetimeIndex(["2023-01-01"]),
    )
    with pytest.raises(OHLCVValidationError, match="Missing"):
        validate_ohlcv(df)


def test_non_datetime_index_raises():
    df = pd.DataFrame(
        {"open": [1.0], "high": [1.0], "low": [1.0], "close": [1.0], "volume": [1.0]},
    )
    with pytest.raises(OHLCVValidationError, match="DatetimeIndex"):
        validate_ohlcv(df)


def test_non_monotonic_index_raises():
    df = pd.DataFrame(
        {"open": [1.0, 1.0], "high": [1.0, 1.0], "low": [1.0, 1.0],
         "close": [1.0, 1.0], "volume": [1.0, 1.0]},
        index=pd.DatetimeIndex(["2023-01-02", "2023-01-01"]),
    )
    with pytest.raises(OHLCVValidationError, match="monotonic"):
        validate_ohlcv(df)


def test_duplicate_index_raises():
    df = pd.DataFrame(
        {"open": [1.0, 1.0], "high": [1.0, 1.0], "low": [1.0, 1.0],
         "close": [1.0, 1.0], "volume": [1.0, 1.0]},
        index=pd.DatetimeIndex(["2023-01-01", "2023-01-01"]),
    )
    with pytest.raises(OHLCVValidationError, match="duplicate"):
        validate_ohlcv(df)


def test_nan_raises():
    df = pd.DataFrame(
        {"open": [1.0, float("nan")], "high": [1.0, 1.0], "low": [1.0, 1.0],
         "close": [1.0, 1.0], "volume": [1.0, 1.0]},
        index=pd.DatetimeIndex(["2023-01-01", "2023-01-02"]),
    )
    with pytest.raises(OHLCVValidationError, match="NaN"):
        validate_ohlcv(df)


def test_high_lower_than_close_raises():
    df = pd.DataFrame(
        {"open": [100.0], "high": [95.0], "low": [90.0],
         "close": [100.0], "volume": [1.0]},
        index=pd.DatetimeIndex(["2023-01-01"]),
    )
    with pytest.raises(OHLCVValidationError, match="high"):
        validate_ohlcv(df)


def test_negative_volume_raises():
    df = pd.DataFrame(
        {"open": [1.0], "high": [1.0], "low": [1.0], "close": [1.0], "volume": [-1.0]},
        index=pd.DatetimeIndex(["2023-01-01"]),
    )
    with pytest.raises(OHLCVValidationError, match="volume"):
        validate_ohlcv(df)
