"""Tests for the idata.fyi API client (src/fastbt/data.py)."""

from __future__ import annotations

import time
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

from fastbt.config import CONFIG_FILE, load_config, set_value
from fastbt.data import (
    DEFAULT_LIMIT,
    TOKEN_REFRESH_MARGIN,
    IdataAPIError,
    IdataAuthError,
    IdataClient,
)


# ── Helpers ──────────────────────────────────────────────────────────────


def _mock_response(status_code: int = 200, json_data: dict | None = None, text: str = ""):
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data or {}
    resp.text = text
    resp.headers = {}
    return resp


def _auth_json() -> dict:
    return {"access_token": "test-jwt-token", "token_type": "bearer", "expires_in": 28800}


def _ohlcv_rows(n: int = 10, start_date: str = "2025-01-01") -> list[dict]:
    dates = pd.bdate_range(start_date, periods=n)
    rows = []
    for i, d in enumerate(dates):
        base = 100.0 + i
        rows.append(
            {
                "trade_date": d.strftime("%Y-%m-%d"),
                "symbol": "SBIN",
                "open": base,
                "high": base + 2.0,
                "low": base - 1.0,
                "close": base + 1.0,
                "volume": 1_000_000 + i * 1000,
                "last": base + 0.5,
                "prv_close": base - 0.5,
                "vwap": base + 0.3,
            }
        )
    return rows


def _data_json(rows: list[dict]) -> dict:
    return {"status": "success", "data": rows}


# ── Auth Tests ───────────────────────────────────────────────────────────


class TestAuth:
    def test_reads_api_key_from_env(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("IDATA_API_KEY", "env-key-123")
        client = IdataClient()
        assert client._api_key == "env-key-123"

    def test_raises_without_api_key(self, monkeypatch: pytest.MonkeyPatch, tmp_path):
        monkeypatch.delenv("IDATA_API_KEY", raising=False)
        monkeypatch.setattr("fastbt.config.CONFIG_FILE", tmp_path / "nope.toml")
        with pytest.raises(IdataAuthError, match="No idata API key found"):
            IdataClient()

    def test_accepts_explicit_api_key(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.delenv("IDATA_API_KEY", raising=False)
        client = IdataClient(api_key="explicit-key")
        assert client._api_key == "explicit-key"

    def test_auth_sends_correct_headers(self):
        client = IdataClient(api_key="my-key")
        auth_resp = _mock_response(200, _auth_json())
        client._session.post = MagicMock(return_value=auth_resp)

        token = client._ensure_token()

        assert token == "test-jwt-token"
        call_kwargs = client._session.post.call_args
        assert call_kwargs.kwargs["headers"]["X-API-Key"] == "my-key"

    def test_auth_failure_raises(self):
        client = IdataClient(api_key="bad-key")
        client._session.post = MagicMock(
            return_value=_mock_response(401, text="Unauthorized")
        )
        with pytest.raises(IdataAuthError, match="401"):
            client._ensure_token()

    def test_token_cached_on_second_call(self):
        client = IdataClient(api_key="key")
        auth_resp = _mock_response(200, _auth_json())
        client._session.post = MagicMock(return_value=auth_resp)

        client._ensure_token()
        client._ensure_token()

        assert client._session.post.call_count == 1

    def test_token_refreshed_when_expired(self):
        client = IdataClient(api_key="key")
        auth_resp = _mock_response(200, _auth_json())
        client._session.post = MagicMock(return_value=auth_resp)

        client._ensure_token()
        # Simulate expired token
        client._token_expires_at = time.time() - 10
        client._ensure_token()

        assert client._session.post.call_count == 2

    def test_token_refreshed_within_margin(self):
        client = IdataClient(api_key="key")
        auth_resp = _mock_response(200, _auth_json())
        client._session.post = MagicMock(return_value=auth_resp)

        client._ensure_token()
        # Set expiry within the refresh margin
        client._token_expires_at = time.time() + TOKEN_REFRESH_MARGIN - 10
        client._ensure_token()

        assert client._session.post.call_count == 2


# ── Fetch Tests ──────────────────────────────────────────────────────────


class TestFetchOhlcv:
    def _make_client(self) -> IdataClient:
        client = IdataClient(api_key="key")
        client._session.post = MagicMock(return_value=_mock_response(200, _auth_json()))
        return client

    def test_returns_valid_ohlcv_dataframe(self):
        client = self._make_client()
        rows = _ohlcv_rows(20)
        client._session.get = MagicMock(return_value=_mock_response(200, _data_json(rows)))

        df = client.fetch_ohlcv("SBIN")

        assert isinstance(df, pd.DataFrame)
        assert isinstance(df.index, pd.DatetimeIndex)
        assert list(df.columns) == ["open", "high", "low", "close", "volume"]
        assert len(df) == 20

    def test_pagination_fetches_multiple_pages(self):
        client = self._make_client()
        page1 = _ohlcv_rows(DEFAULT_LIMIT, start_date="2020-01-01")
        page2 = _ohlcv_rows(50, start_date="2060-01-01")

        client._session.get = MagicMock(
            side_effect=[
                _mock_response(200, _data_json(page1)),
                _mock_response(200, _data_json(page2)),
            ]
        )

        df = client.fetch_ohlcv("SBIN")
        assert len(df) == DEFAULT_LIMIT + 50
        assert client._session.get.call_count == 2

    def test_empty_response_raises(self):
        client = self._make_client()
        client._session.get = MagicMock(return_value=_mock_response(200, _data_json([])))

        with pytest.raises(IdataAPIError, match="No data"):
            client.fetch_ohlcv("NOSYMBOL")

    def test_401_retries_with_fresh_token(self):
        client = self._make_client()
        rows = _ohlcv_rows(5)

        client._session.get = MagicMock(
            side_effect=[
                _mock_response(401, text="Token expired"),
                _mock_response(200, _data_json(rows)),
            ]
        )

        df = client.fetch_ohlcv("SBIN")
        assert len(df) == 5
        # First auth + re-auth after 401
        assert client._session.post.call_count == 2

    @patch("fastbt.data.time.sleep")
    def test_429_rate_limit_retries(self, mock_sleep: MagicMock):
        client = self._make_client()
        rows = _ohlcv_rows(5)

        rate_resp = _mock_response(429)
        rate_resp.headers = {"Retry-After": "1"}

        client._session.get = MagicMock(
            side_effect=[rate_resp, _mock_response(200, _data_json(rows))]
        )

        df = client.fetch_ohlcv("SBIN")
        assert len(df) == 5
        mock_sleep.assert_called_once_with(1.0)

    def test_api_error_raises(self):
        client = self._make_client()
        client._session.get = MagicMock(
            return_value=_mock_response(500, text="Internal Server Error")
        )

        with pytest.raises(IdataAPIError, match="500"):
            client.fetch_ohlcv("SBIN")


# ── Universe Tests ───────────────────────────────────────────────────────


class TestFetchUniverse:
    def test_returns_dict_of_dataframes(self):
        client = IdataClient(api_key="key")
        client._session.post = MagicMock(return_value=_mock_response(200, _auth_json()))

        rows_a = _ohlcv_rows(10, start_date="2025-01-01")
        rows_b = _ohlcv_rows(15, start_date="2025-01-01")

        client._session.get = MagicMock(
            side_effect=[
                _mock_response(200, _data_json(rows_a)),
                _mock_response(200, _data_json(rows_b)),
            ]
        )

        result = client.fetch_universe(["SBIN", "RELIANCE"])
        assert set(result.keys()) == {"SBIN", "RELIANCE"}
        assert len(result["SBIN"]) == 10
        assert len(result["RELIANCE"]) == 15


# ── CLI Integration Tests ────────────────────────────────────────────────


class TestCLI:
    def test_run_with_symbol_fetches_from_idata(self, tmp_path, monkeypatch):
        """fastbt run strategy.json --symbol SBIN (no --data) should fetch from idata."""
        from fastbt.cli import main

        # Create a minimal strategy JSON
        strat = tmp_path / "strat.json"
        strat.write_text(
            '{"version":"0.0.3","entry":{"all":[{"left":{"indicator":"sma",'
            '"params":{"period":2},"output":"value"},"operator":">","right":50}]},'
            '"exit":{"all":[{"left":{"indicator":"sma","params":{"period":2},'
            '"output":"value"},"operator":"<","right":50}]}}'
        )

        rows = _ohlcv_rows(30)
        mock_client = MagicMock()
        mock_client.return_value.fetch_ohlcv.return_value = pd.DataFrame(
            rows
        ).assign(trade_date=lambda d: pd.to_datetime(d["trade_date"])).set_index(
            "trade_date"
        )[["open", "high", "low", "close", "volume"]]

        monkeypatch.setattr("fastbt.cli.IdataClient", mock_client, raising=False)
        # Patch the lazy import
        import fastbt.cli as cli_mod

        with patch.object(cli_mod, "_cmd_run", wraps=cli_mod._cmd_run):
            with patch("fastbt.data.IdataClient", mock_client):
                # We need to patch the import inside _cmd_run
                pass

        # Simpler: just test _cmd_fetch
        mock_client_inst = MagicMock()
        mock_client_inst.fetch_ohlcv.return_value = pd.DataFrame(
            rows
        ).assign(trade_date=lambda d: pd.to_datetime(d["trade_date"])).set_index(
            "trade_date"
        )[["open", "high", "low", "close", "volume"]]

        with patch("fastbt.data.IdataClient", return_value=mock_client_inst):
            out_csv = tmp_path / "out.csv"
            main(["fetch", "SBIN", "-o", str(out_csv)])
            assert out_csv.exists()
            df = pd.read_csv(str(out_csv), index_col=0, parse_dates=True)
            assert len(df) == 30

    def test_run_without_data_or_symbol_errors(self, tmp_path):
        from fastbt.cli import main

        strat = tmp_path / "strat.json"
        strat.write_text(
            '{"version":"0.0.3","entry":{"all":[{"left":{"indicator":"sma",'
            '"params":{"period":2},"output":"value"},"operator":">","right":50}]},'
            '"exit":{"all":[{"left":{"indicator":"sma","params":{"period":2},'
            '"output":"value"},"operator":"<","right":50}]}}'
        )

        with pytest.raises(SystemExit) as exc_info:
            main(["run", str(strat)])
        assert exc_info.value.code == 1

    def test_fetch_saves_csv(self, tmp_path):
        rows = _ohlcv_rows(10)
        mock_client = MagicMock()
        mock_client.fetch_ohlcv.return_value = pd.DataFrame(
            rows
        ).assign(trade_date=lambda d: pd.to_datetime(d["trade_date"])).set_index(
            "trade_date"
        )[["open", "high", "low", "close", "volume"]]

        with patch("fastbt.data.IdataClient", return_value=mock_client):
            from fastbt.cli import main

            out = tmp_path / "out.csv"
            main(["fetch", "SBIN", "-o", str(out)])
            assert out.exists()
            df = pd.read_csv(str(out), index_col=0, parse_dates=True)
            assert len(df) == 10


# ── Config Tests ─────────────────────────────────────────────────────────


class TestConfig:
    def test_set_and_load(self, tmp_path, monkeypatch):
        cfg_file = tmp_path / "config.toml"
        monkeypatch.setattr("fastbt.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("fastbt.config.CONFIG_FILE", cfg_file)

        set_value("idata-api-key", "sk-test-key-12345")

        cfg = load_config()
        assert cfg["idata"]["api_key"] == "sk-test-key-12345"

    def test_set_unknown_key_raises(self, tmp_path, monkeypatch):
        monkeypatch.setattr("fastbt.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("fastbt.config.CONFIG_FILE", tmp_path / "config.toml")

        with pytest.raises(KeyError, match="Unknown config key"):
            set_value("nonexistent-key", "value")

    def test_load_missing_file_returns_empty(self, tmp_path, monkeypatch):
        monkeypatch.setattr("fastbt.config.CONFIG_FILE", tmp_path / "nope.toml")
        assert load_config() == {}

    def test_client_reads_from_config(self, tmp_path, monkeypatch):
        """IdataClient falls back to config when env var is unset."""
        cfg_file = tmp_path / "config.toml"
        monkeypatch.setattr("fastbt.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("fastbt.config.CONFIG_FILE", cfg_file)
        monkeypatch.delenv("IDATA_API_KEY", raising=False)

        set_value("idata-api-key", "config-key-xyz")

        client = IdataClient()
        assert client._api_key == "config-key-xyz"

    def test_env_var_takes_precedence_over_config(self, tmp_path, monkeypatch):
        cfg_file = tmp_path / "config.toml"
        monkeypatch.setattr("fastbt.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("fastbt.config.CONFIG_FILE", cfg_file)
        monkeypatch.setenv("IDATA_API_KEY", "env-key")

        set_value("idata-api-key", "config-key")

        client = IdataClient()
        assert client._api_key == "env-key"

    def test_config_set_cli(self, tmp_path, monkeypatch):
        from fastbt.cli import main

        cfg_file = tmp_path / "config.toml"
        monkeypatch.setattr("fastbt.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("fastbt.config.CONFIG_FILE", cfg_file)

        main(["config", "set", "idata-api-key", "cli-key-abc"])

        cfg = load_config()
        assert cfg["idata"]["api_key"] == "cli-key-abc"

    def test_config_show_cli(self, tmp_path, monkeypatch, capsys):
        from fastbt.cli import main

        cfg_file = tmp_path / "config.toml"
        monkeypatch.setattr("fastbt.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("fastbt.config.CONFIG_FILE", cfg_file)

        set_value("idata-api-key", "sk-abcdefghijklmnop")
        main(["config", "show"])

        out = capsys.readouterr().out
        assert "sk-a" in out  # masked prefix shown
        assert "sk-abcdefghijklmnop" not in out  # full key NOT shown
