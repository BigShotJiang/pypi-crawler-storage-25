"""Tests for the indicator registry."""

from __future__ import annotations

import pandas as pd
import pytest

from fastbt.registry import IndicatorMeta, IndicatorRegistry, default_registry


# ---------------------------------------------------------------------------
# IndicatorRegistry basics
# ---------------------------------------------------------------------------

class TestRegistryBasics:
    def test_register_and_get(self) -> None:
        reg = IndicatorRegistry()
        meta = IndicatorMeta(
            name="test_ind",
            fn=lambda s, period=10: s,
            input_type="series",
            output_type="series",
            output_names=["value"],
            param_schema={"period": 10},
        )
        reg.register(meta)
        assert reg.get("test_ind") is meta

    def test_has(self) -> None:
        reg = IndicatorRegistry()
        assert not reg.has("missing")
        meta = IndicatorMeta(
            name="x", fn=lambda: None, input_type="series",
            output_type="series", output_names=["value"], param_schema={},
        )
        reg.register(meta)
        assert reg.has("x")

    def test_get_missing_raises_keyerror(self) -> None:
        reg = IndicatorRegistry()
        with pytest.raises(KeyError, match="not found"):
            reg.get("nonexistent")

    def test_list_names(self) -> None:
        reg = IndicatorRegistry()
        for name in ["beta", "alpha"]:
            reg.register(IndicatorMeta(
                name=name, fn=lambda: None, input_type="series",
                output_type="series", output_names=["value"], param_schema={},
            ))
        assert reg.list_names() == ["alpha", "beta"]


# ---------------------------------------------------------------------------
# validate_params
# ---------------------------------------------------------------------------

class TestValidateParams:
    def test_accepts_valid_params(self) -> None:
        reg = IndicatorRegistry()
        reg.register(IndicatorMeta(
            name="ind", fn=lambda: None, input_type="series",
            output_type="series", output_names=["value"],
            param_schema={"period": 14, "std": 2.0},
        ))
        reg.validate_params("ind", {"period": 20})  # should not raise

    def test_catches_unknown_params(self) -> None:
        reg = IndicatorRegistry()
        reg.register(IndicatorMeta(
            name="ind", fn=lambda: None, input_type="series",
            output_type="series", output_names=["value"],
            param_schema={"period": 14},
        ))
        with pytest.raises(ValueError, match="Unknown params"):
            reg.validate_params("ind", {"period": 20, "bogus": 1})

    def test_empty_params_accepted(self) -> None:
        reg = IndicatorRegistry()
        reg.register(IndicatorMeta(
            name="ind", fn=lambda: None, input_type="series",
            output_type="series", output_names=["value"],
            param_schema={"period": 14},
        ))
        reg.validate_params("ind", {})  # should not raise


# ---------------------------------------------------------------------------
# Default registry completeness
# ---------------------------------------------------------------------------

EXPECTED_INDICATORS = [
    "sma", "ema", "rsi", "macd", "bollinger_bands", "atr",
    "stochastic", "adx", "cci", "obv", "vwap", "supertrend",
    "donchian", "keltner", "ichimoku", "williams_r", "mfi",
    "roc", "trix", "kama",
    "pct_from_sma",
]


class TestDefaultRegistry:
    def test_has_20_plus_indicators(self) -> None:
        assert len(default_registry.list_names()) >= 20

    @pytest.mark.parametrize("name", EXPECTED_INDICATORS)
    def test_expected_indicator_registered(self, name: str) -> None:
        assert default_registry.has(name), f"{name!r} missing from default_registry"

    @pytest.mark.parametrize("name", EXPECTED_INDICATORS)
    def test_output_names_match_function_output(
        self, name: str, synthetic_ohlcv: pd.DataFrame,
    ) -> None:
        """For multi-output indicators, output_names must match DataFrame columns."""
        meta = default_registry.get(name)
        if meta.output_type != "multi":
            return  # single-output, nothing to verify against columns

        # Call the indicator to get actual columns
        h, l, c, v = (
            synthetic_ohlcv["high"], synthetic_ohlcv["low"],
            synthetic_ohlcv["close"], synthetic_ohlcv["volume"],
        )
        if meta.input_type == "series":
            result = meta.fn(c)
        elif name == "donchian":
            result = meta.fn(h, l)
        else:
            # ohlcv multi — determine args from function
            import inspect
            sig = inspect.signature(meta.fn)
            params = list(sig.parameters)
            args: list = []
            for p in params:
                if p == "high":
                    args.append(h)
                elif p == "low":
                    args.append(l)
                elif p == "close":
                    args.append(c)
                elif p == "volume":
                    args.append(v)
                else:
                    break  # remaining are keyword-only with defaults
            result = meta.fn(*args)

        assert list(result.columns) == meta.output_names
