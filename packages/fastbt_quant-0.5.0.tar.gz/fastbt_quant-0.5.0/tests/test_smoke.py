"""End-user smoke test — exercises the public API the way a downstream
consumer would, so we catch regressions in the import surface or the most
common single-symbol path.

Kept deliberately tiny so it doubles as the post-install verification we
recommend in INSTALL/USAGE.
"""

from __future__ import annotations

import pandas as pd
import pytest

import fastbt


def test_version_string_matches_distribution():
    """``fastbt.__version__`` is the version pip resolves — keeps PyPI
    metadata and the runtime in sync."""
    assert isinstance(fastbt.__version__, str)
    parts = fastbt.__version__.split(".")
    assert len(parts) >= 2, f"unexpected version format: {fastbt.__version__}"


def test_public_surface_is_importable():
    """Every name in ``__all__`` resolves. Catches accidental removals."""
    for name in fastbt.__all__:
        if name == "IdataClient":
            continue  # lazy-loaded behind the data extra; covered separately
        assert hasattr(fastbt, name), f"{name} listed in __all__ but missing"


def test_idata_client_lazy_message_when_extra_missing():
    """Without the data extra, ``from fastbt import IdataClient`` should
    raise a friendly message, not a bare ImportError or AttributeError."""
    try:
        import requests  # noqa: F401
    except ImportError:
        with pytest.raises(ImportError, match=r"pip install fastbt-quant\[data\]"):
            fastbt.IdataClient  # noqa: B018
    else:
        # data extra IS installed; just check the symbol resolves.
        assert fastbt.IdataClient is not None


def test_minimal_backtest_runs_end_to_end():
    """5-line backtest the README promises actually works."""

    class BuyAndHold(fastbt.Strategy):
        def on_bar(self, ctx):
            if ctx.position.is_flat and len(ctx.history) >= 1:
                ctx.buy(qty=10)

    dates = pd.bdate_range("2024-01-01", periods=20)
    df = pd.DataFrame(
        {
            "open": 100.0,
            "high": 101.0,
            "low": 99.0,
            "close": 100.0,
            "volume": 1000.0,
        },
        index=dates,
    )

    result = fastbt.backtest(BuyAndHold(), data=df, initial_cash=100_000)

    # Buy-and-hold never closes a round-trip, so check fills (entries),
    # not metrics.num_trades (closed trades).
    assert len(result.fills) >= 1, "expected at least one buy fill"
    assert result.fills[0].symbol  # symbol-aware Bar plumbing reached the fill
    assert result.equity_curve.iloc[-1] > 0
