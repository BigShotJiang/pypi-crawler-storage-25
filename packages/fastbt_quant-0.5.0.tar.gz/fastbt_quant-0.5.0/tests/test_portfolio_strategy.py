"""Tests for PortfolioStrategy base class."""

import pandas as pd
import pytest

from fastbt.engine import portfolio_backtest
from fastbt.portfolio_strategy import PortfolioStrategy


def _make_ohlcv(closes, start="2024-01-01"):
    dates = pd.bdate_range(start, periods=len(closes))
    return pd.DataFrame(
        {
            "open": closes,
            "high": [c * 1.01 for c in closes],
            "low": [c * 0.99 for c in closes],
            "close": closes,
            "volume": [1000] * len(closes),
        },
        index=dates,
    )


class TestBaseClass:
    def test_raises_not_implemented(self):
        strat = PortfolioStrategy()
        with pytest.raises(NotImplementedError, match="must implement allocate"):
            data = {"AAPL": _make_ohlcv([100.0] * 3)}
            portfolio_backtest(strat, data, fill_policy="current_close")

    def test_params_passed_through(self):
        strat = PortfolioStrategy(params={"key": "value"})
        assert strat.params["key"] == "value"

    def test_default_params_empty_dict(self):
        strat = PortfolioStrategy()
        assert strat.params == {}


class TestInitialize:
    def test_initialize_called_before_first_bar(self):
        class TrackInit(PortfolioStrategy):
            def __init__(self):
                super().__init__()
                self.initialized = False
                self.init_symbols = None

            def initialize(self, ctx):
                self.initialized = True
                self.init_symbols = ctx.symbols

            def on_rebalance(self, ctx):
                return {}

        strat = TrackInit()
        data = {
            "AAPL": _make_ohlcv([100.0] * 3),
            "GOOG": _make_ohlcv([200.0] * 3),
        }
        portfolio_backtest(strat, data, fill_policy="current_close")
        assert strat.initialized
        assert "AAPL" in strat.init_symbols
        assert "GOOG" in strat.init_symbols


class TestOnRebalanceContext:
    def test_receives_portfolio_context(self):
        class InspectCtx(PortfolioStrategy):
            def __init__(self):
                super().__init__()
                self.ctx_snapshots = []

            def on_rebalance(self, ctx):
                self.ctx_snapshots.append({
                    "symbols": ctx.symbols,
                    "cash": ctx.cash,
                    "equity": ctx.equity,
                    "bars_keys": list(ctx.bars.keys()),
                    "positions_keys": list(ctx.positions.keys()),
                })
                return {}

        strat = InspectCtx()
        data = {
            "AAPL": _make_ohlcv([100.0] * 3),
            "GOOG": _make_ohlcv([200.0] * 3),
        }
        portfolio_backtest(strat, data, initial_cash=50_000.0, fill_policy="current_close")
        assert len(strat.ctx_snapshots) > 0
        snap = strat.ctx_snapshots[0]
        assert snap["symbols"] == ["AAPL", "GOOG"]
        assert snap["cash"] == pytest.approx(50_000.0)
        assert snap["equity"] == pytest.approx(50_000.0)
        assert "AAPL" in snap["bars_keys"]
        assert "GOOG" in snap["bars_keys"]


class TestSubclassExamples:
    def test_equal_weight_strategy(self):
        class EW(PortfolioStrategy):
            def on_rebalance(self, ctx):
                n = len(ctx.symbols)
                w = 1.0 / n if n > 0 else 0.0
                return {s: w for s in ctx.symbols}

        data = {
            "AAPL": _make_ohlcv([100.0] * 5),
            "GOOG": _make_ohlcv([200.0] * 5),
        }
        result = portfolio_backtest(EW(), data, fill_policy="current_close")
        assert result.metrics.num_trades >= 0

    def test_momentum_ranking_strategy(self):
        class MomentumTop1(PortfolioStrategy):
            def on_rebalance(self, ctx):
                # Pick the symbol with highest return over history
                returns = {}
                for sym in ctx.symbols:
                    hist = ctx.history[sym]
                    if len(hist) >= 2:
                        ret = hist["close"].iloc[-1] / hist["close"].iloc[0] - 1
                        returns[sym] = ret
                    else:
                        returns[sym] = 0.0
                best = max(returns, key=returns.get)
                return {best: 0.9}

        data = {
            "WINNER": _make_ohlcv([100.0, 105.0, 110.0, 115.0, 120.0]),
            "LOSER": _make_ohlcv([100.0, 95.0, 90.0, 85.0, 80.0]),
        }
        result = portfolio_backtest(MomentumTop1(), data, fill_policy="current_close")
        # The winner stock should dominate PnL
        assert result.per_symbol_pnl.get("WINNER", 0) >= result.per_symbol_pnl.get("LOSER", 0)


# ---------------------------------------------------------------------------
# Lifecycle pipeline tests
# ---------------------------------------------------------------------------


class TestLifecycleDefaults:
    def test_universe_default_returns_all_symbols(self):
        strat = PortfolioStrategy()
        from fastbt.portfolio_context import PortfolioContext
        from fastbt.types import Bar, Position
        from fastbt.broker import PaperBroker

        broker = PaperBroker(initial_cash=100_000.0)
        ctx = PortfolioContext(
            bars={"A": Bar(pd.Timestamp("2024-01-01"), "A", 100, 101, 99, 100, 1000),
                  "B": Bar(pd.Timestamp("2024-01-01"), "B", 200, 202, 198, 200, 500)},
            positions={},
            cash=100_000.0,
            equity=100_000.0,
            history={},
            symbols=["A", "B"],
            params={},
            broker=broker,
        )
        assert strat.universe(ctx) == ["A", "B"]

    def test_rank_default_equal_scores(self):
        strat = PortfolioStrategy()
        from fastbt.portfolio_context import PortfolioContext
        from fastbt.types import Bar
        from fastbt.broker import PaperBroker

        broker = PaperBroker(initial_cash=100_000.0)
        ctx = PortfolioContext(
            bars={}, positions={}, cash=100_000.0, equity=100_000.0,
            history={}, symbols=["A", "B"], params={}, broker=broker,
        )
        ranked = strat.rank(ctx, ["X", "Y", "Z"])
        assert ranked == [("X", 1.0), ("Y", 1.0), ("Z", 1.0)]

    def test_select_default_selects_all(self):
        strat = PortfolioStrategy()
        from fastbt.portfolio_context import PortfolioContext
        from fastbt.broker import PaperBroker

        broker = PaperBroker(initial_cash=100_000.0)
        ctx = PortfolioContext(
            bars={}, positions={}, cash=100_000.0, equity=100_000.0,
            history={}, symbols=[], params={}, broker=broker,
        )
        selected = strat.select(ctx, [("X", 5.0), ("Y", 3.0), ("Z", 1.0)])
        assert selected == ["X", "Y", "Z"]

    def test_allocate_raises_not_implemented(self):
        strat = PortfolioStrategy()
        from fastbt.portfolio_context import PortfolioContext
        from fastbt.broker import PaperBroker

        broker = PaperBroker(initial_cash=100_000.0)
        ctx = PortfolioContext(
            bars={}, positions={}, cash=100_000.0, equity=100_000.0,
            history={}, symbols=[], params={}, broker=broker,
        )
        with pytest.raises(NotImplementedError, match="must implement allocate"):
            strat.allocate(ctx, ["A", "B"])


class TestLifecyclePipeline:
    def test_pipeline_runs_when_on_rebalance_not_overridden(self):
        """Subclass that overrides allocate() only — pipeline should chain."""
        class AllocateOnly(PortfolioStrategy):
            def allocate(self, ctx, selected):
                w = 1.0 / len(selected) if selected else 0.0
                return {s: w for s in selected}

        data = {
            "AAPL": _make_ohlcv([100.0] * 5),
            "GOOG": _make_ohlcv([200.0] * 5),
        }
        result = portfolio_backtest(AllocateOnly(), data, fill_policy="current_close")
        # Should have buys for both symbols (default universe=all, rank=equal, select=all)
        symbols_filled = {f.symbol for f in result.fills}
        assert "AAPL" in symbols_filled
        assert "GOOG" in symbols_filled

    def test_pipeline_with_all_four_methods(self):
        """Full pipeline: universe filters, rank scores, select picks top 1, allocate weights."""
        class Top1ByVolume(PortfolioStrategy):
            def universe(self, ctx):
                # Filter: only symbols with volume > 500
                return [s for s in ctx.symbols if ctx.bars[s].volume > 500]

            def rank(self, ctx, universe):
                return [(s, ctx.bars[s].volume) for s in universe]

            def select(self, ctx, ranked):
                ranked.sort(key=lambda x: x[1], reverse=True)
                return [ranked[0][0]] if ranked else []

            def allocate(self, ctx, selected):
                return {s: 0.9 for s in selected}

        # AAPL has volume 1000 (from _make_ohlcv), SMALL has volume 100
        aapl_df = _make_ohlcv([100.0] * 5)
        small_dates = pd.bdate_range("2024-01-01", periods=5)
        small_df = pd.DataFrame({
            "open": [50.0] * 5, "high": [51.0] * 5, "low": [49.0] * 5,
            "close": [50.0] * 5, "volume": [100] * 5,
        }, index=small_dates)

        data = {"AAPL": aapl_df, "SMALL": small_df}
        result = portfolio_backtest(Top1ByVolume(), data, fill_policy="current_close")

        # Only AAPL should be bought (SMALL filtered out by universe)
        symbols_filled = {f.symbol for f in result.fills}
        assert "AAPL" in symbols_filled
        assert "SMALL" not in symbols_filled

    def test_on_rebalance_override_skips_pipeline(self):
        """Overriding on_rebalance directly means pipeline methods are NOT called."""
        class DirectOverride(PortfolioStrategy):
            def on_rebalance(self, ctx):
                return {"AAPL": 0.5}

            def universe(self, ctx):
                raise AssertionError("universe should not be called")

            def allocate(self, ctx, selected):
                raise AssertionError("allocate should not be called")

        data = {"AAPL": _make_ohlcv([100.0] * 5)}
        # Should not raise — pipeline is skipped
        result = portfolio_backtest(DirectOverride(), data, fill_policy="current_close")
        assert len(result.fills) > 0

    def test_empty_universe_returns_empty_weights(self):
        """If universe() returns [], on_rebalance() should return {} (all cash)."""
        class EmptyUniverse(PortfolioStrategy):
            def universe(self, ctx):
                return []

            def allocate(self, ctx, selected):
                raise AssertionError("allocate should not be called on empty universe")

        data = {"AAPL": _make_ohlcv([100.0] * 5)}
        result = portfolio_backtest(EmptyUniverse(), data, fill_policy="current_close")
        # No trades, all cash
        assert len(result.fills) == 0
        assert result.equity_curve.iloc[-1] == pytest.approx(100_000.0)
