"""Tests for portfolio_backtest() engine function."""

import numpy as np
import pandas as pd
import pytest

from fastbt.engine import portfolio_backtest
from fastbt.portfolio_strategy import PortfolioStrategy
from fastbt.schedule import RebalanceSchedule


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_ohlcv(
    closes: list[float],
    start: str = "2024-01-01",
    freq: str = "B",
) -> pd.DataFrame:
    """Build a simple OHLCV DataFrame from a list of close prices."""
    dates = pd.bdate_range(start, periods=len(closes), freq=freq)
    return pd.DataFrame(
        {
            "open": closes,
            "high": [c * 1.01 for c in closes],
            "low": [c * 0.99 for c in closes],
            "close": closes,
            "volume": [1000] * len(closes),
        },
        index=dates,
    )


class EqualWeight(PortfolioStrategy):
    """Equal weight across all symbols."""

    def on_rebalance(self, ctx):
        n = len(ctx.symbols)
        w = 1.0 / n if n > 0 else 0.0
        return {s: w for s in ctx.symbols}


class FixedWeight(PortfolioStrategy):
    """Return fixed weights from params."""

    def on_rebalance(self, ctx):
        return self.params.get("weights", {})


class EmptyWeight(PortfolioStrategy):
    """Always returns empty weights (all cash)."""

    def on_rebalance(self, ctx):
        return {}


class ShiftingWeight(PortfolioStrategy):
    """Shifts weights after a certain bar count."""

    def __init__(self, params=None):
        super().__init__(params)
        self._bar_count = 0

    def on_rebalance(self, ctx):
        self._bar_count += 1
        if self._bar_count <= self.params.get("shift_after", 3):
            return self.params.get("weights_before", {})
        return self.params.get("weights_after", {})


# ---------------------------------------------------------------------------
# Basic functionality
# ---------------------------------------------------------------------------


class TestEqualWeight:
    def test_two_stocks_equal_weight(self):
        data = {
            "AAPL": _make_ohlcv([100.0] * 10),
            "GOOG": _make_ohlcv([200.0] * 10),
        }
        result = portfolio_backtest(
            EqualWeight(),
            data,
            initial_cash=100_000.0,
            fill_policy="current_close",
        )
        # Should have buy fills for both symbols
        assert len(result.fills) >= 2
        symbols_filled = {f.symbol for f in result.fills}
        assert "AAPL" in symbols_filled
        assert "GOOG" in symbols_filled

    def test_single_symbol_dict_works(self):
        data = {"AAPL": _make_ohlcv([100.0] * 5)}
        result = portfolio_backtest(
            EqualWeight(),
            data,
            fill_policy="current_close",
        )
        assert result.metrics.num_trades >= 0
        assert len(result.equity_curve) == 5


class TestRebalanceExecution:
    def test_rebalance_adjusts_positions_on_weight_change(self):
        data = {
            "AAPL": _make_ohlcv([100.0] * 10),
            "GOOG": _make_ohlcv([100.0] * 10),
        }
        strategy = ShiftingWeight(
            params={
                "shift_after": 3,
                "weights_before": {"AAPL": 0.5, "GOOG": 0.5},
                "weights_after": {"AAPL": 0.8, "GOOG": 0.2},
            }
        )
        result = portfolio_backtest(
            strategy,
            data,
            fill_policy="current_close",
        )
        # Should have initial buys plus rebalance orders
        assert len(result.fills) > 2

    def test_exit_symbol_not_in_weights(self):
        """Symbol in portfolio but not in returned weights should be exited."""

        class DropGoog(PortfolioStrategy):
            def __init__(self):
                super().__init__()
                self._count = 0

            def on_rebalance(self, ctx):
                self._count += 1
                if self._count <= 2:
                    return {"AAPL": 0.5, "GOOG": 0.5}
                return {"AAPL": 0.5}  # drop GOOG

        data = {
            "AAPL": _make_ohlcv([100.0] * 8),
            "GOOG": _make_ohlcv([100.0] * 8),
        }
        result = portfolio_backtest(
            DropGoog(),
            data,
            fill_policy="current_close",
        )
        # GOOG should have been sold
        goog_sells = [f for f in result.fills if f.symbol == "GOOG" and f.side.value == "sell"]
        assert len(goog_sells) >= 1

    def test_weight_zero_exits_position(self):
        class ZeroGoog(PortfolioStrategy):
            def __init__(self):
                super().__init__()
                self._count = 0

            def on_rebalance(self, ctx):
                self._count += 1
                if self._count <= 2:
                    return {"AAPL": 0.5, "GOOG": 0.5}
                return {"AAPL": 0.5, "GOOG": 0.0}

        data = {
            "AAPL": _make_ohlcv([100.0] * 8),
            "GOOG": _make_ohlcv([100.0] * 8),
        }
        result = portfolio_backtest(
            ZeroGoog(),
            data,
            fill_policy="current_close",
        )
        goog_sells = [f for f in result.fills if f.symbol == "GOOG" and f.side.value == "sell"]
        assert len(goog_sells) >= 1

    def test_empty_weights_exits_all(self):
        class ExitAll(PortfolioStrategy):
            def __init__(self):
                super().__init__()
                self._count = 0

            def on_rebalance(self, ctx):
                self._count += 1
                if self._count <= 2:
                    return {"AAPL": 0.5, "GOOG": 0.5}
                return {}

        data = {
            "AAPL": _make_ohlcv([100.0] * 8),
            "GOOG": _make_ohlcv([100.0] * 8),
        }
        result = portfolio_backtest(
            ExitAll(),
            data,
            fill_policy="current_close",
        )
        # Both should be sold
        sells = [f for f in result.fills if f.side.value == "sell"]
        assert len(sells) >= 2

    def test_zero_delta_no_orders_submitted(self):
        """Same weights every bar should not generate new orders after initial."""
        data = {
            "AAPL": _make_ohlcv([100.0] * 5),
        }
        result = portfolio_backtest(
            FixedWeight(params={"weights": {"AAPL": 0.5}}),
            data,
            fill_policy="current_close",
        )
        # Should have only the initial buy, no subsequent orders
        # (prices don't change, so target qty stays the same)
        aapl_buys = [f for f in result.fills if f.symbol == "AAPL" and f.side.value == "buy"]
        assert len(aapl_buys) == 1


# ---------------------------------------------------------------------------
# Fill policy
# ---------------------------------------------------------------------------


class TestFillPolicy:
    def test_next_open_delays_rebalance(self):
        data = {
            "AAPL": _make_ohlcv([100.0, 105.0, 110.0, 115.0, 120.0]),
        }
        result = portfolio_backtest(
            FixedWeight(params={"weights": {"AAPL": 0.5}}),
            data,
            fill_policy="next_open",
        )
        # With next_open, the first fill should be at bar 2's open (105.0),
        # not bar 1's close (100.0)
        if result.fills:
            assert result.fills[0].price != 100.0


# ---------------------------------------------------------------------------
# Commission and slippage
# ---------------------------------------------------------------------------


class TestCostsApplied:
    def test_commission_applied(self):
        data = {"AAPL": _make_ohlcv([100.0] * 5)}
        result = portfolio_backtest(
            FixedWeight(params={"weights": {"AAPL": 0.5}}),
            data,
            commission_pct=0.1,
            fill_policy="current_close",
        )
        assert any(f.commission > 0 for f in result.fills)

    def test_slippage_applied(self):
        data = {"AAPL": _make_ohlcv([100.0] * 5)}
        result_no_slip = portfolio_backtest(
            FixedWeight(params={"weights": {"AAPL": 0.5}}),
            data,
            slippage_pct=0.0,
            fill_policy="current_close",
        )
        result_with_slip = portfolio_backtest(
            FixedWeight(params={"weights": {"AAPL": 0.5}}),
            data,
            slippage_pct=1.0,
            fill_policy="current_close",
        )
        if result_no_slip.fills and result_with_slip.fills:
            # Slippage should make buy price higher
            assert result_with_slip.fills[0].price > result_no_slip.fills[0].price


# ---------------------------------------------------------------------------
# Share truncation
# ---------------------------------------------------------------------------


class TestTruncation:
    def test_integer_truncation_of_share_qty(self):
        data = {"AAPL": _make_ohlcv([100.0] * 5)}
        result = portfolio_backtest(
            FixedWeight(params={"weights": {"AAPL": 0.5}}),
            data,
            initial_cash=100_000.0,
            fill_policy="current_close",
        )
        # 50% of 100k at $100 = 500 shares (exact), all fills should be int qty
        for f in result.fills:
            assert f.qty == int(f.qty)

    def test_truncation_cash_drag_with_expensive_stocks(self):
        # $10k portfolio, 10% weight in $5000 stock = $1000 target = 0 shares (int truncation)
        data = {"EXP": _make_ohlcv([5000.0] * 5)}
        result = portfolio_backtest(
            FixedWeight(params={"weights": {"EXP": 0.1}}),
            data,
            initial_cash=10_000.0,
            fill_policy="current_close",
        )
        # int(0.1 * 10000 / 5000) = int(0.2) = 0 shares — no fills
        exp_fills = [f for f in result.fills if f.symbol == "EXP"]
        assert len(exp_fills) == 0


# ---------------------------------------------------------------------------
# Alignment
# ---------------------------------------------------------------------------


class TestAlignment:
    def test_timestamp_alignment_forward_fill(self):
        # AAPL has data every day, GOOG skips day 3
        aapl_dates = pd.bdate_range("2024-01-01", periods=5)
        goog_dates = aapl_dates.delete(2)  # remove day 3

        aapl_df = pd.DataFrame(
            {"open": 100, "high": 101, "low": 99, "close": 100, "volume": 1000},
            index=aapl_dates,
        )
        goog_df = pd.DataFrame(
            {"open": 200, "high": 202, "low": 198, "close": 200, "volume": 500},
            index=goog_dates,
        )

        data = {"AAPL": aapl_df, "GOOG": goog_df}
        result = portfolio_backtest(
            EqualWeight(),
            data,
            fill_policy="current_close",
        )
        # Should work without error, ffill covers the gap
        assert len(result.equity_curve) == 5

    def test_non_overlapping_dates_raises(self):
        data = {
            "AAPL": _make_ohlcv([100.0] * 5, start="2024-01-01"),
            "GOOG": _make_ohlcv([200.0] * 5, start="2025-01-01"),
        }
        with pytest.raises(ValueError, match="No overlapping data"):
            portfolio_backtest(EqualWeight(), data)


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_zero_equity_no_division_error(self):
        # Start with very low cash, commissions eat everything
        data = {"AAPL": _make_ohlcv([100.0] * 5)}
        # With $1 cash, can't buy anything at $100
        result = portfolio_backtest(
            EqualWeight(),
            data,
            initial_cash=1.0,
            fill_policy="current_close",
        )
        assert len(result.fills) == 0
        assert result.equity_curve.iloc[-1] == pytest.approx(1.0)

    def test_zero_price_symbol_skipped(self):
        # A symbol with zero prices should not cause division by zero
        data = {
            "AAPL": _make_ohlcv([100.0] * 5),
            "ZERO": _make_ohlcv([0.0] * 5),
        }
        # This should not raise
        result = portfolio_backtest(
            EqualWeight(),
            data,
            fill_policy="current_close",
        )
        zero_fills = [f for f in result.fills if f.symbol == "ZERO"]
        assert len(zero_fills) == 0

    def test_warmup_bars_skips_initial_rebalance(self):
        data = {"AAPL": _make_ohlcv([100.0] * 10)}
        result = portfolio_backtest(
            EqualWeight(),
            data,
            warmup_bars=5,
            fill_policy="current_close",
        )
        # First 5 bars skipped, so fewer fills
        result_no_warmup = portfolio_backtest(
            EqualWeight(),
            data,
            fill_policy="current_close",
        )
        assert len(result.fills) <= len(result_no_warmup.fills)

    def test_rebalance_every_skips_intermediate_bars(self):
        data = {"AAPL": _make_ohlcv([100.0] * 10)}
        result_every_bar = portfolio_backtest(
            EqualWeight(),
            data,
            rebalance_every=1,
            fill_policy="current_close",
        )
        result_every_5 = portfolio_backtest(
            EqualWeight(),
            data,
            rebalance_every=5,
            fill_policy="current_close",
        )
        # Rebalancing every 5 bars should produce same or fewer fills
        assert len(result_every_5.fills) <= len(result_every_bar.fills)


# ---------------------------------------------------------------------------
# Validation errors
# ---------------------------------------------------------------------------


class TestValidation:
    def test_empty_dict_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            portfolio_backtest(EqualWeight(), {})

    def test_weights_sum_gt_one_raises(self):
        class OverWeight(PortfolioStrategy):
            def on_rebalance(self, ctx):
                return {"AAPL": 0.6, "GOOG": 0.6}

        data = {
            "AAPL": _make_ohlcv([100.0] * 3),
            "GOOG": _make_ohlcv([100.0] * 3),
        }
        with pytest.raises(ValueError, match="<= 1.0"):
            portfolio_backtest(OverWeight(), data, fill_policy="current_close")

    def test_negative_weight_raises(self):
        class NegWeight(PortfolioStrategy):
            def on_rebalance(self, ctx):
                return {"AAPL": -0.5}

        data = {"AAPL": _make_ohlcv([100.0] * 3)}
        with pytest.raises(ValueError, match="Negative weight"):
            portfolio_backtest(NegWeight(), data, fill_policy="current_close")

    def test_unknown_symbol_raises(self):
        class UnknownSym(PortfolioStrategy):
            def on_rebalance(self, ctx):
                return {"TSLA": 0.5}

        data = {"AAPL": _make_ohlcv([100.0] * 3)}
        with pytest.raises(ValueError, match="Unknown symbol"):
            portfolio_backtest(UnknownSym(), data, fill_policy="current_close")

    def test_non_ohlcv_dataframe_raises(self):
        bad_df = pd.DataFrame({"price": [100, 200]}, index=pd.bdate_range("2024-01-01", periods=2))
        with pytest.raises(Exception):
            portfolio_backtest(EqualWeight(), {"BAD": bad_df})


# ---------------------------------------------------------------------------
# Equity curve correctness
# ---------------------------------------------------------------------------


class TestEquityCurve:
    def test_equity_curve_matches_manual_calculation(self):
        """With current_close and no costs, equity should be cash + position values."""
        data = {
            "AAPL": _make_ohlcv([100.0, 100.0, 110.0, 110.0, 120.0]),
        }
        result = portfolio_backtest(
            FixedWeight(params={"weights": {"AAPL": 0.5}}),
            data,
            initial_cash=100_000.0,
            fill_policy="current_close",
        )
        # After first bar: buy 500 shares at $100 = $50k invested, $50k cash
        # Bar 3: price goes to $110, equity = $50k cash + 500*$110 = $105k
        assert result.equity_curve.iloc[2] == pytest.approx(105_000.0, rel=0.01)


# ---------------------------------------------------------------------------
# Schedule integration
# ---------------------------------------------------------------------------


class TestScheduleIntegration:
    def test_schedule_weekly_friday_only_rebalances_on_fridays(self):
        # Generate 4 weeks of daily data
        dates = pd.bdate_range("2024-01-01", periods=20)
        data = {"AAPL": pd.DataFrame(
            {"open": 100, "high": 101, "low": 99, "close": 100, "volume": 1000},
            index=dates,
        )}

        class CountRebalances(PortfolioStrategy):
            def __init__(self):
                super().__init__()
                self.rebalance_days = []

            def on_rebalance(self, ctx):
                self.rebalance_days.append(list(ctx.bars.values())[0].timestamp)
                return {"AAPL": 0.5}

        strat = CountRebalances()
        portfolio_backtest(
            strat, data,
            schedule=RebalanceSchedule.weekly(day=4),  # Friday
            fill_policy="current_close",
        )
        # All rebalance days should be Fridays
        for ts in strat.rebalance_days:
            assert ts.weekday() == 4, f"{ts} is not a Friday"
        assert len(strat.rebalance_days) >= 3  # at least 3 Fridays in 4 weeks

    def test_schedule_monthly_first_rebalances_on_month_start(self):
        # 3 months of daily data
        dates = pd.bdate_range("2024-01-01", "2024-03-31")
        data = {"AAPL": pd.DataFrame(
            {"open": 100, "high": 101, "low": 99, "close": 100, "volume": 1000},
            index=dates,
        )}

        class CountRebalances(PortfolioStrategy):
            def __init__(self):
                super().__init__()
                self.rebalance_months = []

            def on_rebalance(self, ctx):
                ts = list(ctx.bars.values())[0].timestamp
                self.rebalance_months.append((ts.year, ts.month))
                return {"AAPL": 0.5}

        strat = CountRebalances()
        portfolio_backtest(
            strat, data,
            schedule=RebalanceSchedule.monthly("first"),
            fill_policy="current_close",
        )
        # Should fire exactly 3 times (Jan, Feb, Mar)
        assert len(strat.rebalance_months) == 3
        assert set(m for _, m in strat.rebalance_months) == {1, 2, 3}

    def test_schedule_monthly_last_rebalances_on_last_trading_day(self):
        dates = pd.bdate_range("2024-01-01", "2024-03-31")
        data = {"AAPL": pd.DataFrame(
            {"open": 100, "high": 101, "low": 99, "close": 100, "volume": 1000},
            index=dates,
        )}

        class TrackDates(PortfolioStrategy):
            def __init__(self):
                super().__init__()
                self.rebalance_dates = []

            def on_rebalance(self, ctx):
                self.rebalance_dates.append(list(ctx.bars.values())[0].timestamp)
                return {"AAPL": 0.5}

        strat = TrackDates()
        portfolio_backtest(
            strat, data,
            schedule=RebalanceSchedule.monthly("last"),
            fill_policy="current_close",
        )
        # Should fire 3 times (last trading day of Jan, Feb, Mar)
        assert len(strat.rebalance_dates) == 3
        # Each should be the last business day of its month
        for ts in strat.rebalance_dates:
            month_dates = [d for d in dates if d.month == ts.month and d.year == ts.year]
            assert ts == month_dates[-1]

    def test_schedule_and_rebalance_every_both_set_raises(self):
        data = {"AAPL": _make_ohlcv([100.0] * 5)}
        with pytest.raises(ValueError, match="Cannot set both"):
            portfolio_backtest(
                EqualWeight(), data,
                rebalance_every=5,
                schedule=RebalanceSchedule.weekly(4),
            )

    def test_schedule_with_default_rebalance_every_ok(self):
        """schedule + rebalance_every=1 (default) should NOT raise."""
        data = {"AAPL": _make_ohlcv([100.0] * 5)}
        # Should not raise
        result = portfolio_backtest(
            EqualWeight(), data,
            rebalance_every=1,
            schedule=RebalanceSchedule.every_bar(),
            fill_policy="current_close",
        )
        assert len(result.equity_curve) == 5


# ---------------------------------------------------------------------------
# Context fields
# ---------------------------------------------------------------------------


class TestContextFields:
    def test_bar_index_in_context(self):
        class TrackIndex(PortfolioStrategy):
            def __init__(self):
                super().__init__()
                self.bar_indices = []

            def on_rebalance(self, ctx):
                self.bar_indices.append(ctx.bar_index)
                return {"AAPL": 0.5}

        strat = TrackIndex()
        data = {"AAPL": _make_ohlcv([100.0] * 5)}
        portfolio_backtest(strat, data, fill_policy="current_close")
        assert strat.bar_indices == [0, 1, 2, 3, 4]

    def test_rebalance_count_in_context(self):
        class TrackCount(PortfolioStrategy):
            def __init__(self):
                super().__init__()
                self.counts = []

            def on_rebalance(self, ctx):
                self.counts.append(ctx.rebalance_count)
                return {"AAPL": 0.5}

        strat = TrackCount()
        data = {"AAPL": _make_ohlcv([100.0] * 5)}
        portfolio_backtest(strat, data, fill_policy="current_close")
        # rebalance_count is the count BEFORE this rebalance fires
        assert strat.counts == [0, 1, 2, 3, 4]

    def test_rebalance_count_with_schedule(self):
        """rebalance_count should only increment on actual rebalance bars."""
        class TrackCount(PortfolioStrategy):
            def __init__(self):
                super().__init__()
                self.counts = []

            def on_rebalance(self, ctx):
                self.counts.append(ctx.rebalance_count)
                return {"AAPL": 0.5}

        strat = TrackCount()
        data = {"AAPL": _make_ohlcv([100.0] * 10)}
        portfolio_backtest(
            strat, data,
            rebalance_every=3,
            fill_policy="current_close",
        )
        # Fires on bars 0, 3, 6, 9 → counts should be 0, 1, 2, 3
        assert strat.counts == [0, 1, 2, 3]


# ---------------------------------------------------------------------------
# Lifecycle pipeline E2E
# ---------------------------------------------------------------------------


class TestLifecyclePipelineE2E:
    def test_momentum_pipeline_end_to_end(self):
        """Full lifecycle: universe filters, rank scores by return, select top 1, allocate."""
        class MomentumTop1(PortfolioStrategy):
            def universe(self, ctx):
                return [s for s in ctx.symbols if ctx.bars[s].volume > 500]

            def rank(self, ctx, universe):
                scores = []
                for sym in universe:
                    hist = ctx.history[sym]["close"]
                    ret = hist.iloc[-1] / hist.iloc[0] - 1 if len(hist) >= 2 else 0.0
                    scores.append((sym, ret))
                return sorted(scores, key=lambda x: x[1], reverse=True)

            def select(self, ctx, ranked):
                return [ranked[0][0]] if ranked else []

            def allocate(self, ctx, selected):
                return {s: 0.9 for s in selected}

        data = {
            "WINNER": _make_ohlcv([100.0, 105.0, 110.0, 115.0, 120.0]),
            "LOSER": _make_ohlcv([100.0, 95.0, 90.0, 85.0, 80.0]),
        }
        result = portfolio_backtest(
            MomentumTop1(), data,
            fill_policy="current_close",
        )
        # Should mostly hold WINNER
        winner_fills = [f for f in result.fills if f.symbol == "WINNER"]
        assert len(winner_fills) > 0

    def test_pipeline_with_monthly_schedule(self):
        """Pipeline strategy + monthly schedule work together."""
        class AllocateEqual(PortfolioStrategy):
            def allocate(self, ctx, selected):
                if not selected:
                    return {}
                w = 1.0 / len(selected)
                return {s: w for s in selected}

        dates = pd.bdate_range("2024-01-01", "2024-03-31")
        data = {
            "AAPL": pd.DataFrame(
                {"open": 100, "high": 101, "low": 99, "close": 100, "volume": 1000},
                index=dates,
            ),
        }
        result = portfolio_backtest(
            AllocateEqual(), data,
            schedule=RebalanceSchedule.monthly("first"),
            fill_policy="current_close",
        )
        # Should have fills (3 monthly rebalances)
        assert len(result.fills) > 0


# ---------------------------------------------------------------------------
# Matrix tests (cross-cutting old + new combos)
# ---------------------------------------------------------------------------


class TestMatrixCombinations:
    def test_old_strategy_with_new_schedule(self):
        """Phase A strategy (overrides on_rebalance) + Phase B schedule."""
        data = {
            "AAPL": _make_ohlcv([100.0] * 10),
        }
        result = portfolio_backtest(
            EqualWeight(), data,
            schedule=RebalanceSchedule.every_n_bars(3),
            fill_policy="current_close",
        )
        # Should have fewer fills than every-bar (only bars 0, 3, 6, 9)
        result_every = portfolio_backtest(
            EqualWeight(), data,
            fill_policy="current_close",
        )
        assert len(result.fills) <= len(result_every.fills)

    def test_lifecycle_strategy_with_rebalance_every(self):
        """Phase B pipeline strategy + Phase A rebalance_every param."""
        class AllocateOnly(PortfolioStrategy):
            def allocate(self, ctx, selected):
                if not selected:
                    return {}
                w = 1.0 / len(selected)
                return {s: w for s in selected}

        data = {"AAPL": _make_ohlcv([100.0] * 10)}
        result = portfolio_backtest(
            AllocateOnly(), data,
            rebalance_every=3,
            fill_policy="current_close",
        )
        assert len(result.fills) > 0
        assert len(result.equity_curve) == 10

    def test_schedule_reuse_across_backtests(self):
        """Same schedule object used for two backtests should work correctly."""
        schedule = RebalanceSchedule.monthly("first")
        dates = pd.bdate_range("2024-01-01", "2024-02-29")
        data = {
            "AAPL": pd.DataFrame(
                {"open": 100, "high": 101, "low": 99, "close": 100, "volume": 1000},
                index=dates,
            ),
        }

        # First run
        result1 = portfolio_backtest(
            EqualWeight(), data,
            schedule=schedule,
            fill_policy="current_close",
        )
        # Second run with same schedule object
        result2 = portfolio_backtest(
            EqualWeight(), data,
            schedule=schedule,
            fill_policy="current_close",
        )
        # Both should produce the same results
        assert len(result1.fills) == len(result2.fills)
        assert len(result1.equity_curve) == len(result2.equity_curve)


class TestSymbolAwareFills:
    """Regression tests for the symbol-blind broker drain bug.

    Pre-fix: every pending order from a rebalance batch filled at the
    first symbol's open price. With a wide price spread (CHEAP=100,
    PRICEY=3000), this produced nonsense equity and MDD.
    """

    def test_mixed_price_levels_fill_at_own_open_next_open(self):
        # Two symbols at very different price levels.
        dates = pd.bdate_range("2024-01-01", periods=5)
        data = {
            "CHEAP": pd.DataFrame(
                {"open": 100.0, "high": 101.0, "low": 99.0,
                 "close": 100.0, "volume": 1000},
                index=dates,
            ),
            "PRICEY": pd.DataFrame(
                {"open": 3000.0, "high": 3010.0, "low": 2990.0,
                 "close": 3000.0, "volume": 1000},
                index=dates,
            ),
        }

        result = portfolio_backtest(
            EqualWeight(), data,
            schedule=RebalanceSchedule.every_bar(),
            fill_policy="next_open",
            initial_cash=1_000_000,
        )

        # First-bar rebalance submits buys; they fill on bar 2's open
        # (next_open policy). Each fill must use its own symbol's open.
        first_fills = [f for f in result.fills if f.timestamp == dates[1]]
        assert len(first_fills) == 2
        prices = {f.symbol: f.price for f in first_fills}
        assert prices["CHEAP"] == pytest.approx(100.0)
        assert prices["PRICEY"] == pytest.approx(3000.0)

    def test_mixed_price_levels_fill_at_own_close_current_close(self):
        dates = pd.bdate_range("2024-01-01", periods=5)
        data = {
            "CHEAP": pd.DataFrame(
                {"open": 100.0, "high": 106.0, "low": 99.0,
                 "close": 105.0, "volume": 1000},
                index=dates,
            ),
            "PRICEY": pd.DataFrame(
                {"open": 3000.0, "high": 3060.0, "low": 2990.0,
                 "close": 3050.0, "volume": 1000},
                index=dates,
            ),
        }

        result = portfolio_backtest(
            EqualWeight(), data,
            schedule=RebalanceSchedule.every_bar(),
            fill_policy="current_close",
            initial_cash=1_000_000,
        )

        # current_close: rebalance fills happen on the same bar's close.
        first_fills = [f for f in result.fills if f.timestamp == dates[0]]
        assert len(first_fills) == 2
        prices = {f.symbol: f.price for f in first_fills}
        assert prices["CHEAP"] == pytest.approx(105.0)
        assert prices["PRICEY"] == pytest.approx(3050.0)

    def test_mixed_price_equity_stays_sane(self):
        """Pre-fix bug produced negative equity / MDD > 100%. Equity must
        stay positive and bounded for trivially flat prices."""
        dates = pd.bdate_range("2024-01-01", periods=20)
        data = {
            "CHEAP": pd.DataFrame(
                {"open": 100.0, "high": 100.0, "low": 100.0,
                 "close": 100.0, "volume": 1000},
                index=dates,
            ),
            "PRICEY": pd.DataFrame(
                {"open": 3000.0, "high": 3000.0, "low": 3000.0,
                 "close": 3000.0, "volume": 1000},
                index=dates,
            ),
        }

        result = portfolio_backtest(
            EqualWeight(), data,
            schedule=RebalanceSchedule.every_bar(),
            fill_policy="next_open",
            initial_cash=1_000_000,
        )

        # Flat prices and equal-weight rebalance should leave equity
        # near initial cash (minus small rounding from integer share qty).
        eq = result.equity_curve
        assert (eq > 0).all(), "Equity went negative — symbol-blind drain regression"
        # Initial 1M, equity should stay within a tight band around it.
        assert eq.min() >= 900_000
        assert eq.max() <= 1_010_000
