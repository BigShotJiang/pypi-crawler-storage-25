"""Tests for fastbt.portfolio_schema — Pydantic models for JSON portfolio strategies."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from fastbt.portfolio_schema import (
    EqualWeightAlloc,
    EveryBarSchedule,
    EveryNBarsSchedule,
    InverseVolatilityAlloc,
    MomentumWeightedAlloc,
    MonthlySchedule,
    PortfolioStrategySpec,
    RiskParityAlloc,
    SelectSpec,
    UniverseFilter,
    WeeklySchedule,
    WeightedIndicatorRef,
    WeightedMetricsRank,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _minimal_portfolio_spec(**overrides) -> dict:
    """Smallest valid portfolio spec — equal_weight allocation, every-bar schedule."""
    spec: dict = {
        "kind": "portfolio",
        "version": "0.4.0",
        "allocate": {"method": "equal_weight"},
    }
    spec.update(overrides)
    return spec


# ---------------------------------------------------------------------------
# 1. Top-level kind discriminator (D1)
# ---------------------------------------------------------------------------


def test_minimal_portfolio_spec_loads() -> None:
    model = PortfolioStrategySpec.model_validate(_minimal_portfolio_spec())
    assert model.kind == "portfolio"
    assert model.version == "0.4.0"
    assert isinstance(model.allocate, EqualWeightAlloc)
    assert isinstance(model.schedule, EveryBarSchedule)


def test_kind_must_be_portfolio() -> None:
    spec = _minimal_portfolio_spec()
    spec["kind"] = "single"
    with pytest.raises(ValidationError):
        PortfolioStrategySpec.model_validate(spec)


def test_version_must_be_040() -> None:
    spec = _minimal_portfolio_spec(version="0.3.0")
    with pytest.raises(ValidationError):
        PortfolioStrategySpec.model_validate(spec)


# ---------------------------------------------------------------------------
# 2. UniverseFilter
# ---------------------------------------------------------------------------


def test_universe_default_no_filters() -> None:
    uf = UniverseFilter()
    assert uf.min_history is None
    assert uf.min_avg_volume is None
    assert uf.max_symbols is None


def test_universe_min_history_negative_rejected() -> None:
    with pytest.raises(ValidationError, match="min_history"):
        UniverseFilter.model_validate({"min_history": -1})


def test_universe_max_symbols_zero_rejected() -> None:
    with pytest.raises(ValidationError, match="max_symbols"):
        UniverseFilter.model_validate({"max_symbols": 0})


def test_universe_all_three_filters() -> None:
    uf = UniverseFilter.model_validate(
        {"min_history": 90, "min_avg_volume": 100_000.0, "max_symbols": 50}
    )
    assert uf.min_history == 90
    assert uf.min_avg_volume == 100_000.0
    assert uf.max_symbols == 50


# ---------------------------------------------------------------------------
# 3. WeightedIndicatorRef + WeightedMetricsRank (D3, D6)
# ---------------------------------------------------------------------------


def test_weighted_indicator_ref_inherits_validation() -> None:
    # Same registry validation as IndicatorRef
    with pytest.raises(ValidationError, match="not found"):
        WeightedIndicatorRef.model_validate(
            {"indicator": "ghost", "params": {}, "output": "value", "weight": 1.0}
        )


def test_weighted_indicator_ref_typo_param() -> None:
    with pytest.raises(ValidationError, match="Unknown params"):
        WeightedIndicatorRef.model_validate(
            {
                "indicator": "rsi",
                "params": {"periood": 14},
                "output": "value",
                "weight": 1.0,
            }
        )


def test_weighted_indicator_ref_valid() -> None:
    ref = WeightedIndicatorRef.model_validate(
        {"indicator": "roc", "params": {"period": 90}, "output": "value", "weight": 0.35}
    )
    assert ref.weight == 0.35
    assert ref.indicator == "roc"


def test_weighted_metrics_rank_empty_metrics_rejected() -> None:
    with pytest.raises(ValidationError):
        WeightedMetricsRank.model_validate({"score": "weighted_metrics", "metrics": []})


def test_weighted_metrics_rank_single_metric_ok() -> None:
    rank = WeightedMetricsRank.model_validate(
        {
            "score": "weighted_metrics",
            "metrics": [
                {
                    "indicator": "roc",
                    "params": {"period": 30},
                    "output": "value",
                    "weight": 1.0,
                }
            ],
        }
    )
    assert len(rank.metrics) == 1


def test_weighted_metrics_rank_invalid_score_value_rejected() -> None:
    with pytest.raises(ValidationError):
        WeightedMetricsRank.model_validate(
            {"score": "z_score", "metrics": []}
        )


# ---------------------------------------------------------------------------
# 4. SelectSpec
# ---------------------------------------------------------------------------


def test_select_default_all() -> None:
    s = SelectSpec()
    assert s.top_n is None
    assert s.direction == "desc"


def test_select_top_n_zero_rejected() -> None:
    with pytest.raises(ValidationError, match="top_n"):
        SelectSpec.model_validate({"top_n": 0})


def test_select_invalid_direction_rejected() -> None:
    with pytest.raises(ValidationError):
        SelectSpec.model_validate({"top_n": 5, "direction": "sideways"})


def test_select_top_n_requires_rank_in_spec() -> None:
    spec = _minimal_portfolio_spec(select={"top_n": 3})
    with pytest.raises(ValidationError, match="select.top_n requires a rank"):
        PortfolioStrategySpec.model_validate(spec)


# ---------------------------------------------------------------------------
# 5. AllocateSpec (discriminated union)
# ---------------------------------------------------------------------------


def test_allocate_equal_weight() -> None:
    spec = _minimal_portfolio_spec(allocate={"method": "equal_weight"})
    model = PortfolioStrategySpec.model_validate(spec)
    assert isinstance(model.allocate, EqualWeightAlloc)


def test_allocate_momentum_weighted() -> None:
    spec = _minimal_portfolio_spec(allocate={"method": "momentum_weighted"})
    model = PortfolioStrategySpec.model_validate(spec)
    assert isinstance(model.allocate, MomentumWeightedAlloc)


def test_allocate_inverse_volatility_with_lookback() -> None:
    spec = _minimal_portfolio_spec(
        allocate={"method": "inverse_volatility", "vol_lookback": 90}
    )
    model = PortfolioStrategySpec.model_validate(spec)
    assert isinstance(model.allocate, InverseVolatilityAlloc)
    assert model.allocate.vol_lookback == 90


def test_allocate_inverse_volatility_default_lookback() -> None:
    spec = _minimal_portfolio_spec(allocate={"method": "inverse_volatility"})
    model = PortfolioStrategySpec.model_validate(spec)
    assert model.allocate.vol_lookback == 60


def test_allocate_risk_parity() -> None:
    spec = _minimal_portfolio_spec(allocate={"method": "risk_parity", "vol_lookback": 30})
    model = PortfolioStrategySpec.model_validate(spec)
    assert isinstance(model.allocate, RiskParityAlloc)
    assert model.allocate.vol_lookback == 30


def test_allocate_unknown_method_rejected() -> None:
    spec = _minimal_portfolio_spec(allocate={"method": "kelly_optimal"})
    with pytest.raises(ValidationError):
        PortfolioStrategySpec.model_validate(spec)


def test_allocate_typo_param_rejected() -> None:
    # vol_lokback typo (extra param) — Pydantic rejects extras by default? No, it allows them.
    # But the discriminated union will accept extras silently. Check the actual default.
    # If this test fails, we may need model_config = {"extra": "forbid"} on the alloc classes.
    spec = _minimal_portfolio_spec(
        allocate={"method": "inverse_volatility", "vol_lokback": 90}
    )
    model = PortfolioStrategySpec.model_validate(spec)
    # Verify the typo'd param is NOT accidentally applied
    assert model.allocate.vol_lookback == 60  # default, since typo was ignored
    # Note: if you want to forbid extras, add `model_config = {"extra": "forbid"}` to _AllocBase


# ---------------------------------------------------------------------------
# 6. ScheduleSpec (discriminated union)
# ---------------------------------------------------------------------------


def test_schedule_every_bar() -> None:
    spec = _minimal_portfolio_spec(schedule={"type": "every_bar"})
    model = PortfolioStrategySpec.model_validate(spec)
    assert isinstance(model.schedule, EveryBarSchedule)


def test_schedule_every_n_bars() -> None:
    spec = _minimal_portfolio_spec(schedule={"type": "every_n_bars", "n": 5})
    model = PortfolioStrategySpec.model_validate(spec)
    assert isinstance(model.schedule, EveryNBarsSchedule)
    assert model.schedule.n == 5


def test_schedule_every_n_bars_zero_rejected() -> None:
    spec = _minimal_portfolio_spec(schedule={"type": "every_n_bars", "n": 0})
    with pytest.raises(ValidationError, match="n must be >= 1"):
        PortfolioStrategySpec.model_validate(spec)


def test_schedule_weekly() -> None:
    spec = _minimal_portfolio_spec(schedule={"type": "weekly", "day": 3})
    model = PortfolioStrategySpec.model_validate(spec)
    assert isinstance(model.schedule, WeeklySchedule)
    assert model.schedule.day == 3


def test_schedule_weekly_default_friday() -> None:
    spec = _minimal_portfolio_spec(schedule={"type": "weekly"})
    model = PortfolioStrategySpec.model_validate(spec)
    assert model.schedule.day == 4


def test_schedule_weekly_out_of_range_rejected() -> None:
    spec = _minimal_portfolio_spec(schedule={"type": "weekly", "day": 7})
    with pytest.raises(ValidationError, match="weekly day must be 0..6"):
        PortfolioStrategySpec.model_validate(spec)


def test_schedule_monthly_first() -> None:
    spec = _minimal_portfolio_spec(schedule={"type": "monthly", "when": "first"})
    model = PortfolioStrategySpec.model_validate(spec)
    assert isinstance(model.schedule, MonthlySchedule)
    assert model.schedule.when == "first"
    assert model.schedule.day is None


def test_schedule_monthly_last() -> None:
    spec = _minimal_portfolio_spec(schedule={"type": "monthly", "when": "last"})
    model = PortfolioStrategySpec.model_validate(spec)
    assert model.schedule.when == "last"


def test_schedule_monthly_day_n() -> None:
    spec = _minimal_portfolio_spec(schedule={"type": "monthly", "day": 15})
    model = PortfolioStrategySpec.model_validate(spec)
    assert model.schedule.day == 15


def test_schedule_monthly_when_and_day_mutually_exclusive() -> None:
    spec = _minimal_portfolio_spec(
        schedule={"type": "monthly", "when": "first", "day": 15}
    )
    with pytest.raises(ValidationError, match="mutually exclusive"):
        PortfolioStrategySpec.model_validate(spec)


def test_schedule_monthly_no_args_defaults_to_first() -> None:
    # Mirrors RebalanceSchedule.monthly() default.
    spec = _minimal_portfolio_spec(schedule={"type": "monthly"})
    model = PortfolioStrategySpec.model_validate(spec)
    assert model.schedule.when == "first"


def test_schedule_monthly_day_out_of_range_rejected() -> None:
    spec = _minimal_portfolio_spec(schedule={"type": "monthly", "day": 32})
    with pytest.raises(ValidationError, match="monthly day must be 1..31"):
        PortfolioStrategySpec.model_validate(spec)


def test_schedule_unknown_type_rejected() -> None:
    spec = _minimal_portfolio_spec(schedule={"type": "biweekly"})
    with pytest.raises(ValidationError):
        PortfolioStrategySpec.model_validate(spec)


# ---------------------------------------------------------------------------
# 7. Stops in portfolio spec (D4 — shared StopsConfig + back-compat shim)
# ---------------------------------------------------------------------------


def test_portfolio_stops_nested_form() -> None:
    spec = _minimal_portfolio_spec(stops={"vol_trailing_multiplier": 2.0})
    model = PortfolioStrategySpec.model_validate(spec)
    assert model.stops is not None
    assert model.stops.vol_trailing_multiplier == 2.0


def test_portfolio_stops_legacy_flat_normalized() -> None:
    # Even portfolio specs accept the flat shape via the same shim.
    spec = _minimal_portfolio_spec(stop_loss_pct=5.0)
    model = PortfolioStrategySpec.model_validate(spec)
    assert model.stops is not None
    assert model.stops.stop_loss_pct == 5.0


def test_portfolio_stops_both_shapes_rejected() -> None:
    spec = _minimal_portfolio_spec(
        stop_loss_pct=5.0,
        stops={"stop_loss_pct": 3.0},
    )
    with pytest.raises(ValidationError, match="Cannot mix flat and nested stops"):
        PortfolioStrategySpec.model_validate(spec)


def test_portfolio_no_stops_returns_none() -> None:
    model = PortfolioStrategySpec.model_validate(_minimal_portfolio_spec())
    assert model.stops is None


# ---------------------------------------------------------------------------
# 8. Full portfolio spec — momentum-rotation example translated from Python
# ---------------------------------------------------------------------------


def test_full_portfolio_spec() -> None:
    spec = {
        "kind": "portfolio",
        "version": "0.4.0",
        "universe": {"min_history": 90},
        "rank": {
            "score": "weighted_metrics",
            "metrics": [
                {"indicator": "roc", "params": {"period": 30}, "output": "value", "weight": 0.25},
                {"indicator": "roc", "params": {"period": 90}, "output": "value", "weight": 0.35},
                {"indicator": "roc", "params": {"period": 180}, "output": "value", "weight": 0.25},
                {"indicator": "roc", "params": {"period": 360}, "output": "value", "weight": 0.15},
            ],
        },
        "select": {"top_n": 3, "direction": "desc"},
        "allocate": {"method": "inverse_volatility", "vol_lookback": 60},
        "schedule": {"type": "monthly", "day": 1},
        "stops": {
            "vol_trailing_multiplier": 2.0,
            "vol_trailing_lookback": 60,
            "vol_trailing_fallback_pct": 10.0,
        },
        "min_drift_pct": 2.0,
        "initial_cash": 1_000_000,
        "commission_pct": 0.05,
        "slippage_pct": 0.02,
        "risk_free_rate": 6.0,
    }
    model = PortfolioStrategySpec.model_validate(spec)
    assert model.universe.min_history == 90
    assert model.rank is not None
    assert len(model.rank.metrics) == 4
    assert model.select.top_n == 3
    assert isinstance(model.allocate, InverseVolatilityAlloc)
    assert isinstance(model.schedule, MonthlySchedule)
    assert model.schedule.day == 1
    assert model.stops.vol_trailing_multiplier == 2.0
    assert model.min_drift_pct == 2.0
    assert model.initial_cash == 1_000_000
