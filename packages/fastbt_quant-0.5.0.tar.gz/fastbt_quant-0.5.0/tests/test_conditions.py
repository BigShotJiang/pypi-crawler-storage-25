"""Focused tests for condition tree evaluation — operators, nesting, edge cases."""

from __future__ import annotations

import math

import pytest

from fastbt.json_strategy import IndicatorCache, _eval_group
from fastbt.schema import (
    Condition,
    ConditionGroup,
    IndicatorRef,
    StrategySpec,
)


def _simple_spec(indicator: str = "sma", period: int = 10) -> dict:
    """Minimal spec that uses a single indicator."""
    ref = {"indicator": indicator, "params": {"period": period}, "output": "value"}
    return {
        "version": "0.0.3",
        "entry": {"all": [{"left": ref, "operator": ">", "right": 0.0}]},
        "exit": {"all": [{"left": ref, "operator": "<", "right": 0.0}]},
    }


class TestOperators:
    """Test each comparison operator."""

    @pytest.fixture(autouse=True)
    def setup(self, synthetic_ohlcv):
        self.data = synthetic_ohlcv
        spec = StrategySpec.model_validate(_simple_spec("sma", 10))
        self.cache = IndicatorCache()
        self.cache.populate(spec, self.data)
        self.ref = IndicatorRef(indicator="sma", params={"period": 10}, output="value")
        # Get the actual SMA value at bar 50 for comparison
        self.val_at_50 = self.cache.get(self.ref, bar_idx=50)

    def _eval_cond(self, operator: str, right: float) -> bool:
        group = ConditionGroup(all=[
            Condition(left=self.ref, operator=operator, right=right)
        ])
        return _eval_group(group, self.cache, bar_idx=50)

    def test_greater_than_true(self):
        assert self._eval_cond(">", self.val_at_50 - 1) is True

    def test_greater_than_false(self):
        assert self._eval_cond(">", self.val_at_50 + 1) is False

    def test_less_than_true(self):
        assert self._eval_cond("<", self.val_at_50 + 1) is True

    def test_less_than_false(self):
        assert self._eval_cond("<", self.val_at_50 - 1) is False

    def test_gte_equal(self):
        assert self._eval_cond(">=", self.val_at_50) is True

    def test_lte_equal(self):
        assert self._eval_cond("<=", self.val_at_50) is True

    def test_eq_true(self):
        assert self._eval_cond("==", self.val_at_50) is True

    def test_eq_false(self):
        assert self._eval_cond("==", self.val_at_50 + 0.01) is False


class TestCrossovers:
    """Test crosses_above and crosses_below operators."""

    @pytest.fixture(autouse=True)
    def setup(self, synthetic_ohlcv):
        self.data = synthetic_ohlcv
        spec_dict = {
            "version": "0.0.3",
            "entry": {
                "all": [
                    {
                        "left": {"indicator": "sma", "params": {"period": 5}, "output": "value"},
                        "operator": "crosses_above",
                        "right": {"indicator": "sma", "params": {"period": 20}, "output": "value"},
                    }
                ]
            },
            "exit": {
                "all": [
                    {
                        "left": {"indicator": "sma", "params": {"period": 5}, "output": "value"},
                        "operator": "crosses_below",
                        "right": {"indicator": "sma", "params": {"period": 20}, "output": "value"},
                    }
                ]
            },
        }
        self.spec = StrategySpec.model_validate(spec_dict)
        self.cache = IndicatorCache()
        self.cache.populate(self.spec, self.data)

    def test_crossover_returns_bool(self):
        for i in range(20, len(self.data)):
            result = _eval_group(self.spec.entry, self.cache, bar_idx=i)
            assert isinstance(result, bool)

    def test_crossover_at_bar_0_false(self):
        assert _eval_group(self.spec.entry, self.cache, bar_idx=0) is False
        assert _eval_group(self.spec.exit, self.cache, bar_idx=0) is False

    def test_crossover_not_both_true_same_bar(self):
        """crosses_above and crosses_below cannot both be True on the same bar."""
        for i in range(len(self.data)):
            entry = _eval_group(self.spec.entry, self.cache, bar_idx=i)
            exit_ = _eval_group(self.spec.exit, self.cache, bar_idx=i)
            assert not (entry and exit_), f"Both entry and exit fired at bar {i}"

    def test_crossover_fires_at_least_once(self):
        """Over 200 bars, at least one crossover should occur."""
        any_entry = any(
            _eval_group(self.spec.entry, self.cache, bar_idx=i)
            for i in range(20, len(self.data))
        )
        any_exit = any(
            _eval_group(self.spec.exit, self.cache, bar_idx=i)
            for i in range(20, len(self.data))
        )
        assert any_entry or any_exit, "No crossovers in 200 bars of synthetic data"


class TestDeepNesting:
    """Test deeply nested condition groups."""

    def test_all_containing_any(self, synthetic_ohlcv):
        spec_dict = _simple_spec("sma", 10)
        spec = StrategySpec.model_validate(spec_dict)
        cache = IndicatorCache()
        cache.populate(spec, synthetic_ohlcv)

        ref = IndicatorRef(indicator="sma", params={"period": 10}, output="value")
        group = ConditionGroup(all=[
            ConditionGroup(any=[
                Condition(left=ref, operator=">", right=0.0),  # true
                Condition(left=ref, operator="<", right=0.0),  # false
            ]),
            Condition(left=ref, operator=">", right=0.0),  # true
        ])
        assert _eval_group(group, cache, bar_idx=50) is True

    def test_any_containing_all_false(self, synthetic_ohlcv):
        spec_dict = _simple_spec("sma", 10)
        spec = StrategySpec.model_validate(spec_dict)
        cache = IndicatorCache()
        cache.populate(spec, synthetic_ohlcv)

        ref = IndicatorRef(indicator="sma", params={"period": 10}, output="value")
        group = ConditionGroup(any=[
            ConditionGroup(all=[
                Condition(left=ref, operator=">", right=0.0),   # true
                Condition(left=ref, operator="<", right=0.0),   # false
            ]),
            Condition(left=ref, operator="<", right=0.0),  # false
        ])
        assert _eval_group(group, cache, bar_idx=50) is False
