"""Tests for JSON reference strategy recipes."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from fastbt import Strategy, backtest

RECIPES_DIR = Path(__file__).parent.parent / "examples" / "recipes"


def _load_recipe(name: str) -> dict:
    path = RECIPES_DIR / f"{name}.json"
    return json.loads(path.read_text())


class TestRecipes:
    @pytest.mark.parametrize("recipe", ["sma_crossover", "rsi_mean_reversion", "bollinger_breakout"])
    def test_recipe_validates(self, recipe):
        """Each recipe should parse without validation errors."""
        spec = _load_recipe(recipe)
        strategy = Strategy.from_json(spec)
        assert strategy is not None

    @pytest.mark.parametrize("recipe", ["sma_crossover", "rsi_mean_reversion", "bollinger_breakout"])
    def test_recipe_runs(self, recipe, synthetic_ohlcv):
        """Each recipe should run through backtest without errors."""
        spec = _load_recipe(recipe)
        strategy = Strategy.from_json(spec)
        result = backtest(strategy, data=synthetic_ohlcv, initial_cash=100_000)
        assert len(result.equity_curve) == len(synthetic_ohlcv)
        assert result.metrics.num_trades >= 0

    def test_sma_crossover_produces_trades(self, synthetic_ohlcv):
        """SMA crossover on 200 bars should produce at least one trade."""
        spec = _load_recipe("sma_crossover")
        strategy = Strategy.from_json(spec)
        result = backtest(strategy, data=synthetic_ohlcv, initial_cash=100_000)
        assert result.metrics.num_trades > 0
