"""Smoke tests for the backtest engine."""

from __future__ import annotations

from fastbt import Strategy, backtest
from fastbt.indicators import sma


class BuyAndHold(Strategy):
    def on_bar(self, ctx):
        if ctx.position.is_flat and len(ctx.history) >= 2:
            qty = int(ctx.cash * 0.95 / ctx.bar.close)
            if qty > 0:
                ctx.buy(qty=qty)


class SmaCross(Strategy):
    def on_bar(self, ctx):
        if len(ctx.history) < 31:
            return
        close = ctx.history["close"]
        fast_now = sma(close, 10).iloc[-1]
        slow_now = sma(close, 30).iloc[-1]
        fast_prev = sma(close, 10).iloc[-2]
        slow_prev = sma(close, 30).iloc[-2]

        if fast_prev <= slow_prev and fast_now > slow_now and ctx.position.is_flat:
            ctx.buy(qty=100)
        elif fast_prev >= slow_prev and fast_now < slow_now and ctx.position.is_long:
            ctx.close()


def test_buy_and_hold_runs(synthetic_ohlcv):
    result = backtest(BuyAndHold(), data=synthetic_ohlcv, initial_cash=100_000)
    assert result.initial_cash == 100_000
    assert len(result.equity_curve) == len(synthetic_ohlcv)
    assert len(result.fills) == 1
    assert result.fills[0].side.value == "buy"


def test_sma_cross_runs(synthetic_ohlcv):
    result = backtest(SmaCross(), data=synthetic_ohlcv, initial_cash=100_000)
    assert result.metrics.num_trades >= 0
    assert result.equity_curve.iloc[0] > 0


def test_repr_is_informative(synthetic_ohlcv):
    result = backtest(BuyAndHold(), data=synthetic_ohlcv, initial_cash=100_000)
    assert "BacktestResult" in repr(result)
    assert "return=" in repr(result)


def test_commission_reduces_equity(synthetic_ohlcv):
    no_comm = backtest(BuyAndHold(), data=synthetic_ohlcv, initial_cash=100_000,
                       commission_pct=0.0)
    with_comm = backtest(BuyAndHold(), data=synthetic_ohlcv, initial_cash=100_000,
                         commission_pct=1.0)
    assert with_comm.equity_curve.iloc[-1] < no_comm.equity_curve.iloc[-1]


def test_fill_policy_next_open_delays_fill(synthetic_ohlcv):
    """Under next_open, first fill price matches the NEXT bar's open."""
    result = backtest(BuyAndHold(), data=synthetic_ohlcv, initial_cash=100_000,
                      fill_policy="next_open", slippage_pct=0.0, commission_pct=0.0)
    first_fill = result.fills[0]
    expected_price = synthetic_ohlcv["open"].iloc[2]
    assert abs(first_fill.price - expected_price) < 1e-6
