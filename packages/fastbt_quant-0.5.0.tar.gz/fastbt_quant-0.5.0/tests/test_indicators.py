"""Tests for all indicators (v0.0.1 + v0.0.2)."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from fastbt import indicators as ind


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _short_ohlcv(n: int = 5) -> pd.DataFrame:
    """Return a tiny OHLCV DataFrame for short-series tests."""
    rng = np.random.default_rng(99)
    close = 100 + rng.standard_normal(n).cumsum()
    high = close + np.abs(rng.standard_normal(n))
    low = close - np.abs(rng.standard_normal(n))
    volume = rng.integers(1000, 5000, n).astype(float)
    return pd.DataFrame({"high": high, "low": low, "close": close, "volume": volume})


# ---------------------------------------------------------------------------
# v0.0.1 indicators — basic sanity
# ---------------------------------------------------------------------------

class TestSMA:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.sma(synthetic_ohlcv["close"], 20)
        assert isinstance(result, pd.Series)

    def test_short_series(self) -> None:
        df = _short_ohlcv(5)
        result = ind.sma(df["close"], 20)
        assert isinstance(result, pd.Series)
        assert result.notna().sum() == 0  # not enough data


class TestEMA:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.ema(synthetic_ohlcv["close"], 20)
        assert isinstance(result, pd.Series)


class TestRSI:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.rsi(synthetic_ohlcv["close"])
        assert isinstance(result, pd.Series)

    def test_range(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.rsi(synthetic_ohlcv["close"]).dropna()
        assert (result >= 0).all() and (result <= 100).all()


class TestMACD:
    def test_returns_dataframe(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.macd(synthetic_ohlcv["close"])
        assert isinstance(result, pd.DataFrame)
        assert list(result.columns) == ["macd", "signal", "histogram"]


class TestBollingerBands:
    def test_returns_dataframe(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.bollinger_bands(synthetic_ohlcv["close"])
        assert isinstance(result, pd.DataFrame)
        assert set(result.columns) == {"middle", "upper", "lower"}


class TestATR:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.atr(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"], synthetic_ohlcv["close"]
        )
        assert isinstance(result, pd.Series)


# ---------------------------------------------------------------------------
# v0.0.2 indicators
# ---------------------------------------------------------------------------

class TestStochastic:
    def test_returns_dataframe(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.stochastic(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"], synthetic_ohlcv["close"]
        )
        assert isinstance(result, pd.DataFrame)
        assert list(result.columns) == ["k", "d"]

    def test_range(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.stochastic(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"], synthetic_ohlcv["close"]
        )
        k = result["k"].dropna()
        assert (k >= 0).all() and (k <= 100).all()

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.stochastic(df["high"], df["low"], df["close"])
        assert isinstance(result, pd.DataFrame)


class TestADX:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.adx(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"], synthetic_ohlcv["close"]
        )
        assert isinstance(result, pd.Series)

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.adx(df["high"], df["low"], df["close"])
        assert isinstance(result, pd.Series)


class TestCCI:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.cci(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"], synthetic_ohlcv["close"]
        )
        assert isinstance(result, pd.Series)

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.cci(df["high"], df["low"], df["close"])
        assert isinstance(result, pd.Series)


class TestOBV:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.obv(synthetic_ohlcv["close"], synthetic_ohlcv["volume"])
        assert isinstance(result, pd.Series)

    def test_short_series(self) -> None:
        df = _short_ohlcv(2)
        result = ind.obv(df["close"], df["volume"])
        assert isinstance(result, pd.Series)


class TestVWAP:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.vwap(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"],
            synthetic_ohlcv["close"], synthetic_ohlcv["volume"],
        )
        assert isinstance(result, pd.Series)

    def test_short_series(self) -> None:
        df = _short_ohlcv(2)
        result = ind.vwap(df["high"], df["low"], df["close"], df["volume"])
        assert isinstance(result, pd.Series)


class TestSupertrend:
    def test_returns_dataframe(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.supertrend(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"], synthetic_ohlcv["close"]
        )
        assert isinstance(result, pd.DataFrame)
        assert list(result.columns) == ["supertrend", "direction"]

    def test_direction_values(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.supertrend(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"], synthetic_ohlcv["close"]
        )
        vals = result["direction"].dropna().unique()
        assert set(vals).issubset({-1, 1})

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.supertrend(df["high"], df["low"], df["close"])
        assert isinstance(result, pd.DataFrame)


class TestDonchian:
    def test_returns_dataframe(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.donchian(synthetic_ohlcv["high"], synthetic_ohlcv["low"])
        assert isinstance(result, pd.DataFrame)
        assert list(result.columns) == ["upper", "lower", "middle"]

    def test_upper_gte_lower(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.donchian(synthetic_ohlcv["high"], synthetic_ohlcv["low"])
        valid = result.dropna()
        assert (valid["upper"] >= valid["lower"]).all()

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.donchian(df["high"], df["low"])
        assert isinstance(result, pd.DataFrame)


class TestKeltner:
    def test_returns_dataframe(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.keltner(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"], synthetic_ohlcv["close"]
        )
        assert isinstance(result, pd.DataFrame)
        assert list(result.columns) == ["upper", "middle", "lower"]

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.keltner(df["high"], df["low"], df["close"])
        assert isinstance(result, pd.DataFrame)


class TestIchimoku:
    def test_returns_dataframe(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.ichimoku(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"], synthetic_ohlcv["close"]
        )
        assert isinstance(result, pd.DataFrame)
        assert list(result.columns) == [
            "tenkan_sen", "kijun_sen", "senkou_a", "senkou_b",
        ]

    def test_short_series(self) -> None:
        df = _short_ohlcv(5)
        result = ind.ichimoku(df["high"], df["low"], df["close"])
        assert isinstance(result, pd.DataFrame)


class TestWilliamsR:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.williams_r(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"], synthetic_ohlcv["close"]
        )
        assert isinstance(result, pd.Series)

    def test_range(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.williams_r(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"], synthetic_ohlcv["close"]
        ).dropna()
        assert (result >= -100).all() and (result <= 0).all()

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.williams_r(df["high"], df["low"], df["close"])
        assert isinstance(result, pd.Series)


class TestMFI:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.mfi(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"],
            synthetic_ohlcv["close"], synthetic_ohlcv["volume"],
        )
        assert isinstance(result, pd.Series)

    def test_range(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.mfi(
            synthetic_ohlcv["high"], synthetic_ohlcv["low"],
            synthetic_ohlcv["close"], synthetic_ohlcv["volume"],
        ).dropna()
        assert (result >= 0).all() and (result <= 100).all()

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.mfi(df["high"], df["low"], df["close"], df["volume"])
        assert isinstance(result, pd.Series)


class TestROC:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.roc(synthetic_ohlcv["close"])
        assert isinstance(result, pd.Series)

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.roc(df["close"])
        assert isinstance(result, pd.Series)


class TestTRIX:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.trix(synthetic_ohlcv["close"])
        assert isinstance(result, pd.Series)

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.trix(df["close"])
        assert isinstance(result, pd.Series)


class TestKAMA:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.kama(synthetic_ohlcv["close"])
        assert isinstance(result, pd.Series)

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.kama(df["close"])
        assert isinstance(result, pd.Series)


class TestPctFromSMA:
    def test_returns_series(self, synthetic_ohlcv: pd.DataFrame) -> None:
        result = ind.pct_from_sma(synthetic_ohlcv["close"], period=20)
        assert isinstance(result, pd.Series)

    def test_zero_when_price_equals_sma(self) -> None:
        flat = pd.Series([100.0] * 30)
        result = ind.pct_from_sma(flat, period=10)
        # After warm-up, price == SMA == 100, so pct == 0
        assert result.iloc[-1] == 0.0

    def test_positive_when_price_above_sma(self) -> None:
        # Steadily rising prices: latest price is above any rolling mean
        rising = pd.Series([100.0 + i for i in range(30)])
        result = ind.pct_from_sma(rising, period=10)
        assert result.iloc[-1] > 0

    def test_negative_when_price_below_sma(self) -> None:
        # Steadily falling prices: latest price is below the rolling mean
        falling = pd.Series([100.0 - i for i in range(30)])
        result = ind.pct_from_sma(falling, period=10)
        assert result.iloc[-1] < 0

    def test_nan_for_insufficient_history(self) -> None:
        result = ind.pct_from_sma(pd.Series([100.0] * 5), period=10)
        # First 9 values should be NaN; we only have 5 values total
        assert result.isna().all()

    def test_nan_warmup_then_value(self) -> None:
        result = ind.pct_from_sma(pd.Series([100.0] * 30), period=10)
        # First 9 values NaN (need 10 for SMA), 10th onward valid
        assert result.iloc[:9].isna().all()
        assert result.iloc[9:].notna().all()

    def test_short_series(self) -> None:
        df = _short_ohlcv(3)
        result = ind.pct_from_sma(df["close"], period=20)
        assert isinstance(result, pd.Series)
        assert result.notna().sum() == 0
