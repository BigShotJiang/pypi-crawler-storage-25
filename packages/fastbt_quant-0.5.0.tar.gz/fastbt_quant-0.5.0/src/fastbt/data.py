"""idata.fyi API client for fetching OHLCV equity data."""

from __future__ import annotations

import os
import time

import pandas as pd

from fastbt.validators import validate_ohlcv

# ── Constants ────────────────────────────────────────────────────────────

BASE_URL = "https://idata.fyi"
AUTH_ENDPOINT = "/auth/token"
SERIES_ENDPOINT = "/api/data/series/equity/{symbol}"
DEFAULT_LIMIT = 10_000
TOKEN_REFRESH_MARGIN = 300  # refresh 5 min before expiry


# ── Exceptions ───────────────────────────────────────────────────────────


class IdataError(Exception):
    """Base error for idata.fyi operations."""


class IdataAuthError(IdataError):
    """Authentication failure (missing key, invalid key, expired)."""


class IdataAPIError(IdataError):
    """Non-200 API response."""

    def __init__(self, message: str, status_code: int | None = None):
        self.status_code = status_code
        super().__init__(message)


# ── Client ───────────────────────────────────────────────────────────────


class IdataClient:
    """Synchronous client for the idata.fyi equity data API.

    Usage::

        client = IdataClient()                    # reads IDATA_API_KEY from env
        df = client.fetch_ohlcv("SBIN")           # single symbol
        data = client.fetch_universe(["SBIN", "RELIANCE"])  # multiple symbols
    """

    def __init__(self, api_key: str | None = None, base_url: str = BASE_URL) -> None:
        try:
            import requests  # noqa: F811
        except ImportError:
            raise ImportError(
                "requests is required for idata.fyi integration. "
                "Install with: pip install fastbt-quant[data]"
            ) from None

        if api_key is None:
            api_key = os.environ.get("IDATA_API_KEY")
        if api_key is None:
            from fastbt.config import get as config_get

            api_key = config_get("idata", "api_key")
        if not api_key:
            raise IdataAuthError(
                "No idata API key found. Set it with one of:\n"
                "  fastbt config set idata-api-key <your-key>\n"
                "  export IDATA_API_KEY=<your-key>\n"
                "  IdataClient(api_key=<your-key>)"
            )

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._session = requests.Session()
        self._token: str | None = None
        self._token_expires_at: float = 0.0

    def _ensure_token(self) -> str:
        """Authenticate and return a valid JWT, using cache when possible."""
        if self._token and time.time() < self._token_expires_at - TOKEN_REFRESH_MARGIN:
            return self._token

        resp = self._session.post(
            f"{self._base_url}{AUTH_ENDPOINT}",
            headers={"X-API-Key": self._api_key},
        )
        if resp.status_code != 200:
            raise IdataAuthError(
                f"Authentication failed (HTTP {resp.status_code}): {resp.text}"
            )

        body = resp.json()
        self._token = body["access_token"]
        self._token_expires_at = time.time() + body.get("expires_in", 28800)
        return self._token  # type: ignore[return-value]

    def fetch_ohlcv(self, symbol: str) -> pd.DataFrame:
        """Fetch full OHLCV history for a symbol, returning a validated DataFrame."""
        rows = self._fetch_pages(symbol)
        if not rows:
            raise IdataAPIError(f"No data returned for symbol '{symbol}'")

        df = pd.DataFrame(rows)
        df["trade_date"] = pd.to_datetime(df["trade_date"])
        df = df.drop_duplicates(subset=["trade_date"])
        df = df.set_index("trade_date").sort_index()

        # Keep only standard OHLCV columns
        ohlcv = df[["open", "high", "low", "close", "volume"]].copy()
        ohlcv = ohlcv.dropna()

        validate_ohlcv(ohlcv)
        return ohlcv

    def fetch_universe(self, symbols: list[str]) -> dict[str, pd.DataFrame]:
        """Fetch OHLCV data for multiple symbols."""
        return {sym: self.fetch_ohlcv(sym) for sym in symbols}

    def _fetch_pages(self, symbol: str) -> list[dict]:
        """Paginate through the series endpoint, returning all rows."""
        all_rows: list[dict] = []
        offset = 0
        retried_auth = False

        while True:
            token = self._ensure_token()
            resp = self._session.get(
                f"{self._base_url}{SERIES_ENDPOINT.format(symbol=symbol)}",
                params={
                    "sort": "trade_date",
                    "order": "asc",
                    "limit": DEFAULT_LIMIT,
                    "offset": offset,
                    "format": "json",
                },
                headers={"Authorization": f"Bearer {token}", "accept": "application/json"},
            )

            # 401 — token may have expired mid-fetch, retry once
            if resp.status_code == 401 and not retried_auth:
                self._token = None
                retried_auth = True
                continue

            # 429 — rate limited
            if resp.status_code == 429:
                wait = float(resp.headers.get("Retry-After", "2"))
                time.sleep(wait)
                continue

            if resp.status_code != 200:
                raise IdataAPIError(
                    f"API error for {symbol} (HTTP {resp.status_code}): {resp.text}",
                    status_code=resp.status_code,
                )

            body = resp.json()
            batch = body.get("data", [])
            all_rows.extend(batch)

            if len(batch) < DEFAULT_LIMIT:
                break
            offset += DEFAULT_LIMIT
            retried_auth = False  # reset for next page

        return all_rows
