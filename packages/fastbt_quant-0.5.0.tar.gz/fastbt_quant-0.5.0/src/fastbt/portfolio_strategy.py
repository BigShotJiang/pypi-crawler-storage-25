"""Portfolio strategy base class — user strategies subclass this."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastbt.portfolio_context import PortfolioContext


class PortfolioStrategy:
    """Base class for portfolio/basket strategies.

    **Simple usage** — override ``on_rebalance`` directly::

        class EqualWeight(PortfolioStrategy):
            def on_rebalance(self, ctx):
                n = len(ctx.symbols)
                w = 1.0 / n if n > 0 else 0.0
                return {s: w for s in ctx.symbols}

    **Pipeline usage** — override individual lifecycle methods::

        class MomentumTop10(PortfolioStrategy):
            def universe(self, ctx):
                return [s for s in ctx.symbols
                        if ctx.bars[s].volume > 100_000]

            def rank(self, ctx, universe):
                scores = []
                for sym in universe:
                    hist = ctx.history[sym]["close"]
                    ret = (hist.iloc[-1] / hist.iloc[-252] - 1
                           if len(hist) >= 252 else 0.0)
                    scores.append((sym, ret))
                return sorted(scores, key=lambda x: x[1], reverse=True)

            def select(self, ctx, ranked):
                return [sym for sym, _ in ranked[:10]]

            def allocate(self, ctx, selected):
                w = 1.0 / len(selected) if selected else 0.0
                return {s: w for s in selected}

    When ``on_rebalance`` is not overridden, the base class chains
    ``universe -> rank -> select -> allocate`` automatically. If
    ``universe`` returns an empty list, the pipeline short-circuits
    and returns ``{}`` (all cash).
    """

    def __init__(self, params: dict | None = None):
        self.params: dict = params or {}

    def initialize(self, ctx: PortfolioContext) -> None:
        """Called once before the first bar."""

    def stop_config(self) -> dict | None:
        """Return per-symbol stop configuration as a dict, or None for no stops.

        Recognized keys: ``stop_loss_pct``, ``stop_loss_points``,
        ``take_profit_pct``, ``take_profit_points``, ``trailing_stop_pct``,
        ``trailing_stop_points``, ``vol_trailing_multiplier``,
        ``vol_trailing_lookback``, ``vol_trailing_fallback_pct``.

        Explicit kwargs passed to ``portfolio_backtest()`` take precedence
        over values returned here (mirrors the single-symbol pattern).
        """
        return None

    def on_rebalance(self, ctx: PortfolioContext) -> dict[str, float]:
        """Return target portfolio weights.

        Override this directly for simple strategies. If not overridden,
        the base class runs the lifecycle pipeline:
        ``universe() -> rank() -> select() -> allocate()``.

        If ``universe()`` returns an empty list, returns ``{}`` immediately
        (go to all cash / exit all positions).
        """
        univ = self.universe(ctx)
        if not univ:
            return {}
        ranked = self.rank(ctx, univ)
        selected = self.select(ctx, ranked)
        return self.allocate(ctx, selected)

    def universe(self, ctx: PortfolioContext) -> list[str]:
        """Which symbols are eligible this rebalance. Default: all symbols."""
        return list(ctx.symbols)

    def rank(
        self, ctx: PortfolioContext, universe: list[str]
    ) -> list[tuple[str, float]]:
        """Score/rank eligible symbols. Default: equal score, input order."""
        return [(sym, 1.0) for sym in universe]

    def select(
        self, ctx: PortfolioContext, ranked: list[tuple[str, float]]
    ) -> list[str]:
        """Pick symbols from the ranked list. Default: select all."""
        return [sym for sym, _score in ranked]

    def allocate(
        self, ctx: PortfolioContext, selected: list[str]
    ) -> dict[str, float]:
        """Assign weights to selected symbols.

        Must return a dict ``{symbol: weight}`` where weights are
        non-negative and sum to at most 1.0.

        **Must be overridden** when using the lifecycle pipeline
        (i.e., not overriding ``on_rebalance`` directly).
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement allocate() or on_rebalance()"
        )
