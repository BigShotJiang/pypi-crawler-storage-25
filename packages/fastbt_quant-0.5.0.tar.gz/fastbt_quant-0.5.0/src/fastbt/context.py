"""Execution context passed to strategy callbacks."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from fastbt.types import Bar, OrderId, OrderSide, Position

if TYPE_CHECKING:
    from fastbt.broker import Broker


class Context:
    """Runtime context for a strategy.

    Provides:
      - `bar` — the current bar (open/high/low/close/volume + timestamp).
      - `history` — all bars up to and including the current bar.
      - `position` / `cash` / `equity` — account state via the attached broker.
      - `buy` / `sell` / `close` — order submission helpers.

    The engine mutates `bar` and `history` between bars; strategy code reads them.
    """

    def __init__(
        self,
        symbol: str,
        bar: Bar,
        history: pd.DataFrame,
        params: dict,
        broker: Broker,
        full_data: pd.DataFrame | None = None,
    ):
        self.symbol = symbol
        self.bar = bar
        self.history = history
        self.params = params
        self._broker = broker
        self.full_data: pd.DataFrame = full_data if full_data is not None else history

    @property
    def position(self) -> Position:
        return self._broker.position(self.symbol)

    @property
    def cash(self) -> float:
        return self._broker.cash()

    @property
    def equity(self) -> float:
        return self._broker.equity({self.symbol: self.bar.close})

    @property
    def now(self) -> pd.Timestamp:
        return self.bar.timestamp

    def buy(self, qty: float) -> OrderId:
        """Submit a market buy order for `qty` units."""
        if qty <= 0:
            raise ValueError(f"buy qty must be positive, got {qty}")
        return self._broker.submit_market(self.symbol, OrderSide.BUY, qty, self.bar.timestamp)

    def sell(self, qty: float) -> OrderId:
        """Submit a market sell order for `qty` units."""
        if qty <= 0:
            raise ValueError(f"sell qty must be positive, got {qty}")
        return self._broker.submit_market(self.symbol, OrderSide.SELL, qty, self.bar.timestamp)

    def close(self) -> OrderId | None:
        """Close the entire current position via a market order. Returns None if flat."""
        pos = self.position
        if pos.is_flat:
            return None
        if pos.is_long:
            return self.sell(pos.qty)
        return self.buy(-pos.qty)
