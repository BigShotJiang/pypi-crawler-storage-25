"""Signal types for live signal mode."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from enum import Enum

from fastbt.types import Position


class SignalType(str, Enum):
    """Type of signal emitted by the signal engine."""

    ENTRY_LONG = "entry_long"
    ENTRY_SHORT = "entry_short"
    EXIT_SIGNAL = "exit_signal"
    STOP_LOSS_HIT = "stop_loss_hit"
    TAKE_PROFIT_HIT = "take_profit_hit"
    TRAILING_STOP_HIT = "trailing_stop_hit"
    POSITION_UPDATE = "position_update"
    NO_ACTION = "no_action"


@dataclass(frozen=True, slots=True)
class PositionState:
    """Snapshot of position state included in signal payloads."""

    qty: float
    avg_entry_price: float
    unrealized_pnl: float
    side: str  # "long", "short", "flat"

    @classmethod
    def from_position(cls, pos: Position, current_price: float) -> PositionState:
        if pos.is_long:
            side = "long"
        elif pos.is_short:
            side = "short"
        else:
            side = "flat"
        return cls(
            qty=pos.qty,
            avg_entry_price=pos.avg_entry_price,
            unrealized_pnl=pos.unrealized_pnl(current_price),
            side=side,
        )


@dataclass(frozen=True, slots=True)
class SignalPayload:
    """Signal emitted by the signal engine on each bar."""

    version: str
    type: SignalType
    symbol: str
    timestamp: str  # ISO 8601
    bar: dict
    position: PositionState
    reason: str
    side: str | None = None  # "buy" / "sell" / None for NO_ACTION
    qty: float | None = None
    price: float | None = None

    def to_dict(self) -> dict:
        """Convert to a plain dict suitable for JSON serialization."""
        d = asdict(self)
        d["type"] = self.type.value
        return d

    def to_json(self) -> str:
        """Serialize to a JSON string."""
        return json.dumps(self.to_dict())
