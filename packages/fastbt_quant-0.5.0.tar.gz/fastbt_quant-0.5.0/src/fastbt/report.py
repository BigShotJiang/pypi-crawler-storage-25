"""Tearsheet generation via QuantStats (optional dependency)."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from fastbt.result import BacktestResult


def tearsheet(
    result: BacktestResult,
    output_path: str,
    benchmark: pd.Series | None = None,
) -> None:
    """Generate an HTML tearsheet using QuantStats.

    Converts the equity curve to a returns series and passes it to
    QuantStats for rendering. The output is a self-contained HTML file.

    Args:
        result: BacktestResult with equity_curve (pd.Series, DatetimeIndex, float values).
        output_path: Path to write the self-contained HTML file.
        benchmark: Optional benchmark returns series for comparison.

    Raises:
        ImportError: If QuantStats is not installed.
        ValueError: If the equity curve is flat (all returns are zero).

    Note:
        QuantStats assumes 252 trading days/year for annualized metrics
        (Sharpe, Sortino, etc.). This is standard for US equities but
        may differ for crypto (365) or other markets.

    Requires: pip install fastbt-quant[report]
    """
    try:
        import quantstats as qs
    except ImportError:
        raise ImportError(
            "QuantStats is required for tearsheet generation. "
            "Install with: pip install fastbt-quant[report]"
        )

    returns = result.equity_curve.pct_change().dropna()

    if len(returns) == 0 or (returns == 0).all():
        raise ValueError(
            "Equity curve is flat — no returns to chart. "
            "The backtest may have produced no trades."
        )

    qs.reports.html(returns, benchmark=benchmark, output=output_path)
