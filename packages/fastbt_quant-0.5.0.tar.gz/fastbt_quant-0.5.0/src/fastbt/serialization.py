"""Save and load backtest results to/from JSON."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

import pandas as pd

from fastbt.portfolio_result import PortfolioResult
from fastbt.result import BacktestResult, Metrics
from fastbt.types import Fill, OrderSide


def _get_version() -> str:
    from fastbt import __version__

    return __version__


def save_result(result: BacktestResult | PortfolioResult, path: str) -> None:
    """Save a BacktestResult or PortfolioResult to a JSON file."""
    data: dict = {
        "version": _get_version(),
        "result_type": "portfolio" if isinstance(result, PortfolioResult) else "backtest",
        "initial_cash": result.initial_cash,
        "final_cash": result.final_cash,
        "metrics": asdict(result.metrics),
        "fills": [_fill_to_dict(f) for f in result.fills],
        "equity_curve": {
            "timestamps": [t.isoformat() for t in result.equity_curve.index],
            "values": result.equity_curve.values.tolist(),
        },
    }
    if isinstance(result, PortfolioResult):
        data["weight_history"] = {
            "timestamps": [t.isoformat() for t in result.weight_history.index],
            "columns": result.weight_history.columns.tolist(),
            "values": result.weight_history.values.tolist(),
        }
        data["per_symbol_pnl"] = result.per_symbol_pnl
        data["turnover"] = result.turnover

    Path(path).write_text(json.dumps(data, indent=2))


def load_result(path: str) -> BacktestResult | PortfolioResult:
    """Load a BacktestResult or PortfolioResult from a JSON file.

    Raises ValueError if the file version doesn't match the current fastbt version.
    """
    text = Path(path).read_text()
    data = json.loads(text)

    current_version = _get_version()
    file_version = data.get("version")
    if file_version != current_version:
        raise ValueError(
            f"Result file version '{file_version}' does not match "
            f"current fastbt version '{current_version}'"
        )

    equity_curve = pd.Series(
        data["equity_curve"]["values"],
        index=pd.DatetimeIndex(pd.to_datetime(data["equity_curve"]["timestamps"])),
        name="equity",
    )
    fills = [_dict_to_fill(d) for d in data["fills"]]
    metrics = Metrics(**data["metrics"])

    if data.get("result_type") == "portfolio":
        wh = data["weight_history"]
        weight_history = pd.DataFrame(
            wh["values"],
            index=pd.DatetimeIndex(pd.to_datetime(wh["timestamps"])),
            columns=wh["columns"],
        )
        return PortfolioResult(
            equity_curve=equity_curve,
            fills=fills,
            metrics=metrics,
            initial_cash=data["initial_cash"],
            final_cash=data["final_cash"],
            weight_history=weight_history,
            per_symbol_pnl=data["per_symbol_pnl"],
            turnover=data["turnover"],
        )

    return BacktestResult(
        equity_curve=equity_curve,
        fills=fills,
        metrics=metrics,
        initial_cash=data["initial_cash"],
        final_cash=data["final_cash"],
    )


def _fill_to_dict(fill: Fill) -> dict:
    return {
        "order_id": str(fill.order_id),
        "symbol": fill.symbol,
        "side": fill.side.value,
        "qty": fill.qty,
        "price": fill.price,
        "timestamp": fill.timestamp.isoformat(),
        "commission": fill.commission,
    }


def _dict_to_fill(d: dict) -> Fill:
    return Fill(
        order_id=d["order_id"],
        symbol=d["symbol"],
        side=OrderSide(d["side"]),
        qty=d["qty"],
        price=d["price"],
        timestamp=pd.Timestamp(d["timestamp"]),
        commission=d.get("commission", 0.0),
    )
