"""JSON declarative strategy — evaluate conditions from a JSON spec.

Architecture:
                    Strategy.from_json(spec)
                           │
                           ▼
              ┌─────────────────────────┐
              │   Pydantic Validation   │
              │  StrategySpec model     │
              └───────────┬─────────────┘
                          │
                          ▼
              ┌─────────────────────────┐
              │    JsonStrategy         │
              │  (subclasses Strategy)  │
              │                         │
              │  initialize(ctx):       │
              │    pre-compute all      │
              │    indicators into      │
              │    IndicatorCache       │
              │                         │
              │  on_bar(ctx):           │
              │    1. eval exit tree    │
              │    2. eval entry tree   │
              │    3. apply sizing      │
              │    4. ctx.buy/sell/close│
              └───────────┬─────────────┘
                          │
                          ▼
              ┌─────────────────────────┐
              │   IndicatorCache        │
              │  get(name, output, idx) │
              │  Pre-computed in        │
              │  backtest mode.         │
              │  Swap to incremental    │
              │  for live mode (v0.2.0) │
              └─────────────────────────┘

Exit takes priority over entry on the same bar.
NaN during warmup → condition evaluates to False.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import pandas as pd

from fastbt.registry import IndicatorMeta, default_registry
from fastbt.schema import ConditionGroup, IndicatorRef, StrategySpec
from fastbt.strategy import Strategy

if TYPE_CHECKING:
    from fastbt.context import Context
    from fastbt.schema import Condition


class IndicatorCache:
    """Pre-computed indicator values indexed by bar position.

    In backtest mode, all indicators are computed once over the full DataFrame
    in populate(). The evaluator calls get() with a bar index to look up values.

    For live mode (v0.2.0), swap this to an incremental implementation that
    computes values as new bars arrive. The evaluator code stays identical.
    """

    def __init__(self) -> None:
        # key: (indicator_name, param_key, output_name) → pd.Series
        self._cache: dict[tuple[str, str, str], pd.Series] = {}

    def populate(
        self,
        spec: StrategySpec,
        data: pd.DataFrame,
    ) -> None:
        """Pre-compute all indicators referenced in the spec."""
        refs = _collect_indicator_refs(spec)
        for ref in refs:
            cache_key = _cache_key(ref)
            if cache_key in self._cache:
                continue
            meta = default_registry.get(ref.indicator)
            series = self._compute(meta, ref, data)
            self._cache[cache_key] = series

    def get(self, ref: IndicatorRef, bar_idx: int) -> float:
        """Get indicator value at bar_idx + ref.offset. Returns NaN if out of bounds."""
        cache_key = _cache_key(ref)
        series = self._cache[cache_key]
        idx = bar_idx + ref.offset
        if idx < 0 or idx >= len(series):
            return float("nan")
        return float(series.iloc[idx])

    def _compute(
        self,
        meta: IndicatorMeta,
        ref: IndicatorRef,
        data: pd.DataFrame,
    ) -> pd.Series:
        """Compute a single indicator and extract the requested output."""
        params = {k: v for k, v in ref.params.items()}
        # Fill in defaults for missing params
        for k, v in meta.param_schema.items():
            if k not in params:
                params[k] = v

        if meta.input_type == "series":
            input_series = _resolve_source(data, ref.source)
            result = meta.fn(input_series, **params)
        else:
            # ohlcv input — pass the columns the function needs
            result = _call_ohlcv_indicator(meta, data, params)

        if meta.output_type == "series":
            return result
        else:
            # multi-output → extract the named column
            return result[ref.output]


def _resolve_source(data: pd.DataFrame, source: str) -> pd.Series:
    """Resolve a source name to a pandas Series from the OHLCV DataFrame."""
    if source == "hlc3":
        return (data["high"] + data["low"] + data["close"]) / 3
    if source == "ohlc4":
        return (data["open"] + data["high"] + data["low"] + data["close"]) / 4
    return data[source]


def _call_ohlcv_indicator(
    meta: IndicatorMeta,
    data: pd.DataFrame,
    params: dict,
) -> pd.Series | pd.DataFrame:
    """Call an OHLCV-input indicator by inspecting its function signature."""
    import inspect

    sig = inspect.signature(meta.fn)
    args = {}
    ohlcv_cols = {"high", "low", "close", "volume", "open"}
    for pname in sig.parameters:
        if pname in ohlcv_cols:
            args[pname] = data[pname]
        elif pname in params:
            args[pname] = params[pname]
    return meta.fn(**args)


def _cache_key(ref: IndicatorRef) -> tuple[str, str, str]:
    """Create a hashable cache key from an indicator reference."""
    # Include source + params so sma(close, 10) != sma(open, 10)
    param_key = f"{ref.source}:{_param_str(ref.params)}"
    return (ref.indicator, param_key, ref.output)


def _param_str(params: dict) -> str:
    return ",".join(f"{k}={v}" for k, v in sorted(params.items()))


def _collect_indicator_refs(spec: StrategySpec) -> list[IndicatorRef]:
    """Walk the spec and collect all unique IndicatorRef instances."""
    refs: list[IndicatorRef] = []
    _walk_group(spec.entry, refs)
    _walk_group(spec.exit, refs)
    return refs


def _walk_group(group: ConditionGroup, refs: list[IndicatorRef]) -> None:
    items = group.all if group.all is not None else group.any or []
    for item in items:
        if isinstance(item, ConditionGroup):
            _walk_group(item, refs)
        else:
            _walk_condition(item, refs)


def _walk_condition(cond: Condition, refs: list[IndicatorRef]) -> None:
    if isinstance(cond.left, IndicatorRef):
        refs.append(cond.left)
    if isinstance(cond.right, IndicatorRef):
        refs.append(cond.right)


# ---------------------------------------------------------------------------
# Condition evaluation
# ---------------------------------------------------------------------------


def _eval_group(group: ConditionGroup, cache: IndicatorCache, bar_idx: int) -> bool:
    """Evaluate a condition group at the given bar index."""
    if group.all is not None:
        return all(_eval_item(item, cache, bar_idx) for item in group.all)
    else:
        items = group.any or []
        return any(_eval_item(item, cache, bar_idx) for item in items)


def _eval_item(
    item: Condition | ConditionGroup,
    cache: IndicatorCache,
    bar_idx: int,
) -> bool:
    if isinstance(item, ConditionGroup):
        return _eval_group(item, cache, bar_idx)
    return _eval_condition(item, cache, bar_idx)


def _eval_condition(cond: Condition, cache: IndicatorCache, bar_idx: int) -> bool:
    """Evaluate a single condition at bar_idx."""
    left = _resolve_value(cond.left, cache, bar_idx)
    right = _resolve_value(cond.right, cache, bar_idx)

    # NaN during warmup → condition is False
    if math.isnan(left) or math.isnan(right):
        return False

    op = cond.operator

    if op == "crosses_above":
        return _eval_crossover(cond, cache, bar_idx, direction="above")
    if op == "crosses_below":
        return _eval_crossover(cond, cache, bar_idx, direction="below")

    if op == ">":
        return left > right
    if op == "<":
        return left < right
    if op == ">=":
        return left >= right
    if op == "<=":
        return left <= right
    if op == "==":
        return left == right

    return False


def _eval_crossover(
    cond: Condition,
    cache: IndicatorCache,
    bar_idx: int,
    direction: str,
) -> bool:
    """Evaluate crosses_above / crosses_below."""
    if bar_idx < 1:
        return False

    curr_left = _resolve_value(cond.left, cache, bar_idx)
    curr_right = _resolve_value(cond.right, cache, bar_idx)
    prev_left = _resolve_value(cond.left, cache, bar_idx - 1)
    prev_right = _resolve_value(cond.right, cache, bar_idx - 1)

    if any(math.isnan(v) for v in [curr_left, curr_right, prev_left, prev_right]):
        return False

    if direction == "above":
        return prev_left <= prev_right and curr_left > curr_right
    else:
        return prev_left >= prev_right and curr_left < curr_right


def _resolve_value(
    operand: IndicatorRef | float,
    cache: IndicatorCache,
    bar_idx: int,
) -> float:
    """Resolve an operand to a float value."""
    if isinstance(operand, (int, float)):
        return float(operand)
    return cache.get(operand, bar_idx)


# ---------------------------------------------------------------------------
# Position sizing
# ---------------------------------------------------------------------------


def _compute_qty(
    spec: StrategySpec,
    price: float,
    cash: float,
) -> int:
    """Compute order quantity from the spec's position_sizing. Clamps to available cash."""
    sizing = spec.position_sizing
    method = sizing.method

    if method == "fixed_qty":
        raw_qty = sizing.qty or 0
    elif method == "percent_equity":
        pct = (sizing.pct or 0) / 100.0
        raw_qty = (cash * pct) / price if price > 0 else 0
    elif method == "fixed_cash":
        amount = sizing.amount or 0
        raw_qty = amount / price if price > 0 else 0
    elif method == "risk_pct":
        risk_amount = cash * (sizing.risk_fraction or 0)
        stop_dist = _stop_distance(spec, price)
        raw_qty = risk_amount / stop_dist if stop_dist > 0 else 0
    elif method == "kelly":
        raw_qty = (sizing.kelly_fraction or 0) * cash / price if price > 0 else 0
    else:
        raw_qty = 0

    qty = int(raw_qty)

    # Clamp to available cash
    if price > 0:
        max_affordable = int(cash / price)
        qty = min(qty, max_affordable)

    return max(qty, 0)


def _stop_distance(spec: StrategySpec, price: float) -> float:
    """Compute stop distance from entry price for risk_pct sizing."""
    stops = spec.stops
    if stops is None:
        return 0.0
    if stops.stop_loss_pct is not None:
        return price * stops.stop_loss_pct / 100.0
    if stops.stop_loss_points is not None:
        return stops.stop_loss_points
    return 0.0


# ---------------------------------------------------------------------------
# JsonStrategy
# ---------------------------------------------------------------------------


class JsonStrategy(Strategy):
    """Strategy driven by a JSON spec instead of Python code.

    Usage:
        spec = StrategySpec.model_validate(json_dict)
        strategy = JsonStrategy(spec)
        result = backtest(strategy, data)
    """

    def __init__(self, spec: StrategySpec, params: dict | None = None):
        super().__init__(params=params)
        self.spec = spec
        self._cache = IndicatorCache()

    def initialize(self, ctx: Context) -> None:
        """Pre-compute all indicators over the full dataset.

        Uses ctx.full_data (the complete DataFrame) rather than ctx.history
        (which only has the first bar at init time). The evaluator guards
        against look-ahead by only indexing up to the current bar position.
        """
        self._cache.populate(self.spec, ctx.full_data)

    def refresh_cache(self, data: pd.DataFrame) -> None:
        """Clear and repopulate the indicator cache with updated data.

        Used by SignalEngine to recompute indicators as the history grows.
        """
        self._cache._cache.clear()
        self._cache.populate(self.spec, data)

    def stop_config(self) -> dict | None:
        if self.spec.stops is None:
            return None
        cfg = self.spec.stops.to_engine_dict()
        return cfg or None

    def on_bar(self, ctx: Context) -> None:
        """Evaluate entry/exit conditions and submit orders.

        Exit takes priority: if in a position and exit fires, close first.
        Entry only fires when flat. Respects spec.side for long/short.
        """
        bar_idx = len(ctx.history) - 1
        side = self.spec.side

        # Exit check — only when in a position matching our side
        has_position = (side == "long" and ctx.position.is_long) or (
            side == "short" and ctx.position.is_short
        )
        if has_position:
            if _eval_group(self.spec.exit, self._cache, bar_idx):
                ctx.close()
                return

        # Entry check — only when flat
        if ctx.position.is_flat:
            if _eval_group(self.spec.entry, self._cache, bar_idx):
                qty = _compute_qty(self.spec, ctx.bar.close, ctx.cash)
                if qty > 0:
                    if side == "long":
                        ctx.buy(qty=qty)
                    else:
                        ctx.sell(qty=qty)
