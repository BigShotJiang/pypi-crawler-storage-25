"""Async webhook delivery with HMAC-SHA256 signing and exponential backoff.

Dispatches SignalPayload to one or more URLs whenever a non-NO_ACTION signal
fires. Each URL is retried independently up to max_retries times.
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import logging
from dataclasses import dataclass, field

from fastbt.signal_types import SignalPayload, SignalType

logger = logging.getLogger(__name__)


@dataclass
class WebhookConfig:
    """Configuration for webhook delivery."""

    urls: list[str]
    secret: str | None = None
    max_retries: int = 3
    backoff_base: float = 1.0
    timeout: float = 10.0


class WebhookDispatcher:
    """Async webhook dispatcher with HMAC signing and retry.

    Usage::

        dispatcher = WebhookDispatcher(config)
        await dispatcher.start()
        await dispatcher.dispatch(signal_payload)
        await dispatcher.stop()
    """

    def __init__(self, config: WebhookConfig) -> None:
        self._config = config
        self._session: object | None = None  # aiohttp.ClientSession

    async def start(self) -> None:
        """Create the HTTP client session."""
        import aiohttp

        timeout = aiohttp.ClientTimeout(total=self._config.timeout)
        self._session = aiohttp.ClientSession(timeout=timeout)

    async def stop(self) -> None:
        """Close the HTTP client session."""
        if self._session is not None:
            await self._session.close()  # type: ignore[union-attr]
            self._session = None

    async def dispatch(self, payload: SignalPayload) -> list[bool]:
        """Send payload to all configured URLs. Returns success list per URL.

        Skips NO_ACTION signals. Each URL is sent independently and concurrently.
        """
        if payload.type == SignalType.NO_ACTION:
            return [True] * len(self._config.urls)

        tasks = [self._send(url, payload) for url in self._config.urls]
        return await asyncio.gather(*tasks)

    async def _send(self, url: str, payload: SignalPayload) -> bool:
        """Send to a single URL with exponential backoff retry."""
        body = payload.to_json().encode("utf-8")
        headers = self._build_headers(body, payload.type)

        for attempt in range(self._config.max_retries + 1):
            try:
                resp = await self._session.post(url, data=body, headers=headers)  # type: ignore[union-attr]
                if resp.status < 400:
                    return True
                if resp.status < 500:
                    logger.warning(
                        "Webhook %s returned %d (non-retryable)", url, resp.status
                    )
                    return False
                logger.warning(
                    "Webhook %s returned %d (attempt %d/%d)",
                    url,
                    resp.status,
                    attempt + 1,
                    self._config.max_retries + 1,
                )
            except Exception as exc:
                logger.warning(
                    "Webhook %s failed (attempt %d/%d): %s",
                    url,
                    attempt + 1,
                    self._config.max_retries + 1,
                    exc,
                )

            if attempt < self._config.max_retries:
                delay = self._config.backoff_base * (2**attempt)
                await asyncio.sleep(delay)

        logger.error("Webhook %s exhausted retries", url)
        return False

    def _build_headers(self, body: bytes, signal_type: SignalType) -> dict[str, str]:
        """Build HTTP headers including HMAC signature if secret is configured."""
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "X-Fastbt-Event": signal_type.value,
        }
        if self._config.secret:
            sig = hmac.new(
                self._config.secret.encode("utf-8"),
                body,
                hashlib.sha256,
            ).hexdigest()
            headers["X-Fastbt-Signature"] = sig
        return headers
