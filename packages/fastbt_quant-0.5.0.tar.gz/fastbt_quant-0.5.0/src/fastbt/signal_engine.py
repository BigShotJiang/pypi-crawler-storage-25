"""Signal engine — stateful bar-by-bar processor for live signal mode.

Wraps PaperBroker + StopTracker + Strategy, maintaining state between
bar submissions. Each call to process_bar() returns a SignalPayload.

Architecture:

    POST /bar  →  SignalEngine.process_bar(bar)
                      │
                      ├── append to history_df
                      ├── recompute indicators (if JsonStrategy)
                      ├── broker.on_bar_open()
                      ├── stop check → possible stop signal
                      ├── strategy.on_bar()
                      ├── broker.on_bar_close()
                      ├── diff fills → detect signal type
                      └── return SignalPayload
"""

from __future__ import annotations

import pandas as pd

from fastbt.broker import PaperBroker
from fastbt.context import Context
from fastbt.engine import StopResult, StopTracker
from fastbt.json_strategy import JsonStrategy
from fastbt.signal_types import PositionState, SignalPayload, SignalType
from fastbt.strategy import Strategy
from fastbt.types import Bar, OrderSide

_STOP_KIND_TO_SIGNAL = {
    "sl": SignalType.STOP_LOSS_HIT,
    "tp": SignalType.TAKE_PROFIT_HIT,
    "ts": SignalType.TRAILING_STOP_HIT,
    "vol_ts": SignalType.TRAILING_STOP_HIT,  # vol-adaptive trailing variant
}


class SignalEngine:
    """Stateful bar-by-bar signal processor.

    Each call to ``process_bar()`` advances the engine by one bar,
    evaluates the strategy, checks stops, and returns the resulting signal.
    """

    def __init__(
        self,
        strategy: Strategy,
        *,
        symbol: str = "SYMBOL",
        initial_cash: float = 100_000.0,
        commission_pct: float = 0.0,
        slippage_pct: float = 0.0,
        fill_policy: str = "current_close",
        warmup_bars: int = 0,
        stop_loss_pct: float | None = None,
        stop_loss_points: float | None = None,
        take_profit_pct: float | None = None,
        take_profit_points: float | None = None,
        trailing_stop_pct: float | None = None,
        trailing_stop_points: float | None = None,
    ):
        self._strategy = strategy
        self._symbol = symbol
        self._slippage_pct = slippage_pct
        self._warmup_bars = warmup_bars

        self._broker = PaperBroker(
            initial_cash=initial_cash,
            commission_pct=commission_pct,
            slippage_pct=slippage_pct,
            fill_policy=fill_policy,  # type: ignore[arg-type]
        )

        # Build stop tracker — explicit params override strategy.stop_config()
        strat_cfg = strategy.stop_config() or {}
        self._stop_tracker = StopTracker(
            stop_loss_pct=stop_loss_pct or strat_cfg.get("stop_loss_pct"),
            stop_loss_points=stop_loss_points or strat_cfg.get("stop_loss_points"),
            take_profit_pct=take_profit_pct or strat_cfg.get("take_profit_pct"),
            take_profit_points=take_profit_points or strat_cfg.get("take_profit_points"),
            trailing_stop_pct=trailing_stop_pct or strat_cfg.get("trailing_stop_pct"),
            trailing_stop_points=trailing_stop_points or strat_cfg.get("trailing_stop_points"),
        )

        self._history: pd.DataFrame | None = None
        self._bar_count = 0
        self._prev_pos_qty = 0.0
        self._initialized = False
        self._ctx: Context | None = None

        # Idempotency: cache last bar timestamp and signal
        self._last_bar_ts: pd.Timestamp | None = None
        self._last_signal: SignalPayload | None = None

    @property
    def symbol(self) -> str:
        """Instrument symbol this engine was configured for."""
        return self._symbol

    def process_bar(self, bar: Bar) -> SignalPayload:
        """Process a single bar. Returns the signal generated.

        Raises ValueError if bar timestamp is before or equal to the last bar.
        Returns cached signal if bar timestamp matches the last bar (idempotent).
        """
        # Idempotency check
        if self._last_bar_ts is not None and bar.timestamp == self._last_bar_ts:
            assert self._last_signal is not None
            return self._last_signal

        # Out-of-order rejection
        if self._last_bar_ts is not None and bar.timestamp <= self._last_bar_ts:
            raise ValueError(
                f"Bar timestamp {bar.timestamp} is before or equal to "
                f"last bar {self._last_bar_ts}"
            )

        # Append to history
        new_row = pd.DataFrame(
            {
                "open": [bar.open],
                "high": [bar.high],
                "low": [bar.low],
                "close": [bar.close],
                "volume": [bar.volume],
            },
            index=pd.DatetimeIndex([bar.timestamp]),
        )
        if self._history is None:
            self._history = new_row
        else:
            self._history = pd.concat([self._history, new_row])

        self._bar_count += 1

        # Recompute indicators for JsonStrategy
        if isinstance(self._strategy, JsonStrategy):
            self._strategy.refresh_cache(self._history)

        # Initialize strategy on first bar
        if not self._initialized:
            self._ctx = Context(
                symbol=self._symbol,
                bar=bar,
                history=self._history,
                params=self._strategy.params,
                broker=self._broker,
                full_data=self._history,
            )
            self._strategy.initialize(self._ctx)
            self._initialized = True

        # Update context
        assert self._ctx is not None
        self._ctx.bar = bar
        self._ctx.history = self._history
        self._ctx.full_data = self._history

        ts = bar.timestamp

        # Broker processes pending orders from prior bar
        self._broker.on_bar_open(bar)

        # Snapshot fills before strategy runs
        fills_before = len(self._broker.fills())

        # Stop check — before strategy
        stop_result: StopResult | None = None
        if self._stop_tracker.is_active:
            pos = self._broker.position(self._symbol)
            stop_result = self._stop_tracker.check(self._symbol, bar, pos)
            if stop_result is not None:
                slip = self._slippage_pct / 100.0
                if pos.is_long:
                    fill_price = stop_result.price * (1 - slip)
                else:
                    fill_price = stop_result.price * (1 + slip)
                self._broker.execute_stop(self._symbol, fill_price, ts)
                self._stop_tracker.on_position_closed(self._symbol)

        # Strategy execution
        bar_idx = self._bar_count - 1
        if bar_idx >= self._warmup_bars:
            self._strategy.on_bar(self._ctx)

        # Broker processes orders at close
        self._broker.on_bar_close(bar)

        # Track position changes for stop tracker
        if self._stop_tracker.is_active:
            curr_pos = self._broker.position(self._symbol)
            if self._prev_pos_qty == 0 and curr_pos.qty != 0:
                fills = self._broker.fills()
                if fills:
                    self._stop_tracker.on_position_opened(
                        self._symbol, fills[-1].price
                    )
            elif self._prev_pos_qty != 0 and curr_pos.qty == 0:
                self._stop_tracker.on_position_closed(self._symbol)
            self._prev_pos_qty = curr_pos.qty

        # Detect signal
        fills_after = len(self._broker.fills())
        signal = self._detect_signal(
            fills_before, fills_after, stop_result, bar
        )

        # Cache for idempotency
        self._last_bar_ts = bar.timestamp
        self._last_signal = signal

        return signal

    def status(self) -> dict:
        """Return current engine state."""
        pos = self._broker.position(self._symbol)
        last_close = 0.0
        if self._ctx is not None:
            last_close = self._ctx.bar.close
        return {
            "symbol": self._symbol,
            "bar_count": self._bar_count,
            "position": {
                "qty": pos.qty,
                "avg_entry_price": pos.avg_entry_price,
                "side": "long" if pos.is_long else ("short" if pos.is_short else "flat"),
            },
            "cash": self._broker.cash(),
            "equity": self._broker.equity({self._symbol: last_close}),
            "fills_count": len(self._broker.fills()),
            "last_bar_timestamp": str(self._last_bar_ts) if self._last_bar_ts else None,
        }

    def _detect_signal(
        self,
        fills_before: int,
        fills_after: int,
        stop_result: StopResult | None,
        bar: Bar,
    ) -> SignalPayload:
        """Determine what happened this bar and build the signal payload."""
        pos = self._broker.position(self._symbol)
        pos_state = PositionState.from_position(pos, bar.close)
        bar_dict = {
            "timestamp": str(bar.timestamp),
            "open": bar.open,
            "high": bar.high,
            "low": bar.low,
            "close": bar.close,
            "volume": bar.volume,
        }

        new_fills = self._broker.fills()[fills_before:fills_after]

        if not new_fills:
            return SignalPayload(
                version="0.2.0",
                type=SignalType.NO_ACTION,
                symbol=self._symbol,
                timestamp=str(bar.timestamp),
                bar=bar_dict,
                position=pos_state,
                reason="No conditions met",
            )

        last_fill = new_fills[-1]
        side_str = last_fill.side.value

        # Determine signal type
        was_flat = self._prev_pos_qty == 0 or (
            # Position was closed by stop, then possibly reopened
            stop_result is not None and pos.is_flat
        )

        if stop_result is not None and pos.is_flat:
            signal_type = _STOP_KIND_TO_SIGNAL[stop_result.kind]
            reason = f"{signal_type.value.replace('_', ' ').title()} at {last_fill.price:.2f}"
        elif fills_before == 0 and pos.qty != 0:
            # First fill ever — entry
            if pos.is_long:
                signal_type = SignalType.ENTRY_LONG
            else:
                signal_type = SignalType.ENTRY_SHORT
            reason = f"Entry at {last_fill.price:.2f}"
        elif self._prev_pos_qty == 0 and pos.qty != 0:
            # Was flat, now positioned — entry
            if pos.is_long:
                signal_type = SignalType.ENTRY_LONG
            else:
                signal_type = SignalType.ENTRY_SHORT
            reason = f"Entry at {last_fill.price:.2f}"
        elif pos.is_flat:
            # Was positioned, now flat — exit
            signal_type = SignalType.EXIT_SIGNAL
            reason = f"Exit at {last_fill.price:.2f}"
        else:
            # Still positioned but qty changed — update
            signal_type = SignalType.POSITION_UPDATE
            reason = f"Position update at {last_fill.price:.2f}"

        return SignalPayload(
            version="0.2.0",
            type=signal_type,
            symbol=self._symbol,
            timestamp=str(bar.timestamp),
            bar=bar_dict,
            position=pos_state,
            reason=reason,
            side=side_str,
            qty=last_fill.qty,
            price=last_fill.price,
        )
