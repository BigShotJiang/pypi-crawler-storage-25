"""Strategy base class — user strategies subclass this."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from fastbt.context import Context


class Strategy:
    """Base class for single-symbol strategies.

    Subclass and override `initialize` (called once) and `on_bar` (called per bar).

    Example:
        class SmaCross(Strategy):
            def initialize(self, ctx):
                self.fast = self.params.get("fast", 10)
                self.slow = self.params.get("slow", 30)

            def on_bar(self, ctx):
                close = ctx.history["close"]
                if len(close) < self.slow:
                    return
                fast_ma = close.rolling(self.fast).mean().iloc[-1]
                slow_ma = close.rolling(self.slow).mean().iloc[-1]
                if fast_ma > slow_ma and ctx.position.is_flat:
                    ctx.buy(qty=100)
                elif fast_ma < slow_ma and ctx.position.is_long:
                    ctx.close()
    """

    def __init__(self, params: dict | None = None):
        self.params: dict = params or {}

    @classmethod
    def from_json(cls, spec: dict | str, params: dict | None = None) -> Strategy:
        """Create a JsonStrategy from a JSON spec (dict or JSON string).

        Indicator names, params, and output fields are validated at the schema
        boundary by ``IndicatorRef`` (see schema.py). Bad references raise
        ``pydantic.ValidationError`` here.

        Args:
            spec: Strategy specification as a dict or JSON string.
            params: Optional extra params passed to the Strategy constructor.

        Returns:
            A JsonStrategy instance ready to pass to backtest().

        Raises:
            pydantic.ValidationError: If the spec fails schema validation.
            json.JSONDecodeError: If spec is a string and is not valid JSON.
        """
        from fastbt.json_strategy import JsonStrategy
        from fastbt.schema import StrategySpec

        if isinstance(spec, str):
            parsed = StrategySpec.model_validate_json(spec)
        else:
            parsed = StrategySpec.model_validate(spec)
        return JsonStrategy(parsed, params=params)

    def initialize(self, ctx: Context) -> None:
        """Called once before the first bar."""

    def on_bar(self, ctx: Context) -> None:
        """Called on each bar. Override in subclass."""
        raise NotImplementedError(f"{type(self).__name__} must implement on_bar(self, ctx)")

    def stop_config(self) -> dict | None:
        """Override to provide stop-loss/take-profit/trailing-stop config.

        Returns a dict with keys like 'stop_loss_pct', 'trailing_stop_points', etc.
        The engine reads this during backtest setup. Explicit backtest() params
        take precedence over values returned here.
        """
        return None
