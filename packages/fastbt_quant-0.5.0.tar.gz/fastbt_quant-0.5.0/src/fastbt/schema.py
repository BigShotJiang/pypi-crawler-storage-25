"""Pydantic schema models for JSON declarative strategies.

Defines the data models that validate strategy JSON specs,
enabling users to define trading rules as JSON instead of Python subclasses.
"""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, field_validator, model_validator

# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------

VALID_OPERATORS: list[str] = [">", "<", ">=", "<=", "==", "crosses_above", "crosses_below"]
VALID_SOURCES: list[str] = ["open", "high", "low", "close", "volume", "hlc3", "ohlc4"]
VALID_SIZING_METHODS: list[str] = ["fixed_qty", "percent_equity", "fixed_cash", "risk_pct", "kelly"]


# -----------------------------------------------------------------------------
# IndicatorRef
# -----------------------------------------------------------------------------


class IndicatorRef(BaseModel):
    """Reference to an indicator value on a specific OHLCV source column."""

    indicator: str
    params: dict[str, object]
    output: str
    source: str = "close"
    offset: int = 0

    @field_validator("source")
    @classmethod
    def _validate_source(cls, v: str) -> str:
        if v not in VALID_SOURCES:
            msg = f"Invalid source {v!r}. Must be one of {VALID_SOURCES}"
            raise ValueError(msg)
        return v

    @model_validator(mode="after")
    def _validate_against_registry(self) -> IndicatorRef:
        # Lazy import: registry imports indicators which is independent of schema,
        # but keeping the import lazy guards against any future cycle.
        from fastbt.registry import default_registry

        # Indicator name must exist (raises KeyError on miss).
        try:
            meta = default_registry.get(self.indicator)
        except KeyError as exc:
            raise ValueError(str(exc)) from None

        # Param names must be recognized.
        default_registry.validate_params(self.indicator, self.params)

        # Output name must be one of the indicator's declared outputs.
        if self.output not in meta.output_names:
            valid = ", ".join(meta.output_names)
            msg = (
                f"Invalid output {self.output!r} for indicator {self.indicator!r}. "
                f"Valid outputs: {valid}"
            )
            raise ValueError(msg)
        return self


# -----------------------------------------------------------------------------
# Condition
# -----------------------------------------------------------------------------

Operand = Annotated[Union[IndicatorRef, float], "indicator ref or numeric literal"]


class Condition(BaseModel):
    """A single comparison between two operands."""

    left: Operand
    operator: str
    right: Operand

    @field_validator("operator")
    @classmethod
    def _validate_operator(cls, v: str) -> str:
        if v not in VALID_OPERATORS:
            msg = f"Invalid operator {v!r}. Must be one of {VALID_OPERATORS}"
            raise ValueError(msg)
        return v

    @model_validator(mode="after")
    def _at_least_one_indicator(self) -> Condition:
        if isinstance(self.left, float) and isinstance(self.right, float):
            msg = "At least one of left/right must be an IndicatorRef"
            raise ValueError(msg)
        return self


# -----------------------------------------------------------------------------
# ConditionGroup (recursive)
# -----------------------------------------------------------------------------


class ConditionGroup(BaseModel):
    """AND/OR group of conditions, supporting recursive nesting."""

    all: list[Condition | ConditionGroup] | None = None
    any: list[Condition | ConditionGroup] | None = None

    @model_validator(mode="after")
    def _exactly_one_key(self) -> ConditionGroup:
        has_all = self.all is not None
        has_any = self.any is not None
        if has_all and has_any:
            msg = "Exactly one of 'all' or 'any' must be set, not both"
            raise ValueError(msg)
        if not has_all and not has_any:
            msg = "Exactly one of 'all' or 'any' must be set"
            raise ValueError(msg)
        return self


# Rebuild to resolve forward references for recursive types.
ConditionGroup.model_rebuild()


# -----------------------------------------------------------------------------
# PositionSizing
# -----------------------------------------------------------------------------


class PositionSizing(BaseModel):
    """How to size trades."""

    method: str
    qty: float | None = None
    pct: float | None = None
    amount: float | None = None
    risk_fraction: float | None = None
    kelly_fraction: float | None = None

    @field_validator("method")
    @classmethod
    def _validate_method(cls, v: str) -> str:
        if v not in VALID_SIZING_METHODS:
            msg = f"Invalid method {v!r}. Must be one of {VALID_SIZING_METHODS}"
            raise ValueError(msg)
        return v

    @model_validator(mode="after")
    def _required_field_for_method(self) -> PositionSizing:
        required = {
            "fixed_qty": "qty",
            "percent_equity": "pct",
            "fixed_cash": "amount",
            "risk_pct": "risk_fraction",
            "kelly": "kelly_fraction",
        }
        field_name = required[self.method]
        if getattr(self, field_name) is None:
            msg = f"Field {field_name!r} is required when method is {self.method!r}"
            raise ValueError(msg)
        return self


# -----------------------------------------------------------------------------
# StopsConfig — shared between StrategySpec and PortfolioStrategySpec (D4)
# -----------------------------------------------------------------------------

# Names of the stop fields that may appear in the legacy flat shape (D4 shim).
_STOP_FIELDS: tuple[str, ...] = (
    "stop_loss_pct",
    "stop_loss_points",
    "take_profit_pct",
    "take_profit_points",
    "trailing_stop_pct",
    "trailing_stop_points",
    "vol_trailing_multiplier",
    "vol_trailing_lookback",
    "vol_trailing_fallback_pct",
)


class StopsConfig(BaseModel):
    """Per-position stop configuration shared by single-symbol and portfolio specs.

    All fields optional. Each stop type fires independently; the engine resolves
    same-bar conflicts via its existing intra-bar ordering.
    """

    stop_loss_pct: float | None = None
    stop_loss_points: float | None = None
    take_profit_pct: float | None = None
    take_profit_points: float | None = None
    trailing_stop_pct: float | None = None
    trailing_stop_points: float | None = None
    vol_trailing_multiplier: float | None = None
    vol_trailing_lookback: int = 60
    vol_trailing_fallback_pct: float | None = None

    @property
    def has_stop_loss(self) -> bool:
        return self.stop_loss_pct is not None or self.stop_loss_points is not None

    def to_engine_dict(self) -> dict:
        """Dump non-None stop fields as a dict matching the engine kwargs."""
        out: dict = {}
        for field in _STOP_FIELDS:
            val = getattr(self, field)
            # vol_trailing_lookback has a default of 60 — only emit when something
            # else makes the vol_trailing band active, so unused defaults don't
            # leak into engine kwargs.
            if val is None:
                continue
            if field == "vol_trailing_lookback" and self.vol_trailing_multiplier is None:
                continue
            out[field] = val
        return out


def _normalize_stops_shape(values: dict) -> dict:
    """Pre-validator shim that normalizes legacy flat stop fields into nested ``stops``.

    Single-symbol JSON specs prior to v0.4.0 placed stop fields at the top level
    (e.g. ``{"stop_loss_pct": 5.0}``). v0.4.0 nests them under ``stops``. To stay
    back-compat, this shim lifts top-level stop keys into ``stops`` automatically.

    Raises ``ValueError`` if BOTH the flat and nested shapes are present (D11) —
    silent precedence in financial config is a foot-gun.
    """
    if not isinstance(values, dict):
        return values  # let Pydantic emit its own type error

    flat_present = {k: values[k] for k in _STOP_FIELDS if k in values}
    nested = values.get("stops")
    has_nested = nested is not None and nested != {}

    if flat_present and has_nested:
        flat_keys = sorted(flat_present)
        msg = (
            f"Cannot mix flat and nested stops in the same spec. Found flat keys "
            f"{flat_keys} alongside nested 'stops'. Use one form (the nested "
            f"'stops: {{...}}' shape is preferred from v0.4.0)."
        )
        raise ValueError(msg)

    if flat_present:
        # Lift the flat fields into a nested stops dict and remove from top level.
        new_values = {k: v for k, v in values.items() if k not in flat_present}
        new_values["stops"] = flat_present
        return new_values

    return values


# -----------------------------------------------------------------------------
# StrategySpec
# -----------------------------------------------------------------------------


class StrategySpec(BaseModel):
    """Top-level strategy specification parsed from JSON."""

    kind: Literal["single"] = "single"
    version: Literal["0.0.3", "0.2.0", "0.4.0"]
    side: Literal["long", "short"] = "long"
    entry: ConditionGroup
    exit: ConditionGroup
    position_sizing: PositionSizing = PositionSizing(method="fixed_qty", qty=100)
    stops: StopsConfig | None = None

    @model_validator(mode="before")
    @classmethod
    def _normalize_legacy_flat_stops(cls, values: dict) -> dict:
        return _normalize_stops_shape(values)

    @model_validator(mode="after")
    def _risk_pct_needs_stop(self) -> StrategySpec:
        if self.position_sizing.method == "risk_pct":
            stops = self.stops
            if stops is None or not stops.has_stop_loss:
                msg = "risk_pct sizing requires stop_loss_pct or stop_loss_points"
                raise ValueError(msg)
        return self
