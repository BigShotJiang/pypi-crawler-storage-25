"""CLI entry point: fastbt run <strategy.json> --data <file> [options]."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd


def main(argv: list[str] | None = None) -> None:
    """Entry point for the ``fastbt`` CLI command."""
    parser = argparse.ArgumentParser(prog="fastbt", description="fastbt backtesting CLI")
    sub = parser.add_subparsers(dest="command")

    # -- run subcommand --
    run_p = sub.add_parser("run", help="Run a JSON strategy backtest")
    run_p.add_argument("strategy_file", help="Path to strategy JSON file")
    run_p.add_argument("--data", default=None, help="OHLCV data file (parquet or CSV)")
    run_p.add_argument("--symbol", default="SYMBOL", help="Display label (default: SYMBOL)")
    run_p.add_argument("--cash", type=float, default=100_000.0, help="Initial cash")
    run_p.add_argument("--commission", type=float, default=0.0, help="Commission pct")
    run_p.add_argument("--slippage", type=float, default=0.0, help="Slippage pct")
    run_p.add_argument("--warmup", type=int, default=0, help="Warmup bars")
    run_p.add_argument("--report", metavar="FILE", help="Generate HTML tearsheet at path")
    run_p.add_argument("--save", metavar="FILE", help="Save result to JSON file")
    run_p.add_argument("--quiet", action="store_true", help="Suppress terminal summary")

    # -- show subcommand --
    show_p = sub.add_parser("show", help="Display a saved result")
    show_p.add_argument("result_file", help="Path to saved result JSON")

    # -- signal subcommand --
    sig_p = sub.add_parser("signal", help="Run signal server for live bar-by-bar processing")
    sig_p.add_argument("strategy_file", help="Path to strategy JSON file")
    sig_p.add_argument("--port", type=int, default=8080, help="Server port (default: 8080)")
    sig_p.add_argument("--host", default="0.0.0.0", help="Server host (default: 0.0.0.0)")
    sig_p.add_argument("--symbol", default="SYMBOL", help="Symbol label (default: SYMBOL)")
    sig_p.add_argument("--cash", type=float, default=100_000.0, help="Initial cash")
    sig_p.add_argument("--commission", type=float, default=0.0, help="Commission pct")
    sig_p.add_argument("--slippage", type=float, default=0.0, help="Slippage pct")
    sig_p.add_argument("--warmup", type=int, default=0, help="Warmup bars")
    sig_p.add_argument(
        "--webhook-url", action="append", dest="webhook_urls", help="Webhook URL (repeatable)"
    )
    sig_p.add_argument("--webhook-secret", default=None, help="HMAC-SHA256 secret for webhooks")

    # -- fetch subcommand --
    fetch_p = sub.add_parser("fetch", help="Download OHLCV data from idata.fyi")
    fetch_p.add_argument("symbol", help="Ticker symbol (e.g., SBIN)")
    fetch_p.add_argument(
        "-o", "--output", required=True, help="Output file path (.csv or .parquet)"
    )

    # -- config subcommand --
    cfg_p = sub.add_parser("config", help="Manage persistent configuration")
    cfg_sub = cfg_p.add_subparsers(dest="config_action")
    cfg_set = cfg_sub.add_parser("set", help="Set a config value")
    cfg_set.add_argument("key", help="Config key (e.g., idata-api-key)")
    cfg_set.add_argument("value", help="Value to set")
    cfg_sub.add_parser("show", help="Display current configuration")

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    try:
        if args.command == "run":
            _cmd_run(args)
        elif args.command == "show":
            _cmd_show(args)
        elif args.command == "signal":
            _cmd_signal(args)
        elif args.command == "fetch":
            _cmd_fetch(args)
        elif args.command == "config":
            _cmd_config(args)
    except FileNotFoundError as exc:
        print(f"Error: File not found: {exc.filename or exc}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as exc:
        print(f"Error: Invalid JSON: {exc.msg}", file=sys.stderr)
        sys.exit(1)
    except ImportError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    except Exception as exc:
        _name = type(exc).__name__
        if _name in (
            "ValidationError",
            "OHLCVValidationError",
            "IdataError",
            "IdataAuthError",
            "IdataAPIError",
        ):
            print(f"Error: {exc}", file=sys.stderr)
            sys.exit(1)
        raise


def _cmd_run(args: argparse.Namespace) -> None:
    from fastbt import __version__
    from fastbt.engine import backtest
    from fastbt.json_strategy import JsonStrategy
    from fastbt.schema import StrategySpec
    from fastbt.validators import validate_ohlcv

    # Load strategy
    spec_text = Path(args.strategy_file).read_text()
    spec_data = json.loads(spec_text)
    spec = StrategySpec.model_validate(spec_data)
    strategy = JsonStrategy(spec)

    # Load data
    if args.data is not None:
        data_path = Path(args.data)
        if data_path.suffix == ".parquet":
            df = pd.read_parquet(data_path)
        else:
            df = pd.read_csv(data_path, index_col=0, parse_dates=True)
    elif args.symbol != "SYMBOL":
        from fastbt.data import IdataClient

        if not args.quiet:
            print(f"Fetching {args.symbol} from idata.fyi...")
        client = IdataClient()
        df = client.fetch_ohlcv(args.symbol)
        if not args.quiet:
            print(f"  {len(df)} bars loaded.")
    else:
        print("Error: provide --data <file> or --symbol <SYMBOL>", file=sys.stderr)
        sys.exit(1)
    validate_ohlcv(df)

    # Build stop config from strategy spec
    stop_kwargs: dict = {}
    stop_cfg = strategy.stop_config()
    if stop_cfg:
        stop_kwargs = stop_cfg

    # Run backtest
    result = backtest(
        strategy,
        df,
        symbol=args.symbol,
        initial_cash=args.cash,
        commission_pct=args.commission,
        slippage_pct=args.slippage,
        warmup_bars=args.warmup,
        **stop_kwargs,
    )

    # Print summary
    if not args.quiet:
        _print_summary(result, args, __version__)

    # Generate tearsheet
    if args.report:
        from fastbt.report import tearsheet

        tearsheet(result, args.report)
        if not args.quiet:
            print(f"  Tearsheet:    {args.report}")

    # Save result
    if args.save:
        from fastbt.serialization import save_result

        save_result(result, args.save)
        if not args.quiet:
            print(f"  Result saved: {args.save}")


def _cmd_signal(args: argparse.Namespace) -> None:
    try:
        import aiohttp  # noqa: F401
    except ImportError:
        print(
            "Error: aiohttp is required for signal mode.\n"
            "Install with: pip install fastbt-quant[signal]",
            file=sys.stderr,
        )
        sys.exit(1)

    from fastbt.json_strategy import JsonStrategy
    from fastbt.schema import StrategySpec
    from fastbt.signal_engine import SignalEngine
    from fastbt.signal_server import SignalServer
    from fastbt.webhook import WebhookConfig, WebhookDispatcher

    spec_text = Path(args.strategy_file).read_text()
    spec_data = json.loads(spec_text)
    spec = StrategySpec.model_validate(spec_data)
    strategy = JsonStrategy(spec)

    stop_kwargs: dict = {}
    stop_cfg = strategy.stop_config()
    if stop_cfg:
        stop_kwargs = stop_cfg

    engine = SignalEngine(
        strategy,
        symbol=args.symbol,
        initial_cash=args.cash,
        commission_pct=args.commission,
        slippage_pct=args.slippage,
        warmup_bars=args.warmup,
        **stop_kwargs,
    )

    dispatcher = None
    if args.webhook_urls:
        dispatcher = WebhookDispatcher(
            WebhookConfig(
                urls=args.webhook_urls,
                secret=args.webhook_secret,
            )
        )

    server = SignalServer(engine, dispatcher, host=args.host, port=args.port)
    print(f"fastbt signal server starting on {args.host}:{args.port}")
    print(f"  Symbol: {args.symbol}")
    print(f"  Strategy: {args.strategy_file}")
    if args.webhook_urls:
        print(f"  Webhooks: {len(args.webhook_urls)} URL(s)")
    print("\n  POST /bar   — submit a bar, receive signal")
    print("  GET  /status — current engine state\n")
    server.run()


def _cmd_show(args: argparse.Namespace) -> None:
    from fastbt import __version__
    from fastbt.serialization import load_result

    result = load_result(args.result_file)
    _print_summary(result, args, __version__)


def _print_summary(result: object, args: argparse.Namespace, version: str) -> None:
    m = result.metrics  # type: ignore[union-attr]
    eq = result.equity_curve  # type: ignore[union-attr]

    symbol = getattr(args, "symbol", "SYMBOL")
    start = eq.index[0].strftime("%Y-%m-%d") if len(eq) > 0 else "N/A"
    end = eq.index[-1].strftime("%Y-%m-%d") if len(eq) > 0 else "N/A"

    print(f"\nfastbt v{version}")
    print(f"\n  Symbol:       {symbol}")
    print(f"  Period:       {start} to {end} ({len(eq)} bars)")
    print(f"  Initial:      ${result.initial_cash:,.2f}")  # type: ignore[union-attr]
    print(f"  Final:        ${result.final_cash:,.2f}")  # type: ignore[union-attr]
    print(f"\n  Total Return:    {m.total_return_pct:.2f}%")
    print(f"  Max Drawdown:    {m.max_drawdown_pct:.2f}%")
    print(f"  Sharpe Ratio:    {m.sharpe:.2f}")
    print(f"  Win Rate:        {m.win_rate_pct:.1f}%")
    print(f"  Profit Factor:   {m.profit_factor:.2f}")
    print(f"  Trades:          {m.num_trades}")
    print(f"  Avg Trade PnL:   {m.avg_trade_pnl:,.2f}")


def _cmd_config(args: argparse.Namespace) -> None:
    from fastbt.config import CONFIG_FILE, _KEY_MAP, load_config, set_value

    if args.config_action == "set":
        set_value(args.key, args.value)
        print(f"  Saved {args.key} to {CONFIG_FILE}")
    elif args.config_action == "show":
        cfg = load_config()
        if not cfg:
            print(f"  No config file found at {CONFIG_FILE}")
            return
        print(f"  Config: {CONFIG_FILE}\n")
        for section, values in sorted(cfg.items()):
            if isinstance(values, dict):
                print(f"  [{section}]")
                for k, v in sorted(values.items()):
                    # Mask sensitive values
                    if "key" in k or "secret" in k or "token" in k:
                        display = v[:4] + "..." + v[-4:] if len(v) > 12 else "****"
                    else:
                        display = v
                    print(f"    {k} = {display}")
    else:
        valid = ", ".join(sorted(_KEY_MAP))
        print(f"Usage: fastbt config set <key> <value>")
        print(f"       fastbt config show")
        print(f"\n  Valid keys: {valid}")


def _cmd_fetch(args: argparse.Namespace) -> None:
    from fastbt.data import IdataClient

    client = IdataClient()
    print(f"Fetching {args.symbol} from idata.fyi...")
    df = client.fetch_ohlcv(args.symbol)
    print(f"  {len(df)} bars loaded.")

    out = Path(args.output)
    if out.suffix == ".parquet":
        df.to_parquet(str(out))
    else:
        df.to_csv(str(out))
    print(f"  Saved to {out}")


if __name__ == "__main__":
    main()
