"""HTTP signal server — receives bars, returns signals, fires webhooks.

Endpoints:
    POST /bar   — submit a completed OHLCV bar, receive signal JSON
    GET /status — current engine state (position, cash, fills count)

Requires ``aiohttp`` (install via ``pip install fastbt-quant[signal]``).
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

import pandas as pd

from fastbt.signal_engine import SignalEngine
from fastbt.types import Bar

if TYPE_CHECKING:
    from aiohttp import web

    from fastbt.webhook import WebhookDispatcher

logger = logging.getLogger(__name__)

_REQUIRED_BAR_FIELDS = {"timestamp", "open", "high", "low", "close", "volume"}


class SignalServer:
    """aiohttp-based signal server wrapping a SignalEngine.

    Usage::

        server = SignalServer(engine, dispatcher, host="0.0.0.0", port=8080)
        server.run()  # blocking
    """

    def __init__(
        self,
        engine: SignalEngine,
        dispatcher: WebhookDispatcher | None = None,
        *,
        host: str = "0.0.0.0",
        port: int = 8080,
    ) -> None:
        self._engine = engine
        self._dispatcher = dispatcher
        self._host = host
        self._port = port
        self._lock = asyncio.Lock()

    def create_app(self) -> web.Application:
        """Create and return the aiohttp Application (useful for testing)."""
        from aiohttp import web

        app = web.Application()
        app.router.add_post("/bar", self._handle_bar)
        app.router.add_get("/status", self._handle_status)
        if self._dispatcher is not None:
            app.on_startup.append(self._on_startup)
            app.on_cleanup.append(self._on_cleanup)
        return app

    def run(self) -> None:
        """Run the server (blocking)."""
        from aiohttp import web

        app = self.create_app()
        web.run_app(app, host=self._host, port=self._port)

    async def _on_startup(self, app: web.Application) -> None:
        if self._dispatcher is not None:
            await self._dispatcher.start()

    async def _on_cleanup(self, app: web.Application) -> None:
        if self._dispatcher is not None:
            await self._dispatcher.stop()

    async def _handle_bar(self, request: web.Request) -> web.Response:
        """Process a bar submission."""
        from aiohttp import web

        try:
            data = await request.json()
        except Exception:
            return web.json_response(
                {"error": "Invalid JSON"}, status=400
            )

        missing = _REQUIRED_BAR_FIELDS - set(data.keys())
        if missing:
            return web.json_response(
                {"error": f"Missing fields: {sorted(missing)}"}, status=400
            )

        try:
            bar = Bar(
                timestamp=pd.Timestamp(data["timestamp"]),
                symbol=self._engine.symbol,
                open=float(data["open"]),
                high=float(data["high"]),
                low=float(data["low"]),
                close=float(data["close"]),
                volume=float(data["volume"]),
            )
        except (ValueError, TypeError) as exc:
            return web.json_response(
                {"error": f"Invalid bar data: {exc}"}, status=400
            )

        async with self._lock:
            try:
                signal = self._engine.process_bar(bar)
            except ValueError as exc:
                return web.json_response(
                    {"error": str(exc)}, status=422
                )

        # Fire webhook asynchronously (don't block response)
        from fastbt.signal_types import SignalType

        if (
            self._dispatcher is not None
            and signal.type != SignalType.NO_ACTION
        ):
            asyncio.create_task(self._dispatcher.dispatch(signal))

        return web.json_response(signal.to_dict())

    async def _handle_status(self, request: web.Request) -> web.Response:
        """Return current engine state."""
        from aiohttp import web

        return web.json_response(self._engine.status())
