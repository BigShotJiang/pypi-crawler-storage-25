"""Pydantic schema models for JSON declarative portfolio strategies (v0.4.0).

A ``PortfolioStrategySpec`` describes a portfolio strategy entirely in JSON,
mirroring the lifecycle of ``PortfolioStrategy``::

    universe -> rank -> select -> allocate -> schedule

The spec compiles down to existing primitives in ``allocators.py`` and
``schedule.py`` — no new engine logic.

Design decisions (see plan-eng-review):
- D1: ``kind: "portfolio"`` discriminator distinguishes from single-symbol specs.
- D2: ``AllocateSpec`` and ``ScheduleSpec`` are Pydantic discriminated unions —
  typo'd method/type fails at JSON load time, not deep in the bar loop.
- D3: Ranking is constrained to ``weighted_metrics``. Custom Python ranking
  remains available via ``PortfolioStrategy`` subclass.
- D4: ``StopsConfig`` (in schema.py) is shared between single-symbol and
  portfolio specs. Same back-compat shim applies.
- D6: ``WeightedIndicatorRef`` extends ``IndicatorRef`` with a ``weight`` field.
"""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field, field_validator, model_validator

from fastbt.schema import IndicatorRef, StopsConfig, _normalize_stops_shape


# -----------------------------------------------------------------------------
# Universe
# -----------------------------------------------------------------------------


class UniverseFilter(BaseModel):
    """Optional filters applied at each rebalance to narrow the eligible universe.

    All filters are AND-composed. Symbols failing any filter are excluded.
    Missing filters mean "no constraint."
    """

    min_history: int | None = None
    """Minimum bars of history required (e.g. ``90`` for a 90d momentum lookback)."""

    min_avg_volume: float | None = None
    """Minimum average daily volume across the symbol's full history."""

    max_symbols: int | None = None
    """Cap the universe at N symbols (after filtering, before ranking).
    Truncation order is the input symbol order."""

    @field_validator("min_history")
    @classmethod
    def _min_history_positive(cls, v: int | None) -> int | None:
        if v is not None and v < 0:
            raise ValueError("min_history must be >= 0")
        return v

    @field_validator("max_symbols")
    @classmethod
    def _max_symbols_positive(cls, v: int | None) -> int | None:
        if v is not None and v < 1:
            raise ValueError("max_symbols must be >= 1")
        return v


# -----------------------------------------------------------------------------
# Rank — weighted_metrics (D3)
# -----------------------------------------------------------------------------


class WeightedIndicatorRef(IndicatorRef):
    """An ``IndicatorRef`` plus a weight, used inside a ``WeightedMetricsRank``.

    The same registry validation applies (indicator name, params, output) —
    inherited from ``IndicatorRef``.
    """

    weight: float


class WeightedMetricsRank(BaseModel):
    """Rank symbols by a weighted sum of indicator values evaluated on each
    symbol's price history.

    Mirrors ``allocators.momentum_score`` (no z-score normalization — see
    TODOS.md "Metric z-score normalization for weighted_metrics").

    Note: tie-breaking is by input symbol order (Python's ``sorted`` is stable).
    """

    score: Literal["weighted_metrics"]
    metrics: list[WeightedIndicatorRef] = Field(min_length=1)


# -----------------------------------------------------------------------------
# Select
# -----------------------------------------------------------------------------


class SelectSpec(BaseModel):
    """Pick top-N (or bottom-N) ranked symbols.

    Default direction is ``desc`` — pick the highest-scoring symbols.
    """

    top_n: int | None = None
    """Number of symbols to keep. ``None`` keeps all ranked symbols."""

    direction: Literal["desc", "asc"] = "desc"

    @field_validator("top_n")
    @classmethod
    def _top_n_positive(cls, v: int | None) -> int | None:
        if v is not None and v < 1:
            raise ValueError("top_n must be >= 1")
        return v


# -----------------------------------------------------------------------------
# Allocators (discriminated union — D2)
# -----------------------------------------------------------------------------


class _AllocBase(BaseModel):
    """Common shape for allocator specs. Each subclass adds method-specific fields."""


class EqualWeightAlloc(_AllocBase):
    method: Literal["equal_weight"]


class MomentumWeightedAlloc(_AllocBase):
    method: Literal["momentum_weighted"]


class InverseVolatilityAlloc(_AllocBase):
    method: Literal["inverse_volatility"]
    vol_lookback: int = 60


class RiskParityAlloc(_AllocBase):
    method: Literal["risk_parity"]
    vol_lookback: int = 60


AllocateSpec = Annotated[
    Union[
        EqualWeightAlloc,
        MomentumWeightedAlloc,
        InverseVolatilityAlloc,
        RiskParityAlloc,
    ],
    Field(discriminator="method"),
]


# -----------------------------------------------------------------------------
# Schedule (discriminated union — D2)
# -----------------------------------------------------------------------------


class _SchedBase(BaseModel):
    pass


class EveryBarSchedule(_SchedBase):
    type: Literal["every_bar"]


class EveryNBarsSchedule(_SchedBase):
    type: Literal["every_n_bars"]
    n: int

    @field_validator("n")
    @classmethod
    def _n_positive(cls, v: int) -> int:
        if v < 1:
            raise ValueError("n must be >= 1")
        return v


class WeeklySchedule(_SchedBase):
    type: Literal["weekly"]
    day: int = 4  # default Friday — matches RebalanceSchedule.weekly()

    @field_validator("day")
    @classmethod
    def _day_in_range(cls, v: int) -> int:
        if not 0 <= v <= 6:
            raise ValueError("weekly day must be 0..6 (0=Mon, 4=Fri, 6=Sun)")
        return v


class MonthlySchedule(_SchedBase):
    type: Literal["monthly"]
    when: Literal["first", "last"] | None = None
    day: int | None = None

    @model_validator(mode="after")
    def _when_or_day(self) -> MonthlySchedule:
        # Mirror RebalanceSchedule.monthly(): when and day are mutually exclusive.
        if self.when is not None and self.day is not None:
            raise ValueError(
                "monthly schedule: 'when' and 'day' are mutually exclusive — "
                "use one (when='first'/'last' OR day=N)"
            )
        if self.when is None and self.day is None:
            # Default to first-of-month, matching RebalanceSchedule.monthly() default.
            object.__setattr__(self, "when", "first")
        if self.day is not None and not 1 <= self.day <= 31:
            raise ValueError("monthly day must be 1..31")
        return self


ScheduleSpec = Annotated[
    Union[
        EveryBarSchedule,
        EveryNBarsSchedule,
        WeeklySchedule,
        MonthlySchedule,
    ],
    Field(discriminator="type"),
]


# -----------------------------------------------------------------------------
# Top-level PortfolioStrategySpec
# -----------------------------------------------------------------------------


class PortfolioStrategySpec(BaseModel):
    """Top-level portfolio strategy specification parsed from JSON.

    Compiles down to the existing ``PortfolioStrategy`` lifecycle::

        universe -> rank -> select -> allocate

    All execution-related kwargs (cash, commission, slippage) and stops are
    represented declaratively. The ``min_drift_pct`` field hooks the v0.3.0
    drift-aware rebalance.
    """

    kind: Literal["portfolio"]
    version: Literal["0.4.0"]

    universe: UniverseFilter = UniverseFilter()
    rank: WeightedMetricsRank | None = None
    select: SelectSpec = SelectSpec()
    allocate: AllocateSpec
    schedule: ScheduleSpec = EveryBarSchedule(type="every_bar")
    stops: StopsConfig | None = None

    # Engine-level execution config (mirrors portfolio_backtest kwargs).
    initial_cash: float = 100_000.0
    commission_pct: float = 0.0
    slippage_pct: float = 0.0
    fill_policy: Literal["next_open", "current_close"] = "next_open"
    warmup_bars: int = 0
    min_drift_pct: float = 0.0
    risk_free_rate: float = 0.0

    @model_validator(mode="before")
    @classmethod
    def _normalize_legacy_flat_stops(cls, values: dict) -> dict:
        return _normalize_stops_shape(values)

    @model_validator(mode="after")
    def _rank_required_when_selecting(self) -> PortfolioStrategySpec:
        # If select.top_n is set, you need a rank to define what "top" means.
        if self.select.top_n is not None and self.rank is None:
            raise ValueError(
                "select.top_n requires a rank spec — without ranking, 'top' is undefined"
            )
        return self
