"""Typed indicator registry for JSON strategy specs.

Maps string names to indicator callables with metadata so that strategy
definitions can reference indicators by name without importing them directly.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from fastbt import indicators as ind


@dataclass(frozen=True)
class IndicatorMeta:
    """Metadata for a registered indicator."""

    name: str
    fn: Callable
    input_type: str  # "series" or "ohlcv"
    output_type: str  # "series" or "multi"
    output_names: list[str]
    param_schema: dict[str, object]  # param_name → default_value


class IndicatorRegistry:
    """Container mapping indicator names to their metadata."""

    def __init__(self) -> None:
        self._indicators: dict[str, IndicatorMeta] = {}

    def register(self, meta: IndicatorMeta) -> None:
        """Register an indicator. Overwrites if name already exists."""
        self._indicators[meta.name] = meta

    def get(self, name: str) -> IndicatorMeta:
        """Lookup by name. Raises ``KeyError`` with available names on miss."""
        try:
            return self._indicators[name]
        except KeyError:
            available = ", ".join(sorted(self._indicators))
            raise KeyError(
                f"Indicator {name!r} not found. Available: {available}"
            ) from None

    def has(self, name: str) -> bool:
        """Return True if *name* is registered."""
        return name in self._indicators

    def list_names(self) -> list[str]:
        """Return sorted list of registered indicator names."""
        return sorted(self._indicators)

    def validate_params(self, name: str, params: dict) -> None:
        """Raise ``ValueError`` if *params* contains unknown parameter names."""
        meta = self.get(name)
        unknown = set(params) - set(meta.param_schema)
        if unknown:
            valid = ", ".join(sorted(meta.param_schema))
            raise ValueError(
                f"Unknown params for {name!r}: {sorted(unknown)}. "
                f"Valid params: {valid}"
            )


# ---------------------------------------------------------------------------
# Module-level default registry, pre-populated with all indicators
# ---------------------------------------------------------------------------

default_registry = IndicatorRegistry()

_INDICATOR_DEFS: list[dict] = [
    # --- v0.0.1 indicators ---
    dict(name="sma", fn=ind.sma, input_type="series", output_type="series",
         output_names=["value"], param_schema={"period": 20}),
    dict(name="ema", fn=ind.ema, input_type="series", output_type="series",
         output_names=["value"], param_schema={"period": 20}),
    dict(name="rsi", fn=ind.rsi, input_type="series", output_type="series",
         output_names=["value"], param_schema={"period": 14}),
    dict(name="macd", fn=ind.macd, input_type="series", output_type="multi",
         output_names=["macd", "signal", "histogram"],
         param_schema={"fast": 12, "slow": 26, "signal": 9}),
    dict(name="bollinger_bands", fn=ind.bollinger_bands, input_type="series",
         output_type="multi", output_names=["middle", "upper", "lower"],
         param_schema={"period": 20, "std": 2.0}),
    dict(name="atr", fn=ind.atr, input_type="ohlcv", output_type="series",
         output_names=["value"], param_schema={"period": 14}),
    # --- v0.0.2 indicators ---
    dict(name="stochastic", fn=ind.stochastic, input_type="ohlcv",
         output_type="multi", output_names=["k", "d"],
         param_schema={"k_period": 14, "d_period": 3}),
    dict(name="adx", fn=ind.adx, input_type="ohlcv", output_type="series",
         output_names=["value"], param_schema={"period": 14}),
    dict(name="cci", fn=ind.cci, input_type="ohlcv", output_type="series",
         output_names=["value"], param_schema={"period": 20}),
    dict(name="obv", fn=ind.obv, input_type="ohlcv", output_type="series",
         output_names=["value"], param_schema={}),
    dict(name="vwap", fn=ind.vwap, input_type="ohlcv", output_type="series",
         output_names=["value"], param_schema={}),
    dict(name="supertrend", fn=ind.supertrend, input_type="ohlcv",
         output_type="multi", output_names=["supertrend", "direction"],
         param_schema={"period": 10, "multiplier": 3.0}),
    dict(name="donchian", fn=ind.donchian, input_type="ohlcv",
         output_type="multi", output_names=["upper", "lower", "middle"],
         param_schema={"period": 20}),
    dict(name="keltner", fn=ind.keltner, input_type="ohlcv",
         output_type="multi", output_names=["upper", "middle", "lower"],
         param_schema={"period": 20, "multiplier": 1.5}),
    dict(name="ichimoku", fn=ind.ichimoku, input_type="ohlcv",
         output_type="multi",
         output_names=["tenkan_sen", "kijun_sen", "senkou_a", "senkou_b"],
         param_schema={"tenkan": 9, "kijun": 26, "senkou_b": 52}),
    dict(name="williams_r", fn=ind.williams_r, input_type="ohlcv",
         output_type="series", output_names=["value"],
         param_schema={"period": 14}),
    dict(name="mfi", fn=ind.mfi, input_type="ohlcv", output_type="series",
         output_names=["value"], param_schema={"period": 14}),
    dict(name="roc", fn=ind.roc, input_type="series", output_type="series",
         output_names=["value"], param_schema={"period": 12}),
    dict(name="trix", fn=ind.trix, input_type="series", output_type="series",
         output_names=["value"], param_schema={"period": 15}),
    dict(name="kama", fn=ind.kama, input_type="series", output_type="series",
         output_names=["value"],
         param_schema={"period": 10, "fast_sc": 2, "slow_sc": 30}),
    # --- v0.3.0 indicators ---
    dict(name="pct_from_sma", fn=ind.pct_from_sma, input_type="series",
         output_type="series", output_names=["value"],
         param_schema={"period": 20}),
]

for _def in _INDICATOR_DEFS:
    default_registry.register(IndicatorMeta(**_def))
