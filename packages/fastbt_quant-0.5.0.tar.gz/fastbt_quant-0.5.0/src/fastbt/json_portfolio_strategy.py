"""JSON-driven portfolio strategy — compiles a ``PortfolioStrategySpec`` into
the existing ``PortfolioStrategy`` lifecycle (universe -> rank -> select -> allocate).

Architecture:

                    JsonPortfolioStrategy(spec)
                              │
                              ▼
               ┌─────────────────────────────┐
               │  initialize(ctx):           │
               │    no-op (lifecycle is      │
               │    fully declarative — no   │
               │    cache to populate)       │
               │                             │
               │  universe(ctx):             │
               │    apply UniverseFilter     │
               │                             │
               │  rank(ctx, universe):       │
               │    compute weighted_metrics │
               │    for each symbol          │
               │                             │
               │  select(ctx, ranked):       │
               │    top_n + direction        │
               │                             │
               │  allocate(ctx, selected):   │
               │    dispatch on method       │
               │      → equal_weight         │
               │      → momentum_weighted    │
               │      → inverse_volatility   │
               │      → risk_parity          │
               │                             │
               │  stop_config():             │
               │    forward StopsConfig      │
               └─────────────────────────────┘

The Python ``PortfolioStrategy`` subclass remains the escape hatch for
strategies whose ranking can't be expressed as ``weighted_metrics``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from fastbt.allocators import (
    annualized_volatility,
    equal_weight,
    inverse_volatility,
    momentum_score,
    momentum_weighted,
    risk_parity,
)
from fastbt.indicators import (
    adx,
    atr,
    bollinger_bands,
    cci,
    donchian,
    ema,
    ichimoku,
    kama,
    keltner,
    macd,
    mfi,
    obv,
    pct_from_sma,
    roc,
    rsi,
    sma,
    stochastic,
    supertrend,
    trix,
    vwap,
    williams_r,
)
from fastbt.portfolio_schema import (
    EqualWeightAlloc,
    EveryBarSchedule,
    EveryNBarsSchedule,
    InverseVolatilityAlloc,
    MomentumWeightedAlloc,
    MonthlySchedule,
    PortfolioStrategySpec,
    RiskParityAlloc,
    WeeklySchedule,
)
from fastbt.portfolio_strategy import PortfolioStrategy
from fastbt.schedule import RebalanceSchedule

if TYPE_CHECKING:
    from fastbt.portfolio_context import PortfolioContext
    from fastbt.portfolio_schema import WeightedIndicatorRef


# Indicator name -> callable. Mirrors registry but for series-input indicators
# only (which is what weighted_metrics ranking uses on a single symbol's price
# history). OHLCV-input indicators raise at validation time if used in ranking
# context where we only have a close series — todo-item to revisit if a real
# user needs ATR-ranked momentum.
_RANK_INDICATORS = {
    "sma": sma,
    "ema": ema,
    "rsi": rsi,
    "roc": roc,
    "trix": trix,
    "kama": kama,
    "pct_from_sma": pct_from_sma,
}

_OHLCV_RANK_INDICATORS = {
    "atr": atr,
    "adx": adx,
    "cci": cci,
    "obv": obv,
    "vwap": vwap,
    "williams_r": williams_r,
    "mfi": mfi,
    "bollinger_bands": bollinger_bands,
    "donchian": donchian,
    "keltner": keltner,
    "supertrend": supertrend,
    "ichimoku": ichimoku,
    "macd": macd,
    "stochastic": stochastic,
}


def _resolve_source(history: pd.DataFrame, source: str) -> pd.Series:
    if source == "hlc3":
        return (history["high"] + history["low"] + history["close"]) / 3
    if source == "ohlc4":
        return (history["open"] + history["high"] + history["low"] + history["close"]) / 4
    return history[source]


def _compute_metric_value(
    ref: WeightedIndicatorRef,
    history: pd.DataFrame,
) -> float | None:
    """Compute a single indicator's latest value on a symbol's price history.

    Returns ``None`` when there isn't enough history for the indicator —
    matches the Python pattern ``roc(close, 90).iloc[-1] if len(close) >= 90 else None``.
    """
    name = ref.indicator
    params = dict(ref.params)

    if name in _RANK_INDICATORS:
        fn = _RANK_INDICATORS[name]
        series = _resolve_source(history, ref.source)
        result = fn(series, **params)
        if isinstance(result, pd.DataFrame):
            value = result[ref.output].iloc[-1]
        else:
            value = result.iloc[-1]
    elif name in _OHLCV_RANK_INDICATORS:
        fn = _OHLCV_RANK_INDICATORS[name]
        # OHLCV-input indicators take named columns; pass the ones the function expects.
        import inspect

        sig = inspect.signature(fn)
        kwargs: dict = {}
        ohlcv_cols = {"high", "low", "close", "volume", "open"}
        for pname in sig.parameters:
            if pname in ohlcv_cols:
                kwargs[pname] = history[pname]
            elif pname in params:
                kwargs[pname] = params[pname]
        result = fn(**kwargs)
        if isinstance(result, pd.DataFrame):
            value = result[ref.output].iloc[-1]
        else:
            value = result.iloc[-1]
    else:
        # Caught earlier by Pydantic validation, but keep a defensive path.
        return None

    # Apply offset (negative offset reads earlier bars).
    if ref.offset != 0:
        idx = -1 + ref.offset
        if isinstance(result, pd.DataFrame):
            series_obj = result[ref.output]
        else:
            series_obj = result
        if abs(idx) > len(series_obj):
            return None
        value = series_obj.iloc[idx]

    if pd.isna(value):
        return None
    return float(value)


class JsonPortfolioStrategy(PortfolioStrategy):
    """A ``PortfolioStrategy`` driven by a ``PortfolioStrategySpec`` instead of Python code.

    Usage::

        spec = PortfolioStrategySpec.model_validate(json_dict)
        strategy = JsonPortfolioStrategy(spec)
        result = portfolio_backtest(strategy, data, ...)

    Or via the unified loader::

        strategy = load_strategy(json_dict)
    """

    def __init__(self, spec: PortfolioStrategySpec, params: dict | None = None) -> None:
        super().__init__(params=params)
        self.spec = spec

    def initialize(self, ctx: PortfolioContext) -> None:
        # Lifecycle is fully declarative — no per-strategy cache to populate.
        pass

    def stop_config(self) -> dict | None:
        if self.spec.stops is None:
            return None
        cfg = self.spec.stops.to_engine_dict()
        return cfg or None

    def universe(self, ctx: PortfolioContext) -> list[str]:
        uf = self.spec.universe
        symbols = list(ctx.symbols)
        out: list[str] = []
        for sym in symbols:
            hist = ctx.history.get(sym)
            if hist is None:
                continue
            if uf.min_history is not None and len(hist) < uf.min_history:
                continue
            if uf.min_avg_volume is not None:
                avg_vol = float(hist["volume"].mean())
                if avg_vol < uf.min_avg_volume:
                    continue
            out.append(sym)
        if uf.max_symbols is not None:
            out = out[: uf.max_symbols]
        return out

    def rank(
        self, ctx: PortfolioContext, universe: list[str]
    ) -> list[tuple[str, float]]:
        rank_spec = self.spec.rank
        if rank_spec is None:
            # No ranking — equal score, input order preserved.
            return [(sym, 1.0) for sym in universe]

        # Pre-compute weight dict once.
        weights = {f"_m{i}": ref.weight for i, ref in enumerate(rank_spec.metrics)}
        scored: list[tuple[str, float]] = []
        for sym in universe:
            hist = ctx.history[sym]
            metrics: dict[str, float | None] = {}
            for i, ref in enumerate(rank_spec.metrics):
                # Skip metrics whose lookback exceeds available history.
                lookback = ref.params.get("period")
                if (
                    isinstance(lookback, (int, float))
                    and len(hist) <= int(lookback)
                ):
                    metrics[f"_m{i}"] = None
                else:
                    metrics[f"_m{i}"] = _compute_metric_value(ref, hist)
            score = momentum_score(metrics, weights)
            scored.append((sym, score))
        # Stable sort — input order is the tiebreaker (matches Python `sorted`).
        return sorted(scored, key=lambda x: x[1], reverse=True)

    def select(
        self, ctx: PortfolioContext, ranked: list[tuple[str, float]]
    ) -> list[str]:
        s = self.spec.select
        if s.direction == "asc":
            ranked = list(reversed(ranked))
        if s.top_n is None:
            return [sym for sym, _ in ranked]
        return [sym for sym, _ in ranked[: s.top_n]]

    def allocate(
        self, ctx: PortfolioContext, selected: list[str]
    ) -> dict[str, float]:
        a = self.spec.allocate
        if isinstance(a, EqualWeightAlloc):
            return equal_weight(selected)
        if isinstance(a, MomentumWeightedAlloc):
            # Re-rank to get scores keyed by symbol — small duplication of work,
            # but keeps the lifecycle pure (rank() is called once before this).
            scores = dict(self.rank(ctx, selected))
            return momentum_weighted(selected, scores)
        if isinstance(a, InverseVolatilityAlloc):
            vols = {
                sym: annualized_volatility(
                    ctx.history[sym]["close"], lookback=a.vol_lookback
                )
                for sym in selected
            }
            return inverse_volatility(selected, vols)
        if isinstance(a, RiskParityAlloc):
            vols = {
                sym: annualized_volatility(
                    ctx.history[sym]["close"], lookback=a.vol_lookback
                )
                for sym in selected
            }
            return risk_parity(selected, vols)
        # Should be unreachable — discriminated union exhausts all cases.
        raise ValueError(f"Unknown allocator method: {a!r}")


def schedule_from_spec(spec: PortfolioStrategySpec) -> RebalanceSchedule:
    """Translate a ``ScheduleSpec`` into a ``RebalanceSchedule``."""
    s = spec.schedule
    if isinstance(s, EveryBarSchedule):
        return RebalanceSchedule.every_bar()
    if isinstance(s, EveryNBarsSchedule):
        return RebalanceSchedule.every_n_bars(s.n)
    if isinstance(s, WeeklySchedule):
        return RebalanceSchedule.weekly(day=s.day)
    if isinstance(s, MonthlySchedule):
        if s.day is not None:
            return RebalanceSchedule.monthly(day=s.day)
        return RebalanceSchedule.monthly(when=s.when or "first")
    raise ValueError(f"Unknown schedule type: {s!r}")
