"""Portfolio backtest result — equity curve, per-symbol breakdown, and metrics."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import pandas as pd

from fastbt.result import Metrics, _pair_fills_into_trades
from fastbt.types import Fill, OrderSide

if TYPE_CHECKING:
    from fastbt.engine import StopOutEvent


@dataclass
class PortfolioResult:
    """Complete result of a portfolio backtest run."""

    equity_curve: pd.Series
    fills: list[Fill]
    metrics: Metrics
    initial_cash: float
    final_cash: float
    weight_history: pd.DataFrame
    per_symbol_pnl: dict[str, float]
    turnover: float
    stop_outs: list[StopOutEvent] = field(default_factory=list)

    def __repr__(self) -> str:
        m = self.metrics
        n_symbols = len(self.per_symbol_pnl)
        return (
            f"PortfolioResult(symbols={n_symbols}, "
            f"trades={m.num_trades}, return={m.total_return_pct:.2f}%, "
            f"max_dd={m.max_drawdown_pct:.2f}%, sharpe={m.sharpe:.2f})"
        )

    @classmethod
    def build(
        cls,
        equity_values: list[float],
        equity_index: list[pd.Timestamp],
        fills: list[Fill],
        initial_cash: float,
        final_cash: float,
        weight_records: list[dict[str, float]],
        symbols: list[str],
        risk_free_rate: float = 0.0,
        stop_outs: list[StopOutEvent] | None = None,
    ) -> PortfolioResult:
        """Construct a PortfolioResult from raw engine output."""
        equity_series = pd.Series(
            equity_values,
            index=pd.DatetimeIndex(equity_index),
            name="equity",
        )

        metrics = Metrics.from_equity_curve(
            equity=equity_series,
            initial_cash=initial_cash,
            fills=fills,
            risk_free_rate=risk_free_rate,
        )

        # Weight history DataFrame
        weight_history = pd.DataFrame(
            weight_records,
            index=pd.DatetimeIndex(equity_index),
        )
        # Fill missing symbols with 0.0
        for sym in symbols:
            if sym not in weight_history.columns:
                weight_history[sym] = 0.0
        weight_history = weight_history.fillna(0.0)
        weight_history = weight_history[sorted(weight_history.columns)]

        # Per-symbol PnL
        per_symbol_pnl = _compute_per_symbol_pnl(fills)

        # Turnover: two-way, as fraction of portfolio value
        turnover = _compute_turnover(weight_history)

        return cls(
            equity_curve=equity_series,
            fills=fills,
            metrics=metrics,
            initial_cash=initial_cash,
            final_cash=final_cash,
            weight_history=weight_history,
            per_symbol_pnl=per_symbol_pnl,
            turnover=turnover,
            stop_outs=list(stop_outs or []),
        )


def _compute_per_symbol_pnl(fills: list[Fill]) -> dict[str, float]:
    """Compute total PnL per symbol from fills."""
    by_symbol: dict[str, list[Fill]] = {}
    for f in fills:
        by_symbol.setdefault(f.symbol, []).append(f)

    result: dict[str, float] = {}
    for sym, sym_fills in by_symbol.items():
        trade_pnls = _pair_fills_into_trades(sym_fills)
        result[sym] = round(sum(trade_pnls), 2)
    return result


def _compute_turnover(weight_history: pd.DataFrame) -> float:
    """Compute two-way turnover as fraction of portfolio value.

    Turnover = mean of (sum of |weight_change| / 2) across all rebalance bars.
    """
    if len(weight_history) < 2:
        return 0.0
    diffs = weight_history.diff().iloc[1:]  # skip first row (NaN)
    per_bar_turnover = diffs.abs().sum(axis=1) / 2.0
    return round(float(per_bar_turnover.mean()), 6)
