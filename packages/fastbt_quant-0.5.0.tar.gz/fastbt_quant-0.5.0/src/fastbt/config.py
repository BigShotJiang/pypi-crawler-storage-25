"""Persistent configuration stored in ~/.fastbt/config.toml."""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any

CONFIG_DIR = Path.home() / ".fastbt"
CONFIG_FILE = CONFIG_DIR / "config.toml"

# Maps CLI key names to TOML paths: "idata-api-key" → ("idata", "api_key")
_KEY_MAP: dict[str, tuple[str, str]] = {
    "idata-api-key": ("idata", "api_key"),
    "idata-base-url": ("idata", "base_url"),
}


def load_config() -> dict[str, Any]:
    """Load config from ~/.fastbt/config.toml, returning empty dict if missing."""
    if not CONFIG_FILE.exists():
        return {}
    return tomllib.loads(CONFIG_FILE.read_text())


def get(section: str, key: str, default: str | None = None) -> str | None:
    """Read a single config value. Returns *default* if not set."""
    cfg = load_config()
    return cfg.get(section, {}).get(key, default)


def set_value(cli_key: str, value: str) -> None:
    """Write a config value using the CLI key name (e.g. 'idata-api-key')."""
    if cli_key not in _KEY_MAP:
        valid = ", ".join(sorted(_KEY_MAP))
        raise KeyError(f"Unknown config key '{cli_key}'. Valid keys: {valid}")

    section, key = _KEY_MAP[cli_key]
    cfg = load_config()
    cfg.setdefault(section, {})[key] = value

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(_dump_toml(cfg))


def _dump_toml(cfg: dict[str, Any]) -> str:
    """Minimal TOML serializer for our flat section→key→string structure."""
    lines: list[str] = []
    for section, values in sorted(cfg.items()):
        if isinstance(values, dict):
            lines.append(f"[{section}]")
            for k, v in sorted(values.items()):
                lines.append(f'{k} = "{v}"')
            lines.append("")
    return "\n".join(lines) + "\n"
