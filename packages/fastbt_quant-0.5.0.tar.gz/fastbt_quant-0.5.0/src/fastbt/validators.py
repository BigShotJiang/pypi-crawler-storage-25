"""OHLCV schema validation."""

from __future__ import annotations

import pandas as pd

REQUIRED_COLUMNS = ("open", "high", "low", "close", "volume")


class OHLCVValidationError(ValueError):
    """Raised when a DataFrame fails OHLCV schema validation."""


def validate_ohlcv(df: pd.DataFrame) -> None:
    """Validate that `df` has a proper OHLCV schema.

    Contract:
        - Type: pd.DataFrame
        - Columns: open, high, low, close, volume (case-insensitive)
        - Index: pd.DatetimeIndex, monotonic increasing, no duplicates
        - No NaN in OHLCV columns
        - high >= max(open, close); low <= min(open, close)
        - volume >= 0

    Raises:
        OHLCVValidationError on any contract violation.
    """
    if not isinstance(df, pd.DataFrame):
        raise OHLCVValidationError(f"Expected pd.DataFrame, got {type(df).__name__}")

    cols_lower = {c.lower(): c for c in df.columns}
    missing = set(REQUIRED_COLUMNS) - set(cols_lower.keys())
    if missing:
        raise OHLCVValidationError(f"Missing required columns: {sorted(missing)}")

    if not isinstance(df.index, pd.DatetimeIndex):
        raise OHLCVValidationError(
            f"Index must be pd.DatetimeIndex, got {type(df.index).__name__}"
        )

    if not df.index.is_monotonic_increasing:
        raise OHLCVValidationError("Index must be monotonic increasing")

    if df.index.has_duplicates:
        raise OHLCVValidationError("Index must not have duplicate timestamps")

    ohlcv = df.rename(columns={cols_lower[c]: c for c in REQUIRED_COLUMNS})[list(REQUIRED_COLUMNS)]

    if ohlcv.isna().any().any():
        raise OHLCVValidationError("OHLCV columns must not contain NaN values")

    max_oc = ohlcv[["open", "close"]].max(axis=1)
    min_oc = ohlcv[["open", "close"]].min(axis=1)

    if (ohlcv["high"] < max_oc).any():
        raise OHLCVValidationError("'high' must be >= max(open, close) for every bar")

    if (ohlcv["low"] > min_oc).any():
        raise OHLCVValidationError("'low' must be <= min(open, close) for every bar")

    if (ohlcv["volume"] < 0).any():
        raise OHLCVValidationError("'volume' must be >= 0")
