"""Backtest result — equity curve, fills, and computed metrics."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

from fastbt.types import Fill, OrderSide

if TYPE_CHECKING:
    from fastbt.engine import StopOutEvent


TRADING_DAYS_PER_YEAR = 252


@dataclass(frozen=True)
class Metrics:
    """Summary metrics for a backtest run.

    The ``cagr``, ``sortino``, and ``annual_volatility`` fields default to
    ``0.0`` so existing positional construction (and old serialized results)
    keep working after the v0.3.0 metric expansion.
    """

    total_return: float
    total_return_pct: float
    max_drawdown_pct: float
    sharpe: float
    num_trades: int
    win_rate_pct: float
    profit_factor: float
    avg_trade_pnl: float
    cagr: float = 0.0
    sortino: float = 0.0
    annual_volatility: float = 0.0

    @classmethod
    def from_equity_curve(
        cls,
        equity: pd.Series,
        initial_cash: float,
        fills: list[Fill],
        risk_free_rate: float = 0.0,
    ) -> Metrics:
        """Compute summary metrics from an equity curve and fill list.

        Args:
            equity: Equity curve (Series indexed by timestamp).
            initial_cash: Starting cash for return calculations.
            fills: All fills, used for trade pairing / win-rate.
            risk_free_rate: Annual risk-free rate (percent, e.g. ``6.0`` for
                6%/year). Subtracted from returns before computing Sharpe and
                Sortino. Default ``0.0`` (international convention) — set per
                market when needed.
        """
        if len(equity) == 0:
            return cls(0.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)

        final = float(equity.iloc[-1])
        total_return = final - initial_cash
        total_return_pct = (total_return / initial_cash) * 100.0 if initial_cash else 0.0

        running_max = equity.cummax()
        dd_series = (equity - running_max) / running_max * 100.0
        dd_min = dd_series.min()
        max_dd = float(abs(dd_min)) if not math.isnan(dd_min) else 0.0

        returns = equity.pct_change().dropna()
        # Per-period risk-free rate — convert annual % to daily decimal
        rf_daily = (risk_free_rate / 100.0) / TRADING_DAYS_PER_YEAR
        excess = returns - rf_daily

        if len(returns) > 1 and returns.std() > 0:
            sharpe = float(
                (excess.mean() / returns.std()) * np.sqrt(TRADING_DAYS_PER_YEAR)
            )
            annual_vol = float(returns.std() * np.sqrt(TRADING_DAYS_PER_YEAR) * 100.0)
        else:
            sharpe = 0.0
            annual_vol = 0.0

        # Sortino — uses downside deviation only.
        # Convention: 999.99 when there's no downside but positive excess;
        # 0.0 when there's neither downside nor positive excess.
        if len(returns) > 1:
            downside = excess.where(excess < 0, 0.0)
            downside_std = float(np.sqrt((downside ** 2).mean()))
            mean_excess = float(excess.mean())
            if downside_std > 0:
                sortino = (mean_excess / downside_std) * np.sqrt(TRADING_DAYS_PER_YEAR)
            elif mean_excess > 0:
                sortino = 999.99
            else:
                sortino = 0.0
        else:
            sortino = 0.0

        # CAGR — annualized total return over the trading-day count.
        if initial_cash > 0 and final > 0 and len(equity) > 1:
            growth = final / initial_cash
            years = len(equity) / TRADING_DAYS_PER_YEAR
            cagr = float((growth ** (1 / years) - 1) * 100.0)
        elif initial_cash > 0 and len(equity) > 1:
            # final <= 0 — total loss, CAGR is -100%
            cagr = -100.0
        else:
            cagr = 0.0

        trade_pnls = _pair_fills_into_trades(fills)
        num_trades = len(trade_pnls)
        if num_trades > 0:
            wins = [p for p in trade_pnls if p > 0]
            losses = [p for p in trade_pnls if p <= 0]
            win_rate = (len(wins) / num_trades) * 100.0
            gross_profit = sum(wins) if wins else 0.0
            gross_loss = abs(sum(losses)) if losses else 0.0
            if gross_loss > 0:
                profit_factor = gross_profit / gross_loss
            elif gross_profit > 0:
                profit_factor = 999.99
            else:
                profit_factor = 0.0
            avg_pnl = sum(trade_pnls) / num_trades
        else:
            win_rate = 0.0
            profit_factor = 0.0
            avg_pnl = 0.0

        return cls(
            total_return=round(total_return, 2),
            total_return_pct=round(total_return_pct, 2),
            max_drawdown_pct=round(max_dd, 2),
            sharpe=round(sharpe, 2),
            num_trades=num_trades,
            win_rate_pct=round(win_rate, 2),
            profit_factor=round(profit_factor, 2),
            avg_trade_pnl=round(avg_pnl, 2),
            cagr=round(cagr, 2),
            sortino=round(sortino, 2),
            annual_volatility=round(annual_vol, 2),
        )


def _pair_fills_into_trades(fills: list[Fill]) -> list[float]:
    """Direction-aware FIFO trade pairing.

    Tracks running position per symbol. A trade is completed when the
    position returns to zero or flips through zero. Handles:
    - Long entries (buy) and exits (sell)
    - Short entries (sell) and exits (buy)
    - Position flips (one fill closes + opens the opposite side)
    - Partial closes
    - Adding to existing positions (weighted-average entry)
    """
    by_symbol: dict[str, list[Fill]] = {}
    for f in fills:
        by_symbol.setdefault(f.symbol, []).append(f)

    pnls: list[float] = []
    for sym_fills in by_symbol.values():
        qty = 0.0
        avg_entry = 0.0
        entry_comm = 0.0

        for fill in sym_fills:
            delta = fill.qty if fill.side == OrderSide.BUY else -fill.qty
            new_qty = qty + delta

            if qty == 0:
                # Opening new position
                avg_entry = fill.price
                entry_comm = fill.commission
            elif (qty > 0 and new_qty <= 0) or (qty < 0 and new_qty >= 0):
                # Closing (possibly flipping through zero)
                close_qty = abs(qty)
                if qty > 0:
                    pnl = (fill.price - avg_entry) * close_qty
                else:
                    pnl = (avg_entry - fill.price) * close_qty
                pnl -= entry_comm + fill.commission
                pnls.append(pnl)

                if new_qty != 0:
                    # Flipped — remainder starts a new position
                    avg_entry = fill.price
                    entry_comm = 0.0
                else:
                    avg_entry = 0.0
                    entry_comm = 0.0
            elif (qty > 0 and delta > 0) or (qty < 0 and delta < 0):
                # Adding to position — weighted average
                total_cost = avg_entry * abs(qty) + fill.price * abs(delta)
                avg_entry = total_cost / abs(new_qty)
                entry_comm += fill.commission
            else:
                # Partial close (reducing without crossing zero)
                close_qty = abs(delta)
                if qty > 0:
                    pnl = (fill.price - avg_entry) * close_qty
                else:
                    pnl = (avg_entry - fill.price) * close_qty
                pnl -= fill.commission
                remaining_frac = abs(new_qty) / abs(qty) if qty != 0 else 0
                entry_comm *= remaining_frac
                pnls.append(pnl)

            qty = new_qty

    return pnls


@dataclass
class BacktestResult:
    """Complete result of a backtest run."""

    equity_curve: pd.Series
    fills: list[Fill]
    metrics: Metrics
    initial_cash: float
    final_cash: float
    stop_outs: list[StopOutEvent] = field(default_factory=list)

    def __repr__(self) -> str:
        m = self.metrics
        return (
            f"BacktestResult(trades={m.num_trades}, return={m.total_return_pct:.2f}%, "
            f"max_dd={m.max_drawdown_pct:.2f}%, sharpe={m.sharpe:.2f}, "
            f"win_rate={m.win_rate_pct:.1f}%)"
        )
