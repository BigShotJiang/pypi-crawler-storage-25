"""Core value types for fastbt."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import NewType

import pandas as pd

OrderId = NewType("OrderId", str)


class OrderSide(str, Enum):
    BUY = "buy"
    SELL = "sell"


class OrderType(str, Enum):
    MARKET = "market"
    # LIMIT, STOP, STOP_LIMIT reserved for later versions


class OrderStatus(str, Enum):
    PENDING = "pending"
    FILLED = "filled"
    CANCELLED = "cancelled"
    REJECTED = "rejected"


@dataclass(frozen=True, slots=True)
class Bar:
    """A single OHLCV bar for one symbol at one timestamp.

    ``symbol`` carries the instrument identity end-to-end so the broker can
    match a fill to the correct bar's price even when bars for many symbols
    are processed in sequence (portfolio mode).
    """

    timestamp: pd.Timestamp
    symbol: str
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(slots=True)
class Order:
    """An order submitted to a broker."""

    id: OrderId
    symbol: str
    side: OrderSide
    qty: float
    type: OrderType = OrderType.MARKET
    submitted_at: pd.Timestamp | None = None
    status: OrderStatus = OrderStatus.PENDING


@dataclass(frozen=True, slots=True)
class Fill:
    """A filled order with execution price and timestamp."""

    order_id: OrderId
    symbol: str
    side: OrderSide
    qty: float
    price: float
    timestamp: pd.Timestamp
    commission: float = 0.0


@dataclass(slots=True)
class Position:
    """A position in a single symbol."""

    symbol: str
    qty: float = 0.0
    avg_entry_price: float = 0.0

    @property
    def is_flat(self) -> bool:
        return self.qty == 0.0

    @property
    def is_long(self) -> bool:
        return self.qty > 0.0

    @property
    def is_short(self) -> bool:
        return self.qty < 0.0

    def market_value(self, price: float) -> float:
        return self.qty * price

    def unrealized_pnl(self, price: float) -> float:
        if self.is_flat:
            return 0.0
        return (price - self.avg_entry_price) * self.qty
