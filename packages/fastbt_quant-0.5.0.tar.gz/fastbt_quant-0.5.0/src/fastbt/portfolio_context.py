"""Execution context for portfolio strategies."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from fastbt.types import Bar, Position

if TYPE_CHECKING:
    from fastbt.broker import Broker


class PortfolioContext:
    """Runtime context for a portfolio strategy.

    Provides:
      - ``bars``      — current bar for each symbol.
      - ``positions`` — current position for each symbol.
      - ``weights``   — actual portfolio weights (position value / equity).
      - ``cash``      — available cash.
      - ``equity``    — total portfolio value (cash + all position values).
      - ``history``   — all bars up to and including the current bar, per symbol.
      - ``symbols``   — list of all symbols in the universe.
      - ``params``    — user-supplied strategy parameters.

    The engine rebuilds this context each bar before calling ``on_rebalance``.
    """

    def __init__(
        self,
        bars: dict[str, Bar],
        positions: dict[str, Position],
        cash: float,
        equity: float,
        history: dict[str, pd.DataFrame],
        symbols: list[str],
        params: dict,
        broker: Broker,
        bar_index: int = 0,
        rebalance_count: int = 0,
    ):
        self.bars = bars
        self.positions = positions
        self._cash = cash
        self._equity = equity
        self.history = history
        self.symbols = symbols
        self.params = params
        self._broker = broker
        self.bar_index = bar_index
        self.rebalance_count = rebalance_count

    @property
    def cash(self) -> float:
        return self._cash

    @property
    def equity(self) -> float:
        return self._equity

    @property
    def weights(self) -> dict[str, float]:
        """Actual portfolio weights based on current positions and prices."""
        if self._equity <= 0:
            return {}
        result: dict[str, float] = {}
        for sym, pos in self.positions.items():
            if not pos.is_flat and sym in self.bars:
                mv = pos.market_value(self.bars[sym].close)
                result[sym] = mv / self._equity
        return result
