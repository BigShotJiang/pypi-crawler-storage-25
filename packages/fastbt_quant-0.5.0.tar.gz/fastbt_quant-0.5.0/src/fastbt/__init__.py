"""fastbt — Pandas-native backtesting with backtest/live parity."""

from fastbt.broker import Broker, PaperBroker
from fastbt.context import Context
from fastbt.engine import StopOutEvent, backtest, portfolio_backtest
from fastbt.json_portfolio_strategy import JsonPortfolioStrategy, schedule_from_spec
from fastbt.json_strategy import JsonStrategy
from fastbt.loader import load_strategy
from fastbt.portfolio_context import PortfolioContext
from fastbt.portfolio_result import PortfolioResult
from fastbt.portfolio_schema import PortfolioStrategySpec
from fastbt.portfolio_strategy import PortfolioStrategy
from fastbt.result import BacktestResult, Metrics
from fastbt.schedule import RebalanceSchedule
from fastbt.schema import StopsConfig, StrategySpec
from fastbt.serialization import load_result, save_result
from fastbt.signal_engine import SignalEngine
from fastbt.signal_types import SignalPayload, SignalType
from fastbt.strategy import Strategy
from fastbt.types import (
    Bar,
    Fill,
    Order,
    OrderId,
    OrderSide,
    OrderStatus,
    OrderType,
    Position,
)
from fastbt.validators import OHLCVValidationError, validate_ohlcv

__version__ = "0.5.0"


def __getattr__(name: str):
    if name == "IdataClient":
        try:
            from fastbt.data import IdataClient
        except ImportError as exc:
            raise ImportError(
                "IdataClient requires the 'data' extra. "
                "Install with: pip install fastbt-quant[data]"
            ) from exc
        return IdataClient
    raise AttributeError(f"module 'fastbt' has no attribute {name!r}")

__all__ = [
    "Bar",
    "BacktestResult",
    "IdataClient",
    "Broker",
    "Context",
    "Fill",
    "JsonPortfolioStrategy",
    "JsonStrategy",
    "Metrics",
    "OHLCVValidationError",
    "Order",
    "OrderId",
    "OrderSide",
    "OrderStatus",
    "OrderType",
    "PaperBroker",
    "PortfolioContext",
    "PortfolioResult",
    "PortfolioStrategy",
    "PortfolioStrategySpec",
    "Position",
    "RebalanceSchedule",
    "SignalEngine",
    "SignalPayload",
    "SignalType",
    "StopOutEvent",
    "StopsConfig",
    "Strategy",
    "StrategySpec",
    "backtest",
    "load_result",
    "load_strategy",
    "portfolio_backtest",
    "save_result",
    "schedule_from_spec",
    "validate_ohlcv",
]
