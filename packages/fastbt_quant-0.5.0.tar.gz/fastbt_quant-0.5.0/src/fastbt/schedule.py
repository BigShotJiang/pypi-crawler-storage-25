"""Rebalance schedule — determines when on_rebalance fires."""

from __future__ import annotations

from typing import Callable

import pandas as pd


class RebalanceSchedule:
    """Determines whether a given bar is a rebalance bar.

    Use the named constructors to create instances::

        schedule = RebalanceSchedule.weekly(day=4)      # every Friday
        schedule = RebalanceSchedule.monthly("last")     # last trading day of month
        schedule = RebalanceSchedule.every_n_bars(5)     # every 5th bar
        schedule = RebalanceSchedule.custom(my_func)     # arbitrary predicate

    The schedule operates on whatever timestamps exist in the data.
    Holidays and missing sessions are handled implicitly: if a weekday
    has no bar, the schedule simply doesn't fire that day.
    """

    def __init__(
        self,
        predicate: Callable[[pd.Timestamp, int], bool],
        label: str = "custom",
    ):
        self._predicate = predicate
        self._label = label

    def should_rebalance(self, ts: pd.Timestamp, bar_index: int) -> bool:
        """Return True if the strategy should rebalance on this bar."""
        return self._predicate(ts, bar_index)

    def _prepare(self, index: pd.DatetimeIndex) -> None:
        """Called by the engine before the bar loop with the full aligned index.

        Most schedules ignore this. Monthly "last" uses it to pre-compute
        which timestamps are the last trading day of each month.
        """

    @staticmethod
    def every_bar() -> RebalanceSchedule:
        """Rebalance on every bar."""
        return RebalanceSchedule(lambda ts, i: True, label="every_bar")

    @staticmethod
    def every_n_bars(n: int) -> RebalanceSchedule:
        """Rebalance every N bars (0-indexed: fires on bars 0, N, 2N, ...)."""
        if n < 1:
            raise ValueError(f"n must be >= 1, got {n}")
        return RebalanceSchedule(lambda ts, i: i % n == 0, label=f"every_{n}_bars")

    @staticmethod
    def weekly(day: int = 4) -> RebalanceSchedule:
        """Rebalance on a specific weekday. 0=Monday ... 4=Friday ... 6=Sunday.

        If the target weekday has no bar (holiday), no rebalance occurs
        that week. This is intentional: the schedule fires on bars that
        exist, not on calendar days.
        """
        if not 0 <= day <= 6:
            raise ValueError(f"day must be 0-6, got {day}")
        day_names = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
        return RebalanceSchedule(
            lambda ts, i: ts.weekday() == day,
            label=f"weekly({day_names[day]})",
        )

    @staticmethod
    def monthly(
        when: str = "first",
        *,
        day: int | None = None,
    ) -> RebalanceSchedule:
        """Rebalance on a specific day of each month.

        Three forms:

        - ``monthly("first")``: fires on the first bar of each new month
          (detected by comparing with the previous bar's month).
        - ``monthly("last")``: fires on the last bar before the month changes.
        - ``monthly(day=N)``: fires on the first trading day on or after
          day N of each month. If day N is past the last trading day of the
          month (e.g. ``day=30`` in February), the schedule **clamps** to the
          last trading day of that month — preserving the
          one-rebalance-per-month invariant. ``day`` must be 1..31.

        All three pre-compute the firing timestamps via ``_prepare(index)``
        which the engine calls before the bar loop.

        Args:
            when: ``"first"`` or ``"last"`` (ignored when ``day`` is set).
            day: Day of month, 1..31. Mutually exclusive with ``when``.
        """
        if day is not None:
            if not 1 <= day <= 31:
                raise ValueError(f"day must be 1..31, got {day}")
            return _MonthlyDayNSchedule(day)

        if when not in ("first", "last"):
            raise ValueError(f"when must be 'first' or 'last', got {when!r}")

        if when == "first":
            return _MonthlyFirstSchedule()
        return _MonthlyLastSchedule()

    @staticmethod
    def custom(predicate: Callable[[pd.Timestamp, int], bool]) -> RebalanceSchedule:
        """Rebalance when the predicate returns True.

        The predicate receives ``(timestamp, bar_index)`` and should
        return a bool.
        """
        return RebalanceSchedule(predicate, label="custom")

    def __repr__(self) -> str:
        return f"RebalanceSchedule({self._label})"


class _MonthlyFirstSchedule(RebalanceSchedule):
    """Fires on the first trading day of each month."""

    def __init__(self) -> None:
        self._prev_month: tuple[int, int] | None = None
        super().__init__(predicate=self._check, label="monthly(first)")

    def _check(self, ts: pd.Timestamp, bar_index: int) -> bool:
        current = (ts.year, ts.month)
        if self._prev_month is None or current != self._prev_month:
            self._prev_month = current
            return True
        return False

    def _prepare(self, index: pd.DatetimeIndex) -> None:
        # Reset state for a fresh run
        self._prev_month = None


class _MonthlyLastSchedule(RebalanceSchedule):
    """Fires on the last trading day of each month.

    Requires ``_prepare(index)`` to be called before the bar loop.
    """

    def __init__(self) -> None:
        self._last_days: set[pd.Timestamp] | None = None
        super().__init__(predicate=self._check, label="monthly(last)")

    def _check(self, ts: pd.Timestamp, bar_index: int) -> bool:
        if self._last_days is None:
            raise RuntimeError(
                "monthly('last') schedule requires _prepare(index) to be "
                "called before use. This is normally done by the engine."
            )
        return ts in self._last_days

    def _prepare(self, index: pd.DatetimeIndex) -> None:
        # Group by (year, month), take the last timestamp in each group
        series = index.to_series()
        last_per_month = series.groupby(
            [series.dt.year, series.dt.month]
        ).last()
        self._last_days = set(last_per_month.values)


class _MonthlyDayNSchedule(RebalanceSchedule):
    """Fires on the first trading day on or after day N of each month.

    If day N is past the month's last trading day, clamps to the last
    trading day of that month so each month gets exactly one rebalance.

    Pre-computed via ``_prepare(index)``.
    """

    def __init__(self, day: int) -> None:
        self._day = day
        self._fire_days: set[pd.Timestamp] | None = None
        super().__init__(predicate=self._check, label=f"monthly(day={day})")

    def _check(self, ts: pd.Timestamp, bar_index: int) -> bool:
        if self._fire_days is None:
            raise RuntimeError(
                f"monthly(day={self._day}) requires _prepare(index) to be "
                "called before use. This is normally done by the engine."
            )
        return ts in self._fire_days

    def _prepare(self, index: pd.DatetimeIndex) -> None:
        # For each (year, month), pick the first bar with day >= N.
        # If none exists (e.g. day=30 in Feb), clamp to the month's last bar.
        series = index.to_series()
        groups = series.groupby([series.dt.year, series.dt.month])
        fire_days: set[pd.Timestamp] = set()
        for _key, group in groups:
            on_or_after = group[group.dt.day >= self._day]
            if len(on_or_after) > 0:
                fire_days.add(on_or_after.iloc[0])
            else:
                # Clamp: day N doesn't exist this month, use last trading day
                fire_days.add(group.iloc[-1])
        self._fire_days = fire_days
