"""Unified strategy loader — dispatches a JSON spec to the right strategy class.

A single entry point hides the Spec/Strategy class distinction so users can
load any strategy with one call::

    strategy = load_strategy(json_dict)
    # → JsonStrategy (single-symbol) or JsonPortfolioStrategy (portfolio)

Smart kind defaulting (D10): if the spec has no ``kind`` field, we infer
``"single"`` only when the spec has ``entry``/``exit`` keys (the unmistakable
single-symbol shape). Otherwise we raise a clear error asking the user to
add ``kind: "portfolio"`` — silent misroutes are exactly the bug class to avoid.
"""

from __future__ import annotations

import json
from typing import Any, Union

from fastbt.json_portfolio_strategy import JsonPortfolioStrategy
from fastbt.json_strategy import JsonStrategy
from fastbt.portfolio_schema import PortfolioStrategySpec
from fastbt.schema import StrategySpec


def load_strategy(
    json_or_dict: Union[str, dict, bytes],
    params: dict | None = None,
) -> JsonStrategy | JsonPortfolioStrategy:
    """Load a JSON strategy spec and return a ready-to-backtest strategy.

    Accepts a dict, JSON string, or JSON bytes. Returns either a
    :class:`JsonStrategy` (single-symbol) or :class:`JsonPortfolioStrategy`
    (portfolio) based on the spec's ``kind`` field.

    Args:
        json_or_dict: Strategy spec as a Python dict, a JSON string, or bytes.
        params: Optional extra params forwarded to the Strategy constructor.

    Returns:
        A strategy instance matching the spec's kind.

    Raises:
        ValueError: If the spec lacks a ``kind`` field and doesn't look like a
            single-symbol spec (no ``entry``/``exit``). The user should add
            ``kind: "portfolio"`` to disambiguate.
        pydantic.ValidationError: If the spec fails schema validation.
        json.JSONDecodeError: If a string/bytes input is not valid JSON.
    """
    if isinstance(json_or_dict, (str, bytes)):
        try:
            data = json.loads(json_or_dict)
        except json.JSONDecodeError as exc:
            msg = f"Could not parse input as JSON: {exc.msg}"
            raise ValueError(msg) from exc
    elif isinstance(json_or_dict, dict):
        data = json_or_dict
    else:
        raise TypeError(
            f"load_strategy expects dict, str, or bytes; got {type(json_or_dict).__name__}"
        )

    kind = _resolve_kind(data)

    if kind == "single":
        single_spec = StrategySpec.model_validate(data)
        return JsonStrategy(single_spec, params=params)
    if kind == "portfolio":
        portfolio_spec = PortfolioStrategySpec.model_validate(data)
        return JsonPortfolioStrategy(portfolio_spec, params=params)

    # Unreachable — _resolve_kind raises before we get here.
    raise ValueError(f"Unknown spec kind: {kind!r}")


def _resolve_kind(data: dict[str, Any]) -> str:
    """Smart kind dispatch (D10).

    - Explicit ``kind`` always wins.
    - No ``kind`` AND has ``entry``/``exit`` → assume single-symbol (back-compat).
    - No ``kind`` AND no ``entry``/``exit`` → raise: user must specify ``kind``.
    """
    explicit = data.get("kind")
    if explicit is not None:
        return explicit

    has_single_shape = "entry" in data and "exit" in data
    if has_single_shape:
        return "single"

    raise ValueError(
        "Spec is missing 'kind' field and doesn't look like a single-symbol "
        "strategy (no entry/exit). Add 'kind: \"portfolio\"' (or "
        "'kind: \"single\"') to disambiguate."
    )
