"""Portfolio allocators and scoring utilities.

Pure functions for portfolio strategies. Use inside
``PortfolioStrategy.allocate(ctx, selected)`` to convert a list of selected
symbols into a ``{symbol: weight}`` dict that sums to ~1.0.

All allocators take pre-computed inputs (vols, scores). They never reach
into ``PortfolioContext`` so they're trivial to unit-test and let users
swap vol estimators (EWMA, GARCH, custom) without touching this module.

Example::

    from fastbt.allocators import (
        annualized_volatility, inverse_volatility, momentum_score,
    )

    class MyStrategy(PortfolioStrategy):
        def rank(self, ctx, universe):
            scored = []
            for sym in universe:
                close = ctx.history[sym]["close"]
                score = momentum_score(
                    {"r90d": roc(close, 90).iloc[-1]},
                    {"r90d": 1.0},
                )
                scored.append((sym, score))
            return sorted(scored, key=lambda x: x[1], reverse=True)

        def allocate(self, ctx, selected):
            vols = {
                s: annualized_volatility(ctx.history[s]["close"], 60)
                for s in selected
            }
            return inverse_volatility(selected, vols)
"""

from __future__ import annotations

import math

import pandas as pd

TRADING_DAYS_PER_YEAR = 252


# ---------------------------------------------------------------------------
# Volatility utility
# ---------------------------------------------------------------------------


def annualized_volatility(
    prices: pd.Series,
    lookback: int = 60,
    ddof: int = 1,
) -> float | None:
    """Annualized volatility from daily returns over the last ``lookback`` bars.

    Uses sample standard deviation (``ddof=1``, the pandas Series default) and
    multiplies by ``sqrt(252)`` to annualize. Returns ``None`` if there are
    fewer than ``lookback + 1`` bars (need ``lookback`` returns, which need
    ``lookback + 1`` prices).

    Args:
        prices: Price series (typically close).
        lookback: Number of returns to include (default 60).
        ddof: Delta degrees of freedom for std (default 1, sample std).

    Returns:
        Annualized vol as a percentage (e.g., ``25.0`` means 25% annualized),
        or ``None`` if insufficient data.
    """
    if len(prices) < lookback + 1:
        return None
    returns = prices.iloc[-(lookback + 1) :].pct_change().dropna()
    if len(returns) < 2:
        return None
    std = returns.std(ddof=ddof)
    if math.isnan(std):
        return None
    return float(std * math.sqrt(TRADING_DAYS_PER_YEAR) * 100.0)


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------


def momentum_score(
    metrics: dict[str, float | None],
    weights: dict[str, float],
) -> float:
    """Weighted sum of named metrics, skipping ``None`` values.

    Weights are used as-is — no re-normalization when metrics are missing.
    Returns ``0.0`` if every metric is ``None`` or every weight is missing
    from ``metrics``.

    Example::

        momentum_score(
            {"r30d": 5.0, "r90d": None, "r180d": 12.0},
            {"r30d": 0.3, "r90d": 0.4, "r180d": 0.3},
        )  # → 0.3 * 5.0 + 0.3 * 12.0 = 5.1 (r90d skipped)
    """
    total = 0.0
    for key, weight in weights.items():
        value = metrics.get(key)
        if value is None:
            continue
        total += weight * value
    return total


# ---------------------------------------------------------------------------
# Allocators
# ---------------------------------------------------------------------------


def equal_weight(symbols: list[str]) -> dict[str, float]:
    """Assign ``1/N`` weight to each symbol.

    Returns ``{}`` for an empty list (no allocation = all cash).
    """
    n = len(symbols)
    if n == 0:
        return {}
    w = 1.0 / n
    return {s: w for s in symbols}


def momentum_weighted(
    symbols: list[str],
    scores: dict[str, float],
) -> dict[str, float]:
    """Weight each symbol proportionally to its score.

    Negative scores are clamped to 0 (no short exposure in portfolio mode).
    If every score is ≤ 0 or missing, falls back to equal-weight across
    the input symbols.

    Args:
        symbols: List of symbols to allocate across.
        scores: ``{symbol: score}`` dict. Missing entries treated as 0.
    """
    if not symbols:
        return {}

    positives = {s: max(0.0, scores.get(s, 0.0)) for s in symbols}
    total = sum(positives.values())

    if total <= 0:
        return equal_weight(symbols)

    return {s: v / total for s, v in positives.items()}


def inverse_volatility(
    symbols: list[str],
    vols: dict[str, float | None],
) -> dict[str, float]:
    """Weight each symbol inversely proportional to its annualized vol.

    Symbols whose vol is ``None`` or ≤ 0 are excluded from the allocation
    (they contribute no weight). If every symbol lacks a usable vol, falls
    back to equal-weight across the input symbols.

    Args:
        symbols: List of symbols to allocate across.
        vols: ``{symbol: annualized_vol_pct}``. Missing/None values mean
            "no vol estimate available" — use ``annualized_volatility()``
            to compute.
    """
    if not symbols:
        return {}

    inverse = {}
    for s in symbols:
        v = vols.get(s)
        if v is None or v <= 0:
            continue
        inverse[s] = 1.0 / v

    if not inverse:
        return equal_weight(symbols)

    total = sum(inverse.values())
    return {s: v / total for s, v in inverse.items()}


def risk_parity(
    symbols: list[str],
    vols: dict[str, float | None],
) -> dict[str, float]:
    """Risk-parity allocation (assumes zero correlation between symbols).

    With zero-correlation assumption this collapses to inverse-volatility
    weighting. A future correlation-aware version would solve a non-trivial
    optimization.
    """
    return inverse_volatility(symbols, vols)
