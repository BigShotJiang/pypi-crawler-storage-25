"""Pandas-native technical indicators.

v0.0.1 ships 6 core indicators: SMA, EMA, RSI, MACD, Bollinger Bands, ATR.
v0.0.2 adds: Stochastic, ADX, CCI, OBV, VWAP, Supertrend, Donchian, Keltner,
             Ichimoku, Williams %R, MFI, ROC, TRIX, KAMA — and a unified registry.
v0.3.0 adds: pct_from_sma — distance from a moving average, common in momentum
             screens. Note: rolling_return is already provided as ``roc``.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def sma(series: pd.Series, period: int) -> pd.Series:
    """Simple moving average."""
    return series.rolling(window=period, min_periods=period).mean()


def ema(series: pd.Series, period: int) -> pd.Series:
    """Exponential moving average."""
    return series.ewm(span=period, adjust=False).mean()


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """Relative Strength Index (Wilder's smoothing)."""
    delta = series.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)

    avg_gain = gain.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False).mean()

    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def macd(
    series: pd.Series,
    fast: int = 12,
    slow: int = 26,
    signal: int = 9,
) -> pd.DataFrame:
    """MACD — returns DataFrame with columns 'macd', 'signal', 'histogram'."""
    fast_ema = ema(series, fast)
    slow_ema = ema(series, slow)
    macd_line = fast_ema - slow_ema
    signal_line = ema(macd_line, signal)
    histogram = macd_line - signal_line
    return pd.DataFrame(
        {"macd": macd_line, "signal": signal_line, "histogram": histogram}
    )


def bollinger_bands(
    series: pd.Series,
    period: int = 20,
    std: float = 2.0,
) -> pd.DataFrame:
    """Bollinger Bands — returns DataFrame with 'middle', 'upper', 'lower'."""
    middle = sma(series, period)
    stdev = series.rolling(window=period, min_periods=period).std()
    return pd.DataFrame(
        {"middle": middle, "upper": middle + std * stdev, "lower": middle - std * stdev}
    )


def atr(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 14,
) -> pd.Series:
    """Average True Range (Wilder's smoothing)."""
    prev_close = close.shift(1)
    tr = pd.concat(
        [high - low, (high - prev_close).abs(), (low - prev_close).abs()],
        axis=1,
    ).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False).mean()


# ---------------------------------------------------------------------------
# v0.0.2 indicators
# ---------------------------------------------------------------------------


def stochastic(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    k_period: int = 14,
    d_period: int = 3,
) -> pd.DataFrame:
    """Stochastic Oscillator — returns DataFrame with 'k', 'd'."""
    lowest_low = low.rolling(window=k_period, min_periods=k_period).min()
    highest_high = high.rolling(window=k_period, min_periods=k_period).max()
    k = 100 * (close - lowest_low) / (highest_high - lowest_low)
    d = k.rolling(window=d_period, min_periods=d_period).mean()
    return pd.DataFrame({"k": k, "d": d})


def adx(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 14,
) -> pd.Series:
    """Average Directional Index."""
    plus_dm = high.diff()
    minus_dm = -low.diff()
    plus_dm = plus_dm.where((plus_dm > minus_dm) & (plus_dm > 0), 0.0)
    minus_dm = minus_dm.where((minus_dm > plus_dm) & (minus_dm > 0), 0.0)

    atr_vals = atr(high, low, close, period)
    plus_di = 100 * plus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr_vals
    minus_di = 100 * minus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr_vals

    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
    return dx.ewm(alpha=1 / period, adjust=False).mean()


def cci(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 20,
) -> pd.Series:
    """Commodity Channel Index."""
    tp = (high + low + close) / 3
    sma_tp = tp.rolling(window=period, min_periods=period).mean()
    mad = tp.rolling(window=period, min_periods=period).apply(
        lambda x: np.mean(np.abs(x - np.mean(x))), raw=True
    )
    return (tp - sma_tp) / (0.015 * mad)


def obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    """On-Balance Volume."""
    direction = np.sign(close.diff())
    direction.iloc[0] = 0
    return (volume * direction).cumsum()


def vwap(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    volume: pd.Series,
) -> pd.Series:
    """Cumulative Volume-Weighted Average Price."""
    tp = (high + low + close) / 3
    return (tp * volume).cumsum() / volume.cumsum()


def supertrend(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 10,
    multiplier: float = 3.0,
) -> pd.DataFrame:
    """Supertrend — returns DataFrame with 'supertrend', 'direction'."""
    hl2 = (high + low) / 2
    atr_vals = atr(high, low, close, period)
    upper_band = hl2 + multiplier * atr_vals
    lower_band = hl2 - multiplier * atr_vals

    st = pd.Series(np.nan, index=close.index)
    direction = pd.Series(1, index=close.index)

    for i in range(1, len(close)):
        if close.iloc[i] > upper_band.iloc[i - 1]:
            direction.iloc[i] = 1
        elif close.iloc[i] < lower_band.iloc[i - 1]:
            direction.iloc[i] = -1
        else:
            direction.iloc[i] = direction.iloc[i - 1]
            if direction.iloc[i] == 1 and lower_band.iloc[i] < lower_band.iloc[i - 1]:
                lower_band.iloc[i] = lower_band.iloc[i - 1]
            if direction.iloc[i] == -1 and upper_band.iloc[i] > upper_band.iloc[i - 1]:
                upper_band.iloc[i] = upper_band.iloc[i - 1]

        st.iloc[i] = lower_band.iloc[i] if direction.iloc[i] == 1 else upper_band.iloc[i]

    return pd.DataFrame({"supertrend": st, "direction": direction})


def donchian(
    high: pd.Series,
    low: pd.Series,
    period: int = 20,
) -> pd.DataFrame:
    """Donchian Channel — returns DataFrame with 'upper', 'lower', 'middle'."""
    upper = high.rolling(window=period, min_periods=period).max()
    lower = low.rolling(window=period, min_periods=period).min()
    return pd.DataFrame({"upper": upper, "lower": lower, "middle": (upper + lower) / 2})


def keltner(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 20,
    multiplier: float = 1.5,
) -> pd.DataFrame:
    """Keltner Channel — returns DataFrame with 'upper', 'middle', 'lower'."""
    middle = ema(close, period)
    atr_vals = atr(high, low, close, period)
    return pd.DataFrame(
        {
            "upper": middle + multiplier * atr_vals,
            "middle": middle,
            "lower": middle - multiplier * atr_vals,
        }
    )


def ichimoku(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    tenkan: int = 9,
    kijun: int = 26,
    senkou_b: int = 52,
) -> pd.DataFrame:
    """Ichimoku Cloud — returns DataFrame with 'tenkan_sen', 'kijun_sen', 'senkou_a', 'senkou_b'."""
    tenkan_sen = (
        high.rolling(window=tenkan, min_periods=tenkan).max()
        + low.rolling(window=tenkan, min_periods=tenkan).min()
    ) / 2
    kijun_sen = (
        high.rolling(window=kijun, min_periods=kijun).max()
        + low.rolling(window=kijun, min_periods=kijun).min()
    ) / 2
    senkou_a_line = (tenkan_sen + kijun_sen) / 2
    senkou_b_line = (
        high.rolling(window=senkou_b, min_periods=senkou_b).max()
        + low.rolling(window=senkou_b, min_periods=senkou_b).min()
    ) / 2
    return pd.DataFrame(
        {
            "tenkan_sen": tenkan_sen,
            "kijun_sen": kijun_sen,
            "senkou_a": senkou_a_line,
            "senkou_b": senkou_b_line,
        }
    )


def williams_r(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 14,
) -> pd.Series:
    """Williams %R."""
    highest_high = high.rolling(window=period, min_periods=period).max()
    lowest_low = low.rolling(window=period, min_periods=period).min()
    return -100 * (highest_high - close) / (highest_high - lowest_low)


def mfi(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    volume: pd.Series,
    period: int = 14,
) -> pd.Series:
    """Money Flow Index."""
    tp = (high + low + close) / 3
    raw_mf = tp * volume
    delta = tp.diff()
    pos_mf = raw_mf.where(delta > 0, 0.0).rolling(window=period, min_periods=period).sum()
    neg_mf = raw_mf.where(delta <= 0, 0.0).rolling(window=period, min_periods=period).sum()
    mf_ratio = pos_mf / neg_mf
    return 100 - (100 / (1 + mf_ratio))


def roc(series: pd.Series, period: int = 12) -> pd.Series:
    """Rate of Change (percentage)."""
    return 100 * (series - series.shift(period)) / series.shift(period)


def trix(series: pd.Series, period: int = 15) -> pd.Series:
    """TRIX — triple-smoothed EMA rate of change."""
    ema1 = ema(series, period)
    ema2 = ema(ema1, period)
    ema3 = ema(ema2, period)
    return ema3.pct_change() * 100


def pct_from_sma(series: pd.Series, period: int = 20) -> pd.Series:
    """Percent distance from a simple moving average.

    Returns ``(series - SMA(series, period)) / SMA(series, period) * 100``.
    Common in momentum screens for filtering symbols above/below their
    200-day SMA. Returns NaN for the first ``period - 1`` bars.
    """
    ma = sma(series, period)
    return (series - ma) / ma * 100


def kama(
    series: pd.Series,
    period: int = 10,
    fast_sc: int = 2,
    slow_sc: int = 30,
) -> pd.Series:
    """Kaufman Adaptive Moving Average."""
    fast_alpha = 2 / (fast_sc + 1)
    slow_alpha = 2 / (slow_sc + 1)

    direction = (series - series.shift(period)).abs()
    volatility = series.diff().abs().rolling(window=period, min_periods=period).sum()
    er = direction / volatility
    sc = (er * (fast_alpha - slow_alpha) + slow_alpha) ** 2

    result = pd.Series(np.nan, index=series.index)
    # First valid KAMA value starts at index = period
    start = period
    if start < len(series):
        result.iloc[start] = series.iloc[start]
    for i in range(start + 1, len(series)):
        if np.isnan(sc.iloc[i]) or np.isnan(result.iloc[i - 1]):
            result.iloc[i] = series.iloc[i]
        else:
            result.iloc[i] = result.iloc[i - 1] + sc.iloc[i] * (
                series.iloc[i] - result.iloc[i - 1]
            )
    return result
