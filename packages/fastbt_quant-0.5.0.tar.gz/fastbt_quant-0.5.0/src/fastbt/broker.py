"""Broker protocol and paper-trading implementation."""

from __future__ import annotations

import uuid
from typing import Literal, Protocol

import pandas as pd

from fastbt.types import (
    Bar,
    Fill,
    Order,
    OrderId,
    OrderSide,
    OrderStatus,
    OrderType,
    Position,
)

FillPolicy = Literal["next_open", "current_close"]


class Broker(Protocol):
    """Minimal broker interface. Paper and real brokers both implement this."""

    def submit_market(
        self,
        symbol: str,
        side: OrderSide,
        qty: float,
        submitted_at: pd.Timestamp,
    ) -> OrderId: ...

    def cancel(self, order_id: OrderId) -> None: ...

    def position(self, symbol: str) -> Position: ...

    def cash(self) -> float: ...

    def equity(self, marks: dict[str, float]) -> float: ...


class PaperBroker:
    """Simulated broker for backtesting and paper-trading.

    Fill policy:
      - "next_open" (default): orders submitted on bar N fill at bar N+1's open.
        Realistic — close is only known AFTER the bar ends.
      - "current_close": orders fill at the close of the bar they were submitted on.
        Optimistic — only use when signals are known intra-bar.

    Slippage is applied multiplicatively:
      - buy fills at price * (1 + slippage_pct/100)
      - sell fills at price * (1 - slippage_pct/100)

    Commission is a percentage of trade value per fill.

    Shorting: supported in v0.0.3 with basic margin model.
      - Initial margin (default 50%): required cash to open a short.
      - Maintenance margin (default 25%): if equity falls below this, auto-liquidate.
    """

    def __init__(
        self,
        initial_cash: float = 100_000.0,
        commission_pct: float = 0.0,
        slippage_pct: float = 0.0,
        fill_policy: FillPolicy = "next_open",
        margin_pct: float = 50.0,
        maintenance_pct: float = 25.0,
    ):
        self._initial_cash = initial_cash
        self._cash = initial_cash
        self._commission_pct = commission_pct
        self._slippage_pct = slippage_pct
        self._fill_policy: FillPolicy = fill_policy
        self._margin_pct = margin_pct
        self._maintenance_pct = maintenance_pct

        self._positions: dict[str, Position] = {}
        self._pending: list[Order] = []
        self._fills: list[Fill] = []

    # ── Broker protocol ──────────────────────────────────────────────

    def submit_market(
        self,
        symbol: str,
        side: OrderSide,
        qty: float,
        submitted_at: pd.Timestamp,
    ) -> OrderId:
        order = Order(
            id=OrderId(uuid.uuid4().hex[:12]),
            symbol=symbol,
            side=side,
            qty=qty,
            type=OrderType.MARKET,
            submitted_at=submitted_at,
            status=OrderStatus.PENDING,
        )
        self._pending.append(order)
        return order.id

    def cancel(self, order_id: OrderId) -> None:
        for o in self._pending:
            if o.id == order_id and o.status == OrderStatus.PENDING:
                o.status = OrderStatus.CANCELLED

    def position(self, symbol: str) -> Position:
        return self._positions.get(symbol, Position(symbol=symbol))

    def cash(self) -> float:
        return self._cash

    def equity(self, marks: dict[str, float]) -> float:
        mv = sum(
            pos.market_value(marks.get(sym, pos.avg_entry_price))
            for sym, pos in self._positions.items()
        )
        return self._cash + mv

    # ── Engine hooks ─────────────────────────────────────────────────

    def on_bar_open(self, bar: Bar) -> None:
        """Fill orders pending with next_open policy at this bar's open.

        Only orders matching ``bar.symbol`` are filled; orders for other
        symbols stay pending until their own bar arrives.
        """
        if self._fill_policy != "next_open":
            return
        self._drain_pending(bar.symbol, bar.open, bar.timestamp)

    def on_bar_close(self, bar: Bar) -> None:
        """Fill orders pending with current_close policy at this bar's close.

        Only orders matching ``bar.symbol`` are filled; orders for other
        symbols stay pending until their own bar arrives.
        """
        if self._fill_policy != "current_close":
            return
        self._drain_pending(bar.symbol, bar.close, bar.timestamp)

    def fills(self) -> list[Fill]:
        return list(self._fills)

    # ── Stops & margin ──────────────────────────────────────────────

    def execute_stop(
        self,
        symbol: str,
        price: float,
        ts: pd.Timestamp,
    ) -> OrderId | None:
        """Close a position at an exact price. Bypasses fill policy (immediate).

        Used by the engine for stop-loss, take-profit, trailing stop, and
        margin liquidation. The caller is responsible for applying slippage
        to *price* before calling this method.
        """
        pos = self._positions.get(symbol, Position(symbol=symbol))
        if pos.is_flat:
            return None
        side = OrderSide.SELL if pos.is_long else OrderSide.BUY
        qty = abs(pos.qty)
        order = Order(
            id=OrderId(uuid.uuid4().hex[:12]),
            symbol=symbol,
            side=side,
            qty=qty,
            type=OrderType.MARKET,
            submitted_at=ts,
            status=OrderStatus.PENDING,
        )
        self._fill_at_price(order, price, ts)
        return order.id

    def check_maintenance_margin(
        self,
        marks: dict[str, float],
        ts: pd.Timestamp,
    ) -> list[OrderId]:
        """Auto-liquidate short positions that breach maintenance margin.

        Returns order IDs for any positions that were force-closed.
        """
        closed: list[OrderId] = []
        eq = self.equity(marks)
        for sym in list(self._positions):
            pos = self._positions[sym]
            if pos.is_short:
                mark = marks.get(sym, pos.avg_entry_price)
                required = abs(pos.qty * mark) * (self._maintenance_pct / 100.0)
                if eq < required:
                    oid = self.execute_stop(sym, mark, ts)
                    if oid:
                        closed.append(oid)
                    eq = self.equity(marks)
        return closed

    # ── Internals ────────────────────────────────────────────────────

    def _drain_pending(
        self,
        symbol: str,
        raw_price: float,
        ts: pd.Timestamp,
    ) -> None:
        """Fill all pending orders for ``symbol`` at ``raw_price``.

        Orders for other symbols remain pending. An empty ``symbol`` is
        treated as a wildcard — kept only as a safety net for legacy callers
        and is not used by the engines.
        """
        for order in list(self._pending):
            if order.status != OrderStatus.PENDING:
                continue
            if symbol and order.symbol != symbol:
                continue
            self._fill(order, raw_price, ts)
        self._pending = [o for o in self._pending if o.status == OrderStatus.PENDING]

    def _fill_at_price(self, order: Order, price: float, ts: pd.Timestamp) -> None:
        """Fill an order at an exact price (no slippage applied)."""
        delta = order.qty if order.side == OrderSide.BUY else -order.qty
        commission = abs(price * order.qty) * (self._commission_pct / 100.0)
        self._apply_fill(order, price, delta, commission, ts)

    def _fill(self, order: Order, raw_price: float, ts: pd.Timestamp) -> None:
        slip = self._slippage_pct / 100.0
        if order.side == OrderSide.BUY:
            price = raw_price * (1 + slip)
            delta = order.qty
        else:
            price = raw_price * (1 - slip)
            delta = -order.qty

        commission = abs(price * order.qty) * (self._commission_pct / 100.0)

        # Margin check for new or increased short positions
        pos = self._positions.get(order.symbol, Position(symbol=order.symbol))
        new_qty = pos.qty + delta
        if new_qty < 0 and (pos.qty >= 0 or abs(new_qty) > abs(pos.qty)):
            required_margin = abs(new_qty * price) * (self._margin_pct / 100.0)
            if self._cash < required_margin:
                order.status = OrderStatus.REJECTED
                return

        self._apply_fill(order, price, delta, commission, ts)

    def _apply_fill(
        self,
        order: Order,
        price: float,
        delta: float,
        commission: float,
        ts: pd.Timestamp,
    ) -> None:
        """Shared fill logic — updates position, cash, and records the fill."""
        pos = self._positions.get(order.symbol, Position(symbol=order.symbol))
        new_qty = pos.qty + delta

        # Weighted-average entry price
        if pos.qty == 0:
            # Opening a new position
            pos.avg_entry_price = price
        elif (pos.qty > 0 and new_qty < 0) or (pos.qty < 0 and new_qty > 0):
            # Position flip through zero — new side starts at fill price
            pos.avg_entry_price = price
        elif (pos.qty > 0 and delta > 0) or (pos.qty < 0 and delta < 0):
            # Adding to position — weighted average
            total_cost = pos.avg_entry_price * abs(pos.qty) + price * abs(delta)
            pos.avg_entry_price = total_cost / abs(new_qty)
        elif new_qty == 0:
            pos.avg_entry_price = 0.0
        # Reducing without flipping: keep avg_entry_price unchanged.

        pos.qty = new_qty
        self._positions[order.symbol] = pos
        self._cash -= price * delta + commission
        order.status = OrderStatus.FILLED

        self._fills.append(
            Fill(
                order_id=order.id,
                symbol=order.symbol,
                side=order.side,
                qty=order.qty,
                price=price,
                timestamp=ts,
                commission=commission,
            )
        )
