"""Backtest engine — walk a strategy bar-by-bar through a DataFrame."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from fastbt.broker import FillPolicy, PaperBroker
from fastbt.context import Context
from fastbt.portfolio_context import PortfolioContext
from fastbt.portfolio_result import PortfolioResult
from fastbt.portfolio_strategy import PortfolioStrategy
from fastbt.result import BacktestResult, Metrics
from fastbt.schedule import RebalanceSchedule
from fastbt.strategy import Strategy
from fastbt.types import Bar, OrderSide, Position
from fastbt.validators import validate_ohlcv


# ---------------------------------------------------------------------------
# StopTracker
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class StopResult:
    """Result from a triggered stop: the fill price and which stop type fired."""

    price: float
    kind: str  # "sl", "tp", "ts", "vol_ts"


@dataclass(frozen=True, slots=True)
class StopOutEvent:
    """A recorded stop trigger.

    Captured by the engine when a stop fires and the broker fills the close.
    ``pnl`` is derived from the actual broker fill (post-slippage,
    post-commission), not from the StopTracker price math, so it's the truth
    even on partial exits, position flips, or pyramiding adds.
    """

    symbol: str
    kind: str  # "sl", "tp", "ts", "vol_ts"
    entry_price: float
    exit_price: float
    pnl: float
    days_held: int
    stop_level: float
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp


@dataclass
class _StopState:
    """Per-symbol stop tracking state."""

    entry_price: float
    highest_since_entry: float
    lowest_since_entry: float
    entry_bar: int = 0
    entry_time: pd.Timestamp | None = None


class StopTracker:
    """Tracks stop levels and high-water marks for trailing stops.

    Configured once at backtest start. The engine calls ``check()`` on each
    bar *before* the strategy runs. If a stop triggers, the engine closes
    the position at the stop price (with slippage applied by the caller).

    When multiple stops trigger on the same bar, the one whose price is
    closest to the bar's open wins — a simple intra-bar ordering heuristic.
    """

    def __init__(
        self,
        *,
        stop_loss_pct: float | None = None,
        stop_loss_points: float | None = None,
        take_profit_pct: float | None = None,
        take_profit_points: float | None = None,
        trailing_stop_pct: float | None = None,
        trailing_stop_points: float | None = None,
        vol_trailing_multiplier: float | None = None,
        vol_trailing_lookback: int = 60,
        vol_trailing_fallback_pct: float | None = None,
    ):
        self._sl_pct = stop_loss_pct
        self._sl_pts = stop_loss_points
        self._tp_pct = take_profit_pct
        self._tp_pts = take_profit_points
        self._ts_pct = trailing_stop_pct
        self._ts_pts = trailing_stop_points
        self._vol_ts_mult = vol_trailing_multiplier
        self._vol_ts_lookback = vol_trailing_lookback
        self._vol_ts_fallback_pct = vol_trailing_fallback_pct
        self._states: dict[str, _StopState] = {}
        self.stop_outs: list[StopOutEvent] = []

    @property
    def is_active(self) -> bool:
        return any(
            v is not None
            for v in [
                self._sl_pct,
                self._sl_pts,
                self._tp_pct,
                self._tp_pts,
                self._ts_pct,
                self._ts_pts,
                self._vol_ts_mult,
            ]
        )

    def on_position_opened(
        self,
        symbol: str,
        entry_price: float,
        *,
        bar_index: int = 0,
        entry_time: pd.Timestamp | None = None,
    ) -> None:
        self._states[symbol] = _StopState(
            entry_price=entry_price,
            highest_since_entry=entry_price,
            lowest_since_entry=entry_price,
            entry_bar=bar_index,
            entry_time=entry_time,
        )

    def on_position_closed(self, symbol: str) -> None:
        self._states.pop(symbol, None)

    def get_state(self, symbol: str) -> _StopState | None:
        """Read-only access to a symbol's stop state (used by engine to
        derive entry_price/days_held when assembling a StopOutEvent).
        """
        return self._states.get(symbol)

    def record_stop_out(
        self,
        symbol: str,
        *,
        kind: str,
        stop_level: float,
        exit_price: float,
        exit_qty: float,
        exit_commission: float,
        exit_time: pd.Timestamp,
        bar_index: int,
        is_long: bool,
    ) -> None:
        """Record a stop-out event. Called by the engine after the broker
        fills the close, so ``exit_price`` is the actual post-slippage fill.

        ``pnl`` is approximated as ``(exit - entry) * qty * direction -
        exit_commission``. Entry commission was paid at position open and is
        not double-counted here. For pyramided positions, entry_price is the
        weighted-average set at first open; the approximation drifts slightly
        on adds. Use ``broker.fills()`` for the authoritative trade ledger.
        """
        state = self._states.get(symbol)
        if state is None:
            return  # nothing to record

        if is_long:
            pnl = (exit_price - state.entry_price) * exit_qty - exit_commission
        else:
            pnl = (state.entry_price - exit_price) * exit_qty - exit_commission

        days_held = max(0, bar_index - state.entry_bar)

        self.stop_outs.append(
            StopOutEvent(
                symbol=symbol,
                kind=kind,
                entry_price=state.entry_price,
                exit_price=exit_price,
                pnl=pnl,
                days_held=days_held,
                stop_level=stop_level,
                entry_time=state.entry_time or exit_time,
                exit_time=exit_time,
            )
        )

    def check(
        self,
        symbol: str,
        bar: Bar,
        position: Position,
        *,
        history: pd.Series | None = None,
        bar_index: int = 0,
    ) -> StopResult | None:
        """Check all stops. Returns StopResult if triggered, else None.

        Args:
            symbol: Symbol identifier.
            bar: Current bar.
            position: Current position for the symbol.
            history: Optional close-price history up to and including this
                bar. Required only when vol_trailing is configured — used to
                compute current annualized vol. Pass ``None`` for fixed/
                trailing-only configurations.
            bar_index: Current bar index in the run (used to compute days_held
                later via state.entry_bar).
        """
        if position.is_flat or symbol not in self._states:
            return None

        state = self._states[symbol]
        state.highest_since_entry = max(state.highest_since_entry, bar.high)
        state.lowest_since_entry = min(state.lowest_since_entry, bar.low)

        triggered: list[tuple[str, float]] = []

        sl = self._stop_loss_price(state, position)
        if sl is not None:
            if (position.is_long and bar.low <= sl) or (
                position.is_short and bar.high >= sl
            ):
                triggered.append(("sl", sl))

        tp = self._take_profit_price(state, position)
        if tp is not None:
            if (position.is_long and bar.high >= tp) or (
                position.is_short and bar.low <= tp
            ):
                triggered.append(("tp", tp))

        ts = self._trailing_stop_price(state, position)
        if ts is not None:
            if (position.is_long and bar.low <= ts) or (
                position.is_short and bar.high >= ts
            ):
                triggered.append(("ts", ts))

        vol_ts = self._vol_trailing_price(state, position, history)
        if vol_ts is not None:
            if (position.is_long and bar.low <= vol_ts) or (
                position.is_short and bar.high >= vol_ts
            ):
                triggered.append(("vol_ts", vol_ts))

        if not triggered:
            return None

        # Closest to open wins
        triggered.sort(key=lambda t: abs(bar.open - t[1]))
        kind, price = triggered[0]
        return StopResult(price=price, kind=kind)

    def _stop_loss_price(
        self, state: _StopState, pos: Position
    ) -> float | None:
        if self._sl_pct is not None:
            if pos.is_long:
                return state.entry_price * (1 - self._sl_pct / 100)
            return state.entry_price * (1 + self._sl_pct / 100)
        if self._sl_pts is not None:
            if pos.is_long:
                return state.entry_price - self._sl_pts
            return state.entry_price + self._sl_pts
        return None

    def _take_profit_price(
        self, state: _StopState, pos: Position
    ) -> float | None:
        if self._tp_pct is not None:
            if pos.is_long:
                return state.entry_price * (1 + self._tp_pct / 100)
            return state.entry_price * (1 - self._tp_pct / 100)
        if self._tp_pts is not None:
            if pos.is_long:
                return state.entry_price + self._tp_pts
            return state.entry_price - self._tp_pts
        return None

    def _trailing_stop_price(
        self, state: _StopState, pos: Position
    ) -> float | None:
        if self._ts_pct is not None:
            if pos.is_long:
                return state.highest_since_entry * (1 - self._ts_pct / 100)
            return state.lowest_since_entry * (1 + self._ts_pct / 100)
        if self._ts_pts is not None:
            if pos.is_long:
                return state.highest_since_entry - self._ts_pts
            return state.lowest_since_entry + self._ts_pts
        return None

    def _vol_trailing_price(
        self,
        state: _StopState,
        pos: Position,
        history: pd.Series | None,
    ) -> float | None:
        """Volatility-adaptive trailing stop.

        ``stop = HWM * (1 - vol * multiplier / 100)`` for longs.
        Vol is recomputed each bar from the trailing close history. Falls
        back to ``vol_trailing_fallback_pct`` when vol is unavailable
        (insufficient history).
        """
        if self._vol_ts_mult is None:
            return None

        # Lazy import to keep allocators an optional dep at engine boot
        from fastbt.allocators import annualized_volatility

        vol_pct = None
        if history is not None and len(history) >= self._vol_ts_lookback + 1:
            vol_pct = annualized_volatility(
                history, lookback=self._vol_ts_lookback
            )

        # Use vol-derived band when vol is positive and yields a sensible
        # band (< 100%). A single flash-crash bar in the lookback window can
        # produce vol*mult > 100%, which would set the stop level negative
        # (long) or meaninglessly high (short). In that degenerate case fall
        # back to fallback_pct — matches user intent of "vol unusable."
        band: float | None = None
        if vol_pct is not None and vol_pct > 0:
            candidate = vol_pct * self._vol_ts_mult / 100.0
            if candidate < 1.0:
                band = candidate
        if band is None and self._vol_ts_fallback_pct is not None:
            band = self._vol_ts_fallback_pct / 100.0
        if band is None:
            return None

        if pos.is_long:
            return state.highest_since_entry * (1 - band)
        return state.lowest_since_entry * (1 + band)


# ---------------------------------------------------------------------------
# backtest()
# ---------------------------------------------------------------------------


def backtest(
    strategy: Strategy,
    data: pd.DataFrame,
    *,
    symbol: str = "SYMBOL",
    initial_cash: float = 100_000.0,
    commission_pct: float = 0.0,
    slippage_pct: float = 0.0,
    fill_policy: FillPolicy = "next_open",
    warmup_bars: int = 0,
    margin_pct: float = 50.0,
    maintenance_pct: float = 25.0,
    stop_loss_pct: float | None = None,
    stop_loss_points: float | None = None,
    take_profit_pct: float | None = None,
    take_profit_points: float | None = None,
    trailing_stop_pct: float | None = None,
    trailing_stop_points: float | None = None,
    risk_free_rate: float = 0.0,
) -> BacktestResult:
    """Run `strategy` against `data` and return a BacktestResult.

    Args:
        strategy: Strategy instance.
        data: OHLCV DataFrame with DatetimeIndex. See `validate_ohlcv` for contract.
        symbol: Label for the instrument.
        initial_cash: Starting cash balance.
        commission_pct: Commission as a pct of trade value (e.g., 0.1 = 10 bps).
        slippage_pct: Slippage as a pct of fill price.
        fill_policy: "next_open" (realistic) or "current_close" (optimistic).
        warmup_bars: Number of initial bars to skip before calling `on_bar`.
        risk_free_rate: Annual risk-free rate (percent) used for Sharpe and
            Sortino. Default 0.0 — set per market when needed (e.g. 6.0 for India).
    """
    validate_ohlcv(data)
    data = _normalize_columns(data)

    broker = PaperBroker(
        initial_cash=initial_cash,
        commission_pct=commission_pct,
        slippage_pct=slippage_pct,
        fill_policy=fill_policy,
        margin_pct=margin_pct,
        maintenance_pct=maintenance_pct,
    )

    # Build stop tracker — explicit params override strategy.stop_config()
    strat_cfg = strategy.stop_config() or {}
    stop_tracker = StopTracker(
        stop_loss_pct=stop_loss_pct or strat_cfg.get("stop_loss_pct"),
        stop_loss_points=stop_loss_points or strat_cfg.get("stop_loss_points"),
        take_profit_pct=take_profit_pct or strat_cfg.get("take_profit_pct"),
        take_profit_points=take_profit_points or strat_cfg.get("take_profit_points"),
        trailing_stop_pct=trailing_stop_pct or strat_cfg.get("trailing_stop_pct"),
        trailing_stop_points=trailing_stop_points or strat_cfg.get("trailing_stop_points"),
    )

    first_bar = _bar_from_row(data.index[0], data.iloc[0], symbol)
    ctx = Context(
        symbol=symbol,
        bar=first_bar,
        history=data.iloc[:1],
        params=strategy.params,
        broker=broker,
        full_data=data,
    )
    strategy.initialize(ctx)

    equity_values: list[float] = []
    equity_index: list[pd.Timestamp] = []
    prev_pos_qty = 0.0

    for i in range(len(data)):
        ts = data.index[i]
        bar = _bar_from_row(ts, data.iloc[i], symbol)

        broker.on_bar_open(bar)

        # Stop check — before strategy runs.
        # Vol-trailing uses history up to (not including) the current bar so
        # a flash-crash bar doesn't pollute its own vol measurement.
        if stop_tracker.is_active:
            pos = broker.position(symbol)
            vol_history = data["close"].iloc[:i] if i > 0 else None
            stop_result = stop_tracker.check(
                symbol,
                bar,
                pos,
                history=vol_history,
                bar_index=i,
            )
            if stop_result is not None:
                # Apply slippage to stop price
                slip = slippage_pct / 100.0
                if pos.is_long:
                    fill_price = stop_result.price * (1 - slip)
                else:
                    fill_price = stop_result.price * (1 + slip)
                exit_qty = abs(pos.qty)
                pos_was_long = pos.is_long
                broker.execute_stop(symbol, fill_price, ts)
                # Pull commission from the just-recorded fill
                fills_after = broker.fills()
                exit_commission = (
                    fills_after[-1].commission if fills_after else 0.0
                )
                stop_tracker.record_stop_out(
                    symbol,
                    kind=stop_result.kind,
                    stop_level=stop_result.price,
                    exit_price=fill_price,
                    exit_qty=exit_qty,
                    exit_commission=exit_commission,
                    exit_time=ts,
                    bar_index=i,
                    is_long=pos_was_long,
                )
                stop_tracker.on_position_closed(symbol)

        ctx.bar = bar
        ctx.history = data.iloc[: i + 1]

        if i >= warmup_bars:
            strategy.on_bar(ctx)

        # Track position changes for stop tracker
        if stop_tracker.is_active:
            curr_pos = broker.position(symbol)
            if prev_pos_qty == 0 and curr_pos.qty != 0:
                # New position opened
                fills = broker.fills()
                if fills:
                    stop_tracker.on_position_opened(
                        symbol,
                        fills[-1].price,
                        bar_index=i,
                        entry_time=ts,
                    )
            elif prev_pos_qty != 0 and curr_pos.qty == 0:
                stop_tracker.on_position_closed(symbol)
            prev_pos_qty = curr_pos.qty

        broker.on_bar_close(bar)

        # Margin maintenance check
        broker.check_maintenance_margin({symbol: bar.close}, ts)

        equity_values.append(broker.equity({symbol: bar.close}))
        equity_index.append(ts)

    equity_series = pd.Series(equity_values, index=pd.DatetimeIndex(equity_index), name="equity")
    metrics = Metrics.from_equity_curve(
        equity=equity_series,
        initial_cash=initial_cash,
        fills=broker.fills(),
        risk_free_rate=risk_free_rate,
    )

    return BacktestResult(
        equity_curve=equity_series,
        fills=broker.fills(),
        metrics=metrics,
        initial_cash=initial_cash,
        final_cash=broker.cash(),
        stop_outs=list(stop_tracker.stop_outs),
    )


def _bar_from_row(ts: pd.Timestamp, row: pd.Series, symbol: str) -> Bar:
    return Bar(
        timestamp=ts,
        symbol=symbol,
        open=float(row["open"]),
        high=float(row["high"]),
        low=float(row["low"]),
        close=float(row["close"]),
        volume=float(row["volume"]),
    )


def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    renames = {c: c.lower() for c in df.columns if c != c.lower()}
    if renames:
        df = df.rename(columns=renames)
    return df


# ---------------------------------------------------------------------------
# Portfolio backtest
# ---------------------------------------------------------------------------


def portfolio_backtest(
    strategy: PortfolioStrategy,
    data: dict[str, pd.DataFrame],
    *,
    initial_cash: float = 100_000.0,
    commission_pct: float = 0.0,
    slippage_pct: float = 0.0,
    fill_policy: FillPolicy = "next_open",
    warmup_bars: int = 0,
    rebalance_every: int = 1,
    schedule: RebalanceSchedule | None = None,
    min_drift_pct: float = 0.0,
    risk_free_rate: float = 0.0,
    stop_loss_pct: float | None = None,
    stop_loss_points: float | None = None,
    take_profit_pct: float | None = None,
    take_profit_points: float | None = None,
    trailing_stop_pct: float | None = None,
    trailing_stop_points: float | None = None,
    vol_trailing_multiplier: float | None = None,
    vol_trailing_lookback: int = 60,
    vol_trailing_fallback_pct: float | None = None,
) -> PortfolioResult:
    """Run a portfolio strategy across multiple symbols.

    Args:
        strategy: PortfolioStrategy instance.
        data: Dict mapping symbol names to OHLCV DataFrames with DatetimeIndex.
        initial_cash: Starting cash balance.
        commission_pct: Commission as pct of trade value.
        slippage_pct: Slippage as pct of fill price.
        fill_policy: "next_open" or "current_close".
        warmup_bars: Bars to skip before calling on_rebalance.
        rebalance_every: Call on_rebalance every N bars (default 1 = every bar).
            Mutually exclusive with ``schedule``.
        schedule: A ``RebalanceSchedule`` for date-aware rebalancing
            (weekly, monthly, etc.). Mutually exclusive with a non-default
            ``rebalance_every``.
        min_drift_pct: Drift threshold (percent of portfolio) below which
            held∩target positions are not traded — reduces turnover. Default
            ``0.0`` preserves pre-v0.3.0 behavior (every nonzero delta trades).
            Full exits and new entries always trade regardless of threshold.
        risk_free_rate: Annual risk-free rate (percent) for Sharpe and Sortino.
            Default 0.0 — set per market when needed (e.g. 6.0 for India).
        stop_loss_pct, stop_loss_points, take_profit_pct, take_profit_points,
            trailing_stop_pct, trailing_stop_points, vol_trailing_multiplier,
            vol_trailing_lookback, vol_trailing_fallback_pct:
            Per-symbol stop configuration, applied to every position the
            portfolio opens. Explicit kwargs override any values returned by
            ``strategy.stop_config()``. When a stop fires, the symbol is
            converted to cash, a ``StopOutEvent`` is recorded, and that
            symbol is excluded from rebalance entry on the same bar.
    """
    if not data:
        raise ValueError("data must be a non-empty dict of DataFrames")

    # Conflict guard: schedule and rebalance_every are mutually exclusive
    if schedule is not None and rebalance_every != 1:
        raise ValueError(
            "Cannot set both 'schedule' and 'rebalance_every'. "
            "Use one or the other."
        )

    # Resolve schedule
    if schedule is None:
        schedule = RebalanceSchedule.every_n_bars(rebalance_every)

    # Validate and normalize each DataFrame
    normalized: dict[str, pd.DataFrame] = {}
    for sym, df in data.items():
        validate_ohlcv(df)
        normalized[sym] = _normalize_columns(df)

    symbols = sorted(normalized.keys())
    aligned = _align_dataframes(normalized)

    # Let the schedule pre-compute from the full aligned index
    schedule._prepare(aligned.index)

    broker = PaperBroker(
        initial_cash=initial_cash,
        commission_pct=commission_pct,
        slippage_pct=slippage_pct,
        fill_policy=fill_policy,
    )

    # Build stop tracker — explicit kwargs override strategy.stop_config().
    # Mirrors the single-symbol pattern at lines 220-229.
    strat_cfg = strategy.stop_config() or {}
    stop_tracker = StopTracker(
        stop_loss_pct=stop_loss_pct or strat_cfg.get("stop_loss_pct"),
        stop_loss_points=stop_loss_points or strat_cfg.get("stop_loss_points"),
        take_profit_pct=take_profit_pct or strat_cfg.get("take_profit_pct"),
        take_profit_points=take_profit_points or strat_cfg.get("take_profit_points"),
        trailing_stop_pct=trailing_stop_pct or strat_cfg.get("trailing_stop_pct"),
        trailing_stop_points=trailing_stop_points or strat_cfg.get("trailing_stop_points"),
        vol_trailing_multiplier=(
            vol_trailing_multiplier or strat_cfg.get("vol_trailing_multiplier")
        ),
        vol_trailing_lookback=(
            strat_cfg.get("vol_trailing_lookback", vol_trailing_lookback)
        ),
        vol_trailing_fallback_pct=(
            vol_trailing_fallback_pct
            or strat_cfg.get("vol_trailing_fallback_pct")
        ),
    )

    equity_values: list[float] = []
    equity_index: list[pd.Timestamp] = []
    weight_records: list[dict[str, float]] = []
    rebalance_count = 0
    # Per-symbol prev qty for open/close detection
    prev_qtys: dict[str, float] = {sym: 0.0 for sym in symbols}
    # Symbols that just stopped out this bar — excluded from same-bar rebalance entry
    just_stopped_this_bar: set[str] = set()

    # Build initial context for initialize()
    first_ts = aligned.index[0]
    first_bars = _bars_for_timestamp(first_ts, aligned, symbols)
    first_marks = {sym: bar.close for sym, bar in first_bars.items()}
    first_ctx = PortfolioContext(
        bars=first_bars,
        positions={sym: broker.position(sym) for sym in symbols},
        cash=broker.cash(),
        equity=broker.equity(first_marks),
        history={sym: normalized[sym].iloc[:1] for sym in symbols},
        symbols=symbols,
        params=strategy.params,
        broker=broker,
        bar_index=0,
        rebalance_count=0,
    )
    strategy.initialize(first_ctx)

    for i in range(len(aligned)):
        ts = aligned.index[i]
        just_stopped_this_bar = set()

        # Build per-symbol bars
        current_bars = _bars_for_timestamp(ts, aligned, symbols)
        marks = {sym: bar.close for sym, bar in current_bars.items()}

        # Fill pending orders from previous bar
        for sym in symbols:
            if sym in current_bars:
                broker.on_bar_open(current_bars[sym])

        # Stop check — runs before strategy/rebalance, mirrors single-symbol pattern
        if stop_tracker.is_active:
            for sym in symbols:
                if sym not in current_bars:
                    continue
                pos = broker.position(sym)
                if pos.is_flat:
                    continue
                # Use history up to (not including) the current bar so a
                # flash-crash bar doesn't pollute its own vol measurement.
                if i > 0:
                    prev_ts = aligned.index[i - 1]
                    vol_history = normalized[sym]["close"].loc[:prev_ts]
                else:
                    vol_history = None
                stop_result = stop_tracker.check(
                    sym,
                    current_bars[sym],
                    pos,
                    history=vol_history,
                    bar_index=i,
                )
                if stop_result is not None:
                    slip = slippage_pct / 100.0
                    if pos.is_long:
                        fill_price = stop_result.price * (1 - slip)
                    else:
                        fill_price = stop_result.price * (1 + slip)
                    exit_qty = abs(pos.qty)
                    pos_was_long = pos.is_long
                    broker.execute_stop(sym, fill_price, ts)
                    fills_after = broker.fills()
                    exit_commission = (
                        fills_after[-1].commission if fills_after else 0.0
                    )
                    stop_tracker.record_stop_out(
                        sym,
                        kind=stop_result.kind,
                        stop_level=stop_result.price,
                        exit_price=fill_price,
                        exit_qty=exit_qty,
                        exit_commission=exit_commission,
                        exit_time=ts,
                        bar_index=i,
                        is_long=pos_was_long,
                    )
                    stop_tracker.on_position_closed(sym)
                    just_stopped_this_bar.add(sym)
                    prev_qtys[sym] = 0.0

        equity = broker.equity(marks)

        # Build context
        ctx = PortfolioContext(
            bars=current_bars,
            positions={sym: broker.position(sym) for sym in symbols},
            cash=broker.cash(),
            equity=equity,
            history={sym: normalized[sym].loc[:ts] for sym in symbols},
            symbols=symbols,
            params=strategy.params,
            broker=broker,
            bar_index=i,
            rebalance_count=rebalance_count,
        )

        # Rebalance check
        if i >= warmup_bars and schedule.should_rebalance(ts, i):
            target_weights = strategy.on_rebalance(ctx)
            _validate_weights(target_weights, symbols)
            # Same-bar cooldown: a symbol that stopped out this bar gets target=0
            # for this rebalance, preventing immediate re-entry. It's eligible
            # again at the next rebalance after this bar.
            if just_stopped_this_bar:
                target_weights = {
                    s: w for s, w in target_weights.items()
                    if s not in just_stopped_this_bar
                }
            _rebalance_to_weights(
                broker, target_weights, marks, equity, ts,
                min_drift_pct=min_drift_pct,
            )
            rebalance_count += 1

        # Close bars
        for sym in symbols:
            if sym in current_bars:
                broker.on_bar_close(current_bars[sym])

        # Track per-symbol position open/close for stop tracker
        if stop_tracker.is_active:
            for sym in symbols:
                curr_qty = broker.position(sym).qty
                prev_q = prev_qtys.get(sym, 0.0)
                if prev_q == 0 and curr_qty != 0:
                    # New position opened this bar — find the matching fill
                    fills = broker.fills()
                    entry_fill = None
                    for f in reversed(fills):
                        if f.symbol == sym and f.timestamp == ts:
                            entry_fill = f
                            break
                    if entry_fill is not None:
                        stop_tracker.on_position_opened(
                            sym,
                            entry_fill.price,
                            bar_index=i,
                            entry_time=ts,
                        )
                elif prev_q != 0 and curr_qty == 0 and sym not in just_stopped_this_bar:
                    stop_tracker.on_position_closed(sym)
                prev_qtys[sym] = curr_qty

        # Record actual weights (post-fill for current_close, pre-fill for next_open)
        post_equity = broker.equity(marks)
        actual_weights = _compute_actual_weights(broker, symbols, marks)
        weight_records.append(actual_weights)
        equity_values.append(post_equity)
        equity_index.append(ts)

    return PortfolioResult.build(
        equity_values=equity_values,
        equity_index=equity_index,
        fills=broker.fills(),
        initial_cash=initial_cash,
        final_cash=broker.cash(),
        weight_records=weight_records,
        symbols=symbols,
        risk_free_rate=risk_free_rate,
        stop_outs=list(stop_tracker.stop_outs),
    )


def _bars_for_timestamp(
    ts: pd.Timestamp,
    aligned: pd.DataFrame,
    symbols: list[str],
) -> dict[str, Bar]:
    """Build a Bar for each symbol at a given timestamp."""
    bars: dict[str, Bar] = {}
    for sym in symbols:
        row = aligned.loc[ts, sym]
        bars[sym] = Bar(
            timestamp=ts,
            symbol=sym,
            open=float(row["open"]),
            high=float(row["high"]),
            low=float(row["low"]),
            close=float(row["close"]),
            volume=float(row["volume"]),
        )
    return bars


def _align_dataframes(data: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Align multiple DataFrames to intersection of date ranges with ffill."""
    # Find intersection of date ranges
    start = max(df.index.min() for df in data.values())
    end = min(df.index.max() for df in data.values())

    trimmed = {sym: df.loc[start:end] for sym, df in data.items()}

    # Concat with MultiIndex columns: (symbol, ohlcv_field)
    combined = pd.concat(trimmed, axis=1)
    combined = combined.ffill().dropna()

    if len(combined) == 0:
        raise ValueError(
            "No overlapping data after alignment. "
            "Check that input DataFrames have overlapping date ranges."
        )

    return combined


def _validate_weights(weights: dict[str, float], symbols: list[str]) -> None:
    """Raise ValueError if weights are invalid."""
    symbol_set = set(symbols)
    for sym in weights:
        if sym not in symbol_set:
            raise ValueError(f"Unknown symbol {sym!r} in target weights")
    for sym, w in weights.items():
        if w < 0:
            raise ValueError(
                f"Negative weight {w} for {sym!r}. "
                "Short weights are not supported in portfolio mode."
            )
    total = sum(weights.values())
    if total > 1.0 + 1e-9:
        raise ValueError(
            f"Weights sum to {total:.6f}, must be <= 1.0. "
            "Leverage is not supported in portfolio mode."
        )


def _rebalance_to_weights(
    broker: PaperBroker,
    target_weights: dict[str, float],
    marks: dict[str, float],
    equity: float,
    ts: pd.Timestamp,
    *,
    min_drift_pct: float = 0.0,
) -> None:
    """Submit orders to move portfolio toward target weights.

    When ``min_drift_pct > 0``, holdings whose weight drift is below the
    threshold are skipped — reducing turnover and transaction costs. Full
    exits (held but not in target) and new entries (in target but not held)
    always trade regardless of drift; the threshold only applies to held
    AND in-target symbols.

    Sells are submitted before buys. In live brokers this lets sells fund
    buys; in this paper broker long buys aren't cash-constrained at fill
    time, so the ordering here is for live-broker consistency.
    """
    if equity <= 0:
        return

    # Collect all symbols that have a position or a target weight
    all_syms: set[str] = set(target_weights.keys())
    for sym in list(broker._positions.keys()):
        pos = broker.position(sym)
        if not pos.is_flat:
            all_syms.add(sym)

    sell_orders: list[tuple[str, int]] = []
    buy_orders: list[tuple[str, int]] = []

    for sym in all_syms:
        target_w = target_weights.get(sym, 0.0)
        price = marks.get(sym, 0.0)
        if price <= 0:
            continue

        target_qty = int(target_w * equity / price)
        current_qty = int(broker.position(sym).qty)
        delta = target_qty - current_qty

        if delta == 0:
            continue

        # Drift threshold applies only when symbol is held AND in target.
        # Full exits (target=0, held) and new entries (target>0, not held)
        # always execute.
        is_full_exit = target_w == 0.0 and current_qty != 0
        is_new_entry = current_qty == 0 and target_w > 0
        if not is_full_exit and not is_new_entry and min_drift_pct > 0:
            current_w = (current_qty * price) / equity if equity > 0 else 0.0
            drift = abs(current_w - target_w) * 100.0
            if drift < min_drift_pct:
                continue

        if delta > 0:
            buy_orders.append((sym, abs(delta)))
        else:
            sell_orders.append((sym, abs(delta)))

    # Sells first — frees cash in live brokers; harmless ordering choice here
    for sym, qty in sell_orders:
        broker.submit_market(sym, OrderSide.SELL, qty, ts)
    for sym, qty in buy_orders:
        broker.submit_market(sym, OrderSide.BUY, qty, ts)


def _compute_actual_weights(
    broker: PaperBroker,
    symbols: list[str],
    marks: dict[str, float],
) -> dict[str, float]:
    """Compute actual portfolio weights from current positions."""
    equity = broker.equity(marks)
    if equity <= 0:
        return {}
    weights: dict[str, float] = {}
    for sym in symbols:
        pos = broker.position(sym)
        if not pos.is_flat:
            mv = pos.market_value(marks.get(sym, 0.0))
            weights[sym] = mv / equity
    return weights
