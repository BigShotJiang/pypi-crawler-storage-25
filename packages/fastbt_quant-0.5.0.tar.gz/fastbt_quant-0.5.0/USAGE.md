# fastbt-quant Usage Guide

> Distribution name: **`fastbt-quant`**. Import name: **`fastbt`**.

## Getting Started

### 1. Install

```bash
# From PyPI (recommended for users)
pip install "fastbt-quant[data,report]"

# From source (for contributors)
git clone https://github.com/Vbhadala/fastbt
cd fastbt
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[data,report,dev]"
```

**Dependency groups:**

| Group | What it adds | When you need it |
|-------|-------------|-----------------|
| `data` | `requests` | Fetching data from idata.fyi |
| `report` | `quantstats` | HTML tearsheet reports |
| `signal` | `aiohttp` | Live signal server mode |
| `dev` | pytest, ruff, mypy | Development and testing |

### 2. Set up your API key

fastbt fetches market data from [idata.fyi](https://idata.fyi). Set your API key once:

```bash
fastbt config set idata-api-key <your-api-key>
```

This saves to `~/.fastbt/config.toml` and works from any directory on that machine.

**Other ways to provide the key:**

```bash
# Environment variable (useful for CI/Docker)
export IDATA_API_KEY=<your-api-key>

# Programmatic (in Python scripts)
from fastbt import IdataClient
client = IdataClient(api_key="<your-api-key>")
```

Resolution order: explicit `api_key=` > `IDATA_API_KEY` env var > `~/.fastbt/config.toml`.

### 3. Verify it works

```bash
fastbt fetch SBIN -o /tmp/sbin.csv
fastbt run examples/recipes/sma_crossover.json --symbol SBIN --cash 500000 --warmup 30
```

---

## Fetching Data

### Download to a file

```bash
# Save as CSV
fastbt fetch SBIN -o data/sbin.csv

# Save as Parquet
fastbt fetch SBIN -o data/sbin.parquet
```

### Fetch in Python

```python
from fastbt import IdataClient

client = IdataClient()

# Single symbol — returns a validated OHLCV DataFrame
df = client.fetch_ohlcv("SBIN")
print(df.head())

# Multiple symbols — returns dict[str, DataFrame]
data = client.fetch_universe(["SBIN", "HDFCBANK", "RELIANCE"])
```

### Data format

fastbt expects an OHLCV DataFrame with a `DatetimeIndex` and columns: `open`, `high`, `low`, `close`, `volume` (case-insensitive).

**From CSV:**

```python
df = pd.read_csv("data/sbin.csv", index_col=0, parse_dates=True)
```

**From Parquet:**

```python
df = pd.read_parquet("data/sbin.parquet")
```

The validator checks that all required columns exist, the index is a `DatetimeIndex`, there are no NaN values, and OHLC relationships are valid (high >= low, etc.).

---

## Running a Backtest

### From CLI (quickest)

```bash
# Fetch data from idata.fyi and run backtest in one command
fastbt run examples/recipes/sma_crossover.json --symbol SBIN --cash 500000 --warmup 30

# Or use a local data file
fastbt run examples/recipes/sma_crossover.json --data data/sbin.csv --symbol SBIN --cash 500000

# Generate HTML tearsheet
fastbt run examples/recipes/sma_crossover.json --symbol SBIN --cash 500000 --warmup 30 --report tearsheet.html

# Save result to JSON for later viewing
fastbt run examples/recipes/sma_crossover.json --symbol SBIN --cash 500000 --save result.json

# View a saved result
fastbt show result.json
```

### From Python

```python
import pandas as pd
from fastbt import Strategy, backtest, IdataClient

# Fetch data
client = IdataClient()
data = client.fetch_ohlcv("SBIN")

# Define a strategy
class SmaCross(Strategy):
    def initialize(self, ctx):
        self.fast = self.params.get("fast", 10)
        self.slow = self.params.get("slow", 30)

    def on_bar(self, ctx):
        close = ctx.history["close"]
        if len(close) < self.slow:
            return
        fast_ma = close.rolling(self.fast).mean().iloc[-1]
        slow_ma = close.rolling(self.slow).mean().iloc[-1]

        if fast_ma > slow_ma and ctx.position.is_flat:
            qty = int(ctx.cash * 0.95 / ctx.bar.close)
            if qty > 0:
                ctx.buy(qty)
        elif fast_ma < slow_ma and ctx.position.is_long:
            ctx.close()

# Run backtest
result = backtest(
    SmaCross(params={"fast": 10, "slow": 30}),
    data,
    symbol="SBIN",
    initial_cash=500_000,
    commission_pct=0.03,
    slippage_pct=0.05,
    warmup_bars=30,
)

print(result.metrics)
```

### What is `--warmup`?

The warmup period skips the first N bars before allowing any trades. This gives indicators time to build up meaningful values. For example, SMA(30) needs at least 30 bars of history before it produces a valid signal. Set `--warmup` to at least the longest indicator period in your strategy.

---

## Creating Strategies

### JSON Strategies (no code needed)

Define entry/exit rules as JSON. fastbt evaluates conditions each bar and manages positions automatically.

**Example: SMA Crossover** (`examples/recipes/sma_crossover.json`)

```json
{
  "version": "0.0.3",
  "entry": {
    "all": [
      {
        "left": {"indicator": "sma", "params": {"period": 10}, "output": "value", "source": "close"},
        "operator": "crosses_above",
        "right": {"indicator": "sma", "params": {"period": 30}, "output": "value", "source": "close"}
      }
    ]
  },
  "exit": {
    "all": [
      {
        "left": {"indicator": "sma", "params": {"period": 10}, "output": "value", "source": "close"},
        "operator": "crosses_below",
        "right": {"indicator": "sma", "params": {"period": 30}, "output": "value", "source": "close"}
      }
    ]
  },
  "position_sizing": {"method": "percent_equity", "pct": 95}
}
```

**Condition structure:**

Each condition compares a `left` operand to a `right` operand using an `operator`.

- **Operands** can be an indicator reference or a literal number
- **Operators:** `>`, `<`, `>=`, `<=`, `==`, `crosses_above`, `crosses_below`
- **Condition groups:** `"all"` (AND) and `"any"` (OR), nestable

**Indicator reference fields:**

| Field | Description | Default |
|-------|-------------|---------|
| `indicator` | Name: sma, ema, rsi, macd, bollinger_bands, atr, etc. | (required) |
| `params` | Indicator-specific: `{"period": 14}` | (required) |
| `output` | Output name: `"value"`, or `"macd"`, `"signal"`, `"histogram"` for MACD | `"value"` |
| `source` | OHLCV column: open, high, low, close, volume, hlc3, ohlc4 | `"close"` |
| `offset` | Look-back offset (0 = current bar, 1 = previous bar) | `0` |

**Available indicators:** sma, ema, rsi, macd, bollinger_bands, atr, stochastic, adx, cci, obv, vwap, supertrend, donchian, keltner, ichimoku, williams_r, mfi, roc, trix, kama

**Position sizing methods:**

| Method | Required field | Description |
|--------|---------------|-------------|
| `fixed_qty` | `qty` | Fixed number of shares |
| `percent_equity` | `pct` | % of equity |
| `fixed_cash` | `amount` | Fixed cash amount per trade |
| `risk_pct` | `risk_fraction` | Risk-based (requires stop-loss) |
| `kelly` | `kelly_fraction` | Kelly criterion fraction |

**Stop-losses and take-profits** (add to strategy JSON):

From v0.4.0, prefer the nested `stops:` form:

```json
{
  "kind": "single",
  "version": "0.4.0",
  "entry": { ... },
  "exit": { ... },
  "stops": {
    "stop_loss_pct": 5.0,
    "take_profit_pct": 10.0,
    "trailing_stop_pct": 3.0,
    "vol_trailing_multiplier": 2.0,
    "vol_trailing_lookback": 60,
    "vol_trailing_fallback_pct": 10.0
  }
}
```

The legacy flat shape (stop fields at the top level) still works for v0.0.3 / v0.2.0 specs — a back-compat shim normalizes them transparently. **Mixing flat and nested forms in the same spec raises an error** to avoid silent precedence in financial config.

**`kind` field (v0.4.0)** — every spec now self-describes as `"single"` (single-symbol) or `"portfolio"` (basket). Existing JSON files without `kind` continue to load as single-symbol when they have `entry`/`exit`. Portfolio specs must declare `kind: "portfolio"` explicitly.

**Available stop fields** (in `stops:` block or as flat top-level keys):

| Field | Description |
|-------|-------------|
| `stop_loss_pct` / `stop_loss_points` | Hard stop, % below entry or absolute points |
| `take_profit_pct` / `take_profit_points` | Take-profit at fixed level |
| `trailing_stop_pct` / `trailing_stop_points` | Standard trailing stop |
| `vol_trailing_multiplier` | v0.4.0 — band = N × annualized vol; recomputes every bar |
| `vol_trailing_lookback` | Bars used to estimate annualized vol (default 60) |
| `vol_trailing_fallback_pct` | Used when history < lookback or band would exceed 100% |

**Preset strategies** in `examples/recipes/`:

| File | Strategy |
|------|----------|
| `sma_crossover.json` | SMA(10) crosses above/below SMA(30) |
| `rsi_mean_reversion.json` | Buy when RSI < 30, sell when RSI > 70 |
| `bollinger_breakout.json` | Close breaks above/below Bollinger Bands |

### Python Strategies (full control)

Subclass `Strategy` and implement `on_bar()`:

```python
from fastbt import Strategy, backtest
from fastbt.indicators import sma, rsi

class RsiMeanReversion(Strategy):
    def on_bar(self, ctx):
        if len(ctx.history) < 20:
            return

        r = rsi(ctx.history["close"], 14).iloc[-1]

        if r < 30 and ctx.position.is_flat:
            ctx.buy(qty=100)
        elif r > 70 and ctx.position.is_long:
            ctx.close()
```

**Context object** (`ctx`) provides:

- `ctx.bar` — current bar (open, high, low, close, volume, timestamp)
- `ctx.history` — DataFrame of all bars up to now
- `ctx.position` — current position (`.is_flat`, `.is_long`, `.is_short`, `.qty`)
- `ctx.cash` / `ctx.equity` — account state
- `ctx.buy(qty)` / `ctx.sell(qty)` / `ctx.close()` — order helpers

**Shorting:**

```python
class ShortStrategy(Strategy):
    def on_bar(self, ctx):
        if some_bearish_signal and ctx.position.is_flat:
            ctx.sell(qty=100)   # Opens a short position
        elif exit_signal and ctx.position.is_short:
            ctx.close()         # Covers the short
```

**Stop-losses (from Python):**

```python
result = backtest(
    strategy,
    data,
    stop_loss_pct=5.0,
    take_profit_pct=10.0,
    trailing_stop_pct=3.0,
)
```

### Portfolio Strategies (multi-symbol)

```python
from fastbt import PortfolioStrategy, portfolio_backtest, IdataClient

client = IdataClient()
data = client.fetch_universe(["SBIN", "HDFCBANK", "ICICIBANK", "RELIANCE", "TCS"])

class EqualWeight(PortfolioStrategy):
    def on_rebalance(self, ctx):
        n = len(ctx.symbols)
        w = 1.0 / n if n > 0 else 0.0
        return {s: w for s in ctx.symbols}

result = portfolio_backtest(
    EqualWeight(),
    data,
    initial_cash=1_000_000,
    commission_pct=0.03,
    rebalance_every=5,
)

print(result.per_symbol_pnl)
print(result.turnover)
```

**Lifecycle pipeline** — for complex strategies, override individual steps:

```python
class MomentumTop3(PortfolioStrategy):
    def universe(self, ctx):
        """Filter: only liquid stocks."""
        return [s for s in ctx.symbols if ctx.bars[s].volume > 100_000]

    def rank(self, ctx, universe):
        """Score: 20-day momentum."""
        scores = []
        for sym in universe:
            hist = ctx.history[sym]["close"]
            ret = hist.iloc[-1] / hist.iloc[-20] - 1 if len(hist) >= 20 else 0.0
            scores.append((sym, ret))
        return sorted(scores, key=lambda x: x[1], reverse=True)

    def select(self, ctx, ranked):
        """Pick top 3."""
        return [sym for sym, _ in ranked[:3]]

    def allocate(self, ctx, selected):
        """Equal weight the selected symbols."""
        w = 0.9 / len(selected) if selected else 0.0
        return {s: w for s in selected}
```

The base class chains `universe() -> rank() -> select() -> allocate()` automatically when `on_rebalance()` is not overridden.

#### Built-in allocators (v0.3.0)

The `fastbt.allocators` module provides ready-made weight functions for use
inside `allocate()`:

```python
from fastbt.allocators import (
    annualized_volatility,
    equal_weight,
    inverse_volatility,
    momentum_score,
    momentum_weighted,
    risk_parity,
)

class Allocate(PortfolioStrategy):
    def allocate(self, ctx, selected):
        # equal weight
        return equal_weight(selected)

        # or weight by momentum scores
        scores = {s: ctx.scores[s] for s in selected}
        return momentum_weighted(selected, scores)

        # or inverse volatility
        vols = {s: annualized_volatility(ctx.history[s]["close"], 60) for s in selected}
        return inverse_volatility(selected, vols)
```

`momentum_score(metrics, weights)` is a small utility that combines named
metrics into a single score, skipping `None` values:

```python
score = momentum_score(
    {"r30d": 12.3, "r90d": None, "r180d": 8.1},
    {"r30d": 0.3, "r90d": 0.4, "r180d": 0.3},
)
# r90d is missing -> 0.3*12.3 + 0.3*8.1 = 6.12 (weights NOT renormalized)
```

#### Vol-adaptive trailing stops (v0.3.0)

`portfolio_backtest()` accepts the same stop kwargs as the single-symbol
`backtest()`, plus a vol-adaptive variant whose band scales with each
symbol's current annualized volatility:

```python
result = portfolio_backtest(
    strategy, data,
    schedule=RebalanceSchedule.monthly(day=1),
    vol_trailing_multiplier=2.0,        # band = 2 * annualized_vol
    vol_trailing_lookback=60,
    vol_trailing_fallback_pct=10.0,     # used when history < lookback bars
)

for event in result.stop_outs:
    print(event.symbol, event.kind, event.pnl, event.days_held)
```

Strategies can also declare stops via `stop_config()`; explicit kwargs win:

```python
class MyStrategy(PortfolioStrategy):
    def stop_config(self):
        return {"vol_trailing_multiplier": 2.0, "vol_trailing_fallback_pct": 10.0}
```

When a stop fires, the symbol is converted to cash and excluded from
rebalance entry on the same bar (cooldown). It's eligible again at the
next rebalance.

#### Drift-aware rebalancing (v0.3.0)

Set `min_drift_pct` to skip rebalance trades that would only nudge a
position by a small amount — reducing turnover and transaction costs:

```python
result = portfolio_backtest(
    strategy, data,
    schedule=RebalanceSchedule.monthly(day=1),
    min_drift_pct=2.0,    # skip if |actual - target| < 2% of portfolio
)
```

Full exits (held but not in target) and new entries (in target but not
held) always trade regardless of the threshold. Default is `0.0` (every
nonzero delta trades, matching v0.2.0 behavior).

---

## Reports and Results

### Terminal summary

Every `fastbt run` prints a summary:

```
fastbt v0.2.0

  Symbol:       SBIN
  Period:       2025-01-01 to 2026-04-17 (328 bars)
  Initial:      500,000.00
  Final:        644,248.15

  Total Return:    28.85%
  Max Drawdown:    11.76%
  Sharpe Ratio:    1.29
  Win Rate:        50.0%
  Profit Factor:   5.91
  Trades:          6
  Avg Trade PnL:   24,041.36
```

### HTML tearsheet

Requires `pip install fastbt-quant[report]` (installs QuantStats).

```bash
# Generate from CLI
fastbt run examples/recipes/sma_crossover.json --symbol SBIN --cash 500000 --warmup 30 --report tearsheet.html

# Open in browser
open tearsheet.html
```

From Python:

```python
from fastbt.report import tearsheet

tearsheet(result, "tearsheet.html")

# With benchmark comparison
tearsheet(result, "tearsheet.html", benchmark=benchmark_returns)
```

The tearsheet includes equity curve, drawdown chart, monthly returns heatmap, rolling Sharpe, and detailed statistics.

### Save and load results

```bash
# Save from CLI
fastbt run strategy.json --symbol SBIN --save result.json

# View later
fastbt show result.json
```

From Python:

```python
from fastbt import save_result, load_result

save_result(result, "my_backtest.json")
loaded = load_result("my_backtest.json")
```

### BacktestResult fields

```python
result.initial_cash
result.final_cash
result.equity_curve       # pd.Series with DatetimeIndex
result.fills              # List of Fill objects
result.metrics            # Metrics dataclass
result.stop_outs          # List of StopOutEvent (v0.3.0)

m = result.metrics
m.total_return_pct
m.max_drawdown_pct
m.sharpe                  # Annualized, 252 trading days. Pass risk_free_rate=N to backtest()
m.sortino                 # v0.3.0 — uses downside deviation only
m.cagr                    # v0.3.0 — compound annual growth rate
m.annual_volatility       # v0.3.0 — std(returns) * sqrt(252) * 100
m.win_rate_pct
m.profit_factor
m.num_trades
m.avg_trade_pnl
```

### PortfolioResult fields

Extends BacktestResult with:

```python
result.weight_history     # DataFrame: timestamps x symbols
result.per_symbol_pnl     # dict: {symbol: pnl}
result.turnover           # Mean absolute weight change / 2
result.stop_outs          # List of StopOutEvent (v0.3.0)
```

`StopOutEvent` fields: `symbol`, `kind` (`"sl"`/`"tp"`/`"ts"`/`"vol_ts"`),
`entry_price`, `exit_price`, `pnl`, `days_held`, `stop_level`, `entry_time`,
`exit_time`. PnL is derived from the broker's actual fill (post-slippage,
post-commission).

---

## CLI Reference

### `fastbt run`

Run a JSON strategy backtest.

```bash
fastbt run <strategy.json> [options]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--data FILE` | — | OHLCV data file (CSV or Parquet). Optional if `--symbol` is set. |
| `--symbol NAME` | `SYMBOL` | Symbol to fetch from idata.fyi (also used as display label) |
| `--cash AMOUNT` | `100000` | Initial cash |
| `--commission PCT` | `0.0` | Commission percentage (e.g., 0.03 = 3 bps) |
| `--slippage PCT` | `0.0` | Slippage percentage |
| `--warmup N` | `0` | Skip first N bars before trading starts |
| `--report FILE` | — | Generate HTML tearsheet at path |
| `--save FILE` | — | Save result to JSON file |
| `--quiet` | — | Suppress terminal summary |

When `--data` is omitted and `--symbol` is provided, data is fetched from idata.fyi automatically.

### `fastbt fetch`

Download OHLCV data from idata.fyi to a local file.

```bash
fastbt fetch <SYMBOL> -o <output-file>
```

Examples:

```bash
fastbt fetch SBIN -o data/sbin.csv
fastbt fetch HDFCBANK -o data/hdfcbank.parquet
```

### `fastbt show`

Display a previously saved backtest result.

```bash
fastbt show <result.json>
```

### `fastbt config`

Manage persistent configuration stored in `~/.fastbt/config.toml`.

```bash
# Set a value
fastbt config set idata-api-key <your-api-key>

# View current config (sensitive values are masked)
fastbt config show
```

Valid config keys: `idata-api-key`, `idata-base-url`.

### `fastbt signal`

Start a live signal server for bar-by-bar processing.

```bash
fastbt signal <strategy.json> [--port 8080] [--host 0.0.0.0] [--webhook-url URL]
```

Then POST bars to `http://localhost:8080/bar` and receive trade signals.

---

## Fill Policy

Controls when market orders execute:

- `"next_open"` (default) — Orders submitted on bar N fill at bar N+1's open. Realistic: avoids look-ahead bias.
- `"current_close"` — Orders fill at the current bar's close. Useful for same-bar strategies.

```python
result = backtest(strategy, data, fill_policy="current_close")
```

---

## Rebalance Schedules

Control when portfolio strategies rebalance:

```python
from fastbt import RebalanceSchedule

schedule = RebalanceSchedule.every_bar()        # Every bar (default)
schedule = RebalanceSchedule.every_n_bars(5)    # Every 5 bars
schedule = RebalanceSchedule.weekly(day=4)      # Every Friday
schedule = RebalanceSchedule.monthly("first")   # First trading day of month
schedule = RebalanceSchedule.monthly("last")    # Last trading day of month
schedule = RebalanceSchedule.monthly(day=15)    # First trading day on/after the 15th

result = portfolio_backtest(strategy, data, schedule=schedule)
```

`monthly(day=N)` clamps to the last trading day of the month when day N
doesn't exist (e.g. `day=30` in February → fires on the last trading day of
Feb), preserving the one-rebalance-per-month invariant.

---

## Examples

See the `examples/` directory:

- `examples/sma_crossover.py` — Python strategy with synthetic data
- `examples/real_data_backtest.py` — Single + portfolio backtest with idata.fyi API
- `examples/momentum_portfolio.py` — v0.3.0 — full momentum-rotation pipeline:
  rank by `roc` + `momentum_score`, pick top-N, allocate via
  `inverse_volatility`, rebalance monthly, vol-trailing stops
- `examples/recipes/sma_crossover.json` — JSON SMA crossover
- `examples/recipes/rsi_mean_reversion.json` — JSON RSI mean reversion
- `examples/recipes/bollinger_breakout.json` — JSON Bollinger band breakout
- `examples/momentum_portfolio.json` — v0.4.0 — JSON-driven momentum-rotation
  portfolio (parity-tested against `momentum_portfolio.py`)

## Unified loader: `load_strategy()` (v0.4.0)

`load_strategy()` accepts any JSON spec — single-symbol OR portfolio — and
returns the right strategy class based on the spec's `kind` field:

```python
import json
from fastbt import load_strategy, backtest, portfolio_backtest

# Single-symbol
with open("examples/recipes/sma_crossover.json") as f:
    strategy = load_strategy(json.load(f))    # -> JsonStrategy
result = backtest(strategy, data=ohlcv_df)

# Portfolio
with open("examples/momentum_portfolio.json") as f:
    strategy = load_strategy(json.load(f))    # -> JsonPortfolioStrategy
# (see the portfolio section below for the portfolio_backtest call)
```

Smart kind dispatch:

- Spec has `kind`? → use it (explicit wins).
- No `kind`, has `entry`/`exit`? → loads as single-symbol (back-compat for pre-v0.4.0 files).
- No `kind`, no `entry`/`exit`? → raises a clear error asking for `kind: "portfolio"`. No silent misroute.

`load_strategy()` accepts a Python dict, a JSON string, or JSON bytes.

## JSON portfolio strategies (v0.4.0)

Portfolio strategies can be written declaratively in JSON. Use
`load_strategy()` to dispatch to the right strategy class based on the spec's
`kind` field:

```python
import json
from fastbt import load_strategy, portfolio_backtest, schedule_from_spec

with open("examples/momentum_portfolio.json") as f:
    spec_dict = json.load(f)

strategy = load_strategy(spec_dict)
schedule = schedule_from_spec(strategy.spec)  # JSON `schedule` -> RebalanceSchedule

result = portfolio_backtest(
    strategy,
    data=universe,                 # dict[str, OHLCV DataFrame]
    initial_cash=strategy.spec.initial_cash,
    commission_pct=strategy.spec.commission_pct,
    slippage_pct=strategy.spec.slippage_pct,
    schedule=schedule,
    min_drift_pct=strategy.spec.min_drift_pct,
    risk_free_rate=strategy.spec.risk_free_rate,
)
```

A portfolio spec is the JSON equivalent of subclassing `PortfolioStrategy`. The
top-level keys map directly to the lifecycle methods:

| Spec key   | Python equivalent                |
|------------|----------------------------------|
| `universe` | `def universe(ctx)` filter       |
| `rank`     | `def rank(ctx, universe)`        |
| `select`   | `def select(ctx, ranked)`        |
| `allocate` | `def allocate(ctx, selected)`    |
| `schedule` | `RebalanceSchedule.*` factory    |
| `stops`    | `def stop_config()` return dict  |

### Allocators

| `method`              | Equivalent function in `fastbt.allocators` |
|-----------------------|--------------------------------------------|
| `equal_weight`        | `equal_weight(symbols)`                    |
| `momentum_weighted`   | `momentum_weighted(symbols, scores)`       |
| `inverse_volatility`  | `inverse_volatility(symbols, vols)`        |
| `risk_parity`         | `risk_parity(symbols, vols)` (alias)       |

`inverse_volatility` and `risk_parity` accept an optional `vol_lookback` (default 60).

### Schedules

| `type`            | Equivalent factory                          |
|-------------------|---------------------------------------------|
| `every_bar`       | `RebalanceSchedule.every_bar()`             |
| `every_n_bars`    | `RebalanceSchedule.every_n_bars(n)`         |
| `weekly`          | `RebalanceSchedule.weekly(day=0..6)`        |
| `monthly`         | `RebalanceSchedule.monthly(when=.../day=N)` |

Custom schedule predicates remain Python-only (function references can't
serialize to JSON) — subclass `PortfolioStrategy` directly for those.

### Ranking

The constrained `weighted_metrics` ranking computes a weighted sum of named
indicators on each symbol's price history:

```json
"rank": {
  "score": "weighted_metrics",
  "metrics": [
    {"indicator": "roc", "params": {"period": 30},  "output": "value", "weight": 0.25},
    {"indicator": "roc", "params": {"period": 90},  "output": "value", "weight": 0.35}
  ]
}
```

Strategies that need conditional logic or expression-based ranking (e.g.,
"rank by ROC unless ATR > 2x avg") still subclass `PortfolioStrategy` in
Python. The two paths interoperate.

### Stops

The same `StopsConfig` model is used by single-symbol and portfolio specs.
All 9 stop fields are addressable in JSON:

```json
"stops": {
  "vol_trailing_multiplier": 2.0,
  "vol_trailing_lookback": 60,
  "vol_trailing_fallback_pct": 10.0
}
```

Legacy single-symbol JSON files placing stop fields at the top level continue
to work via a back-compat shim. Mixing flat and nested forms in the same spec
raises a clear error — silent precedence in financial config is a foot-gun.
