# Changelog

All notable changes to fastbt are recorded here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) loosely, with
release-specific notes about backwards compatibility called out explicitly.

## [0.5.0] - 2026-05-03

First public release on PyPI as **`fastbt-quant`**. The import name stays
`fastbt` (so existing user code is unchanged); only the distribution name on
PyPI is new. This release also fixes a portfolio-mode correctness bug whose
fix is a small breaking change to the `Bar` dataclass.

### Added

- **PyPI distribution**: `pip install fastbt-quant`. Extras: `data`, `signal`,
  `report`. See README and USAGE for the full matrix.
- **`LICENSE` file** (MIT) — required by downstream legal review.
- **Project URLs** in `pyproject.toml` for Homepage / Issues / Changelog.
- **Smoke test** (`tests/test_smoke.py`) — minimal `import fastbt` + 5-line
  backtest, runs in CI to catch regressions in the public surface.
- **Direct broker tests** (`tests/test_broker.py`) covering symbol-aware
  order draining, including the regression scenario described below.

### Changed (breaking)

- **`Bar` now requires a `symbol` field.** Construction signature changed
  from `Bar(timestamp, open, high, low, close, volume)` to
  `Bar(timestamp, symbol, open, high, low, close, volume)`. The engine and
  signal server pass this automatically; only direct `Bar(...)` callers
  need to update.

  *Why:* `PaperBroker._drain_pending(price)` ignored `order.symbol`, so the
  first `on_bar_open` call in a portfolio-mode batch drained every pending
  order at one common price. With mixed price levels (e.g. CHEAP=100,
  PRICEY=3000) this produced nonsensical equity and >100% MDD. The fix
  threads `symbol` through the bar so the broker can match each fill to
  its own bar.

### Migration from 0.4.0

  ```python
  # Before
  bar = Bar(timestamp=ts, open=100, high=101, low=99, close=100, volume=1000)

  # After
  bar = Bar(timestamp=ts, symbol="SBIN", open=100, high=101, low=99, close=100, volume=1000)
  ```

  No JSON spec changes. No Strategy subclass changes. Only direct `Bar(...)`
  calls in test fixtures or custom adapters need the new field.

### Packaging

- `[tool.hatch.version]` reads from `src/fastbt/__init__.py` so
  `pyproject.toml` and `__version__` can no longer drift.
- `[tool.hatch.build.targets.sdist]` now uses an explicit allowlist —
  `.git`, `.context/`, `HANDOFF.md`, `TODOS.md`, `v003-plan.md`,
  `v010a-plan.md`, `.python-version`, `.gitkeep`, `.gitignore` no longer
  ship in the sdist.
- `IdataClient` is now lazily imported via `__getattr__` — `from fastbt
  import IdataClient` raises a friendly `ImportError` pointing to
  `pip install fastbt-quant[data]` instead of failing silently.
- Classifiers updated: `Development Status :: 4 - Beta`, added Python 3.13.

### Examples

- `examples/momentum_top5_nifty50.{py,json}` — top-5 Nifty 50 momentum
  portfolio (ROC 10/20/50 weighted score, equal weight, monthly rebalance).
  Demonstrates loading a JSON portfolio spec, fetching universe data via
  `IdataClient`, running a historical backtest, and printing today's picks.

## [0.4.0] - 2026-04-28

JSON declarative layer for portfolio strategies, plus vol_trailing in the
single-symbol JSON schema. The Python building blocks shipped in v0.3.0; this
release makes them addressable from JSON.

### Added

- **JSON portfolio strategy spec (new module: `fastbt.portfolio_schema`)**
  - `PortfolioStrategySpec` — top-level Pydantic model with `kind: "portfolio"`
    discriminator. Composes `UniverseFilter`, `WeightedMetricsRank`,
    `SelectSpec`, `AllocateSpec`, `ScheduleSpec`, and the shared `StopsConfig`.
  - **Discriminated unions**: typo'd allocator/schedule names fail at JSON load
    time, not deep in the bar loop.
    - `AllocateSpec`: `equal_weight`, `momentum_weighted`, `inverse_volatility`,
      `risk_parity`. `inverse_volatility`/`risk_parity` accept `vol_lookback`.
    - `ScheduleSpec`: `every_bar`, `every_n_bars`, `weekly`, `monthly` (with
      `when="first"|"last"` or `day=N`).
  - **Universe filters**: `min_history`, `min_avg_volume`, `max_symbols`. AND-composed.
  - **Weighted-metrics ranking**: `WeightedIndicatorRef` extends `IndicatorRef`
    with a `weight` field. Mirrors `allocators.momentum_score` (no z-score
    normalization — see TODOS).
  - `JsonPortfolioStrategy(PortfolioStrategy)` (new module
    `fastbt.json_portfolio_strategy`) compiles a spec into the existing
    `universe → rank → select → allocate` lifecycle. Zero new engine code.
  - `schedule_from_spec(spec)` translates a spec's schedule into the
    `RebalanceSchedule` the engine expects.
- **vol_trailing in single-symbol JSON** — `StopsConfig` now carries the three
  v0.3.0 vol-trailing fields (`vol_trailing_multiplier`, `vol_trailing_lookback`,
  `vol_trailing_fallback_pct`), reachable from both flat and nested shapes.
- **Shared `StopsConfig` submodel (in `fastbt.schema`)** — single source of truth
  for the 9 stop fields, used by both single-symbol and portfolio specs.
- **Unified loader** — `from fastbt import load_strategy` returns a `JsonStrategy`
  or `JsonPortfolioStrategy` depending on the spec's `kind`. Smart defaulting:
  legacy single-symbol JSON without `kind` still loads (when `entry`/`exit` are
  present); portfolio JSON missing `kind` raises a clear "kind required" error
  rather than silently misrouting to single-symbol.
- **Indicator param validation at the schema boundary** — `IndicatorRef` now
  invokes `default_registry.validate_params()` during Pydantic validation, so
  typo'd params (`periood: 14`) and unknown indicators fail at JSON load with
  a clear error listing valid options. Same rule applies to ranking metrics
  via `WeightedIndicatorRef`.
- **`kind` discriminator on `StrategySpec`** (defaults to `"single"` for
  back-compat) — sets up the same self-describing JSON pattern as the portfolio
  spec.
- **Version literal `"0.4.0"`** accepted on both spec types alongside the
  existing `"0.0.3"`/`"0.2.0"` literals on `StrategySpec`.

### Backwards compatibility

- Legacy flat stop fields (`stop_loss_pct`, `take_profit_pct`, …) at the top
  level of a single-symbol spec continue to work — a `model_validator(mode="before")`
  shim normalizes them into `stops: {...}`. **Specifying both flat and nested
  forms in the same spec now raises** to avoid silent precedence in financial
  config.
- Single-symbol JSON files without a `kind` field still load as `JsonStrategy`.
- All v0.0.3 / v0.2.0 spec versions still accepted.

### Migration

- The flat stop shape will be deprecated in a future release (v0.5+) and
  removed in v1.0.0. Migrate by moving stop fields under a `stops` key.
- New portfolio strategies should use `kind: "portfolio"` explicitly.

### Files

- `src/fastbt/schema.py` — added `StopsConfig`, `kind` discriminator, version
  literal, back-compat shim, indicator-registry validator on `IndicatorRef`.
- `src/fastbt/json_strategy.py` — `stop_config()` now reads from nested
  `stops`. Duplicate runtime indicator validation removed (now at schema).
- `src/fastbt/portfolio_schema.py` — NEW (256 LOC).
- `src/fastbt/json_portfolio_strategy.py` — NEW (215 LOC).
- `src/fastbt/loader.py` — NEW (74 LOC).
- `src/fastbt/__init__.py` — exports `load_strategy`, `PortfolioStrategySpec`,
  `JsonPortfolioStrategy`, `JsonStrategy`, `StopsConfig`, `StrategySpec`,
  `schedule_from_spec`. Bump `__version__` to `"0.4.0"`.
- `tests/test_portfolio_schema.py` — NEW (42 tests).
- `tests/test_json_portfolio_strategy.py` — NEW (20 tests, including 4
  mandatory JSON↔Python parity tests at `rtol=1e-10`, one per allocator).
- `tests/test_loader.py` — NEW (13 tests).
- `tests/test_schema.py` and `tests/test_json_strategy.py` — extended with
  vol_trailing, kind, version, back-compat, and stop_config-forwarding tests.
- `examples/momentum_portfolio.json` — JSON equivalent of
  `examples/momentum_portfolio.py`.

## [0.3.0] - 2026-04-28

Portfolio strategy modules — momentum scoring, allocators, vol-aware stops,
and drift-aware rebalancing. All Python building blocks ship now; the JSON
portfolio strategy spec is deferred to a follow-up release.

### Added

- **Indicators**
  - `pct_from_sma(series, period)` — percent distance from a moving average
    (registered in `default_registry`). `roc()` already implements
    `rolling_return`, so no alias was added.
- **Allocators (new module: `fastbt.allocators`)**
  - `equal_weight(symbols)` — `1/N` allocation
  - `momentum_weighted(symbols, scores)` — proportional to positive scores;
    falls back to equal-weight when no positive scores
  - `inverse_volatility(symbols, vols)` — weight inversely proportional to
    annualized vol; missing/zero vols excluded
  - `risk_parity(symbols, vols)` — alias of `inverse_volatility` (zero-
    correlation simplification; correlation-aware version is future work)
  - `annualized_volatility(prices, lookback=60, ddof=1)` — sample std of
    returns × √252, expressed as a percent. Returns `None` for insufficient
    history.
  - `momentum_score(metrics, weights)` — weighted sum of named metrics,
    skipping `None` values; weights are not renormalized
- **Stop engine**
  - `vol_trailing` stop type — stop band adapts to current annualized vol.
    Stop level recomputed every bar. Falls back to `vol_trailing_fallback_pct`
    when vol is unavailable or yields a degenerate band (≥100%).
    Available on both `backtest()` and `portfolio_backtest()`.
  - `StopOutEvent` dataclass — recorded on every stop trigger with `kind`,
    `entry_price`, `exit_price`, `pnl`, `days_held`, `stop_level`,
    `entry_time`, `exit_time`. PnL is derived from the broker's actual fill
    (post-slippage, post-commission), not from StopTracker price math.
  - `BacktestResult.stop_outs` and `PortfolioResult.stop_outs` — list of
    triggered stop events for diagnostic analysis.
- **Portfolio engine**
  - Per-symbol stop integration in `portfolio_backtest()`. New kwargs:
    `stop_loss_pct`, `stop_loss_points`, `take_profit_pct`,
    `take_profit_points`, `trailing_stop_pct`, `trailing_stop_points`,
    `vol_trailing_multiplier`, `vol_trailing_lookback`,
    `vol_trailing_fallback_pct`. Explicit kwargs override values returned by
    the new `PortfolioStrategy.stop_config()` hook (mirrors the single-symbol
    pattern).
  - Same-bar cooldown — when a stop fires at bar N, that symbol is excluded
    from any rebalance entry on the same bar (eligible again from bar N+1).
  - Drift-aware `_rebalance_to_weights` — new `min_drift_pct` kwarg on
    `portfolio_backtest()`. Holdings whose target-vs-actual drift falls
    below the threshold are skipped, reducing turnover. Full exits and new
    entries always trade regardless of threshold. Sells are submitted before
    buys (consistency with live brokers).
- **Schedule**
  - `RebalanceSchedule.monthly(day=N)` — fires on the first trading day on
    or after day N of each month. Clamps to the last trading day of the
    month when day N doesn't exist (e.g. `day=30` in February). Preserves
    the one-rebalance-per-month invariant.
- **Metrics**
  - `Metrics.cagr` — compound annual growth rate
  - `Metrics.sortino` — Sortino ratio. Returns `999.99` when there's no
    downside but positive excess; `0.0` when neither (matches the
    `profit_factor` convention).
  - `Metrics.annual_volatility` — annualized return std (× √252)
  - `risk_free_rate` parameter on `backtest()`, `portfolio_backtest()`, and
    `Metrics.from_equity_curve()`. Default `0.0` (international convention).
    Set per market when needed (e.g. `6.0` for India).
- Public exports: `StopOutEvent` is now importable from `fastbt`.

### Changed

- `Metrics` gains three optional fields (`cagr`, `sortino`,
  `annual_volatility`) with `0.0` defaults so existing positional
  construction (e.g. `Metrics(0, 0, 0, 0, 0, 0, 0, 0)`) still works.
- `signal_engine._STOP_KIND_TO_SIGNAL` now maps `'vol_ts'` to
  `SignalType.TRAILING_STOP_HIT` so vol-trailing stops in live mode classify
  correctly.

### Backwards compatibility

- `min_drift_pct` defaults to `0.0`, so portfolio backtests behave
  identically to v0.2.0 unless the threshold is explicitly enabled.
- `risk_free_rate` defaults to `0.0`, so Sharpe with the default produces
  the same value as the v0.2.0 calculation.
- `monthly("first")` and `monthly("last")` still work unchanged.
- Existing `StopTracker` configurations (`stop_loss_pct`, `trailing_stop_pct`,
  etc.) behave identically; vol-trailing is purely additive.
- Saved results from v0.2.0 cannot be loaded into v0.3.0 because the
  version-strict `load_result()` rejects mismatched versions. Re-run the
  backtest under v0.3.0 to regenerate.

### Deferred (follow-up PRs)

- JSON portfolio strategy spec — `PortfolioStrategySpec` Pydantic model with
  scoring/allocation/rebalance/risk sections.
- `vol_trailing` in single-symbol JSON `StrategySpec`.
- Intrabar lookahead bias in stop evaluation (pre-existing — uses full-bar
  high/low before strategy runs; tracked in `TODOS.md`).

## [0.2.0]

- Live signal engine, webhook server, idata.fyi data module, config system.

## [0.1.0]

- Portfolio lifecycle pipeline (`universe → rank → select → allocate`),
  CLI, reporting, scheduling, serialization.

## [0.0.3]

- Shorting, stop-losses, portfolio engine, risk management.

## [0.0.2]

- JSON declarative strategy engine, 14 additional indicators, indicator
  registry.

## [0.0.1]

- Initial scaffold: paper broker, 6 indicators, OHLCV validator.
