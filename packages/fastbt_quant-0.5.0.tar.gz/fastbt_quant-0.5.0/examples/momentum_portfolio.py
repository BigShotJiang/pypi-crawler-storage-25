"""End-to-end example: momentum-rotation portfolio strategy.

Demonstrates the v0.3.0 portfolio modules end-to-end:
    universe -> rank (roc + momentum_score) -> select top N
        -> allocate (inverse_volatility) -> rebalance monthly
        -> vol-trailing stops with same-bar cooldown
        -> drift-aware rebalancing to reduce turnover

Self-contained — generates synthetic ETF-like price series so it runs
without an external data source.

Run:
    uv run python examples/momentum_portfolio.py
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from fastbt import PortfolioStrategy, RebalanceSchedule, portfolio_backtest
from fastbt.allocators import (
    annualized_volatility,
    inverse_volatility,
    momentum_score,
)
from fastbt.indicators import roc

# -----------------------------------------------------------------------------
# Strategy
# -----------------------------------------------------------------------------

# Weights chosen by the strategy author. Not a fastbt-blessed preset —
# every momentum strategy picks its own combination.
MOMENTUM_WEIGHTS = {
    "r30d": 0.25,
    "r90d": 0.35,
    "r180d": 0.25,
    "r360d": 0.15,
}


class MomentumTopN(PortfolioStrategy):
    """Top-N momentum rotation, weighted by inverse volatility."""

    def initialize(self, ctx):
        self.top_n = int(self.params.get("top_n", 3))
        self.vol_lookback = int(self.params.get("vol_lookback", 60))

    def universe(self, ctx):
        # Need at least the longest momentum lookback to score
        return [s for s in ctx.symbols if len(ctx.history[s]) >= 90]

    def rank(self, ctx, universe):
        scored: list[tuple[str, float]] = []
        for sym in universe:
            close = ctx.history[sym]["close"]
            metrics = {
                "r30d": roc(close, 30).iloc[-1] if len(close) >= 30 else None,
                "r90d": roc(close, 90).iloc[-1] if len(close) >= 90 else None,
                "r180d": roc(close, 180).iloc[-1] if len(close) >= 180 else None,
                "r360d": roc(close, 360).iloc[-1] if len(close) >= 360 else None,
            }
            scored.append((sym, momentum_score(metrics, MOMENTUM_WEIGHTS)))
        return sorted(scored, key=lambda x: x[1], reverse=True)

    def select(self, ctx, ranked):
        return [sym for sym, _score in ranked[: self.top_n]]

    def allocate(self, ctx, selected):
        vols = {
            s: annualized_volatility(ctx.history[s]["close"], self.vol_lookback)
            for s in selected
        }
        return inverse_volatility(selected, vols)


# -----------------------------------------------------------------------------
# Synthetic data — five ETF-like symbols with different drifts and vols
# -----------------------------------------------------------------------------


def _synthetic_etf(
    n_bars: int,
    drift: float,
    vol: float,
    start_price: float,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2022-01-01", periods=n_bars)
    returns = rng.normal(loc=drift, scale=vol, size=n_bars)
    close = start_price * np.exp(np.cumsum(returns))
    open_ = close * (1 + rng.normal(0, 0.003, n_bars))
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, 0.003, n_bars)))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, 0.003, n_bars)))
    volume = rng.integers(50_000, 500_000, n_bars).astype(float)
    return pd.DataFrame(
        {"open": open_, "high": high, "low": low, "close": close, "volume": volume},
        index=dates,
    )


def make_universe(n_bars: int = 800) -> dict[str, pd.DataFrame]:
    """Generate five ETF-like series with varied drift/vol profiles."""
    return {
        "EQUITY": _synthetic_etf(n_bars, 0.0008, 0.012, 100.0, seed=1),
        "BONDS":  _synthetic_etf(n_bars, 0.0002, 0.004, 100.0, seed=2),
        "GOLD":   _synthetic_etf(n_bars, 0.0004, 0.010, 100.0, seed=3),
        "SMALL":  _synthetic_etf(n_bars, 0.0010, 0.020, 100.0, seed=4),
        "INTL":   _synthetic_etf(n_bars, 0.0005, 0.013, 100.0, seed=5),
    }


# -----------------------------------------------------------------------------
# Run
# -----------------------------------------------------------------------------


def main() -> None:
    data = make_universe(n_bars=800)

    result = portfolio_backtest(
        MomentumTopN(params={"top_n": 3, "vol_lookback": 60}),
        data,
        initial_cash=1_000_000,
        commission_pct=0.05,
        slippage_pct=0.02,
        schedule=RebalanceSchedule.monthly(day=1),
        min_drift_pct=2.0,                     # skip rebalances under 2% drift
        vol_trailing_multiplier=2.0,           # band = 2 x annualized vol
        vol_trailing_lookback=60,
        vol_trailing_fallback_pct=10.0,
        risk_free_rate=6.0,                    # India default for Sharpe / Sortino
    )

    m = result.metrics
    print(result)
    print()
    print(f"  CAGR:             {m.cagr:.2f}%")
    print(f"  Sortino:          {m.sortino:.2f}")
    print(f"  Annual Vol:       {m.annual_volatility:.2f}%")
    print(f"  Sharpe (rf=6%):   {m.sharpe:.2f}")
    print(f"  Max Drawdown:     {m.max_drawdown_pct:.2f}%")
    print(f"  Trades:           {m.num_trades}")
    print(f"  Turnover:         {result.turnover:.4f}")
    print(f"  Stop-outs:        {len(result.stop_outs)}")
    print()

    if result.stop_outs:
        print("First 5 stop-outs:")
        for ev in result.stop_outs[:5]:
            print(
                f"  {ev.exit_time.date()}  {ev.symbol:6s}  kind={ev.kind:6s}  "
                f"entry={ev.entry_price:7.2f}  exit={ev.exit_price:7.2f}  "
                f"pnl={ev.pnl:+10.2f}  held={ev.days_held}d"
            )
        print()

    print("Per-symbol PnL:")
    for sym, pnl in sorted(result.per_symbol_pnl.items(), key=lambda x: -x[1]):
        print(f"  {sym:6s}  {pnl:+12.2f}")


if __name__ == "__main__":
    main()
