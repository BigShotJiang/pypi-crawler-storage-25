"""End-to-end example: SMA crossover strategy on synthetic data.

Run:
    uv run python examples/sma_crossover.py
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from fastbt import Strategy, backtest
from fastbt.indicators import sma


class SmaCrossover(Strategy):
    def initialize(self, ctx):
        self.fast = self.params.get("fast", 10)
        self.slow = self.params.get("slow", 30)

    def on_bar(self, ctx):
        if len(ctx.history) < self.slow + 1:
            return

        close = ctx.history["close"]
        fast_now = sma(close, self.fast).iloc[-1]
        slow_now = sma(close, self.slow).iloc[-1]
        fast_prev = sma(close, self.fast).iloc[-2]
        slow_prev = sma(close, self.slow).iloc[-2]

        crossed_up = fast_prev <= slow_prev and fast_now > slow_now
        crossed_down = fast_prev >= slow_prev and fast_now < slow_now

        if crossed_up and ctx.position.is_flat:
            qty = int(ctx.cash * 0.95 / ctx.bar.close)
            if qty > 0:
                ctx.buy(qty=qty)
        elif crossed_down and ctx.position.is_long:
            ctx.close()


def make_synthetic_ohlcv(n_bars: int = 500, seed: int = 42) -> pd.DataFrame:
    """Generate a synthetic OHLCV series with trend + noise."""
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2023-01-01", periods=n_bars, freq="D")

    returns = rng.normal(loc=0.0005, scale=0.015, size=n_bars)
    close = 100 * np.exp(np.cumsum(returns))
    open_ = close * (1 + rng.normal(0, 0.005, n_bars))
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, 0.005, n_bars)))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, 0.005, n_bars)))
    volume = rng.integers(100_000, 1_000_000, n_bars).astype(float)

    return pd.DataFrame(
        {"open": open_, "high": high, "low": low, "close": close, "volume": volume},
        index=dates,
    )


def main() -> None:
    data = make_synthetic_ohlcv(n_bars=500)

    strategy = SmaCrossover(params={"fast": 10, "slow": 30})
    result = backtest(
        strategy,
        data=data,
        initial_cash=100_000,
        commission_pct=0.1,
        slippage_pct=0.05,
    )

    print(result)
    print("\nMetrics:")
    for k, v in result.metrics.__dict__.items():
        print(f"  {k}: {v}")

    print(f"\nFirst 5 fills ({len(result.fills)} total):")
    for f in result.fills[:5]:
        print(f"  {f.timestamp.date()}  {f.side.value:4s}  qty={f.qty:>6.0f}  @ {f.price:8.2f}")


if __name__ == "__main__":
    main()
