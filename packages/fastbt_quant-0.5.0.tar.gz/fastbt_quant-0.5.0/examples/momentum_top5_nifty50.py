"""Top-5 Nifty 50 momentum portfolio — monthly rebalance, equal weight.

Score = mean of ROC(10), ROC(20), ROC(50). Top 5 by score get 20% each,
rebalanced on the first trading day of each month. Strategy is declared
in `momentum_top5_nifty50.json`; this script loads it, fetches Nifty 50
EOD data via the idata API, and:

    1. Runs a historical portfolio backtest.
    2. Prints today's pick — what the strategy would hold if rebalanced now.

Requires:
    IDATA_API_KEY in the environment (or in `.env` at the repo root).

Run:
    uv run python examples/momentum_top5_nifty50.py
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pandas as pd

# Repo-local src import for running without `pip install -e .`
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from fastbt import IdataClient, load_strategy, portfolio_backtest, schedule_from_spec
from fastbt.allocators import momentum_score
from fastbt.indicators import roc

# ── Nifty 50 universe (NSE EQ symbols) ──────────────────────────────────
# Static snapshot — refresh periodically as constituents change.
NIFTY_50: list[str] = [
    "ADANIENT", "ADANIPORTS", "APOLLOHOSP", "ASIANPAINT", "AXISBANK",
    "BAJAJ-AUTO", "BAJFINANCE", "BAJAJFINSV", "BHARTIARTL", "BPCL",
    "BRITANNIA", "CIPLA", "COALINDIA", "DIVISLAB", "DRREDDY",
    "EICHERMOT", "GRASIM", "HCLTECH", "HDFCBANK", "HDFCLIFE",
    "HEROMOTOCO", "HINDALCO", "HINDUNILVR", "ICICIBANK", "INDUSINDBK",
    "INFY", "ITC", "JSWSTEEL", "KOTAKBANK", "LT",
    "LTIM", "M&M", "MARUTI", "NESTLEIND", "NTPC",
    "ONGC", "POWERGRID", "RELIANCE", "SBILIFE", "SBIN",
    "SHRIRAMFIN", "SUNPHARMA", "TATACONSUM", "TATAMOTORS", "TATASTEEL",
    "TCS", "TECHM", "TITAN", "ULTRACEMCO", "WIPRO",
]

SPEC_PATH = Path(__file__).with_name("momentum_top5_nifty50.json")


# ── .env loader (no extra deps) ─────────────────────────────────────────


def load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


# ── Data ────────────────────────────────────────────────────────────────


def fetch_universe(symbols: list[str]) -> dict[str, pd.DataFrame]:
    client = IdataClient()
    data: dict[str, pd.DataFrame] = {}
    for sym in symbols:
        try:
            data[sym] = client.fetch_ohlcv(sym)
            print(f"  {sym:12s}  {len(data[sym]):4d} bars  "
                  f"{data[sym].index[0].date()} → {data[sym].index[-1].date()}")
        except Exception as e:
            print(f"  {sym:12s}  SKIPPED ({e})")
    return data


# ── Live snapshot — score against the most recent bars ─────────────────


def current_picks(
    data: dict[str, pd.DataFrame],
    weights: dict[str, float],
    top_n: int,
    min_history: int,
) -> list[tuple[str, float, float, float, float]]:
    """Return [(symbol, score, roc10, roc20, roc50)] sorted by score desc."""
    scored: list[tuple[str, float, float, float, float]] = []
    for sym, df in data.items():
        close = df["close"]
        if len(close) < min_history:
            continue
        r10 = roc(close, 10).iloc[-1]
        r20 = roc(close, 20).iloc[-1]
        r50 = roc(close, 50).iloc[-1]
        metrics = {"r10": r10, "r20": r20, "r50": r50}
        score = momentum_score(metrics, weights)
        scored.append((sym, score, r10, r20, r50))
    scored.sort(key=lambda x: x[1], reverse=True)
    return scored[:top_n]


# ── Main ────────────────────────────────────────────────────────────────


def main() -> None:
    load_dotenv(ROOT / ".env")

    spec = json.loads(SPEC_PATH.read_text())
    strategy = load_strategy(spec)
    schedule = schedule_from_spec(strategy.spec)

    print("=" * 70)
    print(f"Strategy: top-{spec['select']['top_n']} Nifty 50 by momentum "
          f"(ROC 10/20/50), equal weight, monthly rebalance")
    print("=" * 70)
    print(f"\nFetching {len(NIFTY_50)} Nifty 50 symbols from idata.fyi…\n")

    data = fetch_universe(NIFTY_50)
    if len(data) < spec["select"]["top_n"]:
        sys.exit(f"\nNot enough symbols fetched ({len(data)}). Aborting.")

    # Drop symbols whose history ends well before the latest bar — the engine
    # aligns to the intersection of date ranges, so a single truncated series
    # caps the entire backtest. Keep only symbols within 5 trading days of
    # the latest bar in the universe.
    latest = max(df.index[-1] for df in data.values())
    cutoff = latest - pd.Timedelta(days=10)
    dropped = [s for s, df in data.items() if df.index[-1] < cutoff]
    if dropped:
        print(f"\n  Dropping {len(dropped)} symbols with stale data: {dropped}")
        for s in dropped:
            del data[s]

    # ── Historical backtest ────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("HISTORICAL BACKTEST")
    print("=" * 70)

    result = portfolio_backtest(
        strategy,
        data,
        initial_cash=spec["initial_cash"],
        commission_pct=spec["commission_pct"],
        slippage_pct=spec["slippage_pct"],
        schedule=schedule,
        risk_free_rate=spec.get("risk_free_rate", 0.0),
    )

    m = result.metrics
    eq = result.equity_curve
    print(f"\n  Period:           {eq.index[0].date()} → {eq.index[-1].date()}")
    print(f"  Final equity:     ₹{eq.iloc[-1]:,.0f}")
    print(f"  CAGR:             {m.cagr:.2f}%")
    print(f"  Annual Vol:       {m.annual_volatility:.2f}%")
    print(f"  Sharpe (rf=6%):   {m.sharpe:.2f}")
    print(f"  Sortino:          {m.sortino:.2f}")
    print(f"  Max Drawdown:     {m.max_drawdown_pct:.2f}%")
    print(f"  Trades:           {m.num_trades}")
    print(f"  Turnover:         {result.turnover:.4f}")

    print("\n  Top per-symbol PnL:")
    pnl_sorted = sorted(result.per_symbol_pnl.items(), key=lambda x: -x[1])
    for sym, pnl in pnl_sorted[:10]:
        print(f"    {sym:12s}  ₹{pnl:+12,.0f}")

    # ── Live snapshot — what would we hold today? ──────────────────────
    print("\n" + "=" * 70)
    print(f"CURRENT PICKS (as of latest bar)")
    print("=" * 70)

    weights = {f"r{m['params']['period']}": m["weight"] for m in spec["rank"]["metrics"]}
    picks = current_picks(
        data,
        weights=weights,
        top_n=spec["select"]["top_n"],
        min_history=spec["universe"]["min_history"],
    )

    latest_dates = sorted({df.index[-1] for df in data.values()})
    print(f"\n  Latest bar across universe: {latest_dates[-1].date()}")
    print(f"  Equal weight: {100 / len(picks):.2f}% per name\n")
    print(f"  {'Rank':<5}{'Symbol':<12}{'Score':>8}{'ROC10':>9}{'ROC20':>9}{'ROC50':>9}")
    print(f"  {'-'*4:<5}{'-'*10:<12}{'-'*7:>8}{'-'*8:>9}{'-'*8:>9}{'-'*8:>9}")
    # roc() already returns percent — no extra *100.
    for i, (sym, score, r10, r20, r50) in enumerate(picks, 1):
        print(
            f"  {i:<5}{sym:<12}{score:>7.2f}%"
            f"{r10:>8.2f}%{r20:>8.2f}%{r50:>8.2f}%"
        )


if __name__ == "__main__":
    main()
