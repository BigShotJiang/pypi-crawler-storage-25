"""Example: Run fastbt backtests against real EOD data from the idata API.

Usage:
    python examples/real_data_backtest.py

Requires:
    - idata API running on localhost:8001
    - Valid auth token (set IDATA_TOKEN env var or edit TOKEN below)
"""

from __future__ import annotations

import os
import sys

import pandas as pd
import requests

# ── fastbt imports ──────────────────────────────────────────────────────
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from fastbt import Strategy, backtest, portfolio_backtest
from fastbt.portfolio_strategy import PortfolioStrategy

# ── Config ──────────────────────────────────────────────────────────────

BASE_URL = "http://localhost:8001/api/data/eod/equity/browse"
TOKEN = os.environ.get(
    "IDATA_TOKEN",
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJpZGF0YXZiIiwidXNlcl9pZCI6MSwiZW1haWwiOiJ2aW5vZGJoYWRhbGFAZ21haWwuY29tIiwiaXNfYWRtaW4iOnRydWUsImV4cCI6MTc3Njk5NTYyNn0.Ev_1h3XJcZ-M4OmRi9yIbRsauHqqFCAKP7xlQ8srdGM",
)
HEADERS = {"Authorization": f"Bearer {TOKEN}", "accept": "application/json"}


# ── Data fetching ───────────────────────────────────────────────────────


def fetch_ohlcv(symbol: str, per_page: int = 200) -> pd.DataFrame:
    """Fetch EOD data from idata API and return as OHLCV DataFrame."""
    rows = []
    page = 1
    while True:
        resp = requests.get(
            BASE_URL,
            params={
                "symbol": symbol,
                "order": "asc",
                "page": page,
                "per_page": per_page,
            },
            headers=HEADERS,
        )
        resp.raise_for_status()
        data = resp.json()
        batch = data.get("rows", [])
        if not batch:
            break
        rows.extend(batch)
        total = data.get("total", 0)
        if len(rows) >= total:
            break
        page += 1

    if not rows:
        raise ValueError(f"No data returned for {symbol}")

    df = pd.DataFrame(rows)
    df["trade_date"] = pd.to_datetime(df["trade_date"])
    df = df.drop_duplicates(subset=["trade_date"])
    df = df.set_index("trade_date").sort_index()

    # Select and rename to standard OHLCV
    ohlcv = df[["open", "high", "low", "close", "volume"]].copy()
    ohlcv = ohlcv.dropna()
    return ohlcv


# ── Strategies ──────────────────────────────────────────────────────────


class SmaCrossover(Strategy):
    """Classic SMA crossover — long when fast > slow, exit when fast < slow."""

    def initialize(self, ctx):
        self.fast = self.params.get("fast", 20)
        self.slow = self.params.get("slow", 50)

    def on_bar(self, ctx):
        close = ctx.history["close"]
        if len(close) < self.slow:
            return
        fast_ma = close.rolling(self.fast).mean().iloc[-1]
        slow_ma = close.rolling(self.slow).mean().iloc[-1]
        if fast_ma > slow_ma and ctx.position.is_flat:
            ctx.buy(qty=100)
        elif fast_ma < slow_ma and ctx.position.is_long:
            ctx.close()


class MomentumEqualWeight(PortfolioStrategy):
    """Equal-weight the top N stocks by recent momentum."""

    def initialize(self, ctx):
        self.lookback = self.params.get("lookback", 20)
        self.top_n = self.params.get("top_n", 3)

    def on_rebalance(self, ctx):
        # Rank by return over lookback period
        returns = {}
        for sym in ctx.symbols:
            hist = ctx.history[sym]
            if len(hist) >= self.lookback:
                ret = hist["close"].iloc[-1] / hist["close"].iloc[-self.lookback] - 1
                returns[sym] = ret

        if not returns:
            return {}

        # Pick top N
        ranked = sorted(returns, key=returns.get, reverse=True)
        top = ranked[: self.top_n]
        weight = 0.9 / len(top)  # 90% invested, 10% cash
        return {sym: weight for sym in top}


# ── Main ────────────────────────────────────────────────────────────────


def run_single_symbol():
    print("=" * 60)
    print("SINGLE-SYMBOL BACKTEST: SMA Crossover on SBIN")
    print("=" * 60)

    df = fetch_ohlcv("SBIN")
    print(f"Data: {len(df)} bars, {df.index[0].date()} to {df.index[-1].date()}")

    result = backtest(
        SmaCrossover(params={"fast": 20, "slow": 50}),
        df,
        symbol="SBIN",
        initial_cash=500_000.0,
        commission_pct=0.03,
        slippage_pct=0.05,
        warmup_bars=50,
    )
    print(f"\n{result}")
    print(f"  Final equity: ₹{result.equity_curve.iloc[-1]:,.0f}")
    print(f"  Trades: {result.metrics.num_trades}")
    print(f"  Win rate: {result.metrics.win_rate_pct:.1f}%")
    print(f"  Sharpe: {result.metrics.sharpe:.2f}")
    print(f"  Max DD: {result.metrics.max_drawdown_pct:.2f}%")
    print(f"  Fills: {len(result.fills)}")


def run_portfolio():
    print("\n" + "=" * 60)
    print("PORTFOLIO BACKTEST: Momentum Top-3 on Banking Stocks")
    print("=" * 60)

    symbols = ["SBIN", "HDFCBANK", "ICICIBANK", "KOTAKBANK", "AXISBANK"]
    data = {}
    for sym in symbols:
        try:
            df = fetch_ohlcv(sym)
            data[sym] = df
            print(f"  {sym}: {len(df)} bars")
        except Exception as e:
            print(f"  {sym}: SKIPPED ({e})")

    if len(data) < 2:
        print("Need at least 2 symbols. Skipping portfolio backtest.")
        return

    result = portfolio_backtest(
        MomentumEqualWeight(params={"lookback": 20, "top_n": 3}),
        data,
        initial_cash=1_000_000.0,
        commission_pct=0.03,
        slippage_pct=0.05,
        warmup_bars=30,
        rebalance_every=5,  # rebalance every 5 bars (~weekly)
    )
    print(f"\n{result}")
    print(f"  Final equity: ₹{result.equity_curve.iloc[-1]:,.0f}")
    print(f"  Sharpe: {result.metrics.sharpe:.2f}")
    print(f"  Max DD: {result.metrics.max_drawdown_pct:.2f}%")
    print(f"  Turnover: {result.turnover:.4f}")
    print(f"  Fills: {len(result.fills)}")
    print(f"\n  Per-symbol PnL:")
    for sym, pnl in sorted(result.per_symbol_pnl.items(), key=lambda x: x[1], reverse=True):
        print(f"    {sym}: ₹{pnl:,.0f}")


if __name__ == "__main__":
    try:
        run_single_symbol()
        run_portfolio()
    except requests.exceptions.ConnectionError:
        print("ERROR: Cannot connect to idata API at localhost:8001")
        print("Make sure the API server is running.")
        sys.exit(1)
