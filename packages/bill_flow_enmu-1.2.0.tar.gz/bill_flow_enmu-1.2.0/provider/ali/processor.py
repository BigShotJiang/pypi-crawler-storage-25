import logging
import json
from pathlib import Path
from datetime import date, datetime
from decimal import Decimal
from functools import lru_cache

from ir.ir import IR, Order
from provider.ali.ali_types import DealStatus


def post_process(ir: IR) -> IR:
    orders = []

    for i, o in enumerate(ir.orders):
        status = o.meta_data.get("status")
        omi = o.meta_data.get("order_id") or ""

        # 1. 交易退款冲回过滤：互相抵消退款和原订单
        if status == DealStatus.REPAY.value and o.category == "退款":
            for j, ori in enumerate(ir.orders):
                # 跳过自身、已被标记为无用的订单、以及其他退款订单
                if i == j or ori.meta_data.get("useless") == "true" or ori.category == "退款":
                    continue
                
                omj = ori.meta_data.get("order_id") or ""
                # 如果退款订单ID以原始订单ID开头，且金额一致，则冲回双方
                if omj and omi.startswith(omj) and o.money == ori.money:
                    o.meta_data["useless"] = "true"
                    ori.meta_data["useless"] = "true"
                    break  # 找到关联订单后立即中断内层循环，避免 O(N^2) 性能耗损
                    
        # 2. 异常及无效状态过滤
        if status == DealStatus.CLOSE.value and o.meta_data.get("type") == "不计收支":
            o.meta_data["useless"] = "true"
            logging.info(f"订单取消被过滤: {omi or '未知ID'}")

        if status == DealStatus.SHOP_PENDING.value:
            o.meta_data["useless"] = "true"

    # 3. 收集并处理有效订单
    for v in ir.orders:
        if v.meta_data.get("useless") != "true":
            orders.append(v)
            
            # 逻辑修正：只对有效的真实交易触发还款生成逻辑 (之前无论是否useless都做了生成)
            spec_order = pre_repay(v)
            if spec_order:
                orders.append(spec_order)

    # 4. 全局定期策略检查
    google_order = pre_google()
    if google_order:
        orders.append(google_order)

    ir.orders = orders
    return ir


@lru_cache(maxsize=1)
def _get_accounts() -> dict:
    """获取账户配置并缓存，避免循环中频繁读取文件"""
    account_path = Path.home() / ".flow" / "account.json"
    if account_path.is_file():
        try:
            with open(account_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logging.error(f"解析配置文件失败 {account_path}: {e}")
    return {}

def pre_google():
    """处理 Google One 定期记账逻辑（仅执行一次）"""
    accounts = _get_accounts()
    google_obj = accounts.get("google_one")
    
    if not google_obj or str(date.today().day) != str(google_obj.get("payday")):
        return None

    google_order = Order()
    # 为了确保有时间信息，使用当前完整时间戳
    google_order.pay_time = datetime.now()
    google_order.minus_account = google_obj.get("method_account")
    google_order.plus_account = google_obj.get("target_account")
    google_order.peer = google_obj.get("peer")
    google_order.item = google_obj.get("item")
    google_order.currency = google_obj.get("currency")
    google_order.money = Decimal("22.10")
    
    return google_order


def pre_repay(v: Order):
    """处理还款及外币转换逻辑"""
    if not v.note:
        return None

    keys = v.note.split(";")
    if not keys:
        return None

    accounts = _get_accounts()
    account_obj = accounts.get(keys[0])

    if not account_obj or account_obj.get("type") != "repay":
        return None

    # 外币转换逻辑
    if "usd" in v.note.lower() and len(keys) >= 3:
        usd_money = keys[1]
        cny_money = keys[2]
        
        repay_order = Order()
        repay_order.pay_time = v.pay_time
        repay_order.plus_str = f"{usd_money} USD @@ {cny_money} CNY"
        repay_order.minus_str = f"-{cny_money} CNY"
        repay_order.minus_account = v.plus_account
        repay_order.plus_account = account_obj.get("target_account")
        repay_order.peer = account_obj.get("peer")
        repay_order.item = account_obj.get("item")
        
        return repay_order

    return None


# method_account
