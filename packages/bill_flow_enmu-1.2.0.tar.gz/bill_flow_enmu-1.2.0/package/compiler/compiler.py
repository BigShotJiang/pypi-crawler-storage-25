import logging

from package.config import Config
from ir.ir import IR, Order
from package.strategy.template.strategy import TemplateStrategy
from package.parser.paser import Paser
import re
import json


class Compiler:
    def __init__(
        self,
        privider: str,
        config: Config,
        ir: IR,
        template_strategy: TemplateStrategy,
        analyser: Paser,
    ):
        self.privider = privider
        self.config = config
        self.ir = ir
        self.template_strategy = template_strategy
        self.analyser = analyser

    def compile(self):
        logging.debug("start compile")
        orders: list[Order] = []
        for o in self.ir.orders:
            ignore, res_minus, res_plus, extra_account, tags = (
                self.analyser.get_account_and_tags(o, self.config)
            )
            if ignore:
                continue
            o.minus_account = res_minus
            o.plus_account = res_plus
            o.extra_account = extra_account
            o.tags = tags
            orders.append(o)
            
        self.ir.orders = orders
        
        # 执行特定 provider 的后置逻辑 (例如处理信用卡还款分离等)
        if self.privider == "alipay":
            from provider.ali.processor import post_process
            self.ir = post_process(self.ir)

        for io in self.ir.orders:
            self.template_strategy.template_parser(io)

        # expense_data = self.distribution(self.template_strategy.expense_list)
        # income_data = self.distribution(self.template_strategy.income_list)

        # result = {
        #     "expense": {k: v[::-1] for k, v in expense_data.items()},
        #     "income": {k: v[::-1] for k, v in income_data.items()},
        # }
        # json_str = json.dumps(result, ensure_ascii=False)
        # print(json_str)

        expense_data = self.distribution(self.template_strategy.expense_list)
        income_data = self.distribution(self.template_strategy.income_list)

        result = {
            "expense": {k: sorted(v) for k, v in sorted(expense_data.items())},
            "income": {k: sorted(v) for k, v in sorted(income_data.items())},
        }

        json_str = json.dumps(result, ensure_ascii=False)
        print(json_str)

    def distribution(self, bean_bill_list: list):
        r = r"^\d{4}-(\d{2})-\d{2}"
        monthly_data = {}

        for item in bean_bill_list:
            match_obj = re.match(r, item)
            if match_obj:
                month = match_obj.group(1)
                if month not in monthly_data:
                    monthly_data[month] = []
                monthly_data[month].append(item)

        return monthly_data

        # self.write_bills(
        #     file_path="/Users/enmu/code/mandt/account/data/2026/income.bean",
        #     data=self.template_strategy.income_list,
        # )
        # self.write_bills(
        #     file_path=self.output, data=self.template_strategy.expense_list
        # )

    # def get_income_path(self) -> str:
    #     today = date.today()
    #     # month = f"{today.month:02d}"
    #     year = f"{today.year}"
    #     home = Path().home()
    #     return str(home / ".flow" / "account" / "data" / year / "income.bean")

    # def write_bills(self, file_path: str, data: list[str]):
    #     with open(file=file_path, mode="a", encoding="utf-8") as f:
    #         f.writelines(data)
