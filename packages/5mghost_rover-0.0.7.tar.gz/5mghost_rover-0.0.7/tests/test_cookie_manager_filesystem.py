from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from reddit_mcp import cookie_manager


def _write_cookies_db(path: Path, *, reddit_rows: int = 0, other_rows: int = 0) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as conn:
        conn.execute("create table cookies (host_key text)")
        for _ in range(reddit_rows):
            conn.execute("insert into cookies(host_key) values (?)", (".reddit.com",))
        for _ in range(other_rows):
            conn.execute("insert into cookies(host_key) values (?)", (".example.com",))
        conn.commit()


def test_discover_browser_profile_candidates_prefers_reddit_rows_then_freshness(
    monkeypatch,
    tmp_path: Path,
) -> None:
    browser_bin = tmp_path / "chrome"
    browser_bin.write_text("", encoding="utf-8")

    user_data_dir = tmp_path / "User Data"
    default_profile = user_data_dir / "Default"
    profile_two = user_data_dir / "Profile 2"
    default_db = default_profile / "Cookies"
    profile_two_db = profile_two / "Cookies"

    _write_cookies_db(default_db, reddit_rows=0, other_rows=3)
    _write_cookies_db(profile_two_db, reddit_rows=2)
    (user_data_dir / "Local State").write_text("{}", encoding="utf-8")

    default_db.touch()
    profile_two_db.touch()
    default_db_mtime = 1_700_000_000
    profile_two_db_mtime = 1_600_000_000
    default_db.touch()
    profile_two_db.touch()
    default_db.chmod(0o600)
    profile_two_db.chmod(0o600)
    import os

    os.utime(default_db, (default_db_mtime, default_db_mtime))
    os.utime(profile_two_db, (profile_two_db_mtime, profile_two_db_mtime))

    monkeypatch.setattr(
        cookie_manager,
        "_known_browser_installations",
        lambda: [("Google Chrome", browser_bin, user_data_dir)],
    )

    candidates = cookie_manager._discover_browser_profile_candidates()

    assert [candidate.profile_name for candidate in candidates] == ["Profile 2", "Default"]
    assert candidates[0].reddit_cookie_rows == 2
    assert candidates[1].reddit_cookie_rows == 0


def test_discover_browser_profile_candidates_supports_network_cookies_path(
    monkeypatch,
    tmp_path: Path,
) -> None:
    browser_bin = tmp_path / "chrome"
    browser_bin.write_text("", encoding="utf-8")

    user_data_dir = tmp_path / "User Data"
    profile_dir = user_data_dir / "Profile 9"
    cookies_db = profile_dir / "Network" / "Cookies"
    _write_cookies_db(cookies_db, reddit_rows=3)

    monkeypatch.setattr(
        cookie_manager,
        "_known_browser_installations",
        lambda: [("Google Chrome", browser_bin, user_data_dir)],
    )

    candidates = cookie_manager._discover_browser_profile_candidates()

    assert len(candidates) == 1
    assert candidates[0].cookies_db == cookies_db
    assert candidates[0].reddit_cookie_rows == 3


def test_copy_profile_workspace_copies_local_state_and_skips_cache_dirs(tmp_path: Path) -> None:
    user_data_dir = tmp_path / "User Data"
    profile_dir = user_data_dir / "Profile 3"
    cookies_db = profile_dir / "Cookies"
    _write_cookies_db(cookies_db, reddit_rows=1)

    (user_data_dir / "Local State").write_text('{"profile":"ok"}', encoding="utf-8")
    (profile_dir / "Preferences").write_text('{"theme":"light"}', encoding="utf-8")
    (profile_dir / "Cache").mkdir(parents=True, exist_ok=True)
    (profile_dir / "Cache" / "tmp.bin").write_text("skip-me", encoding="utf-8")

    candidate = cookie_manager.BrowserProfileCandidate(
        browser_label="Google Chrome",
        executable_path=tmp_path / "chrome",
        user_data_dir=user_data_dir,
        profile_name="Profile 3",
        profile_dir=profile_dir,
        cookies_db=cookies_db,
        reddit_cookie_rows=1,
        cookies_mtime=123.0,
    )

    workspace = tmp_path / "workspace"
    cookie_manager._copy_profile_workspace(candidate, workspace)

    assert (workspace / "Local State").read_text("utf-8") == '{"profile":"ok"}'
    assert (workspace / "Profile 3" / "Preferences").read_text("utf-8") == '{"theme":"light"}'
    assert not (workspace / "Profile 3" / "Cache").exists()


def test_copy_profile_workspace_keeps_network_cookie_db(tmp_path: Path) -> None:
    user_data_dir = tmp_path / "User Data"
    profile_dir = user_data_dir / "Profile 10"
    cookies_db = profile_dir / "Network" / "Cookies"
    _write_cookies_db(cookies_db, reddit_rows=1)

    candidate = cookie_manager.BrowserProfileCandidate(
        browser_label="Google Chrome",
        executable_path=tmp_path / "chrome",
        user_data_dir=user_data_dir,
        profile_name="Profile 10",
        profile_dir=profile_dir,
        cookies_db=cookies_db,
        reddit_cookie_rows=1,
        cookies_mtime=321.0,
    )

    workspace = tmp_path / "workspace"
    cookie_manager._copy_profile_workspace(candidate, workspace)

    assert (workspace / "Profile 10" / "Network" / "Cookies").exists()


def test_copy_profile_workspace_windows_raises_clear_error_for_locked_cookie_db(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    user_data_dir = tmp_path / "User Data"
    profile_dir = user_data_dir / "Profile 11"
    cookies_db = profile_dir / "Network" / "Cookies"
    _write_cookies_db(cookies_db, reddit_rows=1)
    (user_data_dir / "Local State").write_text("{}", encoding="utf-8")

    candidate = cookie_manager.BrowserProfileCandidate(
        browser_label="Google Chrome",
        executable_path=tmp_path / "chrome",
        user_data_dir=user_data_dir,
        profile_name="Profile 11",
        profile_dir=profile_dir,
        cookies_db=cookies_db,
        reddit_cookie_rows=1,
        cookies_mtime=654.0,
    )

    real_copy2 = cookie_manager.shutil.copy2

    def fake_copy2(src, dst, *args, **kwargs):  # type: ignore[no-untyped-def]
        if Path(src) == cookies_db:
            raise PermissionError("locked")
        return real_copy2(src, dst, *args, **kwargs)

    monkeypatch.setattr(cookie_manager.shutil, "copy2", fake_copy2)
    monkeypatch.setattr(cookie_manager.sys, "platform", "win32")

    with pytest.raises(RuntimeError, match="Task Manager"):
        cookie_manager._copy_profile_workspace(candidate, tmp_path / "workspace")


def test_spawn_browser_from_workspace_uses_isolated_profile_flags(
    monkeypatch,
    tmp_path: Path,
) -> None:
    launched: dict[str, object] = {}

    class FakeProcess:
        def poll(self) -> int | None:
            return None

    def fake_popen(args, stdout=None, stderr=None):  # type: ignore[no-untyped-def]
        launched["args"] = args
        launched["stdout"] = stdout
        launched["stderr"] = stderr
        return FakeProcess()

    browser_bin = tmp_path / "chrome"
    browser_bin.write_text("", encoding="utf-8")
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    profile_dir = tmp_path / "User Data" / "Profile 7"
    cookies_db = profile_dir / "Cookies"
    _write_cookies_db(cookies_db, reddit_rows=1)

    candidate = cookie_manager.BrowserProfileCandidate(
        browser_label="Google Chrome",
        executable_path=browser_bin,
        user_data_dir=tmp_path / "User Data",
        profile_name="Profile 7",
        profile_dir=profile_dir,
        cookies_db=cookies_db,
        reddit_cookie_rows=1,
        cookies_mtime=456.0,
    )

    monkeypatch.setattr(cookie_manager, "_allocate_debug_port", lambda: 45678)
    monkeypatch.setattr(cookie_manager.subprocess, "Popen", fake_popen)

    process, port = cookie_manager._spawn_browser_from_workspace(candidate, workspace)

    assert isinstance(process, FakeProcess)
    assert port == 45678
    args = launched["args"]
    assert args[0] == str(browser_bin)
    assert f"--user-data-dir={workspace}" in args
    assert "--profile-directory=Profile 7" in args
    assert "--remote-debugging-port=45678" in args
    assert "--disable-sync" in args
    assert "--disable-background-networking" in args
    assert "--disable-features=AccountReconcilor,IdentityManager" in args
    assert "--headless=new" in args
    assert args[-1] == "about:blank"
