import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.probability import FreqDist
from nltk.corpus import stopwords
import matplotlib.pyplot as plt

nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('stopwords')



'''
remix code 

'''


































































text = """a for apple, c for cooked, d for damn, z for zaza, x for xmas"""

print("Text:", text)
tokenized_word = word_tokenize(text)
print("Words:", tokenized_word)

fdist = FreqDist(tokenized_word)
print("Frequency Distribution:", fdist)
print("Most Common 4:", fdist.most_common(4))





























































fdist.plot(30, cumulative=False)
plt.show()

stop_words = set(stopwords.words('english'))
print("Stopwords:", stop_words)





































filtered_sent = []
for w in tokenized_word:
    if w.lower() not in stop_words:
        filtered_sent.append(w)

print("Tokenized Words:", tokenized_word)
print("Filtered Words:", filtered_sent)
