#basic
import hashlib

def generate_hash(data):
    return hashlib.sha256(data.encode()).hexdigest()
def verify_hash(data, original_hash):
    return generate_hash(data) == original_hash

data = "This is a secret message."
hash_value = generate_hash(data)
print(f"Hash: {hash_value}")
print("Verification (correct data):", verify_hash(data, hash_value))
print("Verification (tampered data):", verify_hash("This is a tampered message.", hash_value))


#advanced
import hashlib
import hmac





















def generate_hash(data):
    return hashlib.sha256(data.encode()).hexdigest()
def verify_hash(data, original_hash):
    return hmac.compare_digest(generate_hash(data), original_hash)
def check_data_integrity(data, original_hash):
    print("Data is intact and verified." if verify_hash(data, original_hash) else "Warning: Data has been tampered with!")





















original_data = "This is a secret message."
hash_value = generate_hash(original_data)
print(f"Original Hash: {hash_value}\n")





















print("Checking original data:")
check_data_integrity(original_data, hash_value)





















print("\nChecking tampered data:")
check_data_integrity("This is a hacked message.", hash_value)






















print("\nChecking data with added space:")
check_data_integrity("This is a secret message. ", hash_value)

























print("\nChecking data with missing character:")
check_data_integrity("This is a seet message.", hash_value)
