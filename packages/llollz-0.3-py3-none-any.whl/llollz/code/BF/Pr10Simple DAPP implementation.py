#SINGLE DAPP REMIX CODE
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract SimpleStorage {
    uint storedData;

    function set(uint x) public {
        storedData = x;
    }

    function get() public view returns (uint) {
        return storedData;
    }
}
























#INDEX.HTML FOR DAPP
<!DOCTYPE html>
<html>
    <head>
        <title>SimpleStorage DApp</title>
    </head>
    <body>
        <h2>SimpleStorage DApp</h2>
        <input type="number" id="inputValue" placeholder="Enter a number" />
        <button onclick="setValue()">Set Value</button>
        <button onclick="getValue()">Get Stored Value</button>
        <p>Stored Value: <span id="storedValue">-</span></p>
        <script src="https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js"></script>
        <script src="app.js"></script>
    </body>
</html>























#APP.JS FOR DAPP
const contractABI = [
    "function set(uint256 x) public",
    "function get() public view returns (uint256)"
];
const contractAddress = "0x769b87a3Db1c5A99504Cd5b71BFE8eE456bbf75F";

let contract;

async function init() {
    if (!window.ethereum) {
        alert("MetaMask is not installed!");
        return;
    }
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    contract = new ethers.Contract(contractAddress, contractABI, provider.getSigner());
}

async function setValue() {
    const value = document.getElementById('inputValue').value;
    if (!value) { alert("Enter a number first!"); return; }
    try {
        await (await contract.set(value)).wait();
        alert("Value set successfully!");
    } catch (err) {
        alert("Transaction failed!");
    }
}

async function getValue() {
    try {
        document.getElementById('storedValue').innerText = (await contract.get()).toString();
    } catch (err) {
        alert("Failed to get value!");
    }
}

window.onload = init;




















