#MULTIPLE BLOCK GENERTION
import hashlib, json, time

DIFFICULTY = 4









































def hash(block):
    return hashlib.sha256(json.dumps({k: v for k, v in block.items() if k != 'hash'}, sort_keys=True).encode()).hexdigest()

def mine(block):
    block['nonce'] = 0
    while not (h := hash(block)).startswith('0' * DIFFICULTY):
        block['nonce'] += 1
    return h









































def make_block(index, txns, prev_hash):
    block = {'index': index, 'timestamp': time.time(), 'transactions': txns, 'previous_hash': prev_hash, 'nonce': 0}
    block['hash'] = mine(block)
    return block









































def is_valid(chain):
    return all(
        chain[i]['index'] == chain[i-1]['index'] + 1 and
        chain[i]['previous_hash'] == chain[i-1]['hash'] and
        hash(chain[i]) == chain[i]['hash']
        for i in range(1, len(chain))
    )

def generate(num_blocks, tx_per_block=2):
    chain = [make_block(0, [], '0' * 64)]
    for i in range(1, num_blocks):
        txns = [{'sender': f'User{i}', 'recipient': f'User{i+1}', 'amount': i*10+j} for j in range(tx_per_block)]
        chain.append(make_block(i, txns, chain[-1]['hash']))
    return chain









































if __name__ == "__main__":
    chain = generate(3, tx_per_block=3)
    for block in chain:
        print(json.dumps(block, indent=4))
        print('-' * 60)
    print(f"\nIs the blockchain valid? {is_valid(chain)}")








































