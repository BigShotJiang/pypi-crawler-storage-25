#SINGLE BLOCK GENERATION
import hashlib
import time
import json









































class Block:
    def __init__(self, index, data, previous_hash):
        self.index = index
        self.timestamp = time.time()
        self.data = data
        self.previous_hash = previous_hash
        self.nonce = 0
        self.hash = self.compute_hash()

    def compute_hash(self):
        block_string = json.dumps({
            'index': self.index,
            'timestamp': self.timestamp,
            'data': self.data,
            'previous_hash': self.previous_hash,
            'nonce': self.nonce
        }, sort_keys=True)
        return hashlib.sha256(block_string.encode()).hexdigest()

genesis_block = Block(0, "Genesis Block", "0")
print("Block index:", genesis_block.index)
print("Block timestamp:", genesis_block.timestamp)
print("Block data:", genesis_block.data)
print("Previous hash:", genesis_block.previous_hash)
print("Current hash:", genesis_block.hash)





















#SINGLE BLOCK GENERATION WITH USER INPUT
import hashlib
from datetime import datetime
import json

def create_blockchain_transaction_block():
    print("Blockchain Transaction Block Creation")
    
    sender = input("Enter Sender Address (Public Key): ")
    recipient = input("Enter Recipient Address (Public Key): ")
    amount_str = input("Enter Transaction Amount: ")
    
    try:
        amount = float(amount_str)
    except ValueError:
        print("\n[ERROR] Transaction Amount must be a valid number.")
        return None
        
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    transaction_block = {
        "timestamp": timestamp,
        "sender": sender,
        "recipient": recipient,
        "amount": amount,
        "previous_hash": "0" * 64,
        "nonce": 0
    }
    
    block_string = json.dumps(transaction_block, sort_keys=True).encode()
    transaction_block["current_hash"] = hashlib.sha256(block_string).hexdigest()
    
    print("\nSecure Transaction Block Created")
    for key, value in transaction_block.items():
        print(f" {key}: {value}")
        
    return transaction_block

new_block = create_blockchain_transaction_block()











































#MULTIPLE TRANSACTION IN SINGLE BLOCK
import hashlib
import datetime
import json

class Block:
    def __init__(self, transactions, previous_hash="0"*64):
        self.index = 0
        self.timestamp = str(datetime.datetime.now())
        self.transactions = transactions
        self.previous_hash = previous_hash
        self.nonce = 0
        self.hash = self.compute_hash()

    def compute_hash(self):
        block_string = json.dumps({
            'index': self.index,
            'timestamp': self.timestamp,
            'transactions': self.transactions,
            'previous_hash': self.previous_hash,
            'nonce': self.nonce
        }, sort_keys=True)
        return hashlib.sha256(block_string.encode()).hexdigest()

    def __str__(self):
        return (f"Block index: {self.index}\n"
                f"Timestamp: {self.timestamp}\n"
                f"Transactions:\n" + "\n".join(f" - {tx}" for tx in self.transactions) + "\n"
                f"Previous hash: {self.previous_hash}\n"
                f"Hash: {self.hash}\n")

transactions = [
    "Alice pays Bob 5 BTC",
    "Bob pays Charlie 2 BTC",
    "Charlie pays Dave 1 BTC"
]

block = Block(transactions)
print(block)








































