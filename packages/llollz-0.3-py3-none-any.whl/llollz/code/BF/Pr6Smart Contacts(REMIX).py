'''


prac6
#SINGLE INHERITANCE
#MULTILEVEL INHERITANCE
#HIERARCHICAL INHERITANCE
#MULTIPLE INHERITANCE
#LIBRARIES
#CONTRACT USING LIBRARIES
#MAPPING
#MODIFIER WITHOUT ARGUMENTS(ADMIN ONLY)
#MODIFIER WITH ARGUMENTS(EXPERIENCE CHECK)
#MULTIPLE MODIFIERS(ADMIN+EXPERIENCE CHECK)
#STRUCTURE & ARRAYS
#USING REQUIRE STATEMENT
#USING ASSERT STATEMENT
#USING REVERT STATEMENT
























#SINGLE INHERITANCE
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract Contract_A {
    uint256 value;

    constructor(uint256 n) public {
        value = n;
    }

    function incrementValue(uint256 x) public {
        value += x;
    }
}

contract Contract_B is Contract_A(22) {
    function getValue() public view returns (uint256) {
        return value;
    }
}







#MULTILEVEL INHERITANCE
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract Contract_A {
    uint256 value;

    constructor(uint256 n) public {
        value = n;
    }

    function incrementValue(uint256 x) public {
        value += x;
    }
}

contract Contract_B is Contract_A(22) {
    function decrementValue(uint256 x) public {
        value -= x;
    }
}

contract Contract_C is Contract_B {
    function getValue() public view returns (uint256) {
        return value;
    }
}


#HIERARCHICAL INHERITANCE
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract Contract_A {
    uint256 value;

    constructor(uint256 n) public {
        value = n;
    }

    function getValue() public view returns (uint256) {
        return value;
    }
}

contract Contract_B is Contract_A(22) {
    function incrementValue(uint256 x) public {
        value += x;
    }
}

contract Contract_C is Contract_A(25) {
    function decrementValue(uint256 x) public {
        value -= x;
    }
}


#MULTIPLE INHERITANCE
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract Contract_A {
    uint public valueA;
    function setA(uint n) public {
        valueA = n;
    }
}

contract Contract_B {
    uint public valueB;
    function setB(uint n) public {
        valueB = n;
    }
}

contract Contract_C is Contract_A, Contract_B {
    function getSum() public view returns (uint) {
        return valueA + valueB;
    }
}


#LIBRARIES
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

library lib {
    function increment(uint val) public pure returns (uint) {
        return val + 1;
    }
    function decrement(uint val) public pure returns (uint) {
        return val - 1;
    }
    function incrementByValue(uint val, uint x) public pure returns (uint) {
        return val + x;
    }
    function decrementByValue(uint val, uint x) public pure returns (uint) {
        return val - x;
    }
}













#CONTRACT USING LIBRARIES
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

library lib {
    function increment(uint val) public pure returns (uint) {
        return val + 1;
    }
    function decrement(uint val) public pure returns (uint) {
        return val - 1;
    }
    function incrementByValue(uint val, uint x) public pure returns (uint) {
        return val + x;
    }
    function decrementByValue(uint val, uint x) public pure returns (uint) {
        return val - x;
    }
}











contract useLibrary {
    using lib for uint;

    function testIncrement(uint userVal) public pure returns (uint) {
        return lib.increment(userVal);
    }

    function testDecrement(uint userVal) public pure returns (uint) {
        return lib.decrement(userVal);
    }

    function testIncrementByValue(uint userVal, uint x) public pure returns (uint) {
        return lib.incrementByValue(userVal, x);
    }

    function testDecrementByValue(uint userVal, uint x) public pure returns (uint) {
        return lib.decrementByValue(userVal, x);
    }
}


















#MAPPING
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract mappingExample {
    mapping(int => string) details;

    function addDetails(int id, string memory name) public {
        details[id] = name;
    }

    function updateDetails(int id, string memory name) public {
        details[id] = name;
    }

    function getDetails(int id) public view returns (string memory) {
        return details[id];
    }
}


















#MODIFIER WITHOUT ARGUMENTS(ADMIN ONLY)
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract modifierWithoutArg { 
    address admin; 
    struct employee { 
        uint emp_id; 
        string emp_name; 
        uint age; 
    } 
    constructor() public { 
        admin = msg.sender; 
    } 
    modifier isAdmin { 
        require(admin == msg.sender, "Not authorized"); 
        _; 
    } 
    employee e; 
    function enterDetails(uint _empid, string memory _empname, uint _empage) public isAdmin { 
        e.emp_id = _empid; 
        e.emp_name = _empname; 
        e.age = _empage; 
    }
}













#MODIFIER WITH ARGUMENTS(EXPERIENCE CHECK)
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract modifierWithArg {
    struct employee {
        uint emp_id;
        string emp_name;
        uint age;
    }
    
    employee e;

    modifier isExperienced(uint exp) {
        if (exp >= 5) {
            _;
        } else {
            revert("Must have a minimum of 5 years of experience");
        }
    }

    function enterDetails(uint _empid, string memory _empname, uint _empage) public isExperienced(2) {
        e.emp_id = _empid;
        e.emp_name = _empname;
        e.age = _empage;
    }
}













#MULTIPLE MODIFIERS(ADMIN+EXPERIENCE CHECK)
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract multipleModifier {
    address admin;
    
    struct employee {
        uint emp_id;
        string emp_name;
        uint age;
    }
    
    employee e;

    constructor() public {
        admin = msg.sender;
    }

    modifier isAdmin {
        require(admin == msg.sender, "Not authorized");
        _;
    }

    modifier isExperienced(uint exp) {
        if (exp >= 5) {
            _;
        } else {
            revert("Must have a minimum of 5 years of experience");
        }
    }

    function enterDetails(uint _empid, string memory _empname, uint _empage) public isAdmin isExperienced(2) {
        e.emp_id = _empid;
        e.emp_name = _empname;
        e.age = _empage;
    }
}













#STRUCTURE & ARRAYS
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract StructAndArray {
    struct Employee {
        uint emp_id;
        string emp_name;
        uint age;
    }

    uint[] public dynamicArray; 
    
    uint[3] public staticArray = [1, 2, 3];

    Employee public emp;

    function setEmployee(uint _id, string memory _name, uint _age) public {
        emp = Employee(_id, _name, _age);
    }
    
    function addToDynamicArray(uint val) public {
        dynamicArray.push(val);
    }
    
    function getStaticArrayLength() public view returns (uint) {
        return staticArray.length;
    }
}













#USING REQUIRE STATEMENT
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract requireStatement {
    
    function checkInput(uint _input) public pure returns (string memory) {
        require(_input >= 0, "invalid uint8");
        require(_input <= 255, "invalid uint8");
        return "Input is Uint8";
    }

    function checkOdd(uint _input) public pure returns (bool) {
        require(_input % 2 != 0, "Input is not odd");
        return true;
    }
}













#USING ASSERT STATEMENT
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract assertStatement {
    bool result;

    function checkOverflow(uint _num1, uint _num2) public {
        uint sum = _num1 + _num2;
        assert(sum <= 255); 
        result = true;
    }

    function getResult() public view returns (string memory) {
        if (result == true) {
            return "No Overflow";
        } else {
            return "Overflow exists";
        }
    }
}




























#USING REVERT STATEMENT
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract revertStatement {
    
    function checkOverflow(uint _num1, uint _num2) public pure returns (string memory, uint) {
        uint sum = _num1 + _num2;
        
        if (sum > 255) {
            revert("Overflow Exist");
        } else {
            return ("No Overflow", sum);
        }
    }
}

'''