#AES
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend





















def aes_encrypt(key, plaintext):
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(plaintext.encode()) + padder.finalize()
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()
    return iv + ciphertext





















def aes_decrypt(key, ciphertext):
    iv = ciphertext[:16]
    actual_ciphertext = ciphertext[16:]
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded_plaintext = decryptor.update(actual_ciphertext) + decryptor.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()
    return plaintext.decode()

key = os.urandom(32)
message = "Hello AES!"
encrypted = aes_encrypt(key, message)
print("Encrypted AES:", encrypted)
print("Decrypted AES:", aes_decrypt(key, encrypted))






















#DSA
from cryptography.hazmat.primitives.asymmetric import dsa
from cryptography.hazmat.primitives import hashes

private_key = dsa.generate_private_key(key_size=2048)

def dsa_sign(private_key, message):
    return private_key.sign(message.encode(), hashes.SHA256())

def dsa_verify(public_key, message, signature):
    try:
        public_key.verify(signature, message.encode(), hashes.SHA256())
        return True
    except:
        return False

message = "Hello DSA!"
signature = dsa_sign(private_key, message)
public_key = private_key.public_key()

print(f"Message: {message}")
print(f"Signature valid? {dsa_verify(public_key, message, signature)}")






















#BLOWFISH
from Crypto.Cipher import Blowfish
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad

def blowfish_encrypt(key, plaintext):
    cipher = Blowfish.new(key, Blowfish.MODE_CBC)
    iv = cipher.iv
    padded_data = pad(plaintext.encode(), Blowfish.block_size)
    ciphertext = cipher.encrypt(padded_data)
    return iv + ciphertext

def blowfish_decrypt(key, ciphertext):
    iv = ciphertext[:8]
    actual_ciphertext = ciphertext[8:]
    cipher = Blowfish.new(key, Blowfish.MODE_CBC, iv)
    padded_plaintext = cipher.decrypt(actual_ciphertext)
    plaintext = unpad(padded_plaintext, Blowfish.block_size)
    return plaintext.decode()

key = get_random_bytes(16)
msg = "Hello Blowfish!"
encrypted = blowfish_encrypt(key, msg)

print("Encrypted:", encrypted)
decrypted = blowfish_decrypt(key, encrypted)
print("Decrypted:", decrypted)





















#RSA
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

# Generate RSA keys
private_key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=2048
)
public_key = private_key.public_key()

def rsa_encrypt(public_key, message):
    ciphertext = public_key.encrypt(
        message.encode(),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return ciphertext

def rsa_decrypt(private_key, ciphertext):
    plaintext = private_key.decrypt(
        ciphertext,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return plaintext.decode()









































# Usage
msg = "Hello RSA!"
encrypted = rsa_encrypt(public_key, msg)
print("Encrypted:", encrypted)
decrypted = rsa_decrypt(private_key, encrypted)
print("Decrypted:", decrypted)
