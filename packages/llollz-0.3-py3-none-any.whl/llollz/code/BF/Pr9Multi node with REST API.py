import datetime, hashlib, json
from flask import Flask, jsonify, request
import requests
from urllib.parse import urlparse





















class Blockchain:
    def __init__(self):
        self.chain = []
        self.transactions = []
        self.nodes = set()
        self.create_block(proof=1, previous_hash='0')

    def create_block(self, proof, previous_hash):
        block = {
            'index': len(self.chain) + 1,
            'timestamp': str(datetime.datetime.now()),
            'proof': proof,
            'previous_hash': previous_hash,
            'transaction': self.transactions
        }
        self.transactions = []
        self.chain.append(block)
        return block

    def get_previous_block(self):
        return self.chain[-1]

    def proof_of_work(self, previous_proof):
        new_proof = 1
        while hashlib.sha256(str(new_proof**2 - previous_proof**2).encode()).hexdigest()[:5] != '00000':
            new_proof += 1
        return new_proof

    def hash(self, block):
        return hashlib.sha256(json.dumps(block, sort_keys=True).encode()).hexdigest()

    def is_chain_valid(self, chain):
        previous_block = chain[0]
        for block in chain[1:]:
            if block['previous_hash'] != self.hash(previous_block):
                return False
            hash_value = hashlib.sha256(str(block['proof']**2 - previous_block['proof']**2).encode()).hexdigest()
            if hash_value[:5] != '00000':
                return False
            previous_block = block
        return True

    def add_transaction(self, sender, receiver, amount):
        self.transactions.append({'sender': sender, 'receiver': receiver, 'amount': amount})
        return self.get_previous_block()['index'] + 1

    def add_node(self, address):
        self.nodes.add(urlparse(address).netloc)

    def replace_chain(self):
        max_length = len(self.chain)
        longest_chain = None
        for node in self.nodes:
            response = requests.get(f'http://{node}/get_chain')
            if response.status_code == 200:
                data = response.json()
                if data['length'] > max_length and self.is_chain_valid(data['chain']):
                    max_length = data['length']
                    longest_chain = data['chain']
        if longest_chain:
            self.chain = longest_chain
            return True
        return False









































app = Flask(__name__)
blockchain = Blockchain()

@app.route('/mine_block')
def mine_block():
    prev = blockchain.get_previous_block()
    proof = blockchain.proof_of_work(prev['proof'])
    block = blockchain.create_block(proof, blockchain.hash(prev))
    return jsonify({'message': 'block is mined', 'index': block['index'],
                    'timestamp': block['timestamp'], 'proof': block['proof'],
                    'previous_hash': block['previous_hash']}), 200

@app.route('/get_chain')
def get_chain():
    return jsonify({'chain': blockchain.chain, 'length': len(blockchain.chain)}), 200

@app.route('/is_valid')
def is_valid():
    msg = 'Your chain is validated' if blockchain.is_chain_valid(blockchain.chain) else 'Your chain is not valid'
    return jsonify({'message': msg}), 200

@app.route('/add_transaction', methods=['POST'])
def add_transaction():
    data = request.get_json()
    if not all(k in data for k in ['sender', 'receiver', 'amount']):
        return 'Some elements are missing', 400
    index = blockchain.add_transaction(data['sender'], data['receiver'], data['amount'])
    return jsonify({'Message': f'The transaction is added to block {index}'}), 201

@app.route('/connect_nodes', methods=['POST'])
def connect_nodes():
    nodes = request.get_json().get('nodes')
    if not nodes:
        return 'No Nodes', 400
    for node in nodes:
        blockchain.add_node(node)
    return jsonify({'message': 'all nodes are now connected', 'Total nodes': list(blockchain.nodes)}), 201

@app.route('/replace_chain')
def replace_chain():
    replaced = blockchain.replace_chain()
    return jsonify({'message': 'chain replaced' if replaced else 'chain not replaced', 'new_chain': blockchain.chain}), 201

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
























#step1 create 2 instances of block , port 5001 & 5002
#in postman ->
# 1- Request URL - http://127.0.0.1:5001/connect_nodes [connect 5001 to 5002]
'''
{
   "nodes":["http://127.0.0.1:5002"]     
}

'''

# 2- Request URL - http://127.0.0.1:5002/connect_nodes [connect 5002 to 5001]
'''
{
   "nodes":["http://127.0.0.1:5001"]     
}

'''
# 3- http://127.0.0.1:5001/get_chain 

# 4- http://127.0.0.1:5001/add_transaction 
'''
{
    "sender":"Alice",
    "receiver":"Bob",
    "amount": "1000"

}
'''

# 5- http://127.0.0.1:5001/mine_block

# 6- http://127.0.0.1:5001/get_chain [port 5001]

# 6.1- http://127.0.0.1:5002/get_chain [port 5002]
'''
{
   "nodes":["http://127.0.0.1:5002"]     
}

'''
# 7- http://127.0.0.1:5002/replace_chain

# 8- http://127.0.0.1:5002/add_transaction  

# 9- http://127.0.0.1:5002/mine_block

# 10-http://127.0.0.1:5002/get_chain 

# 10.1- http://127.0.0.1:5002/get_chain [port 5001]

# 11- http://127.0.0.1:5001/replace_chain