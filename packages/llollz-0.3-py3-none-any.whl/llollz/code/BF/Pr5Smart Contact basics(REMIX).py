'''

prac5
#GET-SET
#CALCULATOR
#FACTORIAL
#PRIME NUMBER
#EVEN ODD
#WEEKDAYS
#STRUCTURE
#ARRAYS



























#GET-SET
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract Message {
    string message;

    constructor(string memory newMessage) public {
        message = newMessage;
    }

    function setMessage(string memory newMessage) public {
        message = newMessage;
    }

    function getMessage() public view returns (string memory) {
        return message;
    }
}

















#CALCULATOR
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract Calculator {
    uint public na;
    uint public nb;

    constructor(uint _na, uint _nb) public {
        na = _na;
        nb = _nb;
    }

    function add() public view returns (uint) {
        return na + nb;
    }

    function sub() public view returns (uint) {
        require(na >= nb, "Subtraction results in negative value");
        return na - nb;
    }

    function mul() public view returns (uint) {
        return na * nb;
    }

    function div() public view returns (uint) {
        require(nb != 0, "Division by zero is not allowed");
        return na / nb;
    }

    function getAllResults() public view returns (uint, uint, uint, uint) {
        uint sum = na + nb;
        uint diff = na >= nb ? na - nb : 0;
        uint prod = na * nb;
        uint quotient = nb != 0 ? na / nb : 0;
        return (sum, diff, prod, quotient);
    }
}

















#FACTORIAL
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract Factorial {
    uint public a;

    constructor(uint _a) public {
        a = _a;
    }

    function fact() public view returns (uint256) {
        uint256 r = 1;
        for (uint256 i = 1; i <= a; i++) {
            r *= i;
        }
        return r;
    }
}







#PRIME NUMBER
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract PrimeCheck {
    uint public a;

    constructor(uint _a) public {
        a = _a;
    }

    function isPrime() public view returns (bool) {
        if (a <= 1) {
            return false;
        }
        for (uint256 i = 2; i * i <= a; i++) {
            if (a % i == 0) {
                return false;
            }
        }
        return true;
    }
}






















#EVEN ODD
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract EvenOddCheck {
    uint public a;

    constructor(uint _a) public {
        a = _a;
    }

    function isEven() public view returns (string memory) {
        if (a % 2 == 0) {
            return "Number is even";
        } else {
            return "Number is odd";
        }
    }
}

















#WEEKDAYS
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract Weekday {
    function getWeekday(uint8 day) public pure returns (string memory) {
        if (day == 1) {
            return "Monday";
        } else if (day == 2) {
            return "Tuesday";
        } else if (day == 3) {
            return "Wednesday";
        } else if (day == 4) {
            return "Thursday";
        } else if (day == 5) {
            return "Friday";
        } else if (day == 6) {
            return "Saturday";
        } else if (day == 7) {
            return "Sunday";
        } else {
            return "Invalid input";
        }
    }
}


#STRUCTURE
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract SimpleStruct {
    struct Person {
        string name;
        uint age;
    }

    Person public person;

    function setPerson(string memory _name, uint _age) public {
        person.name = _name;
        person.age = _age;
    }

    function getPerson() public view returns (string memory, uint) {
        return (person.name, person.age);
    }
}






















#ARRAYS
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.17;

contract SimpleArray {
    uint[] public numbers;

    function addNumber(uint _number) public {
        numbers.push(_number);
    }

    function getNumbers() public view returns (uint[] memory) {
        return numbers;
    }

    function getNumberCount() public view returns (uint) {
        return numbers.length;
    }
}


'''