'''
library(sna)
library(igraph)

links2 <- read.csv(file.choose(), header=TRUE, row.names=1)
net_matrix <- as.matrix(links2)












































eq <- equiv.clust(net_matrix)
plot(eq, main="Cluster Dendrogram of Structural Equivalence")

g.se <- sedist(net_matrix)

































plot(cmdscale(as.dist(g.se)), 
     main="MDS Plot: Vertex Positions", 
     xlab="Dimension 1", ylab="Dimension 2",
     pch=19, col="blue")
text(cmdscale(as.dist(g.se)), labels=rownames(net_matrix), pos=3, cex=0.8)

b <- blockmodel(net_matrix, eq, h=10) 
plot(b)
print(b)
'''
