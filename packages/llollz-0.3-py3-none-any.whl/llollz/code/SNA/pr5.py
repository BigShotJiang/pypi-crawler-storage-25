'''
library(igraph)

g <- erdos.renyi.game(10, 0.3, directed = TRUE)
g1 <- sample_gnp(10, 0.3, directed = TRUE)

den <- edge_density(g)
deg <- degree(g)
rec <- reciprocity(g)
tra <- transitivity(g, type = "global")
































































cat("Edge density:", den, "\n")
cat("Degrees:\n")
print(deg)
cat("Reciprocity:", rec, "\n")
cat("Global transitivity:", tra, "\n")

plot(g)


























































#----------------CLUSTERING-----------------------
library(igraph)

#Krackhardt Kite Graph
kite <- make_graph("Krackhardt_Kite")
triangles_count <- count_triangles(kite)
plot(kite, vertex.label = triangles_count, main = "Krackhardt Kite Graph")

#Local clustering
local_trans <- transitivity(kite, type = "local")
cat("Local transitivity (clustering):\n")
print(local_trans)

#Manual clustering
manual_clust <- count_triangles(kite) / (degree(kite) * (degree(kite) - 1) / 2)
cat("Manual clustering coefficient:\n")
print(manual_clust)

g1 <- sample_pa(50, power = 1, directed = FALSE)
g2 <- sample_smallworld(dim = 1, size = 100, nei = 5, p = 0.05)
g <- igraph::union(g1, g2)
g <- simplify(g)

# Edge betweenness clustering
ebc <- cluster_edge_betweenness(g, directed = FALSE)
membership_vec <- membership(ebc)
cat("Community membership:\n")
print(membership_vec)

mod <- modularity(g, membership_vec)
cat("Modularity of detected communities:", mod, "\n")

plot(ebc, g, main = "Edge Betweenness Community Detection")




















































#---------------------------CENTRALIZATION-------------------------------
library(igraph)

optimal_edges <- which.max(mods) - 1
g2 <- delete_edges(g, ebc$removed.edges[seq_len(optimal_edges)])
V(g2)$color <- components(g2)$membership + 1
g2layout <- layout_with_fr(g2)

plot(g, vertex.label = NA, main = "Original Graph")
plot(g2, vertex.label = NA, layout = g2layout, main = "Optimized Graph")
plot(kite, vertex.label = NA, main = "Krackhardt Kite")


#Adjacency edge list of the Krackhardt Kite
edge_list <- as_edgelist(kite, names = TRUE)
print(edge_list)


# Fast-greedy community detection on g2
g2_undirected <- as.undirected(g2, mode = "collapse")
fc <- cluster_fast_greedy(g2_undirected)
max_step <- min(which.max(fc$modularity), length(fc$steps))
com <- cut_at(fc, steps = max_step)

V(g2_undirected)$color <- com + 1
g2layout <- layout_with_fr(g2_undirected)

plot(g2_undirected, vertex.label = NA, layout = g2layout,
     main = "Fast-Greedy Communities")


# Degree centrality
centr_deg <- centr_degree(g, mode = "in", normalized = TRUE)

# Closeness centrality
centr_clo <- closeness(g, mode = "all", weights = NA, normalized = TRUE)

# Betweenness centrality
betw <- betweenness(g, directed = TRUE, weights = NA)

# Edge betweenness
edge_betw <- edge_betweenness(g, directed = TRUE, weights = NA)

# Eigenvector centrality (remove 'normalized' argument)
eig <- eigen_centrality(g, directed = TR




































cat("Degree centralization:\n"); print(centr_deg$centralization)
cat("Closeness centrality:\n"); print(centr_clo)
cat("Betweenness centrality:\n"); print(betw)
cat("Edge betweenness:\n"); print(edge_betw)
cat("Eigenvector centrality:\n"); print(eig$vector)
'''
