'''
library(igraph)
matt_data <- read.table(text=
"node  R  S  T  U
R  7  5  0  0  
S  7  0  0  2  
T  0  6  0  0  
U  4  0  1  0", header=TRUE)











































matt <- as.matrix(matt_data)
nms <- matt[,1]
matt <- matt[, -1]
matt <- apply(matt, 2, as.numeric) 
colnames(matt) <- rownames(matt) <- nms
matt[is.na(matt)] <- 0







































g <- graph_from_adjacency_matrix(matt, weighted=TRUE, mode="directed")

plot(g, edge.label=E(g)$weight)

s.paths <- distances(g, algorithm = "dijkstra")
print("All shortest paths:")
print(s.paths)

path_R_to_S <- distances(g, v="R", to="S")
print("Shortest path from R to S:")
print(path_R_to_S)
'''
