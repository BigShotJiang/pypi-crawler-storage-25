'''
library(igraph)
nodes <- read.csv(file.choose(), header=TRUE, as.is=TRUE)
links <- read.csv(file.choose(), header=TRUE, as.is=TRUE)
net <- graph_from_data_frame(d=links, vertices=nodes, directed=TRUE)
adj_matrix_sparse <- as_adjacency_matrix(net) 
m <- as.matrix(as_adjacency_matrix(net))
print(m)
plot(net)
'''
