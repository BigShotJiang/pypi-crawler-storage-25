#Density---Degree---Reciprocity---Transitivity
'''
library(igraph)

g <- erdos.renyi.game(10, 0.3, directed = TRUE)
g1 <- sample_gnp(10, 0.3, directed = TRUE)

den <- edge_density(g)
deg <- degree(g)
rec <- reciprocity(g)
tra <- transitivity(g, type = "global")































































cat("Edge density:", den, "\n")
cat("Degrees:\n")
print(deg)
cat("Reciprocity:", rec, "\n")
cat("Global transitivity:", tra, "\n")

plot(g)
'''
