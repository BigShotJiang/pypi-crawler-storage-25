'''
library(igraph)
edge_list_data <- data.frame(
  Person1 = c("Alice", "Alice", "Bob", "Charlie", "David", "Eve"),
  Person2 = c("Bob", "Charlie", "David", "David", "Alice", "Alice")
)



















































cat("\n--- NETWORK AS AN EDGE LIST ---\n")
print(edge_list_data)

g_edge <- graph_from_data_frame(edge_list_data, directed = FALSE)

matrix_data <- matrix(c(
  0, 1, 1, 0,
  1, 0, 0, 1,
  1, 0, 0, 1,
  0, 1, 1, 0
), nrow = 4, byrow = TRUE)

rownames(matrix_data) <- colnames(matrix_data) <- c("CityA", "CityB", "CityC", "CityD")

























































cat("\n--- NETWORK AS A MATRIX ---\n")
print(matrix_data)

g_matrix <- graph_from_adjacency_matrix(matrix_data, mode = "undirected")

g_sociogram <- make_star(n = 6, mode = "undirected", center = 1)
V(g_sociogram)$name <- c("Manager", "Emp1", "Emp2", "Emp3", "Emp4", "Emp5")

cat("\n--- 3. NETWORK AS A SOCIOGRAM ---\n")
cat("A sociogram is best understood visually. Plotting now...\n")

par(mfrow=c(1,3)) 


















































plot(g_edge, main="1. Built from Edge List\n(Friendships)", 
     vertex.color="lightblue", vertex.size=30, vertex.label.cex=1.2)

plot(g_matrix, main="2. Built from Matrix\n(Transportation)", 
     vertex.color="lightgreen", vertex.size=40, vertex.label.cex=1.2)

plot(g_sociogram, main="3. The Sociogram Plot\n(Corporate)", 
     vertex.color="salmon", vertex.size=35, vertex.label.cex=1.2)

par(mfrow=c(1,1))
'''
