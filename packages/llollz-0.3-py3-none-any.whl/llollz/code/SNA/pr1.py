'''
library(igraph)

analyze_network <- function(graph_obj) {
  cat("\n--- Network Analysis ---\n")
  
  cat("Number of nodes:", vcount(graph_obj), "\n")
  cat("Number of edges:", ecount(graph_obj), "\n")
















































  
  if (is_directed(graph_obj)) {
    cat("\nDegrees (Directed):\n")
    print(data.frame(
      Node = V(graph_obj)$name,
      Total = degree(graph_obj, mode="all"),
      In = degree(graph_obj, mode="in"),
      Out = degree(graph_obj, mode="out")
    ))
  } else {
    cat("\nDegrees (Undirected):\n")
    print(degree(graph_obj))
  }









































  
  deg_all <- degree(graph_obj, mode="all")
  min_nodes <- V(graph_obj)$name[deg_all == min(deg_all)]
  cat("\nNode(s) with lowest degree:", paste(min_nodes, collapse=", "), "\n")
  
  cat("\nAdjacency List:\n")
  print(as_adj_list(graph_obj))
  
  cat("\nAdjacency Matrix:\n")
  print(as_adjacency_matrix(graph_obj))
  
  plot(graph_obj, main=paste("Type:", ifelse(is_directed(graph_obj), "Directed", "Undirected")))
}
























g_undirected <- graph_from_literal(A-B, B-C, C-A, C-D)
analyze_network(g_undirected)

g_directed <- graph_from_literal(A-+B, B-+C, C-+A, C-+D, D-+A)
analyze_network(g_directed)
'''
