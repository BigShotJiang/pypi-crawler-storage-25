'''
library(igraph)

edges <- read.csv(file.choose(), header=FALSE)
colnames(edges) <- c("Person", "Event")



















































g <- graph_from_data_frame(edges, directed=FALSE)

V(g)$type <- bipartite_mapping(g)$type

V(g)$color <- ifelse(V(g)$type, "lightblue", "salmon")
V(g)$shape <- ifelse(V(g)$type, "square", "circle")
V(g)$label.cex <- 0.6
V(g)$size <- 15









































plot(g, 
     layout = layout_as_bipartite, 
     main = "Bipartite Network: Davis Southern Club Women")
'''
