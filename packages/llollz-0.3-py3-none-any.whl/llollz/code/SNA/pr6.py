import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd

G = nx.gnp_random_graph(
    n=20,
    p=0.15,
    directed=True
)
G.remove_edges_from(nx.selfloop_edges(G))

damping_factor = 0.85
pagerank = nx.pagerank(G, alpha=damping_factor)
plt.figure(figsize=(8, 6))
pos = nx.spring_layout(G, seed=42)
node_sizes = [8000 * pagerank[n] for n in G.nodes()]

nx.draw_networkx_nodes(
    G,
    pos,
    node_size=node_sizes,
    node_color="skyblue",
    alpha=0.9
)

nx.draw_networkx_edges(
    G,
    pos,
    arrowstyle="->",
    arrowsize=15,
    edge_color="gray"
)

labels = {n: f"{pagerank[n]:.3f}" for n in G.nodes()}
nx.draw_networkx_labels(
    G,
    pos,
    labels,
    font_size=8
)

plt.title(f"PageRank (Damping Factor = {damping_factor})")
plt.axis("off")
plt.show()

pagerank_df = (
    pd.DataFrame.from_dict(pagerank, orient="index", columns=["PageRank"])
    .sort_values("PageRank", ascending=False)
)
pagerank_df.head(10)
