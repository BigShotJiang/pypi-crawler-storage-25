#----------------CLUSTERING-----------------------
'''library(igraph)

#Krackhardt Kite Graph
kite <- make_graph("Krackhardt_Kite")
triangles_count <- count_triangles(kite)
plot(kite, vertex.label = triangles_count, main = "Krackhardt Kite Graph")
























































#Local clustering
local_trans <- transitivity(kite, type = "local")
cat("Local transitivity (clustering):\n")
print(local_trans)

#Manual clustering
manual_clust <- count_triangles(kite) / (degree(kite) * (degree(kite) - 1) / 2)
cat("Manual clustering coefficient:\n")
print(manual_clust)





































g1 <- sample_pa(50, power = 1, directed = FALSE)
g2 <- sample_smallworld(dim = 1, size = 100, nei = 5, p = 0.05)
g <- igraph::union(g1, g2)
g <- simplify(g)

# Edge betweenness clustering
ebc <- cluster_edge_betweenness(g, directed = FALSE)
membership_vec <- membership(ebc)
cat("Community membership:\n")
print(membership_vec)




































mod <- modularity(g, membership_vec)
cat("Modularity of detected communities:", mod, "\n")

plot(ebc, g, main = "Edge Betweenness Community Detection")
'''
