#---------------------------CENTRALIZATION-------------------------------
'''
library(igraph)

optimal_edges <- which.max(mods) - 1
g2 <- delete_edges(g, ebc$removed.edges[seq_len(optimal_edges)])
V(g2)$color <- components(g2)$membership + 1
g2layout <- layout_with_fr(g2)























































plot(g, vertex.label = NA, main = "Original Graph")
plot(g2, vertex.label = NA, layout = g2layout, main = "Optimized Graph")
plot(kite, vertex.label = NA, main = "Krackhardt Kite")


#Adjacency edge list of the Krackhardt Kite
edge_list <- as_edgelist(kite, names = TRUE)
print(edge_list)



















































# Fast-greedy community detection on g2
g2_undirected <- as.undirected(g2, mode = "collapse")
fc <- cluster_fast_greedy(g2_undirected)
max_step <- min(which.max(fc$modularity), length(fc$steps))
com <- cut_at(fc, steps = max_step)

V(g2_undirected)$color <- com + 1
g2layout <- layout_with_fr(g2_undirected)

plot(g2_undirected, vertex.label = NA, layout = g2layout,
     main = "Fast-Greedy Communities")






































# Degree centrality
centr_deg <- centr_degree(g, mode = "in", normalized = TRUE)

# Closeness centrality
centr_clo <- closeness(g, mode = "all", weights = NA, normalized = TRUE)

# Betweenness centrality
betw <- betweenness(g, directed = TRUE, weights = NA)

# Edge betweenness
edge_betw <- edge_betweenness(g, directed = TRUE, weights = NA)

# Eigenvector centrality (remove 'normalized' argument)
eig <- eigen_centrality(g, directed = TRUE)


































cat("Degree centralization:\n"); print(centr_deg$centralization)
cat("Closeness centrality:\n"); print(centr_clo)
cat("Betweenness centrality:\n"); print(betw)
cat("Edge betweenness:\n"); print(edge_betw)
cat("Eigenvector centrality:\n"); print(eig$vector)
'''
