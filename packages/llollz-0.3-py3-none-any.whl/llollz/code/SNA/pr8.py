'''
if(!require(igraph)) install.packages("igraph")
library(igraph)

relations <- data.frame(
  Director = c("Alice", "Alice", "Bob", "Charlie", "Charlie", "David", "Eve", "Eve"),
  Committee = c("Audit", "Risk", "Audit", "Risk", "Comp", "Comp", "Audit", "Comp")
)





















































g_2mode <- graph_from_data_frame(relations, directed = FALSE)

V(g_2mode)$type <- V(g_2mode)$name %in% relations$Committee

plot(g_2mode, 
     layout = layout_as_bipartite, 
     vertex.color = ifelse(V(g_2mode)$type, "salmon", "lightblue"),
     main = "Two-Mode Network: Directors & Committees")

projections <- bipartite_projection(g_2mode)




































g_persons <- projections$proj1
g_committees <- projections$proj2

par(mfrow=c(1,2))





























plot(g_persons, 
     vertex.color = "lightblue", 
     main = "Person-by-Person\n(Shared Committees)")

plot(g_committees, 
     vertex.color = "salmon", 
     main = "Committee-by-Committee\n(Shared Members)")
'''
