# Python SDK Guide

This repo is archived. The maintained SMR SDK now ships in `synth-ai`.

Install:

```bash
uv add synth-ai
```

Import:

```python
from synth_ai.sdk.managed_research import SmrControlClient
```

The archived `managed-research` branch head no longer contains a runnable SDK.
