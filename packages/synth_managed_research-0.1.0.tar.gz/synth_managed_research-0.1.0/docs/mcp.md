# MCP Guide

This repo is archived. The maintained SMR MCP server now ships in `synth-ai`.

Install the CLI/tooling:

```bash
uv tool install synth-ai
```

Launch the stdio server directly:

```bash
synth-ai-mcp-managed-research
```

Or use the bundled Codex installer:

```bash
synth-ai mcp codex install
```
