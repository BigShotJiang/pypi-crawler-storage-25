# Quickstart

This repo is archived. Use the SMR quickstart in `synth-ai` instead.

Install:

```bash
uv add synth-ai
```

Import:

```python
from synth_ai.sdk.managed_research import SmrControlClient
```

For MCP setup, use `synth-ai-mcp-managed-research`.
