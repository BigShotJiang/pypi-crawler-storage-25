"""Public Managed Research package."""

from managed_research.version import __version__

__all__ = ["__version__"]
