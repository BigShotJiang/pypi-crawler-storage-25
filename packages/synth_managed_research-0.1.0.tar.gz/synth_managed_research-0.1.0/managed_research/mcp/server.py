"""MCP entrypoint placeholder for Managed Research."""

from __future__ import annotations


def main() -> None:
    print(
        "managed-research-mcp is scaffolded, but the SMR MCP server has not "
        "been remigrated from synth-ai yet."
    )


__all__ = ["main"]
