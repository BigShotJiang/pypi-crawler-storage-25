"""Managed Research MCP package."""
