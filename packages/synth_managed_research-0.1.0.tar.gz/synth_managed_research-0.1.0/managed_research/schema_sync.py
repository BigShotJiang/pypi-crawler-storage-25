"""Schema sync entrypoint placeholder for Managed Research."""

from __future__ import annotations


def main() -> None:
    print(
        "managed-research-sync-schemas is scaffolded, but schema sync has not "
        "been remigrated from synth-ai yet."
    )


__all__ = ["main"]
