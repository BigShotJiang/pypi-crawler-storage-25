# synth-managed-research

Public package scaffold for Synth Managed Research.

This repository is being prepared to become the canonical public home for the
Managed Research Python SDK, MCP server, and schema sync tooling again.

Current status:

- Packaging and entrypoint scaffolding is in place.
- Full SDK and MCP implementation remigration is planned next.

Planned Python import surface:

```python
from managed_research import __version__
```

Planned CLI entrypoints:

```bash
managed-research-mcp
managed-research-sync-schemas
```

Until the remigration lands, these entrypoints are placeholders.
