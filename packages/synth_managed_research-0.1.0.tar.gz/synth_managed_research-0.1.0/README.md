# managed-research

This repository is archived. The public SMR Python SDK and MCP server now live
in [`synth-ai`](https://github.com/synth-laboratories/synth-ai).

## Migrate now

Python SDK:

```bash
uv add synth-ai
```

```python
from synth_ai.sdk.managed_research import SmrControlClient
```

MCP server:

```bash
uv tool install synth-ai
synth-ai-mcp-managed-research
```

Schema sync:

```bash
synth-ai-smr-sync-schemas --source /path/to/exported/schemas
```

## Historical reference

- Final standalone package release: `managed-research 0.1.0`
- Canonical maintained code path:
  - `synth_ai/sdk/managed_research/`
  - `synth_ai/mcp/managed_research/`

The old SDK, MCP implementation, tests, and packaging metadata have been
removed from this repo head so the default branch is migration-only.
