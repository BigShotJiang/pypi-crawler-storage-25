# noqa: N999
import itertools
import json
import os
import warnings
from collections import defaultdict
from enum import Enum
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pysam
import seaborn as sns
from ugbio_core.plotting_utils import set_pyplot_defaults
from ugbio_core.reports.report_utils import generate_report as generate_report_func
from ugbio_core.trimmer_utils import (
    read_trimmer_failure_codes,
)
from ugbio_core.vcfbed.variant_annotation import VcfAnnotator

from ugbio_ppmseq.ppmSeq_consts import STRAND_RATIO_AXIS_LABEL


# Supported adapter versions
class PpmseqAdapterVersions(Enum):
    LEGACY_V5 = "legacy_v5"
    V1 = "v1"


# Trimmer segment labels and tags
class TrimmerSegmentTags(Enum):
    T_HMER_START = "ts"
    T_HMER_END = "te"
    A_HMER_START = "as"
    A_HMER_END = "ae"
    NATIVE_ADAPTER = "a3"
    STEM_END = "s2"  # when native adapter trimming was done on-tool a modified format is used


class PpmseqCategories(Enum):
    # Category names
    MIXED = "MIXED"
    MINUS = "MINUS"
    PLUS = "PLUS"
    END_UNREACHED = "END_UNREACHED"
    UNDETERMINED = "UNDETERMINED"


class PpmseqCategoriesConsensus(Enum):
    # Category names
    MIXED = "MIXED"
    MINUS = "MINUS"
    PLUS = "PLUS"
    DISCORDANT = "DISCORDANT"
    UNDETERMINED = "UNDETERMINED"


class HistogramColumnNames(Enum):
    # Internal names
    COUNT = "count"
    COUNT_NORM = "count_norm"
    STRAND_RATIO_START = "strand_ratio_start"
    STRAND_RATIO_END = "strand_ratio_end"
    STRAND_RATIO_CATEGORY_START = "strand_ratio_category_start"
    STRAND_RATIO_CATEGORY_END = "strand_ratio_category_end"
    STRAND_RATIO_CATEGORY_END_NO_UNREACHED = "strand_ratio_category_end_no_unreached"
    STRAND_RATIO_CATEGORY_CONSENSUS = "strand_ratio_category_consensus"
    ST = "st"  # STRAND_RATIO_CATEGORY_START in ppmSeq V1
    ET = "et"  # STRAND_RATIO_CATEGORY_END in ppmSeq V1


# Per-read ppmSeq tag names expected in the subsampled SAM.
SR_TAG = "sr"  # strand ratio (float, from raw signal)
ST_TAG = "st"  # start-loop category (MINUS / PLUS / MIXED / UNDETERMINED)
ET_TAG = "et"  # end-loop category
TM_TAG = "tm"  # trimming reasons; contains "A" when the adapter was seen (end reached)

# Subset of sorter-stats metrics to surface in the report's headline Table 1.
# The raw CSV has ~40 rows; we only want the ones below. Missing keys are silently
# skipped so older sorter versions / partial CSVs still work.
SORTER_STATS_KEYS_TO_SHOW = (
    "PF_Barcode_reads",
    "PCT_PF_Reads_aligned",
    "PCT_PF_Q30_bases",
    "PCT_SOFTCLIPPED_bases",
    "Mean_Read_Length",
    "Mean_cvg",
    "PCT_Quality_Trimmed_Reads",
    "PCT_Adapter_Reached",
    "PCT_Chimeras",
    "Indel_Rate",
)


# Per-metric formatters used by the headline "Table 1" in the report. The mix of units
# (integer counts, sub-1 percent, 0-100 percent, plain float) means a single table-wide
# format string would be wrong for at least some rows; keep it as a dict here so the
# notebook can reference one source of truth.
#
# Scales (verified against Z0263 HDF, see VERIFICATION.md):
#   PF_Barcode_reads           — integer count, e.g. 194,932,881
#   PCT_PF_Reads_aligned       — 0-100 scale (e.g. 99.83 means 99.83%)
#   PCT_PF_Q30_bases           — 0-100 scale
#   PCT_SOFTCLIPPED_bases      — 0-100 scale (small values, e.g. 0.90)
#   Mean_Read_Length           — plain float (bp)
#   Mean_cvg                   — plain float (x coverage)
#   PCT_Quality_Trimmed_Reads  — 0-100 scale
#   PCT_Adapter_Reached        — 0-100 scale
#   PCT_Chimeras               — 0-100 scale (small values, e.g. 0.53)
#   Indel_Rate                 — plain float (rate, e.g. 0.29)
SORTER_STATS_FORMATS: dict[str, object] = {
    "PF_Barcode_reads": lambda v: f"{int(v):,}",
    "PCT_PF_Reads_aligned": "{:.2f}%".format,
    "PCT_PF_Q30_bases": "{:.2f}%".format,
    "PCT_SOFTCLIPPED_bases": "{:.2f}%".format,
    "Mean_Read_Length": lambda v: f"{v:.1f}",
    "Mean_cvg": lambda v: f"{v:.1f}",
    "PCT_Quality_Trimmed_Reads": "{:.2f}%".format,
    "PCT_Adapter_Reached": "{:.2f}%".format,
    "PCT_Chimeras": "{:.2f}%".format,
    "Indel_Rate": lambda v: f"{v:.2f}",
}


# Formatters for the two ppmSeq rows that lead Table 1. PCT_MIXED_start_tag is stored
# on the 0-100 scale (stats_shortlist value ~32 means 32%); PCT_failed_adapter_dimers
# is also stored on the 0-100 scale but its natural values are sub-1 (~0.07),
# so we want a high-precision percent after dividing by 100.
TABLE1_PPMSEQ_FORMATS: dict[str, object] = {
    "PCT_MIXED_start_tag": "{:.2f}%".format,
    "PCT_failed_adapter_dimers": lambda v: f"{v / 100:.4%}",
}

# NOTE: these are legacy parameters used ONLY by the featuremap annotator path
# (PpmseqStrandVcfAnnotator / add_strand_ratios_and_categories_to_featuremap). The SAM-based
# QC report does not read or surface them. Treat them as configuration for the legacy
# featuremap annotator only.
STRAND_RATIO_LOWER_THRESH = 0.27
STRAND_RATIO_UPPER_THRESH = 0.73
MIN_TOTAL_HMER_LENGTHS_IN_LOOPS = 4
MAX_TOTAL_HMER_LENGTHS_IN_LOOPS = 8
MIN_STEM_END_MATCHED_LENGTH = 11  # the stem is 12bp, 1 indel allowed as tolerance
BASE_PATH = Path(__file__).parent
REPORTS_DIR = "reports"


class PpmseqStrandVcfAnnotator(VcfAnnotator):
    def __init__(
        self,
        adapter_version: str | PpmseqAdapterVersions,
        sr_lower: float = STRAND_RATIO_LOWER_THRESH,
        sr_upper: float = STRAND_RATIO_UPPER_THRESH,
        min_total_hmer_lengths_in_loops: int = MIN_TOTAL_HMER_LENGTHS_IN_LOOPS,
        max_total_hmer_lengths_in_loops: int = MAX_TOTAL_HMER_LENGTHS_IN_LOOPS,
        min_stem_end_matched_length: int = MIN_STEM_END_MATCHED_LENGTH,
    ):
        _assert_adapter_version_supported(adapter_version)
        self.adapter_version = (
            adapter_version.value if isinstance(adapter_version, PpmseqAdapterVersions) else adapter_version
        )
        self.sr_lower = sr_lower
        self.sr_upper = sr_upper
        self.min_total_hmer_lengths_in_loops = min_total_hmer_lengths_in_loops
        self.max_total_hmer_lengths_in_loops = max_total_hmer_lengths_in_loops
        self.min_stem_end_matched_length = min_stem_end_matched_length

    def edit_vcf_header(self, header: pysam.VariantHeader) -> pysam.VariantHeader:
        """
        Edit the VCF header to add strand ratio and strand ratio category INFO fields

        Parameters
        ----------
        header : pysam.VariantHeader
            VCF header

        Returns
        -------
        pysam.VariantHeader
            VCF header with strand ratio and strand ratio category INFO fields

        """
        header.add_line(f"##ppmSeq_adapter_version={self.adapter_version}")
        header.add_line(
            f"##python_cmd:add_strand_ratios_and_categories_to_featuremap=MIXED is {self.sr_lower}-{self.sr_upper}"
        )
        header.info.add(
            id=HistogramColumnNames.STRAND_RATIO_START.value,
            type="Float",
            number=1,
            description="Ratio of MINUS and PLUS strands measured from the tag in the start of the read",
        )
        header.info.add(
            id=HistogramColumnNames.STRAND_RATIO_END.value,
            type="Float",
            number=1,
            description="Ratio of MINUS and PLUS strands measured from the tag in the end of the read",
        )
        header.info.add(
            id=HistogramColumnNames.STRAND_RATIO_CATEGORY_START.value,
            type="String",
            number=1,
            description="ppmSeq read category derived from the ratio of MINUS and PLUS strands "
            "measured from the tag in the start of the read, options: "
            f'{", ".join(ppmseq_category_list)}',
        )
        header.info.add(
            id=HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value,
            type="String",
            number=1,
            description="ppmSeq read category derived from the ratio of MINUS and PLUS strands "
            "measured from the tag in the end of the read, options: "
            f'{", ".join(ppmseq_category_list)}',
        )
        return header

    # TODO: refactor
    def process_records(self, records: list[pysam.VariantRecord]) -> list[pysam.VariantRecord]:  # noqa: C901
        """
        Add strand ratio and strand ratio category INFO fields to the VCF records

        Parameters
        ----------
        records : list[pysam.VariantRecord]
            list of VCF records

        Returns
        -------
        list[pysam.VariantRecord]
            list of VCF records with strand ratio and strand ratio category INFO fields
        """
        records_out = [None] * len(records)
        for j, record in enumerate(records):
            # get the ppmSeq tags from the VCF record
            ppmseq_tags = defaultdict(int)
            for x in [v.value for v in TrimmerSegmentTags.__members__.values()]:
                if x in record.info:
                    ppmseq_tags[x] = int(record.info.get(x))
            # add the start strand ratio and strand ratio category columns to the VCF record
            if self.adapter_version == PpmseqAdapterVersions.LEGACY_V5.value:
                # assign to simple variables for readability
                t_hmer_start = ppmseq_tags[TrimmerSegmentTags.T_HMER_START.value]
                a_hmer_start = ppmseq_tags[TrimmerSegmentTags.A_HMER_START.value]
                # determine ratio and category
                tags_sum_start = t_hmer_start + a_hmer_start
                if self.min_total_hmer_lengths_in_loops <= tags_sum_start <= self.max_total_hmer_lengths_in_loops:
                    record.info[HistogramColumnNames.STRAND_RATIO_START.value] = t_hmer_start / (
                        t_hmer_start + a_hmer_start
                    )
                else:
                    record.info[HistogramColumnNames.STRAND_RATIO_START.value] = np.nan
                record.info[HistogramColumnNames.STRAND_RATIO_CATEGORY_START.value] = get_strand_ratio_category(
                    record.info[HistogramColumnNames.STRAND_RATIO_START.value],
                    self.sr_lower,
                    self.sr_upper,
                )
                t_hmer_end = ppmseq_tags[TrimmerSegmentTags.T_HMER_END.value]
                a_hmer_end = ppmseq_tags[TrimmerSegmentTags.A_HMER_END.value]
                # determine ratio and category
                tags_sum_end = t_hmer_end + a_hmer_end
                # determine if read end was reached
                is_end_reached = (
                    ppmseq_tags[TrimmerSegmentTags.NATIVE_ADAPTER.value] >= 1
                    or ppmseq_tags[TrimmerSegmentTags.STEM_END.value] >= self.min_stem_end_matched_length
                )
                record.info[HistogramColumnNames.STRAND_RATIO_END.value] = np.nan
                if not is_end_reached:
                    record.info[HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value] = (
                        PpmseqCategories.END_UNREACHED.value
                    )
                else:
                    if self.min_total_hmer_lengths_in_loops <= tags_sum_end <= self.max_total_hmer_lengths_in_loops:
                        record.info[HistogramColumnNames.STRAND_RATIO_END.value] = t_hmer_end / (
                            t_hmer_end + a_hmer_end
                        )
                    record.info[HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value] = get_strand_ratio_category(
                        record.info[HistogramColumnNames.STRAND_RATIO_END.value],
                        self.sr_lower,
                        self.sr_upper,
                    )  # this works for nan values as well - returns UNDETERMINED
            else:  # v1 — st/et tags already carry the category
                record.info[HistogramColumnNames.ST.value] = record.info.get(
                    HistogramColumnNames.ST.value, PpmseqCategories.UNDETERMINED.value
                )
                record.info[HistogramColumnNames.ET.value] = record.info.get(
                    HistogramColumnNames.ET.value, PpmseqCategories.END_UNREACHED.value
                )

            records_out[j] = record

        return records_out


# Misc
ppmseq_category_list = [v.value for v in PpmseqCategories.__members__.values()]
supported_adapter_versions = [e.value for e in PpmseqAdapterVersions]


def _assert_adapter_version_supported(
    adapter_version: str | PpmseqAdapterVersions,
):
    """
    Assert that the adapter version is supported

    Parameters
    ----------
    adapter_version : str | PpmseqAdapterVersions
        adapter version to check

    Raises
    ------
    AssertionError
        If the adapter version is not supported
    """
    if isinstance(adapter_version, PpmseqAdapterVersions):
        if adapter_version.value not in supported_adapter_versions:
            raise AssertionError(
                f"Unsupported adapter version {adapter_version.value}, "
                + f"supported values are {', '.join(supported_adapter_versions)}"
            )
    if isinstance(adapter_version, str):
        if adapter_version not in supported_adapter_versions:
            raise AssertionError(
                f"Unsupported adapter version {adapter_version}, "
                + f"supported values are {', '.join(supported_adapter_versions)}"
            )


def get_strand_ratio_category(strand_ratio, sr_lower, sr_upper) -> str:
    """
    Determine the strand ratio category

    Parameters
    ----------
    strand_ratio : float
        strand ratio
    sr_lower : float
        lower strand ratio threshold for determining strand ratio category MIXED
    sr_upper : float
        upper strand ratio threshold for determining strand ratio category MIXED

    Returns
    -------
    str
        strand ratio category
    """
    if strand_ratio == 0:
        return PpmseqCategories.PLUS.value
    if strand_ratio == 1:
        return PpmseqCategories.MINUS.value
    if sr_lower <= strand_ratio <= sr_upper:
        return PpmseqCategories.MIXED.value
    return PpmseqCategories.UNDETERMINED.value


def read_tags_from_subsampled_sam(
    sam_path: str,
    sample_name: str = "",
    output_filename: str = None,
) -> pd.DataFrame:
    """
    Read per-read ppmSeq tags (sr, st, et, tm) from the subsampled SAM/BAM/CRAM produced by sorter.

    Parameters
    ----------
    sam_path : str
        Path to the subsampled SAM/BAM/CRAM emitted by sorter when demux was called with
        ``--sample-nr-reads=N``. Pysam autodetects the format from the extension.
    sample_name : str, optional
        Sample name to use as the dataframe index name.
    output_filename : str, optional
        If provided, save the dataframe as parquet.

    Returns
    -------
    pd.DataFrame
        One row per read with columns:
          - ``sr`` (float): strand ratio from raw signal. NaN on reads whose sr tag is
            absent; the report's sr-dependent sections are skipped when every read lacks it.
          - ``st`` (str): start-loop category (MINUS / PLUS / MIXED / UNDETERMINED).
          - ``et`` (str): end-loop category; empty string when the ``et`` tag is absent.
          - ``tm`` (str): trimming-reason string (e.g. ``A``, ``AQZ``). Empty string when
            absent, which means the adapter was not reached — mapped to END_UNREACHED below.
          - ``count``: always 1 — lets downstream code that aggregates on it work unchanged.
          - ``is_aligned`` (bool): ``not rec.is_unmapped``. Used by the read-length plot to
            split aligned vs unaligned reads into two normalized lines.
          - ``strand_ratio_category_start`` / ``strand_ratio_category_end``:
            copies of ``st`` / ``et`` with END_UNREACHED substituted on rows where ``tm`` has no ``A``.

    Raises
    ------
    KeyError
        If any read is missing the ``st`` tag. The ``st`` tag is required on every ppmSeq
        read produced by the current pipeline; a missing one is a fixture/pipeline bug.
    """
    rows = []
    for_sr_nan = float("nan")
    with pysam.AlignmentFile(sam_path, check_sq=False) as fh:
        for rec in fh:
            # Skip reads that Trimmer couldn't match. Sorter tags them with RG="unmatched"
            # (configurable via TrimmerParameters.failure_read_group, but "unmatched" is the
            # standard value used by our WDL templates). These reads never received ppmSeq
            # tag calls so including them would either raise KeyError on st or skew Section 1
            # denominators; they're accounted for separately in the Trimmer failure-codes
            # section.
            try:
                if rec.get_tag("RG") == "unmatched":
                    # Trimmer routed this read to the unmatched read group — it has no
                    # ppmSeq tag calls, so skip before querying st below.
                    continue
            except KeyError:
                # No RG tag at all — treat as matched. Production reads always carry an
                # RG, but handcrafted test fixtures sometimes omit it.
                pass
            st = rec.get_tag(ST_TAG)  # KeyError if absent — st is required
            try:
                sr = float(rec.get_tag(SR_TAG))
            except KeyError:
                # sr is optional: libraries that don't carry it (e.g. legacy_v5 chemistries
                # without strand-ratio calibration) still produce a useful QC report, just
                # without the sr-based sections.
                sr = for_sr_nan
            try:
                et = rec.get_tag(ET_TAG)
            except KeyError:
                et = ""
            try:
                tm = rec.get_tag(TM_TAG)
            except KeyError:
                # A missing tm tag means the adapter was not reached (== END_UNREACHED
                # downstream), not "undetermined". See Ken's comment on PR #307.
                tm = ""
            read_len = rec.query_length or 0
            rows.append(
                (sr, str(st), str(et), str(tm), int(read_len), not rec.is_unmapped),
            )

    df_reads = pd.DataFrame(rows, columns=[SR_TAG, ST_TAG, ET_TAG, TM_TAG, "read_length", "is_aligned"])
    df_reads[HistogramColumnNames.COUNT.value] = 1
    is_end_reached = df_reads[TM_TAG].str.contains("A", na=False)
    undetermined = PpmseqCategories.UNDETERMINED.value
    end_unreached = PpmseqCategories.END_UNREACHED.value
    df_reads[HistogramColumnNames.STRAND_RATIO_CATEGORY_START.value] = df_reads[ST_TAG].replace("", undetermined)
    df_reads[HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value] = (
        df_reads[ET_TAG].where(is_end_reached, end_unreached).replace("", undetermined)
    )
    # Expose sr under STRAND_RATIO_{START,END} columns for downstream plotters that group
    # by those. Post-RAMP reads have a single sr per read; STRAND_RATIO_END is masked on
    # reads where the end was not reached.
    df_reads[HistogramColumnNames.STRAND_RATIO_START.value] = df_reads[SR_TAG].round(2)
    df_reads[HistogramColumnNames.STRAND_RATIO_END.value] = df_reads[SR_TAG].where(is_end_reached).round(2)
    df_reads[HistogramColumnNames.COUNT_NORM.value] = 1.0 / max(len(df_reads), 1)
    if sample_name:
        df_reads.index.name = sample_name
    if output_filename is not None:
        df_reads.to_parquet(output_filename)
    return df_reads


def has_sr_tag(df_reads: pd.DataFrame) -> bool:
    """Return True if at least one read in the per-read dataframe carries a non-NaN sr value.

    Used to decide whether the sr-dependent report sections (Figure 3 "Overall strand-ratio
    distribution" and Figure 4 "Strand-ratio by end-tag category") should be rendered at all.
    """
    return df_reads[SR_TAG].notna().any()


def all_reads_have_sr_tag(df_reads: pd.DataFrame) -> bool:
    """Return True only when every read in the per-read dataframe has a non-NaN sr value.

    Used to decide whether the start-axis UNDETERMINED category can be safely suppressed in
    the category / concordance plots. When sr is present on every read the Trimmer --compare
    cascade guarantees st ∈ {MIXED, PLUS, MINUS}; hiding UNDETERMINED is correct. If even
    one read is missing sr, st could still legitimately be UNDETERMINED for that read, so we
    keep the bar/row.
    """
    return len(df_reads) > 0 and df_reads[SR_TAG].notna().all()


def group_trimmer_histogram_by_strand_ratio_category(
    adapter_version: str | PpmseqAdapterVersions,
    df_trimmer_histogram: pd.DataFrame,
) -> pd.DataFrame:
    """
    Group the trimmer histogram by strand ratio category

    Parameters
    ----------
    adapter_version : str | PpmseqAdapterVersions
        adapter version to check
    df_trimmer_histogram : pd.DataFrame
        per-read dataframe from read_tags_from_subsampled_sam (columns: sr, st, et, tm, count, ...)

    Returns
    -------
    pd.DataFrame
        dataframe with strand ratio category columns as index and strand ratio category columns as columns
    """
    # fill end tag with dummy column if it does not exist
    _assert_adapter_version_supported(adapter_version)
    if HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value not in df_trimmer_histogram.columns:
        df_trimmer_histogram.loc[:, HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value] = np.nan
    # Group by strand ratio category
    count = HistogramColumnNames.COUNT.value
    df_trimmer_histogram_by_category = (
        pd.concat(
            (
                df_trimmer_histogram.groupby(HistogramColumnNames.STRAND_RATIO_CATEGORY_START.value)
                .agg({count: "sum"})
                .rename(columns={count: HistogramColumnNames.STRAND_RATIO_CATEGORY_START.value}),
                df_trimmer_histogram.groupby(HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value)
                .agg({count: "sum"})
                .rename(columns={count: HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value}),
                df_trimmer_histogram.groupby(HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value)
                .agg({count: "sum"})
                .drop(PpmseqCategories.END_UNREACHED.value, errors="ignore")
                .rename(columns={count: HistogramColumnNames.STRAND_RATIO_CATEGORY_END_NO_UNREACHED.value}),
            ),
            axis=1,
        )
        .reindex(ppmseq_category_list)
        .dropna(how="all", axis=1)
        .fillna(0)
        .astype(int)
    )
    # drop dummy column
    if HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value not in df_trimmer_histogram.columns:
        df_trimmer_histogram_by_category = df_trimmer_histogram_by_category.drop(
            [
                HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value,
                HistogramColumnNames.STRAND_RATIO_CATEGORY_END_NO_UNREACHED.value,
            ],
            axis=1,
        )
    return df_trimmer_histogram_by_category


def get_strand_ratio_category_concordance(
    adapter_version: str | PpmseqAdapterVersions,
    df_trimmer_histogram: pd.DataFrame,
) -> pd.DataFrame:
    """
    Get the concordance between the strand ratio categories at the start and end of the read

    Parameters
    ----------
    adapter_version : str | PpmseqAdapterVersions
        adapter version to check
    df_trimmer_histogram : pd.DataFrame
        per-read dataframe from read_tags_from_subsampled_sam (columns: sr, st, et, tm, count, ...)

    Returns
    -------
    df_category_concordance: pd.DataFrame
        dataframe with strand ratio category columns as index and strand ratio category columns as columns
    df_category_concordance_no_end_unreached: pd.DataFrame
        dataframe with strand ratio category columns as index and strand ratio category columns as columns, excluding
        reads where the end was unreached


    """
    _assert_adapter_version_supported(adapter_version)
    # create concordance dataframe
    df_category_concordance = (
        df_trimmer_histogram.groupby(
            [
                HistogramColumnNames.STRAND_RATIO_CATEGORY_START.value,
                HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value,
            ]
        )
        .agg({HistogramColumnNames.COUNT.value: "sum"})
        .reindex(
            itertools.product(
                [v for v in ppmseq_category_list if v != PpmseqCategories.END_UNREACHED.value],
                ppmseq_category_list,
            )
        )
        .fillna(0)
    )
    df_category_concordance = (df_category_concordance / df_category_concordance.sum().sum()).rename(
        columns={HistogramColumnNames.COUNT.value: HistogramColumnNames.COUNT_NORM.value}
    )
    # create concordance dataframe excluding end unreached reads
    df_category_concordance_no_end_unreached = df_category_concordance.drop(
        PpmseqCategories.END_UNREACHED.value,
        level=HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value,
        errors="ignore",
    )
    df_category_concordance_no_end_unreached = (
        df_category_concordance_no_end_unreached / df_category_concordance_no_end_unreached.sum().sum()
    )
    index_names = df_category_concordance_no_end_unreached.index.names
    df_category_concordance_no_end_unreached = df_category_concordance_no_end_unreached.rename(
        columns={HistogramColumnNames.COUNT.value: HistogramColumnNames.COUNT_NORM.value}
    ).reset_index()
    # create consensus dataframe (combined status of both tags)
    x = HistogramColumnNames.STRAND_RATIO_CATEGORY_CONSENSUS.value  # otherwise flake8 fails on line length
    #   sum consensus categories where both ends are not UNDETERMINED
    df_category_consensus = (
        df_category_concordance_no_end_unreached[
            (
                df_category_concordance_no_end_unreached[HistogramColumnNames.STRAND_RATIO_CATEGORY_START.value]
                == df_category_concordance_no_end_unreached[HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value]
            )
            & (
                df_category_concordance_no_end_unreached[HistogramColumnNames.STRAND_RATIO_CATEGORY_START.value]
                != PpmseqCategories.UNDETERMINED.value
            )
            & (
                df_category_concordance_no_end_unreached[HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value]
                != PpmseqCategories.UNDETERMINED.value
            )
        ]
        .drop(columns=[HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value])
        .rename(columns={HistogramColumnNames.STRAND_RATIO_CATEGORY_START.value: x})
        .set_index(x)
    )
    #   Set UNDETERMINED where at least one is
    df_category_consensus.loc[
        PpmseqCategoriesConsensus.UNDETERMINED.value,
        HistogramColumnNames.COUNT_NORM.value,
    ] = df_category_concordance_no_end_unreached[
        (
            df_category_concordance_no_end_unreached[HistogramColumnNames.STRAND_RATIO_CATEGORY_START.value]
            == PpmseqCategories.UNDETERMINED.value
        )
        | (
            df_category_concordance_no_end_unreached[HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value]
            == PpmseqCategories.UNDETERMINED.value
        )
    ][HistogramColumnNames.COUNT_NORM.value].sum()
    #   the remainder is DISCORDANT - both not UNDETERMINED but do not match
    count = HistogramColumnNames.COUNT_NORM.value  # workaround flake8 contradicts Black and fails on line length
    df_category_consensus.loc[PpmseqCategoriesConsensus.DISCORDANT.value, count] = (
        1 - df_category_consensus[HistogramColumnNames.COUNT_NORM.value].sum()
    )

    return (
        df_category_concordance[HistogramColumnNames.COUNT_NORM.value],
        df_category_concordance_no_end_unreached.set_index(index_names)[HistogramColumnNames.COUNT_NORM.value],
        df_category_consensus[HistogramColumnNames.COUNT_NORM.value],
    )


def read_trimmer_tags_dataframe(
    adapter_version: str | PpmseqAdapterVersions,
    df_strand_ratio_category: pd.DataFrame,
    df_category_consensus: pd.Series,
    df_category_concordance: pd.Series = None,
) -> pd.DataFrame:
    """
    Read the trimmer tags dataframe

    Parameters
    ----------
    adapter_version : str | PpmseqAdapterVersions
        adapter version to check
    df_strand_ratio_category : pd.DataFrame

    df_category_consensus : pd.Series

    df_category_concordance : pd.Series, optional

    Returns
    -------
    pd.DataFrame
        dataframe with strand ratio category columns as index and strand ratio category columns as columns

    """
    _assert_adapter_version_supported(adapter_version)
    df_tags = df_category_consensus * 100
    undetermined = PpmseqCategoriesConsensus.UNDETERMINED.value
    df_tags = df_tags.rename(
        {
            **{
                x: f"PCT_{x}_both_tags_where_endreached"
                for x in (
                    PpmseqCategories.MIXED.value,
                    PpmseqCategories.MINUS.value,
                    PpmseqCategories.PLUS.value,
                )
            },
            # Keep the previous name for the consensus Series but expose it to the
            # shortlist as PCT_UNDETERMINED_end_tag (reviewer asked for the more
            # accurate name).
            undetermined: "PCT_UNDETERMINED_end_tag",
            PpmseqCategoriesConsensus.DISCORDANT.value: f"PCT_{PpmseqCategoriesConsensus.DISCORDANT.value}",
        }
    )
    df_tags.name = "value"
    df_strand_ratio_category_norm = (
        df_strand_ratio_category.loc[
            [PpmseqCategories.END_UNREACHED.value],
            HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value,
        ]
        * 100
        / df_strand_ratio_category[HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value].sum()
    ).T.to_frame()
    df_strand_ratio_category_norm.index = ["PCT_read_end_unreached"]
    df_strand_ratio_category_norm.columns = ["value"]
    df_tags = pd.concat((df_tags, df_strand_ratio_category_norm["value"])).rename(
        {
            HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value: "PCT_read_end_unreached",
        }
    )
    # Calculate mixed reads of total (including end unreached) and mixed read coverage
    mixed_tot = df_category_concordance.loc[(PpmseqCategories.MIXED.value, PpmseqCategories.MIXED.value),]
    mixed_start = df_category_concordance.loc[(PpmseqCategories.MIXED.value, slice(None)),].sum()
    df_mixed_cov = pd.DataFrame(
        {
            "PCT_MIXED_start_tag": mixed_start * 100,
            "PCT_MIXED_both_tags": mixed_tot * 100,
        },
        index=["value"],
    ).T["value"]
    df_tags = pd.concat((df_mixed_cov, df_tags))

    # Drop noise metrics from the full mixed-reads dump (§7 in the report, stored under
    # /mixed_reads_stats) — kenissur asked for these two to be removed. They stay
    # available via the /strand_ratio_category_consensus HDF5 key for downstream
    # tooling / Papyrus.
    for drop_metric in ("PCT_UNDETERMINED_end_tag", "PCT_DISCORDANT"):
        if drop_metric in df_tags.index:
            df_tags = df_tags.drop(drop_metric)

    df_tags.index.name = "metric"
    return df_tags


def read_trimmer_failure_codes_ppmseq(trimmer_failure_codes_csv: str):
    """
    Read a trimmer failure codes csv file

    Parameters
    ----------
    trimmer_failure_codes_csv : str
        path to a Trimmer failure codes file

    Returns
    -------
    pd.DataFrame
        dataframe with trimmer failure codes

    pd.DataFrame
        dataframe with trimmer application-specific statistics

    Raises
    ------
    AssertionError
        If the columns are not as expected
    """
    df_trimmer_failure_codes = read_trimmer_failure_codes(
        trimmer_failure_codes_csv, include_failed_rsq=False, add_total=True
    )
    adapter_dimers_index = ("insert", "sequence was too short")
    adapter_dimers = (
        df_trimmer_failure_codes.reindex([adapter_dimers_index]).fillna(0).loc[adapter_dimers_index, "PCT_failure"]
    )

    unrecognized_stem_index = ("Stem_start", "no match")
    unrecognized_stem = (
        df_trimmer_failure_codes.reindex([unrecognized_stem_index])
        .fillna(0)
        .loc[unrecognized_stem_index, "PCT_failure"]
    )

    unrecognized_start_loop_index = ("Unrecognized_Start_loop", "sequence was too long")
    unrecognized_start_loop = (
        df_trimmer_failure_codes.reindex([unrecognized_start_loop_index])
        .fillna(0)
        .loc[unrecognized_start_loop_index, "PCT_failure"]
    )

    total_failed_reads_pct = df_trimmer_failure_codes.loc[("total", "total"), "PCT_failure"]

    df_metrics = pd.DataFrame(
        (
            ("PCT_failed_adapter_dimers", adapter_dimers),
            ("PCT_failed_unrecognized_start_stem", unrecognized_stem),
            ("PCT_failed_unrecognized_start_loop", unrecognized_start_loop),
            ("PCT_failed_total", total_failed_reads_pct),
        ),
        columns=["metric", "value"],
    ).set_index("metric")

    return df_trimmer_failure_codes, df_metrics


def _load_whitelisted_sorter_stats(sorter_stats_csv: str) -> pd.Series:
    """Load a sorter-stats CSV, keep only the whitelisted numeric rows.

    Reads the raw two-column CSV directly instead of going through
    ``read_and_parse_sorter_statistics_csv``, which silently filters to a fixed set
    of ~7 metrics and would drop several of the rows we want to show (e.g.
    ``PCT_SOFTCLIPPED_bases``, ``PCT_Adapter_Reached``). Rows that don't parse to a
    float are dropped; if any whitelisted key was present but unparseable, emit a
    warning so future sorter versions that start emitting wrapped values
    (``"(1.43)"``) or ``"N/A"`` don't silently vanish from the Key-metrics table.
    """
    raw = pd.read_csv(sorter_stats_csv, header=None, names=["metric", "value"])
    raw = raw.dropna(subset=["metric"]).set_index("metric")["value"]
    raw_numeric = pd.to_numeric(raw, errors="coerce")
    coerced_out = [k for k in SORTER_STATS_KEYS_TO_SHOW if k in raw.index and pd.isna(raw_numeric.loc[k])]
    if coerced_out:
        warnings.warn(
            f"Sorter-stats CSV has non-numeric values for whitelisted keys "
            f"{coerced_out}; those rows will be missing from the Key-metrics table.",
            stacklevel=2,
        )
    raw = raw_numeric.dropna()
    # Preserve the canonical SORTER_STATS_KEYS_TO_SHOW order so the report table
    # reads top-to-bottom in the expected layout.
    present = [k for k in SORTER_STATS_KEYS_TO_SHOW if k in raw.index]
    sorter_stats = raw.reindex(present)
    sorter_stats.name = "value"
    sorter_stats.index.name = "metric"
    return sorter_stats


def collect_statistics(
    adapter_version: str | PpmseqAdapterVersions,
    subsampled_sam: str,
    output_filename: str,
    sorter_stats_csv: str = None,
    trimmer_failure_codes_csv: str = None,
):
    """
    Collect statistics from a ppmSeq subsampled SAM file produced by sorter.

    Parameters
    ----------
    adapter_version : str | PpmseqAdapterVersions
        adapter version (kept for backward compatibility; SAM-based path treats all versions identically).
    subsampled_sam : str
        Path to the subsampled sam.gz produced by sorter when demux is called with ``--sample-nr-reads=N``.
    output_filename : str
        path to save dataframe to in hdf format (should end with .h5).
    sorter_stats_csv : str, optional
        path to a Sorter stats file. When present, the whitelisted rows
        (``SORTER_STATS_KEYS_TO_SHOW``) are appended to ``/stats_shortlist`` — the
        Key-metrics Series rendered in Section 1. The full filtered series is also
        stored under ``/sorter_stats``.
    trimmer_failure_codes_csv : str, optional
        path to a Trimmer failure codes file. When present, the headline
        ``PCT_failed_adapter_dimers`` row is appended to ``/stats_shortlist``;
        the rest of the per-code failure-rate metrics are stored under
        ``/failure_codes_metrics`` for the Section 8 table.
    """
    _assert_adapter_version_supported(adapter_version)
    df_reads = read_tags_from_subsampled_sam(subsampled_sam)
    df_strand_ratio_category = group_trimmer_histogram_by_strand_ratio_category(adapter_version, df_reads)
    df_category_concordance, _, df_category_consensus = get_strand_ratio_category_concordance(adapter_version, df_reads)

    if sorter_stats_csv:
        sorter_stats = _load_whitelisted_sorter_stats(sorter_stats_csv)
    else:
        sorter_stats = pd.Series(dtype=float, name="value")
        sorter_stats.index.name = "metric"

    df_tags = read_trimmer_tags_dataframe(
        adapter_version=adapter_version,
        df_strand_ratio_category=df_strand_ratio_category,
        df_category_consensus=df_category_consensus,
        df_category_concordance=df_category_concordance,
    )

    # The full ppmSeq mixed-read metrics (MIXED coverage, per-category percentages,
    # read-end-unreached fraction) live under /mixed_reads_stats. /stats_shortlist
    # stores the concise headline Key-metrics Series (one PCT_MIXED_start_tag row,
    # one PCT_failed_adapter_dimers row when available, then the whitelisted sorter
    # rows in SORTER_STATS_KEYS_TO_SHOW order) — this is the table the report's
    # Section 1 "Key metrics" displays.
    df_mixed_reads_stats = df_tags

    if trimmer_failure_codes_csv:
        df_trimmer_failure_codes, df_failure_codes_metrics = read_trimmer_failure_codes_ppmseq(
            trimmer_failure_codes_csv
        )

    # Assemble the Key-metrics Series in display order. Rows missing from the inputs
    # (e.g. no failure codes CSV, sorter CSV lacking a metric) are silently skipped.
    key_metrics_rows: list[tuple[str, float]] = []
    if "PCT_MIXED_start_tag" in df_mixed_reads_stats.index:
        key_metrics_rows.append(("PCT_MIXED_start_tag", float(df_mixed_reads_stats.loc["PCT_MIXED_start_tag"])))
    if trimmer_failure_codes_csv and "PCT_failed_adapter_dimers" in df_failure_codes_metrics.index:
        key_metrics_rows.append(
            (
                "PCT_failed_adapter_dimers",
                float(df_failure_codes_metrics.loc["PCT_failed_adapter_dimers", "value"]),
            )
        )
    for key in SORTER_STATS_KEYS_TO_SHOW:
        if key in sorter_stats.index:
            key_metrics_rows.append((key, float(sorter_stats.loc[key])))
    df_stats_shortlist = pd.Series(dict(key_metrics_rows), dtype=float, name="value")
    df_stats_shortlist.index.name = "metric"
    # Preserve row order.
    if key_metrics_rows:
        df_stats_shortlist = df_stats_shortlist.loc[[n for n, _ in key_metrics_rows]]

    if not output_filename.endswith(".h5"):
        output_filename += ".h5"
    with pd.HDFStore(output_filename, "w") as store:
        keys_to_convert = [
            "stats_shortlist",
            "mixed_reads_stats",
            "sorter_stats",
            "strand_ratio_category_counts",
            "strand_ratio_category_norm",
            "strand_ratio_category_concordance",
            "strand_ratio_category_consensus",
        ]
        store["stats_shortlist"] = df_stats_shortlist
        store["mixed_reads_stats"] = df_mixed_reads_stats
        store["sorter_stats"] = sorter_stats
        store["subsampled_reads"] = df_reads
        store["strand_ratio_category_counts"] = df_strand_ratio_category
        store["strand_ratio_category_norm"] = df_strand_ratio_category / df_strand_ratio_category.sum()
        store["strand_ratio_category_concordance"] = df_category_concordance
        store["strand_ratio_category_consensus"] = df_category_consensus
        if trimmer_failure_codes_csv:
            store["trimmer_failure_codes"] = df_trimmer_failure_codes
            store["failure_codes_metrics"] = df_failure_codes_metrics
            keys_to_convert += ["trimmer_failure_codes", "failure_codes_metrics"]
        # keys_to_convert is consumed by convert_h5_to_papyrus_json to decide which HDF keys
        # to flatten into the shareable Papyrus JSON. Kept in the HDF for downstream tools
        # that need the same list (analytics DB ingestion, etc.).
        store["keys_to_convert"] = pd.Series(keys_to_convert)


def add_strand_ratios_and_categories_to_featuremap(
    adapter_version: str | PpmseqAdapterVersions,
    input_featuremap_vcf: str,
    output_featuremap_vcf: str,
    sr_lower: float = STRAND_RATIO_LOWER_THRESH,
    sr_upper: float = STRAND_RATIO_UPPER_THRESH,
    min_total_hmer_lengths_in_tags: int = MIN_TOTAL_HMER_LENGTHS_IN_LOOPS,
    max_total_hmer_lengths_in_tags: int = MAX_TOTAL_HMER_LENGTHS_IN_LOOPS,
    min_stem_end_matched_length: int = MIN_STEM_END_MATCHED_LENGTH,
    chunk_size: int = 10000,
    process_number: int = 1,
):
    """
    Add strand ratio and strand ratio category columns to a featuremap VCF file

    Parameters
    ----------
    adapter_version : str | PpmseqAdapterVersions
        adapter version to check
    input_featuremap_vcf : str
        path to input featuremap VCF file
    output_featuremap_vcf : str
        path to which the output featuremap VCF with the additional fields will be written
    sr_lower : float, optional
        lower strand ratio threshold for determining strand ratio category
        default 0.27
    sr_upper : float, optional
        upper strand ratio threshold for determining strand ratio category
        default 0.73
    min_total_hmer_lengths_in_tags : int, optional
        minimum total hmer lengths in tags for determining strand ratio category
        default 4
    max_total_hmer_lengths_in_tags : int, optional
        maximum total hmer lengths in tags for determining strand ratio category
        default 8
    min_stem_end_matched_length : int, optional
        minimum length of stem end matched to determine the read end was reached
    chunk_size : int, optional
        The chunk size. Defaults to 10000.
    process_number: int, optional
        The number of processes to use. Defaults to 1.
    """
    _assert_adapter_version_supported(adapter_version)
    ppmseq_variant_annotator = PpmseqStrandVcfAnnotator(
        adapter_version=adapter_version,
        sr_lower=sr_lower,
        sr_upper=sr_upper,
        min_total_hmer_lengths_in_loops=min_total_hmer_lengths_in_tags,
        max_total_hmer_lengths_in_loops=max_total_hmer_lengths_in_tags,
        min_stem_end_matched_length=min_stem_end_matched_length,
    )
    PpmseqStrandVcfAnnotator.process_vcf(
        annotators=[ppmseq_variant_annotator],
        input_path=input_featuremap_vcf,
        output_path=output_featuremap_vcf,
        chunk_size=chunk_size,
        process_number=process_number,
    )


def plot_strand_ratio_category(
    adapter_version: str | PpmseqAdapterVersions,
    df_trimmer_histogram: pd.DataFrame,
    title: str = "",
    output_filename: str = None,
    ax: plt.Axes = None,
    *,
    sr_present: bool = False,
) -> plt.Axes:
    """
    Plot the strand ratio category histogram

    Parameters
    ----------
    adapter_version : str | PpmseqAdapterVersions
        adapter version to check
    df_trimmer_histogram : pd.DataFrame
        per-read dataframe from read_tags_from_subsampled_sam (columns: sr, st, et, tm, count, ...)
    title : str, optional
        plot title, by default ""
    output_filename : str, optional
        path to save the plot to, by default None (not saved)
    ax : matplotlib.axes.Axes, optional
        axes to plot on, by default None (new figure created)
    sr_present : bool, optional
        Pass True only when *every* read has sr (see :func:`all_reads_have_sr_tag`). When
        that holds, the Trimmer --compare cascade only emits MIXED / PLUS / MINUS on the
        start axis so UNDETERMINED is dropped from the Start-tag bars. If sr is only
        partially present, pass False: some reads may legitimately still carry
        st=UNDETERMINED and hiding their bar would be misleading. The end-tag axis keeps
        UNDETERMINED regardless because et is base-called.

    Returns
    -------
        matplotlib.axes.Axes

    """
    _assert_adapter_version_supported(adapter_version)
    # display settings
    set_pyplot_defaults()
    if ax is None:
        plt.figure(figsize=(14, 4))
        ax = plt.gca()
    else:
        plt.sca(ax)

    # group by category

    df_trimmer_histogram_by_strand_ratio_category = (
        (group_trimmer_histogram_by_strand_ratio_category(adapter_version, df_trimmer_histogram))
        .drop(PpmseqCategories.END_UNREACHED.value, errors="ignore")
        .drop(
            columns=[HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value],
            errors="ignore",
        )
        .rename(
            columns={
                HistogramColumnNames.STRAND_RATIO_CATEGORY_START.value: "Start tag strand ratio category",
                HistogramColumnNames.STRAND_RATIO_CATEGORY_END_NO_UNREACHED.value: "End tag strand ratio category",
            }
        )
    )
    # Fractions 0-1; multiply by 100 so the axis + bar labels read as percent.
    normalized = (
        100 * df_trimmer_histogram_by_strand_ratio_category / df_trimmer_histogram_by_strand_ratio_category.sum()
    )
    if sr_present:
        # Zero out UNDETERMINED on the Start-tag column only (if present); leave the End-tag
        # column untouched because et can still be UNDETERMINED when sr is present.
        start_col = "Start tag strand ratio category"
        undetermined = PpmseqCategories.UNDETERMINED.value
        if start_col in normalized.columns and undetermined in normalized.index:
            normalized.loc[undetermined, start_col] = float("nan")
    df_plot = normalized.reset_index().melt(id_vars="index", var_name="").dropna(subset=["value"])
    # plot
    sns.barplot(
        data=df_plot,
        x="index",
        y="value",
        hue="",
        ax=ax,
    )
    for cont in ax.containers:
        ax.bar_label(cont, labels=[f"{x:.1f}%" for x in cont.datavalues], label_type="edge")
    plt.xticks(rotation=10, ha="center")
    plt.xlabel("")
    plt.ylabel("Relative abundance (%)", fontsize=22)
    ylim = ax.get_ylim()
    ax.set_ylim(ylim[0], ylim[1] * 1.05)
    legend_handle = plt.legend(bbox_to_anchor=(1.01, 1), fontsize=14, framealpha=0.95)
    title_handle = plt.title(title)
    if output_filename is not None:
        if not output_filename.endswith(".png"):
            output_filename += ".png"
        plt.savefig(
            output_filename,
            facecolor="w",
            dpi=300,
            bbox_inches="tight",
            bbox_extra_artists=[title_handle, legend_handle],
        )
    return ax


def plot_strand_ratio_category_concordnace(
    adapter_version: str | PpmseqAdapterVersions,
    df_trimmer_histogram: pd.DataFrame,
    title: str = "",
    output_filename: str = None,
    axs: list[plt.Axes] = None,
    *,
    sr_present: bool = False,
) -> list[plt.Axes]:
    """
    Plot the strand ratio category concordance heatmap

    Parameters
    ----------
    adapter_version : str | PpmseqAdapterVersions
        adapter version to check
    df_trimmer_histogram : pd.DataFrame
        per-read dataframe from read_tags_from_subsampled_sam (columns: sr, st, et, tm, count, ...)
    title : str, optional
        plot title, by default ""
    output_filename : str, optional
        path to save the plot to, by default None (not saved)
    axs : matplotlib.axes.Axes, optional
        axes to plot on, by default None (new figure created)
    sr_present : bool, optional
        Pass True only when *every* read has sr (see :func:`all_reads_have_sr_tag`). When
        that holds, the UNDETERMINED row on the start-tag axis is dropped — see
        plot_strand_ratio_category for the full rationale. The end-tag (column) axis
        keeps UNDETERMINED regardless.

    Returns
    -------
    list of axes objects to which the output was plotted

    """
    _assert_adapter_version_supported(adapter_version)
    # get concordance
    df_category_concordance, df_category_concordance_no_end_unreached, _ = get_strand_ratio_category_concordance(
        adapter_version, df_trimmer_histogram
    )

    # display settings
    set_pyplot_defaults()
    if axs is None:
        fig, axs = plt.subplots(2, 1, figsize=(10, 12))
        fig.subplots_adjust(hspace=0.7)
    # Assign title_handle up front so the savefig call below has a valid reference even
    # if every subplot ends up empty (which would otherwise raise NameError).
    suptitle_handle = plt.suptitle(title)
    bbox_extras = [suptitle_handle]
    # Start-axis categories. UNDETERMINED is dropped when sr is present because the
    # sr-based cascade never emits UNDETERMINED on the start axis.
    start_categories = [v for v in ppmseq_category_list if v != PpmseqCategories.END_UNREACHED.value]
    if sr_present:
        start_categories = [v for v in start_categories if v != PpmseqCategories.UNDETERMINED.value]
    # plot
    for ax, subtitle, df_plot in zip(
        axs,
        ("All reads", "Only reads where end was reached"),
        (df_category_concordance, df_category_concordance_no_end_unreached),
        strict=False,
    ):
        df_plot = df_plot.to_frame().unstack().droplevel(0, axis=1)  # noqa: PD010, PLW2901
        df_plot = df_plot.loc[  # noqa: PLW2901
            [v for v in start_categories if v in df_plot.index],
            [v for v in ppmseq_category_list if v in df_plot.columns],
        ].fillna(0)
        df_plot.index.name = "Start tag category"
        df_plot.columns.name = "End tag category"

        if df_plot.shape[0] == 0:
            continue

        sns.heatmap(
            df_plot,
            annot=True,
            fmt=".1%",
            cmap="rocket",
            linewidths=4,
            linecolor="white",
            cbar=False,
            ax=ax,
            annot_kws={"size": 18},
        )
        ax.grid(visible=False)
        plt.sca(ax)
        plt.xticks(rotation=20)
        bbox_extras.append(ax.set_title(subtitle, fontsize=20))
    if output_filename is not None:
        if not output_filename.endswith(".png"):
            output_filename += ".png"
        plt.savefig(
            output_filename,
            facecolor="w",
            dpi=300,
            bbox_inches="tight",
            bbox_extra_artists=bbox_extras,
        )
    return axs


_SR_BIN_EDGES = np.arange(0.0, 1.01, 0.01)
_SR_TITLE_FONTSIZE = 28
_SR_AXIS_LABEL_FONTSIZE = 20

# Vertical lines at the sr thresholds used by the Solaris-2 --compare cascade (MIXED band edges).
_SR_THRESHOLD_LINES = (0.2, 0.8)

# Colors for sr-by-et facets; one per end-tag category so the per-category panels read at a glance.
_SR_CATEGORY_COLORS = {
    PpmseqCategories.PLUS.value: "xkcd:royal blue",
    PpmseqCategories.MINUS.value: "xkcd:red orange",
    PpmseqCategories.MIXED.value: "xkcd:green",
    PpmseqCategories.UNDETERMINED.value: "xkcd:grey",
    PpmseqCategories.END_UNREACHED.value: "xkcd:black",
}


def _plot_sr_hist_on_ax(ax: plt.Axes, sr_values: pd.Series, color: str) -> None:
    """Draw an sr histogram on the given ax as a line plot over bin centers, expressed as a
    percentage so facets are directly comparable. Values outside [0, 1] are clipped
    (np.clip-style) so the outlier mass lands in the edge bins rather than being discarded."""
    n = len(sr_values)
    if n == 0:
        ax.text(0.5, 0.5, "no reads", transform=ax.transAxes, ha="center", va="center")
        return
    clipped = sr_values.clip(lower=_SR_BIN_EDGES[0], upper=_SR_BIN_EDGES[-1])
    counts, _ = np.histogram(clipped, bins=_SR_BIN_EDGES)
    percent_per_bin = 100.0 * counts / n
    centers = 0.5 * (_SR_BIN_EDGES[:-1] + _SR_BIN_EDGES[1:])
    ax.plot(centers, percent_per_bin, color=color, linewidth=2)
    ax.set_xlim(_SR_BIN_EDGES[0], _SR_BIN_EDGES[-1])
    for x in _SR_THRESHOLD_LINES:
        ax.axvline(x, color="xkcd:dark grey", linestyle="--", linewidth=1.2)


def plot_sr_histogram(
    df_reads: pd.DataFrame,
    title: str = "",
    output_filename: str = None,
    ax: plt.Axes = None,
) -> plt.Axes:
    """
    Plot the overall strand-ratio histogram across all reads. Bins are 0.01 wide and the
    y-axis is a percentage of total reads. Reads with sr outside [0, 1] are clipped to the
    edge bins so they remain visible. Two dashed guide lines at 0.2 and 0.8 mark the
    thresholds used by the Solaris-2 ``--compare`` cascade.

    Parameters
    ----------
    df_reads : pd.DataFrame
        Per-read tag dataframe from :func:`read_tags_from_subsampled_sam`.
    title : str, optional
        plot title.
    output_filename : str, optional
        if provided, save the plot.
    ax : matplotlib.axes.Axes, optional
        axes to plot on.
    """
    set_pyplot_defaults()
    if ax is None:
        plt.figure(figsize=(12, 4))
        ax = plt.gca()
    else:
        plt.sca(ax)
    sr_values = df_reads[SR_TAG].dropna()
    _plot_sr_hist_on_ax(ax, sr_values, "xkcd:royal blue")
    ax.set_xlabel(STRAND_RATIO_AXIS_LABEL, fontsize=_SR_AXIS_LABEL_FONTSIZE)
    ax.set_ylabel("Frequency (%)", fontsize=_SR_AXIS_LABEL_FONTSIZE)
    title_handle = plt.title(title, fontsize=_SR_TITLE_FONTSIZE)
    if output_filename is not None:
        if not output_filename.endswith(".png"):
            output_filename += ".png"
        plt.savefig(
            output_filename,
            facecolor="w",
            dpi=300,
            bbox_inches="tight",
            bbox_extra_artists=[title_handle],
        )
    return ax


def plot_sr_by_et(
    df_reads: pd.DataFrame,
    title: str = "",
    output_filename: str = None,
) -> plt.Figure:
    """
    Plot strand-ratio histograms faceted by the end-loop category, as a vertically stacked
    3x1 grid (one panel per category: MIXED / PLUS / MINUS). Values are a percentage of
    reads within each panel. Restricted to reads whose read end was reached. UNDETERMINED
    reads are excluded — at this point in the pipeline they're effectively never present
    and leaving the panel in adds noise. Reads with sr outside [0, 1] are clipped
    (np.clip-style) so they remain visible.

    Parameters
    ----------
    df_reads : pd.DataFrame
        Per-read tag dataframe from :func:`read_tags_from_subsampled_sam`.
    title : str, optional
        plot title.
    output_filename : str, optional
        if provided, save the plot.
    """
    set_pyplot_defaults()
    # Use the filled strand_ratio_category_end column so reads whose end was reached but
    # whose et tag was missing show up under UNDETERMINED instead of being silently dropped.
    # UNDETERMINED reads are excluded from the panels (the reviewer asked for it, and in
    # practice end-reached reads with UNDETERMINED end-tag are rare).
    category_col = HistogramColumnNames.STRAND_RATIO_CATEGORY_END.value
    df_endreached = df_reads[df_reads[TM_TAG].str.contains("A", na=False)]
    et_categories = [
        PpmseqCategories.MIXED.value,
        PpmseqCategories.PLUS.value,
        PpmseqCategories.MINUS.value,
    ]
    # Vertical stack: each panel the same size as the overall plot (width 12, height 4).
    fig, axs = plt.subplots(len(et_categories), 1, figsize=(12, 4 * len(et_categories)), sharex=True)
    for ax, et_val in zip(axs, et_categories, strict=True):
        subset = df_endreached[df_endreached[category_col] == et_val]
        sr_values = subset[SR_TAG].dropna()
        _plot_sr_hist_on_ax(ax, sr_values, _SR_CATEGORY_COLORS[et_val])
        ax.set_title(f"et={et_val}", fontsize=_SR_TITLE_FONTSIZE)
        ax.set_ylabel("Frequency (%)", fontsize=_SR_AXIS_LABEL_FONTSIZE)
    axs[-1].set_xlabel(STRAND_RATIO_AXIS_LABEL, fontsize=_SR_AXIS_LABEL_FONTSIZE)
    title_handle = fig.suptitle(title, fontsize=_SR_TITLE_FONTSIZE)
    fig.tight_layout()
    if output_filename is not None:
        if not output_filename.endswith(".png"):
            output_filename += ".png"
        fig.savefig(
            output_filename,
            facecolor="w",
            dpi=300,
            bbox_inches="tight",
            bbox_extra_artists=[title_handle],
        )
    return fig


def plot_read_length_overall(
    df_reads: pd.DataFrame,
    title: str = "",
    output_filename: str = None,
    ax: plt.Axes = None,
) -> plt.Axes:
    """
    Plot the per-read read-length distribution as two lines on a single axes:
    one for aligned reads, one for unaligned reads. Each line is normalized to 1
    within its own group so the two can be read as PDFs of independent populations
    rather than fractions of the combined total.

    The legend shows each group's share of the subsampled population plus its median
    length, so the reader can tell at a glance whether the aligned vs unaligned split
    is extreme (e.g. aligned 99%, unaligned 1%) and whether their length distributions
    differ.

    Parameters
    ----------
    df_reads : pd.DataFrame
        Per-read tag dataframe from :func:`read_tags_from_subsampled_sam`. Must carry
        ``read_length`` and ``is_aligned`` columns.
    title : str, optional
        plot title.
    output_filename : str, optional
        if provided, save the plot.
    ax : matplotlib.axes.Axes, optional
        axes to plot on.
    """
    set_pyplot_defaults()
    if ax is None:
        plt.figure(figsize=(12, 4))
        ax = plt.gca()
    else:
        plt.sca(ax)

    lengths_all = df_reads["read_length"].dropna()
    n_total = max(len(lengths_all), 1)
    x_max = int(np.ceil(lengths_all.quantile(0.995))) if len(lengths_all) else 1
    x_max = max(x_max, 10)
    # 1 bp bins centered on integer read lengths so centers are N (not N + 0.5) and
    # each bin holds exactly one read-length value (no aliasing / zig-zag).
    bin_edges = np.arange(-0.5, x_max + 0.5, 1.0)
    centers = 0.5 * (bin_edges[:-1] + bin_edges[1:])

    groups = [
        ("Aligned", df_reads[df_reads["is_aligned"]], "xkcd:royal blue", "-"),
        ("Unaligned", df_reads[~df_reads["is_aligned"]], "xkcd:red orange", "--"),
    ]
    handles_drawn = False
    for label, subset, color, linestyle in groups:
        lengths = subset["read_length"].dropna()
        n = len(lengths)
        if n == 0:
            continue
        clipped = lengths.clip(lower=0, upper=x_max)
        counts, _ = np.histogram(clipped, bins=bin_edges)
        # Independently-normalized PDF per group (fraction of the group, not of the total).
        pdf = counts / n
        pct_of_total = 100.0 * n / n_total
        median = int(lengths.median())
        ax.plot(
            centers,
            pdf,
            color=color,
            linestyle=linestyle,
            linewidth=2,
            label=f"{label} ({pct_of_total:.1f}%), median={median} bp",
        )
        handles_drawn = True
    if handles_drawn:
        ax.legend(loc="upper right", fontsize=12, framealpha=0.95)
    ax.set_xlim(0, x_max)
    ax.set_xlabel("Read length (bp)", fontsize=_SR_AXIS_LABEL_FONTSIZE)
    ax.set_ylabel("Fraction of reads in group", fontsize=_SR_AXIS_LABEL_FONTSIZE)
    title_handle = plt.title(title, fontsize=_SR_TITLE_FONTSIZE)
    if output_filename is not None:
        if not output_filename.endswith(".png"):
            output_filename += ".png"
        plt.savefig(
            output_filename,
            facecolor="w",
            dpi=300,
            bbox_inches="tight",
            bbox_extra_artists=[title_handle],
        )
    return ax


def build_headline_table(statistics_h5: str) -> pd.Series:
    """Load the headline "Key metrics" Series (Section 1 of the report) from the HDF5.

    This is the same Series ``collect_statistics`` writes under ``/stats_shortlist``:

    1. ``PCT_MIXED_start_tag`` — from ``/mixed_reads_stats``
    2. ``PCT_failed_adapter_dimers`` — from ``/failure_codes_metrics`` (when available)
    3. each whitelisted row from ``/sorter_stats`` in ``SORTER_STATS_KEYS_TO_SHOW`` order

    The notebook applies :data:`TABLE1_PPMSEQ_FORMATS` / :data:`SORTER_STATS_FORMATS` to
    the returned Series to format each value with the right units.
    """
    shortlist = pd.read_hdf(statistics_h5, key="stats_shortlist")
    if isinstance(shortlist, pd.DataFrame):
        shortlist = shortlist.iloc[:, 0]
    return shortlist


def flatten_strand_ratio_category(h5_file: str, key: str) -> pd.DataFrame:
    """ "
    convert the 2D dataframe of strand ratio categories to a 1D dataframe that is readable by Papyrus
    """
    df = pd.read_hdf(h5_file, key)  # noqa: PD901
    df["index_col"] = df.index
    df = df.reset_index(drop=True)  # noqa: PD901
    df1 = df.melt(id_vars=["index_col"])
    df1[""] = df1["index_col"] + "_" + df1["variable"]
    df2 = df1[["", "value"]]
    df2 = df2.set_index("")
    df2 = df2.T
    df2 = df2.reset_index(drop=True)
    return df2


def flatten_metrics(h5_file: str, key: str) -> pd.DataFrame:
    """
    Convert a 1D dataframe to a 1D dataframe that is readable by Papyrus
    """
    df = pd.read_hdf(h5_file, key)  # noqa: PD901
    df.index.names = [""]
    df = df.T  # noqa: PD901
    df = df.reset_index(drop=True)  # noqa: PD901
    return df


def convert_h5_to_papyrus_json(h5_file: str, output_json: str) -> str:
    """
    Convert a statistics HDF5 file to a Papyrus JSON file
    """
    with pd.HDFStore(h5_file, "r") as store:
        h5_file_keys = store.keys()

    # flatten strand ratio categories
    strand_ratio_to_convert = [
        "strand_ratio_category_counts",
        "strand_ratio_category_norm",
    ]
    flatten_dfs = {
        key: flatten_strand_ratio_category(h5_file, key) for key in strand_ratio_to_convert if f"/{key}" in h5_file_keys
    }

    # flatten 1D dataframes
    keys_to_convert = [
        "stats_shortlist",
        "mixed_reads_stats",
        "sorter_stats",
        "strand_ratio_category_consensus",
    ]
    flatten_dfs.update({key: flatten_metrics(h5_file, key) for key in keys_to_convert if f"/{key}" in h5_file_keys})

    # category concordance
    if "/strand_ratio_category_concordance" in h5_file_keys or "strand_ratio_category_concordance" in h5_file_keys:
        df_category_concordance = pd.read_hdf(h5_file, "/strand_ratio_category_concordance")
        df_category_concordance.index = df_category_concordance.index.to_flat_index()
        df_category_concordance = df_category_concordance.to_frame().rename(
            columns={HistogramColumnNames.COUNT_NORM.value: 0}
        )
        df_category_concordance = df_category_concordance.T
        flatten_dfs["category_concordance"] = df_category_concordance

    # wrap all in one json
    root_element = "metrics"
    new_json_dict = {root_element: {}}
    new_json_dict[root_element] = {key: json.loads(df.to_json(orient="table")) for key, df in flatten_dfs.items()}

    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(new_json_dict, f, indent=2)


def ppmseq_qc_analysis(
    adapter_version: str | PpmseqAdapterVersions,
    subsampled_sam: str,
    output_path: str,
    output_basename: str = None,
    sorter_stats_csv: str = None,
    trimmer_failure_codes_csv: str = None,
    generate_report: bool = True,  # noqa: FBT001, FBT002
    keep_temp_visualization_files: bool = False,  # noqa: FBT001, FBT002
    qc_filename_suffix: str = ".ppmSeq.applicationQC",
    extra_info: dict = None,
):
    """
    Run the ppmSeq QC analysis pipeline on the subsampled SAM produced by sorter.

    All per-read QC — including the strand-ratio category plots, the concordance
    heatmap, the sr/sr-by-et histograms, and the aligned-vs-unaligned read-length
    plot — is derived from the SAM. ``adapter_version`` is validated but no longer
    branches any logic; all supported versions share the same SAM-based path. It's
    retained in the signature because existing WDL callers still pass it.

    Parameters
    ----------
    adapter_version : str | PpmseqAdapterVersions
        adapter version; validated but no longer affects QC content.
    subsampled_sam : str
        Path to the sorter-produced subsampled sam, bam, or cram file (requires demux
        --sample-nr-reads=N). Pysam picks the format from the extension.
    output_path : str
        output folder for h5, json, and html.
    output_basename : str, optional
        basename for output files; defaults to the SAM file basename.
    sorter_stats_csv : str, optional
        path to a Sorter stats csv file; whitelisted metrics are appended to the
        Key-metrics table in Section 1 of the report.
    trimmer_failure_codes_csv : str, optional
        path to a Trimmer failure codes csv file. If provided, failure-rate metrics are added.
    generate_report : bool, optional
        if True, generate an html + jupyter report.
    keep_temp_visualization_files : bool, optional
        if True, keep temporary png/ipynb files.
    qc_filename_suffix : str, optional
        suffix for the output statistics file immediately after output_basename.
    extra_info : dict, optional
        Free-form key/value pairs to surface at the top of the HTML report (e.g.
        ``{"version": "1.2.3.4"}``). Rendered as a small table between the sample
        header and the table of contents.
    """
    _assert_adapter_version_supported(adapter_version)
    if not os.path.isfile(subsampled_sam):
        raise FileNotFoundError(f"{subsampled_sam} not found")

    os.makedirs(output_path, exist_ok=True)
    if output_basename is None:
        output_basename = os.path.basename(subsampled_sam)

    output_statistics_h5 = os.path.join(output_path, f"{output_basename}{qc_filename_suffix}.h5")
    output_statistics_json = os.path.join(output_path, f"{output_basename}{qc_filename_suffix}.json")
    output_report_html = Path(output_path) / f"{output_basename}{qc_filename_suffix}.html"
    output_report_ipynb = os.path.join(output_path, f"{output_basename}{qc_filename_suffix}.ipynb")
    output_strand_ratio_category_plot = os.path.join(output_path, f"{output_basename}.strand_ratio_category.png")
    output_strand_ratio_category_concordance_plot = os.path.join(
        output_path, f"{output_basename}.strand_ratio_category_concordance.png"
    )
    output_sr_hist_plot = os.path.join(output_path, f"{output_basename}.sr_hist.png")
    output_sr_by_et_plot = os.path.join(output_path, f"{output_basename}.sr_by_et.png")
    output_read_length_plot = os.path.join(output_path, f"{output_basename}.read_length.png")
    output_visualization_files = [
        output_report_ipynb,
        output_strand_ratio_category_plot,
        output_strand_ratio_category_concordance_plot,
        output_read_length_plot,
    ]

    collect_statistics(
        adapter_version=adapter_version,
        subsampled_sam=subsampled_sam,
        sorter_stats_csv=sorter_stats_csv,
        trimmer_failure_codes_csv=trimmer_failure_codes_csv,
        output_filename=output_statistics_h5,
    )

    df_reads = pd.read_hdf(output_statistics_h5, "subsampled_reads")
    convert_h5_to_papyrus_json(output_statistics_h5, output_statistics_json)
    # Two different semantics here:
    # - any_sr governs whether to generate the sr-only figures (3/4) at all.
    # - all_sr governs whether it is safe to suppress the UNDETERMINED start-axis bar/row
    #   in the category + concordance plots. We only do that when every read has sr —
    #   otherwise some reads could legitimately still have st=UNDETERMINED and we'd hide
    #   real data.
    any_sr = has_sr_tag(df_reads)
    all_sr = all_reads_have_sr_tag(df_reads)

    plot_strand_ratio_category(
        adapter_version,
        df_reads,
        title=f"{output_basename} strand ratio category",
        output_filename=output_strand_ratio_category_plot,
        sr_present=all_sr,
    )
    plot_strand_ratio_category_concordnace(
        adapter_version,
        df_reads,
        title=f"{output_basename} strand ratio category concordance",
        output_filename=output_strand_ratio_category_concordance_plot,
        sr_present=all_sr,
    )
    if any_sr:
        plot_sr_histogram(
            df_reads,
            title=f"{output_basename} strand ratio",
            output_filename=output_sr_hist_plot,
        )
        plot_sr_by_et(
            df_reads,
            title=f"{output_basename} strand ratio by et (end reached)",
            output_filename=output_sr_by_et_plot,
        )
        output_visualization_files.extend([output_sr_hist_plot, output_sr_by_et_plot])
    plot_read_length_overall(
        df_reads,
        title=f"{output_basename} read length",
        output_filename=output_read_length_plot,
    )

    if generate_report:
        template_notebook = BASE_PATH / REPORTS_DIR / "ppmSeq_qc_report.ipynb"
        adapter_value = adapter_version if isinstance(adapter_version, str) else adapter_version.value
        logo_path = BASE_PATH / REPORTS_DIR / "ug_logo.b64"
        illustration_path = BASE_PATH / REPORTS_DIR / "ppmSeq_v1_illustration.png"
        parameters = {
            "sample_name": output_basename,
            # The notebook still validates that adapter_version is supported so we keep
            # passing it through, but the report itself never displays it.
            "adapter_version": adapter_value,
            "statistics_h5": output_statistics_h5,
            "strand_ratio_category_png": output_strand_ratio_category_plot,
            "strand_ratio_category_concordance_png": output_strand_ratio_category_concordance_plot,
            # When sr is absent the sr-dependent sections are dropped from the report.
            # Passing None here signals the notebook to skip them.
            "sr_hist_png": output_sr_hist_plot if any_sr else None,
            "sr_by_et_png": output_sr_by_et_plot if any_sr else None,
            "read_length_png": output_read_length_plot,
            "logo_file": str(logo_path),
            "illustration_file": str(illustration_path),
            "trimmer_failure_codes_csv": trimmer_failure_codes_csv,
            "sorter_stats_csv": sorter_stats_csv,
            "extra_info": dict(extra_info) if extra_info else {},
        }

        if not keep_temp_visualization_files:
            tmp_files = [Path(file) for file in output_visualization_files]
        else:
            tmp_files = None

        generate_report_func(
            template_notebook_path=template_notebook,
            parameters=parameters,
            output_report_html_path=output_report_html,
            tmp_files=tmp_files,
        )
