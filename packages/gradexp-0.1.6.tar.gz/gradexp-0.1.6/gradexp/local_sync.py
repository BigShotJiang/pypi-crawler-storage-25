import base64
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path

import click
import requests

from . import auth


SYNC_STATE_FILENAME = "remote-sync-state.json"
SYNC_STATE_VERSION = 1
DEFAULT_SYNC_INTERVAL_S = 5.0
DEFAULT_SYNC_BATCH_SIZE = 128
DEFAULT_SYNC_MAX_BATCH_BYTES = 5 * 1024 * 1024


@dataclass
class SyncSummary:
    store_available: bool = True
    runs_created: int = 0
    tensors_created: int = 0
    step_batches_uploaded: int = 0
    steps_uploaded: int = 0
    bytes_uploaded: int = 0
    statuses_updated: int = 0

    def changed(self):
        return any(
            (
                self.runs_created,
                self.tensors_created,
                self.step_batches_uploaded,
                self.steps_uploaded,
                self.bytes_uploaded,
                self.statuses_updated,
            )
        )


class HostedSyncClient:
    def __init__(self, api_key, api_base_url=None, session=None):
        self.api_key = api_key
        self.api_base_url = (api_base_url or auth.get_api_base_url(prefer_local=False)).rstrip("/")
        self._session = session or requests.Session()

    def get_remote_user(self):
        response = self._session.get(self._url("/api/v1/me"), headers=self._headers(), timeout=30)
        response.raise_for_status()
        return response.json()

    def create_run(self, project_name, run_name):
        current_run_name = run_name
        while True:
            response = self._session.post(
                self._url("/api/v1/runs"),
                headers=self._headers(),
                json={"project_name": project_name, "run_name": current_run_name},
                timeout=30,
            )

            if response.status_code == 409:
                current_run_name = _next_run_name(current_run_name, response)
                continue

            response.raise_for_status()
            payload = response.json()
            return {
                "project_id": payload.get("project_id"),
                "run_id": payload.get("run_id"),
                "run_name": current_run_name,
            }

    def update_run_status(self, run_id, status):
        response = self._session.patch(
            self._url(f"/api/v1/runs/{run_id}"),
            headers=self._headers(),
            json={"status": status},
            timeout=30,
        )
        response.raise_for_status()

    def create_tensor(self, run_id, tensor):
        payload = {
            "name": str(tensor.get("name") or ""),
            "dtype": str(tensor.get("dtype") or ""),
            "shape": [int(value) for value in (tensor.get("shape") or [])],
            "dimension_labels": list(tensor.get("dimensionLabels") or []),
        }
        response = self._session.post(
            self._url(f"/api/v1/runs/{run_id}/tensors"),
            headers=self._headers(),
            json=payload,
            timeout=30,
        )
        response.raise_for_status()
        return response.json()

    def upload_tensor_steps(self, tensor_id, steps):
        payload = {
            "steps": [
                {
                    "step": int(item["step"]),
                    "value": base64.b64encode(item["value"]).decode("ascii"),
                }
                for item in steps
            ]
        }

        try:
            response = self._session.post(
                self._url(f"/api/v1/tensors/{tensor_id}/steps"),
                headers=self._headers(),
                json=payload,
                timeout=60,
            )
            response.raise_for_status()
        except requests.exceptions.HTTPError as error:
            if error.response.status_code == 413 and len(steps) > 1:
                midpoint = len(steps) // 2
                left_count, left_bytes = self.upload_tensor_steps(tensor_id, steps[:midpoint])
                right_count, right_bytes = self.upload_tensor_steps(tensor_id, steps[midpoint:])
                return left_count + right_count, left_bytes + right_bytes
            raise

        return len(steps), sum(len(item["value"]) for item in steps)

    def _headers(self):
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _url(self, path):
        normalized_path = path if path.startswith("/") else f"/{path}"
        return f"{self.api_base_url}{normalized_path}"


def run_local_sync(data_dir=None, once=False, interval=DEFAULT_SYNC_INTERVAL_S):
    resolved_data_dir = Path(data_dir).expanduser() if data_dir else auth.get_local_data_dir()
    resolved_data_dir.mkdir(parents=True, exist_ok=True)

    sync_client, remote_user = _build_hosted_sync_client()
    remote_user_label = _remote_user_label(remote_user)

    if once:
        try:
            summary = sync_local_data_once(resolved_data_dir, sync_client, remote_user)
        except Exception as error:
            raise click.ClickException(str(error)) from error
        _report_sync_cycle(summary, resolved_data_dir, remote_user_label, is_watch=False)
        return summary

    click.echo(
        f"Syncing local data from {resolved_data_dir} to {sync_client.api_base_url} for {remote_user_label}. Press Ctrl+C to stop."
    )
    missing_store_reported = False
    try:
        while True:
            try:
                summary = sync_local_data_once(resolved_data_dir, sync_client, remote_user)
                if not summary.store_available:
                    if not missing_store_reported:
                        click.echo(f"Waiting for local data in {resolved_data_dir}")
                        missing_store_reported = True
                else:
                    missing_store_reported = False
                    _report_sync_cycle(summary, resolved_data_dir, remote_user_label, is_watch=True)
            except Exception as error:
                click.echo(f"Sync error: {error}")
            time.sleep(interval)
    except KeyboardInterrupt:
        click.echo("Stopping local sync.")
        return None


def sync_local_data_once(data_dir, sync_client, remote_user):
    resolved_data_dir = Path(data_dir).expanduser()
    local_store = _load_local_store(resolved_data_dir)
    if local_store is None:
        return SyncSummary(store_available=False)

    sync_state = _load_sync_state(resolved_data_dir)
    account_state = _get_account_state(sync_state, sync_client.api_base_url, remote_user)
    summary = SyncSummary()

    projects_by_id = {
        str(project["projectId"]): project
        for project in local_store.get("projects", [])
        if isinstance(project, dict) and project.get("projectId")
    }
    tensors_by_run = {}
    for tensor in local_store.get("tensors", []):
        if not isinstance(tensor, dict):
            continue
        run_id = str(tensor.get("runId") or "")
        if not run_id:
            continue
        tensors_by_run.setdefault(run_id, []).append(tensor)

    runs = [
        run
        for run in local_store.get("runs", [])
        if isinstance(run, dict) and run.get("runId") and run.get("projectId") in projects_by_id
    ]
    runs.sort(key=lambda item: str(item.get("createdAt") or ""))

    state_dirty = False
    for run in runs:
        local_run_id = str(run["runId"])
        project = projects_by_id[str(run["projectId"])]
        run_state = account_state["runs"].setdefault(local_run_id, {})

        if not run_state.get("remote_run_id"):
            created_run = sync_client.create_run(str(project.get("name") or "default"), str(run.get("name") or "run"))
            run_state.update(
                {
                    "remote_project_id": created_run.get("project_id"),
                    "remote_run_id": created_run.get("run_id"),
                    "remote_run_name": created_run.get("run_name"),
                    "last_synced_status": "active",
                }
            )
            summary.runs_created += 1
            state_dirty = True
            _save_sync_state(resolved_data_dir, sync_state)

        for tensor in sorted(tensors_by_run.get(local_run_id, []), key=lambda item: str(item.get("createdAt") or "")):
            local_tensor_id = str(tensor.get("tensorId") or "")
            if not local_tensor_id:
                continue

            tensor_state = account_state["tensors"].setdefault(local_tensor_id, {"last_synced_step": -1})
            if not tensor_state.get("remote_tensor_id"):
                created_tensor = sync_client.create_tensor(run_state["remote_run_id"], tensor)
                tensor_state["remote_tensor_id"] = created_tensor.get("tensor_id")
                summary.tensors_created += 1
                state_dirty = True
                _save_sync_state(resolved_data_dir, sync_state)

            for batch in _iter_pending_step_batches(resolved_data_dir, tensor, tensor_state):
                uploaded_steps, uploaded_bytes = sync_client.upload_tensor_steps(tensor_state["remote_tensor_id"], batch)
                tensor_state["last_synced_step"] = int(batch[-1]["step"])
                summary.step_batches_uploaded += 1
                summary.steps_uploaded += uploaded_steps
                summary.bytes_uploaded += uploaded_bytes
                state_dirty = True
                _save_sync_state(resolved_data_dir, sync_state)

        local_status = str(run.get("status") or "active")
        if local_status != str(run_state.get("last_synced_status") or "active"):
            sync_client.update_run_status(run_state["remote_run_id"], local_status)
            run_state["last_synced_status"] = local_status
            summary.statuses_updated += 1
            state_dirty = True
            _save_sync_state(resolved_data_dir, sync_state)

    if state_dirty:
        _save_sync_state(resolved_data_dir, sync_state)
    return summary


def _build_hosted_sync_client():
    api_base_url = auth.get_api_base_url(prefer_local=False)
    candidate_tokens = []

    env_token = os.getenv("GRADEXP_API_KEY")
    if env_token:
        candidate_tokens.append(env_token)

    saved_token = auth.load_saved_token()
    if saved_token and saved_token not in candidate_tokens:
        candidate_tokens.append(saved_token)

    if not candidate_tokens:
        raise click.ClickException("No hosted API key found. Run `gradexp login` to sync local data.")

    last_error = None
    for token in candidate_tokens:
        client = HostedSyncClient(token, api_base_url=api_base_url)
        try:
            return client, client.get_remote_user()
        except requests.exceptions.HTTPError as error:
            last_error = error
            if error.response is not None and error.response.status_code == 401:
                continue
            raise click.ClickException(f"Hosted sync failed: {error}") from error
        except requests.exceptions.RequestException as error:
            raise click.ClickException(f"Hosted sync failed: {error}") from error

    raise click.ClickException(
        "Hosted authentication failed. Run `gradexp login` to sync local data."
    ) from last_error


def _load_local_store(data_dir):
    state_path = Path(data_dir) / "store.json"
    if not state_path.exists():
        return None

    try:
        payload = json.loads(state_path.read_text())
    except json.JSONDecodeError as error:
        raise RuntimeError(f"Could not read local store from {state_path}: {error}") from error

    if not isinstance(payload, dict):
        raise RuntimeError(f"Local store at {state_path} is not a JSON object.")
    return payload


def _sync_state_path(data_dir):
    return Path(data_dir) / SYNC_STATE_FILENAME


def _load_sync_state(data_dir):
    state_path = _sync_state_path(data_dir)
    if not state_path.exists():
        return {"version": SYNC_STATE_VERSION, "accounts": {}}

    try:
        payload = json.loads(state_path.read_text())
    except json.JSONDecodeError:
        return {"version": SYNC_STATE_VERSION, "accounts": {}}

    if not isinstance(payload, dict):
        return {"version": SYNC_STATE_VERSION, "accounts": {}}
    payload.setdefault("version", SYNC_STATE_VERSION)
    payload.setdefault("accounts", {})
    if not isinstance(payload["accounts"], dict):
        payload["accounts"] = {}
    return payload


def _save_sync_state(data_dir, sync_state):
    state_path = _sync_state_path(data_dir)
    tmp_path = state_path.with_suffix(".tmp")
    tmp_path.write_text(json.dumps(sync_state, indent=2))
    tmp_path.replace(state_path)


def _get_account_state(sync_state, api_base_url, remote_user):
    remote_user_id = _remote_user_id(remote_user)
    account_key = f"{api_base_url}|{remote_user_id}"
    account_state = sync_state["accounts"].setdefault(
        account_key,
        {
            "remote_api_base_url": api_base_url,
            "remote_user_id": remote_user_id,
            "runs": {},
            "tensors": {},
        },
    )
    account_state.setdefault("runs", {})
    account_state.setdefault("tensors", {})
    return account_state


def _remote_user_id(remote_user):
    remote_user_id = remote_user.get("id") or remote_user.get("userId") or remote_user.get("username")
    if not remote_user_id:
        raise RuntimeError("Hosted sync could not determine the remote user ID.")
    return str(remote_user_id)


def _remote_user_label(remote_user):
    return str(remote_user.get("username") or remote_user.get("id") or "your hosted account")


def _iter_pending_step_batches(data_dir, tensor, tensor_state):
    tensor_id = str(tensor.get("tensorId") or "")
    if not tensor_id:
        return

    last_synced_step = int(tensor_state.get("last_synced_step", -1))
    sorted_steps = sorted(int(step) for step in (tensor.get("steps") or []))

    batch = []
    batch_bytes = 0
    for step in sorted_steps:
        if step <= last_synced_step:
            continue

        step_path = Path(data_dir) / "blobs" / tensor_id / f"{step}.bin"
        if not step_path.exists():
            raise RuntimeError(f"Missing local tensor step payload: {step_path}")

        value = step_path.read_bytes()
        if batch and (
            len(batch) >= DEFAULT_SYNC_BATCH_SIZE
            or batch_bytes + len(value) > DEFAULT_SYNC_MAX_BATCH_BYTES
        ):
            yield batch
            batch = []
            batch_bytes = 0

        batch.append({"step": step, "value": value})
        batch_bytes += len(value)

    if batch:
        yield batch


def _next_run_name(current_run_name, response):
    try:
        payload = response.json()
    except ValueError:
        payload = {}

    suggested_name = payload.get("suggested_name")
    if suggested_name:
        return str(suggested_name)

    if "-" in current_run_name and current_run_name.rsplit("-", 1)[1].isdigit():
        base_name, suffix = current_run_name.rsplit("-", 1)
        return f"{base_name}-{int(suffix) + 1}"
    return f"{current_run_name}-2"


def _report_sync_cycle(summary, data_dir, remote_user_label, is_watch):
    if not summary.store_available:
        if not is_watch:
            click.echo(f"No local data found in {data_dir}")
        return

    if summary.changed():
        click.echo(
            "Synced local data for "
            f"{remote_user_label}: {summary.runs_created} runs, "
            f"{summary.tensors_created} tensors, {summary.steps_uploaded} steps "
            f"in {summary.step_batches_uploaded} batches, "
            f"{summary.statuses_updated} status updates."
        )
        return

    if not is_watch:
        click.echo(f"Local data in {data_dir} is already synced.")
