import os
import sys
import signal
import atexit
import base64
import json
import time
import threading
import queue
import requests
import numpy as np

from . import auth

# Calm red: \033[38;5;174m
# Reset: \033[0m
GRADEXP_PREFIX = "\033[38;5;174mgradexp\033[0m: "

def _term_log(message, end="\n"):
    """
    Prints a message with a colored 'gradexp:' prefix.
    """
    # Handle multi-line messages or messages starting with newline
    if isinstance(message, str) and message.startswith("\n"):
        print(f"\n{GRADEXP_PREFIX}{message[1:]}", end=end)
    else:
        print(f"{GRADEXP_PREFIX}{message}", end=end)

class Client:
    def __init__(self):
        self.api_key = None
        self.run_id = None
        self.project_id = None
        self._api_base_url = None
        self._web_base_url = None
        self.tensors = {} # {name: {"id": uuid, "step": 0}}
        self._tensors_lock = threading.Lock()  # Protects self.tensors
        self.active = False
        self._session = requests.Session()
        self._upload_queue = queue.Queue()
        self._batch_queue = queue.Queue()
        self._stop_event = threading.Event()
        self._batcher_thread = None
        self._uploader_threads = []
        self._interrupted = False
        self._original_sigint_handler = None
        self._original_sigterm_handler = None
        self._local_backend_status = None
        self._local_runtime_status_emitted = False

        # Progress tracking
        self._progress_lock = threading.Lock()
        self._bytes_uploaded = 0
        self._tensors_uploaded = 0
        self._total_tensors_queued = 0
        self._upload_start_time = None

    def _get_runtime_api_base_url(self):
        return (self._api_base_url or auth.get_api_base_url()).rstrip("/")

    def _get_runtime_web_base_url(self):
        return (self._web_base_url or auth.get_web_base_url()).rstrip("/")

    def _build_api_url(self, path):
        normalized_path = path if path.startswith("/") else f"/{path}"
        return f"{self._get_runtime_api_base_url()}{normalized_path}"

    def _get_upload_config(self):
        def _env_int(key, default):
            val = os.getenv(key)
            if val is None or val == "":
                return default
            try:
                return int(val)
            except ValueError:
                return default

        def _env_float(key, default):
            val = os.getenv(key)
            if val is None or val == "":
                return default
            try:
                return float(val)
            except ValueError:
                return default

        def _env_bool(key, default=False):
            val = os.getenv(key)
            if val is None or val == "":
                return default
            return val.strip().lower() in ("1", "true", "yes", "y", "on")

        return {
            # Hard caps
            "batch_size": _env_int("GRADEXP_BATCH_SIZE", 1000),
            "max_batch_bytes": _env_int("GRADEXP_MAX_BATCH_BYTES", 5 * 1024 * 1024),
            # Flush heuristics
            "idle_flush_s": _env_float("GRADEXP_BATCH_IDLE_FLUSH_S", 2.0),
            "max_batch_age_s": _env_float("GRADEXP_BATCH_MAX_AGE_S", 15.0),
            "min_flush_steps": _env_int("GRADEXP_BATCH_MIN_FLUSH_STEPS", 8),
            "min_flush_bytes": _env_int("GRADEXP_BATCH_MIN_FLUSH_BYTES", 64 * 1024),
            # Debug/transport
            "debug_upload": _env_bool("GRADEXP_DEBUG_UPLOAD", default=False),
            "gzip_upload": _env_bool("GRADEXP_GZIP_UPLOAD", default=False),
            "gzip_level": _env_int("GRADEXP_GZIP_LEVEL", 1),
            "upload_workers": _env_int("GRADEXP_UPLOAD_WORKERS", 1),
        }

    def _get_local_backend_status(self):
        if self._local_backend_status is not None:
            return self._local_backend_status

        api_base_url = self._get_runtime_api_base_url()
        if not (
            auth.is_loopback_url(api_base_url)
            or auth.is_loopback_url(self._get_runtime_web_base_url())
        ):
            self._local_backend_status = False
            return None

        local_backend_status = {
            "api_base_url": api_base_url,
            "data_dir": str(auth.get_local_data_dir()),
        }

        try:
            response = self._session.get(self._build_api_url("/version"), timeout=1.0)
            response.raise_for_status()
            payload = response.json()
            data_dir = payload.get("data_dir")
            if isinstance(data_dir, str) and data_dir.strip():
                local_backend_status["data_dir"] = data_dir.strip()
        except (ValueError, requests.exceptions.RequestException):
            pass

        self._local_backend_status = local_backend_status
        return self._local_backend_status

    def _maybe_log_local_backend_status(self):
        if self._local_runtime_status_emitted:
            return

        local_backend_status = self._get_local_backend_status()
        if not local_backend_status:
            return

        _term_log(
            f"Local backend detected at {local_backend_status['api_base_url']}. Logging to the local store in {local_backend_status['data_dir']}"
        )
        self._local_runtime_status_emitted = True

    def init(self, project_name=None, run_name=None):
        """
        Initialize a new run session.
        """
        # Try to pull from wandb if not provided
        if project_name is None or run_name is None:
            if "wandb" in sys.modules:
                import wandb
                if wandb.run:
                    if project_name is None:
                        project_name = wandb.run.project
                    if run_name is None:
                        run_name = wandb.run.name
                        
        # Fallback to defaults if still None
        if project_name is None:
            project_name = "default"
        if run_name is None:
            run_name = "default-run"

        self._api_base_url = auth.get_api_base_url()
        self._web_base_url = auth.get_web_base_url()
        self.api_key = auth.load_token()
        if not self.api_key:
            raise RuntimeError("Not logged in. Please run 'gradexp login' first.")

        current_run_name = run_name
        while True:
            payload = {
                "project_name": project_name,
                "run_name": current_run_name
            }

            try:
                url = self._build_api_url("/api/v1/runs")
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }
                
                response = self._session.post(url, headers=headers, json=payload)
                response.raise_for_status()
                
                data = response.json()
                self.run_id = data.get("run_id")
                self.project_id = data.get("project_id")
                self.tensors = {}
                self.active = True
                self._local_backend_status = None
                self._local_runtime_status_emitted = False

                self._stop_event.clear()
                cfg = self._get_upload_config()
                workers = max(1, cfg["upload_workers"])
                adapter = requests.adapters.HTTPAdapter(pool_connections=workers * 2, pool_maxsize=workers * 2)
                self._session.mount("https://", adapter)
                self._session.mount("http://", adapter)

                self._uploader_threads = [
                    threading.Thread(target=self._uploader_worker, daemon=True)
                    for _ in range(workers)
                ]
                for t in self._uploader_threads:
                    t.start()
                self._batcher_thread = threading.Thread(target=self._batcher_worker, daemon=True)
                self._batcher_thread.start()

                base_url = self._get_runtime_web_base_url()
                run_url = f"{base_url}/?project={self.project_id}&run={self.run_id}"
                self._maybe_log_local_backend_status()
                _term_log(f"Initialized. See run progress at {run_url}")

                atexit.register(self.finish)

                try:
                    self._original_sigint_handler = signal.getsignal(signal.SIGINT)
                    self._original_sigterm_handler = signal.getsignal(signal.SIGTERM)
                    signal.signal(signal.SIGINT, self._handle_interrupt)
                    signal.signal(signal.SIGTERM, self._handle_interrupt)
                except ValueError:
                    pass

                break # Success

            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 409:
                    try:
                        err_data = e.response.json()
                        if "suggested_name" in err_data:
                            current_run_name = err_data["suggested_name"]
                            continue
                    except Exception:
                        pass
                    
                    if "-" in current_run_name and current_run_name.rsplit("-", 1)[1].isdigit():
                        parts = current_run_name.rsplit("-", 1)
                        base = parts[0]
                        num = int(parts[1]) + 1
                        current_run_name = f"{base}-{num}"
                    else:
                        current_run_name = f"{current_run_name}-2"
                    continue
                
                _term_log(f"Failed to initialize: {e}")
                try:
                    _term_log(f"Backend error message: {e.response.text}")
                except:
                    pass

                if e.response.status_code == 401:
                    _term_log("Authentication failed: Unauthorized. Please run 'gradexp login' to authenticate.")
                    sys.exit(1)
                else:
                    raise
            except requests.exceptions.RequestException as e:
                _term_log(f"Failed to initialize: {e}")
                raise

    def _ensure_tensor_registered(self, name, dtype, shape, dimension_labels=None):
        """
        Ensures a tensor exists on the backend. Returns its ID.
        Thread-safe - called from worker thread.
        """
        with self._tensors_lock:
            if name in self.tensors and self.tensors[name].get("id"):
                return self.tensors[name]["id"]

        try:
            url = self._build_api_url(f"/api/v1/runs/{self.run_id}/tensors")
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "name": name,
                "dtype": dtype,
                "shape": shape
            }
            if dimension_labels:
                payload["dimension_labels"] = dimension_labels
            response = self._session.post(url, headers=headers, json=payload)
            response.raise_for_status()

            data = response.json()
            tensor_id = data.get("tensor_id")
            with self._tensors_lock:
                if name in self.tensors:
                    self.tensors[name]["id"] = tensor_id
                else:
                    self.tensors[name] = {"id": tensor_id, "step": 0}
            return tensor_id
        except Exception as e:
            _term_log(f"Failed to create tensor '{name}': {e}")
            return None

    def log(self, tensor, name="default", dimension_labels=None):
        """
        Upload data for the tensor. Non-blocking - queues data for background upload.

        Args:
            tensor: The tensor data (numpy array, PyTorch tensor, or array-like)
            name: Name for this tensor
            dimension_labels: Optional list of labels for each dimension (e.g., ["batch", "height", "width"])
        """
        if not self.active:
            _term_log("Not initialized. Please call gradexp.init() first.")
            return

        self._maybe_log_local_backend_status()

        # Convert to numpy if needed
        if not isinstance(tensor, np.ndarray):
            # Handle PyTorch tensors
            if hasattr(tensor, 'detach') and hasattr(tensor, 'cpu'):
                try:
                    tensor = tensor.detach().cpu()
                    try:
                        tensor = tensor.numpy()
                    except (TypeError, RuntimeError):
                        # Handle dtypes numpy doesn't support (bfloat16, float8, etc.)
                        tensor = tensor.float().numpy()
                except Exception as e:
                    _term_log(f"Could not convert torch tensor to numpy: {e}")
                    return
            else:
                try:
                    tensor = np.array(tensor)
                except Exception:
                    _term_log("Could not convert input to numpy array.")
                    return

        try:
            # TODO respect tensor dtype here & in backend
            if tensor.dtype != np.float32:
                tensor = tensor.astype(np.float32)

            tensor_bytes = tensor.tobytes()
            dtype_str = str(tensor.dtype)
            shape_list = list(tensor.shape)

            # Get and increment step (thread-safe)
            with self._tensors_lock:
                if name not in self.tensors:
                    self.tensors[name] = {"id": None, "step": 0}
                step_index = self.tensors[name]["step"]
                self.tensors[name]["step"] += 1

            # Enqueue for background upload (in-memory, no file I/O)
            with self._progress_lock:
                self._total_tensors_queued += 1
                # Set upload start time when first tensor is queued (not when first batch uploads)
                if self._upload_start_time is None:
                    self._upload_start_time = time.time()
            self._upload_queue.put({
                "content": tensor_bytes,
                "name": name,
                "dtype": dtype_str,
                "shape": shape_list,
                "step": step_index,
                "dimension_labels": dimension_labels
            })

        except Exception as e:
            _term_log(f"Failed to buffer tensor data: {e}")

    def _update_status(self, status):
        """
        Updates the status of the run.
        Uses PATCH /api/v1/runs/{run_id}
        """
        if not self.run_id or not self.api_key:
            return

        try:
            url = self._build_api_url(f"/api/v1/runs/{self.run_id}")
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            payload = {"status": status}
            response = self._session.patch(url, headers=headers, json=payload)
            response.raise_for_status()
        except Exception as e:
            _term_log(f"Failed to update session status to {status}: {e}")

    def _print_progress(self):
        """
        Prints a progress bar showing upload status and throughput.
        """
        with self._progress_lock:
            uploaded = self._tensors_uploaded
            total = self._total_tensors_queued
            bytes_up = self._bytes_uploaded
            start_time = self._upload_start_time
        
        # Calculate throughput
        if start_time and bytes_up > 0:
            elapsed = time.time() - start_time
            if elapsed > 0:
                mbps = (bytes_up / (1024 * 1024)) / elapsed
            else:
                mbps = 0.0
        else:
            mbps = 0.0
        
        # Build progress bar
        bar_width = 30
        if total > 0:
            filled = int(bar_width * uploaded / total)
        else:
            filled = 0
        bar = "█" * filled + "░" * (bar_width - filled)
        
        sys.stdout.write(f"\r{GRADEXP_PREFIX}[{bar}] {uploaded}/{total} tensors | {mbps:.2f} MB/s ")
        sys.stdout.flush()

    def _handle_interrupt(self, signum, frame):
        """
        Handles SIGINT (Ctrl+C) or SIGTERM.
        """
        if not self._interrupted:
            self._interrupted = True
            q_size = self._upload_queue.qsize()
            
            if q_size == 0:
                _term_log("\nInterrupt received. No pending uploads. Shutting down...")
                self.finish("stopped")
                sys.exit(0)
            else:
                _term_log(f"\nInterrupt received. Waiting for {q_size} pending uploads to complete.")
                _term_log("Press Ctrl+C again to force quit.\n")
                
                # Show progress while waiting for uploads
                try:
                    while not self._upload_queue.empty() or (self._batcher_thread and self._batcher_thread.is_alive()) or any(t.is_alive() for t in self._uploader_threads):
                        if self._tensors_uploaded >= self._total_tensors_queued:
                            break
                        self._print_progress()
                        time.sleep(0.2)
                    self._print_progress()  # Final update
                    print()  # Newline after progress bar
                    self.finish("stopped")
                    sys.exit(0)
                except KeyboardInterrupt:
                    # Second Ctrl+C during progress display - force quit
                    _term_log("\nForce quitting...")
                    self._update_status("stopped")
                    os._exit(1)
        else:
            _term_log("\nForce quitting...")
            # Attempt a quick status update if possible, but don't block
            try:
                # Direct status update attempt to backend, skipping the queue
                # This might fail if the session is already half-closed but worth a try
                self._update_status("stopped")
            except:
                pass
            os._exit(1) # Immediate exit

    def _upload_batch(self, tensor_id, items, retry_on_413=True):
        """
        Upload a batch of steps for a tensor using the batch endpoint.
        If the payload is too large (413), splits into smaller batches and retries.
        """
        if not items:
            return

        url = self._build_api_url(f"/api/v1/tensors/{tensor_id}/steps")
        cfg = self._get_upload_config()
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        total_bytes = sum(len(item["content"]) for item in items)

        t_build0 = time.perf_counter()
        payload = {"steps": []}
        approx_b64_chars = 0
        for item in items:
            raw_len = len(item["content"])
            approx_b64_chars += ((raw_len + 2) // 3) * 4
            payload["steps"].append({
                "step": item["step"],
                "value": base64.b64encode(item["content"]).decode("ascii"),
            })
        t_build1 = time.perf_counter()

        body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        t_json = time.perf_counter()

        if cfg["gzip_upload"]:
            import gzip
            body = gzip.compress(body, compresslevel=max(0, min(9, cfg["gzip_level"])))
            headers["Content-Encoding"] = "gzip"
        t_build2 = time.perf_counter()

        try:
            t_send0 = time.perf_counter()
            response = self._session.post(url, headers=headers, data=body, timeout=60)
            t_send1 = time.perf_counter()
            response.raise_for_status()

            if cfg["debug_upload"]:
                build_ms = (t_build2 - t_build0) * 1000.0
                b64_ms = (t_build1 - t_build0) * 1000.0
                json_ms = (t_json - t_build1) * 1000.0
                send_ms = (t_send1 - t_send0) * 1000.0
                wire_mb = len(body) / (1024 * 1024)
                raw_mb = total_bytes / (1024 * 1024)
                _term_log(
                    f"upload_batch steps={len(items)} raw_mb={raw_mb:.2f} approx_b64_mb={approx_b64_chars/(1024*1024):.2f} "
                    f"wire_mb={wire_mb:.2f} b64_ms={b64_ms:.1f} json_ms={json_ms:.1f} build_ms={build_ms:.1f} send_ms={send_ms:.1f}"
                )

            # Success: update progress
            with self._progress_lock:
                self._bytes_uploaded += total_bytes
                self._tensors_uploaded += len(items)

        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 413 and retry_on_413 and len(items) > 1:
                # Payload too large - split into smaller batches and retry
                mid = len(items) // 2
                _term_log(f"Batch too large ({len(items)} steps, {total_bytes / (1024*1024):.2f} MB), splitting...")
                self._upload_batch(tensor_id, items[:mid], retry_on_413=True)
                self._upload_batch(tensor_id, items[mid:], retry_on_413=True)
            else:
                _term_log(f"Failed to upload batch of {len(items)} steps ({total_bytes / (1024*1024):.2f} MB): {e}")
        except requests.exceptions.RequestException as e:
            _term_log(f"Failed to upload batch of {len(items)} steps ({total_bytes / (1024*1024):.2f} MB): {e}")
        except Exception as e:
            _term_log(f"Unexpected error uploading batch ({total_bytes / (1024*1024):.2f} MB): {e}")

    def _batcher_worker(self):
        """
        Background worker that batches data from the queue.
        Handles lazy tensor registration to avoid blocking the main thread.
        """
        cfg = self._get_upload_config()
        BATCH_SIZE = cfg["batch_size"]
        IDLE_FLUSH_S = cfg["idle_flush_s"]
        MAX_BATCH_AGE_S = cfg["max_batch_age_s"]
        MIN_FLUSH_STEPS = cfg["min_flush_steps"]
        MIN_FLUSH_BYTES = cfg["min_flush_bytes"]
        MAX_BATCH_BYTES = cfg["max_batch_bytes"]

        # {tensor_id: {"items": [...], "bytes": int, "first_ts": float, "last_ts": float}}
        pending = {}
        # Local cache of name -> tensor_id to avoid repeated lookups
        tensor_id_cache = {}

        while True:
            # Check exit condition: stop requested, queue empty, and no pending batches
            if self._stop_event.is_set() and self._upload_queue.empty() and not pending:
                break

            try:
                item = self._upload_queue.get(timeout=0.5)

                name = item["name"]
                step = item["step"]
                content = item["content"]
                dtype = item["dtype"]
                shape = item["shape"]
                dimension_labels = item.get("dimension_labels")

                # Lazy tensor registration - only happens in background thread
                if name not in tensor_id_cache:
                    tensor_id = self._ensure_tensor_registered(name, dtype, shape, dimension_labels)
                    if tensor_id:
                        tensor_id_cache[name] = tensor_id
                    else:
                        # Failed to register tensor, skip this item
                        self._upload_queue.task_done()
                        continue
                else:
                    tensor_id = tensor_id_cache[name]

                now = time.time()
                if tensor_id not in pending:
                    pending[tensor_id] = {"items": [], "bytes": 0, "first_ts": now, "last_ts": now}

                pending[tensor_id]["items"].append({
                    "step": step,
                    "content": content
                })
                pending[tensor_id]["bytes"] += len(content)
                pending[tensor_id]["last_ts"] = now

                self._upload_queue.task_done()

            except queue.Empty:
                pass

            # Determine if we should flush batches
            current_time = time.time()
            is_flushing = self._stop_event.is_set() and self._upload_queue.empty()

            for tensor_id in list(pending.keys()):
                batch_info = pending[tensor_id]
                batch = batch_info["items"]
                batch_bytes = batch_info["bytes"]
                batch_age = current_time - batch_info["first_ts"]
                batch_idle = current_time - batch_info["last_ts"]
                can_flush_small = (len(batch) >= MIN_FLUSH_STEPS) or (batch_bytes >= MIN_FLUSH_BYTES)
                should_upload = (
                    len(batch) >= BATCH_SIZE or
                    batch_bytes >= MAX_BATCH_BYTES or
                    (batch and is_flushing) or
                    (batch and batch_age >= MAX_BATCH_AGE_S) or
                    (batch and batch_idle >= IDLE_FLUSH_S and can_flush_small)
                )
                if should_upload:
                    self._batch_queue.put((tensor_id, batch))
                    del pending[tensor_id]

        for _ in self._uploader_threads:
            self._batch_queue.put(None)

    def _uploader_worker(self):
        """
        Background worker that uploads prepared batches.
        """
        while True:
            item = self._batch_queue.get()
            if item is None:
                self._batch_queue.task_done()
                break
            tensor_id, batch = item
            self._upload_batch(tensor_id, batch)
            self._batch_queue.task_done()

    def finish(self, status="complete"):
        """
        Marks the session as finished and flushes the upload queue.
        """
        if not self.active:
            return

        # Signal the worker to stop after processing remaining items
        self._stop_event.set()
        
        any_alive = False
        if self._batcher_thread and self._batcher_thread.is_alive():
            any_alive = True
        for t in self._uploader_threads:
            if t.is_alive():
                any_alive = True
                break

        if any_alive:
            with self._progress_lock:
                pending = self._total_tensors_queued - self._tensors_uploaded

            if pending > 0:
                _term_log("finishing... Waiting for background uploads to complete.")
                while (self._batcher_thread and self._batcher_thread.is_alive()) or any(t.is_alive() for t in self._uploader_threads):
                    if self._tensors_uploaded >= self._total_tensors_queued:
                        break
                    self._print_progress()
                    time.sleep(0.2)
                self._print_progress()
                print()

            if self._batcher_thread:
                self._batcher_thread.join()
            for t in self._uploader_threads:
                t.join()

        # Update status on backend
        self._update_status(status)

        # Restore signal handlers
        try:
            if self._original_sigint_handler:
                signal.signal(signal.SIGINT, self._original_sigint_handler)
            if self._original_sigterm_handler:
                signal.signal(signal.SIGTERM, self._original_sigterm_handler)
        except ValueError:
            pass

        self._interrupted = False
        self.active = False
        _term_log(f"Session {status}.")

# Singleton instance
_client = Client()

def _excepthook(type, value, traceback):
    if _client.active:
        _client.finish("stopped")
    sys.__excepthook__(type, value, traceback)

def init(project_name=None, run_name=None):
    # Install excepthook if not already installed
    if sys.excepthook is not _excepthook:
        # We might want to chain if there's already a custom one?
        # For simplicity, we just use ours which calls the default __excepthook__.
        # If user has another custom one, this might override it.
        # A safer way is to store the previous one.
        global _original_excepthook
        _original_excepthook = sys.excepthook
        
        def tagged_excepthook(type, value, traceback):
            if _client.active:
                _client.finish("stopped")
            _original_excepthook(type, value, traceback)
            
        sys.excepthook = tagged_excepthook
        
    _client.init(project_name=project_name, run_name=run_name)

def log(tensor, name="default", dimension_labels=None):
    _client.log(tensor, name=name, dimension_labels=dimension_labels)

def finish(status="complete"):
    _client.finish(status)

def _split_layer_string(input_string):
    """Parse layer name into (layer_num, layer_type).

    Finds the first numeric component as the layer number and uses
    the remainder as the layer type. Expands LLaMA w1/w2/w3 shorthand.
    """
    parts = input_string.split('.')

    # Find first numeric part as layer number
    layer_num = 0
    layer_num_idx = -1
    for i, part in enumerate(parts):
        if part.isdigit():
            layer_num = int(part)
            layer_num_idx = i
            break

    # Build layer type from parts after the layer number
    if layer_num_idx >= 0:
        layer_type = '.'.join(parts[layer_num_idx + 1:])
    else:
        layer_type = input_string

    # Expand LLaMA shorthand (no-op for other architectures)
    layer_type = layer_type.replace("w1", "gate_proj").replace("w2", "down_proj").replace("w3", "up_proj")

    return layer_num, layer_type

def log_gradient_stats(model):
    """Log gradient and parameter statistics for a PyTorch model."""
    stats_by_layer_type = {}

    for name, param in model.named_parameters():
        if param.grad is None:
            continue

        layer_num, layer_type = _split_layer_string(name)

        grad_l2_norm = param.grad.norm(2)
        param_l2_norm = param.norm(2)
        param_std_dev = param.std()
        avg_abs_grad = param.grad.abs().mean()

        l2_grad_param_ratio = (grad_l2_norm / param_l2_norm) * 100
        avg_grad_std_ratio = (avg_abs_grad / param_std_dev) * 100

        if layer_type not in stats_by_layer_type:
            stats_by_layer_type[layer_type] = {}

        stats_by_layer_type[layer_type][layer_num] = {
            'grad_l2': grad_l2_norm.item(),
            'param_l2': param_l2_norm.item(),
            'param_std': param_std_dev.item(), 'avg_abs_grad': avg_abs_grad.item(),
            'l2_grad_param_ratio': l2_grad_param_ratio.item(),
            'avg_grad_std_ratio': avg_grad_std_ratio.item(),
        }

    stat_names = ['grad_l2', 'param_l2', 'param_std',
                  'avg_abs_grad', 'l2_grad_param_ratio', 'avg_grad_std_ratio']

    for layer_type, layers_dict in stats_by_layer_type.items():
        layer_nums = sorted(layers_dict.keys())
        for stat_name in stat_names:
            values = [layers_dict[ln][stat_name] for ln in layer_nums]
            _client.log(values, name=f"{layer_type}/{stat_name}", dimension_labels=["Layer", "Step"])
