import sys
import unittest
from unittest.mock import MagicMock, patch
import gradexp.client as client
import gradexp

class TestStatusUpdates(unittest.TestCase):
    def setUp(self):
        # Reset client state
        client._client = client.Client()
        client._client.api_key = "fake_key" # Mock logged in
        client._client.run_id = "fake_run_id"
        client._client._api_base_url = "https://api.test.url"
        client._client.active = True
        # Mock requests
        self.mock_session = MagicMock()
        client._client._session = self.mock_session
        
        # Mock auth.BASE_URL
        self.auth_patcher = patch('gradexp.auth.BASE_URL', "test.url")
        self.auth_patcher.start()

    def tearDown(self):
        self.auth_patcher.stop()

    def test_finish_complete(self):
        client._client.finish() # Default status="complete"
        self.mock_session.patch.assert_called_with(
            "https://api.test.url/api/v1/runs/fake_run_id",
            headers={"Authorization": "Bearer fake_key", "Content-Type": "application/json"},
            json={"status": "complete"},
        )

    def test_finish_stopped(self):
        client._client.finish(status="stopped")
        self.mock_session.patch.assert_called_with(
            "https://api.test.url/api/v1/runs/fake_run_id",
            headers={"Authorization": "Bearer fake_key", "Content-Type": "application/json"},
            json={"status": "stopped"},
        )
        
    def test_excepthook_installed(self):
        # Check if excepthook wraps the original
        original = sys.excepthook
        
        # Force reinstall for test (since init might have been called or not)
        client.init(project_name="test", run_name="test")
        
        self.assertNotEqual(sys.excepthook, original)
        self.assertTrue(hasattr(sys.excepthook, "__code__")) # simple check
        
        # Test that calling it triggers finish("stopped")
        client._client.finish = MagicMock()
        try:
            # We don't want to actually crash, just call the hook
            sys.excepthook(RuntimeError, RuntimeError("test"), None)
        except:
            pass
            
        client._client.finish.assert_called_with("stopped")

if __name__ == '__main__':
    # Need to prevent init from running real network requests during import/setup if possible
    # But init is only called explicitly.
    unittest.main()
