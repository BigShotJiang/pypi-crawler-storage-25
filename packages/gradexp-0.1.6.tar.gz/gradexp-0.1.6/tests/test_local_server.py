import tempfile
import unittest
from unittest.mock import patch

from gradexp.local_server import LocalStore


class TestLocalStoreRunUpdates(unittest.TestCase):
    def test_update_run_refreshes_last_activity_at(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            store = LocalStore(tmp_dir, "gradexp-local-token")
            created_run = store.create_run("project-a", "run-a")
            run_id = created_run["payload"]["run_id"]
            original_run = store._get_run(run_id)
            original_last_activity = original_run["lastActivityAt"]

            with patch("gradexp.local_server._utc_now", return_value="2026-03-24T12:00:00.000Z"):
                result = store.update_run(run_id, {"status": "complete"})

            self.assertEqual(result["status"], 200)
            updated_run = store._get_run(run_id)
            self.assertEqual(updated_run["status"], "complete")
            self.assertEqual(updated_run["lastActivityAt"], "2026-03-24T12:00:00.000Z")
            self.assertNotEqual(updated_run["lastActivityAt"], original_last_activity)
            self.assertEqual(
                store.list_runs("project-a")["lastModified"],
                "2026-03-24T12:00:00.000Z",
            )


if __name__ == "__main__":
    unittest.main()
