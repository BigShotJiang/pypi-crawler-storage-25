import unittest
from unittest.mock import patch, MagicMock
import numpy as np
import sys
import os

# Ensure we can import gradexp from current directory
sys.path.append(os.getcwd())

import gradexp
import gradexp.client as client

class TestGradExp(unittest.TestCase):
    @patch('gradexp.auth.load_token')
    @patch('requests.Session.patch')
    @patch('requests.Session.post')
    def test_full_flow(self, mock_post, mock_patch, mock_load_token):
        client._client = client.Client()

        # Setup mocks
        mock_load_token.return_value = "test_api_key"
        patch_response = MagicMock()
        patch_response.status_code = 200
        patch_response.json.return_value = {"status": "updated"}
        mock_patch.return_value = patch_response
        
        # Mock Init Response (201 Created)
        init_response = MagicMock()
        init_response.status_code = 201
        init_response.json.return_value = {
            "run_id": "run_uuid_123",
            "project_id": "project_uuid_456",
            "name": "test-run",
            "status": "active"
        }
        
        # Mock Upload Response (200 OK)
        upload_response = MagicMock()
        upload_response.status_code = 200
        upload_response.json.return_value = {"status": "success"}
        
        # Configure side_effect to return different responses based on call order or inspection
        # But simpler: just cycle them if we know the order, or make the mock return init first then upload
        # Since we use the same session object, requests.Session.post is called
        mock_post.side_effect = [init_response, upload_response]

        # 1. run gradexp.init()
        gradexp.init(project_name="test-project", run_name="test-run")
        
        # Verify init call
        self.assertEqual(mock_post.call_count, 1)
        init_call_args = mock_post.call_args_list[0]
        self.assertIn('/api/v1/runs', init_call_args[0][0])
        self.assertEqual(init_call_args[1]['headers']['Authorization'], 'Bearer test_api_key')
        
        payload = init_call_args[1]['json']
        self.assertEqual(payload['project_name'], 'test-project')
        self.assertEqual(payload['run_name'], 'test-run')
        
        # Mock Tensor Creation Response (200 OK)
        tensor_response = MagicMock()
        tensor_response.status_code = 200
        tensor_response.json.return_value = {"tensor_id": "tensor_uuid_123"}
        
        # Update side_effect for subsequent calls
        # 2nd call: _ensure_tensor (POST /runs/.../tensors)
        # 3rd call: batch upload (POST /tensors/.../steps)
        mock_post.side_effect = [tensor_response, upload_response]

        # 2. run gradexp.log()
        data = np.random.rand(3, 224, 224).astype(np.float32)
        gradexp.log(data)
        gradexp.finish()

        # Verify calls
        self.assertEqual(mock_post.call_count, 3) 
        
        # Verify tensor creation call
        tensor_call_args = mock_post.call_args_list[1]
        self.assertIn('/api/v1/runs/run_uuid_123/tensors', tensor_call_args[0][0])
        
        # Verify log call
        log_call_args = mock_post.call_args_list[2]
        self.assertIn('/api/v1/tensors/tensor_uuid_123/steps', log_call_args[0][0])
        self.assertIn('data', log_call_args[1])
        self.assertEqual(log_call_args[1]['headers']['Authorization'], 'Bearer test_api_key')

        print("\nTest passed successfully!")

if __name__ == '__main__':
    unittest.main()
