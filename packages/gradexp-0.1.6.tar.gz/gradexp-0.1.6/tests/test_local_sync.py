import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import requests

from gradexp import local_sync


class FakeHostedSyncClient:
    def __init__(self):
        self.api_base_url = "https://api.gradient-explorer.xyz"
        self.created_runs = []
        self.created_tensors = []
        self.uploaded_batches = []
        self.updated_statuses = []

    def create_run(self, project_name, run_name):
        self.created_runs.append((project_name, run_name))
        return {
            "project_id": "remote-project-1",
            "run_id": "remote-run-1",
            "run_name": run_name,
        }

    def create_tensor(self, run_id, tensor):
        tensor_id = f"remote-tensor-{len(self.created_tensors) + 1}"
        self.created_tensors.append((run_id, tensor["name"]))
        return {"tensor_id": tensor_id}

    def upload_tensor_steps(self, tensor_id, steps):
        self.uploaded_batches.append((tensor_id, [item["step"] for item in steps]))
        total_bytes = sum(len(item["value"]) for item in steps)
        return len(steps), total_bytes

    def update_run_status(self, run_id, status):
        self.updated_statuses.append((run_id, status))


class TestLocalSync(unittest.TestCase):
    def test_sync_is_incremental_and_persists_state(self):
        remote_user = {"id": "remote-user-1", "username": "tester"}
        sync_client = FakeHostedSyncClient()

        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            self._write_store(
                data_dir,
                steps=[0, 1],
                run_status="complete",
            )

            first_summary = local_sync.sync_local_data_once(data_dir, sync_client, remote_user)
            self.assertTrue(first_summary.changed())
            self.assertEqual(first_summary.runs_created, 1)
            self.assertEqual(first_summary.tensors_created, 1)
            self.assertEqual(first_summary.steps_uploaded, 2)
            self.assertEqual(first_summary.statuses_updated, 1)

            sync_state = json.loads((data_dir / local_sync.SYNC_STATE_FILENAME).read_text())
            account_state = next(iter(sync_state["accounts"].values()))
            self.assertEqual(account_state["runs"]["local-run-1"]["remote_run_id"], "remote-run-1")
            self.assertEqual(account_state["tensors"]["local-tensor-1"]["last_synced_step"], 1)

            second_summary = local_sync.sync_local_data_once(data_dir, sync_client, remote_user)
            self.assertFalse(second_summary.changed())
            self.assertEqual(len(sync_client.created_runs), 1)
            self.assertEqual(len(sync_client.created_tensors), 1)
            self.assertEqual(len(sync_client.uploaded_batches), 1)
            self.assertEqual(len(sync_client.updated_statuses), 1)

            self._write_store(
                data_dir,
                steps=[0, 1, 2],
                run_status="complete",
            )
            third_summary = local_sync.sync_local_data_once(data_dir, sync_client, remote_user)
            self.assertEqual(third_summary.steps_uploaded, 1)
            self.assertEqual(third_summary.step_batches_uploaded, 1)
            self.assertEqual(sync_client.uploaded_batches[-1], ("remote-tensor-1", [2]))

    def test_build_hosted_sync_client_falls_back_to_saved_token(self):
        def fake_get_remote_user(instance):
            if instance.api_key == "gradexp-local-token":
                response = MagicMock()
                response.status_code = 401
                error = requests.exceptions.HTTPError("unauthorized")
                error.response = response
                raise error
            return {"id": "remote-user-1", "username": "tester"}

        with patch.dict(os.environ, {"GRADEXP_API_KEY": "gradexp-local-token"}, clear=False), \
             patch("gradexp.local_sync.auth.get_api_base_url", return_value="https://api.gradient-explorer.xyz"), \
             patch("gradexp.local_sync.auth.load_saved_token", return_value="saved-remote-token"), \
             patch.object(local_sync.HostedSyncClient, "get_remote_user", new=fake_get_remote_user):
            sync_client, remote_user = local_sync._build_hosted_sync_client()

        self.assertEqual(sync_client.api_key, "saved-remote-token")
        self.assertEqual(remote_user["id"], "remote-user-1")

    def _write_store(self, data_dir, steps, run_status):
        blobs_dir = data_dir / "blobs" / "local-tensor-1"
        blobs_dir.mkdir(parents=True, exist_ok=True)
        for step in steps:
            (blobs_dir / f"{step}.bin").write_bytes(bytes([step + 1, step + 2, step + 3]))

        store = {
            "version": 1,
            "projects": [
                {
                    "projectId": "local-project-1",
                    "userId": "local-user",
                    "name": "project-a",
                    "createdAt": "2026-03-19T10:00:00Z",
                }
            ],
            "runs": [
                {
                    "runId": "local-run-1",
                    "projectId": "local-project-1",
                    "name": "run-a",
                    "status": run_status,
                    "createdAt": "2026-03-19T10:01:00Z",
                    "lastActivityAt": "2026-03-19T10:02:00Z",
                }
            ],
            "tensors": [
                {
                    "tensorId": "local-tensor-1",
                    "runId": "local-run-1",
                    "name": "weights",
                    "dtype": "float32",
                    "shape": [3],
                    "dimensionLabels": [],
                    "createdAt": "2026-03-19T10:01:30Z",
                    "updatedAt": "2026-03-19T10:02:00Z",
                    "stepCount": len(steps),
                    "minStep": min(steps) if steps else None,
                    "maxStep": max(steps) if steps else None,
                    "steps": steps,
                }
            ],
        }
        (data_dir / "store.json").write_text(json.dumps(store, indent=2))


if __name__ == "__main__":
    unittest.main()
