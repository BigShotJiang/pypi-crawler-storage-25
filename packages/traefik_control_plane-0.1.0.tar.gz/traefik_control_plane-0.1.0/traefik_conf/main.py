def main():
    print("Hello from traefik-conf!")


if __name__ == "__main__":
    main()
