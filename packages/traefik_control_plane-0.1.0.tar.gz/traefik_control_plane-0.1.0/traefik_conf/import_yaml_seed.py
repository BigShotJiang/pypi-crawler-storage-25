#!/usr/bin/env -S uv run --script
# /// script
# dependencies = ["psycopg[binary]>=3.2", "PyYAML>=6.0"]
# ///

from __future__ import annotations

import argparse
import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import quote

import psycopg
import yaml
from psycopg.rows import dict_row


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_STATIC_CONFIG = SCRIPT_DIR / "static_conf.yml"
DEFAULT_DYNAMIC_CONFIG = SCRIPT_DIR / "dynamic" / "dynamic_conf.generated.yml"

HOST_CALL_RE = re.compile(r"Host\((.*?)\)")
PATH_PREFIX_CALL_RE = re.compile(r"PathPrefix\((.*?)\)")
QUOTED_VALUE_RE = re.compile(r"`([^`]+)`")
NAME_SANITIZE_RE = re.compile(r"[^A-Za-z0-9._-]+")


def _expand_env_references(value: str) -> str:
    expanded = value
    for _ in range(8):
        next_value = os.path.expandvars(expanded)
        if next_value == expanded:
            break
        expanded = next_value
    return expanded


def default_static_config_path() -> str:
    configured = os.environ.get("TRAEFIK_STATIC_CONFIG_PATH", "").strip()
    if configured:
        return configured
    return str(DEFAULT_STATIC_CONFIG)


def default_dynamic_config_path() -> str:
    runtime_root = os.environ.get("TRAEFIK_RUNTIME_CONFIG_DIR", "").strip()
    if not runtime_root:
        runtime_root = os.environ.get("TRAEFIK_CONTROL_PLANE_CONFIG_DIR", "").strip()
    if runtime_root:
        return str(
            Path(_expand_env_references(runtime_root)).expanduser().resolve()
            / "dynamic"
            / "dynamic_conf.generated.yml"
        )
    return str(DEFAULT_DYNAMIC_CONFIG)


@dataclass
class ImportReport:
    inserted: list[str] = field(default_factory=list)
    reused: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    conflicts: list[str] = field(default_factory=list)
    cleaned: list[str] = field(default_factory=list)

    def note(self, bucket: str, message: str) -> None:
        getattr(self, bucket).append(message)


@dataclass(frozen=True)
class SiteSeed:
    name: str
    fields: dict[str, Any]
    entrypoint_names: list[str]
    middleware_names: list[str]


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Safely seed the Traefik control-plane database from static_conf.yml "
            "and dynamic/dynamic_conf.generated.yml. The importer only writes objects "
            "that can be mapped into the schema without guessing."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--static-config", default=default_static_config_path())
    parser.add_argument("--dynamic-config", default=default_dynamic_config_path())
    parser.add_argument("--db-url", default=os.environ.get("TRAEFIK_DB_URL"))
    parser.add_argument("--db-host", default=os.environ.get("TRAEFIK_DB_HOST", "localhost"))
    parser.add_argument("--db-port", type=int, default=int(os.environ.get("TRAEFIK_DB_PORT", "5432")))
    parser.add_argument("--db-name", default=os.environ.get("TRAEFIK_DB_NAME"))
    parser.add_argument("--db-user", default=os.environ.get("TRAEFIK_DB_USER"))
    parser.add_argument("--db-password", default=os.environ.get("TRAEFIK_DB_PASSWORD"))
    parser.add_argument("--db-sslmode", default=os.environ.get("TRAEFIK_DB_SSLMODE"))
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Persist the imported rows. Without this flag the script runs in dry-run mode and rolls everything back.",
    )
    args = parser.parse_args(argv)
    if not args.db_url and not (args.db_name and args.db_user):
        parser.error(
            "Provide --db-url or set TRAEFIK_DB_URL, or provide "
            "--db-name/--db-user (optionally with --db-password)."
        )
    return args


def discover_dsn(args: argparse.Namespace) -> str:
    if args.db_url:
        return str(args.db_url)
    credentials = quote(str(args.db_user), safe="")
    if args.db_password:
        credentials = f"{credentials}:{quote(str(args.db_password), safe='')}"
    host_part = str(args.db_host)
    if args.db_port:
        host_part = f"{host_part}:{int(args.db_port)}"
    query = f"?sslmode={quote(str(args.db_sslmode), safe='')}" if args.db_sslmode else ""
    return f"postgresql://{credentials}@{host_part}/{quote(str(args.db_name), safe='')}{query}"


def load_yaml_file(path_value: str) -> dict[str, Any]:
    path = Path(_expand_env_references(path_value)).expanduser().resolve()
    with path.open("r", encoding="utf-8") as handle:
        loaded = yaml.safe_load(handle.read()) or {}
    if not isinstance(loaded, dict):
        raise ValueError(f"{path} must contain a top-level mapping/object.")
    return loaded


def json_text(value: Any) -> str | None:
    if value in (None, "", [], {}):
        return None
    return json.dumps(value, indent=2, sort_keys=True)


def sanitize_name(value: str) -> str:
    cleaned = NAME_SANITIZE_RE.sub("-", value.strip())
    candidate = cleaned.strip(".-")
    return candidate or "imported-site"


def uniquify_name(candidate: str, used: set[str]) -> str:
    if candidate not in used:
        used.add(candidate)
        return candidate
    suffix = 2
    while True:
        maybe = f"{candidate}-{suffix}"
        if maybe not in used:
            used.add(maybe)
            return maybe
        suffix += 1


def split_rule_values(pattern: re.Pattern[str], rule: str) -> list[str]:
    match = pattern.search(rule)
    if not match:
        return []
    return [item.strip() for item in QUOTED_VALUE_RE.findall(match.group(1)) if item.strip()]


def extract_hosts(rule: str) -> list[str]:
    return split_rule_values(HOST_CALL_RE, rule)


def extract_path_prefixes(rule: str) -> list[str]:
    return split_rule_values(PATH_PREFIX_CALL_RE, rule)


def parse_static_entrypoints(static_config: dict[str, Any], report: ImportReport) -> list[dict[str, Any]]:
    raw_entrypoints = static_config.get("entryPoints")
    if raw_entrypoints in (None, {}):
        return []
    if not isinstance(raw_entrypoints, dict):
        report.note("skipped", "static.entryPoints: skipped because the section is not a mapping.")
        return []

    rows: list[dict[str, Any]] = []
    for name in sorted(raw_entrypoints):
        raw_value = raw_entrypoints.get(name)
        if not isinstance(raw_value, dict):
            report.note("skipped", f"entrypoint:{name}: skipped because the definition is not an object.")
            continue
        address = str(raw_value.get("address", "")).strip()
        if not address:
            report.note("skipped", f"entrypoint:{name}: skipped because no address is defined.")
            continue
        rows.append(
            {
                "name": str(name),
                "enabled": True,
                "address": address,
                "as_default": bool(raw_value.get("asDefault", False)),
                "forwarded_headers_json": json_text(raw_value.get("forwardedHeaders")),
                "proxy_protocol_json": json_text(raw_value.get("proxyProtocol")),
                "http_options_json": json_text(raw_value.get("http")),
            }
        )
    return rows


def parse_static_cert_resolvers(static_config: dict[str, Any], report: ImportReport) -> list[dict[str, Any]]:
    raw_resolvers = static_config.get("certificatesResolvers")
    if raw_resolvers in (None, {}):
        return []
    if not isinstance(raw_resolvers, dict):
        report.note("skipped", "static.certificatesResolvers: skipped because the section is not a mapping.")
        return []

    rows: list[dict[str, Any]] = []
    for name in sorted(raw_resolvers):
        raw_value = raw_resolvers.get(name)
        if not isinstance(raw_value, dict):
            report.note("skipped", f"cert_resolver:{name}: skipped because the definition is not an object.")
            continue
        acme = raw_value.get("acme")
        if not isinstance(acme, dict):
            report.note("skipped", f"cert_resolver:{name}: skipped because only ACME resolvers are supported.")
            continue

        dns_challenge = acme.get("dnsChallenge") if isinstance(acme.get("dnsChallenge"), dict) else None
        http_challenge = acme.get("httpChallenge") if isinstance(acme.get("httpChallenge"), dict) else None
        tls_challenge = acme.get("tlsChallenge") if isinstance(acme.get("tlsChallenge"), dict) else None
        challenge_names = [
            label
            for label, value in (
                ("dnsChallenge", dns_challenge),
                ("httpChallenge", http_challenge),
                ("tlsChallenge", tls_challenge),
            )
            if value is not None
        ]
        if len(challenge_names) > 1:
            report.note(
                "skipped",
                f"cert_resolver:{name}: skipped because multiple ACME challenge types are configured.",
            )
            continue

        challenge_type = challenge_names[0] if challenge_names else "dnsChallenge"
        provider = None
        http_entrypoint = None
        delay_before_check = None
        resolvers_json = None
        extra_acme = dict(acme)

        email = str(acme.get("email", "")).strip() or None
        storage = str(acme.get("storage", "")).strip() or None
        ca_server = str(acme.get("caServer", "")).strip() or None

        extra_acme.pop("email", None)
        extra_acme.pop("storage", None)
        extra_acme.pop("caServer", None)

        if dns_challenge is not None:
            provider = str(dns_challenge.get("provider", "")).strip() or None
            delay_value = dns_challenge.get("delayBeforeCheck")
            if delay_value not in (None, ""):
                try:
                    delay_before_check = int(delay_value)
                except (TypeError, ValueError):
                    report.note("skipped", f"cert_resolver:{name}: skipped because delayBeforeCheck is not an integer.")
                    continue
            resolvers_json = json_text(dns_challenge.get("resolvers"))
            dns_extra = dict(dns_challenge)
            dns_extra.pop("provider", None)
            dns_extra.pop("delayBeforeCheck", None)
            dns_extra.pop("resolvers", None)
            extra_acme["dnsChallenge"] = dns_extra if dns_extra else None
        elif http_challenge is not None:
            http_entrypoint = str(http_challenge.get("entryPoint", "")).strip() or None
            http_extra = dict(http_challenge)
            http_extra.pop("entryPoint", None)
            extra_acme["httpChallenge"] = http_extra if http_extra else None
        elif tls_challenge is not None:
            tls_extra = dict(tls_challenge)
            extra_acme["tlsChallenge"] = tls_extra if tls_extra else None

        compact_extra = {key: value for key, value in extra_acme.items() if value not in (None, "", [], {})}
        rows.append(
            {
                "name": str(name),
                "enabled": True,
                "email": email,
                "challenge_type": challenge_type,
                "provider": provider,
                "storage": storage,
                "http_challenge_entrypoint": http_entrypoint,
                "delay_before_check": delay_before_check,
                "resolvers_json": resolvers_json,
                "ca_server": ca_server,
                "extra_json": json_text(compact_extra),
            }
        )
    return rows


def parse_dynamic_middlewares(dynamic_config: dict[str, Any], report: ImportReport) -> list[dict[str, Any]]:
    raw_middlewares = (((dynamic_config.get("http") or {}).get("middlewares")) or {})
    if raw_middlewares in (None, {}):
        return []
    if not isinstance(raw_middlewares, dict):
        report.note("skipped", "dynamic.http.middlewares: skipped because the section is not a mapping.")
        return []

    rows: list[dict[str, Any]] = []
    for name in sorted(raw_middlewares):
        raw_value = raw_middlewares.get(name)
        if not isinstance(raw_value, dict) or len(raw_value) != 1:
            report.note("skipped", f"middleware:{name}: skipped because it is not a single-type middleware object.")
            continue
        middleware_type, config = next(iter(raw_value.items()))
        if not isinstance(config, dict):
            report.note("skipped", f"middleware:{name}: skipped because middleware config is not an object.")
            continue
        rows.append(
            {
                "name": str(name),
                "enabled": True,
                "type": str(middleware_type),
                "config_json": json_text(config),
                "tags": None,
            }
        )
    return rows


def parse_dynamic_tls_options(dynamic_config: dict[str, Any], report: ImportReport) -> list[dict[str, Any]]:
    raw_options = (((dynamic_config.get("tls") or {}).get("options")) or {})
    if raw_options in (None, {}):
        return []
    if not isinstance(raw_options, dict):
        report.note("skipped", "dynamic.tls.options: skipped because the section is not a mapping.")
        return []

    rows: list[dict[str, Any]] = []
    for name in sorted(raw_options):
        raw_value = raw_options.get(name)
        if not isinstance(raw_value, dict):
            report.note("skipped", f"tls_option:{name}: skipped because the definition is not an object.")
            continue
        extra = dict(raw_value)
        min_version = str(extra.pop("minVersion", "")).strip() or None
        sni_strict = bool(extra.pop("sniStrict", False))
        cipher_suites = extra.pop("cipherSuites", None)
        curve_preferences = extra.pop("curvePreferences", None)
        client_auth = extra.pop("clientAuth", None)
        rows.append(
            {
                "name": str(name),
                "enabled": True,
                "min_version": min_version,
                "sni_strict": sni_strict,
                "cipher_suites_json": json_text(cipher_suites),
                "curve_preferences_json": json_text(curve_preferences),
                "client_auth_json": json_text(client_auth),
                "extra_json": json_text(extra),
            }
        )
    return rows


def parse_dynamic_servers_transports(dynamic_config: dict[str, Any], report: ImportReport) -> list[dict[str, Any]]:
    raw_transports = ((((dynamic_config.get("http") or {}).get("serversTransports")) or {}))
    if raw_transports in (None, {}):
        return []
    if not isinstance(raw_transports, dict):
        report.note("skipped", "dynamic.http.serversTransports: skipped because the section is not a mapping.")
        return []

    rows: list[dict[str, Any]] = []
    for name in sorted(raw_transports):
        raw_value = raw_transports.get(name)
        if not isinstance(raw_value, dict):
            report.note("skipped", f"servers_transport:{name}: skipped because the definition is not an object.")
            continue
        extra = dict(raw_value)
        server_name = str(extra.pop("serverName", "")).strip() or None
        insecure_skip_verify = bool(extra.pop("insecureSkipVerify", False))
        root_cas = extra.pop("rootCAs", None)
        max_idle = extra.pop("maxIdleConnsPerHost", None)
        forwarding_timeouts = extra.pop("forwardingTimeouts", None)
        if max_idle not in (None, ""):
            try:
                max_idle = int(max_idle)
            except (TypeError, ValueError):
                report.note("skipped", f"servers_transport:{name}: skipped because maxIdleConnsPerHost is not an integer.")
                continue
        else:
            max_idle = None
        rows.append(
            {
                "name": str(name),
                "enabled": True,
                "server_name": server_name,
                "insecure_skip_verify": insecure_skip_verify,
                "root_cas_json": json_text(root_cas),
                "max_idle_conns_per_host": max_idle,
                "forwarding_timeouts_json": json_text(forwarding_timeouts),
                "extra_json": json_text(extra),
            }
        )
    return rows


def parse_router_rule(rule: str) -> tuple[str, str | None, str | None]:
    hosts = extract_hosts(rule)
    if not hosts:
        raise ValueError("rule does not contain a Host() matcher")
    path_prefixes = extract_path_prefixes(rule)
    simple_host_only = bool(re.fullmatch(r"\s*Host\((.*?)\)\s*", rule))
    simple_host_path = bool(re.fullmatch(r"\s*Host\((.*?)\)\s*&&\s*PathPrefix\((.*?)\)\s*", rule))
    if len(hosts) == 1 and len(path_prefixes) <= 1 and (simple_host_only or simple_host_path):
        return hosts[0], (path_prefixes[0] if path_prefixes else None), None
    return hosts[0], None, rule


def build_site_seeds(
    dynamic_config: dict[str, Any],
    *,
    middleware_names: set[str],
    entrypoint_names: set[str],
    cert_resolver_names: set[str],
    tls_option_names: set[str],
    transport_names: set[str],
    report: ImportReport,
) -> list[SiteSeed]:
    http_config = dynamic_config.get("http") or {}
    if not isinstance(http_config, dict):
        report.note("skipped", "dynamic.http: skipped because the section is not a mapping.")
        return []
    routers = http_config.get("routers") or {}
    services = http_config.get("services") or {}
    if not isinstance(routers, dict) or not isinstance(services, dict):
        report.note("skipped", "dynamic.http routers/services: skipped because the section is not a mapping.")
        return []

    used_names: set[str] = set()
    seeds: list[SiteSeed] = []
    for router_name in sorted(routers):
        router = routers.get(router_name)
        if not isinstance(router, dict):
            report.note("skipped", f"site:{router_name}: skipped because router definition is not an object.")
            continue

        service_name = str(router.get("service", "")).strip()
        if not service_name or service_name.endswith("@internal"):
            report.note("skipped", f"site:{router_name}: skipped because the router points to an internal or missing service.")
            continue

        service = services.get(service_name)
        if not isinstance(service, dict):
            report.note("skipped", f"site:{router_name}: skipped because service {service_name} is missing.")
            continue
        if set(service.keys()) != {"loadBalancer"} or not isinstance(service.get("loadBalancer"), dict):
            report.note("skipped", f"site:{router_name}: skipped because only single loadBalancer services are admissible.")
            continue

        load_balancer = dict(service["loadBalancer"])
        servers = load_balancer.get("servers")
        if not isinstance(servers, list) or len(servers) != 1 or not isinstance(servers[0], dict):
            report.note("skipped", f"site:{router_name}: skipped because only exactly one upstream server is admissible.")
            continue
        upstream_url = str(servers[0].get("url", "")).strip()
        if not upstream_url:
            report.note("skipped", f"site:{router_name}: skipped because the single server has no url.")
            continue
        if len(servers[0]) != 1:
            report.note("skipped", f"site:{router_name}: skipped because the server entry contains unsupported fields.")
            continue

        rule = str(router.get("rule", "")).strip()
        if not rule:
            report.note("skipped", f"site:{router_name}: skipped because the router has no rule.")
            continue
        try:
            host, path_prefix, rule_override = parse_router_rule(rule)
        except ValueError as exc:
            report.note("skipped", f"site:{router_name}: skipped because {exc}.")
            continue

        entrypoints = router.get("entryPoints")
        if not isinstance(entrypoints, list) or not entrypoints:
            report.note("skipped", f"site:{router_name}: skipped because the router has no explicit entryPoints list.")
            continue
        resolved_entrypoints = [str(item).strip() for item in entrypoints if str(item).strip()]
        if not resolved_entrypoints or any(name not in entrypoint_names for name in resolved_entrypoints):
            report.note("skipped", f"site:{router_name}: skipped because one or more entrypoints are unavailable in the imported static inventory.")
            continue

        middleware_list = router.get("middlewares") or []
        if middleware_list and not isinstance(middleware_list, list):
            report.note("skipped", f"site:{router_name}: skipped because middlewares is not a list.")
            continue
        resolved_middlewares = [str(item).strip() for item in middleware_list if str(item).strip()]
        if any(name not in middleware_names for name in resolved_middlewares):
            report.note("skipped", f"site:{router_name}: skipped because one or more referenced middlewares are unavailable.")
            continue

        tls_enabled = "tls" in router
        tls_config = router.get("tls") if tls_enabled else None
        if tls_config not in (None, {}) and not isinstance(tls_config, dict):
            report.note("skipped", f"site:{router_name}: skipped because tls is not an object.")
            continue

        cert_resolver_name = None
        tls_option_name = None
        extra_router: dict[str, Any] = {}
        if isinstance(tls_config, dict):
            cert_resolver_name = str(tls_config.get("certResolver", "")).strip() or None
            tls_option_name = str(tls_config.get("options", "")).strip() or None
            if cert_resolver_name and cert_resolver_name not in cert_resolver_names:
                report.note("skipped", f"site:{router_name}: skipped because cert resolver {cert_resolver_name} is unavailable.")
                continue
            if tls_option_name and tls_option_name not in tls_option_names:
                report.note("skipped", f"site:{router_name}: skipped because TLS option {tls_option_name} is unavailable.")
                continue
            extra_tls = dict(tls_config)
            extra_tls.pop("certResolver", None)
            extra_tls.pop("options", None)
            if extra_tls:
                extra_router["tls"] = extra_tls

        extra_service: dict[str, Any] = {}
        pass_host_header = bool(load_balancer.get("passHostHeader", True))
        health_check = load_balancer.get("healthCheck")
        if health_check not in (None, {}) and not isinstance(health_check, dict):
            report.note("skipped", f"site:{router_name}: skipped because healthCheck is not an object.")
            continue
        transport_name = str(load_balancer.get("serversTransport", "")).strip() or None
        if transport_name and transport_name not in transport_names:
            report.note("skipped", f"site:{router_name}: skipped because serversTransport {transport_name} is unavailable.")
            continue

        extra_router_keys = dict(router)
        for key in ("rule", "service", "entryPoints", "middlewares", "priority", "tls"):
            extra_router_keys.pop(key, None)
        if extra_router_keys:
            extra_router.update(extra_router_keys)

        extra_load_balancer = dict(load_balancer)
        for key in ("servers", "passHostHeader", "serversTransport", "healthCheck"):
            extra_load_balancer.pop(key, None)
        if extra_load_balancer:
            extra_service["loadBalancer"] = extra_load_balancer

        base_name = str(router_name)
        if base_name.startswith("site-"):
            base_name = base_name[5:]
        candidate_name = uniquify_name(sanitize_name(base_name), used_names)

        fields: dict[str, Any] = {
            "name": candidate_name,
            "enabled": True,
            "host": host,
            "upstream_url": upstream_url,
            "tls_enabled": tls_enabled,
            "path_prefix": path_prefix,
            "priority": router.get("priority"),
            "pass_host_header": pass_host_header,
            "healthcheck_json": json_text(health_check),
            "rule_override": rule_override,
            "extra_router_json": json_text(extra_router),
            "extra_service_json": json_text(extra_service),
        }
        if cert_resolver_name:
            fields["cert_resolver_name"] = cert_resolver_name
        if tls_option_name:
            fields["tls_option_name"] = tls_option_name
        if transport_name:
            fields["servers_transport_name"] = transport_name

        seeds.append(
            SiteSeed(
                name=candidate_name,
                fields=fields,
                entrypoint_names=resolved_entrypoints,
                middleware_names=resolved_middlewares,
            )
        )

    if dynamic_config.get("tcp"):
        report.note("skipped", "dynamic.tcp: skipped because TCP routing is intentionally out of scope for this importer.")
    if dynamic_config.get("udp"):
        report.note("skipped", "dynamic.udp: skipped because UDP routing is intentionally out of scope for this importer.")
    return seeds


def fetch_existing_row(cur: psycopg.Cursor[Any], table_name: str, name: str) -> dict[str, Any] | None:
    cur.execute(f"SELECT * FROM public.{table_name} WHERE name = %s", (name,))
    row = cur.fetchone()
    return dict(row) if row else None


def compare_fields(existing: dict[str, Any], wanted: dict[str, Any], columns: tuple[str, ...]) -> bool:
    return all(existing.get(column) == wanted.get(column) for column in columns)


def ensure_named_row(
    cur: psycopg.Cursor[Any],
    *,
    table_name: str,
    row: dict[str, Any],
    compare_columns: tuple[str, ...],
    report: ImportReport,
) -> int | None:
    existing = fetch_existing_row(cur, table_name, str(row["name"]))
    if existing is None:
        columns = tuple(row.keys())
        placeholders = ", ".join(["%s"] * len(columns))
        column_sql = ", ".join(columns)
        cur.execute(
            f"INSERT INTO public.{table_name} ({column_sql}) VALUES ({placeholders}) RETURNING id",
            [row[column] for column in columns],
        )
        report.note("inserted", f"{table_name}:{row['name']}")
        inserted = cur.fetchone()
        return int(inserted["id"])

    if compare_fields(existing, row, compare_columns):
        report.note("reused", f"{table_name}:{row['name']}")
        return int(existing["id"])

    report.note("conflicts", f"{table_name}:{row['name']}: skipped because an existing row has different values.")
    return None


def fetch_site_by_name(cur: psycopg.Cursor[Any], name: str) -> dict[str, Any] | None:
    cur.execute("SELECT * FROM public.sites WHERE name = %s", (name,))
    row = cur.fetchone()
    return dict(row) if row else None


def replace_site_links(
    cur: psycopg.Cursor[Any],
    *,
    site_id: int,
    join_table: str,
    foreign_column: str,
    ids: list[int],
) -> None:
    for foreign_id in ids:
        cur.execute(
            f"INSERT INTO public.{join_table} (site, {foreign_column}) VALUES (%s, %s) ON CONFLICT DO NOTHING",
            (site_id, foreign_id),
        )


def ensure_site(
    cur: psycopg.Cursor[Any],
    *,
    seed: SiteSeed,
    cert_resolver_ids: dict[str, int],
    tls_option_ids: dict[str, int],
    transport_ids: dict[str, int],
    entrypoint_ids: dict[str, int],
    middleware_ids: dict[str, int],
    report: ImportReport,
) -> None:
    existing = fetch_site_by_name(cur, seed.name)
    if existing is not None:
        report.note("conflicts", f"sites:{seed.name}: skipped because a site with that name already exists.")
        return

    fields = dict(seed.fields)
    cert_resolver_name = fields.pop("cert_resolver_name", None)
    tls_option_name = fields.pop("tls_option_name", None)
    transport_name = fields.pop("servers_transport_name", None)
    if cert_resolver_name:
        fields["cert_resolver"] = cert_resolver_ids[cert_resolver_name]
    if tls_option_name:
        fields["tls_options"] = tls_option_ids[tls_option_name]
    if transport_name:
        fields["servers_transport"] = transport_ids[transport_name]

    columns = tuple(fields.keys())
    placeholders = ", ".join(["%s"] * len(columns))
    column_sql = ", ".join(columns)
    cur.execute(
        f"INSERT INTO public.sites ({column_sql}) VALUES ({placeholders}) RETURNING id",
        [fields[column] for column in columns],
    )
    inserted = cur.fetchone()
    site_id = int(inserted["id"])
    replace_site_links(
        cur,
        site_id=site_id,
        join_table="site_entrypoints",
        foreign_column="entrypoint",
        ids=[entrypoint_ids[name] for name in seed.entrypoint_names],
    )
    replace_site_links(
        cur,
        site_id=site_id,
        join_table="site_middlewares",
        foreign_column="middleware",
        ids=[middleware_ids[name] for name in seed.middleware_names],
    )
    report.note("inserted", f"sites:{seed.name}")


def cleanup_import_placeholders(cur: psycopg.Cursor[Any], report: ImportReport) -> None:
    cleanup_statements = (
        (
            "entrypoints",
            "notes",
            "notes = 'Imported from static_conf.yml'",
        ),
        (
            "cert_resolvers",
            "notes",
            "notes = 'Imported from static_conf.yml'",
        ),
        (
            "middlewares",
            "description",
            "description = 'Imported from dynamic/dynamic_conf.generated.yml'",
        ),
        (
            "tls_options",
            "notes",
            "notes = 'Imported from dynamic/dynamic_conf.generated.yml'",
        ),
        (
            "servers_transports",
            "notes",
            "notes = 'Imported from dynamic/dynamic_conf.generated.yml'",
        ),
        (
            "sites",
            "notes",
            "notes LIKE 'Imported from dynamic/dynamic_conf.generated.yml router=% service=%'",
        ),
    )
    for table_name, column_name, where_clause in cleanup_statements:
        cur.execute(
            f"""
            UPDATE public.{table_name}
            SET {column_name} = NULL
            WHERE {where_clause}
            RETURNING name
            """
        )
        for row in cur.fetchall():
            report.note("cleaned", f"{table_name}:{row['name']}")


def print_report(report: ImportReport, *, apply: bool) -> None:
    mode = "APPLY" if apply else "DRY-RUN"
    print(f"[{mode}] inserted={len(report.inserted)} reused={len(report.reused)} conflicts={len(report.conflicts)} skipped={len(report.skipped)}")
    for label, items in (
        ("inserted", report.inserted),
        ("reused", report.reused),
        ("cleaned", report.cleaned),
        ("conflicts", report.conflicts),
        ("skipped", report.skipped),
    ):
        if not items:
            continue
        print(f"\n{label.upper()}:")
        for item in items:
            print(f"  - {item}")


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    dsn = discover_dsn(args)
    static_config = load_yaml_file(args.static_config)
    dynamic_config = load_yaml_file(args.dynamic_config)
    report = ImportReport()

    entrypoint_rows = parse_static_entrypoints(static_config, report)
    cert_resolver_rows = parse_static_cert_resolvers(static_config, report)
    middleware_rows = parse_dynamic_middlewares(dynamic_config, report)
    tls_option_rows = parse_dynamic_tls_options(dynamic_config, report)
    transport_rows = parse_dynamic_servers_transports(dynamic_config, report)

    with psycopg.connect(dsn, row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            cleanup_import_placeholders(cur, report)
            entrypoint_ids: dict[str, int] = {}
            for row in entrypoint_rows:
                maybe_id = ensure_named_row(
                    cur,
                    table_name="entrypoints",
                    row=row,
                    compare_columns=(
                        "enabled",
                        "address",
                        "as_default",
                        "forwarded_headers_json",
                        "proxy_protocol_json",
                        "http_options_json",
                    ),
                    report=report,
                )
                if maybe_id is not None:
                    entrypoint_ids[str(row["name"])] = maybe_id

            cert_resolver_ids: dict[str, int] = {}
            for row in cert_resolver_rows:
                maybe_id = ensure_named_row(
                    cur,
                    table_name="cert_resolvers",
                    row=row,
                    compare_columns=(
                        "enabled",
                        "email",
                        "challenge_type",
                        "provider",
                        "storage",
                        "http_challenge_entrypoint",
                        "delay_before_check",
                        "resolvers_json",
                        "ca_server",
                        "extra_json",
                    ),
                    report=report,
                )
                if maybe_id is not None:
                    cert_resolver_ids[str(row["name"])] = maybe_id

            middleware_ids: dict[str, int] = {}
            for row in middleware_rows:
                maybe_id = ensure_named_row(
                    cur,
                    table_name="middlewares",
                    row=row,
                    compare_columns=("enabled", "type", "config_json"),
                    report=report,
                )
                if maybe_id is not None:
                    middleware_ids[str(row["name"])] = maybe_id

            tls_option_ids: dict[str, int] = {}
            for row in tls_option_rows:
                maybe_id = ensure_named_row(
                    cur,
                    table_name="tls_options",
                    row=row,
                    compare_columns=(
                        "enabled",
                        "min_version",
                        "sni_strict",
                        "cipher_suites_json",
                        "curve_preferences_json",
                        "client_auth_json",
                        "extra_json",
                    ),
                    report=report,
                )
                if maybe_id is not None:
                    tls_option_ids[str(row["name"])] = maybe_id

            transport_ids: dict[str, int] = {}
            for row in transport_rows:
                maybe_id = ensure_named_row(
                    cur,
                    table_name="servers_transports",
                    row=row,
                    compare_columns=(
                        "enabled",
                        "server_name",
                        "insecure_skip_verify",
                        "root_cas_json",
                        "max_idle_conns_per_host",
                        "forwarding_timeouts_json",
                        "extra_json",
                    ),
                    report=report,
                )
                if maybe_id is not None:
                    transport_ids[str(row["name"])] = maybe_id

            site_seeds = build_site_seeds(
                dynamic_config,
                middleware_names=set(middleware_ids),
                entrypoint_names=set(entrypoint_ids),
                cert_resolver_names=set(cert_resolver_ids),
                tls_option_names=set(tls_option_ids),
                transport_names=set(transport_ids),
                report=report,
            )

            for seed in site_seeds:
                ensure_site(
                    cur,
                    seed=seed,
                    cert_resolver_ids=cert_resolver_ids,
                    tls_option_ids=tls_option_ids,
                    transport_ids=transport_ids,
                    entrypoint_ids=entrypoint_ids,
                    middleware_ids=middleware_ids,
                    report=report,
                )

        if args.apply:
            conn.commit()
        else:
            conn.rollback()

    print_report(report, apply=args.apply)


if __name__ == "__main__":
    main()
