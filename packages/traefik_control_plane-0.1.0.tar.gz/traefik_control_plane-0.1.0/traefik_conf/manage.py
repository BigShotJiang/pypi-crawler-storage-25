from __future__ import annotations

import argparse

from control_plane.cli import main as run_control_plane


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run packaged Traefik control-plane helper commands.",
    )
    subparsers = parser.add_subparsers(dest="command")

    server_parser = subparsers.add_parser("server", help="Run the control-plane server.")
    server_parser.add_argument("args", nargs=argparse.REMAINDER)

    schema_parser = subparsers.add_parser("create-db-schema", help="Create or update the Postgres schema.")
    schema_parser.add_argument("args", nargs=argparse.REMAINDER)

    restore_parser = subparsers.add_parser("db-restore", help="Seed or restore database rows from YAML.")
    restore_parser.add_argument("args", nargs=argparse.REMAINDER)

    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "server":
        run_control_plane(args.args)
        return
    if args.command == "create-db-schema":
        from .create_db_schema import main as create_db_schema

        create_db_schema(args.args)
        return
    if args.command == "db-restore":
        from .import_yaml_seed import main as import_yaml_seed

        import_yaml_seed(args.args)
        return

    parser.print_help()
