from __future__ import annotations

from typing import Any


def disabled_backend_health(url: str, *, checked_at: str) -> dict[str, Any]:
    return {
        "ok": None,
        "url": url,
        "scheme": "",
        "host": "",
        "port": None,
        "latency_ms": None,
        "checked_at": checked_at,
        "error": "",
    }


def site_runtime_errors(
    runtime_errors: list[str],
    *,
    router_key: str,
    service_key: str,
    router_name: str,
    service_name: str,
    host: str,
) -> list[str]:
    return [
        value
        for value in runtime_errors
        if any(
            token and token in value
            for token in (
                router_key,
                service_key,
                router_name,
                service_name,
                host,
            )
        )
    ]


def site_provisioning_state(
    *,
    enabled: bool,
    router_seen: bool,
    service_seen: bool,
    backend_ok: bool | None,
    has_config_errors: bool,
) -> str:
    if not enabled:
        return "disabled"
    if router_seen and service_seen and backend_ok is True and not has_config_errors:
        return "healthy"
    return "degraded"


def build_site_runtime_status(
    site: dict[str, Any],
    *,
    router_key: str,
    router_value: dict[str, Any] | None,
    service_key: str,
    service_value: dict[str, Any] | None,
    backend_health: dict[str, Any],
    config_errors: list[str],
) -> dict[str, Any]:
    provisioning_state = site_provisioning_state(
        enabled=bool(site.get("enabled")),
        router_seen=router_value is not None,
        service_seen=service_value is not None,
        backend_ok=backend_health.get("ok"),
        has_config_errors=bool(config_errors),
    )
    return {
        "site_id": int(site["id"]),
        "site_name": str(site["name"]),
        "enabled": bool(site.get("enabled")),
        "host": str(site.get("host") or ""),
        "router_name": str(site["router_name"]),
        "service_name": str(site["service_name"]),
        "router_seen": router_value is not None,
        "router_runtime_name": router_key or None,
        "router_status": str(router_value.get("status") or "") if isinstance(router_value, dict) else "",
        "service_seen": service_value is not None,
        "service_runtime_name": service_key or None,
        "service_status": str(service_value.get("status") or "") if isinstance(service_value, dict) else "",
        "provisioning_state": provisioning_state,
        "backend_health": backend_health,
        "config_errors": list(config_errors),
        "site_issues": list(site.get("site_issues") or []),
    }
