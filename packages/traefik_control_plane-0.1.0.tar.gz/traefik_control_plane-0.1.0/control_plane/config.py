from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote, urljoin, urlparse, urlunparse

from .traefik_client import TraefikAPIEndpoint, discover_api_endpoint

COMBINED_CONFIG_DIRNAME = "dynamic"
COMBINED_CONFIG_FILENAME = "dynamic_conf.generated.yml"
DEFAULT_STATIC_CONFIG_FILENAME = "static_conf.yml"


def _expand_env_references(value: str) -> str:
    expanded = value
    for _ in range(8):
        next_value = os.path.expandvars(expanded)
        if next_value == expanded:
            break
        expanded = next_value
    return expanded


def _resolve_path(value: str | Path) -> Path:
    return Path(_expand_env_references(str(value))).expanduser().resolve()


def _env_value(name: str) -> str:
    value = os.getenv(name, "").strip()
    if value:
        return value
    return ""


def _parse_port(raw_value: str) -> int:
    try:
        port = int(raw_value)
    except ValueError as exc:
        raise RuntimeError(f"TRAEFIK_CONTROL_PLANE_PORT must be an integer, got {raw_value!r}.") from exc
    if not 1 <= port <= 65535:
        raise RuntimeError(f"TRAEFIK_CONTROL_PLANE_PORT must be between 1 and 65535, got {port}.")
    return port


def _parse_sync_interval(raw_value: str) -> float:
    try:
        interval = float(raw_value)
    except ValueError as exc:
        raise RuntimeError(
            f"TRAEFIK_CONTROL_PLANE_SYNC_INTERVAL must be a number, got {raw_value!r}."
        ) from exc
    if interval <= 0:
        raise RuntimeError(
            f"TRAEFIK_CONTROL_PLANE_SYNC_INTERVAL must be greater than 0, got {interval}."
        )
    return interval


def _validate_directory_path(path: Path, *, label: str, must_exist: bool = False) -> None:
    if path.exists() and not path.is_dir():
        raise RuntimeError(f"{label} must point to a directory, got file path {path}.")
    if must_exist and not path.is_dir():
        raise RuntimeError(f"{label} directory does not exist: {path}.")


def _validate_file_parent(path: Path, *, label: str) -> None:
    parent = path.parent
    if parent.exists() and not parent.is_dir():
        raise RuntimeError(f"{label} parent must be a directory, got file path {parent}.")


def discover_config_root() -> Path:
    configured = _env_value("TRAEFIK_CONTROL_PLANE_CONFIG_DIR")
    if configured:
        return _resolve_path(configured)
    raise RuntimeError(
        "Set TRAEFIK_CONTROL_PLANE_CONFIG_DIR. This directory holds the "
        "user-managed dynamic snippets for the control plane."
    )


def discover_runtime_root(config_root: Path) -> Path:
    configured = _env_value("TRAEFIK_RUNTIME_CONFIG_DIR")
    if configured:
        return _resolve_path(configured)
    return config_root


def discover_database_dsn() -> str:
    explicit = _env_value("TRAEFIK_DB_URL")
    if explicit:
        return explicit

    db_name = _env_value("TRAEFIK_DB_NAME")
    db_user = _env_value("TRAEFIK_DB_USER")
    db_password = _env_value("TRAEFIK_DB_PASSWORD")
    db_host = _env_value("TRAEFIK_DB_HOST") or "localhost"
    db_port = _env_value("TRAEFIK_DB_PORT") or "5432"
    db_sslmode = _env_value("TRAEFIK_DB_SSLMODE")

    if db_name and db_user:
        credentials = quote(db_user, safe="")
        if db_password:
            credentials = f"{credentials}:{quote(db_password, safe='')}"
        host_part = db_host
        if db_port:
            host_part = f"{host_part}:{db_port}"
        query = f"?sslmode={quote(db_sslmode, safe='')}" if db_sslmode else ""
        return f"postgresql://{credentials}@{host_part}/{quote(db_name, safe='')}{query}"

    raise RuntimeError(
        "Set TRAEFIK_DB_URL or provide TRAEFIK_DB_HOST, TRAEFIK_DB_PORT, "
        "TRAEFIK_DB_NAME, TRAEFIK_DB_USER, and optional TRAEFIK_DB_PASSWORD / "
        "TRAEFIK_DB_SSLMODE for the Traefik control-plane database."
    )


def mask_database_dsn(value: str) -> str:
    candidate = value.strip()
    if "://" not in candidate:
        return "configured"
    parsed = urlparse(candidate)
    if not parsed.scheme:
        return "configured"
    host = parsed.hostname or ""
    if parsed.port:
        host = f"{host}:{parsed.port}"
    if parsed.username:
        netloc = parsed.username
        if parsed.password:
            netloc = f"{netloc}:********"
        if host:
            netloc = f"{netloc}@{host}"
    else:
        netloc = host
    return urlunparse((parsed.scheme, netloc, parsed.path, "", "", ""))


def discover_dashboard_url(api_endpoint: TraefikAPIEndpoint, dashboard_host: str = "") -> str:
    explicit = _env_value("TRAEFIK_DASHBOARD_URL")
    if explicit:
        return explicit
    if dashboard_host:
        return f"https://{dashboard_host}/dashboard/"
    if api_endpoint.available and api_endpoint.base_url:
        return urljoin(f"{api_endpoint.base_url}/", "dashboard/")
    return ""


@dataclass(frozen=True)
class ControlPlaneConfig:
    config_root: Path
    runtime_root: Path
    repo_root: Path
    static_root: Path
    active_config_path: Path
    generated_config_path: Path
    database_dsn: str
    database_dsn_display: str
    host: str
    port: int
    sync_interval_seconds: float
    enable_ui: bool
    admin_api_endpoint: TraefikAPIEndpoint
    dashboard_url: str
    dashboard_host: str

    def __post_init__(self) -> None:
        _validate_directory_path(self.config_root, label="TRAEFIK_CONTROL_PLANE_CONFIG_DIR")
        _validate_directory_path(self.runtime_root, label="TRAEFIK_RUNTIME_CONFIG_DIR")
        _validate_file_parent(self.active_config_path, label="TRAEFIK_STATIC_CONFIG_PATH")
        _validate_file_parent(self.generated_config_path, label="generated config path")
        if self.enable_ui:
            _validate_directory_path(
                self.static_root,
                label="TRAEFIK_CONTROL_PLANE_STATIC_ASSETS_DIR",
                must_exist=True,
            )

    @classmethod
    def from_env(cls) -> "ControlPlaneConfig":
        module_dir = Path(__file__).resolve().parent
        config_root = discover_config_root()
        runtime_root = discover_runtime_root(config_root)
        default_static_config = config_root / DEFAULT_STATIC_CONFIG_FILENAME
        database_dsn = discover_database_dsn()
        admin_api_endpoint = discover_api_endpoint()
        dashboard_host = _env_value("TRAEFIK_DASHBOARD_HOST")
        host = _env_value("TRAEFIK_CONTROL_PLANE_HOST") or "127.0.0.1"
        port = _parse_port(_env_value("TRAEFIK_CONTROL_PLANE_PORT") or "8000")
        sync_interval_seconds = _parse_sync_interval(
            _env_value("TRAEFIK_CONTROL_PLANE_SYNC_INTERVAL") or "2.0"
        )
        enable_ui = _env_value("TRAEFIK_CONTROL_PLANE_ENABLE_UI").lower() in {"1", "true", "yes", "on"}
        return cls(
            config_root=config_root,
            runtime_root=runtime_root,
            repo_root=module_dir.parent,
            static_root=_resolve_path(
                _env_value("TRAEFIK_CONTROL_PLANE_STATIC_ASSETS_DIR")
                or str(module_dir / "static")
            ),
            active_config_path=_resolve_path(
                _env_value("TRAEFIK_STATIC_CONFIG_PATH")
                or str(default_static_config)
            ),
            generated_config_path=runtime_root / COMBINED_CONFIG_DIRNAME / COMBINED_CONFIG_FILENAME,
            database_dsn=database_dsn,
            database_dsn_display=mask_database_dsn(database_dsn),
            host=host,
            port=port,
            sync_interval_seconds=sync_interval_seconds,
            enable_ui=enable_ui,
            admin_api_endpoint=admin_api_endpoint,
            dashboard_url=discover_dashboard_url(admin_api_endpoint, dashboard_host),
            dashboard_host=dashboard_host,
        )

    def ensure_layout(self, root: Path | None = None) -> None:
        config_root = self.config_root
        runtime_root = root or self.runtime_root
        _validate_directory_path(config_root, label="TRAEFIK_CONTROL_PLANE_CONFIG_DIR")
        _validate_directory_path(runtime_root, label="TRAEFIK_RUNTIME_CONFIG_DIR")
        config_root.mkdir(parents=True, exist_ok=True)
        (config_root / COMBINED_CONFIG_DIRNAME).mkdir(parents=True, exist_ok=True)
        runtime_root.mkdir(parents=True, exist_ok=True)
        (runtime_root / COMBINED_CONFIG_DIRNAME).mkdir(parents=True, exist_ok=True)

    def capabilities_payload(self) -> dict[str, object]:
        return {
            "database_primary": True,
            "mutations_enabled": True,
            "quick_setup_supported": True,
            "managed_static_tables": ["entrypoints", "cert_resolvers"],
            "admin_api_available": self.admin_api_endpoint.available,
            "admin_api": self.admin_api_endpoint.as_payload(),
            "dashboard_url": self.dashboard_url,
            "dashboard_host": self.dashboard_host,
        }

    def runtime_payload(self, config_root: Path | None = None) -> dict[str, object]:
        target_root = config_root or self.runtime_root
        return {
            "listen_address": f"http://{self.host}:{self.port}",
            "config_root": str(self.config_root),
            "runtime_root": str(target_root),
            "active_config_path": str(self.active_config_path),
            "combined_config_path": str(
                self.generated_config_path
                if target_root == self.runtime_root
                else target_root / COMBINED_CONFIG_DIRNAME / COMBINED_CONFIG_FILENAME
            ),
            "static_root": str(self.static_root),
            "database_url": self.database_dsn_display,
            "sync_interval_seconds": self.sync_interval_seconds,
            "admin_api": self.admin_api_endpoint.as_payload(),
            "dashboard_url": self.dashboard_url,
            "dashboard_host": self.dashboard_host,
        }
