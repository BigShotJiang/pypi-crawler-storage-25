from __future__ import annotations

from typing import Any, Callable


IssueFactory = Callable[[str, str, str, str], dict[str, str]]
MappingParser = Callable[[Any, str, list[dict[str, str]]], dict[str, Any]]
StringListParser = Callable[[Any, str, list[dict[str, str]]], list[str]]
TemplateRenderer = Callable[[Any], tuple[Any, Any]]
PlaceholderFinder = Callable[[Any], list[str]]
PluginNormalizer = Callable[[dict[str, Any]], dict[str, Any]]


def render_middleware_row(
    row: dict[str, Any],
    *,
    issues: list[dict[str, str]],
    parse_mapping_text: MappingParser,
    render_template_env_references: TemplateRenderer,
    find_placeholder_paths: PlaceholderFinder,
    issue_factory: IssueFactory,
    normalize_plugin_config: PluginNormalizer,
) -> tuple[str, dict[str, Any], dict[str, Any]] | None:
    name = str(row["name"])
    middleware_type = str(row["type"])
    config = parse_mapping_text(row.get("config_json"), f"middlewares.{name}.config_json", issues)
    issue_count_before_resolution = len(issues)
    resolved_config, redacted_config = render_template_env_references(config)
    placeholder_paths = find_placeholder_paths(config)
    if placeholder_paths:
        issues.append(
            issue_factory(
                "warning",
                f"middlewares.{name}.config_json",
                "placeholder_values",
                "Middleware config_json still contains placeholder values at "
                + ", ".join(placeholder_paths)
                + ".",
            )
        )
    if any(item["severity"] == "error" for item in issues[issue_count_before_resolution:]):
        return None
    if middleware_type == "plugin":
        resolved_config = normalize_plugin_config(resolved_config)
        redacted_config = normalize_plugin_config(redacted_config)
    return name, {middleware_type: resolved_config}, {middleware_type: redacted_config}


def render_tls_option_row(
    row: dict[str, Any],
    *,
    issues: list[dict[str, str]],
    parse_mapping_text: MappingParser,
    parse_string_list_text: StringListParser,
    render_template_env_references: TemplateRenderer,
) -> tuple[str, dict[str, Any], dict[str, Any]]:
    name = str(row["name"])
    tls_option: dict[str, Any] = {}
    redacted_tls_option: dict[str, Any] = {}
    if row.get("min_version"):
        tls_option["minVersion"] = str(row["min_version"])
        redacted_tls_option["minVersion"] = str(row["min_version"])
    if row.get("sni_strict"):
        tls_option["sniStrict"] = True
        redacted_tls_option["sniStrict"] = True
    cipher_suites = parse_string_list_text(row.get("cipher_suites_json"), f"tls_options.{name}.cipher_suites_json", issues)
    if cipher_suites:
        tls_option["cipherSuites"] = cipher_suites
        redacted_tls_option["cipherSuites"] = list(cipher_suites)
    curve_preferences = parse_string_list_text(
        row.get("curve_preferences_json"),
        f"tls_options.{name}.curve_preferences_json",
        issues,
    )
    if curve_preferences:
        tls_option["curvePreferences"] = curve_preferences
        redacted_tls_option["curvePreferences"] = list(curve_preferences)
    client_auth = parse_mapping_text(row.get("client_auth_json"), f"tls_options.{name}.client_auth_json", issues)
    if client_auth:
        resolved_client_auth, redacted_client_auth = render_template_env_references(client_auth)
        tls_option["clientAuth"] = resolved_client_auth
        redacted_tls_option["clientAuth"] = redacted_client_auth
    return name, tls_option, redacted_tls_option


def render_servers_transport_row(
    row: dict[str, Any],
    *,
    issues: list[dict[str, str]],
    parse_mapping_text: MappingParser,
    parse_string_list_text: StringListParser,
    render_template_env_references: TemplateRenderer,
) -> tuple[str, dict[str, Any], dict[str, Any]]:
    name = str(row["name"])
    transport: dict[str, Any] = {}
    redacted_transport: dict[str, Any] = {}
    if row.get("server_name"):
        transport["serverName"] = str(row["server_name"])
        redacted_transport["serverName"] = str(row["server_name"])
    if row.get("insecure_skip_verify"):
        transport["insecureSkipVerify"] = True
        redacted_transport["insecureSkipVerify"] = True
    root_cas = parse_string_list_text(row.get("root_cas_json"), f"servers_transports.{name}.root_cas_json", issues)
    if root_cas:
        transport["rootCAs"] = root_cas
        redacted_transport["rootCAs"] = list(root_cas)
    if row.get("max_idle_conns_per_host") is not None:
        transport["maxIdleConnsPerHost"] = int(row["max_idle_conns_per_host"])
        redacted_transport["maxIdleConnsPerHost"] = int(row["max_idle_conns_per_host"])
    forwarding_timeouts = parse_mapping_text(
        row.get("forwarding_timeouts_json"),
        f"servers_transports.{name}.forwarding_timeouts_json",
        issues,
    )
    if forwarding_timeouts:
        resolved_timeouts, redacted_timeouts = render_template_env_references(forwarding_timeouts)
        transport["forwardingTimeouts"] = resolved_timeouts
        redacted_transport["forwardingTimeouts"] = redacted_timeouts
    return name, transport, redacted_transport
