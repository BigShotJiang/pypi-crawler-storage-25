from __future__ import annotations

import argparse
import os


def _env_value(name: str) -> str:
    return os.environ.get(name, "").strip()


def _env_bool(name: str, default: bool = False) -> bool:
    value = _env_value(name)
    if not value:
        return default
    return value.lower() in {"1", "true", "yes", "on"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the Traefik database-backed control-plane server.")
    parser.add_argument("--host", default=_env_value("TRAEFIK_CONTROL_PLANE_HOST") or "127.0.0.1")
    parser.add_argument("--port", type=int, default=int(_env_value("TRAEFIK_CONTROL_PLANE_PORT") or "8000"))
    parser.add_argument("--headless", action="store_true", help="Run sync/render loop without serving HTTP.")
    parser.add_argument("--once", action="store_true", help="Run one sync cycle and exit.")
    parser.add_argument(
        "--enable-ui",
        action="store_true",
        default=_env_bool("TRAEFIK_CONTROL_PLANE_ENABLE_UI"),
        help="Serve the optional built web UI and static assets.",
    )
    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    forwarded: list[str] = [
        "--host",
        str(args.host),
        "--port",
        str(args.port),
    ]
    if args.headless:
        forwarded.append("--headless")
    if args.once:
        forwarded.append("--once")
    if args.enable_ui:
        forwarded.append("--enable-ui")

    from . import server

    server.main(forwarded)
