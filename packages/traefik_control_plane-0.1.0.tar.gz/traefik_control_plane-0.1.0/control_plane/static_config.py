from __future__ import annotations

import json
from typing import Any, Callable


IssueFactory = Callable[[str, str, str, str], dict[str, str]]


def json_text(value: Any) -> str | None:
    if value in (None, "", [], {}):
        return None
    return json.dumps(value, indent=2, sort_keys=True)


def parse_static_entrypoints(
    static_config: dict[str, Any],
    issues: list[dict[str, str]],
    *,
    issue_factory: IssueFactory,
) -> list[dict[str, Any]]:
    raw_entrypoints = static_config.get("entryPoints")
    if raw_entrypoints in (None, {}):
        return []
    if not isinstance(raw_entrypoints, dict):
        issues.append(issue_factory("error", "static.entryPoints", "invalid_shape", "entryPoints must be a mapping."))
        return []

    rows: list[dict[str, Any]] = []
    for name in sorted(raw_entrypoints):
        raw_value = raw_entrypoints.get(name)
        if not isinstance(raw_value, dict):
            issues.append(
                issue_factory(
                    "warning",
                    f"static.entryPoints.{name}",
                    "invalid_shape",
                    "Skipping non-object entryPoint definition.",
                )
            )
            continue
        address = str(raw_value.get("address", "")).strip()
        if not address:
            issues.append(
                issue_factory(
                    "warning",
                    f"static.entryPoints.{name}",
                    "missing_address",
                    "Skipping entryPoint without an address.",
                )
            )
            continue
        rows.append(
            {
                "name": str(name),
                "enabled": True,
                "address": address,
                "as_default": bool(raw_value.get("asDefault", False)),
                "forwarded_headers_json": json_text(raw_value.get("forwardedHeaders")),
                "proxy_protocol_json": json_text(raw_value.get("proxyProtocol")),
                "http_options_json": json_text(raw_value.get("http")),
            }
        )
    return rows


def parse_static_cert_resolvers(
    static_config: dict[str, Any],
    issues: list[dict[str, str]],
    *,
    issue_factory: IssueFactory,
) -> list[dict[str, Any]]:
    raw_resolvers = static_config.get("certificatesResolvers")
    if raw_resolvers in (None, {}):
        return []
    if not isinstance(raw_resolvers, dict):
        issues.append(
            issue_factory(
                "error",
                "static.certificatesResolvers",
                "invalid_shape",
                "certificatesResolvers must be a mapping.",
            )
        )
        return []

    rows: list[dict[str, Any]] = []
    for name in sorted(raw_resolvers):
        raw_value = raw_resolvers.get(name)
        if not isinstance(raw_value, dict):
            issues.append(
                issue_factory(
                    "warning",
                    f"static.certificatesResolvers.{name}",
                    "invalid_shape",
                    "Skipping non-object cert resolver definition.",
                )
            )
            continue
        acme = raw_value.get("acme")
        if not isinstance(acme, dict):
            issues.append(
                issue_factory(
                    "warning",
                    f"static.certificatesResolvers.{name}",
                    "unsupported_shape",
                    "Skipping resolver without an ACME configuration.",
                )
            )
            continue

        dns_challenge = acme.get("dnsChallenge") if isinstance(acme.get("dnsChallenge"), dict) else None
        http_challenge = acme.get("httpChallenge") if isinstance(acme.get("httpChallenge"), dict) else None
        tls_challenge = acme.get("tlsChallenge") if isinstance(acme.get("tlsChallenge"), dict) else None
        challenge_names = [
            label
            for label, value in (
                ("dnsChallenge", dns_challenge),
                ("httpChallenge", http_challenge),
                ("tlsChallenge", tls_challenge),
            )
            if value is not None
        ]
        if len(challenge_names) > 1:
            issues.append(
                issue_factory(
                    "warning",
                    f"static.certificatesResolvers.{name}",
                    "multiple_challenges",
                    f"Multiple ACME challenge types were found; using {challenge_names[0]} as the primary one.",
                )
            )
        challenge_type = challenge_names[0] if challenge_names else "dnsChallenge"

        extra_acme = dict(acme)
        email = str(acme.get("email", "")).strip() or None
        storage = str(acme.get("storage", "")).strip() or None
        ca_server = str(acme.get("caServer", "")).strip() or None
        extra_acme.pop("email", None)
        extra_acme.pop("storage", None)
        extra_acme.pop("caServer", None)

        provider = None
        http_entrypoint = None
        delay_before_check = None
        resolvers_json = None

        if dns_challenge is not None:
            provider = str(dns_challenge.get("provider", "")).strip() or None
            delay_value = dns_challenge.get("delayBeforeCheck")
            if delay_value not in (None, ""):
                try:
                    delay_before_check = int(delay_value)
                except (TypeError, ValueError):
                    issues.append(
                        issue_factory(
                            "warning",
                            f"static.certificatesResolvers.{name}",
                            "invalid_delay",
                            "Ignoring non-integer delayBeforeCheck value.",
                        )
                    )
            resolvers_json = json_text(dns_challenge.get("resolvers"))
            dns_extra = dict(dns_challenge)
            dns_extra.pop("provider", None)
            dns_extra.pop("delayBeforeCheck", None)
            dns_extra.pop("resolvers", None)
            if dns_extra:
                extra_acme["dnsChallenge"] = dns_extra
            else:
                extra_acme.pop("dnsChallenge", None)

        if http_challenge is not None:
            http_entrypoint = str(http_challenge.get("entryPoint", "")).strip() or None
            http_extra = dict(http_challenge)
            http_extra.pop("entryPoint", None)
            if http_extra:
                extra_acme["httpChallenge"] = http_extra
            else:
                extra_acme.pop("httpChallenge", None)

        if tls_challenge is not None:
            extra_acme["tlsChallenge"] = dict(tls_challenge)

        rows.append(
            {
                "name": str(name),
                "enabled": True,
                "email": email,
                "challenge_type": challenge_type,
                "provider": provider,
                "storage": storage,
                "http_challenge_entrypoint": http_entrypoint,
                "delay_before_check": delay_before_check,
                "resolvers_json": resolvers_json,
                "ca_server": ca_server,
                "extra_json": json_text(extra_acme),
            }
        )
    return rows
