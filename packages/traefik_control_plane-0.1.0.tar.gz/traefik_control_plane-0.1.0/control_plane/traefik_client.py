from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any
from urllib import error, parse, request


DEFAULT_API_BASE_URL = "http://localhost:8080"


class TraefikAPIError(RuntimeError):
    """Raised when the Traefik API returns an error or cannot be reached."""


@dataclass(frozen=True)
class TraefikAPIEndpoint:
    available: bool
    base_url: str
    source: str
    detail: str

    def as_payload(self) -> dict[str, Any]:
        return {
            "available": self.available,
            "base_url": self.base_url,
            "source": self.source,
            "detail": self.detail,
        }


def normalize_api_base_url(value: str) -> str:
    target = value.strip()
    if not target:
        return DEFAULT_API_BASE_URL
    if target.startswith(("http://", "https://")):
        return target.rstrip("/")
    if "://" in target:
        raise ValueError(f"unsupported Traefik API target: {target}")
    if target.startswith(":"):
        target = f"localhost{target}"
    return f"http://{target}".rstrip("/")


def discover_api_endpoint() -> TraefikAPIEndpoint:
    candidates = [
        (
            "TRAEFIK_API_URL",
            os.getenv("TRAEFIK_API_URL", "").strip(),
            "Traefik API URL configured for the control plane",
        ),
        (
            "default",
            DEFAULT_API_BASE_URL,
            "Default Traefik API address",
        ),
    ]
    for source, candidate, detail in candidates:
        if not candidate:
            continue
        try:
            base_url = normalize_api_base_url(candidate)
        except ValueError as exc:
            return TraefikAPIEndpoint(
                available=False,
                base_url="",
                source=source,
                detail=str(exc),
            )
        return TraefikAPIEndpoint(
            available=True,
            base_url=base_url,
            source=source,
            detail=detail,
        )
    return TraefikAPIEndpoint(
        available=False,
        base_url="",
        source="unavailable",
        detail="No Traefik API address is configured.",
    )


class TraefikAPIClient:
    def __init__(self, endpoint: TraefikAPIEndpoint, timeout_seconds: float = 1.0) -> None:
        if not endpoint.available:
            raise TraefikAPIError(endpoint.detail)
        self.endpoint = endpoint
        self.timeout_seconds = timeout_seconds

    def _request(self, path: str) -> tuple[Any, dict[str, str]]:
        url = parse.urljoin(f"{self.endpoint.base_url}/", path.lstrip("/"))
        req = request.Request(url, headers={"Accept": "application/json"})
        try:
            with request.urlopen(req, timeout=self.timeout_seconds) as response:
                raw = response.read().decode("utf-8", "replace")
                content_type = response.headers.get("Content-Type", "")
                if "json" in content_type:
                    return json.loads(raw), dict(response.headers.items())
                return raw, dict(response.headers.items())
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace").strip()
            raise TraefikAPIError(f"GET {url} failed with HTTP {exc.code}: {detail or exc.reason}") from exc
        except error.URLError as exc:
            reason = getattr(exc, "reason", exc)
            raise TraefikAPIError(f"GET {url} failed: {reason}") from exc

    def get_overview(self) -> tuple[Any, dict[str, str]]:
        return self._request("/api/overview")

    def get_rawdata(self) -> tuple[Any, dict[str, str]]:
        return self._request("/api/rawdata")

    def get_version(self) -> tuple[Any, dict[str, str]]:
        return self._request("/api/version")


def _count_mapping_items(value: Any) -> int:
    if isinstance(value, dict):
        return len(value)
    if isinstance(value, list):
        return len(value)
    return 0


def fetch_runtime_snapshot(endpoint: TraefikAPIEndpoint, *, timeout_seconds: float = 1.0) -> dict[str, Any]:
    snapshot = {
        "available": endpoint.available,
        "base_url": endpoint.base_url,
        "source": endpoint.source,
        "detail": endpoint.detail,
        "reachable": False,
        "overview": {
            "ok": False,
            "value": None,
            "error": "",
        },
        "rawdata": {
            "ok": False,
            "value": None,
            "error": "",
        },
        "version": {
            "ok": False,
            "value": None,
            "error": "",
        },
    }
    if not endpoint.available:
        return snapshot

    client = TraefikAPIClient(endpoint, timeout_seconds=timeout_seconds)
    try:
        overview, _ = client.get_overview()
    except TraefikAPIError as exc:
        snapshot["overview"]["error"] = str(exc)
        return snapshot
    snapshot["reachable"] = True
    snapshot["overview"].update({"ok": True, "value": overview})

    try:
        rawdata, _ = client.get_rawdata()
    except TraefikAPIError as exc:
        snapshot["rawdata"]["error"] = str(exc)
        return snapshot
    snapshot["rawdata"].update({"ok": True, "value": rawdata})

    try:
        version, _ = client.get_version()
    except TraefikAPIError as exc:
        snapshot["version"]["error"] = str(exc)
        return snapshot
    snapshot["version"].update({"ok": True, "value": version})
    return snapshot


def summarize_runtime_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    overview = snapshot["overview"]["value"] if snapshot["overview"]["ok"] else {}
    rawdata = snapshot["rawdata"]["value"] if snapshot["rawdata"]["ok"] else {}
    http_section = rawdata.get("http", {}) if isinstance(rawdata, dict) else {}
    tcp_section = rawdata.get("tcp", {}) if isinstance(rawdata, dict) else {}
    errors = rawdata.get("errors", []) if isinstance(rawdata, dict) else []
    return {
        "available": snapshot["available"],
        "base_url": snapshot["base_url"],
        "source": snapshot["source"],
        "detail": snapshot["detail"],
        "reachable": snapshot["reachable"],
        "config_ok": snapshot["rawdata"]["ok"] and not bool(errors),
        "config_etag": "",
        "config_apps": ["http", "tcp", "providers"],
        "config_top_level_keys": sorted(str(key) for key in rawdata.keys()) if isinstance(rawdata, dict) else [],
        "config_error": snapshot["overview"]["error"] or snapshot["rawdata"]["error"],
        "upstreams_ok": snapshot["rawdata"]["ok"],
        "upstream_count": _count_mapping_items(http_section.get("services")) + _count_mapping_items(tcp_section.get("services")),
        "upstreams_error": "",
        "router_count": _count_mapping_items(http_section.get("routers")) + _count_mapping_items(tcp_section.get("routers")),
        "middleware_count": _count_mapping_items(http_section.get("middlewares")) + _count_mapping_items(tcp_section.get("middlewares")),
        "service_count": _count_mapping_items(http_section.get("services")) + _count_mapping_items(tcp_section.get("services")),
        "error_count": len(errors) if isinstance(errors, list) else 0,
        "version": snapshot["version"]["value"].get("Version", "") if isinstance(snapshot["version"]["value"], dict) else "",
        "overview": overview,
    }
