from __future__ import annotations

from typing import Any


def resolved_site_rule(site: dict[str, Any], *, generated_rule: str) -> str:
    explicit_rule = str(site.get("rule_override") or "").strip()
    return explicit_rule or generated_rule


def build_site_payload(
    site: dict[str, Any],
    *,
    router_name: str,
    service_name: str,
    resolved_rule: str,
    resolved_entrypoints: list[str],
    non_auth_middlewares: list[dict[str, Any]],
    cert_resolver: dict[str, Any] | None,
    tls_option: dict[str, Any] | None,
    transport: dict[str, Any] | None,
    oidc_client: dict[str, Any] | None,
    has_advanced_config: bool,
    site_issues: list[dict[str, str]],
) -> dict[str, Any]:
    middleware_names = [str(row["name"]) for row in non_auth_middlewares]
    oidc_client_id = int(oidc_client["id"]) if oidc_client else None
    oidc_client_name = str(oidc_client["name"]) if oidc_client else None
    return {
        **dict(site),
        "router_name": router_name,
        "service_name": service_name,
        "resolved_rule": resolved_rule,
        "entrypoints": list(resolved_entrypoints),
        "middlewares": middleware_names,
        "cert_resolver_name": cert_resolver["name"] if cert_resolver else None,
        "tls_options_name": tls_option["name"] if tls_option else None,
        "servers_transport_name": transport["name"] if transport else None,
        "oidc_client_id": oidc_client_id,
        "oidc_client_name": oidc_client_name,
        "auth_preset_id": oidc_client_id,
        "auth_preset_name": oidc_client_name,
        "non_auth_middlewares": middleware_names,
        "has_advanced_config": has_advanced_config,
        "site_issues": list(site_issues),
    }


def resolved_stream_rule(stream: dict[str, Any], *, generated_rule: str) -> str:
    explicit_rule = str(stream.get("rule_override") or "").strip()
    return explicit_rule or generated_rule


def build_stream_payload(
    stream: dict[str, Any],
    *,
    router_name: str,
    service_name: str,
    resolved_rule: str,
    entrypoints: list[str],
    transport: dict[str, Any] | None,
    stream_issues: list[dict[str, str]],
) -> dict[str, Any]:
    return {
        **dict(stream),
        "router_name": router_name,
        "service_name": service_name,
        "resolved_rule": resolved_rule,
        "entrypoints": list(entrypoints),
        "servers_transport_name": transport["name"] if transport else None,
        "stream_issues": list(stream_issues),
    }
