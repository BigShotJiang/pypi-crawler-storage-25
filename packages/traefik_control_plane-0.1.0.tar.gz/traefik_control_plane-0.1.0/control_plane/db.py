from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any

import psycopg
from psycopg import sql
from psycopg.rows import dict_row


TABLES = (
    "sites",
    "streams",
    "middlewares",
    "oidc_clients",
    "entrypoints",
    "cert_resolvers",
    "tls_options",
    "servers_transports",
)

QUICK_SITE_COLUMNS = (
    "name",
    "enabled",
    "host",
    "upstream_url",
    "tls_enabled",
    "cert_resolver",
    "oidc_client",
    "path_prefix",
)


@dataclass(frozen=True)
class InventorySnapshot:
    sites: list[dict[str, Any]]
    streams: list[dict[str, Any]]
    middlewares: list[dict[str, Any]]
    oidc_clients: list[dict[str, Any]]
    entrypoints: list[dict[str, Any]]
    cert_resolvers: list[dict[str, Any]]
    tls_options: list[dict[str, Any]]
    servers_transports: list[dict[str, Any]]
    site_entrypoints: dict[int, list[dict[str, Any]]]
    stream_entrypoints: dict[int, list[dict[str, Any]]]
    site_middlewares: dict[int, list[dict[str, Any]]]
    deployments: list[dict[str, Any]]

    def as_payload(self) -> dict[str, Any]:
        return {
            "sites": self.sites,
            "streams": self.streams,
            "middlewares": self.middlewares,
            "oidc_clients": self.oidc_clients,
            "entrypoints": self.entrypoints,
            "cert_resolvers": self.cert_resolvers,
            "tls_options": self.tls_options,
            "servers_transports": self.servers_transports,
            "site_entrypoints": self.site_entrypoints,
            "stream_entrypoints": self.stream_entrypoints,
            "site_middlewares": self.site_middlewares,
            "deployments": self.deployments,
        }


def connect(dsn: str, *, autocommit: bool = False) -> psycopg.Connection[Any]:
    return psycopg.connect(dsn, autocommit=autocommit, row_factory=dict_row)


def _fetch_named_table(cur: psycopg.Cursor[Any], table_name: str) -> list[dict[str, Any]]:
    query = sql.SQL("SELECT * FROM public.{} ORDER BY enabled DESC, name ASC, id ASC").format(
        sql.Identifier(table_name)
    )
    cur.execute(query)
    return list(cur.fetchall())


def _fetch_site_links(
    cur: psycopg.Cursor[Any],
    join_table: str,
    foreign_table: str,
    foreign_column: str,
    owner_column: str = "site",
) -> dict[int, list[dict[str, Any]]]:
    query = sql.SQL(
        """
        SELECT link.{owner_column} AS owner_id, item.id, item.name, item.enabled
        FROM public.{join_table} AS link
        JOIN public.{foreign_table} AS item
          ON item.id = link.{foreign_column}
        ORDER BY link.{owner_column} ASC, item.name ASC, item.id ASC
        """
    ).format(
        owner_column=sql.Identifier(owner_column),
        join_table=sql.Identifier(join_table),
        foreign_table=sql.Identifier(foreign_table),
        foreign_column=sql.Identifier(foreign_column),
    )
    cur.execute(query)
    linked: dict[int, list[dict[str, Any]]] = {}
    for row in cur.fetchall():
        owner_id = int(row["owner_id"])
        linked.setdefault(owner_id, []).append(
            {
                "id": row["id"],
                "name": row["name"],
                "enabled": row["enabled"],
            }
        )
    return linked


def fetch_inventory(dsn: str, *, deployment_limit: int = 25) -> InventorySnapshot:
    with connect(dsn) as conn:
        with conn.cursor() as cur:
            tables = {table_name: _fetch_named_table(cur, table_name) for table_name in TABLES}
            site_entrypoints = _fetch_site_links(cur, "site_entrypoints", "entrypoints", "entrypoint")
            stream_entrypoints = _fetch_site_links(
                cur,
                "stream_entrypoints",
                "entrypoints",
                "entrypoint",
                owner_column="stream",
            )
            site_middlewares = _fetch_site_links(cur, "site_middlewares", "middlewares", "middleware")
            deployments = _fetch_recent_deployments(cur, deployment_limit=deployment_limit)

    return InventorySnapshot(
        sites=tables["sites"],
        streams=tables["streams"],
        middlewares=tables["middlewares"],
        oidc_clients=tables["oidc_clients"],
        entrypoints=tables["entrypoints"],
        cert_resolvers=tables["cert_resolvers"],
        tls_options=tables["tls_options"],
        servers_transports=tables["servers_transports"],
        site_entrypoints=site_entrypoints,
        stream_entrypoints=stream_entrypoints,
        site_middlewares=site_middlewares,
        deployments=deployments,
    )


def _fetch_recent_deployments(
    cur: psycopg.Cursor[Any],
    *,
    deployment_limit: int,
) -> list[dict[str, Any]]:
    cur.execute(
        """
        SELECT *
        FROM public.deployments
        ORDER BY created_at DESC, id DESC
        LIMIT %s
        """,
        (deployment_limit,),
    )
    return list(cur.fetchall())


def fetch_recent_deployments(dsn: str, *, deployment_limit: int = 25) -> list[dict[str, Any]]:
    with connect(dsn) as conn:
        with conn.cursor() as cur:
            return _fetch_recent_deployments(cur, deployment_limit=deployment_limit)


def with_updated_deployments(
    snapshot: InventorySnapshot,
    deployments: list[dict[str, Any]],
) -> InventorySnapshot:
    return replace(snapshot, deployments=deployments)


def _upsert_named_rows(
    cur: psycopg.Cursor[Any],
    *,
    table_name: str,
    rows: list[dict[str, Any]],
    update_columns: tuple[str, ...],
) -> None:
    if not rows:
        return

    insert_columns = tuple(rows[0].keys())
    values_sql = sql.SQL(", ").join(sql.Placeholder() for _ in insert_columns)
    insert_columns_sql = sql.SQL(", ").join(sql.Identifier(column) for column in insert_columns)
    update_sql = sql.SQL(", ").join(
        sql.SQL("{column} = EXCLUDED.{column}").format(column=sql.Identifier(column))
        for column in update_columns
    )
    statement = sql.SQL(
        """
        INSERT INTO public.{table_name} ({insert_columns})
        VALUES ({values})
        ON CONFLICT (name) DO UPDATE
        SET {updates}
        """
    ).format(
        table_name=sql.Identifier(table_name),
        insert_columns=insert_columns_sql,
        values=values_sql,
        updates=update_sql,
    )

    for row in rows:
        cur.execute(statement, [row[column] for column in insert_columns])


def _delete_missing_names(
    cur: psycopg.Cursor[Any], *, table_name: str, names: list[str]
) -> None:
    if names:
        cur.execute(
            sql.SQL("DELETE FROM public.{} WHERE NOT (name = ANY(%s))").format(
                sql.Identifier(table_name)
            ),
            (names,),
        )
        return
    cur.execute(sql.SQL("DELETE FROM public.{}").format(sql.Identifier(table_name)))


def replace_static_inventory(
    dsn: str,
    *,
    entrypoints: list[dict[str, Any]],
    cert_resolvers: list[dict[str, Any]],
) -> None:
    with connect(dsn) as conn:
        with conn.cursor() as cur:
            _upsert_named_rows(
                cur,
                table_name="entrypoints",
                rows=entrypoints,
                update_columns=(
                    "enabled",
                    "address",
                    "as_default",
                    "forwarded_headers_json",
                    "proxy_protocol_json",
                    "http_options_json",
                ),
            )
            _delete_missing_names(
                cur,
                table_name="entrypoints",
                names=[str(row["name"]) for row in entrypoints],
            )
            _upsert_named_rows(
                cur,
                table_name="cert_resolvers",
                rows=cert_resolvers,
                update_columns=(
                    "enabled",
                    "email",
                    "challenge_type",
                    "provider",
                    "storage",
                    "http_challenge_entrypoint",
                    "delay_before_check",
                    "resolvers_json",
                    "ca_server",
                    "extra_json",
                ),
            )
            _delete_missing_names(
                cur,
                table_name="cert_resolvers",
                names=[str(row["name"]) for row in cert_resolvers],
            )
        conn.commit()


def record_deployment(
    dsn: str,
    *,
    status: str,
    checksum: str = "",
    triggered_by: str = "",
    rendered_yaml: str = "",
    error_text: str = "",
    notes: str = "",
) -> dict[str, Any]:
    with connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO public.deployments (
                    status,
                    checksum,
                    triggered_by,
                    rendered_yaml,
                    error_text,
                    notes
                )
                VALUES (%s, %s, %s, %s, %s, %s)
                RETURNING *
                """,
                (status, checksum, triggered_by, rendered_yaml, error_text, notes),
            )
            row = dict(cur.fetchone())
        conn.commit()
    return row


def _replace_site_links(
    cur: psycopg.Cursor[Any],
    *,
    site_id: int,
    join_table: str,
    foreign_column: str,
    values: list[int],
) -> None:
    deduped = list(dict.fromkeys(int(value) for value in values))
    cur.execute(
        sql.SQL("DELETE FROM public.{} WHERE site = %s").format(sql.Identifier(join_table)),
        (site_id,),
    )
    if not deduped:
        return
    statement = sql.SQL(
        "INSERT INTO public.{join_table} (site, {foreign_column}) VALUES (%s, %s)"
    ).format(
        join_table=sql.Identifier(join_table),
        foreign_column=sql.Identifier(foreign_column),
    )
    for value in deduped:
        cur.execute(statement, (site_id, value))


def _site_fields_payload(fields: dict[str, Any]) -> tuple[tuple[str, ...], list[Any]]:
    columns = tuple(column for column in QUICK_SITE_COLUMNS if column in fields)
    values = [fields[column] for column in columns]
    return columns, values


def create_quick_site(
    dsn: str,
    *,
    fields: dict[str, Any],
    entrypoint_ids: list[int],
    middleware_ids: list[int],
) -> dict[str, Any]:
    columns, values = _site_fields_payload(fields)
    if not columns:
        raise ValueError("site fields are required")

    with connect(dsn) as conn:
        with conn.cursor() as cur:
            insert_columns = sql.SQL(", ").join(sql.Identifier(column) for column in columns)
            placeholders = sql.SQL(", ").join(sql.Placeholder() for _ in columns)
            cur.execute(
                sql.SQL(
                    """
                    INSERT INTO public.sites ({columns})
                    VALUES ({placeholders})
                    RETURNING *
                    """
                ).format(columns=insert_columns, placeholders=placeholders),
                values,
            )
            row = dict(cur.fetchone())
            site_id = int(row["id"])
            _replace_site_links(
                cur,
                site_id=site_id,
                join_table="site_entrypoints",
                foreign_column="entrypoint",
                values=entrypoint_ids,
            )
            _replace_site_links(
                cur,
                site_id=site_id,
                join_table="site_middlewares",
                foreign_column="middleware",
                values=middleware_ids,
            )
        conn.commit()
    return row


def update_quick_site(
    dsn: str,
    *,
    site_id: int,
    fields: dict[str, Any],
    middleware_ids: list[int],
) -> dict[str, Any]:
    columns, values = _site_fields_payload(fields)
    if not columns:
        raise ValueError("site fields are required")

    with connect(dsn) as conn:
        with conn.cursor() as cur:
            assignments = sql.SQL(", ").join(
                sql.SQL("{} = %s").format(sql.Identifier(column)) for column in columns
            )
            cur.execute(
                sql.SQL(
                    """
                    UPDATE public.sites
                    SET {assignments}
                    WHERE id = %s
                    RETURNING *
                    """
                ).format(assignments=assignments),
                [*values, site_id],
            )
            record = cur.fetchone()
            if record is None:
                raise LookupError(f"site {site_id} was not found")
            row = dict(record)
            _replace_site_links(
                cur,
                site_id=site_id,
                join_table="site_middlewares",
                foreign_column="middleware",
                values=middleware_ids,
            )
        conn.commit()
    return row


def toggle_site_enabled(dsn: str, *, site_id: int, enabled: bool) -> dict[str, Any]:
    with connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE public.sites
                SET enabled = %s
                WHERE id = %s
                RETURNING *
                """,
                (enabled, site_id),
            )
            record = cur.fetchone()
            if record is None:
                raise LookupError(f"site {site_id} was not found")
            row = dict(record)
        conn.commit()
    return row
