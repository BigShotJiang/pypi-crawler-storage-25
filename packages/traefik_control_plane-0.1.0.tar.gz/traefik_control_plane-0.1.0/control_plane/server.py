#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import html
import json
import mimetypes
import os
import re
import shutil
import socket
import sys
import signal
import tempfile
import time
from dataclasses import dataclass
from datetime import UTC, date, datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Lock, RLock, Thread
from typing import Any
from urllib.parse import urlparse

import yaml

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from control_plane.config import ControlPlaneConfig
    from control_plane.db import (
        InventorySnapshot,
        create_quick_site,
        fetch_recent_deployments,
        fetch_inventory,
        record_deployment,
        replace_static_inventory,
        toggle_site_enabled,
        update_quick_site,
        with_updated_deployments,
    )
    from control_plane.runtime_status import (
        build_site_runtime_status,
        disabled_backend_health,
        site_runtime_errors,
    )
    from control_plane.render_output import (
        build_render_payloads,
        build_render_summary,
    )
    from control_plane.render_components import (
        render_middleware_row,
        render_servers_transport_row,
        render_tls_option_row,
    )
    from control_plane.state_payload import (
        build_site_payload,
        build_stream_payload,
        resolved_site_rule,
        resolved_stream_rule,
    )
    from control_plane.static_config import (
        parse_static_cert_resolvers,
        parse_static_entrypoints,
    )
    from control_plane.traefik_client import fetch_runtime_snapshot, summarize_runtime_snapshot
else:
    from .config import ControlPlaneConfig
    from .db import (
        InventorySnapshot,
        create_quick_site,
        fetch_recent_deployments,
        fetch_inventory,
        record_deployment,
        replace_static_inventory,
        toggle_site_enabled,
        update_quick_site,
        with_updated_deployments,
    )
    from .runtime_status import (
        build_site_runtime_status,
        disabled_backend_health,
        site_runtime_errors,
    )
    from .render_output import (
        build_render_payloads,
        build_render_summary,
    )
    from .render_components import (
        render_middleware_row,
        render_servers_transport_row,
        render_tls_option_row,
    )
    from .state_payload import (
        build_site_payload,
        build_stream_payload,
        resolved_site_rule,
        resolved_stream_rule,
    )
    from .static_config import (
        parse_static_cert_resolvers,
        parse_static_entrypoints,
    )
    from .traefik_client import fetch_runtime_snapshot, summarize_runtime_snapshot

SETTINGS = ControlPlaneConfig.from_env()
CONFIG_ROOT = SETTINGS.config_root
RUNTIME_ROOT = SETTINGS.runtime_root
STATIC_ROOT = SETTINGS.static_root
ACTIVE_CONFIG_PATH = SETTINGS.active_config_path
WEB_UI_ENABLED = SETTINGS.enable_ui

GENERATED_FILE_BANNER = (
    "# Generated from the Traefik control-plane database.\n"
    "# Edit records in NocoDB or update the static Traefik config instead of editing this file."
)
NAME_RE = re.compile(r"[^A-Za-z0-9._-]+")
UPSTREAM_HEALTH_TIMEOUT_SECONDS = 2.0
UPSTREAM_HEALTH_TTL_SECONDS = 30.0
UPSTREAM_HEALTH_CACHE: dict[str, dict[str, Any]] = {}
UPSTREAM_HEALTH_LOCK = Lock()
ENV_REF_PREFIX = "env://"
SECRET_REF_PREFIX = "secret://"


def utc_timestamp() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")


def sha256_text(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    normalized = content if content.endswith("\n") else f"{content}\n"
    with tempfile.NamedTemporaryFile("w", dir=path.parent, delete=False, encoding="utf-8") as handle:
        handle.write(normalized)
        temp_name = handle.name
    os.replace(temp_name, path)


def sync_user_dynamic_snippets(*, config_root: Path, runtime_root: Path, generated_filename: str) -> None:
    source_dir = config_root / "dynamic"
    target_dir = runtime_root / "dynamic"
    target_dir.mkdir(parents=True, exist_ok=True)

    expected_files: set[str] = set()
    if source_dir.is_dir():
        for source_path in sorted(source_dir.iterdir()):
            if not source_path.is_file():
                continue
            if source_path.name == generated_filename:
                continue
            if source_path.suffix.lower() not in {".yml", ".yaml"}:
                continue
            expected_files.add(source_path.name)
            target_path = target_dir / source_path.name
            if target_path.exists() and target_path.read_text(encoding="utf-8") == source_path.read_text(encoding="utf-8"):
                continue
            shutil.copy2(source_path, target_path)

    for target_path in target_dir.iterdir():
        if not target_path.is_file():
            continue
        if target_path.name == generated_filename:
            continue
        if target_path.suffix.lower() not in {".yml", ".yaml"}:
            continue
        if target_path.name not in expected_files:
            target_path.unlink()


def yaml_load(text: str) -> Any:
    if not text.strip():
        return None
    return yaml.safe_load(text)


def yaml_dump(data: Any) -> str:
    return yaml.safe_dump(data, sort_keys=False, default_flow_style=False, allow_unicode=True).rstrip()


def deep_merge_dicts(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    for key, value in overlay.items():
        if isinstance(base.get(key), dict) and isinstance(value, dict):
            deep_merge_dicts(base[key], value)
        else:
            base[key] = value
    return base


def oidc_cookie_prefix(name: Any) -> str:
    candidate = str(name or "").strip()
    if not candidate:
        return "TraefikOidcAuth"
    return candidate


def normalize_oidc_middleware_config(config: dict[str, Any]) -> dict[str, Any]:
    plugin_config = config.get("oidc-authentication")
    if not isinstance(plugin_config, dict):
        return config

    normalized = dict(plugin_config)
    provider = dict(normalized.get("Provider") or {})
    if provider:
        if "UsePkce" in normalized and "UsePkce" not in provider:
            provider["UsePkce"] = normalized.pop("UsePkce")
        if "TokenValidation" in normalized and "TokenValidation" not in provider:
            provider["TokenValidation"] = normalized.pop("TokenValidation")
        if provider.get("UsePkce") is False:
            provider.pop("UsePkce", None)
        if provider.get("TokenValidation") == "IdToken":
            provider.pop("TokenValidation", None)
        normalized["Provider"] = provider

    legacy_urls = normalized.pop("Urls", None)
    if isinstance(legacy_urls, dict):
        callback_uri = str(legacy_urls.get("Callback") or "").strip()
        logout_uri = str(legacy_urls.get("Logout") or "").strip()
        post_logout_redirect_uri = str(legacy_urls.get("PostLogoutRedirect") or "").strip()
        if callback_uri and "CallbackUri" not in normalized:
            normalized["CallbackUri"] = callback_uri
        if logout_uri and "LogoutUri" not in normalized:
            normalized["LogoutUri"] = logout_uri
        if post_logout_redirect_uri and "PostLogoutRedirectUri" not in normalized:
            normalized["PostLogoutRedirectUri"] = post_logout_redirect_uri

    session_cookie = dict(normalized.get("SessionCookie") or {})
    if session_cookie:
        cookie_name = str(session_cookie.pop("Name", "")).strip()
        if cookie_name and "CookieNamePrefix" not in normalized:
            normalized["CookieNamePrefix"] = oidc_cookie_prefix(cookie_name)
        if session_cookie.get("Path") == "/":
            session_cookie.pop("Path", None)
        if session_cookie.get("Secure") is True:
            session_cookie.pop("Secure", None)
        if session_cookie.get("HttpOnly") is True:
            session_cookie.pop("HttpOnly", None)
        if session_cookie.get("SameSite") == "default":
            session_cookie.pop("SameSite", None)
        if session_cookie.get("MaxAge") == 0:
            session_cookie.pop("MaxAge", None)
        if session_cookie:
            normalized["SessionCookie"] = session_cookie
        else:
            normalized.pop("SessionCookie", None)

    if normalized.get("Scopes") == ["openid", "profile", "email"]:
        normalized.pop("Scopes", None)

    updated = dict(config)
    updated["oidc-authentication"] = normalized
    return updated


def parse_mapping_text_silent(raw_value: Any) -> dict[str, Any]:
    candidate = str(raw_value or "").strip()
    if not candidate:
        return {}
    try:
        value = yaml_load(candidate)
    except yaml.YAMLError:
        return {}
    return value if isinstance(value, dict) else {}


def parse_string_list_text_silent(raw_value: Any) -> list[str]:
    candidate = str(raw_value or "").strip()
    if not candidate:
        return []
    try:
        value = yaml_load(candidate)
    except yaml.YAMLError:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, str):
        return normalize_string_list(value)
    return []


def middleware_is_legacy_oidc(row: dict[str, Any]) -> bool:
    if str(row.get("type", "")).strip() != "plugin":
        return False
    config = parse_mapping_text_silent(row.get("config_json"))
    return "oidc-authentication" in config


def oidc_client_payload(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": int(row["id"]),
        "name": str(row["name"]),
        "description": str(row.get("description") or ""),
        "tags": parse_tags(row.get("tags")),
        "provider_url": str(row.get("provider_url") or ""),
        "client_id": str(row.get("client_id") or ""),
    }


def oidc_clients(snapshot: InventorySnapshot) -> list[dict[str, Any]]:
    clients = [oidc_client_payload(row) for row in snapshot.oidc_clients if row.get("enabled")]
    return sorted(clients, key=lambda row: (row["name"], row["id"]))


def render_oidc_client_middleware(
    row: dict[str, Any],
    *,
    issues: list[dict[str, str]],
) -> tuple[str, dict[str, Any], dict[str, Any]] | None:
    name = str(row["name"])
    provider_url = str(row.get("provider_url") or "").strip()
    client_id = str(row.get("client_id") or "").strip()
    if not provider_url or not client_id:
        issues.append(issue("error", f"oidc_clients.{name}", "missing_provider", "OIDC client requires provider_url and client_id."))
        return None

    middleware: dict[str, Any] = {
        "oidc-authentication": {
            "Provider": {
                "Url": provider_url,
                "ClientId": client_id,
            },
        }
    }
    if row.get("client_secret_ref"):
        middleware["oidc-authentication"]["Provider"]["ClientSecret"] = str(row["client_secret_ref"])
    if row.get("session_secret_ref"):
        middleware["oidc-authentication"]["Secret"] = str(row["session_secret_ref"])
    if row.get("callback_uri"):
        middleware["oidc-authentication"]["CallbackUri"] = str(row["callback_uri"])
    if row.get("logout_uri"):
        middleware["oidc-authentication"]["LogoutUri"] = str(row["logout_uri"])
    if row.get("post_logout_redirect_uri"):
        middleware["oidc-authentication"]["PostLogoutRedirectUri"] = str(row["post_logout_redirect_uri"])
    if row.get("cookie_name_prefix"):
        middleware["oidc-authentication"]["CookieNamePrefix"] = str(row["cookie_name_prefix"])

    scopes = parse_string_list_text(row.get("scopes_json"), f"oidc_clients.{name}.scopes_json", issues)
    if scopes:
        middleware["oidc-authentication"]["Scopes"] = scopes

    extra = parse_mapping_text(row.get("extra_json"), f"oidc_clients.{name}.extra_json", issues)
    resolved, redacted = render_template_env_references(
        middleware,
        context=f"oidc_clients.{name}",
        issues=issues,
    )
    if extra:
        resolved_extra, redacted_extra = render_template_env_references(
            extra,
            context=f"oidc_clients.{name}.extra_json",
            issues=issues,
        )
        deep_merge_dicts(resolved["oidc-authentication"], resolved_extra)
        deep_merge_dicts(redacted["oidc-authentication"], redacted_extra)

    return name, normalize_oidc_middleware_config(resolved), normalize_oidc_middleware_config(redacted)


def normalize_string_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, str):
        return [part.strip() for part in re.split(r"[\n,]+", value) if part.strip()]
    candidate = str(value).strip()
    return [candidate] if candidate else []


def parse_tags(value: Any) -> list[str]:
    candidate = str(value or "").strip()
    if not candidate:
        return []
    try:
        loaded = yaml_load(candidate)
    except yaml.YAMLError:
        return [tag.lower() for tag in normalize_string_list(candidate)]
    if isinstance(loaded, list):
        return [str(item).strip().lower() for item in loaded if str(item).strip()]
    if isinstance(loaded, str):
        return [tag.lower() for tag in normalize_string_list(loaded)]
    return [tag.lower() for tag in normalize_string_list(candidate)]


def issue(severity: str, path: str, code: str, message: str) -> dict[str, str]:
    return {
        "severity": severity,
        "path": path,
        "code": code,
        "message": message,
    }


def slugify_name(value: str, fallback: str) -> str:
    cleaned = NAME_RE.sub("-", value.strip())
    candidate = cleaned.strip(".-").lower()
    return candidate or fallback


def router_name_for_site(site: dict[str, Any]) -> str:
    fallback = f"site-{site.get('id', 'x')}"
    return f"site-{slugify_name(str(site.get('name', '')), fallback)}"


def service_name_for_site(site: dict[str, Any]) -> str:
    fallback = f"service-{site.get('id', 'x')}"
    return f"service-{slugify_name(str(site.get('name', '')), fallback)}"


def router_name_for_stream(stream: dict[str, Any]) -> str:
    fallback = f"stream-{stream.get('id', 'x')}"
    return f"stream-{slugify_name(str(stream.get('name', '')), fallback)}"


def service_name_for_stream(stream: dict[str, Any]) -> str:
    fallback = f"stream-service-{stream.get('id', 'x')}"
    return f"stream-service-{slugify_name(str(stream.get('name', '')), fallback)}"


def normalize_path_prefix(value: str) -> str:
    trimmed = value.strip()
    if not trimmed:
        return ""
    return trimmed if trimmed.startswith("/") else f"/{trimmed}"


def split_host_values(value: str) -> list[str]:
    parts = [part.strip() for part in re.split(r"[\n,]+", value) if part.strip()]
    deduped: list[str] = []
    for part in parts:
        if part not in deduped:
            deduped.append(part)
    return deduped


def parse_inline_or_yaml_string_list(raw_value: Any) -> list[str]:
    candidate = str(raw_value or "").strip()
    if not candidate:
        return []
    try:
        loaded = yaml_load(candidate)
    except yaml.YAMLError:
        loaded = candidate

    items = normalize_string_list(loaded)
    deduped: list[str] = []
    for item in items:
        if item not in deduped:
            deduped.append(item)
    return deduped


def generated_stream_rule(sni_host: str) -> str:
    hosts = parse_inline_or_yaml_string_list(sni_host)
    if not hosts:
        return "HostSNI(``)"
    if len(hosts) == 1:
        return f"HostSNI(`{hosts[0]}`)"
    return " || ".join(f"HostSNI(`{current}`)" for current in hosts)


def generated_rule(host: str, path_prefix: str | None) -> str:
    hosts = split_host_values(host)
    if not hosts:
        host_rule = "Host(``)"
    elif len(hosts) == 1:
        host_rule = f"Host(`{hosts[0]}`)"
    else:
        host_rule = " || ".join(f"Host(`{current}`)" for current in hosts)
    prefix = normalize_path_prefix(path_prefix or "")
    if not prefix:
        return host_rule
    if len(hosts) > 1:
        return f"({host_rule}) && PathPrefix(`{prefix}`)"
    return f"{host_rule} && PathPrefix(`{prefix}`)"


def parse_mapping_text(raw_value: Any, context: str, issues: list[dict[str, str]]) -> dict[str, Any]:
    candidate = str(raw_value or "").strip()
    if not candidate:
        return {}
    try:
        value = yaml_load(candidate)
    except yaml.YAMLError as exc:
        issues.append(issue("error", context, "invalid_mapping", str(exc)))
        return {}
    if value is None:
        return {}
    if not isinstance(value, dict):
        issues.append(issue("error", context, "invalid_mapping", "Expected an object/mapping value."))
        return {}
    return value


def parse_string_list_text(raw_value: Any, context: str, issues: list[dict[str, str]]) -> list[str]:
    candidate = str(raw_value or "").strip()
    if not candidate:
        return []
    try:
        value = yaml_load(candidate)
    except yaml.YAMLError as exc:
        issues.append(issue("error", context, "invalid_list", str(exc)))
        return []
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, str):
        return normalize_string_list(value)
    issues.append(issue("error", context, "invalid_list", "Expected a list or string value."))
    return []


def render_env_template(name: str) -> tuple[str, str | None]:
    candidate = name.strip()
    if not candidate:
        return "", "empty environment variable reference"
    if any(char in candidate for char in {'"', "\n", "\r"}):
        return "", f"invalid environment variable reference {candidate!r}"
    return '{{ env "' + candidate + '" }}', None


def render_template_env_references(
    value: Any,
    *,
    context: str,
    issues: list[dict[str, str]],
) -> tuple[Any, Any]:
    if isinstance(value, dict):
        resolved: dict[str, Any] = {}
        redacted: dict[str, Any] = {}
        for key, nested in value.items():
            child_context = f"{context}.{key}" if context else str(key)
            resolved_value, redacted_value = render_template_env_references(
                nested,
                context=child_context,
                issues=issues,
            )
            resolved[key] = resolved_value
            redacted[key] = redacted_value
        return resolved, redacted

    if isinstance(value, list):
        resolved_items: list[Any] = []
        redacted_items: list[Any] = []
        for index, nested in enumerate(value):
            child_context = f"{context}[{index}]"
            resolved_value, redacted_value = render_template_env_references(
                nested,
                context=child_context,
                issues=issues,
            )
            resolved_items.append(resolved_value)
            redacted_items.append(redacted_value)
        return resolved_items, redacted_items

    if isinstance(value, str):
        if value.startswith(ENV_REF_PREFIX):
            rendered_value, error_text = render_env_template(value[len(ENV_REF_PREFIX):])
            if error_text is not None:
                issues.append(issue("error", context, "invalid_env_reference", error_text))
                return value, value
            return rendered_value, rendered_value
        if value.startswith(SECRET_REF_PREFIX):
            rendered_value, error_text = render_env_template(value[len(SECRET_REF_PREFIX):])
            if error_text is not None:
                issues.append(issue("error", context, "invalid_env_reference", error_text))
                return value, value
            return rendered_value, rendered_value

    return value, value


def find_placeholder_paths(value: Any, path: str = "") -> list[str]:
    matches: list[str] = []
    if isinstance(value, dict):
        for key, nested in value.items():
            child_path = f"{path}.{key}" if path else str(key)
            matches.extend(find_placeholder_paths(nested, child_path))
        return matches
    if isinstance(value, list):
        for index, nested in enumerate(value):
            child_path = f"{path}[{index}]" if path else f"[{index}]"
            matches.extend(find_placeholder_paths(nested, child_path))
        return matches
    if isinstance(value, str) and "REPLACE_WITH_" in value:
        matches.append(path or "<value>")
    return matches


def enabled_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [row for row in rows if row.get("enabled")]


def entrypoint_supports_tls(row: dict[str, Any]) -> bool:
    name = str(row.get("name", "")).strip().lower()
    address = str(row.get("address", "")).strip().lower()
    return name == "websecure" or address.endswith(":443") or address == ":443"


def default_entrypoint_rows(snapshot: InventorySnapshot) -> list[dict[str, Any]]:
    enabled = enabled_rows(snapshot.entrypoints)
    marked_default = [row for row in enabled if row.get("as_default")]
    if marked_default:
        return marked_default
    websecure = [row for row in enabled if str(row.get("name", "")).strip() == "websecure"]
    if websecure:
        return websecure
    return enabled


def enabled_cert_resolvers(snapshot: InventorySnapshot) -> list[dict[str, Any]]:
    return enabled_rows(snapshot.cert_resolvers)


def default_cert_resolver_row(snapshot: InventorySnapshot) -> dict[str, Any] | None:
    cert_resolvers = enabled_cert_resolvers(snapshot)
    return cert_resolvers[0] if len(cert_resolvers) == 1 else None


def entrypoint_tls_defaults(row: dict[str, Any], issues: list[dict[str, str]]) -> dict[str, Any]:
    http_options = parse_mapping_text(
        row.get("http_options_json"),
        f"entrypoints.{row.get('name', '')}.http_options_json",
        issues,
    )
    tls_options = http_options.get("tls")
    if not isinstance(tls_options, dict):
        return {}

    defaults: dict[str, Any] = {}
    cert_resolver = str(tls_options.get("certResolver", "")).strip()
    if cert_resolver:
        defaults["certResolver"] = cert_resolver

    domains = tls_options.get("domains")
    if isinstance(domains, list) and domains:
        resolved_domains: list[dict[str, Any]] = []
        for item in domains:
            if isinstance(item, dict) and str(item.get("main", "")).strip():
                domain_item: dict[str, Any] = {"main": str(item["main"]).strip()}
                sans = item.get("sans")
                if isinstance(sans, list):
                    domain_item["sans"] = [str(value).strip() for value in sans if str(value).strip()]
                resolved_domains.append(domain_item)
        if resolved_domains:
            defaults["domains"] = resolved_domains
    return defaults


def managed_dashboard_host(snapshot: InventorySnapshot, issues: list[dict[str, str]]) -> str:
    explicit = SETTINGS.dashboard_host.strip()
    if explicit:
        return explicit

    for row in default_entrypoint_rows(snapshot):
        defaults = entrypoint_tls_defaults(row, issues)
        for domain in defaults.get("domains", []):
            if not isinstance(domain, dict):
                continue
            main = str(domain.get("main", "")).strip()
            if main:
                return f"traefik.{main}"
    return ""


def quick_defaults(snapshot: InventorySnapshot) -> dict[str, Any]:
    entrypoints = default_entrypoint_rows(snapshot)
    default_cert_resolver = default_cert_resolver_row(snapshot)
    return {
        "entrypoints": [{"id": int(row["id"]), "name": str(row["name"])} for row in entrypoints],
        "entrypoint_names": [str(row["name"]) for row in entrypoints],
        "tls_enabled": bool(
            entrypoints
            and any(entrypoint_supports_tls(row) for row in entrypoints)
            and default_cert_resolver is not None
        ),
        "cert_resolver_id": int(default_cert_resolver["id"]) if default_cert_resolver else None,
        "cert_resolver_name": str(default_cert_resolver["name"]) if default_cert_resolver else None,
    }


def auth_presets(snapshot: InventorySnapshot) -> list[dict[str, Any]]:
    return [
        {
            "id": row["id"],
            "name": row["name"],
            "type": "oidc",
            "description": row["description"],
            "tags": row["tags"],
        }
        for row in oidc_clients(snapshot)
    ]


def site_scoped_issues(site_name: str, issues: list[dict[str, str]], *, prefix: str = "sites") -> list[dict[str, str]]:
    prefix = f"{prefix}.{site_name}"
    return [
        current
        for current in issues
        if str(current.get("path", "")) == prefix or str(current.get("path", "")).startswith(f"{prefix}.")
    ]


def site_linked_rows(
    mapping: dict[int, list[dict[str, Any]]],
    site_id: int,
    rows_by_id: dict[int, dict[str, Any]],
) -> list[dict[str, Any]]:
    linked_rows: list[dict[str, Any]] = []
    for linked in mapping.get(site_id, []):
        row = rows_by_id.get(int(linked["id"]))
        if row:
            linked_rows.append(row)
    return linked_rows


def site_advanced_config_present(
    site: dict[str, Any],
    *,
    linked_entrypoints: list[dict[str, Any]],
    non_auth_middlewares: list[dict[str, Any]],
    default_entrypoint_ids: set[int],
) -> bool:
    if site.get("priority") is not None:
        return True
    if bool(site.get("pass_host_header", True)) is not True:
        return True
    if site.get("tls_options") is not None or site.get("servers_transport") is not None:
        return True
    for column in (
        "healthcheck_json",
        "rule_override",
        "extra_router_json",
        "extra_service_json",
        "notes",
    ):
        if str(site.get(column) or "").strip():
            return True
    if non_auth_middlewares:
        return True
    if linked_entrypoints and {int(row["id"]) for row in linked_entrypoints} != default_entrypoint_ids:
        return True
    return False


def extract_runtime_item(mapping: Any, object_name: str) -> tuple[str, dict[str, Any] | None]:
    if not isinstance(mapping, dict):
        return "", None
    if object_name in mapping and isinstance(mapping[object_name], dict):
        return object_name, mapping[object_name]
    for key, value in mapping.items():
        if str(key).split("@", 1)[0] == object_name and isinstance(value, dict):
            return str(key), value
    return "", None


def stringify_runtime_errors(raw_errors: Any) -> list[str]:
    if not isinstance(raw_errors, list):
        return []
    values: list[str] = []
    for item in raw_errors:
        if isinstance(item, str):
            candidate = item.strip()
        else:
            candidate = json.dumps(item, sort_keys=True)
        if candidate:
            values.append(candidate)
    return values


def upstream_health(url: str) -> dict[str, Any]:
    with UPSTREAM_HEALTH_LOCK:
        cached = UPSTREAM_HEALTH_CACHE.get(url)
        if cached and (time.time() - float(cached["checked_at_epoch"])) < UPSTREAM_HEALTH_TTL_SECONDS:
            return dict(cached["payload"])

    checked_at = utc_timestamp()
    parsed = urlparse(url)
    scheme = parsed.scheme.lower()
    host = parsed.hostname or ""
    port = parsed.port or (443 if scheme == "https" else 80 if scheme == "http" else None)
    payload = {
        "ok": None,
        "url": url,
        "scheme": scheme,
        "host": host,
        "port": port,
        "latency_ms": None,
        "checked_at": checked_at,
        "error": "",
    }

    if scheme not in {"http", "https"} or not host or port is None:
        payload["ok"] = False
        payload["error"] = "Expected an http(s) upstream URL with a host."
    else:
        start = time.perf_counter()
        try:
            with socket.create_connection((host, port), timeout=UPSTREAM_HEALTH_TIMEOUT_SECONDS):
                pass
        except OSError as exc:
            payload["ok"] = False
            payload["error"] = str(exc)
        else:
            payload["ok"] = True
            payload["latency_ms"] = round((time.perf_counter() - start) * 1000, 1)

    with UPSTREAM_HEALTH_LOCK:
        UPSTREAM_HEALTH_CACHE[url] = {
            "checked_at_epoch": time.time(),
            "payload": dict(payload),
        }
    return payload


def serialize_named_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [dict(row) for row in rows]


def serialize_deployments(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    serialized: list[dict[str, Any]] = []
    for row in rows:
        payload = dict(row)
        created_at = payload.get("created_at")
        if isinstance(created_at, datetime):
            payload["created_at"] = created_at.astimezone(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")
        serialized.append(payload)
    return serialized


def render_dynamic_config(snapshot: InventorySnapshot) -> tuple[str, str, dict[str, Any], list[dict[str, str]]]:
    issues: list[dict[str, str]] = []

    entrypoints_by_id = {int(row["id"]): row for row in snapshot.entrypoints}
    cert_resolvers_by_id = {int(row["id"]): row for row in snapshot.cert_resolvers}
    tls_options_by_id = {int(row["id"]): row for row in snapshot.tls_options}
    servers_transports_by_id = {int(row["id"]): row for row in snapshot.servers_transports}
    middlewares_by_id = {int(row["id"]): row for row in snapshot.middlewares}
    default_cert_resolver = default_cert_resolver_row(snapshot)

    enabled_entrypoint_names = [str(row["name"]) for row in snapshot.entrypoints if row.get("enabled")]
    default_entrypoint_names = [str(row["name"]) for row in snapshot.entrypoints if row.get("enabled") and row.get("as_default")]
    fallback_entrypoints = default_entrypoint_names or enabled_entrypoint_names

    rendered_middlewares: dict[str, Any] = {}
    redacted_middlewares: dict[str, Any] = {}
    for row in snapshot.middlewares:
        if not row.get("enabled"):
            continue
        if middleware_is_legacy_oidc(row):
            continue
        name = str(row["name"])
        rendered_middleware = render_middleware_row(
            row,
            issues=issues,
            parse_mapping_text=parse_mapping_text,
            render_template_env_references=lambda value, *, _name=name: render_template_env_references(
                value,
                context=f"middlewares.{_name}.config_json",
                issues=issues,
            ),
            find_placeholder_paths=find_placeholder_paths,
            issue_factory=issue,
            normalize_plugin_config=normalize_oidc_middleware_config,
        )
        if rendered_middleware is None:
            continue
        rendered_name, resolved_middleware, redacted_middleware = rendered_middleware
        rendered_middlewares[rendered_name] = resolved_middleware
        redacted_middlewares[rendered_name] = redacted_middleware

    oidc_clients_by_id = {int(row["id"]): row for row in snapshot.oidc_clients}
    for row in snapshot.oidc_clients:
        if not row.get("enabled"):
            continue
        if str(row["name"]) in rendered_middlewares:
            issues.append(issue("error", f"oidc_clients.{row['name']}", "middleware_name_conflict", "OIDC client name conflicts with an existing middleware name."))
            continue
        rendered = render_oidc_client_middleware(row, issues=issues)
        if rendered is None:
            continue
        name, resolved_config, redacted_config = rendered
        rendered_middlewares[name] = {"plugin": resolved_config}
        redacted_middlewares[name] = {"plugin": redacted_config}

    rendered_tls_options: dict[str, Any] = {}
    redacted_tls_options: dict[str, Any] = {}
    for row in snapshot.tls_options:
        if not row.get("enabled"):
            continue
        name, tls_option, redacted_tls_option = render_tls_option_row(
            row,
            issues=issues,
            parse_mapping_text=parse_mapping_text,
            parse_string_list_text=parse_string_list_text,
            render_template_env_references=lambda value, *, _name=str(row["name"]): render_template_env_references(
                value,
                context=f"tls_options.{_name}.client_auth_json",
                issues=issues,
            ),
        )
        extra = parse_mapping_text(row.get("extra_json"), f"tls_options.{name}.extra_json", issues)
        if extra:
            resolved_extra, redacted_extra = render_template_env_references(
                extra,
                context=f"tls_options.{name}.extra_json",
                issues=issues,
            )
            deep_merge_dicts(tls_option, resolved_extra)
            deep_merge_dicts(redacted_tls_option, redacted_extra)
        rendered_tls_options[name] = tls_option
        redacted_tls_options[name] = redacted_tls_option

    rendered_servers_transports: dict[str, Any] = {}
    redacted_servers_transports: dict[str, Any] = {}
    for row in snapshot.servers_transports:
        if not row.get("enabled"):
            continue
        name, transport, redacted_transport = render_servers_transport_row(
            row,
            issues=issues,
            parse_mapping_text=parse_mapping_text,
            parse_string_list_text=parse_string_list_text,
            render_template_env_references=lambda value, *, _name=str(row["name"]): render_template_env_references(
                value,
                context=f"servers_transports.{_name}.forwarding_timeouts_json",
                issues=issues,
            ),
        )
        extra = parse_mapping_text(row.get("extra_json"), f"servers_transports.{name}.extra_json", issues)
        if extra:
            resolved_extra, redacted_extra = render_template_env_references(
                extra,
                context=f"servers_transports.{name}.extra_json",
                issues=issues,
            )
            deep_merge_dicts(transport, resolved_extra)
            deep_merge_dicts(redacted_transport, redacted_extra)
        rendered_servers_transports[name] = transport
        redacted_servers_transports[name] = redacted_transport

    routers: dict[str, Any] = {}
    services: dict[str, Any] = {}
    redacted_routers: dict[str, Any] = {}
    redacted_services: dict[str, Any] = {}
    tcp_routers: dict[str, Any] = {}
    tcp_services: dict[str, Any] = {}
    redacted_tcp_routers: dict[str, Any] = {}
    redacted_tcp_services: dict[str, Any] = {}

    enabled_site_count = 0
    enabled_stream_count = 0
    for site in snapshot.sites:
        if not site.get("enabled"):
            continue
        enabled_site_count += 1
        site_name = str(site["name"])
        site_id = int(site["id"])
        router_name = router_name_for_site(site)
        service_name = service_name_for_site(site)
        host = str(site.get("host", "")).strip()
        upstream_url = str(site.get("upstream_url", "")).strip()

        if not host:
            issues.append(issue("error", f"sites.{site_name}.host", "missing_host", "Enabled site is missing host."))
            continue
        if not upstream_url:
            issues.append(issue("error", f"sites.{site_name}.upstream_url", "missing_upstream", "Enabled site is missing upstream_url."))
            continue
        if router_name in routers:
            issues.append(issue("error", f"sites.{site_name}.name", "router_name_conflict", f"Generated router name {router_name} conflicts with another site."))
            continue
        if service_name in services:
            issues.append(issue("error", f"sites.{site_name}.name", "service_name_conflict", f"Generated service name {service_name} conflicts with another site."))
            continue

        site_entrypoints = snapshot.site_entrypoints.get(site_id, [])
        resolved_entrypoints: list[str] = []
        for linked in site_entrypoints:
            entrypoint_row = entrypoints_by_id.get(int(linked["id"]))
            if not entrypoint_row or not entrypoint_row.get("enabled"):
                issues.append(issue("warning", f"sites.{site_name}.entrypoints", "missing_entrypoint", f"Skipping unavailable entrypoint {linked['name']}."))
                continue
            resolved_entrypoints.append(str(entrypoint_row["name"]))
        if not resolved_entrypoints:
            resolved_entrypoints = list(fallback_entrypoints)
        if not resolved_entrypoints:
            issues.append(issue("error", f"sites.{site_name}.entrypoints", "no_entrypoints", "No enabled entrypoints are available for this site."))
            continue

        resolved_middlewares: list[str] = []
        for linked in snapshot.site_middlewares.get(site_id, []):
            middleware_row = middlewares_by_id.get(int(linked["id"]))
            if not middleware_row or not middleware_row.get("enabled"):
                issues.append(issue("warning", f"sites.{site_name}.middlewares", "missing_middleware", f"Skipping unavailable middleware {linked['name']}."))
                continue
            if middleware_is_legacy_oidc(middleware_row):
                continue
            middleware_name = str(middleware_row["name"])
            if middleware_name not in rendered_middlewares:
                issues.append(
                    issue(
                        "warning",
                        f"sites.{site_name}.middlewares",
                        "invalid_middleware",
                        f"Skipping middleware {middleware_name} because its rendered config is invalid.",
                    )
                )
                continue
            resolved_middlewares.append(middleware_name)
        oidc_client_id = site.get("oidc_client")
        if oidc_client_id is not None:
            oidc_client_row = oidc_clients_by_id.get(int(oidc_client_id))
            if oidc_client_row and oidc_client_row.get("enabled"):
                resolved_middlewares.append(str(oidc_client_row["name"]))
            else:
                issues.append(issue("warning", f"sites.{site_name}.oidc_client", "missing_oidc_client", "Linked OIDC client is unavailable and will be omitted."))

        router: dict[str, Any] = {
            "rule": str(site["rule_override"]).strip() if str(site.get("rule_override") or "").strip() else generated_rule(host, str(site.get("path_prefix") or "")),
            "service": service_name,
            "entryPoints": resolved_entrypoints,
        }
        if resolved_middlewares:
            router["middlewares"] = resolved_middlewares
        if site.get("priority") is not None:
            router["priority"] = int(site["priority"])

        if site.get("tls_enabled", False):
            tls_config: dict[str, Any] = {}
            cert_resolver_id = site.get("cert_resolver")
            if cert_resolver_id is not None:
                cert_resolver_row = cert_resolvers_by_id.get(int(cert_resolver_id))
                if cert_resolver_row and cert_resolver_row.get("enabled"):
                    tls_config["certResolver"] = str(cert_resolver_row["name"])
                else:
                    issues.append(issue("warning", f"sites.{site_name}.cert_resolver", "missing_cert_resolver", "Linked cert resolver is unavailable and will be omitted."))
            tls_option_id = site.get("tls_options")
            if tls_option_id is not None:
                tls_option_row = tls_options_by_id.get(int(tls_option_id))
                if tls_option_row and tls_option_row.get("enabled"):
                    tls_config["options"] = str(tls_option_row["name"])
                else:
                    issues.append(issue("warning", f"sites.{site_name}.tls_options", "missing_tls_option", "Linked TLS options record is unavailable and will be omitted."))
            router["tls"] = tls_config if tls_config else {}

        extra_router = parse_mapping_text(site.get("extra_router_json"), f"sites.{site_name}.extra_router_json", issues)
        redacted_router = dict(router)
        if extra_router:
            resolved_extra_router, redacted_extra_router = render_template_env_references(
                extra_router,
                context=f"sites.{site_name}.extra_router_json",
                issues=issues,
            )
            deep_merge_dicts(router, resolved_extra_router)
            deep_merge_dicts(redacted_router, redacted_extra_router)
        routers[router_name] = router
        redacted_routers[router_name] = redacted_router

        load_balancer: dict[str, Any] = {
            "servers": [{"url": upstream_url}],
            "passHostHeader": bool(site.get("pass_host_header", True)),
        }
        redacted_load_balancer: dict[str, Any] = {
            "servers": [{"url": upstream_url}],
            "passHostHeader": bool(site.get("pass_host_header", True)),
        }
        transport_id = site.get("servers_transport")
        if transport_id is not None:
            transport_row = servers_transports_by_id.get(int(transport_id))
            if transport_row and transport_row.get("enabled"):
                load_balancer["serversTransport"] = str(transport_row["name"])
                redacted_load_balancer["serversTransport"] = str(transport_row["name"])
            else:
                issues.append(issue("warning", f"sites.{site_name}.servers_transport", "missing_transport", "Linked servers transport is unavailable and will be omitted."))
        health_check = parse_mapping_text(site.get("healthcheck_json"), f"sites.{site_name}.healthcheck_json", issues)
        if health_check:
            resolved_health_check, redacted_health_check = render_template_env_references(
                health_check,
                context=f"sites.{site_name}.healthcheck_json",
                issues=issues,
            )
            load_balancer["healthCheck"] = resolved_health_check
            redacted_load_balancer["healthCheck"] = redacted_health_check

        service: dict[str, Any] = {"loadBalancer": load_balancer}
        redacted_service: dict[str, Any] = {"loadBalancer": redacted_load_balancer}
        extra_service = parse_mapping_text(site.get("extra_service_json"), f"sites.{site_name}.extra_service_json", issues)
        if extra_service:
            resolved_extra_service, redacted_extra_service = render_template_env_references(
                extra_service,
                context=f"sites.{site_name}.extra_service_json",
                issues=issues,
            )
            deep_merge_dicts(service, resolved_extra_service)
            deep_merge_dicts(redacted_service, redacted_extra_service)
        services[service_name] = service
        redacted_services[service_name] = redacted_service

    for stream in snapshot.streams:
        if not stream.get("enabled"):
            continue
        enabled_stream_count += 1
        stream_name = str(stream["name"])
        stream_id = int(stream["id"])
        router_name = router_name_for_stream(stream)
        service_name = service_name_for_stream(stream)
        sni_hosts = parse_inline_or_yaml_string_list(stream.get("sni_host"))
        upstream_addresses = parse_inline_or_yaml_string_list(stream.get("upstream_address"))

        if not sni_hosts:
            issues.append(issue("error", f"streams.{stream_name}.sni_host", "missing_sni_host", "Enabled stream is missing sni_host."))
            continue
        if not upstream_addresses:
            issues.append(issue("error", f"streams.{stream_name}.upstream_address", "missing_upstream", "Enabled stream is missing upstream_address."))
            continue
        if router_name in tcp_routers:
            issues.append(issue("error", f"streams.{stream_name}.name", "router_name_conflict", f"Generated TCP router name {router_name} conflicts with another stream."))
            continue
        if service_name in tcp_services:
            issues.append(issue("error", f"streams.{stream_name}.name", "service_name_conflict", f"Generated TCP service name {service_name} conflicts with another stream."))
            continue

        stream_entrypoints = snapshot.stream_entrypoints.get(stream_id, [])
        resolved_entrypoints: list[str] = []
        for linked in stream_entrypoints:
            entrypoint_row = entrypoints_by_id.get(int(linked["id"]))
            if not entrypoint_row or not entrypoint_row.get("enabled"):
                issues.append(issue("warning", f"streams.{stream_name}.entrypoints", "missing_entrypoint", f"Skipping unavailable entrypoint {linked['name']}."))
                continue
            resolved_entrypoints.append(str(entrypoint_row["name"]))
        if not resolved_entrypoints:
            issues.append(issue("error", f"streams.{stream_name}.entrypoints", "no_entrypoints", "No enabled entrypoints are linked for this stream."))
            continue

        router = {
            "rule": str(stream["rule_override"]).strip() if str(stream.get("rule_override") or "").strip() else generated_stream_rule(stream.get("sni_host")),
            "service": service_name,
            "entryPoints": resolved_entrypoints,
            "tls": {"passthrough": True},
        }
        if stream.get("priority") is not None:
            router["priority"] = int(stream["priority"])

        extra_router = parse_mapping_text(stream.get("extra_router_json"), f"streams.{stream_name}.extra_router_json", issues)
        redacted_router = dict(router)
        if extra_router:
            resolved_extra_router, redacted_extra_router = render_template_env_references(
                extra_router,
                context=f"streams.{stream_name}.extra_router_json",
                issues=issues,
            )
            deep_merge_dicts(router, resolved_extra_router)
            deep_merge_dicts(redacted_router, redacted_extra_router)
        tcp_routers[router_name] = router
        redacted_tcp_routers[router_name] = redacted_router

        load_balancer = {
            "servers": [{"address": address} for address in upstream_addresses],
        }
        redacted_load_balancer = {
            "servers": [{"address": address} for address in upstream_addresses],
        }
        transport_id = stream.get("servers_transport")
        if transport_id is not None:
            transport_row = servers_transports_by_id.get(int(transport_id))
            if transport_row and transport_row.get("enabled"):
                load_balancer["serversTransport"] = str(transport_row["name"])
                redacted_load_balancer["serversTransport"] = str(transport_row["name"])
            else:
                issues.append(issue("warning", f"streams.{stream_name}.servers_transport", "missing_transport", "Linked servers transport is unavailable and will be omitted."))

        service = {"loadBalancer": load_balancer}
        redacted_service = {"loadBalancer": redacted_load_balancer}
        extra_service = parse_mapping_text(stream.get("extra_service_json"), f"streams.{stream_name}.extra_service_json", issues)
        if extra_service:
            resolved_extra_service, redacted_extra_service = render_template_env_references(
                extra_service,
                context=f"streams.{stream_name}.extra_service_json",
                issues=issues,
            )
            deep_merge_dicts(service, resolved_extra_service)
            deep_merge_dicts(redacted_service, redacted_extra_service)
        tcp_services[service_name] = service
        redacted_tcp_services[service_name] = redacted_service

    rendered, redacted_rendered = build_render_payloads(
        routers=routers,
        services=services,
        middlewares=rendered_middlewares,
        servers_transports=rendered_servers_transports,
        tcp_routers=tcp_routers,
        tcp_services=tcp_services,
        tls_options=rendered_tls_options,
        redacted_routers=redacted_routers,
        redacted_services=redacted_services,
        redacted_middlewares=redacted_middlewares,
        redacted_servers_transports=redacted_servers_transports,
        redacted_tcp_routers=redacted_tcp_routers,
        redacted_tcp_services=redacted_tcp_services,
        redacted_tls_options=redacted_tls_options,
    )

    final_payload = rendered if rendered else {"http": {}}
    redacted_final_payload = redacted_rendered if redacted_rendered else {"http": {}}
    rendered_text = f"{GENERATED_FILE_BANNER}\n\n{yaml_dump(final_payload)}\n"
    redacted_rendered_text = f"{GENERATED_FILE_BANNER}\n\n{yaml_dump(redacted_final_payload)}\n"
    summary = build_render_summary(
        enabled_site_count=enabled_site_count,
        enabled_stream_count=enabled_stream_count,
        routers=routers,
        services=services,
        tcp_routers=tcp_routers,
        tcp_services=tcp_services,
        middlewares=rendered_middlewares,
        servers_transports=rendered_servers_transports,
        tls_options=rendered_tls_options,
    )
    return rendered_text, redacted_rendered_text, summary, issues


@dataclass
class StaticSyncResult:
    changed: bool
    checksum: str
    entrypoint_count: int
    cert_resolver_count: int


class SyncService:
    def __init__(self, settings: ControlPlaneConfig) -> None:
        self.settings = settings
        self._state_lock = RLock()
        self._sync_lock = Lock()
        self._loop_started = False
        self._thread: Thread | None = None
        self._last_inventory: InventorySnapshot | None = None
        self._last_issues: list[dict[str, str]] = []
        self._last_render_summary: dict[str, Any] = {}
        self._last_state: dict[str, Any] | None = None
        self._last_rendered_text = ""
        self._last_render_checksum = ""
        self._last_static_checksum = ""
        self._last_error_signature = ""
        self._sync_status: dict[str, Any] = {
            "started_at": utc_timestamp(),
            "last_cycle_started_at": None,
            "last_cycle_finished_at": None,
            "last_cycle_reason": "",
            "last_static_sync_at": None,
            "last_static_sync_changed": False,
            "last_static_checksum": "",
            "last_render_at": None,
            "last_render_changed": False,
            "last_render_checksum": "",
            "last_error": "",
        }

    def start(self) -> None:
        with self._state_lock:
            if self._loop_started:
                return
            self._loop_started = True
            self._thread = Thread(target=self._run_loop, daemon=True, name="traefik-db-sync")
            self._thread.start()

    def _run_loop(self) -> None:
        while True:
            try:
                self.sync_once(reason="poll")
            except Exception as exc:  # noqa: BLE001
                self._record_failure(str(exc))
            time.sleep(self.settings.sync_interval_seconds)

    def sync_once(self, *, reason: str, force_static: bool = False) -> dict[str, Any]:
        with self._sync_lock:
            started_at = utc_timestamp()
            with self._state_lock:
                self._sync_status["last_cycle_started_at"] = started_at
                self._sync_status["last_cycle_reason"] = reason

            try:
                issues: list[dict[str, str]] = []
                sync_user_dynamic_snippets(
                    config_root=self.settings.config_root,
                    runtime_root=self.settings.runtime_root,
                    generated_filename=self.settings.generated_config_path.name,
                )
                static_result = self._sync_static_catalog(force=force_static, issues=issues)

                inventory = fetch_inventory(self.settings.database_dsn)
                rendered_text, redacted_rendered_text, render_summary, render_issues = render_dynamic_config(inventory)
                issues.extend(render_issues)

                checksum = sha256_text(rendered_text)
                current_disk_text = self.settings.generated_config_path.read_text(encoding="utf-8") if self.settings.generated_config_path.exists() else ""
                render_changed = checksum != self._last_render_checksum or current_disk_text != rendered_text

                if render_changed:
                    atomic_write(self.settings.generated_config_path, rendered_text)
                    record_deployment(
                        self.settings.database_dsn,
                        status="rendered",
                        checksum=checksum,
                        triggered_by=reason,
                        rendered_yaml=redacted_rendered_text,
                        notes="Generated from database state.",
                    )

                last_error = ""
                if issues:
                    last_error = "; ".join(item["message"] for item in issues if item["severity"] == "error")[:2000]
                    error_signature = sha256_text(json.dumps(issues, sort_keys=True))
                    if error_signature != self._last_error_signature:
                        record_deployment(
                            self.settings.database_dsn,
                            status="warning",
                            checksum=checksum,
                            triggered_by=reason,
                            rendered_yaml=redacted_rendered_text,
                            error_text=last_error,
                            notes="Rendered with sync issues.",
                        )
                    self._last_error_signature = error_signature
                else:
                    self._last_error_signature = ""

                refreshed_inventory = with_updated_deployments(
                    inventory,
                    fetch_recent_deployments(self.settings.database_dsn),
                )
                finished_at = utc_timestamp()
                with self._state_lock:
                    self._last_inventory = refreshed_inventory
                    self._last_issues = issues
                    self._last_render_summary = render_summary
                    self._last_rendered_text = redacted_rendered_text
                    self._last_render_checksum = checksum
                    self._sync_status.update(
                        {
                            "last_cycle_finished_at": finished_at,
                            "last_static_sync_at": self._sync_status["last_static_sync_at"],
                            "last_static_sync_changed": static_result.changed,
                            "last_static_checksum": static_result.checksum,
                            "last_render_at": finished_at,
                            "last_render_changed": render_changed,
                            "last_render_checksum": checksum,
                            "last_error": last_error,
                        }
                    )
                    self._last_state = self._build_state_payload(
                        refreshed_inventory,
                        issues=issues,
                        render_summary=render_summary,
                        rendered_text=redacted_rendered_text,
                        sync_status=dict(self._sync_status),
                    )
                return self.build_state()
            except Exception as exc:
                self._record_failure(str(exc))
                raise

    def _record_failure(self, message: str) -> None:
        with self._state_lock:
            self._sync_status["last_cycle_finished_at"] = utc_timestamp()
            self._sync_status["last_error"] = message
            if self._last_state is not None:
                self._last_state["sync"] = dict(self._sync_status)

    def _sync_static_catalog(self, *, force: bool, issues: list[dict[str, str]]) -> StaticSyncResult:
        static_path = self.settings.active_config_path
        if not static_path.exists():
            issues.append(issue("warning", "static.config", "missing_file", f"Static config file not found at {static_path}."))
            return StaticSyncResult(False, "", 0, 0)

        raw_text = static_path.read_text(encoding="utf-8")
        checksum = sha256_text(raw_text)
        if not force and checksum == self._last_static_checksum:
            return StaticSyncResult(False, checksum, 0, 0)

        try:
            loaded = yaml_load(raw_text) or {}
        except yaml.YAMLError as exc:
            issues.append(issue("error", "static.config", "invalid_yaml", str(exc)))
            return StaticSyncResult(False, checksum, 0, 0)
        if not isinstance(loaded, dict):
            issues.append(issue("error", "static.config", "invalid_shape", "Static config must be a YAML mapping/object."))
            return StaticSyncResult(False, checksum, 0, 0)

        entrypoints = parse_static_entrypoints(loaded, issues, issue_factory=issue)
        cert_resolvers = parse_static_cert_resolvers(loaded, issues, issue_factory=issue)
        replace_static_inventory(
            self.settings.database_dsn,
            entrypoints=entrypoints,
            cert_resolvers=cert_resolvers,
        )
        self._last_static_checksum = checksum
        self._sync_status["last_static_sync_at"] = utc_timestamp()
        return StaticSyncResult(True, checksum, len(entrypoints), len(cert_resolvers))

    def _build_state_payload(
        self,
        inventory: InventorySnapshot,
        *,
        issues: list[dict[str, str]],
        render_summary: dict[str, Any],
        rendered_text: str,
        sync_status: dict[str, Any],
    ) -> dict[str, Any]:
        defaults = quick_defaults(inventory)
        sites_payload: list[dict[str, Any]] = []
        streams_payload: list[dict[str, Any]] = []
        cert_resolvers_by_id = {int(row["id"]): row for row in inventory.cert_resolvers}
        tls_options_by_id = {int(row["id"]): row for row in inventory.tls_options}
        transports_by_id = {int(row["id"]): row for row in inventory.servers_transports}
        entrypoints_by_id = {int(row["id"]): row for row in inventory.entrypoints}
        middlewares_by_id = {int(row["id"]): row for row in inventory.middlewares}
        oidc_clients_by_id = {int(row["id"]): row for row in inventory.oidc_clients}
        default_entrypoint_ids = {int(row["id"]) for row in default_entrypoint_rows(inventory)}

        for site in inventory.sites:
            site_id = int(site["id"])
            site_name = str(site["name"])
            cert_resolver = cert_resolvers_by_id.get(int(site["cert_resolver"])) if site.get("cert_resolver") is not None else None
            tls_option = tls_options_by_id.get(int(site["tls_options"])) if site.get("tls_options") is not None else None
            transport = transports_by_id.get(int(site["servers_transport"])) if site.get("servers_transport") is not None else None
            oidc_client = oidc_clients_by_id.get(int(site["oidc_client"])) if site.get("oidc_client") is not None else None
            linked_entrypoints = site_linked_rows(inventory.site_entrypoints, site_id, entrypoints_by_id)
            linked_middlewares = site_linked_rows(inventory.site_middlewares, site_id, middlewares_by_id)
            non_auth_middlewares = [row for row in linked_middlewares if not middleware_is_legacy_oidc(row)]
            current_issues = site_scoped_issues(site_name, issues)
            resolved_entrypoints = [str(row["name"]) for row in linked_entrypoints] or list(defaults["entrypoint_names"])
            sites_payload.append(
                build_site_payload(
                    site,
                    router_name=router_name_for_site(site),
                    service_name=service_name_for_site(site),
                    resolved_rule=resolved_site_rule(
                        site,
                        generated_rule=generated_rule(
                            str(site.get("host", "")).strip(),
                            str(site.get("path_prefix") or ""),
                        ),
                    ),
                    resolved_entrypoints=resolved_entrypoints,
                    non_auth_middlewares=non_auth_middlewares,
                    cert_resolver=cert_resolver,
                    tls_option=tls_option,
                    transport=transport,
                    oidc_client=oidc_client,
                    has_advanced_config=site_advanced_config_present(
                        site,
                        linked_entrypoints=linked_entrypoints,
                        non_auth_middlewares=non_auth_middlewares,
                        default_entrypoint_ids=default_entrypoint_ids,
                    ),
                    site_issues=current_issues,
                )
            )

        for stream in inventory.streams:
            stream_id = int(stream["id"])
            stream_name = str(stream["name"])
            transport = transports_by_id.get(int(stream["servers_transport"])) if stream.get("servers_transport") is not None else None
            linked_entrypoints = site_linked_rows(inventory.stream_entrypoints, stream_id, entrypoints_by_id)
            current_issues = site_scoped_issues(stream_name, issues, prefix="streams")
            streams_payload.append(
                build_stream_payload(
                    stream,
                    router_name=router_name_for_stream(stream),
                    service_name=service_name_for_stream(stream),
                    resolved_rule=resolved_stream_rule(
                        stream,
                        generated_rule=generated_stream_rule(str(stream.get("sni_host", "")).strip()),
                    ),
                    entrypoints=[str(row["name"]) for row in linked_entrypoints],
                    transport=transport,
                    stream_issues=current_issues,
                )
            )

        return {
            "version": 4,
            "mode": "database-sync",
            "config_root": str(self.settings.config_root),
            "runtime_root": str(self.settings.runtime_root),
            "sites": sites_payload,
            "streams": streams_payload,
            "linked": {
                "middlewares": serialize_named_rows([row for row in inventory.middlewares if not middleware_is_legacy_oidc(row)]),
                "oidc_clients": serialize_named_rows(inventory.oidc_clients),
                "entrypoints": serialize_named_rows(inventory.entrypoints),
                "cert_resolvers": serialize_named_rows(inventory.cert_resolvers),
                "tls_options": serialize_named_rows(inventory.tls_options),
                "servers_transports": serialize_named_rows(inventory.servers_transports),
            },
            "quick": {
                "defaults": defaults,
                "oidc_clients": oidc_clients(inventory),
                "auth_presets": auth_presets(inventory),
            },
            "issues": issues,
            "runtime": self.settings.runtime_payload(),
            "metadata": {
                "editing_surface": "NocoDB",
                "managed_static_tables": ["entrypoints", "cert_resolvers"],
                "rendered_file_preview_bytes": len(rendered_text.encode("utf-8")) if rendered_text else 0,
            },
            "capabilities": self.settings.capabilities_payload(),
            "database": {
                "configured": True,
                "url": self.settings.database_dsn_display,
            },
            "sync": sync_status,
            "render": {
                "path": str(self.settings.generated_config_path),
                "checksum": sync_status.get("last_render_checksum", ""),
                **render_summary,
            },
            "deployments": serialize_deployments(inventory.deployments),
        }

    def build_state(self) -> dict[str, Any]:
        with self._state_lock:
            cached_state = self._last_state
            inventory = self._last_inventory
            issues = list(self._last_issues)
            render_summary = dict(self._last_render_summary)
            rendered_text = self._last_rendered_text
            sync_status = dict(self._sync_status)

        if cached_state is not None:
            return cached_state

        if inventory is None:
            inventory = fetch_inventory(self.settings.database_dsn)

        state = self._build_state_payload(
            inventory,
            issues=issues,
            render_summary=render_summary,
            rendered_text=rendered_text,
            sync_status=sync_status,
        )
        with self._state_lock:
            self._last_inventory = inventory
            self._last_state = state
        return state

    def get_runtime_payload(self) -> dict[str, Any]:
        snapshot = fetch_runtime_snapshot(self.settings.admin_api_endpoint)
        state = self.build_state()
        summary = summarize_runtime_snapshot(snapshot)
        rawdata = snapshot.get("rawdata", {}).get("value") if snapshot.get("rawdata", {}).get("ok") else {}
        http_section = rawdata.get("http", {}) if isinstance(rawdata, dict) else {}
        routers = http_section.get("routers", {}) if isinstance(http_section, dict) else {}
        services = http_section.get("services", {}) if isinstance(http_section, dict) else {}
        runtime_errors = stringify_runtime_errors(rawdata.get("errors")) if isinstance(rawdata, dict) else []

        site_statuses: list[dict[str, Any]] = []
        counts = {
            "healthy": 0,
            "degraded": 0,
            "disabled": 0,
        }
        for site in state["sites"]:
            router_key, router_value = extract_runtime_item(routers, str(site["router_name"]))
            service_key, service_value = extract_runtime_item(services, str(site["service_name"]))
            if site.get("enabled"):
                backend_health = upstream_health(str(site.get("upstream_url") or ""))
            else:
                backend_health = disabled_backend_health(
                    str(site.get("upstream_url") or ""),
                    checked_at=utc_timestamp(),
                )
            site_errors = site_runtime_errors(
                runtime_errors,
                router_key=router_key,
                service_key=service_key,
                router_name=str(site["router_name"]),
                service_name=str(site["service_name"]),
                host=str(site["host"]),
            )
            site_status = build_site_runtime_status(
                site,
                router_key=router_key,
                router_value=router_value,
                service_key=service_key,
                service_value=service_value,
                backend_health=backend_health,
                config_errors=site_errors,
            )
            counts[str(site_status["provisioning_state"])] += 1
            site_statuses.append(site_status)

        return {
            "summary": summary,
            "dashboard_url": self.settings.dashboard_url,
            "snapshot": snapshot,
            "sync": state["sync"],
            "render": state["render"],
            "deployments": state["deployments"],
            "sites": site_statuses,
            "status_summary": {
                "traefik_reachable": bool(summary.get("reachable")),
                "config_ok": bool(summary.get("config_ok")),
                "enabled_sites": sum(1 for site in state["sites"] if site.get("enabled")),
                **counts,
            },
        }

    def rendered_config_text(self) -> str:
        with self._state_lock:
            if self._last_rendered_text:
                return self._last_rendered_text
        return ""


SYNC_SERVICE = SyncService(SETTINGS)


def sync_runtime_artifacts(root: Path) -> None:
    del root
    SETTINGS.ensure_layout()
    sync_user_dynamic_snippets(
        config_root=SETTINGS.config_root,
        runtime_root=SETTINGS.runtime_root,
        generated_filename=SETTINGS.generated_config_path.name,
    )
    SYNC_SERVICE.sync_once(reason="bootstrap", force_static=True)


def run_sync_loop(*, once: bool = False) -> None:
    SETTINGS.ensure_layout()
    sync_user_dynamic_snippets(
        config_root=SETTINGS.config_root,
        runtime_root=SETTINGS.runtime_root,
        generated_filename=SETTINGS.generated_config_path.name,
    )
    SYNC_SERVICE.sync_once(reason="bootstrap", force_static=True)
    if once:
        return

    stop_requested = False

    def _handle_stop(signum: int, frame: Any) -> None:
        del signum, frame
        nonlocal stop_requested
        stop_requested = True

    previous_sigint = signal.signal(signal.SIGINT, _handle_stop)
    previous_sigterm = signal.signal(signal.SIGTERM, _handle_stop)
    try:
        while not stop_requested:
            sleep_seconds = max(float(SETTINGS.sync_interval_seconds), 0.1)
            deadline = time.monotonic() + sleep_seconds
            while not stop_requested:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                time.sleep(min(remaining, 0.5))
            if stop_requested:
                break
            SYNC_SERVICE.sync_once(reason="poll")
    finally:
        signal.signal(signal.SIGINT, previous_sigint)
        signal.signal(signal.SIGTERM, previous_sigterm)


def _json_default(value: Any) -> str:
    if isinstance(value, datetime):
        return value.astimezone(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")
    if isinstance(value, date):
        return value.isoformat()
    return str(value)


def write_response(handler: BaseHTTPRequestHandler, body: bytes, *, content_type: str, status: int = 200) -> None:
    handler.send_response(status)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def write_json(handler: BaseHTTPRequestHandler, payload: dict[str, Any], status: int = 200) -> None:
    body = json.dumps(payload, default=_json_default).encode("utf-8")
    write_response(handler, body, content_type="application/json", status=status)


def read_json_body(handler: BaseHTTPRequestHandler) -> dict[str, Any]:
    raw_length = handler.headers.get("Content-Length", "0").strip() or "0"
    try:
        content_length = int(raw_length)
    except ValueError as exc:
        raise ValueError("Invalid Content-Length header.") from exc
    body = handler.rfile.read(content_length) if content_length > 0 else b""
    if not body:
        return {}
    try:
        payload = json.loads(body.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON body: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError("Expected a JSON object request body.")
    return payload


def parse_bool_value(value: Any, *, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    candidate = str(value).strip().lower()
    if candidate in {"1", "true", "yes", "on"}:
        return True
    if candidate in {"0", "false", "no", "off"}:
        return False
    return default


def parse_optional_int(value: Any, field_name: str) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be an integer.") from exc


def validate_upstream_url(value: str) -> str:
    candidate = value.strip()
    parsed = urlparse(candidate)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("upstream_url must be a valid http:// or https:// URL.")
    return candidate


def prepare_quick_site_payload(
    payload: dict[str, Any],
    snapshot: InventorySnapshot,
) -> tuple[dict[str, Any], list[int], int | None]:
    defaults = quick_defaults(snapshot)
    enabled_resolvers = enabled_cert_resolvers(snapshot)
    enabled_resolver_ids = {int(row["id"]) for row in enabled_resolvers}
    oidc_client_ids = {client["id"] for client in oidc_clients(snapshot)}

    name = str(payload.get("name") or "").strip()
    host = str(payload.get("host") or "").strip()
    upstream_url = validate_upstream_url(str(payload.get("upstream_url") or ""))
    if not name:
        raise ValueError("name is required.")
    if not host:
        raise ValueError("host is required.")

    enabled = parse_bool_value(payload.get("enabled"), default=True)
    path_prefix = normalize_path_prefix(str(payload.get("path_prefix") or ""))
    tls_enabled = parse_bool_value(payload.get("tls_enabled"), default=bool(defaults["tls_enabled"]))

    cert_resolver_id = parse_optional_int(payload.get("cert_resolver_id"), "cert_resolver_id")
    if not tls_enabled:
        cert_resolver_id = None
    elif cert_resolver_id is None and defaults["cert_resolver_id"] is not None:
        cert_resolver_id = int(defaults["cert_resolver_id"])

    if tls_enabled and cert_resolver_id is None:
        if not enabled_resolvers:
            raise ValueError("TLS is enabled but no enabled cert resolver is available.")
        raise ValueError("TLS is enabled; choose a cert resolver or disable TLS.")

    if cert_resolver_id is not None and cert_resolver_id not in enabled_resolver_ids:
        raise ValueError("cert_resolver_id must reference an enabled cert resolver.")

    oidc_client_raw = payload.get("oidc_client_id", payload.get("auth_preset_id"))
    oidc_client_id = parse_optional_int(oidc_client_raw, "oidc_client_id")
    if oidc_client_id is not None and oidc_client_id not in oidc_client_ids:
        raise ValueError("oidc_client_id must reference an enabled OIDC client.")

    entrypoint_ids = [int(row["id"]) for row in default_entrypoint_rows(snapshot)]
    if not entrypoint_ids:
        raise ValueError("No enabled entrypoints are available for quick setup.")

    return (
        {
            "name": name,
            "enabled": enabled,
            "host": host,
            "upstream_url": upstream_url,
            "tls_enabled": tls_enabled,
            "cert_resolver": cert_resolver_id,
            "oidc_client": oidc_client_id,
            "path_prefix": path_prefix or None,
        },
        entrypoint_ids,
        oidc_client_id,
    )


def build_updated_middleware_ids(
    snapshot: InventorySnapshot,
    *,
    site_id: int,
    oidc_client_id: int | None,
) -> list[int]:
    del oidc_client_id
    middlewares_by_id = {int(row["id"]): row for row in snapshot.middlewares}
    current_middlewares = site_linked_rows(snapshot.site_middlewares, site_id, middlewares_by_id)
    preserved = [int(row["id"]) for row in current_middlewares if not middleware_is_legacy_oidc(row)]
    return list(dict.fromkeys(preserved))


def safe_static_target(url_path: str) -> Path | None:
    relative = url_path.removeprefix("/static/").strip("/")
    if not relative:
        return None
    candidate = (STATIC_ROOT / relative).resolve()
    try:
        candidate.relative_to(STATIC_ROOT.resolve())
    except ValueError:
        return None
    return candidate


def serve_static_asset(handler: BaseHTTPRequestHandler, url_path: str) -> bool:
    if not WEB_UI_ENABLED:
        return False
    target = safe_static_target(url_path)
    if target is None or not target.exists() or not target.is_file():
        return False
    content_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
    write_response(handler, target.read_bytes(), content_type=content_type, status=HTTPStatus.OK)
    return True


def serve_frontend_index(handler: BaseHTTPRequestHandler) -> None:
    if not WEB_UI_ENABLED:
        write_json(handler, {"ok": False, "error": "web UI is disabled"}, status=HTTPStatus.NOT_FOUND)
        return
    built_index = STATIC_ROOT / "index.html"
    if built_index.exists():
        write_response(
            handler,
            built_index.read_bytes(),
            content_type="text/html; charset=utf-8",
            status=HTTPStatus.OK,
        )
        return
    write_response(
        handler,
        index_html().encode("utf-8"),
        content_type="text/html; charset=utf-8",
        status=HTTPStatus.OK,
    )


def index_html() -> str:
    state = SYNC_SERVICE.build_state()
    issue_count = len(state["issues"])
    endpoints = [
        ("/api/state", "Current database-backed control-plane state"),
        ("/api/traefik/runtime", "Live Traefik API snapshot plus sync status"),
        ("/api/rendered-config", "Current generated dynamic Traefik config"),
        ("/api/sync", "Trigger an immediate sync cycle"),
        ("/healthz", "Basic process and sync health"),
    ]
    rows = "\n".join(
        f"<li><code>{html.escape(path)}</code> - {html.escape(description)}</li>"
        for path, description in endpoints
    )
    return f"""<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Traefik Control Plane</title>
    <style>
      body {{
        margin: 2rem auto;
        max-width: 860px;
        padding: 0 1rem;
        font: 16px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        color: #132033;
        background: #f6f8fb;
      }}
      main {{
        background: white;
        border: 1px solid rgba(15, 23, 42, 0.08);
        border-radius: 18px;
        padding: 1.5rem;
        box-shadow: 0 10px 30px rgba(15, 23, 42, 0.05);
      }}
      code {{
        background: #eef3f8;
        border-radius: 6px;
        padding: 0.1rem 0.35rem;
      }}
      ul {{
        padding-left: 1.1rem;
      }}
      dl {{
        display: grid;
        grid-template-columns: max-content 1fr;
        gap: 0.4rem 1rem;
      }}
      dt {{
        font-weight: 700;
      }}
    </style>
  </head>
  <body>
    <main>
      <h1>Traefik Control Plane</h1>
      <p>This process mirrors static Traefik inventory into Postgres and renders the watched dynamic config file from database state.</p>
      <dl>
        <dt>Database</dt><dd><code>{html.escape(str(state["database"]["url"]))}</code></dd>
        <dt>Static config</dt><dd><code>{html.escape(str(SETTINGS.active_config_path))}</code></dd>
        <dt>Generated config</dt><dd><code>{html.escape(str(SETTINGS.generated_config_path))}</code></dd>
        <dt>Enabled sites</dt><dd>{html.escape(str(state["render"].get("enabled_site_count", 0)))}</dd>
        <dt>Issues</dt><dd>{html.escape(str(issue_count))}</dd>
      </dl>
      <h2>Endpoints</h2>
      <ul>{rows}</ul>
    </main>
  </body>
</html>
"""


class RequestHandler(BaseHTTPRequestHandler):
    server_version = "TraefikControlPlane/0.3"

    def do_GET(self) -> None:
        parsed_path = self.path.split("?", 1)[0]
        if parsed_path == "/api/state":
            write_json(self, {"ok": True, "state": SYNC_SERVICE.build_state()})
            return
        if parsed_path == "/api/traefik/runtime":
            write_json(self, {"ok": True, "runtime": SYNC_SERVICE.get_runtime_payload()})
            return
        if parsed_path == "/api/rendered-config":
            body = SYNC_SERVICE.rendered_config_text().encode("utf-8")
            write_response(self, body, content_type="text/plain; charset=utf-8", status=HTTPStatus.OK)
            return
        if parsed_path == "/healthz":
            state = SYNC_SERVICE.build_state()
            status = HTTPStatus.OK if not state["sync"].get("last_error") else HTTPStatus.SERVICE_UNAVAILABLE
            write_json(
                self,
                {
                    "ok": status == HTTPStatus.OK,
                    "sync": state["sync"],
                    "render": state["render"],
                },
                status=status,
            )
            return
        if parsed_path.startswith("/static/"):
            if serve_static_asset(self, parsed_path):
                return
            write_json(self, {"ok": False, "error": "static asset not found"}, status=HTTPStatus.NOT_FOUND)
            return
        if parsed_path == "/" or not Path(parsed_path).suffix:
            serve_frontend_index(self)
            return
        write_json(self, {"ok": False, "error": "unknown endpoint"}, status=HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:
        parsed_path = self.path.split("?", 1)[0]
        if parsed_path == "/api/sync":
            try:
                state = SYNC_SERVICE.sync_once(reason="api", force_static=True)
            except Exception as exc:  # noqa: BLE001
                write_json(self, {"ok": False, "error": str(exc)}, status=HTTPStatus.INTERNAL_SERVER_ERROR)
                return
            write_json(self, {"ok": True, "state": state})
            return
        if parsed_path == "/api/sites/quick-create":
            try:
                payload = read_json_body(self)
                inventory = fetch_inventory(SETTINGS.database_dsn)
                fields, entrypoint_ids, oidc_client_id = prepare_quick_site_payload(payload, inventory)
                middleware_ids: list[int] = []
                site = create_quick_site(
                    SETTINGS.database_dsn,
                    fields=fields,
                    entrypoint_ids=entrypoint_ids,
                    middleware_ids=middleware_ids,
                )
                state = SYNC_SERVICE.sync_once(reason=f"quick-create:{site['id']}")
            except ValueError as exc:
                write_json(self, {"ok": False, "error": str(exc)}, status=HTTPStatus.BAD_REQUEST)
                return
            except Exception as exc:  # noqa: BLE001
                write_json(self, {"ok": False, "error": str(exc)}, status=HTTPStatus.INTERNAL_SERVER_ERROR)
                return
            write_json(self, {"ok": True, "site_id": int(site["id"]), "state": state}, status=HTTPStatus.CREATED)
            return

        toggle_match = re.fullmatch(r"/api/sites/(\d+)/toggle", parsed_path)
        if toggle_match:
            try:
                payload = read_json_body(self)
                site_id = int(toggle_match.group(1))
                enabled = parse_bool_value(payload.get("enabled"), default=True)
                toggle_site_enabled(SETTINGS.database_dsn, site_id=site_id, enabled=enabled)
                state = SYNC_SERVICE.sync_once(reason=f"quick-toggle:{site_id}")
            except ValueError as exc:
                write_json(self, {"ok": False, "error": str(exc)}, status=HTTPStatus.BAD_REQUEST)
                return
            except LookupError as exc:
                write_json(self, {"ok": False, "error": str(exc)}, status=HTTPStatus.NOT_FOUND)
                return
            except Exception as exc:  # noqa: BLE001
                write_json(self, {"ok": False, "error": str(exc)}, status=HTTPStatus.INTERNAL_SERVER_ERROR)
                return
            write_json(self, {"ok": True, "state": state})
            return
        write_json(self, {"ok": False, "error": "unknown endpoint"}, status=HTTPStatus.NOT_FOUND)

    def do_PATCH(self) -> None:
        parsed_path = self.path.split("?", 1)[0]
        update_match = re.fullmatch(r"/api/sites/(\d+)/quick-update", parsed_path)
        if not update_match:
            write_json(self, {"ok": False, "error": "unknown endpoint"}, status=HTTPStatus.NOT_FOUND)
            return
        try:
            payload = read_json_body(self)
            site_id = int(update_match.group(1))
            inventory = fetch_inventory(SETTINGS.database_dsn)
            fields, _entrypoint_ids, oidc_client_id = prepare_quick_site_payload(payload, inventory)
            middleware_ids = build_updated_middleware_ids(
                inventory,
                site_id=site_id,
                oidc_client_id=oidc_client_id,
            )
            update_quick_site(
                SETTINGS.database_dsn,
                site_id=site_id,
                fields=fields,
                middleware_ids=middleware_ids,
            )
            state = SYNC_SERVICE.sync_once(reason=f"quick-update:{site_id}")
        except ValueError as exc:
            write_json(self, {"ok": False, "error": str(exc)}, status=HTTPStatus.BAD_REQUEST)
            return
        except LookupError as exc:
            write_json(self, {"ok": False, "error": str(exc)}, status=HTTPStatus.NOT_FOUND)
            return
        except Exception as exc:  # noqa: BLE001
            write_json(self, {"ok": False, "error": str(exc)}, status=HTTPStatus.INTERNAL_SERVER_ERROR)
            return
        write_json(self, {"ok": True, "state": state})


def main(argv: list[str] | None = None) -> None:
    global WEB_UI_ENABLED
    parser = argparse.ArgumentParser(description="Run the Traefik database-backed control-plane server.")
    parser.add_argument("--host", default=SETTINGS.host)
    parser.add_argument("--port", type=int, default=SETTINGS.port)
    parser.add_argument("--headless", action="store_true", help="Run sync/render loop without serving HTTP.")
    parser.add_argument("--once", action="store_true", help="Run one sync cycle and exit.")
    parser.add_argument(
        "--enable-ui",
        action="store_true",
        default=SETTINGS.enable_ui,
        help="Serve the optional built web UI and static assets.",
    )
    args = parser.parse_args(argv)
    WEB_UI_ENABLED = args.enable_ui
    if args.headless or args.once:
        run_sync_loop(once=args.once)
        return

    sync_runtime_artifacts(CONFIG_ROOT)
    SYNC_SERVICE.start()
    httpd = ThreadingHTTPServer((args.host, args.port), RequestHandler)
    print(f"Traefik control plane listening on http://{args.host}:{args.port}")
    httpd.serve_forever()


if __name__ == "__main__":
    main()
