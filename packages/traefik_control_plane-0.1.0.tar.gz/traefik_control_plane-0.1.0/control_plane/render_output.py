from __future__ import annotations

from typing import Any


def build_render_payloads(
    *,
    routers: dict[str, Any],
    services: dict[str, Any],
    middlewares: dict[str, Any],
    servers_transports: dict[str, Any],
    tcp_routers: dict[str, Any],
    tcp_services: dict[str, Any],
    tls_options: dict[str, Any],
    redacted_routers: dict[str, Any],
    redacted_services: dict[str, Any],
    redacted_middlewares: dict[str, Any],
    redacted_servers_transports: dict[str, Any],
    redacted_tcp_routers: dict[str, Any],
    redacted_tcp_services: dict[str, Any],
    redacted_tls_options: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    rendered: dict[str, Any] = {}
    redacted_rendered: dict[str, Any] = {}

    http_payload: dict[str, Any] = {}
    redacted_http_payload: dict[str, Any] = {}
    if routers:
        http_payload["routers"] = routers
        redacted_http_payload["routers"] = redacted_routers
    if services:
        http_payload["services"] = services
        redacted_http_payload["services"] = redacted_services
    if middlewares:
        http_payload["middlewares"] = middlewares
        redacted_http_payload["middlewares"] = redacted_middlewares
    if servers_transports:
        http_payload["serversTransports"] = servers_transports
        redacted_http_payload["serversTransports"] = redacted_servers_transports
    if http_payload:
        rendered["http"] = http_payload
        redacted_rendered["http"] = redacted_http_payload

    tcp_payload: dict[str, Any] = {}
    redacted_tcp_payload: dict[str, Any] = {}
    if tcp_routers:
        tcp_payload["routers"] = tcp_routers
        redacted_tcp_payload["routers"] = redacted_tcp_routers
    if tcp_services:
        tcp_payload["services"] = tcp_services
        redacted_tcp_payload["services"] = redacted_tcp_services
    if tcp_payload:
        rendered["tcp"] = tcp_payload
        redacted_rendered["tcp"] = redacted_tcp_payload

    if tls_options:
        rendered["tls"] = {"options": tls_options}
        redacted_rendered["tls"] = {"options": redacted_tls_options}

    return rendered, redacted_rendered


def build_render_summary(
    *,
    enabled_site_count: int,
    enabled_stream_count: int,
    routers: dict[str, Any],
    services: dict[str, Any],
    tcp_routers: dict[str, Any],
    tcp_services: dict[str, Any],
    middlewares: dict[str, Any],
    servers_transports: dict[str, Any],
    tls_options: dict[str, Any],
) -> dict[str, int]:
    return {
        "enabled_site_count": enabled_site_count,
        "enabled_stream_count": enabled_stream_count,
        "router_count": len(routers),
        "service_count": len(services),
        "tcp_router_count": len(tcp_routers),
        "tcp_service_count": len(tcp_services),
        "middleware_count": len(middlewares),
        "servers_transport_count": len(servers_transports),
        "tls_option_count": len(tls_options),
    }
