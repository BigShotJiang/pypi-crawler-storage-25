from __future__ import annotations

import os
import io
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from control_plane.cli import main as control_plane_cli_main
from control_plane.config import (
    _parse_port,
    _parse_sync_interval,
    discover_database_dsn,
)
from control_plane.runtime_status import (
    build_site_runtime_status,
    disabled_backend_health,
    site_provisioning_state,
    site_runtime_errors,
)
from control_plane.render_output import (
    build_render_payloads,
    build_render_summary,
)
from control_plane.render_components import (
    render_middleware_row,
    render_servers_transport_row,
    render_tls_option_row,
)
from control_plane.state_payload import (
    build_site_payload,
    build_stream_payload,
    resolved_site_rule,
    resolved_stream_rule,
)
from control_plane.static_config import (
    parse_static_cert_resolvers,
    parse_static_entrypoints,
)
from traefik_conf.manage import main as traefik_manage_main


class ConfigParsingTests(unittest.TestCase):
    def test_parse_port_accepts_valid_value(self) -> None:
        self.assertEqual(_parse_port("8000"), 8000)

    def test_parse_port_rejects_out_of_range_value(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "between 1 and 65535"):
            _parse_port("70000")

    def test_parse_sync_interval_rejects_non_positive_value(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "greater than 0"):
            _parse_sync_interval("0")

    def test_discover_database_dsn_builds_url_from_parts(self) -> None:
        original = {key: os.environ.get(key) for key in (
            "TRAEFIK_DB_URL",
            "TRAEFIK_DB_NAME",
            "TRAEFIK_DB_USER",
            "TRAEFIK_DB_PASSWORD",
            "TRAEFIK_DB_HOST",
            "TRAEFIK_DB_PORT",
            "TRAEFIK_DB_SSLMODE",
        )}
        try:
            os.environ.pop("TRAEFIK_DB_URL", None)
            os.environ["TRAEFIK_DB_NAME"] = "traefik"
            os.environ["TRAEFIK_DB_USER"] = "app"
            os.environ["TRAEFIK_DB_PASSWORD"] = "p@ss word"
            os.environ["TRAEFIK_DB_HOST"] = "db.internal"
            os.environ["TRAEFIK_DB_PORT"] = "5433"
            os.environ["TRAEFIK_DB_SSLMODE"] = "require"
            self.assertEqual(
                discover_database_dsn(),
                "postgresql://app:p%40ss%20word@db.internal:5433/traefik?sslmode=require",
            )
        finally:
            for key, value in original.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value


class ConfigPathValidationTests(unittest.TestCase):
    def test_static_assets_directory_must_exist_when_ui_enabled(self) -> None:
        from control_plane.config import ControlPlaneConfig
        from control_plane.traefik_client import TraefikAPIEndpoint

        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            config_root = root / "config"
            runtime_root = root / "runtime"
            config_root.mkdir()
            runtime_root.mkdir()

            with self.assertRaisesRegex(RuntimeError, "STATIC_ASSETS_DIR"):
                ControlPlaneConfig(
                    config_root=config_root,
                    runtime_root=runtime_root,
                    repo_root=root,
                    static_root=root / "missing-static",
                    active_config_path=config_root / "static_conf.yml",
                    generated_config_path=runtime_root / "dynamic" / "dynamic_conf.generated.yml",
                    database_dsn="postgresql://user:pass@localhost/db",
                    database_dsn_display="postgresql://user:********@localhost/db",
                    host="127.0.0.1",
                    port=8000,
                    sync_interval_seconds=2.0,
                    enable_ui=True,
                    admin_api_endpoint=TraefikAPIEndpoint(
                        available=False,
                        base_url="",
                        source="test",
                        detail="",
                    ),
                    dashboard_url="",
                    dashboard_host="",
                )


class InventorySnapshotTests(unittest.TestCase):
    def test_with_updated_deployments_preserves_other_inventory_sections(self) -> None:
        try:
            from control_plane.db import InventorySnapshot, with_updated_deployments
        except ModuleNotFoundError as exc:
            if exc.name == "psycopg":
                self.skipTest("psycopg is not installed in this test environment")
            raise

        snapshot = InventorySnapshot(
            sites=[{"id": 1, "name": "site-a"}],
            streams=[{"id": 2, "name": "stream-a"}],
            middlewares=[],
            oidc_clients=[],
            entrypoints=[],
            cert_resolvers=[],
            tls_options=[],
            servers_transports=[],
            site_entrypoints={1: [{"id": 10, "name": "web", "enabled": True}]},
            stream_entrypoints={},
            site_middlewares={},
            deployments=[{"id": 1, "status": "old"}],
        )

        updated = with_updated_deployments(snapshot, [{"id": 2, "status": "new"}])

        self.assertEqual(updated.deployments, [{"id": 2, "status": "new"}])
        self.assertEqual(updated.sites, snapshot.sites)
        self.assertEqual(updated.site_entrypoints, snapshot.site_entrypoints)


class RuntimeStatusTests(unittest.TestCase):
    def test_disabled_backend_health_uses_empty_network_fields(self) -> None:
        payload = disabled_backend_health("http://backend.internal", checked_at="2026-04-16T10:00:00Z")
        self.assertIsNone(payload["ok"])
        self.assertEqual(payload["host"], "")
        self.assertEqual(payload["checked_at"], "2026-04-16T10:00:00Z")

    def test_site_runtime_errors_matches_any_relevant_identifier(self) -> None:
        errors = site_runtime_errors(
            [
                "router site-a@file failed",
                "service service-a@file unhealthy",
                "unrelated warning",
            ],
            router_key="site-a@file",
            service_key="service-a@file",
            router_name="site-a",
            service_name="service-a",
            host="example.com",
        )
        self.assertEqual(
            errors,
            [
                "router site-a@file failed",
                "service service-a@file unhealthy",
            ],
        )

    def test_site_provisioning_state_marks_healthy_only_for_fully_ready_site(self) -> None:
        self.assertEqual(
            site_provisioning_state(
                enabled=True,
                router_seen=True,
                service_seen=True,
                backend_ok=True,
                has_config_errors=False,
            ),
            "healthy",
        )
        self.assertEqual(
            site_provisioning_state(
                enabled=True,
                router_seen=True,
                service_seen=False,
                backend_ok=True,
                has_config_errors=False,
            ),
            "degraded",
        )
        self.assertEqual(
            site_provisioning_state(
                enabled=False,
                router_seen=False,
                service_seen=False,
                backend_ok=None,
                has_config_errors=False,
            ),
            "disabled",
        )

    def test_build_site_runtime_status_preserves_site_issue_list(self) -> None:
        status = build_site_runtime_status(
            {
                "id": 7,
                "name": "site-a",
                "enabled": True,
                "host": "example.com",
                "router_name": "site-site-a",
                "service_name": "service-site-a",
                "site_issues": [{"message": "warning"}],
            },
            router_key="site-site-a@file",
            router_value={"status": "enabled"},
            service_key="service-site-a@file",
            service_value={"status": "enabled"},
            backend_health={"ok": True, "url": "http://backend.internal"},
            config_errors=[],
        )
        self.assertEqual(status["provisioning_state"], "healthy")
        self.assertEqual(status["site_issues"], [{"message": "warning"}])
        self.assertEqual(status["router_runtime_name"], "site-site-a@file")


class StatePayloadTests(unittest.TestCase):
    def test_resolved_site_rule_prefers_rule_override(self) -> None:
        self.assertEqual(
            resolved_site_rule({"rule_override": "Host(`override.example.com`)"}, generated_rule="generated"),
            "Host(`override.example.com`)",
        )
        self.assertEqual(
            resolved_site_rule({"rule_override": ""}, generated_rule="generated"),
            "generated",
        )

    def test_build_site_payload_duplicates_oidc_fields_for_auth_preset_shape(self) -> None:
        payload = build_site_payload(
            {"id": 1, "name": "site-a"},
            router_name="site-site-a",
            service_name="service-site-a",
            resolved_rule="Host(`example.com`)",
            resolved_entrypoints=["websecure"],
            non_auth_middlewares=[{"name": "compress"}],
            cert_resolver={"name": "letsencrypt"},
            tls_option={"name": "modern"},
            transport={"name": "default"},
            oidc_client={"id": 9, "name": "auth-a"},
            has_advanced_config=True,
            site_issues=[{"message": "warn"}],
        )
        self.assertEqual(payload["oidc_client_id"], 9)
        self.assertEqual(payload["auth_preset_id"], 9)
        self.assertEqual(payload["middlewares"], ["compress"])
        self.assertTrue(payload["has_advanced_config"])

    def test_resolved_stream_rule_prefers_rule_override(self) -> None:
        self.assertEqual(
            resolved_stream_rule({"rule_override": "HostSNI(`db.example.com`)"}, generated_rule="generated"),
            "HostSNI(`db.example.com`)",
        )
        self.assertEqual(
            resolved_stream_rule({"rule_override": None}, generated_rule="generated"),
            "generated",
        )

    def test_build_stream_payload_keeps_transport_name_when_present(self) -> None:
        payload = build_stream_payload(
            {"id": 2, "name": "stream-a"},
            router_name="stream-stream-a",
            service_name="stream-service-a",
            resolved_rule="HostSNI(`db.example.com`)",
            entrypoints=["tcp"],
            transport={"name": "tcp-default"},
            stream_issues=[{"message": "warn"}],
        )
        self.assertEqual(payload["servers_transport_name"], "tcp-default")
        self.assertEqual(payload["stream_issues"], [{"message": "warn"}])


class StaticConfigParsingTests(unittest.TestCase):
    @staticmethod
    def _issue(severity: str, path: str, code: str, message: str) -> dict[str, str]:
        return {
            "severity": severity,
            "path": path,
            "code": code,
            "message": message,
        }

    def test_parse_static_entrypoints_skips_invalid_entries(self) -> None:
        issues: list[dict[str, str]] = []
        rows = parse_static_entrypoints(
            {
                "entryPoints": {
                    "web": {"address": ":80", "asDefault": True},
                    "broken": {"asDefault": False},
                    "wrong": "value",
                }
            },
            issues,
            issue_factory=self._issue,
        )
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["name"], "web")
        self.assertEqual(rows[0]["address"], ":80")
        self.assertEqual([item["code"] for item in issues], ["missing_address", "invalid_shape"])

    def test_parse_static_cert_resolvers_extracts_dns_fields_and_extra_json(self) -> None:
        issues: list[dict[str, str]] = []
        rows = parse_static_cert_resolvers(
            {
                "certificatesResolvers": {
                    "le": {
                        "acme": {
                            "email": "ops@example.com",
                            "storage": "/data/acme.json",
                            "caServer": "https://acme.example.test/directory",
                            "dnsChallenge": {
                                "provider": "cloudflare",
                                "delayBeforeCheck": "12",
                                "resolvers": ["1.1.1.1:53"],
                                "disablePropagationCheck": True,
                            },
                        }
                    }
                }
            },
            issues,
            issue_factory=self._issue,
        )
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["challenge_type"], "dnsChallenge")
        self.assertEqual(rows[0]["provider"], "cloudflare")
        self.assertEqual(rows[0]["delay_before_check"], 12)
        self.assertIn("disablePropagationCheck", rows[0]["extra_json"])
        self.assertEqual(issues, [])

    def test_parse_static_cert_resolvers_warns_on_invalid_delay(self) -> None:
        issues: list[dict[str, str]] = []
        rows = parse_static_cert_resolvers(
            {
                "certificatesResolvers": {
                    "le": {
                        "acme": {
                            "dnsChallenge": {
                                "provider": "cloudflare",
                                "delayBeforeCheck": "later",
                            }
                        }
                    }
                }
            },
            issues,
            issue_factory=self._issue,
        )
        self.assertEqual(len(rows), 1)
        self.assertIsNone(rows[0]["delay_before_check"])
        self.assertEqual([item["code"] for item in issues], ["invalid_delay"])


class RenderOutputTests(unittest.TestCase):
    def test_build_render_payloads_omits_empty_sections(self) -> None:
        rendered, redacted = build_render_payloads(
            routers={"site-a": {"rule": "Host(`a.example.com`)"}},
            services={},
            middlewares={},
            servers_transports={},
            tcp_routers={},
            tcp_services={},
            tls_options={},
            redacted_routers={"site-a": {"rule": "Host(`a.example.com`)"}},
            redacted_services={},
            redacted_middlewares={},
            redacted_servers_transports={},
            redacted_tcp_routers={},
            redacted_tcp_services={},
            redacted_tls_options={},
        )
        self.assertEqual(rendered, {"http": {"routers": {"site-a": {"rule": "Host(`a.example.com`)"}}}})
        self.assertEqual(redacted, rendered)

    def test_build_render_summary_counts_sections(self) -> None:
        summary = build_render_summary(
            enabled_site_count=2,
            enabled_stream_count=1,
            routers={"a": {}, "b": {}},
            services={"a": {}},
            tcp_routers={"tcp-a": {}},
            tcp_services={"tcp-a": {}, "tcp-b": {}},
            middlewares={"m1": {}},
            servers_transports={"st1": {}, "st2": {}},
            tls_options={"tls1": {}},
        )
        self.assertEqual(summary["enabled_site_count"], 2)
        self.assertEqual(summary["tcp_service_count"], 2)
        self.assertEqual(summary["servers_transport_count"], 2)


class RenderComponentTests(unittest.TestCase):
    @staticmethod
    def _parse_mapping_text(raw_value: object, _context: str, _issues: list[dict[str, str]]) -> dict[str, object]:
        return dict(raw_value) if isinstance(raw_value, dict) else {}

    @staticmethod
    def _parse_string_list_text(raw_value: object, _context: str, _issues: list[dict[str, str]]) -> list[str]:
        if isinstance(raw_value, list):
            return [str(item) for item in raw_value]
        return []

    @staticmethod
    def _render_template_env_references(value: object) -> tuple[object, object]:
        return value, value

    @staticmethod
    def _find_placeholder_paths(_value: object) -> list[str]:
        return []

    @staticmethod
    def _issue(severity: str, path: str, code: str, message: str) -> dict[str, str]:
        return {
            "severity": severity,
            "path": path,
            "code": code,
            "message": message,
        }

    @staticmethod
    def _normalize_plugin_config(config: dict[str, object]) -> dict[str, object]:
        return {"normalized": config}

    def test_render_middleware_row_wraps_plugin_config(self) -> None:
        issues: list[dict[str, str]] = []
        rendered = render_middleware_row(
            {
                "name": "auth",
                "type": "plugin",
                "config_json": {"oidc-authentication": {"Provider": {"Url": "https://issuer"}}},
            },
            issues=issues,
            parse_mapping_text=self._parse_mapping_text,
            render_template_env_references=self._render_template_env_references,
            find_placeholder_paths=self._find_placeholder_paths,
            issue_factory=self._issue,
            normalize_plugin_config=self._normalize_plugin_config,
        )
        self.assertIsNotNone(rendered)
        name, resolved, redacted = rendered or ("", {}, {})
        self.assertEqual(name, "auth")
        self.assertIn("plugin", resolved)
        self.assertEqual(resolved["plugin"]["normalized"]["oidc-authentication"]["Provider"]["Url"], "https://issuer")
        self.assertEqual(redacted, resolved)

    def test_render_tls_option_row_builds_client_auth_and_ciphers(self) -> None:
        issues: list[dict[str, str]] = []
        name, resolved, redacted = render_tls_option_row(
            {
                "name": "modern",
                "min_version": "VersionTLS13",
                "sni_strict": True,
                "cipher_suites_json": ["TLS_AES_256_GCM_SHA384"],
                "curve_preferences_json": ["CurveP256"],
                "client_auth_json": {"caFiles": ["/tmp/ca.pem"]},
            },
            issues=issues,
            parse_mapping_text=self._parse_mapping_text,
            parse_string_list_text=self._parse_string_list_text,
            render_template_env_references=self._render_template_env_references,
        )
        self.assertEqual(name, "modern")
        self.assertTrue(resolved["sniStrict"])
        self.assertEqual(resolved["cipherSuites"], ["TLS_AES_256_GCM_SHA384"])
        self.assertEqual(redacted["clientAuth"]["caFiles"], ["/tmp/ca.pem"])

    def test_render_servers_transport_row_builds_forwarding_timeouts(self) -> None:
        issues: list[dict[str, str]] = []
        name, resolved, redacted = render_servers_transport_row(
            {
                "name": "default",
                "server_name": "backend.internal",
                "insecure_skip_verify": True,
                "root_cas_json": ["/tmp/root.pem"],
                "max_idle_conns_per_host": 16,
                "forwarding_timeouts_json": {"dialTimeout": "30s"},
            },
            issues=issues,
            parse_mapping_text=self._parse_mapping_text,
            parse_string_list_text=self._parse_string_list_text,
            render_template_env_references=self._render_template_env_references,
        )
        self.assertEqual(name, "default")
        self.assertEqual(resolved["serverName"], "backend.internal")
        self.assertEqual(resolved["forwardingTimeouts"]["dialTimeout"], "30s")
        self.assertEqual(redacted["rootCAs"], ["/tmp/root.pem"])


class PackageCliTests(unittest.TestCase):
    def test_control_plane_cli_help_does_not_require_runtime_env(self) -> None:
        with self.assertRaises(SystemExit) as exc:
            control_plane_cli_main(["--help"])
        self.assertEqual(exc.exception.code, 0)

    def test_traefik_manage_help_lists_subcommands(self) -> None:
        output = io.StringIO()
        with redirect_stdout(output):
            traefik_manage_main([])
        rendered = output.getvalue()
        self.assertIn("create-db-schema", rendered)
        self.assertIn("db-restore", rendered)
        self.assertIn("server", rendered)


if __name__ == "__main__":
    unittest.main()
