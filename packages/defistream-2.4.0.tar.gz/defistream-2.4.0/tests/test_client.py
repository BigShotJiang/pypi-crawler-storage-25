"""Tests for DeFiStream client."""

import os
import pytest
from unittest.mock import MagicMock, patch

from defistream import (
    AsyncDeFiStream,
    AsyncExchangeDataQueryBuilder,
    AsyncHLQueryBuilder,
    AsyncOHLCVQueryBuilder,
    AsyncQueryBuilder,
    AsyncTradeQueryBuilder,
    DeFiStream,
    EVMChain,
    TronChain,
    BitcoinChain,
    ExchangeNamespace,
    ExchangeDataQueryBuilder,
    HLQueryBuilder,
    OHLCVQueryBuilder,
    QueryBuilder,
    AggregateQueryBuilder,
    AsyncAggregateQueryBuilder,
    EventsAggregateQueryBuilder,
    AsyncEventsAggregateQueryBuilder,
    TronBtcQueryBuilder,
    AsyncTronBtcQueryBuilder,
    TradeQueryBuilder,
)
from defistream.exceptions import (
    AuthenticationError,
    QuotaExceededError,
    ValidationError,
)
from defistream.protocols import BinanceProtocol, AsyncBinanceProtocol, HyperliquidProtocol


class TestDeFiStreamInit:
    """Test client initialization."""

    def test_requires_api_key(self):
        """Should raise if no API key provided."""
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ValueError, match="API key required"):
                DeFiStream()

    def test_accepts_api_key_argument(self):
        """Should accept API key as argument."""
        client = DeFiStream(api_key="dsk_test")
        assert client.api_key == "dsk_test"

    def test_reads_api_key_from_env(self):
        """Should read API key from environment."""
        with patch.dict(os.environ, {"DEFISTREAM_API_KEY": "dsk_env"}):
            client = DeFiStream()
            assert client.api_key == "dsk_env"

    def test_default_base_url(self):
        """Should use default base URL."""
        client = DeFiStream(api_key="dsk_test")
        assert client.base_url == "https://api.defistream.dev/v1"

    def test_custom_base_url(self):
        """Should accept custom base URL."""
        client = DeFiStream(api_key="dsk_test", base_url="http://localhost:8081/v1")
        assert client.base_url == "http://localhost:8081/v1"


class TestChainNamespaces:
    """Test chain namespace availability."""

    def test_has_evm_namespace(self):
        """Should have evm namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client, "evm")
        assert isinstance(client.evm, EVMChain)

    def test_has_tron_namespace(self):
        """Should have tron namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client, "tron")
        assert isinstance(client.tron, TronChain)

    def test_has_bitcoin_namespace(self):
        """Should have bitcoin namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client, "bitcoin")
        assert isinstance(client.bitcoin, BitcoinChain)

    def test_has_exchange_namespace(self):
        """Should have exchange namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client, "exchange")
        assert isinstance(client.exchange, ExchangeNamespace)


class TestEVMProtocols:
    """Test EVM protocol availability through chain namespace."""

    def test_has_erc20_protocol(self):
        """Should have ERC20 protocol client via evm namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.evm, "erc20")
        assert hasattr(client.evm.erc20, "transfers")

    def test_has_native_protocol(self):
        """Should have native protocol client via evm namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.evm, "native")
        assert hasattr(client.evm.native, "transfers")

    def test_has_aave_protocol(self):
        """Should have AAVE protocol client via evm namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.evm, "aave_v3")
        assert hasattr(client.evm.aave_v3, "deposits")
        assert hasattr(client.evm.aave_v3, "withdrawals")
        assert hasattr(client.evm.aave_v3, "borrows")
        assert hasattr(client.evm.aave_v3, "repays")
        assert hasattr(client.evm.aave_v3, "flashloans")
        assert hasattr(client.evm.aave_v3, "liquidations")

    def test_has_uniswap_protocol(self):
        """Should have Uniswap protocol client via evm namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.evm, "uniswap_v3")
        assert hasattr(client.evm.uniswap_v3, "swaps")
        assert hasattr(client.evm.uniswap_v3, "deposits")
        assert hasattr(client.evm.uniswap_v3, "withdrawals")
        assert hasattr(client.evm.uniswap_v3, "collects")

    def test_has_lido_protocol(self):
        """Should have Lido protocol client via evm namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.evm, "lido")
        assert hasattr(client.evm.lido, "deposits")
        assert hasattr(client.evm.lido, "withdrawal_requests")
        assert hasattr(client.evm.lido, "withdrawals_claimed")
        assert hasattr(client.evm.lido, "l2_deposits")
        assert hasattr(client.evm.lido, "l2_withdrawal_requests")

    def test_has_stader_protocol(self):
        """Should have Stader protocol client via evm namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.evm, "stader")
        assert hasattr(client.evm.stader, "deposits")
        assert hasattr(client.evm.stader, "withdrawal_requests")
        assert hasattr(client.evm.stader, "withdrawals")

    def test_has_threshold_protocol(self):
        """Should have Threshold protocol client via evm namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.evm, "threshold")
        assert hasattr(client.evm.threshold, "deposit_requests")
        assert hasattr(client.evm.threshold, "deposits")
        assert hasattr(client.evm.threshold, "withdrawal_requests")
        assert hasattr(client.evm.threshold, "withdrawals")


class TestTronProtocols:
    """Test Tron protocol availability."""

    def test_has_trc20(self):
        """Should have TRC20 protocol."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.tron, "trc20")
        assert hasattr(client.tron.trc20, "transfers")

    def test_has_native(self):
        """Should have Tron native protocol."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.tron, "native")
        assert hasattr(client.tron.native, "transfers")

    def test_trc20_transfers_endpoint(self):
        """TRC20 transfers should use /tron/trc20/events/transfer endpoint."""
        client = DeFiStream(api_key="dsk_test")
        query = client.tron.trc20.transfers("USDT")
        assert query._endpoint == "/tron/trc20/events/transfer"
        assert query._params["token"] == "USDT"
        assert "network" not in query._params

    def test_trc20_transfers_no_token(self):
        """TRC20 transfers with no token should not set token param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.tron.trc20.transfers()
        assert "token" not in query._params
        assert "network" not in query._params

    def test_tron_native_transfers_endpoint(self):
        """Tron native transfers should use /tron/native/events/transfer endpoint."""
        client = DeFiStream(api_key="dsk_test")
        query = client.tron.native.transfers()
        assert query._endpoint == "/tron/native/events/transfer"
        assert "network" not in query._params


class TestBitcoinProtocols:
    """Test Bitcoin protocol availability."""

    def test_has_native(self):
        """Should have Bitcoin native protocol."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.bitcoin, "native")
        assert hasattr(client.bitcoin.native, "transfers")

    def test_bitcoin_native_transfers_endpoint(self):
        """Bitcoin native transfers should use /btc/native/events/transfer endpoint."""
        client = DeFiStream(api_key="dsk_test")
        query = client.bitcoin.native.transfers()
        assert query._endpoint == "/btc/native/events/transfer"
        assert "network" not in query._params


class TestTronBtcAggregate:
    """Test aggregate query building for Tron and Bitcoin endpoints."""

    def test_trc20_transfers_returns_tronbtc_builder(self):
        """TRC20 transfers should return a TronBtcQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        query = client.tron.trc20.transfers("USDT")
        assert isinstance(query, TronBtcQueryBuilder)

    def test_tron_native_transfers_returns_tronbtc_builder(self):
        """Tron native transfers should return a TronBtcQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        query = client.tron.native.transfers()
        assert isinstance(query, TronBtcQueryBuilder)

    def test_bitcoin_native_transfers_returns_tronbtc_builder(self):
        """Bitcoin native transfers should return a TronBtcQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        query = client.bitcoin.native.transfers()
        assert isinstance(query, TronBtcQueryBuilder)

    def test_trc20_aggregate_returns_events_aggregate_builder(self):
        """TRC20 aggregate should return an EventsAggregateQueryBuilder (uses 'events' key)."""
        client = DeFiStream(api_key="dsk_test")
        query = client.tron.trc20.transfers("USDT").aggregate()
        assert isinstance(query, EventsAggregateQueryBuilder)
        assert query._response_key == "events"

    def test_trc20_aggregate_appends_to_endpoint(self):
        """TRC20 aggregate should append /aggregate to endpoint."""
        client = DeFiStream(api_key="dsk_test")
        query = client.tron.trc20.transfers("USDT").aggregate()
        assert query._endpoint == "/tron/trc20/events/transfer/aggregate"

    def test_trc20_aggregate_sets_default_params(self):
        """TRC20 aggregate should default to group_by='time', period='1h'."""
        client = DeFiStream(api_key="dsk_test")
        query = client.tron.trc20.transfers().aggregate()
        assert query._params["group_by"] == "time"
        assert query._params["period"] == "1h"

    def test_trc20_aggregate_custom_params(self):
        """TRC20 aggregate should accept custom group_by/period."""
        client = DeFiStream(api_key="dsk_test")
        query = client.tron.trc20.transfers().aggregate(group_by="block_number", period="5000")
        assert query._params["group_by"] == "block_number"
        assert query._params["period"] == "5000"

    def test_trc20_aggregate_preserves_filters(self):
        """Filters set before .aggregate() should carry over, and chain must
        keep the TronBtcQueryBuilder type so .aggregate() returns an
        EventsAggregateQueryBuilder (with 'events' response key)."""
        client = DeFiStream(api_key="dsk_test")
        # Verify the pre-aggregate chain preserves type after filter methods.
        pre = (
            client.tron.trc20.transfers("USDT")
            .block_range(80000000, 80001000)
            .min_amount(1000)
        )
        assert isinstance(pre, TronBtcQueryBuilder)
        query = pre.aggregate(group_by="time", period="1d")
        assert isinstance(query, EventsAggregateQueryBuilder)
        assert query._response_key == "events"
        assert query._params["token"] == "USDT"
        assert query._params["block_start"] == 80000000
        assert query._params["block_end"] == 80001000
        assert query._params["min_amount"] == 1000
        assert query._params["group_by"] == "time"
        assert query._params["period"] == "1d"

    def test_tron_native_aggregate_endpoint(self):
        """Tron native aggregate should append /aggregate."""
        client = DeFiStream(api_key="dsk_test")
        query = client.tron.native.transfers().aggregate(group_by="time", period="1h")
        assert query._endpoint == "/tron/native/events/transfer/aggregate"
        assert isinstance(query, EventsAggregateQueryBuilder)

    def test_bitcoin_native_aggregate_endpoint(self):
        """Bitcoin native aggregate should append /aggregate."""
        client = DeFiStream(api_key="dsk_test")
        query = client.bitcoin.native.transfers().aggregate(group_by="time", period="1h")
        assert query._endpoint == "/btc/native/events/transfer/aggregate"
        assert isinstance(query, EventsAggregateQueryBuilder)

    def test_bitcoin_aggregate_preserves_filters(self):
        """Bitcoin aggregate should preserve filters set before .aggregate()."""
        client = DeFiStream(api_key="dsk_test")
        query = (
            client.bitcoin.native.transfers()
            .block_range(880000, 881000)
            .aggregate(group_by="block_number", period="100")
        )
        assert query._params["block_start"] == 880000
        assert query._params["block_end"] == 881000
        assert query._params["group_by"] == "block_number"
        assert query._params["period"] == "100"

    def test_tron_btc_aggregate_chain_preserves_type(self):
        """Chaining filters after .aggregate() should preserve EventsAggregateQueryBuilder type."""
        client = DeFiStream(api_key="dsk_test")
        query = (
            client.tron.trc20.transfers("USDT")
            .aggregate()
            .min_amount(100)
            .network("TRON")
        )
        assert isinstance(query, EventsAggregateQueryBuilder)
        assert query._response_key == "events"

    def test_async_trc20_aggregate_returns_async_events_builder(self):
        """Async TRC20 aggregate should return AsyncEventsAggregateQueryBuilder."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.tron.trc20.transfers("USDT").aggregate()
        assert isinstance(query, AsyncEventsAggregateQueryBuilder)
        assert query._endpoint == "/tron/trc20/events/transfer/aggregate"
        assert query._response_key == "events"

    def test_async_tron_native_aggregate_endpoint(self):
        """Async Tron native aggregate should append /aggregate."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.tron.native.transfers().aggregate(group_by="block_number", period="2000")
        assert query._endpoint == "/tron/native/events/transfer/aggregate"
        assert query._params["group_by"] == "block_number"
        assert query._params["period"] == "2000"

    def test_async_bitcoin_aggregate_endpoint(self):
        """Async Bitcoin aggregate should append /aggregate."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.bitcoin.native.transfers().aggregate()
        assert query._endpoint == "/btc/native/events/transfer/aggregate"
        assert isinstance(query, AsyncEventsAggregateQueryBuilder)


class TestAsyncClient:
    """Test async client."""

    def test_async_client_init(self):
        """Should initialize async client."""
        client = AsyncDeFiStream(api_key="dsk_test")
        assert client.api_key == "dsk_test"

    def test_async_has_evm_namespace(self):
        """Should have evm namespace on async client."""
        client = AsyncDeFiStream(api_key="dsk_test")
        assert hasattr(client, "evm")
        assert hasattr(client.evm, "erc20")
        assert hasattr(client.evm, "native")
        assert hasattr(client.evm, "aave_v3")
        assert hasattr(client.evm, "uniswap_v3")
        assert hasattr(client.evm, "lido")
        assert hasattr(client.evm, "stader")
        assert hasattr(client.evm, "threshold")

    def test_async_has_tron_namespace(self):
        """Should have tron namespace on async client."""
        client = AsyncDeFiStream(api_key="dsk_test")
        assert hasattr(client, "tron")
        assert hasattr(client.tron, "trc20")
        assert hasattr(client.tron, "native")

    def test_async_has_bitcoin_namespace(self):
        """Should have bitcoin namespace on async client."""
        client = AsyncDeFiStream(api_key="dsk_test")
        assert hasattr(client, "bitcoin")
        assert hasattr(client.bitcoin, "native")

    def test_async_has_exchange_namespace(self):
        """Should have exchange namespace on async client."""
        client = AsyncDeFiStream(api_key="dsk_test")
        assert hasattr(client, "exchange")
        assert hasattr(client.exchange, "binance")
        assert hasattr(client.exchange, "hyperliquid")


class TestContextManager:
    """Test context manager support."""

    def test_sync_context_manager(self):
        """Should work as context manager."""
        with DeFiStream(api_key="dsk_test") as client:
            assert client.api_key == "dsk_test"

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        """Should work as async context manager."""
        async with AsyncDeFiStream(api_key="dsk_test") as client:
            assert client.api_key == "dsk_test"


class TestWalletNamespaceDefault:
    """Test wallet_namespace default behavior."""

    def test_query_builder_has_wallet_namespace_default(self):
        """QueryBuilder should default wallet_namespace to 'public'."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT")
        assert query._params.get("wallet_namespace") == "public"

    def test_async_query_builder_has_wallet_namespace_default(self):
        """AsyncQueryBuilder should default wallet_namespace to 'public'."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT")
        assert query._params.get("wallet_namespace") == "public"

    def test_wallet_namespace_in_build_params(self):
        """wallet_namespace should appear in built params."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").network("ETH")
        params = query._build_params()
        assert params["wallet_namespace"] == "public"

    def test_wallet_namespace_preserved_through_chaining(self):
        """wallet_namespace should be preserved through builder chaining."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").network("ETH").block_range(1, 100)
        assert query._params["wallet_namespace"] == "public"


class TestMyWallets:
    """Test my_wallets() method."""

    def test_my_wallets_removes_wallet_namespace(self):
        """my_wallets() should remove wallet_namespace from params."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").my_wallets()
        assert "wallet_namespace" not in query._params

    def test_my_wallets_immutable(self):
        """my_wallets() should return a new instance."""
        client = DeFiStream(api_key="dsk_test")
        query1 = client.evm.erc20.transfers("USDT")
        query2 = query1.my_wallets()
        assert query1 is not query2
        assert query1._params.get("wallet_namespace") == "public"
        assert "wallet_namespace" not in query2._params

    def test_my_wallets_preserves_other_params(self):
        """my_wallets() should preserve other params."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").network("ETH").my_wallets()
        assert query._params["network"] == "ETH"
        assert query._params["token"] == "USDT"
        assert "wallet_namespace" not in query._params

    def test_async_my_wallets_removes_wallet_namespace(self):
        """Async my_wallets() should remove wallet_namespace from params."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").my_wallets()
        assert isinstance(query, AsyncQueryBuilder)
        assert "wallet_namespace" not in query._params

    def test_my_wallets_build_params_no_wallet_namespace(self):
        """Built params after my_wallets() should not contain wallet_namespace."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").my_wallets()
        params = query._build_params()
        assert "wallet_namespace" not in params


class TestBuilderPattern:
    """Test builder pattern for queries."""

    def test_transfers_returns_query_builder(self):
        """Protocol methods should return QueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert isinstance(query, QueryBuilder)

    def test_transfers_with_token_sets_param(self):
        """transfers('USDT') should set token param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT")
        assert query._params.get("token") == "USDT"

    def test_builder_chaining(self):
        """Builder methods should return QueryBuilder for chaining."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").network("ETH").start_block(21000000).end_block(21010000)
        assert isinstance(query, QueryBuilder)
        assert query._params["network"] == "ETH"
        assert query._params["block_start"] == 21000000
        assert query._params["block_end"] == 21010000

    def test_builder_immutability(self):
        """Builder methods should return new instances."""
        client = DeFiStream(api_key="dsk_test")
        query1 = client.evm.erc20.transfers("USDT")
        query2 = query1.network("ETH")
        assert query1 is not query2
        assert "network" not in query1._params
        assert query2._params["network"] == "ETH"

    def test_last_value_wins(self):
        """Multiple calls to same filter should use last value."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().network("ETH").network("ARB")
        assert query._params["network"] == "ARB"

    def test_block_range_method(self):
        """block_range should set both start and end."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().block_range(21000000, 21010000)
        assert query._params["block_start"] == 21000000
        assert query._params["block_end"] == 21010000

    def test_from_address_alias(self):
        """from_address should be alias for sender."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().from_address("0x123")
        assert query._params["sender"] == "0x123"

    def test_to_address_alias(self):
        """to_address should be alias for receiver."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().to_address("0x456")
        assert query._params["receiver"] == "0x456"

    def test_verbose_mode(self):
        """verbose() should set verbose param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().verbose()
        assert query._verbose is True
        params = query._build_params()
        assert params["verbose"] == "true"

    def test_verbose_false_by_default(self):
        """verbose should be False by default."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert query._verbose is False
        params = query._build_params()
        assert "verbose" not in params

    def test_min_amount_filter(self):
        """min_amount should set param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().min_amount(1000)
        assert query._params["min_amount"] == 1000

    def test_max_amount_filter(self):
        """max_amount should set param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().max_amount(10000)
        assert query._params["max_amount"] == 10000

    def test_start_time(self):
        """start_time should set since param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().start_time("2024-01-01T00:00:00Z")
        assert query._params["since"] == "2024-01-01T00:00:00Z"

    def test_end_time(self):
        """end_time should set until param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().end_time("2024-01-31T23:59:59Z")
        assert query._params["until"] == "2024-01-31T23:59:59Z"

    def test_time_range(self):
        """time_range should set both since and until params."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().time_range("2024-01-01", "2024-01-31")
        assert query._params["since"] == "2024-01-01"
        assert query._params["until"] == "2024-01-31"


class TestWithValue:
    """Test with_value builder method."""

    def test_with_value_sets_flag(self):
        """with_value() should set _with_value flag."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().with_value()
        assert query._with_value is True
        params = query._build_params()
        assert params["with_value"] == "true"

    def test_with_value_false_by_default(self):
        """_with_value should be False by default."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert query._with_value is False
        params = query._build_params()
        assert "with_value" not in params

    def test_with_value_immutability(self):
        """with_value() should return a new instance."""
        client = DeFiStream(api_key="dsk_test")
        query1 = client.evm.erc20.transfers()
        query2 = query1.with_value()
        assert query1 is not query2
        assert query1._with_value is False
        assert query2._with_value is True

    def test_with_value_explicit_false(self):
        """with_value(False) should disable value enrichment."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().with_value().with_value(False)
        assert query._with_value is False
        params = query._build_params()
        assert "with_value" not in params

    def test_with_value_carries_to_aggregate(self):
        """with_value should carry through to AggregateQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().with_value().aggregate()
        assert isinstance(query, AggregateQueryBuilder)
        assert query._with_value is True
        params = query._build_params()
        assert params["with_value"] == "true"

    def test_with_value_on_aggregate_builder(self):
        """with_value should work on AggregateQueryBuilder directly."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().aggregate().with_value()
        assert isinstance(query, AggregateQueryBuilder)
        assert query._with_value is True

    def test_async_with_value_sets_flag(self):
        """Async with_value() should set _with_value flag."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().with_value()
        assert isinstance(query, AsyncQueryBuilder)
        assert query._with_value is True
        params = query._build_params()
        assert params["with_value"] == "true"

    def test_async_with_value_false_by_default(self):
        """Async _with_value should be False by default."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert query._with_value is False
        params = query._build_params()
        assert "with_value" not in params

    def test_async_with_value_carries_to_aggregate(self):
        """Async with_value should carry through to AsyncAggregateQueryBuilder."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().with_value().aggregate()
        assert isinstance(query, AsyncAggregateQueryBuilder)
        assert query._with_value is True
        params = query._build_params()
        assert params["with_value"] == "true"

    def test_with_value_chains_with_other_methods(self):
        """with_value should chain with other builder methods."""
        client = DeFiStream(api_key="dsk_test")
        query = (
            client.evm.erc20.transfers("USDT")
            .network("ETH")
            .with_value()
            .block_range(21000000, 21010000)
        )
        assert query._with_value is True
        assert query._params["network"] == "ETH"
        assert query._params["block_start"] == 21000000


class TestMultiTokenSupport:
    """Test multi-token support for ERC20 transfers."""

    def test_transfers_single_token(self):
        """transfers('USDT') should set token param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT")
        assert query._params["token"] == "USDT"

    def test_transfers_multiple_tokens(self):
        """transfers('USDT', 'USDC', 'DAI') should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT", "USDC", "DAI")
        assert query._params["token"] == "USDT,USDC,DAI"

    def test_transfers_two_tokens(self):
        """transfers('USDT', 'USDC') should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT", "USDC")
        assert query._params["token"] == "USDT,USDC"

    def test_transfers_no_token(self):
        """transfers() with no args should have no token param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert "token" not in query._params

    def test_transfers_pre_joined_string(self):
        """transfers('USDT,USDC') with pre-joined string should pass through."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT,USDC")
        assert query._params["token"] == "USDT,USDC"

    def test_token_chain_multiple(self):
        """.token('USDT', 'USDC') should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().token("USDT", "USDC")
        assert query._params["token"] == "USDT,USDC"

    def test_token_chain_single(self):
        """.token('USDT') should set single token."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().token("USDT")
        assert query._params["token"] == "USDT"

    def test_token_chain_no_args_raises(self):
        """.token() with no args should raise ValueError."""
        client = DeFiStream(api_key="dsk_test")
        with pytest.raises(ValueError, match="At least one value is required"):
            client.evm.erc20.transfers().token()

    def test_multi_token_with_chaining(self):
        """Multi-token should work with other builder methods."""
        client = DeFiStream(api_key="dsk_test")
        query = (
            client.evm.erc20.transfers("USDT", "USDC", "DAI")
            .network("ETH")
            .block_range(21000000, 21010000)
        )
        assert query._params["token"] == "USDT,USDC,DAI"
        assert query._params["network"] == "ETH"
        assert query._params["block_start"] == 21000000

    def test_async_transfers_multiple_tokens(self):
        """Async transfers should support multi-token."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT", "USDC")
        assert isinstance(query, AsyncQueryBuilder)
        assert query._params["token"] == "USDT,USDC"

    def test_async_token_chain_multiple(self):
        """Async .token() should support multi-token."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().token("USDT", "USDC", "DAI")
        assert query._params["token"] == "USDT,USDC,DAI"

    def test_contract_address_still_works(self):
        """Single contract address should still work."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("0xdAC17F958D2ee523a2206206994597C13D831ec7")
        assert query._params["token"] == "0xdAC17F958D2ee523a2206206994597C13D831ec7"

    def test_multi_token_aggregate(self):
        """Multi-token should carry through to aggregate queries."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT", "USDC").network("ETH").aggregate()
        assert query._params["token"] == "USDT,USDC"
        assert isinstance(query, AggregateQueryBuilder)

    def test_ignore_non_existing_default_false(self):
        """ignore_non_existing should default to False."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT", "USDC")
        assert query._ignore_non_existing is False
        params = query._build_params()
        assert "ignore_non_existing" not in params

    def test_ignore_non_existing_true(self):
        """ignore_non_existing(True) should set the param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT", "USDC").ignore_non_existing()
        assert query._ignore_non_existing is True
        params = query._build_params()
        assert params["ignore_non_existing"] == "true"

    def test_ignore_non_existing_with_chaining(self):
        """ignore_non_existing should work with other builder methods."""
        client = DeFiStream(api_key="dsk_test")
        query = (
            client.evm.erc20.transfers("USDT", "USDC", "BTCB")
            .network("BSC")
            .block_range(48000000, 48010000)
            .ignore_non_existing()
        )
        assert query._params["token"] == "USDT,USDC,BTCB"
        assert query._params["network"] == "BSC"
        assert query._ignore_non_existing is True
        params = query._build_params()
        assert params["ignore_non_existing"] == "true"

    def test_ignore_non_existing_false_explicit(self):
        """ignore_non_existing(False) should not include the param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").ignore_non_existing(False)
        assert query._ignore_non_existing is False
        params = query._build_params()
        assert "ignore_non_existing" not in params

    def test_async_ignore_non_existing(self):
        """Async builder should support ignore_non_existing."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT", "USDC").ignore_non_existing()
        assert isinstance(query, AsyncQueryBuilder)
        assert query._ignore_non_existing is True
        params = query._build_params()
        assert params["ignore_non_existing"] == "true"


class TestAsyncBuilderPattern:
    """Test async builder pattern."""

    def test_async_transfers_returns_async_query_builder(self):
        """Async protocol methods should return AsyncQueryBuilder."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert isinstance(query, AsyncQueryBuilder)

    def test_async_builder_chaining(self):
        """Async builder methods should chain correctly."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").network("ETH").start_block(21000000).end_block(21010000)
        assert isinstance(query, AsyncQueryBuilder)
        assert query._params["network"] == "ETH"


class TestEVMEndpointPaths:
    """Test that EVM protocols use /evm/ prefixed paths."""

    def test_erc20_endpoint(self):
        """ERC20 transfers should use /evm/erc20/events/transfer."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT")
        assert query._endpoint == "/evm/erc20/events/transfer"

    def test_native_endpoint(self):
        """Native transfers should use /evm/native/events/transfer."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.native.transfers()
        assert query._endpoint == "/evm/native/events/transfer"

    def test_aave_deposit_endpoint(self):
        """AAVE deposits should use /evm/aave_v3/events/deposit."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.aave_v3.deposits()
        assert query._endpoint == "/evm/aave_v3/events/deposit"

    def test_aave_flashloan_endpoint(self):
        """AAVE flashloans should use /evm/aave_v3/events/flashloan."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.aave_v3.flashloans()
        assert query._endpoint == "/evm/aave_v3/events/flashloan"

    def test_uniswap_swap_endpoint(self):
        """Uniswap swaps should use /evm/uniswap_v3/events/swap."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.uniswap_v3.swaps("WETH", "USDC", 500)
        assert query._endpoint == "/evm/uniswap_v3/events/swap"

    def test_uniswap_deposit_endpoint(self):
        """Uniswap deposits should use /evm/uniswap_v3/events/deposit."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.uniswap_v3.deposits("WETH", "USDC", 500)
        assert query._endpoint == "/evm/uniswap_v3/events/deposit"

    def test_uniswap_withdraw_endpoint(self):
        """Uniswap withdrawals should use /evm/uniswap_v3/events/withdraw."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.uniswap_v3.withdrawals("WETH", "USDC", 500)
        assert query._endpoint == "/evm/uniswap_v3/events/withdraw"

    def test_uniswap_collect_endpoint(self):
        """Uniswap collects should use /evm/uniswap_v3/events/collect."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.uniswap_v3.collects("WETH", "USDC", 500)
        assert query._endpoint == "/evm/uniswap_v3/events/collect"

    def test_lido_deposit_endpoint(self):
        """Lido deposits should use /evm/lido/events/deposit."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.lido.deposits()
        assert query._endpoint == "/evm/lido/events/deposit"

    def test_stader_deposit_endpoint(self):
        """Stader deposits should use /evm/stader/events/deposit."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.stader.deposits()
        assert query._endpoint == "/evm/stader/events/deposit"

    def test_threshold_deposit_endpoint(self):
        """Threshold deposits should use /evm/threshold/events/deposit."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.threshold.deposits()
        assert query._endpoint == "/evm/threshold/events/deposit"


class TestUniswapBuilder:
    """Test Uniswap-specific builder methods."""

    def test_swaps_with_tokens_and_fee(self):
        """swaps() should accept symbol0, symbol1, fee."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.uniswap_v3.swaps("WETH", "USDC", 500)
        assert query._params["symbol0"] == "WETH"
        assert query._params["symbol1"] == "USDC"
        assert query._params["fee"] == 500

    def test_symbol_and_fee_chain_methods(self):
        """symbol0, symbol1, fee should work as chain methods."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.uniswap_v3.swaps().symbol0("WETH").symbol1("USDC").fee(3000)
        assert query._params["symbol0"] == "WETH"
        assert query._params["symbol1"] == "USDC"
        assert query._params["fee"] == 3000


class TestAAVEBuilder:
    """Test AAVE-specific builder methods."""

    def test_eth_market_type_filter(self):
        """eth_market_type should set param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.aave_v3.deposits().eth_market_type("Prime")
        assert query._params["eth_market_type"] == "Prime"


class TestQueryBuilderRepr:
    """Test QueryBuilder repr."""

    def test_repr(self):
        """Should have informative repr."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").network("ETH")
        repr_str = repr(query)
        assert "QueryBuilder" in repr_str
        assert "/evm/erc20/events/transfer" in repr_str


class TestTerminalMethods:
    """Test terminal methods."""

    def test_has_as_dict(self):
        """QueryBuilder should have as_dict method."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert hasattr(query, "as_dict")

    def test_has_as_df(self):
        """QueryBuilder should have as_df method."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert hasattr(query, "as_df")

    def test_has_as_file(self):
        """QueryBuilder should have as_file method."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert hasattr(query, "as_file")

    def test_as_df_invalid_library(self):
        """as_df should raise for invalid library."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        with pytest.raises(ValueError, match="library must be"):
            query.as_df("invalid")

    def test_as_file_requires_format_or_extension(self):
        """as_file should raise if no format or extension."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        with pytest.raises(ValueError, match="Cannot determine format"):
            query.as_file("transfers_without_extension")

    def test_as_file_invalid_format(self):
        """as_file should raise for invalid format."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        with pytest.raises(ValueError, match="format must be"):
            query.as_file("transfers", format="xml")


class TestAsyncTerminalMethods:
    """Test async terminal methods."""

    def test_async_has_as_dict(self):
        """AsyncQueryBuilder should have as_dict method."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert hasattr(query, "as_dict")

    def test_async_has_as_df(self):
        """AsyncQueryBuilder should have as_df method."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert hasattr(query, "as_df")

    def test_async_has_as_file(self):
        """AsyncQueryBuilder should have as_file method."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert hasattr(query, "as_file")


class TestLabelCategoryMethods:
    """Test label and category filter methods."""

    def test_involving_sets_param(self):
        """involving() should set involving param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving("0xA")
        assert query._params["involving"] == "0xA"

    def test_involving_label_sets_param(self):
        """involving_label() should set involving_label param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving_label("Binance")
        assert query._params["involving_label"] == "Binance"

    def test_involving_category_sets_param(self):
        """involving_category() should set involving_category param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving_category("CEX")
        assert query._params["involving_category"] == "CEX"

    def test_sender_label_sets_param(self):
        """sender_label() should set sender_label param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender_label("Binance")
        assert query._params["sender_label"] == "Binance"

    def test_sender_category_sets_param(self):
        """sender_category() should set sender_category param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender_category("CEX")
        assert query._params["sender_category"] == "CEX"

    def test_receiver_label_sets_param(self):
        """receiver_label() should set receiver_label param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().receiver_label("Coinbase")
        assert query._params["receiver_label"] == "Coinbase"

    def test_receiver_category_sets_param(self):
        """receiver_category() should set receiver_category param."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().receiver_category("DEX")
        assert query._params["receiver_category"] == "DEX"

    def test_label_chaining(self):
        """Label methods should chain with other methods."""
        client = DeFiStream(api_key="dsk_test")
        query = (
            client.evm.erc20.transfers("USDT")
            .network("ETH")
            .sender_label("Binance")
            .block_range(21000000, 21010000)
        )
        assert query._params["sender_label"] == "Binance"
        assert query._params["network"] == "ETH"
        assert query._params["block_start"] == 21000000

    def test_label_immutability(self):
        """Label methods should return new instances (immutability)."""
        client = DeFiStream(api_key="dsk_test")
        query1 = client.evm.erc20.transfers()
        query2 = query1.sender_label("Binance")
        assert query1 is not query2
        assert "sender_label" not in query1._params
        assert query2._params["sender_label"] == "Binance"

    def test_sender_and_receiver_labels_together(self):
        """sender_label and receiver_label should work together."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender_label("Binance").receiver_label("Coinbase")
        params = query._build_params()
        assert params["sender_label"] == "Binance"
        assert params["receiver_label"] == "Coinbase"


class TestMultiValueSupport:
    """Test multi-value support for address and label/category filters."""

    def test_sender_varargs_join(self):
        """sender() with multiple args should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender("0xA", "0xB", "0xC")
        assert query._params["sender"] == "0xA,0xB,0xC"

    def test_receiver_varargs_join(self):
        """receiver() with multiple args should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().receiver("0xA", "0xB")
        assert query._params["receiver"] == "0xA,0xB"

    def test_from_address_varargs_join(self):
        """from_address() with multiple args should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().from_address("0xA", "0xB")
        assert query._params["sender"] == "0xA,0xB"

    def test_to_address_varargs_join(self):
        """to_address() with multiple args should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().to_address("0xA", "0xB")
        assert query._params["receiver"] == "0xA,0xB"

    def test_involving_varargs_join(self):
        """involving() with multiple args should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving("0xA", "0xB")
        assert query._params["involving"] == "0xA,0xB"

    def test_involving_label_varargs_join(self):
        """involving_label() with multiple args should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving_label("Binance", "Coinbase")
        assert query._params["involving_label"] == "Binance,Coinbase"

    def test_involving_category_varargs_join(self):
        """involving_category() with multiple args should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving_category("CEX", "DEX")
        assert query._params["involving_category"] == "CEX,DEX"

    def test_sender_label_varargs_join(self):
        """sender_label() with multiple args should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender_label("Binance", "Coinbase")
        assert query._params["sender_label"] == "Binance,Coinbase"

    def test_pre_joined_string_passthrough(self):
        """A single pre-joined string should pass through unchanged."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender("0xA,0xB,0xC")
        assert query._params["sender"] == "0xA,0xB,0xC"

    def test_single_string_backward_compat(self):
        """Single string arg should still work."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender("0xA")
        assert query._params["sender"] == "0xA"

    def test_sender_no_args_raises(self):
        """sender() with no args should raise ValueError."""
        client = DeFiStream(api_key="dsk_test")
        with pytest.raises(ValueError, match="At least one value is required"):
            client.evm.erc20.transfers().sender()

    def test_involving_label_no_args_raises(self):
        """involving_label() with no args should raise ValueError."""
        client = DeFiStream(api_key="dsk_test")
        with pytest.raises(ValueError, match="At least one value is required"):
            client.evm.erc20.transfers().involving_label()


class TestMutualExclusivity:
    """Test mutual exclusivity validation between filter slots."""

    def test_involving_vs_involving_label_raises(self):
        """involving + involving_label should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving("0xA").involving_label("Binance")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_involving_vs_involving_category_raises(self):
        """involving + involving_category should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving("0xA").involving_category("CEX")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_involving_label_vs_involving_category_raises(self):
        """involving_label + involving_category should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving_label("Binance").involving_category("CEX")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_sender_vs_sender_label_raises(self):
        """sender + sender_label should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender("0xA").sender_label("Binance")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_sender_vs_sender_category_raises(self):
        """sender + sender_category should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender("0xA").sender_category("CEX")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_receiver_vs_receiver_label_raises(self):
        """receiver + receiver_label should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().receiver("0xA").receiver_label("Coinbase")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_receiver_vs_receiver_category_raises(self):
        """receiver + receiver_category should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().receiver("0xA").receiver_category("CEX")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_involving_with_sender_raises(self):
        """involving + sender should raise ValidationError (cross-slot)."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving("0xA").sender("0xB")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_involving_label_with_receiver_label_raises(self):
        """involving_label + receiver_label should raise ValidationError (cross-slot)."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving_label("Binance").receiver_label("Coinbase")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_involving_category_with_sender_category_raises(self):
        """involving_category + sender_category should raise ValidationError (cross-slot)."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving_category("CEX").sender_category("DEX")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_sender_and_receiver_valid(self):
        """sender + receiver should be valid (different slots, no involving)."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender("0xA").receiver("0xB")
        params = query._build_params()
        assert params["sender"] == "0xA"
        assert params["receiver"] == "0xB"

    def test_sender_label_and_receiver_category_valid(self):
        """sender_label + receiver_category should be valid."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender_label("Binance").receiver_category("DEX")
        params = query._build_params()
        assert params["sender_label"] == "Binance"
        assert params["receiver_category"] == "DEX"


class TestSQLSafetyValidation:
    """Test SQL safety validation for label/category params."""

    def test_single_quote_in_label_raises(self):
        """Label with single quote should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving_label("Binance'; DROP TABLE--")
        with pytest.raises(ValidationError, match="unsafe characters"):
            query._build_params()

    def test_backslash_in_label_raises(self):
        """Label with backslash should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender_label("Binance\\x00")
        with pytest.raises(ValidationError, match="unsafe characters"):
            query._build_params()

    def test_single_quote_in_category_raises(self):
        """Category with single quote should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().receiver_category("CEX'")
        with pytest.raises(ValidationError, match="unsafe characters"):
            query._build_params()

    def test_backslash_in_category_raises(self):
        """Category with backslash should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving_category("CEX\\")
        with pytest.raises(ValidationError, match="unsafe characters"):
            query._build_params()

    def test_clean_label_passes(self):
        """Clean label values should pass validation."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving_label("Binance 14")
        params = query._build_params()
        assert params["involving_label"] == "Binance 14"

    def test_address_params_not_checked(self):
        """Address params (sender, receiver) should not be SQL-checked."""
        client = DeFiStream(api_key="dsk_test")
        # Addresses can contain any characters -- only label/category is checked
        query = client.evm.erc20.transfers().sender("0x'abc")
        params = query._build_params()
        assert params["sender"] == "0x'abc"


class TestAsyncLabelCategoryMethods:
    """Test label/category methods on AsyncQueryBuilder."""

    def test_async_involving_label(self):
        """Async involving_label should set param."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving_label("Binance")
        assert isinstance(query, AsyncQueryBuilder)
        assert query._params["involving_label"] == "Binance"

    def test_async_sender_multi_value(self):
        """Async sender with multiple args should join."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender("0xA", "0xB")
        assert query._params["sender"] == "0xA,0xB"

    def test_async_mutual_exclusivity(self):
        """Async builder should enforce mutual exclusivity."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().involving("0xA").sender("0xB")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_async_sql_safety(self):
        """Async builder should enforce SQL safety."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().sender_label("test'injection")
        with pytest.raises(ValidationError, match="unsafe characters"):
            query._build_params()

    def test_async_label_chaining(self):
        """Async label methods should chain correctly."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = (
            client.evm.erc20.transfers("USDT")
            .network("ETH")
            .sender_label("Binance", "Coinbase")
            .receiver_category("DEX")
        )
        assert query._params["sender_label"] == "Binance,Coinbase"
        assert query._params["receiver_category"] == "DEX"


class TestAggregateBuilder:
    """Test aggregate query builder."""

    def test_aggregate_returns_aggregate_builder(self):
        """aggregate() should return AggregateQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").network("ETH").aggregate()
        assert isinstance(query, AggregateQueryBuilder)

    def test_aggregate_appends_to_endpoint(self):
        """aggregate() should append /aggregate to endpoint."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").aggregate()
        assert query._endpoint == "/evm/erc20/events/transfer/aggregate"

    def test_aggregate_sets_group_by_and_period(self):
        """aggregate() should set group_by and period params."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().aggregate(group_by="block", period="100b")
        assert query._params["group_by"] == "block"
        assert query._params["period"] == "100b"

    def test_aggregate_default_params(self):
        """aggregate() should default to group_by='time', period='1h'."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().aggregate()
        assert query._params["group_by"] == "time"
        assert query._params["period"] == "1h"

    def test_aggregate_preserves_filters(self):
        """Filters set before .aggregate() should be preserved."""
        client = DeFiStream(api_key="dsk_test")
        query = (
            client.evm.erc20.transfers("USDT")
            .network("ETH")
            .block_range(21000000, 21100000)
            .min_amount(1000)
            .aggregate(group_by="time", period="2h")
        )
        assert query._params["token"] == "USDT"
        assert query._params["network"] == "ETH"
        assert query._params["block_start"] == 21000000
        assert query._params["block_end"] == 21100000
        assert query._params["min_amount"] == 1000
        assert query._params["group_by"] == "time"
        assert query._params["period"] == "2h"

    def test_aggregate_preserves_verbose(self):
        """Verbose mode should carry through to aggregate builder."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().verbose().aggregate()
        assert query._verbose is True
        params = query._build_params()
        assert params["verbose"] == "true"

    def test_chaining_after_aggregate_preserves_type(self):
        """Chaining filter methods after .aggregate() should preserve AggregateQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().aggregate().network("ETH").min_amount(500)
        assert isinstance(query, AggregateQueryBuilder)
        assert query._params["network"] == "ETH"
        assert query._params["min_amount"] == 500

    def test_aggregate_builder_immutability(self):
        """AggregateQueryBuilder methods should return new instances."""
        client = DeFiStream(api_key="dsk_test")
        query1 = client.evm.erc20.transfers().aggregate()
        query2 = query1.network("ETH")
        assert query1 is not query2
        assert "network" not in query1._params
        assert query2._params["network"] == "ETH"

    def test_aggregate_builder_repr(self):
        """AggregateQueryBuilder should have informative repr."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").aggregate()
        repr_str = repr(query)
        assert "AggregateQueryBuilder" in repr_str
        assert "/aggregate" in repr_str

    def test_aggregate_uniswap_endpoint(self):
        """aggregate() should work with Uniswap endpoints."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.uniswap_v3.swaps("WETH", "USDC", 500).aggregate(group_by="time", period="1h")
        assert query._endpoint == "/evm/uniswap_v3/events/swap/aggregate"
        assert isinstance(query, AggregateQueryBuilder)

    def test_aggregate_aave_endpoint(self):
        """aggregate() should work with AAVE endpoints."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.aave_v3.deposits().aggregate(group_by="block", period="50b")
        assert query._endpoint == "/evm/aave_v3/events/deposit/aggregate"

    def test_aggregate_validation_still_works(self):
        """Mutual exclusivity validation should still apply on aggregate builder."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().aggregate().involving("0xA").sender("0xB")
        with pytest.raises(ValidationError, match="Cannot combine"):
            query._build_params()

    def test_aggregate_sql_safety_still_works(self):
        """SQL safety validation should still apply on aggregate builder."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().aggregate().sender_label("test'injection")
        with pytest.raises(ValidationError, match="unsafe characters"):
            query._build_params()


class TestAsyncAggregateBuilder:
    """Test async aggregate query builder."""

    def test_async_aggregate_returns_async_aggregate_builder(self):
        """async aggregate() should return AsyncAggregateQueryBuilder."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").network("ETH").aggregate()
        assert isinstance(query, AsyncAggregateQueryBuilder)

    def test_async_aggregate_appends_to_endpoint(self):
        """async aggregate() should append /aggregate to endpoint."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").aggregate()
        assert query._endpoint == "/evm/erc20/events/transfer/aggregate"

    def test_async_aggregate_sets_params(self):
        """async aggregate() should set group_by and period params."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().aggregate(group_by="block", period="200b")
        assert query._params["group_by"] == "block"
        assert query._params["period"] == "200b"

    def test_async_chaining_after_aggregate_preserves_type(self):
        """Chaining after async aggregate should preserve AsyncAggregateQueryBuilder."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().aggregate().network("ETH").sender("0xA")
        assert isinstance(query, AsyncAggregateQueryBuilder)
        assert query._params["network"] == "ETH"
        assert query._params["sender"] == "0xA"

    def test_async_aggregate_preserves_filters(self):
        """Filters set before async aggregate should be preserved."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = (
            client.evm.erc20.transfers("USDT")
            .network("ETH")
            .block_range(21000000, 21100000)
            .aggregate(group_by="time", period="4h")
        )
        assert query._params["token"] == "USDT"
        assert query._params["network"] == "ETH"
        assert query._params["block_start"] == 21000000
        assert query._params["block_end"] == 21100000
        assert query._params["group_by"] == "time"
        assert query._params["period"] == "4h"

    def test_async_aggregate_builder_repr(self):
        """AsyncAggregateQueryBuilder should have informative repr."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers("USDT").aggregate()
        repr_str = repr(query)
        assert "AsyncAggregateQueryBuilder" in repr_str
        assert "/aggregate" in repr_str


class TestAggregateSchema:
    """Test aggregate_schema discovery method."""

    def test_sync_aggregate_schema_calls_correct_endpoint(self):
        """aggregate_schema should call GET /{protocol}/aggregate_schema."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client, "aggregate_schema")

    def test_async_aggregate_schema_exists(self):
        """async client should have aggregate_schema method."""
        client = AsyncDeFiStream(api_key="dsk_test")
        assert hasattr(client, "aggregate_schema")


class TestProcessResponseDataKey:
    """Test that _process_response handles the 'data' response key."""

    def test_process_response_with_data_key(self):
        """_process_response should extract from 'data' key when response_key='data'."""
        client = DeFiStream(api_key="dsk_test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"Content-Type": "application/json"}
        mock_response.json.return_value = {
            "status": "ok",
            "data": [
                {"bucket": "2024-01-01T00:00:00Z", "count": 42, "total_amount": 1000.0},
                {"bucket": "2024-01-01T01:00:00Z", "count": 15, "total_amount": 500.0},
            ],
        }
        result = client._process_response(mock_response, response_key="data")
        assert len(result) == 2
        assert result[0]["count"] == 42
        assert result[1]["total_amount"] == 500.0

    def test_process_response_default_events_key(self):
        """_process_response should default to 'events' key."""
        client = DeFiStream(api_key="dsk_test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"Content-Type": "application/json"}
        mock_response.json.return_value = {
            "status": "ok",
            "events": [
                {"block_number": 21000000, "amount": 100.0},
            ],
        }
        result = client._process_response(mock_response)
        assert len(result) == 1
        assert result[0]["block_number"] == 21000000

    def test_process_response_data_key_empty(self):
        """_process_response should return empty list when 'data' key is missing."""
        client = DeFiStream(api_key="dsk_test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"Content-Type": "application/json"}
        mock_response.json.return_value = {"status": "ok"}
        result = client._process_response(mock_response, response_key="data")
        assert result == []


class TestAsLinkMethod:
    """Test as_link() terminal method."""

    def test_has_as_link(self):
        """QueryBuilder should have as_link method."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert hasattr(query, "as_link")

    def test_as_link_invalid_format_json(self):
        """as_link should raise for json format."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        with pytest.raises(ValueError, match="format must be"):
            query.as_link("json")

    def test_as_link_invalid_format_xml(self):
        """as_link should raise for xml format."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        with pytest.raises(ValueError, match="format must be"):
            query.as_link("xml")

    def test_async_has_as_link(self):
        """AsyncQueryBuilder should have as_link method."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers()
        assert hasattr(query, "as_link")

    def test_aggregate_has_as_link(self):
        """AggregateQueryBuilder should have as_link method."""
        client = DeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().aggregate()
        assert hasattr(query, "as_link")

    def test_async_aggregate_has_as_link(self):
        """AsyncAggregateQueryBuilder should have as_link method."""
        client = AsyncDeFiStream(api_key="dsk_test")
        query = client.evm.erc20.transfers().aggregate()
        assert hasattr(query, "as_link")


class TestBinanceProtocol:
    """Test BinanceProtocol and its builder methods."""

    def test_sync_client_has_binance(self):
        """DeFiStream should have binance via exchange namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.exchange, "binance")
        assert isinstance(client.exchange.binance, BinanceProtocol)

    def test_async_client_has_binance(self):
        """AsyncDeFiStream should have binance via exchange namespace."""
        client = AsyncDeFiStream(api_key="dsk_test")
        assert hasattr(client.exchange, "binance")
        assert isinstance(client.exchange.binance, AsyncBinanceProtocol)

    def test_raw_trades_returns_trade_query_builder(self):
        """binance.raw_trades() should return TradeQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades()
        assert isinstance(builder, TradeQueryBuilder)

    def test_ohlcv_returns_ohlcv_query_builder(self):
        """binance.ohlcv() should return OHLCVQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.ohlcv()
        assert isinstance(builder, OHLCVQueryBuilder)

    def test_async_raw_trades_returns_async_trade_query_builder(self):
        """async binance.raw_trades() should return AsyncTradeQueryBuilder."""
        client = AsyncDeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades()
        assert isinstance(builder, AsyncTradeQueryBuilder)

    def test_async_ohlcv_returns_async_ohlcv_query_builder(self):
        """async binance.ohlcv() should return AsyncOHLCVQueryBuilder."""
        client = AsyncDeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.ohlcv()
        assert isinstance(builder, AsyncOHLCVQueryBuilder)

    def test_raw_trades_endpoint(self):
        """raw_trades() should use /exchange/binance/raw_trades endpoint."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades()
        assert builder._endpoint == "/exchange/binance/raw_trades"

    def test_ohlcv_endpoint(self):
        """ohlcv() should use /exchange/binance/ohlcv endpoint."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.ohlcv()
        assert builder._endpoint == "/exchange/binance/ohlcv"

    def test_book_depth_endpoint(self):
        """book_depth() should use /exchange/binance/book_depth endpoint."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.book_depth()
        assert builder._endpoint == "/exchange/binance/book_depth"

    def test_open_interest_endpoint(self):
        """open_interest() should use /exchange/binance/open_interest endpoint."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.open_interest()
        assert builder._endpoint == "/exchange/binance/open_interest"

    def test_long_short_ratios_endpoint(self):
        """long_short_ratios() should use /exchange/binance/long_short_ratios endpoint."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.long_short_ratios()
        assert builder._endpoint == "/exchange/binance/long_short_ratios"

    def test_funding_rate_endpoint(self):
        """funding_rate() should use /exchange/binance/funding_rate endpoint."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.funding_rate()
        assert builder._endpoint == "/exchange/binance/funding_rate"


class TestHyperliquidProtocol:
    """Test HyperliquidProtocol and its builder methods."""

    def test_sync_client_has_hyperliquid(self):
        """DeFiStream should have hyperliquid via exchange namespace."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.exchange, "hyperliquid")
        assert isinstance(client.exchange.hyperliquid, HyperliquidProtocol)

    def test_fills_returns_hl_query_builder(self):
        """fills() should return HLQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills()
        assert isinstance(builder, HLQueryBuilder)

    def test_trades_returns_hl_query_builder(self):
        """trades() should return HLQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.trades()
        assert isinstance(builder, HLQueryBuilder)

    def test_ohlcv_returns_hl_query_builder(self):
        """ohlcv() should return HLQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.ohlcv()
        assert isinstance(builder, HLQueryBuilder)

    def test_positions_returns_hl_query_builder(self):
        """positions() should return HLQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.positions()
        assert isinstance(builder, HLQueryBuilder)

    def test_funding_returns_hl_query_builder(self):
        """funding() should return HLQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.funding()
        assert isinstance(builder, HLQueryBuilder)

    def test_transfers_returns_hl_query_builder(self):
        """transfers() should return HLQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.transfers()
        assert isinstance(builder, HLQueryBuilder)

    def test_vaults_returns_hl_query_builder(self):
        """vaults() should return HLQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.vaults()
        assert isinstance(builder, HLQueryBuilder)

    def test_sends_returns_hl_query_builder(self):
        """sends() should return HLQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.sends()
        assert isinstance(builder, HLQueryBuilder)

    def test_spot_transfers_returns_hl_query_builder(self):
        """spot_transfers() should return HLQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.spot_transfers()
        assert isinstance(builder, HLQueryBuilder)

    def test_wallet_stats_returns_hl_query_builder(self):
        """wallet_stats() should return HLQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.wallet_stats()
        assert isinstance(builder, HLQueryBuilder)

    def test_wallet_stats_endpoint(self):
        """wallet_stats() should use /exchange/hyperliquid/wallet_stats endpoint."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.wallet_stats()
        assert builder._endpoint == "/exchange/hyperliquid/wallet_stats"

    def test_async_wallet_stats_returns_async_hl_query_builder(self):
        """async wallet_stats() should return AsyncHLQueryBuilder."""
        client = AsyncDeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.wallet_stats()
        assert isinstance(builder, AsyncHLQueryBuilder)

    def test_fills_endpoint(self):
        """fills() should use /exchange/hyperliquid/fills endpoint."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills()
        assert builder._endpoint == "/exchange/hyperliquid/fills"

    def test_trades_endpoint(self):
        """trades() should use /exchange/hyperliquid/trades endpoint."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.trades()
        assert builder._endpoint == "/exchange/hyperliquid/trades"

    def test_async_fills_returns_async_hl_query_builder(self):
        """async fills() should return AsyncHLQueryBuilder."""
        client = AsyncDeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills()
        assert isinstance(builder, AsyncHLQueryBuilder)


class TestHLQueryBuilder:
    """Test HLQueryBuilder builder methods."""

    def test_tokens_sets_param(self):
        """tokens() should set tokens param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().tokens("ETH")
        assert builder._params["tokens"] == "ETH"

    def test_tokens_multiple(self):
        """tokens() with multiple args should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().tokens("ETH", "BTC")
        assert builder._params["tokens"] == "ETH,BTC"

    def test_wallets_sets_param(self):
        """wallets() should set wallets param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().wallets("0xABC")
        assert builder._params["wallets"] == "0xABC"

    def test_wallets_multiple(self):
        """wallets() with multiple args should join with comma."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().wallets("0xA", "0xB")
        assert builder._params["wallets"] == "0xA,0xB"

    def test_date_range_sets_params(self):
        """date_range() should set date_start and date_end params."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().date_range("2024-01-01", "2024-02-01")
        assert builder._params["date_start"] == "2024-01-01"
        assert builder._params["date_end"] == "2024-02-01"

    def test_block_range_sets_params(self):
        """block_range() should set block_start and block_end params."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().block_range(1000, 2000)
        assert builder._params["block_start"] == 1000
        assert builder._params["block_end"] == 2000

    def test_market_type_sets_param(self):
        """market_type() should set market_type param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().market_type("perp")
        assert builder._params["market_type"] == "perp"

    def test_limit_sets_param(self):
        """limit() should set limit param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().limit(100)
        assert builder._params["limit"] == 100

    def test_format_sets_param(self):
        """format() should set format param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().format("csv")
        assert builder._params["format"] == "csv"

    def test_per_token_sets_param_true(self):
        """per_token(True) should set per_token='true'."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.wallet_stats().per_token(True)
        assert builder._params["per_token"] == "true"

    def test_per_token_sets_param_false(self):
        """per_token(False) should set per_token='false'."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.wallet_stats().per_token(False)
        assert builder._params["per_token"] == "false"

    def test_skip_hip3_sets_param_true(self):
        """skip_hip3(True) should set skip_hip3='true'."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().skip_hip3(True)
        assert builder._params["skip_hip3"] == "true"

    def test_skip_hip3_sets_param_false(self):
        """skip_hip3(False) should set skip_hip3='false'."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().skip_hip3(False)
        assert builder._params["skip_hip3"] == "false"

    def test_skip_hip3_default_true(self):
        """skip_hip3() with no args should default to True."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.trades().skip_hip3()
        assert builder._params["skip_hip3"] == "true"

    def test_wallet_stats_chaining(self):
        """wallet_stats builder should chain with all relevant methods."""
        client = DeFiStream(api_key="dsk_test")
        builder = (
            client.exchange.hyperliquid.wallet_stats()
            .wallets("0xABC")
            .tokens("BTC", "ETH")
            .date_range("2026-04-09", "2026-04-12")
            .window("1d")
            .per_token(False)
            .skip_hip3(True)
        )
        assert builder._params["wallets"] == "0xABC"
        assert builder._params["tokens"] == "BTC,ETH"
        assert builder._params["window"] == "1d"
        assert builder._params["per_token"] == "false"
        assert builder._params["skip_hip3"] == "true"

    def test_chaining(self):
        """Builder methods should chain correctly."""
        client = DeFiStream(api_key="dsk_test")
        builder = (
            client.exchange.hyperliquid.fills()
            .tokens("ETH", "BTC")
            .wallets("0xABC")
            .date_range("2024-01-01", "2024-02-01")
            .market_type("perp")
            .limit(50)
        )
        assert builder._params["tokens"] == "ETH,BTC"
        assert builder._params["wallets"] == "0xABC"
        assert builder._params["date_start"] == "2024-01-01"
        assert builder._params["date_end"] == "2024-02-01"
        assert builder._params["market_type"] == "perp"
        assert builder._params["limit"] == 50

    def test_immutability(self):
        """Builder methods should return new instances."""
        client = DeFiStream(api_key="dsk_test")
        original = client.exchange.hyperliquid.fills().tokens("ETH")
        with_wallets = original.wallets("0xABC")
        assert original is not with_wallets
        assert "wallets" not in original._params
        assert with_wallets._params["wallets"] == "0xABC"

    def test_repr(self):
        """HLQueryBuilder should have informative repr."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills().tokens("ETH")
        r = repr(builder)
        assert "HLQueryBuilder" in r
        assert "/exchange/hyperliquid/fills" in r

    def test_has_terminal_methods(self):
        """HLQueryBuilder should have all terminal methods."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills()
        assert hasattr(builder, "as_dict")
        assert hasattr(builder, "as_df")
        assert hasattr(builder, "as_file")

    def test_as_df_invalid_library_raises(self):
        """as_df() with invalid library should raise ValueError."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.hyperliquid.fills()
        with pytest.raises(ValueError, match="library must be"):
            builder.as_df("invalid")


class TestTradeQueryBuilder:
    """Test TradeQueryBuilder builder methods."""

    def test_token_sets_param(self):
        """token() should set token param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().token("BTC")
        assert builder._params["token"] == "BTC"

    def test_start_time_sets_since(self):
        """start_time() should set since param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().start_time("2024-01-01T00:00:00Z")
        assert builder._params["since"] == "2024-01-01T00:00:00Z"

    def test_end_time_sets_until(self):
        """end_time() should set until param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().end_time("2024-02-01T00:00:00Z")
        assert builder._params["until"] == "2024-02-01T00:00:00Z"

    def test_time_range_sets_both(self):
        """time_range() should set both since and until params."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().time_range("2024-01-01", "2024-02-01")
        assert builder._params["since"] == "2024-01-01"
        assert builder._params["until"] == "2024-02-01"

    def test_skip_id_sets_param(self):
        """skip_id() should set skip_id param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().skip_id(12345)
        assert builder._params["skip_id"] == 12345

    def test_chaining_sets_all_params(self):
        """Chaining should set all params correctly."""
        client = DeFiStream(api_key="dsk_test")
        builder = (
            client.exchange.binance.raw_trades()
            .token("BTC")
            .start_time("2024-01-01T00:00:00Z")
            .end_time("2024-01-02T00:00:00Z")
        )
        assert builder._params["token"] == "BTC"
        assert builder._params["since"] == "2024-01-01T00:00:00Z"
        assert builder._params["until"] == "2024-01-02T00:00:00Z"

    def test_immutability(self):
        """Chaining should not mutate original builder."""
        client = DeFiStream(api_key="dsk_test")
        original = client.exchange.binance.raw_trades().token("BTC")
        with_time = original.start_time("2024-01-01")
        assert original is not with_time
        assert "since" not in original._params
        assert with_time._params["since"] == "2024-01-01"

    def test_as_dict_raises_validation_error(self):
        """as_dict() should raise ValidationError for raw trades."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().token("BTC")
        with pytest.raises(ValidationError, match="Raw trades do not support JSON format"):
            builder.as_dict()

    def test_as_file_json_extension_raises(self):
        """as_file() with .json extension should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().token("BTC")
        with pytest.raises(ValidationError, match="Raw trades do not support JSON format"):
            builder.as_file("trades.json")

    def test_as_file_json_format_raises(self):
        """as_file() with format='json' should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().token("BTC")
        with pytest.raises(ValidationError, match="Raw trades do not support JSON format"):
            builder.as_file("trades", format="json")

    def test_as_file_invalid_format_raises(self):
        """as_file() with unknown format should raise ValueError."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().token("BTC")
        with pytest.raises(ValueError, match="format must be"):
            builder.as_file("trades", format="xml")

    def test_as_file_no_extension_raises(self):
        """as_file() with no extension and no format should raise ValueError."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().token("BTC")
        with pytest.raises(ValueError, match="Cannot determine format"):
            builder.as_file("trades_without_extension")

    def test_as_df_invalid_library_raises(self):
        """as_df() with invalid library should raise ValueError."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().token("BTC")
        with pytest.raises(ValueError, match="library must be"):
            builder.as_df("invalid")

    def test_as_link_invalid_format_raises(self):
        """as_link() with invalid format should raise ValueError."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().token("BTC")
        with pytest.raises(ValueError, match="format must be"):
            builder.as_link("json")

    def test_time_range_over_7_days_raises(self):
        """_build_params() should raise ValidationError when range exceeds 7 days."""
        client = DeFiStream(api_key="dsk_test")
        builder = (
            client.exchange.binance.raw_trades()
            .token("BTC")
            .time_range("2024-01-01", "2024-01-15")
        )
        with pytest.raises(ValidationError, match="limited to a maximum range of 7 days"):
            builder._build_params()

    def test_time_range_within_7_days_ok(self):
        """_build_params() should succeed when range is within 7 days."""
        client = DeFiStream(api_key="dsk_test")
        builder = (
            client.exchange.binance.raw_trades()
            .token("BTC")
            .time_range("2024-01-01", "2024-01-05")
        )
        params = builder._build_params()
        assert params["since"] == "2024-01-01"
        assert params["until"] == "2024-01-05"

    def test_repr(self):
        """TradeQueryBuilder should have informative repr."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.raw_trades().token("BTC")
        r = repr(builder)
        assert "TradeQueryBuilder" in r
        assert "/exchange/binance/raw_trades" in r


class TestOHLCVQueryBuilder:
    """Test OHLCVQueryBuilder builder methods."""

    def test_token_sets_param(self):
        """token() should set token param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.ohlcv().token("ETH")
        assert builder._params["token"] == "ETH"

    def test_window_sets_param(self):
        """window() should set window param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.ohlcv().window("4h")
        assert builder._params["window"] == "4h"

    def test_window_valid_values(self):
        """All valid window sizes should be accepted."""
        client = DeFiStream(api_key="dsk_test")
        for size in ("1m", "5m", "15m", "30m", "1h", "4h", "1d"):
            builder = client.exchange.binance.ohlcv().window(size)
            assert builder._params["window"] == size

    def test_window_invalid_raises(self):
        """Invalid window size should raise ValidationError."""
        client = DeFiStream(api_key="dsk_test")
        with pytest.raises(ValidationError, match="Invalid window"):
            client.exchange.binance.ohlcv().window("bad")

    def test_window_invalid_2h_raises(self):
        """'2h' is not a valid window size."""
        client = DeFiStream(api_key="dsk_test")
        with pytest.raises(ValidationError, match="Invalid window"):
            client.exchange.binance.ohlcv().window("2h")

    def test_start_time_sets_since(self):
        """start_time() should set since param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.ohlcv().start_time("2024-01-01")
        assert builder._params["since"] == "2024-01-01"

    def test_end_time_sets_until(self):
        """end_time() should set until param."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.ohlcv().end_time("2024-02-01")
        assert builder._params["until"] == "2024-02-01"

    def test_time_range_sets_both(self):
        """time_range() should set both since and until."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.ohlcv().time_range("2024-01-01", "2024-02-01")
        assert builder._params["since"] == "2024-01-01"
        assert builder._params["until"] == "2024-02-01"

    def test_immutability(self):
        """Chaining should not mutate original builder."""
        client = DeFiStream(api_key="dsk_test")
        original = client.exchange.binance.ohlcv().token("BTC")
        with_window = original.window("1h")
        assert original is not with_window
        assert "window" not in original._params
        assert with_window._params["window"] == "1h"

    def test_chaining_all_params(self):
        """Full chain should set all params."""
        client = DeFiStream(api_key="dsk_test")
        builder = (
            client.exchange.binance.ohlcv()
            .token("BTC")
            .window("4h")
            .start_time("2024-01-01")
            .end_time("2024-02-01")
        )
        assert builder._params["token"] == "BTC"
        assert builder._params["window"] == "4h"
        assert builder._params["since"] == "2024-01-01"
        assert builder._params["until"] == "2024-02-01"

    def test_has_as_dict(self):
        """OHLCVQueryBuilder should have as_dict method."""
        client = DeFiStream(api_key="dsk_test")
        assert hasattr(client.exchange.binance.ohlcv(), "as_dict")

    def test_as_file_invalid_format_raises(self):
        """as_file() with unknown format should raise ValueError."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.ohlcv().token("BTC")
        with pytest.raises(ValueError, match="format must be"):
            builder.as_file("ohlcv", format="xml")

    def test_time_range_over_31_days_raises(self):
        """_build_params() should raise ValidationError when range exceeds 31 days."""
        client = DeFiStream(api_key="dsk_test")
        builder = (
            client.exchange.binance.ohlcv()
            .token("BTC")
            .time_range("2024-01-01", "2024-03-01")
        )
        with pytest.raises(ValidationError, match="limited to a maximum range of 31 days"):
            builder._build_params()

    def test_time_range_within_31_days_ok(self):
        """_build_params() should succeed when range is within 31 days."""
        client = DeFiStream(api_key="dsk_test")
        builder = (
            client.exchange.binance.ohlcv()
            .token("BTC")
            .time_range("2024-01-01", "2024-01-20")
        )
        params = builder._build_params()
        assert params["since"] == "2024-01-01"
        assert params["until"] == "2024-01-20"

    def test_repr(self):
        """OHLCVQueryBuilder should have informative repr."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.ohlcv().token("BTC")
        r = repr(builder)
        assert "OHLCVQueryBuilder" in r
        assert "/exchange/binance/ohlcv" in r


class TestExchangeDataQueryBuilder:
    """Test ExchangeDataQueryBuilder."""

    def test_book_depth_returns_exchange_data_builder(self):
        """book_depth() should return ExchangeDataQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.book_depth()
        assert isinstance(builder, ExchangeDataQueryBuilder)

    def test_open_interest_returns_exchange_data_builder(self):
        """open_interest() should return ExchangeDataQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.open_interest()
        assert isinstance(builder, ExchangeDataQueryBuilder)

    def test_long_short_ratios_returns_exchange_data_builder(self):
        """long_short_ratios() should return ExchangeDataQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.long_short_ratios()
        assert isinstance(builder, ExchangeDataQueryBuilder)

    def test_funding_rate_returns_exchange_data_builder(self):
        """funding_rate() should return ExchangeDataQueryBuilder."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.funding_rate()
        assert isinstance(builder, ExchangeDataQueryBuilder)

    def test_as_dict_raises_validation_error(self):
        """as_dict() should raise for exchange data."""
        client = DeFiStream(api_key="dsk_test")
        builder = client.exchange.binance.book_depth().token("BTC")
        with pytest.raises(ValidationError, match="do not support JSON"):
            builder.as_dict()

    def test_time_range_over_31_days_raises(self):
        """_build_params() should raise for range > 31 days."""
        client = DeFiStream(api_key="dsk_test")
        builder = (
            client.exchange.binance.open_interest()
            .token("BTC")
            .time_range("2024-01-01", "2024-03-01")
        )
        with pytest.raises(ValidationError, match="limited to a maximum range of 31 days"):
            builder._build_params()
