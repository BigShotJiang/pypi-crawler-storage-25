import type { HostConfig } from '../scripts/host-config';

const openclaw: HostConfig = {
  name: 'openclaw',
  displayName: 'OpenClaw',
  cliCommand: 'openclaw',
  cliAliases: [],

  globalRoot: '.openclaw/skills/ketacli',
  localSkillRoot: '.openclaw/skills/ketacli',
  hostSubdir: '.openclaw',
  usesEnvVars: true,

  frontmatter: {
    mode: 'allowlist',
    keepFields: ['name', 'description'],
    descriptionLimit: null,
  },

  generation: {
    generateMetadata: false,
    skipSkills: [],
  },

  pathRewrites: [],

  runtimeRoot: {
    globalSymlinks: ['bin'],
    globalFiles: {},
  },

  install: {
    prefixable: false,
    linkingStrategy: 'symlink-generated',
  },

  learningsMode: 'basic',
};

export default openclaw;
