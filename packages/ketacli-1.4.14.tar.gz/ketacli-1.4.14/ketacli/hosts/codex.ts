import type { HostConfig } from '../scripts/host-config';

const codex: HostConfig = {
  name: 'codex',
  displayName: 'OpenAI Codex CLI',
  cliCommand: 'codex',
  cliAliases: [],

  globalRoot: '.codex/skills/ketacli',
  localSkillRoot: '.codex/skills/ketacli',
  hostSubdir: '.codex',
  usesEnvVars: false,

  frontmatter: {
    mode: 'allowlist',
    keepFields: ['name', 'description'],
    descriptionLimit: null,
  },

  generation: {
    generateMetadata: false,
    skipSkills: [],
  },

  pathRewrites: [],

  runtimeRoot: {
    globalSymlinks: ['bin'],
    globalFiles: {},
  },

  install: {
    prefixable: false,
    linkingStrategy: 'symlink-generated',
  },

  learningsMode: 'basic',
};

export default codex;
