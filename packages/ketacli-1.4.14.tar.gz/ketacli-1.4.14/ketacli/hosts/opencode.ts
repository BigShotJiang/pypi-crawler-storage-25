import type { HostConfig } from '../scripts/host-config';

const ketacli: HostConfig = {
  name: 'ketacli',
  displayName: 'KetaDB CLI',
  cliCommand: 'ketacli',
  cliAliases: [],

  globalRoot: '.config/opencode/skills/ketacli',
  localSkillRoot: '.opencode/skills/ketacli',
  hostSubdir: '.opencode',
  usesEnvVars: true,

  frontmatter: {
    mode: 'allowlist',
    keepFields: ['name', 'description'],
    descriptionLimit: null,
  },

  generation: {
    generateMetadata: false,
    skipSkills: [],
  },

  pathRewrites: [
    { from: '~/.claude/skills/ketacli', to: '~/.config/opencode/skills/ketacli' },
    { from: '.claude/skills/ketacli', to: '.opencode/skills/ketacli' },
    { from: '.claude/skills', to: '.opencode/skills' },
  ],

  runtimeRoot: {
    globalSymlinks: ['bin'],
    globalFiles: {},
  },

  install: {
    prefixable: false,
    linkingStrategy: 'symlink-generated',
  },

  learningsMode: 'basic',
};

export default ketacli;
