---
name: spl-search
version: 1.0.0
description: |
  KetaDB SPL Search Tool — query logs and metrics from KetaDB using SPL syntax.
  Supports search2 engine for logs, mstats engine for metrics, time-based queries,
  aggregations, and real-time monitoring.
  Use when asked to "search logs", "query metrics", "find errors", or "analyze data".
allowed-tools:
  - Bash
  - Read
---

# spl-search

KetaDB SPL search tool for querying logs and metrics data.

## Authentication

```bash
# Login to KetaDB (if not already authenticated)
ketacli login -n <username> -e <endpoint> -t <token>

# Check current configuration
ketacli config list-clusters
```

## Basic Search

```bash
# Basic log search
ketacli search 'search2 repo="repo_name" | limit 10'

# Specify time range
ketacli search 'search2 start="-1h" end="@d" repo="repo_name" | limit 100'

# Output formats: text, json, csv, html
ketacli search 'search2 repo="repo_name" | limit 10' -f json
```

## SPL Syntax

### Basic Structure

```
search2 repo="repository_name" <conditions> | command1 | command2 | ...
```

**Field reference rules:**
- Field names use single quotes: `'field_name'`
- Field values use double quotes: `"value"`
- Use triple quotes for values containing double quotes: `"""value"""`

### Time Syntax

**Critical: Time parameters must come right after `search2` command, before `repo`**

```spl
# Relative time
search2 start="-1h" repo="logs"              # Last 1 hour
search2 start="-d@d" end="@d" repo="logs"  # Yesterday (full day)
search2 start="-3d" repo="logs"             # Last 3 days
search2 start="-M@M" end="@M" repo="logs"  # Last month

# Time units: s(seconds) m(minutes) h(hours) d(days) w(weeks) M(months) y(years)
# Alignment: @s @m @h @d @w @M @y
```

### Search & Filter

```spl
# Basic search
search2 start="-3d" repo="logs" 'status'=500 AND 'host'="web01"

# Full-text search
search2 repo="app_logs" "error"                              # Contains "error"
search2 repo="app_logs" "error" AND 'host'="web01"          # Combined conditions
search2 repo="app_logs" "error" OR "warning"                # OR conditions
search2 repo="app_logs" and (level in ("WARN","ERROR"))      # IN clause
```

### Field Operations

```spl
| fields 'timestamp', 'user', 'action'  # Select fields
| fields - '_raw', '_time'              # Exclude fields
| rename 'user' as 'username'           # Rename field
| eval 'response_sec' = 'response_time' / 1000  # Calculate field
| eval 'full_name' = 'first_name' + " " + 'last_name'  # String concat
```

### Statistics & Aggregation

```spl
| stats count() as cnt by status          # Count by group
| stats avg(response_time), max(response_time) by host

# Time series
| timechart span="1h" count() as requests
| timechart span="5m" avg(cpu_usage) by host

# Common functions: count(), sum(), avg(), min(), max(), distinct(), percentile()
```

### Sorting & Limiting

```spl
| sort by response_time asc     # Ascending
| sort by timestamp desc        # Descending
| limit 10
| dedup user                   # Deduplicate
| top 10 url                  # Top N
```

### Data Processing

```spl
# Regex extraction
| rex field='_raw' "(?<method>\w+)\s+(?<url>\S+)"

# Type conversion
| convert num('response_time')
```

## Common Patterns

### Error Analysis

```bash
# Error count by status
ketacli search 'search2 start="-24h" repo="web_logs" status>=400 | stats count() by status, url | sort by count desc'

# Error trends
ketacli search 'search2 start="-24h" repo="web_logs" | timechart span="1h" count() by status'
```

### Slow Request Analysis

```bash
ketacli search 'search2 repo="api_logs" response_time>1000 | stats avg(response_time) as avg_rt, count() as cnt by url | sort by avg_rt desc'
```

### User Behavior Analysis

```bash
ketacli search 'search2 start="-7d" repo="user_logs" | stats count() as actions, dc(session_id) as sessions by user | sort by actions desc'
```

### Anomaly Detection

```bash
ketacli search 'search2 repo="api_logs" | timechart span="5m" avg(response_time) as avg_time | eventstats avg(avg_time) as overall_avg, stdev(avg_time) as stdev | eval upper_bound = overall_avg + 2 * stdev | where avg_time > upper_bound'
```

## Real-time Monitoring

```bash
# Watch query results with refresh interval
ketacli search 'search2 repo="logs"' -w --interval 5
```

## Performance Tips

1. **Always use repo parameter**: `search2 repo="xxx"`
2. **Filter early**: Use full-text search for fast filtering
3. **Limit fields**: Use `fields` to reduce data transfer
4. **Use time range**: Avoid large time spans
5. **Limit results**: Use `limit` to reduce data volume
6. **Debug incrementally**: Start with `| limit 1` to see field structure

## Common Functions

| Function | Description | Example |
|----------|-------------|---------|
| `len(str)` | String length | `len('message')` |
| `substr(str, start, len)` | Substring | `substr('msg', 0, 10)` |
| `replace(str, old, new)` | Replace | `replace('a', 'b')` |
| `round(num, decimals)` | Round | `round(3.14159, 2)` |
| `if(cond, true, false)` | Conditional | `if(status>=200, "ok", "error")` |
| `now()` | Current time | `now()` |
| `isnull(field)` | Null check | `isnull('field')` |

## Output Format

| Format | Flag | Use Case |
|--------|------|----------|
| `text` | `-f text` | Human readable (default) |
| `json` | `-f json` | Programmatic processing |
| `csv` | `-f csv` | Spreadsheet analysis |
| `html` | `-f html` | Report generation |

## Notes

- Time parameters must be placed right after `search2` command
- Use `| limit 1` to quickly check data structure
- For complex queries, build incrementally
- Enable `--raw` to output raw timestamps instead of formatted time
