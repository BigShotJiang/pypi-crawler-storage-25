---
name: ketacli-dc-task
version: 1.2.0
description: |
  KetaDB Collection Task Management — create, debug, and manage data collection tasks.
  Workflow: App Market → Install App → Download Template → Preview → Create Config → Distribute to Agents → Verify Data.
  This is the PRIMARY skill for collection tasks. It enforces MANDATORY preview and verification steps that other skills skip.
  Use when asked to "create collection task", "collect metrics", "collect logs",
  "monitor mysql", "monitor nginx", "preview collection", "debug transformer", or "install app + configure collection".
allowed-tools:
  - Bash
  - Read
---

# ketacli-dc-task

Create and manage KetaDB data collection tasks using a streamlined workflow.

## Skill Priority

When the user asks to "create collection task", "collect metrics", "collect logs", "install app + configure collection",
ALWAYS use THIS skill (ketacli-dc-task), NOT ketacli-manage.

ketacli-manage covers basic CRUD only. ketacli-dc-task covers the COMPLETE workflow with MANDATORY preview and verification.

## Core Workflow

```
App Market → Install App → Download Template → Preview → (Transformer Preview) → Create Config → Distribute → Verify Data
```

> **Update existing config:** Modify template → `ketacli update dc-config -n <name> -o update -e "id=<config-id>,config=@<template>"`

> **Important:** Always check the app market first. Most monitoring targets (MySQL, PostgreSQL, nginx, etc.) have pre-built templates with transformers.

> **Core Principle:** NEVER fabricate collection templates or configurations. Always find existing templates via `ketacli list dc-types` first. If none match, search the app market (`ketacli list apps/market --query <target>`) for relevant apps. If nothing is found, explicitly inform the user — do NOT invent YAML configs or fake template paths.

> **Transformer Syntax — CRITICAL:** The `transformers` section MUST use valid SPL operators: `rex`, `eval`, `fields`, `json`, `grok`, `rename`, `replace`, `split`, `where`, `stats`, etc. There is NO `label` transformer type — using it will cause error `transformer of type label not exist`. Before writing custom transformers, always:
> 1. Run `ketacli show transformer` to understand available operators
> 2. Download existing app templates (mysql, redis, etc.) and study their transformer sections
> 3. Use `ketacli create dc-preview` first to get REAL sample data, then test transformers with `dc-preview-transformer`
> 4. **ANY task involving data transformation MUST call `ketacli show transformer` first to get correct syntax**

> **MANDATORY:** NEVER skip preview before creating config. NEVER skip data verification after distribution.

## Skill Boundaries

> **CRITICAL:** This skill covers Agent-based collection tasks ONLY via the standard workflow (dc-config → dc-dispatch).

**What THIS skill CAN do:**
- Create collection tasks using dc-config / dc-dispatch workflow
- Use templates from installed apps (mysql, nginx, jenkins, etc.)
- Preview, create, distribute, and verify data

**What THIS skill CANNOT do:**
- Webhook-based collection (e.g., Gitee Webhook, GitHub Webhook) — requires external system configuration
- Direct API polling that requires custom authentication or complex script logic outside template scope
- Collection methods not available in `ketacli list dc-types`
- KetaDB API or infrastructure-level configuration beyond collection tasks

**Decision rules:**
1. If target app exists in `ketacli list apps/market` → proceed with workflow
2. If template exists in `ketacli list dc-types` → proceed with workflow
3. If NEITHER exists → **INFORM USER that the collection type is not supported** and ask if they want to proceed with a different approach or cancel
4. **DO NOT** invent workarounds, fabricate templates, or attempt to use unsupported collection methods

**When to inform user:**
- Target system uses Webhook push instead of Agent pull
- Required template doesn't exist and no app provides it
- Task requires capabilities outside the defined workflow steps

## Key Concepts

**dc-config vs dc-dispatch — 两个不同的概念：**

| 概念 | 说明 | 命令 |
|------|------|------|
| **dc-config** | 采集配置 — 定义"采集什么"（目标地址、采集间隔、数据格式等） | `ketacli create dc-config` |
| **dc-dispatch** | 分发操作 — 定义"分发到哪里"（哪些Agent、分发策略等） | `ketacli create dc-dispatch` |

**工作流：** 先创建 dc-config（返回 configId），再用 configId 创建 dc-dispatch 进行分发。

## Step 0: Check App Market

```bash
# Search for apps related to your target
ketacli list apps/market --query mysql
ketacli list apps/market --query nginx
ketacli list apps/market --query postgres

# List all available apps
ketacli list apps/market -l 100

# If found, install the app (version auto-fetched)
ketacli update apps/market -o install -e "name=mysql"
```

Benefits of using app templates:
- Pre-configured transformers for parsing output
- Proper reader/sender configuration
- Multiple collection types (metrics, logs, slow queries, etc.)

## Step 1: List Collection Template Types

```bash
# List all collection template types (from installed apps)
ketacli list dc-types

# Filter by keyword
ketacli list dc-types --query <keyword>

# Get detailed template info
ketacli list dc-types -f json
```

Common template types:
| Type | Description |
|------|-------------|
| `tailx` | File tail collection (most common) |
| `dirx` | Multi-directory collection |
| `mysql_tel` | MySQL metrics (from mysql app) |
| `mysql_slow` | MySQL slow query logs |
| `mysql_log_gen` | MySQL general logs |
| `container_stdout` | Kubernetes container stdout |
| `container_dirx` | Container directory collection |
| `http_listener` | HTTP listener collection |
| `script` | Script-based collection |

## Step 2: Download Template File

```bash
# Download from base_collect app
ketacli download dc-template -e template_filename=tailx.yaml --base_path ./

# Download from a specific app (mysql, nginx, etc.)
ketacli download dc-template -e "app_name=mysql,template_filename=mysql_tel.yaml" --base_path ./

# Or download full app package and extract
ketacli download apps -e "name=mysql" --base_path /tmp
cd /tmp && tar -xzf mysql_*.tar.gz
ls mysql_*/static/
```

## Step 3: Preview Before Creating (MANDATORY)

> **CRITICAL:** Do NOT proceed to Step 4 without completing preview and confirming data can be collected.

### 3.1 Preview Collection Output (dc-preview)

Test reader on a specific agent before saving:

```bash
# Get agent ID first
ketacli list dc-agent -f json | grep -E '"id"|"hostName"'

# Preview with config file
ketacli create dc-preview -e "config=@/path/to/config.yaml,agent_id=<uuid>"
```

**Verify:** The preview output must show actual data being collected. If empty or error, fix the config before proceeding.

### 3.2 Preview Transformer (dc-preview-transformer) — IF template has transformers

> **MANDATORY when transformers exist:** If the template YAML contains a `transformers` section, you MUST preview transformer output to confirm data parses correctly.

> **IMPORTANT:** Always use ACTUAL sample data from `dc-preview`, NOT fabricated test data. Fabricated data may not match real log formats and cause false positives.

```bash
# 1. First run dc-preview to get actual reader output
ketacli create dc-preview -e "config=@/path/to/config.yaml,agent_id=<uuid>"
# Copy the "data" array from the output

# 2. Create content file with REAL reader output (JSON array of strings)
echo '["{\"raw\":\"2025-10-13 14:03:58 startup archives install\",\"host\":\"test\"}"]' > /tmp/content.json
# Use actual data from step 1, not this fabricated example

# 3. Preview transformer results
ketacli create dc-preview-transformer \
  -e "config=@/path/to/config.yaml,agent_id=<uuid>,content=@/tmp/content.json"
```

**How to check if template has transformers:**
1. Read the downloaded YAML template file
2. Look for `transformers:` key in the config
3. If present → MUST run dc-preview-transformer
4. If absent → skip this step

**Verify:** Transformer output must show correctly parsed/transformed fields. If parsing fails, fix the transformer config before proceeding.

### Complete Preview Workflow

```bash
# 1. Preview reader output (ALWAYS)
ketacli create dc-preview -e "config=@config.yaml,agent_id=<uuid>"

# 2. If template has transformers, preview transformer output (MANDATORY)
#    Use dc-preview output as the content input
ketacli create dc-preview-transformer \
  -e "config=@config.yaml,agent_id=<uuid>,content=@/tmp/reader_output.json"

# 3. Only if both previews look good → proceed to create config
ketacli create dc-config -n <task-name> -e "config=@config.yaml"
```

### Preview Timeout Handling

> **Note:** Preview may timeout for slow-responding targets (e.g., Jenkins with many jobs). This does NOT mean collection will fail. The actual collector has its own timeout and retry mechanisms. If the target API responds correctly (HTTP 200), you can proceed to create the config even if preview times out.

## Step 4: Create Collection Config

```bash
# Create from template file
ketacli create dc-config -n <task-name> -e "config=@<template-file-path>"

# With additional parameters
ketacli create dc-config -n <task-name> \
  -e "config=@<template-file-path>,description=My collector,sync_frequency=5m"

# For script-based templates, provide required variables
ketacli create dc-config -n mysql_collector \
  -e "config=@mysql_tel.yaml,Server=127.0.0.1:3306"
```

## Step 5: Create Repository and Sourcetype

> **Check first:** Repo and sourcetype may already exist (especially from app installation). Check before creating:
> ```bash
> ketacli list repo --query <repo_name>
> ketacli list sourcetype --query <sourcetype_name>
> ```

```bash
# Create METRICS repository for metrics collection
ketacli create repo -n <repo_name> --data '{"type":"METRICS","retention":"2592000000"}'

# Create EVENTS repository for logs
ketacli create repo -n <repo_name> --data '{"type":"EVENTS","retention":"604800000"}'

# Create sourcetype
ketacli create sourcetype -n <name> --data '{"extractors":[]}'
```

> **Note:** `retention` is in milliseconds. `2592000000` = 30 days, `604800000` = 7 days.

## Step 6: Distribute to Agents

### 6.1 Basic Distribution (All Agents in Tag)

```bash
# List available agent tags
ketacli list dc-tags

# Create task distribution — distributes to ALL agents in the tag
ketacli create dc-dispatch -e "config_id=<config-id>,tag_id=<tag-id>"

# Example: distribute to systemd-root (tag_id=7)
ketacli create dc-dispatch -e "config_id=45,tag_id=7"
```

### 6.2 Controlled Distribution (Specific Agent Count)

> **Use case:** Only distribute to N agents instead of all agents in the tag.

```bash
# Distribute to exactly 1 agent (auto-selected from tag)
ketacli create dc-dispatch -e "config_id=49,tag_id=6,assign_type=schedule,schedule=true,schedule_option_size=1,agentIds=[]"

# Distribute to exactly 3 agents
ketacli create dc-dispatch -e "config_id=49,tag_id=6,assign_type=schedule,schedule=true,schedule_option_size=3,agentIds=[]"
```

### 6.3 Distribution Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `config_id` | string | required | Config ID to distribute |
| `tag_id` | string | required | Agent tag ID to distribute to |
| `assign_type` | string | `all` | Distribution strategy: `all` (all agents), `schedule` (controlled count), `agent` (specific agents) |
| `schedule` | bool | `false` | Enable schedule mode |
| `schedule_option_size` | int | `0` | Number of agents to distribute to (when assign_type=schedule) |
| `agentIds` | array | `[]` | Specific agent IDs (when assign_type=agent) |
| `full_assign` | bool | `false` | Full assignment mode |

### 6.4 Important Notes on Re-distribution

> **Old tasks persist:** Creating a new dc-dispatch does NOT automatically stop old distribution tasks. Old agents will continue collecting until their tasks are removed or the agent restarts.

> **Verify distribution scope:** After creating a dc-dispatch, verify the config's distribution settings:
> ```bash
> ketacli get dc-config <config-id> -f json | python3 -c "
> import sys, json
> d = json.load(sys.stdin)
> c = d['configs'][0]
> print(f'assignType: {c.get(\"assignType\")}')
> print(f'scheduleOption: {c.get(\"scheduleOption\")}')
> "
> ```

## Step 7: Verify Data in Repository (MANDATORY)

> **CRITICAL:** Do NOT report task completion without verifying data exists in the target repository.

```bash
# Query the target repository to confirm data is being written
ketacli search 'search2 repo="<repo_name>" | limit 5' --format json

# For metrics repos, verify key fields exist
ketacli search 'search2 repo="<repo_name>" | limit 1' --format json

# Check how many agents are actually sending data
ketacli search 'search2 repo="<repo_name>" | stats count() as cnt by host' --format json
```

**Verification checklist:**
- [ ] Query returns data (not empty)
- [ ] `server` / target address matches the configured target
- [ ] `repo` field matches the expected repository name
- [ ] `sourcetype` field matches the expected sourcetype
- [ ] `_time` shows recent timestamps (data is being collected now, not stale)
- [ ] Key metrics/fields are populated (not all zeros or nulls unless expected)
- [ ] Number of hosts matches expected distribution count

**If no data found:**
1. Wait 30-60 seconds and retry (collection interval may not have fired yet)
2. Check agent status: `ketacli list dc-agent`
3. Check config status: `ketacli get dc-config <config-id> -f json`
4. Report the issue to the user — do NOT silently skip verification

## Step 8: Debugging Collection Issues

**If collection fails or no data appears:**

### Empty Search Troubleshooting Order:

1. **Check dispatch distribution** — verify the config was distributed to agents:
   ```bash
   ketacli get dc-config <config-id> -f json
   # Look for: assignType, tag, agentIds fields
   ```

2. **Verify reader and transformer with previews** — confirm both work:
   ```bash
   # Test reader output
   ketacli create dc-preview -e "config=@config.yaml,agent_id=<uuid>"
   # Test transformer (if any)
   ketacli create dc-preview-transformer -e "config=@config.yaml,agent_id=<uuid>,content=@/tmp/content.json"
   ```

3. **Check Keta Agent logs in logs_keta** — search errors on the target agent:
   ```bash
   ketacli search 'search2 repo="logs_keta" host="<agent_hostname>" AND level in ("ERROR", "WARN") | limit 50'
   # Example: host="systemd-ubuntu-d29h8"
   ```

### Common Agent Error Patterns:
- `transformer of type xxx not exist` → Invalid transformer type (e.g., `label` doesn't exist, use `rex`)
- `eval expr failed with err: illegal argument type` → Field is null or wrong type, use `when` conditions
- `add runner failed` → Config failed to load, check transformer syntax

### Debugging Tips:
- **Verify reader works before adding transformers** — first test with NO transformers to confirm raw data collection
- **Add transformers one at a time** — test with `dc-preview-transformer` after each addition
- **Use actual sample data** — run `ketacli create dc-preview` to get REAL reader output, not fabricated test data

## Step 9: Update Existing Collection Config

> Use when the user asks to modify an existing task (e.g., change interval, update target address, change repo).

### 8.1 Get Current Config ID and Details

```bash
# Find the config by name
ketacli list dc-config --query <task-name>

# Get full config details (note the id)
ketacli get dc-config <config-id>
```

### 8.2 Modify Template and Apply

```bash
# 1. Edit the local YAML template file (change interval, servers, repo, etc.)

# 2. Update the config using the template file
ketacli update dc-config -n <task-name> -o update -e "id=<config-id>,config=@<template-file-path>"
```

### 8.3 Verify Update

```bash
# Confirm the config was updated
ketacli get dc-config <config-id> | grep <changed-field>

# Example: verify interval changed to 1m
ketacli get dc-config <config-id> | grep "interval: 1m"
```

### Common Update Scenarios

| Scenario | Template Change |
|----------|----------------|
| Change collection interval | `interval: 30s` → `interval: 1m` |
| Update target server | `servers: ["tcp://old:6379"]` → `servers: ["tcp://new:6379"]` |
| Change target repo | `repo: old_repo` → `repo: new_repo` |
| Add password | Uncomment and set `password: "xxx"` |

## Template Configuration

### Transformer Syntax (CRITICAL)

Transformers use SPL operators. **There is NO `label` transformer type.**

**Valid operators:**
| Operator | Example |
|----------|---------|
| `rex` | `rex field="raw" "(?P<time>\d+-\d+-\d+)"` |
| `eval` | `eval timestamp=strptime(time, "2006-01-02T15:04:05")` |
| `fields` | `fields -raw, -time` (remove) or `fields time, level` (keep) |
| `json` | `json field=_raw` |
| `rename` | `rename old_name as new_name` |
| `where` | `where status = 200` |

**Common mistakes to avoid:**
- `label` type does NOT exist → use `rex` or `eval`
- `strptime` requires string argument, not null → check `when isnull(field)` before using
- Regex groups must use `(?P<name>...)` syntax for named capture

**Study existing templates for correct syntax:**
```bash
# Download mysql log template to see correct transformer format
ketacli download dc-template -e "app_name=mysql,template_filename=mysql_log_gen.yaml" --base_path ./

# Download redis log template
ketacli download dc-template -e "app_name=redis,template_filename=redis_log.yaml" --base_path ./
```

### Modify Template Fields

Edit the downloaded YAML template:

```yaml
readers:
  - <reader_type>:
      interval: 30s
      path: /var/log/*.log
      # ... other reader-specific fields

senders:
  - keta:
      repo: <target_repo>
      sourcetype: <target_sourcetype>
      token: "${keta_token}"
```

### Common Reader Types

| Reader | Key Fields | Use Case |
|--------|------------|----------|
| `tailx` | `path`, `interval` | Log files |
| `dirx` | `path`, `interval` | Directory monitoring |
| `mysql_tel` | `servers`, `interval` | MySQL metrics |
| `script` | `script_content`, `interpreter` | Custom scripts |
| `http_listener` | `port` | HTTP API collection |

## Quick Reference

```bash
# Complete workflow with verification
ketacli list apps/market --query mysql              # Search
ketacli update apps/market -o install -e "name=mysql"  # Install
ketacli list dc-types -f json | grep mysql           # Find template
ketacli download dc-template -e "app_name=mysql,template_filename=mysql_tel.yaml" --base_path ./  # Download
ketacli create dc-preview -e "config=@mysql_tel.yaml,agent_id=<uuid>"  # Preview (MANDATORY)
ketacli create dc-config -n mysql_collector -e "config=@mysql_tel.yaml,Server=127.0.0.1:3306"  # Create
ketacli create dc-dispatch -e "config_id=<id>,tag_id=7"   # Distribute
ketacli search 'search2 repo="mysql_tel" | limit 5' --format json  # Verify data (MANDATORY)

# Controlled distribution (N agents only)
ketacli create dc-dispatch -e "config_id=<id>,tag_id=6,assign_type=schedule,schedule=true,schedule_option_size=1,agentIds=[]"

# Update existing config
ketacli update dc-config -n mysql_collector -o update -e "id=<config-id>,config=@mysql_tel.yaml"  # Update

# Verify distribution scope
ketacli get dc-config <config-id> -f json
```

## Common Pitfalls

### 1. Choose Correct read_from for Preview

**Problem:** Setting `read_from: newest` results in empty preview if no new logs are generated during the preview window.

**Experience:** Default to `oldest` unless user explicitly requests otherwise. Always confirm data collection works with `oldest` first, then adjust if needed.

### 2. Be Careful with Transformer Regex

**Problem:** Adding complex regex without proper escaping causes agent to fail loading config.

**Error:** `error parsing regexp: unexpected )` — unescaped parentheses

**Experience:**
- Test regex locally before adding to config
- Use `dc-preview-transformer` to verify each transformer step
- Add complex regex incrementally, testing at each step

### 3. Handle null Values for strptime Carefully

**Problem:** `when isnull(timestamp)` condition does not prevent strptime from receiving null, causing warnings.

**Cause:** When rex doesn't match, the timestamp field doesn't exist (not null).

**Experience:**
- Don't over-rely on `when` conditions
- Simplify transformer chains, keep only essential transformations
- Consider using `fields -raw` early to remove raw field, avoiding null handling downstream

### 4. Always Verify After Dispatch

**Problem:** No new data after updating config, assuming dispatch failed.

**Experience:**
- `schedule: false` + `assignType: all` requires manual dispatch
- Check `logs_keta` after dispatch to confirm config sync
- Verify `_time` in target repo is recent (new data, not stale)

### 5. Use Logs to Troubleshoot

**Command:**
```bash
ketacli search 'search2 repo="logs_keta" host="<agent>" AND level in ("ERROR", "WARN") | limit 50'
```

**Experience:** Agent-side issues are recorded in `logs_keta`. Focus on entries with `mode: reader/transformer/sender`.

### 6. SPL Syntax Notes

**Correct:** `search2 start="-1h" repo="var_log" | limit 5`

**Note:** Field names use single quotes, values use double quotes.

### Recommended Workflow

```
1. Create/download template
2. Preview with dc-preview (use oldest)
3. Test transformer with dc-preview-transformer
4. Create/update config
5. Dispatch to agent tag
6. Wait ~3 minutes for collection cycle
7. Verify: search2 repo="<repo_name>" | limit 5
8. If issues: search2 repo="logs_keta" ... to investigate
```
