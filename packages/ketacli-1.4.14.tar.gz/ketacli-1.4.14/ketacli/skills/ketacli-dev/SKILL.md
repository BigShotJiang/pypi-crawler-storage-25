---
name: ketacli-dev
version: 1.0.0
description: |
  KetaDB CLI (ketacli) Development Workflow — code, test, commit, PR, and release.
  Use when working on ketacli development tasks.
allowed-tools:
  - Bash
  - Read
  - Edit
  - Write
---

# ketacli Development Workflow

KetaDB CLI development guide for code, test, commit, PR, and release.

## Project Structure

```
ketacli/
├── ketacli/                 # Main source code
│   ├── plugins/            # CLI commands (asset.py, mock.py, search.py, etc.)
│   ├── sdk/                 # SDK modules
│   └── ...
├── pyproject.toml          # Version and dependencies
├── setup.py                # Version (must sync with pyproject.toml)
├── publish.sh              # Release script
└── venv/                   # Virtual environment
```

## Version Management

Version must be synchronized in two files:
- `pyproject.toml`: `version = "x.x.x"`
- `setup.py`: `version='x.x.x'`

## Development Workflow

### 1. Create Feature Branch

```bash
cd /data/git-project/ketacli

# Switch to develop branch
git checkout master

# Create feature branch
git checkout -b feature/your-feature-name
```

### 2. Make Changes

Edit source files in `ketacli/` directory.

### 3. Test Changes

```bash
# Activate virtual environment
source venv/bin/activate

# Run tests
./run_tests.sh

# Test specific command
ketacli search 'search2 repo="default" | limit 10'
```

### 4. Commit Changes

```bash
# Stage changes
git add <files>

# Commit with descriptive message
git commit -m "fix: describe the fix

- Detail 1
- Detail 2"
```

### 5. Push to Fork

```bash
# Push to ketabot fork
git push ketabot feature/your-feature-name
```

### 6. Create PR

**Via Gitee Web UI:**
1. Visit: `https://gitee.com/ketabot/ketacli/pull/new/ketabot:feature/your-feature-name...ketabot:master`
2. Fill PR title and description
3. Submit PR

**Target:** `ketabot/ketacli:feature/xxx` → `xishuhq/ketacli:master`

## Release Workflow

### 1. Update Version

```bash
# Edit pyproject.toml
# Edit setup.py
```

### 2. Run Tests

```bash
source venv/bin/activate
./run_tests.sh
```

### 3. Publish to PyPI

```bash
# Use venv python for pip
PY=/data/git-project/ketacli/venv/bin/python ./publish.sh

# Or for testpypi first
PY=/data/git-project/ketacli/venv/bin/python ./publish.sh testpypi
```

### 4. Create Release Commit

```bash
git add -A
git commit -m "chore: bump version to x.x.x"
git push ketabot master
```

### 5. Create Git Tag (Optional)

```bash
git tag vx.x.x
git push ketabot vx.x.x
```

## Git Remotes

| Remote | URL | Purpose |
|--------|-----|---------|
| `origin` | git@gitee.com:xishuhq/ketacli.git | Original repo |
| `ketabot` | git@gitee.com:ketabot/ketacli.git | Fork for PRs |
| `guojongg` | git@gitee.com:guojongg/ketacli.git | Personal fork |

## Common Commands

```bash
# Install locally for development
PY=/data/git-project/ketacli/venv/bin/python
$PY -m pip install -e .

# Build distribution
PY=/data/git-project/ketacli/venv/bin/python
$PY -m build

# Check package info
ketacli version

# Check config
ketacli config list-clusters
```

## Code Style

- Python 3.10+
- Follow PEP 8
- Use type hints where appropriate
- Write tests for new features

## Notes

- Use `ketabot` fork for all PRs
- Target branch: `master`
- Always test before committing
- Sync versions before release
