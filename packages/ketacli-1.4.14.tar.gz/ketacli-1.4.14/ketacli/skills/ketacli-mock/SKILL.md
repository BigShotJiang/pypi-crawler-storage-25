---
name: ketacli-mock
version: 1.0.0
description: |
  KetaDB Mock Data Tool — generate test data and create test repositories.
  Supports mock_data for generic data, mock_log for various log types (nginx, java, linux),
  mock_metrics for metrics data, and insert for custom data uploads.
  Use when asked to "mock data", "generate test data", "create test repo", or "seed data".
allowed-tools:
  - Bash
  - Read
---

# ketacli-mock

KetaDB mock data generation tool for testing and development.

## Authentication

```bash
# Login to KetaDB (if not already authenticated)
ketacli login -n <username> -e <endpoint> -t <token>

# Verify connection
ketacli config list-clusters
```

## Create Test Repository

Before generating mock data, you may need to create a repository:

```bash
# Create an EVENTS repository (for logs)
ketacli create repo -n <test_repo_name> --data '{"type":"EVENTS","retention":"604800000"}'

# Create a METRICS repository
ketacli create repo -n <test_metrics_repo> --data '{"type":"METRICS","retention":"604800000"}'
```

**Note:** `retention` is in milliseconds (e.g., `604800000` = 7 days).

## Mock Generic Data

### Basic Usage

```bash
# Generate 100 records with default template
ketacli mock_data --repo <repo_name> -n 100

# Generate with rendering (template variables)
ketacli mock_data --repo <repo_name> -n 100 --render

# Output to file instead of server
ketacli mock_data --repo <repo_name> -n 100 --output_type file --output_file /path/to/output.json
```

### Custom Data Template

```bash
# Use custom template with Faker variables
ketacli mock_data --repo <repo_name> --data '{
  "raw": "{{ faker.sentence() }}",
  "host": "{{ faker.ipv4_private() }}",
  "user": "{{ faker.user_name() }}",
  "timestamp": "{{ faker.unix_time() }}"
}' -n 100 --render

# More complex template
ketacli mock_data --repo <repo_name> --data '{
  "message": "{{ faker.text(max_nb_chars=200) }}",
  "level": "{{ random.choice([\"INFO\", \"WARN\", \"ERROR\"]) }}",
  "service": "{{ random.choice([\"api\", \"web\", \"worker\"]) }}",
  "trace_id": "{{ faker.uuid4() }}"
}' -n 1000 --render
```

### Performance Options

```bash
# With gzip compression
ketacli mock_data --repo <repo_name> -n 1000 --gzip

# Batch processing
ketacli mock_data --repo <repo_name> -n 10000 --batch 1000

# Multiple workers
ketacli mock_data --repo <repo_name> -n 10000 --workers 4
```

## Mock Log Data

### Log Types

```bash
# Nginx access logs
ketacli mock_log --repo <repo_name> --log_type nginx -n 100

# Java application logs
ketacli mock_log --repo <repo_name> --log_type java -n 100

# Linux system logs
ketacli mock_log --repo <repo_name> --log_type linux -n 100

# Default (nginx)
ketacli mock_log --repo <repo_name> -n 100
```

### Log Type Details

| Type | Description | Example Fields |
|------|-------------|----------------|
| `nginx` | Web server access logs | ip, method, path, status, response_time |
| `java` | Java application logs | timestamp, level, logger, message, thread |
| `linux` | System logs | timestamp, hostname, service, message |

### Custom Log Template

```bash
ketacli mock_log --repo <repo_name> --data '{
  "raw": "{{ faker sentence() }}",
  "host": "{{ faker.ipv4_private() }}",
  "level": "{{ random.choice([\"DEBUG\", \"INFO\", \"WARN\", \"ERROR\"]) }}"
}' --log_type nginx -n 500 --render
```

## Mock Metrics Data

```bash
# Generate metrics with default template
ketacli mock_metrics --repo <metrics_repo> -n 100

# Output to file
ketacli mock_metrics --repo <metrics_repo> -n 100 --output_type file --output_file /tmp/metrics.json

# With custom data
ketacli mock_metrics --repo <metrics_repo> --data '{
  "host": "{{ faker.ipv4_private() }}",
  "region": "{{ random.choice([\"us-west-2\", \"ap-shanghai\", \"ap-nanjing\"]) }}",
  "service": "{{ random.choice([\"api\", \"web\", \"db\"]) }}",
  "fields": {
    "cpu_usage": "{{ random.randint(0, 100) }}",
    "memory_usage": "{{ random.randint(0, 100) }}",
    "disk_usage": "{{ random.randint(0, 100) }}"
  }
}' -n 100 --render
```

## Insert Custom Data

### Insert Single Record

```bash
# Insert with JSON string
ketacli insert --repo <repo_name> --data '[{"raw":"test log message","host":"host-1"}]'
```

### Insert from File

```bash
# Insert data from file
ketacli insert --repo <repo_name> --file /path/to/data.json

# With gzip compression
ketacli insert --repo <repo_name> --file /path/to/data.json.gz --gzip
```

## Common Parameters

| Parameter | Description | Example |
|-----------|-------------|---------|
| `--repo` | Target repository | `my_repo` |
| `-n`, `--number` | Number of records | `100` (use `-1` for continuous) |
| `--data` | Data template | JSON with Faker variables |
| `--file` | Data file path | `/path/to/data.json` |
| `--render` | Enable template rendering | Use Faker variables |
| `--gzip` | Enable gzip compression | Reduce network usage |
| `--batch` | Batch size | `1000` |
| `--workers` | Number of workers | `4` |
| `--output_type` | Output destination | `server`, `file`, `stdout` |
| `--output_file` | Output file path | `/path/to/output.json` |
| `--log_type` | Log type for mock_log | `nginx`, `java`, `linux` |

## Faker Variables

Templates use [Python Faker](https://faker.readthedocs.io/) for data generation. Faker is a powerful library that generates fake data for testing and development.

### Common Faker Methods

| Variable | Description | Example Output |
|----------|-------------|----------------|
| `{{ faker.name() }}` | Full name | "John Doe" |
| `{{ faker.user_name() }}` | Username | "johndoe" |
| `{{ faker.email() }}` | Email | "john@example.com" |
| `{{ faker.phone_number() }}` | Phone number | "+1-555-123-4567" |
| `{{ faker.address() }}` | Full address | "123 Main St, City, State" |
| `{{ faker.city() }}` | City name | "New York" |
| `{{ faker.country() }}` | Country name | "United States" |
| `{{ faker.company() }}` | Company name | "Acme Corp" |
| `{{ faker.job() }}` | Job title | "Software Engineer" |
| `{{ faker.ipv4_private() }}` | Private IP | "192.168.1.1" |
| `{{ faker.ipv4_public() }}` | Public IP | "8.8.8.8" |
| `{{ faker.ipv6() }}` | IPv6 address | "2001:0db8::1" |
| `{{ faker.mac_address() }}` | MAC address | "00:11:22:33:44:55" |
| `{{ faker.uuid4() }}` | UUID | "550e8400-e29b-41d4-a716-446655440000" |
| `{{ faker.uri() }}` | URI/URL | "https://example.com/page" |
| `{{ faker.uri_path() }}` | URI path | "/users/123/profile" |
| `{{ faker.user_agent() }}` | User agent | "Mozilla/5.0..." |
| `{{ faker.sentence() }}` | Sentence | "Lorem ipsum dolor sit amet." |
| `{{ faker.text() }}` | Multi-paragraph text | Long text content |
| `{{ faker.word() }}` | Single word | "lorem" |
| `{{ faker.paragraph() }}` | Paragraph | "Lorem ipsum..." |
| `{{ faker.catch_phrase() }}` | Catch phrase | "Multi-layered client-server" |
| `{{ faker.color_name() }}` | Color name | "Blue" |
| `{{ faker.currency() }}` | Currency code | "USD" |
| `{{ faker.currency_name() }}` | Currency name | "United States Dollar" |
| `{{ faker.credit_card_number() }}` | Credit card | "4532015112830366" |
| `{{ faker.date() }}` | Date | "2024-01-15" |
| `{{ faker.date_time() }}` | DateTime | "2024-01-15 10:30:00" |
| `{{ faker.unix_time() }}` | Unix timestamp | 1704067200 |
| `{{ faker.iso8601() }}` | ISO 8601 datetime | "2024-01-15T10:30:00Z" |
| `{{ faker.timezone() }}` | Timezone | "America/New_York" |
| `{{ faker.sha1() }}` | SHA1 hash | "a94a8fe5ccb19ba6..." |
| `{{ faker.md5() }}` | MD5 hash | "d41d8cd98f00b204..." |
| `{{ faker.locale() }}` | Locale code | "en_US" |
| `{{ faker.language_code() }}` | Language code | "en" |
| `{{ faker.file_name() }}` | File name | "document.pdf" |
| `{{ faker.file_extension() }}` | File extension | "pdf" |
| `{{ faker.file_path() }}` | File path | "/home/user/docs/report.pdf" |
| `{{ faker.mime_type() }}` | MIME type | "application/pdf" |

### Random Functions

| Variable | Description | Example |
|----------|-------------|---------|
| `{{ random.choice(list) }}` | Random item from list | `{{ random.choice(["INFO","WARN","ERROR"]) }}` |
| `{{ random.randint(a, b) }}` | Random integer | `{{ random.randint(1, 100) }}` |
| `{{ random.random() }}` | Random float 0-1 | `{{ random.random() }}` |
| `{{ random.uniform(a, b) }}` | Random float range | `{{ random.uniform(0.5, 1.5) }}` |
| `{{ random.sample(list, n) }}` | Random sample | `{{ random.sample(items, 3) }}` |
| `{{ random.shuffle(list) }}` | Shuffle list | `{{ random.shuffle(items) }}` |

### Python Built-in Functions

| Variable | Description | Example |
|----------|-------------|---------|
| `{{ time.time() }}` | Current Unix timestamp | `{{ int(time.time() * 1000) }}` |
| `{{ time.strftime(format) }}` | Formatted time | `{{ time.strftime("%Y-%m-%d %H:%M:%S") }}` |
| `{{ len(string) }}` | String length | `{{ len(text) }}` |
| `{{ str(value) }}` | Convert to string | `{{ str(number) }}` |
| `{{ int(value) }}` | Convert to int | `{{ int(float_val) }}` |

### Faker Providers

Faker organizes methods by "providers". Common providers:

| Provider | Methods |
|----------|---------|
| `faker.name` | name(), first_name(), last_name(), prefix(), suffix() |
| `faker.address` | address(), street_address(), city(), country(), zipcode() |
| `faker.company` | company(), bs(), catch_phrase() |
| `faker.internet` | email(), ipv4(), ipv6(), url(), user_agent(), mac_address() |
| `faker.text` | sentence(), paragraph(), text(), word() |
| `faker.date_time` | date(), date_time(), unix_time(), iso8601() |
| `faker.lorem` | sentence(), paragraph(), text() |
| `faker.misc` | uuid4(), binary(), boolean() |
| `faker.file` | file_name(), file_extension(), file_path(), mime_type() |
| `faker.currency` | currency(), currency_name() |
| `faker.credit_card` | credit_card_number(), credit_card_provider() |

### Examples

```bash
# Generate realistic log entry
ketacli mock_data --repo logs --data '{
  "timestamp": "{{ time.strftime("%Y-%m-%d %H:%M:%S") }}",
  "level": "{{ random.choice(["DEBUG", "INFO", "WARN", "ERROR"]) }}",
  "host": "{{ faker.ipv4_private() }}",
  "service": "{{ faker.bs() }}",
  "message": "{{ faker.sentence() }}",
  "request_id": "{{ faker.uuid4() }}",
  "user": "{{ faker.user_name() }}"
}' -n 1000 --render

# Generate API access log
ketacli mock_log --repo api_logs --data '{
  "ip": "{{ faker.ipv4_public() }}",
  "method": "{{ random.choice(["GET", "POST", "PUT", "DELETE"]) }}",
  "path": "/api/{{ faker.uri_path() }}",
  "status": "{{ random.choice([200, 200, 200, 400, 500]) }}",
  "response_time_ms": "{{ random.randint(10, 5000) }}",
  "user_agent": "{{ faker.user_agent() }}"
}' --log_type nginx -n 5000 --render

# Generate metrics data
ketacli mock_metrics --repo metrics --data '{
  "host": "{{ faker.ipv4_private() }}",
  "service": "{{ faker.bs() }}",
  "region": "{{ random.choice(["us-west-2", "us-east-1", "eu-west-1"]) }}",
  "timestamp": {{ int(time.time() * 1000) }},
  "fields": {
    "cpu_percent": {{ random.randint(0, 100) }},
    "memory_percent": {{ random.randint(0, 100) }},
    "disk_percent": {{ random.randint(0, 100) }},
    "network_in_mb": {{ random.uniform(0, 1000) }},
    "network_out_mb": {{ random.uniform(0, 1000) }}
  }
}' -n 1000 --render
```

### Full Documentation

For complete Faker documentation, visit: https://faker.readthedocs.io/

## Workflow Examples

### Quick Test Setup

```bash
# 1. Create test repository
ketacli create repo -n test_logs --data '{"type":"EVENTS","retention":"604800000"}'

# 2. Generate mock data
ketacli mock_data --repo test_logs -n 1000

# 3. Verify data
ketacli search 'search2 repo="test_logs" | limit 10'
```

### Full Test Environment

```bash
# 1. Create repositories
ketacli create repo -n test_logs --data '{"type":"EVENTS","retention":"604800000"}'
ketacli create repo -n test_metrics --data '{"type":"METRICS","retention":"604800000"}'

# 2. Generate data
ketacli mock_log --repo test_logs --log_type nginx -n 5000
ketacli mock_metrics --repo test_metrics -n 1000

# 3. Generate errors for testing
ketacli mock_log --repo test_logs --data '{
  "raw": "ERROR: Connection timeout",
  "host": "{{ faker.ipv4_private() }}",
  "level": "ERROR"
}' -n 100 --render

# 4. Verify
ketacli search 'search2 repo="test_logs" level="ERROR" | limit 10'
```

### Benchmark Test Data

```bash
# Create large dataset for performance testing
ketacli create repo -n perf_test --data '{"type":"EVENTS","retention":"604800000"}'
ketacli mock_data --repo perf_test -n 100000 --batch 5000 --workers 4

# Verify count
ketacli search 'search2 repo="perf_test" | stats count()'
```

## Notes

- **Use `--render` flag** to enable Faker template variables
- **For large datasets**, use `--batch` and `--workers` for better performance
- **Enable gzip** with `--gzip` for faster data transfer
- **Use `--output_type file`** to preview data before uploading (may have issues with progress display)
- **Delete test repositories** after testing to save storage: `ketacli delete repo -n <repo_name>`
