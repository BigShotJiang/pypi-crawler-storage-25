---
name: ketacli-manage
version: 1.4.0
description: |
  KetaDB Resource Management Tool — manage repositories, sourcetypes, metrics,
  and other assets in KetaDB. Supports CRUD operations: list, get, create,
  update, delete, and describe.
  Also supports app market: browse (apps/market), install apps to get more collection templates.
  Use when asked to "manage repos", "create repo", "delete asset", "list resources",
  "describe schema", or "install app".

  ⚠️ For collection task creation (dc-config/dc-dispatch) with full workflow
  (preview → create → distribute → verify), use ketacli-dc-task instead.
  This skill only covers basic CRUD operations, NOT the complete workflow.
allowed-tools:
  - Bash
  - Read
---

# ketacli-manage

KetaDB resource management tool for CRUD operations on repositories and other assets.

## Authentication

```bash
# Login to KetaDB
ketacli login -n <username> -e <endpoint> -t <token>

# Check current configuration
ketacli config list-clusters

# View resource info
ketacli rs -t <resource_type>
```

## List Resources

### List Repositories

```bash
# List all repositories
ketacli list repo

# Fuzzy search by keyword
ketacli list repo --query <keyword>

# Pagination
ketacli list repo --pageNo 1 -l 20

# Specify output fields
ketacli list repo --fields "id,name,type,status"

# JSON format
ketacli list repo -f json

# Watch mode (real-time monitoring)
ketacli list repo -w --interval 10
```

### List Other Asset Types

```bash
# List sourcetypes
ketacli list sourcetype

# List metrics
ketacli list metric

# List alert targets
ketacli list targets

# List all asset types
ketacli admin repo
```

### Watch Mode

```bash
# Monitor resource changes in real-time
ketacli list repo -w --interval 10
```

## Get Resource Details

```bash
# Get repository details
ketacli get repo <repo_name_or_id>

# Get sourcetype details
ketacli get sourcetype <name>

# Get metric details
ketacli get metric <name>

# JSON format
ketacli get repo <name> -f json

# Specify fields
ketacli get repo <name> --fields "id,name,type,retention"
```

## Describe Schema

```bash
# View repository schema/field definitions
ketacli describe repo <repo_name>

# View sourcetype schema
ketacli describe sourcetype <name>

# JSON format
ketacli describe repo <name> -f json
```

## Create Resources

### Create Repository

```bash
# Create EVENTS repository (logs)
ketacli create repo -n <repo_name> --data '{"type":"EVENTS","retention":"604800000"}'

# Create METRICS repository
ketacli create repo -n <repo_name> --data '{"type":"METRICS","retention":"604800000"}'

# Create TRACES repository
ketacli create repo -n <repo_name> --data '{"type":"TRACES","retention":"604800000"}'

# Create from file
ketacli create repo -n <repo_name> --file /path/to/config.json

# Create with extra arguments
ketacli create repo -n <repo_name> --data '{"type":"EVENTS"}' -e "key=value"
```

**Note:** `retention` is in milliseconds. Common values:
- `604800000` = 7 days
- `2592000000` = 30 days
- `7776000000` = 90 days

### Create Other Asset Types

```bash
# Create sourcetype
ketacli create sourcetype -n <name> --data '{"extractors":[]}'

# Create metric
ketacli create metric -n <name> --data '{"query":"search2 repo=\"repo_name\" | stats count()"}'

# Create with file
ketacli create <asset_type> -n <name> --file /path/to/config.json
```

## Update Resources

```bash
# Update repository configuration
ketacli update repo -n <repo_name> -d '{"retention":"60d"}'

# Update with data file
ketacli update repo -n <repo_name> --file /path/to/update.json

# Operations
ketacli update repo -n <repo_name> -o open   # Open repository
ketacli update repo -n <repo_name> -o close  # Close repository

# Update with extra arguments
ketacli update repo -n <repo_name> -d '{}' -e "key=value"
```

## Delete Resources

```bash
# Delete repository
ketacli delete repo -n <repo_name>

# Delete sourcetype
ketacli delete sourcetype -n <name>

# Delete metric
ketacli delete metric -n <name>

# Delete with extra arguments
ketacli delete repo -n <repo_name> -e "id=12345"
```

## Download Resources

```bash
# Export repository data
ketacli download repo --base_path /path/to/save

# Export sourcetype
ketacli download sourcetype --base_path /path/to/save
```

## Common Parameters

| Parameter | Description | Example |
|-----------|-------------|---------|
| `-n`, `--name` | Resource name | `my_repo` |
| `--data` | JSON data string | `'{"key":"value"}'` |
| `--file` | File path | `/path/to/file.json` |
| `-f`, `--format` | Output format | `text`, `json`, `csv` |
| `--fields` | Output fields | `"id,name,type"` |
| `-e`, `--extra` | Extra arguments | `key=value,key2=value2` |
| `-w`, `--watch` | Watch mode | Real-time monitoring |
| `--interval` | Refresh interval (seconds) | `10` |
| `-l`, `--limit` | Page size | `20` |
| `--pageNo` | Page number | `1` |

## Output Formats

| Format | Flag | Use Case |
|--------|------|----------|
| `text` | `-f text` | Human readable (default) |
| `json` | `-f json` | Programmatic processing |
| `csv` | `-f csv` | Spreadsheet analysis |
| `html` | `-f html` | Report generation |
| `latex` | `-f latex` | LaTeX documents |

## Asset Types

| Type | Description | Main Fields |
|------|-------------|-------------|
| `repo` | Repository | name, type, retention, status |
| `sourcetype` | Data source type | name, extractors |
| `metric` | Metric definition | name, query |
| `targets` | Alert targets | name, type, config |
| `dc-config` | 采集任务配置 | name, config, enabled, app |
| `dc-dispatch` | 采集任务分发 | configIds, tagIds, enabled |
| `dc-agent` | Agent 实例 | hostName, ip, version, os |
| `dc-types` | 采集模板类型 | name, title, app, template |
| `dc-preview` | 采集任务预览 | agentIds, config, batchSize, timeout |
| `dc-preview-transformer` | Transformer 预览 | agentId, config, content |

## Collection Tasks (dc-config / dc-dispatch)

> ⚠️ **For the complete collection task workflow** (App → Install → Download → Preview → Create → Distribute → Verify), use the **ketacli-dc-task** skill instead. That skill enforces MANDATORY preview and verification steps that are critical for working collection tasks.

This section covers basic CRUD operations only.

```bash
# List collection configs
ketacli list dc-config --fields "id,name,type,enabled,app"

# List all agent instances
ketacli list dc-agent

# List agent tags
ketacli list dc-tags

# Get specific config details
ketacli get dc-config <config-id> -f json

# Create dc-config (basic)
ketacli create dc-config -n <task-name> -e "config=@<template-file-path>"

# Create dc-dispatch (basic)
ketacli create dc-dispatch -e "config_id=<config-id>,tag_id=<tag-id>"
```

## Debug Collection Tasks

> ⚠️ **For the complete debug workflow with MANDATORY preview and verification**, use the **ketacli-dc-task** skill.

Basic preview commands (for quick checks only):

```bash
# Preview collection output
ketacli create dc-preview -e "config=@/path/to/config.yaml,agent_id=<agent-uuid>"

# Preview transformer results
ketacli create dc-preview-transformer \
  -e "config=@/path/to/config.yaml,agent_id=<uuid>,content=@/tmp/content.json"
```

## App Market

### Browse Apps

```bash
# List all available apps in market
ketacli list apps/market -l 100

# Search apps by keyword
ketacli list apps/market --query mysql
ketacli list apps/market --query nginx
ketacli list apps/market --query postgres

# List installed apps
ketacli list apps
```

### Install/Uninstall Apps

```bash
# Install an app (version is auto-fetched if not specified)
ketacli update apps/market -o install -e "name=mysql"

# Install specific version
ketacli update apps/market -o install -e "name=mysql,version=1.0.5"

# Uninstall an app
ketacli update apps -o uninstall -e "name=mysql"

# Upgrade an app
ketacli update apps/market -o upgrade -e "name=mysql"
```

### Download App Templates

After installing an app, you can download its collection templates:

```bash
# List app contents (usually includes templates in static/ directory)
ketacli download apps -e "name=mysql" --base_path /tmp

# Then extract the tarball to find templates
cd /tmp && tar -xzf mysql_*.tar.gz
ls mysql_*/static/

# Or download specific template if app_name is supported
ketacli download dc-template -e "app_name=mysql,template_filename=mysql_tel.yaml" --base_path ./
```

## Notes

- **Delete operations are irreversible** — confirm before executing
- Use `--test` flag to validate without making changes
- Use `-w --interval 10` for real-time monitoring of resource changes
- For bulk operations, consider using files instead of inline JSON
- **Always check app market first** before manually creating collection configs
- App templates come with pre-configured transformers and proper reader/sender settings
