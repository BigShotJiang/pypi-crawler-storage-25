import argcomplete
from mando import main

# 导入所有插件模块
from ketacli.plugins import auth
from ketacli.plugins import asset
from ketacli.plugins import search
from ketacli.plugins import visualization
from ketacli.plugins import data
from ketacli.plugins import config
from ketacli.plugins import interactive
from ketacli.plugins import metric
from ketacli.plugins import docs

# 导入mock模块中的函数
from ketacli.plugins.mock import mock_data, mock_log, mock_metrics, generate_and_upload

# 导入测试模块
from ketacli.sdk.test.cli import test_command

# 导入AI模块
from ketacli.plugins.ai_search import *


def start():
    import argcomplete
    import json
    from rich.console import Console
    
    console = Console()
    argcomplete.autocomplete(main.parser)
    try:
        argcomplete.autocomplete(main.parser)
        main()
    except Exception as e:
        error_msg = str(e)
        
        if error_msg.startswith("('Bad request'") or error_msg.startswith("('Server error'"):
            try:
                parts = eval(error_msg)
                if len(parts) >= 5:
                    status_code = parts[1]
                    url = parts[2]
                    method = parts[3].upper()
                    response_text = parts[4]
                    
                    try:
                        resp = json.loads(response_text)
                        code = resp.get("Code", "")
                        message = resp.get("Message", "")
                        console.print(f"[red]Error {status_code}[/red]")
                        if code:
                            console.print(f"[red]{code}[/red]: {message}")
                        else:
                            console.print(f"[red]{message}[/red]")
                        return
                    except:
                        pass
            except:
                pass
        
        console.print(f"[red]Error:[/red] {error_msg}")


if __name__ == "__main__":
    start()
