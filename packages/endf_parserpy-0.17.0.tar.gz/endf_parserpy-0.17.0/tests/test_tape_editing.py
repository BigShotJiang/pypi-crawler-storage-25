import pickle
import pytest
from pathlib import Path

from endf_parserpy import EndfParserFactory, EndfFile
from endf_parserpy.tape import SectionRenderError, TapeStructureError
from endf_parserpy.tape.records import TEND_LINE


TESTDATA = Path(__file__).parent / "testdata"
CU = TESTDATA / "n_2925_29-Cu-63.endf"  # MAT 2925
ZN = TESTDATA / "n_3025_30-Zn-64.endf"  # MAT 3025
RAW_EXCLUDE = tuple(range(1, 100))


@pytest.fixture(params=["python", "cpp"])
def parser(request):
    try:
        return EndfParserFactory.create(select=request.param)
    except Exception:
        pytest.skip(f"{request.param} backend unavailable")


def _read_lines(path):
    with open(path) as fh:
        return [line.rstrip("\n") for line in fh]


def _canonical_tape(parser, paths):
    tpid = tend = None
    bodies = []
    for path in paths:
        single = parser.write(parser.parse(_read_lines(path), exclude=RAW_EXCLUDE))
        tpid, tend = single[0], single[-1]
        bodies.append(single[1:-1])
    return [tpid] + sum(bodies, []) + [tend]


def _open(tmp_path, parser, paths, name="tape.endf"):
    path = tmp_path / name
    path.write_bytes(
        ("\n".join(_canonical_tape(parser, paths)) + "\n").encode("latin-1")
    )
    return EndfFile(path, parser=parser), path


# --------------------------------------------------------------------------
# write-back without edits
# --------------------------------------------------------------------------


def test_unedited_export_is_byte_exact(tmp_path, parser):
    multi = _canonical_tape(parser, [CU, ZN])
    path = tmp_path / "tape.endf"
    path.write_bytes(("\n".join(multi) + "\n").encode("latin-1"))
    endf_file = EndfFile(path, parser=parser)
    assert endf_file.to_string().splitlines() == multi


def test_export_to_file(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU, ZN])
    out = tmp_path / "out.endf"
    endf_file.export(out)
    assert EndfFile(out, parser=parser).materials()
    with pytest.raises(FileExistsError):
        endf_file.export(out)
    endf_file.export(out, overwrite=True)


def test_export_cleans_up_temp_file_on_failure(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    target = tmp_path / "adir"
    target.mkdir()  # a directory: the atomic replace onto it fails
    with pytest.raises(OSError):
        endf_file.export(target, overwrite=True)
    # a failed export must not leave its temporary file behind
    assert not (tmp_path / "adir.endfparserpy-tmp").exists()


def test_export_empty_tape(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    original_tpid = endf_file.index.tpid_line
    del endf_file[0]
    assert len(endf_file) == 0
    # an EndfFile with every material deleted writes a valid empty
    # tape: its original tape head (TPID) followed by the tape end
    assert endf_file.to_string().splitlines() == [original_tpid, TEND_LINE]
    out = tmp_path / "out.endf"
    endf_file.export(out)
    reopened = EndfFile(out, parser=parser)
    assert len(reopened) == 0
    assert reopened.index.tpid_line == original_tpid


def test_strip_send_only_strips_a_real_send():
    # regression: only a genuine SEND (MF>0, MT=0) is stripped; an
    # FEND/MEND/TEND record (also MT=0) must be left in place
    from endf_parserpy.tape.records import _strip_send

    data = " " * 66 + "2925 3  2"  # a data record of MF=3/MT=2
    send = " " * 66 + "2925 3  0"  # SEND  (MF=3,  MT=0)
    fend = " " * 66 + "2925 0  0"  # FEND  (MF=0,  MT=0)
    assert _strip_send([data, send]) == [data]
    assert _strip_send([data, fend]) == [data, fend]
    assert _strip_send([data]) == [data]


def test_export_peak_memory_is_bounded(tmp_path, parser):
    # export streams material by material, so its peak memory is bounded
    # by a single material -- a 4x larger tape does not need 4x the heap
    import tracemalloc

    def peak_exporting(n_materials):
        path = tmp_path / f"tape{n_materials}.endf"
        path.write_bytes(
            ("\n".join(_canonical_tape(parser, [CU] * n_materials)) + "\n").encode(
                "latin-1"
            )
        )
        endf_file = EndfFile(
            path, parser=parser, parsed_cache_bytes=1 << 20, raw_cache_bytes=1 << 20
        )
        out = tmp_path / f"out{n_materials}.endf"
        tracemalloc.start()
        try:
            endf_file.export(out)
            peak = tracemalloc.get_traced_memory()[1]
        finally:
            tracemalloc.stop()
        assert len(EndfFile(out, parser=parser)) == n_materials
        return peak

    small = peak_exporting(2)
    large = peak_exporting(8)
    assert large < small * 2


# --------------------------------------------------------------------------
# section editing
# --------------------------------------------------------------------------


def test_value_edit_roundtrip(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU, ZN])
    assert not endf_file[0].is_modified

    section = dict(endf_file[0][1, 451])
    section["AWR"] = 123.5
    endf_file[0][1, 451] = section
    assert endf_file[0].is_modified

    out = tmp_path / "out.endf"
    endf_file.export(out)
    reopened = EndfFile(out, parser=parser)
    assert reopened[0][1, 451]["AWR"] == 123.5
    # the other material is untouched
    assert reopened[1][1, 451]["AWR"] == endf_file[1][1, 451]["AWR"]


def test_get_reflects_edits(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    section = dict(endf_file[0][1, 451])
    section["AWR"] = 77.0
    endf_file[0][1, 451] = section
    assert endf_file.get("#0/1/451/AWR") == 77.0


def test_delete_section(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    keys = endf_file[0].sections()
    victim = keys[-1]
    del endf_file[0][victim]
    assert victim not in endf_file[0]

    out = tmp_path / "out.endf"
    endf_file.export(out)
    reopened = EndfFile(out, parser=parser)
    assert victim not in reopened[0]
    assert len(reopened[0].sections()) == len(keys) - 1


def test_delete_then_readd_section(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    keys = set(endf_file[0].sections())
    victim = endf_file[0].sections()[-1]
    section = endf_file[0][victim]
    del endf_file[0][victim]
    assert victim not in endf_file[0]
    endf_file[0][victim] = section
    assert victim in endf_file[0]
    assert set(endf_file[0].sections()) == keys


def test_set_section_type_validation(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    with pytest.raises(TypeError):
        endf_file[0][1, 451] = 42


def test_section_assignment_rejects_invalid_keys(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    section = dict(endf_file[0][1, 451])
    # MF 0 is the tape-head slot and MT 0 the SEND marker; assigning a
    # section to either would corrupt the written tape
    with pytest.raises(ValueError, match="MF=0/MT=0"):
        endf_file[0][0, 0] = section
    with pytest.raises(ValueError, match="not a valid section key"):
        endf_file["#0/0/451"] = section
    with pytest.raises(ValueError, match="not a valid section key"):
        endf_file[0][3, 0] = section


def test_append_material_skips_tape_head_entry(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    zn = parser.parse(_read_lines(ZN), exclude=RAW_EXCLUDE)
    # an MF=0 tape-head entry is ignored whether its key is int or str
    # (the str case would otherwise slip past the mf == 0 skip)
    zn_with_head = {"0": {0: ["tape head"]}, **zn}
    view = endf_file.append_material(zn_with_head, mat=3025)
    assert (0, 0) not in view  # the MF=0 entry was not added as a section


def test_malformed_section_path_raises_descriptive_error(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    # a non-integer MF/MT in a material path gives a descriptive error,
    # not a bare int() ValueError
    with pytest.raises(ValueError, match="MF and MT must be integers"):
        endf_file["#0/x/2"]


# --------------------------------------------------------------------------
# material editing
# --------------------------------------------------------------------------


def test_delete_material(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU, ZN])
    assert len(endf_file) == 2
    cu_mat = endf_file[0].mat
    del endf_file[0]
    assert len(endf_file) == 1

    out = tmp_path / "out.endf"
    endf_file.export(out)
    reopened = EndfFile(out, parser=parser)
    assert len(reopened) == 1
    assert reopened[0].mat != cu_mat


def test_append_material(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    zn = parser.parse(_read_lines(ZN), exclude=RAW_EXCLUDE)
    view = endf_file.append_material(zn, mat=3025, za=30064)
    assert len(endf_file) == 2
    assert view.position == 1 and view.mat == 3025

    out = tmp_path / "out.endf"
    endf_file.export(out)
    reopened = EndfFile(out, parser=parser)
    assert len(reopened) == 2
    assert reopened[1].mat == 3025


def test_append_material_eager_rejects_malformed_section(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    # under check_edits="eager" a malformed appended section is rejected
    # right away, not deferred to export() time
    with pytest.raises(SectionRenderError):
        endf_file.append_material({1: {451: {"bogus": 1}}}, mat=9999)
    assert len(endf_file) == 1  # nothing was appended


def test_append_material_rejects_bad_section_type(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    with pytest.raises(TypeError):
        endf_file.append_material({3: {2: 42}}, mat=9999)
    assert len(endf_file) == 1


def test_append_material_rejects_mat_mismatch_raw(tmp_path, parser):
    # the mat argument must agree with the MAT the material's records
    # carry; for a raw (line-list) section that MAT comes from the
    # control field of the first line
    endf_file, _ = _open(tmp_path, parser, [CU])
    zn = parser.parse(_read_lines(ZN), exclude=RAW_EXCLUDE)  # raw sections
    with pytest.raises(ValueError, match="MAT=3025"):
        endf_file.append_material(zn, mat=9999)
    assert len(endf_file) == 1  # nothing was appended


def test_append_material_rejects_mat_mismatch_parsed(tmp_path, parser):
    # the same check fires for a fully parsed material, whose MAT is
    # read from the 'MAT' key of a section mapping
    endf_file, _ = _open(tmp_path, parser, [CU])
    zn = parser.parse(_read_lines(ZN))  # fully parsed sections
    with pytest.raises(ValueError, match="MAT=3025"):
        endf_file.append_material(zn, mat=9999)
    assert len(endf_file) == 1


def test_append_material_accepts_matching_mat_parsed(tmp_path, parser):
    # a parsed material whose 'MAT' agrees with the argument is appended
    endf_file, _ = _open(tmp_path, parser, [CU])
    zn = parser.parse(_read_lines(ZN))  # fully parsed sections
    view = endf_file.append_material(zn, mat=3025)
    assert len(endf_file) == 2 and view.mat == 3025


def test_delete_material_drops_cached_view(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU, ZN])
    endf_file[0]  # materialise and cache the views
    endf_file[1]
    assert len(endf_file._material_views) == 2
    del endf_file[0]
    # the deleted material's view is dropped, not leaked
    assert len(endf_file._material_views) == 1


def test_by_za_none_selects_unknown_za_only(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])  # CU has a known ZA
    zn = parser.parse(_read_lines(ZN), exclude=RAW_EXCLUDE)
    endf_file.append_material(zn, mat=3025)  # no za= given -> za is None
    selected = endf_file.by_za(None)
    # by_za(None) selects only the material with unknown ZA, not every
    # material (None must not be read as "no filter")
    assert [v.position for v in selected] == [1]


def test_live_sequence_slice_is_a_detached_copy():
    # regression: slicing a live sequence view must return a detached
    # plain copy, not a write-through view over a throwaway slice
    from endf_parserpy.tape.views import _LiveSequence

    target = [{"x": 1}, {"x": 2}, {"x": 3}]
    view = _LiveSequence(target, lambda: None)
    piece = view[0:2]
    assert piece == [{"x": 1}, {"x": 2}]
    assert isinstance(piece, list) and not isinstance(piece, _LiveSequence)
    # mutating the slice must not reach the canonical section
    piece[0]["x"] = 999
    assert target[0]["x"] == 1


def test_export_rejects_a_sectionless_material(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU, ZN])
    for key in list(endf_file[0].sections()):
        del endf_file[0][key]
    assert len(endf_file[0]) == 0
    # a material with no sections is not valid ENDF -- it is rejected at
    # output time, naming its position
    with pytest.raises(TapeStructureError, match="position 0 has no sections"):
        endf_file.export(tmp_path / "out.endf")
    with pytest.raises(TapeStructureError, match="position 0 has no sections"):
        endf_file.to_string()


def test_append_empty_material_is_rejected_at_export(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    endf_file.append_material({}, mat=3025)
    with pytest.raises(TapeStructureError, match="position 1 has no sections"):
        endf_file.export(tmp_path / "out.endf")


def test_emptied_material_can_be_rebuilt_and_exported(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    section = dict(endf_file[0][1, 451])
    for key in list(endf_file[0].sections()):
        del endf_file[0][key]
    # the empty state is transient: re-adding a section makes it valid
    endf_file[0][1, 451] = section
    out = tmp_path / "out.endf"
    endf_file.export(out)
    assert len(EndfFile(out, parser=parser)) == 1


def test_reorder(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU, ZN])
    mat0, mat1 = endf_file[0].mat, endf_file[1].mat
    endf_file.reorder([1, 0])
    assert (endf_file[0].mat, endf_file[1].mat) == (mat1, mat0)

    out = tmp_path / "out.endf"
    endf_file.export(out)
    reopened = EndfFile(out, parser=parser)
    assert (reopened[0].mat, reopened[1].mat) == (mat1, mat0)

    with pytest.raises(ValueError):
        endf_file.reorder([0, 0])


def test_export_to_same_path(tmp_path, parser):
    endf_file, path = _open(tmp_path, parser, [CU, ZN])
    del endf_file[1]
    endf_file.export(path, overwrite=True)
    reopened = EndfFile(path, parser=parser)
    assert len(reopened) == 1


def test_export_onto_source_invalidates(tmp_path, parser):
    from endf_parserpy.tape import StaleSourceError

    endf_file, path = _open(tmp_path, parser, [CU, ZN])
    endf_file.export(path, overwrite=True)
    # the in-memory index no longer matches the rewritten file
    with pytest.raises(StaleSourceError):
        len(endf_file)
    with pytest.raises(StaleSourceError):
        endf_file[0]
    with pytest.raises(StaleSourceError):
        endf_file.export(tmp_path / "elsewhere.endf")
    # the secondary lookups guard against the stale index too
    with pytest.raises(StaleSourceError):
        endf_file.by_za(29063)
    with pytest.raises(StaleSourceError):
        endf_file.find(za=29063)
    with pytest.raises(StaleSourceError):
        endf_file.query("1/451", value=0.0)
    assert "invalidated" in repr(endf_file)


def test_secondary_index_dropped_on_structural_edit(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU, ZN])
    endf_file.build_index("1/451/AWR", name="by_awr")
    assert "by_awr" in endf_file.secondary_indexes
    del endf_file[0]
    # a position-keyed index would be wrong after a structural edit, so
    # it is dropped rather than left stale
    assert endf_file.secondary_indexes == {}


def test_save_to_other_path_keeps_object_valid(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    endf_file.export(tmp_path / "copy.endf")
    # saving elsewhere is a plain export and leaves the object usable
    assert len(endf_file) == 1
    endf_file.to_string()  # to_string() never invalidates either
    assert len(endf_file) == 1


# --------------------------------------------------------------------------
# view identity through structural edits
# --------------------------------------------------------------------------


def test_view_survives_reorder(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU, ZN])
    view = endf_file[0]
    assert view.position == 0
    endf_file.reorder([1, 0])
    # the view is bound to the material, which moved to position 1
    assert view.position == 1
    assert view.mat == endf_file[1].mat


def test_deleted_material_view_is_invalid(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU, ZN])
    view = endf_file[1]
    del endf_file[1]
    # every operation on a view of a deleted material raises -- a stale
    # read or, worse, an edit dropped into a slot no longer on the tape
    with pytest.raises(RuntimeError):
        view.position
    with pytest.raises(RuntimeError):
        view.mat
    with pytest.raises(RuntimeError):
        view[1, 451]
    with pytest.raises(RuntimeError):
        view.sections()
    with pytest.raises(RuntimeError):
        len(view)
    with pytest.raises(RuntimeError):
        view[1, 451] = {}


def test_append_material_coerces_identifiers(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    zn = parser.parse(_read_lines(ZN), exclude=RAW_EXCLUDE)
    # string identifiers are coerced, so the material stays findable
    view = endf_file.append_material(zn, mat="3025", za="30064")
    assert view.mat == 3025 and view.za == 30064
    assert endf_file.by_mat(3025).position == view.position
    assert [v.position for v in endf_file.by_za(30064)] == [view.position]


# --------------------------------------------------------------------------
# pickling preserves edits
# --------------------------------------------------------------------------


def test_pickle_preserves_edits(tmp_path, parser):
    endf_file, _ = _open(tmp_path, parser, [CU])
    section = dict(endf_file[0][1, 451])
    section["AWR"] = 55.0
    endf_file[0][1, 451] = section

    restored = pickle.loads(pickle.dumps(endf_file))
    assert restored[0].is_modified
    assert restored[0][1, 451]["AWR"] == 55.0
