"""
protkit test suite
==================
Basic unit tests. Run with: pytest tests/
"""

import pytest
import numpy as np


# ─────────────────────────────────────────────
# LEARN MODULE
# ─────────────────────────────────────────────

def test_learn_oneliner_all_modules():
    from protkit.learn import THEORY
    for mod in ["qc", "cluster", "mutant", "network", "run_all"]:
        assert mod in THEORY
        assert "oneliner" in THEORY[mod]
        assert len(THEORY[mod]["oneliner"]) > 10

def test_learn_theory_content():
    from protkit.learn import THEORY
    for mod in ["qc", "cluster", "mutant", "network"]:
        assert "theory" in THEORY[mod]
        assert "analogy" in THEORY[mod]
        assert len(THEORY[mod]["theory"]) > 100

def test_random_quote():
    from protkit.learn import get_random_quote
    q = get_random_quote()
    assert isinstance(q, str)
    assert len(q) > 10


# ─────────────────────────────────────────────
# MUTANT MODULE (no MDTraj needed)
# ─────────────────────────────────────────────

def test_parse_mutations_basic():
    from protkit.modules.mutant import parse_mutations
    muts = parse_mutations("A100G,V200I")
    assert len(muts) == 2
    assert muts[0] == {"chain": None, "resid": 100, "wt": "A", "mut": "G"}
    assert muts[1] == {"chain": None, "resid": 200, "wt": "V", "mut": "I"}

def test_parse_mutations_with_chain():
    from protkit.modules.mutant import parse_mutations
    muts = parse_mutations("A:R50K")
    assert muts[0]["chain"] == "A"
    assert muts[0]["wt"] == "R"
    assert muts[0]["resid"] == 50
    assert muts[0]["mut"] == "K"

def test_parse_mutations_invalid_skipped():
    from protkit.modules.mutant import parse_mutations
    muts = parse_mutations("A100G,INVALID,V200I")
    # INVALID should be skipped, 2 valid remain
    assert len(muts) == 2

def test_blosum_score():
    from protkit.modules.mutant import _blosum_score
    score = _blosum_score("A", "A")
    assert isinstance(score, float)
    # Same AA should be less destabilizing than very different AA
    score_diff = _blosum_score("A", "W")
    assert score_diff > score or abs(score_diff - score) < 2.0  # within noise range

def test_physics_constants():
    from protkit.modules.mutant import HYDROPHOBICITY, AA_VOLUME, AA_3TO1
    # All 20 standard amino acids should be present
    standard_aa = set("ACDEFGHIKLMNPQRSTVWY")
    assert standard_aa.issubset(set(HYDROPHOBICITY.keys()))
    assert standard_aa.issubset(set(AA_VOLUME.keys()))
    assert len(AA_3TO1) == 20


# ─────────────────────────────────────────────
# CLUSTER MODULE (pure numpy, no MDTraj)
# ─────────────────────────────────────────────

def test_gromos_cluster_basic():
    from protkit.modules.cluster import _gromos_cluster
    # Simple 2-cluster RMSD matrix
    n = 10
    rmsd = np.zeros((n, n), dtype=np.float32)
    # Frames 0-4 close to each other, 5-9 close to each other
    for i in range(5):
        for j in range(5):
            if i != j:
                rmsd[i, j] = 0.5
    for i in range(5, 10):
        for j in range(5, 10):
            if i != j:
                rmsd[i, j] = 0.5
    for i in range(5):
        for j in range(5, 10):
            rmsd[i, j] = rmsd[j, i] = 5.0

    labels = _gromos_cluster(rmsd, cutoff=1.0)
    assert len(labels) == n
    # Two distinct clusters
    unique = set(l for l in labels if l != -1)
    assert len(unique) == 2

def test_count_transitions():
    from protkit.modules.cluster import _count_transitions
    labels = [0, 0, 1, 1, 0, 2, 2]
    trans = _count_transitions(labels)
    assert isinstance(trans, dict)
    # Should have transition 0→1 and 1→0 and 0→2
    total = sum(trans.values())
    assert total == 3  # 0→1, 1→0, 0→2


# ─────────────────────────────────────────────
# REPORTS (no MDTraj needed)
# ─────────────────────────────────────────────

def test_text_report_generates(tmp_path):
    from protkit.reports.text_report import generate_text_report
    results = {
        "meta": {"timestamp": "2025-01-01", "traj_file": "test.xtc",
                 "top_file": "test.pdb", "n_frames": 100, "n_residues": 150},
        "qc": {
            "rmsd":    {"times": list(range(10)), "values": [1.0]*10, "unit": "Å"},
            "rmsf":    {"residues": ["ALA1","GLY2"], "values": [0.5, 1.2], "unit": "Å"},
            "rg":      {"times": list(range(10)), "values": [15.0]*10, "unit": "Å"},
            "hbonds":  {"times": list(range(10)), "values": [50.0]*10, "unit": "count"},
            "convergence": {"rmsd_converged": True, "rg_stable": True, "rg_rel_std_pct": 1.2,
                           "rmsd_first_half_mean": 1.0, "rmsd_second_half_mean": 1.1},
        },
        "cluster": {
            "method": "hdbscan", "n_frames": 100, "n_clusters": 2, "n_noise": 5,
            "labels": [0]*50 + [1]*45 + [-1]*5,
            "populations": {0: 50, 1: 45}, "centroids": {0: 10, 1: 60},
            "centroid_files": {}, "transitions": {"(0, 1)": 3},
            "rmsd_matrix_mean": 2.0, "rmsd_matrix_max": 5.0,
        },
        "mutant": {},
        "network": {},
    }
    out = tmp_path / "report.txt"
    generate_text_report(results, out)
    assert out.exists()
    content = out.read_text()
    assert "PROTKIT" in content
    assert "RMSD" in content
    assert "CLUSTERING" in content

def test_html_report_generates(tmp_path):
    from protkit.reports.html_report import generate_html_report
    results = {
        "meta": {"timestamp": "2025-01-01", "traj_file": "test.xtc",
                 "top_file": "test.pdb", "n_frames": 100, "n_residues": 150},
        "qc": {}, "cluster": {}, "mutant": {}, "network": {},
    }
    out = tmp_path / "report.html"
    generate_html_report(results, out)
    assert out.exists()
    content = out.read_text()
    assert "protkit" in content.lower()
    assert "Chart.js" in content
    assert "<!DOCTYPE html>" in content

def test_json_data_generates(tmp_path):
    from protkit.reports.text_report import generate_json_data
    import json
    results = {"meta": {"n_frames": 100}, "qc": {}, "cluster": {}, "mutant": {}, "network": {}}
    out = tmp_path / "data.json"
    generate_json_data(results, out)
    assert out.exists()
    data = json.loads(out.read_text())
    assert data["meta"]["n_frames"] == 100


# ─────────────────────────────────────────────
# UTILS
# ─────────────────────────────────────────────

def test_make_output_dir(tmp_path):
    from protkit.utils import make_output_dir
    out = make_output_dir(str(tmp_path), "test_run")
    assert out.exists()
    assert "test_run" in out.name

def test_pdb_to_sequence_empty():
    from protkit.modules.mutant import _pdb_to_sequence
    seq = _pdb_to_sequence("/nonexistent/path.pdb")
    assert seq == ""
