"""
protkit CLI
===========
Main command-line interface. Entry point: `protkit`

Commands:
  protkit qc       — MD Quality Control
  protkit cluster  — Conformational Clustering
  protkit mutant   — Mutant Stability Scan
  protkit network  — Residue Network Analysis
  protkit run-all  — Full pipeline

Global flags:
  --learn          Show full theory + analogy before running
  --stride N       Load every Nth frame (default: 1)
  --output DIR     Output directory (default: ./protkit_results_<timestamp>)
"""

import argparse
import sys
import json
import time
from pathlib import Path
from datetime import datetime


# ─────────────────────────────────────────────
# TOP-LEVEL PARSER
# ─────────────────────────────────────────────

def build_parser():
    parser = argparse.ArgumentParser(
        prog="protkit",
        description="protkit — Protein Dynamics Analysis Suite",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  protkit qc      --traj md.xtc --top protein.pdb
  protkit cluster --traj md.xtc --top protein.pdb --method hdbscan --learn
  protkit mutant  --pdb protein.pdb --mutations A100G,V200I --method both
  protkit network --traj md.xtc  --top protein.pdb --edge-mode heavy_atom
  protkit run-all --traj md.xtc  --top protein.pdb --mutations A100G
        """,
    )
    parser.add_argument("--version", action="version", version="protkit 0.1.5")

    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # ── QC ────────────────────────────────────────────────────────
    p_qc = sub.add_parser("qc", help="MD Quality Control Dashboard")
    _add_traj_args(p_qc)
    p_qc.add_argument("--energy", metavar="FILE",
                      help="GROMACS .log or two-column energy file (optional)")
    _add_common_args(p_qc)

    # ── CLUSTER ───────────────────────────────────────────────────
    p_cl = sub.add_parser("cluster", help="Conformational State Clustering")
    _add_traj_args(p_cl)
    p_cl.add_argument("--method", choices=["hdbscan","gromos","agglomerative"],
                      default="hdbscan", help="Clustering algorithm (default: hdbscan)")
    p_cl.add_argument("--min-cluster-size", type=int, metavar="N",
                      help="HDBSCAN min_cluster_size (auto if omitted)")
    p_cl.add_argument("--n-clusters", type=int, metavar="K",
                      help="Number of clusters for agglomerative")
    p_cl.add_argument("--cutoff", type=float, default=2.0, metavar="Å",
                      help="GROMOS RMSD cutoff in Å (default: 2.0)")
    _add_common_args(p_cl)

    # ── MUTANT ────────────────────────────────────────────────────
    p_mu = sub.add_parser("mutant", help="Mutant Stability Scanner")
    p_mu.add_argument("--pdb", required=True, metavar="FILE",
                      help="Input PDB file")
    p_mu.add_argument("--mutations", required=True, metavar="MUT[,MUT...]",
                      help="Comma-separated mutations e.g. A100G,V200I")
    p_mu.add_argument("--method", choices=["physics","ml","both"],
                      default="physics", help="Scoring method (default: physics)")
    p_mu.add_argument("--centroids-json", metavar="FILE",
                      help="JSON file mapping cluster IDs to centroid PDB paths")
    _add_common_args(p_mu)

    # ── NETWORK ───────────────────────────────────────────────────
    p_nw = sub.add_parser("network", help="Protein Residue Network Analysis")
    _add_traj_args(p_nw)
    p_nw.add_argument("--edge-mode", choices=["ca_cutoff","heavy_atom"],
                      default="ca_cutoff",
                      help="Contact definition (default: ca_cutoff)")
    p_nw.add_argument("--cutoff-ca", type=float, default=8.0, metavar="Å",
                      help="Cα cutoff distance in Å (default: 8.0)")
    p_nw.add_argument("--cutoff-heavy", type=float, default=4.5, metavar="Å",
                      help="Heavy atom cutoff in Å (default: 4.5)")
    p_nw.add_argument("--source", type=int, metavar="RESID",
                      help="Source residue ID for pathway calculation")
    p_nw.add_argument("--target", type=int, metavar="RESID",
                      help="Target residue ID for pathway calculation")
    _add_common_args(p_nw)

    # ── RUN-ALL ───────────────────────────────────────────────────
    p_all = sub.add_parser("run-all", help="Run full protkit pipeline")
    _add_traj_args(p_all)
    p_all.add_argument("--energy", metavar="FILE")
    p_all.add_argument("--mutations", metavar="MUT[,MUT...]",
                       help="Mutations for mutant scan (optional)")
    p_all.add_argument("--mutant-method", choices=["physics","ml","both"],
                       default="physics")
    p_all.add_argument("--cluster-method", choices=["hdbscan","gromos","agglomerative"],
                       default="hdbscan")
    p_all.add_argument("--edge-mode", choices=["ca_cutoff","heavy_atom"],
                       default="ca_cutoff")
    p_all.add_argument("--source", type=int, metavar="RESID")
    p_all.add_argument("--target", type=int, metavar="RESID")
    _add_common_args(p_all)

    # DEMO
    p_demo = sub.add_parser('demo', help='Run full pipeline on built-in synthetic data (no files needed)')
    p_demo.add_argument('--output', metavar='DIR', default='.', help='Output directory')
    p_demo.add_argument('--open', action='store_true', help='Auto-open HTML report in browser')
    p_demo.add_argument('--quiet', action='store_true')

    return parser


def _add_traj_args(p):
    p.add_argument("--traj", required=True, metavar="FILE",
                   help="Trajectory file (.xtc .trr .nc .dcd .pdb ...)")
    p.add_argument("--top", metavar="FILE",
                   help="Topology/reference PDB (required for binary trajectory formats)")
    p.add_argument("--ref", metavar="FILE",
                   help="Reference PDB for alignment (optional; uses frame 0 if omitted)")
    p.add_argument("--ref-frame", type=int, default=0, metavar="N",
                   help="Frame to align to if no --ref given (default: 0)")
    p.add_argument("--stride", type=int, default=1, metavar="N",
                   help="Load every Nth frame (default: 1)")
    p.add_argument("--no-align", action="store_true",
                   help="Skip trajectory alignment")


def _add_common_args(p):
    p.add_argument("--output", metavar="DIR", default=".",
                   help="Output directory (default: current directory)")
    p.add_argument("--learn", action="store_true",
                   help="Show full theory + analogy before running")
    p.add_argument("--no-html", action="store_true",
                   help="Skip HTML report generation")
    p.add_argument("--no-text", action="store_true",
                   help="Skip text report generation")
    p.add_argument("--quiet", action="store_true",
                   help="Suppress banner and verbose output")


# ─────────────────────────────────────────────
# COMMAND HANDLERS
# ─────────────────────────────────────────────

def cmd_qc(args):
    from protkit.utils import banner, make_output_dir, load_trajectory, select_protein, align_trajectory, load_reference
    from protkit.learn import print_oneliner, print_learn, get_random_quote
    from protkit.modules.qc import run_qc
    from protkit.reports import generate_html_report, generate_text_report, generate_json_data

    if not args.quiet:
        banner()
    if args.learn:
        print_learn("qc")
    else:
        print_oneliner("qc")

    out_dir = make_output_dir(args.output, "protkit_qc")
    traj = load_trajectory(args.traj, args.top, args.stride)
    traj = select_protein(traj)

    if not args.no_align:
        ref = load_reference(args.ref) if args.ref else None
        traj = align_trajectory(traj, ref, args.ref_frame, top_path=getattr(args, "top", None))

    results_qc = run_qc(traj, out_dir, energy_file=args.energy)

    meta = _build_meta(args, traj)
    results = {"meta": meta, "qc": results_qc, "cluster": {}, "mutant": {}, "network": {}}

    _write_reports(results, out_dir, args)
    _finish(out_dir, args)


def cmd_cluster(args):
    from protkit.utils import banner, make_output_dir, load_trajectory, select_protein, align_trajectory, load_reference
    from protkit.learn import print_oneliner, print_learn, get_random_quote
    from protkit.modules.cluster import run_cluster
    from protkit.reports import generate_html_report, generate_text_report, generate_json_data

    if not args.quiet:
        banner()
    if args.learn:
        print_learn("cluster")
    else:
        print_oneliner("cluster")

    out_dir = make_output_dir(args.output, "protkit_cluster")
    traj = load_trajectory(args.traj, args.top, args.stride)
    traj = select_protein(traj)

    if not args.no_align:
        ref = load_reference(args.ref) if args.ref else None
        traj = align_trajectory(traj, ref, args.ref_frame, top_path=getattr(args, "top", None))

    results_cl = run_cluster(
        traj, out_dir,
        method=args.method,
        min_cluster_size=args.min_cluster_size,
        n_clusters=args.n_clusters,
        cutoff=args.cutoff,
    )

    meta = _build_meta(args, traj)
    results = {"meta": meta, "qc": {}, "cluster": results_cl, "mutant": {}, "network": {}}

    _write_reports(results, out_dir, args)
    _finish(out_dir, args)


def cmd_mutant(args):
    from protkit.utils import banner, make_output_dir
    from protkit.learn import print_oneliner, print_learn
    from protkit.modules.mutant import run_mutant
    from protkit.reports import generate_html_report, generate_text_report, generate_json_data

    if not args.quiet:
        banner()
    if args.learn:
        print_learn("mutant")
    else:
        print_oneliner("mutant")

    out_dir = make_output_dir(args.output, "protkit_mutant")

    centroids = None
    if args.centroids_json:
        with open(args.centroids_json) as f:
            centroids = json.load(f)

    results_mu = run_mutant(
        pdb_path=args.pdb,
        mutations=args.mutations,
        output_dir=out_dir,
        method=args.method,
        cluster_centroids=centroids,
    )

    meta = {"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "traj_file": args.pdb, "top_file": "N/A",
            "n_frames": 1, "n_residues": "N/A"}
    results = {"meta": meta, "qc": {}, "cluster": {}, "mutant": results_mu, "network": {}}

    _write_reports(results, out_dir, args)
    _finish(out_dir, args)


def cmd_network(args):
    from protkit.utils import banner, make_output_dir, load_trajectory, select_protein, align_trajectory, load_reference
    from protkit.learn import print_oneliner, print_learn
    from protkit.modules.network import run_network
    from protkit.reports import generate_html_report, generate_text_report, generate_json_data

    if not args.quiet:
        banner()
    if args.learn:
        print_learn("network")
    else:
        print_oneliner("network")

    out_dir = make_output_dir(args.output, "protkit_network")
    traj = load_trajectory(args.traj, args.top, args.stride)
    traj = select_protein(traj)

    if not args.no_align:
        ref = load_reference(args.ref) if args.ref else None
        traj = align_trajectory(traj, ref, args.ref_frame, top_path=getattr(args, "top", None))

    results_nw = run_network(
        traj, out_dir,
        edge_mode=args.edge_mode,
        cutoff_ca=args.cutoff_ca,
        cutoff_heavy=args.cutoff_heavy,
        source_resid=args.source,
        target_resid=args.target,
    )

    meta = _build_meta(args, traj)
    results = {"meta": meta, "qc": {}, "cluster": {}, "mutant": {}, "network": results_nw}

    _write_reports(results, out_dir, args)
    _finish(out_dir, args)


def cmd_run_all(args):
    from protkit.utils import (banner, make_output_dir, load_trajectory,
                                select_protein, align_trajectory, load_reference,
                                section_header, success)
    from protkit.learn import print_oneliner, print_learn
    from protkit.modules.qc import run_qc
    from protkit.modules.cluster import run_cluster
    from protkit.modules.mutant import run_mutant
    from protkit.modules.network import run_network
    from protkit.reports import generate_html_report, generate_text_report, generate_json_data

    if not args.quiet:
        banner()
    if args.learn:
        for mod in ["qc", "cluster", "mutant", "network"]:
            print_learn(mod)
    else:
        print_oneliner("run_all")

    out_dir = make_output_dir(args.output, "protkit_full")

    # Load & prep trajectory
    traj = load_trajectory(args.traj, args.top, args.stride)
    traj = select_protein(traj)
    if not args.no_align:
        ref = load_reference(args.ref) if args.ref else None
        traj = align_trajectory(traj, ref, args.ref_frame, top_path=getattr(args, "top", None))

    meta = _build_meta(args, traj)

    # QC
    section_header("STEP 1 / 4 — Quality Control", "🔬")
    results_qc = run_qc(traj, out_dir, energy_file=getattr(args, "energy", None))

    # Clustering
    section_header("STEP 2 / 4 — Conformational Clustering", "🔬")
    results_cl = run_cluster(traj, out_dir, method=args.cluster_method)

    # Network
    section_header("STEP 3 / 4 — Residue Network", "🔬")
    results_nw = run_network(
        traj, out_dir,
        edge_mode=args.edge_mode,
        source_resid=getattr(args, "source", None),
        target_resid=getattr(args, "target", None),
    )

    # Mutant (optional)
    results_mu = {}
    if getattr(args, "mutations", None):
        section_header("STEP 4 / 4 — Mutant Stability Scan", "🔬")
        centroid_files = results_cl.get("centroid_files", {})
        results_mu = run_mutant(
            pdb_path=args.top or args.traj,
            mutations=args.mutations,
            output_dir=out_dir,
            method=args.mutant_method,
            cluster_centroids=centroid_files if centroid_files else None,
        )
    else:
        from protkit.utils import info
        info("No --mutations provided. Skipping mutant scan. (use --mutations A100G,V200I to enable)")

    results = {
        "meta": meta,
        "qc": results_qc,
        "cluster": results_cl,
        "mutant": results_mu,
        "network": results_nw,
    }

    _write_reports(results, out_dir, args)
    _finish(out_dir, args)


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def _build_meta(args, traj) -> dict:
    return {
        "timestamp":  datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "traj_file":  getattr(args, "traj", "N/A"),
        "top_file":   getattr(args, "top",  "N/A") or "N/A",
        "n_frames":   traj.n_frames,
        "n_residues": traj.n_residues,
        "stride":     getattr(args, "stride", 1),
    }


def _write_reports(results: dict, out_dir: Path, args):
    from protkit.utils import section_header, success
    from protkit.reports import generate_html_report, generate_text_report, generate_json_data
    from protkit.reports.plot_report import generate_plots

    section_header("Writing Reports", "📝")

    # JSON data (always)
    json_path = out_dir / "protkit_data.json"
    generate_json_data(results, json_path)
    success(f"Raw data  → {json_path}")

    # Text report
    if not args.no_text:
        txt_path = out_dir / "protkit_report.txt"
        generate_text_report(results, txt_path)
        success(f"Text report → {txt_path}")

    # Individual PNG plots (always)
    generate_plots(results, out_dir)

    # HTML report
    if not args.no_html:
        html_path = out_dir / "protkit_report.html"
        generate_html_report(results, html_path)
        success(f"HTML report → {html_path}")


def _finish(out_dir: Path, args):
    from protkit.utils import success, print_quote, CYAN, BOLD, RESET, DIM
    from protkit.learn import get_random_quote

    print(f"\n{CYAN}{BOLD}  ✨ Analysis complete!{RESET}")
    print(f"{DIM}  Output directory: {out_dir}{RESET}\n")
    print_quote(get_random_quote())


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    parser = build_parser()

    if len(sys.argv) == 1:
        from protkit.utils import banner
        banner()
        parser.print_help()
        sys.exit(0)

    args = parser.parse_args()

    dispatch = {
        "qc":      cmd_qc,
        "cluster": cmd_cluster,
        "mutant":  cmd_mutant,
        "network": cmd_network,
        "run-all": cmd_run_all,
        "demo":    cmd_demo,
    }

    handler = dispatch.get(args.command)
    if handler is None:
        parser.print_help()
        sys.exit(1)

    try:
        handler(args)
    except KeyboardInterrupt:
        print("\n\n  Interrupted by user. Goodbye! 🧬\n")
        sys.exit(0)
    except Exception as e:
        from protkit.utils import error
        import traceback
        traceback.print_exc()
        error(f"Unexpected error: {e}")


def cmd_demo(args):
    from protkit.demo import run_demo
    from pathlib import Path
    run_demo(output_dir=Path(args.output), open_browser=args.open, quiet=args.quiet)


if __name__ == "__main__":
    main()
