"""
protkit — Protein Dynamics Analysis Suite
==========================================
A unified, pip-installable toolkit for structural bioinformatics.

Modules:
    - qc        : MD Simulation Quality Dashboard
    - cluster   : Conformational State Clustering (HDBSCAN)
    - mutant    : Mutant Stability Scanner
    - network   : Protein Residue Network Analysis

Usage:
    protkit qc       --traj traj.xtc --top protein.pdb
    protkit cluster  --traj traj.xtc --top protein.pdb
    protkit mutant   --pdb protein.pdb --mutations A100G,V200I
    protkit network  --pdb protein.pdb
    protkit run-all  --traj traj.xtc --top protein.pdb
"""

__version__ = "0.1.5"
__author__ = "protkit contributors"
__license__ = "MIT"

from protkit.modules.qc import run_qc
from protkit.modules.cluster import run_cluster
from protkit.modules.mutant import run_mutant
from protkit.modules.network import run_network

__all__ = ["run_qc", "run_cluster", "run_mutant", "run_network"]
