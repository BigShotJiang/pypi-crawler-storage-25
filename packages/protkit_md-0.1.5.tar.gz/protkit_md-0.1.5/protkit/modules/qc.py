"""
protkit.modules.qc
==================
MD Simulation Quality Control Dashboard.

Computes:
  - RMSD vs time
  - Per-residue RMSF
  - Radius of Gyration vs time
  - Hydrogen bond count vs time
  - Potential energy (if available via .edr or .log)
"""

import numpy as np
from pathlib import Path


def run_qc(traj, output_dir: Path, energy_file: str = None) -> dict:
    """
    Run full QC analysis on an MD trajectory.

    Parameters
    ----------
    traj        : mdtraj.Trajectory (protein-only, aligned)
    output_dir  : Path to write outputs
    energy_file : Optional path to GROMACS .edr or AMBER energy log

    Returns
    -------
    results : dict with all computed arrays (for report generation)
    """
    import mdtraj as md
    from protkit.utils import section_header, success, warn, info, progress

    section_header("MD Quality Control", "📊")

    results = {}
    n_frames = traj.n_frames
    times = np.arange(n_frames)  # frame indices (user can scale to ns)

    # ── RMSD ──────────────────────────────────────────────────────
    progress("Computing RMSD...")
    ca_idx = traj.topology.select("name CA")
    ref = traj[0]
    rmsd = md.rmsd(traj, ref, atom_indices=ca_idx) * 10  # nm → Å
    results["rmsd"] = {"times": [int(t) for t in times], "values": rmsd.tolist(), "unit": "Å"}
    success(f"RMSD  | mean={rmsd.mean():.2f} Å  max={rmsd.max():.2f} Å  final={rmsd[-1]:.2f} Å")

    # ── RMSF ──────────────────────────────────────────────────────
    progress("Computing RMSF per residue...")
    rmsf = md.rmsf(traj, traj, atom_indices=ca_idx) * 10  # nm → Å
    residue_ids = [str(r) for r in traj.topology.residues]
    results["rmsf"] = {
        "residues": residue_ids,
        "values": rmsf.tolist(),
        "unit": "Å"
    }
    top3_flex = np.argsort(rmsf)[-3:][::-1]
    success(f"RMSF  | mean={rmsf.mean():.2f} Å  most flexible: " +
            ", ".join([residue_ids[i] for i in top3_flex]))

    # ── RADIUS OF GYRATION ────────────────────────────────────────
    progress("Computing Radius of Gyration...")
    rg = md.compute_rg(traj) * 10  # nm → Å
    results["rg"] = {"times": [int(t) for t in times], "values": rg.tolist(), "unit": "Å"}
    success(f"Rg    | mean={rg.mean():.2f} Å  std={rg.std():.2f} Å")

    # ── HYDROGEN BONDS ────────────────────────────────────────────
    progress("Computing hydrogen bonds...")
    try:
        hbonds_per_frame = []
        # Sample frames for speed on large trajectories
        sample_frames = list(range(0, n_frames, max(1, n_frames // 200)))

        # Try wernet_nilsson first, then baker_hubbard, then backbone geometry fallback
        for i in sample_frames:
            frame = traj[i]
            count = 0
            try:
                hb = md.wernet_nilsson(frame, exclude_water=True, periodic=False)[0]
                count = len(hb)
            except Exception:
                try:
                    hb = md.baker_hubbard(frame, periodic=False, freq=0.0)
                    count = len(hb)
                except Exception:
                    # Geometry fallback: count N-H...O distances < 3.5 Å
                    try:
                        n_idx  = frame.topology.select("backbone and name N")
                        o_idx  = frame.topology.select("backbone and name O")
                        if len(n_idx) > 0 and len(o_idx) > 0:
                            n_pos = frame.xyz[0, n_idx]
                            o_pos = frame.xyz[0, o_idx]
                            from itertools import product as iproduct
                            cnt = 0
                            for ni, oi in iproduct(range(len(n_pos)), range(len(o_pos))):
                                d = np.linalg.norm(n_pos[ni] - o_pos[oi])
                                if 0.15 < d < 0.35:  # 1.5-3.5 Å in nm
                                    cnt += 1
                            count = cnt
                    except Exception:
                        count = 0
            hbonds_per_frame.append(count)

        hbonds_arr = np.array(hbonds_per_frame, dtype=float)
        results["hbonds"] = {
            "times": [int(times[i]) for i in sample_frames],
            "values": hbonds_arr.tolist(),
            "unit": "count"
        }
        success(f"H-bonds | mean={hbonds_arr.mean():.1f}  std={hbonds_arr.std():.1f}")
    except Exception as e:
        warn(f"H-bond calculation failed: {e}. Skipping.")
        results["hbonds"] = None

    # ── POTENTIAL ENERGY (optional) ────────────────────────────────
    results["energy"] = None
    if energy_file:
        progress(f"Parsing energy file: {energy_file}")
        energy_data = _parse_energy_file(energy_file)
        if energy_data:
            results["energy"] = energy_data
            mean_e = np.mean(energy_data["values"])
            success(f"Energy | mean={mean_e:.1f} kJ/mol")
        else:
            warn("Could not parse energy file. Skipping energy plot.")
    else:
        info("No energy file provided (--energy). Energy plot will be skipped.")

    # ── CONVERGENCE SUMMARY ────────────────────────────────────────
    conv = _convergence_assessment(rmsd, rg)
    results["convergence"] = conv
    _print_convergence(conv)

    return results


def _parse_energy_file(path: str) -> dict:
    """
    Parse energy from a GROMACS .log or simple two-column text file.
    Returns dict with 'times' and 'values' lists, or None on failure.
    """
    path = Path(path)
    ext = path.suffix.lower()
    times, values = [], []

    try:
        if ext in [".log"]:
            # Parse GROMACS log: look for Potential Energy lines
            with open(path) as f:
                step = 0
                for line in f:
                    if "Potential Energy" in line:
                        parts = line.split()
                        for i, p in enumerate(parts):
                            if p == "Energy" and i + 1 < len(parts):
                                try:
                                    values.append(float(parts[i + 1]))
                                    times.append(step)
                                    step += 1
                                except ValueError:
                                    pass
        else:
            # Assume two-column text: time  energy
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    parts = line.split()
                    if len(parts) >= 2:
                        try:
                            times.append(float(parts[0]))
                            values.append(float(parts[1]))
                        except ValueError:
                            pass
        if times and values:
            return {"times": times, "values": values, "unit": "kJ/mol"}
    except Exception:
        pass
    return None


def _convergence_assessment(rmsd: np.ndarray, rg: np.ndarray) -> dict:
    """
    Simple heuristic convergence check:
      - Split trajectory into first and second halves
      - Compare RMSD means; if difference < 20% of overall mean → converged
    """
    mid = len(rmsd) // 2
    rmsd_diff = abs(rmsd[mid:].mean() - rmsd[:mid].mean())
    rmsd_converged = rmsd_diff < 0.2 * rmsd.mean()

    rg_std_rel = rg.std() / rg.mean()
    rg_stable = rg_std_rel < 0.05  # less than 5% relative fluctuation

    return {
        "rmsd_converged": bool(rmsd_converged),
        "rg_stable": bool(rg_stable),
        "rmsd_first_half_mean": float(rmsd[:mid].mean()),
        "rmsd_second_half_mean": float(rmsd[mid:].mean()),
        "rg_rel_std_pct": float(rg_std_rel * 100),
    }


def _print_convergence(conv: dict):
    from protkit.utils import success, warn, section_header
    section_header("Convergence Assessment", "🔍")
    if conv["rmsd_converged"]:
        success("RMSD appears converged (second half stable)")
    else:
        warn("RMSD may not be converged — consider longer simulation")
    if conv["rg_stable"]:
        success(f"Radius of Gyration stable (rel. std = {conv['rg_rel_std_pct']:.1f}%)")
    else:
        warn(f"Rg fluctuating significantly (rel. std = {conv['rg_rel_std_pct']:.1f}%)")
