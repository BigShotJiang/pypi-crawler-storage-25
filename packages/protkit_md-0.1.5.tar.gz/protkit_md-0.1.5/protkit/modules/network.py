"""
protkit.modules.network
=======================
Protein Residue Network (PRN) Analysis.

Builds a graph where:
  Nodes  = residues
  Edges  = contacts (Cα cutoff OR heavy atom contacts)
  Weight = contact frequency across trajectory frames

Computes:
  - Degree centrality
  - Betweenness centrality
  - Closeness centrality
  - Shortest communication pathways between any two residues
  - Hub residues (top betweenness)
  - Per-cluster network comparison (if cluster data provided)
"""

import numpy as np
from pathlib import Path


def run_network(
    traj,
    output_dir: Path,
    edge_mode: str = "ca_cutoff",
    cutoff_ca: float = 8.0,
    cutoff_heavy: float = 4.5,
    source_resid: int = None,
    target_resid: int = None,
    cluster_centroids: dict = None,
) -> dict:
    """
    Build and analyse a Protein Residue Network.

    Parameters
    ----------
    traj             : mdtraj.Trajectory (protein-only)
    output_dir       : Path
    edge_mode        : 'ca_cutoff' | 'heavy_atom'
    cutoff_ca        : Å cutoff for Cα-Cα contacts (default 8.0 Å)
    cutoff_heavy     : Å cutoff for heavy atom contacts (default 4.5 Å)
    source_resid     : Residue ID for pathway start (optional)
    target_resid     : Residue ID for pathway end (optional)
    cluster_centroids: dict {cluster_id: pdb_path} for multi-state comparison

    Returns
    -------
    results : dict
    """
    from protkit.utils import section_header, success, warn, info, progress

    section_header("Protein Residue Network Analysis", "🕸️")
    info(f"Edge mode: {edge_mode}  |  Frames: {traj.n_frames}")

    # Build contact map averaged over trajectory
    progress("Computing contact frequency map...")
    contact_map, residue_labels = _compute_contact_map(traj, edge_mode, cutoff_ca, cutoff_heavy)
    n_res = len(residue_labels)
    success(f"Contact map: {n_res} residues")

    # Build graph
    progress("Building residue network graph...")
    G = _build_graph(contact_map, residue_labels)
    n_edges = G.number_of_edges()
    success(f"Graph: {n_res} nodes | {n_edges} edges")

    # Compute centralities
    progress("Computing network centralities...")
    centralities = _compute_centralities(G)
    success("Centralities computed")

    # Hub residues
    hubs = _get_hubs(centralities, n=10)
    _print_hubs(hubs, residue_labels)

    # Communication pathway
    pathway_result = None
    if source_resid is not None and target_resid is not None:
        progress(f"Finding shortest path: residue {source_resid} → {target_resid}")
        pathway_result = _shortest_path(G, source_resid, target_resid, residue_labels)
        _print_pathway(pathway_result)

    # Multi-state comparison
    cluster_comparison = {}
    if cluster_centroids:
        progress("Comparing networks across conformational states...")
        cluster_comparison = _compare_cluster_networks(
            cluster_centroids, edge_mode, cutoff_ca, cutoff_heavy
        )
        _print_cluster_comparison(cluster_comparison)

    return {
        "edge_mode": edge_mode,
        "n_residues": n_res,
        "n_edges": n_edges,
        "residue_labels": residue_labels,
        "contact_map": contact_map.tolist(),
        "centralities": centralities,
        "hubs": hubs,
        "pathway": pathway_result,
        "cluster_comparison": cluster_comparison,
    }


# ─────────────────────────────────────────────────────────
# CONTACT MAP
# ─────────────────────────────────────────────────────────

def _compute_contact_map(traj, edge_mode: str, cutoff_ca: float, cutoff_heavy: float):
    """
    Returns (contact_map, residue_labels).
    contact_map[i,j] = fraction of frames where residues i,j are in contact.
    """
    import mdtraj as md

    n_res = traj.n_residues
    residue_labels = [f"{r.name}{r.resSeq}" for r in traj.topology.residues]
    contact_counts = np.zeros((n_res, n_res), dtype=np.float32)

    if edge_mode == "ca_cutoff":
        ca_idx = traj.topology.select("name CA")
        for fi in range(traj.n_frames):
            ca_pos = traj.xyz[fi, ca_idx] * 10  # nm → Å
            dist_matrix = np.linalg.norm(
                ca_pos[:, None, :] - ca_pos[None, :, :], axis=-1
            )
            contacts = (dist_matrix < cutoff_ca) & (dist_matrix > 0)
            contact_counts += contacts.astype(np.float32)

    elif edge_mode == "heavy_atom":
        # Use MDTraj's compute_contacts for residue pairs
        residue_pairs = [(i, j) for i in range(n_res) for j in range(i + 3, n_res)]
        if residue_pairs:
            try:
                distances, _ = md.compute_contacts(
                    traj, contacts=residue_pairs, scheme="closest-heavy"
                )
                distances_A = distances * 10  # nm → Å
                contacts_bool = distances_A < cutoff_heavy  # (n_frames, n_pairs)
                freq = contacts_bool.mean(axis=0)  # fraction of frames

                for idx, (i, j) in enumerate(residue_pairs):
                    contact_counts[i, j] = freq[idx] * traj.n_frames
                    contact_counts[j, i] = freq[idx] * traj.n_frames
            except Exception as e:
                from protkit.utils import warn
                warn(f"Heavy atom contact failed ({e}), falling back to Cα cutoff.")
                return _compute_contact_map(traj, "ca_cutoff", cutoff_ca, cutoff_heavy)

    contact_map = contact_counts / traj.n_frames
    return contact_map, residue_labels


# ─────────────────────────────────────────────────────────
# GRAPH
# ─────────────────────────────────────────────────────────

def _build_graph(contact_map: np.ndarray, residue_labels: list):
    """Build a weighted networkx graph from the contact map."""
    try:
        import networkx as nx
    except ImportError:
        from protkit.utils import error
        error("NetworkX not found. Install with: pip install networkx")

    n = contact_map.shape[0]
    G = nx.Graph()

    # Add nodes
    for i, label in enumerate(residue_labels):
        G.add_node(i, label=label)

    # Add edges (contact frequency as weight)
    for i in range(n):
        for j in range(i + 1, n):
            freq = float(contact_map[i, j])
            if freq > 0.3:  # only persistent contacts (>30% of frames)
                # Weight = 1/freq so shortest path = strongest contact path
                G.add_edge(i, j, weight=1.0 / freq, frequency=freq)

    return G


# ─────────────────────────────────────────────────────────
# CENTRALITIES
# ─────────────────────────────────────────────────────────

def _compute_centralities(G) -> dict:
    """Compute degree, betweenness, closeness centrality for all nodes."""
    import networkx as nx

    degree = nx.degree_centrality(G)
    betweenness = nx.betweenness_centrality(G, weight="weight", normalized=True)
    closeness = nx.closeness_centrality(G, distance="weight")

    return {
        "degree": {int(k): round(v, 6) for k, v in degree.items()},
        "betweenness": {int(k): round(v, 6) for k, v in betweenness.items()},
        "closeness": {int(k): round(v, 6) for k, v in closeness.items()},
    }


def _get_hubs(centralities: dict, n: int = 10) -> list:
    """Return top-n hub residues by betweenness centrality."""
    bw = centralities["betweenness"]
    sorted_hubs = sorted(bw.items(), key=lambda x: x[1], reverse=True)
    return [{"node": int(k), "betweenness": v,
             "degree": centralities["degree"].get(int(k), 0),
             "closeness": centralities["closeness"].get(int(k), 0)}
            for k, v in sorted_hubs[:n]]


# ─────────────────────────────────────────────────────────
# SHORTEST PATH
# ─────────────────────────────────────────────────────────

def _shortest_path(G, source_resid: int, target_resid: int, residue_labels: list) -> dict:
    """Find shortest communication path between two residues."""
    import networkx as nx

    # Map resid → node index
    def resid_to_node(resid):
        for i, label in enumerate(residue_labels):
            try:
                if int("".join(filter(str.isdigit, label))) == resid:
                    return i
            except Exception:
                pass
        return None

    src = resid_to_node(source_resid)
    tgt = resid_to_node(target_resid)

    if src is None or tgt is None:
        from protkit.utils import warn
        warn(f"Could not map residues {source_resid}/{target_resid} to graph nodes.")
        return None

    try:
        path = nx.shortest_path(G, source=src, target=tgt, weight="weight")
        path_length = nx.shortest_path_length(G, source=src, target=tgt, weight="weight")
        path_labels = [residue_labels[p] for p in path]
        return {
            "source": source_resid, "target": target_resid,
            "path_nodes": path, "path_labels": path_labels,
            "path_length": round(path_length, 4),
            "n_hops": len(path) - 1,
        }
    except nx.NetworkXNoPath:
        from protkit.utils import warn
        warn(f"No path found between residues {source_resid} and {target_resid}.")
        return None


# ─────────────────────────────────────────────────────────
# CLUSTER COMPARISON
# ─────────────────────────────────────────────────────────

def _compare_cluster_networks(cluster_centroids: dict, edge_mode, cutoff_ca, cutoff_heavy) -> dict:
    """Build a separate PRN for each cluster centroid and compare hub residues."""
    import mdtraj as md

    comparison = {}
    for cid, pdb_path in cluster_centroids.items():
        try:
            traj_c = md.load(str(pdb_path))
            cmap, rlabels = _compute_contact_map(traj_c, edge_mode, cutoff_ca, cutoff_heavy)
            G_c = _build_graph(cmap, rlabels)
            centralities_c = _compute_centralities(G_c)
            hubs_c = _get_hubs(centralities_c, n=5)
            comparison[str(cid)] = {
                "n_edges": G_c.number_of_edges(),
                "hubs": hubs_c,
                "residue_labels": rlabels,
            }
        except Exception as e:
            from protkit.utils import warn
            warn(f"Network analysis failed for cluster {cid}: {e}")

    return comparison


# ─────────────────────────────────────────────────────────
# PRINTING
# ─────────────────────────────────────────────────────────

def _print_hubs(hubs: list, residue_labels: list):
    from protkit.utils import section_header, CYAN, BOLD, RESET, DIM

    section_header("Top Hub Residues (Betweenness Centrality)", "🔑")
    print(f"  {BOLD}{'Rank':<5} {'Residue':<10} {'Betweenness':>14} {'Degree':>10} {'Closeness':>12}{RESET}")
    print(f"  {DIM}{'─'*55}{RESET}")
    for rank, hub in enumerate(hubs, 1):
        label = residue_labels[hub["node"]] if hub["node"] < len(residue_labels) else str(hub["node"])
        print(f"  {rank:<5} {CYAN}{label:<10}{RESET} {hub['betweenness']:>14.4f} {hub['degree']:>10.4f} {hub['closeness']:>12.4f}")


def _print_pathway(pathway: dict):
    from protkit.utils import section_header, success, CYAN, RESET

    if pathway is None:
        return
    section_header("Communication Pathway", "📡")
    path_str = " → ".join([f"{CYAN}{l}{RESET}" for l in pathway["path_labels"]])
    print(f"  {path_str}")
    success(f"Path length: {pathway['path_length']:.4f}  |  Hops: {pathway['n_hops']}")


def _print_cluster_comparison(comparison: dict):
    from protkit.utils import section_header, info, BOLD, RESET

    if not comparison:
        return
    section_header("Network Comparison Across Conformational States", "🔀")
    for cid, data in comparison.items():
        hub_labels = [h.get("label", str(h["node"])) for h in data["hubs"][:3]]
        info(f"Cluster {cid}: {data['n_edges']} edges | top hubs: " +
             ", ".join([data["residue_labels"][h["node"]]
                        for h in data["hubs"][:3]
                        if h["node"] < len(data["residue_labels"])]))
