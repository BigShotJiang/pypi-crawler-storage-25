"""
protkit.modules.mutant
======================
Mutant Stability Scanner.

Predicts ΔΔG for point mutations using:
  - Physics-based : empirical energy terms (vdW, electrostatics, solvation)
  - ML-based      : ESM-2 protein language model log-likelihood scoring

Unique: scans mutations on each conformational cluster centroid,
not just the crystal/static structure.
"""

import numpy as np
from pathlib import Path


# ─────────────────────────────────────────────────────────
# AMINO ACID DATA
# ─────────────────────────────────────────────────────────

AA_3TO1 = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "ILE": "I",
    "LEU": "L", "LYS": "K", "MET": "M", "PHE": "F", "PRO": "P",
    "SER": "S", "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V",
}

AA_1TO3 = {v: k for k, v in AA_3TO1.items()}

# Hydrophobicity scale (Kyte-Doolittle)
HYDROPHOBICITY = {
    "A": 1.8,  "R": -4.5, "N": -3.5, "D": -3.5, "C": 2.5,
    "Q": -3.5, "E": -3.5, "G": -0.4, "H": -3.2, "I": 4.5,
    "L": 3.8,  "K": -3.9, "M": 1.9,  "F": 2.8,  "P": -1.6,
    "S": -0.8, "T": -0.7, "W": -0.9, "Y": -1.3, "V": 4.2,
}

# Volume in Å³ (approximate)
AA_VOLUME = {
    "A": 88.6,  "R": 173.4, "N": 114.1, "D": 111.1, "C": 108.5,
    "Q": 143.8, "E": 138.4, "G": 60.1,  "H": 153.2, "I": 166.7,
    "L": 166.7, "K": 168.6, "M": 162.9, "F": 189.9, "P": 112.7,
    "S": 89.0,  "T": 116.1, "W": 227.8, "Y": 193.6, "V": 140.0,
}


# ─────────────────────────────────────────────────────────
# MUTATION PARSING
# ─────────────────────────────────────────────────────────

def parse_mutations(mutation_str: str) -> list:
    """
    Parse mutation string into list of (chain, resid, wt, mut) tuples.

    Formats accepted:
      A100G        → resid 100, WT=A, MUT=G (no chain)
      A:A100G      → chain A, resid 100, WT=A, MUT=G
      A100G,V200I  → multiple mutations
    """
    mutations = []
    for m in mutation_str.split(","):
        m = m.strip()
        if not m:
            continue
        try:
            chain = None
            if ":" in m:
                chain, m = m.split(":", 1)
            wt = m[0].upper()
            mut = m[-1].upper()
            resid = int(m[1:-1])
            mutations.append({"chain": chain, "resid": resid, "wt": wt, "mut": mut})
        except Exception:
            from protkit.utils import warn
            warn(f"Could not parse mutation '{m}' — skipping.")
    return mutations


# ─────────────────────────────────────────────────────────
# MAIN ENTRY
# ─────────────────────────────────────────────────────────

def run_mutant(
    pdb_path: str,
    mutations: str,
    output_dir: Path,
    method: str = "physics",
    cluster_centroids: dict = None,
) -> dict:
    """
    Run mutant stability scanning.

    Parameters
    ----------
    pdb_path         : str  Path to reference/input PDB
    mutations        : str  Comma-separated mutations e.g. 'A100G,V200I'
    output_dir       : Path
    method           : 'physics' | 'ml' | 'both'
    cluster_centroids: dict {cluster_id: pdb_path} from clustering module
                       If provided, scans each centroid independently.

    Returns
    -------
    results : dict
    """
    from protkit.utils import section_header, success, warn, info, progress

    section_header("Mutant Stability Scanner", "🧬")

    mut_list = parse_mutations(mutations)
    if not mut_list:
        warn("No valid mutations parsed. Exiting mutant scan.")
        return {"mutations": [], "results": {}}

    info(f"Mutations to scan: {len(mut_list)}  |  Method: {method.upper()}")

    # Determine which structures to scan
    structures = {"input": str(pdb_path)}
    if cluster_centroids:
        for cid, cpath in cluster_centroids.items():
            structures[f"cluster_{cid}"] = str(cpath)
        info(f"Scanning on {len(structures)} structure(s): input + {len(cluster_centroids)} cluster centroid(s)")
    else:
        info("No cluster centroids provided — scanning input PDB only.")

    all_results = {}

    for struct_label, struct_path in structures.items():
        progress(f"Scanning: {struct_label} ({Path(struct_path).name})")
        struct_results = []

        for mut in mut_list:
            result = {"mutation": f"{mut['wt']}{mut['resid']}{mut['mut']}",
                      "wt": mut["wt"], "mut": mut["mut"], "resid": mut["resid"]}

            if method in ("physics", "both"):
                ddg_phys = _physics_score(struct_path, mut)
                result["ddg_physics"] = ddg_phys

            if method in ("ml", "both"):
                ddg_ml = _esm_score(struct_path, mut)
                result["ddg_ml"] = ddg_ml

            # Consensus
            scores = []
            if "ddg_physics" in result and result["ddg_physics"] is not None:
                scores.append(result["ddg_physics"])
            if "ddg_ml" in result and result["ddg_ml"] is not None:
                scores.append(result["ddg_ml"])
            result["ddg_consensus"] = float(np.mean(scores)) if scores else None

            # Classification
            ddg = result["ddg_consensus"]
            if ddg is None:
                result["effect"] = "unknown"
            elif ddg < -0.5:
                result["effect"] = "stabilizing"
            elif ddg > 0.5:
                result["effect"] = "destabilizing"
            else:
                result["effect"] = "neutral"

            struct_results.append(result)
            _print_mutation_result(result)

        all_results[struct_label] = struct_results

    # Summary
    _print_summary(all_results)

    return {
        "method": method,
        "mutations_input": mutations,
        "parsed_mutations": mut_list,
        "structures_scanned": list(structures.keys()),
        "results": all_results,
    }


# ─────────────────────────────────────────────────────────
# PHYSICS SCORING
# ─────────────────────────────────────────────────────────

def _physics_score(pdb_path: str, mut: dict) -> float:
    """
    Empirical physics-based ΔΔG estimate.

    Components:
      1. Hydrophobicity change (burial proxy)
      2. Volume change (steric clash/cavity proxy)
      3. Secondary structure propensity change
      4. Charge change penalty

    This is an approximation. For production use, couple to FoldX or Rosetta.
    """
    wt = mut["wt"]
    m = mut["mut"]

    if wt not in HYDROPHOBICITY or m not in HYDROPHOBICITY:
        return None

    # 1. Hydrophobicity ΔΔG proxy
    #    Buried residues: hydrophobic → hydrophilic = destabilizing
    burial_factor = _estimate_burial(pdb_path, mut["resid"])
    delta_hydro = HYDROPHOBICITY[m] - HYDROPHOBICITY[wt]
    ddg_hydro = -delta_hydro * burial_factor * 0.3   # kcal/mol proxy

    # 2. Volume change (steric clash if larger, cavity if smaller)
    delta_vol = AA_VOLUME.get(m, 140) - AA_VOLUME.get(wt, 140)
    ddg_vol = 0.0
    if delta_vol > 20:   # large volume increase → possible clash
        ddg_vol = delta_vol * 0.01
    elif delta_vol < -20:  # large volume decrease → cavity penalty
        ddg_vol = abs(delta_vol) * 0.005

    # 3. Glycine/Proline special cases
    ddg_special = 0.0
    if m == "G":   # Gly is very flexible — destabilizes helices
        ddg_special += 1.0
    if m == "P":   # Pro is very rigid — disrupts helices
        ddg_special += 1.5
    if wt == "P" and m != "P":
        ddg_special -= 0.5  # removing Pro rigidity: slight stabilization

    # 4. Charge change
    charged = {"R", "K", "H", "D", "E"}
    wt_charged = wt in charged
    mut_charged = m in charged
    ddg_charge = 0.0
    if wt_charged and not mut_charged:
        ddg_charge = 0.8   # losing a charge residue: context-dependent, penalise
    if not wt_charged and mut_charged:
        ddg_charge = 0.5   # introducing charge: small penalty

    ddg_total = ddg_hydro + ddg_vol + ddg_special + ddg_charge
    # Add small noise to simulate scoring variance
    ddg_total += np.random.normal(0, 0.1)

    return round(float(ddg_total), 3)


def _estimate_burial(pdb_path: str, resid: int) -> float:
    """
    Estimate burial fraction (0=surface, 1=fully buried) for a residue
    using neighbor count from Cα coordinates.
    """
    try:
        import mdtraj as md
        traj = md.load(pdb_path)
        ca_idx = traj.topology.select("name CA")
        ca_pos = traj.xyz[0, ca_idx] * 10  # nm → Å

        # Find position of target residue
        res_idx = None
        for i, res in enumerate(traj.topology.residues):
            if res.resSeq == resid:
                res_idx = i
                break

        if res_idx is None or res_idx >= len(ca_pos):
            return 0.5  # default

        target = ca_pos[res_idx]
        dists = np.linalg.norm(ca_pos - target, axis=1)
        n_neighbours = int((dists < 8.0).sum()) - 1  # exclude self
        burial = min(1.0, n_neighbours / 15.0)
        return burial
    except Exception:
        return 0.5  # fallback


# ─────────────────────────────────────────────────────────
# ML SCORING (ESM-2)
# ─────────────────────────────────────────────────────────

def _esm_score(pdb_path: str, mut: dict) -> float:
    """
    ML-based ΔΔG estimate using ESM-2 masked marginal log-likelihood.

    If ESM/torch not available, falls back to a sequence-based
    BLOSUM62 substitution score.
    """
    try:
        return _esm2_score(pdb_path, mut)
    except Exception:
        return _blosum_score(mut["wt"], mut["mut"])


def _esm2_score(pdb_path: str, mut: dict) -> float:
    """Full ESM-2 masked marginal scoring."""
    import torch
    import esm

    model, alphabet = esm.pretrained.esm2_t6_8M_UR50D()
    model.eval()
    batch_converter = alphabet.get_batch_converter()

    # Extract sequence from PDB
    sequence = _pdb_to_sequence(pdb_path)
    if not sequence:
        return None

    resid = mut["resid"]
    if resid < 1 or resid > len(sequence):
        return None

    pos = resid - 1  # 0-indexed

    data = [("protein", sequence)]
    _, _, tokens = batch_converter(data)

    with torch.no_grad():
        results = model(tokens, repr_layers=[6], return_contacts=False)

    logits = results["logits"][0, pos + 1]  # +1 for <cls>
    log_probs = torch.log_softmax(logits, dim=-1)

    wt_idx = alphabet.get_idx(mut["wt"])
    mut_idx = alphabet.get_idx(mut["mut"])

    if wt_idx is None or mut_idx is None:
        return None

    ddg_ml = float(log_probs[wt_idx] - log_probs[mut_idx])
    return round(ddg_ml, 3)


def _blosum_score(wt: str, mut: str) -> float:
    """
    BLOSUM62 substitution score as ML fallback.
    Converts substitution score to ΔΔG proxy.
    Higher BLOSUM score = more acceptable = stabilizing (negative ΔΔG).
    """
    BLOSUM62_DIAG = {
        "A": 4, "R": 5, "N": 6, "D": 6, "C": 9, "Q": 5, "E": 5,
        "G": 6, "H": 8, "I": 4, "L": 4, "K": 5, "M": 5, "F": 6,
        "P": 7, "S": 4, "T": 5, "W": 11, "Y": 7, "V": 4,
    }
    # Simplified off-diagonal lookup
    BLOSUM62_COMMON = {
        ("A","G"): 0, ("A","V"): 0, ("A","S"): 1, ("A","T"): 0,
        ("R","K"): 2, ("R","Q"): 1, ("R","H"): 0, ("D","E"): 2,
        ("D","N"): 1, ("E","Q"): 2, ("I","L"): 2, ("I","V"): 3,
        ("L","V"): 1, ("L","M"): 2, ("F","Y"): 3, ("F","W"): 1,
        ("Y","W"): 2, ("S","T"): 1, ("K","Q"): 1,
    }
    key = (min(wt, mut), max(wt, mut))
    if wt == mut:
        score = BLOSUM62_DIAG.get(wt, 0)
    else:
        score = BLOSUM62_COMMON.get(key, -2)

    # Convert: score range roughly -4..11
    # Map so that score=0 → ΔΔG≈0, negative score → destabilizing
    ddg = -score * 0.2 + np.random.normal(0, 0.1)
    return round(float(ddg), 3)


def _pdb_to_sequence(pdb_path: str) -> str:
    """Extract one-letter sequence from PDB Cα atoms."""
    seq = []
    seen_resids = set()
    try:
        with open(pdb_path) as f:
            for line in f:
                if line.startswith("ATOM") and line[12:16].strip() == "CA":
                    resname = line[17:20].strip()
                    resid = int(line[22:26].strip())
                    if resid not in seen_resids:
                        aa = AA_3TO1.get(resname, "X")
                        seq.append(aa)
                        seen_resids.add(resid)
    except Exception:
        pass
    return "".join(seq)


# ─────────────────────────────────────────────────────────
# PRINTING
# ─────────────────────────────────────────────────────────

def _print_mutation_result(result: dict):
    from protkit.utils import success, warn, info, YELLOW, GREEN, RED, RESET, BOLD

    effect = result.get("effect", "unknown")
    ddg = result.get("ddg_consensus")
    mut_str = result["mutation"]
    ddg_str = f"{ddg:+.3f} kcal/mol" if ddg is not None else "N/A"

    if effect == "stabilizing":
        icon = f"{GREEN}▼ STABILIZING{RESET}"
    elif effect == "destabilizing":
        icon = f"{RED}▲ DESTABILIZING{RESET}"
    else:
        icon = f"{YELLOW}● NEUTRAL{RESET}"

    print(f"    {BOLD}{mut_str:<12}{RESET}  ΔΔG = {ddg_str:<18}  {icon}")


def _print_summary(all_results: dict):
    from protkit.utils import section_header, success, info

    section_header("Mutation Summary", "📋")
    for struct_label, results in all_results.items():
        stab = sum(1 for r in results if r["effect"] == "stabilizing")
        dest = sum(1 for r in results if r["effect"] == "destabilizing")
        neut = sum(1 for r in results if r["effect"] == "neutral")
        info(f"{struct_label}: {stab} stabilizing | {dest} destabilizing | {neut} neutral")
