"""
protkit.modules.cluster
=======================
Conformational state clustering of MD trajectories.

Default  : HDBSCAN on RMSD matrix (non-parametric, noise-aware)
Optional : GROMOS (cutoff-based nearest-neighbour)
           Agglomerative (Ward linkage hierarchical)
"""

import numpy as np
from pathlib import Path


def run_cluster(
    traj,
    output_dir: Path,
    method: str = "hdbscan",
    min_cluster_size: int = None,
    n_clusters: int = None,
    cutoff: float = 2.0,
) -> dict:
    """
    Cluster trajectory frames by conformational similarity.

    Parameters
    ----------
    traj             : mdtraj.Trajectory (protein-only, aligned)
    output_dir       : Path to write centroid PDBs
    method           : 'hdbscan' (default) | 'gromos' | 'agglomerative'
    min_cluster_size : HDBSCAN min_cluster_size (auto if None)
    n_clusters       : Number of clusters for agglomerative (auto if None)
    cutoff           : GROMOS RMSD cutoff in Å (default 2.0 Å)

    Returns
    -------
    results : dict with cluster labels, populations, centroids
    """
    import mdtraj as md
    from protkit.utils import section_header, success, warn, info, progress

    section_header("Conformational Clustering", "🔄")
    info(f"Method: {method.upper()}  |  Frames: {traj.n_frames}")

    # ── Compute pairwise RMSD matrix ─────────────────────────────
    progress("Computing pairwise RMSD matrix (this may take a moment)...")
    ca_idx = traj.topology.select("name CA")
    n = traj.n_frames

    rmsd_matrix = np.zeros((n, n), dtype=np.float32)
    for i in range(n):
        row = md.rmsd(traj, traj[i], atom_indices=ca_idx) * 10  # nm → Å
        rmsd_matrix[i] = row

    success(f"RMSD matrix computed ({n}×{n})")

    # ── Clustering ────────────────────────────────────────────────
    if method == "hdbscan":
        labels = _hdbscan_cluster(rmsd_matrix, min_cluster_size, traj.n_frames)
    elif method == "gromos":
        labels = _gromos_cluster(rmsd_matrix, cutoff)
    elif method == "agglomerative":
        k = n_clusters or _estimate_k(rmsd_matrix)
        labels = _agglomerative_cluster(rmsd_matrix, k)
    else:
        warn(f"Unknown method '{method}'. Falling back to HDBSCAN.")
        labels = _hdbscan_cluster(rmsd_matrix, min_cluster_size, traj.n_frames)

    # ── Analyse clusters ──────────────────────────────────────────
    unique_labels = sorted(set(labels))
    n_noise = int(np.sum(np.array(labels) == -1))
    cluster_ids = [l for l in unique_labels if l != -1]
    n_clusters_found = len(cluster_ids)

    success(f"Found {n_clusters_found} conformational cluster(s)  |  Noise frames: {n_noise}")

    # Populations and centroids
    populations = {}
    centroids = {}
    centroid_files = {}

    for cid in cluster_ids:
        mask = np.array(labels) == cid
        pop = int(mask.sum())
        populations[int(cid)] = pop

        # Centroid = frame with minimum mean RMSD to all cluster members
        cluster_frames = np.where(mask)[0]
        sub_rmsd = rmsd_matrix[np.ix_(cluster_frames, cluster_frames)]
        mean_rmsd = sub_rmsd.mean(axis=1)
        centroid_local = int(np.argmin(mean_rmsd))
        centroid_frame = int(cluster_frames[centroid_local])
        centroids[int(cid)] = centroid_frame

        # Write centroid PDB
        pdb_path = output_dir / f"cluster_{cid}_centroid.pdb"
        traj[centroid_frame].save_pdb(str(pdb_path))
        centroid_files[int(cid)] = str(pdb_path)
        info(f"  Cluster {cid}: {pop} frames ({pop/traj.n_frames*100:.1f}%)  centroid=frame {centroid_frame}")

    # ── Lifetime / transition analysis ────────────────────────────
    transitions = _count_transitions(labels)
    dominant = max(populations, key=populations.get) if populations else None
    if dominant is not None:
        success(f"Dominant state: Cluster {dominant} ({populations[dominant]/traj.n_frames*100:.1f}% of trajectory)")

    return {
        "method": method,
        "n_frames": traj.n_frames,
        "labels": [int(l) for l in labels],
        "n_clusters": n_clusters_found,
        "n_noise": n_noise,
        "populations": populations,
        "centroids": centroids,
        "centroid_files": centroid_files,
        "transitions": transitions,
        "rmsd_matrix_mean": float(rmsd_matrix.mean()),
        "rmsd_matrix_max": float(rmsd_matrix.max()),
    }


def _hdbscan_cluster(rmsd_matrix: np.ndarray, min_cluster_size, n_frames: int):
    """HDBSCAN on precomputed RMSD distance matrix."""
    try:
        from hdbscan import HDBSCAN
    except ImportError:
        try:
            from sklearn.cluster import HDBSCAN
        except ImportError:
            from protkit.utils import error
            error("HDBSCAN not found. Install with: pip install hdbscan")

    if min_cluster_size is None:
        # Heuristic: ~2% of frames, min 5
        min_cluster_size = max(5, int(n_frames * 0.02))

    from protkit.utils import info
    info(f"HDBSCAN min_cluster_size={min_cluster_size}")

    clusterer = HDBSCAN(
        min_cluster_size=min_cluster_size,
        metric="precomputed",
        cluster_selection_method="eom",
    )
    labels = clusterer.fit_predict(rmsd_matrix.astype(np.float64))
    return labels.tolist()


def _gromos_cluster(rmsd_matrix: np.ndarray, cutoff: float):
    """
    GROMOS nearest-neighbour clustering.
    Iteratively picks frame with most neighbours within cutoff.
    """
    from protkit.utils import info
    info(f"GROMOS cutoff={cutoff} Å")

    n = rmsd_matrix.shape[0]
    assigned = np.full(n, -1, dtype=int)
    cluster_id = 0

    while True:
        unassigned = np.where(assigned == -1)[0]
        if len(unassigned) == 0:
            break

        # Count neighbours within cutoff for unassigned frames
        sub = rmsd_matrix[np.ix_(unassigned, unassigned)]
        neighbour_counts = (sub < cutoff).sum(axis=1)
        center_local = int(np.argmax(neighbour_counts))
        center = unassigned[center_local]

        # Assign all frames within cutoff of center
        neighbours = np.where(rmsd_matrix[center] < cutoff)[0]
        for f in neighbours:
            if assigned[f] == -1:
                assigned[f] = cluster_id
        cluster_id += 1

    return assigned.tolist()


def _agglomerative_cluster(rmsd_matrix: np.ndarray, n_clusters: int):
    """Ward agglomerative clustering on precomputed RMSD matrix."""
    from sklearn.cluster import AgglomerativeClustering
    from protkit.utils import info
    info(f"Agglomerative clustering | n_clusters={n_clusters}")
    model = AgglomerativeClustering(
        n_clusters=n_clusters,
        metric="precomputed",
        linkage="average",
    )
    labels = model.fit_predict(rmsd_matrix.astype(np.float64))
    return labels.tolist()


def _estimate_k(rmsd_matrix: np.ndarray) -> int:
    """
    Estimate k for agglomerative clustering using the elbow method
    on within-cluster RMSD vs k=2..10.
    """
    from sklearn.cluster import AgglomerativeClustering
    best_k = 3
    try:
        scores = []
        k_range = range(2, min(11, rmsd_matrix.shape[0]))
        for k in k_range:
            model = AgglomerativeClustering(n_clusters=k, metric="precomputed", linkage="average")
            labels = model.fit_predict(rmsd_matrix.astype(np.float64))
            intra = []
            for cid in set(labels):
                mask = labels == cid
                sub = rmsd_matrix[np.ix_(mask, mask)]
                if sub.shape[0] > 1:
                    intra.append(sub.mean())
            scores.append(np.mean(intra) if intra else 999)

        # Elbow: largest drop
        diffs = np.diff(scores)
        best_k = int(list(k_range)[int(np.argmin(diffs)) + 1])
    except Exception:
        pass
    return best_k


def _count_transitions(labels) -> dict:
    """Count transitions between states."""
    labels = np.array(labels)
    transitions = {}
    for i in range(len(labels) - 1):
        a, b = int(labels[i]), int(labels[i + 1])
        if a != b and a != -1 and b != -1:
            key = (min(a, b), max(a, b))
            transitions[str(key)] = transitions.get(str(key), 0) + 1
    return transitions
