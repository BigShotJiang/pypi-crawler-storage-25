"""
protkit.learn
=============
Theory content, analogies, and one-liners for every module.
Printed with --learn flag (full) or always as a one-liner.
"""

import textwrap

THEORY = {
    "qc": {
        "oneliner": "📊 Validating your simulation — checking structural stability, convergence, and physical consistency.",
        "title": "MD Quality Control — Theory & Intuition",
        "theory": """
WHAT IS MD QC?
──────────────
Before trusting any result from a molecular dynamics simulation, you must
verify that the simulation actually sampled meaningful physics — not just
numerical noise. MD QC checks key observables that should behave in
predictable ways if your simulation is well-equilibrated.

METRICS EXPLAINED:
──────────────────
• RMSD (Root Mean Square Deviation)
  Measures how far your protein has drifted from the starting structure
  over time. A rising RMSD that plateaus = your protein equilibrated.
  A continuously rising RMSD = your simulation may not have converged yet.

• RMSF (Root Mean Square Fluctuation)
  Per-residue flexibility. High RMSF = flexible/disordered region (often
  loops). Low RMSF = rigid core (often secondary structure). This is your
  protein's "motion fingerprint".

• Radius of Gyration (Rg)
  How compact is your protein? A stable Rg means your protein maintained
  its overall fold. A rising Rg = unfolding. A falling Rg = collapse.

• Hydrogen Bonds
  Tracks backbone H-bond count over time. Secondary structure is held
  together by H-bonds — stable count means stable secondary structure.

• Potential Energy
  Should plateau and fluctuate around a stable mean after equilibration.
  A drifting energy = something is wrong with your simulation setup.
""",
        "analogy": """
THE ANALOGY 🏋️
──────────────
Think of your simulation like a workout session for your protein.

RMSD is like checking if your form broke down over time — did you start
with perfect squats and end up wobbling? 

RMSF is like measuring how much each joint moves — your knees flex a lot
(loops), your spine barely moves (helices).

Rg is like measuring your overall posture — did you stay upright or did
you slouch and collapse?

Energy is your heart rate monitor — it should stabilize, not keep rising.

If all these "vitals" are stable, your protein had a good workout. ✅
"""
    },

    "cluster": {
        "oneliner": "🔄 Clustering trajectory frames — finding the dominant conformational states your protein visits.",
        "title": "Conformational Clustering — Theory & Intuition",
        "theory": """
WHAT IS CONFORMATIONAL CLUSTERING?
────────────────────────────────────
Proteins are not rigid — they constantly breathe, flex, and shift between
different 3D shapes (conformations). An MD trajectory of 10,000 frames
doesn't contain 10,000 unique states — most frames are slight variations
of a few dominant shapes. Clustering finds those dominant shapes.

WHY HDBSCAN?
────────────
Most tools use k-means (requires you to pre-specify k, the number of
clusters) or GROMOS (a greedy nearest-neighbour approach). protkit uses
HDBSCAN (Hierarchical Density-Based Spatial Clustering of Applications
with Noise):

  ✓ No need to specify number of clusters in advance
  ✓ Finds clusters of arbitrary shape in conformational space
  ✓ Explicitly labels noise frames (rare/transitional conformations)
  ✓ Scales to long trajectories efficiently
  ✓ Peer-validated for MD trajectories (Bioinformatics, Oxford, 2022)

HOW IT WORKS:
─────────────
1. All-vs-all RMSD matrix is computed (after alignment)
2. HDBSCAN finds dense regions in RMSD space = conformational clusters
3. Each frame is labelled with its cluster ID
4. A representative centroid frame is extracted per cluster
5. Population, lifetime, and transition patterns are reported
""",
        "analogy": """
THE ANALOGY 🗺️
──────────────
Imagine your protein's conformational journey is like GPS tracking a
person walking around a city all day.

They spend most of their time at 3 places: home, office, and gym. But
they also pass through random streets briefly while commuting.

k-means would force you to say "I know they visit exactly 3 places" — but
what if you didn't know that in advance?

HDBSCAN is like a smart GPS analyst who looks at the data, finds where
the person spent the MOST time (dense clusters), and marks the brief
commute routes as "noise" — without you telling it how many destinations
to look for. 🏙️
"""
    },

    "mutant": {
        "oneliner": "🧬 Scanning point mutations — predicting which changes stabilize or destabilize your protein.",
        "title": "Mutant Stability Scanner — Theory & Intuition",
        "theory": """
WHAT IS MUTANT STABILITY SCANNING?
────────────────────────────────────
A point mutation replaces one amino acid with another. Some mutations
stabilize a protein (higher melting temperature, tighter fold), others
destabilize it (unfolding, aggregation). Predicting ΔΔG (change in folding
free energy) for a mutation tells you its effect:

  ΔΔG < 0  → Stabilizing (mutation is beneficial for fold stability)
  ΔΔG > 0  → Destabilizing (mutation weakens the fold)
  ΔΔG ≈ 0  → Neutral

TWO SCORING MODES:
──────────────────
• Physics-based (default):
  Uses empirical energy terms — van der Waals packing, electrostatics,
  solvation, and torsional strain — to estimate ΔΔG. Fast, interpretable,
  no ML model needed. Based on FoldX-style scoring.

• ML-based (ESM embeddings):
  Uses Facebook's ESM-2 protein language model. The model was trained on
  250M+ protein sequences and has learned deep evolutionary constraints on
  which amino acids can tolerate substitution. Slower but captures
  context-dependent effects physics scoring misses.

UNIQUE ANGLE IN protkit:
─────────────────────────
Most tools scan mutations only on the crystal (static) structure. protkit
scans mutations on EACH conformational cluster centroid — so you see if a
mutation stabilizes state A but destabilizes state B. Critical for
allosteric proteins.
""",
        "analogy": """
THE ANALOGY 🧱
──────────────
Think of your protein as a very precise LEGO structure. Each amino acid
is a LEGO brick.

Swapping one brick (mutation) might:
  - Make the structure stronger (fits better, fills a gap) ✅
  - Weaken it (awkward shape, clashes with neighbors) ❌
  - Do nothing (same size/shape roughly) ➡️

Physics scoring is like physically measuring whether the new brick fits.
ML scoring is like asking an expert who has seen a million LEGO structures
and knows from experience which swaps work — even in tricky, context-
dependent spots that pure measurement misses. 🏗️
"""
    },

    "network": {
        "oneliner": "🕸️ Building residue contact network — mapping communication pathways and allosteric hubs.",
        "title": "Protein Residue Network Analysis — Theory & Intuition",
        "theory": """
WHAT IS A PROTEIN RESIDUE NETWORK (PRN)?
──────────────────────────────────────────
A PRN models the protein as a graph:
  • Nodes  = amino acid residues
  • Edges  = physical contacts between residues (within cutoff distance)
  • Weights = contact strength (distance or frequency across trajectory)

Once the graph is built, network theory metrics reveal how information
(mechanical stress, allosteric signals, ligand-induced changes) propagates
through the protein.

KEY METRICS:
────────────
• Degree Centrality
  How many contacts does a residue have? High degree = structural hub
  (often in the hydrophobic core, important for folding).

• Betweenness Centrality
  How often does a residue lie on the shortest path between other residues?
  High betweenness = communication bottleneck — mutating this residue will
  disrupt long-range signalling. Key for allosteric drug targeting.

• Closeness Centrality
  How quickly can a residue "communicate" with the rest of the protein?
  High closeness = globally well-connected, rapid signal propagation.

• Shortest Path (Communication Pathway)
  The most efficient route for signal transmission between two residues
  (e.g., active site → allosteric site). Useful for designing mutations
  that disrupt communication.

TWO EDGE MODES:
───────────────
• Cα cutoff (8Å): Fast, standard. Connects residues whose alpha-carbons
  are within 8 Å. Great for global topology.
• Heavy atom contacts: Detailed. Any heavy atom within 4.5 Å counts.
  Captures sidechain-specific interactions. Better for active sites.
""",
        "analogy": """
THE ANALOGY 📡
──────────────
Think of your protein as a city's telephone network.

Each residue is a telephone exchange. A wire (edge) connects two exchanges
if they're physically close enough to talk.

Degree centrality = the busiest exchange (Grand Central — everyone calls
through it).

Betweenness centrality = the exchange that, if it fails, cuts off entire
neighborhoods from each other. This is your allosteric hotspot — the
residue a drug could "jam" to disrupt the whole network.

Shortest path = the fastest phone route from the active site to the other
side of the protein. Allosteric signals travel this route. 📞
"""
    },

    "run_all": {
        "oneliner": "🚀 Running full protkit pipeline — QC → Clustering → Residue Network → Mutant Scan.",
    }
}

QUOTES = [
    "\"Proteins are the machinery of life — and you just mapped the blueprint.\" — protkit 🧬",
    "\"In the dance of atoms, the protein finds its purpose. You just watched it dance.\" — protkit 💃",
    "\"Every simulation is a conversation with physics. Today, physics answered.\" — protkit ⚛️",
    "\"The secret of life is not in the sequence, but in the fold. You're getting closer.\" — protkit 🔬",
    "\"Biology is just chemistry that got ambitious. Your analysis just caught up.\" — protkit 🧪",
    "\"The protein was folding long before we could watch. Now we can. That's everything.\" — protkit 🌀",
    "\"Science is the art of asking the right question. Today you asked a great one.\" — protkit 🎯",
    "\"Somewhere in those clusters is the answer you're looking for. Keep going.\" — protkit 🔍",
    "\"RMSD may plateau, but curiosity never should.\" — protkit 📈",
    "\"A mutation is just evolution's hypothesis. You're the experiment.\" — protkit 🧫",
    "\"Even disordered proteins know what they're doing. Mostly.\" — protkit 😅",
    "\"Nature doesn't optimize — it satisfices. Your protein is good enough, and so are you.\" — protkit 🌿",
]


def print_oneliner(module: str):
    info = THEORY.get(module, {})
    oneliner = info.get("oneliner", "")
    if oneliner:
        print(f"\n  {oneliner}\n")


def print_learn(module: str):
    info = THEORY.get(module, {})
    if not info or "title" not in info:
        print(f"  No learning content available for module: {module}")
        return

    width = 70
    border = "═" * width

    print(f"\n  ╔{border}╗")
    print(f"  ║  📚  {info['title']:<{width - 5}}║")
    print(f"  ╚{border}╝\n")

    for section in ["theory", "analogy"]:
        content = info.get(section, "")
        if content:
            for line in content.strip().split("\n"):
                print(f"  {line}")
            print()

    print(f"  {'─' * width}\n")


def get_random_quote() -> str:
    import random
    return random.choice(QUOTES)
