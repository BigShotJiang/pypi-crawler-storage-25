"""
protkit.utils
=============
Shared utility functions: trajectory loading, alignment, printing.
"""

import os
import sys
import time
import numpy as np
from pathlib import Path


# ─────────────────────────────────────────────
# TERMINAL STYLING
# ─────────────────────────────────────────────

RESET  = "\033[0m"
BOLD   = "\033[1m"
DIM    = "\033[2m"
GREEN  = "\033[92m"
CYAN   = "\033[96m"
YELLOW = "\033[93m"
RED    = "\033[91m"
MAGENTA= "\033[95m"
BLUE   = "\033[94m"

def banner():
    print(f"""
{CYAN}{BOLD}
  ██████╗ ██████╗  ██████╗ ████████╗██╗  ██╗██╗████████╗
  ██╔══██╗██╔══██╗██╔═══██╗╚══██╔══╝██║ ██╔╝██║╚══██╔══╝
  ██████╔╝██████╔╝██║   ██║   ██║   █████╔╝ ██║   ██║
  ██╔═══╝ ██╔══██╗██║   ██║   ██║   ██╔═██╗ ██║   ██║
  ██║     ██║  ██║╚██████╔╝   ██║   ██║  ██╗██║   ██║
  ╚═╝     ╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚═╝   ╚═╝
{RESET}{DIM}  Protein Dynamics Analysis Suite  |  v0.1.5{RESET}
  {DIM}────────────────────────────────────────────────{RESET}
""")


def section_header(title: str, icon: str = "▶"):
    width = 60
    print(f"\n{CYAN}{BOLD}  {icon} {title}{RESET}")
    print(f"{DIM}  {'─' * width}{RESET}")


def success(msg: str):
    print(f"  {GREEN}✔{RESET}  {msg}")


def warn(msg: str):
    print(f"  {YELLOW}⚠{RESET}  {msg}")


def error(msg: str):
    print(f"  {RED}✖{RESET}  {msg}")
    sys.exit(1)


def info(msg: str):
    print(f"  {BLUE}ℹ{RESET}  {msg}")


def progress(msg: str):
    print(f"  {MAGENTA}⟳{RESET}  {msg}")


def print_quote(quote: str):
    width = 66
    print(f"\n{DIM}  {'─' * width}")
    # word wrap the quote
    words = quote.split()
    lines, current = [], ""
    for word in words:
        if len(current) + len(word) + 1 <= width - 4:
            current += (" " if current else "") + word
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    for line in lines:
        print(f"  {line}")
    print(f"  {'─' * width}{RESET}\n")


# ─────────────────────────────────────────────
# TRAJECTORY LOADING
# ─────────────────────────────────────────────

def load_trajectory(traj_path: str, top_path: str = None, stride: int = 1):
    """
    Load a trajectory using MDTraj. Supports:
      GROMACS : .xtc, .trr, .gro
      AMBER   : .nc, .ncdf, .dcd, .crd
      PDB     : .pdb (multi-model)
      Generic : .dcd, .lammpstrj

    Parameters
    ----------
    traj_path : str  Path to trajectory file
    top_path  : str  Path to topology/reference PDB (optional for PDB traj)
    stride    : int  Load every Nth frame (default=1)

    Returns
    -------
    traj : mdtraj.Trajectory
    """
    try:
        import mdtraj as md
    except ImportError:
        error("MDTraj not found. Install with: pip install mdtraj")

    traj_path = str(traj_path)
    ext = Path(traj_path).suffix.lower()

    progress(f"Loading trajectory: {Path(traj_path).name}")

    topology_needed = ext not in [".pdb"]

    if topology_needed and top_path is None:
        error(
            f"Trajectory format '{ext}' requires a topology file.\n"
            "    Provide it with --top <file.pdb> or --top <file.gro>"
        )

    try:
        if top_path:
            traj = md.load(traj_path, top=top_path, stride=stride)
        else:
            traj = md.load(traj_path, stride=stride)
    except Exception as e:
        error(f"Failed to load trajectory: {e}")

    success(f"Loaded {traj.n_frames} frames | {traj.n_atoms} atoms | {traj.n_residues} residues")
    return traj


def select_protein(traj):
    """Select only protein atoms from trajectory."""
    try:
        import mdtraj as md
        protein_idx = traj.topology.select("protein")
        if len(protein_idx) == 0:
            warn("No protein atoms found — using all atoms.")
            return traj
        traj_protein = traj.atom_slice(protein_idx)
        info(f"Protein-only selection: {traj_protein.n_atoms} atoms, {traj_protein.n_residues} residues")
        return traj_protein
    except Exception as e:
        warn(f"Protein selection failed ({e}), using full trajectory.")
        return traj


def align_trajectory(traj, ref=None, ref_frame: int = 0, top_path: str = None):
    """
    Align trajectory to a reference.

    If ref is an mdtraj.Trajectory, align to it.
    If top_path is provided, load it as reference.
    If ref is None, align to frame `ref_frame` of the trajectory itself.
    """
    try:
        import mdtraj as md
    except ImportError:
        error("MDTraj not found.")

    ca_idx = traj.topology.select("name CA")
    if len(ca_idx) == 0:
        warn("No CA atoms found for alignment — skipping.")
        return traj

    if ref is not None:
        progress(f"Aligning trajectory to reference PDB.")
        reference = ref
    elif top_path is not None:
        try:
            progress(f"Aligning trajectory to topology file: {top_path}")
            reference = md.load(str(top_path))
            # Slice to protein only to match traj
            prot_idx = reference.topology.select("protein")
            if len(prot_idx) > 0:
                reference = reference.atom_slice(prot_idx)
        except Exception as e:
            warn(f"Could not load topology as reference ({e}), aligning to frame {ref_frame} instead.")
            reference = traj[ref_frame]
    else:
        progress(f"Aligning trajectory to frame {ref_frame} of trajectory.")
        reference = traj[ref_frame]

    try:
        traj.superpose(reference, atom_indices=ca_idx)
        success("Trajectory aligned successfully.")
    except Exception as e:
        warn(f"Alignment failed ({e}), proceeding without alignment.")

    return traj


def load_reference(ref_path: str):
    """Load a reference PDB file."""
    try:
        import mdtraj as md
        ref = md.load(str(ref_path))
        success(f"Reference PDB loaded: {Path(ref_path).name}")
        return ref
    except Exception as e:
        error(f"Failed to load reference PDB: {e}")


def get_ca_indices(traj):
    """Return Cα atom indices."""
    return traj.topology.select("name CA")


def residue_labels(traj):
    """Return list of 'RES_CHAIN_RESID' strings for all residues."""
    labels = []
    for res in traj.topology.residues:
        labels.append(f"{res.name}{res.resSeq}")
    return labels


def make_output_dir(base: str, prefix: str = "protkit_results") -> Path:
    """Create a timestamped output directory."""
    ts = time.strftime("%Y%m%d_%H%M%S")
    out = Path(base) / f"{prefix}_{ts}"
    out.mkdir(parents=True, exist_ok=True)
    return out
