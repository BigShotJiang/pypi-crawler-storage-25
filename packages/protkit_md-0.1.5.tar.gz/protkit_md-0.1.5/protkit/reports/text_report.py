"""
protkit.reports.text_report
============================
Generates a clean plain-text report and a raw JSON data file.
"""

import json
from pathlib import Path
from datetime import datetime


def generate_text_report(results: dict, output_path: Path):
    """Write a human-readable .txt report."""
    lines = _build_text(results)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def generate_json_data(results: dict, output_path: Path):
    """Write raw results as a .json file for downstream use."""
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, default=_json_safe)


def _json_safe(obj):
    """Make numpy types JSON serializable."""
    try:
        import numpy as np
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, np.bool_):
            return bool(obj)
    except ImportError:
        pass
    if hasattr(obj, "item"):
        return obj.item()
    return str(obj)


def _build_text(results: dict) -> list:
    meta    = results.get("meta", {})
    qc      = results.get("qc", {})
    cluster = results.get("cluster", {})
    mutant  = results.get("mutant", {})
    network = results.get("network", {})

    ts        = meta.get("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    traj_file = meta.get("traj_file", "N/A")
    top_file  = meta.get("top_file",  "N/A")
    n_frames  = meta.get("n_frames",  "N/A")
    n_res     = meta.get("n_residues","N/A")

    W = 72
    lines = []

    def rule(char="═"):
        lines.append(char * W)

    def title(text):
        rule()
        pad = (W - len(text) - 2) // 2
        lines.append(f"{'':>{pad}} {text} {'':>{W - pad - len(text) - 2}}")
        rule()

    def section(text, icon="▶"):
        lines.append("")
        lines.append(f"{icon}  {text}")
        lines.append("─" * W)

    def kv(key, val, indent=2):
        lines.append(f"{'':>{indent}}{key:<32}{val}")

    def blank():
        lines.append("")

    # ── HEADER ────────────────────────────────────────────────────
    title("PROTKIT — PROTEIN DYNAMICS ANALYSIS REPORT")
    blank()
    kv("Generated",   ts)
    kv("Trajectory",  traj_file)
    kv("Topology",    top_file)
    kv("Frames",      str(n_frames))
    kv("Residues",    str(n_res))
    kv("Version",     "0.1.4")

    # ── QC ────────────────────────────────────────────────────────
    if qc:
        section("MD QUALITY CONTROL", "📊")

        rmsd   = qc.get("rmsd", {})
        rmsf   = qc.get("rmsf", {})
        rg     = qc.get("rg", {})
        hbonds = qc.get("hbonds")
        conv   = qc.get("convergence", {})

        if rmsd.get("values"):
            import numpy as np
            v = rmsd["values"]
            kv("RMSD mean",   f"{sum(v)/len(v):.3f} Å")
            kv("RMSD max",    f"{max(v):.3f} Å")
            kv("RMSD final",  f"{v[-1]:.3f} Å")

        if rg.get("values"):
            v = rg["values"]
            kv("Rg mean",     f"{sum(v)/len(v):.3f} Å")
            kv("Rg std",      f"{(sum((x - sum(v)/len(v))**2 for x in v)/len(v))**0.5:.3f} Å")

        if hbonds and hbonds.get("values"):
            v = hbonds["values"]
            kv("H-bonds mean",f"{sum(v)/len(v):.1f} / frame")

        blank()
        lines.append("  CONVERGENCE ASSESSMENT")
        rmsd_ok = conv.get("rmsd_converged", False)
        rg_ok   = conv.get("rg_stable", False)
        kv("  RMSD converged", "YES ✓" if rmsd_ok else "NO — review simulation")
        kv("  Rg stable",      "YES ✓" if rg_ok   else f"NO — rel.std {conv.get('rg_rel_std_pct',0):.1f}%")
        kv("  Overall",        "PASS ✓" if (rmsd_ok and rg_ok) else "REVIEW ⚠")

        if rmsf.get("values") and rmsf.get("residues"):
            vals = rmsf["values"]
            res  = rmsf["residues"]
            pairs = sorted(zip(vals, res), reverse=True)
            blank()
            lines.append("  TOP 5 FLEXIBLE RESIDUES (RMSF)")
            for v, r in pairs[:5]:
                kv(f"    {r}", f"{v:.3f} Å")

    # ── CLUSTERING ────────────────────────────────────────────────
    if cluster:
        section("CONFORMATIONAL CLUSTERING", "🔄")

        kv("Method",         cluster.get("method","N/A").upper())
        kv("Clusters found", str(cluster.get("n_clusters", "N/A")))
        kv("Noise frames",   f"{cluster.get('n_noise',0)}  ({cluster.get('n_noise',0)/max(cluster.get('n_frames',1),1)*100:.1f}%)")
        kv("Total frames",   str(cluster.get("n_frames","N/A")))

        pops = cluster.get("populations", {})
        cents = cluster.get("centroids", {})
        if pops:
            blank()
            lines.append("  CLUSTER POPULATIONS")
            n_total = cluster.get("n_frames", 1)
            for cid, pop in sorted(pops.items()):
                bar_len = int(pop / n_total * 30)
                bar = "█" * bar_len + "░" * (30 - bar_len)
                lines.append(f"    Cluster {cid}  [{bar}]  {pop} frames ({pop/n_total*100:.1f}%)")
                if str(cid) in cents or cid in cents:
                    frame = cents.get(str(cid), cents.get(cid, "N/A"))
                    lines.append(f"             centroid = frame {frame}")

        transitions = cluster.get("transitions", {})
        if transitions:
            blank()
            lines.append("  STATE TRANSITIONS")
            for pair, count in sorted(transitions.items(), key=lambda x: -x[1])[:5]:
                lines.append(f"    {pair:<20} {count} transitions")

    # ── MUTANT ────────────────────────────────────────────────────
    if mutant:
        section("MUTANT STABILITY SCAN", "🧬")

        kv("Method",           (mutant.get("method","N/A")).upper())
        kv("Mutations input",  mutant.get("mutations_input","N/A"))
        kv("Structures scanned", str(len(mutant.get("structures_scanned",[]))))

        all_res = mutant.get("results", {})
        for struct_label, mut_results in all_res.items():
            blank()
            lines.append(f"  Structure: {struct_label}")
            lines.append(f"  {'Mutation':<14} {'ΔΔG Physics':>14} {'ΔΔG ML':>10} {'ΔΔG Consensus':>15} {'Effect':<16}")
            lines.append(f"  {'─'*70}")
            for r in mut_results:
                phys = f"{r['ddg_physics']:+.3f}" if r.get('ddg_physics') is not None else "N/A"
                ml   = f"{r['ddg_ml']:+.3f}"      if r.get('ddg_ml')      is not None else "N/A"
                cons = f"{r['ddg_consensus']:+.3f}" if r.get('ddg_consensus') is not None else "N/A"
                eff  = r.get("effect","unknown")
                icon = "▼" if eff == "stabilizing" else "▲" if eff == "destabilizing" else "●"
                lines.append(f"  {r['mutation']:<14} {phys:>14} {ml:>10} {cons:>15} {icon} {eff}")

    # ── NETWORK ───────────────────────────────────────────────────
    if network:
        section("PROTEIN RESIDUE NETWORK", "🕸️")

        kv("Edge mode",    network.get("edge_mode","N/A"))
        kv("Residues",     str(network.get("n_residues","N/A")))
        kv("Edges",        str(network.get("n_edges","N/A")))

        hubs     = network.get("hubs", [])
        rlabels  = network.get("residue_labels", [])

        if hubs:
            blank()
            lines.append("  TOP HUB RESIDUES (Betweenness Centrality)")
            lines.append(f"  {'Rank':<6} {'Residue':<12} {'Betweenness':>14} {'Degree':>10} {'Closeness':>12}")
            lines.append(f"  {'─'*56}")
            for i, h in enumerate(hubs[:10], 1):
                label = rlabels[h["node"]] if h["node"] < len(rlabels) else str(h["node"])
                lines.append(f"  {i:<6} {label:<12} {h['betweenness']:>14.4f} {h['degree']:>10.4f} {h['closeness']:>12.4f}")

        pathway = network.get("pathway")
        if pathway:
            blank()
            lines.append(f"  COMMUNICATION PATHWAY: Residue {pathway['source']} → {pathway['target']}")
            lines.append("  " + " → ".join(pathway.get("path_labels", [])))
            kv("  Path length", f"{pathway.get('path_length',0):.4f}")
            kv("  Hops",        str(pathway.get("n_hops","N/A")))

    # ── FOOTER ────────────────────────────────────────────────────
    blank()
    rule()
    lines.append("  protkit v0.1.5  |  Protein Dynamics Analysis Suite")
    lines.append(f"  Report generated: {ts}")
    rule()
    blank()

    return lines
