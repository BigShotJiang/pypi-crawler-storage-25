"""
protkit.reports.html_report
============================
Generates a fully self-contained, interactive HTML report.

Visuals:
  QC      : RMSD line, RMSF bar, Rg line, H-bond line, RMSD heatmap
  Cluster : Doughnut + population bars + frame timeline
  Mutant  : Grouped bar chart per cluster + table with tabs
  Network : D3.js force-directed graph + betweenness bar + hub table
"""

import json
from pathlib import Path
from datetime import datetime


def generate_html_report(results: dict, output_path: Path):
    html = _build_html(results)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)


def _build_html(results: dict) -> str:
    qc_data      = results.get("qc", {})
    cluster_data = results.get("cluster", {})
    mutant_data  = results.get("mutant", {})
    network_data = results.get("network", {})
    meta         = results.get("meta", {})

    timestamp  = meta.get("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    traj_file  = meta.get("traj_file",  "N/A")
    top_file   = meta.get("top_file",   "N/A")
    n_frames   = meta.get("n_frames",   "N/A")
    n_residues = meta.get("n_residues", "N/A")
    is_demo    = meta.get("demo", False)

    def _safe(obj):
        import numpy as np
        if isinstance(obj, np.integer): return int(obj)
        if isinstance(obj, np.floating): return float(obj)
        if isinstance(obj, np.ndarray): return obj.tolist()
        if isinstance(obj, np.bool_): return bool(obj)
        if hasattr(obj, "item"): return obj.item()
        raise TypeError(f"Not serializable: {type(obj)}")
    qc_json      = json.dumps(qc_data, default=_safe)
    cluster_json = json.dumps(cluster_data, default=_safe)
    mutant_json  = json.dumps(mutant_data, default=_safe)
    network_json = json.dumps(network_data, default=_safe)

    demo_banner = """
  <div style="background:linear-gradient(90deg,rgba(123,94,167,0.25),rgba(0,255,224,0.15));
              border:1px solid rgba(0,255,224,0.3);border-radius:10px;
              padding:14px 24px;margin-bottom:32px;font-family:'Space Mono',monospace;
              font-size:12px;color:#00ffe0;letter-spacing:1px;">
    🧪 DEMO MODE — synthetic 80-residue protein, 200 frames, 3 conformational states
  </div>""" if is_demo else ""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>protkit — Analysis Report</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.8.5/d3.min.js"></script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:ital,wght@0,300;0,400;0,600;1,300&display=swap');
:root{{--bg:#09090f;--bg2:#111118;--bg3:#18181f;--border:#2a2a3a;--accent:#00ffe0;--accent2:#7b5ea7;--accent3:#ff6b6b;--accent4:#ffd166;--green:#00ffa0;--text:#e8e8f0;--dim:#7878a0;--mono:'Space Mono',monospace;--sans:'DM Sans',sans-serif;--radius:12px;--glow:0 0 24px rgba(0,255,224,0.12)}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:var(--bg);color:var(--text);font-family:var(--sans);font-size:15px;line-height:1.6;min-height:100vh}}
body::before{{content:'';position:fixed;inset:0;background-image:linear-gradient(rgba(0,255,224,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(0,255,224,0.03) 1px,transparent 1px);background-size:40px 40px;pointer-events:none;z-index:0}}
.hdr{{position:relative;padding:60px 48px 48px;border-bottom:1px solid var(--border);background:linear-gradient(180deg,rgba(0,255,224,0.06) 0%,transparent 100%);overflow:hidden}}
.hdr::after{{content:'PROTKIT';position:absolute;right:-20px;top:-10px;font-family:var(--mono);font-size:160px;font-weight:700;color:rgba(0,255,224,0.03);letter-spacing:-8px;user-select:none}}
.badge{{display:inline-block;font-family:var(--mono);font-size:11px;color:var(--accent);border:1px solid var(--accent);padding:3px 10px;border-radius:20px;margin-bottom:16px;letter-spacing:2px}}
.hdr h1{{font-family:var(--mono);font-size:42px;font-weight:700;letter-spacing:-1px;line-height:1.1}}
.hdr h1 span{{color:var(--accent)}}
.hdr-sub{{margin-top:10px;color:var(--dim);font-size:15px;font-weight:300}}
.meta-grid{{display:flex;gap:32px;margin-top:32px;flex-wrap:wrap}}
.meta-item{{display:flex;flex-direction:column;gap:2px}}
.meta-label{{font-family:var(--mono);font-size:10px;color:var(--dim);letter-spacing:2px;text-transform:uppercase}}
.meta-value{{font-family:var(--mono);font-size:14px;color:var(--accent)}}
.nav{{position:sticky;top:0;z-index:100;background:rgba(9,9,15,0.95);backdrop-filter:blur(12px);border-bottom:1px solid var(--border);padding:0 48px;display:flex;gap:0;overflow-x:auto}}
.nav a{{font-family:var(--mono);font-size:12px;color:var(--dim);text-decoration:none;padding:16px 20px;letter-spacing:1px;border-bottom:2px solid transparent;transition:all 0.2s;white-space:nowrap}}
.nav a:hover{{color:var(--accent);border-bottom-color:var(--accent)}}
.container{{padding:48px;max-width:1400px;margin:0 auto;position:relative;z-index:1}}
.section{{margin-bottom:72px;scroll-margin-top:70px}}
.sec-hdr{{display:flex;align-items:center;gap:14px;margin-bottom:32px;padding-bottom:16px;border-bottom:1px solid var(--border)}}
.sec-icon{{width:42px;height:42px;background:linear-gradient(135deg,var(--accent2),var(--accent));border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}}
.sec-title{{font-family:var(--mono);font-size:22px;font-weight:700}}
.sec-desc{{font-size:13px;color:var(--dim);margin-top:2px}}
.card-grid{{display:grid;gap:20px;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));margin-bottom:28px}}
.card{{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);padding:24px;position:relative;overflow:hidden;transition:border-color 0.2s,box-shadow 0.2s}}
.card:hover{{border-color:rgba(0,255,224,0.3);box-shadow:var(--glow)}}
.card::before{{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,var(--accent),var(--accent2))}}
.card-label{{font-family:var(--mono);font-size:10px;color:var(--dim);letter-spacing:2px;text-transform:uppercase;margin-bottom:8px}}
.card-value{{font-family:var(--mono);font-size:28px;font-weight:700;color:var(--accent);line-height:1}}
.card-unit{{font-size:13px;color:var(--dim);margin-top:4px}}
.cbadge{{display:inline-block;padding:3px 10px;border-radius:20px;font-family:var(--mono);font-size:11px;margin-top:8px}}
.bg{{background:rgba(0,255,160,0.12);color:var(--green);border:1px solid rgba(0,255,160,0.3)}}
.bw{{background:rgba(255,209,102,0.12);color:var(--accent4);border:1px solid rgba(255,209,102,0.3)}}
.bb{{background:rgba(255,107,107,0.12);color:var(--accent3);border:1px solid rgba(255,107,107,0.3)}}
.chart-grid{{display:grid;gap:20px;grid-template-columns:repeat(auto-fit,minmax(460px,1fr))}}
.chart-box{{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);padding:28px}}
.chart-title{{font-family:var(--mono);font-size:11px;color:var(--dim);letter-spacing:2px;text-transform:uppercase;margin-bottom:20px}}
.tbl-box{{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;margin-top:20px}}
table{{width:100%;border-collapse:collapse}}
thead tr{{background:var(--bg3)}}
th{{font-family:var(--mono);font-size:10px;color:var(--dim);letter-spacing:2px;text-transform:uppercase;padding:14px 20px;text-align:left;border-bottom:1px solid var(--border)}}
td{{font-size:14px;padding:12px 20px;border-bottom:1px solid rgba(42,42,58,0.5)}}
tbody tr:last-child td{{border-bottom:none}}
tbody tr:hover{{background:rgba(0,255,224,0.03)}}
.mono{{font-family:var(--mono);font-size:13px}}
.stab{{color:var(--green);font-weight:600}}
.dest{{color:var(--accent3);font-weight:600}}
.neut{{color:var(--accent4)}}
.cl-row{{display:flex;align-items:center;gap:14px;margin-bottom:12px}}
.cl-label{{font-family:var(--mono);font-size:12px;color:var(--dim);width:90px;flex-shrink:0}}
.cl-bar-bg{{flex:1;height:18px;background:var(--bg3);border-radius:4px;overflow:hidden}}
.cl-bar-fill{{height:100%;border-radius:4px;transition:width 1s ease}}
.cl-pct{{font-family:var(--mono);font-size:12px;color:var(--accent);width:48px;text-align:right;flex-shrink:0}}
.timeline{{display:flex;height:32px;border-radius:6px;overflow:hidden;margin-top:12px;gap:1px}}
.tl-seg{{height:100%;display:flex;align-items:center;justify-content:center;font-family:var(--mono);font-size:10px;color:rgba(255,255,255,0.8)}}
#network-svg{{width:100%;height:480px;background:var(--bg3);border-radius:var(--radius);border:1px solid var(--border);display:block;cursor:grab}}
#network-svg:active{{cursor:grabbing}}
.node circle{{stroke-width:2;cursor:pointer}}
.node text{{font-family:'Space Mono',monospace;font-size:9px;fill:#e8e8f0;pointer-events:none}}
.link{{stroke:rgba(0,255,224,0.12);stroke-width:1px}}
.link.strong{{stroke:rgba(0,255,224,0.45);stroke-width:2px}}
.d3tip{{position:fixed;background:#18181f;border:1px solid #2a2a3a;border-radius:8px;padding:10px 14px;font-family:'Space Mono',monospace;font-size:11px;color:#e8e8f0;pointer-events:none;opacity:0;transition:opacity 0.15s;z-index:9999}}
.pathway-box{{background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius);padding:24px;margin-top:20px;font-family:var(--mono);font-size:13px;line-height:2;word-break:break-all}}
.pnode{{display:inline-block;background:rgba(0,255,224,0.1);border:1px solid rgba(0,255,224,0.3);color:var(--accent);padding:2px 10px;border-radius:6px;margin:2px}}
.parrow{{color:var(--dim);margin:0 4px}}
.tab-btn{{background:transparent;border:1px solid #2a2a3a;color:#7878a0;font-family:'Space Mono',monospace;font-size:11px;padding:8px 16px;cursor:pointer;border-radius:6px;margin:0 4px 16px 0;transition:all 0.2s}}
.tab-btn.active,.tab-btn:hover{{border-color:var(--accent);color:var(--accent)}}
.no-data{{background:var(--bg3);border:1px dashed var(--border);border-radius:var(--radius);padding:32px;text-align:center;color:var(--dim);font-family:var(--mono);font-size:13px}}
.footer{{border-top:1px solid var(--border);padding:32px 48px;display:flex;justify-content:space-between;align-items:center;color:var(--dim);font-size:12px;font-family:var(--mono);flex-wrap:wrap;gap:12px}}
.footer-brand{{color:var(--accent);font-weight:700}}
</style>
</head>
<body>
<div class="hdr">
  <div class="badge">PROTKIT · ANALYSIS REPORT</div>
  <h1>Protein Dynamics<br/><span>Analysis Suite</span></h1>
  <p class="hdr-sub">Structural Bioinformatics · MD Trajectory Analysis · Residue Network Mapping</p>
  <div class="meta-grid">
    <div class="meta-item"><span class="meta-label">Generated</span><span class="meta-value">{timestamp}</span></div>
    <div class="meta-item"><span class="meta-label">Trajectory</span><span class="meta-value">{traj_file}</span></div>
    <div class="meta-item"><span class="meta-label">Topology</span><span class="meta-value">{top_file}</span></div>
    <div class="meta-item"><span class="meta-label">Frames</span><span class="meta-value">{n_frames}</span></div>
    <div class="meta-item"><span class="meta-label">Residues</span><span class="meta-value">{n_residues}</span></div>
  </div>
</div>
<nav class="nav">
  <a href="#qc">📊 QC Dashboard</a>
  <a href="#cluster">🔄 Clustering</a>
  <a href="#mutant">🧬 Mutant Scan</a>
  <a href="#network">🕸️ Residue Network</a>
</nav>
<div class="container">
{demo_banner}
<div class="section" id="qc">
  <div class="sec-hdr"><div class="sec-icon">📊</div><div><div class="sec-title">MD Quality Control</div><div class="sec-desc">RMSD · RMSF · Radius of Gyration · Hydrogen Bonds · RMSD Heatmap · Convergence</div></div></div>
  <div id="qc-content"></div>
</div>
<div class="section" id="cluster">
  <div class="sec-hdr"><div class="sec-icon">🔄</div><div><div class="sec-title">Conformational Clustering</div><div class="sec-desc">HDBSCAN · State populations · Frame timeline · Transition analysis</div></div></div>
  <div id="cluster-content"></div>
</div>
<div class="section" id="mutant">
  <div class="sec-hdr"><div class="sec-icon">🧬</div><div><div class="sec-title">Mutant Stability Scanner</div><div class="sec-desc">ΔΔG predictions · Per-cluster grouped comparison · Physics &amp; ML scoring</div></div></div>
  <div id="mutant-content"></div>
</div>
<div class="section" id="network">
  <div class="sec-hdr"><div class="sec-icon">🕸️</div><div><div class="sec-title">Protein Residue Network</div><div class="sec-desc">D3 force-directed graph · Hub residues · Betweenness centrality · Communication pathways</div></div></div>
  <div id="network-content"></div>
</div>
</div>
<div class="d3tip" id="d3tip"></div>
<footer class="footer">
  <div><span class="footer-brand">protkit</span> · Protein Dynamics Analysis Suite · v0.1.5</div>
  <div>Generated {timestamp}</div>
</footer>
<script>
const QC={qc_json},CLUSTER={cluster_json},MUTANT={mutant_json},NETWORK={network_json};
const PAL=['#00ffe0','#7b5ea7','#ff6b6b','#ffd166','#06d6a0','#118ab2','#ef476f','#ffc43d','#1b998b','#e9c46a'];
const CC={{responsive:true,maintainAspectRatio:false,plugins:{{legend:{{labels:{{color:'#7878a0',font:{{family:'Space Mono',size:11}}}}}},tooltip:{{backgroundColor:'#18181f',borderColor:'#2a2a3a',borderWidth:1,titleColor:'#00ffe0',bodyColor:'#e8e8f0',titleFont:{{family:'Space Mono'}},bodyFont:{{family:'DM Sans'}}}}}},scales:{{x:{{ticks:{{color:'#7878a0',font:{{family:'Space Mono',size:10}}}},grid:{{color:'rgba(42,42,58,0.5)'}}}},y:{{ticks:{{color:'#7878a0',font:{{family:'Space Mono',size:10}}}},grid:{{color:'rgba(42,42,58,0.5)'}}}}}}  }};
function mg(a,b){{const o=Object.assign({{}},a);for(const k in b){{if(b[k]&&typeof b[k]==='object'&&!Array.isArray(b[k]))o[k]=mg(a[k]||{{}},b[k]);else o[k]=b[k];}}return o;}}
function nd(el,m='No data available.'){{el.innerHTML=`<div class="no-data">⚠ ${{m}}</div>`;}}
function avg(a){{return a&&a.length?a.reduce((s,v)=>s+v,0)/a.length:0;}}

function renderQC(){{
  const el=document.getElementById('qc-content');
  if(!QC||!Object.keys(QC).length){{nd(el);return;}}
  const rmsd=QC.rmsd||{{}},rmsf=QC.rmsf||{{}},rg=QC.rg||{{}},hb=QC.hbonds||{{}},cv=QC.convergence||{{}};
  const cb=ok=>ok?`<span class="cbadge bg">✓ Converged</span>`:`<span class="cbadge bw">⚠ Review</span>`;
  el.innerHTML=`
  <div class="card-grid">
    <div class="card"><div class="card-label">Mean RMSD</div><div class="card-value">${{avg(rmsd.values).toFixed(2)}}</div><div class="card-unit">Ångström</div>${{cb(cv.rmsd_converged)}}</div>
    <div class="card"><div class="card-label">Mean Rg</div><div class="card-value">${{avg(rg.values).toFixed(2)}}</div><div class="card-unit">Ångström</div>${{cb(cv.rg_stable)}}</div>
    <div class="card"><div class="card-label">Mean H-Bonds</div><div class="card-value">${{avg(hb.values).toFixed(1)}}</div><div class="card-unit">count/frame</div></div>
    <div class="card"><div class="card-label">Convergence</div><div class="card-value" style="font-size:18px">${{cv.rmsd_converged&&cv.rg_stable?'✓ PASS':'⚠ REVIEW'}}</div><div class="card-unit">Rg rel.std: ${{(cv.rg_rel_std_pct||0).toFixed(1)}}%</div></div>
  </div>
  <div class="chart-grid">
    ${{rmsd.values?`<div class="chart-box"><div class="chart-title">RMSD vs Frame (Å)</div><div style="height:220px"><canvas id="c-rmsd"></canvas></div></div>`:''}}
    ${{rg.values?`<div class="chart-box"><div class="chart-title">Radius of Gyration vs Frame (Å)</div><div style="height:220px"><canvas id="c-rg"></canvas></div></div>`:''}}
    ${{rmsf.values?`<div class="chart-box"><div class="chart-title">RMSF per Residue (Å)</div><div style="height:220px"><canvas id="c-rmsf"></canvas></div></div>`:''}}
    ${{hb.values?`<div class="chart-box"><div class="chart-title">Hydrogen Bonds vs Frame</div><div style="height:220px"><canvas id="c-hb"></canvas></div></div>`:''}}
  </div>
  ${{rmsd.values&&rmsd.values.length>1?`<div class="chart-box" style="margin-top:20px"><div class="chart-title">Pairwise RMSD Heatmap — Conformational Diversity Matrix</div><svg id="rmsd-hm" style="width:100%;height:300px;background:var(--bg3);border-radius:8px"></svg></div>`:''}}`;
  const ln=(id,lbl,data,lbs,col)=>new Chart(document.getElementById(id),mg(CC,{{type:'line',data:{{labels:lbs,datasets:[{{label:lbl,data,borderColor:col,backgroundColor:col+'18',borderWidth:1.5,pointRadius:0,fill:true,tension:0.3}}]}},options:{{plugins:{{legend:{{display:false}}}}}}}}));
  if(rmsd.values)ln('c-rmsd','RMSD',rmsd.values,rmsd.times,'#00ffe0');
  if(rg.values)ln('c-rg','Rg',rg.values,rg.times,'#7b5ea7');
  if(hb.values)ln('c-hb','H-bonds',hb.values,hb.times,'#ffd166');
  if(rmsf.values&&rmsf.residues){{
    const s=Math.ceil(rmsf.residues.length/150),rv=rmsf.values.filter((_,i)=>i%s===0),rr=rmsf.residues.filter((_,i)=>i%s===0);
    new Chart(document.getElementById('c-rmsf'),mg(CC,{{type:'bar',data:{{labels:rr,datasets:[{{label:'RMSF',data:rv,backgroundColor:rv.map(v=>v>3?'#ff6b6b88':v>1.5?'#ffd16688':'#00ffe044'),borderColor:rv.map(v=>v>3?'#ff6b6b':v>1.5?'#ffd166':'#00ffe0'),borderWidth:1}}]}},options:{{plugins:{{legend:{{display:false}}}}}}}}));
  }}
  if(rmsd.values&&rmsd.values.length>1)setTimeout(()=>drawHeatmap(rmsd.values),150);
}}

function drawHeatmap(rmsdVals){{
  const svg=document.getElementById('rmsd-hm');
  if(!svg)return;
  const maxN=60,n=rmsdVals.length,step=Math.max(1,Math.floor(n/maxN));
  const s=rmsdVals.filter((_,i)=>i%step===0),sn=s.length;
  const mat=s.map((a,i)=>s.map((b,j)=>Math.abs(a-b)));
  const mx=Math.max(...mat.flat());
  const W=svg.clientWidth||700,H=280,m={{t:16,r:16,b:36,l:36}};
  const iW=W-m.l-m.r,iH=H-m.t-m.b,cW=iW/sn,cH=iH/sn;
  svg.setAttribute('viewBox',`0 0 ${{W}} ${{H}}`);
  const ns='http://www.w3.org/2000/svg';
  svg.innerHTML='';
  const g=document.createElementNS(ns,'g');g.setAttribute('transform',`translate(${{m.l}},${{m.t)}}`);
  const cs=d3.scaleSequential(d3.interpolateInferno).domain([0,mx]);
  for(let i=0;i<sn;i++)for(let j=0;j<sn;j++){{
    const r=document.createElementNS(ns,'rect');
    r.setAttribute('x',j*cW);r.setAttribute('y',i*cH);
    r.setAttribute('width',cW+0.5);r.setAttribute('height',cH+0.5);
    r.setAttribute('fill',cs(mat[i][j]));g.appendChild(r);
  }}
  const ax=Math.ceil(sn/8);
  for(let i=0;i<sn;i+=ax){{
    const lbl=Math.round(i*step).toString();
    const tx=document.createElementNS(ns,'text');tx.setAttribute('x',i*cW+cW/2);tx.setAttribute('y',iH+13);tx.setAttribute('text-anchor','middle');tx.setAttribute('font-size','9');tx.setAttribute('fill','#7878a0');tx.setAttribute('font-family','Space Mono');tx.textContent=lbl;g.appendChild(tx);
    const ty=document.createElementNS(ns,'text');ty.setAttribute('x',-6);ty.setAttribute('y',i*cH+cH/2+3);ty.setAttribute('text-anchor','end');ty.setAttribute('font-size','9');ty.setAttribute('fill','#7878a0');ty.setAttribute('font-family','Space Mono');ty.textContent=lbl;g.appendChild(ty);
  }}
  const defs=document.createElementNS(ns,'defs'),gr=document.createElementNS(ns,'linearGradient');
  gr.setAttribute('id','hg');gr.setAttribute('x1','0');gr.setAttribute('x2','1');
  ['#000004','#3b0f70','#8c2981','#de4968','#fe9f6d','#fcfdbf'].forEach((c,i,a)=>{{const st=document.createElementNS(ns,'stop');st.setAttribute('offset',`${{(i/(a.length-1)*100).toFixed(0)}}%`);st.setAttribute('stop-color',c);gr.appendChild(st);}});
  defs.appendChild(gr);svg.appendChild(defs);
  const lr=document.createElementNS(ns,'rect');lr.setAttribute('x',iW-100);lr.setAttribute('y',iH+20);lr.setAttribute('width',100);lr.setAttribute('height',7);lr.setAttribute('fill','url(#hg)');g.appendChild(lr);
  ['0Å',mx.toFixed(1)+'Å'].forEach((t,i)=>{{const lt=document.createElementNS(ns,'text');lt.setAttribute('x',iW-100+i*100);lt.setAttribute('y',iH+34);lt.setAttribute('text-anchor',i===0?'start':'end');lt.setAttribute('font-size','8');lt.setAttribute('fill','#7878a0');lt.setAttribute('font-family','Space Mono');lt.textContent=t;g.appendChild(lt);}});
  svg.appendChild(g);
}}

function renderCluster(){{
  const el=document.getElementById('cluster-content');
  if(!CLUSTER||!Object.keys(CLUSTER).length){{nd(el);return;}}
  const nc=CLUSTER.n_clusters||0,nn=CLUSTER.n_noise||0,nf=CLUSTER.n_frames||1;
  const pops=CLUSTER.populations||{{}},lbls=CLUSTER.labels||[];
  const method=(CLUSTER.method||'hdbscan').toUpperCase();
  const colors=Object.keys(pops).map((_,i)=>PAL[i%PAL.length]);
  const bars=Object.entries(pops).map(([cid,pop],i)=>{{
    const pct=(pop/nf*100).toFixed(1);
    return `<div class="cl-row"><span class="cl-label">Cluster ${{cid}}</span><div class="cl-bar-bg"><div class="cl-bar-fill" style="width:${{pct}}%;background:${{PAL[i%PAL.length]}}"></div></div><span class="cl-pct">${{pct}}%</span></div>`;
  }}).join('');
  el.innerHTML=`
  <div class="card-grid">
    <div class="card"><div class="card-label">States Found</div><div class="card-value">${{nc}}</div><div class="card-unit">conformational clusters</div></div>
    <div class="card"><div class="card-label">Noise Frames</div><div class="card-value">${{nn}}</div><div class="card-unit">${{(nn/nf*100).toFixed(1)}}% of trajectory</div></div>
    <div class="card"><div class="card-label">Algorithm</div><div class="card-value" style="font-size:18px">${{method}}</div><div class="card-unit">clustering method</div></div>
    <div class="card"><div class="card-label">Total Frames</div><div class="card-value">${{nf}}</div><div class="card-unit">analysed</div></div>
  </div>
  <div class="chart-grid">
    <div class="chart-box"><div class="chart-title">State Populations</div><div style="height:260px"><canvas id="c-pie"></canvas></div></div>
    <div class="chart-box"><div class="chart-title">Population Breakdown</div><div style="margin-top:8px">${{bars}}</div>
      ${{lbls.length?`<div style="margin-top:20px"><div class="chart-title" style="margin-bottom:10px">Frame Assignment Timeline</div><div class="timeline" id="tl"></div></div>`:''}}
    </div>
  </div>`;
  if(Object.keys(pops).length)new Chart(document.getElementById('c-pie'),{{type:'doughnut',data:{{labels:Object.keys(pops).map(k=>`Cluster ${{k}}`),datasets:[{{data:Object.values(pops),backgroundColor:colors,borderColor:'#09090f',borderWidth:3}}]}},options:mg(CC,{{cutout:'60%',plugins:{{legend:{{position:'right',labels:{{color:'#e8e8f0',padding:16}}}}}}}})}});
  if(lbls.length){{
    const tl=document.getElementById('tl');if(!tl)return;
    const runs=[];let cur=lbls[0],cnt=1;
    for(let i=1;i<lbls.length;i++){{if(lbls[i]===cur)cnt++;else{{runs.push({{s:cur,c:cnt}});cur=lbls[i];cnt=1;}}}}
    runs.push({{s:cur,c:cnt}});
    runs.forEach(r=>{{const seg=document.createElement('div');seg.className='tl-seg';seg.style.flex=r.c;const ci=parseInt(r.s);seg.style.background=ci===-1?'#2a2a3a':PAL[ci%PAL.length];seg.style.opacity=ci===-1?0.3:0.85;if(r.c>lbls.length*0.05)seg.textContent=ci===-1?'N':ci;tl.appendChild(seg);}});
  }}
}}

function renderMutant(){{
  const el=document.getElementById('mutant-content');
  if(!MUTANT||!Object.keys(MUTANT).length){{nd(el,'No mutation scan. Run with --mutations flag.');return;}}
  const allRes=MUTANT.results||{{}},method=(MUTANT.method||'physics').toUpperCase();
  const structs=Object.keys(allRes);if(!structs.length){{nd(el);return;}}
  const first=allRes[structs[0]]||[];
  const muts=first.map(r=>r.mutation);
  const ds=structs.map((s,i)=>{{const res=allRes[s]||[];return{{label:s,data:res.map(r=>r.ddg_consensus||0),backgroundColor:PAL[i%PAL.length]+'99',borderColor:PAL[i%PAL.length],borderWidth:1,borderRadius:4}};}});
  const stab=first.filter(r=>r.effect==='stabilizing').length,dest=first.filter(r=>r.effect==='destabilizing').length,neut=first.filter(r=>r.effect==='neutral').length;
  let tbs='',tcs='';
  structs.forEach((s,i)=>{{
    const res=allRes[s]||[];
    const rows=res.map(r=>{{const ddg=r.ddg_consensus!=null?r.ddg_consensus.toFixed(3):'N/A';const ph=r.ddg_physics!=null?r.ddg_physics.toFixed(3):'—';const ml=r.ddg_ml!=null?r.ddg_ml.toFixed(3):'—';const ec=r.effect==='stabilizing'?'stab':r.effect==='destabilizing'?'dest':'neut';const ei=r.effect==='stabilizing'?'▼':r.effect==='destabilizing'?'▲':'●';return `<tr><td class="mono">${{r.mutation}}</td><td class="mono">${{r.wt}}→${{r.mut}}</td><td class="mono">${{r.resid}}</td><td class="mono">${{ph}}</td><td class="mono">${{ml}}</td><td class="mono ${{ec}}">${{ddg}}</td><td class="${{ec}}">${{ei}} ${{r.effect}}</td></tr>`;}}).join('');
    tbs+=`<button class="tab-btn${{i===0?' active':''}}" onclick="swTab('${{s}}')" id="tb-${{s}}">${{s}}</button>`;
    tcs+=`<div id="tc-${{s}}" style="display:${{i===0?'block':'none'}}"><div class="tbl-box"><table><thead><tr><th>Mutation</th><th>Change</th><th>Residue</th><th>ΔΔG Physics</th><th>ΔΔG ML</th><th>ΔΔG Consensus</th><th>Effect</th></tr></thead><tbody>${{rows}}</tbody></table></div></div>`;
  }});
  el.innerHTML=`
  <div class="card-grid">
    <div class="card"><div class="card-label">Mutations</div><div class="card-value">${{first.length}}</div><div class="card-unit">scanned</div></div>
    <div class="card"><div class="card-label">Stabilizing</div><div class="card-value" style="color:var(--green)">${{stab}}</div><div class="card-unit">ΔΔG &lt; −0.5</div></div>
    <div class="card"><div class="card-label">Destabilizing</div><div class="card-value" style="color:var(--accent3)">${{dest}}</div><div class="card-unit">ΔΔG &gt; +0.5</div></div>
    <div class="card"><div class="card-label">Method</div><div class="card-value" style="font-size:16px">${{method}}</div><div class="card-unit">scoring</div></div>
  </div>
  ${{muts.length?`<div class="chart-box" style="margin-bottom:24px"><div class="chart-title">ΔΔG per Mutation — Grouped by Conformational State</div><div style="height:260px"><canvas id="c-mutgrp"></canvas></div></div>`:''}}
  <div style="margin-bottom:8px">${{tbs}}</div>${{tcs}}`;
  window.swTab=function(id){{document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));document.querySelectorAll('[id^="tc-"]').forEach(c=>c.style.display='none');document.getElementById('tb-'+id).classList.add('active');document.getElementById('tc-'+id).style.display='block';}};
  if(muts.length){{const mutOpts={{plugins:{{legend:{{display:true,position:'top',labels:{{color:'#e8e8f0',font:{{family:'Space Mono',size:10}}}}}}}},scales:{{y:{{title:{{display:true,text:'ddG (kcal/mol)',color:'#7878a0',font:{{family:'Space Mono',size:10}}}}}}}}}};new Chart(document.getElementById('c-mutgrp'),mg(CC,{{type:'bar',data:{{labels:muts,datasets:ds}},options:mutOpts}}));}}
}}

function renderNetwork(){{
  const el=document.getElementById('network-content');
  if(!NETWORK||!Object.keys(NETWORK).length){{nd(el);return;}}
  const hubs=NETWORK.hubs||[],rl=NETWORK.residue_labels||[];
  const ne=NETWORK.n_edges||0,nr=NETWORK.n_residues||0,em=NETWORK.edge_mode||'ca_cutoff';
  const cmap=NETWORK.contact_map||[],pathway=NETWORK.pathway;
  const topHub=hubs.length>0?(rl[hubs[0].node]||hubs[0].node):'N/A';
  const topN=hubs.slice(0,15),hl=topN.map(h=>rl[h.node]||String(h.node)),hbw=topN.map(h=>h.betweenness);
  const hrows=hubs.slice(0,10).map((h,i)=>`<tr><td class="mono" style="color:var(--accent2)">#${{i+1}}</td><td class="mono" style="color:var(--accent);font-weight:700">${{rl[h.node]||h.node}}</td><td class="mono">${{h.betweenness.toFixed(4)}}</td><td class="mono">${{h.degree.toFixed(4)}}</td><td class="mono">${{h.closeness.toFixed(4)}}</td></tr>`).join('');
  const ph=pathway?`<div class="chart-box" style="margin-top:20px"><div class="chart-title">Communication Pathway: Residue ${{pathway.source}} → ${{pathway.target}}</div><div class="pathway-box">${{pathway.path_labels.map(l=>`<span class="pnode">${{l}}</span>`).join('<span class="parrow">→</span>')}}</div><div style="margin-top:10px;font-family:monospace;font-size:12px;color:#7878a0">Length: ${{pathway.path_length}} | Hops: ${{pathway.n_hops}}</div></div>`:'';
  el.innerHTML=`
  <div class="card-grid">
    <div class="card"><div class="card-label">Residue Nodes</div><div class="card-value">${{nr}}</div><div class="card-unit">in network</div></div>
    <div class="card"><div class="card-label">Contact Edges</div><div class="card-value">${{ne}}</div><div class="card-unit">persistent contacts</div></div>
    <div class="card"><div class="card-label">Edge Mode</div><div class="card-value" style="font-size:16px">${{em==='ca_cutoff'?'Cα Cutoff':'Heavy Atom'}}</div><div class="card-unit">contact definition</div></div>
    <div class="card"><div class="card-label">Top Hub</div><div class="card-value" style="font-size:22px">${{topHub}}</div><div class="card-unit">highest betweenness</div></div>
  </div>
  <div class="chart-box" style="margin-bottom:20px">
    <div class="chart-title">Force-Directed Residue Contact Network — Node size = Betweenness Centrality · Drag · Zoom</div>
    <svg id="network-svg"></svg>
    <div style="margin-top:10px;font-size:11px;color:var(--dim);font-family:var(--mono)">🟢 High betweenness &nbsp; 🔵 Medium &nbsp; ⚪ Low &nbsp; — Brighter edges = stronger contact frequency</div>
  </div>
  <div class="chart-grid" style="margin-bottom:20px">
    <div class="chart-box"><div class="chart-title">Top 15 Hub Residues — Betweenness Centrality</div><div style="height:260px"><canvas id="c-hub"></canvas></div></div>
    <div class="tbl-box" style="margin-top:0"><table><thead><tr><th>Rank</th><th>Residue</th><th>Betweenness</th><th>Degree</th><th>Closeness</th></tr></thead><tbody>${{hrows}}</tbody></table></div>
  </div>
  ${{ph}}`;
  if(topN.length)new Chart(document.getElementById('c-hub'),mg(CC,{{type:'bar',data:{{labels:hl,datasets:[{{label:'Betweenness',data:hbw,backgroundColor:hbw.map((_,i)=>PAL[i%3]+'cc'),borderColor:hbw.map((_,i)=>PAL[i%3]),borderWidth:1,borderRadius:4}}]}},options:{{plugins:{{legend:{{display:false}}}}}}}}));
  setTimeout(()=>drawD3(cmap,rl,hubs),200);
}}

function drawD3(contactMap,resLabels,hubs){{
  const svgEl=document.getElementById('network-svg');
  if(!svgEl)return;
  const W=svgEl.clientWidth||800,H=480;
  svgEl.setAttribute('viewBox',`0 0 ${{W}} ${{H}}`);
  const n=resLabels.length,THR=0.35,MAX=60;
  const bwMap={{}};hubs.forEach(h=>bwMap[h.node]=h.betweenness);
  const maxBW=Math.max(...Object.values(bwMap),0.001);
  let idxs;
  if(n<=MAX)idxs=Array.from({{length:n}},(_,i)=>i);
  else{{const rk=Array.from({{length:n}},(_,i)=>i).sort((a,b)=>(bwMap[b]||0)-(bwMap[a]||0));idxs=rk.slice(0,MAX).sort((a,b)=>a-b);}}
  const nodes=idxs.map(i=>{{const bw=bwMap[i]||0;return{{id:i,label:resLabels[i]||`R${{i}}`,bw,nb:bw/maxBW}};}});
  const links=[];
  if(contactMap.length)idxs.forEach((i,ni)=>idxs.forEach((j,nj)=>{{if(ni>=nj)return;const f=contactMap[i]&&contactMap[i][j]!=null?contactMap[i][j]:0;if(f>THR)links.push({{source:ni,target:nj,freq:f}})}}));
  d3.select(svgEl).selectAll('*').remove();
  const svg=d3.select(svgEl),g=svg.append('g');
  svg.call(d3.zoom().scaleExtent([0.2,5]).on('zoom',e=>g.attr('transform',e.transform)));
  const nr=d=>4+d.nb*14,nc=nb=>nb>0.6?'#00ffa0':nb>0.3?'#00ffe0':nb>0.1?'#7b5ea7':'#2a2a4a';
  const sim=d3.forceSimulation(nodes)
    .force('link',d3.forceLink(links).id(d=>d.id).distance(d=>35+55*(1-d.freq)).strength(0.5))
    .force('charge',d3.forceManyBody().strength(-100))
    .force('center',d3.forceCenter(W/2,H/2))
    .force('collision',d3.forceCollide().radius(d=>nr(d)+3));
  const link=g.append('g').selectAll('line').data(links).join('line').attr('class',d=>d.freq>0.7?'link strong':'link');
  const tip=document.getElementById('d3tip');
  const node=g.append('g').selectAll('g').data(nodes).join('g').attr('class','node')
    .call(d3.drag().on('start',(e,d)=>{{if(!e.active)sim.alphaTarget(0.3).restart();d.fx=d.x;d.fy=d.y;}}).on('drag',(e,d)=>{{d.fx=e.x;d.fy=e.y;}}).on('end',(e,d)=>{{if(!e.active)sim.alphaTarget(0);d.fx=null;d.fy=null;}}));
  node.append('circle').attr('r',d=>nr(d.nb)).attr('fill',d=>nc(d.nb)).attr('fill-opacity',0.85).attr('stroke',d=>d.nb>0.5?'rgba(255,255,255,0.6)':'rgba(255,255,255,0.2)')
    .on('mouseover',(e,d)=>{{tip.style.opacity=1;tip.innerHTML=`<b style="color:#00ffe0">${{d.label}}</b><br/>Betweenness: ${{d.bw.toFixed(4)}}<br/>Rank: #${{hubs.findIndex(h=>h.node===d.id)+1||'—'}}`;tip.style.left=(e.clientX+14)+'px';tip.style.top=(e.clientY-10)+'px';}})
    .on('mousemove',(e)=>{{tip.style.left=(e.clientX+14)+'px';tip.style.top=(e.clientY-10)+'px';}})
    .on('mouseout',()=>tip.style.opacity=0);
  node.filter(d=>d.nb>0.3).append('text').attr('dy','0.35em').attr('text-anchor','middle').text(d=>d.label.replace(/[A-Z]+/,'').slice(0,4));
  sim.on('tick',()=>{{link.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y).attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);node.attr('transform',d=>`translate(${{d.x}},${{d.y)}}`)}});
}}

document.addEventListener('DOMContentLoaded',()=>{{renderQC();renderCluster();renderMutant();renderNetwork();}});
</script>
</body>
</html>"""
