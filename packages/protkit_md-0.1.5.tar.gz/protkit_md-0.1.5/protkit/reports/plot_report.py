"""
protkit.reports.plot_report
============================
Saves individual publication-quality PNG plots for each analysis.

Outputs (in output_dir/plots/):
  qc_rmsd.png
  qc_rmsf.png
  qc_rg.png
  qc_hbonds.png
  cluster_populations.png
  cluster_timeline.png
  mutant_ddg.png
  network_centrality.png
"""

from pathlib import Path
import numpy as np


STYLE = {
    "bg":       "#09090f",
    "bg2":      "#111118",
    "border":   "#2a2a3a",
    "accent":   "#00ffe0",
    "accent2":  "#7b5ea7",
    "accent3":  "#ff6b6b",
    "accent4":  "#ffd166",
    "green":    "#00ffa0",
    "text":     "#e8e8f0",
    "dim":      "#7878a0",
}

PALETTE = ["#00ffe0", "#7b5ea7", "#ff6b6b", "#ffd166",
           "#06d6a0", "#118ab2", "#ef476f", "#ffc43d"]


def _setup_matplotlib():
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.ticker as ticker
        plt.rcParams.update({
            "figure.facecolor":  STYLE["bg"],
            "axes.facecolor":    STYLE["bg2"],
            "axes.edgecolor":    STYLE["border"],
            "axes.labelcolor":   STYLE["dim"],
            "axes.titlecolor":   STYLE["text"],
            "xtick.color":       STYLE["dim"],
            "ytick.color":       STYLE["dim"],
            "grid.color":        STYLE["border"],
            "grid.linewidth":    0.5,
            "text.color":        STYLE["text"],
            "font.family":       "monospace",
            "font.size":         10,
            "figure.dpi":        150,
            "savefig.dpi":       150,
            "savefig.bbox":      "tight",
            "savefig.facecolor": STYLE["bg"],
        })
        return plt
    except ImportError:
        return None


def generate_plots(results: dict, output_dir: Path) -> list:
    """
    Generate all individual PNG plots.

    Returns list of (label, path) tuples for all saved plots.
    """
    plt = _setup_matplotlib()
    if plt is None:
        from protkit.utils import warn
        warn("matplotlib not found — skipping PNG plots. Install with: pip install matplotlib")
        return []

    plots_dir = output_dir / "plots"
    plots_dir.mkdir(exist_ok=True)

    from protkit.utils import success, progress
    progress("Saving individual PNG plots...")

    saved = []

    qc      = results.get("qc", {})
    cluster = results.get("cluster", {})
    mutant  = results.get("mutant", {})
    network = results.get("network", {})

    # ── QC PLOTS ──────────────────────────────────────────────────

    if qc.get("rmsd", {}).get("values"):
        p = _plot_line(plt, qc["rmsd"]["times"], qc["rmsd"]["values"],
                       "Frame", "RMSD (Å)", "RMSD vs Frame",
                       STYLE["accent"], plots_dir / "qc_rmsd.png")
        if p: saved.append(("RMSD", p))

    if qc.get("rg", {}).get("values"):
        p = _plot_line(plt, qc["rg"]["times"], qc["rg"]["values"],
                       "Frame", "Rg (Å)", "Radius of Gyration vs Frame",
                       STYLE["accent2"], plots_dir / "qc_rg.png")
        if p: saved.append(("Radius of Gyration", p))

    if qc.get("hbonds") and qc["hbonds"].get("values"):
        p = _plot_line(plt, qc["hbonds"]["times"], qc["hbonds"]["values"],
                       "Frame", "H-Bond Count", "Hydrogen Bonds vs Frame",
                       STYLE["accent4"], plots_dir / "qc_hbonds.png")
        if p: saved.append(("Hydrogen Bonds", p))

    if qc.get("rmsf", {}).get("values"):
        p = _plot_rmsf(plt, qc["rmsf"]["residues"], qc["rmsf"]["values"],
                       plots_dir / "qc_rmsf.png")
        if p: saved.append(("RMSF", p))

    if qc.get("rmsd", {}).get("values") and len(qc["rmsd"]["values"]) > 1:
        p = _plot_rmsd_heatmap(plt, qc["rmsd"]["values"], plots_dir / "qc_rmsd_heatmap.png")
        if p: saved.append(("RMSD Heatmap", p))

    # ── CLUSTER PLOTS ──────────────────────────────────────────────

    if cluster.get("populations"):
        p = _plot_cluster_populations(plt, cluster, plots_dir / "cluster_populations.png")
        if p: saved.append(("Cluster Populations", p))

    if cluster.get("labels"):
        p = _plot_cluster_timeline(plt, cluster["labels"], plots_dir / "cluster_timeline.png")
        if p: saved.append(("Cluster Timeline", p))

    # ── MUTANT PLOTS ───────────────────────────────────────────────

    if mutant.get("results"):
        p = _plot_mutant_ddg(plt, mutant, plots_dir / "mutant_ddg.png")
        if p: saved.append(("Mutant ΔΔG", p))

    # ── NETWORK PLOTS ──────────────────────────────────────────────

    if network.get("hubs"):
        p = _plot_network_centrality(plt, network, plots_dir / "network_centrality.png")
        if p: saved.append(("Network Centrality", p))

    for label, path in saved:
        success(f"  {label} → {path}")

    success(f"Saved {len(saved)} PNG plots → {plots_dir}")
    return saved


# ── INDIVIDUAL PLOT FUNCTIONS ─────────────────────────────────────

def _plot_line(plt, x, y, xlabel, ylabel, title, color, path):
    try:
        fig, ax = plt.subplots(figsize=(10, 4))
        ax.plot(x, y, color=color, linewidth=1.2, alpha=0.9)
        ax.fill_between(x, y, alpha=0.15, color=color)
        mean_val = np.mean(y)
        ax.axhline(mean_val, color=color, linewidth=0.8, linestyle="--", alpha=0.5,
                   label=f"mean = {mean_val:.2f}")
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title(title, pad=14)
        ax.legend(framealpha=0.2, edgecolor=STYLE["border"])
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(path)
        plt.close(fig)
        return path
    except Exception as e:
        from protkit.utils import warn
        warn(f"Could not save {path.name}: {e}")
        return None


def _plot_rmsf(plt, residues, values, path):
    try:
        fig, ax = plt.subplots(figsize=(14, 4))
        vals = np.array(values)
        colors = [STYLE["accent3"] if v > 3 else
                  STYLE["accent4"] if v > 1.5 else
                  STYLE["accent"] for v in vals]

        # Downsample labels for readability
        # Ensure lengths match
        min_len = min(len(residues), len(vals))
        residues = residues[:min_len]
        vals = vals[:min_len]
        colors = colors[:min_len]
        x = np.arange(min_len)
        ax.bar(x, vals, color=colors, width=1.0, edgecolor="none")

        # Label every Nth residue
        step = max(1, min_len // 20)
        ax.set_xticks(x[::step])
        ax.set_xticklabels(residues[::step], rotation=45, ha="right", fontsize=8)

        ax.set_xlabel("Residue")
        ax.set_ylabel("RMSF (Å)")
        ax.set_title("Per-Residue RMSF — Flexibility Profile", pad=14)
        ax.axhline(np.mean(vals), color="white", linewidth=0.8,
                   linestyle="--", alpha=0.4, label=f"mean = {np.mean(vals):.2f} Å")

        # Legend for color coding
        from matplotlib.patches import Patch
        legend_els = [
            Patch(facecolor=STYLE["accent"],  label="Low (<1.5 Å)"),
            Patch(facecolor=STYLE["accent4"], label="Medium (1.5–3 Å)"),
            Patch(facecolor=STYLE["accent3"], label="High (>3 Å)"),
        ]
        ax.legend(handles=legend_els, framealpha=0.2, edgecolor=STYLE["border"])
        ax.grid(True, axis="y", alpha=0.3)
        fig.tight_layout()
        fig.savefig(path)
        plt.close(fig)
        return path
    except Exception as e:
        from protkit.utils import warn
        warn(f"Could not save {path.name}: {e}")
        return None


def _plot_rmsd_heatmap(plt, rmsd_values, path):
    try:
        # Build proxy pairwise matrix from 1D RMSD
        maxN = 80
        vals = np.array(rmsd_values)
        step = max(1, len(vals) // maxN)
        s = vals[::step]
        mat = np.abs(s[:, None] - s[None, :])

        fig, ax = plt.subplots(figsize=(7, 6))
        im = ax.imshow(mat, cmap="inferno", aspect="auto", origin="upper")
        plt.colorbar(im, ax=ax, label="RMSD proxy (Å)", fraction=0.046, pad=0.04)

        n = len(s)
        tick_pos = np.linspace(0, n - 1, min(8, n), dtype=int)
        tick_lbl = [str(int(i * step)) for i in tick_pos]
        ax.set_xticks(tick_pos); ax.set_xticklabels(tick_lbl)
        ax.set_yticks(tick_pos); ax.set_yticklabels(tick_lbl)
        ax.set_xlabel("Frame"); ax.set_ylabel("Frame")
        ax.set_title("Pairwise RMSD Heatmap — Conformational Diversity", pad=14)

        fig.tight_layout()
        fig.savefig(path)
        plt.close(fig)
        return path
    except Exception as e:
        from protkit.utils import warn
        warn(f"Could not save {path.name}: {e}")
        return None


def _plot_cluster_populations(plt, cluster, path):
    try:
        pops = cluster.get("populations", {})
        if not pops:
            return None
        n_total = cluster.get("n_frames", 1)
        labels  = [f"Cluster {k}" for k in pops.keys()]
        sizes   = list(pops.values())
        colors  = PALETTE[:len(sizes)]
        pcts    = [s / n_total * 100 for s in sizes]

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

        # Pie / donut
        wedges, texts, autotexts = ax1.pie(
            sizes, labels=labels, colors=colors,
            autopct="%1.1f%%", startangle=90,
            wedgeprops={"edgecolor": STYLE["bg"], "linewidth": 2},
        )
        for t in texts + autotexts:
            t.set_color(STYLE["text"])
        ax1.set_title("State Populations", pad=14)

        # Bar chart
        x = np.arange(len(labels))
        bars = ax2.bar(x, pcts, color=colors, edgecolor=STYLE["bg"], linewidth=1.5)
        ax2.set_xticks(x)
        ax2.set_xticklabels(labels, rotation=20, ha="right")
        ax2.set_ylabel("Population (%)")
        ax2.set_title("Population Breakdown", pad=14)
        ax2.grid(True, axis="y", alpha=0.3)
        for bar, pct in zip(bars, pcts):
            ax2.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5,
                     f"{pct:.1f}%", ha="center", va="bottom",
                     color=STYLE["text"], fontsize=9)

        fig.tight_layout()
        fig.savefig(path)
        plt.close(fig)
        return path
    except Exception as e:
        from protkit.utils import warn
        warn(f"Could not save {path.name}: {e}")
        return None


def _plot_cluster_timeline(plt, labels, path):
    try:
        labels = np.array(labels)
        n = len(labels)
        unique = sorted(set(labels))
        cluster_ids = [l for l in unique if l != -1]

        fig, ax = plt.subplots(figsize=(14, 2.5))
        for ci, cid in enumerate(cluster_ids):
            mask = labels == cid
            x = np.where(mask)[0]
            ax.scatter(x, np.ones_like(x) * 0.5, c=PALETTE[ci % len(PALETTE)],
                       s=3, label=f"Cluster {cid}", marker="|", linewidths=1.5)

        noise_mask = labels == -1
        if noise_mask.any():
            x = np.where(noise_mask)[0]
            ax.scatter(x, np.ones_like(x) * 0.5, c=STYLE["dim"],
                       s=3, label="Noise", marker="|", linewidths=1)

        ax.set_xlim(0, n)
        ax.set_ylim(0, 1)
        ax.set_xlabel("Frame")
        ax.set_yticks([])
        ax.set_title("Conformational State Assignment — Frame Timeline", pad=12)
        ax.legend(loc="upper right", framealpha=0.2, edgecolor=STYLE["border"],
                  markerscale=4, ncol=min(len(cluster_ids) + 1, 6))

        fig.tight_layout()
        fig.savefig(path)
        plt.close(fig)
        return path
    except Exception as e:
        from protkit.utils import warn
        warn(f"Could not save {path.name}: {e}")
        return None


def _plot_mutant_ddg(plt, mutant, path):
    try:
        all_res = mutant.get("results", {})
        if not all_res:
            return None

        structs = list(all_res.keys())
        first   = all_res[structs[0]]
        mut_names = [r["mutation"] for r in first]
        n_muts  = len(mut_names)
        n_structs = len(structs)

        fig, ax = plt.subplots(figsize=(max(10, n_muts * 1.5), 5))
        x = np.arange(n_muts)
        width = 0.8 / n_structs

        for si, struct in enumerate(structs):
            res = all_res[struct]
            ddgs = [r.get("ddg_consensus") or 0 for r in res]
            offset = (si - n_structs / 2 + 0.5) * width
            bars = ax.bar(x + offset, ddgs, width=width * 0.9,
                          color=PALETTE[si % len(PALETTE)],
                          edgecolor=STYLE["bg"], linewidth=1,
                          label=struct, alpha=0.85)

        ax.axhline(0, color="white", linewidth=0.8, alpha=0.4)
        ax.axhline(-0.5, color=STYLE["green"],   linewidth=0.8,
                   linestyle="--", alpha=0.5, label="Stabilizing threshold")
        ax.axhline(+0.5, color=STYLE["accent3"], linewidth=0.8,
                   linestyle="--", alpha=0.5, label="Destabilizing threshold")

        ax.set_xticks(x)
        ax.set_xticklabels(mut_names, rotation=30, ha="right")
        ax.set_ylabel("ΔΔG (kcal/mol)")
        ax.set_title("Mutant Stability Scan — ΔΔG per Mutation × Conformational State", pad=14)
        ax.legend(framealpha=0.2, edgecolor=STYLE["border"], ncol=min(n_structs + 2, 4))
        ax.grid(True, axis="y", alpha=0.3)

        fig.tight_layout()
        fig.savefig(path)
        plt.close(fig)
        return path
    except Exception as e:
        from protkit.utils import warn
        warn(f"Could not save {path.name}: {e}")
        return None


def _plot_network_centrality(plt, network, path):
    try:
        hubs   = network.get("hubs", [])
        rl     = network.get("residue_labels", [])
        if not hubs:
            return None

        top15  = hubs[:15]
        labels = [rl[h["node"]] if h["node"] < len(rl) else str(h["node"]) for h in top15]
        bw     = [h["betweenness"] for h in top15]
        deg    = [h["degree"]      for h in top15]
        clos   = [h["closeness"]   for h in top15]

        x = np.arange(len(labels))
        width = 0.26

        fig, ax = plt.subplots(figsize=(14, 5))
        ax.bar(x - width, bw,   width=width, color=PALETTE[0], label="Betweenness", alpha=0.85)
        ax.bar(x,         deg,  width=width, color=PALETTE[1], label="Degree",      alpha=0.85)
        ax.bar(x + width, clos, width=width, color=PALETTE[2], label="Closeness",   alpha=0.85)

        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=40, ha="right")
        ax.set_ylabel("Centrality Score (normalized)")
        ax.set_title("Top Hub Residues — Network Centrality Metrics", pad=14)
        ax.legend(framealpha=0.2, edgecolor=STYLE["border"])
        ax.grid(True, axis="y", alpha=0.3)

        fig.tight_layout()
        fig.savefig(path)
        plt.close(fig)
        return path
    except Exception as e:
        from protkit.utils import warn
        warn(f"Could not save {path.name}: {e}")
        return None
