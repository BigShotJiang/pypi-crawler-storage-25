"""
protkit.demo
============
Generates a synthetic protein trajectory and runs the full protkit
pipeline on it — no real data needed.

Run with:
    protkit demo
    protkit demo --open   (auto-opens HTML report in browser)
"""

import numpy as np
from pathlib import Path


def generate_synthetic_trajectory(n_frames: int = 200, n_residues: int = 80, seed: int = 42):
    """
    Generate a synthetic protein-like trajectory with:
      - 3 distinct conformational states (clusters)
      - Realistic RMSD drift and plateau
      - Per-residue flexibility variation (loops vs helices)
      - Radius of gyration fluctuation

    Returns an mdtraj.Trajectory object.
    """
    try:
        import mdtraj as md
    except ImportError:
        from protkit.utils import error
        error("MDTraj not found. Install with: pip install mdtraj")

    rng = np.random.default_rng(seed)

    # ── Build a simple linear chain topology ─────────────────────
    from mdtraj.core.topology import Topology
    from mdtraj.core import element as elem

    top = Topology()
    chain = top.add_chain()
    residue_names = (
        ["ALA"] * 20 + ["GLY"] * 5 + ["LEU"] * 15 +   # helix-like rigid
        ["SER"] * 10 + ["ASP"] * 5 + ["GLY"] * 5 +    # loop-like flexible
        ["VAL"] * 10 + ["ILE"] * 10                    # beta-like
    )[:n_residues]

    atoms = []
    for i, resname in enumerate(residue_names):
        res = top.add_residue(resname, chain, resSeq=i + 1)
        atom = top.add_atom("CA", elem.carbon, res)
        atoms.append(atom)

    # ── Generate 3 conformational states ─────────────────────────
    # State 0: compact  (Rg ~ 14 Å)
    # State 1: extended (Rg ~ 17 Å)
    # State 2: intermediate with loop movement

    def make_helix_coords(n, radius=5.0, rise=1.5, noise=0.2):
        t = np.linspace(0, 4 * np.pi, n)
        x = radius * np.cos(t)
        y = radius * np.sin(t)
        z = rise * t
        coords = np.stack([x, y, z], axis=1)
        return coords + rng.normal(0, noise, coords.shape)

    base0 = make_helix_coords(n_residues, radius=4.5, rise=1.4)
    base1 = make_helix_coords(n_residues, radius=6.0, rise=1.8)
    base2 = make_helix_coords(n_residues, radius=5.0, rise=1.6)
    # Loop region (residues 35-50) has extra displacement in state 2
    base2[35:50] += rng.normal(0, 1.5, base2[35:50].shape)

    # ── Assign frames to states ───────────────────────────────────
    # 0-79: state 0, 80-149: state 1, 150-199: state 2
    state_assignments = (
        [0] * 80 + [1] * 70 + [2] * 50
    )

    # ── Per-residue flexibility (RMSF profile) ────────────────────
    # Loops are flexible, helices are rigid
    flex = np.ones(n_residues) * 0.3
    flex[20:25] = 1.2   # loop 1
    flex[35:50] = 1.8   # loop 2 (most flexible)
    flex[55:60] = 1.0   # loop 3

    # ── Build xyz frames ──────────────────────────────────────────
    xyz = np.zeros((n_frames, n_residues, 3), dtype=np.float32)

    for fi, state in enumerate(state_assignments):
        base = [base0, base1, base2][state]
        # Per-residue thermal noise scaled by flexibility
        noise = rng.normal(0, 1, (n_residues, 3)) * flex[:, None] * 0.1
        # Slow drift over time within each state
        drift_scale = (fi % 80) / 80 * 0.3
        drift = rng.normal(0, drift_scale, (n_residues, 3)) * 0.05
        xyz[fi] = (base + noise + drift) * 0.1  # Å → nm

    traj = md.Trajectory(xyz, top)
    return traj


def make_demo_pdb(traj, output_path: Path):
    """Save frame 0 as reference PDB."""
    traj[0].save_pdb(str(output_path))


def run_demo(output_dir: Path, open_browser: bool = False, quiet: bool = False):
    """
    Run the full protkit pipeline on synthetic demo data.
    """
    from protkit.utils import (banner, section_header, success, info,
                                progress, make_output_dir, select_protein,
                                align_trajectory, print_quote)
    from protkit.learn import print_oneliner, get_random_quote
    from protkit.modules.qc import run_qc
    from protkit.modules.cluster import run_cluster
    from protkit.modules.mutant import run_mutant
    from protkit.modules.network import run_network
    from protkit.reports import generate_html_report, generate_text_report, generate_json_data
    from datetime import datetime

    if not quiet:
        banner()

    print_oneliner("run_all")

    section_header("Demo Mode — Generating Synthetic Trajectory", "🧪")
    info("No real data needed! protkit will generate a synthetic 80-residue protein")
    info("with 200 frames and 3 conformational states for demonstration.")

    progress("Generating synthetic trajectory (80 residues, 200 frames, 3 states)...")
    traj = generate_synthetic_trajectory(n_frames=200, n_residues=80)
    success(f"Synthetic trajectory ready: {traj.n_frames} frames | {traj.n_residues} residues")

    out_dir = make_output_dir(str(output_dir), "protkit_demo")

    # Save reference PDB
    ref_pdb = out_dir / "demo_reference.pdb"
    make_demo_pdb(traj, ref_pdb)
    success(f"Reference PDB → {ref_pdb}")

    # Align to frame 0
    traj = align_trajectory(traj, ref=None, ref_frame=0)

    meta = {
        "timestamp":  datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "traj_file":  "synthetic_demo (generated)",
        "top_file":   str(ref_pdb),
        "n_frames":   traj.n_frames,
        "n_residues": traj.n_residues,
        "stride":     1,
        "demo":       True,
    }

    # QC
    section_header("STEP 1 / 4 — Quality Control", "🔬")
    results_qc = run_qc(traj, out_dir)

    # Clustering
    section_header("STEP 2 / 4 — Conformational Clustering", "🔬")
    results_cl = run_cluster(traj, out_dir, method="hdbscan")

    # Network
    section_header("STEP 3 / 4 — Residue Network", "🔬")
    results_nw = run_network(
        traj, out_dir,
        edge_mode="ca_cutoff",
        source_resid=1,
        target_resid=70,
    )

    # Mutant scan on demo mutations
    section_header("STEP 4 / 4 — Mutant Stability Scan", "🔬")
    demo_mutations = "A1G,L21V,S41P,V71I,G25A"
    centroid_files = results_cl.get("centroid_files", {})
    results_mu = run_mutant(
        pdb_path=str(ref_pdb),
        mutations=demo_mutations,
        output_dir=out_dir,
        method="physics",
        cluster_centroids=centroid_files if centroid_files else None,
    )

    results = {
        "meta": meta,
        "qc": results_qc,
        "cluster": results_cl,
        "mutant": results_mu,
        "network": results_nw,
    }

    # Write all reports
    section_header("Writing Reports", "📝")

    json_path  = out_dir / "protkit_data.json"
    txt_path   = out_dir / "protkit_report.txt"
    html_path  = out_dir / "protkit_report.html"

    generate_json_data(results, json_path)
    success(f"Raw data    → {json_path}")
    generate_text_report(results, txt_path)
    success(f"Text report → {txt_path}")
    generate_html_report(results, html_path)
    success(f"HTML report → {html_path}")

    from protkit.utils import CYAN, BOLD, RESET, DIM
    print(f"\n{CYAN}{BOLD}  ✨ Demo complete!{RESET}")
    print(f"{DIM}  Output directory: {out_dir}{RESET}")
    print(f"\n  Open the HTML report in your browser:")
    print(f"  {CYAN}{html_path}{RESET}\n")

    if open_browser:
        import webbrowser
        webbrowser.open(f"file://{html_path.resolve()}")
        success("Opened HTML report in browser!")

    print_quote(get_random_quote())
    return results
