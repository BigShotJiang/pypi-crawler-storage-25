# ASGT Engine

ASGT Engine is a CPU-native, zero-float research engine for integer-only text retrieval and multimodal medical-style retrieval.

Version `1.1.0` combines:

- ASGT text RAG over elliptic-curve semantic lattices on `GF(65537)`
- FFSC vision encoding over `GF(786433)` using 2D NTT, Kloosterman coefficients, and algebraic Zernike coefficients over `GF(p^2)`
- Hecke-style fusion of text and image fingerprints
- Binary save/load for trained symbolic knowledge entries
- A native `pybind11` Python extension named `asgt_engine`

All core similarity and encoding operations use integer arithmetic. No neural network, floating-point vector embedding, or GPU dependency is required by the engine.

## Install

```bash
pip install asgt-engine
```

For local development:

```bash
python -m pip install build twine pybind11
python -m build
```

## Quick Start

```python
import numpy as np
import asgt_engine

engine = asgt_engine.ASGTEngine()

engine.train_text_batch([
    "The heart pumps blood through the circulatory system",
    "DNA carries genetic instructions for life",
    "Pneumonia may appear as opacity on chest xray",
])

print(engine.retrieve("What pumps blood?", top_k=1)[0].text)

image = np.zeros((256, 256), dtype=np.uint8)
image[96:160, 96:160] = 240

engine.train_vision_batch(
    [image],
    ["Chest xray pattern with focal bright opacity"],
)

matches = engine.retrieve_multimodal(image, top_k=1)
print(matches[0].text)

engine.save_model("medical_symbolic.asgt")
```

## API

```python
engine = asgt_engine.ASGTEngine(a=7, b=13, p=65537)
```

Text methods:

- `train_text_batch(texts)`
- `train_batch(texts)`
- `train_step(text)`
- `retrieve(query, top_k=3)`
- `generate(prompt, max_tokens=1)`

Vision and multimodal methods:

- `train_vision_batch(images, texts)`
- `retrieve_multimodal(image_pixels, top_k=3)`

Persistence:

- `save_model(path)`
- `load_model(path)`

Stats:

- `vocab_size`
- `num_facts`
- `num_entries`
- `train_steps`

## Image Input

`train_vision_batch` and `retrieve_multimodal` accept each image as either:

- a flat list of `65536` integer pixels
- a nested `256 x 256` list
- a NumPy `uint8` array with shape `(256, 256)`
- a NumPy `uint8` array with shape `(65536,)`

Image loading and resizing stay in Python. The C++ engine receives only raw grayscale pixels.

## Medical Safety

ASGT Engine is a research and retrieval engine. It is not a medical device and does not provide diagnosis. Production medical SaaS deployments must add clinical validation, data governance, access control, audit logging, PHI protections, and clinician-facing safety review.

## License

MIT

