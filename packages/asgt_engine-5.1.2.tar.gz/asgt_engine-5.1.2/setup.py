import platform
from setuptools import Extension, setup
import pybind11


if platform.system() == "Windows":
    extra_compile_args = ["/O2", "/std:c++17", "/EHsc", "/DNDEBUG"]
else:
    extra_compile_args = ["-O3", "-std=c++17", "-march=native", "-fPIC", "-DNDEBUG"]


ext_modules = [
    Extension(
        "asgt_engine",
        sources=["src/wrapper.cpp"],
        include_dirs=[pybind11.get_include(), "src"],
        language="c++",
        extra_compile_args=extra_compile_args,
    )
]


setup(
    name="asgt-engine",
    version="5.1.2",
    author="Alhdrawi",
    description="ASGT Engine - zero-float algebraic tensor vision with native archive loading",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    ext_modules=ext_modules,
    python_requires=">=3.8",
)
