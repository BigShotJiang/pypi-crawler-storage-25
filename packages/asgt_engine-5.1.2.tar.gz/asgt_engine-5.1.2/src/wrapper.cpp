// ============================================================================
// ASGT Engine pybind11 wrapper
// ============================================================================
#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "asgt_core.hpp"
#include "deep_network.hpp"
#include "universal_vision.hpp"
#include "vision_classifier.hpp"

namespace py = pybind11;

static std::vector<uint8_t> parse_image(const py::object &obj) {
    constexpr size_t N = ffsc::N;
    constexpr size_t PIXELS = ffsc::PIXELS;
    std::vector<uint8_t> out(PIXELS);

    if (py::isinstance<py::array>(obj)) {
        py::array arr = py::cast<py::array>(obj);
        py::buffer_info info = arr.request();

        if (info.ndim == 1 && static_cast<size_t>(info.shape[0]) == PIXELS) {
            for (size_t i = 0; i < PIXELS; ++i) {
                out[i] = static_cast<uint8_t>(*static_cast<unsigned char*>(
                    static_cast<void*>(static_cast<char*>(info.ptr) + i * info.strides[0])));
            }
            return out;
        }

        if (info.ndim == 2 &&
            static_cast<size_t>(info.shape[0]) == N &&
            static_cast<size_t>(info.shape[1]) == N) {
            for (size_t y = 0; y < N; ++y) {
                for (size_t x = 0; x < N; ++x) {
                    char *base = static_cast<char*>(info.ptr);
                    out[y * N + x] = static_cast<uint8_t>(
                        *reinterpret_cast<unsigned char*>(base + y * info.strides[0] +
                                                          x * info.strides[1]));
                }
            }
            return out;
        }
        throw std::runtime_error("NumPy image must be uint8 256x256 or flat 65536");
    }

    py::sequence seq = py::cast<py::sequence>(obj);
    if (seq.size() == PIXELS) {
        for (size_t i = 0; i < PIXELS; ++i)
            out[i] = static_cast<uint8_t>(py::cast<int>(seq[i]) & 255);
        return out;
    }

    if (seq.size() == N) {
        for (size_t y = 0; y < N; ++y) {
            py::sequence row = py::cast<py::sequence>(seq[y]);
            if (row.size() != N) throw std::runtime_error("Each image row must have 256 pixels");
            for (size_t x = 0; x < N; ++x)
                out[y * N + x] = static_cast<uint8_t>(py::cast<int>(row[x]) & 255);
        }
        return out;
    }

    throw std::runtime_error("Image must be uint8 256x256 or flat 65536");
}

static std::vector<std::vector<uint8_t>> parse_images(const std::vector<py::object> &images) {
    std::vector<std::vector<uint8_t>> out;
    out.reserve(images.size());
    for (const auto &img : images) out.push_back(parse_image(img));
    return out;
}

static u64 dict_u64(const py::dict &d, const char *key, u64 fallback) {
    if (!d.contains(key)) return fallback;
    return py::cast<u64>(d[py::str(key)]);
}

static FFSCConfig config_from_dict(const py::dict &d) {
    FFSCConfig c;
    c.target_width = dict_u64(d, "target_width", c.target_width);
    c.target_height = dict_u64(d, "target_height", c.target_height);
    c.p = dict_u64(d, "p", c.p);
    c.g = dict_u64(d, "g", c.g);
    c.top_k = dict_u64(d, "top_k", c.top_k);
    c.kloosterman_dim = dict_u64(d, "kloosterman_dim", c.kloosterman_dim);
    c.zernike_orders = dict_u64(d, "zernike_orders", c.zernike_orders);
    c.centroid_momentum_num = dict_u64(d, "centroid_momentum_num", c.centroid_momentum_num);
    c.centroid_momentum_den = dict_u64(d, "centroid_momentum_den", c.centroid_momentum_den);
    c.num_threads = dict_u64(d, "num_threads", c.num_threads);
    c.num_deep_layers = dict_u64(d, "num_deep_layers", c.num_deep_layers);
    return c;
}

static asgt_v5::VisionConfig vision_config_from_dict(const py::dict &d) {
    asgt_v5::VisionConfig c;
    c.target_width = dict_u64(d, "target_width", c.target_width);
    c.target_height = dict_u64(d, "target_height", c.target_height);
    c.p = dict_u64(d, "p", c.p);
    c.g = dict_u64(d, "g", c.g);
    c.top_k = dict_u64(d, "top_k", c.top_k);
    c.num_threads = dict_u64(d, "num_threads", c.num_threads);
    c.feature_dim = dict_u64(d, "feature_dim", c.feature_dim);
    c.num_layers = dict_u64(d, "num_layers", c.num_layers);
    c.num_channels = dict_u64(d, "num_channels", c.num_channels);
    c.max_tensor_cells = dict_u64(d, "max_tensor_cells", c.max_tensor_cells);
    c.centroid_momentum_num = dict_u64(d, "centroid_momentum_num", c.centroid_momentum_num);
    c.centroid_momentum_den = dict_u64(d, "centroid_momentum_den", c.centroid_momentum_den);
    return c;
}

static py::dict v2_result_dict(const V2ClassResult &r) {
    py::dict out;
    out["predicted_class"] = r.predicted_class;
    out["confidence"] = r.confidence;
    out["distance"] = r.distance;
    return out;
}

static py::dict deep_result_dict(const ffsc_v3::DeepClassResult &r) {
    py::dict out;
    out["predicted_class"] = r.predicted_class;
    out["confidence"] = r.confidence;
    out["distance"] = r.distance;
    return out;
}

static py::dict vision_result_dict(const asgt_v5::VisionClassResult &r) {
    py::dict out;
    out["predicted_class"] = r.predicted_class;
    out["confidence"] = r.confidence;
    out["distance"] = r.distance;
    return out;
}

static py::dict metrics_dict(const asgt_v5::MetricsSummary &m) {
    py::dict out;
    out["labels"] = m.labels;
    out["confusion"] = m.confusion;
    out["total"] = m.total;
    out["correct"] = m.correct;
    out["accuracy_ppm"] = m.accuracy_ppm;
    out["macro_precision_ppm"] = m.macro_precision_ppm;
    out["macro_recall_ppm"] = m.macro_recall_ppm;
    out["macro_f1_ppm"] = m.macro_f1_ppm;
    out["micro_precision_ppm"] = m.micro_precision_ppm;
    out["micro_recall_ppm"] = m.micro_recall_ppm;
    out["micro_f1_ppm"] = m.micro_f1_ppm;
    return out;
}

static py::dict kfold_dict(const asgt_v5::KFoldResult &r) {
    py::dict out;
    py::list folds;
    for (const auto &m : r.folds) folds.append(metrics_dict(m));
    out["folds"] = folds;
    out["aggregate"] = metrics_dict(r.aggregate);
    return out;
}

static asgt_v5::UniversalImage parse_universal_image(
    const py::object &obj,
    u64 width,
    u64 height) {
    const size_t w = static_cast<size_t>(width);
    const size_t h = static_cast<size_t>(height);
    py::array_t<uint8_t, py::array::c_style | py::array::forcecast> arr(obj);
    py::buffer_info info = arr.request();
    if (info.ndim != 2 && info.ndim != 3)
        throw std::runtime_error("V5 image array must be HxW or HxWxC");
    if (static_cast<size_t>(info.shape[0]) != h || static_cast<size_t>(info.shape[1]) != w)
        throw std::runtime_error("V5 image array shape does not match engine dimensions");

    const size_t channels = info.ndim == 3 ? static_cast<size_t>(info.shape[2]) : 1;
    if (channels == 0 || channels > 4)
        throw std::runtime_error("V5 image channels must be 1, 2, 3, or 4");

    asgt_v5::UniversalImage img;
    img.width = width;
    img.height = height;
    img.channels = static_cast<u64>(channels);
    u64 spatial = 0, total = 0;
    if (!asgt_v5::checked_mul_u64(width, height, spatial) ||
        !asgt_v5::checked_mul_u64(spatial, static_cast<u64>(channels), total)) {
        throw std::runtime_error("V5 image array size overflow");
    }
    img.pixels.resize(static_cast<size_t>(total));
    const uint8_t *base = static_cast<const uint8_t*>(info.ptr);
    std::copy(base, base + img.pixels.size(), img.pixels.begin());
    return img;
}

static std::unordered_map<std::string, std::string> parse_metadata_dict(const py::dict &metadata) {
    std::unordered_map<std::string, std::string> out;
    for (const auto &item : metadata) {
        const std::string key = py::cast<std::string>(py::str(item.first));
        if (py::isinstance<py::dict>(item.second)) {
            py::dict value = py::reinterpret_borrow<py::dict>(item.second);
            if (value.contains("label")) {
                out[key] = py::cast<std::string>(py::str(value[py::str("label")]));
            } else if (value.contains("class")) {
                out[key] = py::cast<std::string>(py::str(value[py::str("class")]));
            }
        } else {
            out[key] = py::cast<std::string>(py::str(item.second));
        }
    }
    return out;
}

static std::vector<std::vector<u64>> parse_soft_target_matrix(const py::object &matrix, u64 p) {
    std::vector<std::vector<u64>> out;
    if (py::isinstance<py::array>(matrix)) {
        py::array arr = py::cast<py::array>(matrix);
        py::buffer_info info = arr.request();
        if (info.ndim != 2) throw std::runtime_error("soft_target_matrix must be rank-2");
        const size_t rows = static_cast<size_t>(info.shape[0]);
        const size_t cols = static_cast<size_t>(info.shape[1]);
        if (info.format == py::format_descriptor<u64>::format()) {
            py::array_t<u64, py::array::c_style | py::array::forcecast> fast(matrix);
            py::buffer_info fast_info = fast.request();
            const u64 *data = static_cast<const u64*>(fast_info.ptr);
            out.assign(rows, std::vector<u64>(cols, 0));
            for (size_t i = 0; i < rows; ++i) {
                for (size_t j = 0; j < cols; ++j) {
                    out[i][j] = data[i * cols + j] % p;
                    if (out[i][j] == 0) out[i][j] = 1;
                }
            }
            return out;
        }
        out.assign(rows, std::vector<u64>(cols, 0));
        for (size_t i = 0; i < rows; ++i) {
            for (size_t j = 0; j < cols; ++j) {
                py::object value = arr.attr("__getitem__")(py::make_tuple(i, j));
                out[i][j] = asgt_v5::SAKDEngine::soft_target_to_bound(
                    py::cast<std::string>(py::str(value)),
                    p);
            }
        }
        return out;
    }

    py::sequence rows = py::cast<py::sequence>(matrix);
    out.reserve(static_cast<size_t>(rows.size()));
    for (py::ssize_t i = 0; i < rows.size(); ++i) {
        py::sequence row = py::cast<py::sequence>(rows[i]);
        std::vector<u64> parsed;
        parsed.reserve(static_cast<size_t>(row.size()));
        for (py::ssize_t j = 0; j < row.size(); ++j) {
            parsed.push_back(asgt_v5::SAKDEngine::soft_target_to_bound(
                py::cast<std::string>(py::str(row[j])),
                p));
        }
        out.push_back(std::move(parsed));
    }
    return out;
}

static std::vector<uint8_t> parse_dynamic_pixels(const py::object &obj, u64 width, u64 height) {
    const size_t w = static_cast<size_t>(width);
    const size_t h = static_cast<size_t>(height);
    const size_t pixels = w * h;
    std::vector<uint8_t> out(pixels);

    if (py::isinstance<py::array>(obj)) {
        py::array arr = py::cast<py::array>(obj);
        py::buffer_info info = arr.request();

        if (info.ndim == 1 && static_cast<size_t>(info.shape[0]) == pixels) {
            char *base = static_cast<char*>(info.ptr);
            for (size_t i = 0; i < pixels; ++i) {
                out[i] = static_cast<uint8_t>(
                    *reinterpret_cast<unsigned char*>(base + i * info.strides[0]));
            }
            return out;
        }

        if (info.ndim == 2 &&
            static_cast<size_t>(info.shape[0]) == h &&
            static_cast<size_t>(info.shape[1]) == w) {
            char *base = static_cast<char*>(info.ptr);
            for (size_t y = 0; y < h; ++y) {
                for (size_t x = 0; x < w; ++x) {
                    out[y * w + x] = static_cast<uint8_t>(
                        *reinterpret_cast<unsigned char*>(base + y * info.strides[0] +
                                                          x * info.strides[1]));
                }
            }
            return out;
        }
        throw std::runtime_error("NumPy image shape does not match ASGTEngineV2 config");
    }

    py::sequence seq = py::cast<py::sequence>(obj);
    if (seq.size() == pixels) {
        for (size_t i = 0; i < pixels; ++i)
            out[i] = static_cast<uint8_t>(py::cast<int>(seq[i]) & 255);
        return out;
    }

    if (seq.size() == h) {
        for (size_t y = 0; y < h; ++y) {
            py::sequence row = py::cast<py::sequence>(seq[y]);
            if (row.size() != w) throw std::runtime_error("Image row width does not match ASGTEngineV2 config");
            for (size_t x = 0; x < w; ++x)
                out[y * w + x] = static_cast<uint8_t>(py::cast<int>(row[x]) & 255);
        }
        return out;
    }

    throw std::runtime_error("Image pixels do not match ASGTEngineV2 configured dimensions");
}

static std::vector<u64> parse_dynamic_latents(const py::object &obj, u64 width, u64 height) {
    const size_t w = static_cast<size_t>(width);
    const size_t h = static_cast<size_t>(height);
    const size_t cells = w * h;
    std::vector<u64> out(cells);

    if (py::isinstance<py::array>(obj)) {
        py::array_t<u64, py::array::c_style | py::array::forcecast> arr(obj);
        py::buffer_info info = arr.request();
        const u64 *data = static_cast<const u64*>(info.ptr);

        if (info.ndim == 1 && static_cast<size_t>(info.shape[0]) == cells) {
            std::copy(data, data + cells, out.begin());
            return out;
        }

        if (info.ndim == 2 &&
            static_cast<size_t>(info.shape[0]) == h &&
            static_cast<size_t>(info.shape[1]) == w) {
            std::copy(data, data + cells, out.begin());
            return out;
        }
        throw std::runtime_error("Latents array shape does not match ASGTEngineV3 config");
    }

    py::sequence seq = py::cast<py::sequence>(obj);
    if (seq.size() == cells) {
        for (size_t i = 0; i < cells; ++i) out[i] = py::cast<u64>(seq[i]);
        return out;
    }

    if (seq.size() == h) {
        for (size_t y = 0; y < h; ++y) {
            py::sequence row = py::cast<py::sequence>(seq[y]);
            if (row.size() != w) throw std::runtime_error("Latent row width does not match ASGTEngineV3 config");
            for (size_t x = 0; x < w; ++x) out[y * w + x] = py::cast<u64>(row[x]);
        }
        return out;
    }

    throw std::runtime_error("Latents do not match ASGTEngineV3 configured dimensions");
}

static py::array_t<u64> latents_to_numpy(const std::vector<u64> &latents, u64 width, u64 height) {
    py::array_t<u64> arr({static_cast<py::ssize_t>(height), static_cast<py::ssize_t>(width)});
    py::buffer_info info = arr.request();
    std::copy(latents.begin(), latents.end(), static_cast<u64*>(info.ptr));
    return arr;
}

PYBIND11_MODULE(asgt_engine, m) {
    m.doc() = "ASGT Engine - zero-float text RAG, FFSC vision, and V5.1 algebraic tensor vision";

    py::class_<SearchResult>(m, "SearchResult")
        .def_readonly("index", &SearchResult::index)
        .def_readonly("similarity", &SearchResult::similarity)
        .def_readonly("text", &SearchResult::text)
        .def("__repr__", [](const SearchResult &r) {
            return "<SearchResult index=" + std::to_string(r.index) +
                   " similarity=" + std::to_string(r.similarity) +
                   " text='" + r.text.substr(0, 48) + "...'>";
        });

    py::class_<ASGTEngine>(m, "ASGTEngine")
        .def(py::init<u64, u64, u64>(),
             py::arg("a") = 7, py::arg("b") = 13, py::arg("p") = 65537)

        .def("train_step", &ASGTEngine::train_step, py::arg("text"))
        .def("train_batch", &ASGTEngine::train_batch, py::arg("texts"))
        .def("train_text_batch", &ASGTEngine::train_text_batch, py::arg("texts"))

        .def("train_vision_batch",
             [](ASGTEngine &engine, const std::vector<py::object> &images,
                const std::vector<std::string> &texts) {
                 engine.train_vision_batch(parse_images(images), texts);
             },
             py::arg("images"), py::arg("texts"))

        .def("retrieve", &ASGTEngine::retrieve,
             py::arg("query"), py::arg("top_k") = 3)

        .def("retrieve_multimodal",
             [](ASGTEngine &engine, const py::object &image, size_t top_k) {
                 return engine.retrieve_multimodal(parse_image(image), top_k);
             },
             py::arg("image_pixels"), py::arg("top_k") = 3)

        .def("generate", &ASGTEngine::generate,
             py::arg("prompt"), py::arg("max_tokens") = 1)

        .def("save_model", &ASGTEngine::save_model, py::arg("path"))
        .def("load_model", &ASGTEngine::load_model, py::arg("path"))

        .def_property_readonly("vocab_size", &ASGTEngine::vocab_size)
        .def_property_readonly("num_facts", &ASGTEngine::num_facts)
        .def_property_readonly("num_entries", &ASGTEngine::num_entries)
        .def_property_readonly("train_steps", &ASGTEngine::get_train_steps)

        .def("__repr__", [](const ASGTEngine &e) {
            return "<ASGTEngine v1.1.0 entries=" + std::to_string(e.num_entries()) +
                   " vocab=" + std::to_string(e.vocab_size()) + ">";
        });

    py::class_<V2ClassResult>(m, "V2ClassResult")
        .def_readonly("predicted_class", &V2ClassResult::predicted_class)
        .def_readonly("confidence", &V2ClassResult::confidence)
        .def_readonly("distance", &V2ClassResult::distance)
        .def("__repr__", [](const V2ClassResult &r) {
            return "<V2ClassResult predicted_class='" + r.predicted_class +
                   "' confidence=" + std::to_string(r.confidence) +
                   " distance=" + std::to_string(r.distance) + ">";
        });

    py::class_<ASGTEngineV2>(m, "ASGTEngineV2")
        .def(py::init([](py::dict config) {
                 return ASGTEngineV2(config_from_dict(config));
             }),
             py::arg("config") = py::dict())

        .def("train_native_batch",
             [](ASGTEngineV2 &engine,
                const std::vector<std::string> &image_paths,
                const std::vector<std::string> &class_labels,
                py::object sample_weights) {
                 std::vector<u64> weights;
                 if (!sample_weights.is_none()) weights = py::cast<std::vector<u64>>(sample_weights);
                 return engine.train_native_batch(image_paths, class_labels, weights);
             },
             py::arg("image_paths"),
             py::arg("class_labels"),
             py::arg("sample_weights") = py::none())

        .def("classify",
             [](const ASGTEngineV2 &engine, const std::string &image_path) {
                 return v2_result_dict(engine.classify(image_path));
             },
             py::arg("image_path"))

        .def("classify_pixels",
             [](const ASGTEngineV2 &engine, const py::object &pixels) {
                 auto parsed = parse_dynamic_pixels(pixels, engine.target_width(), engine.target_height());
                 return v2_result_dict(engine.classify_pixels(parsed));
             },
             py::arg("pixels_array"))

        .def("save_weights", &ASGTEngineV2::save_weights, py::arg("path"))
        .def("load_weights", &ASGTEngineV2::load_weights, py::arg("path"))
        .def("class_labels", &ASGTEngineV2::class_labels)

        .def_property_readonly("num_classes", &ASGTEngineV2::num_classes)
        .def_property_readonly("num_samples", &ASGTEngineV2::num_samples)
        .def_property_readonly("target_width", &ASGTEngineV2::target_width)
        .def_property_readonly("target_height", &ASGTEngineV2::target_height)
        .def_property_readonly("prime", &ASGTEngineV2::prime)

        .def("__repr__", [](const ASGTEngineV2 &e) {
            return "<ASGTEngineV2 classes=" + std::to_string(e.num_classes()) +
                   " samples=" + std::to_string(e.num_samples()) +
                   " size=" + std::to_string(e.target_width()) + "x" +
                   std::to_string(e.target_height()) + ">";
        });

    py::class_<ASGTEngineV3>(m, "ASGTEngineV3")
        .def(py::init([](py::dict config) {
                 return ASGTEngineV3(config_from_dict(config));
             }),
             py::arg("config") = py::dict())

        .def("get_spectral_latents",
             [](const ASGTEngineV3 &engine, const std::string &image_path) {
                 return latents_to_numpy(engine.get_spectral_latents(image_path),
                                         engine.target_width(), engine.target_height());
             },
             py::arg("image_path"))

        .def("decode_latents_to_image",
             [](const ASGTEngineV3 &engine, const py::object &latents, const std::string &output_path) {
                 auto parsed = parse_dynamic_latents(latents, engine.target_width(), engine.target_height());
                 return engine.decode_latents_to_image(parsed, output_path);
             },
             py::arg("latents_array"), py::arg("output_path"))

        .def("get_deep_latents",
             [](const ASGTEngineV3 &engine, const std::string &image_path) {
                 return latents_to_numpy(engine.get_deep_latents(image_path),
                                         engine.target_width(), engine.target_height());
             },
             py::arg("image_path"))

        .def("train_deep_native_batch",
             [](ASGTEngineV3 &engine,
                const std::vector<std::string> &image_paths,
                const std::vector<std::string> &class_labels,
                py::object sample_weights) {
                 std::vector<u64> weights;
                 if (!sample_weights.is_none()) weights = py::cast<std::vector<u64>>(sample_weights);
                 return engine.train_deep_native_batch(image_paths, class_labels, weights);
             },
             py::arg("image_paths"),
             py::arg("class_labels"),
             py::arg("sample_weights") = py::none())

        .def("generate_overlay",
             &ASGTEngineV3::generate_overlay,
             py::arg("image_path"), py::arg("target_label"), py::arg("output_path"))

        .def("classify_deep",
             [](const ASGTEngineV3 &engine, const std::string &image_path) {
                 return deep_result_dict(engine.classify_deep(image_path));
             },
             py::arg("image_path"))

        .def("save_deep_weights", &ASGTEngineV3::save_deep_weights, py::arg("path"))
        .def("load_deep_weights", &ASGTEngineV3::load_deep_weights, py::arg("path"))
        .def("class_labels", &ASGTEngineV3::class_labels)

        .def("test_autoencoder_loop",
             &ASGTEngineV3::test_autoencoder_loop,
             py::arg("image_path"), py::arg("output_path"))

        .def_property_readonly("target_width", &ASGTEngineV3::target_width)
        .def_property_readonly("target_height", &ASGTEngineV3::target_height)
        .def_property_readonly("prime", &ASGTEngineV3::prime)
        .def_property_readonly("num_deep_layers", &ASGTEngineV3::num_deep_layers)
        .def_property_readonly("num_profiles", &ASGTEngineV3::num_profiles)

        .def("__repr__", [](const ASGTEngineV3 &e) {
            return "<ASGTEngineV3 rc1 size=" + std::to_string(e.target_width()) + "x" +
                   std::to_string(e.target_height()) +
                   " prime=" + std::to_string(e.prime()) +
                   " deep_layers=" + std::to_string(e.num_deep_layers()) +
                   " profiles=" + std::to_string(e.num_profiles()) + ">";
        });

    py::class_<asgt_v5::ASGTVisionEngine>(m, "ASGTVisionEngine")
        .def(py::init([](py::dict config) {
                 return asgt_v5::ASGTVisionEngine(vision_config_from_dict(config));
             }),
             py::arg("config") = py::dict())

        .def("extract_features",
             [](const asgt_v5::ASGTVisionEngine &engine, const std::string &image_path) {
                 return engine.extract_features(image_path);
             },
             py::arg("image_path"))

        .def("extract_features_array",
             [](const asgt_v5::ASGTVisionEngine &engine, const py::object &image) {
                 auto parsed = parse_universal_image(image, engine.target_width(), engine.target_height());
                 return engine.extract_features_image(parsed);
             },
             py::arg("image_array"))

        .def("train_paths",
             [](asgt_v5::ASGTVisionEngine &engine,
                const std::vector<std::string> &image_paths,
                const std::vector<std::string> &class_labels,
                py::object sample_weights) {
                 std::vector<u64> weights;
                 if (!sample_weights.is_none()) weights = py::cast<std::vector<u64>>(sample_weights);
                 return engine.train_paths(image_paths, class_labels, weights);
             },
             py::arg("image_paths"),
             py::arg("class_labels"),
             py::arg("sample_weights") = py::none())

        .def("train_folder",
             &asgt_v5::ASGTVisionEngine::train_folder,
             py::arg("root_dir"))

        .def("train_mmap_archive",
             [](asgt_v5::ASGTVisionEngine &engine,
                const std::string &archive_path,
                py::dict metadata_dict) {
                 return engine.train_mmap_archive(archive_path, parse_metadata_dict(metadata_dict));
             },
             py::arg("archive_path"),
             py::arg("metadata_dict"))

        .def("train_distilled_batch",
             [](asgt_v5::ASGTVisionEngine &engine,
                const std::vector<std::string> &image_paths,
                const py::object &soft_target_matrix,
                const std::vector<std::string> &hard_labels,
                py::object sample_weights) {
                 std::vector<u64> weights;
                 if (!sample_weights.is_none()) weights = py::cast<std::vector<u64>>(sample_weights);
                 auto soft_bounds = parse_soft_target_matrix(soft_target_matrix, engine.prime());
                 return engine.train_distilled_batch(image_paths, soft_bounds, hard_labels, weights);
             },
             py::arg("image_paths"),
             py::arg("soft_target_matrix"),
             py::arg("hard_labels"),
             py::arg("sample_weights") = py::none())

        .def("classify",
             [](const asgt_v5::ASGTVisionEngine &engine, const std::string &image_path) {
                 return vision_result_dict(engine.classify(image_path));
             },
             py::arg("image_path"))

        .def("classify_array",
             [](const asgt_v5::ASGTVisionEngine &engine, const py::object &image) {
                 auto parsed = parse_universal_image(image, engine.target_width(), engine.target_height());
                 return vision_result_dict(engine.classify_image(parsed));
             },
             py::arg("image_array"))

        .def("evaluate_paths",
             [](const asgt_v5::ASGTVisionEngine &engine,
                const std::vector<std::string> &image_paths,
                const std::vector<std::string> &class_labels) {
                 return metrics_dict(engine.evaluate_paths(image_paths, class_labels));
             },
             py::arg("image_paths"), py::arg("class_labels"))

        .def("stratified_kfold",
             [](const asgt_v5::ASGTVisionEngine &engine,
                const std::vector<std::string> &image_paths,
                const std::vector<std::string> &class_labels,
                u64 k) {
                 return kfold_dict(engine.stratified_kfold(image_paths, class_labels, k));
             },
             py::arg("image_paths"), py::arg("class_labels"), py::arg("k") = 5)

        .def("segment_to_mask",
             &asgt_v5::ASGTVisionEngine::segment_to_mask,
             py::arg("image_path"),
             py::arg("target_label"),
             py::arg("output_path"),
             py::arg("multiclass") = false)

        .def("save_weights",
             &asgt_v5::ASGTVisionEngine::save_weights,
             py::arg("file_path"))

        .def("load_weights",
             &asgt_v5::ASGTVisionEngine::load_weights,
             py::arg("file_path"))

        .def("class_labels", &asgt_v5::ASGTVisionEngine::class_labels)

        .def_property_readonly("num_classes", &asgt_v5::ASGTVisionEngine::num_classes)
        .def_property_readonly("target_width", &asgt_v5::ASGTVisionEngine::target_width)
        .def_property_readonly("target_height", &asgt_v5::ASGTVisionEngine::target_height)
        .def_property_readonly("prime", &asgt_v5::ASGTVisionEngine::prime)
        .def_property_readonly("num_channels", &asgt_v5::ASGTVisionEngine::num_channels)
        .def_property_readonly("num_blocks", &asgt_v5::ASGTVisionEngine::num_blocks)

        .def("__repr__", [](const asgt_v5::ASGTVisionEngine &e) {
            return "<ASGTVisionEngine v5.1 size=" + std::to_string(e.target_width()) + "x" +
                   std::to_string(e.target_height()) +
                   " prime=" + std::to_string(e.prime()) +
                   " channels=" + std::to_string(e.num_channels()) +
                   " classes=" + std::to_string(e.num_classes()) +
                   " blocks=" + std::to_string(e.num_blocks()) + ">";
        });
}
