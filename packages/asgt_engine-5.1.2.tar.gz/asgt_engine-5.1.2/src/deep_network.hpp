// ============================================================================
// ASGT Engine V3 RC1 - Deep Hensel Feature Network
// Local algebraic receptive fields, modular inverse activation, and overlays.
// ============================================================================
#pragma once

#include "decoder.hpp"

#include <future>
#include <limits>
#include <mutex>
#include <thread>

namespace ffsc_v3 {

inline u64 label_hash(const std::string &label, u64 p) {
    u64 h = 1469598103934665603ull % p;
    for (unsigned char c : label) {
        h = GF::mul(GF::add(h, c + 1, p), 1099511628211ull % p, p);
    }
    return h == 0 ? 1 : h;
}

inline u64 fast_mod_inverse(u64 n, u64 p) {
    n %= p;
    if (n == 0) return 0;
    return GF::power(n, p - 2, p);
}

inline u64 hensel_lift_residue(u64 coeff, u64 residue, u64 layer, u64 p) {
    const u64 base = GF::add(residue % p, layer + 1, p);
    const u64 lifted = GF::mul(base, base, p);
    return GF::add(coeff, lifted, p);
}

struct ProductionAlgebraicLayer {
    u64 kernel_size = 3;
    u64 stride = 1;
    u64 p = 786433;
    std::vector<u64> poly_weights;

    ProductionAlgebraicLayer() = default;
    ProductionAlgebraicLayer(u64 k_size, u64 strd, u64 prime, u64 layer_index)
        : kernel_size(k_size), stride(std::max<u64>(1, strd)), p(prime) {
        poly_weights.resize(static_cast<size_t>(kernel_size * kernel_size), 1);
        for (size_t i = 0; i < poly_weights.size(); ++i) {
            poly_weights[i] = ((static_cast<u64>(i + 1) * 7) + 13 + layer_index * 31) % p;
            if (poly_weights[i] == 0) poly_weights[i] = 1;
        }
    }

    std::vector<u64> forward(const std::vector<u64> &input_map, u64 width, u64 height) const {
        if (input_map.size() != static_cast<size_t>(width * height))
            throw std::runtime_error("deep layer input dimension mismatch");

        std::vector<u64> output(input_map.size(), 0);
        const u64 radius = kernel_size / 2;
        for (u64 y = 0; y < height; ++y) {
            for (u64 x = 0; x < width; ++x) {
                u64 acc = 0;
                for (u64 ky = 0; ky < kernel_size; ++ky) {
                    for (u64 kx = 0; kx < kernel_size; ++kx) {
                        const u64 sx = (x + width + (kx * stride) - radius) % width;
                        const u64 sy = (y + height + (ky * stride) - radius) % height;
                        const u64 pixel = input_map[static_cast<size_t>(sy * width + sx)] % p;
                        const u64 weight = poly_weights[static_cast<size_t>(ky * kernel_size + kx)] % p;
                        acc = GF::add(acc, GF::mul(pixel, weight, p), p);
                    }
                }
                output[static_cast<size_t>(y * width + x)] = fast_mod_inverse(acc, p);
            }
        }
        return output;
    }

    void hensel_residual_update(const std::vector<u64> &input_map, u64 residual, u64 layer_index) {
        if (input_map.empty()) return;
        const size_t stride_sample = std::max<size_t>(1, input_map.size() / poly_weights.size());
        for (size_t i = 0; i < poly_weights.size(); ++i) {
            const u64 sample = input_map[(i * stride_sample) % input_map.size()] % p;
            const u64 lifted = hensel_lift_residue(poly_weights[i], GF::mul(residual, sample, p), layer_index, p);
            poly_weights[i] = lifted == 0 ? 1 : lifted;
        }
    }
};

struct DeepLabelProfile {
    std::string label;
    std::vector<u64> spectrum;
    u64 samples = 0;
    u64 weight_sum = 0;
};

struct DeepClassResult {
    std::string predicted_class;
    u64 confidence = 0;
    u64 distance = 0;
};

class DeepHenselFeatureNetwork {
public:
    explicit DeepHenselFeatureNetwork(const FFSCConfig &cfg)
        : cfg_(cfg), decoder_(cfg) {
        const u64 n = cfg_.num_deep_layers == 0 ? 1 : cfg_.num_deep_layers;
        layers_.reserve(static_cast<size_t>(n));
        for (u64 i = 0; i < n; ++i) {
            const u64 kernel = i == 0 ? 5 : 3;
            const u64 stride = i == 0 ? 2 : 1;
            layers_.emplace_back(kernel, stride, cfg_.p, i);
        }
    }

    std::vector<u64> extract_deep_latents(const std::string &image_path) const {
        std::vector<uint8_t> pixels = ffsc_v2::load_and_preprocess(image_path, cfg_);
        if (pixels.empty()) throw std::runtime_error("failed to load image for deep algebraic encoding");
        std::vector<u64> map(pixels.size());
        for (size_t i = 0; i < pixels.size(); ++i) map[i] = static_cast<u64>(pixels[i]) % cfg_.p;
        apply_layers(map);
        return map;
    }

    std::vector<std::string> train_deep_native_batch(
        const std::vector<std::string> &image_paths,
        const std::vector<std::string> &class_labels,
        const std::vector<u64> &sample_weights) {
        if (image_paths.size() != class_labels.size())
            throw std::runtime_error("image_paths and class_labels must have equal length");
        if (!sample_weights.empty() && sample_weights.size() != image_paths.size())
            throw std::runtime_error("sample_weights must be empty or match image_paths length");

        const u64 n = static_cast<u64>(image_paths.size());
        const u64 threads = resolved_threads();
        const u64 chunk = (n + threads - 1) / threads;
        std::vector<std::future<std::vector<size_t>>> futures;
        std::vector<std::vector<u64>> features(image_paths.size());
        std::vector<std::string> skipped;
        std::mutex skipped_mutex;

        for (u64 t = 0; t < threads; ++t) {
            const u64 begin = t * chunk;
            const u64 end = std::min<u64>(n, begin + chunk);
            if (begin >= end) continue;
            futures.push_back(std::async(std::launch::async, [&, begin, end]() {
                std::vector<size_t> valid;
                valid.reserve(static_cast<size_t>(end - begin));
                for (u64 i = begin; i < end; ++i) {
                    try {
                        features[static_cast<size_t>(i)] =
                            extract_deep_latents(image_paths[static_cast<size_t>(i)]);
                        valid.push_back(static_cast<size_t>(i));
                    } catch (...) {
                        std::lock_guard<std::mutex> lock(skipped_mutex);
                        skipped.push_back(image_paths[static_cast<size_t>(i)]);
                    }
                }
                return valid;
            }));
        }

        for (auto &f : futures) {
            for (size_t i : f.get()) {
                const u64 weight = sample_weights.empty() ? 1 : std::max<u64>(1, sample_weights[i]);
                update_profile(class_labels[i], features[i], weight);
                update_layers_hensel(class_labels[i], features[i], weight);
            }
        }
        return skipped;
    }

    bool generate_pathology_overlay(
        const std::string &image_path,
        const std::string &target_label,
        const std::string &output_path) const {
        auto it = profiles_.find(target_label);
        if (it == profiles_.end() || it->second.spectrum.empty())
            throw std::runtime_error("target_label has no trained deep algebraic profile");

        std::vector<u64> deep = extract_deep_latents(image_path);
        const std::vector<u64> &profile = it->second.spectrum;
        if (deep.size() != profile.size()) throw std::runtime_error("profile dimension mismatch");

        std::vector<u64> overlay(deep.size());
        for (size_t i = 0; i < deep.size(); ++i) {
            const u64 a = deep[i] % cfg_.p;
            const u64 b = profile[i] % cfg_.p;
            const u64 delta = a >= b ? a - b : b - a;
            overlay[i] = GF::mul(delta, label_hash(target_label, cfg_.p), cfg_.p);
        }
        return decoder_.decode_latents_to_image(overlay, output_path);
    }

    ffsc_v3::DeepClassResult classify_deep(const std::string &image_path) const {
        if (profiles_.empty()) return {"", 0, cfg_.p};
        std::vector<u64> feature = extract_deep_latents(image_path);
        DeepClassResult best{"", 0, std::numeric_limits<u64>::max()};
        for (const auto &kv : profiles_) {
            const DeepLabelProfile &profile = kv.second;
            if (profile.spectrum.size() != feature.size()) continue;
            const u64 dist = profile_distance(feature, profile.spectrum);
            if (best.predicted_class.empty() || dist < best.distance) {
                best.predicted_class = profile.label;
                best.distance = dist;
                best.confidence = distance_to_confidence(dist);
            }
        }
        if (best.predicted_class.empty()) return {"", 0, cfg_.p};
        return best;
    }

    bool save_deep_weights(const std::string &path) const {
        std::ofstream f(path, std::ios::binary);
        if (!f) return false;
        const char magic[8] = {'A','S','G','T','V','3','R','1'};
        f.write(magic, 8);
        write_config(f);
        ffsc_v2::write_u64(f, static_cast<u64>(layers_.size()));
        for (const auto &layer : layers_) {
            ffsc_v2::write_u64(f, layer.kernel_size);
            ffsc_v2::write_u64(f, layer.stride);
            ffsc_v2::write_u64(f, static_cast<u64>(layer.poly_weights.size()));
            for (u64 w : layer.poly_weights) ffsc_v2::write_u64(f, w);
        }
        ffsc_v2::write_u64(f, static_cast<u64>(profiles_.size()));
        for (const auto &kv : profiles_) {
            const DeepLabelProfile &profile = kv.second;
            ffsc_v2::write_str(f, profile.label);
            ffsc_v2::write_u64(f, profile.samples);
            ffsc_v2::write_u64(f, profile.weight_sum);
            ffsc_v2::write_u64(f, static_cast<u64>(profile.spectrum.size()));
            for (u64 v : profile.spectrum) ffsc_v2::write_u64(f, v);
        }
        return true;
    }

    bool load_deep_weights(const std::string &path) {
        std::ifstream f(path, std::ios::binary);
        if (!f) return false;
        char magic[8];
        f.read(magic, 8);
        if (std::string(magic, 8) != "ASGTV3R1") return false;
        FFSCConfig loaded = read_config(f);
        if (loaded.target_width != cfg_.target_width || loaded.target_height != cfg_.target_height ||
            loaded.p != cfg_.p || loaded.g != cfg_.g || loaded.num_deep_layers != cfg_.num_deep_layers)
            throw std::runtime_error("deep weight config does not match engine config");

        layers_.clear();
        u64 layer_count = ffsc_v2::read_u64(f);
        layers_.resize(static_cast<size_t>(layer_count));
        for (auto &layer : layers_) {
            layer.kernel_size = ffsc_v2::read_u64(f);
            layer.stride = ffsc_v2::read_u64(f);
            layer.p = cfg_.p;
            u64 weight_count = ffsc_v2::read_u64(f);
            layer.poly_weights.resize(static_cast<size_t>(weight_count));
            for (u64 &w : layer.poly_weights) w = ffsc_v2::read_u64(f);
        }

        profiles_.clear();
        u64 profile_count = ffsc_v2::read_u64(f);
        for (u64 i = 0; i < profile_count; ++i) {
            DeepLabelProfile profile;
            profile.label = ffsc_v2::read_str(f);
            profile.samples = ffsc_v2::read_u64(f);
            profile.weight_sum = ffsc_v2::read_u64(f);
            u64 dim = ffsc_v2::read_u64(f);
            profile.spectrum.resize(static_cast<size_t>(dim));
            for (u64 &v : profile.spectrum) v = ffsc_v2::read_u64(f);
            profiles_[profile.label] = std::move(profile);
        }
        return true;
    }

    std::vector<std::string> class_labels() const {
        std::vector<std::string> labels;
        labels.reserve(profiles_.size());
        for (const auto &kv : profiles_) labels.push_back(kv.first);
        std::sort(labels.begin(), labels.end());
        return labels;
    }

    size_t num_deep_layers() const { return layers_.size(); }
    size_t num_profiles() const { return profiles_.size(); }

private:
    FFSCConfig cfg_;
    InverseDiffractionDecoder decoder_;
    std::vector<ProductionAlgebraicLayer> layers_;
    std::unordered_map<std::string, DeepLabelProfile> profiles_;

    u64 resolved_threads() const {
        if (cfg_.num_threads > 0) return cfg_.num_threads;
        u64 hw = static_cast<u64>(std::thread::hardware_concurrency());
        return std::max<u64>(1, hw == 0 ? 2 : hw);
    }

    void apply_layers(std::vector<u64> &latents) const {
        for (const auto &layer : layers_)
            latents = layer.forward(latents, cfg_.target_width, cfg_.target_height);
    }

    void update_profile(const std::string &label, const std::vector<u64> &feature, u64 weight) {
        DeepLabelProfile &profile = profiles_[label];
        if (profile.label.empty()) profile.label = label;
        if (profile.spectrum.empty()) profile.spectrum.assign(feature.size(), 0);
        const u64 old_w = profile.weight_sum == 0 ? 0 : profile.weight_sum % cfg_.p;
        const u64 new_w = weight % cfg_.p;
        const u64 den = GF::add(old_w, new_w, cfg_.p);
        const u64 inv_den = den == 0 ? 1 : mod_inverse(den, cfg_.p);
        for (size_t i = 0; i < feature.size(); ++i) {
            const u64 old_part = GF::mul(profile.spectrum[i], old_w, cfg_.p);
            const u64 new_part = GF::mul(feature[i] % cfg_.p, new_w, cfg_.p);
            profile.spectrum[i] = GF::mul(GF::add(old_part, new_part, cfg_.p), inv_den, cfg_.p);
        }
        profile.samples += 1;
        profile.weight_sum += weight;
    }

    void update_layers_hensel(const std::string &label, const std::vector<u64> &feature, u64 weight) {
        u64 residue = label_hash(label, cfg_.p);
        const size_t stride = std::max<size_t>(1, feature.size() / 257);
        for (size_t i = 0; i < feature.size(); i += stride) {
            residue = GF::add(GF::mul(residue, 31337, cfg_.p), feature[i] % cfg_.p, cfg_.p);
        }
        residue = GF::mul(residue, weight % cfg_.p, cfg_.p);
        for (size_t i = layers_.size(); i > 0; --i) {
            const size_t idx = i - 1;
            layers_[idx].hensel_residual_update(feature, residue, static_cast<u64>(idx));
            residue = GF::mul(GF::add(residue, 13 + static_cast<u64>(idx), cfg_.p), 17, cfg_.p);
        }
    }

    u64 profile_distance(const std::vector<u64> &a, const std::vector<u64> &b) const {
        u64 acc = 0;
        for (size_t i = 0; i < a.size(); ++i) {
            const u64 av = a[i] % cfg_.p;
            const u64 bv = b[i] % cfg_.p;
            const u64 d = av >= bv ? av - bv : bv - av;
            acc += d;
        }
        return acc / std::max<u64>(1, static_cast<u64>(a.size()));
    }

    u64 distance_to_confidence(u64 distance) const {
        if (distance >= cfg_.p) return 1;
        return cfg_.p - distance;
    }

    void write_config(std::ofstream &f) const {
        ffsc_v2::write_u64(f, cfg_.target_width);
        ffsc_v2::write_u64(f, cfg_.target_height);
        ffsc_v2::write_u64(f, cfg_.p);
        ffsc_v2::write_u64(f, cfg_.g);
        ffsc_v2::write_u64(f, cfg_.top_k);
        ffsc_v2::write_u64(f, cfg_.kloosterman_dim);
        ffsc_v2::write_u64(f, cfg_.zernike_orders);
        ffsc_v2::write_u64(f, cfg_.centroid_momentum_num);
        ffsc_v2::write_u64(f, cfg_.centroid_momentum_den);
        ffsc_v2::write_u64(f, cfg_.num_threads);
        ffsc_v2::write_u64(f, cfg_.num_deep_layers);
    }

    static FFSCConfig read_config(std::ifstream &f) {
        FFSCConfig c;
        c.target_width = ffsc_v2::read_u64(f);
        c.target_height = ffsc_v2::read_u64(f);
        c.p = ffsc_v2::read_u64(f);
        c.g = ffsc_v2::read_u64(f);
        c.top_k = ffsc_v2::read_u64(f);
        c.kloosterman_dim = ffsc_v2::read_u64(f);
        c.zernike_orders = ffsc_v2::read_u64(f);
        c.centroid_momentum_num = ffsc_v2::read_u64(f);
        c.centroid_momentum_den = ffsc_v2::read_u64(f);
        c.num_threads = ffsc_v2::read_u64(f);
        c.num_deep_layers = ffsc_v2::read_u64(f);
        return c;
    }
};

} // namespace ffsc_v3

class ASGTEngineV3 {
public:
    explicit ASGTEngineV3(const FFSCConfig &config)
        : cfg_(config), decoder_(config), deep_(config) {}

    std::vector<u64> get_spectral_latents(const std::string &image_path) const {
        return decoder_.get_spectral_latents(image_path);
    }

    std::vector<u64> get_deep_latents(const std::string &image_path) const {
        return deep_.extract_deep_latents(image_path);
    }

    bool decode_latents_to_image(const std::vector<u64> &latents, const std::string &output_path) const {
        return decoder_.decode_latents_to_image(latents, output_path);
    }

    bool test_autoencoder_loop(const std::string &image_path, const std::string &output_path) const {
        return decoder_.test_autoencoder_loop(image_path, output_path);
    }

    std::vector<std::string> train_deep_native_batch(
        const std::vector<std::string> &image_paths,
        const std::vector<std::string> &class_labels,
        const std::vector<u64> &sample_weights) {
        return deep_.train_deep_native_batch(image_paths, class_labels, sample_weights);
    }

    bool generate_overlay(
        const std::string &image_path,
        const std::string &target_label,
        const std::string &output_path) const {
        return deep_.generate_pathology_overlay(image_path, target_label, output_path);
    }

    ffsc_v3::DeepClassResult classify_deep(const std::string &image_path) const {
        return deep_.classify_deep(image_path);
    }

    bool save_deep_weights(const std::string &path) const {
        return deep_.save_deep_weights(path);
    }

    bool load_deep_weights(const std::string &path) {
        return deep_.load_deep_weights(path);
    }

    std::vector<std::string> class_labels() const {
        return deep_.class_labels();
    }

    u64 target_width() const { return cfg_.target_width; }
    u64 target_height() const { return cfg_.target_height; }
    u64 prime() const { return cfg_.p; }
    size_t num_deep_layers() const { return deep_.num_deep_layers(); }
    size_t num_profiles() const { return deep_.num_profiles(); }

private:
    FFSCConfig cfg_;
    ffsc_v3::InverseDiffractionDecoder decoder_;
    ffsc_v3::DeepHenselFeatureNetwork deep_;
};
