// ============================================================================
// ASGT Engine V3 Alpha - Inverse Diffraction Decoder
// Integer-only 2D INTT reconstruction over GF(p), native image export.
// ============================================================================
#pragma once

#include "vision_classifier.hpp"

#include <cctype>

#ifndef ASGT_STB_IMAGE_WRITE_INCLUDED
#define ASGT_STB_IMAGE_WRITE_INCLUDED
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"
#endif

namespace ffsc_v3 {

inline u64 mod_inverse(u64 x, u64 p) {
    x %= p;
    if (x == 0) throw std::runtime_error("zero has no modular inverse");
    return GF::power(x, p - 2, p);
}

inline std::string lower_extension(const std::string &path) {
    size_t dot = path.find_last_of('.');
    if (dot == std::string::npos) return "";
    std::string ext = path.substr(dot + 1);
    for (char &c : ext) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return ext;
}

class INTT2D {
public:
    explicit INTT2D(const FFSCConfig &cfg)
        : width_(cfg.target_width), height_(cfg.target_height), p_(cfg.p), g_(cfg.g) {
        if (!ffsc_v2::is_power_of_two(width_) || !ffsc_v2::is_power_of_two(height_))
            throw std::runtime_error("target_width and target_height must be powers of two");
        if ((p_ - 1) % width_ != 0 || (p_ - 1) % height_ != 0)
            throw std::runtime_error("target dimensions must divide p-1 for NTT roots");
        row_root_ = GF::power(g_, (p_ - 1) / width_, p_);
        col_root_ = GF::power(g_, (p_ - 1) / height_, p_);
        inv_row_root_ = mod_inverse(row_root_, p_);
        inv_col_root_ = mod_inverse(col_root_, p_);
        inv_total_ = mod_inverse((width_ % p_) * (height_ % p_) % p_, p_);
    }

    void forward(std::vector<u64> &a) const {
        validate_size(a);
        transform_rows(a, row_root_);
        transform_cols(a, col_root_);
    }

    void inverse(std::vector<u64> &a) const {
        validate_size(a);
        transform_rows(a, inv_row_root_);
        transform_cols(a, inv_col_root_);
        for (u64 &v : a) v = GF::mul(v, inv_total_, p_);
    }

private:
    u64 width_, height_, p_, g_, row_root_, col_root_, inv_row_root_, inv_col_root_, inv_total_;

    void validate_size(const std::vector<u64> &a) const {
        if (a.size() != static_cast<size_t>(width_ * height_))
            throw std::runtime_error("latent buffer size does not match decoder dimensions");
    }

    void transform_rows(std::vector<u64> &a, u64 root) const {
        std::vector<u64> tmp(static_cast<size_t>(width_));
        for (u64 row = 0; row < height_; ++row) {
            const size_t base = static_cast<size_t>(row * width_);
            std::copy(a.begin() + base, a.begin() + base + static_cast<size_t>(width_), tmp.begin());
            ntt_1d(tmp.data(), width_, root);
            std::copy(tmp.begin(), tmp.end(), a.begin() + base);
        }
    }

    void transform_cols(std::vector<u64> &a, u64 root) const {
        std::vector<u64> tmp(static_cast<size_t>(height_));
        for (u64 col = 0; col < width_; ++col) {
            for (u64 row = 0; row < height_; ++row)
                tmp[static_cast<size_t>(row)] = a[static_cast<size_t>(row * width_ + col)];
            ntt_1d(tmp.data(), height_, root);
            for (u64 row = 0; row < height_; ++row)
                a[static_cast<size_t>(row * width_ + col)] = tmp[static_cast<size_t>(row)];
        }
    }

    void ntt_1d(u64 *a, u64 n, u64 root) const {
        bit_reverse(a, n);
        for (u64 len = 2; len <= n; len <<= 1) {
            const u64 wlen = GF::power(root, n / len, p_);
            const u64 half = len >> 1;
            for (u64 i = 0; i < n; i += len) {
                u64 w = 1;
                for (u64 j = 0; j < half; ++j) {
                    const u64 u = a[i + j];
                    const u64 v = GF::mul(a[i + j + half], w, p_);
                    a[i + j] = GF::add(u, v, p_);
                    a[i + j + half] = GF::sub(u, v, p_);
                    w = GF::mul(w, wlen, p_);
                }
            }
        }
    }

    void bit_reverse(u64 *a, u64 n) const {
        for (u64 i = 1, j = 0; i < n; ++i) {
            u64 bit = n >> 1;
            while (j & bit) {
                j ^= bit;
                bit >>= 1;
            }
            j ^= bit;
            if (i < j) std::swap(a[i], a[j]);
        }
    }
};

class InverseDiffractionDecoder {
public:
    explicit InverseDiffractionDecoder(const FFSCConfig &cfg) : cfg_(cfg), ntt_(cfg) {}

    std::vector<u64> get_spectral_latents(const std::string &image_path) const {
        std::vector<uint8_t> pixels = ffsc_v2::load_and_preprocess(image_path, cfg_);
        if (pixels.empty()) throw std::runtime_error("failed to load image for spectral encoding");
        std::vector<u64> latents(pixels.size());
        for (size_t i = 0; i < pixels.size(); ++i) latents[i] = static_cast<u64>(pixels[i]) % cfg_.p;
        ntt_.forward(latents);
        return latents;
    }

    bool decode_latents_to_image(const std::vector<u64> &latents, const std::string &output_path) const {
        std::vector<uint8_t> pixels = reconstruct_pixels(latents);
        return write_image(output_path, pixels);
    }

    bool test_autoencoder_loop(const std::string &image_path, const std::string &output_path) const {
        return decode_latents_to_image(get_spectral_latents(image_path), output_path);
    }

    std::vector<uint8_t> reconstruct_pixels(const std::vector<u64> &latents) const {
        std::vector<u64> field = latents;
        for (u64 &v : field) v %= cfg_.p;
        ntt_.inverse(field);

        std::vector<uint8_t> pixels(field.size());
        for (size_t i = 0; i < field.size(); ++i) {
            const u64 v = field[i] % cfg_.p;
            pixels[i] = static_cast<uint8_t>(v <= 255 ? v : (v & 255));
        }
        return pixels;
    }

private:
    FFSCConfig cfg_;
    INTT2D ntt_;

    bool write_image(const std::string &path, const std::vector<uint8_t> &pixels) const {
        if (pixels.size() != static_cast<size_t>(cfg_.target_width * cfg_.target_height))
            throw std::runtime_error("pixel buffer size does not match output dimensions");

        const int w = static_cast<int>(cfg_.target_width);
        const int h = static_cast<int>(cfg_.target_height);
        const std::string ext = lower_extension(path);
        if (ext == "jpg" || ext == "jpeg")
            return stbi_write_jpg(path.c_str(), w, h, 1, pixels.data(), 95) != 0;
        return stbi_write_png(path.c_str(), w, h, 1, pixels.data(), w) != 0;
    }
};

} // namespace ffsc_v3
