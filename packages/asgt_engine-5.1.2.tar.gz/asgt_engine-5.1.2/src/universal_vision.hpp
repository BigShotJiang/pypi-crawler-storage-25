// ============================================================================
// ASGT Vision V5.1 - Universal zero-float algebraic tensor vision engine
// Multi-channel tensors, mmap archive loading, p-adic distillation.
// ============================================================================
#pragma once

#include "decoder.hpp"

#include <cctype>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <future>
#include <limits>
#include <mutex>
#include <unordered_map>
#include <thread>

#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

namespace asgt_v5 {

struct VisionConfig {
    u64 target_width = 256;
    u64 target_height = 256;
    u64 p = 786433;
    u64 g = 10;
    u64 top_k = 128;
    u64 num_threads = 0;
    u64 feature_dim = 256;
    u64 num_layers = 3;
    u64 num_channels = 64;
    u64 max_tensor_cells = 16777216;
    u64 centroid_momentum_num = 1;
    u64 centroid_momentum_den = 8;
};

struct UniversalImage {
    u64 width = 0;
    u64 height = 0;
    u64 channels = 0;
    std::vector<uint8_t> pixels;
};

struct AlgebraicTensor {
    u64 width = 0;
    u64 height = 0;
    u64 channels = 0;
    std::vector<u64> data;
};

struct VisionClassResult {
    std::string predicted_class;
    u64 confidence = 0;
    u64 distance = 0;
};

struct VisionLabelProfile {
    std::string label;
    std::vector<u64> signature;
    std::vector<u64> feature_tensor;
    u64 samples = 0;
    u64 weight_sum = 0;
};

struct MetricsSummary {
    std::vector<std::string> labels;
    std::vector<u64> confusion;
    u64 total = 0;
    u64 correct = 0;
    u64 accuracy_ppm = 0;
    u64 macro_precision_ppm = 0;
    u64 macro_recall_ppm = 0;
    u64 macro_f1_ppm = 0;
    u64 micro_precision_ppm = 0;
    u64 micro_recall_ppm = 0;
    u64 micro_f1_ppm = 0;
};

struct KFoldResult {
    std::vector<MetricsSummary> folds;
    MetricsSummary aggregate;
};

inline u64 addm(u64 a, u64 b, u64 p) { return GF::add(a, b, p); }
inline u64 subm(u64 a, u64 b, u64 p) { return GF::sub(a, b, p); }
inline u64 mulm(u64 a, u64 b, u64 p) { return GF::mul(a, b, p); }
inline u64 powm(u64 a, u64 e, u64 p) { return GF::power(a, e, p); }

inline u64 fast_mod_inverse(u64 n, u64 p) {
    n %= p;
    if (n == 0) return 0;
    return GF::power(n, p - 2, p);
}

inline u64 label_hash(const std::string &label, u64 p) {
    u64 h = 1469598103934665603ull % p;
    for (unsigned char c : label) {
        h = mulm(addm(h, static_cast<u64>(c) + 1, p), 1099511628211ull % p, p);
    }
    return h == 0 ? 1 : h;
}

inline u64 scaled_div(u64 num, u64 den, u64 scale = 1000000) {
    if (den == 0) return 0;
    return (num / den) * scale + ((num % den) * scale) / den;
}

inline bool checked_mul_u64(u64 a, u64 b, u64 &out) {
    if (a != 0 && b > std::numeric_limits<u64>::max() / a) return false;
    out = a * b;
    return true;
}

inline u64 checked_spatial_cells(u64 width, u64 height) {
    u64 cells = 0;
    if (!checked_mul_u64(width, height, cells))
        throw std::runtime_error("spatial dimension overflow");
    return cells;
}

inline u64 checked_tensor_cells(const VisionConfig &cfg) {
    const u64 spatial = checked_spatial_cells(cfg.target_width, cfg.target_height);
    u64 cells = 0;
    if (!checked_mul_u64(spatial, cfg.num_channels, cells))
        throw std::runtime_error("tensor dimension overflow");
    if (cfg.max_tensor_cells == 0 || cells > cfg.max_tensor_cells)
        throw std::runtime_error("tensor dimensions exceed max_tensor_cells safety limit");
    return cells;
}

inline u64 crc64_update(u64 crc, const void *data, size_t size) {
    const uint8_t *p = static_cast<const uint8_t*>(data);
    crc = ~crc;
    for (size_t i = 0; i < size; ++i) {
        crc ^= static_cast<u64>(p[i]);
        for (int bit = 0; bit < 8; ++bit) {
            const u64 mask = 0 - (crc & 1);
            crc = (crc >> 1) ^ (0xC96C5795D7870F42ull & mask);
        }
    }
    return ~crc;
}

inline bool write_exact(FILE *f, const void *data, size_t size) {
    return size == 0 || std::fwrite(data, 1, size, f) == size;
}

inline bool read_exact(FILE *f, void *data, size_t size) {
    return size == 0 || std::fread(data, 1, size, f) == size;
}

inline bool write_u64_native(FILE *f, u64 v) {
    return write_exact(f, &v, sizeof(v));
}

inline bool read_u64_native(FILE *f, u64 &v) {
    return read_exact(f, &v, sizeof(v));
}

inline bool write_exact_crc(FILE *f, const void *data, size_t size, u64 &crc) {
    if (!write_exact(f, data, size)) return false;
    crc = crc64_update(crc, data, size);
    return true;
}

inline bool read_exact_crc(FILE *f, void *data, size_t size, u64 &crc) {
    if (!read_exact(f, data, size)) return false;
    crc = crc64_update(crc, data, size);
    return true;
}

inline bool write_u64_native_crc(FILE *f, u64 v, u64 &crc) {
    return write_exact_crc(f, &v, sizeof(v), crc);
}

inline bool read_u64_native_crc(FILE *f, u64 &v, u64 &crc) {
    return read_exact_crc(f, &v, sizeof(v), crc);
}

inline bool write_string_native(FILE *f, const std::string &s) {
    const u64 n = static_cast<u64>(s.size());
    return write_u64_native(f, n) && write_exact(f, s.data(), static_cast<size_t>(n));
}

inline bool read_string_native(FILE *f, std::string &s) {
    u64 n = 0;
    if (!read_u64_native(f, n)) return false;
    if (n > (1ull << 30)) return false;
    s.assign(static_cast<size_t>(n), '\0');
    return read_exact(f, s.data(), static_cast<size_t>(n));
}

inline bool write_string_native_crc(FILE *f, const std::string &s, u64 &crc) {
    const u64 n = static_cast<u64>(s.size());
    return write_u64_native_crc(f, n, crc) &&
           write_exact_crc(f, s.data(), static_cast<size_t>(n), crc);
}

inline bool read_string_native_crc(FILE *f, std::string &s, u64 &crc) {
    u64 n = 0;
    if (!read_u64_native_crc(f, n, crc)) return false;
    if (n > (1ull << 30)) return false;
    s.assign(static_cast<size_t>(n), '\0');
    return read_exact_crc(f, s.data(), static_cast<size_t>(n), crc);
}

inline bool write_vector_u64_native(FILE *f, const std::vector<u64> &v) {
    const u64 n = static_cast<u64>(v.size());
    return write_u64_native(f, n) &&
           write_exact(f, v.data(), static_cast<size_t>(n) * sizeof(u64));
}

inline bool read_vector_u64_native(FILE *f, std::vector<u64> &v, u64 expected_size) {
    u64 n = 0;
    if (!read_u64_native(f, n)) return false;
    if (n != expected_size) return false;
    v.assign(static_cast<size_t>(n), 0);
    return read_exact(f, v.data(), static_cast<size_t>(n) * sizeof(u64));
}

inline bool write_vector_u64_native_crc(FILE *f, const std::vector<u64> &v, u64 &crc) {
    const u64 n = static_cast<u64>(v.size());
    return write_u64_native_crc(f, n, crc) &&
           write_exact_crc(f, v.data(), static_cast<size_t>(n) * sizeof(u64), crc);
}

inline bool read_vector_u64_native_crc(FILE *f, std::vector<u64> &v, u64 expected_size, u64 &crc) {
    u64 n = 0;
    if (!read_u64_native_crc(f, n, crc)) return false;
    if (n != expected_size) return false;
    v.assign(static_cast<size_t>(n), 0);
    return read_exact_crc(f, v.data(), static_cast<size_t>(n) * sizeof(u64), crc);
}

inline size_t tensor_index(u64 width, u64 channels, u64 x, u64 y, u64 c) {
    u64 row = 0, spatial = 0, base = 0;
    if (!checked_mul_u64(y, width, row) ||
        !checked_mul_u64(row + x, channels, base)) {
        throw std::runtime_error("tensor index overflow");
    }
    spatial = base + c;
    return static_cast<size_t>(spatial);
}

inline size_t tensor_index_spatial(u64 channels, u64 spatial, u64 c) {
    u64 base = 0;
    if (!checked_mul_u64(spatial, channels, base))
        throw std::runtime_error("tensor index overflow");
    return static_cast<size_t>(base + c);
}

inline u64 wrap_axis(u64 v, int delta, u64 limit) {
    const i64 raw = static_cast<i64>(v) + static_cast<i64>(delta);
    i64 m = raw % static_cast<i64>(limit);
    if (m < 0) m += static_cast<i64>(limit);
    return static_cast<u64>(m);
}

inline u64 wrap_channel(u64 c, int delta, u64 channels) {
    const i64 raw = static_cast<i64>(c) + static_cast<i64>(delta);
    i64 m = raw % static_cast<i64>(channels);
    if (m < 0) m += static_cast<i64>(channels);
    return static_cast<u64>(m);
}

inline u64 p_adic_ball_project(u64 v, u64 p) {
    const u64 ball = std::max<u64>(1, p / 4096);
    const u64 anchor = (v / ball) * ball;
    const u64 local = (v % ball) / 2;
    return addm(anchor % p, local % p, p);
}

inline bool is_supported_image_path(const std::filesystem::path &path) {
    std::string ext = path.extension().string();
    std::transform(ext.begin(), ext.end(), ext.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".bmp" ||
           ext == ".tga" || ext == ".ppm" || ext == ".pgm";
}

inline UniversalImage load_image_native(const std::string &path) {
    int w = 0, h = 0, channels = 0;
    unsigned char *data = stbi_load(path.c_str(), &w, &h, &channels, 0);
    if (!data || w <= 0 || h <= 0 || channels <= 0) {
        if (data) stbi_image_free(data);
        return {};
    }

    UniversalImage img;
    img.width = static_cast<u64>(w);
    img.height = static_cast<u64>(h);
    img.channels = static_cast<u64>(channels);
    const size_t n = static_cast<size_t>(w) * static_cast<size_t>(h) * static_cast<size_t>(channels);
    img.pixels.assign(data, data + n);
    stbi_image_free(data);
    return img;
}

inline UniversalImage decode_image_memory_native(const uint8_t *bytes, size_t byte_count) {
    if (!bytes || byte_count == 0 || byte_count > static_cast<size_t>(std::numeric_limits<int>::max()))
        return {};

    int w = 0, h = 0, channels = 0;
    unsigned char *data = stbi_load_from_memory(
        bytes,
        static_cast<int>(byte_count),
        &w,
        &h,
        &channels,
        0);
    if (!data || w <= 0 || h <= 0 || channels <= 0) {
        if (data) stbi_image_free(data);
        return {};
    }

    UniversalImage img;
    img.width = static_cast<u64>(w);
    img.height = static_cast<u64>(h);
    img.channels = static_cast<u64>(channels);
    const size_t n = static_cast<size_t>(w) * static_cast<size_t>(h) * static_cast<size_t>(channels);
    img.pixels.assign(data, data + n);
    stbi_image_free(data);
    return img;
}

inline UniversalImage resize_nearest(const UniversalImage &src, u64 tw, u64 th) {
    UniversalImage out;
    out.width = tw;
    out.height = th;
    out.channels = src.channels;
    if (src.pixels.empty() || src.width == 0 || src.height == 0 || src.channels == 0) return {};
    out.pixels.resize(static_cast<size_t>(tw * th * src.channels));
    for (u64 y = 0; y < th; ++y) {
        u64 sy = (y * src.height) / th;
        if (sy >= src.height) sy = src.height - 1;
        for (u64 x = 0; x < tw; ++x) {
            u64 sx = (x * src.width) / tw;
            if (sx >= src.width) sx = src.width - 1;
            const size_t dst = static_cast<size_t>((y * tw + x) * src.channels);
            const size_t src_i = static_cast<size_t>((sy * src.width + sx) * src.channels);
            for (u64 c = 0; c < src.channels; ++c)
                out.pixels[dst + static_cast<size_t>(c)] = src.pixels[src_i + static_cast<size_t>(c)];
        }
    }
    return out;
}

inline UniversalImage load_and_preprocess(const std::string &path, const VisionConfig &cfg) {
    UniversalImage img = load_image_native(path);
    if (img.pixels.empty()) return {};
    if (img.width == cfg.target_width && img.height == cfg.target_height) return img;
    return resize_nearest(img, cfg.target_width, cfg.target_height);
}

inline UniversalImage decode_and_preprocess_memory(const uint8_t *bytes, size_t byte_count, const VisionConfig &cfg) {
    UniversalImage img = decode_image_memory_native(bytes, byte_count);
    if (img.pixels.empty()) return {};
    if (img.width == cfg.target_width && img.height == cfg.target_height) return img;
    return resize_nearest(img, cfg.target_width, cfg.target_height);
}

inline std::vector<uint8_t> intensity_plane(const UniversalImage &img) {
    const size_t pixels = static_cast<size_t>(img.width * img.height);
    std::vector<uint8_t> out(pixels, 0);
    if (img.pixels.empty() || img.channels == 0) return {};
    for (size_t i = 0; i < pixels; ++i) {
        const size_t base = i * static_cast<size_t>(img.channels);
        const u64 r = img.pixels[base];
        const u64 g = img.channels > 1 ? img.pixels[base + 1] : r;
        const u64 b = img.channels > 2 ? img.pixels[base + 2] : r;
        out[i] = static_cast<uint8_t>((r + g + b) / 3);
    }
    return out;
}

inline AlgebraicTensor project_image_to_tensor(const UniversalImage &img, const VisionConfig &cfg) {
    AlgebraicTensor tensor;
    tensor.width = cfg.target_width;
    tensor.height = cfg.target_height;
    tensor.channels = cfg.num_channels;
    if (img.pixels.empty() || img.channels == 0) return {};
    const u64 tensor_cells = checked_tensor_cells(cfg);
    tensor.data.assign(static_cast<size_t>(tensor_cells), 0);

    for (u64 y = 0; y < cfg.target_height; ++y) {
        for (u64 x = 0; x < cfg.target_width; ++x) {
            const size_t src = static_cast<size_t>((y * cfg.target_width + x) * img.channels);
            const u64 r = img.pixels[src] % cfg.p;
            const u64 g = img.channels > 1 ? img.pixels[src + 1] % cfg.p : r;
            const u64 b = img.channels > 2 ? img.pixels[src + 2] % cfg.p : r;
            const u64 a = img.channels > 3 ? img.pixels[src + 3] % cfg.p : 255 % cfg.p;
            const u64 xy = addm(mulm(x + 1, 131, cfg.p), mulm(y + 1, 257, cfg.p), cfg.p);
            for (u64 c = 0; c < cfg.num_channels; ++c) {
                const u64 k = c + 1;
                const u64 wr = addm(mulm(k, 17, cfg.p), 3, cfg.p);
                const u64 wg = addm(mulm(k, 31, cfg.p), 5, cfg.p);
                const u64 wb = addm(mulm(k, 47, cfg.p), 7, cfg.p);
                const u64 wa = addm(mulm(k, 11, cfg.p), 13, cfg.p);
                u64 v = mulm(r, wr, cfg.p);
                v = addm(v, mulm(g, wg, cfg.p), cfg.p);
                v = addm(v, mulm(b, wb, cfg.p), cfg.p);
                v = addm(v, mulm(a, wa, cfg.p), cfg.p);
                v = addm(v, mulm(xy, addm(k, 19, cfg.p), cfg.p), cfg.p);
                tensor.data[tensor_index(cfg.target_width, cfg.num_channels, x, y, c)] = v == 0 ? 1 : v;
            }
        }
    }
    return tensor;
}

struct ArchiveImageEntry {
    std::string name;
    const uint8_t *bytes = nullptr;
    size_t byte_count = 0;
};

inline std::string trim_tar_string(const char *data, size_t n) {
    size_t end = 0;
    while (end < n && data[end] != '\0') ++end;
    while (end > 0 && (data[end - 1] == ' ' || data[end - 1] == '\0')) --end;
    return std::string(data, data + end);
}

inline u64 parse_tar_octal(const char *data, size_t n) {
    u64 value = 0;
    for (size_t i = 0; i < n; ++i) {
        const unsigned char c = static_cast<unsigned char>(data[i]);
        if (c == '\0' || c == ' ') continue;
        if (c < '0' || c > '7') break;
        value = (value << 3) + static_cast<u64>(c - '0');
    }
    return value;
}

inline bool tar_block_is_zero(const uint8_t *block) {
    for (size_t i = 0; i < 512; ++i)
        if (block[i] != 0) return false;
    return true;
}

inline std::string normalize_archive_name(std::string name) {
    std::replace(name.begin(), name.end(), '\\', '/');
    while (!name.empty() && name.front() == '/') name.erase(name.begin());
    return name;
}

inline std::string archive_basename(const std::string &name) {
    const std::string norm = normalize_archive_name(name);
    const size_t pos = norm.find_last_of('/');
    return pos == std::string::npos ? norm : norm.substr(pos + 1);
}

class NativeMemoryMappedLoader {
public:
    explicit NativeMemoryMappedLoader(const std::string &path) : path_(path) {
        try {
            open_mapping();
        } catch (...) {
            close_mapping();
            throw;
        }
    }

    NativeMemoryMappedLoader(const NativeMemoryMappedLoader&) = delete;
    NativeMemoryMappedLoader& operator=(const NativeMemoryMappedLoader&) = delete;

    ~NativeMemoryMappedLoader() {
        close_mapping();
    }

    std::vector<ArchiveImageEntry> image_entries() const {
        if (!data_ || size_ == 0) return {};
        if (looks_like_tar()) return parse_tar_entries();
        std::filesystem::path p(path_);
        if (!is_supported_image_path(p)) return {};
        return {ArchiveImageEntry{p.filename().string(), data_, size_}};
    }

    size_t size() const { return size_; }

private:
    std::string path_;
    const uint8_t *data_ = nullptr;
    size_t size_ = 0;

#if defined(_WIN32)
    HANDLE file_ = INVALID_HANDLE_VALUE;
    HANDLE mapping_ = nullptr;
#else
    int fd_ = -1;
#endif

    void open_mapping() {
#if defined(_WIN32)
        file_ = CreateFileA(path_.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING,
                            FILE_ATTRIBUTE_NORMAL, nullptr);
        if (file_ == INVALID_HANDLE_VALUE) throw std::runtime_error("failed to open memory-mapped file");
        LARGE_INTEGER sz;
        if (!GetFileSizeEx(file_, &sz) || sz.QuadPart <= 0)
            throw std::runtime_error("failed to read memory-mapped file size");
        size_ = static_cast<size_t>(sz.QuadPart);
        mapping_ = CreateFileMappingA(file_, nullptr, PAGE_READONLY, 0, 0, nullptr);
        if (!mapping_) throw std::runtime_error("failed to create file mapping");
        data_ = static_cast<const uint8_t*>(MapViewOfFile(mapping_, FILE_MAP_READ, 0, 0, 0));
        if (!data_) throw std::runtime_error("failed to map file view");
#else
        fd_ = ::open(path_.c_str(), O_RDONLY);
        if (fd_ < 0) throw std::runtime_error("failed to open memory-mapped file");
        struct stat st;
        if (::fstat(fd_, &st) != 0 || st.st_size <= 0)
            throw std::runtime_error("failed to read memory-mapped file size");
        size_ = static_cast<size_t>(st.st_size);
        void *mapped = ::mmap(nullptr, size_, PROT_READ, MAP_PRIVATE, fd_, 0);
        if (mapped == MAP_FAILED) throw std::runtime_error("failed to mmap file");
        data_ = static_cast<const uint8_t*>(mapped);
#endif
    }

    void close_mapping() {
#if defined(_WIN32)
        if (data_) {
            UnmapViewOfFile(data_);
            data_ = nullptr;
        }
        if (mapping_) {
            CloseHandle(mapping_);
            mapping_ = nullptr;
        }
        if (file_ != INVALID_HANDLE_VALUE) {
            CloseHandle(file_);
            file_ = INVALID_HANDLE_VALUE;
        }
#else
        if (data_) {
            ::munmap(const_cast<uint8_t*>(data_), size_);
            data_ = nullptr;
        }
        if (fd_ >= 0) {
            ::close(fd_);
            fd_ = -1;
        }
#endif
        size_ = 0;
    }

    bool looks_like_tar() const {
        if (size_ < 512) return false;
        std::string ext = ffsc_v3::lower_extension(path_);
        if (ext == "tar") return true;
        if (std::memcmp(data_ + 257, "ustar", 5) == 0) return true;
        return false;
    }

    std::vector<ArchiveImageEntry> parse_tar_entries() const {
        std::vector<ArchiveImageEntry> entries;
        size_t pos = 0;
        while (pos + 512 <= size_) {
            const uint8_t *hdr = data_ + pos;
            if (tar_block_is_zero(hdr)) break;

            const std::string name = trim_tar_string(reinterpret_cast<const char*>(hdr), 100);
            const std::string prefix = trim_tar_string(reinterpret_cast<const char*>(hdr + 345), 155);
            const u64 file_size = parse_tar_octal(reinterpret_cast<const char*>(hdr + 124), 12);
            const char type = static_cast<char>(hdr[156]);
            const size_t data_pos = pos + 512;
            if (data_pos + static_cast<size_t>(file_size) > size_) break;

            std::string full_name = prefix.empty() ? name : prefix + "/" + name;
            full_name = normalize_archive_name(full_name);
            if ((type == '\0' || type == '0') && !full_name.empty() &&
                is_supported_image_path(std::filesystem::path(full_name))) {
                entries.push_back(ArchiveImageEntry{full_name, data_ + data_pos, static_cast<size_t>(file_size)});
            }

            const size_t padded = ((static_cast<size_t>(file_size) + 511) / 512) * 512;
            pos = data_pos + padded;
        }
        return entries;
    }
};

class UniversalNTT2D {
public:
    explicit UniversalNTT2D(const VisionConfig &cfg)
        : width_(cfg.target_width), height_(cfg.target_height), p_(cfg.p), g_(cfg.g) {
        if (!ffsc_v2::is_power_of_two(width_) || !ffsc_v2::is_power_of_two(height_))
            throw std::runtime_error("target_width and target_height must be powers of two");
        if ((p_ - 1) % width_ != 0 || (p_ - 1) % height_ != 0)
            throw std::runtime_error("target dimensions must divide p-1 for NTT roots");
        row_root_ = powm(g_, (p_ - 1) / width_, p_);
        col_root_ = powm(g_, (p_ - 1) / height_, p_);
    }

    void forward(std::vector<u64> &a) const {
        validate(a);
        transform_rows(a, row_root_);
        transform_cols(a, col_root_);
    }

private:
    u64 width_, height_, p_, g_, row_root_, col_root_;

    void validate(const std::vector<u64> &a) const {
        if (a.size() != static_cast<size_t>(width_ * height_))
            throw std::runtime_error("field buffer size does not match NTT dimensions");
    }

    void transform_rows(std::vector<u64> &a, u64 root) const {
        std::vector<u64> tmp(static_cast<size_t>(width_));
        for (u64 row = 0; row < height_; ++row) {
            for (u64 col = 0; col < width_; ++col)
                tmp[static_cast<size_t>(col)] = a[static_cast<size_t>(row * width_ + col)];
            ntt_1d(tmp.data(), width_, root);
            for (u64 col = 0; col < width_; ++col)
                a[static_cast<size_t>(row * width_ + col)] = tmp[static_cast<size_t>(col)];
        }
    }

    void transform_cols(std::vector<u64> &a, u64 root) const {
        std::vector<u64> tmp(static_cast<size_t>(height_));
        for (u64 col = 0; col < width_; ++col) {
            for (u64 row = 0; row < height_; ++row)
                tmp[static_cast<size_t>(row)] = a[static_cast<size_t>(row * width_ + col)];
            ntt_1d(tmp.data(), height_, root);
            for (u64 row = 0; row < height_; ++row)
                a[static_cast<size_t>(row * width_ + col)] = tmp[static_cast<size_t>(row)];
        }
    }

    void ntt_1d(u64 *a, u64 n, u64 root) const {
        for (u64 i = 1, j = 0; i < n; ++i) {
            u64 bit = n >> 1;
            for (; j & bit; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) std::swap(a[i], a[j]);
        }
        for (u64 len = 2; len <= n; len <<= 1) {
            const u64 wlen = powm(root, n / len, p_);
            for (u64 i = 0; i < n; i += len) {
                u64 w = 1;
                for (u64 j = 0; j < len / 2; ++j) {
                    const u64 u = a[i + j];
                    const u64 v = mulm(a[i + j + len / 2], w, p_);
                    a[i + j] = addm(u, v, p_);
                    a[i + j + len / 2] = subm(u, v, p_);
                    w = mulm(w, wlen, p_);
                }
            }
        }
    }
};

class SpectralGlobalRouter {
public:
    explicit SpectralGlobalRouter(const VisionConfig &cfg)
        : cfg_(cfg), ntt_(cfg) {}

    AlgebraicTensor route(const AlgebraicTensor &input) const {
        validate(input);
        const u64 cells = checked_spatial_cells(input.width, input.height);
        std::vector<u64> spectral(input.data.size(), 0);
        std::vector<u64> plane(static_cast<size_t>(cells), 0);

        for (u64 c = 0; c < input.channels; ++c) {
            for (u64 i = 0; i < cells; ++i)
                plane[static_cast<size_t>(i)] = input.data[tensor_index_spatial(input.channels, i, c)] % cfg_.p;
            ntt_.forward(plane);
            for (u64 i = 0; i < cells; ++i)
                spectral[tensor_index_spatial(input.channels, i, c)] = plane[static_cast<size_t>(i)] % cfg_.p;
        }

        AlgebraicTensor out = input;
        for (u64 i = 0; i < cells; ++i) {
            for (u64 c = 0; c < input.channels; ++c) {
                const u64 routed_i = (i * 131 + c * 17 + 7) % cells;
                const u64 routed_c = (c * 17 + i + 1) % input.channels;
                const size_t idx = tensor_index_spatial(input.channels, i, c);
                const size_t ridx = tensor_index_spatial(input.channels, routed_i, routed_c);
                const u64 gate = addm(mulm(c + 1, 97, cfg_.p), mulm(i + 1, 13, cfg_.p), cfg_.p);
                u64 mixed = addm(spectral[idx], spectral[ridx], cfg_.p);
                mixed = mulm(mixed, gate == 0 ? 1 : gate, cfg_.p);
                out.data[idx] = addm(input.data[idx] % cfg_.p, mixed, cfg_.p);
            }
        }
        return out;
    }

private:
    VisionConfig cfg_;
    UniversalNTT2D ntt_;

    void validate(const AlgebraicTensor &input) const {
        if (input.width != cfg_.target_width || input.height != cfg_.target_height ||
            input.channels != cfg_.num_channels)
            throw std::runtime_error("router tensor dimensions do not match V5 config");
        u64 cells = 0, tensor_cells = 0;
        if (!checked_mul_u64(input.width, input.height, cells) ||
            !checked_mul_u64(cells, input.channels, tensor_cells) ||
            input.data.size() != static_cast<size_t>(tensor_cells))
            throw std::runtime_error("router tensor buffer size mismatch");
    }
};

struct TensorHenselBlock {
    u64 kernel_size = 3;
    u64 channel_span = 5;
    u64 channels = 1;
    u64 p = 786433;
    std::vector<u64> weights;

    TensorHenselBlock() = default;
    TensorHenselBlock(u64 kernel, u64 span, u64 ch, u64 prime, u64 layer_index)
        : kernel_size(kernel), channel_span(std::max<u64>(1, std::min<u64>(span, ch))),
          channels(ch), p(prime) {
        weights.resize(static_cast<size_t>(channels * kernel_size * kernel_size * channel_span), 1);
        for (u64 oc = 0; oc < channels; ++oc) {
            for (u64 ky = 0; ky < kernel_size; ++ky) {
                for (u64 kx = 0; kx < kernel_size; ++kx) {
                    for (u64 s = 0; s < channel_span; ++s) {
                        const size_t idx = weight_index(oc, ky, kx, s);
                        weights[idx] = (mulm(oc + 1, 101, p) +
                                        mulm(ky + 1, 37, p) +
                                        mulm(kx + 1, 43, p) +
                                        mulm(s + 1, 59, p) +
                                        layer_index * 97 + 23) % p;
                        if (weights[idx] == 0) weights[idx] = 1;
                    }
                }
            }
        }
    }

    AlgebraicTensor forward(const AlgebraicTensor &input) const {
        validate(input);
        AlgebraicTensor raw = input;
        raw.data.assign(input.data.size(), 0);
        const u64 radius = kernel_size / 2;
        const int channel_radius = static_cast<int>(channel_span / 2);

        for (u64 y = 0; y < input.height; ++y) {
            for (u64 x = 0; x < input.width; ++x) {
                for (u64 oc = 0; oc < input.channels; ++oc) {
                    u64 acc = 0;
                    for (u64 ky = 0; ky < kernel_size; ++ky) {
                        const u64 sy = wrap_axis(y, static_cast<int>(ky) - static_cast<int>(radius), input.height);
                        for (u64 kx = 0; kx < kernel_size; ++kx) {
                            const u64 sx = wrap_axis(x, static_cast<int>(kx) - static_cast<int>(radius), input.width);
                            for (u64 s = 0; s < channel_span; ++s) {
                                const u64 ic = wrap_channel(oc, static_cast<int>(s) - channel_radius, input.channels);
                                const u64 v = input.data[tensor_index(input.width, input.channels, sx, sy, ic)] % p;
                                const u64 w = weights[weight_index(oc, ky, kx, s)] % p;
                                acc = addm(acc, mulm(v, w, p), p);
                            }
                        }
                    }
                    raw.data[tensor_index(input.width, input.channels, x, y, oc)] = acc;
                }
            }
        }
        return activate_smoothed(raw);
    }

    void residual_update(const std::vector<u64> &feature, const std::vector<u64> &channel_residuals, u64 layer_index) {
        if (feature.empty() || channel_residuals.empty()) return;
        const size_t spatial = feature.size() / std::max<u64>(1, channels);
        if (spatial == 0) return;
        for (u64 oc = 0; oc < channels; ++oc) {
            const u64 residual = channel_residuals[static_cast<size_t>(oc % channel_residuals.size())] % p;
            for (u64 ky = 0; ky < kernel_size; ++ky) {
                for (u64 kx = 0; kx < kernel_size; ++kx) {
                    for (u64 s = 0; s < channel_span; ++s) {
                        const size_t widx = weight_index(oc, ky, kx, s);
                        const u64 sample_spatial = (oc * 131 + ky * 17 + kx * 19 + s * 23 + layer_index * 29) %
                                                   static_cast<u64>(spatial);
                        const u64 sample_channel = (oc + s + layer_index) % channels;
                        const u64 sample = feature[tensor_index_spatial(channels, sample_spatial, sample_channel)] % p;
                        u64 lifted = addm(weights[widx], mulm(addm(residual, layer_index + 1, p), sample, p), p);
                        lifted = addm(lifted, mulm(lifted, lifted, p), p);
                        weights[widx] = lifted == 0 ? 1 : lifted;
                    }
                }
            }
        }
    }

private:
    size_t weight_index(u64 oc, u64 ky, u64 kx, u64 s) const {
        return static_cast<size_t>(((oc * kernel_size + ky) * kernel_size + kx) * channel_span + s);
    }

    void validate(const AlgebraicTensor &input) const {
        if (input.channels != channels)
            throw std::runtime_error("hensel block channel dimension mismatch");
        u64 cells = 0, tensor_cells = 0;
        if (!checked_mul_u64(input.width, input.height, cells) ||
            !checked_mul_u64(cells, input.channels, tensor_cells) ||
            input.data.size() != static_cast<size_t>(tensor_cells))
            throw std::runtime_error("hensel block tensor buffer size mismatch");
    }

    AlgebraicTensor activate_smoothed(const AlgebraicTensor &raw) const {
        AlgebraicTensor out = raw;
        out.data.assign(raw.data.size(), 0);
        for (u64 y = 0; y < raw.height; ++y) {
            for (u64 x = 0; x < raw.width; ++x) {
                for (u64 c = 0; c < raw.channels; ++c) {
                    const u64 projected = isogeny_smooth_projection(raw, x, y, c);
                    out.data[tensor_index(raw.width, raw.channels, x, y, c)] =
                        fast_mod_inverse(projected, p);
                }
            }
        }
        return out;
    }

    u64 isogeny_smooth_projection(const AlgebraicTensor &raw, u64 x, u64 y, u64 c) const {
        u64 acc = 0;
        u64 weight_sum = 0;
        for (int dy = -1; dy <= 1; ++dy) {
            const u64 sy = wrap_axis(y, dy, raw.height);
            for (int dx = -1; dx <= 1; ++dx) {
                const u64 sx = wrap_axis(x, dx, raw.width);
                const u64 w = (dx == 0 && dy == 0) ? 8 : ((dx == 0 || dy == 0) ? 4 : 2);
                const u64 v = raw.data[tensor_index(raw.width, raw.channels, sx, sy, c)] % p;
                acc = addm(acc, mulm(v, w, p), p);
                weight_sum += w;
            }
        }
        const u64 prev_c = wrap_channel(c, -1, raw.channels);
        const u64 next_c = wrap_channel(c, 1, raw.channels);
        acc = addm(acc, mulm(raw.data[tensor_index(raw.width, raw.channels, x, y, prev_c)] % p, 3, p), p);
        acc = addm(acc, mulm(raw.data[tensor_index(raw.width, raw.channels, x, y, next_c)] % p, 3, p), p);
        weight_sum += 6;

        const u64 inv_w = fast_mod_inverse(weight_sum % p, p);
        const u64 pooled = mulm(acc, inv_w == 0 ? 1 : inv_w, p);
        const u64 projected = p_adic_ball_project(pooled, p);
        return projected == 0 ? 1 : projected;
    }
};

class UniversalHenselBackbone {
public:
    explicit UniversalHenselBackbone(const VisionConfig &cfg)
        : cfg_(cfg), router_(cfg) {
        const u64 n = cfg_.num_layers == 0 ? 1 : cfg_.num_layers;
        for (u64 i = 0; i < n; ++i) {
            const u64 kernel = i == 0 ? 7 : (i == 1 ? 5 : 3);
            const u64 span = std::min<u64>(cfg_.num_channels, i == 0 ? 7 : 5);
            blocks_.emplace_back(kernel, span, cfg_.num_channels, cfg_.p, i);
        }
    }

    std::vector<u64> extract_map(const std::string &image_path) const {
        UniversalImage img = load_and_preprocess(image_path, cfg_);
        if (img.pixels.empty()) throw std::runtime_error("failed to load image for V5 vision encoding");
        return extract_map(img);
    }

    std::vector<u64> extract_map(const UniversalImage &img) const {
        AlgebraicTensor tensor = project_image_to_tensor(img, cfg_);
        if (tensor.data.empty()) throw std::runtime_error("empty V5 image tensor");
        tensor = router_.route(tensor);
        for (const auto &block : blocks_) {
            tensor = block.forward(tensor);
            tensor = router_.route(tensor);
        }
        return tensor.data;
    }

    std::vector<u64> signature_from_map(const std::vector<u64> &map) const {
        const size_t dim = static_cast<size_t>(std::max<u64>(1, cfg_.feature_dim));
        std::vector<u64> sig(dim, 0);
        if (map.empty()) return sig;
        const size_t step = std::max<size_t>(1, map.size() / dim);
        for (size_t i = 0; i < dim; ++i) {
            const size_t begin = (i * step) % map.size();
            const size_t end = std::min(map.size(), begin + step);
            u64 acc = 0;
            const u64 salt = static_cast<u64>(i + 1) * 31337;
            for (size_t j = begin; j < end; ++j) {
                const u64 channel = static_cast<u64>(j % std::max<u64>(1, cfg_.num_channels));
                const u64 v = addm(map[j] % cfg_.p, addm(salt % cfg_.p, channel + 1, cfg_.p), cfg_.p);
                acc = addm(mulm(acc, 257, cfg_.p), v, cfg_.p);
            }
            sig[i] = acc;
        }
        return sig;
    }

    std::vector<u64> extract_signature(const std::string &image_path) const {
        return signature_from_map(extract_map(image_path));
    }

    void residual_update(const std::string &label, const std::vector<u64> &feature_tensor, u64 weight) {
        std::vector<u64> residuals(static_cast<size_t>(cfg_.num_channels), 0);
        const u64 base = mulm(label_hash(label, cfg_.p), weight % cfg_.p, cfg_.p);
        for (u64 c = 0; c < cfg_.num_channels; ++c)
            residuals[static_cast<size_t>(c)] = addm(base, mulm(c + 1, 97, cfg_.p), cfg_.p);

        for (size_t i = 0; i < feature_tensor.size(); ++i) {
            const u64 c = static_cast<u64>(i % cfg_.num_channels);
            residuals[static_cast<size_t>(c)] =
                addm(mulm(residuals[static_cast<size_t>(c)], 131, cfg_.p),
                     feature_tensor[i] % cfg_.p, cfg_.p);
        }

        for (size_t i = blocks_.size(); i > 0; --i) {
            const size_t idx = i - 1;
            blocks_[idx].residual_update(feature_tensor, residuals, static_cast<u64>(idx));
            for (u64 &r : residuals)
                r = addm(mulm(r, 17, cfg_.p), static_cast<u64>(idx + 11), cfg_.p);
        }
    }

    void residual_update_distilled(
        const std::string &label,
        const std::vector<u64> &feature_tensor,
        u64 weight,
        const std::vector<u64> &teacher_bounds) {
        std::vector<u64> residuals(static_cast<size_t>(cfg_.num_channels), 0);
        const u64 hard_base = mulm(label_hash(label, cfg_.p), weight % cfg_.p, cfg_.p);
        u64 teacher_residue = 0;
        for (size_t i = 0; i < teacher_bounds.size(); ++i) {
            teacher_residue = addm(
                mulm(teacher_residue, 257, cfg_.p),
                mulm(teacher_bounds[i] % cfg_.p, static_cast<u64>(i + 1), cfg_.p),
                cfg_.p);
        }
        for (u64 c = 0; c < cfg_.num_channels; ++c) {
            const u64 soft = teacher_bounds.empty()
                ? 0
                : teacher_bounds[static_cast<size_t>(c % teacher_bounds.size())] % cfg_.p;
            residuals[static_cast<size_t>(c)] =
                addm(addm(hard_base, mulm(soft, c + 1, cfg_.p), cfg_.p),
                     teacher_residue, cfg_.p);
        }

        for (size_t i = 0; i < feature_tensor.size(); ++i) {
            const u64 c = static_cast<u64>(i % cfg_.num_channels);
            residuals[static_cast<size_t>(c)] =
                addm(mulm(residuals[static_cast<size_t>(c)], 131, cfg_.p),
                     feature_tensor[i] % cfg_.p, cfg_.p);
        }

        for (size_t i = blocks_.size(); i > 0; --i) {
            const size_t idx = i - 1;
            blocks_[idx].residual_update(feature_tensor, residuals, static_cast<u64>(idx));
            for (u64 c = 0; c < cfg_.num_channels; ++c) {
                const u64 soft = teacher_bounds.empty()
                    ? 0
                    : teacher_bounds[static_cast<size_t>((c + idx) % teacher_bounds.size())] % cfg_.p;
                residuals[static_cast<size_t>(c)] =
                    addm(addm(mulm(residuals[static_cast<size_t>(c)], 17, cfg_.p),
                              static_cast<u64>(idx + 11), cfg_.p),
                         soft, cfg_.p);
            }
        }
    }

    size_t num_blocks() const { return blocks_.size(); }
    u64 num_channels() const { return cfg_.num_channels; }

    bool save_weights_native(FILE *f, u64 &crc) const {
        if (!write_u64_native_crc(f, static_cast<u64>(blocks_.size()), crc)) return false;
        for (const auto &block : blocks_) {
            if (!write_u64_native_crc(f, block.kernel_size, crc) ||
                !write_u64_native_crc(f, block.channel_span, crc) ||
                !write_u64_native_crc(f, block.channels, crc) ||
                !write_vector_u64_native_crc(f, block.weights, crc)) {
                return false;
            }
        }
        return true;
    }

    bool stage_weights_native(FILE *f, std::vector<TensorHenselBlock> &loaded, u64 &crc) const {
        u64 block_count = 0;
        if (!read_u64_native_crc(f, block_count, crc)) return false;
        if (block_count != static_cast<u64>(blocks_.size())) return false;

        loaded = blocks_;
        for (u64 i = 0; i < block_count; ++i) {
            u64 kernel = 0, span = 0, channels = 0;
            std::vector<u64> weights;
            if (!read_u64_native_crc(f, kernel, crc) ||
                !read_u64_native_crc(f, span, crc) ||
                !read_u64_native_crc(f, channels, crc)) {
                return false;
            }
            TensorHenselBlock &block = loaded[static_cast<size_t>(i)];
            if (!read_vector_u64_native_crc(f, weights, static_cast<u64>(block.weights.size()), crc))
                return false;
            if (kernel != block.kernel_size || span != block.channel_span ||
                channels != block.channels || weights.size() != block.weights.size()) {
                return false;
            }
            block.weights = std::move(weights);
        }
        return true;
    }

    void commit_weights(std::vector<TensorHenselBlock> &&loaded) {
        blocks_ = std::move(loaded);
    }

private:
    VisionConfig cfg_;
    SpectralGlobalRouter router_;
    std::vector<TensorHenselBlock> blocks_;
};

class VisionMetricsTracker {
public:
    explicit VisionMetricsTracker(std::vector<std::string> labels)
        : labels_(std::move(labels)) {
        std::sort(labels_.begin(), labels_.end());
        labels_.erase(std::unique(labels_.begin(), labels_.end()), labels_.end());
        for (size_t i = 0; i < labels_.size(); ++i) index_[labels_[i]] = i;
        confusion_.assign(labels_.size() * labels_.size(), 0);
    }

    void update(const std::string &truth, const std::string &predicted) {
        auto ti = index_.find(truth);
        auto pi = index_.find(predicted);
        if (ti == index_.end() || pi == index_.end()) return;
        confusion_[ti->second * labels_.size() + pi->second] += 1;
    }

    MetricsSummary summary() const {
        MetricsSummary s;
        s.labels = labels_;
        s.confusion = confusion_;
        const size_t n = labels_.size();
        u64 macro_p = 0, macro_r = 0, macro_f1 = 0;
        u64 tp_all = 0, fp_all = 0, fn_all = 0;
        for (size_t i = 0; i < n; ++i) {
            const u64 tp = confusion_[i * n + i];
            u64 row = 0, col = 0;
            for (size_t j = 0; j < n; ++j) {
                row += confusion_[i * n + j];
                col += confusion_[j * n + i];
            }
            const u64 fp = col >= tp ? col - tp : 0;
            const u64 fn = row >= tp ? row - tp : 0;
            const u64 p = scaled_div(tp, tp + fp);
            const u64 r = scaled_div(tp, tp + fn);
            const u64 f1 = (p + r) == 0 ? 0 : (2 * p * r) / (p + r);
            macro_p += p;
            macro_r += r;
            macro_f1 += f1;
            tp_all += tp;
            fp_all += fp;
            fn_all += fn;
            s.total += row;
            s.correct += tp;
        }
        if (n > 0) {
            s.macro_precision_ppm = macro_p / static_cast<u64>(n);
            s.macro_recall_ppm = macro_r / static_cast<u64>(n);
            s.macro_f1_ppm = macro_f1 / static_cast<u64>(n);
        }
        s.accuracy_ppm = scaled_div(s.correct, s.total);
        s.micro_precision_ppm = scaled_div(tp_all, tp_all + fp_all);
        s.micro_recall_ppm = scaled_div(tp_all, tp_all + fn_all);
        s.micro_f1_ppm = (s.micro_precision_ppm + s.micro_recall_ppm) == 0
            ? 0
            : (2 * s.micro_precision_ppm * s.micro_recall_ppm) /
                  (s.micro_precision_ppm + s.micro_recall_ppm);
        return s;
    }

private:
    std::vector<std::string> labels_;
    std::unordered_map<std::string, size_t> index_;
    std::vector<u64> confusion_;
};

class SAKDEngine {
public:
    explicit SAKDEngine(const VisionConfig &cfg) : cfg_(cfg) {}

    static u64 soft_target_to_bound(const std::string &text, u64 p) {
        const u64 ppm = decimal_text_to_ppm(text);
        u64 bound = scaled_div(ppm, 1000000, p - 1);
        bound += 1;
        return bound >= p ? p - 1 : bound;
    }

    std::vector<u64> normalize_bounds(const std::vector<u64> &bounds) const {
        if (bounds.empty()) return {};
        u64 sum = 0;
        for (u64 v : bounds) sum = addm(sum, v % cfg_.p, cfg_.p);
        if (sum == 0) return bounds;
        const u64 inv_sum = fast_mod_inverse(sum, cfg_.p);
        std::vector<u64> out(bounds.size(), 0);
        for (size_t i = 0; i < bounds.size(); ++i) {
            out[i] = mulm(bounds[i] % cfg_.p, inv_sum == 0 ? 1 : inv_sum, cfg_.p);
            if (out[i] == 0) out[i] = 1;
        }
        return out;
    }

    std::vector<u64> align_signature(
        const std::vector<u64> &signature,
        const std::vector<u64> &teacher_bounds) const {
        if (teacher_bounds.empty()) return signature;
        const std::vector<u64> normalized = normalize_bounds(teacher_bounds);
        const u64 residue = teacher_residue(normalized);
        std::vector<u64> aligned = signature;
        for (size_t i = 0; i < aligned.size(); ++i) {
            const u64 soft = normalized[i % normalized.size()] % cfg_.p;
            const u64 momentum = static_cast<u64>((i % 17) + 1);
            aligned[i] = addm(aligned[i] % cfg_.p,
                              addm(mulm(soft, momentum, cfg_.p), residue, cfg_.p),
                              cfg_.p);
        }
        return aligned;
    }

    u64 distilled_weight(u64 sample_weight, const std::vector<u64> &teacher_bounds) const {
        if (teacher_bounds.empty()) return sample_weight == 0 ? 1 : sample_weight;
        const std::vector<u64> normalized = normalize_bounds(teacher_bounds);
        const u64 residue = teacher_residue(normalized);
        return std::max<u64>(1, sample_weight) + 1 + (residue % 11);
    }

private:
    VisionConfig cfg_;

    static u64 pow10_u64(u64 n) {
        u64 v = 1;
        for (u64 i = 0; i < n; ++i) {
            if (v > std::numeric_limits<u64>::max() / 10) return std::numeric_limits<u64>::max();
            v *= 10;
        }
        return v;
    }

    static u64 decimal_text_to_ppm(std::string text) {
        text.erase(std::remove_if(text.begin(), text.end(),
                                  [](unsigned char c) { return std::isspace(c) != 0; }),
                   text.end());
        if (text.empty()) return 0;
        if (text == "nan" || text == "NaN" || text == "inf" || text == "Infinity") return 0;

        bool negative = false;
        if (!text.empty() && (text[0] == '+' || text[0] == '-')) {
            negative = text[0] == '-';
            text.erase(text.begin());
        }
        if (negative || text.empty()) return 0;

        i64 exponent = 0;
        size_t epos = text.find_first_of("eE");
        if (epos != std::string::npos) {
            std::string exp_text = text.substr(epos + 1);
            text = text.substr(0, epos);
            bool exp_neg = false;
            if (!exp_text.empty() && (exp_text[0] == '+' || exp_text[0] == '-')) {
                exp_neg = exp_text[0] == '-';
                exp_text.erase(exp_text.begin());
            }
            for (char c : exp_text) {
                if (!std::isdigit(static_cast<unsigned char>(c))) break;
                exponent = exponent * 10 + static_cast<i64>(c - '0');
                if (exponent > 18) break;
            }
            if (exp_neg) exponent = -exponent;
        }

        u64 digits = 0;
        u64 frac_len = 0;
        bool seen_dot = false;
        for (char c : text) {
            if (c == '.') {
                seen_dot = true;
                continue;
            }
            if (!std::isdigit(static_cast<unsigned char>(c))) continue;
            if (digits <= std::numeric_limits<u64>::max() / 10)
                digits = digits * 10 + static_cast<u64>(c - '0');
            if (seen_dot) ++frac_len;
        }
        if (digits == 0) return 0;

        const i64 shift = exponent + 6 - static_cast<i64>(frac_len);
        u64 ppm = 0;
        if (shift >= 0) {
            const u64 scale = pow10_u64(static_cast<u64>(shift));
            if (scale != 0 && digits > std::numeric_limits<u64>::max() / scale)
                ppm = 1000000;
            else
                ppm = digits * scale;
        } else {
            const u64 scale = pow10_u64(static_cast<u64>(-shift));
            ppm = scale == 0 ? 0 : digits / scale;
        }
        return std::min<u64>(ppm, 1000000);
    }

    u64 teacher_residue(const std::vector<u64> &bounds) const {
        u64 residue = 0;
        for (size_t i = 0; i < bounds.size(); ++i) {
            residue = addm(mulm(residue, 257, cfg_.p),
                           mulm(bounds[i] % cfg_.p, static_cast<u64>(i + 1), cfg_.p),
                           cfg_.p);
        }
        return residue == 0 ? 1 : residue;
    }
};

class ASGTVisionEngine {
public:
    explicit ASGTVisionEngine(const VisionConfig &config)
        : cfg_(config), backbone_(config) {
        validate_config();
    }

    std::vector<u64> extract_features(const std::string &image_path) const {
        return backbone_.extract_signature(image_path);
    }

    std::vector<u64> extract_features_image(const UniversalImage &image) const {
        return backbone_.signature_from_map(backbone_.extract_map(image));
    }

    std::vector<std::string> train_paths(
        const std::vector<std::string> &image_paths,
        const std::vector<std::string> &class_labels,
        const std::vector<u64> &sample_weights = {}) {
        if (image_paths.size() != class_labels.size())
            throw std::runtime_error("image_paths and class_labels must have equal length");
        if (!sample_weights.empty() && sample_weights.size() != image_paths.size())
            throw std::runtime_error("sample_weights must be empty or match image_paths length");

        const std::vector<u64> auto_weights = sample_weights.empty()
            ? automatic_class_weights(class_labels)
            : sample_weights;
        std::vector<std::vector<u64>> maps(image_paths.size());
        std::vector<std::vector<u64>> signatures(image_paths.size());
        std::vector<std::string> skipped;
        std::mutex skipped_mutex;
        const u64 n = static_cast<u64>(image_paths.size());
        const u64 threads = resolved_threads();
        const u64 chunk = (n + threads - 1) / threads;
        std::vector<std::future<std::vector<size_t>>> futures;

        for (u64 t = 0; t < threads; ++t) {
            const u64 begin = t * chunk;
            const u64 end = std::min<u64>(n, begin + chunk);
            if (begin >= end) continue;
            futures.push_back(std::async(std::launch::async, [&, begin, end]() {
                std::vector<size_t> valid;
                valid.reserve(static_cast<size_t>(end - begin));
                for (u64 i = begin; i < end; ++i) {
                    try {
                        maps[static_cast<size_t>(i)] = backbone_.extract_map(image_paths[static_cast<size_t>(i)]);
                        signatures[static_cast<size_t>(i)] = backbone_.signature_from_map(maps[static_cast<size_t>(i)]);
                        valid.push_back(static_cast<size_t>(i));
                    } catch (...) {
                        std::lock_guard<std::mutex> lock(skipped_mutex);
                        skipped.push_back(image_paths[static_cast<size_t>(i)]);
                    }
                }
                return valid;
            }));
        }

        for (auto &f : futures) {
            for (size_t i : f.get()) {
                const u64 weight = std::max<u64>(1, auto_weights[i]);
                update_profile(class_labels[i], signatures[i], maps[i], weight);
                backbone_.residual_update(class_labels[i], maps[i], weight);
            }
        }
        return skipped;
    }

    std::vector<std::string> train_folder(const std::string &root_dir) {
        std::vector<std::string> paths;
        std::vector<std::string> labels;
        collect_folder_dataset(root_dir, paths, labels);
        return train_paths(paths, labels);
    }

    std::vector<std::string> train_mmap_archive(
        const std::string &archive_path,
        const std::unordered_map<std::string, std::string> &metadata) {
        NativeMemoryMappedLoader loader(archive_path);
        std::vector<ArchiveImageEntry> entries = loader.image_entries();
        std::vector<std::string> labels(entries.size());
        std::vector<size_t> selected;
        selected.reserve(entries.size());
        std::vector<std::string> skipped;

        for (size_t i = 0; i < entries.size(); ++i) {
            const std::string label = metadata_label(entries[i].name, metadata);
            if (label.empty()) {
                skipped.push_back(entries[i].name);
                continue;
            }
            labels[i] = label;
            selected.push_back(i);
        }

        std::vector<std::vector<u64>> maps(entries.size());
        std::vector<std::vector<u64>> signatures(entries.size());
        std::mutex skipped_mutex;
        const u64 n = static_cast<u64>(selected.size());
        const u64 threads = resolved_threads();
        const u64 chunk = (n + threads - 1) / threads;
        std::vector<std::future<std::vector<size_t>>> futures;

        for (u64 t = 0; t < threads; ++t) {
            const u64 begin = t * chunk;
            const u64 end = std::min<u64>(n, begin + chunk);
            if (begin >= end) continue;
            futures.push_back(std::async(std::launch::async, [&, begin, end]() {
                std::vector<size_t> valid;
                valid.reserve(static_cast<size_t>(end - begin));
                for (u64 local_i = begin; local_i < end; ++local_i) {
                    const size_t i = selected[static_cast<size_t>(local_i)];
                    try {
                        UniversalImage img = decode_and_preprocess_memory(
                            entries[i].bytes,
                            entries[i].byte_count,
                            cfg_);
                        if (img.pixels.empty()) throw std::runtime_error("failed to decode archive image");
                        maps[i] = backbone_.extract_map(img);
                        signatures[i] = backbone_.signature_from_map(maps[i]);
                        valid.push_back(i);
                    } catch (...) {
                        std::lock_guard<std::mutex> lock(skipped_mutex);
                        skipped.push_back(entries[i].name);
                    }
                }
                return valid;
            }));
        }

        std::vector<std::string> train_labels;
        train_labels.reserve(selected.size());
        for (size_t idx : selected) train_labels.push_back(labels[idx]);
        const std::vector<u64> auto_weights = automatic_class_weights(train_labels);
        std::vector<u64> entry_weights(entries.size(), 1);
        for (size_t i = 0; i < selected.size(); ++i)
            entry_weights[selected[i]] = i < auto_weights.size() ? auto_weights[i] : 1;
        for (auto &f : futures) {
            for (size_t i : f.get()) {
                const u64 weight = entry_weights[i];
                update_profile(labels[i], signatures[i], maps[i], weight);
                backbone_.residual_update(labels[i], maps[i], weight);
            }
        }
        return skipped;
    }

    std::vector<std::string> train_distilled_batch(
        const std::vector<std::string> &image_paths,
        const std::vector<std::vector<u64>> &soft_target_bounds,
        const std::vector<std::string> &hard_labels,
        const std::vector<u64> &sample_weights = {}) {
        if (image_paths.size() != hard_labels.size())
            throw std::runtime_error("image_paths and hard_labels must have equal length");
        if (soft_target_bounds.size() != image_paths.size())
            throw std::runtime_error("soft_target_matrix row count must match image_paths");
        if (!sample_weights.empty() && sample_weights.size() != image_paths.size())
            throw std::runtime_error("sample_weights must be empty or match image_paths length");

        const std::vector<u64> auto_weights = sample_weights.empty()
            ? automatic_class_weights(hard_labels)
            : sample_weights;
        std::vector<std::vector<u64>> maps(image_paths.size());
        std::vector<std::vector<u64>> signatures(image_paths.size());
        std::vector<std::string> skipped;
        std::mutex skipped_mutex;
        const u64 n = static_cast<u64>(image_paths.size());
        const u64 threads = resolved_threads();
        const u64 chunk = (n + threads - 1) / threads;
        std::vector<std::future<std::vector<size_t>>> futures;

        for (u64 t = 0; t < threads; ++t) {
            const u64 begin = t * chunk;
            const u64 end = std::min<u64>(n, begin + chunk);
            if (begin >= end) continue;
            futures.push_back(std::async(std::launch::async, [&, begin, end]() {
                std::vector<size_t> valid;
                valid.reserve(static_cast<size_t>(end - begin));
                for (u64 i = begin; i < end; ++i) {
                    try {
                        maps[static_cast<size_t>(i)] = backbone_.extract_map(image_paths[static_cast<size_t>(i)]);
                        signatures[static_cast<size_t>(i)] =
                            backbone_.signature_from_map(maps[static_cast<size_t>(i)]);
                        valid.push_back(static_cast<size_t>(i));
                    } catch (...) {
                        std::lock_guard<std::mutex> lock(skipped_mutex);
                        skipped.push_back(image_paths[static_cast<size_t>(i)]);
                    }
                }
                return valid;
            }));
        }

        SAKDEngine sakd(cfg_);
        for (auto &f : futures) {
            for (size_t i : f.get()) {
                const std::vector<u64> normalized = sakd.normalize_bounds(soft_target_bounds[i]);
                const u64 weight = sakd.distilled_weight(std::max<u64>(1, auto_weights[i]), normalized);
                const std::vector<u64> aligned_signature = sakd.align_signature(signatures[i], normalized);
                update_profile(hard_labels[i], aligned_signature, maps[i], weight);
                backbone_.residual_update_distilled(hard_labels[i], maps[i], weight, normalized);
            }
        }
        return skipped;
    }

    VisionClassResult classify(const std::string &image_path) const {
        if (profiles_.empty()) return {"", 0, cfg_.p};
        std::vector<u64> sig = backbone_.extract_signature(image_path);
        return classify_signature(sig);
    }

    VisionClassResult classify_image(const UniversalImage &image) const {
        if (profiles_.empty()) return {"", 0, cfg_.p};
        return classify_signature(extract_features_image(image));
    }

    MetricsSummary evaluate_paths(
        const std::vector<std::string> &image_paths,
        const std::vector<std::string> &class_labels) const {
        if (image_paths.size() != class_labels.size())
            throw std::runtime_error("image_paths and class_labels must have equal length");
        std::vector<std::string> labels = class_labels;
        for (const auto &kv : profiles_) labels.push_back(kv.first);
        VisionMetricsTracker tracker(labels);
        for (size_t i = 0; i < image_paths.size(); ++i) {
            VisionClassResult r = classify(image_paths[i]);
            tracker.update(class_labels[i], r.predicted_class);
        }
        return tracker.summary();
    }

    KFoldResult stratified_kfold(
        const std::vector<std::string> &image_paths,
        const std::vector<std::string> &class_labels,
        u64 k) const {
        if (image_paths.size() != class_labels.size())
            throw std::runtime_error("image_paths and class_labels must have equal length");
        if (k < 2) throw std::runtime_error("k must be at least 2");

        std::unordered_map<std::string, std::vector<size_t>> by_label;
        for (size_t i = 0; i < class_labels.size(); ++i) by_label[class_labels[i]].push_back(i);
        std::vector<std::vector<size_t>> folds(static_cast<size_t>(k));
        for (auto &kv : by_label) {
            for (size_t i = 0; i < kv.second.size(); ++i)
                folds[i % static_cast<size_t>(k)].push_back(kv.second[i]);
        }

        std::vector<std::string> all_labels = class_labels;
        VisionMetricsTracker aggregate(all_labels);
        KFoldResult out;
        for (u64 fold = 0; fold < k; ++fold) {
            ASGTVisionEngine model(cfg_);
            std::vector<std::string> train_x, train_y, test_x, test_y;
            for (u64 f = 0; f < k; ++f) {
                for (size_t idx : folds[static_cast<size_t>(f)]) {
                    if (f == fold) {
                        test_x.push_back(image_paths[idx]);
                        test_y.push_back(class_labels[idx]);
                    } else {
                        train_x.push_back(image_paths[idx]);
                        train_y.push_back(class_labels[idx]);
                    }
                }
            }
            model.train_paths(train_x, train_y);
            VisionMetricsTracker fold_tracker(all_labels);
            for (size_t i = 0; i < test_x.size(); ++i) {
                VisionClassResult r = model.classify(test_x[i]);
                fold_tracker.update(test_y[i], r.predicted_class);
                aggregate.update(test_y[i], r.predicted_class);
            }
            out.folds.push_back(fold_tracker.summary());
        }
        out.aggregate = aggregate.summary();
        return out;
    }

    bool segment_to_mask(
        const std::string &image_path,
        const std::string &target_label,
        const std::string &output_path,
        bool multiclass = false) const {
        auto it = profiles_.find(target_label);
        if (it == profiles_.end() || it->second.feature_tensor.empty())
            throw std::runtime_error("target_label has no trained V5 profile");

        UniversalImage img = load_and_preprocess(image_path, cfg_);
        if (img.pixels.empty()) throw std::runtime_error("failed to load image for segmentation");
        const std::vector<uint8_t> intensity = intensity_plane(img);
        std::vector<u64> fmap = backbone_.extract_map(img);
        const std::vector<u64> &profile = it->second.feature_tensor;
        if (fmap.size() != profile.size()) throw std::runtime_error("segmentation profile dimension mismatch");

        const size_t pixels = static_cast<size_t>(checked_spatial_cells(cfg_.target_width, cfg_.target_height));
        std::vector<u64> deltas(pixels, 0);
        u64 mean_delta = 0;
        for (size_t i = 0; i < pixels; ++i) {
            u64 pd = 0;
            for (u64 c = 0; c < cfg_.num_channels; ++c) {
                const size_t idx = tensor_index_spatial(cfg_.num_channels, static_cast<u64>(i), c);
                const u64 a = fmap[idx] % cfg_.p;
                const u64 b = profile[idx] % cfg_.p;
                const u64 d = a >= b ? a - b : b - a;
                pd += d / std::max<u64>(1, cfg_.num_channels);
            }
            deltas[i] = pd;
            mean_delta += pd / std::max<u64>(1, static_cast<u64>(pixels));
        }

        std::vector<uint8_t> mask(pixels, 0);
        const u64 label_code = label_hash(target_label, 255);
        for (size_t i = 0; i < pixels; ++i) {
            const u64 skip = static_cast<u64>(intensity[i]);
            const u64 gate = addm(deltas[i] % cfg_.p, mulm(skip % cfg_.p, 17, cfg_.p), cfg_.p);
            const bool active = deltas[i] <= mean_delta || gate > (cfg_.p / 2);
            if (multiclass) {
                mask[i] = active ? static_cast<uint8_t>(std::max<u64>(1, label_code & 255)) : 0;
            } else {
                mask[i] = active ? 255 : 0;
            }
        }
        return write_mask(output_path, mask);
    }

    std::vector<std::string> class_labels() const {
        std::vector<std::string> labels;
        labels.reserve(profiles_.size());
        for (const auto &kv : profiles_) labels.push_back(kv.first);
        std::sort(labels.begin(), labels.end());
        return labels;
    }

    bool save_weights(const std::string &file_path) const {
        FILE *f = std::fopen(file_path.c_str(), "wb");
        if (!f) return false;
        const bool ok = save_weights_native(f);
        std::fclose(f);
        return ok;
    }

    bool load_weights(const std::string &file_path) {
        FILE *f = std::fopen(file_path.c_str(), "rb");
        if (!f) return false;
        const bool ok = load_weights_native(f);
        std::fclose(f);
        return ok;
    }

    size_t num_classes() const { return profiles_.size(); }
    u64 target_width() const { return cfg_.target_width; }
    u64 target_height() const { return cfg_.target_height; }
    u64 prime() const { return cfg_.p; }
    u64 num_channels() const { return cfg_.num_channels; }
    size_t num_blocks() const { return backbone_.num_blocks(); }

private:
    VisionConfig cfg_;
    UniversalHenselBackbone backbone_;
    std::unordered_map<std::string, VisionLabelProfile> profiles_;

    bool write_config_native(FILE *f, u64 &crc) const {
        return write_u64_native_crc(f, cfg_.target_width, crc) &&
               write_u64_native_crc(f, cfg_.target_height, crc) &&
               write_u64_native_crc(f, cfg_.p, crc) &&
               write_u64_native_crc(f, cfg_.g, crc) &&
               write_u64_native_crc(f, cfg_.top_k, crc) &&
               write_u64_native_crc(f, cfg_.num_threads, crc) &&
               write_u64_native_crc(f, cfg_.feature_dim, crc) &&
               write_u64_native_crc(f, cfg_.num_layers, crc) &&
               write_u64_native_crc(f, cfg_.num_channels, crc) &&
               write_u64_native_crc(f, cfg_.max_tensor_cells, crc) &&
               write_u64_native_crc(f, cfg_.centroid_momentum_num, crc) &&
               write_u64_native_crc(f, cfg_.centroid_momentum_den, crc);
    }

    bool read_and_validate_config_native(FILE *f, u64 &crc) const {
        VisionConfig loaded;
        if (!read_u64_native_crc(f, loaded.target_width, crc) ||
            !read_u64_native_crc(f, loaded.target_height, crc) ||
            !read_u64_native_crc(f, loaded.p, crc) ||
            !read_u64_native_crc(f, loaded.g, crc) ||
            !read_u64_native_crc(f, loaded.top_k, crc) ||
            !read_u64_native_crc(f, loaded.num_threads, crc) ||
            !read_u64_native_crc(f, loaded.feature_dim, crc) ||
            !read_u64_native_crc(f, loaded.num_layers, crc) ||
            !read_u64_native_crc(f, loaded.num_channels, crc) ||
            !read_u64_native_crc(f, loaded.max_tensor_cells, crc) ||
            !read_u64_native_crc(f, loaded.centroid_momentum_num, crc) ||
            !read_u64_native_crc(f, loaded.centroid_momentum_den, crc)) {
            return false;
        }
        return loaded.target_width == cfg_.target_width &&
               loaded.target_height == cfg_.target_height &&
               loaded.p == cfg_.p &&
               loaded.g == cfg_.g &&
               loaded.feature_dim == cfg_.feature_dim &&
               loaded.num_layers == cfg_.num_layers &&
               loaded.num_channels == cfg_.num_channels &&
               loaded.max_tensor_cells == cfg_.max_tensor_cells;
    }

    bool save_weights_native(FILE *f) const {
        const char magic[8] = {'A','S','G','T','V','5','P','2'};
        u64 crc = 0;
        if (!write_exact(f, magic, sizeof(magic)) || !write_config_native(f, crc)) return false;
        if (!backbone_.save_weights_native(f, crc)) return false;

        if (!write_u64_native_crc(f, static_cast<u64>(profiles_.size()), crc)) return false;
        for (const auto &kv : profiles_) {
            const VisionLabelProfile &profile = kv.second;
            if (!write_string_native_crc(f, profile.label, crc) ||
                !write_u64_native_crc(f, profile.samples, crc) ||
                !write_u64_native_crc(f, profile.weight_sum, crc) ||
                !write_vector_u64_native_crc(f, profile.signature, crc) ||
                !write_vector_u64_native_crc(f, profile.feature_tensor, crc)) {
                return false;
            }
        }
        const char footer[8] = {'A','S','G','T','C','R','C','2'};
        if (!write_u64_native(f, crc) || !write_exact(f, footer, sizeof(footer))) return false;
        return std::fflush(f) == 0;
    }

    bool load_weights_native(FILE *f) {
        char magic[8] = {};
        if (!read_exact(f, magic, sizeof(magic))) return false;
        if (std::string(magic, sizeof(magic)) != "ASGTV5P2") return false;

        u64 crc = 0;
        if (!read_and_validate_config_native(f, crc)) return false;
        std::vector<TensorHenselBlock> staged_blocks;
        if (!backbone_.stage_weights_native(f, staged_blocks, crc)) return false;

        u64 profile_count = 0;
        if (!read_u64_native_crc(f, profile_count, crc)) return false;
        if (profile_count > (1ull << 20)) return false;

        std::unordered_map<std::string, VisionLabelProfile> loaded;
        const u64 feature_tensor_size = checked_tensor_cells(cfg_);
        for (u64 i = 0; i < profile_count; ++i) {
            VisionLabelProfile profile;
            if (!read_string_native_crc(f, profile.label, crc) ||
                !read_u64_native_crc(f, profile.samples, crc) ||
                !read_u64_native_crc(f, profile.weight_sum, crc) ||
                !read_vector_u64_native_crc(f, profile.signature, cfg_.feature_dim, crc) ||
                !read_vector_u64_native_crc(f, profile.feature_tensor, feature_tensor_size, crc)) {
                return false;
            }
            if (profile.label.empty() || profile.signature.size() != static_cast<size_t>(cfg_.feature_dim) ||
                profile.feature_tensor.size() != static_cast<size_t>(feature_tensor_size)) {
                return false;
            }
            loaded[profile.label] = std::move(profile);
        }
        u64 stored_crc = 0;
        char footer[8] = {};
        if (!read_u64_native(f, stored_crc) || !read_exact(f, footer, sizeof(footer))) return false;
        if (std::string(footer, sizeof(footer)) != "ASGTCRC2" || stored_crc != crc) return false;
        char extra = 0;
        if (std::fread(&extra, 1, 1, f) != 0) return false;

        backbone_.commit_weights(std::move(staged_blocks));
        profiles_ = std::move(loaded);
        return true;
    }

    void validate_config() const {
        if (cfg_.target_width == 0 || cfg_.target_height == 0) throw std::runtime_error("target dimensions must be positive");
        if (cfg_.feature_dim == 0) throw std::runtime_error("feature_dim must be positive");
        if (cfg_.num_channels == 0 || cfg_.num_channels > 512) throw std::runtime_error("num_channels must be in [1, 512]");
        checked_tensor_cells(cfg_);
        if (cfg_.centroid_momentum_den == 0) throw std::runtime_error("centroid_momentum_den must be positive");
    }

    u64 resolved_threads() const {
        if (cfg_.num_threads > 0) return cfg_.num_threads;
        u64 hw = static_cast<u64>(std::thread::hardware_concurrency());
        return std::max<u64>(1, hw == 0 ? 2 : hw);
    }

    std::vector<u64> automatic_class_weights(const std::vector<std::string> &labels) const {
        std::unordered_map<std::string, u64> counts;
        u64 max_count = 1;
        for (const auto &label : labels) {
            u64 &count = counts[label];
            count += 1;
            if (count > max_count) max_count = count;
        }
        std::vector<u64> weights(labels.size(), 1);
        for (size_t i = 0; i < labels.size(); ++i) {
            const u64 count = std::max<u64>(1, counts[labels[i]]);
            weights[i] = std::max<u64>(1, max_count / count);
        }
        return weights;
    }

    void update_profile(
        const std::string &label,
        const std::vector<u64> &signature,
        const std::vector<u64> &feature_tensor,
        u64 weight) {
        VisionLabelProfile &profile = profiles_[label];
        if (profile.label.empty()) profile.label = label;
        if (profile.signature.empty()) profile.signature.assign(signature.size(), 0);
        if (profile.feature_tensor.empty()) profile.feature_tensor.assign(feature_tensor.size(), 0);

        const u64 old_w = profile.weight_sum == 0 ? 0 : profile.weight_sum % cfg_.p;
        const u64 new_w = weight % cfg_.p;
        const u64 den = addm(old_w, new_w, cfg_.p);
        const u64 inv_den = den == 0 ? 1 : fast_mod_inverse(den, cfg_.p);
        blend(profile.signature, signature, old_w, new_w, inv_den);
        blend(profile.feature_tensor, feature_tensor, old_w, new_w, inv_den);
        profile.samples += 1;
        profile.weight_sum += weight;
    }

    void blend(std::vector<u64> &dst, const std::vector<u64> &src, u64 old_w, u64 new_w, u64 inv_den) {
        if (dst.size() != src.size()) throw std::runtime_error("profile dimension mismatch");
        for (size_t i = 0; i < src.size(); ++i) {
            const u64 old_part = mulm(dst[i] % cfg_.p, old_w, cfg_.p);
            const u64 new_part = mulm(src[i] % cfg_.p, new_w, cfg_.p);
            dst[i] = mulm(addm(old_part, new_part, cfg_.p), inv_den, cfg_.p);
        }
    }

    VisionClassResult classify_signature(const std::vector<u64> &sig) const {
        VisionClassResult best{"", 0, std::numeric_limits<u64>::max()};
        for (const auto &kv : profiles_) {
            const auto &profile = kv.second.signature;
            if (profile.size() != sig.size()) continue;
            u64 dist = 0;
            for (size_t i = 0; i < sig.size(); ++i) {
                const u64 a = sig[i] % cfg_.p;
                const u64 b = profile[i] % cfg_.p;
                const u64 d = a >= b ? a - b : b - a;
                dist += d / std::max<u64>(1, static_cast<u64>(sig.size()));
            }
            if (best.predicted_class.empty() || dist < best.distance) {
                best.predicted_class = kv.first;
                best.distance = dist;
                best.confidence = dist >= cfg_.p ? 1 : cfg_.p - dist;
            }
        }
        if (best.predicted_class.empty()) return {"", 0, cfg_.p};
        return best;
    }

    std::string metadata_label(
        const std::string &entry_name,
        const std::unordered_map<std::string, std::string> &metadata) const {
        const std::string normalized = normalize_archive_name(entry_name);
        auto it = metadata.find(normalized);
        if (it != metadata.end()) return it->second;
        it = metadata.find(entry_name);
        if (it != metadata.end()) return it->second;
        const std::string base = archive_basename(normalized);
        it = metadata.find(base);
        if (it != metadata.end()) return it->second;
        return "";
    }

    void collect_folder_dataset(
        const std::string &root_dir,
        std::vector<std::string> &paths,
        std::vector<std::string> &labels) const {
        namespace fs = std::filesystem;
        fs::path root(root_dir);
        if (!fs::exists(root) || !fs::is_directory(root))
            throw std::runtime_error("root_dir must be an existing directory");
        for (const auto &entry : fs::directory_iterator(root)) {
            if (!entry.is_directory()) continue;
            const std::string label = entry.path().filename().string();
            for (const auto &img : fs::recursive_directory_iterator(entry.path())) {
                if (!img.is_regular_file() || !is_supported_image_path(img.path())) continue;
                paths.push_back(img.path().string());
                labels.push_back(label);
            }
        }
    }

    bool write_mask(const std::string &path, const std::vector<uint8_t> &mask) const {
        if (mask.size() != static_cast<size_t>(checked_spatial_cells(cfg_.target_width, cfg_.target_height)))
            throw std::runtime_error("mask size does not match output dimensions");
        const int w = static_cast<int>(cfg_.target_width);
        const int h = static_cast<int>(cfg_.target_height);
        const std::string ext = ffsc_v3::lower_extension(path);
        if (ext == "jpg" || ext == "jpeg")
            return stbi_write_jpg(path.c_str(), w, h, 1, mask.data(), 95) != 0;
        return stbi_write_png(path.c_str(), w, h, 1, mask.data(), w) != 0;
    }
};

} // namespace asgt_v5
