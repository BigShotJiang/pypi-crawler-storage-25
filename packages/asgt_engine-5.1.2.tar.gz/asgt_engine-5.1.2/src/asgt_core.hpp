// ============================================================================
// ASGT Engine v1.1.0 - Text RAG v4 + FFSC Vision Core
// Zero float. Pure integer arithmetic over GF(p). Header-only C++17 core.
// ============================================================================
#pragma once

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

using u64 = uint64_t;
using i64 = int64_t;

#if defined(__SIZEOF_INT128__)
inline u64 mul_mod(u64 a, u64 b, u64 m) {
    return static_cast<u64>((static_cast<unsigned __int128>(a) * b) % m);
}
#elif defined(_MSC_VER) && defined(_M_X64)
#include <intrin.h>
inline u64 mul_mod(u64 a, u64 b, u64 m) {
    u64 hi = 0;
    u64 lo = _umul128(a, b, &hi);
    if (hi == 0) return lo % m;
#if _MSC_VER >= 1923
    u64 rem = 0;
    _udiv128(hi, lo, m, &rem);
    return rem;
#else
    u64 result = 0;
    a %= m;
    while (b > 0) {
        if (b & 1) result = (result + a) % m;
        a = (a + a) % m;
        b >>= 1;
    }
    return result;
#endif
}
#else
inline u64 mul_mod(u64 a, u64 b, u64 m) {
    u64 result = 0;
    a %= m;
    while (b > 0) {
        if (b & 1) result = (result + a) % m;
        a = (a + a) % m;
        b >>= 1;
    }
    return result;
}
#endif

namespace GF {
inline u64 add(u64 a, u64 b, u64 p) {
    u64 s = a + b;
    return s >= p ? s - p : s;
}

inline u64 sub(u64 a, u64 b, u64 p) {
    return a >= b ? a - b : p - b + a;
}

inline u64 mul(u64 a, u64 b, u64 p) {
    return mul_mod(a, b, p);
}

inline u64 power(u64 base, u64 exp, u64 p) {
    u64 r = 1;
    base %= p;
    while (exp > 0) {
        if (exp & 1) r = mul(r, base, p);
        base = mul(base, base, p);
        exp >>= 1;
    }
    return r;
}

inline i64 ext_gcd(i64 a, i64 b, i64 &x, i64 &y) {
    if (a == 0) {
        x = 0;
        y = 1;
        return b;
    }
    i64 x1 = 0, y1 = 0;
    i64 g = ext_gcd(b % a, a, x1, y1);
    x = y1 - (b / a) * x1;
    y = x1;
    return g;
}

inline u64 inv(u64 a, u64 p) {
    i64 x = 0, y = 0;
    i64 g = ext_gcd(static_cast<i64>(a % p), static_cast<i64>(p), x, y);
    if (g != 1) return 0;
    return static_cast<u64>((x % static_cast<i64>(p) + static_cast<i64>(p)) %
                            static_cast<i64>(p));
}

inline int legendre(u64 a, u64 p) {
    u64 v = power(a % p, (p - 1) / 2, p);
    return v == 0 ? 0 : (v == 1 ? 1 : -1);
}

inline u64 sqrt_mod(u64 n, u64 p) {
    n %= p;
    if (n == 0) return 0;
    if (legendre(n, p) != 1) return p;
    u64 q = p - 1, s = 0;
    while ((q & 1) == 0) {
        q >>= 1;
        ++s;
    }
    if (s == 1) return power(n, (p + 1) / 4, p);
    u64 z = 2;
    while (legendre(z, p) != -1) ++z;
    u64 m = s;
    u64 c = power(z, q, p);
    u64 t = power(n, q, p);
    u64 r = power(n, (q + 1) / 2, p);
    while (true) {
        if (t == 1) return r;
        u64 i = 0, tmp = t;
        while (tmp != 1) {
            tmp = mul(tmp, tmp, p);
            ++i;
        }
        u64 b = power(c, u64(1) << (m - i - 1), p);
        m = i;
        c = mul(b, b, p);
        t = mul(t, c, p);
        r = mul(r, b, p);
    }
}
} // namespace GF

struct ECPoint {
    u64 x;
    u64 y;
    bool inf;
    ECPoint() : x(0), y(0), inf(true) {}
    ECPoint(u64 px, u64 py) : x(px), y(py), inf(false) {}
    bool operator==(const ECPoint &o) const {
        if (inf && o.inf) return true;
        if (inf || o.inf) return false;
        return x == o.x && y == o.y;
    }
    bool operator!=(const ECPoint &o) const { return !(*this == o); }
};

struct EllipticCurve {
    u64 a;
    u64 b;
    u64 p;
    EllipticCurve() : a(7), b(13), p(65537) {}
    EllipticCurve(u64 ca, u64 cb, u64 cp) : a(ca), b(cb), p(cp) {}

    bool on_curve(const ECPoint &P) const {
        if (P.inf) return true;
        u64 lhs = GF::mul(P.y, P.y, p);
        u64 rhs = GF::add(GF::add(GF::power(P.x, 3, p), GF::mul(a, P.x, p), p), b, p);
        return lhs == rhs;
    }

    ECPoint add(const ECPoint &P, const ECPoint &Q) const {
        if (P.inf) return Q;
        if (Q.inf) return P;
        if (P.x == Q.x && P.y != Q.y) return ECPoint();
        if (P.x == Q.x && P.y == Q.y) return dbl(P);
        u64 dy = GF::sub(Q.y, P.y, p);
        u64 dx = GF::sub(Q.x, P.x, p);
        u64 lam = GF::mul(dy, GF::inv(dx, p), p);
        u64 x3 = GF::sub(GF::sub(GF::mul(lam, lam, p), P.x, p), Q.x, p);
        u64 y3 = GF::sub(GF::mul(lam, GF::sub(P.x, x3, p), p), P.y, p);
        return ECPoint(x3, y3);
    }

    ECPoint dbl(const ECPoint &P) const {
        if (P.inf || P.y == 0) return ECPoint();
        u64 num = GF::add(GF::mul(3, GF::mul(P.x, P.x, p), p), a, p);
        u64 den = GF::mul(2, P.y, p);
        u64 lam = GF::mul(num, GF::inv(den, p), p);
        u64 x3 = GF::sub(GF::mul(lam, lam, p), GF::mul(2, P.x, p), p);
        u64 y3 = GF::sub(GF::mul(lam, GF::sub(P.x, x3, p), p), P.y, p);
        return ECPoint(x3, y3);
    }

    ECPoint scalar_mul(u64 n, const ECPoint &P) const {
        ECPoint r;
        ECPoint q = P;
        while (n > 0) {
            if (n & 1) r = add(r, q);
            q = dbl(q);
            n >>= 1;
        }
        return r;
    }

    ECPoint find_generator() const {
        for (u64 x = 0; x < p; ++x) {
            u64 rhs = GF::add(GF::add(GF::power(x, 3, p), GF::mul(a, x, p), p), b, p);
            u64 y = GF::sqrt_mod(rhs, p);
            if (y < p) {
                ECPoint g(x, y);
                if (on_curve(g)) return g;
            }
        }
        return ECPoint();
    }
};

struct PadicMetric {
    u64 p;
    PadicMetric() : p(65537) {}
    explicit PadicMetric(u64 prime) : p(prime) {}

    u64 valuation(u64 n) const {
        if (n == 0) return 64;
        u64 v = 0;
        while (n > 0 && n % p == 0) {
            n /= p;
            ++v;
        }
        return v;
    }

    u64 coord_similarity(const ECPoint &A, const ECPoint &B) const {
        if (A.inf && B.inf) return 1000;
        if (A.inf || B.inf) return 0;
        u64 dx = A.x >= B.x ? A.x - B.x : B.x - A.x;
        u64 dy = A.y >= B.y ? A.y - B.y : B.y - A.y;
        u64 vx = valuation(dx);
        u64 vy = valuation(dy);
        u64 close_x = dx == 0 ? p : p / (dx + 1);
        u64 close_y = dy == 0 ? p : p / (dy + 1);
        return close_x + close_y + (vx + vy) * 1000;
    }
};

struct SemanticCluster {
    std::string name;
    u64 base_scalar;
    u64 importance_weight;
    std::vector<std::string> words;
    ECPoint base_point;
};

struct SemanticLatticeEmbedder {
    const EllipticCurve &E;
    ECPoint generator;
    std::vector<SemanticCluster> clusters;
    std::unordered_map<std::string, ECPoint> word_map;
    std::unordered_map<std::string, size_t> word_cluster;

    SemanticLatticeEmbedder(const EllipticCurve &curve, const ECPoint &G)
        : E(curve), generator(G) {
        clusters = {
            {"circulatory", 1000, 1000, {"heart","pumps","blood","circulatory","system","filters","liver","toxins","kidneys","filter","waste","products"}, {}},
            {"immunity", 2000, 1000, {"white","cells","fight","infection","immune","antibiotics","kill","bacteria","viruses","vaccines","stimulate","produce","antibodies","vaccine"}, {}},
            {"neurology", 3000, 1000, {"brain","contains","approximately","billion","neurons","neural","nervous"}, {}},
            {"genetics", 4000, 1000, {"dna","carries","genetic","instructions","life","genes","hereditary","information"}, {}},
            {"botany", 5000, 1000, {"photosynthesis","converts","sunlight","chemical","energy","plants","plant","make","chlorophyll"}, {}},
            {"metabolism", 6000, 1000, {"insulin","regulates","sugar","levels","body","glucose","metabolism","controls","blood"}, {}},
            {"radiology", 8000, 1000, {"xray","chest","cardiomegaly","pneumonia","effusion","atelectasis","infiltration","nodule","mass","edema","fibrosis","diagnosis","finding","patient"}, {}},
            {"general", 7000, 0, {"the","a","an","in","on","of","to","and","but","not","from","into","through","for","with","how","what","do","does","work","is","are"}, {}},
        };
        build_lattice();
    }

    void build_lattice() {
        word_map.clear();
        word_cluster.clear();
        for (size_t ci = 0; ci < clusters.size(); ++ci) {
            auto &cl = clusters[ci];
            cl.base_point = E.scalar_mul(cl.base_scalar, generator);
            for (size_t wi = 0; wi < cl.words.size(); ++wi) {
                const std::string &w = cl.words[wi];
                if (word_map.find(w) != word_map.end()) continue;
                ECPoint pt = E.add(cl.base_point, E.scalar_mul(wi + 1, generator));
                word_map[w] = pt;
                word_cluster[w] = ci;
            }
        }
    }

    static std::string normalize(const std::string &w) {
        std::string out;
        for (char c : w) {
            if (c >= 'A' && c <= 'Z') out += static_cast<char>(c + 32);
            else if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) out += c;
        }
        return out;
    }

    static std::vector<std::string> tokenize(const std::string &s) {
        std::vector<std::string> out;
        std::istringstream iss(s);
        std::string w;
        while (iss >> w) {
            std::string n = normalize(w);
            if (!n.empty()) out.push_back(n);
        }
        return out;
    }

    ECPoint embed(const std::string &word) const {
        std::string w = normalize(word);
        auto it = word_map.find(w);
        if (it != word_map.end()) return it->second;
        u64 h = 5381;
        for (char c : w) h = ((h << 5) + h) + static_cast<u64>(c);
        return E.scalar_mul((h % 100) + 9000, generator);
    }

    u64 word_weight(const std::string &word) const {
        auto it = word_cluster.find(normalize(word));
        if (it == word_cluster.end()) return 0;
        return clusters[it->second].importance_weight;
    }
};

struct HeckeSentenceEncoder {
    const EllipticCurve &E;
    const SemanticLatticeEmbedder &embedder;
    std::array<u64, 18> primes;

    HeckeSentenceEncoder(const EllipticCurve &curve, const SemanticLatticeEmbedder &emb)
        : E(curve),
          embedder(emb),
          primes{2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61} {}

    ECPoint encode(const std::string &sentence) const {
        auto words = SemanticLatticeEmbedder::tokenize(sentence);
        ECPoint acc;
        for (size_t i = 0; i < words.size(); ++i) {
            ECPoint wpt = embedder.embed(words[i]);
            u64 cw = (primes[i % primes.size()] * (i + 1)) % (E.p - 1);
            if (cw == 0) cw = 1;
            acc = E.add(acc, E.scalar_mul(cw, wpt));
        }
        return acc;
    }
};

namespace ffsc {
constexpr u64 P = 786433ULL;
constexpr u64 G = 10ULL;
constexpr size_t N = 256;
constexpr size_t PIXELS = N * N;
constexpr size_t TOP_K = 128;
constexpr u64 LAMBDA = 31337ULL;

inline u64 addm(u64 a, u64 b) { return GF::add(a, b, P); }
inline u64 subm(u64 a, u64 b) { return GF::sub(a, b, P); }
inline u64 mulm(u64 a, u64 b) { return GF::mul(a, b, P); }
inline u64 powm(u64 a, u64 e) { return GF::power(a, e, P); }
inline u64 invm(u64 a) { return GF::power(a % P, P - 2, P); }

struct GFp2 {
    u64 re, im;
    GFp2() : re(0), im(0) {}
    GFp2(u64 r, u64 i) : re(r % P), im(i % P) {}
    GFp2 operator+(const GFp2 &o) const { return GFp2(addm(re, o.re), addm(im, o.im)); }
    GFp2 operator*(const GFp2 &o) const {
        return GFp2(subm(mulm(re, o.re), mulm(im, o.im)),
                    addm(mulm(re, o.im), mulm(im, o.re)));
    }
};

class NTT2D {
public:
    NTT2D() : root_(powm(G, (P - 1) / N)) {}
    void normalize(const std::vector<uint8_t> &pixels, std::array<u64, PIXELS> &out) const {
        if (pixels.size() != PIXELS) throw std::runtime_error("Image must contain exactly 65536 uint8 pixels");
        for (size_t i = 0; i < PIXELS; ++i) out[i] = pixels[i];
    }
    void forward(std::array<u64, PIXELS> &a) const {
        std::array<u64, N> tmp{};
        for (size_t r = 0; r < N; ++r) {
            for (size_t c = 0; c < N; ++c) tmp[c] = a[r * N + c];
            ntt1(tmp);
            for (size_t c = 0; c < N; ++c) a[r * N + c] = tmp[c];
        }
        for (size_t c = 0; c < N; ++c) {
            for (size_t r = 0; r < N; ++r) tmp[r] = a[r * N + c];
            ntt1(tmp);
            for (size_t r = 0; r < N; ++r) a[r * N + c] = tmp[r];
        }
    }
private:
    u64 root_;
    void ntt1(std::array<u64, N> &a) const {
        for (size_t i = 1, j = 0; i < N; ++i) {
            size_t bit = N >> 1;
            for (; j & bit; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) std::swap(a[i], a[j]);
        }
        for (size_t len = 2; len <= N; len <<= 1) {
            u64 wlen = powm(root_, N / len);
            for (size_t i = 0; i < N; i += len) {
                u64 w = 1;
                for (size_t j = 0; j < len / 2; ++j) {
                    u64 u = a[i + j];
                    u64 v = mulm(a[i + j + len / 2], w);
                    a[i + j] = addm(u, v);
                    a[i + j + len / 2] = subm(u, v);
                    w = mulm(w, wlen);
                }
            }
        }
    }
};

struct TopFreq { uint32_t idx; u64 amp; };

class KloostermanExtractor {
public:
    std::array<u64, 8> extract(const std::array<u64, PIXELS> &spec) const {
        std::array<TopFreq, TOP_K> top{};
        size_t used = 0;
        for (uint32_t i = 1; i < PIXELS; ++i) {
            u64 amp = spec[i];
            if (amp == 0) continue;
            if (used < TOP_K) { top[used++] = {i, amp}; continue; }
            size_t min_pos = 0;
            for (size_t j = 1; j < TOP_K; ++j) if (top[j].amp < top[min_pos].amp) min_pos = j;
            if (amp > top[min_pos].amp) top[min_pos] = {i, amp};
        }
        std::array<u64, 8> out{};
        for (size_t d = 0; d < 8; ++d) {
            u64 a = (static_cast<u64>(d) * P / 8) % P;
            u64 b = (static_cast<u64>(d) * d + 1) % P;
            u64 k = 0;
            for (size_t i = 0; i < used; ++i) {
                u64 freq = (top[i].idx + 1ULL) % P;
                if (freq == 0) freq = 1;
                u64 psi = addm(mulm(a, freq), mulm(b, invm(freq)));
                k = addm(k, mulm(top[i].amp, psi));
            }
            out[d] = k;
        }
        return out;
    }
};

class ZernikeExtractor {
public:
    std::array<u64, 8> extract(const std::vector<uint8_t> &pixels) const {
        std::array<GFp2, 4> z{};
        for (size_t y = 0; y < N; ++y) {
            for (size_t x = 0; x < N; ++x) {
                u64 pix = pixels[y * N + x];
                if (pix == 0) continue;
                u64 cx = (x + P - (N / 2)) % P;
                u64 cy = (y + P - (N / 2)) % P;
                u64 r2 = addm(mulm(cx, cx), mulm(cy, cy));
                GFp2 phase(cx, cy), acc(1, 0);
                for (size_t order = 0; order < 4; ++order) {
                    u64 radial = powm(addm(r2, 1), static_cast<u64>(order + 1));
                    z[order] = z[order] + (GFp2(mulm(pix, radial), 0) * acc);
                    acc = acc * phase;
                }
            }
        }
        std::array<u64, 8> out{};
        for (size_t i = 0; i < 4; ++i) {
            out[2 * i] = z[i].re;
            out[2 * i + 1] = z[i].im;
        }
        return out;
    }
};

class FFSCEncoder {
public:
    FFSCEncoder() : curve_(7, 13, P) {}
    ECPoint encode(const std::vector<uint8_t> &pixels) {
        ntt_.normalize(pixels, spectrum_);
        ntt_.forward(spectrum_);
        return project(hash(klo_.extract(spectrum_), zer_.extract(pixels)));
    }
private:
    NTT2D ntt_;
    KloostermanExtractor klo_;
    ZernikeExtractor zer_;
    EllipticCurve curve_;
    std::array<u64, PIXELS> spectrum_{};

    u64 hash(const std::array<u64, 8> &k, const std::array<u64, 8> &z) const {
        u64 s = 0, gauss = 0;
        for (u64 c : k) { s = addm(mulm(s, LAMBDA), c); gauss = addm(gauss, legendre(c)); }
        for (u64 c : z) { s = addm(mulm(s, LAMBDA), c); gauss = addm(gauss, legendre(c)); }
        if (gauss == 0) gauss = 1;
        return mulm(s, gauss);
    }
    u64 legendre(u64 x) const { return x == 0 ? 0 : powm(x, (P - 1) / 2); }
    ECPoint project(u64 s) const {
        u64 x = s % P;
        for (size_t attempt = 0; attempt < 128; ++attempt) {
            u64 rhs = addm(addm(mulm(mulm(x, x), x), mulm(7, x)), 13);
            u64 y = GF::sqrt_mod(rhs, P);
            if (y < P) return ECPoint(x, y);
            x = addm(x, 1);
        }
        return ECPoint();
    }
};

class HeckeFusion {
public:
    HeckeFusion() : curve_(7, 13, P), metric_(P) {}
    ECPoint fuse(const ECPoint &txt, const ECPoint &img) const {
        ECPoint result;
        u64 htxt = txt.inf ? 1 : txt.x;
        u64 himg = img.inf ? 1 : img.x;
        for (u64 n1 = 1; n1 <= 16; ++n1) {
            for (u64 n2 = 1; n1 * n2 <= 16; ++n2) {
                if (std::gcd(n1, n2) != 1) continue;
                u64 w1 = std::gcd(htxt, n1) % P;
                u64 w2 = std::gcd(himg, n2) % P;
                if (w1 == 0) w1 = 1;
                if (w2 == 0) w2 = 1;
                result = curve_.add(result, curve_.add(
                    curve_.scalar_mul((w1 * n1) % P, txt),
                    curve_.scalar_mul((w2 * n2) % P, img)));
            }
        }
        return result;
    }
    u64 similarity(const ECPoint &a, const ECPoint &b) const {
        return metric_.coord_similarity(a, b);
    }
private:
    EllipticCurve curve_;
    PadicMetric metric_;
};
} // namespace ffsc

struct SearchResult {
    size_t index;
    u64 similarity;
    std::string text;
};

struct MultiModalEntry {
    std::string text;
    ECPoint text_point;
    ECPoint image_point;
    ECPoint fused_point;
    bool has_image;
};

class ASGTEngine {
public:
    ASGTEngine(u64 a = 7, u64 b = 13, u64 p = 65537)
        : text_curve(a, b, p),
          vision_curve(7, 13, ffsc::P),
          text_generator(text_curve.find_generator()),
          vision_generator(vision_curve.find_generator()),
          embedder(text_curve, text_generator),
          sentence_encoder(text_curve, embedder),
          text_metric(p),
          vision_metric(ffsc::P),
          train_steps(0) {
        if (text_generator.inf || vision_generator.inf)
            throw std::runtime_error("Failed to initialize ASGT curve generator");
    }

    void train_step(const std::string &text) { add_text_entry(text); }
    void train_batch(const std::vector<std::string> &texts) { train_text_batch(texts); }
    void train_text_batch(const std::vector<std::string> &texts) {
        for (const auto &text : texts) add_text_entry(text);
    }

    void train_vision_batch(const std::vector<std::vector<uint8_t>> &images,
                            const std::vector<std::string> &texts) {
        if (images.size() != texts.size())
            throw std::runtime_error("images and texts must have equal length");
        for (size_t i = 0; i < images.size(); ++i) {
            ECPoint img = vision_encoder.encode(images[i]);
            ECPoint txt = sentence_encoder.encode(texts[i]);
            ECPoint bridge = bridge_text(txt);
            ECPoint fused = fusion.fuse(bridge, img);
            entries.push_back({texts[i], txt, img, fused, true});
            ++train_steps;
        }
    }

    std::vector<SearchResult> retrieve(const std::string &query, size_t top_k = 3) const {
        ECPoint q = sentence_encoder.encode(query);
        std::vector<SearchResult> results;
        for (size_t i = 0; i < entries.size(); ++i) {
            u64 sim = text_metric.coord_similarity(q, entries[i].text_point);
            auto q_words = SemanticLatticeEmbedder::tokenize(query);
            auto e_words = SemanticLatticeEmbedder::tokenize(entries[i].text);
            for (const auto &qw : q_words) {
                u64 weight = embedder.word_weight(qw);
                if (weight == 0) continue;
                for (const auto &ew : e_words) {
                    if (qw == ew) sim += 100 * weight;
                }
            }
            results.push_back({i, sim, entries[i].text});
        }
        sort_results(results, top_k);
        return results;
    }

    std::vector<SearchResult> retrieve_multimodal(const std::vector<uint8_t> &image,
                                                  size_t top_k = 3) {
        ECPoint img = vision_encoder.encode(image);
        std::vector<SearchResult> results;
        for (size_t i = 0; i < entries.size(); ++i) {
            u64 sim = entries[i].has_image
                ? vision_metric.coord_similarity(img, entries[i].image_point)
                : vision_metric.coord_similarity(img, entries[i].fused_point);
            results.push_back({i, sim, entries[i].text});
        }
        sort_results(results, top_k);
        return results;
    }

    std::string generate(const std::string &prompt, size_t = 1) const {
        auto r = retrieve(prompt, 1);
        return r.empty() ? "[No relevant knowledge]" : r[0].text;
    }

    bool save_model(const std::string &path) const {
        std::ofstream f(path, std::ios::binary);
        if (!f) return false;
        const char magic[8] = {'A','S','G','T','1','1','0','0'};
        f.write(magic, 8);
        write_u64(f, text_curve.a); write_u64(f, text_curve.b); write_u64(f, text_curve.p);
        write_u64(f, train_steps);
        write_u64(f, static_cast<u64>(entries.size()));
        for (const auto &e : entries) {
            write_str(f, e.text);
            write_point(f, e.text_point);
            write_point(f, e.image_point);
            write_point(f, e.fused_point);
            uint8_t has = e.has_image ? 1 : 0;
            f.write(reinterpret_cast<const char*>(&has), 1);
        }
        return true;
    }

    bool load_model(const std::string &path) {
        std::ifstream f(path, std::ios::binary);
        if (!f) return false;
        char magic[8];
        f.read(magic, 8);
        if (std::string(magic, 8) != "ASGT1100") return false;
        u64 a = read_u64(f), b = read_u64(f), p = read_u64(f);
        if (a != text_curve.a || b != text_curve.b || p != text_curve.p)
            throw std::runtime_error("Model curve parameters do not match engine");
        train_steps = read_u64(f);
        u64 n = read_u64(f);
        entries.clear();
        entries.reserve(static_cast<size_t>(n));
        for (u64 i = 0; i < n; ++i) {
            MultiModalEntry e;
            e.text = read_str(f);
            e.text_point = read_point(f);
            e.image_point = read_point(f);
            e.fused_point = read_point(f);
            uint8_t has = 0;
            f.read(reinterpret_cast<char*>(&has), 1);
            e.has_image = has != 0;
            entries.push_back(e);
        }
        return true;
    }

    size_t vocab_size() const { return embedder.word_map.size(); }
    size_t num_facts() const { return entries.size(); }
    size_t num_entries() const { return entries.size(); }
    u64 get_train_steps() const { return train_steps; }

private:
    EllipticCurve text_curve;
    EllipticCurve vision_curve;
    ECPoint text_generator;
    ECPoint vision_generator;
    SemanticLatticeEmbedder embedder;
    HeckeSentenceEncoder sentence_encoder;
    ffsc::FFSCEncoder vision_encoder;
    ffsc::HeckeFusion fusion;
    PadicMetric text_metric;
    PadicMetric vision_metric;
    std::vector<MultiModalEntry> entries;
    u64 train_steps;

    void add_text_entry(const std::string &text) {
        ECPoint txt = sentence_encoder.encode(text);
        ECPoint bridge = bridge_text(txt);
        entries.push_back({text, txt, ECPoint(), bridge, false});
        ++train_steps;
    }

    ECPoint bridge_text(const ECPoint &txt) const {
        u64 scalar = txt.inf ? 1 : ((txt.x + txt.y + 1) % ffsc::P);
        if (scalar == 0) scalar = 1;
        return vision_curve.scalar_mul(scalar, vision_generator);
    }

    static void sort_results(std::vector<SearchResult> &results, size_t top_k) {
        std::sort(results.begin(), results.end(),
                  [](const SearchResult &a, const SearchResult &b) {
                      return a.similarity > b.similarity;
                  });
        if (results.size() > top_k) results.resize(top_k);
    }

    static void write_u64(std::ofstream &f, u64 v) {
        f.write(reinterpret_cast<const char*>(&v), 8);
    }
    static u64 read_u64(std::ifstream &f) {
        u64 v = 0;
        f.read(reinterpret_cast<char*>(&v), 8);
        return v;
    }
    static void write_str(std::ofstream &f, const std::string &s) {
        write_u64(f, static_cast<u64>(s.size()));
        f.write(s.data(), static_cast<std::streamsize>(s.size()));
    }
    static std::string read_str(std::ifstream &f) {
        u64 n = read_u64(f);
        std::string s(n, '\0');
        f.read(&s[0], static_cast<std::streamsize>(n));
        return s;
    }
    static void write_point(std::ofstream &f, const ECPoint &p) {
        write_u64(f, p.x);
        write_u64(f, p.y);
        uint8_t inf = p.inf ? 1 : 0;
        f.write(reinterpret_cast<const char*>(&inf), 1);
    }
    static ECPoint read_point(std::ifstream &f) {
        ECPoint p;
        p.x = read_u64(f);
        p.y = read_u64(f);
        uint8_t inf = 0;
        f.read(reinterpret_cast<char*>(&inf), 1);
        p.inf = inf != 0;
        return p;
    }
};

