// ============================================================================
// ASGT Engine V2 - Dynamic FFSC Spectral Centroid Classifier
// Native image loading, integer-only spectral processing, C++17.
// ============================================================================
#pragma once

#include "asgt_core.hpp"

#include <future>
#include <mutex>
#include <thread>

#ifndef ASGT_STB_IMAGE_INCLUDED
#define ASGT_STB_IMAGE_INCLUDED
#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_LINEAR
#define STBI_NO_HDR
#include "stb_image.h"
#endif

struct FFSCConfig {
    u64 target_width = 256;
    u64 target_height = 256;
    u64 p = 786433;
    u64 g = 10;
    u64 top_k = 128;
    u64 kloosterman_dim = 8;
    u64 zernike_orders = 4;
    u64 centroid_momentum_num = 1;
    u64 centroid_momentum_den = 8;
    u64 num_threads = 0;
    u64 num_deep_layers = 3;
};

struct V2ClassResult {
    std::string predicted_class;
    u64 confidence;
    u64 distance;
};

struct V2ClassState {
    std::string label;
    ECPoint centroid;
    u64 samples = 0;
    u64 weight_sum = 0;
};

namespace ffsc_v2 {

inline bool is_power_of_two(u64 x) {
    return x > 0 && (x & (x - 1)) == 0;
}

inline u64 addm(u64 a, u64 b, u64 p) { return GF::add(a, b, p); }
inline u64 subm(u64 a, u64 b, u64 p) { return GF::sub(a, b, p); }
inline u64 mulm(u64 a, u64 b, u64 p) { return GF::mul(a, b, p); }
inline u64 powm(u64 a, u64 e, u64 p) { return GF::power(a, e, p); }
inline u64 invm(u64 a, u64 p) { return GF::power(a % p, p - 2, p); }

inline u64 point_distance(const ECPoint &a, const ECPoint &b, u64 p) {
    if (a.inf && b.inf) return 0;
    if (a.inf || b.inf) return p;
    u64 dx = a.x >= b.x ? a.x - b.x : b.x - a.x;
    u64 dy = a.y >= b.y ? a.y - b.y : b.y - a.y;
    u64 sx = dx == 0 ? 0 : dx;
    u64 sy = dy == 0 ? 0 : dy;
    return sx + sy;
}

inline u64 distance_to_confidence(u64 distance, u64 p) {
    if (distance == 0) return p;
    return p / (1 + (distance % p));
}

inline void write_u64(std::ofstream &f, u64 v) {
    f.write(reinterpret_cast<const char*>(&v), 8);
}

inline u64 read_u64(std::ifstream &f) {
    u64 v = 0;
    f.read(reinterpret_cast<char*>(&v), 8);
    return v;
}

inline void write_str(std::ofstream &f, const std::string &s) {
    write_u64(f, static_cast<u64>(s.size()));
    f.write(s.data(), static_cast<std::streamsize>(s.size()));
}

inline std::string read_str(std::ifstream &f) {
    u64 n = read_u64(f);
    std::string s(n, '\0');
    f.read(&s[0], static_cast<std::streamsize>(n));
    return s;
}

inline void write_point(std::ofstream &f, const ECPoint &p) {
    write_u64(f, p.x);
    write_u64(f, p.y);
    uint8_t inf = p.inf ? 1 : 0;
    f.write(reinterpret_cast<const char*>(&inf), 1);
}

inline ECPoint read_point(std::ifstream &f) {
    ECPoint p;
    p.x = read_u64(f);
    p.y = read_u64(f);
    uint8_t inf = 0;
    f.read(reinterpret_cast<char*>(&inf), 1);
    p.inf = inf != 0;
    return p;
}

struct NativeImage {
    u64 width = 0;
    u64 height = 0;
    std::vector<uint8_t> gray;
};

inline NativeImage load_image_gray_native(const std::string &path) {
    int w = 0, h = 0, channels = 0;
    unsigned char *data = stbi_load(path.c_str(), &w, &h, &channels, 1);
    if (!data || w <= 0 || h <= 0) {
        if (data) stbi_image_free(data);
        return {};
    }
    NativeImage img;
    img.width = static_cast<u64>(w);
    img.height = static_cast<u64>(h);
    img.gray.assign(data, data + static_cast<size_t>(w) * static_cast<size_t>(h));
    stbi_image_free(data);
    return img;
}

inline std::vector<uint8_t> resize_nearest_u8(const NativeImage &src, u64 tw, u64 th) {
    std::vector<uint8_t> out(static_cast<size_t>(tw * th));
    if (src.gray.empty() || src.width == 0 || src.height == 0) return {};
    for (u64 y = 0; y < th; ++y) {
        u64 sy = (y * src.height) / th;
        if (sy >= src.height) sy = src.height - 1;
        for (u64 x = 0; x < tw; ++x) {
            u64 sx = (x * src.width) / tw;
            if (sx >= src.width) sx = src.width - 1;
            out[static_cast<size_t>(y * tw + x)] =
                src.gray[static_cast<size_t>(sy * src.width + sx)];
        }
    }
    return out;
}

inline std::vector<uint8_t> load_and_preprocess(const std::string &path, const FFSCConfig &cfg) {
    NativeImage img = load_image_gray_native(path);
    if (img.gray.empty()) return {};
    if (img.width == cfg.target_width && img.height == cfg.target_height) return img.gray;
    return resize_nearest_u8(img, cfg.target_width, cfg.target_height);
}

class DynamicNTT2D {
public:
    explicit DynamicNTT2D(const FFSCConfig &cfg)
        : width_(cfg.target_width), height_(cfg.target_height), p_(cfg.p), g_(cfg.g) {
        if (!is_power_of_two(width_) || !is_power_of_two(height_))
            throw std::runtime_error("target_width and target_height must be powers of two");
        if ((p_ - 1) % width_ != 0 || (p_ - 1) % height_ != 0)
            throw std::runtime_error("target dimensions must divide p-1 for NTT roots");
        row_root_ = powm(g_, (p_ - 1) / width_, p_);
        col_root_ = powm(g_, (p_ - 1) / height_, p_);
    }

    void normalize(const std::vector<uint8_t> &pixels, std::vector<u64> &out) const {
        const size_t expected = static_cast<size_t>(width_ * height_);
        if (pixels.size() != expected) throw std::runtime_error("pixel buffer size mismatch");
        out.resize(expected);
        for (size_t i = 0; i < expected; ++i) out[i] = pixels[i] % p_;
    }

    void forward(std::vector<u64> &a) const {
        std::vector<u64> tmp(static_cast<size_t>(std::max(width_, height_)));
        for (u64 row = 0; row < height_; ++row) {
            for (u64 col = 0; col < width_; ++col) tmp[col] = a[static_cast<size_t>(row * width_ + col)];
            ntt_1d(tmp.data(), width_, row_root_);
            for (u64 col = 0; col < width_; ++col) a[static_cast<size_t>(row * width_ + col)] = tmp[col];
        }
        for (u64 col = 0; col < width_; ++col) {
            for (u64 row = 0; row < height_; ++row) tmp[row] = a[static_cast<size_t>(row * width_ + col)];
            ntt_1d(tmp.data(), height_, col_root_);
            for (u64 row = 0; row < height_; ++row) a[static_cast<size_t>(row * width_ + col)] = tmp[row];
        }
    }

private:
    u64 width_, height_, p_, g_, row_root_, col_root_;

    void ntt_1d(u64 *a, u64 n, u64 root) const {
        for (u64 i = 1, j = 0; i < n; ++i) {
            u64 bit = n >> 1;
            for (; j & bit; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) std::swap(a[i], a[j]);
        }
        for (u64 len = 2; len <= n; len <<= 1) {
            u64 wlen = powm(root, n / len, p_);
            for (u64 i = 0; i < n; i += len) {
                u64 w = 1;
                for (u64 j = 0; j < len / 2; ++j) {
                    u64 u = a[i + j];
                    u64 v = mulm(a[i + j + len / 2], w, p_);
                    a[i + j] = addm(u, v, p_);
                    a[i + j + len / 2] = subm(u, v, p_);
                    w = mulm(w, wlen, p_);
                }
            }
        }
    }
};

class DynamicFeatureExtractor {
public:
    explicit DynamicFeatureExtractor(const FFSCConfig &cfg) : cfg_(cfg) {}

    std::vector<u64> kloosterman(const std::vector<u64> &spectrum) const {
        const size_t count = spectrum.size();
        const size_t top_k = static_cast<size_t>(std::min<u64>(cfg_.top_k, count));
        std::vector<std::pair<u64, u64>> top;
        top.reserve(top_k);
        for (u64 i = 1; i < count; ++i) {
            u64 amp = spectrum[static_cast<size_t>(i)];
            if (amp == 0) continue;
            if (top.size() < top_k) {
                top.push_back({amp, i});
            } else {
                size_t min_pos = 0;
                for (size_t j = 1; j < top.size(); ++j)
                    if (top[j].first < top[min_pos].first) min_pos = j;
                if (amp > top[min_pos].first) top[min_pos] = {amp, i};
            }
        }

        std::vector<u64> out(static_cast<size_t>(cfg_.kloosterman_dim), 0);
        for (u64 d = 0; d < cfg_.kloosterman_dim; ++d) {
            u64 a = (d * cfg_.p / cfg_.kloosterman_dim) % cfg_.p;
            u64 b = (d * d + 1) % cfg_.p;
            u64 k = 0;
            for (const auto &item : top) {
                u64 freq = (item.second + 1) % cfg_.p;
                if (freq == 0) freq = 1;
                u64 psi = addm(mulm(a, freq, cfg_.p), mulm(b, invm(freq, cfg_.p), cfg_.p), cfg_.p);
                k = addm(k, mulm(item.first, psi, cfg_.p), cfg_.p);
            }
            out[static_cast<size_t>(d)] = k;
        }
        return out;
    }

    std::vector<u64> zernike(const std::vector<uint8_t> &pixels) const {
        std::vector<u64> out(static_cast<size_t>(cfg_.zernike_orders * 2), 0);
        const u64 cx0 = cfg_.target_width / 2;
        const u64 cy0 = cfg_.target_height / 2;
        for (u64 y = 0; y < cfg_.target_height; ++y) {
            for (u64 x = 0; x < cfg_.target_width; ++x) {
                u64 pix = pixels[static_cast<size_t>(y * cfg_.target_width + x)];
                if (pix == 0) continue;
                u64 cx = (x + cfg_.p - cx0) % cfg_.p;
                u64 cy = (y + cfg_.p - cy0) % cfg_.p;
                u64 r2 = addm(mulm(cx, cx, cfg_.p), mulm(cy, cy, cfg_.p), cfg_.p);
                u64 acc_re = 1, acc_im = 0;
                for (u64 order = 0; order < cfg_.zernike_orders; ++order) {
                    u64 radial = powm(addm(r2, 1, cfg_.p), order + 1, cfg_.p);
                    u64 term_re = mulm(pix, radial, cfg_.p);
                    size_t idx = static_cast<size_t>(order * 2);
                    out[idx] = addm(out[idx], mulm(term_re, acc_re, cfg_.p), cfg_.p);
                    out[idx + 1] = addm(out[idx + 1], mulm(term_re, acc_im, cfg_.p), cfg_.p);
                    u64 next_re = subm(mulm(acc_re, cx, cfg_.p), mulm(acc_im, cy, cfg_.p), cfg_.p);
                    u64 next_im = addm(mulm(acc_re, cy, cfg_.p), mulm(acc_im, cx, cfg_.p), cfg_.p);
                    acc_re = next_re;
                    acc_im = next_im;
                }
            }
        }
        return out;
    }

private:
    FFSCConfig cfg_;
};

class DynamicFFSCEncoder {
public:
    explicit DynamicFFSCEncoder(const FFSCConfig &cfg)
        : cfg_(cfg), ntt_(cfg), features_(cfg), curve_(7, 13, cfg.p) {}

    ECPoint encode_pixels(const std::vector<uint8_t> &pixels) const {
        std::vector<u64> spectrum;
        ntt_.normalize(pixels, spectrum);
        ntt_.forward(spectrum);
        auto k = features_.kloosterman(spectrum);
        auto z = features_.zernike(pixels);
        return project(spectral_hash(k, z));
    }

    ECPoint encode_path(const std::string &path) const {
        auto pixels = load_and_preprocess(path, cfg_);
        if (pixels.empty()) return ECPoint();
        return encode_pixels(pixels);
    }

private:
    FFSCConfig cfg_;
    DynamicNTT2D ntt_;
    DynamicFeatureExtractor features_;
    EllipticCurve curve_;

    u64 spectral_hash(const std::vector<u64> &k, const std::vector<u64> &z) const {
        u64 s = 0, gauss = 0;
        for (u64 c : k) { s = addm(mulm(s, 31337, cfg_.p), c, cfg_.p); gauss = addm(gauss, legendre(c), cfg_.p); }
        for (u64 c : z) { s = addm(mulm(s, 31337, cfg_.p), c, cfg_.p); gauss = addm(gauss, legendre(c), cfg_.p); }
        if (gauss == 0) gauss = 1;
        return mulm(s, gauss, cfg_.p);
    }

    u64 legendre(u64 x) const { return x == 0 ? 0 : powm(x, (cfg_.p - 1) / 2, cfg_.p); }

    ECPoint project(u64 s) const {
        u64 x = s % cfg_.p;
        for (u64 attempt = 0; attempt < 256; ++attempt) {
            u64 rhs = addm(addm(mulm(mulm(x, x, cfg_.p), x, cfg_.p), mulm(7, x, cfg_.p), cfg_.p), 13, cfg_.p);
            u64 y = GF::sqrt_mod(rhs, cfg_.p);
            if (y < cfg_.p) return ECPoint(x, y);
            x = addm(x, 1, cfg_.p);
        }
        return ECPoint();
    }
};

} // namespace ffsc_v2

class ASGTEngineV2 {
public:
    explicit ASGTEngineV2(const FFSCConfig &config)
        : cfg_(config),
          curve_(7, 13, config.p),
          generator_(curve_.find_generator()),
          encoder_(config) {
        validate_config();
        if (generator_.inf) throw std::runtime_error("failed to find FFSC curve generator");
    }

    std::vector<std::string> train_native_batch(
        const std::vector<std::string> &image_paths,
        const std::vector<std::string> &class_labels,
        const std::vector<u64> &sample_weights) {
        if (image_paths.size() != class_labels.size())
            throw std::runtime_error("image_paths and class_labels must have equal length");
        if (!sample_weights.empty() && sample_weights.size() != image_paths.size())
            throw std::runtime_error("sample_weights must be empty or match image_paths length");

        const u64 n = static_cast<u64>(image_paths.size());
        const u64 threads = resolved_threads();
        std::vector<std::future<std::vector<std::pair<size_t, ECPoint>>>> futures;
        std::vector<std::string> skipped;
        std::mutex skipped_mutex;

        u64 chunk = (n + threads - 1) / threads;
        for (u64 t = 0; t < threads; ++t) {
            u64 begin = t * chunk;
            u64 end = std::min<u64>(n, begin + chunk);
            if (begin >= end) continue;
            futures.push_back(std::async(std::launch::async, [&, begin, end]() {
                std::vector<std::pair<size_t, ECPoint>> local;
                local.reserve(static_cast<size_t>(end - begin));
                for (u64 i = begin; i < end; ++i) {
                    ECPoint p = encoder_.encode_path(image_paths[static_cast<size_t>(i)]);
                    if (p.inf) {
                        std::lock_guard<std::mutex> lock(skipped_mutex);
                        skipped.push_back(image_paths[static_cast<size_t>(i)]);
                        continue;
                    }
                    local.push_back({static_cast<size_t>(i), p});
                }
                return local;
            }));
        }

        for (auto &f : futures) {
            auto batch = f.get();
            for (const auto &item : batch) {
                size_t i = item.first;
                u64 weight = sample_weights.empty() ? 1 : sample_weights[i];
                if (weight == 0) weight = 1;
                update_centroid(class_labels[i], item.second, weight);
            }
        }
        return skipped;
    }

    V2ClassResult classify(const std::string &image_path) const {
        ECPoint p = encoder_.encode_path(image_path);
        if (p.inf) return {"", 0, cfg_.p};
        return classify_point(p);
    }

    V2ClassResult classify_pixels(const std::vector<uint8_t> &pixels) const {
        ECPoint p = encoder_.encode_pixels(pixels);
        if (p.inf) return {"", 0, cfg_.p};
        return classify_point(p);
    }

    bool save_weights(const std::string &path) const {
        std::ofstream f(path, std::ios::binary);
        if (!f) return false;
        const char magic[8] = {'A','S','G','T','V','2','0','0'};
        f.write(magic, 8);
        write_config(f);
        ffsc_v2::write_u64(f, static_cast<u64>(classes_.size()));
        for (const auto &kv : classes_) {
            ffsc_v2::write_str(f, kv.first);
            ffsc_v2::write_point(f, kv.second.centroid);
            ffsc_v2::write_u64(f, kv.second.samples);
            ffsc_v2::write_u64(f, kv.second.weight_sum);
        }
        return true;
    }

    bool load_weights(const std::string &path) {
        std::ifstream f(path, std::ios::binary);
        if (!f) return false;
        char magic[8];
        f.read(magic, 8);
        if (std::string(magic, 8) != "ASGTV200") return false;
        FFSCConfig loaded = read_config(f);
        if (loaded.target_width != cfg_.target_width || loaded.target_height != cfg_.target_height ||
            loaded.p != cfg_.p || loaded.g != cfg_.g)
            throw std::runtime_error("weight config does not match engine config");
        classes_.clear();
        u64 n = ffsc_v2::read_u64(f);
        for (u64 i = 0; i < n; ++i) {
            V2ClassState s;
            s.label = ffsc_v2::read_str(f);
            s.centroid = ffsc_v2::read_point(f);
            s.samples = ffsc_v2::read_u64(f);
            s.weight_sum = ffsc_v2::read_u64(f);
            classes_[s.label] = s;
        }
        return true;
    }

    size_t num_classes() const { return classes_.size(); }
    u64 target_width() const { return cfg_.target_width; }
    u64 target_height() const { return cfg_.target_height; }
    u64 prime() const { return cfg_.p; }

    size_t num_samples() const {
        size_t n = 0;
        for (const auto &kv : classes_) n += static_cast<size_t>(kv.second.samples);
        return n;
    }
    std::vector<std::string> class_labels() const {
        std::vector<std::string> labels;
        labels.reserve(classes_.size());
        for (const auto &kv : classes_) labels.push_back(kv.first);
        std::sort(labels.begin(), labels.end());
        return labels;
    }

private:
    FFSCConfig cfg_;
    EllipticCurve curve_;
    ECPoint generator_;
    ffsc_v2::DynamicFFSCEncoder encoder_;
    std::unordered_map<std::string, V2ClassState> classes_;

    void validate_config() const {
        if (cfg_.target_width == 0 || cfg_.target_height == 0) throw std::runtime_error("target dimensions must be positive");
        if (cfg_.top_k == 0 || cfg_.kloosterman_dim == 0 || cfg_.zernike_orders == 0) throw std::runtime_error("feature dimensions must be positive");
        if (cfg_.centroid_momentum_den == 0) throw std::runtime_error("centroid_momentum_den must be positive");
    }

    u64 resolved_threads() const {
        if (cfg_.num_threads > 0) return cfg_.num_threads;
        u64 hw = static_cast<u64>(std::thread::hardware_concurrency());
        return std::max<u64>(1, hw == 0 ? 2 : hw);
    }

    void update_centroid(const std::string &label, const ECPoint &point, u64 weight) {
        auto &state = classes_[label];
        if (state.label.empty()) state.label = label;
        if (state.centroid.inf) {
            state.centroid = point;
        } else {
            u64 den = cfg_.centroid_momentum_den;
            u64 num = std::min<u64>(cfg_.centroid_momentum_num * weight, den);
            u64 old_w = den > num ? den - num : 1;
            ECPoint old_part = curve_.scalar_mul(old_w, state.centroid);
            ECPoint new_part = curve_.scalar_mul(num == 0 ? 1 : num, point);
            state.centroid = curve_.add(old_part, new_part);
        }
        state.samples += 1;
        state.weight_sum += weight;
    }

    V2ClassResult classify_point(const ECPoint &point) const {
        V2ClassResult best{"", 0, cfg_.p};
        bool first = true;
        for (const auto &kv : classes_) {
            u64 dist = ffsc_v2::point_distance(point, kv.second.centroid, cfg_.p);
            if (first || dist < best.distance) {
                first = false;
                best.predicted_class = kv.first;
                best.distance = dist;
                best.confidence = ffsc_v2::distance_to_confidence(dist, cfg_.p);
            }
        }
        return best;
    }

    void write_config(std::ofstream &f) const {
        ffsc_v2::write_u64(f, cfg_.target_width);
        ffsc_v2::write_u64(f, cfg_.target_height);
        ffsc_v2::write_u64(f, cfg_.p);
        ffsc_v2::write_u64(f, cfg_.g);
        ffsc_v2::write_u64(f, cfg_.top_k);
        ffsc_v2::write_u64(f, cfg_.kloosterman_dim);
        ffsc_v2::write_u64(f, cfg_.zernike_orders);
        ffsc_v2::write_u64(f, cfg_.centroid_momentum_num);
        ffsc_v2::write_u64(f, cfg_.centroid_momentum_den);
        ffsc_v2::write_u64(f, cfg_.num_threads);
    }

    static FFSCConfig read_config(std::ifstream &f) {
        FFSCConfig c;
        c.target_width = ffsc_v2::read_u64(f);
        c.target_height = ffsc_v2::read_u64(f);
        c.p = ffsc_v2::read_u64(f);
        c.g = ffsc_v2::read_u64(f);
        c.top_k = ffsc_v2::read_u64(f);
        c.kloosterman_dim = ffsc_v2::read_u64(f);
        c.zernike_orders = ffsc_v2::read_u64(f);
        c.centroid_momentum_num = ffsc_v2::read_u64(f);
        c.centroid_momentum_den = ffsc_v2::read_u64(f);
        c.num_threads = ffsc_v2::read_u64(f);
        return c;
    }
};
