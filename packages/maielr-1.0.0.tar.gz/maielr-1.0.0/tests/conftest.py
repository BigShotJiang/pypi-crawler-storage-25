"""Shared pytest fixtures for the Maielr SDK test suite."""

import pytest

from maielr import Maielr, AsyncMailer


API_KEY = "maielr_test_key.secret123"
BASE_URL = "https://relay.maielr.com"


@pytest.fixture
def api_key() -> str:
    return API_KEY


@pytest.fixture
def client(api_key: str) -> Maielr:
    """Return a synchronous Maielr client with retries disabled for fast tests."""
    return Maielr(api_key=api_key, max_retries=0)


@pytest.fixture
def client_with_retries(api_key: str) -> Maielr:
    """Return a synchronous Maielr client with retries enabled."""
    return Maielr(api_key=api_key, max_retries=3)


@pytest.fixture
def async_client(api_key: str) -> AsyncMailer:
    """Return an async Maielr client with retries disabled for fast tests."""
    return AsyncMailer(api_key=api_key, max_retries=0)
