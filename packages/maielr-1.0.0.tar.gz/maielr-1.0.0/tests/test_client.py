"""
Comprehensive tests for the Maielr Python SDK.

Uses pytest-httpx for mocking httpx requests (both sync and async).
"""

import hashlib
import hmac
import json
import time
import uuid
from typing import Any, Dict
from unittest.mock import patch

import httpx
import pytest
from pytest_httpx import HTTPXMock

from maielr import (
    AsyncMailer,
    Maielr,
    AuthError,
    ConnectionError as MailerConnectionError,
    MailerError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError as MailerTimeoutError,
    ValidationError,
    WebhookVerificationError,
    WebhookVerifier,
)

BASE_URL = "https://relay.maielr.com"
API_KEY = "maielr_test_key.secret123"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _send_response(
    msg_id: str = "msg_abc123",
    status: str = "queued",
) -> Dict[str, Any]:
    return {"id": msg_id, "status": status, "message": "Email queued for delivery"}


def _status_response(msg_id: str = "msg_abc123") -> Dict[str, Any]:
    return {
        "message": {
            "id": msg_id,
            "from_email": "sender@example.com",
            "to": "recipient@example.com",
            "subject": "Hello",
            "status": "delivered",
            "created_at": "2026-01-01T00:00:00Z",
        },
        "events": [
            {"type": "queued", "timestamp": "2026-01-01T00:00:00Z"},
            {"type": "delivered", "timestamp": "2026-01-01T00:00:05Z"},
        ],
    }


def _make_signature(payload: bytes, secret: str, timestamp: int = None) -> str:
    """Helper to create a valid webhook signature for testing."""
    if timestamp is None:
        timestamp = int(time.time())
    signed_content = f"{timestamp}.".encode() + payload
    hash_val = hmac.new(
        secret.encode("utf-8"),
        signed_content,
        hashlib.sha256,
    ).hexdigest()
    return f"t={timestamp},v1={hash_val}"


# ---------------------------------------------------------------------------
# send() tests
# ---------------------------------------------------------------------------

class TestSend:
    def test_send_success(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        result = client.send(
            from_email="sender@example.com",
            to="recipient@example.com",
            subject="Test",
            html="<p>Hello</p>",
        )

        assert result["id"] == "msg_abc123"
        assert result["status"] == "queued"

        # Verify the request payload
        request = httpx_mock.get_request()
        assert request is not None
        body = json.loads(request.content)
        assert body["from"] == "sender@example.com"
        assert body["to"] == "recipient@example.com"
        assert body["subject"] == "Test"
        assert body["html"] == "<p>Hello</p>"

    def test_send_with_all_options(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        result = client.send(
            from_email="sender@example.com",
            to=["a@example.com", "b@example.com"],
            subject="Test",
            html="<p>Hello</p>",
            text="Hello",
            from_name="Test Sender",
            cc="cc@example.com",
            bcc=["bcc1@example.com", "bcc2@example.com"],
            reply_to="reply@example.com",
            headers={"X-Custom": "value"},
            attachments=[{"filename": "test.txt", "content": "aGVsbG8=", "content_type": "text/plain"}],
        )

        assert result["status"] == "queued"

        request = httpx_mock.get_request()
        assert request is not None
        body = json.loads(request.content)
        assert body["from_name"] == "Test Sender"
        assert body["cc"] == "cc@example.com"
        assert body["bcc"] == ["bcc1@example.com", "bcc2@example.com"]
        assert body["reply_to"] == "reply@example.com"
        assert body["headers"] == {"X-Custom": "value"}
        assert len(body["attachments"]) == 1

    def test_send_text_only(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        result = client.send(
            from_email="sender@example.com",
            to="recipient@example.com",
            subject="Test",
            text="Plain text email",
        )

        assert result["status"] == "queued"
        request = httpx_mock.get_request()
        assert request is not None
        body = json.loads(request.content)
        assert body["text"] == "Plain text email"
        assert "html" not in body


# ---------------------------------------------------------------------------
# Error handling tests
# ---------------------------------------------------------------------------

class TestErrors:
    def test_validation_error_400(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Missing required field: to", "details": [{"field": "to", "message": "required"}]},
            status_code=400,
        )

        with pytest.raises(ValidationError) as exc_info:
            client.send(from_email="a@b.com", to="", subject="Test", html="<p>x</p>")

        err = exc_info.value
        assert err.status_code == 400
        assert "Missing required field" in err.message
        assert err.errors is not None

    def test_auth_error_401(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Invalid API key"},
            status_code=401,
        )

        with pytest.raises(AuthError) as exc_info:
            client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        assert exc_info.value.status_code == 401

    def test_auth_error_403(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Forbidden"},
            status_code=403,
        )

        with pytest.raises(AuthError) as exc_info:
            client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        assert exc_info.value.status_code == 403

    def test_not_found_error_404(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/nonexistent",
            method="GET",
            json={"error": "Message not found"},
            status_code=404,
        )

        with pytest.raises(NotFoundError) as exc_info:
            client.get_status("nonexistent")

        assert exc_info.value.status_code == 404

    def test_rate_limit_error_429(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Too many requests", "retry_after": 5},
            status_code=429,
            headers={
                "retry-after": "5",
                "x-ratelimit-limit": "100",
                "x-ratelimit-remaining": "0",
            },
        )

        with pytest.raises(RateLimitError) as exc_info:
            client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        err = exc_info.value
        assert err.status_code == 429
        assert err.retry_after == 5
        assert err.limit == 100
        assert err.remaining == 0

    def test_server_error_500(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Internal server error"},
            status_code=500,
        )

        with pytest.raises(ServerError) as exc_info:
            client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        assert exc_info.value.status_code == 500

    def test_empty_api_key_raises_auth_error(self) -> None:
        with pytest.raises(AuthError):
            Maielr(api_key="")

    def test_request_id_propagated(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Bad request"},
            status_code=400,
            headers={"x-request-id": "req_12345"},
        )

        with pytest.raises(ValidationError) as exc_info:
            client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        assert exc_info.value.request_id == "req_12345"


# ---------------------------------------------------------------------------
# Retry tests
# ---------------------------------------------------------------------------

class TestRetry:
    def test_retry_on_429_then_success(self, httpx_mock: HTTPXMock, api_key: str) -> None:
        """Client retries on 429 and succeeds on the next attempt."""
        client = Maielr(api_key=api_key, max_retries=1)

        # First call returns 429, second returns 200
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Rate limited"},
            status_code=429,
        )
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        with patch("maielr.client.time.sleep") as mock_sleep:
            result = client.send(
                from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>"
            )

        assert result["status"] == "queued"
        mock_sleep.assert_called_once()

    def test_retry_on_500_then_success(self, httpx_mock: HTTPXMock, api_key: str) -> None:
        client = Maielr(api_key=api_key, max_retries=2)

        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Server error"},
            status_code=500,
        )
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        with patch("maielr.client.time.sleep"):
            result = client.send(
                from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>"
            )

        assert result["status"] == "queued"

    def test_retry_exhausted_raises(self, httpx_mock: HTTPXMock, api_key: str) -> None:
        """After max retries are exhausted, the error is raised."""
        client = Maielr(api_key=api_key, max_retries=2)

        for _ in range(3):
            httpx_mock.add_response(
                url=f"{BASE_URL}/v1/email/send",
                method="POST",
                json={"error": "Server error"},
                status_code=502,
            )

        with patch("maielr.client.time.sleep"):
            with pytest.raises(ServerError):
                client.send(
                    from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>"
                )

    def test_retry_jitter_applied(self, httpx_mock: HTTPXMock, api_key: str) -> None:
        """Verify that retry delays include jitter (not exactly power-of-2)."""
        client = Maielr(api_key=api_key, max_retries=2)

        for _ in range(3):
            httpx_mock.add_response(
                url=f"{BASE_URL}/v1/email/send",
                method="POST",
                json={"error": "Server error"},
                status_code=503,
            )

        delays = []
        with patch("maielr.client.time.sleep", side_effect=lambda d: delays.append(d)):
            with pytest.raises(ServerError):
                client.send(
                    from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>"
                )

        # With jitter, delays should be >= base * 2^attempt (the exponential part)
        # and <= base * 2^attempt + base (the jitter part)
        assert len(delays) == 2
        assert 1.0 <= delays[0] <= 2.0  # attempt 0: 1*2^0 + jitter(0, 1)
        assert 2.0 <= delays[1] <= 3.0  # attempt 1: 1*2^1 + jitter(0, 1)

    def test_retry_after_header_override(self, httpx_mock: HTTPXMock, api_key: str) -> None:
        """retry-after header overrides the exponential backoff delay."""
        client = Maielr(api_key=api_key, max_retries=1)

        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Rate limited"},
            status_code=429,
            headers={"retry-after": "10"},
        )
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        delays = []
        with patch("maielr.client.time.sleep", side_effect=lambda d: delays.append(d)):
            result = client.send(
                from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>"
            )

        assert result["status"] == "queued"
        assert delays == [10.0]

    def test_no_retry_on_400(self, httpx_mock: HTTPXMock, api_key: str) -> None:
        """Client should NOT retry on 400 errors."""
        client = Maielr(api_key=api_key, max_retries=3)

        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Validation error"},
            status_code=400,
        )

        with pytest.raises(ValidationError):
            client.send(
                from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>"
            )

        # Only 1 request should have been made (no retries)
        assert len(httpx_mock.get_requests()) == 1


# ---------------------------------------------------------------------------
# Timeout and connection error tests
# ---------------------------------------------------------------------------

class TestTransportErrors:
    def test_timeout_error(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_exception(
            httpx.ReadTimeout("Connection read timed out"),
            url=f"{BASE_URL}/v1/email/send",
        )

        with pytest.raises(MailerTimeoutError):
            client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

    def test_connection_error(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_exception(
            httpx.ConnectError("Connection refused"),
            url=f"{BASE_URL}/v1/email/send",
        )

        with pytest.raises(MailerConnectionError):
            client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

    def test_timeout_retried_then_success(self, httpx_mock: HTTPXMock, api_key: str) -> None:
        client = Maielr(api_key=api_key, max_retries=1)

        httpx_mock.add_exception(
            httpx.ReadTimeout("Timed out"),
            url=f"{BASE_URL}/v1/email/send",
        )
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        with patch("maielr.client.time.sleep"):
            result = client.send(
                from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>"
            )

        assert result["status"] == "queued"

    def test_connection_error_retried_then_success(self, httpx_mock: HTTPXMock, api_key: str) -> None:
        client = Maielr(api_key=api_key, max_retries=1)

        httpx_mock.add_exception(
            httpx.ConnectError("Connection refused"),
            url=f"{BASE_URL}/v1/email/send",
        )
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        with patch("maielr.client.time.sleep"):
            result = client.send(
                from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>"
            )

        assert result["status"] == "queued"

    def test_error_includes_client_request_id(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        """Errors should include the client-generated X-Request-ID."""
        httpx_mock.add_exception(
            httpx.ConnectError("Connection refused"),
            url=f"{BASE_URL}/v1/email/send",
        )

        with pytest.raises(MailerConnectionError) as exc_info:
            client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        # Should have a request_id (UUID format)
        assert exc_info.value.request_id is not None
        uuid.UUID(exc_info.value.request_id)  # validates it's a UUID


# ---------------------------------------------------------------------------
# batch_send() tests
# ---------------------------------------------------------------------------

class TestBatchSend:
    def test_batch_send_multiple(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        for i in range(3):
            httpx_mock.add_response(
                url=f"{BASE_URL}/v1/email/send",
                method="POST",
                json=_send_response(msg_id=f"msg_{i}"),
                status_code=200,
            )

        messages = [
            {"from_email": "a@b.com", "to": f"r{i}@example.com", "subject": f"Test {i}", "html": f"<p>{i}</p>"}
            for i in range(3)
        ]

        results = client.batch_send(messages)
        assert len(results) == 3
        assert results[0]["id"] == "msg_0"
        assert results[2]["id"] == "msg_2"

    def test_batch_send_partial_failure(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(msg_id="msg_0"),
            status_code=200,
        )
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Validation error"},
            status_code=400,
        )

        messages = [
            {"from_email": "a@b.com", "to": "r1@example.com", "subject": "Test 1", "html": "<p>1</p>"},
            {"from_email": "a@b.com", "to": "", "subject": "Test 2", "html": "<p>2</p>"},
        ]

        with pytest.raises(ValidationError):
            client.batch_send(messages)


# ---------------------------------------------------------------------------
# get_status() tests
# ---------------------------------------------------------------------------

class TestGetStatus:
    def test_get_status_success(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/msg_abc123",
            method="GET",
            json=_status_response(),
            status_code=200,
        )

        result = client.get_status("msg_abc123")
        assert result["message"]["status"] == "delivered"
        assert len(result["events"]) == 2

    def test_get_status_not_found(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/nonexistent",
            method="GET",
            json={"error": "Message not found"},
            status_code=404,
        )

        with pytest.raises(NotFoundError):
            client.get_status("nonexistent")


# ---------------------------------------------------------------------------
# list_bounces() tests
# ---------------------------------------------------------------------------

class TestListBounces:
    def test_list_bounces_success(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        bounce_data = {
            "total_sent": 1000,
            "total_bounced": 15,
            "bounce_rate": 0.015,
            "providers": [],
        }

        httpx_mock.add_response(
            url=f"{BASE_URL}/api/relay/bounces/health?days=7",
            method="GET",
            json=bounce_data,
            status_code=200,
        )

        result = client.list_bounces(days=7)
        assert result["total_sent"] == 1000
        assert result["bounce_rate"] == 0.015

    def test_list_bounces_default_days(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/api/relay/bounces/health?days=30",
            method="GET",
            json={"total_sent": 5000, "total_bounced": 50, "bounce_rate": 0.01},
            status_code=200,
        )

        result = client.list_bounces()

        request = httpx_mock.get_request()
        assert request is not None
        assert "days=30" in str(request.url)


# ---------------------------------------------------------------------------
# add_suppression() tests
# ---------------------------------------------------------------------------

class TestAddSuppression:
    def test_add_suppression_success(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/api/relay/suppressions",
            method="POST",
            json={"email": "bounce@example.com", "reason": "manual", "created_at": "2026-01-01T00:00:00Z"},
            status_code=200,
        )

        result = client.add_suppression("bounce@example.com")
        assert result["email"] == "bounce@example.com"

        request = httpx_mock.get_request()
        assert request is not None
        body = json.loads(request.content)
        assert body["email"] == "bounce@example.com"
        assert body["reason"] == "manual"

    def test_add_suppression_custom_reason(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/api/relay/suppressions",
            method="POST",
            json={"email": "spam@example.com", "reason": "complaint", "created_at": "2026-01-01T00:00:00Z"},
            status_code=200,
        )

        result = client.add_suppression("spam@example.com", reason="complaint")
        assert result["reason"] == "complaint"


# ---------------------------------------------------------------------------
# Context manager tests
# ---------------------------------------------------------------------------

class TestContextManager:
    def test_sync_context_manager(self, api_key: str) -> None:
        with Maielr(api_key=api_key) as client:
            assert client.api_key == api_key
        # After exiting, the client should be closed
        assert client._client.is_closed

    @pytest.mark.asyncio
    async def test_async_context_manager(self, api_key: str) -> None:
        async with AsyncMailer(api_key=api_key) as client:
            assert client.api_key == api_key
        assert client._client.is_closed


# ---------------------------------------------------------------------------
# Auth header tests
# ---------------------------------------------------------------------------

class TestHeaders:
    def test_bearer_auth_header(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        request = httpx_mock.get_request()
        assert request is not None
        assert request.headers["authorization"] == f"Bearer {API_KEY}"

    def test_user_agent_header(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        request = httpx_mock.get_request()
        assert request is not None
        assert request.headers["user-agent"].startswith("maielr-python/")

    def test_sdk_version_header(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        """X-SDK-Version header is sent on every request."""
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        request = httpx_mock.get_request()
        assert request is not None
        assert request.headers["x-sdk-version"] == "maielr-python/1.0.0"

    def test_request_id_header(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        """X-Request-ID header is a valid UUID on every request."""
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        request = httpx_mock.get_request()
        assert request is not None
        request_id = request.headers["x-request-id"]
        uuid.UUID(request_id)  # validates format

    def test_sdk_timestamp_header(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        """X-SDK-Timestamp header is an ISO 8601 timestamp."""
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        request = httpx_mock.get_request()
        assert request is not None
        ts = request.headers["x-sdk-timestamp"]
        assert "T" in ts  # ISO 8601 format


# ---------------------------------------------------------------------------
# Idempotency key tests
# ---------------------------------------------------------------------------

class TestIdempotencyKey:
    def test_send_with_idempotency_key(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        idem_key = "test-idem-key-123"
        client.send(
            from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>",
            idempotency_key=idem_key,
        )

        request = httpx_mock.get_request()
        assert request is not None
        assert request.headers["idempotency-key"] == idem_key

    def test_send_without_idempotency_key(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")

        request = httpx_mock.get_request()
        assert request is not None
        assert "idempotency-key" not in request.headers

    def test_generate_idempotency_key(self) -> None:
        key = Maielr.generate_idempotency_key()
        uuid.UUID(key)  # validates it's a UUID
        key2 = Maielr.generate_idempotency_key()
        assert key != key2


# ---------------------------------------------------------------------------
# Per-request timeout tests
# ---------------------------------------------------------------------------

class TestPerRequestTimeout:
    def test_send_with_timeout_override(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        # Should not raise -- just verifying it accepts the param
        result = client.send(
            from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>",
            timeout=5.0,
        )
        assert result["status"] == "queued"


# ---------------------------------------------------------------------------
# Custom HTTP client tests
# ---------------------------------------------------------------------------

class TestCustomHttpClient:
    def test_custom_sync_client(self, httpx_mock: HTTPXMock, api_key: str) -> None:
        custom = httpx.Client(base_url=BASE_URL, timeout=httpx.Timeout(10.0))
        client = Maielr(api_key=api_key, http_client=custom, max_retries=0)

        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        result = client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")
        assert result["status"] == "queued"

        # Auth headers should still be present
        request = httpx_mock.get_request()
        assert request is not None
        assert request.headers["authorization"] == f"Bearer {api_key}"

        # Closing the Maielr client should NOT close the external client
        client.close()
        assert not custom.is_closed
        custom.close()

    @pytest.mark.asyncio
    async def test_custom_async_client(self, httpx_mock: HTTPXMock, api_key: str) -> None:
        custom = httpx.AsyncClient(base_url=BASE_URL, timeout=httpx.Timeout(10.0))
        client = AsyncMailer(api_key=api_key, http_client=custom, max_retries=0)

        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        result = await client.send(from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>")
        assert result["status"] == "queued"

        await client.close()
        assert not custom.is_closed
        await custom.aclose()


# ---------------------------------------------------------------------------
# Debug mode tests
# ---------------------------------------------------------------------------

class TestDebugMode:
    def test_debug_enables_logging(self, api_key: str) -> None:
        import logging as _logging
        client = Maielr(api_key=api_key, debug=True)
        maielr_logger = _logging.getLogger("maielr")
        assert maielr_logger.level == _logging.DEBUG
        client.close()


# ---------------------------------------------------------------------------
# Webhook signature verification tests
# ---------------------------------------------------------------------------

class TestWebhookVerification:
    def test_verify_valid_signature(self) -> None:
        payload = b'{"type":"email.delivered","data":{"id":"msg_123"}}'
        secret = "whsec_test_secret_key"
        signature = _make_signature(payload, secret)

        result = WebhookVerifier.verify_signature(payload, signature, secret)
        assert result is True

    def test_verify_invalid_signature(self) -> None:
        payload = b'{"type":"email.delivered"}'
        secret = "whsec_test_secret_key"
        signature = _make_signature(payload, secret)

        with pytest.raises(WebhookVerificationError, match="Signature mismatch"):
            WebhookVerifier.verify_signature(payload, signature, "wrong_secret")

    def test_verify_expired_signature(self) -> None:
        payload = b'{"type":"email.delivered"}'
        secret = "whsec_test_secret_key"
        old_timestamp = int(time.time()) - 600  # 10 minutes ago
        signature = _make_signature(payload, secret, old_timestamp)

        with pytest.raises(WebhookVerificationError, match="too old"):
            WebhookVerifier.verify_signature(payload, signature, secret, tolerance=300)

    def test_verify_tolerance_zero_disables_check(self) -> None:
        payload = b'{"type":"email.delivered"}'
        secret = "whsec_test_secret_key"
        old_timestamp = int(time.time()) - 86400  # 1 day ago
        signature = _make_signature(payload, secret, old_timestamp)

        # tolerance=0 disables timestamp checking
        result = WebhookVerifier.verify_signature(payload, signature, secret, tolerance=0)
        assert result is True

    def test_verify_missing_signature(self) -> None:
        with pytest.raises(WebhookVerificationError, match="Missing webhook signature"):
            WebhookVerifier.verify_signature(b'{}', "", "secret")

    def test_verify_missing_secret(self) -> None:
        with pytest.raises(WebhookVerificationError, match="Missing webhook secret"):
            WebhookVerifier.verify_signature(b'{}', "t=123,v1=abc", "")

    def test_verify_malformed_signature(self) -> None:
        with pytest.raises(WebhookVerificationError, match="Invalid signature format"):
            WebhookVerifier.verify_signature(b'{}', "garbage", "secret")

    def test_construct_event(self) -> None:
        payload = b'{"type":"email.delivered","data":{"id":"msg_123"}}'
        secret = "whsec_test_secret_key"
        signature = _make_signature(payload, secret)

        event = WebhookVerifier.construct_event(payload, signature, secret)
        assert event["type"] == "email.delivered"
        assert event["data"]["id"] == "msg_123"

    def test_construct_event_invalid_json(self) -> None:
        payload = b'not-json'
        secret = "whsec_test_secret_key"
        signature = _make_signature(payload, secret)

        with pytest.raises(WebhookVerificationError, match="Failed to parse"):
            WebhookVerifier.construct_event(payload, signature, secret)

    def test_client_webhooks_attribute(self, client: Maielr) -> None:
        """Maielr.webhooks is a WebhookVerifier instance."""
        assert isinstance(client.webhooks, WebhookVerifier)


# ---------------------------------------------------------------------------
# Auto-pagination tests
# ---------------------------------------------------------------------------

class TestAutoPagination:
    def test_list_messages_auto_single_page(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            method="GET",
            json={"messages": [{"id": "msg_1"}, {"id": "msg_2"}], "total": 2},
            status_code=200,
        )

        messages = list(client.list_messages_auto(page_size=100))
        assert len(messages) == 2
        assert messages[0]["id"] == "msg_1"

    def test_list_messages_auto_multi_page(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        # Page 1: full page of 2
        httpx_mock.add_response(
            method="GET",
            json={"messages": [{"id": "msg_1"}, {"id": "msg_2"}], "total": 3},
            status_code=200,
        )
        # Page 2: partial page (signals end)
        httpx_mock.add_response(
            method="GET",
            json={"messages": [{"id": "msg_3"}], "total": 3},
            status_code=200,
        )

        messages = list(client.list_messages_auto(page_size=2))
        assert len(messages) == 3
        assert messages[2]["id"] == "msg_3"

    def test_list_messages_auto_empty(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            method="GET",
            json={"messages": [], "total": 0},
            status_code=200,
        )

        messages = list(client.list_messages_auto(page_size=100))
        assert len(messages) == 0

    @pytest.mark.asyncio
    async def test_async_list_messages_auto(self, httpx_mock: HTTPXMock, async_client: AsyncMailer) -> None:
        httpx_mock.add_response(
            method="GET",
            json={"messages": [{"id": "msg_1"}, {"id": "msg_2"}], "total": 3},
            status_code=200,
        )
        httpx_mock.add_response(
            method="GET",
            json={"messages": [{"id": "msg_3"}], "total": 3},
            status_code=200,
        )

        messages = []
        async for msg in await async_client.list_messages_auto(page_size=2):
            messages.append(msg)

        assert len(messages) == 3


# ---------------------------------------------------------------------------
# AsyncMailer tests
# ---------------------------------------------------------------------------

class TestAsyncMailer:
    @pytest.mark.asyncio
    async def test_async_send_success(self, httpx_mock: HTTPXMock, async_client: AsyncMailer) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        result = await async_client.send(
            from_email="sender@example.com",
            to="recipient@example.com",
            subject="Async Test",
            html="<p>Hello Async</p>",
        )

        assert result["id"] == "msg_abc123"
        assert result["status"] == "queued"

    @pytest.mark.asyncio
    async def test_async_get_status(self, httpx_mock: HTTPXMock, async_client: AsyncMailer) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/msg_async123",
            method="GET",
            json=_status_response("msg_async123"),
            status_code=200,
        )

        result = await async_client.get_status("msg_async123")
        assert result["message"]["status"] == "delivered"

    @pytest.mark.asyncio
    async def test_async_list_bounces(self, httpx_mock: HTTPXMock, async_client: AsyncMailer) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/api/relay/bounces/health?days=14",
            method="GET",
            json={"total_sent": 500, "total_bounced": 5, "bounce_rate": 0.01},
            status_code=200,
        )

        result = await async_client.list_bounces(days=14)
        assert result["total_sent"] == 500

    @pytest.mark.asyncio
    async def test_async_add_suppression(self, httpx_mock: HTTPXMock, async_client: AsyncMailer) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/api/relay/suppressions",
            method="POST",
            json={"email": "bad@example.com", "reason": "manual", "created_at": "2026-01-01T00:00:00Z"},
            status_code=200,
        )

        result = await async_client.add_suppression("bad@example.com")
        assert result["email"] == "bad@example.com"

    @pytest.mark.asyncio
    async def test_async_auth_error(self, httpx_mock: HTTPXMock, async_client: AsyncMailer) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json={"error": "Invalid API key"},
            status_code=401,
        )

        with pytest.raises(AuthError):
            await async_client.send(
                from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>"
            )

    @pytest.mark.asyncio
    async def test_async_batch_send(self, httpx_mock: HTTPXMock, async_client: AsyncMailer) -> None:
        for i in range(2):
            httpx_mock.add_response(
                url=f"{BASE_URL}/v1/email/send",
                method="POST",
                json=_send_response(msg_id=f"msg_{i}"),
                status_code=200,
            )

        messages = [
            {"from_email": "a@b.com", "to": f"r{i}@example.com", "subject": f"Test {i}", "html": f"<p>{i}</p>"}
            for i in range(2)
        ]

        results = await async_client.batch_send(messages)
        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_async_send_with_idempotency_key(self, httpx_mock: HTTPXMock, async_client: AsyncMailer) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email/send",
            method="POST",
            json=_send_response(),
            status_code=200,
        )

        await async_client.send(
            from_email="a@b.com", to="c@d.com", subject="Test", html="<p>x</p>",
            idempotency_key="async-idem-key",
        )

        request = httpx_mock.get_request()
        assert request is not None
        assert request.headers["idempotency-key"] == "async-idem-key"


# ---------------------------------------------------------------------------
# Additional endpoint tests
# ---------------------------------------------------------------------------

class TestAdditionalEndpoints:
    def test_list_messages(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/email?limit=20&offset=0",
            method="GET",
            json={"messages": [], "total": 0, "limit": 20, "offset": 0},
            status_code=200,
        )

        result = client.list_messages(limit=20, offset=0)
        assert result["total"] == 0

    def test_get_rate_limit(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/v1/rate-limit",
            method="GET",
            json={"limit": 1000, "used": 42, "remaining": 958},
            status_code=200,
        )

        result = client.get_rate_limit()
        assert result["remaining"] == 958

    def test_get_bounce_stats(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/api/relay/bounces/stats",
            method="GET",
            json={"providers": [{"provider": "gmail", "total": 100}]},
            status_code=200,
        )

        result = client.get_bounce_stats()
        assert result["providers"][0]["provider"] == "gmail"

    def test_get_bounce_trends(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/api/relay/bounces/trends?days=7",
            method="GET",
            json={"trends": [{"date": "2026-01-01", "bounced": 5}]},
            status_code=200,
        )

        result = client.get_bounce_trends(days=7)
        assert len(result["trends"]) == 1

    def test_export_suppressions(self, httpx_mock: HTTPXMock, client: Maielr) -> None:
        httpx_mock.add_response(
            url=f"{BASE_URL}/api/relay/suppressions/export?format=json&reason=bounce",
            method="GET",
            json={"suppressions": [{"email": "x@y.com", "reason": "bounce"}]},
            status_code=200,
        )

        result = client.export_suppressions(format="json", reason="bounce")
        assert len(result["suppressions"]) == 1
