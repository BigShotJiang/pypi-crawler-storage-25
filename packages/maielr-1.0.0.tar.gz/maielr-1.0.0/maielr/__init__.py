"""
Maielr Python SDK
=================

Official Python SDK for the Maielr email relay API.
Send transactional and marketing emails with enterprise-grade deliverability.

Quick start::

    from maielr import Maielr

    mailer = Maielr("your_api_key")
    result = mailer.send(
        from_email="sender@yourdomain.com",
        to="recipient@example.com",
        subject="Hello",
        html="<h1>Hello World</h1>",
    )
    print(result["id"], result["status"])

Async usage::

    from maielr import AsyncMailer

    async with AsyncMailer("your_api_key") as mailer:
        result = await mailer.send(
            from_email="sender@yourdomain.com",
            to="recipient@example.com",
            subject="Hello",
            html="<h1>Hello World</h1>",
        )
"""

from .client import AsyncMailer, Maielr
from .errors import (
    APIError,
    AuthError,
    ConnectionError,
    MailerError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from .webhooks_verify import WebhookVerificationError, WebhookVerifier

__version__ = "1.0.0"

__all__ = [
    # Clients
    "Maielr",
    "AsyncMailer",
    # Errors
    "MailerError",
    "APIError",
    "AuthError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
    "ServerError",
    "ConnectionError",
    "TimeoutError",
    # Webhooks
    "WebhookVerifier",
    "WebhookVerificationError",
    # Version
    "__version__",
]
