"""
Maielr Python SDK - Webhook Signature Verification

Provides HMAC-SHA256 signature verification with timestamp tolerance
to prevent replay attacks. Used to validate incoming webhook payloads
from the Maielr API.
"""

import hashlib
import hmac
import json
import time
from typing import Any, Dict, Optional


class WebhookVerificationError(Exception):
    """Raised when webhook signature verification fails."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class WebhookVerifier:
    """Webhook signature verification utilities.

    Typically accessed via ``Maielr.webhooks`` or used standalone::

        from maielr.webhooks_verify import WebhookVerifier

        verifier = WebhookVerifier()
        event = verifier.construct_event(payload, signature, secret)
    """

    @staticmethod
    def verify_signature(
        payload: bytes,
        signature: str,
        secret: str,
        tolerance: int = 300,
    ) -> bool:
        """Verify an HMAC-SHA256 webhook signature.

        The expected signature format is ``t=<unix_timestamp>,v1=<hex_digest>``.
        The signed content is ``<timestamp>.<payload>``.

        Args:
            payload: Raw request body bytes.
            signature: Value of the ``X-Maielr-Signature`` header.
            secret: The webhook signing secret.
            tolerance: Maximum age of the signature in seconds (default 300).
                Set to 0 to disable timestamp checking.

        Returns:
            ``True`` if the signature is valid.

        Raises:
            WebhookVerificationError: If the signature is missing, malformed,
                expired, or does not match.
        """
        if not signature:
            raise WebhookVerificationError("Missing webhook signature")

        if not secret:
            raise WebhookVerificationError("Missing webhook secret")

        # Parse signature: t=<timestamp>,v1=<hash>
        parts: Dict[str, str] = {}
        for element in signature.split(","):
            if "=" in element:
                key, _, value = element.partition("=")
                parts[key.strip()] = value.strip()

        timestamp_str = parts.get("t")
        signed_hash = parts.get("v1")

        if not timestamp_str or not signed_hash:
            raise WebhookVerificationError(
                "Invalid signature format. Expected 't=<timestamp>,v1=<hash>'"
            )

        try:
            timestamp = int(timestamp_str)
        except ValueError:
            raise WebhookVerificationError(
                f"Invalid timestamp in signature: {timestamp_str}"
            )

        # Check timestamp tolerance (replay attack prevention)
        if tolerance > 0:
            now = int(time.time())
            if abs(now - timestamp) > tolerance:
                raise WebhookVerificationError(
                    f"Signature timestamp too old. Received {timestamp}, "
                    f"current time {now}, tolerance {tolerance}s"
                )

        # Compute expected signature: HMAC-SHA256(secret, "timestamp.payload")
        signed_content = f"{timestamp}.".encode() + payload
        expected_hash = hmac.new(
            secret.encode("utf-8"),
            signed_content,
            hashlib.sha256,
        ).hexdigest()

        # Timing-safe comparison
        if not hmac.compare_digest(expected_hash, signed_hash):
            raise WebhookVerificationError("Signature mismatch")

        return True

    @staticmethod
    def construct_event(
        payload: bytes,
        signature: str,
        secret: str,
        tolerance: int = 300,
    ) -> Dict[str, Any]:
        """Verify a webhook signature and parse the payload as JSON.

        Convenience method that combines :meth:`verify_signature` with
        JSON deserialization.

        Args:
            payload: Raw request body bytes.
            signature: Value of the ``X-Maielr-Signature`` header.
            secret: The webhook signing secret.
            tolerance: Maximum age of the signature in seconds (default 300).

        Returns:
            Parsed JSON event dictionary.

        Raises:
            WebhookVerificationError: If verification fails or payload is
                not valid JSON.
        """
        WebhookVerifier.verify_signature(payload, signature, secret, tolerance)

        try:
            event: Dict[str, Any] = json.loads(payload)
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise WebhookVerificationError(
                f"Failed to parse webhook payload as JSON: {exc}"
            ) from exc

        return event
