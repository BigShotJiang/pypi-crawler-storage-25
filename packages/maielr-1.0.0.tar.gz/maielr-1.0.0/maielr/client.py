"""
Maielr Python SDK - Client

Provides ``Maielr`` (synchronous) and ``AsyncMailer`` (asynchronous) clients
for the Maielr email relay API. Both clients include automatic retry with
exponential backoff and jitter, structured error mapping, full type hints,
per-request timeouts, idempotency keys, request ID tracking, security
headers, custom HTTP client support, and configurable debug logging.
"""

import logging
import random
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Generator, Iterator, List, Optional, Union

import httpx

from .errors import (
    APIError,
    AuthError,
    ConnectionError as MailerConnectionError,
    MailerError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError as MailerTimeoutError,
    ValidationError,
)
from .webhooks_verify import WebhookVerificationError, WebhookVerifier

logger = logging.getLogger("maielr")

__version__ = "1.0.0"

DEFAULT_BASE_URL = "https://relay.maielr.com"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3
USER_AGENT = f"maielr-python/{__version__}"
SDK_VERSION_HEADER = f"maielr-python/{__version__}"

# Retry configuration
RETRY_STATUS_CODES = {429, 500, 502, 503, 504}
RETRY_BASE_DELAY = 1.0  # seconds
MAX_RETRY_DELAY = 30.0


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _error_from_response(
    response: httpx.Response,
    body: Dict[str, Any],
    client_request_id: Optional[str] = None,
) -> MailerError:
    """Map an HTTP error response to the correct SDK exception."""
    status = response.status_code
    request_id = response.headers.get("x-request-id") or client_request_id
    message = (
        body.get("error")
        or body.get("message")
        or response.reason_phrase
        or "Unknown error"
    )
    if isinstance(message, dict):
        message = str(message)

    kwargs: Dict[str, Any] = dict(
        message=str(message),
        status_code=status,
        body=body,
        request_id=request_id,
    )

    if status == 400:
        return ValidationError(**kwargs, errors=body.get("details"))
    if status in (401, 403):
        return AuthError(**kwargs)
    if status == 404:
        return NotFoundError(**kwargs)
    if status == 429:
        retry_after = _parse_int(response.headers.get("retry-after")) or _parse_int(body.get("retry_after"))
        limit = _parse_int(response.headers.get("x-ratelimit-limit"))
        remaining = _parse_int(response.headers.get("x-ratelimit-remaining"))
        return RateLimitError(**kwargs, retry_after=retry_after, limit=limit, remaining=remaining)
    if 500 <= status < 600:
        return ServerError(**kwargs)

    return APIError(**kwargs)


def _parse_int(value: Any) -> Optional[int]:
    """Safely parse an integer from a header or body value."""
    if value is None:
        return None
    try:
        return int(value)
    except (ValueError, TypeError):
        return None


def _retry_delay(attempt: int, retry_after: Optional[int] = None) -> float:
    """Return the delay in seconds for a given retry attempt with jitter.

    Uses exponential backoff with random jitter:
    ``delay = base_delay * (2 ** attempt) + random.uniform(0, base_delay)``
    Capped at 30 seconds. If ``retry_after`` is provided (from a 429 response),
    it takes precedence but is still capped.
    """
    if retry_after is not None and retry_after > 0:
        return min(float(retry_after), MAX_RETRY_DELAY)
    delay = RETRY_BASE_DELAY * (2 ** attempt) + random.uniform(0, RETRY_BASE_DELAY)
    return min(delay, MAX_RETRY_DELAY)


def _build_send_payload(
    from_email: str,
    to: Union[str, List[str]],
    subject: str,
    html: Optional[str] = None,
    text: Optional[str] = None,
    from_name: Optional[str] = None,
    cc: Optional[Union[str, List[str]]] = None,
    bcc: Optional[Union[str, List[str]]] = None,
    reply_to: Optional[str] = None,
    headers: Optional[Dict[str, str]] = None,
    attachments: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Build the JSON payload for POST /v1/email/send."""
    payload: Dict[str, Any] = {
        "from": from_email,
        "to": to,
        "subject": subject,
    }
    if from_name is not None:
        payload["from_name"] = from_name
    if html is not None:
        payload["html"] = html
    if text is not None:
        payload["text"] = text
    if cc is not None:
        payload["cc"] = cc
    if bcc is not None:
        payload["bcc"] = bcc
    if reply_to is not None:
        payload["reply_to"] = reply_to
    if headers is not None:
        payload["headers"] = headers
    if attachments is not None:
        payload["attachments"] = attachments
    return payload


# ---------------------------------------------------------------------------
# Base Client
# ---------------------------------------------------------------------------

class _BaseClient:
    """Shared configuration for sync and async clients."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        debug: bool = False,
        http_client: Any = None,
    ) -> None:
        if not api_key:
            raise AuthError("API key is required. Pass your Maielr API key.")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._debug = debug
        self._external_client = http_client is not None

        if debug:
            logger.setLevel(logging.DEBUG)
            if not logger.handlers:
                handler = logging.StreamHandler()
                handler.setFormatter(
                    logging.Formatter("[maielr %(levelname)s] %(message)s")
                )
                logger.addHandler(handler)

        # Webhook verifier instance
        self.webhooks = WebhookVerifier()

    def _build_headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": USER_AGENT,
            "X-SDK-Version": SDK_VERSION_HEADER,
        }

    @staticmethod
    def generate_idempotency_key() -> str:
        """Generate a unique idempotency key using uuid4.

        Returns:
            A new UUID string suitable for use as an ``Idempotency-Key`` header.
        """
        return str(uuid.uuid4())

    def _make_request_headers(
        self,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, str]:
        """Build per-request headers including request ID and security headers."""
        headers: Dict[str, str] = {
            "X-Request-ID": str(uuid.uuid4()),
            "X-SDK-Timestamp": datetime.now(timezone.utc).isoformat(),
        }
        if idempotency_key is not None:
            headers["Idempotency-Key"] = idempotency_key
        return headers


# ---------------------------------------------------------------------------
# Synchronous Client
# ---------------------------------------------------------------------------

class Maielr(_BaseClient):
    """Synchronous Maielr client.

    Usage::

        from maielr import Maielr

        mailer = Maielr("your_api_key")
        result = mailer.send(
            from_email="sender@yourdomain.com",
            to="recipient@example.com",
            subject="Hello",
            html="<h1>Hello World</h1>",
        )
        print(result)  # {"id": "...", "status": "queued", "message": "..."}

    Args:
        api_key: Your Maielr API key.
        base_url: API base URL. Defaults to ``https://relay.maielr.com``.
        timeout: Request timeout in seconds. Defaults to 30.
        max_retries: Maximum retry attempts for transient failures. Defaults to 3.
        debug: Enable debug logging. Defaults to False.
        http_client: Optional pre-configured ``httpx.Client``. If provided,
            the SDK will use it instead of creating its own. Auth headers
            are still added per-request.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        debug: bool = False,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        super().__init__(api_key, base_url, timeout, max_retries, debug, http_client)
        if http_client is not None:
            self._client = http_client
        else:
            self._client = httpx.Client(
                base_url=self.base_url,
                headers=self._build_headers(),
                timeout=httpx.Timeout(self.timeout),
            )

    # -- low-level request ---------------------------------------------------

    def request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Execute an HTTP request with retry logic.

        Args:
            method: HTTP method (GET, POST, PUT, PATCH, DELETE).
            path: API path (e.g., ``/v1/email/send``).
            json: Request body as a dictionary.
            params: Query parameters.
            idempotency_key: Optional idempotency key for POST requests.
            timeout: Optional per-request timeout override in seconds.

        Returns:
            Parsed JSON response body.

        Raises:
            MailerError: On any API or transport error after retries.
        """
        if params:
            params = {k: v for k, v in params.items() if v is not None}

        request_headers = self._make_request_headers(idempotency_key)
        client_request_id = request_headers["X-Request-ID"]

        # Per-request timeout override
        request_timeout = httpx.Timeout(timeout) if timeout is not None else None

        # If using an external client, add auth headers per-request
        if self._external_client:
            request_headers.update(self._build_headers())

        last_error: Optional[Exception] = None

        start_time = time.monotonic()

        for attempt in range(self.max_retries + 1):
            try:
                logger.debug(
                    "Request: %s %s (attempt %d/%d, request_id=%s)",
                    method, path, attempt + 1, self.max_retries + 1, client_request_id,
                )

                response = self._client.request(
                    method=method,
                    url=path,
                    json=json,
                    params=params,
                    headers=request_headers,
                    timeout=request_timeout,
                )

                elapsed = time.monotonic() - start_time
                logger.debug(
                    "Response: %s %s -> %d (%.3fs)",
                    method, path, response.status_code, elapsed,
                )

                if response.status_code == 204:
                    return {}

                try:
                    body: Dict[str, Any] = response.json()
                except Exception:
                    body = {"error": response.text}

                if response.is_success:
                    return body

                error = _error_from_response(response, body, client_request_id)

                if response.status_code in RETRY_STATUS_CODES and attempt < self.max_retries:
                    ra = error.retry_after if isinstance(error, RateLimitError) else None
                    delay = _retry_delay(attempt, ra)
                    logger.info(
                        "Retrying %s %s (attempt %d/%d) after %.1fs (request_id=%s)",
                        method, path, attempt + 1, self.max_retries, delay,
                        client_request_id,
                    )
                    time.sleep(delay)
                    last_error = error
                    continue

                raise error

            except httpx.ConnectError as exc:
                if attempt < self.max_retries:
                    delay = _retry_delay(attempt)
                    logger.info(
                        "Connection error on %s %s, retrying (%d/%d) after %.1fs",
                        method, path, attempt + 1, self.max_retries, delay,
                    )
                    time.sleep(delay)
                    last_error = exc
                    continue
                raise MailerConnectionError(
                    message=f"Failed to connect to {self.base_url}: {exc}",
                    request_id=client_request_id,
                ) from exc

            except httpx.TimeoutException as exc:
                if attempt < self.max_retries:
                    delay = _retry_delay(attempt)
                    logger.info(
                        "Timeout on %s %s, retrying (%d/%d) after %.1fs",
                        method, path, attempt + 1, self.max_retries, delay,
                    )
                    time.sleep(delay)
                    last_error = exc
                    continue
                raise MailerTimeoutError(
                    message=f"Request timed out after {timeout or self.timeout}s: {method} {path}",
                    request_id=client_request_id,
                ) from exc

        if last_error:
            if isinstance(last_error, MailerError):
                raise last_error
            raise MailerError(
                message=f"Max retries ({self.max_retries}) exhausted: {last_error}",
                request_id=client_request_id,
            ) from last_error
        raise MailerError(
            "Unexpected error: no response received",
            request_id=client_request_id,
        )

    # -- high-level methods --------------------------------------------------

    def send(
        self,
        from_email: str,
        to: Union[str, List[str]],
        subject: str,
        html: Optional[str] = None,
        text: Optional[str] = None,
        *,
        from_name: Optional[str] = None,
        cc: Optional[Union[str, List[str]]] = None,
        bcc: Optional[Union[str, List[str]]] = None,
        reply_to: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        attachments: Optional[List[Dict[str, Any]]] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Send a single email.

        Args:
            from_email: Sender email address.
            to: Recipient address or list of addresses.
            subject: Email subject line.
            html: HTML body content.
            text: Plain-text body content.
            from_name: Display name for the sender.
            cc: CC recipient(s).
            bcc: BCC recipient(s).
            reply_to: Reply-to address.
            headers: Additional email headers.
            attachments: List of attachment dicts with ``filename``, ``content``, ``content_type``.
            idempotency_key: Optional idempotency key to prevent duplicate sends.
            timeout: Optional per-request timeout override in seconds.

        Returns:
            API response with ``id``, ``status``, and ``message`` keys.
        """
        payload = _build_send_payload(
            from_email=from_email,
            to=to,
            subject=subject,
            html=html,
            text=text,
            from_name=from_name,
            cc=cc,
            bcc=bcc,
            reply_to=reply_to,
            headers=headers,
            attachments=attachments,
        )
        return self.request(
            "POST", "/v1/email/send",
            json=payload,
            idempotency_key=idempotency_key,
            timeout=timeout,
        )

    def batch_send(
        self,
        messages: List[Dict[str, Any]],
        *,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> List[Dict[str, Any]]:
        """Send a batch of emails sequentially.

        Each message dict should contain the same keys accepted by
        :meth:`send` (``from_email``, ``to``, ``subject``, etc.).

        Args:
            messages: List of message parameter dicts.
            idempotency_key: Optional idempotency key for the batch.
            timeout: Optional per-request timeout override in seconds.

        Returns:
            List of API responses, one per message.
        """
        results: List[Dict[str, Any]] = []
        for msg in messages:
            result = self.send(
                from_email=msg["from_email"],
                to=msg["to"],
                subject=msg["subject"],
                html=msg.get("html"),
                text=msg.get("text"),
                from_name=msg.get("from_name"),
                cc=msg.get("cc"),
                bcc=msg.get("bcc"),
                reply_to=msg.get("reply_to"),
                headers=msg.get("headers"),
                attachments=msg.get("attachments"),
                idempotency_key=msg.get("idempotency_key") or idempotency_key,
                timeout=timeout,
            )
            results.append(result)
        return results

    def get_status(
        self,
        message_id: str,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get the status and events for a sent message.

        Args:
            message_id: The message ID returned by :meth:`send`.
            timeout: Optional per-request timeout override in seconds.

        Returns:
            Message details with events.
        """
        return self.request("GET", f"/v1/email/{message_id}", timeout=timeout)

    def list_messages(
        self,
        limit: int = 20,
        offset: int = 0,
        status: Optional[str] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """List sent messages with pagination.

        Args:
            limit: Number of messages to return (default 20).
            offset: Pagination offset.
            status: Filter by message status.
            timeout: Optional per-request timeout override in seconds.

        Returns:
            Paginated list of messages.
        """
        return self.request("GET", "/v1/email", params={
            "limit": limit,
            "offset": offset,
            "status": status,
        }, timeout=timeout)

    def list_messages_auto(
        self,
        status: Optional[str] = None,
        page_size: int = 100,
        *,
        timeout: Optional[float] = None,
    ) -> Generator[Dict[str, Any], None, None]:
        """Auto-paginating iterator over all messages.

        Yields individual message dicts, automatically fetching subsequent
        pages until all results are returned.

        Args:
            status: Filter by message status.
            page_size: Number of messages per page (default 100).
            timeout: Optional per-request timeout override in seconds.

        Yields:
            Individual message dictionaries.
        """
        offset = 0
        while True:
            page = self.list_messages(
                limit=page_size, offset=offset, status=status, timeout=timeout,
            )
            messages = page.get("messages", [])
            for msg in messages:
                yield msg
            if len(messages) < page_size:
                break
            offset += page_size

    def get_rate_limit(
        self,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Check current rate limit status.

        Returns:
            Rate limit info with ``limit``, ``used``, ``remaining``, etc.
        """
        return self.request("GET", "/v1/rate-limit", timeout=timeout)

    def list_bounces(
        self,
        days: int = 30,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get bounce health summary.

        Args:
            days: Number of days to look back (default 30).
            timeout: Optional per-request timeout override in seconds.

        Returns:
            Bounce health data.
        """
        return self.request("GET", "/api/relay/bounces/health", params={"days": days}, timeout=timeout)

    def get_bounce_stats(
        self,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get bounce statistics by provider.

        Returns:
            Bounce stats breakdown.
        """
        return self.request("GET", "/api/relay/bounces/stats", timeout=timeout)

    def get_bounce_trends(
        self,
        days: int = 30,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get bounce trends over time.

        Args:
            days: Number of days to look back (default 30).
            timeout: Optional per-request timeout override in seconds.

        Returns:
            Bounce trend data.
        """
        return self.request("GET", "/api/relay/bounces/trends", params={"days": days}, timeout=timeout)

    def add_suppression(
        self,
        email: str,
        reason: str = "manual",
        *,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Add an email address to the suppression list.

        Args:
            email: Email address to suppress.
            reason: Suppression reason (default ``"manual"``).
            idempotency_key: Optional idempotency key.
            timeout: Optional per-request timeout override in seconds.

        Returns:
            API confirmation.
        """
        return self.request("POST", "/api/relay/suppressions", json={
            "email": email,
            "reason": reason,
        }, idempotency_key=idempotency_key, timeout=timeout)

    def export_suppressions(
        self,
        format: str = "json",
        reason: Optional[str] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Export the suppression list.

        Args:
            format: Export format — ``"json"`` or ``"csv"``.
            reason: Filter by suppression reason.
            timeout: Optional per-request timeout override in seconds.

        Returns:
            Suppression list data.
        """
        return self.request("GET", "/api/relay/suppressions/export", params={
            "format": format,
            "reason": reason,
        }, timeout=timeout)

    # -- lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client and release resources."""
        if not self._external_client:
            self._client.close()

    def __enter__(self) -> "Maielr":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Asynchronous Client
# ---------------------------------------------------------------------------

class AsyncMailer(_BaseClient):
    """Asynchronous Maielr client.

    Usage::

        import asyncio
        from maielr import AsyncMailer

        async def main():
            async with AsyncMailer("your_api_key") as mailer:
                result = await mailer.send(
                    from_email="sender@yourdomain.com",
                    to="recipient@example.com",
                    subject="Hello",
                    html="<h1>Hello World</h1>",
                )
                print(result)

        asyncio.run(main())

    Args:
        api_key: Your Maielr API key.
        base_url: API base URL. Defaults to ``https://relay.maielr.com``.
        timeout: Request timeout in seconds. Defaults to 30.
        max_retries: Maximum retry attempts for transient failures. Defaults to 3.
        debug: Enable debug logging. Defaults to False.
        http_client: Optional pre-configured ``httpx.AsyncClient``. If provided,
            the SDK will use it instead of creating its own.

    Note:
        ``AsyncMailer`` should be used within an asyncio event loop.
        It is not thread-safe. For multi-threaded applications, use the
        synchronous ``Maielr`` client or create one ``AsyncMailer`` per
        event loop.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        debug: bool = False,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        super().__init__(api_key, base_url, timeout, max_retries, debug, http_client)
        if http_client is not None:
            self._client = http_client
        else:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=self._build_headers(),
                timeout=httpx.Timeout(self.timeout),
            )

    # -- low-level request ---------------------------------------------------

    async def request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Execute an async HTTP request with retry logic.

        Args:
            method: HTTP method (GET, POST, PUT, PATCH, DELETE).
            path: API path (e.g., ``/v1/email/send``).
            json: Request body as a dictionary.
            params: Query parameters.
            idempotency_key: Optional idempotency key for POST requests.
            timeout: Optional per-request timeout override in seconds.

        Returns:
            Parsed JSON response body.

        Raises:
            MailerError: On any API or transport error after retries.
        """
        import asyncio as _asyncio

        if params:
            params = {k: v for k, v in params.items() if v is not None}

        request_headers = self._make_request_headers(idempotency_key)
        client_request_id = request_headers["X-Request-ID"]

        request_timeout = httpx.Timeout(timeout) if timeout is not None else None

        if self._external_client:
            request_headers.update(self._build_headers())

        last_error: Optional[Exception] = None

        start_time = time.monotonic()

        for attempt in range(self.max_retries + 1):
            try:
                logger.debug(
                    "Request: %s %s (attempt %d/%d, request_id=%s)",
                    method, path, attempt + 1, self.max_retries + 1, client_request_id,
                )

                response = await self._client.request(
                    method=method,
                    url=path,
                    json=json,
                    params=params,
                    headers=request_headers,
                    timeout=request_timeout,
                )

                elapsed = time.monotonic() - start_time
                logger.debug(
                    "Response: %s %s -> %d (%.3fs)",
                    method, path, response.status_code, elapsed,
                )

                if response.status_code == 204:
                    return {}

                try:
                    body: Dict[str, Any] = response.json()
                except Exception:
                    body = {"error": response.text}

                if response.is_success:
                    return body

                error = _error_from_response(response, body, client_request_id)

                if response.status_code in RETRY_STATUS_CODES and attempt < self.max_retries:
                    ra = error.retry_after if isinstance(error, RateLimitError) else None
                    delay = _retry_delay(attempt, ra)
                    logger.info(
                        "Retrying %s %s (attempt %d/%d) after %.1fs (request_id=%s)",
                        method, path, attempt + 1, self.max_retries, delay,
                        client_request_id,
                    )
                    await _asyncio.sleep(delay)
                    last_error = error
                    continue

                raise error

            except httpx.ConnectError as exc:
                if attempt < self.max_retries:
                    delay = _retry_delay(attempt)
                    logger.info(
                        "Connection error on %s %s, retrying (%d/%d) after %.1fs",
                        method, path, attempt + 1, self.max_retries, delay,
                    )
                    await _asyncio.sleep(delay)
                    last_error = exc
                    continue
                raise MailerConnectionError(
                    message=f"Failed to connect to {self.base_url}: {exc}",
                    request_id=client_request_id,
                ) from exc

            except httpx.TimeoutException as exc:
                if attempt < self.max_retries:
                    delay = _retry_delay(attempt)
                    logger.info(
                        "Timeout on %s %s, retrying (%d/%d) after %.1fs",
                        method, path, attempt + 1, self.max_retries, delay,
                    )
                    await _asyncio.sleep(delay)
                    last_error = exc
                    continue
                raise MailerTimeoutError(
                    message=f"Request timed out after {timeout or self.timeout}s: {method} {path}",
                    request_id=client_request_id,
                ) from exc

        if last_error:
            if isinstance(last_error, MailerError):
                raise last_error
            raise MailerError(
                message=f"Max retries ({self.max_retries}) exhausted: {last_error}",
                request_id=client_request_id,
            ) from last_error
        raise MailerError(
            "Unexpected error: no response received",
            request_id=client_request_id,
        )

    # -- high-level methods --------------------------------------------------

    async def send(
        self,
        from_email: str,
        to: Union[str, List[str]],
        subject: str,
        html: Optional[str] = None,
        text: Optional[str] = None,
        *,
        from_name: Optional[str] = None,
        cc: Optional[Union[str, List[str]]] = None,
        bcc: Optional[Union[str, List[str]]] = None,
        reply_to: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        attachments: Optional[List[Dict[str, Any]]] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Send a single email (async).

        Args:
            from_email: Sender email address.
            to: Recipient address or list of addresses.
            subject: Email subject line.
            html: HTML body content.
            text: Plain-text body content.
            from_name: Display name for the sender.
            cc: CC recipient(s).
            bcc: BCC recipient(s).
            reply_to: Reply-to address.
            headers: Additional email headers.
            attachments: List of attachment dicts.
            idempotency_key: Optional idempotency key to prevent duplicate sends.
            timeout: Optional per-request timeout override in seconds.
        """
        payload = _build_send_payload(
            from_email=from_email,
            to=to,
            subject=subject,
            html=html,
            text=text,
            from_name=from_name,
            cc=cc,
            bcc=bcc,
            reply_to=reply_to,
            headers=headers,
            attachments=attachments,
        )
        return await self.request(
            "POST", "/v1/email/send",
            json=payload,
            idempotency_key=idempotency_key,
            timeout=timeout,
        )

    async def batch_send(
        self,
        messages: List[Dict[str, Any]],
        *,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> List[Dict[str, Any]]:
        """Send a batch of emails sequentially (async).

        Args:
            messages: List of message parameter dicts.
            idempotency_key: Optional idempotency key for the batch.
            timeout: Optional per-request timeout override in seconds.
        """
        results: List[Dict[str, Any]] = []
        for msg in messages:
            result = await self.send(
                from_email=msg["from_email"],
                to=msg["to"],
                subject=msg["subject"],
                html=msg.get("html"),
                text=msg.get("text"),
                from_name=msg.get("from_name"),
                cc=msg.get("cc"),
                bcc=msg.get("bcc"),
                reply_to=msg.get("reply_to"),
                headers=msg.get("headers"),
                attachments=msg.get("attachments"),
                idempotency_key=msg.get("idempotency_key") or idempotency_key,
                timeout=timeout,
            )
            results.append(result)
        return results

    async def get_status(
        self,
        message_id: str,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get the status and events for a sent message (async)."""
        return await self.request("GET", f"/v1/email/{message_id}", timeout=timeout)

    async def list_messages(
        self,
        limit: int = 20,
        offset: int = 0,
        status: Optional[str] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """List sent messages with pagination (async)."""
        return await self.request("GET", "/v1/email", params={
            "limit": limit,
            "offset": offset,
            "status": status,
        }, timeout=timeout)

    async def list_messages_auto(
        self,
        status: Optional[str] = None,
        page_size: int = 100,
        *,
        timeout: Optional[float] = None,
    ) -> "AsyncMessageIterator":
        """Auto-paginating async iterator over all messages.

        Usage::

            async for msg in await client.list_messages_auto():
                print(msg["id"])

        Args:
            status: Filter by message status.
            page_size: Number of messages per page (default 100).
            timeout: Optional per-request timeout override in seconds.

        Returns:
            An async iterator that yields individual message dictionaries.
        """
        return AsyncMessageIterator(self, status=status, page_size=page_size, timeout=timeout)

    async def get_rate_limit(
        self,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Check current rate limit status (async)."""
        return await self.request("GET", "/v1/rate-limit", timeout=timeout)

    async def list_bounces(
        self,
        days: int = 30,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get bounce health summary (async)."""
        return await self.request("GET", "/api/relay/bounces/health", params={"days": days}, timeout=timeout)

    async def get_bounce_stats(
        self,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get bounce statistics by provider (async)."""
        return await self.request("GET", "/api/relay/bounces/stats", timeout=timeout)

    async def get_bounce_trends(
        self,
        days: int = 30,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get bounce trends over time (async)."""
        return await self.request("GET", "/api/relay/bounces/trends", params={"days": days}, timeout=timeout)

    async def add_suppression(
        self,
        email: str,
        reason: str = "manual",
        *,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Add an email address to the suppression list (async)."""
        return await self.request("POST", "/api/relay/suppressions", json={
            "email": email,
            "reason": reason,
        }, idempotency_key=idempotency_key, timeout=timeout)

    async def export_suppressions(
        self,
        format: str = "json",
        reason: Optional[str] = None,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Export the suppression list (async)."""
        return await self.request("GET", "/api/relay/suppressions/export", params={
            "format": format,
            "reason": reason,
        }, timeout=timeout)

    # -- lifecycle -----------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying HTTP client and release resources."""
        if not self._external_client:
            await self._client.aclose()

    async def __aenter__(self) -> "AsyncMailer":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()


# ---------------------------------------------------------------------------
# Async auto-pagination iterator
# ---------------------------------------------------------------------------

class AsyncMessageIterator:
    """Async iterator for auto-paginated message listing."""

    def __init__(
        self,
        client: AsyncMailer,
        status: Optional[str] = None,
        page_size: int = 100,
        timeout: Optional[float] = None,
    ) -> None:
        self._client = client
        self._status = status
        self._page_size = page_size
        self._timeout = timeout
        self._offset = 0
        self._buffer: List[Dict[str, Any]] = []
        self._exhausted = False

    def __aiter__(self) -> "AsyncMessageIterator":
        return self

    async def __anext__(self) -> Dict[str, Any]:
        if not self._buffer:
            if self._exhausted:
                raise StopAsyncIteration

            page = await self._client.list_messages(
                limit=self._page_size,
                offset=self._offset,
                status=self._status,
                timeout=self._timeout,
            )
            messages = page.get("messages", [])
            if not messages:
                raise StopAsyncIteration

            self._buffer = messages
            self._offset += self._page_size

            if len(messages) < self._page_size:
                self._exhausted = True

        return self._buffer.pop(0)
