"""
Maielr Python SDK - Type Definitions

TypedDict classes for structured request and response typing.
Compatible with Python 3.8+ via typing_extensions fallback.
"""

import sys
from typing import Any, Dict, List, Optional, Union

if sys.version_info >= (3, 8):
    from typing import TypedDict
else:
    from typing_extensions import TypedDict


# ---------------------------------------------------------------------------
# Attachment
# ---------------------------------------------------------------------------

class Attachment(TypedDict, total=False):
    """Email attachment.

    Attributes:
        filename: The attachment filename (e.g., ``report.pdf``).
        content: Base64-encoded file content.
        content_type: MIME type (e.g., ``application/pdf``).
    """
    filename: str
    content: str
    content_type: str


# ---------------------------------------------------------------------------
# Send Email
# ---------------------------------------------------------------------------

class SendEmailParams(TypedDict, total=False):
    """Parameters for sending a single email.

    Required keys: ``from_email``, ``to``, ``subject``, and at least
    one of ``html`` or ``text``.
    """
    from_email: str
    from_name: Optional[str]
    to: Union[str, List[str]]
    cc: Union[str, List[str], None]
    bcc: Union[str, List[str], None]
    subject: str
    html: Optional[str]
    text: Optional[str]
    reply_to: Optional[str]
    headers: Optional[Dict[str, str]]
    attachments: Optional[List[Attachment]]


class SendEmailResponse(TypedDict):
    """Response from the send email endpoint."""
    id: str
    status: str
    message: str


# ---------------------------------------------------------------------------
# Email Status / Detail
# ---------------------------------------------------------------------------

class EmailEvent(TypedDict, total=False):
    """An event associated with an email message."""
    type: str
    timestamp: str
    data: Optional[Dict[str, Any]]


class EmailMessage(TypedDict, total=False):
    """An email message record returned from the API."""
    id: str
    from_email: str
    to: str
    cc: Optional[str]
    bcc: Optional[str]
    subject: str
    status: str
    error: Optional[str]
    smtp_response: Optional[str]
    created_at: str
    sent_at: Optional[str]
    delivered_at: Optional[str]


class EmailDetailResponse(TypedDict, total=False):
    """Response from GET /v1/email/:id — single message with events."""
    message: EmailMessage
    events: List[EmailEvent]


class EmailListResponse(TypedDict, total=False):
    """Response from GET /v1/email — paginated message list."""
    messages: List[EmailMessage]
    total: int
    limit: int
    offset: int


# ---------------------------------------------------------------------------
# Rate Limit
# ---------------------------------------------------------------------------

class RateLimitInfo(TypedDict, total=False):
    """Rate limit status returned by GET /v1/rate-limit."""
    limit: int
    used: int
    remaining: int
    reset_at: str
    window_seconds: int


# ---------------------------------------------------------------------------
# Bounce / Health
# ---------------------------------------------------------------------------

class BounceStats(TypedDict, total=False):
    """Bounce statistics by provider."""
    provider: str
    total: int
    hard_bounces: int
    soft_bounces: int
    bounce_rate: float


class BounceHealth(TypedDict, total=False):
    """Bounce health summary."""
    total_sent: int
    total_bounced: int
    bounce_rate: float
    providers: List[BounceStats]


class BounceTrend(TypedDict, total=False):
    """Daily bounce trend data point."""
    date: str
    sent: int
    bounced: int
    bounce_rate: float


# ---------------------------------------------------------------------------
# Suppression
# ---------------------------------------------------------------------------

class SuppressionEntry(TypedDict, total=False):
    """A suppression list entry."""
    email: str
    reason: str
    created_at: str


class AddSuppressionParams(TypedDict, total=False):
    """Parameters for adding an address to the suppression list."""
    email: str
    reason: str


class BatchMessage(TypedDict, total=False):
    """A single message in a batch send request.

    Mirrors ``SendEmailParams`` but as a plain dict for batch iteration.
    """
    from_email: str
    from_name: Optional[str]
    to: Union[str, List[str]]
    cc: Union[str, List[str], None]
    bcc: Union[str, List[str], None]
    subject: str
    html: Optional[str]
    text: Optional[str]
    reply_to: Optional[str]
    headers: Optional[Dict[str, str]]
    attachments: Optional[List[Attachment]]
