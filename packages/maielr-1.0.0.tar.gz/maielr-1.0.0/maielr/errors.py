"""
Maielr Python SDK - Error Hierarchy

Structured exception classes for precise error handling. Every error
carries the HTTP status code, parsed response body, and request ID
so callers can log, retry, or surface actionable messages.
"""

from typing import Any, Dict, List, Optional, Union


class MailerError(Exception):
    """Base exception for all Maielr SDK errors.

    Attributes:
        message: Human-readable error description.
        status_code: HTTP status code from the API response, if available.
        body: Parsed JSON body from the API response.
        request_id: Server-assigned request ID for support debugging.
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        body: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.body: Dict[str, Any] = body or {}
        self.request_id = request_id
        super().__init__(self.message)

    def __repr__(self) -> str:
        parts = [f"message={self.message!r}"]
        if self.status_code is not None:
            parts.append(f"status_code={self.status_code}")
        if self.request_id:
            parts.append(f"request_id={self.request_id!r}")
        return f"{self.__class__.__name__}({', '.join(parts)})"


class APIError(MailerError):
    """Generic API error for unmapped status codes."""
    pass


class AuthError(MailerError):
    """Raised on HTTP 401 or 403 — invalid, expired, or revoked API key."""

    def __init__(
        self,
        message: str = "Authentication failed. Check your API key.",
        status_code: Optional[int] = None,
        body: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            status_code=status_code or 401,
            body=body,
            request_id=request_id,
        )


class RateLimitError(MailerError):
    """Raised on HTTP 429 — rate limit exceeded.

    Attributes:
        retry_after: Seconds to wait before retrying.
        limit: Maximum requests allowed in the window.
        remaining: Requests remaining in the current window.
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded. Please retry later.",
        status_code: Optional[int] = None,
        body: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
        retry_after: Optional[int] = None,
        limit: Optional[int] = None,
        remaining: Optional[int] = None,
    ) -> None:
        super().__init__(
            message=message,
            status_code=status_code or 429,
            body=body,
            request_id=request_id,
        )
        self.retry_after = retry_after
        self.limit = limit
        self.remaining = remaining

    def __repr__(self) -> str:
        base = super().__repr__()
        extras = []
        if self.retry_after is not None:
            extras.append(f"retry_after={self.retry_after}")
        if self.limit is not None:
            extras.append(f"limit={self.limit}")
        if self.remaining is not None:
            extras.append(f"remaining={self.remaining}")
        if extras:
            return f"{base[:-1]}, {', '.join(extras)})"
        return base


class ValidationError(MailerError):
    """Raised on HTTP 400 — request validation failed.

    Attributes:
        errors: Structured validation error details from the API.
    """

    def __init__(
        self,
        message: str = "Request validation failed.",
        status_code: Optional[int] = None,
        body: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
        errors: Optional[Union[List[Any], Dict[str, Any]]] = None,
    ) -> None:
        super().__init__(
            message=message,
            status_code=status_code or 400,
            body=body,
            request_id=request_id,
        )
        self.errors = errors


class NotFoundError(MailerError):
    """Raised on HTTP 404 — requested resource does not exist."""

    def __init__(
        self,
        message: str = "Resource not found.",
        status_code: Optional[int] = None,
        body: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            status_code=status_code or 404,
            body=body,
            request_id=request_id,
        )


class ServerError(MailerError):
    """Raised on HTTP 5xx — server-side failure."""

    def __init__(
        self,
        message: str = "Internal server error. Please try again later.",
        status_code: Optional[int] = None,
        body: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            status_code=status_code or 500,
            body=body,
            request_id=request_id,
        )


class ConnectionError(MailerError):
    """Raised when the SDK cannot establish a network connection."""

    def __init__(
        self,
        message: str = "Failed to connect to Maielr API.",
        status_code: Optional[int] = None,
        body: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            status_code=status_code,
            body=body,
            request_id=request_id,
        )


class TimeoutError(MailerError):
    """Raised when a request exceeds the configured timeout."""

    def __init__(
        self,
        message: str = "Request to Maielr API timed out.",
        status_code: Optional[int] = None,
        body: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(
            message=message,
            status_code=status_code,
            body=body,
            request_id=request_id,
        )
