# Asciisort

---
Asciisort is a library created by im-lemon (me! :3), that maps ASCII characters from bright to dark, it's purpose is to
help you when mapping ascii characters, by using ``Ascii.sort()``
 Asciisort also has a random charset feature: ``Ascii.map()``, It generates random character sets based on the length you put in the length parameter.


---
More features *may* include:

- Colourization, add colour to ASCII art instantly (powered by Colorim)
