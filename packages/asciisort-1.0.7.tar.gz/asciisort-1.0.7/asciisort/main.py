## asciisort, a python library that maps ascii characters from brightest to darkest.

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import string
import random

BASE_DIR = Path(__file__).resolve().parent.parent
font_path = BASE_DIR / "assets" / "CourierPrime-Regular.ttf"

class Ascii:
    @classmethod
    def sort(cls, characters):
        width = 32
        height = 32
        font = ImageFont.truetype(str(font_path), 32)
        results = []
        for char in characters:
            img = Image.new('L', (width, height))
            draw = ImageDraw.Draw(img)
            draw.text((0, 0), char, font=font, fill=255)
            pixels = img.get_flattened_data()
            num_pixels = len(pixels)
            pixels = sum(pixels)
            brightness = pixels / num_pixels
            brightness = 255 - brightness

            to_append = (char, brightness)
            results.append(to_append)

        results.sort(key=lambda x: x[1], reverse=True) #this part made me CRY.
        end_result = []
        for item in results:
            first_char = item[0]
            end_result.append(first_char)
            end_str = "".join(end_result)
        return end_str

    @classmethod
    def randcharset(cls, length_charset):
        charset = string.punctuation

        rand_charset_list = []
        for i in range (length_charset):
            rand_charset = random.choice(charset)
            rand_charset_list.append(rand_charset)
        end = "".join(rand_charset_list)
        return end