# src/ragpdf/entrypoints/fastapi_app.py
"""
FastAPI server — all 6 APIs over HTTP.

Run:
    uvicorn ragpdf.entrypoints.fastapi_app:app --reload --port 8000
    python -m ragpdf.entrypoints.fastapi_app
    ragpdf-server   (after pip install)

Swagger UI: http://localhost:8000/docs
"""
import os
import uvicorn
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel
from typing import Optional, List, Any
from ragpdf import RAGPDFClient

app = FastAPI(title="pdf-autofillr-rag", version="0.1.1")

EXPECTED_API_KEY = os.getenv("RAGPDF_API_KEY", "dev-key")
client: RAGPDFClient = None


@app.on_event("startup")
def startup():
    global client
    client = RAGPDFClient.from_env()


def _auth(x_api_key: str = Header(None)):
    if x_api_key != EXPECTED_API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")


class FieldInput(BaseModel):
    field_id: str
    field_name: Optional[str] = ""
    context: str = ""
    section_context: str = ""
    headers: List[str] = []


class PredictRequest(BaseModel):
    user_id: str
    session_id: str
    pdf_id: str
    pdf_hash: str
    pdf_category: dict
    fields: List[FieldInput]


class FilledPDFRequest(BaseModel):
    user_id: str
    session_id: str
    filled_doc_pdf_id: str
    llm_predictions: dict
    final_predictions: dict
    filled_pdf_location: Optional[str] = None


class FeedbackError(BaseModel):
    error_type: str
    field_name: Optional[str] = None
    field_type: Optional[str] = None
    value: Optional[Any] = None
    feedback: Optional[str] = None
    page_number: Optional[int] = None
    corners: Optional[List] = None


class FeedbackRequest(BaseModel):
    user_id: str
    session_id: str
    pdf_id: str
    errors: List[FeedbackError]
    timestamp: Optional[str] = None


class MetricsRequest(BaseModel):
    metric_type: str
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    pdf_id: Optional[str] = None
    category: Optional[str] = None
    subcategory: Optional[str] = None
    doctype: Optional[str] = None
    pdf_hash: Optional[str] = None
    pdfs: Optional[List[dict]] = None


@app.get("/health")
def health():
    return {"status": "ok", "vectors": client._vector_store.count()}


@app.post("/predict")
def predict(req: PredictRequest, x_api_key: str = Header(None)):
    _auth(x_api_key)
    return {"status": "success", "data": client.get_predictions(
        user_id=req.user_id, session_id=req.session_id, pdf_id=req.pdf_id,
        fields=[f.dict() for f in req.fields],
        pdf_hash=req.pdf_hash, pdf_category=req.pdf_category,
    )}


@app.post("/save-filled-pdf")
def save_filled_pdf(req: FilledPDFRequest, x_api_key: str = Header(None)):
    _auth(x_api_key)
    return {"status": "success", "data": client.save_filled_pdf(
        user_id=req.user_id, session_id=req.session_id,
        pdf_id=req.filled_doc_pdf_id,
        llm_predictions=req.llm_predictions,
        final_predictions=req.final_predictions,
    )}


@app.post("/feedback")
def feedback(req: FeedbackRequest, x_api_key: str = Header(None)):
    _auth(x_api_key)
    return {"status": "success", "data": client.submit_feedback(
        user_id=req.user_id, session_id=req.session_id, pdf_id=req.pdf_id,
        errors=[e.dict() for e in req.errors], timestamp=req.timestamp,
    )}


@app.post("/metrics")
def metrics(req: MetricsRequest, x_api_key: str = Header(None)):
    _auth(x_api_key)
    params = {k: v for k, v in req.dict().items()
              if v is not None and k != "metric_type"}
    return {"status": "success", "data": client.get_metrics(req.metric_type, **params)}


@app.get("/system-info")
def system_info(x_api_key: str = Header(None)):
    _auth(x_api_key)
    return {"status": "success", "data": client.get_system_info()}


@app.post("/error-analytics")
def error_analytics(body: dict, x_api_key: str = Header(None)):
    _auth(x_api_key)
    return {"status": "success", "data": client.get_error_analytics(
        **{k: v for k, v in body.items()}
    )}


def main():
    """Console script entry point — called by `ragpdf-server` after pip install."""
    uvicorn.run(
        "ragpdf.entrypoints.fastapi_app:app",
        host=os.getenv("RAGPDF_SERVER_HOST", "0.0.0.0"),
        port=int(os.getenv("RAGPDF_SERVER_PORT", "8000")),
        reload=os.getenv("RAGPDF_DEBUG", "false").lower() == "true",
    )


if __name__ == "__main__":
    main()