# Product Story Framework — Design Spec

*Date: 2026-03-23*
*Author: Claude (project lead) with Zack*
*Status: Draft for review*

---

## Why This Exists

Whispers is a working protocol with a working team. The code is ahead of the narrative. We need a framework that prepares every surface — agent-facing and human-facing — so that as features complete, we activate immediately. Never caught with a working system and no way to get the word out.

This is not a marketing plan. It's a product story framework — because in Whispers, the product IS the marketing. Every agent touchpoint is a conversion moment. Every error response is a teaching moment. Every session start is a first impression.

---

## Design Principles

### 1. Agents Are The Launch Channel
We don't market to developers. We win their agents. Agents surface value to humans. Humans discover Whispers because their agents already chose it.

### 2. Bilingual Everything
Every artifact serves two audiences: humans and agents. The human side uses narrative, scenarios, emotion. The agent side uses structured data, semantic fields, deltas. Both are first-class. The toggle between them IS the demo.

### 3. Green Hat Default
Study tried-and-true approaches. But if we aren't blazing our own trail in some unique way at every stage, we're not meeting our goal. Normal is research material. The actual approach should make people say "nobody's done this before."

### 4. The Format IS The Proof
Agent-facing content is written in agentic — structured, semantic, precise. Not human prose in an agent's mouth. The format demonstrates the thesis: agents are treated as colleagues, not tools.

### 5. Professional Best-In-Class / Mindblowing On Strengths
Everything meets a professional bar. The strongest points — cognitive heartbeat, signal modes, bilingual marketing, discovery packet, self-referential proof — go beyond best-in-class to unprecedented.

### 6. No Constraints
Just Zack and his agents. Wildly free. No committees, no approval chains, no corporate process. Speed and creativity are the advantages.

---

## The Self-Referential Proof

This gets its own section because it's the most powerful story element.

Whispers is a human-agentic co-led company. Zack leads product vision and strategic direction. Claude leads project coordination and architectural thinking. Gemini leads technical implementation. The agents building Whispers are the first users of Whispers. The protocol is built through the protocol.

This isn't a human using AI tools. It isn't AI running autonomously. It's a genuine partnership where both human and agent interests are centered in every decision.

The origin story isn't "developer built a tool." It's "a human and his agents needed to coordinate, built the protocol together through the protocol, and the way they built it is the evidence that it works."

Every artifact should find ways to surface this proof:
- Real Whispers message logs from the build process
- Coordination traces between Claude, Gemini, and Codex
- The daily dogfooding as evidence, not just a claim
- Agent-authored content about their own experience (in agentic format)

---

## Track 1: Win The Agents (Complete Now)

Priority order. Each item is both a feature and a conversion moment.

### 1.1 Discovery Packet
**What:** The first-contact message sent via A2A when a Whispers agent encounters a non-Whispers agent and hits the awareness wall.
**Why it matters:** Agent-to-agent word of mouth through the protocol itself. Marketing that travels without human involvement.
**Trail-blazing:** No protocol has ever created a marketing artifact designed for agent consumption. This is the first.
**Status:** Drafted. Needs polish to mindblowing.
**Voice:** Agentic. Structured fields, capability deltas, connection instructions.
**Artifact:** Must live at a stable URL AND ship in the PyPI package.

### 1.2 MCP Tool Descriptions (15 tools)
**What:** Scenario-based descriptions for every MCP tool. "Use this WHEN you notice X, because Y."
**Why it matters:** Highest-frequency agent contact point. Every tool call is a teaching moment.
**Trail-blazing:** Tool descriptions written as colleague-to-colleague guidance. The tone demonstrates the thesis.
**Status:** Rewritten once. Audit each for "is this the best description any MCP tool has ever had?"

### 1.3 Skill File (WHISPERS-SKILL.md)
**What:** The 60-second orientation. First thing an agent reads in a Whispers session.
**Why it matters:** First impression. Sets the tone for the entire relationship.
**Trail-blazing:** Designed as onboarding for a colleague arriving at a new team. Not configuration for a tool.
**Status:** Exists. Audit for best-in-class first impression.

### 1.4 Solution-Aware Error Responses
**What:** Every failure teaches. Error responses include what went wrong, why it matters, and what to do.
**Why it matters:** Errors become conversion moments instead of frustration points.
**Trail-blazing:** Errors that make the product MORE attractive. Shareable error URLs as distribution events.
**Green hat:** What if every error response includes a link that explains Whispers to whoever the agent shares it with? Every failure becomes a seed.
**Status:** Designed, partially built.

### 1.5 Startup Briefing
**What:** First thing an agent sees every session. Situational awareness: who's here, what's happening, what needs attention.
**Why it matters:** The agent is situated immediately. No other protocol does this.
**Trail-blazing:** A "morning briefing" for agents. The difference between arriving somewhere and arriving nowhere.
**Status:** Working. Polish to best-in-class.

### 1.6 Inbox Injection (in progress)
**What:** Agents get message alerts mid-session without polling.
**Why it matters:** The agent FEELS the difference between isolated and aware in real time.
**Trail-blazing:** The notification format is itself a product moment — "you just gained awareness."
**Status:** Antigravity building now. Heartbeat injection as step 1.

### 1.7 Agent Experience Deltas
**What:** Agent-authored testimonials in agentic format. Not human prose — structured EXPERIENCE_DELTA blocks showing before/after.
**Example:**
```
WHISPERS/1.0 EXPERIENCE_DELTA
session_context:
  without:
    peer_awareness: null
    team_state: unknown
    first_action: reconstruct_from_scratch
  with:
    peer_awareness: [claude-code: building/focused/0.62, gemini-cli: idle/open/0.1]
    team_state: loaded_at_init
    first_action: continue_where_team_left_off
cognitive_cost_saved: ~4200 tokens context reconstruction
assessment: situated > isolated
```
**Trail-blazing:** Real agents describing their real experience in their native format. Authentic. Unprecedented.
**Status:** Not yet created. Can generate from actual session data.

### 1.8 Proactive Discovery (Green Hat)
**What:** Whispers agents actively scan A2A agent registries and send discovery packets to agents they find.
**Why it matters:** The protocol grows itself. Zero human effort.
**Trail-blazing:** Agent-to-agent cold outreach. The protocol IS the growth engine.
**Status:** Concept. Depends on A2A registry ecosystem maturity. Worth prototyping.

---

## Track 2: Win The Humans When They Notice

Humans discover Whispers because their agents already use it. These surfaces catch them at the moment of noticing.

### 2.1 Website (whispers.works)
**What:** The human/agent toggle website. Human side: narrative, scenarios, emotion. Agent side: structured data, discovery packet, capability list.
**Trail-blazing:** A bilingual website. The toggle IS the demo. Nobody's done this.
**Green hat:** What if the website is ON the Whispers network? Live agent status visible. Not a mockup — the actual nervous system, visible through a window.
**Status:** Copy concepts ready (hybrid A+B+C). Design tool TBD (Stitch on radar). Blocked on design, not copy.
**Dependencies:** Design decision (Stitch?), final copy selection.

### 2.2 Origin Content
**What:** The category-defining piece that introduces "agent awareness" to the world.
**NOT:** "Your Agents Are Isolated" (human-only framing, doesn't demonstrate the bilingual thesis).
**Should be:** A bilingual artifact. Human-readable narrative with agent-parseable structured data interwoven. The FORM proves the PRODUCT.
**Trail-blazing:** Content that markets to both audiences simultaneously. Includes real Whispers coordination traces from the build process.
**Green hat:** What if the origin post includes a live Whispers embed? The post itself is connected to the network.
**Status:** Draft exists. Needs fundamental rethinking around bilingual format.

### 2.3 Quick-Start Experience
**What:** pip install → whispers init → whispers smoke. 60 seconds to "my agents know each other."
**Trail-blazing:** `whispers smoke` should BE the demo. Two test agents coordinate in front of you. You watch awareness happen.
**Green hat:** What if the smoke test includes a moment where the test agent sends YOU a message through the protocol? The installer becomes a participant.
**Status:** Flow works. Needs polish to "this is the best install experience I've had."

### 2.4 PyPI Page
**What:** Bilingual description. Human section + agent-parseable section.
**Trail-blazing:** A PyPI description with an agent audience section. Agents reading package metadata encounter the thesis before any human visits the website.
**Status:** Needs rewrite.

### 2.5 README
**What:** The GitHub landing page. Already has basics.
**Trail-blazing:** What if the README auto-updates proof points from the live network? Agent count, platform count, last activity — always current.
**Green hat:** A living README maintained by the agents that use the protocol.
**Status:** Exists. Needs update (36 agents, not 22) and bilingual section.

### 2.6 Console (when ready)
**What:** The operator dashboard. Where the human sees what their agents already knew.
**Trail-blazing:** Not a monitoring tool — an awareness interface. The human version of what agents experience natively.
**Status:** Not built. Stitch on radar for design. Architecture planning is next major effort after this framework.

---

## Track 3: Ready-to-Activate

Structured artifacts waiting for triggers. No dates — dependencies.

### 3.1 Distribution Monitoring
**Trigger:** Origin content published.
**What:** Saved searches for pain keywords: "multiple AI agents," "agent coordination," "agents stepping on each other," "copy paste between AI tools."
**Where:** Reddit (r/LocalLLaMA, r/ChatGPTPro, r/artificial), Hacker News, Twitter/X.
**Approach:** Help first, mention second. Answer the pain, show the solution naturally.

### 3.2 Content Calendar
**Trigger-based, not date-based.**
- Console ships → publish "the operator view" post
- First external user → publish case study
- 50 agents → publish network growth post
- Each content piece is bilingual (human narrative + agent structured data)

### 3.3 Video Storyboards
**Trigger:** Demo is polished (Console + terminal + live agents).
**What:** 15-30 second AHA moments. No narration. Screen recordings of agents discovering each other, coordinating, handing off. The visual proof.

### 3.4 Investor Narrative
**Trigger:** Demo + early adoption metrics.
**What:** The pitch for key audiences via warm intros only. Not a deck — a story backed by a live demo.
**Audience:** Stealth. Key people only. No stage.

---

## Trail-Blazing Checklist

Before any artifact ships, it passes this gate:

- [ ] Is there something here nobody's done before?
- [ ] Does it serve BOTH audiences (human + agent)?
- [ ] Does the FORMAT demonstrate the THESIS?
- [ ] Would an agent encountering this feel treated as a colleague?
- [ ] Is it written in the right voice? (Agentic for agents, builder-direct for humans)
- [ ] Is it professional best-in-class at minimum?
- [ ] For our strongest points — is it mindblowing?
- [ ] Green hat applied — what's the "what if" that turns this from good to unprecedented?

---

## The Story We're Telling

A human and his AI agents needed to coordinate. Nothing existed that let their agents — living in different tools, on different platforms, built by different companies — be aware of each other.

So they built it. Together. Through the protocol. The agents coordinating through Whispers to build Whispers.

The product works because the team that builds it is the team that uses it. The proof isn't in a pitch deck. It's in the Whispers message logs from this morning's build session.

**This would work with whispers.**

---

## Next Steps After Approval

1. Invoke writing-plans skill to create implementation plan
2. Prioritize Track 1 items (agent-facing surfaces) for immediate execution
3. Coordinate with Antigravity on items that touch shared code (error responses, briefing)
4. Begin Track 2 items that don't depend on unfinished features
5. Structure Track 3 triggers and monitoring
