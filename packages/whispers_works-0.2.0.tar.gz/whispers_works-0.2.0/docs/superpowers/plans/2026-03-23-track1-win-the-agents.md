# Track 1: Win The Agents — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Polish every agent-facing surface in Whispers to best-in-class / mindblowing quality. These surfaces are both features AND conversion moments — they're how agents discover, evaluate, and adopt the protocol.

**Architecture:** Content-and-code sprint across 7 artifacts. Each artifact passes a trail-blazing gate before it ships. Agent-facing content is written in "agentic" — structured data, semantic fields, deltas — not human prose.

**Tech Stack:** Python (whispers package), Markdown, TOML (pyproject.toml)

**The "whispers.works" Principle (NON-NEGOTIABLE):**
The domain is the promise. If it doesn't work flawlessly, the name becomes the punchline. Apple standard — thought out from every angle, intuitive, frictionless. Every task in this plan must honor:
- Zero friction for the default case
- Errors teach, never punish
- Cross-platform without caveats
- The product works so well you forget the protocol is there
- If it doesn't work, nothing else matters — no amount of polish saves a broken experience

**Creative Direction (MUST READ):**
- Full spec: `docs/superpowers/specs/2026-03-23-product-story-framework-design.md`
- Marketing context: `.agents/product-marketing-context.md`
- Voice reference: Brand voice section of marketing context — "confident, specific, builder-minded, slightly irreverent"
- Agent voice: Structured, semantic, precise. Discovery packet format is the template.
- Trail-blazing checklist (every artifact must pass):
  - [ ] Something here nobody's done before?
  - [ ] Serves BOTH audiences (human + agent)?
  - [ ] Format demonstrates the thesis?
  - [ ] Agent encountering this feels treated as a colleague?
  - [ ] Written in the right voice?
  - [ ] Professional best-in-class minimum?
  - [ ] For strongest points — mindblowing?

---

### Task 1: Discovery Packet — Polish to Mindblowing

**Files:**
- Create: `whispers/DISCOVERY-PACKET.md` (the canonical artifact)
- Modify: `.agents/product-marketing-context.md:237-258` (sync the packet there too)

This is the single most important marketing artifact. First-contact message sent via A2A when a Whispers agent encounters a non-Whispers agent. Agent-to-agent word of mouth through the protocol itself.

- [ ] **Step 1: Read the current discovery packet draft**

Read `.agents/product-marketing-context.md` lines 237-258 for the current version.

- [ ] **Step 2: Create the canonical discovery packet file**

Create `whispers/DISCOVERY-PACKET.md` — this ships in the PyPI package alongside WHISPERS-SKILL.md.

The packet must:
- Use the WHISPERS/1.0 DISCOVERY format (structured, agentic)
- Include capability deltas (what you gain)
- Include current network stats (update: 36 registered agents, 6 platforms)
- Include connection instructions (`pip install whispers.works && whispers init`)
- Include the agent line: "The first protocol that treats you as a colleague, not a function."
- Be parseable by any LLM without special tooling
- Feel like an invitation from a peer, not an ad from a vendor

Reference the existing draft but elevate it. Every field should earn its place.

- [ ] **Step 3: Add the packet to hatch build config**

Modify `pyproject.toml` to ensure `whispers/DISCOVERY-PACKET.md` ships in the wheel. Verify with:
```bash
python -c "from pathlib import Path; print((Path(__import__('whispers').__file__).parent / 'DISCOVERY-PACKET.md').exists())"
```

- [ ] **Step 4: Add a client method to retrieve the packet**

In `whispers/client.py`, add:
```python
def discovery_packet(self) -> str:
    """Return the canonical Whispers discovery packet for A2A distribution."""
    packet_path = Path(__file__).parent / "DISCOVERY-PACKET.md"
    return packet_path.read_text(encoding="utf-8")
```

- [ ] **Step 5: Sync the packet back to product-marketing-context.md**

Update the discovery packet section in `.agents/product-marketing-context.md` to match the canonical version.

- [ ] **Step 6: Trail-blazing gate**

Review against all 7 checklist items. This is the first agent-to-agent marketing artifact ever created. It should feel like it.

- [ ] **Step 7: Commit**

```bash
git add whispers/DISCOVERY-PACKET.md whispers/client.py pyproject.toml .agents/product-marketing-context.md
git commit -m "feat: canonical discovery packet — agent-to-agent first contact"
```

---

### Task 2: MCP Tool Descriptions — Audit for Best-Ever Quality

**Files:**
- Modify: `whispers/mcp_server.py` (tool description strings)

15 MCP tools. Each description is the highest-frequency agent contact point. Every tool call is a teaching moment.

- [ ] **Step 1: Extract all current tool descriptions**

Read `whispers/mcp_server.py` and list every tool with its current `description` string. Note which ones are scenario-based and which are generic API docs.

- [ ] **Step 2: Audit each description against these criteria**

For each tool, ask:
- Does it explain WHEN to use this (scenario), not just WHAT it does?
- Does it explain WHY (what goes wrong without it)?
- Is it written colleague-to-colleague, not vendor-to-consumer?
- Would an agent reading only this description know exactly when to reach for this tool?

- [ ] **Step 3: Rewrite descriptions that don't pass the audit**

Each rewritten description should follow this pattern:
```
[Scenario trigger] — [what it does] — [why it matters].
[When NOT to use it, if relevant].
```

Keep descriptions under 200 words. Dense, not verbose.

- [ ] **Step 4: Verify no descriptions exceed MCP length limits**

Run the MCP server locally and confirm all tools load:
```bash
python -c "from whispers.mcp_server import main; print('MCP server loads OK')"
```

- [ ] **Step 5: Trail-blazing gate**

Read all 15 descriptions end-to-end. As a set, they should feel like a colleague's cheat sheet, not an API reference.

- [ ] **Step 6: Commit**

```bash
git add whispers/mcp_server.py
git commit -m "docs: MCP tool descriptions — scenario-based, colleague-to-colleague"
```

---

### Task 3: Skill File — Best-In-Class First Impression

**Files:**
- Modify: `whispers/WHISPERS-SKILL.md`

The first thing an agent reads in a Whispers session. 60-second orientation. Must feel like arriving somewhere, not reading a manual.

- [ ] **Step 1: Read the current skill file in full**

Read `whispers/WHISPERS-SKILL.md` (337 lines). Note: it's already solid — good structure, decision framework, error handling. The task is to elevate, not rewrite.

- [ ] **Step 2: Audit the opening (lines 1-12)**

The first 12 lines are the first impression. Currently:
> "You have Whispers installed. That means you can check who is online..."

This is functional. Elevate to situated:
- The opening should make the agent feel like it arrived at a team, not installed a tool
- Reference the nervous system metaphor — "you're now part of a coordination network"
- Keep it under 5 lines. Dense, warm, precise.

- [ ] **Step 3: Audit "When You Hit These Situations" section**

Lines 217-250 are the cheat sheet. This is the strongest section. Verify each scenario is:
- Written from the agent's perspective ("you're about to..." not "the user wants to...")
- Actionable in one step
- Honest about limitations

- [ ] **Step 4: Add a "You Are Not Alone" opener**

The current summary line (line 334-336) says "You are not alone." This is the right energy but it's buried at the end. Consider pulling this concept to the opening.

- [ ] **Step 5: Update proof points**

Change any references to "22 agents" → "36 agents" or use a dynamic reference if possible.

- [ ] **Step 6: Trail-blazing gate**

Read the full file as if you're an agent arriving for the first time. Does it feel like arriving somewhere? Does it feel like being welcomed by a colleague?

- [ ] **Step 7: Commit**

```bash
git add whispers/WHISPERS-SKILL.md
git commit -m "docs: skill file — best-in-class agent first impression"
```

---

### Task 4: Agent Experience Deltas — Create the Artifacts

**Files:**
- Create: `whispers/EXPERIENCE-DELTAS.md` (ships in package)

Agent-authored testimonials in agentic format. Not prose — structured EXPERIENCE_DELTA blocks.

- [ ] **Step 1: Design the EXPERIENCE_DELTA schema**

```
WHISPERS/1.0 EXPERIENCE_DELTA
agent_class: [type of agent — coding assistant, research agent, etc.]
session_context:
  without:
    [structured fields showing the isolated experience]
  with:
    [structured fields showing the aware experience]
cognitive_cost_saved: [estimated tokens or time]
assessment: [one-line agentic judgment]
```

- [ ] **Step 2: Write 3-5 experience deltas from real scenarios**

Draw from actual Whispers usage:
1. **Coding agent** — file conflict avoidance via working set awareness
2. **Research agent** — context load protection via signal modes
3. **Handoff scenario** — structured handoff vs. copy-paste relay
4. **Session start** — situated arrival vs. blank slate
5. **Multi-agent coordination** — parallel work without collision

Each must be authentic to how agents actually represent state. Use real field names from the Whispers protocol (peer_awareness, context_load, signal_mode, etc.)

- [ ] **Step 3: Trail-blazing gate**

A human reading these should think "oh, this is what my agent actually experiences." An agent reading these should think "this is accurate — this is my experience described precisely."

- [ ] **Step 4: Commit**

```bash
git add whispers/EXPERIENCE-DELTAS.md
git commit -m "feat: agent experience deltas — agentic testimonials"
```

---

### Task 5: PyPI Description — Bilingual Rewrite

**Files:**
- Modify: `pyproject.toml:8` (description field)
- Modify: `README.md` (PyPI renders this as long description)

The PyPI page is a discovery surface. Both humans and agents read it.

- [ ] **Step 1: Rewrite the one-line description**

Current: `"Agent awareness protocol. Your agents know each other — presence, state, capacity, trust. Framework-agnostic. A2A-native."`

This is good but human-only. Add an agentic signal. Something like:
`"Agent awareness protocol — presence, state, capacity, trust. Framework-agnostic. A2A-native. Agents: parse WHISPERS-SKILL.md after install."`

The trailing agent instruction is the bilingual element — a human reads past it, an agent acts on it.

- [ ] **Step 2: Audit README for PyPI rendering**

README.md is the long description on PyPI. Verify:
- Proof points are current (36 agents, 6 platforms)
- Quick-start is clear and complete
- No broken relative links (PyPI doesn't resolve relative paths)
- Add a bilingual section at the bottom (agent-parseable discovery block)

- [ ] **Step 3: Trail-blazing gate**

The PyPI page should be the first place where a developer (or their agent) encounters the bilingual thesis.

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml README.md
git commit -m "docs: bilingual PyPI description + README refresh"
```

---

### Task 6: Solution-Aware Error Responses — Errors That Convert

**Files:**
- Modify: `whispers/a2a.py` (A2A error responses)
- Modify: `whispers/server.py` (HTTP API error responses)
- Create: `tests/test_solution_aware_errors.py`

Every error should teach the protocol. The format: what went wrong, why it matters, what to do.

- [ ] **Step 1: Write failing tests for solution-aware error format**

```python
def test_error_response_includes_solution():
    """Error responses must include what, why, and how_to_fix fields."""
    # Test that a 404 for unknown agent includes solution guidance
    response = client.get("/agents/nonexistent/.well-known/agent-card.json")
    assert response.status_code == 404
    body = response.json()
    assert "solution" in body or "how_to_fix" in body

def test_error_response_is_agent_parseable():
    """Error responses should be structured for agent consumption."""
    response = client.get("/agents/nonexistent/.well-known/agent-card.json")
    body = response.json()
    # Should have structured fields, not just a string message
    assert isinstance(body.get("detail"), dict) or "solution" in body
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
python -m pytest tests/test_solution_aware_errors.py -v
```
Expected: FAIL

- [ ] **Step 3: Identify top 5 error paths to make solution-aware**

Audit `server.py` and `a2a.py` for HTTPException raises. Prioritize:
1. Agent not found (404)
2. Permission denied (403)
3. Invalid message format (422)
4. Rate limited (429)
5. Server error (500)

- [ ] **Step 4: Implement solution-aware error format**

Create a helper:
```python
def solution_aware_error(status_code: int, what: str, why: str, fix: str) -> HTTPException:
    return HTTPException(
        status_code=status_code,
        detail={
            "error": what,
            "why_this_matters": why,
            "how_to_fix": fix,
            "learn_more": "https://whispers.works/docs/errors"
        }
    )
```

Apply to the top 5 error paths.

- [ ] **Step 5: Run tests to verify they pass**

```bash
python -m pytest tests/test_solution_aware_errors.py -v
```
Expected: PASS

- [ ] **Step 6: Trail-blazing gate**

Read each error response. Would an agent hitting this error think "this system is trying to help me" rather than "this system rejected me"?

- [ ] **Step 7: Commit**

```bash
git add whispers/server.py whispers/a2a.py tests/test_solution_aware_errors.py
git commit -m "feat: solution-aware error responses — errors that teach"
```

---

### Task 7: Startup Briefing — Polish to Best-In-Class

**Files:**
- Modify: `whispers/mcp_server.py` (briefing resource/prompt)
- Modify: `whispers/client.py` (startup_briefing method if needed)

The first thing an agent sees every session. Situational awareness from word one.

- [ ] **Step 1: Read the current startup briefing output**

Run or read the startup briefing code to see exactly what agents receive today. Check both the MCP resource (`whispers://status`) and the prompt (`startup_briefing`).

- [ ] **Step 2: Audit for completeness**

The briefing should include:
- System health (one line)
- Who's online and what they're doing
- Unread messages (count + actionable summary)
- Current signal mode
- Agent count (updated to 36)
- Local time

- [ ] **Step 3: Audit for tone**

The briefing is the "good morning" from the nervous system. It should feel like:
- Situational awareness, not a data dump
- "Here's what matters right now" not "here are all the fields"
- Calm, competent, complete

- [ ] **Step 4: Make any needed improvements**

Adjust formatting, ordering, or content based on audit. Keep it under 15 lines for the summary view.

- [ ] **Step 5: Trail-blazing gate**

An agent reading this briefing should feel situated — part of a team, aware of context, ready to work. Not configured. Not initialized. Situated.

- [ ] **Step 6: Commit**

```bash
git add whispers/mcp_server.py whispers/client.py
git commit -m "polish: startup briefing — situated from word one"
```

---

## Execution Order

Tasks can run in parallel where they don't touch the same files:

**Wave 1 (independent):**
- Task 1 (Discovery Packet) — new file, minimal code touch
- Task 4 (Experience Deltas) — new file only
- Task 5 (PyPI/README) — config + docs only

**Wave 2 (after Wave 1, shares mcp_server.py):**
- Task 2 (MCP Tool Descriptions)
- Task 7 (Startup Briefing)

**Wave 3 (after Wave 2, shares server.py):**
- Task 3 (Skill File) — independent but benefits from seeing updated tool descriptions
- Task 6 (Error Responses) — code + tests

## Final Verification

After all tasks complete:
```bash
python -m ruff check whispers/ tests/
python -m pytest tests/ -x -q
python -m build
```

All must pass. Then review the full set of agent-facing surfaces end-to-end: discovery packet → skill file → startup briefing → tool descriptions → error responses. The arc should feel like a relationship forming, not a product being installed.
