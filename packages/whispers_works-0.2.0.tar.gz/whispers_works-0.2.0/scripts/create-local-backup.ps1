param(
    [string]$BackupRoot = "E:\\WhispersBackups",
    [string]$Reason = "manual",
    [switch]$SkipBundle,
    [switch]$SkipArchive,
    [switch]$SkipWorktreeCapture
)

$ErrorActionPreference = "Continue"

function Get-GitText {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    $prevPref = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $output = & git @Arguments 2>$null
    $code = $LASTEXITCODE
    $ErrorActionPreference = $prevPref
    if ($code -ne 0) {
        throw "git $($Arguments -join ' ') failed."
    }
    return $output
}

function Get-OptionalGitText {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments,
        [object]$Fallback = ""
    )

    $prevPref = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $output = & git @Arguments 2>$null
    $code = $LASTEXITCODE
    $ErrorActionPreference = $prevPref
    if ($code -ne 0) {
        return $Fallback
    }
    return $output
}

$repoRoot = (Get-GitText -Arguments @("rev-parse", "--show-toplevel") | Select-Object -First 1).Trim()
if (-not $repoRoot) {
    throw "Not inside a git repository."
}

Set-Location $repoRoot

$repoName = Split-Path $repoRoot -Leaf
$head = ((Get-OptionalGitText -Arguments @("rev-parse", "--short", "HEAD") -Fallback "no-commit") | Select-Object -First 1).Trim()
if (-not $head) {
    $head = "no-commit"
}

$branch = ((Get-OptionalGitText -Arguments @("rev-parse", "--abbrev-ref", "HEAD") -Fallback "detached") | Select-Object -First 1).Trim()
if (-not $branch) {
    $branch = "detached"
}

$upstream = ((Get-OptionalGitText -Arguments @("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}") -Fallback "") | Select-Object -First 1).Trim()
$statusLines = @(Get-OptionalGitText -Arguments @("status", "--short") -Fallback @())
$dirty = $statusLines.Count -gt 0
$timestamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
$safeReason = if ($Reason) { $Reason -replace "[^A-Za-z0-9._-]", "_" } else { "manual" }

$targetName = "{0}_{1}_{2}_{3}{4}" -f $repoName, $timestamp, $head, $safeReason, ($(if ($dirty) { "_dirty" } else { "" }))
$targetDir = Join-Path $BackupRoot $targetName
New-Item -ItemType Directory -Path $targetDir -Force | Out-Null

$manifestPath = Join-Path $targetDir "manifest.txt"
$statusPath = Join-Path $targetDir "git-status.txt"
$logPath = Join-Path $targetDir "git-log.txt"
$patchPath = Join-Path $targetDir "working-tree.patch"
$bundlePath = Join-Path $targetDir ("{0}-{1}.bundle" -f $repoName, $head)
$archivePath = Join-Path $targetDir ("{0}-{1}.zip" -f $repoName, $head)

$manifest = @(
    "repo=$repoName"
    "repo_root=$repoRoot"
    "branch=$branch"
    "head=$head"
    "upstream=$upstream"
    "dirty=$dirty"
    "reason=$Reason"
    "created_at=$([DateTimeOffset]::Now.ToString('o'))"
    "backup_root=$BackupRoot"
)
$manifest | Set-Content -Encoding utf8 $manifestPath
$statusLines | Set-Content -Encoding utf8 $statusPath
Get-OptionalGitText -Arguments @("log", "--oneline", "--decorate", "-n", "50") -Fallback @() | Set-Content -Encoding utf8 $logPath

if (-not $SkipBundle) {
    & git bundle create $bundlePath --all 2>$null
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to create git bundle."
    }
}

if (-not $SkipArchive -and $head -ne "no-commit") {
    & git archive --format=zip --output=$archivePath HEAD 2>$null
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to create git archive."
    }
}

if (-not $SkipWorktreeCapture) {
    $worktreeDir = Join-Path $targetDir "worktree"
    $changedTracked = @()
    $untracked = @()

    if ($head -ne "no-commit") {
        $changedTracked = @(Get-OptionalGitText -Arguments @("diff", "--name-only", "HEAD") -Fallback @())
        $diffOutput = @(& git diff --binary HEAD 2>$null)
        if ($diffOutput.Count -gt 0) {
            $diffOutput | Set-Content -Encoding utf8 $patchPath
        } else {
            "No tracked worktree diff relative to HEAD." | Set-Content -Encoding utf8 $patchPath
        }
    } else {
        $patchMessage = "No HEAD commit available. Worktree files copied below if present."
        $patchMessage | Set-Content -Encoding utf8 $patchPath
    }

    $untracked = @(Get-OptionalGitText -Arguments @("ls-files", "--others", "--exclude-standard") -Fallback @())
    $pathsToCopy = @($changedTracked + $untracked | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Sort-Object -Unique)

    if ($pathsToCopy.Count -gt 0) {
        New-Item -ItemType Directory -Path $worktreeDir -Force | Out-Null
        foreach ($relativePath in $pathsToCopy) {
            $sourcePath = Join-Path $repoRoot $relativePath
            if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
                continue
            }

            $destinationPath = Join-Path $worktreeDir $relativePath
            $destinationDir = Split-Path -Parent $destinationPath
            if ($destinationDir) {
                New-Item -ItemType Directory -Path $destinationDir -Force | Out-Null
            }
            Copy-Item -LiteralPath $sourcePath -Destination $destinationPath -Force
        }
    }
}

Write-Output $targetDir
