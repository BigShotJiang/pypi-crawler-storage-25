import argparse
import os
from pathlib import Path

import anyio
import httpx
from dotenv import load_dotenv
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import CallToolResult, Implementation


def _candidate_env_paths() -> list[Path]:
    candidates: list[Path] = []

    explicit = os.environ.get("ZMAIA_ENV_PATH", "").strip()
    if explicit:
        candidates.append(Path(explicit).expanduser())

    repo_root = Path(__file__).resolve().parents[2]
    candidates.append(repo_root / "zmaia" / ".env")

    return candidates


def _load_brain_token() -> str:
    token = os.environ.get("BRAIN_MCP_TOKEN", "").strip()
    if token:
        return token

    for env_path in _candidate_env_paths():
        if not env_path.exists():
            continue
        load_dotenv(env_path, override=False)
        token = os.environ.get("BRAIN_MCP_TOKEN", "").strip()
        if token:
            return token

    raise RuntimeError("BRAIN_MCP_TOKEN not found in environment or sibling zmaia/.env")


def _brain_url() -> str:
    host = os.environ.get("BRAIN_MCP_HOST", "127.0.0.1").strip() or "127.0.0.1"
    port = os.environ.get("BRAIN_MCP_PORT", "8751").strip() or "8751"
    return f"http://{host}:{port}/mcp/"


async def _connect_remote():
    token = _load_brain_token()
    headers = {"Authorization": f"Bearer {token}"}
    client = httpx.AsyncClient(headers=headers, timeout=30.0)
    return client, streamable_http_client(_brain_url(), http_client=client)


async def _run_selftest() -> int:
    http_client, transport_cm = await _connect_remote()
    try:
        async with transport_cm as (read_stream, write_stream, _get_session_id):
            async with ClientSession(
                read_stream,
                write_stream,
                client_info=Implementation(name="brain-stdio-proxy-selftest", version="0.1.0"),
            ) as session:
                await session.initialize()
                tools = await session.list_tools()
                print(f"Brain MCP reachable at {_brain_url()} ({len(tools.tools)} tools)")
                return 0
    finally:
        await http_client.aclose()


async def _run_stdio_proxy() -> None:
    remote_session: ClientSession | None = None

    server = Server("brain")
    server.instructions = (
        "Zmaia Brain MCP proxy. Use the brain tools for memory, profile, timeline, "
        "actions, and briefings. Call `briefing` near the start of sessions where broader context matters."
    )

    def _session() -> ClientSession:
        if remote_session is None:
            raise RuntimeError("Brain MCP session is not connected")
        return remote_session

    @server.list_tools()
    async def list_tools():
        return (await _session().list_tools()).tools

    @server.call_tool()
    async def call_tool(name: str, arguments: dict):
        return await _session().call_tool(name, arguments or {})

    http_client, transport_cm = await _connect_remote()
    try:
        async with transport_cm as (read_stream, write_stream, _get_session_id):
            async with ClientSession(
                read_stream,
                write_stream,
                client_info=Implementation(name="brain-stdio-proxy", version="0.1.0"),
            ) as session:
                await session.initialize()
                remote_session = session
                async with stdio_server() as (stdio_read, stdio_write):
                    await server.run(stdio_read, stdio_write, server.create_initialization_options())
    finally:
        await http_client.aclose()


def main() -> int:
    parser = argparse.ArgumentParser(description="Bridge the Zmaia Brain HTTP MCP daemon to stdio for Codex.")
    parser.add_argument("--selftest", action="store_true", help="Verify remote brain connectivity and exit")
    args = parser.parse_args()

    if args.selftest:
        return anyio.run(_run_selftest)

    anyio.run(_run_stdio_proxy)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
