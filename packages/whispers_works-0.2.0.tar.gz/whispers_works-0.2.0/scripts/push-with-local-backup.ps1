 [CmdletBinding(PositionalBinding = $false)]
param(
    [string]$BackupRoot = "E:\\WhispersBackups",
    [string]$Reason = "significant-push",
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$PushArgs
)

$ErrorActionPreference = "Stop"

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$backupScript = Join-Path $scriptRoot "create-local-backup.ps1"

$effectivePushArgs = @($PushArgs | Where-Object { $_ -and $_ -ne "--" })

if ($effectivePushArgs.Count -eq 0) {
    throw "No git push arguments supplied. Invoke like: .\\scripts\\push-with-local-backup.ps1 origin main or pass named -BackupRoot/-Reason options before the push args."
}

if (-not (Test-Path -LiteralPath $backupScript -PathType Leaf)) {
    throw "Backup script not found: $backupScript"
}

$backupPath = & $backupScript -BackupRoot $BackupRoot -Reason $Reason
if ($LASTEXITCODE -ne 0) {
    throw "Local backup failed before push."
}

Write-Output "Local backup created: $backupPath"

& git push @effectivePushArgs
exit $LASTEXITCODE
