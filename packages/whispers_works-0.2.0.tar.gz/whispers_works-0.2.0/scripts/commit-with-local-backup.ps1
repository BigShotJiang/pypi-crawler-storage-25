param(
    [string]$BackupRoot = "E:\\WhispersBackups",
    [string]$Reason = "post-commit",
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$CommitArgs
)

$ErrorActionPreference = "Stop"

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$backupScript = Join-Path $scriptRoot "create-local-backup.ps1"

if (-not (Test-Path -LiteralPath $backupScript -PathType Leaf)) {
    throw "Backup script not found: $backupScript"
}

& git commit @CommitArgs
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}

$backupPath = & $backupScript -BackupRoot $BackupRoot -Reason $Reason
if ($LASTEXITCODE -ne 0) {
    throw "Local backup failed after commit."
}

Write-Output "Local backup created: $backupPath"
