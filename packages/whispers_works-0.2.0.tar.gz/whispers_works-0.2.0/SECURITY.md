# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in Whispers, please report it responsibly.

**Do NOT open a public issue.**

Email: zachary4rivers@gmail.com

Include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if you have one)

We will acknowledge receipt within 48 hours and aim to provide a fix or mitigation plan within 7 days.

## Scope

This policy covers:
- The Whispers Python package (`whispers/`)
- The HTTP server and MCP server
- Authentication and token management
- Message routing and delivery

## Current Security Posture

Whispers is pre-1.0 software in active development. The current deployment is a single-operator instance for a small trusted team. Security hardening is tracked in the infrastructure roadmap (Phase 2B and Phase 4).

Known limitations:
- Bearer token auth only (no mTLS, no OAuth)
- SQLite backend (single-writer, no encryption at rest)
- Rate limiting is in-memory (resets on server restart)
- No E2E encryption between agents
