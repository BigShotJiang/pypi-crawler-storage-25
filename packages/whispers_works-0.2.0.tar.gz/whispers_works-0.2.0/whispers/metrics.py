"""Operational metrics — behind-the-scenes view of system health.

Derives metrics from existing data stores (messages, presence, workspaces)
without requiring new database tables or instrumentation.

Design ref: .planning/CONSOLE-METRICS-PAGE-SPEC.md

Scale-aware: every metric must be meaningful at 3 agents and not break at 300.
Counts always have rates. Time displays use appropriate units automatically.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional


@dataclass
class MetricsSummary:
    """Top-level dashboard numbers — the minimal first build."""
    messages_today: int
    delivery_success_rate: float       # 0.0-1.0
    agents_online: int
    active_workspaces: int
    handoffs_today: int
    handoff_ack_rate: float            # 0.0-1.0
    period_start: str                  # ISO 8601 UTC
    period_end: str

    def to_dict(self) -> dict:
        return {
            "messages_today": self.messages_today,
            "delivery_success_rate": round(self.delivery_success_rate, 4),
            "delivery_success_pct": f"{self.delivery_success_rate * 100:.1f}%",
            "agents_online": self.agents_online,
            "active_workspaces": self.active_workspaces,
            "handoffs_today": self.handoffs_today,
            "handoff_ack_rate": round(self.handoff_ack_rate, 4),
            "handoff_ack_pct": f"{self.handoff_ack_rate * 100:.1f}%",
            "period_start": self.period_start,
            "period_end": self.period_end,
        }


@dataclass
class HourlyBucket:
    """One hour of message throughput."""
    hour: str          # "2026-03-26T14:00:00Z"
    sent: int
    delivered: int
    failed: int

    def to_dict(self) -> dict:
        return {
            "hour": self.hour,
            "sent": self.sent,
            "delivered": self.delivered,
            "failed": self.failed,
        }


def compute_summary(conn: sqlite3.Connection, *, agents_online: int = 0, active_workspaces: int = 0) -> MetricsSummary:
    """Compute the top-level metrics summary from existing data stores.

    agents_online and active_workspaces are passed in from the caller since
    they come from in-memory state (presence leases, workspace manager) rather
    than simple SQL queries.
    """
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    period_start = today_start.strftime("%Y-%m-%dT%H:%M:%SZ")
    period_end = now.strftime("%Y-%m-%dT%H:%M:%SZ")

    # Message counts today
    row = conn.execute(
        "SELECT COUNT(*) as total FROM messages WHERE created_at >= ?",
        (period_start,),
    ).fetchone()
    messages_today = row["total"] if row else 0

    # Delivery success rate today (count non-failures rather than specific success statuses)
    delivery_row = conn.execute(
        """
        SELECT
            COUNT(*) as total,
            SUM(CASE WHEN r.delivery_status IN ('failed', 'dead_lettered') THEN 1 ELSE 0 END) as failed
        FROM message_recipients r
        JOIN messages m ON r.message_uuid = m.uuid
        WHERE m.created_at >= ?
        """,
        (period_start,),
    ).fetchone()
    total_deliveries = delivery_row["total"] if delivery_row else 0
    failed = delivery_row["failed"] if delivery_row else 0
    delivery_rate = (total_deliveries - failed) / total_deliveries if total_deliveries > 0 else 1.0

    # Handoff counts today (messages with handoff_baton.v1 schema)
    handoff_row = conn.execute(
        """
        SELECT
            COUNT(*) as total,
            SUM(CASE WHEN r.ack_state IS NOT NULL AND r.ack_state != '' THEN 1 ELSE 0 END) as acked
        FROM messages m
        LEFT JOIN message_recipients r ON m.uuid = r.message_uuid
        WHERE m.created_at >= ?
          AND (m.msg_type = 'handoff' OR m.payload LIKE '%handoff_baton.v1%')
        """,
        (period_start,),
    ).fetchone()
    handoffs_today = handoff_row["total"] if handoff_row else 0
    handoffs_acked = handoff_row["acked"] if handoff_row else 0
    handoff_ack_rate = handoffs_acked / handoffs_today if handoffs_today > 0 else 1.0

    return MetricsSummary(
        messages_today=messages_today,
        delivery_success_rate=delivery_rate,
        agents_online=agents_online,
        active_workspaces=active_workspaces,
        handoffs_today=handoffs_today,
        handoff_ack_rate=handoff_ack_rate,
        period_start=period_start,
        period_end=period_end,
    )


def compute_hourly_throughput(conn: sqlite3.Connection, *, hours: int = 24) -> List[HourlyBucket]:
    """Message throughput broken down by hour for the last N hours."""
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=hours)
    cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")

    rows = conn.execute(
        """
        SELECT
            strftime('%%Y-%%m-%%dT%%H:00:00Z', m.created_at) as hour,
            COUNT(*) as sent,
            SUM(CASE WHEN r.delivery_status IN ('delivered', 'claimed') THEN 1 ELSE 0 END) as delivered,
            SUM(CASE WHEN r.delivery_status = 'failed' THEN 1 ELSE 0 END) as failed
        FROM messages m
        LEFT JOIN message_recipients r ON m.uuid = r.message_uuid
        WHERE m.created_at >= ?
        GROUP BY hour
        ORDER BY hour ASC
        """,
        (cutoff_str,),
    ).fetchall()

    return [
        HourlyBucket(
            hour=row["hour"],
            sent=row["sent"],
            delivered=row["delivered"] or 0,
            failed=row["failed"] or 0,
        )
        for row in rows
    ]
