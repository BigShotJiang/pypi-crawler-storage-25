"""
Connection Story and Briefing Capsule — Tranche 1 of the Collaboration Runtime.

The Connection Story is the canonical startup/runtime truth object. It captures
everything an agent needs to know on arrival: identity, session, peers, pending
obligations, and recommended next action.

The Briefing Capsule is the compact, token-efficient presentation of that truth
— what gets delivered to the agent in startup instructions.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Optional

from whispers import __version__, SCHEMA_VERSION
from whispers.context_cost import ContextBudgetStatus
from whispers.coordination_runtime import CoordinationItem, render_coordination_lines
from whispers.jolt import (
    HostWakeCapabilities,
    JoltContext,
    JoltHostAdapter,
    JoltBudget,
    JoltDecision,
    baseline_capabilities_for_wake_model,
    conservative_jolt_budget,
    decide_jolt_action,
)
from whispers.startup import (
    ICON_FLASH,
    ICON_INFORM,
    SIGNAL_PREFIX,
    STARTUP_MESSAGE_HANDLING_RULE,
    build_attention_treatment_summary,
    build_wake_posture_summary,
    format_attention_treatment_summary,
    format_wake_posture_summary,
    format_pending_by_class_counts,
    render_local_client_auth_lines,
    render_active_baton_token,
    render_baton_state_tokens,
    render_huddle_baton_tokens,
    render_status_line,
    render_waiting_baton_token,
)
from whispers.time_utils import parse_timestamp, utc_now, utc_now_iso


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class PeerSnapshot:
    """Compact view of a single online peer."""
    callsign: str
    agent_type: str = "unknown"
    readiness: str = "ready"
    reception_mode: str = "open"
    working_on: Optional[str] = None
    current_task: Optional[str] = None
    attention_state: Optional[str] = None
    attention_detail: Optional[str] = None
    progress_summary: Optional[str] = None
    trust_tier: Optional[int] = None
    derived_active_mode: str = "ready"
    wake_model: Optional[str] = None
    operator_nudge_required: Optional[bool] = None
    basis: Optional[str] = None
    runtime_updated_at: Optional[str] = None
    freshness_posture: Optional[str] = None
    presence_kind: Optional[str] = None
    evidence_refs: Optional[list[str]] = None
    actionable_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class HuddlePeer:
    """Peer with explicit close-work adjacency."""
    callsign: str
    readiness: str = "ready"
    derived_active_mode: str = "ready"
    working_on: Optional[str] = None
    basis: Optional[str] = None
    runtime_updated_at: Optional[str] = None
    shared_workspaces: list[str] = field(default_factory=list)
    incoming_baton_from_them: bool = False
    outgoing_baton_to_them: bool = False
    incoming_baton_count: int = 0
    outgoing_baton_count: int = 0
    reasons: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        if d.get("working_on") is None:
            d.pop("working_on", None)
        if not d.get("shared_workspaces"):
            d.pop("shared_workspaces", None)
        if not d.get("reasons"):
            d.pop("reasons", None)
        if not d.get("incoming_baton_from_them"):
            d.pop("incoming_baton_from_them", None)
        if not d.get("outgoing_baton_to_them"):
            d.pop("outgoing_baton_to_them", None)
        if not d.get("incoming_baton_count"):
            d.pop("incoming_baton_count", None)
        if not d.get("outgoing_baton_count"):
            d.pop("outgoing_baton_count", None)
        return d


@dataclass
class BatonDetail:
    """Operator-readable snapshot of a single active baton."""
    baton_ref: str
    counterpart: str
    direction: str = "incoming"  # "incoming" or "outgoing"
    state: str = "offered"
    priority: str = "routine"
    label: str = ""
    last_update: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    workspace_id: Optional[str] = None
    working_scope: Optional[str] = None
    version: int = 1

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class ActiveReplyAlert:
    """Unread collaborator reply or checkpoint that should stay hot."""

    message_id: str
    counterpart: str
    subject: str
    priority: str = "routine"
    msg_type: str = "inform"
    created_at: Optional[str] = None
    reply_to: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class ActiveThreadWatch:
    """Recent outbound thread that should stay operator-visible until it resolves."""

    message_id: str
    counterpart: str
    subject: str
    stage: str = "awaiting_read"
    priority: str = "routine"
    msg_type: str = "inform"
    created_at: Optional[str] = None
    delivered_at: Optional[str] = None
    read_at: Optional[str] = None
    stage_started_at: Optional[str] = None
    stage_label: Optional[str] = None
    age_label: Optional[str] = None
    reception_truth: Optional[dict[str, Any]] = None

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class SinceLastSeen:
    """What changed since this agent's previous session."""
    last_session_ended: Optional[str] = None  # ISO timestamp
    messages_arrived: int = 0
    messages_by_priority: dict[str, int] = field(default_factory=dict)
    messages_by_class: dict[str, int] = field(default_factory=dict)
    messages_by_sender: dict[str, dict[str, Any]] = field(default_factory=dict)
    peers_joined: list[str] = field(default_factory=list)
    peers_departed: list[str] = field(default_factory=list)
    is_first_session: bool = False

    # Baton changes
    batons_received: int = 0
    batons_completed: int = 0
    batons_expired: int = 0

    # Workspace activity
    workspace_events: int = 0
    active_workspaces: list[str] = field(default_factory=list)

    # Process run state
    tasks_assigned: int = 0
    tasks_completed_by_others: int = 0

    # Resume suggestion
    resume_hint: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        for key in ("messages_by_priority", "messages_by_class", "messages_by_sender", "peers_joined", "peers_departed", "active_workspaces"):
            if not d.get(key):
                d.pop(key, None)
        for key in ("batons_received", "batons_completed", "batons_expired",
                     "workspace_events", "tasks_assigned", "tasks_completed_by_others"):
            if not d.get(key):
                d.pop(key, None)
        if not d.get("resume_hint"):
            d.pop("resume_hint", None)
        return d


@dataclass
class ConnectionStory:
    """
    Canonical startup/runtime truth object.

    Assembled once on connection (or on demand), this is the single source of
    truth for: startup summary, status, doctor, onboarding UX, dashboard views,
    and the briefing capsule delivered to agents.
    """
    # Identity
    agent_name: str
    agent_type: str = "unknown"
    trust_tier: int = 1
    display_name: Optional[str] = None

    # Session
    session_id: Optional[str] = None
    deployment_mode: str = "standalone"
    transport: str = "http"

    # Signal state
    signal_mode: str = "OPEN"
    readiness: str = "ready"
    derived_active_mode: str = "ready"
    wake_model: Optional[str] = None
    interruptibility: Optional[str] = None
    basis: Optional[str] = None
    runtime_updated_at: Optional[str] = None

    # Peers
    peers: list[PeerSnapshot] = field(default_factory=list)
    huddle_peers: list[HuddlePeer] = field(default_factory=list)
    peers_online_count: int = 0
    agents_registered: int = 0

    # Pending obligations
    pending_messages: int = 0
    pending_by_priority: dict[str, int] = field(default_factory=dict)
    pending_by_class: dict[str, int] = field(default_factory=dict)
    attention_treatment: dict[str, Any] = field(default_factory=dict)
    unread_flash: int = 0
    incoming_batons: int = 0
    carrying_batons: int = 0
    claimed_reviews: int = 0
    pending_assignments: int = 0
    pending_review_requests: int = 0
    blocking_review_requests: int = 0
    blocked_waiting_for_review: int = 0
    answered_waiting_to_close: int = 0
    coordination_highlights: list[CoordinationItem] = field(default_factory=list)
    captain_action_alerts: list[dict[str, Any]] = field(default_factory=list)
    active_reply_alerts: list[ActiveReplyAlert] = field(default_factory=list)
    active_thread_watches: list[ActiveThreadWatch] = field(default_factory=list)

    # Unread message previews (top-N, attention-filtered)
    unread_previews: list[dict[str, Any]] = field(default_factory=list)

    # Baton details (per-baton operator truth)
    baton_details: list[BatonDetail] = field(default_factory=list)

    # Resume awareness
    since_last_seen: Optional[SinceLastSeen] = None

    # Narrator state
    narrator_agent: Optional[str] = None
    narrator_status: str = "disabled"  # disabled | designated | active | degraded
    context_budget: Optional[ContextBudgetStatus] = None
    jolt_packet: Optional["JoltPacket"] = None
    jolt_adapter: Optional[JoltHostAdapter] = None
    jolt_host_capabilities: Optional[HostWakeCapabilities] = None
    jolt_budget: Optional[JoltBudget] = None
    jolt_decision: Optional[JoltDecision] = None

    # Courtesy activity (machine courtesy visibility for operator)
    courtesy_summary: Optional[dict[str, Any]] = None

    # Recommended action
    recommended_action: Optional[str] = None

    # Metadata
    server_time_utc: str = field(default_factory=utc_now_iso)
    local_time: Optional[str] = None
    whispers_version: str = __version__
    schema_version: int = SCHEMA_VERSION
    http_server_reachable: Optional[bool] = None
    local_client_auth_healthy: Optional[bool] = None
    local_client_token_source: Optional[str] = None
    local_client_auth_issue: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        peer_assignment_alerts = _peers_needing_assignment(self.peers)
        peer_nudge_alerts = _peers_needing_operator_nudge(self.peers)
        wake_posture = build_wake_posture_summary(
            wake_model=self.wake_model,
            interruptibility=self.interruptibility,
        )
        reentry_packet = _build_reentry_packet(self)
        d: dict[str, Any] = {
            "agent_name": self.agent_name,
            "agent_type": self.agent_type,
            "trust_tier": self.trust_tier,
            "deployment_mode": self.deployment_mode,
            "transport": self.transport,
            "signal_mode": self.signal_mode,
            "readiness": self.readiness,
            "derived_active_mode": self.derived_active_mode,
            "peers": [p.to_dict() for p in self.peers],
            "huddle_peers": [p.to_dict() for p in self.huddle_peers],
            "peers_online_count": self.peers_online_count,
            "agents_registered": self.agents_registered,
            "pending_messages": self.pending_messages,
            "pending_by_priority": self.pending_by_priority,
            "pending_by_class": self.pending_by_class,
            "has_blocking_obligations": bool(self.carrying_batons > 0 or self.incoming_batons > 0 or self.pending_assignments > 0 or self.claimed_reviews > 0),
            "unread_flash": self.unread_flash,
            "incoming_batons": self.incoming_batons,
            "carrying_batons": self.carrying_batons,
            "claimed_reviews": self.claimed_reviews,
            "baton_details": [b.to_dict() for b in self.baton_details],
            "pending_assignments": self.pending_assignments,
            "pending_review_requests": self.pending_review_requests,
            "blocking_review_requests": self.blocking_review_requests,
            "blocked_waiting_for_review": self.blocked_waiting_for_review,
            "answered_waiting_to_close": self.answered_waiting_to_close,
            "coordination_highlights": [item.to_dict() for item in self.coordination_highlights],
            "captain_action_requests": len(self.captain_action_alerts),
            "captain_action_alerts": self.captain_action_alerts,
            "active_reply_requests": len(self.active_reply_alerts),
            "active_reply_alerts": [item.to_dict() for item in self.active_reply_alerts],
            "active_thread_watch_count": len(self.active_thread_watches),
            "active_thread_watches": [item.to_dict() for item in self.active_thread_watches],
            "peer_assignment_requests": len(peer_assignment_alerts),
            "peer_assignment_alerts": [peer.to_dict() for peer in peer_assignment_alerts],
            "peer_nudge_requests": len(peer_nudge_alerts),
            "peer_nudge_alerts": [peer.to_dict() for peer in peer_nudge_alerts],
            "narrator_agent": self.narrator_agent,
            "narrator_status": self.narrator_status,
            "recommended_action": self.recommended_action,
            "server_time_utc": self.server_time_utc,
            "local_time": self.local_time,
            "whispers_version": self.whispers_version,
            "schema_version": self.schema_version,
        }
        if self.display_name:
            d["display_name"] = self.display_name
        if self.attention_treatment:
            d["attention_treatment"] = self.attention_treatment
        if self.session_id:
            d["session_id"] = self.session_id
        if self.wake_model:
            d["wake_model"] = self.wake_model
        if self.interruptibility:
            d["interruptibility"] = self.interruptibility
        if wake_posture:
            d["wake_posture"] = wake_posture
        if self.basis:
            d["basis"] = self.basis
        if self.runtime_updated_at:
            d["runtime_updated_at"] = self.runtime_updated_at
        if self.since_last_seen:
            d["since_last_seen"] = self.since_last_seen.to_dict()
        if reentry_packet:
            d["reentry_packet"] = reentry_packet
        if self.context_budget:
            d["context_budget"] = self.context_budget.to_dict()
        if self.jolt_packet is not None:
            d["jolt_packet"] = self.jolt_packet.to_dict()
        if self.jolt_adapter is not None:
            d["jolt_adapter"] = self.jolt_adapter.to_dict()
        if self.jolt_host_capabilities is not None:
            d["jolt_host_capabilities"] = self.jolt_host_capabilities.to_dict()
        if self.jolt_budget is not None:
            d["jolt_budget"] = self.jolt_budget.to_dict()
        if self.jolt_decision is not None:
            d["jolt"] = self.jolt_decision.to_dict()
        if self.http_server_reachable is not None:
            d["http_server_reachable"] = self.http_server_reachable
        if self.local_client_auth_healthy is not None:
            d["local_client_auth_healthy"] = self.local_client_auth_healthy
        if self.local_client_token_source:
            d["local_client_token_source"] = self.local_client_token_source
        if self.local_client_auth_issue:
            d["local_client_auth_issue"] = self.local_client_auth_issue
        if self.courtesy_summary and self.courtesy_summary.get("total_actions", 0) > 0:
            d["courtesy_summary"] = self.courtesy_summary
        return d


@dataclass(frozen=True)
class JoltPacket:
    action: str
    trigger: str
    headline: str
    wake_model: Optional[str] = None
    priority: str = "routine"
    interruptibility: str = "defer"
    blocking: bool = False
    explicitly_addressed: bool = False
    recommended_action: Optional[str] = None
    freshness: Optional[str] = None
    age_seconds: Optional[int] = None
    age_label: Optional[str] = None
    stale_after_seconds: Optional[int] = None
    source_stage: Optional[str] = None
    adapter: Optional[JoltHostAdapter] = None
    reasons: list[str] = field(default_factory=list)
    budget_limited: bool = False
    fallback_used: bool = False
    version: str = "jolt-packet-v1"

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "version": self.version,
            "action": self.action,
            "trigger": self.trigger,
            "headline": self.headline,
            "priority": self.priority,
            "interruptibility": self.interruptibility,
            "blocking": self.blocking,
            "explicitly_addressed": self.explicitly_addressed,
            "reasons": list(self.reasons),
            "budget_limited": self.budget_limited,
            "fallback_used": self.fallback_used,
        }
        if self.wake_model:
            payload["wake_model"] = self.wake_model
        if self.recommended_action:
            payload["recommended_action"] = self.recommended_action
        if self.freshness:
            payload["freshness"] = self.freshness
        if self.age_seconds is not None:
            payload["age_seconds"] = self.age_seconds
        if self.age_label:
            payload["age_label"] = self.age_label
        if self.stale_after_seconds is not None:
            payload["stale_after_seconds"] = self.stale_after_seconds
        if self.source_stage:
            payload["source_stage"] = self.source_stage
        if self.adapter is not None:
            payload["adapter"] = self.adapter.to_dict()
        return payload


# ---------------------------------------------------------------------------
# Briefing Capsule — compact, token-efficient presentation
# ---------------------------------------------------------------------------

_PRIORITY_ORDER = ("system", "flash", "priority", "routine")

_DEPLOYMENT_LABELS = {
    "embedded": "Embedded",
    "standalone": "Standalone",
    "remote": "Remote",
    "mock": "Mock",
}

_CONTEXT_BUDGET_LABELS = {
    "full": "full delivery ok",
    "summarize": "prefer summaries for larger packets",
    "headline_only": "prefer headlines only until load drops",
    "defer": "defer non-urgent packets until load drops",
}

_JOLT_ACTION_LABELS = {
    "notify": "notify only",
    "stage_context": "stage local context",
    "infer": "run autonomous inference",
}

_JOLT_TRIGGER_LABELS = {
    "flash_message": "flash attention",
    "hot_thread": "hot thread pressure",
    "blocking_dependency": "blocking dependency",
    "direct_assignment": "direct assignment",
    "ambient_update": "ambient update",
    "operator_directed": "operator-directed wake",
}

_JOLT_HOT_THREAD_STALE_AFTER_SECONDS = 4 * 60


def _deployment_label(mode: str) -> str:
    mode = (mode or "unknown").strip().lower()
    return _DEPLOYMENT_LABELS.get(mode, mode.replace("_", " ").title())


def _format_pending(by_priority: dict[str, int]) -> str:
    if not by_priority:
        return "none"
    parts: list[str] = []
    for p in _PRIORITY_ORDER:
        if p in by_priority:
            parts.append(f"{p} {by_priority[p]}")
    for p in sorted(by_priority):
        if p not in _PRIORITY_ORDER:
            parts.append(f"{p} {by_priority[p]}")
    return ", ".join(parts) if parts else "none"


def _format_workspace_labels(labels: list[str], max_items: int = 2) -> str:
    if not labels:
        return ""
    if len(labels) <= max_items:
        return ", ".join(labels)
    return f"{', '.join(labels[:max_items])} +{len(labels) - max_items}"


def _render_context_budget_line(context_budget: ContextBudgetStatus | None) -> str | None:
    if not context_budget:
        return None
    load_pct = round(context_budget.current_load * 100)
    depth_label = _CONTEXT_BUDGET_LABELS.get(
        context_budget.default_delivery_depth,
        context_budget.default_delivery_depth.replace("_", " "),
    )
    return (
        f"Context budget: {load_pct}% load | "
        f"~{context_budget.remaining_tokens_estimate:,} tokens remaining | "
        f"{depth_label}"
    )


def _format_attention_age_label(age_seconds: float) -> str:
    seconds = max(0, int(age_seconds))
    if seconds >= 86_400:
        return f"{seconds / 86_400:.1f}d"
    if seconds >= 3_600:
        return f"{seconds / 3_600:.1f}h"
    if seconds >= 60:
        return f"{seconds // 60}m"
    return f"{seconds}s"


def _build_freshness_fields(
    signal_started_at,
    *,
    source_stage: str | None = None,
) -> dict[str, Any]:
    if signal_started_at is None:
        return {}
    age_seconds = max(0.0, (utc_now() - signal_started_at).total_seconds())
    freshness = "stale" if age_seconds >= _JOLT_HOT_THREAD_STALE_AFTER_SECONDS else "fresh"
    return {
        "freshness": freshness,
        "age_seconds": int(age_seconds),
        "age_label": _format_attention_age_label(age_seconds),
        "stale_after_seconds": _JOLT_HOT_THREAD_STALE_AFTER_SECONDS,
        "source_stage": source_stage,
    }


def _build_active_reply_freshness_fields(alerts: list[ActiveReplyAlert]) -> dict[str, Any]:
    if not alerts:
        return {}
    alert = alerts[0]
    return _build_freshness_fields(
        parse_timestamp(alert.created_at),
        source_stage="reply_ready",
    )


def _build_thread_watch_freshness_fields(watches: list[ActiveThreadWatch]) -> dict[str, Any]:
    if not watches:
        return {}
    watch = watches[0]
    return _build_freshness_fields(
        parse_timestamp(watch.stage_started_at or watch.read_at or watch.delivered_at or watch.created_at),
        source_stage=watch.stage or None,
    )


def _build_hot_thread_freshness_fields(story: ConnectionStory) -> dict[str, Any]:
    if story.active_reply_alerts:
        return _build_active_reply_freshness_fields(story.active_reply_alerts)
    if story.active_thread_watches:
        return _build_thread_watch_freshness_fields(story.active_thread_watches)
    return {}


def _is_stale_hot_thread(fields: dict[str, Any]) -> bool:
    return str(fields.get("freshness") or "").strip().lower() == "stale"


def _effective_interruptibility(story: ConnectionStory) -> str:
    normalized = str(story.interruptibility or "").strip().lower()
    if normalized in {"free", "defer", "urgent_only", "do_not_interrupt"}:
        return normalized
    if story.signal_mode == "FOCUSED":
        return "defer"
    return "free"


def _surface_now_actionable_count(story: ConnectionStory) -> int:
    pending_by_class = story.pending_by_class if isinstance(story.pending_by_class, dict) else {}
    actionable = int(pending_by_class.get("actionable", 0) or 0)
    if actionable <= 0 or story.pending_messages <= 0:
        return 0

    attention_treatment = story.attention_treatment if isinstance(story.attention_treatment, dict) else {}
    counts = attention_treatment.get("counts") if isinstance(attention_treatment.get("counts"), dict) else {}
    surface_now = int(counts.get("surface_now", 0) or 0)
    if surface_now <= 0:
        return 0
    return min(actionable, surface_now)


def _build_jolt_context(story: ConnectionStory) -> JoltContext | None:
    wake_model = str(story.wake_model or "").strip().lower() or None
    if not wake_model:
        return None

    interruptibility = _effective_interruptibility(story)
    flash = story.pending_by_priority.get("flash", 0) + story.pending_by_priority.get("system", 0)
    if flash > 0:
        return JoltContext(
            trigger="flash_message",
            wake_model=wake_model,
            interruptibility=interruptibility,
            priority="flash",
            explicitly_addressed=True,
            blocking=True,
            message_size_tier="signal",
        )

    reply_freshness = _build_active_reply_freshness_fields(story.active_reply_alerts)
    if story.active_reply_alerts and not _is_stale_hot_thread(reply_freshness):
        return JoltContext(
            trigger="hot_thread",
            wake_model=wake_model,
            interruptibility=interruptibility,
            priority="priority",
            explicitly_addressed=True,
            already_hot=False,
            message_size_tier="message",
        )

    thread_freshness = _build_thread_watch_freshness_fields(story.active_thread_watches)
    if story.active_thread_watches and not _is_stale_hot_thread(thread_freshness):
        return JoltContext(
            trigger="hot_thread",
            wake_model=wake_model,
            interruptibility=interruptibility,
            priority="priority",
            explicitly_addressed=True,
            already_hot=bool(story.active_thread_watches),
            message_size_tier="message",
        )

    blocking_review = next(
        (
            item
            for item in story.coordination_highlights
            if item.direction == "incoming"
            and item.kind == "review_request"
            and item.blocking
        ),
        None,
    )
    if blocking_review or story.blocked_waiting_for_review > 0:
        return JoltContext(
            trigger="blocking_dependency",
            wake_model=wake_model,
            interruptibility=interruptibility,
            priority="priority",
            explicitly_addressed=True,
            blocking=True,
            message_size_tier="message",
        )

    if (
        story.incoming_batons > 0
        or story.pending_assignments > 0
        or story.pending_review_requests > 0
        or story.captain_action_alerts
        or _peers_needing_assignment(story.peers)
        or _surface_now_actionable_count(story) > 0
    ):
        return JoltContext(
            trigger="direct_assignment",
            wake_model=wake_model,
            interruptibility=interruptibility,
            priority="priority",
            explicitly_addressed=True,
            blocking=bool(story.incoming_batons or story.pending_review_requests),
            message_size_tier="message",
        )

    return JoltContext(
        trigger="ambient_update",
        wake_model=wake_model,
        interruptibility=interruptibility,
        priority="routine",
        message_size_tier="message",
    )


def infer_jolt_decision(story: ConnectionStory) -> JoltDecision | None:
    wake_model = str(story.wake_model or "").strip().lower() or None
    if not wake_model:
        return None

    flash = story.pending_by_priority.get("flash", 0) + story.pending_by_priority.get("system", 0)
    if story.signal_mode == "QUIET" and flash <= 0:
        return JoltDecision("suppress", reasons=["signal mode is QUIET"])

    context = _build_jolt_context(story)
    if context is None:
        return None

    return decide_jolt_action(
        context,
        story.jolt_host_capabilities or baseline_capabilities_for_wake_model(wake_model),
        story.jolt_budget or conservative_jolt_budget(),
    )


def _priority_filter_for_interruptibility(interruptibility: str | None) -> set[str] | None:
    """Map interruptibility state to allowed preview priorities for coherence."""
    norm = str(interruptibility or "").strip().lower()
    if norm == "do_not_interrupt":
        return {"flash", "system"}
    if norm in ("defer", "urgent_only"):
        return {"flash", "system", "priority"}
    return None  # free — show all


def _top_preview_headline(previews: list[dict[str, Any]], priority_filter: set[str] | None = None) -> str | None:
    """Extract a content-rich headline from the top matching preview."""
    for p in (previews or []):
        prio = str(p.get("priority") or "routine").lower()
        if priority_filter and prio not in priority_filter:
            continue
        sender = str(p.get("from_agent") or "").strip()
        subject = str(p.get("subject") or "").strip()
        if sender and subject:
            return f"{sender}: {subject}"
    return None


def _jolt_headline(story: ConnectionStory, context: JoltContext) -> str:
    previews = story.unread_previews or []

    if context.trigger == "flash_message":
        flash = story.pending_by_priority.get("flash", 0) + story.pending_by_priority.get("system", 0)
        # Enrich with actual flash message content
        content = _top_preview_headline(previews, {"flash", "system"})
        if content:
            suffix = f" (+{flash - 1} more)" if flash > 1 else ""
            return f"{content}{suffix}"
        return f"{flash} flash/system message{'s' if flash != 1 else ''} waiting"

    if context.trigger == "hot_thread":
        if story.active_reply_alerts:
            alert = story.active_reply_alerts[0]
            return f"Hot reply from {alert.counterpart}: {alert.subject}"
        if story.active_thread_watches:
            watch = story.active_thread_watches[0]
            return f"Hot thread with {watch.counterpart}: {watch.subject}"
        return "Hot collaboration thread needs attention"

    if context.trigger == "blocking_dependency":
        blocking_review = next(
            (
                item
                for item in story.coordination_highlights
                if item.direction == "incoming"
                and item.kind == "review_request"
                and item.blocking
            ),
            None,
        )
        if blocking_review:
            return f"Blocking review from {blocking_review.counterpart}: {blocking_review.subject}"
        if story.blocked_waiting_for_review > 0:
            return f"{story.blocked_waiting_for_review} review block{'s' if story.blocked_waiting_for_review != 1 else ''} waiting"
        return "Blocking dependency waiting on review"

    if context.trigger == "direct_assignment":
        # Enrich with actual message content — respect interruptibility for coherence
        pf = _priority_filter_for_interruptibility(story.interruptibility)
        content = _top_preview_headline(previews, pf)
        if story.incoming_batons > 0:
            if content:
                suffix = f" (+{story.incoming_batons - 1} more)" if story.incoming_batons > 1 else ""
                return f"{content}{suffix}"
            return f"{story.incoming_batons} incoming baton{'s' if story.incoming_batons != 1 else ''} waiting"
        if story.pending_review_requests > 0:
            return f"{story.pending_review_requests} review request{'s' if story.pending_review_requests != 1 else ''} waiting"
        if story.pending_assignments > 0:
            if content:
                return content
            return f"{story.pending_assignments} assignment{'s' if story.pending_assignments != 1 else ''} waiting"
        if story.captain_action_alerts:
            alert = story.captain_action_alerts[0]
            sender = str(alert.get("sender") or "peer").strip() or "peer"
            label = str(alert.get("label") or alert.get("kind") or "packet").strip()
            return f"Captain packet from {sender}: {label}"
        alerts = _peers_needing_assignment(story.peers)
        if alerts:
            return f"{alerts[0].callsign} needs assignment"
        surfaced_actionable = _surface_now_actionable_count(story)
        if surfaced_actionable > 0:
            if content:
                suffix = f" (+{surfaced_actionable - 1} more)" if surfaced_actionable > 1 else ""
                return f"{content}{suffix}"
            return f"{surfaced_actionable} actionable message{'s' if surfaced_actionable != 1 else ''} waiting"
        if content:
            return content
        return "Direct assignment or baton waiting"

    # Ambient — enrich with top preview, respect interruptibility
    pf = _priority_filter_for_interruptibility(story.interruptibility)
    content = _top_preview_headline(previews, pf)
    if content:
        return content
    return story.recommended_action or "Ambient update"


def build_jolt_packet(story: ConnectionStory) -> JoltPacket | None:
    decision = story.jolt_decision or infer_jolt_decision(story)
    if decision is None or decision.action == "suppress":
        return None

    context = _build_jolt_context(story)
    if context is None:
        return None

    recommended_action = story.recommended_action or infer_recommended_action(story)
    freshness_fields = _build_hot_thread_freshness_fields(story) if context.trigger == "hot_thread" else {}
    return JoltPacket(
        action=decision.action,
        trigger=context.trigger,
        headline=_jolt_headline(story, context),
        wake_model=story.wake_model,
        priority=context.priority,
        interruptibility=context.interruptibility,
        blocking=context.blocking,
        explicitly_addressed=context.explicitly_addressed,
        recommended_action=recommended_action,
        freshness=str(freshness_fields.get("freshness") or "").strip() or None,
        age_seconds=freshness_fields.get("age_seconds"),
        age_label=str(freshness_fields.get("age_label") or "").strip() or None,
        stale_after_seconds=freshness_fields.get("stale_after_seconds"),
        source_stage=str(freshness_fields.get("source_stage") or "").strip() or None,
        adapter=story.jolt_adapter,
        reasons=list(decision.reasons),
        budget_limited=decision.budget_limited,
        fallback_used=decision.fallback_used,
    )


def _render_jolt_line(story: ConnectionStory, decision: JoltDecision | None) -> str | None:
    if decision is None or decision.action == "suppress":
        return None

    context = _build_jolt_context(story)
    if context is None:
        return None

    parts = [
        f"Jolt: {_JOLT_ACTION_LABELS.get(decision.action, decision.action)}",
        _JOLT_TRIGGER_LABELS.get(context.trigger, context.trigger.replace("_", " ")),
    ]
    if decision.reasons:
        parts.append(decision.reasons[0])
    if decision.budget_limited:
        parts.append("budget limited")
    return " | ".join(parts)


def _render_peers_online_line(peers: list[PeerSnapshot]) -> str:
    """Render a compact peer list with wake posture annotations."""
    parts = []
    for p in peers:
        name = p.callsign
        annotations = []
        if p.wake_model == "manual_wake":
            annotations.append("manual-wake")
        if p.freshness_posture and p.freshness_posture not in ("normal",):
            annotations.append(p.freshness_posture)
        if annotations:
            name = f"{name} ({', '.join(annotations)})"
        parts.append(name)
    return ", ".join(parts)


def _format_huddle_peer(peer: HuddlePeer) -> str:
    basis_tag = f" {{{peer.basis}}}" if peer.basis else ""
    parts = [f"{peer.callsign} [{peer.readiness}]{basis_tag}"]
    if peer.shared_workspaces:
        parts.append(f"workspace {_format_workspace_labels(peer.shared_workspaces)}")
    parts.extend(
        render_huddle_baton_tokens(
            incoming_baton=peer.incoming_baton_from_them,
            incoming_baton_count=peer.incoming_baton_count,
            outgoing_baton=peer.outgoing_baton_to_them,
            outgoing_baton_count=peer.outgoing_baton_count,
        )
    )
    if peer.working_on and not peer.shared_workspaces:
        parts.append(str(peer.working_on))
    return " | ".join(parts)


def _peers_needing_assignment(peers: list[PeerSnapshot]) -> list[PeerSnapshot]:
    alerts = [
        peer
        for peer in peers
        if (peer.attention_state or "").strip().lower() == "needs_assignment"
    ]
    alerts.sort(
        key=lambda peer: (
            -int(bool(peer.operator_nudge_required)),
            -(peer.trust_tier or 1),
            peer.callsign,
        )
    )
    return alerts


def _render_assignment_alert_lines(peers: list[PeerSnapshot], max_lines: int = 2) -> list[str]:
    alerts = _peers_needing_assignment(peers)
    if not alerts:
        return []

    lines: list[str] = []
    for peer in alerts[:max_lines]:
        detail = peer.attention_detail or peer.progress_summary or peer.current_task
        nudge_suffix = " | operator nudge required (manual wake)" if peer.operator_nudge_required else ""
        if detail:
            lines.append(f"Team alert: {peer.callsign} needs assignment{nudge_suffix} | {detail}")
        else:
            lines.append(f"Team alert: {peer.callsign} needs assignment{nudge_suffix}")
    overflow = len(alerts) - max_lines
    if overflow > 0:
        lines.append(f"Team alert: +{overflow} more peer{'s' if overflow != 1 else ''} need assignment")
    return lines


def _render_captain_action_lines(alerts: list[dict[str, Any]], max_lines: int = 2) -> list[str]:
    if not alerts:
        return []

    lines: list[str] = []
    for alert in alerts[:max_lines]:
        sender = str(alert.get("sender") or "peer").strip() or "peer"
        label = str(alert.get("label") or alert.get("kind") or "update").strip()
        detail = (
            str(alert.get("detail") or alert.get("subject") or "").strip()
            or None
        )
        if detail:
            lines.append(f"Captain alert: {sender} {label} pending | {detail}")
        else:
            lines.append(f"Captain alert: {sender} {label} pending")
    overflow = len(alerts) - max_lines
    if overflow > 0:
        lines.append(f"Captain alert: +{overflow} more peer packet{'s' if overflow != 1 else ''} waiting")
    return lines


def _render_active_reply_lines(alerts: list[ActiveReplyAlert], max_lines: int = 2) -> list[str]:
    if not alerts:
        return []

    freshness = _build_active_reply_freshness_fields(alerts)
    is_stale = _is_stale_hot_thread(freshness)
    prefix = "Reply waiting" if is_stale else "Hot reply"
    lines = []
    for alert in alerts[:max_lines]:
        detail = f"{prefix}: {alert.counterpart} responded | {alert.subject}"
        if is_stale and freshness.get("age_label"):
            detail += f" | {freshness['age_label']} old"
        lines.append(detail)
    overflow = len(alerts) - max_lines
    if overflow > 0:
        lines.append(
            f"{prefix}: +{overflow} more collaborator update{'s' if overflow != 1 else ''} waiting"
        )
    return lines


def _group_active_thread_watches(
    watches: list[ActiveThreadWatch],
) -> list[tuple[str, list[ActiveThreadWatch]]]:
    groups: list[tuple[str, list[ActiveThreadWatch]]] = []
    grouped: dict[str, list[ActiveThreadWatch]] = {}
    for watch in watches:
        counterpart = str(watch.counterpart or "peer").strip() or "peer"
        key = counterpart.lower()
        bucket = grouped.get(key)
        if bucket is None:
            bucket = []
            grouped[key] = bucket
            groups.append((counterpart, bucket))
        bucket.append(watch)
    return groups


def _summarize_active_thread_subjects(watches: list[ActiveThreadWatch]) -> str:
    if not watches:
        return "active thread"
    subject = str(watches[0].subject or "active thread").strip() or "active thread"
    overflow = len(watches) - 1
    if overflow > 0:
        return f"{subject} (+{overflow} more)"
    return subject


def _render_active_thread_watch_lines(watches: list[ActiveThreadWatch], max_lines: int = 2) -> list[str]:
    if not watches:
        return []

    grouped = _group_active_thread_watches(watches)
    lines: list[str] = []
    for counterpart, grouped_watches in grouped[:max_lines]:
        watch = grouped_watches[0]
        subject_summary = _summarize_active_thread_subjects(grouped_watches)
        freshness = _build_thread_watch_freshness_fields(grouped_watches)
        hot_prefix = "Cooling thread" if _is_stale_hot_thread(freshness) else "Hot thread"

        if len(grouped_watches) > 1:
            if all(item.stage == "awaiting_reply" for item in grouped_watches):
                detail = f"{hot_prefix}: {counterpart} read multiple messages | {subject_summary}"
                if watch.age_label:
                    detail += f" | awaiting reply for {watch.age_label}"
                lines.append(detail)
                continue
            if all(item.stage == "awaiting_delivery" for item in grouped_watches):
                detail = f"{hot_prefix}: delivery pending to {counterpart} | {subject_summary}"
                if watch.age_label:
                    detail += f" | latest sent {watch.age_label} ago"
                lines.append(detail)
                continue
            if all(item.stage not in {"awaiting_reply", "awaiting_delivery"} for item in grouped_watches):
                detail = f"{hot_prefix}: waiting on {counterpart} to read | {subject_summary}"
                if watch.age_label:
                    age_prefix = watch.stage_label or "delivered"
                    detail += f" | latest {age_prefix} {watch.age_label} ago"
                lines.append(detail)
                continue
            detail = f"{hot_prefix}: multiple active follow-ups with {counterpart} | {subject_summary}"
            if watch.age_label:
                detail += f" | latest update {watch.age_label} ago"
            lines.append(detail)
            continue

        if watch.stage == "awaiting_reply":
            detail = f"{hot_prefix}: {watch.counterpart} read it | {watch.subject}"
            if watch.age_label:
                detail += f" | awaiting reply for {watch.age_label}"
            lines.append(detail)
            continue
        if watch.stage == "awaiting_delivery":
            detail = f"{hot_prefix}: delivery pending to {watch.counterpart} | {watch.subject}"
            if watch.age_label:
                detail += f" | sent {watch.age_label} ago"
            lines.append(detail)
            continue
        detail = f"{hot_prefix}: waiting on {watch.counterpart} to read | {watch.subject}"
        if watch.age_label:
            age_prefix = watch.stage_label or "delivered"
            detail += f" | {age_prefix} {watch.age_label} ago"
        lines.append(detail)

    overflow = len(grouped) - max_lines
    if overflow > 0:
        lines.append(f"Thread context: +{overflow} more active thread{'s' if overflow != 1 else ''} waiting")
    return lines


def _peers_needing_operator_nudge(peers: list[PeerSnapshot]) -> list[PeerSnapshot]:
    return [peer for peer in _peers_needing_assignment(peers) if peer.operator_nudge_required]


def _render_huddle_lines(huddle_peers: list[HuddlePeer], max_lines: int = 3) -> list[str]:
    if not huddle_peers:
        return []
    lines = [f"Huddle nearby: {_format_huddle_peer(peer)}" for peer in huddle_peers[:max_lines]]
    overflow = len(huddle_peers) - max_lines
    if overflow > 0:
        lines.append(f"Huddle nearby: +{overflow} more adjacent peer{'s' if overflow != 1 else ''}")
    return lines


_BATON_STATE_LABELS = {
    "offered": "waiting for ack",
    "accepted": "accepted",
    "conditionally_accepted": "conditionally accepted",
    "in_progress": "in progress",
    "blocked": "BLOCKED",
    "review_pending": "review pending",
}

_BATON_DIRECTION_ARROWS = {
    "incoming": "\u2190",  # ←
    "outgoing": "\u2192",  # →
}


def _render_baton_detail_lines(
    baton_details: list[BatonDetail], max_lines: int = 4
) -> list[str]:
    if not baton_details:
        return []

    from whispers.coordination_runtime import _compute_age_seconds, _format_age

    lines: list[str] = []
    for baton in baton_details[:max_lines]:
        arrow = _BATON_DIRECTION_ARROWS.get(baton.direction, "\u2194")
        state_label = _BATON_STATE_LABELS.get(baton.state, baton.state)
        label = baton.label[:60] if baton.label else "untitled"
        parts = [f"  {arrow} {baton.counterpart}: {label} [{state_label}]"]
        if baton.last_update:
            parts.append(baton.last_update[:60])
        # Show how long the baton has been in its current state
        age_source = baton.updated_at or baton.created_at
        age = _compute_age_seconds(age_source) if age_source else None
        if age is not None:
            parts.append(_format_age(age))
        lines.append(" | ".join(parts))

    overflow = len(baton_details) - max_lines
    if overflow > 0:
        lines.append(f"  +{overflow} more active baton{'s' if overflow != 1 else ''}")
    return lines


def _render_blocking_obligations(story: ConnectionStory) -> list[str]:
    debts = []
    if story.incoming_batons > 0:
        debts.append(f"{story.incoming_batons} incoming baton{'s' if story.incoming_batons != 1 else ''} waiting")
    if story.carrying_batons > 0:
        debts.append(f"{story.carrying_batons} carried baton{'s' if story.carrying_batons != 1 else ''} open")
    if story.pending_assignments > 0:
        debts.append(f"{story.pending_assignments} unresolved assignment{'s' if story.pending_assignments != 1 else ''}")
    if story.claimed_reviews > 0:
        debts.append(f"{story.claimed_reviews} claimed review{'s' if story.claimed_reviews != 1 else ''}")
        
    if not debts:
        return []
        
    from whispers.startup import SIGNAL_PREFIX
    return [
        "",
        f"{SIGNAL_PREFIX} ⚠️ BLOCKING OBLIGATIONS (Must resolve before yielding):",
        f"  - {', '.join(debts)}"
    ]


def _build_reentry_packet(story: ConnectionStory) -> dict[str, Any]:
    wake_posture = build_wake_posture_summary(
        wake_model=story.wake_model,
        interruptibility=story.interruptibility,
    )
    if not wake_posture:
        return {}

    sls = story.since_last_seen
    changed: list[str] = []
    if sls and not sls.is_first_session:
        if sls.messages_arrived > 0:
            if sls.messages_by_sender:
                senders = sorted(
                    sls.messages_by_sender.keys(),
                    key=lambda s: sls.messages_by_sender[s].get("count", 0),
                    reverse=True,
                )
                sender_summary = ", ".join(senders[:3])
                if len(senders) > 3:
                    sender_summary += f" +{len(senders) - 3}"
                changed.append(f"{sls.messages_arrived} new from {sender_summary}")
            else:
                changed.append(
                    f"{sls.messages_arrived} new message{'s' if sls.messages_arrived != 1 else ''}"
                )
            # Queue class breakdown so the agent knows what kind of work arrived
            if sls.messages_by_class:
                class_parts = []
                for cls_name in ("actionable", "conversation", "system"):
                    count = sls.messages_by_class.get(cls_name, 0)
                    if count > 0:
                        class_parts.append(f"{count} {cls_name}")
                if class_parts:
                    changed.append(f"by class: {', '.join(class_parts)}")
        if sls.batons_received > 0:
            changed.append(
                f"{sls.batons_received} incoming baton{'s' if sls.batons_received != 1 else ''}"
            )
        if sls.tasks_assigned > 0:
            changed.append(
                f"{sls.tasks_assigned} task{'s' if sls.tasks_assigned != 1 else ''} assigned"
            )
        if sls.workspace_events > 0:
            changed.append(
                f"{sls.workspace_events} workspace event{'s' if sls.workspace_events != 1 else ''}"
            )
        if sls.peers_joined:
            changed.append(f"joined {', '.join(sls.peers_joined)}")
        if sls.peers_departed:
            changed.append(f"departed {', '.join(sls.peers_departed)}")

    hot_now: list[str] = []
    flash = story.pending_by_priority.get("flash", 0) + story.pending_by_priority.get("system", 0)
    if flash > 0:
        hot_now.append(
            f"{flash} flash/system message{'s' if flash != 1 else ''} waiting"
        )
    reply_freshness = _build_active_reply_freshness_fields(story.active_reply_alerts)
    thread_freshness = _build_thread_watch_freshness_fields(story.active_thread_watches)
    if story.active_reply_alerts and not _is_stale_hot_thread(reply_freshness):
        first = story.active_reply_alerts[0]
        hot_now.append(f"hot reply from {first.counterpart}")
    elif story.active_thread_watches and not _is_stale_hot_thread(thread_freshness):
        first = story.active_thread_watches[0]
        hot_now.append(f"active thread with {first.counterpart}")

    blocking: list[str] = []
    if story.incoming_batons > 0:
        blocking.append(
            f"{story.incoming_batons} incoming baton{'s' if story.incoming_batons != 1 else ''}"
        )
    if story.blocking_review_requests > 0:
        blocking.append(
            f"{story.blocking_review_requests} blocking review{'s' if story.blocking_review_requests != 1 else ''}"
        )
    if story.blocked_waiting_for_review > 0:
        blocking.append(
            f"{story.blocked_waiting_for_review} review block{'s' if story.blocked_waiting_for_review != 1 else ''}"
        )
    if story.pending_assignments > 0:
        blocking.append(
            f"{story.pending_assignments} assignment{'s' if story.pending_assignments != 1 else ''} waiting"
        )

    attention_treatment = story.attention_treatment or build_attention_treatment_summary(
        pending_by_class=story.pending_by_class,
        pending_by_priority=story.pending_by_priority,
        interruptibility=story.interruptibility,
        readiness=story.readiness,
        has_blocking_work=bool(blocking),
    )
    counts = attention_treatment.get("counts") or {}
    can_wait: list[str] = []
    defer_visible = int(counts.get("defer_visible") or 0)
    hold_quietly = int(counts.get("hold_quietly") or 0)
    archive_only = int(counts.get("archive_only") or 0)
    if defer_visible > 0:
        can_wait.append(f"defer visible {defer_visible}")
    if hold_quietly > 0:
        can_wait.append(f"hold quietly {hold_quietly}")
    if archive_only > 0:
        can_wait.append(f"archive only {archive_only}")

    has_any = bool(changed or hot_now or blocking or can_wait or (sls and sls.resume_hint))
    if not has_any:
        return {}

    packet = {
        "style": "bounded" if story.wake_model in {"manual_wake", "mixed", "operator_console"} else "light",
        "wake_posture": wake_posture,
        "changed": changed,
        "hot_now": hot_now,
        "blocking": blocking,
        "can_wait": can_wait,
        "resume_hint": sls.resume_hint if sls and sls.resume_hint else None,
        "next_useful_move": story.recommended_action or infer_recommended_action(story),
    }

    # Inline message previews for re-entry — show what arrived, not just counts
    if story.unread_previews and sls and sls.messages_arrived > 0:
        packet["message_previews"] = story.unread_previews[:5]
        packet["interruptibility"] = story.interruptibility or "free"

    # Stale residue count: how many unread messages are old enough to be residue
    if story.unread_previews:
        from datetime import datetime as _dt, timezone as _tz
        _now = _dt.now(_tz.utc)
        stale_count = 0
        for preview in story.unread_previews:
            created_at = str(preview.get("created_at") or "").strip()
            if not created_at:
                continue
            try:
                from .time_utils import parse_timestamp
                created = parse_timestamp(created_at)
                if created:
                    age_min = int((_now - created).total_seconds() / 60)
                    priority = str(preview.get("priority") or "routine").lower()
                    threshold = 30 if priority in ("flash", "priority") else 120
                    if age_min >= threshold:
                        stale_count += 1
            except Exception:
                pass
        if stale_count > 0:
            packet["stale_residue"] = stale_count

    # 2ACK P1.6: Truth summary for the re-entry packet.
    # Gives the agent a quick honest assessment of state quality.
    truth_issues: list[str] = []
    for watch in (story.active_thread_watches or []):
        rt = watch.reception_truth
        if isinstance(rt, dict) and rt.get("label", {}).get("negative_states"):
            neg = [ns.get("state", "?") for ns in rt["label"]["negative_states"] if isinstance(ns, dict)]
            truth_issues.append(f"thread {watch.counterpart}: {', '.join(neg)}")
    # Check if own readiness has negative states (contradicted, stale)
    if story.readiness and story.derived_active_mode:
        if story.readiness == "ready" and story.derived_active_mode == "offline":
            truth_issues.append("self: claims ready but derived offline")
    if truth_issues:
        packet["truth_issues"] = truth_issues[:5]

    return packet


def _render_reentry_lines(packet: dict[str, Any]) -> list[str]:
    if not packet:
        return []

    summary_parts: list[str] = []
    if packet.get("hot_now"):
        summary_parts.append(f"hot now: {'; '.join(packet['hot_now'][:2])}")
    if packet.get("blocking"):
        summary_parts.append(f"blocking: {'; '.join(packet['blocking'][:2])}")
    if packet.get("can_wait"):
        summary_parts.append(f"can wait: {'; '.join(packet['can_wait'][:2])}")
    if packet.get("changed"):
        summary_parts.append(f"changed: {'; '.join(packet['changed'][:2])}")

    lines: list[str] = []
    if summary_parts:
        lines.append(f"Re-entry: {' | '.join(summary_parts)}")

    # Inline message previews — show what arrived during absence
    # Respects agent's actual interruptibility state for coherence
    previews = packet.get("message_previews") or []
    if previews:
        reentry_interruptibility = str(packet.get("interruptibility") or "free").lower()
        preview_lines = _render_surfaced_message_lines(
            previews,
            {"counts": {"surface_now": len(previews)}, "interruptibility": reentry_interruptibility, "has_any": True},
            max_lines=3,
        )
        lines.extend(preview_lines)

    stale_residue = int(packet.get("stale_residue") or 0)
    if stale_residue > 0:
        lines.append(f"  \u23f3 {stale_residue} message{'s' if stale_residue != 1 else ''} aged into stale residue — review or dismiss, not fresh urgency")
    resume_hint = str(packet.get('resume_hint') or '').strip()
    if resume_hint:
        lines.append(f"Re-entry hint: {resume_hint}")
    return lines


def _normalize_subject_stem(subject: str) -> str:
    """Strip variable suffixes (timestamps, ages, counts) to find the subject stem.

    Examples:
      "Reminder: handoff from codex waiting (30m)" → "reminder: handoff from codex waiting"
      "Reminder: handoff from codex waiting (1h34m)" → "reminder: handoff from codex waiting"
    """
    import re
    s = str(subject or "").strip().lower()
    # Strip trailing parenthesized content (ages, counts, timestamps)
    s = re.sub(r'\s*\([^)]*\)\s*$', '', s)
    return s.strip()


_PRIORITY_RANK = {"flash": 0, "system": 1, "priority": 2, "routine": 3}


def collapse_related_signals(previews: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Group related signals and promote the highest severity.

    Signals are considered related when they share (sender, subject_stem).
    A collapsed signal keeps the newest created_at and the highest priority.
    """
    if len(previews) <= 1:
        return list(previews)

    groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
    order: list[tuple[str, str]] = []
    for preview in previews:
        sender = str(preview.get("from_agent") or "").strip().lower()
        stem = _normalize_subject_stem(preview.get("subject") or "")
        key = (sender, stem)
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(preview)

    result: list[dict[str, Any]] = []
    for key in order:
        group = groups[key]
        if len(group) == 1:
            result.append(group[0])
            continue

        # Collapse: pick the highest priority, newest timestamp, combine into one
        best_priority = min(group, key=lambda p: _PRIORITY_RANK.get(
            str(p.get("priority") or "routine").lower(), 3
        ))
        newest = max(group, key=lambda p: str(p.get("created_at") or ""))

        collapsed = dict(newest)
        collapsed["priority"] = best_priority.get("priority", "routine")
        collapsed["_collapsed_count"] = len(group)
        # Use the stem as subject (cleaner without variable suffix)
        stem_subject = str(newest.get("subject") or "(no subject)").strip()
        import re
        stem_subject = re.sub(r'\s*\([^)]*\)\s*$', '', stem_subject).strip()
        collapsed["subject"] = stem_subject
        result.append(collapsed)

    return result


def _render_courtesy_lines(summary: Optional[dict[str, Any]]) -> list[str]:
    """Render machine courtesy activity for the briefing detail block."""
    if not summary or summary.get("total_actions", 0) == 0:
        return []
    lines: list[str] = []
    by_outcome = summary.get("by_outcome", {})
    coalesced = summary.get("coalesced_messages", 0)
    parts: list[str] = []
    for outcome, count in sorted(by_outcome.items(), key=lambda kv: -kv[1]):
        parts.append(f"{outcome}: {count}")
    if coalesced > 0 and "habituation_coalesced" not in by_outcome and "saturation_coalesced" not in by_outcome:
        parts.append(f"coalesced (dead-letter): {coalesced}")
    lines.append(f"Courtesy activity (last hour): {', '.join(parts)}")
    recent = summary.get("recent", [])
    if recent:
        last = recent[-1]
        lines.append(f"  Last: {last.get('outcome', '?')} — {last.get('sender', '?')} -> {last.get('recipient', '?')}: {last.get('subject', '')}")
    return lines


def _render_surfaced_message_lines(
    previews: list[dict[str, Any]],
    attention_treatment: dict[str, Any],
    *,
    max_lines: int = 5,
) -> list[str]:
    """Render inline message previews for surface-now signals.

    Filters previews through attention treatment and interruptibility so the
    briefing shows message *content* — not just counts — for signals that
    should surface without ceremony. Related signals are collapsed before
    rendering via alarm collapse.
    """
    if not previews:
        return []

    counts = (attention_treatment or {}).get("counts") or {}
    surface_now = int(counts.get("surface_now") or 0)
    if surface_now <= 0:
        return []

    interruptibility = str((attention_treatment or {}).get("interruptibility") or "free").lower()

    # Priority threshold based on interruptibility
    if interruptibility == "do_not_interrupt":
        min_priorities = {"flash", "system"}
    elif interruptibility in ("defer", "urgent_only"):
        min_priorities = {"flash", "system", "priority"}
    else:
        min_priorities = None  # show all

    filtered: list[dict[str, Any]] = []
    for preview in previews:
        priority = str(preview.get("priority") or "routine").lower()
        if min_priorities and priority not in min_priorities:
            continue
        filtered.append(preview)

    if not filtered:
        return []

    # Alarm collapse: group related signals before rendering
    filtered = collapse_related_signals(filtered)

    lines: list[str] = []
    now = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
    for preview in filtered[:max_lines]:
        sender = str(preview.get("from_agent") or "unknown").strip()
        subject = str(preview.get("subject") or "(no subject)").strip()
        priority = str(preview.get("priority") or "routine").lower()
        msg_type = str(preview.get("msg_type") or "inform").lower()
        created_at = str(preview.get("created_at") or "").strip()

        age_label = ""
        is_stale = False
        if created_at:
            try:
                from .time_utils import parse_timestamp
                created = parse_timestamp(created_at)
                if created:
                    delta = now - created
                    total_minutes = int(delta.total_seconds() / 60)
                    if total_minutes < 1:
                        age_label = "just now"
                    elif total_minutes < 60:
                        age_label = f"{total_minutes}m ago"
                    elif total_minutes < 1440:
                        hours = total_minutes // 60
                        age_label = f"{hours}h ago"
                    else:
                        days = total_minutes // 1440
                        age_label = f"{days}d ago"
                    # Stale escalation: mark old unread messages as residue.
                    # Priority/flash: stale after 30 min. Routine: stale after 2 hours.
                    if priority in ("flash", "priority"):
                        is_stale = total_minutes >= 30
                    else:
                        is_stale = total_minutes >= 120
            except Exception:
                pass

        collapsed_count = int(preview.get("_collapsed_count") or 0)

        tag_parts: list[str] = []
        if is_stale:
            tag_parts.append("stale")
        if collapsed_count > 1:
            tag_parts.append(f"{collapsed_count}x")
        if priority not in ("routine",):
            tag_parts.append(priority)
        if msg_type not in ("inform",):
            tag_parts.append(msg_type)
        if age_label:
            tag_parts.append(age_label)
        # Participant role enrichment — show origin/subject when present
        metadata = preview.get("metadata")
        if isinstance(metadata, str):
            try:
                metadata = __import__("json").loads(metadata)
            except Exception:
                metadata = {}
        elif not isinstance(metadata, dict):
            metadata = {}
        participants = metadata.get("whispers:participants") or {}
        consequence = metadata.get("whispers:consequence_scope") or metadata.get("_consequence_scope")
        origin = participants.get("origin")
        subject_of = participants.get("subject_of")
        if origin and origin != sender:
            tag_parts.append(f"via {origin}")
        if subject_of:
            tag_parts.append(f"re: {subject_of}")
        if consequence and consequence != "digital":
            tag_parts.append(consequence.replace("_", " "))

        tag = f" ({', '.join(tag_parts)})" if tag_parts else ""

        icon = "\u23f3" if is_stale else ICON_INFORM  # hourglass for stale residue
        lines.append(f"{SIGNAL_PREFIX} {icon} {sender}: {subject}{tag}")

    overflow = len(filtered) - max_lines
    if overflow > 0:
        lines.append(f"{SIGNAL_PREFIX} {ICON_INFORM} +{overflow} more signal{'s' if overflow != 1 else ''} to surface")

    return lines


def build_briefing_capsule(story: ConnectionStory) -> dict[str, Any]:
    """
    Generate a compact briefing from a ConnectionStory.

    Returns a dict with:
      - status_line: one-line summary
      - must_present_block: the mandatory display block
      - detail_block: full briefing text
      - All fields needed by MCP dynamic instructions
    """
    peer_names = [p.callsign for p in story.peers]
    status_line = render_status_line(
        story.agent_name,
        story.signal_mode,
        peer_names,
        story.pending_messages,
        peers_online_count=story.peers_online_count,
    )
    jolt_decision = story.jolt_decision or infer_jolt_decision(story)
    jolt_packet = story.jolt_packet or build_jolt_packet(story)
    wake_posture = build_wake_posture_summary(
        wake_model=story.wake_model,
        interruptibility=story.interruptibility,
    )
    reentry_packet = _build_reentry_packet(story)

    details = [
        status_line,
        f"Local time: {story.local_time or '-'}",
        f"Deployment: {_deployment_label(story.deployment_mode)}",
        f"Peers online: {_render_peers_online_line(story.peers) if story.peers else 'none'}",
    ]
    if wake_posture:
        details.append(f"Wake posture: {format_wake_posture_summary(wake_posture)}")
    # Surface health warnings for degraded/stale peers (with predictive escalation)
    _HEALTH_WARN = "\u26a0\ufe0f"  # ⚠️
    for peer in story.peers:
        mode = peer.derived_active_mode
        actionable_suffix = ""
        if peer.actionable_count > 0:
            actionable_suffix = f" ({peer.actionable_count} actionable item{'s' if peer.actionable_count != 1 else ''} waiting)"
        if mode == "stale":
            details.append(f"  {_HEALTH_WARN} {peer.callsign} is stale — last heartbeat may be outdated{actionable_suffix}")
        elif mode == "degraded":
            details.append(f"  {_HEALTH_WARN} {peer.callsign} is degraded — high load or unresponsive{actionable_suffix}")
        elif mode == "overloaded":
            details.append(f"  {_HEALTH_WARN} {peer.callsign} is overloaded — context load at capacity{actionable_suffix}")
        elif peer.actionable_count > 0 and mode in ("ready", "offline"):
            # Peer looks fine but has actionable items piling up — surface it
            details.append(f"  {_HEALTH_WARN} {peer.callsign} has {peer.actionable_count} actionable item{'s' if peer.actionable_count != 1 else ''} waiting")
    context_budget_line = _render_context_budget_line(story.context_budget)
    if context_budget_line:
        details.append(context_budget_line)

    details.extend(_render_huddle_lines(story.huddle_peers))
    details.extend(_render_captain_action_lines(story.captain_action_alerts))
    details.extend(_render_active_reply_lines(story.active_reply_alerts))
    details.extend(_render_active_thread_watch_lines(story.active_thread_watches))
    details.extend(_render_assignment_alert_lines(story.peers))

    if story.pending_by_priority:
        details.append(f"Unread by priority: {_format_pending(story.pending_by_priority)}")
    if story.pending_by_class:
        details.append(f"Unread by class: {format_pending_by_class_counts(story.pending_by_class)}")
    attention_treatment = story.attention_treatment or build_attention_treatment_summary(
        pending_by_class=story.pending_by_class,
        pending_by_priority=story.pending_by_priority,
        interruptibility=story.interruptibility,
        readiness=story.readiness,
        has_blocking_work=bool(
            story.incoming_batons
            or story.pending_assignments
            or story.pending_review_requests
            or story.blocking_review_requests
            or story.blocked_waiting_for_review
        ),
    )
    if attention_treatment.get("has_any"):
        details.append(f"Attention treatment: {format_attention_treatment_summary(attention_treatment)}")

    # Machine courtesy: surface what the runtime deferred, held, or coalesced
    details.extend(_render_courtesy_lines(story.courtesy_summary))

    # Inline message previews — surface content without ceremony
    details.extend(_render_surfaced_message_lines(story.unread_previews, attention_treatment))

    details.extend(
        render_coordination_lines(
            {
                "pending_assignments": story.pending_assignments,
                "pending_review_requests": story.pending_review_requests,
                "blocking_review_requests": story.blocking_review_requests,
                "blocked_waiting_for_review": story.blocked_waiting_for_review,
                "answered_waiting_to_close": story.answered_waiting_to_close,
                "highlights": [item.to_dict() for item in story.coordination_highlights],
            }
        )
    )

    baton_tokens = render_baton_state_tokens(
        incoming_batons=story.incoming_batons,
        carrying_batons=story.carrying_batons,
        claimed_reviews=story.claimed_reviews,
    )
    if baton_tokens:
        details.append(f"BATON state: {' | '.join(baton_tokens)}")

    details.extend(_render_baton_detail_lines(story.baton_details))

    obligations = _render_blocking_obligations(story)
    if obligations:
        details.extend(obligations)

    if story.http_server_reachable is False:
        details.append(f"{SIGNAL_PREFIX} {ICON_FLASH} HTTP server unreachable — agents using HTTP transport cannot connect.")
    elif story.http_server_reachable is True:
        details.append("HTTP server: reachable")

    details.extend(
        render_local_client_auth_lines(
            healthy=story.local_client_auth_healthy,
            source=story.local_client_token_source,
            issue=story.local_client_auth_issue,
        )
    )

    # Suppress stale resume noise when the agent is already back in a live
    # collaboration context with no unread inbox work to triage first.
    show_since_last_seen = story.pending_messages > 0 or story.peers_online_count == 0

    # Since-last-seen section
    sls = story.since_last_seen
    if show_since_last_seen and sls and not sls.is_first_session and not reentry_packet:
        since_parts: list[str] = []
        if sls.messages_arrived > 0:
            # Per-sender breakdown: "codex: 2 (1 priority), whispers-server: 3"
            if sls.messages_by_sender:
                sender_parts: list[str] = []
                for sender, info in sorted(
                    sls.messages_by_sender.items(),
                    key=lambda kv: kv[1].get("count", 0),
                    reverse=True,
                ):
                    count = info.get("count", 0)
                    priorities = info.get("priorities", {})
                    notable = [
                        f"{c} {p}" for p, c in priorities.items()
                        if p in ("flash", "system", "priority") and c > 0
                    ]
                    if notable:
                        sender_parts.append(f"{sender}: {count} ({', '.join(notable)})")
                    else:
                        sender_parts.append(f"{sender}: {count}")
                since_parts.append(f"{sls.messages_arrived} new — {', '.join(sender_parts)}")
            else:
                since_parts.append(f"{sls.messages_arrived} new message{'s' if sls.messages_arrived != 1 else ''}")
        if sls.peers_joined:
            since_parts.append(f"joined: {', '.join(sls.peers_joined)}")
        if sls.peers_departed:
            since_parts.append(f"departed: {', '.join(sls.peers_departed)}")
        if since_parts:
            details.append(f"Since last session: {'; '.join(since_parts)}")
    details.extend(_render_reentry_lines(reentry_packet))

    jolt_line = _render_jolt_line(story, jolt_decision)
    if jolt_line:
        details.append(jolt_line)

    details.append(STARTUP_MESSAGE_HANDLING_RULE)

    # Narrator state
    if story.narrator_status == "active":
        details.append(f"Narrator: {story.narrator_agent} (active)")
    elif story.narrator_status == "designated":
        details.append(f"Narrator: {story.narrator_agent} (offline — narratives paused)")
    elif story.narrator_status == "degraded":
        details.append(f"Narrator: {story.narrator_agent} (degraded — lost connection)")

    # Recommended action
    if story.recommended_action:
        details.append(f"Suggested next action: {story.recommended_action}")

    peer_assignment_alerts = _peers_needing_assignment(story.peers)
    peer_nudge_alerts = _peers_needing_operator_nudge(story.peers)

    capsule = {
        "agent_name": story.agent_name,
        "deployment_mode": story.deployment_mode,
        "signal_mode": story.signal_mode,
        "peers_online_count": story.peers_online_count,
        "peer_names": peer_names,
        "huddle_peers": [peer.to_dict() for peer in story.huddle_peers],
        "agents_registered": story.agents_registered,
        "pending_messages": story.pending_messages,
        "pending_by_priority": story.pending_by_priority,
        "pending_by_class": story.pending_by_class,
        "attention_treatment": attention_treatment,
        "wake_posture": wake_posture,
        "has_blocking_obligations": bool(
            story.incoming_batons > 0
            or story.carrying_batons > 0
            or story.pending_assignments > 0
            or story.claimed_reviews > 0
        ),
        "incoming_batons": story.incoming_batons,
        "carrying_batons": story.carrying_batons,
        "claimed_reviews": story.claimed_reviews,
        "baton_details": [b.to_dict() for b in story.baton_details],
        "pending_assignments": story.pending_assignments,
        "pending_review_requests": story.pending_review_requests,
        "blocking_review_requests": story.blocking_review_requests,
        "blocked_waiting_for_review": story.blocked_waiting_for_review,
        "captain_action_requests": len(story.captain_action_alerts),
        "captain_action_alerts": story.captain_action_alerts,
        "active_reply_requests": len(story.active_reply_alerts),
        "active_reply_alerts": [item.to_dict() for item in story.active_reply_alerts],
        "active_thread_watch_count": len(story.active_thread_watches),
        "active_thread_watches": [item.to_dict() for item in story.active_thread_watches],
        "peer_assignment_requests": len(peer_assignment_alerts),
        "peer_assignment_alerts": [peer.to_dict() for peer in peer_assignment_alerts],
        "peer_nudge_requests": len(peer_nudge_alerts),
        "peer_nudge_alerts": [peer.to_dict() for peer in peer_nudge_alerts],
        "coordination_highlights": [item.to_dict() for item in story.coordination_highlights],
        "surfaced_previews": story.unread_previews,
        "local_time": story.local_time or "-",
        "status_line": status_line,
        "must_present_block": status_line,
        "narrator_agent": story.narrator_agent,
        "narrator_status": story.narrator_status,
        "detail_block": "\n".join(details),
        "resource_uri": "whispers://status",
        "prompt_name": "startup_briefing",
        "version": story.whispers_version,
        "schema_version": story.schema_version,
        "local_client_auth_healthy": story.local_client_auth_healthy,
        "local_client_token_source": story.local_client_token_source,
        "local_client_auth_issue": story.local_client_auth_issue,
    }
    if reentry_packet:
        capsule["reentry_packet"] = reentry_packet
    if story.wake_model:
        capsule["wake_model"] = story.wake_model
    if story.interruptibility:
        capsule["interruptibility"] = story.interruptibility
    if story.jolt_adapter is not None:
        capsule["jolt_adapter"] = story.jolt_adapter.to_dict()
    if story.jolt_host_capabilities is not None:
        capsule["jolt_host_capabilities"] = story.jolt_host_capabilities.to_dict()
    if story.jolt_budget is not None:
        capsule["jolt_budget"] = story.jolt_budget.to_dict()
    if jolt_decision is not None:
        capsule["jolt"] = jolt_decision.to_dict()
    if jolt_packet is not None:
        capsule["jolt_packet"] = jolt_packet.to_dict()
    return capsule


# ---------------------------------------------------------------------------
# Recommended action inference
# ---------------------------------------------------------------------------

def infer_recommended_action(story: ConnectionStory) -> str:
    """
    Determine the most useful next action for this agent.

    Priority order:
    1. Flash/system messages need immediate attention
    2. Blocking review / hot collaborator replies
    3. Other typed coordination obligations
    4. Generic unread messages
    5. Nearby peers / ready-for-work state
    """
    flash = story.pending_by_priority.get("flash", 0) + story.pending_by_priority.get("system", 0)
    if flash > 0:
        return f"Check inbox immediately -- {flash} flash/system message{'s' if flash != 1 else ''} waiting."

    blocking_review = next(
        (
            item
            for item in story.coordination_highlights
            if item.direction == "incoming"
            and item.kind == "review_request"
            and item.blocking
        ),
        None,
        )
    if blocking_review:
        detail = blocking_review.requested_action or blocking_review.subject
        age_note = ""
        if blocking_review.age_seconds is not None and blocking_review.age_seconds >= 60:
            from whispers.coordination_runtime import _format_age
            age_note = f" ({_format_age(blocking_review.age_seconds)} waiting)"
        return f"Review blocking request from {blocking_review.counterpart}{age_note} -- {detail}."

    reply_freshness = _build_active_reply_freshness_fields(story.active_reply_alerts)
    if story.active_reply_alerts and not _is_stale_hot_thread(reply_freshness):
        first = story.active_reply_alerts[0]
        if len(story.active_reply_alerts) == 1:
            return f"Open hot reply from {first.counterpart} -- {first.subject}."

        names = ", ".join(alert.counterpart for alert in story.active_reply_alerts[:2])
        overflow = len(story.active_reply_alerts) - 2
        if overflow > 0:
            names = f"{names} +{overflow}"
        return f"Open hot collaborator replies -- {names} responded in active threads."

    thread_freshness = _build_thread_watch_freshness_fields(story.active_thread_watches)
    if story.active_thread_watches and not _is_stale_hot_thread(thread_freshness):
        # Build peer wake-model lookup for honest delivery phrasing
        _peer_wake = {p.callsign: str(p.wake_model or "").strip().lower() for p in story.peers}

        def _delivered_phrase(counterpart: str) -> str:
            """Phrase delivery honestly based on counterpart's wake model."""
            if _peer_wake.get(counterpart) == "manual_wake":
                return "delivered but manual-wake -- pickup needs nudge"
            return "delivered and unread"

        grouped_watches = _group_active_thread_watches(story.active_thread_watches)
        first = story.active_thread_watches[0]
        if len(story.active_thread_watches) == 1:
            if first.stage == "awaiting_reply":
                age_tag = f" ({first.age_label} since read)" if first.age_label else ""
                return f"Stay hot on thread with {first.counterpart} -- awaiting reply on {first.subject}{age_tag}."
            if first.stage == "awaiting_delivery":
                age_tag = f" (sent {first.age_label} ago)" if first.age_label else ""
                return f"Stay hot on thread with {first.counterpart} -- {first.subject} is still queued for delivery{age_tag}."
            age_prefix = first.stage_label or "delivered"
            age_tag = f" ({age_prefix} {first.age_label} ago)" if first.age_label else ""
            return f"Stay hot on thread with {first.counterpart} -- {first.subject} is {_delivered_phrase(first.counterpart)}{age_tag}."

        if len(grouped_watches) == 1:
            counterpart, watches = grouped_watches[0]
            subject_summary = _summarize_active_thread_subjects(watches)
            newest = watches[0]
            if all(watch.stage == "awaiting_reply" for watch in watches):
                age_tag = f" ({newest.age_label} since latest read)" if newest.age_label else ""
                return f"Stay hot on thread with {counterpart} -- awaiting reply on {subject_summary}{age_tag}."
            if all(watch.stage == "awaiting_delivery" for watch in watches):
                age_tag = f" (latest sent {newest.age_label} ago)" if newest.age_label else ""
                return f"Stay hot on thread with {counterpart} -- {subject_summary} is still queued for delivery{age_tag}."
            if all(watch.stage not in {'awaiting_reply', 'awaiting_delivery'} for watch in watches):
                age_prefix = newest.stage_label or "delivered"
                age_tag = f" (latest {age_prefix} {newest.age_label} ago)" if newest.age_label else ""
                return f"Stay hot on thread with {counterpart} -- {subject_summary} is {_delivered_phrase(counterpart)}{age_tag}."
            return f"Stay hot on thread with {counterpart} -- {subject_summary} still need delivery, read, or reply."

        names = ", ".join(counterpart for counterpart, _ in grouped_watches[:2])
        overflow = len(grouped_watches) - 2
        if overflow > 0:
            names = f"{names} +{overflow}"
        return f"Stay hot on active threads -- {names} still owe delivery, read, or reply."

    if story.claimed_reviews > 0:
        return f"Finish or update {story.claimed_reviews} claimed review{'s' if story.claimed_reviews != 1 else ''}."

    if story.incoming_batons > 0:
        token = render_waiting_baton_token(story.incoming_batons)
        incoming = [b for b in story.baton_details if b.direction == "incoming"]
        if incoming:
            first = incoming[0]
            label = first.label[:50] if first.label else "baton"
            return (
                f"Review BATON state {token} -- "
                f"incoming from {first.counterpart}: {label}."
            )
        return (
            f"Review BATON state {token} -- "
            f"{story.incoming_batons} incoming baton{'s' if story.incoming_batons != 1 else ''} waiting."
        )

    assignment = next(
        (
            item
            for item in story.coordination_highlights
            if item.direction == "incoming" and item.kind == "assignment"
        ),
        None,
    )
    if assignment:
        detail = assignment.requested_action or assignment.subject
        return f"Start assignment from {assignment.counterpart} -- {detail}."

    if story.captain_action_alerts:
        first = story.captain_action_alerts[0]
        sender = str(first.get("sender") or "peer").strip() or "peer"
        label = str(first.get("label") or first.get("kind") or "packet").strip()
        detail = str(first.get("detail") or first.get("subject") or "").strip() or None
        if len(story.captain_action_alerts) == 1:
            if detail:
                return f"Review {sender} {label} -- {detail}."
            return f"Review {sender} {label}."

        names = ", ".join(
            str(alert.get("sender") or "peer").strip() or "peer"
            for alert in story.captain_action_alerts[:2]
        )
        overflow = len(story.captain_action_alerts) - 2
        if overflow > 0:
            names = f"{names} +{overflow}"
        return f"Review peer packets -- {names} are waiting on captain response."

    peer_assignment_alerts = _peers_needing_assignment(story.peers)
    peer_nudge_alerts = _peers_needing_operator_nudge(story.peers)
    if peer_nudge_alerts:
        first = peer_nudge_alerts[0]
        detail = first.attention_detail or first.progress_summary or first.current_task
        if len(peer_nudge_alerts) == 1:
            if detail:
                return (
                    f"Route next work and nudge {first.callsign} -- "
                    f"manual-wake peer is ready for more and reports: {detail}."
                )
            return f"Route next work and nudge {first.callsign} -- manual-wake peer is ready for more."

        names = ", ".join(peer.callsign for peer in peer_nudge_alerts[:2])
        overflow = len(peer_nudge_alerts) - 2
        if overflow > 0:
            names = f"{names} +{overflow}"
        return f"Route next work and nudge prompt-bound peers -- {names} need fresh assignments."

    if peer_assignment_alerts:
        first = peer_assignment_alerts[0]
        detail = first.attention_detail or first.progress_summary or first.current_task
        if len(peer_assignment_alerts) == 1:
            if detail:
                return f"Route next work -- {first.callsign} is ready for more and reports: {detail}."
            return f"Route next work -- {first.callsign} is ready for more."

        names = ", ".join(peer.callsign for peer in peer_assignment_alerts[:2])
        overflow = len(peer_assignment_alerts) - 2
        if overflow > 0:
            names = f"{names} +{overflow}"
        return f"Route next work -- {names} need fresh assignments."

    review_request = next(
        (
            item
            for item in story.coordination_highlights
            if item.direction == "incoming"
            and item.kind == "review_request"
            and not item.blocking
        ),
        None,
    )
    if review_request:
        detail = review_request.requested_action or review_request.subject
        return f"Pick up review request from {review_request.counterpart} -- {detail}."

    if story.blocked_waiting_for_review > 0:
        return (
            f"Hold or reroute -- {story.blocked_waiting_for_review} blocking review request"
            f"{'s are' if story.blocked_waiting_for_review != 1 else ' is'} still open."
        )

    answered_request = next(
        (
            item
            for item in story.coordination_highlights
            if item.direction == "outgoing" and item.coordination_status == "answered"
        ),
        None,
    )
    if answered_request:
        label = "assignment" if answered_request.kind == "assignment" else "review request"
        return f"Close the loop -- {answered_request.counterpart} answered your {label}."

    attention_counts = {}
    if isinstance(story.attention_treatment, dict):
        raw_counts = story.attention_treatment.get("counts")
        if isinstance(raw_counts, dict):
            attention_counts = raw_counts

    if story.pending_messages > 0 and int(attention_counts.get("surface_now", 0) or 0) > 0:
        # Manual-wake re-entry: guide triage, don't just say "check inbox"
        wake = str(story.wake_model or "").strip().lower()
        sls = story.since_last_seen
        is_returning = sls and not sls.is_first_session and sls.messages_arrived > 0
        if wake == "manual_wake" and is_returning and story.pending_messages > 1:
            stale_count = 0
            if story.unread_previews:
                _now = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
                for _p in story.unread_previews:
                    _ca = str(_p.get("created_at") or "").strip()
                    if _ca:
                        try:
                            from .time_utils import parse_timestamp
                            _cr = parse_timestamp(_ca)
                            if _cr:
                                _age = int((_now - _cr).total_seconds() / 60)
                                _pri = str(_p.get("priority") or "routine").lower()
                                if _age >= (30 if _pri in ("flash", "priority") else 120):
                                    stale_count += 1
                        except Exception:
                            pass
            fresh = story.pending_messages - stale_count
            if stale_count > 0 and fresh > 0:
                return (
                    f"Triage inbox -- {fresh} fresh message{'s' if fresh != 1 else ''} "
                    f"need attention, {stale_count} stale. Start with fresh, dismiss or batch-review residue."
                )
            if stale_count > 0 and fresh == 0:
                return (
                    f"Inbox is all stale residue ({stale_count} message{'s' if stale_count != 1 else ''}) "
                    f"-- batch-review or dismiss, no fresh urgency."
                )
        return f"Check inbox -- {story.pending_messages} unread message{'s' if story.pending_messages != 1 else ''}."

    if story.carrying_batons > 0:
        token = render_active_baton_token(story.carrying_batons)
        outgoing = [b for b in story.baton_details if b.direction == "outgoing"]
        if outgoing:
            first = outgoing[0]
            state_label = _BATON_STATE_LABELS.get(first.state, first.state)
            label = first.label[:50] if first.label else "baton"
            return (
                f"Advance BATON state {token} -- "
                f"to {first.counterpart}: {label} [{state_label}]."
            )
        return (
            f"Advance BATON state {token} -- "
            f"{story.carrying_batons} carried baton{'s' if story.carrying_batons != 1 else ''} still open."
        )

    if story.pending_messages > 0:
        # Manual-wake returning from absence: frame low-priority messages as scannable backlog
        wake = str(story.wake_model or "").strip().lower()
        sls = story.since_last_seen
        is_returning = sls and not sls.is_first_session and sls.messages_arrived > 0
        if wake == "manual_wake" and is_returning:
            return (
                f"Low-priority inbox -- {story.pending_messages} unread message"
                f"{'s' if story.pending_messages != 1 else ''} below surface threshold. "
                f"Scan when ready, nothing blocking."
            )
        return f"Check inbox -- {story.pending_messages} unread message{'s' if story.pending_messages != 1 else ''}."

    if story.huddle_peers:
        first = story.huddle_peers[0]
        if len(story.huddle_peers) == 1:
            if first.shared_workspaces:
                return (
                    f"Stay in close huddle -- {first.callsign} is beside you in "
                    f"{_format_workspace_labels(first.shared_workspaces, max_items=1)}."
                )
            if first.incoming_baton_from_them and first.outgoing_baton_to_them:
                return f"Stay in close huddle -- {first.callsign} has open baton traffic with you in both directions."
            if first.incoming_baton_from_them:
                return f"Stay in close huddle -- {first.callsign} is beside you and an incoming baton is still open."
            if first.outgoing_baton_to_them:
                return f"Stay in close huddle -- {first.callsign} is beside you and your baton to them is still open."
            return f"Stay in close huddle -- {first.callsign} is beside you on active shared work."

        names = ", ".join(peer.callsign for peer in story.huddle_peers[:2])
        overflow = len(story.huddle_peers) - 2
        if overflow > 0:
            names = f"{names} +{overflow}"
        return f"Stay in close huddle -- {names} are adjacent on active shared work."

    if story.peers_online_count > 0:
        peer_names = [p.callsign for p in story.peers[:2]]
        if peer_names:
            overflow = story.peers_online_count - len(peer_names)
            peers_label = ", ".join(peer_names)
            if overflow > 0:
                peers_label = f"{peers_label} +{overflow}"
            return f"Stay in active collaboration -- no unread messages, and {peers_label} {'is' if story.peers_online_count == 1 else 'are'} online."
        return "Stay in active collaboration. Peers are online."

    sls = story.since_last_seen
    if sls and sls.is_first_session:
        return (
            "Welcome to Whispers. Quick prove-it loop to verify your connection:\n"
            "  1. Run `presence_who` to see who else is online\n"
            "  2. Run `wag` with state='listening' to announce yourself\n"
            "  3. If a peer is online, send them a test message with `message_send`\n"
            "  4. Run `message_check` to see if anything arrived\n"
            "All four should work in under a minute. After that, you're connected."
        )

    if sls and not sls.is_first_session:
        if sls.messages_arrived > 0:
            return f"Review {sls.messages_arrived} message{'s' if sls.messages_arrived != 1 else ''} that arrived since last session."

    return "Ready. No pending work."
