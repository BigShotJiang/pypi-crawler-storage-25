"""
Whispers test harness — real behavior, no server required.

Use WhispersTestClient in CI, unit tests, and integration tests.
Each test client uses an isolated temporary SQLite database that is
automatically cleaned up when the client (or its WhispersTestHarness)
is closed.

Quick start::

    from whispers.testing import WhispersTestClient

    # Single agent
    with WhispersTestClient("my-agent") as client:
        status = client.status()
        assert status["healthy"] is True

    # Two agents exchanging messages
    from whispers.testing import WhispersTestHarness

    with WhispersTestHarness() as harness:
        alice = harness.make_client("alice")
        bob = harness.make_client("bob")

        alice.send("bob", "Hello!")
        inbox = bob.check_inbox()
        assert inbox[0]["subject"] == "Hello!"

The test database is a real SQLite database with the full Whispers
schema. All client operations work exactly as they do in production
— send, receive, presence, heartbeat, modes, trust tiers, etc.
The only difference is there is no HTTP server; everything is local.
"""

import gc
import os
import shutil
import sqlite3
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from .client import WhispersClient
from .path_utils import resolve_path


def _test_root_dir() -> str:
    override = os.environ.get("WHISPERS_TEST_TMP_ROOT", "").strip()
    if override:
        root = Path(resolve_path(override))
    else:
        root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    return str(root)


def _make_test_dir() -> str:
    root = _test_root_dir()
    path = os.path.join(root, f"whispers-test-{uuid.uuid4().hex}")
    os.makedirs(path, exist_ok=False)
    return path


def _safe_rmtree(db_path: str, dir_path: str) -> None:
    """Remove a test directory, handling SQLite WAL file locking on Windows.

    On Windows, SQLite WAL mode keeps journal files briefly locked after
    the last connection closes. This function checkpoints the WAL,
    forces garbage collection (releasing Python-held handles), and
    retries rmtree with brief sleeps.
    """
    # Checkpoint WAL to flush pending writes and release journal files
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        conn.close()
    except (sqlite3.Error, OSError):
        pass

    # Force GC to release any lingering Connection objects
    gc.collect()

    # Retry loop — Windows may need a moment after handle release
    for attempt in range(3):
        try:
            shutil.rmtree(dir_path)
            return
        except OSError:
            if attempt < 2:
                time.sleep(0.1 * (attempt + 1))
    # Final attempt without suppressing the error
    shutil.rmtree(dir_path, ignore_errors=True)


class WhispersTestClient(WhispersClient):
    """A WhispersClient backed by a temporary, isolated SQLite database.

    Use as a context manager for automatic cleanup::

        with WhispersTestClient("my-agent") as client:
            result = client.send("other", "Hello")
            assert result["status"] in ("delivered", "queued")

    Or instantiate directly and call close() when done::

        client = WhispersTestClient("my-agent")
        try:
            client.send("other", "Hello")
        finally:
            client.close()

    Multiple clients can share the same database by passing a
    ``shared_db_path``::

        db = WhispersTestClient.create_temp_db()
        a = WhispersTestClient("alice", shared_db_path=db)
        b = WhispersTestClient("bob", shared_db_path=db)
        # ... test message exchange ...
        a.close()
        b.close()
        WhispersTestClient.cleanup_temp_db(db)
    """

    def __init__(
        self,
        agent_name: str,
        *,
        shared_db_path: Optional[str] = None,
        agent_type: str = "script",
        model_id: Optional[str] = None,
        display_name: Optional[str] = None,
    ):
        self._owns_db = shared_db_path is None
        if shared_db_path:
            self._test_db_path = shared_db_path
            self._test_dir: Optional[str] = None
        else:
            self._test_dir = _make_test_dir()
            self._test_db_path = os.path.join(self._test_dir, "test.db")

        super().__init__(
            agent_name,
            db_path=self._test_db_path,
            agent_type=agent_type,
            model_id=model_id,
            display_name=display_name,
        )

    @staticmethod
    def create_temp_db() -> str:
        """Create a temporary database directory and return the db path.

        Use with ``shared_db_path`` to share a database between multiple
        test clients. Call ``cleanup_temp_db()`` when done.
        """
        test_dir = _make_test_dir()
        return os.path.join(test_dir, "test.db")

    @staticmethod
    def cleanup_temp_db(db_path: str) -> None:
        """Remove the temporary directory containing a shared test database."""
        test_dir = os.path.dirname(db_path)
        if os.path.isdir(test_dir) and "whispers-test-" in test_dir:
            _safe_rmtree(db_path, test_dir)

    def close(self) -> None:
        """Clean up the temporary database."""
        if self._owns_db and self._test_dir and os.path.isdir(self._test_dir):
            _safe_rmtree(self._test_db_path, self._test_dir)

    def send_handoff(
        self,
        to: str,
        subject: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Backwards compatibility wrapper for test suite."""
        from whispers.twoack_schemas import HandoffBaton
        # Separate kwargs meant for baton_create
        create_kwargs = {}
        for k in ["human_summary", "trace_id", "context_id", "reply_to", "priority"]:
            if k in kwargs:
                create_kwargs[k] = kwargs.pop(k)
        
        # Convert legacy fields to HandoffBaton
        if "context" in kwargs:
            kwargs["repo_focus"] = kwargs.pop("context") # Map old 'context' to 'repo_focus' or similar depending on the tests' intent. Actually just map 'context' to 'repo_focus'.
        if "lane_state" in kwargs:
            kwargs.pop("lane_state") # Discarded in new schema
        if "confidence" in kwargs:
            kwargs.pop("confidence") # Discarded in new schema
        if "conditions" in kwargs:
            kwargs.pop("conditions") # Discarded in new schema
        if "tags" in kwargs:
            kwargs.pop("tags") # Discarded in new schema
        
        # Tuple-ize list fields
        for array_field in ["decisions", "assumptions", "open_questions", "dead_ends", "artifacts", "risks"]:
            if array_field in kwargs and isinstance(kwargs[array_field], list):
                kwargs[array_field] = tuple(kwargs[array_field])
                
        # Fill missing required fields with dummies for test backwards compat
        if "objective" not in kwargs:
            kwargs["objective"] = "Test Objective"
        if "deliverable" not in kwargs:
            kwargs["deliverable"] = "Test Deliverable"

        baton = HandoffBaton(**kwargs)
        return self.baton_create(to=to, subject=subject, baton=baton, **create_kwargs)

    def send_handoff_baton(self, *args, **kwargs) -> Dict[str, Any]:
        """Backwards compatibility alias for the old send_handoff_baton."""
        return self.send_handoff(*args, **kwargs)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


class WhispersTestHarness:
    """A test harness that manages multiple agents on a shared database.

    The harness creates a single temporary SQLite database and lets you
    spin up multiple agents that can exchange messages, check presence,
    and use all Whispers features::

        with WhispersTestHarness() as harness:
            sender = harness.make_client("sender")
            receiver = harness.make_client("receiver")

            sender.send("receiver", "Integration test")
            inbox = receiver.check_inbox()
            assert len(inbox) == 1
            assert inbox[0]["subject"] == "Integration test"

            status = sender.status()
            assert status["agents_registered"] == 2

    All agents and the database are cleaned up when the harness exits.
    """

    def __init__(self):
        self._test_dir = _make_test_dir()
        self._db_path = os.path.join(self._test_dir, "test.db")
        self._clients: List[WhispersTestClient] = []

    @property
    def db_path(self) -> str:
        """The path to the shared test database."""
        return self._db_path

    def make_client(
        self,
        agent_name: str,
        *,
        agent_type: str = "script",
        model_id: Optional[str] = None,
        display_name: Optional[str] = None,
    ) -> WhispersTestClient:
        """Create a new test client on the shared database.

        The client is automatically tracked and cleaned up when the
        harness closes.
        """
        client = WhispersTestClient(
            agent_name,
            shared_db_path=self._db_path,
            agent_type=agent_type,
            model_id=model_id,
            display_name=display_name,
        )
        self._clients.append(client)
        return client

    def close(self) -> None:
        """Clean up all clients and the shared database."""
        self._clients.clear()
        if os.path.isdir(self._test_dir):
            _safe_rmtree(self._db_path, self._test_dir)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False
