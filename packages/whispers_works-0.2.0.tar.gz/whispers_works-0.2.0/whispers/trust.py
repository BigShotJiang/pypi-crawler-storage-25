import json
import secrets
from datetime import datetime, timezone
from typing import Dict, Any, Optional

from whispers.storage.db import WhispersDB

class TrustManager:
    """
    Manages the issuance, validation, and revocation of security artifacts.
    Specifically drives the Server Nonce authority proof system, providing
    Cryptographically secure tokens that bind execution scope to a specific
    principal and time window.
    """
    def __init__(self, db: WhispersDB):
        self.db = db

    def issue_nonce(self, principal: str, scope: Dict[str, Any], expires_at: Optional[datetime] = None) -> str:
        """Issue a new server nonce bound to a principal and specific scope payload."""
        nonce = f"sn-{secrets.token_hex(16)}"
        expires_iso = expires_at.isoformat() if expires_at else None
        
        with self.db._db_op("Issue server nonce") as conn:
            conn.execute(
                """
                INSERT INTO authority_proofs (nonce, principal, scope_json, expires_at)
                VALUES (?, ?, ?, ?)
                """,
                (nonce, principal, json.dumps(scope), expires_iso)
            )
            conn.commit()
        return nonce

    def verify_nonce(self, nonce: str, required_scope: Dict[str, Any]) -> bool:
        """
        Validates the nonce is active, not expired, and contains the required scope.
        Returns True if authorized, False otherwise.
        """
        with self.db.get_connection() as conn:
            row = conn.execute(
                "SELECT principal, scope_json, expires_at, status FROM authority_proofs WHERE nonce = ?",
                (nonce,)
            ).fetchone()
            
            if not row:
                return False
                
            if row["status"] != "active":
                return False
                
            if row["expires_at"]:
                expires = datetime.fromisoformat(row["expires_at"])
                if datetime.now(timezone.utc) > expires:
                    return False
                    
            granted_scope = json.loads(row["scope_json"]) if row["scope_json"] else {}
            
            # Sub-dictionary containment check
            for key, required_val in required_scope.items():
                if granted_scope.get(key) != required_val:
                    return False
                    
            return True

    def revoke_nonce(self, nonce: str) -> None:
        """Explicitly revoke an issued server nonce to prevent further use."""
        with self.db._db_op("Revoke server nonce") as conn:
            conn.execute("UPDATE authority_proofs SET status = 'revoked' WHERE nonce = ?", (nonce,))
            conn.commit()
