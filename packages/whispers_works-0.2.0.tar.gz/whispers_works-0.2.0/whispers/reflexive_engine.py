"""Reflexive Coordination Engine v0.

The nervous system's first reflex — automatic, bounded actions taken when
specific coordination conditions are met. Deterministic rules, not LLM-driven.
Typed runtime truth, version-aware, operator-visible.

Each reflex is a pure function: (world_state) → List[CoordinationInsight].
The engine collects, deduplicates, tracks escalation, and detects resolution.

Design:
  - Progressive escalation: concern → recommend (proportional to age)
  - Cooldowns: won't re-fire for the same subject within its window
  - Resolution tracking: emits when a previously-raised insight clears
  - Version-aware: skips action when baton has mutated since last read
  - Composable: adding a reflex is one function and one test
"""

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Progressive escalation stages
# ---------------------------------------------------------------------------

class Stage(str, Enum):
    QUIET = "quiet"          # Below action threshold. Noted internally.
    CONCERN = "concern"      # Operator-visible. No action suggested yet.
    RECOMMEND = "recommend"  # Specific action suggested.
    URGENT = "urgent"        # Immediate attention needed.


_STAGE_RANK = {Stage.QUIET: 0, Stage.CONCERN: 1, Stage.RECOMMEND: 2, Stage.URGENT: 3}


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class CoordinationInsight:
    """A single coordination observation from a reflex."""
    reflex: str                    # which reflex produced this
    stage: Stage                   # escalation level
    subject_key: str               # stable dedup key (e.g., "baton:abc123")
    agents_involved: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)
    detected_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "reflex": self.reflex,
            "stage": self.stage.value,
            "subject_key": self.subject_key,
            "agents_involved": self.agents_involved,
            "details": self.details,
            "detected_at": self.detected_at,
        }


@dataclass
class Resolution:
    """Emitted when a previously-raised insight clears."""
    subject_key: str
    reflex: str
    was_stage: str               # what stage it had reached before resolving
    resolved_at: float = field(default_factory=time.time)
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "subject_key": self.subject_key,
            "reflex": self.reflex,
            "was_stage": self.was_stage,
            "resolved_at": self.resolved_at,
            "details": self.details,
        }


# ---------------------------------------------------------------------------
# Cooldown tracker
# ---------------------------------------------------------------------------

class CooldownTracker:
    """Per-subject cooldown. Prevents alert fatigue."""

    def __init__(self):
        self._last_fired: Dict[str, float] = {}

    def should_fire(self, subject_key: str, cooldown_seconds: float) -> bool:
        last = self._last_fired.get(subject_key, 0)
        return (time.time() - last) >= cooldown_seconds

    def record(self, subject_key: str) -> None:
        self._last_fired[subject_key] = time.time()

    def clear(self, subject_key: str) -> None:
        self._last_fired.pop(subject_key, None)


# ---------------------------------------------------------------------------
# Reflex: stale_offered_baton
# ---------------------------------------------------------------------------

# Thresholds (seconds)
_STALE_CONCERN_THRESHOLD = 15 * 60   # 15 minutes
_STALE_RECOMMEND_THRESHOLD = 30 * 60  # 30 minutes


def _format_age(seconds: float) -> str:
    minutes = int(seconds / 60)
    if minutes < 1:
        return "just now"
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    remaining = minutes % 60
    if hours < 24:
        return f"{hours}h{remaining}m" if remaining else f"{hours}h"
    return f"{hours // 24}d"


_ESCALATION_PRIORITY_THRESHOLD = 2 * 60 * 60     # 2 hours → priority
_ESCALATION_FLASH_THRESHOLD = 6 * 60 * 60        # 6 hours → flash


def reflex_stalled_handoff(world: Dict[str, Any]) -> List[CoordinationInsight]:
    """Detect handoffs waiting too long for acknowledgment.

    Escalation tiers (machine courtesy — escalate, don't repeat):
    15min+ → concern (operator-visible alert only)
    30min+ → recommend (routine re-notify to assignee)
    2h+   → recommend (priority re-notify — escalated wording)
    6h+   → recommend (flash re-notify — operator alert)

    Skips if assignee is offline (they can't see the re-notify).
    """
    insights = []
    now = time.time()

    for baton in world.get("active_batons", []):
        if baton.get("state") != "offered":
            continue

        created = baton.get("created_epoch", 0)
        age = now - created

        if age < _STALE_CONCERN_THRESHOLD:
            continue

        assignee = baton.get("assignee", "unknown")
        owner = baton.get("owner", "unknown")
        assignee_online = baton.get("assignee_online", False)
        baton_ref = baton.get("baton_ref", "unknown")
        subject = baton.get("subject", "handoff")
        version = baton.get("version", 1)

        # Offline no-op: if assignee isn't online, skip
        if not assignee_online:
            continue

        stage = Stage.RECOMMEND if age >= _STALE_RECOMMEND_THRESHOLD else Stage.CONCERN

        # Escalation tier determines reminder priority and wording
        if age >= _ESCALATION_FLASH_THRESHOLD:
            escalation = "flash"
        elif age >= _ESCALATION_PRIORITY_THRESHOLD:
            escalation = "priority"
        else:
            escalation = "routine"

        insights.append(CoordinationInsight(
            reflex="stalled_handoff",
            stage=stage,
            subject_key=f"baton:{baton_ref}",
            agents_involved=[owner, assignee],
            details={
                "baton_ref": baton_ref,
                "owner": owner,
                "assignee": assignee,
                "age_seconds": int(age),
                "age_human": _format_age(age),
                "assignee_online": assignee_online,
                "subject": subject,
                "version": version,
                "action": "re_notify" if stage == Stage.RECOMMEND else "alert_only",
                "escalation": escalation,
            },
        ))

    return insights


# ---------------------------------------------------------------------------
# Reflex: stale readiness with actionable items waiting
# ---------------------------------------------------------------------------

_STALE_READINESS_THRESHOLD = 30 * 60    # 30 minutes without heartbeat update
_STALE_READINESS_URGENT = 2 * 60 * 60   # 2 hours — urgent if actionable items waiting


def reflex_stale_readiness(world: Dict[str, Any]) -> List[CoordinationInsight]:
    """Detect agents whose readiness hasn't been updated while actionable items wait.

    When an agent hasn't refreshed their heartbeat/readiness and they have
    actionable queue items, this likely means they're stuck, disconnected,
    or forgot to update state. Surface this proactively so the operator
    or peers can intervene.
    """
    insights = []
    now = time.time()

    for agent in world.get("agents", []):
        agent_name = agent.get("agent_name", "unknown")
        last_heartbeat = agent.get("last_heartbeat_epoch", 0)
        actionable_count = agent.get("actionable_count", 0)
        readiness = agent.get("readiness", "ready")

        if not last_heartbeat or actionable_count == 0:
            continue

        staleness = now - last_heartbeat
        if staleness < _STALE_READINESS_THRESHOLD:
            continue

        # Agent has stale readiness AND pending actionable items
        if staleness >= _STALE_READINESS_URGENT:
            stage = Stage.URGENT
            escalation = "flash"
        elif staleness >= _STALE_READINESS_THRESHOLD * 2:
            stage = Stage.RECOMMEND
            escalation = "priority"
        else:
            stage = Stage.CONCERN
            escalation = "routine"

        insights.append(CoordinationInsight(
            reflex="stale_readiness",
            stage=stage,
            subject_key=f"readiness:{agent_name}",
            agents_involved=[agent_name],
            details={
                "agent_name": agent_name,
                "readiness": readiness,
                "staleness_seconds": int(staleness),
                "staleness_human": _format_age(staleness),
                "actionable_count": actionable_count,
                "escalation": escalation,
                "action": "check_agent" if stage == Stage.CONCERN else "intervene",
            },
        ))

    return insights


# ---------------------------------------------------------------------------
# Reflex registry
# ---------------------------------------------------------------------------

_REFLEXES: List[Callable[[Dict[str, Any]], List[CoordinationInsight]]] = [
    reflex_stalled_handoff,
    reflex_stale_readiness,
]


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class ReflexiveCoordinationEngine:
    """Runs reflexes, manages state, emits insights and resolutions.

    Stateful: tracks active insights, cooldowns, and escalation history.
    Reflexes are stateless pure functions — the engine handles lifecycle.
    """

    DEFAULT_COOLDOWN_SECONDS = 30 * 60  # 30 minutes between re-fires

    def __init__(self, on_insight=None, on_resolution=None):
        self._active: Dict[str, CoordinationInsight] = {}
        self._cooldowns = CooldownTracker()
        self._on_insight = on_insight
        self._on_resolution = on_resolution

    @property
    def active_insights(self) -> List[CoordinationInsight]:
        return list(self._active.values())

    def scan(self, world: Dict[str, Any]) -> Dict[str, Any]:
        """Run all reflexes against current world state.

        Returns summary: new insights, escalations, resolutions.
        """
        all_insights: List[CoordinationInsight] = []

        for reflex_fn in _REFLEXES:
            try:
                results = reflex_fn(world)
                all_insights.extend(results)
            except Exception:
                logger.warning("Reflex %s failed", reflex_fn.__name__, exc_info=True)

        # Deduplicate and detect changes
        new_insights = []
        escalations = []

        for insight in all_insights:
            existing = self._active.get(insight.subject_key)

            if existing is None:
                # New insight — check cooldown
                if self._cooldowns.should_fire(insight.subject_key, self.DEFAULT_COOLDOWN_SECONDS):
                    new_insights.append(insight)
                    self._cooldowns.record(insight.subject_key)
            elif _STAGE_RANK.get(insight.stage, 0) > _STAGE_RANK.get(existing.stage, 0):
                # Escalation — always fires regardless of cooldown
                escalations.append(insight)
                self._cooldowns.record(insight.subject_key)

            self._active[insight.subject_key] = insight

        # Detect resolutions — previously active, now absent
        current_keys = {i.subject_key for i in all_insights}
        cleared_keys = set(self._active.keys()) - current_keys
        resolutions = []

        for key in cleared_keys:
            old = self._active.pop(key)
            # Do NOT clear cooldowns on resolution. The insight may reappear
            # if a transient condition changes (e.g., assignee goes offline
            # then comes back online). Preserving the cooldown prevents
            # reminder spam from online-status flicker.
            resolutions.append(Resolution(
                subject_key=key,
                reflex=old.reflex,
                was_stage=old.stage.value,
                details=old.details,
            ))

        # Fire callbacks
        for insight in new_insights + escalations:
            if self._on_insight:
                try:
                    self._on_insight(insight)
                except Exception:
                    logger.warning("Insight callback failed", exc_info=True)

        for resolution in resolutions:
            if self._on_resolution:
                try:
                    self._on_resolution(resolution)
                except Exception:
                    logger.warning("Resolution callback failed", exc_info=True)

        return {
            "new": [i.to_dict() for i in new_insights],
            "escalated": [i.to_dict() for i in escalations],
            "resolved": [r.to_dict() for r in resolutions],
            "active_count": len(self._active),
        }
