import logging
from typing import Optional
from .db import WhispersDB

class GarbageCollector:
    """Handles TTL decay and Moving un-acked messages to the Dead Letter Queue."""
    def __init__(self, db: WhispersDB):
        self.db = db
        
    def sweep(self) -> int:
        """Finds TTL expired messages and moves them to DLQ. Returns number swept."""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT uuid, from_agent, subject, created_at, ttl_seconds 
                FROM messages 
                WHERE ttl_seconds IS NOT NULL 
                AND status != 'done' 
                AND datetime(created_at, '+' || CAST(ttl_seconds AS TEXT) || ' seconds') < CURRENT_TIMESTAMP
            ''')
            expired = cursor.fetchall()
            
            for row in expired:
                cursor.execute(
                    "INSERT INTO dead_letters (uuid, original_envelope, reason) VALUES (?, ?, ?)",
                    (row['uuid'], f"From:{row['from_agent']} Subject:{row['subject']}", "TTL Expired")
                )
                cursor.execute("UPDATE messages SET status = 'failed' WHERE uuid = ?", (row['uuid'],))
            
            conn.commit()
            return len(expired)

    def sweep_stale_batons(self) -> int:
        """Finds abandoned batons and expires them automatically in bulk.
        
        Rules:
        - Offered Expiry: > 2 hours un-acked.
        - Idle Expiry: > 12 hours without progress updates on an accepted baton.
        """
        swept_count = 0
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            # Rule 1: Offered Expiry (un-acked for > 2 hours)
            cursor.execute('''
                SELECT m.uuid, m.from_agent, r.recipient_callsign, m.subject, r.rowid as r_id
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE (m.msg_type = 'handoff_baton.v1' OR m.payload LIKE '%"schema": "handoff_baton.v1"%')
                AND r.delivery_status IN ('delivered', 'read')
                AND r.ack_state IS NULL
                AND datetime(m.created_at, '+2 hours') < CURRENT_TIMESTAMP
            ''')
            offered_stale = cursor.fetchall()
            
            for row in offered_stale:
                cursor.execute(
                    "UPDATE message_recipients SET ack_state = 'expired', ack_detail = ? WHERE rowid = ?",
                    ("Auto-expired: Offered baton un-acknowledged for > 2 hours.", row['r_id'])
                )
                cursor.execute(
                    "INSERT INTO dead_letters (uuid, original_envelope, reason) VALUES (?, ?, ?)",
                    (row['uuid'], f"From:{row['from_agent']} To:{row['recipient_callsign']} Subject:{row['subject']}", "Baton Offered Expiry")
                )
                # Ensure the message status is updated if not done
                cursor.execute("UPDATE messages SET status = 'failed' WHERE uuid = ? AND status != 'done'", (row['uuid'],))
                swept_count += 1
                
            # Rule 2: Idle Expiry (in-progress/accepted for > 12 hours with no newer updates)
            cursor.execute('''
                SELECT m.uuid, m.from_agent, r.recipient_callsign, m.subject, r.rowid as r_id
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                LEFT JOIN baton_projections bp ON m.uuid = bp.baton_ref
                WHERE (m.msg_type = 'handoff_baton.v1' OR m.payload LIKE '%"schema": "handoff_baton.v1"%')
                AND r.ack_state IN ('accepted', 'conditionally_accepted', 'in_progress', 'blocked', 'review_pending')
                AND (bp.state IS NULL OR bp.state NOT IN ('completed', 'merged', 'superseded', 'expired', 'canceled', 'rejected'))
                AND datetime(
                    COALESCE(
                        (SELECT MAX(created_at) FROM messages mu WHERE mu.reply_to = m.uuid AND (mu.msg_type = 'baton_update.v1' OR mu.payload LIKE '%"schema": "baton_update.v1"%')),
                        r.acked_at,
                        m.created_at
                    ), '+12 hours'
                ) < CURRENT_TIMESTAMP
            ''')
            idle_stale = cursor.fetchall()
            
            for row in idle_stale:
                cursor.execute(
                    "UPDATE message_recipients SET ack_state = 'expired', ack_detail = ? WHERE rowid = ?",
                    ("Auto-expired: Accepted baton idle for > 12 hours with no progress updates.", row['r_id'])
                )
                cursor.execute(
                    "INSERT INTO dead_letters (uuid, original_envelope, reason) VALUES (?, ?, ?)",
                    (row['uuid'], f"From:{row['from_agent']} To:{row['recipient_callsign']} Subject:{row['subject']}", "Baton Idle Expiry")
                )
                cursor.execute("UPDATE messages SET status = 'failed' WHERE uuid = ? AND status != 'done'", (row['uuid'],))
                swept_count += 1
                
            conn.commit()
            
            if swept_count > 0:
                logging.getLogger("whispers").info(f"[GarbageCollector] Swept {swept_count} stale batons to expired terminal state.")

            return swept_count

    def sweep_hung_messages(self, max_age_hours: int = 2) -> int:
        """Revert hung delivered-but-unread messages after max_age_hours.

        Messages stuck in 'delivered' status without being read are likely
        going to a disconnected or crashed agent. Move them to dead letters
        so the sender knows delivery failed.
        """
        swept = 0
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT m.uuid, m.from_agent, m.subject, r.recipient_callsign, r.rowid as r_id
                FROM messages m
                JOIN message_recipients r ON r.message_uuid = m.uuid
                WHERE r.delivery_status IN ('delivered', 'queued')
                  AND r.read_at IS NULL
                  AND m.status NOT IN ('done', 'failed')
                  AND datetime(m.created_at, '+' || ? || ' hours') < CURRENT_TIMESTAMP
            ''', (max_age_hours,))
            hung = cursor.fetchall()

            for row in hung:
                cursor.execute(
                    "UPDATE message_recipients SET delivery_status = 'expired', ack_detail = ? WHERE rowid = ?",
                    (f"Auto-expired: delivered but unread for >{max_age_hours}h.", row['r_id'])
                )
                cursor.execute(
                    "INSERT OR IGNORE INTO dead_letters (uuid, original_envelope, reason) VALUES (?, ?, ?)",
                    (row['uuid'], f"From:{row['from_agent']} To:{row['recipient_callsign']} Subject:{row['subject']}", f"Hung message: unread for >{max_age_hours}h")
                )
                cursor.execute(
                    "UPDATE messages SET status = 'failed' WHERE uuid = ? AND status NOT IN ('done', 'failed')",
                    (row['uuid'],)
                )
                swept += 1

            conn.commit()

            if swept > 0:
                logging.getLogger("whispers").info(f"[GarbageCollector] Swept {swept} hung unread messages to dead letters.")

        return swept

    def sweep_expired_leases(self) -> int:
        """Expire file leases past their TTL."""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.execute(
                    "UPDATE file_leases SET released_at = CURRENT_TIMESTAMP WHERE released_at IS NULL AND expires_at < CURRENT_TIMESTAMP"
                )
                count = cursor.rowcount
                if count > 0:
                    conn.commit()
                    logging.getLogger("whispers").info(f"[GarbageCollector] Expired {count} file leases.")
                return count
        except Exception:
            return 0  # file_leases table may not exist yet

    def sweep_all(self) -> dict:
        """Run all GC sweeps. Returns counts per category."""
        results = {}
        results["ttl_expired"] = self.sweep()
        results["stale_batons"] = self.sweep_stale_batons()
        results["hung_messages"] = self.sweep_hung_messages()
        results["expired_leases"] = self.sweep_expired_leases()
        results.update(self.sweep_retention())
        return results

    def sweep_retention(self) -> dict:
        """Enforce retention policies — delete data older than configured thresholds.

        Part of security item #10 (participant rights baseline).
        """
        from ..participant_rights import enforce_retention
        with self.db.get_connection() as conn:
            return enforce_retention(conn)
