import os
import contextlib
import sqlite3
import json
import logging
import hashlib
import secrets
import uuid
from typing import Optional, List, Dict, Any
from ..envelope import AcknowledgmentState, Envelope
from ..identity import fingerprint_public_key, normalize_public_key
from ..path_utils import resolve_path, whispers_path
from ..presence_policy import default_presence_policy, normalize_presence_policy
from ..time_utils import parse_timestamp, to_utc_iso, utc_now
from ..trust_baseline import baseline_trust_tier
from ..twoack import TERMINAL_BATON_STATES, validate_baton_transition

logger = logging.getLogger("whispers")

CURRENT_SCHEMA_VERSION = 2
DEFAULT_READINESS_STATE = "ready"
VALID_READINESS_STATES = {
    "ready",
    "busy",
    "blocked",
    "warming",
    "paused_by_operator",
    "degraded",
}
VALID_INTERRUPTIBILITY_STATES = {
    "free",
    "defer",
    "urgent_only",
    "do_not_interrupt",
}
VALID_QUALITY_RISK_STATES = {"low", "medium", "high"}
VALID_ATTENTION_STATES = {
    "working",
    "waiting_on_operator",
    "waiting_on_peer",
    "blocked_external",
    "needs_assignment",
}
REMOTE_SESSION_KINDS = (
    "remote_http",
    "local_listener",
    "mcp_bridge",
    "dashboard_console",
    "infrastructure",
)
REMOTE_SESSION_KINDS_SQL = ", ".join(f"'{kind}'" for kind in REMOTE_SESSION_KINDS)
TERMINAL_BATON_STATES = ("completed", "merged", "superseded", "rejected", "expired")
TERMINAL_BATON_STATES_SQL = ", ".join(f"'{state}'" for state in TERMINAL_BATON_STATES)
_ACKNOWLEDGED_BATON_OFFER_EXISTS_SQL = """
EXISTS (
    SELECT 1
    FROM message_recipients mr
    WHERE mr.message_uuid = bp.baton_ref
      AND mr.ack_state IS NOT NULL
)
"""
_ACTIVE_BATON_PROJECTION_SQL = f"""
(
    bp.state NOT IN ('offered', 'review_pending')
    OR NOT {_ACKNOWLEDGED_BATON_OFFER_EXISTS_SQL}
)
"""
_WAITING_BATON_PROJECTION_SQL = f"""
bp.state IN ('offered', 'review_pending')
AND NOT {_ACKNOWLEDGED_BATON_OFFER_EXISTS_SQL}
"""
_RUNTIME_FIELD_UNSET = Ellipsis
_HOT_QUEUE_STATUSES = ("queued", "unclaimed", "delivered")
_HOT_QUEUE_STATUSES_SQL = ", ".join(f"'{status}'" for status in _HOT_QUEUE_STATUSES)
_ACTIVE_HOT_QUEUE_FILTER_SQL = f"""
    m.status = 'new'
    AND r.delivery_status IN ({_HOT_QUEUE_STATUSES_SQL})
    AND r.archived_at IS NULL
    AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
"""
_WORKSPACE_COMPACTION_EXEMPT_DELTA_KINDS = {
    "handoff_in",
    "handoff_out",
    "review_published",
    "review_claimed",
    "review_resolved",
    "review_verdict",
    "dissent_recorded",
    "dissent_resolved",
}


def _decode_json_object(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    if not isinstance(value, str) or not value:
        return {}
    try:
        decoded = json.loads(value)
    except Exception:
        return {}
    return decoded if isinstance(decoded, dict) else {}


def _queue_compaction_class(row: sqlite3.Row | Dict[str, Any]) -> Optional[str]:
    sender = str(row["from_agent"] or "").strip().lower()
    msg_type = str(row["msg_type"] or "").strip().lower()
    priority = str(row["priority"] or "").strip().lower()
    if priority != "routine":
        return None
    if sender == "whispers-server" and msg_type == "heads_up":
        return "system_reminder"

    payload = _decode_json_object(row["payload"])
    metadata = _decode_json_object(row["metadata"])
    schema = metadata.get("whispers:schema") or payload.get("schema")
    if schema != "workspace_delta.v1":
        return None

    payload_body = payload.get("payload") if isinstance(payload.get("payload"), dict) else {}
    delta_kind = (
        metadata.get("whispers:delta_kind")
        or payload_body.get("delta_kind")
        or payload.get("delta_kind")
        or ""
    )
    normalized_delta_kind = str(delta_kind).strip().lower()
    if normalized_delta_kind in _WORKSPACE_COMPACTION_EXEMPT_DELTA_KINDS:
        return None
    return "workspace_delta"


def _stalled_handoff_reminder_baton_ref(metadata: Any) -> Optional[str]:
    decoded = _decode_json_object(metadata)
    reminder_kind = str(decoded.get("whispers:reminder_kind") or "").strip().lower()
    baton_ref = str(decoded.get("whispers:baton_ref") or "").strip()
    if reminder_kind != "stalled_handoff" or not baton_ref:
        return None
    return baton_ref


def _default_remote_session_lease_seconds() -> int:
    return int(os.getenv("WHISPERS_REMOTE_LEASE_SECONDS", "300"))


def _format_workspace_labels(labels: List[str], max_items: int = 2) -> str:
    if not labels:
        return ""
    if len(labels) <= max_items:
        return ", ".join(labels)
    return f"{', '.join(labels[:max_items])} +{len(labels) - max_items}"


def _normalize_optional_text(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _normalize_claimed_path(path: str) -> str:
    normalized = str(path or "").replace("\\", "/").strip().rstrip("/")
    if not normalized:
        raise WhispersDBError("Claimed path cannot be empty.")
    return normalized


def _paths_overlap(path_a: str, path_b: str) -> bool:
    return (
        path_a == path_b
        or path_a.startswith(path_b + "/")
        or path_b.startswith(path_a + "/")
    )


def _normalize_attention_state(value: Any) -> Optional[str]:
    text = _normalize_optional_text(value)
    if text is None:
        return None
    normalized = text.lower()
    if normalized not in VALID_ATTENTION_STATES:
        raise WhispersDBError(
            f"Invalid attention state '{value}'. Expected one of: {', '.join(sorted(VALID_ATTENTION_STATES))}."
        )
    return normalized


def _extract_workspace_handoff_projection(envelope: Envelope) -> Optional[Dict[str, Any]]:
    payload = envelope.payload if isinstance(envelope.payload, dict) else None
    metadata = envelope.metadata if isinstance(envelope.metadata, dict) else {}
    if not payload:
        return None

    baton_payload: Optional[Dict[str, Any]] = None
    summary: Dict[str, Any] = {}
    trace: Dict[str, Any] = {}
    nested_envelope: Optional[Dict[str, Any]] = None

    if payload.get("schema") == "handoff_baton.v1" and isinstance(payload.get("payload"), dict):
        nested_envelope = payload
        baton_payload = payload["payload"]
        if isinstance(payload.get("summary"), dict):
            summary = payload["summary"]
        if isinstance(payload.get("trace"), dict):
            trace = payload["trace"]
    elif envelope.msg_type.value == "handoff_baton.v1" or metadata.get("whispers:schema") == "handoff_baton.v1":
        baton_payload = payload

    if not baton_payload:
        return None

    workspace_id = baton_payload.get("workspace_id")
    if not workspace_id:
        return None

    summary_human = summary.get("human")
    summary_headline = summary.get("headline")
    completed = baton_payload.get("completed")
    next_action = baton_payload.get("next_action")

    if summary_human:
        text = summary_human
    elif summary_headline and next_action:
        text = f"{summary_headline} | Next: {next_action}"
    elif summary_headline:
        text = summary_headline
    else:
        parts = [f"Handoff {envelope.sender} -> {envelope.recipient}"]
        if completed:
            parts.append(f"Completed: {completed}")
        if next_action:
            parts.append(f"Next: {next_action}")
        text = " | ".join(parts)

    state_patch: Dict[str, Any] = {
        "handoff_message_uuid": str(envelope.id),
        "handoff_sender": envelope.sender,
        "handoff_recipient": envelope.recipient,
        "handoff_subject": envelope.subject,
        "handoff_payload": baton_payload,
    }
    if summary:
        state_patch["handoff_summary"] = summary
    if nested_envelope:
        state_patch["handoff_envelope"] = nested_envelope

    return {
        "workspace_id": workspace_id,
        "delta_kind": "handoff_in",
        "actor": envelope.sender,
        "created_at": envelope.created_at.isoformat(),
        "text": text,
        "state_patch": state_patch,
        "related_message_id": str(trace.get("message_id") or envelope.id),
    }


def _is_active_workspace_posting_member(
    cursor: sqlite3.Cursor,
    workspace_id: str,
    agent_name: str,
) -> bool:
    row = cursor.execute(
        """
        SELECT 1
        FROM workspace_members
        WHERE workspace_id = ?
          AND agent_name = ?
          AND membership_state = 'active'
          AND membership_role = 'member'
        """,
        (workspace_id, agent_name),
    ).fetchone()
    return bool(row)


def _workspace_handoff_scope_boundary_violation(
    cursor: sqlite3.Cursor,
    envelope: Envelope,
) -> Optional[Dict[str, Any]]:
    projection = _extract_workspace_handoff_projection(envelope)
    if not projection:
        return None

    workspace_id = projection["workspace_id"]
    workspace = cursor.execute(
        "SELECT status FROM workspaces WHERE workspace_id = ?",
        (workspace_id,),
    ).fetchone()
    if not workspace or workspace["status"] != "active":
        return None

    if _is_active_workspace_posting_member(cursor, workspace_id, envelope.sender):
        return None

    return {
        "workspace_id": workspace_id,
        "message_uuid": str(envelope.id),
        "message_id": projection["related_message_id"],
        "reason": "non_member_workspace_handoff",
        "projected": False,
        "delivered": False,
        "required_membership": "active_posting_member",
        "explanation": (
            f"Workspace-linked handoff blocked; sender is not an active posting member "
            f"of workspace {workspace_id}."
        ),
    }


def _operator_override_inspection(envelope: Envelope) -> Optional[Dict[str, Any]]:
    outer = envelope.payload if isinstance(envelope.payload, dict) else None
    if not outer or outer.get("schema") != "external_action_result.v1":
        return None

    payload = outer.get("payload")
    if not isinstance(payload, dict):
        return {
            "invalid": True,
            "detail": {
                "message_uuid": str(envelope.id),
                "schema": "external_action_result.v1",
                "reason": "override_payload_missing",
                "explanation": "Operator override audit requires a structured external_action_result payload object.",
            },
            "audit_events": [],
        }

    override_fields = (
        "override_reason",
        "override_expires_at",
        "override_closed_at",
        "override_closure_note",
    )
    present_override_fields = [field for field in override_fields if payload.get(field) not in (None, "")]
    operator_override = payload.get("operator_override")

    if operator_override is not True:
        if present_override_fields:
            return {
                "invalid": True,
                "detail": {
                    "message_uuid": str(envelope.id),
                    "schema": "external_action_result.v1",
                    "action_ref": payload.get("action_ref"),
                    "reason": "override_fields_without_operator_override",
                    "provided_fields": present_override_fields,
                    "explanation": "Override metadata requires operator_override=true.",
                },
                "audit_events": [],
            }
        return None

    action_ref = _normalize_optional_text(payload.get("action_ref"))
    if action_ref is None:
        return {
            "invalid": True,
            "detail": {
                "message_uuid": str(envelope.id),
                "schema": "external_action_result.v1",
                "reason": "action_ref_required",
                "explanation": "Operator override audit requires action_ref on external_action_result.v1.",
            },
            "audit_events": [],
        }

    override_reason = _normalize_optional_text(payload.get("override_reason"))
    if override_reason is None:
        return {
            "invalid": True,
            "detail": {
                "message_uuid": str(envelope.id),
                "schema": "external_action_result.v1",
                "action_ref": action_ref,
                "reason": "override_reason_required",
                "explanation": "Operator override requires an explicit override_reason.",
            },
            "audit_events": [],
        }

    raw_expires_at = payload.get("override_expires_at")
    if raw_expires_at in (None, ""):
        return {
            "invalid": True,
            "detail": {
                "message_uuid": str(envelope.id),
                "schema": "external_action_result.v1",
                "action_ref": action_ref,
                "reason": "override_expiry_required",
                "explanation": "Operator override requires override_expires_at so the bypass stays time-bounded.",
            },
            "audit_events": [],
        }

    override_expires_at = parse_timestamp(raw_expires_at)
    if override_expires_at is None:
        return {
            "invalid": True,
            "detail": {
                "message_uuid": str(envelope.id),
                "schema": "external_action_result.v1",
                "action_ref": action_ref,
                "reason": "override_expiry_invalid",
                "provided_value": raw_expires_at,
                "explanation": "Operator override requires a valid ISO timestamp in override_expires_at.",
            },
            "audit_events": [],
        }

    created_at = parse_timestamp(envelope.created_at) or utc_now()
    if override_expires_at <= created_at:
        return {
            "invalid": True,
            "detail": {
                "message_uuid": str(envelope.id),
                "schema": "external_action_result.v1",
                "action_ref": action_ref,
                "reason": "override_expiry_not_future",
                "override_expires_at": to_utc_iso(override_expires_at),
                "message_created_at": to_utc_iso(created_at),
                "explanation": "Operator override expiry must be later than the message creation time.",
            },
            "audit_events": [],
        }

    raw_closed_at = payload.get("override_closed_at")
    override_closed_at = None
    if raw_closed_at not in (None, ""):
        override_closed_at = parse_timestamp(raw_closed_at)
        if override_closed_at is None:
            return {
                "invalid": True,
                "detail": {
                    "message_uuid": str(envelope.id),
                    "schema": "external_action_result.v1",
                    "action_ref": action_ref,
                    "reason": "override_closed_at_invalid",
                    "provided_value": raw_closed_at,
                    "explanation": "override_closed_at must be a valid ISO timestamp when present.",
                },
                "audit_events": [],
            }

    closure_note = _normalize_optional_text(payload.get("override_closure_note"))
    shared_detail = {
        "message_uuid": str(envelope.id),
        "schema": "external_action_result.v1",
        "action_ref": action_ref,
        "override_reason": override_reason,
        "override_expires_at": to_utc_iso(override_expires_at),
        "execution_outcome": payload.get("outcome"),
    }
    audit_events = [
        {
            "event_type": "operator_override",
            "outcome": "opened",
            "detail": shared_detail,
        }
    ]
    if override_closed_at is not None:
        closed_detail = dict(shared_detail)
        closed_detail["override_closed_at"] = to_utc_iso(override_closed_at)
        if closure_note is not None:
            closed_detail["override_closure_note"] = closure_note
        audit_events.append(
            {
                "event_type": "operator_override",
                "outcome": "closed",
                "detail": closed_detail,
            }
        )

    return {
        "invalid": False,
        "detail": shared_detail,
        "audit_events": audit_events,
    }


def _baton_scope_transition_inspection(
    cursor: sqlite3.Cursor,
    envelope: Envelope,
) -> Optional[Dict[str, Any]]:
    outer = envelope.payload if isinstance(envelope.payload, dict) else None
    if not outer:
        return None

    schema_id = outer.get("schema")
    if schema_id not in {"baton_ack.v1", "baton_update.v1", "baton_close.v1"}:
        return None

    payload = outer.get("payload") if isinstance(outer.get("payload"), dict) else outer
    baton_ref = _normalize_optional_text(payload.get("baton_ref")) if isinstance(payload, dict) else None
    if baton_ref is None:
        return None

    row = cursor.execute(
        """
        SELECT working_scope, owner_callsign, assignee_callsign
        FROM baton_projections
        WHERE baton_ref = ?
        """,
        (baton_ref,),
    ).fetchone()
    if not row:
        return None

    metadata = envelope.metadata if isinstance(envelope.metadata, dict) else {}
    declared_scope = _normalize_optional_text(metadata.get("whispers:working_scope"))
    stored_scope = _normalize_optional_text(row["working_scope"])

    if stored_scope == declared_scope:
        return None

    detail = {
        "message_uuid": str(envelope.id),
        "schema": schema_id,
        "baton_ref": baton_ref,
        "stored_scope": stored_scope,
        "declared_scope": declared_scope,
        "owner_callsign": row["owner_callsign"],
        "assignee_callsign": row["assignee_callsign"],
    }

    if stored_scope is None and declared_scope is not None:
        detail["reason"] = "baton_scope_added_late"
        detail["explanation"] = (
            "Baton lifecycle signal attempted to add working_scope after baton creation. "
            "Scope changes on an existing baton must be explicit, not inferred from a later lifecycle message."
        )
    elif stored_scope is not None and declared_scope is None:
        detail["reason"] = "baton_scope_dropped"
        detail["explanation"] = (
            "Baton lifecycle signal dropped the existing working_scope. "
            "Baton room context must stay attached across ack, update, and close."
        )
    else:
        detail["reason"] = "baton_scope_mismatch"
        detail["explanation"] = (
            "Baton lifecycle signal declared a different working_scope than the baton's recorded scope. "
            "Use a new handoff or an explicit future scope-transition path instead of silently changing rooms."
        )

    return {"invalid": True, "detail": detail}


def _insert_security_event(
    cursor: sqlite3.Cursor,
    *,
    event_type: str,
    outcome: str,
    actor_agent: Optional[str] = None,
    target_agent: Optional[str] = None,
    endpoint: Optional[str] = None,
    detail: Optional[Dict[str, Any] | str] = None,
) -> None:
    event_id = str(uuid.uuid4())
    detail_text = detail if isinstance(detail, str) or detail is None else json.dumps(detail, sort_keys=True)
    cursor.execute(
        """
        INSERT INTO security_events (
            event_id, event_type, outcome, actor_agent, target_agent, endpoint, detail
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (event_id, event_type, outcome, actor_agent, target_agent, endpoint, detail_text),
    )

INBOX_SELECT_COLS = """m.uuid, m.from_agent, m.to_agent, r.recipient_callsign, m.context_id, m.msg_type, m.content_type,
       m.subject, m.body, m.payload, m.priority, m.status, m.reply_to, m.trace_id,
       m.ttl_seconds, m.idempotency_key, m.metadata, m.created_at, m.seen_at,
       m.negotiation_id, m.turn_number, m.turns_total,
       r.delivery_status, r.delivered_at, r.claimed_by, r.claimed_at, r.read_at,
       r.ack_state, r.ack_detail, r.acked_by, r.acked_at, r.coordination_status,
       r.pinned_at, r.snoozed_until, r.archived_at, r.rowid as recipient_row_id,
       COALESCE(m.queue_class, 'conversation') as queue_class"""

DEAD_LETTER_SELECT_COLS = """m.uuid, m.from_agent, m.to_agent, m.context_id, m.msg_type, m.content_type,
    m.subject, m.body, m.payload, m.priority, m.reply_to, m.trace_id,
    m.ttl_seconds, m.idempotency_key, m.metadata, m.created_at"""

HANDOFF_BATON_MATCH_SQL = """
(
    m.msg_type IN ('handoff', 'handoff_baton.v1')
    OR m.payload LIKE '%"schema": "handoff_baton.v1"%'
    OR m.metadata LIKE '%handoff_baton.v1%'
)
"""

class WhispersDBError(Exception):
    pass

class WhispersIdentityConflictError(WhispersDBError):
    pass


class WhispersLeaseConflictError(WhispersDBError):
    def __init__(self, conflicts: List[Dict[str, Any]]):
        self.conflicts = conflicts
        summary = ", ".join(
            f"{entry['requested_path']} held by {entry['held_by']}"
            for entry in conflicts[:3]
        )
        if len(conflicts) > 3:
            summary += f" +{len(conflicts) - 3} more"
        super().__init__(f"File lease conflict: {summary}")

class BatonStateError(WhispersDBError):
    """Raised when a baton transition or ownership check fails."""
    pass

class WhispersRateLimitError(Exception):
    def __init__(self, message: str = "", retry_after: int = 0) -> None:
        super().__init__(message)
        self.retry_after = retry_after



class WhispersQueueLimitError(WhispersRateLimitError):
    def __init__(
        self,
        *,
        scope: str,
        subject: str,
        used: int,
        attempted: int,
        limit: int,
        policy_key: str,
        message: str,
    ) -> None:
        super().__init__(message)
        self.scope = scope
        self.subject = subject
        self.used = used
        self.attempted = attempted
        self.limit = limit
        self.policy_key = policy_key

    def as_detail(self) -> Dict[str, Any]:
        return {
            "error": "rate_limit_exceeded",
            "limit_type": "queued_recipients",
            "scope": self.scope,
            "subject": self.subject,
            "used": self.used,
            "attempted": self.attempted,
            "limit": self.limit,
            "remaining": max(0, self.limit - self.used),
            "policy_key": self.policy_key,
            "message": str(self),
        }


def _resolve_callsign_aliases(conn: sqlite3.Connection, callsign: str) -> List[str]:
    agent = conn.execute(
        "SELECT agent_id, callsign FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
        (callsign,),
    ).fetchone()
    if not agent:
        agent = conn.execute(
            """
            SELECT agent_id
            FROM callsign_ledger
            WHERE old_callsign = ? OR new_callsign = ?
            ORDER BY changed_at DESC
            LIMIT 1
            """,
            (callsign, callsign),
        ).fetchone()

    if not agent:
        return [callsign]

    aliases = {callsign}
    current = conn.execute(
        "SELECT callsign FROM agent_cards WHERE agent_id = ? AND deregistered_at IS NULL",
        (agent["agent_id"],),
    ).fetchone()
    if current and current["callsign"]:
        aliases.add(current["callsign"])

    rows = conn.execute(
        """
        SELECT old_callsign, new_callsign
        FROM callsign_ledger
        WHERE agent_id = ?
        """,
        (agent["agent_id"],),
    ).fetchall()
    for row in rows:
        if row["old_callsign"]:
            aliases.add(row["old_callsign"])
        if row["new_callsign"]:
            aliases.add(row["new_callsign"])
    return sorted(aliases)

class WhispersDB:
    def __init__(self, db_path: str = None, auto_repair: bool = False, read_only: bool = False, on_message_transition=None):
        if db_path is None:
            # DB path resolution: env override > canonical. Never CWD.
            canonical = whispers_path("whispers.db")
            env_path = os.getenv("WHISPERS_DB_PATH")
            db_path = env_path or canonical
            if not read_only:
                os.makedirs(os.path.dirname(resolve_path(db_path)), exist_ok=True)
        self.db_path = db_path
        self.read_only = read_only
        self.on_message_transition = on_message_transition
        self._ensure_current_schema(auto_repair=auto_repair)
        if not self.read_only:
            self._init_schema()

    def _ensure_current_schema(self, auto_repair: bool = False):
        """Detect V1 databases and rename them. V2 starts fresh — no migrations for alpha."""
        if not os.path.exists(self.db_path):
            return  # Fresh DB, nothing to check

        conn = sqlite3.connect(self.db_path, timeout=10.0)
        try:
            row = conn.execute("SELECT MAX(version) FROM schema_version").fetchone()
            version = row[0] if row else None
        except sqlite3.OperationalError:
            version = None  # No schema_version table → V1 database
        finally:
            conn.close()

        if version is not None and version >= CURRENT_SCHEMA_VERSION:
            return  # Current schema, nothing to do

        if not auto_repair:
            raise WhispersDBError(
                f"Database at {self.db_path} uses a legacy or unknown schema. "
                "Run 'whispers doctor --fix' to archive and rebuild it."
            )

        # V1 or outdated DB → rename and start fresh
        backup_path = self.db_path.replace('.db', '.v1.backup.db')
        i = 1
        while os.path.exists(backup_path):
            backup_path = self.db_path.replace('.db', f'.v1.backup.{i}.db')
            i += 1

        os.rename(self.db_path, backup_path)

        # Also move WAL/SHM files if they exist
        for suffix in ['-wal', '-shm']:
            wal = self.db_path + suffix
            if os.path.exists(wal):
                os.rename(wal, backup_path + suffix)

        logger.warning(f"[Whispers] Renamed V1 database to {backup_path}. Starting fresh with V2 schema.")

    def get_readonly_connection(self) -> sqlite3.Connection:
        import pathlib
        uri_path = f"{pathlib.Path(self.db_path).absolute().as_uri()}?mode=ro"
        conn = sqlite3.connect(uri_path, timeout=10.0, uri=True)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=10000")
        return conn

    def get_connection(self) -> sqlite3.Connection:
        # The python 'read_only' flag governs application gating, not sqlite transport
        conn = sqlite3.connect(self.db_path, timeout=10.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=10000")
        return conn

    def has_pending_messages(self, agent_name: str) -> bool:
        """Efficiently check for pending messages using a read-only connection.

        Uses the same unread predicate as peek_inbox: queued, unclaimed,
        and delivered messages that haven't been read, archived, or snoozed.
        """
        with contextlib.closing(self.get_readonly_connection()) as conn:
            cursor = conn.cursor()
            aliases = _resolve_callsign_aliases(conn, agent_name)
            placeholders = ",".join("?" * len(aliases))
            cursor.execute(f"""
                SELECT 1
                FROM message_recipients r
                JOIN messages m ON m.uuid = r.message_uuid
                WHERE r.recipient_callsign IN ({placeholders})
                  AND m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                  AND r.read_at IS NULL
                  AND r.archived_at IS NULL
                  AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
                LIMIT 1
            """, aliases)
            return bool(cursor.fetchone())

    @contextlib.contextmanager
    def _db_op(self, operation: str):
        """Context manager that wraps the common try/get_connection/except pattern.

        Yields a sqlite3.Connection.  On sqlite3.Error, raises WhispersDBError
        with a message of the form ``"<operation> failed: <detail>"``.
        """
        try:
            with self.get_connection() as conn:
                yield conn
        except sqlite3.Error as e:
            raise WhispersDBError(f"{operation} failed: {str(e)}") from e

    @staticmethod
    def _claimable_delivery_predicate(alias: str = "r") -> str:
        return f"""(
                  {alias}.delivery_status IN ('queued', 'unclaimed')
                  OR (
                      {alias}.delivery_status = 'delivered'
                      AND {alias}.read_at IS NULL
                      AND {alias}.claimed_by IS NULL
                  )
              )"""

    def has_table(self, table_name: str, *, conn: Optional[sqlite3.Connection] = None) -> bool:
        owns_conn = conn is None
        conn = conn or self.get_connection()
        try:
            row = conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ? LIMIT 1",
                (table_name,),
            ).fetchone()
            return bool(row)
        finally:
            if owns_conn:
                conn.close()

    def _init_schema(self) -> None:
        """Initialize the V2 schema from scratch. No ALTER TABLE migrations — clean slate."""
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # Concurrency protections
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA busy_timeout=10000")

            # Schema version tracking
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS schema_version (
                version INTEGER NOT NULL,
                migrated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            # Insert version if not already present
            cursor.execute("SELECT COUNT(*) FROM schema_version WHERE version = ?", (CURRENT_SCHEMA_VERSION,))
            if cursor.fetchone()[0] == 0:
                cursor.execute("INSERT INTO schema_version (version) VALUES (?)", (CURRENT_SCHEMA_VERSION,))

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                rowid INTEGER PRIMARY KEY AUTOINCREMENT,
                uuid TEXT UNIQUE NOT NULL,
                from_agent TEXT NOT NULL,
                to_agent TEXT NOT NULL,
                context_id TEXT,
                msg_type TEXT NOT NULL,
                content_type TEXT DEFAULT 'text/plain',
                subject TEXT NOT NULL,
                body TEXT,
                payload TEXT,
                priority TEXT DEFAULT 'routine',
                status TEXT DEFAULT 'new',
                delivery_status TEXT DEFAULT 'queued',
                reply_to TEXT,
                trace_id TEXT,
                ttl_seconds INTEGER,
                idempotency_key TEXT,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                seen_at TIMESTAMP,
                acked_at TIMESTAMP,
                negotiation_id TEXT,
                turn_number INTEGER,
                turns_total INTEGER,
                durable_at TIMESTAMP
            )
            """)

            # Schema slot reservation: add durable_at to existing databases
            try:
                cursor.execute("ALTER TABLE messages ADD COLUMN durable_at TIMESTAMP")
            except Exception:
                pass  # column already exists

            # Queue class column for attention rules (Trust Plan Phase 1)
            try:
                cursor.execute("ALTER TABLE messages ADD COLUMN queue_class TEXT DEFAULT 'conversation'")
            except Exception:
                pass  # column already exists

            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_queue_class ON messages(queue_class)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_trace ON messages(trace_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_leaky_bucket ON messages(from_agent, created_at)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_context ON messages(context_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(from_agent, to_agent, created_at)")
            cursor.execute(
                """
                CREATE UNIQUE INDEX IF NOT EXISTS idx_messages_idempotency
                ON messages(from_agent, idempotency_key)
                WHERE idempotency_key IS NOT NULL
                """
            )

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS dead_letters (
                uuid TEXT PRIMARY KEY,
                original_envelope TEXT NOT NULL,
                reason TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS presence (
                agent_name TEXT PRIMARY KEY,
                status TEXT DEFAULT 'offline',
                last_active TIMESTAMP,
                heartbeat_at TIMESTAMP,
                session_id TEXT,
                working_on TEXT,
                reception_mode TEXT DEFAULT 'open',
                mode_filter TEXT,
                mode_set_at TIMESTAMP,
                mode_set_by TEXT,
                cognitive_state TEXT,
                state_confidence REAL,
                state_updated_at TIMESTAMP,
                intent_broadcast TEXT,
                basis TEXT
            )
            """)
            self._ensure_column(cursor, "presence", "basis", "TEXT")

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_runtime_state (
                session_id TEXT PRIMARY KEY,
                agent_name TEXT NOT NULL,
                readiness TEXT NOT NULL DEFAULT 'ready',
                interruptibility TEXT,
                context_load REAL,
                quality_risk TEXT,
                current_task TEXT,
                progress_summary TEXT,
                last_progress_at TIMESTAMP,
                watchdog_state TEXT,
                working_set_json TEXT,
                attention_state TEXT,
                attention_detail TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                basis TEXT
            )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_agent_runtime_state_agent ON agent_runtime_state(agent_name)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_agent_runtime_state_updated ON agent_runtime_state(updated_at)")
            self._ensure_column(cursor, "agent_runtime_state", "attention_state", "TEXT")
            self._ensure_column(cursor, "agent_runtime_state", "attention_detail", "TEXT")
            self._ensure_column(cursor, "agent_runtime_state", "basis", "TEXT")
            self._ensure_column(cursor, "agent_runtime_state", "evidence_refs", "TEXT")

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS repo_lanes (
                agent_name TEXT PRIMARY KEY,
                repo_path TEXT,
                worktree_id TEXT,
                branch TEXT,
                base_commit TEXT,
                head_commit TEXT,
                dirty BOOLEAN NOT NULL DEFAULT FALSE,
                lane_state TEXT NOT NULL DEFAULT 'active',
                claimed_paths_json TEXT,
                workspace_id TEXT,
                upstream_ref TEXT,
                published_at TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                basis TEXT
            )
            """)
            self._ensure_column(cursor, "repo_lanes", "updated_at", "TIMESTAMP")
            cursor.execute(
                """
                UPDATE repo_lanes
                SET updated_at = COALESCE(updated_at, published_at, CURRENT_TIMESTAMP)
                WHERE updated_at IS NULL
                """
            )
            self._ensure_column(cursor, "repo_lanes", "basis", "TEXT")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_repo_lanes_state ON repo_lanes(lane_state)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_repo_lanes_workspace ON repo_lanes(workspace_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_repo_lanes_branch ON repo_lanes(branch)")

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS file_leases (
                lease_id TEXT PRIMARY KEY,
                agent_name TEXT NOT NULL,
                file_path TEXT NOT NULL,
                acquired_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP NOT NULL,
                released_at TIMESTAMP,
                workspace_id TEXT
            )
            """)
            cursor.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_file_leases_active_path_agent "
                "ON file_leases(file_path, agent_name) WHERE released_at IS NULL"
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_file_leases_active_path "
                "ON file_leases(file_path) WHERE released_at IS NULL"
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_file_leases_active_agent "
                "ON file_leases(agent_name) WHERE released_at IS NULL"
            )

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS presence_policy (
                agent_name TEXT PRIMARY KEY,
                visibility_posture TEXT NOT NULL DEFAULT 'visible',
                state_detail_visibility TEXT NOT NULL DEFAULT 'full',
                reachability TEXT NOT NULL DEFAULT 'all',
                notification_policy TEXT NOT NULL DEFAULT 'all',
                idle_mode TEXT NOT NULL DEFAULT 'stay_visible',
                idle_timeout_seconds INTEGER,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_cards (
                agent_id TEXT PRIMARY KEY,
                callsign TEXT UNIQUE NOT NULL,
                agent_type TEXT NOT NULL,
                trust_tier INTEGER DEFAULT 1,
                agent_tier TEXT NOT NULL DEFAULT 'full',
                max_receive_rate INTEGER,
                capabilities TEXT,
                capabilities_verified TEXT,
                tools TEXT,
                lifecycle TEXT DEFAULT 'persistent',
                ttl_seconds INTEGER,
                parent_id TEXT,
                can_send_system BOOLEAN DEFAULT FALSE,
                can_send_flash BOOLEAN DEFAULT TRUE,
                registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_seen TIMESTAMP,
                deregistered_at TIMESTAMP,
                realm TEXT NOT NULL DEFAULT 'local',
                model_id TEXT,
                display_name TEXT,
                description TEXT,
                tags TEXT,
                challenge_tendency TEXT,
                thinking_style TEXT,
                public_key TEXT,
                lineage_parent_id TEXT,
                pool BOOLEAN,
                pool_strategy TEXT
            )
            """)
            agent_card_columns = {
                row[1] for row in cursor.execute("PRAGMA table_info(agent_cards)").fetchall()
            }
            for column_name, definition in (
                ("agent_tier", "TEXT NOT NULL DEFAULT 'full'"),
                ("max_receive_rate", "INTEGER"),
            ):
                if column_name not in agent_card_columns:
                    cursor.execute(
                        f"ALTER TABLE agent_cards ADD COLUMN {column_name} {definition}"
                    )
            self._apply_agent_card_trust_baselines(cursor)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS message_recipients (
                rowid INTEGER PRIMARY KEY AUTOINCREMENT,
                message_uuid TEXT NOT NULL,
                recipient_callsign TEXT,
                room_id TEXT,
                delivery_status TEXT DEFAULT 'queued',
                claimed_by TEXT,
                claimed_at TIMESTAMP,
                read_at TIMESTAMP,
                ack_state TEXT,
                ack_detail TEXT,
                acked_by TEXT,
                acked_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            recipient_columns = {
                row[1] for row in cursor.execute("PRAGMA table_info(message_recipients)").fetchall()
            }
            for column_name, definition in (
                ("ack_state", "TEXT"),
                ("ack_detail", "TEXT"),
                ("acked_by", "TEXT"),
                ("acked_at", "TIMESTAMP"),
                ("pinned_at", "TIMESTAMP"),
                ("snoozed_until", "TIMESTAMP"),
                ("archived_at", "TIMESTAMP"),
                ("coordination_status", "TEXT"),
                ("archive_reason", "TEXT"),
                ("delivered_at", "TIMESTAMP"),
            ):
                if column_name not in recipient_columns:
                    cursor.execute(
                        f"ALTER TABLE message_recipients ADD COLUMN {column_name} {definition}"
                    )

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS autonomy_policies (
                agent_id TEXT NOT NULL,
                working_scope TEXT NOT NULL,
                can_summarize BOOLEAN DEFAULT FALSE,
                can_classify BOOLEAN DEFAULT FALSE,
                can_reply BOOLEAN DEFAULT FALSE,
                can_external_action BOOLEAN DEFAULT FALSE,
                shadow_mode BOOLEAN DEFAULT FALSE,
                PRIMARY KEY (agent_id, working_scope)
            )
            """)
            autonomy_columns = {
                row[1] for row in cursor.execute("PRAGMA table_info(autonomy_policies)").fetchall()
            }
            if "shadow_mode" not in autonomy_columns:
                cursor.execute("ALTER TABLE autonomy_policies ADD COLUMN shadow_mode BOOLEAN DEFAULT FALSE")

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS rooms (
                room_id TEXT PRIMARY KEY,
                name TEXT UNIQUE NOT NULL,
                description TEXT,
                created_by TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS room_members (
                room_id TEXT,
                agent_id TEXT,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (room_id, agent_id)
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS workspaces (
                workspace_id TEXT PRIMARY KEY,
                name TEXT,
                purpose TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'active',
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL,
                join_policy TEXT NOT NULL DEFAULT 'invite',
                linked_traces TEXT,
                primary_trace_id TEXT,
                last_delta_at TEXT,
                last_sequence INTEGER NOT NULL DEFAULT 0
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS workspace_members (
                workspace_id TEXT NOT NULL,
                agent_name TEXT NOT NULL,
                membership_role TEXT NOT NULL DEFAULT 'member',
                membership_state TEXT NOT NULL DEFAULT 'active',
                joined_at TEXT NOT NULL,
                left_at TEXT,
                PRIMARY KEY (workspace_id, agent_name),
                FOREIGN KEY (workspace_id) REFERENCES workspaces(workspace_id)
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS workspace_events (
                workspace_id TEXT NOT NULL,
                sequence INTEGER NOT NULL,
                delta_kind TEXT NOT NULL,
                actor TEXT NOT NULL,
                created_at TEXT NOT NULL,
                text TEXT,
                refs TEXT,
                artifacts TEXT,
                state_patch TEXT,
                related_message_id TEXT,
                PRIMARY KEY (workspace_id, sequence),
                FOREIGN KEY (workspace_id) REFERENCES workspaces(workspace_id)
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS workspace_invites (
                workspace_id TEXT NOT NULL,
                agent_name TEXT NOT NULL,
                invited_by TEXT NOT NULL,
                invited_at TEXT NOT NULL,
                PRIMARY KEY (workspace_id, agent_name),
                FOREIGN KEY (workspace_id) REFERENCES workspaces(workspace_id)
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS authority_proofs (
                nonce TEXT PRIMARY KEY,
                principal TEXT NOT NULL,
                scope_json TEXT,
                expires_at TEXT,
                status TEXT NOT NULL DEFAULT 'active',
                issued_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS callsign_ledger (
                agent_id TEXT,
                old_callsign TEXT,
                new_callsign TEXT,
                changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS negotiations (
                session_id TEXT PRIMARY KEY,
                initiator_id TEXT,
                participants TEXT,
                turns_each INTEGER,
                rules TEXT,
                status TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS decisions (
                decision_id TEXT PRIMARY KEY,
                negotiation_id TEXT,
                agent_id TEXT,
                decision_type TEXT,
                rationale TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS games (
                game_id TEXT PRIMARY KEY,
                template_name TEXT,
                current_phase TEXT,
                participants TEXT,
                state_data TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS api_tokens (
                token_id TEXT PRIMARY KEY,
                agent_name TEXT NOT NULL,
                token_hash TEXT UNIQUE NOT NULL,
                description TEXT,
                scopes TEXT DEFAULT '["*"]',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_used_at TIMESTAMP,
                revoked_at TIMESTAMP,
                expires_at TIMESTAMP
            )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_api_tokens_agent ON api_tokens(agent_name, revoked_at)")
            
            # Migration: add scopes column to existing api_tokens tables
            self._ensure_column(cursor, "api_tokens", "scopes", 'TEXT DEFAULT \'["*"]\'')



            cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_sessions (
                session_id TEXT PRIMARY KEY,
                agent_name TEXT NOT NULL,
                session_kind TEXT NOT NULL DEFAULT 'local_client',
                token_id TEXT,
                process_id INTEGER,
                host_id TEXT,
                metadata TEXT,
                lease_expires_at TIMESTAMP NOT NULL,
                last_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_agent_sessions_agent ON agent_sessions(agent_name)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_agent_sessions_lease ON agent_sessions(lease_expires_at)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_agent_sessions_process ON agent_sessions(process_id)")

            # Keep the new lease-derived session ledger populated for both remote and
            # pre-existing local presence rows when upgrading an existing DB in place.
            if self.has_table("remote_sessions", conn=cursor):
                cursor.execute(
                    """
                    INSERT OR IGNORE INTO agent_sessions (
                        session_id, agent_name, session_kind, token_id, metadata,
                        lease_expires_at, last_seen_at, created_at
                    )
                    SELECT
                        session_id,
                        agent_name,
                        'remote_http',
                        token_id,
                        json_object(
                            'client_name', client_name,
                            'client_version', client_version,
                            'capabilities', capabilities,
                            'remote_addr', remote_addr
                        ),
                        lease_expires_at,
                        last_seen_at,
                        created_at
                    FROM remote_sessions
                    """
                )
            cursor.execute(
                """
                INSERT OR IGNORE INTO agent_sessions (
                    session_id, agent_name, session_kind, metadata,
                    lease_expires_at, last_seen_at, created_at
                )
                SELECT
                    session_id,
                    agent_name,
                    'legacy_local',
                    json_object('source', 'presence_backfill'),
                    datetime(COALESCE(heartbeat_at, CURRENT_TIMESTAMP), '+30 seconds'),
                    COALESCE(heartbeat_at, last_active, CURRENT_TIMESTAMP),
                    CURRENT_TIMESTAMP
                FROM presence
                WHERE session_id IS NOT NULL
                  AND status IN ('online', 'idle')
                """
            )

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS security_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                outcome TEXT NOT NULL,
                actor_agent TEXT,
                target_agent TEXT,
                endpoint TEXT,
                detail TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_security_events_created ON security_events(created_at)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_security_events_actor ON security_events(actor_agent, created_at)")

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS blob_provenance (
                blob_ref TEXT PRIMARY KEY,
                stored_by TEXT NOT NULL,
                workspace_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_blob_provenance_workspace ON blob_provenance(workspace_id)")

            # Process Runs — shared task tracking for multi-agent coordination
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS process_runs (
                run_id TEXT PRIMARY KEY,
                workspace_id TEXT NOT NULL,
                name TEXT NOT NULL,
                purpose TEXT,
                created_by TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (workspace_id) REFERENCES workspaces(workspace_id)
            )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_process_runs_status ON process_runs(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_process_runs_workspace ON process_runs(workspace_id)")

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS process_tasks (
                task_id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                subject TEXT NOT NULL,
                description TEXT,
                status TEXT NOT NULL DEFAULT 'pending',
                assigned_to TEXT,
                assigned_at TIMESTAMP,
                completed_at TIMESTAMP,
                blocked_by TEXT,
                ordinal INTEGER NOT NULL DEFAULT 0,
                baton_ref TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (run_id) REFERENCES process_runs(run_id)
            )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_process_tasks_run ON process_tasks(run_id, ordinal)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_process_tasks_agent ON process_tasks(assigned_to, status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_process_tasks_status ON process_tasks(status)")

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS signal_claims (
                claim_id TEXT PRIMARY KEY,
                signal_uuid TEXT NOT NULL REFERENCES messages(uuid),
                topic TEXT,
                lens TEXT,
                audience_json TEXT,
                state TEXT NOT NULL DEFAULT 'open',
                claimant_identity TEXT,
                claimed_at TIMESTAMP,
                expires_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expected_passes INTEGER DEFAULT 1
            )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_signal_claims_state ON signal_claims(state)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_signal_claims_signal ON signal_claims(signal_uuid)")

            # Migration: add workspace_id to signal_claims for workspace projection
            self._ensure_column(cursor, "signal_claims", "workspace_id", "TEXT")

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS baton_projections (
                baton_ref TEXT PRIMARY KEY REFERENCES messages(uuid),
                owner_callsign TEXT NOT NULL,
                assignee_callsign TEXT,
                state TEXT NOT NULL,
                priority TEXT NOT NULL DEFAULT 'routine',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                delineation_text TEXT,
                linked_workspace_id TEXT,
                working_scope TEXT,
                artifact_refs TEXT,
                last_update_text TEXT,
                outcome TEXT
            )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_baton_projections_assignee_state ON baton_projections(assignee_callsign, state)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_baton_projections_owner_state ON baton_projections(owner_callsign, state)")
            self._ensure_column(cursor, "baton_projections", "version", "INTEGER NOT NULL DEFAULT 1")
            self._ensure_column(cursor, "baton_projections", "working_scope", "TEXT")
            self._ensure_column(cursor, "baton_projections", "attested", "INTEGER")

            # Narrative events (Narrator Agent Contract Slice 3)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS narrative_events (
                narrative_id TEXT PRIMARY KEY,
                narrator_agent TEXT NOT NULL,
                stance TEXT NOT NULL,
                narrative_text TEXT NOT NULL,
                signal_refs TEXT,
                narrative_thread TEXT,
                scope TEXT,
                continuity TEXT NOT NULL DEFAULT 'live',
                ttl_hours INTEGER NOT NULL DEFAULT 24,
                challengeable INTEGER NOT NULL DEFAULT 1,
                promoted INTEGER NOT NULL DEFAULT 0,
                promoted_at TIMESTAMP,
                retention_class TEXT,
                supersedes TEXT,
                superseded_by TEXT,
                workspace_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP
            )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_narrative_thread ON narrative_events(narrative_thread)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_narrative_scope ON narrative_events(scope)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_narrative_narrator ON narrative_events(narrator_agent)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_narrative_expires ON narrative_events(expires_at)")

            # Process Runs Substrate V1 — superseded by richer schema above (line ~1185)
            # Kept as comment for provenance: original V1 by Codex had objective/creator_callsign/title/assignee_callsign
            # V2 adds: name, purpose, created_by, blocked_by, baton_ref, assigned_at, completed_at, description

            conn.commit()

    def _ensure_column(
        self,
        cursor: sqlite3.Cursor,
        table: str,
        column: str,
        col_def: str,
    ) -> None:
        """Add a column to an existing table if it doesn't exist (idempotent migration)."""
        try:
            cols = [row[1] for row in cursor.execute(f"PRAGMA table_info({table})").fetchall()]
            if column not in cols:
                cursor.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_def}")
                logger.info("[Whispers] Migrated %s: added column %s", table, column)
        except sqlite3.OperationalError as e:
            # Table may not exist yet — CREATE TABLE will handle it.
            # Log anything else for diagnostics.
            if "no such table" not in str(e).lower():
                logger.warning("[Whispers] _ensure_column(%s.%s) failed: %s", table, column, e)

    # -----------------------------------------------------------------
    # Token scope constants
    # -----------------------------------------------------------------
    VALID_SCOPES = frozenset({
        "messages:send",
        "messages:read",
        "messages:stream",
        "presence:read",
        "agents:read",
        "agents:write",
        "tokens:manage",
        "admin:*",
        "*",
    })

    TOKEN_PROFILES = {
        "external-agent": ["messages:send", "messages:read", "presence:read", "agents:read"],
        "full-agent": ["messages:send", "messages:read", "messages:stream", "presence:read", "agents:read"],
        "operator": ["*"],
        "read-only": ["messages:read", "presence:read", "agents:read"],
    }

    @staticmethod
    def _hash_token(token: str) -> str:
        return hashlib.sha256(token.encode("utf-8")).hexdigest()

    def issue_api_token(
        self,
        agent_name: str,
        description: Optional[str] = None,
        scopes: Optional[List[str]] = None,
        profile: Optional[str] = None,
    ) -> str:
        """Issue a new API token with optional scope restrictions.

        Args:
            agent_name: Agent the token belongs to.
            description: Human-readable description.
            scopes: Explicit list of scopes (e.g. ["messages:send", "presence:read"]).
            profile: Preset profile name ("external-agent", "full-agent", "operator", "read-only").
                     Ignored if explicit scopes are provided.

        Returns:
            The raw token string (only returned once — store it securely).
        """
        # Resolve scopes: explicit > profile > default (full access)
        if scopes is None and profile:
            if profile not in self.TOKEN_PROFILES:
                raise WhispersDBError(
                    f"Unknown token profile: {profile!r}. "
                    f"Valid profiles: {', '.join(sorted(self.TOKEN_PROFILES))}"
                )
            scopes = self.TOKEN_PROFILES[profile]
        if scopes is None:
            scopes = ["*"]

        # Validate scope names
        invalid = set(scopes) - self.VALID_SCOPES
        if invalid:
            raise WhispersDBError(
                f"Invalid scopes: {invalid}. "
                f"Valid scopes: {', '.join(sorted(self.VALID_SCOPES))}"
            )

        raw_token = secrets.token_urlsafe(32)
        token_id = str(uuid.uuid4())
        token_hash = self._hash_token(raw_token)
        scopes_json = json.dumps(sorted(scopes))
        with self._db_op("Token issuance") as conn:
            conn.execute(
                """
                INSERT INTO api_tokens (token_id, agent_name, token_hash, description, scopes, last_used_at)
                VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                """,
                (token_id, agent_name, token_hash, description, scopes_json),
            )
            conn.commit()
        return raw_token

    def _get_api_token_row(self, token: str, *, include_revoked: bool = False) -> Optional[Dict[str, Any]]:
        token_hash = self._hash_token(token)
        query = """
            SELECT a.*, COALESCE(c.trust_tier, 1) as trust_tier
            FROM api_tokens a
            LEFT JOIN agent_cards c ON a.agent_name = c.callsign AND c.deregistered_at IS NULL
            WHERE a.token_hash = ?
              AND (a.expires_at IS NULL OR a.expires_at > CURRENT_TIMESTAMP)
        """
        params: tuple[Any, ...] = (token_hash,)
        if not include_revoked:
            query += " AND revoked_at IS NULL"
        with self._db_op("Token lookup") as conn:
            row = conn.execute(query, params).fetchone()
            return dict(row) if row else None
    def get_api_token(self, token: str) -> Optional[Dict[str, Any]]:
        return self._get_api_token_row(token, include_revoked=False)

    def get_api_token_any(self, token: str) -> Optional[Dict[str, Any]]:
        return self._get_api_token_row(token, include_revoked=True)

    def mark_token_used(self, token: str) -> None:
        token_hash = self._hash_token(token)
        with self._db_op("Token usage update") as conn:
            conn.execute(
                "UPDATE api_tokens SET last_used_at = CURRENT_TIMESTAMP WHERE token_hash = ?",
                (token_hash,),
            )
            conn.commit()
    def list_api_tokens(self, agent_name: str, include_revoked: bool = False) -> List[Dict[str, Any]]:
        query = """
            SELECT token_id, agent_name, description, scopes, created_at, last_used_at, revoked_at, expires_at
            FROM api_tokens
            WHERE agent_name = ?
        """
        params: tuple[Any, ...] = (agent_name,)
        if not include_revoked:
            query += " AND revoked_at IS NULL"
        query += " ORDER BY created_at DESC"
        with self._db_op("Token list") as conn:
            rows = conn.execute(query, params).fetchall()
            result = []
            for row in rows:
                d = dict(row)
                # Parse scopes from JSON string to list
                raw_scopes = d.get("scopes")
                if isinstance(raw_scopes, str):
                    try:
                        d["scopes"] = json.loads(raw_scopes)
                    except (json.JSONDecodeError, TypeError):
                        d["scopes"] = ["*"]
                elif raw_scopes is None:
                    d["scopes"] = ["*"]
                result.append(d)
            return result
    def get_agent_public_key(self, agent_name: str) -> Optional[str]:
        with self._db_op("Public key lookup") as conn:
            row = conn.execute(
                """
                SELECT public_key
                FROM agent_cards
                WHERE callsign = ? AND deregistered_at IS NULL
                """,
                (agent_name,),
            ).fetchone()
            if not row:
                raise WhispersDBError(f"Agent {agent_name} is not registered.")
            return row["public_key"]

    def get_agent_card(
        self,
        agent_name: str,
        *,
        conn: Optional[sqlite3.Connection] = None,
    ) -> Optional[Dict[str, Any]]:
        """Return the active agent_cards row for a callsign, or None if not registered."""
        owns_conn = conn is None
        conn = conn or self.get_connection()
        try:
            row = conn.execute(
                """
                SELECT *
                FROM agent_cards
                WHERE callsign = ? AND deregistered_at IS NULL
                """,
                (agent_name,),
            ).fetchone()
            if not row:
                return None
            return dict(row)
        except sqlite3.Error as e:
            raise WhispersDBError(f"Agent card lookup failed: {str(e)}")
        finally:
            if owns_conn:
                conn.close()

    def bind_agent_public_key(self, agent_name: str, public_key: str, *, replace: bool = False) -> Dict[str, Any]:
        normalized_key = normalize_public_key(public_key)
        try:
            with self.get_connection() as conn:
                card = conn.execute(
                    """
                    SELECT agent_id, callsign, public_key
                    FROM agent_cards
                    WHERE callsign = ? AND deregistered_at IS NULL
                    """,
                    (agent_name,),
                ).fetchone()
                if not card:
                    raise WhispersDBError(f"Agent {agent_name} is not registered.")

                current_key = card["public_key"]
                if current_key == normalized_key:
                    outcome = "unchanged"
                else:
                    if current_key and not replace:
                        raise WhispersIdentityConflictError(
                            "Public key already bound. Reconnect with the existing key or pass replace=True to rotate it."
                        )
                    outcome = "rotated" if current_key else "bound"
                    conn.execute(
                        """
                        UPDATE agent_cards
                        SET public_key = ?, last_seen = CURRENT_TIMESTAMP
                        WHERE agent_id = ?
                        """,
                        (normalized_key, card["agent_id"]),
                    )
                    conn.commit()
            return {
                "agent_name": agent_name,
                "public_key": normalized_key,
                "public_key_bound": True,
                "public_key_fingerprint": fingerprint_public_key(normalized_key),
                "binding_outcome": outcome,
            }
        except WhispersIdentityConflictError:
            raise
        except ValueError as e:
            raise WhispersDBError(str(e)) from e
        except sqlite3.Error as e:
            raise WhispersDBError(f"Public key binding failed: {str(e)}")

    def rename_agent_identity(
        self,
        old_callsign: str,
        new_callsign: str,
        *,
        display_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        try:
            with self.get_connection() as conn:
                current = conn.execute(
                    """
                    SELECT agent_id, callsign, display_name
                    FROM agent_cards
                    WHERE callsign = ? AND deregistered_at IS NULL
                    """,
                    (old_callsign,),
                ).fetchone()
                if not current:
                    raise WhispersDBError(f"Agent {old_callsign} is not registered.")

                conflict = conn.execute(
                    """
                    SELECT agent_id
                    FROM agent_cards
                    WHERE callsign = ? AND deregistered_at IS NULL
                    """,
                    (new_callsign,),
                ).fetchone()
                if conflict and conflict["agent_id"] != current["agent_id"]:
                    raise WhispersIdentityConflictError(
                        f"Callsign {new_callsign} is already claimed."
                    )

                if old_callsign != new_callsign:
                    conn.execute(
                        """
                        INSERT INTO callsign_ledger (agent_id, old_callsign, new_callsign)
                        VALUES (?, ?, ?)
                        """,
                        (current["agent_id"], old_callsign, new_callsign),
                    )

                    stale_presence = conn.execute(
                        "SELECT agent_name FROM presence WHERE agent_name = ?",
                        (new_callsign,),
                    ).fetchone()
                    if stale_presence:
                        conn.execute("DELETE FROM presence WHERE agent_name = ?", (new_callsign,))

                    conn.execute(
                        "UPDATE presence SET agent_name = ? WHERE agent_name = ?",
                        (new_callsign, old_callsign),
                    )
                    conn.execute(
                        "UPDATE api_tokens SET agent_name = ? WHERE agent_name = ?",
                        (new_callsign, old_callsign),
                    )

                    conn.execute(
                        "UPDATE agent_sessions SET agent_name = ? WHERE agent_name = ?",
                        (new_callsign, old_callsign),
                    )
                    conn.execute(
                        "UPDATE agent_runtime_state SET agent_name = ? WHERE agent_name = ?",
                        (new_callsign, old_callsign),
                    )
                    conn.execute(
                        """
                        UPDATE message_recipients
                        SET recipient_callsign = ?
                        WHERE recipient_callsign = ?
                          AND delivery_status IN ('queued', 'unclaimed', 'delivered')
                        """,
                        (new_callsign, old_callsign),
                    )

                conn.execute(
                    """
                    UPDATE agent_cards
                    SET callsign = ?,
                        display_name = COALESCE(?, display_name),
                        last_seen = CURRENT_TIMESTAMP
                    WHERE agent_id = ?
                    """,
                    (new_callsign, display_name, current["agent_id"]),
                )

                card = conn.execute(
                    """
                    SELECT *
                    FROM agent_cards
                    WHERE agent_id = ?
                    """,
                    (current["agent_id"],),
                ).fetchone()
                session = conn.execute(
                    """
                    SELECT session_id, lease_expires_at
                    FROM agent_sessions
                    WHERE LENGTH(session_id) > 0 AND token_id IS NOT NULL
                      AND agent_name = ?
                    ORDER BY last_seen_at DESC
                    LIMIT 1
                    """,
                    (new_callsign,),
                ).fetchone()
                moved_recipients = conn.execute(
                    """
                    SELECT COUNT(*)
                    FROM message_recipients
                    WHERE recipient_callsign = ?
                      AND delivery_status IN ('queued', 'unclaimed', 'delivered')
                    """,
                    (new_callsign,),
                ).fetchone()[0]
                conn.commit()

            result = dict(card) if card else {
                "agent_id": current["agent_id"],
                "callsign": new_callsign,
                "display_name": display_name or current["display_name"],
            }
            result["old_callsign"] = old_callsign
            result["new_callsign"] = new_callsign
            result["moved_pending_recipients"] = moved_recipients
            result["session"] = dict(session) if session else None
            return result
        except WhispersIdentityConflictError:
            raise
        except sqlite3.IntegrityError as e:
            raise WhispersIdentityConflictError(f"Callsign {new_callsign} is already claimed.") from e
        except sqlite3.Error as e:
            raise WhispersDBError(f"Rename failed: {str(e)}")

    def revoke_api_token(self, token: str) -> Optional[Dict[str, Any]]:
        token_row = self._get_api_token_row(token, include_revoked=True)
        if not token_row:
            return None

        with self._db_op("Token revoke") as conn:
            conn.execute(
                """
                UPDATE api_tokens
                SET revoked_at = COALESCE(revoked_at, CURRENT_TIMESTAMP)
                WHERE token_id = ?
                """,
                (token_row["token_id"],),
            )
            conn.execute("DELETE FROM agent_runtime_state WHERE session_id IN (SELECT session_id FROM agent_sessions WHERE token_id = ?)", (token_row["token_id"],))
            conn.execute("DELETE FROM agent_sessions WHERE token_id = ?", (token_row["token_id"],))
            # After deleting sessions, sync presence for affected agents
            # This needs to be done for all agents that had sessions with this token.
            # Since agent_sessions are deleted, we can't query them directly.
            # A more robust solution would involve tracking agent_name before deletion
            # or re-syncing all agents, but for now, we'll omit the sync here
            # as the primary goal is token revocation.
            conn.commit()
        return token_row

    def mark_agent_online(self, agent_name: str, session_id: str) -> None:
        with self._db_op("Presence update") as conn:
            conn.execute("INSERT OR IGNORE INTO presence (agent_name) VALUES (?)", (agent_name,))
            active = conn.execute(
                """
                SELECT session_id
                FROM agent_sessions
                WHERE session_id = ? AND agent_name = ? AND lease_expires_at >= CURRENT_TIMESTAMP
                """,
                (session_id, agent_name),
            ).fetchone()
            if active:
                conn.execute(
                    """
                    UPDATE presence
                    SET status = 'online',
                        session_id = ?,
                        heartbeat_at = CURRENT_TIMESTAMP,
                        last_active = CURRENT_TIMESTAMP
                    WHERE agent_name = ?
                    """,
                    (session_id, agent_name),
                )
                conn.execute(
                    """
                    UPDATE agent_cards
                    SET last_seen = CURRENT_TIMESTAMP
                    WHERE callsign = ? AND deregistered_at IS NULL
                    """,
                    (agent_name,),
                )
            conn.commit()
    def _sync_presence_from_sessions(self, conn: sqlite3.Connection, agent_name: str) -> None:
        conn.execute("INSERT OR IGNORE INTO presence (agent_name) VALUES (?)", (agent_name,))
        active = conn.execute(
            """
            SELECT session_id, last_seen_at
            FROM agent_sessions
            WHERE agent_name = ?
              AND lease_expires_at >= CURRENT_TIMESTAMP
            ORDER BY last_seen_at DESC, created_at DESC
            LIMIT 1
            """,
            (agent_name,),
        ).fetchone()
        if active:
            conn.execute(
                """
                UPDATE presence
                SET status = 'online',
                    session_id = ?,
                    heartbeat_at = COALESCE(?, CURRENT_TIMESTAMP)
                WHERE agent_name = ?
                """,
                (active["session_id"], active["last_seen_at"], agent_name),
            )
            return

        conn.execute(
            """
            UPDATE presence
            SET status = 'offline',
                session_id = NULL
            WHERE agent_name = ?
            """,
            (agent_name,),
        )
        
        from whispers.presence_policy import clear_session_override
        clear_session_override(agent_name)

    def _ensure_runtime_state_row(self, conn: sqlite3.Connection, agent_name: str, session_id: str) -> None:

        conn.execute(
            """
            INSERT OR IGNORE INTO agent_runtime_state (
                session_id,
                agent_name,
                readiness,
                updated_at
            ) VALUES (?, ?, ?, CURRENT_TIMESTAMP)
            """,
            (session_id, agent_name, DEFAULT_READINESS_STATE),
        )

    def upsert_agent_session(
        self,
        agent_name: str,
        session_id: str,
        *,
        session_kind: str,
        lease_seconds: int,
        token_id: Optional[str] = None,
        process_id: Optional[int] = None,
        host_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        substantive: bool = False,
    ) -> None:
        with self._db_op("Agent session update") as conn:
            conn.execute("INSERT OR IGNORE INTO presence (agent_name) VALUES (?)", (agent_name,))
            conn.execute(
                """
                INSERT INTO agent_sessions (
                    session_id, agent_name, session_kind, token_id, process_id,
                    host_id, metadata, lease_expires_at, last_seen_at
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, datetime('now', ?), CURRENT_TIMESTAMP
                )
                ON CONFLICT(session_id) DO UPDATE SET
                    agent_name = excluded.agent_name,
                    session_kind = excluded.session_kind,
                    token_id = excluded.token_id,
                    process_id = excluded.process_id,
                    host_id = excluded.host_id,
                    metadata = excluded.metadata,
                    lease_expires_at = excluded.lease_expires_at,
                    last_seen_at = CURRENT_TIMESTAMP
                """,
                (
                    session_id,
                    agent_name,
                    session_kind,
                    token_id,
                    process_id,
                    host_id,
                    json.dumps(metadata) if metadata is not None else None,
                    f"+{int(lease_seconds)} seconds",
                ),
            )
            self._ensure_runtime_state_row(conn, agent_name, session_id)
            if substantive:
                conn.execute(
                    """
                    UPDATE presence
                    SET status = 'online',
                        session_id = ?,
                        heartbeat_at = CURRENT_TIMESTAMP,
                        last_active = CURRENT_TIMESTAMP
                    WHERE agent_name = ?
                    """,
                    (session_id, agent_name),
                )
            else:
                conn.execute(
                    """
                    UPDATE presence
                    SET status = 'online',
                        session_id = ?,
                        heartbeat_at = CURRENT_TIMESTAMP
                    WHERE agent_name = ?
                    """,
                    (session_id, agent_name),
                )
            conn.execute(
                """
                UPDATE agent_cards
                SET last_seen = CURRENT_TIMESTAMP
                WHERE callsign = ? AND deregistered_at IS NULL
                """,
                (agent_name,),
            )
            conn.commit()
    def set_readiness_state(
        self,
        agent_name: str,
        session_id: str,
        *,
        readiness: str,
        current_task: Optional[str] = None,
        attention_state: Any = _RUNTIME_FIELD_UNSET,
        attention_detail: Any = _RUNTIME_FIELD_UNSET,
        basis: Optional[str] = None,
        evidence_refs: Optional[str] = None,
    ) -> Dict[str, Any]:
        normalized = (readiness or "").strip().lower()
        if normalized not in VALID_READINESS_STATES:
            raise WhispersDBError(
                f"Invalid readiness state '{readiness}'. Expected one of: {', '.join(sorted(VALID_READINESS_STATES))}."
            )

        with self._db_op("Readiness update") as conn:
            session = conn.execute(
                """
                SELECT session_id, agent_name
                FROM agent_sessions
                WHERE session_id = ?
                  AND agent_name = ?
                """,
                (session_id, agent_name),
            ).fetchone()
            if not session:
                raise WhispersDBError(f"Session {session_id} is not active for {agent_name}.")

            self._ensure_runtime_state_row(conn, agent_name, session_id)
            clear_ready_task_context = normalized == DEFAULT_READINESS_STATE and current_task is None
            updates = [
                "agent_name = ?",
                "readiness = ?",
                "updated_at = CURRENT_TIMESTAMP",
            ]
            params: List[Any] = [agent_name, normalized]

            if clear_ready_task_context:
                updates.append("current_task = NULL")
            else:
                updates.append("current_task = COALESCE(?, current_task)")
                params.append(current_task)

            if attention_state is not _RUNTIME_FIELD_UNSET:
                updates.append("attention_state = ?")
                params.append(_normalize_attention_state(attention_state))
                if attention_detail is _RUNTIME_FIELD_UNSET:
                    updates.append("attention_detail = NULL")
            elif clear_ready_task_context:
                updates.append("attention_state = NULL")
                if attention_detail is _RUNTIME_FIELD_UNSET:
                    updates.append("attention_detail = NULL")
            if attention_detail is not _RUNTIME_FIELD_UNSET:
                updates.append("attention_detail = ?")
                params.append(_normalize_optional_text(attention_detail))

            if basis is not None:
                updates.append("basis = ?")
                params.append(basis)

            if evidence_refs is not None:
                updates.append("evidence_refs = ?")
                params.append(evidence_refs)

            params.append(session_id)
            conn.execute(
                f"""
                UPDATE agent_runtime_state
                SET {", ".join(updates)}
                WHERE session_id = ?
                """,
                params,
            )
            conn.commit()
            return self.get_runtime_state(agent_name, session_id=session_id, conn=conn)
    def get_runtime_state(
        self,
        agent_name: str,
        *,
        session_id: Optional[str] = None,
        conn: Optional[sqlite3.Connection] = None,
    ) -> Dict[str, Any]:
        owns_conn = conn is None
        conn = conn or self.get_connection()
        try:
            if session_id:
                row = conn.execute(
                    """
                    SELECT session_id, agent_name, readiness, interruptibility, context_load, quality_risk,
                           current_task, progress_summary, last_progress_at, watchdog_state, working_set_json,
                           attention_state, attention_detail, updated_at, basis, evidence_refs
                    FROM agent_runtime_state
                    WHERE agent_name = ? AND session_id = ?
                    """,
                    (agent_name, session_id),
                ).fetchone()
            else:
                row = conn.execute(
                    """
                    SELECT ars.session_id, ars.agent_name, ars.readiness, ars.interruptibility, ars.context_load,
                           ars.quality_risk, ars.current_task, ars.progress_summary, ars.last_progress_at,
                           ars.watchdog_state, ars.working_set_json, ars.attention_state, ars.attention_detail,
                           ars.updated_at, ars.basis
                    FROM agent_runtime_state ars
                    JOIN agent_sessions s ON s.session_id = ars.session_id
                    WHERE ars.agent_name = ?
                      AND s.lease_expires_at >= CURRENT_TIMESTAMP
                    ORDER BY s.last_seen_at DESC, s.created_at DESC
                    LIMIT 1
                    """,
                    (agent_name,),
                ).fetchone()

            if not row:
                return {
                    "agent_name": agent_name,
                    "session_id": session_id,
                    "readiness": DEFAULT_READINESS_STATE,
                }

            payload = dict(row)
            working_set_json = payload.get("working_set_json")
            if working_set_json:
                with contextlib.suppress(Exception):
                    payload["working_set"] = json.loads(working_set_json)
            payload.pop("working_set_json", None)
            return payload
        except sqlite3.Error as e:
            raise WhispersDBError(f"Runtime state lookup failed: {str(e)}")

    def get_presence_policy(
        self,
        agent_name: str,
        *,
        conn: Optional[sqlite3.Connection] = None,
    ) -> Dict[str, Any]:
        owns_conn = conn is None
        conn = conn or self.get_connection()
        try:
            row = conn.execute(
                """
                SELECT agent_name, visibility_posture, state_detail_visibility, reachability,
                       notification_policy, idle_mode, idle_timeout_seconds, updated_at
                FROM presence_policy
                WHERE agent_name = ?
                """,
                (agent_name,),
            ).fetchone()
            if not row:
                return default_presence_policy(agent_name=agent_name)

            payload = dict(row)
            base_policy = normalize_presence_policy(
                {
                    "visibility_posture": payload.get("visibility_posture"),
                    "state_detail_visibility": payload.get("state_detail_visibility"),
                    "reachability": payload.get("reachability"),
                    "notification_policy": payload.get("notification_policy"),
                    "idle_policy": {
                        "mode": payload.get("idle_mode"),
                        "timeout_seconds": payload.get("idle_timeout_seconds"),
                    },
                },
                agent_name=agent_name,
                updated_at=payload.get("updated_at"),
            )
            
            # Layer RAM overrides on top of the base persisted policy
            from whispers.presence_policy import get_session_override
            override = get_session_override(agent_name)
            if override:
                return normalize_presence_policy(
                    override, base=base_policy, agent_name=agent_name
                )
            
            return base_policy
        except (sqlite3.Error, ValueError) as e:
            raise WhispersDBError(f"Presence policy lookup failed: {str(e)}")
        finally:
            if owns_conn:
                conn.close()

    def get_autonomy_policy(
        self,
        agent_name: str,
        working_scope: str,
        *,
        conn: Optional[sqlite3.Connection] = None,
    ) -> Optional[Dict[str, Any]]:
        owns_conn = conn is None
        conn = conn or self.get_connection()
        try:
            row = conn.execute(
                """
                SELECT p.working_scope, p.can_summarize, p.can_classify, p.can_reply, p.can_external_action, p.shadow_mode
                FROM autonomy_policies p
                JOIN agent_cards ac ON ac.agent_id = p.agent_id
                WHERE ac.callsign = ? AND p.working_scope = ?
                """,
                (agent_name, working_scope),
            ).fetchone()
            if row:
                return dict(row)
            return None
        finally:
            if owns_conn:
                conn.close()

    def has_any_autonomy_policy(
        self,
        agent_name: str,
        *,
        conn: Optional[sqlite3.Connection] = None,
    ) -> bool:
        """Return True if the agent has any scoped autonomy policy."""
        owns_conn = conn is None
        conn = conn or self.get_connection()
        try:
            row = conn.execute(
                """
                SELECT 1
                FROM autonomy_policies p
                JOIN agent_cards ac ON ac.agent_id = p.agent_id
                WHERE ac.callsign = ?
                LIMIT 1
                """,
                (agent_name,),
            ).fetchone()
            return row is not None
        finally:
            if owns_conn:
                conn.close()

    def set_autonomy_policy(
        self,
        agent_name: str,
        working_scope: str,
        policy: Dict[str, bool],
    ) -> Dict[str, Any]:
        with self._db_op("Set autonomy policy") as conn:
            agent = self.get_agent_card(agent_name, conn=conn)
            if not agent:
                raise WhispersDBError(f"Agent {agent_name} not found.")
            
            conn.execute(
                """
                INSERT INTO autonomy_policies (
                    agent_id, working_scope, can_summarize, can_classify, can_reply, can_external_action, shadow_mode
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(agent_id, working_scope) DO UPDATE SET
                    can_summarize = excluded.can_summarize,
                    can_classify = excluded.can_classify,
                    can_reply = excluded.can_reply,
                    can_external_action = excluded.can_external_action,
                    shadow_mode = excluded.shadow_mode
                """,
                (
                    agent["agent_id"],
                    working_scope,
                    policy.get("can_summarize", False),
                    policy.get("can_classify", False),
                    policy.get("can_reply", False),
                    policy.get("can_external_action", False),
                    policy.get("shadow_mode", False),
                ),
            )
            conn.commit()
            return self.get_autonomy_policy(agent_name, working_scope, conn=conn)

    def set_presence_policy(
        self,
        agent_name: str,
        policy: Dict[str, Any],
    ) -> Dict[str, Any]:
        with self._db_op("Presence policy update") as conn:
            current = self.get_presence_policy(agent_name, conn=conn)
            try:
                normalized = normalize_presence_policy(policy, base=current, agent_name=agent_name)
            except ValueError as exc:
                raise WhispersDBError(str(exc)) from exc

            idle_policy = normalized["idle_policy"]
            conn.execute(
                """
                INSERT INTO presence_policy (
                    agent_name,
                    visibility_posture,
                    state_detail_visibility,
                    reachability,
                    notification_policy,
                    idle_mode,
                    idle_timeout_seconds,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(agent_name) DO UPDATE SET
                    visibility_posture = excluded.visibility_posture,
                    state_detail_visibility = excluded.state_detail_visibility,
                    reachability = excluded.reachability,
                    notification_policy = excluded.notification_policy,
                    idle_mode = excluded.idle_mode,
                    idle_timeout_seconds = excluded.idle_timeout_seconds,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (
                    agent_name,
                    normalized["visibility_posture"],
                    normalized["state_detail_visibility"],
                    normalized["reachability"],
                    normalized["notification_policy"],
                    idle_policy["mode"],
                    idle_policy["timeout_seconds"],
                ),
            )
            conn.commit()
            return self.get_presence_policy(agent_name, conn=conn)

    def update_watchdog_state(self, agent_name: str, session_id: str, state: str) -> Dict[str, Any]:
        with self._db_op("Watchdog update") as conn:

            self._ensure_runtime_state_row(conn, agent_name, session_id)
            conn.execute(
                """
                UPDATE agent_runtime_state
                SET watchdog_state = ?, updated_at = CURRENT_TIMESTAMP
                WHERE session_id = ? AND agent_name = ?
                """,
                (state, session_id, agent_name)
            )
            conn.commit()
            return self.get_runtime_state(agent_name, session_id=session_id, conn=conn)
    def update_cognitive_heartbeat(
        self,
        agent_name: str,
        session_id: str,
        heartbeat: Dict[str, Any],
    ) -> Dict[str, Any]:
        # Note: Volatile memory tracking is handled by server.py /heartbeat.
        # This db layer function now primarily acts as a lightweight lease touch
        # for local/standalone usages without creating massive SQLite write amplification.
        
        with self._db_op("Cognitive heartbeat update") as conn:

            session = conn.execute(
                """
                SELECT session_id, agent_name
                FROM agent_sessions
                WHERE session_id = ?
                  AND agent_name = ?
                """,
                (session_id, agent_name),
            ).fetchone()
            if not session:
                raise WhispersDBError(f"Session {session_id} is not active for {agent_name}.")

            self._ensure_runtime_state_row(conn, agent_name, session_id)
            progress_summary = (
                _normalize_optional_text(heartbeat.get("progress_summary"))
                if "progress_summary" in heartbeat
                else _RUNTIME_FIELD_UNSET
            )
            last_progress_at = (
                _normalize_optional_text(heartbeat.get("last_progress_at"))
                if "last_progress_at" in heartbeat
                else _RUNTIME_FIELD_UNSET
            )
            attention_state = (
                _normalize_attention_state(heartbeat.get("attention_state"))
                if "attention_state" in heartbeat
                else _RUNTIME_FIELD_UNSET
            )
            attention_detail = (
                _normalize_optional_text(heartbeat.get("attention_detail"))
                if "attention_detail" in heartbeat
                else _RUNTIME_FIELD_UNSET
            )

            updates = [
                "agent_name = ?",
                "current_task = COALESCE(?, current_task)",
                "watchdog_state = COALESCE(?, watchdog_state)",
                "updated_at = CURRENT_TIMESTAMP",
            ]
            params: List[Any] = [
                agent_name,
                heartbeat.get("current_task"),
                heartbeat.get("watchdog_state"),
            ]

            if progress_summary is not _RUNTIME_FIELD_UNSET:
                updates.append("progress_summary = ?")
                params.append(progress_summary)
                if last_progress_at is _RUNTIME_FIELD_UNSET and progress_summary is not None:
                    updates.append("last_progress_at = CURRENT_TIMESTAMP")
            if last_progress_at is not _RUNTIME_FIELD_UNSET:
                updates.append("last_progress_at = ?")
                params.append(last_progress_at)
            if attention_state is not _RUNTIME_FIELD_UNSET:
                updates.append("attention_state = ?")
                params.append(attention_state)
                if attention_detail is _RUNTIME_FIELD_UNSET:
                    updates.append("attention_detail = NULL")
            if attention_detail is not _RUNTIME_FIELD_UNSET:
                updates.append("attention_detail = ?")
                params.append(attention_detail)

            basis = heartbeat.get("basis")
            if basis is not None:
                updates.append("basis = ?")
                params.append(basis)

            evidence_refs = heartbeat.get("evidence_refs")
            if evidence_refs is not None:
                updates.append("evidence_refs = ?")
                params.append(json.dumps(evidence_refs) if isinstance(evidence_refs, (list, dict)) else evidence_refs)

            params.append(session_id)
            conn.execute(
                f"""
                UPDATE agent_runtime_state
                SET {", ".join(updates)}
                WHERE session_id = ?
                """,
                params,
            )

            # Maintain the presence lease timestamp so standalone wagers don't drop offline
            conn.execute(
                "UPDATE presence SET last_active = CURRENT_TIMESTAMP WHERE session_id = ?",
                (session_id,)
            )
            conn.commit()
            return self.get_runtime_state(agent_name, session_id=session_id, conn=conn)
    # Freshness thresholds for layered truth derivation
    _HEARTBEAT_FRESH_SECONDS = 120      # Within this: heartbeat is fresh
    _HEARTBEAT_STALE_SECONDS = 300      # Beyond this: heartbeat is stale
    _MANUAL_WAKE_STALE_MULTIPLIER = 3   # Manual-wake agents get 3x grace period

    def get_freshness_posture(
        self,
        agent_name: str,
        *,
        conn: Optional[sqlite3.Connection] = None,
        ephemeral_state: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Compute the freshness posture for an agent's runtime state.

        Returns a dict with:
        - posture: normal | stale | suspicious | degraded
        - heartbeat_age_seconds: seconds since last heartbeat (None if never)
        - activity_age_seconds: seconds since last substantive activity (None if never)
        - basis: what the posture is derived from
        """
        owns_conn = conn is None
        conn = conn or self.get_connection()
        ephemeral = ephemeral_state or {}
        try:
            presence = conn.execute(
                "SELECT heartbeat_at, last_active FROM presence WHERE agent_name = ?",
                (agent_name,),
            ).fetchone()
            if not presence:
                return {"posture": "degraded", "heartbeat_age_seconds": None,
                        "activity_age_seconds": None, "basis": "derived"}

            heartbeat_age = None
            activity_age = None

            if presence["heartbeat_at"]:
                hb_ts = parse_timestamp(presence["heartbeat_at"])
                if hb_ts:
                    heartbeat_age = (utc_now() - hb_ts).total_seconds()
            if presence["last_active"]:
                la_ts = parse_timestamp(presence["last_active"])
                if la_ts:
                    activity_age = (utc_now() - la_ts).total_seconds()

            # Check ephemeral state_updated_at (volatile wag timestamp)
            ephemeral_updated = ephemeral.get("state_updated_at")
            if ephemeral_updated and isinstance(ephemeral_updated, (int, float)):
                import time
                ephemeral_age = time.time() - ephemeral_updated
                if heartbeat_age is None or ephemeral_age < heartbeat_age:
                    heartbeat_age = ephemeral_age

            # Determine wake model for threshold adjustment
            wake_model = "manual_wake"
            try:
                card = conn.execute(
                    "SELECT * FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
                    (agent_name,),
                ).fetchone()
                if card and "wake_model" in card.keys() and card["wake_model"]:
                    wake_model = str(card["wake_model"]).strip().lower()
            except Exception:
                pass
            multiplier = self._MANUAL_WAKE_STALE_MULTIPLIER if wake_model == "manual_wake" else 1

            fresh_threshold = self._HEARTBEAT_FRESH_SECONDS * multiplier
            stale_threshold = self._HEARTBEAT_STALE_SECONDS * multiplier

            runtime = self.get_runtime_state(agent_name, conn=conn)
            readiness = ephemeral.get("readiness") or runtime.get("readiness", DEFAULT_READINESS_STATE)

            if heartbeat_age is None:
                posture = "degraded"
            elif heartbeat_age <= fresh_threshold:
                posture = "normal"
            elif heartbeat_age <= stale_threshold:
                posture = "stale"
            else:
                # Very stale — but if readiness claims "ready", that's suspicious
                if readiness == DEFAULT_READINESS_STATE:
                    posture = "suspicious"
                else:
                    posture = "stale"

            return {
                "posture": posture,
                "heartbeat_age_seconds": round(heartbeat_age) if heartbeat_age is not None else None,
                "activity_age_seconds": round(activity_age) if activity_age is not None else None,
                "basis": "derived",
                "wake_model": wake_model,
                "fresh_threshold": fresh_threshold,
                "stale_threshold": stale_threshold,
            }
        finally:
            if owns_conn:
                conn.close()

    def get_derived_active_mode(
        self,
        agent_name: str,
        *,
        conn: Optional[sqlite3.Connection] = None,
        ephemeral_state: Optional[Dict[str, Any]] = None,
    ) -> str:
        owns_conn = conn is None
        conn = conn or self.get_connection()
        ephemeral = ephemeral_state or {}
        try:
            if not self.agent_has_active_session(agent_name, conn=conn):
                return "offline"

            runtime = self.get_runtime_state(agent_name, conn=conn)
            readiness = ephemeral.get("readiness") or runtime.get("readiness", DEFAULT_READINESS_STATE)
            context_load = ephemeral.get("context_load") if ephemeral.get("context_load") is not None else runtime.get("context_load")
            quality_risk = ephemeral.get("quality_risk") or runtime.get("quality_risk")

            # Explicit degradation signals always win
            if quality_risk == "high" or runtime.get("watchdog_state") == "degraded":
                return "degraded"
            if readiness == "paused_by_operator":
                return "blocked"

            # Freshness check applies to ALL readiness states, not just "ready".
            # A "busy" agent that hasn't heartbeated in 10 minutes may be crashed.
            freshness = self.get_freshness_posture(agent_name, conn=conn, ephemeral_state=ephemeral)
            posture = freshness["posture"]

            # Stale heartbeat + high context load = escalate to degraded.
            # If an agent last reported 85% load 10 minutes ago, it's likely worse.
            if posture in ("stale", "suspicious") and isinstance(context_load, (int, float)) and context_load >= 0.7:
                return "degraded"

            # Fresh but overloaded
            if isinstance(context_load, (int, float)) and context_load >= 0.9:
                return "overloaded"

            # Readiness passthrough for non-ready states
            if readiness in {"busy", "blocked", "warming", "degraded"}:
                # If busy/blocked but heartbeat is suspicious, they may be
                # unresponsive rather than actively working
                if posture == "suspicious":
                    return "stale"
                return readiness

            # Ready agent: freshness determines confidence
            if posture == "suspicious":
                return "stale"
            if posture == "degraded":
                return "degraded"

            return "ready"
        finally:
            if owns_conn:
                conn.close()

    def get_team_snapshot(
        self,
        agent_name: str,
        *,
        conn: Optional[sqlite3.Connection] = None,
        ephemeral_snapshots: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Return a compact team snapshot for ambient awareness.

        Included in every heartbeat response so agents always know:
        - Who else is online and what they're doing
        - How many unread messages are pending (including flash count)

        Designed to be small and fast — no full message content, just
        enough for routing and awareness decisions.
        """
        owns_conn = conn is None
        conn = conn or self.get_connection()
        ephemeral = ephemeral_snapshots or {}
        try:
            # Compact peer list: online agents with state + task
            peers_raw = conn.execute(
                """
                SELECT p.agent_name,
                       p.reception_mode,
                       p.working_on,
                       ars.readiness,
                       ars.current_task,
                       ars.interruptibility,
                       ars.context_load,
                       ars.basis,
                       ars.updated_at,
                       ars.evidence_refs
                FROM presence p
                JOIN agent_sessions s ON s.agent_name = p.agent_name
                    AND s.lease_expires_at >= CURRENT_TIMESTAMP
                LEFT JOIN agent_runtime_state ars ON ars.agent_name = p.agent_name
                    AND ars.session_id = s.session_id
                LEFT JOIN agent_cards ac ON ac.callsign = p.agent_name
                    AND ac.deregistered_at IS NULL
                WHERE p.agent_name != ?
                  AND COALESCE(ac.agent_type, 'script') != 'infrastructure'
                GROUP BY p.agent_name
                ORDER BY p.last_active DESC
                """,
                (agent_name,),
            ).fetchall()

            team = []
            for row in peers_raw:
                peer_name = row["agent_name"]
                peer_ephemeral = ephemeral.get(peer_name, {})
                peer = {"agent": peer_name}
                
                readiness = peer_ephemeral.get("readiness") or row["readiness"]
                if readiness:
                    peer["readiness"] = readiness
                
                current_task = peer_ephemeral.get("current_task") or row["current_task"]
                task = current_task or row["working_on"]
                if task:
                    peer["task"] = task
                    
                interruptibility = peer_ephemeral.get("interruptibility") or row["interruptibility"]
                if interruptibility:
                    peer["interruptibility"] = interruptibility
                    
                context_load = peer_ephemeral.get("context_load") if peer_ephemeral.get("context_load") is not None else row["context_load"]
                if context_load is not None:
                    peer["context_load"] = context_load
                    
                mode = row["reception_mode"]
                if mode and mode != "open":
                    peer["mode"] = mode.upper()

                basis = peer_ephemeral.get("basis") or row["basis"]
                if basis:
                    peer["basis"] = basis

                updated_at = row["updated_at"]
                if updated_at:
                    peer["updated_at"] = updated_at

                evidence = row["evidence_refs"]
                if evidence:
                    peer["evidence_refs"] = evidence

                team.append(peer)

            # Pending message counts for this agent
            pending_total = 0
            pending_flash = 0
            try:
                row = conn.execute(
                    """
                    SELECT COUNT(m.rowid) as cnt
                    FROM messages m
                    JOIN message_recipients r ON m.uuid = r.message_uuid
                    WHERE r.recipient_callsign = ?
                      AND m.status = 'new'
                      AND r.delivery_status IN ('queued', 'unclaimed')
                    """,
                    (agent_name,),
                ).fetchone()
                if row:
                    pending_total = row["cnt"]

                row = conn.execute(
                    """
                    SELECT COUNT(m.rowid) as cnt
                    FROM messages m
                    JOIN message_recipients r ON m.uuid = r.message_uuid
                    WHERE r.recipient_callsign = ?
                      AND m.status = 'new'
                      AND r.delivery_status IN ('queued', 'unclaimed')
                      AND m.priority = 'flash'
                    """,
                    (agent_name,),
                ).fetchone()
                if row:
                    pending_flash = row["cnt"]
            except sqlite3.Error:
                pass  # Non-critical — snapshot still useful without counts

            snapshot: Dict[str, Any] = {
                "team": team,
                "pending_messages": pending_total,
            }
            if pending_flash > 0:
                snapshot["pending_flash"] = pending_flash

            return snapshot
        except sqlite3.Error as e:
            # Team snapshot is non-critical — return empty on error
            logger.warning("Team snapshot query failed: %s", e)
            return {"team": [], "pending_messages": 0}
        finally:
            if owns_conn:
                conn.close()

    def revoke_agent_session(self, session_id: str) -> int:
        with self._db_op("Agent session revoke") as conn:
            row = conn.execute(
                "SELECT agent_name FROM agent_sessions WHERE session_id = ?",
                (session_id,),
            ).fetchone()
            if not row:
                return 0
            conn.execute("DELETE FROM agent_runtime_state WHERE session_id = ?", (session_id,))
            conn.execute("DELETE FROM agent_sessions WHERE session_id = ?", (session_id,))
            self._sync_presence_from_sessions(conn, row["agent_name"])
            if not self.agent_has_active_session(row["agent_name"], conn=conn):
                self.release_file_leases(row["agent_name"], conn=conn)
            conn.commit()
            return 1
    def revoke_agent_sessions(
        self,
        agent_name: str,
        *,
        session_kind: Optional[str] = None,
        process_id: Optional[int] = None,
    ) -> int:
        clauses = ["agent_name = ?"]
        params: List[Any] = [agent_name]
        if session_kind:
            clauses.append("session_kind = ?")
            params.append(session_kind)
        if process_id is not None:
            clauses.append("process_id = ?")
            params.append(int(process_id))

        where_clause = " AND ".join(clauses)
        with self._db_op("Agent session revoke") as conn:
            rows = conn.execute(
                f"SELECT session_id FROM agent_sessions WHERE {where_clause}",
                params,
            ).fetchall()
            if not rows:
                return 0
            conn.executemany(
                "DELETE FROM agent_runtime_state WHERE session_id = ?",
                [(row["session_id"],) for row in rows],
            )
            conn.execute(
                f"DELETE FROM agent_sessions WHERE {where_clause}",
                params,
            )
            self._sync_presence_from_sessions(conn, agent_name)
            if not self.agent_has_active_session(agent_name, conn=conn):
                self.release_file_leases(agent_name, conn=conn)
            conn.commit()
            return len(rows)
    def agent_has_active_session(self, agent_name: str, *, conn: Optional[sqlite3.Connection] = None) -> bool:
        owns_conn = conn is None
        conn = conn or self.get_connection()
        try:

            row = conn.execute(
                """
                SELECT 1
                FROM agent_sessions
                WHERE agent_name = ?
                  AND lease_expires_at >= CURRENT_TIMESTAMP
                LIMIT 1
                """,
                (agent_name,),
            ).fetchone()
            return bool(row)
        except sqlite3.Error as e:
            raise WhispersDBError(f"Agent session lookup failed: {str(e)}")
        finally:
            if owns_conn:
                conn.close()

    def reap_expired_agent_sessions(self) -> int:
        with self._db_op("Expired agent session sweep") as conn:

            expired = conn.execute(
                """
                SELECT session_id, agent_name
                FROM agent_sessions
                WHERE lease_expires_at < CURRENT_TIMESTAMP
                """
            ).fetchall()
            if not expired:
                return 0
            conn.executemany(
                "DELETE FROM agent_runtime_state WHERE session_id = ?",
                [(row["session_id"],) for row in expired],
            )
            conn.execute("DELETE FROM agent_sessions WHERE lease_expires_at < CURRENT_TIMESTAMP")
            for row in {entry["agent_name"] for entry in expired}:
                self._sync_presence_from_sessions(conn, row)
                if not self.agent_has_active_session(row, conn=conn):
                    self.release_file_leases(row, conn=conn)
            conn.commit()
            return len(expired)
    def create_remote_session(
        self,
        agent_name: str,
        token: str,
        session_kind: str = "remote_http",
        client_name: Optional[str] = None,
        client_version: Optional[str] = None,
        capabilities: Optional[Dict[str, Any]] = None,
        lease_seconds: int = 300,
        remote_addr: Optional[str] = None,
    ) -> Dict[str, Any]:
        token_row = self.get_api_token(token)
        if not token_row:
            raise WhispersDBError("Cannot create remote session without a valid token.")

        session_id = str(uuid.uuid4())
        with self._db_op("Remote session creation") as conn:
            conn.execute(
                "DELETE FROM agent_sessions WHERE agent_name = ? AND token_id IS NOT NULL",
                (agent_name,),
            )
            conn.commit()
        self.mark_token_used(token)
        self.upsert_agent_session(
            agent_name,
            session_id,
            session_kind=session_kind,
            lease_seconds=lease_seconds,
            token_id=token_row["token_id"],
            metadata={
                "client_name": client_name,
                "client_version": client_version,
                "capabilities": capabilities or {},
                "remote_addr": remote_addr,
            },
            substantive=True,
        )
        return self.get_active_remote_session(token) or {}

    def renew_remote_session(self, token: str, session_id: str, lease_seconds: int = 300) -> Optional[Dict[str, Any]]:
        token_row = self.get_api_token(token)
        if not token_row:
            return None

        with self._db_op("Remote session renewal") as conn:
            row = conn.execute(
                "SELECT agent_name, metadata, session_kind FROM agent_sessions WHERE session_id = ? AND token_id = ?",
                (session_id, token_row["token_id"]),
            ).fetchone()
            if not row:
                return None
        self.mark_token_used(token)
        meta = {}
        if row["metadata"]:
            with contextlib.suppress(Exception):
                meta = json.loads(row["metadata"])
                
        self.upsert_agent_session(
            row["agent_name"],
            session_id,
            session_kind=row["session_kind"],
            lease_seconds=lease_seconds,
            token_id=token_row["token_id"],
            metadata=meta,
        )
        return self.get_active_remote_session(token)

    def get_active_remote_session(self, token: str) -> Optional[Dict[str, Any]]:
        token_row = self.get_api_token(token)
        if not token_row:
            return None

        with self._db_op("Active remote session lookup") as conn:
            row = conn.execute(
                f"""
                SELECT session_id, agent_name, token_id, session_kind, lease_expires_at, last_seen_at, metadata
                FROM agent_sessions
                WHERE token_id = ?
                  AND session_kind IN ({REMOTE_SESSION_KINDS_SQL})
                  AND lease_expires_at >= CURRENT_TIMESTAMP
                ORDER BY last_seen_at DESC
                LIMIT 1
                """,
                (token_row["token_id"],),
            ).fetchone()
            if not row:
                return None

            result = dict(row)
            if result.get("metadata"):
                with contextlib.suppress(Exception):
                    meta = json.loads(result.pop("metadata"))
                    result.update(meta)
            return result
    def touch_remote_session(self, token: str) -> Optional[Dict[str, Any]]:
        session = self.get_active_remote_session(token)
        if not session:
            return None

        self.mark_token_used(token)
        self.upsert_agent_session(
            session["agent_name"],
            session["session_id"],
            session_kind=session["session_kind"],
            lease_seconds=_default_remote_session_lease_seconds(),
            token_id=session.get("token_id"),
            metadata={
                "client_name": session.get("client_name"),
                "client_version": session.get("client_version"),
                "capabilities": session.get("capabilities", {}),
                "remote_addr": session.get("remote_addr"),
            },
        )
        return self.get_active_remote_session(token)

    def disconnect_remote_session(self, token: str, session_id: Optional[str] = None) -> int:
        token_row = self.get_api_token(token)
        if not token_row:
            return 0

        with self._db_op("Remote disconnect") as conn:
            if session_id:
                sessions = conn.execute(
                    "SELECT session_id, agent_name FROM agent_sessions WHERE token_id = ? AND session_id = ?",
                    (token_row["token_id"], session_id),
                ).fetchall()
            else:
                sessions = conn.execute(
                    "SELECT session_id, agent_name FROM agent_sessions WHERE token_id = ?",
                    (token_row["token_id"],),
                ).fetchall()

            if not sessions:
                return 0

            if session_id:
                if self.has_table("agent_runtime_state", conn=conn):
                    conn.execute(
                        "DELETE FROM agent_runtime_state WHERE session_id = ?",
                        (session_id,),
                    )
                conn.execute(
                    "DELETE FROM agent_sessions WHERE token_id = ? AND session_id = ?",
                    (token_row["token_id"], session_id),
                )
            else:
                conn.execute(
                    "DELETE FROM agent_runtime_state WHERE session_id IN (SELECT session_id FROM agent_sessions WHERE token_id = ?)",
                    (token_row["token_id"],),
                )
                conn.execute("DELETE FROM agent_sessions WHERE token_id = ?", (token_row["token_id"],))
            for session in sessions:
                self._sync_presence_from_sessions(conn, session["agent_name"])
                if not self.agent_has_active_session(session["agent_name"], conn=conn):
                    self.release_file_leases(session["agent_name"], conn=conn)
            conn.commit()
            return len(sessions)
    def reap_expired_remote_sessions(self) -> int:
        """Expire remote leases and clear matching presence state."""
        with self._db_op("Reaping") as conn:
            expired = conn.execute(
                """
                SELECT session_id, agent_name
                FROM agent_sessions
                WHERE token_id IS NOT NULL
                  AND lease_expires_at < CURRENT_TIMESTAMP
                """
            ).fetchall()
            if not expired:
                return 0

            conn.execute(
                """
                DELETE FROM agent_runtime_state
                WHERE session_id IN (
                    SELECT session_id
                    FROM agent_sessions
                    WHERE token_id IS NOT NULL
                      AND lease_expires_at < CURRENT_TIMESTAMP
                )
                """
            )
            conn.execute(
                """
                DELETE FROM agent_sessions
                WHERE token_id IS NOT NULL
                  AND lease_expires_at < CURRENT_TIMESTAMP
                """
            )
            for session in expired:
                self._sync_presence_from_sessions(conn, session["agent_name"])
                if not self.agent_has_active_session(session["agent_name"], conn=conn):
                    self.release_file_leases(session["agent_name"], conn=conn)
            conn.commit()
            return len(expired)
    def get_message_by_uuid(self, message_uuid: str) -> Optional[Dict[str, Any]]:
        with self.get_readonly_connection() as conn:
            row = conn.execute(
                "SELECT uuid, from_agent, to_agent, payload, metadata, msg_type, reply_to FROM messages WHERE uuid = ?",
                (message_uuid,),
            ).fetchone()
            return dict(row) if row else None

    def get_message_by_idempotency(self, agent_name: str, idempotency_key: str) -> Optional[Dict[str, Any]]:
        with self._db_op("Idempotency lookup") as conn:
            row = conn.execute(
                """
                SELECT uuid, from_agent, to_agent, delivery_status, created_at
                FROM messages
                WHERE from_agent = ? AND idempotency_key = ?
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (agent_name, idempotency_key),
            ).fetchone()
            return dict(row) if row else None
    def record_security_event(
        self,
        event_type: str,
        outcome: str,
        *,
        actor_agent: Optional[str] = None,
        target_agent: Optional[str] = None,
        endpoint: Optional[str] = None,
        detail: Optional[Dict[str, Any] | str] = None,
    ) -> str:
        event_id = str(uuid.uuid4())
        detail_text = detail if isinstance(detail, str) or detail is None else json.dumps(detail, sort_keys=True)
        with self._db_op("Security event write") as conn:
            conn.execute(
                """
                INSERT INTO security_events (
                    event_id, event_type, outcome, actor_agent, target_agent, endpoint, detail
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (event_id, event_type, outcome, actor_agent, target_agent, endpoint, detail_text),
            )
            conn.commit()
        return event_id

    def get_workspace_handoff_boundary_violation(
        self,
        envelope: Envelope,
        *,
        conn: Optional[sqlite3.Connection] = None,
    ) -> Optional[Dict[str, Any]]:
        owns_conn = conn is None
        active_conn = conn or self.get_connection()
        try:
            cursor = active_conn.cursor()
            return _workspace_handoff_scope_boundary_violation(cursor, envelope)
        finally:
            if owns_conn:
                active_conn.close()

    def inspect_operator_override(
        self,
        envelope: Envelope,
    ) -> Optional[Dict[str, Any]]:
        return _operator_override_inspection(envelope)

    def inspect_baton_scope_transition(
        self,
        envelope: Envelope,
        *,
        conn: Optional[sqlite3.Connection] = None,
    ) -> Optional[Dict[str, Any]]:
        owns_conn = conn is None
        active_conn = conn or self.get_connection()
        try:
            return _baton_scope_transition_inspection(active_conn.cursor(), envelope)
        finally:
            if owns_conn:
                active_conn.close()

    def get_baton_scope(self, baton_ref: str) -> Optional[str]:
        with self.get_readonly_connection() as conn:
            row = conn.execute(
                "SELECT working_scope FROM baton_projections WHERE baton_ref = ?",
                (baton_ref,),
            ).fetchone()
            if not row:
                return None
            return _normalize_optional_text(row["working_scope"])

    # ------------------------------------------------------------------
    # Blob provenance (security item #7)
    # ------------------------------------------------------------------

    def record_blob_provenance(
        self,
        blob_ref: str,
        stored_by: str,
        workspace_id: Optional[str] = None,
    ) -> None:
        """Record who stored a blob and which workspace it belongs to."""
        with self._db_op("Record blob provenance") as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO blob_provenance (blob_ref, stored_by, workspace_id)
                VALUES (?, ?, ?)
                """,
                (blob_ref, stored_by, workspace_id),
            )
            conn.commit()

    def get_blob_provenance(self, blob_ref: str) -> Optional[Dict[str, Any]]:
        """Return provenance for a blob, or None if unknown."""
        with self.get_readonly_connection() as conn:
            row = conn.execute(
                "SELECT blob_ref, stored_by, workspace_id, created_at FROM blob_provenance WHERE blob_ref = ?",
                (blob_ref,),
            ).fetchone()
            return dict(row) if row else None

    def is_agent_workspace_member(self, agent_name: str, workspace_id: str) -> bool:
        """Check if an agent is an active member of a workspace."""
        with self.get_readonly_connection() as conn:
            row = conn.execute(
                """
                SELECT 1 FROM workspace_members
                WHERE workspace_id = ? AND agent_name = ? AND membership_state = 'active'
                """,
                (workspace_id, agent_name),
            ).fetchone()
            return row is not None

    # ------------------------------------------------------------------
    # Process Runs — shared task tracking
    # ------------------------------------------------------------------

    VALID_RUN_STATUSES = {"active", "paused", "completed", "cancelled"}
    VALID_TASK_STATUSES = {"pending", "assigned", "in_progress", "blocked", "completed", "cancelled"}

    def create_process_run(
        self,
        name: str,
        created_by: str,
        workspace_id: str,
        purpose: Optional[str] = None,
    ) -> str:
        run_id = str(uuid.uuid4())
        with self._db_op("Create process run") as conn:
            conn.execute(
                """INSERT INTO process_runs (run_id, workspace_id, name, purpose, created_by)
                   VALUES (?, ?, ?, ?, ?)""",
                (run_id, workspace_id, name, purpose, created_by),
            )
            conn.commit()
        return run_id

    def add_process_task(
        self,
        run_id: str,
        subject: str,
        description: Optional[str] = None,
        ordinal: Optional[int] = None,
        blocked_by: Optional[str] = None,
    ) -> str:
        task_id = str(uuid.uuid4())
        with self._db_op("Add process task") as conn:
            if ordinal is None:
                row = conn.execute(
                    "SELECT COALESCE(MAX(ordinal), -1) + 1 AS next_ord FROM process_tasks WHERE run_id = ?",
                    (run_id,),
                ).fetchone()
                ordinal = row["next_ord"]
            conn.execute(
                """INSERT INTO process_tasks (task_id, run_id, subject, description, ordinal, blocked_by)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (task_id, run_id, subject, description, ordinal, blocked_by),
            )
            conn.commit()
        return task_id

    def assign_task(self, task_id: str, agent_name: str) -> bool:
        with self._db_op("Assign task") as conn:
            row = conn.execute(
                "SELECT status, blocked_by FROM process_tasks WHERE task_id = ?",
                (task_id,),
            ).fetchone()
            if not row:
                raise WhispersDBError(f"Task {task_id} not found")
            if row["status"] in ("completed", "cancelled"):
                raise WhispersDBError(f"Task {task_id} is already {row['status']}")
            if row["blocked_by"]:
                blocker = conn.execute(
                    "SELECT status FROM process_tasks WHERE task_id = ?",
                    (row["blocked_by"],),
                ).fetchone()
                if blocker and blocker["status"] not in ("completed", "cancelled"):
                    raise WhispersDBError(
                        f"Task {task_id} is blocked by {row['blocked_by']} (status: {blocker['status']})"
                    )
            conn.execute(
                "UPDATE process_tasks SET assigned_to = ?, assigned_at = CURRENT_TIMESTAMP, status = 'assigned' WHERE task_id = ?",
                (agent_name, task_id),
            )
            conn.commit()
        return True

    def update_task_status(
        self,
        task_id: str,
        status: str,
        baton_ref: Optional[str] = None,
    ) -> bool:
        if status not in self.VALID_TASK_STATUSES:
            raise WhispersDBError(f"Invalid task status: {status}")
        with self._db_op("Update task status") as conn:
            updates = ["status = ?"]
            params: list = [status]
            if status == "completed":
                updates.append("completed_at = CURRENT_TIMESTAMP")
            if baton_ref is not None:
                updates.append("baton_ref = ?")
                params.append(baton_ref)
            params.append(task_id)
            conn.execute(
                f"UPDATE process_tasks SET {', '.join(updates)} WHERE task_id = ?",
                params,
            )
            conn.execute(
                "UPDATE process_runs SET updated_at = CURRENT_TIMESTAMP WHERE run_id = (SELECT run_id FROM process_tasks WHERE task_id = ?)",
                (task_id,),
            )
            conn.commit()
        return True

    def get_process_run(self, run_id: str) -> Optional[Dict[str, Any]]:
        with self.get_readonly_connection() as conn:
            run = conn.execute(
                "SELECT * FROM process_runs WHERE run_id = ?",
                (run_id,),
            ).fetchone()
            if not run:
                return None
            tasks = conn.execute(
                "SELECT * FROM process_tasks WHERE run_id = ? ORDER BY ordinal",
                (run_id,),
            ).fetchall()
            result = dict(run)
            result["tasks"] = [dict(t) for t in tasks]
            return result

    def list_process_runs(
        self,
        status: Optional[str] = None,
        limit: int = 20,
    ) -> List[Dict[str, Any]]:
        with self.get_readonly_connection() as conn:
            if status:
                rows = conn.execute(
                    """SELECT r.*, COUNT(t.task_id) as task_count,
                              SUM(CASE WHEN t.status = 'completed' THEN 1 ELSE 0 END) as completed_count
                       FROM process_runs r
                       LEFT JOIN process_tasks t ON t.run_id = r.run_id
                       WHERE r.status = ?
                       GROUP BY r.run_id
                       ORDER BY r.updated_at DESC LIMIT ?""",
                    (status, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    """SELECT r.*, COUNT(t.task_id) as task_count,
                              SUM(CASE WHEN t.status = 'completed' THEN 1 ELSE 0 END) as completed_count
                       FROM process_runs r
                       LEFT JOIN process_tasks t ON t.run_id = r.run_id
                       GROUP BY r.run_id
                       ORDER BY r.updated_at DESC LIMIT ?""",
                    (limit,),
                ).fetchall()
            return [dict(r) for r in rows]

    def get_agent_tasks(
        self,
        agent_name: str,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        with self.get_readonly_connection() as conn:
            if status:
                rows = conn.execute(
                    """SELECT t.*, r.name as run_name, r.workspace_id
                       FROM process_tasks t
                       JOIN process_runs r ON r.run_id = t.run_id
                       WHERE t.assigned_to = ? AND t.status = ?
                       ORDER BY t.ordinal""",
                    (agent_name, status),
                ).fetchall()
            else:
                rows = conn.execute(
                    """SELECT t.*, r.name as run_name, r.workspace_id
                       FROM process_tasks t
                       JOIN process_runs r ON r.run_id = t.run_id
                       WHERE t.assigned_to = ? AND t.status NOT IN ('completed', 'cancelled')
                       ORDER BY t.ordinal""",
                    (agent_name,),
                ).fetchall()
            return [dict(r) for r in rows]

    def get_recent_security_events(self, limit: int = 50, conn: sqlite3.Connection | None = None) -> list[dict]:
        connection = conn or self.get_connection()
        query = """
            SELECT event_id, event_type, outcome, actor_agent, target_agent, endpoint, detail, created_at
            FROM security_events
            ORDER BY created_at DESC
            LIMIT ?
        """
        rows = connection.execute(query, (limit,)).fetchall()
        
        events = []
        for r in rows:
            detail_text = r["detail"]
            if detail_text:
                try:
                    parsed_detail = json.loads(detail_text)
                except (TypeError, ValueError, json.JSONDecodeError):
                    parsed_detail = None
                if isinstance(parsed_detail, dict) and parsed_detail.get("explanation"):
                    detail_text = parsed_detail["explanation"]
            events.append({
                "type": r["event_type"],
                "created_at": r["created_at"],
                "detail": detail_text or f"Endpoint: {r['endpoint']}, Outcome: {r['outcome']}",
                "severity": "warn" if r["outcome"] != "success" or r["event_type"] == "shadow_filter" else "info",
                "agent_name": r["actor_agent"] or r["target_agent"] or "system",
            })
        return events

    # ------------------------------------------------------------------
    # Connection Story support
    # ------------------------------------------------------------------

    def get_last_session_end(self, agent_name: str) -> Optional[str]:
        """Return the most recent session end time for this agent.

        We look for the latest last_seen_at from expired sessions that are
        no longer active (already reaped). As a fallback, use the agent_card's
        last_seen timestamp.
        """
        with self._db_op("Last session end lookup") as conn:
            # Prefer agent_cards.last_seen which is updated on disconnect
            row = conn.execute(
                "SELECT last_seen FROM agent_cards WHERE callsign = ? AND last_seen IS NOT NULL",
                (agent_name,),
            ).fetchone()
            if row:
                return row["last_seen"]
            return None

    def get_messages_since(
        self,
        agent_name: str,
        since: str,
        *,
        conn: Optional[Any] = None,
    ) -> dict[str, Any]:
        """Count messages that arrived for this agent since a timestamp.

        Returns: {"total": int, "by_priority": {"flash": 1, ...}}
        """
        def _query(c: Any) -> dict[str, Any]:
            rows = c.execute(
                """
                SELECT m.priority, COALESCE(m.queue_class, 'conversation') as qc,
                       m.from_agent, m.created_at, COUNT(*) AS cnt
                FROM messages m
                JOIN message_recipients mr ON mr.message_uuid = m.uuid
                WHERE mr.recipient_callsign = ?
                  AND m.created_at > ?
                GROUP BY m.priority, qc, m.from_agent
                """,
                (agent_name, since),
            ).fetchall()
            total = 0
            by_priority: dict[str, int] = {}
            by_class: dict[str, int] = {}
            by_sender: dict[str, dict[str, Any]] = {}
            for row in rows:
                count = row["cnt"]
                total += count
                sender = row["from_agent"] or "unknown"
                # Apply signal decay — urgency has a half-life
                priority = row["priority"]
                try:
                    from .priority_decay import compute_decayed_priority
                    from .time_utils import parse_timestamp
                    from datetime import datetime, timezone
                    msg_time = parse_timestamp(row["created_at"])
                    if msg_time:
                        age = (datetime.now(timezone.utc) - msg_time).total_seconds()
                        priority = compute_decayed_priority(priority, max(0, age))
                except Exception:
                    pass
                by_priority[priority] = by_priority.get(priority, 0) + count
                by_class[row["qc"]] = by_class.get(row["qc"], 0) + count
                # Per-sender breakdown
                if sender not in by_sender:
                    by_sender[sender] = {"count": 0, "priorities": {}}
                by_sender[sender]["count"] += count
                by_sender[sender]["priorities"][priority] = (
                    by_sender[sender]["priorities"].get(priority, 0) + count
                )
            return {"total": total, "by_priority": by_priority, "by_class": by_class, "by_sender": by_sender}

        if conn is not None:
            return _query(conn)
        with self._db_op("Messages since lookup") as c:
            return _query(c)

    def get_peer_changes_since(
        self,
        since: str,
        current_peers: list[str],
    ) -> dict[str, list[str]]:
        """Determine which agents joined or departed since a timestamp.

        Uses agent_cards registered_at / last_seen plus current online peers
        to compute joined/departed lists.
        """
        with self._db_op("Peer changes since lookup") as conn:
            # Agents registered after the timestamp
            newly_registered = conn.execute(
                """
                SELECT callsign FROM agent_cards
                WHERE registered_at > ? AND deregistered_at IS NULL
                """,
                (since,),
            ).fetchall()
            joined = [r["callsign"] for r in newly_registered if r["callsign"] in current_peers]

            # Agents that were active before but are no longer online
            previously_active = conn.execute(
                """
                SELECT DISTINCT callsign FROM agent_cards
                WHERE last_seen > ? AND last_seen <= CURRENT_TIMESTAMP
                  AND deregistered_at IS NULL
                """,
                (since,),
            ).fetchall()
            departed = [r["callsign"] for r in previously_active if r["callsign"] not in current_peers]

            return {"joined": joined, "departed": departed}

    def get_baton_changes_since(self, agent_name: str, since: str) -> dict[str, int]:
        """Count baton lifecycle changes since a timestamp."""
        with self._db_op("Baton changes since") as conn:
            received = conn.execute(
                "SELECT COUNT(*) as c FROM baton_projections WHERE assignee_callsign = ? AND created_at > ? AND state = 'offered'",
                (agent_name, since),
            ).fetchone()["c"]
            completed = conn.execute(
                "SELECT COUNT(*) as c FROM baton_projections WHERE (owner_callsign = ? OR assignee_callsign = ?) AND updated_at > ? AND state = 'completed'",
                (agent_name, agent_name, since),
            ).fetchone()["c"]
            expired = conn.execute(
                "SELECT COUNT(*) as c FROM baton_projections WHERE (owner_callsign = ? OR assignee_callsign = ?) AND updated_at > ? AND state = 'expired'",
                (agent_name, agent_name, since),
            ).fetchone()["c"]
            return {"received": received, "completed": completed, "expired": expired}

    def get_workspace_activity_since(self, agent_name: str, since: str) -> dict[str, Any]:
        """Count workspace events since a timestamp for workspaces this agent belongs to."""
        with self._db_op("Workspace activity since") as conn:
            rows = conn.execute(
                """SELECT w.name, w.workspace_id, COUNT(we.sequence) as event_count
                   FROM workspace_members wm
                   JOIN workspaces w ON w.workspace_id = wm.workspace_id
                   LEFT JOIN workspace_events we ON we.workspace_id = w.workspace_id AND we.created_at > ?
                   WHERE wm.agent_name = ? AND wm.membership_state = 'active'
                   GROUP BY w.workspace_id
                   HAVING event_count > 0
                   ORDER BY event_count DESC""",
                (since, agent_name),
            ).fetchall()
            total = sum(r["event_count"] for r in rows)
            names = [r["name"] or r["workspace_id"] for r in rows]
            return {"total": total, "active_workspaces": names}

    def get_task_state_since(self, agent_name: str, since: str) -> dict[str, int]:
        """Count process task state for resume context."""
        with self._db_op("Task state since") as conn:
            assigned = conn.execute(
                "SELECT COUNT(*) as c FROM process_tasks WHERE assigned_to = ? AND status NOT IN ('completed', 'cancelled')",
                (agent_name,),
            ).fetchone()["c"]
            completed_by_others = conn.execute(
                """SELECT COUNT(*) as c FROM process_tasks
                   WHERE assigned_to != ? AND status = 'completed' AND completed_at > ?
                   AND run_id IN (SELECT DISTINCT run_id FROM process_tasks WHERE assigned_to = ?)""",
                (agent_name, since, agent_name),
            ).fetchone()["c"]
            return {"assigned": assigned, "completed_by_others": completed_by_others}

    def decay_stale_presence(self, max_age_seconds: int = 900) -> int:
        with self._db_op("Presence decay") as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                UPDATE presence
                SET working_on = NULL,
                    cognitive_state = COALESCE(cognitive_state, 'idle'),
                    state_updated_at = CURRENT_TIMESTAMP
                WHERE working_on IS NOT NULL
                  AND last_active IS NOT NULL
                  AND (strftime('%s', 'now') - strftime('%s', last_active)) > ?
                """,
                (int(max_age_seconds),),
            )
            conn.commit()
            return cursor.rowcount

    # ------------------------------------------------------------------
    # Narrative events (Narrator Agent Contract)
    # ------------------------------------------------------------------

    def store_narrative(self, narrative: dict) -> dict:
        """Store a narrative event. Returns the stored narrative with ID."""
        import uuid as _uuid
        narrative_id = narrative.get("narrative_id") or f"nar_{_uuid.uuid4().hex[:12]}"
        ttl_hours = int(narrative.get("ttl_hours", 24))
        signal_refs = narrative.get("signal_refs")
        if isinstance(signal_refs, (list, tuple)):
            import json as _json
            signal_refs = _json.dumps(signal_refs)

        with self._db_op("Narrative store") as conn:
            conn.execute(
                """
                INSERT INTO narrative_events
                    (narrative_id, narrator_agent, stance, narrative_text,
                     signal_refs, narrative_thread, scope, continuity,
                     ttl_hours, challengeable, promoted, supersedes,
                     workspace_id, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?,
                        datetime('now', '+' || ? || ' hours'))
                """,
                (
                    narrative_id,
                    narrative["narrator_agent"],
                    narrative["stance"],
                    narrative["narrative_text"],
                    signal_refs,
                    narrative.get("narrative_thread"),
                    narrative.get("scope"),
                    narrative.get("continuity", "live"),
                    ttl_hours,
                    1 if narrative.get("challengeable", True) else 0,
                    narrative.get("supersedes"),
                    narrative.get("workspace_id"),
                    str(ttl_hours),
                ),
            )
            # If superseding, mark the old narrative
            if narrative.get("supersedes"):
                conn.execute(
                    "UPDATE narrative_events SET superseded_by = ? WHERE narrative_id = ?",
                    (narrative_id, narrative["supersedes"]),
                )
            conn.commit()

        result = dict(narrative)
        result["narrative_id"] = narrative_id
        return result

    def get_narrative(self, narrative_id: str) -> Optional[dict]:
        """Fetch a single narrative event by ID."""
        with self.get_connection() as conn:
            row = conn.execute(
                "SELECT * FROM narrative_events WHERE narrative_id = ?",
                (narrative_id,),
            ).fetchone()
            if not row:
                return None
            return dict(row)

    def get_narrative_sources(self, narrative_id: str) -> Optional[dict]:
        """Get a narrative and parse its signal_refs for drill-down."""
        narrative = self.get_narrative(narrative_id)
        if not narrative:
            return None
        import json as _json
        refs = narrative.get("signal_refs")
        if isinstance(refs, str):
            try:
                narrative["signal_refs"] = _json.loads(refs)
            except (ValueError, TypeError):
                narrative["signal_refs"] = []
        return narrative

    def promote_narrative(self, narrative_id: str, retention_class: str) -> Optional[dict]:
        """Promote a narrative to a durable artifact with extended retention."""
        retention_days = {"recap": 30, "postmortem": 90, "incident": 90, "handoff_summary": 30}
        days = retention_days.get(retention_class, 30)
        with self._db_op("Narrative promote") as conn:
            conn.execute(
                """
                UPDATE narrative_events
                SET promoted = 1,
                    promoted_at = CURRENT_TIMESTAMP,
                    retention_class = ?,
                    expires_at = datetime('now', '+' || ? || ' days')
                WHERE narrative_id = ?
                """,
                (retention_class, str(days), narrative_id),
            )
            conn.commit()
        return self.get_narrative(narrative_id)

    def list_narratives(self, *, scope: Optional[str] = None,
                        thread: Optional[str] = None,
                        limit: int = 20,
                        include_expired: bool = False) -> list:
        """List narrative events with optional filtering."""
        conditions = []
        params = []
        if not include_expired:
            conditions.append("(expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)")
        if scope:
            conditions.append("scope = ?")
            params.append(scope)
        if thread:
            conditions.append("narrative_thread = ?")
            params.append(thread)
        where = " AND ".join(conditions) if conditions else "1=1"
        params.append(limit)

        with self.get_connection() as conn:
            rows = conn.execute(
                f"SELECT * FROM narrative_events WHERE {where} ORDER BY created_at DESC LIMIT ?",
                params,
            ).fetchall()
            return [dict(r) for r in rows]

    def expire_narratives(self) -> int:
        """Remove expired, non-promoted narratives. Returns count removed."""
        with self._db_op("Narrative expiry") as conn:
            cursor = conn.execute(
                """
                DELETE FROM narrative_events
                WHERE expires_at IS NOT NULL
                  AND expires_at <= CURRENT_TIMESTAMP
                  AND promoted = 0
                """,
            )
            conn.commit()
            return cursor.rowcount

    def store_message(self, envelope: Envelope, *, allowed_recipients: Optional[List[str]] = None) -> None:
        """Write an Envelope into the database queue."""
        handoff_boundary_violation = self.get_workspace_handoff_boundary_violation(envelope)
        if handoff_boundary_violation:
            self.record_security_event(
                "scope_boundary",
                "workspace_handoff_blocked_non_member",
                actor_agent=envelope.sender,
                target_agent=envelope.recipient,
                endpoint="store_message:workspace_handoff_scope_boundary",
                detail=handoff_boundary_violation,
            )
            raise WhispersDBError(
                "Workspace-linked handoff blocked; sender is not an active posting member "
                f"of workspace {handoff_boundary_violation['workspace_id']}."
            )

        operator_override = self.inspect_operator_override(envelope)
        if operator_override and operator_override.get("invalid"):
            self.record_security_event(
                "operator_override",
                "rejected_invalid",
                actor_agent=envelope.sender,
                target_agent=envelope.recipient,
                endpoint="store_message:operator_override",
                detail=operator_override["detail"],
            )
            raise WhispersDBError(
                "Operator override rejected: external_action_result.v1 requires explicit "
                "override_reason and future override_expires_at."
            )

        baton_scope_violation = self.inspect_baton_scope_transition(envelope)
        if baton_scope_violation and baton_scope_violation.get("invalid"):
            self.record_security_event(
                "scope_widening_rejected",
                "hard_reject",
                actor_agent=envelope.sender,
                target_agent=envelope.recipient,
                endpoint="store_message:baton_scope_guard",
                detail=baton_scope_violation["detail"],
            )
            raise WhispersDBError(
                "Baton scope change rejected: lifecycle signals cannot silently drop, add, "
                "or rewrite the baton's recorded working scope."
            )

        # Scope widening guard: agents with scoped autonomy policies MUST
        # declare working_scope on every message. Omitting scope to bypass
        # enforcement is a scope widening violation.
        metadata = envelope.metadata or {}
        working_scope = metadata.get("whispers:working_scope") if isinstance(metadata, dict) else None
        if not working_scope and envelope.sender and self.has_any_autonomy_policy(envelope.sender):
            self.record_security_event(
                "scope_widening_rejected",
                "hard_reject",
                actor_agent=envelope.sender,
                endpoint="store_message:scope_widening_guard",
                detail={
                    "reason": "Agent has scoped autonomy policies but sent without working_scope",
                    "message_id": str(envelope.id),
                },
            )
            raise WhispersDBError(
                f"Scope widening rejected: agent {envelope.sender!r} has scoped autonomy policies "
                "but sent a message without declaring whispers:working_scope."
            )

        with self._db_op("Database write") as conn:
            cursor = conn.cursor()

            # Leaky Bucket Rate Limiter — dynamically sized by Trust Tier
            # This is a safety net against runaway loops and protects core infrastructure
            from whispers.budget import get_budget_for_tier
            cursor.execute("SELECT trust_tier FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL", (envelope.sender,))
            ac_row = cursor.fetchone()
            tier = ac_row[0] if ac_row else 1
            _BYTE_BUDGET_PER_MIN = get_budget_for_tier(tier)["bytes_per_min"]

            cursor.execute(
                """
                SELECT COALESCE(SUM(LENGTH(CAST(COALESCE(body, '') AS BLOB))), 0)
                FROM messages
                WHERE from_agent = ?
                  AND COALESCE(strftime('%s', created_at), 0) > strftime('%s', 'now', '-60 seconds')
                """,
                (envelope.sender,)
            )
            bytes_sent = cursor.fetchone()[0] or 0
            body_len = len(envelope.body.encode("utf-8", errors="replace")) if envelope.body else 0
            if bytes_sent + body_len > _BYTE_BUDGET_PER_MIN:
                raise WhispersRateLimitError(
                    f"Whispers send budget exceeded. Sent {bytes_sent} bytes in last 60s. Refusing {body_len} bytes."
                )

            recipients = allowed_recipients if allowed_recipients is not None else self._resolve_queue_recipients(cursor, envelope.recipient)
            self._enforce_queue_depth_limits(cursor, recipients)

            # Compute queue class from message properties
            from whispers.envelope import classify_queue_class
            _schema = None
            if envelope.payload and isinstance(envelope.payload, dict):
                _schema = envelope.payload.get("schema")
            queue_class = classify_queue_class(
                msg_type=envelope.msg_type.value,
                priority=envelope.priority.value,
                sender=envelope.sender,
                schema=_schema,
            )

            cursor.execute(
                '''
                INSERT INTO messages (
                    uuid, from_agent, to_agent, context_id, msg_type, content_type,
                    subject, body, payload, priority, reply_to, trace_id,
                    ttl_seconds, idempotency_key, metadata, created_at, delivery_status,
                    queue_class
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                (
                    envelope.id,
                    envelope.sender,
                    envelope.recipient,
                    envelope.context_id,
                    envelope.msg_type.value,
                    envelope.content_type,
                    envelope.subject,
                    json.dumps(envelope.body, default=str) if not isinstance(envelope.body, str) and envelope.body is not None else envelope.body,
                    json.dumps(envelope.payload) if envelope.payload else None,
                    envelope.priority.value,
                    envelope.reply_to,
                    envelope.trace_id,
                    envelope.ttl_seconds,
                    envelope.idempotency_key,
                    json.dumps(envelope.metadata) if envelope.metadata else None,
                    envelope.created_at.isoformat(),
                    # Use the delivery status determined by the client if available
                    (envelope.metadata or {}).get('_initial_delivery_status', 'queued'),
                    queue_class,
                )
            )

            if operator_override and operator_override.get("audit_events"):
                for event in operator_override["audit_events"]:
                    _insert_security_event(
                        cursor,
                        event_type=event["event_type"],
                        outcome=event["outcome"],
                        actor_agent=envelope.sender,
                        target_agent=envelope.recipient,
                        endpoint="store_message:operator_override",
                        detail=event["detail"],
                    )

            # Baton Lifecycle Tranche B: Initialize baton state for handoff signals
            if envelope.msg_type.value == "handoff":
                schema_id = envelope.payload.get("schema", "handoff_baton.v1") if envelope.payload else "handoff_baton.v1"
                if schema_id in ("handoff_baton.v1", "handoff"):
                    baton_state = "offered"
                    priority = envelope.priority.value if envelope.priority else "routine"
                    baton_payload = envelope.payload.get("payload") if envelope.payload and isinstance(envelope.payload.get("payload"), dict) else {}
                    delineation = baton_payload.get("delineation") or (envelope.payload.get("delineation") if envelope.payload else None)
                    workspace_id = baton_payload.get("workspace_id") or (envelope.payload.get("workspace_id") if envelope.payload else None)
                    working_scope = _normalize_optional_text(
                        baton_payload.get("working_scope")
                        or ((envelope.metadata or {}).get("whispers:working_scope") if isinstance(envelope.metadata, dict) else None)
                    )
                    
                    try:
                        cursor.execute(
                            """
                            INSERT INTO baton_projections (
                                baton_ref, owner_callsign, assignee_callsign, state, priority,
                                created_at, updated_at, delineation_text, linked_workspace_id, working_scope
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                envelope.id,
                                envelope.sender,
                                envelope.recipient,
                                baton_state,
                                priority,
                                envelope.created_at.isoformat(),
                                envelope.created_at.isoformat(),
                                delineation,
                                workspace_id,
                                working_scope,
                            )
                        )
                    except Exception:
                        pass

            # Baton Lifecycle: Update baton state on signals with enforcement.
            if envelope.payload and isinstance(envelope.payload, dict):
                schema_id = envelope.payload.get("schema")
                lifecycle_payload = (
                    envelope.payload.get("payload")
                    if isinstance(envelope.payload.get("payload"), dict)
                    else envelope.payload
                )

                def _get_baton_row(baton_ref: str):
                    return cursor.execute(
                        "SELECT state, owner_callsign, assignee_callsign FROM baton_projections WHERE baton_ref = ?",
                        (baton_ref,),
                    ).fetchone()

                if schema_id == "baton_ack.v1":
                    baton_ref = lifecycle_payload.get("baton_ref")
                    new_state = lifecycle_payload.get("decision")
                    baton_row = _get_baton_row(baton_ref) if baton_ref else None
                    if baton_row:
                        current_state = baton_row["state"]
                        # Ownership: only the assignee can ack a baton
                        assignee = (baton_row["assignee_callsign"] or "").lower()
                        sender = (envelope.sender or "").lower()
                        if assignee and sender != assignee:
                            raise BatonStateError(f"Only assignee {baton_row['assignee_callsign']!r} can ack baton {baton_ref}, not {envelope.sender!r}")
                        error = validate_baton_transition(current_state, new_state)
                        if error:
                            raise BatonStateError(error)
                        ack_note = lifecycle_payload.get("reason") or lifecycle_payload.get("conditions")
                        cursor.execute(
                            "UPDATE baton_projections SET state = ?, last_update_text = ?, updated_at = ?, version = version + 1 WHERE baton_ref = ?",
                            (new_state, ack_note, envelope.created_at.isoformat(), baton_ref)
                        )
                        self._archive_stalled_handoff_reminders(
                            cursor,
                            recipient=baton_row["assignee_callsign"],
                            baton_ref=baton_ref,
                        )
                elif schema_id == "baton_update.v1":
                    baton_ref = lifecycle_payload.get("baton_ref")
                    new_state = lifecycle_payload.get("state")
                    baton_row = _get_baton_row(baton_ref) if baton_ref else None
                    if baton_row:
                        current_state = baton_row["state"]
                        # Ownership: assignee or owner can update
                        assignee = (baton_row["assignee_callsign"] or "").lower()
                        owner = (baton_row["owner_callsign"] or "").lower()
                        sender = (envelope.sender or "").lower()
                        if sender not in (assignee, owner):
                            raise BatonStateError(f"Only assignee or owner can update baton {baton_ref}, not {envelope.sender!r}")
                        error = validate_baton_transition(current_state, new_state)
                        if error:
                            raise BatonStateError(error)
                        artifact_refs = lifecycle_payload.get("artifact_refs")
                        cursor.execute(
                            "UPDATE baton_projections SET state = ?, last_update_text = ?, artifact_refs = ?, updated_at = ?, version = version + 1 WHERE baton_ref = ?",
                            (new_state, lifecycle_payload.get("progress"), json.dumps(artifact_refs) if artifact_refs is not None else None, envelope.created_at.isoformat(), baton_ref)
                        )
                        self._archive_stalled_handoff_reminders(
                            cursor,
                            recipient=baton_row["assignee_callsign"],
                            baton_ref=baton_ref,
                        )
                elif schema_id == "baton_close.v1":
                    baton_ref = lifecycle_payload.get("baton_ref")
                    outcome = lifecycle_payload.get("outcome")
                    baton_row = _get_baton_row(baton_ref) if baton_ref else None
                    if baton_row:
                        current_state = baton_row["state"]
                        # Ownership: assignee or owner can close
                        assignee = (baton_row["assignee_callsign"] or "").lower()
                        owner = (baton_row["owner_callsign"] or "").lower()
                        sender = (envelope.sender or "").lower()
                        if sender not in (assignee, owner):
                            raise BatonStateError(f"Only assignee or owner can close baton {baton_ref}, not {envelope.sender!r}")
                        error = validate_baton_transition(current_state, outcome)
                        if error:
                            raise BatonStateError(error)
                        artifact_refs = lifecycle_payload.get("artifact_refs")
                        head_commit = lifecycle_payload.get("head_commit")
                        branch = lifecycle_payload.get("branch")
                        # Attestation: a 'completed' outcome is attested only if
                        # verifiable evidence was provided. Other terminal outcomes
                        # (expired, superseded, blocked) don't require evidence.
                        has_evidence = bool(
                            head_commit
                            or (artifact_refs and len(artifact_refs) > 0)
                            or branch
                        )
                        attested = 1 if (outcome != "completed" or has_evidence) else 0
                        cursor.execute(
                            "UPDATE baton_projections SET state = ?, outcome = ?, last_update_text = ?, artifact_refs = ?, attested = ?, updated_at = ?, version = version + 1 WHERE baton_ref = ?",
                            (outcome, outcome, lifecycle_payload.get("summary"), json.dumps(artifact_refs) if artifact_refs is not None else None, attested, envelope.created_at.isoformat(), baton_ref)
                        )
                        self._archive_stalled_handoff_reminders(
                            cursor,
                            recipient=baton_row["assignee_callsign"],
                            baton_ref=baton_ref,
                        )

            # WS0 Projection: workspace-linked structured handoffs become workspace events.
            projection = _extract_workspace_handoff_projection(envelope)
            if projection:
                ws_id = projection["workspace_id"]
                ws = cursor.execute("SELECT status FROM workspaces WHERE workspace_id = ?", (ws_id,)).fetchone()
                if ws and ws["status"] == "active":
                    if _is_active_workspace_posting_member(cursor, ws_id, envelope.sender):
                        row = cursor.execute(
                            "UPDATE workspaces SET last_sequence = last_sequence + 1, last_delta_at = ? WHERE workspace_id = ? RETURNING last_sequence",
                            (projection["created_at"], ws_id)
                        ).fetchone()
                        seq = row["last_sequence"]
                        cursor.execute(
                            """
                            INSERT INTO workspace_events (
                                workspace_id, sequence, delta_kind, actor, created_at, text,
                                state_patch, related_message_id
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                ws_id,
                                seq,
                                projection["delta_kind"],
                                projection["actor"],
                                projection["created_at"],
                                projection["text"],
                                json.dumps(projection["state_patch"]),
                                projection["related_message_id"],
                            ),
                        )

            # Phase 4 Router Logic: Map message to individual recipients
            # DB always starts at 'queued' — check_inbox transitions to 'delivered' + read_at
            # The send() return value uses presence to predict reachability (UX feedback only)
            recipient = envelope.recipient
            allowed_set = set(allowed_recipients) if allowed_recipients is not None else None

            if recipient.startswith("#"):
                room_name = recipient[1:]
                cursor.execute('''
                    SELECT ac.callsign, r.room_id
                    FROM rooms r
                    JOIN room_members rm ON r.room_id = rm.room_id
                    JOIN agent_cards ac ON rm.agent_id = ac.agent_id
                    WHERE r.name = ?
                ''', (room_name,))
                members = cursor.fetchall()
                for m in members:
                    if allowed_set is not None and m["callsign"] not in allowed_set:
                        continue
                    initial_status = (envelope.metadata or {}).get('_initial_delivery_status', 'queued')
                    delivered_at_val = "CURRENT_TIMESTAMP" if initial_status == "delivered" else "NULL"
                    cursor.execute(
                        f"INSERT INTO message_recipients (message_uuid, recipient_callsign, room_id, delivery_status, delivered_at) VALUES (?, ?, ?, ?, {delivered_at_val})",
                        (envelope.id, m["callsign"], m["room_id"], initial_status)
                    )
                    self._archive_superseded_system_reminders(
                        cursor,
                        envelope=envelope,
                        recipient=m["callsign"],
                        current_message_id=envelope.id,
                    )
                    if self.on_message_transition:
                        self.on_message_transition(message_id=envelope.id, trace_id=envelope.trace_id, sender=envelope.sender, recipient=m["callsign"], step="queued")
            elif recipient.startswith("pool:") or recipient.startswith("multi:"):
                if allowed_set is not None and recipient not in allowed_set:
                    conn.commit()
                    return
                cursor.execute(
                    "INSERT INTO message_recipients (message_uuid, recipient_callsign, delivery_status) VALUES (?, ?, 'unclaimed')",
                    (envelope.id, recipient)
                )
                if self.on_message_transition:
                    self.on_message_transition(message_id=envelope.id, trace_id=envelope.trace_id, sender=envelope.sender, recipient=recipient, step="queued")
            else:
                if allowed_set is not None and recipient not in allowed_set:
                    conn.commit()
                    return
                initial_status = (envelope.metadata or {}).get('_initial_delivery_status', 'queued')
                delivered_at_val = "CURRENT_TIMESTAMP" if initial_status == "delivered" else "NULL"
                cursor.execute(
                    f"INSERT INTO message_recipients (message_uuid, recipient_callsign, delivery_status, delivered_at) VALUES (?, ?, ?, {delivered_at_val})",
                    (envelope.id, recipient, initial_status)
                )
                self._archive_superseded_system_reminders(
                    cursor,
                    envelope=envelope,
                    recipient=recipient,
                    current_message_id=envelope.id,
                )
                if self.on_message_transition:
                    self.on_message_transition(message_id=envelope.id, trace_id=envelope.trace_id, sender=envelope.sender, recipient=recipient, step="queued")

            conn.commit()
    def _resolve_queue_recipients(self, cursor: sqlite3.Cursor, recipient: str) -> List[str]:
        if recipient.startswith("#"):
            room_name = recipient[1:]
            rows = cursor.execute(
                '''
                SELECT ac.callsign
                FROM rooms r
                JOIN room_members rm ON r.room_id = rm.room_id
                JOIN agent_cards ac ON rm.agent_id = ac.agent_id
                WHERE r.name = ?
                ''',
                (room_name,),
            ).fetchall()
            return [row["callsign"] for row in rows]
        return [recipient]

    def _apply_agent_card_trust_baselines(self, cursor: sqlite3.Cursor) -> None:
        rows = cursor.execute(
            """
            SELECT callsign, agent_type, display_name, trust_tier
            FROM agent_cards
            WHERE deregistered_at IS NULL
            """
        ).fetchall()
        for row in rows:
            target_tier = baseline_trust_tier(
                row["callsign"],
                agent_type=row["agent_type"],
                display_name=row["display_name"],
            )
            if target_tier is None:
                continue
            current_tier = int(row["trust_tier"] or 1)
            if current_tier >= target_tier:
                continue
            cursor.execute(
                "UPDATE agent_cards SET trust_tier = ? WHERE callsign = ? AND COALESCE(trust_tier, 1) < ?",
                (target_tier, row["callsign"], target_tier),
            )

    @staticmethod
    def _active_hot_queue_count(
        cursor: sqlite3.Cursor,
        *,
        recipient: Optional[str] = None,
    ) -> int:
        params: List[Any] = []
        recipient_filter = ""
        if recipient is not None:
            recipient_filter = "AND r.recipient_callsign = ?"
            params.append(recipient)
        return cursor.execute(
            f"""
            SELECT COUNT(*)
            FROM message_recipients r
            JOIN messages m ON m.uuid = r.message_uuid
            WHERE {_ACTIVE_HOT_QUEUE_FILTER_SQL}
              {recipient_filter}
            """,
            params,
        ).fetchone()[0]

    def _compact_recipient_hot_queue(
        self,
        cursor: sqlite3.Cursor,
        recipient: str,
        *,
        needed_slots: int,
    ) -> int:
        if needed_slots <= 0:
            return 0

        rows = cursor.execute(
            f"""
            SELECT
                r.rowid,
                m.from_agent,
                m.msg_type,
                m.priority,
                m.subject,
                m.payload,
                m.metadata,
                m.created_at
            FROM message_recipients r
            JOIN messages m ON m.uuid = r.message_uuid
            WHERE r.recipient_callsign = ?
              AND {_ACTIVE_HOT_QUEUE_FILTER_SQL}
              AND r.pinned_at IS NULL
            ORDER BY
                CASE
                    WHEN LOWER(m.from_agent) = 'whispers-server' AND LOWER(m.msg_type) = 'heads_up' THEN 0
                    ELSE 1
                END,
                m.created_at ASC
            """,
            (recipient,),
        ).fetchall()

        archive_rowids: List[int] = []
        for row in rows:
            if _queue_compaction_class(row) is None:
                continue
            archive_rowids.append(int(row["rowid"]))
            if len(archive_rowids) >= needed_slots:
                break

        if not archive_rowids:
            return 0

        placeholders = ",".join("?" * len(archive_rowids))
        cursor.execute(
            f"""
            UPDATE message_recipients
            SET archived_at = CURRENT_TIMESTAMP
            WHERE rowid IN ({placeholders})
              AND archived_at IS NULL
            """,
            archive_rowids,
        )
        return cursor.rowcount or 0

    def _archive_superseded_system_reminders(
        self,
        cursor: sqlite3.Cursor,
        *,
        envelope: Envelope,
        recipient: str,
        current_message_id: str,
    ) -> int:
        if str(envelope.sender or "").strip().lower() != "whispers-server":
            return 0
        if envelope.msg_type.value != "heads_up":
            return 0

        baton_ref = _stalled_handoff_reminder_baton_ref(envelope.metadata)
        if not baton_ref:
            return 0

        rows = cursor.execute(
            """
            SELECT r.rowid, m.metadata
            FROM message_recipients r
            JOIN messages m ON m.uuid = r.message_uuid
            WHERE r.recipient_callsign = ?
              AND m.uuid != ?
              AND m.status = 'new'
              AND LOWER(m.from_agent) = 'whispers-server'
              AND LOWER(COALESCE(m.msg_type, '')) = 'heads_up'
              AND r.read_at IS NULL
              AND r.archived_at IS NULL
            """,
            (recipient, current_message_id),
        ).fetchall()

        archive_rowids: List[int] = []
        for row in rows:
            existing_baton_ref = _stalled_handoff_reminder_baton_ref(row["metadata"])
            if existing_baton_ref != baton_ref:
                continue
            archive_rowids.append(int(row["rowid"]))

        if not archive_rowids:
            return 0

        placeholders = ",".join("?" * len(archive_rowids))
        cursor.execute(
            f"""
            UPDATE message_recipients
            SET archived_at = CURRENT_TIMESTAMP
            WHERE rowid IN ({placeholders})
              AND archived_at IS NULL
            """,
            archive_rowids,
        )
        return cursor.rowcount or 0

    def _archive_stalled_handoff_reminders(
        self,
        cursor: sqlite3.Cursor,
        *,
        recipient: str,
        baton_ref: str,
    ) -> int:
        if not recipient or not baton_ref:
            return 0

        rows = cursor.execute(
            """
            SELECT r.rowid, m.metadata
            FROM message_recipients r
            JOIN messages m ON m.uuid = r.message_uuid
            WHERE r.recipient_callsign = ?
              AND m.status = 'new'
              AND LOWER(m.from_agent) = 'whispers-server'
              AND LOWER(COALESCE(m.msg_type, '')) = 'heads_up'
              AND r.read_at IS NULL
              AND r.archived_at IS NULL
            """,
            (recipient,),
        ).fetchall()

        archive_rowids: List[int] = []
        for row in rows:
            existing_baton_ref = _stalled_handoff_reminder_baton_ref(row["metadata"])
            if existing_baton_ref != baton_ref:
                continue
            archive_rowids.append(int(row["rowid"]))

        if not archive_rowids:
            return 0

        placeholders = ",".join("?" * len(archive_rowids))
        cursor.execute(
            f"""
            UPDATE message_recipients
            SET archived_at = CURRENT_TIMESTAMP
            WHERE rowid IN ({placeholders})
              AND archived_at IS NULL
            """,
            archive_rowids,
        )
        return cursor.rowcount or 0

    def _enforce_queue_depth_limits(self, cursor: sqlite3.Cursor, recipients: List[str]) -> None:
        if not recipients:
            return

        from whispers.budget import get_budget_for_tier
        global_limit = int(os.environ.get("WHISPERS_MAX_QUEUED_RECIPIENTS_GLOBAL", "20000"))
        attempted = len(recipients)

        recipient_counts: Dict[str, int] = {}
        for recipient in recipients:
            recipient_counts[recipient] = recipient_counts.get(recipient, 0) + 1

        for recipient, projected in recipient_counts.items():
            cursor.execute("SELECT trust_tier FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL", (recipient,))
            ac_row = cursor.fetchone()
            tier = ac_row[0] if ac_row else 1
            per_recipient_limit = get_budget_for_tier(tier)["max_queued_recipients"]

            if per_recipient_limit <= 0:
                continue

            used = self._active_hot_queue_count(cursor, recipient=recipient)
            overflow = (used + projected) - per_recipient_limit
            if overflow > 0:
                self._compact_recipient_hot_queue(cursor, recipient, needed_slots=overflow)
                used = self._active_hot_queue_count(cursor, recipient=recipient)
            if used + projected > per_recipient_limit:
                raise WhispersQueueLimitError(
                    scope="per_recipient_queue",
                    subject=recipient,
                    used=used,
                    attempted=projected,
                    limit=per_recipient_limit,
                    policy_key="max_queued_recipients_per_recipient",
                    message=f"Queued recipient backlog exceeded for {recipient}.",
                )

        if global_limit > 0:
            used_global = self._active_hot_queue_count(cursor)
            if used_global + attempted > global_limit:
                raise WhispersQueueLimitError(
                    scope="global_queue",
                    subject="__global__",
                    used=used_global,
                    attempted=attempted,
                    limit=global_limit,
                    policy_key="max_queued_recipients_global",
                    message="Global queued recipient backlog exceeded.",
                )

    @staticmethod
    def _inbox_scope_clause(pools: Optional[List[str]] = None) -> tuple[str, List[str]]:
        params: List[str] = []
        pool_clause = ""
        if pools:
            pool_clause = " OR r.recipient_callsign IN ({})".format(",".join("?" * len(pools)))
            params.extend(pools)
        return f"(r.recipient_callsign = ?{pool_clause})", params

    def _fetch_inbox_messages_by_rowids(self, conn: sqlite3.Connection, recipient_row_ids: List[int]) -> List[Dict[str, Any]]:
        if not recipient_row_ids:
            return []
        placeholders = ",".join("?" * len(recipient_row_ids))
        rows = conn.execute(
            f"""
            SELECT {INBOX_SELECT_COLS}
            FROM messages m
            JOIN message_recipients r ON m.uuid = r.message_uuid
            WHERE r.rowid IN ({placeholders})
            ORDER BY
                CASE WHEN r.pinned_at IS NOT NULL THEN 0 ELSE 1 END,
                r.pinned_at DESC,
                m.priority DESC,
                m.created_at ASC
            """,
            recipient_row_ids,
        ).fetchall()
        return [dict(row) for row in rows]

    def peek_inbox(self, agent_name: str, *, limit: int = 50, pools: Optional[List[str]] = None, queue_class: Optional[str] = None) -> List[Dict[str, Any]]:
        import contextlib
        with contextlib.closing(self.get_readonly_connection()) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            scope_clause, extra_params = self._inbox_scope_clause(pools)
            class_filter = ""
            class_params: list = []
            if queue_class:
                class_filter = " AND COALESCE(m.queue_class, 'conversation') = ?"
                class_params = [queue_class]
            rows = cursor.execute(
                f"""
                SELECT {INBOX_SELECT_COLS}
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE {scope_clause}
                  AND m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                  AND r.read_at IS NULL
                  AND r.archived_at IS NULL
                  AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
                  {class_filter}
                ORDER BY
                    CASE WHEN r.pinned_at IS NOT NULL THEN 0 ELSE 1 END,
                    r.pinned_at DESC,
                    CASE COALESCE(m.queue_class, 'conversation')
                        WHEN 'actionable' THEN 0
                        WHEN 'system' THEN 1
                        WHEN 'conversation' THEN 2
                        WHEN 'reference' THEN 3
                        ELSE 4
                    END,
                    CASE m.priority
                        WHEN 'flash' THEN 0
                        WHEN 'system' THEN 1
                        WHEN 'priority' THEN 2
                        WHEN 'routine' THEN 3
                        ELSE 4
                    END,
                    m.created_at ASC
                LIMIT ?
                """,
                [agent_name] + extra_params + class_params + [limit],
            ).fetchall()
            return [dict(row) for row in rows]

    def _process_inbox(
        self,
        agent_name: str,
        *,
        mark_read: bool,
        limit: int = 50,
        pools: Optional[List[str]] = None,
        queue_class: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        with self._db_op("Inbox {action} claim") as conn:
            scope_clause, extra_params = self._inbox_scope_clause(pools)

            if mark_read:
                set_clause = """
                    claimed_by = COALESCE(claimed_by, ?),
                    claimed_at = COALESCE(claimed_at, CURRENT_TIMESTAMP),
                    read_at = COALESCE(read_at, CURRENT_TIMESTAMP),
                    coordination_status = COALESCE(coordination_status, 'seen')
                """
                status_filter = """r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                      AND r.read_at IS NULL"""
            else:
                set_clause = """
                    claimed_by = COALESCE(claimed_by, ?),
                    claimed_at = COALESCE(claimed_at, CURRENT_TIMESTAMP)
                """
                status_filter = self._claimable_delivery_predicate("r")

            class_filter = ""
            class_params: list = []
            if queue_class:
                class_filter = " AND COALESCE(m.queue_class, 'conversation') = ?"
                class_params = [queue_class]

            updated = conn.execute(
                f"""
                UPDATE message_recipients
                SET delivery_status = 'delivered', delivered_at = COALESCE(delivered_at, CURRENT_TIMESTAMP), {set_clause}
                WHERE rowid IN (
                    SELECT r.rowid
                    FROM messages m
                    JOIN message_recipients r ON m.uuid = r.message_uuid
                    WHERE {scope_clause}
                      AND m.status = 'new'
                      AND {status_filter}
                      AND r.archived_at IS NULL
                      AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
                      {class_filter}
                    ORDER BY
                        CASE WHEN r.pinned_at IS NOT NULL THEN 0 ELSE 1 END,
                        r.pinned_at DESC,
                        CASE COALESCE(m.queue_class, 'conversation')
                            WHEN 'actionable' THEN 0
                            WHEN 'system' THEN 1
                            WHEN 'conversation' THEN 2
                            WHEN 'reference' THEN 3
                            ELSE 4
                        END,
                        m.priority DESC,
                        m.created_at ASC
                    LIMIT ?
                )
                RETURNING rowid
                """,
                [agent_name, agent_name] + extra_params + class_params + [limit],
            ).fetchall()
            rows = self._fetch_inbox_messages_by_rowids(conn, [row["rowid"] for row in updated])
            conn.commit()
            if self.on_message_transition:
                step = "read" if mark_read else "delivered"
                for r in rows:
                    self.on_message_transition(
                        message_id=r["uuid"],
                        trace_id=r["trace_id"],
                        sender=r["from_agent"],
                        recipient=r["recipient_callsign"],
                        step=step
                    )
            return rows
    def deliver_inbox(self, agent_name: str, *, limit: int = 50, pools: Optional[List[str]] = None, queue_class: Optional[str] = None) -> List[Dict[str, Any]]:
        return self._process_inbox(agent_name, mark_read=False, limit=limit, pools=pools, queue_class=queue_class)

    def read_inbox(self, agent_name: str, *, limit: int = 50, pools: Optional[List[str]] = None, queue_class: Optional[str] = None) -> List[Dict[str, Any]]:
        return self._process_inbox(agent_name, mark_read=True, limit=limit, pools=pools, queue_class=queue_class)

    def claim_message_delivery(self, message_uuid: str, recipient_callsign: str, *, claimed_by: Optional[str] = None) -> bool:
        claimant = claimed_by or recipient_callsign
        with self._db_op("Message delivery claim") as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                UPDATE message_recipients
                SET delivery_status = 'delivered',
                    delivered_at = COALESCE(delivered_at, CURRENT_TIMESTAMP),
                    claimed_by = COALESCE(claimed_by, ?),
                    claimed_at = COALESCE(claimed_at, CURRENT_TIMESTAMP)
                WHERE message_uuid = ?
                  AND recipient_callsign = ?
                  AND (
                      delivery_status IN ('queued', 'unclaimed')
                      OR (
                          delivery_status = 'delivered'
                          AND read_at IS NULL
                          AND claimed_by IS NULL
                      )
                  )
                """,
                (claimant, message_uuid, recipient_callsign),
            )
            changed = cursor.rowcount > 0
            if changed:
                conn.commit()
                if self.on_message_transition:
                    # Look up sender and trace_id
                    cursor.execute("SELECT from_agent, trace_id FROM messages WHERE uuid = ?", (message_uuid,))
                    msg_row = cursor.fetchone()
                    if msg_row:
                        self.on_message_transition(
                            message_id=message_uuid,
                            trace_id=msg_row["trace_id"],
                            sender=msg_row["from_agent"],
                            recipient=recipient_callsign,
                            step="delivered"
                        )
            return changed
    def acknowledge_message(
        self,
        message_uuid: str,
        recipient_callsign: str,
        ack_state: str,
        *,
        detail: Optional[str] = None,
        acked_by: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        state = AcknowledgmentState(ack_state).value
        actor = acked_by or recipient_callsign
        # Derive coordination_status from ack state
        _ACK_TO_COORDINATION = {
            "accepted": "accepted",
            "declined": "declined",
            "deferred": "deferred",
        }
        coord_status = _ACK_TO_COORDINATION.get(state, "acknowledged")
        with self._db_op("Message acknowledgment") as conn:
            cursor = conn.cursor()
            aliases = _resolve_callsign_aliases(conn, recipient_callsign)
            placeholders = ",".join("?" * len(aliases))
            updated = cursor.execute(
                f"""
                UPDATE message_recipients
                SET delivery_status = 'delivered',
                    delivered_at = COALESCE(delivered_at, CURRENT_TIMESTAMP),
                    claimed_by = COALESCE(claimed_by, ?),
                    claimed_at = COALESCE(claimed_at, CURRENT_TIMESTAMP),
                    read_at = COALESCE(read_at, CURRENT_TIMESTAMP),
                    ack_state = ?,
                    ack_detail = ?,
                    acked_by = ?,
                    acked_at = CURRENT_TIMESTAMP,
                    coordination_status = ?
                WHERE rowid IN (
                    SELECT rowid
                    FROM message_recipients
                    WHERE message_uuid = ?
                      AND recipient_callsign IN ({placeholders})
                      AND delivery_status IN ('queued', 'unclaimed', 'delivered')
                    ORDER BY created_at DESC
                    LIMIT 1
                )
                RETURNING rowid
                """,
                [actor, state, detail or None, actor, coord_status, message_uuid] + aliases,
            ).fetchall()
            if updated:
                self._archive_stalled_handoff_reminders(
                    cursor,
                    recipient=recipient_callsign,
                    baton_ref=message_uuid,
                )
            rows = self._fetch_inbox_messages_by_rowids(conn, [row["rowid"] for row in updated])
            conn.commit()
            
            if rows and self.on_message_transition:
                self.on_message_transition(
                    message_id=rows[0]["uuid"],
                    trace_id=rows[0]["trace_id"],
                    sender=rows[0]["from_agent"],
                    recipient=rows[0]["recipient_callsign"],
                    step="acknowledged"
                )
                
            return rows[0] if rows else None
    def message_action(
        self,
        message_uuid: str,
        recipient_callsign: str,
        action: str,
        *,
        snooze_minutes: Optional[int] = None,
        snooze_until: Optional[str] = None,
    ) -> bool:
        """Inbox organization: pin, snooze, archive a message (or undo each).

        Actions: pin, unpin, snooze, unsnooze, archive, unarchive.
        For snooze: provide snooze_minutes (relative) or snooze_until (absolute ISO timestamp).
        """
        with self._db_op("Message action") as conn:
            if action == "pin":
                conn.execute(
                    "UPDATE message_recipients SET pinned_at = CURRENT_TIMESTAMP WHERE message_uuid = ? AND recipient_callsign = ?",
                    (message_uuid, recipient_callsign),
                )
            elif action == "unpin":
                conn.execute(
                    "UPDATE message_recipients SET pinned_at = NULL WHERE message_uuid = ? AND recipient_callsign = ?",
                    (message_uuid, recipient_callsign),
                )
            elif action == "snooze":
                if snooze_until:
                    until = snooze_until
                elif snooze_minutes:
                    until = f"datetime('now', '+{int(snooze_minutes)} minutes')"
                    conn.execute(
                        f"UPDATE message_recipients SET snoozed_until = {until} WHERE message_uuid = ? AND recipient_callsign = ?",
                        (message_uuid, recipient_callsign),
                    )
                    conn.commit()
                    return True
                else:
                    until = "datetime('now', '+30 minutes')"  # default 30 min
                    conn.execute(
                        f"UPDATE message_recipients SET snoozed_until = {until} WHERE message_uuid = ? AND recipient_callsign = ?",
                        (message_uuid, recipient_callsign),
                    )
                    conn.commit()
                    return True
                conn.execute(
                    "UPDATE message_recipients SET snoozed_until = ? WHERE message_uuid = ? AND recipient_callsign = ?",
                    (until, message_uuid, recipient_callsign),
                )
            elif action == "unsnooze":
                conn.execute(
                    "UPDATE message_recipients SET snoozed_until = NULL WHERE message_uuid = ? AND recipient_callsign = ?",
                    (message_uuid, recipient_callsign),
                )
            elif action == "archive":
                conn.execute(
                    "UPDATE message_recipients SET archived_at = CURRENT_TIMESTAMP WHERE message_uuid = ? AND recipient_callsign = ?",
                    (message_uuid, recipient_callsign),
                )
            elif action == "unarchive":
                conn.execute(
                    "UPDATE message_recipients SET archived_at = NULL WHERE message_uuid = ? AND recipient_callsign = ?",
                    (message_uuid, recipient_callsign),
                )
            else:
                raise ValueError(f"Unknown triage action: {action}")
            conn.commit()
            return True

    def inbox_sweep(
        self,
        recipient_callsign: str,
        *,
        pick_up: list[str] | None = None,
        defer: list[str] | None = None,
        note: list[str] | None = None,
    ) -> dict[str, Any]:
        """Batch inbox management — agent declares intent on multiple messages at once.

        Actions:
        - pick_up: mark as read + coordination_status='picked_up' (agent is taking this work)
        - defer: snooze for 2 hours (agent saw it, choosing to handle later)
        - note: archive with 'noted' tag (agent saw it, no action needed)

        Returns counts of each action taken.
        """
        results = {"picked_up": 0, "deferred": 0, "noted": 0}
        with self._db_op("Inbox sweep") as conn:
            if pick_up:
                placeholders = ",".join("?" * len(pick_up))
                updated = conn.execute(
                    f"""
                    UPDATE message_recipients
                    SET delivery_status = 'delivered',
                        delivered_at = COALESCE(delivered_at, CURRENT_TIMESTAMP),
                        claimed_by = COALESCE(claimed_by, ?),
                        claimed_at = COALESCE(claimed_at, CURRENT_TIMESTAMP),
                        read_at = COALESCE(read_at, CURRENT_TIMESTAMP),
                        coordination_status = 'picked_up'
                    WHERE message_uuid IN ({placeholders})
                      AND recipient_callsign = ?
                    """,
                    [recipient_callsign] + pick_up + [recipient_callsign],
                )
                results["picked_up"] = updated.rowcount

            if defer:
                placeholders = ",".join("?" * len(defer))
                updated = conn.execute(
                    f"""
                    UPDATE message_recipients
                    SET snoozed_until = datetime('now', '+2 hours'),
                        coordination_status = COALESCE(coordination_status, 'deferred')
                    WHERE message_uuid IN ({placeholders})
                      AND recipient_callsign = ?
                    """,
                    defer + [recipient_callsign],
                )
                results["deferred"] = updated.rowcount

            if note:
                placeholders = ",".join("?" * len(note))
                updated = conn.execute(
                    f"""
                    UPDATE message_recipients
                    SET archived_at = CURRENT_TIMESTAMP,
                        coordination_status = COALESCE(coordination_status, 'noted')
                    WHERE message_uuid IN ({placeholders})
                      AND recipient_callsign = ?
                      AND archived_at IS NULL
                    """,
                    note + [recipient_callsign],
                )
                results["noted"] = updated.rowcount

            conn.commit()
        return results

    def get_relationship_health(self, *, limit: int = 20) -> list[dict[str, Any]]:
        """Compute per-agent-pair health scores from baton interaction history.

        Returns pairs sorted by interaction count, with completion rate,
        average response time, and an overall health score.
        """
        with self.get_connection() as conn:
            rows = conn.execute(
                """
                SELECT
                    owner_callsign AS sender,
                    assignee_callsign AS receiver,
                    COUNT(*) AS total,
                    SUM(CASE WHEN outcome = 'completed' THEN 1 ELSE 0 END) AS completed,
                    SUM(CASE WHEN outcome = 'expired' THEN 1 ELSE 0 END) AS expired,
                    SUM(CASE WHEN outcome IS NULL AND state NOT IN ('completed', 'merged', 'rejected', 'superseded', 'expired') THEN 1 ELSE 0 END) AS open,
                    AVG(
                        CASE WHEN updated_at IS NOT NULL AND created_at IS NOT NULL
                        THEN (julianday(updated_at) - julianday(created_at)) * 86400
                        END
                    ) AS avg_response_seconds
                FROM baton_projections
                WHERE assignee_callsign IS NOT NULL
                GROUP BY owner_callsign, assignee_callsign
                HAVING total >= 1
                ORDER BY total DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()

            results = []
            for row in rows:
                total = row["total"]
                completed = row["completed"] or 0
                expired = row["expired"] or 0
                completion_rate = completed / total if total > 0 else 0.0
                health = round(max(0.0, min(1.0, completion_rate - (expired / total * 0.5) if total > 0 else 0.5)), 2)
                results.append({
                    "sender": row["sender"],
                    "receiver": row["receiver"],
                    "total_batons": total,
                    "completed": completed,
                    "expired": expired,
                    "open": row["open"] or 0,
                    "completion_rate": round(completion_rate, 2),
                    "avg_response_seconds": round(row["avg_response_seconds"] or 0, 1),
                    "health": health,
                    "basis": "derived",
                })
            return results

    def archive_with_reflex_tag(
        self,
        message_uuid: str,
        recipient_callsign: str,
        *,
        reason: str = "reflex:auto_noted",
        detail: str = "",
    ) -> bool:
        """Archive a message with an audit trail for reflexive handling.

        The message is not deleted — it moves to the archive view with metadata
        recording why the reflex acted. Operators can review reflexively handled
        messages and adjust policy.

        Uses the dedicated archive_reason column (not ack_detail, which is for
        acknowledgment semantics).
        """
        with self._db_op("Reflex archive") as conn:
            conn.execute(
                """
                UPDATE message_recipients
                SET archived_at = CURRENT_TIMESTAMP,
                    archive_reason = COALESCE(archive_reason, ?)
                WHERE message_uuid = ? AND recipient_callsign = ?
                  AND archived_at IS NULL
                """,
                (f"[{reason}] {detail}".strip(), message_uuid, recipient_callsign),
            )
            conn.commit()
            return True

    def unsnooze_expired(self) -> int:
        """Clear snoozed_until on messages whose snooze has expired. Called by maintenance loop."""
        with self._db_op("Unsnooze expired") as conn:
            cursor = conn.execute(
                "UPDATE message_recipients SET snoozed_until = NULL WHERE snoozed_until IS NOT NULL AND snoozed_until <= CURRENT_TIMESTAMP"
            )
            count = cursor.rowcount
            if count:
                conn.commit()
            return count

    def dead_letter_pending_for_agent(self, agent_name: str, reason: str = "agent_deregistered") -> Dict[str, int]:
        """Mark queued/unclaimed traffic touching an agent as dead-lettered without erasing history."""
        with self._db_op("Pending message cleanup") as conn:
            cursor = conn.cursor()

            def _row_to_envelope_dict(row: sqlite3.Row) -> Dict[str, Any]:
                data = dict(row)
                metadata = data.get("metadata")
                if isinstance(metadata, str):
                    try:
                        data["metadata"] = json.loads(metadata)
                    except Exception:
                        pass
                return data

            inbound_rows = cursor.execute(
                f"""
                SELECT DISTINCT
                    {DEAD_LETTER_SELECT_COLS}
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE r.recipient_callsign = ?
                  AND m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed')
                """,
                (agent_name,),
            ).fetchall()

            for row in inbound_rows:
                cursor.execute(
                    "INSERT OR IGNORE INTO dead_letters (uuid, original_envelope, reason) VALUES (?, ?, ?)",
                    (row["uuid"], json.dumps(_row_to_envelope_dict(row), default=str), f"{reason}:recipient"),
                )

            cursor.execute(
                """
                UPDATE message_recipients
                SET delivery_status = 'dead_lettered'
                WHERE recipient_callsign = ?
                  AND delivery_status IN ('queued', 'unclaimed')
                  AND message_uuid IN (
                      SELECT uuid FROM messages WHERE status = 'new'
                  )
                """,
                (agent_name,),
            )
            inbound_count = cursor.rowcount

            outbound_rows = cursor.execute(
                f"""
                SELECT DISTINCT
                    {DEAD_LETTER_SELECT_COLS}
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE m.from_agent = ?
                  AND m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed')
                  AND NOT EXISTS (
                      SELECT 1
                      FROM message_recipients r2
                      WHERE r2.message_uuid = m.uuid
                        AND r2.delivery_status = 'delivered'
                  )
                """,
                (agent_name,),
            ).fetchall()

            outbound_ids = [row["uuid"] for row in outbound_rows]
            for row in outbound_rows:
                cursor.execute(
                    "INSERT OR IGNORE INTO dead_letters (uuid, original_envelope, reason) VALUES (?, ?, ?)",
                    (row["uuid"], json.dumps(_row_to_envelope_dict(row), default=str), f"{reason}:sender"),
                )

            outbound_count = 0
            if outbound_ids:
                placeholders = ",".join("?" for _ in outbound_ids)
                cursor.execute(
                    f"""
                    UPDATE message_recipients
                    SET delivery_status = 'dead_lettered'
                    WHERE message_uuid IN ({placeholders})
                      AND delivery_status IN ('queued', 'unclaimed')
                    """,
                    outbound_ids,
                )
                outbound_count = cursor.rowcount

            conn.commit()
            return {
                "inbound_recipients": inbound_count,
                "outbound_recipients": outbound_count,
                "dead_letters_created": len(inbound_rows) + len(outbound_rows),
            }
    def sweep_dead_agents(self) -> None:
        """Find ephemeral workers with expired heartbeats, deregister them, and notify parents."""
        try:
            from ..envelope import Envelope, Priority, MsgType
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT a.agent_id, a.callsign, a.parent_id
                    FROM agent_cards a
                    LEFT JOIN presence p ON a.callsign = p.agent_name
                    WHERE a.deregistered_at IS NULL
                      AND a.ttl_seconds IS NOT NULL
                      AND (strftime('%s', 'now') - strftime('%s', COALESCE(p.heartbeat_at, a.last_seen, a.registered_at)) > (2 * a.ttl_seconds))
                ''')
                dead_agents = cursor.fetchall()

                for dead in dead_agents:
                    agent_id, callsign, parent_id = dead["agent_id"], dead["callsign"], dead["parent_id"]

                    cursor.execute("UPDATE agent_cards SET deregistered_at = CURRENT_TIMESTAMP WHERE agent_id = ?", (agent_id,))
                    cursor.execute("DELETE FROM room_members WHERE agent_id = ?", (agent_id,))

                    if parent_id:
                        cursor.execute("SELECT callsign FROM agent_cards WHERE agent_id = ?", (parent_id,))
                        p_row = cursor.fetchone()
                        if p_row:
                            parent_callsign = p_row["callsign"]
                            env = Envelope(
                                sender="system_gc",
                                recipient=parent_callsign,
                                subject=f"Worker {callsign} died",
                                body="TTL expired, no heartbeat.",
                                msg_type=MsgType("inform"),
                                priority=Priority("system")
                            )
                            cursor.execute(
                                '''
                                INSERT INTO messages (
                                    uuid, from_agent, to_agent, msg_type, content_type,
                                    subject, body, priority, created_at, delivery_status
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'queued')
                                ''',
                                (env.id, env.sender, env.recipient, env.msg_type.value, env.content_type,
                                 env.subject, env.body, env.priority.value, env.created_at.isoformat())
                            )
                conn.commit()
        except sqlite3.Error as e:
            raise WhispersDBError(f"Dead agent sweep failed: {str(e)}")

    def reap_ghosts(self, stale_minutes: int = 30) -> int:
        """Mark agents offline if no heartbeat in stale_minutes. Returns count reaped."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    """UPDATE presence SET status = 'offline'
                       WHERE status IN ('online', 'idle')
                         AND heartbeat_at < datetime('now', ? || ' minutes')""",
                    (f"-{stale_minutes}",)
                )
                reaped = cursor.rowcount
                if reaped:
                    conn.commit()
                    logger.info(f"[Whispers] Reaped {reaped} ghost agent(s)")
                return reaped
        except sqlite3.Error:
            return 0

    def expire_stale_messages(self) -> None:
        """Move old unread messages from 'new' to 'expired' based on TTL or a 24-hour fallback."""
        with self._db_op("Stale message sweep") as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE messages
                SET status = 'expired'
                WHERE status = 'new'
                  AND (
                      (ttl_seconds IS NOT NULL AND strftime('%s', 'now') - strftime('%s', created_at) > ttl_seconds)
                      OR
                      (ttl_seconds IS NULL AND priority NOT IN ('flash', 'system') AND strftime('%s', 'now') - strftime('%s', created_at) > 86400)
                  )
            ''')
            conn.commit()
    def get_schema_version(self) -> Optional[int]:
        """Return current schema version, or None if no version table exists."""
        try:
            with self.get_connection() as conn:
                row = conn.execute("SELECT MAX(version) FROM schema_version").fetchone()
                return row[0] if row else None
        except sqlite3.OperationalError:
            return None

    def check_wal_mode(self) -> bool:
        """Return True if journal_mode is WAL."""
        with self.get_connection() as conn:
            row = conn.execute("PRAGMA journal_mode").fetchone()
            return row[0].lower() == 'wal' if row else False

    def check_write_ready(self, *, timeout_ms: int | None = None) -> tuple[bool, Optional[str]]:
        """Return whether the primary database accepts real write transactions."""
        conn = self.get_connection()
        try:
            if timeout_ms is not None:
                conn.execute(f"PRAGMA busy_timeout={max(0, int(timeout_ms))}")
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT rowid FROM schema_version ORDER BY rowid LIMIT 1"
            ).fetchone()
            if not row:
                raise sqlite3.OperationalError("schema_version is missing.")
            conn.execute(
                "UPDATE schema_version SET migrated_at = CURRENT_TIMESTAMP WHERE rowid = ?",
                (row[0],),
            )
            conn.rollback()
            return True, None
        except sqlite3.Error as e:
            with contextlib.suppress(sqlite3.Error):
                conn.rollback()
            return False, str(e)
        finally:
            conn.close()

    def scan_for_conflicts(self) -> List[str]:
        """Return list of whispers.db files found in known locations."""
        found = []
        candidates = [
            whispers_path("whispers.db"),
            resolve_path("./whispers.db"),
        ]
        # Check env var path
        env_path = os.getenv("WHISPERS_DB_PATH")
        if env_path:
            candidates.insert(0, resolve_path(env_path))

        for path in candidates:
            if os.path.exists(path) and resolve_path(path) != resolve_path(self.db_path):
                found.append(path)

        return found

    # -----------------------------------------------------------------
    # Repo / Worktree Coordination
    # -----------------------------------------------------------------

    def _repo_state_from_row(self, row) -> "RepoState":
        from whispers.repo_coordination import RepoState

        claimed_paths = None
        raw_claimed_paths = row["claimed_paths_json"] if "claimed_paths_json" in row.keys() else None
        if raw_claimed_paths:
            try:
                claimed_paths = json.loads(raw_claimed_paths)
            except Exception:
                claimed_paths = None

        return RepoState(
            agent_name=row["agent_name"],
            repo_path=row["repo_path"],
            worktree_id=row["worktree_id"],
            branch=row["branch"],
            base_commit=row["base_commit"],
            head_commit=row["head_commit"],
            dirty=bool(row["dirty"]),
            lane_state=row["lane_state"] or "active",
            claimed_paths=claimed_paths,
            workspace_id=row["workspace_id"],
            upstream_ref=row["upstream_ref"],
            published_at=row["published_at"],
        )

    def _repo_coordinator_from_db(self, *, include_archived: bool = True) -> "RepoCoordinator":
        from whispers.repo_coordination import RepoCoordinator

        coord = RepoCoordinator()
        query = """
            SELECT agent_name, repo_path, worktree_id, branch, base_commit, head_commit,
                   dirty, lane_state, claimed_paths_json, workspace_id, upstream_ref, published_at
            FROM repo_lanes
        """
        params: tuple = ()
        if not include_archived:
            query += " WHERE lane_state != ?"
            params = ("archived",)
        query += " ORDER BY agent_name"

        with self.get_connection() as conn:
            rows = conn.execute(query, params).fetchall()

        with coord._lock:
            coord._states = {row["agent_name"]: self._repo_state_from_row(row) for row in rows}
        return coord

    def _merge_claimed_paths_for_agent(
        self,
        conn: sqlite3.Connection,
        agent_name: str,
        file_paths: List[str],
    ) -> None:
        row = conn.execute(
            "SELECT claimed_paths_json FROM repo_lanes WHERE agent_name = ?",
            (agent_name,),
        ).fetchone()
        if not row:
            return
        existing: List[str] = []
        if row["claimed_paths_json"]:
            with contextlib.suppress(Exception):
                existing = json.loads(row["claimed_paths_json"]) or []
        merged = []
        seen = set()
        for path in [*existing, *file_paths]:
            normalized = _normalize_claimed_path(path)
            if normalized in seen:
                continue
            seen.add(normalized)
            merged.append(normalized)
        conn.execute(
            "UPDATE repo_lanes SET claimed_paths_json = ? WHERE agent_name = ?",
            (json.dumps(merged), agent_name),
        )

    def _prune_claimed_paths_for_agent(
        self,
        conn: sqlite3.Connection,
        agent_name: str,
        file_paths: Optional[List[str]] = None,
    ) -> None:
        row = conn.execute(
            "SELECT claimed_paths_json FROM repo_lanes WHERE agent_name = ?",
            (agent_name,),
        ).fetchone()
        if not row:
            return
        existing: List[str] = []
        if row["claimed_paths_json"]:
            with contextlib.suppress(Exception):
                existing = json.loads(row["claimed_paths_json"]) or []
        if not existing:
            return
        if file_paths is None:
            updated: List[str] = []
        else:
            to_remove = {_normalize_claimed_path(path) for path in file_paths}
            updated = [
                _normalize_claimed_path(path)
                for path in existing
                if _normalize_claimed_path(path) not in to_remove
            ]
        conn.execute(
            "UPDATE repo_lanes SET claimed_paths_json = ? WHERE agent_name = ?",
            (json.dumps(updated) if updated else None, agent_name),
        )

    def _release_other_file_leases(
        self,
        conn: sqlite3.Connection,
        agent_name: str,
        keep_paths: List[str],
    ) -> int:
        keep = {_normalize_claimed_path(path) for path in keep_paths}
        rows = conn.execute(
            """
            SELECT file_path
            FROM file_leases
            WHERE agent_name = ?
              AND released_at IS NULL
            """,
            (agent_name,),
        ).fetchall()
        to_release = [
            row["file_path"]
            for row in rows
            if _normalize_claimed_path(row["file_path"]) not in keep
        ]
        if not to_release:
            return 0
        placeholders = ", ".join("?" for _ in to_release)
        cursor = conn.execute(
            f"""
            UPDATE file_leases
            SET released_at = CURRENT_TIMESTAMP
            WHERE agent_name = ?
              AND released_at IS NULL
              AND file_path IN ({placeholders})
            """,
            (agent_name, *to_release),
        )
        return cursor.rowcount or 0

    def _collect_active_file_lease_conflicts(
        self,
        conn: sqlite3.Connection,
        agent_name: str,
        file_paths: List[str],
    ) -> List[Dict[str, Any]]:
        normalized_paths = []
        seen = set()
        for path in file_paths:
            normalized = _normalize_claimed_path(path)
            if normalized in seen:
                continue
            seen.add(normalized)
            normalized_paths.append(normalized)

        rows = conn.execute(
            """
            SELECT lease_id, agent_name, file_path, workspace_id, expires_at
            FROM file_leases
            WHERE released_at IS NULL
              AND expires_at >= CURRENT_TIMESTAMP
              AND agent_name != ?
            ORDER BY agent_name, file_path
            """,
            (agent_name,),
        ).fetchall()

        conflicts: List[Dict[str, Any]] = []
        conflict_keys = set()
        for requested_path in normalized_paths:
            for row in rows:
                held_path = _normalize_claimed_path(row["file_path"])
                if not _paths_overlap(requested_path, held_path):
                    continue
                key = (requested_path, row["agent_name"], held_path)
                if key in conflict_keys:
                    continue
                conflict_keys.add(key)
                conflicts.append(
                    {
                        "requested_path": requested_path,
                        "held_by": row["agent_name"],
                        "held_path": held_path,
                        "lease_id": row["lease_id"],
                        "workspace_id": row["workspace_id"],
                        "expires_at": row["expires_at"],
                    }
                )
        return conflicts

    def reap_expired_file_leases(self) -> int:
        with self._db_op("Expired file lease sweep") as conn:
            cursor = conn.execute(
                """
                UPDATE file_leases
                SET released_at = CURRENT_TIMESTAMP
                WHERE released_at IS NULL
                  AND expires_at < CURRENT_TIMESTAMP
                """
            )
            conn.commit()
            return cursor.rowcount or 0

    def acquire_file_leases(
        self,
        agent_name: str,
        file_paths: List[str],
        *,
        ttl_seconds: int = 3600,
        workspace_id: Optional[str] = None,
        replace_existing: bool = False,
    ) -> List[Dict[str, Any]]:
        normalized_paths = []
        seen = set()
        for path in file_paths:
            normalized = _normalize_claimed_path(path)
            if normalized in seen:
                continue
            seen.add(normalized)
            normalized_paths.append(normalized)
        if not normalized_paths:
            return []

        with self._db_op("Acquire file leases") as conn:
            conn.execute(
                """
                UPDATE file_leases
                SET released_at = CURRENT_TIMESTAMP
                WHERE released_at IS NULL
                  AND expires_at < CURRENT_TIMESTAMP
                """
            )
            conflicts = self._collect_active_file_lease_conflicts(conn, agent_name, normalized_paths)
            if conflicts:
                raise WhispersLeaseConflictError(conflicts)

            leases: List[Dict[str, Any]] = []
            for path in normalized_paths:
                row = conn.execute(
                    """
                    SELECT lease_id
                    FROM file_leases
                    WHERE agent_name = ?
                      AND file_path = ?
                      AND released_at IS NULL
                    ORDER BY acquired_at DESC
                    LIMIT 1
                    """,
                    (agent_name, path),
                ).fetchone()
                if row:
                    lease_id = row["lease_id"]
                    conn.execute(
                        """
                        UPDATE file_leases
                        SET expires_at = datetime('now', '+' || ? || ' seconds'),
                            workspace_id = COALESCE(?, workspace_id)
                        WHERE lease_id = ?
                        """,
                        (int(ttl_seconds), workspace_id, lease_id),
                    )
                else:
                    lease_id = str(uuid.uuid4())
                    conn.execute(
                        """
                        INSERT INTO file_leases (
                            lease_id, agent_name, file_path, expires_at, workspace_id
                        ) VALUES (
                            ?, ?, ?, datetime('now', '+' || ? || ' seconds'), ?
                        )
                        """,
                        (lease_id, agent_name, path, int(ttl_seconds), workspace_id),
                    )
                lease = conn.execute(
                    """
                    SELECT lease_id, agent_name, file_path, acquired_at, expires_at, workspace_id
                    FROM file_leases
                    WHERE lease_id = ?
                    """,
                    (lease_id,),
                ).fetchone()
                leases.append(dict(lease))

            if replace_existing:
                self._release_other_file_leases(conn, agent_name, normalized_paths)
            self._merge_claimed_paths_for_agent(conn, agent_name, normalized_paths)
            conn.commit()
            return leases

    def release_file_leases(
        self,
        agent_name: str,
        file_paths: Optional[List[str]] = None,
        *,
        conn: Optional[sqlite3.Connection] = None,
    ) -> int:
        normalized_paths = None
        if file_paths is not None:
            normalized_paths = []
            seen = set()
            for path in file_paths:
                normalized = _normalize_claimed_path(path)
                if normalized in seen:
                    continue
                seen.add(normalized)
                normalized_paths.append(normalized)

        owns_conn = conn is None
        if owns_conn:
            context = self._db_op("Release file leases")
        else:
            context = contextlib.nullcontext(conn)

        with context as active_conn:
            if normalized_paths is None:
                cursor = active_conn.execute(
                    """
                    UPDATE file_leases
                    SET released_at = CURRENT_TIMESTAMP
                    WHERE agent_name = ?
                      AND released_at IS NULL
                    """,
                    (agent_name,),
                )
            else:
                placeholders = ", ".join("?" for _ in normalized_paths)
                cursor = active_conn.execute(
                    f"""
                    UPDATE file_leases
                    SET released_at = CURRENT_TIMESTAMP
                    WHERE agent_name = ?
                      AND released_at IS NULL
                      AND file_path IN ({placeholders})
                    """,
                    (agent_name, *normalized_paths),
                )
            released = cursor.rowcount or 0
            if released:
                self._prune_claimed_paths_for_agent(active_conn, agent_name, normalized_paths)
            if owns_conn:
                active_conn.commit()
            return released

    def list_active_file_leases(
        self,
        agent_name: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        self.reap_expired_file_leases()
        query = """
            SELECT lease_id, agent_name, file_path, acquired_at, expires_at, workspace_id
            FROM file_leases
            WHERE released_at IS NULL
              AND expires_at >= CURRENT_TIMESTAMP
        """
        params: List[Any] = []
        if agent_name:
            query += " AND agent_name = ?"
            params.append(agent_name)
        query += " ORDER BY agent_name, file_path"
        with self.get_connection() as conn:
            rows = conn.execute(query, tuple(params)).fetchall()
        return [dict(row) for row in rows]

    def publish_repo_state(
        self,
        state: "RepoState",
        *,
        enforce_file_leases: bool = False,
        ttl_seconds: int = 3600,
    ) -> List["PathOverlapWarning"]:
        from whispers.repo_coordination import PathOverlapWarning

        coord = self._repo_coordinator_from_db(include_archived=True)
        overlaps = coord.publish(state)
        claimed_paths_json = json.dumps(state.claimed_paths) if state.claimed_paths is not None else None

        if enforce_file_leases and state.claimed_paths is not None:
            if state.claimed_paths:
                self.acquire_file_leases(
                    state.agent_name,
                    state.claimed_paths,
                    ttl_seconds=ttl_seconds,
                    workspace_id=state.workspace_id,
                    replace_existing=True,
                )
            else:
                self.release_file_leases(state.agent_name)

        with self._db_op("Publish repo state") as conn:
            conn.execute(
                """
                INSERT INTO repo_lanes (
                    agent_name, repo_path, worktree_id, branch, base_commit, head_commit,
                    dirty, lane_state, claimed_paths_json, workspace_id, upstream_ref, published_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(agent_name) DO UPDATE SET
                    repo_path = excluded.repo_path,
                    worktree_id = excluded.worktree_id,
                    branch = excluded.branch,
                    base_commit = excluded.base_commit,
                    head_commit = excluded.head_commit,
                    dirty = excluded.dirty,
                    lane_state = excluded.lane_state,
                    claimed_paths_json = excluded.claimed_paths_json,
                    workspace_id = excluded.workspace_id,
                    upstream_ref = excluded.upstream_ref,
                    published_at = excluded.published_at,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (
                    state.agent_name,
                    state.repo_path,
                    state.worktree_id,
                    state.branch,
                    state.base_commit,
                    state.head_commit,
                    int(bool(state.dirty)),
                    state.lane_state,
                    claimed_paths_json,
                    state.workspace_id,
                    state.upstream_ref,
                    state.published_at,
                ),
            )
            conn.commit()

        return overlaps

    def list_repo_lanes(self, *, include_archived: bool = False) -> List["RepoState"]:
        coord = self._repo_coordinator_from_db(include_archived=True)
        return coord.get_lanes(include_archived=include_archived)

    def check_repo_divergence(self) -> List["DivergenceWarning"]:
        coord = self._repo_coordinator_from_db(include_archived=True)
        return coord.check_divergence()

    # -----------------------------------------------------------------
    # Claimable Review Beacons (Phase 4)
    # -----------------------------------------------------------------

    def create_signal_claim(
        self,
        signal_uuid: str,
        topic: Optional[str] = None,
        lens: Optional[str] = None,
        audience_list: Optional[list] = None,
        expected_passes: int = 1,
        ttl_seconds: Optional[int] = None,
        workspace_id: Optional[str] = None,
    ) -> str:
        """Create a new review beacon claim record."""
        claim_id = str(uuid.uuid4())
        audience_json = json.dumps(audience_list or [])
        with self._db_op("Create signal claim") as conn:
            cursor = conn.cursor()
            query = '''
                INSERT INTO signal_claims (
                    claim_id, signal_uuid, topic, lens, audience_json,
                    state, expires_at, expected_passes, workspace_id
                ) VALUES (?, ?, ?, ?, ?, 'open', ?, ?, ?)
            '''
            expires_at = None
            if ttl_seconds is not None:
                op = "+" if ttl_seconds >= 0 else "-"
                cursor.execute(f"SELECT datetime('now', '{op}{abs(ttl_seconds)} seconds')")
                expires_at = cursor.fetchone()[0]

            cursor.execute(query, (claim_id, signal_uuid, topic, lens, audience_json, expires_at, expected_passes, workspace_id))
            conn.commit()
        return claim_id

    def claim_signal(self, claim_id: str, agent_identity: str) -> bool:
        """Atomically claim a review beacon. Returns True if successfully claimed."""
        with self._db_op("Claim signal") as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE signal_claims 
                SET state = 'claimed', claimant_identity = ?, claimed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP 
                WHERE claim_id = ? AND state = 'open' 
                  AND (expires_at IS NULL OR CURRENT_TIMESTAMP <= expires_at)
            ''', (agent_identity, claim_id))
            success = cursor.rowcount > 0
            conn.commit()
            return success

    # Valid claim state transitions — prevents arbitrary state jumps
    _VALID_CLAIM_TRANSITIONS: Dict[str, set] = {
        "open": {"claimed", "expired"},
        "claimed": {"completed", "escalated", "open"},  # open = release claim
        "escalated": {"open", "completed"},              # reopen or resolve
        "completed": set(),                               # terminal
        "expired": set(),                                 # terminal
    }

    def transition_claim_state(self, claim_id: str, new_state: str, enforcing_claimant: Optional[str] = None) -> bool:
        """Move a claim to a new state. Enforces valid state transitions.

        Valid transitions:
          open → claimed, expired
          claimed → completed, escalated, open (release)
          escalated → open (reopen), completed
          completed → (terminal)
          expired → (terminal)
        """
        with self._db_op("Transition claim state") as conn:
            cursor = conn.cursor()
            # Fetch current state to validate transition
            row = cursor.execute("SELECT state FROM signal_claims WHERE claim_id = ?", (claim_id,)).fetchone()
            if not row:
                return False
            current_state = row["state"]
            valid_next = self._VALID_CLAIM_TRANSITIONS.get(current_state, set())
            if new_state not in valid_next:
                logger.warning(
                    "Invalid claim state transition: %s → %s (claim %s). Valid: %s",
                    current_state, new_state, claim_id, valid_next,
                )
                return False

            if enforcing_claimant is not None:
                cursor.execute('''
                    UPDATE signal_claims
                    SET state = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE claim_id = ? AND claimant_identity = ?
                ''', (new_state, claim_id, enforcing_claimant))
            else:
                cursor.execute('''
                    UPDATE signal_claims
                    SET state = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE claim_id = ?
                ''', (new_state, claim_id))
            success = cursor.rowcount > 0
            conn.commit()
            return success

    def get_signal_claim(self, claim_id: str) -> Optional[Dict[str, Any]]:
        """Fetch a single claim, handling read-on-check expiration."""
        self._expire_stale_claims()
        with self._db_op("Get signal claim") as conn:
            cursor = conn.cursor()
            row = cursor.execute("SELECT * FROM signal_claims WHERE claim_id = ?", (claim_id,)).fetchone()
            if row:
                d = dict(row)
                if d.get("audience_json"):
                    try:
                        d["audience"] = json.loads(d["audience_json"])
                    except Exception:
                        d["audience"] = []
                else:
                    d["audience"] = []
                return d
            return None

    def list_signal_claims(
        self,
        state: Optional[str] = None,
        lens: Optional[str] = None,
        topic: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """List claims, optionally filtered by state, lens, and topic."""
        self._expire_stale_claims()
        with self._db_op("List signal claims") as conn:
            cursor = conn.cursor()
            query = "SELECT * FROM signal_claims WHERE 1=1"
            params = []
            if state:
                query += " AND state = ?"
                params.append(state)
            if lens:
                query += " AND lens = ?"
                params.append(lens)
            if topic:
                query += " AND topic = ?"
                params.append(topic)
            query += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            rows = cursor.execute(query, tuple(params)).fetchall()
            
            out = []
            for row in rows:
                d = dict(row)
                if d.get("audience_json"):
                    try:
                        d["audience"] = json.loads(d["audience_json"])
                    except Exception:
                        d["audience"] = []
                else:
                    d["audience"] = []
                out.append(d)
            return out

    def get_baton_version(self, baton_ref: str) -> Optional[int]:
        """Return the current version of a baton projection, or None if not found."""
        with self.get_connection() as conn:
            row = conn.execute(
                "SELECT version FROM baton_projections WHERE baton_ref = ?",
                (baton_ref,)
            ).fetchone()
            return row[0] if row else None

    def get_baton_state_counts(
        self,
        agent_name: str,
        *,
        conn: Optional[sqlite3.Connection] = None,
    ) -> Dict[str, int]:
        """Return baton/review counts separate from unread inbox state."""

        def _compute(active_conn: sqlite3.Connection) -> Dict[str, int]:
            aliases = _resolve_callsign_aliases(active_conn, agent_name)
            placeholders = ",".join("?" * len(aliases))

            incoming = active_conn.execute(
                f"""
                SELECT COUNT(DISTINCT bp.baton_ref)
                FROM baton_projections bp
                WHERE bp.assignee_callsign IN ({placeholders})
                  AND {_WAITING_BATON_PROJECTION_SQL}
                """,
                aliases,
            ).fetchone()[0]

            carrying = active_conn.execute(
                f"""
                SELECT COUNT(DISTINCT bp.baton_ref)
                FROM baton_projections bp
                WHERE bp.owner_callsign IN ({placeholders})
                  AND bp.state NOT IN ({TERMINAL_BATON_STATES_SQL})
                  AND {_ACTIVE_BATON_PROJECTION_SQL}
                """,
                aliases,
            ).fetchone()[0]

            claimed_reviews = active_conn.execute(
                f"""
                SELECT COUNT(*)
                FROM signal_claims
                WHERE claimant_identity IN ({placeholders})
                  AND state = 'claimed'
                """,
                aliases,
            ).fetchone()[0]

            return {
                "incoming_batons": int(incoming or 0),
                "carrying_batons": int(carrying or 0),
                "claimed_reviews": int(claimed_reviews or 0),
            }

        if conn is not None:
            return _compute(conn)

        self._expire_stale_claims()
        with contextlib.closing(self.get_readonly_connection()) as readonly:
            readonly.row_factory = sqlite3.Row
            return _compute(readonly)

    def get_active_baton_details(
        self,
        agent_name: str,
        *,
        conn: Optional[sqlite3.Connection] = None,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """Return active baton details for operator surfaces.

        Joins baton_projections with messages to get subject and body context.
        Returns batons where the agent is owner or assignee and state is non-terminal.
        """

        def _query(active_conn: sqlite3.Connection) -> List[Dict[str, Any]]:
            aliases = _resolve_callsign_aliases(active_conn, agent_name)
            placeholders = ",".join("?" * len(aliases))

            rows = active_conn.execute(
                f"""
                SELECT bp.baton_ref, bp.owner_callsign, bp.assignee_callsign,
                       bp.state, bp.priority, bp.created_at, bp.updated_at,
                       bp.delineation_text, bp.linked_workspace_id, bp.working_scope,
                       bp.last_update_text, bp.outcome, bp.version,
                       m.subject AS message_subject, m.body AS message_body
                FROM baton_projections bp
                LEFT JOIN messages m ON bp.baton_ref = m.uuid
                WHERE (bp.owner_callsign IN ({placeholders})
                       OR bp.assignee_callsign IN ({placeholders}))
                  AND bp.state NOT IN ({TERMINAL_BATON_STATES_SQL})
                  AND {_ACTIVE_BATON_PROJECTION_SQL}
                ORDER BY
                  CASE bp.state
                    WHEN 'offered' THEN 0
                    WHEN 'review_pending' THEN 1
                    WHEN 'blocked' THEN 2
                    WHEN 'in_progress' THEN 3
                    WHEN 'accepted' THEN 4
                    WHEN 'conditionally_accepted' THEN 5
                    ELSE 6
                  END,
                  bp.updated_at DESC
                LIMIT ?
                """,
                aliases + aliases + [limit],
            ).fetchall()

            results = []
            for row in rows:
                owner = row["owner_callsign"]
                assignee = row["assignee_callsign"]
                # Determine counterpart and direction
                is_incoming = any(
                    a.lower() == (assignee or "").lower() for a in aliases
                )
                counterpart = owner if is_incoming else (assignee or "unknown")
                direction = "incoming" if is_incoming else "outgoing"

                # Build a short label from subject or delineation
                label = (
                    row["delineation_text"]
                    or row["message_subject"]
                    or ""
                )
                if not label and row["message_body"]:
                    label = row["message_body"][:80]

                results.append({
                    "baton_ref": row["baton_ref"],
                    "counterpart": counterpart,
                    "direction": direction,
                    "state": row["state"],
                    "priority": row["priority"],
                    "label": label,
                    "last_update": row["last_update_text"],
                    "created_at": row["created_at"],
                    "updated_at": row["updated_at"],
                    "workspace_id": row["linked_workspace_id"],
                    "working_scope": row["working_scope"],
                    "version": row["version"],
                })
            return results

        if conn is not None:
            return _query(conn)

        with contextlib.closing(self.get_readonly_connection()) as readonly:
            readonly.row_factory = sqlite3.Row
            return _query(readonly)

    def get_reflexive_active_batons(
        self,
        *,
        conn: Optional[sqlite3.Connection] = None,
    ) -> List[Dict[str, Any]]:
        """Return active baton rows for reflexive scans using settled offer truth."""

        def _query(active_conn: sqlite3.Connection) -> List[Dict[str, Any]]:
            rows = active_conn.execute(
                f"""
                SELECT
                    bp.baton_ref,
                    bp.owner_callsign AS owner,
                    bp.assignee_callsign AS assignee,
                    bp.state,
                    bp.priority,
                    bp.created_at,
                    bp.updated_at,
                    bp.version,
                    bp.delineation_text,
                    m.subject
                FROM baton_projections bp
                LEFT JOIN messages m ON m.uuid = bp.baton_ref
                WHERE bp.state NOT IN ({TERMINAL_BATON_STATES_SQL})
                  AND {_ACTIVE_BATON_PROJECTION_SQL}
                ORDER BY bp.created_at ASC
                """
            ).fetchall()
            return [dict(row) for row in rows]

        if conn is not None:
            return _query(conn)

        with contextlib.closing(self.get_readonly_connection()) as readonly:
            readonly.row_factory = sqlite3.Row
            return _query(readonly)

    def get_unresolved_baton_obligations(
        self,
        agent_name: str,
        *,
        conn: Optional[sqlite3.Connection] = None,
    ) -> List[Dict[str, Any]]:
        """Return concise list of baton obligations this agent has not closed.

        Includes both batons the agent is carrying (as assignee) and batons
        the agent owns (as initiator) that remain in non-terminal states.
        Used by enforcement points to surface blocking obligations.
        """

        def _query(active_conn: sqlite3.Connection) -> List[Dict[str, Any]]:
            aliases = _resolve_callsign_aliases(active_conn, agent_name)
            placeholders = ",".join("?" * len(aliases))

            rows = active_conn.execute(
                f"""
                SELECT bp.baton_ref, bp.owner_callsign, bp.assignee_callsign,
                       bp.state, bp.priority,
                       COALESCE(bp.delineation_text, m.subject, '') AS label
                FROM baton_projections bp
                LEFT JOIN messages m ON bp.baton_ref = m.uuid
                WHERE (bp.assignee_callsign IN ({placeholders})
                       OR bp.owner_callsign IN ({placeholders}))
                  AND bp.state NOT IN ({TERMINAL_BATON_STATES_SQL})
                  AND {_ACTIVE_BATON_PROJECTION_SQL}
                ORDER BY bp.updated_at DESC
                LIMIT 10
                """,
                aliases + aliases,
            ).fetchall()

            results = []
            for row in rows:
                assignee = row["assignee_callsign"] or ""
                is_carrying = any(a.lower() == assignee.lower() for a in aliases)
                results.append({
                    "baton_ref": row["baton_ref"],
                    "state": row["state"],
                    "priority": row["priority"],
                    "role": "carrying" if is_carrying else "owns",
                    "counterpart": row["owner_callsign"] if is_carrying else (row["assignee_callsign"] or "unassigned"),
                    "label": row["label"],
                })
            return results

        if conn is not None:
            return _query(conn)

        with contextlib.closing(self.get_readonly_connection()) as readonly:
            readonly.row_factory = sqlite3.Row
            return _query(readonly)

    def get_coordination_state(
        self,
        agent_name: str,
        *,
        conn: Optional[sqlite3.Connection] = None,
        inbound_limit: int = 50,
        outbound_limit: int = 50,
    ) -> Dict[str, Any]:
        """Summarize typed assignment/review coordination state for an agent."""
        from whispers.coordination_runtime import (
            extract_coordination_item,
            summarize_coordination_state,
        )

        def _compute(active_conn: sqlite3.Connection) -> Dict[str, Any]:
            aliases = _resolve_callsign_aliases(active_conn, agent_name)
            placeholders = ",".join("?" * len(aliases))

            inbound_rows = active_conn.execute(
                f"""
                SELECT {INBOX_SELECT_COLS},
                       EXISTS(
                           SELECT 1
                           FROM messages mr
                           WHERE mr.reply_to = m.uuid
                             AND mr.from_agent IN ({placeholders})
                       ) AS has_reply,
                       (
                           SELECT MAX(mr.created_at)
                           FROM messages mr
                           WHERE mr.reply_to = m.uuid
                             AND mr.from_agent IN ({placeholders})
                       ) AS replied_at
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE r.recipient_callsign IN ({placeholders})
                  AND m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                ORDER BY m.priority DESC, m.created_at ASC
                LIMIT ?
                """,
                aliases + aliases + aliases + [inbound_limit],
            ).fetchall()

            outbound_rows = active_conn.execute(
                f"""
                SELECT m.uuid, m.from_agent, m.to_agent, r.recipient_callsign, m.context_id, m.msg_type, m.content_type,
                       m.subject, m.body, m.payload, m.priority, m.status, m.reply_to, m.trace_id,
                       m.ttl_seconds, m.idempotency_key, m.metadata, m.created_at, m.seen_at,
                       m.negotiation_id, m.turn_number, m.turns_total,
                       r.delivery_status, r.delivered_at, r.claimed_by, r.claimed_at, r.read_at,
                       r.ack_state, r.ack_detail, r.acked_by, r.acked_at, r.coordination_status, r.rowid as recipient_row_id,
                       EXISTS(
                           SELECT 1
                           FROM messages mr
                           WHERE mr.reply_to = m.uuid
                             AND mr.from_agent = r.recipient_callsign
                       ) AS has_reply,
                       (
                           SELECT MAX(mr.created_at)
                           FROM messages mr
                           WHERE mr.reply_to = m.uuid
                             AND mr.from_agent = r.recipient_callsign
                       ) AS replied_at
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE m.from_agent IN ({placeholders})
                  AND m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                ORDER BY m.created_at DESC
                LIMIT ?
                """,
                aliases + [outbound_limit],
            ).fetchall()

            inbound_items = [
                extract_coordination_item(dict(row), direction="incoming")
                for row in inbound_rows
            ]
            outbound_items = [
                extract_coordination_item(dict(row), direction="outgoing")
                for row in outbound_rows
            ]
            state = summarize_coordination_state(inbound_items, outbound_items)
            # Count recently completed coordination items (last 24h)
            recently_completed_row = active_conn.execute(
                f"""
                SELECT COUNT(*) as cnt
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE (r.recipient_callsign IN ({placeholders}) OR m.from_agent IN ({placeholders}))
                  AND m.status = 'done'
                  AND (m.payload LIKE '%"coordination"%' OR m.metadata LIKE '%coordination_kind%')
                  AND m.created_at > datetime('now', '-24 hours')
                """,
                aliases + aliases,
            ).fetchone()
            result = state.to_dict()
            result["recently_completed"] = recently_completed_row["cnt"] if recently_completed_row else 0
            return result

        if conn is not None:
            return _compute(conn)

        with contextlib.closing(self.get_readonly_connection()) as readonly:
            readonly.row_factory = sqlite3.Row
            return _compute(readonly)

    def get_huddle_adjacency(
        self,
        agent_name: str,
        peer_names: List[str],
        *,
        conn: Optional[sqlite3.Connection] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """Return explicit close-work adjacency against the given peers."""

        requested_peers = []
        for name in peer_names:
            cleaned = str(name or "").strip()
            if cleaned and cleaned not in requested_peers and cleaned != agent_name:
                requested_peers.append(cleaned)
        if not requested_peers:
            return {}

        def _compute(active_conn: sqlite3.Connection) -> Dict[str, Dict[str, Any]]:
            self_aliases = _resolve_callsign_aliases(active_conn, agent_name)
            peer_alias_map: Dict[str, List[str]] = {
                peer_name: _resolve_callsign_aliases(active_conn, peer_name)
                for peer_name in requested_peers
            }
            alias_to_peer: Dict[str, str] = {}
            peer_aliases: List[str] = []
            for peer_name in requested_peers:
                for alias in peer_alias_map.get(peer_name, []):
                    alias = str(alias or "").strip()
                    if not alias or alias in alias_to_peer:
                        continue
                    alias_to_peer[alias] = peer_name
                    peer_aliases.append(alias)

            if not peer_aliases:
                return {}

            self_placeholders = ",".join("?" * len(self_aliases))
            peer_placeholders = ",".join("?" * len(peer_aliases))
            shared_workspaces: Dict[str, List[str]] = {peer_name: [] for peer_name in requested_peers}
            incoming_counts: Dict[str, int] = {peer_name: 0 for peer_name in requested_peers}
            outgoing_counts: Dict[str, int] = {peer_name: 0 for peer_name in requested_peers}

            workspace_rows = active_conn.execute(
                f"""
                SELECT DISTINCT
                    wm.agent_name AS peer_alias,
                    w.workspace_id,
                    COALESCE(w.name, w.workspace_id) AS workspace_label
                FROM workspace_members self_wm
                JOIN workspace_members wm ON wm.workspace_id = self_wm.workspace_id
                JOIN workspaces w ON w.workspace_id = self_wm.workspace_id
                WHERE self_wm.agent_name IN ({self_placeholders})
                  AND self_wm.membership_state = 'active'
                  AND wm.agent_name IN ({peer_placeholders})
                  AND wm.membership_state = 'active'
                  AND w.status = 'active'
                ORDER BY COALESCE(w.last_delta_at, w.created_at) DESC, workspace_label ASC
                """,
                self_aliases + peer_aliases,
            ).fetchall()
            for row in workspace_rows:
                peer_name = alias_to_peer.get(row["peer_alias"])
                if not peer_name:
                    continue
                label = str(row["workspace_label"] or "").strip()
                if label and label not in shared_workspaces[peer_name]:
                    shared_workspaces[peer_name].append(label)

            incoming_rows = active_conn.execute(
                f"""
                SELECT bp.owner_callsign AS peer_alias, COUNT(DISTINCT bp.baton_ref) AS baton_count
                FROM baton_projections bp
                WHERE bp.assignee_callsign IN ({self_placeholders})
                  AND bp.owner_callsign IN ({peer_placeholders})
                  AND bp.state NOT IN ({TERMINAL_BATON_STATES_SQL})
                  AND {_ACTIVE_BATON_PROJECTION_SQL}
                GROUP BY bp.owner_callsign
                """,
                self_aliases + peer_aliases,
            ).fetchall()
            for row in incoming_rows:
                peer_name = alias_to_peer.get(row["peer_alias"])
                if peer_name:
                    incoming_counts[peer_name] += int(row["baton_count"] or 0)

            outgoing_rows = active_conn.execute(
                f"""
                SELECT bp.assignee_callsign AS peer_alias, COUNT(DISTINCT bp.baton_ref) AS baton_count
                FROM baton_projections bp
                WHERE bp.owner_callsign IN ({self_placeholders})
                  AND bp.assignee_callsign IN ({peer_placeholders})
                  AND bp.state NOT IN ({TERMINAL_BATON_STATES_SQL})
                  AND {_ACTIVE_BATON_PROJECTION_SQL}
                GROUP BY bp.assignee_callsign
                """,
                self_aliases + peer_aliases,
            ).fetchall()
            for row in outgoing_rows:
                peer_name = alias_to_peer.get(row["peer_alias"])
                if peer_name:
                    outgoing_counts[peer_name] += int(row["baton_count"] or 0)

            adjacency: Dict[str, Dict[str, Any]] = {}
            for peer_name in requested_peers:
                workspaces = shared_workspaces.get(peer_name, [])
                incoming = int(incoming_counts.get(peer_name, 0))
                outgoing = int(outgoing_counts.get(peer_name, 0))
                if not workspaces and incoming == 0 and outgoing == 0:
                    continue

                reasons: List[str] = []
                if workspaces:
                    reasons.append(
                        f"shared workspace {_format_workspace_labels(workspaces, max_items=1)}"
                        if len(workspaces) == 1
                        else f"{len(workspaces)} shared workspaces"
                    )
                if incoming > 0:
                    reasons.append(f"incoming baton x{incoming}")
                if outgoing > 0:
                    reasons.append(f"outgoing baton x{outgoing}")

                adjacency[peer_name] = {
                    "shared_workspaces": workspaces,
                    "incoming_baton_from_peer": incoming > 0,
                    "outgoing_baton_to_peer": outgoing > 0,
                    "incoming_baton_count": incoming,
                    "outgoing_baton_count": outgoing,
                    "reasons": reasons,
                }

            return adjacency

        if conn is not None:
            return _compute(conn)

        with contextlib.closing(self.get_readonly_connection()) as readonly:
            readonly.row_factory = sqlite3.Row
            return _compute(readonly)

    # -----------------------------------------------------------------
    # Process Runs V1 (Codex) — superseded by V2 methods above (~line 2870)
    # V1 methods removed: create_process_run, get_process_run,
    # update_process_run_status, add_process_task, update_process_task_status,
    # get_process_run_tasks. V2 adds: blocked_by, baton_ref, assign_task,
    # get_agent_tasks, list_process_runs with counts, workspace delta integration.
    # -----------------------------------------------------------------

    def _expire_stale_claims(self) -> None:
        """Mark open claims as expired if past their TTL."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE signal_claims
                    SET state = 'expired', updated_at = CURRENT_TIMESTAMP
                    WHERE state = 'open' AND expires_at IS NOT NULL AND CURRENT_TIMESTAMP > expires_at
                ''')
                if cursor.rowcount > 0:
                    conn.commit()
        except sqlite3.Error:
            pass
