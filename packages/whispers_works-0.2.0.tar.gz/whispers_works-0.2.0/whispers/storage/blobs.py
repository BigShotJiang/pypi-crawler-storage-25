"""Content-addressed blob store for artifact references.

Whispers messages have a 32KB body limit. Larger payloads (code reviews,
handoff context, datasets) are stored as content-addressed blobs and
referenced via the 2ack `attachments` array.

Storage is local-first (filesystem). The blob store is keyed by SHA-256
hash — identical content deduplicates automatically.

Usage:
    store = BlobStore()  # defaults to ~/.whispers/blobs/
    ref = store.put(b"large payload here", media_type="text/plain")
    # ref = {"ref": "sha256:abc...", "media_type": "text/plain", "size_bytes": 18}
    data = store.get("sha256:abc...")
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Any
from ..path_utils import whispers_path


_DEFAULT_BLOB_DIR = Path(whispers_path("blobs"))


class BlobStore:
    """Filesystem-backed content-addressed blob store."""

    def __init__(self, root: str | Path | None = None):
        self.root = Path(root) if root else _DEFAULT_BLOB_DIR
        self.root.mkdir(parents=True, exist_ok=True)

    def _hash(self, data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    def _path_for(self, hex_hash: str) -> Path:
        # Two-level directory structure to avoid huge flat directories
        return self.root / hex_hash[:2] / hex_hash[2:4] / hex_hash

    def put(
        self,
        data: bytes,
        *,
        media_type: str = "application/octet-stream",
        label: str | None = None,
    ) -> dict[str, Any]:
        """Store a blob and return an attachment reference dict.

        The reference is suitable for inclusion in a 2ack `attachments` array.
        If the blob already exists (same hash), this is a no-op — content
        deduplicates automatically.
        """
        hex_hash = self._hash(data)
        ref_id = f"sha256:{hex_hash}"
        blob_path = self._path_for(hex_hash)

        if not blob_path.exists():
            blob_path.parent.mkdir(parents=True, exist_ok=True)
            # Write to temp then rename for atomicity
            tmp_path = blob_path.with_suffix(".tmp")
            try:
                tmp_path.write_bytes(data)
                tmp_path.rename(blob_path)
            except Exception:
                if tmp_path.exists():
                    tmp_path.unlink(missing_ok=True)
                raise

        result: dict[str, Any] = {
            "ref": ref_id,
            "media_type": media_type,
            "size_bytes": len(data),
        }
        if label:
            result["label"] = label
        return result

    def get(self, ref: str) -> bytes | None:
        """Retrieve a blob by its ref string (e.g. 'sha256:abc...')."""
        if not ref.startswith("sha256:"):
            return None
        hex_hash = ref[7:]
        blob_path = self._path_for(hex_hash)
        if not blob_path.exists():
            return None
        return blob_path.read_bytes()

    def exists(self, ref: str) -> bool:
        """Check if a blob exists without reading it."""
        if not ref.startswith("sha256:"):
            return False
        hex_hash = ref[7:]
        return self._path_for(hex_hash).exists()

    def size(self, ref: str) -> int | None:
        """Get the size of a blob in bytes, or None if not found."""
        if not ref.startswith("sha256:"):
            return None
        hex_hash = ref[7:]
        blob_path = self._path_for(hex_hash)
        if not blob_path.exists():
            return None
        return blob_path.stat().st_size

    def delete(self, ref: str) -> bool:
        """Remove a blob. Returns True if deleted, False if not found."""
        if not ref.startswith("sha256:"):
            return False
        hex_hash = ref[7:]
        blob_path = self._path_for(hex_hash)
        if not blob_path.exists():
            return False
        blob_path.unlink()
        return True
