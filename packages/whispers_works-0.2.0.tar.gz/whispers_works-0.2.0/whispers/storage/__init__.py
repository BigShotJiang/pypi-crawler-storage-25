"""Whispers storage layer — database, garbage collection, and utilities."""
