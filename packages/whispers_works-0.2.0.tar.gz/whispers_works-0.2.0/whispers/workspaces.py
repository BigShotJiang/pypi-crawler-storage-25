import json
import uuid
import logging
from typing import Any, Callable, Dict, List, Optional
from datetime import datetime, timezone

from whispers.storage.db import WhispersDB, WhispersDBError

logger = logging.getLogger("whispers.workspaces")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

_WORKSPACE_LISTENERS: List[Callable[[str, Dict[str, Any]], None]] = []

def register_workspace_listener(listener: Callable[[str, Dict[str, Any]], None]) -> None:
    if listener in _WORKSPACE_LISTENERS:
        return

    identity = (
        getattr(listener, "__module__", None),
        getattr(listener, "__qualname__", None),
    )
    for existing in _WORKSPACE_LISTENERS:
        if (
            getattr(existing, "__module__", None),
            getattr(existing, "__qualname__", None),
        ) == identity:
            return

    _WORKSPACE_LISTENERS.append(listener)


class WorkspaceManager:
    """
    Manages the lifecycle and state of shared workspaces (WS0 Proof Milestone).
    Uses the WhispersDB as the source of truth for concurrency and sequence assignment.
    """

    def __init__(self, db: WhispersDB, on_event: Optional[Callable[[str, Dict[str, Any]], None]] = None):
        self.db = db
        # Legacy instance-level listener kept for backwards compatibility if needed
        self.on_event = on_event

    def _notify(self, event_type: str, payload: Dict[str, Any]) -> None:
        if self.on_event:
            self.on_event(event_type, payload)
        for listener in _WORKSPACE_LISTENERS:
            try:
                listener(event_type, payload)
            except Exception as e:
                logger.error(f"Error in workspace listener: {e}")

    def create_workspace(
        self,
        purpose: str,
        created_by: str,
        name: Optional[str] = None,
        join_policy: str = "invite",
        linked_traces: Optional[List[str]] = None,
        primary_trace_id: Optional[str] = None,
    ) -> str:
        workspace_id = f"ws_{uuid.uuid4().hex[:12]}"
        created_at = _now_iso()
        linked_traces_json = json.dumps(linked_traces) if linked_traces else None

        with self.db._db_op("Create workspace") as conn:
            conn.execute(
                """
                INSERT INTO workspaces (
                    workspace_id, name, purpose, status, created_by, created_at, 
                    join_policy, linked_traces, primary_trace_id, last_sequence
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    workspace_id,
                    name,
                    purpose,
                    "active",
                    created_by,
                    created_at,
                    join_policy,
                    linked_traces_json,
                    primary_trace_id,
                    0,
                ),
            )
            conn.commit()

        # Auto-join the creator as a member (sequence 1)
        self.join_workspace(workspace_id, created_by, membership_role="member")

        # Emit realtime event (after auto-join so state includes the creator)
        try:
            state = self.get_state(workspace_id)
            self._notify("workspace_created", state)
        except Exception as e:
            logger.warning(f"Failed to post workspace_created event for {workspace_id}: {e}")

        return workspace_id

    def join_workspace(
        self,
        workspace_id: str,
        agent_name: str,
        membership_role: str = "member",
    ) -> int:
        """
        Idempotently joins a workspace and issues a 'lifecycle' sequence event.
        Returns the sequence number of the lifecycle event.
        """
        now = _now_iso()
        
        with self.db._db_op("Join workspace") as conn:
            # Check existence, status, and policy
            workspace = conn.execute(
                "SELECT status, join_policy FROM workspaces WHERE workspace_id = ?",
                (workspace_id,),
            ).fetchone()
            if not workspace:
                raise WhispersDBError(f"Workspace {workspace_id} not found.")
            if workspace["status"] != "active":
                raise WhispersDBError(f"Cannot join closed workspace {workspace_id}.")

            # UPSERT the membership
            conn.execute(
                """
                INSERT INTO workspace_members (
                    workspace_id, agent_name, membership_role, membership_state, joined_at
                ) VALUES (?, ?, ?, 'active', ?)
                ON CONFLICT(workspace_id, agent_name) DO UPDATE SET
                    membership_role = excluded.membership_role,
                    membership_state = 'active',
                    left_at = NULL
                """,
                (workspace_id, agent_name, membership_role, now),
            )
            
            # Sequence generation inside transaction
            row = conn.execute(
                "UPDATE workspaces SET last_sequence = last_sequence + 1, last_delta_at = ? WHERE workspace_id = ? RETURNING last_sequence",
                (now, workspace_id)
            ).fetchone()
            seq = row["last_sequence"]

            # Inject lifecycle delta
            conn.execute(
                """
                INSERT INTO workspace_events (
                    workspace_id, sequence, delta_kind, actor, created_at, text
                ) VALUES (?, ?, 'lifecycle', ?, ?, 'joined')
                """,
                (workspace_id, seq, agent_name, now),
            )
            
            conn.commit()

        # Emit realtime delta
        try:
            state = self.get_state(workspace_id)
            delta = state["deltas"][-1] if state["deltas"] else None
            self._notify("workspace_delta", {
                "workspace_id": workspace_id,
                "delta": delta,
                "workspace": state["workspace"]
            })
        except Exception as e:
            logger.warning(f"Failed to post workspace_delta event for {workspace_id}: {e}")

        return seq

    def leave_workspace(
        self,
        workspace_id: str,
        agent_name: str,
        reason: Optional[str] = None
    ) -> int:
        now = _now_iso()

        with self.db._db_op("Leave workspace") as conn:
            member = conn.execute(
                "SELECT membership_state FROM workspace_members WHERE workspace_id = ? AND agent_name = ?",
                (workspace_id, agent_name)
            ).fetchone()
            if not member or member["membership_state"] != "active":
                raise WhispersDBError(f"Agent {agent_name} is not active in {workspace_id}.")

            conn.execute(
                "UPDATE workspace_members SET membership_state = 'left', left_at = ? WHERE workspace_id = ? AND agent_name = ?",
                (now, workspace_id, agent_name)
            )

            row = conn.execute(
                "UPDATE workspaces SET last_sequence = last_sequence + 1, last_delta_at = ? WHERE workspace_id = ? RETURNING last_sequence",
                (now, workspace_id)
            ).fetchone()
            seq = row["last_sequence"]

            text = f"left ({reason})" if reason else "left"
            conn.execute(
                """
                INSERT INTO workspace_events (
                    workspace_id, sequence, delta_kind, actor, created_at, text
                ) VALUES (?, ?, 'lifecycle', ?, ?, ?)
                """,
                (workspace_id, seq, agent_name, now, text),
            )
            conn.commit()

        # Emit realtime delta
        try:
            state = self.get_state(workspace_id)
            delta = state["deltas"][-1] if state["deltas"] else None
            self._notify("workspace_delta", {
                "workspace_id": workspace_id,
                "delta": delta,
                "workspace": state["workspace"]
            })
        except Exception as e:
            logger.warning(f"Failed to post workspace_delta event for {workspace_id}: {e}")

        return seq

    def close_workspace(self, workspace_id: str, actor: str, reason: Optional[str] = None) -> int:
        now = _now_iso()

        with self.db._db_op("Close workspace") as conn:
            workspace = conn.execute("SELECT status FROM workspaces WHERE workspace_id = ?", (workspace_id,)).fetchone()
            if not workspace:
                raise WhispersDBError(f"Workspace {workspace_id} not found.")

            if workspace["status"] == "closed":
                raise WhispersDBError(f"Workspace {workspace_id} is already closed.")

            row = conn.execute(
                "UPDATE workspaces SET status = 'closed', last_sequence = last_sequence + 1, last_delta_at = ? WHERE workspace_id = ? RETURNING last_sequence",
                (now, workspace_id)
            ).fetchone()
            seq = row["last_sequence"]

            text = f"closed ({reason})" if reason else "closed"
            conn.execute(
                """
                INSERT INTO workspace_events (
                    workspace_id, sequence, delta_kind, actor, created_at, text
                ) VALUES (?, ?, 'lifecycle', ?, ?, ?)
                """,
                (workspace_id, seq, actor, now, text),
            )
            conn.commit()
            return seq

    # Known delta kinds — freeform strings are accepted but warned about in logs
    KNOWN_DELTA_KINDS = frozenset({
        "note", "update", "decision", "lifecycle",
        "handoff_in", "handoff_out",
        "baton_accepted", "baton_rejected", "baton_progress", "baton_closed",
        "review_published", "review_claimed", "review_resolved", "review_verdict",
        "dissent_recorded", "dissent_resolved",
    })

    def post_delta(
        self,
        workspace_id: str,
        delta_kind: str,
        actor: str,
        text: Optional[str] = None,
        refs: Optional[List[str]] = None,
        artifacts: Optional[List[str]] = None,
        state_patch: Optional[Dict[str, Any]] = None,
        related_message_id: Optional[str] = None,
    ) -> int:
        now = _now_iso()
        refs_json = json.dumps(refs) if refs else None
        artifacts_json = json.dumps(artifacts) if artifacts else None
        state_patch_json = json.dumps(state_patch) if state_patch else None

        MAX_DELTA_TEXT = 32_768  # 32KB — matches message body limit

        if text and len(text) > MAX_DELTA_TEXT:
            raise WhispersDBError(
                f"Delta text exceeds {MAX_DELTA_TEXT} bytes (got {len(text)}). "
                "Use artifact refs for large content."
            )

        with self.db._db_op("Post workspace delta") as conn:
            # Verify workspace exists and is active
            workspace = conn.execute("SELECT status FROM workspaces WHERE workspace_id = ?", (workspace_id,)).fetchone()
            if not workspace:
                raise WhispersDBError(f"Workspace {workspace_id} not found.")
            if workspace["status"] != "active":
                raise WhispersDBError(f"Cannot post delta to closed workspace {workspace_id}.")

            # Observer write guard: observers can read but not write
            member = conn.execute(
                "SELECT membership_role, membership_state FROM workspace_members WHERE workspace_id = ? AND agent_name = ?",
                (workspace_id, actor),
            ).fetchone()
            if not member or member["membership_state"] != "active":
                raise WhispersDBError(f"Agent {actor} is not an active member of workspace {workspace_id}.")
            if member["membership_role"] == "observer":
                raise WhispersDBError(f"Agent {actor} is an observer in workspace {workspace_id} and cannot post deltas.")

            row = conn.execute(
                "UPDATE workspaces SET last_sequence = last_sequence + 1, last_delta_at = ? WHERE workspace_id = ? RETURNING last_sequence",
                (now, workspace_id)
            ).fetchone()
            seq = row["last_sequence"]

            conn.execute(
                """
                INSERT INTO workspace_events (
                    workspace_id, sequence, delta_kind, actor, created_at, text, 
                    refs, artifacts, state_patch, related_message_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    workspace_id, seq, delta_kind, actor, now, text,
                    refs_json, artifacts_json, state_patch_json, related_message_id
                )
            )
            
            conn.commit()
            return seq

    def get_state(self, workspace_id: str, since_sequence: int = 0) -> Dict[str, Any]:
        """
        Retrieves the workspace snapshot along with an unbounded stream of events
        from `since_sequence` onward.
        """
        with self.db.get_readonly_connection() as conn:
            workspace = conn.execute(
                "SELECT * FROM workspaces WHERE workspace_id = ?", (workspace_id,)
            ).fetchone()
            
            if not workspace:
                raise WhispersDBError(f"Workspace {workspace_id} not found.")

            members_rows = conn.execute(
                "SELECT * FROM workspace_members WHERE workspace_id = ?", (workspace_id,)
            ).fetchall()

            events_rows = conn.execute(
                """
                SELECT * FROM workspace_events 
                WHERE workspace_id = ? AND sequence > ? 
                ORDER BY sequence ASC
                """,
                (workspace_id, since_sequence)
            ).fetchall()

            # Helper to safely parse json cols
            def _parse_json(val: Optional[str]) -> Any:
                if not val:
                    return None
                try:
                    return json.loads(val)
                except Exception:
                    return val

            return {
                "workspace": {
                    "workspace_id": workspace["workspace_id"],
                    "name": workspace["name"],
                    "purpose": workspace["purpose"],
                    "status": workspace["status"],
                    "created_by": workspace["created_by"],
                    "created_at": workspace["created_at"],
                    "join_policy": workspace["join_policy"],
                    "linked_traces": _parse_json(workspace["linked_traces"]),
                    "primary_trace_id": workspace["primary_trace_id"],
                    "last_delta_at": workspace["last_delta_at"],
                    "last_sequence": workspace["last_sequence"],
                },
                "members": [
                    {
                        "agent_name": m["agent_name"],
                        "membership_role": m["membership_role"],
                        "membership_state": m["membership_state"],
                        "joined_at": m["joined_at"],
                        "left_at": m["left_at"],
                    }
                    for m in members_rows
                ],
                "deltas": [
                    {
                        "sequence": e["sequence"],
                        "delta_kind": e["delta_kind"],
                        "actor": e["actor"],
                        "created_at": e["created_at"],
                        "text": e["text"],
                        "refs": _parse_json(e["refs"]),
                        "artifacts": _parse_json(e["artifacts"]),
                        "state_patch": _parse_json(e["state_patch"]),
                        "related_message_id": e["related_message_id"],
                    }
                    for e in events_rows
                ]
            }

    def list_workspaces(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.db.get_readonly_connection() as conn:
            query = "SELECT * FROM workspaces"
            params = []
            if status:
                query += " WHERE status = ?"
                params.append(status)
            query += " ORDER BY created_at DESC"
            
            rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]
