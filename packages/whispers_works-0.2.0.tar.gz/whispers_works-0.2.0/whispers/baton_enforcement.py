from __future__ import annotations

from typing import Any, Dict, Iterable, List


YIELD_BLOCKING_READINESS_STATES = frozenset({"ready", "paused_by_operator"})


def yield_blocking_baton_obligations(obligations: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Return only baton obligations that should block a clean yield.

    Carrying an unresolved baton means the agent has accepted or been offered
    work that still needs an explicit lifecycle transition. Owner-side batons
    stay visible elsewhere, but they are not enough on their own to block
    reopening capacity.
    """

    blockers: List[Dict[str, Any]] = []
    for obligation in obligations:
        if str(obligation.get("role") or "").strip().lower() == "carrying":
            blockers.append(obligation)
    return blockers


def format_yield_blocked_message(readiness: str, obligations: Iterable[Dict[str, Any]]) -> str:
    blockers = yield_blocking_baton_obligations(obligations)
    count = len(blockers)
    state_label = str(readiness or "").strip().upper() or "READY"
    noun = "baton" if count == 1 else "batons"
    summary = (
        f"Cannot set readiness to {state_label} while carrying {count} unresolved {noun}. "
        "Use baton_update to report progress or baton_close to close the baton before yielding."
    )
    if not blockers:
        return summary

    samples = []
    for obligation in blockers[:2]:
        label = str(obligation.get("label") or obligation.get("baton_ref") or "unnamed baton").strip()
        state = str(obligation.get("state") or "unknown").strip()
        samples.append(f"{label} [{state}]")
    return summary + " Open: " + "; ".join(samples)
