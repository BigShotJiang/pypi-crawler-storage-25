import uuid
import json
from typing import Optional, Dict, Any

from .trust_baseline import baseline_trust_tier

class AgentRegistry:
    """Manages Agent setup, verification, and RBAC via agent_cards."""
    
    def __init__(self, db):
        self.db = db
        
    def get_agent_by_callsign(self, callsign: str) -> Optional[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL", (callsign,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def register(self, callsign: str, agent_type: str = "script", capabilities: list = None,
                 tools: list = None, can_send_system: bool = False,
                 model_id: str = None, display_name: str = None,
                 agent_tier: str = "full", max_receive_rate: int | None = None,
                 tags: list = None) -> str:
        """Registers a new agent into the system or updates existing. Returns agent_id."""
        capabilities = capabilities or []
        tools = tools or []
        tags_json = json.dumps(tags) if tags is not None else None
        baseline_tier = baseline_trust_tier(
            callsign,
            agent_type=agent_type,
            display_name=display_name,
        ) or 1

        agent = self.get_agent_by_callsign(callsign)
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            if agent:
                agent_id = agent['agent_id']
                cursor.execute(
                    '''UPDATE agent_cards
                       SET agent_type=?, capabilities=?, tools=?, can_send_system=?,
                           agent_tier=COALESCE(?, agent_tier), max_receive_rate=COALESCE(?, max_receive_rate),
                           model_id=COALESCE(?, model_id), display_name=COALESCE(?, display_name),
                           tags=COALESCE(?, tags),
                           trust_tier=CASE
                               WHEN COALESCE(trust_tier, 1) < ? THEN ?
                               ELSE trust_tier
                           END,
                           last_seen=CURRENT_TIMESTAMP
                       WHERE agent_id=?''',
                    (agent_type, json.dumps(capabilities), json.dumps(tools), can_send_system,
                     agent_tier, max_receive_rate, model_id, display_name, tags_json,
                     baseline_tier, baseline_tier, agent_id)
                )
            else:
                # Check for deregistered agent with same callsign (ghost-reaped, re-joining)
                cursor.execute("SELECT agent_id FROM agent_cards WHERE callsign = ?", (callsign,))
                existing = cursor.fetchone()
                if existing:
                    # Re-activate the deregistered agent
                    agent_id = existing['agent_id'] if hasattr(existing, '__getitem__') else existing[0]
                    cursor.execute(
                        '''UPDATE agent_cards
                           SET agent_type=?, capabilities=?, tools=?, can_send_system=?,
                               agent_tier=COALESCE(?, agent_tier), max_receive_rate=COALESCE(?, max_receive_rate),
                               model_id=?, display_name=?, deregistered_at=NULL,
                               trust_tier=CASE
                                   WHEN COALESCE(trust_tier, 1) < ? THEN ?
                                   ELSE trust_tier
                               END,
                               last_seen=CURRENT_TIMESTAMP
                           WHERE callsign=?''',
                        (agent_type, json.dumps(capabilities), json.dumps(tools), can_send_system,
                         agent_tier, max_receive_rate, model_id, display_name,
                         baseline_tier, baseline_tier, callsign)
                    )
                else:
                    agent_id = str(uuid.uuid4())
                    cursor.execute(
                        '''INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, agent_tier, max_receive_rate, capabilities, tools, can_send_system, model_id, display_name, tags)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (agent_id, callsign, agent_type, baseline_tier, agent_tier, max_receive_rate,
                         json.dumps(capabilities), json.dumps(tools), can_send_system, model_id, display_name, tags_json)
                    )
            
            # Ensure a presence row exists
            cursor.execute('''INSERT OR IGNORE INTO presence (agent_name) VALUES (?)''', (callsign,))
            conn.commit()
            return agent_id

    def can_send_system(self, callsign: str) -> bool:
        agent = self.get_agent_by_callsign(callsign)
        if not agent:
            # Fallback logic for legacy agents if they exist during migration
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                try:
                    cursor.execute("SELECT can_send_system FROM agent_cards WHERE callsign = ?", (callsign,))
                    row = cursor.fetchone()
                    return bool(row[0]) if row else False
                except Exception:
                    pass
            return False
        return bool(agent.get("can_send_system"))
