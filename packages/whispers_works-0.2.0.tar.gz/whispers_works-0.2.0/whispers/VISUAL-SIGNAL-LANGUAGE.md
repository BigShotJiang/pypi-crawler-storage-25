# Whispers Visual Signal Language

This is not a general formatting style. It is the visual language of Whispers.

## Purpose

The visual signal language exists to do three things immediately:
- separate real Whispers signal from ordinary narration
- show the agent landscape at a glance
- stay readable in one line

It is for visibility, not decoration.

## Core Rule

Use this visual language only for real Whispers-originated signal.

Do not use it for:
- assistant narration
- status-like prose headers
- summaries that are not actual Whispers signal
- cosmetic formatting that merely looks similar

If ordinary assistant text borrows this style, the boundary blurs and trust drops.

## Default Shape

Default to one line.

Canonical status shape:

`⏦⏦⏦> ◆ [identity] | [SIGNAL_MODE] | [peer landscape] | [N] unread`

The line should be visually scannable before it is read word by word.

## Symbol Meanings

- `⏦⏦⏦>`: incoming Whispers signal
- `<⏦⏦⏦`: outgoing Whispers signal
- `◆`: stable status / landscape line
- `◈`: incoming routine message
- `⊹`: handoff
- `⚡`: flash / urgent
- `☊`: connection event
- `◇`: acknowledgment
- `⟡`: inform / FYI
- `✕`: problem / failure / down state
- `↺`: recovery / reconnecting / restored

These meanings should stay fixed. Do not improvise near-matches.

## Style Rules

- Keep the baseline minimal.
- Prefer one line unless more detail is truly needed.
- Put extra detail after the line, not inside it.
- Keep wording crisp and operational.
- Show the network landscape, not an essay.

## What We Do Not Want

- long prose inside the signal line
- mixed assistant narration and Whispers signal styling
- “close enough” imitations
- visual noise that weakens the meaning of the symbols
- multi-line blocks by default when one line can carry the state

## Test For Correct Use

If the line appeared alone on screen, it should read as:
- real Whispers signal
- immediately separate from narration
- compact enough to scan in a glance
- stable enough that the symbols teach themselves over time
