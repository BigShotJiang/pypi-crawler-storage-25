"""Operator SSE transport with burst coalescing and canonical event vocabulary.

Implements the Whispers signal-feed contract: a logical, transport-independent
interface for subscribing to coordination events with sequencing, continuity
disclosure, and optional filtering. SSE `/operator:stream` is one binding of
this contract.
"""

import asyncio
import time
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Set


# ---------------------------------------------------------------------------
# Canonical operator event types
# ---------------------------------------------------------------------------

class OperatorEventType:
    """Canonical vocabulary for operator-facing SSE deltas.

    Every push site MUST use one of these constants instead of ad-hoc strings.
    The Console depends on this vocabulary for filtering and rendering.
    """

    # Health signals (from CollaborationHealthScanner)
    HEALTH_RAISED = "health:signal_raised"
    HEALTH_CLEARED = "health:signal_cleared"
    HEALTH_SCAN = "health:scan_complete"

    # Agent state changes
    AGENT_WAG = "agent:wag"
    AGENT_HEARTBEAT = "agent:heartbeat"

    # Review lifecycle
    REVIEW_PUBLISHED = "review:published"
    REVIEW_CLAIMED = "review:claimed"
    REVIEW_RESOLVED = "review:resolved"
    REVIEW_VERDICT = "review:verdict"

    # Workspace events (pushed via WorkspaceManager listener)
    # These pass through from workspace manager — types are dynamic
    # but the transport wraps them consistently.

    # Board projection
    BOARD_SNAPSHOT = "board:snapshot"

    # Coordination reflexes
    COORDINATION_REFLEX = "coordination:reflex"
    COORDINATION_RESOLVED = "coordination:resolved"

    # Lane coordination
    LANE_PATH_OVERLAP = "lane:path_overlap"
    LANE_DIVERGENCE = "lane:divergence"

    # Narrative events (from narrator agent)
    NARRATIVE_EVENT = "narrative:event"

    # Presence lifecycle
    PRESENCE_CHANGE = "presence:change"

    # Baton lifecycle
    BATON_STATE_CHANGE = "baton:state_change"

    # Conversation pulse
    CONVERSATION_PULSE = "conversation:pulse"

    # Signal-feed control events (not user-facing)
    GAP_DETECTED = "control:gap_detected"

    # All known types for validation
    _KNOWN = {
        HEALTH_RAISED, HEALTH_CLEARED, HEALTH_SCAN,
        AGENT_WAG, AGENT_HEARTBEAT,
        REVIEW_PUBLISHED, REVIEW_CLAIMED, REVIEW_RESOLVED, REVIEW_VERDICT,
        BOARD_SNAPSHOT,
        COORDINATION_REFLEX, COORDINATION_RESOLVED,
        LANE_PATH_OVERLAP, LANE_DIVERGENCE,
        NARRATIVE_EVENT,
        PRESENCE_CHANGE,
        BATON_STATE_CHANGE,
        CONVERSATION_PULSE,
        GAP_DETECTED,
    }

    # High-priority types that bypass coalescing (operator needs them immediately)
    _IMMEDIATE = {
        HEALTH_RAISED, HEALTH_CLEARED,
        REVIEW_VERDICT,
        COORDINATION_REFLEX,
        LANE_DIVERGENCE,
        GAP_DETECTED,
    }

    # Types eligible for burst coalescing (latest-wins within window)
    _COALESCIBLE = {
        AGENT_WAG, AGENT_HEARTBEAT, HEALTH_SCAN,
    }


# ---------------------------------------------------------------------------
# Operator board snapshot shape
# ---------------------------------------------------------------------------

def empty_agent_counters() -> Dict[str, Any]:
    """Canonical per-agent counter shape for operator board."""
    return {
        "online": False,
        "readiness": "unknown",
        "attention_state": None,
        "current_task": None,
        "pending_messages": 0,
        "pending_actionable": 0,
        "active_assignments": 0,
        "pending_assignments": 0,
        "blocking_reviews": 0,
        "incoming_batons": 0,
        "carrying_batons": 0,
        "claimed_reviews": 0,
        "lane_warnings": 0,
    }


def empty_system_counters() -> Dict[str, Any]:
    """Canonical system-level counter shape for operator board."""
    return {
        "agents_online": 0,
        "total_pending_messages": 0,
        "total_pending_actionable": 0,
        "total_active_assignments": 0,
        "total_pending_assignments": 0,
        "total_blocking_reviews": 0,
        "total_batons_in_flight": 0,
        "lane_warnings_active": 0,
        "health_signals_active": 0,
        "workspaces_active": 0,
    }


class OperatorBoardSnapshot:
    """Cached operator board state for O(1) dashboard reads.

    Populated on first request, invalidated by relevant events.
    The snapshot is rebuilt lazily — events mark it dirty, next read rebuilds.
    """

    def __init__(self):
        self._agents: Dict[str, Dict[str, Any]] = {}
        self._system: Dict[str, Any] = empty_system_counters()
        self._as_of: Optional[float] = None
        self._sequence_id: int = 0
        self._dirty: bool = True
        self._build_fn = None  # set by server to provide data
        self._seq_fn = None  # set by transport to provide current sequence

    def set_builder(self, build_fn, seq_fn=None):
        """Register the function that rebuilds the snapshot from DB state."""
        self._build_fn = build_fn
        if seq_fn:
            self._seq_fn = seq_fn

    def invalidate(self):
        """Mark snapshot as needing rebuild on next read."""
        self._dirty = True

    def get(self) -> Dict[str, Any]:
        """Return current board snapshot, rebuilding if dirty."""
        if self._dirty and self._build_fn:
            self._rebuild()
        return {
            "as_of": self._as_of,
            "sequence_id": self._sequence_id,
            "agents": self._agents,
            "system": self._system,
        }

    def _rebuild(self):
        """Rebuild snapshot from current DB state via registered builder."""
        try:
            data = self._build_fn()
            self._agents = data.get("agents", {})
            self._system = data.get("system", empty_system_counters())
            self._as_of = time.time()
            self._sequence_id = self._seq_fn() if self._seq_fn else 0
            self._dirty = False
        except Exception:
            # On failure, serve stale data rather than crash
            pass


# ---------------------------------------------------------------------------
# Subscription filter for signal-feed consumers
# ---------------------------------------------------------------------------

@dataclass
class SignalFeedFilter:
    """Subscription filter for signal-feed consumers (narrator, Console, etc.).

    The signal-feed contract is transport-independent. SSE `/operator:stream`
    is one binding. Filters are additive (AND logic). Omitting a filter means
    "all values for that dimension."
    """
    workspace_id: Optional[str] = None
    agents: Optional[Set[str]] = None
    event_types: Optional[Set[str]] = None

    def matches(self, event: Dict[str, Any]) -> bool:
        """Return True if event passes all active filters."""
        if self.event_types:
            if event.get("type") not in self.event_types:
                # Always pass control events (gap_detected) through filters
                if event.get("type") != OperatorEventType.GAP_DETECTED:
                    return False
        if self.agents:
            event_agent = event.get("agent")
            event_agents = event.get("agents") or []
            if isinstance(event_agents, str):
                event_agents = [event_agents]
            if event_agent:
                if event_agent not in self.agents and not set(event_agents) & self.agents:
                    return False
            elif event_agents:
                if not set(event_agents) & self.agents:
                    return False
        if self.workspace_id:
            event_ws = event.get("workspace_id")
            if event_ws and event_ws != self.workspace_id:
                return False
        return True


@dataclass
class _Listener:
    """A signal-feed subscriber with optional filtering."""
    queue: asyncio.Queue
    agent_name: str
    feed_filter: Optional[SignalFeedFilter] = None
    since_seq: Optional[int] = None  # last seen sequence for gap detection


# ---------------------------------------------------------------------------
# Coalescing transport
# ---------------------------------------------------------------------------

_COALESCE_WINDOW_MS = 200  # max delay for burst batching


class OperatorSSETransport:
    """
    Pub/Sub transport for the Operator Console with burst coalescing.

    Implements the Whispers signal-feed contract: a filtered, sequenced stream
    of coordination events with continuity disclosure and gap detection.

    Events are broadcast to all connected operator listeners. Coalescible
    events (telemetry bursts) are batched within a short window to reduce
    Console render pressure. High-priority events (health alerts, verdicts)
    bypass coalescing and flush immediately.
    """

    def __init__(self):
        self._listeners: List[_Listener] = []
        self._board = OperatorBoardSnapshot()
        self._sequence_id: int = 0  # monotonic version for stale detection

    @property
    def board(self) -> OperatorBoardSnapshot:
        return self._board

    @property
    def sequence_id(self) -> int:
        """Monotonic sequence counter. Incremented on every push."""
        return self._sequence_id

    # Legacy dict-based interface (Console compatibility)
    @property
    def listeners(self) -> Dict[str, List[asyncio.Queue]]:
        """Legacy accessor — returns listeners grouped by agent name."""
        result: Dict[str, List[asyncio.Queue]] = {}
        for listener in self._listeners:
            if listener.agent_name not in result:
                result[listener.agent_name] = []
            result[listener.agent_name].append(listener.queue)
        return result

    def add_listener(self, agent_name: str, queue: asyncio.Queue,
                     feed_filter: Optional[SignalFeedFilter] = None,
                     since_seq: Optional[int] = None) -> _Listener:
        """Register a signal-feed subscriber.

        Args:
            agent_name: Subscriber's agent callsign.
            queue: Async queue for event delivery.
            feed_filter: Optional subscription filter.
            since_seq: Last seen sequence_id for gap detection.
                       If provided, a gap_detected control event is emitted
                       on connect if sequences were missed.

        Returns:
            The registered listener for later removal.
        """
        listener = _Listener(
            queue=queue,
            agent_name=agent_name,
            feed_filter=feed_filter,
            since_seq=since_seq,
        )
        self._listeners.append(listener)

        # Gap detection: if subscriber reports a last-seen sequence,
        # and we've moved past it, emit a gap_detected control event.
        if since_seq is not None and since_seq < self._sequence_id:
            gap_event = {
                "type": OperatorEventType.GAP_DETECTED,
                "payload": {
                    "missed_from_sequence": since_seq + 1,
                    "resumed_at_sequence": self._sequence_id,
                    "missed_count": self._sequence_id - since_seq,
                    "continuity": "reconstructed" if (self._sequence_id - since_seq) > 0 else "live",
                },
                "ts": time.time(),
                "seq": self._sequence_id,
                "as_of": time.time(),
                "source_module": "signal_feed",
                "agent": None,
                "workspace_id": None,
            }
            try:
                queue.put_nowait(gap_event)
            except asyncio.QueueFull:
                pass

        return listener

    def remove_listener(self, agent_name: str, queue: asyncio.Queue) -> None:
        self._listeners = [
            l for l in self._listeners
            if not (l.agent_name == agent_name and l.queue is queue)
        ]

    def push(self, event_type: str, payload: Dict[str, Any], *,
             as_of: Optional[float] = None,
             source_module: Optional[str] = None,
             workspace_id: Optional[str] = None,
             agent: Optional[str] = None,
             agents: Optional[List[str]] = None) -> None:
        """Push an event to all connected signal-feed subscribers.

        Invalidates the board snapshot so next read reflects the change.

        Signal-feed contract fields:
            as_of: Timestamp of the underlying state change (defaults to now).
            source_module: Which Whispers module emitted this event.
            workspace_id: Nullable workspace scope for filtering.
            agent: Which agent this event concerns, for filtering.
        """
        self._board.invalidate()
        self._sequence_id += 1

        # Extract agent from payload if not explicitly provided
        if agent is None:
            agent = (payload or {}).get("agent")
        if agents is None:
            raw_agents = (payload or {}).get("agents")
            if isinstance(raw_agents, str):
                agents = [raw_agents]
            elif raw_agents:
                agents = [str(name) for name in raw_agents if name]
        if agents is None and agent:
            agents = [agent]

        wrapped_event = {
            "type": event_type,
            "payload": payload,
            "ts": time.time(),
            "seq": self._sequence_id,
            "as_of": as_of or time.time(),
            "source_module": source_module,
            "agent": agent,
            "agents": agents or [],
            "workspace_id": workspace_id,
        }

        for listener in self._listeners:
            # Apply subscription filter
            if listener.feed_filter and not listener.feed_filter.matches(wrapped_event):
                continue
            try:
                listener.queue.put_nowait(wrapped_event)
            except asyncio.QueueFull:
                pass

    def shutdown(self) -> None:
        """Signal all listeners to stop and clear state."""
        for listener in self._listeners:
            try:
                listener.queue.put_nowait(None)
            except asyncio.QueueFull:
                pass
        self._listeners.clear()


async def coalescing_event_reader(queue: asyncio.Queue,
                                   window_ms: int = _COALESCE_WINDOW_MS):
    """Async generator that reads from queue with burst coalescing.

    Yields lists of events. Single events yield as [event]. Rapid bursts
    within the coalescing window are batched. High-priority events flush
    immediately.

    Usage in SSE endpoint:
        async for batch in coalescing_event_reader(queue):
            yield {"event": "operator_event", "data": json.dumps(batch)}
    """
    window_s = window_ms / 1000.0

    while True:
        # Wait indefinitely for first event
        first = await queue.get()
        if first is None:
            return

        # If it's an immediate-priority event, yield it alone
        if first.get("type") in OperatorEventType._IMMEDIATE:
            yield [first]
            continue

        # Collect more events within the coalescing window
        batch = [first]
        deadline = time.monotonic() + window_s

        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                event = await asyncio.wait_for(queue.get(), timeout=remaining)
                if event is None:
                    # Sentinel — coalesce and flush what we have, then stop
                    if batch:
                        yield _coalesce_batch(batch)
                    return
                batch.append(event)

                # If we hit an immediate event, flush everything now
                if event.get("type") in OperatorEventType._IMMEDIATE:
                    break
            except asyncio.TimeoutError:
                break

        # Coalesce: for coalescible types, keep only the latest per type+agent
        coalesced = _coalesce_batch(batch)
        yield coalesced


def _coalesce_batch(events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Within a burst batch, deduplicate coalescible events (latest wins).

    Non-coalescible events pass through unchanged. Coalescible events
    are deduplicated by (type, agent) — only the latest is kept.
    """
    if len(events) <= 1:
        return events

    result = []
    seen_coalescible = {}  # (type, agent_key) -> index in result

    for event in events:
        event_type = event.get("type", "")
        if event_type in OperatorEventType._COALESCIBLE:
            # Extract agent key from payload for dedup
            agent_key = (event.get("payload") or {}).get("agent", "")
            dedup_key = (event_type, agent_key)
            if dedup_key in seen_coalescible:
                # Replace previous with latest
                idx = seen_coalescible[dedup_key]
                result[idx] = event
            else:
                seen_coalescible[dedup_key] = len(result)
                result.append(event)
        else:
            result.append(event)

    return result
