from ..envelope import Envelope

class Transport:
    """Base transport interface that the Dispatcher triggers upon delivery."""
    def push(self, envelope: Envelope) -> None:
        pass
