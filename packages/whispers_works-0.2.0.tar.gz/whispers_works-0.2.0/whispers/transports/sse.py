import asyncio
import os
from typing import Callable, Dict, List
from ..envelope import Envelope
from .base import Transport

class SSETransport(Transport):
    """
    Pub/Sub transport bridge to Starlette/FastAPI SSE endpoints.
    Allows clients to keep a connection open and receive Dispatcher pushes.
    """
    def __init__(self, *, observability_mode_getter: Callable[[], str] | None = None):
        self.listeners: Dict[str, List[asyncio.Queue]] = {}
        self._observability_mode_getter = observability_mode_getter or (
            lambda: os.environ.get("WHISPERS_OBSERVABILITY_MODE", "metadata").strip().lower()
        )
        self.console_tap_enabled = os.environ.get("WHISPERS_ENABLE_CONSOLE_TAP", "1").strip().lower() not in {"0", "false", "no"}

    @property
    def observability_mode(self) -> str:
        return self._observability_mode_getter()

    def add_listener(self, agent_name: str, queue: asyncio.Queue) -> None:
        if agent_name not in self.listeners:
            self.listeners[agent_name] = []
        self.listeners[agent_name].append(queue)

    def remove_listener(self, agent_name: str, queue: asyncio.Queue) -> None:
        if agent_name in self.listeners and queue in self.listeners[agent_name]:
            self.listeners[agent_name].remove(queue)
            if not self.listeners[agent_name]:
                del self.listeners[agent_name]

    def push(self, envelope: Envelope, target_agent: str = None) -> None:
        """Called synchronously by the Dispatcher when an Envelope triggers delivery."""
        targets = []
        routing_key = target_agent or envelope.recipient
        if routing_key in self.listeners:
            targets.extend((queue, envelope) for queue in self.listeners[routing_key])
            
        # Global Observability Tap for Phase 4 Dashboard
        if (
            self.console_tap_enabled
            and "whispers-console" in self.listeners
            and envelope.recipient != "whispers-console"
            and not getattr(envelope, "_console_tapped", False)
        ):
            setattr(envelope, "_console_tapped", True)
            console_envelope = envelope if self.observability_mode == "full" else self._redacted_console_copy(envelope)
            targets.extend((queue, console_envelope) for queue in self.listeners["whispers-console"])

        for q, queued_envelope in targets:
            try:
                q.put_nowait(queued_envelope)
            except asyncio.QueueFull:
                pass

    def shutdown(self) -> None:
        """Drain all listener queues and clear listeners for graceful shutdown."""
        listener_count = sum(len(qs) for qs in self.listeners.values())
        if listener_count:
            # Signal all listeners to stop by putting None sentinel
            for agent_name, queues in list(self.listeners.items()):
                for q in queues:
                    try:
                        q.put_nowait(None)
                    except asyncio.QueueFull:
                        pass
            self.listeners.clear()

    @staticmethod
    def _redacted_console_copy(envelope: Envelope) -> Envelope:
        return Envelope(
            sender=envelope.sender,
            recipient=envelope.recipient,
            subject="[redacted]",
            body=None,
            payload=None,
            priority=envelope.priority,
            msg_type=envelope.msg_type,
            content_type=envelope.content_type,
            version=envelope.version,
            id=envelope.id,
            context_id=envelope.context_id,
            reply_to=envelope.reply_to,
            trace_id=envelope.trace_id,
            ttl_seconds=envelope.ttl_seconds,
            idempotency_key=envelope.idempotency_key,
            metadata={"observability_redacted": True, "observability_mode": "metadata"},
            created_at=envelope.created_at,
        )
