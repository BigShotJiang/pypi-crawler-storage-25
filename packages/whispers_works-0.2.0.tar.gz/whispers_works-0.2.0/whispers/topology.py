"""Topology Enrichment — collaboration-aware agent state derivation.

Extends presence beyond simple online/offline by synthesizing multiple
signals into a single collaboration topology state. This tells the
operator not just whether an agent is healthy, but what it's doing
in the collaboration.

Design ref: .planning/NEXT-BUILD-ORDER-COLLABORATION-RUNTIME.md (Item 7)

Derivation inputs:
  - wag() cognitive_state: listening, building, exploring, blocked, eureka, winding_down
  - readiness: ready, busy, blocked, warming, paused_by_operator, degraded
  - derived_active_mode: ready, offline, degraded, overloaded, blocked, busy, warming
  - handoff state: whether the agent is carrying an unacknowledged baton
  - workspace activity: recent delta kinds (note, update, decision, review)

Output:
  - topology_state: one of the canonical collaboration states
  - topology_detail: human-readable explanation of why
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, Optional


class TopologyState(str, Enum):
    """Canonical collaboration-aware agent states.

    These describe what an agent is doing in the collaboration,
    not just whether it's healthy.
    """
    AVAILABLE = "available"           # free to take work
    BUSY = "busy"                     # actively building/working
    BLOCKED = "blocked"               # stuck, needs help
    REVIEWING = "reviewing"           # reviewing someone else's work
    SYNTHESIZING = "synthesizing"     # combining research/inputs
    CARRYING_BATON = "carrying_baton" # has an undelivered/unacked handoff
    WINDING_DOWN = "winding_down"     # finishing up, about to go idle
    DEGRADED = "degraded"             # quality risk or system issue
    OFFLINE = "offline"               # not connected


# Map wag cognitive_state -> default topology state
_WAG_TO_TOPOLOGY = {
    "listening": TopologyState.AVAILABLE,
    "idle": TopologyState.AVAILABLE,
    "building": TopologyState.BUSY,
    "exploring": TopologyState.BUSY,
    "eureka": TopologyState.BUSY,
    "blocked": TopologyState.BLOCKED,
    "winding_down": TopologyState.WINDING_DOWN,
}

# Map readiness -> topology state (used as override when stronger signal)
_READINESS_TO_TOPOLOGY = {
    "blocked": TopologyState.BLOCKED,
    "paused_by_operator": TopologyState.BLOCKED,
    "degraded": TopologyState.DEGRADED,
    "warming": TopologyState.AVAILABLE,
}


def derive_topology_state(
    *,
    cognitive_state: Optional[str] = None,
    readiness: Optional[str] = None,
    derived_active_mode: Optional[str] = None,
    has_pending_handoff: bool = False,
    recent_workspace_kinds: Optional[list[str]] = None,
    intent: Optional[str] = None,
) -> tuple[TopologyState, str]:
    """Derive a collaboration-aware topology state from available signals.

    Returns (state, detail) where detail explains the derivation.
    Signals are checked in priority order — stronger signals override weaker ones.
    """
    recent_kinds = recent_workspace_kinds or []

    # Priority 1: Offline
    if derived_active_mode == "offline":
        return TopologyState.OFFLINE, "Agent is offline"

    # Priority 2: Degraded (system-level issue overrides everything)
    if derived_active_mode in ("degraded", "overloaded"):
        return TopologyState.DEGRADED, f"Agent is {derived_active_mode}"
    if readiness in ("degraded",):
        return TopologyState.DEGRADED, "Agent reported degraded readiness"

    # Priority 3: Blocked (explicit signal)
    if readiness in ("blocked", "paused_by_operator"):
        detail = "Paused by operator" if readiness == "paused_by_operator" else "Agent is blocked"
        return TopologyState.BLOCKED, detail
    if cognitive_state == "blocked":
        return TopologyState.BLOCKED, "Agent reported blocked state"

    # Priority 4: Carrying baton (has undelivered handoff)
    if has_pending_handoff:
        return TopologyState.CARRYING_BATON, "Agent has an unacknowledged handoff to deliver"

    # Priority 5: Reviewing (inferred from workspace activity or intent)
    if "review" in recent_kinds or "decision" in recent_kinds:
        return TopologyState.REVIEWING, "Recent workspace activity includes review/decision"
    if intent and any(kw in intent.lower() for kw in ("review", "audit", "check", "verify")):
        return TopologyState.REVIEWING, f"Intent suggests reviewing: {intent[:60]}"

    # Priority 6: Synthesizing (inferred from workspace activity or intent)
    if intent and any(kw in intent.lower() for kw in ("synthesiz", "research", "compar", "analyz")):
        return TopologyState.SYNTHESIZING, f"Intent suggests synthesizing: {intent[:60]}"

    # Priority 7: Winding down
    if cognitive_state == "winding_down":
        return TopologyState.WINDING_DOWN, "Agent is winding down"

    # Priority 8: Busy (actively working)
    if cognitive_state in ("building", "exploring", "eureka"):
        return TopologyState.BUSY, f"Agent is {cognitive_state}"
    if readiness == "busy":
        return TopologyState.BUSY, "Agent reported busy readiness"

    # Default: Available
    return TopologyState.AVAILABLE, "Agent is available for work"


def enrich_agent_presence(agent: Dict[str, Any], *, has_pending_handoff: bool = False) -> Dict[str, Any]:
    """Add topology_state and topology_detail to an agent presence record.

    Non-destructive — returns a new dict with the added fields.
    """
    enriched = dict(agent)
    state, detail = derive_topology_state(
        cognitive_state=agent.get("cognitive_state"),
        readiness=agent.get("readiness"),
        derived_active_mode=agent.get("derived_active_mode"),
        has_pending_handoff=has_pending_handoff,
        intent=agent.get("intent") or agent.get("working_on"),
    )
    enriched["topology_state"] = state.value
    enriched["topology_detail"] = detail
    return enriched
