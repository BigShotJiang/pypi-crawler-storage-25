"""Repo / Worktree Coordination — explicit branch and lane state for agents.

Makes repo alignment a first-class runtime concept so agents and operators
can see which branch/worktree each agent is actually using, detect divergence,
and track lane ownership without relying on tribal knowledge.

Design ref: .planning/REPO-WORKTREE-COORDINATION.md

This module provides:
  - RepoState: data model for an agent's current repo position
  - RepoCoordinator: in-memory tracker of all agents' repo states
  - Lane state tracking: active, handoff_pending, superseded, archived
  - Divergence detection: warns when agents believe they're aligned but aren't
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional


# --- Data model ---

@dataclass
class RepoState:
    """An agent's current repo/worktree position."""
    agent_name: str
    repo_path: Optional[str] = None
    worktree_id: Optional[str] = None
    branch: Optional[str] = None
    base_commit: Optional[str] = None    # commit the branch was created from
    head_commit: Optional[str] = None    # current HEAD
    dirty: bool = False                  # uncommitted changes
    lane_state: str = "active"           # active | handoff_pending | superseded | archived
    claimed_paths: Optional[List[str]] = None  # file paths this agent owns
    workspace_id: Optional[str] = None   # linked workspace if any
    upstream_ref: Optional[str] = None   # upstream tracking branch
    published_at: Optional[str] = None   # ISO 8601 UTC

    def to_dict(self) -> dict:
        return {
            "agent_name": self.agent_name,
            "repo_path": self.repo_path,
            "worktree_id": self.worktree_id,
            "branch": self.branch,
            "base_commit": self.base_commit,
            "head_commit": self.head_commit,
            "dirty": self.dirty,
            "lane_state": self.lane_state,
            "claimed_paths": self.claimed_paths,
            "workspace_id": self.workspace_id,
            "upstream_ref": self.upstream_ref,
            "published_at": self.published_at,
        }

    @property
    def short_head(self) -> str:
        """First 7 chars of head commit, or 'unknown'."""
        return (self.head_commit or "unknown")[:7]

    @property
    def headline(self) -> str:
        """Human-readable one-liner."""
        dirty_mark = "*" if self.dirty else ""
        branch = self.branch or "detached"
        state = f" [{self.lane_state}]" if self.lane_state != "active" else ""
        return f"{self.agent_name}: {branch}{dirty_mark} @ {self.short_head}{state}"


@dataclass
class PathOverlapWarning:
    """Warning when two agents claim overlapping file paths."""
    agent_a: str
    agent_b: str
    overlapping_paths: List[str]

    def to_dict(self) -> dict:
        return {
            "agent_a": self.agent_a,
            "agent_b": self.agent_b,
            "overlapping_paths": self.overlapping_paths,
        }


@dataclass
class DivergenceWarning:
    """Warning when agents appear to be on conflicting lanes."""
    agent_a: str
    agent_b: str
    reason: str        # "different_branches", "same_branch_different_heads", "superseded_lane"
    detail: str        # human-readable explanation

    def to_dict(self) -> dict:
        return {
            "agent_a": self.agent_a,
            "agent_b": self.agent_b,
            "reason": self.reason,
            "detail": self.detail,
        }


# --- Coordinator ---

class RepoCoordinator:
    """In-memory tracker of all agents' repo states.

    Thread-safe. Call publish() when an agent reports its repo position,
    then query get_lanes() for the operator view or check_divergence()
    for alignment warnings.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._states: Dict[str, RepoState] = {}

    def publish(self, state: RepoState) -> List["PathOverlapWarning"]:
        """Publish or update an agent's repo state.

        Returns a list of path overlap warnings if the agent's claimed_paths
        collide with another active agent's claimed_paths.
        """
        state.published_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        overlaps = self._detect_path_overlaps(state)
        with self._lock:
            self._states[state.agent_name] = state
        return overlaps

    def get_state(self, agent_name: str) -> Optional[RepoState]:
        """Get a specific agent's repo state."""
        with self._lock:
            return self._states.get(agent_name)

    def get_lanes(self, *, include_archived: bool = False) -> List[RepoState]:
        """Get all agents' repo states, sorted by agent name."""
        with self._lock:
            states = list(self._states.values())
        if not include_archived:
            states = [s for s in states if s.lane_state not in ("archived",)]
        states.sort(key=lambda s: s.agent_name)
        return states

    def set_lane_state(self, agent_name: str, lane_state: str) -> Optional[RepoState]:
        """Update an agent's lane state (e.g., mark as superseded)."""
        with self._lock:
            state = self._states.get(agent_name)
            if state:
                state.lane_state = lane_state
                state.published_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            return state

    def check_divergence(self) -> List[DivergenceWarning]:
        """Detect agents that may be working from conflicting assumptions.

        Checks:
        1. Agents on the same branch with different HEAD commits
        2. Agents working on a lane marked as superseded
        """
        warnings: List[DivergenceWarning] = []
        with self._lock:
            active_states = [s for s in self._states.values() if s.lane_state == "active"]

        # Check for same-branch different-heads
        branch_groups: Dict[str, List[RepoState]] = {}
        for s in active_states:
            if s.branch:
                branch_groups.setdefault(s.branch, []).append(s)

        for branch, agents in branch_groups.items():
            if len(agents) < 2:
                continue
            heads = {s.head_commit for s in agents if s.head_commit}
            if len(heads) > 1:
                names = [s.agent_name for s in agents]
                warnings.append(DivergenceWarning(
                    agent_a=names[0],
                    agent_b=names[1],
                    reason="same_branch_different_heads",
                    detail=f"Agents {', '.join(names)} are on branch '{branch}' but at different commits: {', '.join(h[:7] for h in heads)}",
                ))

        # Check for agents on superseded lanes
        with self._lock:
            for s in self._states.values():
                if s.lane_state == "superseded":
                    warnings.append(DivergenceWarning(
                        agent_a=s.agent_name,
                        agent_b="",
                        reason="superseded_lane",
                        detail=f"{s.agent_name} is on lane '{s.branch}' which is marked superseded",
                    ))

        # Check for overlapping claimed paths among active agents
        with self._lock:
            for i, s1 in enumerate(active_states):
                if not s1.claimed_paths:
                    continue
                paths1 = set(p.replace("\\", "/").rstrip("/") for p in s1.claimed_paths)
                for s2 in active_states[i+1:]:
                    if not s2.claimed_paths:
                        continue
                    paths2 = set(p.replace("\\", "/").rstrip("/") for p in s2.claimed_paths)
                    
                    direct = paths1 & paths2
                    prefix_overlaps = set()
                    for p1 in paths1:
                        for p2 in paths2:
                            if p1.startswith(p2 + "/") or p2.startswith(p1 + "/"):
                                prefix_overlaps.add(min(p1, p2, key=len))
                    
                    overlapping = direct | prefix_overlaps
                    if overlapping:
                        warnings.append(DivergenceWarning(
                            agent_a=s1.agent_name,
                            agent_b=s2.agent_name,
                            reason="overlapping_claims",
                            detail=f"Agents {s1.agent_name} and {s2.agent_name} have overlapping claimed paths: {', '.join(sorted(overlapping))}",
                        ))

        return warnings

    def _detect_path_overlaps(self, new_state: RepoState) -> List[PathOverlapWarning]:
        """Check if new_state's claimed_paths overlap with any other active agent."""
        if not new_state.claimed_paths:
            return []

        new_paths = set(p.replace("\\", "/").rstrip("/") for p in new_state.claimed_paths)
        warnings: List[PathOverlapWarning] = []

        with self._lock:
            for name, existing in self._states.items():
                if name == new_state.agent_name:
                    continue
                if existing.lane_state != "active":
                    continue
                if not existing.claimed_paths:
                    continue

                existing_paths = set(
                    p.replace("\\", "/").rstrip("/") for p in existing.claimed_paths
                )

                # Direct match
                direct = new_paths & existing_paths
                # Prefix containment (one path is parent of another)
                prefix_overlaps = set()
                for np in new_paths:
                    for ep in existing_paths:
                        if np.startswith(ep + "/") or ep.startswith(np + "/"):
                            prefix_overlaps.add(min(np, ep, key=len))

                overlapping = direct | prefix_overlaps
                if overlapping:
                    warnings.append(PathOverlapWarning(
                        agent_a=new_state.agent_name,
                        agent_b=name,
                        overlapping_paths=sorted(overlapping),
                    ))

        return warnings

    def clear(self) -> None:
        """Reset all state."""
        with self._lock:
            self._states.clear()


# --- Module-level singleton ---

_coordinator: Optional[RepoCoordinator] = None
_coordinator_lock = threading.Lock()


def get_coordinator() -> RepoCoordinator:
    """Get or create the global RepoCoordinator singleton."""
    global _coordinator
    if _coordinator is None:
        with _coordinator_lock:
            if _coordinator is None:
                _coordinator = RepoCoordinator()
    return _coordinator
