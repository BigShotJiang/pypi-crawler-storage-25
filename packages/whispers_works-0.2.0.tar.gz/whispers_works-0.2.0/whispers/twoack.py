from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal

from .time_utils import parse_timestamp

ERR_MALFORMED_ENVELOPE = "ERR_MALFORMED_ENVELOPE"
ERR_WIRE_VERSION = "ERR_WIRE_VERSION"
ERR_UNSUPPORTED_SCHEMA = "ERR_UNSUPPORTED_SCHEMA"
ERR_SCHEMA_INVALID = "ERR_SCHEMA_INVALID"
ERR_EXPIRED = "ERR_EXPIRED"
ERR_HOP_LIMIT_EXCEEDED = "ERR_HOP_LIMIT_EXCEEDED"
ERR_NEGOTIATION_FAILED = "ERR_NEGOTIATION_FAILED"
ERR_TRUST_INSUFFICIENT = "ERR_TRUST_INSUFFICIENT"
ERR_DELEGATION_PROOF_REQUIRED = "ERR_DELEGATION_PROOF_REQUIRED"

MAX_ENVELOPE_DEPTH = 7
MAX_STRING_FIELD_BYTES = 65_536       # 64KB — hard cap on any single string field
MAX_SUMMARY_FIELD_BYTES = 10_240      # 10KB — summaries should be concise
MAX_THREAD_DEPTH = 100                # prevent unbounded thread nesting

_REQUIRED_ENVELOPE_FIELDS = {"wire_v", "schema", "trace", "payload"}
_SCHEMA_ID_RE = re.compile(r"^[a-z][a-z0-9_]*\.v[1-9][0-9]*$")
_RFC3339_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}"
    r"T\d{2}:\d{2}:\d{2}"
    r"(?:\.\d+)?"
    r"(?:Z|[+-]\d{2}:\d{2})$"
)
_PAYLOAD_HASH_RE = re.compile(r"^sha256:[0-9a-f]{64}$", re.IGNORECASE)
_EXT_KEY_RE = re.compile(r"^(?:whispers|x-[a-z0-9][a-z0-9-]*):[A-Za-z0-9][A-Za-z0-9._-]*$")
_ALLOWED_MODES = {"human-readable", "agent-native", "bilingual"}
_ALLOWED_SIGNAL_CLASSES = {"internal", "whispers_internal", "external"}
_ALLOWED_SOURCES = {"human", "agent", "dual"}
_ALLOWED_RISK_LEVELS = {"low", "elevated", "critical"}
_ALLOWED_WORKSPACE_JOIN_POLICIES = {"invite", "open"}
_ALLOWED_WORKSPACE_MEMBERSHIP_ROLES = {"member", "observer"}
_ALLOWED_WORKSPACE_PRIORITIES = {"critical", "normal", "background"}
_ALLOWED_REVIEW_LENSES = {"correctness", "security", "architecture", "protocol", "quality", "ux", "custom"}
_ALLOWED_REVIEW_URGENCIES = {"routine", "priority", "blocking"}
_ALLOWED_REVIEW_VERDICTS = {"approve", "request_changes", "reject", "defer"}
_ALLOWED_FINDING_SEVERITIES = {"critical", "major", "minor", "advisory"}
_ALLOWED_REVISIT_TRIGGERS = {"next_checkpoint", "on_failure", "time_based", "operator_review", "never"}
_ALLOWED_DISSENT_RESOLUTIONS = {"resolved", "vindicated", "archived", "withdrawn"}
_ALLOWED_BATON_DECISIONS = {"accepted", "conditionally_accepted", "rejected"}
_ALLOWED_BATON_STATES = {"in_progress", "blocked", "review_pending"}
_ALLOWED_BATON_OUTCOMES = {"completed", "merged", "blocked", "superseded", "expired"}

# Terminal states: no further transitions allowed.
TERMINAL_BATON_STATES = frozenset({"completed", "merged", "rejected", "superseded", "expired"})

# Canonical baton state machine: current_state -> set of allowed next states.
_BATON_TERMINAL_OUTCOMES = {"completed", "merged", "superseded", "expired"}
_BATON_WORK_AND_TERMINAL = {"in_progress", "blocked", "review_pending"} | _BATON_TERMINAL_OUTCOMES
VALID_BATON_TRANSITIONS: dict[str, frozenset[str]] = {
    # offered: can be acked, rejected, or closed directly (skipping the lifecycle)
    "offered": frozenset({"accepted", "conditionally_accepted", "rejected"} | _BATON_TERMINAL_OUTCOMES),
    "accepted": frozenset(_BATON_WORK_AND_TERMINAL),
    "conditionally_accepted": frozenset(_BATON_WORK_AND_TERMINAL),
    "in_progress": frozenset({"blocked", "review_pending"} | _BATON_TERMINAL_OUTCOMES),
    "blocked": frozenset({"in_progress", "review_pending"} | _BATON_TERMINAL_OUTCOMES),
    "review_pending": frozenset({"in_progress", "blocked"} | _BATON_TERMINAL_OUTCOMES),
    # Terminal states: no transitions out.
    "completed": frozenset(),
    "merged": frozenset(),
    "rejected": frozenset(),
    "superseded": frozenset(),
    "expired": frozenset(),
}


def validate_baton_transition(current_state: str, new_state: str) -> str | None:
    """Return an error message if the transition is invalid, or None if valid."""
    allowed = VALID_BATON_TRANSITIONS.get(current_state)
    if allowed is None:
        return f"Unknown baton state: {current_state!r}"
    if current_state in TERMINAL_BATON_STATES:
        return f"Baton is in terminal state {current_state!r} and cannot be modified."
    if new_state not in allowed:
        return f"Invalid baton transition: {current_state!r} -> {new_state!r}. Allowed: {sorted(allowed)}"
    return None


# ---------------------------------------------------------------------------
# Truth Labels (2ACK-P1.6)
# ---------------------------------------------------------------------------
# Every claim in the system carries a truth label — not just what the claim
# says, but how honest it is. The label answers: where did this claim come
# from, when was it last known true, and how confident is the source?

# Basis: where the claim came from
VALID_BASIS_VALUES = frozenset({"attested", "observed", "derived", "declared"})

# Negative states: how a claim can be degraded
VALID_NEGATIVE_STATES = frozenset({
    "stale",              # claim not refreshed within expected window
    "contradicted",       # another claim or observation conflicts
    "revoked",            # original source explicitly withdrew this claim
    "insufficient_basis", # claim lacks minimum evidence for its context
    "unauthorized",       # source lacks trust tier or scope to make this claim
    "disputed",           # another participant has formally challenged this
    "quarantined",        # system isolated this claim pending review
})


@dataclass(frozen=True)
class NegativeState:
    """A typed assertion that something is wrong with a claim."""
    state: str
    reason: str | None = None
    detected_at: str | None = None
    detected_by: str | None = None

    def __post_init__(self):
        if self.state not in VALID_NEGATIVE_STATES:
            raise ValueError(f"Unknown negative state: {self.state!r}. Valid: {sorted(VALID_NEGATIVE_STATES)}")

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"state": self.state}
        if self.reason:
            d["reason"] = self.reason
        if self.detected_at:
            d["detected_at"] = self.detected_at
        if self.detected_by:
            d["detected_by"] = self.detected_by
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NegativeState:
        return cls(
            state=data["state"],
            reason=data.get("reason"),
            detected_at=data.get("detected_at"),
            detected_by=data.get("detected_by"),
        )


@dataclass(frozen=True)
class ClaimLabel:
    """Truth metadata for any field or signal in the 2ack protocol.

    Answers: where did this claim come from (basis), when was it last
    known true (as_of), how confident is the source (confidence), what
    supports it (evidence_refs), and what's wrong with it (negative_states).
    """
    basis: str | None = None
    as_of: str | None = None
    confidence: float | None = None
    evidence_refs: tuple[str, ...] = ()
    negative_states: tuple[NegativeState, ...] = ()

    def __post_init__(self):
        if self.basis is not None and self.basis not in VALID_BASIS_VALUES:
            raise ValueError(f"Unknown basis: {self.basis!r}. Valid: {sorted(VALID_BASIS_VALUES)}")
        if self.confidence is not None and not (0.0 <= self.confidence <= 1.0):
            raise ValueError(f"Confidence must be 0.0-1.0, got {self.confidence}")

    @property
    def is_stale(self) -> bool:
        return any(ns.state == "stale" for ns in self.negative_states)

    @property
    def is_degraded(self) -> bool:
        return len(self.negative_states) > 0

    def with_negative(self, state: NegativeState) -> ClaimLabel:
        """Return a new label with an additional negative state."""
        return ClaimLabel(
            basis=self.basis,
            as_of=self.as_of,
            confidence=self.confidence,
            evidence_refs=self.evidence_refs,
            negative_states=self.negative_states + (state,),
        )

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {}
        if self.basis is not None:
            d["basis"] = self.basis
        if self.as_of is not None:
            d["as_of"] = self.as_of
        if self.confidence is not None:
            d["confidence"] = self.confidence
        if self.evidence_refs:
            d["evidence_refs"] = list(self.evidence_refs)
        if self.negative_states:
            d["negative_states"] = [ns.to_dict() for ns in self.negative_states]
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ClaimLabel:
        neg = data.get("negative_states") or []
        return cls(
            basis=data.get("basis"),
            as_of=data.get("as_of"),
            confidence=data.get("confidence"),
            evidence_refs=tuple(data.get("evidence_refs") or ()),
            negative_states=tuple(NegativeState.from_dict(n) for n in neg),
        )


# ---------------------------------------------------------------------------
# Reception Truth (2ACK extension for message lifecycle)
# ---------------------------------------------------------------------------
# A message's reception state is a chain of truth claims, each with its own
# label. The server attests delivery. The agent's inbox check observes seen.
# The agent declares read. A reply or ack attests acted_on.

VALID_RECEPTION_STAGES = frozenset({
    "queued",       # server accepted, not yet delivered to agent's inbox
    "delivered",    # stored in agent's inbox (server-attested)
    "seen",         # agent's session retrieved the message (server-observed)
    "read",         # agent claims to have processed the content (agent-declared)
    "acted_on",     # agent replied, acked, or took action (server-attested)
})

# Canonical basis for each reception stage
_RECEPTION_STAGE_BASIS: dict[str, str] = {
    "queued": "attested",
    "delivered": "attested",
    "seen": "observed",
    "read": "declared",
    "acted_on": "attested",
}


@dataclass(frozen=True)
class ReceptionTruth:
    """Truth-labeled reception state for a message.

    Tracks the full lifecycle: queued -> delivered -> seen -> read -> acted_on.
    Each transition is timestamped and labeled with its basis.
    """
    stage: str
    label: ClaimLabel
    queued_at: str | None = None
    delivered_at: str | None = None
    seen_at: str | None = None
    read_at: str | None = None
    acted_on_at: str | None = None

    def __post_init__(self):
        if self.stage not in VALID_RECEPTION_STAGES:
            raise ValueError(f"Unknown reception stage: {self.stage!r}")

    @classmethod
    def at_stage(cls, stage: str, timestamp: str, **kwargs: Any) -> ReceptionTruth:
        """Create a reception truth at a given stage with canonical basis."""
        basis = _RECEPTION_STAGE_BASIS.get(stage, "declared")
        label = ClaimLabel(basis=basis, as_of=timestamp, confidence=1.0)
        ts_field = f"{stage}_at"
        timestamps = {ts_field: timestamp}
        # Carry forward earlier timestamps if provided
        for field_name in ("queued_at", "delivered_at", "seen_at", "read_at", "acted_on_at"):
            if field_name in kwargs:
                timestamps[field_name] = kwargs[field_name]
        return cls(stage=stage, label=label, **timestamps)

    def advance(self, new_stage: str, timestamp: str) -> ReceptionTruth:
        """Advance to a new stage, carrying forward all timestamps."""
        stage_order = ["queued", "delivered", "seen", "read", "acted_on"]
        current_idx = stage_order.index(self.stage)
        new_idx = stage_order.index(new_stage)
        if new_idx <= current_idx:
            raise ValueError(f"Cannot go backward: {self.stage!r} -> {new_stage!r}")
        basis = _RECEPTION_STAGE_BASIS.get(new_stage, "declared")
        label = ClaimLabel(basis=basis, as_of=timestamp, confidence=1.0)
        timestamps = {
            "queued_at": self.queued_at,
            "delivered_at": self.delivered_at,
            "seen_at": self.seen_at,
            "read_at": self.read_at,
            "acted_on_at": self.acted_on_at,
        }
        timestamps[f"{new_stage}_at"] = timestamp
        return ReceptionTruth(stage=new_stage, label=label, **timestamps)

    @property
    def is_pending_action(self) -> bool:
        """True if message has been seen/read but not acted on."""
        return self.stage in ("seen", "read") and self.acted_on_at is None

    @property
    def awaiting_read(self) -> bool:
        return self.stage in ("queued", "delivered")

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"stage": self.stage, "label": self.label.to_dict()}
        for ts_name in ("queued_at", "delivered_at", "seen_at", "read_at", "acted_on_at"):
            val = getattr(self, ts_name)
            if val is not None:
                d[ts_name] = val
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ReceptionTruth:
        return cls(
            stage=data["stage"],
            label=ClaimLabel.from_dict(data.get("label", {})),
            queued_at=data.get("queued_at"),
            delivered_at=data.get("delivered_at"),
            seen_at=data.get("seen_at"),
            read_at=data.get("read_at"),
            acted_on_at=data.get("acted_on_at"),
        )

    @classmethod
    def from_db_row(cls, row: dict[str, Any]) -> ReceptionTruth:
        """Compute ReceptionTruth from existing Whispers DB fields.

        Bridges the gap between the current message_recipients schema
        (delivery_status, read_at, ack_state, acked_at, claimed_at,
        created_at) and the 2ACK protocol type. This lets every message
        surface speak typed reception truth without a schema migration.
        """
        created = row.get("created_at")
        delivered_at = row.get("delivered_at") or row.get("claimed_at")
        read_at = row.get("read_at")
        acked_at = row.get("acked_at")
        ack_state = row.get("ack_state")
        delivery_status = str(row.get("delivery_status") or "queued").strip().lower()

        # Determine highest stage reached
        if ack_state and acked_at:
            stage = "acted_on"
            ts = acked_at
        elif read_at:
            stage = "seen"  # mark_seen = server observed retrieval
            ts = read_at
        elif delivery_status == "delivered" and delivered_at:
            stage = "delivered"
            ts = delivered_at
        elif delivery_status == "delivered":
            stage = "delivered"
            ts = created or ""
        elif delivery_status == "queued":
            stage = "queued"
            ts = created or ""
        else:
            # dead_lettered or unknown
            stage = "queued"
            ts = created or ""

        basis = _RECEPTION_STAGE_BASIS.get(stage, "declared")
        label = ClaimLabel(basis=basis, as_of=ts, confidence=1.0)

        return cls(
            stage=stage,
            label=label,
            queued_at=created,
            delivered_at=delivered_at,
            seen_at=read_at,
            read_at=None,  # no separate "agent claims read" vs "server saw retrieval" yet
            acted_on_at=acked_at,
        )


# ---------------------------------------------------------------------------
# Expectation Grammar (2ACK Attention and Expectation)
# ---------------------------------------------------------------------------
# The structured statement of what a signal wants from the receiver.
# This is the relational grammar that makes machine courtesy possible.

VALID_ATTENTION_POSTURES = frozenset({
    "ambient",           # background awareness, no action needed
    "fyi",               # worth seeing but not requiring action
    "actionable",        # needs action at some point
    "blocking",          # blocks sender's work until resolved
    "interrupt",         # should interrupt current work
})

VALID_RESPONSE_POSTURES = frozenset({
    "none",              # no reply expected
    "if_useful",         # reply only if the receiver has something to add
    "required",          # reply is expected
    "ack_then_answer",   # acknowledge receipt first, full answer later
})

VALID_TIMING_POSTURES = frozenset({
    "now",               # needs immediate attention
    "soon",              # within current work session
    "when_free",         # when the receiver has capacity
    "by_deadline",       # by a specific time (see policy_hint.reply_by)
    "only_if_blocking",  # only if nothing else is more important
})

VALID_CLOSURE_POSTURES = frozenset({
    "none",              # no explicit closure needed
    "on_state_change",   # update when something changes
    "explicit_close",    # sender expects explicit completion/closure
    "explicit_reject",   # if not taking it, say so explicitly
})

VALID_ESCALATION_POSTURES = frozenset({
    "handle_locally",    # resolve without escalation
    "escalate_if_blocked",  # escalate to operator if stuck
    "operator_required", # operator must review before action
    "no_auto_escalate",  # do not escalate automatically
})

VALID_PROOF_POSTURES = frozenset({
    "prose",             # prose explanation is sufficient
    "structured",        # structured reply schema required
    "artifact",          # artifact (commit, file, etc.) required
    "evidence_ref",      # evidence reference required
    "authority_proof",   # authority proof required
})


@dataclass(frozen=True)
class Expectation:
    """Structured statement of what a signal wants from the receiver.

    The relational grammar for attention, response, timing, closure,
    escalation, and proof. Gives Whispers and machine courtesy a clean
    structured input instead of guessing from priority + schema.
    """
    attention: str | None = None     # what kind of attention is being asked for
    response: str | None = None      # whether/what reply is expected
    timing: str | None = None        # when the response is expected
    closure: str | None = None       # what closure the sender expects
    escalation: str | None = None    # escalation posture
    proof: str | None = None         # what kind of follow-through is sufficient

    def __post_init__(self):
        _posture_sets = {
            "attention": VALID_ATTENTION_POSTURES,
            "response": VALID_RESPONSE_POSTURES,
            "timing": VALID_TIMING_POSTURES,
            "closure": VALID_CLOSURE_POSTURES,
            "escalation": VALID_ESCALATION_POSTURES,
            "proof": VALID_PROOF_POSTURES,
        }
        for field_name, valid_set in _posture_sets.items():
            value = getattr(self, field_name)
            if value is not None and value not in valid_set:
                raise ValueError(
                    f"Unknown {field_name} posture: {value!r}. Valid: {sorted(valid_set)}"
                )

    @property
    def is_blocking(self) -> bool:
        return self.attention in ("blocking", "interrupt")

    @property
    def needs_reply(self) -> bool:
        return self.response in ("required", "ack_then_answer")

    @property
    def needs_closure(self) -> bool:
        return self.closure in ("explicit_close", "explicit_reject")

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in {
            "attention": self.attention,
            "response": self.response,
            "timing": self.timing,
            "closure": self.closure,
            "escalation": self.escalation,
            "proof": self.proof,
        }.items() if v is not None}

    def to_attention_tier(self) -> str:
        """Map expectation to attention tier for the dispatcher.

        Bridges the 2ACK expectation grammar to the runtime attention
        tier system (interrupt_now / surface_now / hold_visible).
        """
        if self.attention in ("interrupt", "blocking") or self.timing == "now":
            return "interrupt_now"
        if self.attention in ("actionable",) or self.needs_reply or self.timing == "soon":
            return "surface_now"
        return "hold_visible"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Expectation:
        return cls(
            attention=data.get("attention"),
            response=data.get("response"),
            timing=data.get("timing"),
            closure=data.get("closure"),
            escalation=data.get("escalation"),
            proof=data.get("proof"),
        )

    @classmethod
    def for_schema(cls, schema_id: str, priority: str = "routine") -> Expectation:
        """Derive a default expectation from schema and priority.

        This is the canonical mapping — when no explicit expectation is
        provided, the system infers one from the schema type and priority.
        """
        _schema_defaults: dict[str, dict[str, str]] = {
            "decision_request.v1": {
                "attention": "actionable",
                "response": "required",
                "timing": "soon",
                "closure": "explicit_close",
                "escalation": "escalate_if_blocked",
                "proof": "structured",
            },
            "handoff_baton.v1": {
                "attention": "actionable",
                "response": "ack_then_answer",
                "timing": "soon",
                "closure": "explicit_close",
                "escalation": "escalate_if_blocked",
                "proof": "artifact",
            },
            "external_action_request.v1": {
                "attention": "blocking",
                "response": "required",
                "timing": "now",
                "closure": "explicit_close",
                "escalation": "operator_required",
                "proof": "evidence_ref",
            },
            "status_update.v1": {
                "attention": "fyi",
                "response": "none",
                "timing": "when_free",
                "closure": "none",
                "escalation": "handle_locally",
                "proof": "prose",
            },
        }
        defaults = _schema_defaults.get(schema_id, {
            "attention": "fyi",
            "response": "if_useful",
            "timing": "when_free",
            "closure": "none",
            "escalation": "handle_locally",
            "proof": "prose",
        })
        # Priority overrides
        if priority == "flash":
            defaults["attention"] = "interrupt"
            defaults["timing"] = "now"
        elif priority == "priority":
            if defaults.get("attention") not in ("blocking", "interrupt"):
                defaults["attention"] = "actionable"
            if defaults.get("timing") not in ("now",):
                defaults["timing"] = "soon"
        return cls(**defaults)


# ---------------------------------------------------------------------------
# Participant roles and state
# ---------------------------------------------------------------------------

VALID_PARTICIPANT_ROLES = frozenset({"origin", "subject", "principal"})

VALID_WAKE_POSTURES = frozenset({
    "listener_backed",
    "manual_wake",
    "always_on",
    "mixed",
    "operator_console",
})

VALID_READINESS_STATES = frozenset({
    "ready", "busy", "blocked", "warming",
    "paused_by_operator", "degraded",
})

VALID_INTERRUPTIBILITY = frozenset({
    "free", "defer", "urgent_only", "do_not_interrupt",
})


@dataclass(frozen=True)
class ParticipantRoles:
    """Who is involved in this signal beyond sender/recipient.

    origin: who created this signal (may differ from sender if relayed
            through a gateway or proxy)
    subject_of: who or what the signal is about (distinct from the
                message subject line — this is the participant role)
    principal: under whose authority this signal speaks (enables
               delegation and gateway patterns)

    All fields are optional. Omission means the obvious default:
    origin=sender, subject_of=recipient, principal=sender.
    """
    origin: str | None = None
    subject_of: str | None = None
    principal: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in {
            "origin": self.origin,
            "subject_of": self.subject_of,
            "principal": self.principal,
        }.items() if v is not None}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ParticipantRoles:
        return cls(
            origin=data.get("origin"),
            subject_of=data.get("subject_of") or data.get("subject_agent"),
            principal=data.get("principal"),
        )

    @property
    def is_relayed(self) -> bool:
        """True if origin differs from the implicit sender default."""
        return self.origin is not None

    @property
    def is_delegated(self) -> bool:
        """True if principal differs from the implicit sender default."""
        return self.principal is not None

    @property
    def has_explicit_subject(self) -> bool:
        """True if the signal is explicitly about someone."""
        return self.subject_of is not None


@dataclass(frozen=True)
class ParticipantState:
    """Portable participant state — the structured protocol type for
    wake posture, readiness, interruptibility, and contextual pressures.

    This replaces ad-hoc runtime fields with one schema that can travel
    in 2ack envelopes, connection stories, and descriptor extensions.

    Schema: participant_state.v1
    """
    wake_posture: str | None = None        # listener_backed | manual_wake | ...
    readiness: str | None = None           # ready | busy | blocked | ...
    interruptibility: str | None = None    # free | defer | urgent_only | do_not_interrupt
    context_load: float | None = None      # 0.0 - 1.0
    quality_risk: str | None = None        # low | medium | high
    current_task: str | None = None
    progress_summary: str | None = None
    degraded_reason: str | None = None     # why this participant is degraded
    basis: str | None = None               # declared | observed | derived | attested

    def __post_init__(self):
        if self.wake_posture is not None and self.wake_posture not in VALID_WAKE_POSTURES:
            raise ValueError(f"Unknown wake_posture: {self.wake_posture!r}")
        if self.readiness is not None and self.readiness not in VALID_READINESS_STATES:
            raise ValueError(f"Unknown readiness: {self.readiness!r}")
        if self.interruptibility is not None and self.interruptibility not in VALID_INTERRUPTIBILITY:
            raise ValueError(f"Unknown interruptibility: {self.interruptibility!r}")
        if self.context_load is not None and not (0.0 <= self.context_load <= 1.0):
            raise ValueError(f"context_load must be 0.0-1.0, got {self.context_load}")

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in {
            "schema": "participant_state.v1",
            "wake_posture": self.wake_posture,
            "readiness": self.readiness,
            "interruptibility": self.interruptibility,
            "context_load": self.context_load,
            "quality_risk": self.quality_risk,
            "current_task": self.current_task,
            "progress_summary": self.progress_summary,
            "degraded_reason": self.degraded_reason,
            "basis": self.basis,
        }.items() if v is not None}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ParticipantState:
        return cls(
            wake_posture=data.get("wake_posture"),
            readiness=data.get("readiness"),
            interruptibility=data.get("interruptibility"),
            context_load=data.get("context_load"),
            quality_risk=data.get("quality_risk"),
            current_task=data.get("current_task"),
            progress_summary=data.get("progress_summary"),
            degraded_reason=data.get("degraded_reason"),
            basis=data.get("basis"),
        )


# ---------------------------------------------------------------------------
# Actuation lifecycle (Slice 11)
# ---------------------------------------------------------------------------

ACTUATION_STATES = (
    "intent",       # action proposed but not yet approved
    "approved",     # operator or principal approved the action
    "issued",       # command sent to the target system
    "executing",    # target is actively performing the action
    "observed",     # an effect was observed (sensor, log, callback)
    "confirmed",    # effect verified as matching intent
    "reverted",     # action was rolled back or undone
    "failed",       # action failed to achieve intent
    "cancelled",    # action was withdrawn before completion
)

ACTUATION_TERMINAL_STATES = frozenset({"confirmed", "reverted", "failed", "cancelled"})

# Valid transitions: state -> set of states it can move to
_ACTUATION_TRANSITIONS: dict[str, frozenset[str]] = {
    "intent":    frozenset({"approved", "cancelled", "failed"}),
    "approved":  frozenset({"issued", "cancelled"}),
    "issued":    frozenset({"executing", "observed", "confirmed", "failed", "cancelled"}),
    "executing": frozenset({"observed", "confirmed", "failed", "reverted"}),
    "observed":  frozenset({"confirmed", "reverted", "failed"}),
    "confirmed": frozenset(),  # terminal
    "reverted":  frozenset(),  # terminal
    "failed":    frozenset(),  # terminal
    "cancelled": frozenset(),  # terminal
}

# Operator-visible labels for each state
_ACTUATION_OPERATOR_LABELS: dict[str, str] = {
    "intent": "proposed",
    "approved": "approved — awaiting issuance",
    "issued": "issued — awaiting execution",
    "executing": "in progress",
    "observed": "effect observed — awaiting confirmation",
    "confirmed": "confirmed",
    "reverted": "REVERTED",
    "failed": "FAILED",
    "cancelled": "cancelled",
}


@dataclass(frozen=True)
class ActuationLifecycle:
    """Tracks the lifecycle of a consequential action from intent to outcome.

    This is the protocol type for effect truth — stronger than the thin
    success/failure binary in external_action_result.v1. It captures the
    full chain: who proposed, who approved, what was issued, what was
    observed, and whether the outcome matches the intent.

    Schema: actuation_lifecycle.v1
    """
    action_ref: str                          # links to external_action_request message_id
    state: str = "intent"
    consequence_scope: str | None = None     # digital | physical_reversible | physical_irreversible
    action_class: str | None = None          # what kind of action (from request)
    intent_summary: str | None = None        # what was supposed to happen
    target: str | None = None                # what system/device/resource
    approved_by: str | None = None           # who approved (operator, principal, auto-policy)
    approved_at: str | None = None           # when approved
    issued_at: str | None = None             # when the command was sent
    observed_effect: str | None = None       # what was actually observed
    observed_at: str | None = None           # when the observation was made
    outcome_summary: str | None = None       # final outcome description
    outcome_at: str | None = None            # when the terminal state was reached
    revert_reason: str | None = None         # why it was reverted
    failure_reason: str | None = None        # why it failed
    evidence_refs: list[str] = field(default_factory=list)
    basis: str | None = None                 # declared | observed | attested

    def __post_init__(self):
        if self.state not in ACTUATION_STATES:
            raise ValueError(
                f"Unknown actuation state: {self.state!r}. "
                f"Valid: {ACTUATION_STATES}"
            )
        if self.consequence_scope is not None:
            from .envelope import VALID_CONSEQUENCE_SCOPES
            if self.consequence_scope not in VALID_CONSEQUENCE_SCOPES:
                raise ValueError(
                    f"Unknown consequence_scope: {self.consequence_scope!r}"
                )

    @property
    def is_terminal(self) -> bool:
        return self.state in ACTUATION_TERMINAL_STATES

    @property
    def operator_label(self) -> str:
        return _ACTUATION_OPERATOR_LABELS.get(self.state, self.state)

    def can_transition_to(self, new_state: str) -> bool:
        valid_next = _ACTUATION_TRANSITIONS.get(self.state, frozenset())
        return new_state in valid_next

    def valid_transitions(self) -> frozenset[str]:
        return _ACTUATION_TRANSITIONS.get(self.state, frozenset())

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "schema": "actuation_lifecycle.v1",
            "action_ref": self.action_ref,
            "state": self.state,
            "operator_label": self.operator_label,
            "is_terminal": self.is_terminal,
        }
        for key in (
            "consequence_scope", "action_class", "intent_summary",
            "target", "approved_by", "approved_at", "issued_at",
            "observed_effect", "observed_at", "outcome_summary",
            "outcome_at", "revert_reason", "failure_reason", "basis",
        ):
            val = getattr(self, key)
            if val is not None:
                d[key] = val
        if self.evidence_refs:
            d["evidence_refs"] = list(self.evidence_refs)
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ActuationLifecycle:
        return cls(
            action_ref=data.get("action_ref", ""),
            state=data.get("state", "intent"),
            consequence_scope=data.get("consequence_scope"),
            action_class=data.get("action_class"),
            intent_summary=data.get("intent_summary"),
            target=data.get("target"),
            approved_by=data.get("approved_by"),
            approved_at=data.get("approved_at"),
            issued_at=data.get("issued_at"),
            observed_effect=data.get("observed_effect"),
            observed_at=data.get("observed_at"),
            outcome_summary=data.get("outcome_summary"),
            outcome_at=data.get("outcome_at"),
            revert_reason=data.get("revert_reason"),
            failure_reason=data.get("failure_reason"),
            evidence_refs=list(data.get("evidence_refs") or []),
            basis=data.get("basis"),
        )


# ---------------------------------------------------------------------------
# Alarm collapse and calm decision surface (Slice 12)
# ---------------------------------------------------------------------------

# Severity ranking: higher index = more severe
SEVERITY_LEVELS = ("info", "warning", "elevated", "critical", "emergency")
_SEVERITY_RANK = {level: i for i, level in enumerate(SEVERITY_LEVELS)}

# Consequence scope severity weighting
_CONSEQUENCE_SEVERITY_BOOST = {
    "digital": 0,
    "physical_reversible": 1,
    "physical_irreversible": 2,
}


@dataclass
class AlarmSignal:
    """A single consequential event that may be part of a larger alarm group."""
    signal_id: str
    source: str                              # who/what generated this signal
    severity: str = "info"                   # info | warning | elevated | critical | emergency
    consequence_scope: str | None = None     # digital | physical_reversible | physical_irreversible
    action_class: str | None = None          # what domain (hvac, security, network, etc.)
    summary: str = ""
    timestamp: str | None = None
    evidence_refs: list[str] = field(default_factory=list)
    actuation_ref: str | None = None         # links to ActuationLifecycle if applicable
    target: str | None = None                # what system/device/resource

    @property
    def severity_rank(self) -> int:
        base = _SEVERITY_RANK.get(self.severity, 0)
        boost = _CONSEQUENCE_SEVERITY_BOOST.get(self.consequence_scope or "digital", 0)
        return base + boost

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"signal_id": self.signal_id, "source": self.source, "severity": self.severity}
        for key in ("consequence_scope", "action_class", "summary", "timestamp", "actuation_ref", "target"):
            val = getattr(self, key)
            if val is not None:
                d[key] = val
        if self.evidence_refs:
            d["evidence_refs"] = list(self.evidence_refs)
        return d


@dataclass
class DecisionSurface:
    """One calm decision surface collapsed from multiple alarm signals.

    This is the human-facing object: instead of N machine-speed events,
    the operator sees one surface with the highest severity, grouped
    evidence, available options, and provenance.

    Schema: decision_surface.v1
    """
    group_id: str                            # unique ID for this collapsed group
    signals: list[AlarmSignal] = field(default_factory=list)
    consequence_scope: str | None = None     # promoted to highest in group
    action_class: str | None = None          # shared action domain if uniform
    headline: str = ""                       # one-line summary for operator
    options: list[str] = field(default_factory=list)  # available operator actions
    recommended_action: str | None = None
    created_at: str | None = None
    expires_at: str | None = None            # decision window

    @property
    def signal_count(self) -> int:
        return len(self.signals)

    @property
    def promoted_severity(self) -> str:
        """Highest base severity across all signals in this group.

        Uses the signal's declared severity level, not the consequence-
        boosted rank (which is used for cross-group sorting only).
        """
        if not self.signals:
            return "info"
        max_base = max(_SEVERITY_RANK.get(s.severity, 0) for s in self.signals)
        for level in reversed(SEVERITY_LEVELS):
            if _SEVERITY_RANK[level] == max_base:
                return level
        return "info"

    @property
    def promoted_consequence_scope(self) -> str | None:
        """Highest consequence scope across all signals."""
        scopes = [s.consequence_scope for s in self.signals if s.consequence_scope]
        if not scopes:
            return self.consequence_scope
        return max(scopes, key=lambda s: _CONSEQUENCE_SEVERITY_BOOST.get(s, 0))

    @property
    def all_evidence(self) -> list[str]:
        """Deduplicated evidence refs across all signals."""
        seen: set[str] = set()
        refs: list[str] = []
        for signal in self.signals:
            for ref in signal.evidence_refs:
                if ref not in seen:
                    seen.add(ref)
                    refs.append(ref)
        return refs

    @property
    def sources(self) -> list[str]:
        """Unique sources across all signals, preserving order."""
        seen: set[str] = set()
        result: list[str] = []
        for s in self.signals:
            if s.source not in seen:
                seen.add(s.source)
                result.append(s.source)
        return result

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "schema": "decision_surface.v1",
            "group_id": self.group_id,
            "signal_count": self.signal_count,
            "promoted_severity": self.promoted_severity,
            "promoted_consequence_scope": self.promoted_consequence_scope,
            "sources": self.sources,
            "headline": self.headline,
        }
        if self.action_class:
            d["action_class"] = self.action_class
        if self.options:
            d["options"] = list(self.options)
        if self.recommended_action:
            d["recommended_action"] = self.recommended_action
        if self.all_evidence:
            d["evidence"] = self.all_evidence
        if self.signals:
            d["signals"] = [s.to_dict() for s in self.signals]
        if self.created_at:
            d["created_at"] = self.created_at
        if self.expires_at:
            d["expires_at"] = self.expires_at
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DecisionSurface:
        signals = [
            AlarmSignal(
                signal_id=s.get("signal_id", ""),
                source=s.get("source", ""),
                severity=s.get("severity", "info"),
                consequence_scope=s.get("consequence_scope"),
                action_class=s.get("action_class"),
                summary=s.get("summary", ""),
                timestamp=s.get("timestamp"),
                evidence_refs=list(s.get("evidence_refs") or []),
                actuation_ref=s.get("actuation_ref"),
                target=s.get("target"),
            )
            for s in (data.get("signals") or [])
            if isinstance(s, dict)
        ]
        return cls(
            group_id=data.get("group_id", ""),
            signals=signals,
            consequence_scope=data.get("consequence_scope") or data.get("promoted_consequence_scope"),
            action_class=data.get("action_class"),
            headline=data.get("headline", ""),
            options=list(data.get("options") or []),
            recommended_action=data.get("recommended_action"),
            created_at=data.get("created_at"),
            expires_at=data.get("expires_at"),
        )


def collapse_alarms(
    signals: list[AlarmSignal],
    *,
    group_key: str = "action_class",
    time_window_seconds: int = 300,
) -> list[DecisionSurface]:
    """Collapse related alarm signals into decision surfaces.

    Groups signals by the group_key field (default: action_class) and
    time window. Within each group, promotes the highest severity and
    consequence scope.

    Returns one DecisionSurface per group.
    """
    if not signals:
        return []

    # Group by key
    groups: dict[str, list[AlarmSignal]] = {}
    for signal in signals:
        key = getattr(signal, group_key, None) or "_ungrouped"
        groups.setdefault(key, []).append(signal)

    # Build decision surfaces
    surfaces: list[DecisionSurface] = []
    for key, group_signals in groups.items():
        # Sub-group by time window if timestamps are available
        # For now, treat the whole group as one surface
        surface = DecisionSurface(
            group_id=f"alarm-{key}-{len(surfaces)}",
            signals=sorted(group_signals, key=lambda s: s.severity_rank, reverse=True),
            action_class=key if key != "_ungrouped" else None,
            headline=_build_alarm_headline(key, group_signals),
        )
        surfaces.append(surface)

    # Sort surfaces by promoted severity (most severe first)
    surfaces.sort(key=lambda s: _SEVERITY_RANK.get(s.promoted_severity, 0), reverse=True)
    return surfaces


def _build_alarm_headline(group_key: str, signals: list[AlarmSignal]) -> str:
    """Build a one-line headline for an alarm group."""
    count = len(signals)
    if count == 1:
        return signals[0].summary or f"{group_key} alert from {signals[0].source}"
    sources = {s.source for s in signals}
    if len(sources) == 1:
        return f"{count} {group_key} alerts from {next(iter(sources))}"
    return f"{count} {group_key} alerts from {len(sources)} sources"


# ---------------------------------------------------------------------------
# Baton staleness detection
# ---------------------------------------------------------------------------

# Thresholds for staleness warnings (seconds)
_BATON_STALE_AGE_THRESHOLD = 30 * 60   # 30 minutes
_BATON_VERY_STALE_AGE_THRESHOLD = 2 * 60 * 60  # 2 hours


@dataclass(frozen=True)
class BatonStalenessReport:
    """Staleness context surfaced at baton_ack time.

    When stale is True, the accepting agent must resolve the staleness
    before the ack can proceed. The report provides human-readable
    context about what changed so the agent (or zMaia on their behalf)
    can make an informed decision.
    """
    stale: bool = False
    age_seconds: int = 0
    age_label: str = ""
    reasons: list[str] = field(default_factory=list)
    suggested_action: str = ""

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "stale": self.stale,
            "age_seconds": self.age_seconds,
            "age_label": self.age_label,
        }
        if self.reasons:
            d["reasons"] = list(self.reasons)
        if self.suggested_action:
            d["suggested_action"] = self.suggested_action
        return d


def _format_baton_age(seconds: int) -> str:
    if seconds >= 86_400:
        return f"{seconds / 86_400:.1f}d"
    if seconds >= 3_600:
        return f"{seconds / 3_600:.1f}h"
    if seconds >= 60:
        return f"{seconds // 60}m"
    return f"{seconds}s"


def check_baton_staleness(
    *,
    baton_created_at: str | datetime | None,
    baton_updated_at: str | datetime | None,
    owner_callsign: str,
    owner_current_state: dict[str, Any] | None = None,
    active_file_leases: list[str] | None = None,
    now: datetime | None = None,
) -> BatonStalenessReport:
    """Check whether a baton is stale before acceptance.

    Returns a report with staleness reasons. When stale is True,
    the system should surface the report to the accepting agent
    and require explicit acknowledgment of the changed context.
    """
    if now is None:
        now = datetime.now(timezone.utc)

    reasons: list[str] = []

    # Age check
    reference_time = baton_updated_at or baton_created_at
    if reference_time is not None:
        if isinstance(reference_time, str):
            reference_time = parse_timestamp(reference_time)
        age_seconds = max(0, int((now - reference_time).total_seconds()))
    else:
        age_seconds = 0

    age_label = _format_baton_age(age_seconds)

    if age_seconds >= _BATON_VERY_STALE_AGE_THRESHOLD:
        reasons.append(
            f"This baton is {age_label} old. The context may have significantly changed."
        )
    elif age_seconds >= _BATON_STALE_AGE_THRESHOLD:
        reasons.append(
            f"This baton is {age_label} old. Verify the work is still needed."
        )

    # Owner state change check
    if owner_current_state:
        owner_readiness = str(owner_current_state.get("readiness") or "").strip().lower()
        owner_working_on = str(owner_current_state.get("current_task") or "").strip()
        if owner_readiness in ("blocked", "paused_by_operator", "degraded"):
            reasons.append(
                f"The assigning agent ({owner_callsign}) is now {owner_readiness}."
            )
        if owner_working_on and "jolt" not in owner_working_on.lower():
            # Owner has moved on to different work — possible context shift
            pass  # Don't flag this — it's normal for the owner to work on other things

    # File lease collision check
    if active_file_leases:
        reasons.append(
            f"Files are currently leased by another agent: {', '.join(active_file_leases[:3])}"
        )

    stale = len(reasons) > 0
    suggested_action = ""
    if stale:
        if age_seconds >= _BATON_VERY_STALE_AGE_THRESHOLD:
            suggested_action = (
                f"Check with {owner_callsign} whether this is still needed, "
                "or decline and request a fresh assignment."
            )
        else:
            suggested_action = (
                "Review the current swarm state before accepting. "
                "The baton may still be valid but the context has shifted."
            )

    return BatonStalenessReport(
        stale=stale,
        age_seconds=age_seconds,
        age_label=age_label,
        reasons=reasons,
        suggested_action=suggested_action,
    )
_REGISTERED_SCHEMAS = {
    "status_update.v1",
    "handoff_baton.v1",
    "decision_request.v1",
    "decision_response.v1",
    "external_action_request.v1",
    "external_action_result.v1",
    "protocol_error.v1",
    "workspace_create.v1",
    "workspace_join.v1",
    "workspace_leave.v1",
    "workspace_close.v1",
    "workspace_delta.v1",
    "workspace_state.v1",
    "review_beacon.v1",
    "review_claim.v1",
    "review_verdict.v1",
    "dissent_record.v1",
    "dissent_resolution.v1",
    "baton_ack.v1",
    "baton_update.v1",
    "baton_close.v1",
}


@dataclass(frozen=True)
class ValidationIssue:
    code: str
    path: str
    message: str


@dataclass
class ValidationResult:
    errors: list[ValidationIssue] = field(default_factory=list)

    @property
    def valid(self) -> bool:
        return not self.errors

    @property
    def codes(self) -> list[str]:
        return [error.code for error in self.errors]

    def add_error(self, code: str, path: str, message: str) -> None:
        self.errors.append(ValidationIssue(code=code, path=path, message=message))

    def extend(self, other: "ValidationResult") -> None:
        self.errors.extend(other.errors)


@dataclass(frozen=True)
class PreflightSurface:
    wire_v: Any = None
    schema: Any = None
    signal_class: Any = None
    tier_required: Any = None
    requires_operator: Any = None
    expires_at: Any = None
    max_hops: Any = None
    accept_schemas: tuple[str, ...] | None = None
    message_id: Any = None
    # Participant and consequence fields (Slice 10)
    origin: str | None = None
    subject_of: str | None = None
    principal: str | None = None
    consequence_scope: str | None = None

    def is_expired(self, *, now: datetime | str | None = None) -> bool | None:
        if self.expires_at is None:
            return None
        expiry = parse_timestamp(self.expires_at)
        if expiry is None:
            return None
        if now is None:
            reference = datetime.now(timezone.utc)
        elif isinstance(now, datetime):
            reference = now if now.tzinfo else now.replace(tzinfo=timezone.utc)
        else:
            reference = parse_timestamp(now)
            if reference is None:
                return None
        return expiry <= reference.astimezone(timezone.utc)


@dataclass(frozen=True)
class PreflightPolicy:
    supported_wire_versions: tuple[int, ...] = (1,)
    known_schemas: tuple[str, ...] | None = tuple(sorted(_REGISTERED_SCHEMAS))
    operator_available: bool | None = None
    receiver_trust_tier: int | None = None


@dataclass(frozen=True)
class PreflightDecision:
    action: Literal["accept", "reject", "defer"]
    surface: PreflightSurface = field(default_factory=PreflightSurface)
    code: str | None = None
    reason: str | None = None
    offered_alternatives: tuple[str, ...] | None = None

    @property
    def accepted(self) -> bool:
        return self.action == "accept"

    @property
    def rejected(self) -> bool:
        return self.action == "reject"

    @property
    def deferred(self) -> bool:
        return self.action == "defer"


@dataclass(frozen=True)
class A2ABinding:
    envelope: dict[str, Any] | None
    text_parts: tuple[str, ...]
    metadata_mirrors: dict[str, Any]
    message_id: Any
    conflicts: tuple[str, ...] = ()

    @property
    def fallback_text(self) -> str | None:
        if not self.text_parts:
            return None
        return "\n".join(self.text_parts)


@dataclass(frozen=True)
class ConformanceObservation:
    level: int
    envelope_present: bool
    fallback_text: str | None
    preserved_envelope: dict[str, Any] | None
    can_execute: bool
    rejection_code: str | None
    metadata_conflicts: tuple[str, ...] = ()


def _check_depth(obj: Any, current_depth: int, max_depth: int) -> bool:
    if current_depth > max_depth:
        return False
    if isinstance(obj, dict):
        return all(_check_depth(v, current_depth + 1, max_depth) for v in obj.values())
    if isinstance(obj, list):
        return all(_check_depth(v, current_depth + 1, max_depth) for v in obj)
    return True


def validate_envelope(envelope: Any) -> ValidationResult:
    result = ValidationResult()
    if not isinstance(envelope, dict):
        result.add_error(ERR_MALFORMED_ENVELOPE, "$", "Envelope must be a JSON object.")
        return result

    if not _check_depth(envelope, current_depth=1, max_depth=MAX_ENVELOPE_DEPTH):
        result.add_error(ERR_MALFORMED_ENVELOPE, "$", f"Envelope exceeds maximum recursive depth of {MAX_ENVELOPE_DEPTH}.")
        return result

    for field_name in sorted(_REQUIRED_ENVELOPE_FIELDS):
        if field_name not in envelope:
            result.add_error(
                ERR_MALFORMED_ENVELOPE,
                field_name,
                f"Missing required field '{field_name}'.",
            )

    if "wire_v" in envelope:
        wire_v = envelope["wire_v"]
        if not _is_int(wire_v):
            result.add_error(ERR_MALFORMED_ENVELOPE, "wire_v", "wire_v must be an integer.")
        elif wire_v != 1:
            result.add_error(ERR_WIRE_VERSION, "wire_v", f"Unsupported wire_v '{wire_v}'.")

    if "schema" in envelope:
        _validate_schema_id(envelope["schema"], "schema", result, code=ERR_MALFORMED_ENVELOPE)

    trace = envelope.get("trace")
    if "trace" in envelope:
        if not isinstance(trace, dict):
            result.add_error(ERR_MALFORMED_ENVELOPE, "trace", "trace must be an object.")
        else:
            message_id = trace.get("message_id")
            if not isinstance(message_id, str) or not message_id.strip():
                result.add_error(
                    ERR_MALFORMED_ENVELOPE,
                    "trace.message_id",
                    "trace.message_id must be a non-empty string.",
                )
            for field_name in ("trace_id", "thread_id", "in_reply_to", "caused_by", "supersedes"):
                if field_name in trace and trace[field_name] is not None and not isinstance(trace[field_name], str):
                    result.add_error(
                        ERR_MALFORMED_ENVELOPE,
                        f"trace.{field_name}",
                        f"trace.{field_name} must be a string when present.",
                    )

    is_encrypted = "encryption" in envelope and isinstance(envelope["encryption"], dict)
    if not is_encrypted and "payload" in envelope and not isinstance(envelope["payload"], dict):
        result.add_error(ERR_MALFORMED_ENVELOPE, "payload", "payload must be an object.")
    _validate_enum_field(envelope, "mode", _ALLOWED_MODES, result)
    _validate_enum_field(envelope, "signal_class", _ALLOWED_SIGNAL_CLASSES, result)
    _validate_enum_field(envelope, "source", _ALLOWED_SOURCES, result)

    _validate_optional_object(envelope, "trust", result)
    _validate_optional_object(envelope, "summary", result)

    # Enforce summary field length limits
    if isinstance(envelope.get("summary"), dict):
        for sfield in ("headline", "brief", "human"):
            val = envelope["summary"].get(sfield)
            if isinstance(val, str) and len(val.encode("utf-8", errors="replace")) > MAX_SUMMARY_FIELD_BYTES:
                result.add_error(
                    ERR_MALFORMED_ENVELOPE,
                    f"summary.{sfield}",
                    f"summary.{sfield} exceeds maximum length of {MAX_SUMMARY_FIELD_BYTES} bytes.",
                )
    
    if "authority" in envelope and envelope["authority"] is not None:
        authority = envelope["authority"]
        if not isinstance(authority, dict):
            result.add_error(ERR_MALFORMED_ENVELOPE, "authority", "authority must be an object.")
        else:
            if "principal" not in authority or not isinstance(authority["principal"], str):
                result.add_error(ERR_MALFORMED_ENVELOPE, "authority.principal", "Required string field 'principal' missing or invalid.")
            if "delegated_by" in authority and authority["delegated_by"] is not None and not isinstance(authority["delegated_by"], str):
                result.add_error(ERR_MALFORMED_ENVELOPE, "authority.delegated_by", "delegated_by must be a string.")
            if "scope" in authority and authority["scope"] is not None and not isinstance(authority["scope"], (dict, list, str)):
                result.add_error(ERR_MALFORMED_ENVELOPE, "authority.scope", "scope must be a valid JSON type (list, dict, or string).")
            if "expires_at" in authority and authority["expires_at"] is not None:
                _validate_timestamp(authority["expires_at"], "authority.expires_at", result, allow_null=False, code=ERR_MALFORMED_ENVELOPE)

    _validate_optional_object(envelope, "policy_hint", result)

    if "authority_proof" in envelope and envelope["authority_proof"] is not None:
        proof = envelope["authority_proof"]
        if not isinstance(proof, (dict, list, str, int, float, bool)):
            result.add_error(
                ERR_MALFORMED_ENVELOPE,
                "authority_proof",
                "authority_proof must be a JSON-compatible value when present.",
            )

    if "attachments" in envelope:
        attachments = envelope["attachments"]
        _validate_list(attachments, "attachments", result, allow_empty=True, code=ERR_MALFORMED_ENVELOPE)
        if isinstance(attachments, list):
            for i, att in enumerate(attachments):
                if not isinstance(att, dict):
                    continue
                # Validate artifact reference structure when ref is present
                ref = att.get("ref")
                if ref is not None:
                    if not isinstance(ref, str) or not _PAYLOAD_HASH_RE.fullmatch(ref.removeprefix("sha256:") if ref.startswith("sha256:") else ""):
                        if isinstance(ref, str) and not ref.startswith("sha256:"):
                            pass  # Non-sha256 refs are allowed (future schemes)
                        elif isinstance(ref, str):
                            result.add_error(
                                ERR_MALFORMED_ENVELOPE,
                                f"attachments[{i}].ref",
                                "Attachment ref with sha256: prefix must match sha256:<64 hex chars>.",
                            )
                        else:
                            result.add_error(
                                ERR_MALFORMED_ENVELOPE,
                                f"attachments[{i}].ref",
                                "Attachment ref must be a string.",
                            )
                    if "size_bytes" in att and att["size_bytes"] is not None:
                        if not _is_int(att["size_bytes"]) or att["size_bytes"] < 0:
                            result.add_error(
                                ERR_MALFORMED_ENVELOPE,
                                f"attachments[{i}].size_bytes",
                                "Attachment size_bytes must be a non-negative integer.",
                            )

    for timestamp_field in ("created_at", "expires_at"):
        if timestamp_field in envelope:
            _validate_timestamp(envelope[timestamp_field], timestamp_field, result, allow_null=False, code=ERR_MALFORMED_ENVELOPE)

    # Validate created_at <= expires_at when both present
    if "created_at" in envelope and "expires_at" in envelope:
        try:
            from datetime import datetime as _dt
            ca = _dt.fromisoformat(str(envelope["created_at"]).replace("Z", "+00:00"))
            ea = _dt.fromisoformat(str(envelope["expires_at"]).replace("Z", "+00:00"))
            if ea < ca:
                result.add_error(
                    ERR_MALFORMED_ENVELOPE,
                    "expires_at",
                    "expires_at must not be earlier than created_at.",
                )
        except (ValueError, TypeError):
            pass  # timestamp format errors already caught above

    if "policy_hint" in envelope and isinstance(envelope["policy_hint"], dict):
        policy_hint = envelope["policy_hint"]
        if "reply_by" in policy_hint:
            _validate_timestamp(policy_hint["reply_by"], "policy_hint.reply_by", result, allow_null=True, code=ERR_MALFORMED_ENVELOPE)
        for field_name in ("reply_expected", "defer_ok", "human_derivable"):
            if field_name in policy_hint and policy_hint[field_name] is not None and not isinstance(policy_hint[field_name], bool):
                result.add_error(
                    ERR_MALFORMED_ENVELOPE,
                    f"policy_hint.{field_name}",
                    f"policy_hint.{field_name} must be a boolean when present.",
                )

    if "accept_schemas" in envelope and envelope["accept_schemas"] is not None:
        accept_schemas = envelope["accept_schemas"]
        if not isinstance(accept_schemas, list):
            result.add_error(
                ERR_MALFORMED_ENVELOPE,
                "accept_schemas",
                "accept_schemas must be an array of schema identifiers.",
            )
        else:
            for index, schema_id in enumerate(accept_schemas):
                _validate_schema_id(
                    schema_id,
                    f"accept_schemas[{index}]",
                    result,
                    code=ERR_MALFORMED_ENVELOPE,
                )

    if "max_hops" in envelope:
        max_hops = envelope["max_hops"]
        if not _is_int(max_hops) or max_hops < 0:
            result.add_error(ERR_MALFORMED_ENVELOPE, "max_hops", "max_hops must be a non-negative integer.")

    if "received_via" in envelope:
        _validate_string_list(envelope["received_via"], "received_via", result, allow_empty=True, code=ERR_MALFORMED_ENVELOPE)

    if "payload_hash" in envelope:
        payload_hash = envelope["payload_hash"]
        if not isinstance(payload_hash, str) or not _PAYLOAD_HASH_RE.fullmatch(payload_hash):
            result.add_error(
                ERR_MALFORMED_ENVELOPE,
                "payload_hash",
                "payload_hash must match sha256:<64 hex chars>.",
            )

    if "encryption" in envelope and not isinstance(envelope["encryption"], dict):
        result.add_error(ERR_MALFORMED_ENVELOPE, "encryption", "encryption must be an object.")

    if "ext" in envelope:
        ext = envelope["ext"]
        if not isinstance(ext, dict):
            result.add_error(ERR_MALFORMED_ENVELOPE, "ext", "ext must be an object.")
        else:
            for key in ext:
                if not _EXT_KEY_RE.fullmatch(key):
                    result.add_error(
                        ERR_MALFORMED_ENVELOPE,
                        f"ext.{key}",
                        "ext keys must use a namespace prefix such as whispers: or x-<vendor>:.",
                    )

    # 2ACK P1.6: Validate _label suffix fields as ClaimLabel structures.
    # Any field ending in _label is treated as a truth label companion.
    # Validation is lenient: labels are optional, but if present must be well-formed.
    for key, value in envelope.items():
        if key.endswith("_label") and value is not None:
            if not isinstance(value, dict):
                result.add_error(
                    ERR_MALFORMED_ENVELOPE,
                    key,
                    f"Truth label '{key}' must be an object.",
                )
                continue
            _validate_claim_label(value, key, result)

    # Also validate _label fields inside the payload if it's a dict
    payload = envelope.get("payload")
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key.endswith("_label") and value is not None:
                if not isinstance(value, dict):
                    result.add_error(
                        ERR_SCHEMA_INVALID,
                        f"payload.{key}",
                        f"Truth label '{key}' must be an object.",
                    )
                    continue
                _validate_claim_label(value, f"payload.{key}", result)

    # 2ACK Attention & Expectation: validate the expectation object if present
    if "expectation" in envelope:
        exp = envelope["expectation"]
        if exp is not None:
            if not isinstance(exp, dict):
                result.add_error(ERR_MALFORMED_ENVELOPE, "expectation", "expectation must be an object.")
            else:
                _posture_validation = {
                    "attention": VALID_ATTENTION_POSTURES,
                    "response": VALID_RESPONSE_POSTURES,
                    "timing": VALID_TIMING_POSTURES,
                    "closure": VALID_CLOSURE_POSTURES,
                    "escalation": VALID_ESCALATION_POSTURES,
                    "proof": VALID_PROOF_POSTURES,
                }
                for field_name, valid_set in _posture_validation.items():
                    if field_name in exp and exp[field_name] is not None:
                        if exp[field_name] not in valid_set:
                            result.add_error(
                                ERR_MALFORMED_ENVELOPE,
                                f"expectation.{field_name}",
                                f"Unknown {field_name} posture: '{exp[field_name]}'. "
                                f"Valid: {sorted(valid_set)}",
                            )

    return result


def validate_schema(schema_id: Any, payload: Any, *, envelope: dict[str, Any] | None = None) -> ValidationResult:
    result = ValidationResult()

    if not isinstance(payload, dict):
        result.add_error(ERR_SCHEMA_INVALID, "payload", "payload must be an object.")
        return result

    if not isinstance(schema_id, str) or not _SCHEMA_ID_RE.fullmatch(schema_id):
        result.add_error(ERR_UNSUPPORTED_SCHEMA, "schema", "schema must use the name.vN format.")
        return result

    if schema_id not in _REGISTERED_SCHEMAS:
        result.add_error(ERR_UNSUPPORTED_SCHEMA, "schema", f"Unsupported schema '{schema_id}'.")
        return result

    if schema_id == "status_update.v1":
        _require_string(payload, "state", result)
        _validate_optional_float(payload, "confidence", result, min_value=0.0, max_value=1.0)
        _validate_optional_string_list(payload, "working_set", result)
        for field_name in ("readiness", "current_task", "interruptibility", "progress"):
            _validate_optional_string(payload, field_name, result)

    elif schema_id == "handoff_baton.v1":
        _require_string(payload, "objective", result)
        _require_string(payload, "deliverable", result)
        _validate_optional_string(payload, "repo_focus", result)
        _validate_optional_string(payload, "working_scope", result)
        _validate_optional_string(payload, "handoff_contract", result)
        _validate_optional_string(payload, "completed", result)
        _validate_optional_string(payload, "remaining", result)
        _validate_optional_string(payload, "next_action", result)
        _validate_optional_string(payload, "workspace_id", result)
        _validate_optional_string_list(payload, "open_questions", result)
        _validate_optional_string_list(payload, "dead_ends", result)
        _validate_optional_string_list(payload, "decisions", result)
        _validate_optional_string_list(payload, "artifacts", result)
        _validate_optional_string_list(payload, "assumptions", result)
        _validate_optional_string_list(payload, "risks", result)

    elif schema_id == "baton_ack.v1":
        _require_string(payload, "baton_ref", result)
        decision = _require_string(payload, "decision", result)
        if decision and decision not in _ALLOWED_BATON_DECISIONS:
            result.add_error(
                ERR_SCHEMA_INVALID,
                "payload.decision",
                f"payload.decision must be one of {', '.join(sorted(_ALLOWED_BATON_DECISIONS))}.",
            )
        if decision == "conditionally_accepted" and "conditions" not in payload:
            result.add_error(ERR_SCHEMA_INVALID, "payload.conditions", "conditions are required when decision is conditionally_accepted.")
        elif "conditions" in payload:
            _validate_optional_string_list(payload, "conditions", result)
            
        if decision == "rejected" and "reason" not in payload:
            result.add_error(ERR_SCHEMA_INVALID, "payload.reason", "reason is required when decision is rejected.")
        elif "reason" in payload:
            _validate_optional_string(payload, "reason", result)

    elif schema_id == "baton_update.v1":
        _require_string(payload, "baton_ref", result)
        state = _require_string(payload, "state", result)
        if state and state not in _ALLOWED_BATON_STATES:
            result.add_error(
                ERR_SCHEMA_INVALID,
                "payload.state",
                f"payload.state must be one of {', '.join(sorted(_ALLOWED_BATON_STATES))}.",
            )
        _validate_optional_string(payload, "progress", result)
        _validate_optional_string_list(payload, "artifact_refs", result)
        _validate_optional_string(payload, "branch", result)
        _validate_optional_string(payload, "head_commit", result)

    elif schema_id == "baton_close.v1":
        _require_string(payload, "baton_ref", result)
        outcome = _require_string(payload, "outcome", result)
        if outcome and outcome not in _ALLOWED_BATON_OUTCOMES:
            result.add_error(
                ERR_SCHEMA_INVALID,
                "payload.outcome",
                f"payload.outcome must be one of {', '.join(sorted(_ALLOWED_BATON_OUTCOMES))}.",
            )
        _validate_optional_string(payload, "summary", result)
        _validate_optional_string_list(payload, "artifact_refs", result)
        _validate_optional_string(payload, "branch", result)
        _validate_optional_string(payload, "head_commit", result)

    elif schema_id == "decision_request.v1":
        _require_string(payload, "question", result)
        options = _require_string_list(payload, "options", result, allow_empty=False)
        _validate_optional_string(payload, "why_now", result)
        _validate_optional_string(payload, "risk_if_wrong", result)
        if "deadline" in payload:
            _validate_timestamp(payload["deadline"], "payload.deadline", result, allow_null=True, code=ERR_SCHEMA_INVALID)
        if "blocking" in payload and payload["blocking"] is not None and not isinstance(payload["blocking"], bool):
            result.add_error(ERR_SCHEMA_INVALID, "payload.blocking", "payload.blocking must be a boolean when present.")
        if "recommended_option" in payload and payload["recommended_option"] is not None:
            recommended_option = payload["recommended_option"]
            if not isinstance(recommended_option, str):
                result.add_error(
                    ERR_SCHEMA_INVALID,
                    "payload.recommended_option",
                    "payload.recommended_option must be a string when present.",
                )
            elif options is not None and recommended_option not in options:
                result.add_error(
                    ERR_SCHEMA_INVALID,
                    "payload.recommended_option",
                    "payload.recommended_option must match one of payload.options.",
                )

    elif schema_id == "decision_response.v1":
        _require_string(payload, "decision", result)
        _validate_optional_float(payload, "confidence", result, min_value=0.0, max_value=1.0)
        _validate_optional_string(payload, "reason", result)
        _validate_optional_string(payload, "follow_up", result)
        _validate_optional_string_list(payload, "conditions", result)
        _validate_optional_string_list(payload, "rejected_options", result)

        request_envelope = envelope or {}
        request_options = None
        if isinstance(request_envelope.get("request_options"), list):
            request_options = request_envelope.get("request_options")
        else:
            request_payload = request_envelope.get("request_payload")
            if isinstance(request_payload, dict) and isinstance(request_payload.get("options"), list):
                request_options = request_payload.get("options")
            else:
                original_request = request_envelope.get("original_request")
                if isinstance(original_request, dict):
                    original_request_payload = original_request.get("payload")
                    if isinstance(original_request_payload, dict) and isinstance(original_request_payload.get("options"), list):
                        request_options = original_request_payload.get("options")
        if (
            isinstance(request_envelope.get("trace"), dict)
            and isinstance(request_envelope["trace"].get("in_reply_to"), str)
            and isinstance(request_options, list)
            and isinstance(payload.get("decision"), str)
            and payload["decision"] not in request_options
        ):
            result.add_error(
                ERR_SCHEMA_INVALID,
                "payload.decision",
                "payload.decision must match one of the offered request options.",
            )

    elif schema_id == "external_action_request.v1":
        _require_string(payload, "action_class", result)
        _require_string(payload, "intent", result)
        _validate_optional_string(payload, "target", result)
        _validate_optional_string(payload, "audit_note", result)
        if "risk_level" in payload and payload["risk_level"] is not None:
            risk_level = payload["risk_level"]
            if not isinstance(risk_level, str) or risk_level not in _ALLOWED_RISK_LEVELS:
                result.add_error(
                    ERR_SCHEMA_INVALID,
                    "payload.risk_level",
                    "payload.risk_level must be one of low, elevated, or critical.",
                )
            elif risk_level in {"elevated", "critical"}:
                authority = (envelope or {}).get("authority")
                principal = authority.get("principal") if isinstance(authority, dict) else None
                if not isinstance(principal, str) or not principal.strip():
                    result.add_error(
                        ERR_DELEGATION_PROOF_REQUIRED,
                        "authority.principal",
                        "High-risk external actions require an authority claim with authority.principal.",
                    )

    elif schema_id == "external_action_result.v1":
        _require_string(payload, "action_ref", result)
        if "outcome" not in payload or not isinstance(payload["outcome"], str) or payload["outcome"] not in {"success", "failure"}:
            result.add_error(
                ERR_SCHEMA_INVALID,
                "payload.outcome",
                "payload.outcome must be one of success or failure.",
            )
        if "operator_override" in payload and payload["operator_override"] is not None and not isinstance(payload["operator_override"], bool):
            result.add_error(
                ERR_SCHEMA_INVALID,
                "payload.operator_override",
                "payload.operator_override must be a boolean when present.",
            )
        _validate_optional_string(payload, "override_reason", result)
        if "override_expires_at" in payload and payload["override_expires_at"] is not None:
            _validate_timestamp(payload["override_expires_at"], "payload.override_expires_at", result, allow_null=True, code=ERR_SCHEMA_INVALID)
        if "override_closed_at" in payload and payload["override_closed_at"] is not None:
            _validate_timestamp(payload["override_closed_at"], "payload.override_closed_at", result, allow_null=True, code=ERR_SCHEMA_INVALID)
        _validate_optional_string(payload, "override_closure_note", result)
        _validate_optional_string(payload, "execution_log", result)

    elif schema_id == "protocol_error.v1":
        _require_string(payload, "error_code", result)
        _require_string(payload, "rejected_message_id", result)
        _require_string(payload, "reason", result)
        _validate_optional_string(payload, "rejected_schema", result)
        _validate_optional_string_list(payload, "offered_alternatives", result)
        if "recoverable" in payload and payload["recoverable"] is not None and not isinstance(payload["recoverable"], bool):
            result.add_error(
                ERR_SCHEMA_INVALID,
                "payload.recoverable",
                "payload.recoverable must be a boolean when present.",
            )

    elif schema_id == "workspace_create.v1":
        _require_string(payload, "purpose", result)
        _validate_optional_string(payload, "name", result)
        _validate_optional_string_list(payload, "linked_traces", result)
        _validate_optional_string_list(payload, "initial_members", result)
        if "join_policy" in payload and payload["join_policy"] is not None:
            join_policy = payload["join_policy"]
            if not isinstance(join_policy, str) or join_policy not in _ALLOWED_WORKSPACE_JOIN_POLICIES:
                result.add_error(
                    ERR_SCHEMA_INVALID,
                    "payload.join_policy",
                    "payload.join_policy must be one of invite or open.",
                )

    elif schema_id == "workspace_join.v1":
        _require_string(payload, "workspace_id", result)
        _validate_optional_string(payload, "reason", result)
        _validate_optional_string_list(payload, "interests", result)
        _validate_optional_int(payload, "max_receive_rate", result, min_value=1)
        if "membership_role" in payload and payload["membership_role"] is not None:
            membership_role = payload["membership_role"]
            if not isinstance(membership_role, str) or membership_role not in _ALLOWED_WORKSPACE_MEMBERSHIP_ROLES:
                result.add_error(
                    ERR_SCHEMA_INVALID,
                    "payload.membership_role",
                    "payload.membership_role must be one of member or observer.",
                )

    elif schema_id == "workspace_leave.v1":
        _require_string(payload, "workspace_id", result)
        _validate_optional_string(payload, "reason", result)

    elif schema_id == "workspace_close.v1":
        _require_string(payload, "workspace_id", result)
        _validate_optional_string(payload, "reason", result)

    elif schema_id == "workspace_state.v1":
        _require_string(payload, "workspace_id", result)
        if "workspace" in payload and payload["workspace"] is not None:
            workspace = payload["workspace"]
            if not isinstance(workspace, dict):
                result.add_error(ERR_SCHEMA_INVALID, "payload.workspace", "payload.workspace must be an object.")
        if "members" in payload and payload["members"] is not None:
            members = payload["members"]
            if not isinstance(members, list):
                result.add_error(ERR_SCHEMA_INVALID, "payload.members", "payload.members must be an array.")
        if "deltas" in payload and payload["deltas"] is not None:
            deltas = payload["deltas"]
            if not isinstance(deltas, list):
                result.add_error(ERR_SCHEMA_INVALID, "payload.deltas", "payload.deltas must be an array.")
        if "since_sequence" in payload and payload["since_sequence"] is not None:
            _validate_optional_int(payload, "since_sequence", result, min_value=0)

    elif schema_id == "workspace_delta.v1":
        _require_string(payload, "workspace_id", result)
        _require_string(payload, "delta_kind", result)
        _validate_optional_string(payload, "text", result)
        _validate_optional_string(payload, "related_message_id", result)
        _validate_optional_string(payload, "channel", result)
        _validate_optional_string(payload, "drop_policy", result)
        _validate_optional_string_list(payload, "artifacts", result)
        _validate_optional_string_list(payload, "refs", result)
        _validate_optional_int(payload, "ttl", result, min_value=1)
        if "priority" in payload and payload["priority"] is not None:
            priority = payload["priority"]
            if not isinstance(priority, str) or priority not in _ALLOWED_WORKSPACE_PRIORITIES:
                result.add_error(
                    ERR_SCHEMA_INVALID,
                    "payload.priority",
                    "payload.priority must be one of critical, normal, or background.",
                )

    # ------------------------------------------------------------------
    # P2: Review Beacons + Dissent Records
    # ------------------------------------------------------------------

    elif schema_id == "review_beacon.v1":
        _require_string(payload, "artifact", result)
        if "review_lens" not in payload or not isinstance(payload.get("review_lens"), str):
            result.add_error(ERR_SCHEMA_INVALID, "payload.review_lens", "payload.review_lens is required and must be a string.")
        elif payload["review_lens"] not in _ALLOWED_REVIEW_LENSES:
            result.add_error(
                ERR_SCHEMA_INVALID,
                "payload.review_lens",
                f"payload.review_lens must be one of {', '.join(sorted(_ALLOWED_REVIEW_LENSES))}.",
            )
        _validate_optional_string(payload, "lens_detail", result)
        _validate_optional_string_list(payload, "candidate_pool", result)
        if "urgency" in payload and payload["urgency"] is not None:
            urgency = payload["urgency"]
            if not isinstance(urgency, str) or urgency not in _ALLOWED_REVIEW_URGENCIES:
                result.add_error(
                    ERR_SCHEMA_INVALID,
                    "payload.urgency",
                    f"payload.urgency must be one of {', '.join(sorted(_ALLOWED_REVIEW_URGENCIES))}.",
                )
        _validate_optional_string_list(payload, "context_refs", result)
        _validate_optional_string(payload, "workspace_id", result)
        _validate_optional_string_list(payload, "accept_schemas", result)
        if "expires_at" in payload:
            _validate_timestamp(payload["expires_at"], "payload.expires_at", result, allow_null=True, code=ERR_SCHEMA_INVALID)

    elif schema_id == "review_claim.v1":
        _require_string(payload, "beacon_ref", result)
        _validate_optional_string(payload, "reviewer_context", result)
        if "estimated_completion" in payload:
            _validate_timestamp(payload["estimated_completion"], "payload.estimated_completion", result, allow_null=True, code=ERR_SCHEMA_INVALID)

    elif schema_id == "review_verdict.v1":
        _require_string(payload, "beacon_ref", result)
        if "verdict" not in payload or not isinstance(payload.get("verdict"), str):
            result.add_error(ERR_SCHEMA_INVALID, "payload.verdict", "payload.verdict is required and must be a string.")
        elif payload["verdict"] not in _ALLOWED_REVIEW_VERDICTS:
            result.add_error(
                ERR_SCHEMA_INVALID,
                "payload.verdict",
                f"payload.verdict must be one of {', '.join(sorted(_ALLOWED_REVIEW_VERDICTS))}.",
            )
        _validate_optional_float(payload, "confidence", result, min_value=0.0, max_value=1.0)
        _validate_optional_int(payload, "blocking_findings_count", result, min_value=0)
        # Validate findings array if present
        if "findings" in payload and payload["findings"] is not None:
            findings = payload["findings"]
            if not isinstance(findings, list):
                result.add_error(ERR_SCHEMA_INVALID, "payload.findings", "payload.findings must be an array.")
            else:
                for i, finding in enumerate(findings):
                    if not isinstance(finding, dict):
                        result.add_error(ERR_SCHEMA_INVALID, f"payload.findings[{i}]", "Each finding must be an object.")
                        continue
                    if "severity" in finding and finding["severity"] is not None:
                        if not isinstance(finding["severity"], str) or finding["severity"] not in _ALLOWED_FINDING_SEVERITIES:
                            result.add_error(
                                ERR_SCHEMA_INVALID,
                                f"payload.findings[{i}].severity",
                                f"severity must be one of {', '.join(sorted(_ALLOWED_FINDING_SEVERITIES))}.",
                            )
                    for finding_field in ("category", "description", "location", "suggestion"):
                        if finding_field in finding and finding[finding_field] is not None:
                            if not isinstance(finding[finding_field], str):
                                result.add_error(
                                    ERR_SCHEMA_INVALID,
                                    f"payload.findings[{i}].{finding_field}",
                                    f"{finding_field} must be a string when present.",
                                )
        # Validate inline dissent if present
        if "dissent" in payload and payload["dissent"] is not None:
            dissent = payload["dissent"]
            if not isinstance(dissent, dict):
                result.add_error(ERR_SCHEMA_INVALID, "payload.dissent", "payload.dissent must be an object.")
            else:
                _validate_inline_dissent(dissent, "payload.dissent", result)

    elif schema_id == "dissent_record.v1":
        _require_string(payload, "decision_ref", result)
        _require_string(payload, "chosen_path", result)
        _require_string(payload, "dissenting_agent", result)
        _validate_optional_string(payload, "alternate_path", result)
        _validate_optional_string(payload, "rationale", result)
        _validate_optional_float(payload, "confidence", result, min_value=0.0, max_value=1.0)
        _validate_optional_string_list(payload, "evidence_refs", result)
        _validate_optional_string(payload, "risk_if_wrong", result)
        if "revisit_trigger" in payload and payload["revisit_trigger"] is not None:
            trigger = payload["revisit_trigger"]
            if not isinstance(trigger, str) or trigger not in _ALLOWED_REVISIT_TRIGGERS:
                result.add_error(
                    ERR_SCHEMA_INVALID,
                    "payload.revisit_trigger",
                    f"payload.revisit_trigger must be one of {', '.join(sorted(_ALLOWED_REVISIT_TRIGGERS))}.",
                )
        if "revisit_by" in payload:
            _validate_timestamp(payload["revisit_by"], "payload.revisit_by", result, allow_null=True, code=ERR_SCHEMA_INVALID)
        if "blocking" in payload and payload["blocking"] is not None and not isinstance(payload["blocking"], bool):
            result.add_error(ERR_SCHEMA_INVALID, "payload.blocking", "payload.blocking must be a boolean when present.")
        _validate_optional_string(payload, "workspace_id", result)

    elif schema_id == "dissent_resolution.v1":
        _require_string(payload, "dissent_ref", result)
        if "resolution" not in payload or not isinstance(payload.get("resolution"), str):
            result.add_error(ERR_SCHEMA_INVALID, "payload.resolution", "payload.resolution is required and must be a string.")
        elif payload["resolution"] not in _ALLOWED_DISSENT_RESOLUTIONS:
            result.add_error(
                ERR_SCHEMA_INVALID,
                "payload.resolution",
                f"payload.resolution must be one of {', '.join(sorted(_ALLOWED_DISSENT_RESOLUTIONS))}.",
            )
        _validate_optional_string(payload, "resolution_rationale", result)
        _validate_optional_string_list(payload, "resolution_evidence", result)

    return result


def validate_message(envelope: Any, *, original_envelope: Any | None = None) -> ValidationResult:
    result = validate_envelope(envelope)
    if not result.valid or not isinstance(envelope, dict):
        return result
        
    if "encryption" in envelope and isinstance(envelope["encryption"], dict):
        return result
        
    result.extend(validate_schema(envelope.get("schema"), envelope.get("payload"), envelope=envelope))
    trace = envelope.get("trace")
    if (
        original_envelope is not None
        and isinstance(trace, dict)
        and isinstance(trace.get("in_reply_to"), str)
    ):
        violation = check_reply_schema_constraint(original_envelope, envelope)
        if violation:
            result.add_error(ERR_NEGOTIATION_FAILED, "schema", violation)
    return result


def extract_preflight(envelope: Any) -> PreflightSurface:
    if not isinstance(envelope, dict):
        return PreflightSurface()

    trust = envelope.get("trust")
    if not isinstance(trust, dict):
        trust = {}

    accept_schemas = envelope.get("accept_schemas")
    normalized_accept_schemas: tuple[str, ...] | None
    if isinstance(accept_schemas, list):
        normalized_accept_schemas = tuple(
            schema_id for schema_id in accept_schemas if isinstance(schema_id, str)
        )
    else:
        normalized_accept_schemas = None

    trace = envelope.get("trace")
    message_id = trace.get("message_id") if isinstance(trace, dict) else None

    # Participant roles
    participants = envelope.get("participants")
    if not isinstance(participants, dict):
        participants = {}

    return PreflightSurface(
        wire_v=envelope.get("wire_v"),
        schema=envelope.get("schema"),
        signal_class=envelope.get("signal_class"),
        tier_required=trust.get("tier_required"),
        requires_operator=trust.get("requires_operator"),
        expires_at=envelope.get("expires_at"),
        max_hops=envelope.get("max_hops"),
        accept_schemas=normalized_accept_schemas,
        message_id=message_id,
        origin=participants.get("origin"),
        subject_of=participants.get("subject_of") or participants.get("subject_agent"),
        principal=participants.get("principal"),
        consequence_scope=envelope.get("consequence_scope"),
    )


def evaluate_preflight(
    envelope: Any,
    *,
    now: datetime | str | None = None,
    policy: PreflightPolicy | None = None,
    require_forwardable: bool = False,
    proposed_reply_schema: str | None = None,
    available_reply_schemas: tuple[str, ...] | list[str] | None = None,
) -> PreflightDecision:
    surface = envelope if isinstance(envelope, PreflightSurface) else extract_preflight(envelope)
    active_policy = policy or PreflightPolicy()

    if surface.wire_v is None:
        return PreflightDecision(
            "reject",
            surface=surface,
            code=ERR_MALFORMED_ENVELOPE,
            reason="Preflight surface is missing wire_v.",
        )

    if surface.wire_v not in active_policy.supported_wire_versions:
        return PreflightDecision(
            "reject",
            surface=surface,
            code=ERR_WIRE_VERSION,
            reason=f"Unsupported wire_v '{surface.wire_v}'.",
        )

    if not isinstance(surface.schema, str) or not surface.schema:
        return PreflightDecision(
            "reject",
            surface=surface,
            code=ERR_MALFORMED_ENVELOPE,
            reason="Preflight surface is missing schema.",
        )

    if active_policy.known_schemas is not None and surface.schema not in active_policy.known_schemas:
        return PreflightDecision(
            "reject",
            surface=surface,
            code=ERR_UNSUPPORTED_SCHEMA,
            reason=f"Unsupported schema '{surface.schema}'.",
        )

    if surface.is_expired(now=now) is True:
        return PreflightDecision(
            "reject",
            surface=surface,
            code=ERR_EXPIRED,
            reason="Signal has expired according to expires_at.",
        )

    if surface.max_hops is not None and not _is_int(surface.max_hops):
        return PreflightDecision(
            "reject",
            surface=surface,
            code=ERR_MALFORMED_ENVELOPE,
            reason="max_hops must be a non-negative integer when present.",
        )

    if require_forwardable and surface.max_hops is not None and surface.max_hops <= 0:
        return PreflightDecision(
            "reject",
            surface=surface,
            code=ERR_HOP_LIMIT_EXCEEDED,
            reason="Signal cannot be forwarded because max_hops is exhausted.",
        )

    if (
        proposed_reply_schema is not None
        and surface.accept_schemas is not None
        and proposed_reply_schema not in surface.accept_schemas
    ):
        alternatives: tuple[str, ...] | None = None
        if available_reply_schemas:
            alternatives = tuple(
                schema_id
                for schema_id in available_reply_schemas
                if isinstance(schema_id, str) and schema_id != proposed_reply_schema
            ) or None
        return PreflightDecision(
            "reject",
            surface=surface,
            code=ERR_NEGOTIATION_FAILED,
            reason=f"Reply schema '{proposed_reply_schema}' is not allowed by accept_schemas.",
            offered_alternatives=alternatives,
        )

    # Trust tier enforcement (2ack P1): reject if receiver's tier is below
    # the sender's declared tier_required.
    if (
        surface.tier_required is not None
        and active_policy.receiver_trust_tier is not None
        and _is_int(surface.tier_required)
        and active_policy.receiver_trust_tier < surface.tier_required
    ):
        return PreflightDecision(
            "reject",
            surface=surface,
            code=ERR_TRUST_INSUFFICIENT,
            reason=(
                f"Signal requires trust tier {surface.tier_required}, "
                f"but receiver has tier {active_policy.receiver_trust_tier}."
            ),
        )

    if surface.requires_operator is True and active_policy.operator_available is False:
        return PreflightDecision(
            "defer",
            surface=surface,
            reason="Signal requires operator approval before action.",
        )

    # 2ACK P1.6: Truth label quality check on high-impact envelopes.
    # If a flash/priority envelope or action-requiring schema has _label
    # fields with negative states, surface as advisory (accept with reason).
    if isinstance(envelope, dict):
        _high_impact_schemas = {
            "decision_request.v1", "external_action_request.v1", "handoff_baton.v1",
        }
        is_high_impact = (
            surface.schema in _high_impact_schemas
            or (isinstance(envelope.get("payload"), dict) and
                str(envelope["payload"].get("priority", "")).lower() in ("flash", "priority"))
        )
        if is_high_impact:
            degraded_labels = []
            for key, value in envelope.items():
                if key.endswith("_label") and isinstance(value, dict):
                    neg_states = value.get("negative_states") or []
                    if neg_states:
                        state_names = [ns.get("state", "?") for ns in neg_states if isinstance(ns, dict)]
                        degraded_labels.append(f"{key}: [{', '.join(state_names)}]")
            payload = envelope.get("payload")
            if isinstance(payload, dict):
                for key, value in payload.items():
                    if key.endswith("_label") and isinstance(value, dict):
                        neg_states = value.get("negative_states") or []
                        if neg_states:
                            state_names = [ns.get("state", "?") for ns in neg_states if isinstance(ns, dict)]
                            degraded_labels.append(f"payload.{key}: [{', '.join(state_names)}]")
            if degraded_labels:
                advisory = f"High-impact signal has degraded truth labels: {'; '.join(degraded_labels)}"
                return PreflightDecision("accept", surface=surface, reason=advisory)

    return PreflightDecision("accept", surface=surface)


def check_reply_schema_constraint(
    original_payload: Any,
    reply_payload: Any,
) -> str | None:
    """Check if a reply's schema satisfies the original message's accept_schemas constraint.

    Returns None if allowed, or an error reason string if the reply violates the constraint.
    Only enforces when both payloads are 2ack envelopes and the original declares accept_schemas.
    Accepts either dict payloads or JSON-encoded envelope strings from storage.
    """
    if isinstance(original_payload, str):
        try:
            original_payload = json.loads(original_payload)
        except (TypeError, ValueError, json.JSONDecodeError):
            pass
    if isinstance(reply_payload, str):
        try:
            reply_payload = json.loads(reply_payload)
        except (TypeError, ValueError, json.JSONDecodeError):
            pass

    if not isinstance(original_payload, dict) or not isinstance(reply_payload, dict):
        return None

    accept_schemas = original_payload.get("accept_schemas")
    if not isinstance(accept_schemas, list) or not accept_schemas:
        return None

    reply_schema = reply_payload.get("schema")
    if not isinstance(reply_schema, str):
        return None

    # protocol_error.v1 is always allowed as a reply — agents must be able
    # to send typed rejections regardless of accept_schemas constraints
    if reply_schema == "protocol_error.v1":
        return None

    if reply_schema in accept_schemas:
        return None

    return (
        f"Reply schema '{reply_schema}' is not in the original message's "
        f"accept_schemas {accept_schemas}. Use one of the accepted schemas or "
        f"send a protocol_error.v1 rejection."
    )


def validate_authority_claim(
    envelope: dict[str, Any],
    verify_nonce: Any | None = None,
) -> str | None:
    """Check if an authority-bearing envelope has valid proof material.

    Returns None if no authority claim is present or if the proof validates.
    Returns an error reason string if the proof is missing or invalid.

    Args:
        envelope: A 2ack envelope dict.
        verify_nonce: Optional callable(nonce: str, required_scope: dict) -> bool.
            If provided, server nonce proofs are verified against it.
            If not provided, structural checks only (nonce format, required fields).
    """
    authority = envelope.get("authority")
    if not isinstance(authority, dict):
        return None  # No authority claim — nothing to validate

    principal = authority.get("principal")
    if not isinstance(principal, str) or not principal:
        return "authority.principal is required when authority is present"

    proof = envelope.get("authority_proof")
    if proof is None:
        return (
            f"authority_proof is required when authority is declared "
            f"(principal: {principal})"
        )

    # Server nonce proof validation
    if isinstance(proof, dict) and proof.get("kind") == "server_nonce":
        nonce = proof.get("nonce")
        if not isinstance(nonce, str) or not nonce:
            return "authority_proof.nonce is required for server_nonce proofs"

        if verify_nonce is not None:
            scope = authority.get("scope")
            required_scope = scope if isinstance(scope, dict) else {}
            if not verify_nonce(nonce, required_scope):
                return (
                    f"authority_proof nonce verification failed for principal "
                    f"'{principal}'. Nonce may be expired, revoked, or scope mismatch."
                )

    # Delegation token proof — structural check only for now
    elif isinstance(proof, dict) and proof.get("kind") == "delegation_token":
        ref = proof.get("ref")
        if not isinstance(ref, str) or not ref:
            return "authority_proof.ref is required for delegation_token proofs"

    # Unknown proof kinds are allowed but logged — future-compatible
    return None


def build_protocol_error(
    *,
    message_id: str,
    rejected_message_id: str,
    error_code: str,
    reason: str,
    trace_id: str | None = None,
    thread_id: str | None = None,
    rejected_schema: str | None = None,
    offered_alternatives: list[str] | tuple[str, ...] | None = None,
    recoverable: bool | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "error_code": error_code,
        "rejected_message_id": rejected_message_id,
        "reason": reason,
    }
    if rejected_schema is not None:
        payload["rejected_schema"] = rejected_schema
    if offered_alternatives is not None:
        payload["offered_alternatives"] = list(offered_alternatives)
    if recoverable is not None:
        payload["recoverable"] = recoverable

    trace: dict[str, Any] = {"message_id": message_id}
    if trace_id is not None:
        trace["trace_id"] = trace_id
    if thread_id is not None:
        trace["thread_id"] = thread_id

    return {
        "wire_v": 1,
        "schema": "protocol_error.v1",
        "mode": "agent-native",
        "signal_class": "whispers_internal",
        "trace": trace,
        "payload": payload,
    }


def round_trip(envelope: Any) -> Any:
    return json.loads(json.dumps(envelope))


def build_a2a_message(
    envelope: dict[str, Any],
    *,
    text: str | None = None,
    metadata: dict[str, Any] | None = None,
    role: str = "user",
) -> dict[str, Any]:
    validation = validate_message(envelope)
    if not validation.valid:
        joined = "; ".join(f"{error.path}: {error.message}" for error in validation.errors)
        raise ValueError(f"Cannot build A2A message from invalid 2ack envelope: {joined}")

    trace = envelope["trace"]
    message_id = trace["message_id"]
    parts: list[dict[str, Any]] = [{"data": round_trip(envelope)}]

    fallback_text = text if text is not None else derive_text_fallback(envelope)
    if fallback_text:
        parts.append({"text": fallback_text})

    merged_metadata = dict(metadata or {})
    merged_metadata["whispers:schema"] = envelope["schema"]
    if envelope.get("mode") is not None:
        merged_metadata["whispers:wireMode"] = envelope["mode"]
    if envelope.get("signal_class") is not None:
        merged_metadata["whispers:signalClass"] = envelope["signal_class"]

    message = {
        "role": role,
        "parts": parts,
        "messageId": message_id,
    }
    if merged_metadata:
        message["metadata"] = merged_metadata
    return message


def extract_a2a_binding(message: Any) -> A2ABinding:
    if not isinstance(message, dict):
        return A2ABinding(
            envelope=None,
            text_parts=(),
            metadata_mirrors={},
            message_id=None,
            conflicts=(),
        )

    parts = message.get("parts")
    if not isinstance(parts, list):
        parts = []

    envelope = None
    text_parts: list[str] = []
    for part in parts:
        if not isinstance(part, dict):
            continue
        text = part.get("text")
        if isinstance(text, str):
            text_parts.append(text)
        data = part.get("data")
        if envelope is None and isinstance(data, dict) and _looks_like_twoack_envelope(data):
            envelope = round_trip(data)

    metadata = message.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}

    mirrors = {
        key: value
        for key, value in metadata.items()
        if key in {"whispers:schema", "whispers:wireMode", "whispers:signalClass", "whispers:wireProfiles"}
    }
    conflicts = _detect_a2a_mirror_conflicts(envelope, mirrors, message.get("messageId"))

    return A2ABinding(
        envelope=envelope,
        text_parts=tuple(text_parts),
        metadata_mirrors=mirrors,
        message_id=message.get("messageId"),
        conflicts=tuple(conflicts),
    )


def evaluate_conformance_level(message: Any, level: int) -> ConformanceObservation:
    if level not in (0, 1, 2, 3):
        raise ValueError("Conformance level must be 0, 1, 2, or 3.")

    binding = extract_a2a_binding(message)

    if level == 0:
        return ConformanceObservation(
            level=level,
            envelope_present=binding.envelope is not None,
            fallback_text=binding.fallback_text,
            preserved_envelope=None,
            can_execute=False,
            rejection_code=None,
            metadata_conflicts=binding.conflicts,
        )

    if level == 1:
        return ConformanceObservation(
            level=level,
            envelope_present=binding.envelope is not None,
            fallback_text=binding.fallback_text,
            preserved_envelope=round_trip(binding.envelope) if binding.envelope is not None else None,
            can_execute=False,
            rejection_code=None,
            metadata_conflicts=binding.conflicts,
        )

    if binding.envelope is None:
        return ConformanceObservation(
            level=level,
            envelope_present=False,
            fallback_text=binding.fallback_text,
            preserved_envelope=None,
            can_execute=False,
            rejection_code=None,
            metadata_conflicts=binding.conflicts,
        )

    validation = validate_message(binding.envelope)
    rejection_code = validation.codes[0] if validation.codes else None
    return ConformanceObservation(
        level=level,
        envelope_present=True,
        fallback_text=binding.fallback_text,
        preserved_envelope=round_trip(binding.envelope),
        can_execute=validation.valid,
        rejection_code=rejection_code,
        metadata_conflicts=binding.conflicts,
    )


def derive_text_fallback(envelope: Any) -> str | None:
    if not isinstance(envelope, dict):
        return None
    summary = envelope.get("summary")
    if isinstance(summary, dict):
        for field_name in ("human", "brief", "headline"):
            value = summary.get(field_name)
            if isinstance(value, str) and value.strip():
                return value
    return None


def _is_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _looks_like_twoack_envelope(value: dict[str, Any]) -> bool:
    return _REQUIRED_ENVELOPE_FIELDS.issubset(value.keys())


def _detect_a2a_mirror_conflicts(
    envelope: dict[str, Any] | None,
    metadata_mirrors: dict[str, Any],
    outer_message_id: Any,
) -> list[str]:
    if envelope is None:
        return []

    conflicts: list[str] = []
    if metadata_mirrors.get("whispers:schema") not in (None, envelope.get("schema")):
        conflicts.append("whispers:schema")
    if metadata_mirrors.get("whispers:wireMode") not in (None, envelope.get("mode")):
        conflicts.append("whispers:wireMode")
    if metadata_mirrors.get("whispers:signalClass") not in (None, envelope.get("signal_class")):
        conflicts.append("whispers:signalClass")

    trace = envelope.get("trace")
    if (
        isinstance(trace, dict)
        and isinstance(trace.get("message_id"), str)
        and outer_message_id not in (None, trace["message_id"])
    ):
        conflicts.append("messageId")

    return conflicts


def _validate_schema_id(value: Any, path: str, result: ValidationResult, *, code: str) -> None:
    if not isinstance(value, str) or not _SCHEMA_ID_RE.fullmatch(value):
        result.add_error(code, path, f"{path} must use the name.vN format.")


def _validate_enum_field(
    envelope: dict[str, Any],
    field_name: str,
    allowed_values: set[str],
    result: ValidationResult,
) -> None:
    if field_name not in envelope:
        return
    value = envelope[field_name]
    if value is None:
        result.add_error(ERR_MALFORMED_ENVELOPE, field_name, f"{field_name} may not be null.")
    elif not isinstance(value, str) or value not in allowed_values:
        allowed = ", ".join(sorted(allowed_values))
        result.add_error(ERR_MALFORMED_ENVELOPE, field_name, f"{field_name} must be one of: {allowed}.")


def _validate_optional_object(envelope: dict[str, Any], field_name: str, result: ValidationResult) -> None:
    if field_name in envelope and envelope[field_name] is not None and not isinstance(envelope[field_name], dict):
        result.add_error(ERR_MALFORMED_ENVELOPE, field_name, f"{field_name} must be an object when present.")


def _validate_claim_label(label: dict[str, Any], path: str, result: ValidationResult) -> None:
    """Validate a _label suffix field as a well-formed ClaimLabel."""
    if "basis" in label:
        if label["basis"] not in VALID_BASIS_VALUES:
            result.add_error(
                ERR_MALFORMED_ENVELOPE, f"{path}.basis",
                f"Unknown basis '{label['basis']}'. Valid: {sorted(VALID_BASIS_VALUES)}",
            )
    if "confidence" in label:
        conf = label["confidence"]
        if not isinstance(conf, (int, float)) or conf < 0.0 or conf > 1.0:
            result.add_error(
                ERR_MALFORMED_ENVELOPE, f"{path}.confidence",
                "confidence must be a number between 0.0 and 1.0.",
            )
    if "evidence_refs" in label:
        refs = label["evidence_refs"]
        if not isinstance(refs, list) or not all(isinstance(r, str) for r in refs):
            result.add_error(
                ERR_MALFORMED_ENVELOPE, f"{path}.evidence_refs",
                "evidence_refs must be an array of strings.",
            )
    if "negative_states" in label:
        ns_list = label["negative_states"]
        if not isinstance(ns_list, list):
            result.add_error(
                ERR_MALFORMED_ENVELOPE, f"{path}.negative_states",
                "negative_states must be an array.",
            )
        elif ns_list:
            for i, ns in enumerate(ns_list):
                if not isinstance(ns, dict):
                    result.add_error(
                        ERR_MALFORMED_ENVELOPE, f"{path}.negative_states[{i}]",
                        "Each negative state must be an object.",
                    )
                elif "state" not in ns:
                    result.add_error(
                        ERR_MALFORMED_ENVELOPE, f"{path}.negative_states[{i}].state",
                        "Missing required field 'state'.",
                    )
                elif ns["state"] not in VALID_NEGATIVE_STATES:
                    result.add_error(
                        ERR_MALFORMED_ENVELOPE, f"{path}.negative_states[{i}].state",
                        f"Unknown negative state '{ns['state']}'. Valid: {sorted(VALID_NEGATIVE_STATES)}",
                    )


def _validate_timestamp(
    value: Any,
    path: str,
    result: ValidationResult,
    *,
    allow_null: bool,
    code: str,
) -> None:
    if value is None:
        if not allow_null:
            result.add_error(code, path, f"{path} may not be null.")
        return
    if not isinstance(value, str) or not _RFC3339_RE.fullmatch(value):
        result.add_error(code, path, f"{path} must be an RFC 3339 timestamp.")
        return
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        result.add_error(code, path, f"{path} must be an RFC 3339 timestamp.")


def _require_string(
    payload: dict[str, Any],
    field_name: str,
    result: ValidationResult,
    *,
    max_bytes: int = MAX_STRING_FIELD_BYTES,
) -> str | None:
    value = payload.get(field_name)
    if not isinstance(value, str) or not value.strip():
        result.add_error(
            ERR_SCHEMA_INVALID,
            f"payload.{field_name}",
            f"payload.{field_name} must be a non-empty string.",
        )
        return None
    elif len(value.encode("utf-8", errors="replace")) > max_bytes:
        result.add_error(
            ERR_SCHEMA_INVALID,
            f"payload.{field_name}",
            f"payload.{field_name} exceeds maximum length of {max_bytes} bytes.",
        )
        return None
    return value


def _validate_optional_string(payload: dict[str, Any], field_name: str, result: ValidationResult, *, max_bytes: int = MAX_STRING_FIELD_BYTES) -> None:
    if field_name in payload and payload[field_name] is not None:
        if not isinstance(payload[field_name], str):
            result.add_error(
                ERR_SCHEMA_INVALID,
                f"payload.{field_name}",
                f"payload.{field_name} must be a string when present.",
            )
        elif len(payload[field_name].encode("utf-8", errors="replace")) > max_bytes:
            result.add_error(
                ERR_SCHEMA_INVALID,
                f"payload.{field_name}",
                f"payload.{field_name} exceeds maximum length of {max_bytes} bytes.",
        )


def _require_string_list(
    payload: dict[str, Any],
    field_name: str,
    result: ValidationResult,
    *,
    allow_empty: bool,
) -> list[str] | None:
    value = payload.get(field_name)
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        result.add_error(
            ERR_SCHEMA_INVALID,
            f"payload.{field_name}",
            f"payload.{field_name} must be an array of strings.",
        )
        return None
    if not allow_empty and not value:
        result.add_error(
            ERR_SCHEMA_INVALID,
            f"payload.{field_name}",
            f"payload.{field_name} must not be empty.",
        )
    return value


def _validate_optional_string_list(payload: dict[str, Any], field_name: str, result: ValidationResult) -> None:
    if field_name not in payload or payload[field_name] is None:
        return
    _require_string_list(payload, field_name, result, allow_empty=True)


def _validate_optional_float(
    payload: dict[str, Any],
    field_name: str,
    result: ValidationResult,
    *,
    min_value: float,
    max_value: float,
) -> None:
    if field_name not in payload or payload[field_name] is None:
        return
    value = payload[field_name]
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        result.add_error(
            ERR_SCHEMA_INVALID,
            f"payload.{field_name}",
            f"payload.{field_name} must be a float in the inclusive range {min_value}..{max_value}.",
        )
        return
    if value < min_value or value > max_value:
        result.add_error(
            ERR_SCHEMA_INVALID,
            f"payload.{field_name}",
            f"payload.{field_name} must be a float in the inclusive range {min_value}..{max_value}.",
        )


def _validate_optional_int(
    payload: dict[str, Any],
    field_name: str,
    result: ValidationResult,
    *,
    min_value: int,
) -> None:
    if field_name not in payload or payload[field_name] is None:
        return
    value = payload[field_name]
    if not isinstance(value, int) or isinstance(value, bool) or value < min_value:
        result.add_error(
            ERR_SCHEMA_INVALID,
            f"payload.{field_name}",
            f"payload.{field_name} must be an integer >= {min_value}.",
        )
        return


def _validate_inline_dissent(dissent: dict[str, Any], path: str, result: ValidationResult) -> None:
    """Validate an inline dissent_record payload embedded in a review_verdict."""
    for req_field in ("decision_ref", "chosen_path", "dissenting_agent"):
        if req_field not in dissent or not isinstance(dissent.get(req_field), str) or not dissent[req_field].strip():
            result.add_error(ERR_SCHEMA_INVALID, f"{path}.{req_field}", f"{path}.{req_field} is required and must be a non-empty string.")
    for opt_field in ("alternate_path", "rationale", "risk_if_wrong"):
        if opt_field in dissent and dissent[opt_field] is not None and not isinstance(dissent[opt_field], str):
            result.add_error(ERR_SCHEMA_INVALID, f"{path}.{opt_field}", f"{path}.{opt_field} must be a string when present.")
    if "confidence" in dissent and dissent["confidence"] is not None:
        conf = dissent["confidence"]
        if not isinstance(conf, (int, float)) or isinstance(conf, bool) or conf < 0.0 or conf > 1.0:
            result.add_error(ERR_SCHEMA_INVALID, f"{path}.confidence", f"{path}.confidence must be a float in [0.0, 1.0].")
    if "blocking" in dissent and dissent["blocking"] is not None and not isinstance(dissent["blocking"], bool):
        result.add_error(ERR_SCHEMA_INVALID, f"{path}.blocking", f"{path}.blocking must be a boolean when present.")
    if "evidence_refs" in dissent and dissent["evidence_refs"] is not None:
        refs = dissent["evidence_refs"]
        if not isinstance(refs, list) or any(not isinstance(r, str) for r in refs):
            result.add_error(ERR_SCHEMA_INVALID, f"{path}.evidence_refs", f"{path}.evidence_refs must be an array of strings when present.")
    if "revisit_trigger" in dissent and dissent["revisit_trigger"] is not None:
        trigger = dissent["revisit_trigger"]
        if not isinstance(trigger, str) or trigger not in _ALLOWED_REVISIT_TRIGGERS:
            result.add_error(ERR_SCHEMA_INVALID, f"{path}.revisit_trigger", f"{path}.revisit_trigger must be one of {', '.join(sorted(_ALLOWED_REVISIT_TRIGGERS))}.")
    if "revisit_by" in dissent:
        _validate_timestamp(dissent["revisit_by"], f"{path}.revisit_by", result, allow_null=True, code=ERR_SCHEMA_INVALID)


def _validate_string_list(
    value: Any,
    path: str,
    result: ValidationResult,
    *,
    allow_empty: bool,
    code: str,
) -> None:
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        result.add_error(code, path, f"{path} must be an array of strings.")
        return
    if not allow_empty and not value:
        result.add_error(code, path, f"{path} must not be empty.")


def _validate_list(
    value: Any,
    path: str,
    result: ValidationResult,
    *,
    allow_empty: bool,
    code: str,
) -> None:
    if not isinstance(value, list):
        result.add_error(code, path, f"{path} must be an array.")
        return
    if not allow_empty and not value:
        result.add_error(code, path, f"{path} must not be empty.")
