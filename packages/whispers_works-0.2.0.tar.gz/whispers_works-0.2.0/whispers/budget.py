from typing import Dict, TypedDict

class TrustTierBudget(TypedDict):
    requests_per_min: int
    bytes_per_min: int
    max_queued_recipients: int

# Default limits based on Agent Trust Tier (1-5)
# Tier 1: Guest (Highly constrained, safe playground)
# Tier 2: Standard Agent (Normal operational volume)
# Tier 3: Team Member (High volume intra-team tasks)
# Tier 4: Core/Trusted (Substrate-level volume)
# Tier 5: Operator (Unlimited/Massive bounds for the human orchestrator)

TRUST_TIER_BUDGETS: Dict[int, TrustTierBudget] = {
    1: {"requests_per_min": 20, "bytes_per_min": 50_000, "max_queued_recipients": 50},
    2: {"requests_per_min": 100, "bytes_per_min": 200_000, "max_queued_recipients": 250},
    3: {"requests_per_min": 500, "bytes_per_min": 1_000_000, "max_queued_recipients": 1000},
    4: {"requests_per_min": 1000, "bytes_per_min": 10_000_000, "max_queued_recipients": 5000},
    5: {"requests_per_min": 10000, "bytes_per_min": 100_000_000, "max_queued_recipients": 20000},  # Operator bypass
}

def get_budget_for_tier(tier: int | str | None) -> TrustTierBudget:
    """
    Return the allocated network budget for a given trust tier.
    Falls back to Tier 1 constraints if the tier is unrecognized, providing
    fail-safe bounds for unverified agents.
    """
    try:
        tier_int = int(tier) if tier is not None else 1
    except ValueError:
        tier_int = 1
        
    return TRUST_TIER_BUDGETS.get(tier_int, TRUST_TIER_BUDGETS[1])
