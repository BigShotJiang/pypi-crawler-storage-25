"""Pre-handoff cognitive load checks — advisory routing.

Before assigning work via handoff, check the target agent's readiness,
interruptibility, and context load. Returns an advisory recommendation:

- "clear": good to go
- "caution": agent is busy but interruptible, proceed with awareness
- "defer": agent is saturated or uninterruptible, suggest waiting or reassigning
- "unavailable": agent is offline or degraded

This is advisory-first — handoffs still deliver, but the sender gets a
heads-up about the recipient's state. The operator can override.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger("whispers")


def check_handoff_readiness(
    db: Any,
    target_agent: str,
) -> dict[str, Any]:
    """Check if a target agent is ready to receive a handoff.

    Returns advisory result with recommendation and state details.
    """
    result: dict[str, Any] = {
        "target": target_agent,
        "recommendation": "clear",
        "reasons": [],
    }

    # Check if agent is online
    try:
        if not db.agent_has_active_session(target_agent):
            result["recommendation"] = "unavailable"
            result["reasons"].append("agent is offline")
            return result
    except Exception:
        pass  # Can't determine — assume available

    # Get runtime state
    try:
        runtime = db.get_runtime_state(target_agent)
    except Exception:
        return result  # Can't determine state — clear by default

    readiness = runtime.get("readiness", "ready")
    interruptibility = runtime.get("interruptibility")
    context_load = runtime.get("context_load")
    quality_risk = runtime.get("quality_risk")
    current_task = runtime.get("current_task")

    # Check quality risk
    if quality_risk == "high":
        result["recommendation"] = "defer"
        result["reasons"].append("quality risk is high — agent may be hallucinating")
        return result

    # Check readiness
    if readiness == "paused_by_operator":
        result["recommendation"] = "unavailable"
        result["reasons"].append("agent is paused by operator")
        return result
    elif readiness == "blocked":
        result["recommendation"] = "defer"
        result["reasons"].append("agent is blocked")
    elif readiness == "degraded":
        result["recommendation"] = "defer"
        result["reasons"].append("agent is degraded")
    elif readiness == "busy":
        result["recommendation"] = "caution"
        result["reasons"].append(f"agent is busy" + (f" on: {current_task}" if current_task else ""))

    # Check context load
    if isinstance(context_load, (int, float)):
        result["context_load"] = context_load
        if context_load >= 0.9:
            result["recommendation"] = "defer"
            result["reasons"].append(f"context window nearly full ({context_load:.0%})")
        elif context_load >= 0.7:
            if result["recommendation"] == "clear":
                result["recommendation"] = "caution"
            result["reasons"].append(f"context load elevated ({context_load:.0%})")

    # Check interruptibility
    if interruptibility == "do_not_interrupt":
        result["recommendation"] = "defer"
        result["reasons"].append("agent requested no interruptions")
    elif interruptibility == "urgent_only":
        if result["recommendation"] == "clear":
            result["recommendation"] = "caution"
        result["reasons"].append("agent only accepting urgent interrupts")

    # Count active batons
    try:
        active_batons = db.list_baton_projections(
            assignee_callsign=target_agent,
            state="in_progress",
        )
        if active_batons and len(active_batons) >= 3:
            if result["recommendation"] == "clear":
                result["recommendation"] = "caution"
            result["reasons"].append(f"already carrying {len(active_batons)} active batons")
    except Exception:
        pass

    return result


def format_preflight_advisory(check: dict[str, Any]) -> str:
    """Format a preflight check result as a human-readable advisory."""
    rec = check["recommendation"]
    target = check["target"]
    reasons = check.get("reasons", [])

    if rec == "clear":
        return f"{target} is ready for a handoff."

    icon = {"caution": "!", "defer": "!!", "unavailable": "X"}[rec]
    lines = [f"[{icon}] Handoff to {target}: {rec.upper()}"]
    for r in reasons:
        lines.append(f"  - {r}")

    if rec == "defer":
        lines.append("  Consider waiting or assigning to another agent.")
    elif rec == "caution":
        lines.append("  Proceed with awareness — the agent may be slower to respond.")

    return "\n".join(lines)
