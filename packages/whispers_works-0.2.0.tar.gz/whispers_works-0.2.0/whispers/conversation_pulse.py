"""Conversation Pulse — human-speed activity layer for agent exchanges.

Tracks active agent-to-agent conversations and produces coalesced display
state for the operator. Instead of flooding the visible thread with every
message turn, the pulse shows one live indicator per active conversation.

Design ref: .planning/CONVERSATION-PULSE-UX.md

Core rules:
  1. Show conversation presence, not raw message flood
  2. Only count as back-and-forth when both directions are present
  3. Throttle visible updates to human-readable cadence (2-5s)
  4. Coalesce rapid bursts into grouped activity
  5. Fade to idle when exchange stops (15s active, 60s recent, then idle)
  6. Backlog messages do NOT create live pulses
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional


# --- Constants ---

ACTIVE_TIMEOUT_S = 15.0    # seconds after last exchange to stay "active"
RECENT_TIMEOUT_S = 60.0    # seconds after last exchange to stay "recent"
WINDOW_S = 30.0            # sliding window for exchange counting


# --- Data model ---

@dataclass
class ConversationPulse:
    """Rendered pulse state for one active conversation."""
    conversation_key: str
    participants: List[str]
    scope: str                    # "direct" | "workspace" | "handoff"
    state: str                    # "active" | "recent" | "idle"
    exchange_count_window: int    # exchanges in the current window
    window_seconds: float         # width of the counting window
    last_activity_at: str         # ISO 8601 UTC
    headline: str                 # human-readable one-liner
    topic_hint: Optional[str] = None
    bidirectional: bool = False   # True only when both sides have sent

    def to_dict(self) -> dict:
        return {
            "conversation_key": self.conversation_key,
            "participants": self.participants,
            "scope": self.scope,
            "state": self.state,
            "exchange_count_window": self.exchange_count_window,
            "window_seconds": round(self.window_seconds, 1),
            "last_activity_at": self.last_activity_at,
            "headline": self.headline,
            "topic_hint": self.topic_hint,
            "bidirectional": self.bidirectional,
        }


@dataclass
class _Exchange:
    """Internal record of a single message in a conversation."""
    sender: str
    timestamp: float  # monotonic clock
    utc_iso: str


@dataclass
class _ConversationState:
    """Internal mutable state for a tracked conversation."""
    participants: List[str]
    scope: str
    exchanges: List[_Exchange] = field(default_factory=list)
    topic_hint: Optional[str] = None
    senders_seen: set = field(default_factory=set)

    @property
    def last_activity(self) -> float:
        return self.exchanges[-1].timestamp if self.exchanges else 0.0

    @property
    def last_activity_utc(self) -> str:
        return self.exchanges[-1].utc_iso if self.exchanges else ""

    @property
    def bidirectional(self) -> bool:
        return len(self.senders_seen) >= 2

    def prune_window(self, now: float, window_s: float = WINDOW_S) -> None:
        """Remove exchanges older than the window."""
        cutoff = now - window_s
        self.exchanges = [e for e in self.exchanges if e.timestamp >= cutoff]
        # Rebuild senders_seen from remaining exchanges
        self.senders_seen = {e.sender for e in self.exchanges}


# --- Tracker ---

class PulseTracker:
    """In-memory tracker that derives conversation pulses from message events.

    Thread-safe. Call record_exchange() when a message is sent or received,
    then query get_pulses() for the current operator-visible state.
    """

    def __init__(
        self,
        active_timeout: float = ACTIVE_TIMEOUT_S,
        recent_timeout: float = RECENT_TIMEOUT_S,
        window: float = WINDOW_S,
    ):
        self._lock = threading.Lock()
        self._conversations: Dict[str, _ConversationState] = {}
        self._active_timeout = active_timeout
        self._recent_timeout = recent_timeout
        self._window = window

    @staticmethod
    def _make_key(participant_a: str, participant_b: str, scope: str = "direct") -> str:
        """Canonical conversation key — sorted so A->B and B->A map to same key."""
        pair = sorted([participant_a, participant_b])
        return f"{scope}:{pair[0]}:{pair[1]}"

    def record_exchange(
        self,
        sender: str,
        recipient: str,
        *,
        scope: str = "direct",
        topic_hint: Optional[str] = None,
    ) -> None:
        """Record a message exchange between two agents.

        Call this on both send and receive events. The tracker deduplicates
        and maintains sliding window state.
        """
        key = self._make_key(sender, recipient, scope)
        now = time.monotonic()
        utc_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        exchange = _Exchange(sender=sender, timestamp=now, utc_iso=utc_iso)

        with self._lock:
            if key not in self._conversations:
                participants = sorted([sender, recipient])
                self._conversations[key] = _ConversationState(
                    participants=participants,
                    scope=scope,
                )
            conv = self._conversations[key]
            conv.exchanges.append(exchange)
            conv.senders_seen.add(sender)
            if topic_hint:
                conv.topic_hint = topic_hint
            conv.prune_window(now, self._window)

    def get_pulses(self, *, include_idle: bool = False) -> List[ConversationPulse]:
        """Return current conversation pulses, sorted by most recent first.

        By default only returns active and recent pulses. Set include_idle=True
        to also return idle conversations (useful for history views).
        """
        now = time.monotonic()
        pulses: List[ConversationPulse] = []
        expired_keys: List[str] = []

        with self._lock:
            for key, conv in self._conversations.items():
                conv.prune_window(now, self._window)
                elapsed = now - conv.last_activity if conv.exchanges else float("inf")

                if elapsed <= self._active_timeout:
                    state = "active"
                elif elapsed <= self._recent_timeout:
                    state = "recent"
                else:
                    state = "idle"
                    if not include_idle:
                        # Mark for cleanup if very old
                        if elapsed > self._recent_timeout * 3:
                            expired_keys.append(key)
                        continue

                exchange_count = len(conv.exchanges)
                window_seconds = min(
                    now - conv.exchanges[0].timestamp if conv.exchanges else 0.0,
                    self._window,
                )

                headline = self._build_headline(conv, state, exchange_count, window_seconds)

                pulses.append(ConversationPulse(
                    conversation_key=key,
                    participants=conv.participants,
                    scope=conv.scope,
                    state=state,
                    exchange_count_window=exchange_count,
                    window_seconds=window_seconds,
                    last_activity_at=conv.last_activity_utc,
                    headline=headline,
                    topic_hint=conv.topic_hint,
                    bidirectional=conv.bidirectional,
                ))

            # Clean up very old conversations
            for key in expired_keys:
                del self._conversations[key]

        # Sort by most recent activity first
        pulses.sort(key=lambda p: p.last_activity_at, reverse=True)
        return pulses

    @staticmethod
    def _build_headline(
        conv: _ConversationState,
        state: str,
        exchange_count: int,
        window_seconds: float,
    ) -> str:
        """Build the human-readable one-liner for a pulse."""
        a, b = conv.participants[0], conv.participants[1]
        arrow = "\u2194" if conv.bidirectional else "\u2192"  # ↔ or →

        if state == "active" and exchange_count > 1:
            secs = max(1, int(window_seconds))
            return f"{a} {arrow} {b} active \u00b7 {exchange_count} exchanges in {secs}s"
        elif state == "active":
            return f"{a} {arrow} {b} active"
        elif state == "recent":
            return f"{a} {arrow} {b} recent"
        else:
            return f"{a} {arrow} {b} idle"

    def clear(self) -> None:
        """Reset all tracked conversations."""
        with self._lock:
            self._conversations.clear()


# --- Module-level singleton ---

_tracker: Optional[PulseTracker] = None
_tracker_lock = threading.Lock()


def get_tracker() -> PulseTracker:
    """Get or create the global PulseTracker singleton."""
    global _tracker
    if _tracker is None:
        with _tracker_lock:
            if _tracker is None:
                _tracker = PulseTracker()
    return _tracker
