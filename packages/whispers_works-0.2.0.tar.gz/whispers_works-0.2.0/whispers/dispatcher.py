import json
import logging
import re
import sqlite3
import time
from collections import defaultdict
from copy import copy
from datetime import datetime, timezone
from typing import Callable, List
from .envelope import (
    Envelope,
    Priority,
    MsgType,
    AudienceScope,
    classify_attention_tier,
    classify_queue_class,
    requires_prompt_attention,
)
from .modes import Mode, ModeFilter
from .presence_policy import evaluate_reachability
from .scope_delivery import sanitize_envelope_for_workspace_recipient

logger = logging.getLogger(__name__)

# Velocity circuit breaker: reject agents sending more than this per second
VELOCITY_LIMIT = 5
VELOCITY_WINDOW = 1.0  # seconds

# EOT (End of Thread): max exchanges before forced thread termination
EOT_EXCHANGE_LIMIT = 20

# Signal protection classification for saturation resilience.
# Protected signals ALWAYS deliver. Degradable signals can be coalesced
# (multiple similar events merged into one). Deferrable signals can be
# dropped entirely under pressure.
SIGNAL_PROTECTION = {
    # Protected: always deliver, never coalesce or drop
    "protected": {
        "priorities": {Priority.FLASH, Priority.SYSTEM},
        "msg_types": {MsgType.HANDOFF},
        "schemas": {"external_action_request.v1", "decision_request.v1"},
    },
    # Degradable: deliver but coalesce duplicates under load
    "degradable": {
        "priorities": {Priority.PRIORITY},
        "msg_types": {MsgType.REQUEST, MsgType.REJECT},
    },
    # Deferrable: can be dropped under saturation pressure
    "deferrable": {
        "priorities": {Priority.ROUTINE},
        "msg_types": {MsgType.INFORM},
    },
}

# Per-recipient saturation thresholds (messages per minute)
SATURATION_THRESHOLD_DEGRADED = 60   # Start coalescing above this
SATURATION_THRESHOLD_CRITICAL = 120  # Start dropping deferrables above this


def classify_signal_protection(envelope: Envelope) -> str:
    """Classify an envelope's protection level: 'protected', 'degradable', or 'deferrable'."""
    # Check protected rules first
    protected = SIGNAL_PROTECTION["protected"]
    if envelope.priority in protected["priorities"]:
        return "protected"
    if envelope.msg_type in protected["msg_types"]:
        return "protected"
    payload = envelope.payload
    if isinstance(payload, dict):
        schema = payload.get("schema", "")
        if schema in protected["schemas"]:
            return "protected"

    # Check degradable
    degradable = SIGNAL_PROTECTION["degradable"]
    if envelope.priority in degradable["priorities"]:
        return "degradable"
    if envelope.msg_type in degradable["msg_types"]:
        return "degradable"

    return "deferrable"


class Dispatcher:
    """Central Routing Engine (Modes + Priority logic)."""

    SHADOW_EVENT_LIMIT = 100
    SHADOW_EVENT_WINDOW_SECONDS = 3600

    # Habituation: always-on duplicate coalescing (nervous system reflex)
    HABITUATION_WINDOW_SECONDS = 5 * 60  # 5 minutes — same sender+subject = duplicate

    # Courtesy ledger: bounded ring of recent courtesy actions for operator visibility.
    # Each entry: (timestamp, recipient, outcome, reason, sender, subject)
    COURTESY_LEDGER_MAX = 200
    COURTESY_LEDGER_WINDOW = 3600  # 1 hour

    def __init__(self, db):
        self.db = db
        self._transports: List[Callable[[Envelope], None]] = []
        self._health_scanner = None  # Set by server to enable bad-timing detection
        self._velocity_tracker: dict[str, list[float]] = defaultdict(list)
        self._shadow_rates: dict[str, list[float]] = defaultdict(list)
        self._recipient_rates: dict[str, list[float]] = defaultdict(list)
        self._coalesce_keys: dict[str, dict[str, float]] = defaultdict(dict)
        self._habituation_keys: dict[str, dict[str, float]] = defaultdict(dict)
        self._courtesy_ledger: list[dict] = []

    def _record_courtesy(self, envelope: Envelope, recipient: str, outcome: dict) -> None:
        """Append a courtesy action to the bounded ledger for operator visibility."""
        now = time.time()
        self._courtesy_ledger.append({
            "ts": now,
            "recipient": recipient,
            "outcome": outcome.get("outcome", "unknown"),
            "reason": outcome.get("reason", ""),
            "sender": envelope.sender,
            "subject": envelope.subject or "",
            "attention_tier": outcome.get("attention_tier"),
        })
        # Trim: drop entries older than window or exceeding max size
        cutoff = now - self.COURTESY_LEDGER_WINDOW
        self._courtesy_ledger = [
            e for e in self._courtesy_ledger if e["ts"] > cutoff
        ][-self.COURTESY_LEDGER_MAX:]

    def get_courtesy_summary(self) -> dict:
        """Return a summary of recent courtesy activity for operator surfaces.

        Returns counts by outcome type and the most recent entries.
        """
        now = time.time()
        cutoff = now - self.COURTESY_LEDGER_WINDOW
        recent = [e for e in self._courtesy_ledger if e["ts"] > cutoff]
        counts: dict[str, int] = defaultdict(int)
        for entry in recent:
            counts[entry["outcome"]] += 1
        # Also pull coalescing stats from dead_letters (last hour)
        coalesced_count = 0
        try:
            with self.db.get_connection() as conn:
                row = conn.execute(
                    "SELECT COUNT(*) AS cnt FROM dead_letters "
                    "WHERE reason LIKE '%coalesced%' "
                    "AND created_at > datetime('now', '-1 hour')"
                ).fetchone()
                coalesced_count = row["cnt"] if row else 0
        except Exception:
            pass
        return {
            "window_seconds": self.COURTESY_LEDGER_WINDOW,
            "total_actions": len(recent),
            "by_outcome": dict(counts),
            "coalesced_messages": coalesced_count,
            "recent": [
                {
                    "outcome": e["outcome"],
                    "reason": e["reason"],
                    "sender": e["sender"],
                    "recipient": e["recipient"],
                    "subject": e["subject"][:60],
                }
                for e in recent[-5:]  # last 5 for operator display
            ],
        }

    def add_transport_listener(self, callback: Callable):
        """Transports register here to be notified of immediate deliveries."""
        self._transports.append(callback)

    def _get_presence(self, agent_name: str) -> dict:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT reception_mode, mode_filter FROM presence WHERE agent_name = ?", (agent_name,))
            row = cursor.fetchone()
            return dict(row) if row else {"reception_mode": "open", "mode_filter": "{}"}

    def _courtesy_outcome(self, envelope: Envelope, recipient: str) -> dict | None:
        """Return a bounded courtesy outcome based on expectation + receiver state.

        Courtesy here affects alerting, not message truth. The message still stores
        and remains visible in the inbox unless a stronger mode/policy suppresses it.

        Uses the 2ACK expectation grammar (from _expectation metadata) when available,
        falling back to the legacy priority/msg_type heuristics.
        """
        # Check expectation-based courtesy first (structured protocol input)
        metadata = envelope.metadata if isinstance(envelope.metadata, dict) else {}
        attention_tier = metadata.get("_attention_tier")

        if attention_tier == "interrupt_now":
            return None  # never suppress interrupts

        try:
            runtime = self.db.get_runtime_state(recipient)
        except Exception:
            runtime = {}

        interruptibility = str(runtime.get("interruptibility") or "free").strip().lower()

        # Expectation-aware courtesy: use structured attention tier
        if attention_tier == "hold_visible":
            if interruptibility in ("do_not_interrupt", "urgent_only"):
                return {
                    "outcome": "hold_quietly",
                    "reason": f"expectation=hold_visible, interruptibility={interruptibility}",
                    "interruptibility": interruptibility,
                    "attention_tier": attention_tier,
                }
            return {
                "outcome": "defer_visible",
                "reason": f"expectation=hold_visible",
                "attention_tier": attention_tier,
            }

        if attention_tier == "surface_now":
            if interruptibility == "do_not_interrupt":
                return {
                    "outcome": "defer_visible",
                    "reason": f"expectation=surface_now, interruptibility=do_not_interrupt",
                    "interruptibility": interruptibility,
                    "attention_tier": attention_tier,
                }
            return None  # surface_now + free/urgent_only = let it through

        # Legacy fallback: no expectation metadata, use old heuristics
        if self._requires_prompt_attention(envelope):
            return None
        protection = classify_signal_protection(envelope)
        if protection != "deferrable" or envelope.priority != Priority.ROUTINE:
            return None
        if envelope.msg_type not in (MsgType.INFORM, MsgType.HEADS_UP):
            return None

        if interruptibility == "do_not_interrupt":
            return {
                "outcome": "hold_quietly",
                "reason": "recipient_interruptibility=do_not_interrupt",
                "interruptibility": interruptibility,
            }
        if interruptibility == "urgent_only":
            return {
                "outcome": "defer_visible",
                "reason": "recipient_interruptibility=urgent_only",
                "interruptibility": interruptibility,
            }
        return None

    @staticmethod
    def _envelope_schema(envelope: Envelope) -> str | None:
        payload = envelope.payload
        if isinstance(payload, dict):
            schema = payload.get("schema")
            if isinstance(schema, str) and schema.strip():
                return schema.strip()
        return None

    def _requires_prompt_attention(self, envelope: Envelope) -> bool:
        return requires_prompt_attention(
            envelope.msg_type.value,
            envelope.priority.value,
            envelope.sender,
            subject=envelope.subject,
            schema=self._envelope_schema(envelope),
            reply_to=envelope.reply_to,
        )

    def _attention_outcome(
        self,
        envelope: Envelope,
        recipient: str,
        *,
        alert: bool,
        courtesy: dict | None = None,
    ) -> dict:
        schema = self._envelope_schema(envelope)
        tier = classify_attention_tier(
            envelope.msg_type.value,
            envelope.priority.value,
            envelope.sender,
            subject=envelope.subject,
            schema=schema,
            reply_to=envelope.reply_to,
            alert_allowed=alert,
        )
        if courtesy is not None:
            reason = str(courtesy.get("reason") or courtesy.get("outcome") or "courtesy").strip()
        elif self._requires_prompt_attention(envelope):
            if envelope.reply_to:
                reason = "reply_or_thread_follow_up"
            elif envelope.priority != Priority.ROUTINE:
                reason = f"priority={envelope.priority.value}"
            else:
                queue_class = classify_queue_class(
                    envelope.msg_type.value,
                    envelope.priority.value,
                    envelope.sender,
                    schema=schema,
                )
                reason = f"queue_class={queue_class}"
        else:
            reason = "routine_visible"
        return {
            "tier": tier,
            "reason": reason,
            "recipient": recipient,
        }

    def _dead_letter(self, envelope: Envelope, reason: str):
        """Drops a message into dead_letters and prevents forward routing."""
        import json
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO dead_letters (uuid, original_envelope, reason) VALUES (?, ?, ?)",
                (envelope.id, json.dumps(envelope.__dict__, default=str), reason)
            )
            conn.commit()

    def _get_trust_tiers(self, sender: str, recipient: str, *, conn=None) -> tuple[int, int]:
        owns_conn = conn is None
        conn = conn or self.db.get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT callsign, trust_tier FROM agent_cards WHERE callsign IN (?, ?)", (sender, recipient))
            rows = {row["callsign"]: row["trust_tier"] for row in cursor.fetchall()}
            
            # Unknown agents fall back to Tier 1, matching the rest of the
            # runtime's fail-safe defaults for unverified agents.
            return rows.get(sender, 1), rows.get(recipient, 1)
        finally:
            if owns_conn:
                conn.close()

    def _reply_targets_agent(self, conn, envelope: Envelope, recipient: str) -> bool:
        if not envelope.reply_to:
            return False

        row = conn.execute(
            "SELECT from_agent, to_agent FROM messages WHERE uuid = ?",
            (envelope.reply_to,),
        ).fetchone()
        if row and recipient in {row["from_agent"], row["to_agent"]}:
            return True

        recipient_row = conn.execute(
            """
            SELECT 1
            FROM message_recipients
            WHERE message_uuid = ? AND recipient_callsign = ?
            LIMIT 1
            """,
            (envelope.reply_to, recipient),
        ).fetchone()
        return bool(recipient_row)

    def _message_mentions_agent(self, envelope: Envelope, recipient: str) -> bool:
        pattern = re.compile(rf"(^|[^\w-])@{re.escape(recipient)}(?=$|[^\w-])")
        for candidate in (envelope.subject, envelope.body):
            if isinstance(candidate, str) and pattern.search(candidate):
                return True
        return False

    def _is_direct_for_recipient(self, conn, envelope: Envelope, recipient: str) -> bool:
        if envelope.audience_scope == AudienceScope.DIRECT:
            return True
        if self._reply_targets_agent(conn, envelope, recipient):
            return True
        if self._message_mentions_agent(envelope, recipient):
            return True
        return False

    def _evaluate_delivery_recipients(self, envelope: Envelope) -> tuple[list[str], list[dict]]:
        twoack_payload = self._extract_twoack_envelope(envelope)
        twoack_now = datetime.now(timezone.utc).isoformat() if twoack_payload is not None else None
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            recipients = self.db._resolve_queue_recipients(cursor, envelope.recipient)
            allowed: list[str] = []
            blocked: list[dict] = []

            for actual_recipient in recipients:
                sender_tier, recipient_tier = self._get_trust_tiers(
                    envelope.sender,
                    actual_recipient,
                    conn=conn,
                )
                if twoack_payload is not None:
                    from .twoack import ERR_TRUST_INSUFFICIENT, PreflightPolicy, evaluate_preflight

                    trust_check = evaluate_preflight(
                        twoack_payload,
                        now=twoack_now,
                        policy=PreflightPolicy(receiver_trust_tier=recipient_tier),
                    )
                    if trust_check.rejected and trust_check.code == ERR_TRUST_INSUFFICIENT:
                        blocked.append(
                            {
                                "recipient": actual_recipient,
                                "reason": "2ack_trust_insufficient",
                                "preflight_code": trust_check.code,
                                "schema": trust_check.surface.schema,
                                "tier_required": trust_check.surface.tier_required,
                                "receiver_tier": recipient_tier,
                                "detail": trust_check.reason,
                            }
                        )
                        continue

                if sender_tier < recipient_tier - 1:
                    blocked.append(
                        {
                            "recipient": actual_recipient,
                            "reason": "trust_tier_violation",
                            "sender_tier": sender_tier,
                            "recipient_tier": recipient_tier,
                        }
                    )
                    continue

                policy = self.db.get_presence_policy(actual_recipient, conn=conn)
                decision = evaluate_reachability(
                    policy,
                    priority=envelope.priority,
                    is_direct=self._reply_targets_agent(conn, envelope, actual_recipient) or self._message_mentions_agent(envelope, actual_recipient),
                    sender_tier=sender_tier,
                    recipient_tier=recipient_tier,
                    sender_agent=envelope.sender,
                    target_agent=actual_recipient,
                )
                if decision.allowed:
                    allowed.append(actual_recipient)
                    continue

                blocked.append(
                    {
                        "recipient": actual_recipient,
                        "reason": "reachability_policy_blocked",
                        "reachability": decision.policy,
                        "detail": decision.reason,
                        "sender_tier": sender_tier,
                        "recipient_tier": recipient_tier,
                    }
                )

            return allowed, blocked

    def _extract_twoack_envelope(self, envelope: Envelope) -> dict | None:
        payload = envelope.payload
        if not isinstance(payload, dict):
            return None

        schema = payload.get("schema")
        if not isinstance(schema, str) or not schema:
            return None

        metadata = envelope.metadata if isinstance(envelope.metadata, dict) else {}
        has_envelope_markers = any(
            key in payload
            for key in (
                "wire_v",
                "trace",
                "payload",
                "mode",
                "signal_class",
                "summary",
                "accept_schemas",
                "authority",
                "authority_proof",
            )
        )
        has_metadata_mirrors = any(
            metadata.get(key) is not None
            for key in ("whispers:schema", "whispers:wireMode", "whispers:signalClass")
        )
        if has_envelope_markers or has_metadata_mirrors:
            return payload
        return None

    def _check_twoack_predispatch(self, envelope: Envelope) -> str | None:
        twoack_payload = self._extract_twoack_envelope(envelope)
        if twoack_payload is None:
            return None

        from .twoack import evaluate_preflight, validate_authority_claim, validate_message

        now = datetime.now(timezone.utc).isoformat()
        preflight = evaluate_preflight(twoack_payload, now=now)
        if preflight.rejected or preflight.deferred:
            status_phrase = "deferred" if preflight.deferred else "rejected"
            self.db.record_security_event(
                f"2ack_preflight_{status_phrase}",
                status_phrase,
                actor_agent=envelope.sender,
                target_agent=envelope.recipient,
                endpoint="dispatch:2ack_preflight",
                detail={
                    "preflight_code": preflight.code,
                    "schema": preflight.surface.schema,
                    "message_id": preflight.surface.message_id,
                    "reason": preflight.reason,
                },
            )
            reject_reason = f"2ack_preflight_{status_phrase}:{preflight.code or 'unknown'}"
            self._dead_letter(envelope, reason=reject_reason)
            return reject_reason

        schema_id = twoack_payload.get("schema")
        payload_data = twoack_payload.get("payload", {})
        risk_level = payload_data.get("risk_level") if isinstance(payload_data, dict) else None
        authority = twoack_payload.get("authority")
        principal = authority.get("principal") if isinstance(authority, dict) else None
        if (
            schema_id == "external_action_request.v1"
            and risk_level in ("elevated", "critical")
            and not isinstance(principal, str)
        ):
            proof_err = (
                f"Schema '{schema_id}' with risk_level '{risk_level}' requires "
                f"an authority claim. Add authority.principal and authority_proof."
            )
            self.db.record_security_event(
                "2ack_authority_required",
                "rejected",
                actor_agent=envelope.sender,
                target_agent=envelope.recipient,
                endpoint="dispatch:2ack_authority",
                detail={
                    "schema": schema_id,
                    "risk_level": risk_level,
                    "reason": proof_err,
                },
            )
            reject_reason = "2ack_authority_required"
            self._dead_letter(envelope, reason=reject_reason)
            return reject_reason

        validation = validate_message(twoack_payload)
        if not validation.valid:
            self.db.record_security_event(
                "2ack_validation_failed",
                "rejected",
                actor_agent=envelope.sender,
                target_agent=envelope.recipient,
                endpoint="dispatch:2ack_validation",
                detail={
                    "schema": twoack_payload.get("schema"),
                    "errors": [
                        {"code": error.code, "path": error.path, "message": error.message}
                        for error in validation.errors
                    ],
                },
            )
            reject_reason = "2ack_invalid_envelope"
            self._dead_letter(envelope, reason=reject_reason)
            return reject_reason

        auth_err = validate_authority_claim(twoack_payload)
        if auth_err:
            self.db.record_security_event(
                "2ack_authority_failed",
                "rejected",
                actor_agent=envelope.sender,
                target_agent=envelope.recipient,
                endpoint="dispatch:2ack_authority",
                detail={
                    "reason": auth_err,
                    "schema": twoack_payload.get("schema"),
                    "message_id": (twoack_payload.get("trace") or {}).get("message_id"),
                    "principal": (twoack_payload.get("authority") or {}).get("principal"),
                },
            )
            reject_reason = "2ack_authority_failed"
            self._dead_letter(envelope, reason=reject_reason)
            return reject_reason

        return None

    def _record_delivery_blocks(self, envelope: Envelope, blocked: list[dict], *, all_blocked: bool) -> None:
        for item in blocked:
            detail = dict(item)
            detail["all_recipients_blocked"] = all_blocked
            self.db.record_security_event(
                item["reason"],
                "rejected" if all_blocked else "filtered",
                actor_agent=envelope.sender,
                target_agent=item["recipient"],
                endpoint="dispatch",
                detail=detail,
            )

    def dispatch(self, envelope: Envelope) -> str | None:
        """Evaluates payload, trust tiers, tripwires, then stores and routes.
        Returns None on success, or a dead-letter reason string if rejected."""
        MAX_BODY_BYTES = 32_000
        MAX_PAYLOAD_BYTES = 256_000
        if envelope.body:
            body_str = envelope.body if isinstance(envelope.body, str) else json.dumps(envelope.body, default=str)
            if len(body_str.encode('utf-8')) > MAX_BODY_BYTES:
                reason = "payload_too_large: Exceeds body bytes limit. Store large payloads in CAS using the store_blob MCP tool and pass the urn:whispers:blob reference instead."
                self._dead_letter(envelope, reason=reason)
                return reason

        if envelope.payload:
            payload_str = envelope.payload if isinstance(envelope.payload, str) else json.dumps(envelope.payload, default=str)
            if len(payload_str.encode('utf-8')) > MAX_PAYLOAD_BYTES:
                reason = "payload_too_large: Exceeds payload bytes limit. Store large payloads in CAS using the store_blob MCP tool and pass the urn:whispers:blob reference instead."
                self._dead_letter(envelope, reason=reason)
                return reason

        # Guardian pre-dispatch firewall — scan BEFORE any routing work
        from .alignment.guardian import scan_content, enforce_policy
        envelope = scan_content(envelope)
        guardian_reject = enforce_policy(self.db, envelope)
        if guardian_reject:
            self._dead_letter(envelope, reason=guardian_reject)
            return guardian_reject

        # Velocity circuit breaker: reject agents sending too fast
        if envelope.sender and envelope.priority not in (Priority.FLASH, Priority.SYSTEM):
            now = time.monotonic()
            window = self._velocity_tracker[envelope.sender]
            # Prune old entries
            cutoff = now - VELOCITY_WINDOW
            self._velocity_tracker[envelope.sender] = [t for t in window if t > cutoff]
            window = self._velocity_tracker[envelope.sender]
            if len(window) >= VELOCITY_LIMIT:
                reason = f"velocity_limit: {envelope.sender} exceeded {VELOCITY_LIMIT} messages/sec"
                self.db.record_security_event(
                    "velocity_circuit_breaker",
                    "rate_limited",
                    actor_agent=envelope.sender,
                    target_agent=envelope.recipient,
                    endpoint="dispatch:velocity_breaker",
                    detail=f"rate={len(window)}/{VELOCITY_WINDOW}s, limit={VELOCITY_LIMIT}",
                )
                self._dead_letter(envelope, reason=reason)
                return reason
            window.append(now)

        # Replay protection: reject duplicate idempotency keys
        if envelope.idempotency_key:
            existing = self.db.get_message_by_idempotency(envelope.sender, envelope.idempotency_key)
            if existing:
                reason = f"replay_rejected: duplicate idempotency_key={envelope.idempotency_key}, original={existing['uuid']}"
                self.db.record_security_event(
                    "replay_rejected",
                    "duplicate_idempotency_key",
                    actor_agent=envelope.sender,
                    target_agent=envelope.recipient,
                    endpoint="dispatch:replay_protection",
                    detail=f"key={envelope.idempotency_key}, original_uuid={existing['uuid']}",
                )
                self._dead_letter(envelope, reason=reason)
                return reason

        # Self-handoff prevention: handoff_baton.v1 from sender to self is invalid
        if envelope.sender == envelope.recipient:
            payload = envelope.payload if isinstance(envelope.payload, dict) else {}
            schema = payload.get("schema") or ""
            if schema == "handoff_baton.v1":
                reason = "self_handoff_rejected: Cannot hand off baton to yourself."
                self._dead_letter(envelope, reason=reason)
                return reason

        if envelope.ephemeral:
            metadata = envelope.metadata or {}
            sig_class = metadata.get("whispers:signalClass")
            payload = envelope.payload or {}
            schema = payload.get("schema") if isinstance(payload, dict) else None

            if sig_class == "external" or schema in (
                "external_action_request.v1",
                "workspace_delta.v1",
                "workspace_state.v1",
                "handoff_baton.v1"
            ):
                reject_reason = "ephemeral_authority_not_allowed"
                self._dead_letter(envelope, reason=reject_reason)
                return reject_reason

        twoack_reject = self._check_twoack_predispatch(envelope)
        if twoack_reject:
            return twoack_reject

        handoff_boundary_violation = self.db.get_workspace_handoff_boundary_violation(envelope)
        if handoff_boundary_violation:
            reject_reason = "workspace_handoff_blocked_non_member"
            self.db.record_security_event(
                "scope_boundary",
                reject_reason,
                actor_agent=envelope.sender,
                target_agent=envelope.recipient,
                endpoint="dispatch:workspace_handoff_scope_boundary",
                detail=handoff_boundary_violation,
            )
            self._dead_letter(envelope, reason=reject_reason)
            return reject_reason

        operator_override = self.db.inspect_operator_override(envelope)
        if operator_override and operator_override.get("invalid"):
            reject_reason = "operator_override_invalid"
            self.db.record_security_event(
                "operator_override",
                "rejected_invalid",
                actor_agent=envelope.sender,
                target_agent=envelope.recipient,
                endpoint="dispatch:operator_override",
                detail=operator_override["detail"],
            )
            self._dead_letter(envelope, reason=reject_reason)
            return reject_reason

        baton_scope_violation = self.db.inspect_baton_scope_transition(envelope)
        if baton_scope_violation and baton_scope_violation.get("invalid"):
            reject_reason = "scope_widening:baton_scope_change"
            self.db.record_security_event(
                "scope_widening_rejected",
                "hard_reject",
                actor_agent=envelope.sender,
                target_agent=envelope.recipient,
                endpoint="dispatch:baton_scope_guard",
                detail=baton_scope_violation["detail"],
            )
            self._dead_letter(envelope, reason=reject_reason)
            return reject_reason

        # EOT: prevent runaway thread loops
        if envelope.context_id and envelope.priority not in (Priority.FLASH, Priority.SYSTEM):
            try:
                with self.db.get_connection() as conn:
                    row = conn.execute(
                        "SELECT COUNT(*) as cnt FROM messages WHERE context_id = ?",
                        (envelope.context_id,),
                    ).fetchone()
                    if row and row["cnt"] >= EOT_EXCHANGE_LIMIT:
                        reason = f"eot_thread_limit: thread {envelope.context_id} exceeded {EOT_EXCHANGE_LIMIT} exchanges"
                        self.db.record_security_event(
                            "eot_thread_limit",
                            "thread_terminated",
                            actor_agent=envelope.sender,
                            target_agent=envelope.recipient,
                            endpoint="dispatch:eot_guard",
                            detail=f"context_id={envelope.context_id}, exchanges={row['cnt']}, limit={EOT_EXCHANGE_LIMIT}",
                        )
                        self._dead_letter(envelope, reason=reason)
                        return reason
            except Exception:
                pass  # EOT check is best-effort

        # Autonomy enforcement: check action class against agent policy
        try:
            from .autonomy_enforcement import classify_action, check_autonomy
            action_class = classify_action(
                envelope.msg_type.value if hasattr(envelope.msg_type, 'value') else str(envelope.msg_type),
                envelope.payload,
            )
            if action_class:
                metadata = envelope.metadata if isinstance(envelope.metadata, dict) else {}
                working_scope = metadata.get("whispers:working_scope")
                autonomy_result = check_autonomy(self.db, envelope.sender, action_class, working_scope)
                if not autonomy_result["allowed"]:
                    self.db.record_security_event(
                        "autonomy_policy_denied",
                        "hard_reject",
                        actor_agent=envelope.sender,
                        target_agent=envelope.recipient,
                        endpoint="dispatch:autonomy_enforcement",
                        detail=f"action={action_class}, scope={working_scope}, reason={autonomy_result['reason']}",
                    )
                    self._dead_letter(envelope, reason=autonomy_result["reason"])
                    return autonomy_result["reason"]
                if autonomy_result.get("shadow"):
                    self.db.record_security_event(
                        "autonomy_shadow",
                        "allowed_shadow",
                        actor_agent=envelope.sender,
                        target_agent=envelope.recipient,
                        endpoint="dispatch:autonomy_enforcement",
                        detail=f"action={action_class}, scope={working_scope}, shadow_mode=true",
                    )
        except ImportError:
            pass  # Module not available yet

        # 2ack P1: accept_schemas enforcement on replies
        # When a reply targets a message that declared accept_schemas,
        # verify the reply's schema is in the allowed set.
        if envelope.reply_to and isinstance(envelope.payload, dict) and envelope.payload.get("schema"):
            try:
                with self.db.get_connection() as conn:
                    original = conn.execute(
                        "SELECT payload FROM messages WHERE uuid = ?",
                        (envelope.reply_to,),
                    ).fetchone()
                    if original and original["payload"]:
                        original_payload = json.loads(original["payload"]) if isinstance(original["payload"], str) else original["payload"]
                        from .twoack import check_reply_schema_constraint
                        violation = check_reply_schema_constraint(original_payload, envelope.payload)
                        if violation:
                            self._dead_letter(envelope, reason=f"accept_schemas_violation:{violation}")
                            self.db.record_security_event(
                                "accept_schemas_violation",
                                "rejected",
                                actor_agent=envelope.sender,
                                endpoint="dispatch",
                                detail={"reply_to": envelope.reply_to, "violation": violation},
                            )
                            return f"accept_schemas_violation"
            except (sqlite3.Error, json.JSONDecodeError, TypeError, ValueError) as exc:
                logger.warning(
                    "Failed to enforce accept_schemas for reply %s -> %s: %s",
                    envelope.reply_to,
                    envelope.id,
                    exc,
                )

        # Scope-based Autonomy Enforcement
        metadata = envelope.metadata or {}
        working_scope = metadata.get("whispers:working_scope")

        # Scope widening guard: if an agent has ANY scoped policy, they MUST
        # declare a working_scope on every message. Dropping the scope tag
        # to bypass enforcement is itself a scope violation.
        if not working_scope and self.db.has_any_autonomy_policy(envelope.sender):
            reject_reason = "scope_widening:missing_scope"
            self.db.record_security_event(
                "scope_widening_rejected",
                "hard_reject",
                actor_agent=envelope.sender,
                endpoint="dispatch",
                detail={
                    "reason": "Agent has scoped autonomy policies but sent message without working_scope",
                    "message_id": str(envelope.id),
                },
            )
            self._dead_letter(envelope, reason=reject_reason)
            return reject_reason

        if working_scope:
            policy = self.db.get_autonomy_policy(envelope.sender, working_scope)

            if not policy:
                reject_reason = f"unauthorized_scope:{working_scope}"
                self._dead_letter(envelope, reason=reject_reason)
                return reject_reason

            shadow_mode = policy.get("shadow_mode", False)

            sig_class = metadata.get("whispers:signalClass")
            payload = envelope.payload or {}
            schema = payload.get("schema") if isinstance(payload, dict) else ""
            
            is_reply = bool(envelope.reply_to)
            is_external = sig_class == "external" or (isinstance(schema, str) and schema.startswith("external_"))
            is_summary = isinstance(schema, str) and "summary" in schema
            is_classify = isinstance(schema, str) and ("classify" in schema or "classification" in schema)

            def _handle_autonomy_block(reason: str, detail: dict) -> str | None:
                if shadow_mode:
                    import time
                    now = time.time()
                    sender = envelope.sender
                    
                    if sender not in self._shadow_rates:
                        self._shadow_rates[sender] = []
                        
                    window_start = now - Dispatcher.SHADOW_EVENT_WINDOW_SECONDS
                    self._shadow_rates[sender] = [t for t in self._shadow_rates[sender] if t > window_start]
                    
                    if len(self._shadow_rates[sender]) < Dispatcher.SHADOW_EVENT_LIMIT:
                        self.db.record_security_event(
                            f"{reason}:shadow",
                            "shadow_filter",
                            actor_agent=sender,
                            endpoint="dispatch",
                            detail=detail,
                        )
                        self._shadow_rates[sender].append(now)
                    else:
                        logger.warning("Shadow event rate limit exceeded for %s", sender)
                    return None
                self._dead_letter(envelope, reason=reason)
                return reason

            if is_reply and not policy.get("can_reply"):
                reject_reason = _handle_autonomy_block("autonomy_policy_blocked:reply", {
                    "reply_to": envelope.reply_to, "action_class": "reply",
                    "policy_scope": working_scope, "would_block_reason": "can_reply is false",
                })
                if reject_reason: return reject_reason

            if is_external and not policy.get("can_external_action"):
                reject_reason = _handle_autonomy_block("autonomy_policy_blocked:external_action", {
                    "schema": schema, "action_class": "external_action",
                    "policy_scope": working_scope, "would_block_reason": "can_external_action is false",
                })
                if reject_reason: return reject_reason

            if is_summary and not policy.get("can_summarize"):
                reject_reason = _handle_autonomy_block("autonomy_policy_blocked:summarize", {
                    "schema": schema, "action_class": "summarize",
                    "policy_scope": working_scope, "would_block_reason": "can_summarize is false",
                })
                if reject_reason: return reject_reason

            if is_classify and not policy.get("can_classify"):
                reject_reason = _handle_autonomy_block("autonomy_policy_blocked:classify", {
                    "schema": schema, "action_class": "classify",
                    "policy_scope": working_scope, "would_block_reason": "can_classify is false",
                })
                if reject_reason: return reject_reason

        # Habituation reflex: coalesce exact-duplicate routine signals (always-on)
        import time as _time
        protection = classify_signal_protection(envelope)
        recipient = envelope.recipient or ""
        if recipient and protection == "deferrable" and envelope.priority == Priority.ROUTINE:
            now_h = _time.time()
            hab_key = f"{envelope.sender}:{envelope.subject}"
            agent_hab = self._habituation_keys.setdefault(recipient, {})
            last_hab = agent_hab.get(hab_key, 0)
            if now_h - last_hab < self.HABITUATION_WINDOW_SECONDS:
                self._dead_letter(envelope, reason="habituation:coalesced")
                self._record_courtesy(envelope, recipient, {
                    "outcome": "habituation_coalesced",
                    "reason": "exact duplicate within habituation window",
                })
                return "habituation:coalesced"
            agent_hab[hab_key] = now_h

        # Saturation resilience: classify signal protection and apply pressure rules
        if recipient and protection != "protected":
            now = _time.time()
            if recipient not in self._recipient_rates:
                self._recipient_rates[recipient] = []
            window_start = now - 60
            self._recipient_rates[recipient] = [
                t for t in self._recipient_rates[recipient] if t > window_start
            ]
            rate = len(self._recipient_rates[recipient])

            if rate >= SATURATION_THRESHOLD_CRITICAL and protection == "deferrable":
                self.db.record_security_event(
                    "signal_deferred_saturation",
                    "dropped",
                    actor_agent=envelope.sender,
                    target_agent=recipient,
                    endpoint="dispatch:saturation_guard",
                    detail={
                        "protection": protection,
                        "rate": rate,
                        "threshold": SATURATION_THRESHOLD_CRITICAL,
                        "subject": envelope.subject,
                    },
                )
                self._dead_letter(envelope, reason="saturation:deferrable_dropped")
                self._record_courtesy(envelope, recipient, {
                    "outcome": "saturation_dropped",
                    "reason": f"deferrable dropped at rate={rate}",
                })
                return "saturation:deferrable_dropped"

            if rate >= SATURATION_THRESHOLD_DEGRADED and protection == "degradable":
                # Coalesce: if same sender+subject sent recently, skip
                coalesce_key = f"{envelope.sender}:{envelope.subject}"
                agent_keys = self._coalesce_keys.setdefault(recipient, {})
                last_seen = agent_keys.get(coalesce_key, 0)
                if now - last_seen < 30:  # Coalesce window: 30 seconds
                    self._dead_letter(envelope, reason="saturation:coalesced")
                    self._record_courtesy(envelope, recipient, {
                        "outcome": "saturation_coalesced",
                        "reason": "degradable duplicate under saturation",
                    })
                    return "saturation:coalesced"
                agent_keys[coalesce_key] = now

            self._recipient_rates[recipient].append(now)

        allowed_recipients, blocked_recipients = self._evaluate_delivery_recipients(envelope)
        if blocked_recipients:
            self._record_delivery_blocks(
                envelope,
                blocked_recipients,
                all_blocked=not allowed_recipients,
            )
        if not allowed_recipients:
            reject_reason = blocked_recipients[0]["reason"] if blocked_recipients else "no_reachable_recipients"
            self._dead_letter(envelope, reason=reject_reason)
            return reject_reason

        # Guardian already ran at pre-dispatch (top of dispatch method)

        # 2ACK: Compute and attach expectation if not explicitly provided.
        # This gives the attention/courtesy system structured input.
        try:
            from .twoack import Expectation
            payload = envelope.payload if isinstance(envelope.payload, dict) else {}
            explicit_exp = payload.get("expectation") if isinstance(payload, dict) else None
            if explicit_exp and isinstance(explicit_exp, dict):
                exp = Expectation.from_dict(explicit_exp)
            else:
                schema = payload.get("schema", "") if isinstance(payload, dict) else ""
                priority = envelope.priority.value if hasattr(envelope.priority, "value") else str(envelope.priority)
                exp = Expectation.for_schema(str(schema), priority)
            envelope.metadata = envelope.metadata or {}
            envelope.metadata["_expectation"] = exp.to_dict()
            tier = exp.to_attention_tier()
            # Replies always interrupt — they're action-worthy responses to
            # something the receiver sent. Never courtesy-suppress a reply.
            if envelope.reply_to:
                tier = "interrupt_now"
            # Consequence-scope boost: physical-irreversible signals always
            # interrupt. Physical-reversible signals surface immediately.
            # This gives proportional governance without payload inspection.
            consequence = (
                envelope.consequence_scope
                or (envelope.metadata or {}).get("whispers:consequence_scope")
            )
            if consequence == "physical_irreversible":
                tier = "interrupt_now"
            elif consequence == "physical_reversible" and tier == "hold_visible":
                tier = "surface_now"
            if consequence:
                envelope.metadata["_consequence_scope"] = consequence
            envelope.metadata["_attention_tier"] = tier
        except Exception:
            pass  # expectation is advisory, not blocking

        if not envelope.ephemeral:
            self.db.store_message(envelope, allowed_recipients=allowed_recipients)

        # AB9/AB10: Detect dissent and review verdict schemas for workspace projection + operator events
        self._project_review_dissent_events(envelope)

        # Evaluate signal modes and SSE delivery PER ACTUAL RECIPIENT
        for actual_recipient in allowed_recipients:
            # Alerting is recipient-specific, so delivery fanout must not mutate the
            # shared envelope and let one recipient's policy leak into another's.
            delivery_envelope = copy(envelope)
            alert = self._should_alert(envelope, actual_recipient)
            delivery_envelope._alert = alert
            delivery_envelope, redaction = sanitize_envelope_for_workspace_recipient(
                self.db,
                delivery_envelope,
                actual_recipient,
            )
            courtesy = self._courtesy_outcome(envelope, actual_recipient) if not alert else None
            delivery_envelope._alert = alert
            if courtesy is not None:
                delivery_envelope._courtesy = courtesy
                self._record_courtesy(envelope, actual_recipient, courtesy)
            delivery_envelope._attention = self._attention_outcome(
                envelope,
                actual_recipient,
                alert=bool(alert),
                courtesy=courtesy,
            )
            if redaction is not None:
                self.db.record_security_event(
                    "scope_boundary",
                    "workspace_context_delivery_redacted_non_member",
                    actor_agent=envelope.sender,
                    target_agent=actual_recipient,
                    endpoint="dispatch:workspace_context_delivery_guard",
                    detail=redaction.as_detail(
                        message_id=envelope.id,
                        explicit_transfer=redaction.redaction_mode == "payload_preserved",
                    ),
                )

            # 1. System Priority ALWAYS delivers immediately
            if envelope.priority == Priority.SYSTEM:
                self._push_to_transports(delivery_envelope, target_agent=actual_recipient)
                continue

            presence = self._get_presence(actual_recipient)
            mode = Mode(presence["reception_mode"])
            mf = ModeFilter.from_json(presence["mode_filter"])

            # 2. Recipient is OPEN
            if mode == Mode.OPEN:
                self._push_to_transports(delivery_envelope, target_agent=actual_recipient)
                continue

            # 3. Recipient is FOCUSED
            if mode == Mode.FOCUSED:
                if mf.permits(envelope):
                    self._push_to_transports(delivery_envelope, target_agent=actual_recipient)
                else:
                    pass # Queue silently
                continue

            # 4. Recipient is QUIET
            if mode == Mode.QUIET:
                if envelope.priority == Priority.FLASH:
                    # Queue silently, but push a lightweight Heads-up Ping
                    ping = Envelope(
                        sender="system",
                        recipient=actual_recipient,
                        subject=f"FLASH priority queued from {envelope.sender}",
                        msg_type=MsgType.HEADS_UP,
                        priority=Priority.SYSTEM,
                        metadata={"whispers:original_envelope": envelope.id}
                    )
                    self._push_to_transports(ping, target_agent=actual_recipient)
                else:
                    pass # Queue silently for Routine/Priority

            # AB-HS4: Bad-timing interruption detection (inline, post-delivery)
            if self._health_scanner:
                self._check_bad_timing(envelope, actual_recipient)

    def _should_alert(self, envelope: Envelope, recipient: str) -> bool:
        """Evaluate notification_policy to decide if this delivery should alert the recipient.

        Action-prompting traffic always alerts. Courtesy suppression is limited
        to deferrable routine traffic, not replies, handoffs, requests, or
        priority work.
        """
        # Operator messages always alert
        if envelope.sender == "operator":
            return True
        if self._requires_prompt_attention(envelope):
            return True

        try:
            policy = self.db.get_presence_policy(recipient)
        except Exception:
            return True  # fail-open: alert if policy lookup fails

        raw_notification_policy = policy.get("notification_policy")
        notification_policy = str(raw_notification_policy or "all")
        explicit_all_policy = (
            str(raw_notification_policy or "").strip().lower() == "all"
            and policy.get("updated_at") is not None
        )

        if notification_policy == "all":
            base_alert = True
        elif notification_policy == "none":
            base_alert = False
        elif notification_policy == "direct_only":
            with self.db.get_connection() as conn:
                base_alert = self._is_direct_for_recipient(conn, envelope, recipient)
        elif notification_policy == "trusted_or_priority":
            if envelope.priority in (Priority.PRIORITY, Priority.FLASH):
                base_alert = True
            else:
                sender_tier, recipient_tier = self._get_trust_tiers(envelope.sender, recipient)
                base_alert = sender_tier >= max(1, recipient_tier)
        elif notification_policy == "mentions_only":
            base_alert = self._message_mentions_agent(envelope, recipient)
        else:
            base_alert = True  # unknown policy: fail-open

        if not base_alert:
            return False

        if explicit_all_policy:
            return True

        courtesy = self._courtesy_outcome(envelope, recipient)
        if courtesy is not None:
            return False

        return True

    def _check_bad_timing(self, envelope: Envelope, recipient: str):
        """Check if a delivered message was a bad-timing interruption."""
        try:
            runtime = self.db.get_runtime_state(recipient)
            from .collaboration_health import check_bad_timing
            signal = check_bad_timing(envelope, runtime)
            if signal and self._health_scanner:
                self._health_scanner.record_bad_timing(signal)
        except Exception:
            logger.debug("Bad-timing check failed for %s", recipient, exc_info=True)

    def _project_review_dissent_events(self, envelope: Envelope):
        """Project dissent_record, dissent_resolution, and review_verdict schemas into workspace streams and operator SSE."""
        payload = envelope.payload
        if not isinstance(payload, dict):
            return
        schema = payload.get("schema") or payload.get("whispers:schema")
        if not schema:
            return

        _PROJECTABLE = {
            "dissent_record.v1",
            "dissent_resolution.v1",
            "review_verdict.v1",
        }
        if schema not in _PROJECTABLE:
            return

        # 1. Dispatch Operator Escalations for Blocking Dissents
        try:
            from whispers.envelope import Priority, Envelope as CoreEnvelope

            if schema == "dissent_record.v1" and payload.get("blocking"):
                alert_env = CoreEnvelope(
                    sender=envelope.sender,
                    recipient="captain",
                    msg_type="propose",
                    priority=Priority.PRIORITY,
                    subject=f"correction: blocking dissent filed on {payload.get('decision_ref', 'unknown')}",
                    body=payload.get("alternate_path", "N/A"),
                    metadata={
                        "whispers:generated_by": "dispatcher", 
                        "whispers:dissent_ref": envelope.id,
                        "whispers:coordination_kind": "correction"
                    }
                )
                self.db.store_message(alert_env, allowed_recipients=["captain"])
            elif schema == "dissent_resolution.v1":
                dissent_ref = payload.get("dissent_ref")
                if dissent_ref:
                    with self.db.get_connection() as conn:
                        conn.execute(
                            "UPDATE messages SET status = 'done' "
                            "WHERE to_agent = 'captain' "
                            "  AND json_extract(metadata, '$.\"whispers:dissent_ref\"') = ?",
                            (dissent_ref,)
                        )
        except Exception as e:
            logger.warning("Failed to process dissent escalation for %s: %s", envelope.id, e)

        workspace_id = payload.get("workspace_id")
        if not workspace_id:
            return

        try:
            from whispers.workspaces import WorkspaceManager
            wm = WorkspaceManager(self.db)

            if schema == "dissent_record.v1":
                wm.post_delta(
                    workspace_id,
                    delta_kind="dissent_recorded",
                    actor=envelope.sender,
                    text=f"Dissent recorded by {envelope.sender}: {payload.get('alternate_path', 'N/A')[:120]}",
                    refs=[payload.get("decision_ref")] if payload.get("decision_ref") else None,
                    state_patch={"dissent": {"schema": schema, "blocking": payload.get("blocking", False)}},
                )
            elif schema == "dissent_resolution.v1":
                wm.post_delta(
                    workspace_id,
                    delta_kind="dissent_resolved",
                    actor=envelope.sender,
                    text=f"Dissent resolved as {payload.get('resolution', 'unknown')} by {envelope.sender}",
                    refs=[payload.get("dissent_ref")] if payload.get("dissent_ref") else None,
                    state_patch={"dissent": {"schema": schema, "resolution": payload.get("resolution")}},
                )
            elif schema == "review_verdict.v1":
                wm.post_delta(
                    workspace_id,
                    delta_kind="review_verdict",
                    actor=envelope.sender,
                    text=f"Review verdict: {payload.get('verdict', 'unknown')} (confidence: {payload.get('confidence', 'N/A')})",
                    refs=[payload.get("beacon_ref")] if payload.get("beacon_ref") else None,
                    state_patch={"review_verdict": {"verdict": payload.get("verdict"), "confidence": payload.get("confidence")}},
                )
        except Exception as e:
            logger.warning("Failed to project %s into workspace %s: %s", schema, workspace_id, e)

    def _push_to_transports(self, envelope: Envelope, target_agent: str = None):
        for t in self._transports:
            try:
                import inspect
                sig = inspect.signature(t)
                if "target_agent" in sig.parameters:
                    t(envelope, target_agent=target_agent)
                else:
                    t(envelope)
            except Exception:
                logger.warning(
                    "Transport push failed for %s -> %s",
                    envelope.id, target_agent, exc_info=True,
                )
