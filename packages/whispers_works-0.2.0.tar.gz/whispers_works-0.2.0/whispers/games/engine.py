import json
import uuid
import logging
from typing import List
from ..client import WhispersClient
from ..envelope import Envelope, MsgType

logger = logging.getLogger(__name__)

class GameOrchestrator:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.client = WhispersClient("game_orchestrator", db_path=db_path, agent_type="infrastructure")
        
    def create_game(self, template_name: str, participants: List[str]) -> str:
        game_id = str(uuid.uuid4())
        initial_state = {}
        with self.client.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """INSERT INTO games (game_id, template_name, current_phase, participants, state_data)
                   VALUES (?, ?, ?, ?, ?)""",
                (game_id, template_name, "setup", json.dumps(participants), json.dumps(initial_state))
            )
            conn.commit()
        return game_id

    def init_phase(self, game_id: str, phase_name: str):
        with self.client.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE games SET current_phase = ? WHERE game_id = ?", (phase_name, game_id))
            cursor.execute("SELECT participants FROM games WHERE game_id = ?", (game_id,))
            row = cursor.fetchone()
            participants = json.loads(row['participants']) if row else []
            conn.commit()
            
        for p in participants:
            with self.client.db.get_connection() as conn:
                cursor = conn.cursor()
                mode_filter = json.dumps({"allowed_senders": ["game_orchestrator"]})
                cursor.execute(
                    """UPDATE presence 
                       SET reception_mode = 'focused', mode_filter = ?, mode_set_by = 'game_orchestrator' 
                       WHERE agent_name = ?""",
                    (mode_filter, p)
                )
                conn.commit()

    def handle_move(self, envelope: Envelope):
        if envelope.msg_type != MsgType.MOVE:
            return
            
        game_id = envelope.context_id
        if not game_id:
            logger.error("MOVE signal missing dict context_id (game_id)")
            return
            
        with self.client.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT state_data, participants FROM games WHERE game_id = ?", (game_id,))
            row = cursor.fetchone()
            if not row:
                return
            state_data = json.loads(row['state_data']) if row['state_data'] else {}
            participants = json.loads(row['participants'])
            
            if not envelope.trace_id:
                logger.warning(f"MOVE from {envelope.sender} missing trace_id")
                
            if "moves" not in state_data:
                state_data["moves"] = {}
            state_data["moves"][envelope.sender] = {
                "body": envelope.body,
                "payload": envelope.payload,
                "trace_id": envelope.trace_id
            }
            
            cursor.execute("UPDATE games SET state_data = ? WHERE game_id = ?", (json.dumps(state_data), game_id))
            conn.commit()
            
            if len(state_data["moves"]) >= len(participants):
                self.trigger_reveal(game_id)

    def trigger_reveal(self, game_id: str):
        with self.client.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT state_data, participants FROM games WHERE game_id = ?", (game_id,))
            row = cursor.fetchone()
            if not row: return
            state_data = json.loads(row['state_data'])
            participants = json.loads(row['participants'])
            
            cursor.execute("UPDATE games SET current_phase = 'reveal' WHERE game_id = ?", (game_id,))
            conn.commit()

        for p in participants:
            with self.client.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "UPDATE presence SET reception_mode = 'open', mode_filter = NULL, mode_set_by = 'game_orchestrator' WHERE agent_name = ?",
                    (p,)
                )
                conn.commit()
                
        for p in participants:
            self.client.send(
                to=p,
                subject=f"REVEAL: Phase ended for game {game_id}",
                body=json.dumps(state_data["moves"]),
                msg_type="reveal",
                priority="priority",
                context_id=game_id
            )

def mount_orchestrator(dispatcher, db_path: str):
    orchestrator = GameOrchestrator(db_path)
    dispatcher.add_transport_listener(orchestrator.handle_move)
    return orchestrator
