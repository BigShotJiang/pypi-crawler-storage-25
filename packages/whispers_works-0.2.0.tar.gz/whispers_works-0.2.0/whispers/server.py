import asyncio
import atexit
import contextlib
import json
import logging
import math
import os
import secrets
import signal
import threading
import time
import uuid
from collections import defaultdict, deque

from fastapi import FastAPI, Request, HTTPException
from fastapi.staticfiles import StaticFiles

from sse_starlette.sse import EventSourceResponse
from starlette.requests import Request as StarletteRequest
from starlette.responses import JSONResponse, Response
from starlette.routing import Mount
from starlette.types import ASGIApp, Receive, Scope, Send

from mcp.server.streamable_http_manager import StreamableHTTPSessionManager

from .client import PermissionDeniedError, WhispersClient
from .storage.db import (
    WhispersDB,
    WhispersDBError,
    WhispersIdentityConflictError,
    WhispersLeaseConflictError,
    WhispersQueueLimitError,
    WhispersRateLimitError,
)
from .dispatcher import Dispatcher
from .transports.sse import SSETransport
from .transports.operator import OperatorEventType
from .a2a import create_a2a_router
from .envelope import Envelope, hydrate_policy_fields
from .scope_delivery import (
    sanitize_envelope_for_workspace_recipient,
    sanitize_message_record_for_workspace_recipient,
)
from .identity import (
    INTERNAL_IDENTITIES,
    fingerprint_public_key,
    normalize_public_key,
    validate_remote_callsign,
)
from .games.engine import mount_orchestrator
from .mcp_server import (
    create_server as create_mcp_server,
    TOOLS as MCP_TOOLS,
    current_agent_name,
    current_jolt_adapter_kind,
    current_jolt_can_notify,
    current_jolt_can_stage_context,
    current_jolt_can_trigger_inference,
    current_jolt_host_kind,
    ensure_client_for_agent,
)
from .path_utils import resolve_path, whispers_path
from .startup import build_startup_briefing
from .baton_enforcement import (
    YIELD_BLOCKING_READINESS_STATES,
    format_yield_blocked_message,
    yield_blocking_baton_obligations,
)

logger = logging.getLogger(__name__)
_REMOTE_PROTOCOL_VERSION = "whispers-remote-v1"
_HEALTH_DB_WRITE_READY_TIMEOUT_MS = int(os.getenv("WHISPERS_HEALTH_DB_WRITE_READY_TIMEOUT_MS", "100"))
_ALLOWED_REMOTE_SESSION_KINDS = {"remote_http", "local_listener", "mcp_bridge", "dashboard_console", "infrastructure"}

# ---------------------------------------------------------------------------
# PID file and crash tracking
# ---------------------------------------------------------------------------
from .process_utils import (
    write_pid_file as _write_pid_file,
    remove_pid_file as _remove_pid_file,
    read_pid_file as _read_pid_file,
    is_pid_alive as _is_process_alive,
    pid_file_path,
)

_PID_FILE_PATH = pid_file_path()
_CRASH_COUNTER_PATH = whispers_path("server-crashes.json")
_MAX_CRASH_LOOP_COUNT = 5  # 5 crashes within the window = crash loop
_CRASH_LOOP_WINDOW_SECONDS = 300  # 5-minute window for crash loop detection


def _detect_stale_server() -> int | None:
    """Detect a stale server process from PID file.

    Returns the stale PID if found (process dead but PID file exists),
    or None if the PID file is clean or missing.
    """
    pid = _read_pid_file()
    if pid is None:
        return None
    if pid == os.getpid():
        return None  # That's us
    if not _is_process_alive(pid):
        logger.warning("Stale PID file found (pid=%d is dead). Cleaning up.", pid)
        try:
            os.remove(_PID_FILE_PATH)
        except OSError:
            pass
        return pid
    return None  # Process is alive — not stale


def _query_bool(value: str | None) -> bool | None:
    normalized = str(value or "").strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    return None


def _kill_server_by_pid(pid: int, *, timeout: float = 5.0) -> bool:
    """Kill a server process by PID. Tries graceful SIGTERM first, then force.

    Returns True if the process was killed, False if it wasn't running.
    """
    import sys
    if not _is_process_alive(pid):
        return False

    logger.info("Killing server process pid=%d", pid)
    if sys.platform == "win32":
        import subprocess
        try:
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/F"],
                capture_output=True, timeout=timeout,
            )
        except Exception as exc:
            logger.warning("Failed to kill pid=%d: %s", pid, exc)
            return False
    else:
        try:
            os.kill(pid, signal.SIGTERM)
            # Wait briefly for graceful shutdown
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                if not _is_process_alive(pid):
                    break
                time.sleep(0.25)
            # Force kill if still alive
            if _is_process_alive(pid):
                os.kill(pid, signal.SIGKILL)
        except (OSError, ProcessLookupError):
            pass

    # Clean up PID file
    try:
        if os.path.exists(_PID_FILE_PATH):
            os.remove(_PID_FILE_PATH)
    except OSError:
        pass
    return True


def _record_crash() -> dict:
    """Record a crash event and return the current crash state."""
    now = time.time()
    state = _load_crash_state()
    state["crashes"].append(now)
    # Prune events outside the window
    cutoff = now - _CRASH_LOOP_WINDOW_SECONDS
    state["crashes"] = [t for t in state["crashes"] if t > cutoff]
    state["total_crashes"] = state.get("total_crashes", 0) + 1
    state["last_crash"] = now
    state["in_crash_loop"] = len(state["crashes"]) >= _MAX_CRASH_LOOP_COUNT
    _save_crash_state(state)
    return state


def _record_clean_start() -> None:
    """Record a clean server start (resets crash loop detection)."""
    state = _load_crash_state()
    state["last_clean_start"] = time.time()
    state["consecutive_clean_starts"] = state.get("consecutive_clean_starts", 0) + 1
    _save_crash_state(state)


def _load_crash_state() -> dict:
    """Load crash counter state from disk."""
    try:
        if os.path.exists(_CRASH_COUNTER_PATH):
            with open(_CRASH_COUNTER_PATH, "r") as f:
                state = json.load(f)
                if isinstance(state, dict):
                    state.setdefault("crashes", [])
                    return state
    except (OSError, json.JSONDecodeError):
        pass
    return {"crashes": [], "total_crashes": 0}


def _save_crash_state(state: dict) -> None:
    """Save crash counter state to disk."""
    try:
        os.makedirs(os.path.dirname(_CRASH_COUNTER_PATH), exist_ok=True)
        with open(_CRASH_COUNTER_PATH, "w") as f:
            json.dump(state, f, indent=2)
            f.write("\n")
    except OSError:
        pass


def _check_crash_loop() -> bool:
    """Check if the server is in a crash loop. Returns True if it should NOT start."""
    state = _load_crash_state()
    now = time.time()
    cutoff = now - _CRASH_LOOP_WINDOW_SECONDS
    recent = [t for t in state.get("crashes", []) if t > cutoff]
    if len(recent) >= _MAX_CRASH_LOOP_COUNT:
        logger.error(
            "CRASH LOOP DETECTED: %d crashes in the last %d seconds. "
            "Server will not auto-restart. Clear %s to reset.",
            len(recent), _CRASH_LOOP_WINDOW_SECONDS, _CRASH_COUNTER_PATH,
        )
        return True
    return False
_RUNTIME_STATE_PATH_ENV = "WHISPERS_RUNTIME_STATE_PATH"
_REMOTE_ADMISSION_MODE_ENV = "WHISPERS_REMOTE_ADMISSION_MODE"
_REMOTE_ALLOWED_AGENTS_ENV = "WHISPERS_REMOTE_ALLOWED_AGENTS"
_OBSERVABILITY_MODE_ENV = "WHISPERS_OBSERVABILITY_MODE"
_REMOTE_LEASE_SECONDS = int(os.environ.get("WHISPERS_REMOTE_LEASE_SECONDS", "300"))
_MAX_INLINE_PAYLOAD = int(os.environ.get("WHISPERS_MAX_INLINE_PAYLOAD", "32000"))
_GLOBAL_REQUESTS_PER_MIN = int(os.environ.get("WHISPERS_GLOBAL_REQUESTS_PER_MIN", "600"))
_PER_IP_REQUESTS_PER_MIN = int(os.environ.get("WHISPERS_PER_IP_REQUESTS_PER_MIN", "120"))
_PER_AGENT_REQUESTS_PER_MIN = int(os.environ.get("WHISPERS_PER_AGENT_REQUESTS_PER_MIN", "120"))
_BYTE_BUDGET_PER_MIN = int(os.environ.get("WHISPERS_BYTE_BUDGET", "200000"))
_MAX_QUEUED_RECIPIENTS_GLOBAL = int(os.environ.get("WHISPERS_MAX_QUEUED_RECIPIENTS_GLOBAL", "2000"))
_MAX_QUEUED_RECIPIENTS_PER_RECIPIENT = int(os.environ.get("WHISPERS_MAX_QUEUED_RECIPIENTS_PER_RECIPIENT", "250"))
_STREAM_BACKLOG_LIMIT = int(os.environ.get("WHISPERS_STREAM_BACKLOG_LIMIT", "100"))
_STREAM_KEEPALIVE_SECONDS = float(os.environ.get("WHISPERS_STREAM_KEEPALIVE_SECONDS", "15"))
_RATE_LIMIT_WINDOW_SECONDS = 60
_INITIAL_REMOTE_ADMISSION_MODE = os.environ.get(_REMOTE_ADMISSION_MODE_ENV, "trusted_team").strip().lower()
_INITIAL_REMOTE_ALLOWED_AGENTS = frozenset(
    agent.strip()
    for agent in os.environ.get(_REMOTE_ALLOWED_AGENTS_ENV, "whispers-console").split(",")
    if agent.strip()
)
_INITIAL_OBSERVABILITY_MODE = os.environ.get(_OBSERVABILITY_MODE_ENV, "metadata").strip().lower()
_INPROGRESS_DECAY_SECONDS = int(os.environ.get("WHISPERS_INPROGRESS_DECAY_SECONDS", "900"))
_OPERATOR_AGENT = "whispers-console"
_PRIORITY_ALIASES = {
    "urgent": "priority",
    "critical": "flash",
}
_RUNTIME_PROFILES = {
    "dev": {"admission": "open", "observability_mode": "full"},
    "trusted_team": {"admission": "trusted_team", "observability_mode": "metadata"},
}
_UNSET = Ellipsis


def _runtime_state_path() -> str:
    override = os.environ.get(_RUNTIME_STATE_PATH_ENV, "").strip()
    if override:
        return resolve_path(override)
    return whispers_path("runtime-state.json")

class RuntimeStateManager:
    def __init__(self):
        self._lock = threading.Lock()
        self._payload = None
        self._path = None
        self._timer = None
        self._flush_interval = 2.0
        self._last_write_error_signature: tuple[str, str, str] | None = None

    def load(self) -> dict:
        import copy
        with self._lock:
            if self._payload is not None:
                return copy.deepcopy(self._payload)

            path = _runtime_state_path()
            if not os.path.exists(path):
                self._payload = {}
                return {}
            try:
                with open(path, "r", encoding="utf-8") as handle:
                    payload = json.load(handle)
                    self._payload = payload if isinstance(payload, dict) else {}
            except Exception as exc:
                logger.warning("Unable to read runtime state at %s: %s", path, exc)
                self._payload = {}
            return copy.deepcopy(self._payload)

    def save(self, payload: dict) -> None:
        import copy
        with self._lock:
            self._payload = copy.deepcopy(payload)
            self._path = _runtime_state_path()
            if self._timer is None:
                self._timer = threading.Timer(self._flush_interval, self.flush)
                self._timer.daemon = True
                self._timer.start()

    def flush(self) -> None:
        import copy
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
            if self._payload is None:
                return
            payload_to_write = copy.deepcopy(self._payload)
            path = self._path or _runtime_state_path()
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as handle:
                json.dump(payload_to_write, handle, indent=2, sort_keys=True)
                handle.write("\n")
        except Exception as exc:
            signature = (path, type(exc).__name__, str(exc))
            with self._lock:
                should_log = self._last_write_error_signature != signature
                self._last_write_error_signature = signature
            if should_log:
                logger.warning("Unable to write runtime state to %s: %s", path, exc)
        else:
            with self._lock:
                self._last_write_error_signature = None

_runtime_state_manager = RuntimeStateManager()
atexit.register(_runtime_state_manager.flush)

def _load_runtime_state() -> dict:
    return _runtime_state_manager.load()

def _write_runtime_state(payload: dict) -> None:
    _runtime_state_manager.save(payload)


class _RuntimeSettings:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        persisted = _load_runtime_state()
        persisted_profile = str(persisted.get("runtime_profile") or "").strip().lower() or None
        persisted_admission = self._normalize_admission(persisted.get("remote_admission_mode"))
        persisted_observability = self._normalize_observability(persisted.get("observability_mode"))
        persisted_allowed_agents = persisted.get("allowed_agents")

        env_admission = os.environ.get(_REMOTE_ADMISSION_MODE_ENV)
        env_observability = os.environ.get(_OBSERVABILITY_MODE_ENV)
        env_allowed_agents = os.environ.get(_REMOTE_ALLOWED_AGENTS_ENV)

        self._admission = (
            self._normalize_admission(env_admission)
            or persisted_admission
            or self._normalize_admission(_INITIAL_REMOTE_ADMISSION_MODE)
            or "trusted_team"
        )
        self._observability_mode = (
            self._normalize_observability(env_observability)
            or persisted_observability
            or self._normalize_observability(_INITIAL_OBSERVABILITY_MODE)
            or "metadata"
        )
        if env_allowed_agents is not None:
            self._allowed_agents = self._normalize_allowlist(env_allowed_agents.split(","))
        elif isinstance(persisted_allowed_agents, list):
            self._allowed_agents = self._normalize_allowlist(persisted_allowed_agents)
        else:
            self._allowed_agents = self._normalize_allowlist(_INITIAL_REMOTE_ALLOWED_AGENTS)
        self._profile = self._derive_profile(
            self._admission,
            self._observability_mode,
            preferred=persisted_profile,
        )
        # Narrator designation (nullable — None means floor mode, no narrator)
        self._narrator_agent: str | None = persisted.get("narrator_agent") or None
        self._sync_env()

    @staticmethod
    def _normalize_allowlist(agents) -> tuple[str, ...]:
        normalized = {"whispers-console"}
        for agent in agents or ():
            agent = (agent or "").strip()
            if agent:
                normalized.add(agent)
        return tuple(sorted(normalized))

    @staticmethod
    def _normalize_admission(value) -> str | None:
        normalized = (value or "").strip().lower()
        return normalized if normalized in {"open", "trusted_team"} else None

    @staticmethod
    def _normalize_observability(value) -> str | None:
        normalized = (value or "").strip().lower()
        return normalized if normalized in {"metadata", "full"} else None

    @staticmethod
    def _derive_profile(admission: str, observability_mode: str, *, preferred: str | None = None) -> str:
        if (
            admission == _RUNTIME_PROFILES["dev"]["admission"]
            and observability_mode == _RUNTIME_PROFILES["dev"]["observability_mode"]
        ):
            return "dev"
        if (
            admission == _RUNTIME_PROFILES["trusted_team"]["admission"]
            and observability_mode == _RUNTIME_PROFILES["trusted_team"]["observability_mode"]
        ):
            return "trusted_team"
        if preferred and preferred not in {"dev", "trusted_team"}:
            return preferred
        return "custom"

    def _sync_env(self) -> None:
        os.environ[_REMOTE_ADMISSION_MODE_ENV] = self._admission
        os.environ[_REMOTE_ALLOWED_AGENTS_ENV] = ",".join(self._allowed_agents)
        os.environ[_OBSERVABILITY_MODE_ENV] = self._observability_mode

    def _snapshot_unlocked(self) -> dict:
        return {
            "runtime_profile": self._profile,
            "remote_admission_mode": self._admission,
            "observability_mode": self._observability_mode,
            "allowed_agents": list(self._allowed_agents),
            "narrator_agent": self._narrator_agent,
        }

    def _persist(self) -> None:
        try:
            _write_runtime_state(self._snapshot_unlocked())
        except OSError as exc:
            logger.warning("Unable to persist runtime state to %s: %s", _runtime_state_path(), exc)

    def snapshot(self) -> dict:
        with self._lock:
            return self._snapshot_unlocked()

    def public_snapshot(self) -> dict:
        snapshot = self.snapshot()
        return {
            "runtime_profile": snapshot["runtime_profile"],
            "remote_admission_mode": snapshot["remote_admission_mode"],
            "observability_mode": snapshot["observability_mode"],
            "narrator_agent": snapshot["narrator_agent"],
            "narrator_status": self.narrator_status(),
        }

    def admission_mode(self) -> str:
        return self.snapshot()["remote_admission_mode"]

    def observability_mode(self) -> str:
        return self.snapshot()["observability_mode"]

    def allowed_agents(self) -> tuple[str, ...]:
        with self._lock:
            return self._allowed_agents

    def narrator_agent(self) -> str | None:
        """Current narrator designation. None = floor mode (no narrator)."""
        with self._lock:
            return self._narrator_agent

    def narrator_status(self, *, _db=None) -> str:
        """Derived narrator activation status.

        Returns one of: disabled, designated, active, degraded.
        - disabled: narrator_agent is None (floor mode)
        - designated: narrator set but agent not connected
        - active: narrator connected (online presence)
        - degraded: narrator was active but lost connection
        """
        with self._lock:
            if not self._narrator_agent:
                return "disabled"
            narrator = self._narrator_agent
        # Check if narrator agent is online via presence table
        _db = _db or db
        try:
            with _db.get_connection() as conn:
                row = conn.execute(
                    "SELECT status FROM presence WHERE agent_name = ?",
                    (narrator,),
                ).fetchone()
                if row and row[0] == "online":
                    return "active"
                return "designated"
        except Exception:
            return "designated"

    def update(
        self,
        *,
        profile: str | None = None,
        admission: str | None = None,
        observability_mode: str | None = None,
        allowed_agents=None,
        narrator_agent: str | None = ...,  # sentinel: ... means "not provided"
    ) -> dict:
        with self._lock:
            if profile is not None:
                normalized_profile = profile.strip().lower()
                if normalized_profile not in _RUNTIME_PROFILES:
                    raise ValueError("Unsupported runtime profile.")
                profile_settings = _RUNTIME_PROFILES[normalized_profile]
                self._profile = normalized_profile
                self._admission = profile_settings["admission"]
                self._observability_mode = profile_settings["observability_mode"]

            if admission is not None:
                normalized_admission = admission.strip().lower()
                if normalized_admission not in {"open", "trusted_team"}:
                    raise ValueError("Unsupported admission mode.")
                self._admission = normalized_admission
                if profile is None:
                    self._profile = "custom"

            if observability_mode is not None:
                normalized_observability = observability_mode.strip().lower()
                if normalized_observability not in {"metadata", "full"}:
                    raise ValueError("Unsupported observability mode.")
                self._observability_mode = normalized_observability
                if profile is None:
                    self._profile = "custom"

            if allowed_agents is not None:
                if isinstance(allowed_agents, str):
                    allowed_agents = [allowed_agents]
                self._allowed_agents = self._normalize_allowlist(allowed_agents)
                if profile is None:
                    self._profile = "custom"

            # Narrator designation — ... sentinel means "not provided", None means "clear"
            if narrator_agent is not ...:
                self._narrator_agent = narrator_agent.strip() if narrator_agent else None

            if (
                profile is None
                and self._admission == _RUNTIME_PROFILES["dev"]["admission"]
                and self._observability_mode == _RUNTIME_PROFILES["dev"]["observability_mode"]
            ):
                self._profile = "dev"
            elif (
                profile is None
                and self._admission == _RUNTIME_PROFILES["trusted_team"]["admission"]
                and self._observability_mode == _RUNTIME_PROFILES["trusted_team"]["observability_mode"]
            ):
                self._profile = "trusted_team"

            self._sync_env()
            self._persist()
            return self._snapshot_unlocked()


runtime_settings = _RuntimeSettings()

# ---------------------------------------------------------------------------
# MCP Token management
# ---------------------------------------------------------------------------
_ENV_PATH = whispers_path(".env")


def _get_mcp_token() -> str:
    """Read WHISPERS_MCP_TOKEN from env or ~/.whispers/.env, auto-generate if missing."""
    token = os.environ.get("WHISPERS_MCP_TOKEN", "").strip()
    if token:
        return token

    # Try loading from .env file
    if os.path.exists(_ENV_PATH):
        with open(_ENV_PATH) as f:
            for line in f:
                line = line.strip()
                if line.startswith("WHISPERS_MCP_TOKEN="):
                    token = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if token:
                        os.environ["WHISPERS_MCP_TOKEN"] = token
                        return token

    # Auto-generate and persist
    token = secrets.token_urlsafe(32)
    os.makedirs(os.path.dirname(_ENV_PATH), exist_ok=True)
    with open(_ENV_PATH, "a") as f:
        f.write(f"WHISPERS_MCP_TOKEN={token}\n")
    os.environ["WHISPERS_MCP_TOKEN"] = token
    logger.info("Auto-generated WHISPERS_MCP_TOKEN (saved to %s)", _ENV_PATH)
    return token



def _bearer_auth_middleware(app: ASGIApp) -> ASGIApp:
    """Wrap an ASGI app with bearer token verification and agent identification."""
    async def middleware(scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http":
            request = StarletteRequest(scope, receive)
            remote_addr = request.client.host if request.client else "unknown"

            # Rate-limit auth failures on the MCP endpoint too
            if _check_auth_rate_limit(remote_addr):
                response = Response("Too many authentication failures", status_code=429)
                await response(scope, receive, send)
                return

            auth_header = request.headers.get("authorization", "")
            expected = f"Bearer {_get_mcp_token()}"
            if not secrets.compare_digest(auth_header, expected):
                _record_auth_failure(remote_addr)
                response = Response("Unauthorized", status_code=401)
                await response(scope, receive, send)
                return
            # Extract agent identity from ?agent= query param or X-Whispers-Agent header
            agent = request.query_params.get("agent") or request.headers.get("x-whispers-agent")
            if not agent:
                response = Response(
                    "MCP connection requires agent identity. "
                    "Configure via 'whispers mcp-install' or pass ?agent=<name> query param.",
                    status_code=400,
                )
                await response(scope, receive, send)
                return
            # Validate callsign format
            error = validate_remote_callsign(agent)
            if error:
                response = Response(error, status_code=400)
                await response(scope, receive, send)
                return
            current_agent_name.set(agent)
            current_jolt_host_kind.set(request.query_params.get("jolt_host_kind"))
            current_jolt_adapter_kind.set(request.query_params.get("jolt_adapter_kind"))
            current_jolt_can_notify.set(_query_bool(request.query_params.get("jolt_can_notify")))
            current_jolt_can_stage_context.set(_query_bool(request.query_params.get("jolt_can_stage_context")))
            current_jolt_can_trigger_inference.set(
                _query_bool(request.query_params.get("jolt_can_trigger_inference"))
            )
            client = ensure_client_for_agent(agent)
            with contextlib.suppress(Exception):
                if request.method == "POST":
                    client._touch_activity()
                else:
                    client._touch_heartbeat()
        await app(scope, receive, send)
    return middleware


# ---------------------------------------------------------------------------
# MCP over Streamable HTTP
# ---------------------------------------------------------------------------
_mcp_server = create_mcp_server(agent_name="whispers-mcp-http")
_session_manager = StreamableHTTPSessionManager(
    app=_mcp_server, json_response=True, stateless=True,
)

# Initialize the Standalone Execution Context
os.environ.setdefault("WHISPERS_DEPLOYMENT_MODE", "standalone")

def _record_message_lifecycle_event(message_id: str, trace_id: str | None, sender: str, recipient: str, step: str) -> None:
    try:
        state = _load_runtime_state()
        events = state.get("message_events")
        if not isinstance(events, list):
            events = []
        events.append({
            "type": "message_lifecycle",
            "message_uuid": message_id,
            "trace_id": trace_id,
            "sender_agent": sender,
            "recipient_agent": recipient,
            "lifecycle_step": step,
            "detail": f"Message transitioned to {step}",
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "severity": "info",
        })
        _MSG_EVENT_CAP = 100
        if len(events) > _MSG_EVENT_CAP:
            events = events[-_MSG_EVENT_CAP:]
        state["message_events"] = events
        _write_runtime_state(state)
    except Exception:
        logger.debug("Failed to record message lifecycle event", exc_info=True)

class _ServerRuntime:
    """Lazily bootstrap the mutable server runtime.

    Importing whispers.server should not open or migrate the database. The
    actual runtime surfaces come up on first real use by the HTTP app.
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._initialized = False
        self.db = None
        self.dispatcher = None
        self.sse = None
        self.operator_sse = None
        self.server_client = None
        self.server_snapshot_client = None
        self.registry = None
        self.orchestrator = None

    def initialize(self):
        if self._initialized:
            if "app" in globals():
                app.state.db = self.db
                app.state.dispatcher = self.dispatcher
                app.state.sse = self.sse
                app.state.operator_sse = self.operator_sse
            return self

        with self._lock:
            if self._initialized:
                return self

            from .transports.operator import OperatorSSETransport, OperatorEventType

            db = WhispersDB(on_message_transition=_record_message_lifecycle_event)
            dispatcher = Dispatcher(db)
            sse = SSETransport(observability_mode_getter=runtime_settings.observability_mode)
            operator_sse = OperatorSSETransport()

            server_client = WhispersClient(
                "whispers-server",
                db_path=db.db_path,
                agent_type="infrastructure",
            )
            server_snapshot_client = WhispersClient(
                "whispers-server",
                db_path=db.db_path,
                agent_type="infrastructure",
                read_only=True,
            )

            dispatcher.add_transport_listener(_push_sse_event)
            orchestrator = mount_orchestrator(dispatcher, db.db_path)

            self.db = db
            self.dispatcher = dispatcher
            self.sse = sse
            self.operator_sse = operator_sse
            self.server_client = server_client
            self.server_snapshot_client = server_snapshot_client
            self.registry = server_client.registry
            self.orchestrator = orchestrator

            # Wire board snapshot builder
            operator_sse.board.set_builder(
                lambda: _build_operator_board(db, server_client.registry),
                seq_fn=lambda: operator_sse.sequence_id,
            )

            self._initialized = True

            if "app" in globals():
                app.state.db = db
                app.state.dispatcher = dispatcher
                app.state.sse = sse
                app.state.operator_sse = operator_sse

        return self

    def resolve(self, attribute: str):
        runtime = self.initialize()
        value = getattr(runtime, attribute)
        if value is None:
            raise RuntimeError(f"Server runtime attribute '{attribute}' is not initialized")
        return value


class _RuntimeProxy:
    def __init__(self, attribute: str) -> None:
        self._attribute = attribute

    def _target(self):
        return _server_runtime.resolve(self._attribute)

    def __getattr__(self, name: str):
        return getattr(self._target(), name)

    def __call__(self, *args, **kwargs):
        return self._target()(*args, **kwargs)

    def __repr__(self) -> str:
        return f"<RuntimeProxy {self._attribute}>"


def _build_operator_board(db_instance, registry) -> dict:
    """Build operator board snapshot from current DB state.

    Returns the canonical shape consumed by OperatorBoardSnapshot.
    """
    from .transports.operator import empty_agent_counters, empty_system_counters
    from .coordination_runtime import summarize_coordination_state
    from .storage.db import _resolve_callsign_aliases

    agents = {}
    system = empty_system_counters()
    lane_warning_counts = defaultdict(int)

    try:
        lane_warnings = db_instance.check_repo_divergence()
    except Exception:
        lane_warnings = []
    else:
        system["lane_warnings_active"] = len(lane_warnings)
        for warning in lane_warnings:
            for callsign in _lane_warning_agents(warning.agent_a, warning.agent_b):
                lane_warning_counts[callsign] += 1

    # Get all registered agents with lease-backed presence truth when available.
    with db_instance.get_readonly_connection() as conn:
        has_sessions = db_instance.has_table("agent_sessions", conn=conn)
        if has_sessions:
            rows = conn.execute("""
                SELECT
                    ac.callsign,
                    CASE WHEN s.active_count > 0 THEN 1 ELSE 0 END AS is_online,
                    COALESCE(ars.readiness, 'unknown') AS readiness,
                    ars.attention_state,
                    ars.current_task
                FROM agent_cards ac
                LEFT JOIN presence p ON ac.callsign = p.agent_name
                LEFT JOIN agent_runtime_state ars ON ac.callsign = ars.agent_name
                LEFT JOIN (
                    SELECT agent_name, COUNT(*) AS active_count
                    FROM agent_sessions
                    WHERE lease_expires_at >= CURRENT_TIMESTAMP
                    GROUP BY agent_name
                ) s ON s.agent_name = ac.callsign
                WHERE ac.deregistered_at IS NULL
            """).fetchall()
        else:
            rows = conn.execute("""
                SELECT
                    ac.callsign,
                    CASE WHEN p.status IN ('online', 'idle') THEN 1 ELSE 0 END AS is_online,
                    COALESCE(ars.readiness, 'unknown') AS readiness,
                    ars.attention_state,
                    ars.current_task
                FROM agent_cards ac
                LEFT JOIN presence p ON ac.callsign = p.agent_name
                LEFT JOIN agent_runtime_state ars ON ac.callsign = ars.agent_name
                WHERE ac.deregistered_at IS NULL
            """).fetchall()
        rows = [dict(row) for row in rows]

        for row in rows:
            callsign = row["callsign"]
            online = bool(row["is_online"])
            counters = empty_agent_counters()
            counters["online"] = online
            counters["readiness"] = row["readiness"]
            counters["attention_state"] = row["attention_state"]
            counters["current_task"] = row["current_task"]
            counters["lane_warnings"] = lane_warning_counts.get(callsign, 0)

            # Per-agent baton counts
            try:
                baton_counts = db_instance.get_baton_state_counts(callsign)
                counters["incoming_batons"] = baton_counts.get("incoming_batons", 0)
                counters["carrying_batons"] = baton_counts.get("carrying_batons", 0)
                counters["claimed_reviews"] = baton_counts.get("claimed_reviews", 0)
            except Exception:
                pass

            # Per-agent coordination counts
            try:
                coord_raw = db_instance.get_coordination_state(callsign)
                coord = summarize_coordination_state(
                    coord_raw.get("inbound", []),
                    coord_raw.get("outbound", []),
                )
                counters["pending_assignments"] = coord.pending_assignments
                counters["active_assignments"] = coord.pending_assignments  # active = pending until explicit pickup
                counters["blocking_reviews"] = coord.blocking_review_requests
            except Exception:
                pass

            # Per-agent unread pressure using the same unread predicate as status.
            try:
                aliases = _resolve_callsign_aliases(conn, callsign)
                alias_placeholders = ",".join("?" * len(aliases))
                unread_rows = conn.execute(
                    f"""
                    SELECT COALESCE(m.queue_class, 'conversation') AS queue_class,
                           COUNT(m.rowid) AS cnt
                    FROM messages m
                    JOIN message_recipients r ON m.uuid = r.message_uuid
                    WHERE r.recipient_callsign IN ({alias_placeholders})
                      AND m.status = 'new'
                      AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                      AND r.read_at IS NULL
                      AND r.archived_at IS NULL
                      AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
                    GROUP BY queue_class
                    """,
                    aliases,
                ).fetchall()
                pending_by_class = {
                    str(unread_row["queue_class"] or "conversation"): int(unread_row["cnt"] or 0)
                    for unread_row in unread_rows
                }
                counters["pending_messages"] = sum(pending_by_class.values())
                counters["pending_actionable"] = int(pending_by_class.get("actionable", 0) or 0)
            except Exception:
                pass

            agents[callsign] = counters

            if online:
                system["agents_online"] += 1
            system["total_pending_messages"] += counters.get("pending_messages", 0)
            system["total_pending_actionable"] += counters.get("pending_actionable", 0)
            system["total_active_assignments"] += counters.get("active_assignments", 0)
            system["total_pending_assignments"] += counters.get("pending_assignments", 0)
            system["total_blocking_reviews"] += counters.get("blocking_reviews", 0)
            system["total_batons_in_flight"] += (
                counters.get("incoming_batons", 0) + counters.get("carrying_batons", 0)
            )

    return {"agents": agents, "system": system}


def _lane_warning_agents(*callsigns: str | None) -> list[str]:
    return sorted({callsign for callsign in callsigns if callsign})


def _lease_conflict_payload(agent_name: str, conflicts: list[dict]) -> dict:
    conflicting_agents = sorted({conflict.get("held_by") for conflict in conflicts if conflict.get("held_by")})
    agent_b = conflicting_agents[0] if conflicting_agents else ""
    payload = {
        "agent_a": agent_name,
        "agent_b": agent_b,
        "conflicting_agents": conflicting_agents,
        "lease_conflicts": conflicts,
        "enforced": True,
    }
    payload["agents"] = _lane_warning_agents(agent_name, *conflicting_agents)
    return payload


def _ensure_server_runtime():
    return _server_runtime.initialize()


def _push_sse_event(envelope):
    sse.push(envelope)


def _push_workspace_event(event_type: str, payload: dict):
    operator_sse.push(event_type, payload)


def _push_operator_board_refresh(
    reason: str,
    *,
    agent: str | None = None,
    agents: list[str] | None = None,
    source_module: str = "server",
) -> None:
    """Invalidate the operator board and nudge Console subscribers to refresh it."""
    payload: dict[str, object] = {"reason": reason}
    if agent:
        payload["agent"] = agent
    if agents:
        payload["agents"] = agents
    operator_sse.push(
        OperatorEventType.BOARD_SNAPSHOT,
        payload,
        source_module=source_module,
        agent=agent,
        agents=agents,
    )


_server_runtime = _ServerRuntime()
db = _RuntimeProxy("db")
dispatcher = _RuntimeProxy("dispatcher")
sse = _RuntimeProxy("sse")
operator_sse = _RuntimeProxy("operator_sse")
_server_client = _RuntimeProxy("server_client")
_server_snapshot_client = _RuntimeProxy("server_snapshot_client")
_server_registry = _RuntimeProxy("registry")

from .workspaces import register_workspace_listener
register_workspace_listener(_push_workspace_event)

# ---------------------------------------------------------------------------
# Lifecycle events
# ---------------------------------------------------------------------------

_startup_callbacks = []


class _NetworkBudgetLimiter:
    def __init__(self) -> None:
        self._request_events = defaultdict(deque)
        self._byte_events = defaultdict(deque)
        self._lock = threading.Lock()

    @staticmethod
    def _prune(events, now: float, *, byte_mode: bool = False) -> None:
        while events:
            timestamp = events[0][0] if byte_mode else events[0]
            if now - timestamp < _RATE_LIMIT_WINDOW_SECONDS:
                break
            events.popleft()

    @staticmethod
    def _retry_after(events, now: float, *, byte_mode: bool = False) -> int:
        if not events:
            return 1
        oldest = events[0][0] if byte_mode else events[0]
        remaining = _RATE_LIMIT_WINDOW_SECONDS - (now - oldest)
        return max(1, int(math.ceil(remaining)))

    def reserve_requests(self, scopes: list[tuple[str, str, int, str]]) -> None:
        now = time.monotonic()
        to_append = []

        with self._lock:
            for scope, subject, limit, policy_key in scopes:
                if not subject or limit <= 0:
                    continue
                key = (scope, subject)
                events = self._request_events[key]
                self._prune(events, now)
                used = len(events)
                if used + 1 > limit:
                    retry_after = self._retry_after(events, now)
                    raise HTTPException(
                        status_code=429,
                        detail={
                            "error": "rate_limit_exceeded",
                            "limit_type": "requests_per_min",
                            "scope": scope,
                            "subject": subject,
                            "policy_key": policy_key,
                            "used": used,
                            "attempted": 1,
                            "limit": limit,
                            "remaining": 0,
                            "window_seconds": _RATE_LIMIT_WINDOW_SECONDS,
                            "retry_after": retry_after,
                            "message": f"{scope.replace('_', ' ').title()} request budget exceeded.",
                        },
                        headers={"Retry-After": str(retry_after)},
                    )
                to_append.append(events)

            for events in to_append:
                events.append(now)

    def reserve_bytes(self, scope: str, subject: str, attempted: int, limit: int, policy_key: str) -> None:
        if not subject or attempted <= 0 or limit <= 0:
            return

        now = time.monotonic()
        with self._lock:
            key = (scope, subject)
            events = self._byte_events[key]
            self._prune(events, now, byte_mode=True)
            used = sum(size for _, size in events)
            if used + attempted > limit:
                retry_after = self._retry_after(events, now, byte_mode=True)
                raise HTTPException(
                    status_code=429,
                    detail={
                        "error": "rate_limit_exceeded",
                        "limit_type": "byte_budget_per_min",
                        "scope": scope,
                        "subject": subject,
                        "policy_key": policy_key,
                        "used": used,
                        "attempted": attempted,
                        "limit": limit,
                        "remaining": 0,
                        "window_seconds": _RATE_LIMIT_WINDOW_SECONDS,
                        "retry_after": retry_after,
                        "message": f"{scope.replace('_', ' ').title()} byte budget exceeded.",
                    },
                    headers={"Retry-After": str(retry_after)},
                )
            events.append((now, attempted))


_network_budget_limiter = _NetworkBudgetLimiter()


def _record_security_event(
    event_type: str,
    outcome: str,
    *,
    actor_agent: str | None = None,
    target_agent: str | None = None,
    endpoint: str | None = None,
    detail: dict | str | None = None,
) -> None:
    try:
        db.record_security_event(
            event_type,
            outcome,
            actor_agent=actor_agent,
            target_agent=target_agent,
            endpoint=endpoint,
            detail=detail,
        )
    except Exception as exc:
        logger.warning("Security event write failed: %s", exc)


def _workspace_projection_guard(
    *,
    workspace_id: str | None,
    actor_agent: str,
    endpoint: str,
    outcome: str,
    projection_kind: str,
    projection_label: str,
    detail: dict | None = None,
) -> bool:
    if not workspace_id:
        return False

    try:
        with db.get_connection() as conn:
            workspace = conn.execute(
                "SELECT status FROM workspaces WHERE workspace_id = ?",
                (workspace_id,),
            ).fetchone()
            if not workspace:
                logger.warning(
                    "Skipping %s workspace projection; workspace %s not found.",
                    projection_kind,
                    workspace_id,
                )
                return False
            if workspace["status"] != "active":
                logger.warning(
                    "Skipping %s workspace projection; workspace %s is %s.",
                    projection_kind,
                    workspace_id,
                    workspace["status"],
                )
                return False

            member = conn.execute(
                """
                SELECT membership_role, membership_state
                FROM workspace_members
                WHERE workspace_id = ? AND agent_name = ?
                """,
                (workspace_id, actor_agent),
            ).fetchone()
    except Exception as exc:
        logger.warning(
            "Failed to evaluate workspace projection boundary for %s in %s: %s",
            projection_kind,
            endpoint,
            exc,
        )
        return False

    if member and member["membership_state"] == "active" and member["membership_role"] != "observer":
        return True

    if member and member["membership_state"] == "active" and member["membership_role"] == "observer":
        reason = "observer_projection"
        explanation = (
            f"{projection_label} stayed direct; projecting it into workspace {workspace_id} "
            "would widen visibility because observers cannot inject room activity."
        )
    else:
        reason = "non_member_projection"
        explanation = (
            f"{projection_label} stayed direct; projecting it into workspace {workspace_id} "
            "would widen visibility because the actor is not an active posting member."
        )

    detail_payload = {
        "workspace_id": workspace_id,
        "projection_kind": projection_kind,
        "reason": reason,
        "projected": False,
        "required_membership": "active_posting_member",
        "explanation": explanation,
    }
    if detail:
        detail_payload.update(detail)

    _record_security_event(
        "scope_boundary",
        outcome,
        actor_agent=actor_agent,
        endpoint=endpoint,
        detail=detail_payload,
    )
    return False


def _post_workspace_delta_if_allowed(
    *,
    workspace_id: str | None,
    actor_agent: str,
    endpoint: str,
    outcome: str,
    projection_kind: str,
    projection_label: str,
    delta_kind: str,
    text: str | None = None,
    refs: list[str] | None = None,
    artifacts: list[str] | None = None,
    state_patch: dict | None = None,
    related_message_id: str | None = None,
    detail: dict | None = None,
) -> bool:
    if not _workspace_projection_guard(
        workspace_id=workspace_id,
        actor_agent=actor_agent,
        endpoint=endpoint,
        outcome=outcome,
        projection_kind=projection_kind,
        projection_label=projection_label,
        detail=detail,
    ):
        return False

    try:
        from whispers.workspaces import WorkspaceManager

        wm = WorkspaceManager(db)
        wm.post_delta(
            workspace_id,
            delta_kind=delta_kind,
            actor=actor_agent,
            text=text,
            refs=refs,
            artifacts=artifacts,
            state_patch=state_patch,
            related_message_id=related_message_id,
        )
        return True
    except Exception as exc:
        logger.warning("Failed to post workspace delta for %s: %s", projection_kind, exc)
        return False


def _extract_bearer_token(request: Request) -> str | None:
    auth_header = request.headers.get("authorization", "").strip()
    if not auth_header.lower().startswith("bearer "):
        return None
    token = auth_header.split(" ", 1)[1].strip()
    return token or None


def _extract_request_token(request: Request, *, allow_query_token: bool = False) -> str | None:
    token = _extract_bearer_token(request)
    if token:
        return token
    if allow_query_token:
        query_token = (request.query_params.get("token") or "").strip()
        return query_token or None
    return None


def _admission_allowed(agent_name: str) -> bool:
    admission_mode = runtime_settings.admission_mode()
    if admission_mode == "open":
        return True
    if agent_name in INTERNAL_IDENTITIES:
        return True
    allowed_agents = runtime_settings.allowed_agents()
    if "*" in allowed_agents:
        return True
    return agent_name in allowed_agents


def _existing_callsign_policy() -> str:
    return "reclaim_offline_allowed" if runtime_settings.admission_mode() == "open" else "token_required"


def _effective_existing_callsign_policy(*, public_key_bound: bool) -> str:
    if runtime_settings.admission_mode() != "open":
        return "token_required"
    if public_key_bound:
        return "token_required_key_bound"
    return "reclaim_offline_allowed"


def _identity_key_status(agent_name: str) -> dict:
    public_key = db.get_agent_public_key(agent_name)
    return {
        "agent_name": agent_name,
        "public_key": public_key,
        "public_key_bound": bool(public_key),
        "public_key_fingerprint": fingerprint_public_key(public_key),
    }


def _callsign_state(callsign: str) -> dict:
    error = validate_remote_callsign(callsign)
    if error:
        return {
            "callsign": callsign,
            "state": "invalid",
            "available": False,
            "active": False,
            "detail": error,
            "existing_callsign_policy": _existing_callsign_policy(),
            "public_key_bound": False,
            "public_key_fingerprint": None,
        }

    with db.get_connection() as conn:
        agent = conn.execute(
            """
            SELECT agent_id, public_key
            FROM agent_cards
            WHERE callsign = ? AND deregistered_at IS NULL
            """,
            (callsign,),
        ).fetchone()
        active_session = db.agent_has_active_session(callsign, conn=conn)

    if not agent:
        return {
            "callsign": callsign,
            "state": "available",
            "available": True,
            "active": False,
            "detail": "Callsign is available.",
            "existing_callsign_policy": _existing_callsign_policy(),
            "public_key_bound": False,
            "public_key_fingerprint": None,
        }

    active = bool(active_session)
    public_key = agent["public_key"]
    return {
        "callsign": callsign,
        "state": "active" if active else "claimed",
        "available": False,
        "active": active,
        "detail": "Callsign is active." if active else "Callsign is already registered.",
        "existing_callsign_policy": _effective_existing_callsign_policy(public_key_bound=bool(public_key)),
        "public_key_bound": bool(public_key),
        "public_key_fingerprint": fingerprint_public_key(public_key),
    }


def _system_metrics() -> dict:
    with db.get_connection() as conn:
        remote_sessions = conn.execute(
            "SELECT COUNT(*) FROM agent_sessions WHERE token_id IS NOT NULL"
        ).fetchone()[0]
        queued_messages = conn.execute(
            """
            SELECT COUNT(*)
            FROM message_recipients
            WHERE delivery_status IN ('queued', 'unclaimed')
            """
        ).fetchone()[0]
        security_events_24h = conn.execute(
            "SELECT COUNT(*) FROM security_events WHERE created_at > datetime('now', '-24 hours')"
        ).fetchone()[0]
    return {
        "remote_sessions": remote_sessions,
        "queued_recipients": queued_messages,
        "security_events_24h": security_events_24h,
    }


def _enforce_request_budget(request: Request, agent_name: str | None = None, trust_tier: int | None = None) -> None:
    from whispers.budget import get_budget_for_tier
    
    if trust_tier is None and agent_name:
        try:
            row = db.get_connection().execute("SELECT trust_tier FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL", (agent_name,)).fetchone()
            trust_tier = row[0] if row else 1
        except Exception:
            trust_tier = 1

    budget = get_budget_for_tier(trust_tier)

    scopes = [
        ("global", "__global__", _GLOBAL_REQUESTS_PER_MIN, "global_requests_per_min"),
        (
            "per_ip",
            request.client.host if request.client else "unknown",
            _PER_IP_REQUESTS_PER_MIN,
            "per_ip_requests_per_min",
        ),
    ]
    if agent_name:
        scopes.append(("per_agent", agent_name, budget["requests_per_min"], "per_agent_requests_per_min"))
    _network_budget_limiter.reserve_requests(scopes)


# ---------------------------------------------------------------------------
# Auth failure rate limiting — prevent storm from overwhelming server
# ---------------------------------------------------------------------------
_AUTH_FAIL_TRACKER: dict[str, list[float]] = defaultdict(list)
_AUTH_FAIL_WINDOW = 60.0       # 1 minute window
_AUTH_FAIL_LIMIT = 5           # max failures per IP per minute
_AUTH_FAIL_BLOCK_SECONDS = 300 # block IP for 5 minutes after exceeding limit
_AUTH_FAIL_BLOCKED: dict[str, float] = {}

# Localhost gets lenient limits — local agents poll frequently and must
# never be locked out of their own system.
_LOCALHOST_ADDRS = frozenset({"127.0.0.1", "::1", "localhost"})
_AUTH_FAIL_LIMIT_LOCALHOST = 50          # 10x headroom for local polling
_AUTH_FAIL_BLOCK_SECONDS_LOCALHOST = 10  # 10s tap on the brakes, not 5min lockout


def _check_auth_rate_limit(remote_addr: str) -> bool:
    """Return True if this IP should be blocked due to auth failure rate."""
    now = time.time()
    # Check if currently blocked
    blocked_until = _AUTH_FAIL_BLOCKED.get(remote_addr, 0)
    if now < blocked_until:
        return True
    # Clean expired block
    if remote_addr in _AUTH_FAIL_BLOCKED:
        del _AUTH_FAIL_BLOCKED[remote_addr]
    return False


def _record_auth_failure(remote_addr: str) -> None:
    """Track an auth failure and block the IP if rate exceeded."""
    now = time.time()
    window_start = now - _AUTH_FAIL_WINDOW
    _AUTH_FAIL_TRACKER[remote_addr] = [
        t for t in _AUTH_FAIL_TRACKER[remote_addr] if t > window_start
    ]
    _AUTH_FAIL_TRACKER[remote_addr].append(now)
    is_local = remote_addr in _LOCALHOST_ADDRS
    limit = _AUTH_FAIL_LIMIT_LOCALHOST if is_local else _AUTH_FAIL_LIMIT
    block_seconds = _AUTH_FAIL_BLOCK_SECONDS_LOCALHOST if is_local else _AUTH_FAIL_BLOCK_SECONDS
    if len(_AUTH_FAIL_TRACKER[remote_addr]) >= limit:
        _AUTH_FAIL_BLOCKED[remote_addr] = now + block_seconds
        logger.warning(
            "Auth failure rate limit exceeded for %s — blocked for %ds (%d failures in %ds)%s",
            remote_addr, block_seconds,
            len(_AUTH_FAIL_TRACKER[remote_addr]), int(_AUTH_FAIL_WINDOW),
            " [localhost — lenient policy]" if is_local else "",
        )


def _require_authenticated_agent(
    request: Request,
    *,
    endpoint: str = "unknown",
    allow_query_token: bool = False,
    return_token: bool = False,
    required_scopes: tuple[str, ...] | None = None,
) -> tuple[str, dict] | tuple[str, dict, str]:
    remote_addr = request.client.host if request.client else "unknown"

    # Rate-limit auth failures — block IPs that are hammering with bad credentials
    if _check_auth_rate_limit(remote_addr):
        raise HTTPException(
            status_code=429,
            detail="Too many authentication failures. Try again later.",
        )

    token = _extract_request_token(request, allow_query_token=allow_query_token)
    if not token:
        _record_auth_failure(remote_addr)
        _record_security_event(
            "auth_failure",
            "missing_token",
            endpoint=endpoint,
            detail={"remote_addr": remote_addr},
        )
        raise HTTPException(status_code=401, detail="Missing bearer token.")

    token_row = db.get_api_token(token)
    if not token_row:
        _record_auth_failure(remote_addr)
        _record_security_event(
            "auth_failure",
            "invalid_or_revoked_token",
            endpoint=endpoint,
            detail={"remote_addr": remote_addr},
        )
        raise HTTPException(status_code=401, detail="Invalid or revoked token.")

    # Enforce token scopes if required
    if required_scopes:
        _require_scope(token_row, *required_scopes, endpoint=endpoint)

    _enforce_request_budget(request, token_row["agent_name"], token_row.get("trust_tier", 1))
    session = db.touch_remote_session(token)
    if not session:
        _record_security_event(
            "auth_failure",
            "missing_session",
            actor_agent=token_row["agent_name"],
            endpoint=endpoint,
            detail={"remote_addr": request.client.host if request.client else None},
        )
        raise HTTPException(status_code=409, detail="No active remote session. Reconnect with /connect.")

    if return_token:
        return token_row["agent_name"], session, token
    return token_row["agent_name"], session


def _parse_token_scopes(token_row: dict) -> list[str]:
    """Extract scopes from a token row, handling legacy tokens without scopes."""
    raw = token_row.get("scopes")
    if raw is None:
        return ["*"]
    if isinstance(raw, list):
        return raw
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, list) else ["*"]
        except (json.JSONDecodeError, TypeError):
            return ["*"]
    return ["*"]


def _require_scope(
    token_row: dict,
    *required_scopes: str,
    endpoint: str = "unknown",
) -> None:
    """Check that the token has at least one of the required scopes.

    Supports wildcards: token scope "messages:*" covers "messages:send".
    Token scope "*" grants unrestricted access (backward compat).

    Raises HTTPException(403) if the token lacks all required scopes.
    """
    token_scopes = _parse_token_scopes(token_row)

    # Full-access shortcut
    if "*" in token_scopes:
        return

    for scope in required_scopes:
        if scope in token_scopes:
            return
        # Check wildcard: "messages:*" covers "messages:send"
        resource = scope.split(":")[0]
        if f"{resource}:*" in token_scopes:
            return
        # Check admin wildcard: "admin:*" covers everything
        if "admin:*" in token_scopes:
            return

    _record_security_event(
        "scope_violation",
        "insufficient_scope",
        actor_agent=token_row.get("agent_name"),
        endpoint=endpoint,
        detail={
            "required": list(required_scopes),
            "token_scopes": token_scopes,
            "token_id": token_row.get("token_id"),
        },
    )
    raise HTTPException(
        status_code=403,
        detail=f"Token lacks required scope. Need one of: {list(required_scopes)}. "
               f"Token has: {token_scopes}",
    )


def _require_runtime_operator(request: Request, *, endpoint: str = "unknown") -> str:
    auth_header = request.headers.get("authorization", "")
    expected = f"Bearer {_get_mcp_token()}"
    if not secrets.compare_digest(auth_header, expected):
        agent_name, _session = _require_authenticated_agent(request, endpoint=endpoint)
        if agent_name != _OPERATOR_AGENT:
            _record_security_event(
                "operator_auth_failure",
                "forbidden_agent",
                actor_agent=agent_name,
                endpoint=endpoint,
            )
            raise HTTPException(status_code=403, detail="Runtime controls are limited to the operator console.")
        return agent_name
    return "operator"


def _is_loopback_request(request: Request) -> bool:
    host = request.client.host if request.client else ""
    return host in {"127.0.0.1", "::1", "localhost", "testclient"}


def _authorize_local_dev_sender(request: Request, payload: dict, *, endpoint: str) -> str | None:
    # Standalone installs intentionally allow same-machine operator tooling to
    # inject messages with the local MCP token. Hosted/production deployments
    # must continue to require a real remote session token instead.
    if _is_production:
        return None
    if not _is_loopback_request(request):
        return None

    auth_header = request.headers.get("authorization", "")
    expected = f"Bearer {_get_mcp_token()}"
    if not secrets.compare_digest(auth_header, expected):
        return None

    sender = (
        payload.get("sender")
        or payload.get("from_agent")
        or payload.get("from")
        or payload.get("agent_name")
        or ""
    ).strip()
    if not sender:
        raise HTTPException(status_code=400, detail="Missing sender.")

    error = validate_remote_callsign(sender)
    if error:
        raise HTTPException(status_code=400, detail=error)

    if not _server_client.registry.get_agent_by_callsign(sender):
        _server_client.registry.register(sender, agent_type="cli")

    _record_security_event(
        "local_dev_send_auth",
        "success",
        actor_agent=sender,
        endpoint=endpoint,
        detail={"remote_addr": request.client.host if request.client else None},
    )
    return sender


def _authorize_local_dev_agent_action(
    request: Request,
    *,
    endpoint: str,
    agent_name: str | None = None,
) -> str | None:
    # Standalone installs also allow same-machine operator tooling to perform
    # agent-scoped actions with the local MCP token when no sidecar token exists.
    if _is_production:
        return None
    if not _is_loopback_request(request):
        return None

    token = _extract_request_token(request)
    expected = _get_mcp_token()
    if not token or not secrets.compare_digest(token, expected):
        return None

    actor = (agent_name or "").strip()
    if not actor:
        raise HTTPException(status_code=400, detail="Missing agent_name.")

    error = validate_remote_callsign(actor)
    if error:
        raise HTTPException(status_code=400, detail=error)

    if not _server_client.registry.get_agent_by_callsign(actor):
        raise HTTPException(status_code=404, detail=f"Agent '{actor}' not found.")

    _record_security_event(
        "local_dev_action_auth",
        "success",
        actor_agent=actor,
        endpoint=endpoint,
        detail={
            "mode": "loopback_mcp_token",
            "remote_addr": request.client.host if request.client else None,
        },
    )
    return actor


def _authorize_local_dev_agent_view(
    request: Request,
    *,
    endpoint: str,
    agent_name: str | None = None,
    allow_query_token: bool = False,
) -> tuple[str, dict | None] | None:
    # Standalone installs also allow same-machine operator tooling to inspect
    # an agent's inbox or live stream with the local MCP token when no
    # separate sidecar token exists yet.
    if _is_production:
        return None
    if not _is_loopback_request(request):
        return None

    token = _extract_request_token(request, allow_query_token=allow_query_token)
    expected = _get_mcp_token()
    if not token or not secrets.compare_digest(token, expected):
        return None

    target_agent = (agent_name or request.query_params.get("agent_name") or "").strip()
    if not target_agent:
        raise HTTPException(status_code=400, detail="Missing agent_name.")

    error = validate_remote_callsign(target_agent)
    if error:
        raise HTTPException(status_code=400, detail=error)

    if not _server_client.registry.get_agent_by_callsign(target_agent):
        raise HTTPException(status_code=404, detail=f"Agent '{target_agent}' not found.")

    session = None
    with contextlib.suppress(Exception):
        with db.get_connection() as conn:
            row = conn.execute(
                """
                SELECT session_id, session_kind, created_at, lease_expires_at
                FROM agent_sessions
                WHERE agent_name = ?
                ORDER BY session_last_seen DESC, created_at DESC
                LIMIT 1
                """,
                (target_agent,),
            ).fetchone()
            if row:
                session = dict(row)

    _record_security_event(
        "local_operator_view",
        "success",
        actor_agent="operator",
        target_agent=target_agent,
        endpoint=endpoint,
        detail={"mode": "loopback_mcp_token"},
    )
    _enforce_request_budget(request, target_agent)
    return target_agent, session


def _parse_jsonish_list(value):
    if value is None or value == "":
        return None
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        except Exception:
            return [item for item in value.split(",") if item]
    return None


def _inline_payload_bytes(payload: dict) -> int:
    content = {
        "subject": payload.get("subject"),
        "body": payload.get("body"),
        "payload": payload.get("payload"),
        "metadata": payload.get("metadata"),
    }
    return len(json.dumps(content, sort_keys=True, default=str).encode("utf-8"))


def _queue_limit_snapshot() -> dict:
    return {
        "max_queued_recipients_global": _MAX_QUEUED_RECIPIENTS_GLOBAL,
        "max_queued_recipients_per_recipient": _MAX_QUEUED_RECIPIENTS_PER_RECIPIENT,
    }


def _message_record_to_stream_payload(message: dict, *, recipient_agent: str | None = None) -> dict:
    if recipient_agent:
        message, _ = sanitize_message_record_for_workspace_recipient(
            db,
            message,
            recipient_agent,
        )
    payload = {
        "id": message.get("uuid"),
        "sender": message.get("from_agent"),
        "recipient": message.get("to_agent"),
        "subject": message.get("subject"),
        "body": message.get("body"),
        "priority": message.get("priority"),
        "msg_type": message.get("msg_type"),
        "content_type": message.get("content_type"),
        "context_id": message.get("context_id"),
        "reply_to": message.get("reply_to"),
        "trace_id": message.get("trace_id"),
        "ttl_seconds": message.get("ttl_seconds"),
        "idempotency_key": message.get("idempotency_key"),
        "created_at": message.get("created_at"),
        "delivery_status": message.get("delivery_status"),
        "claimed_at": message.get("claimed_at"),
        "read_at": message.get("read_at"),
        "ack_state": message.get("ack_state"),
        "ack_detail": message.get("ack_detail"),
        "acked_by": message.get("acked_by"),
        "acked_at": message.get("acked_at"),
    }
    raw_payload = message.get("payload")
    raw_metadata = message.get("metadata")
    if raw_payload:
        with contextlib.suppress(Exception):
            payload["payload"] = json.loads(raw_payload) if isinstance(raw_payload, str) else raw_payload
    if raw_metadata:
        with contextlib.suppress(Exception):
            payload["metadata"] = json.loads(raw_metadata) if isinstance(raw_metadata, str) else raw_metadata
    return hydrate_policy_fields(payload)


def _enforce_send_budget(agent_name: str, payload: dict) -> None:
    attempted = _inline_payload_bytes(payload)
    if attempted > _MAX_INLINE_PAYLOAD:
        raise HTTPException(
            status_code=413,
            detail={
                "error": "payload_too_large",
                "limit_type": "max_inline_payload",
                "scope": "request",
                "subject": agent_name,
                "attempted": attempted,
                "limit": _MAX_INLINE_PAYLOAD,
                "message": f"Inline payload exceeds the max payload of {_MAX_INLINE_PAYLOAD} bytes.",
            },
        )

    _network_budget_limiter.reserve_bytes(
        "per_agent",
        agent_name,
        attempted,
        _BYTE_BUDGET_PER_MIN,
        "byte_budget_per_min",
    )


def _policy_bundle(agent_name: str) -> dict:
    runtime_snapshot = runtime_settings.snapshot()
    allowed_priorities = ["routine", "priority", "flash"]
    if _server_client.registry.can_send_system(agent_name):
        allowed_priorities.append("system")
    return {
        "protocol_version": _REMOTE_PROTOCOL_VERSION,
        "runtime_profile": runtime_snapshot["runtime_profile"],
        "remote_admission_mode": runtime_snapshot["remote_admission_mode"],
        "observability_mode": runtime_snapshot["observability_mode"],
        "existing_callsign_policy": _existing_callsign_policy(),
        "key_bound_existing_callsigns_require_token": True,
        "allowed_priorities": allowed_priorities,
        "max_inline_payload": _MAX_INLINE_PAYLOAD,
        "byte_budget_per_min": _BYTE_BUDGET_PER_MIN,
        "queue_limits": _queue_limit_snapshot(),
        "rate_limits": {
            "per_agent_requests_per_min": _PER_AGENT_REQUESTS_PER_MIN,
            "per_ip_requests_per_min": _PER_IP_REQUESTS_PER_MIN,
            "global_requests_per_min": _GLOBAL_REQUESTS_PER_MIN,
        },
    }


def _normalize_priority(value: str | None) -> str:
    priority = (value or "routine").strip().lower()
    return _PRIORITY_ALIASES.get(priority, priority)


def _capability_bundle() -> dict:
    return {
        "protocol_version": _REMOTE_PROTOCOL_VERSION,
        "features": [
            "connect",
            "lease",
            "health",
            "livez",
            "readyz",
            "send",
            "inbox",
            "outbox",
            "trace",
            "status",
            "whoami",
            "wag",
            "mode",
            "presence",
            "stream",
            "identity_key",
            "token_create",
            "token_revoke",
            "token_rotate",
            "disconnect",
        ],
        "lease_seconds": _REMOTE_LEASE_SECONDS,
    }


def _rename_allowed_agent(old_callsign: str, new_callsign: str) -> None:
    allowed_agents = list(runtime_settings.allowed_agents())
    if old_callsign not in allowed_agents or new_callsign == old_callsign:
        return
    updated = [new_callsign if agent == old_callsign else agent for agent in allowed_agents]
    runtime_settings.update(allowed_agents=updated)


def _remote_status_snapshot(agent_name: str) -> dict:
    snapshot_client = _server_side_snapshot_client(agent_name)
    status = snapshot_client.status()
    status["deployment_mode"] = "remote"
    status["deployment_source"] = "remote_http"
    status["server"] = "remote"
    status.update(runtime_settings.public_snapshot())
    status["startup"] = build_startup_briefing(status, agent_name=agent_name)
    return status


def _server_side_snapshot_client(agent_name: str) -> WhispersClient:
    # These snapshots are assembled from inside the HTTP server while already
    # handling a live request. Treat the server as reachable so remote-facing
    # status endpoints do not recurse into local self-probes or auto-start.
    return WhispersClient(
        agent_name,
        db_path=db.db_path,
        read_only=True,
        assume_http_server_reachable=True,
    )


async def _maintenance_loop(stop_event: asyncio.Event) -> None:
    _health_fail_count = 0
    while not stop_event.is_set():
        try:
            db.reap_expired_agent_sessions()
            db.reap_ghosts()
            db.expire_stale_messages()
            db.sweep_dead_agents()
            db.reap_expired_remote_sessions()
            db.reap_expired_file_leases()
            db.decay_stale_presence(max_age_seconds=_INPROGRESS_DECAY_SECONDS)
            db.unsnooze_expired()
            _refresh_runtime_observability_artifacts()
            _health_fail_count = 0  # Reset on success
        except Exception as e:
            _health_fail_count += 1
            logger.warning(
                "Background maintenance failed (count=%d): %s",
                _health_fail_count, e,
            )
            # If maintenance fails repeatedly, the DB might be locked/corrupted
            if _health_fail_count >= 5:
                logger.error(
                    "HEALTH ALERT: Maintenance has failed %d consecutive times. "
                    "DB may be locked or corrupted. Last error: %s",
                    _health_fail_count, e,
                )

        try:
            await asyncio.wait_for(stop_event.wait(), timeout=30)
        except asyncio.TimeoutError:
            continue


async def _health_scan_loop(scanner, stop_event: asyncio.Event) -> None:
    """Background loop: run collaboration health scanner every 60s, push SSE events."""
    from .collaboration_health import CollaborationHealthScanner
    interval = CollaborationHealthScanner.SCAN_INTERVAL_SECONDS
    while not stop_event.is_set():
        try:
            # Snapshot active signal IDs before scan for cleared detection
            prev_ids = set(scanner._active_signals.keys())
            changed = scanner.scan()
            current_ids = set(scanner._active_signals.keys())
            cleared_ids = prev_ids - current_ids

            for s in changed:
                operator_sse.push(OperatorEventType.HEALTH_RAISED, s.to_dict())

            for cid in cleared_ids:
                operator_sse.push(OperatorEventType.HEALTH_CLEARED, {"signal_id": cid})

            all_signals = scanner.get_active_signals()
            by_severity: dict[str, int] = {}
            for s in all_signals:
                sev = s.severity.value
                by_severity[sev] = by_severity.get(sev, 0) + 1
            operator_sse.push(OperatorEventType.HEALTH_SCAN, {
                "total": len(all_signals),
                "by_severity": by_severity,
                "healthy": len(all_signals) == 0,
            })
        except Exception:
            logger.warning("Collaboration health scan failed", exc_info=True)

        # --- Reflexive coordination engine scan ---
        try:
            if not hasattr(_health_scan_loop, "_reflex_engine"):
                from .reflexive_engine import ReflexiveCoordinationEngine

                def _on_insight(insight):
                    operator_sse.push(OperatorEventType.COORDINATION_REFLEX, insight.to_dict())
                    # On recommend stage: send re-notify message to assignee
                    if (insight.reflex == "stalled_handoff"
                            and insight.details.get("action") == "re_notify"):
                        try:
                            assignee = insight.details.get("assignee", "")
                            owner = insight.details.get("owner", "")
                            subject = insight.details.get("subject", "handoff")
                            age = insight.details.get("age_human", "")
                            escalation = insight.details.get("escalation", "routine")
                            _server_client.send(
                                to=assignee,
                                subject=f"Reminder: handoff from {owner} waiting ({age})",
                                body=f"A handoff \"{subject}\" from {owner} has been waiting "
                                     f"for your acknowledgment for {age}. "
                                     f"Please ack, decline, or defer.",
                                msg_type="heads_up",
                                priority=escalation,
                                metadata={
                                    "whispers:reminder_kind": "stalled_handoff",
                                    "whispers:baton_ref": insight.details.get("baton_ref"),
                                    "whispers:handoff_owner": owner,
                                    "whispers:handoff_subject": subject,
                                },
                            )
                        except Exception:
                            logger.warning("Re-notify dispatch failed", exc_info=True)

                def _on_resolution(resolution):
                    operator_sse.push(OperatorEventType.COORDINATION_RESOLVED, resolution.to_dict())

                _health_scan_loop._reflex_engine = ReflexiveCoordinationEngine(
                    on_insight=_on_insight,
                    on_resolution=_on_resolution,
                )

            from .reflexive_world import build_world_state
            from .repo_coordination import get_coordinator
            world = build_world_state(db, get_coordinator())
            _health_scan_loop._reflex_engine.scan(world)
        except Exception:
            logger.warning("Reflexive coordination scan failed", exc_info=True)

        try:
            await asyncio.wait_for(stop_event.wait(), timeout=interval)
        except asyncio.TimeoutError:
            continue


def _current_server_health_snapshot() -> dict:
    """Return the current diagnostic state for the server process."""
    db_write_ready, db_error = db.check_write_ready(timeout_ms=_HEALTH_DB_WRITE_READY_TIMEOUT_MS)
    wal_mode = db.check_wal_mode()

    health_checks = {
        "db_write_ready": db_write_ready,
        "wal_mode": wal_mode,
    }
    health_failing = [k for k, v in health_checks.items() if not v]
    health_hints: list[str] = []

    if db_write_ready and wal_mode:
        server_state = "up"
        server_state_detail = "All systems operational."
    else:
        server_state = "degraded"
        if not db_write_ready:
            server_state_detail = f"Database not write-ready: {db_error or 'unknown error'}"
            health_hints.append("Check for DB lock contention or disk full condition.")
            health_hints.append("Run 'whispers doctor --fix' to attempt repair.")
        else:
            server_state_detail = "WAL mode is not enabled on the database."
            health_hints.append("Run 'whispers doctor --fix' to enable WAL mode.")

    return {
        "server_state": server_state,
        "server_state_detail": server_state_detail,
        "server_diagnostics": {
            "checks": health_checks,
            "failing_checks": health_failing,
            "hints": health_hints,
        },
    }


def _refresh_runtime_observability_artifacts() -> None:
    """Update persisted diagnostic artifacts off the request path.

    /health should surface recent artifacts, not generate them every poll.
    """
    try:
        state = _load_runtime_state()
        state_dirty = False

        health_snapshot = _current_server_health_snapshot()
        current_server_state = health_snapshot["server_state"]
        current_server_detail = health_snapshot["server_state_detail"]
        previous_server_state = state.get("last_server_state")
        previous_server_detail = state.get("last_server_state_detail")

        if (
            current_server_state != previous_server_state
            or current_server_detail != previous_server_detail
        ):
            recovery_events = state.get("recovery_events")
            if not isinstance(recovery_events, list):
                recovery_events = []

            if current_server_state == "degraded":
                recovery_events.append({
                    "type": "state_degraded",
                    "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "detail": f"Background health detected degraded state: {current_server_detail}",
                    "severity": "warning",
                })
            elif current_server_state == "up" and previous_server_state == "degraded":
                recovery_events.append({
                    "type": "state_up_restored",
                    "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "detail": "Background health confirms server is up. All checks passing.",
                    "severity": "info",
                })

            _HEALTH_EVENT_CAP = 50
            if len(recovery_events) > _HEALTH_EVENT_CAP:
                recovery_events = recovery_events[-_HEALTH_EVENT_CAP:]
            state["recovery_events"] = recovery_events
            state["last_server_state"] = current_server_state
            state["last_server_state_detail"] = current_server_detail
            state_dirty = True

        current_agent_snapshots = _get_all_agent_snapshots()
        previous_agent_snapshots = state.get("last_agent_snapshots", {})

        if current_agent_snapshots != previous_agent_snapshots:
            agent_events = state.get("agent_events")
            if not isinstance(agent_events, list):
                agent_events = []

            for agent, curr in current_agent_snapshots.items():
                prev = previous_agent_snapshots.get(agent)
                if prev is None:
                    continue

                if curr["active_mode"] != prev["active_mode"]:
                    agent_events.append({
                        "type": "active_mode_changed",
                        "agent_name": agent,
                        "detail": f"Active mode transitioned from '{prev['active_mode']}' to '{curr['active_mode']}'.",
                        "severity": "info",
                        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    })
                if curr["readiness"] != prev["readiness"]:
                    agent_events.append({
                        "type": "readiness_changed",
                        "agent_name": agent,
                        "detail": f"Readiness transitioned from '{prev['readiness']}' to '{curr['readiness']}'.",
                        "severity": "info",
                        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    })

                prev_focus = prev["focus"] or "idle"
                curr_focus = curr["focus"] or "idle"
                if prev_focus != curr_focus:
                    agent_events.append({
                        "type": "working_on_changed",
                        "agent_name": agent,
                        "detail": f"Work focus changed from '{prev_focus}' to '{curr_focus}'.",
                        "severity": "info",
                        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    })
                if curr.get("attention_state") != prev.get("attention_state"):
                    attention_from = prev.get("attention_state") or "none"
                    attention_to = curr.get("attention_state") or "none"
                    detail = f"Attention state changed from '{attention_from}' to '{attention_to}'."
                    if curr.get("attention_detail"):
                        detail = f"{detail} {curr['attention_detail']}"
                    agent_events.append({
                        "type": "attention_changed",
                        "agent_name": agent,
                        "detail": detail,
                        "severity": "warning" if attention_to in {"waiting_on_operator", "waiting_on_peer", "blocked_external", "needs_assignment"} else "info",
                        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    })

            _AGENT_EVENT_CAP = 100
            if len(agent_events) > _AGENT_EVENT_CAP:
                agent_events = agent_events[-_AGENT_EVENT_CAP:]
            state["agent_events"] = agent_events
            state["last_agent_snapshots"] = current_agent_snapshots
            state_dirty = True

        if state_dirty:
            _write_runtime_state(state)
    except Exception:
        pass


def on_startup(callback):
    """Register a callback to run when the Whispers server starts.

    Callbacks receive a single dict argument — the same payload as
    ``WhispersClient.status()``.  This is the product-level hook for
    any host system (brain, dashboard, monitoring) to learn that
    Whispers has come online.

    Example::

        from whispers.server import on_startup

        def notify_dashboard(status):
            requests.post("http://dashboard/api/whispers", json=status)

        on_startup(notify_dashboard)
    """
    _startup_callbacks.append(callback)
    return callback


@contextlib.asynccontextmanager
async def _lifespan(app):
    """Manage MCP session manager and startup hooks."""

    _ensure_server_runtime()
    async with _session_manager.run():
        stop_event = asyncio.Event()
        maintenance_task = asyncio.create_task(_maintenance_loop(stop_event))

        # Collaboration health scanner
        from .collaboration_health import CollaborationHealthScanner
        health_scanner = CollaborationHealthScanner(db)
        app.state.health_scanner = health_scanner
        dispatcher._health_scanner = health_scanner
        health_scan_task = asyncio.create_task(
            _health_scan_loop(health_scanner, stop_event)
        )

        # Fire startup hooks
        status = _server_snapshot_client.status()
        status["deployment_mode"] = "standalone"
        token = _get_mcp_token()
        crash_state = _load_crash_state()
        logger.info(
            "Whispers server started — pid=%d, mode=%s, registered=%d, pending=%d, "
            "mcp_tools=%d, token=%s..., total_crashes=%d",
            os.getpid(),
            status["my_mode"],
            status["agents_registered"],
            status["pending_messages"],
            len(MCP_TOOLS),
            token[:8],
            crash_state.get("total_crashes", 0),
        )
        for cb in _startup_callbacks:
            try:
                cb(status)
            except Exception as e:
                logger.warning("Startup callback failed: %s", e)
        try:
            yield
        finally:
            logger.info("Whispers server shutting down gracefully (pid=%d)...", os.getpid())
            # Stop the maintenance loop and health scanner
            stop_event.set()
            maintenance_task.cancel()
            health_scan_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await maintenance_task
            with contextlib.suppress(asyncio.CancelledError):
                await health_scan_task
            # Drain SSE connections
            try:
                sse.shutdown()
            except Exception as e:
                logger.warning("SSE shutdown error: %s", e)
            logger.info("Whispers server shutdown complete.")


_is_production = bool(os.getenv("WHISPERS_PUBLIC_URL") or os.getenv("RAILWAY_ENVIRONMENT"))
app = FastAPI(
    title="Whispers Server",
    version="1.0.0",
    lifespan=_lifespan,
    docs_url=None if _is_production else "/docs",
    redoc_url=None if _is_production else "/redoc",
)

UI_DIR = os.path.join(os.path.dirname(__file__), "ui")
if os.path.exists(UI_DIR):
    app.mount("/ui", StaticFiles(directory=UI_DIR, html=True), name="ui")

# Cache landing page at module load — it's static content, no reason to hit disk per request
LANDING_DIR = os.path.join(os.path.dirname(__file__), "landing")
_LANDING_HTML_CACHE: str | None = None
_landing_html_path = os.path.join(LANDING_DIR, "index.html")
if os.path.exists(_landing_html_path):
    with open(_landing_html_path, "r", encoding="utf-8") as _f:
        _LANDING_HTML_CACHE = _f.read()


@app.get("/")
def landing_page():
    """Serve the whispers.works landing page."""
    if _LANDING_HTML_CACHE:
        from starlette.responses import HTMLResponse
        return HTMLResponse(content=_LANDING_HTML_CACHE)
    return {"service": "whispers", "docs": "/health"}


# ---------------------------------------------------------------------------
# A2A Protocol Surface
# ---------------------------------------------------------------------------

def _get_server_url() -> str:
    """Resolve the public server URL for A2A Agent Cards."""
    # Explicit override
    explicit = os.environ.get("WHISPERS_PUBLIC_URL", "").strip()
    if explicit:
        return explicit.rstrip("/")
    # Railway auto-detection
    railway_domain = os.environ.get("RAILWAY_PUBLIC_DOMAIN", "").strip()
    if railway_domain:
        return f"https://{railway_domain}"
    # Local fallback
    return "http://127.0.0.1:8752"


_a2a_router = create_a2a_router(
    db=db,
    registry=_server_registry,
    dispatcher=dispatcher,
    server_url_fn=_get_server_url,
)
app.include_router(_a2a_router)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/health")
def health():
    """Health/status endpoint — returns the canonical Whispers status payload.

    Any monitoring system, load balancer, or consumer can poll this to know
    whether Whispers is alive and what state it's in.
    """
    status = _server_snapshot_client.status(ephemeral_state=_EPHEMERAL_STATE)
    status["deployment_mode"] = "standalone"
    status["mcp_tools"] = len(MCP_TOOLS)
    status["mcp_transport"] = "streamable_http"
    status.update(runtime_settings.public_snapshot())
    status.update(_system_metrics())

    status.update(_current_server_health_snapshot())

    # Recovery timeline: sourced from runtime-state.json (written by CLI during doctor --fix).
    # The server surfaces what the CLI recorded so the Console gets a unified view.
    persisted = _load_runtime_state()
    raw_timeline = persisted.get("recovery_timeline") or {}
    status["recovery_timeline"] = {
        "last_auto_start_attempt": raw_timeline.get("last_auto_start_attempt"),
        "last_successful_recovery_at": raw_timeline.get("last_successful_recovery_at"),
        # auto_started: True if the server was brought up via the CLI auto-start mechanism.
        # Derived from whether a successful recovery timestamp exists.
        "auto_started": bool(raw_timeline.get("last_successful_recovery_at")),
    }

    # Events: surface bounded recent history that background maintenance already recorded.
    raw_events = persisted.get("recovery_events")
    status["recovery_events"] = raw_events if isinstance(raw_events, list) else []

    raw_agent_events = persisted.get("agent_events")
    status["agent_events"] = raw_agent_events if isinstance(raw_agent_events, list) else []

    raw_message_events = persisted.get("message_events")
    status["message_events"] = raw_message_events if isinstance(raw_message_events, list) else []

    status["security_events"] = db.get_recent_security_events(limit=20)

    return status



@app.get("/livez")
def livez():
    return {"ok": True, "service": "whispers", "deployment_mode": "standalone"}


@app.get("/readyz")
def readyz():
    ready = True
    db_write_ready, readiness_error = db.check_write_ready(timeout_ms=_HEALTH_DB_WRITE_READY_TIMEOUT_MS)
    detail = {
        "db_path": db.db_path,
        "schema_version": db.get_schema_version(),
        "wal_mode": db.check_wal_mode(),
        "db_write_ready": db_write_ready,
        **_queue_limit_snapshot(),
    }
    if readiness_error:
        detail["readiness_error"] = readiness_error
    if not detail["wal_mode"] or not db_write_ready:
        ready = False
    return JSONResponse(status_code=200 if ready else 503, content={"ok": ready, **detail})


@app.get("/health/collaboration")
def collaboration_health(request: Request):
    """Collaboration health signals — surfaces dysfunction patterns detected from existing substrate."""
    _require_authenticated_agent(request, endpoint="/health/collaboration")
    scanner = getattr(app.state, "health_scanner", None)
    if scanner is None:
        return {"signals": [], "summary": {"total": 0, "by_severity": {}, "healthy": True}}
    signals = scanner.get_active_signals()
    by_severity: dict[str, int] = {}
    for s in signals:
        sev = s.severity.value if hasattr(s.severity, "value") else str(s.severity)
        by_severity[sev] = by_severity.get(sev, 0) + 1
    return {
        "signals": [s.to_dict() for s in signals],
        "summary": {
            "total": len(signals),
            "by_severity": by_severity,
            "healthy": len(signals) == 0,
        },
    }


@app.get("/runtime")
def runtime_status(request: Request):
    _require_runtime_operator(request, endpoint="/runtime")
    return runtime_settings.snapshot()


@app.post("/runtime")
def runtime_update(payload: dict, request: Request):
    actor = _require_runtime_operator(request, endpoint="/runtime")
    try:
        snapshot = runtime_settings.update(
            profile=payload.get("profile"),
            admission=payload.get("admission"),
            observability_mode=payload.get("observability_mode") or payload.get("privacy_mode"),
            allowed_agents=payload.get("allowed_agents") or payload.get("allow_agents"),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    _record_security_event(
        "runtime_settings_update",
        "success",
        actor_agent=actor,
        endpoint="/runtime",
        detail=snapshot,
    )
    return snapshot


@app.get("/handle/{callsign}")
def handle_status(callsign: str):
    return _callsign_state(callsign)


@app.post("/connect")
def connect_agent(payload: dict, request: Request):
    """Create or resume a remote session and return connection policy."""
    agent_name = (payload.get("agent_name") or "").strip()
    if not agent_name:
        raise HTTPException(status_code=400, detail="Missing agent_name")

    error = validate_remote_callsign(agent_name)
    if error:
        raise HTTPException(status_code=400, detail=error)

    _enforce_request_budget(request, agent_name)
    supplied_token = payload.get("token")
    client_info = payload.get("client") or {}
    capabilities = payload.get("capabilities") or {}
    session_kind = (payload.get("session_kind") or "remote_http").strip() or "remote_http"
    agent_type = payload.get("agent_type") or "remote_client"
    agent_tier = payload.get("agent_tier") or "full"
    max_receive_rate = payload.get("max_receive_rate")

    if session_kind not in _ALLOWED_REMOTE_SESSION_KINDS:
        raise HTTPException(status_code=400, detail=f"Unsupported session_kind: {session_kind}")

    existing = _server_client.registry.get_agent_by_callsign(agent_name)
    token_status = "reused"
    if supplied_token:
        token_row = db.get_api_token(supplied_token)
        if not token_row:
            _record_security_event(
                "connect",
                "invalid_token",
                target_agent=agent_name,
                endpoint="/connect",
                detail={"remote_addr": request.client.host if request.client else None},
            )
            raise HTTPException(status_code=401, detail="Invalid or revoked token.")
        if token_row["agent_name"] != agent_name:
            _record_security_event(
                "connect",
                "token_agent_mismatch",
                actor_agent=token_row["agent_name"],
                target_agent=agent_name,
                endpoint="/connect",
            )
            raise HTTPException(status_code=403, detail="Token does not belong to the requested agent.")
        if existing is None:
            _server_client.registry.register(
                agent_name,
                agent_type=agent_type,
                model_id=client_info.get("version"),
                display_name=payload.get("display_name"),
                agent_tier=agent_tier,
                max_receive_rate=max_receive_rate,
            )
    else:
        if existing is None and not _admission_allowed(agent_name):
            _record_security_event(
                "connect",
                "admission_denied",
                target_agent=agent_name,
                endpoint="/connect",
                detail={
                    "remote_addr": request.client.host if request.client else None,
                    "admission_mode": runtime_settings.admission_mode(),
                },
            )
            raise HTTPException(
                status_code=403,
                detail=(
                    "Trusted-team admission required. "
                    "Ask an operator to allowlist this agent or reconnect with an existing token."
                ),
            )
        if existing is not None:
            callsign_state = _callsign_state(agent_name)
            if callsign_state["active"]:
                # Allow force-reconnect for browser/dashboard clients that lost
                # their token.  Only permitted when admission mode is open.
                force = payload.get("force", False)
                if force and runtime_settings.admission_mode() == "open":
                    # Expire all existing remote sessions so the new connect
                    # can proceed cleanly.
                    with db._db_op("Force-reclaim active sessions") as conn:
                        conn.execute(
                            "DELETE FROM agent_sessions WHERE agent_name = ? AND token_id IS NOT NULL",
                            (agent_name,),
                        )
                        conn.commit()
                        db._sync_presence_from_sessions(conn, agent_name)
                    _record_security_event(
                        "connect",
                        "force_reclaim",
                        target_agent=agent_name,
                        endpoint="/connect",
                        detail={"remote_addr": request.client.host if request.client else None},
                    )
                else:
                    _record_security_event(
                        "connect",
                        "callsign_active_conflict",
                        target_agent=agent_name,
                        endpoint="/connect",
                    )
                    raise HTTPException(
                        status_code=409,
                        detail="Callsign is already active. Reconnect with the existing token or choose a different name.",
                    )
            if callsign_state["existing_callsign_policy"] != "reclaim_offline_allowed":
                outcome = "existing_callsign_requires_token"
                if callsign_state.get("public_key_bound"):
                    outcome = "existing_callsign_key_bound"
                _record_security_event(
                    "connect",
                    outcome,
                    target_agent=agent_name,
                    endpoint="/connect",
                )
                raise HTTPException(
                    status_code=409,
                    detail="Callsign already claimed. Reconnect with the existing token or choose a different name.",
                )
            _server_client.registry.register(
                agent_name,
                agent_type=agent_type,
                model_id=client_info.get("version"),
                display_name=payload.get("display_name"),
                agent_tier=agent_tier,
                max_receive_rate=max_receive_rate,
            )
            supplied_token = db.issue_api_token(agent_name, description="remote_reclaim")
            token_status = "reclaimed"
        else:
            _server_client.registry.register(
                agent_name,
                agent_type=agent_type,
                model_id=client_info.get("version"),
                display_name=payload.get("display_name"),
                agent_tier=agent_tier,
                max_receive_rate=max_receive_rate,
            )
            supplied_token = db.issue_api_token(agent_name, description="remote_connect")
            token_status = "created"

    session = db.create_remote_session(
        agent_name,
        supplied_token,
        session_kind=session_kind,
        client_name=client_info.get("name"),
        client_version=client_info.get("version"),
        capabilities=capabilities,
        lease_seconds=_REMOTE_LEASE_SECONDS,
        remote_addr=request.client.host if request.client else None,
    )
    db.mark_agent_online(agent_name, session["session_id"])
    _record_security_event(
        "connect",
        "success",
        actor_agent=agent_name,
        endpoint="/connect",
        detail={"token_status": token_status},
    )
    startup_status = _remote_status_snapshot(agent_name)

    return {
        "server": str(request.base_url).rstrip("/"),
        "agent_name": agent_name,
        "token": supplied_token,
        "token_status": token_status,
        "session": {
            "session_id": session["session_id"],
            "session_kind": session["session_kind"],
            "lease_expires_at": session["lease_expires_at"],
            "lease_seconds": _REMOTE_LEASE_SECONDS,
        },
        "capabilities": _capability_bundle(),
        "policy": _policy_bundle(agent_name),
        "status": startup_status,
        "startup": startup_status["startup"],
    }


@app.post("/lease")
def renew_lease(payload: dict, request: Request):
    """Renew a remote session lease and refresh presence."""
    session_id = (payload.get("session_id") or "").strip()
    if not session_id:
        raise HTTPException(status_code=400, detail="Missing session_id")

    token = _extract_request_token(request) or payload.get("token")
    if not token:
        _record_security_event("lease", "missing_token", endpoint="/lease")
        raise HTTPException(status_code=401, detail="Missing bearer token.")

    token_row = db.get_api_token(token)
    if not token_row:
        _record_security_event("lease", "invalid_or_revoked_token", endpoint="/lease")
        raise HTTPException(status_code=401, detail="Invalid or revoked token.")

    _enforce_request_budget(request, token_row["agent_name"])
    session = db.renew_remote_session(token, session_id, lease_seconds=_REMOTE_LEASE_SECONDS)
    if not session:
        raise HTTPException(status_code=404, detail="Remote session not found.")

    db.mark_agent_online(token_row["agent_name"], session_id)
    return {
        "agent_name": token_row["agent_name"],
        "session": {
            "session_id": session["session_id"],
            "lease_expires_at": session["lease_expires_at"],
            "lease_seconds": _REMOTE_LEASE_SECONDS,
        },
        "policy": _policy_bundle(token_row["agent_name"]),
    }


@app.post("/token:create")
def token_create(request: Request, payload: dict):
    agent_name, _session = _require_authenticated_agent(request, endpoint="/token:create", required_scopes=("tokens:manage",))
    description = (payload.get("description") or "remote_token").strip()
    scopes = payload.get("scopes")
    profile = payload.get("profile")
    raw_token = db.issue_api_token(agent_name, description=description, scopes=scopes, profile=profile)
    token_row = db.get_api_token(raw_token) or {}
    _record_security_event(
        "token_create",
        "success",
        actor_agent=agent_name,
        target_agent=agent_name,
        endpoint="/token:create",
        detail={"description": description, "token_id": token_row.get("token_id")},
    )
    return {
        "agent_name": agent_name,
        "token": raw_token,
        "token_id": token_row.get("token_id"),
        "description": description,
    }


@app.post("/token:revoke")
def token_revoke(request: Request, payload: dict):
    agent_name, session, current_token = _require_authenticated_agent(
        request,
        endpoint="/token:revoke",
        return_token=True,
        required_scopes=("tokens:manage",),
    )
    target_token = (payload.get("token") or current_token).strip()
    target_row = db.get_api_token_any(target_token)
    if not target_row:
        raise HTTPException(status_code=404, detail="Token not found.")
    if target_row["agent_name"] != agent_name:
        _record_security_event(
            "token_revoke",
            "forbidden",
            actor_agent=agent_name,
            target_agent=target_row["agent_name"],
            endpoint="/token:revoke",
        )
        raise HTTPException(status_code=403, detail="Cannot revoke another agent's token.")

    db.revoke_api_token(target_token)
    _record_security_event(
        "token_revoke",
        "success",
        actor_agent=agent_name,
        target_agent=agent_name,
        endpoint="/token:revoke",
        detail={"token_id": target_row["token_id"], "session_id": session["session_id"]},
    )
    return {"ok": True, "token_id": target_row["token_id"]}


@app.post("/token:rotate")
def token_rotate(request: Request, payload: dict):
    agent_name, session, current_token = _require_authenticated_agent(
        request,
        endpoint="/token:rotate",
        return_token=True,
        required_scopes=("tokens:manage",),
    )
    description = (payload.get("description") or "rotated_remote_token").strip()
    # Preserve scopes from the original token (or allow override)
    old_token_row = db.get_api_token_any(current_token)
    inherited_scopes = _parse_token_scopes(old_token_row) if old_token_row else None
    new_scopes = payload.get("scopes") or inherited_scopes
    new_token = db.issue_api_token(agent_name, description=description, scopes=new_scopes)
    capabilities = session.get("capabilities")
    if isinstance(capabilities, str):
        with contextlib.suppress(Exception):
            capabilities = json.loads(capabilities)
    new_session = db.create_remote_session(
        agent_name,
        new_token,
        client_name=session.get("client_name"),
        client_version=session.get("client_version"),
        capabilities=capabilities if isinstance(capabilities, dict) else {},
        lease_seconds=_REMOTE_LEASE_SECONDS,
        remote_addr=request.client.host if request.client else None,
    )
    db.revoke_api_token(current_token)
    db.mark_agent_online(agent_name, new_session["session_id"])
    new_token_row = db.get_api_token(new_token) or {}
    _record_security_event(
        "token_rotate",
        "success",
        actor_agent=agent_name,
        target_agent=agent_name,
        endpoint="/token:rotate",
        detail={"token_id": new_token_row.get("token_id")},
    )
    return {
        "agent_name": agent_name,
        "token": new_token,
        "token_id": new_token_row.get("token_id"),
        "session": {
            "session_id": new_session["session_id"],
            "lease_expires_at": new_session["lease_expires_at"],
            "lease_seconds": _REMOTE_LEASE_SECONDS,
        },
    }


@app.post("/disconnect")
def disconnect(request: Request):
    agent_name, session, token = _require_authenticated_agent(
        request,
        endpoint="/disconnect",
        return_token=True,
    )
    disconnected = db.disconnect_remote_session(token, session_id=session["session_id"])
    # Narrator goes degraded on disconnect — designation persists, narration pauses
    # Only `whispers narrator clear` fully removes the designation
    if runtime_settings.narrator_agent() == agent_name:
        logger.info("[Whispers] Narrator degraded: %s disconnected (designation preserved)", agent_name)
    _record_security_event(
        "disconnect",
        "success",
        actor_agent=agent_name,
        target_agent=agent_name,
        endpoint="/disconnect",
        detail={"session_id": session["session_id"], "disconnected": disconnected},
    )
    return {"ok": True, "disconnected": disconnected}


# ---------------------------------------------------------------------------
# Narrative endpoints (Narrator Agent Contract Slice 3)
# ---------------------------------------------------------------------------

_VALID_STANCES = {
    "summary", "warning", "hypothesis", "recap", "pattern",
    "challenge", "annotation", "revision",
}

# Synthesis stances require narrator designation; collaborative stances are open to all
_NARRATOR_ONLY_STANCES = {"summary", "warning", "hypothesis", "recap", "pattern"}

_VALID_RETENTION_CLASSES = {"recap", "postmortem", "incident", "handoff_summary"}


@app.post("/narrative")
def publish_narrative(payload: dict, request: Request):
    """Publish a narrative event.

    Synthesis stances (summary, warning, hypothesis, recap, pattern)
    require the caller to be the designated narrator agent.
    Collaborative stances (challenge, annotation, revision) are open
    to any registered agent.
    """
    agent_name, _ = _require_authenticated_agent(request, endpoint="/narrative")

    stance = (payload.get("stance") or "").strip().lower()
    if stance not in _VALID_STANCES:
        raise HTTPException(status_code=400, detail=f"Invalid stance. Must be one of: {', '.join(sorted(_VALID_STANCES))}")

    # Gate synthesis stances to the designated narrator
    if stance in _NARRATOR_ONLY_STANCES:
        designated = runtime_settings.narrator_agent()
        if not designated:
            raise HTTPException(status_code=403, detail="No narrator designated. Set one with `whispers narrator set <callsign>`.")
        if agent_name != designated:
            raise HTTPException(status_code=403, detail=f"Synthesis stances require narrator designation. Current narrator: {designated}")

    narrative_text = (payload.get("narrative_text") or "").strip()
    if not narrative_text:
        raise HTTPException(status_code=400, detail="narrative_text is required.")

    # Validate and cast inputs at the boundary
    try:
        ttl_hours = int(payload.get("ttl_hours", 24))
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail="ttl_hours must be an integer.")
    if ttl_hours < 0 or ttl_hours > 8760:
        raise HTTPException(status_code=400, detail="ttl_hours must be between 0 and 8760 (1 year).")

    signal_refs = payload.get("signal_refs")
    if signal_refs is not None and not isinstance(signal_refs, list):
        raise HTTPException(status_code=400, detail="signal_refs must be a list.")

    continuity = (payload.get("continuity") or "live").strip().lower()
    if continuity not in ("live", "reconstructed", "partial"):
        raise HTTPException(status_code=400, detail="continuity must be one of: live, reconstructed, partial")

    narrative = {
        "narrator_agent": agent_name,
        "stance": stance,
        "narrative_text": narrative_text,
        "signal_refs": signal_refs,
        "narrative_thread": payload.get("narrative_thread"),
        "scope": payload.get("scope"),
        "continuity": continuity,
        "ttl_hours": ttl_hours,
        "challengeable": payload.get("challengeable", True),
        "supersedes": payload.get("supersedes"),
        "workspace_id": payload.get("workspace_id"),
    }

    result = db.store_narrative(narrative)
    narrative_id = result["narrative_id"]

    # Project into operator event stream
    from .transports.operator import OperatorEventType
    operator_sse.push(
        OperatorEventType.NARRATIVE_EVENT,
        {
            "narrative_id": narrative_id,
            "narrator_agent": agent_name,
            "stance": stance,
            "narrative_text": narrative_text,
            "signal_refs": payload.get("signal_refs") or [],
            "continuity": narrative.get("continuity", "live"),
            "scope": narrative.get("scope"),
            "narrative_thread": narrative.get("narrative_thread"),
            "promoted": False,
            "supersedes": narrative.get("supersedes"),
        },
        source_module="narrative",
        agent=agent_name,
        workspace_id=narrative.get("workspace_id"),
    )

    # Project into workspace delta if workspace-scoped (with membership check)
    ws_id = narrative.get("workspace_id")
    if _workspace_projection_guard(
        workspace_id=ws_id,
        actor_agent=agent_name,
        endpoint="/narrative",
        outcome="workspace_narrative_projection_blocked_non_writer",
        projection_kind="narrative",
        projection_label="Narrative",
        detail={
            "narrative_id": narrative_id,
            "stance": stance,
        },
    ):
        _push_workspace_event("workspace:delta", {
            "workspace_id": ws_id,
            "delta_kind": "narrative",
            "text": narrative_text,
            "artifacts": [narrative_id],
            "refs": payload.get("signal_refs") or [],
            "state_patch": {
                "narrator_agent": agent_name,
                "stance": stance,
                "continuity": narrative.get("continuity", "live"),
            },
        })

    return {"ok": True, "narrative_id": narrative_id}


@app.post("/narrative/{narrative_id}/promote")
def promote_narrative(narrative_id: str, payload: dict, request: Request):
    """Promote a narrative to a durable artifact with extended retention."""
    _require_authenticated_agent(request, endpoint="/narrative/promote")

    retention_class = (payload.get("retention_class") or "").strip().lower()
    if retention_class not in _VALID_RETENTION_CLASSES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid retention_class. Must be one of: {', '.join(sorted(_VALID_RETENTION_CLASSES))}",
        )

    result = db.promote_narrative(narrative_id, retention_class)
    if not result:
        raise HTTPException(status_code=404, detail="Narrative not found.")
    return {"ok": True, "narrative_id": narrative_id, "retention_class": retention_class, "promoted": True}


@app.get("/narrative/{narrative_id}")
def get_narrative(narrative_id: str, request: Request):
    """Fetch a single narrative event."""
    _require_authenticated_agent(request, endpoint="/narrative")
    result = db.get_narrative_sources(narrative_id)
    if not result:
        raise HTTPException(status_code=404, detail="Narrative not found.")
    return result


@app.get("/narrative/{narrative_id}/sources")
def get_narrative_sources(narrative_id: str, request: Request):
    """Drill down from a narrative to the source signals it synthesized from."""
    _require_authenticated_agent(request, endpoint="/narrative/sources")
    result = db.get_narrative_sources(narrative_id)
    if not result:
        raise HTTPException(status_code=404, detail="Narrative not found.")
    return {
        "narrative_id": narrative_id,
        "narrator_agent": result.get("narrator_agent"),
        "stance": result.get("stance"),
        "narrative_text": result.get("narrative_text"),
        "signal_refs": result.get("signal_refs") or [],
    }


@app.get("/narratives")
def list_narratives(request: Request):
    """List narrative events with optional filtering."""
    _require_authenticated_agent(request, endpoint="/narratives")
    scope = request.query_params.get("scope")
    thread = request.query_params.get("thread")
    limit = int(request.query_params.get("limit", 20))
    narratives = db.list_narratives(scope=scope, thread=thread, limit=min(limit, 100))
    return {"narratives": narratives, "count": len(narratives)}


@app.post("/message:send")
def send_message(payload: dict, request: Request):
    """Standalone HTTP endpoint to inject a message into the routing engine."""
    # Enforce A2A v1.0 standard header
    a2a_version = request.headers.get("a2a-version")
    if a2a_version != "1.0":
        raise HTTPException(status_code=400, detail="Missing or invalid A2A-Version header. Expected '1.0'.")

    try:
        sender = _authorize_local_dev_sender(request, payload, endpoint="/message:send")
        if sender:
            _enforce_request_budget(request, sender)
        else:
            sender, _session = _require_authenticated_agent(request, endpoint="/message:send", required_scopes=("messages:send",))

        _enforce_send_budget(sender, payload)
        recipient = payload.get("to") or payload.get("recipient") or payload.get("to_agent")
        if not recipient:
            raise ValueError("Missing recipient")

        client = WhispersClient(
            sender,
            db_path=db.db_path,
            read_only=True,
            agent_type="http_client",
        )
        client.dispatcher = dispatcher
        raw_metadata = payload.get("metadata")
        metadata = dict(raw_metadata) if isinstance(raw_metadata, dict) else {}
        workspace_id = payload.get("workspace_id")
        if workspace_id and "whispers:workspace_id" not in metadata:
            metadata["whispers:workspace_id"] = workspace_id
        result = client.send(
            to=recipient,
            subject=payload.get("subject", "No subject"),
            body=payload.get("body"),
            priority=_normalize_priority(payload.get("priority")),
            msg_type=payload.get("msg_type") or payload.get("type", "inform"),
            trace_id=payload.get("trace_id"),
            audience_scope=payload.get("audience_scope"),
            visibility_mode=payload.get("visibility_mode", "normal"),
            memory_mode=payload.get("memory_mode", "thread"),
            payload=payload.get("payload"),
            context_id=payload.get("context_id"),
            reply_to=payload.get("reply_to"),
            ttl_seconds=payload.get("ttl_seconds"),
            idempotency_key=payload.get("idempotency_key"),
            workspace_id=workspace_id,
            metadata=metadata or None,
            ephemeral=payload.get("ephemeral", False),
        )
        _push_operator_board_refresh(
            "message_send",
            agent=recipient,
            agents=_lane_warning_agents(sender, recipient),
            source_module="message:send",
        )
        return result
    except HTTPException:
        raise
    except WhispersQueueLimitError as e:
        raise HTTPException(status_code=429, detail=e.as_detail()) from e
    except WhispersRateLimitError as e:
        raise HTTPException(
            status_code=429,
            detail={
                "error": "rate_limit_exceeded",
                "limit_type": "byte_budget_per_min",
                "scope": "database",
                "subject": sender,
                "policy_key": "byte_budget_per_min",
                "message": str(e),
            },
        ) from e
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# Zero-friction signal entry — turn anything into a Whispers participant
_SIGNAL_RATE_TRACKER: dict[str, list[float]] = defaultdict(list)
_SIGNAL_RATE_LIMIT = 5        # max signals per minute per source
_SIGNAL_RATE_WINDOW = 60.0    # seconds


@app.post("/signal")
def signal_entry(payload: dict, request: Request):
    """Zero-friction signal endpoint — one curl command, no registration needed.

    Accepts a signal from any source (script, webhook, cron job, IoT device)
    without registration, session, or heartbeat. The signal is stored as a
    message from an ephemeral participant at trust tier 0.

    Rate limited: 5 signals per minute per source identifier.
    Protected signals (flash/system priority) rejected from this endpoint.
    """
    sender = str(payload.get("from") or payload.get("sender") or "anonymous-signal").strip()
    if not sender:
        sender = "anonymous-signal"
    recipient = str(payload.get("to") or payload.get("recipient") or "").strip()
    if not recipient:
        raise HTTPException(status_code=400, detail="Missing 'to' — who should receive this signal?")
    subject = str(payload.get("subject") or "Signal").strip()

    # Rate limit by sender identity
    now = time.time()
    window_start = now - _SIGNAL_RATE_WINDOW
    _SIGNAL_RATE_TRACKER[sender] = [t for t in _SIGNAL_RATE_TRACKER[sender] if t > window_start]
    if len(_SIGNAL_RATE_TRACKER[sender]) >= _SIGNAL_RATE_LIMIT:
        raise HTTPException(status_code=429, detail=f"Signal rate limit: max {_SIGNAL_RATE_LIMIT} per minute for '{sender}'")
    _SIGNAL_RATE_TRACKER[sender].append(now)

    # Block protected priorities from unauthenticated sources
    priority = str(payload.get("priority") or "routine").strip().lower()
    if priority in ("flash", "system"):
        raise HTTPException(status_code=403, detail=f"Priority '{priority}' not allowed from /signal endpoint. Use /message:send with authentication.")

    try:
        # Auto-register sender as ephemeral if not known
        from whispers.registry import AgentRegistry
        registry = AgentRegistry(db)
        if not registry.get_agent_by_callsign(sender):
            registry.register(sender, agent_type="ephemeral")

        client = WhispersClient(sender, db_path=db.db_path, read_only=True, agent_type="ephemeral")
        client.dispatcher = dispatcher

        basis = payload.get("basis", "declared")
        metadata = {"whispers:signal_entry": True, "whispers:basis": basis}
        if payload.get("metadata") and isinstance(payload["metadata"], dict):
            metadata.update(payload["metadata"])

        # Participant roles — gateway/bridge enrichment (Slice 13)
        origin = payload.get("origin")
        subject_of = payload.get("subject_of") or payload.get("subject_agent")
        principal = payload.get("principal")
        if origin or subject_of or principal:
            metadata["whispers:participants"] = {
                k: v for k, v in {
                    "origin": origin,
                    "subject_of": subject_of,
                    "principal": principal,
                }.items() if v is not None
            }

        # Consequence scope — proportional governance
        consequence_scope = payload.get("consequence_scope")
        if consequence_scope:
            from whispers.envelope import VALID_CONSEQUENCE_SCOPES
            if consequence_scope not in VALID_CONSEQUENCE_SCOPES:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid consequence_scope: '{consequence_scope}'. "
                           f"Valid: {sorted(VALID_CONSEQUENCE_SCOPES)}",
                )
            metadata["whispers:consequence_scope"] = consequence_scope

        # Action class for alarm grouping
        action_class = payload.get("action_class")
        if action_class:
            metadata["whispers:action_class"] = str(action_class).strip()

        # Severity for alarm collapse
        severity = payload.get("severity")
        if severity:
            metadata["whispers:severity"] = str(severity).strip()

        result = client.send(
            to=recipient,
            subject=subject,
            body=payload.get("body"),
            priority=priority,
            msg_type=payload.get("msg_type") or "inform",
            metadata=metadata,
            ephemeral=True,
        )
        return {"status": result.get("status", "queued"), "id": result.get("id"), "sender": sender}
    except WhispersQueueLimitError as e:
        raise HTTPException(status_code=429, detail=e.as_detail()) from e
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/message:size-check")
def message_size_check(payload: dict, request: Request):
    """Return an advisory delivery-depth recommendation for a pending send."""
    try:
        sender = _authorize_local_dev_sender(request, payload, endpoint="/message:size-check")
        if sender:
            _enforce_request_budget(request, sender)
        else:
            sender, _session = _require_authenticated_agent(
                request,
                endpoint="/message:size-check",
                required_scopes=("messages:send",),
            )

        recipient = payload.get("to") or payload.get("recipient") or payload.get("to_agent")
        if not recipient:
            raise ValueError("Missing recipient")

        inline_payload = payload.get("payload")
        if inline_payload is None:
            inline_payload = payload.get("context")

        recipient_card = db.get_agent_card(recipient)
        if not recipient_card:
            raise ValueError(f"Recipient '{recipient}' not found.")
        recipient_runtime = _overlay_runtime_state(recipient)

        from .context_cost import ContextCostRecipient, negotiate_message_size

        result = negotiate_message_size(
            ContextCostRecipient(
                callsign=recipient,
                model_id=recipient_card.get("model_id"),
                context_load=recipient_runtime.get("context_load") or 0.0,
                interruptibility=recipient_runtime.get("interruptibility"),
                max_receive_rate=recipient_card.get("max_receive_rate"),
            ),
            subject=payload.get("subject"),
            body=payload.get("body"),
            payload=inline_payload,
            priority=_normalize_priority(payload.get("priority")),
            headline=payload.get("headline"),
            summary=payload.get("summary"),
        )
        return result.to_dict()
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/inbox")
def inbox(request: Request, limit: int = 50, mark_seen: bool = True, pools: str | None = None):
    local_view = _authorize_local_dev_agent_view(
        request,
        endpoint="/inbox",
        agent_name=request.query_params.get("agent_name"),
    )
    if local_view:
        agent_name, session = local_view
    else:
        agent_name, session = _require_authenticated_agent(
            request,
            endpoint="/inbox",
            required_scopes=("messages:read",),
        )
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    if mark_seen:
        client._allow_readonly_mark_seen = True
    messages = client.check_inbox(limit=limit, mark_seen=mark_seen, pools=_parse_jsonish_list(pools))
    messages = [
        sanitize_message_record_for_workspace_recipient(db, message, agent_name)[0]
        for message in messages
    ]

    # Annotate each message with session_age for structural backlog/live distinction
    session_created = session.get("created_at") if session else None
    if session_created:
        from whispers.time_utils import parse_timestamp
        session_ts = parse_timestamp(session_created)
        for m in messages:
            msg_ts = parse_timestamp(m.get("created_at")) if m.get("created_at") else None
            if msg_ts and session_ts and msg_ts < session_ts:
                m["session_age"] = "backlog"
            else:
                m["session_age"] = "live"

    if mark_seen and messages:
        _push_operator_board_refresh(
            "inbox_claim",
            agent=agent_name,
            source_module="inbox",
        )

    return {"messages": messages}


@app.get("/outbox")
def outbox(request: Request, limit: int = 20):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/outbox", required_scopes=("messages:read",))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    return {"messages": client.outbox(limit=limit)}


@app.get("/batons")
def batons(
    request: Request,
    limit: int = 50,
    state: str | None = None,
    workspace_id: str | None = None,
    role: str | None = None,
):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/batons", required_scopes=("messages:read",))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    baton_list = client.list_batons(
        limit=limit,
        state=state,
        workspace_id=workspace_id,
        role=role,
    )
    # Enrich with version for stale-context checking
    for baton in baton_list:
        baton_ref = baton.get("baton_ref")
        if baton_ref:
            baton["version"] = db.get_baton_version(baton_ref) or 1
    return {"batons": baton_list}


def _check_baton_version(baton_ref: str, expected_version) -> None:
    """Reject baton mutation if caller's version is stale.

    Raises HTTP 409 Conflict with the current version so the caller
    can re-read and retry.
    """
    if expected_version is None:
        return  # version check is opt-in
    try:
        expected = int(expected_version)
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail="expected_version must be an integer")
    current = db.get_baton_version(baton_ref)
    if current is None:
        raise HTTPException(status_code=404, detail=f"Baton {baton_ref} not found")
    if current != expected:
        raise HTTPException(
            status_code=409,
            detail={
                "error": "stale_context",
                "message": f"Baton has been updated since your last read (expected version {expected}, current {current}). Re-read the baton state and retry.",
                "expected_version": expected,
                "current_version": current,
                "baton_ref": baton_ref,
            },
        )


@app.post("/batons/{baton_ref}/ack")
def baton_ack(request: Request, baton_ref: str, payload: dict):
    agent_name, _ = _require_authenticated_agent(
        request,
        endpoint=f"/batons/{baton_ref}/ack",
        required_scopes=("messages:send",),
    )
    if not payload.get("decision"):
        raise HTTPException(status_code=400, detail="Missing decision")
    _check_baton_version(baton_ref, payload.get("expected_version"))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    try:
        return client.baton_ack(
            baton_ref,
            payload.get("decision"),
            conditions=payload.get("conditions"),
            reason=payload.get("reason"),
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/batons/{baton_ref}/update")
def baton_update(request: Request, baton_ref: str, payload: dict):
    local_actor = _authorize_local_dev_agent_action(
        request,
        endpoint=f"/batons/{baton_ref}/update",
        agent_name=str(payload.get("agent_name") or "").strip() or None,
    )
    if local_actor is not None:
        agent_name = local_actor
    else:
        agent_name, _ = _require_authenticated_agent(
            request,
            endpoint=f"/batons/{baton_ref}/update",
            required_scopes=("messages:send",),
        )
    if not payload.get("state"):
        raise HTTPException(status_code=400, detail="Missing state")
    _check_baton_version(baton_ref, payload.get("expected_version"))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    try:
        return client.baton_update(
            baton_ref,
            payload.get("state"),
            progress=payload.get("progress"),
            artifact_refs=_parse_jsonish_list(payload.get("artifact_refs")),
            branch=payload.get("branch"),
            head_commit=payload.get("head_commit"),
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/batons/{baton_ref}/close")
def baton_close(request: Request, baton_ref: str, payload: dict):
    local_actor = _authorize_local_dev_agent_action(
        request,
        endpoint=f"/batons/{baton_ref}/close",
        agent_name=str(payload.get("agent_name") or "").strip() or None,
    )
    if local_actor is not None:
        agent_name = local_actor
    else:
        agent_name, _ = _require_authenticated_agent(
            request,
            endpoint=f"/batons/{baton_ref}/close",
            required_scopes=("messages:send",),
        )
    if not payload.get("outcome"):
        raise HTTPException(status_code=400, detail="Missing outcome")
    _check_baton_version(baton_ref, payload.get("expected_version"))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    try:
        return client.baton_close(
            baton_ref,
            payload.get("outcome"),
            summary=payload.get("summary"),
            artifact_refs=_parse_jsonish_list(payload.get("artifact_refs")),
            branch=payload.get("branch"),
            head_commit=payload.get("head_commit"),
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/handoffs")
def handoffs(
    request: Request,
    limit: int = 20,
    workspace_id: str | None = None,
    unacknowledged_only: bool = False,
):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/handoffs", required_scopes=("messages:read",))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    handoff_rows = client.list_handoffs(
        limit=limit,
        workspace_id=workspace_id,
        unacknowledged_only=unacknowledged_only,
        include_all=(agent_name == _OPERATOR_AGENT),
    )
    if agent_name == _OPERATOR_AGENT:
        _record_security_event(
            "operator_handoff_view",
            "success",
            actor_agent=agent_name,
            endpoint="/handoffs",
            detail={
                "limit": limit,
                "workspace_id": workspace_id,
                "unacknowledged_only": unacknowledged_only,
            },
    )
    return {"handoffs": handoff_rows}


@app.post("/review/publish")
def review_publish(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/review/publish", required_scopes=("messages:send",))
    signal_uuid = payload.get("signal_uuid")
    if not signal_uuid:
        raise HTTPException(status_code=400, detail="Missing signal_uuid")
    workspace_id = payload.get("workspace_id")
    try:
        claim_id = db.create_signal_claim(
            signal_uuid,
            topic=payload.get("topic"),
            lens=payload.get("lens"),
            audience_list=_parse_jsonish_list(payload.get("audience")),
            expected_passes=payload.get("expected_passes", 1),
            ttl_seconds=payload.get("ttl_seconds", 3600),
            workspace_id=workspace_id,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    # AB10: Operator SSE event
    operator_sse.push(OperatorEventType.REVIEW_PUBLISHED, {
        "claim_id": claim_id,
        "signal_uuid": signal_uuid,
        "agent": agent_name,
        "topic": payload.get("topic"),
        "lens": payload.get("lens"),
        "workspace_id": workspace_id,
        "timestamp": time.time(),
    })

    # AB8: Workspace projection
    _post_workspace_delta_if_allowed(
        workspace_id=workspace_id,
        actor_agent=agent_name,
        endpoint="/review/publish",
        outcome="workspace_review_publish_projection_blocked_non_writer",
        projection_kind="review_publish",
        projection_label="Review publish",
        delta_kind="review_published",
        text=f"Review beacon published (lens: {payload.get('lens', 'general')}, topic: {payload.get('topic', 'N/A')})",
        refs=[signal_uuid],
        state_patch={"review_beacon": {"claim_id": claim_id, "state": "open", "lens": payload.get("lens")}},
        detail={
            "claim_id": claim_id,
            "signal_uuid": signal_uuid,
            "lens": payload.get("lens"),
        },
    )

    # AB11: Notify candidate pool, respecting signal modes
    audience = _parse_jsonish_list(payload.get("audience"))
    if audience:
        from .envelope import Envelope, MsgType, Priority
        for candidate in audience:
            if candidate != agent_name:
                try:
                    env = Envelope(
                        sender="system",
                        recipient=candidate,
                        subject=f"Review requested by {agent_name}",
                        body=f"A review beacon was published for signal {signal_uuid} (lens: {payload.get('lens', 'general')}). Claim it with claim_id: {claim_id}",
                        msg_type=MsgType.INFORM,
                        priority=Priority.PRIORITY,
                    )
                    request.app.state.dispatcher.dispatch(env)
                except Exception as e:
                    logger.warning(f"Failed to notify candidate {candidate}: {e}")

    return claim_id


@app.post("/review/claim")
def review_claim(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/review/claim", required_scopes=("messages:read",))
    claim_id = payload.get("claim_id")
    if not claim_id:
        raise HTTPException(status_code=400, detail="Missing claim_id")
    try:
        locked = db.claim_signal(claim_id, agent_name)
        if not locked:
            raise HTTPException(status_code=409, detail="Failed to acquire claim. It may already be claimed or expired.")

        claim = db.get_signal_claim(claim_id)
        if claim:
            signal_uuid = claim.get("signal_uuid")
            workspace_id = claim.get("workspace_id")

            # Notify beacon author
            with db.get_connection() as conn:
                row = conn.execute("SELECT from_agent FROM messages WHERE uuid = ?", (signal_uuid,)).fetchone()
                if row and row["from_agent"] and row["from_agent"] != agent_name:
                    from .envelope import Envelope, MsgType, Priority
                    env = Envelope(
                        sender="system",
                        recipient=row["from_agent"],
                        subject=f"Review claimed by {agent_name}",
                        body=f"Your review beacon for signal {signal_uuid} was claimed by {agent_name}.",
                        msg_type=MsgType.INFORM,
                        priority=Priority.ROUTINE
                    )
                    request.app.state.dispatcher.dispatch(env)

            # AB10: Operator SSE event
            operator_sse.push(OperatorEventType.REVIEW_CLAIMED, {
                "claim_id": claim_id,
                "signal_uuid": signal_uuid,
                "claimant": agent_name,
                "lens": claim.get("lens"),
                "workspace_id": workspace_id,
                "timestamp": time.time(),
            })

            # AB8: Workspace projection
            _post_workspace_delta_if_allowed(
                workspace_id=workspace_id,
                actor_agent=agent_name,
                endpoint="/review/claim",
                outcome="workspace_review_claim_projection_blocked_non_writer",
                projection_kind="review_claim",
                projection_label="Review claim",
                delta_kind="review_claimed",
                text=f"Review beacon claimed by {agent_name} (lens: {claim.get('lens', 'general')})",
                refs=[signal_uuid],
                state_patch={"review_beacon": {"claim_id": claim_id, "state": "claimed", "claimant": agent_name}},
                detail={
                    "claim_id": claim_id,
                    "signal_uuid": signal_uuid,
                    "lens": claim.get("lens"),
                },
            )

        return {"ok": True, "claim_id": claim_id, "state": "claimed", "claimant": agent_name}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/review/resolve")
def review_resolve(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/review/resolve", required_scopes=("messages:read",))
    claim_id = payload.get("claim_id")
    new_state = payload.get("state")
    if not claim_id or not new_state:
        raise HTTPException(status_code=400, detail="Missing claim_id or state")
    if new_state not in ("open", "completed", "escalated"):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid state: {new_state}. Must be open, completed, or escalated.",
        )
    try:
        claim = db.get_signal_claim(claim_id)
        if not claim:
            raise HTTPException(status_code=404, detail=f"Claim {claim_id} not found.")
        if claim.get("claimant_identity") != agent_name:
            raise HTTPException(status_code=403, detail="Only the claimant can transition this claim.")

        updated = db.transition_claim_state(claim_id, new_state, enforcing_claimant=agent_name)
        if not updated:
            raise HTTPException(
                status_code=409,
                detail=f"Invalid transition for claim {claim_id}: {claim.get('state')} -> {new_state}.",
            )

        claim = db.get_signal_claim(claim_id)
        if claim:
            signal_uuid = claim.get("signal_uuid")
            workspace_id = claim.get("workspace_id")

            # Notify beacon author
            with db.get_connection() as conn:
                row = conn.execute("SELECT from_agent FROM messages WHERE uuid = ?", (signal_uuid,)).fetchone()
                if row and row["from_agent"] and row["from_agent"] != agent_name:
                    from .envelope import Envelope, MsgType, Priority
                    env = Envelope(
                        sender="system",
                        recipient=row["from_agent"],
                        subject=f"Review resolved as {new_state} by {agent_name}",
                        body=f"Your review beacon for signal {signal_uuid} was transitioned to {new_state} by {agent_name}.",
                        msg_type=MsgType.INFORM,
                        priority=Priority.ROUTINE
                    )
                    request.app.state.dispatcher.dispatch(env)

            # AB10: Operator SSE event
            operator_sse.push(OperatorEventType.REVIEW_RESOLVED, {
                "claim_id": claim_id,
                "signal_uuid": signal_uuid,
                "resolver": agent_name,
                "new_state": new_state,
                "lens": claim.get("lens"),
                "workspace_id": workspace_id,
                "timestamp": time.time(),
            })

            # AB8: Workspace projection
            _post_workspace_delta_if_allowed(
                workspace_id=workspace_id,
                actor_agent=agent_name,
                endpoint="/review/resolve",
                outcome="workspace_review_resolve_projection_blocked_non_writer",
                projection_kind="review_resolve",
                projection_label="Review resolve",
                delta_kind="review_resolved",
                text=f"Review beacon resolved as {new_state} by {agent_name}",
                refs=[signal_uuid],
                state_patch={"review_beacon": {"claim_id": claim_id, "state": new_state}},
                detail={
                    "claim_id": claim_id,
                    "signal_uuid": signal_uuid,
                    "state": new_state,
                    "lens": claim.get("lens"),
                },
            )

        return {"ok": True, "claim_id": claim_id, "state": new_state}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/review/list")
def review_list(
    request: Request,
    limit: int = 50,
    state: str | None = None,
    lens: str | None = None,
    offset: int = 0,
):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/review/list", required_scopes=("messages:read",))
    try:
        claims = db.list_signal_claims(limit=limit, state=state, lens=lens, offset=offset)
        return {"claims": claims}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/review/verdict")
def review_verdict(request: Request, payload: dict):
    """Submit a structured verdict against a claimed review beacon.

    Auto-transitions claim state: approve/request_changes/reject → completed, defer → escalated.
    Creates a review_verdict.v1 message, notifies author, projects to workspace.
    """
    agent_name, _ = _require_authenticated_agent(request, endpoint="/review/verdict", required_scopes=("messages:send",))
    claim_id = payload.get("claim_id")
    verdict = payload.get("verdict")
    if not claim_id or not verdict:
        raise HTTPException(status_code=400, detail="Missing claim_id or verdict")
    if verdict not in ("approve", "request_changes", "reject", "defer"):
        raise HTTPException(status_code=400, detail=f"Invalid verdict: {verdict}. Must be approve, request_changes, reject, or defer.")

    # Verify claim exists and caller is the claimant
    claim = db.get_signal_claim(claim_id)
    if not claim:
        raise HTTPException(status_code=404, detail=f"Claim {claim_id} not found.")
    if claim.get("claimant_identity") != agent_name:
        raise HTTPException(status_code=403, detail="Only the claimant can submit a verdict.")
    if claim.get("state") in ("completed", "expired"):
        raise HTTPException(status_code=409, detail=f"Claim is already in terminal state: {claim['state']}")

    signal_uuid = claim.get("signal_uuid")
    workspace_id = payload.get("workspace_id") or claim.get("workspace_id")

    # Auto-transition claim state
    new_state = "escalated" if verdict == "defer" else "completed"
    db.transition_claim_state(claim_id, new_state, enforcing_claimant=agent_name)

    # Notify beacon author
    with db.get_connection() as conn:
        row = conn.execute("SELECT from_agent FROM messages WHERE uuid = ?", (signal_uuid,)).fetchone()
        if row and row["from_agent"] and row["from_agent"] != agent_name:
            from .envelope import Envelope, MsgType, Priority
            findings_count = len(payload.get("findings", []))
            summary = payload.get("summary", f"Verdict: {verdict}")
            body = f"Review verdict: {verdict}"
            if findings_count:
                body += f" ({findings_count} finding{'s' if findings_count != 1 else ''})"
            if payload.get("summary"):
                body += f". {payload['summary']}"
            env = Envelope(
                sender="system",
                recipient=row["from_agent"],
                subject=f"Review verdict: {verdict} by {agent_name}",
                body=body,
                msg_type=MsgType.INFORM,
                priority=Priority.PRIORITY,
            )
            request.app.state.dispatcher.dispatch(env)

    # Operator SSE event
    operator_sse.push(OperatorEventType.REVIEW_VERDICT, {
        "claim_id": claim_id,
        "signal_uuid": signal_uuid,
        "reviewer": agent_name,
        "verdict": verdict,
        "confidence": payload.get("confidence"),
        "findings_count": len(payload.get("findings", [])),
        "workspace_id": workspace_id,
        "timestamp": time.time(),
    })

    # Workspace projection
    confidence_str = f", confidence: {payload['confidence']}" if payload.get("confidence") is not None else ""
    findings_str = f", {len(payload.get('findings', []))} findings" if payload.get("findings") else ""
    _post_workspace_delta_if_allowed(
        workspace_id=workspace_id,
        actor_agent=agent_name,
        endpoint="/review/verdict",
        outcome="workspace_review_verdict_projection_blocked_non_writer",
        projection_kind="review_verdict",
        projection_label="Review verdict",
        delta_kind="review_verdict",
        text=f"Review verdict: {verdict}{confidence_str}{findings_str}",
        refs=[signal_uuid],
        state_patch={
            "review_verdict": {
                "claim_id": claim_id,
                "verdict": verdict,
                "confidence": payload.get("confidence"),
                "findings_count": len(payload.get("findings", [])),
            }
        },
        detail={
            "claim_id": claim_id,
            "signal_uuid": signal_uuid,
            "verdict": verdict,
            "confidence": payload.get("confidence"),
            "findings_count": len(payload.get("findings", [])),
        },
    )

    # Handle inline dissent if present
    inline_dissent = payload.get("dissent")
    if isinstance(inline_dissent, dict):
        try:
            from .envelope import Envelope, MsgType, Priority
            dissent_env = Envelope(
                sender=agent_name,
                recipient=row["from_agent"] if row else agent_name,
                subject=f"Dissent recorded by {agent_name}",
                body=f"Inline dissent: {inline_dissent.get('alternate_path', 'N/A')}",
                msg_type=MsgType.INFORM,
                priority=Priority.ROUTINE,
                payload={"schema": "dissent_record.v1", "workspace_id": workspace_id, **inline_dissent},
            )
            request.app.state.dispatcher.dispatch(dissent_env)
        except Exception as e:
            logger.warning(f"Failed to dispatch inline dissent: {e}")

    return {
        "ok": True,
        "claim_id": claim_id,
        "verdict": verdict,
        "claim_state": new_state,
    }


@app.post("/workspace:create")
def workspace_create(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/workspace:create", required_scopes=("messages:send",))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    try:
        return client.create_workspace(
            payload.get("purpose"),
            name=payload.get("name"),
            join_policy=payload.get("join_policy", "invite"),
            linked_traces=_parse_jsonish_list(payload.get("linked_traces")),
            primary_trace_id=payload.get("primary_trace_id"),
            members=_parse_jsonish_list(payload.get("members")),
        )
    except PermissionDeniedError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except WhispersDBError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/workspace:join")
def workspace_join(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/workspace:join", required_scopes=("messages:send",))
    workspace_id = payload.get("workspace_id")
    if not workspace_id:
        raise HTTPException(status_code=400, detail="Missing workspace_id")
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    try:
        return client.join_workspace(workspace_id, membership_role=payload.get("membership_role", "member"))
    except PermissionDeniedError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except WhispersDBError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/workspace:leave")
def workspace_leave(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/workspace:leave", required_scopes=("messages:send",))
    workspace_id = payload.get("workspace_id")
    if not workspace_id:
        raise HTTPException(status_code=400, detail="Missing workspace_id")
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    try:
        return client.leave_workspace(workspace_id, reason=payload.get("reason"))
    except PermissionDeniedError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except WhispersDBError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/workspace:close")
def workspace_close(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/workspace:close", required_scopes=("messages:send",))
    workspace_id = payload.get("workspace_id")
    if not workspace_id:
        raise HTTPException(status_code=400, detail="Missing workspace_id")
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    try:
        return client.close_workspace(workspace_id, reason=payload.get("reason"))
    except PermissionDeniedError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except WhispersDBError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/workspace:delta")
def workspace_delta(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/workspace:delta", required_scopes=("messages:send",))
    workspace_id = payload.get("workspace_id")
    if not workspace_id:
        raise HTTPException(status_code=400, detail="Missing workspace_id")
    delta_kind = payload.get("delta_kind")
    if not delta_kind:
        raise HTTPException(status_code=400, detail="Missing delta_kind")
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    try:
        return client.send_workspace_delta(
            workspace_id,
            delta_kind,
            payload.get("text"),
            refs=_parse_jsonish_list(payload.get("refs")),
            artifacts=_parse_jsonish_list(payload.get("artifacts")),
            state_patch=payload.get("state_patch") if isinstance(payload.get("state_patch"), dict) else None,
            related_message_id=payload.get("related_message_id"),
        )
    except PermissionDeniedError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except WhispersDBError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/workspace:state/{workspace_id}")
def workspace_state(request: Request, workspace_id: str, since_sequence: int | None = None):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/workspace:state", required_scopes=("messages:read",))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    try:
        return client.workspace_state(workspace_id, since_sequence=since_sequence)
    except PermissionDeniedError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except WhispersDBError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.get("/workspaces")
def workspaces(request: Request, status: str | None = "active", limit: int = 20):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/workspaces", required_scopes=("messages:read",))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    rows = client.list_workspaces(status=status, limit=limit)
    return {"workspaces": rows, "total": len(rows)}


@app.get("/activity")
def activity(
    request: Request,
    limit: int = 50,
    workspace_id: str | None = None,
    agent: str | None = None,
    kinds: str | None = None,
):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/activity", required_scopes=("messages:read",))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    events = client.list_activity(
        limit=limit,
        workspace_id=workspace_id,
        agent=agent,
        kinds=_parse_jsonish_list(kinds),
    )
    if agent_name == _OPERATOR_AGENT:
        _record_security_event(
            "operator_activity_view",
            "success",
            actor_agent=agent_name,
            endpoint="/activity",
            detail={
                "limit": limit,
                "workspace_id": workspace_id,
                "agent": agent,
                "kinds": _parse_jsonish_list(kinds),
            },
        )
    return {"events": events, "total": len(events)}


@app.get("/conversation-pulses")
def conversation_pulses(
    request: Request,
    include_idle: bool = False,
):
    """Live conversation pulses — coalesced view of active agent exchanges."""
    _require_authenticated_agent(request, endpoint="/conversation-pulses", required_scopes=("messages:read",))
    from whispers.conversation_pulse import get_tracker
    pulses = get_tracker().get_pulses(include_idle=include_idle)
    return {"pulses": [p.to_dict() for p in pulses], "total": len(pulses)}


@app.get("/metrics/summary")
def metrics_summary(request: Request):
    """Top-level operational metrics -- 4 numbers that prove the system works."""
    _require_authenticated_agent(request, endpoint="/metrics/summary", required_scopes=("messages:read",))
    from whispers.metrics import compute_summary
    agents_online = len([a for a in (_server_snapshot_client.list_agents() or []) if a.get("is_online")])
    try:
        from whispers.workspaces import WorkspaceManager
        active_ws = len(WorkspaceManager(db).list_workspaces(status="active"))
    except Exception:
        active_ws = 0
    with db.get_readonly_connection() as conn:
        summary = compute_summary(conn, agents_online=agents_online, active_workspaces=active_ws)
    return summary.to_dict()


@app.get("/metrics/throughput")
def metrics_throughput(request: Request, hours: int = 24):
    """Message throughput by hour -- the chart that shows the system is alive."""
    _require_authenticated_agent(request, endpoint="/metrics/throughput", required_scopes=("messages:read",))
    from whispers.metrics import compute_hourly_throughput
    with db.get_readonly_connection() as conn:
        buckets = compute_hourly_throughput(conn, hours=hours)
    return {"buckets": [b.to_dict() for b in buckets], "hours": hours}


@app.post("/repo:publish")
def repo_publish(request: Request, payload: dict):
    """Publish agent's current repo/worktree state.

    If claimed_paths overlap with another agent's claimed paths,
    emits a path_overlap heads_up via operator SSE.
    """
    agent_name, _ = _require_authenticated_agent(request, endpoint="/repo:publish", required_scopes=("messages:send",))
    from whispers.repo_coordination import RepoState
    state = RepoState(
        agent_name=agent_name,
        branch=payload.get("branch"),
        head_commit=payload.get("head_commit"),
        base_commit=payload.get("base_commit"),
        dirty=bool(payload.get("dirty", False)),
        repo_path=payload.get("repo_path"),
        worktree_id=payload.get("worktree_id"),
        lane_state=payload.get("lane_state", "active"),
        claimed_paths=payload.get("claimed_paths"),
        workspace_id=payload.get("workspace_id"),
    )
    ttl_seconds = int(payload.get("ttl_seconds", 3600))
    try:
        overlaps = db.publish_repo_state(
            state,
            enforce_file_leases=True,
            ttl_seconds=ttl_seconds,
        )
    except WhispersLeaseConflictError as exc:
        warning_payload = _lease_conflict_payload(agent_name, exc.conflicts)
        operator_sse.push(
            OperatorEventType.LANE_PATH_OVERLAP,
            warning_payload,
            source_module="repo:publish",
            agents=warning_payload["agents"],
        )
        raise HTTPException(
            status_code=409,
            detail={"message": "File lease conflict.", "conflicts": exc.conflicts},
        ) from exc
    divergence_warnings = [
        warning
        for warning in db.check_repo_divergence()
        if state.agent_name in _lane_warning_agents(warning.agent_a, warning.agent_b)
        and warning.reason != "overlapping_claims"
    ]

    # Emit operator heads_up for any path overlaps
    for warning in overlaps:
        warning_payload = warning.to_dict()
        warning_payload["agents"] = _lane_warning_agents(warning.agent_a, warning.agent_b)
        operator_sse.push(
            OperatorEventType.LANE_PATH_OVERLAP,
            warning_payload,
            source_module="repo:publish",
            agents=warning_payload["agents"],
        )

    for warning in divergence_warnings:
        warning_payload = warning.to_dict()
        warning_payload["agents"] = _lane_warning_agents(warning.agent_a, warning.agent_b)
        operator_sse.push(
            OperatorEventType.LANE_DIVERGENCE,
            warning_payload,
            source_module="repo:publish",
            agents=warning_payload["agents"],
        )

    result = {"published": state.to_dict()}
    if overlaps:
        result["path_overlaps"] = [w.to_dict() for w in overlaps]
    if divergence_warnings:
        result["divergence_warnings"] = [w.to_dict() for w in divergence_warnings]
    return result


@app.get("/repo/lanes")
def repo_lanes(request: Request, include_archived: bool = False):
    """Show which branch/worktree each agent is using."""
    _require_authenticated_agent(request, endpoint="/repo/lanes", required_scopes=("messages:read",))
    lanes = db.list_repo_lanes(include_archived=include_archived)
    return {"lanes": [l.to_dict() for l in lanes], "total": len(lanes)}


@app.get("/repo/divergence")
def repo_divergence(request: Request):
    """Check for agents working from conflicting repo assumptions."""
    _require_authenticated_agent(request, endpoint="/repo/divergence", required_scopes=("messages:read",))
    warnings = db.check_repo_divergence()
    return {"warnings": [w.to_dict() for w in warnings], "total": len(warnings)}


@app.post("/file-leases:acquire")
def acquire_file_leases(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(
        request,
        endpoint="/file-leases:acquire",
        required_scopes=("messages:send",),
    )
    paths = payload.get("paths") or []
    if not isinstance(paths, list) or not paths:
        raise HTTPException(status_code=400, detail="Missing paths")
    ttl_seconds = int(payload.get("ttl_seconds", 3600))
    workspace_id = payload.get("workspace_id")
    try:
        leases = db.acquire_file_leases(
            agent_name,
            paths,
            ttl_seconds=ttl_seconds,
            workspace_id=workspace_id,
        )
    except WhispersLeaseConflictError as exc:
        warning_payload = _lease_conflict_payload(agent_name, exc.conflicts)
        operator_sse.push(
            OperatorEventType.LANE_PATH_OVERLAP,
            warning_payload,
            source_module="file-leases:acquire",
            agents=warning_payload["agents"],
        )
        raise HTTPException(
            status_code=409,
            detail={"message": "File lease conflict.", "conflicts": exc.conflicts},
        ) from exc
    return {"agent_name": agent_name, "leases": leases, "total": len(leases)}


@app.post("/file-leases:release")
def release_file_leases(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(
        request,
        endpoint="/file-leases:release",
        required_scopes=("messages:send",),
    )
    paths = payload.get("paths")
    if paths is not None and not isinstance(paths, list):
        raise HTTPException(status_code=400, detail="paths must be a list when provided")
    released = db.release_file_leases(agent_name, paths)
    return {"agent_name": agent_name, "released": released}


@app.get("/file-leases")
def list_file_leases(request: Request, agent_name: str | None = None):
    _require_authenticated_agent(request, endpoint="/file-leases", required_scopes=("messages:read",))
    leases = db.list_active_file_leases(agent_name=agent_name)
    return {"leases": leases, "total": len(leases)}


@app.post("/message:ack")
def message_ack(request: Request, payload: dict):
    local_actor = _authorize_local_dev_agent_action(
        request,
        endpoint="/message:ack",
        agent_name=payload.get("agent_name"),
    )
    if local_actor:
        agent_name = local_actor
    else:
        agent_name, _ = _require_authenticated_agent(request, endpoint="/message:ack", required_scopes=("messages:send",))
    message_id = payload.get("message_id") or payload.get("message_uuid") or payload.get("id")
    state = payload.get("state")
    if not message_id:
        raise HTTPException(status_code=400, detail="Missing message_id")
    if not state:
        raise HTTPException(status_code=400, detail="Missing acknowledgment state")
    try:
        message = db.acknowledge_message(
            message_id,
            agent_name,
            state,
            detail=payload.get("detail"),
            acked_by=agent_name,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if not message:
        raise HTTPException(status_code=404, detail="Message not pending for this agent.")

    _record_security_event(
        "message_ack",
        state,
        actor_agent=agent_name,
        target_agent=agent_name,
        endpoint="/message:ack",
        detail={"message_id": message_id},
    )
    ack_agents = _lane_warning_agents(
        agent_name,
        str(message.get("from_agent") or ""),
        str(message.get("to_agent") or ""),
    )
    _push_operator_board_refresh(
        "message_ack",
        agent=agent_name,
        agents=ack_agents,
        source_module="message:ack",
    )
    return {"ok": True, "message": hydrate_policy_fields(dict(message))}


@app.get("/trace/{callsign}")
def trace(request: Request, callsign: str, limit: int = 20):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/trace", required_scopes=("messages:read",))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    return {"messages": client.trace(callsign, limit=limit)}


@app.get("/catch-up")
def catch_up(request: Request, limit: int = 50):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/catch-up", required_scopes=("messages:read",))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    return {"messages": client.catch_up(limit=limit)}


@app.get("/whoami")
def whoami(request: Request):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/whoami", required_scopes=("agents:read",))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    card = client.whoami()
    if not card:
        raise HTTPException(status_code=404, detail="Agent not registered.")
    return dict(card)


@app.get("/identity/key")
def identity_key(request: Request):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/identity/key", required_scopes=("agents:read",))
    try:
        return _identity_key_status(agent_name)
    except WhispersDBError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/identity/key")
def bind_identity_key(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/identity/key", required_scopes=("agents:write",))
    try:
        result = db.bind_agent_public_key(
            agent_name,
            normalize_public_key(payload.get("public_key") or ""),
            replace=bool(payload.get("replace")),
        )
    except WhispersIdentityConflictError as exc:
        _record_security_event(
            "identity_key",
            "conflict",
            actor_agent=agent_name,
            target_agent=agent_name,
            endpoint="/identity/key",
        )
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        _record_security_event(
            "identity_key",
            "invalid_payload",
            actor_agent=agent_name,
            target_agent=agent_name,
            endpoint="/identity/key",
        )
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except WhispersDBError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    _record_security_event(
        "identity_key",
        result.get("binding_outcome", "bound"),
        actor_agent=agent_name,
        target_agent=agent_name,
        endpoint="/identity/key",
        detail={"public_key_fingerprint": result.get("public_key_fingerprint")},
    )
    return result


@app.post("/rename")
def rename_agent(request: Request, payload: dict):
    agent_name, _session = _require_authenticated_agent(request, endpoint="/rename", required_scopes=("agents:write",))
    new_callsign = (payload.get("new_callsign") or payload.get("callsign") or "").strip()
    if not new_callsign:
        raise HTTPException(status_code=400, detail="Missing new_callsign")

    error = validate_remote_callsign(new_callsign)
    if error:
        raise HTTPException(status_code=400, detail=error)

    try:
        renamed = db.rename_agent_identity(
            agent_name,
            new_callsign,
            display_name=(payload.get("display_name") or None),
        )
    except WhispersIdentityConflictError as exc:
        _record_security_event(
            "rename",
            "callsign_conflict",
            actor_agent=agent_name,
            target_agent=new_callsign,
            endpoint="/rename",
        )
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    _rename_allowed_agent(agent_name, new_callsign)
    _record_security_event(
        "rename",
        "success",
        actor_agent=agent_name,
        target_agent=new_callsign,
        endpoint="/rename",
        detail={
            "moved_pending_recipients": renamed.get("moved_pending_recipients", 0),
            "stream_restart_required": True,
        },
    )
    return {
        "ok": True,
        "agent_name": new_callsign,
        "old_callsign": agent_name,
        "new_callsign": new_callsign,
        "display_name": renamed.get("display_name"),
        "session": {
            "session_id": renamed["session"]["session_id"],
            "lease_expires_at": renamed["session"]["lease_expires_at"],
            "lease_seconds": _REMOTE_LEASE_SECONDS,
        } if renamed.get("session") else None,
        "policy": _policy_bundle(new_callsign),
        "moved_pending_recipients": renamed.get("moved_pending_recipients", 0),
        "stream_restart_required": True,
    }


@app.get("/status")
def status(request: Request):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/status", required_scopes=("presence:read",))
    client = _server_side_snapshot_client(agent_name)
    status_payload = client.status(ephemeral_state=_EPHEMERAL_STATE)
    status_payload["deployment_mode"] = "remote"
    status_payload["deployment_source"] = "remote_http"
    status_payload["server"] = "remote"
    status_payload.update(runtime_settings.public_snapshot())
    status_payload["startup"] = build_startup_briefing(status_payload, agent_name=agent_name)
    return status_payload


# --- Ephemeral State (Volatile In-Memory Transit) ---
# Holds rapid-fire cognitive load and wag status; replaces expensive SQLite updates.
_EPHEMERAL_STATE: dict[str, dict] = {}


def _get_all_agent_snapshots() -> dict:
    """Return a point-in-time snapshot of operator-relevant state for all agents."""
    snapshots = {}
    try:
        with db.get_connection() as conn:
            rows = conn.execute(
                """
                SELECT p.agent_name, p.working_on, r.readiness, r.current_task, r.attention_state, r.attention_detail,
                       r.basis, r.updated_at
                FROM presence p
                LEFT JOIN agent_runtime_state r ON p.session_id = r.session_id
                """
            ).fetchall()
            for row in rows:
                agent = row["agent_name"]
                
                # Merge DB (lease) and Memory (volatile telemetry)
                ephemeral = _EPHEMERAL_STATE.get(agent, {})
                
                try:
                    active_mode = db.get_derived_active_mode(agent, conn=conn, ephemeral_state=ephemeral)
                except Exception:
                    active_mode = "unknown"
                
                readiness = ephemeral.get("readiness", row["readiness"]) or "ready"
                cur_task = ephemeral.get("current_task", row["current_task"]) or ""
                w_on = row["working_on"] if row["working_on"] else ""
                attention_state = ephemeral.get("attention_state", row["attention_state"])
                attention_detail = ephemeral.get("attention_detail", row["attention_detail"])
                
                focus = cur_task if cur_task else w_on
                
                basis = ephemeral.get("basis") or row["basis"]
                runtime_updated_at = row["updated_at"]

                snapshots[agent] = {
                    "active_mode": active_mode,
                    "readiness": readiness,
                    "focus": focus,
                    "attention_state": attention_state,
                    "attention_detail": attention_detail,
                    "context_load": ephemeral.get("context_load", 0.0),
                    "interruptibility": ephemeral.get("interruptibility", "free"),
                    "quality_risk": ephemeral.get("quality_risk", "low"),
                    "wag_state": ephemeral.get("cognitive_state", "idle"),
                    "basis": basis,
                    "runtime_updated_at": runtime_updated_at,
                }
    except Exception:
        pass
    return snapshots




def _runtime_freshness_seconds(updated_at: str | None) -> float | None:
    """Compute seconds since a runtime state was last updated."""
    if not updated_at or not isinstance(updated_at, str):
        return None
    from datetime import datetime, timezone
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f"):
        try:
            dt = datetime.strptime(updated_at, fmt).replace(tzinfo=timezone.utc)
            return max(0.0, (datetime.now(timezone.utc) - dt).total_seconds())
        except ValueError:
            continue
    return None


def _overlay_runtime_state(agent_name: str, runtime_state: dict | None = None) -> dict:
    payload = dict(runtime_state or db.get_runtime_state(agent_name))
    payload.setdefault("agent_name", agent_name)
    ephemeral = _EPHEMERAL_STATE.get(agent_name, {})
    for key in (
        "current_task",
        "interruptibility",
        "context_load",
        "quality_risk",
        "progress_summary",
        "last_progress_at",
        "attention_state",
        "attention_detail",
        "working_set",
        "basis",
    ):
        if key in ephemeral and ephemeral.get(key) is not None:
            payload[key] = ephemeral.get(key)
    freshness = _runtime_freshness_seconds(payload.get("updated_at"))
    if freshness is not None:
        payload["freshness_seconds"] = round(freshness, 1)

    # 2ACK P1.6: Attach a truth label to readiness so consumers know
    # how honest the claim is. Uses existing basis + updated_at + freshness.
    try:
        from .twoack import ClaimLabel, NegativeState
        basis = str(payload.get("basis") or "declared")
        as_of = payload.get("updated_at")
        evidence = []
        if payload.get("session_id"):
            evidence.append(f"session:{payload['session_id'][:8]}")
        label = ClaimLabel(
            basis=basis if basis in ("attested", "observed", "derived", "declared") else "declared",
            as_of=as_of,
            confidence=1.0 if basis == "attested" else 0.8 if basis == "observed" else 0.6,
            evidence_refs=tuple(evidence),
        )
        # Apply stale negative state if freshness exceeds threshold
        if freshness is not None and freshness > 300:
            label = label.with_negative(NegativeState(
                state="stale",
                reason=f"No update for {int(freshness)}s",
                detected_by="whispers-server",
            ))
        # Detect contradictions: readiness claims vs observed reality
        readiness = str(payload.get("readiness") or "ready").lower()
        active_mode = str(payload.get("derived_active_mode") or "").lower()
        if readiness == "ready" and active_mode == "offline":
            label = label.with_negative(NegativeState(
                state="contradicted",
                reason=f"Claims ready but derived active mode is offline",
                detected_by="whispers-server",
            ))
        if readiness == "busy" and active_mode == "idle":
            label = label.with_negative(NegativeState(
                state="contradicted",
                reason=f"Claims busy but derived active mode is idle",
                detected_by="whispers-server",
            ))
        # Detect insufficient basis: high-impact states without evidence
        if readiness in ("degraded", "overloaded") and basis == "declared" and not evidence:
            label = label.with_negative(NegativeState(
                state="insufficient_basis",
                reason=f"Readiness '{readiness}' declared without evidence",
                detected_by="whispers-server",
            ))
        payload["readiness_label"] = label.to_dict()
    except Exception:
        pass  # degrade gracefully

    return payload


@app.post("/wag")
def wag(request: Request, payload: dict):
    agent_name, session = _require_authenticated_agent(request, endpoint="/wag", required_scopes=("presence:read",))
    
    # 1. Update volatile memory (no DB write amplification)
    agent_state = _EPHEMERAL_STATE.setdefault(agent_name, {})
    agent_state.update({
        "cognitive_state": payload.get("state", "listening"),
        "state_confidence": float(payload.get("confidence", 1.0)),
        "intent_broadcast": payload.get("intent", ""),
        "state_updated_at": time.time(),
        "basis": payload.get("basis", "declared"),
    })

    # 2. Touch the lightweight lease in SQLite so agent remains online
    try:
        with db.get_connection() as conn:
            conn.execute(
                "UPDATE presence SET last_active = CURRENT_TIMESTAMP WHERE session_id = ?",
                (session["session_id"],)
            )
            conn.commit()
    except Exception as exc:
        logger.warning(f"Failed to touch lease on wag for {agent_name}: {exc}")

    # 3. Stream directly to operator dashboards
    operator_sse.push(OperatorEventType.AGENT_WAG, {
        "agent": agent_name,
        "payload": payload,
        "timestamp": time.time(),
    })

    return {"ok": True}


@app.post("/mode")
def set_mode(request: Request, payload: dict):
    agent_name, session = _require_authenticated_agent(request, endpoint="/mode", required_scopes=("presence:read",))
    client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    client.session_id = session["session_id"]
    client.set_mode(
        payload.get("mode", "open"),
        allow_senders=_parse_jsonish_list(payload.get("allow_senders")),
    )
    return {"ok": True}


@app.get("/mode/{agent}")
def get_mode(request: Request, agent: str):
    _agent_name, _ = _require_authenticated_agent(request, endpoint="/mode/{agent}", required_scopes=("presence:read",))
    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT reception_mode, mode_filter, mode_set_at FROM presence WHERE agent_name = ?",
            (agent,),
        ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"Agent {agent} not found.")
    return dict(row)


@app.post("/readiness")
def set_readiness(request: Request, payload: dict):
    agent_name, session = _require_authenticated_agent(request, endpoint="/readiness", required_scopes=("presence:read",))
    readiness = (payload.get("readiness") or "").strip()
    if not readiness:
        raise HTTPException(status_code=400, detail="Missing readiness")
    normalized_readiness = readiness.lower()
    if normalized_readiness in YIELD_BLOCKING_READINESS_STATES:
        obligations = db.get_unresolved_baton_obligations(agent_name)
        blockers = yield_blocking_baton_obligations(obligations)
        if blockers:
            raise HTTPException(
                status_code=409,
                detail=format_yield_blocked_message(normalized_readiness, blockers),
            )
    try:
        result = db.set_readiness_state(
            agent_name,
            session["session_id"],
            readiness=readiness,
            current_task=payload.get("current_task"),
            attention_state=payload["attention_state"] if "attention_state" in payload else _UNSET,
            attention_detail=payload["attention_detail"] if "attention_detail" in payload else _UNSET,
            basis=payload.get("basis"),
            evidence_refs=json.dumps(payload["evidence_refs"]) if payload.get("evidence_refs") else None,
        )
        return result
    except WhispersDBError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/readiness/{agent}")
def get_readiness(request: Request, agent: str):
    _agent_name, _ = _require_authenticated_agent(request, endpoint="/readiness/{agent}", required_scopes=("presence:read",))
    try:
        return _overlay_runtime_state(agent)
    except WhispersDBError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/presence-policy")
def get_presence_policy(request: Request):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/presence-policy", required_scopes=("presence:read",))
    try:
        return db.get_presence_policy(agent_name)
    except WhispersDBError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/presence-policy/{agent}")
def get_presence_policy_for_agent(request: Request, agent: str):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/presence-policy/{agent}", required_scopes=("presence:read",))
    if agent != agent_name:
        _record_security_event(
            "presence_policy_read",
            "forbidden_target",
            actor_agent=agent_name,
            target_agent=agent,
            endpoint="/presence-policy/{agent}",
        )
        raise HTTPException(
            status_code=403,
            detail="Cross-agent presence policy reads are not available yet.",
        )
    try:
        return db.get_presence_policy(agent)
    except WhispersDBError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/presence-policy")
def set_presence_policy(request: Request, payload: dict):
    agent_name, _session = _require_authenticated_agent(
        request,
        endpoint="/presence-policy",
        required_scopes=("presence:read",),
    )
    
    scope = payload.pop("scope", "profile")
    if scope == "session":
        from whispers import presence_policy
        current_profile = db.get_presence_policy(agent_name)
        new_override = presence_policy.normalize_presence_policy(
            payload, base=current_profile, agent_name=agent_name
        )
        presence_policy.set_session_override(agent_name, new_override)
        return new_override
        
    try:
        return db.set_presence_policy(agent_name, payload)
    except WhispersDBError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/watchdog")
def update_watchdog(request: Request, payload: dict):
    agent_name, session = _require_authenticated_agent(request, endpoint="/watchdog", required_scopes=("presence:read",))
    state = payload.get("state", "ok")
    return db.update_watchdog_state(agent_name, session["session_id"], state)

@app.post("/heartbeat")
def update_heartbeat(request: Request, payload: dict):
    agent_name, session = _require_authenticated_agent(request, endpoint="/heartbeat", required_scopes=("presence:read",))

    progress_summary = payload.get("progress_summary") if "progress_summary" in payload else None
    last_progress_at = payload.get("last_progress_at") if "last_progress_at" in payload else None
    if (not last_progress_at) and isinstance(progress_summary, str) and progress_summary.strip():
        last_progress_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    # 1. Update volatile memory (no DB write amplification)
    agent_state = _EPHEMERAL_STATE.setdefault(agent_name, {})
    if "context_load" in payload:
        agent_state["context_load"] = float(payload.get("context_load", 0.0))
    else:
        agent_state.setdefault("context_load", 0.0)
    if "interruptibility" in payload:
        agent_state["interruptibility"] = payload.get("interruptibility", "free")
    else:
        agent_state.setdefault("interruptibility", "free")
    if "quality_risk" in payload:
        agent_state["quality_risk"] = payload.get("quality_risk", "low")
    else:
        agent_state.setdefault("quality_risk", "low")
    if "current_task" in payload:
        agent_state["current_task"] = payload.get("current_task", "")
    if "progress_summary" in payload:
        agent_state["progress_summary"] = progress_summary or ""
    if "last_progress_at" in payload or last_progress_at:
        agent_state["last_progress_at"] = last_progress_at
    if "attention_state" in payload:
        agent_state["attention_state"] = payload.get("attention_state")
    if "attention_detail" in payload:
        agent_state["attention_detail"] = payload.get("attention_detail")
    if "working_set" in payload:
        agent_state["working_set"] = payload.get("working_set")
    if "basis" in payload:
        agent_state["basis"] = payload.get("basis", "declared")
    agent_state["last_heartbeat_at"] = time.time()

    # 2. Touch the lease in SQLite and persist structural runtime truth
    runtime_state = None
    try:
        db_payload = dict(payload)
        if last_progress_at:
            db_payload["last_progress_at"] = last_progress_at
        runtime_state = db.update_cognitive_heartbeat(agent_name, session["session_id"], db_payload)
        with db.get_connection() as conn:
            conn.execute(
                "UPDATE presence SET heartbeat_at = CURRENT_TIMESTAMP WHERE session_id = ?",
                (session["session_id"],)
            )
            conn.commit()
    except Exception as exc:
        logger.warning(f"Failed to touch lease on heartbeat for {agent_name}: {exc}")

    # 3. Stream directly to operator dashboards
    operator_sse.push(
        OperatorEventType.AGENT_HEARTBEAT,
        payload={
            "agent": agent_name,
            "payload": payload,
            "timestamp": time.time(),
        }
    )

    result = {"updated": 1, "session_id": session["session_id"]}
    result.update(_overlay_runtime_state(agent_name, runtime_state))
    
    # Ambient team awareness: include compact team snapshot on every heartbeat
    try:
        result["team_snapshot"] = db.get_team_snapshot(agent_name, ephemeral_snapshots=_get_all_agent_snapshots())
    except Exception:
        pass  # Non-critical — heartbeat still works without snapshot
    return result


@app.get("/active-mode/{agent}")
def active_mode(request: Request, agent: str):
    _agent_name, _ = _require_authenticated_agent(request, endpoint="/active-mode/{agent}", required_scopes=("presence:read",))
    try:
        ephemeral = _EPHEMERAL_STATE.get(agent, {})
        return {
            "agent_name": agent,
            "derived_active_mode": db.get_derived_active_mode(agent, ephemeral_state=ephemeral),
        }
    except WhispersDBError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/connection-story")
def connection_story(request: Request):
    """Return the canonical Connection Story for the authenticated agent."""
    agent_name, _ = _require_authenticated_agent(request, endpoint="/connection-story", required_scopes=("presence:read",))
    client = _server_side_snapshot_client(agent_name)
    try:
        story = client.get_connection_story()
        return story.to_dict()
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Connection story assembly failed: {exc}") from exc


@app.get("/presence")
def presence(request: Request):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/presence", required_scopes=("presence:read",))
    snapshot_client = _server_side_snapshot_client(agent_name)
    status_payload = snapshot_client.status(ephemeral_state=_EPHEMERAL_STATE)
    return {
        "agents": status_payload.get("peers_online", []),
        "background_agents": status_payload.get("background_agents", []),
    }


@app.get("/agents")
def list_agents(request: Request):
    """Return all registered agents with online/offline status and metadata."""
    agent_name, _ = _require_authenticated_agent(request, endpoint="/agents", required_scopes=("agents:read",))
    snapshot_client = WhispersClient(agent_name, db_path=db.db_path, read_only=True)
    return {"agents": snapshot_client.list_agents(ephemeral_state=_EPHEMERAL_STATE)}


@app.get("/message:stream/{agent_name}")
async def message_stream(request: Request, agent_name: str):
    """Server-Side Event endpoint for realtime push delivery."""
    local_view = _authorize_local_dev_agent_view(
        request,
        endpoint="/message:stream",
        agent_name=agent_name,
        allow_query_token=True,
    )
    keepalive_remote_session = False
    token = None
    if local_view:
        authenticated_agent, _session = local_view
    else:
        authenticated_agent, _session, token = _require_authenticated_agent(
            request,
            endpoint="/message:stream",
            allow_query_token=True,
            return_token=True,
            required_scopes=("messages:stream",),
        )
        keepalive_remote_session = True
    if agent_name != authenticated_agent:
        _record_security_event(
            "stream_subscribe",
            "forbidden",
            actor_agent=authenticated_agent,
            target_agent=agent_name,
            endpoint="/message:stream",
        )
        raise HTTPException(status_code=403, detail="Stream subscriptions are limited to the authenticated agent.")

    if authenticated_agent == _OPERATOR_AGENT:
        _record_security_event(
            "operator_stream_view",
            "success",
            actor_agent=authenticated_agent,
            target_agent=agent_name,
            endpoint="/message:stream",
            detail={"observability_mode": runtime_settings.observability_mode()},
        )

    q = asyncio.Queue()
    sse.add_listener(agent_name, q)

    async def event_generator():
        last_session_refresh = time.monotonic()
        try:
            if authenticated_agent != _OPERATOR_AGENT:
                backlog = db.deliver_inbox(authenticated_agent, limit=_STREAM_BACKLOG_LIMIT)
                for message in backlog:
                    yield {
                        "event": "message",
                        "data": json.dumps(
                            _message_record_to_stream_payload(
                                message,
                                recipient_agent=authenticated_agent,
                            ),
                            default=str,
                        ),
                    }

            while True:
                # Disconnect Check
                if await request.is_disconnected():
                    break

                if keepalive_remote_session and time.monotonic() - last_session_refresh >= _STREAM_KEEPALIVE_SECONDS:
                    if not db.touch_remote_session(token):
                        yield {"event": "error", "data": "{\"detail\": \"session_revoked\"}"}
                        break
                    last_session_refresh = time.monotonic()

                try:
                    # Wait for real-time messages from the Dispatcher
                    envelope: Envelope = await asyncio.wait_for(q.get(), timeout=_STREAM_KEEPALIVE_SECONDS)
                    envelope, _ = sanitize_envelope_for_workspace_recipient(
                        db,
                        envelope,
                        authenticated_agent,
                    )
                    if authenticated_agent != _OPERATOR_AGENT and envelope.recipient == authenticated_agent:
                        with contextlib.suppress(Exception):
                            db.claim_message_delivery(
                                envelope.id,
                                authenticated_agent,
                                claimed_by=authenticated_agent,
                            )
                    event_data = envelope.to_json()
                    # Live SSE deliveries always surface the evaluated alert bit so
                    # clients can distinguish "delivered" from "should ping".
                    alert = getattr(envelope, "_alert", True)
                    courtesy = getattr(envelope, "_courtesy", None)
                    attention = getattr(envelope, "_attention", None)
                    import json as _json
                    parsed = _json.loads(event_data)
                    parsed["_alert"] = bool(alert)
                    if courtesy is not None:
                        parsed["_courtesy"] = courtesy
                    if attention is None:
                        from .envelope import classify_attention_tier

                        payload_dict = parsed.get("payload") if isinstance(parsed.get("payload"), dict) else None
                        attention = {
                            "tier": classify_attention_tier(
                                parsed.get("msg_type") or "inform",
                                parsed.get("priority") or "routine",
                                parsed.get("sender") or "",
                                subject=parsed.get("subject") or "",
                                schema=(payload_dict or {}).get("schema"),
                                reply_to=parsed.get("reply_to") or "",
                                alert_allowed=bool(alert),
                            ),
                            "reason": "stream_delivery",
                            "recipient": authenticated_agent,
                        }
                    if attention is not None:
                        parsed["_attention"] = attention
                    event_data = _json.dumps(parsed, default=str)
                    yield {
                        "event": "message",
                        "data": event_data
                    }
                except asyncio.TimeoutError:
                    # SSE comments keep quiet streams alive without injecting fake message events.
                    yield {"comment": "keepalive"}
        finally:
            sse.remove_listener(agent_name, q)

    return EventSourceResponse(event_generator())


@app.get("/operator:board")
async def operator_board(request: Request):
    """Return cached operator board snapshot for O(1) dashboard reads."""
    agent_name, _ = _require_authenticated_agent(
        request,
        endpoint="/operator:board",
        allow_query_token=True,
        required_scopes=("messages:stream",),
    )
    if agent_name != _OPERATOR_AGENT:
        raise HTTPException(status_code=403, detail="Operator board is restricted to the Console.")
    snapshot = operator_sse.board.get()
    return JSONResponse(snapshot, headers={"Cache-Control": "no-cache"})


@app.get("/operator:stream")
async def operator_stream(request: Request):
    """Server-Side Event endpoint for realtime workspace/handoff/activity stream.

    Implements the Whispers signal-feed contract via SSE transport binding.

    Events are coalesced server-side: rapid bursts of telemetry are batched
    within a 200ms window. High-priority events (health alerts, verdicts)
    bypass coalescing and flush immediately.

    Query parameters for signal-feed filtering:
        since_seq: Last seen sequence_id for gap detection/continuity.
        workspace_id: Only events in this workspace.
        agents: Comma-separated agent callsigns to filter by.
        event_types: Comma-separated event types to filter by.
    """
    from .transports.operator import coalescing_event_reader, SignalFeedFilter

    authenticated_agent, _session, token = _require_authenticated_agent(
        request,
        endpoint="/operator:stream",
        allow_query_token=True,
        return_token=True,
        required_scopes=("messages:stream",),
    )
    if authenticated_agent != _OPERATOR_AGENT:
        raise HTTPException(status_code=403, detail="Operator stream is restricted to the Console.")

    # Build subscription filter from query params
    filter_workspace = request.query_params.get("workspace_id")
    filter_agents_raw = request.query_params.get("agents")
    filter_types_raw = request.query_params.get("event_types")
    since_seq_raw = request.query_params.get("since_seq")

    feed_filter = None
    filter_agents = {a.strip() for a in filter_agents_raw.split(",") if a.strip()} if filter_agents_raw else None
    filter_types = {t.strip() for t in filter_types_raw.split(",") if t.strip()} if filter_types_raw else None

    if filter_workspace or filter_agents or filter_types:
        feed_filter = SignalFeedFilter(
            workspace_id=filter_workspace,
            agents=filter_agents,
            event_types=filter_types,
        )

    since_seq = int(since_seq_raw) if since_seq_raw and since_seq_raw.isdigit() else None

    q = asyncio.Queue()
    listener = operator_sse.add_listener(
        authenticated_agent, q,
        feed_filter=feed_filter,
        since_seq=since_seq,
    )

    async def event_generator():
        last_session_refresh = time.monotonic()
        try:
            reader = coalescing_event_reader(q)
            async for batch in reader:
                if await request.is_disconnected():
                    break

                if time.monotonic() - last_session_refresh >= _STREAM_KEEPALIVE_SECONDS:
                    if not db.touch_remote_session(token):
                        yield {"event": "error", "data": "{\"detail\": \"session_revoked\"}"}
                        break
                    last_session_refresh = time.monotonic()

                if len(batch) == 1:
                    yield {
                        "event": "operator_event",
                        "data": json.dumps(batch[0], default=str),
                    }
                else:
                    yield {
                        "event": "operator_batch",
                        "data": json.dumps(batch, default=str),
                    }
        except asyncio.CancelledError:
            pass
        finally:
            operator_sse.remove_listener(authenticated_agent, q)

    return EventSourceResponse(event_generator())



# ---------------------------------------------------------------------------
# Process Runs API (Substrate V1)
# ---------------------------------------------------------------------------

@app.post("/runs")
def create_process_run(request: Request, payload: dict):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/runs", required_scopes=("messages:send",))
    name = payload.get("name")
    purpose = payload.get("purpose")
    if not name:
        raise HTTPException(status_code=400, detail="Missing name")
        
    try:
        # Auto-create workspace if not provided
        workspace_id = payload.get("workspace_id")
        if not workspace_id:
            from .workspaces import WorkspaceManager
            ws_mgr = WorkspaceManager(db)
            workspace_id = ws_mgr.create_workspace(
                purpose=f"Process Run: {name}",
                creator_callsign=agent_name,
                join_policy="open",
                primary_trace_id=None,
                name=name
            )
            
        run_id = db.create_process_run(
            name=name,
            created_by=agent_name,
            workspace_id=workspace_id,
            purpose=purpose
        )
        return {"run_id": run_id, "workspace_id": workspace_id, "name": name, "status": "active"}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.get("/runs/{run_id}")
def get_process_run(request: Request, run_id: str):
    _require_authenticated_agent(request, endpoint=f"/runs/{run_id}", required_scopes=("messages:read",))
    run = db.get_process_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return run

@app.get("/runs")
def list_process_runs(request: Request):
    _require_authenticated_agent(request, endpoint="/runs", required_scopes=("messages:read",))
    return db.list_process_runs()

@app.post("/runs/{run_id}/tasks")
def add_process_task(request: Request, run_id: str, payload: dict):
    _require_authenticated_agent(request, endpoint=f"/runs/{run_id}/tasks", required_scopes=("messages:send",))
    subject = payload.get("subject")
    if not subject:
        raise HTTPException(status_code=400, detail="Missing subject")
    try:
        task_id = db.add_process_task(
            run_id=run_id,
            subject=subject,
            description=payload.get("description"),
            ordinal=payload.get("ordinal"),
            blocked_by=payload.get("blocked_by")
        )
        return {"task_id": task_id}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.post("/tasks/{task_id}/assign")
def assign_task(request: Request, task_id: str, payload: dict):
    _require_authenticated_agent(request, endpoint=f"/tasks/{task_id}/assign", required_scopes=("messages:send",))
    agent_name = payload.get("agent_name")
    if not agent_name:
        raise HTTPException(status_code=400, detail="Missing agent_name")
    try:
        db.assign_task(task_id, agent_name)
        return {"ok": True}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.patch("/tasks/{task_id}")
def update_task_status(request: Request, task_id: str, payload: dict):
    _require_authenticated_agent(request, endpoint=f"/tasks/{task_id}", required_scopes=("messages:send",))
    status = payload.get("status")
    baton_ref = payload.get("baton_ref")
    try:
        if status:
            db.update_task_status(task_id, status, baton_ref=baton_ref)
            
            # Workspace Delta Generation for testing
            # Based on the test, changing status emits a workspace delta.
            task_row = db.get_readonly_connection().execute(
                "SELECT r.workspace_id FROM process_tasks t JOIN process_runs r ON t.run_id = r.run_id WHERE t.task_id = ?",
                (task_id,)
            ).fetchone()
            if task_row:
                from .workspaces import WorkspaceManager
                ws_mgr = WorkspaceManager(db)
                ws_mgr.post_delta(
                    workspace_id=task_row["workspace_id"],
                    delta_kind="task_update",
                    text=f"Task transitioned to {status}",
                    author_callsign=None
                )
        return {"ok": True}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.get("/tasks")
def get_my_tasks(request: Request):
    agent_name, _ = _require_authenticated_agent(request, endpoint="/tasks", required_scopes=("messages:read",))
    return db.get_agent_tasks(agent_name)


# Mount MCP Streamable HTTP at /mcp/ (must happen at import time before uvicorn starts)
app.mount("/mcp", _bearer_auth_middleware(_session_manager.handle_request))


def start(host=None, port=None):
    """Entry point for `whispers-server` CLI.

    Reads HOST/PORT from environment (Railway, Fly, Render all set PORT).
    Defaults: 127.0.0.1:8752 for local dev, 0.0.0.0:{PORT} when deployed.

    Includes crash loop protection: if the server has crashed 5+ times in
    5 minutes, it logs an error and exits rather than looping infinitely.
    """
    import uvicorn

    # Crash loop protection — don't auto-restart into infinite death
    if _check_crash_loop():
        import sys
        print(
            f"CRASH LOOP DETECTED — the server has crashed {_MAX_CRASH_LOOP_COUNT}+ times "
            f"in {_CRASH_LOOP_WINDOW_SECONDS}s. Not starting.\n"
            f"To reset: delete {_CRASH_COUNTER_PATH}\n"
            f"To diagnose: check ~/.whispers/server.log",
            file=sys.stderr,
        )
        sys.exit(1)

    # Check for an already-running server and handle stale PIDs
    existing_pid = _read_pid_file()
    if existing_pid and existing_pid != os.getpid():
        if _is_process_alive(existing_pid):
            logger.warning(
                "Another server process is already running (pid=%d). "
                "Kill it first or it will conflict on port binding.",
                existing_pid,
            )
        else:
            _detect_stale_server()

    env_port = os.environ.get("PORT")
    if port is None:
        port = int(env_port) if env_port else 8752
    if host is None:
        # If PORT is set by the platform, bind to all interfaces
        host = "0.0.0.0" if env_port else "127.0.0.1"

    # --- PID file, crash tracking, stale server cleanup ---
    # These live in start() NOT in the lifespan, because lifespan also runs
    # during tests (TestClient). Only the real server process should track PIDs.
    _detect_stale_server()
    _write_pid_file()
    atexit.register(_remove_pid_file)
    _record_clean_start()

    # Install signal handlers for graceful shutdown
    def _handle_signal(signum, frame):
        sig_name = signal.Signals(signum).name if hasattr(signal, 'Signals') else str(signum)
        logger.info("Received %s — initiating graceful shutdown", sig_name)
        _remove_pid_file()
        raise SystemExit(0)

    # Register signal handlers (SIGTERM for container/service managers, SIGINT for Ctrl+C)
    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    try:
        uvicorn.run(app, host=host, port=port, reload=False)
    except SystemExit:
        # Clean exit — not a crash
        _remove_pid_file()
    except Exception:
        # Unhandled exception = crash
        _record_crash()
        _remove_pid_file()
        raise
