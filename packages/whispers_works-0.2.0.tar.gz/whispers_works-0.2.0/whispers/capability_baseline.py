"""Capability baseline vs operating state.

Distinguishes what an agent CAN do at its best from how it's FUNCTIONING
right now. This matters for routing, escalation, and operator truth:

- A strong agent (Opus) having a bad day (context_load=0.95, quality_risk=high)
  should be treated as DEGRADED, not WEAK
- A limited agent (Haiku) functioning normally (context_load=0.3, quality_risk=low)
  should be treated as AT BASELINE, not STRONG

The capability baseline is registered once (or updated on model change).
Operating state comes from runtime heartbeat. The comparison tells you
whether the agent is performing above, at, or below its capability.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, asdict
from typing import Any, Optional

logger = logging.getLogger("whispers")


@dataclass
class CapabilityBaseline:
    """What an agent can do at its best."""
    model_class: str = "unknown"           # titan, fast, manual
    context_window: int = 0                # max tokens
    strengths: list[str] | None = None     # ["architecture", "deep reasoning", "code review"]
    limitations: list[str] | None = None   # ["slow", "expensive", "no tool access"]
    max_concurrent_tasks: int = 1          # how many tasks it can juggle
    autonomy_level: str = "supervised"     # autonomous, supervised, manual
    wake_model: str = "manual_wake"        # listener_backed, manual_wake, always_on

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        if not d.get("strengths"):
            d.pop("strengths", None)
        if not d.get("limitations"):
            d.pop("limitations", None)
        return d


@dataclass
class OperatingAssessment:
    """How the agent is functioning RIGHT NOW relative to baseline."""
    agent: str
    baseline: CapabilityBaseline
    current_capacity: float          # 0.0-1.0 from backpressure
    context_load: float | None       # 0.0-1.0
    quality_risk: str | None         # low, medium, high
    readiness: str                   # ready, busy, blocked, etc.
    performance: str                 # above_baseline, at_baseline, below_baseline, degraded

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent": self.agent,
            "model_class": self.baseline.model_class,
            "performance": self.performance,
            "current_capacity": self.current_capacity,
            "context_load": self.context_load,
            "quality_risk": self.quality_risk,
            "readiness": self.readiness,
            "max_concurrent_tasks": self.baseline.max_concurrent_tasks,
            "strengths": self.baseline.strengths,
            "wake_model": self.baseline.wake_model,
        }


def assess_performance(
    baseline: CapabilityBaseline,
    *,
    capacity: float = 1.0,
    context_load: float | None = None,
    quality_risk: str | None = None,
    readiness: str = "ready",
) -> str:
    """Determine performance level relative to baseline.

    Returns: "above_baseline", "at_baseline", "below_baseline", or "degraded"
    """
    if quality_risk == "high":
        return "degraded"
    if readiness in ("blocked", "paused_by_operator", "degraded"):
        return "degraded"

    load = context_load if isinstance(context_load, (int, float)) else 0.0

    # Titan with high load = below baseline (should be doing better)
    # Fast model with high load = at baseline (expected)
    if baseline.model_class == "titan":
        if load >= 0.8 or capacity < 0.2:
            return "below_baseline"
        if quality_risk == "medium":
            return "below_baseline"
        return "at_baseline"
    elif baseline.model_class == "fast":
        if load >= 0.9:
            return "below_baseline"
        return "at_baseline"
    else:
        # Unknown/manual — just check for obvious degradation
        if load >= 0.9 or quality_risk == "medium":
            return "below_baseline"
        return "at_baseline"


def get_operating_assessment(
    db: Any,
    agent_name: str,
) -> OperatingAssessment:
    """Get full operating assessment for an agent."""
    # Get baseline from agent card
    baseline = CapabilityBaseline()
    try:
        with db.get_readonly_connection() as conn:
            card = conn.execute(
                "SELECT model_id, agent_tier, capabilities, tags FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
                (agent_name,),
            ).fetchone()
            if card:
                model_id = card["model_id"] or ""
                # Infer model class from model_id
                if any(t in model_id.lower() for t in ("opus", "pro", "gpt-4")):
                    baseline.model_class = "titan"
                elif any(t in model_id.lower() for t in ("haiku", "flash", "mini")):
                    baseline.model_class = "fast"
                elif any(t in model_id.lower() for t in ("sonnet", "codex")):
                    baseline.model_class = "titan"

                if card["capabilities"]:
                    try:
                        caps = json.loads(card["capabilities"]) if isinstance(card["capabilities"], str) else card["capabilities"]
                        baseline.strengths = caps.get("strengths", [])
                        baseline.limitations = caps.get("limitations", [])
                        baseline.max_concurrent_tasks = caps.get("max_concurrent_tasks", 1)
                        baseline.autonomy_level = caps.get("autonomy_level", "supervised")
                    except (json.JSONDecodeError, TypeError, AttributeError):
                        pass
    except Exception:
        pass

    # Get current operating state
    capacity = 0.5
    context_load = None
    quality_risk = None
    readiness = "ready"
    try:
        from .backpressure import get_agent_capacity
        cap_result = get_agent_capacity(db, agent_name)
        capacity = cap_result["capacity"]
        context_load = cap_result.get("context_load")
        quality_risk = cap_result.get("quality_risk")
        readiness = cap_result.get("readiness", "ready")
    except Exception:
        pass

    performance = assess_performance(
        baseline,
        capacity=capacity,
        context_load=context_load,
        quality_risk=quality_risk,
        readiness=readiness,
    )

    return OperatingAssessment(
        agent=agent_name,
        baseline=baseline,
        current_capacity=capacity,
        context_load=context_load,
        quality_risk=quality_risk,
        readiness=readiness,
        performance=performance,
    )
