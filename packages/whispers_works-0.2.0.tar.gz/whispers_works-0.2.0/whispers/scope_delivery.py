from __future__ import annotations

import contextlib
import json
from dataclasses import dataclass
from typing import Any

from .envelope import Envelope


_EXPLICIT_CROSS_SCOPE_SCHEMAS = {
    "handoff_baton.v1",
    "baton_ack.v1",
    "baton_update.v1",
    "baton_close.v1",
}


@dataclass(frozen=True)
class WorkspaceDeliveryRedaction:
    workspace_id: str
    schema: str | None
    redaction_mode: str
    reason: str = "non_member_workspace_delivery"

    def as_detail(self, *, message_id: str, explicit_transfer: bool) -> dict[str, Any]:
        return {
            "workspace_id": self.workspace_id,
            "schema": self.schema,
            "redaction_mode": self.redaction_mode,
            "reason": self.reason,
            "message_id": message_id,
            "explicit_transfer": explicit_transfer,
        }


def _normalize_optional_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _load_jsonish(value: Any) -> Any:
    if isinstance(value, str):
        with contextlib.suppress(Exception):
            return json.loads(value)
    return value


def _linked_workspace_for_baton(db, baton_ref: str | None) -> str | None:
    if not baton_ref:
        return None
    with db.get_readonly_connection() as conn:
        row = conn.execute(
            "SELECT linked_workspace_id FROM baton_projections WHERE baton_ref = ?",
            (baton_ref,),
        ).fetchone()
    if not row:
        return None
    return _normalize_optional_text(row["linked_workspace_id"])


def _is_active_workspace_member(db, agent_name: str, workspace_id: str) -> bool:
    with db.get_readonly_connection() as conn:
        row = conn.execute(
            """
            SELECT 1
            FROM workspace_members
            WHERE workspace_id = ?
              AND agent_name = ?
              AND membership_state = 'active'
            """,
            (workspace_id, agent_name),
        ).fetchone()
    return row is not None


def _workspace_scope_info(db, payload: Any, metadata: Any) -> tuple[str | None, str | None, bool]:
    payload_dict = _load_jsonish(payload)
    metadata_dict = _load_jsonish(metadata)
    if not isinstance(metadata_dict, dict):
        metadata_dict = {}

    schema = payload_dict.get("schema") if isinstance(payload_dict, dict) else None
    inner_payload = payload_dict.get("payload") if isinstance(payload_dict, dict) and isinstance(payload_dict.get("payload"), dict) else None

    workspace_id = _normalize_optional_text(metadata_dict.get("whispers:workspace_id"))
    if workspace_id is None and isinstance(payload_dict, dict):
        workspace_id = _normalize_optional_text(payload_dict.get("workspace_id"))
    if workspace_id is None and isinstance(inner_payload, dict):
        workspace_id = _normalize_optional_text(inner_payload.get("workspace_id"))

    baton_payload = inner_payload if isinstance(inner_payload, dict) else payload_dict if isinstance(payload_dict, dict) else None
    if workspace_id is None and schema in _EXPLICIT_CROSS_SCOPE_SCHEMAS and isinstance(baton_payload, dict):
        workspace_id = _linked_workspace_for_baton(
            db,
            _normalize_optional_text(baton_payload.get("baton_ref")),
        )

    if workspace_id is None:
        working_scope = _normalize_optional_text(metadata_dict.get("whispers:working_scope"))
        if working_scope and working_scope.startswith("workspace:"):
            workspace_id = _normalize_optional_text(working_scope.split("workspace:", 1)[1])

    return workspace_id, schema, schema in _EXPLICIT_CROSS_SCOPE_SCHEMAS


def _sanitize_explicit_payload(payload: Any) -> dict[str, Any] | None:
    payload_dict = _load_jsonish(payload)
    if not isinstance(payload_dict, dict):
        return None

    sanitized: dict[str, Any] = {}
    for key in ("wire_v", "schema", "mode", "signal_class"):
        if key in payload_dict:
            sanitized[key] = payload_dict[key]

    trace = payload_dict.get("trace")
    if isinstance(trace, dict):
        sanitized_trace = {
            key: trace[key]
            for key in ("message_id", "trace_id")
            if trace.get(key) not in (None, "")
        }
        if sanitized_trace:
            sanitized["trace"] = sanitized_trace

    if "payload" in payload_dict:
        sanitized["payload"] = payload_dict["payload"]

    return sanitized or None


def sanitize_envelope_for_workspace_recipient(
    db,
    envelope: Envelope,
    recipient: str,
) -> tuple[Envelope, WorkspaceDeliveryRedaction | None]:
    workspace_id, schema, explicit_transfer = _workspace_scope_info(
        db,
        envelope.payload,
        envelope.metadata,
    )
    if not workspace_id or _is_active_workspace_member(db, recipient, workspace_id):
        return envelope, None

    metadata = dict(envelope.metadata or {})
    redaction_mode = "payload_preserved" if explicit_transfer else "full_redaction"
    metadata.update(
        {
            "whispers:scope_redacted": True,
            "whispers:scope_redaction_reason": "non_member_workspace_delivery",
            "whispers:scope_redaction_mode": redaction_mode,
            "whispers:workspace_id": workspace_id,
        }
    )
    if schema:
        metadata["whispers:original_schema"] = schema

    sanitized_envelope = Envelope(
        sender=envelope.sender,
        recipient=envelope.recipient,
        msg_type=envelope.msg_type,
        subject=f"[workspace-scoped {schema}]" if explicit_transfer and schema else "[scope-redacted]",
        priority=envelope.priority,
        audience_scope=envelope.audience_scope,
        visibility_mode=envelope.visibility_mode,
        memory_mode=envelope.memory_mode,
        content_type=envelope.content_type,
        version=envelope.version,
        id=envelope.id,
        body=None,
        payload=_sanitize_explicit_payload(envelope.payload) if explicit_transfer else None,
        trust=envelope.trust,
        summary=envelope.summary,
        authority=envelope.authority,
        authority_proof=envelope.authority_proof,
        policy_hint=envelope.policy_hint,
        context_id=envelope.context_id,
        reply_to=envelope.reply_to,
        trace_id=envelope.trace_id,
        ttl_seconds=envelope.ttl_seconds,
        idempotency_key=envelope.idempotency_key,
        metadata=metadata,
        ephemeral=envelope.ephemeral,
        created_at=envelope.created_at,
    )
    return sanitized_envelope, WorkspaceDeliveryRedaction(
        workspace_id=workspace_id,
        schema=schema,
        redaction_mode=redaction_mode,
    )


def sanitize_message_record_for_workspace_recipient(
    db,
    message: dict[str, Any],
    recipient: str,
) -> tuple[dict[str, Any], WorkspaceDeliveryRedaction | None]:
    payload = _load_jsonish(message.get("payload"))
    metadata = _load_jsonish(message.get("metadata"))
    envelope = Envelope(
        sender=message.get("from_agent") or message.get("sender") or "",
        recipient=message.get("to_agent") or message.get("recipient") or recipient,
        msg_type=message.get("msg_type") or "inform",
        subject=message.get("subject") or "",
        priority=message.get("priority") or "routine",
        audience_scope=message.get("audience_scope"),
        visibility_mode=message.get("visibility_mode") or "normal",
        memory_mode=message.get("memory_mode") or "thread",
        content_type=message.get("content_type") or "text/plain",
        version=message.get("version") or "1.0",
        id=message.get("uuid") or message.get("id") or "",
        body=message.get("body"),
        payload=payload,
        context_id=message.get("context_id"),
        reply_to=message.get("reply_to"),
        trace_id=message.get("trace_id"),
        ttl_seconds=message.get("ttl_seconds"),
        idempotency_key=message.get("idempotency_key"),
        metadata=metadata,
        created_at=message.get("created_at"),
    )
    sanitized_envelope, redaction = sanitize_envelope_for_workspace_recipient(
        db,
        envelope,
        recipient,
    )
    if redaction is None:
        return message, None

    sanitized_message = dict(message)
    sanitized_message["subject"] = sanitized_envelope.subject
    sanitized_message["body"] = sanitized_envelope.body
    sanitized_message["payload"] = sanitized_envelope.payload
    sanitized_message["metadata"] = sanitized_envelope.metadata
    return sanitized_message, redaction
