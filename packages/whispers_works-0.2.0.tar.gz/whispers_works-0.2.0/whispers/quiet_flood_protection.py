"""Quiet flood protection — prevent inbox overwhelm on mode change.

When an agent switches from QUIET to OPEN, they could receive dozens of
queued messages at once. This module caps delivery at a readable amount
and summarizes the overflow.

Rules:
- Max 5 full messages delivered on mode change from QUIET
- Overflow messages are summarized: count by sender, priority breakdown
- Flash messages always delivered in full (never summarized)
- Agent can still fetch all messages explicitly via pagination
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("whispers")

QUIET_FLOOD_LIMIT = 5


def apply_quiet_flood_protection(
    messages: list[dict[str, Any]],
    was_quiet: bool = False,
) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    """Apply flood protection to an inbox batch.

    Args:
        messages: Full list of inbox messages
        was_quiet: Whether the agent was recently in QUIET mode

    Returns:
        (delivered_messages, overflow_summary_or_none)
    """
    if not was_quiet or len(messages) <= QUIET_FLOOD_LIMIT:
        return messages, None

    # Flash messages always get through
    flash = [m for m in messages if m.get("priority") == "flash"]
    non_flash = [m for m in messages if m.get("priority") != "flash"]

    # Deliver flash + up to QUIET_FLOOD_LIMIT non-flash (most recent first)
    budget = max(0, QUIET_FLOOD_LIMIT - len(flash))
    delivered = flash + non_flash[:budget]
    overflow = non_flash[budget:]

    if not overflow:
        return delivered, None

    # Build summary of overflow
    by_sender: dict[str, int] = {}
    by_priority: dict[str, int] = {}
    for m in overflow:
        sender = m.get("from_agent", "unknown")
        by_sender[sender] = by_sender.get(sender, 0) + 1
        prio = m.get("priority", "routine")
        by_priority[prio] = by_priority.get(prio, 0) + 1

    summary = {
        "overflow_count": len(overflow),
        "by_sender": by_sender,
        "by_priority": by_priority,
        "note": f"{len(overflow)} additional messages queued while you were in QUIET mode. Check inbox with a higher limit to see all.",
    }

    return delivered, summary


def format_overflow_summary(summary: dict[str, Any]) -> str:
    """Format overflow summary as a readable string."""
    lines = [f"\n--- {summary['overflow_count']} messages summarized (queued while QUIET) ---"]

    senders = summary.get("by_sender", {})
    if senders:
        sender_parts = [f"{name}: {count}" for name, count in sorted(senders.items(), key=lambda x: -x[1])]
        lines.append(f"  From: {', '.join(sender_parts)}")

    priorities = summary.get("by_priority", {})
    if priorities:
        prio_parts = [f"{p}: {c}" for p, c in sorted(priorities.items())]
        lines.append(f"  Priority: {', '.join(prio_parts)}")

    lines.append(f"  Use message_check with a higher limit to see all.")
    return "\n".join(lines)
