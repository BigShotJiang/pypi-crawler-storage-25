"""Autonomy enforcement — runtime check of agent action permissions.

The autonomy_policies table defines what each agent is allowed to do
per working scope: summarize, classify, reply, external_action. This
module provides the enforcement check that the dispatcher calls before
allowing a message through.

Action classification:
- summarize: generating summaries, condensing information
- classify: categorizing, labeling, triaging messages
- reply: sending replies to conversations
- external_action: side-effecting actions (file writes, API calls, tool use)

Shadow mode: when enabled, the action is allowed but logged as a shadow
event for operator review. The agent doesn't know it's in shadow mode.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Optional

logger = logging.getLogger("whispers")

# Map message types / schemas to action classes
_ACTION_CLASS_MAP = {
    # Reply actions
    "reply": "reply",
    "inform": "reply",
    "note": "reply",
    "accept": "reply",
    "reject": "reply",
    "collaboration": "reply",
    # Classification actions
    "classify": "classify",
    # External actions
    "external_action_request.v1": "external_action",
    "external_action_result.v1": "external_action",
    # Summary actions
    "checkpoint": "summarize",
}

# Schemas that map to action classes
_SCHEMA_ACTION_MAP = {
    "external_action_request.v1": "external_action",
    "external_action_result.v1": "external_action",
    "status_update.v1": "reply",
    "decision_request.v1": "reply",
    "decision_response.v1": "reply",
}


def classify_action(
    msg_type: str,
    payload: dict[str, Any] | str | None = None,
) -> str | None:
    """Determine the action class of a message.

    Returns one of: "summarize", "classify", "reply", "external_action", or None
    if the message doesn't map to a controlled action class.
    """
    # Check schema in payload first (more specific)
    if payload:
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except (json.JSONDecodeError, TypeError):
                payload = {}
        if isinstance(payload, dict):
            schema = payload.get("schema", "")
            if schema in _SCHEMA_ACTION_MAP:
                return _SCHEMA_ACTION_MAP[schema]

    # Fall back to message type
    return _ACTION_CLASS_MAP.get(msg_type)


def check_autonomy(
    db: Any,
    agent_name: str,
    action_class: str,
    working_scope: str | None = None,
) -> dict[str, Any]:
    """Check if an agent is allowed to perform an action.

    Returns:
        {"allowed": True} or
        {"allowed": False, "reason": str, "shadow": bool}

    If no policy exists for the agent, the action is allowed (open by default).
    If a policy exists but the action is not permitted, it's blocked.
    If shadow_mode is on, the action is allowed but flagged for review.
    """
    if not working_scope:
        # No scope declared — check if agent has ANY policy
        if not db.has_any_autonomy_policy(agent_name):
            return {"allowed": True}
        # Agent has policies but didn't declare scope — already handled by
        # scope_widening enforcement in store_message. Let it through here.
        return {"allowed": True}

    policy = db.get_autonomy_policy(agent_name, working_scope)
    if policy is None:
        # No policy for this scope — allowed by default
        return {"allowed": True}

    permission_key = f"can_{action_class}"
    if permission_key not in policy:
        # Unknown action class — allowed (don't block novel actions)
        return {"allowed": True}

    if policy[permission_key]:
        if policy.get("shadow_mode"):
            return {"allowed": True, "shadow": True}
        return {"allowed": True}

    if policy.get("shadow_mode"):
        return {"allowed": True, "shadow": True}

    # Action not permitted
    return {
        "allowed": False,
        "reason": f"autonomy_policy_blocked:{action_class}",
        "shadow": False,
    }
