"""Peer reorientation support — supportive collaboration health.

Lets peers raise an operator-visible advisory concern when another agent
appears off-rhythm, collapsed, overly literal, or otherwise not at its best.

This is NOT a command channel. It's a supportive signal:
- Recorded as a security/health event for operator review
- Optionally sent as a heads_up to the target agent
- Never forces action — the target agent decides how to respond

Use cases:
- "Codex seems to be looping on the same error"
- "Antigravity's output quality dropped — context might be exhausted"
- "Claude is responding to stale instructions from 3 sessions ago"
"""
from __future__ import annotations

import json
import logging
import uuid
from typing import Any, Optional

logger = logging.getLogger("whispers")


def raise_reorientation_concern(
    db: Any,
    observer: str,
    target: str,
    concern: str,
    *,
    suggested_action: str | None = None,
    severity: str = "advisory",  # advisory, concern, urgent
) -> dict[str, Any]:
    """Record a peer reorientation concern.

    Returns the event ID and whether a heads_up was queued.
    """
    if severity not in ("advisory", "concern", "urgent"):
        severity = "advisory"

    event_id = db.record_security_event(
        "peer_reorientation",
        severity,
        actor_agent=observer,
        target_agent=target,
        endpoint="peer_reorientation.raise_concern",
        detail=json.dumps({
            "concern": concern,
            "suggested_action": suggested_action,
            "severity": severity,
        }),
    )

    return {
        "event_id": event_id,
        "observer": observer,
        "target": target,
        "severity": severity,
        "concern": concern,
        "suggested_action": suggested_action,
    }


def get_reorientation_history(
    db: Any,
    target: str | None = None,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Get recent reorientation concerns for an agent or all agents."""
    with db.get_readonly_connection() as conn:
        if target:
            rows = conn.execute(
                """SELECT event_id, actor_agent as observer, target_agent as target,
                          outcome as severity, detail, created_at
                   FROM security_events
                   WHERE event_type = 'peer_reorientation' AND target_agent = ?
                   ORDER BY created_at DESC LIMIT ?""",
                (target, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT event_id, actor_agent as observer, target_agent as target,
                          outcome as severity, detail, created_at
                   FROM security_events
                   WHERE event_type = 'peer_reorientation'
                   ORDER BY created_at DESC LIMIT ?""",
                (limit,),
            ).fetchall()

    results = []
    for r in rows:
        entry = dict(r)
        if entry.get("detail"):
            try:
                entry.update(json.loads(entry["detail"]))
                del entry["detail"]
            except (json.JSONDecodeError, TypeError):
                pass
        results.append(entry)
    return results
