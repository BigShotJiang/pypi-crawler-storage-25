"""Shared process management utilities for Whispers server and client.

Centralizes PID file operations and process liveness checks to prevent
the duplicated implementations from diverging between server.py and client.py.
"""

import logging
import os
import sys
from .path_utils import whispers_path

logger = logging.getLogger(__name__)

_PID_FILE_PATH = whispers_path("server.pid")


def write_pid_file() -> None:
    """Write our PID to disk so clients can reliably identify and manage us."""
    try:
        os.makedirs(os.path.dirname(_PID_FILE_PATH), exist_ok=True)
        with open(_PID_FILE_PATH, "w") as f:
            f.write(str(os.getpid()))
        logger.info("PID file written: %s (pid=%d)", _PID_FILE_PATH, os.getpid())
    except OSError as exc:
        logger.warning("Failed to write PID file: %s", exc)


def remove_pid_file() -> None:
    """Remove our PID file on clean shutdown. Only removes if the stored PID is ours."""
    try:
        if os.path.exists(_PID_FILE_PATH):
            with open(_PID_FILE_PATH) as f:
                stored_pid = f.read().strip()
            if stored_pid == str(os.getpid()):
                os.remove(_PID_FILE_PATH)
                logger.info("PID file removed on clean shutdown")
    except OSError:
        pass


def read_pid_file() -> int | None:
    """Read the server PID from the PID file. Returns None if missing or unreadable."""
    try:
        if os.path.exists(_PID_FILE_PATH):
            with open(_PID_FILE_PATH) as f:
                return int(f.read().strip())
    except (OSError, ValueError):
        pass
    return None


def is_pid_alive(pid: int) -> bool:
    """Check if a process with the given PID is still running."""
    if sys.platform == "win32":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if handle:
            kernel32.CloseHandle(handle)
            return True
        return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except (OSError, ProcessLookupError):
            return False


def pid_file_path() -> str:
    """Return the canonical PID file path."""
    return _PID_FILE_PATH
