"""Priority decay — urgency has a half-life.

Messages don't stay urgent forever. A FLASH message that's been sitting
unread for 15 minutes is no longer an emergency — it's important. A
PRIORITY message unread for an hour is just... a message.

Decay rules:
- FLASH → PRIORITY after 15 minutes unread
- PRIORITY → ROUTINE after 60 minutes unread
- ROUTINE and SYSTEM never decay

Applied at read time (inbox check), not write time. The stored priority
is preserved — decay is a delivery-time view adjustment.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger("whispers")

# Decay thresholds in seconds
FLASH_DECAY_SECONDS = 15 * 60      # 15 minutes
PRIORITY_DECAY_SECONDS = 60 * 60   # 1 hour


def compute_decayed_priority(
    original_priority: str,
    age_seconds: float,
) -> str:
    """Compute the effective priority after time decay."""
    if original_priority == "flash" and age_seconds >= FLASH_DECAY_SECONDS:
        return "priority"
    if original_priority == "priority" and age_seconds >= PRIORITY_DECAY_SECONDS:
        return "routine"
    return original_priority


def apply_priority_decay(
    message: dict[str, Any],
    *,
    now_timestamp: Optional[str] = None,
) -> dict[str, Any]:
    """Apply priority decay to a message based on its age.

    Returns a new dict with effective_priority set if decayed.
    Does not mutate the original.
    """
    priority = message.get("priority", "routine")
    if priority in ("routine", "system"):
        return message  # These don't decay

    created_at = message.get("created_at")
    if not created_at:
        return message

    try:
        from .time_utils import parse_timestamp
        from datetime import datetime, timezone
        msg_ts = parse_timestamp(created_at)
        if not msg_ts:
            return message
        if now_timestamp:
            now = parse_timestamp(now_timestamp)
        else:
            now = datetime.now(timezone.utc)
        if not now:
            return message

        age = (now - msg_ts).total_seconds()
        if age < 0:
            return message

        effective = compute_decayed_priority(priority, age)
        if effective != priority:
            result = dict(message)
            result["effective_priority"] = effective
            result["original_priority"] = priority
            result["priority"] = effective  # Update the visible priority
            return result
    except Exception:
        pass

    return message


def apply_priority_decay_batch(
    messages: list[dict[str, Any]],
    **kwargs,
) -> list[dict[str, Any]]:
    """Apply priority decay to a list of messages."""
    return [apply_priority_decay(m, **kwargs) for m in messages]
