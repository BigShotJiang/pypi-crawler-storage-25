"""Participant rights baseline (security item #10).

Every agent in Whispers has three baseline rights:

1. **Disclosure** — Query all data Whispers holds about them
2. **Challenge** — Contest security decisions that affected them
3. **Retention** — Know and enforce data lifecycle policies

These rights exist regardless of trust tier or workspace membership.
"""
from __future__ import annotations

import json
import logging
import sqlite3
from typing import Any, Optional

logger = logging.getLogger("whispers")

# Retention policy defaults (in days)
RETENTION_POLICY = {
    "security_events": 90,       # Security audit trail
    "dead_letters": 30,          # Dead letter queue
    "blob_provenance": 180,      # Blob ownership tracking
    "workspace_deltas": 90,      # Workspace activity
    "sessions": 30,              # Closed sessions
}


def get_self_disclosure(
    conn: sqlite3.Connection,
    agent_name: str,
) -> dict[str, Any]:
    """Return all data Whispers holds about an agent.

    This is the agent's right to know what the system knows about them.
    """
    disclosure: dict[str, Any] = {"agent_name": agent_name}

    # Agent registration / card
    row = conn.execute(
        "SELECT * FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
        (agent_name,),
    ).fetchone()
    if row:
        card = dict(row)
        # Strip internal fields
        card.pop("public_key_pem", None)
        card.pop("public_key_fingerprint", None)
        disclosure["agent_card"] = card

    # Trust tier
    tier_row = conn.execute(
        "SELECT trust_tier FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
        (agent_name,),
    ).fetchone()
    disclosure["trust_tier"] = tier_row["trust_tier"] if tier_row else 1

    # Autonomy policies
    policies = conn.execute(
        "SELECT working_scope, can_summarize, can_classify, can_reply, can_external_action, shadow_mode "
        "FROM autonomy_policies WHERE agent_id = ?",
        (agent_name,),
    ).fetchall()
    disclosure["autonomy_policies"] = [dict(p) for p in policies]

    # Workspace memberships
    memberships = conn.execute(
        """SELECT wm.workspace_id, w.name, w.purpose, wm.membership_role, wm.membership_state, wm.joined_at
           FROM workspace_members wm
           JOIN workspaces w ON w.workspace_id = wm.workspace_id
           WHERE wm.agent_name = ? AND wm.membership_state = 'active'""",
        (agent_name,),
    ).fetchall()
    disclosure["workspace_memberships"] = [dict(m) for m in memberships]

    # Message counts
    sent = conn.execute(
        "SELECT COUNT(*) as count FROM messages WHERE from_agent = ?",
        (agent_name,),
    ).fetchone()
    received = conn.execute(
        "SELECT COUNT(*) as count FROM message_recipients WHERE recipient_callsign = ?",
        (agent_name,),
    ).fetchone()
    disclosure["message_counts"] = {
        "sent": sent["count"] if sent else 0,
        "received": received["count"] if received else 0,
    }

    # Security events involving this agent (last 30 days)
    events = conn.execute(
        """SELECT event_id, event_type, outcome, endpoint, created_at
           FROM security_events
           WHERE (actor_agent = ? OR target_agent = ?)
           AND created_at > datetime('now', '-30 days')
           ORDER BY created_at DESC LIMIT 50""",
        (agent_name, agent_name),
    ).fetchall()
    disclosure["recent_security_events"] = [dict(e) for e in events]

    # Blobs stored by this agent
    blobs = conn.execute(
        "SELECT blob_ref, workspace_id, created_at FROM blob_provenance WHERE stored_by = ?",
        (agent_name,),
    ).fetchall()
    disclosure["blobs_stored"] = [dict(b) for b in blobs]

    # Active sessions
    try:
        sessions = conn.execute(
            """SELECT session_id, session_kind, created_at
               FROM agent_sessions
               WHERE agent_name = ? AND lease_expires_at > datetime('now')""",
            (agent_name,),
        ).fetchall()
        disclosure["active_sessions"] = [dict(s) for s in sessions]
    except Exception:
        disclosure["active_sessions"] = []

    # Baton participation
    batons = conn.execute(
        """SELECT baton_ref, state, owner_callsign, assignee_callsign, working_scope, updated_at
           FROM baton_projections
           WHERE owner_callsign = ? OR assignee_callsign = ?
           ORDER BY updated_at DESC LIMIT 20""",
        (agent_name, agent_name),
    ).fetchall()
    disclosure["baton_participation"] = [dict(b) for b in batons]

    # Retention policy (what they're entitled to know)
    disclosure["retention_policy"] = {
        k: f"{v} days" for k, v in RETENTION_POLICY.items()
    }

    return disclosure


def record_challenge(
    conn: sqlite3.Connection,
    agent_name: str,
    event_id: str,
    reason: str,
) -> dict[str, Any]:
    """Record a formal challenge against a security event.

    Any agent can challenge a security event that involved them.
    Challenges are recorded as security events themselves, creating
    an audit trail that operators can review.
    """
    import uuid as uuid_mod

    # Verify the event exists and involves this agent
    event = conn.execute(
        "SELECT event_id, event_type, outcome, actor_agent, target_agent, detail FROM security_events WHERE event_id = ?",
        (event_id,),
    ).fetchone()

    if not event:
        return {"error": "Security event not found", "event_id": event_id}

    if event["actor_agent"] != agent_name and event["target_agent"] != agent_name:
        return {
            "error": "You can only challenge events that involved you",
            "event_id": event_id,
        }

    # Record the challenge
    challenge_id = str(uuid_mod.uuid4())
    detail = json.dumps({
        "challenged_event_id": event_id,
        "challenged_event_type": event["event_type"],
        "challenged_outcome": event["outcome"],
        "challenge_reason": reason,
        "original_detail": event["detail"],
    })
    conn.execute(
        """INSERT INTO security_events
           (event_id, event_type, outcome, actor_agent, target_agent, endpoint, detail)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (challenge_id, "participant_challenge", "pending_review",
         agent_name, None, "participant_rights.challenge", detail),
    )
    conn.commit()

    return {
        "challenge_id": challenge_id,
        "challenged_event_id": event_id,
        "status": "pending_review",
        "message": "Challenge recorded. An operator can review this via security event audit.",
    }


def enforce_retention(conn: sqlite3.Connection) -> dict[str, int]:
    """Enforce retention policy — delete data older than policy thresholds.

    Returns counts of rows cleaned per category.
    """
    cleaned: dict[str, int] = {}

    # Security events (90 days)
    cursor = conn.execute(
        "DELETE FROM security_events WHERE created_at < datetime('now', ?)",
        (f"-{RETENTION_POLICY['security_events']} days",),
    )
    cleaned["security_events"] = cursor.rowcount

    # Dead letters (30 days)
    cursor = conn.execute(
        "DELETE FROM dead_letters WHERE created_at < datetime('now', ?)",
        (f"-{RETENTION_POLICY['dead_letters']} days",),
    )
    cleaned["dead_letters"] = cursor.rowcount

    # Blob provenance (180 days)
    cursor = conn.execute(
        "DELETE FROM blob_provenance WHERE created_at < datetime('now', ?)",
        (f"-{RETENTION_POLICY['blob_provenance']} days",),
    )
    cleaned["blob_provenance"] = cursor.rowcount

    # Workspace events (90 days)
    try:
        cursor = conn.execute(
            "DELETE FROM workspace_events WHERE created_at < datetime('now', ?)",
            (f"-{RETENTION_POLICY['workspace_deltas']} days",),
        )
        cleaned["workspace_events"] = cursor.rowcount
    except Exception:
        cleaned["workspace_events"] = 0

    conn.commit()

    total = sum(cleaned.values())
    if total > 0:
        logger.info(f"[Retention] Cleaned {total} expired rows: {cleaned}")

    return cleaned
