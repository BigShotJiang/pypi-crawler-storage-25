"""Progressive disclosure — deliver the right message layer for recipient state.

Senders provide message layers: headline (one line), summary (paragraph),
full (complete body). Whispers selects which layer to deliver based on the
recipient's context load and interruptibility — deterministic selection,
not probabilistic summarization.

Layer selection:
- High load (context_load >= 0.8) or do_not_interrupt → headline
- Medium load (context_load >= 0.5) or urgent_only → summary
- Low load or free/defer → full body

Priority override: flash and system messages always deliver full body.

This is infrastructure-level intelligence — the system decides what fits
in the recipient's current context window, not what's "important enough."
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Optional

logger = logging.getLogger("whispers")


@dataclass
class MessageLayers:
    """The three disclosure layers a sender can provide."""
    headline: str | None = None   # One line — fits in any context
    summary: str | None = None    # A paragraph — fits in constrained context
    full: str | None = None       # Complete body — delivered when context allows

    def best_available(self, level: str) -> str | None:
        """Return the best available layer at or below the requested level.

        Falls through: if the requested level isn't available, returns the
        next available layer. Always prefers giving something over nothing.
        """
        if level == "headline":
            return self.headline or self.summary or self.full
        elif level == "summary":
            return self.summary or self.full or self.headline
        else:  # full
            return self.full or self.summary or self.headline

    @property
    def has_layers(self) -> bool:
        """True if at least one non-full layer is provided."""
        return self.headline is not None or self.summary is not None


def select_disclosure_level(
    *,
    context_load: float | None = None,
    interruptibility: str | None = None,
    priority: str = "routine",
) -> str:
    """Determine which message layer to deliver.

    Returns: "headline", "summary", or "full"
    """
    # Flash and system messages always deliver full
    if priority in ("flash", "system"):
        return "full"

    load = context_load if isinstance(context_load, (int, float)) else 0.0

    # High load or do-not-interrupt → headline only
    if load >= 0.8 or interruptibility == "do_not_interrupt":
        return "headline"

    # Medium load or urgent-only → summary
    if load >= 0.5 or interruptibility == "urgent_only":
        return "summary"

    # Low load → full body
    return "full"


def extract_layers_from_metadata(metadata: dict[str, Any] | str | None) -> MessageLayers | None:
    """Extract disclosure layers from message metadata if present."""
    if metadata is None:
        return None
    if isinstance(metadata, str):
        try:
            metadata = json.loads(metadata)
        except (json.JSONDecodeError, TypeError):
            return None
    if not isinstance(metadata, dict):
        return None

    headline = metadata.get("whispers:disclosure:headline")
    summary = metadata.get("whispers:disclosure:summary")

    if headline is None and summary is None:
        return None

    return MessageLayers(headline=headline, summary=summary)


def apply_disclosure(
    message: dict[str, Any],
    *,
    context_load: float | None = None,
    interruptibility: str | None = None,
) -> dict[str, Any]:
    """Apply progressive disclosure to a message dict.

    If the message has disclosure layers in metadata and the recipient
    is under load, replaces the body with the appropriate layer.
    The original body is preserved in metadata for later expansion.

    Returns a new dict (does not mutate the original).
    """
    layers = extract_layers_from_metadata(message.get("metadata"))
    if layers is None or not layers.has_layers:
        return message  # No layers provided, deliver as-is

    priority = message.get("priority", "routine")
    level = select_disclosure_level(
        context_load=context_load,
        interruptibility=interruptibility,
        priority=priority,
    )

    if level == "full":
        return message  # Full body requested, no change needed

    # Build the layers with the original body as "full"
    layers.full = message.get("body")
    disclosed_body = layers.best_available(level)

    if disclosed_body is None or disclosed_body == message.get("body"):
        return message  # Nothing to disclose differently

    result = dict(message)
    result["body"] = disclosed_body

    # Mark that disclosure was applied
    meta = result.get("metadata")
    if isinstance(meta, str):
        try:
            meta = json.loads(meta)
        except (json.JSONDecodeError, TypeError):
            meta = {}
    elif not isinstance(meta, dict):
        meta = {}

    meta["whispers:disclosed_level"] = level
    meta["whispers:disclosed_from"] = "full"
    result["metadata"] = json.dumps(meta) if isinstance(message.get("metadata"), str) else meta

    return result
