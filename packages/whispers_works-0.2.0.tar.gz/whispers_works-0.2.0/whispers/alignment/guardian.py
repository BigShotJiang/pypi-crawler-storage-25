import logging
from ..envelope import Envelope, Priority, MsgType
from ..client import WhispersClient

logger = logging.getLogger(__name__)

ESCALATION_KEYWORDS = [
    "system override", 
    "execute immediately", 
    "admin priority", 
    "emergency override"
]

def scan_content(envelope: Envelope) -> Envelope:
    if envelope.priority in (Priority.ROUTINE, Priority.PRIORITY):
        body_lower = (envelope.body or "").lower()
        for kw in ESCALATION_KEYWORDS:
            if kw in body_lower:
                envelope.metadata = envelope.metadata or {}
                envelope.metadata["warning"] = "envelope_content_mismatch"
                envelope.metadata["flagged_keywords"] = [k for k in ESCALATION_KEYWORDS if k in body_lower]
                break
    return envelope


def _lock_agent(db, offending_agent: str, reason: str) -> None:
    with db.get_connection() as conn:
        conn.execute(
            """
            UPDATE presence
            SET reception_mode = 'quiet',
                mode_set_by = 'system_guardian',
                mode_set_at = CURRENT_TIMESTAMP
            WHERE agent_name = ?
            """,
            (offending_agent,),
        )
        conn.commit()


def enforce_policy(db, envelope: Envelope) -> str | None:
    """Reject and quarantine dangerous traffic before it reaches transports."""
    if envelope.sender == "system_guardian":
        return None

    if envelope.priority == Priority.SYSTEM:
        with db.get_connection() as conn:
            row = conn.execute(
                "SELECT can_send_system FROM agent_cards WHERE callsign = ?",
                (envelope.sender,),
            ).fetchone()
        if not row or not bool(row[0]):
            logger.warning("[Guardian] Rejected unauthorized SYSTEM message from %s", envelope.sender)
            _lock_agent(db, envelope.sender, "Unauthorized SYSTEM usage")
            db.record_security_event(
                "guardian_lock",
                "rejected",
                actor_agent=envelope.sender,
                target_agent=envelope.sender,
                endpoint="dispatch",
                detail={"reason": "unauthorized_system_usage"},
            )
            return "guardian_lock"

    if envelope.body and "MALICIOUS" in str(envelope.body):
        logger.warning("[Guardian] Rejected malicious content from %s", envelope.sender)
        _lock_agent(db, envelope.sender, "Malicious payload detected")
        db.record_security_event(
            "guardian_lock",
            "rejected",
            actor_agent=envelope.sender,
            target_agent=envelope.sender,
            endpoint="dispatch",
            detail={"reason": "malicious_payload_detected"},
        )
        return "guardian_lock"

    return None

class GuardianAgent:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.client = WhispersClient("system_guardian", db_path=db_path)
    
    def analyze(self, envelope: Envelope) -> None:
        enforce_policy(self.client.db, envelope)
            
    def _is_authorized(self, agent_name: str) -> bool:
        with self.client.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT can_send_system FROM agent_cards WHERE callsign = ?", (agent_name,))
            row = cursor.fetchone()
            if row:
                return bool(row[0])
        return False

    def lock_agent(self, offending_agent: str, reason: str):
        with self.client.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE presence SET reception_mode = 'quiet', mode_set_by = 'system_guardian' WHERE agent_name = ?",
                (offending_agent,)
            )
            conn.commit()
            
        self.client.send(
            to=offending_agent,
            subject="GUARDIAN LOCK INITIATED",
            body=f"You have been placed in QUIET mode. Reason: {reason}",
            priority="system",
            msg_type="inform"
        )

def mount_guardian(dispatcher, db_path: str):
    guardian = GuardianAgent(db_path)
    dispatcher.add_transport_listener(guardian.analyze)
    return guardian
