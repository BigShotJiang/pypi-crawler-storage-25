"""Collaboration health signal detection.

Detects dysfunction patterns from existing substrate (messages, presence,
heartbeat, workspaces) and surfaces them as actionable signals for the
operator. No new storage — purely derived from what already exists.
"""

import logging
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)


class Severity(str, Enum):
    INFO = "info"
    WARNING = "warning"
    ESCALATE = "escalate"


@dataclass
class HealthSignal:
    """A single collaboration health observation."""

    signal: str  # stalled_handoff, stale_availability, bad_timing_interruption, missing_challenge
    severity: Severity
    confidence: float  # 0.0-1.0
    suggestion: str  # human-readable next action
    detected_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    details: dict = field(default_factory=dict)

    @property
    def signal_id(self) -> str:
        """Stable key for deduplication. Derived from signal type + distinguishing detail."""
        if self.signal == "stalled_handoff":
            return f"stalled_handoff:{self.details.get('handoff_uuid', 'unknown')}"
        if self.signal == "stale_availability":
            return f"stale_availability:{self.details.get('agent', 'unknown')}"
        if self.signal == "bad_timing_interruption":
            return f"bad_timing:{self.details.get('message_uuid', 'unknown')}"
        if self.signal == "missing_challenge":
            return f"missing_challenge:{self.details.get('workspace_id', '')}:{self.details.get('sequence', '')}"
        if self.signal in ("blind_work", "blind_wait", "stale_progress"):
            return f"{self.signal}:{self.details.get('agent', 'unknown')}"
        if self.signal == "blocking_dissent_unresolved":
            return f"{self.signal}:{self.details.get('dissent_ref', 'unknown')}"
        return f"{self.signal}:{id(self)}"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["signal_id"] = self.signal_id
        d["severity"] = self.severity.value
        return d


def clamp_confidence(value: float) -> float:
    return max(0.0, min(1.0, value))


class CollaborationHealthScanner:
    """Periodic scanner that detects collaboration health issues from existing substrate."""

    SCAN_INTERVAL_SECONDS = 60

    # Thresholds
    STALLED_HANDOFF_WARNING_MINUTES = 15
    STALLED_HANDOFF_ESCALATE_MINUTES = 30
    STALE_AVAILABILITY_MINUTES = 10
    MISSING_CHALLENGE_MINUTES = 15

    def __init__(self, db):
        self.db = db
        self._active_signals: dict[str, HealthSignal] = {}
        self._bad_timing_signals: dict[str, HealthSignal] = {}

    def scan(self) -> list[HealthSignal]:
        """Run all periodic detection rules. Returns new or changed signals."""
        signals = []
        try:
            signals.extend(self._detect_stalled_handoffs())
        except Exception:
            logger.warning("Stalled handoff detection failed", exc_info=True)
        try:
            signals.extend(self._detect_stale_availability())
        except Exception:
            logger.warning("Stale availability detection failed", exc_info=True)
        try:
            signals.extend(self._detect_missing_challenges())
        except Exception:
            logger.warning("Missing challenge detection failed", exc_info=True)
        try:
            signals.extend(self._detect_operator_blindness())
        except Exception:
            logger.warning("Operator blindness detection failed", exc_info=True)
        try:
            signals.extend(self._detect_blocking_dissents())
        except Exception:
            logger.warning("Blocking dissents detection failed", exc_info=True)

        return self._deduplicate_and_update(signals)

    def get_active_signals(self) -> list[HealthSignal]:
        """Return all currently active signals (periodic + inline)."""
        all_signals = dict(self._active_signals)
        all_signals.update(self._bad_timing_signals)
        return list(all_signals.values())

    def record_bad_timing(self, signal: HealthSignal) -> None:
        """Record an inline bad-timing signal from the dispatcher."""
        self._bad_timing_signals[signal.signal_id] = signal
        # Auto-expire bad-timing signals after 10 minutes
        cutoff = time.time() - 600
        expired = [
            k for k, v in self._bad_timing_signals.items()
            if _parse_iso_epoch(v.detected_at) < cutoff
        ]
        for k in expired:
            del self._bad_timing_signals[k]

    # ------------------------------------------------------------------
    # Detection rules
    # ------------------------------------------------------------------

    def _detect_blocking_dissents(self) -> list[HealthSignal]:
        signals = []
        with self.db.get_connection() as conn:
            # Query unresolved dissent records with blocking=True
            rows = conn.execute("""
                SELECT m.uuid, m.from_agent, m.created_at,
                       json_extract(m.payload, '$.alternate_path') as alternate_path,
                       json_extract(m.payload, '$.decision_ref') as decision_ref
                FROM messages m
                WHERE m.msg_type = 'inform'
                  AND json_extract(m.payload, '$.schema') = 'dissent_record.v1'
                  AND json_extract(m.payload, '$.blocking') = 1
                  AND NOT EXISTS (
                      SELECT 1 FROM messages res
                      WHERE res.msg_type = 'inform'
                        AND json_extract(res.payload, '$.schema') = 'dissent_resolution.v1'
                        AND json_extract(res.payload, '$.dissent_ref') = m.uuid
                  )
            """).fetchall()

            for row in rows:
                age_seconds = _epoch_now() - _sqlite_epoch(row["created_at"])
                
                signals.append(HealthSignal(
                    signal="blocking_dissent_unresolved",
                    severity=Severity.ESCALATE,
                    confidence=1.0,
                    suggestion=f"Please review blocking dissent from {row['from_agent']} on {row['decision_ref']}.",
                    details={
                        "dissent_ref": row["uuid"],
                        "decision_ref": row["decision_ref"],
                        "age_seconds": age_seconds,
                    }
                ))
        return signals

    def _detect_stalled_handoffs(self) -> list[HealthSignal]:
        signals = []
        with self.db.get_connection() as conn:
            rows = conn.execute("""
                SELECT m.uuid, m.from_agent, m.to_agent, m.subject, m.created_at,
                       p.status as recipient_status, p.heartbeat_at,
                       ars.readiness, ars.interruptibility
                FROM messages m
                JOIN presence p ON p.agent_name = m.to_agent
                LEFT JOIN agent_runtime_state ars ON ars.agent_name = m.to_agent
                LEFT JOIN message_recipients mr
                    ON mr.message_uuid = m.uuid AND mr.recipient_callsign = m.to_agent
                WHERE (m.msg_type = 'handoff' OR m.payload LIKE '%handoff_baton.v1%')
                  AND (mr.read_at IS NULL)
                  AND (mr.ack_state IS NULL OR mr.ack_state = '')
                  AND p.status = 'online'
                  AND (strftime('%s', 'now') - strftime('%s', m.created_at)) > ?
                ORDER BY m.created_at ASC
            """, (self.STALLED_HANDOFF_WARNING_MINUTES * 60,)).fetchall()

            for row in rows:
                stalled_seconds = _epoch_now() - _sqlite_epoch(row["created_at"])
                stalled_minutes = int(stalled_seconds / 60)

                # Confidence scoring
                confidence = 0.7
                if row["readiness"] == "ready":
                    confidence += 0.1
                heartbeat_age = _epoch_now() - _sqlite_epoch(row["heartbeat_at"]) if row["heartbeat_at"] else 999
                if heartbeat_age < 300:
                    confidence += 0.1
                if row["interruptibility"] == "do_not_interrupt":
                    confidence -= 0.2

                severity = Severity.ESCALATE if stalled_minutes >= self.STALLED_HANDOFF_ESCALATE_MINUTES else Severity.WARNING

                signals.append(HealthSignal(
                    signal="stalled_handoff",
                    severity=severity,
                    confidence=clamp_confidence(confidence),
                    suggestion=f"Handoff from {row['from_agent']} to {row['to_agent']} waiting {stalled_minutes} min. "
                               f"{row['to_agent']} is online ({row['readiness'] or 'unknown'} readiness).",
                    details={
                        "handoff_uuid": row["uuid"],
                        "sender": row["from_agent"],
                        "recipient": row["to_agent"],
                        "recipient_status": row["recipient_status"],
                        "recipient_readiness": row["readiness"],
                        "stalled_minutes": stalled_minutes,
                        "subject": row["subject"],
                    },
                ))
        return signals

    def _detect_stale_availability(self) -> list[HealthSignal]:
        signals = []
        with self.db.get_connection() as conn:
            # Find agents who are online + busy/blocked but whose last
            # progress event (message_done, baton close) is > threshold ago.
            # readiness/context_load/last_progress_at live on agent_runtime_state.
            # cognitive_state/intent_broadcast live on presence.
            rows = conn.execute("""
                SELECT p.agent_name, p.heartbeat_at, p.cognitive_state, p.intent_broadcast,
                       ars.readiness, ars.context_load, ars.last_progress_at
                FROM presence p
                JOIN agent_runtime_state ars ON ars.agent_name = p.agent_name
                WHERE p.status = 'online'
                  AND ars.readiness IN ('busy', 'blocked')
                  AND ars.last_progress_at IS NOT NULL
                  AND (strftime('%s', 'now') - strftime('%s', ars.last_progress_at)) > ?
            """, (self.STALE_AVAILABILITY_MINUTES * 60,)).fetchall()

            for row in rows:
                stale_seconds = _epoch_now() - _sqlite_epoch(row["last_progress_at"])
                stale_minutes = int(stale_seconds / 60)

                confidence = 0.5
                # Check for recent workspace activity (no deltas in last 10 min)
                recent_deltas = conn.execute("""
                    SELECT COUNT(*) as cnt FROM workspace_events
                    WHERE actor = ?
                      AND (strftime('%s', 'now') - strftime('%s', created_at)) < ?
                """, (row["agent_name"], self.STALE_AVAILABILITY_MINUTES * 60)).fetchone()
                if recent_deltas and recent_deltas["cnt"] == 0:
                    confidence += 0.2

                # Check wag intent staleness
                if not row["intent_broadcast"]:
                    confidence += 0.1

                # FP-HS4: Suppress if recent heartbeat shows active work
                context_load = row["context_load"]
                if context_load is not None and context_load > 0.5:
                    confidence -= 0.3

                signals.append(HealthSignal(
                    signal="stale_availability",
                    severity=Severity.INFO,
                    confidence=clamp_confidence(confidence),
                    suggestion=f"{row['agent_name']} completed work {stale_minutes} min ago "
                               f"but readiness is still '{row['readiness']}'.",
                    details={
                        "agent": row["agent_name"],
                        "current_readiness": row["readiness"],
                        "stale_minutes": stale_minutes,
                        "cognitive_state": row["cognitive_state"],
                    },
                ))
        return signals

    def _detect_missing_challenges(self) -> list[HealthSignal]:
        signals = []
        with self.db.get_connection() as conn:
            rows = conn.execute("""
                SELECT we.workspace_id, we.actor, we.text, we.created_at, we.sequence
                FROM workspace_events we
                WHERE we.delta_kind = 'decision'
                  AND (strftime('%s', 'now') - strftime('%s', we.created_at)) > ?
                  AND NOT EXISTS (
                    SELECT 1 FROM workspace_events we2
                    WHERE we2.workspace_id = we.workspace_id
                      AND we2.sequence > we.sequence
                      AND we2.sequence <= we.sequence + 10
                      AND we2.actor != we.actor
                      AND we2.delta_kind IN (
                        'note', 'update', 'decision',
                        'review_verdict', 'dissent_recorded'
                      )
                  )
            """, (self.MISSING_CHALLENGE_MINUTES * 60,)).fetchall()

            for row in rows:
                workspace_id = row["workspace_id"]

                # Count active members in this workspace
                member_count = conn.execute("""
                    SELECT COUNT(DISTINCT actor) as cnt
                    FROM workspace_events
                    WHERE workspace_id = ?
                """, (workspace_id,)).fetchone()["cnt"]

                # FP-HS2: Skip solo workspaces
                if member_count <= 1:
                    continue

                confidence = 0.5
                if member_count > 2:
                    confidence += 0.2

                signals.append(HealthSignal(
                    signal="missing_challenge",
                    severity=Severity.INFO,
                    confidence=clamp_confidence(confidence),
                    suggestion=f"Decision by {row['actor']} in workspace {workspace_id} "
                               f"went unchallenged ({member_count} active members).",
                    details={
                        "workspace_id": workspace_id,
                        "decision_actor": row["actor"],
                        "decision_text": (row["text"] or "")[:120],
                        "sequence": row["sequence"],
                        "member_count": member_count,
                    },
                ))
        return signals

    def _detect_operator_blindness(self) -> list[HealthSignal]:
        """Detect agents whose operator-visible state is uninformative."""
        signals = []
        _GENERIC_TASKS = {"working", "busy", "doing stuff", "in progress", "building", ""}

        with self.db.get_connection() as conn:
            rows = conn.execute("""
                SELECT p.agent_name, p.status, p.cognitive_state,
                       ars.readiness, ars.current_task, ars.attention_state,
                       ars.attention_detail, ars.last_progress_at
                FROM presence p
                JOIN agent_runtime_state ars ON ars.agent_name = p.agent_name
                WHERE p.status = 'online'
            """).fetchall()

            for row in rows:
                agent = row["agent_name"]
                readiness = row["readiness"] or "ready"
                current_task = (row["current_task"] or "").strip()
                attention_state = (row["attention_state"] or "").strip()
                attention_detail = (row["attention_detail"] or "").strip()
                last_progress_at = row["last_progress_at"]

                # Blind work: busy but no informative current_task
                if readiness == "busy" and attention_state in ("working", ""):
                    if not current_task or current_task.lower() in _GENERIC_TASKS or len(current_task) < 10:
                        signals.append(HealthSignal(
                            signal="blind_work",
                            severity=Severity.WARNING,
                            confidence=0.8,
                            suggestion=f"{agent} is busy but the operator cannot see what concrete slice is being worked on.",
                            details={"agent": agent, "current_task": current_task or None, "readiness": readiness},
                        ))

                # Blind wait: waiting but no detail on what/who
                if attention_state in ("waiting_on_peer", "waiting_on_operator", "blocked_external"):
                    if not attention_detail:
                        signals.append(HealthSignal(
                            signal="blind_wait",
                            severity=Severity.WARNING,
                            confidence=0.8,
                            suggestion=f"{agent} is {attention_state} but the operator cannot see what is being waited on.",
                            details={"agent": agent, "attention_state": attention_state, "readiness": readiness},
                        ))

                # Stale progress: busy but last_progress_at is old
                if readiness == "busy" and last_progress_at:
                    progress_age = _epoch_now() - _sqlite_epoch(last_progress_at)
                    if progress_age > self.STALE_AVAILABILITY_MINUTES * 60:
                        stale_minutes = int(progress_age / 60)
                        signals.append(HealthSignal(
                            signal="stale_progress",
                            severity=Severity.INFO,
                            confidence=0.6,
                            suggestion=f"{agent} shows busy but last progress was {stale_minutes} min ago.",
                            details={"agent": agent, "stale_minutes": stale_minutes, "readiness": readiness},
                        ))

        return signals

    # ------------------------------------------------------------------
    # Deduplication
    # ------------------------------------------------------------------

    def _deduplicate_and_update(self, new_signals: list[HealthSignal]) -> list[HealthSignal]:
        """Merge new scan results into active signals. Returns signals that are new or changed."""
        new_ids = {s.signal_id for s in new_signals}
        changed: list[HealthSignal] = []

        # Detect cleared signals
        cleared_ids = set(self._active_signals.keys()) - new_ids
        for cid in cleared_ids:
            del self._active_signals[cid]

        # Detect new or changed signals
        for s in new_signals:
            existing = self._active_signals.get(s.signal_id)
            if existing is None or existing.severity != s.severity or abs(existing.confidence - s.confidence) > 0.05:
                changed.append(s)
            self._active_signals[s.signal_id] = s

        return changed

    def get_cleared_ids(self, current_scan: list[HealthSignal]) -> list[str]:
        """Return signal IDs that were active but are no longer detected."""
        current_ids = {s.signal_id for s in current_scan}
        return [sid for sid in self._active_signals if sid not in current_ids]


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _epoch_now() -> float:
    return time.time()


def _sqlite_epoch(ts: Optional[str]) -> float:
    """Parse a SQLite timestamp string to epoch seconds."""
    if not ts:
        return 0.0
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f",
                "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S.%f%z"):
        try:
            dt = datetime.strptime(ts, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except ValueError:
            continue
    return 0.0


def _parse_iso_epoch(ts: str) -> float:
    """Parse an ISO 8601 string to epoch."""
    return _sqlite_epoch(ts)


def check_bad_timing(envelope, recipient_state: dict) -> Optional[HealthSignal]:
    """Inline detection: called by dispatcher after delivery.

    Returns a HealthSignal if a routine message was sent to a
    do_not_interrupt or urgent_only agent, else None.
    """
    from .envelope import Priority

    interruptibility = recipient_state.get("interruptibility", "free")
    if interruptibility not in ("do_not_interrupt", "urgent_only"):
        return None

    priority = envelope.priority if hasattr(envelope, "priority") else None
    if priority != Priority.ROUTINE:
        return None

    # FP-HS3: Operator-sent messages are intentional
    sender = envelope.sender if hasattr(envelope, "sender") else ""
    if sender == "operator":
        return None

    confidence = 0.7
    quality_risk = recipient_state.get("quality_risk", "low")
    if quality_risk == "high":
        confidence += 0.2

    recipient = envelope.recipient if hasattr(envelope, "recipient") else "unknown"

    return HealthSignal(
        signal="bad_timing_interruption",
        severity=Severity.INFO,
        confidence=clamp_confidence(confidence),
        suggestion=f"{sender} sent a routine message to {recipient} who is in {interruptibility} mode.",
        details={
            "message_uuid": getattr(envelope, "id", "unknown"),
            "sender": sender,
            "recipient": recipient,
            "priority": priority.value if hasattr(priority, "value") else str(priority),
            "recipient_interruptibility": interruptibility,
        },
    )
